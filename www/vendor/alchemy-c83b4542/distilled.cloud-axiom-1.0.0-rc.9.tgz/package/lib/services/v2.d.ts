import * as S from "@distilled.cloud/core/schema";
import * as Redacted from "effect/Redacted";
import * as API from "@distilled.cloud/core/api";
import { type AxiomOpError, type AxiomOpContext } from "../protocol.ts";
export type { AxiomOpError, AxiomOpContext };
declare const BadRequest_base: S.Class<BadRequest, S.TaggedStruct<"BadRequest", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequest extends /*@__PURE__*/ BadRequest_base {
}
declare const Conflict_base: S.Class<Conflict, S.TaggedStruct<"Conflict", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class Conflict extends /*@__PURE__*/ Conflict_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const NotFound_base: S.Class<NotFound, S.TaggedStruct<"NotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
declare const UnprocessableEntity_base: S.Class<UnprocessableEntity, S.TaggedStruct<"UnprocessableEntity", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntity extends /*@__PURE__*/ UnprocessableEntity_base {
}
/** array<string> of dataset names for which the annotation appears on charts */
export type CreateAnnotationRequestDatasetsList = Array<string>;
export declare const CreateAnnotationRequestDatasetsList: S.Schema<CreateAnnotationRequestDatasetsList>;
export interface CreateAnnotationRequest {
    /** array<string> of dataset names for which the annotation appears on charts */
    datasets: CreateAnnotationRequestDatasetsList;
    /** Explanation of the event the annotation marks on the charts */
    description?: string;
    /** End time of the annotation */
    endTime?: string;
    /** Time the annotation marks on the charts. If you don't include this field, Axiom assigns the time of the API request to the annotation. */
    time?: string;
    /** Summary of the annotation that appears on the charts */
    title?: string;
    /** Type of the event marked by the annotation. Use only alphanumeric characters or hyphens. For example, "production-deployment". */
    type: string;
    /** URL relevant for the event marked by the annotation. For example, link to GitHub pull request. */
    url?: string;
}
export declare const CreateAnnotationRequest: S.Schema<CreateAnnotationRequest>;
/** array<string> of dataset names for which the annotation appears on charts */
export type AnnotationDatasetsList = Array<string>;
export declare const AnnotationDatasetsList: S.Schema<AnnotationDatasetsList>;
export interface Annotation {
    /** array<string> of dataset names for which the annotation appears on charts */
    datasets: AnnotationDatasetsList;
    /** Explanation of the event the annotation marks on the charts */
    description?: string;
    /** End time of the annotation */
    endTime?: string | null;
    id: string;
    /** Time the annotation marks on the charts. If you don't include this field, Axiom assigns the time of the API request to the annotation. */
    time: string;
    /** Summary of the annotation that appears on the charts */
    title?: string;
    /** Type of the event marked by the annotation. Use only alphanumeric characters or hyphens. For example, "production-deployment". */
    type: string;
    /** URL relevant for the event marked by the annotation. For example, link to GitHub pull request. */
    url?: string;
}
export declare const Annotation: S.Schema<Annotation>;
export type DatasetCapabilitiesValueDataItem = "delete";
export declare const DatasetCapabilitiesValueDataItem: any;
/** Data Management capability */
export type DatasetCapabilitiesValueDataList = Array<DatasetCapabilitiesValueDataItem | (string & {})>;
export declare const DatasetCapabilitiesValueDataList: S.Schema<DatasetCapabilitiesValueDataList>;
export type DatasetCapabilitiesValueIngestItem = "create";
export declare const DatasetCapabilitiesValueIngestItem: any;
/** Ingest capability */
export type DatasetCapabilitiesValueIngestList = Array<DatasetCapabilitiesValueIngestItem | (string & {})>;
export declare const DatasetCapabilitiesValueIngestList: S.Schema<DatasetCapabilitiesValueIngestList>;
export type DatasetCapabilitiesValueQueryItem = "read";
export declare const DatasetCapabilitiesValueQueryItem: any;
/** Query capability */
export type DatasetCapabilitiesValueQueryList = Array<DatasetCapabilitiesValueQueryItem | (string & {})>;
export declare const DatasetCapabilitiesValueQueryList: S.Schema<DatasetCapabilitiesValueQueryList>;
export type DatasetCapabilitiesValueShareItem = "create" | "read" | "delete";
export declare const DatasetCapabilitiesValueShareItem: any;
/** Sharing dataset capability */
export type DatasetCapabilitiesValueShareList = Array<DatasetCapabilitiesValueShareItem | (string & {})>;
export declare const DatasetCapabilitiesValueShareList: S.Schema<DatasetCapabilitiesValueShareList>;
export type DatasetCapabilitiesValueStarredQueriesItem = "create" | "read" | "update" | "delete";
export declare const DatasetCapabilitiesValueStarredQueriesItem: any;
/** Starred queries capability */
export type DatasetCapabilitiesValueStarredQueriesList = Array<DatasetCapabilitiesValueStarredQueriesItem | (string & {})>;
export declare const DatasetCapabilitiesValueStarredQueriesList: S.Schema<DatasetCapabilitiesValueStarredQueriesList>;
export type DatasetCapabilitiesValueTrimItem = "update";
export declare const DatasetCapabilitiesValueTrimItem: any;
/** Data Trimming capability */
export type DatasetCapabilitiesValueTrimList = Array<DatasetCapabilitiesValueTrimItem | (string & {})>;
export declare const DatasetCapabilitiesValueTrimList: S.Schema<DatasetCapabilitiesValueTrimList>;
export type DatasetCapabilitiesValueVacuumItem = "update";
export declare const DatasetCapabilitiesValueVacuumItem: any;
/** Field Vacuuming capability */
export type DatasetCapabilitiesValueVacuumList = Array<DatasetCapabilitiesValueVacuumItem | (string & {})>;
export declare const DatasetCapabilitiesValueVacuumList: S.Schema<DatasetCapabilitiesValueVacuumList>;
export type DatasetCapabilitiesValueVirtualFieldsItem = "create" | "read" | "update" | "delete";
export declare const DatasetCapabilitiesValueVirtualFieldsItem: any;
/** Virtual fields capability */
export type DatasetCapabilitiesValueVirtualFieldsList = Array<DatasetCapabilitiesValueVirtualFieldsItem | (string & {})>;
export declare const DatasetCapabilitiesValueVirtualFieldsList: S.Schema<DatasetCapabilitiesValueVirtualFieldsList>;
export interface DatasetCapabilitiesValue {
    /** Data Management capability */
    data?: DatasetCapabilitiesValueDataList;
    /** Ingest capability */
    ingest?: DatasetCapabilitiesValueIngestList;
    /** Query capability */
    query?: DatasetCapabilitiesValueQueryList;
    /** Sharing dataset capability */
    share?: DatasetCapabilitiesValueShareList;
    /** Starred queries capability */
    starredQueries?: DatasetCapabilitiesValueStarredQueriesList;
    /** Data Trimming capability */
    trim?: DatasetCapabilitiesValueTrimList;
    /** Field Vacuuming capability */
    vacuum?: DatasetCapabilitiesValueVacuumList;
    /** Virtual fields capability */
    virtualFields?: DatasetCapabilitiesValueVirtualFieldsList;
}
export declare const DatasetCapabilitiesValue: S.Schema<DatasetCapabilitiesValue>;
export type DatasetCapabilities = {
    [key: string]: DatasetCapabilitiesValue | undefined;
};
export declare const DatasetCapabilities: S.Schema<DatasetCapabilities>;
export type OrgCapabilitiesAnnotationsItem = "create" | "read" | "update" | "delete";
export declare const OrgCapabilitiesAnnotationsItem: any;
/** Annotations capability */
export type OrgCapabilitiesAnnotationsList = Array<OrgCapabilitiesAnnotationsItem | (string & {})>;
export declare const OrgCapabilitiesAnnotationsList: S.Schema<OrgCapabilitiesAnnotationsList>;
export type OrgCapabilitiesApiTokensItem = "create" | "read" | "update" | "delete";
export declare const OrgCapabilitiesApiTokensItem: any;
/** API tokens capability */
export type OrgCapabilitiesApiTokensList = Array<OrgCapabilitiesApiTokensItem | (string & {})>;
export declare const OrgCapabilitiesApiTokensList: S.Schema<OrgCapabilitiesApiTokensList>;
export type OrgCapabilitiesAuditLogItem = "read";
export declare const OrgCapabilitiesAuditLogItem: any;
/** Audit Log capability */
export type OrgCapabilitiesAuditLogList = Array<OrgCapabilitiesAuditLogItem | (string & {})>;
export declare const OrgCapabilitiesAuditLogList: S.Schema<OrgCapabilitiesAuditLogList>;
export type OrgCapabilitiesBillingItem = "read" | "update";
export declare const OrgCapabilitiesBillingItem: any;
/** Billing capability */
export type OrgCapabilitiesBillingList = Array<OrgCapabilitiesBillingItem | (string & {})>;
export declare const OrgCapabilitiesBillingList: S.Schema<OrgCapabilitiesBillingList>;
export type OrgCapabilitiesDashboardsItem = "create" | "read" | "update" | "delete";
export declare const OrgCapabilitiesDashboardsItem: any;
/** Dashboards capability */
export type OrgCapabilitiesDashboardsList = Array<OrgCapabilitiesDashboardsItem | (string & {})>;
export declare const OrgCapabilitiesDashboardsList: S.Schema<OrgCapabilitiesDashboardsList>;
export type OrgCapabilitiesDatasetsItem = "create" | "read" | "update" | "delete";
export declare const OrgCapabilitiesDatasetsItem: any;
/** Datasets capability */
export type OrgCapabilitiesDatasetsList = Array<OrgCapabilitiesDatasetsItem | (string & {})>;
export declare const OrgCapabilitiesDatasetsList: S.Schema<OrgCapabilitiesDatasetsList>;
export type OrgCapabilitiesEndpointsItem = "create" | "read" | "update" | "delete";
export declare const OrgCapabilitiesEndpointsItem: any;
/** Endpoints capability */
export type OrgCapabilitiesEndpointsList = Array<OrgCapabilitiesEndpointsItem | (string & {})>;
export declare const OrgCapabilitiesEndpointsList: S.Schema<OrgCapabilitiesEndpointsList>;
export type OrgCapabilitiesFlowsItem = "create" | "read" | "update" | "delete";
export declare const OrgCapabilitiesFlowsItem: any;
/** Flows capability */
export type OrgCapabilitiesFlowsList = Array<OrgCapabilitiesFlowsItem | (string & {})>;
export declare const OrgCapabilitiesFlowsList: S.Schema<OrgCapabilitiesFlowsList>;
export type OrgCapabilitiesIntegrationsItem = "create" | "read" | "update" | "delete";
export declare const OrgCapabilitiesIntegrationsItem: any;
/** Integrations capability */
export type OrgCapabilitiesIntegrationsList = Array<OrgCapabilitiesIntegrationsItem | (string & {})>;
export declare const OrgCapabilitiesIntegrationsList: S.Schema<OrgCapabilitiesIntegrationsList>;
export type OrgCapabilitiesMonitorsItem = "create" | "read" | "update" | "delete";
export declare const OrgCapabilitiesMonitorsItem: any;
/** Monitors capability */
export type OrgCapabilitiesMonitorsList = Array<OrgCapabilitiesMonitorsItem | (string & {})>;
export declare const OrgCapabilitiesMonitorsList: S.Schema<OrgCapabilitiesMonitorsList>;
export type OrgCapabilitiesNotifiersItem = "create" | "read" | "update" | "delete";
export declare const OrgCapabilitiesNotifiersItem: any;
/** Notifiers capability */
export type OrgCapabilitiesNotifiersList = Array<OrgCapabilitiesNotifiersItem | (string & {})>;
export declare const OrgCapabilitiesNotifiersList: S.Schema<OrgCapabilitiesNotifiersList>;
export type OrgCapabilitiesRbacItem = "create" | "read" | "update" | "delete";
export declare const OrgCapabilitiesRbacItem: any;
/** Access control capability */
export type OrgCapabilitiesRbacList = Array<OrgCapabilitiesRbacItem | (string & {})>;
export declare const OrgCapabilitiesRbacList: S.Schema<OrgCapabilitiesRbacList>;
export type OrgCapabilitiesSharedAccessKeysItem = "read" | "update";
export declare const OrgCapabilitiesSharedAccessKeysItem: any;
/** Shared access keys capability */
export type OrgCapabilitiesSharedAccessKeysList = Array<OrgCapabilitiesSharedAccessKeysItem | (string & {})>;
export declare const OrgCapabilitiesSharedAccessKeysList: S.Schema<OrgCapabilitiesSharedAccessKeysList>;
export type OrgCapabilitiesUsersItem = "create" | "read" | "update" | "delete";
export declare const OrgCapabilitiesUsersItem: any;
/** Users capability */
export type OrgCapabilitiesUsersList = Array<OrgCapabilitiesUsersItem | (string & {})>;
export declare const OrgCapabilitiesUsersList: S.Schema<OrgCapabilitiesUsersList>;
export type OrgCapabilitiesViewsItem = "create" | "read" | "update" | "delete";
export declare const OrgCapabilitiesViewsItem: any;
/** Views capability */
export type OrgCapabilitiesViewsList = Array<OrgCapabilitiesViewsItem | (string & {})>;
export declare const OrgCapabilitiesViewsList: S.Schema<OrgCapabilitiesViewsList>;
export interface OrgCapabilities {
    /** Annotations capability */
    annotations?: OrgCapabilitiesAnnotationsList;
    /** API tokens capability */
    apiTokens?: OrgCapabilitiesApiTokensList;
    /** Audit Log capability */
    auditLog?: OrgCapabilitiesAuditLogList;
    /** Billing capability */
    billing?: OrgCapabilitiesBillingList;
    /** Dashboards capability */
    dashboards?: OrgCapabilitiesDashboardsList;
    /** Datasets capability */
    datasets?: OrgCapabilitiesDatasetsList;
    /** Endpoints capability */
    endpoints?: OrgCapabilitiesEndpointsList;
    /** Flows capability */
    flows?: OrgCapabilitiesFlowsList;
    /** Integrations capability */
    integrations?: OrgCapabilitiesIntegrationsList;
    /** Monitors capability */
    monitors?: OrgCapabilitiesMonitorsList;
    /** Notifiers capability */
    notifiers?: OrgCapabilitiesNotifiersList;
    /** Access control capability */
    rbac?: OrgCapabilitiesRbacList;
    /** Shared access keys capability */
    sharedAccessKeys?: OrgCapabilitiesSharedAccessKeysList;
    /** Users capability */
    users?: OrgCapabilitiesUsersList;
    /** Views capability */
    views?: OrgCapabilitiesViewsList;
}
export declare const OrgCapabilities: S.Schema<OrgCapabilities>;
export type ViewCapabilitiesValueQueryItem = "read";
export declare const ViewCapabilitiesValueQueryItem: any;
/** Query capability */
export type ViewCapabilitiesValueQueryList = Array<ViewCapabilitiesValueQueryItem | (string & {})>;
export declare const ViewCapabilitiesValueQueryList: S.Schema<ViewCapabilitiesValueQueryList>;
export type ViewCapabilitiesValueShareItem = "create" | "read" | "delete";
export declare const ViewCapabilitiesValueShareItem: any;
/** Sharing view capability */
export type ViewCapabilitiesValueShareList = Array<ViewCapabilitiesValueShareItem | (string & {})>;
export declare const ViewCapabilitiesValueShareList: S.Schema<ViewCapabilitiesValueShareList>;
export interface ViewCapabilitiesValue {
    /** Query capability */
    query?: ViewCapabilitiesValueQueryList;
    /** Sharing view capability */
    share?: ViewCapabilitiesValueShareList;
}
export declare const ViewCapabilitiesValue: S.Schema<ViewCapabilitiesValue>;
export type ViewCapabilities = {
    [key: string]: ViewCapabilitiesValue | undefined;
};
export declare const ViewCapabilities: S.Schema<ViewCapabilities>;
export interface CreateAPITokenRequest {
    datasetCapabilities?: DatasetCapabilities;
    /** Description of the token */
    description?: string;
    /** Expiration date of the token (ISO 8601 format) */
    expiresAt?: string | null;
    /** Name of the token */
    name: string;
    orgCapabilities?: OrgCapabilities;
    viewCapabilities?: ViewCapabilities;
}
export declare const CreateAPITokenRequest: S.Schema<CreateAPITokenRequest>;
export interface CreateAPITokenResponse {
    datasetCapabilities: DatasetCapabilities;
    /** Description of the token */
    description?: string;
    /** Expiration date of the token (ISO 8601 format) */
    expiresAt?: string | null;
    /** ID of the token */
    id: string;
    /** Name of the token */
    name: string;
    orgCapabilities: OrgCapabilities;
    samlAuthenticated?: boolean;
    viewCapabilities?: ViewCapabilities;
    token?: string;
}
export declare const CreateAPITokenResponse: S.Schema<CreateAPITokenResponse>;
export type TimeSeriesChartType = "TimeSeries";
export declare const TimeSeriesChartType: any;
/** Controls how empty intervals are rendered in time series charts. `auto` infers from the query, `null` leaves gaps, `span` connects adjacent points, `zero` fills with zero. */
export type TimeSeriesQueryOptionsDisplayNull = "auto" | "null" | "span" | "zero" | "";
export declare const TimeSeriesQueryOptionsDisplayNull: any;
export type BooleanString = "true" | "false" | "";
export declare const BooleanString: any;
export type TimeSeriesQueryOptionsTimeSeriesVariant = "area" | "bars" | "line" | "lines" | "";
export declare const TimeSeriesQueryOptionsTimeSeriesVariant: any;
export type TimeSeriesQueryOptionsTimeSeriesView = "charts" | "resultsTable" | "charts|resultsTable" | "";
export declare const TimeSeriesQueryOptionsTimeSeriesView: any;
export interface TimeSeriesQueryOptions {
    /** Controls how empty intervals are rendered in time series charts. `auto` infers from the query, `null` leaves gaps, `span` connects adjacent points, `zero` fills with zero. */
    displayNull?: TimeSeriesQueryOptionsDisplayNull | (string & {});
    /** When enabled, charts are overlaid on a single chart instead of stacked separately. */
    overlayCharts?: BooleanString | (string & {});
    shownColumns?: string;
    timeSeriesVariant?: TimeSeriesQueryOptionsTimeSeriesVariant | (string & {});
    timeSeriesView?: TimeSeriesQueryOptionsTimeSeriesView | (string & {});
}
export declare const TimeSeriesQueryOptions: S.Schema<TimeSeriesQueryOptions>;
export interface TimeSeriesNonMetricsAplQuery {
    apl: string;
    queryOptions?: TimeSeriesQueryOptions;
}
export declare const TimeSeriesNonMetricsAplQuery: S.Schema<TimeSeriesNonMetricsAplQuery>;
export interface TimeSeriesNativeMplQuery {
    mpl: string;
    queryOptions?: TimeSeriesQueryOptions;
}
export declare const TimeSeriesNativeMplQuery: S.Schema<TimeSeriesNativeMplQuery>;
export type TimeSeriesChartQuery = TimeSeriesNonMetricsAplQuery | TimeSeriesNativeMplQuery;
export declare const TimeSeriesChartQuery: S.Schema<TimeSeriesChartQuery>;
export interface TimeSeriesChart {
    id: string;
    type: TimeSeriesChartType;
    name?: string;
    query: TimeSeriesChartQuery;
}
export declare const TimeSeriesChart: S.Schema<TimeSeriesChart>;
export type HeatmapChartType = "Heatmap";
export declare const HeatmapChartType: any;
export type HeatmapQueryOptionsTimeSeriesView = "charts" | "resultsTable" | "charts|resultsTable" | "";
export declare const HeatmapQueryOptionsTimeSeriesView: any;
export interface HeatmapQueryOptions {
    timeSeriesView?: HeatmapQueryOptionsTimeSeriesView | (string & {});
}
export declare const HeatmapQueryOptions: S.Schema<HeatmapQueryOptions>;
export interface HeatmapNonMetricsAplQuery {
    apl: string;
    queryOptions?: HeatmapQueryOptions;
}
export declare const HeatmapNonMetricsAplQuery: S.Schema<HeatmapNonMetricsAplQuery>;
export interface HeatmapNativeMplQuery {
    mpl: string;
    queryOptions?: HeatmapQueryOptions;
}
export declare const HeatmapNativeMplQuery: S.Schema<HeatmapNativeMplQuery>;
export type HeatmapChartQuery = HeatmapNonMetricsAplQuery | HeatmapNativeMplQuery;
export declare const HeatmapChartQuery: S.Schema<HeatmapChartQuery>;
export interface HeatmapChart {
    id: string;
    type: HeatmapChartType;
    name?: string;
    query: HeatmapChartQuery;
}
export declare const HeatmapChart: S.Schema<HeatmapChart>;
export type LogStreamChartType = "LogStream";
export declare const LogStreamChartType: any;
export interface SimpleNonMetricsAplQuery {
    apl: string;
}
export declare const SimpleNonMetricsAplQuery: S.Schema<SimpleNonMetricsAplQuery>;
export interface SimpleNativeMplQuery {
    mpl: string;
}
export declare const SimpleNativeMplQuery: S.Schema<SimpleNativeMplQuery>;
export type SimpleChartQuery = SimpleNonMetricsAplQuery | SimpleNativeMplQuery;
export declare const SimpleChartQuery: S.Schema<SimpleChartQuery>;
export interface AdvancedColumnSetting {
    name: string;
    width?: number;
}
export declare const AdvancedColumnSetting: S.Schema<AdvancedColumnSetting>;
export type ColumnSetting = string | AdvancedColumnSetting;
export declare const ColumnSetting: S.Schema<ColumnSetting>;
export type TableSettingsColumnsList = Array<ColumnSetting>;
export declare const TableSettingsColumnsList: S.Schema<TableSettingsColumnsList>;
export interface DatasetStreamSettings {
    fontSize?: string;
    highlightSeverity?: boolean;
    showRaw?: boolean;
    showEvent?: boolean;
    showTimestamp?: boolean;
    wrapLines?: boolean;
    hideNulls?: boolean;
    fitColumns?: boolean;
}
export declare const DatasetStreamSettings: S.Schema<DatasetStreamSettings>;
export interface TableSettings {
    columns?: TableSettingsColumnsList;
    settings?: DatasetStreamSettings;
}
export declare const TableSettings: S.Schema<TableSettings>;
export interface LogStreamChart {
    id: string;
    type: LogStreamChartType;
    name?: string;
    query: SimpleChartQuery;
    tableSettings?: TableSettings;
}
export declare const LogStreamChart: S.Schema<LogStreamChart>;
export type PieChartType = "Pie";
export declare const PieChartType: any;
export interface PieChart {
    id: string;
    type: PieChartType;
    name?: string;
    query: SimpleChartQuery;
}
export declare const PieChart: S.Schema<PieChart>;
export type ScatterChartType = "Scatter";
export declare const ScatterChartType: any;
export interface ScatterChart {
    id: string;
    type: ScatterChartType;
    name?: string;
    query: SimpleChartQuery;
}
export declare const ScatterChart: S.Schema<ScatterChart>;
export type TableChartType = "Table";
export declare const TableChartType: any;
export interface TableChart {
    id: string;
    type: TableChartType;
    name?: string;
    query: SimpleChartQuery;
    tableSettings?: TableSettings;
}
export declare const TableChart: S.Schema<TableChart>;
export type TopKChartType = "TopK";
export declare const TopKChartType: any;
export interface TopKChart {
    id: string;
    type: TopKChartType;
    name?: string;
    query: SimpleChartQuery;
}
export declare const TopKChart: S.Schema<TopKChart>;
export type StatisticChartType = "Statistic";
export declare const StatisticChartType: any;
export type StatisticChartColorScheme = "Blue" | "Orange" | "Red" | "Purple" | "Teal" | "Yellow" | "Green" | "Pink" | "Grey" | "Brown";
export declare const StatisticChartColorScheme: any;
export type StatisticChartShowChart = boolean | string;
export declare const StatisticChartShowChart: S.Schema<StatisticChartShowChart>;
export type StatisticChartChartHeight = string | number;
export declare const StatisticChartChartHeight: S.Schema<StatisticChartChartHeight>;
export type StatisticChartErrorThreshold = "Above" | "AboveOrEqual" | "Below" | "BelowOrEqual" | "AboveOrBelow";
export declare const StatisticChartErrorThreshold: any;
export type StatisticChartWarningThreshold = "Above" | "AboveOrEqual" | "Below" | "BelowOrEqual" | "AboveOrBelow";
export declare const StatisticChartWarningThreshold: any;
export interface StatisticChartColorProps {
    background?: string;
    chartFillColor?: string;
    labelColor?: string;
    textColor?: string;
}
export declare const StatisticChartColorProps: S.Schema<StatisticChartColorProps>;
export interface StatisticChart {
    id: string;
    type: StatisticChartType;
    name?: string;
    query: SimpleChartQuery;
    colorScheme?: StatisticChartColorScheme | (string & {});
    customUnits?: string;
    showChart?: StatisticChartShowChart;
    hideValue?: boolean;
    chartHeight?: StatisticChartChartHeight;
    errorThreshold?: StatisticChartErrorThreshold | (string & {});
    errorThresholdValue?: string;
    warningThreshold?: StatisticChartWarningThreshold | (string & {});
    warningThresholdValue?: string;
    invertTheme?: boolean;
    background?: string;
    textColor?: string;
    labelColor?: string;
    chartFillColor?: string;
    okColorProps?: StatisticChartColorProps;
    warningColorProps?: StatisticChartColorProps;
    errorColorProps?: StatisticChartColorProps;
}
export declare const StatisticChart: S.Schema<StatisticChart>;
export type NoteChartType = "Note";
export declare const NoteChartType: any;
export type NoteChartVariant = "default";
export declare const NoteChartVariant: any;
export interface NoteChart {
    id: string;
    type: NoteChartType;
    text: string;
    variant?: NoteChartVariant | (string & {});
}
export declare const NoteChart: S.Schema<NoteChart>;
export type MonitorListChartType = "MonitorList";
export declare const MonitorListChartType: any;
export type MonitorListChartSelectedMonitorsList = Array<string>;
export declare const MonitorListChartSelectedMonitorsList: S.Schema<MonitorListChartSelectedMonitorsList>;
export interface MonitorListColumns {
    status: boolean;
    history: boolean;
    dataset: boolean;
    type: boolean;
    notifiers: boolean;
}
export declare const MonitorListColumns: S.Schema<MonitorListColumns>;
export interface MonitorListChart {
    id: string;
    type: MonitorListChartType;
    name?: string;
    selectedMonitors: MonitorListChartSelectedMonitorsList;
    columns: MonitorListColumns;
}
export declare const MonitorListChart: S.Schema<MonitorListChart>;
export type SmartFilterChartType = "SmartFilter";
export declare const SmartFilterChartType: any;
export type SmartFilterSearchType = "search";
export declare const SmartFilterSearchType: any;
export interface SmartFilterSearch {
    id: string;
    name: string;
    active?: boolean;
    type: SmartFilterSearchType;
}
export declare const SmartFilterSearch: S.Schema<SmartFilterSearch>;
export interface SmartFilterOption {
    key: string;
    value: string;
    default?: boolean;
    unset?: boolean;
}
export declare const SmartFilterOption: S.Schema<SmartFilterOption>;
export type SmartFilterOptionsCase0List = Array<SmartFilterOption>;
export declare const SmartFilterOptionsCase0List: S.Schema<SmartFilterOptionsCase0List>;
export type SmartFilterOptionsCase1 = "";
export declare const SmartFilterOptionsCase1: any;
export type SmartFilterOptions = SmartFilterOptionsCase0List | SmartFilterOptionsCase1;
export declare const SmartFilterOptions: S.Schema<SmartFilterOptions>;
export type SmartFilterSelectListType = "select";
export declare const SmartFilterSelectListType: any;
export type SmartFilterSelectListSelectType = "list";
export declare const SmartFilterSelectListSelectType: any;
export interface SmartFilterSelectList {
    id: string;
    name: string;
    active?: boolean;
    options?: SmartFilterOptions | null;
    type: SmartFilterSelectListType;
    selectType: SmartFilterSelectListSelectType;
}
export declare const SmartFilterSelectList: S.Schema<SmartFilterSelectList>;
export type SmartFilterSelectQueryOptionsCase0List = Array<SmartFilterOption>;
export declare const SmartFilterSelectQueryOptionsCase0List: S.Schema<SmartFilterSelectQueryOptionsCase0List>;
export type SmartFilterSelectQueryOptionsCase1 = "";
export declare const SmartFilterSelectQueryOptionsCase1: any;
export type SmartFilterSelectQueryOptions = SmartFilterSelectQueryOptionsCase0List | SmartFilterSelectQueryOptionsCase1;
export declare const SmartFilterSelectQueryOptions: S.Schema<SmartFilterSelectQueryOptions>;
export type SmartFilterSelectQueryType = "select";
export declare const SmartFilterSelectQueryType: any;
export type SmartFilterSelectQuerySelectType = "query";
export declare const SmartFilterSelectQuerySelectType: any;
export interface SmartFilterAplQuery {
    /** APL query that returns the list of options for the filter dropdown. The result must contain a `key` column and a `value` column — Axiom interprets each row as a `{ key, value }` pair for an option. Use `distinct` to collapse the source field to unique values, then `project` to expose the `key` and `value` columns. Example: ``` ['dataset-name'] | distinct field_name | project key=field_name, value=field_name ``` */
    apl: string;
}
export declare const SmartFilterAplQuery: S.Schema<SmartFilterAplQuery>;
export interface SmartFilterNativeMplQuery {
    /** MPL query that returns the list of options for the filter dropdown. The query must group by exactly one tag — Axiom uses each distinct value of that tag as both the key and the value of an option. Use `align using last` to simplify the query. Example: ``` dataset:metric | align using last | group by tag using count ``` */
    mpl: string;
}
export declare const SmartFilterNativeMplQuery: S.Schema<SmartFilterNativeMplQuery>;
export type SmartFilterQuery = SmartFilterAplQuery | SmartFilterNativeMplQuery;
export declare const SmartFilterQuery: S.Schema<SmartFilterQuery>;
export interface SmartFilterSelectQuery {
    id: string;
    name: string;
    active?: boolean;
    /** Pre-defined options merged with the dynamic options returned by `query` at runtime. Typically used to seed a default option (for example an "All" entry with `unset: true`) so the filter has a sensible initial selection before — or independent of — query results. */
    options?: SmartFilterSelectQueryOptions | null;
    type: SmartFilterSelectQueryType;
    selectType: SmartFilterSelectQuerySelectType;
    query?: SmartFilterQuery;
}
export declare const SmartFilterSelectQuery: S.Schema<SmartFilterSelectQuery>;
export type SmartFilterSelect = SmartFilterSelectList | SmartFilterSelectQuery;
export declare const SmartFilterSelect: S.Schema<SmartFilterSelect>;
export type SmartFilterConfig = SmartFilterSearch | SmartFilterSelect;
export declare const SmartFilterConfig: S.Schema<SmartFilterConfig>;
export type SmartFilterChartFiltersList = Array<SmartFilterConfig>;
export declare const SmartFilterChartFiltersList: S.Schema<SmartFilterChartFiltersList>;
export interface SmartFilterChart {
    id: string;
    type: SmartFilterChartType;
    name?: string;
    filters: SmartFilterChartFiltersList;
    logo?: string;
    logoDark?: string;
}
export declare const SmartFilterChart: S.Schema<SmartFilterChart>;
export type SpacerChartType = "Spacer";
export declare const SpacerChartType: any;
export interface SpacerChart {
    id: string;
    type: SpacerChartType;
    name?: string;
}
export declare const SpacerChart: S.Schema<SpacerChart>;
export type Chart = TimeSeriesChart | HeatmapChart | LogStreamChart | PieChart | ScatterChart | TableChart | TopKChart | StatisticChart | NoteChart | MonitorListChart | SmartFilterChart | SpacerChart;
export declare const Chart: S.Schema<Chart>;
export type DashboardChartsList = Array<Chart>;
export declare const DashboardChartsList: S.Schema<DashboardChartsList>;
export interface LayoutItem {
    i: string;
    x: number;
    y: number | null;
    w: number;
    h: number;
    minW?: number;
    minH?: number;
    maxW?: number;
    maxH?: number;
    static?: boolean;
}
export declare const LayoutItem: S.Schema<LayoutItem>;
export type DashboardLayoutList = Array<LayoutItem>;
export declare const DashboardLayoutList: S.Schema<DashboardLayoutList>;
export type DashboardRefreshTime = 15 | 60 | 300;
export declare const DashboardRefreshTime: any;
export type SchemaVersion = 2;
export declare const SchemaVersion: any;
/** Relative time comparison offset. Compares the current time window against a previous period offset by this duration. Mutually exclusive with `againstTimestamp` — setting one clears the other. Use an empty string or omit to disable comparison. */
export type DashboardAgainst = "-1h" | "-3h" | "-6h" | "-12h" | "-1d" | "-3d" | "-7d" | "-1w" | "-2w" | "-3w" | "-30d" | "-60d" | "-90d";
export declare const DashboardAgainst: any;
export interface Dashboard {
    name: string;
    owner: string;
    description?: string;
    charts: DashboardChartsList;
    layout: DashboardLayoutList;
    refreshTime: DashboardRefreshTime | (number & {});
    schemaVersion: SchemaVersion | (number & {});
    /** Relative time comparison offset. Compares the current time window against a previous period offset by this duration. Mutually exclusive with `againstTimestamp` — setting one clears the other. Use an empty string or omit to disable comparison. */
    against?: DashboardAgainst | (string & {});
    /** Absolute or relative timestamp to compare against. Mutually exclusive with `against` — setting one clears the other. Accepts ISO 8601, `now-{duration}` (e.g. `now-1h`), or epoch milliseconds as a string. */
    againstTimestamp?: string;
    timeWindowStart: string;
    timeWindowEnd: string;
    uid?: string;
}
export declare const Dashboard: S.Schema<Dashboard>;
/** Required for updates when overwrite is false. Pass back the version value received from the server verbatim (string or number). */
export type CreateDashboardRequestVersion = string | number;
export declare const CreateDashboardRequestVersion: S.Schema<CreateDashboardRequestVersion>;
export interface CreateDashboardRequest {
    dashboard: Dashboard;
    message?: string;
    overwrite?: boolean;
    /** Stable external dashboard identifier (org-scoped unique). */
    uid?: string;
    /** Required for updates when overwrite is false. Pass back the version value received from the server verbatim (string or number). */
    version?: CreateDashboardRequestVersion;
}
export declare const CreateDashboardRequest: S.Schema<CreateDashboardRequest>;
/** 64-bit server-assigned version (hybrid-logical-clock timestamp). Emitted as either JSON number or JSON string, sometimes exceeding JavaScript Number precision. */
export type DashboardResourceVersion = string | number;
export declare const DashboardResourceVersion: S.Schema<DashboardResourceVersion>;
export interface DashboardResource {
    createdAt: string;
    createdBy: string;
    dashboard: Dashboard;
    id: string;
    uid: string;
    updatedAt: string;
    updatedBy: string;
    /** 64-bit server-assigned version (hybrid-logical-clock timestamp). Emitted as either JSON number or JSON string, sometimes exceeding JavaScript Number precision. */
    version: DashboardResourceVersion;
}
export declare const DashboardResource: S.Schema<DashboardResource>;
export type DashboardWriteResponseStatus = "created" | "updated";
export declare const DashboardWriteResponseStatus: any;
export interface DashboardWriteResponse {
    dashboard: DashboardResource;
    overwritten?: boolean;
    status: DashboardWriteResponseStatus;
}
export declare const DashboardWriteResponse: S.Schema<DashboardWriteResponse>;
/** The kind of the dataset */
export type CreateDatasetRequestKind = "otel:metrics:v1" | "otel:traces:v1" | "otel:logs:v1" | "axiom:events:v1";
export declare const CreateDatasetRequestKind: any;
export interface CreateDatasetRequest {
    /** Referrer slug */
    referrer?: string;
    /** Dataset description */
    description?: string;
    /** Edge deployment of the dataset */
    edgeDeployment?: string;
    /** The kind of the dataset */
    kind?: CreateDatasetRequestKind | (string & {});
    /** Dataset unique name */
    name: string;
    /** Number of days to retain data in the dataset */
    retentionDays?: number;
    /** Whether to use the retention period */
    useRetentionPeriod?: boolean;
}
export declare const CreateDatasetRequest: S.Schema<CreateDatasetRequest>;
/** The kind of the dataset */
export type DatasetKind = "otel:metrics:v1" | "otel:traces:v1" | "otel:logs:v1" | "axiom:events:v1";
export declare const DatasetKind: any;
export type DatasetMapFieldsList = Array<string>;
export declare const DatasetMapFieldsList: S.Schema<DatasetMapFieldsList>;
export interface Dataset {
    /** Whether this dataset has write access */
    canWrite?: boolean;
    /** The RFC3339-formatted time when the dataset was created. */
    created: string;
    /** Dataset description */
    description: string;
    /** Edge deployment of the dataset */
    edgeDeployment?: string;
    /** URL of the edge deployment */
    edgeDeploymentUrl?: string;
    /** Dataset ID */
    id: string;
    /** The kind of the dataset */
    kind: DatasetKind;
    mapFields?: DatasetMapFieldsList;
    /** Unique dataset name */
    name: string;
    /** Number of days to retain data in the dataset */
    retentionDays?: number;
    /** ID of the org that shared this resource, if it's shared */
    sharedByOrg?: string;
    /** The RFC3339-formatted time when the dataset was last updated. */
    updatedAt: string;
    /** Whether to use the retention period */
    useRetentionPeriod?: boolean;
    /** Name of the dataset creator */
    who: string;
}
export declare const Dataset: S.Schema<Dataset>;
/** List of user IDs that are assigned to this group */
export type CreateGroupRequestMembersList = Array<string>;
export declare const CreateGroupRequestMembersList: S.Schema<CreateGroupRequestMembersList>;
/** List of role IDs that are assigned to this group */
export type CreateGroupRequestRolesList = Array<string>;
export declare const CreateGroupRequestRolesList: S.Schema<CreateGroupRequestRolesList>;
export interface CreateGroupRequest {
    /** Detailed description of the group's purpose and scope */
    description?: string;
    /** List of user IDs that are assigned to this group */
    members?: CreateGroupRequestMembersList;
    /** Unique name identifier for the group */
    name: string;
    /** List of role IDs that are assigned to this group */
    roles?: CreateGroupRequestRolesList;
}
export declare const CreateGroupRequest: S.Schema<CreateGroupRequest>;
/** List of user IDs that are assigned to this group */
export type CreateGroupResponseMembersList = Array<string>;
export declare const CreateGroupResponseMembersList: S.Schema<CreateGroupResponseMembersList>;
/** List of role IDs that are assigned to this group */
export type CreateGroupResponseRolesList = Array<string>;
export declare const CreateGroupResponseRolesList: S.Schema<CreateGroupResponseRolesList>;
export interface CreateGroupResponse {
    /** Detailed description of the group's purpose and scope */
    description?: string;
    /** Whether the group is managed by Axiom */
    isManaged?: boolean;
    /** List of user IDs that are assigned to this group */
    members?: CreateGroupResponseMembersList;
    /** Unique name identifier for the group */
    name: string;
    /** List of role IDs that are assigned to this group */
    roles?: CreateGroupResponseRolesList;
    /** Unique identifier for the group */
    id: string;
}
export declare const CreateGroupResponse: S.Schema<CreateGroupResponse>;
export interface CreateMapFieldRequest {
    dataset_id: string;
    name: string;
}
export declare const CreateMapFieldRequest: S.Schema<CreateMapFieldRequest>;
/** A map field, described by a name */
export interface MapField {
    name: string;
}
export declare const MapField: S.Schema<MapField>;
/** List of notifier IDs that will receive alerts. Notifiers can be email, Slack, webhook endpoints, etc. */
export type CreateMonitorRequestNotifierIdsList = Array<string>;
export declare const CreateMonitorRequestNotifierIdsList: S.Schema<CreateMonitorRequestNotifierIdsList>;
/** Comparison operator for threshold checks: - Below: Trigger when value < threshold - BelowOrEqual: Trigger when value <= threshold - Above: Trigger when value > threshold - AboveOrEqual: Trigger when value >= threshold - AboveOrBelow: Trigger when value is outside a range */
export type CreateMonitorRequestOperator = "Below" | "BelowOrEqual" | "Above" | "AboveOrEqual" | "AboveOrBelow";
export declare const CreateMonitorRequestOperator: any;
/** Type of monitoring check to perform: - Threshold: Compares a numeric value against a threshold - MatchEvent: Looks for specific events or patterns - AnomalyDetection: Identifies unusual patterns based on historical data */
export type CreateMonitorRequestType = "Threshold" | "MatchEvent" | "AnomalyDetection";
export declare const CreateMonitorRequestType: any;
export interface CreateMonitorRequest {
    /** Whether to alert when no data is received */
    alertOnNoData?: boolean;
    /** APL (Axiom Processing Language) query string used for monitoring. This query defines what data to analyze and how to process it. At least one of aplQuery or mplQuery must be provided. */
    aplQuery?: string;
    /** Name of the column to monitor */
    columnName?: string;
    /** Number of days to compare for anomaly detection */
    compareDays?: number;
    /** Timestamp when the monitor was created */
    createdAt?: string;
    /** ID of the user who created the monitor */
    createdBy?: string;
    /** Detailed description of the monitor's purpose */
    description?: string;
    /** Whether the monitor is currently disabled */
    disabled?: boolean;
    /** Timestamp until when the monitor should remain disabled */
    disabledUntil?: string | null;
    /** How frequently the monitor should run, in minutes. Minimum value is 1 minute. */
    intervalMinutes?: number;
    /** MPL (Metrics Processing Language) query string for metrics-based monitoring. Use this as an alternative to aplQuery for metrics datasets. At least one of aplQuery or mplQuery must be provided. */
    mplQuery?: string;
    /** Name of the monitor */
    name: string;
    /** List of notifier IDs that will receive alerts. Notifiers can be email, Slack, webhook endpoints, etc. */
    notifierIds?: CreateMonitorRequestNotifierIdsList;
    /** Whether to group notifications */
    notifyByGroup?: boolean;
    /** Whether to send notifications on every check */
    notifyEveryRun?: boolean;
    /** Comparison operator for threshold checks: - Below: Trigger when value < threshold - BelowOrEqual: Trigger when value <= threshold - Above: Trigger when value > threshold - AboveOrEqual: Trigger when value >= threshold - AboveOrBelow: Trigger when value is outside a range */
    operator?: CreateMonitorRequestOperator | (string & {});
    /** Time window to evaluate in each check, in minutes. For example, "last 5 minutes of data" */
    rangeMinutes?: number;
    /** Whether the alert can be manually resolved */
    resolvable?: boolean;
    /** Delay in seconds before triggering the alert */
    secondDelay?: number;
    /** Whether to skip resolved alerts */
    skipResolved?: boolean;
    /** Threshold value for triggering the alert */
    threshold?: number;
    /** Tolerance percentage for anomaly detection */
    tolerance?: number;
    /** Number of positive results needed before triggering */
    triggerAfterNPositiveResults?: number;
    /** Number of consecutive check runs that must fail before triggering an alert. Use this to avoid alerting on temporary spikes. */
    triggerFromNRuns?: number;
    /** Type of monitoring check to perform: - Threshold: Compares a numeric value against a threshold - MatchEvent: Looks for specific events or patterns - AnomalyDetection: Identifies unusual patterns based on historical data */
    type: CreateMonitorRequestType | (string & {});
    /** Timestamp when the monitor was last updated */
    updatedAt?: string;
}
export declare const CreateMonitorRequest: S.Schema<CreateMonitorRequest>;
/** List of notifier IDs that will receive alerts. Notifiers can be email, Slack, webhook endpoints, etc. */
export type CreateMonitorResponseNotifierIdsList = Array<string>;
export declare const CreateMonitorResponseNotifierIdsList: S.Schema<CreateMonitorResponseNotifierIdsList>;
/** Comparison operator for threshold checks: - Below: Trigger when value < threshold - BelowOrEqual: Trigger when value <= threshold - Above: Trigger when value > threshold - AboveOrEqual: Trigger when value >= threshold - AboveOrBelow: Trigger when value is outside a range */
export type CreateMonitorResponseOperator = "Below" | "BelowOrEqual" | "Above" | "AboveOrEqual" | "AboveOrBelow";
export declare const CreateMonitorResponseOperator: any;
/** Type of monitoring check to perform: - Threshold: Compares a numeric value against a threshold - MatchEvent: Looks for specific events or patterns - AnomalyDetection: Identifies unusual patterns based on historical data */
export type CreateMonitorResponseType = "Threshold" | "MatchEvent" | "AnomalyDetection";
export declare const CreateMonitorResponseType: any;
export interface CreateMonitorResponse {
    /** Whether to alert when no data is received */
    alertOnNoData?: boolean;
    /** APL (Axiom Processing Language) query string used for monitoring. This query defines what data to analyze and how to process it. At least one of aplQuery or mplQuery must be provided. */
    aplQuery?: string;
    /** Name of the column to monitor */
    columnName?: string;
    /** Number of days to compare for anomaly detection */
    compareDays?: number;
    /** Timestamp when the monitor was created */
    createdAt?: string;
    /** ID of the user who created the monitor */
    createdBy?: string;
    /** Detailed description of the monitor's purpose */
    description?: string;
    /** Whether the monitor is currently disabled */
    disabled?: boolean;
    /** Timestamp until when the monitor should remain disabled */
    disabledUntil?: string | null;
    /** How frequently the monitor should run, in minutes. Minimum value is 1 minute. */
    intervalMinutes?: number;
    /** MPL (Metrics Processing Language) query string for metrics-based monitoring. Use this as an alternative to aplQuery for metrics datasets. At least one of aplQuery or mplQuery must be provided. */
    mplQuery?: string;
    /** Name of the monitor */
    name: string;
    /** List of notifier IDs that will receive alerts. Notifiers can be email, Slack, webhook endpoints, etc. */
    notifierIds?: CreateMonitorResponseNotifierIdsList;
    /** Whether to group notifications */
    notifyByGroup?: boolean;
    /** Whether to send notifications on every check */
    notifyEveryRun?: boolean;
    /** Comparison operator for threshold checks: - Below: Trigger when value < threshold - BelowOrEqual: Trigger when value <= threshold - Above: Trigger when value > threshold - AboveOrEqual: Trigger when value >= threshold - AboveOrBelow: Trigger when value is outside a range */
    operator?: CreateMonitorResponseOperator;
    /** Time window to evaluate in each check, in minutes. For example, "last 5 minutes of data" */
    rangeMinutes?: number;
    /** Whether the alert can be manually resolved */
    resolvable?: boolean;
    /** Delay in seconds before triggering the alert */
    secondDelay?: number;
    /** Whether to skip resolved alerts */
    skipResolved?: boolean;
    /** Threshold value for triggering the alert */
    threshold?: number;
    /** Tolerance percentage for anomaly detection */
    tolerance?: number;
    /** Number of positive results needed before triggering */
    triggerAfterNPositiveResults?: number;
    /** Number of consecutive check runs that must fail before triggering an alert. Use this to avoid alerting on temporary spikes. */
    triggerFromNRuns?: number;
    /** Type of monitoring check to perform: - Threshold: Compares a numeric value against a threshold - MatchEvent: Looks for specific events or patterns - AnomalyDetection: Identifies unusual patterns based on historical data */
    type: CreateMonitorResponseType;
    /** Timestamp when the monitor was last updated */
    updatedAt?: string;
    /** Unique identifier for the monitor */
    id: string;
}
export declare const CreateMonitorResponse: S.Schema<CreateMonitorResponse>;
/** HTTP headers to include in the request */
export type CustomNotifierConfigHeadersMap = {
    [key: string]: string | undefined;
};
export declare const CustomNotifierConfigHeadersMap: S.Schema<CustomNotifierConfigHeadersMap>;
/** Sensitive HTTP headers (tokens, keys) that should be masked in logs */
export type CustomNotifierConfigSecretHeadersMap = {
    [key: string]: string | undefined;
};
export declare const CustomNotifierConfigSecretHeadersMap: S.Schema<CustomNotifierConfigSecretHeadersMap>;
/** Configuration for custom webhook notifications with flexible headers and body template. Supports variable substitution in the body template using {{.Variable}} syntax. */
export interface CustomNotifierConfig {
    /** Template for the webhook body, supports variable substitution */
    body: string;
    /** HTTP headers to include in the request */
    headers?: CustomNotifierConfigHeadersMap;
    /** Sensitive HTTP headers (tokens, keys) that should be masked in logs */
    secretHeaders?: CustomNotifierConfigSecretHeadersMap;
    /** Custom webhook endpoint URL */
    url: string;
}
export declare const CustomNotifierConfig: S.Schema<CustomNotifierConfig>;
/** Configuration for Discord notifications using bot token */
export interface DiscordConfig {
    /** Discord channel ID to send notifications */
    discordChannel?: string;
    /** Discord bot token for authentication */
    discordToken?: string;
}
export declare const DiscordConfig: S.Schema<DiscordConfig>;
/** Configuration for Discord notifications using webhooks */
export interface DiscordWebhookConfig {
    /** Discord webhook URL */
    discordWebhookUrl?: string;
}
export declare const DiscordWebhookConfig: S.Schema<DiscordWebhookConfig>;
/** List of email addresses to receive notifications */
export type EmailConfigEmailsList = Array<string>;
export declare const EmailConfigEmailsList: S.Schema<EmailConfigEmailsList>;
/** Configuration for email notifications */
export interface EmailConfig {
    /** List of email addresses to receive notifications */
    emails?: EmailConfigEmailsList;
}
export declare const EmailConfig: S.Schema<EmailConfig>;
/** Configuration for Microsoft Teams notifications */
export interface MicrosoftTeamsConfig {
    /** Microsoft Teams webhook URL */
    microsoftTeamsUrl?: string;
}
export declare const MicrosoftTeamsConfig: S.Schema<MicrosoftTeamsConfig>;
/** Configuration for OpsGenie integration */
export interface OpsGenieConfig {
    /** OpsGenie API key for authentication */
    apiKey?: string | Redacted.Redacted<string>;
    /** Whether to use EU region endpoints */
    isEU?: boolean;
}
export declare const OpsGenieConfig: S.Schema<OpsGenieConfig>;
/** Configuration for PagerDuty integration */
export interface PagerDutyConfig {
    /** PagerDuty integration key for routing alerts */
    routingKey?: string;
    /** PagerDuty API token for additional functionality */
    token?: string;
}
export declare const PagerDutyConfig: S.Schema<PagerDutyConfig>;
/** Configuration for Slack notifications using incoming webhooks */
export interface SlackConfig {
    /** Slack incoming webhook URL */
    slackUrl?: string;
}
export declare const SlackConfig: S.Schema<SlackConfig>;
/** Configuration for simple webhook notifications */
export interface WebhookConfig {
    /** Webhook endpoint URL */
    url?: string;
}
export declare const WebhookConfig: S.Schema<WebhookConfig>;
/** Configuration options for different notification channels. Only one channel should be configured per notifier. */
export interface NotifierProperties {
    customWebhook?: CustomNotifierConfig;
    discord?: DiscordConfig;
    discordWebhook?: DiscordWebhookConfig;
    email?: EmailConfig;
    microsoftTeams?: MicrosoftTeamsConfig;
    opsgenie?: OpsGenieConfig;
    pagerduty?: PagerDutyConfig;
    slack?: SlackConfig;
    webhook?: WebhookConfig;
}
export declare const NotifierProperties: S.Schema<NotifierProperties>;
export interface CreateNotifierRequest {
    /** ISO timestamp until which the notifier is disabled (null if enabled) */
    disabledUntil?: string;
    /** Human-readable name for the notifier */
    name: string;
    properties: NotifierProperties;
}
export declare const CreateNotifierRequest: S.Schema<CreateNotifierRequest>;
export interface CreateNotifierResponse {
    /** Timestamp when the notifier was created */
    createdAt?: string;
    /** Email or ID of the user who created the notifier */
    createdBy?: string;
    /** ISO timestamp until which the notifier is disabled (null if enabled) */
    disabledUntil?: string;
    /** Human-readable name for the notifier */
    name: string;
    properties: NotifierProperties;
    /** Timestamp when the notifier was last updated */
    updatedAt?: string;
    /** Unique identifier for the notifier */
    id?: string;
}
export declare const CreateNotifierResponse: S.Schema<CreateNotifierResponse>;
export interface CreateOrgRequest {
    /** The default edge deployment of the organization. */
    edgeDeployment?: string;
    name: string;
}
export declare const CreateOrgRequest: S.Schema<CreateOrgRequest>;
export type LicenseEdgeDeploymentsList = Array<string>;
export declare const LicenseEdgeDeploymentsList: S.Schema<LicenseEdgeDeploymentsList>;
export type LicenseFeaturesMap = {
    [key: string]: boolean | undefined;
};
export declare const LicenseFeaturesMap: S.Schema<LicenseFeaturesMap>;
export type LicenseTier = "personal" | "teamMonthlyAws" | "axiomCloud" | "teamPlus" | "enterprise" | "comped" | "accelerator";
export declare const LicenseTier: any;
export type LicenseWithAuthsList = Array<string>;
export declare const LicenseWithAuthsList: S.Schema<LicenseWithAuthsList>;
export interface License {
    apiRateLimitPerSecond?: number;
    billingPeriodEnd?: string;
    billingPeriodStart?: string;
    defaultEdgeDeployment?: string;
    edgeDeployments?: LicenseEdgeDeploymentsList;
    expiresAt?: string | null;
    features?: LicenseFeaturesMap;
    id: string;
    issuedAt?: string;
    issuedTo?: string;
    issuer?: string;
    maxAuditWindowSeconds?: number;
    maxDatasets?: number;
    maxEndpoints?: number;
    maxFields?: number;
    maxMonitors?: number;
    maxQueryWindowSeconds?: number;
    maxUsers?: number;
    monthlyIngestGb?: number;
    monthlyQueryGbHours?: number;
    storageAllowanceGB?: number;
    tier: LicenseTier;
    validFrom?: string;
    withAuths?: LicenseWithAuthsList;
}
export declare const License: S.Schema<License>;
export type OrgPaymentStatus = "na" | "failed" | "success" | "blocked";
export declare const OrgPaymentStatus: any;
export type OrgPlan = "personal" | "teamMonthlyAws" | "axiomCloud" | "teamPlus" | "enterprise" | "comped" | "accelerator";
export declare const OrgPlan: any;
export interface Org {
    defaultEdgeDeployment?: string;
    firstFailedPayment?: string;
    id: string;
    lastUsageSync: string;
    license: License;
    metaCreated?: string;
    metaModified?: string;
    metaVersion?: string;
    name: string;
    paymentStatus: OrgPaymentStatus;
    plan: OrgPlan;
    planCreated: string;
    primaryEmail: string;
    role?: string;
}
export declare const Org: S.Schema<Org>;
export type RoleDatasetCapabilitiesValueDataItem = "delete";
export declare const RoleDatasetCapabilitiesValueDataItem: any;
/** Controls data management operations like deletion */
export type RoleDatasetCapabilitiesValueDataList = Array<RoleDatasetCapabilitiesValueDataItem | (string & {})>;
export declare const RoleDatasetCapabilitiesValueDataList: S.Schema<RoleDatasetCapabilitiesValueDataList>;
export type RoleDatasetCapabilitiesValueIngestItem = "create";
export declare const RoleDatasetCapabilitiesValueIngestItem: any;
/** Controls the ability to ingest data into datasets */
export type RoleDatasetCapabilitiesValueIngestList = Array<RoleDatasetCapabilitiesValueIngestItem | (string & {})>;
export declare const RoleDatasetCapabilitiesValueIngestList: S.Schema<RoleDatasetCapabilitiesValueIngestList>;
export type RoleDatasetCapabilitiesValueQueryItem = "read";
export declare const RoleDatasetCapabilitiesValueQueryItem: any;
/** Controls the ability to query and read data from datasets */
export type RoleDatasetCapabilitiesValueQueryList = Array<RoleDatasetCapabilitiesValueQueryItem | (string & {})>;
export declare const RoleDatasetCapabilitiesValueQueryList: S.Schema<RoleDatasetCapabilitiesValueQueryList>;
export type RoleDatasetCapabilitiesValueShareItem = "create" | "read" | "delete";
export declare const RoleDatasetCapabilitiesValueShareItem: any;
/** Controls the ability to share datasets with other users */
export type RoleDatasetCapabilitiesValueShareList = Array<RoleDatasetCapabilitiesValueShareItem | (string & {})>;
export declare const RoleDatasetCapabilitiesValueShareList: S.Schema<RoleDatasetCapabilitiesValueShareList>;
export type RoleDatasetCapabilitiesValueStarredQueriesItem = "create" | "read" | "update" | "delete";
export declare const RoleDatasetCapabilitiesValueStarredQueriesItem: any;
/** Controls the management of starred/saved queries */
export type RoleDatasetCapabilitiesValueStarredQueriesList = Array<RoleDatasetCapabilitiesValueStarredQueriesItem | (string & {})>;
export declare const RoleDatasetCapabilitiesValueStarredQueriesList: S.Schema<RoleDatasetCapabilitiesValueStarredQueriesList>;
export type RoleDatasetCapabilitiesValueTrimItem = "update";
export declare const RoleDatasetCapabilitiesValueTrimItem: any;
/** Controls data trimming operations for storage optimization */
export type RoleDatasetCapabilitiesValueTrimList = Array<RoleDatasetCapabilitiesValueTrimItem | (string & {})>;
export declare const RoleDatasetCapabilitiesValueTrimList: S.Schema<RoleDatasetCapabilitiesValueTrimList>;
export type RoleDatasetCapabilitiesValueVacuumItem = "update";
export declare const RoleDatasetCapabilitiesValueVacuumItem: any;
/** Controls field vacuuming operations for storage optimization */
export type RoleDatasetCapabilitiesValueVacuumList = Array<RoleDatasetCapabilitiesValueVacuumItem | (string & {})>;
export declare const RoleDatasetCapabilitiesValueVacuumList: S.Schema<RoleDatasetCapabilitiesValueVacuumList>;
export type RoleDatasetCapabilitiesValueVirtualFieldsItem = "create" | "read" | "update" | "delete";
export declare const RoleDatasetCapabilitiesValueVirtualFieldsItem: any;
/** Controls the management of virtual fields in datasets */
export type RoleDatasetCapabilitiesValueVirtualFieldsList = Array<RoleDatasetCapabilitiesValueVirtualFieldsItem | (string & {})>;
export declare const RoleDatasetCapabilitiesValueVirtualFieldsList: S.Schema<RoleDatasetCapabilitiesValueVirtualFieldsList>;
export interface RoleDatasetCapabilitiesValue {
    /** Controls data management operations like deletion */
    data?: RoleDatasetCapabilitiesValueDataList;
    /** Controls the ability to ingest data into datasets */
    ingest?: RoleDatasetCapabilitiesValueIngestList;
    /** Controls the ability to query and read data from datasets */
    query?: RoleDatasetCapabilitiesValueQueryList;
    /** Controls the ability to share datasets with other users */
    share?: RoleDatasetCapabilitiesValueShareList;
    /** Controls the management of starred/saved queries */
    starredQueries?: RoleDatasetCapabilitiesValueStarredQueriesList;
    /** Controls data trimming operations for storage optimization */
    trim?: RoleDatasetCapabilitiesValueTrimList;
    /** Controls field vacuuming operations for storage optimization */
    vacuum?: RoleDatasetCapabilitiesValueVacuumList;
    /** Controls the management of virtual fields in datasets */
    virtualFields?: RoleDatasetCapabilitiesValueVirtualFieldsList;
}
export declare const RoleDatasetCapabilitiesValue: S.Schema<RoleDatasetCapabilitiesValue>;
/** Defines the available permissions for dataset operations */
export type RoleDatasetCapabilities = {
    [key: string]: RoleDatasetCapabilitiesValue | undefined;
};
export declare const RoleDatasetCapabilities: S.Schema<RoleDatasetCapabilities>;
/** List of user IDs that are assigned to this role */
export type CreateRoleRequestMembersList = Array<string>;
export declare const CreateRoleRequestMembersList: S.Schema<CreateRoleRequestMembersList>;
export type RoleOrgCapabilitiesAnnotationsItem = "create" | "read" | "update" | "delete";
export declare const RoleOrgCapabilitiesAnnotationsItem: any;
/** Controls the management of annotations across the organization */
export type RoleOrgCapabilitiesAnnotationsList = Array<RoleOrgCapabilitiesAnnotationsItem | (string & {})>;
export declare const RoleOrgCapabilitiesAnnotationsList: S.Schema<RoleOrgCapabilitiesAnnotationsList>;
export type RoleOrgCapabilitiesApiTokensItem = "create" | "read" | "update" | "delete";
export declare const RoleOrgCapabilitiesApiTokensItem: any;
/** Controls the management of API tokens for authentication */
export type RoleOrgCapabilitiesApiTokensList = Array<RoleOrgCapabilitiesApiTokensItem | (string & {})>;
export declare const RoleOrgCapabilitiesApiTokensList: S.Schema<RoleOrgCapabilitiesApiTokensList>;
export type RoleOrgCapabilitiesAuditLogItem = "read";
export declare const RoleOrgCapabilitiesAuditLogItem: any;
/** Controls access to organization audit logs */
export type RoleOrgCapabilitiesAuditLogList = Array<RoleOrgCapabilitiesAuditLogItem | (string & {})>;
export declare const RoleOrgCapabilitiesAuditLogList: S.Schema<RoleOrgCapabilitiesAuditLogList>;
export type RoleOrgCapabilitiesBillingItem = "read" | "update";
export declare const RoleOrgCapabilitiesBillingItem: any;
/** Controls access to billing information and settings */
export type RoleOrgCapabilitiesBillingList = Array<RoleOrgCapabilitiesBillingItem | (string & {})>;
export declare const RoleOrgCapabilitiesBillingList: S.Schema<RoleOrgCapabilitiesBillingList>;
export type RoleOrgCapabilitiesDashboardsItem = "create" | "read" | "update" | "delete";
export declare const RoleOrgCapabilitiesDashboardsItem: any;
/** Controls the management of organization dashboards */
export type RoleOrgCapabilitiesDashboardsList = Array<RoleOrgCapabilitiesDashboardsItem | (string & {})>;
export declare const RoleOrgCapabilitiesDashboardsList: S.Schema<RoleOrgCapabilitiesDashboardsList>;
export type RoleOrgCapabilitiesDatasetsItem = "create" | "read" | "update" | "delete";
export declare const RoleOrgCapabilitiesDatasetsItem: any;
/** Controls the management of organization datasets */
export type RoleOrgCapabilitiesDatasetsList = Array<RoleOrgCapabilitiesDatasetsItem | (string & {})>;
export declare const RoleOrgCapabilitiesDatasetsList: S.Schema<RoleOrgCapabilitiesDatasetsList>;
export type RoleOrgCapabilitiesEndpointsItem = "create" | "read" | "update" | "delete";
export declare const RoleOrgCapabilitiesEndpointsItem: any;
/** Controls the management of API endpoints */
export type RoleOrgCapabilitiesEndpointsList = Array<RoleOrgCapabilitiesEndpointsItem | (string & {})>;
export declare const RoleOrgCapabilitiesEndpointsList: S.Schema<RoleOrgCapabilitiesEndpointsList>;
export type RoleOrgCapabilitiesFlowsItem = "create" | "read" | "update" | "delete";
export declare const RoleOrgCapabilitiesFlowsItem: any;
/** Controls the management of data flows and pipelines */
export type RoleOrgCapabilitiesFlowsList = Array<RoleOrgCapabilitiesFlowsItem | (string & {})>;
export declare const RoleOrgCapabilitiesFlowsList: S.Schema<RoleOrgCapabilitiesFlowsList>;
export type RoleOrgCapabilitiesIntegrationsItem = "create" | "read" | "update" | "delete";
export declare const RoleOrgCapabilitiesIntegrationsItem: any;
/** Controls the management of third-party integrations */
export type RoleOrgCapabilitiesIntegrationsList = Array<RoleOrgCapabilitiesIntegrationsItem | (string & {})>;
export declare const RoleOrgCapabilitiesIntegrationsList: S.Schema<RoleOrgCapabilitiesIntegrationsList>;
export type RoleOrgCapabilitiesMonitorsItem = "create" | "read" | "update" | "delete";
export declare const RoleOrgCapabilitiesMonitorsItem: any;
/** Controls the management of monitoring */
export type RoleOrgCapabilitiesMonitorsList = Array<RoleOrgCapabilitiesMonitorsItem | (string & {})>;
export declare const RoleOrgCapabilitiesMonitorsList: S.Schema<RoleOrgCapabilitiesMonitorsList>;
export type RoleOrgCapabilitiesNotifiersItem = "create" | "read" | "update" | "delete";
export declare const RoleOrgCapabilitiesNotifiersItem: any;
/** Controls the management of notification settings */
export type RoleOrgCapabilitiesNotifiersList = Array<RoleOrgCapabilitiesNotifiersItem | (string & {})>;
export declare const RoleOrgCapabilitiesNotifiersList: S.Schema<RoleOrgCapabilitiesNotifiersList>;
export type RoleOrgCapabilitiesRbacItem = "create" | "read" | "update" | "delete";
export declare const RoleOrgCapabilitiesRbacItem: any;
/** Controls access to role-based access control settings */
export type RoleOrgCapabilitiesRbacList = Array<RoleOrgCapabilitiesRbacItem | (string & {})>;
export declare const RoleOrgCapabilitiesRbacList: S.Schema<RoleOrgCapabilitiesRbacList>;
export type RoleOrgCapabilitiesSharedAccessKeysItem = "read" | "update";
export declare const RoleOrgCapabilitiesSharedAccessKeysItem: any;
/** Controls the management of shared access keys */
export type RoleOrgCapabilitiesSharedAccessKeysList = Array<RoleOrgCapabilitiesSharedAccessKeysItem | (string & {})>;
export declare const RoleOrgCapabilitiesSharedAccessKeysList: S.Schema<RoleOrgCapabilitiesSharedAccessKeysList>;
export type RoleOrgCapabilitiesUsersItem = "create" | "read" | "update" | "delete";
export declare const RoleOrgCapabilitiesUsersItem: any;
/** Controls user management within the organization */
export type RoleOrgCapabilitiesUsersList = Array<RoleOrgCapabilitiesUsersItem | (string & {})>;
export declare const RoleOrgCapabilitiesUsersList: S.Schema<RoleOrgCapabilitiesUsersList>;
export type RoleOrgCapabilitiesViewsItem = "create" | "read" | "update" | "delete";
export declare const RoleOrgCapabilitiesViewsItem: any;
/** Controls the management of data views */
export type RoleOrgCapabilitiesViewsList = Array<RoleOrgCapabilitiesViewsItem | (string & {})>;
export declare const RoleOrgCapabilitiesViewsList: S.Schema<RoleOrgCapabilitiesViewsList>;
/** Defines organization-wide permissions and capabilities */
export interface RoleOrgCapabilities {
    /** Controls the management of annotations across the organization */
    annotations?: RoleOrgCapabilitiesAnnotationsList;
    /** Controls the management of API tokens for authentication */
    apiTokens?: RoleOrgCapabilitiesApiTokensList;
    /** Controls access to organization audit logs */
    auditLog?: RoleOrgCapabilitiesAuditLogList;
    /** Controls access to billing information and settings */
    billing?: RoleOrgCapabilitiesBillingList;
    /** Controls the management of organization dashboards */
    dashboards?: RoleOrgCapabilitiesDashboardsList;
    /** Controls the management of organization datasets */
    datasets?: RoleOrgCapabilitiesDatasetsList;
    /** Controls the management of API endpoints */
    endpoints?: RoleOrgCapabilitiesEndpointsList;
    /** Controls the management of data flows and pipelines */
    flows?: RoleOrgCapabilitiesFlowsList;
    /** Controls the management of third-party integrations */
    integrations?: RoleOrgCapabilitiesIntegrationsList;
    /** Controls the management of monitoring */
    monitors?: RoleOrgCapabilitiesMonitorsList;
    /** Controls the management of notification settings */
    notifiers?: RoleOrgCapabilitiesNotifiersList;
    /** Controls access to role-based access control settings */
    rbac?: RoleOrgCapabilitiesRbacList;
    /** Controls the management of shared access keys */
    sharedAccessKeys?: RoleOrgCapabilitiesSharedAccessKeysList;
    /** Controls user management within the organization */
    users?: RoleOrgCapabilitiesUsersList;
    /** Controls the management of data views */
    views?: RoleOrgCapabilitiesViewsList;
}
export declare const RoleOrgCapabilities: S.Schema<RoleOrgCapabilities>;
export type RoleViewCapabilitiesValueQueryItem = "read";
export declare const RoleViewCapabilitiesValueQueryItem: any;
/** Controls the ability to query and read data from views */
export type RoleViewCapabilitiesValueQueryList = Array<RoleViewCapabilitiesValueQueryItem | (string & {})>;
export declare const RoleViewCapabilitiesValueQueryList: S.Schema<RoleViewCapabilitiesValueQueryList>;
export type RoleViewCapabilitiesValueShareItem = "create" | "read" | "delete";
export declare const RoleViewCapabilitiesValueShareItem: any;
/** Controls the ability to share views with other users */
export type RoleViewCapabilitiesValueShareList = Array<RoleViewCapabilitiesValueShareItem | (string & {})>;
export declare const RoleViewCapabilitiesValueShareList: S.Schema<RoleViewCapabilitiesValueShareList>;
export interface RoleViewCapabilitiesValue {
    /** Controls the ability to query and read data from views */
    query?: RoleViewCapabilitiesValueQueryList;
    /** Controls the ability to share views with other users */
    share?: RoleViewCapabilitiesValueShareList;
}
export declare const RoleViewCapabilitiesValue: S.Schema<RoleViewCapabilitiesValue>;
/** Defines the available permissions for view operations */
export type RoleViewCapabilities = {
    [key: string]: RoleViewCapabilitiesValue | undefined;
};
export declare const RoleViewCapabilities: S.Schema<RoleViewCapabilities>;
export interface CreateRoleRequest {
    datasetCapabilities?: RoleDatasetCapabilities;
    /** Detailed description of the role's purpose and scope */
    description?: string;
    /** List of user IDs that are assigned to this role */
    members?: CreateRoleRequestMembersList;
    /** Unique name identifier for the role */
    name: string;
    orgCapabilities?: RoleOrgCapabilities;
    viewCapabilities?: RoleViewCapabilities;
}
export declare const CreateRoleRequest: S.Schema<CreateRoleRequest>;
/** List of user IDs that are assigned to this role */
export type CreateRoleResponseMembersList = Array<string>;
export declare const CreateRoleResponseMembersList: S.Schema<CreateRoleResponseMembersList>;
export interface CreateRoleResponse {
    datasetCapabilities?: RoleDatasetCapabilities;
    /** Detailed description of the role's purpose and scope */
    description?: string;
    /** List of user IDs that are assigned to this role */
    members?: CreateRoleResponseMembersList;
    /** Unique name identifier for the role */
    name: string;
    orgCapabilities?: RoleOrgCapabilities;
    viewCapabilities?: RoleViewCapabilities;
    /** Unique identifier for the role */
    id: string;
}
export declare const CreateRoleResponse: S.Schema<CreateRoleResponse>;
export type CreateStarredRequestKind = "apl";
export declare const CreateStarredRequestKind: any;
export type CreateStarredRequestMetadataMap = {
    [key: string]: string | undefined;
};
export declare const CreateStarredRequestMetadataMap: S.Schema<CreateStarredRequestMetadataMap>;
export interface APLRequestWithOptionsDefaultOrder {
    desc?: boolean;
    field?: string;
}
export declare const APLRequestWithOptionsDefaultOrder: S.Schema<APLRequestWithOptionsDefaultOrder>;
export type APLRequestWithOptionsDefaultOrderList = Array<APLRequestWithOptionsDefaultOrder>;
export declare const APLRequestWithOptionsDefaultOrderList: S.Schema<APLRequestWithOptionsDefaultOrderList>;
export type APLRequestWithOptionsLibrariesList = Array<string>;
export declare const APLRequestWithOptionsLibrariesList: S.Schema<APLRequestWithOptionsLibrariesList>;
export type QueryOptionsPriority = "low" | "medium" | "high";
export declare const QueryOptionsPriority: any;
/** Controls how empty intervals are rendered in time series charts. `auto` infers from the query, `null` leaves gaps, `span` connects adjacent points, `zero` fills with zero. */
export type QueryOptionsDisplayNull = "auto" | "null" | "span" | "zero" | "";
export declare const QueryOptionsDisplayNull: any;
export type QueryOptionsTimeSeriesVariant = "area" | "bars" | "line" | "lines" | "";
export declare const QueryOptionsTimeSeriesVariant: any;
export type QueryOptionsTimeSeriesView = "charts" | "resultsTable" | "charts|resultsTable" | "";
export declare const QueryOptionsTimeSeriesView: any;
export interface QueryOptions {
    disableCache?: boolean;
    disableStats?: boolean;
    disableTrace?: boolean;
    maxDataPoints?: number;
    maxSeries?: number;
    noAggregation?: boolean;
    noFill?: boolean;
    noInterpolation?: boolean;
    priority?: QueryOptionsPriority | (string & {});
    resolution?: string;
    /** Controls how empty intervals are rendered in time series charts. `auto` infers from the query, `null` leaves gaps, `span` connects adjacent points, `zero` fills with zero. */
    displayNull?: QueryOptionsDisplayNull | (string & {});
    /** When enabled, charts are overlaid on a single chart instead of stacked separately. */
    overlayCharts?: BooleanString | (string & {});
    shownColumns?: string;
    timeSeriesVariant?: QueryOptionsTimeSeriesVariant | (string & {});
    timeSeriesView?: QueryOptionsTimeSeriesView | (string & {});
}
export declare const QueryOptions: S.Schema<QueryOptions>;
export interface APLRequestWithOptions {
    apl: string;
    cursor?: string;
    defaultLimit?: number;
    defaultOrder?: APLRequestWithOptionsDefaultOrderList;
    endTime?: string;
    includeCursor?: boolean;
    includeCursorField?: boolean;
    libraries?: APLRequestWithOptionsLibrariesList;
    queryOptions?: QueryOptions;
    startTime?: string;
    variables?: unknown;
}
export declare const APLRequestWithOptions: S.Schema<APLRequestWithOptions>;
export interface CreateStarredRequest {
    dataset?: string;
    kind: CreateStarredRequestKind | (string & {});
    metadata: CreateStarredRequestMetadataMap;
    name: string;
    query: APLRequestWithOptions;
    who: string;
}
export declare const CreateStarredRequest: S.Schema<CreateStarredRequest>;
export type CreateStarredResponseKind = "apl";
export declare const CreateStarredResponseKind: any;
export type CreateStarredResponseMetadataMap = {
    [key: string]: string | undefined;
};
export declare const CreateStarredResponseMetadataMap: S.Schema<CreateStarredResponseMetadataMap>;
export interface CreateStarredResponse {
    dataset?: string;
    kind: CreateStarredResponseKind;
    metadata: CreateStarredResponseMetadataMap;
    name: string;
    query: APLRequestWithOptions;
    who: string;
    id: string;
}
export declare const CreateStarredResponse: S.Schema<CreateStarredResponse>;
export interface CreateUserRequest {
    /** Email address of the new user */
    email: string;
    /** Full name of the new user */
    name: string;
    /** Role to assign to the new user */
    role: string;
}
export declare const CreateUserRequest: S.Schema<CreateUserRequest>;
/** Detailed information about a user's role */
export interface UserDetailsRole {
    /** Unique identifier for the role */
    id: string;
    /** Human-readable name of the role */
    name: string;
}
export declare const UserDetailsRole: S.Schema<UserDetailsRole>;
/** Represents a user in the system */
export interface User {
    /** User's email address */
    email: string;
    /** Unique identifier for the user */
    id: string;
    /** User's full name */
    name: string;
    role?: UserDetailsRole;
}
export declare const User: S.Schema<User>;
export type CreateViewRequestDatasetsList = Array<string>;
export declare const CreateViewRequestDatasetsList: S.Schema<CreateViewRequestDatasetsList>;
export interface CreateViewRequest {
    aplQuery: string;
    datasets?: CreateViewRequestDatasetsList;
    description?: string;
    name: string;
    /** ID of the org that shared this resource, if it's shared */
    sharedByOrg?: string;
    /** The name of the org that shared this resource, if it's shared */
    sharedByOrgName?: string;
}
export declare const CreateViewRequest: S.Schema<CreateViewRequest>;
export type ViewDatasetsList = Array<string>;
export declare const ViewDatasetsList: S.Schema<ViewDatasetsList>;
export interface View {
    aplQuery: string;
    datasets?: ViewDatasetsList;
    description?: string;
    name: string;
    /** ID of the org that shared this resource, if it's shared */
    sharedByOrg?: string;
    /** The name of the org that shared this resource, if it's shared */
    sharedByOrgName?: string;
}
export declare const View: S.Schema<View>;
export interface CreateVirtualFieldRequest {
    dataset: string;
    description?: string;
    expression: string;
    name: string;
    type?: string;
    unit?: string;
}
export declare const CreateVirtualFieldRequest: S.Schema<CreateVirtualFieldRequest>;
export interface CreateVirtualFieldResponse {
    dataset: string;
    description?: string;
    expression: string;
    name: string;
    type?: string;
    unit?: string;
    id: string;
}
export declare const CreateVirtualFieldResponse: S.Schema<CreateVirtualFieldResponse>;
export interface DeleteAnnotationRequest {
    /** Unique ID of the annotation */
    id: string;
}
export declare const DeleteAnnotationRequest: S.Schema<DeleteAnnotationRequest>;
export interface DeleteAnnotationResponse {
}
export declare const DeleteAnnotationResponse: S.Schema<DeleteAnnotationResponse>;
export interface DeleteAPITokenRequest {
    id: string;
}
export declare const DeleteAPITokenRequest: S.Schema<DeleteAPITokenRequest>;
export interface DeleteAPITokenResponse {
}
export declare const DeleteAPITokenResponse: S.Schema<DeleteAPITokenResponse>;
export interface DeleteDashboardRequest {
    uid: string;
}
export declare const DeleteDashboardRequest: S.Schema<DeleteDashboardRequest>;
export interface DeleteDashboardResponse {
}
export declare const DeleteDashboardResponse: S.Schema<DeleteDashboardResponse>;
export interface DeleteDatasetRequest {
    dataset_id: string;
}
export declare const DeleteDatasetRequest: S.Schema<DeleteDatasetRequest>;
export interface DeleteDatasetResponse {
}
export declare const DeleteDatasetResponse: S.Schema<DeleteDatasetResponse>;
export interface DeleteGroupRequest {
    /** Unique identifier of the group to delete */
    id: string;
}
export declare const DeleteGroupRequest: S.Schema<DeleteGroupRequest>;
export interface DeleteGroupResponse {
}
export declare const DeleteGroupResponse: S.Schema<DeleteGroupResponse>;
export interface DeleteMapFieldRequest {
    dataset_id: string;
    map_field_name: string;
}
export declare const DeleteMapFieldRequest: S.Schema<DeleteMapFieldRequest>;
export interface DeleteMapFieldResponse {
}
export declare const DeleteMapFieldResponse: S.Schema<DeleteMapFieldResponse>;
export interface DeleteMonitorRequest {
    id: string;
}
export declare const DeleteMonitorRequest: S.Schema<DeleteMonitorRequest>;
export interface DeleteMonitorResponse {
}
export declare const DeleteMonitorResponse: S.Schema<DeleteMonitorResponse>;
export interface DeleteNotifierRequest {
    id: string;
}
export declare const DeleteNotifierRequest: S.Schema<DeleteNotifierRequest>;
export interface DeleteNotifierResponse {
}
export declare const DeleteNotifierResponse: S.Schema<DeleteNotifierResponse>;
export interface DeleteRoleRequest {
    /** Unique identifier of the role to delete */
    id: string;
}
export declare const DeleteRoleRequest: S.Schema<DeleteRoleRequest>;
export interface DeleteRoleResponse {
}
export declare const DeleteRoleResponse: S.Schema<DeleteRoleResponse>;
export interface DeleteStarredRequest {
    id: string;
}
export declare const DeleteStarredRequest: S.Schema<DeleteStarredRequest>;
export interface DeleteStarredResponse {
}
export declare const DeleteStarredResponse: S.Schema<DeleteStarredResponse>;
export interface DeleteViewRequest {
    id: string;
}
export declare const DeleteViewRequest: S.Schema<DeleteViewRequest>;
export interface DeleteViewResponse {
}
export declare const DeleteViewResponse: S.Schema<DeleteViewResponse>;
export interface DeleteVirtualFieldRequest {
    id: string;
}
export declare const DeleteVirtualFieldRequest: S.Schema<DeleteVirtualFieldRequest>;
export interface DeleteVirtualFieldResponse {
}
export declare const DeleteVirtualFieldResponse: S.Schema<DeleteVirtualFieldResponse>;
export interface GetAnnotationRequest {
    /** Unique ID of the annotation */
    id: string;
}
export declare const GetAnnotationRequest: S.Schema<GetAnnotationRequest>;
export type GetAnnotationsRequestDatasetsList = Array<string>;
export declare const GetAnnotationsRequestDatasetsList: S.Schema<GetAnnotationsRequestDatasetsList>;
export interface GetAnnotationsRequest {
    /** Optional: Filter for dataset names. */
    datasets?: GetAnnotationsRequestDatasetsList;
    /** Optional: Filter for events after this date. Use RFC3339 time format. */
    start?: string;
    /** Optional: Filter for events before this date. Use RFC3339 time format. */
    end?: string;
}
export declare const GetAnnotationsRequest: S.Schema<GetAnnotationsRequest>;
export type GetAnnotationsResponseBodyList = Array<Annotation>;
export declare const GetAnnotationsResponseBodyList: S.Schema<GetAnnotationsResponseBodyList>;
export type GetAnnotationsResponse = GetAnnotationsResponseBodyList;
export declare const GetAnnotationsResponse: S.Schema<GetAnnotationsResponse>;
export interface GetAPITokenRequest {
    id: string;
}
export declare const GetAPITokenRequest: S.Schema<GetAPITokenRequest>;
export interface APIToken {
    datasetCapabilities: DatasetCapabilities;
    /** Description of the token */
    description?: string;
    /** Expiration date of the token (ISO 8601 format) */
    expiresAt?: string | null;
    /** ID of the token */
    id: string;
    /** Name of the token */
    name: string;
    orgCapabilities: OrgCapabilities;
    samlAuthenticated?: boolean;
    viewCapabilities?: ViewCapabilities;
}
export declare const APIToken: S.Schema<APIToken>;
export interface GetAPITokensRequest {
}
export declare const GetAPITokensRequest: S.Schema<GetAPITokensRequest>;
export type GetAPITokensResponseBodyList = Array<APIToken>;
export declare const GetAPITokensResponseBodyList: S.Schema<GetAPITokensResponseBodyList>;
export type GetAPITokensResponse = GetAPITokensResponseBodyList;
export declare const GetAPITokensResponse: S.Schema<GetAPITokensResponse>;
export interface GetCurrentUserRequest {
}
export declare const GetCurrentUserRequest: S.Schema<GetCurrentUserRequest>;
export interface GetDashboardRequest {
    uid: string;
}
export declare const GetDashboardRequest: S.Schema<GetDashboardRequest>;
export interface GetDatasetRequest {
    dataset_id: string;
}
export declare const GetDatasetRequest: S.Schema<GetDatasetRequest>;
export interface GetDatasetsRequest {
}
export declare const GetDatasetsRequest: S.Schema<GetDatasetsRequest>;
export type GetDatasetsResponseBodyList = Array<Dataset>;
export declare const GetDatasetsResponseBodyList: S.Schema<GetDatasetsResponseBodyList>;
export type GetDatasetsResponse = GetDatasetsResponseBodyList;
export declare const GetDatasetsResponse: S.Schema<GetDatasetsResponse>;
export interface GetFieldForDatasetRequest {
    dataset_id: string;
    field_id: string;
}
export declare const GetFieldForDatasetRequest: S.Schema<GetFieldForDatasetRequest>;
export interface DatasetField {
    /** Description of the field */
    description?: string;
    /** Whether the field is hidden */
    hidden?: boolean;
    /** Name of the field */
    name: string;
    /** Type of the field */
    type: string;
    /** Unit of the field */
    unit?: string;
}
export declare const DatasetField: S.Schema<DatasetField>;
export interface GetFieldsForDatasetRequest {
    dataset_id: string;
}
export declare const GetFieldsForDatasetRequest: S.Schema<GetFieldsForDatasetRequest>;
export type GetFieldsForDatasetResponseBodyList = Array<DatasetField>;
export declare const GetFieldsForDatasetResponseBodyList: S.Schema<GetFieldsForDatasetResponseBodyList>;
export type GetFieldsForDatasetResponse = GetFieldsForDatasetResponseBodyList;
export declare const GetFieldsForDatasetResponse: S.Schema<GetFieldsForDatasetResponse>;
export interface GetGroupByIdRequest {
    /** Unique identifier of the group to retrieve */
    id: string;
}
export declare const GetGroupByIdRequest: S.Schema<GetGroupByIdRequest>;
/** List of user IDs that are assigned to this group */
export type GetGroupByIdResponseMembersList = Array<string>;
export declare const GetGroupByIdResponseMembersList: S.Schema<GetGroupByIdResponseMembersList>;
/** List of role IDs that are assigned to this group */
export type GetGroupByIdResponseRolesList = Array<string>;
export declare const GetGroupByIdResponseRolesList: S.Schema<GetGroupByIdResponseRolesList>;
export interface GetGroupByIdResponse {
    /** Detailed description of the group's purpose and scope */
    description?: string;
    /** Whether the group is managed by Axiom */
    isManaged?: boolean;
    /** List of user IDs that are assigned to this group */
    members?: GetGroupByIdResponseMembersList;
    /** Unique name identifier for the group */
    name: string;
    /** List of role IDs that are assigned to this group */
    roles?: GetGroupByIdResponseRolesList;
    /** Unique identifier for the group */
    id: string;
}
export declare const GetGroupByIdResponse: S.Schema<GetGroupByIdResponse>;
export interface GetMapFieldsRequest {
    dataset_id: string;
}
export declare const GetMapFieldsRequest: S.Schema<GetMapFieldsRequest>;
/** A list of map field names */
export type MapFields = Array<string>;
export declare const MapFields: S.Schema<MapFields>;
export type GetMapFieldsResponse = MapFields;
export declare const GetMapFieldsResponse: S.Schema<GetMapFieldsResponse>;
export interface GetMonitorRequest {
    /** Unique identifier of the monitor (format: mon_*) */
    id: string;
}
export declare const GetMonitorRequest: S.Schema<GetMonitorRequest>;
/** List of notifier IDs that will receive alerts. Notifiers can be email, Slack, webhook endpoints, etc. */
export type GetMonitorResponseNotifierIdsList = Array<string>;
export declare const GetMonitorResponseNotifierIdsList: S.Schema<GetMonitorResponseNotifierIdsList>;
/** Comparison operator for threshold checks: - Below: Trigger when value < threshold - BelowOrEqual: Trigger when value <= threshold - Above: Trigger when value > threshold - AboveOrEqual: Trigger when value >= threshold - AboveOrBelow: Trigger when value is outside a range */
export type GetMonitorResponseOperator = "Below" | "BelowOrEqual" | "Above" | "AboveOrEqual" | "AboveOrBelow";
export declare const GetMonitorResponseOperator: any;
/** Type of monitoring check to perform: - Threshold: Compares a numeric value against a threshold - MatchEvent: Looks for specific events or patterns - AnomalyDetection: Identifies unusual patterns based on historical data */
export type GetMonitorResponseType = "Threshold" | "MatchEvent" | "AnomalyDetection";
export declare const GetMonitorResponseType: any;
export interface GetMonitorResponse {
    /** Whether to alert when no data is received */
    alertOnNoData?: boolean;
    /** APL (Axiom Processing Language) query string used for monitoring. This query defines what data to analyze and how to process it. At least one of aplQuery or mplQuery must be provided. */
    aplQuery?: string;
    /** Name of the column to monitor */
    columnName?: string;
    /** Number of days to compare for anomaly detection */
    compareDays?: number;
    /** Timestamp when the monitor was created */
    createdAt?: string;
    /** ID of the user who created the monitor */
    createdBy?: string;
    /** Detailed description of the monitor's purpose */
    description?: string;
    /** Whether the monitor is currently disabled */
    disabled?: boolean;
    /** Timestamp until when the monitor should remain disabled */
    disabledUntil?: string | null;
    /** How frequently the monitor should run, in minutes. Minimum value is 1 minute. */
    intervalMinutes?: number;
    /** MPL (Metrics Processing Language) query string for metrics-based monitoring. Use this as an alternative to aplQuery for metrics datasets. At least one of aplQuery or mplQuery must be provided. */
    mplQuery?: string;
    /** Name of the monitor */
    name: string;
    /** List of notifier IDs that will receive alerts. Notifiers can be email, Slack, webhook endpoints, etc. */
    notifierIds?: GetMonitorResponseNotifierIdsList;
    /** Whether to group notifications */
    notifyByGroup?: boolean;
    /** Whether to send notifications on every check */
    notifyEveryRun?: boolean;
    /** Comparison operator for threshold checks: - Below: Trigger when value < threshold - BelowOrEqual: Trigger when value <= threshold - Above: Trigger when value > threshold - AboveOrEqual: Trigger when value >= threshold - AboveOrBelow: Trigger when value is outside a range */
    operator?: GetMonitorResponseOperator;
    /** Time window to evaluate in each check, in minutes. For example, "last 5 minutes of data" */
    rangeMinutes?: number;
    /** Whether the alert can be manually resolved */
    resolvable?: boolean;
    /** Delay in seconds before triggering the alert */
    secondDelay?: number;
    /** Whether to skip resolved alerts */
    skipResolved?: boolean;
    /** Threshold value for triggering the alert */
    threshold?: number;
    /** Tolerance percentage for anomaly detection */
    tolerance?: number;
    /** Number of positive results needed before triggering */
    triggerAfterNPositiveResults?: number;
    /** Number of consecutive check runs that must fail before triggering an alert. Use this to avoid alerting on temporary spikes. */
    triggerFromNRuns?: number;
    /** Type of monitoring check to perform: - Threshold: Compares a numeric value against a threshold - MatchEvent: Looks for specific events or patterns - AnomalyDetection: Identifies unusual patterns based on historical data */
    type: GetMonitorResponseType;
    /** Timestamp when the monitor was last updated */
    updatedAt?: string;
    /** Unique identifier for the monitor */
    id: string;
}
export declare const GetMonitorResponse: S.Schema<GetMonitorResponse>;
export interface GetMonitorHistoryRequest {
    id: string;
    /** Start time (ISO 8601 format) for filtering alert history. */
    startTime: string;
    /** End time (ISO 8601 format) for filtering alert history. */
    endTime: string;
}
export declare const GetMonitorHistoryRequest: S.Schema<GetMonitorHistoryRequest>;
/** Current state of the alert */
export type AlertHistoryState = "open" | "closed";
export declare const AlertHistoryState: any;
/** Historical record of an alert's state changes. Tracks when alerts are opened and closed, allowing for incident timeline analysis. */
export interface AlertHistory {
    /** Unique identifier of the check that triggered the alert */
    checkId: string;
    /** The name of the alert */
    name: string;
    /** Current state of the alert */
    state: AlertHistoryState;
    /** ISO 8601 timestamp when the alert state changed */
    timestamp: string;
}
export declare const AlertHistory: S.Schema<AlertHistory>;
export type GetMonitorHistoryResponseBodyList = Array<AlertHistory>;
export declare const GetMonitorHistoryResponseBodyList: S.Schema<GetMonitorHistoryResponseBodyList>;
export type GetMonitorHistoryResponse = GetMonitorHistoryResponseBodyList;
export declare const GetMonitorHistoryResponse: S.Schema<GetMonitorHistoryResponse>;
export interface GetMonitorsRequest {
}
export declare const GetMonitorsRequest: S.Schema<GetMonitorsRequest>;
/** List of notifier IDs that will receive alerts. Notifiers can be email, Slack, webhook endpoints, etc. */
export type MonitorWithIdNotifierIdsList = Array<string>;
export declare const MonitorWithIdNotifierIdsList: S.Schema<MonitorWithIdNotifierIdsList>;
/** Comparison operator for threshold checks: - Below: Trigger when value < threshold - BelowOrEqual: Trigger when value <= threshold - Above: Trigger when value > threshold - AboveOrEqual: Trigger when value >= threshold - AboveOrBelow: Trigger when value is outside a range */
export type MonitorWithIdOperator = "Below" | "BelowOrEqual" | "Above" | "AboveOrEqual" | "AboveOrBelow";
export declare const MonitorWithIdOperator: any;
/** Type of monitoring check to perform: - Threshold: Compares a numeric value against a threshold - MatchEvent: Looks for specific events or patterns - AnomalyDetection: Identifies unusual patterns based on historical data */
export type MonitorWithIdType = "Threshold" | "MatchEvent" | "AnomalyDetection";
export declare const MonitorWithIdType: any;
/** Monitor configuration with its unique identifier */
export interface MonitorWithId {
    /** Whether to alert when no data is received */
    alertOnNoData?: boolean;
    /** APL (Axiom Processing Language) query string used for monitoring. This query defines what data to analyze and how to process it. At least one of aplQuery or mplQuery must be provided. */
    aplQuery?: string;
    /** Name of the column to monitor */
    columnName?: string;
    /** Number of days to compare for anomaly detection */
    compareDays?: number;
    /** Timestamp when the monitor was created */
    createdAt?: string;
    /** ID of the user who created the monitor */
    createdBy?: string;
    /** Detailed description of the monitor's purpose */
    description?: string;
    /** Whether the monitor is currently disabled */
    disabled?: boolean;
    /** Timestamp until when the monitor should remain disabled */
    disabledUntil?: string | null;
    /** How frequently the monitor should run, in minutes. Minimum value is 1 minute. */
    intervalMinutes?: number;
    /** MPL (Metrics Processing Language) query string for metrics-based monitoring. Use this as an alternative to aplQuery for metrics datasets. At least one of aplQuery or mplQuery must be provided. */
    mplQuery?: string;
    /** Name of the monitor */
    name: string;
    /** List of notifier IDs that will receive alerts. Notifiers can be email, Slack, webhook endpoints, etc. */
    notifierIds?: MonitorWithIdNotifierIdsList;
    /** Whether to group notifications */
    notifyByGroup?: boolean;
    /** Whether to send notifications on every check */
    notifyEveryRun?: boolean;
    /** Comparison operator for threshold checks: - Below: Trigger when value < threshold - BelowOrEqual: Trigger when value <= threshold - Above: Trigger when value > threshold - AboveOrEqual: Trigger when value >= threshold - AboveOrBelow: Trigger when value is outside a range */
    operator?: MonitorWithIdOperator;
    /** Time window to evaluate in each check, in minutes. For example, "last 5 minutes of data" */
    rangeMinutes?: number;
    /** Whether the alert can be manually resolved */
    resolvable?: boolean;
    /** Delay in seconds before triggering the alert */
    secondDelay?: number;
    /** Whether to skip resolved alerts */
    skipResolved?: boolean;
    /** Threshold value for triggering the alert */
    threshold?: number;
    /** Tolerance percentage for anomaly detection */
    tolerance?: number;
    /** Number of positive results needed before triggering */
    triggerAfterNPositiveResults?: number;
    /** Number of consecutive check runs that must fail before triggering an alert. Use this to avoid alerting on temporary spikes. */
    triggerFromNRuns?: number;
    /** Type of monitoring check to perform: - Threshold: Compares a numeric value against a threshold - MatchEvent: Looks for specific events or patterns - AnomalyDetection: Identifies unusual patterns based on historical data */
    type: MonitorWithIdType;
    /** Timestamp when the monitor was last updated */
    updatedAt?: string;
    /** Unique identifier for the monitor */
    id: string;
}
export declare const MonitorWithId: S.Schema<MonitorWithId>;
export type GetMonitorsResponseBodyList = Array<MonitorWithId>;
export declare const GetMonitorsResponseBodyList: S.Schema<GetMonitorsResponseBodyList>;
export type GetMonitorsResponse = GetMonitorsResponseBodyList;
export declare const GetMonitorsResponse: S.Schema<GetMonitorsResponse>;
export interface GetNotifierRequest {
    /** Unique identifier of the notifier (format: notify_*) */
    id: string;
}
export declare const GetNotifierRequest: S.Schema<GetNotifierRequest>;
export interface GetNotifierResponse {
    /** Timestamp when the notifier was created */
    createdAt?: string;
    /** Email or ID of the user who created the notifier */
    createdBy?: string;
    /** ISO timestamp until which the notifier is disabled (null if enabled) */
    disabledUntil?: string;
    /** Human-readable name for the notifier */
    name: string;
    properties: NotifierProperties;
    /** Timestamp when the notifier was last updated */
    updatedAt?: string;
    /** Unique identifier for the notifier */
    id?: string;
}
export declare const GetNotifierResponse: S.Schema<GetNotifierResponse>;
export interface GetNotifiersRequest {
}
export declare const GetNotifiersRequest: S.Schema<GetNotifiersRequest>;
/** Notifier configuration with its unique identifier */
export interface NotifierWithId {
    /** Timestamp when the notifier was created */
    createdAt?: string;
    /** Email or ID of the user who created the notifier */
    createdBy?: string;
    /** ISO timestamp until which the notifier is disabled (null if enabled) */
    disabledUntil?: string;
    /** Human-readable name for the notifier */
    name: string;
    properties: NotifierProperties;
    /** Timestamp when the notifier was last updated */
    updatedAt?: string;
    /** Unique identifier for the notifier */
    id?: string;
}
export declare const NotifierWithId: S.Schema<NotifierWithId>;
export type GetNotifiersResponseBodyList = Array<NotifierWithId>;
export declare const GetNotifiersResponseBodyList: S.Schema<GetNotifiersResponseBodyList>;
export type GetNotifiersResponse = GetNotifiersResponseBodyList;
export declare const GetNotifiersResponse: S.Schema<GetNotifiersResponse>;
export interface GetOrgRequest {
    id: string;
}
export declare const GetOrgRequest: S.Schema<GetOrgRequest>;
export interface GetOrgsRequest {
}
export declare const GetOrgsRequest: S.Schema<GetOrgsRequest>;
export type GetOrgsResponseBodyList = Array<Org>;
export declare const GetOrgsResponseBodyList: S.Schema<GetOrgsResponseBodyList>;
export type GetOrgsResponse = GetOrgsResponseBodyList;
export declare const GetOrgsResponse: S.Schema<GetOrgsResponse>;
export interface GetRoleByIdRequest {
    /** Unique identifier of the role to retrieve */
    id: string;
}
export declare const GetRoleByIdRequest: S.Schema<GetRoleByIdRequest>;
/** List of user IDs that are assigned to this role */
export type GetRoleByIdResponseMembersList = Array<string>;
export declare const GetRoleByIdResponseMembersList: S.Schema<GetRoleByIdResponseMembersList>;
export interface GetRoleByIdResponse {
    datasetCapabilities?: RoleDatasetCapabilities;
    /** Detailed description of the role's purpose and scope */
    description?: string;
    /** List of user IDs that are assigned to this role */
    members?: GetRoleByIdResponseMembersList;
    /** Unique name identifier for the role */
    name: string;
    orgCapabilities?: RoleOrgCapabilities;
    viewCapabilities?: RoleViewCapabilities;
    /** Unique identifier for the role */
    id: string;
}
export declare const GetRoleByIdResponse: S.Schema<GetRoleByIdResponse>;
export interface GetStarredRequest {
    id: string;
}
export declare const GetStarredRequest: S.Schema<GetStarredRequest>;
export type GetStarredResponseKind = "apl";
export declare const GetStarredResponseKind: any;
export type GetStarredResponseMetadataMap = {
    [key: string]: string | undefined;
};
export declare const GetStarredResponseMetadataMap: S.Schema<GetStarredResponseMetadataMap>;
export interface GetStarredResponse {
    dataset?: string;
    kind: GetStarredResponseKind;
    metadata: GetStarredResponseMetadataMap;
    name: string;
    query: APLRequestWithOptions;
    who: string;
    id: string;
}
export declare const GetStarredResponse: S.Schema<GetStarredResponse>;
export interface GetStarredQueriesRequest {
    limit?: number;
    offset?: number;
    dataset?: string;
    /** - If the value of `who` is undefined, the request returns queries starred by the authenticated user. - If the value of `who` is a user ID, the request returns queries starred by the user with this ID (this request requires elevated privileges). For example, `&who='abc123'`. - If the value of `who` is `team`, the request returns queries starred by the team apart from the authenticated user.For example, `&who=team`. - If the value of `who` is `all`, the request returns queries starred by all users in the team, including the authenticated user. For example, `&who=all`. */
    who?: string;
    qs?: string;
}
export declare const GetStarredQueriesRequest: S.Schema<GetStarredQueriesRequest>;
export type StarredQueryWithIdKind = "apl";
export declare const StarredQueryWithIdKind: any;
export type StarredQueryWithIdMetadataMap = {
    [key: string]: string | undefined;
};
export declare const StarredQueryWithIdMetadataMap: S.Schema<StarredQueryWithIdMetadataMap>;
export interface StarredQueryWithId {
    dataset?: string;
    kind: StarredQueryWithIdKind;
    metadata: StarredQueryWithIdMetadataMap;
    name: string;
    query: APLRequestWithOptions;
    who: string;
    id: string;
}
export declare const StarredQueryWithId: S.Schema<StarredQueryWithId>;
export type GetStarredQueriesResponseBodyList = Array<StarredQueryWithId>;
export declare const GetStarredQueriesResponseBodyList: S.Schema<GetStarredQueriesResponseBodyList>;
export type GetStarredQueriesResponse = GetStarredQueriesResponseBodyList;
export declare const GetStarredQueriesResponse: S.Schema<GetStarredQueriesResponse>;
export interface GetUserRequest {
    id: string;
}
export declare const GetUserRequest: S.Schema<GetUserRequest>;
export interface GetUsersRequest {
}
export declare const GetUsersRequest: S.Schema<GetUsersRequest>;
export type GetUsersResponseBodyList = Array<User>;
export declare const GetUsersResponseBodyList: S.Schema<GetUsersResponseBodyList>;
export type GetUsersResponse = GetUsersResponseBodyList;
export declare const GetUsersResponse: S.Schema<GetUsersResponse>;
export interface GetViewRequest {
    id: string;
}
export declare const GetViewRequest: S.Schema<GetViewRequest>;
export interface GetViewsRequest {
}
export declare const GetViewsRequest: S.Schema<GetViewsRequest>;
export type GetViewsResponseBodyList = Array<View>;
export declare const GetViewsResponseBodyList: S.Schema<GetViewsResponseBodyList>;
export type GetViewsResponse = GetViewsResponseBodyList;
export declare const GetViewsResponse: S.Schema<GetViewsResponse>;
export interface GetVirtualFieldRequest {
    id: string;
}
export declare const GetVirtualFieldRequest: S.Schema<GetVirtualFieldRequest>;
export interface GetVirtualFieldResponse {
    dataset: string;
    description?: string;
    expression: string;
    name: string;
    type?: string;
    unit?: string;
    id: string;
}
export declare const GetVirtualFieldResponse: S.Schema<GetVirtualFieldResponse>;
export interface GetVirtualFieldsRequest {
    dataset: string;
}
export declare const GetVirtualFieldsRequest: S.Schema<GetVirtualFieldsRequest>;
export interface VirtualFieldWithId {
    dataset: string;
    description?: string;
    expression: string;
    name: string;
    type?: string;
    unit?: string;
    id: string;
}
export declare const VirtualFieldWithId: S.Schema<VirtualFieldWithId>;
export type GetVirtualFieldsResponseBodyList = Array<VirtualFieldWithId>;
export declare const GetVirtualFieldsResponseBodyList: S.Schema<GetVirtualFieldsResponseBodyList>;
export type GetVirtualFieldsResponse = GetVirtualFieldsResponseBodyList;
export declare const GetVirtualFieldsResponse: S.Schema<GetVirtualFieldsResponse>;
export interface ListDashboardsRequest {
    limit?: number;
    offset?: number;
}
export declare const ListDashboardsRequest: S.Schema<ListDashboardsRequest>;
export type ListDashboardsResponseBodyList = Array<DashboardResource>;
export declare const ListDashboardsResponseBodyList: S.Schema<ListDashboardsResponseBodyList>;
export type ListDashboardsResponse = ListDashboardsResponseBodyList;
export declare const ListDashboardsResponse: S.Schema<ListDashboardsResponse>;
export interface ListGroupsRequest {
}
export declare const ListGroupsRequest: S.Schema<ListGroupsRequest>;
/** List of user IDs that are assigned to this group */
export type GroupWithIDMembersList = Array<string>;
export declare const GroupWithIDMembersList: S.Schema<GroupWithIDMembersList>;
/** List of role IDs that are assigned to this group */
export type GroupWithIDRolesList = Array<string>;
export declare const GroupWithIDRolesList: S.Schema<GroupWithIDRolesList>;
/** Extends the base Group type to include a unique identifier */
export interface GroupWithID {
    /** Detailed description of the group's purpose and scope */
    description?: string;
    /** Whether the group is managed by Axiom */
    isManaged?: boolean;
    /** List of user IDs that are assigned to this group */
    members?: GroupWithIDMembersList;
    /** Unique name identifier for the group */
    name: string;
    /** List of role IDs that are assigned to this group */
    roles?: GroupWithIDRolesList;
    /** Unique identifier for the group */
    id: string;
}
export declare const GroupWithID: S.Schema<GroupWithID>;
export type ListGroupsResponseBodyList = Array<GroupWithID>;
export declare const ListGroupsResponseBodyList: S.Schema<ListGroupsResponseBodyList>;
export type ListGroupsResponse = ListGroupsResponseBodyList;
export declare const ListGroupsResponse: S.Schema<ListGroupsResponse>;
export interface ListRolesRequest {
}
export declare const ListRolesRequest: S.Schema<ListRolesRequest>;
/** List of user IDs that are assigned to this role */
export type RoleWithIDMembersList = Array<string>;
export declare const RoleWithIDMembersList: S.Schema<RoleWithIDMembersList>;
/** Extends the base Role type to include a unique identifier */
export interface RoleWithID {
    datasetCapabilities?: RoleDatasetCapabilities;
    /** Detailed description of the role's purpose and scope */
    description?: string;
    /** List of user IDs that are assigned to this role */
    members?: RoleWithIDMembersList;
    /** Unique name identifier for the role */
    name: string;
    orgCapabilities?: RoleOrgCapabilities;
    viewCapabilities?: RoleViewCapabilities;
    /** Unique identifier for the role */
    id: string;
}
export declare const RoleWithID: S.Schema<RoleWithID>;
export type ListRolesResponseBodyList = Array<RoleWithID>;
export declare const ListRolesResponseBodyList: S.Schema<ListRolesResponseBodyList>;
export type ListRolesResponse = ListRolesResponseBodyList;
export declare const ListRolesResponse: S.Schema<ListRolesResponse>;
export type DashboardChartPatchDocument = {
    [key: string]: unknown | undefined;
};
export declare const DashboardChartPatchDocument: S.Schema<DashboardChartPatchDocument>;
export interface PatchDashboardChartRequest {
    uid: string;
    chartId: string;
    /** JSON merge patch applied to the existing chart. If id is present, it must match the chartId path parameter. */
    chart: DashboardChartPatchDocument;
    message?: string;
    overwrite?: boolean;
    /** Required when overwrite is false. */
    version?: number;
}
export declare const PatchDashboardChartRequest: S.Schema<PatchDashboardChartRequest>;
export interface ProvisionOrgRequest {
    /** Optional display name for the organization. If omitted, a name is auto-generated and the owner can rename it later. */
    name?: string;
    /** Optional edge deployment (region) the organization is created in. If omitted, the environment's default region is used. */
    edgeDeployment?: string;
}
export declare const ProvisionOrgRequest: S.Schema<ProvisionOrgRequest>;
export interface ProvisionOrgResponse {
    id: string;
    name: string;
    defaultEdgeDeployment: string;
    expiresAt: string;
    /** URL a human follows to claim ownership of the temporary org. */
    claimUrl: string;
    /** Full-permission API token the agent uses to create datasets, ingest, and query. Returned once and never retrievable again. */
    token: string;
}
export declare const ProvisionOrgResponse: S.Schema<ProvisionOrgResponse>;
export interface CreateAPIToken2 {
    datasetCapabilities?: DatasetCapabilities;
    /** Description of the token */
    description?: string;
    /** Expiration date of the token (ISO 8601 format) */
    expiresAt?: string | null;
    /** Name of the token */
    name: string;
    orgCapabilities?: OrgCapabilities;
    viewCapabilities?: ViewCapabilities;
}
export declare const CreateAPIToken2: S.Schema<CreateAPIToken2>;
export interface RegenerateAPITokenRequest {
    id: string;
    /** Expiration date of the existing token (ISO 8601 format) */
    existingTokenExpiresAt: string;
    newToken?: CreateAPIToken2;
    /** Expiration date of the new token (ISO 8601 format) */
    newTokenExpiresAt?: string | null;
}
export declare const RegenerateAPITokenRequest: S.Schema<RegenerateAPITokenRequest>;
export interface RegenerateAPITokenResponse {
    datasetCapabilities: DatasetCapabilities;
    /** Description of the token */
    description?: string;
    /** Expiration date of the token (ISO 8601 format) */
    expiresAt?: string | null;
    /** ID of the token */
    id: string;
    /** Name of the token */
    name: string;
    orgCapabilities: OrgCapabilities;
    samlAuthenticated?: boolean;
    viewCapabilities?: ViewCapabilities;
    token?: string;
}
export declare const RegenerateAPITokenResponse: S.Schema<RegenerateAPITokenResponse>;
export interface RemoveUserFromOrgRequest {
    id: string;
}
export declare const RemoveUserFromOrgRequest: S.Schema<RemoveUserFromOrgRequest>;
export interface RemoveUserFromOrgResponse {
}
export declare const RemoveUserFromOrgResponse: S.Schema<RemoveUserFromOrgResponse>;
export interface TrimDatasetRequest {
    dataset_id: string;
    maxDuration: string;
}
export declare const TrimDatasetRequest: S.Schema<TrimDatasetRequest>;
export interface TrimDatasetResponse {
}
export declare const TrimDatasetResponse: S.Schema<TrimDatasetResponse>;
/** array<string> of dataset names for which the annotation appears on charts */
export type UpdateAnnotationRequestDatasetsList = Array<string>;
export declare const UpdateAnnotationRequestDatasetsList: S.Schema<UpdateAnnotationRequestDatasetsList>;
export interface UpdateAnnotationRequest {
    /** Unique ID of the annotation */
    id: string;
    /** array<string> of dataset names for which the annotation appears on charts */
    datasets?: UpdateAnnotationRequestDatasetsList;
    /** Explanation of the event the annotation marks on the charts */
    description?: string;
    /** End time of the annotation */
    endTime?: string;
    /** Time the annotation marks on the charts. If you don't include this field, Axiom assigns the time of the API request to the annotation. */
    time?: string;
    /** Summary of the annotation that appears on the charts */
    title?: string;
    /** Type of the event marked by the annotation. Use only alphanumeric characters or hyphens. For example, "production-deployment". */
    type?: string;
    /** URL relevant for the event marked by the annotation. For example, link to GitHub pull request. */
    url?: string;
}
export declare const UpdateAnnotationRequest: S.Schema<UpdateAnnotationRequest>;
export interface UpdateCurrentUserRequest {
    /** New name for the user */
    name: string;
}
export declare const UpdateCurrentUserRequest: S.Schema<UpdateCurrentUserRequest>;
/** Required for updates when overwrite is false. Pass back the version value received from the server verbatim (string or number). */
export type UpdateDashboardRequestVersion = string | number;
export declare const UpdateDashboardRequestVersion: S.Schema<UpdateDashboardRequestVersion>;
export interface UpdateDashboardRequest {
    uid: string;
    dashboard: Dashboard;
    message?: string;
    overwrite?: boolean;
    /** Required for updates when overwrite is false. Pass back the version value received from the server verbatim (string or number). */
    version?: UpdateDashboardRequestVersion;
}
export declare const UpdateDashboardRequest: S.Schema<UpdateDashboardRequest>;
export interface UpdateDatasetRequest {
    dataset_id: string;
    description?: string;
    /** Number of days to retain data in the dataset */
    retentionDays?: number;
    /** Whether to use the retention period */
    useRetentionPeriod?: boolean;
}
export declare const UpdateDatasetRequest: S.Schema<UpdateDatasetRequest>;
export interface UpdateFieldForDatasetRequest {
    dataset_id: string;
    field_id: string;
    /** Description of the field */
    description?: string;
    /** Whether the field is hidden */
    hidden?: boolean;
    /** Name of the field */
    name: string;
    /** Type of the field */
    type: string;
    /** Unit of the field */
    unit?: string;
}
export declare const UpdateFieldForDatasetRequest: S.Schema<UpdateFieldForDatasetRequest>;
/** List of user IDs that are assigned to this group */
export type UpdateGroupRequestMembersList = Array<string>;
export declare const UpdateGroupRequestMembersList: S.Schema<UpdateGroupRequestMembersList>;
/** List of role IDs that are assigned to this group */
export type UpdateGroupRequestRolesList = Array<string>;
export declare const UpdateGroupRequestRolesList: S.Schema<UpdateGroupRequestRolesList>;
export interface UpdateGroupRequest {
    /** Unique identifier of the group to update */
    id: string;
    /** Detailed description of the group's purpose and scope */
    description?: string;
    /** List of user IDs that are assigned to this group */
    members?: UpdateGroupRequestMembersList;
    /** Unique name identifier for the group */
    name: string;
    /** List of role IDs that are assigned to this group */
    roles?: UpdateGroupRequestRolesList;
}
export declare const UpdateGroupRequest: S.Schema<UpdateGroupRequest>;
/** List of user IDs that are assigned to this group */
export type UpdateGroupResponseMembersList = Array<string>;
export declare const UpdateGroupResponseMembersList: S.Schema<UpdateGroupResponseMembersList>;
/** List of role IDs that are assigned to this group */
export type UpdateGroupResponseRolesList = Array<string>;
export declare const UpdateGroupResponseRolesList: S.Schema<UpdateGroupResponseRolesList>;
export interface UpdateGroupResponse {
    /** Detailed description of the group's purpose and scope */
    description?: string;
    /** Whether the group is managed by Axiom */
    isManaged?: boolean;
    /** List of user IDs that are assigned to this group */
    members?: UpdateGroupResponseMembersList;
    /** Unique name identifier for the group */
    name: string;
    /** List of role IDs that are assigned to this group */
    roles?: UpdateGroupResponseRolesList;
    /** Unique identifier for the group */
    id: string;
}
export declare const UpdateGroupResponse: S.Schema<UpdateGroupResponse>;
export interface UpdateMapFieldsRequest {
    dataset_id: string;
    body: MapFields;
}
export declare const UpdateMapFieldsRequest: S.Schema<UpdateMapFieldsRequest>;
export type UpdateMapFieldsResponse = MapFields;
export declare const UpdateMapFieldsResponse: S.Schema<UpdateMapFieldsResponse>;
/** List of notifier IDs that will receive alerts. Notifiers can be email, Slack, webhook endpoints, etc. */
export type UpdateMonitorRequestNotifierIdsList = Array<string>;
export declare const UpdateMonitorRequestNotifierIdsList: S.Schema<UpdateMonitorRequestNotifierIdsList>;
/** Comparison operator for threshold checks: - Below: Trigger when value < threshold - BelowOrEqual: Trigger when value <= threshold - Above: Trigger when value > threshold - AboveOrEqual: Trigger when value >= threshold - AboveOrBelow: Trigger when value is outside a range */
export type UpdateMonitorRequestOperator = "Below" | "BelowOrEqual" | "Above" | "AboveOrEqual" | "AboveOrBelow";
export declare const UpdateMonitorRequestOperator: any;
/** Type of monitoring check to perform: - Threshold: Compares a numeric value against a threshold - MatchEvent: Looks for specific events or patterns - AnomalyDetection: Identifies unusual patterns based on historical data */
export type UpdateMonitorRequestType = "Threshold" | "MatchEvent" | "AnomalyDetection";
export declare const UpdateMonitorRequestType: any;
export interface UpdateMonitorRequest {
    id: string;
    /** Whether to alert when no data is received */
    alertOnNoData?: boolean;
    /** APL (Axiom Processing Language) query string used for monitoring. This query defines what data to analyze and how to process it. At least one of aplQuery or mplQuery must be provided. */
    aplQuery?: string;
    /** Name of the column to monitor */
    columnName?: string;
    /** Number of days to compare for anomaly detection */
    compareDays?: number;
    /** Timestamp when the monitor was created */
    createdAt?: string;
    /** ID of the user who created the monitor */
    createdBy?: string;
    /** Detailed description of the monitor's purpose */
    description?: string;
    /** Whether the monitor is currently disabled */
    disabled?: boolean;
    /** Timestamp until when the monitor should remain disabled */
    disabledUntil?: string | null;
    /** How frequently the monitor should run, in minutes. Minimum value is 1 minute. */
    intervalMinutes?: number;
    /** MPL (Metrics Processing Language) query string for metrics-based monitoring. Use this as an alternative to aplQuery for metrics datasets. At least one of aplQuery or mplQuery must be provided. */
    mplQuery?: string;
    /** Name of the monitor */
    name: string;
    /** List of notifier IDs that will receive alerts. Notifiers can be email, Slack, webhook endpoints, etc. */
    notifierIds?: UpdateMonitorRequestNotifierIdsList;
    /** Whether to group notifications */
    notifyByGroup?: boolean;
    /** Whether to send notifications on every check */
    notifyEveryRun?: boolean;
    /** Comparison operator for threshold checks: - Below: Trigger when value < threshold - BelowOrEqual: Trigger when value <= threshold - Above: Trigger when value > threshold - AboveOrEqual: Trigger when value >= threshold - AboveOrBelow: Trigger when value is outside a range */
    operator?: UpdateMonitorRequestOperator | (string & {});
    /** Time window to evaluate in each check, in minutes. For example, "last 5 minutes of data" */
    rangeMinutes?: number;
    /** Whether the alert can be manually resolved */
    resolvable?: boolean;
    /** Delay in seconds before triggering the alert */
    secondDelay?: number;
    /** Whether to skip resolved alerts */
    skipResolved?: boolean;
    /** Threshold value for triggering the alert */
    threshold?: number;
    /** Tolerance percentage for anomaly detection */
    tolerance?: number;
    /** Number of positive results needed before triggering */
    triggerAfterNPositiveResults?: number;
    /** Number of consecutive check runs that must fail before triggering an alert. Use this to avoid alerting on temporary spikes. */
    triggerFromNRuns?: number;
    /** Type of monitoring check to perform: - Threshold: Compares a numeric value against a threshold - MatchEvent: Looks for specific events or patterns - AnomalyDetection: Identifies unusual patterns based on historical data */
    type: UpdateMonitorRequestType | (string & {});
    /** Timestamp when the monitor was last updated */
    updatedAt?: string;
}
export declare const UpdateMonitorRequest: S.Schema<UpdateMonitorRequest>;
/** List of notifier IDs that will receive alerts. Notifiers can be email, Slack, webhook endpoints, etc. */
export type UpdateMonitorResponseNotifierIdsList = Array<string>;
export declare const UpdateMonitorResponseNotifierIdsList: S.Schema<UpdateMonitorResponseNotifierIdsList>;
/** Comparison operator for threshold checks: - Below: Trigger when value < threshold - BelowOrEqual: Trigger when value <= threshold - Above: Trigger when value > threshold - AboveOrEqual: Trigger when value >= threshold - AboveOrBelow: Trigger when value is outside a range */
export type UpdateMonitorResponseOperator = "Below" | "BelowOrEqual" | "Above" | "AboveOrEqual" | "AboveOrBelow";
export declare const UpdateMonitorResponseOperator: any;
/** Type of monitoring check to perform: - Threshold: Compares a numeric value against a threshold - MatchEvent: Looks for specific events or patterns - AnomalyDetection: Identifies unusual patterns based on historical data */
export type UpdateMonitorResponseType = "Threshold" | "MatchEvent" | "AnomalyDetection";
export declare const UpdateMonitorResponseType: any;
export interface UpdateMonitorResponse {
    /** Whether to alert when no data is received */
    alertOnNoData?: boolean;
    /** APL (Axiom Processing Language) query string used for monitoring. This query defines what data to analyze and how to process it. At least one of aplQuery or mplQuery must be provided. */
    aplQuery?: string;
    /** Name of the column to monitor */
    columnName?: string;
    /** Number of days to compare for anomaly detection */
    compareDays?: number;
    /** Timestamp when the monitor was created */
    createdAt?: string;
    /** ID of the user who created the monitor */
    createdBy?: string;
    /** Detailed description of the monitor's purpose */
    description?: string;
    /** Whether the monitor is currently disabled */
    disabled?: boolean;
    /** Timestamp until when the monitor should remain disabled */
    disabledUntil?: string | null;
    /** How frequently the monitor should run, in minutes. Minimum value is 1 minute. */
    intervalMinutes?: number;
    /** MPL (Metrics Processing Language) query string for metrics-based monitoring. Use this as an alternative to aplQuery for metrics datasets. At least one of aplQuery or mplQuery must be provided. */
    mplQuery?: string;
    /** Name of the monitor */
    name: string;
    /** List of notifier IDs that will receive alerts. Notifiers can be email, Slack, webhook endpoints, etc. */
    notifierIds?: UpdateMonitorResponseNotifierIdsList;
    /** Whether to group notifications */
    notifyByGroup?: boolean;
    /** Whether to send notifications on every check */
    notifyEveryRun?: boolean;
    /** Comparison operator for threshold checks: - Below: Trigger when value < threshold - BelowOrEqual: Trigger when value <= threshold - Above: Trigger when value > threshold - AboveOrEqual: Trigger when value >= threshold - AboveOrBelow: Trigger when value is outside a range */
    operator?: UpdateMonitorResponseOperator;
    /** Time window to evaluate in each check, in minutes. For example, "last 5 minutes of data" */
    rangeMinutes?: number;
    /** Whether the alert can be manually resolved */
    resolvable?: boolean;
    /** Delay in seconds before triggering the alert */
    secondDelay?: number;
    /** Whether to skip resolved alerts */
    skipResolved?: boolean;
    /** Threshold value for triggering the alert */
    threshold?: number;
    /** Tolerance percentage for anomaly detection */
    tolerance?: number;
    /** Number of positive results needed before triggering */
    triggerAfterNPositiveResults?: number;
    /** Number of consecutive check runs that must fail before triggering an alert. Use this to avoid alerting on temporary spikes. */
    triggerFromNRuns?: number;
    /** Type of monitoring check to perform: - Threshold: Compares a numeric value against a threshold - MatchEvent: Looks for specific events or patterns - AnomalyDetection: Identifies unusual patterns based on historical data */
    type: UpdateMonitorResponseType;
    /** Timestamp when the monitor was last updated */
    updatedAt?: string;
    /** Unique identifier for the monitor */
    id: string;
}
export declare const UpdateMonitorResponse: S.Schema<UpdateMonitorResponse>;
export interface UpdateNotifierRequest {
    id: string;
    /** ISO timestamp until which the notifier is disabled (null if enabled) */
    disabledUntil?: string;
    /** Human-readable name for the notifier */
    name: string;
    properties: NotifierProperties;
}
export declare const UpdateNotifierRequest: S.Schema<UpdateNotifierRequest>;
export interface UpdateNotifierResponse {
    /** Timestamp when the notifier was created */
    createdAt?: string;
    /** Email or ID of the user who created the notifier */
    createdBy?: string;
    /** ISO timestamp until which the notifier is disabled (null if enabled) */
    disabledUntil?: string;
    /** Human-readable name for the notifier */
    name: string;
    properties: NotifierProperties;
    /** Timestamp when the notifier was last updated */
    updatedAt?: string;
    /** Unique identifier for the notifier */
    id?: string;
}
export declare const UpdateNotifierResponse: S.Schema<UpdateNotifierResponse>;
export interface UpdateOrgRequest {
    id: string;
    name: string;
}
export declare const UpdateOrgRequest: S.Schema<UpdateOrgRequest>;
/** List of user IDs that are assigned to this role */
export type UpdateRoleRequestMembersList = Array<string>;
export declare const UpdateRoleRequestMembersList: S.Schema<UpdateRoleRequestMembersList>;
export interface UpdateRoleRequest {
    /** Unique identifier of the role to update */
    id: string;
    datasetCapabilities?: RoleDatasetCapabilities;
    /** Detailed description of the role's purpose and scope */
    description?: string;
    /** List of user IDs that are assigned to this role */
    members?: UpdateRoleRequestMembersList;
    /** Unique name identifier for the role */
    name: string;
    orgCapabilities?: RoleOrgCapabilities;
    viewCapabilities?: RoleViewCapabilities;
}
export declare const UpdateRoleRequest: S.Schema<UpdateRoleRequest>;
/** List of user IDs that are assigned to this role */
export type UpdateRoleResponseMembersList = Array<string>;
export declare const UpdateRoleResponseMembersList: S.Schema<UpdateRoleResponseMembersList>;
export interface UpdateRoleResponse {
    datasetCapabilities?: RoleDatasetCapabilities;
    /** Detailed description of the role's purpose and scope */
    description?: string;
    /** List of user IDs that are assigned to this role */
    members?: UpdateRoleResponseMembersList;
    /** Unique name identifier for the role */
    name: string;
    orgCapabilities?: RoleOrgCapabilities;
    viewCapabilities?: RoleViewCapabilities;
    /** Unique identifier for the role */
    id: string;
}
export declare const UpdateRoleResponse: S.Schema<UpdateRoleResponse>;
export type UpdateStarredRequestKind = "apl";
export declare const UpdateStarredRequestKind: any;
export type UpdateStarredRequestMetadataMap = {
    [key: string]: string | undefined;
};
export declare const UpdateStarredRequestMetadataMap: S.Schema<UpdateStarredRequestMetadataMap>;
export interface UpdateStarredRequest {
    id: string;
    dataset?: string;
    kind: UpdateStarredRequestKind | (string & {});
    metadata: UpdateStarredRequestMetadataMap;
    name: string;
    query: APLRequestWithOptions;
    who: string;
}
export declare const UpdateStarredRequest: S.Schema<UpdateStarredRequest>;
export type UpdateStarredResponseKind = "apl";
export declare const UpdateStarredResponseKind: any;
export type UpdateStarredResponseMetadataMap = {
    [key: string]: string | undefined;
};
export declare const UpdateStarredResponseMetadataMap: S.Schema<UpdateStarredResponseMetadataMap>;
export interface UpdateStarredResponse {
    dataset?: string;
    kind: UpdateStarredResponseKind;
    metadata: UpdateStarredResponseMetadataMap;
    name: string;
    query: APLRequestWithOptions;
    who: string;
    id: string;
}
export declare const UpdateStarredResponse: S.Schema<UpdateStarredResponse>;
export interface UpdateUserRoleRequest {
    id: string;
    /** Role identifier to assign to the user */
    role: string;
}
export declare const UpdateUserRoleRequest: S.Schema<UpdateUserRoleRequest>;
export type UpdateViewRequestDatasetsList = Array<string>;
export declare const UpdateViewRequestDatasetsList: S.Schema<UpdateViewRequestDatasetsList>;
export interface UpdateViewRequest {
    id: string;
    aplQuery: string;
    datasets?: UpdateViewRequestDatasetsList;
    description?: string;
    name: string;
    /** ID of the org that shared this resource, if it's shared */
    sharedByOrg?: string;
    /** The name of the org that shared this resource, if it's shared */
    sharedByOrgName?: string;
}
export declare const UpdateViewRequest: S.Schema<UpdateViewRequest>;
export interface UpdateVirtualFieldRequest {
    id: string;
    dataset: string;
    description?: string;
    expression: string;
    name: string;
    type?: string;
    unit?: string;
}
export declare const UpdateVirtualFieldRequest: S.Schema<UpdateVirtualFieldRequest>;
export interface UpdateVirtualFieldResponse {
    dataset: string;
    description?: string;
    expression: string;
    name: string;
    type?: string;
    unit?: string;
    id: string;
}
export declare const UpdateVirtualFieldResponse: S.Schema<UpdateVirtualFieldResponse>;
export interface VacuumDatasetRequest {
    dataset_id: string;
}
export declare const VacuumDatasetRequest: S.Schema<VacuumDatasetRequest>;
export interface VacuumDatasetResponse {
}
export declare const VacuumDatasetResponse: S.Schema<VacuumDatasetResponse>;
export type CreateAnnotationError = BadRequest | UnprocessableEntity | AxiomOpError;
/** Create annotation */
export declare const createAnnotation: API.OperationMethod<CreateAnnotationRequest, Annotation, CreateAnnotationError, AxiomOpContext>;
export type CreateAPITokenError = UnprocessableEntity | AxiomOpError;
/** Create API token */
export declare const createAPIToken: API.OperationMethod<CreateAPITokenRequest, CreateAPITokenResponse, CreateAPITokenError, AxiomOpContext>;
export type CreateDashboardError = BadRequest | Conflict | AxiomOpError;
/** Create dashboard Create a dashboard from a dashboard document payload. */
export declare const createDashboard: API.OperationMethod<CreateDashboardRequest, DashboardWriteResponse, CreateDashboardError, AxiomOpContext>;
export type CreateDatasetError = BadRequest | Forbidden | UnprocessableEntity | AxiomOpError;
/** Create dataset Create dataset */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest, Dataset, CreateDatasetError, AxiomOpContext>;
export type CreateGroupError = UnprocessableEntity | AxiomOpError;
/** Create group Creates a new group in the organization. */
export declare const createGroup: API.OperationMethod<CreateGroupRequest, CreateGroupResponse, CreateGroupError, AxiomOpContext>;
export type CreateMapFieldError = NotFound | UnprocessableEntity | AxiomOpError;
export declare const createMapField: API.OperationMethod<CreateMapFieldRequest, MapField, CreateMapFieldError, AxiomOpContext>;
export type CreateMonitorError = UnprocessableEntity | AxiomOpError;
/** Create monitor */
export declare const createMonitor: API.OperationMethod<CreateMonitorRequest, CreateMonitorResponse, CreateMonitorError, AxiomOpContext>;
export type CreateNotifierError = UnprocessableEntity | AxiomOpError;
/** Creates a new notifier configuration for sending alerts through various channels (Slack, Email, etc) */
export declare const createNotifier: API.OperationMethod<CreateNotifierRequest, CreateNotifierResponse, CreateNotifierError, AxiomOpContext>;
export type CreateOrgError = AxiomOpError;
export declare const createOrg: API.OperationMethod<CreateOrgRequest, Org, CreateOrgError, AxiomOpContext>;
export type CreateRoleError = UnprocessableEntity | AxiomOpError;
/** Create role Creates a new role in the organization with the specified permissions and member assignments. */
export declare const createRole: API.OperationMethod<CreateRoleRequest, CreateRoleResponse, CreateRoleError, AxiomOpContext>;
export type CreateStarredError = UnprocessableEntity | AxiomOpError;
export declare const createStarred: API.OperationMethod<CreateStarredRequest, CreateStarredResponse, CreateStarredError, AxiomOpContext>;
export type CreateUserError = BadRequest | UnprocessableEntity | AxiomOpError;
/** Create user */
export declare const createUser: API.OperationMethod<CreateUserRequest, User, CreateUserError, AxiomOpContext>;
export type CreateViewError = UnprocessableEntity | AxiomOpError;
export declare const createView: API.OperationMethod<CreateViewRequest, View, CreateViewError, AxiomOpContext>;
export type CreateVirtualFieldError = UnprocessableEntity | AxiomOpError;
export declare const createVirtualField: API.OperationMethod<CreateVirtualFieldRequest, CreateVirtualFieldResponse, CreateVirtualFieldError, AxiomOpContext>;
export type DeleteAnnotationError = BadRequest | NotFound | AxiomOpError;
/** Delete annotation */
export declare const deleteAnnotation: API.OperationMethod<DeleteAnnotationRequest, DeleteAnnotationResponse, DeleteAnnotationError, AxiomOpContext>;
export type DeleteAPITokenError = NotFound | AxiomOpError;
/** Delete API token */
export declare const deleteAPIToken: API.OperationMethod<DeleteAPITokenRequest, DeleteAPITokenResponse, DeleteAPITokenError, AxiomOpContext>;
export type DeleteDashboardError = NotFound | AxiomOpError;
/** Delete dashboard Delete a dashboard by UID. */
export declare const deleteDashboard: API.OperationMethod<DeleteDashboardRequest, DeleteDashboardResponse, DeleteDashboardError, AxiomOpContext>;
export type DeleteDatasetError = Forbidden | NotFound | AxiomOpError;
/** Delete dataset Delete dataset */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest, DeleteDatasetResponse, DeleteDatasetError, AxiomOpContext>;
export type DeleteGroupError = NotFound | AxiomOpError;
/** Delete group Permanently removes a group from the organization. */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest, DeleteGroupResponse, DeleteGroupError, AxiomOpContext>;
export type DeleteMapFieldError = NotFound | AxiomOpError;
export declare const deleteMapField: API.OperationMethod<DeleteMapFieldRequest, DeleteMapFieldResponse, DeleteMapFieldError, AxiomOpContext>;
export type DeleteMonitorError = NotFound | AxiomOpError;
/** Delete monitor */
export declare const deleteMonitor: API.OperationMethod<DeleteMonitorRequest, DeleteMonitorResponse, DeleteMonitorError, AxiomOpContext>;
export type DeleteNotifierError = NotFound | AxiomOpError;
/** Delete notifier */
export declare const deleteNotifier: API.OperationMethod<DeleteNotifierRequest, DeleteNotifierResponse, DeleteNotifierError, AxiomOpContext>;
export type DeleteRoleError = NotFound | AxiomOpError;
/** Delete role Permanently removes a role from the organization. */
export declare const deleteRole: API.OperationMethod<DeleteRoleRequest, DeleteRoleResponse, DeleteRoleError, AxiomOpContext>;
export type DeleteStarredError = NotFound | AxiomOpError;
export declare const deleteStarred: API.OperationMethod<DeleteStarredRequest, DeleteStarredResponse, DeleteStarredError, AxiomOpContext>;
export type DeleteViewError = NotFound | AxiomOpError;
export declare const deleteView: API.OperationMethod<DeleteViewRequest, DeleteViewResponse, DeleteViewError, AxiomOpContext>;
export type DeleteVirtualFieldError = NotFound | AxiomOpError;
export declare const deleteVirtualField: API.OperationMethod<DeleteVirtualFieldRequest, DeleteVirtualFieldResponse, DeleteVirtualFieldError, AxiomOpContext>;
export type GetAnnotationError = BadRequest | NotFound | AxiomOpError;
/** Get annotation by ID */
export declare const getAnnotation: API.OperationMethod<GetAnnotationRequest, Annotation, GetAnnotationError, AxiomOpContext>;
export type GetAnnotationsError = AxiomOpError;
/** Get annotations */
export declare const getAnnotations: API.OperationMethod<GetAnnotationsRequest, GetAnnotationsResponse, GetAnnotationsError, AxiomOpContext>;
export type GetAPITokenError = NotFound | AxiomOpError;
/** Get API token by ID */
export declare const getAPIToken: API.OperationMethod<GetAPITokenRequest, APIToken, GetAPITokenError, AxiomOpContext>;
export type GetAPITokensError = AxiomOpError;
/** Get API tokens */
export declare const getAPITokens: API.OperationMethod<GetAPITokensRequest, GetAPITokensResponse, GetAPITokensError, AxiomOpContext>;
export type GetCurrentUserError = AxiomOpError;
/** Get current user */
export declare const getCurrentUser: API.OperationMethod<GetCurrentUserRequest, User, GetCurrentUserError, AxiomOpContext>;
export type GetDashboardError = NotFound | AxiomOpError;
/** Get dashboard Get a dashboard by UID. */
export declare const getDashboard: API.OperationMethod<GetDashboardRequest, DashboardResource, GetDashboardError, AxiomOpContext>;
export type GetDatasetError = Forbidden | NotFound | AxiomOpError;
/** Get dataset by ID Get dataset by ID */
export declare const getDataset: API.OperationMethod<GetDatasetRequest, Dataset, GetDatasetError, AxiomOpContext>;
export type GetDatasetsError = Forbidden | AxiomOpError;
/** Get list of datasets Get list of datasets */
export declare const getDatasets: API.OperationMethod<GetDatasetsRequest, GetDatasetsResponse, GetDatasetsError, AxiomOpContext>;
export type GetFieldForDatasetError = NotFound | AxiomOpError;
export declare const getFieldForDataset: API.OperationMethod<GetFieldForDatasetRequest, DatasetField, GetFieldForDatasetError, AxiomOpContext>;
export type GetFieldsForDatasetError = Forbidden | NotFound | AxiomOpError;
export declare const getFieldsForDataset: API.OperationMethod<GetFieldsForDatasetRequest, GetFieldsForDatasetResponse, GetFieldsForDatasetError, AxiomOpContext>;
export type GetGroupByIdError = NotFound | AxiomOpError;
/** Get group by ID Retrieves detailed information about a specific group by its unique identifier. */
export declare const getGroupById: API.OperationMethod<GetGroupByIdRequest, GetGroupByIdResponse, GetGroupByIdError, AxiomOpContext>;
export type GetMapFieldsError = NotFound | AxiomOpError;
export declare const getMapFields: API.OperationMethod<GetMapFieldsRequest, GetMapFieldsResponse, GetMapFieldsError, AxiomOpContext>;
export type GetMonitorError = NotFound | AxiomOpError;
/** Retrieves detailed configuration for a specific monitor by its unique identifier */
export declare const getMonitor: API.OperationMethod<GetMonitorRequest, GetMonitorResponse, GetMonitorError, AxiomOpContext>;
export type GetMonitorHistoryError = NotFound | UnprocessableEntity | AxiomOpError;
/** Get monitor history */
export declare const getMonitorHistory: API.OperationMethod<GetMonitorHistoryRequest, GetMonitorHistoryResponse, GetMonitorHistoryError, AxiomOpContext>;
export type GetMonitorsError = AxiomOpError;
/** Lists all configured monitors. Returns an array of monitor configurations including their IDs and current status. */
export declare const getMonitors: API.OperationMethod<GetMonitorsRequest, GetMonitorsResponse, GetMonitorsError, AxiomOpContext>;
export type GetNotifierError = NotFound | AxiomOpError;
/** Retrieves detailed configuration for a specific notifier by its unique identifier */
export declare const getNotifier: API.OperationMethod<GetNotifierRequest, GetNotifierResponse, GetNotifierError, AxiomOpContext>;
export type GetNotifiersError = AxiomOpError;
/** Lists all configured notifiers. Returns an array of notification configurations including their IDs and current status. */
export declare const getNotifiers: API.OperationMethod<GetNotifiersRequest, GetNotifiersResponse, GetNotifiersError, AxiomOpContext>;
export type GetOrgError = NotFound | AxiomOpError;
export declare const getOrg: API.OperationMethod<GetOrgRequest, Org, GetOrgError, AxiomOpContext>;
export type GetOrgsError = AxiomOpError;
export declare const getOrgs: API.OperationMethod<GetOrgsRequest, GetOrgsResponse, GetOrgsError, AxiomOpContext>;
export type GetRoleByIdError = NotFound | AxiomOpError;
/** Get role by ID Retrieves detailed information about a specific role by its unique identifier. */
export declare const getRoleById: API.OperationMethod<GetRoleByIdRequest, GetRoleByIdResponse, GetRoleByIdError, AxiomOpContext>;
export type GetStarredError = NotFound | AxiomOpError;
export declare const getStarred: API.OperationMethod<GetStarredRequest, GetStarredResponse, GetStarredError, AxiomOpContext>;
export type GetStarredQueriesError = AxiomOpError;
export declare const getStarredQueries: API.OperationMethod<GetStarredQueriesRequest, GetStarredQueriesResponse, GetStarredQueriesError, AxiomOpContext>;
export type GetUserError = NotFound | AxiomOpError;
/** Get user by ID */
export declare const getUser: API.OperationMethod<GetUserRequest, User, GetUserError, AxiomOpContext>;
export type GetUsersError = AxiomOpError;
/** Get users */
export declare const getUsers: API.OperationMethod<GetUsersRequest, GetUsersResponse, GetUsersError, AxiomOpContext>;
export type GetViewError = NotFound | AxiomOpError;
export declare const getView: API.OperationMethod<GetViewRequest, View, GetViewError, AxiomOpContext>;
export type GetViewsError = AxiomOpError;
export declare const getViews: API.OperationMethod<GetViewsRequest, GetViewsResponse, GetViewsError, AxiomOpContext>;
export type GetVirtualFieldError = NotFound | AxiomOpError;
export declare const getVirtualField: API.OperationMethod<GetVirtualFieldRequest, GetVirtualFieldResponse, GetVirtualFieldError, AxiomOpContext>;
export type GetVirtualFieldsError = AxiomOpError;
export declare const getVirtualFields: API.OperationMethod<GetVirtualFieldsRequest, GetVirtualFieldsResponse, GetVirtualFieldsError, AxiomOpContext>;
export type ListDashboardsError = AxiomOpError;
/** List dashboards List dashboards visible to the caller. */
export declare const listDashboards: API.OperationMethod<ListDashboardsRequest, ListDashboardsResponse, ListDashboardsError, AxiomOpContext>;
export type ListGroupsError = AxiomOpError;
/** List all groups Retrieves all groups in the organization. */
export declare const listGroups: API.OperationMethod<ListGroupsRequest, ListGroupsResponse, ListGroupsError, AxiomOpContext>;
export type ListRolesError = AxiomOpError;
/** List all roles Retrieves all roles in the organization with their associated permissions and members. */
export declare const listRoles: API.OperationMethod<ListRolesRequest, ListRolesResponse, ListRolesError, AxiomOpContext>;
export type PatchDashboardChartError = BadRequest | NotFound | AxiomOpError;
/** Patch dashboard chart Patch a single chart in a dashboard by chart ID. */
export declare const patchDashboardChart: API.OperationMethod<PatchDashboardChartRequest, DashboardWriteResponse, PatchDashboardChartError, AxiomOpContext>;
export type ProvisionOrgError = AxiomOpError;
/** Provision a temporary organization for an agent Publicly provisions a temporary organization intended for automated agents. The organization is marked temporary with a TTL and is deleted automatically if it is not claimed before it expires. The response includes a claim URL that lets a human take ownership of the org. This endpoint is unauthenticated and strict rate limits apply. */
export declare const provisionOrg: API.OperationMethod<ProvisionOrgRequest, ProvisionOrgResponse, ProvisionOrgError, AxiomOpContext>;
export type RegenerateAPITokenError = NotFound | UnprocessableEntity | AxiomOpError;
/** Regenerate API token */
export declare const regenerateAPIToken: API.OperationMethod<RegenerateAPITokenRequest, RegenerateAPITokenResponse, RegenerateAPITokenError, AxiomOpContext>;
export type RemoveUserFromOrgError = NotFound | AxiomOpError;
/** Remove user from org */
export declare const removeUserFromOrg: API.OperationMethod<RemoveUserFromOrgRequest, RemoveUserFromOrgResponse, RemoveUserFromOrgError, AxiomOpContext>;
export type TrimDatasetError = Forbidden | NotFound | AxiomOpError;
/** Trim dataset by duration Trim dataset */
export declare const trimDataset: API.OperationMethod<TrimDatasetRequest, TrimDatasetResponse, TrimDatasetError, AxiomOpContext>;
export type UpdateAnnotationError = BadRequest | NotFound | UnprocessableEntity | AxiomOpError;
/** Update annotation */
export declare const updateAnnotation: API.OperationMethod<UpdateAnnotationRequest, Annotation, UpdateAnnotationError, AxiomOpContext>;
export type UpdateCurrentUserError = AxiomOpError;
/** Update current user */
export declare const updateCurrentUser: API.OperationMethod<UpdateCurrentUserRequest, User, UpdateCurrentUserError, AxiomOpContext>;
export type UpdateDashboardError = BadRequest | Conflict | AxiomOpError;
/** Update dashboard Update a dashboard by UID. */
export declare const updateDashboard: API.OperationMethod<UpdateDashboardRequest, DashboardWriteResponse, UpdateDashboardError, AxiomOpContext>;
export type UpdateDatasetError = Forbidden | NotFound | UnprocessableEntity | AxiomOpError;
/** Update dataset Update dataset */
export declare const updateDataset: API.OperationMethod<UpdateDatasetRequest, Dataset, UpdateDatasetError, AxiomOpContext>;
export type UpdateFieldForDatasetError = NotFound | UnprocessableEntity | AxiomOpError;
export declare const updateFieldForDataset: API.OperationMethod<UpdateFieldForDatasetRequest, DatasetField, UpdateFieldForDatasetError, AxiomOpContext>;
export type UpdateGroupError = NotFound | UnprocessableEntity | AxiomOpError;
/** Update group Updates an existing group's configuration. */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest, UpdateGroupResponse, UpdateGroupError, AxiomOpContext>;
export type UpdateMapFieldsError = NotFound | AxiomOpError;
export declare const updateMapFields: API.OperationMethod<UpdateMapFieldsRequest, UpdateMapFieldsResponse, UpdateMapFieldsError, AxiomOpContext>;
export type UpdateMonitorError = NotFound | UnprocessableEntity | AxiomOpError;
/** Update monitor */
export declare const updateMonitor: API.OperationMethod<UpdateMonitorRequest, UpdateMonitorResponse, UpdateMonitorError, AxiomOpContext>;
export type UpdateNotifierError = NotFound | UnprocessableEntity | AxiomOpError;
/** Update notifier */
export declare const updateNotifier: API.OperationMethod<UpdateNotifierRequest, UpdateNotifierResponse, UpdateNotifierError, AxiomOpContext>;
export type UpdateOrgError = NotFound | AxiomOpError;
export declare const updateOrg: API.OperationMethod<UpdateOrgRequest, Org, UpdateOrgError, AxiomOpContext>;
export type UpdateRoleError = NotFound | UnprocessableEntity | AxiomOpError;
/** Update role Updates an existing role's configuration including its permissions and member assignments. */
export declare const updateRole: API.OperationMethod<UpdateRoleRequest, UpdateRoleResponse, UpdateRoleError, AxiomOpContext>;
export type UpdateStarredError = NotFound | UnprocessableEntity | AxiomOpError;
export declare const updateStarred: API.OperationMethod<UpdateStarredRequest, UpdateStarredResponse, UpdateStarredError, AxiomOpContext>;
export type UpdateUserRoleError = NotFound | UnprocessableEntity | AxiomOpError;
/** Update user role */
export declare const updateUserRole: API.OperationMethod<UpdateUserRoleRequest, User, UpdateUserRoleError, AxiomOpContext>;
export type UpdateViewError = NotFound | UnprocessableEntity | AxiomOpError;
export declare const updateView: API.OperationMethod<UpdateViewRequest, View, UpdateViewError, AxiomOpContext>;
export type UpdateVirtualFieldError = NotFound | UnprocessableEntity | AxiomOpError;
export declare const updateVirtualField: API.OperationMethod<UpdateVirtualFieldRequest, UpdateVirtualFieldResponse, UpdateVirtualFieldError, AxiomOpContext>;
export type VacuumDatasetError = AxiomOpError;
export declare const vacuumDataset: API.OperationMethod<VacuumDatasetRequest, VacuumDatasetResponse, VacuumDatasetError, AxiomOpContext>;
//# sourceMappingURL=v2.d.ts.map