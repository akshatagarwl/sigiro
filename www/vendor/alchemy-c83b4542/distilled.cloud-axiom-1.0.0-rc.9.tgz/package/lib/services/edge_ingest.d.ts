import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type AxiomOpError, type AxiomOpContext } from "../protocol.ts";
export type { AxiomOpError, AxiomOpContext };
declare const BadRequest_base: S.Class<BadRequest, S.TaggedStruct<"BadRequest", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequest extends /*@__PURE__*/ BadRequest_base {
}
declare const NotFound_base: S.Class<NotFound, S.TaggedStruct<"NotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
declare const UnprocessableEntity_base: S.Class<UnprocessableEntity, S.TaggedStruct<"UnprocessableEntity", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntity extends /*@__PURE__*/ UnprocessableEntity_base {
}
export interface IngestToDatasetRequest {
    dataset_id: string;
    /** The name of the field to use as the timestamp. If not specified, the timestamp will be the time the event was received by Axiom. */
    timestamp_field?: string;
    /** The date-time format of the timestamp field. The reference time is `Mon Jan 2 15:04:05 -0700 MST 2006`, as specified in https://pkg.go.dev/time/?tab=doc#Parse */
    timestamp_format?: string;
    /** The delimiter to use when parsing CSV data. If not specified, the default delimiter is `,`. */
    csv_delimiter?: string;
    body: string;
}
export declare const IngestToDatasetRequest: S.Schema<IngestToDatasetRequest>;
export interface IngestFailure {
    error: string;
    timestamp: string;
}
export declare const IngestFailure: S.Schema<IngestFailure>;
export type IngestStatusFailuresList = Array<IngestFailure>;
export declare const IngestStatusFailuresList: S.Schema<IngestStatusFailuresList>;
export interface IngestStatus {
    blocksCreated: number;
    failed: number;
    failures?: IngestStatusFailuresList;
    ingested: number;
    processedBytes: number;
    walLength: number;
}
export declare const IngestStatus: S.Schema<IngestStatus>;
export type IngestToDatasetError = BadRequest | NotFound | UnprocessableEntity | AxiomOpError;
export declare const ingestToDataset: API.OperationMethod<IngestToDatasetRequest, IngestStatus, IngestToDatasetError, AxiomOpContext>;
//# sourceMappingURL=edge_ingest.d.ts.map