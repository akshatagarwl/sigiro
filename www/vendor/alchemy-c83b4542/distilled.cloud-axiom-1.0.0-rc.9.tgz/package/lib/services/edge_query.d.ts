import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type AxiomOpError, type AxiomOpContext } from "../protocol.ts";
export type { AxiomOpError, AxiomOpContext };
export type QueryAplRequestFormat = "legacy" | "tabular" | "tabular-rows";
export declare const QueryAplRequestFormat: any;
export interface QueryAplRequestDefaultOrderItem {
    desc?: boolean;
    field?: string;
}
export declare const QueryAplRequestDefaultOrderItem: S.Schema<QueryAplRequestDefaultOrderItem>;
/** The default order to use when no order is specified in the query. */
export type QueryAplRequestDefaultOrderList = Array<QueryAplRequestDefaultOrderItem>;
export declare const QueryAplRequestDefaultOrderList: S.Schema<QueryAplRequestDefaultOrderList>;
export type QueryAplRequestLibrariesList = Array<string>;
export declare const QueryAplRequestLibrariesList: S.Schema<QueryAplRequestLibrariesList>;
export interface QueryOptions {
    against?: string;
    againstStart?: string;
    againstTimestamp?: string;
    aggChartOpts?: string;
    caseSensitive?: string;
    containsTimeFilter?: string;
    datasets?: string;
    displayNull?: string;
    editorContent?: string;
    endColumn?: string;
    endLineNumber?: string;
    endTime?: string;
    integrationsFilter?: string;
    nanosecondPrecision?: string;
    openIntervals?: string;
    overlayCharts?: string;
    queryObject?: string;
    quickRange?: string;
    resolution?: string;
    resultsHistogram?: string;
    selection?: string;
    shownColumns?: string;
    startColumn?: string;
    startLineNumber?: string;
    startTime?: string;
    timeSeriesVariant?: string;
    timeSeriesView?: string;
}
export declare const QueryOptions: S.Schema<QueryOptions>;
/** Variables is an optional set of additional variables that are inserted into the APL */
export type QueryAplRequestVariablesMap = {
    [key: string]: unknown | undefined;
};
export declare const QueryAplRequestVariablesMap: S.Schema<QueryAplRequestVariablesMap>;
export interface QueryAplRequest {
    format: QueryAplRequestFormat | (string & {});
    nocache?: boolean;
    saveAsKind?: string;
    /** when saveAsKind is true, this parameter indicates the id of the associated dataset */
    id?: string;
    streaming_duration?: string;
    /** contains the source of the APL query (for example console, dashboard, etc.) */
    apl_source?: string;
    /** contains the id of the source, for example dashboard_id */
    apl_source_id?: string;
    /** Include a totals table (only supported in MetricsDB) */
    totals?: boolean;
    /** APL query string */
    apl: string;
    /** Pagination cursor */
    cursor?: string;
    /** The default limit to use when no limit is specified in the query. */
    defaultLimit?: number;
    /** The default order to use when no order is specified in the query. */
    defaultOrder?: QueryAplRequestDefaultOrderList;
    /** End time for the query range */
    endTime?: string;
    /** Include cursor in response */
    includeCursor?: boolean;
    /** Defines if the _cursor field should be projected in the result */
    includeCursorField?: boolean;
    libraries?: QueryAplRequestLibrariesList;
    /** Maximum number of groups to automatically bin into */
    maxBinAutoGroups?: number;
    queryOptions?: QueryOptions;
    /** start and end time for the query, these must be specified as RFC3339 strings or using relative time expressions (e.g. now-1h, now-1d, now-1w, etc) */
    startTime?: string;
    /** Variables is an optional set of additional variables that are inserted into the APL */
    variables?: QueryAplRequestVariablesMap;
}
export declare const QueryAplRequest: S.Schema<QueryAplRequest>;
export type QueryAplResponse = unknown;
export declare const QueryAplResponse: S.Schema<QueryAplResponse>;
export type QueryAplError = AxiomOpError;
export declare const queryApl: API.OperationMethod<QueryAplRequest, QueryAplResponse, QueryAplError, AxiomOpContext>;
//# sourceMappingURL=edge_query.d.ts.map