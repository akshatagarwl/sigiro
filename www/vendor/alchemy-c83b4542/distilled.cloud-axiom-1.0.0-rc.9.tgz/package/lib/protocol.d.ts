import type * as Layer from "effect/Layer";
import type * as HttpClient from "effect/unstable/http/HttpClient";
import type * as HttpClientError from "effect/unstable/http/HttpClientError";
import type * as API from "@distilled.cloud/core/api";
import type { API_ERRORS, ConfigError } from "@distilled.cloud/core/errors";
import { Credentials } from "./credentials.ts";
import { UnknownAxiomError } from "./errors.ts";
/**
 * Error channel shared by every generated Axiom operation. Generated service
 * files annotate operations with `API.OperationMethod<I, O, AxiomOpError,
 * AxiomOpContext>` explicitly so the compiler never infers these back out of
 * the schema generics.
 */
export type AxiomOpError = InstanceType<(typeof API_ERRORS)[number]> | UnknownAxiomError | ConfigError | HttpClientError.HttpClientError;
/** Context (requirements) shared by every generated Axiom operation. */
export type AxiomOpContext = Credentials | HttpClient.HttpClient;
/**
 * Axiom's backend (Go) serializes nil slices and omitted optional fields as
 * JSON `null`. The generated output schemas model these as optional members
 * (value or absent), so `null` trips decoding. Recursively drop explicit
 * `null` properties before decoding so optional fields are treated as
 * absent. Keys that are genuinely nullable in the API are patched to
 * nullable in the spec — this hook exists for the far more common "Go nil
 * slice" case.
 */
export declare const stripNulls: (value: unknown) => unknown;
export declare const AxiomProtocol: Layer.Layer<API.Protocol>;
//# sourceMappingURL=protocol.d.ts.map