import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
/** Default base URL for Axiom Cloud. Self-hosted users can override via AXIOM_URL. */
export declare const DEFAULT_API_BASE_URL = "https://api.axiom.co";
export interface Config {
    readonly apiKey: Redacted.Redacted<string>;
    readonly apiBaseUrl: string;
    /**
     * Optional organization ID. Required when authenticating with a Personal
     * Access Token (PAT); optional for API tokens scoped to a single org.
     * Sent on every request as the `X-Axiom-Org-ID` header when set.
     */
    readonly orgId?: string;
}
declare const Credentials_base: Context.ServiceClass<Credentials, "AxiomCredentials", Effect.Effect<Config, never, never>>;
export declare class Credentials extends Credentials_base {
}
/** Layer from a plain API token + optional base URL / org ID. */
export declare const fromApiKey: (config: {
    readonly apiKey: string | Redacted.Redacted<string>;
    readonly apiBaseUrl?: string;
    readonly orgId?: string;
}) => Layer.Layer<Credentials>;
/**
 * Build {@link Credentials} from environment variables.
 *
 * - `AXIOM_TOKEN` or `AXIOM_API_KEY` (required) — Axiom API token or PAT.
 * - `AXIOM_URL` (optional) — override the API base URL (for self-hosted or
 *   regional edge deployments). Defaults to `https://api.axiom.co`.
 * - `AXIOM_ORG_ID` (optional) — organization ID, required for PATs.
 */
export declare const CredentialsFromEnv: Layer.Layer<Credentials>;
export {};
//# sourceMappingURL=credentials.d.ts.map