import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
/**
 * Machines API host. The generated Machines routes carry the `/v1` prefix
 * (`/v1/apps/{app_name}/machines`), as the upstream OpenAPI spells them, so
 * the base URL must not.
 */
export declare const DEFAULT_API_BASE_URL = "https://api.machines.dev";
/** UI-EX REST + GraphQL host (MPG, Tigris, Redis). Not overridable via an invented env var. */
export declare const DEFAULT_FLY_API_BASE_URL = "https://api.fly.io";
/** Sprites REST root. Auth is a bearer minted from `FLY_API_TOKEN` — never `SPRITES_TOKEN`. */
export declare const DEFAULT_SPRITES_API_BASE_URL = "https://api.sprites.dev/v1";
/**
 * Normalize a Fly API hostname into the Machines API base URL.
 *
 * - unset / empty → `https://api.machines.dev`
 * - trailing slashes stripped
 * - a trailing `/v1` is dropped: `flyctl` and older consumers set
 *   `FLY_API_HOSTNAME` to the `/v1` root, and the routes already carry it
 */
export declare const normalizeApiBaseUrl: (hostname?: string) => string;
export interface Config {
    readonly apiKey: Redacted.Redacted<string>;
    readonly apiBaseUrl: string;
}
declare const Credentials_base: Context.ServiceClass<Credentials, "Fly-ioCredentials", Effect.Effect<Config, never, never>>;
export declare class Credentials extends Credentials_base {
}
export declare const CredentialsFromEnv: Layer.Layer<Credentials, never, never>;
/** Convenience layer from a plain API token + optional base URL. */
export declare const credentials: (config: {
    readonly apiKey: string;
    readonly apiBaseUrl?: string;
}) => Layer.Layer<Credentials>;
export {};
//# sourceMappingURL=credentials.d.ts.map