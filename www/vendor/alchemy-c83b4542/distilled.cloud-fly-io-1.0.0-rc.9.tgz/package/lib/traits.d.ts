export { Body, Header, Query, Label, Http, ResponseCode, HttpBody, FormDataFile, KeyDictionary, UnionCases, applyErrorMatchers, getErrorMatchers, type HttpTrait, type ErrorMatcher, bodySymbol, headerSymbol, querySymbol, labelSymbol, httpSymbol, responseCodeSymbol, httpBodySymbol, formDataFileSymbol, keyDictionarySymbol, unionCasesSymbol, errorMatchersSymbol, } from "@distilled.cloud/core/trait";
export { RawResponse, RawResponseRoot, SensitiveValue, rawResponseSymbol, rawResponseRootSymbol, sensitiveValueSymbol, } from "@distilled.cloud/core/protocol-rest";
/**
 * The baked GraphQL document for one add-on operation. The protocol wraps
 * the operation's input as `{ query, operationName, variables }`.
 */
export interface GraphQLOpTrait {
    readonly query: string;
    readonly operationName: string;
    readonly type: "query" | "mutation";
}
export declare const graphqlOpSymbol: unique symbol;
/** Marks an operation input with its GraphQL document (`com.flyio.graphql#operation`). */
export declare const GraphQLOp: (op: GraphQLOpTrait) => import("@distilled.cloud/core/trait").Annotation;
export declare const responsePathSymbol: unique symbol;
/** Dotted path under GraphQL `data` (`com.flyio.graphql#responsePath`). */
export declare const ResponsePath: (path: string) => import("@distilled.cloud/core/trait").Annotation;
export declare const graphqlPayloadRootSymbol: unique symbol;
/** Marks a response whose entire value is `data.<responsePath>`. */
export declare const GraphQLPayloadRoot: () => import("@distilled.cloud/core/trait").Annotation;
//# sourceMappingURL=traits.d.ts.map