/**
 * Fly.io-specific error types.
 *
 * Re-exports common HTTP errors from sdk-core and adds the Fly.io-specific
 * fallback/parse error types. Fly.io's error model is a pure HTTP-status
 * map: the API answers failures with `{ "error": "..." }` and the protocol
 * maps the status onto the shared core classes (BadRequest / Forbidden /
 * NotFound / Conflict / UnprocessableEntity / ...).
 */
export { BadGateway, BadRequest, Conflict, ConfigError, Forbidden, GatewayTimeout, InternalServerError, Locked, NotFound, ServiceUnavailable, TooManyRequests, Unauthorized, UnprocessableEntity, HTTP_STATUS_MAP, DEFAULT_ERRORS, API_ERRORS, } from "@distilled.cloud/core/errors";
import type { DefaultErrors as CoreDefaultErrors } from "@distilled.cloud/core/errors";
import * as Schema from "effect/Schema";
declare const UnknownFlyIoError_base: Schema.Class<UnknownFlyIoError, Schema.TaggedStruct<"UnknownFlyIoError", {
    readonly code: Schema.optional<Schema.String>;
    readonly message: Schema.optional<Schema.String>;
    readonly body: Schema.Unknown;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
/**
 * Unknown Fly.io error — returned when a failure matches no status-mapped
 * error class. Carries the raw body for later cataloging.
 */
export declare class UnknownFlyIoError extends UnknownFlyIoError_base {
}
declare const FlyIoParseError_base: Schema.Class<FlyIoParseError, Schema.TaggedStruct<"FlyIoParseError", {
    readonly body: Schema.Unknown;
    readonly cause: Schema.Unknown;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ParseError: true;
    };
});
/** Schema parse error wrapper. */
export declare class FlyIoParseError extends FlyIoParseError_base {
}
declare const SpritesNotEnabled_base: Schema.Class<SpritesNotEnabled, Schema.TaggedStruct<"SpritesNotEnabled", {
    readonly code: Schema.optional<Schema.Int>;
    readonly message: Schema.optional<Schema.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
/**
 * Sprites is not enabled for the Fly organization that owns `FLY_API_TOKEN`.
 *
 * Returned by `POST /v1/organizations/{org}/tokens` as HTTP 401 with a
 * message matching `sprites not enabled`. Sprite CRUD never sees a
 * `SPRITES_TOKEN` — this is the mint-time entitlement signal.
 */
export declare class SpritesNotEnabled extends SpritesNotEnabled_base {
}
declare const CreateExtensionTosAgreementNotAuthorized_base: Schema.Class<CreateExtensionTosAgreementNotAuthorized, Schema.TaggedStruct<"CreateExtensionTosAgreementNotAuthorized", {
    readonly code: Schema.optional<Schema.Int>;
    readonly message: Schema.optional<Schema.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
/**
 * The Fly token cannot record add-on provider ToS agreement
 * (`createExtensionTosAgreement`). GraphQL returns this as a 200
 * with `Not authorized to access this createextensiontosagreement`.
 */
export declare class CreateExtensionTosAgreementNotAuthorized extends CreateExtensionTosAgreementNotAuthorized_base {
}
/**
 * Errors any Fly.io operation may surface in addition to the status-mapped
 * per-operation errors.
 */
export type ClientErrors = UnknownFlyIoError | FlyIoParseError;
/**
 * Default Fly.io operation errors: the shared HTTP status errors from core
 * plus the client-level fallback/decode errors.
 */
export type DefaultErrors = CoreDefaultErrors | ClientErrors;
//# sourceMappingURL=errors.d.ts.map