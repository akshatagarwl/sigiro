/**
 * Fly.io protocols — Machines REST, UI-EX REST (MPG), GraphQL add-ons, and
 * Sprites REST.
 *
 * Machines (`FlyIoProtocol`) is a plain bearer-token JSON API at
 * `api.machines.dev` (routes carry the `/v1` prefix). MPG (`FlyApiProtocol`) is the same token against
 * `https://api.fly.io`. GraphQL add-ons (`FlyGraphqlProtocol`) POST
 * `{ query, operationName, variables }` to `https://api.fly.io/graphql`.
 *
 * Sprites (`SpritesProtocol`) also resolve `FLY_API_TOKEN` (same
 * {@link Credentials} as Machines). Sprite CRUD rejects a Fly macaroon as
 * Bearer, so the protocol mints a Sprites bearer once:
 *
 *   POST https://api.sprites.dev/v1/organizations/{org}/tokens
 *   Authorization: FlyV1 {FLY_API_TOKEN}
 *
 * Org slug comes from Machines `GET /tokens/current` (GraphQL fallback).
 * The minted token is cached process-wide, then sent as
 * `Authorization: Bearer` on sprite ops. There is no `SPRITES_TOKEN`.
 */
import * as Context from "effect/Context";
import * as Layer from "effect/Layer";
import * as HttpClient from "effect/unstable/http/HttpClient";
import type * as HttpClientError from "effect/unstable/http/HttpClientError";
import * as API from "@distilled.cloud/core/api";
import { type ConfigError } from "@distilled.cloud/core/errors";
import { Credentials } from "./credentials.ts";
import { CreateExtensionTosAgreementNotAuthorized, SpritesNotEnabled, type DefaultErrors } from "./errors.ts";
/**
 * Error channel shared by every generated Fly.io operation. Generated
 * service files annotate operations with `API.OperationMethod<I, O,
 * FlyIoOpError, FlyIoOpContext>` explicitly so the compiler never infers
 * these back out of the schema generics.
 */
export type FlyIoOpError = DefaultErrors | ConfigError | CreateExtensionTosAgreementNotAuthorized | HttpClientError.HttpClientError;
/** Context (requirements) shared by Machines / MPG / GraphQL operations. */
export type FlyIoOpContext = Credentials | HttpClient.HttpClient;
/**
 * Sprites operations resolve {@link Credentials} (`FLY_API_TOKEN`) and mint
 * a Sprites bearer. {@link SpritesNotEnabled} surfaces from that mint.
 */
export type SpritesOpError = FlyIoOpError | SpritesNotEnabled;
export type SpritesOpContext = FlyIoOpContext;
declare const MachineIdentity_base: Context.ServiceClass<MachineIdentity, "FlyIoMachineIdentity", true>;
/**
 * Per-call signal that this Machines request is the Fly Machine itself
 * (unix socket `/.fly/api`). Org tokens stay on {@link Credentials} for
 * GetSecret in the same process; this service only changes headers:
 * omit `Authorization`, send `Connection: close`.
 */
export declare class MachineIdentity extends MachineIdentity_base {
}
export declare const FlyIoProtocol: Layer.Layer<API.Protocol>;
/** MPG UI-EX REST at `https://api.fly.io` with the Machines bearer token. */
export declare const FlyApiProtocol: Layer.Layer<API.Protocol>;
/** Sprites REST at `https://api.sprites.dev/v1`, minted from `FLY_API_TOKEN`. */
export declare const SpritesProtocol: Layer.Layer<API.Protocol>;
export declare const FlyGraphqlProtocol: Layer.Layer<API.Protocol>;
export {};
//# sourceMappingURL=protocol.d.ts.map