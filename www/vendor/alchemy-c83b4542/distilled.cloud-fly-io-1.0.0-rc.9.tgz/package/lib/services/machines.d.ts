import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type FlyIoOpError, type FlyIoOpContext } from "../protocol.ts";
import { BadRequest, Conflict, Forbidden, GatewayTimeout, NotFound, UnprocessableEntity } from "../errors.ts";
export type { FlyIoOpError, FlyIoOpContext };
export interface AuthenticateTokenRequest {
    header?: string;
}
export declare const AuthenticateTokenRequest: S.Schema<AuthenticateTokenRequest>;
export type MacaroonCaveatSetCaveatsList = Array<unknown>;
export declare const MacaroonCaveatSetCaveatsList: S.Schema<MacaroonCaveatSetCaveatsList>;
export interface MacaroonCaveatSet {
    caveats?: MacaroonCaveatSetCaveatsList;
}
export declare const MacaroonCaveatSet: S.Schema<MacaroonCaveatSet>;
export type MacaroonNonceKidList = Array<number>;
export declare const MacaroonNonceKidList: S.Schema<MacaroonNonceKidList>;
export type MacaroonNonceRndList = Array<number>;
export declare const MacaroonNonceRndList: S.Schema<MacaroonNonceRndList>;
export interface MacaroonNonce {
    kid?: MacaroonNonceKidList;
    proof?: boolean;
    rnd?: MacaroonNonceRndList;
}
export declare const MacaroonNonce: S.Schema<MacaroonNonce>;
export type RootVerifiedTokenPermissionTokenList = Array<number>;
export declare const RootVerifiedTokenPermissionTokenList: S.Schema<RootVerifiedTokenPermissionTokenList>;
export interface RootVerifiedToken {
    caveats?: MacaroonCaveatSet;
    header?: string;
    nonce?: MacaroonNonce;
    permission_token?: RootVerifiedTokenPermissionTokenList;
}
export declare const RootVerifiedToken: S.Schema<RootVerifiedToken>;
export type AuthenticateTokenResponseBodyList = Array<RootVerifiedToken>;
export declare const AuthenticateTokenResponseBodyList: S.Schema<AuthenticateTokenResponseBodyList>;
export type AuthenticateTokenResponse = AuthenticateTokenResponseBodyList;
export declare const AuthenticateTokenResponse: S.Schema<AuthenticateTokenResponse>;
export type RessetAction = 1 | 2 | 4 | 8 | 16 | 31 | 0;
export declare const RessetAction: any;
/** Command is the command being executed on a machine. If this is specified, the Machine must be set. */
export type MainTokenAccessCommandList = Array<string>;
export declare const MainTokenAccessCommandList: S.Schema<MainTokenAccessCommandList>;
export interface MainTokenAccess {
    /** Action is the action being taken on the specified resource. This is the combination of individual action characters (e.g "rw") - r: read - w: write - c: create - d: delete - C: control */
    action?: RessetAction | (number & {});
    /** AppFeature is a named set of functionality associated with the app. If this is specified, the AppName field must be set. - images: images in the fly.io registry */
    app_feature?: string;
    /** AppName is the name of the app being accessed. */
    app_name?: string;
    /** Command is the command being executed on a machine. If this is specified, the Machine must be set. */
    command?: MainTokenAccessCommandList;
    /** MachineFeature is a named set of functionality associated with the machine. If this is specified, the Machine field must be set. - metadata: machine metadata service - oidc: OIDC tokens - kmstoken: Petsem tokens for KMS access */
    machine_feature?: string;
    /** MachineID is the ID of the machine being accessed (e.g. 7811701f564258). */
    machine_id?: string;
    /** Mutation is the GraphQL mutation being performed. */
    mutation?: string;
    /** OrgFeature is a named set of functionality associated with the organization. If this is specified, the OrgSlug field must be set. - wg: WireGuard peers - builder: remote builders - addon: addons - membership: organization membership - billing: billing - litefs-cloud: LiteFS Cloud - authentication: authentication settings */
    org_feature?: string;
    /** OrgSlug is the slug of the organization being accessed. */
    org_slug?: string;
    /** SourceMachine is the machine ID of the actor attempting access. */
    source_machine?: string;
    /** StorageObject is the storage object being accessed. If this is specified, the OrgSlug must be set. */
    storage_object?: string;
    /** VolumeID is the encoded ID of the volume being accessed (e.g. vol_r1p6pln1k9m9j7zr). */
    volume_id?: string;
}
export declare const MainTokenAccess: S.Schema<MainTokenAccess>;
export interface AuthorizeTokenRequest {
    access?: MainTokenAccess;
    header?: string;
}
export declare const AuthorizeTokenRequest: S.Schema<AuthorizeTokenRequest>;
export type FlyioAccessCommandList = Array<string>;
export declare const FlyioAccessCommandList: S.Schema<FlyioAccessCommandList>;
export interface FlyioAccess {
    action?: RessetAction;
    app_feature?: string;
    appid?: number;
    cluster?: string;
    command?: FlyioAccessCommandList;
    feature?: string;
    machine?: string;
    machine_feature?: string;
    mutation?: string;
    orgid?: number;
    sourceApp?: string;
    sourceMachine?: string;
    sourceOrganization?: string;
    storage_object?: string;
    volume?: string;
}
export declare const FlyioAccess: S.Schema<FlyioAccess>;
export interface AuthorizeResponse {
    access?: FlyioAccess;
    verified_token?: RootVerifiedToken;
}
export declare const AuthorizeResponse: S.Schema<AuthorizeResponse>;
export interface CheckAppCertificateRequest {
    /** Fly App Name */
    app_name: string;
    /** Certificate Hostname */
    hostname: string;
}
export declare const CheckAppCertificateRequest: S.Schema<CheckAppCertificateRequest>;
export type IssuedCertificateType = "rsa" | "ecdsa";
export declare const IssuedCertificateType: any;
export interface IssuedCertificate {
    certificate_authority?: string;
    expires_at?: string;
    type?: IssuedCertificateType;
}
export declare const IssuedCertificate: S.Schema<IssuedCertificate>;
export type CertificateEntryIssuedList = Array<IssuedCertificate>;
export declare const CertificateEntryIssuedList: S.Schema<CertificateEntryIssuedList>;
export type CertificateEntrySource = "custom" | "fly";
export declare const CertificateEntrySource: any;
export type CertificateEntryStatus = "active" | "pending_ownership" | "pending_validation";
export declare const CertificateEntryStatus: any;
export interface CertificateEntry {
    created_at?: string;
    expires_at?: string;
    issued?: CertificateEntryIssuedList;
    issuer?: string;
    source?: CertificateEntrySource;
    status?: CertificateEntryStatus;
}
export declare const CertificateEntry: S.Schema<CertificateEntry>;
export type CertificateCheckResponseCertificatesList = Array<CertificateEntry>;
export declare const CertificateCheckResponseCertificatesList: S.Schema<CertificateCheckResponseCertificatesList>;
export type DNSRecordsAList = Array<string>;
export declare const DNSRecordsAList: S.Schema<DNSRecordsAList>;
export type DNSRecordsAaaaList = Array<string>;
export declare const DNSRecordsAaaaList: S.Schema<DNSRecordsAaaaList>;
export type DNSRecordsCnameList = Array<string>;
export declare const DNSRecordsCnameList: S.Schema<DNSRecordsCnameList>;
export type DNSRecordsResolvedAddressesList = Array<string>;
export declare const DNSRecordsResolvedAddressesList: S.Schema<DNSRecordsResolvedAddressesList>;
export interface DNSRecords {
    a?: DNSRecordsAList;
    aaaa?: DNSRecordsAaaaList;
    acme_challenge_cname?: string;
    cname?: DNSRecordsCnameList;
    ownership_txt?: string;
    resolved_addresses?: DNSRecordsResolvedAddressesList;
    soa?: string;
}
export declare const DNSRecords: S.Schema<DNSRecords>;
export type DNSRequirementsAList = Array<string>;
export declare const DNSRequirementsAList: S.Schema<DNSRequirementsAList>;
export type DNSRequirementsAaaaList = Array<string>;
export declare const DNSRequirementsAaaaList: S.Schema<DNSRequirementsAaaaList>;
export interface AcmeChallenge {
    name?: string;
    target?: string;
}
export declare const AcmeChallenge: S.Schema<AcmeChallenge>;
export interface OwnershipVerification {
    app_value?: string;
    name?: string;
    org_value?: string;
}
export declare const OwnershipVerification: S.Schema<OwnershipVerification>;
export interface DNSRequirements {
    a?: DNSRequirementsAList;
    aaaa?: DNSRequirementsAaaaList;
    acme_challenge?: AcmeChallenge;
    cname?: string;
    ownership?: OwnershipVerification;
}
export declare const DNSRequirements: S.Schema<DNSRequirements>;
export interface CertificateValidation {
    alpn_configured?: boolean;
    dns_configured?: boolean;
    http_configured?: boolean;
    ownership_txt_configured?: boolean;
}
export declare const CertificateValidation: S.Schema<CertificateValidation>;
export interface CertificateValidationError {
    code?: string;
    message?: string;
    remediation?: string;
    timestamp?: string;
}
export declare const CertificateValidationError: S.Schema<CertificateValidationError>;
export type CertificateCheckResponseValidationErrorsList = Array<CertificateValidationError>;
export declare const CertificateCheckResponseValidationErrorsList: S.Schema<CertificateCheckResponseValidationErrorsList>;
export interface CertificateCheckResponse {
    acme_requested?: boolean;
    certificates?: CertificateCheckResponseCertificatesList;
    configured?: boolean;
    dns_provider?: string;
    dns_records?: DNSRecords;
    dns_requirements?: DNSRequirements;
    hostname?: string;
    rate_limited_until?: string;
    status?: string;
    validation?: CertificateValidation;
    validation_errors?: CertificateCheckResponseValidationErrorsList;
}
export declare const CertificateCheckResponse: S.Schema<CertificateCheckResponse>;
export interface CordonMachineRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
}
export declare const CordonMachineRequest: S.Schema<CordonMachineRequest>;
export interface CordonMachineResponse {
}
export declare const CordonMachineResponse: S.Schema<CordonMachineResponse>;
export interface CreateAppRequest {
    enable_subdomains?: boolean;
    name?: string;
    network?: string;
    org_slug?: string;
}
export declare const CreateAppRequest: S.Schema<CreateAppRequest>;
export interface CreateAppResponse {
}
export declare const CreateAppResponse: S.Schema<CreateAppResponse>;
export interface CreateAppAcmeCertificateRequest {
    /** Fly App Name */
    app_name: string;
    hostname?: string;
}
export declare const CreateAppAcmeCertificateRequest: S.Schema<CreateAppAcmeCertificateRequest>;
export type CertificateDetailCertificatesList = Array<CertificateEntry>;
export declare const CertificateDetailCertificatesList: S.Schema<CertificateDetailCertificatesList>;
export type CertificateDetailValidationErrorsList = Array<CertificateValidationError>;
export declare const CertificateDetailValidationErrorsList: S.Schema<CertificateDetailValidationErrorsList>;
export interface CertificateDetail {
    acme_requested?: boolean;
    certificates?: CertificateDetailCertificatesList;
    configured?: boolean;
    dns_provider?: string;
    dns_requirements?: DNSRequirements;
    hostname?: string;
    rate_limited_until?: string;
    status?: string;
    validation?: CertificateValidation;
    validation_errors?: CertificateDetailValidationErrorsList;
}
export declare const CertificateDetail: S.Schema<CertificateDetail>;
export interface CreateAppCustomCertificateRequest {
    /** Fly App Name */
    app_name: string;
    fullchain?: string;
    hostname?: string;
    private_key?: string;
}
export declare const CreateAppCustomCertificateRequest: S.Schema<CreateAppCustomCertificateRequest>;
export interface CreateAppDeployTokenRequest {
    /** Fly App Name */
    app_name: string;
    expiry?: string;
}
export declare const CreateAppDeployTokenRequest: S.Schema<CreateAppDeployTokenRequest>;
export interface CreateAppDeployTokenResponse {
    token?: string;
}
export declare const CreateAppDeployTokenResponse: S.Schema<CreateAppDeployTokenResponse>;
/** Type of IP address to allocate. "egress-pair" allocates both v4 and v6 egress IP addresses (recommended when using egress IPs). */
export type IPAssignmentType = "v4" | "v6" | "shared_v4" | "private_v6" | "egress_v4" | "egress_v6" | "egress_pair";
export declare const IPAssignmentType: any;
export interface CreateAppIPAssignmentRequest {
    /** Fly App Name */
    app_name: string;
    network?: string;
    org_slug?: string;
    region?: string;
    service_name?: string;
    type?: IPAssignmentType | (string & {});
}
export declare const CreateAppIPAssignmentRequest: S.Schema<CreateAppIPAssignmentRequest>;
export interface IPPair {
    v4?: string;
    v6?: string;
}
export declare const IPPair: S.Schema<IPPair>;
export interface AssignIPResponse {
    created_at?: string;
    egress?: boolean;
    ip?: string;
    /** ip_pair is returned when "egress-pair" IP type is requested; in this case, ip is null. */
    ip_pair?: IPPair;
    region?: string;
    service_name?: string;
    shared?: boolean;
}
export declare const AssignIPResponse: S.Schema<AssignIPResponse>;
export interface FlyMachineCacheDrive {
    size_mb?: number;
}
export declare const FlyMachineCacheDrive: S.Schema<FlyMachineCacheDrive>;
/** The header value */
export type FlyMachineHTTPHeaderValuesList = Array<string>;
export declare const FlyMachineHTTPHeaderValuesList: S.Schema<FlyMachineHTTPHeaderValuesList>;
/** For http checks, an array of objects with string field Name and array of strings field Values. The key/value pairs specify header and header values that will get passed with the check call. */
export interface FlyMachineHTTPHeader {
    /** The header name */
    name?: string;
    /** The header value */
    values?: FlyMachineHTTPHeaderValuesList;
}
export declare const FlyMachineHTTPHeader: S.Schema<FlyMachineHTTPHeader>;
export type FlyMachineCheckHeadersList = Array<FlyMachineHTTPHeader>;
export declare const FlyMachineCheckHeadersList: S.Schema<FlyMachineCheckHeadersList>;
/** Kind of the check (informational, readiness) */
export type FlyMachineCheckKind = "informational" | "readiness";
export declare const FlyMachineCheckKind: any;
export interface FlyMachineCheck {
    /** The time to wait after a VM starts before checking its health */
    grace_period?: string;
    headers?: FlyMachineCheckHeadersList;
    /** The time between connectivity checks */
    interval?: string;
    /** Kind of the check (informational, readiness) */
    kind?: FlyMachineCheckKind | (string & {});
    /** For http checks, the HTTP method to use to when making the request */
    method?: string;
    /** For http checks, the path to send the request to */
    path?: string;
    /** The port to connect to, often the same as internal_port */
    port?: number;
    /** For http checks, whether to use http or https */
    protocol?: string;
    /** The maximum time a connection can take before being reported as failing its health check */
    timeout?: string;
    /** If the protocol is https, the hostname to use for TLS certificate validation */
    tls_server_name?: string;
    /** For http checks with https protocol, whether or not to verify the TLS certificate */
    tls_skip_verify?: boolean;
    /** tcp or http */
    type?: string;
}
export declare const FlyMachineCheck: S.Schema<FlyMachineCheck>;
/** An optional object that defines one or more named top-level checks. The key for each check is the check name. */
export type FlyMachineConfigChecksMap = {
    [key: string]: FlyMachineCheck | undefined;
};
export declare const FlyMachineConfigChecksMap: S.Schema<FlyMachineConfigChecksMap>;
/** CmdOverride is used to override the default command of the image. */
export type FlyContainerConfigCmdList = Array<string>;
export declare const FlyContainerConfigCmdList: S.Schema<FlyContainerConfigCmdList>;
export type FlyContainerDependencyCondition = "exited_successfully" | "healthy" | "started";
export declare const FlyContainerDependencyCondition: any;
export interface FlyContainerDependency {
    condition?: FlyContainerDependencyCondition | (string & {});
    name?: string;
}
export declare const FlyContainerDependency: S.Schema<FlyContainerDependency>;
/** DependsOn can be used to define dependencies between containers. The container will only be started after all of its dependent conditions have been satisfied. */
export type FlyContainerConfigDependsOnList = Array<FlyContainerDependency>;
export declare const FlyContainerConfigDependsOnList: S.Schema<FlyContainerConfigDependsOnList>;
/** EntrypointOverride is used to override the default entrypoint of the image. */
export type FlyContainerConfigEntrypointList = Array<string>;
export declare const FlyContainerConfigEntrypointList: S.Schema<FlyContainerConfigEntrypointList>;
/** ExtraEnv is used to add additional environment variables to the container. */
export type FlyContainerConfigEnvMap = {
    [key: string]: string | undefined;
};
export declare const FlyContainerConfigEnvMap: S.Schema<FlyContainerConfigEnvMap>;
/** FieldRef selects a field of the Machine: supports id, version, app_name, private_ip, region, image. */
export type FlyEnvFromFieldRef = "id" | "version" | "app_name" | "private_ip" | "region" | "image";
export declare const FlyEnvFromFieldRef: any;
/** EnvVar defines an environment variable to be populated from a machine field, env_var */
export interface FlyEnvFrom {
    /** EnvVar is required and is the name of the environment variable that will be set from the secret. It must be a valid environment variable name. */
    env_var?: string;
    /** FieldRef selects a field of the Machine: supports id, version, app_name, private_ip, region, image. */
    field_ref?: FlyEnvFromFieldRef | (string & {});
}
export declare const FlyEnvFrom: S.Schema<FlyEnvFrom>;
/** EnvFrom can be provided to set environment variables from machine fields. */
export type FlyContainerConfigEnvFromList = Array<FlyEnvFrom>;
export declare const FlyContainerConfigEnvFromList: S.Schema<FlyContainerConfigEnvFromList>;
/** Image Config overrides - these fields are used to override the image configuration. If not provided, the image configuration will be used. ExecOverride is used to override the default command of the image. */
export type FlyContainerConfigExecList = Array<string>;
export declare const FlyContainerConfigExecList: S.Schema<FlyContainerConfigExecList>;
/** A file that will be written to the Machine. One of RawValue or SecretName must be set. */
export interface FlyFile {
    /** GuestPath is the path on the machine where the file will be written and must be an absolute path. For example: /full/path/to/file.json */
    guest_path?: string;
    /** The name of an image to use the OCI image config as the file contents. */
    image_config?: string;
    /** Mode bits used to set permissions on this file as accepted by chmod(2). */
    mode?: number;
    /** The base64 encoded string of the file contents. */
    raw_value?: string;
    /** The name of the secret that contains the base64 encoded file contents. */
    secret_name?: string;
}
export declare const FlyFile: S.Schema<FlyFile>;
/** Files are files that will be written to the container file system. */
export type FlyContainerConfigFilesList = Array<FlyFile>;
export declare const FlyContainerConfigFilesList: S.Schema<FlyContainerConfigFilesList>;
/** The command to run to check the health of the container (e.g. ["cat", "/tmp/healthy"]) */
export type FlyExecHealthcheckCommandList = Array<string>;
export declare const FlyExecHealthcheckCommandList: S.Schema<FlyExecHealthcheckCommandList>;
export interface FlyExecHealthcheck {
    /** The command to run to check the health of the container (e.g. ["cat", "/tmp/healthy"]) */
    command?: FlyExecHealthcheckCommandList;
}
export declare const FlyExecHealthcheck: S.Schema<FlyExecHealthcheck>;
/** Additional headers to send with the request */
export type FlyHTTPHealthcheckHeadersList = Array<FlyMachineHTTPHeader>;
export declare const FlyHTTPHealthcheckHeadersList: S.Schema<FlyHTTPHealthcheckHeadersList>;
export type FlyContainerHealthcheckScheme = "http" | "https";
export declare const FlyContainerHealthcheckScheme: any;
export interface FlyHTTPHealthcheck {
    /** Additional headers to send with the request */
    headers?: FlyHTTPHealthcheckHeadersList;
    /** The HTTP method to use to when making the request */
    method?: string;
    /** The path to send the request to */
    path?: string;
    /** The port to connect to, often the same as internal_port */
    port?: number;
    /** Whether to use http or https */
    scheme?: FlyContainerHealthcheckScheme | (string & {});
    /** If the protocol is https, the hostname to use for TLS certificate validation */
    tls_server_name?: string;
    /** If the protocol is https, whether or not to verify the TLS certificate */
    tls_skip_verify?: boolean;
}
export declare const FlyHTTPHealthcheck: S.Schema<FlyHTTPHealthcheck>;
export type FlyContainerHealthcheckKind = "readiness" | "liveness";
export declare const FlyContainerHealthcheckKind: any;
export interface FlyTCPHealthcheck {
    /** The port to connect to, often the same as internal_port */
    port?: number;
}
export declare const FlyTCPHealthcheck: S.Schema<FlyTCPHealthcheck>;
export type FlyUnhealthyPolicy = "stop";
export declare const FlyUnhealthyPolicy: any;
export interface FlyContainerHealthcheck {
    exec?: FlyExecHealthcheck;
    /** The number of times the check must fail before considering the container unhealthy. */
    failure_threshold?: number;
    /** The time in seconds to wait after a container starts before checking its health. */
    grace_period?: number;
    http?: FlyHTTPHealthcheck;
    /** The time in seconds between executing the defined check. */
    interval?: number;
    /** Kind of healthcheck (readiness, liveness) */
    kind?: FlyContainerHealthcheckKind | (string & {});
    /** The name of the check. Must be unique within the container. */
    name?: string;
    /** The number of times the check must succeeed before considering the container healthy. */
    success_threshold?: number;
    tcp?: FlyTCPHealthcheck;
    /** The time in seconds to wait for the check to complete. */
    timeout?: number;
    /** Unhealthy policy that determines what action to take if a container is deemed unhealthy */
    unhealthy?: FlyUnhealthyPolicy | (string & {});
}
export declare const FlyContainerHealthcheck: S.Schema<FlyContainerHealthcheck>;
/** Healthchecks determine the health of your containers. Healthchecks can use HTTP, TCP or an Exec command. */
export type FlyContainerConfigHealthchecksList = Array<FlyContainerHealthcheck>;
export declare const FlyContainerConfigHealthchecksList: S.Schema<FlyContainerConfigHealthchecksList>;
/** * no - Never try to restart a Machine automatically when its main process exits, whether that’s on purpose or on a crash. * always - Always restart a Machine automatically and never let it enter a stopped state, even when the main process exits cleanly. * on-failure - Try up to MaxRetries times to automatically restart the Machine if it exits with a non-zero exit code. Default when no explicit policy is set, and for Machines with schedules. * spot-price - Starts the Machine only when there is capacity and the spot price is less than or equal to the bid price. */
export type FlyMachineRestartPolicy = "no" | "always" | "on-failure" | "spot-price";
export declare const FlyMachineRestartPolicy: any;
/** The Machine restart policy defines whether and how flyd restarts a Machine after its main process exits. See https://fly.io/docs/machines/guides-examples/machine-restart-policy/. */
export interface FlyMachineRestart {
    /** GPU bid price for spot Machines. */
    gpu_bid_price?: number;
    /** When policy is on-failure, the maximum number of times to attempt to restart the Machine before letting it stop. */
    max_retries?: number;
    /** * no - Never try to restart a Machine automatically when its main process exits, whether that’s on purpose or on a crash. * always - Always restart a Machine automatically and never let it enter a stopped state, even when the main process exits cleanly. * on-failure - Try up to MaxRetries times to automatically restart the Machine if it exits with a non-zero exit code. Default when no explicit policy is set, and for Machines with schedules. * spot-price - Starts the Machine only when there is capacity and the spot price is less than or equal to the bid price. */
    policy?: FlyMachineRestartPolicy | (string & {});
}
export declare const FlyMachineRestart: S.Schema<FlyMachineRestart>;
/** A Secret needing to be set in the environment of the Machine. env_var is required */
export interface FlyMachineSecret {
    /** EnvVar is required and is the name of the environment variable that will be set from the secret. It must be a valid environment variable name. */
    env_var?: string;
    /** Name is optional and when provided is used to reference a secret name where the EnvVar is different from what was set as the secret name. */
    name?: string;
}
export declare const FlyMachineSecret: S.Schema<FlyMachineSecret>;
/** Secrets can be provided at the process level to explicitly indicate which secrets should be used for the process. If not provided, the secrets provided at the machine level will be used. */
export type FlyContainerConfigSecretsList = Array<FlyMachineSecret>;
export declare const FlyContainerConfigSecretsList: S.Schema<FlyContainerConfigSecretsList>;
export type FlyStopConfigSignal = "SIGHUP" | "SIGINT" | "SIGQUIT" | "SIGKILL" | "SIGUSR1" | "SIGUSR2" | "SIGTERM";
export declare const FlyStopConfigSignal: any;
export interface FlyStopConfig {
    signal?: FlyStopConfigSignal | (string & {});
    timeout?: string;
}
export declare const FlyStopConfig: S.Schema<FlyStopConfig>;
export interface FlyContainerConfig {
    /** CmdOverride is used to override the default command of the image. */
    cmd?: FlyContainerConfigCmdList;
    /** DependsOn can be used to define dependencies between containers. The container will only be started after all of its dependent conditions have been satisfied. */
    depends_on?: FlyContainerConfigDependsOnList;
    /** EntrypointOverride is used to override the default entrypoint of the image. */
    entrypoint?: FlyContainerConfigEntrypointList;
    /** ExtraEnv is used to add additional environment variables to the container. */
    env?: FlyContainerConfigEnvMap;
    /** EnvFrom can be provided to set environment variables from machine fields. */
    env_from?: FlyContainerConfigEnvFromList;
    /** Image Config overrides - these fields are used to override the image configuration. If not provided, the image configuration will be used. ExecOverride is used to override the default command of the image. */
    exec?: FlyContainerConfigExecList;
    /** Files are files that will be written to the container file system. */
    files?: FlyContainerConfigFilesList;
    /** Healthchecks determine the health of your containers. Healthchecks can use HTTP, TCP or an Exec command. */
    healthchecks?: FlyContainerConfigHealthchecksList;
    /** Image is the docker image to run. */
    image?: string;
    /** Name is used to identify the container in the machine. */
    name?: string;
    /** Restart is used to define the restart policy for the container. NOTE: spot-price is not supported for containers. */
    restart?: FlyMachineRestart;
    /** Secrets can be provided at the process level to explicitly indicate which secrets should be used for the process. If not provided, the secrets provided at the machine level will be used. */
    secrets?: FlyContainerConfigSecretsList;
    /** Stop is used to define the signal and timeout for stopping the container. */
    stop?: FlyStopConfig;
    /** UserOverride is used to override the default user of the image. */
    user?: string;
}
export declare const FlyContainerConfig: S.Schema<FlyContainerConfig>;
/** Containers are a list of containers that will run in the machine. Currently restricted to only specific organizations. */
export type FlyMachineConfigContainersList = Array<FlyContainerConfig>;
export declare const FlyMachineConfigContainersList: S.Schema<FlyMachineConfigContainersList>;
export interface FlyDnsForwardRule {
    addr?: string;
    basename?: string;
}
export declare const FlyDnsForwardRule: S.Schema<FlyDnsForwardRule>;
export type FlyDNSConfigDnsForwardRulesList = Array<FlyDnsForwardRule>;
export declare const FlyDNSConfigDnsForwardRulesList: S.Schema<FlyDNSConfigDnsForwardRulesList>;
export type FlyDNSConfigNameserversList = Array<string>;
export declare const FlyDNSConfigNameserversList: S.Schema<FlyDNSConfigNameserversList>;
export interface FlyDnsOption {
    name?: string;
    value?: string;
}
export declare const FlyDnsOption: S.Schema<FlyDnsOption>;
export type FlyDNSConfigOptionsList = Array<FlyDnsOption>;
export declare const FlyDNSConfigOptionsList: S.Schema<FlyDNSConfigOptionsList>;
export type FlyDNSConfigSearchesList = Array<string>;
export declare const FlyDNSConfigSearchesList: S.Schema<FlyDNSConfigSearchesList>;
export interface FlyDNSConfig {
    dns_forward_rules?: FlyDNSConfigDnsForwardRulesList;
    hostname?: string;
    hostname_fqdn?: string;
    nameservers?: FlyDNSConfigNameserversList;
    options?: FlyDNSConfigOptionsList;
    searches?: FlyDNSConfigSearchesList;
    skip_registration?: boolean;
}
export declare const FlyDNSConfig: S.Schema<FlyDNSConfig>;
/** An object filled with key/value pairs to be set as environment variables */
export type FlyMachineConfigEnvMap = {
    [key: string]: string | undefined;
};
export declare const FlyMachineConfigEnvMap: S.Schema<FlyMachineConfigEnvMap>;
export type FlyMachineConfigFilesList = Array<FlyFile>;
export declare const FlyMachineConfigFilesList: S.Schema<FlyMachineConfigFilesList>;
export type FlyMachineGuestKernelArgsList = Array<string>;
export declare const FlyMachineGuestKernelArgsList: S.Schema<FlyMachineGuestKernelArgsList>;
/** Deprecated: use MachineConfig.Rootfs instead */
export type FlyMachineGuestPersistRootfs = "never" | "always" | "restart";
export declare const FlyMachineGuestPersistRootfs: any;
export interface FlyMachineGuest {
    cpu_kind?: string;
    cpus?: number;
    gpu_kind?: string;
    gpus?: number;
    host_dedication_id?: string;
    kernel_args?: FlyMachineGuestKernelArgsList;
    max_memory_mb?: number;
    memory_mb?: number;
    /** Deprecated: use MachineConfig.Rootfs instead */
    persist_rootfs?: FlyMachineGuestPersistRootfs | (string & {});
}
export declare const FlyMachineGuest: S.Schema<FlyMachineGuest>;
export type FlyMachineInitCmdList = Array<string>;
export declare const FlyMachineInitCmdList: S.Schema<FlyMachineInitCmdList>;
export type FlyMachineInitEntrypointList = Array<string>;
export declare const FlyMachineInitEntrypointList: S.Schema<FlyMachineInitEntrypointList>;
export type FlyMachineInitExecList = Array<string>;
export declare const FlyMachineInitExecList: S.Schema<FlyMachineInitExecList>;
export type FlyMachineInitKernelArgsList = Array<string>;
export declare const FlyMachineInitKernelArgsList: S.Schema<FlyMachineInitKernelArgsList>;
export interface FlyMachineInit {
    cmd?: FlyMachineInitCmdList;
    entrypoint?: FlyMachineInitEntrypointList;
    exec?: FlyMachineInitExecList;
    kernel_args?: FlyMachineInitKernelArgsList;
    swap_size_mb?: number;
    tty?: boolean;
}
export declare const FlyMachineInit: S.Schema<FlyMachineInit>;
export type FlyMachineConfigMetadataMap = {
    [key: string]: string | undefined;
};
export declare const FlyMachineConfigMetadataMap: S.Schema<FlyMachineConfigMetadataMap>;
export interface FlyMachineMetrics {
    https?: boolean;
    path?: string;
    port?: number;
}
export declare const FlyMachineMetrics: S.Schema<FlyMachineMetrics>;
export interface FlyMachineMount {
    add_size_gb?: number;
    encrypted?: boolean;
    extend_threshold_percent?: number;
    name?: string;
    path?: string;
    size_gb?: number;
    size_gb_limit?: number;
    volume?: string;
}
export declare const FlyMachineMount: S.Schema<FlyMachineMount>;
export type FlyMachineConfigMountsList = Array<FlyMachineMount>;
export declare const FlyMachineConfigMountsList: S.Schema<FlyMachineConfigMountsList>;
export type FlyMachineProcessCmdList = Array<string>;
export declare const FlyMachineProcessCmdList: S.Schema<FlyMachineProcessCmdList>;
export type FlyMachineProcessEntrypointList = Array<string>;
export declare const FlyMachineProcessEntrypointList: S.Schema<FlyMachineProcessEntrypointList>;
export type FlyMachineProcessEnvMap = {
    [key: string]: string | undefined;
};
export declare const FlyMachineProcessEnvMap: S.Schema<FlyMachineProcessEnvMap>;
/** EnvFrom can be provided to set environment variables from machine fields. */
export type FlyMachineProcessEnvFromList = Array<FlyEnvFrom>;
export declare const FlyMachineProcessEnvFromList: S.Schema<FlyMachineProcessEnvFromList>;
export type FlyMachineProcessExecList = Array<string>;
export declare const FlyMachineProcessExecList: S.Schema<FlyMachineProcessExecList>;
/** Secrets can be provided at the process level to explicitly indicate which secrets should be used for the process. If not provided, the secrets provided at the machine level will be used. */
export type FlyMachineProcessSecretsList = Array<FlyMachineSecret>;
export declare const FlyMachineProcessSecretsList: S.Schema<FlyMachineProcessSecretsList>;
export interface FlyMachineProcess {
    cmd?: FlyMachineProcessCmdList;
    entrypoint?: FlyMachineProcessEntrypointList;
    env?: FlyMachineProcessEnvMap;
    /** EnvFrom can be provided to set environment variables from machine fields. */
    env_from?: FlyMachineProcessEnvFromList;
    exec?: FlyMachineProcessExecList;
    /** IgnoreAppSecrets can be set to true to ignore the secrets for the App the Machine belongs to and only use the secrets provided at the process level. The default/legacy behavior is to use the secrets provided at the App level. */
    ignore_app_secrets?: boolean;
    /** Secrets can be provided at the process level to explicitly indicate which secrets should be used for the process. If not provided, the secrets provided at the machine level will be used. */
    secrets?: FlyMachineProcessSecretsList;
    user?: string;
}
export declare const FlyMachineProcess: S.Schema<FlyMachineProcess>;
export type FlyMachineConfigProcessesList = Array<FlyMachineProcess>;
export declare const FlyMachineConfigProcessesList: S.Schema<FlyMachineConfigProcessesList>;
export type FlyMachineRootfsPersist = "never" | "always" | "restart";
export declare const FlyMachineRootfsPersist: any;
export interface FlyMachineRootfs {
    persist?: FlyMachineRootfsPersist | (string & {});
    size_gb?: number;
}
export declare const FlyMachineRootfs: S.Schema<FlyMachineRootfs>;
/** Accepts a string (new format) or a boolean (old format). For backward compatibility with older clients, the API continues to use booleans for "off" and "stop" in responses. * "off" or false - Do not autostop the Machine. * "stop" or true - Automatically stop the Machine. * "suspend" - Automatically suspend the Machine, falling back to a full stop if this is not possible. */
export type FlyMachineServiceAutostop = "off" | "stop" | "suspend";
export declare const FlyMachineServiceAutostop: any;
export type FlyMachineServiceCheckHeadersList = Array<FlyMachineHTTPHeader>;
export declare const FlyMachineServiceCheckHeadersList: S.Schema<FlyMachineServiceCheckHeadersList>;
export interface FlyMachineServiceCheck {
    /** The time to wait after a VM starts before checking its health */
    grace_period?: string;
    headers?: FlyMachineServiceCheckHeadersList;
    /** The time between connectivity checks */
    interval?: string;
    /** For http checks, the HTTP method to use to when making the request */
    method?: string;
    /** For http checks, the path to send the request to */
    path?: string;
    /** The port to connect to, often the same as internal_port */
    port?: number;
    /** For http checks, whether to use http or https */
    protocol?: string;
    /** The maximum time a connection can take before being reported as failing its health check */
    timeout?: string;
    /** If the protocol is https, the hostname to use for TLS certificate validation */
    tls_server_name?: string;
    /** For http checks with https protocol, whether or not to verify the TLS certificate */
    tls_skip_verify?: boolean;
    /** tcp or http */
    type?: string;
}
export declare const FlyMachineServiceCheck: S.Schema<FlyMachineServiceCheck>;
/** An optional list of service checks */
export type FlyMachineServiceChecksList = Array<FlyMachineServiceCheck>;
export declare const FlyMachineServiceChecksList: S.Schema<FlyMachineServiceChecksList>;
export interface FlyMachineServiceConcurrency {
    hard_limit?: number;
    soft_limit?: number;
    type?: string;
}
export declare const FlyMachineServiceConcurrency: S.Schema<FlyMachineServiceConcurrency>;
export type FlyMachinePortHandlersList = Array<string>;
export declare const FlyMachinePortHandlersList: S.Schema<FlyMachinePortHandlersList>;
/** Currently either "cookie" or "header" */
export type FlyReplayCacheType = "cookie" | "header";
export declare const FlyReplayCacheType: any;
export interface FlyReplayCache {
    allow_bypass?: boolean;
    /** Name of the cookie or header to key the cache on */
    name?: string;
    path_prefix?: string;
    ttl_seconds?: number;
    /** Currently either "cookie" or "header" */
    type?: FlyReplayCacheType | (string & {});
}
export declare const FlyReplayCache: S.Schema<FlyReplayCache>;
export type FlyHTTPOptionsReplayCacheList = Array<FlyReplayCache>;
export declare const FlyHTTPOptionsReplayCacheList: S.Schema<FlyHTTPOptionsReplayCacheList>;
export type FlyHTTPResponseOptionsHeadersMap = {
    [key: string]: unknown | undefined;
};
export declare const FlyHTTPResponseOptionsHeadersMap: S.Schema<FlyHTTPResponseOptionsHeadersMap>;
export interface FlyHTTPResponseOptions {
    headers?: FlyHTTPResponseOptionsHeadersMap;
    pristine?: boolean;
}
export declare const FlyHTTPResponseOptions: S.Schema<FlyHTTPResponseOptions>;
export interface FlyHTTPOptions {
    compress?: boolean;
    h2_backend?: boolean;
    headers_read_timeout?: number;
    idle_timeout?: number;
    replay_cache?: FlyHTTPOptionsReplayCacheList;
    response?: FlyHTTPResponseOptions;
}
export declare const FlyHTTPOptions: S.Schema<FlyHTTPOptions>;
export interface FlyProxyProtoOptions {
    version?: string;
}
export declare const FlyProxyProtoOptions: S.Schema<FlyProxyProtoOptions>;
export type FlyTLSOptionsAlpnList = Array<string>;
export declare const FlyTLSOptionsAlpnList: S.Schema<FlyTLSOptionsAlpnList>;
export type FlyTLSOptionsVersionsList = Array<string>;
export declare const FlyTLSOptionsVersionsList: S.Schema<FlyTLSOptionsVersionsList>;
export interface FlyTLSOptions {
    alpn?: FlyTLSOptionsAlpnList;
    default_self_signed?: boolean;
    versions?: FlyTLSOptionsVersionsList;
}
export declare const FlyTLSOptions: S.Schema<FlyTLSOptions>;
export interface FlyMachinePort {
    end_port?: number;
    force_https?: boolean;
    handlers?: FlyMachinePortHandlersList;
    http_options?: FlyHTTPOptions;
    port?: number;
    proxy_proto_options?: FlyProxyProtoOptions;
    start_port?: number;
    tls_options?: FlyTLSOptions;
}
export declare const FlyMachinePort: S.Schema<FlyMachinePort>;
export type FlyMachineServicePortsList = Array<FlyMachinePort>;
export declare const FlyMachineServicePortsList: S.Schema<FlyMachineServicePortsList>;
export interface FlyMachineService {
    autostart?: boolean;
    /** Accepts a string (new format) or a boolean (old format). For backward compatibility with older clients, the API continues to use booleans for "off" and "stop" in responses. * "off" or false - Do not autostop the Machine. * "stop" or true - Automatically stop the Machine. * "suspend" - Automatically suspend the Machine, falling back to a full stop if this is not possible. */
    autostop?: FlyMachineServiceAutostop | (string & {});
    /** An optional list of service checks */
    checks?: FlyMachineServiceChecksList;
    concurrency?: FlyMachineServiceConcurrency;
    force_instance_description?: string;
    force_instance_key?: string;
    internal_port?: number;
    min_machines_running?: number;
    ports?: FlyMachineServicePortsList;
    protocol?: string;
}
export declare const FlyMachineService: S.Schema<FlyMachineService>;
export type FlyMachineConfigServicesList = Array<FlyMachineService>;
export declare const FlyMachineConfigServicesList: S.Schema<FlyMachineConfigServicesList>;
export interface FlyMachineSpot {
    /** MaxPriceFraction is the maximum fraction of the full Machine price you will pay for this Machine. Range: (0, 1.0] */
    max_price_fraction?: number;
}
export declare const FlyMachineSpot: S.Schema<FlyMachineSpot>;
/** Standbys enable a machine to be a standby for another. In the event of a hardware failure, the standby machine will be started. */
export type FlyMachineConfigStandbysList = Array<string>;
export declare const FlyMachineConfigStandbysList: S.Schema<FlyMachineConfigStandbysList>;
export interface FlyStatic {
    guest_path: string;
    index_document?: string;
    tigris_bucket?: string;
    url_prefix: string;
}
export declare const FlyStatic: S.Schema<FlyStatic>;
export type FlyMachineConfigStaticsList = Array<FlyStatic>;
export declare const FlyMachineConfigStaticsList: S.Schema<FlyMachineConfigStaticsList>;
export interface FlyMachineConfig {
    /** Optional boolean telling the Machine to destroy itself once it’s complete (default false) */
    auto_destroy?: boolean;
    cache_drive?: FlyMachineCacheDrive;
    /** An optional object that defines one or more named top-level checks. The key for each check is the check name. */
    checks?: FlyMachineConfigChecksMap;
    /** Containers are a list of containers that will run in the machine. Currently restricted to only specific organizations. */
    containers?: FlyMachineConfigContainersList;
    /** Deprecated: use Service.Autostart instead */
    disable_machine_autostart?: boolean;
    dns?: FlyDNSConfig;
    /** An object filled with key/value pairs to be set as environment variables */
    env?: FlyMachineConfigEnvMap;
    files?: FlyMachineConfigFilesList;
    guest?: FlyMachineGuest;
    /** The docker image to run */
    image?: string;
    init?: FlyMachineInit;
    metadata?: FlyMachineConfigMetadataMap;
    metrics?: FlyMachineMetrics;
    mounts?: FlyMachineConfigMountsList;
    processes?: FlyMachineConfigProcessesList;
    restart?: FlyMachineRestart;
    rootfs?: FlyMachineRootfs;
    schedule?: string;
    services?: FlyMachineConfigServicesList;
    /** Deprecated: use Guest instead */
    size?: string;
    spot?: FlyMachineSpot;
    /** Standbys enable a machine to be a standby for another. In the event of a hardware failure, the standby machine will be started. */
    standbys?: FlyMachineConfigStandbysList;
    statics?: FlyMachineConfigStaticsList;
    stop_config?: FlyStopConfig;
}
export declare const FlyMachineConfig: S.Schema<FlyMachineConfig>;
export interface CreateMachineRequest {
    /** Fly App Name */
    app_name: string;
    /** An object defining the Machine configuration */
    config?: FlyMachineConfig;
    lease_ttl?: number;
    min_secrets_version?: number;
    /** Unique name for this Machine. If omitted, one is generated for you */
    name?: string;
    /** The target region. Omitting this param launches in the same region as your WireGuard peer connection (somewhere near you). */
    region?: string;
    skip_launch?: boolean;
    skip_secrets?: boolean;
    skip_service_registration?: boolean;
}
export declare const CreateMachineRequest: S.Schema<CreateMachineRequest>;
export interface CheckStatus {
    name?: string;
    output?: string;
    status?: string;
    updated_at?: string;
}
export declare const CheckStatus: S.Schema<CheckStatus>;
export type MachineChecksList = Array<CheckStatus>;
export declare const MachineChecksList: S.Schema<MachineChecksList>;
export interface MachineEvent {
    id?: string;
    request?: unknown;
    source?: string;
    status?: string;
    timestamp?: number;
    type?: string;
}
export declare const MachineEvent: S.Schema<MachineEvent>;
export type MachineEventsList = Array<MachineEvent>;
export declare const MachineEventsList: S.Schema<MachineEventsList>;
export type MachineHostStatus = "ok" | "unknown" | "unreachable";
export declare const MachineHostStatus: any;
export type ImageRefLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ImageRefLabelsMap: S.Schema<ImageRefLabelsMap>;
export interface ImageRef {
    digest?: string;
    labels?: ImageRefLabelsMap;
    registry?: string;
    repository?: string;
    tag?: string;
}
export declare const ImageRef: S.Schema<ImageRef>;
export interface StrippedLease {
    description?: string;
    expires_at?: number;
    owner?: string;
}
export declare const StrippedLease: S.Schema<StrippedLease>;
export interface Machine {
    checks?: MachineChecksList;
    config?: FlyMachineConfig;
    cordoned?: boolean;
    created_at?: string;
    events?: MachineEventsList;
    host_status?: MachineHostStatus;
    id?: string;
    image_ref?: ImageRef;
    incomplete_config?: FlyMachineConfig;
    /** InstanceID is unique for each version of the machine */
    instance_id?: string;
    lease?: StrippedLease;
    name?: string;
    /** Nonce is only every returned on machine creation if a lease_duration was provided. */
    nonce?: string;
    /** PrivateIP is the internal 6PN address of the machine. */
    private_ip?: string;
    region?: string;
    state?: string;
    updated_at?: string;
}
export declare const Machine: S.Schema<Machine>;
export interface CreateMachineLeaseRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    description?: string;
    /** seconds lease will be valid */
    ttl?: number;
}
export declare const CreateMachineLeaseRequest: S.Schema<CreateMachineLeaseRequest>;
export interface Lease {
    /** Description or reason for the Lease. */
    description?: string;
    /** ExpiresAt is the unix timestamp in UTC to denote when the Lease will no longer be valid. */
    expires_at?: number;
    /** Nonce is the unique ID autogenerated and associated with the Lease. */
    nonce?: string;
    /** Owner is the user identifier which acquired the Lease. */
    owner?: string;
    /** Machine version */
    version?: string;
}
export declare const Lease: S.Schema<Lease>;
/** Postgres major version. */
export type CreatePostgresRequestPgMajorVersion = "16" | "17";
export declare const CreatePostgresRequestPgMajorVersion: any;
/** Plan slug selecting CPU, memory, and disk sizing. */
export type CreatePostgresRequestPlan = "basic" | "starter" | "launch" | "scale" | "Performance";
export declare const CreatePostgresRequestPlan: any;
/** Connection pooler mode. */
export type CreatePostgresRequestPoolMode = "session" | "transaction";
export declare const CreatePostgresRequestPoolMode: any;
export interface CreatePostgresRequest {
    /** Disk size in gigabytes. */
    disk_size_gb?: number;
    /** Name for the cluster. A name is generated when omitted. */
    name?: string;
    /** Slug of the organization that will own the cluster. */
    org_slug: string;
    /** Postgres major version. */
    pg_major_version?: CreatePostgresRequestPgMajorVersion | (string & {});
    /** Plan slug selecting CPU, memory, and disk sizing. */
    plan: CreatePostgresRequestPlan | (string & {});
    /** Connection pooler mode. */
    pool_mode?: CreatePostgresRequestPoolMode | (string & {});
    /** Enable PostGIS support, required to later enable PostGIS extensions. */
    postgis_enabled?: boolean;
    /** Fly region code where the cluster's primary runs. */
    region: string;
}
export declare const CreatePostgresRequest: S.Schema<CreatePostgresRequest>;
export interface PostgresAttachedApp {
    /** Attached Fly app name. */
    name?: string;
}
export declare const PostgresAttachedApp: S.Schema<PostgresAttachedApp>;
/** Apps attached to the cluster. */
export type PostgresClusterAttachedAppsList = Array<PostgresAttachedApp>;
export declare const PostgresClusterAttachedAppsList: S.Schema<PostgresClusterAttachedAppsList>;
/** CPU class. */
export type PostgresClusterCpuKind = "shared" | "performance";
export declare const PostgresClusterCpuKind: any;
export interface PostgresEndpoint {
    /** Hostname to connect to. */
    host?: string;
    /** TCP port. */
    port?: number;
}
export declare const PostgresEndpoint: S.Schema<PostgresEndpoint>;
export interface PostgresNodeEndpoints {
    /** Unpooled connection to the cluster node. */
    direct?: PostgresEndpoint;
    /** Pooled connection to the cluster node (through PgBouncer). */
    pooler?: PostgresEndpoint;
}
export declare const PostgresNodeEndpoints: S.Schema<PostgresNodeEndpoints>;
export interface PostgresClusterEndpoints {
    /** Endpoints for connecting to the primary node. */
    primary?: PostgresNodeEndpoints;
}
export declare const PostgresClusterEndpoints: S.Schema<PostgresClusterEndpoints>;
export interface OrganizationRef {
    /** Organization name. */
    name?: string;
    /** Organization slug. */
    slug?: string;
}
export declare const OrganizationRef: S.Schema<OrganizationRef>;
/** Postgres major version. */
export type PostgresClusterPgMajorVersion = "16" | "17";
export declare const PostgresClusterPgMajorVersion: any;
/** Plan slug. */
export type PostgresClusterPlan = "basic" | "starter" | "launch" | "scale" | "Performance";
export declare const PostgresClusterPlan: any;
/** Current lifecycle status. */
export type PostgresClusterStatus = "creating" | "initializing" | "ready" | "deleting" | "deleted" | "failed";
export declare const PostgresClusterStatus: any;
export interface PostgresCluster {
    /** Apps attached to the cluster. */
    attached_apps?: PostgresClusterAttachedAppsList;
    /** CPU class. */
    cpu_kind?: PostgresClusterCpuKind;
    /** vCPUs per node. */
    cpus?: number;
    /** RFC 3339 creation timestamp. */
    created_at?: string;
    /** Disk size in gigabytes. */
    disk_size_gb?: number;
    /** Connection endpoints. Populated once the cluster is ready. */
    endpoints?: PostgresClusterEndpoints;
    /** Cluster ID. */
    id?: string;
    /** Memory per node in megabytes. */
    memory_mb?: number;
    /** Cluster name. */
    name?: string;
    organization?: OrganizationRef;
    /** Postgres major version. */
    pg_major_version?: PostgresClusterPgMajorVersion;
    /** Plan slug. */
    plan?: PostgresClusterPlan;
    /** Whether PostGIS support is enabled. */
    postgis_enabled?: boolean;
    /** Fly region code. */
    region?: string;
    /** Number of replicas. */
    replicas?: number;
    /** Current lifecycle status. */
    status?: PostgresClusterStatus;
}
export declare const PostgresCluster: S.Schema<PostgresCluster>;
export interface ShowPostgresClusterResponse {
    data?: PostgresCluster;
}
export declare const ShowPostgresClusterResponse: S.Schema<ShowPostgresClusterResponse>;
export interface CreatePostgresAttachmentRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Name of the Fly app to attach. */
    app_name: string;
}
export declare const CreatePostgresAttachmentRequest: S.Schema<CreatePostgresAttachmentRequest>;
export interface PostgresAttachment {
    /** Attached Fly app name. */
    app_name?: string;
    /** RFC 3339 timestamp when the attachment was created. */
    attached_at?: string;
    /** Cluster ID the app is attached to. */
    postgres_cluster_id?: string;
}
export declare const PostgresAttachment: S.Schema<PostgresAttachment>;
export interface CreatePostgresAttachmentResponse {
    data?: PostgresAttachment;
}
export declare const CreatePostgresAttachmentResponse: S.Schema<CreatePostgresAttachmentResponse>;
/** Backup type. */
export type CreatePostgresBackupRequestType = "full" | "incr" | "diff";
export declare const CreatePostgresBackupRequestType: any;
export interface CreatePostgresBackupRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Backup type. */
    type: CreatePostgresBackupRequestType | (string & {});
}
export declare const CreatePostgresBackupRequest: S.Schema<CreatePostgresBackupRequest>;
export interface CreatePostgresBackupResponse {
}
export declare const CreatePostgresBackupResponse: S.Schema<CreatePostgresBackupResponse>;
export interface CreatePostgresDatabaseRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Name of the database to create. */
    name: string;
}
export declare const CreatePostgresDatabaseRequest: S.Schema<CreatePostgresDatabaseRequest>;
export interface PostgresDatabase {
    /** Database name. */
    name?: string;
}
export declare const PostgresDatabase: S.Schema<PostgresDatabase>;
export interface PostgresDatabaseResponse {
    data?: PostgresDatabase;
}
export declare const PostgresDatabaseResponse: S.Schema<PostgresDatabaseResponse>;
/** Role to grant the user. */
export type CreatePostgresUserRequestRole = "schema_admin" | "writer" | "reader";
export declare const CreatePostgresUserRequestRole: any;
export interface CreatePostgresUserRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Role to grant the user. */
    role: CreatePostgresUserRequestRole | (string & {});
    /** Name for the new user. */
    username: string;
}
export declare const CreatePostgresUserRequest: S.Schema<CreatePostgresUserRequest>;
/** User role. */
export type PostgresUserRole = "schema_admin" | "writer" | "reader";
export declare const PostgresUserRole: any;
export interface PostgresUser {
    /** User role. */
    role?: PostgresUserRole;
    /** User name. */
    username?: string;
}
export declare const PostgresUser: S.Schema<PostgresUser>;
export interface CreatePostgresUserResponse {
    data?: PostgresUser;
}
export declare const CreatePostgresUserResponse: S.Schema<CreatePostgresUserResponse>;
export interface CreateSecretRequest {
    /** Fly App Name */
    app_name: string;
    /** App secret name */
    secret_name: string;
    value?: string;
}
export declare const CreateSecretRequest: S.Schema<CreateSecretRequest>;
export interface SetAppSecretResponse {
    /** DEPRECATED */
    Version?: number;
    created_at?: string;
    digest?: string;
    name?: string;
    updated_at?: string;
    value?: string;
    version?: number;
}
export declare const SetAppSecretResponse: S.Schema<SetAppSecretResponse>;
export interface CreateVolumeRequest {
    /** Fly App Name */
    app_name: string;
    /** enable scheduled automatic snapshots. Defaults to `true` */
    auto_backup_enabled?: boolean;
    compute?: FlyMachineGuest;
    compute_image?: string;
    encrypted?: boolean;
    fstype?: string;
    name?: string;
    region?: string;
    require_unique_zone?: boolean;
    size_gb?: number;
    /** restore from snapshot */
    snapshot_id?: string;
    snapshot_retention?: number;
    /** fork from remote volume */
    source_volume_id?: string;
    unique_zone_app_wide?: boolean;
}
export declare const CreateVolumeRequest: S.Schema<CreateVolumeRequest>;
export type VolumeHostStatus = "ok" | "unknown" | "unreachable";
export declare const VolumeHostStatus: any;
export type VolumeType = "local" | "cache";
export declare const VolumeType: any;
export interface Volume {
    attached_alloc_id?: string;
    attached_machine_id?: string;
    auto_backup_enabled?: boolean;
    block_size?: number;
    blocks?: number;
    blocks_avail?: number;
    blocks_free?: number;
    bytes_total?: number;
    bytes_used?: number;
    created_at?: string;
    encrypted?: boolean;
    fstype?: string;
    host_status?: VolumeHostStatus;
    id?: string;
    name?: string;
    region?: string;
    size_gb?: number;
    snapshot_retention?: number;
    state?: string;
    type?: VolumeType;
    zone?: string;
}
export declare const Volume: S.Schema<Volume>;
export interface CreateVolumeSnapshotRequest {
    /** Fly App Name */
    app_name: string;
    /** Volume ID */
    volume_id: string;
}
export declare const CreateVolumeSnapshotRequest: S.Schema<CreateVolumeSnapshotRequest>;
export interface CreateVolumeSnapshotResponse {
}
export declare const CreateVolumeSnapshotResponse: S.Schema<CreateVolumeSnapshotResponse>;
export interface DecryptSecretKeyRequest {
    /** Fly App Name */
    app_name: string;
    /** Secret key name */
    secret_name: string;
    /** Minimum secrets version to return. Returned when setting a new secret */
    min_version?: string;
    associated_data?: string;
    ciphertext?: string;
}
export declare const DecryptSecretKeyRequest: S.Schema<DecryptSecretKeyRequest>;
export interface DecryptSecretkeyResponse {
    plaintext?: string;
}
export declare const DecryptSecretkeyResponse: S.Schema<DecryptSecretkeyResponse>;
export interface DeleteAppRequest {
    /** Fly App Name */
    app_name: string;
}
export declare const DeleteAppRequest: S.Schema<DeleteAppRequest>;
export interface DeleteAppResponse {
}
export declare const DeleteAppResponse: S.Schema<DeleteAppResponse>;
export interface DeleteAppAcmeCertificateRequest {
    /** Fly App Name */
    app_name: string;
    /** Certificate Hostname */
    hostname: string;
}
export declare const DeleteAppAcmeCertificateRequest: S.Schema<DeleteAppAcmeCertificateRequest>;
export interface DeleteAppCertificateRequest {
    /** Fly App Name */
    app_name: string;
    /** Certificate Hostname */
    hostname: string;
}
export declare const DeleteAppCertificateRequest: S.Schema<DeleteAppCertificateRequest>;
export interface DeleteAppCertificateResponse {
}
export declare const DeleteAppCertificateResponse: S.Schema<DeleteAppCertificateResponse>;
export interface DeleteAppCustomCertificateRequest {
    /** Fly App Name */
    app_name: string;
    /** Certificate Hostname */
    hostname: string;
}
export declare const DeleteAppCustomCertificateRequest: S.Schema<DeleteAppCustomCertificateRequest>;
export type DestroyCustomCertificateResponseCertificatesList = Array<CertificateEntry>;
export declare const DestroyCustomCertificateResponseCertificatesList: S.Schema<DestroyCustomCertificateResponseCertificatesList>;
export type DestroyCustomCertificateResponseValidationErrorsList = Array<CertificateValidationError>;
export declare const DestroyCustomCertificateResponseValidationErrorsList: S.Schema<DestroyCustomCertificateResponseValidationErrorsList>;
export interface DestroyCustomCertificateResponse {
    acme_requested?: boolean;
    certificates?: DestroyCustomCertificateResponseCertificatesList;
    configured?: boolean;
    dns_provider?: string;
    dns_requirements?: DNSRequirements;
    hostname?: string;
    rate_limited_until?: string;
    status?: string;
    validation?: CertificateValidation;
    validation_errors?: DestroyCustomCertificateResponseValidationErrorsList;
    warning?: string;
}
export declare const DestroyCustomCertificateResponse: S.Schema<DestroyCustomCertificateResponse>;
export interface DeleteAppIPAssignmentRequest {
    /** Fly App Name */
    app_name: string;
    /** IP address */
    ip: string;
}
export declare const DeleteAppIPAssignmentRequest: S.Schema<DeleteAppIPAssignmentRequest>;
export interface DeleteAppIPAssignmentResponse {
}
export declare const DeleteAppIPAssignmentResponse: S.Schema<DeleteAppIPAssignmentResponse>;
export interface DeleteMachineRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    /** Force kill the machine if it's running */
    force?: boolean;
}
export declare const DeleteMachineRequest: S.Schema<DeleteMachineRequest>;
export interface DeleteMachineResponse {
}
export declare const DeleteMachineResponse: S.Schema<DeleteMachineResponse>;
export interface DeleteMachineMetadataRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    /** Metadata Key */
    key: string;
}
export declare const DeleteMachineMetadataRequest: S.Schema<DeleteMachineMetadataRequest>;
export interface DeleteMachineMetadataResponse {
}
export declare const DeleteMachineMetadataResponse: S.Schema<DeleteMachineMetadataResponse>;
export interface DeletePostgresRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
}
export declare const DeletePostgresRequest: S.Schema<DeletePostgresRequest>;
export interface DeletePostgresResponse {
}
export declare const DeletePostgresResponse: S.Schema<DeletePostgresResponse>;
export interface DeletePostgresAttachmentRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Fly App Name */
    app_name: string;
}
export declare const DeletePostgresAttachmentRequest: S.Schema<DeletePostgresAttachmentRequest>;
export interface DeletePostgresAttachmentResponse {
}
export declare const DeletePostgresAttachmentResponse: S.Schema<DeletePostgresAttachmentResponse>;
export interface DeletePostgresDatabaseRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Database Name */
    database_name: string;
}
export declare const DeletePostgresDatabaseRequest: S.Schema<DeletePostgresDatabaseRequest>;
export interface DeletePostgresUserRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Postgres User Name */
    username: string;
}
export declare const DeletePostgresUserRequest: S.Schema<DeletePostgresUserRequest>;
export interface DeletePostgresUserResponse {
}
export declare const DeletePostgresUserResponse: S.Schema<DeletePostgresUserResponse>;
export interface DeleteSecretRequest {
    /** Fly App Name */
    app_name: string;
    /** App secret name */
    secret_name: string;
}
export declare const DeleteSecretRequest: S.Schema<DeleteSecretRequest>;
export interface DeleteAppSecretResponse {
    /** DEPRECATED */
    Version?: number;
    version?: number;
}
export declare const DeleteAppSecretResponse: S.Schema<DeleteAppSecretResponse>;
export interface DeleteSecretKeyRequest {
    /** Fly App Name */
    app_name: string;
    /** Secret key name */
    secret_name: string;
}
export declare const DeleteSecretKeyRequest: S.Schema<DeleteSecretKeyRequest>;
export interface DeleteSecretkeyResponse {
    /** DEPRECATED */
    Version?: number;
    version?: number;
}
export declare const DeleteSecretkeyResponse: S.Schema<DeleteSecretkeyResponse>;
export interface DeleteVolumeRequest {
    /** Fly App Name */
    app_name: string;
    /** Volume ID */
    volume_id: string;
}
export declare const DeleteVolumeRequest: S.Schema<DeleteVolumeRequest>;
export interface DisablePostgresExtensionRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Database Name */
    database_name: string;
    /** Extension Name */
    extension_name: string;
    /** Also drop objects that depend on the extension */
    force?: boolean;
}
export declare const DisablePostgresExtensionRequest: S.Schema<DisablePostgresExtensionRequest>;
export interface DisablePostgresExtensionResponse {
}
export declare const DisablePostgresExtensionResponse: S.Schema<DisablePostgresExtensionResponse>;
export interface EnablePostgresExtensionRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Database Name */
    database_name: string;
    /** Create the schema first if it does not exist. */
    create_schema?: boolean;
    /** Extension to enable. */
    name: string;
    /** Schema to install the extension into. Defaults to the database's default schema. */
    schema?: string;
}
export declare const EnablePostgresExtensionRequest: S.Schema<EnablePostgresExtensionRequest>;
export interface EnablePostgresExtensionResponse {
}
export declare const EnablePostgresExtensionResponse: S.Schema<EnablePostgresExtensionResponse>;
export interface EncryptSecretKeyRequest {
    /** Fly App Name */
    app_name: string;
    /** Secret key name */
    secret_name: string;
    /** Minimum secrets version to return. Returned when setting a new secret */
    min_version?: string;
    associated_data?: string;
    plaintext?: string;
}
export declare const EncryptSecretKeyRequest: S.Schema<EncryptSecretKeyRequest>;
export interface EncryptSecretkeyResponse {
    ciphertext?: string;
}
export declare const EncryptSecretkeyResponse: S.Schema<EncryptSecretkeyResponse>;
export type ExecMachineRequestCommandList = Array<string>;
export declare const ExecMachineRequestCommandList: S.Schema<ExecMachineRequestCommandList>;
export interface ExecMachineRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    /** Deprecated: use Command instead */
    cmd?: string;
    command?: ExecMachineRequestCommandList;
    container?: string;
    /** Machine runs the command in the machine's own namespace instead of in a container. It is mutually exclusive with Container. */
    machine?: boolean;
    stdin?: string;
    timeout?: number;
}
export declare const ExecMachineRequest: S.Schema<ExecMachineRequest>;
export interface Flydv1ExecResponse {
    exit_code?: number;
    exit_signal?: number;
    stderr?: string;
    stdout?: string;
}
export declare const Flydv1ExecResponse: S.Schema<Flydv1ExecResponse>;
export interface ExtendVolumeRequest {
    /** Fly App Name */
    app_name: string;
    /** Volume ID */
    volume_id: string;
    size_gb?: number;
}
export declare const ExtendVolumeRequest: S.Schema<ExtendVolumeRequest>;
export interface ExtendVolumeResponse {
    needs_restart?: boolean;
    volume?: Volume;
}
export declare const ExtendVolumeResponse: S.Schema<ExtendVolumeResponse>;
export interface ForkPostgresRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Name for the forked cluster. Defaults to the source name with a -fork suffix. */
    name?: string;
}
export declare const ForkPostgresRequest: S.Schema<ForkPostgresRequest>;
export type GenerateSecretKeyRequestValueList = Array<number>;
export declare const GenerateSecretKeyRequestValueList: S.Schema<GenerateSecretKeyRequestValueList>;
export interface GenerateSecretKeyRequest {
    /** Fly App Name */
    app_name: string;
    /** Secret key name */
    secret_name: string;
    type?: string;
    value?: GenerateSecretKeyRequestValueList;
}
export declare const GenerateSecretKeyRequest: S.Schema<GenerateSecretKeyRequest>;
export interface SetSecretkeyResponse {
    /** DEPRECATED */
    Version?: number;
    created_at?: string;
    name?: string;
    public_key?: string;
    type?: string;
    updated_at?: string;
    version?: number;
}
export declare const SetSecretkeyResponse: S.Schema<SetSecretkeyResponse>;
export interface GetAppRequest {
    /** Fly App Name */
    app_name: string;
}
export declare const GetAppRequest: S.Schema<GetAppRequest>;
export interface AppOrganizationInfo {
    internal_numeric_id?: number;
    name?: string;
    slug?: string;
}
export declare const AppOrganizationInfo: S.Schema<AppOrganizationInfo>;
export interface App {
    id?: string;
    internal_numeric_id?: number;
    machine_count?: number;
    name?: string;
    network?: string;
    network_cidr?: string;
    organization?: AppOrganizationInfo;
    status?: string;
    volume_count?: number;
}
export declare const App: S.Schema<App>;
export interface GetAppCertificateRequest {
    /** Fly App Name */
    app_name: string;
    /** Certificate Hostname */
    hostname: string;
}
export declare const GetAppCertificateRequest: S.Schema<GetAppCertificateRequest>;
export interface GetCurrentTokenRequest {
}
export declare const GetCurrentTokenRequest: S.Schema<GetCurrentTokenRequest>;
export type MainTokenInfoAppsList = Array<string>;
export declare const MainTokenInfoAppsList: S.Schema<MainTokenInfoAppsList>;
export interface MainTokenInfo {
    apps?: MainTokenInfoAppsList;
    org_slug?: string;
    organization?: string;
    /** Machine the token is restricted to (FromMachine caveat) */
    restricted_to_machine?: string;
    /** Machine making the request */
    source_machine_id?: string;
    token_id?: string;
    /** User identifier if token is for a user */
    user?: string;
}
export declare const MainTokenInfo: S.Schema<MainTokenInfo>;
export type CurrentTokenResponseTokensList = Array<MainTokenInfo>;
export declare const CurrentTokenResponseTokensList: S.Schema<CurrentTokenResponseTokensList>;
export interface CurrentTokenResponse {
    tokens?: CurrentTokenResponseTokensList;
}
export declare const CurrentTokenResponse: S.Schema<CurrentTokenResponse>;
export interface GetMachineRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    /** Include machine lease */
    include_leases?: boolean;
}
export declare const GetMachineRequest: S.Schema<GetMachineRequest>;
export interface GetMachineLeaseRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
}
export declare const GetMachineLeaseRequest: S.Schema<GetMachineLeaseRequest>;
export interface GetMachineMemoryRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
}
export declare const GetMachineMemoryRequest: S.Schema<GetMachineMemoryRequest>;
export interface MainMemoryResponse {
    available_mb?: number;
    limit_mb?: number;
}
export declare const MainMemoryResponse: S.Schema<MainMemoryResponse>;
export interface GetMachineMetadataRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
}
export declare const GetMachineMetadataRequest: S.Schema<GetMachineMetadataRequest>;
export type GetMachineMetadataResponseBodyMap = {
    [key: string]: string | undefined;
};
export declare const GetMachineMetadataResponseBodyMap: S.Schema<GetMachineMetadataResponseBodyMap>;
export type GetMachineMetadataResponse = GetMachineMetadataResponseBodyMap;
export declare const GetMachineMetadataResponse: S.Schema<GetMachineMetadataResponse>;
export interface GetMachineMetadataKeyRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    /** Metadata Key */
    key: string;
}
export declare const GetMachineMetadataKeyRequest: S.Schema<GetMachineMetadataKeyRequest>;
export interface MetadataValueResponse {
    value?: string;
}
export declare const MetadataValueResponse: S.Schema<MetadataValueResponse>;
export type PlacementWeights = {
    [key: string]: number | undefined;
};
export declare const PlacementWeights: S.Schema<PlacementWeights>;
export interface GetPlacementsRequest {
    /** Resource requirements for the Machine to simulate. Defaults to a performance-1x machine */
    compute?: FlyMachineGuest;
    /** Number of machines to simulate placement. Defaults to 0, which returns the org-specific limit for each region. */
    count?: number;
    org_slug: string;
    /** Region expression for placement as a comma-delimited set of regions or aliases. Defaults to "[region],any", to prefer the API endpoint's local region with any other region as fallback. */
    region?: string;
    volume_name?: string;
    volume_size_bytes?: number;
    /** Optional weights to override default placement preferences. */
    weights?: PlacementWeights;
}
export declare const GetPlacementsRequest: S.Schema<GetPlacementsRequest>;
export interface PlacementRegionPlacement {
    concurrency?: number;
    count?: number;
    region?: string;
}
export declare const PlacementRegionPlacement: S.Schema<PlacementRegionPlacement>;
export type MainGetPlacementsResponseRegionsList = Array<PlacementRegionPlacement>;
export declare const MainGetPlacementsResponseRegionsList: S.Schema<MainGetPlacementsResponseRegionsList>;
export interface MainGetPlacementsResponse {
    regions?: MainGetPlacementsResponseRegionsList;
}
export declare const MainGetPlacementsResponse: S.Schema<MainGetPlacementsResponse>;
export interface GetPostgresRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
}
export declare const GetPostgresRequest: S.Schema<GetPostgresRequest>;
export interface GetRegionsRequest {
}
export declare const GetRegionsRequest: S.Schema<GetRegionsRequest>;
export interface MainRegionRow {
    code?: string;
    deprecated?: boolean;
    gateway_available?: boolean;
    geo_region?: string;
    latitude?: number;
    longitude?: number;
    mpg_available?: boolean;
    name?: string;
    requires_paid_plan?: boolean;
}
export declare const MainRegionRow: S.Schema<MainRegionRow>;
export type MainRegionResponseRegionsList = Array<MainRegionRow>;
export declare const MainRegionResponseRegionsList: S.Schema<MainRegionResponseRegionsList>;
export interface MainRegionResponse {
    nearest?: string;
    regions?: MainRegionResponseRegionsList;
}
export declare const MainRegionResponse: S.Schema<MainRegionResponse>;
export interface GetSecretRequest {
    /** Fly App Name */
    app_name: string;
    /** App secret name */
    secret_name: string;
    /** Minimum secrets version to return. Returned when setting a new secret */
    min_version?: string;
    /** Show the secret value. */
    show_secrets?: boolean;
}
export declare const GetSecretRequest: S.Schema<GetSecretRequest>;
export interface AppSecret {
    created_at?: string;
    digest?: string;
    name?: string;
    updated_at?: string;
    value?: string;
}
export declare const AppSecret: S.Schema<AppSecret>;
export interface GetSecretKeyRequest {
    /** Fly App Name */
    app_name: string;
    /** Secret key name */
    secret_name: string;
    /** Minimum secrets version to return. Returned when setting a new secret */
    min_version?: string;
}
export declare const GetSecretKeyRequest: S.Schema<GetSecretKeyRequest>;
export interface SecretKey {
    created_at?: string;
    name?: string;
    public_key?: string;
    type?: string;
    updated_at?: string;
}
export declare const SecretKey: S.Schema<SecretKey>;
export interface GetVolumeByIdRequest {
    /** Fly App Name */
    app_name: string;
    /** Volume ID */
    volume_id: string;
}
export declare const GetVolumeByIdRequest: S.Schema<GetVolumeByIdRequest>;
export interface ListAppCertificatesRequest {
    /** Fly App Name */
    app_name: string;
    /** Hostname filter (substring match) */
    filter?: string;
    /** Pagination cursor from previous response */
    cursor?: string;
    /** Number of results per page (default 25, max 500) */
    limit?: number;
}
export declare const ListAppCertificatesRequest: S.Schema<ListAppCertificatesRequest>;
export interface CertificateSummary {
    acme_alpn_configured?: boolean;
    acme_dns_configured?: boolean;
    acme_http_configured?: boolean;
    acme_requested?: boolean;
    configured?: boolean;
    created_at?: string;
    dns_provider?: string;
    has_custom_certificate?: boolean;
    has_fly_certificate?: boolean;
    hostname?: string;
    ownership_txt_configured?: boolean;
    status?: string;
    updated_at?: string;
}
export declare const CertificateSummary: S.Schema<CertificateSummary>;
export type ListCertificatesResponseCertificatesList = Array<CertificateSummary>;
export declare const ListCertificatesResponseCertificatesList: S.Schema<ListCertificatesResponseCertificatesList>;
export interface ListCertificatesResponse {
    certificates?: ListCertificatesResponseCertificatesList;
    next_cursor?: string;
    total_count?: number;
}
export declare const ListCertificatesResponse: S.Schema<ListCertificatesResponse>;
export interface ListAppIPAssignmentsRequest {
    /** Fly App Name */
    app_name: string;
}
export declare const ListAppIPAssignmentsRequest: S.Schema<ListAppIPAssignmentsRequest>;
export interface IPAssignment {
    created_at?: string;
    egress?: boolean;
    ip?: string;
    region?: string;
    service_name?: string;
    shared?: boolean;
    type?: string;
}
export declare const IPAssignment: S.Schema<IPAssignment>;
export type ListIPAssignmentsResponseIpsList = Array<IPAssignment>;
export declare const ListIPAssignmentsResponseIpsList: S.Schema<ListIPAssignmentsResponseIpsList>;
export interface ListIPAssignmentsResponse {
    ips?: ListIPAssignmentsResponseIpsList;
}
export declare const ListIPAssignmentsResponse: S.Schema<ListIPAssignmentsResponse>;
export interface ListAppsRequest {
    /** The org slug, or 'personal', to filter apps */
    org_slug: string;
    /** Filter apps by role */
    app_role?: string;
}
export declare const ListAppsRequest: S.Schema<ListAppsRequest>;
export type ListAppsResponseAppsList = Array<App>;
export declare const ListAppsResponseAppsList: S.Schema<ListAppsResponseAppsList>;
export interface ListAppsResponse {
    apps?: ListAppsResponseAppsList;
    total_apps?: number;
}
export declare const ListAppsResponse: S.Schema<ListAppsResponse>;
export interface ListMachineEventsRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    /** The number of events to fetch (max of 50). If omitted, this is set to 20 by default. */
    limit?: number;
}
export declare const ListMachineEventsRequest: S.Schema<ListMachineEventsRequest>;
export type ListMachineEventsResponseBodyList = Array<MachineEvent>;
export declare const ListMachineEventsResponseBodyList: S.Schema<ListMachineEventsResponseBodyList>;
export type ListMachineEventsResponse = ListMachineEventsResponseBodyList;
export declare const ListMachineEventsResponse: S.Schema<ListMachineEventsResponse>;
export interface ListMachineProcessesRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    /** Sort by */
    sort_by?: string;
    /** Order */
    order?: string;
}
export declare const ListMachineProcessesRequest: S.Schema<ListMachineProcessesRequest>;
export interface ListenSocket {
    address?: string;
    proto?: string;
}
export declare const ListenSocket: S.Schema<ListenSocket>;
export type ProcessStatListenSocketsList = Array<ListenSocket>;
export declare const ProcessStatListenSocketsList: S.Schema<ProcessStatListenSocketsList>;
export interface ProcessStat {
    command?: string;
    cpu?: number;
    directory?: string;
    listen_sockets?: ProcessStatListenSocketsList;
    pid?: number;
    rss?: number;
    rtime?: number;
    stime?: number;
}
export declare const ProcessStat: S.Schema<ProcessStat>;
export type ListMachineProcessesResponseBodyList = Array<ProcessStat>;
export declare const ListMachineProcessesResponseBodyList: S.Schema<ListMachineProcessesResponseBodyList>;
export type ListMachineProcessesResponse = ListMachineProcessesResponseBodyList;
export declare const ListMachineProcessesResponse: S.Schema<ListMachineProcessesResponse>;
export interface ListMachinesRequest {
    /** Fly App Name */
    app_name: string;
    /** Include deleted machines */
    include_deleted?: boolean;
    /** Include machine leases */
    include_leases?: boolean;
    /** Region filter */
    region?: string;
    /** comma separated list of states to filter (created, started, stopped, suspended) */
    state?: string;
    /** Only return summary info about machines (omit config, checks, events, host_status, nonce, etc.) */
    summary?: boolean;
    /** Filter by a machine metadata key and exact value. Replace {key} with the metadata key, for example metadata.foo=bar. Specify multiple metadata filters to require all matches. */
    metadata__key_?: string;
}
export declare const ListMachinesRequest: S.Schema<ListMachinesRequest>;
export type ListMachinesResponseBodyList = Array<Machine>;
export declare const ListMachinesResponseBodyList: S.Schema<ListMachinesResponseBodyList>;
export type ListMachinesResponse = ListMachinesResponseBodyList;
export declare const ListMachinesResponse: S.Schema<ListMachinesResponse>;
export interface ListMachinesOrgRequest {
    /** Fly Organization Slug */
    org_slug: string;
    /** Include deleted machines */
    include_deleted?: boolean;
    /** Region filter */
    region?: string;
    /** Comma separated list of states to filter (created, started, stopped, suspended) */
    state?: string;
    /** Omit config from responses */
    summary?: boolean;
    /** Only return machines updated after this time. Timestamp must be in the RFC 3339 format */
    updated_after?: string;
    /** Pagination cursor from previous response (takes precedence over updated_after). Note that there is no guarantee that all machines returned by this endpoint are sorted by their updated_at fields. Pagination may reveal machines older than the last updated_at. */
    cursor?: string;
    /** The number of machines to fetch (max of 1000). This limit is advisory. Responses may be shorter, or even empty, even when more machines remain. If omitted, the maximum is used */
    limit?: number;
}
export declare const ListMachinesOrgRequest: S.Schema<ListMachinesOrgRequest>;
export type OrgMachinesResponseErrorRegionsList = Array<string>;
export declare const OrgMachinesResponseErrorRegionsList: S.Schema<OrgMachinesResponseErrorRegionsList>;
export type MachineOverviewConfigMetadataMap = {
    [key: string]: string | undefined;
};
export declare const MachineOverviewConfigMetadataMap: S.Schema<MachineOverviewConfigMetadataMap>;
export interface MachineOverviewConfig {
    guest?: FlyMachineGuest;
    image?: string;
    metadata?: MachineOverviewConfigMetadataMap;
}
export declare const MachineOverviewConfig: S.Schema<MachineOverviewConfig>;
export interface OrgMachine {
    app_name?: string;
    config?: MachineOverviewConfig;
    created_at?: string;
    id?: string;
    name?: string;
    private_ip?: string;
    region?: string;
    state?: string;
    updated_at?: string;
    version?: string;
}
export declare const OrgMachine: S.Schema<OrgMachine>;
export type OrgMachinesResponseMachinesList = Array<OrgMachine>;
export declare const OrgMachinesResponseMachinesList: S.Schema<OrgMachinesResponseMachinesList>;
export interface OrgMachinesResponse {
    error_regions?: OrgMachinesResponseErrorRegionsList;
    last_machine_id?: string;
    last_updated_at?: string;
    machines?: OrgMachinesResponseMachinesList;
    next_cursor?: string;
}
export declare const OrgMachinesResponse: S.Schema<OrgMachinesResponse>;
export interface ListMachineVersionsRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
}
export declare const ListMachineVersionsRequest: S.Schema<ListMachineVersionsRequest>;
export interface MachineVersion {
    user_config?: FlyMachineConfig;
    version?: string;
}
export declare const MachineVersion: S.Schema<MachineVersion>;
export type ListMachineVersionsResponseBodyList = Array<MachineVersion>;
export declare const ListMachineVersionsResponseBodyList: S.Schema<ListMachineVersionsResponseBodyList>;
export type ListMachineVersionsResponse = ListMachineVersionsResponseBodyList;
export declare const ListMachineVersionsResponse: S.Schema<ListMachineVersionsResponse>;
export interface ListPostgresRequest {
    /** Fly Organization Slug */
    org_slug: string;
    /** Include deleted clusters */
    include_deleted?: boolean;
}
export declare const ListPostgresRequest: S.Schema<ListPostgresRequest>;
/** Apps attached to the cluster. */
export type PostgresClusterSummaryAttachedAppsList = Array<PostgresAttachedApp>;
export declare const PostgresClusterSummaryAttachedAppsList: S.Schema<PostgresClusterSummaryAttachedAppsList>;
/** Plan slug. */
export type PostgresClusterSummaryPlan = "basic" | "starter" | "launch" | "scale" | "Performance";
export declare const PostgresClusterSummaryPlan: any;
/** Current lifecycle status. */
export type PostgresClusterSummaryStatus = "creating" | "initializing" | "ready" | "deleting" | "deleted" | "failed";
export declare const PostgresClusterSummaryStatus: any;
export interface PostgresClusterSummary {
    /** Apps attached to the cluster. */
    attached_apps?: PostgresClusterSummaryAttachedAppsList;
    /** RFC 3339 creation timestamp. */
    created_at?: string;
    /** RFC 3339 deletion timestamp; present for deleted clusters. */
    deleted_at?: string;
    /** Cluster ID. */
    id?: string;
    /** Cluster name. */
    name?: string;
    /** Plan slug. */
    plan?: PostgresClusterSummaryPlan;
    /** Fly region code. */
    region?: string;
    /** Current lifecycle status. */
    status?: PostgresClusterSummaryStatus;
}
export declare const PostgresClusterSummary: S.Schema<PostgresClusterSummary>;
export type ListPostgresClustersResponseDataList = Array<PostgresClusterSummary>;
export declare const ListPostgresClustersResponseDataList: S.Schema<ListPostgresClustersResponseDataList>;
export interface ListPostgresClustersResponse {
    data?: ListPostgresClustersResponseDataList;
}
export declare const ListPostgresClustersResponse: S.Schema<ListPostgresClustersResponse>;
export interface ListPostgresBackupsRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
}
export declare const ListPostgresBackupsRequest: S.Schema<ListPostgresBackupsRequest>;
/** Backup type. */
export type PostgresBackupType = "full" | "incr" | "diff";
export declare const PostgresBackupType: any;
export interface PostgresBackup {
    /** RFC 3339 stop timestamp. */
    finished_at?: string;
    /** Backup ID. */
    id?: string;
    /** Backup size in bytes. */
    size_bytes?: number;
    /** RFC 3339 start timestamp. */
    started_at?: string;
    /** Backup status. */
    status?: string;
    /** Backup type. */
    type?: PostgresBackupType;
}
export declare const PostgresBackup: S.Schema<PostgresBackup>;
export type ListPostgresBackupsResponseDataList = Array<PostgresBackup>;
export declare const ListPostgresBackupsResponseDataList: S.Schema<ListPostgresBackupsResponseDataList>;
export interface ListPostgresBackupsResponse {
    data?: ListPostgresBackupsResponseDataList;
}
export declare const ListPostgresBackupsResponse: S.Schema<ListPostgresBackupsResponse>;
export interface ListPostgresDatabasesRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
}
export declare const ListPostgresDatabasesRequest: S.Schema<ListPostgresDatabasesRequest>;
export type ListPostgresDatabasesResponseDataList = Array<PostgresDatabase>;
export declare const ListPostgresDatabasesResponseDataList: S.Schema<ListPostgresDatabasesResponseDataList>;
export interface ListPostgresDatabasesResponse {
    data?: ListPostgresDatabasesResponseDataList;
}
export declare const ListPostgresDatabasesResponse: S.Schema<ListPostgresDatabasesResponse>;
export interface ListPostgresExtensionsRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Database Name */
    database_name: string;
}
export declare const ListPostgresExtensionsRequest: S.Schema<ListPostgresExtensionsRequest>;
export interface PostgresInstalledExtension {
    /** Schema the extension is installed into. */
    schema?: string;
    /** Installed version. */
    version?: string;
}
export declare const PostgresInstalledExtension: S.Schema<PostgresInstalledExtension>;
export interface PostgresExtension {
    /** Default version installed when enabled. */
    default_version?: string;
    /** Human-readable description. */
    description?: string;
    /** Installation details, or null when the extension is not installed. */
    installed?: PostgresInstalledExtension;
    /** Extension name. */
    name?: string;
    /** Whether this is a system extension that cannot be disabled. */
    system?: boolean;
}
export declare const PostgresExtension: S.Schema<PostgresExtension>;
export type ListPostgresExtensionsResponseDataList = Array<PostgresExtension>;
export declare const ListPostgresExtensionsResponseDataList: S.Schema<ListPostgresExtensionsResponseDataList>;
export interface ListPostgresExtensionsResponse {
    data?: ListPostgresExtensionsResponseDataList;
}
export declare const ListPostgresExtensionsResponse: S.Schema<ListPostgresExtensionsResponse>;
export interface ListPostgresUsersRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
}
export declare const ListPostgresUsersRequest: S.Schema<ListPostgresUsersRequest>;
export type ListPostgresUsersResponseDataList = Array<PostgresUser>;
export declare const ListPostgresUsersResponseDataList: S.Schema<ListPostgresUsersResponseDataList>;
export interface ListPostgresUsersResponse {
    data?: ListPostgresUsersResponseDataList;
}
export declare const ListPostgresUsersResponse: S.Schema<ListPostgresUsersResponse>;
export interface ListSecretKeysRequest {
    /** Fly App Name */
    app_name: string;
    /** Minimum secrets version to return. Returned when setting a new secret */
    min_version?: string;
    /** Comma-seperated list of secret keys to list */
    types?: string;
}
export declare const ListSecretKeysRequest: S.Schema<ListSecretKeysRequest>;
export type SecretKeysSecretKeysList = Array<SecretKey>;
export declare const SecretKeysSecretKeysList: S.Schema<SecretKeysSecretKeysList>;
export interface SecretKeys {
    secret_keys?: SecretKeysSecretKeysList;
}
export declare const SecretKeys: S.Schema<SecretKeys>;
export interface ListSecretsRequest {
    /** Fly App Name */
    app_name: string;
    /** Minimum secrets version to return. Returned when setting a new secret */
    min_version?: string;
    /** Show the secret values. */
    show_secrets?: boolean;
}
export declare const ListSecretsRequest: S.Schema<ListSecretsRequest>;
export type AppSecretsSecretsList = Array<AppSecret>;
export declare const AppSecretsSecretsList: S.Schema<AppSecretsSecretsList>;
export interface AppSecrets {
    secrets?: AppSecretsSecretsList;
}
export declare const AppSecrets: S.Schema<AppSecrets>;
export interface ListVolumesRequest {
    /** Fly App Name */
    app_name: string;
    /** Only return summary info about volumes (omit blocks, block size, etc) */
    summary?: boolean;
}
export declare const ListVolumesRequest: S.Schema<ListVolumesRequest>;
export type ListVolumesResponseBodyList = Array<Volume>;
export declare const ListVolumesResponseBodyList: S.Schema<ListVolumesResponseBodyList>;
export type ListVolumesResponse = ListVolumesResponseBodyList;
export declare const ListVolumesResponse: S.Schema<ListVolumesResponse>;
export interface ListVolumeSnapshotsRequest {
    /** Fly App Name */
    app_name: string;
    /** Volume ID */
    volume_id: string;
}
export declare const ListVolumeSnapshotsRequest: S.Schema<ListVolumeSnapshotsRequest>;
export interface VolumeSnapshot {
    created_at?: string;
    digest?: string;
    id?: string;
    retention_days?: number;
    size?: number;
    status?: string;
    volume_size?: number;
}
export declare const VolumeSnapshot: S.Schema<VolumeSnapshot>;
export type ListVolumeSnapshotsResponseBodyList = Array<VolumeSnapshot>;
export declare const ListVolumeSnapshotsResponseBodyList: S.Schema<ListVolumeSnapshotsResponseBodyList>;
export type ListVolumeSnapshotsResponse = ListVolumeSnapshotsResponseBodyList;
export declare const ListVolumeSnapshotsResponse: S.Schema<ListVolumeSnapshotsResponse>;
export interface ListVolumesOrgRequest {
    /** Fly Organization Slug */
    org_slug: string;
    /** Include deleted volumes */
    include_deleted?: boolean;
    /** Region filter */
    region?: string;
    /** Comma separated list of volume states to filter */
    state?: string;
    /** Only return summary info about volumes (omit blocks, block size, etc) */
    summary?: boolean;
    /** Only return volumes updated after this time. Timestamp must be in the RFC 3339 format */
    updated_after?: string;
    /** Pagination cursor from previous response (takes precedence over updated_after) */
    cursor?: string;
    /** The number of volumes to fetch (max of 1000). This limit is advisory. Responses may be shorter, even when more volumes remain. If omitted, the maximum is used */
    limit?: number;
}
export declare const ListVolumesOrgRequest: S.Schema<ListVolumesOrgRequest>;
export type OrgVolumeHostStatus = "ok" | "unknown" | "unreachable";
export declare const OrgVolumeHostStatus: any;
export type OrgVolumeType = "local" | "cache";
export declare const OrgVolumeType: any;
export interface OrgVolume {
    app_name?: string;
    attached_alloc_id?: string;
    attached_machine_id?: string;
    auto_backup_enabled?: boolean;
    block_size?: number;
    blocks?: number;
    blocks_avail?: number;
    blocks_free?: number;
    bytes_total?: number;
    bytes_used?: number;
    created_at?: string;
    encrypted?: boolean;
    fstype?: string;
    host_status?: OrgVolumeHostStatus;
    id?: string;
    name?: string;
    region?: string;
    size_gb?: number;
    snapshot_retention?: number;
    state?: string;
    type?: OrgVolumeType;
    updated_at?: string;
    zone?: string;
}
export declare const OrgVolume: S.Schema<OrgVolume>;
export type OrgVolumesResponseVolumesList = Array<OrgVolume>;
export declare const OrgVolumesResponseVolumesList: S.Schema<OrgVolumesResponseVolumesList>;
export interface OrgVolumesResponse {
    last_updated_at?: string;
    last_volume_id?: string;
    next_cursor?: string;
    volumes?: OrgVolumesResponseVolumesList;
}
export declare const OrgVolumesResponse: S.Schema<OrgVolumesResponse>;
export interface MachinesReleaseLeaseRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
}
export declare const MachinesReleaseLeaseRequest: S.Schema<MachinesReleaseLeaseRequest>;
export interface MachinesReleaseLeaseResponse {
}
export declare const MachinesReleaseLeaseResponse: S.Schema<MachinesReleaseLeaseResponse>;
export type PatchMachineMetadataRequestMetadataMap = {
    [key: string]: string | undefined;
};
export declare const PatchMachineMetadataRequestMetadataMap: S.Schema<PatchMachineMetadataRequestMetadataMap>;
export interface PatchMachineMetadataRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    machine_version?: string;
    metadata?: PatchMachineMetadataRequestMetadataMap;
    updated_at?: string;
}
export declare const PatchMachineMetadataRequest: S.Schema<PatchMachineMetadataRequest>;
export interface PatchMachineMetadataResponse {
}
export declare const PatchMachineMetadataResponse: S.Schema<PatchMachineMetadataResponse>;
export interface PostgresUsersCredentialsRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Postgres User Name */
    username: string;
}
export declare const PostgresUsersCredentialsRequest: S.Schema<PostgresUsersCredentialsRequest>;
export interface PostgresUserCredentials {
    /** User password. */
    password?: string;
    /** User name. */
    username?: string;
}
export declare const PostgresUserCredentials: S.Schema<PostgresUserCredentials>;
export interface GetPostgresUserCredentialsResponse {
    data?: PostgresUserCredentials;
}
export declare const GetPostgresUserCredentialsResponse: S.Schema<GetPostgresUserCredentialsResponse>;
export interface ReclaimMachineMemoryRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    amount_mb?: number;
}
export declare const ReclaimMachineMemoryRequest: S.Schema<ReclaimMachineMemoryRequest>;
export interface MainReclaimMemoryResponse {
    actual_mb?: number;
}
export declare const MainReclaimMemoryResponse: S.Schema<MainReclaimMemoryResponse>;
export interface RequestKmsTokenRequest {
}
export declare const RequestKmsTokenRequest: S.Schema<RequestKmsTokenRequest>;
export interface RequestKmsTokenResponse {
}
export declare const RequestKmsTokenResponse: S.Schema<RequestKmsTokenResponse>;
export interface RequestOidcTokenRequest {
    aud?: string;
    aws_principal_tags?: boolean;
}
export declare const RequestOidcTokenRequest: S.Schema<RequestOidcTokenRequest>;
export interface RequestOidcTokenResponse {
}
export declare const RequestOidcTokenResponse: S.Schema<RequestOidcTokenResponse>;
export type RestartMachineRequestSignal = "SIGHUP" | "SIGINT" | "SIGQUIT" | "SIGKILL" | "SIGUSR1" | "SIGUSR2" | "SIGTERM";
export declare const RestartMachineRequestSignal: any;
export interface RestartMachineRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    /** Restart timeout as a Go duration string or number of seconds */
    timeout?: string;
    /** Unix signal name */
    signal?: RestartMachineRequestSignal | (string & {});
}
export declare const RestartMachineRequest: S.Schema<RestartMachineRequest>;
export interface RestartMachineResponse {
}
export declare const RestartMachineResponse: S.Schema<RestartMachineResponse>;
export interface RestorePostgresRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Backup label to restore from, as returned by the backups list. Mutually exclusive with pitr_time. */
    backup_id?: string;
    /** Name for the restored cluster. Defaults to a generated name derived from the source cluster and backup/point in time when omitted or blank. */
    name?: string;
    /** Point in time to restore to, as an RFC3339 timestamp with an explicit offset from UTC (e.g. Z or +02:00). Normalized to UTC and must fall within the cluster's PITR recovery window. Mutually exclusive with backup_id. */
    pitr_time?: string;
}
export declare const RestorePostgresRequest: S.Schema<RestorePostgresRequest>;
export interface RotatePostgresUserPasswordRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Postgres User Name */
    username: string;
    /** Terminate the user's existing sessions after rotating. */
    kill_sessions?: boolean;
}
export declare const RotatePostgresUserPasswordRequest: S.Schema<RotatePostgresUserPasswordRequest>;
export interface RotatePostgresPasswordResponse {
    data?: PostgresUserCredentials;
}
export declare const RotatePostgresPasswordResponse: S.Schema<RotatePostgresPasswordResponse>;
export interface SetMachineMemoryLimitRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    limit_mb?: number;
}
export declare const SetMachineMemoryLimitRequest: S.Schema<SetMachineMemoryLimitRequest>;
export type SetSecretKeyRequestValueList = Array<number>;
export declare const SetSecretKeyRequestValueList: S.Schema<SetSecretKeyRequestValueList>;
export interface SetSecretKeyRequest {
    /** Fly App Name */
    app_name: string;
    /** Secret key name */
    secret_name: string;
    type?: string;
    value?: SetSecretKeyRequestValueList;
}
export declare const SetSecretKeyRequest: S.Schema<SetSecretKeyRequest>;
export type SignalMachineRequestSignal = "SIGABRT" | "SIGALRM" | "SIGFPE" | "SIGHUP" | "SIGILL" | "SIGINT" | "SIGKILL" | "SIGPIPE" | "SIGQUIT" | "SIGSEGV" | "SIGTERM" | "SIGTRAP" | "SIGUSR1" | "SIGUSR2";
export declare const SignalMachineRequestSignal: any;
export interface SignalMachineRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    signal?: SignalMachineRequestSignal | (string & {});
}
export declare const SignalMachineRequest: S.Schema<SignalMachineRequest>;
export interface SignalMachineResponse {
}
export declare const SignalMachineResponse: S.Schema<SignalMachineResponse>;
export interface SignSecretKeyRequest {
    /** Fly App Name */
    app_name: string;
    /** Secret key name */
    secret_name: string;
    /** Minimum secrets version to return. Returned when setting a new secret */
    min_version?: string;
    plaintext?: string;
}
export declare const SignSecretKeyRequest: S.Schema<SignSecretKeyRequest>;
export interface SignSecretkeyResponse {
    signature?: string;
}
export declare const SignSecretkeyResponse: S.Schema<SignSecretkeyResponse>;
export interface StartMachineRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
}
export declare const StartMachineRequest: S.Schema<StartMachineRequest>;
export interface StartMachineResponse {
}
export declare const StartMachineResponse: S.Schema<StartMachineResponse>;
export type StopMachineRequestSignal = "SIGHUP" | "SIGINT" | "SIGQUIT" | "SIGKILL" | "SIGUSR1" | "SIGUSR2" | "SIGTERM";
export declare const StopMachineRequestSignal: any;
export interface StopMachineRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    signal?: StopMachineRequestSignal | (string & {});
    timeout?: string;
}
export declare const StopMachineRequest: S.Schema<StopMachineRequest>;
export interface StopMachineResponse {
}
export declare const StopMachineResponse: S.Schema<StopMachineResponse>;
export interface SuspendMachineRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
}
export declare const SuspendMachineRequest: S.Schema<SuspendMachineRequest>;
export interface SuspendMachineResponse {
}
export declare const SuspendMachineResponse: S.Schema<SuspendMachineResponse>;
export interface UncordonMachineRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
}
export declare const UncordonMachineRequest: S.Schema<UncordonMachineRequest>;
export interface UncordonMachineResponse {
}
export declare const UncordonMachineResponse: S.Schema<UncordonMachineResponse>;
export interface UpdateMachineRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    /** An object defining the Machine configuration */
    config?: FlyMachineConfig;
    current_version?: string;
    lease_ttl?: number;
    min_secrets_version?: number;
    /** Unique name for this Machine. If omitted, one is generated for you */
    name?: string;
    /** The target region. Omitting this param launches in the same region as your WireGuard peer connection (somewhere near you). */
    region?: string;
    skip_launch?: boolean;
    skip_secrets?: boolean;
    skip_service_registration?: boolean;
}
export declare const UpdateMachineRequest: S.Schema<UpdateMachineRequest>;
export type UpdateMachineMetadataRequestMetadataMap = {
    [key: string]: string | undefined;
};
export declare const UpdateMachineMetadataRequestMetadataMap: S.Schema<UpdateMachineMetadataRequestMetadataMap>;
export interface UpdateMachineMetadataRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    machine_version?: string;
    metadata?: UpdateMachineMetadataRequestMetadataMap;
    updated_at?: string;
}
export declare const UpdateMachineMetadataRequest: S.Schema<UpdateMachineMetadataRequest>;
export interface UpdateMachineMetadataResponse {
}
export declare const UpdateMachineMetadataResponse: S.Schema<UpdateMachineMetadataResponse>;
/** New role for the user. */
export type UpdatePostgresUserRoleRequestRole = "schema_admin" | "writer" | "reader";
export declare const UpdatePostgresUserRoleRequestRole: any;
export interface UpdatePostgresUserRoleRequest {
    /** Managed Postgres Cluster ID */
    postgres_cluster_id: string;
    /** Postgres User Name */
    username: string;
    /** New role for the user. */
    role: UpdatePostgresUserRoleRequestRole | (string & {});
}
export declare const UpdatePostgresUserRoleRequest: S.Schema<UpdatePostgresUserRoleRequest>;
export interface UpdatePostgresUserRoleResponse {
}
export declare const UpdatePostgresUserRoleResponse: S.Schema<UpdatePostgresUserRoleResponse>;
export type UpdateSecretsRequestValuesMap = {
    [key: string]: string | undefined;
};
export declare const UpdateSecretsRequestValuesMap: S.Schema<UpdateSecretsRequestValuesMap>;
export interface UpdateSecretsRequest {
    /** Fly App Name */
    app_name: string;
    values?: UpdateSecretsRequestValuesMap;
}
export declare const UpdateSecretsRequest: S.Schema<UpdateSecretsRequest>;
export type AppSecretsUpdateRespSecretsList = Array<AppSecret>;
export declare const AppSecretsUpdateRespSecretsList: S.Schema<AppSecretsUpdateRespSecretsList>;
export interface AppSecretsUpdateResp {
    /** DEPRECATED */
    Version?: number;
    secrets?: AppSecretsUpdateRespSecretsList;
    version?: number;
}
export declare const AppSecretsUpdateResp: S.Schema<AppSecretsUpdateResp>;
export interface UpdateVolumeRequest {
    /** Fly App Name */
    app_name: string;
    /** Volume ID */
    volume_id: string;
    auto_backup_enabled?: boolean;
    snapshot_retention?: number;
}
export declare const UpdateVolumeRequest: S.Schema<UpdateVolumeRequest>;
export interface UpsertMachineMetadataRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    /** Metadata Key */
    key: string;
    updated_at?: string;
    value?: string;
}
export declare const UpsertMachineMetadataRequest: S.Schema<UpsertMachineMetadataRequest>;
export interface UpsertMachineMetadataResponse {
}
export declare const UpsertMachineMetadataResponse: S.Schema<UpsertMachineMetadataResponse>;
export interface VerifySecretKeyRequest {
    /** Fly App Name */
    app_name: string;
    /** Secret key name */
    secret_name: string;
    /** Minimum secrets version to return. Returned when setting a new secret */
    min_version?: string;
    plaintext?: string;
    signature?: string;
}
export declare const VerifySecretKeyRequest: S.Schema<VerifySecretKeyRequest>;
export interface VerifySecretKeyResponse {
}
export declare const VerifySecretKeyResponse: S.Schema<VerifySecretKeyResponse>;
export type WaitMachineRequestState = "started" | "stopped" | "suspended" | "destroyed" | "failed" | "settled";
export declare const WaitMachineRequestState: any;
export interface WaitMachineRequest {
    /** Fly App Name */
    app_name: string;
    /** Machine ID */
    machine_id: string;
    /** 26-character Machine version ID */
    version?: string;
    /** 26-character Machine version ID (deprecated; use version) */
    instance_id?: string;
    /** 26-character Machine event ID to start waiting after */
    from_event_id?: string;
    /** wait timeout. default 60s */
    timeout?: number;
    /** desired state(s), supports repeated or comma-separated values */
    state?: WaitMachineRequestState | (string & {});
}
export declare const WaitMachineRequest: S.Schema<WaitMachineRequest>;
export interface WaitMachineResponse {
    event_id?: string;
    ok?: boolean;
    state?: string;
    version?: string;
}
export declare const WaitMachineResponse: S.Schema<WaitMachineResponse>;
export type AuthenticateTokenError = BadRequest | FlyIoOpError;
/** Authenticate token header Verify a token header without checking resource access. */
export declare const authenticateToken: API.OperationMethod<AuthenticateTokenRequest, AuthenticateTokenResponse, AuthenticateTokenError, FlyIoOpContext>;
export type AuthorizeTokenError = BadRequest | FlyIoOpError;
/** Authorize token for resource access Verify a token header and validate it against a requested access scope. */
export declare const authorizeToken: API.OperationMethod<AuthorizeTokenRequest, AuthorizeResponse, AuthorizeTokenError, FlyIoOpContext>;
export type CheckAppCertificateError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Check DNS and re-validate certificate */
export declare const checkAppCertificate: API.OperationMethod<CheckAppCertificateRequest, CertificateCheckResponse, CheckAppCertificateError, FlyIoOpContext>;
export type CordonMachineError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Cordon Machine “Cordoning” a Machine refers to disabling its services, so the Fly Proxy won’t route requests to it. In flyctl this is used by blue/green deployments; one set of Machines is started up with services disabled, and when they are all healthy, the services are enabled on the new Machines and disabled on the old ones. */
export declare const cordonMachine: API.OperationMethod<CordonMachineRequest, CordonMachineResponse, CordonMachineError, FlyIoOpContext>;
export type CreateAppError = BadRequest | Forbidden | NotFound | Conflict | UnprocessableEntity | FlyIoOpError;
/** Create App Create an app with the specified details in the request body. */
export declare const createApp: API.OperationMethod<CreateAppRequest, CreateAppResponse, CreateAppError, FlyIoOpContext>;
export type CreateAppAcmeCertificateError = BadRequest | Forbidden | NotFound | Conflict | UnprocessableEntity | FlyIoOpError;
/** Request ACME certificate */
export declare const createAppAcmeCertificate: API.OperationMethod<CreateAppAcmeCertificateRequest, CertificateDetail, CreateAppAcmeCertificateError, FlyIoOpContext>;
export type CreateAppCustomCertificateError = BadRequest | Forbidden | NotFound | Conflict | UnprocessableEntity | FlyIoOpError;
/** Upload custom certificate */
export declare const createAppCustomCertificate: API.OperationMethod<CreateAppCustomCertificateRequest, CertificateDetail, CreateAppCustomCertificateError, FlyIoOpContext>;
export type CreateAppDeployTokenError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Create App deploy token */
export declare const createAppDeployToken: API.OperationMethod<CreateAppDeployTokenRequest, CreateAppDeployTokenResponse, CreateAppDeployTokenError, FlyIoOpContext>;
export type CreateAppIPAssignmentError = BadRequest | Forbidden | NotFound | Conflict | FlyIoOpError;
/** Assign new IP address to app */
export declare const createAppIPAssignment: API.OperationMethod<CreateAppIPAssignmentRequest, AssignIPResponse, CreateAppIPAssignmentError, FlyIoOpContext>;
export type CreateMachineError = BadRequest | Forbidden | NotFound | Conflict | FlyIoOpError;
/** Create Machine Create a Machine within a specific app using the details provided in the request body. **Important**: This request can fail, and you’re responsible for handling that failure. If you ask for a large Machine, or a Machine in a region we happen to be at capacity for, you might need to retry the request, or to fall back to another region. If you’re working directly with the Machines API, you’re taking some responsibility for your own orchestration! */
export declare const createMachine: API.OperationMethod<CreateMachineRequest, Machine, CreateMachineError, FlyIoOpContext>;
export type CreateMachineLeaseError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Create Lease Create a lease for a specific Machine within an app using the details provided in the request body. Machine leases can be used to obtain an exclusive lock on modifying a Machine. */
export declare const createMachineLease: API.OperationMethod<CreateMachineLeaseRequest, Lease, CreateMachineLeaseError, FlyIoOpContext>;
export type CreatePostgresError = BadRequest | NotFound | UnprocessableEntity | FlyIoOpError;
/** Create Postgres Cluster Create a Managed Postgres cluster for the organization named in the request body. Provisioning is asynchronous, and a name is generated when one is not supplied. */
export declare const createPostgres: API.OperationMethod<CreatePostgresRequest, ShowPostgresClusterResponse, CreatePostgresError, FlyIoOpContext>;
export type CreatePostgresAttachmentError = NotFound | FlyIoOpError;
/** Attach Cluster to App Attach a specific cluster to a Fly app. The attachment is created if it does not already exist. */
export declare const createPostgresAttachment: API.OperationMethod<CreatePostgresAttachmentRequest, CreatePostgresAttachmentResponse, CreatePostgresAttachmentError, FlyIoOpContext>;
export type CreatePostgresBackupError = NotFound | Conflict | FlyIoOpError;
/** Create Backup Create a backup for a specific cluster. The backup runs asynchronously and is rejected if one is already in progress. */
export declare const createPostgresBackup: API.OperationMethod<CreatePostgresBackupRequest, CreatePostgresBackupResponse, CreatePostgresBackupError, FlyIoOpContext>;
export type CreatePostgresDatabaseError = BadRequest | NotFound | UnprocessableEntity | FlyIoOpError;
/** Create Database Create a database within a specific cluster. */
export declare const createPostgresDatabase: API.OperationMethod<CreatePostgresDatabaseRequest, PostgresDatabaseResponse, CreatePostgresDatabaseError, FlyIoOpContext>;
export type CreatePostgresUserError = BadRequest | NotFound | Conflict | UnprocessableEntity | FlyIoOpError;
/** Create User Create a Postgres user within a specific cluster. Fetch the generated password from the credentials endpoint. */
export declare const createPostgresUser: API.OperationMethod<CreatePostgresUserRequest, CreatePostgresUserResponse, CreatePostgresUserError, FlyIoOpContext>;
export type CreateSecretError = BadRequest | Forbidden | NotFound | Conflict | FlyIoOpError;
/** Create or update Secret */
export declare const createSecret: API.OperationMethod<CreateSecretRequest, SetAppSecretResponse, CreateSecretError, FlyIoOpContext>;
export type CreateVolumeError = BadRequest | Forbidden | NotFound | Conflict | FlyIoOpError;
/** Create Volume Create a volume for a specific app using the details provided in the request body. */
export declare const createVolume: API.OperationMethod<CreateVolumeRequest, Volume, CreateVolumeError, FlyIoOpContext>;
export type CreateVolumeSnapshotError = BadRequest | Forbidden | NotFound | Conflict | FlyIoOpError;
/** Create Snapshot Create a snapshot for a specific volume within an app. */
export declare const createVolumeSnapshot: API.OperationMethod<CreateVolumeSnapshotRequest, CreateVolumeSnapshotResponse, CreateVolumeSnapshotError, FlyIoOpContext>;
export type DecryptSecretKeyError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Decrypt with a secret key */
export declare const decryptSecretKey: API.OperationMethod<DecryptSecretKeyRequest, DecryptSecretkeyResponse, DecryptSecretKeyError, FlyIoOpContext>;
export type DeleteAppError = Forbidden | NotFound | FlyIoOpError;
/** Destroy App Delete an app by its name. */
export declare const deleteApp: API.OperationMethod<DeleteAppRequest, DeleteAppResponse, DeleteAppError, FlyIoOpContext>;
export type DeleteAppAcmeCertificateError = Forbidden | NotFound | FlyIoOpError;
/** Remove ACME certificates */
export declare const deleteAppAcmeCertificate: API.OperationMethod<DeleteAppAcmeCertificateRequest, CertificateDetail, DeleteAppAcmeCertificateError, FlyIoOpContext>;
export type DeleteAppCertificateError = Forbidden | NotFound | FlyIoOpError;
/** Remove certificate */
export declare const deleteAppCertificate: API.OperationMethod<DeleteAppCertificateRequest, DeleteAppCertificateResponse, DeleteAppCertificateError, FlyIoOpContext>;
export type DeleteAppCustomCertificateError = Forbidden | NotFound | FlyIoOpError;
/** Remove custom certificate */
export declare const deleteAppCustomCertificate: API.OperationMethod<DeleteAppCustomCertificateRequest, DestroyCustomCertificateResponse, DeleteAppCustomCertificateError, FlyIoOpContext>;
export type DeleteAppIPAssignmentError = Forbidden | NotFound | FlyIoOpError;
/** Remove IP assignment from app */
export declare const deleteAppIPAssignment: API.OperationMethod<DeleteAppIPAssignmentRequest, DeleteAppIPAssignmentResponse, DeleteAppIPAssignmentError, FlyIoOpContext>;
export type DeleteMachineError = Forbidden | NotFound | Conflict | FlyIoOpError;
/** Destroy Machine Delete a specific Machine within an app by Machine ID, with an optional force parameter to force kill the Machine if it's running. */
export declare const deleteMachine: API.OperationMethod<DeleteMachineRequest, DeleteMachineResponse, DeleteMachineError, FlyIoOpContext>;
export type DeleteMachineMetadataError = Forbidden | NotFound | FlyIoOpError;
/** Delete Metadata Delete metadata for a specific Machine within an app by providing a metadata key. */
export declare const deleteMachineMetadata: API.OperationMethod<DeleteMachineMetadataRequest, DeleteMachineMetadataResponse, DeleteMachineMetadataError, FlyIoOpContext>;
export type DeletePostgresError = NotFound | FlyIoOpError;
/** Delete Postgres Cluster Delete a Managed Postgres cluster. The cluster is marked for deletion and removed asynchronously. */
export declare const deletePostgres: API.OperationMethod<DeletePostgresRequest, DeletePostgresResponse, DeletePostgresError, FlyIoOpContext>;
export type DeletePostgresAttachmentError = NotFound | FlyIoOpError;
/** Detach Cluster from App Detach a specific cluster from a Fly app. */
export declare const deletePostgresAttachment: API.OperationMethod<DeletePostgresAttachmentRequest, DeletePostgresAttachmentResponse, DeletePostgresAttachmentError, FlyIoOpContext>;
export type DeletePostgresDatabaseError = BadRequest | NotFound | FlyIoOpError;
/** Drop Database Delete a specific database within a cluster, along with objects that depend on it. */
export declare const deletePostgresDatabase: API.OperationMethod<DeletePostgresDatabaseRequest, PostgresDatabaseResponse, DeletePostgresDatabaseError, FlyIoOpContext>;
export type DeletePostgresUserError = BadRequest | NotFound | FlyIoOpError;
/** Delete User Delete a specific Postgres user within a cluster. */
export declare const deletePostgresUser: API.OperationMethod<DeletePostgresUserRequest, DeletePostgresUserResponse, DeletePostgresUserError, FlyIoOpContext>;
export type DeleteSecretError = Forbidden | NotFound | FlyIoOpError;
/** Delete an app secret */
export declare const deleteSecret: API.OperationMethod<DeleteSecretRequest, DeleteAppSecretResponse, DeleteSecretError, FlyIoOpContext>;
export type DeleteSecretKeyError = Forbidden | NotFound | FlyIoOpError;
/** Delete an app's secret key */
export declare const deleteSecretKey: API.OperationMethod<DeleteSecretKeyRequest, DeleteSecretkeyResponse, DeleteSecretKeyError, FlyIoOpContext>;
export type DeleteVolumeError = Forbidden | NotFound | Conflict | FlyIoOpError;
/** Destroy Volume Delete a specific volume within an app by volume ID. */
export declare const deleteVolume: API.OperationMethod<DeleteVolumeRequest, Volume, DeleteVolumeError, FlyIoOpContext>;
export type DisablePostgresExtensionError = BadRequest | NotFound | UnprocessableEntity | FlyIoOpError;
/** Disable Extension Disable a specific Postgres extension within a database, optionally dropping objects that depend on it. System extensions cannot be disabled. */
export declare const disablePostgresExtension: API.OperationMethod<DisablePostgresExtensionRequest, DisablePostgresExtensionResponse, DisablePostgresExtensionError, FlyIoOpContext>;
export type EnablePostgresExtensionError = BadRequest | NotFound | Conflict | UnprocessableEntity | FlyIoOpError;
/** Enable Extension Enable a Postgres extension within a specific database. PostGIS extensions require a PostGIS-enabled cluster. */
export declare const enablePostgresExtension: API.OperationMethod<EnablePostgresExtensionRequest, EnablePostgresExtensionResponse, EnablePostgresExtensionError, FlyIoOpContext>;
export type EncryptSecretKeyError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Encrypt with a secret key */
export declare const encryptSecretKey: API.OperationMethod<EncryptSecretKeyRequest, EncryptSecretkeyResponse, EncryptSecretKeyError, FlyIoOpContext>;
export type ExecMachineError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Execute Command Execute a command on a specific Machine and return the raw command output bytes. */
export declare const execMachine: API.OperationMethod<ExecMachineRequest, Flydv1ExecResponse, ExecMachineError, FlyIoOpContext>;
export type ExtendVolumeError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Extend Volume Extend a volume's size within an app using the details provided in the request body. */
export declare const extendVolume: API.OperationMethod<ExtendVolumeRequest, ExtendVolumeResponse, ExtendVolumeError, FlyIoOpContext>;
export type ForkPostgresError = BadRequest | NotFound | Conflict | UnprocessableEntity | FlyIoOpError;
/** Fork Cluster to New Cluster Fork a ready Managed Postgres cluster into a new cluster that inherits the source's settings. The source cluster is left unchanged, and the fork is provisioned asynchronously. */
export declare const forkPostgres: API.OperationMethod<ForkPostgresRequest, ShowPostgresClusterResponse, ForkPostgresError, FlyIoOpContext>;
export type GenerateSecretKeyError = BadRequest | Forbidden | NotFound | Conflict | FlyIoOpError;
/** Generate a random secret key */
export declare const generateSecretKey: API.OperationMethod<GenerateSecretKeyRequest, SetSecretkeyResponse, GenerateSecretKeyError, FlyIoOpContext>;
export type GetAppError = Forbidden | NotFound | FlyIoOpError;
/** Get App Retrieve details about a specific app by its name. */
export declare const getApp: API.OperationMethod<GetAppRequest, App, GetAppError, FlyIoOpContext>;
export type GetAppCertificateError = Forbidden | NotFound | FlyIoOpError;
/** Get certificate details */
export declare const getAppCertificate: API.OperationMethod<GetAppCertificateRequest, CertificateDetail, GetAppCertificateError, FlyIoOpContext>;
export type GetCurrentTokenError = Forbidden | FlyIoOpError;
/** Get Current Token Information Get information about the current macaroon token(s), including organizations, apps, user identity hashes, and machine restrictions */
export declare const getCurrentToken: API.OperationMethod<GetCurrentTokenRequest, CurrentTokenResponse, GetCurrentTokenError, FlyIoOpContext>;
export type GetMachineError = Forbidden | NotFound | FlyIoOpError;
/** Get Machine Get details of a specific Machine within an app by the Machine ID. */
export declare const getMachine: API.OperationMethod<GetMachineRequest, Machine, GetMachineError, FlyIoOpContext>;
export type GetMachineLeaseError = Forbidden | NotFound | FlyIoOpError;
/** Get Lease Retrieve the current lease of a specific Machine within an app. Machine leases can be used to obtain an exclusive lock on modifying a Machine. */
export declare const getMachineLease: API.OperationMethod<GetMachineLeaseRequest, Lease, GetMachineLeaseError, FlyIoOpContext>;
export type GetMachineMemoryError = Forbidden | NotFound | FlyIoOpError;
/** Get Machine Memory Get current memory limit and available capacity for a machine */
export declare const getMachineMemory: API.OperationMethod<GetMachineMemoryRequest, MainMemoryResponse, GetMachineMemoryError, FlyIoOpContext>;
export type GetMachineMetadataError = Forbidden | NotFound | FlyIoOpError;
/** Get Metadata Retrieve metadata for a specific Machine within an app. */
export declare const getMachineMetadata: API.OperationMethod<GetMachineMetadataRequest, GetMachineMetadataResponse, GetMachineMetadataError, FlyIoOpContext>;
export type GetMachineMetadataKeyError = NotFound | FlyIoOpError;
/** Get Metadata Value Get the value of a specific metadata key */
export declare const getMachineMetadataKey: API.OperationMethod<GetMachineMetadataKeyRequest, MetadataValueResponse, GetMachineMetadataKeyError, FlyIoOpContext>;
export type GetPlacementsError = BadRequest | Forbidden | FlyIoOpError;
/** Get Placements Simulates placing the specified number of machines into regions, depending on available capacity and limits. */
export declare const getPlacements: API.OperationMethod<GetPlacementsRequest, MainGetPlacementsResponse, GetPlacementsError, FlyIoOpContext>;
export type GetPostgresError = NotFound | FlyIoOpError;
/** Get Postgres Cluster Get details of a specific Managed Postgres cluster. */
export declare const getPostgres: API.OperationMethod<GetPostgresRequest, ShowPostgresClusterResponse, GetPostgresError, FlyIoOpContext>;
export type GetRegionsError = Forbidden | FlyIoOpError;
/** Get Regions List all regions on the platform with their details. */
export declare const getRegions: API.OperationMethod<GetRegionsRequest, MainRegionResponse, GetRegionsError, FlyIoOpContext>;
export type GetSecretError = Forbidden | NotFound | FlyIoOpError;
/** Get an app secret */
export declare const getSecret: API.OperationMethod<GetSecretRequest, AppSecret, GetSecretError, FlyIoOpContext>;
export type GetSecretKeyError = Forbidden | NotFound | FlyIoOpError;
/** Get an app's secret key */
export declare const getSecretKey: API.OperationMethod<GetSecretKeyRequest, SecretKey, GetSecretKeyError, FlyIoOpContext>;
export type GetVolumeByIdError = Forbidden | NotFound | FlyIoOpError;
/** Get Volume Retrieve details about a specific volume by its ID within an app. */
export declare const getVolumeById: API.OperationMethod<GetVolumeByIdRequest, Volume, GetVolumeByIdError, FlyIoOpContext>;
export type ListAppCertificatesError = Forbidden | NotFound | FlyIoOpError;
/** List certificates for app */
export declare const listAppCertificates: API.OperationMethod<ListAppCertificatesRequest, ListCertificatesResponse, ListAppCertificatesError, FlyIoOpContext>;
export type ListAppIPAssignmentsError = Forbidden | NotFound | FlyIoOpError;
/** List IP assignments for app */
export declare const listAppIPAssignments: API.OperationMethod<ListAppIPAssignmentsRequest, ListIPAssignmentsResponse, ListAppIPAssignmentsError, FlyIoOpContext>;
export type ListAppsError = Forbidden | FlyIoOpError;
/** List Apps List all apps with the ability to filter by organization slug. */
export declare const listApps: API.OperationMethod<ListAppsRequest, ListAppsResponse, ListAppsError, FlyIoOpContext>;
export type ListMachineEventsError = Forbidden | NotFound | FlyIoOpError;
/** List Events List all events associated with a specific Machine within an app. */
export declare const listMachineEvents: API.OperationMethod<ListMachineEventsRequest, ListMachineEventsResponse, ListMachineEventsError, FlyIoOpContext>;
export type ListMachineProcessesError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** List Processes List all processes running on a specific Machine within an app, with optional sorting parameters. */
export declare const listMachineProcesses: API.OperationMethod<ListMachineProcessesRequest, ListMachineProcessesResponse, ListMachineProcessesError, FlyIoOpContext>;
export type ListMachinesError = Forbidden | NotFound | FlyIoOpError;
/** List Machines List all Machines associated with a specific app, with optional filters for including deleted Machines and filtering by region. */
export declare const listMachines: API.OperationMethod<ListMachinesRequest, ListMachinesResponse, ListMachinesError, FlyIoOpContext>;
export type ListMachinesOrgError = Forbidden | NotFound | FlyIoOpError;
/** List All Machines List all Machines associated with a specific organization. Machines are sorted by their `updated_at` timestamps, oldest to newest. This API call represents "a point in time". Recent machine changes, including creations and destructions, may take time to propagate. When polling with `updated_after`, offset your timestamps to catch late-arriving events. */
export declare const listMachinesOrg: API.OperationMethod<ListMachinesOrgRequest, OrgMachinesResponse, ListMachinesOrgError, FlyIoOpContext>;
export type ListMachineVersionsError = Forbidden | NotFound | FlyIoOpError;
/** List Versions List all versions of the configuration for a specific Machine within an app. */
export declare const listMachineVersions: API.OperationMethod<ListMachineVersionsRequest, ListMachineVersionsResponse, ListMachineVersionsError, FlyIoOpContext>;
export type ListPostgresError = NotFound | UnprocessableEntity | FlyIoOpError;
/** List Postgres Clusters List Managed Postgres clusters for an organization. */
export declare const listPostgres: API.OperationMethod<ListPostgresRequest, ListPostgresClustersResponse, ListPostgresError, FlyIoOpContext>;
export type ListPostgresBackupsError = NotFound | FlyIoOpError;
/** List Backups List all backups associated with a specific cluster. */
export declare const listPostgresBackups: API.OperationMethod<ListPostgresBackupsRequest, ListPostgresBackupsResponse, ListPostgresBackupsError, FlyIoOpContext>;
export type ListPostgresDatabasesError = NotFound | FlyIoOpError;
/** List Databases List all databases within a specific cluster. */
export declare const listPostgresDatabases: API.OperationMethod<ListPostgresDatabasesRequest, ListPostgresDatabasesResponse, ListPostgresDatabasesError, FlyIoOpContext>;
export type ListPostgresExtensionsError = BadRequest | NotFound | FlyIoOpError;
/** List Extensions List all extensions available within a specific database, indicating which are installed. */
export declare const listPostgresExtensions: API.OperationMethod<ListPostgresExtensionsRequest, ListPostgresExtensionsResponse, ListPostgresExtensionsError, FlyIoOpContext>;
export type ListPostgresUsersError = NotFound | FlyIoOpError;
/** List Users List all Postgres users within a specific cluster. */
export declare const listPostgresUsers: API.OperationMethod<ListPostgresUsersRequest, ListPostgresUsersResponse, ListPostgresUsersError, FlyIoOpContext>;
export type ListSecretKeysError = Forbidden | NotFound | FlyIoOpError;
/** List secret keys belonging to an app */
export declare const listSecretKeys: API.OperationMethod<ListSecretKeysRequest, SecretKeys, ListSecretKeysError, FlyIoOpContext>;
export type ListSecretsError = Forbidden | NotFound | FlyIoOpError;
/** List app secrets belonging to an app */
export declare const listSecrets: API.OperationMethod<ListSecretsRequest, AppSecrets, ListSecretsError, FlyIoOpContext>;
export type ListVolumesError = Forbidden | NotFound | FlyIoOpError;
/** List Volumes List all volumes associated with a specific app. */
export declare const listVolumes: API.OperationMethod<ListVolumesRequest, ListVolumesResponse, ListVolumesError, FlyIoOpContext>;
export type ListVolumeSnapshotsError = Forbidden | NotFound | FlyIoOpError;
/** List Snapshots List all snapshots for a specific volume within an app. */
export declare const listVolumeSnapshots: API.OperationMethod<ListVolumeSnapshotsRequest, ListVolumeSnapshotsResponse, ListVolumeSnapshotsError, FlyIoOpContext>;
export type ListVolumesOrgError = FlyIoOpError;
/** List All Volumes List all volumes for an organization with optional filters and cursor-based pagination. */
export declare const listVolumesOrg: API.OperationMethod<ListVolumesOrgRequest, OrgVolumesResponse, ListVolumesOrgError, FlyIoOpContext>;
export type MachinesReleaseLeaseError = Forbidden | NotFound | FlyIoOpError;
/** Release Lease Release the lease of a specific Machine within an app. Machine leases can be used to obtain an exclusive lock on modifying a Machine. */
export declare const machinesReleaseLease: API.OperationMethod<MachinesReleaseLeaseRequest, MachinesReleaseLeaseResponse, MachinesReleaseLeaseError, FlyIoOpContext>;
export type PatchMachineMetadataError = BadRequest | FlyIoOpError;
/** Update Metadata (set/remove multiple keys) Update multiple metadata keys at once. Null values and empty strings remove keys. + If `machine_version` is provided and no longer matches the current machine version, returns 412 Precondition Failed. */
export declare const patchMachineMetadata: API.OperationMethod<PatchMachineMetadataRequest, PatchMachineMetadataResponse, PatchMachineMetadataError, FlyIoOpContext>;
export type PostgresUsersCredentialsError = BadRequest | NotFound | FlyIoOpError;
/** Get User Credentials Get the connection credentials for a specific Postgres user within a cluster. */
export declare const postgresUsersCredentials: API.OperationMethod<PostgresUsersCredentialsRequest, GetPostgresUserCredentialsResponse, PostgresUsersCredentialsError, FlyIoOpContext>;
export type ReclaimMachineMemoryError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Reclaim Machine Memory Trigger the balloon device to reclaim memory from a machine */
export declare const reclaimMachineMemory: API.OperationMethod<ReclaimMachineMemoryRequest, MainReclaimMemoryResponse, ReclaimMachineMemoryError, FlyIoOpContext>;
export type RequestKmsTokenError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Request a Petsem token for accessing KMS This site hosts documentation generated from the Fly.io Machines API OpenAPI specification. Visit our complete [Machines API docs](https://fly.io/docs/machines/api/apps-resource/) for details about using the Apps resource. */
export declare const requestKmsToken: API.OperationMethod<RequestKmsTokenRequest, RequestKmsTokenResponse, RequestKmsTokenError, FlyIoOpContext>;
export type RequestOidcTokenError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Request an OIDC token Request an Open ID Connect token for your machine. Customize the audience claim with the `aud` parameter. This returns a JWT token. Learn more about [using OpenID Connect](/docs/reference/openid-connect/) on Fly.io. */
export declare const requestOidcToken: API.OperationMethod<RequestOidcTokenRequest, RequestOidcTokenResponse, RequestOidcTokenError, FlyIoOpContext>;
export type RestartMachineError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Restart Machine Restart a specific Machine within an app, with an optional timeout parameter. */
export declare const restartMachine: API.OperationMethod<RestartMachineRequest, RestartMachineResponse, RestartMachineError, FlyIoOpContext>;
export type RestorePostgresError = BadRequest | NotFound | UnprocessableEntity | FlyIoOpError;
/** Restore Backup or Point in Time to New Cluster Restore a backup, or a point in time within the cluster's PITR recovery window, into a new Managed Postgres cluster. The source cluster is left unchanged, and a new cluster is provisioned asynchronously. */
export declare const restorePostgres: API.OperationMethod<RestorePostgresRequest, ShowPostgresClusterResponse, RestorePostgresError, FlyIoOpContext>;
export type RotatePostgresUserPasswordError = BadRequest | NotFound | UnprocessableEntity | FlyIoOpError;
/** Rotate User Password Rotate a specific Postgres user's password within a cluster, optionally terminating the user's existing sessions. */
export declare const rotatePostgresUserPassword: API.OperationMethod<RotatePostgresUserPasswordRequest, RotatePostgresPasswordResponse, RotatePostgresUserPasswordError, FlyIoOpContext>;
export type SetMachineMemoryLimitError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Set Machine Memory Limit Set the memory limit for a machine using the balloon device */
export declare const setMachineMemoryLimit: API.OperationMethod<SetMachineMemoryLimitRequest, MainMemoryResponse, SetMachineMemoryLimitError, FlyIoOpContext>;
export type SetSecretKeyError = BadRequest | Forbidden | NotFound | Conflict | FlyIoOpError;
/** Create or update a secret key */
export declare const setSecretKey: API.OperationMethod<SetSecretKeyRequest, SetSecretkeyResponse, SetSecretKeyError, FlyIoOpContext>;
export type SignalMachineError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Signal Machine Send a signal to a specific Machine within an app using the details provided in the request body. */
export declare const signalMachine: API.OperationMethod<SignalMachineRequest, SignalMachineResponse, SignalMachineError, FlyIoOpContext>;
export type SignSecretKeyError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Sign with a secret key */
export declare const signSecretKey: API.OperationMethod<SignSecretKeyRequest, SignSecretkeyResponse, SignSecretKeyError, FlyIoOpContext>;
export type StartMachineError = BadRequest | Forbidden | NotFound | Conflict | FlyIoOpError;
/** Start Machine Start a specific Machine within an app. */
export declare const startMachine: API.OperationMethod<StartMachineRequest, StartMachineResponse, StartMachineError, FlyIoOpContext>;
export type StopMachineError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Stop Machine Stop a specific Machine within an app, with an optional request body to specify signal and timeout. */
export declare const stopMachine: API.OperationMethod<StopMachineRequest, StopMachineResponse, StopMachineError, FlyIoOpContext>;
export type SuspendMachineError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Suspend Machine Suspend a specific Machine within an app. The next start operation will attempt (but is not guaranteed) to resume the Machine from a snapshot taken at suspension time, rather than performing a cold boot. */
export declare const suspendMachine: API.OperationMethod<SuspendMachineRequest, SuspendMachineResponse, SuspendMachineError, FlyIoOpContext>;
export type UncordonMachineError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Uncordon Machine “Cordoning” a Machine refers to disabling its services, so the Fly Proxy won’t route requests to it. In flyctl this is used by blue/green deployments; one set of Machines is started up with services disabled, and when they are all healthy, the services are enabled on the new Machines and disabled on the old ones. */
export declare const uncordonMachine: API.OperationMethod<UncordonMachineRequest, UncordonMachineResponse, UncordonMachineError, FlyIoOpContext>;
export type UpdateMachineError = BadRequest | Forbidden | NotFound | Conflict | FlyIoOpError;
/** Update Machine Update a Machine's configuration using the details provided in the request body. */
export declare const updateMachine: API.OperationMethod<UpdateMachineRequest, Machine, UpdateMachineError, FlyIoOpContext>;
export type UpdateMachineMetadataError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Update Metadata (set/remove multiple keys) Update multiple metadata keys at once. Null values and empty strings remove keys. + If `machine_version` is provided and no longer matches the current machine version, returns 412 Precondition Failed. */
export declare const updateMachineMetadata: API.OperationMethod<UpdateMachineMetadataRequest, UpdateMachineMetadataResponse, UpdateMachineMetadataError, FlyIoOpContext>;
export type UpdatePostgresUserRoleError = BadRequest | NotFound | UnprocessableEntity | FlyIoOpError;
/** Update User Role Update a specific Postgres user's role within a cluster. */
export declare const updatePostgresUserRole: API.OperationMethod<UpdatePostgresUserRoleRequest, UpdatePostgresUserRoleResponse, UpdatePostgresUserRoleError, FlyIoOpContext>;
export type UpdateSecretsError = BadRequest | Forbidden | NotFound | Conflict | FlyIoOpError;
/** Update app secrets belonging to an app */
export declare const updateSecrets: API.OperationMethod<UpdateSecretsRequest, AppSecretsUpdateResp, UpdateSecretsError, FlyIoOpContext>;
export type UpdateVolumeError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Update Volume Update a volume's configuration using the details provided in the request body. */
export declare const updateVolume: API.OperationMethod<UpdateVolumeRequest, Volume, UpdateVolumeError, FlyIoOpContext>;
export type UpsertMachineMetadataError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Upsert Metadata Key Update metadata for a specific machine within an app by providing a metadata key. */
export declare const upsertMachineMetadata: API.OperationMethod<UpsertMachineMetadataRequest, UpsertMachineMetadataResponse, UpsertMachineMetadataError, FlyIoOpContext>;
export type VerifySecretKeyError = BadRequest | Forbidden | NotFound | FlyIoOpError;
/** Verify with a secret key */
export declare const verifySecretKey: API.OperationMethod<VerifySecretKeyRequest, VerifySecretKeyResponse, VerifySecretKeyError, FlyIoOpContext>;
export type WaitMachineError = BadRequest | Forbidden | NotFound | GatewayTimeout | FlyIoOpError;
/** Wait for State Wait for a Machine to reach a specific state. Specify the desired state with the state parameter. See the [Machine states table](https://fly.io/docs/machines/working-with-machines/#machine-states) for a list of possible states. The default for this parameter is `started`. This request will block for up to 60 seconds. Set a shorter timeout with the timeout parameter. */
export declare const waitMachine: API.OperationMethod<WaitMachineRequest, WaitMachineResponse, WaitMachineError, FlyIoOpContext>;
//# sourceMappingURL=machines.d.ts.map