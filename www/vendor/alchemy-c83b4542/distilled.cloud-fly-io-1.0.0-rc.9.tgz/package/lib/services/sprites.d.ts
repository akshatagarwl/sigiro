import * as S from "@distilled.cloud/core/schema";
import type * as Redacted from "effect/Redacted";
import * as API from "@distilled.cloud/core/api";
import { type SpritesOpError, type SpritesOpContext } from "../protocol.ts";
import { BadRequest, Conflict, NotFound, SpritesNotEnabled } from "../errors.ts";
export type { SpritesOpError, SpritesOpContext };
export interface CreateCheckpointRequest {
    name: string;
    comment?: string;
}
export declare const CreateCheckpointRequest: S.Schema<CreateCheckpointRequest>;
export interface StreamEvent {
    type?: string;
    data?: string;
    error?: string;
    time?: string;
}
export declare const StreamEvent: S.Schema<StreamEvent>;
export type CreateCheckpointResponseBodyList = Array<StreamEvent>;
export declare const CreateCheckpointResponseBodyList: S.Schema<CreateCheckpointResponseBodyList>;
export type CreateCheckpointResponse = CreateCheckpointResponseBodyList;
export declare const CreateCheckpointResponse: S.Schema<CreateCheckpointResponse>;
export interface CreateOrganizationTokenRequest {
    /** Fly organization slug */
    org: string;
    /** Human-readable label for the minted token */
    description?: string;
    /** Optional Sprites invite code */
    invite_code?: string;
}
export declare const CreateOrganizationTokenRequest: S.Schema<CreateOrganizationTokenRequest>;
export interface CreateOrganizationTokenResponse {
    /** Sprites bearer token. Send as Authorization: Bearer on subsequent sprite ops. */
    token: string | Redacted.Redacted<string>;
}
export declare const CreateOrganizationTokenResponse: S.Schema<CreateOrganizationTokenResponse>;
export type UrlAuth = "sprite" | "public";
export declare const UrlAuth: any;
export interface UrlSettings {
    auth?: UrlAuth | (string & {});
    private_access?: string;
}
export declare const UrlSettings: S.Schema<UrlSettings>;
/** Labels stamped on the sprite (used for ownership / nuke) */
export type CreateSpriteRequestLabelsList = Array<string>;
export declare const CreateSpriteRequestLabelsList: S.Schema<CreateSpriteRequestLabelsList>;
export interface CreateSpriteRequest {
    /** Unique name for the sprite within the organization */
    name: string;
    url_settings?: UrlSettings;
    /** Labels stamped on the sprite (used for ownership / nuke) */
    labels?: CreateSpriteRequestLabelsList;
}
export declare const CreateSpriteRequest: S.Schema<CreateSpriteRequest>;
export type SpriteStatus = "cold" | "warm" | "running";
export declare const SpriteStatus: any;
export type SpriteLabelsList = Array<string>;
export declare const SpriteLabelsList: S.Schema<SpriteLabelsList>;
export interface Sprite {
    id?: string;
    name?: string;
    organization?: string;
    org_slug?: string;
    url?: string;
    url_settings?: UrlSettings;
    status?: SpriteStatus;
    labels?: SpriteLabelsList;
    created_at?: string;
    updated_at?: string;
    last_started_at?: string | null;
    last_active_at?: string | null;
    last_running_at?: string | null;
    version?: string | null;
}
export declare const Sprite: S.Schema<Sprite>;
export interface DeleteSpriteRequest {
    /** Unique sprite name */
    name: string;
}
export declare const DeleteSpriteRequest: S.Schema<DeleteSpriteRequest>;
export interface DeleteSpriteResponse {
}
export declare const DeleteSpriteResponse: S.Schema<DeleteSpriteResponse>;
export type ExecCommandRequestCmdList = Array<string>;
export declare const ExecCommandRequestCmdList: S.Schema<ExecCommandRequestCmdList>;
export type ExecCommandRequestEnvList = Array<string>;
export declare const ExecCommandRequestEnvList: S.Schema<ExecCommandRequestEnvList>;
export interface ExecCommandRequest {
    name: string;
    /** Command and args (repeatable) */
    cmd: ExecCommandRequestCmdList;
    /** Explicit path to the executable */
    path?: string;
    /** Read stdin from the request body */
    stdin?: boolean;
    /** Environment variables as KEY=VALUE (repeatable) */
    env?: ExecCommandRequestEnvList;
    /** Working directory */
    dir?: string;
    body?: Uint8Array | string;
}
export declare const ExecCommandRequest: S.Schema<ExecCommandRequest>;
export interface ExecResult {
    exit_code?: number;
    stdout?: string;
    stderr?: string;
}
export declare const ExecResult: S.Schema<ExecResult>;
export interface GetCheckpointRequest {
    name: string;
    /** Checkpoint identifier (e.g. v7) */
    checkpoint_id: string;
}
export declare const GetCheckpointRequest: S.Schema<GetCheckpointRequest>;
export interface Checkpoint {
    id?: string;
    create_time?: string;
    source_id?: string;
    comment?: string;
    health?: string;
}
export declare const Checkpoint: S.Schema<Checkpoint>;
export interface GetServiceRequest {
    name: string;
    service_name: string;
}
export declare const GetServiceRequest: S.Schema<GetServiceRequest>;
export type SpriteServiceArgsList = Array<string>;
export declare const SpriteServiceArgsList: S.Schema<SpriteServiceArgsList>;
export type SpriteServiceNeedsList = Array<string>;
export declare const SpriteServiceNeedsList: S.Schema<SpriteServiceNeedsList>;
export interface SpriteServiceState {
    name?: string;
    status?: string;
    pid?: number;
    started_at?: string;
    error?: string;
}
export declare const SpriteServiceState: S.Schema<SpriteServiceState>;
export interface SpriteService {
    name?: string;
    cmd?: string;
    args?: SpriteServiceArgsList;
    needs?: SpriteServiceNeedsList;
    http_port?: number;
    state?: SpriteServiceState;
}
export declare const SpriteService: S.Schema<SpriteService>;
export interface GetSpriteRequest {
    /** Unique sprite name */
    name: string;
}
export declare const GetSpriteRequest: S.Schema<GetSpriteRequest>;
export interface ListCheckpointsRequest {
    name: string;
}
export declare const ListCheckpointsRequest: S.Schema<ListCheckpointsRequest>;
export type ListCheckpointsResponseBodyList = Array<Checkpoint>;
export declare const ListCheckpointsResponseBodyList: S.Schema<ListCheckpointsResponseBodyList>;
export type ListCheckpointsResponse = ListCheckpointsResponseBodyList;
export declare const ListCheckpointsResponse: S.Schema<ListCheckpointsResponse>;
export interface ListExecSessionsRequest {
    name: string;
}
export declare const ListExecSessionsRequest: S.Schema<ListExecSessionsRequest>;
export interface ExecSession {
    id?: string;
    command?: string;
    is_active?: boolean;
    tty?: boolean;
    created?: string;
    last_activity?: string;
    workdir?: string;
    bytes_per_second?: number;
}
export declare const ExecSession: S.Schema<ExecSession>;
export type ListExecSessionsResponseBodyList = Array<ExecSession>;
export declare const ListExecSessionsResponseBodyList: S.Schema<ListExecSessionsResponseBodyList>;
export type ListExecSessionsResponse = ListExecSessionsResponseBodyList;
export declare const ListExecSessionsResponse: S.Schema<ListExecSessionsResponse>;
export interface ListServicesRequest {
    name: string;
}
export declare const ListServicesRequest: S.Schema<ListServicesRequest>;
export type ListServicesResponseBodyList = Array<SpriteService>;
export declare const ListServicesResponseBodyList: S.Schema<ListServicesResponseBodyList>;
export type ListServicesResponse = ListServicesResponseBodyList;
export declare const ListServicesResponse: S.Schema<ListServicesResponse>;
export interface ListSpritesRequest {
    /** Filter sprites by name prefix */
    prefix?: string;
    /** Maximum number of results (1-50, default 50) */
    max_results?: number;
    /** Token from the previous response */
    continuation_token?: string;
}
export declare const ListSpritesRequest: S.Schema<ListSpritesRequest>;
export type ListSpritesResponseSpritesList = Array<Sprite>;
export declare const ListSpritesResponseSpritesList: S.Schema<ListSpritesResponseSpritesList>;
export interface ListSpritesResponse {
    sprites: ListSpritesResponseSpritesList;
    has_more?: boolean;
    next_continuation_token?: string | null;
    name?: string;
    running?: number;
    warm?: number;
    cold?: number;
    running_limit?: number;
    warm_limit?: number;
}
export declare const ListSpritesResponse: S.Schema<ListSpritesResponse>;
/** Command arguments */
export type PutServiceRequestArgsList = Array<string>;
export declare const PutServiceRequestArgsList: S.Schema<PutServiceRequestArgsList>;
/** Service dependencies (started first) */
export type PutServiceRequestNeedsList = Array<string>;
export declare const PutServiceRequestNeedsList: S.Schema<PutServiceRequestNeedsList>;
export interface PutServiceRequest {
    name: string;
    service_name: string;
    /** Time to monitor logs after starting (default 5s) */
    duration?: string;
    /** Command to execute */
    cmd: string;
    /** Command arguments */
    args?: PutServiceRequestArgsList;
    /** Working directory for the service */
    dir?: string;
    /** Service dependencies (started first) */
    needs?: PutServiceRequestNeedsList;
    /** HTTP port for proxy routing */
    http_port?: number;
}
export declare const PutServiceRequest: S.Schema<PutServiceRequest>;
export type PutServiceResponseBodyList = Array<StreamEvent>;
export declare const PutServiceResponseBodyList: S.Schema<PutServiceResponseBodyList>;
export type PutServiceResponse = PutServiceResponseBodyList;
export declare const PutServiceResponse: S.Schema<PutServiceResponse>;
export interface RestoreCheckpointRequest {
    name: string;
    checkpoint_id: string;
}
export declare const RestoreCheckpointRequest: S.Schema<RestoreCheckpointRequest>;
export type RestoreCheckpointResponseBodyList = Array<StreamEvent>;
export declare const RestoreCheckpointResponseBodyList: S.Schema<RestoreCheckpointResponseBodyList>;
export type RestoreCheckpointResponse = RestoreCheckpointResponseBodyList;
export declare const RestoreCheckpointResponse: S.Schema<RestoreCheckpointResponse>;
export interface UpdateSpriteRequest {
    /** Unique sprite name */
    name: string;
    url_settings: UrlSettings;
}
export declare const UpdateSpriteRequest: S.Schema<UpdateSpriteRequest>;
export interface WriteFileRequest {
    name: string;
    /** Path to the file to write */
    path: string;
    /** Working directory for resolving relative paths */
    workingDir: string;
    /** File permissions in octal (e.g. 0644) */
    mode?: string;
    /** Create parent directories if they do not exist */
    mkdir?: boolean;
    body: Uint8Array | string;
}
export declare const WriteFileRequest: S.Schema<WriteFileRequest>;
export interface WriteFileResponse {
    path?: string;
    size?: number;
    mode?: string;
}
export declare const WriteFileResponse: S.Schema<WriteFileResponse>;
export type CreateCheckpointError = NotFound | SpritesOpError;
/** Create a checkpoint (NDJSON progress stream) */
export declare const createCheckpoint: API.OperationMethod<CreateCheckpointRequest, CreateCheckpointResponse, CreateCheckpointError, SpritesOpContext>;
export type CreateOrganizationTokenError = SpritesNotEnabled | SpritesOpError;
/** Mint a Sprites bearer token from a Fly.io macaroon POST with Authorization: FlyV1 {FLY_API_TOKEN}. Sprite CRUD rejects Bearer FLY_API_TOKEN (401); callers mint once, cache, then Bearer the returned token. 401 with 'sprites not enabled' means the org has not enabled Sprites. */
export declare const createOrganizationToken: API.OperationMethod<CreateOrganizationTokenRequest, CreateOrganizationTokenResponse, CreateOrganizationTokenError, SpritesOpContext>;
export type CreateSpriteError = BadRequest | Conflict | SpritesOpError;
/** Create a sprite */
export declare const createSprite: API.OperationMethod<CreateSpriteRequest, Sprite, CreateSpriteError, SpritesOpContext>;
export type DeleteSpriteError = NotFound | SpritesOpError;
/** Delete a sprite */
export declare const deleteSprite: API.OperationMethod<DeleteSpriteRequest, DeleteSpriteResponse, DeleteSpriteError, SpritesOpContext>;
export type ExecCommandError = BadRequest | NotFound | SpritesOpError;
/** Execute a command via HTTP POST (non-TTY). Simpler than the WebSocket exec API. */
export declare const execCommand: API.OperationMethod<ExecCommandRequest, ExecResult, ExecCommandError, SpritesOpContext>;
export type GetCheckpointError = NotFound | SpritesOpError;
/** Get a checkpoint */
export declare const getCheckpoint: API.OperationMethod<GetCheckpointRequest, Checkpoint, GetCheckpointError, SpritesOpContext>;
export type GetServiceError = NotFound | SpritesOpError;
/** Get a sprite service */
export declare const getService: API.OperationMethod<GetServiceRequest, SpriteService, GetServiceError, SpritesOpContext>;
export type GetSpriteError = NotFound | SpritesOpError;
/** Get a sprite */
export declare const getSprite: API.OperationMethod<GetSpriteRequest, Sprite, GetSpriteError, SpritesOpContext>;
export type ListCheckpointsError = NotFound | SpritesOpError;
/** List checkpoints */
export declare const listCheckpoints: API.OperationMethod<ListCheckpointsRequest, ListCheckpointsResponse, ListCheckpointsError, SpritesOpContext>;
export type ListExecSessionsError = NotFound | SpritesOpError;
/** List active exec sessions */
export declare const listExecSessions: API.OperationMethod<ListExecSessionsRequest, ListExecSessionsResponse, ListExecSessionsError, SpritesOpContext>;
export type ListServicesError = NotFound | SpritesOpError;
/** List configured sprite services */
export declare const listServices: API.OperationMethod<ListServicesRequest, ListServicesResponse, ListServicesError, SpritesOpContext>;
export type ListSpritesError = SpritesOpError;
/** List sprites for the authenticated organization */
export declare const listSprites: API.PaginatedOperationMethod<ListSpritesRequest, ListSpritesResponse, ListSpritesError, SpritesOpContext, Sprite>;
export type PutServiceError = BadRequest | NotFound | SpritesOpError;
/** Create or update a sprite service. Returns NDJSON start progress. */
export declare const putService: API.OperationMethod<PutServiceRequest, PutServiceResponse, PutServiceError, SpritesOpContext>;
export type RestoreCheckpointError = NotFound | SpritesOpError;
/** Restore a checkpoint (NDJSON progress stream). Destructive. */
export declare const restoreCheckpoint: API.OperationMethod<RestoreCheckpointRequest, RestoreCheckpointResponse, RestoreCheckpointError, SpritesOpContext>;
export type UpdateSpriteError = NotFound | SpritesOpError;
/** Update sprite URL auth settings */
export declare const updateSprite: API.OperationMethod<UpdateSpriteRequest, Sprite, UpdateSpriteError, SpritesOpContext>;
export type WriteFileError = BadRequest | NotFound | SpritesOpError;
/** Write file contents to the sprite filesystem. Request body is raw file bytes. */
export declare const writeFile: API.OperationMethod<WriteFileRequest, WriteFileResponse, WriteFileError, SpritesOpContext>;
//# sourceMappingURL=sprites.d.ts.map