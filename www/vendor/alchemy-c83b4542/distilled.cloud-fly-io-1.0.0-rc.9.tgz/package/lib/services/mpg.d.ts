import * as S from "@distilled.cloud/core/schema";
import type * as Redacted from "effect/Redacted";
import * as API from "@distilled.cloud/core/api";
import { type FlyIoOpError, type FlyIoOpContext } from "../protocol.ts";
import { Conflict, Forbidden, NotFound } from "../errors.ts";
export type { FlyIoOpError, FlyIoOpContext };
export interface CreateAttachmentRequest {
    id: string;
    app_name: string;
}
export declare const CreateAttachmentRequest: S.Schema<CreateAttachmentRequest>;
export interface CreateAttachmentResponseData {
    id?: number;
    app_id?: number;
    managed_service_id?: number;
    attached_at?: string;
}
export declare const CreateAttachmentResponseData: S.Schema<CreateAttachmentResponseData>;
export interface CreateAttachmentResponse {
    data?: CreateAttachmentResponseData;
}
export declare const CreateAttachmentResponse: S.Schema<CreateAttachmentResponse>;
export interface CreateBackupRequest {
    id: string;
    type?: string;
}
export declare const CreateBackupRequest: S.Schema<CreateBackupRequest>;
export interface CreateBackupResponse {
}
export declare const CreateBackupResponse: S.Schema<CreateBackupResponse>;
export interface CreateClusterRequest {
    org_slug: string;
    name: string;
    region: string;
    plan: string;
    pg_major_version?: string;
    storage_in_gb?: number;
    postgis_enabled?: boolean;
}
export declare const CreateClusterRequest: S.Schema<CreateClusterRequest>;
export interface Organization {
    id?: string;
    name?: string;
    slug?: string;
    raw_slug?: string;
}
export declare const Organization: S.Schema<Organization>;
export type IpAssignments = {
    [key: string]: string | undefined;
};
export declare const IpAssignments: S.Schema<IpAssignments>;
export interface AttachedApp {
    name?: string;
    id?: string;
}
export declare const AttachedApp: S.Schema<AttachedApp>;
export type ManagedClusterAttachedAppsList = Array<AttachedApp>;
export declare const ManagedClusterAttachedAppsList: S.Schema<ManagedClusterAttachedAppsList>;
export interface ManagedCluster {
    id?: string;
    name?: string;
    status?: string;
    engine?: string;
    plan?: string;
    region?: string;
    organization?: Organization;
    mpgd_cluster_id?: string;
    disk?: number;
    replicas?: number;
    ip_assignments?: IpAssignments;
    attached_apps?: ManagedClusterAttachedAppsList;
    postgis_enabled?: boolean;
    environment?: string;
}
export declare const ManagedCluster: S.Schema<ManagedCluster>;
export type CreateClusterResponseErrorsMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateClusterResponseErrorsMap: S.Schema<CreateClusterResponseErrorsMap>;
export interface CreateClusterResponse {
    ok?: boolean;
    data?: ManagedCluster;
    errors?: CreateClusterResponseErrorsMap;
}
export declare const CreateClusterResponse: S.Schema<CreateClusterResponse>;
export interface CreateDatabaseRequest {
    id: string;
    name: string;
}
export declare const CreateDatabaseRequest: S.Schema<CreateDatabaseRequest>;
export interface CreateDatabaseResponse {
}
export declare const CreateDatabaseResponse: S.Schema<CreateDatabaseResponse>;
export type CreateUserRequestRole = "schema_admin" | "writer" | "reader";
export declare const CreateUserRequestRole: any;
export interface CreateUserRequest {
    id: string;
    username: string;
    role: CreateUserRequestRole | (string & {});
}
export declare const CreateUserRequest: S.Schema<CreateUserRequest>;
export interface User {
    name?: string;
    username?: string;
    role?: string;
}
export declare const User: S.Schema<User>;
export interface CreateUserResponse {
    data?: User;
}
export declare const CreateUserResponse: S.Schema<CreateUserResponse>;
export interface DeleteAttachmentRequest {
    id: string;
    app_name: string;
}
export declare const DeleteAttachmentRequest: S.Schema<DeleteAttachmentRequest>;
export interface DeleteAttachmentResponseData {
    message?: string;
}
export declare const DeleteAttachmentResponseData: S.Schema<DeleteAttachmentResponseData>;
export interface DeleteAttachmentResponse {
    data?: DeleteAttachmentResponseData;
}
export declare const DeleteAttachmentResponse: S.Schema<DeleteAttachmentResponse>;
export interface DeleteUserRequest {
    id: string;
    username: string;
}
export declare const DeleteUserRequest: S.Schema<DeleteUserRequest>;
export interface DeleteUserResponse {
}
export declare const DeleteUserResponse: S.Schema<DeleteUserResponse>;
export interface DestroyClusterRequest {
    org_slug: string;
    id: string;
}
export declare const DestroyClusterRequest: S.Schema<DestroyClusterRequest>;
export interface DestroyClusterResponse {
}
export declare const DestroyClusterResponse: S.Schema<DestroyClusterResponse>;
export interface DisableExtensionRequest {
    id: string;
    database: string;
    name: string;
    force?: boolean;
}
export declare const DisableExtensionRequest: S.Schema<DisableExtensionRequest>;
export interface DisableExtensionResponse {
}
export declare const DisableExtensionResponse: S.Schema<DisableExtensionResponse>;
export interface EnableExtensionRequest {
    id: string;
    database: string;
    name: string;
    schema?: string;
    create_schema_if_needed?: boolean;
}
export declare const EnableExtensionRequest: S.Schema<EnableExtensionRequest>;
export interface EnableExtensionResponse {
}
export declare const EnableExtensionResponse: S.Schema<EnableExtensionResponse>;
export interface GetClusterRequest {
    org_slug: string;
    id: string;
}
export declare const GetClusterRequest: S.Schema<GetClusterRequest>;
export interface ClusterCredentials {
    status?: string;
    user?: string;
    password?: string | Redacted.Redacted<string>;
    dbname?: string;
    pgbouncer_uri?: string | Redacted.Redacted<string>;
}
export declare const ClusterCredentials: S.Schema<ClusterCredentials>;
export interface GetClusterResponse {
    data?: ManagedCluster;
    credentials?: ClusterCredentials;
}
export declare const GetClusterResponse: S.Schema<GetClusterResponse>;
export interface GetClusterByIdRequest {
    id: string;
}
export declare const GetClusterByIdRequest: S.Schema<GetClusterByIdRequest>;
export interface GetUserCredentialsRequest {
    id: string;
    username: string;
}
export declare const GetUserCredentialsRequest: S.Schema<GetUserCredentialsRequest>;
export interface GetUserCredentialsResponseData {
    username?: string;
    user?: string;
    password?: string | Redacted.Redacted<string>;
}
export declare const GetUserCredentialsResponseData: S.Schema<GetUserCredentialsResponseData>;
export interface GetUserCredentialsResponse {
    data?: GetUserCredentialsResponseData;
}
export declare const GetUserCredentialsResponse: S.Schema<GetUserCredentialsResponse>;
export interface ListBackupsRequest {
    id: string;
}
export declare const ListBackupsRequest: S.Schema<ListBackupsRequest>;
export interface ClusterBackup {
    id?: string;
    status?: string;
    type?: string;
    start?: string;
    stop?: string;
}
export declare const ClusterBackup: S.Schema<ClusterBackup>;
export type ListBackupsResponseDataList = Array<ClusterBackup>;
export declare const ListBackupsResponseDataList: S.Schema<ListBackupsResponseDataList>;
export interface ListBackupsResponse {
    data?: ListBackupsResponseDataList;
}
export declare const ListBackupsResponse: S.Schema<ListBackupsResponse>;
export interface ListClustersRequest {
    org_slug: string;
}
export declare const ListClustersRequest: S.Schema<ListClustersRequest>;
export type ListClustersResponseDataList = Array<ManagedCluster>;
export declare const ListClustersResponseDataList: S.Schema<ListClustersResponseDataList>;
export interface ListClustersResponse {
    data?: ListClustersResponseDataList;
}
export declare const ListClustersResponse: S.Schema<ListClustersResponse>;
export interface ListDatabasesRequest {
    id: string;
}
export declare const ListDatabasesRequest: S.Schema<ListDatabasesRequest>;
export interface Database {
    name?: string;
}
export declare const Database: S.Schema<Database>;
export type ListDatabasesResponseDataList = Array<Database>;
export declare const ListDatabasesResponseDataList: S.Schema<ListDatabasesResponseDataList>;
export interface ListDatabasesResponse {
    data?: ListDatabasesResponseDataList;
}
export declare const ListDatabasesResponse: S.Schema<ListDatabasesResponse>;
export interface ListExtensionsRequest {
    id: string;
    database: string;
}
export declare const ListExtensionsRequest: S.Schema<ListExtensionsRequest>;
export interface InstalledExtension {
    version?: string;
    schema?: string;
}
export declare const InstalledExtension: S.Schema<InstalledExtension>;
export interface Extension {
    name?: string;
    description?: string;
    docs_url?: string;
    default_version?: string;
    is_system?: boolean;
    installed?: InstalledExtension;
}
export declare const Extension: S.Schema<Extension>;
export type ListExtensionsResponseDataList = Array<Extension>;
export declare const ListExtensionsResponseDataList: S.Schema<ListExtensionsResponseDataList>;
export interface ListExtensionsResponse {
    data?: ListExtensionsResponseDataList;
}
export declare const ListExtensionsResponse: S.Schema<ListExtensionsResponse>;
export interface ListRegionsRequest {
    org_slug: string;
}
export declare const ListRegionsRequest: S.Schema<ListRegionsRequest>;
export interface Region {
    code?: string;
    available?: boolean;
}
export declare const Region: S.Schema<Region>;
export type ListRegionsResponseDataList = Array<Region>;
export declare const ListRegionsResponseDataList: S.Schema<ListRegionsResponseDataList>;
export interface ListRegionsResponse {
    data?: ListRegionsResponseDataList;
}
export declare const ListRegionsResponse: S.Schema<ListRegionsResponse>;
export interface ListUsersRequest {
    id: string;
}
export declare const ListUsersRequest: S.Schema<ListUsersRequest>;
export type ListUsersResponseDataList = Array<User>;
export declare const ListUsersResponseDataList: S.Schema<ListUsersResponseDataList>;
export interface ListUsersResponse {
    data?: ListUsersResponseDataList;
}
export declare const ListUsersResponse: S.Schema<ListUsersResponse>;
export interface RestoreBackupRequest {
    id: string;
    backup_id?: string;
    name?: string;
    pitr_time?: string;
}
export declare const RestoreBackupRequest: S.Schema<RestoreBackupRequest>;
export interface RestoreBackupResponse {
    data?: ManagedCluster;
}
export declare const RestoreBackupResponse: S.Schema<RestoreBackupResponse>;
export type UpdateUserRoleRequestRole = "schema_admin" | "writer" | "reader";
export declare const UpdateUserRoleRequestRole: any;
export interface UpdateUserRoleRequest {
    id: string;
    username: string;
    role: UpdateUserRoleRequestRole | (string & {});
}
export declare const UpdateUserRoleRequest: S.Schema<UpdateUserRoleRequest>;
export interface UpdateUserRoleResponse {
}
export declare const UpdateUserRoleResponse: S.Schema<UpdateUserRoleResponse>;
export type CreateAttachmentError = NotFound | Conflict | FlyIoOpError;
/** Attach a cluster to a Machines app */
export declare const createAttachment: API.OperationMethod<CreateAttachmentRequest, CreateAttachmentResponse, CreateAttachmentError, FlyIoOpContext>;
export type CreateBackupError = NotFound | FlyIoOpError;
/** Create a backup */
export declare const createBackup: API.OperationMethod<CreateBackupRequest, CreateBackupResponse, CreateBackupError, FlyIoOpContext>;
export type CreateClusterError = Forbidden | NotFound | Conflict | FlyIoOpError;
/** Create an MPG v2 cluster */
export declare const createCluster: API.OperationMethod<CreateClusterRequest, CreateClusterResponse, CreateClusterError, FlyIoOpContext>;
export type CreateDatabaseError = NotFound | Conflict | FlyIoOpError;
/** Create a database */
export declare const createDatabase: API.OperationMethod<CreateDatabaseRequest, CreateDatabaseResponse, CreateDatabaseError, FlyIoOpContext>;
export type CreateUserError = NotFound | Conflict | FlyIoOpError;
/** Create a user with a role */
export declare const createUser: API.OperationMethod<CreateUserRequest, CreateUserResponse, CreateUserError, FlyIoOpContext>;
export type DeleteAttachmentError = NotFound | FlyIoOpError;
/** Detach a cluster from a Machines app */
export declare const deleteAttachment: API.OperationMethod<DeleteAttachmentRequest, DeleteAttachmentResponse, DeleteAttachmentError, FlyIoOpContext>;
export type DeleteUserError = NotFound | FlyIoOpError;
/** Delete a user */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest, DeleteUserResponse, DeleteUserError, FlyIoOpContext>;
export type DestroyClusterError = NotFound | FlyIoOpError;
/** Destroy an MPG v2 cluster (async — poll 404) */
export declare const destroyCluster: API.OperationMethod<DestroyClusterRequest, DestroyClusterResponse, DestroyClusterError, FlyIoOpContext>;
export type DisableExtensionError = NotFound | FlyIoOpError;
/** Disable an extension */
export declare const disableExtension: API.OperationMethod<DisableExtensionRequest, DisableExtensionResponse, DisableExtensionError, FlyIoOpContext>;
export type EnableExtensionError = NotFound | Conflict | FlyIoOpError;
/** Enable an extension */
export declare const enableExtension: API.OperationMethod<EnableExtensionRequest, EnableExtensionResponse, EnableExtensionError, FlyIoOpContext>;
export type GetClusterError = NotFound | FlyIoOpError;
/** Get an MPG v2 cluster by org and id */
export declare const getCluster: API.OperationMethod<GetClusterRequest, GetClusterResponse, GetClusterError, FlyIoOpContext>;
export type GetClusterByIdError = NotFound | FlyIoOpError;
/** Get an MPG v2 cluster by id */
export declare const getClusterById: API.OperationMethod<GetClusterByIdRequest, GetClusterResponse, GetClusterByIdError, FlyIoOpContext>;
export type GetUserCredentialsError = NotFound | FlyIoOpError;
/** Get a user's credentials */
export declare const getUserCredentials: API.OperationMethod<GetUserCredentialsRequest, GetUserCredentialsResponse, GetUserCredentialsError, FlyIoOpContext>;
export type ListBackupsError = NotFound | FlyIoOpError;
/** List cluster backups */
export declare const listBackups: API.OperationMethod<ListBackupsRequest, ListBackupsResponse, ListBackupsError, FlyIoOpContext>;
export type ListClustersError = Forbidden | NotFound | FlyIoOpError;
/** List MPG v2 clusters in an organization */
export declare const listClusters: API.OperationMethod<ListClustersRequest, ListClustersResponse, ListClustersError, FlyIoOpContext>;
export type ListDatabasesError = NotFound | FlyIoOpError;
/** List databases (no DELETE API) */
export declare const listDatabases: API.OperationMethod<ListDatabasesRequest, ListDatabasesResponse, ListDatabasesError, FlyIoOpContext>;
export type ListExtensionsError = NotFound | FlyIoOpError;
/** List available/installed extensions */
export declare const listExtensions: API.OperationMethod<ListExtensionsRequest, ListExtensionsResponse, ListExtensionsError, FlyIoOpContext>;
export type ListRegionsError = FlyIoOpError;
/** List regions that support MPG for an organization */
export declare const listRegions: API.OperationMethod<ListRegionsRequest, ListRegionsResponse, ListRegionsError, FlyIoOpContext>;
export type ListUsersError = NotFound | FlyIoOpError;
/** List cluster users */
export declare const listUsers: API.OperationMethod<ListUsersRequest, ListUsersResponse, ListUsersError, FlyIoOpContext>;
export type RestoreBackupError = NotFound | FlyIoOpError;
/** Restore a cluster from a backup (creates a new cluster) */
export declare const restoreBackup: API.OperationMethod<RestoreBackupRequest, RestoreBackupResponse, RestoreBackupError, FlyIoOpContext>;
export type UpdateUserRoleError = NotFound | FlyIoOpError;
/** Update a user's role */
export declare const updateUserRole: API.OperationMethod<UpdateUserRoleRequest, UpdateUserRoleResponse, UpdateUserRoleError, FlyIoOpContext>;
//# sourceMappingURL=mpg.d.ts.map