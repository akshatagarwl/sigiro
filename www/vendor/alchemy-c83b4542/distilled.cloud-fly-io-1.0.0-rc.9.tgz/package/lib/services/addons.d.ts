import * as S from "@distilled.cloud/core/schema";
import type * as Redacted from "effect/Redacted";
import * as API from "@distilled.cloud/core/api";
import { type FlyIoOpError, type FlyIoOpContext } from "../protocol.ts";
import { CreateExtensionTosAgreementNotAuthorized } from "../errors.ts";
export type { FlyIoOpError, FlyIoOpContext };
export interface AddOnRequest {
    id?: string | null;
    name?: string | null;
    provider?: string | null;
}
export declare const AddOnRequest: S.Schema<AddOnRequest>;
export type AddOnResponseReadRegionsList = Array<string>;
export declare const AddOnResponseReadRegionsList: S.Schema<AddOnResponseReadRegionsList>;
export interface AddOnResponseAddOnPlan {
    id: string;
    name: string | null;
    displayName: string | null;
    description: string | null;
    maxDataSize: string | null;
    pricePerMonth: number | null;
}
export declare const AddOnResponseAddOnPlan: S.Schema<AddOnResponseAddOnPlan>;
export interface AddOnResponseAddOnProvider {
    id: string;
    name: string | null;
    displayName: string | null;
    tosUrl: string | null;
    tosAgreement: string | null;
    asyncProvisioning: boolean;
    autoProvision: boolean;
    beta: boolean;
    internal: boolean;
    selectName: boolean;
    selectRegion: boolean;
    selectReplicaRegions: boolean;
    detectPlatform: boolean;
    resourceName: string;
    nameSuffix: string | null;
    provisioningInstructions: string | null;
}
export declare const AddOnResponseAddOnProvider: S.Schema<AddOnResponseAddOnProvider>;
export interface AddOnResponseOrganization {
    id: string;
    name: string | null;
    slug: string | null;
    rawSlug: string;
    paidPlan: boolean;
    billable: boolean;
    provisionsBetaExtensions: boolean;
}
export declare const AddOnResponseOrganization: S.Schema<AddOnResponseOrganization>;
export interface AddOnResponseApp {
    id: string;
    name: string | null;
}
export declare const AddOnResponseApp: S.Schema<AddOnResponseApp>;
/** Selection set for `addOn` (unwrapped from the GraphQL `data` envelope). */
export interface AddOnResponse {
    id: string;
    name: string | null;
    primaryRegion: string | null;
    readRegions: AddOnResponseReadRegionsList | null;
    status: string | null;
    errorMessage: string | null;
    publicUrl: string | Redacted.Redacted<string> | null;
    privateIp: string | null;
    password: string | Redacted.Redacted<string> | null;
    ssoLink: string | null;
    environment: unknown | null;
    options: unknown | null;
    metadata: unknown | null;
    createdAt: string;
    updatedAt: string;
    addOnPlan: AddOnResponseAddOnPlan | null;
    addOnPlanName: string | null;
    addOnProvider: AddOnResponseAddOnProvider | null;
    organization: AddOnResponseOrganization;
    app: AddOnResponseApp | null;
}
export declare const AddOnResponse: S.Schema<AddOnResponse>;
export type AddOnType = "arcjet" | "enveloop" | "fly_mysql" | "kubernetes" | "redis" | "sentry" | "supabase" | "tigris" | "upstash_kafka" | "upstash_redis" | "upstash_vector" | "wafris";
export declare const AddOnType: any;
export interface AddOnPlansRequest {
    after?: string | null;
    before?: string | null;
    first?: number | null;
    last?: number | null;
    type?: AddOnType | (string & {}) | null;
}
export declare const AddOnPlansRequest: S.Schema<AddOnPlansRequest>;
export type AddOnPlansResponseEdgesItemNode = AddOnResponseAddOnPlan;
export declare const AddOnPlansResponseEdgesItemNode: S.Schema<AddOnResponseAddOnPlan>;
export interface AddOnPlansResponseEdgesItem {
    cursor: string;
    node: AddOnResponseAddOnPlan | null;
}
export declare const AddOnPlansResponseEdgesItem: S.Schema<AddOnPlansResponseEdgesItem>;
export type AddOnPlansResponseEdgesList = (AddOnPlansResponseEdgesItem | null)[];
export declare const AddOnPlansResponseEdgesList: S.Schema<AddOnPlansResponseEdgesList>;
export type AddOnPlansResponseNodesItem = AddOnResponseAddOnPlan;
export declare const AddOnPlansResponseNodesItem: S.Schema<AddOnResponseAddOnPlan>;
export type AddOnPlansResponseNodesList = (AddOnResponseAddOnPlan | null)[];
export declare const AddOnPlansResponseNodesList: S.Schema<AddOnPlansResponseNodesList>;
export interface AddOnPlansResponsePageInfo {
    hasNextPage: boolean;
    hasPreviousPage: boolean;
    startCursor: string | null;
    endCursor: string | null;
}
export declare const AddOnPlansResponsePageInfo: S.Schema<AddOnPlansResponsePageInfo>;
/** Selection set for `addOnPlans` (unwrapped from the GraphQL `data` envelope). */
export interface AddOnPlansResponse {
    edges: AddOnPlansResponseEdgesList | null;
    nodes: AddOnPlansResponseNodesList | null;
    pageInfo: AddOnPlansResponsePageInfo;
    totalCount: number;
}
export declare const AddOnPlansResponse: S.Schema<AddOnPlansResponse>;
export interface AddOnProviderRequest {
    name: string;
}
export declare const AddOnProviderRequest: S.Schema<AddOnProviderRequest>;
/** Selection set for `addOnProvider` (unwrapped from the GraphQL `data` envelope). */
export interface AddOnProviderResponse {
    id: string;
    name: string | null;
    displayName: string | null;
    tosUrl: string | null;
    tosAgreement: string | null;
    asyncProvisioning: boolean;
    autoProvision: boolean;
    beta: boolean;
    internal: boolean;
    selectName: boolean;
    selectRegion: boolean;
    selectReplicaRegions: boolean;
    detectPlatform: boolean;
    resourceName: string;
    nameSuffix: string | null;
    provisioningInstructions: string | null;
}
export declare const AddOnProviderResponse: S.Schema<AddOnProviderResponse>;
export interface AddOnsRequest {
    after?: string | null;
    before?: string | null;
    first?: number | null;
    last?: number | null;
    type?: AddOnType | (string & {}) | null;
}
export declare const AddOnsRequest: S.Schema<AddOnsRequest>;
export type AddOnsResponseEdgesItemNodeReadRegionsList = Array<string>;
export declare const AddOnsResponseEdgesItemNodeReadRegionsList: S.Schema<AddOnsResponseEdgesItemNodeReadRegionsList>;
export type AddOnsResponseEdgesItemNodeAddOnPlan = AddOnResponseAddOnPlan;
export declare const AddOnsResponseEdgesItemNodeAddOnPlan: S.Schema<AddOnResponseAddOnPlan>;
export type AddOnsResponseEdgesItemNodeAddOnProvider = AddOnResponseAddOnProvider;
export declare const AddOnsResponseEdgesItemNodeAddOnProvider: S.Schema<AddOnResponseAddOnProvider>;
export type AddOnsResponseEdgesItemNodeOrganization = AddOnResponseOrganization;
export declare const AddOnsResponseEdgesItemNodeOrganization: S.Schema<AddOnResponseOrganization>;
export type AddOnsResponseEdgesItemNodeApp = AddOnResponseApp;
export declare const AddOnsResponseEdgesItemNodeApp: S.Schema<AddOnResponseApp>;
export interface AddOnsResponseEdgesItemNode {
    id: string;
    name: string | null;
    primaryRegion: string | null;
    readRegions: AddOnsResponseEdgesItemNodeReadRegionsList | null;
    status: string | null;
    errorMessage: string | null;
    publicUrl: string | Redacted.Redacted<string> | null;
    privateIp: string | null;
    password: string | Redacted.Redacted<string> | null;
    ssoLink: string | null;
    environment: unknown | null;
    options: unknown | null;
    metadata: unknown | null;
    createdAt: string;
    updatedAt: string;
    addOnPlan: AddOnResponseAddOnPlan | null;
    addOnPlanName: string | null;
    addOnProvider: AddOnResponseAddOnProvider | null;
    organization: AddOnResponseOrganization;
    app: AddOnResponseApp | null;
}
export declare const AddOnsResponseEdgesItemNode: S.Schema<AddOnsResponseEdgesItemNode>;
export interface AddOnsResponseEdgesItem {
    cursor: string;
    node: AddOnsResponseEdgesItemNode | null;
}
export declare const AddOnsResponseEdgesItem: S.Schema<AddOnsResponseEdgesItem>;
export type AddOnsResponseEdgesList = (AddOnsResponseEdgesItem | null)[];
export declare const AddOnsResponseEdgesList: S.Schema<AddOnsResponseEdgesList>;
export type AddOnsResponseNodesItemReadRegionsList = Array<string>;
export declare const AddOnsResponseNodesItemReadRegionsList: S.Schema<AddOnsResponseNodesItemReadRegionsList>;
export interface AddOnsResponseNodesItem {
    id: string;
    name: string | null;
    primaryRegion: string | null;
    readRegions: AddOnsResponseNodesItemReadRegionsList | null;
    status: string | null;
    errorMessage: string | null;
    publicUrl: string | Redacted.Redacted<string> | null;
    privateIp: string | null;
    password: string | Redacted.Redacted<string> | null;
    ssoLink: string | null;
    environment: unknown | null;
    options: unknown | null;
    metadata: unknown | null;
    createdAt: string;
    updatedAt: string;
    addOnPlanName: string | null;
}
export declare const AddOnsResponseNodesItem: S.Schema<AddOnsResponseNodesItem>;
export type AddOnsResponseNodesList = (AddOnsResponseNodesItem | null)[];
export declare const AddOnsResponseNodesList: S.Schema<AddOnsResponseNodesList>;
export type AddOnsResponsePageInfo = AddOnPlansResponsePageInfo;
export declare const AddOnsResponsePageInfo: S.Schema<AddOnPlansResponsePageInfo>;
/** Selection set for `addOns` (unwrapped from the GraphQL `data` envelope). */
export interface AddOnsResponse {
    edges: AddOnsResponseEdgesList | null;
    nodes: AddOnsResponseNodesList | null;
    pageInfo: AddOnPlansResponsePageInfo;
    totalCount: number;
}
export declare const AddOnsResponse: S.Schema<AddOnsResponse>;
export interface AgreedToProviderTosRequest {
    slug: string;
    providerName: string;
}
export declare const AgreedToProviderTosRequest: S.Schema<AgreedToProviderTosRequest>;
export type AgreedToProviderTosResponse = boolean | null;
export declare const AgreedToProviderTosResponse: S.Schema<AgreedToProviderTosResponse>;
export type StringList = Array<string>;
export declare const StringList: S.Schema<StringList>;
export interface CreateAddOnInput {
    type: AddOnType | (string & {});
    name?: string | null;
    organizationId?: string | null;
    appId?: string | null;
    planId?: string | null;
    primaryRegion?: string | null;
    readRegions?: StringList | null;
    options?: unknown | null;
    organizationPlanId?: string | null;
    clientMutationId?: string | null;
}
export declare const CreateAddOnInput: S.Schema<CreateAddOnInput>;
export interface CreateAddOnRequest {
    input: CreateAddOnInput;
}
export declare const CreateAddOnRequest: S.Schema<CreateAddOnRequest>;
export type CreateAddOnResponseAddOnReadRegionsList = Array<string>;
export declare const CreateAddOnResponseAddOnReadRegionsList: S.Schema<CreateAddOnResponseAddOnReadRegionsList>;
export interface CreateAddOnResponseAddOn {
    id: string;
    name: string | null;
    primaryRegion: string | null;
    readRegions: CreateAddOnResponseAddOnReadRegionsList | null;
    status: string | null;
    errorMessage: string | null;
    publicUrl: string | Redacted.Redacted<string> | null;
    privateIp: string | null;
    password: string | Redacted.Redacted<string> | null;
    ssoLink: string | null;
    environment: unknown | null;
    options: unknown | null;
    metadata: unknown | null;
    createdAt: string;
    updatedAt: string;
    addOnPlanName: string | null;
}
export declare const CreateAddOnResponseAddOn: S.Schema<CreateAddOnResponseAddOn>;
/** Selection set for `createAddOn` (unwrapped from the GraphQL `data` envelope). */
export interface CreateAddOnResponse {
    addOn: CreateAddOnResponseAddOn;
    clientMutationId: string | null;
}
export declare const CreateAddOnResponse: S.Schema<CreateAddOnResponse>;
export interface CreateExtensionTosAgreementInput {
    addOnProviderName: string;
    organizationId?: string | null;
    clientMutationId?: string | null;
}
export declare const CreateExtensionTosAgreementInput: S.Schema<CreateExtensionTosAgreementInput>;
export interface CreateExtensionTosAgreementRequest {
    input: CreateExtensionTosAgreementInput;
}
export declare const CreateExtensionTosAgreementRequest: S.Schema<CreateExtensionTosAgreementRequest>;
/** Selection set for `createExtensionTosAgreement` (unwrapped from the GraphQL `data` envelope). */
export interface CreateExtensionTosAgreementResponse {
    clientMutationId: string | null;
}
export declare const CreateExtensionTosAgreementResponse: S.Schema<CreateExtensionTosAgreementResponse>;
export interface DeleteAddOnInput {
    addOnId?: string | null;
    name?: string | null;
    provider?: string | null;
    clientMutationId?: string | null;
}
export declare const DeleteAddOnInput: S.Schema<DeleteAddOnInput>;
export interface DeleteAddOnRequest {
    input: DeleteAddOnInput;
}
export declare const DeleteAddOnRequest: S.Schema<DeleteAddOnRequest>;
/** Selection set for `deleteAddOn` (unwrapped from the GraphQL `data` envelope). */
export interface DeleteAddOnResponse {
    deletedAddOnName: string | null;
    clientMutationId: string | null;
}
export declare const DeleteAddOnResponse: S.Schema<DeleteAddOnResponse>;
export interface OrganizationRequest {
    id?: string | null;
    name?: string | null;
    slug?: string | null;
}
export declare const OrganizationRequest: S.Schema<OrganizationRequest>;
export type OrganizationResponseAddOnsEdgesItemNodeReadRegionsList = Array<string>;
export declare const OrganizationResponseAddOnsEdgesItemNodeReadRegionsList: S.Schema<OrganizationResponseAddOnsEdgesItemNodeReadRegionsList>;
export interface OrganizationResponseAddOnsEdgesItemNode {
    id: string;
    name: string | null;
    primaryRegion: string | null;
    readRegions: OrganizationResponseAddOnsEdgesItemNodeReadRegionsList | null;
    status: string | null;
    errorMessage: string | null;
    publicUrl: string | Redacted.Redacted<string> | null;
    privateIp: string | null;
    password: string | Redacted.Redacted<string> | null;
    ssoLink: string | null;
    environment: unknown | null;
    options: unknown | null;
    metadata: unknown | null;
    createdAt: string;
    updatedAt: string;
    addOnPlanName: string | null;
}
export declare const OrganizationResponseAddOnsEdgesItemNode: S.Schema<OrganizationResponseAddOnsEdgesItemNode>;
export interface OrganizationResponseAddOnsEdgesItem {
    cursor: string;
    node: OrganizationResponseAddOnsEdgesItemNode | null;
}
export declare const OrganizationResponseAddOnsEdgesItem: S.Schema<OrganizationResponseAddOnsEdgesItem>;
export type OrganizationResponseAddOnsEdgesList = (OrganizationResponseAddOnsEdgesItem | null)[];
export declare const OrganizationResponseAddOnsEdgesList: S.Schema<OrganizationResponseAddOnsEdgesList>;
export type OrganizationResponseAddOnsPageInfo = AddOnPlansResponsePageInfo;
export declare const OrganizationResponseAddOnsPageInfo: S.Schema<AddOnPlansResponsePageInfo>;
export interface OrganizationResponseAddOns {
    edges: OrganizationResponseAddOnsEdgesList | null;
    pageInfo: AddOnPlansResponsePageInfo;
    totalCount: number;
}
export declare const OrganizationResponseAddOns: S.Schema<OrganizationResponseAddOns>;
/** Selection set for `organization` (unwrapped from the GraphQL `data` envelope). */
export interface OrganizationResponse {
    id: string;
    name: string | null;
    slug: string | null;
    rawSlug: string;
    paidPlan: boolean;
    billable: boolean;
    provisionsBetaExtensions: boolean;
    addOns: OrganizationResponseAddOns;
}
export declare const OrganizationResponse: S.Schema<OrganizationResponse>;
export interface ResetAddOnPasswordInput {
    name: string;
    clientMutationId?: string | null;
}
export declare const ResetAddOnPasswordInput: S.Schema<ResetAddOnPasswordInput>;
export interface ResetAddOnPasswordRequest {
    input: ResetAddOnPasswordInput;
}
export declare const ResetAddOnPasswordRequest: S.Schema<ResetAddOnPasswordRequest>;
export type ResetAddOnPasswordResponseAddOnReadRegionsList = Array<string>;
export declare const ResetAddOnPasswordResponseAddOnReadRegionsList: S.Schema<ResetAddOnPasswordResponseAddOnReadRegionsList>;
export interface ResetAddOnPasswordResponseAddOn {
    id: string;
    name: string | null;
    primaryRegion: string | null;
    readRegions: ResetAddOnPasswordResponseAddOnReadRegionsList | null;
    status: string | null;
    errorMessage: string | null;
    publicUrl: string | Redacted.Redacted<string> | null;
    privateIp: string | null;
    password: string | Redacted.Redacted<string> | null;
    ssoLink: string | null;
    environment: unknown | null;
    options: unknown | null;
    metadata: unknown | null;
    createdAt: string;
    updatedAt: string;
    addOnPlanName: string | null;
}
export declare const ResetAddOnPasswordResponseAddOn: S.Schema<ResetAddOnPasswordResponseAddOn>;
/** Selection set for `resetAddOnPassword` (unwrapped from the GraphQL `data` envelope). */
export interface ResetAddOnPasswordResponse {
    addOn: ResetAddOnPasswordResponseAddOn;
    clientMutationId: string | null;
}
export declare const ResetAddOnPasswordResponse: S.Schema<ResetAddOnPasswordResponse>;
export interface UpdateAddOnInput {
    addOnId?: string | null;
    name?: string | null;
    provider?: string | null;
    planId?: string | null;
    readRegions?: StringList | null;
    options?: unknown | null;
    metadata?: unknown | null;
    prodPack?: boolean | null;
    clientMutationId?: string | null;
}
export declare const UpdateAddOnInput: S.Schema<UpdateAddOnInput>;
export interface UpdateAddOnRequest {
    input: UpdateAddOnInput;
}
export declare const UpdateAddOnRequest: S.Schema<UpdateAddOnRequest>;
export type UpdateAddOnResponseAddOnReadRegionsList = Array<string>;
export declare const UpdateAddOnResponseAddOnReadRegionsList: S.Schema<UpdateAddOnResponseAddOnReadRegionsList>;
export interface UpdateAddOnResponseAddOn {
    id: string;
    name: string | null;
    primaryRegion: string | null;
    readRegions: UpdateAddOnResponseAddOnReadRegionsList | null;
    status: string | null;
    errorMessage: string | null;
    publicUrl: string | Redacted.Redacted<string> | null;
    privateIp: string | null;
    password: string | Redacted.Redacted<string> | null;
    ssoLink: string | null;
    environment: unknown | null;
    options: unknown | null;
    metadata: unknown | null;
    createdAt: string;
    updatedAt: string;
    addOnPlanName: string | null;
}
export declare const UpdateAddOnResponseAddOn: S.Schema<UpdateAddOnResponseAddOn>;
/** Selection set for `updateAddOn` (unwrapped from the GraphQL `data` envelope). */
export interface UpdateAddOnResponse {
    addOn: UpdateAddOnResponseAddOn;
    clientMutationId: string | null;
}
export declare const UpdateAddOnResponse: S.Schema<UpdateAddOnResponse>;
export type AddOnError = FlyIoOpError;
export declare const addOn: API.OperationMethod<AddOnRequest, AddOnResponse, AddOnError, FlyIoOpContext>;
export type AddOnPlansError = FlyIoOpError;
export declare const addOnPlans: API.PaginatedOperationMethod<AddOnPlansRequest, AddOnPlansResponse, AddOnPlansError, FlyIoOpContext, AddOnResponseAddOnPlan>;
export type AddOnProviderError = FlyIoOpError;
export declare const addOnProvider: API.OperationMethod<AddOnProviderRequest, AddOnProviderResponse, AddOnProviderError, FlyIoOpContext>;
export type AddOnsError = FlyIoOpError;
export declare const addOns: API.PaginatedOperationMethod<AddOnsRequest, AddOnsResponse, AddOnsError, FlyIoOpContext, AddOnsResponseEdgesItemNode>;
export type AgreedToProviderTosError = FlyIoOpError;
/** Whether the organization has agreed to an add-on provider's ToS. */
export declare const agreedToProviderTos: API.OperationMethod<AgreedToProviderTosRequest, AgreedToProviderTosResponse, AgreedToProviderTosError, FlyIoOpContext>;
export type CreateAddOnError = FlyIoOpError;
export declare const createAddOn: API.OperationMethod<CreateAddOnRequest, CreateAddOnResponse, CreateAddOnError, FlyIoOpContext>;
export type CreateExtensionTosAgreementError = CreateExtensionTosAgreementNotAuthorized | FlyIoOpError;
export declare const createExtensionTosAgreement: API.OperationMethod<CreateExtensionTosAgreementRequest, CreateExtensionTosAgreementResponse, CreateExtensionTosAgreementError, FlyIoOpContext>;
export type DeleteAddOnError = FlyIoOpError;
export declare const deleteAddOn: API.OperationMethod<DeleteAddOnRequest, DeleteAddOnResponse, DeleteAddOnError, FlyIoOpContext>;
export type OrganizationError = FlyIoOpError;
export declare const organization: API.OperationMethod<OrganizationRequest, OrganizationResponse, OrganizationError, FlyIoOpContext>;
export type ResetAddOnPasswordError = FlyIoOpError;
export declare const resetAddOnPassword: API.OperationMethod<ResetAddOnPasswordRequest, ResetAddOnPasswordResponse, ResetAddOnPasswordError, FlyIoOpContext>;
export type UpdateAddOnError = FlyIoOpError;
export declare const updateAddOn: API.OperationMethod<UpdateAddOnRequest, UpdateAddOnResponse, UpdateAddOnError, FlyIoOpContext>;
//# sourceMappingURL=addons.d.ts.map