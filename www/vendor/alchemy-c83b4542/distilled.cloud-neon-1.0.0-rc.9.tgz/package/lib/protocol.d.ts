import type * as Layer from "effect/Layer";
import type * as HttpClient from "effect/unstable/http/HttpClient";
import type * as HttpClientError from "effect/unstable/http/HttpClientError";
import type * as API from "@distilled.cloud/core/api";
import type { API_ERRORS, ConfigError } from "@distilled.cloud/core/errors";
import { Credentials } from "./credentials.ts";
import { UnknownNeonError } from "./errors.ts";
/**
 * Error channel shared by every generated Neon operation. Generated service
 * files annotate operations with `API.OperationMethod<I, O, NeonOpError,
 * NeonOpContext>` explicitly so the compiler never infers these back out of
 * the schema generics.
 */
export type NeonOpError = InstanceType<(typeof API_ERRORS)[number]> | UnknownNeonError | ConfigError | HttpClientError.HttpClientError;
/** Context (requirements) shared by every generated Neon operation. */
export type NeonOpContext = Credentials | HttpClient.HttpClient;
export declare const NeonProtocol: Layer.Layer<API.Protocol>;
//# sourceMappingURL=protocol.d.ts.map