/**
 * Neon-specific error types.
 *
 * Re-exports the common HTTP errors from core and adds the Neon fallback
 * errors. Note the generated service module additionally defines its own
 * per-status matcher classes (BadRequest/NotFound/…) for the statuses each
 * operation declares — those share `_tag`s with the core classes here, so
 * `catchTag` works against either.
 */
export { BadGateway, BadRequest, Conflict, ConfigError, Forbidden, GatewayTimeout, InternalServerError, Locked, NotFound, ServiceUnavailable, TooManyRequests, Unauthorized, UnprocessableEntity, HTTP_STATUS_MAP, DEFAULT_ERRORS, API_ERRORS, } from "@distilled.cloud/core/errors";
export type { DefaultErrors } from "@distilled.cloud/core/errors";
import * as Schema from "effect/Schema";
declare const UnknownNeonError_base: Schema.Class<UnknownNeonError, Schema.TaggedStruct<"UnknownNeonError", {
    readonly code: Schema.optional<Schema.String>;
    readonly message: Schema.optional<Schema.String>;
    readonly body: Schema.Unknown;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
/** Unknown Neon error — returned when nothing else matches the failure. */
export declare class UnknownNeonError extends UnknownNeonError_base {
}
declare const NeonParseError_base: Schema.Class<NeonParseError, Schema.TaggedStruct<"NeonParseError", {
    readonly body: Schema.Unknown;
    readonly cause: Schema.Unknown;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ParseError: true;
    };
});
/** Schema parse error wrapper (kept for v0 surface parity). */
export declare class NeonParseError extends NeonParseError_base {
}
//# sourceMappingURL=errors.d.ts.map