/**
 * Neon credentials — hand-written.
 *
 * API-compatible port of the distilled v0 Neon credentials module: the
 * `Credentials` service holds an *effect* that resolves the current
 * credentials on every request (the protocol layer resolves it per request
 * on the calling fiber).
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
export declare const DEFAULT_API_BASE_URL = "https://console.neon.tech/api/v2";
export interface Config {
    readonly apiKey: Redacted.Redacted<string>;
    readonly apiBaseUrl: string;
}
declare const Credentials_base: Context.ServiceClass<Credentials, "NeonCredentials", Effect.Effect<Config, never, never>>;
export declare class Credentials extends Credentials_base {
}
/** Layer from a plain API key + optional base URL. */
export declare const fromApiKey: (config: {
    readonly apiKey: string;
    readonly apiBaseUrl?: string;
}) => Layer.Layer<Credentials>;
/** Reads NEON_API_KEY (required) and NEON_API_BASE_URL (optional). */
export declare const CredentialsFromEnv: Layer.Layer<Credentials>;
export {};
//# sourceMappingURL=credentials.d.ts.map