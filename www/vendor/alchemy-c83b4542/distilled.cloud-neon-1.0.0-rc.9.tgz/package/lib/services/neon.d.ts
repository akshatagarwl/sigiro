import * as S from "@distilled.cloud/core/schema";
import * as Redacted from "effect/Redacted";
import * as API from "@distilled.cloud/core/api";
import { type NeonOpError, type NeonOpContext } from "../protocol.ts";
export type { NeonOpError, NeonOpContext };
declare const BadRequest_base: S.Class<BadRequest, S.TaggedStruct<"BadRequest", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequest extends /*@__PURE__*/ BadRequest_base {
}
declare const Conflict_base: S.Class<Conflict, S.TaggedStruct<"Conflict", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class Conflict extends /*@__PURE__*/ Conflict_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const NotFound_base: S.Class<NotFound, S.TaggedStruct<"NotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
declare const UnprocessableEntity_base: S.Class<UnprocessableEntity, S.TaggedStruct<"UnprocessableEntity", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntity extends /*@__PURE__*/ UnprocessableEntity_base {
}
export interface AcceptProjectTransferRequestRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon project transfer request ID */
    request_id: string;
    /** The Neon organization ID to transfer the project to. If not provided, the project will be transferred to the current user or organization account. */
    org_id?: string;
}
export declare const AcceptProjectTransferRequestRequest: S.Schema<AcceptProjectTransferRequestRequest>;
export interface AcceptProjectTransferRequestResponse {
}
export declare const AcceptProjectTransferRequestResponse: S.Schema<AcceptProjectTransferRequestResponse>;
export type NeonAuthOauthProviderId = "google" | "github" | "microsoft" | "vercel";
export declare const NeonAuthOauthProviderId: any;
export interface AddBranchNeonAuthOauthProviderRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** OAuth provider to configure for Neon Auth. Known values: `google`, `github`, `microsoft`, `vercel`. */
    id: NeonAuthOauthProviderId | (string & {});
    /** The client ID issued by the OAuth provider for your application. Used to identify the application during the OAuth flow. */
    client_id?: string;
    /** OAuth client secret for the provider. */
    client_secret?: string | Redacted.Redacted<string>;
    /** Tenant ID for the Microsoft OAuth provider. Only relevant when the OAuth provider is Microsoft; omit or leave blank for other providers. */
    microsoft_tenant_id?: string;
}
export declare const AddBranchNeonAuthOauthProviderRequest: S.Schema<AddBranchNeonAuthOauthProviderRequest>;
export type NeonAuthOauthProviderType = "standard" | "shared";
export declare const NeonAuthOauthProviderType: any;
export interface NeonAuthOauthProvider {
    /** The OAuth provider's ID. */
    id: NeonAuthOauthProviderId;
    /** OAuth provider key type. `standard` uses your own OAuth credentials. `shared` uses Neon-managed keys intended for development only; they display Neon branding on the OAuth consent screen and must not be used in production. */
    type: NeonAuthOauthProviderType;
    /** Public identifier for the OAuth application, issued by the provider when the application is registered. */
    client_id?: string;
    /** OAuth client secret for the provider. */
    client_secret?: string | Redacted.Redacted<string>;
}
export declare const NeonAuthOauthProvider: S.Schema<NeonAuthOauthProvider>;
/** Authentication provider integrated with this Neon Auth configuration. `better_auth` integrates with Better Auth (the current, recommended provider). `stack` integrates with Stack Auth (deprecated). `mock` is a simulated provider for local development and testing only. */
export type NeonAuthSupportedAuthProvider = "mock" | "stack" | "better_auth";
export declare const NeonAuthSupportedAuthProvider: any;
export interface AddBranchNeonAuthTrustedDomainRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** URI to add to the redirect URI allowlist for the auth provider. */
    domain: string;
    auth_provider: NeonAuthSupportedAuthProvider | (string & {});
}
export declare const AddBranchNeonAuthTrustedDomainRequest: S.Schema<AddBranchNeonAuthTrustedDomainRequest>;
export interface AddBranchNeonAuthTrustedDomainResponse {
}
export declare const AddBranchNeonAuthTrustedDomainResponse: S.Schema<AddBranchNeonAuthTrustedDomainResponse>;
/** Deprecated. The roles the JWKS should be mapped to. By default, the JWKS is mapped to the `authenticator`, `authenticated`, and `anonymous` roles. */
export type AddProjectJWKSRequestRoleNamesList = Array<string>;
export declare const AddProjectJWKSRequestRoleNamesList: S.Schema<AddProjectJWKSRequestRoleNamesList>;
export interface AddProjectJWKSRequest {
    /** The Neon project ID */
    project_id: string;
    /** URL of the provider's JWKS endpoint used to verify JWTs. */
    jwks_url: string;
    /** The name of the authentication provider (e.g., Clerk, Stytch, Auth0) */
    provider_name: string;
    /** The Neon branch ID. Returned as `id` from `GET /projects/{project_id}/branches`. */
    branch_id?: string;
    /** Expected `aud` claim in incoming JWTs. When set, tokens with a different audience are rejected; tokens with no audience are still accepted. Omit to skip audience validation. */
    jwt_audience?: string;
    /** Deprecated. The roles the JWKS should be mapped to. By default, the JWKS is mapped to the `authenticator`, `authenticated`, and `anonymous` roles. */
    role_names?: AddProjectJWKSRequestRoleNamesList;
    /** Deprecated. Only used with Neon RLS. If true, role creation is skipped. */
    skip_role_creation?: boolean;
}
export declare const AddProjectJWKSRequest: S.Schema<AddProjectJWKSRequest>;
/** Database role names that are permitted to authenticate using this JWKS configuration. */
export type JWKSRoleNamesList = Array<string>;
export declare const JWKSRoleNamesList: S.Schema<JWKSRoleNamesList>;
export interface JWKS {
    /** The JWKS configuration's ID. */
    id: string;
    /** The Neon project ID. Returned as `id` from `GET /projects`. */
    project_id: string;
    /** The Neon branch ID. Returned as `id` from `GET /projects/{project_id}/branches`. */
    branch_id?: string;
    /** URL of the provider's JWKS endpoint used to verify JWTs. */
    jwks_url: string;
    /** The name of the authentication provider (e.g., Clerk, Stytch, Auth0) */
    provider_name: string;
    /** The date and time when the JWKS was created */
    created_at: string;
    /** The date and time when the JWKS was last modified */
    updated_at: string;
    /** Expected JWT `aud` claim value configured for this JWKS. */
    jwt_audience?: string;
    /** Database role names that are permitted to authenticate using this JWKS configuration. */
    role_names?: JWKSRoleNamesList;
}
export declare const JWKS: S.Schema<JWKS>;
/** The action performed by the operation */
export type OperationAction = "create_compute" | "create_timeline" | "start_compute" | "suspend_compute" | "apply_config" | "check_availability" | "delete_timeline" | "create_branch" | "import_data" | "tenant_ignore" | "tenant_attach" | "tenant_detach" | "tenant_detach_safekeepers" | "tenant_attach_safekeepers" | "tenant_reattach" | "replace_safekeeper" | "disable_maintenance" | "apply_storage_config" | "prepare_secondary_pageserver" | "switch_pageserver" | "detach_parent_branch" | "timeline_archive" | "timeline_unarchive" | "start_reserved_compute" | "sync_dbs_and_roles_from_compute" | "apply_schema_from_branch" | "timeline_mark_invisible" | "timeline_update_protected_config" | "prewarm_replica" | "promote_replica" | "set_storage_non_dirty" | "swap_binding_id" | "finalize_migration" | "mark_migration_prepared" | "update_catalog" | "epc_sync";
export declare const OperationAction: any;
/** Lifecycle state of the operation. `scheduling`: queued, not yet started. `running`: actively executing. `finished`: completed successfully. `failed`: ended with a failure. `error`: ended with a terminal error. `cancelling`: cancellation requested but not yet complete. `cancelled`: stopped before completion. `skipped`: bypassed without executing. */
export type OperationStatus = "scheduling" | "running" | "finished" | "failed" | "error" | "cancelling" | "cancelled" | "skipped";
export declare const OperationStatus: any;
/** An asynchronous action Neon performs on your resources (for example, starting a compute or creating a branch). Fields such as `action`, `status`, and `total_duration_ms` describe the operation and its progress. */
export interface Operation {
    /** The operation ID */
    id: string;
    /** The ID of the project this operation ran on. */
    project_id: string;
    /** The ID of the branch this operation ran on. */
    branch_id?: string;
    /** The ID of the compute endpoint this operation ran on. */
    endpoint_id?: string;
    action: OperationAction;
    /** Current lifecycle state of the operation. On `failed`, see `failures_count` and `retry_at` for retry detail. */
    status: OperationStatus;
    /** Human-readable message describing why the operation failed. */
    error?: string;
    /** The number of times the operation failed */
    failures_count: number;
    /** A timestamp indicating when the operation was last retried */
    retry_at?: string;
    /** A timestamp indicating when the operation was created */
    created_at: string;
    /** A timestamp indicating when the operation status was last updated */
    updated_at: string;
    /** The total duration of the operation in milliseconds */
    total_duration_ms: number;
}
export declare const Operation: S.Schema<Operation>;
export type AddProjectJWKSResponseOperationsList = Array<Operation>;
export declare const AddProjectJWKSResponseOperationsList: S.Schema<AddProjectJWKSResponseOperationsList>;
export interface AddProjectJWKSResponse {
    /** JWKS configuration associated with the project. */
    jwks: JWKS;
    operations: AddProjectJWKSResponseOperationsList;
}
export declare const AddProjectJWKSResponse: S.Schema<AddProjectJWKSResponse>;
export interface AssignOrganizationVPCEndpointRequest {
    /** The Neon organization ID */
    org_id: string;
    /** The Neon region ID. Azure regions are currently not supported. */
    region_id: string;
    /** The VPC endpoint ID */
    vpc_endpoint_id: string;
    /** Human-readable name for the VPC endpoint assignment, used to identify it within the organization. */
    label: string;
}
export declare const AssignOrganizationVPCEndpointRequest: S.Schema<AssignOrganizationVPCEndpointRequest>;
export interface AssignOrganizationVPCEndpointResponse {
}
export declare const AssignOrganizationVPCEndpointResponse: S.Schema<AssignOrganizationVPCEndpointResponse>;
export interface AssignProjectVPCEndpointRequest {
    /** The Neon project ID */
    project_id: string;
    /** The VPC endpoint ID */
    vpc_endpoint_id: string;
    /** Human-readable name for the VPC endpoint assignment, used to identify it within the organization. */
    label: string;
}
export declare const AssignProjectVPCEndpointRequest: S.Schema<AssignProjectVPCEndpointRequest>;
export interface AssignProjectVPCEndpointResponse {
}
export declare const AssignProjectVPCEndpointResponse: S.Schema<AssignProjectVPCEndpointResponse>;
export interface CountProjectBranchesRequest {
    /** The Neon project ID */
    project_id: string;
    /** Count branches matching the `name` in search query */
    search?: string;
}
export declare const CountProjectBranchesRequest: S.Schema<CountProjectBranchesRequest>;
export interface CountProjectBranchesResponse {
    /** Total number of branches in the project. */
    count: number;
}
export declare const CountProjectBranchesResponse: S.Schema<CountProjectBranchesResponse>;
export interface CreateApiKeyRequest {
    /** A user-specified API key name. This value is required when creating an API key. */
    key_name: string;
}
export declare const CreateApiKeyRequest: S.Schema<CreateApiKeyRequest>;
export interface ApiKeyCreateResponse {
    /** The API key's unique numeric ID. Distinct from the API key token (`key`). */
    id: number;
    /** The generated 64-bit token required to access the Neon API */
    key: string;
    /** The user-specified API key name */
    name: string;
    /** A timestamp indicating when the API key was created */
    created_at: string;
    /** ID of the user who created this API key */
    created_by: string;
}
export declare const ApiKeyCreateResponse: S.Schema<ApiKeyCreateResponse>;
export interface CreateBranchNeonAuthNewUserRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** Email address of the new Neon Auth user to create. */
    email: string;
    /** Display name for the new user. Optional. Pair with the required email field when creating a new user. */
    name?: string;
}
export declare const CreateBranchNeonAuthNewUserRequest: S.Schema<CreateBranchNeonAuthNewUserRequest>;
export interface NeonAuthCreateNewUserResponse {
    /** ID of newly created user */
    id: string;
}
export declare const NeonAuthCreateNewUserResponse: S.Schema<NeonAuthCreateNewUserResponse>;
/** A single capability you may request when issuing a credential. A credential is granted a set of these; it may only perform actions explicitly listed in its scopes. This is the *requestable* set. Responses describing an existing credential use `GrantedCredentialScope`, which is deliberately wider: a credential may have been granted a scope that this endpoint does not offer, and a response must be able to report it. */
export type CredentialScope = "storage:read" | "storage:write" | "ai_gateway:invoke" | "functions:invoke";
export declare const CredentialScope: any;
export type CreateCredentialRequestScopesList = Array<CredentialScope | (string & {})>;
export declare const CreateCredentialRequestScopesList: S.Schema<CreateCredentialRequestScopesList>;
/** Principal type for the credential. Only `user` is customer-managed and accepted here. `function` and `system` credentials are platform-internal (e.g. function-serve auto-mint, presign signer) and are never issued through the customer-facing API. */
export type CreateCredentialRequestPrincipalType = "user";
export declare const CreateCredentialRequestPrincipalType: any;
export interface CreateCredentialRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** Free-form customer label for the credential. */
    name?: string;
    scopes: CreateCredentialRequestScopesList;
    /** Principal type for the credential. Only `user` is customer-managed and accepted here. `function` and `system` credentials are platform-internal (e.g. function-serve auto-mint, presign signer) and are never issued through the customer-facing API. */
    principal_type: CreateCredentialRequestPrincipalType | (string & {});
}
export declare const CreateCredentialRequest: S.Schema<CreateCredentialRequest>;
/** A single capability a credential actually carries, as reported by responses that describe an existing credential. This set is a superset of `CredentialScope` (the requestable set) because a credential's scopes are not limited to what this API offers: the platform accepts additional scopes for customer-managed (`user`) credentials, so one may exist on your branch that was not issued through this endpoint. Responses must be able to report such a credential rather than fail to describe it — a client that rejected the value would, on rotate, discard the replacement secret after the rotation had already committed. Treat unknown values as opaque. */
export type GrantedCredentialScope = "storage:read" | "storage:write" | "ai_gateway:invoke" | "telemetry:write" | "functions:invoke";
export declare const GrantedCredentialScope: any;
export type CreateCredentialResponseScopesList = Array<GrantedCredentialScope>;
export declare const CreateCredentialResponseScopesList: S.Schema<CreateCredentialResponseScopesList>;
export interface CreateCredentialResponse {
    /** Opaque credential id (e.g. nak_live_<32hex>). */
    token_id: string;
    /** First 12 hex chars of token_id; safe to log. */
    token_id_short: string;
    /** Customer-supplied label, echoed back from the request. Absent when not provided. */
    name?: string;
    /** Bearer token; returned exactly once. */
    api_token: string | Redacted.Redacted<string>;
    /** nsk_live_<64 hex>; the AWS_SECRET_ACCESS_KEY, returned exactly once. */
    s3_secret_access_key: string;
    scopes: CreateCredentialResponseScopesList;
    branch_id: string;
    created_at: string;
    /** When the credential expires; absent means never expires. */
    expires_at?: string;
}
export declare const CreateCredentialResponse: S.Schema<CreateCredentialResponse>;
export interface CreateNeonAuthRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    auth_provider: NeonAuthSupportedAuthProvider | (string & {});
    /** Name of the database to enable Neon Auth on. When omitted, the integration uses the project's default database. */
    database_name?: string;
}
export declare const CreateNeonAuthRequest: S.Schema<CreateNeonAuthRequest>;
export interface NeonAuthCreateIntegrationResponse {
    auth_provider: NeonAuthSupportedAuthProvider;
    /** Project ID assigned by the auth provider for this integration. */
    auth_provider_project_id: string;
    /** Publishable SDK key from the auth provider. Populated only for Stack Auth (deprecated); empty for Better Auth. */
    pub_client_key: string;
    /** Secret server-side SDK key from the auth provider. Populated only for Stack Auth (deprecated); empty for Better Auth. Treat as a credential. */
    secret_server_key: string;
    /** URL of the provider's JWKS endpoint used to verify JWTs. */
    jwks_url: string;
    /** Postgres schema containing the auth integration tables. Defaults to `neon_auth`. */
    schema_name: string;
    /** Postgres table in the integration schema where synced user records are stored. */
    table_name: string;
    /** Base URL of the Neon Auth service for this integration. Set as the NEON_AUTH_BASE_URL environment variable in your application. */
    base_url?: string;
}
export declare const NeonAuthCreateIntegrationResponse: S.Schema<NeonAuthCreateIntegrationResponse>;
export interface CreateNeonAuthProviderSDKKeysRequest {
    /** The Neon project ID. Returned as `id` from `GET /projects`. */
    project_id: string;
    auth_provider: NeonAuthSupportedAuthProvider | (string & {});
}
export declare const CreateNeonAuthProviderSDKKeysRequest: S.Schema<CreateNeonAuthProviderSDKKeysRequest>;
/** Organization member's role. `admin`: full administrative access. `editor` (and its legacy alias `member`): standard access governed by project permissions. `viewer` and `collaborator`: additional scoped project roles. Some values may not be available for all organizations. */
export type MemberRole = "admin" | "member" | "editor" | "viewer" | "collaborator";
export declare const MemberRole: any;
export interface OrganizationInviteCreateRequest {
    /** Email address of the person to invite to the organization. */
    email: string;
    role: MemberRole | (string & {});
}
export declare const OrganizationInviteCreateRequest: S.Schema<OrganizationInviteCreateRequest>;
/** Invitations to create for the organization. */
export type CreateOrganizationInvitationsRequestInvitationsList = Array<OrganizationInviteCreateRequest>;
export declare const CreateOrganizationInvitationsRequestInvitationsList: S.Schema<CreateOrganizationInvitationsRequestInvitationsList>;
export interface CreateOrganizationInvitationsRequest {
    /** The Neon organization ID */
    org_id: string;
    /** Invitations to create for the organization. */
    invitations: CreateOrganizationInvitationsRequestInvitationsList;
}
export declare const CreateOrganizationInvitationsRequest: S.Schema<CreateOrganizationInvitationsRequest>;
export interface Invitation {
    /** The invitation ID. */
    id: string;
    /** Email of the invited user */
    email: string;
    /** Organization id as it is stored in Neon */
    org_id: string;
    /** UUID for the user_id who extended the invitation */
    invited_by: string;
    /** Timestamp when the invitation was created */
    invited_at: string;
    role: MemberRole;
}
export declare const Invitation: S.Schema<Invitation>;
/** List of pending invitations for the organization. */
export type OrganizationInvitationsResponseInvitationsList = Array<Invitation>;
export declare const OrganizationInvitationsResponseInvitationsList: S.Schema<OrganizationInvitationsResponseInvitationsList>;
export interface OrganizationInvitationsResponse {
    /** List of pending invitations for the organization. */
    invitations: OrganizationInvitationsResponseInvitationsList;
}
export declare const OrganizationInvitationsResponse: S.Schema<OrganizationInvitationsResponse>;
export interface CreateOrgApiKeyRequest {
    /** The Neon organization ID */
    org_id: string;
    /** A user-specified API key name. This value is required when creating an API key. */
    key_name: string;
    /** If set, the API key can access only this project */
    project_id?: string;
}
export declare const CreateOrgApiKeyRequest: S.Schema<CreateOrgApiKeyRequest>;
export interface CreateOrgApiKeyResponse {
    /** The API key's unique numeric ID. Distinct from the API key token (`key`). */
    id: number;
    /** The generated 64-bit token required to access the Neon API */
    key: string;
    /** The user-specified API key name */
    name: string;
    /** A timestamp indicating when the API key was created */
    created_at: string;
    /** ID of the user who created this API key */
    created_by: string;
    /** If set, the API key can access only this project */
    project_id?: string;
}
export declare const CreateOrgApiKeyResponse: S.Schema<CreateOrgApiKeyResponse>;
/** Per-project consumption quotas. If a quota is exceeded, all active computes are automatically suspended and cannot be started via API calls or incoming connections. The exception is `logical_size_bytes`, which is enforced per branch. If a branch exceeds its `logical_size_bytes` quota, computes can still be started, but write operations will fail—allowing data to be deleted to free up space. Computes on other branches are not affected. Setting `logical_size_bytes` overrides any lower value set by the `neon.max_cluster_size` Postgres setting. Quotas are enforced using per-project consumption metrics with the same names. These metrics reset at the start of each billing period. `logical_size_bytes` is also an exception—it reflects the total data stored in a branch and does not reset. A zero or empty quota value means “unlimited.” */
export interface ProjectQuota {
    /** The total amount of wall-clock time allowed to be spent by the project's compute endpoints. */
    active_time_seconds?: number;
    /** The total amount of CPU seconds allowed to be spent by the project's compute endpoints. */
    compute_time_seconds?: number;
    /** Total amount of data written to all of a project's branches. */
    written_data_bytes?: number;
    /** Total amount of data transferred from all of a project's branches using the proxy. */
    data_transfer_bytes?: number;
    /** Limit on the logical size of every project's branch. If a branch exceeds its `logical_size_bytes` quota, computes can still be started, but write operations will fail—allowing data to be deleted to free up space. Computes on other branches are not affected. Setting `logical_size_bytes` overrides any lower value set by the `neon.max_cluster_size` Postgres setting. */
    logical_size_bytes?: number;
}
export declare const ProjectQuota: S.Schema<ProjectQuota>;
/** A list of IP addresses that are allowed to connect to the endpoint. */
export type AllowedIpsIpsList = Array<string>;
export declare const AllowedIpsIpsList: S.Schema<AllowedIpsIpsList>;
/** A list of IP addresses that are allowed to connect to the compute endpoint. If the list is empty or not set, all IP addresses are allowed. If protected_branches_only is true, the list will be applied only to protected branches. */
export interface AllowedIps {
    /** A list of IP addresses that are allowed to connect to the endpoint. */
    ips?: AllowedIpsIpsList;
    /** If true, the list will be applied only to protected branches. */
    protected_branches_only?: boolean;
}
export declare const AllowedIps: S.Schema<AllowedIps>;
/** A list of weekdays when the maintenance window is active. Encoded as ints, where 1 - Monday, and 7 - Sunday. */
export type MaintenanceWindowWeekdaysList = Array<number>;
export declare const MaintenanceWindowWeekdaysList: S.Schema<MaintenanceWindowWeekdaysList>;
/** A maintenance window is a time period during which Neon may perform maintenance on the project's infrastructure. During this time, the project's compute endpoints may be unavailable and existing connections can be interrupted. */
export interface MaintenanceWindow {
    /** A list of weekdays when the maintenance window is active. Encoded as ints, where 1 - Monday, and 7 - Sunday. */
    weekdays: MaintenanceWindowWeekdaysList;
    /** Start time of the maintenance window, in the format of "HH:MM". Uses UTC. */
    start_time: string;
    /** End time of the maintenance window, in the format of "HH:MM". Uses UTC. */
    end_time: string;
}
export declare const MaintenanceWindow: S.Schema<MaintenanceWindow>;
export type ProjectAuditLogLevel = "base" | "extended" | "full";
export declare const ProjectAuditLogLevel: any;
/** Names of shared preload libraries to enable for the project. */
export type PreloadLibrariesEnabledLibrariesList = Array<string>;
export declare const PreloadLibrariesEnabledLibrariesList: S.Schema<PreloadLibrariesEnabledLibrariesList>;
/** The shared libraries to preload into the project's compute instances. */
export interface PreloadLibraries {
    /** When true, the project's preload libraries include the platform default set in addition to any libraries listed in `enabled_libraries`. */
    use_defaults?: boolean;
    /** Names of shared preload libraries to enable for the project. */
    enabled_libraries?: PreloadLibrariesEnabledLibrariesList;
}
export declare const PreloadLibraries: S.Schema<PreloadLibraries>;
export interface ProjectSettingsData {
    quota?: ProjectQuota;
    allowed_ips?: AllowedIps;
    /** Sets wal_level=logical for all compute endpoints in this project. All active endpoints will be suspended. Once enabled, logical replication cannot be disabled. */
    enable_logical_replication?: boolean;
    maintenance_window?: MaintenanceWindow;
    /** When set, connections from the public internet are disallowed. This supersedes the AllowedIPs list. This parameter is under active development and its semantics may change in the future. */
    block_public_connections?: boolean;
    /** When set, connections using VPC endpoints are disallowed. This parameter is under active development and its semantics may change in the future. */
    block_vpc_connections?: boolean;
    /** Audit logging level, set only on HIPAA-enabled organizations (absent otherwise). Values: `base`, `extended`, `full`; HIPAA defaults to `extended`. Cannot be lowered back to `base` once `extended` or `full`. */
    audit_log_level?: ProjectAuditLogLevel | (string & {});
    /** Enables HIPAA compliance mode for the project, including audit logging. */
    hipaa?: boolean;
    preload_libraries?: PreloadLibraries;
}
export declare const ProjectSettingsData: S.Schema<ProjectSettingsData>;
/** A free-form map of string key-value pairs for attaching metadata to a resource (for example, a git commit reference). Maximum 50 entries. */
export type AnnotationValueData = {
    [key: string]: string | undefined;
};
export declare const AnnotationValueData: S.Schema<AnnotationValueData>;
/** Configuration for the initial branch created with the project. */
export interface CreateProjectRequestProjectBranch {
    /** The default branch name. If not specified, the default branch name, `main`, will be used. */
    name?: string;
    /** The role name. If not specified, the default role name, `{database_name}_owner`, will be used. */
    role_name?: string;
    /** The database name. If not specified, the default database name, `neondb`, will be used. */
    database_name?: string;
    /** Arbitrary key-value metadata to attach to the branch. */
    annotations?: AnnotationValueData;
}
export declare const CreateProjectRequestProjectBranch: S.Schema<CreateProjectRequestProjectBranch>;
/** A raw representation of Postgres settings */
export type PgSettingsData = {
    [key: string]: string | undefined;
};
export declare const PgSettingsData: S.Schema<PgSettingsData>;
/** Deprecated. A raw representation of PgBouncer settings. Removal scheduled for June 20, 2026. */
export type PgbouncerSettingsData = {
    [key: string]: string | undefined;
};
export declare const PgbouncerSettingsData: S.Schema<PgbouncerSettingsData>;
/** A collection of settings for a Neon endpoint */
export interface DefaultEndpointSettings {
    pg_settings?: PgSettingsData;
    /** Deprecated. Use the endpoint-level connection pooler configuration instead. Removal scheduled for June 20, 2026. */
    pgbouncer_settings?: PgbouncerSettingsData;
    /** Minimum number of Compute Units for this endpoint. At least 0.25 and no greater than `autoscaling_limit_max_cu`. */
    autoscaling_limit_min_cu?: number;
    /** Default maximum number of Compute Units for endpoints created under this account. At least 0.25. */
    autoscaling_limit_max_cu?: number;
    /** Scale-to-zero idle timeout, in seconds, before the compute suspends. `0` uses the plan default; `-1` disables scale-to-zero (never suspends). Minimum is plan-dependent (Scale: 60); maximum 604800 (one week). Free cannot change it; Launch can only enable or disable; Scale can set any value. */
    suspend_timeout_seconds?: number;
}
export declare const DefaultEndpointSettings: S.Schema<DefaultEndpointSettings>;
/** Configuration for the new project, including name, region, and Postgres compute and storage settings. */
export interface CreateProjectRequestProject {
    /** Project-level settings applied at creation. */
    settings?: ProjectSettingsData;
    /** The project name. If not specified, the name will be identical to the generated project ID */
    name?: string;
    /** Configuration for the initial branch created with the project. */
    branch?: CreateProjectRequestProjectBranch;
    /** Deprecated. Use `default_endpoint_settings.autoscaling_limit_min_cu` instead. The minimum number of Compute Units. The minimum value is `0.25`. See [Compute size and Autoscaling configuration](https://neon.com/docs/manage/endpoints#compute-size-and-autoscaling-configuration) for more information. */
    autoscaling_limit_min_cu?: number;
    /** Deprecated. Use `default_endpoint_settings.autoscaling_limit_max_cu` instead. The maximum number of Compute Units. See [Compute size and Autoscaling configuration](https://neon.com/docs/manage/endpoints#compute-size-and-autoscaling-configuration) for more information. */
    autoscaling_limit_max_cu?: number;
    /** Compute provisioner. `k8s-neonvm` (default) supports Autoscaling; `k8s-pod` is fixed-size compute. Also `docker` and `serverless-platform`. */
    provisioner?: string;
    /** The region identifier. Refer to our [Regions](https://neon.com/docs/introduction/regions) documentation for supported regions. Values are specified in this format: `aws-us-east-1` */
    region_id?: string;
    default_endpoint_settings?: DefaultEndpointSettings;
    pg_version?: number;
    /** Whether or not passwords are stored for roles in the Neon project. Storing passwords facilitates access to Neon features that require authorization. */
    store_passwords?: boolean;
    /** History window (point-in-time restore range) for all branches, in seconds. `0` disables it. Default 1 day (Free: 6 hours). Maximum depends on plan: Free 6 hours (21600), Launch 7 days (604800), Scale 30 days (2592000). */
    history_retention_seconds?: number;
    /** ID of the organization that will own the project. If omitted when using an organization API key, it is inferred from the key. */
    org_id?: string;
}
export declare const CreateProjectRequestProject: S.Schema<CreateProjectRequestProject>;
export interface CreateProjectRequest {
    /** Configuration for the new project, including name, region, and Postgres compute and storage settings. */
    project: CreateProjectRequestProject;
}
export declare const CreateProjectRequest: S.Schema<CreateProjectRequest>;
/** Type of subscription to Neon Cloud. Notice that for users without billing account this will be "UNKNOWN" */
export type BillingSubscriptionType = "UNKNOWN" | "direct_sales" | "direct_sales_v3" | "aws_marketplace" | "free_v2" | "free_v3" | "launch" | "launch_v3" | "scale" | "scale_v3" | "business" | "vercel_pg_legacy";
export declare const BillingSubscriptionType: any;
export interface ProjectOwnerData {
    /** Email address of the project owner. */
    email: string;
    /** Display name of the project owner. */
    name: string;
    /** Maximum number of branches the owner is allowed to create across their projects. */
    branches_limit: number;
    subscription_type: BillingSubscriptionType;
}
export declare const ProjectOwnerData: S.Schema<ProjectOwnerData>;
/** The caller's effective permission for a project when per-project permissions are enabled. `VIEWER` grants read access, `EDITOR` adds update access, and `ADMIN` grants full management. Omitted for personal projects, flag-off organizations, and non-user subjects. */
export type ProjectPermissionLevel = "VIEWER" | "EDITOR" | "ADMIN";
export declare const ProjectPermissionLevel: any;
export interface Project {
    /** Bytes-Hour. Project consumed that much Postgres storage hourly during the billing period. The value has some lag. The value is reset at the beginning of each billing period. */
    data_storage_bytes_hour: number;
    /** Bytes. Egress traffic from the Neon cloud to the client for given project over the billing period. Includes deleted endpoints. The value has some lag. The value is reset at the beginning of each billing period. */
    data_transfer_bytes: number;
    /** Bytes. Amount of WAL that travelled through Postgres storage for given project across all branches. The value has some lag. The value is reset at the beginning of each billing period. */
    written_data_bytes: number;
    /** Seconds. The number of CPU seconds used by the project's compute endpoints, including compute endpoints that have been deleted. The value has some lag. The value is reset at the beginning of each billing period. Examples: 1. An endpoint that uses 1 CPU for 1 second is equal to `compute_time=1`. 2. An endpoint that uses 2 CPUs simultaneously for 1 second is equal to `compute_time=2`. */
    compute_time_seconds: number;
    /** Seconds. Control plane observed endpoints of this project being active this amount of wall-clock time. The value has some lag. The value is reset at the beginning of each billing period. */
    active_time_seconds: number;
    /** Deprecated. Use `compute_time_seconds` instead. */
    cpu_used_sec: number;
    /** The Neon project ID. Use as the `project_id` path parameter in other endpoints. */
    id: string;
    /** The cloud platform identifier. Currently, only AWS is supported, for which the identifier is `aws`. */
    platform_id: string;
    /** Cloud region where the resource's Postgres compute and storage reside (for example, `aws-us-east-1`). Valid values are returned by `GET /regions`. */
    region_id: string;
    /** The project name */
    name: string;
    /** Compute provisioner. `k8s-neonvm` (default) supports Autoscaling; `k8s-pod` is fixed-size compute. Also `docker` and `serverless-platform`. */
    provisioner: string;
    default_endpoint_settings?: DefaultEndpointSettings;
    /** Project-level settings, for example `quota`, `allowed_ips`, `enable_logical_replication`, and `maintenance_window`. */
    settings?: ProjectSettingsData;
    pg_version: number;
    /** The proxy host for the project. This value combines the `region_id`, the `platform_id`, and the Neon domain (`neon.tech`). */
    proxy_host: string;
    /** The logical size limit for a branch. The value is in MiB. */
    branch_logical_size_limit: number;
    /** The logical size limit for a branch. The value is in B. */
    branch_logical_size_limit_bytes: number;
    /** Whether or not passwords are stored for roles in the Neon project. Storing passwords facilitates access to Neon features that require authorization. */
    store_passwords: boolean;
    /** A timestamp indicating when project maintenance begins. If set, the project is placed into maintenance mode at this time. */
    maintenance_starts_at?: string;
    /** The project creation source */
    creation_source: string;
    /** The number of seconds to retain the shared history for all branches in this project. */
    history_retention_seconds: number;
    /** A timestamp indicating when the project was created */
    created_at: string;
    /** A timestamp indicating when the project was last updated */
    updated_at: string;
    /** The current space occupied by the project in Postgres storage, in bytes. Synthetic Postgres storage size combines the logical data size and Write-Ahead Log (WAL) size for all branches in a project. */
    synthetic_storage_size?: number;
    /** A date-time indicating when Neon Cloud started measuring consumption for current consumption period. */
    consumption_period_start: string;
    /** A date-time indicating when Neon Cloud plans to stop measuring consumption for current consumption period. */
    consumption_period_end: string;
    /** Deprecated. Use the `consumption_period_end` field instead. A timestamp indicating when the project quota resets. */
    quota_reset_at?: string;
    /** ID of the organization that owns the project. */
    owner_id: string;
    /** Ownership details for the project, including the owner's name and email. */
    owner?: ProjectOwnerData;
    /** The most recent time when any endpoint of this project was active. Omitted when observed no activity for endpoints of this project. */
    compute_last_active_at?: string;
    /** The Neon organization ID. Returned as `id` from `GET /users/me/organizations`. */
    org_id?: string;
    /** A timestamp indicating when project update begins. If set, computes might experience a brief restart around this time. */
    maintenance_scheduled_for?: string;
    /** A timestamp indicating when HIPAA was enabled for this project */
    hipaa_enabled_at?: string;
    effective_project_permission?: ProjectPermissionLevel | null;
}
export declare const Project: S.Schema<Project>;
export interface ConnectionParameters {
    /** Name of the Postgres database used in the connection URI. */
    database: string;
    /** Authentication password for the role, used in the connection URI. */
    password: string | Redacted.Redacted<string>;
    /** Postgres role used to authenticate the database connection. */
    role: string;
    /** Hostname of the compute endpoint. Use `pooler_host` for the pooled connection hostname. */
    host: string;
    /** PgBouncer (transaction mode) pooled host, the `-pooler` variant of `host`. Connect through it to work around the Postgres `max_connections` limit for serverless or connection-per-request workloads. */
    pooler_host: string;
}
export declare const ConnectionParameters: S.Schema<ConnectionParameters>;
export interface ConnectionDetails {
    /** The connection URI is defined as specified here: [Connection URIs](https://www.postgresql.org/docs/current/libpq-connect.html#LIBPQ-CONNSTRING-URIS) The connection URI can be used to connect to a Postgres database with psql or defined in a DATABASE_URL environment variable. When creating a branch from a parent with more than one role or database, the response body does not include a connection URI. */
    connection_uri: string | Redacted.Redacted<string>;
    /** Individual components of the connection URI (host, port, database, role, and password) as discrete fields, for programmatic use rather than parsing the sibling `connection_uri` string. */
    connection_parameters: ConnectionParameters;
}
export declare const ConnectionDetails: S.Schema<ConnectionDetails>;
/** Connection URIs for the project. Each entry contains credentials and should be treated as sensitive. */
export type CreateProjectResponseConnectionUrisList = Array<ConnectionDetails>;
export declare const CreateProjectResponseConnectionUrisList: S.Schema<CreateProjectResponseConnectionUrisList>;
export interface Role {
    /** The ID of the branch this role belongs to. */
    branch_id: string;
    /** Postgres role name within the branch. */
    name: string;
    /** The role password */
    password?: string | Redacted.Redacted<string>;
    /** Whether or not the role is system-protected */
    protected?: boolean;
    /** Authentication method configured for this role: `password`, `oauth`, or `no_login`. */
    authentication_method?: string;
    /** A timestamp indicating when the role was created */
    created_at: string;
    /** A timestamp indicating when the role was last updated */
    updated_at: string;
}
export declare const Role: S.Schema<Role>;
/** Roles belonging to the branch. Each role includes fields such as `branch_id`, `name`, `protected`, `created_at`, and `updated_at`. */
export type CreateProjectResponseRolesList = Array<Role>;
export declare const CreateProjectResponseRolesList: S.Schema<CreateProjectResponseRolesList>;
export interface Database {
    /** The database ID */
    id: number;
    /** The ID of the branch this database belongs to. */
    branch_id: string;
    /** The database name */
    name: string;
    /** The name of role that owns the database */
    owner_name: string;
    /** A timestamp indicating when the database was created */
    created_at: string;
    /** A timestamp indicating when the database was last updated */
    updated_at: string;
}
export declare const Database: S.Schema<Database>;
/** Databases on the branch. Each includes `id`, `name`, `owner_name`, and `created_at`. */
export type CreateProjectResponseDatabasesList = Array<Database>;
export declare const CreateProjectResponseDatabasesList: S.Schema<CreateProjectResponseDatabasesList>;
export type CreateProjectResponseOperationsList = Array<Operation>;
export declare const CreateProjectResponseOperationsList: S.Schema<CreateProjectResponseOperationsList>;
/** The resolved user model that contains details of the user/org/integration/api_key used for branch creation. This field is filled only in listing/get/create/get/update/delete methods, if it is empty when calling other handlers, it does not mean that it is empty in the system. */
export interface BranchCreatedBy {
    /** Display name of the user who created the branch. */
    name?: string;
    /** The URL to the user's avatar image. */
    image?: string;
}
export declare const BranchCreatedBy: S.Schema<BranchCreatedBy>;
/** An action that is currently restricted for the branch and the reason why. */
export interface BranchRestrictedAction {
    /** The name of a restricted action on a branch. `restore`: the branch cannot be used as a restore target. `delete-rw-endpoint`: the read-write endpoint for the branch cannot be deleted. */
    name: string;
    /** A human-readable explanation of why the action is restricted. */
    reason: string;
}
export declare const BranchRestrictedAction: S.Schema<BranchRestrictedAction>;
/** A list of actions that are currently restricted for this branch and the reason why. */
export type BranchRestrictedActionsList = Array<BranchRestrictedAction>;
export declare const BranchRestrictedActionsList: S.Schema<BranchRestrictedActionsList>;
/** How the branch was deleted: 'user' for manual deletion, 'ttl' for TTL expiration */
export type BranchRecoveryInfoDeletionMethod = "user" | "ttl";
export declare const BranchRecoveryInfoDeletionMethod: any;
/** Recovery information for a deleted branch. Only present when listing deleted branches with `include_deleted=true`. This is part of the Branch Recovery feature, which is in preview and not available to all users. */
export interface BranchRecoveryInfo {
    /** Timestamp when the branch was deleted */
    deleted_at: string;
    /** Timestamp when the recovery window expires and the branch will be permanently deleted */
    recoverable_until: string;
    /** How the branch was deleted: 'user' for manual deletion, 'ttl' for TTL expiration */
    deletion_method: BranchRecoveryInfoDeletionMethod;
}
export declare const BranchRecoveryInfo: S.Schema<BranchRecoveryInfo>;
export interface Branch {
    /** The branch ID. This value is generated when a branch is created. A `branch_id` value has a `br` prefix. For example: `br-small-term-683261`. */
    id: string;
    /** The ID of the project this branch belongs to. */
    project_id: string;
    /** The `branch_id` of the parent branch */
    parent_id?: string;
    /** The Log Sequence Number (LSN) on the parent branch from which this branch was created. When restoring a branch using the `POST /projects/{project_id}/branches/{branch_id}/restore` endpoint, this value isn’t finalized until all operations related to the restore have completed successfully. */
    parent_lsn?: string;
    /** The point in time on the parent branch from which this branch was created. When restoring a branch using the `POST /projects/{project_id}/branches/{branch_id}/restore` endpoint, this value isn’t finalized until all operations related to the restore have completed successfully. After all the operations completed, this value might stay empty. */
    parent_timestamp?: string;
    /** The branch name */
    name: string;
    current_state: string;
    pending_state?: string;
    /** A UTC timestamp indicating when the `current_state` began */
    state_changed_at: string;
    /** The logical size of the branch, in bytes */
    logical_size?: number;
    /** The branch creation source */
    creation_source: string;
    /** Deprecated. Use the `default` field. Whether the branch is the project's primary branch. */
    primary?: boolean;
    /** Whether the branch is the project's default branch */
    default: boolean;
    /** Whether the branch is protected. Protected branches (and their computes) cannot be deleted, archived, or reset, and block deletion of the project. */
    protected: boolean;
    /** Deprecated. Use `compute_time_seconds` instead. CPU seconds used by all of the branch's compute endpoints, including deleted ones. This value is reset at the beginning of each billing period. */
    cpu_used_sec: number;
    /** Total Postgres compute time consumed by this branch during the current billing period, in CU-seconds (weighted by compute size). Divide by 3600 for CU-hours. */
    compute_time_seconds: number;
    /** Total time this branch's compute has been active during the current billing period, in seconds (not weighted by compute size). Distinct from `compute_time_seconds`, which is CU-weighted. */
    active_time_seconds: number;
    /** Data written by this branch during the current billing period, in bytes. */
    written_data_bytes: number;
    /** Total data transferred out of the branch, in bytes. Used as a consumption metric. */
    data_transfer_bytes: number;
    /** A timestamp indicating when the branch was created */
    created_at: string;
    /** A timestamp indicating when the branch was last updated */
    updated_at: string;
    /** The time-to-live (TTL) duration originally configured for the branch, in seconds. This read-only value represents the interval between the time `expires_at` was set and the expiration timestamp itself. It is preserved to ensure the same TTL duration is reapplied when resetting the branch from its parent, and only updates when a new `expires_at` value is set. Access to this feature is currently limited to participants in the Early Access Program. */
    ttl_interval_seconds?: number;
    /** The timestamp when the branch is scheduled to expire and be automatically deleted. Must be set by the client following the [RFC 3339, section 5.6](https://tools.ietf.org/html/rfc3339#section-5.6) format with precision up to seconds (such as 2025-06-09T18:02:16Z). Deletion is performed by a background job and may not occur exactly at the specified time. Access to this feature is currently limited to participants in the Early Access Program. */
    expires_at?: string;
    /** A timestamp indicating when the branch was last reset */
    last_reset_at?: string;
    /** The resolved user model that contains details of the user/org/integration/api_key used for branch creation. This field is filled only in listing/get/create/get/update/delete methods, if it is empty when calling other handlers, it does not mean that it is empty in the system. */
    created_by?: BranchCreatedBy;
    /** Source of initialization for the branch. `parent-data` (default) copies schema and data from the parent. `parent-schema` copies schema only from the parent. `schema-only` creates a root branch with schema only. `import` initializes from an external import. */
    init_source?: string;
    restore_status?: string;
    /** ID of the snapshot that was the restore source for this branch */
    restored_from?: string;
    /** ID of the target branch which was replaced when this branch was restored */
    restored_as?: string;
    /** A list of actions that are currently restricted for this branch and the reason why. */
    restricted_actions?: BranchRestrictedActionsList;
    recovery?: BranchRecoveryInfo;
}
export declare const Branch: S.Schema<Branch>;
/** Compute endpoint type. `read_write`: the primary read-write endpoint (one per branch). `read_only`: a read replica endpoint (multiple allowed per branch). */
export type EndpointType = "read_only" | "read_write";
export declare const EndpointType: any;
/** Lifecycle state of the compute endpoint. `init`: being initialized. `active`: running and accepting connections. `idle`: suspended (scaled to zero). */
export type EndpointState = "init" | "active" | "idle";
export declare const EndpointState: any;
/** A collection of settings for a compute endpoint */
export interface EndpointSettingsData {
    pg_settings?: PgSettingsData;
    /** Deprecated. PgBouncer settings for the compute endpoint. Removal scheduled for June 20, 2026. */
    pgbouncer_settings?: PgbouncerSettingsData;
    preload_libraries?: PreloadLibraries;
}
export declare const EndpointSettingsData: S.Schema<EndpointSettingsData>;
/** Deprecated. The connection pooler mode. Neon supports PgBouncer in `transaction` mode only. Removal scheduled for June 20, 2026. */
export type EndpointPoolerMode = "transaction";
export declare const EndpointPoolerMode: any;
export interface Endpoint {
    /** The hostname of the compute endpoint. This is the hostname specified when connecting to a Neon database. */
    host: string;
    /** The compute endpoint ID. Compute endpoint IDs have an `ep-` prefix. For example: `ep-little-smoke-851426` */
    id: string;
    /** Optional name of the compute endpoint */
    name?: string;
    /** The ID of the project this compute endpoint belongs to. */
    project_id: string;
    /** The ID of the branch this compute endpoint belongs to. */
    branch_id: string;
    /** The minimum number of Compute Units */
    autoscaling_limit_min_cu: number;
    /** The maximum number of Compute Units */
    autoscaling_limit_max_cu: number;
    /** Cloud region where the resource's Postgres compute and storage reside (for example, `aws-us-east-1`). Valid values are returned by `GET /regions`. */
    region_id: string;
    type: EndpointType;
    current_state: EndpointState;
    /** Target state the compute endpoint is transitioning to. Omitted when no transition is in progress. */
    pending_state?: EndpointState;
    settings: EndpointSettingsData;
    /** Deprecated. To use connection pooling, append `-pooler` to the endpoint ID in the connection string. */
    pooler_enabled: boolean;
    /** Deprecated. The connection pooler mode. Removal scheduled for June 20, 2026. */
    pooler_mode: EndpointPoolerMode;
    /** Whether to restrict connections to the compute endpoint. Enabling this option schedules a suspend compute operation. A disabled compute endpoint cannot be enabled by a connection or console action. */
    disabled: boolean;
    /** Whether to permit passwordless access to the compute endpoint */
    passwordless_access: boolean;
    /** A timestamp indicating when the compute endpoint was last active */
    last_active?: string;
    /** The compute endpoint creation source */
    creation_source: string;
    /** A timestamp indicating when the compute endpoint was created */
    created_at: string;
    /** A timestamp indicating when the compute endpoint was last updated */
    updated_at: string;
    /** A timestamp indicating when the compute endpoint was last started */
    started_at?: string;
    /** A timestamp indicating when the compute endpoint was last suspended */
    suspended_at?: string;
    /** Deprecated. Use the `host` property instead. */
    proxy_host: string;
    /** Scale-to-zero idle timeout, in seconds, before the compute suspends. `0` means the plan default applies; `-1` means scale-to-zero is disabled (never suspends). */
    suspend_timeout_seconds: number;
    /** Compute provisioner. `k8s-neonvm` (default) supports Autoscaling; `k8s-pod` is fixed-size compute. Also `docker` and `serverless-platform`. */
    provisioner: string;
    /** Attached compute's release version number. */
    compute_release_version?: string;
}
export declare const Endpoint: S.Schema<Endpoint>;
/** Compute endpoints in the project. Each includes `id`, `branch_id`, `host`, and `type`. */
export type CreateProjectResponseEndpointsList = Array<Endpoint>;
export declare const CreateProjectResponseEndpointsList: S.Schema<CreateProjectResponseEndpointsList>;
export interface CreateProjectResponse {
    /** Full details of the project, including configuration, consumption metrics, and ownership. */
    project: Project;
    /** Connection URIs for the project. Each entry contains credentials and should be treated as sensitive. */
    connection_uris: CreateProjectResponseConnectionUrisList;
    /** Roles belonging to the branch. Each role includes fields such as `branch_id`, `name`, `protected`, `created_at`, and `updated_at`. */
    roles: CreateProjectResponseRolesList;
    /** Databases on the branch. Each includes `id`, `name`, `owner_name`, and `created_at`. */
    databases: CreateProjectResponseDatabasesList;
    operations: CreateProjectResponseOperationsList;
    /** Branch returned by the request. */
    branch: Branch;
    /** Compute endpoints in the project. Each includes `id`, `branch_id`, `host`, and `type`. */
    endpoints: CreateProjectResponseEndpointsList;
}
export declare const CreateProjectResponse: S.Schema<CreateProjectResponse>;
export interface BranchCreateRequestEndpointOptions {
    type: EndpointType | (string & {});
    /** Compute endpoint settings: `pg_settings` (Postgres parameter overrides such as `work_mem`, `max_connections`) and `preload_libraries`. */
    settings?: EndpointSettingsData;
    /** Minimum number of Compute Units the endpoint can scale down to. Minimum 0.25. */
    autoscaling_limit_min_cu?: number;
    /** Maximum number of Compute Units the endpoint can scale up to. Minimum 0.25. */
    autoscaling_limit_max_cu?: number;
    /** Compute provisioner. `k8s-neonvm` (default) supports Autoscaling; `k8s-pod` is fixed-size compute. Also `docker` and `serverless-platform`. */
    provisioner?: string;
    /** Scale-to-zero idle timeout, in seconds, before the compute suspends. `0` uses the plan default; `-1` disables scale-to-zero (never suspends). Minimum is plan-dependent (Scale: 60); maximum 604800 (one week). Free cannot change it; Launch can only enable or disable; Scale can set any value. */
    suspend_timeout_seconds?: number;
}
export declare const BranchCreateRequestEndpointOptions: S.Schema<BranchCreateRequestEndpointOptions>;
/** Compute endpoints to create together with the branch. If omitted, the branch is created without any compute endpoint. Endpoints can be added to the branch separately after creation. */
export type CreateProjectBranchRequestEndpointsList = Array<BranchCreateRequestEndpointOptions>;
export declare const CreateProjectBranchRequestEndpointsList: S.Schema<CreateProjectBranchRequestEndpointsList>;
/** Optional configuration for the new branch, for example `name`, `parent_id` (fork from a branch), `parent_lsn` or `parent_timestamp` (point-in-time branching), and `protected`. */
export interface CreateProjectBranchRequestBranch {
    /** The `branch_id` of the parent branch. If omitted or empty, the branch will be created from the project's default branch. */
    parent_id?: string;
    /** The branch name */
    name?: string;
    /** A Log Sequence Number (LSN) on the parent branch. The branch will be created with data from this LSN. */
    parent_lsn?: string;
    /** A timestamp identifying a point in time on the parent branch. The branch will be created with data starting from this point in time. RFC 3339 format. */
    parent_timestamp?: string;
    /** Whether the branch is protected. Protected branches (and their computes) cannot be deleted, archived, or reset, and block deletion of the project. Can be gated by `protected_branches_only` in the IP allowlist. Paid plans only. */
    protected?: boolean;
    /** Whether to create the branch in the archived state. When omitted, the branch is created as a normal (non-archived) branch. */
    archived?: boolean;
    /** Source of initialization for the branch. `parent-data` copies schema and data from the parent branch. `parent-schema` copies schema only from the parent branch. `schema-only` creates a new root branch containing schema only, using `parent_id` as the source; optionally, `parent_lsn` or `parent_timestamp` can narrow the source point. `import` initializes the branch from an external import. */
    init_source?: string;
    /** The timestamp when the branch is scheduled to expire and be automatically deleted. Must be set by the client following the [RFC 3339, section 5.6](https://tools.ietf.org/html/rfc3339#section-5.6) format with precision up to seconds (such as 2025-06-09T18:02:16Z). Deletion is performed by a background job and may not occur exactly at the specified time. Access to this feature is currently limited to participants in the Early Access Program. */
    expires_at?: string;
}
export declare const CreateProjectBranchRequestBranch: S.Schema<CreateProjectBranchRequestBranch>;
export interface CreateProjectBranchRequest {
    /** The Neon project ID */
    project_id: string;
    /** Compute endpoints to create together with the branch. If omitted, the branch is created without any compute endpoint. Endpoints can be added to the branch separately after creation. */
    endpoints?: CreateProjectBranchRequestEndpointsList;
    /** Optional configuration for the new branch, for example `name`, `parent_id` (fork from a branch), `parent_lsn` or `parent_timestamp` (point-in-time branching), and `protected`. */
    branch?: CreateProjectBranchRequestBranch;
    annotation_value?: AnnotationValueData;
}
export declare const CreateProjectBranchRequest: S.Schema<CreateProjectBranchRequest>;
/** Compute endpoints in the project. Each includes `id`, `branch_id`, `host`, and `type`. */
export type CreateProjectBranchResponseEndpointsList = Array<Endpoint>;
export declare const CreateProjectBranchResponseEndpointsList: S.Schema<CreateProjectBranchResponseEndpointsList>;
export type CreateProjectBranchResponseOperationsList = Array<Operation>;
export declare const CreateProjectBranchResponseOperationsList: S.Schema<CreateProjectBranchResponseOperationsList>;
/** Roles belonging to the branch. Each role includes fields such as `branch_id`, `name`, `protected`, `created_at`, and `updated_at`. */
export type CreateProjectBranchResponseRolesList = Array<Role>;
export declare const CreateProjectBranchResponseRolesList: S.Schema<CreateProjectBranchResponseRolesList>;
/** Databases on the branch. Each includes `id`, `name`, `owner_name`, and `created_at`. */
export type CreateProjectBranchResponseDatabasesList = Array<Database>;
export declare const CreateProjectBranchResponseDatabasesList: S.Schema<CreateProjectBranchResponseDatabasesList>;
/** Connection URIs for the compute endpoint, including credentials. */
export type CreateProjectBranchResponseConnectionUrisList = Array<ConnectionDetails>;
export declare const CreateProjectBranchResponseConnectionUrisList: S.Schema<CreateProjectBranchResponseConnectionUrisList>;
export interface CreateProjectBranchResponse {
    /** Branch returned by the request. */
    branch: Branch;
    /** Compute endpoints in the project. Each includes `id`, `branch_id`, `host`, and `type`. */
    endpoints: CreateProjectBranchResponseEndpointsList;
    operations: CreateProjectBranchResponseOperationsList;
    /** Roles belonging to the branch. Each role includes fields such as `branch_id`, `name`, `protected`, `created_at`, and `updated_at`. */
    roles: CreateProjectBranchResponseRolesList;
    /** Databases on the branch. Each includes `id`, `name`, `owner_name`, and `created_at`. */
    databases: CreateProjectBranchResponseDatabasesList;
    /** Connection URIs for the compute endpoint, including credentials. */
    connection_uris?: CreateProjectBranchResponseConnectionUrisList;
}
export declare const CreateProjectBranchResponse: S.Schema<CreateProjectBranchResponse>;
/** Compute endpoints to create together with the branch. If omitted, the branch is created without any compute endpoint. Endpoints can be added to the branch separately after creation. */
export type BranchCreateRequestEndpointsList = Array<BranchCreateRequestEndpointOptions>;
export declare const BranchCreateRequestEndpointsList: S.Schema<BranchCreateRequestEndpointsList>;
/** Optional configuration for the new branch, for example `name`, `parent_id` (fork from a branch), `parent_lsn` or `parent_timestamp` (point-in-time branching), and `protected`. */
export type BranchCreateRequestBranch = CreateProjectBranchRequestBranch;
export declare const BranchCreateRequestBranch: S.Schema<CreateProjectBranchRequestBranch>;
export interface BranchCreateRequest {
    /** Compute endpoints to create together with the branch. If omitted, the branch is created without any compute endpoint. Endpoints can be added to the branch separately after creation. */
    endpoints?: BranchCreateRequestEndpointsList;
    /** Optional configuration for the new branch, for example `name`, `parent_id` (fork from a branch), `parent_lsn` or `parent_timestamp` (point-in-time branching), and `protected`. */
    branch?: CreateProjectBranchRequestBranch;
}
export declare const BranchCreateRequest: S.Schema<BranchCreateRequest>;
export interface MaskingRule {
    /** The name of the database containing the table to be masked */
    database_name: string;
    /** The name of the schema containing the table to be masked */
    schema_name: string;
    /** The name of the table containing the column to be masked */
    table_name: string;
    /** The name of the column to be masked */
    column_name: string;
    /** The PostgreSQL Anonymizer masking function to apply. Can be a predefined function (e.g., 'anon.random_string(10)', 'anon.fake_email()') or a custom function definition (e.g., 'anon.hash(column_name)') */
    masking_function?: string;
    /** A literal value to set on the column when masking. */
    masking_value?: string;
}
export declare const MaskingRule: S.Schema<MaskingRule>;
/** List of masking rules to apply to the branch. */
export type CreateProjectBranchAnonymizedRequestMaskingRulesList = Array<MaskingRule>;
export declare const CreateProjectBranchAnonymizedRequestMaskingRulesList: S.Schema<CreateProjectBranchAnonymizedRequestMaskingRulesList>;
export interface CreateProjectBranchAnonymizedRequest {
    /** The Neon project ID */
    project_id: string;
    annotation_value?: AnnotationValueData;
    branch_create?: BranchCreateRequest;
    /** List of masking rules to apply to the branch. */
    masking_rules?: CreateProjectBranchAnonymizedRequestMaskingRulesList;
    /** If true, automatically start anonymization after the branch is created. Defaults to false. */
    start_anonymization?: boolean;
}
export declare const CreateProjectBranchAnonymizedRequest: S.Schema<CreateProjectBranchAnonymizedRequest>;
/** Compute endpoints in the project. Each includes `id`, `branch_id`, `host`, and `type`. */
export type CreateProjectBranchAnonymizedResponseEndpointsList = Array<Endpoint>;
export declare const CreateProjectBranchAnonymizedResponseEndpointsList: S.Schema<CreateProjectBranchAnonymizedResponseEndpointsList>;
export type CreateProjectBranchAnonymizedResponseOperationsList = Array<Operation>;
export declare const CreateProjectBranchAnonymizedResponseOperationsList: S.Schema<CreateProjectBranchAnonymizedResponseOperationsList>;
/** Roles belonging to the branch. Each role includes fields such as `branch_id`, `name`, `protected`, `created_at`, and `updated_at`. */
export type CreateProjectBranchAnonymizedResponseRolesList = Array<Role>;
export declare const CreateProjectBranchAnonymizedResponseRolesList: S.Schema<CreateProjectBranchAnonymizedResponseRolesList>;
/** Databases on the branch. Each includes `id`, `name`, `owner_name`, and `created_at`. */
export type CreateProjectBranchAnonymizedResponseDatabasesList = Array<Database>;
export declare const CreateProjectBranchAnonymizedResponseDatabasesList: S.Schema<CreateProjectBranchAnonymizedResponseDatabasesList>;
/** Connection URIs for the compute endpoint, including credentials. */
export type CreateProjectBranchAnonymizedResponseConnectionUrisList = Array<ConnectionDetails>;
export declare const CreateProjectBranchAnonymizedResponseConnectionUrisList: S.Schema<CreateProjectBranchAnonymizedResponseConnectionUrisList>;
export interface CreateProjectBranchAnonymizedResponse {
    /** Branch returned by the request. */
    branch: Branch;
    /** Compute endpoints in the project. Each includes `id`, `branch_id`, `host`, and `type`. */
    endpoints: CreateProjectBranchAnonymizedResponseEndpointsList;
    operations: CreateProjectBranchAnonymizedResponseOperationsList;
    /** Roles belonging to the branch. Each role includes fields such as `branch_id`, `name`, `protected`, `created_at`, and `updated_at`. */
    roles: CreateProjectBranchAnonymizedResponseRolesList;
    /** Databases on the branch. Each includes `id`, `name`, `owner_name`, and `created_at`. */
    databases: CreateProjectBranchAnonymizedResponseDatabasesList;
    /** Connection URIs for the compute endpoint, including credentials. */
    connection_uris?: CreateProjectBranchAnonymizedResponseConnectionUrisList;
}
export declare const CreateProjectBranchAnonymizedResponse: S.Schema<CreateProjectBranchAnonymizedResponse>;
/** Access level for the bucket. Defaults to `private`. Set to `public_read` to allow anonymous `GetObject`/`HeadObject` on objects in this bucket. */
export type CreateProjectBranchBucketRequestAccessLevel = "private" | "public_read";
export declare const CreateProjectBranchBucketRequestAccessLevel: any;
export interface CreateProjectBranchBucketRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The bucket name. */
    name: string;
    /** Access level for the bucket. Defaults to `private`. Set to `public_read` to allow anonymous `GetObject`/`HeadObject` on objects in this bucket. */
    access_level?: CreateProjectBranchBucketRequestAccessLevel | (string & {});
}
export declare const CreateProjectBranchBucketRequest: S.Schema<CreateProjectBranchBucketRequest>;
/** Controls anonymous access to objects in the bucket. - `private`: all reads and writes require authenticated requests (default). - `public_read`: anonymous `GetObject`/`HeadObject` requests succeed; listing, writes, and deletes still require authenticated requests. */
export type BucketAccessLevel = "private" | "public_read";
export declare const BucketAccessLevel: any;
export interface Bucket {
    /** The bucket name (unique within a branch). */
    name: string;
    access_level: BucketAccessLevel;
    /** When the bucket was created. For a bucket inherited from an ancestor branch this is the ancestor's creation time (the branch fork never re-creates the bucket). */
    created_at: string;
}
export declare const Bucket: S.Schema<Bucket>;
export interface BucketResponse {
    bucket: Bucket;
}
export declare const BucketResponse: S.Schema<BucketResponse>;
/** Authentication provider for the Neon Data API. `neon_auth`: use Neon's built-in managed authentication (no JWKS configuration required). `external`: use an external JWT provider, which requires `jwks_url`. When omitted, no auth provider is configured (existing setup is kept). */
export type CreateProjectBranchDataAPIRequestAuthProvider = "neon_auth" | "external";
export declare const CreateProjectBranchDataAPIRequestAuthProvider: any;
/** List of schemas to expose via the API. Default: ["public"] */
export type DataAPISettingsDbSchemasList = Array<string>;
export declare const DataAPISettingsDbSchemasList: S.Schema<DataAPISettingsDbSchemasList>;
/** Configuration settings for the Neon Data API */
export interface DataAPISettings {
    /** Enable aggregates feature */
    db_aggregates_enabled?: boolean;
    /** Database role to use for anonymous requests */
    db_anon_role?: string;
    /** Extra schemas to add to the search path */
    db_extra_search_path?: string;
    /** Hard limit on the number of rows returned in a single Data API response. No limit when unset. */
    db_max_rows?: number;
    /** List of schemas to expose via the API. Default: ["public"] */
    db_schemas?: DataAPISettingsDbSchemasList;
    /** JWT claim key to use for role extraction */
    jwt_role_claim_key?: string;
    /** Maximum lifetime of the Data API's JWT cache, in seconds. */
    jwt_cache_max_lifetime?: number;
    /** OpenAPI specification mode (ignore-privileges, disabled) */
    openapi_mode?: string;
    /** CORS allowed origins */
    server_cors_allowed_origins?: string;
    /** When enabled, the Data API adds `Server-Timing` headers to each response showing database execution and internal processing time. Default: disabled. */
    server_timing_enabled?: boolean;
}
export declare const DataAPISettings: S.Schema<DataAPISettings>;
export interface CreateProjectBranchDataAPIRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The database name */
    database_name: string;
    /** Authentication provider for the Neon Data API. `neon_auth`: use Neon's built-in managed authentication (no JWKS configuration required). `external`: use an external JWT provider, which requires `jwks_url`. When omitted, no auth provider is configured (existing setup is kept). */
    auth_provider?: CreateProjectBranchDataAPIRequestAuthProvider | (string & {});
    /** URL of the JWKS endpoint used to verify JWTs for this Data API. Required when configuring JWT-based authentication; omit when using a non-JWT auth provider. */
    jwks_url?: string;
    /** Display name for the authentication provider. Accepted values include "Clerk", "Stytch", and "Auth0", but any non-empty string is valid. Optional field. */
    provider_name?: string;
    /** Expected `aud` claim in incoming JWTs. When set, tokens with a different audience are rejected; tokens with no audience are still accepted. Omit to skip audience validation. */
    jwt_audience?: string;
    /** Grant all permissions to the tables in the public schema to authenticated users */
    add_default_grants?: boolean;
    /** Skip creating the auth schema and RLS functions */
    skip_auth_schema?: boolean;
    /** Auth and schema configuration for the Data API. */
    settings?: DataAPISettings;
}
export declare const CreateProjectBranchDataAPIRequest: S.Schema<CreateProjectBranchDataAPIRequest>;
/** Neon Data API created successfully */
export interface DataAPICreateResponse {
    /** URL of the created Data API endpoint. */
    url: string;
}
export declare const DataAPICreateResponse: S.Schema<DataAPICreateResponse>;
/** Configuration for the new Postgres database. */
export interface CreateProjectBranchDatabaseRequestDatabase {
    /** Name of the database to create. */
    name: string;
    /** The name of the role that owns the database */
    owner_name: string;
}
export declare const CreateProjectBranchDatabaseRequestDatabase: S.Schema<CreateProjectBranchDatabaseRequestDatabase>;
export interface CreateProjectBranchDatabaseRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** Configuration for the new Postgres database. */
    database: CreateProjectBranchDatabaseRequestDatabase;
}
export declare const CreateProjectBranchDatabaseRequest: S.Schema<CreateProjectBranchDatabaseRequest>;
export type CreateProjectBranchDatabaseResponseOperationsList = Array<Operation>;
export declare const CreateProjectBranchDatabaseResponseOperationsList: S.Schema<CreateProjectBranchDatabaseResponseOperationsList>;
export interface CreateProjectBranchDatabaseResponse {
    /** Database object returned by the operation. */
    database: Database;
    operations: CreateProjectBranchDatabaseResponseOperationsList;
}
export declare const CreateProjectBranchDatabaseResponse: S.Schema<CreateProjectBranchDatabaseResponse>;
export type CreateProjectBranchFunctionDeploymentRequestRuntime = "nodejs24";
export declare const CreateProjectBranchFunctionDeploymentRequestRuntime: any;
export interface CreateProjectBranchFunctionDeploymentRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The function slug */
    slug: string;
    /** Optional ZIP archive of the function source code. Omit to reuse the latest version's bundle (a config-only change). Required for the first deployment of a function. */
    zip?: string;
    runtime?: CreateProjectBranchFunctionDeploymentRequestRuntime | (string & {});
    /** Optional JSON object (a string-to-string map) of environment variables for the deployment, e.g. {"KEY":"VALUE"}. Carried as a JSON-encoded string because multipart form data does not support typed object parts. Values are write-only: they are encrypted at rest, and responses carry only the variable names (the `environment` array), never the values. */
    environment?: string;
}
export declare const CreateProjectBranchFunctionDeploymentRequest: S.Schema<CreateProjectBranchFunctionDeploymentRequest>;
/** Build lifecycle status of the deployment. */
export type NeonFunctionDeploymentStatus = "pending" | "building" | "completed" | "failed";
export declare const NeonFunctionDeploymentStatus: any;
/** The NAMES of the deployment's environment variables, sorted. Values are encrypted at rest and are never returned — they are write-only. To change a value, deploy the variable with the new value; to remove a variable, deploy it with an empty value. */
export type NeonFunctionDeploymentEnvironmentList = Array<string>;
export declare const NeonFunctionDeploymentEnvironmentList: S.Schema<NeonFunctionDeploymentEnvironmentList>;
export interface NeonFunctionDeployment {
    /** The deployment id, which is the platform version number (monotonic per function). */
    id: number;
    /** Build lifecycle status of the deployment. */
    status: NeonFunctionDeploymentStatus;
    memory_mib: number;
    runtime: string;
    created_at: string;
    /** The NAMES of the deployment's environment variables, sorted. Values are encrypted at rest and are never returned — they are write-only. To change a value, deploy the variable with the new value; to remove a variable, deploy it with an empty value. */
    environment?: NeonFunctionDeploymentEnvironmentList;
    /** Human-readable reason the deployment build failed. Present only when `status` is `failed`. */
    error?: string;
}
export declare const NeonFunctionDeployment: S.Schema<NeonFunctionDeployment>;
export interface NeonFunctionDeploymentResponse {
    deployment: NeonFunctionDeployment;
}
export declare const NeonFunctionDeploymentResponse: S.Schema<NeonFunctionDeploymentResponse>;
/** Properties of the role to create. */
export interface CreateProjectBranchRoleRequestRole {
    /** The role name. Cannot exceed 63 bytes in length. */
    name: string;
    /** Whether to create a role that cannot login. */
    no_login?: boolean;
}
export declare const CreateProjectBranchRoleRequestRole: S.Schema<CreateProjectBranchRoleRequestRole>;
export interface CreateProjectBranchRoleRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** Properties of the role to create. */
    role: CreateProjectBranchRoleRequestRole;
}
export declare const CreateProjectBranchRoleRequest: S.Schema<CreateProjectBranchRoleRequest>;
export type CreateProjectBranchRoleResponseOperationsList = Array<Operation>;
export declare const CreateProjectBranchRoleResponseOperationsList: S.Schema<CreateProjectBranchRoleResponseOperationsList>;
export interface CreateProjectBranchRoleResponse {
    /** Role details for the requested database role. The `password` field is included in the response when a role is created or its password is reset, and is not returned in subsequent read requests. Store it securely at that time. */
    role: Role;
    operations: CreateProjectBranchRoleResponseOperationsList;
}
export declare const CreateProjectBranchRoleResponse: S.Schema<CreateProjectBranchRoleResponse>;
/** Configuration for the compute endpoint to create. */
export interface CreateProjectEndpointRequestEndpoint {
    /** The ID of the branch the compute endpoint will be associated with */
    branch_id: string;
    /** The region where the compute endpoint will be created. Only the project's `region_id` is permitted. */
    region_id?: string;
    type: EndpointType | (string & {});
    settings?: EndpointSettingsData;
    /** The minimum number of Compute Units. The minimum value is `0.25`. See [Compute size and Autoscaling configuration](https://neon.com/docs/manage/endpoints#compute-size-and-autoscaling-configuration) for more information. */
    autoscaling_limit_min_cu?: number;
    /** The maximum number of Compute Units. See [Compute size and Autoscaling configuration](https://neon.com/docs/manage/endpoints#compute-size-and-autoscaling-configuration) for more information. */
    autoscaling_limit_max_cu?: number;
    /** Compute provisioner. `k8s-neonvm` (default) supports Autoscaling; `k8s-pod` is fixed-size compute. Also `docker` and `serverless-platform`. */
    provisioner?: string;
    /** Deprecated. To enable connection pooling, append `-pooler` to the endpoint ID in the connection string. See [How to use connection pooling](https://neon.com/docs/connect/connection-pooling#how-to-use-connection-pooling) */
    pooler_enabled?: boolean;
    /** Deprecated. The connection pooler mode. Removal scheduled for June 20, 2026. */
    pooler_mode?: EndpointPoolerMode | (string & {});
    /** Whether to restrict connections to the compute endpoint. Enabling this option schedules a suspend compute operation. A disabled compute endpoint cannot be enabled by a connection or console action. However, the compute endpoint is periodically enabled by check_availability operations. */
    disabled?: boolean;
    /** NOT YET IMPLEMENTED. Whether to permit passwordless access to the compute endpoint. */
    passwordless_access?: boolean;
    /** Scale-to-zero idle timeout, in seconds, before the compute suspends. `0` uses the plan default; `-1` disables scale-to-zero (never suspends). Minimum is plan-dependent (Scale: 60); maximum 604800 (one week). Free cannot change it; Launch can only enable or disable; Scale can set any value. */
    suspend_timeout_seconds?: number;
    /** Optional name of the compute endpoint */
    name?: string;
}
export declare const CreateProjectEndpointRequestEndpoint: S.Schema<CreateProjectEndpointRequestEndpoint>;
export interface CreateProjectEndpointRequest {
    /** The Neon project ID */
    project_id: string;
    /** Configuration for the compute endpoint to create. */
    endpoint: CreateProjectEndpointRequestEndpoint;
}
export declare const CreateProjectEndpointRequest: S.Schema<CreateProjectEndpointRequest>;
export type CreateProjectEndpointResponseOperationsList = Array<Operation>;
export declare const CreateProjectEndpointResponseOperationsList: S.Schema<CreateProjectEndpointResponseOperationsList>;
export interface CreateProjectEndpointResponse {
    /** Compute endpoint created or retrieved, including its current lifecycle state. */
    endpoint: Endpoint;
    operations: CreateProjectEndpointResponseOperationsList;
}
export declare const CreateProjectEndpointResponse: S.Schema<CreateProjectEndpointResponse>;
export interface CreateProjectTransferRequestRequest {
    /** The Neon project ID */
    project_id: string;
    /** Number of seconds the transfer request stays valid before it expires. Defaults to 86400 (24 hours). */
    ttl_seconds?: number;
}
export declare const CreateProjectTransferRequestRequest: S.Schema<CreateProjectTransferRequestRequest>;
export interface ProjectTransferRequestResponse {
    /** The unique identifier for the transfer request */
    id: string;
    /** The ID of the project that is being transferred */
    project_id: string;
    /** The timestamp when the transfer request was created */
    created_at: string;
    /** The timestamp when the transfer request will expire */
    expires_at: string;
}
export declare const ProjectTransferRequestResponse: S.Schema<ProjectTransferRequestResponse>;
export interface CreateSnapshotRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** The target Log Sequence Number (LSN) to take the snapshot from. Must fall within the restore window. Cannot be used with `timestamp` */
    lsn?: string;
    /** The target timestamp for the snapshot. Must fall within the restore window. RFC 3339 format. Cannot be used with `lsn`. */
    timestamp?: string;
    /** A name for the snapshot. */
    name?: string;
    /** The time at which the snapshot will be automatically deleted. RFC 3339 format. */
    expires_at?: string;
}
export declare const CreateSnapshotRequest: S.Schema<CreateSnapshotRequest>;
export interface Snapshot {
    /** The snapshot ID. */
    id: string;
    /** Human-readable label for the snapshot. */
    name: string;
    /** WAL position (Log Sequence Number) at which the snapshot was captured, in Postgres LSN format (for example, `0/3000000`). */
    lsn?: string;
    /** Point in time captured by the snapshot, in RFC 3339 format (UTC). */
    timestamp?: string;
    /** Branch from which this snapshot was created. */
    source_branch_id?: string;
    /** Timestamp when the snapshot was created, in RFC 3339 format (UTC). */
    created_at: string;
    /** RFC 3339 timestamp when the snapshot expires and is eligible for deletion. Null if the snapshot does not have an expiry. */
    expires_at?: string;
    /** True if the snapshot was created manually rather than by a schedule. */
    manual?: boolean;
    /** Full logical size of the snapshot in bytes at the time it was taken. When absent, the logical size has not been calculated yet and the snapshot is not being charged. When present, a value of 0 means the snapshot is not being charged. */
    full_size?: number;
    /** Incremental Postgres storage size in bytes since the previous scheduled snapshot, when the snapshot is billed on incremental (diff) usage. When absent, either the incremental size has not been calculated yet and the snapshot is not being charged, or the snapshot is charged at full logical size (in that case `full_size` is set). */
    diff_size?: number;
}
export declare const Snapshot: S.Schema<Snapshot>;
export type CreateSnapshotResponseOperationsList = Array<Operation>;
export declare const CreateSnapshotResponseOperationsList: S.Schema<CreateSnapshotResponseOperationsList>;
export interface CreateSnapshotResponse {
    snapshot: Snapshot;
    operations: CreateSnapshotResponseOperationsList;
}
export declare const CreateSnapshotResponse: S.Schema<CreateSnapshotResponse>;
export type DeleteBranchNeonAuthOauthProviderRequestOauthProviderId = "google" | "github" | "microsoft" | "vercel";
export declare const DeleteBranchNeonAuthOauthProviderRequestOauthProviderId: any;
export interface DeleteBranchNeonAuthOauthProviderRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The OAuth provider ID */
    oauth_provider_id: DeleteBranchNeonAuthOauthProviderRequestOauthProviderId | (string & {});
}
export declare const DeleteBranchNeonAuthOauthProviderRequest: S.Schema<DeleteBranchNeonAuthOauthProviderRequest>;
export interface DeleteBranchNeonAuthOauthProviderResponse {
}
export declare const DeleteBranchNeonAuthOauthProviderResponse: S.Schema<DeleteBranchNeonAuthOauthProviderResponse>;
export interface NeonAuthDeleteDomainFromRedirectURIWhitelistItem {
    /** URI to remove from the redirect URI whitelist. */
    domain: string;
}
export declare const NeonAuthDeleteDomainFromRedirectURIWhitelistItem: S.Schema<NeonAuthDeleteDomainFromRedirectURIWhitelistItem>;
/** Domain names to remove from the redirect URI whitelist for the specified auth provider. */
export type DeleteBranchNeonAuthTrustedDomainRequestDomainsList = Array<NeonAuthDeleteDomainFromRedirectURIWhitelistItem>;
export declare const DeleteBranchNeonAuthTrustedDomainRequestDomainsList: S.Schema<DeleteBranchNeonAuthTrustedDomainRequestDomainsList>;
export interface DeleteBranchNeonAuthTrustedDomainRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    auth_provider: NeonAuthSupportedAuthProvider | (string & {});
    /** Domain names to remove from the redirect URI whitelist for the specified auth provider. */
    domains: DeleteBranchNeonAuthTrustedDomainRequestDomainsList;
}
export declare const DeleteBranchNeonAuthTrustedDomainRequest: S.Schema<DeleteBranchNeonAuthTrustedDomainRequest>;
export interface DeleteBranchNeonAuthTrustedDomainResponse {
}
export declare const DeleteBranchNeonAuthTrustedDomainResponse: S.Schema<DeleteBranchNeonAuthTrustedDomainResponse>;
export interface DeleteBranchNeonAuthUserRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The Neon user ID */
    auth_user_id: string;
}
export declare const DeleteBranchNeonAuthUserRequest: S.Schema<DeleteBranchNeonAuthUserRequest>;
export interface DeleteBranchNeonAuthUserResponse {
}
export declare const DeleteBranchNeonAuthUserResponse: S.Schema<DeleteBranchNeonAuthUserResponse>;
export interface DeleteOrganizationSpendingLimitRequest {
    /** The Neon organization ID */
    org_id: string;
}
export declare const DeleteOrganizationSpendingLimitRequest: S.Schema<DeleteOrganizationSpendingLimitRequest>;
export type DeleteOrganizationSpendingLimitResponse = unknown;
export declare const DeleteOrganizationSpendingLimitResponse: S.Schema<DeleteOrganizationSpendingLimitResponse>;
export interface DeleteOrganizationVPCEndpointRequest {
    /** The Neon organization ID */
    org_id: string;
    /** The Neon region ID. Azure regions are currently not supported. */
    region_id: string;
    /** The VPC endpoint ID */
    vpc_endpoint_id: string;
}
export declare const DeleteOrganizationVPCEndpointRequest: S.Schema<DeleteOrganizationVPCEndpointRequest>;
export interface DeleteOrganizationVPCEndpointResponse {
}
export declare const DeleteOrganizationVPCEndpointResponse: S.Schema<DeleteOrganizationVPCEndpointResponse>;
export interface DeleteProjectRequest {
    /** The Neon project ID */
    project_id: string;
}
export declare const DeleteProjectRequest: S.Schema<DeleteProjectRequest>;
export interface ProjectResponse {
    /** Full details of the project, including configuration, consumption metrics, and ownership. */
    project: Project;
}
export declare const ProjectResponse: S.Schema<ProjectResponse>;
export interface DeleteProjectBranchRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** If true, the branch is permanently deleted immediately without a recovery window. If false (default), the branch can be recovered within 7 days via the recover endpoint. This parameter is part of the Branch Recovery feature, which is in preview and not available to all users. */
    hard_delete?: boolean;
}
export declare const DeleteProjectBranchRequest: S.Schema<DeleteProjectBranchRequest>;
export type DeleteProjectBranchResponseOperationsList = Array<Operation>;
export declare const DeleteProjectBranchResponseOperationsList: S.Schema<DeleteProjectBranchResponseOperationsList>;
export interface DeleteProjectBranchResponse {
    /** Branch returned by the request. */
    branch: Branch;
    operations: DeleteProjectBranchResponseOperationsList;
}
export declare const DeleteProjectBranchResponse: S.Schema<DeleteProjectBranchResponse>;
export interface DeleteProjectBranchBucketRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The bucket name */
    bucket_name: string;
}
export declare const DeleteProjectBranchBucketRequest: S.Schema<DeleteProjectBranchBucketRequest>;
export interface DeleteProjectBranchBucketResponse {
}
export declare const DeleteProjectBranchBucketResponse: S.Schema<DeleteProjectBranchBucketResponse>;
export interface DeleteProjectBranchBucketObjectRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The bucket name */
    bucket_name: string;
    /** The object key. Keys may contain `/`; the `/` characters of nested keys must be percent-encoded (`%2F`) in the path segment. */
    object_key: string;
}
export declare const DeleteProjectBranchBucketObjectRequest: S.Schema<DeleteProjectBranchBucketObjectRequest>;
export interface DeleteProjectBranchBucketObjectResponse {
}
export declare const DeleteProjectBranchBucketObjectResponse: S.Schema<DeleteProjectBranchBucketObjectResponse>;
export interface DeleteProjectBranchBucketObjectsByPrefixRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The bucket name */
    bucket_name: string;
    /** The key prefix (folder) to delete. Must be non-empty and end with `/`. Every object on this branch whose key starts with this prefix is soft-deleted. */
    prefix: string;
}
export declare const DeleteProjectBranchBucketObjectsByPrefixRequest: S.Schema<DeleteProjectBranchBucketObjectsByPrefixRequest>;
export interface BucketObjectsDeletePrefixResponse {
    /** The number of objects soft-deleted under the prefix. 0 when no live object matched the prefix on this branch. */
    deleted: number;
}
export declare const BucketObjectsDeletePrefixResponse: S.Schema<BucketObjectsDeletePrefixResponse>;
export interface DeleteProjectBranchCustomDomainRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The registered custom domain (case-insensitive). */
    domain: string;
}
export declare const DeleteProjectBranchCustomDomainRequest: S.Schema<DeleteProjectBranchCustomDomainRequest>;
export interface DeleteProjectBranchCustomDomainResponse {
}
export declare const DeleteProjectBranchCustomDomainResponse: S.Schema<DeleteProjectBranchCustomDomainResponse>;
export interface DeleteProjectBranchDataAPIRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The database name */
    database_name: string;
}
export declare const DeleteProjectBranchDataAPIRequest: S.Schema<DeleteProjectBranchDataAPIRequest>;
export type DeleteProjectBranchDataAPIResponse = unknown;
export declare const DeleteProjectBranchDataAPIResponse: S.Schema<DeleteProjectBranchDataAPIResponse>;
export interface DeleteProjectBranchDatabaseRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** The database name */
    database_name: string;
}
export declare const DeleteProjectBranchDatabaseRequest: S.Schema<DeleteProjectBranchDatabaseRequest>;
export type DeleteProjectBranchDatabaseResponseOperationsList = Array<Operation>;
export declare const DeleteProjectBranchDatabaseResponseOperationsList: S.Schema<DeleteProjectBranchDatabaseResponseOperationsList>;
export interface DeleteProjectBranchDatabaseResponse {
    /** Database object returned by the operation. */
    database: Database;
    operations: DeleteProjectBranchDatabaseResponseOperationsList;
}
export declare const DeleteProjectBranchDatabaseResponse: S.Schema<DeleteProjectBranchDatabaseResponse>;
export interface DeleteProjectBranchFunctionRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The function slug */
    slug: string;
}
export declare const DeleteProjectBranchFunctionRequest: S.Schema<DeleteProjectBranchFunctionRequest>;
export interface DeleteProjectBranchFunctionResponse {
}
export declare const DeleteProjectBranchFunctionResponse: S.Schema<DeleteProjectBranchFunctionResponse>;
export interface DeleteProjectBranchRoleRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** The role name */
    role_name: string;
}
export declare const DeleteProjectBranchRoleRequest: S.Schema<DeleteProjectBranchRoleRequest>;
export type DeleteProjectBranchRoleResponseOperationsList = Array<Operation>;
export declare const DeleteProjectBranchRoleResponseOperationsList: S.Schema<DeleteProjectBranchRoleResponseOperationsList>;
export interface DeleteProjectBranchRoleResponse {
    /** Role details for the requested database role. The `password` field is included in the response when a role is created or its password is reset, and is not returned in subsequent read requests. Store it securely at that time. */
    role: Role;
    operations: DeleteProjectBranchRoleResponseOperationsList;
}
export declare const DeleteProjectBranchRoleResponse: S.Schema<DeleteProjectBranchRoleResponse>;
export interface DeleteProjectEndpointRequest {
    /** The Neon project ID */
    project_id: string;
    /** The endpoint ID */
    endpoint_id: string;
}
export declare const DeleteProjectEndpointRequest: S.Schema<DeleteProjectEndpointRequest>;
export type DeleteProjectEndpointResponseOperationsList = Array<Operation>;
export declare const DeleteProjectEndpointResponseOperationsList: S.Schema<DeleteProjectEndpointResponseOperationsList>;
export interface DeleteProjectEndpointResponse {
    /** Compute endpoint created or retrieved, including its current lifecycle state. */
    endpoint: Endpoint;
    operations: DeleteProjectEndpointResponseOperationsList;
}
export declare const DeleteProjectEndpointResponse: S.Schema<DeleteProjectEndpointResponse>;
export interface DeleteProjectJWKSRequest {
    /** The Neon project ID */
    project_id: string;
    /** The JWKS ID */
    jwks_id: string;
}
export declare const DeleteProjectJWKSRequest: S.Schema<DeleteProjectJWKSRequest>;
export interface DeleteProjectVPCEndpointRequest {
    /** The Neon project ID */
    project_id: string;
    /** The VPC endpoint ID */
    vpc_endpoint_id: string;
}
export declare const DeleteProjectVPCEndpointRequest: S.Schema<DeleteProjectVPCEndpointRequest>;
export interface DeleteProjectVPCEndpointResponse {
}
export declare const DeleteProjectVPCEndpointResponse: S.Schema<DeleteProjectVPCEndpointResponse>;
export interface DeleteSnapshotRequest {
    /** The Neon project ID */
    project_id: string;
    /** The snapshot ID */
    snapshot_id: string;
}
export declare const DeleteSnapshotRequest: S.Schema<DeleteSnapshotRequest>;
export interface DeleteSnapshotResponse {
}
export declare const DeleteSnapshotResponse: S.Schema<DeleteSnapshotResponse>;
export interface DisableNeonAuthRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** If true, deletes the `neon_auth` schema from the database */
    delete_data?: boolean;
}
export declare const DisableNeonAuthRequest: S.Schema<DisableNeonAuthRequest>;
export interface DisableNeonAuthResponse {
}
export declare const DisableNeonAuthResponse: S.Schema<DisableNeonAuthResponse>;
export interface FinalizeRestoreBranchRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** Name for the replaced branch. If omitted, a unique name is generated. */
    name?: string;
}
export declare const FinalizeRestoreBranchRequest: S.Schema<FinalizeRestoreBranchRequest>;
export type OperationsResponseOperationsList = Array<Operation>;
export declare const OperationsResponseOperationsList: S.Schema<OperationsResponseOperationsList>;
export interface OperationsResponse {
    operations: OperationsResponseOperationsList;
}
export declare const OperationsResponse: S.Schema<OperationsResponse>;
export interface GetActiveRegionsRequest {
    /** Organization ID. When provided, returns only regions available to this organization. Recommended for accurate region availability. */
    org_id?: string;
}
export declare const GetActiveRegionsRequest: S.Schema<GetActiveRegionsRequest>;
export interface RegionResponse {
    /** Cloud region where the resource's Postgres compute and storage reside (for example, `aws-us-east-1`). Valid values are returned by `GET /regions`. */
    region_id: string;
    /** A short description of the region. */
    name: string;
    /** True if this region is selected by default when no region is specified during project creation. */
    default: boolean;
    /** The geographical latitude (approximate) for the region. Empty if unknown. */
    geo_lat: string;
    /** The geographical longitude (approximate) for the region. Empty if unknown. */
    geo_long: string;
}
export declare const RegionResponse: S.Schema<RegionResponse>;
/** The list of active regions */
export type ActiveRegionsResponseRegionsList = Array<RegionResponse>;
export declare const ActiveRegionsResponseRegionsList: S.Schema<ActiveRegionsResponseRegionsList>;
export interface ActiveRegionsResponse {
    /** The list of active regions */
    regions: ActiveRegionsResponseRegionsList;
}
export declare const ActiveRegionsResponse: S.Schema<ActiveRegionsResponse>;
export interface GetAnonymizedBranchStatusRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
}
export declare const GetAnonymizedBranchStatusRequest: S.Schema<GetAnonymizedBranchStatusRequest>;
/** Metadata about the most recent anonymization attempt for the branch. */
export interface AnonymizationRunMetadata {
    /** Timestamp indicating when the latest anonymization attempt started. */
    started_at?: string;
    /** Timestamp indicating when the latest anonymization attempt completed. Populated even if the attempt failed. */
    completed_at?: string;
    /** UUID of the user who triggered the latest anonymization attempt. */
    triggered_by?: string;
    /** Username of the user who triggered the latest anonymization attempt. */
    triggered_by_username?: string;
    /** Number of columns that had masking rules applied during the attempt. */
    masked_columns?: number;
}
export declare const AnonymizationRunMetadata: S.Schema<AnonymizationRunMetadata>;
export interface AnonymizedBranchStatusResponse {
    /** The ID of the project this branch belongs to. */
    project_id: string;
    /** The ID of the anonymized branch. */
    branch_id: string;
    /** The current state of the anonymized branch. `created`: branch record exists but setup has not started. `initialized`: setup is complete and the branch is ready for anonymization. `initialization_error`: an error occurred during setup. `anonymizing`: the anonymization process is currently running. `anonymized`: anonymization completed successfully. `error`: an error occurred during anonymization. */
    state: string;
    /** A descriptive message about the current status or any errors */
    status_message?: string;
    /** A timestamp indicating when the anonymized branch was created */
    created_at: string;
    /** A timestamp indicating when the anonymized branch status was last updated */
    updated_at: string;
    /** A timestamp indicating when the anonymized branch operation failed (if applicable) */
    failed_at?: string;
    last_run?: AnonymizationRunMetadata;
}
export declare const AnonymizedBranchStatusResponse: S.Schema<AnonymizedBranchStatusResponse>;
export interface GetAuthDetailsRequest {
}
export declare const GetAuthDetailsRequest: S.Schema<GetAuthDetailsRequest>;
/** Authentication method used for the request: - `keycloak`: Keycloak identity provider authentication. - `session_cookie`: Browser session cookie authentication. - `api_key_user`: API key scoped to a user account. - `api_key_org`: API key scoped to an organization. - `oauth`: OAuth-based authentication. */
export type AuthDetailsResponseAuthMethod = "keycloak" | "session_cookie" | "api_key_user" | "api_key_org" | "oauth";
export declare const AuthDetailsResponseAuthMethod: any;
export interface AuthDetailsResponse {
    /** The ID of the account associated with this authentication record. */
    account_id: string;
    /** Authentication method used for the request: - `keycloak`: Keycloak identity provider authentication. - `session_cookie`: Browser session cookie authentication. - `api_key_user`: API key scoped to a user account. - `api_key_org`: API key scoped to an organization. - `oauth`: OAuth-based authentication. */
    auth_method: AuthDetailsResponseAuthMethod;
    auth_data?: string;
}
export declare const AuthDetailsResponse: S.Schema<AuthDetailsResponse>;
export interface GetAvailablePreloadLibrariesRequest {
    project_id: string;
}
export declare const GetAvailablePreloadLibrariesRequest: S.Schema<GetAvailablePreloadLibrariesRequest>;
export interface AvailablePreloadLibrary {
    /** Name of the Postgres shared preload library as it appears in the `shared_preload_libraries` parameter (for example, `pg_stat_statements`). */
    library_name: string;
    /** Human-readable explanation of the library's purpose and behavior. */
    description: string;
    /** Whether this library is loaded by default in the `shared_preload_libraries` configuration for new compute endpoints. */
    is_default: boolean;
    /** Marks the library as experimental. Experimental libraries may be unstable, subject to breaking changes, or not recommended for production use. */
    is_experimental: boolean;
    /** Version of the preload library. */
    version: string;
}
export declare const AvailablePreloadLibrary: S.Schema<AvailablePreloadLibrary>;
/** Preload libraries available for the project's Postgres version. Each entry includes `library_name`, `description`, `is_default`, `is_experimental`, and `version`. */
export type AvailablePreloadLibrariesLibrariesList = Array<AvailablePreloadLibrary>;
export declare const AvailablePreloadLibrariesLibrariesList: S.Schema<AvailablePreloadLibrariesLibrariesList>;
export interface AvailablePreloadLibraries {
    /** Preload libraries available for the project's Postgres version. Each entry includes `library_name`, `description`, `is_default`, `is_experimental`, and `version`. */
    libraries?: AvailablePreloadLibrariesLibrariesList;
}
export declare const AvailablePreloadLibraries: S.Schema<AvailablePreloadLibraries>;
export interface GetConnectionURIRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID. Defaults to your project's default `branch_id` if not specified. */
    branch_id?: string;
    /** The endpoint ID. Defaults to the read-write `endpoint_id` associated with the `branch_id` if not specified. */
    endpoint_id?: string;
    /** The database name */
    database_name: string;
    /** The role name */
    role_name: string;
    /** Adds the `-pooler` option to the connection URI when set to `true`, creating a pooled connection URI. */
    pooled?: boolean;
}
export declare const GetConnectionURIRequest: S.Schema<GetConnectionURIRequest>;
export interface ConnectionURIResponse {
    /** The connection URI. */
    uri: string;
}
export declare const ConnectionURIResponse: S.Schema<ConnectionURIResponse>;
export type GetConsumptionHistoryPerBranchV2RequestProjectIdsList = Array<string>;
export declare const GetConsumptionHistoryPerBranchV2RequestProjectIdsList: S.Schema<GetConsumptionHistoryPerBranchV2RequestProjectIdsList>;
export type GetConsumptionHistoryPerBranchV2RequestBranchIdsList = Array<string>;
export declare const GetConsumptionHistoryPerBranchV2RequestBranchIdsList: S.Schema<GetConsumptionHistoryPerBranchV2RequestBranchIdsList>;
export type ConsumptionHistoryGranularity = "hourly" | "daily" | "monthly";
export declare const ConsumptionHistoryGranularity: any;
export type ConsumptionHistoryQueryMetrics = Array<string>;
export declare const ConsumptionHistoryQueryMetrics: S.Schema<ConsumptionHistoryQueryMetrics>;
export interface GetConsumptionHistoryPerBranchV2Request {
    /** Cursor from the previous response (`pagination.cursor`). Pass it to fetch the next page of branches. Pages are ordered by project ID, then branch ID. */
    cursor?: string;
    /** Maximum number of branches per page. Allowed range: 1 to 1000. Default: 100. */
    limit?: number;
    /** Project IDs to include (required, 1 to 100). Returns metrics for branches in these projects. Pass multiple IDs as repeated query parameters or a comma-separated list: - `project_ids=cold-poetry-09157238&project_ids=quiet-snow-71788278` - `project_ids=cold-poetry-09157238,quiet-snow-71788278` */
    project_ids: GetConsumptionHistoryPerBranchV2RequestProjectIdsList;
    /** Optional branch IDs to filter the response (up to 100). If omitted, all branches in the listed projects are included. Pass multiple IDs as repeated query parameters or a comma-separated list: - `branch_ids=br-aged-salad-637688&branch_ids=br-sweet-breeze-497520` - `branch_ids=br-aged-salad-637688,br-sweet-breeze-497520` */
    branch_ids?: GetConsumptionHistoryPerBranchV2RequestBranchIdsList;
    /** Specify the start `date-time` for the consumption period. The `date-time` value is rounded according to the specified `granularity`. For example, `2024-03-15T15:30:00Z` for `daily` granularity will be rounded to `2024-03-15T00:00:00Z`. The specified `date-time` value must respect the specified `granularity`: - For `hourly`, consumption metrics are limited to the last 168 hours. - For `daily`, consumption metrics are limited to the last 60 days. - For `monthly`, consumption metrics are limited to the last year. Branch-level metrics are returned from when the account first ingests branch-level consumption data. Periods before that time contain no branch metrics. */
    from: string;
    /** Specify the end `date-time` for the consumption period. The `date-time` value is rounded according to the specified `granularity`. For example, `2024-03-15T15:30:00Z` for `daily` granularity will be rounded to `2024-03-15T00:00:00Z`. The specified `date-time` value must respect the specified `granularity`: - For `hourly`, consumption metrics are limited to the last 168 hours. - For `daily`, consumption metrics are limited to the last 60 days. - For `monthly`, consumption metrics are limited to the last year. */
    to: string;
    /** Specify the granularity of consumption metrics. Hourly, daily, and monthly metrics are available for the last 168 hours, 60 days, and 1 year, respectively. */
    granularity: ConsumptionHistoryGranularity | (string & {});
    /** Organization ID. Metrics are returned for projects in this organization. */
    org_id: string;
    /** Required. List the metrics to return. Only these values are supported: - `compute_unit_seconds` - `root_branch_bytes_month` - `child_branch_bytes_month` - `instant_restore_bytes_month` - `public_network_transfer_bytes` - `private_network_transfer_bytes` Not supported on this endpoint: `extra_branches_month`, `snapshot_storage_bytes_month`. Use `GET /consumption_history/v2/projects` for those. Pass multiple values as repeated query parameters or a comma-separated list: - `metrics=compute_unit_seconds&metrics=public_network_transfer_bytes` - `metrics=compute_unit_seconds,public_network_transfer_bytes` */
    metrics: ConsumptionHistoryQueryMetrics;
}
export declare const GetConsumptionHistoryPerBranchV2Request: S.Schema<GetConsumptionHistoryPerBranchV2Request>;
export interface ConsumptionMetricValue {
    /** Name of the consumption metric, such as compute_time or data_storage_bytes_hour. */
    metric_name: string;
    /** Measured quantity for the metric named by `metric_name`. */
    value: number;
}
export declare const ConsumptionMetricValue: S.Schema<ConsumptionMetricValue>;
/** Consumption metric values recorded for the timeframe. */
export type ConsumptionHistoryPerTimeframeV2MetricsList = Array<ConsumptionMetricValue>;
export declare const ConsumptionHistoryPerTimeframeV2MetricsList: S.Schema<ConsumptionHistoryPerTimeframeV2MetricsList>;
export interface ConsumptionHistoryPerTimeframeV2 {
    /** The specified start date-time for the reported consumption. */
    timeframe_start?: string;
    /** The specified end date-time for the reported consumption. */
    timeframe_end?: string;
    /** Consumption metric values recorded for the timeframe. */
    metrics?: ConsumptionHistoryPerTimeframeV2MetricsList;
}
export declare const ConsumptionHistoryPerTimeframeV2: S.Schema<ConsumptionHistoryPerTimeframeV2>;
/** Consumption metric records for the billing period. */
export type ConsumptionHistoryPerPeriodV2ConsumptionList = Array<ConsumptionHistoryPerTimeframeV2>;
export declare const ConsumptionHistoryPerPeriodV2ConsumptionList: S.Schema<ConsumptionHistoryPerPeriodV2ConsumptionList>;
export interface ConsumptionHistoryPerPeriodV2 {
    /** The ID assigned to the specified billing period. */
    period_id: string;
    /** The billing plan applicable during the billing period. */
    period_plan: string;
    /** The start date-time of the billing period. */
    period_start: string;
    /** The end date-time of the billing period, available for the past periods only. */
    period_end?: string;
    /** Consumption metric records for the billing period. */
    consumption: ConsumptionHistoryPerPeriodV2ConsumptionList;
}
export declare const ConsumptionHistoryPerPeriodV2: S.Schema<ConsumptionHistoryPerPeriodV2>;
/** Consumption history records for the branch, grouped by billing period. */
export type ConsumptionHistoryPerBranchV2PeriodsList = Array<ConsumptionHistoryPerPeriodV2>;
export declare const ConsumptionHistoryPerBranchV2PeriodsList: S.Schema<ConsumptionHistoryPerBranchV2PeriodsList>;
export interface ConsumptionHistoryPerBranchV2 {
    /** The ID of the project that owns this branch. */
    project_id: string;
    /** The Neon branch ID. Returned as `id` from `GET /projects/{project_id}/branches`. */
    branch_id: string;
    /** Consumption history records for the branch, grouped by billing period. */
    periods: ConsumptionHistoryPerBranchV2PeriodsList;
}
export declare const ConsumptionHistoryPerBranchV2: S.Schema<ConsumptionHistoryPerBranchV2>;
/** Per-branch consumption history records returned for the requested time range. */
export type GetConsumptionHistoryPerBranchV2ResponseBranchesList = Array<ConsumptionHistoryPerBranchV2>;
export declare const GetConsumptionHistoryPerBranchV2ResponseBranchesList: S.Schema<GetConsumptionHistoryPerBranchV2ResponseBranchesList>;
/** Cursor-based pagination. The `cursor` value reflects the endpoint's sort field (for example, an ID or timestamp), so pass it back unchanged. */
export interface Pagination {
    /** Cursor marking the last item in this response. Pass it unchanged as the `cursor` query parameter to fetch the next page. */
    cursor: string;
}
export declare const Pagination: S.Schema<Pagination>;
export interface GetConsumptionHistoryPerBranchV2Response {
    /** Per-branch consumption history records returned for the requested time range. */
    branches: GetConsumptionHistoryPerBranchV2ResponseBranchesList;
    pagination?: Pagination;
}
export declare const GetConsumptionHistoryPerBranchV2Response: S.Schema<GetConsumptionHistoryPerBranchV2Response>;
export type GetConsumptionHistoryPerProjectRequestProjectIdsList = Array<string>;
export declare const GetConsumptionHistoryPerProjectRequestProjectIdsList: S.Schema<GetConsumptionHistoryPerProjectRequestProjectIdsList>;
export interface GetConsumptionHistoryPerProjectRequest {
    /** Specify the cursor value from the previous response to get the next batch of projects. */
    cursor?: string;
    /** Specify a value from 1 to 100 to limit number of projects in the response. */
    limit?: number;
    /** Specify a list of project IDs to filter the response. If omitted, the response will contain all projects. A list of project IDs can be specified as an array of parameter values or as a comma-separated list in a single parameter value. - As an array of parameter values: `project_ids=cold-poetry-09157238%20&project_ids=quiet-snow-71788278` - As a comma-separated list in a single parameter value: `project_ids=cold-poetry-09157238,quiet-snow-71788278` */
    project_ids?: GetConsumptionHistoryPerProjectRequestProjectIdsList;
    /** Specify the start `date-time` for the consumption period. The `date-time` value is rounded according to the specified `granularity`. For example, `2024-03-15T15:30:00Z` for `daily` granularity will be rounded to `2024-03-15T00:00:00Z`. The specified `date-time` value must respect the specified `granularity`: - For `hourly`, consumption metrics are limited to the last 168 hours. - For `daily`, consumption metrics are limited to the last 60 days. - For `monthly`, consumption metrics are limited to the last year. The consumption history is available starting from `March 1, 2024, at 00:00:00 UTC`. */
    from: string;
    /** Specify the end `date-time` for the consumption period. The `date-time` value is rounded according to the specified granularity. For example, `2024-03-15T15:30:00Z` for `daily` granularity will be rounded to `2024-03-15T00:00:00Z`. The specified `date-time` value must respect the specified `granularity`: - For `hourly`, consumption metrics are limited to the last 168 hours. - For `daily`, consumption metrics are limited to the last 60 days. - For `monthly`, consumption metrics are limited to the last year. */
    to: string;
    /** Specify the granularity of consumption metrics. Hourly, daily, and monthly metrics are available for the last 168 hours, 60 days, and 1 year, respectively. */
    granularity: ConsumptionHistoryGranularity | (string & {});
    /** Specify the organization for which the project consumption metrics should be returned. If this parameter is not provided, the endpoint will return the metrics for the authenticated user's projects. */
    org_id?: string;
    /** The field is deprecated. Please use `metrics` instead. If `metrics` is specified, this field is ignored. Include metrics utilized in previous pricing models. - **data_storage_bytes_hour**: The sum of the maximum observed storage values for each hour, which never decreases. */
    include_v1_metrics?: boolean;
    /** Specify a list of metrics to include in the response. If omitted, active_time, compute_time, written_data, synthetic_storage_size are returned. Possible values: - `active_time_seconds` - `compute_time_seconds` - `written_data_bytes` - `synthetic_storage_size_bytes` - `data_storage_bytes_hour` - `logical_size_bytes` - `logical_size_bytes_hour` A list of metrics can be specified as an array of parameter values or as a comma-separated list in a single parameter value. - As an array of parameter values: `metrics=cpu_seconds&metrics=ram_bytes` - As a comma-separated list in a single parameter value: `metrics=cpu_seconds,ram_bytes` */
    metrics?: ConsumptionHistoryQueryMetrics;
}
export declare const GetConsumptionHistoryPerProjectRequest: S.Schema<GetConsumptionHistoryPerProjectRequest>;
export interface ConsumptionHistoryPerTimeframe {
    /** The specified start date-time for the reported consumption. */
    timeframe_start: string;
    /** The specified end date-time for the reported consumption. */
    timeframe_end: string;
    /** Seconds. The amount of time the compute endpoints have been active. */
    active_time_seconds: number;
    /** Seconds. The number of CPU seconds used by compute endpoints, including compute endpoints that have been deleted. */
    compute_time_seconds: number;
    /** Bytes. The amount of written data for all branches. */
    written_data_bytes: number;
    /** Bytes. The space occupied in Postgres storage. Synthetic Postgres storage size combines the logical data size and Write-Ahead Log (WAL) size for all branches. */
    synthetic_storage_size_bytes: number;
    /** Bytes-Hour. The amount of Postgres storage consumed hourly. */
    data_storage_bytes_hour?: number;
    /** Bytes. The amount of logical size consumed. */
    logical_size_bytes?: number;
    /** Bytes-Hour. The amount of logical size consumed hourly. */
    logical_size_bytes_hour?: number;
}
export declare const ConsumptionHistoryPerTimeframe: S.Schema<ConsumptionHistoryPerTimeframe>;
/** Consumption metric records for the billing period. */
export type ConsumptionHistoryPerPeriodConsumptionList = Array<ConsumptionHistoryPerTimeframe>;
export declare const ConsumptionHistoryPerPeriodConsumptionList: S.Schema<ConsumptionHistoryPerPeriodConsumptionList>;
export interface ConsumptionHistoryPerPeriod {
    /** The ID assigned to the specified billing period. */
    period_id: string;
    /** The billing plan applicable during the billing period. */
    period_plan: string;
    /** The start date-time of the billing period. */
    period_start: string;
    /** The end date-time of the billing period, available for the past periods only. */
    period_end?: string;
    /** Consumption metric records for the billing period. */
    consumption: ConsumptionHistoryPerPeriodConsumptionList;
}
export declare const ConsumptionHistoryPerPeriod: S.Schema<ConsumptionHistoryPerPeriod>;
/** Consumption periods for the project, each covering a discrete billing interval. */
export type ConsumptionHistoryPerProjectPeriodsList = Array<ConsumptionHistoryPerPeriod>;
export declare const ConsumptionHistoryPerProjectPeriodsList: S.Schema<ConsumptionHistoryPerProjectPeriodsList>;
export interface ConsumptionHistoryPerProject {
    /** The Neon project ID. Returned as `id` from `GET /projects`. */
    project_id: string;
    /** Consumption periods for the project, each covering a discrete billing interval. */
    periods: ConsumptionHistoryPerProjectPeriodsList;
}
export declare const ConsumptionHistoryPerProject: S.Schema<ConsumptionHistoryPerProject>;
/** Per-project consumption history records included in the response. */
export type GetConsumptionHistoryPerProjectResponseProjectsList = Array<ConsumptionHistoryPerProject>;
export declare const GetConsumptionHistoryPerProjectResponseProjectsList: S.Schema<GetConsumptionHistoryPerProjectResponseProjectsList>;
export interface GetConsumptionHistoryPerProjectResponse {
    /** Per-project consumption history records included in the response. */
    projects: GetConsumptionHistoryPerProjectResponseProjectsList;
    pagination?: Pagination;
}
export declare const GetConsumptionHistoryPerProjectResponse: S.Schema<GetConsumptionHistoryPerProjectResponse>;
export type GetConsumptionHistoryPerProjectV2RequestProjectIdsList = Array<string>;
export declare const GetConsumptionHistoryPerProjectV2RequestProjectIdsList: S.Schema<GetConsumptionHistoryPerProjectV2RequestProjectIdsList>;
export interface GetConsumptionHistoryPerProjectV2Request {
    /** Cursor from the previous response (`pagination.cursor`). Pass it to fetch the next page of projects. Pages are ordered by project creation order (newest first). */
    cursor?: string;
    /** Maximum number of projects per page. Allowed range: 1 to 100. Default: 10. */
    limit?: number;
    /** Optional project IDs to filter the response (up to 100). If omitted, projects in the organization are included across pages (use `cursor` and `limit`). Pass multiple IDs as repeated query parameters or a comma-separated list: - `project_ids=cold-poetry-09157238&project_ids=quiet-snow-71788278` - `project_ids=cold-poetry-09157238,quiet-snow-71788278` */
    project_ids?: GetConsumptionHistoryPerProjectV2RequestProjectIdsList;
    /** Specify the start `date-time` for the consumption period. The `date-time` value is rounded according to the specified `granularity`. For example, `2024-03-15T15:30:00Z` for `daily` granularity will be rounded to `2024-03-15T00:00:00Z`. The specified `date-time` value must respect the specified `granularity`: - For `hourly`, consumption metrics are limited to the last 168 hours. - For `daily`, consumption metrics are limited to the last 60 days. - For `monthly`, consumption metrics are limited to the last year. The earliest allowed `from` value is `March 1, 2024, at 00:00:00 UTC`. Metrics are returned from when the account upgraded to an eligible plan, which may be later than that date. */
    from: string;
    /** Specify the end `date-time` for the consumption period. The `date-time` value is rounded according to the specified `granularity`. For example, `2024-03-15T15:30:00Z` for `daily` granularity will be rounded to `2024-03-15T00:00:00Z`. The specified `date-time` value must respect the specified `granularity`: - For `hourly`, consumption metrics are limited to the last 168 hours. - For `daily`, consumption metrics are limited to the last 60 days. - For `monthly`, consumption metrics are limited to the last year. */
    to: string;
    /** Specify the granularity of consumption metrics. Hourly, daily, and monthly metrics are available for the last 168 hours, 60 days, and 1 year, respectively. */
    granularity: ConsumptionHistoryGranularity | (string & {});
    /** Organization ID. Metrics are returned for projects in this organization. */
    org_id: string;
    /** Required. List the metrics to return. Supported values: - `compute_unit_seconds` - `root_branch_bytes_month` - `child_branch_bytes_month` - `instant_restore_bytes_month` - `public_network_transfer_bytes` - `private_network_transfer_bytes` - `extra_branches_month` - `snapshot_storage_bytes_month` Pass multiple values as repeated query parameters or a comma-separated list: - `metrics=compute_unit_seconds&metrics=extra_branches_month` - `metrics=compute_unit_seconds,extra_branches_month` */
    metrics: ConsumptionHistoryQueryMetrics;
}
export declare const GetConsumptionHistoryPerProjectV2Request: S.Schema<GetConsumptionHistoryPerProjectV2Request>;
/** Consumption periods recorded for this project. */
export type ConsumptionHistoryPerProjectV2PeriodsList = Array<ConsumptionHistoryPerPeriodV2>;
export declare const ConsumptionHistoryPerProjectV2PeriodsList: S.Schema<ConsumptionHistoryPerProjectV2PeriodsList>;
export interface ConsumptionHistoryPerProjectV2 {
    /** The Neon project ID. Returned as `id` from `GET /projects`. */
    project_id: string;
    /** Consumption periods recorded for this project. */
    periods: ConsumptionHistoryPerProjectV2PeriodsList;
}
export declare const ConsumptionHistoryPerProjectV2: S.Schema<ConsumptionHistoryPerProjectV2>;
/** Per-project consumption history entries for the requested time range. */
export type GetConsumptionHistoryPerProjectV2ResponseProjectsList = Array<ConsumptionHistoryPerProjectV2>;
export declare const GetConsumptionHistoryPerProjectV2ResponseProjectsList: S.Schema<GetConsumptionHistoryPerProjectV2ResponseProjectsList>;
export interface GetConsumptionHistoryPerProjectV2Response {
    /** Per-project consumption history entries for the requested time range. */
    projects: GetConsumptionHistoryPerProjectV2ResponseProjectsList;
    pagination?: Pagination;
}
export declare const GetConsumptionHistoryPerProjectV2Response: S.Schema<GetConsumptionHistoryPerProjectV2Response>;
export interface GetCurrentUserInfoRequest {
}
export declare const GetCurrentUserInfoRequest: S.Schema<GetCurrentUserInfoRequest>;
/** State of the billing account. */
export type BillingAccountState = "UNKNOWN" | "active" | "suspended" | "deactivated" | "deleted";
export declare const BillingAccountState: any;
/** Card network reported by the payment processor. Set to `unknown` when the network cannot be determined. */
export type PaymentSourceBankCardBrand = "amex" | "diners" | "discover" | "jcb" | "mastercard" | "unionpay" | "unknown" | "visa";
export declare const PaymentSourceBankCardBrand: any;
export interface PaymentSourceBankCard {
    /** Last 4 digits of the card. */
    last4: string;
    /** Card network reported by the payment processor. Set to `unknown` when the network cannot be determined. */
    brand?: PaymentSourceBankCardBrand;
    /** Credit card expiration month */
    exp_month?: number;
    /** Credit card expiration year */
    exp_year?: number;
}
export declare const PaymentSourceBankCard: S.Schema<PaymentSourceBankCard>;
export interface PaymentSource {
    /** Type of payment source. E.g. "card". */
    type: string;
    /** Bank card details for this payment source. */
    card?: PaymentSourceBankCard;
}
export declare const PaymentSource: S.Schema<PaymentSource>;
/** Indicates whether and how an account makes payments. */
export type BillingPaymentMethod = "UNKNOWN" | "none" | "stripe" | "direct_payment" | "aws_mp" | "azure_mp" | "vercel_mp" | "staff" | "trial" | "sponsorship" | "shared_payment_token";
export declare const BillingPaymentMethod: any;
export interface PlanVersion {
    major: number;
    minor: number;
}
export declare const PlanVersion: S.Schema<PlanVersion>;
export interface PlanDetails {
    /** Plan name, for example `free`, `launch`, or `scale`. */
    name: string;
    /** Version of the plan, expressed as `major` and `minor` components. */
    version?: PlanVersion;
}
export declare const PlanDetails: S.Schema<PlanDetails>;
export interface BillingAccount {
    /** State of the billing account. `UNKNOWN`: state is not determined. `active`: the account is active and in normal operation. `suspended`: the account has been suspended. `deactivated`: the account has been deactivated. `deleted`: the account has been deleted. */
    state: BillingAccountState;
    /** Payment source attached to the billing account, such as a credit card on file. */
    payment_source: PaymentSource;
    subscription_type: BillingSubscriptionType;
    payment_method: BillingPaymentMethod;
    /** Timestamp of the last quota reset. Set to the account creation time when the account is first created. */
    quota_reset_at_last: string;
    /** The full name of the individual or entity that owns the billing account. This name appears on invoices. */
    name: string;
    /** Billing email, to receive emails related to invoices and subscriptions. */
    email: string;
    /** Billing address city. */
    address_city: string;
    /** Billing address country code defined by ISO 3166-1 alpha-2. */
    address_country: string;
    /** Billing address country name. */
    address_country_name?: string;
    /** Billing address line 1. */
    address_line1: string;
    /** Billing address line 2. */
    address_line2: string;
    /** Billing address postal code. */
    address_postal_code: string;
    /** Billing address state or region. */
    address_state: string;
    /** Orb user portal url */
    orb_portal_url?: string;
    /** The tax identification number for the billing account, displayed on invoices. */
    tax_id?: string;
    /** The type of the tax identification number based on the country. */
    tax_id_type?: string;
    /** Details of the subscription plan associated with the billing account. */
    plan_details?: PlanDetails;
    /** Monthly spending cap in cents for V3 paid plans. When set, notifications are sent at 80% and 100% of this limit. `null` means no limit is configured. */
    spending_limit_cents?: number | null;
}
export declare const BillingAccount: S.Schema<BillingAccount>;
/** Identity provider id from keycloak */
export type IdentityProviderId = "github" | "google" | "hasura" | "microsoft" | "microsoftv2" | "vercelmp" | "keycloak";
export declare const IdentityProviderId: any;
export interface CurrentUserAuthAccount {
    /** Email address associated with this auth account. */
    email: string;
    /** URL of the user's profile picture as provided by the identity provider. */
    image: string;
    /** Deprecated. Use the `email` field. */
    login: string;
    /** Display name of the account as provided by the identity provider. */
    name: string;
    provider: IdentityProviderId;
}
export declare const CurrentUserAuthAccount: S.Schema<CurrentUserAuthAccount>;
/** Authentication provider accounts linked to the current user. */
export type CurrentUserInfoResponseAuthAccountsList = Array<CurrentUserAuthAccount>;
export declare const CurrentUserInfoResponseAuthAccountsList: S.Schema<CurrentUserInfoResponseAuthAccountsList>;
export interface CurrentUserInfoResponse {
    /** Control plane observes active endpoints of a user this amount of wall-clock time. */
    active_seconds_limit: number;
    /** Billing account associated with the current user, including plan and subscription details. */
    billing_account?: BillingAccount;
    /** Authentication provider accounts linked to the current user. */
    auth_accounts: CurrentUserInfoResponseAuthAccountsList;
    /** Email address of the authenticated user. */
    email: string;
    /** The Neon user ID. */
    id: string;
    /** URL of the user's profile avatar image. */
    image: string;
    /** Deprecated. Use the `email` field. */
    login: string;
    /** First name of the current user. */
    name: string;
    /** Last name of the current user. */
    last_name: string;
    /** Maximum number of projects the account is allowed to create under the current plan. */
    projects_limit: number;
    /** Maximum number of branches allowed for the account under the current plan. */
    branches_limit: number;
    /** The maximum autoscaling limit in Compute Units. A value of 0 indicates no limit is configured. */
    max_autoscaling_limit: number;
    /** Maximum Postgres compute time, in seconds, allowed under the account's current plan. */
    compute_seconds_limit?: number;
    /** Current billing plan for the user's account. */
    plan: string;
}
export declare const CurrentUserInfoResponse: S.Schema<CurrentUserInfoResponse>;
export interface GetCurrentUserOrganizationsRequest {
}
export declare const GetCurrentUserOrganizationsRequest: S.Schema<GetCurrentUserOrganizationsRequest>;
export interface Organization {
    /** The Neon organization ID. Use as the `org_id` path parameter in other endpoints. */
    id: string;
    /** Human-readable display name of the organization. */
    name: string;
    /** URL-safe identifier for the organization, used in API paths. Distinct from the display name. */
    handle: string;
    /** Billing plan for the organization, for example `free`, `launch`, or `scale`. */
    plan: string;
    /** A timestamp indicting when the organization was created */
    created_at: string;
    /** Organizations created via the Console or the API are managed by `console`. Organizations created by other methods can't be deleted via the Console or the API. */
    managed_by: string;
    /** A timestamp indicating when the organization was updated */
    updated_at: string;
    /** If true, allow account to mark projects as HIPAA */
    allow_hipaa_projects?: boolean;
    /** If true, all members must have MFA enabled to access this organization */
    require_mfa?: boolean;
}
export declare const Organization: S.Schema<Organization>;
/** Organizations returned by the request. Each includes `id`, `name`, `handle`, and `plan`. */
export type OrganizationsResponseOrganizationsList = Array<Organization>;
export declare const OrganizationsResponseOrganizationsList: S.Schema<OrganizationsResponseOrganizationsList>;
export interface OrganizationsResponse {
    /** Organizations returned by the request. Each includes `id`, `name`, `handle`, and `plan`. */
    organizations: OrganizationsResponseOrganizationsList;
}
export declare const OrganizationsResponse: S.Schema<OrganizationsResponse>;
export interface GetMaskingRulesRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
}
export declare const GetMaskingRulesRequest: S.Schema<GetMaskingRulesRequest>;
/** List of masking rules for the branch */
export type MaskingRulesResponseMaskingRulesList = Array<MaskingRule>;
export declare const MaskingRulesResponseMaskingRulesList: S.Schema<MaskingRulesResponseMaskingRulesList>;
export interface MaskingRulesResponse {
    /** List of masking rules for the branch */
    masking_rules: MaskingRulesResponseMaskingRulesList;
}
export declare const MaskingRulesResponse: S.Schema<MaskingRulesResponse>;
export interface GetNeonAuthRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const GetNeonAuthRequest: S.Schema<GetNeonAuthRequest>;
export type NeonAuthProviderProjectOwnedBy = "user" | "neon";
export declare const NeonAuthProviderProjectOwnedBy: any;
export type NeonAuthProviderProjectTransferStatus = "initiated" | "finished";
export declare const NeonAuthProviderProjectTransferStatus: any;
export interface NeonAuthIntegration {
    auth_provider: NeonAuthSupportedAuthProvider;
    /** Project identifier assigned by the auth provider for this integration. */
    auth_provider_project_id: string;
    /** The Neon branch ID. Returned as `id` from `GET /projects/{project_id}/branches`. */
    branch_id: string;
    /** Name of the database used by the Neon Auth integration. */
    db_name: string;
    /** Timestamp when the Neon Auth integration was created, in RFC 3339 format (UTC). */
    created_at: string;
    /** Owner of the auth provider project. `neon` means the project is created and managed by Neon on your behalf. `user` means the project was created in your own auth provider account and is self-managed. */
    owned_by: NeonAuthProviderProjectOwnedBy;
    /** Ownership transfer state for the auth provider project. `initiated` means a transfer was requested but not completed. `finished` means it completed successfully. */
    transfer_status?: NeonAuthProviderProjectTransferStatus;
    /** URL of the provider's JWKS endpoint used to verify JWTs. */
    jwks_url: string;
    /** Base URL of the Neon Auth service endpoint for this integration. Injected into the project environment as `NEON_AUTH_BASE_URL`. */
    base_url?: string;
    /** Application name shown in auth emails and communications. Defaults to the project name. */
    name?: string;
}
export declare const NeonAuthIntegration: S.Schema<NeonAuthIntegration>;
export interface GetNeonAuthAllowLocalhostRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const GetNeonAuthAllowLocalhostRequest: S.Schema<GetNeonAuthAllowLocalhostRequest>;
export interface NeonAuthAllowLocalhostResponse {
    /** Whether to allow localhost connections */
    allow_localhost: boolean;
}
export declare const NeonAuthAllowLocalhostResponse: S.Schema<NeonAuthAllowLocalhostResponse>;
export interface GetNeonAuthEmailAndPasswordConfigRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const GetNeonAuthEmailAndPasswordConfigRequest: S.Schema<GetNeonAuthEmailAndPasswordConfigRequest>;
/** The email verification method to use. - `link`: Sends a verification link via email - `otp`: Sends a one-time password (OTP) via email */
export type NeonAuthEmailVerificationMethod = "link" | "otp";
export declare const NeonAuthEmailVerificationMethod: any;
export interface NeonAuthEmailAndPasswordConfig {
    /** Whether email and password authentication is enabled */
    enabled: boolean;
    /** Controls how email addresses are verified during sign-up or sign-in. - `link`: sends a verification link to the user's email address - `otp`: sends a one-time password to the user's email address */
    email_verification_method: NeonAuthEmailVerificationMethod;
    /** Whether email verification is required before users can sign in */
    require_email_verification: boolean;
    /** Whether users are automatically signed in after verifying their email */
    auto_sign_in_after_verification: boolean;
    /** Whether to send a verification email when users sign up */
    send_verification_email_on_sign_up: boolean;
    /** Whether to send a verification email when users sign in */
    send_verification_email_on_sign_in: boolean;
    /** Whether to disable new user sign ups */
    disable_sign_up: boolean;
}
export declare const NeonAuthEmailAndPasswordConfig: S.Schema<NeonAuthEmailAndPasswordConfig>;
export interface GetNeonAuthEmailProviderRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const GetNeonAuthEmailProviderRequest: S.Schema<GetNeonAuthEmailProviderRequest>;
export interface StandardEmailServerResponse {
    /** Hostname of the email server. */
    host: string;
    /** TCP port of the SMTP server. Common values: 25 (SMTP), 465 (SMTPS), 587 (submission). */
    port: number;
    /** Username for authenticating with the SMTP server. */
    username: string;
    /** On GET, returned redacted (empty) for ordinary callers, while callers with project-credential read permission receive the stored password — do not assume this field is empty. Update (PATCH) responses always return it redacted (empty) regardless of permission. Provide a value on update to set or rotate the password. */
    password: string | Redacted.Redacted<string>;
    /** Email address used as the From address on outgoing auth emails. */
    sender_email: string;
    /** Display name shown as the sender in outgoing emails. */
    sender_name: string;
}
export declare const StandardEmailServerResponse: S.Schema<StandardEmailServerResponse>;
export interface SharedEmailServer {
    /** Email address used as the sender for outgoing messages from this shared email server. */
    sender_email?: string;
    /** Display name shown as the sender in outgoing emails. */
    sender_name?: string;
}
export declare const SharedEmailServer: S.Schema<SharedEmailServer>;
export type NeonAuthEmailServerConfigResponse = StandardEmailServerResponse | SharedEmailServer;
export declare const NeonAuthEmailServerConfigResponse: S.Schema<NeonAuthEmailServerConfigResponse>;
export type GetNeonAuthEmailProviderResponse = NeonAuthEmailServerConfigResponse;
export declare const GetNeonAuthEmailProviderResponse: S.Schema<GetNeonAuthEmailProviderResponse>;
export interface GetNeonAuthPhoneNumberPluginRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const GetNeonAuthPhoneNumberPluginRequest: S.Schema<GetNeonAuthPhoneNumberPluginRequest>;
export interface NeonAuthPhoneNumberConfig {
    /** Whether the phone number plugin is enabled. */
    enabled: boolean;
    /** Time in seconds before the OTP expires */
    otp_expires_in?: number;
}
export declare const NeonAuthPhoneNumberConfig: S.Schema<NeonAuthPhoneNumberConfig>;
export interface GetNeonAuthPluginConfigsRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const GetNeonAuthPluginConfigsRequest: S.Schema<GetNeonAuthPluginConfigsRequest>;
/** Role of the organization's creator. `owner`: full control, including deleting the org and transferring ownership. `admin`: manage members and settings only. */
export type NeonAuthOrganizationConfigCreatorRole = "admin" | "owner";
export declare const NeonAuthOrganizationConfigCreatorRole: any;
export interface NeonAuthOrganizationConfig {
    /** Whether the organization plugin is enabled. */
    enabled: boolean;
    /** Maximum organizations a user can belong to (created or joined). At the limit, the user cannot create or join more. */
    organization_limit: number;
    /** Maximum number of members per organization. */
    membership_limit: number;
    /** Role of the organization's creator. `owner`: full control, including deleting the org and transferring ownership. `admin`: manage members and settings only. */
    creator_role: NeonAuthOrganizationConfigCreatorRole;
    /** Whether to send invitation emails when inviting members to an organization. */
    send_invitation_email: boolean;
}
export declare const NeonAuthOrganizationConfig: S.Schema<NeonAuthOrganizationConfig>;
export interface NeonAuthMagicLinkConfig {
    /** Whether the magic link plugin is enabled. */
    enabled: boolean;
    /** Minutes until the magic link expires. */
    expires_in: number;
    /** Whether to disable sign-up via magic link. */
    disable_sign_up: boolean;
}
export declare const NeonAuthMagicLinkConfig: S.Schema<NeonAuthMagicLinkConfig>;
/** OAuth provider configurations enabled for this auth setup. */
export type NeonAuthPluginConfigsOauthProvidersList = Array<NeonAuthOauthProvider>;
export declare const NeonAuthPluginConfigsOauthProvidersList: S.Schema<NeonAuthPluginConfigsOauthProvidersList>;
/** Aggregated plugin configurations for Neon Auth */
export interface NeonAuthPluginConfigs {
    /** Configuration for the Neon Auth organization plugin, which enables user organizations within the authentication system. This is distinct from a Neon platform organization. */
    organization?: NeonAuthOrganizationConfig;
    /** Configuration for passwordless magic-link email authentication. */
    magic_link?: NeonAuthMagicLinkConfig;
    /** Configuration for the phone number authentication plugin. */
    phone_number?: NeonAuthPhoneNumberConfig;
    /** Email server configuration used to send authentication emails. */
    email_provider?: NeonAuthEmailServerConfigResponse;
    /** Configuration for email and password authentication. */
    email_and_password?: NeonAuthEmailAndPasswordConfig;
    /** OAuth provider configurations enabled for this auth setup. */
    oauth_providers?: NeonAuthPluginConfigsOauthProvidersList;
    /** Permits authentication requests from localhost origins when true. Intended for local development; disable in production environments. */
    allow_localhost?: boolean;
}
export declare const NeonAuthPluginConfigs: S.Schema<NeonAuthPluginConfigs>;
export interface GetNeonAuthWebhookConfigRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const GetNeonAuthWebhookConfigRequest: S.Schema<GetNeonAuthWebhookConfigRequest>;
export type NeonAuthWebhookConfigEnabledEventsItem = "user.before_create" | "user.created" | "send.otp" | "send.magic_link" | "organization.invitation.created" | "organization.invitation.accepted" | "phone_number.verified";
export declare const NeonAuthWebhookConfigEnabledEventsItem: any;
/** Event types that trigger this webhook. Covers user lifecycle, email/OTP delivery, organization invitations, and phone verification events; see the enum for exact values. */
export type NeonAuthWebhookConfigEnabledEventsList = Array<NeonAuthWebhookConfigEnabledEventsItem>;
export declare const NeonAuthWebhookConfigEnabledEventsList: S.Schema<NeonAuthWebhookConfigEnabledEventsList>;
export interface NeonAuthWebhookConfig {
    /** Whether the webhook is active. */
    enabled: boolean;
    /** Destination URL that receives webhook event payloads. */
    webhook_url?: string;
    /** Event types that trigger this webhook. Covers user lifecycle, email/OTP delivery, organization invitations, and phone verification events; see the enum for exact values. */
    enabled_events?: NeonAuthWebhookConfigEnabledEventsList;
    /** Maximum time, in seconds, to wait for a response from the webhook endpoint. */
    timeout_seconds?: number;
}
export declare const NeonAuthWebhookConfig: S.Schema<NeonAuthWebhookConfig>;
export interface GetOrganizationRequest {
    /** The Neon organization ID */
    org_id: string;
}
export declare const GetOrganizationRequest: S.Schema<GetOrganizationRequest>;
export interface GetOrganizationInvitationsRequest {
    /** The Neon organization ID */
    org_id: string;
}
export declare const GetOrganizationInvitationsRequest: S.Schema<GetOrganizationInvitationsRequest>;
export interface GetOrganizationMemberRequest {
    /** The Neon organization ID */
    org_id: string;
    /** The Neon organization member ID */
    member_id: string;
}
export declare const GetOrganizationMemberRequest: S.Schema<GetOrganizationMemberRequest>;
export interface Member {
    /** The organization member's ID. */
    id: string;
    /** The Neon user ID. */
    user_id: string;
    /** The Neon organization ID. Returned as `id` from `GET /users/me/organizations`. */
    org_id: string;
    role: MemberRole;
    /** Timestamp when the user joined the organization. */
    joined_at?: string;
}
export declare const Member: S.Schema<Member>;
export type GetOrganizationMembersRequestSortBy = "email" | "role" | "joined_at";
export declare const GetOrganizationMembersRequestSortBy: any;
export type GetOrganizationMembersRequestSortOrder = "asc" | "desc";
export declare const GetOrganizationMembersRequestSortOrder: any;
export interface GetOrganizationMembersRequest {
    /** The Neon organization ID */
    org_id: string;
    /** Sort the members by the specified field. Defaults to `joined_at`. */
    sort_by?: GetOrganizationMembersRequestSortBy | (string & {});
    /** A cursor to use in pagination. A cursor defines your place in the data list. Include `response.pagination.next` in subsequent API calls to fetch next page of the list. */
    cursor?: string;
    /** Defines the sorting order of entities. */
    sort_order?: GetOrganizationMembersRequestSortOrder | (string & {});
    /** The maximum number of members to return in the response */
    limit?: number;
}
export declare const GetOrganizationMembersRequest: S.Schema<GetOrganizationMembersRequest>;
export interface MemberUserInfo {
    /** Email address of the organization member's user account. */
    email: string;
    /** Whether the member has MFA (TOTP) enabled */
    has_mfa?: boolean;
    /** Timestamp of when the user account was deactivated. Absent for active users. When present, the UI should render a "Deactivated" badge inline next to the member. */
    deactivated_at?: string;
}
export declare const MemberUserInfo: S.Schema<MemberUserInfo>;
export interface MemberWithUser {
    /** Membership record for the user in the organization. */
    member: Member;
    /** Profile information for the organization member. */
    user: MemberUserInfo;
}
export declare const MemberWithUser: S.Schema<MemberWithUser>;
/** Members of the organization, each combining membership details (role, status) with the associated user's identity. */
export type GetOrganizationMembersResponseMembersList = Array<MemberWithUser>;
export declare const GetOrganizationMembersResponseMembersList: S.Schema<GetOrganizationMembersResponseMembersList>;
/** To paginate the response, issue an initial request with `limit` value. Then, add the value returned in the response `.pagination.next` attribute into the request under the `cursor` query parameter to the subsequent request to retrieve next page in pagination. The contents on cursor `next` are opaque, clients are not expected to make any assumptions on the format of the data inside the cursor. */
export interface CursorPagination {
    /** Cursor for the next page of results. Pass it as the `cursor` query parameter on the next request. Absent on the last page. */
    next?: string;
    /** Field by which the results were sorted, echoing the request's sort_by parameter. */
    sort_by?: string;
    /** Sort order active for this page. Pass back as `sort_order` in the next request to maintain consistent ordering. Valid values are `asc` and `desc`. */
    sort_order?: string;
}
export declare const CursorPagination: S.Schema<CursorPagination>;
export interface GetOrganizationMembersResponse {
    /** Members of the organization, each combining membership details (role, status) with the associated user's identity. */
    members: GetOrganizationMembersResponseMembersList;
    pagination?: CursorPagination;
}
export declare const GetOrganizationMembersResponse: S.Schema<GetOrganizationMembersResponse>;
export interface GetOrganizationSpendingLimitRequest {
    /** The Neon organization ID */
    org_id: string;
}
export declare const GetOrganizationSpendingLimitRequest: S.Schema<GetOrganizationSpendingLimitRequest>;
export interface SpendingLimitResponse {
    /** Monthly spending cap in cents. `null` indicates that no limit is currently configured. */
    spending_limit_cents: number | null;
}
export declare const SpendingLimitResponse: S.Schema<SpendingLimitResponse>;
export interface GetOrganizationVPCEndpointDetailsRequest {
    /** The Neon organization ID */
    org_id: string;
    /** The Neon region ID. Azure regions are currently not supported. */
    region_id: string;
    /** The VPC endpoint ID */
    vpc_endpoint_id: string;
}
export declare const GetOrganizationVPCEndpointDetailsRequest: S.Schema<GetOrganizationVPCEndpointDetailsRequest>;
/** A list of example projects that are restricted to use this VPC endpoint. There are at most 3 projects in the list, even if more projects are restricted. */
export type VPCEndpointDetailsExampleRestrictedProjectsList = Array<string>;
export declare const VPCEndpointDetailsExampleRestrictedProjectsList: S.Schema<VPCEndpointDetailsExampleRestrictedProjectsList>;
export interface VPCEndpointDetails {
    /** Cloud provider identifier for the VPC endpoint. */
    vpc_endpoint_id: string;
    /** A descriptive label for the VPC endpoint */
    label: string;
    /** The current state of the VPC endpoint. `new` means the endpoint has just been configured and is pending acceptance by Neon. `accepted` means the VPC connection has been accepted by Neon. */
    state: string;
    /** The number of projects that are restricted to use this VPC endpoint. */
    num_restricted_projects: number;
    /** A list of example projects that are restricted to use this VPC endpoint. There are at most 3 projects in the list, even if more projects are restricted. */
    example_restricted_projects: VPCEndpointDetailsExampleRestrictedProjectsList;
}
export declare const VPCEndpointDetails: S.Schema<VPCEndpointDetails>;
export interface GetProjectRequest {
    /** The Neon project ID */
    project_id: string;
}
export declare const GetProjectRequest: S.Schema<GetProjectRequest>;
/** Category of an advisor issue */
export type AdvisorCategory = "SECURITY" | "PERFORMANCE";
export declare const AdvisorCategory: any;
export type GetProjectAdvisorSecurityIssuesRequestMinSeverity = "INFO" | "WARN" | "ERROR";
export declare const GetProjectAdvisorSecurityIssuesRequestMinSeverity: any;
export interface GetProjectAdvisorSecurityIssuesRequest {
    /** Neon project ID */
    project_id: string;
    /** Branch ID to analyze. If not specified, the project's default branch is used. */
    branch_id?: string;
    /** Database name to analyze. Required if branch has multiple databases. */
    database_name?: string;
    /** Filter issues by category */
    category?: AdvisorCategory | (string & {});
    /** Minimum severity level to include. For example, WARN returns WARN and ERROR issues, excluding INFO. */
    min_severity?: GetProjectAdvisorSecurityIssuesRequestMinSeverity | (string & {});
}
export declare const GetProjectAdvisorSecurityIssuesRequest: S.Schema<GetProjectAdvisorSecurityIssuesRequest>;
/** Whether this issue affects external API exposure or is internal only */
export type AdvisorIssueFacing = "EXTERNAL" | "INTERNAL";
export declare const AdvisorIssueFacing: any;
/** Categories this issue belongs to */
export type AdvisorIssueCategoriesList = Array<AdvisorCategory>;
export declare const AdvisorIssueCategoriesList: S.Schema<AdvisorIssueCategoriesList>;
/** Additional context-specific metadata */
export type AdvisorIssueMetadataMap = {
    [key: string]: unknown | undefined;
};
export declare const AdvisorIssueMetadataMap: S.Schema<AdvisorIssueMetadataMap>;
export interface AdvisorIssue {
    /** Unique identifier for the issue type */
    name: string;
    /** Human-readable title */
    title: string;
    /** Severity level of the issue */
    level: string;
    /** Whether this issue affects external API exposure or is internal only */
    facing: AdvisorIssueFacing;
    /** Categories this issue belongs to */
    categories: AdvisorIssueCategoriesList;
    /** Detailed description of what this check detects */
    description: string;
    /** Specific details about this instance of the issue */
    detail: string;
    /** URL to documentation on how to fix this issue */
    remediation: string;
    /** Additional context-specific metadata */
    metadata: AdvisorIssueMetadataMap;
    /** Unique key for caching this issue result */
    cache_key: string;
}
export declare const AdvisorIssue: S.Schema<AdvisorIssue>;
export type GetProjectAdvisorSecurityIssuesResponseIssuesList = Array<AdvisorIssue>;
export declare const GetProjectAdvisorSecurityIssuesResponseIssuesList: S.Schema<GetProjectAdvisorSecurityIssuesResponseIssuesList>;
export interface GetProjectAdvisorSecurityIssuesResponse {
    issues: GetProjectAdvisorSecurityIssuesResponseIssuesList;
}
export declare const GetProjectAdvisorSecurityIssuesResponse: S.Schema<GetProjectAdvisorSecurityIssuesResponse>;
export interface GetProjectBranchRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
}
export declare const GetProjectBranchRequest: S.Schema<GetProjectBranchRequest>;
export interface AnnotationObjectData {
    /** Kind of resource the annotation is attached to, for example "branch" or "endpoint". */
    type: string;
    /** The annotated object's ID. */
    id: string;
}
export declare const AnnotationObjectData: S.Schema<AnnotationObjectData>;
export interface AnnotationData {
    /** Resource that this annotation is attached to. */
    object: AnnotationObjectData;
    value: AnnotationValueData;
    /** Timestamp when the annotation was created, in RFC 3339 format (UTC). */
    created_at?: string;
    /** Timestamp of the most recent update to the annotation, in RFC 3339 format (UTC). */
    updated_at?: string;
}
export declare const AnnotationData: S.Schema<AnnotationData>;
export interface GetProjectBranchResponse {
    /** Branch returned by the request. */
    branch: Branch;
    /** Annotation data associated with the annotated object. */
    annotation: AnnotationData;
}
export declare const GetProjectBranchResponse: S.Schema<GetProjectBranchResponse>;
export interface GetProjectBranchAiGatewayRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const GetProjectBranchAiGatewayRequest: S.Schema<GetProjectBranchAiGatewayRequest>;
export interface BranchAiGateway {
    /** Always `true` in 200 responses. Present for forward compatibility, mirroring BranchStorage.enabled. */
    enabled: boolean;
    /** The AI-gateway endpoint root for this branch — an OpenAI-compatible base URL. No dialect path is included; clients append the route (e.g. `/ai-gateway/openai/v1/responses`) themselves. */
    base_url: string;
}
export declare const BranchAiGateway: S.Schema<BranchAiGateway>;
export interface GetProjectBranchBucketObjectRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The bucket name */
    bucket_name: string;
    /** The object key. Keys may contain `/`; the `/` characters of nested keys must be percent-encoded (`%2F`) in the path segment. */
    object_key: string;
}
export declare const GetProjectBranchBucketObjectRequest: S.Schema<GetProjectBranchBucketObjectRequest>;
export interface GetProjectBranchBucketObjectResponse {
}
export declare const GetProjectBranchBucketObjectResponse: S.Schema<GetProjectBranchBucketObjectResponse>;
export interface GetProjectBranchDataAPIRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The database name */
    database_name: string;
}
export declare const GetProjectBranchDataAPIRequest: S.Schema<GetProjectBranchDataAPIRequest>;
/** List of available database schemas (SubZero only) */
export type DataAPIReponseAvailableSchemasList = Array<string>;
export declare const DataAPIReponseAvailableSchemasList: S.Schema<DataAPIReponseAvailableSchemasList>;
/** Neon Data API response */
export interface DataAPIReponse {
    /** The URL of the Neon Data API */
    url: string;
    /** The status of the Neon Data API deployment */
    status: string;
    /** Configuration settings for the Data API (SubZero only) */
    settings?: DataAPISettings | null;
    /** List of available database schemas (SubZero only) */
    available_schemas?: DataAPIReponseAvailableSchemasList | null;
}
export declare const DataAPIReponse: S.Schema<DataAPIReponse>;
export interface GetProjectBranchDatabaseRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** The database name */
    database_name: string;
}
export declare const GetProjectBranchDatabaseRequest: S.Schema<GetProjectBranchDatabaseRequest>;
export interface DatabaseResponse {
    /** Database object returned by the operation. */
    database: Database;
}
export declare const DatabaseResponse: S.Schema<DatabaseResponse>;
export interface GetProjectBranchFunctionRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The function slug */
    slug: string;
}
export declare const GetProjectBranchFunctionRequest: S.Schema<GetProjectBranchFunctionRequest>;
export interface NeonFunction {
    /** Opaque, stable function identifier. */
    id: string;
    /** Branch-unique, lowercase DNS-label. Forms the invocation URL's host together with the branch id. Immutable. */
    slug: string;
    /** Free-form display name. */
    name: string;
    /** URL at which the function is invoked. The host carries `<branch_id>-<slug>` as its first DNS label under a Neon-managed functions domain, and the URL ends with a trailing slash so paths concatenate onto it. Empty string when the function has no servable invoke host (e.g. a deployment without an invocation front-door). */
    invocation_url: string;
    /** The most recent deployment, regardless of build status. It may still be building or it may have failed. Omitted until the first deployment is created. */
    current_deployment?: NeonFunctionDeployment;
    /** The most recent deployment whose build completed successfully. This is the deployment that serves invocations. Omitted until a deployment succeeds. */
    active_deployment?: NeonFunctionDeployment;
    created_at: string;
}
export declare const NeonFunction: S.Schema<NeonFunction>;
export interface NeonFunctionResponse {
    function: NeonFunction;
}
export declare const NeonFunctionResponse: S.Schema<NeonFunctionResponse>;
export interface GetProjectBranchRoleRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** The role name */
    role_name: string;
}
export declare const GetProjectBranchRoleRequest: S.Schema<GetProjectBranchRoleRequest>;
export interface RoleResponse {
    /** Role details for the requested database role. The `password` field is included in the response when a role is created or its password is reset, and is not returned in subsequent read requests. Store it securely at that time. */
    role: Role;
}
export declare const RoleResponse: S.Schema<RoleResponse>;
export interface GetProjectBranchRolePasswordRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** The role name */
    role_name: string;
}
export declare const GetProjectBranchRolePasswordRequest: S.Schema<GetProjectBranchRolePasswordRequest>;
export interface RolePasswordResponse {
    /** The role password */
    password: string | Redacted.Redacted<string>;
}
export declare const RolePasswordResponse: S.Schema<RolePasswordResponse>;
export interface GetProjectBranchSchemaRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** Name of the database for which the schema is retrieved */
    db_name: string;
    /** The Log Sequence Number (LSN) for which the schema is retrieved */
    lsn?: string;
    /** The point in time for which the schema is retrieved */
    timestamp?: string;
    /** The format of the schema to retrieve. Possible values: - `sql` (default) - `json` */
    format?: string;
}
export declare const GetProjectBranchSchemaRequest: S.Schema<GetProjectBranchSchemaRequest>;
export interface BranchSchemaJSONTablesItemColumnsItem {
    /** Name of the column. */
    name: string;
    /** Postgres data type of the column, for example "integer" or "text". */
    type: string;
    /** Whether the column allows NULL values */
    nullable?: boolean;
    /** Whether the column is a generated (computed) column */
    generated?: boolean;
}
export declare const BranchSchemaJSONTablesItemColumnsItem: S.Schema<BranchSchemaJSONTablesItemColumnsItem>;
/** Columns belonging to this table, each describing a column's name and attributes. */
export type BranchSchemaJSONTablesItemColumnsList = Array<BranchSchemaJSONTablesItemColumnsItem>;
export declare const BranchSchemaJSONTablesItemColumnsList: S.Schema<BranchSchemaJSONTablesItemColumnsList>;
/** Column names participating in this constraint */
export type BranchSchemaJSONTablesItemConstraintsItemColumnsList = Array<string>;
export declare const BranchSchemaJSONTablesItemConstraintsItemColumnsList: S.Schema<BranchSchemaJSONTablesItemConstraintsItemColumnsList>;
/** Names of the referenced columns */
export type BranchSchemaJSONTablesItemConstraintsItemReferencedTableColumnsList = Array<string>;
export declare const BranchSchemaJSONTablesItemConstraintsItemReferencedTableColumnsList: S.Schema<BranchSchemaJSONTablesItemConstraintsItemReferencedTableColumnsList>;
/** For foreign keys - the referenced table information */
export interface BranchSchemaJSONTablesItemConstraintsItemReferencedTable {
    /** Schema of the referenced table */
    schema: string;
    /** Name of the referenced table */
    table: string;
    /** Names of the referenced columns */
    columns: BranchSchemaJSONTablesItemConstraintsItemReferencedTableColumnsList;
}
export declare const BranchSchemaJSONTablesItemConstraintsItemReferencedTable: S.Schema<BranchSchemaJSONTablesItemConstraintsItemReferencedTable>;
export interface BranchSchemaJSONTablesItemConstraintsItem {
    /** Type of constraint. Possible values: `primary_key`, `unique`, `foreign_key` */
    type: string;
    /** Column names participating in this constraint */
    columns: BranchSchemaJSONTablesItemConstraintsItemColumnsList;
    /** Optional name of the constraint */
    name?: string;
    /** For foreign keys - the referenced table information */
    referenced_table?: BranchSchemaJSONTablesItemConstraintsItemReferencedTable;
}
export declare const BranchSchemaJSONTablesItemConstraintsItem: S.Schema<BranchSchemaJSONTablesItemConstraintsItem>;
/** Table constraints defined in the branch schema, such as primary key, foreign key, unique, and check constraints. */
export type BranchSchemaJSONTablesItemConstraintsList = Array<BranchSchemaJSONTablesItemConstraintsItem>;
export declare const BranchSchemaJSONTablesItemConstraintsList: S.Schema<BranchSchemaJSONTablesItemConstraintsList>;
export interface BranchSchemaJSONTablesItem {
    /** Postgres schema (namespace) that contains the table, for example `public`. */
    schema: string;
    /** Name of the table within the schema. */
    name: string;
    /** Columns belonging to this table, each describing a column's name and attributes. */
    columns: BranchSchemaJSONTablesItemColumnsList;
    /** Table constraints defined in the branch schema, such as primary key, foreign key, unique, and check constraints. */
    constraints?: BranchSchemaJSONTablesItemConstraintsList;
}
export declare const BranchSchemaJSONTablesItem: S.Schema<BranchSchemaJSONTablesItem>;
/** Tables present in the branch schema. */
export type BranchSchemaJSONTablesList = Array<BranchSchemaJSONTablesItem>;
export declare const BranchSchemaJSONTablesList: S.Schema<BranchSchemaJSONTablesList>;
export interface BranchSchemaJSON {
    /** Tables present in the branch schema. */
    tables: BranchSchemaJSONTablesList;
}
export declare const BranchSchemaJSON: S.Schema<BranchSchemaJSON>;
export interface BranchSchemaResponse {
    /** Branch schema expressed as SQL DDL statements. */
    sql?: string;
    /** Branch schema represented as a structured JSON object, parallel to the SQL DDL in `sql`. */
    json?: BranchSchemaJSON;
}
export declare const BranchSchemaResponse: S.Schema<BranchSchemaResponse>;
export interface GetProjectBranchSchemaComparisonRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** The branch ID to compare the schema with */
    base_branch_id?: string;
    /** Name of the database for which the schema is retrieved */
    db_name: string;
    /** The Log Sequence Number (LSN) for which the schema is retrieved */
    lsn?: string;
    /** The point in time for which the schema is retrieved */
    timestamp?: string;
    /** The Log Sequence Number (LSN) for the base branch schema */
    base_lsn?: string;
    /** The point in time for the base branch schema */
    base_timestamp?: string;
}
export declare const GetProjectBranchSchemaComparisonRequest: S.Schema<GetProjectBranchSchemaComparisonRequest>;
export interface BranchSchemaCompareResponse {
    /** Unified diff of the SQL schema changes between the compared branches. */
    diff?: string;
}
export declare const BranchSchemaCompareResponse: S.Schema<BranchSchemaCompareResponse>;
export interface GetProjectBranchStorageRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const GetProjectBranchStorageRequest: S.Schema<GetProjectBranchStorageRequest>;
export interface BranchStorage {
    /** Always `true` in 200 responses. Present for forward compatibility: a future version may add intermediate states; callers should treat `true` as "object storage is usable for this branch right now." */
    enabled: boolean;
    /** The S3-compatible endpoint URL for this branch. */
    s3_endpoint: string;
    /** The AWS region for this branch's object storage. The platform normalizes the us-east-1 convention server-side: a non-empty region string is always returned in 200 responses (e.g. `"us-east-1"` for the S3 default region). */
    region: string;
    /** Whether the S3 client must use path-style addressing (bucket-in-path rather than virtual-hosted subdomain). Always true: the wildcard TLS cert covers one level of subdomain (*.storage.<suffix>), so the branch ID occupies that label and the bucket name must travel in the request path, not as a further subdomain. Callers must set the S3 SDK's ForcePathStyle (or equivalent) to true. */
    force_path_style: boolean;
}
export declare const BranchStorage: S.Schema<BranchStorage>;
export interface GetProjectEndpointRequest {
    /** The Neon project ID */
    project_id: string;
    /** The endpoint ID */
    endpoint_id: string;
}
export declare const GetProjectEndpointRequest: S.Schema<GetProjectEndpointRequest>;
export interface EndpointResponse {
    /** Compute endpoint created or retrieved, including its current lifecycle state. */
    endpoint: Endpoint;
}
export declare const EndpointResponse: S.Schema<EndpointResponse>;
export interface GetProjectJWKSRequest {
    /** The Neon project ID */
    project_id: string;
}
export declare const GetProjectJWKSRequest: S.Schema<GetProjectJWKSRequest>;
/** JWKS configurations associated with the project. */
export type ProjectJWKSResponseJwksList = Array<JWKS>;
export declare const ProjectJWKSResponseJwksList: S.Schema<ProjectJWKSResponseJwksList>;
/** The list of configured JWKS definitions for a project */
export interface ProjectJWKSResponse {
    /** JWKS configurations associated with the project. */
    jwks: ProjectJWKSResponseJwksList;
}
export declare const ProjectJWKSResponse: S.Schema<ProjectJWKSResponse>;
export interface GetProjectOperationRequest {
    /** The Neon project ID */
    project_id: string;
    /** The operation ID */
    operation_id: string;
}
export declare const GetProjectOperationRequest: S.Schema<GetProjectOperationRequest>;
export interface OperationResponse {
    operation: Operation;
}
export declare const OperationResponse: S.Schema<OperationResponse>;
export interface GetSnapshotScheduleRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
}
export declare const GetSnapshotScheduleRequest: S.Schema<GetSnapshotScheduleRequest>;
export interface BackupScheduleItem {
    /** How often to take snapshots. Known values: `daily`, `weekly`, `monthly`. */
    frequency: string;
    /** The hour of the day to take the snapshot (if applicable). */
    hour?: number;
    /** The day of the week or month to take the snapshot (if applicable). */
    day?: number;
    /** The month of the year to take the snapshot (if applicable). */
    month?: number;
    /** How long to keep a scheduled snapshot (in seconds) before it's automatically deleted. The default is 3024000 seconds (35 days), which is also the maximum. Manually created snapshots have no maximum retention: set their `expires_at` instead. */
    retention_seconds?: number;
}
export declare const BackupScheduleItem: S.Schema<BackupScheduleItem>;
/** List of schedule entries defining the backup frequency. At least one entry is required. */
export type BackupScheduleScheduleList = Array<BackupScheduleItem>;
export declare const BackupScheduleScheduleList: S.Schema<BackupScheduleScheduleList>;
export interface BackupSchedule {
    /** List of schedule entries defining the backup frequency. At least one entry is required. */
    schedule: BackupScheduleScheduleList;
}
export declare const BackupSchedule: S.Schema<BackupSchedule>;
export interface GrantPermissionToProjectRequest {
    project_id: string;
    /** Email address of the user to grant project access to. */
    email: string;
}
export declare const GrantPermissionToProjectRequest: S.Schema<GrantPermissionToProjectRequest>;
export interface ProjectPermission {
    /** The project permission's ID. */
    id: string;
    /** Email address of the user who has been granted access to the project. */
    granted_to_email: string;
    /** Timestamp when the permission was granted. */
    granted_at: string;
    /** Timestamp when the permission was revoked. Null if the permission is still active. */
    revoked_at?: string;
}
export declare const ProjectPermission: S.Schema<ProjectPermission>;
export interface ListApiKeysRequest {
}
export declare const ListApiKeysRequest: S.Schema<ListApiKeysRequest>;
/** The user data of the user that created this API key. */
export interface ApiKeyCreatorData {
    /** ID of the user who created this API key */
    id: string;
    /** Display name of the user who created the API key. */
    name: string;
    /** The URL to the user's avatar image. */
    image: string;
}
export declare const ApiKeyCreatorData: S.Schema<ApiKeyCreatorData>;
export interface ApiKeysListResponseItem {
    /** The API key's unique numeric ID. Distinct from the API key token (`key`). */
    id: number;
    /** The user-specified API key name */
    name: string;
    /** A timestamp indicating when the API key was created */
    created_at: string;
    created_by: ApiKeyCreatorData;
    /** A timestamp indicating when the API was last used */
    last_used_at?: string | null;
    /** The IP address from which the API key was last used */
    last_used_from_addr: string;
}
export declare const ApiKeysListResponseItem: S.Schema<ApiKeysListResponseItem>;
export type ListApiKeysResponseBodyList = Array<ApiKeysListResponseItem>;
export declare const ListApiKeysResponseBodyList: S.Schema<ListApiKeysResponseBodyList>;
export type ListApiKeysResponse = ListApiKeysResponseBodyList;
export declare const ListApiKeysResponse: S.Schema<ListApiKeysResponse>;
export interface ListBranchNeonAuthOauthProvidersRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const ListBranchNeonAuthOauthProvidersRequest: S.Schema<ListBranchNeonAuthOauthProvidersRequest>;
/** OAuth providers configured for Neon Auth on the project. */
export type ListNeonAuthOauthProvidersResponseProvidersList = Array<NeonAuthOauthProvider>;
export declare const ListNeonAuthOauthProvidersResponseProvidersList: S.Schema<ListNeonAuthOauthProvidersResponseProvidersList>;
export interface ListNeonAuthOauthProvidersResponse {
    /** OAuth providers configured for Neon Auth on the project. */
    providers: ListNeonAuthOauthProvidersResponseProvidersList;
}
export declare const ListNeonAuthOauthProvidersResponse: S.Schema<ListNeonAuthOauthProvidersResponse>;
export interface ListBranchNeonAuthTrustedDomainsRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const ListBranchNeonAuthTrustedDomainsRequest: S.Schema<ListBranchNeonAuthTrustedDomainsRequest>;
export interface NeonAuthRedirectURIWhitelistDomain {
    /** Allowed redirect URI domain for the auth provider. */
    domain: string;
    auth_provider: NeonAuthSupportedAuthProvider;
}
export declare const NeonAuthRedirectURIWhitelistDomain: S.Schema<NeonAuthRedirectURIWhitelistDomain>;
/** Domains permitted as redirect URI targets in the whitelist. */
export type NeonAuthRedirectURIWhitelistResponseDomainsList = Array<NeonAuthRedirectURIWhitelistDomain>;
export declare const NeonAuthRedirectURIWhitelistResponseDomainsList: S.Schema<NeonAuthRedirectURIWhitelistResponseDomainsList>;
export interface NeonAuthRedirectURIWhitelistResponse {
    /** Domains permitted as redirect URI targets in the whitelist. */
    domains: NeonAuthRedirectURIWhitelistResponseDomainsList;
}
export declare const NeonAuthRedirectURIWhitelistResponse: S.Schema<NeonAuthRedirectURIWhitelistResponse>;
export interface ListCredentialsRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const ListCredentialsRequest: S.Schema<ListCredentialsRequest>;
export type CredentialMetaScopesList = Array<GrantedCredentialScope>;
export declare const CredentialMetaScopesList: S.Schema<CredentialMetaScopesList>;
export interface CredentialMeta {
    /** Opaque credential id (e.g. nak_live_<32hex>). */
    token_id: string;
    token_id_short: string;
    /** Customer-supplied label; absent when not provided at issuance. */
    name?: string;
    scopes: CredentialMetaScopesList;
    branch_id?: string;
    principal_type: string;
    function_id?: string;
    created_at: string;
    last_used_at?: string;
    revoked_at?: string;
    /** When the credential expires; absent means never expires. The verifier refuses to authenticate after `expires_at <= now()`. */
    expires_at?: string;
}
export declare const CredentialMeta: S.Schema<CredentialMeta>;
export type ListCredentialsResponseCredentialsList = Array<CredentialMeta>;
export declare const ListCredentialsResponseCredentialsList: S.Schema<ListCredentialsResponseCredentialsList>;
export interface ListCredentialsResponse {
    credentials: ListCredentialsResponseCredentialsList;
}
export declare const ListCredentialsResponse: S.Schema<ListCredentialsResponse>;
export interface ListOrganizationVPCEndpointsRequest {
    /** The Neon organization ID */
    org_id: string;
    /** The Neon region ID */
    region_id: string;
}
export declare const ListOrganizationVPCEndpointsRequest: S.Schema<ListOrganizationVPCEndpointsRequest>;
export interface VPCEndpoint {
    /** Cloud provider identifier for the VPC endpoint. */
    vpc_endpoint_id: string;
    /** A descriptive label for the VPC endpoint */
    label: string;
}
export declare const VPCEndpoint: S.Schema<VPCEndpoint>;
/** List of VPC endpoints returned by the request. */
export type VPCEndpointsResponseEndpointsList = Array<VPCEndpoint>;
export declare const VPCEndpointsResponseEndpointsList: S.Schema<VPCEndpointsResponseEndpointsList>;
export interface VPCEndpointsResponse {
    /** List of VPC endpoints returned by the request. */
    endpoints: VPCEndpointsResponseEndpointsList;
}
export declare const VPCEndpointsResponse: S.Schema<VPCEndpointsResponse>;
export interface ListOrganizationVPCEndpointsAllRegionsRequest {
    /** The Neon organization ID */
    org_id: string;
}
export declare const ListOrganizationVPCEndpointsAllRegionsRequest: S.Schema<ListOrganizationVPCEndpointsAllRegionsRequest>;
export interface VPCEndpointWithRegion {
    /** Cloud provider identifier for the VPC endpoint. */
    vpc_endpoint_id: string;
    /** A descriptive label for the VPC endpoint */
    label: string;
    /** The region where the VPC endpoint is located */
    region_id: string;
}
export declare const VPCEndpointWithRegion: S.Schema<VPCEndpointWithRegion>;
/** VPC endpoints associated with the region. */
export type VPCEndpointsWithRegionResponseEndpointsList = Array<VPCEndpointWithRegion>;
export declare const VPCEndpointsWithRegionResponseEndpointsList: S.Schema<VPCEndpointsWithRegionResponseEndpointsList>;
export interface VPCEndpointsWithRegionResponse {
    /** VPC endpoints associated with the region. */
    endpoints: VPCEndpointsWithRegionResponseEndpointsList;
}
export declare const VPCEndpointsWithRegionResponse: S.Schema<VPCEndpointsWithRegionResponse>;
export interface ListOrgApiKeysRequest {
    /** The Neon organization ID */
    org_id: string;
}
export declare const ListOrgApiKeysRequest: S.Schema<ListOrgApiKeysRequest>;
export interface OrgApiKeysListResponseItem {
    /** The API key's unique numeric ID. Distinct from the API key token (`key`). */
    id: number;
    /** The user-specified API key name */
    name: string;
    /** A timestamp indicating when the API key was created */
    created_at: string;
    created_by: ApiKeyCreatorData;
    /** A timestamp indicating when the API was last used */
    last_used_at?: string | null;
    /** The IP address from which the API key was last used */
    last_used_from_addr: string;
    /** If set, the API key can access only this project */
    project_id?: string;
}
export declare const OrgApiKeysListResponseItem: S.Schema<OrgApiKeysListResponseItem>;
export type ListOrgApiKeysResponseBodyList = Array<OrgApiKeysListResponseItem>;
export declare const ListOrgApiKeysResponseBodyList: S.Schema<ListOrgApiKeysResponseBodyList>;
export type ListOrgApiKeysResponse = ListOrgApiKeysResponseBodyList;
export declare const ListOrgApiKeysResponse: S.Schema<ListOrgApiKeysResponse>;
export interface ListProjectBranchBucketObjectsRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The bucket name */
    bucket_name: string;
    /** Only list objects whose key starts with this prefix. */
    prefix?: string;
    /** Collapse keys sharing a common prefix up to the first occurrence of this delimiter (typically `/`) into the `folders` array. */
    delimiter?: string;
    /** Opaque pagination cursor returned as `next_cursor` by a previous call. Resume listing after the last item of the previous page. */
    cursor?: string;
    /** Maximum number of items (objects + folders) to return. */
    limit?: number;
}
export declare const ListProjectBranchBucketObjectsRequest: S.Schema<ListProjectBranchBucketObjectsRequest>;
/** Common prefixes (folder names) collapsed under the requested `delimiter`. Empty when no `delimiter` was supplied. */
export type BucketObjectsListResponseFoldersList = Array<string>;
export declare const BucketObjectsListResponseFoldersList: S.Schema<BucketObjectsListResponseFoldersList>;
export interface BucketObject {
    /** The full object key. */
    key: string;
    /** The object size in bytes. */
    size: number;
    /** The time the object was last modified. */
    last_modified: string;
    /** The object's entity tag (content hash). */
    etag: string;
}
export declare const BucketObject: S.Schema<BucketObject>;
/** Objects whose keys did not collapse into a folder. */
export type BucketObjectsListResponseObjectsList = Array<BucketObject>;
export declare const BucketObjectsListResponseObjectsList: S.Schema<BucketObjectsListResponseObjectsList>;
export interface BucketObjectsListResponse {
    /** Common prefixes (folder names) collapsed under the requested `delimiter`. Empty when no `delimiter` was supplied. */
    folders: BucketObjectsListResponseFoldersList;
    /** Objects whose keys did not collapse into a folder. */
    objects: BucketObjectsListResponseObjectsList;
    /** The prefix that was applied to this listing (echoed back). */
    prefix: string;
    /** Pagination cursor to pass as `cursor` on the next request. Empty when the listing is not truncated. */
    next_cursor?: string;
    /** True when more results exist beyond this page. */
    is_truncated: boolean;
}
export declare const BucketObjectsListResponse: S.Schema<BucketObjectsListResponse>;
export interface ListProjectBranchBucketsRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const ListProjectBranchBucketsRequest: S.Schema<ListProjectBranchBucketsRequest>;
export type BucketsListResponseBucketsList = Array<Bucket>;
export declare const BucketsListResponseBucketsList: S.Schema<BucketsListResponseBucketsList>;
export interface BucketsListResponse {
    buckets: BucketsListResponseBucketsList;
}
export declare const BucketsListResponse: S.Schema<BucketsListResponse>;
export interface ListProjectBranchCustomDomainsRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** A cursor to use in pagination. A cursor defines your place in the data list. Include `response.pagination.next` in subsequent API calls to fetch next page of the list. */
    cursor?: string;
    /** Specify a value from 1 to 1000 to limit number of domains in the response */
    limit?: number;
}
export declare const ListProjectBranchCustomDomainsRequest: S.Schema<ListProjectBranchCustomDomainsRequest>;
export interface CustomDomain {
    /** The registered custom domain (normalized, lowercase). */
    domain: string;
    /** The kind of branch entity the domain targets. Possible values: `function` (v1 supports only `function`). Not an `enum`: new values may ship in later spec versions — treat any undocumented value as unknown. */
    entity_type: string;
    /** The target entity's identifier within the branch. For `function` this is the function slug. */
    entity_id: string;
    /** The hostname the customer must point their custom domain at with a CNAME record. Empty when the serving region has no custom-domains front door configured. This is the activation input: point DNS here and the domain goes live (see `status`) once a certificate is issued on the first request. */
    cname_target: string;
    /** The domain's current validity, computed by a background check: `pending` (still converging — point your CNAME at `cname_target` and wait), `active` (live: DNS resolves to the edge, the CA is authorized, and routing is published), or `error` (a fixable problem — see `status_reason`). Not an `enum`: treat any undocumented value as unknown. May be absent briefly right after registration. */
    status?: string;
    /** The DNS + CAA portion of the check: `pending` (no records yet), `ok` (resolves to our edge and the CA is authorized), `misconfigured` (your CNAME does not resolve to our edge), or `caa_blocked` (your CAA records forbid Let's Encrypt). Not an `enum`. */
    dns_status?: string;
    /** Whether Neon's internal routing for the domain is published: `pending`, `present`, or `missing`. `missing` is an internal fault surfaced for support. Not an `enum`. */
    binding_status?: string;
    /** A short, stable machine-readable reason for a non-active `status` (e.g. `cname-not-pointing-at-edge`, `caa-blocks-lets-encrypt`, `binding-missing`), suitable for keying an actionable hint. Empty when active or pending. */
    status_reason?: string;
}
export declare const CustomDomain: S.Schema<CustomDomain>;
export type ListProjectBranchCustomDomainsResponseCustomDomainsList = Array<CustomDomain>;
export declare const ListProjectBranchCustomDomainsResponseCustomDomainsList: S.Schema<ListProjectBranchCustomDomainsResponseCustomDomainsList>;
export interface ListProjectBranchCustomDomainsResponse {
    custom_domains: ListProjectBranchCustomDomainsResponseCustomDomainsList;
    pagination?: CursorPagination;
}
export declare const ListProjectBranchCustomDomainsResponse: S.Schema<ListProjectBranchCustomDomainsResponse>;
export interface ListProjectBranchDatabasesRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
}
export declare const ListProjectBranchDatabasesRequest: S.Schema<ListProjectBranchDatabasesRequest>;
/** Databases on the branch. Each includes `id`, `name`, `owner_name`, and `created_at`. */
export type DatabasesResponseDatabasesList = Array<Database>;
export declare const DatabasesResponseDatabasesList: S.Schema<DatabasesResponseDatabasesList>;
export interface DatabasesResponse {
    /** Databases on the branch. Each includes `id`, `name`, `owner_name`, and `created_at`. */
    databases: DatabasesResponseDatabasesList;
}
export declare const DatabasesResponse: S.Schema<DatabasesResponse>;
export interface ListProjectBranchEndpointsRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
}
export declare const ListProjectBranchEndpointsRequest: S.Schema<ListProjectBranchEndpointsRequest>;
/** Compute endpoints in the project. Each includes `id`, `branch_id`, `host`, and `type`. */
export type EndpointsResponseEndpointsList = Array<Endpoint>;
export declare const EndpointsResponseEndpointsList: S.Schema<EndpointsResponseEndpointsList>;
export interface EndpointsResponse {
    /** Compute endpoints in the project. Each includes `id`, `branch_id`, `host`, and `type`. */
    endpoints: EndpointsResponseEndpointsList;
}
export declare const EndpointsResponse: S.Schema<EndpointsResponse>;
export type ListProjectBranchesRequestSortBy = "name" | "created_at" | "updated_at";
export declare const ListProjectBranchesRequestSortBy: any;
export type ListProjectBranchesRequestSortOrder = "asc" | "desc";
export declare const ListProjectBranchesRequestSortOrder: any;
export interface ListProjectBranchesRequest {
    /** The Neon project ID */
    project_id: string;
    /** Search by branch `name` or `id`. You can specify partial `name` or `id` values to filter results. */
    search?: string;
    /** Sort the branches by sort_field. If not provided, branches will be sorted by updated_at descending order */
    sort_by?: ListProjectBranchesRequestSortBy | (string & {});
    /** A cursor to use in pagination. A cursor defines your place in the data list. Include `response.pagination.next` in subsequent API calls to fetch next page of the list. */
    cursor?: string;
    /** Defines the sorting order of entities. */
    sort_order?: ListProjectBranchesRequestSortOrder | (string & {});
    /** The maximum number of records to be returned in the response */
    limit?: number;
    /** If true, return recoverable deleted branches too (soft-deleted within the recovery window). If false or not provided, return only active (non-deleted) branches. This parameter is part of the Branch Recovery feature, which is in preview and not available to all users. */
    include_deleted?: boolean;
}
export declare const ListProjectBranchesRequest: S.Schema<ListProjectBranchesRequest>;
/** Branches in the project. Each includes `id`, `name`, `current_state`, and `created_at`. */
export type ListProjectBranchesResponseBranchesList = Array<Branch>;
export declare const ListProjectBranchesResponseBranchesList: S.Schema<ListProjectBranchesResponseBranchesList>;
/** Map of annotations keyed by resource identifier, where each value contains the annotation data for that resource. */
export type ListProjectBranchesResponseAnnotationsMap = {
    [key: string]: AnnotationData | undefined;
};
export declare const ListProjectBranchesResponseAnnotationsMap: S.Schema<ListProjectBranchesResponseAnnotationsMap>;
export interface ListProjectBranchesResponse {
    /** Branches in the project. Each includes `id`, `name`, `current_state`, and `created_at`. */
    branches: ListProjectBranchesResponseBranchesList;
    /** Map of annotations keyed by resource identifier, where each value contains the annotation data for that resource. */
    annotations: ListProjectBranchesResponseAnnotationsMap;
    pagination?: CursorPagination;
}
export declare const ListProjectBranchesResponse: S.Schema<ListProjectBranchesResponse>;
export interface ListProjectBranchFunctionsRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** A cursor to use in pagination. A cursor defines your place in the data list. Include `response.pagination.next` in subsequent API calls to fetch next page of the list. */
    cursor?: string;
    /** Specify a value from 1 to 1000 to limit number of functions in the response */
    limit?: number;
}
export declare const ListProjectBranchFunctionsRequest: S.Schema<ListProjectBranchFunctionsRequest>;
export type ListProjectBranchFunctionsResponseFunctionsList = Array<NeonFunction>;
export declare const ListProjectBranchFunctionsResponseFunctionsList: S.Schema<ListProjectBranchFunctionsResponseFunctionsList>;
export interface ListProjectBranchFunctionsResponse {
    functions: ListProjectBranchFunctionsResponseFunctionsList;
    pagination?: CursorPagination;
}
export declare const ListProjectBranchFunctionsResponse: S.Schema<ListProjectBranchFunctionsResponse>;
export interface ListProjectBranchLogFieldsRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
}
export declare const ListProjectBranchLogFieldsRequest: S.Schema<ListProjectBranchLogFieldsRequest>;
/** Log field names observed on this branch, each usable as `field_name` on the log field-values endpoint. Computed per branch rather than fixed by this specification, so clients should not assume a particular set. */
export type ProjectBranchLogFieldsResponseFieldsList = Array<string>;
export declare const ProjectBranchLogFieldsResponseFieldsList: S.Schema<ProjectBranchLogFieldsResponseFieldsList>;
export interface ProjectBranchLogFieldsResponse {
    /** Log field names observed on this branch, each usable as `field_name` on the log field-values endpoint. Computed per branch rather than fixed by this specification, so clients should not assume a particular set. */
    fields: ProjectBranchLogFieldsResponseFieldsList;
}
export declare const ProjectBranchLogFieldsResponse: S.Schema<ProjectBranchLogFieldsResponse>;
/** The Neon service that emitted the log record. */
export type ProjectBranchLogSource = "function" | "storage" | "pg_endpoint";
export declare const ProjectBranchLogSource: any;
export interface ListProjectBranchLogFieldValuesRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The log field whose distinct values should be returned. Must be one of the names returned by the log fields endpoint for this branch. */
    field_name: string;
    /** Length of the lookup window, ending at `end_time` or at the current time when `end_time` is omitted. Mutually exclusive with `start_time`. Defaults to six hours. */
    since?: string;
    /** Inclusive beginning of the lookup window. Mutually exclusive with `since`. */
    start_time?: string;
    /** Exclusive end of the lookup window. Defaults to the current time. */
    end_time?: string;
    /** Only consider records emitted by this Neon service. */
    source?: ProjectBranchLogSource | (string & {});
    /** Maximum number of distinct values to return. The response sets `is_truncated` when this bound, or the server's own scan cap, cut the list short. */
    limit?: number;
}
export declare const ListProjectBranchLogFieldValuesRequest: S.Schema<ListProjectBranchLogFieldValuesRequest>;
export type ProjectBranchLogFieldValuesResponseValuesList = Array<string>;
export declare const ProjectBranchLogFieldValuesResponseValuesList: S.Schema<ProjectBranchLogFieldValuesResponseValuesList>;
export interface ProjectBranchLogFieldValuesResponse {
    values: ProjectBranchLogFieldValuesResponseValuesList;
    /** True when more distinct values exist than were returned, because either the requested `limit` or the server's own scan cap was reached. A caller that filters on a partial list is choosing from an arbitrary subset, so narrow `since` or `source` and ask again when this is `true`. */
    is_truncated: boolean;
}
export declare const ProjectBranchLogFieldValuesResponse: S.Schema<ProjectBranchLogFieldValuesResponse>;
export interface ListProjectBranchRolesRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
}
export declare const ListProjectBranchRolesRequest: S.Schema<ListProjectBranchRolesRequest>;
/** Roles belonging to the branch. Each role includes fields such as `branch_id`, `name`, `protected`, `created_at`, and `updated_at`. */
export type RolesResponseRolesList = Array<Role>;
export declare const RolesResponseRolesList: S.Schema<RolesResponseRolesList>;
export interface RolesResponse {
    /** Roles belonging to the branch. Each role includes fields such as `branch_id`, `name`, `protected`, `created_at`, and `updated_at`. */
    roles: RolesResponseRolesList;
}
export declare const RolesResponse: S.Schema<RolesResponse>;
export interface ListProjectEndpointsRequest {
    /** The Neon project ID */
    project_id: string;
}
export declare const ListProjectEndpointsRequest: S.Schema<ListProjectEndpointsRequest>;
export interface ListProjectMembersRequest {
    project_id: string;
    /** A cursor to use in pagination. A cursor defines your place in the data list. Include `response.pagination.next` in subsequent API calls to fetch next page of the list. */
    cursor?: string;
    /** The maximum number of members to return in the response */
    limit?: number;
}
export declare const ListProjectMembersRequest: S.Schema<ListProjectMembersRequest>;
/** Organization-level role used by project member role management. */
export type ProjectMemberOrgRole = "admin" | "member" | "editor" | "viewer" | "collaborator";
export declare const ProjectMemberOrgRole: any;
/** Per-project role. `viewer` maps to `VIEWER`, `editor` maps to `EDITOR`, and `admin` maps to `ADMIN`. */
export type ProjectRole = "viewer" | "editor" | "admin";
export declare const ProjectRole: any;
/** How a member's project access is granted. */
export type ProjectMemberGrantSource = "explicit" | "org_role_default" | "org_admin_override" | "unassigned";
export declare const ProjectMemberGrantSource: any;
export interface ProjectMember {
    /** The organization member ID. */
    member_id: string;
    /** The user ID for the organization member. */
    user_id: string;
    /** Email address of the user who has been granted access to the project. */
    email?: string;
    /** The user's display name. */
    name?: string;
    org_role: ProjectMemberOrgRole;
    project_role?: ProjectRole;
    org_default_project_permission?: ProjectPermissionLevel;
    explicit_project_permission?: ProjectPermissionLevel;
    effective_project_permission?: ProjectPermissionLevel;
    grant_source?: ProjectMemberGrantSource;
}
export declare const ProjectMember: S.Schema<ProjectMember>;
export type ProjectMembersProjectMembersList = Array<ProjectMember>;
export declare const ProjectMembersProjectMembersList: S.Schema<ProjectMembersProjectMembersList>;
export interface ProjectMembers {
    project_members: ProjectMembersProjectMembersList;
    pagination?: CursorPagination;
}
export declare const ProjectMembers: S.Schema<ProjectMembers>;
export interface ListProjectOperationsRequest {
    /** The Neon project ID */
    project_id: string;
    /** Specify the cursor value from the previous response to get the next batch of operations */
    cursor?: string;
    /** Specify a value from 1 to 1000 to limit number of operations in the response */
    limit?: number;
}
export declare const ListProjectOperationsRequest: S.Schema<ListProjectOperationsRequest>;
export type ListProjectOperationsResponseOperationsList = Array<Operation>;
export declare const ListProjectOperationsResponseOperationsList: S.Schema<ListProjectOperationsResponseOperationsList>;
export interface ListProjectOperationsResponse {
    operations: ListProjectOperationsResponseOperationsList;
    pagination?: Pagination;
}
export declare const ListProjectOperationsResponse: S.Schema<ListProjectOperationsResponse>;
export interface ListProjectPermissionsRequest {
    project_id: string;
}
export declare const ListProjectPermissionsRequest: S.Schema<ListProjectPermissionsRequest>;
export type ProjectPermissionsProjectPermissionsList = Array<ProjectPermission>;
export declare const ProjectPermissionsProjectPermissionsList: S.Schema<ProjectPermissionsProjectPermissionsList>;
export interface ProjectPermissions {
    project_permissions: ProjectPermissionsProjectPermissionsList;
}
export declare const ProjectPermissions: S.Schema<ProjectPermissions>;
export interface ListProjectsRequest {
    /** Specify the cursor value from the previous response to retrieve the next batch of projects. */
    cursor?: string;
    /** Specify a value from 1 to 400 to limit number of projects in the response. */
    limit?: number;
    /** Search by project `name` or `id`. You can specify partial `name` or `id` values to filter results. */
    search?: string;
    /** Search for projects by `org_id`. */
    org_id?: string;
    /** Specify an explicit timeout in milliseconds to limit response delay. After timing out, the incomplete list of project data fetched so far will be returned. Projects still being fetched when the timeout occurred are listed in the "unavailable" attribute of the response. If not specified, an implicit implementation defined timeout is chosen with the same behaviour as above */
    timeout?: number;
    /** Show only deleted projects within the recovery window. */
    recoverable?: boolean;
}
export declare const ListProjectsRequest: S.Schema<ListProjectsRequest>;
/** Essential data about the project. Full data is available at `GET /projects/{project_id}`. */
export interface ProjectListItem {
    /** The Neon project ID. Use as the `project_id` path parameter in other endpoints. */
    id: string;
    /** The cloud platform identifier. Currently, only AWS is supported, for which the identifier is `aws`. */
    platform_id: string;
    /** Cloud region where the project's Postgres compute and storage reside (for example, `aws-us-east-2`). Valid values are returned by `GET /regions`. */
    region_id: string;
    /** The project name */
    name: string;
    /** Compute provisioner. `k8s-neonvm` (default) supports Autoscaling; `k8s-pod` is fixed-size compute. Also `docker` and `serverless-platform`. */
    provisioner: string;
    default_endpoint_settings?: DefaultEndpointSettings;
    /** Project-level settings, for example `quota`, `allowed_ips`, `enable_logical_replication`, and `maintenance_window`. */
    settings?: ProjectSettingsData;
    pg_version: number;
    /** The proxy host for the project. This value combines the `region_id`, the `platform_id`, and the Neon domain (`neon.tech`). */
    proxy_host: string;
    /** The logical size limit for a branch. The value is in MiB. */
    branch_logical_size_limit: number;
    /** The logical size limit for a branch. The value is in B. */
    branch_logical_size_limit_bytes: number;
    /** Whether or not passwords are stored for roles in the Neon project. Storing passwords facilitates access to Neon features that require authorization. */
    store_passwords: boolean;
    /** Control plane observed endpoints of this project being active this amount of wall-clock time. */
    active_time: number;
    /** Deprecated. Use `compute_time_seconds` from `GET /projects/{project_id}` instead. */
    cpu_used_sec: number;
    /** A timestamp indicating when project maintenance begins. If set, the project is placed into maintenance mode at this time. */
    maintenance_starts_at?: string;
    /** The project creation source */
    creation_source: string;
    /** A timestamp indicating when the project was created */
    created_at: string;
    /** A timestamp indicating when the project was last updated */
    updated_at: string;
    /** The current space occupied by the project in Postgres storage, in bytes. Synthetic Postgres storage size combines the logical data size and Write-Ahead Log (WAL) size for all branches in a project. */
    synthetic_storage_size?: number;
    /** Deprecated. Use `consumption_period_end` from `GET /projects/{project_id}` instead. A timestamp indicating when the project quota resets. */
    quota_reset_at?: string;
    /** ID of the organization that owns the project. */
    owner_id: string;
    /** The most recent time when any endpoint of this project was active. Omitted when observed no activity for endpoints of this project. */
    compute_last_active_at?: string;
    /** ID of the organization that owns the project. Project permissions are granted to organization members as configured by the organization's admins, independent of which member created the project. */
    org_id?: string;
    /** Name of the organization that owns the project. */
    org_name?: string;
    /** The number of seconds to retain the shared history for all branches in this project. */
    history_retention_seconds?: number;
    /** A timestamp indicating when HIPAA was enabled for this project */
    hipaa_enabled_at?: string;
    /** A timestamp indicating when the project was deleted */
    deleted_at?: string;
    /** A timestamp indicating the project will be recoverable until this date and time. */
    recoverable_until?: string;
    effective_project_permission?: ProjectPermissionLevel | null;
}
export declare const ProjectListItem: S.Schema<ProjectListItem>;
/** List of projects accessible to the caller. Projects that exist but could not be retrieved are identified in `unavailable_project_ids`. */
export type ListProjectsResponseProjectsList = Array<ProjectListItem>;
export declare const ListProjectsResponseProjectsList: S.Schema<ListProjectsResponseProjectsList>;
/** A list of project IDs indicating which projects are known to exist, but whose details could not be fetched within the requested (or implicit) time limit */
export type ListProjectsResponseUnavailableProjectIdsList = Array<string>;
export declare const ListProjectsResponseUnavailableProjectIdsList: S.Schema<ListProjectsResponseUnavailableProjectIdsList>;
/** Type of application integration */
export type ApplicationType = "vercel" | "github" | "datadog" | "opentelemetry";
export declare const ApplicationType: any;
export type ListProjectsResponseApplicationsValueList = Array<ApplicationType>;
export declare const ListProjectsResponseApplicationsValueList: S.Schema<ListProjectsResponseApplicationsValueList>;
/** Map of project IDs to their installed applications. Each key is a project ID; each value is an array of application types (for example, `vercel`, `github`). */
export type ListProjectsResponseApplicationsMap = {
    [key: string]: ListProjectsResponseApplicationsValueList | undefined;
};
export declare const ListProjectsResponseApplicationsMap: S.Schema<ListProjectsResponseApplicationsMap>;
export type ListProjectsResponseIntegrationsValueList = Array<ApplicationType>;
export declare const ListProjectsResponseIntegrationsValueList: S.Schema<ListProjectsResponseIntegrationsValueList>;
/** Map of project IDs to their associated integration details. */
export type ListProjectsResponseIntegrationsMap = {
    [key: string]: ListProjectsResponseIntegrationsValueList | undefined;
};
export declare const ListProjectsResponseIntegrationsMap: S.Schema<ListProjectsResponseIntegrationsMap>;
export interface ListProjectsResponse {
    /** List of projects accessible to the caller. Projects that exist but could not be retrieved are identified in `unavailable_project_ids`. */
    projects: ListProjectsResponseProjectsList;
    /** A list of project IDs indicating which projects are known to exist, but whose details could not be fetched within the requested (or implicit) time limit */
    unavailable_project_ids?: ListProjectsResponseUnavailableProjectIdsList;
    pagination?: Pagination;
    /** Map of project IDs to their installed applications. Each key is a project ID; each value is an array of application types (for example, `vercel`, `github`). */
    applications: ListProjectsResponseApplicationsMap;
    /** Map of project IDs to their associated integration details. */
    integrations: ListProjectsResponseIntegrationsMap;
}
export declare const ListProjectsResponse: S.Schema<ListProjectsResponse>;
export interface ListProjectVPCEndpointsRequest {
    /** The Neon project ID */
    project_id: string;
}
export declare const ListProjectVPCEndpointsRequest: S.Schema<ListProjectVPCEndpointsRequest>;
export interface ListSharedProjectsRequest {
    /** Specify the cursor value from the previous response to get the next batch of projects. */
    cursor?: string;
    /** Specify a value from 1 to 400 to limit number of projects in the response. */
    limit?: number;
    /** Search query by name or id. */
    search?: string;
    /** Specify an explicit timeout in milliseconds to limit response delay. After timing out, the incomplete list of project data fetched so far will be returned. Projects still being fetched when the timeout occurred are listed in the "unavailable" attribute of the response. If not specified, an implicit implementation defined timeout is chosen with the same behaviour as above */
    timeout?: number;
}
export declare const ListSharedProjectsRequest: S.Schema<ListSharedProjectsRequest>;
/** List of projects accessible to the caller. Projects that exist but could not be retrieved are identified in `unavailable_project_ids`. */
export type ListSharedProjectsResponseProjectsList = Array<ProjectListItem>;
export declare const ListSharedProjectsResponseProjectsList: S.Schema<ListSharedProjectsResponseProjectsList>;
/** A list of project IDs indicating which projects are known to exist, but whose details could not be fetched within the requested (or implicit) time limit */
export type ListSharedProjectsResponseUnavailableProjectIdsList = Array<string>;
export declare const ListSharedProjectsResponseUnavailableProjectIdsList: S.Schema<ListSharedProjectsResponseUnavailableProjectIdsList>;
export interface ListSharedProjectsResponse {
    /** List of projects accessible to the caller. Projects that exist but could not be retrieved are identified in `unavailable_project_ids`. */
    projects: ListSharedProjectsResponseProjectsList;
    /** A list of project IDs indicating which projects are known to exist, but whose details could not be fetched within the requested (or implicit) time limit */
    unavailable_project_ids?: ListSharedProjectsResponseUnavailableProjectIdsList;
    pagination?: Pagination;
}
export declare const ListSharedProjectsResponse: S.Schema<ListSharedProjectsResponse>;
export interface ListSnapshotsRequest {
    /** The Neon project ID */
    project_id: string;
}
export declare const ListSnapshotsRequest: S.Schema<ListSnapshotsRequest>;
export type ListSnapshotsResponseSnapshotsList = Array<Snapshot>;
export declare const ListSnapshotsResponseSnapshotsList: S.Schema<ListSnapshotsResponseSnapshotsList>;
export interface ListSnapshotsResponse {
    snapshots: ListSnapshotsResponseSnapshotsList;
}
export declare const ListSnapshotsResponse: S.Schema<ListSnapshotsResponse>;
/** The transfer direction. `upload` returns a presigned `PUT` URL; `download` returns a presigned `GET` URL. */
export type PresignProjectBranchBucketObjectRequestOperation = "upload" | "download";
export declare const PresignProjectBranchBucketObjectRequestOperation: any;
export interface PresignProjectBranchBucketObjectRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The bucket name */
    bucket_name: string;
    /** The object key. Keys may contain `/`; the `/` characters of nested keys must be percent-encoded (`%2F`) in the path segment. */
    object_key: string;
    /** The transfer direction. `upload` returns a presigned `PUT` URL; `download` returns a presigned `GET` URL. */
    operation: PresignProjectBranchBucketObjectRequestOperation | (string & {});
    /** The `Content-Type` to bind into the signed request. Only meaningful for `upload`: when set, the caller MUST send the same `Content-Type` header on the `PUT`, and the value is echoed back in the response `headers`. Ignored for `download`. */
    content_type?: string;
    /** How long the presigned URL stays valid, in seconds. Defaults to 900 (15 minutes); capped at 604800 (7 days). */
    expires_in_seconds?: number;
}
export declare const PresignProjectBranchBucketObjectRequest: S.Schema<PresignProjectBranchBucketObjectRequest>;
/** Headers the caller MUST send verbatim on the request (e.g. `Content-Type` when it was signed on an upload). May be empty. */
export type PresignResponseHeadersMap = {
    [key: string]: string | undefined;
};
export declare const PresignResponseHeadersMap: S.Schema<PresignResponseHeadersMap>;
export interface PresignResponse {
    /** The presigned URL. Transfer the object bytes by issuing `method url` with the returned `headers`. */
    url: string;
    /** The HTTP method to use against `url`: `PUT` for an upload, `GET` for a download. */
    method: string;
    /** Headers the caller MUST send verbatim on the request (e.g. `Content-Type` when it was signed on an upload). May be empty. */
    headers: PresignResponseHeadersMap;
    /** When the presigned URL stops being valid. */
    expires_at: string;
}
export declare const PresignResponse: S.Schema<PresignResponse>;
/** Order matching records by timestamp. `desc`, the default, returns the newest records first. */
export type QueryProjectBranchLogsRequestSortOrder = "asc" | "desc";
export declare const QueryProjectBranchLogsRequestSortOrder: any;
/** An OpenTelemetry severity level. A minimum severity includes every higher level in this order: `trace`, `debug`, `info`, `warn`, `error`, `fatal`. */
export type ProjectBranchLogSeverity = "trace" | "debug" | "info" | "warn" | "error" | "fatal";
export declare const ProjectBranchLogSeverity: any;
export interface QueryProjectBranchLogsRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** Length of the query window, ending at `end_time` or at the current time when `end_time` is omitted. Mutually exclusive with `start_time`. Prefer this over computing absolute bounds when the caller only means "the last hour". */
    since?: string;
    /** Inclusive beginning of the query window. Mutually exclusive with `since`. Defaults to one hour before `end_time`, or one hour before the current time when both bounds are omitted. */
    start_time?: string;
    /** Exclusive end of the query window. Defaults to the current time. */
    end_time?: string;
    /** Maximum number of log records to return per page. */
    limit?: number;
    /** Opaque pagination cursor returned as `next_cursor` by a previous call. Resume the query after the last record of the previous page, repeating the time range and every filter unchanged. */
    cursor?: string;
    /** Order matching records by timestamp. `desc`, the default, returns the newest records first. */
    sort_order?: QueryProjectBranchLogsRequestSortOrder | (string & {});
    source?: ProjectBranchLogSource | (string & {});
    /** Match the OpenTelemetry `service.name` resource attribute exactly. */
    service_name?: string;
    /** Match the OpenTelemetry instrumentation scope name exactly. */
    scope_name?: string;
    minimum_severity?: ProjectBranchLogSeverity | (string & {});
    /** Match the OpenTelemetry severity text exactly. */
    severity_text?: string;
    /** Match records whose rendered `message` contains this case-sensitive substring. Records with a structured body are matched against their JSON rendering, so the substring meets JSON syntax rather than prose: a bare key name such as `operation` matches every record carrying that key, and `http_status: 200` matches none, because the rendering contains `"http_status":200` with no space. */
    body_contains?: string;
    /** Match records associated with this OpenTelemetry trace ID. W3C Trace Context defines a trace ID as 32 lowercase hex digits, and that is what is stored, so an uppercase value is rejected rather than silently matching nothing. */
    trace_id?: string;
    /** Escape hatch for selections the structured filters cannot express: a raw LogQL expression, evaluated against this branch's log stream. Only stream selectors and line filters are accepted — no aggregations and no parser stages. Supplying this alongside any structured filter is rejected with `conflicting_filters` rather than silently ignoring one of them. `limit`, `sort_order`, and the time window still apply. This field passes the underlying query language through to the caller, so unlike the rest of this contract it may change as that backend changes. Prefer the structured filters where they suffice. */
    logql?: string;
}
export declare const QueryProjectBranchLogsRequest: S.Schema<QueryProjectBranchLogsRequest>;
/** Customer-defined OpenTelemetry log and resource attributes. */
export type ProjectBranchLogRecordAttributesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectBranchLogRecordAttributesMap: S.Schema<ProjectBranchLogRecordAttributesMap>;
export interface ProjectBranchLogRecord {
    /** The OpenTelemetry record timestamp in UTC. */
    timestamp: string;
    /** The OpenTelemetry log body rendered as text. A body that is already a string is returned verbatim. Any other OpenTelemetry `AnyValue` body — notably the structured key/value body that `storage` records always carry — is rendered as compact JSON with its keys sorted alphabetically, for example `{"bytes":1024,"operation":"GET","object_key":"a/b.png"}`. */
    message: string;
    source?: ProjectBranchLogSource;
    /** The Neon identifier of the service instance that emitted the record. */
    entity_id?: string;
    /** The OpenTelemetry `service.name` resource attribute. */
    service_name?: string;
    /** The OpenTelemetry instrumentation scope name. */
    scope_name?: string;
    /** The numeric OpenTelemetry severity. */
    severity_number?: number;
    /** The original OpenTelemetry severity text. */
    severity_text?: string;
    /** The OpenTelemetry trace ID, when the record belongs to a trace. */
    trace_id?: string;
    /** The OpenTelemetry span ID, when the record belongs to a span. */
    span_id?: string;
    /** Customer-defined OpenTelemetry log and resource attributes. */
    attributes: ProjectBranchLogRecordAttributesMap;
}
export declare const ProjectBranchLogRecord: S.Schema<ProjectBranchLogRecord>;
export type ProjectBranchLogsQueryResponseLogsList = Array<ProjectBranchLogRecord>;
export declare const ProjectBranchLogsQueryResponseLogsList: S.Schema<ProjectBranchLogsQueryResponseLogsList>;
export interface ProjectBranchLogsQueryResponse {
    logs: ProjectBranchLogsQueryResponseLogsList;
    /** Pagination cursor to pass as `cursor` on the next request. Empty when the response is not truncated. */
    next_cursor?: string;
    /** True when more records matched than were returned. */
    is_truncated: boolean;
}
export declare const ProjectBranchLogsQueryResponse: S.Schema<ProjectBranchLogsQueryResponse>;
export interface RecoverProjectRequest {
    /** The Neon project ID */
    project_id: string;
}
export declare const RecoverProjectRequest: S.Schema<RecoverProjectRequest>;
/** Branches in the project. Each includes `id`, `name`, `current_state`, and `created_at`. */
export type RecoverProjectResponseBranchesList = Array<Branch>;
export declare const RecoverProjectResponseBranchesList: S.Schema<RecoverProjectResponseBranchesList>;
export interface RecoverProjectResponse {
    /** Full details of the project, including configuration, consumption metrics, and ownership. */
    project: Project;
    /** Branches in the project. Each includes `id`, `name`, `current_state`, and `created_at`. */
    branches: RecoverProjectResponseBranchesList;
}
export declare const RecoverProjectResponse: S.Schema<RecoverProjectResponse>;
export interface RegisterProjectBranchCustomDomainRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The custom domain to register (for example `dashboard.acme.com`). Case-insensitive; normalized to lowercase (a trailing root dot is stripped, so the 254-char bound admits a fully-qualified name whose normalized form is 253 chars). Neon-managed and internal hostnames are rejected. */
    domain: string;
    /** The kind of branch entity to point the domain at. v1 supports only `function`; any other value is rejected with `invalid_entity_type`. */
    entity_type: string;
    /** The target entity's identifier within the branch. For `function` this is the function slug (which must already exist on the branch). */
    entity_id: string;
}
export declare const RegisterProjectBranchCustomDomainRequest: S.Schema<RegisterProjectBranchCustomDomainRequest>;
export interface RemoveOrganizationMemberRequest {
    /** The Neon organization ID */
    org_id: string;
    /** The Neon organization member ID */
    member_id: string;
}
export declare const RemoveOrganizationMemberRequest: S.Schema<RemoveOrganizationMemberRequest>;
export type RemoveOrganizationMemberResponse = unknown;
export declare const RemoveOrganizationMemberResponse: S.Schema<RemoveOrganizationMemberResponse>;
export interface RemoveProjectMemberRoleRequest {
    project_id: string;
    member_id: string;
    confirm_self_lockout?: boolean;
}
export declare const RemoveProjectMemberRoleRequest: S.Schema<RemoveProjectMemberRoleRequest>;
export interface ProjectMemberRoleResponse {
    project_id: string;
    member_id: string;
    user_id: string;
    /** Email address of the user who has been granted access to the project. */
    email?: string;
    /** The user's display name. */
    name?: string;
    org_role: ProjectMemberOrgRole;
    /** The resulting effective project role after applying org-admin default access, explicit grants, and creator fallback. Null only when the member has no remaining effective project access. */
    project_role?: ProjectRole;
    org_default_project_permission?: ProjectPermissionLevel;
    explicit_project_permission?: ProjectPermissionLevel;
    effective_project_permission?: ProjectPermissionLevel;
    /** Hint that database credentials may need rotation after the role change. */
    credential_rotation_recommended?: boolean;
    /** Hint that project-scoped org API keys created by the target user may need rotation. */
    org_api_key_rotation_recommended?: boolean;
}
export declare const ProjectMemberRoleResponse: S.Schema<ProjectMemberRoleResponse>;
export interface ResetProjectBranchRolePasswordRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** The role name */
    role_name: string;
}
export declare const ResetProjectBranchRolePasswordRequest: S.Schema<ResetProjectBranchRolePasswordRequest>;
export type ResetProjectBranchRolePasswordResponseOperationsList = Array<Operation>;
export declare const ResetProjectBranchRolePasswordResponseOperationsList: S.Schema<ResetProjectBranchRolePasswordResponseOperationsList>;
export interface ResetProjectBranchRolePasswordResponse {
    /** Role details for the requested database role. The `password` field is included in the response when a role is created or its password is reset, and is not returned in subsequent read requests. Store it securely at that time. */
    role: Role;
    operations: ResetProjectBranchRolePasswordResponseOperationsList;
}
export declare const ResetProjectBranchRolePasswordResponse: S.Schema<ResetProjectBranchRolePasswordResponse>;
export interface RestartProjectEndpointRequest {
    /** The Neon project ID */
    project_id: string;
    /** The endpoint ID */
    endpoint_id: string;
}
export declare const RestartProjectEndpointRequest: S.Schema<RestartProjectEndpointRequest>;
export type RestartProjectEndpointResponseOperationsList = Array<Operation>;
export declare const RestartProjectEndpointResponseOperationsList: S.Schema<RestartProjectEndpointResponseOperationsList>;
export interface RestartProjectEndpointResponse {
    /** Compute endpoint created or retrieved, including its current lifecycle state. */
    endpoint: Endpoint;
    operations: RestartProjectEndpointResponseOperationsList;
}
export declare const RestartProjectEndpointResponse: S.Schema<RestartProjectEndpointResponse>;
export interface RestoreProjectBranchRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** The `branch_id` of the restore source branch. If `source_timestamp` and `source_lsn` are omitted, the branch will be restored to head. If `source_branch_id` is equal to the branch's id, `source_timestamp` or `source_lsn` is required. */
    source_branch_id: string;
    /** A Postgres LSN (for example, `0/1A2B3C4`) on the source branch to restore from. Mutually exclusive with `source_timestamp`. Omit both to restore to head. */
    source_lsn?: string;
    /** A point in time on the source branch to restore from, in RFC 3339 format. When omitted alongside `source_lsn`, the branch is restored to the latest available state of the source branch. */
    source_timestamp?: string;
    /** Name under which to save the current branch state before restoring. Required when the branch has children or when `source_branch_id` equals the branch being restored; in those cases all existing child branches are moved to the newly created branch. If omitted and not required, the previous state is not preserved. */
    preserve_under_name?: string;
}
export declare const RestoreProjectBranchRequest: S.Schema<RestoreProjectBranchRequest>;
export type RestoreProjectBranchResponseOperationsList = Array<Operation>;
export declare const RestoreProjectBranchResponseOperationsList: S.Schema<RestoreProjectBranchResponseOperationsList>;
export interface RestoreProjectBranchResponse {
    /** Branch returned by the request. */
    branch: Branch;
    operations: RestoreProjectBranchResponseOperationsList;
}
export declare const RestoreProjectBranchResponse: S.Schema<RestoreProjectBranchResponse>;
export interface RestoreSnapshotRequest {
    /** The Neon project ID */
    project_id: string;
    /** The snapshot ID */
    snapshot_id: string;
    /** Deprecated. Use the `name` field in the request body instead. Removal scheduled for November 29, 2025. A name for the newly restored branch. If omitted, a default name will be generated. */
    name?: string;
    /** ID of the branch to restore the snapshot into. Defaults to the snapshot's source branch (`snapshot.source_branch_id`); fails if that cannot be determined. */
    target_branch_id?: string;
    /** Set to `true` to finalize the restore operation immediately. This will complete the restore and move any associated computes to the new branch, similar to the `finalizeRestoreBranch` operation. Defaults to `false` to allow previewing the restored snapshot data first. */
    finalize_restore?: boolean;
}
export declare const RestoreSnapshotRequest: S.Schema<RestoreSnapshotRequest>;
/** Compute endpoints associated with the project. */
export type RestoreSnapshotResponseEndpointsList = Array<Endpoint>;
export declare const RestoreSnapshotResponseEndpointsList: S.Schema<RestoreSnapshotResponseEndpointsList>;
export type RestoreSnapshotResponseOperationsList = Array<Operation>;
export declare const RestoreSnapshotResponseOperationsList: S.Schema<RestoreSnapshotResponseOperationsList>;
export interface RestoreSnapshotResponse {
    /** Branch returned by the request. */
    branch: Branch;
    /** Compute endpoints associated with the project. */
    endpoints?: RestoreSnapshotResponseEndpointsList;
    operations: RestoreSnapshotResponseOperationsList;
}
export declare const RestoreSnapshotResponse: S.Schema<RestoreSnapshotResponse>;
export interface RevealCredentialRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The opaque credential id (e.g. nak_live_<32hex>). */
    token_id: string;
}
export declare const RevealCredentialRequest: S.Schema<RevealCredentialRequest>;
/** The live secrets of an existing credential, recovered on demand by the reveal endpoint. `api_token` and `s3_secret_access_key` are the same values handed back once at issuance. The field set is deliberately narrower than `CreateCredentialResponse`: it carries only what reveal can actually recover. `token_id_short`, `scopes`, `principal_type`, `created_at` and `expires_at` are metadata, not secrets — read them from the list endpoint instead. No `branch_id` is returned. Reveal is scoped by `(project_id, token_id)`, so the branch in the request path authorizes the call but is not proven to be the branch the credential was issued on. Echoing it back would assert an anchor this endpoint never verified. For a credential's true anchor branch, read `branch_id` from the list endpoint, which is branch-exact. */
export interface CredentialSecret {
    /** Opaque credential id (e.g. nak_live_<32hex>). */
    token_id: string;
    /** Bearer token. */
    api_token: string | Redacted.Redacted<string>;
    /** nsk_live_<64 hex>; the AWS_SECRET_ACCESS_KEY. */
    s3_secret_access_key: string;
}
export declare const CredentialSecret: S.Schema<CredentialSecret>;
export interface RevokeApiKeyRequest {
    /** The API key ID */
    key_id: number;
}
export declare const RevokeApiKeyRequest: S.Schema<RevokeApiKeyRequest>;
export interface ApiKeyRevokeResponse {
    /** The API key's unique numeric ID. Distinct from the API key token (`key`). */
    id: number;
    /** The user-specified API key name */
    name: string;
    /** A timestamp indicating when the API key was created */
    created_at: string;
    /** ID of the user who created this API key */
    created_by: string;
    /** A timestamp indicating when the API was last used */
    last_used_at?: string | null;
    /** The IP address from which the API key was last used */
    last_used_from_addr: string;
    /** A `true` or `false` value indicating whether the API key is revoked */
    revoked: boolean;
}
export declare const ApiKeyRevokeResponse: S.Schema<ApiKeyRevokeResponse>;
export interface RevokeCredentialRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The opaque credential id (e.g. nak_live_<32hex>). */
    token_id: string;
}
export declare const RevokeCredentialRequest: S.Schema<RevokeCredentialRequest>;
export interface RevokeCredentialResponse {
}
export declare const RevokeCredentialResponse: S.Schema<RevokeCredentialResponse>;
export interface RevokeOrgApiKeyRequest {
    /** The Neon organization ID */
    org_id: string;
    /** The API key ID */
    key_id: number;
}
export declare const RevokeOrgApiKeyRequest: S.Schema<RevokeOrgApiKeyRequest>;
export interface RevokeOrgApiKeyResponse {
    /** The API key's unique numeric ID. Distinct from the API key token (`key`). */
    id: number;
    /** The user-specified API key name */
    name: string;
    /** A timestamp indicating when the API key was created */
    created_at: string;
    /** ID of the user who created this API key */
    created_by: string;
    /** A timestamp indicating when the API was last used */
    last_used_at?: string | null;
    /** The IP address from which the API key was last used */
    last_used_from_addr: string;
    /** A `true` or `false` value indicating whether the API key is revoked */
    revoked: boolean;
    /** If set, the API key can access only this project */
    project_id?: string;
}
export declare const RevokeOrgApiKeyResponse: S.Schema<RevokeOrgApiKeyResponse>;
export interface RevokePermissionFromProjectRequest {
    project_id: string;
    permission_id: string;
}
export declare const RevokePermissionFromProjectRequest: S.Schema<RevokePermissionFromProjectRequest>;
export interface RotateCredentialRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The opaque credential id (e.g. nak_live_<32hex>). */
    token_id: string;
}
export declare const RotateCredentialRequest: S.Schema<RotateCredentialRequest>;
export type RotateCredentialResponseScopesList = Array<GrantedCredentialScope>;
export declare const RotateCredentialResponseScopesList: S.Schema<RotateCredentialResponseScopesList>;
/** Always `user`: only customer-managed credentials are rotatable through this endpoint. */
export type RotateCredentialResponsePrincipalType = "user";
export declare const RotateCredentialResponsePrincipalType: any;
/** The replacement secret material for an existing credential, returned exactly once. `token_id`, `scopes`, `branch_id` and `created_at` are unchanged by the rotation — only `api_token` and `s3_secret_access_key` are new. */
export interface RotateCredentialResponse {
    /** Opaque credential id (e.g. nak_live_<32hex>), unchanged by the rotation. Doubles as the `AWS_ACCESS_KEY_ID` for SigV4. */
    token_id: string;
    /** First 12 hex chars of token_id; safe to log. */
    token_id_short: string;
    /** Customer-supplied label carried on the credential. Absent when none was set at issuance. */
    name?: string;
    /** The new Bearer token; returned exactly once. */
    api_token: string | Redacted.Redacted<string>;
    /** The new nsk_live_<64 hex> AWS_SECRET_ACCESS_KEY; returned exactly once. */
    s3_secret_access_key: string;
    scopes: RotateCredentialResponseScopesList;
    branch_id: string;
    /** Always `user`: only customer-managed credentials are rotatable through this endpoint. */
    principal_type: RotateCredentialResponsePrincipalType;
    /** When the credential was originally issued. Rotation replaces the secrets in place and does not reset this. */
    created_at: string;
    /** When the credential expires; absent means never expires. Rotation does not extend it. */
    expires_at?: string;
}
export declare const RotateCredentialResponse: S.Schema<RotateCredentialResponse>;
export interface SendNeonAuthEmailProviderTestRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The email address to send the test email to. */
    recipient_email: string;
}
export declare const SendNeonAuthEmailProviderTestRequest: S.Schema<SendNeonAuthEmailProviderTestRequest>;
export interface SendNeonAuthTestEmailResponse {
    /** Whether the test email was sent successfully. */
    success: boolean;
    /** The error message from the email server. */
    error_message?: string;
}
export declare const SendNeonAuthTestEmailResponse: S.Schema<SendNeonAuthTestEmailResponse>;
export interface SetDefaultProjectBranchRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
}
export declare const SetDefaultProjectBranchRequest: S.Schema<SetDefaultProjectBranchRequest>;
export type SetDefaultProjectBranchResponseOperationsList = Array<Operation>;
export declare const SetDefaultProjectBranchResponseOperationsList: S.Schema<SetDefaultProjectBranchResponseOperationsList>;
export interface SetDefaultProjectBranchResponse {
    /** Branch returned by the request. */
    branch: Branch;
    operations: SetDefaultProjectBranchResponseOperationsList;
}
export declare const SetDefaultProjectBranchResponse: S.Schema<SetDefaultProjectBranchResponse>;
export interface SetOrganizationSpendingLimitRequest {
    /** The Neon organization ID */
    org_id: string;
    /** Monthly spending cap in cents. Must be positive. To remove a previously configured limit, send a DELETE request to the spending_limit endpoint — `0` and `null` are rejected here. The cap is alert-only: notifications fire at 80% and 100%, but computes are not suspended. Setting a cap below the period's already-accrued spend is permitted and will trigger the over-limit notification on the next worker run. */
    spending_limit_cents: number;
}
export declare const SetOrganizationSpendingLimitRequest: S.Schema<SetOrganizationSpendingLimitRequest>;
export interface SetProjectMemberRoleRequest {
    project_id: string;
    member_id: string;
    confirm_self_demotion?: boolean;
    role: ProjectRole | (string & {});
}
export declare const SetProjectMemberRoleRequest: S.Schema<SetProjectMemberRoleRequest>;
/** List of schedule entries defining the backup frequency. At least one entry is required. */
export type SetSnapshotScheduleRequestScheduleList = Array<BackupScheduleItem>;
export declare const SetSnapshotScheduleRequestScheduleList: S.Schema<SetSnapshotScheduleRequestScheduleList>;
export interface SetSnapshotScheduleRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** List of schedule entries defining the backup frequency. At least one entry is required. */
    schedule: SetSnapshotScheduleRequestScheduleList;
}
export declare const SetSnapshotScheduleRequest: S.Schema<SetSnapshotScheduleRequest>;
export type SetSnapshotScheduleResponse = unknown;
export declare const SetSnapshotScheduleResponse: S.Schema<SetSnapshotScheduleResponse>;
export interface StartAnonymizationRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
}
export declare const StartAnonymizationRequest: S.Schema<StartAnonymizationRequest>;
export interface StartProjectEndpointRequest {
    /** The Neon project ID */
    project_id: string;
    /** The endpoint ID */
    endpoint_id: string;
}
export declare const StartProjectEndpointRequest: S.Schema<StartProjectEndpointRequest>;
export type StartProjectEndpointResponseOperationsList = Array<Operation>;
export declare const StartProjectEndpointResponseOperationsList: S.Schema<StartProjectEndpointResponseOperationsList>;
export interface StartProjectEndpointResponse {
    /** Compute endpoint created or retrieved, including its current lifecycle state. */
    endpoint: Endpoint;
    operations: StartProjectEndpointResponseOperationsList;
}
export declare const StartProjectEndpointResponse: S.Schema<StartProjectEndpointResponse>;
export interface SuspendProjectEndpointRequest {
    /** The Neon project ID */
    project_id: string;
    /** The endpoint ID */
    endpoint_id: string;
}
export declare const SuspendProjectEndpointRequest: S.Schema<SuspendProjectEndpointRequest>;
export type SuspendProjectEndpointResponseOperationsList = Array<Operation>;
export declare const SuspendProjectEndpointResponseOperationsList: S.Schema<SuspendProjectEndpointResponseOperationsList>;
export interface SuspendProjectEndpointResponse {
    /** Compute endpoint created or retrieved, including its current lifecycle state. */
    endpoint: Endpoint;
    operations: SuspendProjectEndpointResponseOperationsList;
}
export declare const SuspendProjectEndpointResponse: S.Schema<SuspendProjectEndpointResponse>;
export interface TransferNeonAuthProviderProjectRequest {
    /** The Neon project ID. Returned as `id` from `GET /projects`. */
    project_id: string;
    auth_provider: NeonAuthSupportedAuthProvider | (string & {});
}
export declare const TransferNeonAuthProviderProjectRequest: S.Schema<TransferNeonAuthProviderProjectRequest>;
export interface NeonAuthTransferAuthProviderProjectResponse {
    /** URL for completing the process of ownership transfer */
    url: string;
}
export declare const NeonAuthTransferAuthProviderProjectResponse: S.Schema<NeonAuthTransferAuthProviderProjectResponse>;
/** The list of projects ids to transfer. Maximum of 400 project ids */
export type TransferProjectsFromOrgToOrgRequestProjectIdsList = Array<string>;
export declare const TransferProjectsFromOrgToOrgRequestProjectIdsList: S.Schema<TransferProjectsFromOrgToOrgRequestProjectIdsList>;
export interface TransferProjectsFromOrgToOrgRequest {
    /** The Neon organization ID (source org, which currently owns the project) */
    source_org_id: string;
    /** The destination organization identifier */
    destination_org_id: string;
    /** The list of projects ids to transfer. Maximum of 400 project ids */
    project_ids: TransferProjectsFromOrgToOrgRequestProjectIdsList;
}
export declare const TransferProjectsFromOrgToOrgRequest: S.Schema<TransferProjectsFromOrgToOrgRequest>;
export type TransferProjectsFromOrgToOrgResponse = unknown;
export declare const TransferProjectsFromOrgToOrgResponse: S.Schema<TransferProjectsFromOrgToOrgResponse>;
export type UpdateBranchNeonAuthOauthProviderRequestOauthProviderId = "google" | "github" | "microsoft" | "vercel";
export declare const UpdateBranchNeonAuthOauthProviderRequestOauthProviderId: any;
export interface UpdateBranchNeonAuthOauthProviderRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The OAuth provider ID */
    oauth_provider_id: UpdateBranchNeonAuthOauthProviderRequestOauthProviderId | (string & {});
    /** The OAuth client ID registered with the provider. Omit to keep the currently configured value. */
    client_id?: string;
    /** OAuth client secret for the provider. Omit to leave the existing secret unchanged. */
    client_secret?: string | Redacted.Redacted<string>;
    /** The tenant ID scoping the Microsoft OAuth provider. Supply this field when the provider type is microsoft; it has no effect for other provider types. */
    microsoft_tenant_id?: string;
}
export declare const UpdateBranchNeonAuthOauthProviderRequest: S.Schema<UpdateBranchNeonAuthOauthProviderRequest>;
/** List of masking rules to apply to the branch. This will replace all existing masking rules for the branch. */
export type UpdateMaskingRulesRequestMaskingRulesList = Array<MaskingRule>;
export declare const UpdateMaskingRulesRequestMaskingRulesList: S.Schema<UpdateMaskingRulesRequestMaskingRulesList>;
export interface UpdateMaskingRulesRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** List of masking rules to apply to the branch. This will replace all existing masking rules for the branch. */
    masking_rules: UpdateMaskingRulesRequestMaskingRulesList;
}
export declare const UpdateMaskingRulesRequest: S.Schema<UpdateMaskingRulesRequest>;
export interface UpdateNeonAuthAllowLocalhostRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** Whether to allow localhost connections */
    allow_localhost: boolean;
}
export declare const UpdateNeonAuthAllowLocalhostRequest: S.Schema<UpdateNeonAuthAllowLocalhostRequest>;
export interface UpdateNeonAuthConfigRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The application name used in auth emails and communications. */
    name: string;
}
export declare const UpdateNeonAuthConfigRequest: S.Schema<UpdateNeonAuthConfigRequest>;
export interface NeonAuthConfigResponse {
    /** The application name used in auth emails and communications. */
    name: string;
}
export declare const NeonAuthConfigResponse: S.Schema<NeonAuthConfigResponse>;
export interface UpdateNeonAuthEmailAndPasswordConfigRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** Controls whether email and password authentication is enabled for this project. When omitted from an update request, the current value is unchanged. */
    enabled?: boolean;
    /** Email verification method. `link`: sends a verification link. `otp`: sends a one-time password. */
    email_verification_method?: NeonAuthEmailVerificationMethod | (string & {});
    /** When true, users must verify their email address before they can sign in. Omitting this field from an update request leaves the current value unchanged. */
    require_email_verification?: boolean;
    /** Whether users are automatically signed in after verifying their email */
    auto_sign_in_after_verification?: boolean;
    /** Whether to send a verification email when users sign up. */
    send_verification_email_on_sign_up?: boolean;
    /** Whether to send a verification email when a user with an unverified email signs in. */
    send_verification_email_on_sign_in?: boolean;
    /** Whether to disable new user sign ups. When omitted, the current setting is not changed. */
    disable_sign_up?: boolean;
}
export declare const UpdateNeonAuthEmailAndPasswordConfigRequest: S.Schema<UpdateNeonAuthEmailAndPasswordConfigRequest>;
export interface StandardEmailServer {
    /** Hostname of the email server. */
    host?: string;
    /** TCP port of the SMTP server. Common values: 25 (SMTP), 465 (SMTPS), 587 (submission). */
    port?: number;
    /** Username for authenticating with the SMTP server. */
    username?: string;
    /** Password for authenticating with the SMTP server. */
    password?: string | Redacted.Redacted<string>;
    /** Email address used as the From address on outgoing auth emails. */
    sender_email?: string;
    /** Display name shown as the sender in outgoing emails. */
    sender_name?: string;
}
export declare const StandardEmailServer: S.Schema<StandardEmailServer>;
export type NeonAuthEmailServerConfig = StandardEmailServer | SharedEmailServer;
export declare const NeonAuthEmailServerConfig: S.Schema<NeonAuthEmailServerConfig>;
export interface UpdateNeonAuthEmailProviderRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    body: NeonAuthEmailServerConfig;
}
export declare const UpdateNeonAuthEmailProviderRequest: S.Schema<UpdateNeonAuthEmailProviderRequest>;
export type UpdateNeonAuthEmailProviderResponse = NeonAuthEmailServerConfigResponse;
export declare const UpdateNeonAuthEmailProviderResponse: S.Schema<UpdateNeonAuthEmailProviderResponse>;
export interface UpdateNeonAuthMagicLinkPluginRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** Whether to enable the magic link plugin. */
    enabled?: boolean;
    /** Minutes until the magic link expires. */
    expires_in?: number;
    /** When true, sign-up via magic link is disabled. */
    disable_sign_up?: boolean;
}
export declare const UpdateNeonAuthMagicLinkPluginRequest: S.Schema<UpdateNeonAuthMagicLinkPluginRequest>;
/** Role of the organization's creator. `owner`: full control, including deleting the org and transferring ownership. `admin`: manage members and settings only. */
export type UpdateNeonAuthOrganizationPluginRequestCreatorRole = "admin" | "owner";
export declare const UpdateNeonAuthOrganizationPluginRequestCreatorRole: any;
export interface UpdateNeonAuthOrganizationPluginRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** Controls whether the organization plugin is active for the organization. */
    enabled?: boolean;
    /** Maximum organizations a user can belong to (created or joined). At the limit, the user cannot create or join more. */
    organization_limit?: number;
    /** Maximum members per organization. */
    membership_limit?: number;
    /** Role of the organization's creator. `owner`: full control, including deleting the org and transferring ownership. `admin`: manage members and settings only. */
    creator_role?: UpdateNeonAuthOrganizationPluginRequestCreatorRole | (string & {});
    /** When true, invited users receive an email containing an accept link. Requires that the invited user has a verified email address. */
    send_invitation_email?: boolean;
}
export declare const UpdateNeonAuthOrganizationPluginRequest: S.Schema<UpdateNeonAuthOrganizationPluginRequest>;
export interface UpdateNeonAuthPhoneNumberPluginRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** Whether the phone number plugin is enabled. */
    enabled?: boolean;
    /** Time in seconds before the OTP expires */
    otp_expires_in?: number;
}
export declare const UpdateNeonAuthPhoneNumberPluginRequest: S.Schema<UpdateNeonAuthPhoneNumberPluginRequest>;
/** Roles to assign to the user in the Neon Auth (Better Auth) directory. `user` and `admin` are the built-in roles; custom role strings are also supported. */
export type UpdateNeonAuthUserRoleRequestRolesList = Array<string>;
export declare const UpdateNeonAuthUserRoleRequestRolesList: S.Schema<UpdateNeonAuthUserRoleRequestRolesList>;
export interface UpdateNeonAuthUserRoleRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The Neon user ID */
    auth_user_id: string;
    /** Roles to assign to the user in the Neon Auth (Better Auth) directory. `user` and `admin` are the built-in roles; custom role strings are also supported. */
    roles: UpdateNeonAuthUserRoleRequestRolesList;
}
export declare const UpdateNeonAuthUserRoleRequest: S.Schema<UpdateNeonAuthUserRoleRequest>;
export interface UpdateNeonAuthUserRoleResponse {
    /** ID of the updated user */
    id: string;
}
export declare const UpdateNeonAuthUserRoleResponse: S.Schema<UpdateNeonAuthUserRoleResponse>;
export type UpdateNeonAuthWebhookConfigRequestEnabledEventsItem = "user.before_create" | "user.created" | "send.otp" | "send.magic_link" | "organization.invitation.created" | "organization.invitation.accepted" | "phone_number.verified";
export declare const UpdateNeonAuthWebhookConfigRequestEnabledEventsItem: any;
/** Event types that trigger this webhook. Covers user lifecycle, email/OTP delivery, organization invitations, and phone verification events; see the enum for exact values. */
export type UpdateNeonAuthWebhookConfigRequestEnabledEventsList = Array<UpdateNeonAuthWebhookConfigRequestEnabledEventsItem | (string & {})>;
export declare const UpdateNeonAuthWebhookConfigRequestEnabledEventsList: S.Schema<UpdateNeonAuthWebhookConfigRequestEnabledEventsList>;
export interface UpdateNeonAuthWebhookConfigRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** Whether the webhook is active. */
    enabled: boolean;
    /** Destination URL that receives webhook event payloads. */
    webhook_url?: string;
    /** Event types that trigger this webhook. Covers user lifecycle, email/OTP delivery, organization invitations, and phone verification events; see the enum for exact values. */
    enabled_events?: UpdateNeonAuthWebhookConfigRequestEnabledEventsList;
    /** Maximum time, in seconds, to wait for a response from the webhook endpoint. */
    timeout_seconds?: number;
}
export declare const UpdateNeonAuthWebhookConfigRequest: S.Schema<UpdateNeonAuthWebhookConfigRequest>;
export interface UpdateOrganizationMemberRequest {
    /** The Neon organization ID */
    org_id: string;
    /** The Neon organization member ID */
    member_id: string;
    role: MemberRole | (string & {});
}
export declare const UpdateOrganizationMemberRequest: S.Schema<UpdateOrganizationMemberRequest>;
export interface UpdateProjectRequestProject {
    /** Project-level settings, for example `quota`, `allowed_ips`, `enable_logical_replication`, and `maintenance_window`. */
    settings?: ProjectSettingsData;
    /** The project name */
    name?: string;
    default_endpoint_settings?: DefaultEndpointSettings;
    /** History window (point-in-time restore range) for all branches, in seconds. `0` disables it. Default 1 day (Free: 6 hours). Maximum depends on plan: Free 6 hours (21600), Launch 7 days (604800), Scale 30 days (2592000). */
    history_retention_seconds?: number;
}
export declare const UpdateProjectRequestProject: S.Schema<UpdateProjectRequestProject>;
export interface UpdateProjectRequest {
    /** The Neon project ID */
    project_id: string;
    project: UpdateProjectRequestProject;
}
export declare const UpdateProjectRequest: S.Schema<UpdateProjectRequest>;
export type UpdateProjectResponseOperationsList = Array<Operation>;
export declare const UpdateProjectResponseOperationsList: S.Schema<UpdateProjectResponseOperationsList>;
export interface UpdateProjectResponse {
    /** Full details of the project, including configuration, consumption metrics, and ownership. */
    project: Project;
    operations: UpdateProjectResponseOperationsList;
}
export declare const UpdateProjectResponse: S.Schema<UpdateProjectResponse>;
/** Branch attributes to update. Supply only the fields you want to change, for example `name` or `protected`. */
export interface UpdateProjectBranchRequestBranch {
    /** New display name for the branch. */
    name?: string;
    /** Whether the branch is protected. Protected branches (and their computes) cannot be deleted, archived, or reset, and block deletion of the project. Can be gated by `protected_branches_only` in the IP allowlist. Paid plans only. */
    protected?: boolean;
    /** The timestamp when the branch is scheduled to expire and be automatically deleted. Must be set by the client following the [RFC 3339, section 5.6](https://tools.ietf.org/html/rfc3339#section-5.6) format with precision up to seconds (such as 2025-06-09T18:02:16Z). Deletion is performed by a background job and may not occur exactly at the specified time. If this field is set to null, the expiration timestamp is removed. Access to this feature is currently limited to participants in the Early Access Program. */
    expires_at?: string | null;
}
export declare const UpdateProjectBranchRequestBranch: S.Schema<UpdateProjectBranchRequestBranch>;
export interface UpdateProjectBranchRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** Branch attributes to update. Supply only the fields you want to change, for example `name` or `protected`. */
    branch: UpdateProjectBranchRequestBranch;
}
export declare const UpdateProjectBranchRequest: S.Schema<UpdateProjectBranchRequest>;
export type UpdateProjectBranchResponseOperationsList = Array<Operation>;
export declare const UpdateProjectBranchResponseOperationsList: S.Schema<UpdateProjectBranchResponseOperationsList>;
export interface UpdateProjectBranchResponse {
    /** Branch returned by the request. */
    branch: Branch;
    operations: UpdateProjectBranchResponseOperationsList;
}
export declare const UpdateProjectBranchResponse: S.Schema<UpdateProjectBranchResponse>;
export interface UpdateProjectBranchDataAPIRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The database name */
    database_name: string;
    /** Configuration settings for the Neon Data API. */
    settings?: DataAPISettings;
}
export declare const UpdateProjectBranchDataAPIRequest: S.Schema<UpdateProjectBranchDataAPIRequest>;
export type UpdateProjectBranchDataAPIResponse = unknown;
export declare const UpdateProjectBranchDataAPIResponse: S.Schema<UpdateProjectBranchDataAPIResponse>;
/** Properties to update on the database. */
export interface UpdateProjectBranchDatabaseRequestDatabase {
    /** Name of the database to update. */
    name?: string;
    /** The name of the role that owns the database */
    owner_name?: string;
}
export declare const UpdateProjectBranchDatabaseRequestDatabase: S.Schema<UpdateProjectBranchDatabaseRequestDatabase>;
export interface UpdateProjectBranchDatabaseRequest {
    /** The Neon project ID */
    project_id: string;
    /** The branch ID */
    branch_id: string;
    /** The database name */
    database_name: string;
    /** Properties to update on the database. */
    database: UpdateProjectBranchDatabaseRequestDatabase;
}
export declare const UpdateProjectBranchDatabaseRequest: S.Schema<UpdateProjectBranchDatabaseRequest>;
export type UpdateProjectBranchDatabaseResponseOperationsList = Array<Operation>;
export declare const UpdateProjectBranchDatabaseResponseOperationsList: S.Schema<UpdateProjectBranchDatabaseResponseOperationsList>;
export interface UpdateProjectBranchDatabaseResponse {
    /** Database object returned by the operation. */
    database: Database;
    operations: UpdateProjectBranchDatabaseResponseOperationsList;
}
export declare const UpdateProjectBranchDatabaseResponse: S.Schema<UpdateProjectBranchDatabaseResponse>;
export interface UpdateProjectBranchFunctionRequest {
    /** The Neon project ID */
    project_id: string;
    /** The Neon branch ID */
    branch_id: string;
    /** The function slug */
    slug: string;
    /** New display name for the function. `null` clears the display name; the function's `name` then falls back to its slug. Leading and trailing whitespace is trimmed; a whitespace-only name is rejected. */
    name: string | null;
}
export declare const UpdateProjectBranchFunctionRequest: S.Schema<UpdateProjectBranchFunctionRequest>;
/** Parameters for the compute endpoint update. */
export interface UpdateProjectEndpointRequestEndpoint {
    /** Deprecated. The destination branch ID; must not have an existing read-write endpoint. */
    branch_id?: string;
    /** The minimum number of Compute Units. The minimum value is `0.25`. See [Compute size and Autoscaling configuration](https://neon.com/docs/manage/endpoints#compute-size-and-autoscaling-configuration) for more information. */
    autoscaling_limit_min_cu?: number;
    /** The maximum number of Compute Units. See [Compute size and Autoscaling configuration](https://neon.com/docs/manage/endpoints#compute-size-and-autoscaling-configuration) for more information. */
    autoscaling_limit_max_cu?: number;
    /** Compute provisioner. `k8s-neonvm` (default) supports Autoscaling; `k8s-pod` is fixed-size compute. Also `docker` and `serverless-platform`. */
    provisioner?: string;
    settings?: EndpointSettingsData;
    /** Deprecated. To enable connection pooling, append `-pooler` to the endpoint ID in the connection string. See [How to use connection pooling](https://neon.com/docs/connect/connection-pooling#how-to-use-connection-pooling) */
    pooler_enabled?: boolean;
    /** Deprecated. The connection pooler mode. Removal scheduled for June 20, 2026. */
    pooler_mode?: EndpointPoolerMode | (string & {});
    /** Whether to restrict connections to the compute endpoint. Enabling this option schedules a suspend compute operation. A disabled compute endpoint cannot be enabled by a connection or console action. However, the compute endpoint is periodically enabled by check_availability operations. */
    disabled?: boolean;
    /** NOT YET IMPLEMENTED. Whether to permit passwordless access to the compute endpoint. */
    passwordless_access?: boolean;
    /** Scale-to-zero idle timeout, in seconds, before the compute suspends. `0` uses the plan default; `-1` disables scale-to-zero (never suspends). Minimum is plan-dependent (Scale: 60); maximum 604800 (one week). Free cannot change it; Launch can only enable or disable; Scale can set any value. */
    suspend_timeout_seconds?: number;
    /** Optional name of the compute endpoint */
    name?: string;
}
export declare const UpdateProjectEndpointRequestEndpoint: S.Schema<UpdateProjectEndpointRequestEndpoint>;
export interface UpdateProjectEndpointRequest {
    /** The Neon project ID */
    project_id: string;
    /** The endpoint ID */
    endpoint_id: string;
    /** Parameters for the compute endpoint update. */
    endpoint: UpdateProjectEndpointRequestEndpoint;
}
export declare const UpdateProjectEndpointRequest: S.Schema<UpdateProjectEndpointRequest>;
export type UpdateProjectEndpointResponseOperationsList = Array<Operation>;
export declare const UpdateProjectEndpointResponseOperationsList: S.Schema<UpdateProjectEndpointResponseOperationsList>;
export interface UpdateProjectEndpointResponse {
    /** Compute endpoint created or retrieved, including its current lifecycle state. */
    endpoint: Endpoint;
    operations: UpdateProjectEndpointResponseOperationsList;
}
export declare const UpdateProjectEndpointResponse: S.Schema<UpdateProjectEndpointResponse>;
/** Fields to update on the snapshot. Updatable fields include `name` and `expires_at`. */
export interface UpdateSnapshotRequestSnapshot {
    /** Human-readable label for the snapshot. */
    name?: string;
    /** The date and time when the snapshot will expire. Omit to leave the current expiration unchanged. Send `null` to clear the expiration so the snapshot never expires. A future timestamp sets the absolute expiration. */
    expires_at?: string | null;
}
export declare const UpdateSnapshotRequestSnapshot: S.Schema<UpdateSnapshotRequestSnapshot>;
export interface UpdateSnapshotRequest {
    /** The Neon project ID */
    project_id: string;
    /** The snapshot ID */
    snapshot_id: string;
    /** Fields to update on the snapshot. Updatable fields include `name` and `expires_at`. */
    snapshot: UpdateSnapshotRequestSnapshot;
}
export declare const UpdateSnapshotRequest: S.Schema<UpdateSnapshotRequest>;
export interface UpdateSnapshotResponse {
    snapshot: Snapshot;
}
export declare const UpdateSnapshotResponse: S.Schema<UpdateSnapshotResponse>;
export type AcceptProjectTransferRequestError = NeonOpError;
/** Accept a project transfer request Accepts a transfer request for the specified project, transferring it to the specified organization or user. If org_id is not passed, the project will be transferred to the current user or organization account. */
export declare const acceptProjectTransferRequest: API.OperationMethod<AcceptProjectTransferRequestRequest, AcceptProjectTransferRequestResponse, AcceptProjectTransferRequestError, NeonOpContext>;
export type AddBranchNeonAuthOauthProviderError = NeonOpError;
/** Add an OAuth provider Adds an OAuth provider configuration to the specified branch's Neon Auth integration. After adding, users can authenticate using the configured provider. */
export declare const addBranchNeonAuthOauthProvider: API.OperationMethod<AddBranchNeonAuthOauthProviderRequest, NeonAuthOauthProvider, AddBranchNeonAuthOauthProviderError, NeonOpContext>;
export type AddBranchNeonAuthTrustedDomainError = NeonOpError;
/** Add domain to redirect_uri whitelist Adds a domain to the redirect URI whitelist for the specified branch. Only domains in this list are permitted as redirect targets after authentication. */
export declare const addBranchNeonAuthTrustedDomain: API.OperationMethod<AddBranchNeonAuthTrustedDomainRequest, AddBranchNeonAuthTrustedDomainResponse, AddBranchNeonAuthTrustedDomainError, NeonOpContext>;
export type AddProjectJWKSError = NeonOpError;
/** Add JWKS URL Adds a JWKS URL to the specified project for verifying JWTs used as the authentication mechanism. The URL must be a valid HTTPS URL that returns a JSON Web Key Set. The `provider_name` field allows you to specify which authentication provider you're using (e.g., Clerk, Auth0, AWS Cognito). The `branch_id` scopes the JWKS URL to specific branches; if not specified, it applies to all branches. The `role_names` scopes the URL to specific roles; if not specified, default roles are used (`authenticator`, `authenticated`, `anonymous`). The `jwt_audience` specifies which `aud` values are accepted in JWTs. */
export declare const addProjectJWKS: API.OperationMethod<AddProjectJWKSRequest, AddProjectJWKSResponse, AddProjectJWKSError, NeonOpContext>;
export type AssignOrganizationVPCEndpointError = NeonOpError;
/** Assign or update VPC endpoint Assigns a VPC endpoint to a Neon organization or updates its existing assignment. */
export declare const assignOrganizationVPCEndpoint: API.OperationMethod<AssignOrganizationVPCEndpointRequest, AssignOrganizationVPCEndpointResponse, AssignOrganizationVPCEndpointError, NeonOpContext>;
export type AssignProjectVPCEndpointError = NeonOpError;
/** Set VPC endpoint restriction Sets or updates a VPC endpoint restriction for a Neon project. When a VPC endpoint restriction is set, the project only accepts connections from the specified VPC. A VPC endpoint can be set as a restriction only after it is assigned to the parent organization of the Neon project. */
export declare const assignProjectVPCEndpoint: API.OperationMethod<AssignProjectVPCEndpointRequest, AssignProjectVPCEndpointResponse, AssignProjectVPCEndpointError, NeonOpContext>;
export type CountProjectBranchesError = NotFound | NeonOpError;
/** Retrieve number of branches Retrieves the total number of branches in the specified project. Supports an optional `search` parameter to count branches matching a name filter. */
export declare const countProjectBranches: API.OperationMethod<CountProjectBranchesRequest, CountProjectBranchesResponse, CountProjectBranchesError, NeonOpContext>;
export type CreateApiKeyError = NeonOpError;
/** Create API key Creates an API key. The `key_name` is a user-specified name for the key. Returns an `id` and `key`; the `key` is a randomly generated, 64-bit token required to access the Neon API. Store the key securely — it is only returned once. API keys can also be managed in the Neon Console. See [Manage API keys](https://neon.com/docs/manage/api-keys/). */
export declare const createApiKey: API.OperationMethod<CreateApiKeyRequest, ApiKeyCreateResponse, CreateApiKeyError, NeonOpContext>;
export type CreateBranchNeonAuthNewUserError = NeonOpError;
/** Create new auth user Creates a new user in the Neon Auth user directory for the specified branch. The user is created in the `neon_auth.users_sync` table and can immediately authenticate using the branch's configured auth providers. */
export declare const createBranchNeonAuthNewUser: API.OperationMethod<CreateBranchNeonAuthNewUserRequest, NeonAuthCreateNewUserResponse, CreateBranchNeonAuthNewUserError, NeonOpContext>;
export type CreateCredentialError = NeonOpError;
/** Issue a scoped credential on the branch Issues a new scoped service credential anchored to the specified branch. The response carries `api_token` and `s3_secret_access_key` exactly once — they are not stored server-side. **Note**: This endpoint is currently in Beta. */
export declare const createCredential: API.OperationMethod<CreateCredentialRequest, CreateCredentialResponse, CreateCredentialError, NeonOpContext>;
export type CreateNeonAuthError = NeonOpError;
/** Enable Neon Auth for the branch Enables Neon Auth for the specified branch by connecting it to an authentication provider. Creating the integration provisions the `neon_auth` schema in the branch database, which stores user identity data synchronized from the provider. */
export declare const createNeonAuth: API.OperationMethod<CreateNeonAuthRequest, NeonAuthCreateIntegrationResponse, CreateNeonAuthError, NeonOpContext>;
export type CreateNeonAuthProviderSDKKeysError = NeonOpError;
/** Create Auth Provider SDK keys Generates SDK or API Keys for the auth provider. These might be called different things depending on the auth provider you're using, but are generally used for setting up the frontend and backend SDKs. */
export declare const createNeonAuthProviderSDKKeys: API.OperationMethod<CreateNeonAuthProviderSDKKeysRequest, NeonAuthCreateIntegrationResponse, CreateNeonAuthProviderSDKKeysError, NeonOpContext>;
export type CreateOrganizationInvitationsError = NeonOpError;
/** Create organization invitations Creates invitations for a specific organization. If the invited user has an existing account, they automatically join as a member. If they don't yet have an account, they are invited to create one, after which they become a member. Each invited user receives an email notification. */
export declare const createOrganizationInvitations: API.OperationMethod<CreateOrganizationInvitationsRequest, OrganizationInvitationsResponse, CreateOrganizationInvitationsError, NeonOpContext>;
export type CreateOrgApiKeyError = NeonOpError;
/** Create organization API key Creates an API key for the specified organization. The `key_name` is a user-specified name for the key. Returns an `id` and `key`; the `key` is a randomly generated, 64-bit token required to access the Neon API. Store the key securely — it is only returned once. API keys can also be managed in the Neon Console. See [Manage API keys](https://neon.com/docs/manage/api-keys/). */
export declare const createOrgApiKey: API.OperationMethod<CreateOrgApiKeyRequest, CreateOrgApiKeyResponse, CreateOrgApiKeyError, NeonOpContext>;
export type CreateProjectError = NeonOpError;
/** Create project Creates a Neon project within an organization. If using a personal API key, include the `org_id` parameter to specify which organization to create the project in. If using an org API key, `org_id` is automatically inferred from the key. Plan limits define how many projects you can create. For more information, see [Manage projects](https://neon.com/docs/manage/projects/). You can specify a region and Postgres version in the request body. Neon supports Postgres 14 through 18, with 19 rolling out to enabled regions. For supported regions and `region_id` values, see [Regions](https://neon.com/docs/introduction/regions/). */
export declare const createProject: API.OperationMethod<CreateProjectRequest, CreateProjectResponse, CreateProjectError, NeonOpContext>;
export type CreateProjectBranchError = NeonOpError;
/** Create branch Creates a branch in the specified project. No request body is required, but you can specify one to create a compute endpoint or select a non-default parent branch. By default, the branch is created from the project's default branch with no compute endpoint, and the branch name is auto-generated. To access the branch, add a `read_write` endpoint. Each branch supports one read-write endpoint and multiple read-only endpoints. For related information, see [Manage branches](https://neon.com/docs/manage/branches/). */
export declare const createProjectBranch: API.OperationMethod<CreateProjectBranchRequest, CreateProjectBranchResponse, CreateProjectBranchError, NeonOpContext>;
export type CreateProjectBranchAnonymizedError = NeonOpError;
/** Create anonymized branch Creates a new branch with anonymized data using PostgreSQL Anonymizer for static masking. This allows developers to work with masked production data. Optionally, provide `masking_rules` to set initial masking rules for the branch and `start_anonymization` to automatically start anonymization after creation. This combines functionality of updating masking rules and starting anonymization into the branch creation request. **Note**: This endpoint is currently in Beta. */
export declare const createProjectBranchAnonymized: API.OperationMethod<CreateProjectBranchAnonymizedRequest, CreateProjectBranchAnonymizedResponse, CreateProjectBranchAnonymizedError, NeonOpContext>;
export type CreateProjectBranchBucketError = NeonOpError;
/** Create a bucket on the branch Creates a new branchable object storage bucket on the specified branch. Buckets are managed by the Neon Platform branchable object storage service. **Note**: This endpoint is currently in Beta. */
export declare const createProjectBranchBucket: API.OperationMethod<CreateProjectBranchBucketRequest, BucketResponse, CreateProjectBranchBucketError, NeonOpContext>;
export type CreateProjectBranchDataAPIError = NeonOpError;
/** Create Neon Data API Creates a new instance of Neon Data API in the specified branch. The Data API exposes a REST interface over the branch database. The `database_name` path parameter determines which database the API serves. */
export declare const createProjectBranchDataAPI: API.OperationMethod<CreateProjectBranchDataAPIRequest, DataAPICreateResponse, CreateProjectBranchDataAPIError, NeonOpContext>;
export type CreateProjectBranchDatabaseError = BadRequest | NotFound | Conflict | UnprocessableEntity | NeonOpError;
/** Create database Creates a database in the specified branch. A branch can have multiple databases. For related information, see [Manage databases](https://neon.com/docs/manage/databases/). */
export declare const createProjectBranchDatabase: API.OperationMethod<CreateProjectBranchDatabaseRequest, CreateProjectBranchDatabaseResponse, CreateProjectBranchDatabaseError, NeonOpContext>;
export type CreateProjectBranchFunctionDeploymentError = NeonOpError;
/** Deploy code to a function Creates a deployment for the function. Supply any subset of zip, environment, and runtime; omitted fields inherit the function's latest version. At least one field must be supplied. The first deployment of a function must include zip. The newest deployment becomes active. **Note**: This endpoint is currently in Beta. */
export declare const createProjectBranchFunctionDeployment: API.OperationMethod<CreateProjectBranchFunctionDeploymentRequest, NeonFunctionDeploymentResponse, CreateProjectBranchFunctionDeploymentError, NeonOpContext>;
export type CreateProjectBranchRoleError = NotFound | Conflict | NeonOpError;
/** Create role Creates a Postgres role in the specified branch. For related information, see [Manage roles](https://neon.com/docs/manage/roles/). Connections established to the active compute endpoint will be dropped. If the compute endpoint is idle, the endpoint becomes active for a short period of time and is suspended afterward. */
export declare const createProjectBranchRole: API.OperationMethod<CreateProjectBranchRoleRequest, CreateProjectBranchRoleResponse, CreateProjectBranchRoleError, NeonOpContext>;
export type CreateProjectEndpointError = NotFound | Conflict | NeonOpError;
/** Create compute endpoint Creates a compute endpoint for the specified branch. A compute endpoint is a Neon compute instance. There is a maximum of one read-write compute endpoint per branch. If the specified branch already has a read-write compute endpoint, the operation fails. A branch can have multiple read-only compute endpoints. For more information about compute endpoints, see [Manage computes](https://neon.com/docs/manage/endpoints/). */
export declare const createProjectEndpoint: API.OperationMethod<CreateProjectEndpointRequest, CreateProjectEndpointResponse, CreateProjectEndpointError, NeonOpContext>;
export type CreateProjectTransferRequestError = NeonOpError;
/** Create a project transfer request Creates a transfer request for the specified project. The request expires after a set period. To accept the request, the recipient calls `PUT /projects/{project_id}/transfer_requests/{request_id}` or uses the Neon Console claim link. The optional `ru` parameter redirects the recipient after acceptance. */
export declare const createProjectTransferRequest: API.OperationMethod<CreateProjectTransferRequestRequest, ProjectTransferRequestResponse, CreateProjectTransferRequestError, NeonOpContext>;
export type CreateSnapshotError = NeonOpError;
/** Create snapshot Creates a snapshot from the specified branch. This operation may initiate an asynchronous process. */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotRequest, CreateSnapshotResponse, CreateSnapshotError, NeonOpContext>;
export type DeleteBranchNeonAuthOauthProviderError = NeonOpError;
/** Delete OAuth provider Deletes an OAuth provider from the specified project. */
export declare const deleteBranchNeonAuthOauthProvider: API.OperationMethod<DeleteBranchNeonAuthOauthProviderRequest, DeleteBranchNeonAuthOauthProviderResponse, DeleteBranchNeonAuthOauthProviderError, NeonOpContext>;
export type DeleteBranchNeonAuthTrustedDomainError = NeonOpError;
/** Delete domain from redirect_uri whitelist Removes a domain from the redirect URI whitelist for the specified branch. After removal, the domain can no longer be used as a redirect target after authentication. */
export declare const deleteBranchNeonAuthTrustedDomain: API.OperationMethod<DeleteBranchNeonAuthTrustedDomainRequest, DeleteBranchNeonAuthTrustedDomainResponse, DeleteBranchNeonAuthTrustedDomainError, NeonOpContext>;
export type DeleteBranchNeonAuthUserError = NeonOpError;
/** Delete auth user Deletes the specified user from the Neon Auth user directory for the specified branch. Removes the user record from `neon_auth.users_sync`. This action cannot be undone. */
export declare const deleteBranchNeonAuthUser: API.OperationMethod<DeleteBranchNeonAuthUserRequest, DeleteBranchNeonAuthUserResponse, DeleteBranchNeonAuthUserError, NeonOpContext>;
export type DeleteOrganizationSpendingLimitError = NeonOpError;
/** Remove organization spending limit Removes the configured monthly spending limit for the specified organization. Idempotent — removing an already-unset limit still succeeds. Available to organization admins on Launch and Scale plans only. */
export declare const deleteOrganizationSpendingLimit: API.OperationMethod<DeleteOrganizationSpendingLimitRequest, DeleteOrganizationSpendingLimitResponse, DeleteOrganizationSpendingLimitError, NeonOpContext>;
export type DeleteOrganizationVPCEndpointError = NeonOpError;
/** Delete VPC endpoint Deletes the VPC endpoint from the specified Neon organization. If you delete a VPC endpoint from a Neon organization, that VPC endpoint cannot be added back to the Neon organization. */
export declare const deleteOrganizationVPCEndpoint: API.OperationMethod<DeleteOrganizationVPCEndpointRequest, DeleteOrganizationVPCEndpointResponse, DeleteOrganizationVPCEndpointError, NeonOpContext>;
export type DeleteProjectError = NotFound | NeonOpError;
/** Delete project Deletes the specified project and all its endpoints, branches, databases, and users. Deleted projects can be recovered within 7 days using `POST /projects/{project_id}/recover`. To list recoverable projects, use `GET /projects?recoverable=true`. */
export declare const deleteProject: API.OperationMethod<DeleteProjectRequest, ProjectResponse, DeleteProjectError, NeonOpContext>;
export type DeleteProjectBranchError = NotFound | UnprocessableEntity | NeonOpError;
/** Delete branch Deletes the specified branch from a project and places all compute endpoints into an idle state, breaking existing client connections. The deletion completes after all operations finish. You cannot delete a project's root or default branch, or a branch that has a child branch. A project must have at least one branch. By default, deleted branches can be recovered within a 7-day grace period. Use the `hard_delete` parameter to permanently delete the branch immediately. For related information, see [Manage branches](https://neon.com/docs/manage/branches/). */
export declare const deleteProjectBranch: API.OperationMethod<DeleteProjectBranchRequest, DeleteProjectBranchResponse, DeleteProjectBranchError, NeonOpContext>;
export type DeleteProjectBranchBucketError = NotFound | NeonOpError;
/** Delete a bucket on the branch Deletes the named bucket from the specified branch. **Note**: This endpoint is currently in Beta. */
export declare const deleteProjectBranchBucket: API.OperationMethod<DeleteProjectBranchBucketRequest, DeleteProjectBranchBucketResponse, DeleteProjectBranchBucketError, NeonOpContext>;
export type DeleteProjectBranchBucketObjectError = NotFound | NeonOpError;
/** Delete an object in a bucket Deletes the named object from the bucket on the specified branch. Served by the user's session (no customer S3 credentials required). **Note**: This endpoint is currently in Beta. */
export declare const deleteProjectBranchBucketObject: API.OperationMethod<DeleteProjectBranchBucketObjectRequest, DeleteProjectBranchBucketObjectResponse, DeleteProjectBranchBucketObjectError, NeonOpContext>;
export type DeleteProjectBranchBucketObjectsByPrefixError = NotFound | NeonOpError;
/** Delete every object under a key prefix (folder) in a bucket Soft-deletes every object on the specified branch whose key starts with `prefix`, in a single call. Intended to back a "delete folder" action in an object browser: a `prefix` of `app/avatars/` removes every object beneath that folder. Served by the user's session (no customer S3 credentials required). `prefix` must be non-empty, end with `/`, be at most 1024 bytes, and contain no control characters - a partial-segment prefix cannot accidentally delete sibling keys. Returns the number of objects soft-deleted (`deleted`), which may be 0 when no live object matched the prefix on this branch. Only objects physically present on this branch are tombstoned; objects inherited from an ancestor branch via copy-on-write (not materialized on this branch) are out of scope. **Note**: This endpoint is currently in Beta. */
export declare const deleteProjectBranchBucketObjectsByPrefix: API.OperationMethod<DeleteProjectBranchBucketObjectsByPrefixRequest, BucketObjectsDeletePrefixResponse, DeleteProjectBranchBucketObjectsByPrefixError, NeonOpContext>;
export type DeleteProjectBranchCustomDomainError = NeonOpError;
/** Delete a custom domain from a branch Removes a custom domain registered on the branch and stops routing it. **Note**: This endpoint is currently in Beta. */
export declare const deleteProjectBranchCustomDomain: API.OperationMethod<DeleteProjectBranchCustomDomainRequest, DeleteProjectBranchCustomDomainResponse, DeleteProjectBranchCustomDomainError, NeonOpContext>;
export type DeleteProjectBranchDataAPIError = NeonOpError;
/** Delete Neon Data API Deletes the Neon Data API for the specified branch. Existing connections using the Data API endpoint will fail after deletion. */
export declare const deleteProjectBranchDataAPI: API.OperationMethod<DeleteProjectBranchDataAPIRequest, DeleteProjectBranchDataAPIResponse, DeleteProjectBranchDataAPIError, NeonOpContext>;
export type DeleteProjectBranchDatabaseError = NotFound | NeonOpError;
/** Delete database Deletes the specified database from the branch. For related information, see [Manage databases](https://neon.com/docs/manage/databases/). */
export declare const deleteProjectBranchDatabase: API.OperationMethod<DeleteProjectBranchDatabaseRequest, DeleteProjectBranchDatabaseResponse, DeleteProjectBranchDatabaseError, NeonOpContext>;
export type DeleteProjectBranchFunctionError = NeonOpError;
/** Delete a function on the branch Deletes the function identified by its slug. **Note**: This endpoint is currently in Beta. */
export declare const deleteProjectBranchFunction: API.OperationMethod<DeleteProjectBranchFunctionRequest, DeleteProjectBranchFunctionResponse, DeleteProjectBranchFunctionError, NeonOpContext>;
export type DeleteProjectBranchRoleError = NotFound | UnprocessableEntity | NeonOpError;
/** Delete role Deletes the specified Postgres role from the branch. For related information, see [Manage roles](https://neon.com/docs/manage/roles/). */
export declare const deleteProjectBranchRole: API.OperationMethod<DeleteProjectBranchRoleRequest, DeleteProjectBranchRoleResponse, DeleteProjectBranchRoleError, NeonOpContext>;
export type DeleteProjectEndpointError = NotFound | NeonOpError;
/** Delete compute endpoint Deletes the specified compute endpoint. A compute endpoint is a Neon compute instance. Deleting a compute endpoint drops existing network connections to the compute endpoint. The deletion is completed when the last operation in the chain finishes successfully. An `endpoint_id` has an `ep-` prefix. For information about compute endpoints, see [Manage computes](https://neon.com/docs/manage/endpoints/). */
export declare const deleteProjectEndpoint: API.OperationMethod<DeleteProjectEndpointRequest, DeleteProjectEndpointResponse, DeleteProjectEndpointError, NeonOpContext>;
export type DeleteProjectJWKSError = NeonOpError;
/** Delete JWKS URL Removes the specified JWKS URL from the project. JWTs signed by keys from the removed URL can no longer authenticate to the project's endpoints. */
export declare const deleteProjectJWKS: API.OperationMethod<DeleteProjectJWKSRequest, JWKS, DeleteProjectJWKSError, NeonOpContext>;
export type DeleteProjectVPCEndpointError = NeonOpError;
/** Delete VPC endpoint restriction Removes the specified VPC endpoint restriction from a Neon project. */
export declare const deleteProjectVPCEndpoint: API.OperationMethod<DeleteProjectVPCEndpointRequest, DeleteProjectVPCEndpointResponse, DeleteProjectVPCEndpointError, NeonOpContext>;
export type DeleteSnapshotError = NeonOpError;
/** Delete snapshot Deletes the specified snapshot. */
export declare const deleteSnapshot: API.OperationMethod<DeleteSnapshotRequest, DeleteSnapshotResponse, DeleteSnapshotError, NeonOpContext>;
export type DisableNeonAuthError = NeonOpError;
/** Disable Neon Auth for the branch Disables the Neon Auth integration for the specified branch, removing the connection to the authentication provider. If `delete_data` is `true`, also deletes the `neon_auth` schema and all associated tables from the branch database. The integration can be re-enabled by calling `POST /projects/{project_id}/branches/{branch_id}/auth`. */
export declare const disableNeonAuth: API.OperationMethod<DisableNeonAuthRequest, DisableNeonAuthResponse, DisableNeonAuthError, NeonOpContext>;
export type FinalizeRestoreBranchError = NeonOpError;
/** Finalize branch restore from snapshot Finalize the restore operation for a branch created from a snapshot. This operation updates the branch so it functions as the original branch it replaced. This includes: - Reassigning any computes from the original branch to the restored branch (this will restart the computes) - Renaming the restored branch to the original branch's name - Renaming the original branch so it no longer uses the original name This operation only applies to branches created using the `restoreSnapshot` endpoint with `finalize_restore: false`. */
export declare const finalizeRestoreBranch: API.OperationMethod<FinalizeRestoreBranchRequest, OperationsResponse, FinalizeRestoreBranchError, NeonOpContext>;
export type GetActiveRegionsError = NeonOpError;
/** List supported regions Lists supported Neon regions. **Note:** Not all regions are available to all organizations. Pass the `org_id` parameter to get an accurate list of regions available to your organization. */
export declare const getActiveRegions: API.OperationMethod<GetActiveRegionsRequest, ActiveRegionsResponse, GetActiveRegionsError, NeonOpContext>;
export type GetAnonymizedBranchStatusError = NeonOpError;
/** Retrieve anonymized branch status Retrieves the current status of an anonymized branch, including its state and progress information. This endpoint allows you to monitor the anonymization process from initialization through completion. Only anonymized branches will have status information available. **Note**: This endpoint is currently in Beta. */
export declare const getAnonymizedBranchStatus: API.OperationMethod<GetAnonymizedBranchStatusRequest, AnonymizedBranchStatusResponse, GetAnonymizedBranchStatusError, NeonOpContext>;
export type GetAuthDetailsError = NeonOpError;
/** Retrieve request authentication details Returns authentication details for the credentials used in the request, including the credential type (API key, Bearer token, or OAuth session) and the associated identity. */
export declare const getAuthDetails: API.OperationMethod<GetAuthDetailsRequest, AuthDetailsResponse, GetAuthDetailsError, NeonOpContext>;
export type GetAvailablePreloadLibrariesError = NeonOpError;
/** List available shared preload libraries Returns the shared preload libraries available for the specified project's Postgres version. Shared preload libraries are Postgres extensions that require the `shared_preload_libraries` setting and a compute restart to activate. Use this list to determine which libraries can be enabled in the project's `settings.preload_libraries` configuration. */
export declare const getAvailablePreloadLibraries: API.OperationMethod<GetAvailablePreloadLibrariesRequest, AvailablePreloadLibraries, GetAvailablePreloadLibrariesError, NeonOpContext>;
export type GetConnectionURIError = NotFound | NeonOpError;
/** Retrieve connection URI Retrieves a connection URI for the specified database. The URI uses the standard PostgreSQL connection string format. Set `pooled=true` to include the `-pooler` suffix for a connection pooler URI. */
export declare const getConnectionURI: API.OperationMethod<GetConnectionURIRequest, ConnectionURIResponse, GetConnectionURIError, NeonOpContext>;
export type GetConsumptionHistoryPerBranchV2Error = Forbidden | NotFound | NeonOpError;
/** Retrieve branch consumption metrics Returns consumption metrics for each branch across one or more projects listed in `project_ids` (1 to 100 projects). Available for accounts on paid usage-based Launch, Scale, Agent, and Enterprise plans. History starts when the account first ingests branch-level consumption data. The `metrics` query parameter is required. Only these six values are supported on this endpoint: `compute_unit_seconds`, `root_branch_bytes_month`, `child_branch_bytes_month`, `instant_restore_bytes_month`, `public_network_transfer_bytes`, `private_network_transfer_bytes`. This endpoint does not support `extra_branches_month` or `snapshot_storage_bytes_month`. Use `GET /consumption_history/v2/projects` for those. Consumption metrics within each branch are returned in ascending time order (oldest first). This request does not wake project computes. */
export declare const getConsumptionHistoryPerBranchV2: API.PaginatedOperationMethod<GetConsumptionHistoryPerBranchV2Request, GetConsumptionHistoryPerBranchV2Response, GetConsumptionHistoryPerBranchV2Error, NeonOpContext, ConsumptionHistoryPerBranchV2>;
export type GetConsumptionHistoryPerProjectError = Forbidden | NotFound | NeonOpError;
/** Retrieve project consumption metrics (legacy plans) Retrieves consumption metrics for Scale, Business, and Enterprise plan projects. History begins at the time of upgrade. Results are ordered by time in ascending order (oldest to newest). Issuing a call to this API does not wake a project's compute endpoint. */
export declare const getConsumptionHistoryPerProject: API.PaginatedOperationMethod<GetConsumptionHistoryPerProjectRequest, GetConsumptionHistoryPerProjectResponse, GetConsumptionHistoryPerProjectError, NeonOpContext, ConsumptionHistoryPerProject>;
export type GetConsumptionHistoryPerProjectV2Error = Forbidden | NotFound | NeonOpError;
/** Retrieve project consumption metrics Returns consumption metrics for up to `limit` projects per page. If `project_ids` is omitted, projects in the organization are included across pages (use `cursor`). If `project_ids` is provided, the response is limited to those projects (up to 100). Available for accounts on Launch, Scale, Agent, Business, and Enterprise plans. History starts when the account upgrades to an eligible plan. The `metrics` query parameter is required. Supported values: `compute_unit_seconds`, `root_branch_bytes_month`, `child_branch_bytes_month`, `instant_restore_bytes_month`, `public_network_transfer_bytes`, `private_network_transfer_bytes`, `extra_branches_month`, `snapshot_storage_bytes_month`. Consumption metrics within each project are returned in ascending time order (oldest first). This request does not wake project computes. */
export declare const getConsumptionHistoryPerProjectV2: API.PaginatedOperationMethod<GetConsumptionHistoryPerProjectV2Request, GetConsumptionHistoryPerProjectV2Response, GetConsumptionHistoryPerProjectV2Error, NeonOpContext, ConsumptionHistoryPerProjectV2>;
export type GetCurrentUserInfoError = NeonOpError;
/** Retrieve current user details Retrieves information about the currently authenticated Neon user, including account identifiers, plan details, and linked auth accounts. */
export declare const getCurrentUserInfo: API.OperationMethod<GetCurrentUserInfoRequest, CurrentUserInfoResponse, GetCurrentUserInfoError, NeonOpContext>;
export type GetCurrentUserOrganizationsError = NeonOpError;
/** List organizations for the current user Retrieves the organizations that the currently authenticated user belongs to. When called with an organization- or project-scoped API key (which is not tied to a user), this returns the single organization that owns the key. */
export declare const getCurrentUserOrganizations: API.OperationMethod<GetCurrentUserOrganizationsRequest, OrganizationsResponse, GetCurrentUserOrganizationsError, NeonOpContext>;
export type GetMaskingRulesError = NeonOpError;
/** Retrieve masking rules Retrieves the masking rules for the specified anonymized branch. Masking rules define how sensitive data should be anonymized using PostgreSQL Anonymizer. **Note**: This endpoint is currently in Beta. */
export declare const getMaskingRules: API.OperationMethod<GetMaskingRulesRequest, MaskingRulesResponse, GetMaskingRulesError, NeonOpContext>;
export type GetNeonAuthError = NeonOpError;
/** Retrieve Neon Auth details for the branch Retrieves the Neon Auth integration details for the specified branch, including the auth provider type and integration status. */
export declare const getNeonAuth: API.OperationMethod<GetNeonAuthRequest, NeonAuthIntegration, GetNeonAuthError, NeonOpContext>;
export type GetNeonAuthAllowLocalhostError = NeonOpError;
/** Retrieve localhost allow setting Retrieves the localhost allow setting for the specified branch's Neon Auth integration. When enabled, authentication flows work from `localhost` without adding it to the redirect URI whitelist. */
export declare const getNeonAuthAllowLocalhost: API.OperationMethod<GetNeonAuthAllowLocalhostRequest, NeonAuthAllowLocalhostResponse, GetNeonAuthAllowLocalhostError, NeonOpContext>;
export type GetNeonAuthEmailAndPasswordConfigError = NeonOpError;
/** Retrieve email and password configuration Retrieves the email and password authentication configuration for the specified branch's Neon Auth integration, including whether it is enabled and the email verification method. */
export declare const getNeonAuthEmailAndPasswordConfig: API.OperationMethod<GetNeonAuthEmailAndPasswordConfigRequest, NeonAuthEmailAndPasswordConfig, GetNeonAuthEmailAndPasswordConfigError, NeonOpContext>;
export type GetNeonAuthEmailProviderError = NeonOpError;
/** Retrieve email provider configuration Retrieves the email provider configuration for the specified branch's Neon Auth integration, including the provider type and server settings. */
export declare const getNeonAuthEmailProvider: API.OperationMethod<GetNeonAuthEmailProviderRequest, GetNeonAuthEmailProviderResponse, GetNeonAuthEmailProviderError, NeonOpContext>;
export type GetNeonAuthPhoneNumberPluginError = NeonOpError;
/** Retrieve phone number plugin configuration Returns the phone number plugin configuration for Neon Auth. The phone number plugin enables phone-based OTP authentication. */
export declare const getNeonAuthPhoneNumberPlugin: API.OperationMethod<GetNeonAuthPhoneNumberPluginRequest, NeonAuthPhoneNumberConfig, GetNeonAuthPhoneNumberPluginError, NeonOpContext>;
export type GetNeonAuthPluginConfigsError = NeonOpError;
/** Retrieve Neon Auth plugin configurations Returns all plugin configurations for Neon Auth in a single response. This endpoint aggregates organization, email provider, email and password, OAuth providers, and localhost settings. */
export declare const getNeonAuthPluginConfigs: API.OperationMethod<GetNeonAuthPluginConfigsRequest, NeonAuthPluginConfigs, GetNeonAuthPluginConfigsError, NeonOpContext>;
export type GetNeonAuthWebhookConfigError = NeonOpError;
/** Retrieve Neon Auth webhook configuration Returns the webhook configuration for the specified branch's Neon Auth integration, including the endpoint URL and the events that trigger it. */
export declare const getNeonAuthWebhookConfig: API.OperationMethod<GetNeonAuthWebhookConfigRequest, NeonAuthWebhookConfig, GetNeonAuthWebhookConfigError, NeonOpContext>;
export type GetOrganizationError = NeonOpError;
/** Retrieve organization details Retrieves details for the specified organization, including its name, plan, and configuration. */
export declare const getOrganization: API.OperationMethod<GetOrganizationRequest, Organization, GetOrganizationError, NeonOpContext>;
export type GetOrganizationInvitationsError = NeonOpError;
/** List organization invitations Retrieves pending and accepted invitations for the specified organization. */
export declare const getOrganizationInvitations: API.OperationMethod<GetOrganizationInvitationsRequest, OrganizationInvitationsResponse, GetOrganizationInvitationsError, NeonOpContext>;
export type GetOrganizationMemberError = NeonOpError;
/** Retrieve organization member details Retrieves information about the specified organization member. */
export declare const getOrganizationMember: API.OperationMethod<GetOrganizationMemberRequest, Member, GetOrganizationMemberError, NeonOpContext>;
export type GetOrganizationMembersError = NeonOpError;
/** List organization members Retrieves a paginated list of members for the specified organization. */
export declare const getOrganizationMembers: API.PaginatedOperationMethod<GetOrganizationMembersRequest, GetOrganizationMembersResponse, GetOrganizationMembersError, NeonOpContext, MemberWithUser>;
export type GetOrganizationSpendingLimitError = NeonOpError;
/** Retrieve organization spending limit Returns the configured monthly spending limit for the specified organization. `spending_limit_cents: null` indicates that no limit is currently set. Available to organization members with read access on Launch and Scale plans only. */
export declare const getOrganizationSpendingLimit: API.OperationMethod<GetOrganizationSpendingLimitRequest, SpendingLimitResponse, GetOrganizationSpendingLimitError, NeonOpContext>;
export type GetOrganizationVPCEndpointDetailsError = NeonOpError;
/** Retrieve VPC endpoint details Retrieves the current state and configuration details of a specified VPC endpoint. */
export declare const getOrganizationVPCEndpointDetails: API.OperationMethod<GetOrganizationVPCEndpointDetailsRequest, VPCEndpointDetails, GetOrganizationVPCEndpointDetailsError, NeonOpContext>;
export type GetProjectError = BadRequest | NotFound | NeonOpError;
/** Retrieve project details Retrieves information about the specified project. Returned details include the project settings, compute configuration, history retention, owner information, and current usage metrics. */
export declare const getProject: API.OperationMethod<GetProjectRequest, ProjectResponse, GetProjectError, NeonOpContext>;
export type GetProjectAdvisorSecurityIssuesError = NeonOpError;
/** Get advisor issues Analyzes the database for security and performance issues. Returns a list of issues categorized by severity (ERROR, WARN, INFO). Requires read access to the project and Data API enabled. */
export declare const getProjectAdvisorSecurityIssues: API.OperationMethod<GetProjectAdvisorSecurityIssuesRequest, GetProjectAdvisorSecurityIssuesResponse, GetProjectAdvisorSecurityIssuesError, NeonOpContext>;
export type GetProjectBranchError = NotFound | NeonOpError;
/** Retrieve branch details Retrieves information about the specified branch. A `branch_id` value has a `br-` prefix. Each Neon project is initially created with a root and default branch named `main`. A project can contain one or more branches. A parent branch is identified by a `parent_id` value, which is the `id` of the parent branch. For related information, see [Manage branches](https://neon.com/docs/manage/branches/). */
export declare const getProjectBranch: API.OperationMethod<GetProjectBranchRequest, GetProjectBranchResponse, GetProjectBranchError, NeonOpContext>;
export type GetProjectBranchAiGatewayError = NotFound | NeonOpError;
/** Get branch AI Gateway endpoint Returns the AI Gateway endpoint host for the specified branch, used to render code-snippet base URLs. A 200 response means the branch is registered and this region serves the AI gateway. A 404 response includes a `reason` field indicating why the gateway is unavailable. **Note**: This endpoint is currently in Beta. */
export declare const getProjectBranchAiGateway: API.OperationMethod<GetProjectBranchAiGatewayRequest, BranchAiGateway, GetProjectBranchAiGatewayError, NeonOpContext>;
export type GetProjectBranchBucketObjectError = NotFound | NeonOpError;
/** Download an object's bytes Streams the raw bytes of the named object from the bucket on the specified branch, including objects inherited from ancestor branches. Served by the user's session (no customer S3 credentials required). The body is returned as `application/octet-stream` so a browser treats it as a download; the `Content-Length` and `ETag` response headers echo the stored object metadata. BINARY-STREAM EXCEPTION TO THE BUILD-GENERATED-TYPES RULE (#7029): the successful 200 body is the raw object stream, proxied verbatim from the platform object storage admin endpoint. It is modeled as an `application/octet-stream` binary body (not a JSON response schema) and is streamed without buffering the whole object in memory. Error responses still use the generated `GeneralError` shape. **Note**: This endpoint is currently in Beta. */
export declare const getProjectBranchBucketObject: API.OperationMethod<GetProjectBranchBucketObjectRequest, GetProjectBranchBucketObjectResponse, GetProjectBranchBucketObjectError, NeonOpContext>;
export type GetProjectBranchDataAPIError = NeonOpError;
/** Retrieve Neon Data API configuration Retrieves the Neon Data API configuration for the specified branch, including endpoint URL, enabled state, and database settings. */
export declare const getProjectBranchDataAPI: API.OperationMethod<GetProjectBranchDataAPIRequest, DataAPIReponse, GetProjectBranchDataAPIError, NeonOpContext>;
export type GetProjectBranchDatabaseError = NotFound | NeonOpError;
/** Retrieve database details Retrieves information about the specified database. For related information, see [Manage databases](https://neon.com/docs/manage/databases/). */
export declare const getProjectBranchDatabase: API.OperationMethod<GetProjectBranchDatabaseRequest, DatabaseResponse, GetProjectBranchDatabaseError, NeonOpContext>;
export type GetProjectBranchFunctionError = NeonOpError;
/** Get function details Returns the function identified by its slug. **Note**: This endpoint is currently in Beta. */
export declare const getProjectBranchFunction: API.OperationMethod<GetProjectBranchFunctionRequest, NeonFunctionResponse, GetProjectBranchFunctionError, NeonOpContext>;
export type GetProjectBranchRoleError = NotFound | NeonOpError;
/** Retrieve role details Retrieves details about the specified role. In Neon, the terms "role" and "user" are synonymous. For related information, see [Manage roles](https://neon.com/docs/manage/roles/). */
export declare const getProjectBranchRole: API.OperationMethod<GetProjectBranchRoleRequest, RoleResponse, GetProjectBranchRoleError, NeonOpContext>;
export type GetProjectBranchRolePasswordError = NotFound | NeonOpError;
/** Retrieve role password Retrieves the password for the specified Postgres role, if possible. For related information, see [Manage roles](https://neon.com/docs/manage/roles/). */
export declare const getProjectBranchRolePassword: API.OperationMethod<GetProjectBranchRolePasswordRequest, RolePasswordResponse, GetProjectBranchRolePasswordError, NeonOpContext>;
export type GetProjectBranchSchemaError = NotFound | NeonOpError;
/** Retrieve database schema Retrieves the database schema. Specify `lsn` or `timestamp` (not both) to read at a point in time; omit both to read from the database's head. */
export declare const getProjectBranchSchema: API.OperationMethod<GetProjectBranchSchemaRequest, BranchSchemaResponse, GetProjectBranchSchemaError, NeonOpContext>;
export type GetProjectBranchSchemaComparisonError = NotFound | NeonOpError;
/** Compare database schema Compares the schema from the specified database with another branch's schema. */
export declare const getProjectBranchSchemaComparison: API.OperationMethod<GetProjectBranchSchemaComparisonRequest, BranchSchemaCompareResponse, GetProjectBranchSchemaComparisonError, NeonOpContext>;
export type GetProjectBranchStorageError = NotFound | NeonOpError;
/** Get branch object storage state Returns whether branchable object storage is usable for the specified branch. A 200 response means the branch is registered in the object storage service and the S3 data plane will accept requests for it. A 404 response includes a `reason` field indicating why object storage is unavailable. **Note**: This endpoint is currently in Beta. */
export declare const getProjectBranchStorage: API.OperationMethod<GetProjectBranchStorageRequest, BranchStorage, GetProjectBranchStorageError, NeonOpContext>;
export type GetProjectEndpointError = NotFound | NeonOpError;
/** Retrieve compute endpoint details Retrieves information about the specified compute endpoint. A compute endpoint is a Neon compute instance. An `endpoint_id` has an `ep-` prefix. For information about compute endpoints, see [Manage computes](https://neon.com/docs/manage/endpoints/). */
export declare const getProjectEndpoint: API.OperationMethod<GetProjectEndpointRequest, EndpointResponse, GetProjectEndpointError, NeonOpContext>;
export type GetProjectJWKSError = NeonOpError;
/** List JWKS URLs Returns the JWKS URLs available for verifying JWTs used as the authentication mechanism for the specified project. */
export declare const getProjectJWKS: API.OperationMethod<GetProjectJWKSRequest, ProjectJWKSResponse, GetProjectJWKSError, NeonOpContext>;
export type GetProjectOperationError = NotFound | NeonOpError;
/** Retrieve operation details Retrieves details for the specified operation. An operation is an action performed on a Neon project resource. */
export declare const getProjectOperation: API.OperationMethod<GetProjectOperationRequest, OperationResponse, GetProjectOperationError, NeonOpContext>;
export type GetSnapshotScheduleError = NeonOpError;
/** Retrieve backup schedule Returns the backup schedule for the specified branch, including the configured snapshot frequencies. */
export declare const getSnapshotSchedule: API.OperationMethod<GetSnapshotScheduleRequest, BackupSchedule, GetSnapshotScheduleError, NeonOpContext>;
export type GrantPermissionToProjectError = NeonOpError;
/** Grant project access Grants project access to the account associated with the specified email address. */
export declare const grantPermissionToProject: API.OperationMethod<GrantPermissionToProjectRequest, ProjectPermission, GrantPermissionToProjectError, NeonOpContext>;
export type ListApiKeysError = NeonOpError;
/** List API keys Retrieves the API keys for your Neon account. The response does not include API key tokens. A token is only provided when creating an API key. API keys can also be managed in the Neon Console. For more information, see [Manage API keys](https://neon.com/docs/manage/api-keys/). */
export declare const listApiKeys: API.OperationMethod<ListApiKeysRequest, ListApiKeysResponse, ListApiKeysError, NeonOpContext>;
export type ListBranchNeonAuthOauthProvidersError = NeonOpError;
/** List OAuth providers for the branch Lists the OAuth providers configured for the specified branch's Neon Auth integration. */
export declare const listBranchNeonAuthOauthProviders: API.OperationMethod<ListBranchNeonAuthOauthProvidersRequest, ListNeonAuthOauthProvidersResponse, ListBranchNeonAuthOauthProvidersError, NeonOpContext>;
export type ListBranchNeonAuthTrustedDomainsError = NeonOpError;
/** List domains in redirect_uri whitelist Lists the trusted domains in the redirect URI whitelist for the specified branch. Only domains in this list are permitted as redirect targets after authentication. */
export declare const listBranchNeonAuthTrustedDomains: API.OperationMethod<ListBranchNeonAuthTrustedDomainsRequest, NeonAuthRedirectURIWhitelistResponse, ListBranchNeonAuthTrustedDomainsError, NeonOpContext>;
export type ListCredentialsError = NeonOpError;
/** List credentials on the branch Returns metadata for customer-issued credentials on the branch. Secrets are never included. **Note**: This endpoint is currently in Beta. */
export declare const listCredentials: API.OperationMethod<ListCredentialsRequest, ListCredentialsResponse, ListCredentialsError, NeonOpContext>;
export type ListOrganizationVPCEndpointsError = NeonOpError;
/** List VPC endpoints Retrieves the list of VPC endpoints for the specified Neon organization. */
export declare const listOrganizationVPCEndpoints: API.OperationMethod<ListOrganizationVPCEndpointsRequest, VPCEndpointsResponse, ListOrganizationVPCEndpointsError, NeonOpContext>;
export type ListOrganizationVPCEndpointsAllRegionsError = NeonOpError;
/** List VPC endpoints across all regions Retrieves the list of VPC endpoints for the specified Neon organization across all regions. */
export declare const listOrganizationVPCEndpointsAllRegions: API.OperationMethod<ListOrganizationVPCEndpointsAllRegionsRequest, VPCEndpointsWithRegionResponse, ListOrganizationVPCEndpointsAllRegionsError, NeonOpContext>;
export type ListOrgApiKeysError = NeonOpError;
/** List organization API keys Retrieves the API keys for the specified organization. The response does not include API key tokens. A token is only provided when creating an API key. API keys can also be managed in the Neon Console. For more information, see [Manage API keys](https://neon.com/docs/manage/api-keys/). */
export declare const listOrgApiKeys: API.OperationMethod<ListOrgApiKeysRequest, ListOrgApiKeysResponse, ListOrgApiKeysError, NeonOpContext>;
export type ListProjectBranchBucketObjectsError = NeonOpError;
/** List objects in a bucket Lists objects visible in the named bucket on the specified branch, including those inherited from ancestor branches. Listing is served by the user's session (no customer S3 credentials required). When `delimiter` is supplied (typically `/`), keys are collapsed into common prefixes (`folders`) so callers can render a folder-style browser; keys that do not contain the delimiter after `prefix` are returned as `objects`. **Note**: This endpoint is currently in Beta. */
export declare const listProjectBranchBucketObjects: API.OperationMethod<ListProjectBranchBucketObjectsRequest, BucketObjectsListResponse, ListProjectBranchBucketObjectsError, NeonOpContext>;
export type ListProjectBranchBucketsError = NeonOpError;
/** List buckets on the branch Lists branchable object storage buckets visible on the specified branch, including those inherited from ancestor branches. **Note**: This endpoint is currently in Beta. */
export declare const listProjectBranchBuckets: API.OperationMethod<ListProjectBranchBucketsRequest, BucketsListResponse, ListProjectBranchBucketsError, NeonOpContext>;
export type ListProjectBranchCustomDomainsError = NeonOpError;
/** List the custom domains on a branch Lists all custom domains registered on the branch, across every target entity. **Note**: This endpoint is currently in Beta. */
export declare const listProjectBranchCustomDomains: API.PaginatedOperationMethod<ListProjectBranchCustomDomainsRequest, ListProjectBranchCustomDomainsResponse, ListProjectBranchCustomDomainsError, NeonOpContext, CustomDomain>;
export type ListProjectBranchDatabasesError = NotFound | NeonOpError;
/** List databases Retrieves a list of databases for the specified branch. A branch can have multiple databases. For related information, see [Manage databases](https://neon.com/docs/manage/databases/). */
export declare const listProjectBranchDatabases: API.OperationMethod<ListProjectBranchDatabasesRequest, DatabasesResponse, ListProjectBranchDatabasesError, NeonOpContext>;
export type ListProjectBranchEndpointsError = NotFound | NeonOpError;
/** List branch endpoints Retrieves a list of compute endpoints for the specified branch. Neon permits only one read-write compute endpoint per branch. A branch can have multiple read-only compute endpoints. */
export declare const listProjectBranchEndpoints: API.OperationMethod<ListProjectBranchEndpointsRequest, EndpointsResponse, ListProjectBranchEndpointsError, NeonOpContext>;
export type ListProjectBranchesError = NotFound | NeonOpError;
/** List branches Retrieves a list of branches for the specified project. Each Neon project has a root branch named `main`. A `branch_id` value has a `br-` prefix. A project may contain child branches that were branched from `main` or from another branch. A parent branch is identified by the `parent_id` value, which is the `id` of the parent branch. For related information, see [Manage branches](https://neon.com/docs/manage/branches/). */
export declare const listProjectBranches: API.PaginatedOperationMethod<ListProjectBranchesRequest, ListProjectBranchesResponse, ListProjectBranchesError, NeonOpContext, Branch>;
export type ListProjectBranchFunctionsError = NeonOpError;
/** List functions on the branch Lists functions on the specified branch. **Note**: This endpoint is currently in Beta. */
export declare const listProjectBranchFunctions: API.PaginatedOperationMethod<ListProjectBranchFunctionsRequest, ListProjectBranchFunctionsResponse, ListProjectBranchFunctionsError, NeonOpContext, NeonFunction>;
export type ListProjectBranchLogFieldsError = NotFound | NeonOpError;
/** List branch log fields Lists the low-cardinality log fields observed on this branch whose distinct values can be discovered with the log field-values endpoint. The set is computed per branch and grows as new fields are observed, so treat it as data rather than a fixed list: discover a field here, then pass it as `field_name` to the field-values endpoint. **Note**: This endpoint is currently in Private Beta. */
export declare const listProjectBranchLogFields: API.OperationMethod<ListProjectBranchLogFieldsRequest, ProjectBranchLogFieldsResponse, ListProjectBranchLogFieldsError, NeonOpContext>;
export type ListProjectBranchLogFieldValuesError = BadRequest | NotFound | NeonOpError;
/** List branch log field values Lists the distinct values observed for a low-cardinality log field in the requested time range. Call the log fields endpoint first to learn which `field_name` values this branch supports; a field that branch has never emitted is rejected with `unknown_field`. Give the window either as `since` or as an explicit `start_time`; supplying both is rejected. If neither is given, the previous six hours are used. The maximum supported time range is seven days. **Note**: This endpoint is currently in Private Beta. */
export declare const listProjectBranchLogFieldValues: API.OperationMethod<ListProjectBranchLogFieldValuesRequest, ProjectBranchLogFieldValuesResponse, ListProjectBranchLogFieldValuesError, NeonOpContext>;
export type ListProjectBranchRolesError = NotFound | NeonOpError;
/** List roles Retrieves a list of Postgres roles from the specified branch. For related information, see [Manage roles](https://neon.com/docs/manage/roles/). */
export declare const listProjectBranchRoles: API.OperationMethod<ListProjectBranchRolesRequest, RolesResponse, ListProjectBranchRolesError, NeonOpContext>;
export type ListProjectEndpointsError = NotFound | NeonOpError;
/** List compute endpoints Retrieves a list of compute endpoints for the specified project. A compute endpoint is a Neon compute instance. For information about compute endpoints, see [Manage computes](https://neon.com/docs/manage/endpoints/). */
export declare const listProjectEndpoints: API.OperationMethod<ListProjectEndpointsRequest, EndpointsResponse, ListProjectEndpointsError, NeonOpContext>;
export type ListProjectMembersError = NeonOpError;
/** List org members and their project roles Lists organization members and their per-project roles for an org-owned project. Returns 404 when the project is not org-owned, per-project role management is disabled, or the caller has no access. Callers with VIEWER or EDITOR see members with effective project access. Callers with ADMIN also see unassigned org members. */
export declare const listProjectMembers: API.PaginatedOperationMethod<ListProjectMembersRequest, ProjectMembers, ListProjectMembersError, NeonOpContext, ProjectMember>;
export type ListProjectOperationsError = NotFound | NeonOpError;
/** List operations Retrieves a list of operations for the specified Neon project. The number of operations returned can be large. To paginate the response, issue an initial request with a `limit` value. Then, add the `cursor` value that was returned in the response to the next request. Operations older than 6 months may be deleted from our systems. If you need more history than that, you should store your own history. */
export declare const listProjectOperations: API.PaginatedOperationMethod<ListProjectOperationsRequest, ListProjectOperationsResponse, ListProjectOperationsError, NeonOpContext, Operation>;
export type ListProjectPermissionsError = NotFound | NeonOpError;
/** List project access Retrieves details about users who have access to the project, including the permission `id`, the granted-to email address, and the date project access was granted. */
export declare const listProjectPermissions: API.OperationMethod<ListProjectPermissionsRequest, ProjectPermissions, ListProjectPermissionsError, NeonOpContext>;
export type ListProjectsError = NeonOpError;
/** List projects Retrieves a list of projects for the specified organization. If using a personal API key, include the `org_id` parameter to specify which organization to work with. If using an org API key, `org_id` is automatically inferred from the key. For more information, see [Manage organizations using the Neon API](https://neon.com/docs/manage/orgs-api) and [Manage projects](https://neon.com/docs/manage/projects/). */
export declare const listProjects: API.PaginatedOperationMethod<ListProjectsRequest, ListProjectsResponse, ListProjectsError, NeonOpContext, ProjectListItem>;
export type ListProjectVPCEndpointsError = NeonOpError;
/** List VPC endpoint restrictions Lists VPC endpoint restrictions for the specified Neon project. */
export declare const listProjectVPCEndpoints: API.OperationMethod<ListProjectVPCEndpointsRequest, VPCEndpointsResponse, ListProjectVPCEndpointsError, NeonOpContext>;
export type ListSharedProjectsError = NeonOpError;
/** List shared projects Retrieves a list of projects shared with your Neon account. For more information, see [Manage projects](https://neon.com/docs/manage/projects/). */
export declare const listSharedProjects: API.PaginatedOperationMethod<ListSharedProjectsRequest, ListSharedProjectsResponse, ListSharedProjectsError, NeonOpContext, ProjectListItem>;
export type ListSnapshotsError = NeonOpError;
/** List project snapshots Lists the snapshots for the specified project. Each snapshot represents a point-in-time backup of the project data. */
export declare const listSnapshots: API.OperationMethod<ListSnapshotsRequest, ListSnapshotsResponse, ListSnapshotsError, NeonOpContext>;
export type PresignProjectBranchBucketObjectError = NotFound | NeonOpError;
/** Presign an upload or download for an object in a bucket Returns a presigned URL that transfers bytes directly to or from the object's bucket on the specified branch, without the caller ever handling S3 credentials. The `operation` field selects the direction: - `upload` returns a presigned `PUT` URL (the caller `PUT`s the file bytes straight to `url` with the returned `headers`). Authorized with project write access. - `download` returns a presigned `GET` URL (the caller `GET`s the bytes straight from `url`). Authorized with project read access. The platform mints a short-lived credential and builds the SigV4-signed URL against the branch's S3 data-plane host, returning it together with the HTTP method, any headers the caller must echo, and the URL's expiry. Served by the user's session (no customer S3 credentials required). **Note**: This endpoint is currently in Beta. */
export declare const presignProjectBranchBucketObject: API.OperationMethod<PresignProjectBranchBucketObjectRequest, PresignResponse, PresignProjectBranchBucketObjectError, NeonOpContext>;
export type QueryProjectBranchLogsError = BadRequest | NotFound | NeonOpError;
/** Query branch logs Returns logs emitted by services running on the specified branch, ordered by timestamp according to `sort_order`. All supplied filters are combined with `AND`: a record is returned only when it matches every filter. `minimum_severity` and `severity_text` are independent filters, so setting both requires a record to clear the severity floor *and* match the exact severity text. Supply `logql` instead of the structured filters to run a raw LogQL expression. Combining it with any structured filter is rejected rather than silently ignored; `limit`, `sort_order`, and the time window still apply, because those bound the query rather than form part of the expression. Give the window either as `since` — a duration ending at `end_time`, or at the current time when `end_time` is omitted — or as an explicit `start_time`. Supplying both is rejected. A single response holds at most 1,000 records. When `is_truncated` is `true`, pass the returned `next_cursor` back as `cursor` to fetch the next page, repeating the time range and every filter unchanged. If no time range is supplied, the query covers the previous hour. The maximum supported time range is seven days. `end_time` is exclusive. **Note**: This endpoint is currently in Private Beta. */
export declare const queryProjectBranchLogs: API.OperationMethod<QueryProjectBranchLogsRequest, ProjectBranchLogsQueryResponse, QueryProjectBranchLogsError, NeonOpContext>;
export type RecoverProjectError = NeonOpError;
/** Recover a deleted project Recovers a deleted project within the 7-day deletion recovery period. Restores branches, endpoints, settings, and connection strings. Some integrations require manual reconfiguration after recovery. To list recoverable projects, use `GET /projects?recoverable=true`. */
export declare const recoverProject: API.OperationMethod<RecoverProjectRequest, RecoverProjectResponse, RecoverProjectError, NeonOpContext>;
export type RegisterProjectBranchCustomDomainError = NeonOpError;
/** Register a custom domain on a branch Registers a customer-owned domain (for example `dashboard.acme.com`) on the branch and points it at a target entity, chosen by `entity_type` + `entity_id`. In v1 only `entity_type: function` is supported (an unsupported type is rejected with `400`), where `entity_id` is the function slug and the function must already exist on the branch (else `404`). The response includes the `cname_target` the customer must point their domain at with a CNAME record; the domain goes live only once that DNS resolves and a certificate is issued on the first request. A domain already registered to another resource is rejected with `409` and no detail about the owner. Re-registering the same domain for the same entity is idempotent. **Note**: This endpoint is currently in Beta. */
export declare const registerProjectBranchCustomDomain: API.OperationMethod<RegisterProjectBranchCustomDomainRequest, CustomDomain, RegisterProjectBranchCustomDomainError, NeonOpContext>;
export type RemoveOrganizationMemberError = NeonOpError;
/** Remove organization member Removes the specified member from the organization. Only organization admins can perform this action. The last admin in an organization cannot be removed. */
export declare const removeOrganizationMember: API.OperationMethod<RemoveOrganizationMemberRequest, RemoveOrganizationMemberResponse, RemoveOrganizationMemberError, NeonOpContext>;
export type RemoveProjectMemberRoleError = NeonOpError;
/** Remove an org member's role on a project Idempotently removes the explicit project grant. The member's organization-role default project permission still applies. Self-DELETE requires `confirm_self_lockout=true` when effective manage access would be lost. */
export declare const removeProjectMemberRole: API.OperationMethod<RemoveProjectMemberRoleRequest, ProjectMemberRoleResponse, RemoveProjectMemberRoleError, NeonOpContext>;
export type ResetProjectBranchRolePasswordError = NotFound | NeonOpError;
/** Reset role password Resets the password for the specified Postgres role. Returns a new password and operations. The new password is ready to use when the last operation finishes. The old password remains valid until last operation finishes. Connections to the compute endpoint are dropped. If idle, the compute endpoint becomes active for a short period of time. For related information, see [Manage roles](https://neon.com/docs/manage/roles/). */
export declare const resetProjectBranchRolePassword: API.OperationMethod<ResetProjectBranchRolePasswordRequest, ResetProjectBranchRolePasswordResponse, ResetProjectBranchRolePasswordError, NeonOpContext>;
export type RestartProjectEndpointError = NotFound | NeonOpError;
/** Restart compute endpoint Restarts the specified compute endpoint by immediately suspending it and then starting it again. An `endpoint_id` has an `ep-` prefix. For information about compute endpoints, see [Manage computes](https://neon.com/docs/manage/endpoints/). */
export declare const restartProjectEndpoint: API.OperationMethod<RestartProjectEndpointRequest, RestartProjectEndpointResponse, RestartProjectEndpointError, NeonOpContext>;
export type RestoreProjectBranchError = NotFound | NeonOpError;
/** Restore branch to a historical state Restores a branch to an earlier state in its own or another branch's history by specifying an LSN or timestamp. Creates a new branch from the historical state. */
export declare const restoreProjectBranch: API.OperationMethod<RestoreProjectBranchRequest, RestoreProjectBranchResponse, RestoreProjectBranchError, NeonOpContext>;
export type RestoreSnapshotError = NeonOpError;
/** Restore snapshot Restores the specified snapshot to a new branch, and optionally finalizes the restore operation to replace the original branch. */
export declare const restoreSnapshot: API.OperationMethod<RestoreSnapshotRequest, RestoreSnapshotResponse, RestoreSnapshotError, NeonOpContext>;
export type RevealCredentialError = NotFound | Conflict | NeonOpError;
/** Reveal a credential's secrets Returns the live `api_token` and `s3_secret_access_key` of an existing credential, so a credential whose issuance response was lost can be recovered without minting a new one. This is a POST with an explicit `/reveal` verb so the secrets never ride a GET, where they would land in access logs, browser history and proxy caches. Revoked and expired credentials return 404, as does a `token_id` that does not belong to this project. A credential issued before secret retrieval was supported has no recoverable secret and returns 409 — rotate it to obtain one. **Note**: This endpoint is currently in Beta. */
export declare const revealCredential: API.OperationMethod<RevealCredentialRequest, CredentialSecret, RevealCredentialError, NeonOpContext>;
export type RevokeApiKeyError = NotFound | NeonOpError;
/** Revoke API key Revokes the specified API key. An API key that is no longer needed can be revoked. This action cannot be reversed. API keys can also be managed in the Neon Console. See [Manage API keys](https://neon.com/docs/manage/api-keys/). */
export declare const revokeApiKey: API.OperationMethod<RevokeApiKeyRequest, ApiKeyRevokeResponse, RevokeApiKeyError, NeonOpContext>;
export type RevokeCredentialError = NotFound | NeonOpError;
/** Revoke a credential Soft-deletes the credential. Idempotent. **Note**: This endpoint is currently in Beta. */
export declare const revokeCredential: API.OperationMethod<RevokeCredentialRequest, RevokeCredentialResponse, RevokeCredentialError, NeonOpContext>;
export type RevokeOrgApiKeyError = NeonOpError;
/** Revoke organization API key Revokes the specified organization API key. An API key that is no longer needed can be revoked. This action cannot be reversed. API keys can also be managed in the Neon Console. See [Manage API keys](https://neon.com/docs/manage/api-keys/). */
export declare const revokeOrgApiKey: API.OperationMethod<RevokeOrgApiKeyRequest, RevokeOrgApiKeyResponse, RevokeOrgApiKeyError, NeonOpContext>;
export type RevokePermissionFromProjectError = NeonOpError;
/** Revoke project access Revokes project access from the user associated with the specified permission `id`. You can retrieve a user's permission `id` by listing project access. */
export declare const revokePermissionFromProject: API.OperationMethod<RevokePermissionFromProjectRequest, ProjectPermission, RevokePermissionFromProjectError, NeonOpContext>;
export type RotateCredentialError = NeonOpError;
/** Rotate a credential's secrets Replaces the secret material on an existing scoped credential in place. `token_id` is preserved — it is the `AWS_ACCESS_KEY_ID` for S3-compatible clients, so the access key id your application already holds keeps working and only the secret changes. This is the analog of resetting a Postgres password, not of issuing a second credential. The response carries the new `api_token` and `s3_secret_access_key` exactly once. Rotation is **not** idempotent: retrying after an ambiguous timeout mints another secret and supersedes the previous replacement, so a retry does not recover a lost response — it only invalidates the secret you did not receive. If you lose the response, issue a replacement credential and revoke this one. The old secret stops authenticating as soon as the rotation commits. Where a region caches credentials on its data-plane verifiers, a replica may briefly keep accepting the old secret — and rejecting the new one — until its cache entry expires; where it does not, the cutover is immediate apart from requests already in flight. Either way the changeover is not atomic across replicas, so retry an unexpected authentication failure right after rotating rather than treating the new secret as bad. `last_used_at` continues to report the logical credential's prior usage and says nothing about whether the new secret has been used yet. Only a live, unexpired, unrevoked customer-managed (`user`) credential on a live project and live branch is eligible. Anything else — including the platform-internal `function` and `system` credentials — is reported as not found, indistinguishable from an unknown `token_id`. **Note**: This endpoint is currently in Beta. */
export declare const rotateCredential: API.OperationMethod<RotateCredentialRequest, RotateCredentialResponse, RotateCredentialError, NeonOpContext>;
export type SendNeonAuthEmailProviderTestError = NeonOpError;
/** Send test email using the saved email provider Sends a test email using the branch's already-saved custom SMTP configuration. Only the `recipient_email` is provided — the stored SMTP settings and password are used server-side, so the caller does not need to re-supply (or be able to read) the password. This avoids the GET response's masked password being sent back, which would fail SMTP authentication. Requires a configured custom SMTP provider on a Better Auth integration. A shared provider, a missing configuration, or a non-Better-Auth integration is rejected. */
export declare const sendNeonAuthEmailProviderTest: API.OperationMethod<SendNeonAuthEmailProviderTestRequest, SendNeonAuthTestEmailResponse, SendNeonAuthEmailProviderTestError, NeonOpContext>;
export type SetDefaultProjectBranchError = NotFound | NeonOpError;
/** Set branch as default Sets the specified branch as the project's default branch. The default designation is automatically removed from the previous default branch. For more information, see [Manage branches](https://neon.com/docs/manage/branches/). */
export declare const setDefaultProjectBranch: API.OperationMethod<SetDefaultProjectBranchRequest, SetDefaultProjectBranchResponse, SetDefaultProjectBranchError, NeonOpContext>;
export type SetOrganizationSpendingLimitError = NeonOpError;
/** Set organization spending limit Sets the monthly spending limit for the specified organization. To remove a previously configured limit, send a DELETE request to this endpoint. When a limit is configured, email notifications are sent at 80% and 100% of the limit. Computes are not suspended when the limit is reached. Available to organization admins on Launch and Scale plans only. */
export declare const setOrganizationSpendingLimit: API.OperationMethod<SetOrganizationSpendingLimitRequest, SpendingLimitResponse, SetOrganizationSpendingLimitError, NeonOpContext>;
export type SetProjectMemberRoleError = NeonOpError;
/** Set an org member's role on a project Idempotently sets or updates the explicit project grant of the specified org member. Self-demotion requires `confirm_self_demotion=true`. */
export declare const setProjectMemberRole: API.OperationMethod<SetProjectMemberRoleRequest, ProjectMemberRoleResponse, SetProjectMemberRoleError, NeonOpContext>;
export type SetSnapshotScheduleError = NeonOpError;
/** Update backup schedule Updates the backup schedule for the specified branch. The schedule defines how often automatic snapshots are created (for example, `daily` or `weekly`). Requires a paid plan. */
export declare const setSnapshotSchedule: API.OperationMethod<SetSnapshotScheduleRequest, SetSnapshotScheduleResponse, SetSnapshotScheduleError, NeonOpContext>;
export type StartAnonymizationError = NeonOpError;
/** Start anonymization Starts the anonymization process for an anonymized branch that is in the initialized, error, or anonymized state. This will apply all defined masking rules to anonymize sensitive data in the branch databases. The branch must be an anonymized branch to start anonymization. **Note**: This endpoint is currently in Beta. */
export declare const startAnonymization: API.OperationMethod<StartAnonymizationRequest, AnonymizedBranchStatusResponse, StartAnonymizationError, NeonOpContext>;
export type StartProjectEndpointError = NotFound | NeonOpError;
/** Start compute endpoint Starts a compute endpoint. The compute endpoint is ready to use after the last operation in the chain finishes successfully. An `endpoint_id` has an `ep-` prefix. For information about compute endpoints, see [Manage computes](https://neon.com/docs/manage/endpoints/). */
export declare const startProjectEndpoint: API.OperationMethod<StartProjectEndpointRequest, StartProjectEndpointResponse, StartProjectEndpointError, NeonOpContext>;
export type SuspendProjectEndpointError = NotFound | NeonOpError;
/** Suspend compute endpoint Suspends the specified compute endpoint. An `endpoint_id` has an `ep-` prefix. For information about compute endpoints, see [Manage computes](https://neon.com/docs/manage/endpoints/). */
export declare const suspendProjectEndpoint: API.OperationMethod<SuspendProjectEndpointRequest, SuspendProjectEndpointResponse, SuspendProjectEndpointError, NeonOpContext>;
export type TransferNeonAuthProviderProjectError = NeonOpError;
/** Transfer Neon-managed auth project to your own account Transfers ownership of your Neon-managed auth project to your own auth provider account. */
export declare const transferNeonAuthProviderProject: API.OperationMethod<TransferNeonAuthProviderProjectRequest, NeonAuthTransferAuthProviderProjectResponse, TransferNeonAuthProviderProjectError, NeonOpContext>;
export type TransferProjectsFromOrgToOrgError = UnprocessableEntity | NeonOpError;
/** Transfer projects between organizations Transfers selected projects, identified by their IDs, from your organization to another specified organization. */
export declare const transferProjectsFromOrgToOrg: API.OperationMethod<TransferProjectsFromOrgToOrgRequest, TransferProjectsFromOrgToOrgResponse, TransferProjectsFromOrgToOrgError, NeonOpContext>;
export type UpdateBranchNeonAuthOauthProviderError = NeonOpError;
/** Update OAuth provider Updates an OAuth provider for the specified project. */
export declare const updateBranchNeonAuthOauthProvider: API.OperationMethod<UpdateBranchNeonAuthOauthProviderRequest, NeonAuthOauthProvider, UpdateBranchNeonAuthOauthProviderError, NeonOpContext>;
export type UpdateMaskingRulesError = NeonOpError;
/** Update masking rules Updates the masking rules for the specified anonymized branch. Masking rules define how sensitive data should be anonymized using PostgreSQL Anonymizer. **Note**: This endpoint is currently in Beta. */
export declare const updateMaskingRules: API.OperationMethod<UpdateMaskingRulesRequest, MaskingRulesResponse, UpdateMaskingRulesError, NeonOpContext>;
export type UpdateNeonAuthAllowLocalhostError = NeonOpError;
/** Update localhost allow setting Updates the localhost allow setting for the specified branch's Neon Auth integration. When enabled, authentication flows work from `localhost` without adding it to the redirect URI whitelist. */
export declare const updateNeonAuthAllowLocalhost: API.OperationMethod<UpdateNeonAuthAllowLocalhostRequest, NeonAuthAllowLocalhostResponse, UpdateNeonAuthAllowLocalhostError, NeonOpContext>;
export type UpdateNeonAuthConfigError = NeonOpError;
/** Update auth configuration Updates the auth configuration for the branch. Currently supports updating the application name used in auth emails. */
export declare const updateNeonAuthConfig: API.OperationMethod<UpdateNeonAuthConfigRequest, NeonAuthConfigResponse, UpdateNeonAuthConfigError, NeonOpContext>;
export type UpdateNeonAuthEmailAndPasswordConfigError = NeonOpError;
/** Update email and password configuration Updates the email and password authentication configuration for the specified branch's Neon Auth integration. Only the fields provided in the request body are updated. */
export declare const updateNeonAuthEmailAndPasswordConfig: API.OperationMethod<UpdateNeonAuthEmailAndPasswordConfigRequest, NeonAuthEmailAndPasswordConfig, UpdateNeonAuthEmailAndPasswordConfigError, NeonOpContext>;
export type UpdateNeonAuthEmailProviderError = NeonOpError;
/** Update email provider configuration Updates the email provider configuration for the specified branch's Neon Auth integration. The email provider handles transactional messages such as verification emails and password reset links. Partial `standard` updates — omitting fields to keep their stored values — are supported only for Better Auth integrations, which merge omitted fields server-side. Legacy Stack Auth integrations do not merge and require all six `standard` fields (`host`, `port`, `username`, `password`, `sender_email`, `sender_name`) on every update; a partial `standard` body is rejected with 400. */
export declare const updateNeonAuthEmailProvider: API.OperationMethod<UpdateNeonAuthEmailProviderRequest, UpdateNeonAuthEmailProviderResponse, UpdateNeonAuthEmailProviderError, NeonOpContext>;
export type UpdateNeonAuthMagicLinkPluginError = NeonOpError;
/** Update magic link plugin configuration Updates the magic link plugin configuration for Neon Auth. The magic link plugin enables passwordless authentication via email magic links. */
export declare const updateNeonAuthMagicLinkPlugin: API.OperationMethod<UpdateNeonAuthMagicLinkPluginRequest, NeonAuthMagicLinkConfig, UpdateNeonAuthMagicLinkPluginError, NeonOpContext>;
export type UpdateNeonAuthOrganizationPluginError = NeonOpError;
/** Update organization plugin configuration Updates the organization plugin configuration for Neon Auth. The organization plugin enables multi-tenant organization support. */
export declare const updateNeonAuthOrganizationPlugin: API.OperationMethod<UpdateNeonAuthOrganizationPluginRequest, NeonAuthOrganizationConfig, UpdateNeonAuthOrganizationPluginError, NeonOpContext>;
export type UpdateNeonAuthPhoneNumberPluginError = NeonOpError;
/** Update phone number plugin configuration Updates the phone number plugin configuration for Neon Auth. Only the fields provided in the request body are updated; omitted fields retain their current values. The phone number plugin enables phone-based OTP authentication. OTP codes are delivered via the `send.otp` webhook event with `delivery_preference: "sms"`. A webhook must be configured with the `send.otp` event enabled for SMS delivery to work. */
export declare const updateNeonAuthPhoneNumberPlugin: API.OperationMethod<UpdateNeonAuthPhoneNumberPluginRequest, NeonAuthPhoneNumberConfig, UpdateNeonAuthPhoneNumberPluginError, NeonOpContext>;
export type UpdateNeonAuthUserRoleError = NeonOpError;
/** Update auth user role Updates the role of a user in the Neon Auth user directory for the specified branch. The role controls the user's level of access within the Neon Auth integration. */
export declare const updateNeonAuthUserRole: API.OperationMethod<UpdateNeonAuthUserRoleRequest, UpdateNeonAuthUserRoleResponse, UpdateNeonAuthUserRoleError, NeonOpContext>;
export type UpdateNeonAuthWebhookConfigError = NeonOpError;
/** Update Neon Auth webhook configuration Updates the webhook configuration for the specified branch's Neon Auth integration. Webhooks notify an external endpoint when auth events occur, such as user creation or sign-in. */
export declare const updateNeonAuthWebhookConfig: API.OperationMethod<UpdateNeonAuthWebhookConfigRequest, NeonAuthWebhookConfig, UpdateNeonAuthWebhookConfigError, NeonOpContext>;
export type UpdateOrganizationMemberError = NeonOpError;
/** Update role for organization member Updates the role of an existing member in the specified organization. The requested role must be valid for the organization. Only organization admins can call this endpoint. */
export declare const updateOrganizationMember: API.OperationMethod<UpdateOrganizationMemberRequest, Member, UpdateOrganizationMemberError, NeonOpContext>;
export type UpdateProjectError = BadRequest | NotFound | NeonOpError;
/** Update project Updates the specified project. Configurable properties include the project name, default compute settings, history retention period, and IP allowlist. */
export declare const updateProject: API.OperationMethod<UpdateProjectRequest, UpdateProjectResponse, UpdateProjectError, NeonOpContext>;
export type UpdateProjectBranchError = BadRequest | NotFound | NeonOpError;
/** Update branch Updates the specified branch. For more information, see [Manage branches](https://neon.com/docs/manage/branches/). */
export declare const updateProjectBranch: API.OperationMethod<UpdateProjectBranchRequest, UpdateProjectBranchResponse, UpdateProjectBranchError, NeonOpContext>;
export type UpdateProjectBranchDataAPIError = NeonOpError;
/** Update Neon Data API Updates the Neon Data API configuration for the specified branch. You can optionally provide settings to update the Data API configuration. The schema cache is always refreshed as part of this operation. */
export declare const updateProjectBranchDataAPI: API.OperationMethod<UpdateProjectBranchDataAPIRequest, UpdateProjectBranchDataAPIResponse, UpdateProjectBranchDataAPIError, NeonOpContext>;
export type UpdateProjectBranchDatabaseError = NotFound | NeonOpError;
/** Update database Updates the specified database in the branch. For related information, see [Manage databases](https://neon.com/docs/manage/databases/). */
export declare const updateProjectBranchDatabase: API.OperationMethod<UpdateProjectBranchDatabaseRequest, UpdateProjectBranchDatabaseResponse, UpdateProjectBranchDatabaseError, NeonOpContext>;
export type UpdateProjectBranchFunctionError = NeonOpError;
/** Update a function Updates the function's mutable metadata — currently only the display `name`. A string sets the display name; `null` clears it, after which the function's `name` falls back to its slug. Leading and trailing whitespace is trimmed; a whitespace-only name is rejected. Acts only on a function owned by the branch: a slug that is only inherited from an ancestor branch returns 404 — rename it on the branch that owns it. Like every other change on a branch, a rename is isolated per branch: a branch forked before the rename keeps the name it had at fork time. **Note**: This endpoint is currently in Beta. */
export declare const updateProjectBranchFunction: API.OperationMethod<UpdateProjectBranchFunctionRequest, NeonFunctionResponse, UpdateProjectBranchFunctionError, NeonOpContext>;
export type UpdateProjectEndpointError = NotFound | NeonOpError;
/** Update compute endpoint Updates the specified compute endpoint. An `endpoint_id` has an `ep-` prefix. A `branch_id` has a `br-` prefix. For more information about compute endpoints, see [Manage computes](https://neon.com/docs/manage/endpoints/). If the returned list of operations is not empty, the compute endpoint is not ready to use. The client must wait for the last operation to finish before using the compute endpoint. If the compute endpoint was idle before the update, it becomes active for a short period of time, and the control plane suspends it again after the update. */
export declare const updateProjectEndpoint: API.OperationMethod<UpdateProjectEndpointRequest, UpdateProjectEndpointResponse, UpdateProjectEndpointError, NeonOpContext>;
export type UpdateSnapshotError = NeonOpError;
/** Update snapshot Updates the specified snapshot. */
export declare const updateSnapshot: API.OperationMethod<UpdateSnapshotRequest, UpdateSnapshotResponse, UpdateSnapshotError, NeonOpContext>;
//# sourceMappingURL=neon.d.ts.map