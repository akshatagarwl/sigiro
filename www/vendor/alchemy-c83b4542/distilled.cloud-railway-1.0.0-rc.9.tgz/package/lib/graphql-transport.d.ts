import * as HttpClient from "effect/unstable/http/HttpClient";
import * as G from "@distilled.cloud/core/graphql";
import { Credentials } from "./credentials.ts";
export type GraphQLRequirements = Credentials | HttpClient.HttpClient;
/** Resolve credentials for each execution, so token rotation and fiber scopes work. */
export declare const transport: G.Transport<GraphQLRequirements>;
//# sourceMappingURL=graphql-transport.d.ts.map