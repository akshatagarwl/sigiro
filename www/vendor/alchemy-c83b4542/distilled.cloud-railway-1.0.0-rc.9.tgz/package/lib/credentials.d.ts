import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
/** Default Railway backboard host. The endpoint path is set per operation. */
export declare const DEFAULT_API_BASE_URL = "https://backboard.railway.com";
/**
 * Which header carries the token.
 *
 * - `"account"` — `Authorization: Bearer <token>`; personal, team, and
 *   workspace tokens from https://railway.com/account/tokens
 * - `"project"` — `Project-Access-Token: <token>`; a token scoped to a single
 *   project environment
 */
export type TokenKind = "account" | "project";
export interface Config {
    readonly token: Redacted.Redacted<string>;
    readonly tokenKind: TokenKind;
    readonly apiBaseUrl: string;
}
/**
 * Build a {@link Config} from a raw token string. Always wraps with this
 * package's `Redacted` so protocol-side `Redacted.value` works even when
 * the caller lives in a different `effect` install (nested distilled vs
 * alchemy workspace).
 */
export declare const toConfig: (config: {
    readonly token: string;
    readonly tokenKind?: TokenKind;
    readonly apiBaseUrl?: string;
}) => Config;
declare const Credentials_base: Context.ServiceClass<Credentials, "RailwayCredentials", Effect.Effect<Config, never, never>>;
export declare class Credentials extends Credentials_base {
}
/** Build {@link Credentials} from an explicit token. */
export declare const CredentialsFromToken: (config: {
    readonly token: string | Redacted.Redacted<string>;
    /** Defaults to `"account"` (the `Authorization: Bearer` header). */
    readonly tokenKind?: TokenKind;
    readonly apiBaseUrl?: string;
}) => Layer.Layer<Credentials>;
/**
 * Build {@link Credentials} from environment variables.
 *
 * - `RAILWAY_API_TOKEN` or `RAILWAY_TOKEN` — an account/team token, sent as
 *   `Authorization: Bearer`. (`RAILWAY_TOKEN` is the name the Railway CLI
 *   uses.)
 * - `RAILWAY_PROJECT_TOKEN` — a project-scoped token, sent as
 *   `Project-Access-Token`.
 * - `RAILWAY_API_URL` (optional) — override the host. Defaults to
 *   `https://backboard.railway.com`.
 *
 * An account token wins when both kinds are set: it is the broader
 * credential, so preferring it keeps every operation reachable instead of
 * silently confining the client to one project environment.
 */
export declare const CredentialsFromEnv: Layer.Layer<Credentials>;
export {};
//# sourceMappingURL=credentials.d.ts.map