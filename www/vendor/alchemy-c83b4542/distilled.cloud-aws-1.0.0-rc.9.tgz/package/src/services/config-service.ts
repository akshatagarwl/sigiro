import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { AwsProtocol } from "../protocol.ts";
import { Retry } from "../retry.ts";
import * as T from "../traits.ts";
import * as C from "../category.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
const ns = T.XmlNamespace("http://config.amazonaws.com/doc/2014-11-12/");
const svc = T.AwsApiService({
  sdkId: "Config Service",
  serviceShapeName: "StarlingDoveService",
});
const auth = T.AwsAuthSigv4({ name: "config" });
const ver = T.ServiceVersion("2014-11-12");
const proto = T.AwsProtocolsAwsJson1_1();
const rules = T.EndpointResolver((p, _) => {
  const { Region, UseDualStack = false, UseFIPS = false, Endpoint } = p;
  const e = (u: unknown, p = {}, h = {}): T.EndpointResolverResult => ({
    type: "endpoint" as const,
    endpoint: { url: u as string, properties: p, headers: h },
  });
  const err = (m: unknown): T.EndpointResolverResult => ({
    type: "error" as const,
    message: m as string,
  });
  if (Endpoint != null) {
    if (UseFIPS === true) {
      return err(
        "Invalid Configuration: FIPS and custom endpoint are not supported",
      );
    }
    if (UseDualStack === true) {
      return err(
        "Invalid Configuration: Dualstack and custom endpoint are not supported",
      );
    }
    return e(Endpoint);
  }
  if (Region != null) {
    {
      const PartitionResult = _.partition(Region);
      if (PartitionResult != null && PartitionResult !== false) {
        if (UseFIPS === true && UseDualStack === true) {
          if (
            true === _.getAttr(PartitionResult, "supportsFIPS") &&
            true === _.getAttr(PartitionResult, "supportsDualStack")
          ) {
            return e(
              `https://config-fips.${Region}.${_.getAttr(PartitionResult, "dualStackDnsSuffix")}`,
            );
          }
          return err(
            "FIPS and DualStack are enabled, but this partition does not support one or both",
          );
        }
        if (UseFIPS === true) {
          if (_.getAttr(PartitionResult, "supportsFIPS") === true) {
            if (_.getAttr(PartitionResult, "name") === "aws-us-gov") {
              return e(`https://config.${Region}.amazonaws.com`);
            }
            return e(
              `https://config-fips.${Region}.${_.getAttr(PartitionResult, "dnsSuffix")}`,
            );
          }
          return err(
            "FIPS is enabled but this partition does not support FIPS",
          );
        }
        if (UseDualStack === true) {
          if (true === _.getAttr(PartitionResult, "supportsDualStack")) {
            return e(
              `https://config.${Region}.${_.getAttr(PartitionResult, "dualStackDnsSuffix")}`,
            );
          }
          return err(
            "DualStack is enabled but this partition does not support DualStack",
          );
        }
        return e(
          `https://config.${Region}.${_.getAttr(PartitionResult, "dnsSuffix")}`,
        );
      }
    }
  }
  return err("Invalid Configuration: Missing Region");
});

export class ConflictException
  extends /*@__PURE__*/ S.TaggedError<ConflictException>()(
    "ConflictException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class ConformancePackTemplateValidationException
  extends /*@__PURE__*/ S.TaggedError<ConformancePackTemplateValidationException>()(
    "ConformancePackTemplateValidationException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class IdempotentParameterMismatch
  extends /*@__PURE__*/ S.TaggedError<IdempotentParameterMismatch>()(
    "IdempotentParameterMismatch",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
    T.HttpError(400),
  ).pipe(C.withBadRequestError, C.withConflictError) {}
export class InsufficientDeliveryPolicyException
  extends /*@__PURE__*/ S.TaggedError<InsufficientDeliveryPolicyException>()(
    "InsufficientDeliveryPolicyException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InsufficientPermissionsException
  extends /*@__PURE__*/ S.TaggedError<InsufficientPermissionsException>()(
    "InsufficientPermissionsException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InvalidConfigurationRecorderNameException
  extends /*@__PURE__*/ S.TaggedError<InvalidConfigurationRecorderNameException>()(
    "InvalidConfigurationRecorderNameException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InvalidDeliveryChannelNameException
  extends /*@__PURE__*/ S.TaggedError<InvalidDeliveryChannelNameException>()(
    "InvalidDeliveryChannelNameException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InvalidExpressionException
  extends /*@__PURE__*/ S.TaggedError<InvalidExpressionException>()(
    "InvalidExpressionException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InvalidLimitException
  extends /*@__PURE__*/ S.TaggedError<InvalidLimitException>()(
    "InvalidLimitException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InvalidNextTokenException
  extends /*@__PURE__*/ S.TaggedError<InvalidNextTokenException>()(
    "InvalidNextTokenException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InvalidParameterValueException
  extends /*@__PURE__*/ S.TaggedError<InvalidParameterValueException>()(
    "InvalidParameterValueException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InvalidRecordingGroupException
  extends /*@__PURE__*/ S.TaggedError<InvalidRecordingGroupException>()(
    "InvalidRecordingGroupException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InvalidResultTokenException
  extends /*@__PURE__*/ S.TaggedError<InvalidResultTokenException>()(
    "InvalidResultTokenException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InvalidRoleException
  extends /*@__PURE__*/ S.TaggedError<InvalidRoleException>()(
    "InvalidRoleException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InvalidS3KeyPrefixException
  extends /*@__PURE__*/ S.TaggedError<InvalidS3KeyPrefixException>()(
    "InvalidS3KeyPrefixException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InvalidS3KmsKeyArnException
  extends /*@__PURE__*/ S.TaggedError<InvalidS3KmsKeyArnException>()(
    "InvalidS3KmsKeyArnException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InvalidSNSTopicARNException
  extends /*@__PURE__*/ S.TaggedError<InvalidSNSTopicARNException>()(
    "InvalidSNSTopicARNException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class InvalidTimeRangeException
  extends /*@__PURE__*/ S.TaggedError<InvalidTimeRangeException>()(
    "InvalidTimeRangeException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class LastDeliveryChannelDeleteFailedException
  extends /*@__PURE__*/ S.TaggedError<LastDeliveryChannelDeleteFailedException>()(
    "LastDeliveryChannelDeleteFailedException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class LimitExceededException
  extends /*@__PURE__*/ S.TaggedError<LimitExceededException>()(
    "LimitExceededException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class MaxActiveResourcesExceededException
  extends /*@__PURE__*/ S.TaggedError<MaxActiveResourcesExceededException>()(
    "MaxActiveResourcesExceededException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class MaxNumberOfConfigRulesExceededException
  extends /*@__PURE__*/ S.TaggedError<MaxNumberOfConfigRulesExceededException>()(
    "MaxNumberOfConfigRulesExceededException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class MaxNumberOfConfigurationRecordersExceededException
  extends /*@__PURE__*/ S.TaggedError<MaxNumberOfConfigurationRecordersExceededException>()(
    "MaxNumberOfConfigurationRecordersExceededException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class MaxNumberOfConformancePacksExceededException
  extends /*@__PURE__*/ S.TaggedError<MaxNumberOfConformancePacksExceededException>()(
    "MaxNumberOfConformancePacksExceededException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class MaxNumberOfConnectorsExceededException
  extends /*@__PURE__*/ S.TaggedError<MaxNumberOfConnectorsExceededException>()(
    "MaxNumberOfConnectorsExceededException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class MaxNumberOfDeliveryChannelsExceededException
  extends /*@__PURE__*/ S.TaggedError<MaxNumberOfDeliveryChannelsExceededException>()(
    "MaxNumberOfDeliveryChannelsExceededException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class MaxNumberOfOrganizationConfigRulesExceededException
  extends /*@__PURE__*/ S.TaggedError<MaxNumberOfOrganizationConfigRulesExceededException>()(
    "MaxNumberOfOrganizationConfigRulesExceededException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class MaxNumberOfOrganizationConformancePacksExceededException
  extends /*@__PURE__*/ S.TaggedError<MaxNumberOfOrganizationConformancePacksExceededException>()(
    "MaxNumberOfOrganizationConformancePacksExceededException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class MaxNumberOfRetentionConfigurationsExceededException
  extends /*@__PURE__*/ S.TaggedError<MaxNumberOfRetentionConfigurationsExceededException>()(
    "MaxNumberOfRetentionConfigurationsExceededException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoAvailableConfigurationRecorderException
  extends /*@__PURE__*/ S.TaggedError<NoAvailableConfigurationRecorderException>()(
    "NoAvailableConfigurationRecorderException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoAvailableDeliveryChannelException
  extends /*@__PURE__*/ S.TaggedError<NoAvailableDeliveryChannelException>()(
    "NoAvailableDeliveryChannelException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoAvailableOrganizationException
  extends /*@__PURE__*/ S.TaggedError<NoAvailableOrganizationException>()(
    "NoAvailableOrganizationException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoRunningConfigurationRecorderException
  extends /*@__PURE__*/ S.TaggedError<NoRunningConfigurationRecorderException>()(
    "NoRunningConfigurationRecorderException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoSuchBucketException
  extends /*@__PURE__*/ S.TaggedError<NoSuchBucketException>()(
    "NoSuchBucketException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoSuchConfigRuleException
  extends /*@__PURE__*/ S.TaggedError<NoSuchConfigRuleException>()(
    "NoSuchConfigRuleException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoSuchConfigRuleInConformancePackException
  extends /*@__PURE__*/ S.TaggedError<NoSuchConfigRuleInConformancePackException>()(
    "NoSuchConfigRuleInConformancePackException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoSuchConfigurationAggregatorException
  extends /*@__PURE__*/ S.TaggedError<NoSuchConfigurationAggregatorException>()(
    "NoSuchConfigurationAggregatorException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoSuchConfigurationRecorderException
  extends /*@__PURE__*/ S.TaggedError<NoSuchConfigurationRecorderException>()(
    "NoSuchConfigurationRecorderException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoSuchConformancePackException
  extends /*@__PURE__*/ S.TaggedError<NoSuchConformancePackException>()(
    "NoSuchConformancePackException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoSuchDeliveryChannelException
  extends /*@__PURE__*/ S.TaggedError<NoSuchDeliveryChannelException>()(
    "NoSuchDeliveryChannelException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoSuchOrganizationConfigRuleException
  extends /*@__PURE__*/ S.TaggedError<NoSuchOrganizationConfigRuleException>()(
    "NoSuchOrganizationConfigRuleException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoSuchOrganizationConformancePackException
  extends /*@__PURE__*/ S.TaggedError<NoSuchOrganizationConformancePackException>()(
    "NoSuchOrganizationConformancePackException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoSuchRemediationConfigurationException
  extends /*@__PURE__*/ S.TaggedError<NoSuchRemediationConfigurationException>()(
    "NoSuchRemediationConfigurationException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoSuchRemediationExceptionException
  extends /*@__PURE__*/ S.TaggedError<NoSuchRemediationExceptionException>()(
    "NoSuchRemediationExceptionException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class NoSuchRetentionConfigurationException
  extends /*@__PURE__*/ S.TaggedError<NoSuchRetentionConfigurationException>()(
    "NoSuchRetentionConfigurationException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class OrganizationAccessDeniedException
  extends /*@__PURE__*/ S.TaggedError<OrganizationAccessDeniedException>()(
    "OrganizationAccessDeniedException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ).pipe(C.withAuthError) {}
export class OrganizationAllFeaturesNotEnabledException
  extends /*@__PURE__*/ S.TaggedError<OrganizationAllFeaturesNotEnabledException>()(
    "OrganizationAllFeaturesNotEnabledException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class OrganizationConformancePackTemplateValidationException
  extends /*@__PURE__*/ S.TaggedError<OrganizationConformancePackTemplateValidationException>()(
    "OrganizationConformancePackTemplateValidationException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class OversizedConfigurationItemException
  extends /*@__PURE__*/ S.TaggedError<OversizedConfigurationItemException>()(
    "OversizedConfigurationItemException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class RemediationInProgressException
  extends /*@__PURE__*/ S.TaggedError<RemediationInProgressException>()(
    "RemediationInProgressException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class ResourceConcurrentModificationException
  extends /*@__PURE__*/ S.TaggedError<ResourceConcurrentModificationException>()(
    "ResourceConcurrentModificationException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class ResourceInUseException
  extends /*@__PURE__*/ S.TaggedError<ResourceInUseException>()(
    "ResourceInUseException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class ResourceNotDiscoveredException
  extends /*@__PURE__*/ S.TaggedError<ResourceNotDiscoveredException>()(
    "ResourceNotDiscoveredException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class ResourceNotFoundException
  extends /*@__PURE__*/ S.TaggedError<ResourceNotFoundException>()(
    "ResourceNotFoundException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class TooManyTagsException
  extends /*@__PURE__*/ S.TaggedError<TooManyTagsException>()(
    "TooManyTagsException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class UnmodifiableEntityException
  extends /*@__PURE__*/ S.TaggedError<UnmodifiableEntityException>()(
    "UnmodifiableEntityException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export class ValidationException
  extends /*@__PURE__*/ S.TaggedError<ValidationException>()(
    "ValidationException",
    { message: S.optional(S.String).pipe(T.ErrorMessage()) },
  ) {}
export type AmazonResourceName = string;
export type ResourceType =
  | "AWS::EC2::CustomerGateway"
  | "AWS::EC2::EIP"
  | "AWS::EC2::Host"
  | "AWS::EC2::Instance"
  | "AWS::EC2::InternetGateway"
  | "AWS::EC2::NetworkAcl"
  | "AWS::EC2::NetworkInterface"
  | "AWS::EC2::RouteTable"
  | "AWS::EC2::SecurityGroup"
  | "AWS::EC2::Subnet"
  | "AWS::CloudTrail::Trail"
  | "AWS::EC2::Volume"
  | "AWS::EC2::VPC"
  | "AWS::EC2::VPNConnection"
  | "AWS::EC2::VPNGateway"
  | "AWS::EC2::RegisteredHAInstance"
  | "AWS::EC2::NatGateway"
  | "AWS::EC2::EgressOnlyInternetGateway"
  | "AWS::EC2::VPCEndpoint"
  | "AWS::EC2::VPCEndpointService"
  | "AWS::EC2::FlowLog"
  | "AWS::EC2::VPCPeeringConnection"
  | "AWS::Elasticsearch::Domain"
  | "AWS::IAM::Group"
  | "AWS::IAM::Policy"
  | "AWS::IAM::Role"
  | "AWS::IAM::User"
  | "AWS::ElasticLoadBalancingV2::LoadBalancer"
  | "AWS::ACM::Certificate"
  | "AWS::RDS::DBInstance"
  | "AWS::RDS::DBSubnetGroup"
  | "AWS::RDS::DBSecurityGroup"
  | "AWS::RDS::DBSnapshot"
  | "AWS::RDS::DBCluster"
  | "AWS::RDS::DBClusterSnapshot"
  | "AWS::RDS::EventSubscription"
  | "AWS::S3::Bucket"
  | "AWS::S3::AccountPublicAccessBlock"
  | "AWS::Redshift::Cluster"
  | "AWS::Redshift::ClusterSnapshot"
  | "AWS::Redshift::ClusterParameterGroup"
  | "AWS::Redshift::ClusterSecurityGroup"
  | "AWS::Redshift::ClusterSubnetGroup"
  | "AWS::Redshift::EventSubscription"
  | "AWS::SSM::ManagedInstanceInventory"
  | "AWS::CloudWatch::Alarm"
  | "AWS::CloudFormation::Stack"
  | "AWS::ElasticLoadBalancing::LoadBalancer"
  | "AWS::AutoScaling::AutoScalingGroup"
  | "AWS::AutoScaling::LaunchConfiguration"
  | "AWS::AutoScaling::ScalingPolicy"
  | "AWS::AutoScaling::ScheduledAction"
  | "AWS::DynamoDB::Table"
  | "AWS::CodeBuild::Project"
  | "AWS::WAF::RateBasedRule"
  | "AWS::WAF::Rule"
  | "AWS::WAF::RuleGroup"
  | "AWS::WAF::WebACL"
  | "AWS::WAFRegional::RateBasedRule"
  | "AWS::WAFRegional::Rule"
  | "AWS::WAFRegional::RuleGroup"
  | "AWS::WAFRegional::WebACL"
  | "AWS::CloudFront::Distribution"
  | "AWS::CloudFront::StreamingDistribution"
  | "AWS::Lambda::Function"
  | "AWS::NetworkFirewall::Firewall"
  | "AWS::NetworkFirewall::FirewallPolicy"
  | "AWS::NetworkFirewall::RuleGroup"
  | "AWS::ElasticBeanstalk::Application"
  | "AWS::ElasticBeanstalk::ApplicationVersion"
  | "AWS::ElasticBeanstalk::Environment"
  | "AWS::WAFv2::WebACL"
  | "AWS::WAFv2::RuleGroup"
  | "AWS::WAFv2::IPSet"
  | "AWS::WAFv2::RegexPatternSet"
  | "AWS::WAFv2::ManagedRuleSet"
  | "AWS::XRay::EncryptionConfig"
  | "AWS::SSM::AssociationCompliance"
  | "AWS::SSM::PatchCompliance"
  | "AWS::Shield::Protection"
  | "AWS::ShieldRegional::Protection"
  | "AWS::Config::ConformancePackCompliance"
  | "AWS::Config::ResourceCompliance"
  | "AWS::ApiGateway::Stage"
  | "AWS::ApiGateway::RestApi"
  | "AWS::ApiGatewayV2::Stage"
  | "AWS::ApiGatewayV2::Api"
  | "AWS::CodePipeline::Pipeline"
  | "AWS::ServiceCatalog::CloudFormationProvisionedProduct"
  | "AWS::ServiceCatalog::CloudFormationProduct"
  | "AWS::ServiceCatalog::Portfolio"
  | "AWS::SQS::Queue"
  | "AWS::KMS::Key"
  | "AWS::QLDB::Ledger"
  | "AWS::SecretsManager::Secret"
  | "AWS::SNS::Topic"
  | "AWS::SSM::FileData"
  | "AWS::Backup::BackupPlan"
  | "AWS::Backup::BackupSelection"
  | "AWS::Backup::BackupVault"
  | "AWS::Backup::RecoveryPoint"
  | "AWS::ECR::Repository"
  | "AWS::ECS::Cluster"
  | "AWS::ECS::Service"
  | "AWS::ECS::TaskDefinition"
  | "AWS::EFS::AccessPoint"
  | "AWS::EFS::FileSystem"
  | "AWS::EKS::Cluster"
  | "AWS::OpenSearch::Domain"
  | "AWS::EC2::TransitGateway"
  | "AWS::Kinesis::Stream"
  | "AWS::Kinesis::StreamConsumer"
  | "AWS::CodeDeploy::Application"
  | "AWS::CodeDeploy::DeploymentConfig"
  | "AWS::CodeDeploy::DeploymentGroup"
  | "AWS::EC2::LaunchTemplate"
  | "AWS::ECR::PublicRepository"
  | "AWS::GuardDuty::Detector"
  | "AWS::EMR::SecurityConfiguration"
  | "AWS::SageMaker::CodeRepository"
  | "AWS::Route53Resolver::ResolverEndpoint"
  | "AWS::Route53Resolver::ResolverRule"
  | "AWS::Route53Resolver::ResolverRuleAssociation"
  | "AWS::DMS::ReplicationSubnetGroup"
  | "AWS::DMS::EventSubscription"
  | "AWS::MSK::Cluster"
  | "AWS::StepFunctions::Activity"
  | "AWS::WorkSpaces::Workspace"
  | "AWS::WorkSpaces::ConnectionAlias"
  | "AWS::SageMaker::Model"
  | "AWS::ElasticLoadBalancingV2::Listener"
  | "AWS::StepFunctions::StateMachine"
  | "AWS::Batch::JobQueue"
  | "AWS::Batch::ComputeEnvironment"
  | "AWS::AccessAnalyzer::Analyzer"
  | "AWS::Athena::WorkGroup"
  | "AWS::Athena::DataCatalog"
  | "AWS::Detective::Graph"
  | "AWS::GlobalAccelerator::Accelerator"
  | "AWS::GlobalAccelerator::EndpointGroup"
  | "AWS::GlobalAccelerator::Listener"
  | "AWS::EC2::TransitGatewayAttachment"
  | "AWS::EC2::TransitGatewayRouteTable"
  | "AWS::DMS::Certificate"
  | "AWS::AppConfig::Application"
  | "AWS::AppSync::GraphQLApi"
  | "AWS::DataSync::LocationSMB"
  | "AWS::DataSync::LocationFSxLustre"
  | "AWS::DataSync::LocationS3"
  | "AWS::DataSync::LocationEFS"
  | "AWS::DataSync::Task"
  | "AWS::DataSync::LocationNFS"
  | "AWS::EC2::NetworkInsightsAccessScopeAnalysis"
  | "AWS::EKS::FargateProfile"
  | "AWS::Glue::Job"
  | "AWS::GuardDuty::ThreatIntelSet"
  | "AWS::GuardDuty::IPSet"
  | "AWS::SageMaker::Workteam"
  | "AWS::SageMaker::NotebookInstanceLifecycleConfig"
  | "AWS::ServiceDiscovery::Service"
  | "AWS::ServiceDiscovery::PublicDnsNamespace"
  | "AWS::SES::ContactList"
  | "AWS::SES::ConfigurationSet"
  | "AWS::Route53::HostedZone"
  | "AWS::IoTEvents::Input"
  | "AWS::IoTEvents::DetectorModel"
  | "AWS::IoTEvents::AlarmModel"
  | "AWS::ServiceDiscovery::HttpNamespace"
  | "AWS::Events::EventBus"
  | "AWS::ImageBuilder::ContainerRecipe"
  | "AWS::ImageBuilder::DistributionConfiguration"
  | "AWS::ImageBuilder::InfrastructureConfiguration"
  | "AWS::DataSync::LocationObjectStorage"
  | "AWS::DataSync::LocationHDFS"
  | "AWS::Glue::Classifier"
  | "AWS::Route53RecoveryReadiness::Cell"
  | "AWS::Route53RecoveryReadiness::ReadinessCheck"
  | "AWS::ECR::RegistryPolicy"
  | "AWS::Backup::ReportPlan"
  | "AWS::Lightsail::Certificate"
  | "AWS::RUM::AppMonitor"
  | "AWS::Events::Endpoint"
  | "AWS::SES::ReceiptRuleSet"
  | "AWS::Events::Archive"
  | "AWS::Events::ApiDestination"
  | "AWS::Lightsail::Disk"
  | "AWS::FIS::ExperimentTemplate"
  | "AWS::DataSync::LocationFSxWindows"
  | "AWS::SES::ReceiptFilter"
  | "AWS::GuardDuty::Filter"
  | "AWS::SES::Template"
  | "AWS::AmazonMQ::Broker"
  | "AWS::AppConfig::Environment"
  | "AWS::AppConfig::ConfigurationProfile"
  | "AWS::Cloud9::EnvironmentEC2"
  | "AWS::EventSchemas::Registry"
  | "AWS::EventSchemas::RegistryPolicy"
  | "AWS::EventSchemas::Discoverer"
  | "AWS::FraudDetector::Label"
  | "AWS::FraudDetector::EntityType"
  | "AWS::FraudDetector::Variable"
  | "AWS::FraudDetector::Outcome"
  | "AWS::IoT::Authorizer"
  | "AWS::IoT::SecurityProfile"
  | "AWS::IoT::RoleAlias"
  | "AWS::IoT::Dimension"
  | "AWS::IoTAnalytics::Datastore"
  | "AWS::Lightsail::Bucket"
  | "AWS::Lightsail::StaticIp"
  | "AWS::MediaPackage::PackagingGroup"
  | "AWS::Route53RecoveryReadiness::RecoveryGroup"
  | "AWS::ResilienceHub::ResiliencyPolicy"
  | "AWS::Transfer::Workflow"
  | "AWS::EKS::IdentityProviderConfig"
  | "AWS::EKS::Addon"
  | "AWS::Glue::MLTransform"
  | "AWS::IoT::Policy"
  | "AWS::IoT::MitigationAction"
  | "AWS::IoTTwinMaker::Workspace"
  | "AWS::IoTTwinMaker::Entity"
  | "AWS::IoTAnalytics::Dataset"
  | "AWS::IoTAnalytics::Pipeline"
  | "AWS::IoTAnalytics::Channel"
  | "AWS::IoTSiteWise::Dashboard"
  | "AWS::IoTSiteWise::Project"
  | "AWS::IoTSiteWise::Portal"
  | "AWS::IoTSiteWise::AssetModel"
  | "AWS::IVS::Channel"
  | "AWS::IVS::RecordingConfiguration"
  | "AWS::IVS::PlaybackKeyPair"
  | "AWS::KinesisAnalyticsV2::Application"
  | "AWS::RDS::GlobalCluster"
  | "AWS::S3::MultiRegionAccessPoint"
  | "AWS::DeviceFarm::TestGridProject"
  | "AWS::Budgets::BudgetsAction"
  | "AWS::Lex::Bot"
  | "AWS::CodeGuruReviewer::RepositoryAssociation"
  | "AWS::IoT::CustomMetric"
  | "AWS::Route53Resolver::FirewallDomainList"
  | "AWS::RoboMaker::RobotApplicationVersion"
  | "AWS::EC2::TrafficMirrorSession"
  | "AWS::IoTSiteWise::Gateway"
  | "AWS::Lex::BotAlias"
  | "AWS::LookoutMetrics::Alert"
  | "AWS::IoT::AccountAuditConfiguration"
  | "AWS::EC2::TrafficMirrorTarget"
  | "AWS::S3::StorageLens"
  | "AWS::IoT::ScheduledAudit"
  | "AWS::Events::Connection"
  | "AWS::EventSchemas::Schema"
  | "AWS::MediaPackage::PackagingConfiguration"
  | "AWS::KinesisVideo::SignalingChannel"
  | "AWS::AppStream::DirectoryConfig"
  | "AWS::LookoutVision::Project"
  | "AWS::Route53RecoveryControl::Cluster"
  | "AWS::Route53RecoveryControl::SafetyRule"
  | "AWS::Route53RecoveryControl::ControlPanel"
  | "AWS::Route53RecoveryControl::RoutingControl"
  | "AWS::Route53RecoveryReadiness::ResourceSet"
  | "AWS::RoboMaker::SimulationApplication"
  | "AWS::RoboMaker::RobotApplication"
  | "AWS::HealthLake::FHIRDatastore"
  | "AWS::Pinpoint::Segment"
  | "AWS::Pinpoint::ApplicationSettings"
  | "AWS::Events::Rule"
  | "AWS::EC2::DHCPOptions"
  | "AWS::EC2::NetworkInsightsPath"
  | "AWS::EC2::TrafficMirrorFilter"
  | "AWS::EC2::IPAM"
  | "AWS::IoTTwinMaker::Scene"
  | "AWS::NetworkManager::TransitGatewayRegistration"
  | "AWS::CustomerProfiles::Domain"
  | "AWS::AutoScaling::WarmPool"
  | "AWS::Connect::PhoneNumber"
  | "AWS::AppConfig::DeploymentStrategy"
  | "AWS::AppFlow::Flow"
  | "AWS::AuditManager::Assessment"
  | "AWS::CloudWatch::MetricStream"
  | "AWS::DeviceFarm::InstanceProfile"
  | "AWS::DeviceFarm::Project"
  | "AWS::EC2::EC2Fleet"
  | "AWS::EC2::SubnetRouteTableAssociation"
  | "AWS::ECR::PullThroughCacheRule"
  | "AWS::GroundStation::Config"
  | "AWS::ImageBuilder::ImagePipeline"
  | "AWS::IoT::FleetMetric"
  | "AWS::IoTWireless::ServiceProfile"
  | "AWS::NetworkManager::Device"
  | "AWS::NetworkManager::GlobalNetwork"
  | "AWS::NetworkManager::Link"
  | "AWS::NetworkManager::Site"
  | "AWS::Panorama::Package"
  | "AWS::Pinpoint::App"
  | "AWS::Redshift::ScheduledAction"
  | "AWS::Route53Resolver::FirewallRuleGroupAssociation"
  | "AWS::SageMaker::AppImageConfig"
  | "AWS::SageMaker::Image"
  | "AWS::ECS::TaskSet"
  | "AWS::Cassandra::Keyspace"
  | "AWS::Signer::SigningProfile"
  | "AWS::Amplify::App"
  | "AWS::AppMesh::VirtualNode"
  | "AWS::AppMesh::VirtualService"
  | "AWS::AppRunner::VpcConnector"
  | "AWS::AppStream::Application"
  | "AWS::CodeArtifact::Repository"
  | "AWS::EC2::PrefixList"
  | "AWS::EC2::SpotFleet"
  | "AWS::Evidently::Project"
  | "AWS::Forecast::Dataset"
  | "AWS::IAM::SAMLProvider"
  | "AWS::IAM::ServerCertificate"
  | "AWS::Pinpoint::Campaign"
  | "AWS::Pinpoint::InAppTemplate"
  | "AWS::SageMaker::Domain"
  | "AWS::Transfer::Agreement"
  | "AWS::Transfer::Connector"
  | "AWS::KinesisFirehose::DeliveryStream"
  | "AWS::Amplify::Branch"
  | "AWS::AppIntegrations::EventIntegration"
  | "AWS::AppMesh::Route"
  | "AWS::Athena::PreparedStatement"
  | "AWS::EC2::IPAMScope"
  | "AWS::Evidently::Launch"
  | "AWS::Forecast::DatasetGroup"
  | "AWS::GreengrassV2::ComponentVersion"
  | "AWS::GroundStation::MissionProfile"
  | "AWS::MediaConnect::FlowEntitlement"
  | "AWS::MediaConnect::FlowVpcInterface"
  | "AWS::MediaTailor::PlaybackConfiguration"
  | "AWS::MSK::Configuration"
  | "AWS::Personalize::Dataset"
  | "AWS::Personalize::Schema"
  | "AWS::Personalize::Solution"
  | "AWS::Pinpoint::EmailTemplate"
  | "AWS::Pinpoint::EventStream"
  | "AWS::ResilienceHub::App"
  | "AWS::ACMPCA::CertificateAuthority"
  | "AWS::AppConfig::HostedConfigurationVersion"
  | "AWS::AppMesh::VirtualGateway"
  | "AWS::AppMesh::VirtualRouter"
  | "AWS::AppRunner::Service"
  | "AWS::CustomerProfiles::ObjectType"
  | "AWS::DMS::Endpoint"
  | "AWS::EC2::CapacityReservation"
  | "AWS::EC2::ClientVpnEndpoint"
  | "AWS::Kendra::Index"
  | "AWS::KinesisVideo::Stream"
  | "AWS::Logs::Destination"
  | "AWS::Pinpoint::EmailChannel"
  | "AWS::S3::AccessPoint"
  | "AWS::NetworkManager::CustomerGatewayAssociation"
  | "AWS::NetworkManager::LinkAssociation"
  | "AWS::IoTWireless::MulticastGroup"
  | "AWS::Personalize::DatasetGroup"
  | "AWS::IoTTwinMaker::ComponentType"
  | "AWS::CodeBuild::ReportGroup"
  | "AWS::SageMaker::FeatureGroup"
  | "AWS::MSK::BatchScramSecret"
  | "AWS::AppStream::Stack"
  | "AWS::IoT::JobTemplate"
  | "AWS::IoTWireless::FuotaTask"
  | "AWS::IoT::ProvisioningTemplate"
  | "AWS::InspectorV2::Filter"
  | "AWS::Route53Resolver::ResolverQueryLoggingConfigAssociation"
  | "AWS::ServiceDiscovery::Instance"
  | "AWS::Transfer::Certificate"
  | "AWS::MediaConnect::FlowSource"
  | "AWS::APS::RuleGroupsNamespace"
  | "AWS::CodeGuruProfiler::ProfilingGroup"
  | "AWS::Route53Resolver::ResolverQueryLoggingConfig"
  | "AWS::Batch::SchedulingPolicy"
  | "AWS::ACMPCA::CertificateAuthorityActivation"
  | "AWS::AppMesh::GatewayRoute"
  | "AWS::AppMesh::Mesh"
  | "AWS::Connect::Instance"
  | "AWS::Connect::QuickConnect"
  | "AWS::EC2::CarrierGateway"
  | "AWS::EC2::IPAMPool"
  | "AWS::EC2::TransitGatewayConnect"
  | "AWS::EC2::TransitGatewayMulticastDomain"
  | "AWS::ECS::CapacityProvider"
  | "AWS::IAM::InstanceProfile"
  | "AWS::IoT::CACertificate"
  | "AWS::IoTTwinMaker::SyncJob"
  | "AWS::KafkaConnect::Connector"
  | "AWS::Lambda::CodeSigningConfig"
  | "AWS::NetworkManager::ConnectPeer"
  | "AWS::ResourceExplorer2::Index"
  | "AWS::AppStream::Fleet"
  | "AWS::Cognito::UserPool"
  | "AWS::Cognito::UserPoolClient"
  | "AWS::Cognito::UserPoolGroup"
  | "AWS::EC2::NetworkInsightsAccessScope"
  | "AWS::EC2::NetworkInsightsAnalysis"
  | "AWS::Grafana::Workspace"
  | "AWS::GroundStation::DataflowEndpointGroup"
  | "AWS::ImageBuilder::ImageRecipe"
  | "AWS::KMS::Alias"
  | "AWS::M2::Environment"
  | "AWS::QuickSight::DataSource"
  | "AWS::QuickSight::Template"
  | "AWS::QuickSight::Theme"
  | "AWS::RDS::OptionGroup"
  | "AWS::Redshift::EndpointAccess"
  | "AWS::Route53Resolver::FirewallRuleGroup"
  | "AWS::SSM::Document"
  | "AWS::AppConfig::ExtensionAssociation"
  | "AWS::AppIntegrations::Application"
  | "AWS::AppSync::ApiCache"
  | "AWS::Bedrock::Guardrail"
  | "AWS::Bedrock::KnowledgeBase"
  | "AWS::Cognito::IdentityPool"
  | "AWS::Connect::Rule"
  | "AWS::Connect::User"
  | "AWS::EC2::ClientVpnTargetNetworkAssociation"
  | "AWS::EC2::EIPAssociation"
  | "AWS::EC2::IPAMResourceDiscovery"
  | "AWS::EC2::IPAMResourceDiscoveryAssociation"
  | "AWS::EC2::InstanceConnectEndpoint"
  | "AWS::EC2::SnapshotBlockPublicAccess"
  | "AWS::EC2::VPCBlockPublicAccessExclusion"
  | "AWS::EC2::VPCBlockPublicAccessOptions"
  | "AWS::EC2::VPCEndpointConnectionNotification"
  | "AWS::EC2::VPNConnectionRoute"
  | "AWS::Evidently::Segment"
  | "AWS::IAM::OIDCProvider"
  | "AWS::InspectorV2::Activation"
  | "AWS::MSK::ClusterPolicy"
  | "AWS::MSK::VpcConnection"
  | "AWS::MediaConnect::Gateway"
  | "AWS::MemoryDB::SubnetGroup"
  | "AWS::OpenSearchServerless::Collection"
  | "AWS::OpenSearchServerless::VpcEndpoint"
  | "AWS::Redshift::EndpointAuthorization"
  | "AWS::Route53Profiles::Profile"
  | "AWS::S3::StorageLensGroup"
  | "AWS::S3Express::BucketPolicy"
  | "AWS::S3Express::DirectoryBucket"
  | "AWS::SageMaker::InferenceExperiment"
  | "AWS::SecurityHub::Standard"
  | "AWS::Transfer::Profile"
  | "AWS::CloudFormation::StackSet"
  | "AWS::MediaPackageV2::Channel"
  | "AWS::S3::AccessGrantsLocation"
  | "AWS::S3::AccessGrant"
  | "AWS::S3::AccessGrantsInstance"
  | "AWS::EMRServerless::Application"
  | "AWS::Config::AggregationAuthorization"
  | "AWS::Bedrock::ApplicationInferenceProfile"
  | "AWS::ApiGatewayV2::Integration"
  | "AWS::SageMaker::MlflowTrackingServer"
  | "AWS::SageMaker::ModelBiasJobDefinition"
  | "AWS::SecretsManager::RotationSchedule"
  | "AWS::Deadline::QueueFleetAssociation"
  | "AWS::ECR::RepositoryCreationTemplate"
  | "AWS::CloudFormation::LambdaHook"
  | "AWS::EC2::SubnetNetworkAclAssociation"
  | "AWS::ApiGateway::UsagePlan"
  | "AWS::AppConfig::Extension"
  | "AWS::Deadline::Fleet"
  | "AWS::EMR::Studio"
  | "AWS::S3Tables::TableBucket"
  | "AWS::CloudFront::RealtimeLogConfig"
  | "AWS::BackupGateway::Hypervisor"
  | "AWS::BCMDataExports::Export"
  | "AWS::CloudFormation::GuardHook"
  | "AWS::CloudFront::PublicKey"
  | "AWS::CloudTrail::EventDataStore"
  | "AWS::EntityResolution::IdMappingWorkflow"
  | "AWS::EntityResolution::SchemaMapping"
  | "AWS::IoT::DomainConfiguration"
  | "AWS::PCAConnectorAD::DirectoryRegistration"
  | "AWS::RDS::Integration"
  | "AWS::Config::ConformancePack"
  | "AWS::RolesAnywhere::Profile"
  | "AWS::CodeArtifact::Domain"
  | "AWS::Backup::RestoreTestingPlan"
  | "AWS::Config::StoredQuery"
  | "AWS::SageMaker::DataQualityJobDefinition"
  | "AWS::SageMaker::ModelExplainabilityJobDefinition"
  | "AWS::SageMaker::ModelQualityJobDefinition"
  | "AWS::SageMaker::StudioLifecycleConfig"
  | "AWS::SES::DedicatedIpPool"
  | "AWS::SES::MailManagerTrafficPolicy"
  | "AWS::SSM::ResourceDataSync"
  | "AWS::BedrockAgentCore::Runtime"
  | "AWS::BedrockAgentCore::BrowserCustom"
  | "AWS::ElasticLoadBalancingV2::TargetGroup"
  | "AWS::EMRContainers::VirtualCluster"
  | "AWS::EntityResolution::MatchingWorkflow"
  | "AWS::IoTCoreDeviceAdvisor::SuiteDefinition"
  | "AWS::EC2::SecurityGroupVpcAssociation"
  | "AWS::EC2::VerifiedAccessInstance"
  | "AWS::KafkaConnect::CustomPlugin"
  | "AWS::NetworkManager::TransitGatewayPeering"
  | "AWS::OpenSearchServerless::SecurityConfig"
  | "AWS::Redshift::Integration"
  | "AWS::RolesAnywhere::TrustAnchor"
  | "AWS::Route53Profiles::ProfileAssociation"
  | "AWS::SSMIncidents::ResponsePlan"
  | "AWS::Transfer::Server"
  | "AWS::Glue::Database"
  | "AWS::Organizations::OrganizationalUnit"
  | "AWS::EC2::IPAMPoolCidr"
  | "AWS::EC2::VPCGatewayAttachment"
  | "AWS::Bedrock::Prompt"
  | "AWS::Comprehend::Flywheel"
  | "AWS::DataSync::Agent"
  | "AWS::MediaTailor::LiveSource"
  | "AWS::MSK::ServerlessCluster"
  | "AWS::IoTSiteWise::Asset"
  | "AWS::B2BI::Capability"
  | "AWS::CloudFront::KeyValueStore"
  | "AWS::Deadline::Monitor"
  | "AWS::GuardDuty::MalwareProtectionPlan"
  | "AWS::Location::APIKey"
  | "AWS::MediaPackageV2::OriginEndpoint"
  | "AWS::PCAConnectorAD::Connector"
  | "AWS::S3Tables::TableBucketPolicy"
  | "AWS::SecretsManager::ResourcePolicy"
  | "AWS::SSMContacts::Contact"
  | "AWS::IoT::ThingGroup"
  | "AWS::ImageBuilder::LifecyclePolicy"
  | "AWS::GameLift::Build"
  | "AWS::ECR::ReplicationConfiguration"
  | "AWS::EC2::SubnetCidrBlock"
  | "AWS::Connect::SecurityProfile"
  | "AWS::CleanRoomsML::TrainingDataset"
  | "AWS::AppStream::AppBlockBuilder"
  | "AWS::Route53::DNSSEC"
  | "AWS::SageMaker::UserProfile"
  | "AWS::ApiGateway::Method"
  | (string & {});
export const ResourceType = S.String;

export type ResourceTypeList = ResourceType[];
export const ResourceTypeList = /*@__PURE__*/ S.Array(ResourceType);
export interface AssociateResourceTypesRequest {
  ConfigurationRecorderArn: string;
  ResourceTypes: ResourceType[];
}
export const AssociateResourceTypesRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigurationRecorderArn: S.String,
    ResourceTypes: ResourceTypeList,
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "AssociateResourceTypesRequest",
}) as any as S.Schema<AssociateResourceTypesRequest>;
export type RecorderName = string;
export type AllSupported = boolean;
export type IncludeGlobalResourceTypes = boolean;
export interface ExclusionByResourceTypes {
  resourceTypes?: ResourceType[];
}
export const ExclusionByResourceTypes = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ resourceTypes: S.optional(ResourceTypeList) }),
).annotate({
  identifier: "ExclusionByResourceTypes",
}) as any as S.Schema<ExclusionByResourceTypes>;
export type RecordingStrategyType =
  | "ALL_SUPPORTED_RESOURCE_TYPES"
  | "INCLUSION_BY_RESOURCE_TYPES"
  | "EXCLUSION_BY_RESOURCE_TYPES"
  | (string & {});
export const RecordingStrategyType = S.String;

export interface RecordingStrategy {
  useOnly?: RecordingStrategyType;
}
export const RecordingStrategy = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ useOnly: S.optional(RecordingStrategyType) }),
).annotate({
  identifier: "RecordingStrategy",
}) as any as S.Schema<RecordingStrategy>;
export interface RecordingGroup {
  allSupported?: boolean;
  includeGlobalResourceTypes?: boolean;
  resourceTypes?: ResourceType[];
  exclusionByResourceTypes?: ExclusionByResourceTypes;
  recordingStrategy?: RecordingStrategy;
}
export const RecordingGroup = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    allSupported: S.optional(S.Boolean),
    includeGlobalResourceTypes: S.optional(S.Boolean),
    resourceTypes: S.optional(ResourceTypeList),
    exclusionByResourceTypes: S.optional(ExclusionByResourceTypes),
    recordingStrategy: S.optional(RecordingStrategy),
  }),
).annotate({ identifier: "RecordingGroup" }) as any as S.Schema<RecordingGroup>;
export type RecordingFrequency = "CONTINUOUS" | "DAILY" | (string & {});
export const RecordingFrequency = S.String;

export type Description = string;
export type RecordingModeResourceTypesList = ResourceType[];
export const RecordingModeResourceTypesList =
  /*@__PURE__*/ S.Array(ResourceType);
export interface RecordingModeOverride {
  description?: string;
  resourceTypes: ResourceType[];
  recordingFrequency: RecordingFrequency;
}
export const RecordingModeOverride = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    description: S.optional(S.String),
    resourceTypes: RecordingModeResourceTypesList,
    recordingFrequency: RecordingFrequency,
  }),
).annotate({
  identifier: "RecordingModeOverride",
}) as any as S.Schema<RecordingModeOverride>;
export type RecordingModeOverrides = RecordingModeOverride[];
export const RecordingModeOverrides = /*@__PURE__*/ S.Array(
  RecordingModeOverride,
);
export interface RecordingMode {
  recordingFrequency: RecordingFrequency;
  recordingModeOverrides?: RecordingModeOverride[];
}
export const RecordingMode = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    recordingFrequency: RecordingFrequency,
    recordingModeOverrides: S.optional(RecordingModeOverrides),
  }),
).annotate({ identifier: "RecordingMode" }) as any as S.Schema<RecordingMode>;
export type RecordingScope = "INTERNAL" | "PAID" | (string & {});
export const RecordingScope = S.String;

export type ServicePrincipal = string;
export type ScopeType = string;
export type ScopeValue = string;
export type ScopeValues = string[];
export const ScopeValues = /*@__PURE__*/ S.Array(S.String);
export type ThirdPartyCloudRegion = string;
export type IncludedRegions = string[];
export const IncludedRegions = /*@__PURE__*/ S.Array(S.String);
export interface ScopeConfiguration {
  scopeType: string;
  scopeValues?: string[];
  allRegions: boolean;
  includedRegions?: string[];
}
export const ScopeConfiguration = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    scopeType: S.String,
    scopeValues: S.optional(ScopeValues),
    allRegions: S.Boolean,
    includedRegions: S.optional(IncludedRegions),
  }),
).annotate({
  identifier: "ScopeConfiguration",
}) as any as S.Schema<ScopeConfiguration>;
export interface ConfigurationRecorder {
  arn?: string;
  name?: string;
  roleARN?: string;
  recordingGroup?: RecordingGroup;
  recordingMode?: RecordingMode;
  recordingScope?: RecordingScope;
  servicePrincipal?: string;
  connectorArn?: string;
  scopeConfiguration?: ScopeConfiguration;
}
export const ConfigurationRecorder = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    arn: S.optional(S.String),
    name: S.optional(S.String),
    roleARN: S.optional(S.String),
    recordingGroup: S.optional(RecordingGroup),
    recordingMode: S.optional(RecordingMode),
    recordingScope: S.optional(RecordingScope),
    servicePrincipal: S.optional(S.String),
    connectorArn: S.optional(S.String),
    scopeConfiguration: S.optional(ScopeConfiguration),
  }),
).annotate({
  identifier: "ConfigurationRecorder",
}) as any as S.Schema<ConfigurationRecorder>;
export interface AssociateResourceTypesResponse {
  ConfigurationRecorder: ConfigurationRecorder;
}
export const AssociateResourceTypesResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConfigurationRecorder: ConfigurationRecorder }).pipe(ns),
).annotate({
  identifier: "AssociateResourceTypesResponse",
}) as any as S.Schema<AssociateResourceTypesResponse>;
export type ConfigurationAggregatorName = string;
export type AccountId = string;
export type AwsRegion = string;
export type ResourceId = string;
export type ResourceName = string;
export interface AggregateResourceIdentifier {
  SourceAccountId: string;
  SourceRegion: string;
  ResourceId: string;
  ResourceType: ResourceType;
  ResourceName?: string;
}
export const AggregateResourceIdentifier = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    SourceAccountId: S.String,
    SourceRegion: S.String,
    ResourceId: S.String,
    ResourceType: ResourceType,
    ResourceName: S.optional(S.String),
  }),
).annotate({
  identifier: "AggregateResourceIdentifier",
}) as any as S.Schema<AggregateResourceIdentifier>;
export type ResourceIdentifiersList = AggregateResourceIdentifier[];
export const ResourceIdentifiersList = /*@__PURE__*/ S.Array(
  AggregateResourceIdentifier,
);
export interface BatchGetAggregateResourceConfigRequest {
  ConfigurationAggregatorName: string;
  ResourceIdentifiers: AggregateResourceIdentifier[];
}
export const BatchGetAggregateResourceConfigRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConfigurationAggregatorName: S.String,
      ResourceIdentifiers: ResourceIdentifiersList,
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "BatchGetAggregateResourceConfigRequest",
}) as any as S.Schema<BatchGetAggregateResourceConfigRequest>;
export type Version = string;
export type ConfigurationItemCaptureTime = Date;
export type ConfigurationItemStatus =
  | "OK"
  | "ResourceDiscovered"
  | "ResourceNotRecorded"
  | "ResourceDeleted"
  | "ResourceDeletedNotRecorded"
  | (string & {});
export const ConfigurationItemStatus = S.String;

export type ConfigurationStateId = string;
export type ARN = string;
export type AvailabilityZone = string;
export type ResourceCreationTime = Date;
export type Configuration = string;
export type SupplementaryConfigurationName = string;
export type SupplementaryConfigurationValue = string;
export type SupplementaryConfiguration = { [key: string]: string | undefined };
export const SupplementaryConfiguration = /*@__PURE__*/ S.Record(
  S.String,
  S.String.pipe(S.optional),
);
export type ConfigurationItemDeliveryTime = Date;
export interface BaseConfigurationItem {
  version?: string;
  accountId?: string;
  configurationItemCaptureTime?: Date;
  configurationItemStatus?: ConfigurationItemStatus;
  configurationStateId?: string;
  arn?: string;
  resourceType?: ResourceType;
  resourceId?: string;
  resourceName?: string;
  awsRegion?: string;
  availabilityZone?: string;
  resourceCreationTime?: Date;
  configuration?: string;
  supplementaryConfiguration?: { [key: string]: string | undefined };
  recordingFrequency?: RecordingFrequency;
  configurationItemDeliveryTime?: Date;
}
export const BaseConfigurationItem = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    version: S.optional(S.String),
    accountId: S.optional(S.String),
    configurationItemCaptureTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    configurationItemStatus: S.optional(ConfigurationItemStatus),
    configurationStateId: S.optional(S.String),
    arn: S.optional(S.String),
    resourceType: S.optional(ResourceType),
    resourceId: S.optional(S.String),
    resourceName: S.optional(S.String),
    awsRegion: S.optional(S.String),
    availabilityZone: S.optional(S.String),
    resourceCreationTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    configuration: S.optional(S.String),
    supplementaryConfiguration: S.optional(SupplementaryConfiguration),
    recordingFrequency: S.optional(RecordingFrequency),
    configurationItemDeliveryTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
  }),
).annotate({
  identifier: "BaseConfigurationItem",
}) as any as S.Schema<BaseConfigurationItem>;
export type BaseConfigurationItems = BaseConfigurationItem[];
export const BaseConfigurationItems = /*@__PURE__*/ S.Array(
  BaseConfigurationItem,
);
export type UnprocessedResourceIdentifierList = AggregateResourceIdentifier[];
export const UnprocessedResourceIdentifierList = /*@__PURE__*/ S.Array(
  AggregateResourceIdentifier,
);
export interface BatchGetAggregateResourceConfigResponse {
  BaseConfigurationItems?: BaseConfigurationItem[];
  UnprocessedResourceIdentifiers?: AggregateResourceIdentifier[];
}
export const BatchGetAggregateResourceConfigResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      BaseConfigurationItems: S.optional(BaseConfigurationItems),
      UnprocessedResourceIdentifiers: S.optional(
        UnprocessedResourceIdentifierList,
      ),
    }).pipe(ns),
).annotate({
  identifier: "BatchGetAggregateResourceConfigResponse",
}) as any as S.Schema<BatchGetAggregateResourceConfigResponse>;
export interface ResourceKey {
  resourceType: ResourceType;
  resourceId: string;
}
export const ResourceKey = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ resourceType: ResourceType, resourceId: S.String }),
).annotate({ identifier: "ResourceKey" }) as any as S.Schema<ResourceKey>;
export type ResourceKeys = ResourceKey[];
export const ResourceKeys = /*@__PURE__*/ S.Array(ResourceKey);
export interface BatchGetResourceConfigRequest {
  resourceKeys: ResourceKey[];
}
export const BatchGetResourceConfigRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ resourceKeys: ResourceKeys }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "BatchGetResourceConfigRequest",
}) as any as S.Schema<BatchGetResourceConfigRequest>;
export interface BatchGetResourceConfigResponse {
  baseConfigurationItems?: BaseConfigurationItem[];
  unprocessedResourceKeys?: ResourceKey[];
}
export const BatchGetResourceConfigResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    baseConfigurationItems: S.optional(BaseConfigurationItems),
    unprocessedResourceKeys: S.optional(ResourceKeys),
  }).pipe(ns),
).annotate({
  identifier: "BatchGetResourceConfigResponse",
}) as any as S.Schema<BatchGetResourceConfigResponse>;
export interface DeleteAggregationAuthorizationRequest {
  AuthorizedAccountId: string;
  AuthorizedAwsRegion: string;
}
export const DeleteAggregationAuthorizationRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      AuthorizedAccountId: S.String,
      AuthorizedAwsRegion: S.String,
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DeleteAggregationAuthorizationRequest",
}) as any as S.Schema<DeleteAggregationAuthorizationRequest>;
export interface DeleteAggregationAuthorizationResponse {}
export const DeleteAggregationAuthorizationResponse = /*@__PURE__*/ S.suspend(
  () => S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeleteAggregationAuthorizationResponse",
}) as any as S.Schema<DeleteAggregationAuthorizationResponse>;
export type ConfigRuleName = string;
export interface DeleteConfigRuleRequest {
  ConfigRuleName: string;
}
export const DeleteConfigRuleRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConfigRuleName: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DeleteConfigRuleRequest",
}) as any as S.Schema<DeleteConfigRuleRequest>;
export interface DeleteConfigRuleResponse {}
export const DeleteConfigRuleResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeleteConfigRuleResponse",
}) as any as S.Schema<DeleteConfigRuleResponse>;
export interface DeleteConfigurationAggregatorRequest {
  ConfigurationAggregatorName: string;
}
export const DeleteConfigurationAggregatorRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({ ConfigurationAggregatorName: S.String }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DeleteConfigurationAggregatorRequest",
}) as any as S.Schema<DeleteConfigurationAggregatorRequest>;
export interface DeleteConfigurationAggregatorResponse {}
export const DeleteConfigurationAggregatorResponse = /*@__PURE__*/ S.suspend(
  () => S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeleteConfigurationAggregatorResponse",
}) as any as S.Schema<DeleteConfigurationAggregatorResponse>;
export interface DeleteConfigurationRecorderRequest {
  ConfigurationRecorderName: string;
}
export const DeleteConfigurationRecorderRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConfigurationRecorderName: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DeleteConfigurationRecorderRequest",
}) as any as S.Schema<DeleteConfigurationRecorderRequest>;
export interface DeleteConfigurationRecorderResponse {}
export const DeleteConfigurationRecorderResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeleteConfigurationRecorderResponse",
}) as any as S.Schema<DeleteConfigurationRecorderResponse>;
export type ConformancePackName = string;
export interface DeleteConformancePackRequest {
  ConformancePackName: string;
}
export const DeleteConformancePackRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConformancePackName: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DeleteConformancePackRequest",
}) as any as S.Schema<DeleteConformancePackRequest>;
export interface DeleteConformancePackResponse {}
export const DeleteConformancePackResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeleteConformancePackResponse",
}) as any as S.Schema<DeleteConformancePackResponse>;
export interface DeleteConnectorRequest {
  Arn: string;
}
export const DeleteConnectorRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ Arn: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DeleteConnectorRequest",
}) as any as S.Schema<DeleteConnectorRequest>;
export interface DeleteConnectorResponse {}
export const DeleteConnectorResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeleteConnectorResponse",
}) as any as S.Schema<DeleteConnectorResponse>;
export type ChannelName = string;
export interface DeleteDeliveryChannelRequest {
  DeliveryChannelName: string;
}
export const DeleteDeliveryChannelRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ DeliveryChannelName: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DeleteDeliveryChannelRequest",
}) as any as S.Schema<DeleteDeliveryChannelRequest>;
export interface DeleteDeliveryChannelResponse {}
export const DeleteDeliveryChannelResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeleteDeliveryChannelResponse",
}) as any as S.Schema<DeleteDeliveryChannelResponse>;
export type StringWithCharLimit64 = string;
export interface DeleteEvaluationResultsRequest {
  ConfigRuleName: string;
}
export const DeleteEvaluationResultsRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConfigRuleName: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DeleteEvaluationResultsRequest",
}) as any as S.Schema<DeleteEvaluationResultsRequest>;
export interface DeleteEvaluationResultsResponse {}
export const DeleteEvaluationResultsResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeleteEvaluationResultsResponse",
}) as any as S.Schema<DeleteEvaluationResultsResponse>;
export type OrganizationConfigRuleName = string;
export interface DeleteOrganizationConfigRuleRequest {
  OrganizationConfigRuleName: string;
}
export const DeleteOrganizationConfigRuleRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ OrganizationConfigRuleName: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DeleteOrganizationConfigRuleRequest",
}) as any as S.Schema<DeleteOrganizationConfigRuleRequest>;
export interface DeleteOrganizationConfigRuleResponse {}
export const DeleteOrganizationConfigRuleResponse = /*@__PURE__*/ S.suspend(
  () => S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeleteOrganizationConfigRuleResponse",
}) as any as S.Schema<DeleteOrganizationConfigRuleResponse>;
export type OrganizationConformancePackName = string;
export interface DeleteOrganizationConformancePackRequest {
  OrganizationConformancePackName: string;
}
export const DeleteOrganizationConformancePackRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({ OrganizationConformancePackName: S.String }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DeleteOrganizationConformancePackRequest",
}) as any as S.Schema<DeleteOrganizationConformancePackRequest>;
export interface DeleteOrganizationConformancePackResponse {}
export const DeleteOrganizationConformancePackResponse =
  /*@__PURE__*/ S.suspend(() => S.Struct({}).pipe(ns)).annotate({
    identifier: "DeleteOrganizationConformancePackResponse",
  }) as any as S.Schema<DeleteOrganizationConformancePackResponse>;
export interface DeletePendingAggregationRequestRequest {
  RequesterAccountId: string;
  RequesterAwsRegion: string;
}
export const DeletePendingAggregationRequestRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      RequesterAccountId: S.String,
      RequesterAwsRegion: S.String,
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DeletePendingAggregationRequestRequest",
}) as any as S.Schema<DeletePendingAggregationRequestRequest>;
export interface DeletePendingAggregationRequestResponse {}
export const DeletePendingAggregationRequestResponse = /*@__PURE__*/ S.suspend(
  () => S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeletePendingAggregationRequestResponse",
}) as any as S.Schema<DeletePendingAggregationRequestResponse>;
export interface DeleteRemediationConfigurationRequest {
  ConfigRuleName: string;
  ResourceType?: string;
}
export const DeleteRemediationConfigurationRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConfigRuleName: S.String,
      ResourceType: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DeleteRemediationConfigurationRequest",
}) as any as S.Schema<DeleteRemediationConfigurationRequest>;
export interface DeleteRemediationConfigurationResponse {}
export const DeleteRemediationConfigurationResponse = /*@__PURE__*/ S.suspend(
  () => S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeleteRemediationConfigurationResponse",
}) as any as S.Schema<DeleteRemediationConfigurationResponse>;
export type StringWithCharLimit256 = string;
export type StringWithCharLimit1024 = string;
export interface RemediationExceptionResourceKey {
  ResourceType?: string;
  ResourceId?: string;
}
export const RemediationExceptionResourceKey = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceType: S.optional(S.String),
    ResourceId: S.optional(S.String),
  }),
).annotate({
  identifier: "RemediationExceptionResourceKey",
}) as any as S.Schema<RemediationExceptionResourceKey>;
export type RemediationExceptionResourceKeys =
  RemediationExceptionResourceKey[];
export const RemediationExceptionResourceKeys = /*@__PURE__*/ S.Array(
  RemediationExceptionResourceKey,
);
export interface DeleteRemediationExceptionsRequest {
  ConfigRuleName: string;
  ResourceKeys: RemediationExceptionResourceKey[];
}
export const DeleteRemediationExceptionsRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleName: S.String,
    ResourceKeys: RemediationExceptionResourceKeys,
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DeleteRemediationExceptionsRequest",
}) as any as S.Schema<DeleteRemediationExceptionsRequest>;
export interface FailedDeleteRemediationExceptionsBatch {
  FailureMessage?: string;
  FailedItems?: RemediationExceptionResourceKey[];
}
export const FailedDeleteRemediationExceptionsBatch = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      FailureMessage: S.optional(S.String),
      FailedItems: S.optional(RemediationExceptionResourceKeys),
    }),
).annotate({
  identifier: "FailedDeleteRemediationExceptionsBatch",
}) as any as S.Schema<FailedDeleteRemediationExceptionsBatch>;
export type FailedDeleteRemediationExceptionsBatches =
  FailedDeleteRemediationExceptionsBatch[];
export const FailedDeleteRemediationExceptionsBatches = /*@__PURE__*/ S.Array(
  FailedDeleteRemediationExceptionsBatch,
);
export interface DeleteRemediationExceptionsResponse {
  FailedBatches?: FailedDeleteRemediationExceptionsBatch[];
}
export const DeleteRemediationExceptionsResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    FailedBatches: S.optional(FailedDeleteRemediationExceptionsBatches),
  }).pipe(ns),
).annotate({
  identifier: "DeleteRemediationExceptionsResponse",
}) as any as S.Schema<DeleteRemediationExceptionsResponse>;
export type ResourceTypeString = string;
export interface DeleteResourceConfigRequest {
  ResourceType: string;
  ResourceId: string;
}
export const DeleteResourceConfigRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ResourceType: S.String, ResourceId: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DeleteResourceConfigRequest",
}) as any as S.Schema<DeleteResourceConfigRequest>;
export interface DeleteResourceConfigResponse {}
export const DeleteResourceConfigResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeleteResourceConfigResponse",
}) as any as S.Schema<DeleteResourceConfigResponse>;
export type RetentionConfigurationName = string;
export interface DeleteRetentionConfigurationRequest {
  RetentionConfigurationName: string;
}
export const DeleteRetentionConfigurationRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ RetentionConfigurationName: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DeleteRetentionConfigurationRequest",
}) as any as S.Schema<DeleteRetentionConfigurationRequest>;
export interface DeleteRetentionConfigurationResponse {}
export const DeleteRetentionConfigurationResponse = /*@__PURE__*/ S.suspend(
  () => S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeleteRetentionConfigurationResponse",
}) as any as S.Schema<DeleteRetentionConfigurationResponse>;
export interface DeleteServiceLinkedConfigurationRecorderRequest {
  ServicePrincipal?: string;
  Arn?: string;
}
export const DeleteServiceLinkedConfigurationRecorderRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ServicePrincipal: S.optional(S.String),
      Arn: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "DeleteServiceLinkedConfigurationRecorderRequest",
  }) as any as S.Schema<DeleteServiceLinkedConfigurationRecorderRequest>;
export interface DeleteServiceLinkedConfigurationRecorderResponse {
  Arn: string;
  Name: string;
}
export const DeleteServiceLinkedConfigurationRecorderResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({ Arn: S.String, Name: S.String }).pipe(ns),
  ).annotate({
    identifier: "DeleteServiceLinkedConfigurationRecorderResponse",
  }) as any as S.Schema<DeleteServiceLinkedConfigurationRecorderResponse>;
export type QueryName = string;
export interface DeleteStoredQueryRequest {
  QueryName: string;
}
export const DeleteStoredQueryRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ QueryName: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DeleteStoredQueryRequest",
}) as any as S.Schema<DeleteStoredQueryRequest>;
export interface DeleteStoredQueryResponse {}
export const DeleteStoredQueryResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "DeleteStoredQueryResponse",
}) as any as S.Schema<DeleteStoredQueryResponse>;
export interface DeliverConfigSnapshotRequest {
  deliveryChannelName: string;
}
export const DeliverConfigSnapshotRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ deliveryChannelName: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DeliverConfigSnapshotRequest",
}) as any as S.Schema<DeliverConfigSnapshotRequest>;
export interface DeliverConfigSnapshotResponse {
  configSnapshotId?: string;
}
export const DeliverConfigSnapshotResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ configSnapshotId: S.optional(S.String) }).pipe(ns),
).annotate({
  identifier: "DeliverConfigSnapshotResponse",
}) as any as S.Schema<DeliverConfigSnapshotResponse>;
export type ComplianceType =
  | "COMPLIANT"
  | "NON_COMPLIANT"
  | "NOT_APPLICABLE"
  | "INSUFFICIENT_DATA"
  | (string & {});
export const ComplianceType = S.String;

export interface ConfigRuleComplianceFilters {
  ConfigRuleName?: string;
  ComplianceType?: ComplianceType;
  AccountId?: string;
  AwsRegion?: string;
}
export const ConfigRuleComplianceFilters = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleName: S.optional(S.String),
    ComplianceType: S.optional(ComplianceType),
    AccountId: S.optional(S.String),
    AwsRegion: S.optional(S.String),
  }),
).annotate({
  identifier: "ConfigRuleComplianceFilters",
}) as any as S.Schema<ConfigRuleComplianceFilters>;
export type GroupByAPILimit = number;
export type NextToken = string;
export interface DescribeAggregateComplianceByConfigRulesRequest {
  ConfigurationAggregatorName: string;
  Filters?: ConfigRuleComplianceFilters;
  Limit?: number;
  NextToken?: string;
}
export const DescribeAggregateComplianceByConfigRulesRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConfigurationAggregatorName: S.String,
      Filters: S.optional(ConfigRuleComplianceFilters),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "DescribeAggregateComplianceByConfigRulesRequest",
  }) as any as S.Schema<DescribeAggregateComplianceByConfigRulesRequest>;
export interface ComplianceContributorCount {
  CappedCount?: number;
  CapExceeded?: boolean;
}
export const ComplianceContributorCount = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    CappedCount: S.optional(S.Number),
    CapExceeded: S.optional(S.Boolean),
  }),
).annotate({
  identifier: "ComplianceContributorCount",
}) as any as S.Schema<ComplianceContributorCount>;
export interface Compliance {
  ComplianceType?: ComplianceType;
  ComplianceContributorCount?: ComplianceContributorCount;
}
export const Compliance = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ComplianceType: S.optional(ComplianceType),
    ComplianceContributorCount: S.optional(ComplianceContributorCount),
  }),
).annotate({ identifier: "Compliance" }) as any as S.Schema<Compliance>;
export interface AggregateComplianceByConfigRule {
  ConfigRuleName?: string;
  Compliance?: Compliance;
  AccountId?: string;
  AwsRegion?: string;
}
export const AggregateComplianceByConfigRule = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleName: S.optional(S.String),
    Compliance: S.optional(Compliance),
    AccountId: S.optional(S.String),
    AwsRegion: S.optional(S.String),
  }),
).annotate({
  identifier: "AggregateComplianceByConfigRule",
}) as any as S.Schema<AggregateComplianceByConfigRule>;
export type AggregateComplianceByConfigRuleList =
  AggregateComplianceByConfigRule[];
export const AggregateComplianceByConfigRuleList = /*@__PURE__*/ S.Array(
  AggregateComplianceByConfigRule,
);
export interface DescribeAggregateComplianceByConfigRulesResponse {
  AggregateComplianceByConfigRules?: AggregateComplianceByConfigRule[];
  NextToken?: string;
}
export const DescribeAggregateComplianceByConfigRulesResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      AggregateComplianceByConfigRules: S.optional(
        AggregateComplianceByConfigRuleList,
      ),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "DescribeAggregateComplianceByConfigRulesResponse",
  }) as any as S.Schema<DescribeAggregateComplianceByConfigRulesResponse>;
export type ConformancePackComplianceType =
  | "COMPLIANT"
  | "NON_COMPLIANT"
  | "INSUFFICIENT_DATA"
  | (string & {});
export const ConformancePackComplianceType = S.String;

export interface AggregateConformancePackComplianceFilters {
  ConformancePackName?: string;
  ComplianceType?: ConformancePackComplianceType;
  AccountId?: string;
  AwsRegion?: string;
}
export const AggregateConformancePackComplianceFilters =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConformancePackName: S.optional(S.String),
      ComplianceType: S.optional(ConformancePackComplianceType),
      AccountId: S.optional(S.String),
      AwsRegion: S.optional(S.String),
    }),
  ).annotate({
    identifier: "AggregateConformancePackComplianceFilters",
  }) as any as S.Schema<AggregateConformancePackComplianceFilters>;
export type Limit = number;
export interface DescribeAggregateComplianceByConformancePacksRequest {
  ConfigurationAggregatorName: string;
  Filters?: AggregateConformancePackComplianceFilters;
  Limit?: number;
  NextToken?: string;
}
export const DescribeAggregateComplianceByConformancePacksRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConfigurationAggregatorName: S.String,
      Filters: S.optional(AggregateConformancePackComplianceFilters),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "DescribeAggregateComplianceByConformancePacksRequest",
  }) as any as S.Schema<DescribeAggregateComplianceByConformancePacksRequest>;
export interface AggregateConformancePackCompliance {
  ComplianceType?: ConformancePackComplianceType;
  CompliantRuleCount?: number;
  NonCompliantRuleCount?: number;
  TotalRuleCount?: number;
}
export const AggregateConformancePackCompliance = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ComplianceType: S.optional(ConformancePackComplianceType),
    CompliantRuleCount: S.optional(S.Number),
    NonCompliantRuleCount: S.optional(S.Number),
    TotalRuleCount: S.optional(S.Number),
  }),
).annotate({
  identifier: "AggregateConformancePackCompliance",
}) as any as S.Schema<AggregateConformancePackCompliance>;
export interface AggregateComplianceByConformancePack {
  ConformancePackName?: string;
  Compliance?: AggregateConformancePackCompliance;
  AccountId?: string;
  AwsRegion?: string;
}
export const AggregateComplianceByConformancePack = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConformancePackName: S.optional(S.String),
      Compliance: S.optional(AggregateConformancePackCompliance),
      AccountId: S.optional(S.String),
      AwsRegion: S.optional(S.String),
    }),
).annotate({
  identifier: "AggregateComplianceByConformancePack",
}) as any as S.Schema<AggregateComplianceByConformancePack>;
export type AggregateComplianceByConformancePackList =
  AggregateComplianceByConformancePack[];
export const AggregateComplianceByConformancePackList = /*@__PURE__*/ S.Array(
  AggregateComplianceByConformancePack,
);
export interface DescribeAggregateComplianceByConformancePacksResponse {
  AggregateComplianceByConformancePacks?: AggregateComplianceByConformancePack[];
  NextToken?: string;
}
export const DescribeAggregateComplianceByConformancePacksResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      AggregateComplianceByConformancePacks: S.optional(
        AggregateComplianceByConformancePackList,
      ),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "DescribeAggregateComplianceByConformancePacksResponse",
  }) as any as S.Schema<DescribeAggregateComplianceByConformancePacksResponse>;
export interface DescribeAggregationAuthorizationsRequest {
  Limit?: number;
  NextToken?: string;
}
export const DescribeAggregationAuthorizationsRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DescribeAggregationAuthorizationsRequest",
}) as any as S.Schema<DescribeAggregationAuthorizationsRequest>;
export interface AggregationAuthorization {
  AggregationAuthorizationArn?: string;
  AuthorizedAccountId?: string;
  AuthorizedAwsRegion?: string;
  CreationTime?: Date;
}
export const AggregationAuthorization = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    AggregationAuthorizationArn: S.optional(S.String),
    AuthorizedAccountId: S.optional(S.String),
    AuthorizedAwsRegion: S.optional(S.String),
    CreationTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
  }),
).annotate({
  identifier: "AggregationAuthorization",
}) as any as S.Schema<AggregationAuthorization>;
export type AggregationAuthorizationList = AggregationAuthorization[];
export const AggregationAuthorizationList = /*@__PURE__*/ S.Array(
  AggregationAuthorization,
);
export interface DescribeAggregationAuthorizationsResponse {
  AggregationAuthorizations?: AggregationAuthorization[];
  NextToken?: string;
}
export const DescribeAggregationAuthorizationsResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      AggregationAuthorizations: S.optional(AggregationAuthorizationList),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "DescribeAggregationAuthorizationsResponse",
  }) as any as S.Schema<DescribeAggregationAuthorizationsResponse>;
export type ConfigRuleNames = string[];
export const ConfigRuleNames = /*@__PURE__*/ S.Array(S.String);
export type ComplianceTypes = ComplianceType[];
export const ComplianceTypes = /*@__PURE__*/ S.Array(ComplianceType);
export interface DescribeComplianceByConfigRuleRequest {
  ConfigRuleNames?: string[];
  ComplianceTypes?: ComplianceType[];
  NextToken?: string;
}
export const DescribeComplianceByConfigRuleRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConfigRuleNames: S.optional(ConfigRuleNames),
      ComplianceTypes: S.optional(ComplianceTypes),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DescribeComplianceByConfigRuleRequest",
}) as any as S.Schema<DescribeComplianceByConfigRuleRequest>;
export interface ComplianceByConfigRule {
  ConfigRuleName?: string;
  Compliance?: Compliance;
}
export const ComplianceByConfigRule = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleName: S.optional(S.String),
    Compliance: S.optional(Compliance),
  }),
).annotate({
  identifier: "ComplianceByConfigRule",
}) as any as S.Schema<ComplianceByConfigRule>;
export type ComplianceByConfigRules = ComplianceByConfigRule[];
export const ComplianceByConfigRules = /*@__PURE__*/ S.Array(
  ComplianceByConfigRule,
);
export interface DescribeComplianceByConfigRuleResponse {
  ComplianceByConfigRules?: ComplianceByConfigRule[];
  NextToken?: string;
}
export const DescribeComplianceByConfigRuleResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ComplianceByConfigRules: S.optional(ComplianceByConfigRules),
      NextToken: S.optional(S.String),
    }).pipe(ns),
).annotate({
  identifier: "DescribeComplianceByConfigRuleResponse",
}) as any as S.Schema<DescribeComplianceByConfigRuleResponse>;
export type BaseResourceId = string;
export interface DescribeComplianceByResourceRequest {
  ResourceType?: string;
  ResourceId?: string;
  ComplianceTypes?: ComplianceType[];
  Limit?: number;
  NextToken?: string;
}
export const DescribeComplianceByResourceRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceType: S.optional(S.String),
    ResourceId: S.optional(S.String),
    ComplianceTypes: S.optional(ComplianceTypes),
    Limit: S.optional(S.Number),
    NextToken: S.optional(S.String),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DescribeComplianceByResourceRequest",
}) as any as S.Schema<DescribeComplianceByResourceRequest>;
export interface ComplianceByResource {
  ResourceType?: string;
  ResourceId?: string;
  Compliance?: Compliance;
}
export const ComplianceByResource = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceType: S.optional(S.String),
    ResourceId: S.optional(S.String),
    Compliance: S.optional(Compliance),
  }),
).annotate({
  identifier: "ComplianceByResource",
}) as any as S.Schema<ComplianceByResource>;
export type ComplianceByResources = ComplianceByResource[];
export const ComplianceByResources =
  /*@__PURE__*/ S.Array(ComplianceByResource);
export interface DescribeComplianceByResourceResponse {
  ComplianceByResources?: ComplianceByResource[];
  NextToken?: string;
}
export const DescribeComplianceByResourceResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ComplianceByResources: S.optional(ComplianceByResources),
      NextToken: S.optional(S.String),
    }).pipe(ns),
).annotate({
  identifier: "DescribeComplianceByResourceResponse",
}) as any as S.Schema<DescribeComplianceByResourceResponse>;
export type RuleLimit = number;
export interface DescribeConfigRuleEvaluationStatusRequest {
  ConfigRuleNames?: string[];
  NextToken?: string;
  Limit?: number;
}
export const DescribeConfigRuleEvaluationStatusRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConfigRuleNames: S.optional(ConfigRuleNames),
      NextToken: S.optional(S.String),
      Limit: S.optional(S.Number),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "DescribeConfigRuleEvaluationStatusRequest",
  }) as any as S.Schema<DescribeConfigRuleEvaluationStatusRequest>;
export interface ConfigRuleEvaluationStatus {
  ConfigRuleName?: string;
  ConfigRuleArn?: string;
  ConfigRuleId?: string;
  LastSuccessfulInvocationTime?: Date;
  LastFailedInvocationTime?: Date;
  LastSuccessfulEvaluationTime?: Date;
  LastFailedEvaluationTime?: Date;
  FirstActivatedTime?: Date;
  LastDeactivatedTime?: Date;
  LastErrorCode?: string;
  LastErrorMessage?: string;
  FirstEvaluationStarted?: boolean;
  LastDebugLogDeliveryStatus?: string;
  LastDebugLogDeliveryStatusReason?: string;
  LastDebugLogDeliveryTime?: Date;
}
export const ConfigRuleEvaluationStatus = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleName: S.optional(S.String),
    ConfigRuleArn: S.optional(S.String),
    ConfigRuleId: S.optional(S.String),
    LastSuccessfulInvocationTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    LastFailedInvocationTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    LastSuccessfulEvaluationTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    LastFailedEvaluationTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    FirstActivatedTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    LastDeactivatedTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    LastErrorCode: S.optional(S.String),
    LastErrorMessage: S.optional(S.String),
    FirstEvaluationStarted: S.optional(S.Boolean),
    LastDebugLogDeliveryStatus: S.optional(S.String),
    LastDebugLogDeliveryStatusReason: S.optional(S.String),
    LastDebugLogDeliveryTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
  }),
).annotate({
  identifier: "ConfigRuleEvaluationStatus",
}) as any as S.Schema<ConfigRuleEvaluationStatus>;
export type ConfigRuleEvaluationStatusList = ConfigRuleEvaluationStatus[];
export const ConfigRuleEvaluationStatusList = /*@__PURE__*/ S.Array(
  ConfigRuleEvaluationStatus,
);
export interface DescribeConfigRuleEvaluationStatusResponse {
  ConfigRulesEvaluationStatus?: ConfigRuleEvaluationStatus[];
  NextToken?: string;
}
export const DescribeConfigRuleEvaluationStatusResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConfigRulesEvaluationStatus: S.optional(ConfigRuleEvaluationStatusList),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "DescribeConfigRuleEvaluationStatusResponse",
  }) as any as S.Schema<DescribeConfigRuleEvaluationStatusResponse>;
export type EvaluationMode = "DETECTIVE" | "PROACTIVE" | (string & {});
export const EvaluationMode = S.String;

export type RuleEvaluationVisibility = "EXTERNAL" | "INTERNAL" | (string & {});
export const RuleEvaluationVisibility = S.String;

export interface DescribeConfigRulesFilters {
  EvaluationMode?: EvaluationMode;
  RuleEvaluationVisibility?: RuleEvaluationVisibility;
}
export const DescribeConfigRulesFilters = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    EvaluationMode: S.optional(EvaluationMode),
    RuleEvaluationVisibility: S.optional(RuleEvaluationVisibility),
  }),
).annotate({
  identifier: "DescribeConfigRulesFilters",
}) as any as S.Schema<DescribeConfigRulesFilters>;
export interface DescribeConfigRulesRequest {
  ConfigRuleNames?: string[];
  Filters?: DescribeConfigRulesFilters;
  NextToken?: string;
}
export const DescribeConfigRulesRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleNames: S.optional(ConfigRuleNames),
    Filters: S.optional(DescribeConfigRulesFilters),
    NextToken: S.optional(S.String),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DescribeConfigRulesRequest",
}) as any as S.Schema<DescribeConfigRulesRequest>;
export type EmptiableStringWithCharLimit256 = string;
export type ComplianceResourceTypes = string[];
export const ComplianceResourceTypes = /*@__PURE__*/ S.Array(S.String);
export type StringWithCharLimit128 = string;
export type ServicePrincipals = string[];
export const ServicePrincipals = /*@__PURE__*/ S.Array(S.String);
export interface Scope {
  ComplianceResourceTypes?: string[];
  TagKey?: string;
  TagValue?: string;
  ComplianceResourceId?: string;
  ServicePrincipals?: string[];
}
export const Scope = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ComplianceResourceTypes: S.optional(ComplianceResourceTypes),
    TagKey: S.optional(S.String),
    TagValue: S.optional(S.String),
    ComplianceResourceId: S.optional(S.String),
    ServicePrincipals: S.optional(ServicePrincipals),
  }),
).annotate({ identifier: "Scope" }) as any as S.Schema<Scope>;
export type Owner = "CUSTOM_LAMBDA" | "AWS" | "CUSTOM_POLICY" | (string & {});
export const Owner = S.String;

export type EventSource = "aws.config" | (string & {});
export const EventSource = S.String;

export type MessageType =
  | "ConfigurationItemChangeNotification"
  | "ConfigurationSnapshotDeliveryCompleted"
  | "ScheduledNotification"
  | "OversizedConfigurationItemChangeNotification"
  | (string & {});
export const MessageType = S.String;

export type MaximumExecutionFrequency =
  | "One_Hour"
  | "Three_Hours"
  | "Six_Hours"
  | "Twelve_Hours"
  | "TwentyFour_Hours"
  | (string & {});
export const MaximumExecutionFrequency = S.String;

export interface SourceDetail {
  EventSource?: EventSource;
  MessageType?: MessageType;
  MaximumExecutionFrequency?: MaximumExecutionFrequency;
}
export const SourceDetail = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    EventSource: S.optional(EventSource),
    MessageType: S.optional(MessageType),
    MaximumExecutionFrequency: S.optional(MaximumExecutionFrequency),
  }),
).annotate({ identifier: "SourceDetail" }) as any as S.Schema<SourceDetail>;
export type SourceDetails = SourceDetail[];
export const SourceDetails = /*@__PURE__*/ S.Array(SourceDetail);
export type PolicyRuntime = string;
export type PolicyText = string;
export interface CustomPolicyDetails {
  PolicyRuntime: string;
  PolicyText: string;
  EnableDebugLogDelivery?: boolean;
}
export const CustomPolicyDetails = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    PolicyRuntime: S.String,
    PolicyText: S.String,
    EnableDebugLogDelivery: S.optional(S.Boolean),
  }),
).annotate({
  identifier: "CustomPolicyDetails",
}) as any as S.Schema<CustomPolicyDetails>;
export interface Source {
  Owner: Owner;
  SourceIdentifier?: string;
  SourceDetails?: SourceDetail[];
  CustomPolicyDetails?: CustomPolicyDetails;
}
export const Source = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    Owner: Owner,
    SourceIdentifier: S.optional(S.String),
    SourceDetails: S.optional(SourceDetails),
    CustomPolicyDetails: S.optional(CustomPolicyDetails),
  }),
).annotate({ identifier: "Source" }) as any as S.Schema<Source>;
export type ConfigRuleState =
  | "ACTIVE"
  | "DELETING"
  | "DELETING_RESULTS"
  | "EVALUATING"
  | (string & {});
export const ConfigRuleState = S.String;

export interface EvaluationModeConfiguration {
  Mode?: EvaluationMode;
}
export const EvaluationModeConfiguration = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ Mode: S.optional(EvaluationMode) }),
).annotate({
  identifier: "EvaluationModeConfiguration",
}) as any as S.Schema<EvaluationModeConfiguration>;
export type EvaluationModes = EvaluationModeConfiguration[];
export const EvaluationModes = /*@__PURE__*/ S.Array(
  EvaluationModeConfiguration,
);
export interface ConfigRule {
  ConfigRuleName?: string;
  ConfigRuleArn?: string;
  ConfigRuleId?: string;
  Description?: string;
  Scope?: Scope;
  Source: Source;
  InputParameters?: string;
  MaximumExecutionFrequency?: MaximumExecutionFrequency;
  ConfigRuleState?: ConfigRuleState;
  CreatedBy?: string;
  EvaluationModes?: EvaluationModeConfiguration[];
  RuleEvaluationVisibility?: RuleEvaluationVisibility;
}
export const ConfigRule = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleName: S.optional(S.String),
    ConfigRuleArn: S.optional(S.String),
    ConfigRuleId: S.optional(S.String),
    Description: S.optional(S.String),
    Scope: S.optional(Scope),
    Source: Source,
    InputParameters: S.optional(S.String),
    MaximumExecutionFrequency: S.optional(MaximumExecutionFrequency),
    ConfigRuleState: S.optional(ConfigRuleState),
    CreatedBy: S.optional(S.String),
    EvaluationModes: S.optional(EvaluationModes),
    RuleEvaluationVisibility: S.optional(RuleEvaluationVisibility),
  }),
).annotate({ identifier: "ConfigRule" }) as any as S.Schema<ConfigRule>;
export type ConfigRules = ConfigRule[];
export const ConfigRules = /*@__PURE__*/ S.Array(ConfigRule);
export interface DescribeConfigRulesResponse {
  ConfigRules?: ConfigRule[];
  NextToken?: string;
}
export const DescribeConfigRulesResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRules: S.optional(ConfigRules),
    NextToken: S.optional(S.String),
  }).pipe(ns),
).annotate({
  identifier: "DescribeConfigRulesResponse",
}) as any as S.Schema<DescribeConfigRulesResponse>;
export type ConfigurationAggregatorNameList = string[];
export const ConfigurationAggregatorNameList = /*@__PURE__*/ S.Array(S.String);
export interface DescribeConfigurationAggregatorsRequest {
  ConfigurationAggregatorNames?: string[];
  NextToken?: string;
  Limit?: number;
}
export const DescribeConfigurationAggregatorsRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConfigurationAggregatorNames: S.optional(ConfigurationAggregatorNameList),
      NextToken: S.optional(S.String),
      Limit: S.optional(S.Number),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DescribeConfigurationAggregatorsRequest",
}) as any as S.Schema<DescribeConfigurationAggregatorsRequest>;
export type ConfigurationAggregatorArn = string;
export type AccountAggregationSourceAccountList = string[];
export const AccountAggregationSourceAccountList = /*@__PURE__*/ S.Array(
  S.String,
);
export type AggregatorRegionList = string[];
export const AggregatorRegionList = /*@__PURE__*/ S.Array(S.String);
export interface AccountAggregationSource {
  AccountIds: string[];
  AllAwsRegions?: boolean;
  AwsRegions?: string[];
}
export const AccountAggregationSource = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    AccountIds: AccountAggregationSourceAccountList,
    AllAwsRegions: S.optional(S.Boolean),
    AwsRegions: S.optional(AggregatorRegionList),
  }),
).annotate({
  identifier: "AccountAggregationSource",
}) as any as S.Schema<AccountAggregationSource>;
export type AccountAggregationSourceList = AccountAggregationSource[];
export const AccountAggregationSourceList = /*@__PURE__*/ S.Array(
  AccountAggregationSource,
);
export interface OrganizationAggregationSource {
  RoleArn: string;
  AwsRegions?: string[];
  AllAwsRegions?: boolean;
}
export const OrganizationAggregationSource = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    RoleArn: S.String,
    AwsRegions: S.optional(AggregatorRegionList),
    AllAwsRegions: S.optional(S.Boolean),
  }),
).annotate({
  identifier: "OrganizationAggregationSource",
}) as any as S.Schema<OrganizationAggregationSource>;
export type AggregatorFilterType = "INCLUDE" | (string & {});
export const AggregatorFilterType = S.String;

export type ResourceTypeValue = string;
export type ResourceTypeValueList = string[];
export const ResourceTypeValueList = /*@__PURE__*/ S.Array(S.String);
export interface AggregatorFilterResourceType {
  Type?: AggregatorFilterType;
  Value?: string[];
}
export const AggregatorFilterResourceType = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    Type: S.optional(AggregatorFilterType),
    Value: S.optional(ResourceTypeValueList),
  }),
).annotate({
  identifier: "AggregatorFilterResourceType",
}) as any as S.Schema<AggregatorFilterResourceType>;
export type ServicePrincipalValue = string;
export type ServicePrincipalValueList = string[];
export const ServicePrincipalValueList = /*@__PURE__*/ S.Array(S.String);
export interface AggregatorFilterServicePrincipal {
  Type?: AggregatorFilterType;
  Value?: string[];
}
export const AggregatorFilterServicePrincipal = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    Type: S.optional(AggregatorFilterType),
    Value: S.optional(ServicePrincipalValueList),
  }),
).annotate({
  identifier: "AggregatorFilterServicePrincipal",
}) as any as S.Schema<AggregatorFilterServicePrincipal>;
export interface AggregatorFilters {
  ResourceType?: AggregatorFilterResourceType;
  ServicePrincipal?: AggregatorFilterServicePrincipal;
}
export const AggregatorFilters = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceType: S.optional(AggregatorFilterResourceType),
    ServicePrincipal: S.optional(AggregatorFilterServicePrincipal),
  }),
).annotate({
  identifier: "AggregatorFilters",
}) as any as S.Schema<AggregatorFilters>;
export interface ConfigurationAggregator {
  ConfigurationAggregatorName?: string;
  ConfigurationAggregatorArn?: string;
  AccountAggregationSources?: AccountAggregationSource[];
  OrganizationAggregationSource?: OrganizationAggregationSource;
  CreationTime?: Date;
  LastUpdatedTime?: Date;
  CreatedBy?: string;
  AggregatorFilters?: AggregatorFilters;
}
export const ConfigurationAggregator = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigurationAggregatorName: S.optional(S.String),
    ConfigurationAggregatorArn: S.optional(S.String),
    AccountAggregationSources: S.optional(AccountAggregationSourceList),
    OrganizationAggregationSource: S.optional(OrganizationAggregationSource),
    CreationTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
    LastUpdatedTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    CreatedBy: S.optional(S.String),
    AggregatorFilters: S.optional(AggregatorFilters),
  }),
).annotate({
  identifier: "ConfigurationAggregator",
}) as any as S.Schema<ConfigurationAggregator>;
export type ConfigurationAggregatorList = ConfigurationAggregator[];
export const ConfigurationAggregatorList = /*@__PURE__*/ S.Array(
  ConfigurationAggregator,
);
export interface DescribeConfigurationAggregatorsResponse {
  ConfigurationAggregators?: ConfigurationAggregator[];
  NextToken?: string;
}
export const DescribeConfigurationAggregatorsResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConfigurationAggregators: S.optional(ConfigurationAggregatorList),
      NextToken: S.optional(S.String),
    }).pipe(ns),
).annotate({
  identifier: "DescribeConfigurationAggregatorsResponse",
}) as any as S.Schema<DescribeConfigurationAggregatorsResponse>;
export type AggregatedSourceStatusType =
  | "FAILED"
  | "SUCCEEDED"
  | "OUTDATED"
  | (string & {});
export const AggregatedSourceStatusType = S.String;

export type AggregatedSourceStatusTypeList = AggregatedSourceStatusType[];
export const AggregatedSourceStatusTypeList = /*@__PURE__*/ S.Array(
  AggregatedSourceStatusType,
);
export interface DescribeConfigurationAggregatorSourcesStatusRequest {
  ConfigurationAggregatorName: string;
  UpdateStatus?: AggregatedSourceStatusType[];
  NextToken?: string;
  Limit?: number;
}
export const DescribeConfigurationAggregatorSourcesStatusRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConfigurationAggregatorName: S.String,
      UpdateStatus: S.optional(AggregatedSourceStatusTypeList),
      NextToken: S.optional(S.String),
      Limit: S.optional(S.Number),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "DescribeConfigurationAggregatorSourcesStatusRequest",
  }) as any as S.Schema<DescribeConfigurationAggregatorSourcesStatusRequest>;
export type AggregatedSourceType = "ACCOUNT" | "ORGANIZATION" | (string & {});
export const AggregatedSourceType = S.String;

export interface AggregatedSourceStatus {
  SourceId?: string;
  SourceType?: AggregatedSourceType;
  AwsRegion?: string;
  LastUpdateStatus?: AggregatedSourceStatusType;
  LastUpdateTime?: Date;
  LastErrorCode?: string;
  LastErrorMessage?: string;
}
export const AggregatedSourceStatus = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    SourceId: S.optional(S.String),
    SourceType: S.optional(AggregatedSourceType),
    AwsRegion: S.optional(S.String),
    LastUpdateStatus: S.optional(AggregatedSourceStatusType),
    LastUpdateTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
    LastErrorCode: S.optional(S.String),
    LastErrorMessage: S.optional(S.String),
  }),
).annotate({
  identifier: "AggregatedSourceStatus",
}) as any as S.Schema<AggregatedSourceStatus>;
export type AggregatedSourceStatusList = AggregatedSourceStatus[];
export const AggregatedSourceStatusList = /*@__PURE__*/ S.Array(
  AggregatedSourceStatus,
);
export interface DescribeConfigurationAggregatorSourcesStatusResponse {
  AggregatedSourceStatusList?: AggregatedSourceStatus[];
  NextToken?: string;
}
export const DescribeConfigurationAggregatorSourcesStatusResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      AggregatedSourceStatusList: S.optional(AggregatedSourceStatusList),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "DescribeConfigurationAggregatorSourcesStatusResponse",
  }) as any as S.Schema<DescribeConfigurationAggregatorSourcesStatusResponse>;
export type ConfigurationRecorderNameList = string[];
export const ConfigurationRecorderNameList = /*@__PURE__*/ S.Array(S.String);
export interface DescribeConfigurationRecordersRequest {
  ConfigurationRecorderNames?: string[];
  ServicePrincipal?: string;
  Arn?: string;
}
export const DescribeConfigurationRecordersRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConfigurationRecorderNames: S.optional(ConfigurationRecorderNameList),
      ServicePrincipal: S.optional(S.String),
      Arn: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DescribeConfigurationRecordersRequest",
}) as any as S.Schema<DescribeConfigurationRecordersRequest>;
export type ConfigurationRecorderList = ConfigurationRecorder[];
export const ConfigurationRecorderList = /*@__PURE__*/ S.Array(
  ConfigurationRecorder,
);
export interface DescribeConfigurationRecordersResponse {
  ConfigurationRecorders?: ConfigurationRecorder[];
}
export const DescribeConfigurationRecordersResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConfigurationRecorders: S.optional(ConfigurationRecorderList),
    }).pipe(ns),
).annotate({
  identifier: "DescribeConfigurationRecordersResponse",
}) as any as S.Schema<DescribeConfigurationRecordersResponse>;
export interface DescribeConfigurationRecorderStatusRequest {
  ConfigurationRecorderNames?: string[];
  ServicePrincipal?: string;
  Arn?: string;
}
export const DescribeConfigurationRecorderStatusRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConfigurationRecorderNames: S.optional(ConfigurationRecorderNameList),
      ServicePrincipal: S.optional(S.String),
      Arn: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "DescribeConfigurationRecorderStatusRequest",
  }) as any as S.Schema<DescribeConfigurationRecorderStatusRequest>;
export type RecorderStatus =
  | "Pending"
  | "Success"
  | "Failure"
  | "NotApplicable"
  | (string & {});
export const RecorderStatus = S.String;

export interface ConfigurationRecorderStatus {
  arn?: string;
  name?: string;
  lastStartTime?: Date;
  lastStopTime?: Date;
  recording?: boolean;
  lastStatus?: RecorderStatus;
  lastErrorCode?: string;
  lastErrorMessage?: string;
  lastStatusChangeTime?: Date;
  servicePrincipal?: string;
}
export const ConfigurationRecorderStatus = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    arn: S.optional(S.String),
    name: S.optional(S.String),
    lastStartTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
    lastStopTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
    recording: S.optional(S.Boolean),
    lastStatus: S.optional(RecorderStatus),
    lastErrorCode: S.optional(S.String),
    lastErrorMessage: S.optional(S.String),
    lastStatusChangeTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    servicePrincipal: S.optional(S.String),
  }),
).annotate({
  identifier: "ConfigurationRecorderStatus",
}) as any as S.Schema<ConfigurationRecorderStatus>;
export type ConfigurationRecorderStatusList = ConfigurationRecorderStatus[];
export const ConfigurationRecorderStatusList = /*@__PURE__*/ S.Array(
  ConfigurationRecorderStatus,
);
export interface DescribeConfigurationRecorderStatusResponse {
  ConfigurationRecordersStatus?: ConfigurationRecorderStatus[];
}
export const DescribeConfigurationRecorderStatusResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConfigurationRecordersStatus: S.optional(ConfigurationRecorderStatusList),
    }).pipe(ns),
  ).annotate({
    identifier: "DescribeConfigurationRecorderStatusResponse",
  }) as any as S.Schema<DescribeConfigurationRecorderStatusResponse>;
export type ConformancePackConfigRuleNames = string[];
export const ConformancePackConfigRuleNames = /*@__PURE__*/ S.Array(S.String);
export interface ConformancePackComplianceFilters {
  ConfigRuleNames?: string[];
  ComplianceType?: ConformancePackComplianceType;
}
export const ConformancePackComplianceFilters = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleNames: S.optional(ConformancePackConfigRuleNames),
    ComplianceType: S.optional(ConformancePackComplianceType),
  }),
).annotate({
  identifier: "ConformancePackComplianceFilters",
}) as any as S.Schema<ConformancePackComplianceFilters>;
export type DescribeConformancePackComplianceLimit = number;
export interface DescribeConformancePackComplianceRequest {
  ConformancePackName: string;
  Filters?: ConformancePackComplianceFilters;
  Limit?: number;
  NextToken?: string;
}
export const DescribeConformancePackComplianceRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConformancePackName: S.String,
      Filters: S.optional(ConformancePackComplianceFilters),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DescribeConformancePackComplianceRequest",
}) as any as S.Schema<DescribeConformancePackComplianceRequest>;
export type ControlsList = string[];
export const ControlsList = /*@__PURE__*/ S.Array(S.String);
export interface ConformancePackRuleCompliance {
  ConfigRuleName?: string;
  ComplianceType?: ConformancePackComplianceType;
  Controls?: string[];
}
export const ConformancePackRuleCompliance = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleName: S.optional(S.String),
    ComplianceType: S.optional(ConformancePackComplianceType),
    Controls: S.optional(ControlsList),
  }),
).annotate({
  identifier: "ConformancePackRuleCompliance",
}) as any as S.Schema<ConformancePackRuleCompliance>;
export type ConformancePackRuleComplianceList = ConformancePackRuleCompliance[];
export const ConformancePackRuleComplianceList = /*@__PURE__*/ S.Array(
  ConformancePackRuleCompliance,
);
export interface DescribeConformancePackComplianceResponse {
  ConformancePackName: string;
  ConformancePackRuleComplianceList: ConformancePackRuleCompliance[];
  NextToken?: string;
}
export const DescribeConformancePackComplianceResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConformancePackName: S.String,
      ConformancePackRuleComplianceList: ConformancePackRuleComplianceList,
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "DescribeConformancePackComplianceResponse",
  }) as any as S.Schema<DescribeConformancePackComplianceResponse>;
export type ConformancePackNamesList = string[];
export const ConformancePackNamesList = /*@__PURE__*/ S.Array(S.String);
export type PageSizeLimit = number;
export interface DescribeConformancePacksRequest {
  ConformancePackNames?: string[];
  Limit?: number;
  NextToken?: string;
}
export const DescribeConformancePacksRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConformancePackNames: S.optional(ConformancePackNamesList),
    Limit: S.optional(S.Number),
    NextToken: S.optional(S.String),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DescribeConformancePacksRequest",
}) as any as S.Schema<DescribeConformancePacksRequest>;
export type ConformancePackArn = string;
export type ConformancePackId = string;
export type DeliveryS3Bucket = string;
export type DeliveryS3KeyPrefix = string;
export type ParameterName = string;
export type ParameterValue = string;
export interface ConformancePackInputParameter {
  ParameterName: string;
  ParameterValue: string;
}
export const ConformancePackInputParameter = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ParameterName: S.String, ParameterValue: S.String }),
).annotate({
  identifier: "ConformancePackInputParameter",
}) as any as S.Schema<ConformancePackInputParameter>;
export type ConformancePackInputParameters = ConformancePackInputParameter[];
export const ConformancePackInputParameters = /*@__PURE__*/ S.Array(
  ConformancePackInputParameter,
);
export type SSMDocumentName = string;
export type SSMDocumentVersion = string;
export interface TemplateSSMDocumentDetails {
  DocumentName: string;
  DocumentVersion?: string;
}
export const TemplateSSMDocumentDetails = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ DocumentName: S.String, DocumentVersion: S.optional(S.String) }),
).annotate({
  identifier: "TemplateSSMDocumentDetails",
}) as any as S.Schema<TemplateSSMDocumentDetails>;
export interface ConformancePackDetail {
  ConformancePackName: string;
  ConformancePackArn: string;
  ConformancePackId: string;
  DeliveryS3Bucket?: string;
  DeliveryS3KeyPrefix?: string;
  ConformancePackInputParameters?: ConformancePackInputParameter[];
  LastUpdateRequestedTime?: Date;
  CreatedBy?: string;
  TemplateSSMDocumentDetails?: TemplateSSMDocumentDetails;
}
export const ConformancePackDetail = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConformancePackName: S.String,
    ConformancePackArn: S.String,
    ConformancePackId: S.String,
    DeliveryS3Bucket: S.optional(S.String),
    DeliveryS3KeyPrefix: S.optional(S.String),
    ConformancePackInputParameters: S.optional(ConformancePackInputParameters),
    LastUpdateRequestedTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    CreatedBy: S.optional(S.String),
    TemplateSSMDocumentDetails: S.optional(TemplateSSMDocumentDetails),
  }),
).annotate({
  identifier: "ConformancePackDetail",
}) as any as S.Schema<ConformancePackDetail>;
export type ConformancePackDetailList = ConformancePackDetail[];
export const ConformancePackDetailList = /*@__PURE__*/ S.Array(
  ConformancePackDetail,
);
export interface DescribeConformancePacksResponse {
  ConformancePackDetails?: ConformancePackDetail[];
  NextToken?: string;
}
export const DescribeConformancePacksResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConformancePackDetails: S.optional(ConformancePackDetailList),
    NextToken: S.optional(S.String),
  }).pipe(ns),
).annotate({
  identifier: "DescribeConformancePacksResponse",
}) as any as S.Schema<DescribeConformancePacksResponse>;
export interface DescribeConformancePackStatusRequest {
  ConformancePackNames?: string[];
  Limit?: number;
  NextToken?: string;
}
export const DescribeConformancePackStatusRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConformancePackNames: S.optional(ConformancePackNamesList),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DescribeConformancePackStatusRequest",
}) as any as S.Schema<DescribeConformancePackStatusRequest>;
export type ConformancePackState =
  | "CREATE_IN_PROGRESS"
  | "CREATE_COMPLETE"
  | "CREATE_FAILED"
  | "DELETE_IN_PROGRESS"
  | "DELETE_FAILED"
  | (string & {});
export const ConformancePackState = S.String;

export type StackArn = string;
export type ConformancePackStatusReason = string;
export interface ConformancePackStatusDetail {
  ConformancePackName: string;
  ConformancePackId: string;
  ConformancePackArn: string;
  ConformancePackState: ConformancePackState;
  StackArn: string;
  ConformancePackStatusReason?: string;
  LastUpdateRequestedTime: Date;
  LastUpdateCompletedTime?: Date;
}
export const ConformancePackStatusDetail = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConformancePackName: S.String,
    ConformancePackId: S.String,
    ConformancePackArn: S.String,
    ConformancePackState: ConformancePackState,
    StackArn: S.String,
    ConformancePackStatusReason: S.optional(S.String),
    LastUpdateRequestedTime: S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    LastUpdateCompletedTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
  }),
).annotate({
  identifier: "ConformancePackStatusDetail",
}) as any as S.Schema<ConformancePackStatusDetail>;
export type ConformancePackStatusDetailsList = ConformancePackStatusDetail[];
export const ConformancePackStatusDetailsList = /*@__PURE__*/ S.Array(
  ConformancePackStatusDetail,
);
export interface DescribeConformancePackStatusResponse {
  ConformancePackStatusDetails?: ConformancePackStatusDetail[];
  NextToken?: string;
}
export const DescribeConformancePackStatusResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConformancePackStatusDetails: S.optional(
        ConformancePackStatusDetailsList,
      ),
      NextToken: S.optional(S.String),
    }).pipe(ns),
).annotate({
  identifier: "DescribeConformancePackStatusResponse",
}) as any as S.Schema<DescribeConformancePackStatusResponse>;
export type DeliveryChannelNameList = string[];
export const DeliveryChannelNameList = /*@__PURE__*/ S.Array(S.String);
export interface DescribeDeliveryChannelsRequest {
  DeliveryChannelNames?: string[];
}
export const DescribeDeliveryChannelsRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ DeliveryChannelNames: S.optional(DeliveryChannelNameList) }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DescribeDeliveryChannelsRequest",
}) as any as S.Schema<DescribeDeliveryChannelsRequest>;
export interface ConfigSnapshotDeliveryProperties {
  deliveryFrequency?: MaximumExecutionFrequency;
}
export const ConfigSnapshotDeliveryProperties = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ deliveryFrequency: S.optional(MaximumExecutionFrequency) }),
).annotate({
  identifier: "ConfigSnapshotDeliveryProperties",
}) as any as S.Schema<ConfigSnapshotDeliveryProperties>;
export interface DeliveryChannel {
  name?: string;
  s3BucketName?: string;
  s3KeyPrefix?: string;
  s3KmsKeyArn?: string;
  snsTopicARN?: string;
  configSnapshotDeliveryProperties?: ConfigSnapshotDeliveryProperties;
}
export const DeliveryChannel = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    name: S.optional(S.String),
    s3BucketName: S.optional(S.String),
    s3KeyPrefix: S.optional(S.String),
    s3KmsKeyArn: S.optional(S.String),
    snsTopicARN: S.optional(S.String),
    configSnapshotDeliveryProperties: S.optional(
      ConfigSnapshotDeliveryProperties,
    ),
  }),
).annotate({
  identifier: "DeliveryChannel",
}) as any as S.Schema<DeliveryChannel>;
export type DeliveryChannelList = DeliveryChannel[];
export const DeliveryChannelList = /*@__PURE__*/ S.Array(DeliveryChannel);
export interface DescribeDeliveryChannelsResponse {
  DeliveryChannels?: DeliveryChannel[];
}
export const DescribeDeliveryChannelsResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ DeliveryChannels: S.optional(DeliveryChannelList) }).pipe(ns),
).annotate({
  identifier: "DescribeDeliveryChannelsResponse",
}) as any as S.Schema<DescribeDeliveryChannelsResponse>;
export interface DescribeDeliveryChannelStatusRequest {
  DeliveryChannelNames?: string[];
}
export const DescribeDeliveryChannelStatusRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      DeliveryChannelNames: S.optional(DeliveryChannelNameList),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DescribeDeliveryChannelStatusRequest",
}) as any as S.Schema<DescribeDeliveryChannelStatusRequest>;
export type DeliveryStatus =
  | "Success"
  | "Failure"
  | "Not_Applicable"
  | (string & {});
export const DeliveryStatus = S.String;

export interface ConfigExportDeliveryInfo {
  lastStatus?: DeliveryStatus;
  lastErrorCode?: string;
  lastErrorMessage?: string;
  lastAttemptTime?: Date;
  lastSuccessfulTime?: Date;
  nextDeliveryTime?: Date;
}
export const ConfigExportDeliveryInfo = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    lastStatus: S.optional(DeliveryStatus),
    lastErrorCode: S.optional(S.String),
    lastErrorMessage: S.optional(S.String),
    lastAttemptTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    lastSuccessfulTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    nextDeliveryTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
  }),
).annotate({
  identifier: "ConfigExportDeliveryInfo",
}) as any as S.Schema<ConfigExportDeliveryInfo>;
export interface ConfigStreamDeliveryInfo {
  lastStatus?: DeliveryStatus;
  lastErrorCode?: string;
  lastErrorMessage?: string;
  lastStatusChangeTime?: Date;
}
export const ConfigStreamDeliveryInfo = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    lastStatus: S.optional(DeliveryStatus),
    lastErrorCode: S.optional(S.String),
    lastErrorMessage: S.optional(S.String),
    lastStatusChangeTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
  }),
).annotate({
  identifier: "ConfigStreamDeliveryInfo",
}) as any as S.Schema<ConfigStreamDeliveryInfo>;
export interface DeliveryChannelStatus {
  name?: string;
  configSnapshotDeliveryInfo?: ConfigExportDeliveryInfo;
  configHistoryDeliveryInfo?: ConfigExportDeliveryInfo;
  configStreamDeliveryInfo?: ConfigStreamDeliveryInfo;
}
export const DeliveryChannelStatus = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    name: S.optional(S.String),
    configSnapshotDeliveryInfo: S.optional(ConfigExportDeliveryInfo),
    configHistoryDeliveryInfo: S.optional(ConfigExportDeliveryInfo),
    configStreamDeliveryInfo: S.optional(ConfigStreamDeliveryInfo),
  }),
).annotate({
  identifier: "DeliveryChannelStatus",
}) as any as S.Schema<DeliveryChannelStatus>;
export type DeliveryChannelStatusList = DeliveryChannelStatus[];
export const DeliveryChannelStatusList = /*@__PURE__*/ S.Array(
  DeliveryChannelStatus,
);
export interface DescribeDeliveryChannelStatusResponse {
  DeliveryChannelsStatus?: DeliveryChannelStatus[];
}
export const DescribeDeliveryChannelStatusResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      DeliveryChannelsStatus: S.optional(DeliveryChannelStatusList),
    }).pipe(ns),
).annotate({
  identifier: "DescribeDeliveryChannelStatusResponse",
}) as any as S.Schema<DescribeDeliveryChannelStatusResponse>;
export type OrganizationConfigRuleNames = string[];
export const OrganizationConfigRuleNames = /*@__PURE__*/ S.Array(S.String);
export type CosmosPageLimit = number;
export interface DescribeOrganizationConfigRulesRequest {
  OrganizationConfigRuleNames?: string[];
  Limit?: number;
  NextToken?: string;
}
export const DescribeOrganizationConfigRulesRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      OrganizationConfigRuleNames: S.optional(OrganizationConfigRuleNames),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DescribeOrganizationConfigRulesRequest",
}) as any as S.Schema<DescribeOrganizationConfigRulesRequest>;
export type StringWithCharLimit256Min0 = string;
export type ResourceTypesScope = string[];
export const ResourceTypesScope = /*@__PURE__*/ S.Array(S.String);
export type StringWithCharLimit768 = string;
export interface OrganizationManagedRuleMetadata {
  Description?: string;
  RuleIdentifier: string;
  InputParameters?: string;
  MaximumExecutionFrequency?: MaximumExecutionFrequency;
  ResourceTypesScope?: string[];
  ResourceIdScope?: string;
  TagKeyScope?: string;
  TagValueScope?: string;
}
export const OrganizationManagedRuleMetadata = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    Description: S.optional(S.String),
    RuleIdentifier: S.String,
    InputParameters: S.optional(S.String),
    MaximumExecutionFrequency: S.optional(MaximumExecutionFrequency),
    ResourceTypesScope: S.optional(ResourceTypesScope),
    ResourceIdScope: S.optional(S.String),
    TagKeyScope: S.optional(S.String),
    TagValueScope: S.optional(S.String),
  }),
).annotate({
  identifier: "OrganizationManagedRuleMetadata",
}) as any as S.Schema<OrganizationManagedRuleMetadata>;
export type OrganizationConfigRuleTriggerType =
  | "ConfigurationItemChangeNotification"
  | "OversizedConfigurationItemChangeNotification"
  | "ScheduledNotification"
  | (string & {});
export const OrganizationConfigRuleTriggerType = S.String;

export type OrganizationConfigRuleTriggerTypes =
  OrganizationConfigRuleTriggerType[];
export const OrganizationConfigRuleTriggerTypes = /*@__PURE__*/ S.Array(
  OrganizationConfigRuleTriggerType,
);
export interface OrganizationCustomRuleMetadata {
  Description?: string;
  LambdaFunctionArn: string;
  OrganizationConfigRuleTriggerTypes: OrganizationConfigRuleTriggerType[];
  InputParameters?: string;
  MaximumExecutionFrequency?: MaximumExecutionFrequency;
  ResourceTypesScope?: string[];
  ResourceIdScope?: string;
  TagKeyScope?: string;
  TagValueScope?: string;
}
export const OrganizationCustomRuleMetadata = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    Description: S.optional(S.String),
    LambdaFunctionArn: S.String,
    OrganizationConfigRuleTriggerTypes: OrganizationConfigRuleTriggerTypes,
    InputParameters: S.optional(S.String),
    MaximumExecutionFrequency: S.optional(MaximumExecutionFrequency),
    ResourceTypesScope: S.optional(ResourceTypesScope),
    ResourceIdScope: S.optional(S.String),
    TagKeyScope: S.optional(S.String),
    TagValueScope: S.optional(S.String),
  }),
).annotate({
  identifier: "OrganizationCustomRuleMetadata",
}) as any as S.Schema<OrganizationCustomRuleMetadata>;
export type ExcludedAccounts = string[];
export const ExcludedAccounts = /*@__PURE__*/ S.Array(S.String);
export type OrganizationConfigRuleTriggerTypeNoSN =
  | "ConfigurationItemChangeNotification"
  | "OversizedConfigurationItemChangeNotification"
  | (string & {});
export const OrganizationConfigRuleTriggerTypeNoSN = S.String;

export type OrganizationConfigRuleTriggerTypeNoSNs =
  OrganizationConfigRuleTriggerTypeNoSN[];
export const OrganizationConfigRuleTriggerTypeNoSNs = /*@__PURE__*/ S.Array(
  OrganizationConfigRuleTriggerTypeNoSN,
);
export type DebugLogDeliveryAccounts = string[];
export const DebugLogDeliveryAccounts = /*@__PURE__*/ S.Array(S.String);
export interface OrganizationCustomPolicyRuleMetadataNoPolicy {
  Description?: string;
  OrganizationConfigRuleTriggerTypes?: OrganizationConfigRuleTriggerTypeNoSN[];
  InputParameters?: string;
  MaximumExecutionFrequency?: MaximumExecutionFrequency;
  ResourceTypesScope?: string[];
  ResourceIdScope?: string;
  TagKeyScope?: string;
  TagValueScope?: string;
  PolicyRuntime?: string;
  DebugLogDeliveryAccounts?: string[];
}
export const OrganizationCustomPolicyRuleMetadataNoPolicy =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      Description: S.optional(S.String),
      OrganizationConfigRuleTriggerTypes: S.optional(
        OrganizationConfigRuleTriggerTypeNoSNs,
      ),
      InputParameters: S.optional(S.String),
      MaximumExecutionFrequency: S.optional(MaximumExecutionFrequency),
      ResourceTypesScope: S.optional(ResourceTypesScope),
      ResourceIdScope: S.optional(S.String),
      TagKeyScope: S.optional(S.String),
      TagValueScope: S.optional(S.String),
      PolicyRuntime: S.optional(S.String),
      DebugLogDeliveryAccounts: S.optional(DebugLogDeliveryAccounts),
    }),
  ).annotate({
    identifier: "OrganizationCustomPolicyRuleMetadataNoPolicy",
  }) as any as S.Schema<OrganizationCustomPolicyRuleMetadataNoPolicy>;
export interface OrganizationConfigRule {
  OrganizationConfigRuleName: string;
  OrganizationConfigRuleArn: string;
  OrganizationManagedRuleMetadata?: OrganizationManagedRuleMetadata;
  OrganizationCustomRuleMetadata?: OrganizationCustomRuleMetadata;
  ExcludedAccounts?: string[];
  LastUpdateTime?: Date;
  OrganizationCustomPolicyRuleMetadata?: OrganizationCustomPolicyRuleMetadataNoPolicy;
}
export const OrganizationConfigRule = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    OrganizationConfigRuleName: S.String,
    OrganizationConfigRuleArn: S.String,
    OrganizationManagedRuleMetadata: S.optional(
      OrganizationManagedRuleMetadata,
    ),
    OrganizationCustomRuleMetadata: S.optional(OrganizationCustomRuleMetadata),
    ExcludedAccounts: S.optional(ExcludedAccounts),
    LastUpdateTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
    OrganizationCustomPolicyRuleMetadata: S.optional(
      OrganizationCustomPolicyRuleMetadataNoPolicy,
    ),
  }),
).annotate({
  identifier: "OrganizationConfigRule",
}) as any as S.Schema<OrganizationConfigRule>;
export type OrganizationConfigRules = OrganizationConfigRule[];
export const OrganizationConfigRules = /*@__PURE__*/ S.Array(
  OrganizationConfigRule,
);
export interface DescribeOrganizationConfigRulesResponse {
  OrganizationConfigRules?: OrganizationConfigRule[];
  NextToken?: string;
}
export const DescribeOrganizationConfigRulesResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      OrganizationConfigRules: S.optional(OrganizationConfigRules),
      NextToken: S.optional(S.String),
    }).pipe(ns),
).annotate({
  identifier: "DescribeOrganizationConfigRulesResponse",
}) as any as S.Schema<DescribeOrganizationConfigRulesResponse>;
export interface DescribeOrganizationConfigRuleStatusesRequest {
  OrganizationConfigRuleNames?: string[];
  Limit?: number;
  NextToken?: string;
}
export const DescribeOrganizationConfigRuleStatusesRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      OrganizationConfigRuleNames: S.optional(OrganizationConfigRuleNames),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "DescribeOrganizationConfigRuleStatusesRequest",
  }) as any as S.Schema<DescribeOrganizationConfigRuleStatusesRequest>;
export type OrganizationRuleStatus =
  | "CREATE_SUCCESSFUL"
  | "CREATE_IN_PROGRESS"
  | "CREATE_FAILED"
  | "DELETE_SUCCESSFUL"
  | "DELETE_FAILED"
  | "DELETE_IN_PROGRESS"
  | "UPDATE_SUCCESSFUL"
  | "UPDATE_IN_PROGRESS"
  | "UPDATE_FAILED"
  | (string & {});
export const OrganizationRuleStatus = S.String;

export interface OrganizationConfigRuleStatus {
  OrganizationConfigRuleName: string;
  OrganizationRuleStatus: OrganizationRuleStatus;
  ErrorCode?: string;
  ErrorMessage?: string;
  LastUpdateTime?: Date;
}
export const OrganizationConfigRuleStatus = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    OrganizationConfigRuleName: S.String,
    OrganizationRuleStatus: OrganizationRuleStatus,
    ErrorCode: S.optional(S.String),
    ErrorMessage: S.optional(S.String),
    LastUpdateTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
  }),
).annotate({
  identifier: "OrganizationConfigRuleStatus",
}) as any as S.Schema<OrganizationConfigRuleStatus>;
export type OrganizationConfigRuleStatuses = OrganizationConfigRuleStatus[];
export const OrganizationConfigRuleStatuses = /*@__PURE__*/ S.Array(
  OrganizationConfigRuleStatus,
);
export interface DescribeOrganizationConfigRuleStatusesResponse {
  OrganizationConfigRuleStatuses?: OrganizationConfigRuleStatus[];
  NextToken?: string;
}
export const DescribeOrganizationConfigRuleStatusesResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      OrganizationConfigRuleStatuses: S.optional(
        OrganizationConfigRuleStatuses,
      ),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "DescribeOrganizationConfigRuleStatusesResponse",
  }) as any as S.Schema<DescribeOrganizationConfigRuleStatusesResponse>;
export type OrganizationConformancePackNames = string[];
export const OrganizationConformancePackNames = /*@__PURE__*/ S.Array(S.String);
export interface DescribeOrganizationConformancePacksRequest {
  OrganizationConformancePackNames?: string[];
  Limit?: number;
  NextToken?: string;
}
export const DescribeOrganizationConformancePacksRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      OrganizationConformancePackNames: S.optional(
        OrganizationConformancePackNames,
      ),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "DescribeOrganizationConformancePacksRequest",
  }) as any as S.Schema<DescribeOrganizationConformancePacksRequest>;
export interface OrganizationConformancePack {
  OrganizationConformancePackName: string;
  OrganizationConformancePackArn: string;
  DeliveryS3Bucket?: string;
  DeliveryS3KeyPrefix?: string;
  ConformancePackInputParameters?: ConformancePackInputParameter[];
  ExcludedAccounts?: string[];
  LastUpdateTime: Date;
}
export const OrganizationConformancePack = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    OrganizationConformancePackName: S.String,
    OrganizationConformancePackArn: S.String,
    DeliveryS3Bucket: S.optional(S.String),
    DeliveryS3KeyPrefix: S.optional(S.String),
    ConformancePackInputParameters: S.optional(ConformancePackInputParameters),
    ExcludedAccounts: S.optional(ExcludedAccounts),
    LastUpdateTime: S.Date.pipe(T.TimestampFormat("epoch-seconds")),
  }),
).annotate({
  identifier: "OrganizationConformancePack",
}) as any as S.Schema<OrganizationConformancePack>;
export type OrganizationConformancePacks = OrganizationConformancePack[];
export const OrganizationConformancePacks = /*@__PURE__*/ S.Array(
  OrganizationConformancePack,
);
export interface DescribeOrganizationConformancePacksResponse {
  OrganizationConformancePacks?: OrganizationConformancePack[];
  NextToken?: string;
}
export const DescribeOrganizationConformancePacksResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      OrganizationConformancePacks: S.optional(OrganizationConformancePacks),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "DescribeOrganizationConformancePacksResponse",
  }) as any as S.Schema<DescribeOrganizationConformancePacksResponse>;
export interface DescribeOrganizationConformancePackStatusesRequest {
  OrganizationConformancePackNames?: string[];
  Limit?: number;
  NextToken?: string;
}
export const DescribeOrganizationConformancePackStatusesRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      OrganizationConformancePackNames: S.optional(
        OrganizationConformancePackNames,
      ),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "DescribeOrganizationConformancePackStatusesRequest",
  }) as any as S.Schema<DescribeOrganizationConformancePackStatusesRequest>;
export type OrganizationResourceStatus =
  | "CREATE_SUCCESSFUL"
  | "CREATE_IN_PROGRESS"
  | "CREATE_FAILED"
  | "DELETE_SUCCESSFUL"
  | "DELETE_FAILED"
  | "DELETE_IN_PROGRESS"
  | "UPDATE_SUCCESSFUL"
  | "UPDATE_IN_PROGRESS"
  | "UPDATE_FAILED"
  | (string & {});
export const OrganizationResourceStatus = S.String;

export interface OrganizationConformancePackStatus {
  OrganizationConformancePackName: string;
  Status: OrganizationResourceStatus;
  ErrorCode?: string;
  ErrorMessage?: string;
  LastUpdateTime?: Date;
}
export const OrganizationConformancePackStatus = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    OrganizationConformancePackName: S.String,
    Status: OrganizationResourceStatus,
    ErrorCode: S.optional(S.String),
    ErrorMessage: S.optional(S.String),
    LastUpdateTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
  }),
).annotate({
  identifier: "OrganizationConformancePackStatus",
}) as any as S.Schema<OrganizationConformancePackStatus>;
export type OrganizationConformancePackStatuses =
  OrganizationConformancePackStatus[];
export const OrganizationConformancePackStatuses = /*@__PURE__*/ S.Array(
  OrganizationConformancePackStatus,
);
export interface DescribeOrganizationConformancePackStatusesResponse {
  OrganizationConformancePackStatuses?: OrganizationConformancePackStatus[];
  NextToken?: string;
}
export const DescribeOrganizationConformancePackStatusesResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      OrganizationConformancePackStatuses: S.optional(
        OrganizationConformancePackStatuses,
      ),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "DescribeOrganizationConformancePackStatusesResponse",
  }) as any as S.Schema<DescribeOrganizationConformancePackStatusesResponse>;
export type DescribePendingAggregationRequestsLimit = number;
export interface DescribePendingAggregationRequestsRequest {
  Limit?: number;
  NextToken?: string;
}
export const DescribePendingAggregationRequestsRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "DescribePendingAggregationRequestsRequest",
  }) as any as S.Schema<DescribePendingAggregationRequestsRequest>;
export interface PendingAggregationRequest {
  RequesterAccountId?: string;
  RequesterAwsRegion?: string;
}
export const PendingAggregationRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    RequesterAccountId: S.optional(S.String),
    RequesterAwsRegion: S.optional(S.String),
  }),
).annotate({
  identifier: "PendingAggregationRequest",
}) as any as S.Schema<PendingAggregationRequest>;
export type PendingAggregationRequestList = PendingAggregationRequest[];
export const PendingAggregationRequestList = /*@__PURE__*/ S.Array(
  PendingAggregationRequest,
);
export interface DescribePendingAggregationRequestsResponse {
  PendingAggregationRequests?: PendingAggregationRequest[];
  NextToken?: string;
}
export const DescribePendingAggregationRequestsResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      PendingAggregationRequests: S.optional(PendingAggregationRequestList),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "DescribePendingAggregationRequestsResponse",
  }) as any as S.Schema<DescribePendingAggregationRequestsResponse>;
export interface DescribeRemediationConfigurationsRequest {
  ConfigRuleNames: string[];
}
export const DescribeRemediationConfigurationsRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({ ConfigRuleNames: ConfigRuleNames }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DescribeRemediationConfigurationsRequest",
}) as any as S.Schema<DescribeRemediationConfigurationsRequest>;
export type RemediationTargetType = "SSM_DOCUMENT" | (string & {});
export const RemediationTargetType = S.String;

export type ResourceValueType = "RESOURCE_ID" | (string & {});
export const ResourceValueType = S.String;

export interface ResourceValue {
  Value: ResourceValueType;
}
export const ResourceValue = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ Value: ResourceValueType }),
).annotate({ identifier: "ResourceValue" }) as any as S.Schema<ResourceValue>;
export type StaticParameterValues = string[];
export const StaticParameterValues = /*@__PURE__*/ S.Array(S.String);
export interface StaticValue {
  Values: string[];
}
export const StaticValue = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ Values: StaticParameterValues }),
).annotate({ identifier: "StaticValue" }) as any as S.Schema<StaticValue>;
export interface RemediationParameterValue {
  ResourceValue?: ResourceValue;
  StaticValue?: StaticValue;
}
export const RemediationParameterValue = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceValue: S.optional(ResourceValue),
    StaticValue: S.optional(StaticValue),
  }),
).annotate({
  identifier: "RemediationParameterValue",
}) as any as S.Schema<RemediationParameterValue>;
export type RemediationParameters = {
  [key: string]: RemediationParameterValue | undefined;
};
export const RemediationParameters = /*@__PURE__*/ S.Record(
  S.String,
  RemediationParameterValue.pipe(S.optional),
);
export type Percentage = number;
export interface SsmControls {
  ConcurrentExecutionRatePercentage?: number;
  ErrorPercentage?: number;
}
export const SsmControls = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConcurrentExecutionRatePercentage: S.optional(S.Number),
    ErrorPercentage: S.optional(S.Number),
  }),
).annotate({ identifier: "SsmControls" }) as any as S.Schema<SsmControls>;
export interface ExecutionControls {
  SsmControls?: SsmControls;
}
export const ExecutionControls = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ SsmControls: S.optional(SsmControls) }),
).annotate({
  identifier: "ExecutionControls",
}) as any as S.Schema<ExecutionControls>;
export type AutoRemediationAttempts = number;
export type AutoRemediationAttemptSeconds = number;
export interface RemediationConfiguration {
  ConfigRuleName: string;
  TargetType: RemediationTargetType;
  TargetId: string;
  TargetVersion?: string;
  Parameters?: { [key: string]: RemediationParameterValue | undefined };
  ResourceType?: string;
  Automatic?: boolean;
  ExecutionControls?: ExecutionControls;
  MaximumAutomaticAttempts?: number;
  RetryAttemptSeconds?: number;
  Arn?: string;
  CreatedByService?: string;
}
export const RemediationConfiguration = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleName: S.String,
    TargetType: RemediationTargetType,
    TargetId: S.String,
    TargetVersion: S.optional(S.String),
    Parameters: S.optional(RemediationParameters),
    ResourceType: S.optional(S.String),
    Automatic: S.optional(S.Boolean),
    ExecutionControls: S.optional(ExecutionControls),
    MaximumAutomaticAttempts: S.optional(S.Number),
    RetryAttemptSeconds: S.optional(S.Number),
    Arn: S.optional(S.String),
    CreatedByService: S.optional(S.String),
  }),
).annotate({
  identifier: "RemediationConfiguration",
}) as any as S.Schema<RemediationConfiguration>;
export type RemediationConfigurations = RemediationConfiguration[];
export const RemediationConfigurations = /*@__PURE__*/ S.Array(
  RemediationConfiguration,
);
export interface DescribeRemediationConfigurationsResponse {
  RemediationConfigurations?: RemediationConfiguration[];
}
export const DescribeRemediationConfigurationsResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      RemediationConfigurations: S.optional(RemediationConfigurations),
    }).pipe(ns),
  ).annotate({
    identifier: "DescribeRemediationConfigurationsResponse",
  }) as any as S.Schema<DescribeRemediationConfigurationsResponse>;
export interface DescribeRemediationExceptionsRequest {
  ConfigRuleName: string;
  ResourceKeys?: RemediationExceptionResourceKey[];
  Limit?: number;
  NextToken?: string;
}
export const DescribeRemediationExceptionsRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConfigRuleName: S.String,
      ResourceKeys: S.optional(RemediationExceptionResourceKeys),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DescribeRemediationExceptionsRequest",
}) as any as S.Schema<DescribeRemediationExceptionsRequest>;
export interface RemediationException {
  ConfigRuleName: string;
  ResourceType: string;
  ResourceId: string;
  Message?: string;
  ExpirationTime?: Date;
}
export const RemediationException = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleName: S.String,
    ResourceType: S.String,
    ResourceId: S.String,
    Message: S.optional(S.String),
    ExpirationTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
  }),
).annotate({
  identifier: "RemediationException",
}) as any as S.Schema<RemediationException>;
export type RemediationExceptions = RemediationException[];
export const RemediationExceptions =
  /*@__PURE__*/ S.Array(RemediationException);
export interface DescribeRemediationExceptionsResponse {
  RemediationExceptions?: RemediationException[];
  NextToken?: string;
}
export const DescribeRemediationExceptionsResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      RemediationExceptions: S.optional(RemediationExceptions),
      NextToken: S.optional(S.String),
    }).pipe(ns),
).annotate({
  identifier: "DescribeRemediationExceptionsResponse",
}) as any as S.Schema<DescribeRemediationExceptionsResponse>;
export interface DescribeRemediationExecutionStatusRequest {
  ConfigRuleName: string;
  ResourceKeys?: ResourceKey[];
  Limit?: number;
  NextToken?: string;
}
export const DescribeRemediationExecutionStatusRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConfigRuleName: S.String,
      ResourceKeys: S.optional(ResourceKeys),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "DescribeRemediationExecutionStatusRequest",
  }) as any as S.Schema<DescribeRemediationExecutionStatusRequest>;
export type RemediationExecutionState =
  | "QUEUED"
  | "IN_PROGRESS"
  | "SUCCEEDED"
  | "FAILED"
  | "UNKNOWN"
  | (string & {});
export const RemediationExecutionState = S.String;

export type RemediationExecutionStepState =
  | "SUCCEEDED"
  | "PENDING"
  | "FAILED"
  | "IN_PROGRESS"
  | "EXITED"
  | "UNKNOWN"
  | (string & {});
export const RemediationExecutionStepState = S.String;

export interface RemediationExecutionStep {
  Name?: string;
  State?: RemediationExecutionStepState;
  ErrorMessage?: string;
  StartTime?: Date;
  StopTime?: Date;
}
export const RemediationExecutionStep = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    Name: S.optional(S.String),
    State: S.optional(RemediationExecutionStepState),
    ErrorMessage: S.optional(S.String),
    StartTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
    StopTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
  }),
).annotate({
  identifier: "RemediationExecutionStep",
}) as any as S.Schema<RemediationExecutionStep>;
export type RemediationExecutionSteps = RemediationExecutionStep[];
export const RemediationExecutionSteps = /*@__PURE__*/ S.Array(
  RemediationExecutionStep,
);
export interface RemediationExecutionStatus {
  ResourceKey?: ResourceKey;
  State?: RemediationExecutionState;
  StepDetails?: RemediationExecutionStep[];
  InvocationTime?: Date;
  LastUpdatedTime?: Date;
}
export const RemediationExecutionStatus = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceKey: S.optional(ResourceKey),
    State: S.optional(RemediationExecutionState),
    StepDetails: S.optional(RemediationExecutionSteps),
    InvocationTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
    LastUpdatedTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
  }),
).annotate({
  identifier: "RemediationExecutionStatus",
}) as any as S.Schema<RemediationExecutionStatus>;
export type RemediationExecutionStatuses = RemediationExecutionStatus[];
export const RemediationExecutionStatuses = /*@__PURE__*/ S.Array(
  RemediationExecutionStatus,
);
export interface DescribeRemediationExecutionStatusResponse {
  RemediationExecutionStatuses?: RemediationExecutionStatus[];
  NextToken?: string;
}
export const DescribeRemediationExecutionStatusResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      RemediationExecutionStatuses: S.optional(RemediationExecutionStatuses),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "DescribeRemediationExecutionStatusResponse",
  }) as any as S.Schema<DescribeRemediationExecutionStatusResponse>;
export type RetentionConfigurationNameList = string[];
export const RetentionConfigurationNameList = /*@__PURE__*/ S.Array(S.String);
export interface DescribeRetentionConfigurationsRequest {
  RetentionConfigurationNames?: string[];
  NextToken?: string;
}
export const DescribeRetentionConfigurationsRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      RetentionConfigurationNames: S.optional(RetentionConfigurationNameList),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "DescribeRetentionConfigurationsRequest",
}) as any as S.Schema<DescribeRetentionConfigurationsRequest>;
export type RetentionPeriodInDays = number;
export interface RetentionConfiguration {
  Name: string;
  RetentionPeriodInDays: number;
}
export const RetentionConfiguration = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ Name: S.String, RetentionPeriodInDays: S.Number }),
).annotate({
  identifier: "RetentionConfiguration",
}) as any as S.Schema<RetentionConfiguration>;
export type RetentionConfigurationList = RetentionConfiguration[];
export const RetentionConfigurationList = /*@__PURE__*/ S.Array(
  RetentionConfiguration,
);
export interface DescribeRetentionConfigurationsResponse {
  RetentionConfigurations?: RetentionConfiguration[];
  NextToken?: string;
}
export const DescribeRetentionConfigurationsResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      RetentionConfigurations: S.optional(RetentionConfigurationList),
      NextToken: S.optional(S.String),
    }).pipe(ns),
).annotate({
  identifier: "DescribeRetentionConfigurationsResponse",
}) as any as S.Schema<DescribeRetentionConfigurationsResponse>;
export interface DisassociateResourceTypesRequest {
  ConfigurationRecorderArn: string;
  ResourceTypes: ResourceType[];
}
export const DisassociateResourceTypesRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigurationRecorderArn: S.String,
    ResourceTypes: ResourceTypeList,
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "DisassociateResourceTypesRequest",
}) as any as S.Schema<DisassociateResourceTypesRequest>;
export interface DisassociateResourceTypesResponse {
  ConfigurationRecorder: ConfigurationRecorder;
}
export const DisassociateResourceTypesResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConfigurationRecorder: ConfigurationRecorder }).pipe(ns),
).annotate({
  identifier: "DisassociateResourceTypesResponse",
}) as any as S.Schema<DisassociateResourceTypesResponse>;
export interface GetAggregateComplianceDetailsByConfigRuleRequest {
  ConfigurationAggregatorName: string;
  ConfigRuleName: string;
  AccountId: string;
  AwsRegion: string;
  ComplianceType?: ComplianceType;
  Limit?: number;
  NextToken?: string;
}
export const GetAggregateComplianceDetailsByConfigRuleRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConfigurationAggregatorName: S.String,
      ConfigRuleName: S.String,
      AccountId: S.String,
      AwsRegion: S.String,
      ComplianceType: S.optional(ComplianceType),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "GetAggregateComplianceDetailsByConfigRuleRequest",
  }) as any as S.Schema<GetAggregateComplianceDetailsByConfigRuleRequest>;
export interface EvaluationResultQualifier {
  ConfigRuleName?: string;
  ResourceType?: string;
  ResourceId?: string;
  EvaluationMode?: EvaluationMode;
}
export const EvaluationResultQualifier = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleName: S.optional(S.String),
    ResourceType: S.optional(S.String),
    ResourceId: S.optional(S.String),
    EvaluationMode: S.optional(EvaluationMode),
  }),
).annotate({
  identifier: "EvaluationResultQualifier",
}) as any as S.Schema<EvaluationResultQualifier>;
export type ResourceEvaluationId = string;
export interface EvaluationResultIdentifier {
  EvaluationResultQualifier?: EvaluationResultQualifier;
  OrderingTimestamp?: Date;
  ResourceEvaluationId?: string;
}
export const EvaluationResultIdentifier = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    EvaluationResultQualifier: S.optional(EvaluationResultQualifier),
    OrderingTimestamp: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    ResourceEvaluationId: S.optional(S.String),
  }),
).annotate({
  identifier: "EvaluationResultIdentifier",
}) as any as S.Schema<EvaluationResultIdentifier>;
export interface AggregateEvaluationResult {
  EvaluationResultIdentifier?: EvaluationResultIdentifier;
  ComplianceType?: ComplianceType;
  ResultRecordedTime?: Date;
  ConfigRuleInvokedTime?: Date;
  Annotation?: string;
  AccountId?: string;
  AwsRegion?: string;
}
export const AggregateEvaluationResult = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    EvaluationResultIdentifier: S.optional(EvaluationResultIdentifier),
    ComplianceType: S.optional(ComplianceType),
    ResultRecordedTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    ConfigRuleInvokedTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    Annotation: S.optional(S.String),
    AccountId: S.optional(S.String),
    AwsRegion: S.optional(S.String),
  }),
).annotate({
  identifier: "AggregateEvaluationResult",
}) as any as S.Schema<AggregateEvaluationResult>;
export type AggregateEvaluationResultList = AggregateEvaluationResult[];
export const AggregateEvaluationResultList = /*@__PURE__*/ S.Array(
  AggregateEvaluationResult,
);
export interface GetAggregateComplianceDetailsByConfigRuleResponse {
  AggregateEvaluationResults?: AggregateEvaluationResult[];
  NextToken?: string;
}
export const GetAggregateComplianceDetailsByConfigRuleResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      AggregateEvaluationResults: S.optional(AggregateEvaluationResultList),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "GetAggregateComplianceDetailsByConfigRuleResponse",
  }) as any as S.Schema<GetAggregateComplianceDetailsByConfigRuleResponse>;
export interface ConfigRuleComplianceSummaryFilters {
  AccountId?: string;
  AwsRegion?: string;
}
export const ConfigRuleComplianceSummaryFilters = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    AccountId: S.optional(S.String),
    AwsRegion: S.optional(S.String),
  }),
).annotate({
  identifier: "ConfigRuleComplianceSummaryFilters",
}) as any as S.Schema<ConfigRuleComplianceSummaryFilters>;
export type ConfigRuleComplianceSummaryGroupKey =
  | "ACCOUNT_ID"
  | "AWS_REGION"
  | (string & {});
export const ConfigRuleComplianceSummaryGroupKey = S.String;

export interface GetAggregateConfigRuleComplianceSummaryRequest {
  ConfigurationAggregatorName: string;
  Filters?: ConfigRuleComplianceSummaryFilters;
  GroupByKey?: ConfigRuleComplianceSummaryGroupKey;
  Limit?: number;
  NextToken?: string;
}
export const GetAggregateConfigRuleComplianceSummaryRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConfigurationAggregatorName: S.String,
      Filters: S.optional(ConfigRuleComplianceSummaryFilters),
      GroupByKey: S.optional(ConfigRuleComplianceSummaryGroupKey),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "GetAggregateConfigRuleComplianceSummaryRequest",
  }) as any as S.Schema<GetAggregateConfigRuleComplianceSummaryRequest>;
export interface ComplianceSummary {
  CompliantResourceCount?: ComplianceContributorCount;
  NonCompliantResourceCount?: ComplianceContributorCount;
  ComplianceSummaryTimestamp?: Date;
}
export const ComplianceSummary = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    CompliantResourceCount: S.optional(ComplianceContributorCount),
    NonCompliantResourceCount: S.optional(ComplianceContributorCount),
    ComplianceSummaryTimestamp: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
  }),
).annotate({
  identifier: "ComplianceSummary",
}) as any as S.Schema<ComplianceSummary>;
export interface AggregateComplianceCount {
  GroupName?: string;
  ComplianceSummary?: ComplianceSummary;
}
export const AggregateComplianceCount = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    GroupName: S.optional(S.String),
    ComplianceSummary: S.optional(ComplianceSummary),
  }),
).annotate({
  identifier: "AggregateComplianceCount",
}) as any as S.Schema<AggregateComplianceCount>;
export type AggregateComplianceCountList = AggregateComplianceCount[];
export const AggregateComplianceCountList = /*@__PURE__*/ S.Array(
  AggregateComplianceCount,
);
export interface GetAggregateConfigRuleComplianceSummaryResponse {
  GroupByKey?: string;
  AggregateComplianceCounts?: AggregateComplianceCount[];
  NextToken?: string;
}
export const GetAggregateConfigRuleComplianceSummaryResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      GroupByKey: S.optional(S.String),
      AggregateComplianceCounts: S.optional(AggregateComplianceCountList),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "GetAggregateConfigRuleComplianceSummaryResponse",
  }) as any as S.Schema<GetAggregateConfigRuleComplianceSummaryResponse>;
export interface AggregateConformancePackComplianceSummaryFilters {
  AccountId?: string;
  AwsRegion?: string;
}
export const AggregateConformancePackComplianceSummaryFilters =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      AccountId: S.optional(S.String),
      AwsRegion: S.optional(S.String),
    }),
  ).annotate({
    identifier: "AggregateConformancePackComplianceSummaryFilters",
  }) as any as S.Schema<AggregateConformancePackComplianceSummaryFilters>;
export type AggregateConformancePackComplianceSummaryGroupKey =
  | "ACCOUNT_ID"
  | "AWS_REGION"
  | (string & {});
export const AggregateConformancePackComplianceSummaryGroupKey = S.String;

export interface GetAggregateConformancePackComplianceSummaryRequest {
  ConfigurationAggregatorName: string;
  Filters?: AggregateConformancePackComplianceSummaryFilters;
  GroupByKey?: AggregateConformancePackComplianceSummaryGroupKey;
  Limit?: number;
  NextToken?: string;
}
export const GetAggregateConformancePackComplianceSummaryRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConfigurationAggregatorName: S.String,
      Filters: S.optional(AggregateConformancePackComplianceSummaryFilters),
      GroupByKey: S.optional(AggregateConformancePackComplianceSummaryGroupKey),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "GetAggregateConformancePackComplianceSummaryRequest",
  }) as any as S.Schema<GetAggregateConformancePackComplianceSummaryRequest>;
export interface AggregateConformancePackComplianceCount {
  CompliantConformancePackCount?: number;
  NonCompliantConformancePackCount?: number;
}
export const AggregateConformancePackComplianceCount = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      CompliantConformancePackCount: S.optional(S.Number),
      NonCompliantConformancePackCount: S.optional(S.Number),
    }),
).annotate({
  identifier: "AggregateConformancePackComplianceCount",
}) as any as S.Schema<AggregateConformancePackComplianceCount>;
export interface AggregateConformancePackComplianceSummary {
  ComplianceSummary?: AggregateConformancePackComplianceCount;
  GroupName?: string;
}
export const AggregateConformancePackComplianceSummary =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ComplianceSummary: S.optional(AggregateConformancePackComplianceCount),
      GroupName: S.optional(S.String),
    }),
  ).annotate({
    identifier: "AggregateConformancePackComplianceSummary",
  }) as any as S.Schema<AggregateConformancePackComplianceSummary>;
export type AggregateConformancePackComplianceSummaryList =
  AggregateConformancePackComplianceSummary[];
export const AggregateConformancePackComplianceSummaryList =
  /*@__PURE__*/ S.Array(AggregateConformancePackComplianceSummary);
export interface GetAggregateConformancePackComplianceSummaryResponse {
  AggregateConformancePackComplianceSummaries?: AggregateConformancePackComplianceSummary[];
  GroupByKey?: string;
  NextToken?: string;
}
export const GetAggregateConformancePackComplianceSummaryResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      AggregateConformancePackComplianceSummaries: S.optional(
        AggregateConformancePackComplianceSummaryList,
      ),
      GroupByKey: S.optional(S.String),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "GetAggregateConformancePackComplianceSummaryResponse",
  }) as any as S.Schema<GetAggregateConformancePackComplianceSummaryResponse>;
export interface ResourceCountFilters {
  ResourceType?: ResourceType;
  AccountId?: string;
  Region?: string;
}
export const ResourceCountFilters = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceType: S.optional(ResourceType),
    AccountId: S.optional(S.String),
    Region: S.optional(S.String),
  }),
).annotate({
  identifier: "ResourceCountFilters",
}) as any as S.Schema<ResourceCountFilters>;
export type ResourceCountGroupKey =
  | "RESOURCE_TYPE"
  | "ACCOUNT_ID"
  | "AWS_REGION"
  | (string & {});
export const ResourceCountGroupKey = S.String;

export interface GetAggregateDiscoveredResourceCountsRequest {
  ConfigurationAggregatorName: string;
  Filters?: ResourceCountFilters;
  GroupByKey?: ResourceCountGroupKey;
  Limit?: number;
  NextToken?: string;
}
export const GetAggregateDiscoveredResourceCountsRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConfigurationAggregatorName: S.String,
      Filters: S.optional(ResourceCountFilters),
      GroupByKey: S.optional(ResourceCountGroupKey),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "GetAggregateDiscoveredResourceCountsRequest",
  }) as any as S.Schema<GetAggregateDiscoveredResourceCountsRequest>;
export interface GroupedResourceCount {
  GroupName: string;
  ResourceCount: number;
}
export const GroupedResourceCount = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ GroupName: S.String, ResourceCount: S.Number }),
).annotate({
  identifier: "GroupedResourceCount",
}) as any as S.Schema<GroupedResourceCount>;
export type GroupedResourceCountList = GroupedResourceCount[];
export const GroupedResourceCountList =
  /*@__PURE__*/ S.Array(GroupedResourceCount);
export interface GetAggregateDiscoveredResourceCountsResponse {
  TotalDiscoveredResources: number;
  GroupByKey?: string;
  GroupedResourceCounts?: GroupedResourceCount[];
  NextToken?: string;
}
export const GetAggregateDiscoveredResourceCountsResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      TotalDiscoveredResources: S.Number,
      GroupByKey: S.optional(S.String),
      GroupedResourceCounts: S.optional(GroupedResourceCountList),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "GetAggregateDiscoveredResourceCountsResponse",
  }) as any as S.Schema<GetAggregateDiscoveredResourceCountsResponse>;
export interface GetAggregateResourceConfigRequest {
  ConfigurationAggregatorName: string;
  ResourceIdentifier: AggregateResourceIdentifier;
}
export const GetAggregateResourceConfigRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigurationAggregatorName: S.String,
    ResourceIdentifier: AggregateResourceIdentifier,
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "GetAggregateResourceConfigRequest",
}) as any as S.Schema<GetAggregateResourceConfigRequest>;
export type ConfigurationItemMD5Hash = string;
export type Name = string;
export type Value = string;
export type Tags = { [key: string]: string | undefined };
export const Tags = /*@__PURE__*/ S.Record(S.String, S.String.pipe(S.optional));
export type RelatedEvent = string;
export type RelatedEventList = string[];
export const RelatedEventList = /*@__PURE__*/ S.Array(S.String);
export type RelationshipName = string;
export interface Relationship {
  resourceType?: ResourceType;
  resourceId?: string;
  resourceName?: string;
  relationshipName?: string;
}
export const Relationship = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    resourceType: S.optional(ResourceType),
    resourceId: S.optional(S.String),
    resourceName: S.optional(S.String),
    relationshipName: S.optional(S.String),
  }),
).annotate({ identifier: "Relationship" }) as any as S.Schema<Relationship>;
export type RelationshipList = Relationship[];
export const RelationshipList = /*@__PURE__*/ S.Array(Relationship);
export interface ConfigurationItem {
  version?: string;
  accountId?: string;
  configurationItemCaptureTime?: Date;
  configurationItemStatus?: ConfigurationItemStatus;
  configurationStateId?: string;
  configurationItemMD5Hash?: string;
  arn?: string;
  resourceType?: ResourceType;
  resourceId?: string;
  resourceName?: string;
  awsRegion?: string;
  availabilityZone?: string;
  resourceCreationTime?: Date;
  tags?: { [key: string]: string | undefined };
  relatedEvents?: string[];
  relationships?: Relationship[];
  configuration?: string;
  supplementaryConfiguration?: { [key: string]: string | undefined };
  recordingFrequency?: RecordingFrequency;
  configurationItemDeliveryTime?: Date;
}
export const ConfigurationItem = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    version: S.optional(S.String),
    accountId: S.optional(S.String),
    configurationItemCaptureTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    configurationItemStatus: S.optional(ConfigurationItemStatus),
    configurationStateId: S.optional(S.String),
    configurationItemMD5Hash: S.optional(S.String),
    arn: S.optional(S.String),
    resourceType: S.optional(ResourceType),
    resourceId: S.optional(S.String),
    resourceName: S.optional(S.String),
    awsRegion: S.optional(S.String),
    availabilityZone: S.optional(S.String),
    resourceCreationTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    tags: S.optional(Tags),
    relatedEvents: S.optional(RelatedEventList),
    relationships: S.optional(RelationshipList),
    configuration: S.optional(S.String),
    supplementaryConfiguration: S.optional(SupplementaryConfiguration),
    recordingFrequency: S.optional(RecordingFrequency),
    configurationItemDeliveryTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
  }),
).annotate({
  identifier: "ConfigurationItem",
}) as any as S.Schema<ConfigurationItem>;
export interface GetAggregateResourceConfigResponse {
  ConfigurationItem?: ConfigurationItem;
}
export const GetAggregateResourceConfigResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConfigurationItem: S.optional(ConfigurationItem) }).pipe(ns),
).annotate({
  identifier: "GetAggregateResourceConfigResponse",
}) as any as S.Schema<GetAggregateResourceConfigResponse>;
export interface GetComplianceDetailsByConfigRuleRequest {
  ConfigRuleName: string;
  ComplianceTypes?: ComplianceType[];
  Limit?: number;
  NextToken?: string;
}
export const GetComplianceDetailsByConfigRuleRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConfigRuleName: S.String,
      ComplianceTypes: S.optional(ComplianceTypes),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "GetComplianceDetailsByConfigRuleRequest",
}) as any as S.Schema<GetComplianceDetailsByConfigRuleRequest>;
export interface EvaluationResult {
  EvaluationResultIdentifier?: EvaluationResultIdentifier;
  ComplianceType?: ComplianceType;
  ResultRecordedTime?: Date;
  ConfigRuleInvokedTime?: Date;
  Annotation?: string;
  ResultToken?: string;
}
export const EvaluationResult = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    EvaluationResultIdentifier: S.optional(EvaluationResultIdentifier),
    ComplianceType: S.optional(ComplianceType),
    ResultRecordedTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    ConfigRuleInvokedTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
    Annotation: S.optional(S.String),
    ResultToken: S.optional(S.String),
  }),
).annotate({
  identifier: "EvaluationResult",
}) as any as S.Schema<EvaluationResult>;
export type EvaluationResults = EvaluationResult[];
export const EvaluationResults = /*@__PURE__*/ S.Array(EvaluationResult);
export interface GetComplianceDetailsByConfigRuleResponse {
  EvaluationResults?: EvaluationResult[];
  NextToken?: string;
}
export const GetComplianceDetailsByConfigRuleResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      EvaluationResults: S.optional(EvaluationResults),
      NextToken: S.optional(S.String),
    }).pipe(ns),
).annotate({
  identifier: "GetComplianceDetailsByConfigRuleResponse",
}) as any as S.Schema<GetComplianceDetailsByConfigRuleResponse>;
export interface GetComplianceDetailsByResourceRequest {
  ResourceType?: string;
  ResourceId?: string;
  ComplianceTypes?: ComplianceType[];
  NextToken?: string;
  ResourceEvaluationId?: string;
}
export const GetComplianceDetailsByResourceRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ResourceType: S.optional(S.String),
      ResourceId: S.optional(S.String),
      ComplianceTypes: S.optional(ComplianceTypes),
      NextToken: S.optional(S.String),
      ResourceEvaluationId: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "GetComplianceDetailsByResourceRequest",
}) as any as S.Schema<GetComplianceDetailsByResourceRequest>;
export interface GetComplianceDetailsByResourceResponse {
  EvaluationResults?: EvaluationResult[];
  NextToken?: string;
}
export const GetComplianceDetailsByResourceResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      EvaluationResults: S.optional(EvaluationResults),
      NextToken: S.optional(S.String),
    }).pipe(ns),
).annotate({
  identifier: "GetComplianceDetailsByResourceResponse",
}) as any as S.Schema<GetComplianceDetailsByResourceResponse>;
export interface GetComplianceSummaryByConfigRuleRequest {}
export const GetComplianceSummaryByConfigRuleRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({}).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "GetComplianceSummaryByConfigRuleRequest",
}) as any as S.Schema<GetComplianceSummaryByConfigRuleRequest>;
export interface GetComplianceSummaryByConfigRuleResponse {
  ComplianceSummary?: ComplianceSummary;
}
export const GetComplianceSummaryByConfigRuleResponse = /*@__PURE__*/ S.suspend(
  () => S.Struct({ ComplianceSummary: S.optional(ComplianceSummary) }).pipe(ns),
).annotate({
  identifier: "GetComplianceSummaryByConfigRuleResponse",
}) as any as S.Schema<GetComplianceSummaryByConfigRuleResponse>;
export type ResourceTypes = string[];
export const ResourceTypes = /*@__PURE__*/ S.Array(S.String);
export interface GetComplianceSummaryByResourceTypeRequest {
  ResourceTypes?: string[];
}
export const GetComplianceSummaryByResourceTypeRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({ ResourceTypes: S.optional(ResourceTypes) }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "GetComplianceSummaryByResourceTypeRequest",
  }) as any as S.Schema<GetComplianceSummaryByResourceTypeRequest>;
export interface ComplianceSummaryByResourceType {
  ResourceType?: string;
  ComplianceSummary?: ComplianceSummary;
}
export const ComplianceSummaryByResourceType = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceType: S.optional(S.String),
    ComplianceSummary: S.optional(ComplianceSummary),
  }),
).annotate({
  identifier: "ComplianceSummaryByResourceType",
}) as any as S.Schema<ComplianceSummaryByResourceType>;
export type ComplianceSummariesByResourceType =
  ComplianceSummaryByResourceType[];
export const ComplianceSummariesByResourceType = /*@__PURE__*/ S.Array(
  ComplianceSummaryByResourceType,
);
export interface GetComplianceSummaryByResourceTypeResponse {
  ComplianceSummariesByResourceType?: ComplianceSummaryByResourceType[];
}
export const GetComplianceSummaryByResourceTypeResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ComplianceSummariesByResourceType: S.optional(
        ComplianceSummariesByResourceType,
      ),
    }).pipe(ns),
  ).annotate({
    identifier: "GetComplianceSummaryByResourceTypeResponse",
  }) as any as S.Schema<GetComplianceSummaryByResourceTypeResponse>;
export type ConformancePackComplianceResourceIds = string[];
export const ConformancePackComplianceResourceIds = /*@__PURE__*/ S.Array(
  S.String,
);
export interface ConformancePackEvaluationFilters {
  ConfigRuleNames?: string[];
  ComplianceType?: ConformancePackComplianceType;
  ResourceType?: string;
  ResourceIds?: string[];
}
export const ConformancePackEvaluationFilters = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleNames: S.optional(ConformancePackConfigRuleNames),
    ComplianceType: S.optional(ConformancePackComplianceType),
    ResourceType: S.optional(S.String),
    ResourceIds: S.optional(ConformancePackComplianceResourceIds),
  }),
).annotate({
  identifier: "ConformancePackEvaluationFilters",
}) as any as S.Schema<ConformancePackEvaluationFilters>;
export type GetConformancePackComplianceDetailsLimit = number;
export interface GetConformancePackComplianceDetailsRequest {
  ConformancePackName: string;
  Filters?: ConformancePackEvaluationFilters;
  Limit?: number;
  NextToken?: string;
}
export const GetConformancePackComplianceDetailsRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConformancePackName: S.String,
      Filters: S.optional(ConformancePackEvaluationFilters),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "GetConformancePackComplianceDetailsRequest",
  }) as any as S.Schema<GetConformancePackComplianceDetailsRequest>;
export type Annotation = string;
export interface ConformancePackEvaluationResult {
  ComplianceType: ConformancePackComplianceType;
  EvaluationResultIdentifier: EvaluationResultIdentifier;
  ConfigRuleInvokedTime: Date;
  ResultRecordedTime: Date;
  Annotation?: string;
}
export const ConformancePackEvaluationResult = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ComplianceType: ConformancePackComplianceType,
    EvaluationResultIdentifier: EvaluationResultIdentifier,
    ConfigRuleInvokedTime: S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ResultRecordedTime: S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    Annotation: S.optional(S.String),
  }),
).annotate({
  identifier: "ConformancePackEvaluationResult",
}) as any as S.Schema<ConformancePackEvaluationResult>;
export type ConformancePackRuleEvaluationResultsList =
  ConformancePackEvaluationResult[];
export const ConformancePackRuleEvaluationResultsList = /*@__PURE__*/ S.Array(
  ConformancePackEvaluationResult,
);
export interface GetConformancePackComplianceDetailsResponse {
  ConformancePackName: string;
  ConformancePackRuleEvaluationResults?: ConformancePackEvaluationResult[];
  NextToken?: string;
}
export const GetConformancePackComplianceDetailsResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConformancePackName: S.String,
      ConformancePackRuleEvaluationResults: S.optional(
        ConformancePackRuleEvaluationResultsList,
      ),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "GetConformancePackComplianceDetailsResponse",
  }) as any as S.Schema<GetConformancePackComplianceDetailsResponse>;
export type ConformancePackNamesToSummarizeList = string[];
export const ConformancePackNamesToSummarizeList = /*@__PURE__*/ S.Array(
  S.String,
);
export interface GetConformancePackComplianceSummaryRequest {
  ConformancePackNames: string[];
  Limit?: number;
  NextToken?: string;
}
export const GetConformancePackComplianceSummaryRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConformancePackNames: ConformancePackNamesToSummarizeList,
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "GetConformancePackComplianceSummaryRequest",
  }) as any as S.Schema<GetConformancePackComplianceSummaryRequest>;
export interface ConformancePackComplianceSummary {
  ConformancePackName: string;
  ConformancePackComplianceStatus: ConformancePackComplianceType;
}
export const ConformancePackComplianceSummary = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConformancePackName: S.String,
    ConformancePackComplianceStatus: ConformancePackComplianceType,
  }),
).annotate({
  identifier: "ConformancePackComplianceSummary",
}) as any as S.Schema<ConformancePackComplianceSummary>;
export type ConformancePackComplianceSummaryList =
  ConformancePackComplianceSummary[];
export const ConformancePackComplianceSummaryList = /*@__PURE__*/ S.Array(
  ConformancePackComplianceSummary,
);
export interface GetConformancePackComplianceSummaryResponse {
  ConformancePackComplianceSummaryList?: ConformancePackComplianceSummary[];
  NextToken?: string;
}
export const GetConformancePackComplianceSummaryResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ConformancePackComplianceSummaryList: S.optional(
        ConformancePackComplianceSummaryList,
      ),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "GetConformancePackComplianceSummaryResponse",
  }) as any as S.Schema<GetConformancePackComplianceSummaryResponse>;
export interface GetConnectorRequest {
  Arn: string;
}
export const GetConnectorRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ Arn: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "GetConnectorRequest",
}) as any as S.Schema<GetConnectorRequest>;
export type ConnectorName = string;
export type AzureTenantIdentifier = string;
export type AzureClientIdentifier = string;
export interface AzureConnectorConfiguration {
  tenantIdentifier: string;
  clientIdentifier: string;
}
export const AzureConnectorConfiguration = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ tenantIdentifier: S.String, clientIdentifier: S.String }),
).annotate({
  identifier: "AzureConnectorConfiguration",
}) as any as S.Schema<AzureConnectorConfiguration>;
export interface ConnectorConfiguration {
  azure?: AzureConnectorConfiguration;
}
export const ConnectorConfiguration = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ azure: S.optional(AzureConnectorConfiguration) }),
).annotate({
  identifier: "ConnectorConfiguration",
}) as any as S.Schema<ConnectorConfiguration>;
export interface Connector {
  name: string;
  arn: string;
  connectorConfiguration: ConnectorConfiguration;
  createdTime: Date;
}
export const Connector = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    name: S.String,
    arn: S.String,
    connectorConfiguration: ConnectorConfiguration,
    createdTime: S.Date.pipe(T.TimestampFormat("epoch-seconds")),
  }),
).annotate({ identifier: "Connector" }) as any as S.Schema<Connector>;
export interface GetConnectorResponse {
  Connector: Connector;
}
export const GetConnectorResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ Connector: Connector }).pipe(ns),
).annotate({
  identifier: "GetConnectorResponse",
}) as any as S.Schema<GetConnectorResponse>;
export interface GetCustomRulePolicyRequest {
  ConfigRuleName?: string;
}
export const GetCustomRulePolicyRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConfigRuleName: S.optional(S.String) }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "GetCustomRulePolicyRequest",
}) as any as S.Schema<GetCustomRulePolicyRequest>;
export interface GetCustomRulePolicyResponse {
  PolicyText?: string;
}
export const GetCustomRulePolicyResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ PolicyText: S.optional(S.String) }).pipe(ns),
).annotate({
  identifier: "GetCustomRulePolicyResponse",
}) as any as S.Schema<GetCustomRulePolicyResponse>;
export interface GetDiscoveredResourceCountsRequest {
  resourceTypes?: string[];
  limit?: number;
  nextToken?: string;
}
export const GetDiscoveredResourceCountsRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    resourceTypes: S.optional(ResourceTypes),
    limit: S.optional(S.Number),
    nextToken: S.optional(S.String),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "GetDiscoveredResourceCountsRequest",
}) as any as S.Schema<GetDiscoveredResourceCountsRequest>;
export interface ResourceCount {
  resourceType?: ResourceType;
  count?: number;
}
export const ResourceCount = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    resourceType: S.optional(ResourceType),
    count: S.optional(S.Number),
  }),
).annotate({ identifier: "ResourceCount" }) as any as S.Schema<ResourceCount>;
export type ResourceCounts = ResourceCount[];
export const ResourceCounts = /*@__PURE__*/ S.Array(ResourceCount);
export interface GetDiscoveredResourceCountsResponse {
  totalDiscoveredResources?: number;
  resourceCounts?: ResourceCount[];
  nextToken?: string;
}
export const GetDiscoveredResourceCountsResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    totalDiscoveredResources: S.optional(S.Number),
    resourceCounts: S.optional(ResourceCounts),
    nextToken: S.optional(S.String),
  }).pipe(ns),
).annotate({
  identifier: "GetDiscoveredResourceCountsResponse",
}) as any as S.Schema<GetDiscoveredResourceCountsResponse>;
export type MemberAccountRuleStatus =
  | "CREATE_SUCCESSFUL"
  | "CREATE_IN_PROGRESS"
  | "CREATE_FAILED"
  | "DELETE_SUCCESSFUL"
  | "DELETE_FAILED"
  | "DELETE_IN_PROGRESS"
  | "UPDATE_SUCCESSFUL"
  | "UPDATE_IN_PROGRESS"
  | "UPDATE_FAILED"
  | (string & {});
export const MemberAccountRuleStatus = S.String;

export interface StatusDetailFilters {
  AccountId?: string;
  MemberAccountRuleStatus?: MemberAccountRuleStatus;
}
export const StatusDetailFilters = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    AccountId: S.optional(S.String),
    MemberAccountRuleStatus: S.optional(MemberAccountRuleStatus),
  }),
).annotate({
  identifier: "StatusDetailFilters",
}) as any as S.Schema<StatusDetailFilters>;
export interface GetOrganizationConfigRuleDetailedStatusRequest {
  OrganizationConfigRuleName: string;
  Filters?: StatusDetailFilters;
  Limit?: number;
  NextToken?: string;
}
export const GetOrganizationConfigRuleDetailedStatusRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      OrganizationConfigRuleName: S.String,
      Filters: S.optional(StatusDetailFilters),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "GetOrganizationConfigRuleDetailedStatusRequest",
  }) as any as S.Schema<GetOrganizationConfigRuleDetailedStatusRequest>;
export interface MemberAccountStatus {
  AccountId: string;
  ConfigRuleName: string;
  MemberAccountRuleStatus: MemberAccountRuleStatus;
  ErrorCode?: string;
  ErrorMessage?: string;
  LastUpdateTime?: Date;
}
export const MemberAccountStatus = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    AccountId: S.String,
    ConfigRuleName: S.String,
    MemberAccountRuleStatus: MemberAccountRuleStatus,
    ErrorCode: S.optional(S.String),
    ErrorMessage: S.optional(S.String),
    LastUpdateTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
  }),
).annotate({
  identifier: "MemberAccountStatus",
}) as any as S.Schema<MemberAccountStatus>;
export type OrganizationConfigRuleDetailedStatus = MemberAccountStatus[];
export const OrganizationConfigRuleDetailedStatus =
  /*@__PURE__*/ S.Array(MemberAccountStatus);
export interface GetOrganizationConfigRuleDetailedStatusResponse {
  OrganizationConfigRuleDetailedStatus?: MemberAccountStatus[];
  NextToken?: string;
}
export const GetOrganizationConfigRuleDetailedStatusResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      OrganizationConfigRuleDetailedStatus: S.optional(
        OrganizationConfigRuleDetailedStatus,
      ),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "GetOrganizationConfigRuleDetailedStatusResponse",
  }) as any as S.Schema<GetOrganizationConfigRuleDetailedStatusResponse>;
export type OrganizationResourceDetailedStatus =
  | "CREATE_SUCCESSFUL"
  | "CREATE_IN_PROGRESS"
  | "CREATE_FAILED"
  | "DELETE_SUCCESSFUL"
  | "DELETE_FAILED"
  | "DELETE_IN_PROGRESS"
  | "UPDATE_SUCCESSFUL"
  | "UPDATE_IN_PROGRESS"
  | "UPDATE_FAILED"
  | (string & {});
export const OrganizationResourceDetailedStatus = S.String;

export interface OrganizationResourceDetailedStatusFilters {
  AccountId?: string;
  Status?: OrganizationResourceDetailedStatus;
}
export const OrganizationResourceDetailedStatusFilters =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      AccountId: S.optional(S.String),
      Status: S.optional(OrganizationResourceDetailedStatus),
    }),
  ).annotate({
    identifier: "OrganizationResourceDetailedStatusFilters",
  }) as any as S.Schema<OrganizationResourceDetailedStatusFilters>;
export interface GetOrganizationConformancePackDetailedStatusRequest {
  OrganizationConformancePackName: string;
  Filters?: OrganizationResourceDetailedStatusFilters;
  Limit?: number;
  NextToken?: string;
}
export const GetOrganizationConformancePackDetailedStatusRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      OrganizationConformancePackName: S.String,
      Filters: S.optional(OrganizationResourceDetailedStatusFilters),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "GetOrganizationConformancePackDetailedStatusRequest",
  }) as any as S.Schema<GetOrganizationConformancePackDetailedStatusRequest>;
export interface OrganizationConformancePackDetailedStatus {
  AccountId: string;
  ConformancePackName: string;
  Status: OrganizationResourceDetailedStatus;
  ErrorCode?: string;
  ErrorMessage?: string;
  LastUpdateTime?: Date;
}
export const OrganizationConformancePackDetailedStatus =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      AccountId: S.String,
      ConformancePackName: S.String,
      Status: OrganizationResourceDetailedStatus,
      ErrorCode: S.optional(S.String),
      ErrorMessage: S.optional(S.String),
      LastUpdateTime: S.optional(
        S.Date.pipe(T.TimestampFormat("epoch-seconds")),
      ),
    }),
  ).annotate({
    identifier: "OrganizationConformancePackDetailedStatus",
  }) as any as S.Schema<OrganizationConformancePackDetailedStatus>;
export type OrganizationConformancePackDetailedStatuses =
  OrganizationConformancePackDetailedStatus[];
export const OrganizationConformancePackDetailedStatuses =
  /*@__PURE__*/ S.Array(OrganizationConformancePackDetailedStatus);
export interface GetOrganizationConformancePackDetailedStatusResponse {
  OrganizationConformancePackDetailedStatuses?: OrganizationConformancePackDetailedStatus[];
  NextToken?: string;
}
export const GetOrganizationConformancePackDetailedStatusResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      OrganizationConformancePackDetailedStatuses: S.optional(
        OrganizationConformancePackDetailedStatuses,
      ),
      NextToken: S.optional(S.String),
    }).pipe(ns),
  ).annotate({
    identifier: "GetOrganizationConformancePackDetailedStatusResponse",
  }) as any as S.Schema<GetOrganizationConformancePackDetailedStatusResponse>;
export interface GetOrganizationCustomRulePolicyRequest {
  OrganizationConfigRuleName: string;
}
export const GetOrganizationCustomRulePolicyRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({ OrganizationConfigRuleName: S.String }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "GetOrganizationCustomRulePolicyRequest",
}) as any as S.Schema<GetOrganizationCustomRulePolicyRequest>;
export interface GetOrganizationCustomRulePolicyResponse {
  PolicyText?: string;
}
export const GetOrganizationCustomRulePolicyResponse = /*@__PURE__*/ S.suspend(
  () => S.Struct({ PolicyText: S.optional(S.String) }).pipe(ns),
).annotate({
  identifier: "GetOrganizationCustomRulePolicyResponse",
}) as any as S.Schema<GetOrganizationCustomRulePolicyResponse>;
export type LaterTime = Date;
export type EarlierTime = Date;
export type ChronologicalOrder = "Reverse" | "Forward" | (string & {});
export const ChronologicalOrder = S.String;

export interface GetResourceConfigHistoryRequest {
  resourceType: ResourceType;
  resourceId: string;
  laterTime?: Date;
  earlierTime?: Date;
  chronologicalOrder?: ChronologicalOrder;
  limit?: number;
  nextToken?: string;
}
export const GetResourceConfigHistoryRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    resourceType: ResourceType,
    resourceId: S.String,
    laterTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
    earlierTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
    chronologicalOrder: S.optional(ChronologicalOrder),
    limit: S.optional(S.Number),
    nextToken: S.optional(S.String),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "GetResourceConfigHistoryRequest",
}) as any as S.Schema<GetResourceConfigHistoryRequest>;
export type ConfigurationItemList = ConfigurationItem[];
export const ConfigurationItemList = /*@__PURE__*/ S.Array(ConfigurationItem);
export interface GetResourceConfigHistoryResponse {
  configurationItems?: ConfigurationItem[];
  nextToken?: string;
}
export const GetResourceConfigHistoryResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    configurationItems: S.optional(ConfigurationItemList),
    nextToken: S.optional(S.String),
  }).pipe(ns),
).annotate({
  identifier: "GetResourceConfigHistoryResponse",
}) as any as S.Schema<GetResourceConfigHistoryResponse>;
export interface GetResourceEvaluationSummaryRequest {
  ResourceEvaluationId: string;
}
export const GetResourceEvaluationSummaryRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ResourceEvaluationId: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "GetResourceEvaluationSummaryRequest",
}) as any as S.Schema<GetResourceEvaluationSummaryRequest>;
export type ResourceEvaluationStatus =
  | "IN_PROGRESS"
  | "FAILED"
  | "SUCCEEDED"
  | (string & {});
export const ResourceEvaluationStatus = S.String;

export interface EvaluationStatus {
  Status: ResourceEvaluationStatus;
  FailureReason?: string;
}
export const EvaluationStatus = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    Status: ResourceEvaluationStatus,
    FailureReason: S.optional(S.String),
  }),
).annotate({
  identifier: "EvaluationStatus",
}) as any as S.Schema<EvaluationStatus>;
export type EvaluationContextIdentifier = string;
export interface EvaluationContext {
  EvaluationContextIdentifier?: string;
}
export const EvaluationContext = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ EvaluationContextIdentifier: S.optional(S.String) }),
).annotate({
  identifier: "EvaluationContext",
}) as any as S.Schema<EvaluationContext>;
export type ResourceConfiguration = string;
export type ResourceConfigurationSchemaType =
  | "CFN_RESOURCE_SCHEMA"
  | (string & {});
export const ResourceConfigurationSchemaType = S.String;

export interface ResourceDetails {
  ResourceId: string;
  ResourceType: string;
  ResourceConfiguration: string;
  ResourceConfigurationSchemaType?: ResourceConfigurationSchemaType;
}
export const ResourceDetails = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceId: S.String,
    ResourceType: S.String,
    ResourceConfiguration: S.String,
    ResourceConfigurationSchemaType: S.optional(
      ResourceConfigurationSchemaType,
    ),
  }),
).annotate({
  identifier: "ResourceDetails",
}) as any as S.Schema<ResourceDetails>;
export interface GetResourceEvaluationSummaryResponse {
  ResourceEvaluationId?: string;
  EvaluationMode?: EvaluationMode;
  EvaluationStatus?: EvaluationStatus;
  EvaluationStartTimestamp?: Date;
  Compliance?: ComplianceType;
  EvaluationContext?: EvaluationContext;
  ResourceDetails?: ResourceDetails;
}
export const GetResourceEvaluationSummaryResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ResourceEvaluationId: S.optional(S.String),
      EvaluationMode: S.optional(EvaluationMode),
      EvaluationStatus: S.optional(EvaluationStatus),
      EvaluationStartTimestamp: S.optional(
        S.Date.pipe(T.TimestampFormat("epoch-seconds")),
      ),
      Compliance: S.optional(ComplianceType),
      EvaluationContext: S.optional(EvaluationContext),
      ResourceDetails: S.optional(ResourceDetails),
    }).pipe(ns),
).annotate({
  identifier: "GetResourceEvaluationSummaryResponse",
}) as any as S.Schema<GetResourceEvaluationSummaryResponse>;
export interface GetStoredQueryRequest {
  QueryName: string;
}
export const GetStoredQueryRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ QueryName: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "GetStoredQueryRequest",
}) as any as S.Schema<GetStoredQueryRequest>;
export type QueryId = string;
export type QueryArn = string;
export type QueryDescription = string;
export type QueryExpression = string;
export interface StoredQuery {
  QueryId?: string;
  QueryArn?: string;
  QueryName: string;
  Description?: string;
  Expression?: string;
}
export const StoredQuery = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    QueryId: S.optional(S.String),
    QueryArn: S.optional(S.String),
    QueryName: S.String,
    Description: S.optional(S.String),
    Expression: S.optional(S.String),
  }),
).annotate({ identifier: "StoredQuery" }) as any as S.Schema<StoredQuery>;
export interface GetStoredQueryResponse {
  StoredQuery?: StoredQuery;
}
export const GetStoredQueryResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ StoredQuery: S.optional(StoredQuery) }).pipe(ns),
).annotate({
  identifier: "GetStoredQueryResponse",
}) as any as S.Schema<GetStoredQueryResponse>;
export interface ResourceFilters {
  AccountId?: string;
  ResourceId?: string;
  ResourceName?: string;
  Region?: string;
}
export const ResourceFilters = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    AccountId: S.optional(S.String),
    ResourceId: S.optional(S.String),
    ResourceName: S.optional(S.String),
    Region: S.optional(S.String),
  }),
).annotate({
  identifier: "ResourceFilters",
}) as any as S.Schema<ResourceFilters>;
export interface ListAggregateDiscoveredResourcesRequest {
  ConfigurationAggregatorName: string;
  ResourceType: ResourceType;
  Filters?: ResourceFilters;
  Limit?: number;
  NextToken?: string;
}
export const ListAggregateDiscoveredResourcesRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ConfigurationAggregatorName: S.String,
      ResourceType: ResourceType,
      Filters: S.optional(ResourceFilters),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "ListAggregateDiscoveredResourcesRequest",
}) as any as S.Schema<ListAggregateDiscoveredResourcesRequest>;
export type DiscoveredResourceIdentifierList = AggregateResourceIdentifier[];
export const DiscoveredResourceIdentifierList = /*@__PURE__*/ S.Array(
  AggregateResourceIdentifier,
);
export interface ListAggregateDiscoveredResourcesResponse {
  ResourceIdentifiers?: AggregateResourceIdentifier[];
  NextToken?: string;
}
export const ListAggregateDiscoveredResourcesResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      ResourceIdentifiers: S.optional(DiscoveredResourceIdentifierList),
      NextToken: S.optional(S.String),
    }).pipe(ns),
).annotate({
  identifier: "ListAggregateDiscoveredResourcesResponse",
}) as any as S.Schema<ListAggregateDiscoveredResourcesResponse>;
export type ConfigurationRecorderFilterName = "recordingScope" | (string & {});
export const ConfigurationRecorderFilterName = S.String;

export type ConfigurationRecorderFilterValue = string;
export type ConfigurationRecorderFilterValues = string[];
export const ConfigurationRecorderFilterValues = /*@__PURE__*/ S.Array(
  S.String,
);
export interface ConfigurationRecorderFilter {
  filterName?: ConfigurationRecorderFilterName;
  filterValue?: string[];
}
export const ConfigurationRecorderFilter = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    filterName: S.optional(ConfigurationRecorderFilterName),
    filterValue: S.optional(ConfigurationRecorderFilterValues),
  }),
).annotate({
  identifier: "ConfigurationRecorderFilter",
}) as any as S.Schema<ConfigurationRecorderFilter>;
export type ConfigurationRecorderFilterList = ConfigurationRecorderFilter[];
export const ConfigurationRecorderFilterList = /*@__PURE__*/ S.Array(
  ConfigurationRecorderFilter,
);
export type MaxResults = number;
export interface ListConfigurationRecordersRequest {
  Filters?: ConfigurationRecorderFilter[];
  MaxResults?: number;
  NextToken?: string;
}
export const ListConfigurationRecordersRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    Filters: S.optional(ConfigurationRecorderFilterList),
    MaxResults: S.optional(S.Number),
    NextToken: S.optional(S.String),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "ListConfigurationRecordersRequest",
}) as any as S.Schema<ListConfigurationRecordersRequest>;
export type Provider = "AZURE" | (string & {});
export const Provider = S.String;

export interface ConfigurationRecorderSummary {
  arn: string;
  name: string;
  servicePrincipal?: string;
  recordingScope: RecordingScope;
  provider?: Provider;
}
export const ConfigurationRecorderSummary = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    arn: S.String,
    name: S.String,
    servicePrincipal: S.optional(S.String),
    recordingScope: RecordingScope,
    provider: S.optional(Provider),
  }),
).annotate({
  identifier: "ConfigurationRecorderSummary",
}) as any as S.Schema<ConfigurationRecorderSummary>;
export type ConfigurationRecorderSummaries = ConfigurationRecorderSummary[];
export const ConfigurationRecorderSummaries = /*@__PURE__*/ S.Array(
  ConfigurationRecorderSummary,
);
export interface ListConfigurationRecordersResponse {
  ConfigurationRecorderSummaries: ConfigurationRecorderSummary[];
  NextToken?: string;
}
export const ListConfigurationRecordersResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigurationRecorderSummaries: ConfigurationRecorderSummaries,
    NextToken: S.optional(S.String),
  }).pipe(ns),
).annotate({
  identifier: "ListConfigurationRecordersResponse",
}) as any as S.Schema<ListConfigurationRecordersResponse>;
export type ConformancePackNameFilter = string[];
export const ConformancePackNameFilter = /*@__PURE__*/ S.Array(S.String);
export interface ConformancePackComplianceScoresFilters {
  ConformancePackNames: string[];
}
export const ConformancePackComplianceScoresFilters = /*@__PURE__*/ S.suspend(
  () => S.Struct({ ConformancePackNames: ConformancePackNameFilter }),
).annotate({
  identifier: "ConformancePackComplianceScoresFilters",
}) as any as S.Schema<ConformancePackComplianceScoresFilters>;
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export const SortOrder = S.String;

export type SortBy = "SCORE" | (string & {});
export const SortBy = S.String;

export interface ListConformancePackComplianceScoresRequest {
  Filters?: ConformancePackComplianceScoresFilters;
  SortOrder?: SortOrder;
  SortBy?: SortBy;
  Limit?: number;
  NextToken?: string;
}
export const ListConformancePackComplianceScoresRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      Filters: S.optional(ConformancePackComplianceScoresFilters),
      SortOrder: S.optional(SortOrder),
      SortBy: S.optional(SortBy),
      Limit: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "ListConformancePackComplianceScoresRequest",
  }) as any as S.Schema<ListConformancePackComplianceScoresRequest>;
export type ComplianceScore = string;
export type LastUpdatedTime = Date;
export interface ConformancePackComplianceScore {
  Score?: string;
  ConformancePackName?: string;
  LastUpdatedTime?: Date;
}
export const ConformancePackComplianceScore = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    Score: S.optional(S.String),
    ConformancePackName: S.optional(S.String),
    LastUpdatedTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
  }),
).annotate({
  identifier: "ConformancePackComplianceScore",
}) as any as S.Schema<ConformancePackComplianceScore>;
export type ConformancePackComplianceScores = ConformancePackComplianceScore[];
export const ConformancePackComplianceScores = /*@__PURE__*/ S.Array(
  ConformancePackComplianceScore,
);
export interface ListConformancePackComplianceScoresResponse {
  NextToken?: string;
  ConformancePackComplianceScores: ConformancePackComplianceScore[];
}
export const ListConformancePackComplianceScoresResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      NextToken: S.optional(S.String),
      ConformancePackComplianceScores: ConformancePackComplianceScores,
    }).pipe(ns),
  ).annotate({
    identifier: "ListConformancePackComplianceScoresResponse",
  }) as any as S.Schema<ListConformancePackComplianceScoresResponse>;
export type ListConnectorsMaxResults = number;
export type ConnectorFilterName = "provider" | (string & {});
export const ConnectorFilterName = S.String;

export type FilterValueList = string[];
export const FilterValueList = /*@__PURE__*/ S.Array(S.String);
export interface ConnectorFilter {
  filterName?: ConnectorFilterName;
  filterValues?: string[];
}
export const ConnectorFilter = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    filterName: S.optional(ConnectorFilterName),
    filterValues: S.optional(FilterValueList),
  }),
).annotate({
  identifier: "ConnectorFilter",
}) as any as S.Schema<ConnectorFilter>;
export type ConnectorFilterList = ConnectorFilter[];
export const ConnectorFilterList = /*@__PURE__*/ S.Array(ConnectorFilter);
export interface ListConnectorsRequest {
  MaxResults?: number;
  NextToken?: string;
  Filters?: ConnectorFilter[];
}
export const ListConnectorsRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    MaxResults: S.optional(S.Number),
    NextToken: S.optional(S.String),
    Filters: S.optional(ConnectorFilterList),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "ListConnectorsRequest",
}) as any as S.Schema<ListConnectorsRequest>;
export interface ConnectorSummary {
  arn: string;
  name: string;
  provider: Provider;
  tenantIdentifier: string;
  createdTime: Date;
}
export const ConnectorSummary = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    arn: S.String,
    name: S.String,
    provider: Provider,
    tenantIdentifier: S.String,
    createdTime: S.Date.pipe(T.TimestampFormat("epoch-seconds")),
  }),
).annotate({
  identifier: "ConnectorSummary",
}) as any as S.Schema<ConnectorSummary>;
export type ConnectorSummaries = ConnectorSummary[];
export const ConnectorSummaries = /*@__PURE__*/ S.Array(ConnectorSummary);
export interface ListConnectorsResponse {
  ConnectorSummaries: ConnectorSummary[];
  NextToken?: string;
}
export const ListConnectorsResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConnectorSummaries: ConnectorSummaries,
    NextToken: S.optional(S.String),
  }).pipe(ns),
).annotate({
  identifier: "ListConnectorsResponse",
}) as any as S.Schema<ListConnectorsResponse>;
export type ResourceIdList = string[];
export const ResourceIdList = /*@__PURE__*/ S.Array(S.String);
export interface ListDiscoveredResourcesRequest {
  resourceType: ResourceType;
  resourceIds?: string[];
  resourceName?: string;
  limit?: number;
  includeDeletedResources?: boolean;
  nextToken?: string;
}
export const ListDiscoveredResourcesRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    resourceType: ResourceType,
    resourceIds: S.optional(ResourceIdList),
    resourceName: S.optional(S.String),
    limit: S.optional(S.Number),
    includeDeletedResources: S.optional(S.Boolean),
    nextToken: S.optional(S.String),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "ListDiscoveredResourcesRequest",
}) as any as S.Schema<ListDiscoveredResourcesRequest>;
export type ResourceDeletionTime = Date;
export interface ResourceIdentifier {
  resourceType?: ResourceType;
  resourceId?: string;
  resourceName?: string;
  resourceDeletionTime?: Date;
}
export const ResourceIdentifier = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    resourceType: S.optional(ResourceType),
    resourceId: S.optional(S.String),
    resourceName: S.optional(S.String),
    resourceDeletionTime: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
  }),
).annotate({
  identifier: "ResourceIdentifier",
}) as any as S.Schema<ResourceIdentifier>;
export type ResourceIdentifierList = ResourceIdentifier[];
export const ResourceIdentifierList = /*@__PURE__*/ S.Array(ResourceIdentifier);
export interface ListDiscoveredResourcesResponse {
  resourceIdentifiers?: ResourceIdentifier[];
  nextToken?: string;
}
export const ListDiscoveredResourcesResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    resourceIdentifiers: S.optional(ResourceIdentifierList),
    nextToken: S.optional(S.String),
  }).pipe(ns),
).annotate({
  identifier: "ListDiscoveredResourcesResponse",
}) as any as S.Schema<ListDiscoveredResourcesResponse>;
export interface TimeWindow {
  StartTime?: Date;
  EndTime?: Date;
}
export const TimeWindow = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    StartTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
    EndTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
  }),
).annotate({ identifier: "TimeWindow" }) as any as S.Schema<TimeWindow>;
export interface ResourceEvaluationFilters {
  EvaluationMode?: EvaluationMode;
  TimeWindow?: TimeWindow;
  EvaluationContextIdentifier?: string;
}
export const ResourceEvaluationFilters = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    EvaluationMode: S.optional(EvaluationMode),
    TimeWindow: S.optional(TimeWindow),
    EvaluationContextIdentifier: S.optional(S.String),
  }),
).annotate({
  identifier: "ResourceEvaluationFilters",
}) as any as S.Schema<ResourceEvaluationFilters>;
export type ListResourceEvaluationsPageItemLimit = number;
export interface ListResourceEvaluationsRequest {
  Filters?: ResourceEvaluationFilters;
  Limit?: number;
  NextToken?: string;
}
export const ListResourceEvaluationsRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    Filters: S.optional(ResourceEvaluationFilters),
    Limit: S.optional(S.Number),
    NextToken: S.optional(S.String),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "ListResourceEvaluationsRequest",
}) as any as S.Schema<ListResourceEvaluationsRequest>;
export interface ResourceEvaluation {
  ResourceEvaluationId?: string;
  EvaluationMode?: EvaluationMode;
  EvaluationStartTimestamp?: Date;
}
export const ResourceEvaluation = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceEvaluationId: S.optional(S.String),
    EvaluationMode: S.optional(EvaluationMode),
    EvaluationStartTimestamp: S.optional(
      S.Date.pipe(T.TimestampFormat("epoch-seconds")),
    ),
  }),
).annotate({
  identifier: "ResourceEvaluation",
}) as any as S.Schema<ResourceEvaluation>;
export type ResourceEvaluations = ResourceEvaluation[];
export const ResourceEvaluations = /*@__PURE__*/ S.Array(ResourceEvaluation);
export interface ListResourceEvaluationsResponse {
  ResourceEvaluations?: ResourceEvaluation[];
  NextToken?: string;
}
export const ListResourceEvaluationsResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceEvaluations: S.optional(ResourceEvaluations),
    NextToken: S.optional(S.String),
  }).pipe(ns),
).annotate({
  identifier: "ListResourceEvaluationsResponse",
}) as any as S.Schema<ListResourceEvaluationsResponse>;
export interface ListStoredQueriesRequest {
  NextToken?: string;
  MaxResults?: number;
}
export const ListStoredQueriesRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    NextToken: S.optional(S.String),
    MaxResults: S.optional(S.Number),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "ListStoredQueriesRequest",
}) as any as S.Schema<ListStoredQueriesRequest>;
export interface StoredQueryMetadata {
  QueryId: string;
  QueryArn: string;
  QueryName: string;
  Description?: string;
}
export const StoredQueryMetadata = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    QueryId: S.String,
    QueryArn: S.String,
    QueryName: S.String,
    Description: S.optional(S.String),
  }),
).annotate({
  identifier: "StoredQueryMetadata",
}) as any as S.Schema<StoredQueryMetadata>;
export type StoredQueryMetadataList = StoredQueryMetadata[];
export const StoredQueryMetadataList =
  /*@__PURE__*/ S.Array(StoredQueryMetadata);
export interface ListStoredQueriesResponse {
  StoredQueryMetadata?: StoredQueryMetadata[];
  NextToken?: string;
}
export const ListStoredQueriesResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    StoredQueryMetadata: S.optional(StoredQueryMetadataList),
    NextToken: S.optional(S.String),
  }).pipe(ns),
).annotate({
  identifier: "ListStoredQueriesResponse",
}) as any as S.Schema<ListStoredQueriesResponse>;
export interface ListTagsForResourceRequest {
  ResourceArn: string;
  Limit?: number;
  NextToken?: string;
}
export const ListTagsForResourceRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceArn: S.String,
    Limit: S.optional(S.Number),
    NextToken: S.optional(S.String),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "ListTagsForResourceRequest",
}) as any as S.Schema<ListTagsForResourceRequest>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
  Key?: string;
  Value?: string;
}
export const Tag = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ Key: S.optional(S.String), Value: S.optional(S.String) }),
).annotate({ identifier: "Tag" }) as any as S.Schema<Tag>;
export type TagList = Tag[];
export const TagList = /*@__PURE__*/ S.Array(Tag);
export interface ListTagsForResourceResponse {
  Tags?: Tag[];
  NextToken?: string;
}
export const ListTagsForResourceResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ Tags: S.optional(TagList), NextToken: S.optional(S.String) }).pipe(
    ns,
  ),
).annotate({
  identifier: "ListTagsForResourceResponse",
}) as any as S.Schema<ListTagsForResourceResponse>;
export type TagsList = Tag[];
export const TagsList = /*@__PURE__*/ S.Array(Tag);
export interface PutAggregationAuthorizationRequest {
  AuthorizedAccountId: string;
  AuthorizedAwsRegion: string;
  Tags?: Tag[];
}
export const PutAggregationAuthorizationRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    AuthorizedAccountId: S.String,
    AuthorizedAwsRegion: S.String,
    Tags: S.optional(TagsList),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutAggregationAuthorizationRequest",
}) as any as S.Schema<PutAggregationAuthorizationRequest>;
export interface PutAggregationAuthorizationResponse {
  AggregationAuthorization?: AggregationAuthorization;
}
export const PutAggregationAuthorizationResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    AggregationAuthorization: S.optional(AggregationAuthorization),
  }).pipe(ns),
).annotate({
  identifier: "PutAggregationAuthorizationResponse",
}) as any as S.Schema<PutAggregationAuthorizationResponse>;
export interface PutConfigRuleRequest {
  ConfigRule: ConfigRule;
  Tags?: Tag[];
}
export const PutConfigRuleRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConfigRule: ConfigRule, Tags: S.optional(TagsList) }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutConfigRuleRequest",
}) as any as S.Schema<PutConfigRuleRequest>;
export interface PutConfigRuleResponse {}
export const PutConfigRuleResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "PutConfigRuleResponse",
}) as any as S.Schema<PutConfigRuleResponse>;
export interface PutConfigurationAggregatorRequest {
  ConfigurationAggregatorName: string;
  AccountAggregationSources?: AccountAggregationSource[];
  OrganizationAggregationSource?: OrganizationAggregationSource;
  Tags?: Tag[];
  AggregatorFilters?: AggregatorFilters;
}
export const PutConfigurationAggregatorRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigurationAggregatorName: S.String,
    AccountAggregationSources: S.optional(AccountAggregationSourceList),
    OrganizationAggregationSource: S.optional(OrganizationAggregationSource),
    Tags: S.optional(TagsList),
    AggregatorFilters: S.optional(AggregatorFilters),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutConfigurationAggregatorRequest",
}) as any as S.Schema<PutConfigurationAggregatorRequest>;
export interface PutConfigurationAggregatorResponse {
  ConfigurationAggregator?: ConfigurationAggregator;
}
export const PutConfigurationAggregatorResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigurationAggregator: S.optional(ConfigurationAggregator),
  }).pipe(ns),
).annotate({
  identifier: "PutConfigurationAggregatorResponse",
}) as any as S.Schema<PutConfigurationAggregatorResponse>;
export interface PutConfigurationRecorderRequest {
  ConfigurationRecorder: ConfigurationRecorder;
  Tags?: Tag[];
}
export const PutConfigurationRecorderRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigurationRecorder: ConfigurationRecorder,
    Tags: S.optional(TagsList),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutConfigurationRecorderRequest",
}) as any as S.Schema<PutConfigurationRecorderRequest>;
export interface PutConfigurationRecorderResponse {}
export const PutConfigurationRecorderResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "PutConfigurationRecorderResponse",
}) as any as S.Schema<PutConfigurationRecorderResponse>;
export type TemplateS3Uri = string;
export type TemplateBody = string;
export interface PutConformancePackRequest {
  ConformancePackName: string;
  TemplateS3Uri?: string;
  TemplateBody?: string;
  DeliveryS3Bucket?: string;
  DeliveryS3KeyPrefix?: string;
  ConformancePackInputParameters?: ConformancePackInputParameter[];
  TemplateSSMDocumentDetails?: TemplateSSMDocumentDetails;
  Tags?: Tag[];
}
export const PutConformancePackRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConformancePackName: S.String,
    TemplateS3Uri: S.optional(S.String),
    TemplateBody: S.optional(S.String),
    DeliveryS3Bucket: S.optional(S.String),
    DeliveryS3KeyPrefix: S.optional(S.String),
    ConformancePackInputParameters: S.optional(ConformancePackInputParameters),
    TemplateSSMDocumentDetails: S.optional(TemplateSSMDocumentDetails),
    Tags: S.optional(TagsList),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutConformancePackRequest",
}) as any as S.Schema<PutConformancePackRequest>;
export interface PutConformancePackResponse {
  ConformancePackArn?: string;
}
export const PutConformancePackResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConformancePackArn: S.optional(S.String) }).pipe(ns),
).annotate({
  identifier: "PutConformancePackResponse",
}) as any as S.Schema<PutConformancePackResponse>;
export interface PutConnectorRequest {
  ConnectorConfiguration: ConnectorConfiguration;
  Tags?: Tag[];
}
export const PutConnectorRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConnectorConfiguration: ConnectorConfiguration,
    Tags: S.optional(TagsList),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutConnectorRequest",
}) as any as S.Schema<PutConnectorRequest>;
export interface PutConnectorResponse {
  Arn: string;
}
export const PutConnectorResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ Arn: S.String }).pipe(ns),
).annotate({
  identifier: "PutConnectorResponse",
}) as any as S.Schema<PutConnectorResponse>;
export interface PutDeliveryChannelRequest {
  DeliveryChannel: DeliveryChannel;
}
export const PutDeliveryChannelRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ DeliveryChannel: DeliveryChannel }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutDeliveryChannelRequest",
}) as any as S.Schema<PutDeliveryChannelRequest>;
export interface PutDeliveryChannelResponse {}
export const PutDeliveryChannelResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "PutDeliveryChannelResponse",
}) as any as S.Schema<PutDeliveryChannelResponse>;
export type OrderingTimestamp = Date;
export interface Evaluation {
  ComplianceResourceType: string;
  ComplianceResourceId: string;
  ComplianceType: ComplianceType;
  Annotation?: string;
  OrderingTimestamp: Date;
}
export const Evaluation = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ComplianceResourceType: S.String,
    ComplianceResourceId: S.String,
    ComplianceType: ComplianceType,
    Annotation: S.optional(S.String),
    OrderingTimestamp: S.Date.pipe(T.TimestampFormat("epoch-seconds")),
  }),
).annotate({ identifier: "Evaluation" }) as any as S.Schema<Evaluation>;
export type Evaluations = Evaluation[];
export const Evaluations = /*@__PURE__*/ S.Array(Evaluation);
export interface PutEvaluationsRequest {
  Evaluations?: Evaluation[];
  ResultToken: string;
  TestMode?: boolean;
}
export const PutEvaluationsRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    Evaluations: S.optional(Evaluations),
    ResultToken: S.String,
    TestMode: S.optional(S.Boolean),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutEvaluationsRequest",
}) as any as S.Schema<PutEvaluationsRequest>;
export interface PutEvaluationsResponse {
  FailedEvaluations?: Evaluation[];
}
export const PutEvaluationsResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ FailedEvaluations: S.optional(Evaluations) }).pipe(ns),
).annotate({
  identifier: "PutEvaluationsResponse",
}) as any as S.Schema<PutEvaluationsResponse>;
export interface ExternalEvaluation {
  ComplianceResourceType: string;
  ComplianceResourceId: string;
  ComplianceType: ComplianceType;
  Annotation?: string;
  OrderingTimestamp: Date;
}
export const ExternalEvaluation = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ComplianceResourceType: S.String,
    ComplianceResourceId: S.String,
    ComplianceType: ComplianceType,
    Annotation: S.optional(S.String),
    OrderingTimestamp: S.Date.pipe(T.TimestampFormat("epoch-seconds")),
  }),
).annotate({
  identifier: "ExternalEvaluation",
}) as any as S.Schema<ExternalEvaluation>;
export interface PutExternalEvaluationRequest {
  ConfigRuleName: string;
  ExternalEvaluation: ExternalEvaluation;
}
export const PutExternalEvaluationRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleName: S.String,
    ExternalEvaluation: ExternalEvaluation,
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutExternalEvaluationRequest",
}) as any as S.Schema<PutExternalEvaluationRequest>;
export interface PutExternalEvaluationResponse {}
export const PutExternalEvaluationResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "PutExternalEvaluationResponse",
}) as any as S.Schema<PutExternalEvaluationResponse>;
export interface OrganizationCustomPolicyRuleMetadata {
  Description?: string;
  OrganizationConfigRuleTriggerTypes?: OrganizationConfigRuleTriggerTypeNoSN[];
  InputParameters?: string;
  MaximumExecutionFrequency?: MaximumExecutionFrequency;
  ResourceTypesScope?: string[];
  ResourceIdScope?: string;
  TagKeyScope?: string;
  TagValueScope?: string;
  PolicyRuntime: string;
  PolicyText: string;
  DebugLogDeliveryAccounts?: string[];
}
export const OrganizationCustomPolicyRuleMetadata = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      Description: S.optional(S.String),
      OrganizationConfigRuleTriggerTypes: S.optional(
        OrganizationConfigRuleTriggerTypeNoSNs,
      ),
      InputParameters: S.optional(S.String),
      MaximumExecutionFrequency: S.optional(MaximumExecutionFrequency),
      ResourceTypesScope: S.optional(ResourceTypesScope),
      ResourceIdScope: S.optional(S.String),
      TagKeyScope: S.optional(S.String),
      TagValueScope: S.optional(S.String),
      PolicyRuntime: S.String,
      PolicyText: S.String,
      DebugLogDeliveryAccounts: S.optional(DebugLogDeliveryAccounts),
    }),
).annotate({
  identifier: "OrganizationCustomPolicyRuleMetadata",
}) as any as S.Schema<OrganizationCustomPolicyRuleMetadata>;
export interface PutOrganizationConfigRuleRequest {
  OrganizationConfigRuleName: string;
  OrganizationManagedRuleMetadata?: OrganizationManagedRuleMetadata;
  OrganizationCustomRuleMetadata?: OrganizationCustomRuleMetadata;
  ExcludedAccounts?: string[];
  OrganizationCustomPolicyRuleMetadata?: OrganizationCustomPolicyRuleMetadata;
  Tags?: Tag[];
}
export const PutOrganizationConfigRuleRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    OrganizationConfigRuleName: S.String,
    OrganizationManagedRuleMetadata: S.optional(
      OrganizationManagedRuleMetadata,
    ),
    OrganizationCustomRuleMetadata: S.optional(OrganizationCustomRuleMetadata),
    ExcludedAccounts: S.optional(ExcludedAccounts),
    OrganizationCustomPolicyRuleMetadata: S.optional(
      OrganizationCustomPolicyRuleMetadata,
    ),
    Tags: S.optional(TagsList),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutOrganizationConfigRuleRequest",
}) as any as S.Schema<PutOrganizationConfigRuleRequest>;
export interface PutOrganizationConfigRuleResponse {
  OrganizationConfigRuleArn?: string;
}
export const PutOrganizationConfigRuleResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ OrganizationConfigRuleArn: S.optional(S.String) }).pipe(ns),
).annotate({
  identifier: "PutOrganizationConfigRuleResponse",
}) as any as S.Schema<PutOrganizationConfigRuleResponse>;
export interface PutOrganizationConformancePackRequest {
  OrganizationConformancePackName: string;
  TemplateS3Uri?: string;
  TemplateBody?: string;
  DeliveryS3Bucket?: string;
  DeliveryS3KeyPrefix?: string;
  ConformancePackInputParameters?: ConformancePackInputParameter[];
  ExcludedAccounts?: string[];
  Tags?: Tag[];
}
export const PutOrganizationConformancePackRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      OrganizationConformancePackName: S.String,
      TemplateS3Uri: S.optional(S.String),
      TemplateBody: S.optional(S.String),
      DeliveryS3Bucket: S.optional(S.String),
      DeliveryS3KeyPrefix: S.optional(S.String),
      ConformancePackInputParameters: S.optional(
        ConformancePackInputParameters,
      ),
      ExcludedAccounts: S.optional(ExcludedAccounts),
      Tags: S.optional(TagsList),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "PutOrganizationConformancePackRequest",
}) as any as S.Schema<PutOrganizationConformancePackRequest>;
export interface PutOrganizationConformancePackResponse {
  OrganizationConformancePackArn?: string;
}
export const PutOrganizationConformancePackResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({ OrganizationConformancePackArn: S.optional(S.String) }).pipe(ns),
).annotate({
  identifier: "PutOrganizationConformancePackResponse",
}) as any as S.Schema<PutOrganizationConformancePackResponse>;
export interface PutRemediationConfigurationsRequest {
  RemediationConfigurations: RemediationConfiguration[];
}
export const PutRemediationConfigurationsRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ RemediationConfigurations: RemediationConfigurations }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutRemediationConfigurationsRequest",
}) as any as S.Schema<PutRemediationConfigurationsRequest>;
export interface FailedRemediationBatch {
  FailureMessage?: string;
  FailedItems?: RemediationConfiguration[];
}
export const FailedRemediationBatch = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    FailureMessage: S.optional(S.String),
    FailedItems: S.optional(RemediationConfigurations),
  }),
).annotate({
  identifier: "FailedRemediationBatch",
}) as any as S.Schema<FailedRemediationBatch>;
export type FailedRemediationBatches = FailedRemediationBatch[];
export const FailedRemediationBatches = /*@__PURE__*/ S.Array(
  FailedRemediationBatch,
);
export interface PutRemediationConfigurationsResponse {
  FailedBatches?: FailedRemediationBatch[];
}
export const PutRemediationConfigurationsResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({ FailedBatches: S.optional(FailedRemediationBatches) }).pipe(ns),
).annotate({
  identifier: "PutRemediationConfigurationsResponse",
}) as any as S.Schema<PutRemediationConfigurationsResponse>;
export interface PutRemediationExceptionsRequest {
  ConfigRuleName: string;
  ResourceKeys: RemediationExceptionResourceKey[];
  Message?: string;
  ExpirationTime?: Date;
}
export const PutRemediationExceptionsRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ConfigRuleName: S.String,
    ResourceKeys: RemediationExceptionResourceKeys,
    Message: S.optional(S.String),
    ExpirationTime: S.optional(S.Date.pipe(T.TimestampFormat("epoch-seconds"))),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutRemediationExceptionsRequest",
}) as any as S.Schema<PutRemediationExceptionsRequest>;
export interface FailedRemediationExceptionBatch {
  FailureMessage?: string;
  FailedItems?: RemediationException[];
}
export const FailedRemediationExceptionBatch = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    FailureMessage: S.optional(S.String),
    FailedItems: S.optional(RemediationExceptions),
  }),
).annotate({
  identifier: "FailedRemediationExceptionBatch",
}) as any as S.Schema<FailedRemediationExceptionBatch>;
export type FailedRemediationExceptionBatches =
  FailedRemediationExceptionBatch[];
export const FailedRemediationExceptionBatches = /*@__PURE__*/ S.Array(
  FailedRemediationExceptionBatch,
);
export interface PutRemediationExceptionsResponse {
  FailedBatches?: FailedRemediationExceptionBatch[];
}
export const PutRemediationExceptionsResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    FailedBatches: S.optional(FailedRemediationExceptionBatches),
  }).pipe(ns),
).annotate({
  identifier: "PutRemediationExceptionsResponse",
}) as any as S.Schema<PutRemediationExceptionsResponse>;
export type SchemaVersionId = string;
export interface PutResourceConfigRequest {
  ResourceType: string;
  SchemaVersionId: string;
  ResourceId: string;
  ResourceName?: string;
  Configuration: string;
  Tags?: { [key: string]: string | undefined };
}
export const PutResourceConfigRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceType: S.String,
    SchemaVersionId: S.String,
    ResourceId: S.String,
    ResourceName: S.optional(S.String),
    Configuration: S.String,
    Tags: S.optional(Tags),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutResourceConfigRequest",
}) as any as S.Schema<PutResourceConfigRequest>;
export interface PutResourceConfigResponse {}
export const PutResourceConfigResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "PutResourceConfigResponse",
}) as any as S.Schema<PutResourceConfigResponse>;
export interface PutRetentionConfigurationRequest {
  RetentionPeriodInDays: number;
}
export const PutRetentionConfigurationRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ RetentionPeriodInDays: S.Number }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutRetentionConfigurationRequest",
}) as any as S.Schema<PutRetentionConfigurationRequest>;
export interface PutRetentionConfigurationResponse {
  RetentionConfiguration?: RetentionConfiguration;
}
export const PutRetentionConfigurationResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ RetentionConfiguration: S.optional(RetentionConfiguration) }).pipe(
    ns,
  ),
).annotate({
  identifier: "PutRetentionConfigurationResponse",
}) as any as S.Schema<PutRetentionConfigurationResponse>;
export interface PutServiceLinkedConfigurationRecorderRequest {
  ServicePrincipal: string;
  Tags?: Tag[];
}
export const PutServiceLinkedConfigurationRecorderRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({ ServicePrincipal: S.String, Tags: S.optional(TagsList) }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "PutServiceLinkedConfigurationRecorderRequest",
  }) as any as S.Schema<PutServiceLinkedConfigurationRecorderRequest>;
export interface PutServiceLinkedConfigurationRecorderResponse {
  Arn?: string;
  Name?: string;
}
export const PutServiceLinkedConfigurationRecorderResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({ Arn: S.optional(S.String), Name: S.optional(S.String) }).pipe(
      ns,
    ),
  ).annotate({
    identifier: "PutServiceLinkedConfigurationRecorderResponse",
  }) as any as S.Schema<PutServiceLinkedConfigurationRecorderResponse>;
export interface PutStoredQueryRequest {
  StoredQuery: StoredQuery;
  Tags?: Tag[];
}
export const PutStoredQueryRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ StoredQuery: StoredQuery, Tags: S.optional(TagsList) }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "PutStoredQueryRequest",
}) as any as S.Schema<PutStoredQueryRequest>;
export interface PutStoredQueryResponse {
  QueryArn?: string;
}
export const PutStoredQueryResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ QueryArn: S.optional(S.String) }).pipe(ns),
).annotate({
  identifier: "PutStoredQueryResponse",
}) as any as S.Schema<PutStoredQueryResponse>;
export interface PutThirdPartyServiceLinkedConfigurationRecorderRequest {
  ServicePrincipal: string;
  ConnectorArn: string;
  ScopeConfiguration: ScopeConfiguration;
  Tags?: Tag[];
}
export const PutThirdPartyServiceLinkedConfigurationRecorderRequest =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({
      ServicePrincipal: S.String,
      ConnectorArn: S.String,
      ScopeConfiguration: ScopeConfiguration,
      Tags: S.optional(TagsList),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
  ).annotate({
    identifier: "PutThirdPartyServiceLinkedConfigurationRecorderRequest",
  }) as any as S.Schema<PutThirdPartyServiceLinkedConfigurationRecorderRequest>;
export interface PutThirdPartyServiceLinkedConfigurationRecorderResponse {
  Arn: string;
  Name: string;
}
export const PutThirdPartyServiceLinkedConfigurationRecorderResponse =
  /*@__PURE__*/ S.suspend(() =>
    S.Struct({ Arn: S.String, Name: S.String }).pipe(ns),
  ).annotate({
    identifier: "PutThirdPartyServiceLinkedConfigurationRecorderResponse",
  }) as any as S.Schema<PutThirdPartyServiceLinkedConfigurationRecorderResponse>;
export type Expression = string;
export interface SelectAggregateResourceConfigRequest {
  Expression: string;
  ConfigurationAggregatorName: string;
  Limit?: number;
  MaxResults?: number;
  NextToken?: string;
}
export const SelectAggregateResourceConfigRequest = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      Expression: S.String,
      ConfigurationAggregatorName: S.String,
      Limit: S.optional(S.Number),
      MaxResults: S.optional(S.Number),
      NextToken: S.optional(S.String),
    }).pipe(
      T.all(
        ns,
        T.Http({ method: "POST", uri: "/" }),
        svc,
        auth,
        proto,
        ver,
        rules,
      ),
    ),
).annotate({
  identifier: "SelectAggregateResourceConfigRequest",
}) as any as S.Schema<SelectAggregateResourceConfigRequest>;
export type Results = string[];
export const Results = /*@__PURE__*/ S.Array(S.String);
export type FieldName = string;
export interface FieldInfo {
  Name?: string;
}
export const FieldInfo = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ Name: S.optional(S.String) }),
).annotate({ identifier: "FieldInfo" }) as any as S.Schema<FieldInfo>;
export type FieldInfoList = FieldInfo[];
export const FieldInfoList = /*@__PURE__*/ S.Array(FieldInfo);
export interface QueryInfo {
  SelectFields?: FieldInfo[];
}
export const QueryInfo = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ SelectFields: S.optional(FieldInfoList) }),
).annotate({ identifier: "QueryInfo" }) as any as S.Schema<QueryInfo>;
export interface SelectAggregateResourceConfigResponse {
  Results?: string[];
  QueryInfo?: QueryInfo;
  NextToken?: string;
}
export const SelectAggregateResourceConfigResponse = /*@__PURE__*/ S.suspend(
  () =>
    S.Struct({
      Results: S.optional(Results),
      QueryInfo: S.optional(QueryInfo),
      NextToken: S.optional(S.String),
    }).pipe(ns),
).annotate({
  identifier: "SelectAggregateResourceConfigResponse",
}) as any as S.Schema<SelectAggregateResourceConfigResponse>;
export interface SelectResourceConfigRequest {
  Expression: string;
  Limit?: number;
  NextToken?: string;
}
export const SelectResourceConfigRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    Expression: S.String,
    Limit: S.optional(S.Number),
    NextToken: S.optional(S.String),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "SelectResourceConfigRequest",
}) as any as S.Schema<SelectResourceConfigRequest>;
export interface SelectResourceConfigResponse {
  Results?: string[];
  QueryInfo?: QueryInfo;
  NextToken?: string;
}
export const SelectResourceConfigResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    Results: S.optional(Results),
    QueryInfo: S.optional(QueryInfo),
    NextToken: S.optional(S.String),
  }).pipe(ns),
).annotate({
  identifier: "SelectResourceConfigResponse",
}) as any as S.Schema<SelectResourceConfigResponse>;
export type ReevaluateConfigRuleNames = string[];
export const ReevaluateConfigRuleNames = /*@__PURE__*/ S.Array(S.String);
export interface StartConfigRulesEvaluationRequest {
  ConfigRuleNames?: string[];
}
export const StartConfigRulesEvaluationRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConfigRuleNames: S.optional(ReevaluateConfigRuleNames) }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "StartConfigRulesEvaluationRequest",
}) as any as S.Schema<StartConfigRulesEvaluationRequest>;
export interface StartConfigRulesEvaluationResponse {}
export const StartConfigRulesEvaluationResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "StartConfigRulesEvaluationResponse",
}) as any as S.Schema<StartConfigRulesEvaluationResponse>;
export interface StartConfigurationRecorderRequest {
  ConfigurationRecorderName: string;
}
export const StartConfigurationRecorderRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConfigurationRecorderName: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "StartConfigurationRecorderRequest",
}) as any as S.Schema<StartConfigurationRecorderRequest>;
export interface StartConfigurationRecorderResponse {}
export const StartConfigurationRecorderResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "StartConfigurationRecorderResponse",
}) as any as S.Schema<StartConfigurationRecorderResponse>;
export interface StartRemediationExecutionRequest {
  ConfigRuleName: string;
  ResourceKeys: ResourceKey[];
}
export const StartRemediationExecutionRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConfigRuleName: S.String, ResourceKeys: ResourceKeys }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "StartRemediationExecutionRequest",
}) as any as S.Schema<StartRemediationExecutionRequest>;
export interface StartRemediationExecutionResponse {
  FailureMessage?: string;
  FailedItems?: ResourceKey[];
}
export const StartRemediationExecutionResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    FailureMessage: S.optional(S.String),
    FailedItems: S.optional(ResourceKeys),
  }).pipe(ns),
).annotate({
  identifier: "StartRemediationExecutionResponse",
}) as any as S.Schema<StartRemediationExecutionResponse>;
export type EvaluationTimeout = number;
export type ClientToken = string;
export interface StartResourceEvaluationRequest {
  ResourceDetails: ResourceDetails;
  EvaluationContext?: EvaluationContext;
  EvaluationMode: EvaluationMode;
  EvaluationTimeout?: number;
  ClientToken?: string;
}
export const StartResourceEvaluationRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({
    ResourceDetails: ResourceDetails,
    EvaluationContext: S.optional(EvaluationContext),
    EvaluationMode: EvaluationMode,
    EvaluationTimeout: S.optional(S.Number),
    ClientToken: S.optional(S.String),
  }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "StartResourceEvaluationRequest",
}) as any as S.Schema<StartResourceEvaluationRequest>;
export interface StartResourceEvaluationResponse {
  ResourceEvaluationId?: string;
}
export const StartResourceEvaluationResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ResourceEvaluationId: S.optional(S.String) }).pipe(ns),
).annotate({
  identifier: "StartResourceEvaluationResponse",
}) as any as S.Schema<StartResourceEvaluationResponse>;
export interface StopConfigurationRecorderRequest {
  ConfigurationRecorderName: string;
}
export const StopConfigurationRecorderRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ConfigurationRecorderName: S.String }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "StopConfigurationRecorderRequest",
}) as any as S.Schema<StopConfigurationRecorderRequest>;
export interface StopConfigurationRecorderResponse {}
export const StopConfigurationRecorderResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "StopConfigurationRecorderResponse",
}) as any as S.Schema<StopConfigurationRecorderResponse>;
export interface TagResourceRequest {
  ResourceArn: string;
  Tags: Tag[];
}
export const TagResourceRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ResourceArn: S.String, Tags: TagList }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "TagResourceRequest",
}) as any as S.Schema<TagResourceRequest>;
export interface TagResourceResponse {}
export const TagResourceResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "TagResourceResponse",
}) as any as S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export const TagKeyList = /*@__PURE__*/ S.Array(S.String);
export interface UntagResourceRequest {
  ResourceArn: string;
  TagKeys: string[];
}
export const UntagResourceRequest = /*@__PURE__*/ S.suspend(() =>
  S.Struct({ ResourceArn: S.String, TagKeys: TagKeyList }).pipe(
    T.all(
      ns,
      T.Http({ method: "POST", uri: "/" }),
      svc,
      auth,
      proto,
      ver,
      rules,
    ),
  ),
).annotate({
  identifier: "UntagResourceRequest",
}) as any as S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {}
export const UntagResourceResponse = /*@__PURE__*/ S.suspend(() =>
  S.Struct({}).pipe(ns),
).annotate({
  identifier: "UntagResourceResponse",
}) as any as S.Schema<UntagResourceResponse>;
export type ErrorMessage = string;
export type AssociateResourceTypesError =
  | ConflictException
  | NoSuchConfigurationRecorderException
  | ValidationException
  | CommonErrors;
/**
 * Adds all resource types specified in the `ResourceTypes` list to the RecordingGroup of specified configuration recorder and includes those resource types when recording.
 *
 * For this operation, the specified configuration recorder must use a RecordingStrategy that is either `INCLUSION_BY_RESOURCE_TYPES` or `EXCLUSION_BY_RESOURCE_TYPES`.
 */
export const associateResourceTypes: API.OperationMethod<
  AssociateResourceTypesRequest,
  AssociateResourceTypesResponse,
  AssociateResourceTypesError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: AssociateResourceTypesRequest,
  output: AssociateResourceTypesResponse,
  errors: [
    ConflictException,
    NoSuchConfigurationRecorderException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "AssociateResourceTypes",
}));

export type BatchGetAggregateResourceConfigError =
  | NoSuchConfigurationAggregatorException
  | ValidationException
  | CommonErrors;
/**
 * Returns the current configuration items for resources that are present in your Config aggregator. The operation also returns a list of resources that are not processed in the current request.
 * If there are no unprocessed resources, the operation returns an empty `unprocessedResourceIdentifiers` list.
 *
 * - The API does not return results for deleted resources.
 *
 * - The API does not return tags and relationships.
 */
export const batchGetAggregateResourceConfig: API.OperationMethod<
  BatchGetAggregateResourceConfigRequest,
  BatchGetAggregateResourceConfigResponse,
  BatchGetAggregateResourceConfigError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: BatchGetAggregateResourceConfigRequest,
  output: BatchGetAggregateResourceConfigResponse,
  errors: [NoSuchConfigurationAggregatorException, ValidationException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "BatchGetAggregateResourceConfig",
}));

export type BatchGetResourceConfigError =
  | NoAvailableConfigurationRecorderException
  | ValidationException
  | CommonErrors;
/**
 * Returns the `BaseConfigurationItem` for one or more requested resources.
 * The operation also returns a list of resources that are
 * not processed in the current request. If there are no unprocessed
 * resources, the operation returns an empty unprocessedResourceKeys
 * list.
 *
 * - The API does not return results for deleted
 * resources.
 *
 * - The API does not return any tags for the requested
 * resources. This information is filtered out of the
 * supplementaryConfiguration section of the API
 * response.
 */
export const batchGetResourceConfig: API.OperationMethod<
  BatchGetResourceConfigRequest,
  BatchGetResourceConfigResponse,
  BatchGetResourceConfigError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: BatchGetResourceConfigRequest,
  output: BatchGetResourceConfigResponse,
  errors: [NoAvailableConfigurationRecorderException, ValidationException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "BatchGetResourceConfig",
}));

export type DeleteAggregationAuthorizationError =
  | InvalidParameterValueException
  | CommonErrors;
/**
 * Deletes the authorization granted to the specified
 * configuration aggregator account in a specified region.
 */
export const deleteAggregationAuthorization: API.OperationMethod<
  DeleteAggregationAuthorizationRequest,
  DeleteAggregationAuthorizationResponse,
  DeleteAggregationAuthorizationError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteAggregationAuthorizationRequest,
  output: DeleteAggregationAuthorizationResponse,
  errors: [InvalidParameterValueException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteAggregationAuthorization",
}));

export type DeleteConfigRuleError =
  | NoSuchConfigRuleException
  | ResourceInUseException
  | CommonErrors;
/**
 * Deletes the specified Config rule and all of its evaluation
 * results.
 *
 * Config sets the state of a rule to `DELETING`
 * until the deletion is complete. You cannot update a rule while it is
 * in this state. If you make a `PutConfigRule` or
 * `DeleteConfigRule` request for the rule, you will
 * receive a `ResourceInUseException`.
 *
 * You can check the state of a rule by using the
 * `DescribeConfigRules` request.
 *
 * **Recommendation: Consider excluding the `AWS::Config::ResourceCompliance` resource type from recording before deleting rules**
 *
 * Deleting rules creates configuration items (CIs) for `AWS::Config::ResourceCompliance`
 * that can affect your costs for the configuration recorder. If you are deleting rules which evaluate a large number of resource types,
 * this can lead to a spike in the number of CIs recorded.
 *
 * To avoid the associated costs, you can opt to disable recording
 * for the `AWS::Config::ResourceCompliance` resource type before deleting rules, and re-enable recording after the rules have been deleted.
 *
 * However, since deleting rules is an asynchronous process, it might take an hour or more to complete. During the time
 * when recording is disabled for `AWS::Config::ResourceCompliance`, rule evaluations will not be recorded in the associated resource’s history.
 */
export const deleteConfigRule: API.OperationMethod<
  DeleteConfigRuleRequest,
  DeleteConfigRuleResponse,
  DeleteConfigRuleError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteConfigRuleRequest,
  output: DeleteConfigRuleResponse,
  errors: [NoSuchConfigRuleException, ResourceInUseException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteConfigRule",
}));

export type DeleteConfigurationAggregatorError =
  | NoSuchConfigurationAggregatorException
  | CommonErrors;
/**
 * Deletes the specified configuration aggregator and the
 * aggregated data associated with the aggregator.
 */
export const deleteConfigurationAggregator: API.OperationMethod<
  DeleteConfigurationAggregatorRequest,
  DeleteConfigurationAggregatorResponse,
  DeleteConfigurationAggregatorError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteConfigurationAggregatorRequest,
  output: DeleteConfigurationAggregatorResponse,
  errors: [NoSuchConfigurationAggregatorException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteConfigurationAggregator",
}));

export type DeleteConfigurationRecorderError =
  | NoSuchConfigurationRecorderException
  | UnmodifiableEntityException
  | CommonErrors;
/**
 * Deletes the customer managed configuration recorder.
 *
 * This operation does not delete the configuration information that
 * was previously recorded. You will be able to access the previously
 * recorded information by using the
 * GetResourceConfigHistory operation, but you will not
 * be able to access this information in the Config console until
 * you have created a new customer managed configuration recorder.
 */
export const deleteConfigurationRecorder: API.OperationMethod<
  DeleteConfigurationRecorderRequest,
  DeleteConfigurationRecorderResponse,
  DeleteConfigurationRecorderError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteConfigurationRecorderRequest,
  output: DeleteConfigurationRecorderResponse,
  errors: [NoSuchConfigurationRecorderException, UnmodifiableEntityException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteConfigurationRecorder",
}));

export type DeleteConformancePackError =
  | NoSuchConformancePackException
  | ResourceInUseException
  | CommonErrors;
/**
 * Deletes the specified conformance pack and all the Config rules, remediation actions, and all evaluation results within that
 * conformance pack.
 *
 * Config sets the conformance pack to `DELETE_IN_PROGRESS` until the deletion is complete.
 * You cannot update a conformance pack while it is in this state.
 *
 * **Recommendation: Consider excluding the `AWS::Config::ResourceCompliance` resource type from recording before deleting rules**
 *
 * Deleting rules creates configuration items (CIs) for `AWS::Config::ResourceCompliance`
 * that can affect your costs for the configuration recorder. If you are deleting rules which evaluate a large number of resource types,
 * this can lead to a spike in the number of CIs recorded.
 *
 * To avoid the associated costs, you can opt to disable recording
 * for the `AWS::Config::ResourceCompliance` resource type before deleting rules, and re-enable recording after the rules have been deleted.
 *
 * However, since deleting rules is an asynchronous process, it might take an hour or more to complete. During the time
 * when recording is disabled for `AWS::Config::ResourceCompliance`, rule evaluations will not be recorded in the associated resource’s history.
 */
export const deleteConformancePack: API.OperationMethod<
  DeleteConformancePackRequest,
  DeleteConformancePackResponse,
  DeleteConformancePackError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteConformancePackRequest,
  output: DeleteConformancePackResponse,
  errors: [NoSuchConformancePackException, ResourceInUseException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteConformancePack",
}));

export type DeleteConnectorError =
  | ResourceNotFoundException
  | ValidationException
  | CommonErrors;
/**
 * Deletes the specified connector.
 */
export const deleteConnector: API.OperationMethod<
  DeleteConnectorRequest,
  DeleteConnectorResponse,
  DeleteConnectorError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteConnectorRequest,
  output: DeleteConnectorResponse,
  errors: [ResourceNotFoundException, ValidationException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteConnector",
}));

export type DeleteDeliveryChannelError =
  | LastDeliveryChannelDeleteFailedException
  | NoSuchDeliveryChannelException
  | CommonErrors;
/**
 * Deletes the delivery channel.
 *
 * Before you can delete the delivery channel, you must stop the customer managed configuration recorder. You can use the StopConfigurationRecorder operation to stop the customer managed configuration recorder.
 */
export const deleteDeliveryChannel: API.OperationMethod<
  DeleteDeliveryChannelRequest,
  DeleteDeliveryChannelResponse,
  DeleteDeliveryChannelError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteDeliveryChannelRequest,
  output: DeleteDeliveryChannelResponse,
  errors: [
    LastDeliveryChannelDeleteFailedException,
    NoSuchDeliveryChannelException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteDeliveryChannel",
}));

export type DeleteEvaluationResultsError =
  | NoSuchConfigRuleException
  | ResourceInUseException
  | CommonErrors;
/**
 * Deletes the evaluation results for the specified Config
 * rule. You can specify one Config rule per request. After you
 * delete the evaluation results, you can call the StartConfigRulesEvaluation API to start evaluating
 * your Amazon Web Services resources against the rule.
 */
export const deleteEvaluationResults: API.OperationMethod<
  DeleteEvaluationResultsRequest,
  DeleteEvaluationResultsResponse,
  DeleteEvaluationResultsError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteEvaluationResultsRequest,
  output: DeleteEvaluationResultsResponse,
  errors: [NoSuchConfigRuleException, ResourceInUseException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteEvaluationResults",
}));

export type DeleteOrganizationConfigRuleError =
  | NoSuchOrganizationConfigRuleException
  | OrganizationAccessDeniedException
  | ResourceInUseException
  | CommonErrors;
/**
 * Deletes the specified organization Config rule and all of its evaluation results from all member accounts in that organization.
 *
 * Only a management account and a delegated administrator account can delete an organization Config rule.
 * When calling this API with a delegated administrator, you must ensure Organizations
 * `ListDelegatedAdministrator` permissions are added.
 *
 * Config sets the state of a rule to DELETE_IN_PROGRESS until the deletion is complete.
 * You cannot update a rule while it is in this state.
 *
 * **Recommendation: Consider excluding the `AWS::Config::ResourceCompliance` resource type from recording before deleting rules**
 *
 * Deleting rules creates configuration items (CIs) for `AWS::Config::ResourceCompliance`
 * that can affect your costs for the configuration recorder. If you are deleting rules which evaluate a large number of resource types,
 * this can lead to a spike in the number of CIs recorded.
 *
 * To avoid the associated costs, you can opt to disable recording
 * for the `AWS::Config::ResourceCompliance` resource type before deleting rules, and re-enable recording after the rules have been deleted.
 *
 * However, since deleting rules is an asynchronous process, it might take an hour or more to complete. During the time
 * when recording is disabled for `AWS::Config::ResourceCompliance`, rule evaluations will not be recorded in the associated resource’s history.
 */
export const deleteOrganizationConfigRule: API.OperationMethod<
  DeleteOrganizationConfigRuleRequest,
  DeleteOrganizationConfigRuleResponse,
  DeleteOrganizationConfigRuleError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteOrganizationConfigRuleRequest,
  output: DeleteOrganizationConfigRuleResponse,
  errors: [
    NoSuchOrganizationConfigRuleException,
    OrganizationAccessDeniedException,
    ResourceInUseException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteOrganizationConfigRule",
}));

export type DeleteOrganizationConformancePackError =
  | NoSuchOrganizationConformancePackException
  | OrganizationAccessDeniedException
  | ResourceInUseException
  | CommonErrors;
/**
 * Deletes the specified organization conformance pack and all of the Config rules and remediation actions from
 * all member accounts in that organization.
 *
 * Only a management account or a delegated administrator account can delete an organization conformance pack.
 * When calling this API with a delegated administrator, you must ensure Organizations
 * `ListDelegatedAdministrator` permissions are added.
 *
 * Config sets the state of a conformance pack to DELETE_IN_PROGRESS until the deletion is complete.
 * You cannot update a conformance pack while it is in this state.
 *
 * **Recommendation: Consider excluding the `AWS::Config::ResourceCompliance` resource type from recording before deleting rules**
 *
 * Deleting rules creates configuration items (CIs) for `AWS::Config::ResourceCompliance`
 * that can affect your costs for the configuration recorder. If you are deleting rules which evaluate a large number of resource types,
 * this can lead to a spike in the number of CIs recorded.
 *
 * To avoid the associated costs, you can opt to disable recording
 * for the `AWS::Config::ResourceCompliance` resource type before deleting rules, and re-enable recording after the rules have been deleted.
 *
 * However, since deleting rules is an asynchronous process, it might take an hour or more to complete. During the time
 * when recording is disabled for `AWS::Config::ResourceCompliance`, rule evaluations will not be recorded in the associated resource’s history.
 */
export const deleteOrganizationConformancePack: API.OperationMethod<
  DeleteOrganizationConformancePackRequest,
  DeleteOrganizationConformancePackResponse,
  DeleteOrganizationConformancePackError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteOrganizationConformancePackRequest,
  output: DeleteOrganizationConformancePackResponse,
  errors: [
    NoSuchOrganizationConformancePackException,
    OrganizationAccessDeniedException,
    ResourceInUseException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteOrganizationConformancePack",
}));

export type DeletePendingAggregationRequestError =
  | InvalidParameterValueException
  | CommonErrors;
/**
 * Deletes pending authorization requests for a specified
 * aggregator account in a specified region.
 */
export const deletePendingAggregationRequest: API.OperationMethod<
  DeletePendingAggregationRequestRequest,
  DeletePendingAggregationRequestResponse,
  DeletePendingAggregationRequestError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeletePendingAggregationRequestRequest,
  output: DeletePendingAggregationRequestResponse,
  errors: [InvalidParameterValueException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeletePendingAggregationRequest",
}));

export type DeleteRemediationConfigurationError =
  | InsufficientPermissionsException
  | InvalidParameterValueException
  | NoSuchRemediationConfigurationException
  | RemediationInProgressException
  | CommonErrors;
/**
 * Deletes the remediation configuration.
 */
export const deleteRemediationConfiguration: API.OperationMethod<
  DeleteRemediationConfigurationRequest,
  DeleteRemediationConfigurationResponse,
  DeleteRemediationConfigurationError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteRemediationConfigurationRequest,
  output: DeleteRemediationConfigurationResponse,
  errors: [
    InsufficientPermissionsException,
    InvalidParameterValueException,
    NoSuchRemediationConfigurationException,
    RemediationInProgressException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteRemediationConfiguration",
}));

export type DeleteRemediationExceptionsError =
  | NoSuchRemediationExceptionException
  | CommonErrors;
/**
 * Deletes one or more remediation exceptions mentioned in the resource keys.
 *
 * Config generates a remediation exception when a problem occurs executing a remediation action to a specific resource.
 * Remediation exceptions blocks auto-remediation until the exception is cleared.
 */
export const deleteRemediationExceptions: API.OperationMethod<
  DeleteRemediationExceptionsRequest,
  DeleteRemediationExceptionsResponse,
  DeleteRemediationExceptionsError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteRemediationExceptionsRequest,
  output: DeleteRemediationExceptionsResponse,
  errors: [NoSuchRemediationExceptionException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteRemediationExceptions",
}));

export type DeleteResourceConfigError =
  | NoRunningConfigurationRecorderException
  | ValidationException
  | CommonErrors;
/**
 * Records the configuration state for a custom resource that has been deleted. This API records a new ConfigurationItem with a ResourceDeleted status. You can retrieve the ConfigurationItems recorded for this resource in your Config History.
 */
export const deleteResourceConfig: API.OperationMethod<
  DeleteResourceConfigRequest,
  DeleteResourceConfigResponse,
  DeleteResourceConfigError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteResourceConfigRequest,
  output: DeleteResourceConfigResponse,
  errors: [NoRunningConfigurationRecorderException, ValidationException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteResourceConfig",
}));

export type DeleteRetentionConfigurationError =
  | InvalidParameterValueException
  | NoSuchRetentionConfigurationException
  | CommonErrors;
/**
 * Deletes the retention configuration.
 */
export const deleteRetentionConfiguration: API.OperationMethod<
  DeleteRetentionConfigurationRequest,
  DeleteRetentionConfigurationResponse,
  DeleteRetentionConfigurationError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteRetentionConfigurationRequest,
  output: DeleteRetentionConfigurationResponse,
  errors: [
    InvalidParameterValueException,
    NoSuchRetentionConfigurationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteRetentionConfiguration",
}));

export type DeleteServiceLinkedConfigurationRecorderError =
  | ConflictException
  | NoSuchConfigurationRecorderException
  | ValidationException
  | CommonErrors;
/**
 * Deletes an existing service-linked configuration recorder.
 *
 * This operation does not delete the configuration information that was previously recorded. You will be able to access the previously
 * recorded information by using the
 * GetResourceConfigHistory operation, but you will not
 * be able to access this information in the Config console until
 * you have created a new service-linked configuration recorder for the same service.
 *
 * **The recording scope determines if you receive configuration items**
 *
 * The recording scope is set by the service that is linked to the configuration recorder and determines whether you receive configuration items (CIs) in the delivery channel. If the recording scope is internal, you will not receive CIs in the delivery channel.
 */
export const deleteServiceLinkedConfigurationRecorder: API.OperationMethod<
  DeleteServiceLinkedConfigurationRecorderRequest,
  DeleteServiceLinkedConfigurationRecorderResponse,
  DeleteServiceLinkedConfigurationRecorderError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteServiceLinkedConfigurationRecorderRequest,
  output: DeleteServiceLinkedConfigurationRecorderResponse,
  errors: [
    ConflictException,
    NoSuchConfigurationRecorderException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteServiceLinkedConfigurationRecorder",
}));

export type DeleteStoredQueryError =
  | ResourceNotFoundException
  | ValidationException
  | CommonErrors;
/**
 * Deletes the stored query for a single Amazon Web Services account and a single Amazon Web Services Region.
 */
export const deleteStoredQuery: API.OperationMethod<
  DeleteStoredQueryRequest,
  DeleteStoredQueryResponse,
  DeleteStoredQueryError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeleteStoredQueryRequest,
  output: DeleteStoredQueryResponse,
  errors: [ResourceNotFoundException, ValidationException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeleteStoredQuery",
}));

export type DeliverConfigSnapshotError =
  | NoAvailableConfigurationRecorderException
  | NoRunningConfigurationRecorderException
  | NoSuchDeliveryChannelException
  | CommonErrors;
/**
 * Schedules delivery of a configuration snapshot to the Amazon S3
 * bucket in the specified delivery channel. After the delivery has
 * started, Config sends the following notifications using an
 * Amazon SNS topic that you have specified.
 *
 * - Notification of the start of the delivery.
 *
 * - Notification of the completion of the delivery, if the
 * delivery was successfully completed.
 *
 * - Notification of delivery failure, if the delivery
 * failed.
 */
export const deliverConfigSnapshot: API.OperationMethod<
  DeliverConfigSnapshotRequest,
  DeliverConfigSnapshotResponse,
  DeliverConfigSnapshotError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DeliverConfigSnapshotRequest,
  output: DeliverConfigSnapshotResponse,
  errors: [
    NoAvailableConfigurationRecorderException,
    NoRunningConfigurationRecorderException,
    NoSuchDeliveryChannelException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DeliverConfigSnapshot",
}));

export type DescribeAggregateComplianceByConfigRulesError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchConfigurationAggregatorException
  | ValidationException
  | CommonErrors;
/**
 * Returns a list of compliant and noncompliant rules with the
 * number of resources for compliant and noncompliant rules. Does not display rules that do not have compliance results.
 *
 * The results can return an empty result page, but if you
 * have a `nextToken`, the results are displayed on the next
 * page.
 */
export const describeAggregateComplianceByConfigRules: API.PaginatedOperationMethod<
  DescribeAggregateComplianceByConfigRulesRequest,
  DescribeAggregateComplianceByConfigRulesResponse,
  DescribeAggregateComplianceByConfigRulesError,
  Credentials | HttpClient.HttpClient,
  unknown
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeAggregateComplianceByConfigRulesRequest,
  output: DescribeAggregateComplianceByConfigRulesResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchConfigurationAggregatorException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeAggregateComplianceByConfigRules",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeAggregateComplianceByConformancePacksError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchConfigurationAggregatorException
  | ValidationException
  | CommonErrors;
/**
 * Returns a list of the existing and deleted conformance packs and their associated compliance status with the count of compliant and noncompliant Config rules within each
 * conformance pack. Also returns the total rule count which includes compliant rules, noncompliant rules, and rules that cannot be evaluated due to insufficient data.
 *
 * The results can return an empty result page, but if you have a `nextToken`, the results are displayed on the next page.
 */
export const describeAggregateComplianceByConformancePacks: API.PaginatedOperationMethod<
  DescribeAggregateComplianceByConformancePacksRequest,
  DescribeAggregateComplianceByConformancePacksResponse,
  DescribeAggregateComplianceByConformancePacksError,
  Credentials | HttpClient.HttpClient,
  AggregateComplianceByConformancePack
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeAggregateComplianceByConformancePacksRequest,
  output: DescribeAggregateComplianceByConformancePacksResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchConfigurationAggregatorException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeAggregateComplianceByConformancePacks",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "AggregateComplianceByConformancePacks",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeAggregationAuthorizationsError =
  | InvalidLimitException
  | InvalidNextTokenException
  | InvalidParameterValueException
  | CommonErrors;
/**
 * Returns a list of authorizations granted to various aggregator
 * accounts and regions.
 */
export const describeAggregationAuthorizations: API.PaginatedOperationMethod<
  DescribeAggregationAuthorizationsRequest,
  DescribeAggregationAuthorizationsResponse,
  DescribeAggregationAuthorizationsError,
  Credentials | HttpClient.HttpClient,
  AggregationAuthorization
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeAggregationAuthorizationsRequest,
  output: DescribeAggregationAuthorizationsResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    InvalidParameterValueException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeAggregationAuthorizations",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "AggregationAuthorizations",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeComplianceByConfigRuleError =
  | InvalidNextTokenException
  | InvalidParameterValueException
  | NoSuchConfigRuleException
  | CommonErrors;
/**
 * Indicates whether the specified Config rules are compliant.
 * If a rule is noncompliant, this operation returns the number of Amazon Web Services
 * resources that do not comply with the rule.
 *
 * A rule is compliant if all of the evaluated resources comply
 * with it. It is noncompliant if any of these resources do not
 * comply.
 *
 * If Config has no current evaluation results for the rule,
 * it returns `INSUFFICIENT_DATA`. This result might
 * indicate one of the following conditions:
 *
 * - Config has never invoked an evaluation for the
 * rule. To check whether it has, use the
 * `DescribeConfigRuleEvaluationStatus` action
 * to get the `LastSuccessfulInvocationTime` and
 * `LastFailedInvocationTime`.
 *
 * - The rule's Lambda function is failing to send
 * evaluation results to Config. Verify that the role you
 * assigned to your configuration recorder includes the
 * `config:PutEvaluations` permission. If the
 * rule is a custom rule, verify that the Lambda execution
 * role includes the `config:PutEvaluations`
 * permission.
 *
 * - The rule's Lambda function has returned
 * `NOT_APPLICABLE` for all evaluation results.
 * This can occur if the resources were deleted or removed from
 * the rule's scope.
 */
export const describeComplianceByConfigRule: API.PaginatedOperationMethod<
  DescribeComplianceByConfigRuleRequest,
  DescribeComplianceByConfigRuleResponse,
  DescribeComplianceByConfigRuleError,
  Credentials | HttpClient.HttpClient,
  ComplianceByConfigRule
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeComplianceByConfigRuleRequest,
  output: DescribeComplianceByConfigRuleResponse,
  errors: [
    InvalidNextTokenException,
    InvalidParameterValueException,
    NoSuchConfigRuleException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeComplianceByConfigRule",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "ComplianceByConfigRules",
  } as const,
})) as any;

export type DescribeComplianceByResourceError =
  | InvalidNextTokenException
  | InvalidParameterValueException
  | CommonErrors;
/**
 * Indicates whether the specified Amazon Web Services resources are compliant. If
 * a resource is noncompliant, this operation returns the number of Config rules that the resource does not comply with.
 *
 * A resource is compliant if it complies with all the Config
 * rules that evaluate it. It is noncompliant if it does not comply
 * with one or more of these rules.
 *
 * If Config has no current evaluation results for the
 * resource, it returns `INSUFFICIENT_DATA`. This result
 * might indicate one of the following conditions about the rules that
 * evaluate the resource:
 *
 * - Config has never invoked an evaluation for the
 * rule. To check whether it has, use the
 * `DescribeConfigRuleEvaluationStatus` action
 * to get the `LastSuccessfulInvocationTime` and
 * `LastFailedInvocationTime`.
 *
 * - The rule's Lambda function is failing to send
 * evaluation results to Config. Verify that the role that
 * you assigned to your configuration recorder includes the
 * `config:PutEvaluations` permission. If the
 * rule is a custom rule, verify that the Lambda execution
 * role includes the `config:PutEvaluations`
 * permission.
 *
 * - The rule's Lambda function has returned
 * `NOT_APPLICABLE` for all evaluation results.
 * This can occur if the resources were deleted or removed from
 * the rule's scope.
 */
export const describeComplianceByResource: API.PaginatedOperationMethod<
  DescribeComplianceByResourceRequest,
  DescribeComplianceByResourceResponse,
  DescribeComplianceByResourceError,
  Credentials | HttpClient.HttpClient,
  ComplianceByResource
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeComplianceByResourceRequest,
  output: DescribeComplianceByResourceResponse,
  errors: [InvalidNextTokenException, InvalidParameterValueException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeComplianceByResource",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "ComplianceByResources",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeConfigRuleEvaluationStatusError =
  | InvalidNextTokenException
  | InvalidParameterValueException
  | NoSuchConfigRuleException
  | CommonErrors;
/**
 * Returns status information for each of your Config managed rules. The status includes information such as the last time Config invoked the rule, the last time Config failed to invoke
 * the rule, and the related error for the last failure.
 */
export const describeConfigRuleEvaluationStatus: API.PaginatedOperationMethod<
  DescribeConfigRuleEvaluationStatusRequest,
  DescribeConfigRuleEvaluationStatusResponse,
  DescribeConfigRuleEvaluationStatusError,
  Credentials | HttpClient.HttpClient,
  ConfigRuleEvaluationStatus
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeConfigRuleEvaluationStatusRequest,
  output: DescribeConfigRuleEvaluationStatusResponse,
  errors: [
    InvalidNextTokenException,
    InvalidParameterValueException,
    NoSuchConfigRuleException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeConfigRuleEvaluationStatus",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "ConfigRulesEvaluationStatus",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeConfigRulesError =
  | InvalidNextTokenException
  | InvalidParameterValueException
  | NoSuchConfigRuleException
  | CommonErrors;
/**
 * Returns details about your Config rules.
 */
export const describeConfigRules: API.PaginatedOperationMethod<
  DescribeConfigRulesRequest,
  DescribeConfigRulesResponse,
  DescribeConfigRulesError,
  Credentials | HttpClient.HttpClient,
  ConfigRule
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeConfigRulesRequest,
  output: DescribeConfigRulesResponse,
  errors: [
    InvalidNextTokenException,
    InvalidParameterValueException,
    NoSuchConfigRuleException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeConfigRules",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "ConfigRules",
  } as const,
})) as any;

export type DescribeConfigurationAggregatorsError =
  | InvalidLimitException
  | InvalidNextTokenException
  | InvalidParameterValueException
  | NoSuchConfigurationAggregatorException
  | CommonErrors;
/**
 * Returns the details of one or more configuration aggregators.
 * If the configuration aggregator is not specified, this operation
 * returns the details for all the configuration aggregators associated
 * with the account.
 */
export const describeConfigurationAggregators: API.PaginatedOperationMethod<
  DescribeConfigurationAggregatorsRequest,
  DescribeConfigurationAggregatorsResponse,
  DescribeConfigurationAggregatorsError,
  Credentials | HttpClient.HttpClient,
  ConfigurationAggregator
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeConfigurationAggregatorsRequest,
  output: DescribeConfigurationAggregatorsResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    InvalidParameterValueException,
    NoSuchConfigurationAggregatorException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeConfigurationAggregators",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "ConfigurationAggregators",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeConfigurationAggregatorSourcesStatusError =
  | InvalidLimitException
  | InvalidNextTokenException
  | InvalidParameterValueException
  | NoSuchConfigurationAggregatorException
  | CommonErrors;
/**
 * Returns status information for sources within an aggregator.
 * The status includes information about the last time Config verified authorization between the source account and an aggregator account. In case of a failure, the status contains the related error code or message.
 */
export const describeConfigurationAggregatorSourcesStatus: API.PaginatedOperationMethod<
  DescribeConfigurationAggregatorSourcesStatusRequest,
  DescribeConfigurationAggregatorSourcesStatusResponse,
  DescribeConfigurationAggregatorSourcesStatusError,
  Credentials | HttpClient.HttpClient,
  AggregatedSourceStatus
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeConfigurationAggregatorSourcesStatusRequest,
  output: DescribeConfigurationAggregatorSourcesStatusResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    InvalidParameterValueException,
    NoSuchConfigurationAggregatorException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeConfigurationAggregatorSourcesStatus",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "AggregatedSourceStatusList",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeConfigurationRecordersError =
  | NoSuchConfigurationRecorderException
  | ValidationException
  | CommonErrors;
/**
 * Returns details for the configuration recorder you specify.
 *
 * If a configuration recorder is not specified, this operation returns details for the customer managed configuration recorder configured for the
 * account, if applicable.
 *
 * When making a request to this operation, you can only specify one configuration recorder.
 */
export const describeConfigurationRecorders: API.OperationMethod<
  DescribeConfigurationRecordersRequest,
  DescribeConfigurationRecordersResponse,
  DescribeConfigurationRecordersError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DescribeConfigurationRecordersRequest,
  output: DescribeConfigurationRecordersResponse,
  errors: [NoSuchConfigurationRecorderException, ValidationException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeConfigurationRecorders",
}));

export type DescribeConfigurationRecorderStatusError =
  | NoSuchConfigurationRecorderException
  | ValidationException
  | CommonErrors;
/**
 * Returns the current status of the configuration
 * recorder you specify as well as the status of the last recording event for the configuration recorders.
 *
 * For a detailed status of recording events over time, add your Config events to Amazon CloudWatch metrics and use CloudWatch metrics.
 *
 * If a configuration recorder is not specified, this operation returns the status for the customer managed configuration recorder configured for the
 * account, if applicable.
 *
 * When making a request to this operation, you can only specify one configuration recorder.
 */
export const describeConfigurationRecorderStatus: API.OperationMethod<
  DescribeConfigurationRecorderStatusRequest,
  DescribeConfigurationRecorderStatusResponse,
  DescribeConfigurationRecorderStatusError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DescribeConfigurationRecorderStatusRequest,
  output: DescribeConfigurationRecorderStatusResponse,
  errors: [NoSuchConfigurationRecorderException, ValidationException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeConfigurationRecorderStatus",
}));

export type DescribeConformancePackComplianceError =
  | InvalidLimitException
  | InvalidNextTokenException
  | InvalidParameterValueException
  | NoSuchConfigRuleInConformancePackException
  | NoSuchConformancePackException
  | CommonErrors;
/**
 * Returns compliance details for each rule in that conformance pack.
 *
 * You must provide exact rule names.
 */
export const describeConformancePackCompliance: API.PaginatedOperationMethod<
  DescribeConformancePackComplianceRequest,
  DescribeConformancePackComplianceResponse,
  DescribeConformancePackComplianceError,
  Credentials | HttpClient.HttpClient,
  ConformancePackRuleCompliance
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeConformancePackComplianceRequest,
  output: DescribeConformancePackComplianceResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    InvalidParameterValueException,
    NoSuchConfigRuleInConformancePackException,
    NoSuchConformancePackException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeConformancePackCompliance",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "ConformancePackRuleComplianceList",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeConformancePacksError =
  | InvalidLimitException
  | InvalidNextTokenException
  | InvalidParameterValueException
  | NoSuchConformancePackException
  | CommonErrors;
/**
 * Returns a list of one or more conformance packs.
 */
export const describeConformancePacks: API.PaginatedOperationMethod<
  DescribeConformancePacksRequest,
  DescribeConformancePacksResponse,
  DescribeConformancePacksError,
  Credentials | HttpClient.HttpClient,
  ConformancePackDetail
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeConformancePacksRequest,
  output: DescribeConformancePacksResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    InvalidParameterValueException,
    NoSuchConformancePackException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeConformancePacks",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "ConformancePackDetails",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeConformancePackStatusError =
  | InvalidLimitException
  | InvalidNextTokenException
  | InvalidParameterValueException
  | CommonErrors;
/**
 * Provides one or more conformance packs deployment status.
 *
 * If there are no conformance packs then you will see an empty result.
 */
export const describeConformancePackStatus: API.PaginatedOperationMethod<
  DescribeConformancePackStatusRequest,
  DescribeConformancePackStatusResponse,
  DescribeConformancePackStatusError,
  Credentials | HttpClient.HttpClient,
  ConformancePackStatusDetail
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeConformancePackStatusRequest,
  output: DescribeConformancePackStatusResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    InvalidParameterValueException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeConformancePackStatus",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "ConformancePackStatusDetails",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeDeliveryChannelsError =
  | NoSuchDeliveryChannelException
  | CommonErrors;
/**
 * Returns details about the specified delivery channel. If a
 * delivery channel is not specified, this operation returns the details
 * of all delivery channels associated with the account.
 *
 * Currently, you can specify only one delivery channel per
 * region in your account.
 */
export const describeDeliveryChannels: API.OperationMethod<
  DescribeDeliveryChannelsRequest,
  DescribeDeliveryChannelsResponse,
  DescribeDeliveryChannelsError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DescribeDeliveryChannelsRequest,
  output: DescribeDeliveryChannelsResponse,
  errors: [NoSuchDeliveryChannelException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeDeliveryChannels",
}));

export type DescribeDeliveryChannelStatusError =
  | NoSuchDeliveryChannelException
  | CommonErrors;
/**
 * Returns the current status of the specified delivery channel.
 * If a delivery channel is not specified, this operation returns the
 * current status of all delivery channels associated with the
 * account.
 *
 * Currently, you can specify only one delivery channel per
 * region in your account.
 */
export const describeDeliveryChannelStatus: API.OperationMethod<
  DescribeDeliveryChannelStatusRequest,
  DescribeDeliveryChannelStatusResponse,
  DescribeDeliveryChannelStatusError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DescribeDeliveryChannelStatusRequest,
  output: DescribeDeliveryChannelStatusResponse,
  errors: [NoSuchDeliveryChannelException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeDeliveryChannelStatus",
}));

export type DescribeOrganizationConfigRulesError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchOrganizationConfigRuleException
  | OrganizationAccessDeniedException
  | CommonErrors;
/**
 * Returns a list of organization Config rules.
 *
 * When you specify the limit and the next token, you receive a paginated response.
 *
 * Limit and next token are not applicable if you specify organization Config rule names.
 * It is only applicable, when you request all the organization Config rules.
 *
 * *For accounts within an organization*
 *
 * If you deploy an organizational rule or conformance pack in an organization
 * administrator account, and then establish a delegated administrator and deploy an
 * organizational rule or conformance pack in the delegated administrator account, you
 * won't be able to see the organizational rule or conformance pack in the organization
 * administrator account from the delegated administrator account or see the organizational
 * rule or conformance pack in the delegated administrator account from organization
 * administrator account. The `DescribeOrganizationConfigRules` and
 * `DescribeOrganizationConformancePacks` APIs can only see and interact with
 * the organization-related resource that were deployed from within the account calling
 * those APIs.
 */
export const describeOrganizationConfigRules: API.PaginatedOperationMethod<
  DescribeOrganizationConfigRulesRequest,
  DescribeOrganizationConfigRulesResponse,
  DescribeOrganizationConfigRulesError,
  Credentials | HttpClient.HttpClient,
  OrganizationConfigRule
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeOrganizationConfigRulesRequest,
  output: DescribeOrganizationConfigRulesResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchOrganizationConfigRuleException,
    OrganizationAccessDeniedException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeOrganizationConfigRules",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "OrganizationConfigRules",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeOrganizationConfigRuleStatusesError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchOrganizationConfigRuleException
  | OrganizationAccessDeniedException
  | CommonErrors;
/**
 * Provides organization Config rule deployment status for an organization.
 *
 * The status is not considered successful until organization Config rule is successfully deployed in all the member
 * accounts with an exception of excluded accounts.
 *
 * When you specify the limit and the next token, you receive a paginated response.
 * Limit and next token are not applicable if you specify organization Config rule names.
 * It is only applicable, when you request all the organization Config rules.
 */
export const describeOrganizationConfigRuleStatuses: API.PaginatedOperationMethod<
  DescribeOrganizationConfigRuleStatusesRequest,
  DescribeOrganizationConfigRuleStatusesResponse,
  DescribeOrganizationConfigRuleStatusesError,
  Credentials | HttpClient.HttpClient,
  OrganizationConfigRuleStatus
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeOrganizationConfigRuleStatusesRequest,
  output: DescribeOrganizationConfigRuleStatusesResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchOrganizationConfigRuleException,
    OrganizationAccessDeniedException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeOrganizationConfigRuleStatuses",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "OrganizationConfigRuleStatuses",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeOrganizationConformancePacksError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchOrganizationConformancePackException
  | OrganizationAccessDeniedException
  | CommonErrors;
/**
 * Returns a list of organization conformance packs.
 *
 * When you specify the limit and the next token, you receive a paginated response.
 *
 * Limit and next token are not applicable if you specify organization conformance packs names. They are only applicable,
 * when you request all the organization conformance packs.
 *
 * *For accounts within an organization*
 *
 * If you deploy an organizational rule or conformance pack in an organization
 * administrator account, and then establish a delegated administrator and deploy an
 * organizational rule or conformance pack in the delegated administrator account, you
 * won't be able to see the organizational rule or conformance pack in the organization
 * administrator account from the delegated administrator account or see the organizational
 * rule or conformance pack in the delegated administrator account from organization
 * administrator account. The `DescribeOrganizationConfigRules` and
 * `DescribeOrganizationConformancePacks` APIs can only see and interact with
 * the organization-related resource that were deployed from within the account calling
 * those APIs.
 */
export const describeOrganizationConformancePacks: API.PaginatedOperationMethod<
  DescribeOrganizationConformancePacksRequest,
  DescribeOrganizationConformancePacksResponse,
  DescribeOrganizationConformancePacksError,
  Credentials | HttpClient.HttpClient,
  OrganizationConformancePack
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeOrganizationConformancePacksRequest,
  output: DescribeOrganizationConformancePacksResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchOrganizationConformancePackException,
    OrganizationAccessDeniedException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeOrganizationConformancePacks",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "OrganizationConformancePacks",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeOrganizationConformancePackStatusesError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchOrganizationConformancePackException
  | OrganizationAccessDeniedException
  | CommonErrors;
/**
 * Provides organization conformance pack deployment status for an organization.
 *
 * The status is not considered successful until organization conformance pack is successfully
 * deployed in all the member accounts with an exception of excluded accounts.
 *
 * When you specify the limit and the next token, you receive a paginated response.
 * Limit and next token are not applicable if you specify organization conformance pack names.
 * They are only applicable, when you request all the organization conformance packs.
 */
export const describeOrganizationConformancePackStatuses: API.PaginatedOperationMethod<
  DescribeOrganizationConformancePackStatusesRequest,
  DescribeOrganizationConformancePackStatusesResponse,
  DescribeOrganizationConformancePackStatusesError,
  Credentials | HttpClient.HttpClient,
  OrganizationConformancePackStatus
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeOrganizationConformancePackStatusesRequest,
  output: DescribeOrganizationConformancePackStatusesResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchOrganizationConformancePackException,
    OrganizationAccessDeniedException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeOrganizationConformancePackStatuses",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "OrganizationConformancePackStatuses",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribePendingAggregationRequestsError =
  | InvalidLimitException
  | InvalidNextTokenException
  | InvalidParameterValueException
  | CommonErrors;
/**
 * Returns a list of all pending aggregation requests.
 */
export const describePendingAggregationRequests: API.PaginatedOperationMethod<
  DescribePendingAggregationRequestsRequest,
  DescribePendingAggregationRequestsResponse,
  DescribePendingAggregationRequestsError,
  Credentials | HttpClient.HttpClient,
  PendingAggregationRequest
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribePendingAggregationRequestsRequest,
  output: DescribePendingAggregationRequestsResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    InvalidParameterValueException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribePendingAggregationRequests",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "PendingAggregationRequests",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeRemediationConfigurationsError = CommonErrors;
/**
 * Returns the details of one or more remediation configurations.
 */
export const describeRemediationConfigurations: API.OperationMethod<
  DescribeRemediationConfigurationsRequest,
  DescribeRemediationConfigurationsResponse,
  DescribeRemediationConfigurationsError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DescribeRemediationConfigurationsRequest,
  output: DescribeRemediationConfigurationsResponse,
  errors: [],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeRemediationConfigurations",
}));

export type DescribeRemediationExceptionsError =
  | InvalidNextTokenException
  | InvalidParameterValueException
  | CommonErrors;
/**
 * Returns the details of one or more remediation exceptions. A detailed view of a remediation exception for a set of resources that includes an explanation of an exception and the time when the exception will be deleted.
 * When you specify the limit and the next token, you receive a paginated response.
 *
 * Config generates a remediation exception when a problem occurs executing a remediation action to a specific resource.
 * Remediation exceptions blocks auto-remediation until the exception is cleared.
 *
 * When you specify the limit and the next token, you receive a paginated response.
 *
 * Limit and next token are not applicable if you request resources in batch. It is only applicable, when you request all resources.
 */
export const describeRemediationExceptions: API.PaginatedOperationMethod<
  DescribeRemediationExceptionsRequest,
  DescribeRemediationExceptionsResponse,
  DescribeRemediationExceptionsError,
  Credentials | HttpClient.HttpClient,
  unknown
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeRemediationExceptionsRequest,
  output: DescribeRemediationExceptionsResponse,
  errors: [InvalidNextTokenException, InvalidParameterValueException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeRemediationExceptions",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeRemediationExecutionStatusError =
  | InvalidNextTokenException
  | InvalidParameterValueException
  | NoSuchRemediationConfigurationException
  | CommonErrors;
/**
 * Provides a detailed view of a Remediation Execution for a set of resources including state, timestamps for when steps for the remediation execution occur, and any error messages for steps that have failed.
 * When you specify the limit and the next token, you receive a paginated response.
 */
export const describeRemediationExecutionStatus: API.PaginatedOperationMethod<
  DescribeRemediationExecutionStatusRequest,
  DescribeRemediationExecutionStatusResponse,
  DescribeRemediationExecutionStatusError,
  Credentials | HttpClient.HttpClient,
  RemediationExecutionStatus
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeRemediationExecutionStatusRequest,
  output: DescribeRemediationExecutionStatusResponse,
  errors: [
    InvalidNextTokenException,
    InvalidParameterValueException,
    NoSuchRemediationConfigurationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeRemediationExecutionStatus",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "RemediationExecutionStatuses",
    pageSize: "Limit",
  } as const,
})) as any;

export type DescribeRetentionConfigurationsError =
  | InvalidNextTokenException
  | InvalidParameterValueException
  | NoSuchRetentionConfigurationException
  | CommonErrors;
/**
 * Returns the details of one or more retention configurations. If
 * the retention configuration name is not specified, this operation
 * returns the details for all the retention configurations for that
 * account.
 *
 * Currently, Config supports only one retention
 * configuration per region in your account.
 */
export const describeRetentionConfigurations: API.PaginatedOperationMethod<
  DescribeRetentionConfigurationsRequest,
  DescribeRetentionConfigurationsResponse,
  DescribeRetentionConfigurationsError,
  Credentials | HttpClient.HttpClient,
  RetentionConfiguration
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: DescribeRetentionConfigurationsRequest,
  output: DescribeRetentionConfigurationsResponse,
  errors: [
    InvalidNextTokenException,
    InvalidParameterValueException,
    NoSuchRetentionConfigurationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DescribeRetentionConfigurations",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "RetentionConfigurations",
  } as const,
})) as any;

export type DisassociateResourceTypesError =
  | ConflictException
  | NoSuchConfigurationRecorderException
  | ValidationException
  | CommonErrors;
/**
 * Removes all resource types specified in the `ResourceTypes` list from the RecordingGroup of configuration recorder and excludes these resource types when recording.
 *
 * For this operation, the configuration recorder must use a RecordingStrategy that is either `INCLUSION_BY_RESOURCE_TYPES` or `EXCLUSION_BY_RESOURCE_TYPES`.
 */
export const disassociateResourceTypes: API.OperationMethod<
  DisassociateResourceTypesRequest,
  DisassociateResourceTypesResponse,
  DisassociateResourceTypesError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: DisassociateResourceTypesRequest,
  output: DisassociateResourceTypesResponse,
  errors: [
    ConflictException,
    NoSuchConfigurationRecorderException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "DisassociateResourceTypes",
}));

export type GetAggregateComplianceDetailsByConfigRuleError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchConfigurationAggregatorException
  | ValidationException
  | CommonErrors;
/**
 * Returns the evaluation results for the specified Config
 * rule for a specific resource in a rule. The results indicate which
 * Amazon Web Services resources were evaluated by the rule, when each resource was
 * last evaluated, and whether each resource complies with the rule.
 *
 * The results can return an empty result page. But if you
 * have a `nextToken`, the results are displayed on the next
 * page.
 */
export const getAggregateComplianceDetailsByConfigRule: API.PaginatedOperationMethod<
  GetAggregateComplianceDetailsByConfigRuleRequest,
  GetAggregateComplianceDetailsByConfigRuleResponse,
  GetAggregateComplianceDetailsByConfigRuleError,
  Credentials | HttpClient.HttpClient,
  AggregateEvaluationResult
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: GetAggregateComplianceDetailsByConfigRuleRequest,
  output: GetAggregateComplianceDetailsByConfigRuleResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchConfigurationAggregatorException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetAggregateComplianceDetailsByConfigRule",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "AggregateEvaluationResults",
    pageSize: "Limit",
  } as const,
})) as any;

export type GetAggregateConfigRuleComplianceSummaryError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchConfigurationAggregatorException
  | ValidationException
  | CommonErrors;
/**
 * Returns the number of compliant and noncompliant rules for one
 * or more accounts and regions in an aggregator.
 *
 * The results can return an empty result page, but if you
 * have a nextToken, the results are displayed on the next
 * page.
 */
export const getAggregateConfigRuleComplianceSummary: API.PaginatedOperationMethod<
  GetAggregateConfigRuleComplianceSummaryRequest,
  GetAggregateConfigRuleComplianceSummaryResponse,
  GetAggregateConfigRuleComplianceSummaryError,
  Credentials | HttpClient.HttpClient,
  unknown
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: GetAggregateConfigRuleComplianceSummaryRequest,
  output: GetAggregateConfigRuleComplianceSummaryResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchConfigurationAggregatorException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetAggregateConfigRuleComplianceSummary",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    pageSize: "Limit",
  } as const,
})) as any;

export type GetAggregateConformancePackComplianceSummaryError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchConfigurationAggregatorException
  | ValidationException
  | CommonErrors;
/**
 * Returns the count of compliant and noncompliant conformance packs across all Amazon Web Services accounts and Amazon Web Services Regions in an aggregator. You can filter based on Amazon Web Services account ID or Amazon Web Services Region.
 *
 * The results can return an empty result page, but if you have a nextToken, the results are displayed on the next page.
 */
export const getAggregateConformancePackComplianceSummary: API.PaginatedOperationMethod<
  GetAggregateConformancePackComplianceSummaryRequest,
  GetAggregateConformancePackComplianceSummaryResponse,
  GetAggregateConformancePackComplianceSummaryError,
  Credentials | HttpClient.HttpClient,
  unknown
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: GetAggregateConformancePackComplianceSummaryRequest,
  output: GetAggregateConformancePackComplianceSummaryResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchConfigurationAggregatorException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetAggregateConformancePackComplianceSummary",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    pageSize: "Limit",
  } as const,
})) as any;

export type GetAggregateDiscoveredResourceCountsError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchConfigurationAggregatorException
  | ValidationException
  | CommonErrors;
/**
 * Returns the resource counts across accounts and regions that are present in your Config aggregator. You can request the resource counts by providing filters and GroupByKey.
 *
 * For example, if the input contains accountID 12345678910 and region us-east-1 in filters, the API returns the count of resources in account ID 12345678910 and region us-east-1.
 * If the input contains ACCOUNT_ID as a GroupByKey, the API returns resource counts for all source accounts that are present in your aggregator.
 */
export const getAggregateDiscoveredResourceCounts: API.PaginatedOperationMethod<
  GetAggregateDiscoveredResourceCountsRequest,
  GetAggregateDiscoveredResourceCountsResponse,
  GetAggregateDiscoveredResourceCountsError,
  Credentials | HttpClient.HttpClient,
  unknown
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: GetAggregateDiscoveredResourceCountsRequest,
  output: GetAggregateDiscoveredResourceCountsResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchConfigurationAggregatorException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetAggregateDiscoveredResourceCounts",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    pageSize: "Limit",
  } as const,
})) as any;

export type GetAggregateResourceConfigError =
  | NoSuchConfigurationAggregatorException
  | OversizedConfigurationItemException
  | ResourceNotDiscoveredException
  | ValidationException
  | CommonErrors;
/**
 * Returns configuration item that is aggregated for your specific resource in a specific source account and region.
 *
 * The API does not return results for deleted resources.
 */
export const getAggregateResourceConfig: API.OperationMethod<
  GetAggregateResourceConfigRequest,
  GetAggregateResourceConfigResponse,
  GetAggregateResourceConfigError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: GetAggregateResourceConfigRequest,
  output: GetAggregateResourceConfigResponse,
  errors: [
    NoSuchConfigurationAggregatorException,
    OversizedConfigurationItemException,
    ResourceNotDiscoveredException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetAggregateResourceConfig",
}));

export type GetComplianceDetailsByConfigRuleError =
  | InvalidNextTokenException
  | InvalidParameterValueException
  | NoSuchConfigRuleException
  | CommonErrors;
/**
 * Returns the evaluation results for the specified Config
 * rule. The results indicate which Amazon Web Services resources were evaluated by the
 * rule, when each resource was last evaluated, and whether each
 * resource complies with the rule.
 */
export const getComplianceDetailsByConfigRule: API.PaginatedOperationMethod<
  GetComplianceDetailsByConfigRuleRequest,
  GetComplianceDetailsByConfigRuleResponse,
  GetComplianceDetailsByConfigRuleError,
  Credentials | HttpClient.HttpClient,
  EvaluationResult
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: GetComplianceDetailsByConfigRuleRequest,
  output: GetComplianceDetailsByConfigRuleResponse,
  errors: [
    InvalidNextTokenException,
    InvalidParameterValueException,
    NoSuchConfigRuleException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetComplianceDetailsByConfigRule",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "EvaluationResults",
    pageSize: "Limit",
  } as const,
})) as any;

export type GetComplianceDetailsByResourceError =
  | InvalidParameterValueException
  | CommonErrors;
/**
 * Returns the evaluation results for the specified Amazon Web Services resource.
 * The results indicate which Config rules were used to evaluate
 * the resource, when each rule was last invoked, and whether the resource
 * complies with each rule.
 */
export const getComplianceDetailsByResource: API.PaginatedOperationMethod<
  GetComplianceDetailsByResourceRequest,
  GetComplianceDetailsByResourceResponse,
  GetComplianceDetailsByResourceError,
  Credentials | HttpClient.HttpClient,
  EvaluationResult
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: GetComplianceDetailsByResourceRequest,
  output: GetComplianceDetailsByResourceResponse,
  errors: [InvalidParameterValueException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetComplianceDetailsByResource",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "EvaluationResults",
  } as const,
})) as any;

export type GetComplianceSummaryByConfigRuleError = CommonErrors;
/**
 * Returns the number of Config rules that are compliant and
 * noncompliant, up to a maximum of 25 for each.
 */
export const getComplianceSummaryByConfigRule: API.OperationMethod<
  GetComplianceSummaryByConfigRuleRequest,
  GetComplianceSummaryByConfigRuleResponse,
  GetComplianceSummaryByConfigRuleError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: GetComplianceSummaryByConfigRuleRequest,
  output: GetComplianceSummaryByConfigRuleResponse,
  errors: [],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetComplianceSummaryByConfigRule",
}));

export type GetComplianceSummaryByResourceTypeError =
  | InvalidParameterValueException
  | CommonErrors;
/**
 * Returns the number of resources that are compliant and the
 * number that are noncompliant. You can specify one or more resource
 * types to get these numbers for each resource type. The maximum
 * number returned is 100.
 */
export const getComplianceSummaryByResourceType: API.OperationMethod<
  GetComplianceSummaryByResourceTypeRequest,
  GetComplianceSummaryByResourceTypeResponse,
  GetComplianceSummaryByResourceTypeError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: GetComplianceSummaryByResourceTypeRequest,
  output: GetComplianceSummaryByResourceTypeResponse,
  errors: [InvalidParameterValueException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetComplianceSummaryByResourceType",
}));

export type GetConformancePackComplianceDetailsError =
  | InvalidLimitException
  | InvalidNextTokenException
  | InvalidParameterValueException
  | NoSuchConfigRuleInConformancePackException
  | NoSuchConformancePackException
  | CommonErrors;
/**
 * Returns compliance details of a conformance pack for all Amazon Web Services resources that are monitered by conformance pack.
 */
export const getConformancePackComplianceDetails: API.PaginatedOperationMethod<
  GetConformancePackComplianceDetailsRequest,
  GetConformancePackComplianceDetailsResponse,
  GetConformancePackComplianceDetailsError,
  Credentials | HttpClient.HttpClient,
  unknown
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: GetConformancePackComplianceDetailsRequest,
  output: GetConformancePackComplianceDetailsResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    InvalidParameterValueException,
    NoSuchConfigRuleInConformancePackException,
    NoSuchConformancePackException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetConformancePackComplianceDetails",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    pageSize: "Limit",
  } as const,
})) as any;

export type GetConformancePackComplianceSummaryError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchConformancePackException
  | CommonErrors;
/**
 * Returns compliance details for the conformance pack based on the cumulative compliance results of all the rules in that conformance pack.
 */
export const getConformancePackComplianceSummary: API.PaginatedOperationMethod<
  GetConformancePackComplianceSummaryRequest,
  GetConformancePackComplianceSummaryResponse,
  GetConformancePackComplianceSummaryError,
  Credentials | HttpClient.HttpClient,
  ConformancePackComplianceSummary
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: GetConformancePackComplianceSummaryRequest,
  output: GetConformancePackComplianceSummaryResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchConformancePackException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetConformancePackComplianceSummary",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "ConformancePackComplianceSummaryList",
    pageSize: "Limit",
  } as const,
})) as any;

export type GetConnectorError =
  | ResourceNotFoundException
  | ValidationException
  | CommonErrors;
/**
 * Returns the details of the specified connector.
 */
export const getConnector: API.OperationMethod<
  GetConnectorRequest,
  GetConnectorResponse,
  GetConnectorError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: GetConnectorRequest,
  output: GetConnectorResponse,
  errors: [ResourceNotFoundException, ValidationException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetConnector",
}));

export type GetCustomRulePolicyError = NoSuchConfigRuleException | CommonErrors;
/**
 * Returns the policy definition containing the logic for your Config Custom Policy rule.
 */
export const getCustomRulePolicy: API.OperationMethod<
  GetCustomRulePolicyRequest,
  GetCustomRulePolicyResponse,
  GetCustomRulePolicyError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: GetCustomRulePolicyRequest,
  output: GetCustomRulePolicyResponse,
  errors: [NoSuchConfigRuleException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetCustomRulePolicy",
}));

export type GetDiscoveredResourceCountsError =
  | InvalidLimitException
  | InvalidNextTokenException
  | ValidationException
  | CommonErrors;
/**
 * Returns the resource types, the number of each resource type,
 * and the total number of resources that Config is recording in
 * this region for your Amazon Web Services account.
 *
 * **Example**
 *
 * - Config is recording three resource types in the US
 * East (Ohio) Region for your account: 25 EC2 instances, 20
 * IAM users, and 15 S3 buckets.
 *
 * - You make a call to the
 * `GetDiscoveredResourceCounts` action and
 * specify that you want all resource types.
 *
 * - Config returns the following:
 *
 * - The resource types (EC2 instances, IAM users,
 * and S3 buckets).
 *
 * - The number of each resource type (25, 20, and
 * 15).
 *
 * - The total number of all resources
 * (60).
 *
 * The response is paginated. By default, Config lists 100
 * ResourceCount objects on each page. You can
 * customize this number with the `limit` parameter. The
 * response includes a `nextToken` string. To get the next
 * page of results, run the request again and specify the string for
 * the `nextToken` parameter.
 *
 * If you make a call to the GetDiscoveredResourceCounts action, you might
 * not immediately receive resource counts in the following
 * situations:
 *
 * - You are a new Config customer.
 *
 * - You just enabled resource recording.
 *
 * It might take a few minutes for Config to record and
 * count your resources. Wait a few minutes and then retry the
 * GetDiscoveredResourceCounts action.
 */
export const getDiscoveredResourceCounts: API.PaginatedOperationMethod<
  GetDiscoveredResourceCountsRequest,
  GetDiscoveredResourceCountsResponse,
  GetDiscoveredResourceCountsError,
  Credentials | HttpClient.HttpClient,
  unknown
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: GetDiscoveredResourceCountsRequest,
  output: GetDiscoveredResourceCountsResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetDiscoveredResourceCounts",
  pagination: {
    inputToken: "nextToken",
    outputToken: "nextToken",
    pageSize: "limit",
  } as const,
})) as any;

export type GetOrganizationConfigRuleDetailedStatusError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchOrganizationConfigRuleException
  | OrganizationAccessDeniedException
  | CommonErrors;
/**
 * Returns detailed status for each member account within an organization for a given organization Config rule.
 */
export const getOrganizationConfigRuleDetailedStatus: API.PaginatedOperationMethod<
  GetOrganizationConfigRuleDetailedStatusRequest,
  GetOrganizationConfigRuleDetailedStatusResponse,
  GetOrganizationConfigRuleDetailedStatusError,
  Credentials | HttpClient.HttpClient,
  MemberAccountStatus
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: GetOrganizationConfigRuleDetailedStatusRequest,
  output: GetOrganizationConfigRuleDetailedStatusResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchOrganizationConfigRuleException,
    OrganizationAccessDeniedException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetOrganizationConfigRuleDetailedStatus",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "OrganizationConfigRuleDetailedStatus",
    pageSize: "Limit",
  } as const,
})) as any;

export type GetOrganizationConformancePackDetailedStatusError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchOrganizationConformancePackException
  | OrganizationAccessDeniedException
  | CommonErrors;
/**
 * Returns detailed status for each member account within an organization for a given organization conformance pack.
 */
export const getOrganizationConformancePackDetailedStatus: API.PaginatedOperationMethod<
  GetOrganizationConformancePackDetailedStatusRequest,
  GetOrganizationConformancePackDetailedStatusResponse,
  GetOrganizationConformancePackDetailedStatusError,
  Credentials | HttpClient.HttpClient,
  OrganizationConformancePackDetailedStatus
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: GetOrganizationConformancePackDetailedStatusRequest,
  output: GetOrganizationConformancePackDetailedStatusResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchOrganizationConformancePackException,
    OrganizationAccessDeniedException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetOrganizationConformancePackDetailedStatus",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "OrganizationConformancePackDetailedStatuses",
    pageSize: "Limit",
  } as const,
})) as any;

export type GetOrganizationCustomRulePolicyError =
  | NoSuchOrganizationConfigRuleException
  | OrganizationAccessDeniedException
  | CommonErrors;
/**
 * Returns the policy definition containing the logic for your organization Config Custom Policy rule.
 */
export const getOrganizationCustomRulePolicy: API.OperationMethod<
  GetOrganizationCustomRulePolicyRequest,
  GetOrganizationCustomRulePolicyResponse,
  GetOrganizationCustomRulePolicyError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: GetOrganizationCustomRulePolicyRequest,
  output: GetOrganizationCustomRulePolicyResponse,
  errors: [
    NoSuchOrganizationConfigRuleException,
    OrganizationAccessDeniedException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetOrganizationCustomRulePolicy",
}));

export type GetResourceConfigHistoryError =
  | InvalidLimitException
  | InvalidNextTokenException
  | InvalidTimeRangeException
  | NoAvailableConfigurationRecorderException
  | ResourceNotDiscoveredException
  | ValidationException
  | CommonErrors;
/**
 * For accurate reporting on the compliance status, you must record the `AWS::Config::ResourceCompliance` resource type.
 *
 * For more information, see Recording Amazon Web Services Resources in the *Config Resources Developer Guide*.
 *
 * Returns a list of configurations items (CIs) for the specified resource.
 *
 * **Contents**
 *
 * The list contains details about each state of the resource
 * during the specified time interval. If you specified a retention
 * period to retain your CIs between a
 * minimum of 30 days and a maximum of 7 years (2557 days), Config
 * returns the CIs for the specified
 * retention period.
 *
 * **Pagination**
 *
 * The response is paginated. By default, Config returns a
 * limit of 10 configuration items per page. You can customize this
 * number with the `limit` parameter. The response includes
 * a `nextToken` string. To get the next page of results,
 * run the request again and specify the string for the
 * `nextToken` parameter.
 *
 * Each call to the API is limited to span a duration of seven
 * days. It is likely that the number of records returned is
 * smaller than the specified `limit`. In such cases,
 * you can make another call, using the
 * `nextToken`.
 */
export const getResourceConfigHistory: API.PaginatedOperationMethod<
  GetResourceConfigHistoryRequest,
  GetResourceConfigHistoryResponse,
  GetResourceConfigHistoryError,
  Credentials | HttpClient.HttpClient,
  ConfigurationItem
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: GetResourceConfigHistoryRequest,
  output: GetResourceConfigHistoryResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    InvalidTimeRangeException,
    NoAvailableConfigurationRecorderException,
    ResourceNotDiscoveredException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetResourceConfigHistory",
  pagination: {
    inputToken: "nextToken",
    outputToken: "nextToken",
    items: "configurationItems",
    pageSize: "limit",
  } as const,
})) as any;

export type GetResourceEvaluationSummaryError =
  | ResourceNotFoundException
  | CommonErrors;
/**
 * Returns a summary of resource evaluation for the specified resource evaluation ID from the proactive rules that were run.
 * The results indicate which evaluation context was used to evaluate the rules, which resource details were evaluated,
 * the evaluation mode that was run, and whether the resource details comply with the configuration of the proactive rules.
 *
 * To see additional information about the evaluation result, such as which rule flagged a resource as NON_COMPLIANT, use the GetComplianceDetailsByResource API.
 * For more information, see the Examples section.
 */
export const getResourceEvaluationSummary: API.OperationMethod<
  GetResourceEvaluationSummaryRequest,
  GetResourceEvaluationSummaryResponse,
  GetResourceEvaluationSummaryError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: GetResourceEvaluationSummaryRequest,
  output: GetResourceEvaluationSummaryResponse,
  errors: [ResourceNotFoundException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetResourceEvaluationSummary",
}));

export type GetStoredQueryError =
  | ResourceNotFoundException
  | ValidationException
  | CommonErrors;
/**
 * Returns the details of a specific stored query.
 */
export const getStoredQuery: API.OperationMethod<
  GetStoredQueryRequest,
  GetStoredQueryResponse,
  GetStoredQueryError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: GetStoredQueryRequest,
  output: GetStoredQueryResponse,
  errors: [ResourceNotFoundException, ValidationException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "GetStoredQuery",
}));

export type ListAggregateDiscoveredResourcesError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchConfigurationAggregatorException
  | ValidationException
  | CommonErrors;
/**
 * Accepts a resource type and returns a list of resource identifiers that are aggregated for a specific resource type across accounts and regions.
 * A resource identifier includes the resource type, ID, (if available) the custom resource name, source account, and source region.
 * You can narrow the results to include only resources that have specific resource IDs, or a resource name, or source account ID, or source region.
 *
 * For example, if the input consists of accountID 12345678910 and the region is us-east-1 for resource type `AWS::EC2::Instance` then the API returns all the EC2 instance identifiers of accountID 12345678910 and region us-east-1.
 */
export const listAggregateDiscoveredResources: API.PaginatedOperationMethod<
  ListAggregateDiscoveredResourcesRequest,
  ListAggregateDiscoveredResourcesResponse,
  ListAggregateDiscoveredResourcesError,
  Credentials | HttpClient.HttpClient,
  AggregateResourceIdentifier
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: ListAggregateDiscoveredResourcesRequest,
  output: ListAggregateDiscoveredResourcesResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchConfigurationAggregatorException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "ListAggregateDiscoveredResources",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "ResourceIdentifiers",
    pageSize: "Limit",
  } as const,
})) as any;

export type ListConfigurationRecordersError =
  | ValidationException
  | CommonErrors;
/**
 * Returns a list of configuration recorders depending on the filters you specify.
 */
export const listConfigurationRecorders: API.PaginatedOperationMethod<
  ListConfigurationRecordersRequest,
  ListConfigurationRecordersResponse,
  ListConfigurationRecordersError,
  Credentials | HttpClient.HttpClient,
  ConfigurationRecorderSummary
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: ListConfigurationRecordersRequest,
  output: ListConfigurationRecordersResponse,
  errors: [ValidationException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "ListConfigurationRecorders",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "ConfigurationRecorderSummaries",
    pageSize: "MaxResults",
  } as const,
})) as any;

export type ListConformancePackComplianceScoresError =
  | InvalidLimitException
  | InvalidNextTokenException
  | InvalidParameterValueException
  | CommonErrors;
/**
 * Returns a list of conformance pack compliance scores.
 * A compliance score is the percentage of the number of compliant rule-resource combinations in a conformance pack compared to the number of total possible rule-resource combinations in the conformance pack.
 * This metric provides you with a high-level view of the compliance state of your conformance packs. You can use it to identify, investigate, and understand
 * the level of compliance in your conformance packs.
 *
 * Conformance packs with no evaluation results will have a compliance score of `INSUFFICIENT_DATA`.
 */
export const listConformancePackComplianceScores: API.PaginatedOperationMethod<
  ListConformancePackComplianceScoresRequest,
  ListConformancePackComplianceScoresResponse,
  ListConformancePackComplianceScoresError,
  Credentials | HttpClient.HttpClient,
  unknown
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: ListConformancePackComplianceScoresRequest,
  output: ListConformancePackComplianceScoresResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    InvalidParameterValueException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "ListConformancePackComplianceScores",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    pageSize: "Limit",
  } as const,
})) as any;

export type ListConnectorsError = ValidationException | CommonErrors;
/**
 * Returns a list of connectors depending on the filters you specify.
 */
export const listConnectors: API.PaginatedOperationMethod<
  ListConnectorsRequest,
  ListConnectorsResponse,
  ListConnectorsError,
  Credentials | HttpClient.HttpClient,
  ConnectorSummary
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: ListConnectorsRequest,
  output: ListConnectorsResponse,
  errors: [ValidationException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "ListConnectors",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "ConnectorSummaries",
    pageSize: "MaxResults",
  } as const,
})) as any;

export type ListDiscoveredResourcesError =
  | InvalidLimitException
  | InvalidNextTokenException
  | NoAvailableConfigurationRecorderException
  | ValidationException
  | CommonErrors;
/**
 * Returns a list of resource
 * resource identifiers for the specified resource types for the resources of that type. A *resource identifier*
 * includes the resource type, ID, and (if available) the custom
 * resource name.
 *
 * The results consist of resources that Config has
 * *discovered*, including those that Config is not currently
 * recording. You can narrow the results to include only resources that
 * have specific resource IDs or a resource name.
 *
 * You can specify either resource IDs or a resource name, but
 * not both, in the same request.
 *
 * *CloudFormation stack recording behavior in Config*
 *
 * When a CloudFormation stack fails to create (for example, it enters the `ROLLBACK_FAILED` state),
 * Config does not record a configuration item (CI) for that stack. Configuration items are only recorded for stacks that reach
 * the following states:
 *
 * - `CREATE_COMPLETE`
 *
 * - `UPDATE_COMPLETE`
 *
 * - `UPDATE_ROLLBACK_COMPLETE`
 *
 * - `UPDATE_ROLLBACK_FAILED`
 *
 * - `DELETE_FAILED`
 *
 * - `DELETE_COMPLETE`
 *
 * Because no CI is created for a failed stack creation, you won't see configuration history
 * for that stack in Config, even after the stack is deleted. This helps make sure that Config only
 * tracks resources that were successfully provisioned.
 */
export const listDiscoveredResources: API.PaginatedOperationMethod<
  ListDiscoveredResourcesRequest,
  ListDiscoveredResourcesResponse,
  ListDiscoveredResourcesError,
  Credentials | HttpClient.HttpClient,
  ResourceIdentifier
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: ListDiscoveredResourcesRequest,
  output: ListDiscoveredResourcesResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    NoAvailableConfigurationRecorderException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "ListDiscoveredResources",
  pagination: {
    inputToken: "nextToken",
    outputToken: "nextToken",
    items: "resourceIdentifiers",
    pageSize: "limit",
  } as const,
})) as any;

export type ListResourceEvaluationsError =
  | InvalidNextTokenException
  | InvalidParameterValueException
  | InvalidTimeRangeException
  | CommonErrors;
/**
 * Returns a list of proactive resource evaluations.
 */
export const listResourceEvaluations: API.PaginatedOperationMethod<
  ListResourceEvaluationsRequest,
  ListResourceEvaluationsResponse,
  ListResourceEvaluationsError,
  Credentials | HttpClient.HttpClient,
  ResourceEvaluation
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: ListResourceEvaluationsRequest,
  output: ListResourceEvaluationsResponse,
  errors: [
    InvalidNextTokenException,
    InvalidParameterValueException,
    InvalidTimeRangeException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "ListResourceEvaluations",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "ResourceEvaluations",
    pageSize: "Limit",
  } as const,
})) as any;

export type ListStoredQueriesError =
  | InvalidNextTokenException
  | ValidationException
  | CommonErrors;
/**
 * Lists the stored queries for a single Amazon Web Services account and a single Amazon Web Services Region. The default is 100.
 */
export const listStoredQueries: API.PaginatedOperationMethod<
  ListStoredQueriesRequest,
  ListStoredQueriesResponse,
  ListStoredQueriesError,
  Credentials | HttpClient.HttpClient,
  unknown
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: ListStoredQueriesRequest,
  output: ListStoredQueriesResponse,
  errors: [InvalidNextTokenException, ValidationException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "ListStoredQueries",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    pageSize: "MaxResults",
  } as const,
})) as any;

export type ListTagsForResourceError =
  | InvalidLimitException
  | InvalidNextTokenException
  | ResourceNotFoundException
  | ValidationException
  | CommonErrors;
/**
 * List the tags for Config resource.
 */
export const listTagsForResource: API.PaginatedOperationMethod<
  ListTagsForResourceRequest,
  ListTagsForResourceResponse,
  ListTagsForResourceError,
  Credentials | HttpClient.HttpClient,
  Tag
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: ListTagsForResourceRequest,
  output: ListTagsForResourceResponse,
  errors: [
    InvalidLimitException,
    InvalidNextTokenException,
    ResourceNotFoundException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "ListTagsForResource",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "Tags",
    pageSize: "Limit",
  } as const,
})) as any;

export type PutAggregationAuthorizationError =
  | InvalidParameterValueException
  | CommonErrors;
/**
 * Authorizes the aggregator account and region to collect data
 * from the source account and region.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * `PutAggregationAuthorization` is an idempotent API. Subsequent requests won’t create a duplicate resource if one was already created. If a following request has different `tags` values,
 * Config will ignore these differences and treat it as an idempotent request of the previous. In this case, `tags` will not be updated, even if they are different.
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export const putAggregationAuthorization: API.OperationMethod<
  PutAggregationAuthorizationRequest,
  PutAggregationAuthorizationResponse,
  PutAggregationAuthorizationError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutAggregationAuthorizationRequest,
  output: PutAggregationAuthorizationResponse,
  errors: [InvalidParameterValueException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutAggregationAuthorization",
}));

export type PutConfigRuleError =
  | InsufficientPermissionsException
  | InvalidParameterValueException
  | MaxNumberOfConfigRulesExceededException
  | NoAvailableConfigurationRecorderException
  | ResourceInUseException
  | CommonErrors;
/**
 * Adds or updates an Config rule to evaluate if your
 * Amazon Web Services resources comply with your desired configurations. For information on how many Config rules you can have per account,
 * see
 * **Service Limits**
 * in the *Config Developer Guide*.
 *
 * There are two types of rules: *Config Managed Rules* and *Config Custom Rules*.
 * You can use `PutConfigRule` to create both Config Managed Rules and Config Custom Rules.
 *
 * Config Managed Rules are predefined,
 * customizable rules created by Config. For a list of managed rules, see
 * List of Config
 * Managed Rules. If you are adding an Config managed rule, you must specify the
 * rule's identifier for the `SourceIdentifier` key.
 *
 * Config Custom Rules are rules that you create from scratch. There are two ways to create Config custom rules: with Lambda functions
 * ( Lambda Developer Guide) and with Guard (Guard GitHub
 * Repository), a policy-as-code language.
 *
 * Config custom rules created with Lambda
 * are called *Config Custom Lambda Rules* and Config custom rules created with
 * Guard are called *Config Custom Policy Rules*.
 *
 * If you are adding a new Config Custom Lambda rule,
 * you first need to create an Lambda function that the rule invokes to evaluate
 * your resources. When you use `PutConfigRule` to add a Custom Lambda rule to Config, you must specify the Amazon Resource
 * Name (ARN) that Lambda assigns to the function. You specify the ARN
 * in the `SourceIdentifier` key. This key is part of the
 * `Source` object, which is part of the
 * `ConfigRule` object.
 *
 * For any new Config rule that you add, specify the
 * `ConfigRuleName` in the `ConfigRule`
 * object. Do not specify the `ConfigRuleArn` or the
 * `ConfigRuleId`. These values are generated by Config for new rules.
 *
 * If you are updating a rule that you added previously, you can
 * specify the rule by `ConfigRuleName`,
 * `ConfigRuleId`, or `ConfigRuleArn` in the
 * `ConfigRule` data type that you use in this
 * request.
 *
 * For more information about developing and using Config
 * rules, see Evaluating Resources with Config Rules
 * in the *Config Developer Guide*.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * `PutConfigRule` is an idempotent API. Subsequent requests won’t create a duplicate resource if one was already created. If a following request has different `tags` values,
 * Config will ignore these differences and treat it as an idempotent request of the previous. In this case, `tags` will not be updated, even if they are different.
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export const putConfigRule: API.OperationMethod<
  PutConfigRuleRequest,
  PutConfigRuleResponse,
  PutConfigRuleError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutConfigRuleRequest,
  output: PutConfigRuleResponse,
  errors: [
    InsufficientPermissionsException,
    InvalidParameterValueException,
    MaxNumberOfConfigRulesExceededException,
    NoAvailableConfigurationRecorderException,
    ResourceInUseException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutConfigRule",
}));

export type PutConfigurationAggregatorError =
  | InvalidParameterValueException
  | InvalidRoleException
  | LimitExceededException
  | NoAvailableOrganizationException
  | OrganizationAccessDeniedException
  | OrganizationAllFeaturesNotEnabledException
  | CommonErrors;
/**
 * Creates and updates the configuration aggregator with the
 * selected source accounts and regions. The source account can be
 * individual account(s) or an organization.
 *
 * `accountIds` that are passed will be replaced with existing accounts.
 * If you want to add additional accounts into the aggregator, call `DescribeConfigurationAggregators` to get the previous accounts and then append new ones.
 *
 * Config should be enabled in source accounts and regions
 * you want to aggregate.
 *
 * If your source type is an organization, you must be signed in to the management account or a registered delegated administrator and all the features must be enabled in your organization.
 * If the caller is a management account, Config calls `EnableAwsServiceAccess` API to enable integration between Config and Organizations.
 * If the caller is a registered delegated administrator, Config calls `ListDelegatedAdministrators` API to verify whether the caller is a valid delegated administrator.
 *
 * To register a delegated administrator, see Register a Delegated Administrator in the *Config developer guide*.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * `PutConfigurationAggregator` is an idempotent API. Subsequent requests won’t create a duplicate resource if one was already created. If a following request has different `tags` values,
 * Config will ignore these differences and treat it as an idempotent request of the previous. In this case, `tags` will not be updated, even if they are different.
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export const putConfigurationAggregator: API.OperationMethod<
  PutConfigurationAggregatorRequest,
  PutConfigurationAggregatorResponse,
  PutConfigurationAggregatorError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutConfigurationAggregatorRequest,
  output: PutConfigurationAggregatorResponse,
  errors: [
    InvalidParameterValueException,
    InvalidRoleException,
    LimitExceededException,
    NoAvailableOrganizationException,
    OrganizationAccessDeniedException,
    OrganizationAllFeaturesNotEnabledException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutConfigurationAggregator",
}));

export type PutConfigurationRecorderError =
  | InvalidConfigurationRecorderNameException
  | InvalidRecordingGroupException
  | InvalidRoleException
  | MaxNumberOfConfigurationRecordersExceededException
  | UnmodifiableEntityException
  | ValidationException
  | CommonErrors;
/**
 * Creates or updates the customer managed configuration recorder.
 *
 * You can use this operation to create a new customer managed configuration recorder or to update the `roleARN` and the `recordingGroup` for an existing customer managed configuration recorder.
 *
 * To start the customer managed configuration recorder and begin recording configuration changes for the resource types you specify,
 * use the StartConfigurationRecorder operation.
 *
 * For more information, see
 * **Working with the Configuration Recorder**
 * in the *Config Developer Guide*.
 *
 * **One customer managed configuration recorder per account per Region**
 *
 * You can create only one customer managed configuration recorder for each account for each Amazon Web Services Region.
 *
 * **Default is to record all supported resource types, excluding the global IAM resource types**
 *
 * If you have not specified values for the `recordingGroup` field, the default for the customer managed configuration recorder is to record all supported resource
 * types, excluding the global IAM resource types: `AWS::IAM::Group`, `AWS::IAM::Policy`, `AWS::IAM::Role`, and `AWS::IAM::User`.
 *
 * **Tags are added at creation and cannot be updated**
 *
 * `PutConfigurationRecorder` is an idempotent API. Subsequent requests won’t create a duplicate resource if one was already created. If a following request has different tags values,
 * Config will ignore these differences and treat it as an idempotent request of the previous. In this case, tags will not be updated, even if they are different.
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export const putConfigurationRecorder: API.OperationMethod<
  PutConfigurationRecorderRequest,
  PutConfigurationRecorderResponse,
  PutConfigurationRecorderError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutConfigurationRecorderRequest,
  output: PutConfigurationRecorderResponse,
  errors: [
    InvalidConfigurationRecorderNameException,
    InvalidRecordingGroupException,
    InvalidRoleException,
    MaxNumberOfConfigurationRecordersExceededException,
    UnmodifiableEntityException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutConfigurationRecorder",
}));

export type PutConformancePackError =
  | ConformancePackTemplateValidationException
  | InsufficientPermissionsException
  | InvalidParameterValueException
  | MaxNumberOfConformancePacksExceededException
  | ResourceInUseException
  | CommonErrors;
/**
 * Creates or updates a conformance pack. A conformance pack is a collection of Config rules that can be easily deployed in an account and a region and across an organization.
 * For information on how many conformance packs you can have per account,
 * see
 * **Service Limits**
 * in the *Config Developer Guide*.
 *
 * When you use `PutConformancePack` to deploy conformance packs in your account,
 * the operation can create Config rules and remediation actions without
 * requiring `config:PutConfigRule` or
 * `config:PutRemediationConfigurations` permissions in your account IAM
 * policies.
 *
 * This API uses the `AWSServiceRoleForConfigConforms` service-linked role in your
 * account to create conformance pack resources. This service-linked role includes the
 * permissions to create Config rules and remediation configurations, even
 * if your account IAM policies explicitly deny these actions.
 *
 * This API creates a service-linked role `AWSServiceRoleForConfigConforms` in your account.
 * The service-linked role is created only when the role does not exist in your account.
 *
 * You must specify only one of the follow parameters: `TemplateS3Uri`, `TemplateBody` or `TemplateSSMDocumentDetails`.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * `PutConformancePack` is an idempotent API. Subsequent requests won't create a duplicate resource if one was already created. If a following request has different `tags` values,
 * Config will ignore these differences and treat it as an idempotent request of the previous. In this case, `tags` will not be updated, even if they are different.
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export const putConformancePack: API.OperationMethod<
  PutConformancePackRequest,
  PutConformancePackResponse,
  PutConformancePackError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutConformancePackRequest,
  output: PutConformancePackResponse,
  errors: [
    ConformancePackTemplateValidationException,
    InsufficientPermissionsException,
    InvalidParameterValueException,
    MaxNumberOfConformancePacksExceededException,
    ResourceInUseException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutConformancePack",
}));

export type PutConnectorError =
  | ConflictException
  | InsufficientPermissionsException
  | MaxNumberOfConnectorsExceededException
  | ValidationException
  | CommonErrors;
/**
 * Creates a connector that specifies the connection between a third-party cloud service provider and Config.
 *
 * A connector is required to create a service-linked configuration recorder for a third-party cloud service provider using the PutThirdPartyServiceLinkedConfigurationRecorder operation.
 *
 * This API creates a service-linked role `AWSServiceRoleForConfigThirdParty` in your account. The service-linked role is created only when the role does not exist in your account.
 *
 * **Connectors cannot be updated**
 *
 * To update the connector configuration, you must delete all associated configuration recorders, delete the connector, and recreate it with the updated configuration.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export const putConnector: API.OperationMethod<
  PutConnectorRequest,
  PutConnectorResponse,
  PutConnectorError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutConnectorRequest,
  output: PutConnectorResponse,
  errors: [
    ConflictException,
    InsufficientPermissionsException,
    MaxNumberOfConnectorsExceededException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutConnector",
}));

export type PutDeliveryChannelError =
  | InsufficientDeliveryPolicyException
  | InvalidDeliveryChannelNameException
  | InvalidS3KeyPrefixException
  | InvalidS3KmsKeyArnException
  | InvalidSNSTopicARNException
  | MaxNumberOfDeliveryChannelsExceededException
  | NoAvailableConfigurationRecorderException
  | NoSuchBucketException
  | CommonErrors;
/**
 * Creates or updates a delivery channel to deliver configuration
 * information and other compliance information.
 *
 * You can use this operation to create a new delivery channel or to update the Amazon S3 bucket and the
 * Amazon SNS topic of an existing delivery channel.
 *
 * For more information, see
 * **Working with the Delivery Channel**
 * in the *Config Developer Guide.*
 *
 * **One delivery channel per account per Region**
 *
 * You can have only one delivery channel for each account for each Amazon Web Services Region.
 */
export const putDeliveryChannel: API.OperationMethod<
  PutDeliveryChannelRequest,
  PutDeliveryChannelResponse,
  PutDeliveryChannelError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutDeliveryChannelRequest,
  output: PutDeliveryChannelResponse,
  errors: [
    InsufficientDeliveryPolicyException,
    InvalidDeliveryChannelNameException,
    InvalidS3KeyPrefixException,
    InvalidS3KmsKeyArnException,
    InvalidSNSTopicARNException,
    MaxNumberOfDeliveryChannelsExceededException,
    NoAvailableConfigurationRecorderException,
    NoSuchBucketException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutDeliveryChannel",
}));

export type PutEvaluationsError =
  | InvalidParameterValueException
  | InvalidResultTokenException
  | NoSuchConfigRuleException
  | CommonErrors;
/**
 * Used by an Lambda function to deliver evaluation results to
 * Config. This operation is required in every Lambda function
 * that is invoked by an Config rule.
 */
export const putEvaluations: API.OperationMethod<
  PutEvaluationsRequest,
  PutEvaluationsResponse,
  PutEvaluationsError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutEvaluationsRequest,
  output: PutEvaluationsResponse,
  errors: [
    InvalidParameterValueException,
    InvalidResultTokenException,
    NoSuchConfigRuleException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutEvaluations",
}));

export type PutExternalEvaluationError =
  | InvalidParameterValueException
  | NoSuchConfigRuleException
  | CommonErrors;
/**
 * Add or updates the evaluations for process checks.
 * This API checks if the rule is a process check when the name of the Config rule is provided.
 */
export const putExternalEvaluation: API.OperationMethod<
  PutExternalEvaluationRequest,
  PutExternalEvaluationResponse,
  PutExternalEvaluationError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutExternalEvaluationRequest,
  output: PutExternalEvaluationResponse,
  errors: [InvalidParameterValueException, NoSuchConfigRuleException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutExternalEvaluation",
}));

export type PutOrganizationConfigRuleError =
  | InsufficientPermissionsException
  | InvalidParameterValueException
  | MaxNumberOfOrganizationConfigRulesExceededException
  | NoAvailableOrganizationException
  | OrganizationAccessDeniedException
  | OrganizationAllFeaturesNotEnabledException
  | ResourceInUseException
  | ValidationException
  | CommonErrors;
/**
 * Adds or updates an Config rule for your entire organization to evaluate if your Amazon Web Services resources comply with your
 * desired configurations. For information on how many organization Config rules you can have per account,
 * see
 * **Service Limits**
 * in the *Config Developer Guide*.
 *
 * Only a management account and a delegated administrator can create or update an organization Config rule.
 * When calling this API with a delegated administrator, you must ensure Organizations
 * `ListDelegatedAdministrator` permissions are added. An organization can have up to 3 delegated administrators.
 *
 * This API enables organization service access through the `EnableAWSServiceAccess` action and creates a service-linked
 * role `AWSServiceRoleForConfigMultiAccountSetup` in the management or delegated administrator account of your organization.
 * The service-linked role is created only when the role does not exist in the caller account.
 * Config verifies the existence of role with `GetRole` action.
 *
 * To use this API with delegated administrator, register a delegated administrator by calling Amazon Web Services Organization
 * `register-delegated-administrator` for `config-multiaccountsetup.amazonaws.com`.
 *
 * There are two types of rules: *Config Managed Rules* and *Config Custom Rules*.
 * You can use `PutOrganizationConfigRule` to create both Config Managed Rules and Config Custom Rules.
 *
 * Config Managed Rules are predefined,
 * customizable rules created by Config. For a list of managed rules, see
 * List of Config
 * Managed Rules. If you are adding an Config managed rule, you must specify the rule's identifier for the `RuleIdentifier` key.
 *
 * Config Custom Rules are rules that you create from scratch. There are two ways to create Config custom rules: with Lambda functions
 * ( Lambda Developer Guide) and with Guard (Guard GitHub
 * Repository), a policy-as-code language.
 *
 * Config custom rules created with Lambda
 * are called *Config Custom Lambda Rules* and Config custom rules created with
 * Guard are called *Config Custom Policy Rules*.
 *
 * If you are adding a new Config Custom Lambda rule, you first need to create an Lambda function in the management account or a delegated
 * administrator that the rule invokes to evaluate your resources. You also need to create an IAM role in the managed account that can be assumed by the Lambda function.
 * When you use `PutOrganizationConfigRule` to add a Custom Lambda rule to Config, you must
 * specify the Amazon Resource Name (ARN) that Lambda assigns to the function.
 *
 * Prerequisite: Ensure you call `EnableAllFeatures` API to enable all features in an organization.
 *
 * Make sure to specify one of either `OrganizationCustomPolicyRuleMetadata` for Custom Policy rules, `OrganizationCustomRuleMetadata` for Custom Lambda rules, or `OrganizationManagedRuleMetadata` for managed rules.
 */
export const putOrganizationConfigRule: API.OperationMethod<
  PutOrganizationConfigRuleRequest,
  PutOrganizationConfigRuleResponse,
  PutOrganizationConfigRuleError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutOrganizationConfigRuleRequest,
  output: PutOrganizationConfigRuleResponse,
  errors: [
    InsufficientPermissionsException,
    InvalidParameterValueException,
    MaxNumberOfOrganizationConfigRulesExceededException,
    NoAvailableOrganizationException,
    OrganizationAccessDeniedException,
    OrganizationAllFeaturesNotEnabledException,
    ResourceInUseException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutOrganizationConfigRule",
}));

export type PutOrganizationConformancePackError =
  | InsufficientPermissionsException
  | MaxNumberOfOrganizationConformancePacksExceededException
  | NoAvailableOrganizationException
  | OrganizationAccessDeniedException
  | OrganizationAllFeaturesNotEnabledException
  | OrganizationConformancePackTemplateValidationException
  | ResourceInUseException
  | ValidationException
  | CommonErrors;
/**
 * Deploys conformance packs across member accounts in an Amazon Web Services Organization. For information on how many organization conformance packs and how many Config rules you can have per account,
 * see
 * **Service Limits**
 * in the *Config Developer Guide*.
 *
 * Only a management account and a delegated administrator can call this API.
 * When calling this API with a delegated administrator, you must ensure Organizations
 * `ListDelegatedAdministrator` permissions are added. An organization can have up to 3 delegated administrators.
 *
 * When you use `PutOrganizationConformancePack` to deploy conformance packs across
 * member accounts, the operation can create Config rules and remediation
 * actions without requiring `config:PutConfigRule` or
 * `config:PutRemediationConfigurations` permissions in member account
 * IAM policies.
 *
 * This API uses the `AWSServiceRoleForConfigConforms` service-linked role in each
 * member account to create conformance pack resources. This service-linked role
 * includes the permissions to create Config rules and remediation
 * configurations, even if member account IAM policies explicitly deny these
 * actions.
 *
 * This API enables organization service access for `config-multiaccountsetup.amazonaws.com`
 * through the `EnableAWSServiceAccess` action and creates a
 * service-linked role `AWSServiceRoleForConfigMultiAccountSetup` in the management or delegated administrator account of your organization.
 * The service-linked role is created only when the role does not exist in the caller account.
 * To use this API with delegated administrator, register a delegated administrator by calling Amazon Web Services Organization
 * `register-delegate-admin` for `config-multiaccountsetup.amazonaws.com`.
 *
 * Prerequisite: Ensure you call `EnableAllFeatures` API to enable all features in an organization.
 *
 * You must specify either the `TemplateS3Uri` or the `TemplateBody` parameter, but not both.
 * If you provide both Config uses the `TemplateS3Uri` parameter and ignores the `TemplateBody` parameter.
 *
 * Config sets the state of a conformance pack to CREATE_IN_PROGRESS and UPDATE_IN_PROGRESS until the conformance pack is created or updated.
 * You cannot update a conformance pack while it is in this state.
 */
export const putOrganizationConformancePack: API.OperationMethod<
  PutOrganizationConformancePackRequest,
  PutOrganizationConformancePackResponse,
  PutOrganizationConformancePackError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutOrganizationConformancePackRequest,
  output: PutOrganizationConformancePackResponse,
  errors: [
    InsufficientPermissionsException,
    MaxNumberOfOrganizationConformancePacksExceededException,
    NoAvailableOrganizationException,
    OrganizationAccessDeniedException,
    OrganizationAllFeaturesNotEnabledException,
    OrganizationConformancePackTemplateValidationException,
    ResourceInUseException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutOrganizationConformancePack",
}));

export type PutRemediationConfigurationsError =
  | InsufficientPermissionsException
  | InvalidParameterValueException
  | CommonErrors;
/**
 * Adds or updates the remediation configuration with a specific Config rule with the
 * selected target or action.
 * The API creates the `RemediationConfiguration` object for the Config rule.
 * The Config rule must already exist for you to add a remediation configuration.
 * The target (SSM document) must exist and have permissions to use the target.
 *
 * **Be aware of backward incompatible changes**
 *
 * If you make backward incompatible changes to the SSM document,
 * you must call this again to ensure the remediations can run.
 *
 * This API does not support adding remediation configurations for service-linked Config Rules such as Organization Config rules,
 * the rules deployed by conformance packs, and rules deployed by Amazon Web Services Security Hub.
 *
 * **Required fields**
 *
 * For manual remediation configuration, you need to provide a value for `automationAssumeRole` or use a value in the `assumeRole`field to remediate your resources. The SSM automation document can use either as long as it maps to a valid parameter.
 *
 * However, for automatic remediation configuration, the only valid `assumeRole` field value is `AutomationAssumeRole` and you need to provide a value for `AutomationAssumeRole` to remediate your resources.
 *
 * **Auto remediation can be initiated even for compliant resources**
 *
 * If you enable auto remediation for a specific Config rule using the PutRemediationConfigurations API or the Config console,
 * it initiates the remediation process for all non-compliant resources for that specific rule.
 * The auto remediation process relies on the compliance data snapshot which is captured on a periodic basis.
 * Any non-compliant resource that is updated between the snapshot schedule will continue to be remediated based on the last known compliance data snapshot.
 *
 * This means that in some cases auto remediation can be initiated even for compliant resources, since the bootstrap processor uses a database that can have stale evaluation results based on the last known compliance data snapshot.
 */
export const putRemediationConfigurations: API.OperationMethod<
  PutRemediationConfigurationsRequest,
  PutRemediationConfigurationsResponse,
  PutRemediationConfigurationsError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutRemediationConfigurationsRequest,
  output: PutRemediationConfigurationsResponse,
  errors: [InsufficientPermissionsException, InvalidParameterValueException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutRemediationConfigurations",
}));

export type PutRemediationExceptionsError =
  | InsufficientPermissionsException
  | InvalidParameterValueException
  | CommonErrors;
/**
 * A remediation exception is when a specified resource is no longer considered for auto-remediation.
 * This API adds a new exception or updates an existing exception for a specified resource with a specified Config rule.
 *
 * **Exceptions block auto remediation**
 *
 * Config generates a remediation exception when a problem occurs running a remediation action for a specified resource.
 * Remediation exceptions blocks auto-remediation until the exception is cleared.
 *
 * **Manual remediation is recommended when placing an exception**
 *
 * When placing an exception on an Amazon Web Services resource, it is recommended that remediation is set as manual remediation until
 * the given Config rule for the specified resource evaluates the resource as `NON_COMPLIANT`.
 * Once the resource has been evaluated as `NON_COMPLIANT`, you can add remediation exceptions and change the remediation type back from Manual to Auto if you want to use auto-remediation.
 * Otherwise, using auto-remediation before a `NON_COMPLIANT` evaluation result can delete resources before the exception is applied.
 *
 * **Exceptions can only be performed on non-compliant resources**
 *
 * Placing an exception can only be performed on resources that are `NON_COMPLIANT`.
 * If you use this API for `COMPLIANT` resources or resources that are `NOT_APPLICABLE`, a remediation exception will not be generated.
 * For more information on the conditions that initiate the possible Config evaluation results,
 * see Concepts | Config Rules in the *Config Developer Guide*.
 *
 * **Exceptions cannot be placed on service-linked remediation actions**
 *
 * You cannot place an exception on service-linked remediation actions, such as remediation actions put by an organizational conformance pack.
 *
 * **Auto remediation can be initiated even for compliant resources**
 *
 * If you enable auto remediation for a specific Config rule using the PutRemediationConfigurations API or the Config console,
 * it initiates the remediation process for all non-compliant resources for that specific rule.
 * The auto remediation process relies on the compliance data snapshot which is captured on a periodic basis.
 * Any non-compliant resource that is updated between the snapshot schedule will continue to be remediated based on the last known compliance data snapshot.
 *
 * This means that in some cases auto remediation can be initiated even for compliant resources, since the bootstrap processor uses a database that can have stale evaluation results based on the last known compliance data snapshot.
 */
export const putRemediationExceptions: API.OperationMethod<
  PutRemediationExceptionsRequest,
  PutRemediationExceptionsResponse,
  PutRemediationExceptionsError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutRemediationExceptionsRequest,
  output: PutRemediationExceptionsResponse,
  errors: [InsufficientPermissionsException, InvalidParameterValueException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutRemediationExceptions",
}));

export type PutResourceConfigError =
  | InsufficientPermissionsException
  | MaxActiveResourcesExceededException
  | NoRunningConfigurationRecorderException
  | ValidationException
  | CommonErrors;
/**
 * Records the configuration state for the resource provided in the request.
 *
 * The configuration state of a resource is represented in Config as Configuration Items.
 * Once this API records the configuration item, you can retrieve the list of configuration items for the custom resource type using existing Config APIs.
 *
 * The custom resource type must be registered with CloudFormation. This API accepts the configuration item registered with CloudFormation.
 *
 * When you call this API, Config only stores configuration state of the resource provided in the request. This API does not change or remediate the configuration of the resource.
 *
 * Write-only schema properites are not recorded as part of the published configuration item.
 */
export const putResourceConfig: API.OperationMethod<
  PutResourceConfigRequest,
  PutResourceConfigResponse,
  PutResourceConfigError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutResourceConfigRequest,
  output: PutResourceConfigResponse,
  errors: [
    InsufficientPermissionsException,
    MaxActiveResourcesExceededException,
    NoRunningConfigurationRecorderException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutResourceConfig",
}));

export type PutRetentionConfigurationError =
  | InvalidParameterValueException
  | MaxNumberOfRetentionConfigurationsExceededException
  | CommonErrors;
/**
 * Creates and updates the retention configuration with details
 * about retention period (number of days) that Config stores your
 * historical information. The API creates the
 * `RetentionConfiguration` object and names the object
 * as **default**. When you have a
 * `RetentionConfiguration` object named **default**, calling the API modifies the
 * default object.
 *
 * Currently, Config supports only one retention
 * configuration per region in your account.
 */
export const putRetentionConfiguration: API.OperationMethod<
  PutRetentionConfigurationRequest,
  PutRetentionConfigurationResponse,
  PutRetentionConfigurationError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutRetentionConfigurationRequest,
  output: PutRetentionConfigurationResponse,
  errors: [
    InvalidParameterValueException,
    MaxNumberOfRetentionConfigurationsExceededException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutRetentionConfiguration",
}));

export type PutServiceLinkedConfigurationRecorderError =
  | ConflictException
  | InsufficientPermissionsException
  | LimitExceededException
  | ValidationException
  | CommonErrors;
/**
 * Creates a service-linked configuration recorder that is linked to a specific Amazon Web Services service based on the `ServicePrincipal` you specify.
 *
 * The configuration recorder's `name`, `recordingGroup`, `recordingMode`, and `recordingScope` is set by the service that is linked to the configuration recorder.
 *
 * For more information and a list of supported services/service principals, see
 * **Working with the Configuration Recorder**
 * in the *Config Developer Guide*.
 *
 * This API creates a service-linked role `AWSServiceRoleForConfig` in your account. The service-linked role is created only when the role does not exist in your account.
 *
 * **The recording scope determines if you receive configuration items**
 *
 * The recording scope is set by the service that is linked to the configuration recorder and determines whether you receive configuration items (CIs) in the delivery channel. If the recording scope is internal, you will not receive CIs in the delivery channel.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export const putServiceLinkedConfigurationRecorder: API.OperationMethod<
  PutServiceLinkedConfigurationRecorderRequest,
  PutServiceLinkedConfigurationRecorderResponse,
  PutServiceLinkedConfigurationRecorderError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutServiceLinkedConfigurationRecorderRequest,
  output: PutServiceLinkedConfigurationRecorderResponse,
  errors: [
    ConflictException,
    InsufficientPermissionsException,
    LimitExceededException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutServiceLinkedConfigurationRecorder",
}));

export type PutStoredQueryError =
  | ResourceConcurrentModificationException
  | TooManyTagsException
  | ValidationException
  | CommonErrors;
/**
 * Saves a new query or updates an existing saved query. The `QueryName` must be unique for a single Amazon Web Services account and a single Amazon Web Services Region.
 * You can create upto 300 queries in a single Amazon Web Services account and a single Amazon Web Services Region.
 *
 * **Tags are added at creation and cannot be updated**
 *
 * `PutStoredQuery` is an idempotent API. Subsequent requests won’t create a duplicate resource if one was already created. If a following request has different `tags` values,
 * Config will ignore these differences and treat it as an idempotent request of the previous. In this case, `tags` will not be updated, even if they are different.
 */
export const putStoredQuery: API.OperationMethod<
  PutStoredQueryRequest,
  PutStoredQueryResponse,
  PutStoredQueryError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutStoredQueryRequest,
  output: PutStoredQueryResponse,
  errors: [
    ResourceConcurrentModificationException,
    TooManyTagsException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutStoredQuery",
}));

export type PutThirdPartyServiceLinkedConfigurationRecorderError =
  | ConflictException
  | InsufficientPermissionsException
  | ValidationException
  | CommonErrors;
/**
 * Creates or updates a service-linked configuration recorder that is linked to a third-party cloud service provider based on the `ConnectorArn` you specify.
 *
 * The configuration recorder's `name`, `recordingGroup`, `recordingMode`, and `recordingScope` is set by the service that is linked to the configuration recorder.
 *
 * If a service-linked configuration recorder already exists for the specified service principal and connector, calling this operation again updates the `ScopeConfiguration`.
 *
 * **This operation can only be called by the Amazon Web Services service linked to the configuration recorder**
 *
 * Customers cannot call this operation directly. Only the linked Amazon Web Services service can create or update the service-linked configuration recorder.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export const putThirdPartyServiceLinkedConfigurationRecorder: API.OperationMethod<
  PutThirdPartyServiceLinkedConfigurationRecorderRequest,
  PutThirdPartyServiceLinkedConfigurationRecorderResponse,
  PutThirdPartyServiceLinkedConfigurationRecorderError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: PutThirdPartyServiceLinkedConfigurationRecorderRequest,
  output: PutThirdPartyServiceLinkedConfigurationRecorderResponse,
  errors: [
    ConflictException,
    InsufficientPermissionsException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "PutThirdPartyServiceLinkedConfigurationRecorder",
}));

export type SelectAggregateResourceConfigError =
  | InvalidExpressionException
  | InvalidLimitException
  | InvalidNextTokenException
  | NoSuchConfigurationAggregatorException
  | CommonErrors;
/**
 * Accepts a structured query language (SQL) SELECT command and an aggregator to query configuration state of Amazon Web Services resources across multiple accounts and regions,
 * performs the corresponding search, and returns resource configurations matching the properties.
 *
 * For more information about query components, see the
 *
 * **Query Components**
 * section in the *Config Developer Guide*.
 *
 * If you run an aggregation query (i.e., using `GROUP BY` or using aggregate functions such as `COUNT`; e.g., `SELECT resourceId, COUNT(*) WHERE resourceType = 'AWS::IAM::Role' GROUP BY resourceId`)
 * and do not specify the `MaxResults` or the `Limit` query parameters, the default page size is set to 500.
 *
 * If you run a non-aggregation query (i.e., not using `GROUP BY` or aggregate function; e.g., `SELECT * WHERE resourceType = 'AWS::IAM::Role'`)
 * and do not specify the `MaxResults` or the `Limit` query parameters, the default page size is set to 25.
 */
export const selectAggregateResourceConfig: API.PaginatedOperationMethod<
  SelectAggregateResourceConfigRequest,
  SelectAggregateResourceConfigResponse,
  SelectAggregateResourceConfigError,
  Credentials | HttpClient.HttpClient,
  string
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: SelectAggregateResourceConfigRequest,
  output: SelectAggregateResourceConfigResponse,
  errors: [
    InvalidExpressionException,
    InvalidLimitException,
    InvalidNextTokenException,
    NoSuchConfigurationAggregatorException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "SelectAggregateResourceConfig",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "Results",
    pageSize: "Limit",
  } as const,
})) as any;

export type SelectResourceConfigError =
  | InvalidExpressionException
  | InvalidLimitException
  | InvalidNextTokenException
  | CommonErrors;
/**
 * Accepts a structured query language (SQL) `SELECT` command, performs the corresponding search, and returns resource configurations matching the properties.
 *
 * For more information about query components, see the
 *
 * **Query Components**
 * section in the *Config Developer Guide*.
 */
export const selectResourceConfig: API.PaginatedOperationMethod<
  SelectResourceConfigRequest,
  SelectResourceConfigResponse,
  SelectResourceConfigError,
  Credentials | HttpClient.HttpClient,
  string
> = /*@__PURE__*/ API.makePaginated(() => ({
  input: SelectResourceConfigRequest,
  output: SelectResourceConfigResponse,
  errors: [
    InvalidExpressionException,
    InvalidLimitException,
    InvalidNextTokenException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "SelectResourceConfig",
  pagination: {
    inputToken: "NextToken",
    outputToken: "NextToken",
    items: "Results",
    pageSize: "Limit",
  } as const,
})) as any;

export type StartConfigRulesEvaluationError =
  | InvalidParameterValueException
  | LimitExceededException
  | NoSuchConfigRuleException
  | ResourceInUseException
  | CommonErrors;
/**
 * Runs an on-demand evaluation for the specified Config rules
 * against the last known configuration state of the resources. Use
 * `StartConfigRulesEvaluation` when you want to test
 * that a rule you updated is working as expected.
 * `StartConfigRulesEvaluation` does not re-record the
 * latest configuration state for your resources. It re-runs an
 * evaluation against the last known state of your resources.
 *
 * You can specify up to 25 Config rules per request.
 *
 * An existing `StartConfigRulesEvaluation` call for
 * the specified rules must complete before you can call the API again.
 * If you chose to have Config stream to an Amazon SNS topic, you
 * will receive a `ConfigRuleEvaluationStarted` notification
 * when the evaluation starts.
 *
 * You don't need to call the
 * `StartConfigRulesEvaluation` API to run an
 * evaluation for a new rule. When you create a rule, Config
 * evaluates your resources against the rule automatically.
 *
 * The `StartConfigRulesEvaluation` API is useful if
 * you want to run on-demand evaluations, such as the following
 * example:
 *
 * - You have a custom rule that evaluates your IAM
 * resources every 24 hours.
 *
 * - You update your Lambda function to add additional
 * conditions to your rule.
 *
 * - Instead of waiting for the next periodic evaluation,
 * you call the `StartConfigRulesEvaluation`
 * API.
 *
 * - Config invokes your Lambda function and evaluates
 * your IAM resources.
 *
 * - Your custom rule will still run periodic evaluations
 * every 24 hours.
 */
export const startConfigRulesEvaluation: API.OperationMethod<
  StartConfigRulesEvaluationRequest,
  StartConfigRulesEvaluationResponse,
  StartConfigRulesEvaluationError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: StartConfigRulesEvaluationRequest,
  output: StartConfigRulesEvaluationResponse,
  errors: [
    InvalidParameterValueException,
    LimitExceededException,
    NoSuchConfigRuleException,
    ResourceInUseException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "StartConfigRulesEvaluation",
}));

export type StartConfigurationRecorderError =
  | NoAvailableDeliveryChannelException
  | NoSuchConfigurationRecorderException
  | UnmodifiableEntityException
  | CommonErrors;
/**
 * Starts the customer managed configuration recorder. The customer managed configuration recorder will begin recording configuration changes for the resource types you specify.
 *
 * You must have created a delivery channel to
 * successfully start the customer managed configuration recorder. You can use the PutDeliveryChannel operation to create a delivery channel.
 */
export const startConfigurationRecorder: API.OperationMethod<
  StartConfigurationRecorderRequest,
  StartConfigurationRecorderResponse,
  StartConfigurationRecorderError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: StartConfigurationRecorderRequest,
  output: StartConfigurationRecorderResponse,
  errors: [
    NoAvailableDeliveryChannelException,
    NoSuchConfigurationRecorderException,
    UnmodifiableEntityException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "StartConfigurationRecorder",
}));

export type StartRemediationExecutionError =
  | InsufficientPermissionsException
  | InvalidParameterValueException
  | NoSuchRemediationConfigurationException
  | CommonErrors;
/**
 * Runs an on-demand remediation for the specified Config rules against the last known remediation configuration. It runs an execution against the current state of your resources. Remediation execution is asynchronous.
 *
 * You can specify up to 100 resource keys per request. An existing StartRemediationExecution call for the specified resource keys must complete before you can call the API again.
 */
export const startRemediationExecution: API.OperationMethod<
  StartRemediationExecutionRequest,
  StartRemediationExecutionResponse,
  StartRemediationExecutionError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: StartRemediationExecutionRequest,
  output: StartRemediationExecutionResponse,
  errors: [
    InsufficientPermissionsException,
    InvalidParameterValueException,
    NoSuchRemediationConfigurationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "StartRemediationExecution",
}));

export type StartResourceEvaluationError =
  | IdempotentParameterMismatch
  | InvalidParameterValueException
  | CommonErrors;
/**
 * Runs an on-demand evaluation for the specified resource to determine whether the resource details will comply with configured Config rules.
 * You can also use it for evaluation purposes. Config recommends using an evaluation context. It runs an execution against the resource details with all
 * of the Config rules in your account that match with the specified proactive mode and resource type.
 *
 * Ensure you have the `cloudformation:DescribeType` role setup to validate the resource type schema.
 *
 * You can find the
 * Resource type schema in "*Amazon Web Services public extensions*" within the CloudFormation registry or with the following CLI commmand:
 * `aws cloudformation describe-type --type-name "AWS::S3::Bucket" --type RESOURCE`.
 *
 * For more information, see Managing extensions through the CloudFormation registry
 * and Amazon Web Services resource and property types reference in the CloudFormation User Guide.
 */
export const startResourceEvaluation: API.OperationMethod<
  StartResourceEvaluationRequest,
  StartResourceEvaluationResponse,
  StartResourceEvaluationError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: StartResourceEvaluationRequest,
  output: StartResourceEvaluationResponse,
  errors: [IdempotentParameterMismatch, InvalidParameterValueException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "StartResourceEvaluation",
}));

export type StopConfigurationRecorderError =
  | NoSuchConfigurationRecorderException
  | UnmodifiableEntityException
  | CommonErrors;
/**
 * Stops the customer managed configuration recorder. The customer managed configuration recorder will stop recording configuration changes for the resource types you have specified.
 */
export const stopConfigurationRecorder: API.OperationMethod<
  StopConfigurationRecorderRequest,
  StopConfigurationRecorderResponse,
  StopConfigurationRecorderError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: StopConfigurationRecorderRequest,
  output: StopConfigurationRecorderResponse,
  errors: [NoSuchConfigurationRecorderException, UnmodifiableEntityException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "StopConfigurationRecorder",
}));

export type TagResourceError =
  | ResourceNotFoundException
  | TooManyTagsException
  | ValidationException
  | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `ResourceArn`. If existing tags on a resource are not specified in the request parameters, they are not changed.
 * If existing tags are specified, however, then their values will be updated. When a resource is deleted, the tags associated with that resource are deleted as well.
 */
export const tagResource: API.OperationMethod<
  TagResourceRequest,
  TagResourceResponse,
  TagResourceError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: TagResourceRequest,
  output: TagResourceResponse,
  errors: [
    ResourceNotFoundException,
    TooManyTagsException,
    ValidationException,
  ],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "TagResource",
}));

export type UntagResourceError =
  | ResourceNotFoundException
  | ValidationException
  | CommonErrors;
/**
 * Deletes specified tags from a resource.
 */
export const untagResource: API.OperationMethod<
  UntagResourceRequest,
  UntagResourceResponse,
  UntagResourceError,
  Credentials | HttpClient.HttpClient
> = /*@__PURE__*/ API.make(() => ({
  input: UntagResourceRequest,
  output: UntagResourceResponse,
  errors: [ResourceNotFoundException, ValidationException],
  protocol: AwsProtocol,
  retry: Retry,
  operationName: "UntagResource",
}));
