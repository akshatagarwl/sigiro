export {};
//# sourceMappingURL=credential-providers.test.d.ts.map