import * as BrowserCredentials from "./credentials.browser.ts";
export * from "./credentials.browser.ts";
import * as Layer from "effect/Layer";
import { Auth } from "./auth.ts";
export declare const fromEnv: () => Layer.Layer<BrowserCredentials.Credentials, never, never>;
export declare const fromChain: () => Layer.Layer<BrowserCredentials.Credentials, never, never>;
export declare const fromIni: () => Layer.Layer<BrowserCredentials.Credentials, never, never>;
export declare const fromContainerMetadata: () => Layer.Layer<BrowserCredentials.Credentials, never, never>;
export declare const fromProcess: () => Layer.Layer<BrowserCredentials.Credentials, never, never>;
export declare const fromTokenFile: () => Layer.Layer<BrowserCredentials.Credentials, never, never>;
/**
 * Create a lazy, cached SSO credentials provider.
 * SSO credential resolution is deferred until the Effect is run,
 * and credentials are cached until they expire.
 */
export declare const fromSSO: (profileName?: string) => Layer.Layer<BrowserCredentials.Credentials, never, Auth>;
//# sourceMappingURL=credentials.d.ts.map