/**
 * AWS Query Protocol Implementation
 *
 * https://smithy.io/2.0/aws/protocols/aws-query-protocol.html
 *
 * Key differences from EC2 Query:
 * - Query key uses xmlName directly (not capitalized like EC2)
 * - Lists use .member.N format by default (not flattened)
 * - Maps use .entry.N.key and .entry.N.value format
 * - Response has {Op}Result wrapper inside {Op}Response
 * - Errors wrapped in <ErrorResponse><Error>...</Error><RequestId>...</RequestId></ErrorResponse>
 */
import type { Protocol } from "../client/protocol.ts";
export declare const awsQueryProtocol: Protocol;
//# sourceMappingURL=aws-query.d.ts.map