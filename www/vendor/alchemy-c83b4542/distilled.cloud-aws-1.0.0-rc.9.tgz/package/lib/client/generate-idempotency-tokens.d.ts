/**
 * Idempotency Token Generation - auto-fills @idempotencyToken fields with UUIDs.
 *
 * The AWS SDK automatically generates UUIDs for fields marked with @idempotencyToken
 * when the user doesn't provide a value. This ensures request retry safety.
 */
import * as S from "effect/Schema";
/**
 * Find property names that have the @idempotencyToken annotation.
 * This is done once at request builder creation time.
 */
export declare const findIdempotencyTokenProps: (schema: S.Top) => string[];
/**
 * Fill in undefined idempotency tokens with generated UUIDs.
 * Uses pre-computed property names for efficiency.
 */
export declare const fillIdempotencyTokens: (input: unknown, idempotencyTokenProps: string[]) => unknown;
//# sourceMappingURL=generate-idempotency-tokens.d.ts.map