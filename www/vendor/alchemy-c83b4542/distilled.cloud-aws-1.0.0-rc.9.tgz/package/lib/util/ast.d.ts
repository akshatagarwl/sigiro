import type * as AST from "effect/SchemaAST";
/**
 * Unwrap Union types to get to the actual type (handles S.optional)
 * Does NOT unwrap Suspend - callers should handle Suspend separately to preserve annotations
 */
export declare function unwrapUnion(ast: AST.AST): AST.AST;
/**
 * Get the identifier (class name) from an AST node
 */
export declare function getIdentifier(ast: AST.AST): string | undefined;
/**
 * Get property signatures from a schema AST (the "type" / decoded side)
 */
export declare function getPropertySignatures(ast: AST.AST): readonly AST.PropertySignature[];
/**
 * Get encoded property signatures (wire-format side)
 */
export declare function getEncodedPropertySignatures(ast: AST.AST): readonly AST.PropertySignature[];
/**
 * Get element AST from array type.
 * In v4, Arrays has rest elements directly as AST nodes (not wrapped in { type }).
 */
export declare function getArrayElementAST(ast: AST.AST): AST.AST | undefined;
/**
 * Check if AST represents an array type
 */
export declare function isArrayAST(ast: AST.AST): boolean;
/**
 * Check if AST represents a string type (including encoded strings like enums)
 */
export declare function isStringAST(ast: AST.AST): boolean;
/**
 * Check if AST represents a number type
 */
export declare function isNumberAST(ast: AST.AST): boolean;
/**
 * Check if AST represents a boolean type
 */
export declare function isBooleanAST(ast: AST.AST): boolean;
/**
 * Check if AST represents a Date type
 */
export declare function isDateAST(ast: AST.AST): boolean;
/**
 * Get xmlNamespace annotation from AST
 */
export declare function getXmlNamespace(ast: AST.AST): string | undefined;
/**
 * Get xmlName annotation from AST (class-level)
 */
export declare function getXmlNameFromAST(ast: AST.AST): string | undefined;
/**
 * Check if AST represents a map/record type
 */
export declare function isMapAST(ast: AST.AST): boolean;
/**
 * Get key and value AST from map/record type
 */
export declare function getMapKeyValueAST(ast: AST.AST): {
    keyAST: AST.AST;
    valueAST: AST.AST;
} | undefined;
//# sourceMappingURL=ast.d.ts.map