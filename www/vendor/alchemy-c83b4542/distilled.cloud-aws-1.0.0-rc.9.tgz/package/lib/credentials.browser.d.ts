import type { AwsCredentialIdentity } from "@smithy/types";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type { PlatformError } from "effect/PlatformError";
import * as Redacted from "effect/Redacted";
import type { HttpClientError } from "effect/unstable/http/HttpClientError";
import * as Providers from "./credential-providers/shared.ts";
import type { RegionName } from "./region.ts";
export * as AWSTypes from "@aws-sdk/types";
export interface AwsCredentials {
    readonly accessKeyId: string;
    readonly secretAccessKey: string;
    readonly sessionToken?: string;
}
/**
 * Resolved credential values ready for request signing.
 *
 * `region` is not optional. Authenticating always establishes one — from the
 * environment, the profile, or the SSO session — and carrying it here is what
 * lets operations drop `Region` from their requirements: the region an
 * operation uses is the one its credentials came with, unless a `Region`
 * override says otherwise.
 */
export interface ResolvedCredentials {
    readonly accessKeyId: Redacted.Redacted<string>;
    readonly secretAccessKey: Redacted.Redacted<string>;
    readonly sessionToken: Redacted.Redacted<string> | undefined;
    readonly region: RegionName;
    readonly expiration?: number;
}
/**
 * The requirements for resolving credentials (HttpClient for SSO, FileSystem for cache).
 */
/**
 * Error types that can occur during credential resolution.
 */
export type CredentialsError = AwsCredentialProviderError | MissingRegion | ProfileNotFound | InvalidSSOProfile | InvalidSSOToken | ExpiredSSOToken | ConflictingSSORegion | ConflictingSSOStartUrl | SsoPortalError | HttpClientError | PlatformError;
declare const Credentials_base: Context.ServiceClass<Credentials, "AWS::Credentials", Effect.Effect<ResolvedCredentials, CredentialsError, never>>;
export declare class Credentials extends Credentials_base {
}
export declare const mock: Layer.Layer<Credentials, never, never>;
/**
 * Create resolved credentials from an AWS credential identity.
 *
 * The identity carries no region — `AwsCredentialIdentity` never has one —
 * so the provider that resolved it supplies the region it authenticated
 * against.
 */
export declare const fromAwsCredentialIdentity: (identity: AwsCredentialIdentity, region: RegionName) => ResolvedCredentials;
declare const MissingRegion_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::MissingRegion";
} & Readonly<A>;
/**
 * A credentials layer resolved a set of credentials but could not determine
 * which region they belong to.
 *
 * A credential-resolution failure like any other, rather than a defect: the
 * caller's fix is the same shape as for a missing key — configure the
 * environment, the profile, or pass it explicitly.
 */
export declare class MissingRegion extends MissingRegion_base<{
    message: string;
    hints?: ReadonlyArray<string>;
}> {
}
/**
 * The region a credentials provider authenticated against, from the
 * environment. Node providers that read a profile override this with the
 * profile's own region.
 */
export declare const regionFromEnv: Effect.Effect<RegionName, MissingRegion, never>;
export type ProviderName = "env" | "ini" | "chain" | "container" | "http" | "process" | "token-file";
export declare const providerHints: (provider: ProviderName) => ReadonlyArray<string> | undefined;
/**
 * Create a credentials effect with lazy resolution and expiration-aware caching.
 * Uses Effect.cachedWithTTL where the TTL is computed from the credentials' expiration.
 */
export declare const createCachedCredentialsEffect: <E, R>(resolve: Effect.Effect<ResolvedCredentials, E, R>) => Effect.Effect<ResolvedCredentials, E, R>;
/**
 * Create a lazy, cached credentials layer from a credential source.
 * Credentials are resolved on first access and cached based on their expiration time.
 */
export declare const createLazyProvider: (source: Providers.CredentialSource, providerName: ProviderName, 
/**
 * Where this provider's region comes from. Defaults to the environment;
 * providers that read a profile pass the profile's region instead.
 */
region?: Effect.Effect<RegionName, CredentialsError>) => Layer.Layer<Credentials>;
/**
 * Create a credentials provider from static credentials.
 * No lazy loading or caching needed since credentials are already available.
 */
export declare const fromCredentials: (credentials: AwsCredentialIdentity, 
/** Defaults to the environment, like every other provider. */
region?: RegionName) => Layer.Layer<Credentials>;
export declare const fromHttp: () => Layer.Layer<Credentials, never, never>;
export declare const ssoRegion: (region: string) => Layer.Layer<SsoRegion, never, never>;
declare const SsoRegion_base: Context.ServiceClass<SsoRegion, "AWS::SsoRegion", string>;
export declare class SsoRegion extends SsoRegion_base {
}
declare const SsoStartUrl_base: Context.ServiceClass<SsoStartUrl, "AWS::SsoStartUrl", string>;
export declare class SsoStartUrl extends SsoStartUrl_base {
}
declare const ProfileNotFound_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::ProfileNotFound";
} & Readonly<A>;
export declare class ProfileNotFound extends ProfileNotFound_base<{
    message: string;
    profile: string;
}> {
}
declare const ConflictingSSORegion_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::ConflictingSSORegion";
} & Readonly<A>;
export declare class ConflictingSSORegion extends ConflictingSSORegion_base<{
    message: string;
    ssoRegion: string;
    profile: string;
}> {
}
declare const ConflictingSSOStartUrl_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::ConflictingSSOStartUrl";
} & Readonly<A>;
export declare class ConflictingSSOStartUrl extends ConflictingSSOStartUrl_base<{
    message: string;
    ssoStartUrl: string;
    profile: string;
}> {
}
declare const InvalidSSOProfile_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::InvalidSSOProfile";
} & Readonly<A>;
export declare class InvalidSSOProfile extends InvalidSSOProfile_base<{
    message: string;
    profile: string;
    missingFields: string[];
}> {
}
declare const InvalidSSOToken_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::InvalidSSOToken";
} & Readonly<A>;
export declare class InvalidSSOToken extends InvalidSSOToken_base<{
    message: string;
    sso_session: string;
}> {
}
declare const ExpiredSSOToken_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::ExpiredSSOToken";
} & Readonly<A>;
export declare class ExpiredSSOToken extends ExpiredSSOToken_base<{
    message: string;
    profile: string;
}> {
}
declare const AwsCredentialProviderError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "AWS::CredentialProviderError";
} & Readonly<A>;
export declare class AwsCredentialProviderError extends AwsCredentialProviderError_base<{
    message: string;
    provider: string;
    cause?: unknown;
    hints?: ReadonlyArray<string>;
}> {
}
declare const SsoPortalError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::SsoPortalError";
} & Readonly<A>;
/**
 * The AWS SSO portal returned a response with no `roleCredentials`, e.g. a
 * `ForbiddenException` when an IAM Identity Center role assignment is in a
 * stale state.
 */
export declare class SsoPortalError extends SsoPortalError_base<{
    message: string;
    profile: string;
    account_id?: string;
    role_name?: string;
    status?: number;
}> {
}
//# sourceMappingURL=credentials.browser.d.ts.map