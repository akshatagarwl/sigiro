export {};
//# sourceMappingURL=crc32.test.d.ts.map