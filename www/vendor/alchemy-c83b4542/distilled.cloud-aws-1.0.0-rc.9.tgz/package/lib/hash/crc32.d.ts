/**
 * CRC32 checksum implementation.
 * Prefers Node.js zlib.crc32 (Node 20.15+) for performance and falls back to
 * an inline implementation for browser and worker runtimes.
 */
import type { Checksum } from "@smithy/types";
export declare class Crc32 implements Checksum {
    private checksum;
    update(data: Uint8Array): void;
    digest(): Promise<Uint8Array>;
    reset(): void;
}
export declare const getCrc32ChecksumAlgorithmFunction: () => new () => Checksum;
//# sourceMappingURL=crc32.d.ts.map