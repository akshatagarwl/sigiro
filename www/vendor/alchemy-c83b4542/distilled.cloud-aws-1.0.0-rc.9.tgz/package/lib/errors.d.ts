import * as S from "effect/Schema";
import type * as HttpClientError from "effect/unstable/http/HttpClientError";
import type * as Credentials from "./credentials.browser.ts";
import type * as SigV4 from "./sigv4.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends AccessDeniedException_base {
}
declare const ExpiredTokenException_base: S.Class<ExpiredTokenException, S.TaggedStruct<"ExpiredTokenException", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ExpiredTokenException extends ExpiredTokenException_base {
}
declare const IncompleteSignature_base: S.Class<IncompleteSignature, S.TaggedStruct<"IncompleteSignature", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class IncompleteSignature extends IncompleteSignature_base {
}
declare const InternalFailure_base: S.Class<InternalFailure, S.TaggedStruct<"InternalFailure", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailure extends InternalFailure_base {
}
declare const MalformedHttpRequestException_base: S.Class<MalformedHttpRequestException, S.TaggedStruct<"MalformedHttpRequestException", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MalformedHttpRequestException extends MalformedHttpRequestException_base {
}
declare const NotAuthorized_base: S.Class<NotAuthorized, S.TaggedStruct<"NotAuthorized", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NotAuthorized extends NotAuthorized_base {
}
declare const OptInRequired_base: S.Class<OptInRequired, S.TaggedStruct<"OptInRequired", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class OptInRequired extends OptInRequired_base {
}
declare const RequestAbortedException_base: S.Class<RequestAbortedException, S.TaggedStruct<"RequestAbortedException", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AbortedError: true;
    };
});
export declare class RequestAbortedException extends RequestAbortedException_base {
}
declare const RequestEntityTooLargeException_base: S.Class<RequestEntityTooLargeException, S.TaggedStruct<"RequestEntityTooLargeException", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestEntityTooLargeException extends RequestEntityTooLargeException_base {
}
declare const RequestExpired_base: S.Class<RequestExpired, S.TaggedStruct<"RequestExpired", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class RequestExpired extends RequestExpired_base {
}
declare const RequestTimeoutException_base: S.Class<RequestTimeoutException, S.TaggedStruct<"RequestTimeoutException", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class RequestTimeoutException extends RequestTimeoutException_base {
}
declare const ServiceUnavailable_base: S.Class<ServiceUnavailable, S.TaggedStruct<"ServiceUnavailable", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailable extends ServiceUnavailable_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends ThrottlingException_base {
}
declare const UnrecognizedClientException_base: S.Class<UnrecognizedClientException, S.TaggedStruct<"UnrecognizedClientException", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnrecognizedClientException extends UnrecognizedClientException_base {
}
declare const UnknownOperationException_base: S.Class<UnknownOperationException, S.TaggedStruct<"UnknownOperationException", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnknownOperationException extends UnknownOperationException_base {
}
declare const ValidationError_base: S.Class<ValidationError, S.TaggedStruct<"ValidationError", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationError extends ValidationError_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    /** The human-readable validation failure reason from the service. */
    readonly message: S.optional<S.String>;
    /** Machine-readable reason code (e.g. "FIELD_VALIDATION_FAILED"). */
    readonly reason: S.optional<S.String>;
    /** Per-field validation failures, when the service reports them. */
    readonly fieldList: S.optional<S.Any>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends ValidationException_base {
}
declare const OperationAborted_base: S.Class<OperationAborted, S.TaggedStruct<"OperationAborted", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AbortedError: true;
    };
});
export declare class OperationAborted extends OperationAborted_base {
}
declare const UnknownAwsError_base: S.Class<UnknownAwsError, S.TaggedStruct<"UnknownAwsError", {
    readonly errorTag: S.String;
    readonly errorData: S.Any;
    /** The AWS service SDK ID (e.g., "S3", "DynamoDB") */
    readonly service: S.optional<S.String>;
    /** The operation name (e.g., "createBucket", "putObject") */
    readonly operation: S.optional<S.String>;
    readonly message: S.String;
}>, import("effect/Cause").YieldableError>;
export declare class UnknownAwsError extends UnknownAwsError_base {
}
/**
 * Check if an error is a transient network error that should be retried.
 * These are low-level fetch/socket errors that indicate temporary connectivity issues.
 */
export declare const isTransientNetworkError: (err: unknown) => boolean;
declare const TransientFetchError_base: S.Class<TransientFetchError, S.TaggedStruct<"TransientFetchError", {
    readonly message: S.String;
    readonly cause: S.Any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NetworkError: true;
    };
});
/**
 * Error thrown when a fetch request fails due to a transient network issue.
 * Marked as retryable so the default retry policy will automatically retry these.
 */
export declare class TransientFetchError extends TransientFetchError_base {
}
declare const InternalError_base: S.Class<InternalError, S.TaggedStruct<"InternalError", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalError extends InternalError_base {
}
declare const EndpointError_base: S.Class<EndpointError, S.TaggedStruct<"EndpointError", {
    readonly message: S.String;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
/** Error when endpoint resolution fails due to a rule error */
export declare class EndpointError extends EndpointError_base {
}
declare const NoMatchingRuleError_base: S.Class<NoMatchingRuleError, S.TaggedStruct<"NoMatchingRuleError", {
    readonly message: S.optional<S.String>;
}>, import("effect/Cause").YieldableError>;
/** Error when no rule matches in the ruleset */
export declare class NoMatchingRuleError extends NoMatchingRuleError_base {
}
declare const ParseError_base: S.Class<ParseError, S.TaggedStruct<"ParseError", {
    readonly message: S.String;
}>, import("effect/Cause").YieldableError>;
export declare class ParseError extends ParseError_base {
}
export declare const COMMON_ERRORS: readonly [typeof AccessDeniedException, typeof ExpiredTokenException, typeof IncompleteSignature, typeof InternalError, typeof InternalFailure, typeof MalformedHttpRequestException, typeof NotAuthorized, typeof OperationAborted, typeof OptInRequired, typeof RequestAbortedException, typeof RequestEntityTooLargeException, typeof RequestExpired, typeof RequestTimeoutException, typeof ServiceUnavailable, typeof ThrottlingException, typeof UnknownOperationException, typeof UnrecognizedClientException, typeof ValidationError, typeof ValidationException];
export type CommonAwsError = AccessDeniedException | ExpiredTokenException | IncompleteSignature | InternalFailure | MalformedHttpRequestException | NotAuthorized | OptInRequired | RequestAbortedException | RequestEntityTooLargeException | RequestExpired | RequestTimeoutException | ServiceUnavailable | ThrottlingException | UnrecognizedClientException | UnknownOperationException | ValidationError | ValidationException | OperationAborted;
/**
 * All error types that can be returned by AWS operations.
 *
 * `HttpClientError` belongs here because `API.make` puts it in every
 * operation's error channel (the request can fail before any AWS response
 * exists — DNS, TLS, connection reset). Leaving it out made each generated
 * operation's declared type narrower than what it can actually fail with.
 */
export type CommonErrors = UnknownAwsError | CommonAwsError | EndpointError | NoMatchingRuleError | SigV4.SigningError | Credentials.CredentialsError | HttpClientError.HttpClientError;
export {};
//# sourceMappingURL=errors.d.ts.map