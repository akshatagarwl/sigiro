import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalErrorException_base: S.Class<InternalErrorException, S.TaggedStruct<"InternalErrorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalErrorException extends /*@__PURE__*/ InternalErrorException_base {
}
declare const InvalidInputException_base: S.Class<InvalidInputException, S.TaggedStruct<"InvalidInputException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidOperationException_base: S.Class<InvalidOperationException, S.TaggedStruct<"InvalidOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidOperationException extends /*@__PURE__*/ InvalidOperationException_base {
}
declare const InvalidTypeException_base: S.Class<InvalidTypeException, S.TaggedStruct<"InvalidTypeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTypeException extends /*@__PURE__*/ InvalidTypeException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type AWSAccountId = string;
export interface AssociateAdminAccountRequest {
    AdminAccount: string;
}
export declare const AssociateAdminAccountRequest: S.Schema<AssociateAdminAccountRequest>;
export interface AssociateAdminAccountResponse {
}
export declare const AssociateAdminAccountResponse: S.Schema<AssociateAdminAccountResponse>;
export type ThirdPartyFirewall = "PALO_ALTO_NETWORKS_CLOUD_NGFW" | "FORTIGATE_CLOUD_NATIVE_FIREWALL" | (string & {});
export declare const ThirdPartyFirewall: any;
export interface AssociateThirdPartyFirewallRequest {
    ThirdPartyFirewall: ThirdPartyFirewall;
}
export declare const AssociateThirdPartyFirewallRequest: S.Schema<AssociateThirdPartyFirewallRequest>;
export type ThirdPartyFirewallAssociationStatus = "ONBOARDING" | "ONBOARD_COMPLETE" | "OFFBOARDING" | "OFFBOARD_COMPLETE" | "NOT_EXIST" | (string & {});
export declare const ThirdPartyFirewallAssociationStatus: any;
export interface AssociateThirdPartyFirewallResponse {
    ThirdPartyFirewallStatus?: ThirdPartyFirewallAssociationStatus;
}
export declare const AssociateThirdPartyFirewallResponse: S.Schema<AssociateThirdPartyFirewallResponse>;
export type Identifier = string;
export type IdentifierList = string[];
export declare const IdentifierList: any;
export interface BatchAssociateResourceRequest {
    ResourceSetIdentifier: string;
    Items: string[];
}
export declare const BatchAssociateResourceRequest: S.Schema<BatchAssociateResourceRequest>;
export type FailedItemReason = "NOT_VALID_ARN" | "NOT_VALID_PARTITION" | "NOT_VALID_REGION" | "NOT_VALID_SERVICE" | "NOT_VALID_RESOURCE_TYPE" | "NOT_VALID_ACCOUNT_ID" | (string & {});
export declare const FailedItemReason: any;
export interface FailedItem {
    URI?: string;
    Reason?: FailedItemReason;
}
export declare const FailedItem: S.Schema<FailedItem>;
export type FailedItemList = FailedItem[];
export declare const FailedItemList: any;
export interface BatchAssociateResourceResponse {
    ResourceSetIdentifier: string;
    FailedItems: FailedItem[];
}
export declare const BatchAssociateResourceResponse: S.Schema<BatchAssociateResourceResponse>;
export interface BatchDisassociateResourceRequest {
    ResourceSetIdentifier: string;
    Items: string[];
}
export declare const BatchDisassociateResourceRequest: S.Schema<BatchDisassociateResourceRequest>;
export interface BatchDisassociateResourceResponse {
    ResourceSetIdentifier: string;
    FailedItems: FailedItem[];
}
export declare const BatchDisassociateResourceResponse: S.Schema<BatchDisassociateResourceResponse>;
export type ListId = string;
export interface DeleteAppsListRequest {
    ListId: string;
}
export declare const DeleteAppsListRequest: S.Schema<DeleteAppsListRequest>;
export interface DeleteAppsListResponse {
}
export declare const DeleteAppsListResponse: S.Schema<DeleteAppsListResponse>;
export interface DeleteNotificationChannelRequest {
}
export declare const DeleteNotificationChannelRequest: S.Schema<DeleteNotificationChannelRequest>;
export interface DeleteNotificationChannelResponse {
}
export declare const DeleteNotificationChannelResponse: S.Schema<DeleteNotificationChannelResponse>;
export type PolicyId = string;
export interface DeletePolicyRequest {
    PolicyId: string;
    DeleteAllPolicyResources?: boolean;
}
export declare const DeletePolicyRequest: S.Schema<DeletePolicyRequest>;
export interface DeletePolicyResponse {
}
export declare const DeletePolicyResponse: S.Schema<DeletePolicyResponse>;
export interface DeleteProtocolsListRequest {
    ListId: string;
}
export declare const DeleteProtocolsListRequest: S.Schema<DeleteProtocolsListRequest>;
export interface DeleteProtocolsListResponse {
}
export declare const DeleteProtocolsListResponse: S.Schema<DeleteProtocolsListResponse>;
export type Base62Id = string;
export interface DeleteResourceSetRequest {
    Identifier: string;
}
export declare const DeleteResourceSetRequest: S.Schema<DeleteResourceSetRequest>;
export interface DeleteResourceSetResponse {
}
export declare const DeleteResourceSetResponse: S.Schema<DeleteResourceSetResponse>;
export interface DisassociateAdminAccountRequest {
}
export declare const DisassociateAdminAccountRequest: S.Schema<DisassociateAdminAccountRequest>;
export interface DisassociateAdminAccountResponse {
}
export declare const DisassociateAdminAccountResponse: S.Schema<DisassociateAdminAccountResponse>;
export interface DisassociateThirdPartyFirewallRequest {
    ThirdPartyFirewall: ThirdPartyFirewall;
}
export declare const DisassociateThirdPartyFirewallRequest: S.Schema<DisassociateThirdPartyFirewallRequest>;
export interface DisassociateThirdPartyFirewallResponse {
    ThirdPartyFirewallStatus?: ThirdPartyFirewallAssociationStatus;
}
export declare const DisassociateThirdPartyFirewallResponse: S.Schema<DisassociateThirdPartyFirewallResponse>;
export interface GetAdminAccountRequest {
}
export declare const GetAdminAccountRequest: S.Schema<GetAdminAccountRequest>;
export type AccountRoleStatus = "READY" | "CREATING" | "PENDING_DELETION" | "DELETING" | "DELETED" | (string & {});
export declare const AccountRoleStatus: any;
export interface GetAdminAccountResponse {
    AdminAccount?: string;
    RoleStatus?: AccountRoleStatus;
}
export declare const GetAdminAccountResponse: S.Schema<GetAdminAccountResponse>;
export interface GetAdminScopeRequest {
    AdminAccount: string;
}
export declare const GetAdminScopeRequest: S.Schema<GetAdminScopeRequest>;
export type AccountIdList = string[];
export declare const AccountIdList: any;
export interface AccountScope {
    Accounts?: string[];
    AllAccountsEnabled?: boolean;
    ExcludeSpecifiedAccounts?: boolean;
}
export declare const AccountScope: S.Schema<AccountScope>;
export type OrganizationalUnitId = string;
export type OrganizationalUnitIdList = string[];
export declare const OrganizationalUnitIdList: any;
export interface OrganizationalUnitScope {
    OrganizationalUnits?: string[];
    AllOrganizationalUnitsEnabled?: boolean;
    ExcludeSpecifiedOrganizationalUnits?: boolean;
}
export declare const OrganizationalUnitScope: S.Schema<OrganizationalUnitScope>;
export type AWSRegion = string;
export type AWSRegionList = string[];
export declare const AWSRegionList: any;
export interface RegionScope {
    Regions?: string[];
    AllRegionsEnabled?: boolean;
}
export declare const RegionScope: S.Schema<RegionScope>;
export type SecurityServiceType = "WAF" | "WAFV2" | "SHIELD_ADVANCED" | "SECURITY_GROUPS_COMMON" | "SECURITY_GROUPS_CONTENT_AUDIT" | "SECURITY_GROUPS_USAGE_AUDIT" | "NETWORK_FIREWALL" | "DNS_FIREWALL" | "THIRD_PARTY_FIREWALL" | "IMPORT_NETWORK_FIREWALL" | "NETWORK_ACL_COMMON" | (string & {});
export declare const SecurityServiceType: any;
export type SecurityServiceTypeList = SecurityServiceType[];
export declare const SecurityServiceTypeList: any;
export interface PolicyTypeScope {
    PolicyTypes?: SecurityServiceType[];
    AllPolicyTypesEnabled?: boolean;
}
export declare const PolicyTypeScope: S.Schema<PolicyTypeScope>;
export interface AdminScope {
    AccountScope?: AccountScope;
    OrganizationalUnitScope?: OrganizationalUnitScope;
    RegionScope?: RegionScope;
    PolicyTypeScope?: PolicyTypeScope;
}
export declare const AdminScope: S.Schema<AdminScope>;
export type OrganizationStatus = "ONBOARDING" | "ONBOARDING_COMPLETE" | "OFFBOARDING" | "OFFBOARDING_COMPLETE" | (string & {});
export declare const OrganizationStatus: any;
export interface GetAdminScopeResponse {
    AdminScope?: AdminScope;
    Status?: OrganizationStatus;
}
export declare const GetAdminScopeResponse: S.Schema<GetAdminScopeResponse>;
export interface GetAppsListRequest {
    ListId: string;
    DefaultList?: boolean;
}
export declare const GetAppsListRequest: S.Schema<GetAppsListRequest>;
export type ResourceName = string;
export type UpdateToken = string;
export type Protocol = string;
export type IPPortNumber = number;
export interface App {
    AppName: string;
    Protocol: string;
    Port: number;
}
export declare const App: S.Schema<App>;
export type AppsList = App[];
export declare const AppsList: any;
export type PreviousListVersion = string;
export type PreviousAppsList = {
    [key: string]: App[] | undefined;
};
export declare const PreviousAppsList: any;
export interface AppsListData {
    ListId?: string;
    ListName: string;
    ListUpdateToken?: string;
    CreateTime?: Date;
    LastUpdateTime?: Date;
    AppsList: App[];
    PreviousAppsList?: {
        [key: string]: App[] | undefined;
    };
}
export declare const AppsListData: S.Schema<AppsListData>;
export type ResourceArn = string;
export interface GetAppsListResponse {
    AppsList?: AppsListData;
    AppsListArn?: string;
}
export declare const GetAppsListResponse: S.Schema<GetAppsListResponse>;
export interface GetComplianceDetailRequest {
    PolicyId: string;
    MemberAccount: string;
}
export declare const GetComplianceDetailRequest: S.Schema<GetComplianceDetailRequest>;
export type ResourceId = string;
export type ViolationReason = "WEB_ACL_MISSING_RULE_GROUP" | "RESOURCE_MISSING_WEB_ACL" | "RESOURCE_INCORRECT_WEB_ACL" | "RESOURCE_MISSING_SHIELD_PROTECTION" | "RESOURCE_MISSING_WEB_ACL_OR_SHIELD_PROTECTION" | "RESOURCE_MISSING_SECURITY_GROUP" | "RESOURCE_VIOLATES_AUDIT_SECURITY_GROUP" | "SECURITY_GROUP_UNUSED" | "SECURITY_GROUP_REDUNDANT" | "FMS_CREATED_SECURITY_GROUP_EDITED" | "MISSING_FIREWALL" | "MISSING_FIREWALL_SUBNET_IN_AZ" | "MISSING_EXPECTED_ROUTE_TABLE" | "NETWORK_FIREWALL_POLICY_MODIFIED" | "FIREWALL_SUBNET_IS_OUT_OF_SCOPE" | "INTERNET_GATEWAY_MISSING_EXPECTED_ROUTE" | "FIREWALL_SUBNET_MISSING_EXPECTED_ROUTE" | "UNEXPECTED_FIREWALL_ROUTES" | "UNEXPECTED_TARGET_GATEWAY_ROUTES" | "TRAFFIC_INSPECTION_CROSSES_AZ_BOUNDARY" | "INVALID_ROUTE_CONFIGURATION" | "MISSING_TARGET_GATEWAY" | "INTERNET_TRAFFIC_NOT_INSPECTED" | "BLACK_HOLE_ROUTE_DETECTED" | "BLACK_HOLE_ROUTE_DETECTED_IN_FIREWALL_SUBNET" | "RESOURCE_MISSING_DNS_FIREWALL" | "ROUTE_HAS_OUT_OF_SCOPE_ENDPOINT" | "FIREWALL_SUBNET_MISSING_VPCE_ENDPOINT" | "INVALID_NETWORK_ACL_ENTRY" | "WEB_ACL_CONFIGURATION_OR_SCOPE_OF_USE" | (string & {});
export declare const ViolationReason: any;
export type ResourceType = string;
export type LengthBoundedString = string;
export type ComplianceViolatorMetadata = {
    [key: string]: string | undefined;
};
export declare const ComplianceViolatorMetadata: any;
export interface ComplianceViolator {
    ResourceId?: string;
    ViolationReason?: ViolationReason;
    ResourceType?: string;
    Metadata?: {
        [key: string]: string | undefined;
    };
}
export declare const ComplianceViolator: S.Schema<ComplianceViolator>;
export type ComplianceViolators = ComplianceViolator[];
export declare const ComplianceViolators: any;
export type DependentServiceName = "AWSCONFIG" | "AWSWAF" | "AWSSHIELD_ADVANCED" | "AWSVPC" | (string & {});
export declare const DependentServiceName: any;
export type DetailedInfo = string;
export type IssueInfoMap = {
    [key in DependentServiceName]?: string;
};
export declare const IssueInfoMap: any;
export interface PolicyComplianceDetail {
    PolicyOwner?: string;
    PolicyId?: string;
    MemberAccount?: string;
    Violators?: ComplianceViolator[];
    EvaluationLimitExceeded?: boolean;
    ExpiredAt?: Date;
    IssueInfoMap?: {
        [key: string]: string | undefined;
    };
}
export declare const PolicyComplianceDetail: S.Schema<PolicyComplianceDetail>;
export interface GetComplianceDetailResponse {
    PolicyComplianceDetail?: PolicyComplianceDetail;
}
export declare const GetComplianceDetailResponse: S.Schema<GetComplianceDetailResponse>;
export interface GetNotificationChannelRequest {
}
export declare const GetNotificationChannelRequest: S.Schema<GetNotificationChannelRequest>;
export interface GetNotificationChannelResponse {
    SnsTopicArn?: string;
    SnsRoleName?: string;
}
export declare const GetNotificationChannelResponse: S.Schema<GetNotificationChannelResponse>;
export interface GetPolicyRequest {
    PolicyId: string;
}
export declare const GetPolicyRequest: S.Schema<GetPolicyRequest>;
export type PolicyUpdateToken = string;
export type ManagedServiceData = string;
export type FirewallDeploymentModel = "CENTRALIZED" | "DISTRIBUTED" | (string & {});
export declare const FirewallDeploymentModel: any;
export interface NetworkFirewallPolicy {
    FirewallDeploymentModel?: FirewallDeploymentModel;
}
export declare const NetworkFirewallPolicy: S.Schema<NetworkFirewallPolicy>;
export interface ThirdPartyFirewallPolicy {
    FirewallDeploymentModel?: FirewallDeploymentModel;
}
export declare const ThirdPartyFirewallPolicy: S.Schema<ThirdPartyFirewallPolicy>;
export type IntegerObject = number;
export interface NetworkAclIcmpTypeCode {
    Code?: number;
    Type?: number;
}
export declare const NetworkAclIcmpTypeCode: S.Schema<NetworkAclIcmpTypeCode>;
export type IPPortNumberInteger = number;
export interface NetworkAclPortRange {
    From?: number;
    To?: number;
}
export declare const NetworkAclPortRange: S.Schema<NetworkAclPortRange>;
export type LengthBoundedNonEmptyString = string;
export type NetworkAclRuleAction = "allow" | "deny" | (string & {});
export declare const NetworkAclRuleAction: any;
export interface NetworkAclEntry {
    IcmpTypeCode?: NetworkAclIcmpTypeCode;
    Protocol: string;
    PortRange?: NetworkAclPortRange;
    CidrBlock?: string;
    Ipv6CidrBlock?: string;
    RuleAction: NetworkAclRuleAction;
    Egress: boolean;
}
export declare const NetworkAclEntry: S.Schema<NetworkAclEntry>;
export type NetworkAclEntries = NetworkAclEntry[];
export declare const NetworkAclEntries: any;
export interface NetworkAclEntrySet {
    FirstEntries?: NetworkAclEntry[];
    ForceRemediateForFirstEntries: boolean;
    LastEntries?: NetworkAclEntry[];
    ForceRemediateForLastEntries: boolean;
}
export declare const NetworkAclEntrySet: S.Schema<NetworkAclEntrySet>;
export interface NetworkAclCommonPolicy {
    NetworkAclEntrySet: NetworkAclEntrySet;
}
export declare const NetworkAclCommonPolicy: S.Schema<NetworkAclCommonPolicy>;
export interface PolicyOption {
    NetworkFirewallPolicy?: NetworkFirewallPolicy;
    ThirdPartyFirewallPolicy?: ThirdPartyFirewallPolicy;
    NetworkAclCommonPolicy?: NetworkAclCommonPolicy;
}
export declare const PolicyOption: S.Schema<PolicyOption>;
export interface SecurityServicePolicyData {
    Type: SecurityServiceType;
    ManagedServiceData?: string;
    PolicyOption?: PolicyOption;
}
export declare const SecurityServicePolicyData: S.Schema<SecurityServicePolicyData>;
export type ResourceTypeList = string[];
export declare const ResourceTypeList: any;
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    Key: string;
    Value?: string;
}
export declare const ResourceTag: S.Schema<ResourceTag>;
export type ResourceTags = ResourceTag[];
export declare const ResourceTags: any;
export type CustomerPolicyScopeIdType = "ACCOUNT" | "ORG_UNIT" | (string & {});
export declare const CustomerPolicyScopeIdType: any;
export type CustomerPolicyScopeId = string;
export type CustomerPolicyScopeIdList = string[];
export declare const CustomerPolicyScopeIdList: any;
export type CustomerPolicyScopeMap = {
    [key in CustomerPolicyScopeIdType]?: string[];
};
export declare const CustomerPolicyScopeMap: any;
export type ResourceSetIds = string[];
export declare const ResourceSetIds: any;
export type ResourceDescription = string;
export type CustomerPolicyStatus = "ACTIVE" | "OUT_OF_ADMIN_SCOPE" | (string & {});
export declare const CustomerPolicyStatus: any;
export type ResourceTagLogicalOperator = "AND" | "OR" | (string & {});
export declare const ResourceTagLogicalOperator: any;
export interface Policy {
    PolicyId?: string;
    PolicyName: string;
    PolicyUpdateToken?: string;
    SecurityServicePolicyData: SecurityServicePolicyData;
    ResourceType: string;
    ResourceTypeList?: string[];
    ResourceTags?: ResourceTag[];
    ExcludeResourceTags: boolean;
    RemediationEnabled: boolean;
    DeleteUnusedFMManagedResources?: boolean;
    IncludeMap?: {
        [key: string]: string[] | undefined;
    };
    ExcludeMap?: {
        [key: string]: string[] | undefined;
    };
    ResourceSetIds?: string[];
    PolicyDescription?: string;
    PolicyStatus?: CustomerPolicyStatus;
    ResourceTagLogicalOperator?: ResourceTagLogicalOperator;
}
export declare const Policy: S.Schema<Policy>;
export interface GetPolicyResponse {
    Policy?: Policy;
    PolicyArn?: string;
}
export declare const GetPolicyResponse: S.Schema<GetPolicyResponse>;
export type PaginationToken = string;
export type PaginationMaxResults = number;
export interface GetProtectionStatusRequest {
    PolicyId: string;
    MemberAccountId?: string;
    StartTime?: Date;
    EndTime?: Date;
    NextToken?: string;
    MaxResults?: number;
}
export declare const GetProtectionStatusRequest: S.Schema<GetProtectionStatusRequest>;
export type ProtectionData = string;
export interface GetProtectionStatusResponse {
    AdminAccountId?: string;
    ServiceType?: SecurityServiceType;
    Data?: string;
    NextToken?: string;
}
export declare const GetProtectionStatusResponse: S.Schema<GetProtectionStatusResponse>;
export interface GetProtocolsListRequest {
    ListId: string;
    DefaultList?: boolean;
}
export declare const GetProtocolsListRequest: S.Schema<GetProtocolsListRequest>;
export type ProtocolsList = string[];
export declare const ProtocolsList: any;
export type PreviousProtocolsList = {
    [key: string]: string[] | undefined;
};
export declare const PreviousProtocolsList: any;
export interface ProtocolsListData {
    ListId?: string;
    ListName: string;
    ListUpdateToken?: string;
    CreateTime?: Date;
    LastUpdateTime?: Date;
    ProtocolsList: string[];
    PreviousProtocolsList?: {
        [key: string]: string[] | undefined;
    };
}
export declare const ProtocolsListData: S.Schema<ProtocolsListData>;
export interface GetProtocolsListResponse {
    ProtocolsList?: ProtocolsListData;
    ProtocolsListArn?: string;
}
export declare const GetProtocolsListResponse: S.Schema<GetProtocolsListResponse>;
export interface GetResourceSetRequest {
    Identifier: string;
}
export declare const GetResourceSetRequest: S.Schema<GetResourceSetRequest>;
export type Name = string;
export type Description = string;
export type ResourceSetStatus = "ACTIVE" | "OUT_OF_ADMIN_SCOPE" | (string & {});
export declare const ResourceSetStatus: any;
export interface ResourceSet {
    Id?: string;
    Name: string;
    Description?: string;
    UpdateToken?: string;
    ResourceTypeList: string[];
    LastUpdateTime?: Date;
    ResourceSetStatus?: ResourceSetStatus;
}
export declare const ResourceSet: S.Schema<ResourceSet>;
export interface GetResourceSetResponse {
    ResourceSet: ResourceSet;
    ResourceSetArn: string;
}
export declare const GetResourceSetResponse: S.Schema<GetResourceSetResponse>;
export interface GetThirdPartyFirewallAssociationStatusRequest {
    ThirdPartyFirewall: ThirdPartyFirewall;
}
export declare const GetThirdPartyFirewallAssociationStatusRequest: S.Schema<GetThirdPartyFirewallAssociationStatusRequest>;
export type MarketplaceSubscriptionOnboardingStatus = "NO_SUBSCRIPTION" | "NOT_COMPLETE" | "COMPLETE" | (string & {});
export declare const MarketplaceSubscriptionOnboardingStatus: any;
export interface GetThirdPartyFirewallAssociationStatusResponse {
    ThirdPartyFirewallStatus?: ThirdPartyFirewallAssociationStatus;
    MarketplaceOnboardingStatus?: MarketplaceSubscriptionOnboardingStatus;
}
export declare const GetThirdPartyFirewallAssociationStatusResponse: S.Schema<GetThirdPartyFirewallAssociationStatusResponse>;
export interface GetViolationDetailsRequest {
    PolicyId: string;
    MemberAccount: string;
    ResourceId: string;
    ResourceType: string;
}
export declare const GetViolationDetailsRequest: S.Schema<GetViolationDetailsRequest>;
export type ViolationTarget = string;
export type ReferenceRule = string;
export type TargetViolationReason = string;
export type TargetViolationReasons = string[];
export declare const TargetViolationReasons: any;
export interface PartialMatch {
    Reference?: string;
    TargetViolationReasons?: string[];
}
export declare const PartialMatch: S.Schema<PartialMatch>;
export type PartialMatches = PartialMatch[];
export declare const PartialMatches: any;
export type RemediationActionType = "REMOVE" | "MODIFY" | (string & {});
export declare const RemediationActionType: any;
export type RemediationActionDescription = string;
export type CIDR = string;
export interface SecurityGroupRuleDescription {
    IPV4Range?: string;
    IPV6Range?: string;
    PrefixListId?: string;
    Protocol?: string;
    FromPort?: number;
    ToPort?: number;
}
export declare const SecurityGroupRuleDescription: S.Schema<SecurityGroupRuleDescription>;
export interface SecurityGroupRemediationAction {
    RemediationActionType?: RemediationActionType;
    Description?: string;
    RemediationResult?: SecurityGroupRuleDescription;
    IsDefaultAction?: boolean;
}
export declare const SecurityGroupRemediationAction: S.Schema<SecurityGroupRemediationAction>;
export type SecurityGroupRemediationActions = SecurityGroupRemediationAction[];
export declare const SecurityGroupRemediationActions: any;
export interface AwsVPCSecurityGroupViolation {
    ViolationTarget?: string;
    ViolationTargetDescription?: string;
    PartialMatches?: PartialMatch[];
    PossibleSecurityGroupRemediationActions?: SecurityGroupRemediationAction[];
}
export declare const AwsVPCSecurityGroupViolation: S.Schema<AwsVPCSecurityGroupViolation>;
export type ResourceIdList = string[];
export declare const ResourceIdList: any;
export interface AwsEc2NetworkInterfaceViolation {
    ViolationTarget?: string;
    ViolatingSecurityGroups?: string[];
}
export declare const AwsEc2NetworkInterfaceViolation: S.Schema<AwsEc2NetworkInterfaceViolation>;
export type AwsEc2NetworkInterfaceViolations = AwsEc2NetworkInterfaceViolation[];
export declare const AwsEc2NetworkInterfaceViolations: any;
export interface AwsEc2InstanceViolation {
    ViolationTarget?: string;
    AwsEc2NetworkInterfaceViolations?: AwsEc2NetworkInterfaceViolation[];
}
export declare const AwsEc2InstanceViolation: S.Schema<AwsEc2InstanceViolation>;
export interface NetworkFirewallMissingFirewallViolation {
    ViolationTarget?: string;
    VPC?: string;
    AvailabilityZone?: string;
    TargetViolationReason?: string;
}
export declare const NetworkFirewallMissingFirewallViolation: S.Schema<NetworkFirewallMissingFirewallViolation>;
export interface NetworkFirewallMissingSubnetViolation {
    ViolationTarget?: string;
    VPC?: string;
    AvailabilityZone?: string;
    TargetViolationReason?: string;
}
export declare const NetworkFirewallMissingSubnetViolation: S.Schema<NetworkFirewallMissingSubnetViolation>;
export interface NetworkFirewallMissingExpectedRTViolation {
    ViolationTarget?: string;
    VPC?: string;
    AvailabilityZone?: string;
    CurrentRouteTable?: string;
    ExpectedRouteTable?: string;
}
export declare const NetworkFirewallMissingExpectedRTViolation: S.Schema<NetworkFirewallMissingExpectedRTViolation>;
export type NetworkFirewallResourceName = string;
export type StatelessRuleGroupPriority = number;
export interface StatelessRuleGroup {
    RuleGroupName?: string;
    ResourceId?: string;
    Priority?: number;
}
export declare const StatelessRuleGroup: S.Schema<StatelessRuleGroup>;
export type StatelessRuleGroupList = StatelessRuleGroup[];
export declare const StatelessRuleGroupList: any;
export type NetworkFirewallAction = string;
export type NetworkFirewallActionList = string[];
export declare const NetworkFirewallActionList: any;
export type PriorityNumber = number;
export type NetworkFirewallOverrideAction = "DROP_TO_ALERT" | (string & {});
export declare const NetworkFirewallOverrideAction: any;
export interface NetworkFirewallStatefulRuleGroupOverride {
    Action?: NetworkFirewallOverrideAction;
}
export declare const NetworkFirewallStatefulRuleGroupOverride: S.Schema<NetworkFirewallStatefulRuleGroupOverride>;
export interface StatefulRuleGroup {
    RuleGroupName?: string;
    ResourceId?: string;
    Priority?: number;
    Override?: NetworkFirewallStatefulRuleGroupOverride;
}
export declare const StatefulRuleGroup: S.Schema<StatefulRuleGroup>;
export type StatefulRuleGroupList = StatefulRuleGroup[];
export declare const StatefulRuleGroupList: any;
export type RuleOrder = "STRICT_ORDER" | "DEFAULT_ACTION_ORDER" | (string & {});
export declare const RuleOrder: any;
export type StreamExceptionPolicy = "DROP" | "CONTINUE" | "REJECT" | "FMS_IGNORE" | (string & {});
export declare const StreamExceptionPolicy: any;
export interface StatefulEngineOptions {
    RuleOrder?: RuleOrder;
    StreamExceptionPolicy?: StreamExceptionPolicy;
}
export declare const StatefulEngineOptions: S.Schema<StatefulEngineOptions>;
export interface NetworkFirewallPolicyDescription {
    StatelessRuleGroups?: StatelessRuleGroup[];
    StatelessDefaultActions?: string[];
    StatelessFragmentDefaultActions?: string[];
    StatelessCustomActions?: string[];
    StatefulRuleGroups?: StatefulRuleGroup[];
    StatefulDefaultActions?: string[];
    StatefulEngineOptions?: StatefulEngineOptions;
}
export declare const NetworkFirewallPolicyDescription: S.Schema<NetworkFirewallPolicyDescription>;
export interface NetworkFirewallPolicyModifiedViolation {
    ViolationTarget?: string;
    CurrentPolicyDescription?: NetworkFirewallPolicyDescription;
    ExpectedPolicyDescription?: NetworkFirewallPolicyDescription;
}
export declare const NetworkFirewallPolicyModifiedViolation: S.Schema<NetworkFirewallPolicyModifiedViolation>;
export type DestinationType = "IPV4" | "IPV6" | "PREFIX_LIST" | (string & {});
export declare const DestinationType: any;
export type TargetType = "GATEWAY" | "CARRIER_GATEWAY" | "INSTANCE" | "LOCAL_GATEWAY" | "NAT_GATEWAY" | "NETWORK_INTERFACE" | "VPC_ENDPOINT" | "VPC_PEERING_CONNECTION" | "EGRESS_ONLY_INTERNET_GATEWAY" | "TRANSIT_GATEWAY" | (string & {});
export declare const TargetType: any;
export interface Route {
    DestinationType?: DestinationType;
    TargetType?: TargetType;
    Destination?: string;
    Target?: string;
}
export declare const Route: S.Schema<Route>;
export type Routes = Route[];
export declare const Routes: any;
export type LengthBoundedStringList = string[];
export declare const LengthBoundedStringList: any;
export interface ExpectedRoute {
    IpV4Cidr?: string;
    PrefixListId?: string;
    IpV6Cidr?: string;
    ContributingSubnets?: string[];
    AllowedTargets?: string[];
    RouteTableId?: string;
}
export declare const ExpectedRoute: S.Schema<ExpectedRoute>;
export type ExpectedRoutes = ExpectedRoute[];
export declare const ExpectedRoutes: any;
export interface NetworkFirewallInternetTrafficNotInspectedViolation {
    SubnetId?: string;
    SubnetAvailabilityZone?: string;
    RouteTableId?: string;
    ViolatingRoutes?: Route[];
    IsRouteTableUsedInDifferentAZ?: boolean;
    CurrentFirewallSubnetRouteTable?: string;
    ExpectedFirewallEndpoint?: string;
    FirewallSubnetId?: string;
    ExpectedFirewallSubnetRoutes?: ExpectedRoute[];
    ActualFirewallSubnetRoutes?: Route[];
    InternetGatewayId?: string;
    CurrentInternetGatewayRouteTable?: string;
    ExpectedInternetGatewayRoutes?: ExpectedRoute[];
    ActualInternetGatewayRoutes?: Route[];
    VpcId?: string;
}
export declare const NetworkFirewallInternetTrafficNotInspectedViolation: S.Schema<NetworkFirewallInternetTrafficNotInspectedViolation>;
export interface NetworkFirewallInvalidRouteConfigurationViolation {
    AffectedSubnets?: string[];
    RouteTableId?: string;
    IsRouteTableUsedInDifferentAZ?: boolean;
    ViolatingRoute?: Route;
    CurrentFirewallSubnetRouteTable?: string;
    ExpectedFirewallEndpoint?: string;
    ActualFirewallEndpoint?: string;
    ExpectedFirewallSubnetId?: string;
    ActualFirewallSubnetId?: string;
    ExpectedFirewallSubnetRoutes?: ExpectedRoute[];
    ActualFirewallSubnetRoutes?: Route[];
    InternetGatewayId?: string;
    CurrentInternetGatewayRouteTable?: string;
    ExpectedInternetGatewayRoutes?: ExpectedRoute[];
    ActualInternetGatewayRoutes?: Route[];
    VpcId?: string;
}
export declare const NetworkFirewallInvalidRouteConfigurationViolation: S.Schema<NetworkFirewallInvalidRouteConfigurationViolation>;
export interface NetworkFirewallBlackHoleRouteDetectedViolation {
    ViolationTarget?: string;
    RouteTableId?: string;
    VpcId?: string;
    ViolatingRoutes?: Route[];
}
export declare const NetworkFirewallBlackHoleRouteDetectedViolation: S.Schema<NetworkFirewallBlackHoleRouteDetectedViolation>;
export interface NetworkFirewallUnexpectedFirewallRoutesViolation {
    FirewallSubnetId?: string;
    ViolatingRoutes?: Route[];
    RouteTableId?: string;
    FirewallEndpoint?: string;
    VpcId?: string;
}
export declare const NetworkFirewallUnexpectedFirewallRoutesViolation: S.Schema<NetworkFirewallUnexpectedFirewallRoutesViolation>;
export interface NetworkFirewallUnexpectedGatewayRoutesViolation {
    GatewayId?: string;
    ViolatingRoutes?: Route[];
    RouteTableId?: string;
    VpcId?: string;
}
export declare const NetworkFirewallUnexpectedGatewayRoutesViolation: S.Schema<NetworkFirewallUnexpectedGatewayRoutesViolation>;
export interface NetworkFirewallMissingExpectedRoutesViolation {
    ViolationTarget?: string;
    ExpectedRoutes?: ExpectedRoute[];
    VpcId?: string;
}
export declare const NetworkFirewallMissingExpectedRoutesViolation: S.Schema<NetworkFirewallMissingExpectedRoutesViolation>;
export type DnsRuleGroupPriority = number;
export type DnsRuleGroupPriorities = number[];
export declare const DnsRuleGroupPriorities: any;
export interface DnsRuleGroupPriorityConflictViolation {
    ViolationTarget?: string;
    ViolationTargetDescription?: string;
    ConflictingPriority?: number;
    ConflictingPolicyId?: string;
    UnavailablePriorities?: number[];
}
export declare const DnsRuleGroupPriorityConflictViolation: S.Schema<DnsRuleGroupPriorityConflictViolation>;
export interface DnsDuplicateRuleGroupViolation {
    ViolationTarget?: string;
    ViolationTargetDescription?: string;
}
export declare const DnsDuplicateRuleGroupViolation: S.Schema<DnsDuplicateRuleGroupViolation>;
export type BasicInteger = number;
export interface DnsRuleGroupLimitExceededViolation {
    ViolationTarget?: string;
    ViolationTargetDescription?: string;
    NumberOfRuleGroupsAlreadyAssociated?: number;
}
export declare const DnsRuleGroupLimitExceededViolation: S.Schema<DnsRuleGroupLimitExceededViolation>;
export interface FirewallSubnetIsOutOfScopeViolation {
    FirewallSubnetId?: string;
    VpcId?: string;
    SubnetAvailabilityZone?: string;
    SubnetAvailabilityZoneId?: string;
    VpcEndpointId?: string;
}
export declare const FirewallSubnetIsOutOfScopeViolation: S.Schema<FirewallSubnetIsOutOfScopeViolation>;
export interface RouteHasOutOfScopeEndpointViolation {
    SubnetId?: string;
    VpcId?: string;
    RouteTableId?: string;
    ViolatingRoutes?: Route[];
    SubnetAvailabilityZone?: string;
    SubnetAvailabilityZoneId?: string;
    CurrentFirewallSubnetRouteTable?: string;
    FirewallSubnetId?: string;
    FirewallSubnetRoutes?: Route[];
    InternetGatewayId?: string;
    CurrentInternetGatewayRouteTable?: string;
    InternetGatewayRoutes?: Route[];
}
export declare const RouteHasOutOfScopeEndpointViolation: S.Schema<RouteHasOutOfScopeEndpointViolation>;
export interface ThirdPartyFirewallMissingFirewallViolation {
    ViolationTarget?: string;
    VPC?: string;
    AvailabilityZone?: string;
    TargetViolationReason?: string;
}
export declare const ThirdPartyFirewallMissingFirewallViolation: S.Schema<ThirdPartyFirewallMissingFirewallViolation>;
export interface ThirdPartyFirewallMissingSubnetViolation {
    ViolationTarget?: string;
    VPC?: string;
    AvailabilityZone?: string;
    TargetViolationReason?: string;
}
export declare const ThirdPartyFirewallMissingSubnetViolation: S.Schema<ThirdPartyFirewallMissingSubnetViolation>;
export interface ThirdPartyFirewallMissingExpectedRouteTableViolation {
    ViolationTarget?: string;
    VPC?: string;
    AvailabilityZone?: string;
    CurrentRouteTable?: string;
    ExpectedRouteTable?: string;
}
export declare const ThirdPartyFirewallMissingExpectedRouteTableViolation: S.Schema<ThirdPartyFirewallMissingExpectedRouteTableViolation>;
export interface FirewallSubnetMissingVPCEndpointViolation {
    FirewallSubnetId?: string;
    VpcId?: string;
    SubnetAvailabilityZone?: string;
    SubnetAvailabilityZoneId?: string;
}
export declare const FirewallSubnetMissingVPCEndpointViolation: S.Schema<FirewallSubnetMissingVPCEndpointViolation>;
export type IntegerObjectMinimum0 = number;
export type EntryType = "FMS_MANAGED_FIRST_ENTRY" | "FMS_MANAGED_LAST_ENTRY" | "CUSTOM_ENTRY" | (string & {});
export declare const EntryType: any;
export interface EntryDescription {
    EntryDetail?: NetworkAclEntry;
    EntryRuleNumber?: number;
    EntryType?: EntryType;
}
export declare const EntryDescription: S.Schema<EntryDescription>;
export type EntriesWithConflicts = EntryDescription[];
export declare const EntriesWithConflicts: any;
export type EntryViolationReason = "MISSING_EXPECTED_ENTRY" | "INCORRECT_ENTRY_ORDER" | "ENTRY_CONFLICT" | (string & {});
export declare const EntryViolationReason: any;
export type EntryViolationReasons = EntryViolationReason[];
export declare const EntryViolationReasons: any;
export interface EntryViolation {
    ExpectedEntry?: EntryDescription;
    ExpectedEvaluationOrder?: string;
    ActualEvaluationOrder?: string;
    EntryAtExpectedEvaluationOrder?: EntryDescription;
    EntriesWithConflicts?: EntryDescription[];
    EntryViolationReasons?: EntryViolationReason[];
}
export declare const EntryViolation: S.Schema<EntryViolation>;
export type EntryViolations = EntryViolation[];
export declare const EntryViolations: any;
export interface InvalidNetworkAclEntriesViolation {
    Vpc?: string;
    Subnet?: string;
    SubnetAvailabilityZone?: string;
    CurrentAssociatedNetworkAcl?: string;
    EntryViolations?: EntryViolation[];
}
export declare const InvalidNetworkAclEntriesViolation: S.Schema<InvalidNetworkAclEntriesViolation>;
export interface ActionTarget {
    ResourceId?: string;
    Description?: string;
}
export declare const ActionTarget: S.Schema<ActionTarget>;
export interface EC2CreateRouteAction {
    Description?: string;
    DestinationCidrBlock?: string;
    DestinationPrefixListId?: string;
    DestinationIpv6CidrBlock?: string;
    VpcEndpointId?: ActionTarget;
    GatewayId?: ActionTarget;
    RouteTableId: ActionTarget;
}
export declare const EC2CreateRouteAction: S.Schema<EC2CreateRouteAction>;
export interface EC2ReplaceRouteAction {
    Description?: string;
    DestinationCidrBlock?: string;
    DestinationPrefixListId?: string;
    DestinationIpv6CidrBlock?: string;
    GatewayId?: ActionTarget;
    RouteTableId: ActionTarget;
}
export declare const EC2ReplaceRouteAction: S.Schema<EC2ReplaceRouteAction>;
export interface EC2DeleteRouteAction {
    Description?: string;
    DestinationCidrBlock?: string;
    DestinationPrefixListId?: string;
    DestinationIpv6CidrBlock?: string;
    RouteTableId: ActionTarget;
}
export declare const EC2DeleteRouteAction: S.Schema<EC2DeleteRouteAction>;
export interface EC2CopyRouteTableAction {
    Description?: string;
    VpcId: ActionTarget;
    RouteTableId: ActionTarget;
}
export declare const EC2CopyRouteTableAction: S.Schema<EC2CopyRouteTableAction>;
export interface EC2ReplaceRouteTableAssociationAction {
    Description?: string;
    AssociationId: ActionTarget;
    RouteTableId: ActionTarget;
}
export declare const EC2ReplaceRouteTableAssociationAction: S.Schema<EC2ReplaceRouteTableAssociationAction>;
export interface EC2AssociateRouteTableAction {
    Description?: string;
    RouteTableId: ActionTarget;
    SubnetId?: ActionTarget;
    GatewayId?: ActionTarget;
}
export declare const EC2AssociateRouteTableAction: S.Schema<EC2AssociateRouteTableAction>;
export interface EC2CreateRouteTableAction {
    Description?: string;
    VpcId: ActionTarget;
}
export declare const EC2CreateRouteTableAction: S.Schema<EC2CreateRouteTableAction>;
export interface FMSPolicyUpdateFirewallCreationConfigAction {
    Description?: string;
    FirewallCreationConfig?: string;
}
export declare const FMSPolicyUpdateFirewallCreationConfigAction: S.Schema<FMSPolicyUpdateFirewallCreationConfigAction>;
export interface CreateNetworkAclAction {
    Description?: string;
    Vpc?: ActionTarget;
    FMSCanRemediate?: boolean;
}
export declare const CreateNetworkAclAction: S.Schema<CreateNetworkAclAction>;
export interface ReplaceNetworkAclAssociationAction {
    Description?: string;
    AssociationId?: ActionTarget;
    NetworkAclId?: ActionTarget;
    FMSCanRemediate?: boolean;
}
export declare const ReplaceNetworkAclAssociationAction: S.Schema<ReplaceNetworkAclAssociationAction>;
export type EntriesDescription = EntryDescription[];
export declare const EntriesDescription: any;
export interface CreateNetworkAclEntriesAction {
    Description?: string;
    NetworkAclId?: ActionTarget;
    NetworkAclEntriesToBeCreated?: EntryDescription[];
    FMSCanRemediate?: boolean;
}
export declare const CreateNetworkAclEntriesAction: S.Schema<CreateNetworkAclEntriesAction>;
export interface DeleteNetworkAclEntriesAction {
    Description?: string;
    NetworkAclId?: ActionTarget;
    NetworkAclEntriesToBeDeleted?: EntryDescription[];
    FMSCanRemediate?: boolean;
}
export declare const DeleteNetworkAclEntriesAction: S.Schema<DeleteNetworkAclEntriesAction>;
export interface RemediationAction {
    Description?: string;
    EC2CreateRouteAction?: EC2CreateRouteAction;
    EC2ReplaceRouteAction?: EC2ReplaceRouteAction;
    EC2DeleteRouteAction?: EC2DeleteRouteAction;
    EC2CopyRouteTableAction?: EC2CopyRouteTableAction;
    EC2ReplaceRouteTableAssociationAction?: EC2ReplaceRouteTableAssociationAction;
    EC2AssociateRouteTableAction?: EC2AssociateRouteTableAction;
    EC2CreateRouteTableAction?: EC2CreateRouteTableAction;
    FMSPolicyUpdateFirewallCreationConfigAction?: FMSPolicyUpdateFirewallCreationConfigAction;
    CreateNetworkAclAction?: CreateNetworkAclAction;
    ReplaceNetworkAclAssociationAction?: ReplaceNetworkAclAssociationAction;
    CreateNetworkAclEntriesAction?: CreateNetworkAclEntriesAction;
    DeleteNetworkAclEntriesAction?: DeleteNetworkAclEntriesAction;
}
export declare const RemediationAction: S.Schema<RemediationAction>;
export interface RemediationActionWithOrder {
    RemediationAction?: RemediationAction;
    Order?: number;
}
export declare const RemediationActionWithOrder: S.Schema<RemediationActionWithOrder>;
export type OrderedRemediationActions = RemediationActionWithOrder[];
export declare const OrderedRemediationActions: any;
export interface PossibleRemediationAction {
    Description?: string;
    OrderedRemediationActions: RemediationActionWithOrder[];
    IsDefaultAction?: boolean;
}
export declare const PossibleRemediationAction: S.Schema<PossibleRemediationAction>;
export type PossibleRemediationActionList = PossibleRemediationAction[];
export declare const PossibleRemediationActionList: any;
export interface PossibleRemediationActions {
    Description?: string;
    Actions?: PossibleRemediationAction[];
}
export declare const PossibleRemediationActions: S.Schema<PossibleRemediationActions>;
export interface WebACLHasIncompatibleConfigurationViolation {
    WebACLArn?: string;
    Description?: string;
}
export declare const WebACLHasIncompatibleConfigurationViolation: S.Schema<WebACLHasIncompatibleConfigurationViolation>;
export type ResourceArnList = string[];
export declare const ResourceArnList: any;
export interface WebACLHasOutOfScopeResourcesViolation {
    WebACLArn?: string;
    OutOfScopeResourceList?: string[];
}
export declare const WebACLHasOutOfScopeResourcesViolation: S.Schema<WebACLHasOutOfScopeResourcesViolation>;
export interface ResourceViolation {
    AwsVPCSecurityGroupViolation?: AwsVPCSecurityGroupViolation;
    AwsEc2NetworkInterfaceViolation?: AwsEc2NetworkInterfaceViolation;
    AwsEc2InstanceViolation?: AwsEc2InstanceViolation;
    NetworkFirewallMissingFirewallViolation?: NetworkFirewallMissingFirewallViolation;
    NetworkFirewallMissingSubnetViolation?: NetworkFirewallMissingSubnetViolation;
    NetworkFirewallMissingExpectedRTViolation?: NetworkFirewallMissingExpectedRTViolation;
    NetworkFirewallPolicyModifiedViolation?: NetworkFirewallPolicyModifiedViolation;
    NetworkFirewallInternetTrafficNotInspectedViolation?: NetworkFirewallInternetTrafficNotInspectedViolation;
    NetworkFirewallInvalidRouteConfigurationViolation?: NetworkFirewallInvalidRouteConfigurationViolation;
    NetworkFirewallBlackHoleRouteDetectedViolation?: NetworkFirewallBlackHoleRouteDetectedViolation;
    NetworkFirewallUnexpectedFirewallRoutesViolation?: NetworkFirewallUnexpectedFirewallRoutesViolation;
    NetworkFirewallUnexpectedGatewayRoutesViolation?: NetworkFirewallUnexpectedGatewayRoutesViolation;
    NetworkFirewallMissingExpectedRoutesViolation?: NetworkFirewallMissingExpectedRoutesViolation;
    DnsRuleGroupPriorityConflictViolation?: DnsRuleGroupPriorityConflictViolation;
    DnsDuplicateRuleGroupViolation?: DnsDuplicateRuleGroupViolation;
    DnsRuleGroupLimitExceededViolation?: DnsRuleGroupLimitExceededViolation;
    FirewallSubnetIsOutOfScopeViolation?: FirewallSubnetIsOutOfScopeViolation;
    RouteHasOutOfScopeEndpointViolation?: RouteHasOutOfScopeEndpointViolation;
    ThirdPartyFirewallMissingFirewallViolation?: ThirdPartyFirewallMissingFirewallViolation;
    ThirdPartyFirewallMissingSubnetViolation?: ThirdPartyFirewallMissingSubnetViolation;
    ThirdPartyFirewallMissingExpectedRouteTableViolation?: ThirdPartyFirewallMissingExpectedRouteTableViolation;
    FirewallSubnetMissingVPCEndpointViolation?: FirewallSubnetMissingVPCEndpointViolation;
    InvalidNetworkAclEntriesViolation?: InvalidNetworkAclEntriesViolation;
    PossibleRemediationActions?: PossibleRemediationActions;
    WebACLHasIncompatibleConfigurationViolation?: WebACLHasIncompatibleConfigurationViolation;
    WebACLHasOutOfScopeResourcesViolation?: WebACLHasOutOfScopeResourcesViolation;
}
export declare const ResourceViolation: S.Schema<ResourceViolation>;
export type ResourceViolations = ResourceViolation[];
export declare const ResourceViolations: any;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface ViolationDetail {
    PolicyId: string;
    MemberAccount: string;
    ResourceId: string;
    ResourceType: string;
    ResourceViolations: ResourceViolation[];
    ResourceTags?: Tag[];
    ResourceDescription?: string;
}
export declare const ViolationDetail: S.Schema<ViolationDetail>;
export interface GetViolationDetailsResponse {
    ViolationDetail?: ViolationDetail;
}
export declare const GetViolationDetailsResponse: S.Schema<GetViolationDetailsResponse>;
export interface ListAdminAccountsForOrganizationRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListAdminAccountsForOrganizationRequest: S.Schema<ListAdminAccountsForOrganizationRequest>;
export interface AdminAccountSummary {
    AdminAccount?: string;
    DefaultAdmin?: boolean;
    Status?: OrganizationStatus;
}
export declare const AdminAccountSummary: S.Schema<AdminAccountSummary>;
export type AdminAccountSummaryList = AdminAccountSummary[];
export declare const AdminAccountSummaryList: any;
export interface ListAdminAccountsForOrganizationResponse {
    AdminAccounts?: AdminAccountSummary[];
    NextToken?: string;
}
export declare const ListAdminAccountsForOrganizationResponse: S.Schema<ListAdminAccountsForOrganizationResponse>;
export interface ListAdminsManagingAccountRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListAdminsManagingAccountRequest: S.Schema<ListAdminsManagingAccountRequest>;
export interface ListAdminsManagingAccountResponse {
    AdminAccounts?: string[];
    NextToken?: string;
}
export declare const ListAdminsManagingAccountResponse: S.Schema<ListAdminsManagingAccountResponse>;
export interface ListAppsListsRequest {
    DefaultLists?: boolean;
    NextToken?: string;
    MaxResults: number;
}
export declare const ListAppsListsRequest: S.Schema<ListAppsListsRequest>;
export interface AppsListDataSummary {
    ListArn?: string;
    ListId?: string;
    ListName?: string;
    AppsList?: App[];
}
export declare const AppsListDataSummary: S.Schema<AppsListDataSummary>;
export type AppsListsData = AppsListDataSummary[];
export declare const AppsListsData: any;
export interface ListAppsListsResponse {
    AppsLists?: AppsListDataSummary[];
    NextToken?: string;
}
export declare const ListAppsListsResponse: S.Schema<ListAppsListsResponse>;
export interface ListComplianceStatusRequest {
    PolicyId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListComplianceStatusRequest: S.Schema<ListComplianceStatusRequest>;
export type PolicyComplianceStatusType = "COMPLIANT" | "NON_COMPLIANT" | (string & {});
export declare const PolicyComplianceStatusType: any;
export type ResourceCount = number;
export interface EvaluationResult {
    ComplianceStatus?: PolicyComplianceStatusType;
    ViolatorCount?: number;
    EvaluationLimitExceeded?: boolean;
}
export declare const EvaluationResult: S.Schema<EvaluationResult>;
export type EvaluationResults = EvaluationResult[];
export declare const EvaluationResults: any;
export interface PolicyComplianceStatus {
    PolicyOwner?: string;
    PolicyId?: string;
    PolicyName?: string;
    MemberAccount?: string;
    EvaluationResults?: EvaluationResult[];
    LastUpdated?: Date;
    IssueInfoMap?: {
        [key: string]: string | undefined;
    };
}
export declare const PolicyComplianceStatus: S.Schema<PolicyComplianceStatus>;
export type PolicyComplianceStatusList = PolicyComplianceStatus[];
export declare const PolicyComplianceStatusList: any;
export interface ListComplianceStatusResponse {
    PolicyComplianceStatusList?: PolicyComplianceStatus[];
    NextToken?: string;
}
export declare const ListComplianceStatusResponse: S.Schema<ListComplianceStatusResponse>;
export type AWSAccountIdList = string[];
export declare const AWSAccountIdList: any;
export interface ListDiscoveredResourcesRequest {
    MemberAccountIds: string[];
    ResourceType: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDiscoveredResourcesRequest: S.Schema<ListDiscoveredResourcesRequest>;
export interface DiscoveredResource {
    URI?: string;
    AccountId?: string;
    Type?: string;
    Name?: string;
}
export declare const DiscoveredResource: S.Schema<DiscoveredResource>;
export type DiscoveredResourceList = DiscoveredResource[];
export declare const DiscoveredResourceList: any;
export interface ListDiscoveredResourcesResponse {
    Items?: DiscoveredResource[];
    NextToken?: string;
}
export declare const ListDiscoveredResourcesResponse: S.Schema<ListDiscoveredResourcesResponse>;
export interface ListMemberAccountsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListMemberAccountsRequest: S.Schema<ListMemberAccountsRequest>;
export type MemberAccounts = string[];
export declare const MemberAccounts: any;
export interface ListMemberAccountsResponse {
    MemberAccounts?: string[];
    NextToken?: string;
}
export declare const ListMemberAccountsResponse: S.Schema<ListMemberAccountsResponse>;
export interface ListPoliciesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListPoliciesRequest: S.Schema<ListPoliciesRequest>;
export interface PolicySummary {
    PolicyArn?: string;
    PolicyId?: string;
    PolicyName?: string;
    ResourceType?: string;
    SecurityServiceType?: SecurityServiceType;
    RemediationEnabled?: boolean;
    DeleteUnusedFMManagedResources?: boolean;
    PolicyStatus?: CustomerPolicyStatus;
}
export declare const PolicySummary: S.Schema<PolicySummary>;
export type PolicySummaryList = PolicySummary[];
export declare const PolicySummaryList: any;
export interface ListPoliciesResponse {
    PolicyList?: PolicySummary[];
    NextToken?: string;
}
export declare const ListPoliciesResponse: S.Schema<ListPoliciesResponse>;
export interface ListProtocolsListsRequest {
    DefaultLists?: boolean;
    NextToken?: string;
    MaxResults: number;
}
export declare const ListProtocolsListsRequest: S.Schema<ListProtocolsListsRequest>;
export interface ProtocolsListDataSummary {
    ListArn?: string;
    ListId?: string;
    ListName?: string;
    ProtocolsList?: string[];
}
export declare const ProtocolsListDataSummary: S.Schema<ProtocolsListDataSummary>;
export type ProtocolsListsData = ProtocolsListDataSummary[];
export declare const ProtocolsListsData: any;
export interface ListProtocolsListsResponse {
    ProtocolsLists?: ProtocolsListDataSummary[];
    NextToken?: string;
}
export declare const ListProtocolsListsResponse: S.Schema<ListProtocolsListsResponse>;
export interface ListResourceSetResourcesRequest {
    Identifier: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListResourceSetResourcesRequest: S.Schema<ListResourceSetResourcesRequest>;
export interface Resource {
    URI: string;
    AccountId?: string;
}
export declare const Resource: S.Schema<Resource>;
export type ResourceList = Resource[];
export declare const ResourceList: any;
export interface ListResourceSetResourcesResponse {
    Items: Resource[];
    NextToken?: string;
}
export declare const ListResourceSetResourcesResponse: S.Schema<ListResourceSetResourcesResponse>;
export interface ListResourceSetsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListResourceSetsRequest: S.Schema<ListResourceSetsRequest>;
export interface ResourceSetSummary {
    Id?: string;
    Name?: string;
    Description?: string;
    LastUpdateTime?: Date;
    ResourceSetStatus?: ResourceSetStatus;
}
export declare const ResourceSetSummary: S.Schema<ResourceSetSummary>;
export type ResourceSetSummaryList = ResourceSetSummary[];
export declare const ResourceSetSummaryList: any;
export interface ListResourceSetsResponse {
    ResourceSets?: ResourceSetSummary[];
    NextToken?: string;
}
export declare const ListResourceSetsResponse: S.Schema<ListResourceSetsResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    TagList?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListThirdPartyFirewallFirewallPoliciesRequest {
    ThirdPartyFirewall: ThirdPartyFirewall;
    NextToken?: string;
    MaxResults: number;
}
export declare const ListThirdPartyFirewallFirewallPoliciesRequest: S.Schema<ListThirdPartyFirewallFirewallPoliciesRequest>;
export type FirewallPolicyId = string;
export type FirewallPolicyName = string;
export interface ThirdPartyFirewallFirewallPolicy {
    FirewallPolicyId?: string;
    FirewallPolicyName?: string;
}
export declare const ThirdPartyFirewallFirewallPolicy: S.Schema<ThirdPartyFirewallFirewallPolicy>;
export type ThirdPartyFirewallFirewallPolicies = ThirdPartyFirewallFirewallPolicy[];
export declare const ThirdPartyFirewallFirewallPolicies: any;
export interface ListThirdPartyFirewallFirewallPoliciesResponse {
    ThirdPartyFirewallFirewallPolicies?: ThirdPartyFirewallFirewallPolicy[];
    NextToken?: string;
}
export declare const ListThirdPartyFirewallFirewallPoliciesResponse: S.Schema<ListThirdPartyFirewallFirewallPoliciesResponse>;
export interface PutAdminAccountRequest {
    AdminAccount: string;
    AdminScope?: AdminScope;
}
export declare const PutAdminAccountRequest: S.Schema<PutAdminAccountRequest>;
export interface PutAdminAccountResponse {
}
export declare const PutAdminAccountResponse: S.Schema<PutAdminAccountResponse>;
export interface PutAppsListRequest {
    AppsList: AppsListData;
    TagList?: Tag[];
}
export declare const PutAppsListRequest: S.Schema<PutAppsListRequest>;
export interface PutAppsListResponse {
    AppsList?: AppsListData;
    AppsListArn?: string;
}
export declare const PutAppsListResponse: S.Schema<PutAppsListResponse>;
export interface PutNotificationChannelRequest {
    SnsTopicArn: string;
    SnsRoleName: string;
}
export declare const PutNotificationChannelRequest: S.Schema<PutNotificationChannelRequest>;
export interface PutNotificationChannelResponse {
}
export declare const PutNotificationChannelResponse: S.Schema<PutNotificationChannelResponse>;
export interface PutPolicyRequest {
    Policy: Policy;
    TagList?: Tag[];
}
export declare const PutPolicyRequest: S.Schema<PutPolicyRequest>;
export interface PutPolicyResponse {
    Policy?: Policy;
    PolicyArn?: string;
}
export declare const PutPolicyResponse: S.Schema<PutPolicyResponse>;
export interface PutProtocolsListRequest {
    ProtocolsList: ProtocolsListData;
    TagList?: Tag[];
}
export declare const PutProtocolsListRequest: S.Schema<PutProtocolsListRequest>;
export interface PutProtocolsListResponse {
    ProtocolsList?: ProtocolsListData;
    ProtocolsListArn?: string;
}
export declare const PutProtocolsListResponse: S.Schema<PutProtocolsListResponse>;
export interface PutResourceSetRequest {
    ResourceSet: ResourceSet;
    TagList?: Tag[];
}
export declare const PutResourceSetRequest: S.Schema<PutResourceSetRequest>;
export interface PutResourceSetResponse {
    ResourceSet: ResourceSet;
    ResourceSetArn: string;
}
export declare const PutResourceSetResponse: S.Schema<PutResourceSetResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    TagList: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type ErrorMessage = string;
export type AssociateAdminAccountError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Sets a Firewall Manager default administrator account. The Firewall Manager default administrator account can manage third-party firewalls and has full administrative scope that allows administration of all policy types, accounts, organizational units, and Regions. This account must be a member account of the organization in Organizations whose resources you want to protect.
 *
 * For information about working with Firewall Manager administrator accounts, see Managing Firewall Manager administrators in the *Firewall Manager Developer Guide*.
 */
export declare const associateAdminAccount: API.OperationMethod<AssociateAdminAccountRequest, AssociateAdminAccountResponse, AssociateAdminAccountError, Credentials | HttpClient.HttpClient>;
export type AssociateThirdPartyFirewallError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Sets the Firewall Manager policy administrator as a tenant administrator of a third-party firewall service. A tenant is an instance of the third-party firewall service that's associated with your Amazon Web Services customer account.
 */
export declare const associateThirdPartyFirewall: API.OperationMethod<AssociateThirdPartyFirewallRequest, AssociateThirdPartyFirewallResponse, AssociateThirdPartyFirewallError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateResourceError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Associate resources to a Firewall Manager resource set.
 */
export declare const batchAssociateResource: API.OperationMethod<BatchAssociateResourceRequest, BatchAssociateResourceResponse, BatchAssociateResourceError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateResourceError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates resources from a Firewall Manager resource set.
 */
export declare const batchDisassociateResource: API.OperationMethod<BatchDisassociateResourceRequest, BatchDisassociateResourceResponse, BatchDisassociateResourceError, Credentials | HttpClient.HttpClient>;
export type DeleteAppsListError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Permanently deletes an Firewall Manager applications list.
 */
export declare const deleteAppsList: API.OperationMethod<DeleteAppsListRequest, DeleteAppsListResponse, DeleteAppsListError, Credentials | HttpClient.HttpClient>;
export type DeleteNotificationChannelError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Firewall Manager association with the IAM role and the Amazon Simple
 * Notification Service (SNS) topic that is used to record Firewall Manager SNS logs.
 */
export declare const deleteNotificationChannel: API.OperationMethod<DeleteNotificationChannelRequest, DeleteNotificationChannelResponse, DeleteNotificationChannelError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Permanently deletes an Firewall Manager policy.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest, DeletePolicyResponse, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteProtocolsListError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Permanently deletes an Firewall Manager protocols list.
 */
export declare const deleteProtocolsList: API.OperationMethod<DeleteProtocolsListRequest, DeleteProtocolsListResponse, DeleteProtocolsListError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceSetError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified ResourceSet.
 */
export declare const deleteResourceSet: API.OperationMethod<DeleteResourceSetRequest, DeleteResourceSetResponse, DeleteResourceSetError, Credentials | HttpClient.HttpClient>;
export type DisassociateAdminAccountError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates an Firewall Manager administrator account. To set a different account as an Firewall Manager administrator, submit a PutAdminAccount request. To set an account as a default administrator account, you must submit an AssociateAdminAccount request.
 *
 * Disassociation of the default administrator account follows the first in, last out principle. If you are the default administrator, all Firewall Manager administrators within the organization must first disassociate their accounts before you can disassociate your account.
 */
export declare const disassociateAdminAccount: API.OperationMethod<DisassociateAdminAccountRequest, DisassociateAdminAccountResponse, DisassociateAdminAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateThirdPartyFirewallError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates a Firewall Manager policy administrator from a third-party firewall tenant. When you call `DisassociateThirdPartyFirewall`, the third-party firewall vendor deletes all of the firewalls that are associated with the account.
 */
export declare const disassociateThirdPartyFirewall: API.OperationMethod<DisassociateThirdPartyFirewallRequest, DisassociateThirdPartyFirewallResponse, DisassociateThirdPartyFirewallError, Credentials | HttpClient.HttpClient>;
export type GetAdminAccountError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the Organizations account that is associated with Firewall Manager
 * as the Firewall Manager default administrator.
 */
export declare const getAdminAccount: API.OperationMethod<GetAdminAccountRequest, GetAdminAccountResponse, GetAdminAccountError, Credentials | HttpClient.HttpClient>;
export type GetAdminScopeError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the specified account's administrative scope. The administrative scope defines the resources that an Firewall Manager administrator can manage.
 */
export declare const getAdminScope: API.OperationMethod<GetAdminScopeRequest, GetAdminScopeResponse, GetAdminScopeError, Credentials | HttpClient.HttpClient>;
export type GetAppsListError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the specified Firewall Manager applications list.
 */
export declare const getAppsList: API.OperationMethod<GetAppsListRequest, GetAppsListResponse, GetAppsListError, Credentials | HttpClient.HttpClient>;
export type GetComplianceDetailError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns detailed compliance information about the specified member account. Details
 * include resources that are in and out of compliance with the specified policy.
 *
 * The reasons for resources being considered compliant depend on the Firewall Manager policy type.
 */
export declare const getComplianceDetail: API.OperationMethod<GetComplianceDetailRequest, GetComplianceDetailResponse, GetComplianceDetailError, Credentials | HttpClient.HttpClient>;
export type GetNotificationChannelError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Information
 * about the Amazon Simple Notification Service (SNS) topic that is used to
 * record Firewall Manager SNS logs.
 */
export declare const getNotificationChannel: API.OperationMethod<GetNotificationChannelRequest, GetNotificationChannelResponse, GetNotificationChannelError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = InternalErrorException | InvalidOperationException | InvalidTypeException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the specified Firewall Manager policy.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest, GetPolicyResponse, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetProtectionStatusError = InternalErrorException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * If you created a Shield Advanced policy, returns policy-level attack summary information
 * in the event of a potential DDoS attack. Other policy types are currently unsupported.
 */
export declare const getProtectionStatus: API.OperationMethod<GetProtectionStatusRequest, GetProtectionStatusResponse, GetProtectionStatusError, Credentials | HttpClient.HttpClient>;
export type GetProtocolsListError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the specified Firewall Manager protocols list.
 */
export declare const getProtocolsList: API.OperationMethod<GetProtocolsListRequest, GetProtocolsListResponse, GetProtocolsListError, Credentials | HttpClient.HttpClient>;
export type GetResourceSetError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about a specific resource set.
 */
export declare const getResourceSet: API.OperationMethod<GetResourceSetRequest, GetResourceSetResponse, GetResourceSetError, Credentials | HttpClient.HttpClient>;
export type GetThirdPartyFirewallAssociationStatusError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * The onboarding status of a Firewall Manager admin account to third-party firewall vendor tenant.
 */
export declare const getThirdPartyFirewallAssociationStatus: API.OperationMethod<GetThirdPartyFirewallAssociationStatusRequest, GetThirdPartyFirewallAssociationStatusResponse, GetThirdPartyFirewallAssociationStatusError, Credentials | HttpClient.HttpClient>;
export type GetViolationDetailsError = InternalErrorException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves violations for a resource based on the specified Firewall Manager policy and Amazon Web Services account.
 */
export declare const getViolationDetails: API.OperationMethod<GetViolationDetailsRequest, GetViolationDetailsResponse, GetViolationDetailsError, Credentials | HttpClient.HttpClient>;
export type ListAdminAccountsForOrganizationError = InternalErrorException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a `AdminAccounts` object that lists the Firewall Manager administrators within the organization that are onboarded to Firewall Manager by AssociateAdminAccount.
 *
 * This operation can be called only from the organization's management account.
 */
export declare const listAdminAccountsForOrganization: API.PaginatedOperationMethod<ListAdminAccountsForOrganizationRequest, ListAdminAccountsForOrganizationResponse, ListAdminAccountsForOrganizationError, Credentials | HttpClient.HttpClient, AdminAccountSummary>;
export type ListAdminsManagingAccountError = InternalErrorException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the accounts that are managing the specified Organizations member account. This is useful for any member account so that they can view the accounts who are managing their account. This operation only returns the managing administrators that have the requested account within their AdminScope.
 */
export declare const listAdminsManagingAccount: API.PaginatedOperationMethod<ListAdminsManagingAccountRequest, ListAdminsManagingAccountResponse, ListAdminsManagingAccountError, Credentials | HttpClient.HttpClient, AWSAccountId>;
export type ListAppsListsError = InternalErrorException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an array of `AppsListDataSummary` objects.
 */
export declare const listAppsLists: API.PaginatedOperationMethod<ListAppsListsRequest, ListAppsListsResponse, ListAppsListsError, Credentials | HttpClient.HttpClient, AppsListDataSummary>;
export type ListComplianceStatusError = InternalErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an array of `PolicyComplianceStatus` objects. Use
 * `PolicyComplianceStatus` to get a summary of which member accounts are protected
 * by the specified policy.
 */
export declare const listComplianceStatus: API.PaginatedOperationMethod<ListComplianceStatusRequest, ListComplianceStatusResponse, ListComplianceStatusError, Credentials | HttpClient.HttpClient, PolicyComplianceStatus>;
export type ListDiscoveredResourcesError = InternalErrorException | InvalidInputException | InvalidOperationException | CommonErrors;
/**
 * Returns an array of resources in the organization's accounts that are available to be associated with a resource set.
 */
export declare const listDiscoveredResources: API.OperationMethod<ListDiscoveredResourcesRequest, ListDiscoveredResourcesResponse, ListDiscoveredResourcesError, Credentials | HttpClient.HttpClient>;
export type ListMemberAccountsError = InternalErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a `MemberAccounts` object that lists the member accounts in the
 * administrator's Amazon Web Services organization.
 *
 * Either an Firewall Manager administrator or the organization's management account can make this request.
 */
export declare const listMemberAccounts: API.PaginatedOperationMethod<ListMemberAccountsRequest, ListMemberAccountsResponse, ListMemberAccountsError, Credentials | HttpClient.HttpClient, AWSAccountId>;
export type ListPoliciesError = InternalErrorException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an array of `PolicySummary` objects.
 */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesRequest, ListPoliciesResponse, ListPoliciesError, Credentials | HttpClient.HttpClient, PolicySummary>;
export type ListProtocolsListsError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an array of `ProtocolsListDataSummary` objects.
 */
export declare const listProtocolsLists: API.PaginatedOperationMethod<ListProtocolsListsRequest, ListProtocolsListsResponse, ListProtocolsListsError, Credentials | HttpClient.HttpClient, ProtocolsListDataSummary>;
export type ListResourceSetResourcesError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an array of resources that are currently associated to a resource set.
 */
export declare const listResourceSetResources: API.OperationMethod<ListResourceSetResourcesRequest, ListResourceSetResourcesResponse, ListResourceSetResourcesError, Credentials | HttpClient.HttpClient>;
export type ListResourceSetsError = InternalErrorException | InvalidInputException | InvalidOperationException | CommonErrors;
/**
 * Returns an array of `ResourceSetSummary` objects.
 */
export declare const listResourceSets: API.OperationMethod<ListResourceSetsRequest, ListResourceSetsResponse, ListResourceSetsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the list of tags for the specified Amazon Web Services resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListThirdPartyFirewallFirewallPoliciesError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list of all of the third-party firewall policies that are associated with the third-party firewall administrator's account.
 */
export declare const listThirdPartyFirewallFirewallPolicies: API.PaginatedOperationMethod<ListThirdPartyFirewallFirewallPoliciesRequest, ListThirdPartyFirewallFirewallPoliciesResponse, ListThirdPartyFirewallFirewallPoliciesError, Credentials | HttpClient.HttpClient, ThirdPartyFirewallFirewallPolicy>;
export type PutAdminAccountError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | CommonErrors;
/**
 * Creates or updates an Firewall Manager administrator account. The account must be a member of the organization that was onboarded to Firewall Manager by AssociateAdminAccount. Only the organization's management account can create an Firewall Manager administrator account. When you create an Firewall Manager administrator account, the service checks to see if the account is already a delegated administrator within Organizations. If the account isn't a delegated administrator, Firewall Manager calls Organizations to delegate the account within Organizations. For more information about administrator accounts within Organizations, see
 * Managing the Amazon Web Services Accounts in Your Organization.
 */
export declare const putAdminAccount: API.OperationMethod<PutAdminAccountRequest, PutAdminAccountResponse, PutAdminAccountError, Credentials | HttpClient.HttpClient>;
export type PutAppsListError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an Firewall Manager applications list.
 */
export declare const putAppsList: API.OperationMethod<PutAppsListRequest, PutAppsListResponse, PutAppsListError, Credentials | HttpClient.HttpClient>;
export type PutNotificationChannelError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Designates the IAM role and Amazon Simple Notification Service (SNS) topic that
 * Firewall Manager uses to record SNS logs.
 *
 * To perform this action outside of the console, you must first configure the SNS topic's access policy to allow the `SnsRoleName` to publish SNS logs. If the `SnsRoleName` provided is a role other than the `AWSServiceRoleForFMS` service-linked role, this role must have a trust relationship configured to allow the Firewall Manager service principal `fms.amazonaws.com` to assume this role. For information about configuring an SNS access policy, see
 * Service roles for Firewall Manager in the *Firewall Manager Developer Guide*.
 */
export declare const putNotificationChannel: API.OperationMethod<PutNotificationChannelRequest, PutNotificationChannelResponse, PutNotificationChannelError, Credentials | HttpClient.HttpClient>;
export type PutPolicyError = InternalErrorException | InvalidInputException | InvalidOperationException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an Firewall Manager policy.
 *
 * A Firewall Manager policy is specific to the individual policy type. If you want to enforce multiple
 * policy types across accounts, you can create multiple policies. You can create more than one
 * policy for each type.
 *
 * If you add a new account to an organization that you created with Organizations, Firewall Manager
 * automatically applies the policy to the resources in that account that are within scope of
 * the policy.
 *
 * Firewall Manager provides the following types of policies:
 *
 * - **WAF policy** - This policy applies WAF web ACL
 * protections to specified accounts and resources.
 *
 * - **Shield Advanced policy** - This policy applies Shield Advanced
 * protection to specified accounts and resources.
 *
 * - **Security Groups policy** - This type of policy gives you
 * control over security groups that are in use throughout your organization in
 * Organizations and lets you enforce a baseline set of rules across your organization.
 *
 * - **Network ACL policy** - This type of policy gives you
 * control over the network ACLs that are in use throughout your organization in
 * Organizations and lets you enforce a baseline set of first and last network ACL rules across your organization.
 *
 * - **Network Firewall policy** - This policy applies
 * Network Firewall protection to your organization's VPCs.
 *
 * - **DNS Firewall policy** - This policy applies
 * Amazon Route 53 Resolver DNS Firewall protections to your organization's VPCs.
 *
 * - **Third-party firewall policy** - This policy applies third-party firewall protections. Third-party firewalls are available by subscription through the Amazon Web Services Marketplace console at Amazon Web Services Marketplace.
 *
 * - **Palo Alto Networks Cloud NGFW policy** - This policy applies Palo Alto Networks Cloud Next Generation Firewall (NGFW) protections and Palo Alto Networks Cloud NGFW rulestacks to your organization's VPCs.
 *
 * - **Fortigate CNF policy** - This policy applies
 * Fortigate Cloud Native Firewall (CNF) protections. Fortigate CNF is a cloud-centered solution that blocks Zero-Day threats and secures cloud infrastructures with industry-leading advanced threat prevention, smart web application firewalls (WAF), and API protection.
 */
export declare const putPolicy: API.OperationMethod<PutPolicyRequest, PutPolicyResponse, PutPolicyError, Credentials | HttpClient.HttpClient>;
export type PutProtocolsListError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an Firewall Manager protocols list.
 */
export declare const putProtocolsList: API.OperationMethod<PutProtocolsListRequest, PutProtocolsListResponse, PutProtocolsListError, Credentials | HttpClient.HttpClient>;
export type PutResourceSetError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | CommonErrors;
/**
 * Creates the resource set.
 *
 * An Firewall Manager resource set defines the resources to import into an Firewall Manager policy from another Amazon Web Services service.
 */
export declare const putResourceSet: API.OperationMethod<PutResourceSetRequest, PutResourceSetResponse, PutResourceSetError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Adds one or more tags to an Amazon Web Services resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from an Amazon Web Services resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=fms.d.ts.map