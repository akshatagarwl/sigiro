import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly message: any;
    readonly Reason: any;
    readonly Details: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const PayloadTooLargeException_base: S.Class<PayloadTooLargeException, S.TaggedStruct<"PayloadTooLargeException", {
    readonly message: any;
    readonly Measure: any;
    readonly Limit: any;
    readonly Size: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PayloadTooLargeException extends /*@__PURE__*/ PayloadTooLargeException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
export type Name = string;
export type Description = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateApplicationRequest {
    Name: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateApplicationRequest: S.Schema<CreateApplicationRequest>;
export type Id = string;
export interface Application {
    Id?: string;
    Name?: string;
    Description?: string;
}
export declare const Application: S.Schema<Application>;
export type LongName = string;
export type Uri = string;
export type RoleArn = string;
export type ValidatorType = "JSON_SCHEMA" | "LAMBDA" | (string & {});
export declare const ValidatorType: any;
export type StringWithLengthBetween0And32768 = string | redacted.Redacted<string>;
export interface Validator {
    Type: ValidatorType;
    Content: string | redacted.Redacted<string>;
}
export declare const Validator: S.Schema<Validator>;
export type ValidatorList = Validator[];
export declare const ValidatorList: any;
export type ConfigurationProfileType = string;
export type KmsKeyIdentifier = string;
export interface CreateConfigurationProfileRequest {
    ApplicationId: string;
    Name: string;
    Description?: string;
    LocationUri: string;
    RetrievalRoleArn?: string;
    Validators?: Validator[];
    Tags?: {
        [key: string]: string | undefined;
    };
    Type?: string;
    KmsKeyIdentifier?: string;
}
export declare const CreateConfigurationProfileRequest: S.Schema<CreateConfigurationProfileRequest>;
export type Arn = string;
export interface ConfigurationProfile {
    ApplicationId?: string;
    Id?: string;
    Name?: string;
    Description?: string;
    LocationUri?: string;
    RetrievalRoleArn?: string;
    Validators?: Validator[];
    Type?: string;
    KmsKeyArn?: string;
    KmsKeyIdentifier?: string;
}
export declare const ConfigurationProfile: S.Schema<ConfigurationProfile>;
export type MinutesBetween0And24Hours = number;
export type GrowthFactor = number;
export type GrowthType = "LINEAR" | "EXPONENTIAL" | (string & {});
export declare const GrowthType: any;
export type ReplicateTo = "NONE" | "SSM_DOCUMENT" | (string & {});
export declare const ReplicateTo: any;
export interface CreateDeploymentStrategyRequest {
    Name: string;
    Description?: string;
    DeploymentDurationInMinutes: number;
    FinalBakeTimeInMinutes?: number;
    GrowthFactor: number;
    GrowthType?: GrowthType;
    ReplicateTo?: ReplicateTo;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDeploymentStrategyRequest: S.Schema<CreateDeploymentStrategyRequest>;
export type Percentage = number;
export interface DeploymentStrategy {
    Id?: string;
    Name?: string;
    Description?: string;
    DeploymentDurationInMinutes?: number;
    GrowthType?: GrowthType;
    GrowthFactor?: number;
    FinalBakeTimeInMinutes?: number;
    ReplicateTo?: ReplicateTo;
}
export declare const DeploymentStrategy: S.Schema<DeploymentStrategy>;
export type StringWithLengthBetween1And2048 = string;
export interface Monitor {
    AlarmArn: string;
    AlarmRoleArn?: string;
}
export declare const Monitor: S.Schema<Monitor>;
export type MonitorList = Monitor[];
export declare const MonitorList: any;
export interface CreateEnvironmentRequest {
    ApplicationId: string;
    Name: string;
    Description?: string;
    Monitors?: Monitor[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateEnvironmentRequest: S.Schema<CreateEnvironmentRequest>;
export type EnvironmentState = "READY_FOR_DEPLOYMENT" | "DEPLOYING" | "ROLLING_BACK" | "ROLLED_BACK" | "REVERTED" | (string & {});
export declare const EnvironmentState: any;
export interface Environment {
    ApplicationId?: string;
    Id?: string;
    Name?: string;
    Description?: string;
    State?: EnvironmentState;
    Monitors?: Monitor[];
}
export declare const Environment: S.Schema<Environment>;
export type Identifier = string;
export type NameWithReservedAwsPrefix = string;
export type FlagKey = string;
export type Weight = number;
export type AttributeKey = string;
export type AttributeString = string;
export type StringList = string[];
export declare const StringList: any;
export type NumberList = number[];
export declare const NumberList: any;
export type AttributeValue = {
    StringValue: string;
    NumberValue?: never;
    BooleanValue?: never;
    StringArray?: never;
    NumberArray?: never;
} | {
    StringValue?: never;
    NumberValue: number;
    BooleanValue?: never;
    StringArray?: never;
    NumberArray?: never;
} | {
    StringValue?: never;
    NumberValue?: never;
    BooleanValue: boolean;
    StringArray?: never;
    NumberArray?: never;
} | {
    StringValue?: never;
    NumberValue?: never;
    BooleanValue?: never;
    StringArray: string[];
    NumberArray?: never;
} | {
    StringValue?: never;
    NumberValue?: never;
    BooleanValue?: never;
    StringArray?: never;
    NumberArray: number[];
};
export declare const AttributeValue: any;
export type AttributeValueMap = {
    [key: string]: AttributeValue | undefined;
};
export declare const AttributeValueMap: any;
export interface FlagValue {
    Enabled: boolean;
    AttributeValues?: {
        [key: string]: AttributeValue | undefined;
    };
}
export declare const FlagValue: S.Schema<FlagValue>;
export interface TreatmentInput {
    Weight: number;
    Description?: string;
    FlagValue: FlagValue;
}
export declare const TreatmentInput: S.Schema<TreatmentInput>;
export type TreatmentInputList = TreatmentInput[];
export declare const TreatmentInputList: any;
export type Rule = string;
export interface CreateExperimentDefinitionRequest {
    ApplicationIdentifier: string;
    Name: string;
    ConfigurationProfileIdentifier: string;
    EnvironmentIdentifier: string;
    FlagKey: string;
    Treatments: TreatmentInput[];
    Control: TreatmentInput;
    AudienceRule: string;
    Hypothesis?: string;
    AudienceDescription?: string;
    LaunchCriteria?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateExperimentDefinitionRequest: S.Schema<CreateExperimentDefinitionRequest>;
export type ExperimentDefinitionStatus = "ACTIVE" | "IDLE" | "ARCHIVED" | (string & {});
export declare const ExperimentDefinitionStatus: any;
export type TreatmentKey = string;
export interface Treatment {
    Key?: string;
    Weight: number;
    Description?: string;
    FlagValue: FlagValue;
}
export declare const Treatment: S.Schema<Treatment>;
export type TreatmentList = Treatment[];
export declare const TreatmentList: any;
export type Iso8601DateTime = Date;
export interface ExperimentDefinition {
    ApplicationId?: string;
    Id?: string;
    Name?: string;
    Hypothesis?: string;
    Status?: ExperimentDefinitionStatus;
    ConfigurationProfileId?: string;
    EnvironmentId?: string;
    FlagKey?: string;
    AudienceRule?: string;
    AudienceDescription?: string;
    LaunchCriteria?: string;
    Treatments?: Treatment[];
    Control?: Treatment;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    KmsKeyIdentifier?: string;
}
export declare const ExperimentDefinition: S.Schema<ExperimentDefinition>;
export type ExtensionOrParameterName = string;
export type ActionPoint = "PRE_CREATE_HOSTED_CONFIGURATION_VERSION" | "PRE_START_DEPLOYMENT" | "AT_DEPLOYMENT_TICK" | "ON_DEPLOYMENT_START" | "ON_DEPLOYMENT_STEP" | "ON_DEPLOYMENT_BAKING" | "ON_DEPLOYMENT_COMPLETE" | "ON_DEPLOYMENT_ROLLED_BACK" | (string & {});
export declare const ActionPoint: any;
export interface Action {
    Name?: string;
    Description?: string;
    Uri?: string;
    RoleArn?: string;
}
export declare const Action: S.Schema<Action>;
export type ActionList = Action[];
export declare const ActionList: any;
export type ActionsMap = {
    [key in ActionPoint]?: Action[];
};
export declare const ActionsMap: any;
export interface Parameter {
    Description?: string;
    Required?: boolean;
    Dynamic?: boolean;
}
export declare const Parameter: S.Schema<Parameter>;
export type ParameterMap = {
    [key: string]: Parameter | undefined;
};
export declare const ParameterMap: any;
export interface CreateExtensionRequest {
    Name: string;
    Description?: string;
    Actions: {
        [key: string]: Action[] | undefined;
    };
    Parameters?: {
        [key: string]: Parameter | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
    LatestVersionNumber?: number;
}
export declare const CreateExtensionRequest: S.Schema<CreateExtensionRequest>;
export interface Extension {
    Id?: string;
    Name?: string;
    VersionNumber?: number;
    Arn?: string;
    Description?: string;
    Actions?: {
        [key: string]: Action[] | undefined;
    };
    Parameters?: {
        [key: string]: Parameter | undefined;
    };
}
export declare const Extension: S.Schema<Extension>;
export type ParameterValueMap = {
    [key: string]: string | undefined;
};
export declare const ParameterValueMap: any;
export interface CreateExtensionAssociationRequest {
    ExtensionIdentifier: string;
    ExtensionVersionNumber?: number;
    ResourceIdentifier: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateExtensionAssociationRequest: S.Schema<CreateExtensionAssociationRequest>;
export interface ExtensionAssociation {
    Id?: string;
    ExtensionArn?: string;
    ResourceArn?: string;
    Arn?: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
    ExtensionVersionNumber?: number;
}
export declare const ExtensionAssociation: S.Schema<ExtensionAssociation>;
export type StringWithLengthBetween1And255 = string;
export type VersionLabel = string;
export interface CreateHostedConfigurationVersionRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    Description?: string;
    Content: T.StreamingInputBody;
    ContentType: string;
    LatestVersionNumber?: number;
    VersionLabel?: string;
}
export declare const CreateHostedConfigurationVersionRequest: S.Schema<CreateHostedConfigurationVersionRequest>;
export interface HostedConfigurationVersion {
    ApplicationId?: string;
    ConfigurationProfileId?: string;
    VersionNumber?: number;
    Description?: string;
    Content?: T.StreamingOutputBody;
    ContentType?: string;
    VersionLabel?: string;
    KmsKeyArn?: string;
}
export declare const HostedConfigurationVersion: S.Schema<HostedConfigurationVersion>;
export interface DeleteApplicationRequest {
    ApplicationId: string;
}
export declare const DeleteApplicationRequest: S.Schema<DeleteApplicationRequest>;
export interface DeleteApplicationResponse {
}
export declare const DeleteApplicationResponse: S.Schema<DeleteApplicationResponse>;
export type DeletionProtectionCheck = "ACCOUNT_DEFAULT" | "APPLY" | "BYPASS" | (string & {});
export declare const DeletionProtectionCheck: any;
export interface DeleteConfigurationProfileRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    DeletionProtectionCheck?: DeletionProtectionCheck;
}
export declare const DeleteConfigurationProfileRequest: S.Schema<DeleteConfigurationProfileRequest>;
export interface DeleteConfigurationProfileResponse {
}
export declare const DeleteConfigurationProfileResponse: S.Schema<DeleteConfigurationProfileResponse>;
export type DeploymentStrategyId = string;
export interface DeleteDeploymentStrategyRequest {
    DeploymentStrategyId: string;
}
export declare const DeleteDeploymentStrategyRequest: S.Schema<DeleteDeploymentStrategyRequest>;
export interface DeleteDeploymentStrategyResponse {
}
export declare const DeleteDeploymentStrategyResponse: S.Schema<DeleteDeploymentStrategyResponse>;
export interface DeleteEnvironmentRequest {
    EnvironmentId: string;
    ApplicationId: string;
    DeletionProtectionCheck?: DeletionProtectionCheck;
}
export declare const DeleteEnvironmentRequest: S.Schema<DeleteEnvironmentRequest>;
export interface DeleteEnvironmentResponse {
}
export declare const DeleteEnvironmentResponse: S.Schema<DeleteEnvironmentResponse>;
export type DeleteType = "ARCHIVE" | "DESTROY" | (string & {});
export declare const DeleteType: any;
export interface DeleteExperimentDefinitionRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    DeleteType?: DeleteType;
}
export declare const DeleteExperimentDefinitionRequest: S.Schema<DeleteExperimentDefinitionRequest>;
export interface DeleteExperimentDefinitionResponse {
}
export declare const DeleteExperimentDefinitionResponse: S.Schema<DeleteExperimentDefinitionResponse>;
export interface DeleteExtensionRequest {
    ExtensionIdentifier: string;
    VersionNumber?: number;
}
export declare const DeleteExtensionRequest: S.Schema<DeleteExtensionRequest>;
export interface DeleteExtensionResponse {
}
export declare const DeleteExtensionResponse: S.Schema<DeleteExtensionResponse>;
export interface DeleteExtensionAssociationRequest {
    ExtensionAssociationId: string;
}
export declare const DeleteExtensionAssociationRequest: S.Schema<DeleteExtensionAssociationRequest>;
export interface DeleteExtensionAssociationResponse {
}
export declare const DeleteExtensionAssociationResponse: S.Schema<DeleteExtensionAssociationResponse>;
export interface DeleteHostedConfigurationVersionRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    VersionNumber: number;
}
export declare const DeleteHostedConfigurationVersionRequest: S.Schema<DeleteHostedConfigurationVersionRequest>;
export interface DeleteHostedConfigurationVersionResponse {
}
export declare const DeleteHostedConfigurationVersionResponse: S.Schema<DeleteHostedConfigurationVersionResponse>;
export interface GetAccountSettingsRequest {
}
export declare const GetAccountSettingsRequest: S.Schema<GetAccountSettingsRequest>;
export type DeletionProtectionDuration = number;
export interface DeletionProtectionSettings {
    Enabled?: boolean;
    ProtectionPeriodInMinutes?: number;
}
export declare const DeletionProtectionSettings: S.Schema<DeletionProtectionSettings>;
export interface VendedMetricsSettings {
    Enabled?: boolean;
}
export declare const VendedMetricsSettings: S.Schema<VendedMetricsSettings>;
export interface AccountSettings {
    DeletionProtection?: DeletionProtectionSettings;
    VendedMetrics?: VendedMetricsSettings;
}
export declare const AccountSettings: S.Schema<AccountSettings>;
export interface GetApplicationRequest {
    ApplicationId: string;
}
export declare const GetApplicationRequest: S.Schema<GetApplicationRequest>;
export type StringWithLengthBetween1And64 = string;
export type Version = string;
export interface GetConfigurationRequest {
    Application: string;
    Environment: string;
    Configuration: string;
    ClientId: string;
    ClientConfigurationVersion?: string;
}
export declare const GetConfigurationRequest: S.Schema<GetConfigurationRequest>;
export interface Configuration {
    Content?: T.StreamingOutputBody;
    ConfigurationVersion?: string;
    ContentType?: string;
}
export declare const Configuration: S.Schema<Configuration>;
export interface GetConfigurationProfileRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
}
export declare const GetConfigurationProfileRequest: S.Schema<GetConfigurationProfileRequest>;
export interface GetDeploymentRequest {
    ApplicationId: string;
    EnvironmentId: string;
    DeploymentNumber: number;
}
export declare const GetDeploymentRequest: S.Schema<GetDeploymentRequest>;
export type DeploymentState = "BAKING" | "VALIDATING" | "DEPLOYING" | "COMPLETE" | "ROLLING_BACK" | "ROLLED_BACK" | "REVERTED" | (string & {});
export declare const DeploymentState: any;
export type DeploymentEventType = "PERCENTAGE_UPDATED" | "ROLLBACK_STARTED" | "ROLLBACK_COMPLETED" | "BAKE_TIME_STARTED" | "DEPLOYMENT_STARTED" | "DEPLOYMENT_COMPLETED" | "REVERT_COMPLETED" | (string & {});
export declare const DeploymentEventType: any;
export type TriggeredBy = "USER" | "APPCONFIG" | "CLOUDWATCH_ALARM" | "INTERNAL_ERROR" | (string & {});
export declare const TriggeredBy: any;
export interface ActionInvocation {
    ExtensionIdentifier?: string;
    ActionName?: string;
    Uri?: string;
    RoleArn?: string;
    ErrorMessage?: string;
    ErrorCode?: string;
    InvocationId?: string;
}
export declare const ActionInvocation: S.Schema<ActionInvocation>;
export type ActionInvocations = ActionInvocation[];
export declare const ActionInvocations: any;
export interface DeploymentEvent {
    EventType?: DeploymentEventType;
    TriggeredBy?: TriggeredBy;
    Description?: string;
    ActionInvocations?: ActionInvocation[];
    OccurredAt?: Date;
}
export declare const DeploymentEvent: S.Schema<DeploymentEvent>;
export type DeploymentEvents = DeploymentEvent[];
export declare const DeploymentEvents: any;
export interface AppliedExtension {
    ExtensionId?: string;
    ExtensionAssociationId?: string;
    VersionNumber?: number;
    Parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const AppliedExtension: S.Schema<AppliedExtension>;
export type AppliedExtensions = AppliedExtension[];
export declare const AppliedExtensions: any;
export interface Deployment {
    ApplicationId?: string;
    EnvironmentId?: string;
    DeploymentStrategyId?: string;
    ConfigurationProfileId?: string;
    DeploymentNumber?: number;
    ConfigurationName?: string;
    ConfigurationLocationUri?: string;
    ConfigurationVersion?: string;
    Description?: string;
    DeploymentDurationInMinutes?: number;
    GrowthType?: GrowthType;
    GrowthFactor?: number;
    FinalBakeTimeInMinutes?: number;
    State?: DeploymentState;
    EventLog?: DeploymentEvent[];
    PercentageComplete?: number;
    StartedAt?: Date;
    CompletedAt?: Date;
    AppliedExtensions?: AppliedExtension[];
    KmsKeyArn?: string;
    KmsKeyIdentifier?: string;
    VersionLabel?: string;
}
export declare const Deployment: S.Schema<Deployment>;
export interface GetDeploymentStrategyRequest {
    DeploymentStrategyId: string;
}
export declare const GetDeploymentStrategyRequest: S.Schema<GetDeploymentStrategyRequest>;
export interface GetEnvironmentRequest {
    ApplicationId: string;
    EnvironmentId: string;
}
export declare const GetEnvironmentRequest: S.Schema<GetEnvironmentRequest>;
export interface GetExperimentDefinitionRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
}
export declare const GetExperimentDefinitionRequest: S.Schema<GetExperimentDefinitionRequest>;
export type PositiveInteger = number;
export interface GetExperimentRunRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    Run: number;
}
export declare const GetExperimentRunRequest: S.Schema<GetExperimentRunRequest>;
export type ExperimentRunStatus = "RUNNING" | "DONE" | (string & {});
export declare const ExperimentRunStatus: any;
export type NullablePercentage = number;
export type EntityId = string;
export type TreatmentOverrideMap = {
    [key: string]: string | undefined;
};
export declare const TreatmentOverrideMap: any;
export type TreatmentOverrides = {
    Inline: {
        [key: string]: string | undefined;
    };
};
export declare const TreatmentOverrides: any;
export interface ExperimentRunResult {
    ExecutiveSummary?: string;
    ReasonsToLaunch?: string;
    ReasonsNotToLaunch?: string;
}
export declare const ExperimentRunResult: S.Schema<ExperimentRunResult>;
export interface ExperimentDefinitionSnapshot {
    ApplicationId?: string;
    Id?: string;
    Name?: string;
    Hypothesis?: string;
    ConfigurationProfileId?: string;
    EnvironmentId?: string;
    FlagKey?: string;
    AudienceRule?: string;
    AudienceDescription?: string;
    LaunchCriteria?: string;
    Treatments?: Treatment[];
    Control?: Treatment;
}
export declare const ExperimentDefinitionSnapshot: S.Schema<ExperimentDefinitionSnapshot>;
export interface ExperimentRun {
    ApplicationId?: string;
    ExperimentDefinitionId?: string;
    Run?: number;
    Description?: string;
    Status?: ExperimentRunStatus;
    ExposurePercentage?: number;
    TreatmentOverrides?: TreatmentOverrides;
    Result?: ExperimentRunResult;
    StartedAt?: Date;
    UpdatedAt?: Date;
    EndedAt?: Date;
    ExperimentDefinitionSnapshot?: ExperimentDefinitionSnapshot;
}
export declare const ExperimentRun: S.Schema<ExperimentRun>;
export interface GetExtensionRequest {
    ExtensionIdentifier: string;
    VersionNumber?: number;
}
export declare const GetExtensionRequest: S.Schema<GetExtensionRequest>;
export interface GetExtensionAssociationRequest {
    ExtensionAssociationId: string;
}
export declare const GetExtensionAssociationRequest: S.Schema<GetExtensionAssociationRequest>;
export interface GetHostedConfigurationVersionRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    VersionNumber: number;
}
export declare const GetHostedConfigurationVersionRequest: S.Schema<GetHostedConfigurationVersionRequest>;
export type MaxResults = number;
export type NextToken = string;
export interface ListApplicationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListApplicationsRequest: S.Schema<ListApplicationsRequest>;
export type ApplicationList = Application[];
export declare const ApplicationList: any;
export interface Applications {
    Items?: Application[];
    NextToken?: string;
}
export declare const Applications: S.Schema<Applications>;
export interface ListConfigurationProfilesRequest {
    ApplicationId: string;
    MaxResults?: number;
    NextToken?: string;
    Type?: string;
}
export declare const ListConfigurationProfilesRequest: S.Schema<ListConfigurationProfilesRequest>;
export type ValidatorTypeList = ValidatorType[];
export declare const ValidatorTypeList: any;
export interface ConfigurationProfileSummary {
    ApplicationId?: string;
    Id?: string;
    Name?: string;
    LocationUri?: string;
    ValidatorTypes?: ValidatorType[];
    Type?: string;
}
export declare const ConfigurationProfileSummary: S.Schema<ConfigurationProfileSummary>;
export type ConfigurationProfileSummaryList = ConfigurationProfileSummary[];
export declare const ConfigurationProfileSummaryList: any;
export interface ConfigurationProfiles {
    Items?: ConfigurationProfileSummary[];
    NextToken?: string;
}
export declare const ConfigurationProfiles: S.Schema<ConfigurationProfiles>;
export interface ListDeploymentsRequest {
    ApplicationId: string;
    EnvironmentId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDeploymentsRequest: S.Schema<ListDeploymentsRequest>;
export type DeploymentType = "USER" | "MANAGED" | (string & {});
export declare const DeploymentType: any;
export interface DeploymentSummary {
    DeploymentNumber?: number;
    ConfigurationProfileId?: string;
    ConfigurationName?: string;
    ConfigurationVersion?: string;
    DeploymentDurationInMinutes?: number;
    GrowthType?: GrowthType;
    GrowthFactor?: number;
    FinalBakeTimeInMinutes?: number;
    State?: DeploymentState;
    PercentageComplete?: number;
    StartedAt?: Date;
    CompletedAt?: Date;
    VersionLabel?: string;
    Type?: DeploymentType;
}
export declare const DeploymentSummary: S.Schema<DeploymentSummary>;
export type DeploymentList = DeploymentSummary[];
export declare const DeploymentList: any;
export interface Deployments {
    Items?: DeploymentSummary[];
    NextToken?: string;
}
export declare const Deployments: S.Schema<Deployments>;
export interface ListDeploymentStrategiesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDeploymentStrategiesRequest: S.Schema<ListDeploymentStrategiesRequest>;
export type DeploymentStrategyList = DeploymentStrategy[];
export declare const DeploymentStrategyList: any;
export interface DeploymentStrategies {
    Items?: DeploymentStrategy[];
    NextToken?: string;
}
export declare const DeploymentStrategies: S.Schema<DeploymentStrategies>;
export interface ListEnvironmentsRequest {
    ApplicationId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListEnvironmentsRequest: S.Schema<ListEnvironmentsRequest>;
export type EnvironmentList = Environment[];
export declare const EnvironmentList: any;
export interface Environments {
    Items?: Environment[];
    NextToken?: string;
}
export declare const Environments: S.Schema<Environments>;
export interface ListExperimentDefinitionsRequest {
    ApplicationIdentifier?: string;
    ConfigurationProfileIdentifier?: string;
    EnvironmentIdentifier?: string;
    Status?: ExperimentDefinitionStatus;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListExperimentDefinitionsRequest: S.Schema<ListExperimentDefinitionsRequest>;
export interface ExperimentDefinitionSummary {
    ApplicationId?: string;
    Id?: string;
    Name?: string;
    Hypothesis?: string;
    Status?: ExperimentDefinitionStatus;
    ConfigurationProfileId?: string;
    EnvironmentId?: string;
    FlagKey?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export declare const ExperimentDefinitionSummary: S.Schema<ExperimentDefinitionSummary>;
export type ExperimentDefinitionList = ExperimentDefinitionSummary[];
export declare const ExperimentDefinitionList: any;
export interface ExperimentDefinitions {
    Items?: ExperimentDefinitionSummary[];
    NextToken?: string;
}
export declare const ExperimentDefinitions: S.Schema<ExperimentDefinitions>;
export interface ListExperimentRunEventsRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    Run: number;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListExperimentRunEventsRequest: S.Schema<ListExperimentRunEventsRequest>;
export type ExperimentRunEventType = "RUN_STARTED" | "EXPOSURE_UPDATED" | "OVERRIDES_UPDATED" | "RUN_STOPPED" | (string & {});
export declare const ExperimentRunEventType: any;
export interface ExperimentRunEvent {
    Description?: string;
    AssociatedDeployment?: string;
    EventType?: ExperimentRunEventType;
    OccurredAt?: Date;
    TriggeredBy?: TriggeredBy;
    ExposurePercentage?: number;
    TreatmentOverrides?: TreatmentOverrides;
}
export declare const ExperimentRunEvent: S.Schema<ExperimentRunEvent>;
export type ExperimentRunEventList = ExperimentRunEvent[];
export declare const ExperimentRunEventList: any;
export interface ExperimentRunEvents {
    Items?: ExperimentRunEvent[];
    NextToken?: string;
}
export declare const ExperimentRunEvents: S.Schema<ExperimentRunEvents>;
export interface ListExperimentRunsRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    MaxResults?: number;
    NextToken?: string;
    Status?: ExperimentRunStatus;
}
export declare const ListExperimentRunsRequest: S.Schema<ListExperimentRunsRequest>;
export interface ExperimentRunSummary {
    ExperimentDefinitionId?: string;
    Run?: number;
    Description?: string;
    Status?: ExperimentRunStatus;
    StartedAt?: Date;
    UpdatedAt?: Date;
    EndedAt?: Date;
}
export declare const ExperimentRunSummary: S.Schema<ExperimentRunSummary>;
export type ExperimentRunSummaryList = ExperimentRunSummary[];
export declare const ExperimentRunSummaryList: any;
export interface ExperimentRuns {
    Items?: ExperimentRunSummary[];
    NextToken?: string;
}
export declare const ExperimentRuns: S.Schema<ExperimentRuns>;
export interface ListExtensionAssociationsRequest {
    ResourceIdentifier?: string;
    ExtensionIdentifier?: string;
    ExtensionVersionNumber?: number;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListExtensionAssociationsRequest: S.Schema<ListExtensionAssociationsRequest>;
export interface ExtensionAssociationSummary {
    Id?: string;
    ExtensionArn?: string;
    ResourceArn?: string;
}
export declare const ExtensionAssociationSummary: S.Schema<ExtensionAssociationSummary>;
export type ExtensionAssociationSummaries = ExtensionAssociationSummary[];
export declare const ExtensionAssociationSummaries: any;
export interface ExtensionAssociations {
    Items?: ExtensionAssociationSummary[];
    NextToken?: string;
}
export declare const ExtensionAssociations: S.Schema<ExtensionAssociations>;
export type QueryName = string;
export interface ListExtensionsRequest {
    MaxResults?: number;
    NextToken?: string;
    Name?: string;
}
export declare const ListExtensionsRequest: S.Schema<ListExtensionsRequest>;
export interface ExtensionSummary {
    Id?: string;
    Name?: string;
    VersionNumber?: number;
    Arn?: string;
    Description?: string;
}
export declare const ExtensionSummary: S.Schema<ExtensionSummary>;
export type ExtensionSummaries = ExtensionSummary[];
export declare const ExtensionSummaries: any;
export interface Extensions {
    Items?: ExtensionSummary[];
    NextToken?: string;
}
export declare const Extensions: S.Schema<Extensions>;
export interface ListHostedConfigurationVersionsRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    MaxResults?: number;
    NextToken?: string;
    VersionLabel?: string;
}
export declare const ListHostedConfigurationVersionsRequest: S.Schema<ListHostedConfigurationVersionsRequest>;
export interface HostedConfigurationVersionSummary {
    ApplicationId?: string;
    ConfigurationProfileId?: string;
    VersionNumber?: number;
    Description?: string;
    ContentType?: string;
    VersionLabel?: string;
    KmsKeyArn?: string;
}
export declare const HostedConfigurationVersionSummary: S.Schema<HostedConfigurationVersionSummary>;
export type HostedConfigurationVersionSummaryList = HostedConfigurationVersionSummary[];
export declare const HostedConfigurationVersionSummaryList: any;
export interface HostedConfigurationVersions {
    Items?: HostedConfigurationVersionSummary[];
    NextToken?: string;
}
export declare const HostedConfigurationVersions: S.Schema<HostedConfigurationVersions>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ResourceTags {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ResourceTags: S.Schema<ResourceTags>;
export type DynamicParameterKey = string;
export type DynamicParameterMap = {
    [key: string]: string | undefined;
};
export declare const DynamicParameterMap: any;
export interface StartDeploymentRequest {
    ApplicationId: string;
    EnvironmentId: string;
    DeploymentStrategyId: string;
    ConfigurationProfileId: string;
    ConfigurationVersion: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    KmsKeyIdentifier?: string;
    DynamicExtensionParameters?: {
        [key: string]: string | undefined;
    };
    LatestDeploymentNumber?: number;
}
export declare const StartDeploymentRequest: S.Schema<StartDeploymentRequest>;
export interface DeploymentParameters {
    DynamicExtensionParameters?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DeploymentParameters: S.Schema<DeploymentParameters>;
export interface StartExperimentRunRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    Description?: string;
    ExposurePercentage?: number;
    TreatmentOverrides?: TreatmentOverrides;
    Tags?: {
        [key: string]: string | undefined;
    };
    DeploymentParameters?: DeploymentParameters;
}
export declare const StartExperimentRunRequest: S.Schema<StartExperimentRunRequest>;
export interface StopDeploymentRequest {
    ApplicationId: string;
    EnvironmentId: string;
    DeploymentNumber: number;
    AllowRevert?: boolean;
}
export declare const StopDeploymentRequest: S.Schema<StopDeploymentRequest>;
export interface StopExperimentRunRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    Run: number;
    Result?: ExperimentRunResult;
    DeploymentParameters?: DeploymentParameters;
}
export declare const StopExperimentRunRequest: S.Schema<StopExperimentRunRequest>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAccountSettingsRequest {
    DeletionProtection?: DeletionProtectionSettings;
    VendedMetrics?: VendedMetricsSettings;
}
export declare const UpdateAccountSettingsRequest: S.Schema<UpdateAccountSettingsRequest>;
export interface UpdateApplicationRequest {
    ApplicationId: string;
    Name?: string;
    Description?: string;
}
export declare const UpdateApplicationRequest: S.Schema<UpdateApplicationRequest>;
export type KmsKeyIdentifierOrEmpty = string;
export interface UpdateConfigurationProfileRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    Name?: string;
    Description?: string;
    RetrievalRoleArn?: string;
    Validators?: Validator[];
    KmsKeyIdentifier?: string;
}
export declare const UpdateConfigurationProfileRequest: S.Schema<UpdateConfigurationProfileRequest>;
export interface UpdateDeploymentStrategyRequest {
    DeploymentStrategyId: string;
    Description?: string;
    DeploymentDurationInMinutes?: number;
    FinalBakeTimeInMinutes?: number;
    GrowthFactor?: number;
    GrowthType?: GrowthType;
}
export declare const UpdateDeploymentStrategyRequest: S.Schema<UpdateDeploymentStrategyRequest>;
export interface UpdateEnvironmentRequest {
    ApplicationId: string;
    EnvironmentId: string;
    Name?: string;
    Description?: string;
    Monitors?: Monitor[];
}
export declare const UpdateEnvironmentRequest: S.Schema<UpdateEnvironmentRequest>;
export interface UpdateExperimentDefinitionRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    Treatments?: TreatmentInput[];
    Control?: TreatmentInput;
    Hypothesis?: string;
    AudienceRule?: string;
    AudienceDescription?: string;
    LaunchCriteria?: string;
}
export declare const UpdateExperimentDefinitionRequest: S.Schema<UpdateExperimentDefinitionRequest>;
export interface UpdateExperimentRunRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    Run: number;
    Description?: string;
    ExposurePercentage?: number;
    TreatmentOverrides?: TreatmentOverrides;
    DeploymentParameters?: DeploymentParameters;
}
export declare const UpdateExperimentRunRequest: S.Schema<UpdateExperimentRunRequest>;
export interface UpdateExtensionRequest {
    ExtensionIdentifier: string;
    Description?: string;
    Actions?: {
        [key: string]: Action[] | undefined;
    };
    Parameters?: {
        [key: string]: Parameter | undefined;
    };
    VersionNumber?: number;
}
export declare const UpdateExtensionRequest: S.Schema<UpdateExtensionRequest>;
export interface UpdateExtensionAssociationRequest {
    ExtensionAssociationId: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateExtensionAssociationRequest: S.Schema<UpdateExtensionAssociationRequest>;
export interface ValidateConfigurationRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    ConfigurationVersion: string;
}
export declare const ValidateConfigurationRequest: S.Schema<ValidateConfigurationRequest>;
export interface ValidateConfigurationResponse {
}
export declare const ValidateConfigurationResponse: S.Schema<ValidateConfigurationResponse>;
export type BadRequestReason = "InvalidConfiguration" | (string & {});
export declare const BadRequestReason: any;
export interface InvalidConfigurationDetail {
    Constraint?: string;
    Location?: string;
    Reason?: string;
    Type?: string;
    Value?: string;
}
export declare const InvalidConfigurationDetail: S.Schema<InvalidConfigurationDetail>;
export type InvalidConfigurationDetailList = InvalidConfigurationDetail[];
export declare const InvalidConfigurationDetailList: any;
export type BadRequestDetails = {
    InvalidConfiguration: InvalidConfigurationDetail[];
};
export declare const BadRequestDetails: any;
export type BytesMeasure = "KILOBYTES" | (string & {});
export declare const BytesMeasure: any;
export type CreateApplicationError = BadRequestException | InternalServerException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates an application. In AppConfig, an application is simply an
 * organizational construct like a folder. This organizational construct has a relationship
 * with some unit of executable code. For example, you could create an application called
 * MyMobileApp to organize and manage configuration data for a mobile application installed by
 * your users.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, Application, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationProfileError = BadRequestException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a configuration profile, which is information that enables AppConfig
 * to access the configuration source. Valid configuration sources include the
 * following:
 *
 * - Configuration data in YAML, JSON, and other formats stored in the AppConfig hosted configuration store
 *
 * - Configuration data stored as objects in an Amazon Simple Storage Service (Amazon S3)
 * bucket
 *
 * - Pipelines stored in CodePipeline
 *
 * - Secrets stored in Secrets Manager
 *
 * - Standard and secure string parameters stored in Amazon Web Services Systems Manager Parameter Store
 *
 * - Configuration data in SSM documents stored in the Systems Manager document store
 *
 * A configuration profile includes the following information:
 *
 * - The URI location of the configuration data.
 *
 * - The Identity and Access Management (IAM) role that provides access to the configuration data.
 *
 * - A validator for the configuration data. Available validators include either a JSON
 * Schema or an Amazon Web Services Lambda function.
 *
 * For more information, see Create a
 * Configuration and a Configuration Profile in the AppConfig
 * User Guide.
 */
export declare const createConfigurationProfile: API.OperationMethod<CreateConfigurationProfileRequest, ConfigurationProfile, CreateConfigurationProfileError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentStrategyError = BadRequestException | InternalServerException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a deployment strategy that defines important criteria for rolling out your
 * configuration to the designated targets. A deployment strategy includes the overall
 * duration required, a percentage of targets to receive the deployment during each interval,
 * an algorithm that defines how percentage grows, and bake time.
 */
export declare const createDeploymentStrategy: API.OperationMethod<CreateDeploymentStrategyRequest, DeploymentStrategy, CreateDeploymentStrategyError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = BadRequestException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates an environment. For each application, you define one or more environments. An
 * environment is a deployment group of AppConfig targets, such as applications in a
 * `Beta` or `Production` environment. You can also define
 * environments for application subcomponents such as the `Web`,
 * `Mobile` and `Back-end` components for your application. You can
 * configure Amazon CloudWatch alarms for each environment. The system monitors alarms during a
 * configuration deployment. If an alarm is triggered, the system rolls back the
 * configuration.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentRequest, Environment, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateExperimentDefinitionError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates an experiment definition in AppConfig. An experiment definition describes the purpose, scope, and operational configuration of an experiment, including the target audience, feature flag, and treatment configurations.
 */
export declare const createExperimentDefinition: API.OperationMethod<CreateExperimentDefinitionRequest, ExperimentDefinition, CreateExperimentDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateExtensionError = BadRequestException | ConflictException | InternalServerException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates an AppConfig extension. An extension augments your ability to inject
 * logic or behavior at different points during the AppConfig workflow of creating
 * or deploying a configuration.
 *
 * You can create your own extensions or use the Amazon Web Services authored extensions provided by
 * AppConfig. For an AppConfig extension that uses Lambda, you must create a Lambda function to perform any computation and processing
 * defined in the extension. If you plan to create custom versions of the Amazon Web Services
 * authored notification extensions, you only need to specify an Amazon Resource Name (ARN) in
 * the `Uri` field for the new extension version.
 *
 * - For a custom EventBridge notification extension, enter the ARN of the EventBridge
 * default events in the `Uri` field.
 *
 * - For a custom Amazon SNS notification extension, enter the ARN of an Amazon SNS
 * topic in the `Uri` field.
 *
 * - For a custom Amazon SQS notification extension, enter the ARN of an Amazon SQS
 * message queue in the `Uri` field.
 *
 * For more information about extensions, see Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const createExtension: API.OperationMethod<CreateExtensionRequest, Extension, CreateExtensionError, Credentials | HttpClient.HttpClient>;
export type CreateExtensionAssociationError = BadRequestException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * When you create an extension or configure an Amazon Web Services authored extension, you
 * associate the extension with an AppConfig application, environment, or
 * configuration profile. For example, you can choose to run the AppConfig
 * deployment events to Amazon SNS
 * Amazon Web Services authored extension and receive notifications on an Amazon SNS
 * topic anytime a configuration deployment is started for a specific application. Defining
 * which extension to associate with an AppConfig resource is called an
 * *extension association*. An extension association is a specified
 * relationship between an extension and an AppConfig resource, such as an
 * application or a configuration profile. For more information about extensions and
 * associations, see Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const createExtensionAssociation: API.OperationMethod<CreateExtensionAssociationRequest, ExtensionAssociation, CreateExtensionAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateHostedConfigurationVersionError = BadRequestException | ConflictException | InternalServerException | PayloadTooLargeException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new configuration in the AppConfig hosted configuration store. If
 * you're creating a feature flag, we recommend you familiarize yourself with the JSON schema
 * for feature flag data. For more information, see Type reference for AWS.AppConfig.FeatureFlags in the
 * *AppConfig User Guide*.
 */
export declare const createHostedConfigurationVersion: API.OperationMethod<CreateHostedConfigurationVersionRequest, HostedConfigurationVersion, CreateHostedConfigurationVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationProfileError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a configuration profile.
 *
 * To prevent users from unintentionally deleting actively-used configuration profiles,
 * enable deletion
 * protection.
 */
export declare const deleteConfigurationProfile: API.OperationMethod<DeleteConfigurationProfileRequest, DeleteConfigurationProfileResponse, DeleteConfigurationProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentStrategyError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a deployment strategy.
 */
export declare const deleteDeploymentStrategy: API.OperationMethod<DeleteDeploymentStrategyRequest, DeleteDeploymentStrategyResponse, DeleteDeploymentStrategyError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an environment.
 *
 * To prevent users from unintentionally deleting actively-used environments, enable deletion
 * protection.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentRequest, DeleteEnvironmentResponse, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteExperimentDefinitionError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an experiment definition. You can archive the definition to hide it from the active list while preserving it for future reference, or permanently delete it along with all associated run history.
 */
export declare const deleteExperimentDefinition: API.OperationMethod<DeleteExperimentDefinitionRequest, DeleteExperimentDefinitionResponse, DeleteExperimentDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteExtensionError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an AppConfig extension. You must delete all associations to an
 * extension before you delete the extension.
 */
export declare const deleteExtension: API.OperationMethod<DeleteExtensionRequest, DeleteExtensionResponse, DeleteExtensionError, Credentials | HttpClient.HttpClient>;
export type DeleteExtensionAssociationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an extension association. This action doesn't delete extensions defined in the
 * association.
 */
export declare const deleteExtensionAssociation: API.OperationMethod<DeleteExtensionAssociationRequest, DeleteExtensionAssociationResponse, DeleteExtensionAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteHostedConfigurationVersionError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a version of a configuration from the AppConfig hosted configuration
 * store.
 */
export declare const deleteHostedConfigurationVersion: API.OperationMethod<DeleteHostedConfigurationVersionRequest, DeleteHostedConfigurationVersionResponse, DeleteHostedConfigurationVersionError, Credentials | HttpClient.HttpClient>;
export type GetAccountSettingsError = BadRequestException | InternalServerException | CommonErrors;
/**
 * Returns information about the status of the `DeletionProtection`
 * parameter.
 */
export declare const getAccountSettings: API.OperationMethod<GetAccountSettingsRequest, AccountSettings, GetAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about an application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest, Application, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * (Deprecated) Retrieves the latest deployed configuration.
 *
 * Note the following important information.
 *
 * - This API action is deprecated. Calls to receive configuration data should use
 * the StartConfigurationSession and GetLatestConfiguration APIs instead.
 *
 * - GetConfiguration is a priced call. For more information, see
 * Pricing.
 */
export declare const getConfiguration: API.OperationMethod<GetConfigurationRequest, Configuration, GetConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationProfileError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a configuration profile.
 */
export declare const getConfigurationProfile: API.OperationMethod<GetConfigurationProfileRequest, ConfigurationProfile, GetConfigurationProfileError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a configuration deployment.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentRequest, Deployment, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentStrategyError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a deployment strategy. A deployment strategy defines
 * important criteria for rolling out your configuration to the designated targets. A
 * deployment strategy includes the overall duration required, a percentage of targets to
 * receive the deployment during each interval, an algorithm that defines how percentage
 * grows, and bake time.
 */
export declare const getDeploymentStrategy: API.OperationMethod<GetDeploymentStrategyRequest, DeploymentStrategy, GetDeploymentStrategyError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about an environment. An environment is a deployment group of
 * AppConfig applications, such as applications in a `Production`
 * environment or in an `EU_Region` environment. Each configuration deployment
 * targets an environment. You can enable one or more Amazon CloudWatch alarms for an environment. If
 * an alarm is triggered during a deployment, AppConfig roles back the
 * configuration.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentRequest, Environment, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetExperimentDefinitionError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about an experiment definition.
 */
export declare const getExperimentDefinition: API.OperationMethod<GetExperimentDefinitionRequest, ExperimentDefinition, GetExperimentDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetExperimentRunError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about an experiment run, including its status, start time, and exposure settings.
 */
export declare const getExperimentRun: API.OperationMethod<GetExperimentRunRequest, ExperimentRun, GetExperimentRunError, Credentials | HttpClient.HttpClient>;
export type GetExtensionError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about an AppConfig extension.
 */
export declare const getExtension: API.OperationMethod<GetExtensionRequest, Extension, GetExtensionError, Credentials | HttpClient.HttpClient>;
export type GetExtensionAssociationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about an AppConfig extension association. For more
 * information about extensions and associations, see Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const getExtensionAssociation: API.OperationMethod<GetExtensionAssociationRequest, ExtensionAssociation, GetExtensionAssociationError, Credentials | HttpClient.HttpClient>;
export type GetHostedConfigurationVersionError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a specific configuration version.
 */
export declare const getHostedConfigurationVersion: API.OperationMethod<GetHostedConfigurationVersionRequest, HostedConfigurationVersion, GetHostedConfigurationVersionError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = BadRequestException | InternalServerException | CommonErrors;
/**
 * Lists all applications in your Amazon Web Services account.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, Applications, ListApplicationsError, Credentials | HttpClient.HttpClient, Application>;
export type ListConfigurationProfilesError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the configuration profiles for an application.
 */
export declare const listConfigurationProfiles: API.PaginatedOperationMethod<ListConfigurationProfilesRequest, ConfigurationProfiles, ListConfigurationProfilesError, Credentials | HttpClient.HttpClient, ConfigurationProfileSummary>;
export type ListDeploymentsError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the deployments for an environment in descending deployment number order.
 */
export declare const listDeployments: API.PaginatedOperationMethod<ListDeploymentsRequest, Deployments, ListDeploymentsError, Credentials | HttpClient.HttpClient, DeploymentSummary>;
export type ListDeploymentStrategiesError = BadRequestException | InternalServerException | CommonErrors;
/**
 * Lists deployment strategies.
 */
export declare const listDeploymentStrategies: API.PaginatedOperationMethod<ListDeploymentStrategiesRequest, DeploymentStrategies, ListDeploymentStrategiesError, Credentials | HttpClient.HttpClient, DeploymentStrategy>;
export type ListEnvironmentsError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the environments for an application.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsRequest, Environments, ListEnvironmentsError, Credentials | HttpClient.HttpClient, Environment>;
export type ListExperimentDefinitionsError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the experiment definitions for an account. You can filter results by application, configuration profile, environment, or status.
 */
export declare const listExperimentDefinitions: API.PaginatedOperationMethod<ListExperimentDefinitionsRequest, ExperimentDefinitions, ListExperimentDefinitionsError, Credentials | HttpClient.HttpClient, ExperimentDefinitionSummary>;
export type ListExperimentRunEventsError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the events for a specified experiment run. Events provide a timeline of actions and state changes that occurred during the run.
 */
export declare const listExperimentRunEvents: API.PaginatedOperationMethod<ListExperimentRunEventsRequest, ExperimentRunEvents, ListExperimentRunEventsError, Credentials | HttpClient.HttpClient, ExperimentRunEvent>;
export type ListExperimentRunsError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the experiment runs for a specified experiment definition. You can filter by status.
 */
export declare const listExperimentRuns: API.PaginatedOperationMethod<ListExperimentRunsRequest, ExperimentRuns, ListExperimentRunsError, Credentials | HttpClient.HttpClient, ExperimentRunSummary>;
export type ListExtensionAssociationsError = BadRequestException | InternalServerException | CommonErrors;
/**
 * Lists all AppConfig extension associations in the account. For more
 * information about extensions and associations, see Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const listExtensionAssociations: API.PaginatedOperationMethod<ListExtensionAssociationsRequest, ExtensionAssociations, ListExtensionAssociationsError, Credentials | HttpClient.HttpClient, ExtensionAssociationSummary>;
export type ListExtensionsError = BadRequestException | InternalServerException | CommonErrors;
/**
 * Lists all custom and Amazon Web Services authored AppConfig extensions in the
 * account. For more information about extensions, see Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const listExtensions: API.PaginatedOperationMethod<ListExtensionsRequest, Extensions, ListExtensionsError, Credentials | HttpClient.HttpClient, ExtensionSummary>;
export type ListHostedConfigurationVersionsError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists configurations stored in the AppConfig hosted configuration store by
 * version.
 */
export declare const listHostedConfigurationVersions: API.PaginatedOperationMethod<ListHostedConfigurationVersionsRequest, HostedConfigurationVersions, ListHostedConfigurationVersionsError, Credentials | HttpClient.HttpClient, HostedConfigurationVersionSummary>;
export type ListTagsForResourceError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the list of key-value tags assigned to the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ResourceTags, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartDeploymentError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Starts a deployment.
 *
 * AppConfig Agent supports deploying feature flag or free-form configuration data to specific segments or individual users during a gradual rollout. Entity-based gradual deployments ensure that once a user or segment receives a configuration version, they continue to receive that same version throughout the deployment period, regardless of which compute resource serves their requests. For more information, see Using AppConfig Agent for user-based or entity-based gradual deployments
 */
export declare const startDeployment: API.OperationMethod<StartDeploymentRequest, Deployment, StartDeploymentError, Credentials | HttpClient.HttpClient>;
export type StartExperimentRunError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Starts an experiment run for the specified experiment definition. An experiment run delivers treatments to the target audience and collects metrics. You can start multiple experiment runs from the same experiment definition.
 *
 * Billing for this experiment begins when you call this operation and continues until the experiment is stopped. For pricing details, see AppConfig pricing.
 */
export declare const startExperimentRun: API.OperationMethod<StartExperimentRunRequest, ExperimentRun, StartExperimentRunError, Credentials | HttpClient.HttpClient>;
export type StopDeploymentError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Stops a deployment. This API action works only on deployments that have a status of
 * `DEPLOYING`, unless an `AllowRevert` parameter is supplied. If the
 * `AllowRevert` parameter is supplied, the status of an in-progress deployment
 * will be `ROLLED_BACK`. The status of a completed deployment will be
 * `REVERTED`. AppConfig only allows a revert within 72 hours of
 * deployment completion.
 */
export declare const stopDeployment: API.OperationMethod<StopDeploymentRequest, Deployment, StopDeploymentError, Credentials | HttpClient.HttpClient>;
export type StopExperimentRunError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Stops a running experiment. Stopping an experiment run ends audience exposure and returns users to the currently deployed feature flag configuration.
 */
export declare const stopExperimentRun: API.OperationMethod<StopExperimentRunRequest, ExperimentRun, StopExperimentRunError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Assigns metadata to an AppConfig resource. Tags help organize and categorize
 * your AppConfig resources. Each tag consists of a key and an optional value, both
 * of which you define. You can specify a maximum of 50 tags for a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a tag key and value from an AppConfig resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountSettingsError = BadRequestException | InternalServerException | CommonErrors;
/**
 * Updates the value of the `DeletionProtection` parameter.
 */
export declare const updateAccountSettings: API.OperationMethod<UpdateAccountSettingsRequest, AccountSettings, UpdateAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest, Application, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationProfileError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a configuration profile.
 */
export declare const updateConfigurationProfile: API.OperationMethod<UpdateConfigurationProfileRequest, ConfigurationProfile, UpdateConfigurationProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateDeploymentStrategyError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a deployment strategy.
 */
export declare const updateDeploymentStrategy: API.OperationMethod<UpdateDeploymentStrategyRequest, DeploymentStrategy, UpdateDeploymentStrategyError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an environment.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentRequest, Environment, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateExperimentDefinitionError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an experiment definition. You can update treatments, the control, audience rules, and other properties. You cannot update an experiment definition while an experiment run is active.
 */
export declare const updateExperimentDefinition: API.OperationMethod<UpdateExperimentDefinitionRequest, ExperimentDefinition, UpdateExperimentDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateExperimentRunError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a running experiment. Use this operation to increase audience exposure, modify treatment assignment overrides, or update the description of an active experiment run. Audience exposure can only be increased, not decreased.
 */
export declare const updateExperimentRun: API.OperationMethod<UpdateExperimentRunRequest, ExperimentRun, UpdateExperimentRunError, Credentials | HttpClient.HttpClient>;
export type UpdateExtensionError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an AppConfig extension. For more information about extensions, see
 * Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const updateExtension: API.OperationMethod<UpdateExtensionRequest, Extension, UpdateExtensionError, Credentials | HttpClient.HttpClient>;
export type UpdateExtensionAssociationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an association. For more information about extensions and associations, see
 * Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const updateExtensionAssociation: API.OperationMethod<UpdateExtensionAssociationRequest, ExtensionAssociation, UpdateExtensionAssociationError, Credentials | HttpClient.HttpClient>;
export type ValidateConfigurationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Uses the validators in a configuration profile to validate a configuration.
 */
export declare const validateConfiguration: API.OperationMethod<ValidateConfigurationRequest, ValidateConfigurationResponse, ValidateConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appconfig.d.ts.map