import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ConformancePackTemplateValidationException_base: S.Class<ConformancePackTemplateValidationException, S.TaggedStruct<"ConformancePackTemplateValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConformancePackTemplateValidationException extends /*@__PURE__*/ ConformancePackTemplateValidationException_base {
}
declare const IdempotentParameterMismatch_base: S.Class<IdempotentParameterMismatch, S.TaggedStruct<"IdempotentParameterMismatch", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class IdempotentParameterMismatch extends /*@__PURE__*/ IdempotentParameterMismatch_base {
}
declare const InsufficientDeliveryPolicyException_base: S.Class<InsufficientDeliveryPolicyException, S.TaggedStruct<"InsufficientDeliveryPolicyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InsufficientDeliveryPolicyException extends /*@__PURE__*/ InsufficientDeliveryPolicyException_base {
}
declare const InsufficientPermissionsException_base: S.Class<InsufficientPermissionsException, S.TaggedStruct<"InsufficientPermissionsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InsufficientPermissionsException extends /*@__PURE__*/ InsufficientPermissionsException_base {
}
declare const InvalidConfigurationRecorderNameException_base: S.Class<InvalidConfigurationRecorderNameException, S.TaggedStruct<"InvalidConfigurationRecorderNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidConfigurationRecorderNameException extends /*@__PURE__*/ InvalidConfigurationRecorderNameException_base {
}
declare const InvalidDeliveryChannelNameException_base: S.Class<InvalidDeliveryChannelNameException, S.TaggedStruct<"InvalidDeliveryChannelNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDeliveryChannelNameException extends /*@__PURE__*/ InvalidDeliveryChannelNameException_base {
}
declare const InvalidExpressionException_base: S.Class<InvalidExpressionException, S.TaggedStruct<"InvalidExpressionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidExpressionException extends /*@__PURE__*/ InvalidExpressionException_base {
}
declare const InvalidLimitException_base: S.Class<InvalidLimitException, S.TaggedStruct<"InvalidLimitException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidLimitException extends /*@__PURE__*/ InvalidLimitException_base {
}
declare const InvalidNextTokenException_base: S.Class<InvalidNextTokenException, S.TaggedStruct<"InvalidNextTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterValueException_base: S.Class<InvalidParameterValueException, S.TaggedStruct<"InvalidParameterValueException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidRecordingGroupException_base: S.Class<InvalidRecordingGroupException, S.TaggedStruct<"InvalidRecordingGroupException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRecordingGroupException extends /*@__PURE__*/ InvalidRecordingGroupException_base {
}
declare const InvalidResultTokenException_base: S.Class<InvalidResultTokenException, S.TaggedStruct<"InvalidResultTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidResultTokenException extends /*@__PURE__*/ InvalidResultTokenException_base {
}
declare const InvalidRoleException_base: S.Class<InvalidRoleException, S.TaggedStruct<"InvalidRoleException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRoleException extends /*@__PURE__*/ InvalidRoleException_base {
}
declare const InvalidS3KeyPrefixException_base: S.Class<InvalidS3KeyPrefixException, S.TaggedStruct<"InvalidS3KeyPrefixException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidS3KeyPrefixException extends /*@__PURE__*/ InvalidS3KeyPrefixException_base {
}
declare const InvalidS3KmsKeyArnException_base: S.Class<InvalidS3KmsKeyArnException, S.TaggedStruct<"InvalidS3KmsKeyArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidS3KmsKeyArnException extends /*@__PURE__*/ InvalidS3KmsKeyArnException_base {
}
declare const InvalidSNSTopicARNException_base: S.Class<InvalidSNSTopicARNException, S.TaggedStruct<"InvalidSNSTopicARNException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSNSTopicARNException extends /*@__PURE__*/ InvalidSNSTopicARNException_base {
}
declare const InvalidTimeRangeException_base: S.Class<InvalidTimeRangeException, S.TaggedStruct<"InvalidTimeRangeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTimeRangeException extends /*@__PURE__*/ InvalidTimeRangeException_base {
}
declare const LastDeliveryChannelDeleteFailedException_base: S.Class<LastDeliveryChannelDeleteFailedException, S.TaggedStruct<"LastDeliveryChannelDeleteFailedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LastDeliveryChannelDeleteFailedException extends /*@__PURE__*/ LastDeliveryChannelDeleteFailedException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MaxActiveResourcesExceededException_base: S.Class<MaxActiveResourcesExceededException, S.TaggedStruct<"MaxActiveResourcesExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaxActiveResourcesExceededException extends /*@__PURE__*/ MaxActiveResourcesExceededException_base {
}
declare const MaxNumberOfConfigRulesExceededException_base: S.Class<MaxNumberOfConfigRulesExceededException, S.TaggedStruct<"MaxNumberOfConfigRulesExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaxNumberOfConfigRulesExceededException extends /*@__PURE__*/ MaxNumberOfConfigRulesExceededException_base {
}
declare const MaxNumberOfConfigurationRecordersExceededException_base: S.Class<MaxNumberOfConfigurationRecordersExceededException, S.TaggedStruct<"MaxNumberOfConfigurationRecordersExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaxNumberOfConfigurationRecordersExceededException extends /*@__PURE__*/ MaxNumberOfConfigurationRecordersExceededException_base {
}
declare const MaxNumberOfConformancePacksExceededException_base: S.Class<MaxNumberOfConformancePacksExceededException, S.TaggedStruct<"MaxNumberOfConformancePacksExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaxNumberOfConformancePacksExceededException extends /*@__PURE__*/ MaxNumberOfConformancePacksExceededException_base {
}
declare const MaxNumberOfConnectorsExceededException_base: S.Class<MaxNumberOfConnectorsExceededException, S.TaggedStruct<"MaxNumberOfConnectorsExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaxNumberOfConnectorsExceededException extends /*@__PURE__*/ MaxNumberOfConnectorsExceededException_base {
}
declare const MaxNumberOfDeliveryChannelsExceededException_base: S.Class<MaxNumberOfDeliveryChannelsExceededException, S.TaggedStruct<"MaxNumberOfDeliveryChannelsExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaxNumberOfDeliveryChannelsExceededException extends /*@__PURE__*/ MaxNumberOfDeliveryChannelsExceededException_base {
}
declare const MaxNumberOfOrganizationConfigRulesExceededException_base: S.Class<MaxNumberOfOrganizationConfigRulesExceededException, S.TaggedStruct<"MaxNumberOfOrganizationConfigRulesExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaxNumberOfOrganizationConfigRulesExceededException extends /*@__PURE__*/ MaxNumberOfOrganizationConfigRulesExceededException_base {
}
declare const MaxNumberOfOrganizationConformancePacksExceededException_base: S.Class<MaxNumberOfOrganizationConformancePacksExceededException, S.TaggedStruct<"MaxNumberOfOrganizationConformancePacksExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaxNumberOfOrganizationConformancePacksExceededException extends /*@__PURE__*/ MaxNumberOfOrganizationConformancePacksExceededException_base {
}
declare const MaxNumberOfRetentionConfigurationsExceededException_base: S.Class<MaxNumberOfRetentionConfigurationsExceededException, S.TaggedStruct<"MaxNumberOfRetentionConfigurationsExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaxNumberOfRetentionConfigurationsExceededException extends /*@__PURE__*/ MaxNumberOfRetentionConfigurationsExceededException_base {
}
declare const NoAvailableConfigurationRecorderException_base: S.Class<NoAvailableConfigurationRecorderException, S.TaggedStruct<"NoAvailableConfigurationRecorderException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoAvailableConfigurationRecorderException extends /*@__PURE__*/ NoAvailableConfigurationRecorderException_base {
}
declare const NoAvailableDeliveryChannelException_base: S.Class<NoAvailableDeliveryChannelException, S.TaggedStruct<"NoAvailableDeliveryChannelException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoAvailableDeliveryChannelException extends /*@__PURE__*/ NoAvailableDeliveryChannelException_base {
}
declare const NoAvailableOrganizationException_base: S.Class<NoAvailableOrganizationException, S.TaggedStruct<"NoAvailableOrganizationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoAvailableOrganizationException extends /*@__PURE__*/ NoAvailableOrganizationException_base {
}
declare const NoRunningConfigurationRecorderException_base: S.Class<NoRunningConfigurationRecorderException, S.TaggedStruct<"NoRunningConfigurationRecorderException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoRunningConfigurationRecorderException extends /*@__PURE__*/ NoRunningConfigurationRecorderException_base {
}
declare const NoSuchBucketException_base: S.Class<NoSuchBucketException, S.TaggedStruct<"NoSuchBucketException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchBucketException extends /*@__PURE__*/ NoSuchBucketException_base {
}
declare const NoSuchConfigRuleException_base: S.Class<NoSuchConfigRuleException, S.TaggedStruct<"NoSuchConfigRuleException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchConfigRuleException extends /*@__PURE__*/ NoSuchConfigRuleException_base {
}
declare const NoSuchConfigRuleInConformancePackException_base: S.Class<NoSuchConfigRuleInConformancePackException, S.TaggedStruct<"NoSuchConfigRuleInConformancePackException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchConfigRuleInConformancePackException extends /*@__PURE__*/ NoSuchConfigRuleInConformancePackException_base {
}
declare const NoSuchConfigurationAggregatorException_base: S.Class<NoSuchConfigurationAggregatorException, S.TaggedStruct<"NoSuchConfigurationAggregatorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchConfigurationAggregatorException extends /*@__PURE__*/ NoSuchConfigurationAggregatorException_base {
}
declare const NoSuchConfigurationRecorderException_base: S.Class<NoSuchConfigurationRecorderException, S.TaggedStruct<"NoSuchConfigurationRecorderException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchConfigurationRecorderException extends /*@__PURE__*/ NoSuchConfigurationRecorderException_base {
}
declare const NoSuchConformancePackException_base: S.Class<NoSuchConformancePackException, S.TaggedStruct<"NoSuchConformancePackException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchConformancePackException extends /*@__PURE__*/ NoSuchConformancePackException_base {
}
declare const NoSuchDeliveryChannelException_base: S.Class<NoSuchDeliveryChannelException, S.TaggedStruct<"NoSuchDeliveryChannelException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchDeliveryChannelException extends /*@__PURE__*/ NoSuchDeliveryChannelException_base {
}
declare const NoSuchOrganizationConfigRuleException_base: S.Class<NoSuchOrganizationConfigRuleException, S.TaggedStruct<"NoSuchOrganizationConfigRuleException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchOrganizationConfigRuleException extends /*@__PURE__*/ NoSuchOrganizationConfigRuleException_base {
}
declare const NoSuchOrganizationConformancePackException_base: S.Class<NoSuchOrganizationConformancePackException, S.TaggedStruct<"NoSuchOrganizationConformancePackException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchOrganizationConformancePackException extends /*@__PURE__*/ NoSuchOrganizationConformancePackException_base {
}
declare const NoSuchRemediationConfigurationException_base: S.Class<NoSuchRemediationConfigurationException, S.TaggedStruct<"NoSuchRemediationConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchRemediationConfigurationException extends /*@__PURE__*/ NoSuchRemediationConfigurationException_base {
}
declare const NoSuchRemediationExceptionException_base: S.Class<NoSuchRemediationExceptionException, S.TaggedStruct<"NoSuchRemediationExceptionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchRemediationExceptionException extends /*@__PURE__*/ NoSuchRemediationExceptionException_base {
}
declare const NoSuchRetentionConfigurationException_base: S.Class<NoSuchRetentionConfigurationException, S.TaggedStruct<"NoSuchRetentionConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchRetentionConfigurationException extends /*@__PURE__*/ NoSuchRetentionConfigurationException_base {
}
declare const OrganizationAccessDeniedException_base: S.Class<OrganizationAccessDeniedException, S.TaggedStruct<"OrganizationAccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class OrganizationAccessDeniedException extends /*@__PURE__*/ OrganizationAccessDeniedException_base {
}
declare const OrganizationAllFeaturesNotEnabledException_base: S.Class<OrganizationAllFeaturesNotEnabledException, S.TaggedStruct<"OrganizationAllFeaturesNotEnabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OrganizationAllFeaturesNotEnabledException extends /*@__PURE__*/ OrganizationAllFeaturesNotEnabledException_base {
}
declare const OrganizationConformancePackTemplateValidationException_base: S.Class<OrganizationConformancePackTemplateValidationException, S.TaggedStruct<"OrganizationConformancePackTemplateValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OrganizationConformancePackTemplateValidationException extends /*@__PURE__*/ OrganizationConformancePackTemplateValidationException_base {
}
declare const OversizedConfigurationItemException_base: S.Class<OversizedConfigurationItemException, S.TaggedStruct<"OversizedConfigurationItemException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OversizedConfigurationItemException extends /*@__PURE__*/ OversizedConfigurationItemException_base {
}
declare const RemediationInProgressException_base: S.Class<RemediationInProgressException, S.TaggedStruct<"RemediationInProgressException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RemediationInProgressException extends /*@__PURE__*/ RemediationInProgressException_base {
}
declare const ResourceConcurrentModificationException_base: S.Class<ResourceConcurrentModificationException, S.TaggedStruct<"ResourceConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceConcurrentModificationException extends /*@__PURE__*/ ResourceConcurrentModificationException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotDiscoveredException_base: S.Class<ResourceNotDiscoveredException, S.TaggedStruct<"ResourceNotDiscoveredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotDiscoveredException extends /*@__PURE__*/ ResourceNotDiscoveredException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnmodifiableEntityException_base: S.Class<UnmodifiableEntityException, S.TaggedStruct<"UnmodifiableEntityException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnmodifiableEntityException extends /*@__PURE__*/ UnmodifiableEntityException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AmazonResourceName = string;
export type ResourceType = "AWS::EC2::CustomerGateway" | "AWS::EC2::EIP" | "AWS::EC2::Host" | "AWS::EC2::Instance" | "AWS::EC2::InternetGateway" | "AWS::EC2::NetworkAcl" | "AWS::EC2::NetworkInterface" | "AWS::EC2::RouteTable" | "AWS::EC2::SecurityGroup" | "AWS::EC2::Subnet" | "AWS::CloudTrail::Trail" | "AWS::EC2::Volume" | "AWS::EC2::VPC" | "AWS::EC2::VPNConnection" | "AWS::EC2::VPNGateway" | "AWS::EC2::RegisteredHAInstance" | "AWS::EC2::NatGateway" | "AWS::EC2::EgressOnlyInternetGateway" | "AWS::EC2::VPCEndpoint" | "AWS::EC2::VPCEndpointService" | "AWS::EC2::FlowLog" | "AWS::EC2::VPCPeeringConnection" | "AWS::Elasticsearch::Domain" | "AWS::IAM::Group" | "AWS::IAM::Policy" | "AWS::IAM::Role" | "AWS::IAM::User" | "AWS::ElasticLoadBalancingV2::LoadBalancer" | "AWS::ACM::Certificate" | "AWS::RDS::DBInstance" | "AWS::RDS::DBSubnetGroup" | "AWS::RDS::DBSecurityGroup" | "AWS::RDS::DBSnapshot" | "AWS::RDS::DBCluster" | "AWS::RDS::DBClusterSnapshot" | "AWS::RDS::EventSubscription" | "AWS::S3::Bucket" | "AWS::S3::AccountPublicAccessBlock" | "AWS::Redshift::Cluster" | "AWS::Redshift::ClusterSnapshot" | "AWS::Redshift::ClusterParameterGroup" | "AWS::Redshift::ClusterSecurityGroup" | "AWS::Redshift::ClusterSubnetGroup" | "AWS::Redshift::EventSubscription" | "AWS::SSM::ManagedInstanceInventory" | "AWS::CloudWatch::Alarm" | "AWS::CloudFormation::Stack" | "AWS::ElasticLoadBalancing::LoadBalancer" | "AWS::AutoScaling::AutoScalingGroup" | "AWS::AutoScaling::LaunchConfiguration" | "AWS::AutoScaling::ScalingPolicy" | "AWS::AutoScaling::ScheduledAction" | "AWS::DynamoDB::Table" | "AWS::CodeBuild::Project" | "AWS::WAF::RateBasedRule" | "AWS::WAF::Rule" | "AWS::WAF::RuleGroup" | "AWS::WAF::WebACL" | "AWS::WAFRegional::RateBasedRule" | "AWS::WAFRegional::Rule" | "AWS::WAFRegional::RuleGroup" | "AWS::WAFRegional::WebACL" | "AWS::CloudFront::Distribution" | "AWS::CloudFront::StreamingDistribution" | "AWS::Lambda::Function" | "AWS::NetworkFirewall::Firewall" | "AWS::NetworkFirewall::FirewallPolicy" | "AWS::NetworkFirewall::RuleGroup" | "AWS::ElasticBeanstalk::Application" | "AWS::ElasticBeanstalk::ApplicationVersion" | "AWS::ElasticBeanstalk::Environment" | "AWS::WAFv2::WebACL" | "AWS::WAFv2::RuleGroup" | "AWS::WAFv2::IPSet" | "AWS::WAFv2::RegexPatternSet" | "AWS::WAFv2::ManagedRuleSet" | "AWS::XRay::EncryptionConfig" | "AWS::SSM::AssociationCompliance" | "AWS::SSM::PatchCompliance" | "AWS::Shield::Protection" | "AWS::ShieldRegional::Protection" | "AWS::Config::ConformancePackCompliance" | "AWS::Config::ResourceCompliance" | "AWS::ApiGateway::Stage" | "AWS::ApiGateway::RestApi" | "AWS::ApiGatewayV2::Stage" | "AWS::ApiGatewayV2::Api" | "AWS::CodePipeline::Pipeline" | "AWS::ServiceCatalog::CloudFormationProvisionedProduct" | "AWS::ServiceCatalog::CloudFormationProduct" | "AWS::ServiceCatalog::Portfolio" | "AWS::SQS::Queue" | "AWS::KMS::Key" | "AWS::QLDB::Ledger" | "AWS::SecretsManager::Secret" | "AWS::SNS::Topic" | "AWS::SSM::FileData" | "AWS::Backup::BackupPlan" | "AWS::Backup::BackupSelection" | "AWS::Backup::BackupVault" | "AWS::Backup::RecoveryPoint" | "AWS::ECR::Repository" | "AWS::ECS::Cluster" | "AWS::ECS::Service" | "AWS::ECS::TaskDefinition" | "AWS::EFS::AccessPoint" | "AWS::EFS::FileSystem" | "AWS::EKS::Cluster" | "AWS::OpenSearch::Domain" | "AWS::EC2::TransitGateway" | "AWS::Kinesis::Stream" | "AWS::Kinesis::StreamConsumer" | "AWS::CodeDeploy::Application" | "AWS::CodeDeploy::DeploymentConfig" | "AWS::CodeDeploy::DeploymentGroup" | "AWS::EC2::LaunchTemplate" | "AWS::ECR::PublicRepository" | "AWS::GuardDuty::Detector" | "AWS::EMR::SecurityConfiguration" | "AWS::SageMaker::CodeRepository" | "AWS::Route53Resolver::ResolverEndpoint" | "AWS::Route53Resolver::ResolverRule" | "AWS::Route53Resolver::ResolverRuleAssociation" | "AWS::DMS::ReplicationSubnetGroup" | "AWS::DMS::EventSubscription" | "AWS::MSK::Cluster" | "AWS::StepFunctions::Activity" | "AWS::WorkSpaces::Workspace" | "AWS::WorkSpaces::ConnectionAlias" | "AWS::SageMaker::Model" | "AWS::ElasticLoadBalancingV2::Listener" | "AWS::StepFunctions::StateMachine" | "AWS::Batch::JobQueue" | "AWS::Batch::ComputeEnvironment" | "AWS::AccessAnalyzer::Analyzer" | "AWS::Athena::WorkGroup" | "AWS::Athena::DataCatalog" | "AWS::Detective::Graph" | "AWS::GlobalAccelerator::Accelerator" | "AWS::GlobalAccelerator::EndpointGroup" | "AWS::GlobalAccelerator::Listener" | "AWS::EC2::TransitGatewayAttachment" | "AWS::EC2::TransitGatewayRouteTable" | "AWS::DMS::Certificate" | "AWS::AppConfig::Application" | "AWS::AppSync::GraphQLApi" | "AWS::DataSync::LocationSMB" | "AWS::DataSync::LocationFSxLustre" | "AWS::DataSync::LocationS3" | "AWS::DataSync::LocationEFS" | "AWS::DataSync::Task" | "AWS::DataSync::LocationNFS" | "AWS::EC2::NetworkInsightsAccessScopeAnalysis" | "AWS::EKS::FargateProfile" | "AWS::Glue::Job" | "AWS::GuardDuty::ThreatIntelSet" | "AWS::GuardDuty::IPSet" | "AWS::SageMaker::Workteam" | "AWS::SageMaker::NotebookInstanceLifecycleConfig" | "AWS::ServiceDiscovery::Service" | "AWS::ServiceDiscovery::PublicDnsNamespace" | "AWS::SES::ContactList" | "AWS::SES::ConfigurationSet" | "AWS::Route53::HostedZone" | "AWS::IoTEvents::Input" | "AWS::IoTEvents::DetectorModel" | "AWS::IoTEvents::AlarmModel" | "AWS::ServiceDiscovery::HttpNamespace" | "AWS::Events::EventBus" | "AWS::ImageBuilder::ContainerRecipe" | "AWS::ImageBuilder::DistributionConfiguration" | "AWS::ImageBuilder::InfrastructureConfiguration" | "AWS::DataSync::LocationObjectStorage" | "AWS::DataSync::LocationHDFS" | "AWS::Glue::Classifier" | "AWS::Route53RecoveryReadiness::Cell" | "AWS::Route53RecoveryReadiness::ReadinessCheck" | "AWS::ECR::RegistryPolicy" | "AWS::Backup::ReportPlan" | "AWS::Lightsail::Certificate" | "AWS::RUM::AppMonitor" | "AWS::Events::Endpoint" | "AWS::SES::ReceiptRuleSet" | "AWS::Events::Archive" | "AWS::Events::ApiDestination" | "AWS::Lightsail::Disk" | "AWS::FIS::ExperimentTemplate" | "AWS::DataSync::LocationFSxWindows" | "AWS::SES::ReceiptFilter" | "AWS::GuardDuty::Filter" | "AWS::SES::Template" | "AWS::AmazonMQ::Broker" | "AWS::AppConfig::Environment" | "AWS::AppConfig::ConfigurationProfile" | "AWS::Cloud9::EnvironmentEC2" | "AWS::EventSchemas::Registry" | "AWS::EventSchemas::RegistryPolicy" | "AWS::EventSchemas::Discoverer" | "AWS::FraudDetector::Label" | "AWS::FraudDetector::EntityType" | "AWS::FraudDetector::Variable" | "AWS::FraudDetector::Outcome" | "AWS::IoT::Authorizer" | "AWS::IoT::SecurityProfile" | "AWS::IoT::RoleAlias" | "AWS::IoT::Dimension" | "AWS::IoTAnalytics::Datastore" | "AWS::Lightsail::Bucket" | "AWS::Lightsail::StaticIp" | "AWS::MediaPackage::PackagingGroup" | "AWS::Route53RecoveryReadiness::RecoveryGroup" | "AWS::ResilienceHub::ResiliencyPolicy" | "AWS::Transfer::Workflow" | "AWS::EKS::IdentityProviderConfig" | "AWS::EKS::Addon" | "AWS::Glue::MLTransform" | "AWS::IoT::Policy" | "AWS::IoT::MitigationAction" | "AWS::IoTTwinMaker::Workspace" | "AWS::IoTTwinMaker::Entity" | "AWS::IoTAnalytics::Dataset" | "AWS::IoTAnalytics::Pipeline" | "AWS::IoTAnalytics::Channel" | "AWS::IoTSiteWise::Dashboard" | "AWS::IoTSiteWise::Project" | "AWS::IoTSiteWise::Portal" | "AWS::IoTSiteWise::AssetModel" | "AWS::IVS::Channel" | "AWS::IVS::RecordingConfiguration" | "AWS::IVS::PlaybackKeyPair" | "AWS::KinesisAnalyticsV2::Application" | "AWS::RDS::GlobalCluster" | "AWS::S3::MultiRegionAccessPoint" | "AWS::DeviceFarm::TestGridProject" | "AWS::Budgets::BudgetsAction" | "AWS::Lex::Bot" | "AWS::CodeGuruReviewer::RepositoryAssociation" | "AWS::IoT::CustomMetric" | "AWS::Route53Resolver::FirewallDomainList" | "AWS::RoboMaker::RobotApplicationVersion" | "AWS::EC2::TrafficMirrorSession" | "AWS::IoTSiteWise::Gateway" | "AWS::Lex::BotAlias" | "AWS::LookoutMetrics::Alert" | "AWS::IoT::AccountAuditConfiguration" | "AWS::EC2::TrafficMirrorTarget" | "AWS::S3::StorageLens" | "AWS::IoT::ScheduledAudit" | "AWS::Events::Connection" | "AWS::EventSchemas::Schema" | "AWS::MediaPackage::PackagingConfiguration" | "AWS::KinesisVideo::SignalingChannel" | "AWS::AppStream::DirectoryConfig" | "AWS::LookoutVision::Project" | "AWS::Route53RecoveryControl::Cluster" | "AWS::Route53RecoveryControl::SafetyRule" | "AWS::Route53RecoveryControl::ControlPanel" | "AWS::Route53RecoveryControl::RoutingControl" | "AWS::Route53RecoveryReadiness::ResourceSet" | "AWS::RoboMaker::SimulationApplication" | "AWS::RoboMaker::RobotApplication" | "AWS::HealthLake::FHIRDatastore" | "AWS::Pinpoint::Segment" | "AWS::Pinpoint::ApplicationSettings" | "AWS::Events::Rule" | "AWS::EC2::DHCPOptions" | "AWS::EC2::NetworkInsightsPath" | "AWS::EC2::TrafficMirrorFilter" | "AWS::EC2::IPAM" | "AWS::IoTTwinMaker::Scene" | "AWS::NetworkManager::TransitGatewayRegistration" | "AWS::CustomerProfiles::Domain" | "AWS::AutoScaling::WarmPool" | "AWS::Connect::PhoneNumber" | "AWS::AppConfig::DeploymentStrategy" | "AWS::AppFlow::Flow" | "AWS::AuditManager::Assessment" | "AWS::CloudWatch::MetricStream" | "AWS::DeviceFarm::InstanceProfile" | "AWS::DeviceFarm::Project" | "AWS::EC2::EC2Fleet" | "AWS::EC2::SubnetRouteTableAssociation" | "AWS::ECR::PullThroughCacheRule" | "AWS::GroundStation::Config" | "AWS::ImageBuilder::ImagePipeline" | "AWS::IoT::FleetMetric" | "AWS::IoTWireless::ServiceProfile" | "AWS::NetworkManager::Device" | "AWS::NetworkManager::GlobalNetwork" | "AWS::NetworkManager::Link" | "AWS::NetworkManager::Site" | "AWS::Panorama::Package" | "AWS::Pinpoint::App" | "AWS::Redshift::ScheduledAction" | "AWS::Route53Resolver::FirewallRuleGroupAssociation" | "AWS::SageMaker::AppImageConfig" | "AWS::SageMaker::Image" | "AWS::ECS::TaskSet" | "AWS::Cassandra::Keyspace" | "AWS::Signer::SigningProfile" | "AWS::Amplify::App" | "AWS::AppMesh::VirtualNode" | "AWS::AppMesh::VirtualService" | "AWS::AppRunner::VpcConnector" | "AWS::AppStream::Application" | "AWS::CodeArtifact::Repository" | "AWS::EC2::PrefixList" | "AWS::EC2::SpotFleet" | "AWS::Evidently::Project" | "AWS::Forecast::Dataset" | "AWS::IAM::SAMLProvider" | "AWS::IAM::ServerCertificate" | "AWS::Pinpoint::Campaign" | "AWS::Pinpoint::InAppTemplate" | "AWS::SageMaker::Domain" | "AWS::Transfer::Agreement" | "AWS::Transfer::Connector" | "AWS::KinesisFirehose::DeliveryStream" | "AWS::Amplify::Branch" | "AWS::AppIntegrations::EventIntegration" | "AWS::AppMesh::Route" | "AWS::Athena::PreparedStatement" | "AWS::EC2::IPAMScope" | "AWS::Evidently::Launch" | "AWS::Forecast::DatasetGroup" | "AWS::GreengrassV2::ComponentVersion" | "AWS::GroundStation::MissionProfile" | "AWS::MediaConnect::FlowEntitlement" | "AWS::MediaConnect::FlowVpcInterface" | "AWS::MediaTailor::PlaybackConfiguration" | "AWS::MSK::Configuration" | "AWS::Personalize::Dataset" | "AWS::Personalize::Schema" | "AWS::Personalize::Solution" | "AWS::Pinpoint::EmailTemplate" | "AWS::Pinpoint::EventStream" | "AWS::ResilienceHub::App" | "AWS::ACMPCA::CertificateAuthority" | "AWS::AppConfig::HostedConfigurationVersion" | "AWS::AppMesh::VirtualGateway" | "AWS::AppMesh::VirtualRouter" | "AWS::AppRunner::Service" | "AWS::CustomerProfiles::ObjectType" | "AWS::DMS::Endpoint" | "AWS::EC2::CapacityReservation" | "AWS::EC2::ClientVpnEndpoint" | "AWS::Kendra::Index" | "AWS::KinesisVideo::Stream" | "AWS::Logs::Destination" | "AWS::Pinpoint::EmailChannel" | "AWS::S3::AccessPoint" | "AWS::NetworkManager::CustomerGatewayAssociation" | "AWS::NetworkManager::LinkAssociation" | "AWS::IoTWireless::MulticastGroup" | "AWS::Personalize::DatasetGroup" | "AWS::IoTTwinMaker::ComponentType" | "AWS::CodeBuild::ReportGroup" | "AWS::SageMaker::FeatureGroup" | "AWS::MSK::BatchScramSecret" | "AWS::AppStream::Stack" | "AWS::IoT::JobTemplate" | "AWS::IoTWireless::FuotaTask" | "AWS::IoT::ProvisioningTemplate" | "AWS::InspectorV2::Filter" | "AWS::Route53Resolver::ResolverQueryLoggingConfigAssociation" | "AWS::ServiceDiscovery::Instance" | "AWS::Transfer::Certificate" | "AWS::MediaConnect::FlowSource" | "AWS::APS::RuleGroupsNamespace" | "AWS::CodeGuruProfiler::ProfilingGroup" | "AWS::Route53Resolver::ResolverQueryLoggingConfig" | "AWS::Batch::SchedulingPolicy" | "AWS::ACMPCA::CertificateAuthorityActivation" | "AWS::AppMesh::GatewayRoute" | "AWS::AppMesh::Mesh" | "AWS::Connect::Instance" | "AWS::Connect::QuickConnect" | "AWS::EC2::CarrierGateway" | "AWS::EC2::IPAMPool" | "AWS::EC2::TransitGatewayConnect" | "AWS::EC2::TransitGatewayMulticastDomain" | "AWS::ECS::CapacityProvider" | "AWS::IAM::InstanceProfile" | "AWS::IoT::CACertificate" | "AWS::IoTTwinMaker::SyncJob" | "AWS::KafkaConnect::Connector" | "AWS::Lambda::CodeSigningConfig" | "AWS::NetworkManager::ConnectPeer" | "AWS::ResourceExplorer2::Index" | "AWS::AppStream::Fleet" | "AWS::Cognito::UserPool" | "AWS::Cognito::UserPoolClient" | "AWS::Cognito::UserPoolGroup" | "AWS::EC2::NetworkInsightsAccessScope" | "AWS::EC2::NetworkInsightsAnalysis" | "AWS::Grafana::Workspace" | "AWS::GroundStation::DataflowEndpointGroup" | "AWS::ImageBuilder::ImageRecipe" | "AWS::KMS::Alias" | "AWS::M2::Environment" | "AWS::QuickSight::DataSource" | "AWS::QuickSight::Template" | "AWS::QuickSight::Theme" | "AWS::RDS::OptionGroup" | "AWS::Redshift::EndpointAccess" | "AWS::Route53Resolver::FirewallRuleGroup" | "AWS::SSM::Document" | "AWS::AppConfig::ExtensionAssociation" | "AWS::AppIntegrations::Application" | "AWS::AppSync::ApiCache" | "AWS::Bedrock::Guardrail" | "AWS::Bedrock::KnowledgeBase" | "AWS::Cognito::IdentityPool" | "AWS::Connect::Rule" | "AWS::Connect::User" | "AWS::EC2::ClientVpnTargetNetworkAssociation" | "AWS::EC2::EIPAssociation" | "AWS::EC2::IPAMResourceDiscovery" | "AWS::EC2::IPAMResourceDiscoveryAssociation" | "AWS::EC2::InstanceConnectEndpoint" | "AWS::EC2::SnapshotBlockPublicAccess" | "AWS::EC2::VPCBlockPublicAccessExclusion" | "AWS::EC2::VPCBlockPublicAccessOptions" | "AWS::EC2::VPCEndpointConnectionNotification" | "AWS::EC2::VPNConnectionRoute" | "AWS::Evidently::Segment" | "AWS::IAM::OIDCProvider" | "AWS::InspectorV2::Activation" | "AWS::MSK::ClusterPolicy" | "AWS::MSK::VpcConnection" | "AWS::MediaConnect::Gateway" | "AWS::MemoryDB::SubnetGroup" | "AWS::OpenSearchServerless::Collection" | "AWS::OpenSearchServerless::VpcEndpoint" | "AWS::Redshift::EndpointAuthorization" | "AWS::Route53Profiles::Profile" | "AWS::S3::StorageLensGroup" | "AWS::S3Express::BucketPolicy" | "AWS::S3Express::DirectoryBucket" | "AWS::SageMaker::InferenceExperiment" | "AWS::SecurityHub::Standard" | "AWS::Transfer::Profile" | "AWS::CloudFormation::StackSet" | "AWS::MediaPackageV2::Channel" | "AWS::S3::AccessGrantsLocation" | "AWS::S3::AccessGrant" | "AWS::S3::AccessGrantsInstance" | "AWS::EMRServerless::Application" | "AWS::Config::AggregationAuthorization" | "AWS::Bedrock::ApplicationInferenceProfile" | "AWS::ApiGatewayV2::Integration" | "AWS::SageMaker::MlflowTrackingServer" | "AWS::SageMaker::ModelBiasJobDefinition" | "AWS::SecretsManager::RotationSchedule" | "AWS::Deadline::QueueFleetAssociation" | "AWS::ECR::RepositoryCreationTemplate" | "AWS::CloudFormation::LambdaHook" | "AWS::EC2::SubnetNetworkAclAssociation" | "AWS::ApiGateway::UsagePlan" | "AWS::AppConfig::Extension" | "AWS::Deadline::Fleet" | "AWS::EMR::Studio" | "AWS::S3Tables::TableBucket" | "AWS::CloudFront::RealtimeLogConfig" | "AWS::BackupGateway::Hypervisor" | "AWS::BCMDataExports::Export" | "AWS::CloudFormation::GuardHook" | "AWS::CloudFront::PublicKey" | "AWS::CloudTrail::EventDataStore" | "AWS::EntityResolution::IdMappingWorkflow" | "AWS::EntityResolution::SchemaMapping" | "AWS::IoT::DomainConfiguration" | "AWS::PCAConnectorAD::DirectoryRegistration" | "AWS::RDS::Integration" | "AWS::Config::ConformancePack" | "AWS::RolesAnywhere::Profile" | "AWS::CodeArtifact::Domain" | "AWS::Backup::RestoreTestingPlan" | "AWS::Config::StoredQuery" | "AWS::SageMaker::DataQualityJobDefinition" | "AWS::SageMaker::ModelExplainabilityJobDefinition" | "AWS::SageMaker::ModelQualityJobDefinition" | "AWS::SageMaker::StudioLifecycleConfig" | "AWS::SES::DedicatedIpPool" | "AWS::SES::MailManagerTrafficPolicy" | "AWS::SSM::ResourceDataSync" | "AWS::BedrockAgentCore::Runtime" | "AWS::BedrockAgentCore::BrowserCustom" | "AWS::ElasticLoadBalancingV2::TargetGroup" | "AWS::EMRContainers::VirtualCluster" | "AWS::EntityResolution::MatchingWorkflow" | "AWS::IoTCoreDeviceAdvisor::SuiteDefinition" | "AWS::EC2::SecurityGroupVpcAssociation" | "AWS::EC2::VerifiedAccessInstance" | "AWS::KafkaConnect::CustomPlugin" | "AWS::NetworkManager::TransitGatewayPeering" | "AWS::OpenSearchServerless::SecurityConfig" | "AWS::Redshift::Integration" | "AWS::RolesAnywhere::TrustAnchor" | "AWS::Route53Profiles::ProfileAssociation" | "AWS::SSMIncidents::ResponsePlan" | "AWS::Transfer::Server" | "AWS::Glue::Database" | "AWS::Organizations::OrganizationalUnit" | "AWS::EC2::IPAMPoolCidr" | "AWS::EC2::VPCGatewayAttachment" | "AWS::Bedrock::Prompt" | "AWS::Comprehend::Flywheel" | "AWS::DataSync::Agent" | "AWS::MediaTailor::LiveSource" | "AWS::MSK::ServerlessCluster" | "AWS::IoTSiteWise::Asset" | "AWS::B2BI::Capability" | "AWS::CloudFront::KeyValueStore" | "AWS::Deadline::Monitor" | "AWS::GuardDuty::MalwareProtectionPlan" | "AWS::Location::APIKey" | "AWS::MediaPackageV2::OriginEndpoint" | "AWS::PCAConnectorAD::Connector" | "AWS::S3Tables::TableBucketPolicy" | "AWS::SecretsManager::ResourcePolicy" | "AWS::SSMContacts::Contact" | "AWS::IoT::ThingGroup" | "AWS::ImageBuilder::LifecyclePolicy" | "AWS::GameLift::Build" | "AWS::ECR::ReplicationConfiguration" | "AWS::EC2::SubnetCidrBlock" | "AWS::Connect::SecurityProfile" | "AWS::CleanRoomsML::TrainingDataset" | "AWS::AppStream::AppBlockBuilder" | "AWS::Route53::DNSSEC" | "AWS::SageMaker::UserProfile" | "AWS::ApiGateway::Method" | (string & {});
export declare const ResourceType: any;
export type ResourceTypeList = ResourceType[];
export declare const ResourceTypeList: any;
export interface AssociateResourceTypesRequest {
    ConfigurationRecorderArn: string;
    ResourceTypes: ResourceType[];
}
export declare const AssociateResourceTypesRequest: S.Schema<AssociateResourceTypesRequest>;
export type RecorderName = string;
export type AllSupported = boolean;
export type IncludeGlobalResourceTypes = boolean;
export interface ExclusionByResourceTypes {
    resourceTypes?: ResourceType[];
}
export declare const ExclusionByResourceTypes: S.Schema<ExclusionByResourceTypes>;
export type RecordingStrategyType = "ALL_SUPPORTED_RESOURCE_TYPES" | "INCLUSION_BY_RESOURCE_TYPES" | "EXCLUSION_BY_RESOURCE_TYPES" | (string & {});
export declare const RecordingStrategyType: any;
export interface RecordingStrategy {
    useOnly?: RecordingStrategyType;
}
export declare const RecordingStrategy: S.Schema<RecordingStrategy>;
export interface RecordingGroup {
    allSupported?: boolean;
    includeGlobalResourceTypes?: boolean;
    resourceTypes?: ResourceType[];
    exclusionByResourceTypes?: ExclusionByResourceTypes;
    recordingStrategy?: RecordingStrategy;
}
export declare const RecordingGroup: S.Schema<RecordingGroup>;
export type RecordingFrequency = "CONTINUOUS" | "DAILY" | (string & {});
export declare const RecordingFrequency: any;
export type Description = string;
export type RecordingModeResourceTypesList = ResourceType[];
export declare const RecordingModeResourceTypesList: any;
export interface RecordingModeOverride {
    description?: string;
    resourceTypes: ResourceType[];
    recordingFrequency: RecordingFrequency;
}
export declare const RecordingModeOverride: S.Schema<RecordingModeOverride>;
export type RecordingModeOverrides = RecordingModeOverride[];
export declare const RecordingModeOverrides: any;
export interface RecordingMode {
    recordingFrequency: RecordingFrequency;
    recordingModeOverrides?: RecordingModeOverride[];
}
export declare const RecordingMode: S.Schema<RecordingMode>;
export type RecordingScope = "INTERNAL" | "PAID" | (string & {});
export declare const RecordingScope: any;
export type ServicePrincipal = string;
export type ScopeType = string;
export type ScopeValue = string;
export type ScopeValues = string[];
export declare const ScopeValues: any;
export type ThirdPartyCloudRegion = string;
export type IncludedRegions = string[];
export declare const IncludedRegions: any;
export interface ScopeConfiguration {
    scopeType: string;
    scopeValues?: string[];
    allRegions: boolean;
    includedRegions?: string[];
}
export declare const ScopeConfiguration: S.Schema<ScopeConfiguration>;
export interface ConfigurationRecorder {
    arn?: string;
    name?: string;
    roleARN?: string;
    recordingGroup?: RecordingGroup;
    recordingMode?: RecordingMode;
    recordingScope?: RecordingScope;
    servicePrincipal?: string;
    connectorArn?: string;
    scopeConfiguration?: ScopeConfiguration;
}
export declare const ConfigurationRecorder: S.Schema<ConfigurationRecorder>;
export interface AssociateResourceTypesResponse {
    ConfigurationRecorder: ConfigurationRecorder;
}
export declare const AssociateResourceTypesResponse: S.Schema<AssociateResourceTypesResponse>;
export type ConfigurationAggregatorName = string;
export type AccountId = string;
export type AwsRegion = string;
export type ResourceId = string;
export type ResourceName = string;
export interface AggregateResourceIdentifier {
    SourceAccountId: string;
    SourceRegion: string;
    ResourceId: string;
    ResourceType: ResourceType;
    ResourceName?: string;
}
export declare const AggregateResourceIdentifier: S.Schema<AggregateResourceIdentifier>;
export type ResourceIdentifiersList = AggregateResourceIdentifier[];
export declare const ResourceIdentifiersList: any;
export interface BatchGetAggregateResourceConfigRequest {
    ConfigurationAggregatorName: string;
    ResourceIdentifiers: AggregateResourceIdentifier[];
}
export declare const BatchGetAggregateResourceConfigRequest: S.Schema<BatchGetAggregateResourceConfigRequest>;
export type Version = string;
export type ConfigurationItemCaptureTime = Date;
export type ConfigurationItemStatus = "OK" | "ResourceDiscovered" | "ResourceNotRecorded" | "ResourceDeleted" | "ResourceDeletedNotRecorded" | (string & {});
export declare const ConfigurationItemStatus: any;
export type ConfigurationStateId = string;
export type ARN = string;
export type AvailabilityZone = string;
export type ResourceCreationTime = Date;
export type Configuration = string;
export type SupplementaryConfigurationName = string;
export type SupplementaryConfigurationValue = string;
export type SupplementaryConfiguration = {
    [key: string]: string | undefined;
};
export declare const SupplementaryConfiguration: any;
export type ConfigurationItemDeliveryTime = Date;
export interface BaseConfigurationItem {
    version?: string;
    accountId?: string;
    configurationItemCaptureTime?: Date;
    configurationItemStatus?: ConfigurationItemStatus;
    configurationStateId?: string;
    arn?: string;
    resourceType?: ResourceType;
    resourceId?: string;
    resourceName?: string;
    awsRegion?: string;
    availabilityZone?: string;
    resourceCreationTime?: Date;
    configuration?: string;
    supplementaryConfiguration?: {
        [key: string]: string | undefined;
    };
    recordingFrequency?: RecordingFrequency;
    configurationItemDeliveryTime?: Date;
}
export declare const BaseConfigurationItem: S.Schema<BaseConfigurationItem>;
export type BaseConfigurationItems = BaseConfigurationItem[];
export declare const BaseConfigurationItems: any;
export type UnprocessedResourceIdentifierList = AggregateResourceIdentifier[];
export declare const UnprocessedResourceIdentifierList: any;
export interface BatchGetAggregateResourceConfigResponse {
    BaseConfigurationItems?: BaseConfigurationItem[];
    UnprocessedResourceIdentifiers?: AggregateResourceIdentifier[];
}
export declare const BatchGetAggregateResourceConfigResponse: S.Schema<BatchGetAggregateResourceConfigResponse>;
export interface ResourceKey {
    resourceType: ResourceType;
    resourceId: string;
}
export declare const ResourceKey: S.Schema<ResourceKey>;
export type ResourceKeys = ResourceKey[];
export declare const ResourceKeys: any;
export interface BatchGetResourceConfigRequest {
    resourceKeys: ResourceKey[];
}
export declare const BatchGetResourceConfigRequest: S.Schema<BatchGetResourceConfigRequest>;
export interface BatchGetResourceConfigResponse {
    baseConfigurationItems?: BaseConfigurationItem[];
    unprocessedResourceKeys?: ResourceKey[];
}
export declare const BatchGetResourceConfigResponse: S.Schema<BatchGetResourceConfigResponse>;
export interface DeleteAggregationAuthorizationRequest {
    AuthorizedAccountId: string;
    AuthorizedAwsRegion: string;
}
export declare const DeleteAggregationAuthorizationRequest: S.Schema<DeleteAggregationAuthorizationRequest>;
export interface DeleteAggregationAuthorizationResponse {
}
export declare const DeleteAggregationAuthorizationResponse: S.Schema<DeleteAggregationAuthorizationResponse>;
export type ConfigRuleName = string;
export interface DeleteConfigRuleRequest {
    ConfigRuleName: string;
}
export declare const DeleteConfigRuleRequest: S.Schema<DeleteConfigRuleRequest>;
export interface DeleteConfigRuleResponse {
}
export declare const DeleteConfigRuleResponse: S.Schema<DeleteConfigRuleResponse>;
export interface DeleteConfigurationAggregatorRequest {
    ConfigurationAggregatorName: string;
}
export declare const DeleteConfigurationAggregatorRequest: S.Schema<DeleteConfigurationAggregatorRequest>;
export interface DeleteConfigurationAggregatorResponse {
}
export declare const DeleteConfigurationAggregatorResponse: S.Schema<DeleteConfigurationAggregatorResponse>;
export interface DeleteConfigurationRecorderRequest {
    ConfigurationRecorderName: string;
}
export declare const DeleteConfigurationRecorderRequest: S.Schema<DeleteConfigurationRecorderRequest>;
export interface DeleteConfigurationRecorderResponse {
}
export declare const DeleteConfigurationRecorderResponse: S.Schema<DeleteConfigurationRecorderResponse>;
export type ConformancePackName = string;
export interface DeleteConformancePackRequest {
    ConformancePackName: string;
}
export declare const DeleteConformancePackRequest: S.Schema<DeleteConformancePackRequest>;
export interface DeleteConformancePackResponse {
}
export declare const DeleteConformancePackResponse: S.Schema<DeleteConformancePackResponse>;
export interface DeleteConnectorRequest {
    Arn: string;
}
export declare const DeleteConnectorRequest: S.Schema<DeleteConnectorRequest>;
export interface DeleteConnectorResponse {
}
export declare const DeleteConnectorResponse: S.Schema<DeleteConnectorResponse>;
export type ChannelName = string;
export interface DeleteDeliveryChannelRequest {
    DeliveryChannelName: string;
}
export declare const DeleteDeliveryChannelRequest: S.Schema<DeleteDeliveryChannelRequest>;
export interface DeleteDeliveryChannelResponse {
}
export declare const DeleteDeliveryChannelResponse: S.Schema<DeleteDeliveryChannelResponse>;
export type StringWithCharLimit64 = string;
export interface DeleteEvaluationResultsRequest {
    ConfigRuleName: string;
}
export declare const DeleteEvaluationResultsRequest: S.Schema<DeleteEvaluationResultsRequest>;
export interface DeleteEvaluationResultsResponse {
}
export declare const DeleteEvaluationResultsResponse: S.Schema<DeleteEvaluationResultsResponse>;
export type OrganizationConfigRuleName = string;
export interface DeleteOrganizationConfigRuleRequest {
    OrganizationConfigRuleName: string;
}
export declare const DeleteOrganizationConfigRuleRequest: S.Schema<DeleteOrganizationConfigRuleRequest>;
export interface DeleteOrganizationConfigRuleResponse {
}
export declare const DeleteOrganizationConfigRuleResponse: S.Schema<DeleteOrganizationConfigRuleResponse>;
export type OrganizationConformancePackName = string;
export interface DeleteOrganizationConformancePackRequest {
    OrganizationConformancePackName: string;
}
export declare const DeleteOrganizationConformancePackRequest: S.Schema<DeleteOrganizationConformancePackRequest>;
export interface DeleteOrganizationConformancePackResponse {
}
export declare const DeleteOrganizationConformancePackResponse: S.Schema<DeleteOrganizationConformancePackResponse>;
export interface DeletePendingAggregationRequestRequest {
    RequesterAccountId: string;
    RequesterAwsRegion: string;
}
export declare const DeletePendingAggregationRequestRequest: S.Schema<DeletePendingAggregationRequestRequest>;
export interface DeletePendingAggregationRequestResponse {
}
export declare const DeletePendingAggregationRequestResponse: S.Schema<DeletePendingAggregationRequestResponse>;
export interface DeleteRemediationConfigurationRequest {
    ConfigRuleName: string;
    ResourceType?: string;
}
export declare const DeleteRemediationConfigurationRequest: S.Schema<DeleteRemediationConfigurationRequest>;
export interface DeleteRemediationConfigurationResponse {
}
export declare const DeleteRemediationConfigurationResponse: S.Schema<DeleteRemediationConfigurationResponse>;
export type StringWithCharLimit256 = string;
export type StringWithCharLimit1024 = string;
export interface RemediationExceptionResourceKey {
    ResourceType?: string;
    ResourceId?: string;
}
export declare const RemediationExceptionResourceKey: S.Schema<RemediationExceptionResourceKey>;
export type RemediationExceptionResourceKeys = RemediationExceptionResourceKey[];
export declare const RemediationExceptionResourceKeys: any;
export interface DeleteRemediationExceptionsRequest {
    ConfigRuleName: string;
    ResourceKeys: RemediationExceptionResourceKey[];
}
export declare const DeleteRemediationExceptionsRequest: S.Schema<DeleteRemediationExceptionsRequest>;
export interface FailedDeleteRemediationExceptionsBatch {
    FailureMessage?: string;
    FailedItems?: RemediationExceptionResourceKey[];
}
export declare const FailedDeleteRemediationExceptionsBatch: S.Schema<FailedDeleteRemediationExceptionsBatch>;
export type FailedDeleteRemediationExceptionsBatches = FailedDeleteRemediationExceptionsBatch[];
export declare const FailedDeleteRemediationExceptionsBatches: any;
export interface DeleteRemediationExceptionsResponse {
    FailedBatches?: FailedDeleteRemediationExceptionsBatch[];
}
export declare const DeleteRemediationExceptionsResponse: S.Schema<DeleteRemediationExceptionsResponse>;
export type ResourceTypeString = string;
export interface DeleteResourceConfigRequest {
    ResourceType: string;
    ResourceId: string;
}
export declare const DeleteResourceConfigRequest: S.Schema<DeleteResourceConfigRequest>;
export interface DeleteResourceConfigResponse {
}
export declare const DeleteResourceConfigResponse: S.Schema<DeleteResourceConfigResponse>;
export type RetentionConfigurationName = string;
export interface DeleteRetentionConfigurationRequest {
    RetentionConfigurationName: string;
}
export declare const DeleteRetentionConfigurationRequest: S.Schema<DeleteRetentionConfigurationRequest>;
export interface DeleteRetentionConfigurationResponse {
}
export declare const DeleteRetentionConfigurationResponse: S.Schema<DeleteRetentionConfigurationResponse>;
export interface DeleteServiceLinkedConfigurationRecorderRequest {
    ServicePrincipal?: string;
    Arn?: string;
}
export declare const DeleteServiceLinkedConfigurationRecorderRequest: S.Schema<DeleteServiceLinkedConfigurationRecorderRequest>;
export interface DeleteServiceLinkedConfigurationRecorderResponse {
    Arn: string;
    Name: string;
}
export declare const DeleteServiceLinkedConfigurationRecorderResponse: S.Schema<DeleteServiceLinkedConfigurationRecorderResponse>;
export type QueryName = string;
export interface DeleteStoredQueryRequest {
    QueryName: string;
}
export declare const DeleteStoredQueryRequest: S.Schema<DeleteStoredQueryRequest>;
export interface DeleteStoredQueryResponse {
}
export declare const DeleteStoredQueryResponse: S.Schema<DeleteStoredQueryResponse>;
export interface DeliverConfigSnapshotRequest {
    deliveryChannelName: string;
}
export declare const DeliverConfigSnapshotRequest: S.Schema<DeliverConfigSnapshotRequest>;
export interface DeliverConfigSnapshotResponse {
    configSnapshotId?: string;
}
export declare const DeliverConfigSnapshotResponse: S.Schema<DeliverConfigSnapshotResponse>;
export type ComplianceType = "COMPLIANT" | "NON_COMPLIANT" | "NOT_APPLICABLE" | "INSUFFICIENT_DATA" | (string & {});
export declare const ComplianceType: any;
export interface ConfigRuleComplianceFilters {
    ConfigRuleName?: string;
    ComplianceType?: ComplianceType;
    AccountId?: string;
    AwsRegion?: string;
}
export declare const ConfigRuleComplianceFilters: S.Schema<ConfigRuleComplianceFilters>;
export type GroupByAPILimit = number;
export type NextToken = string;
export interface DescribeAggregateComplianceByConfigRulesRequest {
    ConfigurationAggregatorName: string;
    Filters?: ConfigRuleComplianceFilters;
    Limit?: number;
    NextToken?: string;
}
export declare const DescribeAggregateComplianceByConfigRulesRequest: S.Schema<DescribeAggregateComplianceByConfigRulesRequest>;
export interface ComplianceContributorCount {
    CappedCount?: number;
    CapExceeded?: boolean;
}
export declare const ComplianceContributorCount: S.Schema<ComplianceContributorCount>;
export interface Compliance {
    ComplianceType?: ComplianceType;
    ComplianceContributorCount?: ComplianceContributorCount;
}
export declare const Compliance: S.Schema<Compliance>;
export interface AggregateComplianceByConfigRule {
    ConfigRuleName?: string;
    Compliance?: Compliance;
    AccountId?: string;
    AwsRegion?: string;
}
export declare const AggregateComplianceByConfigRule: S.Schema<AggregateComplianceByConfigRule>;
export type AggregateComplianceByConfigRuleList = AggregateComplianceByConfigRule[];
export declare const AggregateComplianceByConfigRuleList: any;
export interface DescribeAggregateComplianceByConfigRulesResponse {
    AggregateComplianceByConfigRules?: AggregateComplianceByConfigRule[];
    NextToken?: string;
}
export declare const DescribeAggregateComplianceByConfigRulesResponse: S.Schema<DescribeAggregateComplianceByConfigRulesResponse>;
export type ConformancePackComplianceType = "COMPLIANT" | "NON_COMPLIANT" | "INSUFFICIENT_DATA" | (string & {});
export declare const ConformancePackComplianceType: any;
export interface AggregateConformancePackComplianceFilters {
    ConformancePackName?: string;
    ComplianceType?: ConformancePackComplianceType;
    AccountId?: string;
    AwsRegion?: string;
}
export declare const AggregateConformancePackComplianceFilters: S.Schema<AggregateConformancePackComplianceFilters>;
export type Limit = number;
export interface DescribeAggregateComplianceByConformancePacksRequest {
    ConfigurationAggregatorName: string;
    Filters?: AggregateConformancePackComplianceFilters;
    Limit?: number;
    NextToken?: string;
}
export declare const DescribeAggregateComplianceByConformancePacksRequest: S.Schema<DescribeAggregateComplianceByConformancePacksRequest>;
export interface AggregateConformancePackCompliance {
    ComplianceType?: ConformancePackComplianceType;
    CompliantRuleCount?: number;
    NonCompliantRuleCount?: number;
    TotalRuleCount?: number;
}
export declare const AggregateConformancePackCompliance: S.Schema<AggregateConformancePackCompliance>;
export interface AggregateComplianceByConformancePack {
    ConformancePackName?: string;
    Compliance?: AggregateConformancePackCompliance;
    AccountId?: string;
    AwsRegion?: string;
}
export declare const AggregateComplianceByConformancePack: S.Schema<AggregateComplianceByConformancePack>;
export type AggregateComplianceByConformancePackList = AggregateComplianceByConformancePack[];
export declare const AggregateComplianceByConformancePackList: any;
export interface DescribeAggregateComplianceByConformancePacksResponse {
    AggregateComplianceByConformancePacks?: AggregateComplianceByConformancePack[];
    NextToken?: string;
}
export declare const DescribeAggregateComplianceByConformancePacksResponse: S.Schema<DescribeAggregateComplianceByConformancePacksResponse>;
export interface DescribeAggregationAuthorizationsRequest {
    Limit?: number;
    NextToken?: string;
}
export declare const DescribeAggregationAuthorizationsRequest: S.Schema<DescribeAggregationAuthorizationsRequest>;
export interface AggregationAuthorization {
    AggregationAuthorizationArn?: string;
    AuthorizedAccountId?: string;
    AuthorizedAwsRegion?: string;
    CreationTime?: Date;
}
export declare const AggregationAuthorization: S.Schema<AggregationAuthorization>;
export type AggregationAuthorizationList = AggregationAuthorization[];
export declare const AggregationAuthorizationList: any;
export interface DescribeAggregationAuthorizationsResponse {
    AggregationAuthorizations?: AggregationAuthorization[];
    NextToken?: string;
}
export declare const DescribeAggregationAuthorizationsResponse: S.Schema<DescribeAggregationAuthorizationsResponse>;
export type ConfigRuleNames = string[];
export declare const ConfigRuleNames: any;
export type ComplianceTypes = ComplianceType[];
export declare const ComplianceTypes: any;
export interface DescribeComplianceByConfigRuleRequest {
    ConfigRuleNames?: string[];
    ComplianceTypes?: ComplianceType[];
    NextToken?: string;
}
export declare const DescribeComplianceByConfigRuleRequest: S.Schema<DescribeComplianceByConfigRuleRequest>;
export interface ComplianceByConfigRule {
    ConfigRuleName?: string;
    Compliance?: Compliance;
}
export declare const ComplianceByConfigRule: S.Schema<ComplianceByConfigRule>;
export type ComplianceByConfigRules = ComplianceByConfigRule[];
export declare const ComplianceByConfigRules: any;
export interface DescribeComplianceByConfigRuleResponse {
    ComplianceByConfigRules?: ComplianceByConfigRule[];
    NextToken?: string;
}
export declare const DescribeComplianceByConfigRuleResponse: S.Schema<DescribeComplianceByConfigRuleResponse>;
export type BaseResourceId = string;
export interface DescribeComplianceByResourceRequest {
    ResourceType?: string;
    ResourceId?: string;
    ComplianceTypes?: ComplianceType[];
    Limit?: number;
    NextToken?: string;
}
export declare const DescribeComplianceByResourceRequest: S.Schema<DescribeComplianceByResourceRequest>;
export interface ComplianceByResource {
    ResourceType?: string;
    ResourceId?: string;
    Compliance?: Compliance;
}
export declare const ComplianceByResource: S.Schema<ComplianceByResource>;
export type ComplianceByResources = ComplianceByResource[];
export declare const ComplianceByResources: any;
export interface DescribeComplianceByResourceResponse {
    ComplianceByResources?: ComplianceByResource[];
    NextToken?: string;
}
export declare const DescribeComplianceByResourceResponse: S.Schema<DescribeComplianceByResourceResponse>;
export type RuleLimit = number;
export interface DescribeConfigRuleEvaluationStatusRequest {
    ConfigRuleNames?: string[];
    NextToken?: string;
    Limit?: number;
}
export declare const DescribeConfigRuleEvaluationStatusRequest: S.Schema<DescribeConfigRuleEvaluationStatusRequest>;
export interface ConfigRuleEvaluationStatus {
    ConfigRuleName?: string;
    ConfigRuleArn?: string;
    ConfigRuleId?: string;
    LastSuccessfulInvocationTime?: Date;
    LastFailedInvocationTime?: Date;
    LastSuccessfulEvaluationTime?: Date;
    LastFailedEvaluationTime?: Date;
    FirstActivatedTime?: Date;
    LastDeactivatedTime?: Date;
    LastErrorCode?: string;
    LastErrorMessage?: string;
    FirstEvaluationStarted?: boolean;
    LastDebugLogDeliveryStatus?: string;
    LastDebugLogDeliveryStatusReason?: string;
    LastDebugLogDeliveryTime?: Date;
}
export declare const ConfigRuleEvaluationStatus: S.Schema<ConfigRuleEvaluationStatus>;
export type ConfigRuleEvaluationStatusList = ConfigRuleEvaluationStatus[];
export declare const ConfigRuleEvaluationStatusList: any;
export interface DescribeConfigRuleEvaluationStatusResponse {
    ConfigRulesEvaluationStatus?: ConfigRuleEvaluationStatus[];
    NextToken?: string;
}
export declare const DescribeConfigRuleEvaluationStatusResponse: S.Schema<DescribeConfigRuleEvaluationStatusResponse>;
export type EvaluationMode = "DETECTIVE" | "PROACTIVE" | (string & {});
export declare const EvaluationMode: any;
export type RuleEvaluationVisibility = "EXTERNAL" | "INTERNAL" | (string & {});
export declare const RuleEvaluationVisibility: any;
export interface DescribeConfigRulesFilters {
    EvaluationMode?: EvaluationMode;
    RuleEvaluationVisibility?: RuleEvaluationVisibility;
}
export declare const DescribeConfigRulesFilters: S.Schema<DescribeConfigRulesFilters>;
export interface DescribeConfigRulesRequest {
    ConfigRuleNames?: string[];
    Filters?: DescribeConfigRulesFilters;
    NextToken?: string;
}
export declare const DescribeConfigRulesRequest: S.Schema<DescribeConfigRulesRequest>;
export type EmptiableStringWithCharLimit256 = string;
export type ComplianceResourceTypes = string[];
export declare const ComplianceResourceTypes: any;
export type StringWithCharLimit128 = string;
export type ServicePrincipals = string[];
export declare const ServicePrincipals: any;
export interface Scope {
    ComplianceResourceTypes?: string[];
    TagKey?: string;
    TagValue?: string;
    ComplianceResourceId?: string;
    ServicePrincipals?: string[];
}
export declare const Scope: S.Schema<Scope>;
export type Owner = "CUSTOM_LAMBDA" | "AWS" | "CUSTOM_POLICY" | (string & {});
export declare const Owner: any;
export type EventSource = "aws.config" | (string & {});
export declare const EventSource: any;
export type MessageType = "ConfigurationItemChangeNotification" | "ConfigurationSnapshotDeliveryCompleted" | "ScheduledNotification" | "OversizedConfigurationItemChangeNotification" | (string & {});
export declare const MessageType: any;
export type MaximumExecutionFrequency = "One_Hour" | "Three_Hours" | "Six_Hours" | "Twelve_Hours" | "TwentyFour_Hours" | (string & {});
export declare const MaximumExecutionFrequency: any;
export interface SourceDetail {
    EventSource?: EventSource;
    MessageType?: MessageType;
    MaximumExecutionFrequency?: MaximumExecutionFrequency;
}
export declare const SourceDetail: S.Schema<SourceDetail>;
export type SourceDetails = SourceDetail[];
export declare const SourceDetails: any;
export type PolicyRuntime = string;
export type PolicyText = string;
export interface CustomPolicyDetails {
    PolicyRuntime: string;
    PolicyText: string;
    EnableDebugLogDelivery?: boolean;
}
export declare const CustomPolicyDetails: S.Schema<CustomPolicyDetails>;
export interface Source {
    Owner: Owner;
    SourceIdentifier?: string;
    SourceDetails?: SourceDetail[];
    CustomPolicyDetails?: CustomPolicyDetails;
}
export declare const Source: S.Schema<Source>;
export type ConfigRuleState = "ACTIVE" | "DELETING" | "DELETING_RESULTS" | "EVALUATING" | (string & {});
export declare const ConfigRuleState: any;
export interface EvaluationModeConfiguration {
    Mode?: EvaluationMode;
}
export declare const EvaluationModeConfiguration: S.Schema<EvaluationModeConfiguration>;
export type EvaluationModes = EvaluationModeConfiguration[];
export declare const EvaluationModes: any;
export interface ConfigRule {
    ConfigRuleName?: string;
    ConfigRuleArn?: string;
    ConfigRuleId?: string;
    Description?: string;
    Scope?: Scope;
    Source: Source;
    InputParameters?: string;
    MaximumExecutionFrequency?: MaximumExecutionFrequency;
    ConfigRuleState?: ConfigRuleState;
    CreatedBy?: string;
    EvaluationModes?: EvaluationModeConfiguration[];
    RuleEvaluationVisibility?: RuleEvaluationVisibility;
}
export declare const ConfigRule: S.Schema<ConfigRule>;
export type ConfigRules = ConfigRule[];
export declare const ConfigRules: any;
export interface DescribeConfigRulesResponse {
    ConfigRules?: ConfigRule[];
    NextToken?: string;
}
export declare const DescribeConfigRulesResponse: S.Schema<DescribeConfigRulesResponse>;
export type ConfigurationAggregatorNameList = string[];
export declare const ConfigurationAggregatorNameList: any;
export interface DescribeConfigurationAggregatorsRequest {
    ConfigurationAggregatorNames?: string[];
    NextToken?: string;
    Limit?: number;
}
export declare const DescribeConfigurationAggregatorsRequest: S.Schema<DescribeConfigurationAggregatorsRequest>;
export type ConfigurationAggregatorArn = string;
export type AccountAggregationSourceAccountList = string[];
export declare const AccountAggregationSourceAccountList: any;
export type AggregatorRegionList = string[];
export declare const AggregatorRegionList: any;
export interface AccountAggregationSource {
    AccountIds: string[];
    AllAwsRegions?: boolean;
    AwsRegions?: string[];
}
export declare const AccountAggregationSource: S.Schema<AccountAggregationSource>;
export type AccountAggregationSourceList = AccountAggregationSource[];
export declare const AccountAggregationSourceList: any;
export interface OrganizationAggregationSource {
    RoleArn: string;
    AwsRegions?: string[];
    AllAwsRegions?: boolean;
}
export declare const OrganizationAggregationSource: S.Schema<OrganizationAggregationSource>;
export type AggregatorFilterType = "INCLUDE" | (string & {});
export declare const AggregatorFilterType: any;
export type ResourceTypeValue = string;
export type ResourceTypeValueList = string[];
export declare const ResourceTypeValueList: any;
export interface AggregatorFilterResourceType {
    Type?: AggregatorFilterType;
    Value?: string[];
}
export declare const AggregatorFilterResourceType: S.Schema<AggregatorFilterResourceType>;
export type ServicePrincipalValue = string;
export type ServicePrincipalValueList = string[];
export declare const ServicePrincipalValueList: any;
export interface AggregatorFilterServicePrincipal {
    Type?: AggregatorFilterType;
    Value?: string[];
}
export declare const AggregatorFilterServicePrincipal: S.Schema<AggregatorFilterServicePrincipal>;
export interface AggregatorFilters {
    ResourceType?: AggregatorFilterResourceType;
    ServicePrincipal?: AggregatorFilterServicePrincipal;
}
export declare const AggregatorFilters: S.Schema<AggregatorFilters>;
export interface ConfigurationAggregator {
    ConfigurationAggregatorName?: string;
    ConfigurationAggregatorArn?: string;
    AccountAggregationSources?: AccountAggregationSource[];
    OrganizationAggregationSource?: OrganizationAggregationSource;
    CreationTime?: Date;
    LastUpdatedTime?: Date;
    CreatedBy?: string;
    AggregatorFilters?: AggregatorFilters;
}
export declare const ConfigurationAggregator: S.Schema<ConfigurationAggregator>;
export type ConfigurationAggregatorList = ConfigurationAggregator[];
export declare const ConfigurationAggregatorList: any;
export interface DescribeConfigurationAggregatorsResponse {
    ConfigurationAggregators?: ConfigurationAggregator[];
    NextToken?: string;
}
export declare const DescribeConfigurationAggregatorsResponse: S.Schema<DescribeConfigurationAggregatorsResponse>;
export type AggregatedSourceStatusType = "FAILED" | "SUCCEEDED" | "OUTDATED" | (string & {});
export declare const AggregatedSourceStatusType: any;
export type AggregatedSourceStatusTypeList = AggregatedSourceStatusType[];
export declare const AggregatedSourceStatusTypeList: any;
export interface DescribeConfigurationAggregatorSourcesStatusRequest {
    ConfigurationAggregatorName: string;
    UpdateStatus?: AggregatedSourceStatusType[];
    NextToken?: string;
    Limit?: number;
}
export declare const DescribeConfigurationAggregatorSourcesStatusRequest: S.Schema<DescribeConfigurationAggregatorSourcesStatusRequest>;
export type AggregatedSourceType = "ACCOUNT" | "ORGANIZATION" | (string & {});
export declare const AggregatedSourceType: any;
export interface AggregatedSourceStatus {
    SourceId?: string;
    SourceType?: AggregatedSourceType;
    AwsRegion?: string;
    LastUpdateStatus?: AggregatedSourceStatusType;
    LastUpdateTime?: Date;
    LastErrorCode?: string;
    LastErrorMessage?: string;
}
export declare const AggregatedSourceStatus: S.Schema<AggregatedSourceStatus>;
export type AggregatedSourceStatusList = AggregatedSourceStatus[];
export declare const AggregatedSourceStatusList: any;
export interface DescribeConfigurationAggregatorSourcesStatusResponse {
    AggregatedSourceStatusList?: AggregatedSourceStatus[];
    NextToken?: string;
}
export declare const DescribeConfigurationAggregatorSourcesStatusResponse: S.Schema<DescribeConfigurationAggregatorSourcesStatusResponse>;
export type ConfigurationRecorderNameList = string[];
export declare const ConfigurationRecorderNameList: any;
export interface DescribeConfigurationRecordersRequest {
    ConfigurationRecorderNames?: string[];
    ServicePrincipal?: string;
    Arn?: string;
}
export declare const DescribeConfigurationRecordersRequest: S.Schema<DescribeConfigurationRecordersRequest>;
export type ConfigurationRecorderList = ConfigurationRecorder[];
export declare const ConfigurationRecorderList: any;
export interface DescribeConfigurationRecordersResponse {
    ConfigurationRecorders?: ConfigurationRecorder[];
}
export declare const DescribeConfigurationRecordersResponse: S.Schema<DescribeConfigurationRecordersResponse>;
export interface DescribeConfigurationRecorderStatusRequest {
    ConfigurationRecorderNames?: string[];
    ServicePrincipal?: string;
    Arn?: string;
}
export declare const DescribeConfigurationRecorderStatusRequest: S.Schema<DescribeConfigurationRecorderStatusRequest>;
export type RecorderStatus = "Pending" | "Success" | "Failure" | "NotApplicable" | (string & {});
export declare const RecorderStatus: any;
export interface ConfigurationRecorderStatus {
    arn?: string;
    name?: string;
    lastStartTime?: Date;
    lastStopTime?: Date;
    recording?: boolean;
    lastStatus?: RecorderStatus;
    lastErrorCode?: string;
    lastErrorMessage?: string;
    lastStatusChangeTime?: Date;
    servicePrincipal?: string;
}
export declare const ConfigurationRecorderStatus: S.Schema<ConfigurationRecorderStatus>;
export type ConfigurationRecorderStatusList = ConfigurationRecorderStatus[];
export declare const ConfigurationRecorderStatusList: any;
export interface DescribeConfigurationRecorderStatusResponse {
    ConfigurationRecordersStatus?: ConfigurationRecorderStatus[];
}
export declare const DescribeConfigurationRecorderStatusResponse: S.Schema<DescribeConfigurationRecorderStatusResponse>;
export type ConformancePackConfigRuleNames = string[];
export declare const ConformancePackConfigRuleNames: any;
export interface ConformancePackComplianceFilters {
    ConfigRuleNames?: string[];
    ComplianceType?: ConformancePackComplianceType;
}
export declare const ConformancePackComplianceFilters: S.Schema<ConformancePackComplianceFilters>;
export type DescribeConformancePackComplianceLimit = number;
export interface DescribeConformancePackComplianceRequest {
    ConformancePackName: string;
    Filters?: ConformancePackComplianceFilters;
    Limit?: number;
    NextToken?: string;
}
export declare const DescribeConformancePackComplianceRequest: S.Schema<DescribeConformancePackComplianceRequest>;
export type ControlsList = string[];
export declare const ControlsList: any;
export interface ConformancePackRuleCompliance {
    ConfigRuleName?: string;
    ComplianceType?: ConformancePackComplianceType;
    Controls?: string[];
}
export declare const ConformancePackRuleCompliance: S.Schema<ConformancePackRuleCompliance>;
export type ConformancePackRuleComplianceList = ConformancePackRuleCompliance[];
export declare const ConformancePackRuleComplianceList: any;
export interface DescribeConformancePackComplianceResponse {
    ConformancePackName: string;
    ConformancePackRuleComplianceList: ConformancePackRuleCompliance[];
    NextToken?: string;
}
export declare const DescribeConformancePackComplianceResponse: S.Schema<DescribeConformancePackComplianceResponse>;
export type ConformancePackNamesList = string[];
export declare const ConformancePackNamesList: any;
export type PageSizeLimit = number;
export interface DescribeConformancePacksRequest {
    ConformancePackNames?: string[];
    Limit?: number;
    NextToken?: string;
}
export declare const DescribeConformancePacksRequest: S.Schema<DescribeConformancePacksRequest>;
export type ConformancePackArn = string;
export type ConformancePackId = string;
export type DeliveryS3Bucket = string;
export type DeliveryS3KeyPrefix = string;
export type ParameterName = string;
export type ParameterValue = string;
export interface ConformancePackInputParameter {
    ParameterName: string;
    ParameterValue: string;
}
export declare const ConformancePackInputParameter: S.Schema<ConformancePackInputParameter>;
export type ConformancePackInputParameters = ConformancePackInputParameter[];
export declare const ConformancePackInputParameters: any;
export type SSMDocumentName = string;
export type SSMDocumentVersion = string;
export interface TemplateSSMDocumentDetails {
    DocumentName: string;
    DocumentVersion?: string;
}
export declare const TemplateSSMDocumentDetails: S.Schema<TemplateSSMDocumentDetails>;
export interface ConformancePackDetail {
    ConformancePackName: string;
    ConformancePackArn: string;
    ConformancePackId: string;
    DeliveryS3Bucket?: string;
    DeliveryS3KeyPrefix?: string;
    ConformancePackInputParameters?: ConformancePackInputParameter[];
    LastUpdateRequestedTime?: Date;
    CreatedBy?: string;
    TemplateSSMDocumentDetails?: TemplateSSMDocumentDetails;
}
export declare const ConformancePackDetail: S.Schema<ConformancePackDetail>;
export type ConformancePackDetailList = ConformancePackDetail[];
export declare const ConformancePackDetailList: any;
export interface DescribeConformancePacksResponse {
    ConformancePackDetails?: ConformancePackDetail[];
    NextToken?: string;
}
export declare const DescribeConformancePacksResponse: S.Schema<DescribeConformancePacksResponse>;
export interface DescribeConformancePackStatusRequest {
    ConformancePackNames?: string[];
    Limit?: number;
    NextToken?: string;
}
export declare const DescribeConformancePackStatusRequest: S.Schema<DescribeConformancePackStatusRequest>;
export type ConformancePackState = "CREATE_IN_PROGRESS" | "CREATE_COMPLETE" | "CREATE_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export declare const ConformancePackState: any;
export type StackArn = string;
export type ConformancePackStatusReason = string;
export interface ConformancePackStatusDetail {
    ConformancePackName: string;
    ConformancePackId: string;
    ConformancePackArn: string;
    ConformancePackState: ConformancePackState;
    StackArn: string;
    ConformancePackStatusReason?: string;
    LastUpdateRequestedTime: Date;
    LastUpdateCompletedTime?: Date;
}
export declare const ConformancePackStatusDetail: S.Schema<ConformancePackStatusDetail>;
export type ConformancePackStatusDetailsList = ConformancePackStatusDetail[];
export declare const ConformancePackStatusDetailsList: any;
export interface DescribeConformancePackStatusResponse {
    ConformancePackStatusDetails?: ConformancePackStatusDetail[];
    NextToken?: string;
}
export declare const DescribeConformancePackStatusResponse: S.Schema<DescribeConformancePackStatusResponse>;
export type DeliveryChannelNameList = string[];
export declare const DeliveryChannelNameList: any;
export interface DescribeDeliveryChannelsRequest {
    DeliveryChannelNames?: string[];
}
export declare const DescribeDeliveryChannelsRequest: S.Schema<DescribeDeliveryChannelsRequest>;
export interface ConfigSnapshotDeliveryProperties {
    deliveryFrequency?: MaximumExecutionFrequency;
}
export declare const ConfigSnapshotDeliveryProperties: S.Schema<ConfigSnapshotDeliveryProperties>;
export interface DeliveryChannel {
    name?: string;
    s3BucketName?: string;
    s3KeyPrefix?: string;
    s3KmsKeyArn?: string;
    snsTopicARN?: string;
    configSnapshotDeliveryProperties?: ConfigSnapshotDeliveryProperties;
}
export declare const DeliveryChannel: S.Schema<DeliveryChannel>;
export type DeliveryChannelList = DeliveryChannel[];
export declare const DeliveryChannelList: any;
export interface DescribeDeliveryChannelsResponse {
    DeliveryChannels?: DeliveryChannel[];
}
export declare const DescribeDeliveryChannelsResponse: S.Schema<DescribeDeliveryChannelsResponse>;
export interface DescribeDeliveryChannelStatusRequest {
    DeliveryChannelNames?: string[];
}
export declare const DescribeDeliveryChannelStatusRequest: S.Schema<DescribeDeliveryChannelStatusRequest>;
export type DeliveryStatus = "Success" | "Failure" | "Not_Applicable" | (string & {});
export declare const DeliveryStatus: any;
export interface ConfigExportDeliveryInfo {
    lastStatus?: DeliveryStatus;
    lastErrorCode?: string;
    lastErrorMessage?: string;
    lastAttemptTime?: Date;
    lastSuccessfulTime?: Date;
    nextDeliveryTime?: Date;
}
export declare const ConfigExportDeliveryInfo: S.Schema<ConfigExportDeliveryInfo>;
export interface ConfigStreamDeliveryInfo {
    lastStatus?: DeliveryStatus;
    lastErrorCode?: string;
    lastErrorMessage?: string;
    lastStatusChangeTime?: Date;
}
export declare const ConfigStreamDeliveryInfo: S.Schema<ConfigStreamDeliveryInfo>;
export interface DeliveryChannelStatus {
    name?: string;
    configSnapshotDeliveryInfo?: ConfigExportDeliveryInfo;
    configHistoryDeliveryInfo?: ConfigExportDeliveryInfo;
    configStreamDeliveryInfo?: ConfigStreamDeliveryInfo;
}
export declare const DeliveryChannelStatus: S.Schema<DeliveryChannelStatus>;
export type DeliveryChannelStatusList = DeliveryChannelStatus[];
export declare const DeliveryChannelStatusList: any;
export interface DescribeDeliveryChannelStatusResponse {
    DeliveryChannelsStatus?: DeliveryChannelStatus[];
}
export declare const DescribeDeliveryChannelStatusResponse: S.Schema<DescribeDeliveryChannelStatusResponse>;
export type OrganizationConfigRuleNames = string[];
export declare const OrganizationConfigRuleNames: any;
export type CosmosPageLimit = number;
export interface DescribeOrganizationConfigRulesRequest {
    OrganizationConfigRuleNames?: string[];
    Limit?: number;
    NextToken?: string;
}
export declare const DescribeOrganizationConfigRulesRequest: S.Schema<DescribeOrganizationConfigRulesRequest>;
export type StringWithCharLimit256Min0 = string;
export type ResourceTypesScope = string[];
export declare const ResourceTypesScope: any;
export type StringWithCharLimit768 = string;
export interface OrganizationManagedRuleMetadata {
    Description?: string;
    RuleIdentifier: string;
    InputParameters?: string;
    MaximumExecutionFrequency?: MaximumExecutionFrequency;
    ResourceTypesScope?: string[];
    ResourceIdScope?: string;
    TagKeyScope?: string;
    TagValueScope?: string;
}
export declare const OrganizationManagedRuleMetadata: S.Schema<OrganizationManagedRuleMetadata>;
export type OrganizationConfigRuleTriggerType = "ConfigurationItemChangeNotification" | "OversizedConfigurationItemChangeNotification" | "ScheduledNotification" | (string & {});
export declare const OrganizationConfigRuleTriggerType: any;
export type OrganizationConfigRuleTriggerTypes = OrganizationConfigRuleTriggerType[];
export declare const OrganizationConfigRuleTriggerTypes: any;
export interface OrganizationCustomRuleMetadata {
    Description?: string;
    LambdaFunctionArn: string;
    OrganizationConfigRuleTriggerTypes: OrganizationConfigRuleTriggerType[];
    InputParameters?: string;
    MaximumExecutionFrequency?: MaximumExecutionFrequency;
    ResourceTypesScope?: string[];
    ResourceIdScope?: string;
    TagKeyScope?: string;
    TagValueScope?: string;
}
export declare const OrganizationCustomRuleMetadata: S.Schema<OrganizationCustomRuleMetadata>;
export type ExcludedAccounts = string[];
export declare const ExcludedAccounts: any;
export type OrganizationConfigRuleTriggerTypeNoSN = "ConfigurationItemChangeNotification" | "OversizedConfigurationItemChangeNotification" | (string & {});
export declare const OrganizationConfigRuleTriggerTypeNoSN: any;
export type OrganizationConfigRuleTriggerTypeNoSNs = OrganizationConfigRuleTriggerTypeNoSN[];
export declare const OrganizationConfigRuleTriggerTypeNoSNs: any;
export type DebugLogDeliveryAccounts = string[];
export declare const DebugLogDeliveryAccounts: any;
export interface OrganizationCustomPolicyRuleMetadataNoPolicy {
    Description?: string;
    OrganizationConfigRuleTriggerTypes?: OrganizationConfigRuleTriggerTypeNoSN[];
    InputParameters?: string;
    MaximumExecutionFrequency?: MaximumExecutionFrequency;
    ResourceTypesScope?: string[];
    ResourceIdScope?: string;
    TagKeyScope?: string;
    TagValueScope?: string;
    PolicyRuntime?: string;
    DebugLogDeliveryAccounts?: string[];
}
export declare const OrganizationCustomPolicyRuleMetadataNoPolicy: S.Schema<OrganizationCustomPolicyRuleMetadataNoPolicy>;
export interface OrganizationConfigRule {
    OrganizationConfigRuleName: string;
    OrganizationConfigRuleArn: string;
    OrganizationManagedRuleMetadata?: OrganizationManagedRuleMetadata;
    OrganizationCustomRuleMetadata?: OrganizationCustomRuleMetadata;
    ExcludedAccounts?: string[];
    LastUpdateTime?: Date;
    OrganizationCustomPolicyRuleMetadata?: OrganizationCustomPolicyRuleMetadataNoPolicy;
}
export declare const OrganizationConfigRule: S.Schema<OrganizationConfigRule>;
export type OrganizationConfigRules = OrganizationConfigRule[];
export declare const OrganizationConfigRules: any;
export interface DescribeOrganizationConfigRulesResponse {
    OrganizationConfigRules?: OrganizationConfigRule[];
    NextToken?: string;
}
export declare const DescribeOrganizationConfigRulesResponse: S.Schema<DescribeOrganizationConfigRulesResponse>;
export interface DescribeOrganizationConfigRuleStatusesRequest {
    OrganizationConfigRuleNames?: string[];
    Limit?: number;
    NextToken?: string;
}
export declare const DescribeOrganizationConfigRuleStatusesRequest: S.Schema<DescribeOrganizationConfigRuleStatusesRequest>;
export type OrganizationRuleStatus = "CREATE_SUCCESSFUL" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "DELETE_SUCCESSFUL" | "DELETE_FAILED" | "DELETE_IN_PROGRESS" | "UPDATE_SUCCESSFUL" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | (string & {});
export declare const OrganizationRuleStatus: any;
export interface OrganizationConfigRuleStatus {
    OrganizationConfigRuleName: string;
    OrganizationRuleStatus: OrganizationRuleStatus;
    ErrorCode?: string;
    ErrorMessage?: string;
    LastUpdateTime?: Date;
}
export declare const OrganizationConfigRuleStatus: S.Schema<OrganizationConfigRuleStatus>;
export type OrganizationConfigRuleStatuses = OrganizationConfigRuleStatus[];
export declare const OrganizationConfigRuleStatuses: any;
export interface DescribeOrganizationConfigRuleStatusesResponse {
    OrganizationConfigRuleStatuses?: OrganizationConfigRuleStatus[];
    NextToken?: string;
}
export declare const DescribeOrganizationConfigRuleStatusesResponse: S.Schema<DescribeOrganizationConfigRuleStatusesResponse>;
export type OrganizationConformancePackNames = string[];
export declare const OrganizationConformancePackNames: any;
export interface DescribeOrganizationConformancePacksRequest {
    OrganizationConformancePackNames?: string[];
    Limit?: number;
    NextToken?: string;
}
export declare const DescribeOrganizationConformancePacksRequest: S.Schema<DescribeOrganizationConformancePacksRequest>;
export interface OrganizationConformancePack {
    OrganizationConformancePackName: string;
    OrganizationConformancePackArn: string;
    DeliveryS3Bucket?: string;
    DeliveryS3KeyPrefix?: string;
    ConformancePackInputParameters?: ConformancePackInputParameter[];
    ExcludedAccounts?: string[];
    LastUpdateTime: Date;
}
export declare const OrganizationConformancePack: S.Schema<OrganizationConformancePack>;
export type OrganizationConformancePacks = OrganizationConformancePack[];
export declare const OrganizationConformancePacks: any;
export interface DescribeOrganizationConformancePacksResponse {
    OrganizationConformancePacks?: OrganizationConformancePack[];
    NextToken?: string;
}
export declare const DescribeOrganizationConformancePacksResponse: S.Schema<DescribeOrganizationConformancePacksResponse>;
export interface DescribeOrganizationConformancePackStatusesRequest {
    OrganizationConformancePackNames?: string[];
    Limit?: number;
    NextToken?: string;
}
export declare const DescribeOrganizationConformancePackStatusesRequest: S.Schema<DescribeOrganizationConformancePackStatusesRequest>;
export type OrganizationResourceStatus = "CREATE_SUCCESSFUL" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "DELETE_SUCCESSFUL" | "DELETE_FAILED" | "DELETE_IN_PROGRESS" | "UPDATE_SUCCESSFUL" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | (string & {});
export declare const OrganizationResourceStatus: any;
export interface OrganizationConformancePackStatus {
    OrganizationConformancePackName: string;
    Status: OrganizationResourceStatus;
    ErrorCode?: string;
    ErrorMessage?: string;
    LastUpdateTime?: Date;
}
export declare const OrganizationConformancePackStatus: S.Schema<OrganizationConformancePackStatus>;
export type OrganizationConformancePackStatuses = OrganizationConformancePackStatus[];
export declare const OrganizationConformancePackStatuses: any;
export interface DescribeOrganizationConformancePackStatusesResponse {
    OrganizationConformancePackStatuses?: OrganizationConformancePackStatus[];
    NextToken?: string;
}
export declare const DescribeOrganizationConformancePackStatusesResponse: S.Schema<DescribeOrganizationConformancePackStatusesResponse>;
export type DescribePendingAggregationRequestsLimit = number;
export interface DescribePendingAggregationRequestsRequest {
    Limit?: number;
    NextToken?: string;
}
export declare const DescribePendingAggregationRequestsRequest: S.Schema<DescribePendingAggregationRequestsRequest>;
export interface PendingAggregationRequest {
    RequesterAccountId?: string;
    RequesterAwsRegion?: string;
}
export declare const PendingAggregationRequest: S.Schema<PendingAggregationRequest>;
export type PendingAggregationRequestList = PendingAggregationRequest[];
export declare const PendingAggregationRequestList: any;
export interface DescribePendingAggregationRequestsResponse {
    PendingAggregationRequests?: PendingAggregationRequest[];
    NextToken?: string;
}
export declare const DescribePendingAggregationRequestsResponse: S.Schema<DescribePendingAggregationRequestsResponse>;
export interface DescribeRemediationConfigurationsRequest {
    ConfigRuleNames: string[];
}
export declare const DescribeRemediationConfigurationsRequest: S.Schema<DescribeRemediationConfigurationsRequest>;
export type RemediationTargetType = "SSM_DOCUMENT" | (string & {});
export declare const RemediationTargetType: any;
export type ResourceValueType = "RESOURCE_ID" | (string & {});
export declare const ResourceValueType: any;
export interface ResourceValue {
    Value: ResourceValueType;
}
export declare const ResourceValue: S.Schema<ResourceValue>;
export type StaticParameterValues = string[];
export declare const StaticParameterValues: any;
export interface StaticValue {
    Values: string[];
}
export declare const StaticValue: S.Schema<StaticValue>;
export interface RemediationParameterValue {
    ResourceValue?: ResourceValue;
    StaticValue?: StaticValue;
}
export declare const RemediationParameterValue: S.Schema<RemediationParameterValue>;
export type RemediationParameters = {
    [key: string]: RemediationParameterValue | undefined;
};
export declare const RemediationParameters: any;
export type Percentage = number;
export interface SsmControls {
    ConcurrentExecutionRatePercentage?: number;
    ErrorPercentage?: number;
}
export declare const SsmControls: S.Schema<SsmControls>;
export interface ExecutionControls {
    SsmControls?: SsmControls;
}
export declare const ExecutionControls: S.Schema<ExecutionControls>;
export type AutoRemediationAttempts = number;
export type AutoRemediationAttemptSeconds = number;
export interface RemediationConfiguration {
    ConfigRuleName: string;
    TargetType: RemediationTargetType;
    TargetId: string;
    TargetVersion?: string;
    Parameters?: {
        [key: string]: RemediationParameterValue | undefined;
    };
    ResourceType?: string;
    Automatic?: boolean;
    ExecutionControls?: ExecutionControls;
    MaximumAutomaticAttempts?: number;
    RetryAttemptSeconds?: number;
    Arn?: string;
    CreatedByService?: string;
}
export declare const RemediationConfiguration: S.Schema<RemediationConfiguration>;
export type RemediationConfigurations = RemediationConfiguration[];
export declare const RemediationConfigurations: any;
export interface DescribeRemediationConfigurationsResponse {
    RemediationConfigurations?: RemediationConfiguration[];
}
export declare const DescribeRemediationConfigurationsResponse: S.Schema<DescribeRemediationConfigurationsResponse>;
export interface DescribeRemediationExceptionsRequest {
    ConfigRuleName: string;
    ResourceKeys?: RemediationExceptionResourceKey[];
    Limit?: number;
    NextToken?: string;
}
export declare const DescribeRemediationExceptionsRequest: S.Schema<DescribeRemediationExceptionsRequest>;
export interface RemediationException {
    ConfigRuleName: string;
    ResourceType: string;
    ResourceId: string;
    Message?: string;
    ExpirationTime?: Date;
}
export declare const RemediationException: S.Schema<RemediationException>;
export type RemediationExceptions = RemediationException[];
export declare const RemediationExceptions: any;
export interface DescribeRemediationExceptionsResponse {
    RemediationExceptions?: RemediationException[];
    NextToken?: string;
}
export declare const DescribeRemediationExceptionsResponse: S.Schema<DescribeRemediationExceptionsResponse>;
export interface DescribeRemediationExecutionStatusRequest {
    ConfigRuleName: string;
    ResourceKeys?: ResourceKey[];
    Limit?: number;
    NextToken?: string;
}
export declare const DescribeRemediationExecutionStatusRequest: S.Schema<DescribeRemediationExecutionStatusRequest>;
export type RemediationExecutionState = "QUEUED" | "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | "UNKNOWN" | (string & {});
export declare const RemediationExecutionState: any;
export type RemediationExecutionStepState = "SUCCEEDED" | "PENDING" | "FAILED" | "IN_PROGRESS" | "EXITED" | "UNKNOWN" | (string & {});
export declare const RemediationExecutionStepState: any;
export interface RemediationExecutionStep {
    Name?: string;
    State?: RemediationExecutionStepState;
    ErrorMessage?: string;
    StartTime?: Date;
    StopTime?: Date;
}
export declare const RemediationExecutionStep: S.Schema<RemediationExecutionStep>;
export type RemediationExecutionSteps = RemediationExecutionStep[];
export declare const RemediationExecutionSteps: any;
export interface RemediationExecutionStatus {
    ResourceKey?: ResourceKey;
    State?: RemediationExecutionState;
    StepDetails?: RemediationExecutionStep[];
    InvocationTime?: Date;
    LastUpdatedTime?: Date;
}
export declare const RemediationExecutionStatus: S.Schema<RemediationExecutionStatus>;
export type RemediationExecutionStatuses = RemediationExecutionStatus[];
export declare const RemediationExecutionStatuses: any;
export interface DescribeRemediationExecutionStatusResponse {
    RemediationExecutionStatuses?: RemediationExecutionStatus[];
    NextToken?: string;
}
export declare const DescribeRemediationExecutionStatusResponse: S.Schema<DescribeRemediationExecutionStatusResponse>;
export type RetentionConfigurationNameList = string[];
export declare const RetentionConfigurationNameList: any;
export interface DescribeRetentionConfigurationsRequest {
    RetentionConfigurationNames?: string[];
    NextToken?: string;
}
export declare const DescribeRetentionConfigurationsRequest: S.Schema<DescribeRetentionConfigurationsRequest>;
export type RetentionPeriodInDays = number;
export interface RetentionConfiguration {
    Name: string;
    RetentionPeriodInDays: number;
}
export declare const RetentionConfiguration: S.Schema<RetentionConfiguration>;
export type RetentionConfigurationList = RetentionConfiguration[];
export declare const RetentionConfigurationList: any;
export interface DescribeRetentionConfigurationsResponse {
    RetentionConfigurations?: RetentionConfiguration[];
    NextToken?: string;
}
export declare const DescribeRetentionConfigurationsResponse: S.Schema<DescribeRetentionConfigurationsResponse>;
export interface DisassociateResourceTypesRequest {
    ConfigurationRecorderArn: string;
    ResourceTypes: ResourceType[];
}
export declare const DisassociateResourceTypesRequest: S.Schema<DisassociateResourceTypesRequest>;
export interface DisassociateResourceTypesResponse {
    ConfigurationRecorder: ConfigurationRecorder;
}
export declare const DisassociateResourceTypesResponse: S.Schema<DisassociateResourceTypesResponse>;
export interface GetAggregateComplianceDetailsByConfigRuleRequest {
    ConfigurationAggregatorName: string;
    ConfigRuleName: string;
    AccountId: string;
    AwsRegion: string;
    ComplianceType?: ComplianceType;
    Limit?: number;
    NextToken?: string;
}
export declare const GetAggregateComplianceDetailsByConfigRuleRequest: S.Schema<GetAggregateComplianceDetailsByConfigRuleRequest>;
export interface EvaluationResultQualifier {
    ConfigRuleName?: string;
    ResourceType?: string;
    ResourceId?: string;
    EvaluationMode?: EvaluationMode;
}
export declare const EvaluationResultQualifier: S.Schema<EvaluationResultQualifier>;
export type ResourceEvaluationId = string;
export interface EvaluationResultIdentifier {
    EvaluationResultQualifier?: EvaluationResultQualifier;
    OrderingTimestamp?: Date;
    ResourceEvaluationId?: string;
}
export declare const EvaluationResultIdentifier: S.Schema<EvaluationResultIdentifier>;
export interface AggregateEvaluationResult {
    EvaluationResultIdentifier?: EvaluationResultIdentifier;
    ComplianceType?: ComplianceType;
    ResultRecordedTime?: Date;
    ConfigRuleInvokedTime?: Date;
    Annotation?: string;
    AccountId?: string;
    AwsRegion?: string;
}
export declare const AggregateEvaluationResult: S.Schema<AggregateEvaluationResult>;
export type AggregateEvaluationResultList = AggregateEvaluationResult[];
export declare const AggregateEvaluationResultList: any;
export interface GetAggregateComplianceDetailsByConfigRuleResponse {
    AggregateEvaluationResults?: AggregateEvaluationResult[];
    NextToken?: string;
}
export declare const GetAggregateComplianceDetailsByConfigRuleResponse: S.Schema<GetAggregateComplianceDetailsByConfigRuleResponse>;
export interface ConfigRuleComplianceSummaryFilters {
    AccountId?: string;
    AwsRegion?: string;
}
export declare const ConfigRuleComplianceSummaryFilters: S.Schema<ConfigRuleComplianceSummaryFilters>;
export type ConfigRuleComplianceSummaryGroupKey = "ACCOUNT_ID" | "AWS_REGION" | (string & {});
export declare const ConfigRuleComplianceSummaryGroupKey: any;
export interface GetAggregateConfigRuleComplianceSummaryRequest {
    ConfigurationAggregatorName: string;
    Filters?: ConfigRuleComplianceSummaryFilters;
    GroupByKey?: ConfigRuleComplianceSummaryGroupKey;
    Limit?: number;
    NextToken?: string;
}
export declare const GetAggregateConfigRuleComplianceSummaryRequest: S.Schema<GetAggregateConfigRuleComplianceSummaryRequest>;
export interface ComplianceSummary {
    CompliantResourceCount?: ComplianceContributorCount;
    NonCompliantResourceCount?: ComplianceContributorCount;
    ComplianceSummaryTimestamp?: Date;
}
export declare const ComplianceSummary: S.Schema<ComplianceSummary>;
export interface AggregateComplianceCount {
    GroupName?: string;
    ComplianceSummary?: ComplianceSummary;
}
export declare const AggregateComplianceCount: S.Schema<AggregateComplianceCount>;
export type AggregateComplianceCountList = AggregateComplianceCount[];
export declare const AggregateComplianceCountList: any;
export interface GetAggregateConfigRuleComplianceSummaryResponse {
    GroupByKey?: string;
    AggregateComplianceCounts?: AggregateComplianceCount[];
    NextToken?: string;
}
export declare const GetAggregateConfigRuleComplianceSummaryResponse: S.Schema<GetAggregateConfigRuleComplianceSummaryResponse>;
export interface AggregateConformancePackComplianceSummaryFilters {
    AccountId?: string;
    AwsRegion?: string;
}
export declare const AggregateConformancePackComplianceSummaryFilters: S.Schema<AggregateConformancePackComplianceSummaryFilters>;
export type AggregateConformancePackComplianceSummaryGroupKey = "ACCOUNT_ID" | "AWS_REGION" | (string & {});
export declare const AggregateConformancePackComplianceSummaryGroupKey: any;
export interface GetAggregateConformancePackComplianceSummaryRequest {
    ConfigurationAggregatorName: string;
    Filters?: AggregateConformancePackComplianceSummaryFilters;
    GroupByKey?: AggregateConformancePackComplianceSummaryGroupKey;
    Limit?: number;
    NextToken?: string;
}
export declare const GetAggregateConformancePackComplianceSummaryRequest: S.Schema<GetAggregateConformancePackComplianceSummaryRequest>;
export interface AggregateConformancePackComplianceCount {
    CompliantConformancePackCount?: number;
    NonCompliantConformancePackCount?: number;
}
export declare const AggregateConformancePackComplianceCount: S.Schema<AggregateConformancePackComplianceCount>;
export interface AggregateConformancePackComplianceSummary {
    ComplianceSummary?: AggregateConformancePackComplianceCount;
    GroupName?: string;
}
export declare const AggregateConformancePackComplianceSummary: S.Schema<AggregateConformancePackComplianceSummary>;
export type AggregateConformancePackComplianceSummaryList = AggregateConformancePackComplianceSummary[];
export declare const AggregateConformancePackComplianceSummaryList: any;
export interface GetAggregateConformancePackComplianceSummaryResponse {
    AggregateConformancePackComplianceSummaries?: AggregateConformancePackComplianceSummary[];
    GroupByKey?: string;
    NextToken?: string;
}
export declare const GetAggregateConformancePackComplianceSummaryResponse: S.Schema<GetAggregateConformancePackComplianceSummaryResponse>;
export interface ResourceCountFilters {
    ResourceType?: ResourceType;
    AccountId?: string;
    Region?: string;
}
export declare const ResourceCountFilters: S.Schema<ResourceCountFilters>;
export type ResourceCountGroupKey = "RESOURCE_TYPE" | "ACCOUNT_ID" | "AWS_REGION" | (string & {});
export declare const ResourceCountGroupKey: any;
export interface GetAggregateDiscoveredResourceCountsRequest {
    ConfigurationAggregatorName: string;
    Filters?: ResourceCountFilters;
    GroupByKey?: ResourceCountGroupKey;
    Limit?: number;
    NextToken?: string;
}
export declare const GetAggregateDiscoveredResourceCountsRequest: S.Schema<GetAggregateDiscoveredResourceCountsRequest>;
export interface GroupedResourceCount {
    GroupName: string;
    ResourceCount: number;
}
export declare const GroupedResourceCount: S.Schema<GroupedResourceCount>;
export type GroupedResourceCountList = GroupedResourceCount[];
export declare const GroupedResourceCountList: any;
export interface GetAggregateDiscoveredResourceCountsResponse {
    TotalDiscoveredResources: number;
    GroupByKey?: string;
    GroupedResourceCounts?: GroupedResourceCount[];
    NextToken?: string;
}
export declare const GetAggregateDiscoveredResourceCountsResponse: S.Schema<GetAggregateDiscoveredResourceCountsResponse>;
export interface GetAggregateResourceConfigRequest {
    ConfigurationAggregatorName: string;
    ResourceIdentifier: AggregateResourceIdentifier;
}
export declare const GetAggregateResourceConfigRequest: S.Schema<GetAggregateResourceConfigRequest>;
export type ConfigurationItemMD5Hash = string;
export type Name = string;
export type Value = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export type RelatedEvent = string;
export type RelatedEventList = string[];
export declare const RelatedEventList: any;
export type RelationshipName = string;
export interface Relationship {
    resourceType?: ResourceType;
    resourceId?: string;
    resourceName?: string;
    relationshipName?: string;
}
export declare const Relationship: S.Schema<Relationship>;
export type RelationshipList = Relationship[];
export declare const RelationshipList: any;
export interface ConfigurationItem {
    version?: string;
    accountId?: string;
    configurationItemCaptureTime?: Date;
    configurationItemStatus?: ConfigurationItemStatus;
    configurationStateId?: string;
    configurationItemMD5Hash?: string;
    arn?: string;
    resourceType?: ResourceType;
    resourceId?: string;
    resourceName?: string;
    awsRegion?: string;
    availabilityZone?: string;
    resourceCreationTime?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    relatedEvents?: string[];
    relationships?: Relationship[];
    configuration?: string;
    supplementaryConfiguration?: {
        [key: string]: string | undefined;
    };
    recordingFrequency?: RecordingFrequency;
    configurationItemDeliveryTime?: Date;
}
export declare const ConfigurationItem: S.Schema<ConfigurationItem>;
export interface GetAggregateResourceConfigResponse {
    ConfigurationItem?: ConfigurationItem;
}
export declare const GetAggregateResourceConfigResponse: S.Schema<GetAggregateResourceConfigResponse>;
export interface GetComplianceDetailsByConfigRuleRequest {
    ConfigRuleName: string;
    ComplianceTypes?: ComplianceType[];
    Limit?: number;
    NextToken?: string;
}
export declare const GetComplianceDetailsByConfigRuleRequest: S.Schema<GetComplianceDetailsByConfigRuleRequest>;
export interface EvaluationResult {
    EvaluationResultIdentifier?: EvaluationResultIdentifier;
    ComplianceType?: ComplianceType;
    ResultRecordedTime?: Date;
    ConfigRuleInvokedTime?: Date;
    Annotation?: string;
    ResultToken?: string;
}
export declare const EvaluationResult: S.Schema<EvaluationResult>;
export type EvaluationResults = EvaluationResult[];
export declare const EvaluationResults: any;
export interface GetComplianceDetailsByConfigRuleResponse {
    EvaluationResults?: EvaluationResult[];
    NextToken?: string;
}
export declare const GetComplianceDetailsByConfigRuleResponse: S.Schema<GetComplianceDetailsByConfigRuleResponse>;
export interface GetComplianceDetailsByResourceRequest {
    ResourceType?: string;
    ResourceId?: string;
    ComplianceTypes?: ComplianceType[];
    NextToken?: string;
    ResourceEvaluationId?: string;
}
export declare const GetComplianceDetailsByResourceRequest: S.Schema<GetComplianceDetailsByResourceRequest>;
export interface GetComplianceDetailsByResourceResponse {
    EvaluationResults?: EvaluationResult[];
    NextToken?: string;
}
export declare const GetComplianceDetailsByResourceResponse: S.Schema<GetComplianceDetailsByResourceResponse>;
export interface GetComplianceSummaryByConfigRuleRequest {
}
export declare const GetComplianceSummaryByConfigRuleRequest: S.Schema<GetComplianceSummaryByConfigRuleRequest>;
export interface GetComplianceSummaryByConfigRuleResponse {
    ComplianceSummary?: ComplianceSummary;
}
export declare const GetComplianceSummaryByConfigRuleResponse: S.Schema<GetComplianceSummaryByConfigRuleResponse>;
export type ResourceTypes = string[];
export declare const ResourceTypes: any;
export interface GetComplianceSummaryByResourceTypeRequest {
    ResourceTypes?: string[];
}
export declare const GetComplianceSummaryByResourceTypeRequest: S.Schema<GetComplianceSummaryByResourceTypeRequest>;
export interface ComplianceSummaryByResourceType {
    ResourceType?: string;
    ComplianceSummary?: ComplianceSummary;
}
export declare const ComplianceSummaryByResourceType: S.Schema<ComplianceSummaryByResourceType>;
export type ComplianceSummariesByResourceType = ComplianceSummaryByResourceType[];
export declare const ComplianceSummariesByResourceType: any;
export interface GetComplianceSummaryByResourceTypeResponse {
    ComplianceSummariesByResourceType?: ComplianceSummaryByResourceType[];
}
export declare const GetComplianceSummaryByResourceTypeResponse: S.Schema<GetComplianceSummaryByResourceTypeResponse>;
export type ConformancePackComplianceResourceIds = string[];
export declare const ConformancePackComplianceResourceIds: any;
export interface ConformancePackEvaluationFilters {
    ConfigRuleNames?: string[];
    ComplianceType?: ConformancePackComplianceType;
    ResourceType?: string;
    ResourceIds?: string[];
}
export declare const ConformancePackEvaluationFilters: S.Schema<ConformancePackEvaluationFilters>;
export type GetConformancePackComplianceDetailsLimit = number;
export interface GetConformancePackComplianceDetailsRequest {
    ConformancePackName: string;
    Filters?: ConformancePackEvaluationFilters;
    Limit?: number;
    NextToken?: string;
}
export declare const GetConformancePackComplianceDetailsRequest: S.Schema<GetConformancePackComplianceDetailsRequest>;
export type Annotation = string;
export interface ConformancePackEvaluationResult {
    ComplianceType: ConformancePackComplianceType;
    EvaluationResultIdentifier: EvaluationResultIdentifier;
    ConfigRuleInvokedTime: Date;
    ResultRecordedTime: Date;
    Annotation?: string;
}
export declare const ConformancePackEvaluationResult: S.Schema<ConformancePackEvaluationResult>;
export type ConformancePackRuleEvaluationResultsList = ConformancePackEvaluationResult[];
export declare const ConformancePackRuleEvaluationResultsList: any;
export interface GetConformancePackComplianceDetailsResponse {
    ConformancePackName: string;
    ConformancePackRuleEvaluationResults?: ConformancePackEvaluationResult[];
    NextToken?: string;
}
export declare const GetConformancePackComplianceDetailsResponse: S.Schema<GetConformancePackComplianceDetailsResponse>;
export type ConformancePackNamesToSummarizeList = string[];
export declare const ConformancePackNamesToSummarizeList: any;
export interface GetConformancePackComplianceSummaryRequest {
    ConformancePackNames: string[];
    Limit?: number;
    NextToken?: string;
}
export declare const GetConformancePackComplianceSummaryRequest: S.Schema<GetConformancePackComplianceSummaryRequest>;
export interface ConformancePackComplianceSummary {
    ConformancePackName: string;
    ConformancePackComplianceStatus: ConformancePackComplianceType;
}
export declare const ConformancePackComplianceSummary: S.Schema<ConformancePackComplianceSummary>;
export type ConformancePackComplianceSummaryList = ConformancePackComplianceSummary[];
export declare const ConformancePackComplianceSummaryList: any;
export interface GetConformancePackComplianceSummaryResponse {
    ConformancePackComplianceSummaryList?: ConformancePackComplianceSummary[];
    NextToken?: string;
}
export declare const GetConformancePackComplianceSummaryResponse: S.Schema<GetConformancePackComplianceSummaryResponse>;
export interface GetConnectorRequest {
    Arn: string;
}
export declare const GetConnectorRequest: S.Schema<GetConnectorRequest>;
export type ConnectorName = string;
export type AzureTenantIdentifier = string;
export type AzureClientIdentifier = string;
export interface AzureConnectorConfiguration {
    tenantIdentifier: string;
    clientIdentifier: string;
}
export declare const AzureConnectorConfiguration: S.Schema<AzureConnectorConfiguration>;
export interface ConnectorConfiguration {
    azure?: AzureConnectorConfiguration;
}
export declare const ConnectorConfiguration: S.Schema<ConnectorConfiguration>;
export interface Connector {
    name: string;
    arn: string;
    connectorConfiguration: ConnectorConfiguration;
    createdTime: Date;
}
export declare const Connector: S.Schema<Connector>;
export interface GetConnectorResponse {
    Connector: Connector;
}
export declare const GetConnectorResponse: S.Schema<GetConnectorResponse>;
export interface GetCustomRulePolicyRequest {
    ConfigRuleName?: string;
}
export declare const GetCustomRulePolicyRequest: S.Schema<GetCustomRulePolicyRequest>;
export interface GetCustomRulePolicyResponse {
    PolicyText?: string;
}
export declare const GetCustomRulePolicyResponse: S.Schema<GetCustomRulePolicyResponse>;
export interface GetDiscoveredResourceCountsRequest {
    resourceTypes?: string[];
    limit?: number;
    nextToken?: string;
}
export declare const GetDiscoveredResourceCountsRequest: S.Schema<GetDiscoveredResourceCountsRequest>;
export interface ResourceCount {
    resourceType?: ResourceType;
    count?: number;
}
export declare const ResourceCount: S.Schema<ResourceCount>;
export type ResourceCounts = ResourceCount[];
export declare const ResourceCounts: any;
export interface GetDiscoveredResourceCountsResponse {
    totalDiscoveredResources?: number;
    resourceCounts?: ResourceCount[];
    nextToken?: string;
}
export declare const GetDiscoveredResourceCountsResponse: S.Schema<GetDiscoveredResourceCountsResponse>;
export type MemberAccountRuleStatus = "CREATE_SUCCESSFUL" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "DELETE_SUCCESSFUL" | "DELETE_FAILED" | "DELETE_IN_PROGRESS" | "UPDATE_SUCCESSFUL" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | (string & {});
export declare const MemberAccountRuleStatus: any;
export interface StatusDetailFilters {
    AccountId?: string;
    MemberAccountRuleStatus?: MemberAccountRuleStatus;
}
export declare const StatusDetailFilters: S.Schema<StatusDetailFilters>;
export interface GetOrganizationConfigRuleDetailedStatusRequest {
    OrganizationConfigRuleName: string;
    Filters?: StatusDetailFilters;
    Limit?: number;
    NextToken?: string;
}
export declare const GetOrganizationConfigRuleDetailedStatusRequest: S.Schema<GetOrganizationConfigRuleDetailedStatusRequest>;
export interface MemberAccountStatus {
    AccountId: string;
    ConfigRuleName: string;
    MemberAccountRuleStatus: MemberAccountRuleStatus;
    ErrorCode?: string;
    ErrorMessage?: string;
    LastUpdateTime?: Date;
}
export declare const MemberAccountStatus: S.Schema<MemberAccountStatus>;
export type OrganizationConfigRuleDetailedStatus = MemberAccountStatus[];
export declare const OrganizationConfigRuleDetailedStatus: any;
export interface GetOrganizationConfigRuleDetailedStatusResponse {
    OrganizationConfigRuleDetailedStatus?: MemberAccountStatus[];
    NextToken?: string;
}
export declare const GetOrganizationConfigRuleDetailedStatusResponse: S.Schema<GetOrganizationConfigRuleDetailedStatusResponse>;
export type OrganizationResourceDetailedStatus = "CREATE_SUCCESSFUL" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "DELETE_SUCCESSFUL" | "DELETE_FAILED" | "DELETE_IN_PROGRESS" | "UPDATE_SUCCESSFUL" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | (string & {});
export declare const OrganizationResourceDetailedStatus: any;
export interface OrganizationResourceDetailedStatusFilters {
    AccountId?: string;
    Status?: OrganizationResourceDetailedStatus;
}
export declare const OrganizationResourceDetailedStatusFilters: S.Schema<OrganizationResourceDetailedStatusFilters>;
export interface GetOrganizationConformancePackDetailedStatusRequest {
    OrganizationConformancePackName: string;
    Filters?: OrganizationResourceDetailedStatusFilters;
    Limit?: number;
    NextToken?: string;
}
export declare const GetOrganizationConformancePackDetailedStatusRequest: S.Schema<GetOrganizationConformancePackDetailedStatusRequest>;
export interface OrganizationConformancePackDetailedStatus {
    AccountId: string;
    ConformancePackName: string;
    Status: OrganizationResourceDetailedStatus;
    ErrorCode?: string;
    ErrorMessage?: string;
    LastUpdateTime?: Date;
}
export declare const OrganizationConformancePackDetailedStatus: S.Schema<OrganizationConformancePackDetailedStatus>;
export type OrganizationConformancePackDetailedStatuses = OrganizationConformancePackDetailedStatus[];
export declare const OrganizationConformancePackDetailedStatuses: any;
export interface GetOrganizationConformancePackDetailedStatusResponse {
    OrganizationConformancePackDetailedStatuses?: OrganizationConformancePackDetailedStatus[];
    NextToken?: string;
}
export declare const GetOrganizationConformancePackDetailedStatusResponse: S.Schema<GetOrganizationConformancePackDetailedStatusResponse>;
export interface GetOrganizationCustomRulePolicyRequest {
    OrganizationConfigRuleName: string;
}
export declare const GetOrganizationCustomRulePolicyRequest: S.Schema<GetOrganizationCustomRulePolicyRequest>;
export interface GetOrganizationCustomRulePolicyResponse {
    PolicyText?: string;
}
export declare const GetOrganizationCustomRulePolicyResponse: S.Schema<GetOrganizationCustomRulePolicyResponse>;
export type LaterTime = Date;
export type EarlierTime = Date;
export type ChronologicalOrder = "Reverse" | "Forward" | (string & {});
export declare const ChronologicalOrder: any;
export interface GetResourceConfigHistoryRequest {
    resourceType: ResourceType;
    resourceId: string;
    laterTime?: Date;
    earlierTime?: Date;
    chronologicalOrder?: ChronologicalOrder;
    limit?: number;
    nextToken?: string;
}
export declare const GetResourceConfigHistoryRequest: S.Schema<GetResourceConfigHistoryRequest>;
export type ConfigurationItemList = ConfigurationItem[];
export declare const ConfigurationItemList: any;
export interface GetResourceConfigHistoryResponse {
    configurationItems?: ConfigurationItem[];
    nextToken?: string;
}
export declare const GetResourceConfigHistoryResponse: S.Schema<GetResourceConfigHistoryResponse>;
export interface GetResourceEvaluationSummaryRequest {
    ResourceEvaluationId: string;
}
export declare const GetResourceEvaluationSummaryRequest: S.Schema<GetResourceEvaluationSummaryRequest>;
export type ResourceEvaluationStatus = "IN_PROGRESS" | "FAILED" | "SUCCEEDED" | (string & {});
export declare const ResourceEvaluationStatus: any;
export interface EvaluationStatus {
    Status: ResourceEvaluationStatus;
    FailureReason?: string;
}
export declare const EvaluationStatus: S.Schema<EvaluationStatus>;
export type EvaluationContextIdentifier = string;
export interface EvaluationContext {
    EvaluationContextIdentifier?: string;
}
export declare const EvaluationContext: S.Schema<EvaluationContext>;
export type ResourceConfiguration = string;
export type ResourceConfigurationSchemaType = "CFN_RESOURCE_SCHEMA" | (string & {});
export declare const ResourceConfigurationSchemaType: any;
export interface ResourceDetails {
    ResourceId: string;
    ResourceType: string;
    ResourceConfiguration: string;
    ResourceConfigurationSchemaType?: ResourceConfigurationSchemaType;
}
export declare const ResourceDetails: S.Schema<ResourceDetails>;
export interface GetResourceEvaluationSummaryResponse {
    ResourceEvaluationId?: string;
    EvaluationMode?: EvaluationMode;
    EvaluationStatus?: EvaluationStatus;
    EvaluationStartTimestamp?: Date;
    Compliance?: ComplianceType;
    EvaluationContext?: EvaluationContext;
    ResourceDetails?: ResourceDetails;
}
export declare const GetResourceEvaluationSummaryResponse: S.Schema<GetResourceEvaluationSummaryResponse>;
export interface GetStoredQueryRequest {
    QueryName: string;
}
export declare const GetStoredQueryRequest: S.Schema<GetStoredQueryRequest>;
export type QueryId = string;
export type QueryArn = string;
export type QueryDescription = string;
export type QueryExpression = string;
export interface StoredQuery {
    QueryId?: string;
    QueryArn?: string;
    QueryName: string;
    Description?: string;
    Expression?: string;
}
export declare const StoredQuery: S.Schema<StoredQuery>;
export interface GetStoredQueryResponse {
    StoredQuery?: StoredQuery;
}
export declare const GetStoredQueryResponse: S.Schema<GetStoredQueryResponse>;
export interface ResourceFilters {
    AccountId?: string;
    ResourceId?: string;
    ResourceName?: string;
    Region?: string;
}
export declare const ResourceFilters: S.Schema<ResourceFilters>;
export interface ListAggregateDiscoveredResourcesRequest {
    ConfigurationAggregatorName: string;
    ResourceType: ResourceType;
    Filters?: ResourceFilters;
    Limit?: number;
    NextToken?: string;
}
export declare const ListAggregateDiscoveredResourcesRequest: S.Schema<ListAggregateDiscoveredResourcesRequest>;
export type DiscoveredResourceIdentifierList = AggregateResourceIdentifier[];
export declare const DiscoveredResourceIdentifierList: any;
export interface ListAggregateDiscoveredResourcesResponse {
    ResourceIdentifiers?: AggregateResourceIdentifier[];
    NextToken?: string;
}
export declare const ListAggregateDiscoveredResourcesResponse: S.Schema<ListAggregateDiscoveredResourcesResponse>;
export type ConfigurationRecorderFilterName = "recordingScope" | (string & {});
export declare const ConfigurationRecorderFilterName: any;
export type ConfigurationRecorderFilterValue = string;
export type ConfigurationRecorderFilterValues = string[];
export declare const ConfigurationRecorderFilterValues: any;
export interface ConfigurationRecorderFilter {
    filterName?: ConfigurationRecorderFilterName;
    filterValue?: string[];
}
export declare const ConfigurationRecorderFilter: S.Schema<ConfigurationRecorderFilter>;
export type ConfigurationRecorderFilterList = ConfigurationRecorderFilter[];
export declare const ConfigurationRecorderFilterList: any;
export type MaxResults = number;
export interface ListConfigurationRecordersRequest {
    Filters?: ConfigurationRecorderFilter[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListConfigurationRecordersRequest: S.Schema<ListConfigurationRecordersRequest>;
export type Provider = "AZURE" | (string & {});
export declare const Provider: any;
export interface ConfigurationRecorderSummary {
    arn: string;
    name: string;
    servicePrincipal?: string;
    recordingScope: RecordingScope;
    provider?: Provider;
}
export declare const ConfigurationRecorderSummary: S.Schema<ConfigurationRecorderSummary>;
export type ConfigurationRecorderSummaries = ConfigurationRecorderSummary[];
export declare const ConfigurationRecorderSummaries: any;
export interface ListConfigurationRecordersResponse {
    ConfigurationRecorderSummaries: ConfigurationRecorderSummary[];
    NextToken?: string;
}
export declare const ListConfigurationRecordersResponse: S.Schema<ListConfigurationRecordersResponse>;
export type ConformancePackNameFilter = string[];
export declare const ConformancePackNameFilter: any;
export interface ConformancePackComplianceScoresFilters {
    ConformancePackNames: string[];
}
export declare const ConformancePackComplianceScoresFilters: S.Schema<ConformancePackComplianceScoresFilters>;
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export declare const SortOrder: any;
export type SortBy = "SCORE" | (string & {});
export declare const SortBy: any;
export interface ListConformancePackComplianceScoresRequest {
    Filters?: ConformancePackComplianceScoresFilters;
    SortOrder?: SortOrder;
    SortBy?: SortBy;
    Limit?: number;
    NextToken?: string;
}
export declare const ListConformancePackComplianceScoresRequest: S.Schema<ListConformancePackComplianceScoresRequest>;
export type ComplianceScore = string;
export type LastUpdatedTime = Date;
export interface ConformancePackComplianceScore {
    Score?: string;
    ConformancePackName?: string;
    LastUpdatedTime?: Date;
}
export declare const ConformancePackComplianceScore: S.Schema<ConformancePackComplianceScore>;
export type ConformancePackComplianceScores = ConformancePackComplianceScore[];
export declare const ConformancePackComplianceScores: any;
export interface ListConformancePackComplianceScoresResponse {
    NextToken?: string;
    ConformancePackComplianceScores: ConformancePackComplianceScore[];
}
export declare const ListConformancePackComplianceScoresResponse: S.Schema<ListConformancePackComplianceScoresResponse>;
export type ListConnectorsMaxResults = number;
export type ConnectorFilterName = "provider" | (string & {});
export declare const ConnectorFilterName: any;
export type FilterValueList = string[];
export declare const FilterValueList: any;
export interface ConnectorFilter {
    filterName?: ConnectorFilterName;
    filterValues?: string[];
}
export declare const ConnectorFilter: S.Schema<ConnectorFilter>;
export type ConnectorFilterList = ConnectorFilter[];
export declare const ConnectorFilterList: any;
export interface ListConnectorsRequest {
    MaxResults?: number;
    NextToken?: string;
    Filters?: ConnectorFilter[];
}
export declare const ListConnectorsRequest: S.Schema<ListConnectorsRequest>;
export interface ConnectorSummary {
    arn: string;
    name: string;
    provider: Provider;
    tenantIdentifier: string;
    createdTime: Date;
}
export declare const ConnectorSummary: S.Schema<ConnectorSummary>;
export type ConnectorSummaries = ConnectorSummary[];
export declare const ConnectorSummaries: any;
export interface ListConnectorsResponse {
    ConnectorSummaries: ConnectorSummary[];
    NextToken?: string;
}
export declare const ListConnectorsResponse: S.Schema<ListConnectorsResponse>;
export type ResourceIdList = string[];
export declare const ResourceIdList: any;
export interface ListDiscoveredResourcesRequest {
    resourceType: ResourceType;
    resourceIds?: string[];
    resourceName?: string;
    limit?: number;
    includeDeletedResources?: boolean;
    nextToken?: string;
}
export declare const ListDiscoveredResourcesRequest: S.Schema<ListDiscoveredResourcesRequest>;
export type ResourceDeletionTime = Date;
export interface ResourceIdentifier {
    resourceType?: ResourceType;
    resourceId?: string;
    resourceName?: string;
    resourceDeletionTime?: Date;
}
export declare const ResourceIdentifier: S.Schema<ResourceIdentifier>;
export type ResourceIdentifierList = ResourceIdentifier[];
export declare const ResourceIdentifierList: any;
export interface ListDiscoveredResourcesResponse {
    resourceIdentifiers?: ResourceIdentifier[];
    nextToken?: string;
}
export declare const ListDiscoveredResourcesResponse: S.Schema<ListDiscoveredResourcesResponse>;
export interface TimeWindow {
    StartTime?: Date;
    EndTime?: Date;
}
export declare const TimeWindow: S.Schema<TimeWindow>;
export interface ResourceEvaluationFilters {
    EvaluationMode?: EvaluationMode;
    TimeWindow?: TimeWindow;
    EvaluationContextIdentifier?: string;
}
export declare const ResourceEvaluationFilters: S.Schema<ResourceEvaluationFilters>;
export type ListResourceEvaluationsPageItemLimit = number;
export interface ListResourceEvaluationsRequest {
    Filters?: ResourceEvaluationFilters;
    Limit?: number;
    NextToken?: string;
}
export declare const ListResourceEvaluationsRequest: S.Schema<ListResourceEvaluationsRequest>;
export interface ResourceEvaluation {
    ResourceEvaluationId?: string;
    EvaluationMode?: EvaluationMode;
    EvaluationStartTimestamp?: Date;
}
export declare const ResourceEvaluation: S.Schema<ResourceEvaluation>;
export type ResourceEvaluations = ResourceEvaluation[];
export declare const ResourceEvaluations: any;
export interface ListResourceEvaluationsResponse {
    ResourceEvaluations?: ResourceEvaluation[];
    NextToken?: string;
}
export declare const ListResourceEvaluationsResponse: S.Schema<ListResourceEvaluationsResponse>;
export interface ListStoredQueriesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListStoredQueriesRequest: S.Schema<ListStoredQueriesRequest>;
export interface StoredQueryMetadata {
    QueryId: string;
    QueryArn: string;
    QueryName: string;
    Description?: string;
}
export declare const StoredQueryMetadata: S.Schema<StoredQueryMetadata>;
export type StoredQueryMetadataList = StoredQueryMetadata[];
export declare const StoredQueryMetadataList: any;
export interface ListStoredQueriesResponse {
    StoredQueryMetadata?: StoredQueryMetadata[];
    NextToken?: string;
}
export declare const ListStoredQueriesResponse: S.Schema<ListStoredQueriesResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
    Limit?: number;
    NextToken?: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
    NextToken?: string;
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type TagsList = Tag[];
export declare const TagsList: any;
export interface PutAggregationAuthorizationRequest {
    AuthorizedAccountId: string;
    AuthorizedAwsRegion: string;
    Tags?: Tag[];
}
export declare const PutAggregationAuthorizationRequest: S.Schema<PutAggregationAuthorizationRequest>;
export interface PutAggregationAuthorizationResponse {
    AggregationAuthorization?: AggregationAuthorization;
}
export declare const PutAggregationAuthorizationResponse: S.Schema<PutAggregationAuthorizationResponse>;
export interface PutConfigRuleRequest {
    ConfigRule: ConfigRule;
    Tags?: Tag[];
}
export declare const PutConfigRuleRequest: S.Schema<PutConfigRuleRequest>;
export interface PutConfigRuleResponse {
}
export declare const PutConfigRuleResponse: S.Schema<PutConfigRuleResponse>;
export interface PutConfigurationAggregatorRequest {
    ConfigurationAggregatorName: string;
    AccountAggregationSources?: AccountAggregationSource[];
    OrganizationAggregationSource?: OrganizationAggregationSource;
    Tags?: Tag[];
    AggregatorFilters?: AggregatorFilters;
}
export declare const PutConfigurationAggregatorRequest: S.Schema<PutConfigurationAggregatorRequest>;
export interface PutConfigurationAggregatorResponse {
    ConfigurationAggregator?: ConfigurationAggregator;
}
export declare const PutConfigurationAggregatorResponse: S.Schema<PutConfigurationAggregatorResponse>;
export interface PutConfigurationRecorderRequest {
    ConfigurationRecorder: ConfigurationRecorder;
    Tags?: Tag[];
}
export declare const PutConfigurationRecorderRequest: S.Schema<PutConfigurationRecorderRequest>;
export interface PutConfigurationRecorderResponse {
}
export declare const PutConfigurationRecorderResponse: S.Schema<PutConfigurationRecorderResponse>;
export type TemplateS3Uri = string;
export type TemplateBody = string;
export interface PutConformancePackRequest {
    ConformancePackName: string;
    TemplateS3Uri?: string;
    TemplateBody?: string;
    DeliveryS3Bucket?: string;
    DeliveryS3KeyPrefix?: string;
    ConformancePackInputParameters?: ConformancePackInputParameter[];
    TemplateSSMDocumentDetails?: TemplateSSMDocumentDetails;
    Tags?: Tag[];
}
export declare const PutConformancePackRequest: S.Schema<PutConformancePackRequest>;
export interface PutConformancePackResponse {
    ConformancePackArn?: string;
}
export declare const PutConformancePackResponse: S.Schema<PutConformancePackResponse>;
export interface PutConnectorRequest {
    ConnectorConfiguration: ConnectorConfiguration;
    Tags?: Tag[];
}
export declare const PutConnectorRequest: S.Schema<PutConnectorRequest>;
export interface PutConnectorResponse {
    Arn: string;
}
export declare const PutConnectorResponse: S.Schema<PutConnectorResponse>;
export interface PutDeliveryChannelRequest {
    DeliveryChannel: DeliveryChannel;
}
export declare const PutDeliveryChannelRequest: S.Schema<PutDeliveryChannelRequest>;
export interface PutDeliveryChannelResponse {
}
export declare const PutDeliveryChannelResponse: S.Schema<PutDeliveryChannelResponse>;
export type OrderingTimestamp = Date;
export interface Evaluation {
    ComplianceResourceType: string;
    ComplianceResourceId: string;
    ComplianceType: ComplianceType;
    Annotation?: string;
    OrderingTimestamp: Date;
}
export declare const Evaluation: S.Schema<Evaluation>;
export type Evaluations = Evaluation[];
export declare const Evaluations: any;
export interface PutEvaluationsRequest {
    Evaluations?: Evaluation[];
    ResultToken: string;
    TestMode?: boolean;
}
export declare const PutEvaluationsRequest: S.Schema<PutEvaluationsRequest>;
export interface PutEvaluationsResponse {
    FailedEvaluations?: Evaluation[];
}
export declare const PutEvaluationsResponse: S.Schema<PutEvaluationsResponse>;
export interface ExternalEvaluation {
    ComplianceResourceType: string;
    ComplianceResourceId: string;
    ComplianceType: ComplianceType;
    Annotation?: string;
    OrderingTimestamp: Date;
}
export declare const ExternalEvaluation: S.Schema<ExternalEvaluation>;
export interface PutExternalEvaluationRequest {
    ConfigRuleName: string;
    ExternalEvaluation: ExternalEvaluation;
}
export declare const PutExternalEvaluationRequest: S.Schema<PutExternalEvaluationRequest>;
export interface PutExternalEvaluationResponse {
}
export declare const PutExternalEvaluationResponse: S.Schema<PutExternalEvaluationResponse>;
export interface OrganizationCustomPolicyRuleMetadata {
    Description?: string;
    OrganizationConfigRuleTriggerTypes?: OrganizationConfigRuleTriggerTypeNoSN[];
    InputParameters?: string;
    MaximumExecutionFrequency?: MaximumExecutionFrequency;
    ResourceTypesScope?: string[];
    ResourceIdScope?: string;
    TagKeyScope?: string;
    TagValueScope?: string;
    PolicyRuntime: string;
    PolicyText: string;
    DebugLogDeliveryAccounts?: string[];
}
export declare const OrganizationCustomPolicyRuleMetadata: S.Schema<OrganizationCustomPolicyRuleMetadata>;
export interface PutOrganizationConfigRuleRequest {
    OrganizationConfigRuleName: string;
    OrganizationManagedRuleMetadata?: OrganizationManagedRuleMetadata;
    OrganizationCustomRuleMetadata?: OrganizationCustomRuleMetadata;
    ExcludedAccounts?: string[];
    OrganizationCustomPolicyRuleMetadata?: OrganizationCustomPolicyRuleMetadata;
    Tags?: Tag[];
}
export declare const PutOrganizationConfigRuleRequest: S.Schema<PutOrganizationConfigRuleRequest>;
export interface PutOrganizationConfigRuleResponse {
    OrganizationConfigRuleArn?: string;
}
export declare const PutOrganizationConfigRuleResponse: S.Schema<PutOrganizationConfigRuleResponse>;
export interface PutOrganizationConformancePackRequest {
    OrganizationConformancePackName: string;
    TemplateS3Uri?: string;
    TemplateBody?: string;
    DeliveryS3Bucket?: string;
    DeliveryS3KeyPrefix?: string;
    ConformancePackInputParameters?: ConformancePackInputParameter[];
    ExcludedAccounts?: string[];
    Tags?: Tag[];
}
export declare const PutOrganizationConformancePackRequest: S.Schema<PutOrganizationConformancePackRequest>;
export interface PutOrganizationConformancePackResponse {
    OrganizationConformancePackArn?: string;
}
export declare const PutOrganizationConformancePackResponse: S.Schema<PutOrganizationConformancePackResponse>;
export interface PutRemediationConfigurationsRequest {
    RemediationConfigurations: RemediationConfiguration[];
}
export declare const PutRemediationConfigurationsRequest: S.Schema<PutRemediationConfigurationsRequest>;
export interface FailedRemediationBatch {
    FailureMessage?: string;
    FailedItems?: RemediationConfiguration[];
}
export declare const FailedRemediationBatch: S.Schema<FailedRemediationBatch>;
export type FailedRemediationBatches = FailedRemediationBatch[];
export declare const FailedRemediationBatches: any;
export interface PutRemediationConfigurationsResponse {
    FailedBatches?: FailedRemediationBatch[];
}
export declare const PutRemediationConfigurationsResponse: S.Schema<PutRemediationConfigurationsResponse>;
export interface PutRemediationExceptionsRequest {
    ConfigRuleName: string;
    ResourceKeys: RemediationExceptionResourceKey[];
    Message?: string;
    ExpirationTime?: Date;
}
export declare const PutRemediationExceptionsRequest: S.Schema<PutRemediationExceptionsRequest>;
export interface FailedRemediationExceptionBatch {
    FailureMessage?: string;
    FailedItems?: RemediationException[];
}
export declare const FailedRemediationExceptionBatch: S.Schema<FailedRemediationExceptionBatch>;
export type FailedRemediationExceptionBatches = FailedRemediationExceptionBatch[];
export declare const FailedRemediationExceptionBatches: any;
export interface PutRemediationExceptionsResponse {
    FailedBatches?: FailedRemediationExceptionBatch[];
}
export declare const PutRemediationExceptionsResponse: S.Schema<PutRemediationExceptionsResponse>;
export type SchemaVersionId = string;
export interface PutResourceConfigRequest {
    ResourceType: string;
    SchemaVersionId: string;
    ResourceId: string;
    ResourceName?: string;
    Configuration: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const PutResourceConfigRequest: S.Schema<PutResourceConfigRequest>;
export interface PutResourceConfigResponse {
}
export declare const PutResourceConfigResponse: S.Schema<PutResourceConfigResponse>;
export interface PutRetentionConfigurationRequest {
    RetentionPeriodInDays: number;
}
export declare const PutRetentionConfigurationRequest: S.Schema<PutRetentionConfigurationRequest>;
export interface PutRetentionConfigurationResponse {
    RetentionConfiguration?: RetentionConfiguration;
}
export declare const PutRetentionConfigurationResponse: S.Schema<PutRetentionConfigurationResponse>;
export interface PutServiceLinkedConfigurationRecorderRequest {
    ServicePrincipal: string;
    Tags?: Tag[];
}
export declare const PutServiceLinkedConfigurationRecorderRequest: S.Schema<PutServiceLinkedConfigurationRecorderRequest>;
export interface PutServiceLinkedConfigurationRecorderResponse {
    Arn?: string;
    Name?: string;
}
export declare const PutServiceLinkedConfigurationRecorderResponse: S.Schema<PutServiceLinkedConfigurationRecorderResponse>;
export interface PutStoredQueryRequest {
    StoredQuery: StoredQuery;
    Tags?: Tag[];
}
export declare const PutStoredQueryRequest: S.Schema<PutStoredQueryRequest>;
export interface PutStoredQueryResponse {
    QueryArn?: string;
}
export declare const PutStoredQueryResponse: S.Schema<PutStoredQueryResponse>;
export interface PutThirdPartyServiceLinkedConfigurationRecorderRequest {
    ServicePrincipal: string;
    ConnectorArn: string;
    ScopeConfiguration: ScopeConfiguration;
    Tags?: Tag[];
}
export declare const PutThirdPartyServiceLinkedConfigurationRecorderRequest: S.Schema<PutThirdPartyServiceLinkedConfigurationRecorderRequest>;
export interface PutThirdPartyServiceLinkedConfigurationRecorderResponse {
    Arn: string;
    Name: string;
}
export declare const PutThirdPartyServiceLinkedConfigurationRecorderResponse: S.Schema<PutThirdPartyServiceLinkedConfigurationRecorderResponse>;
export type Expression = string;
export interface SelectAggregateResourceConfigRequest {
    Expression: string;
    ConfigurationAggregatorName: string;
    Limit?: number;
    MaxResults?: number;
    NextToken?: string;
}
export declare const SelectAggregateResourceConfigRequest: S.Schema<SelectAggregateResourceConfigRequest>;
export type Results = string[];
export declare const Results: any;
export type FieldName = string;
export interface FieldInfo {
    Name?: string;
}
export declare const FieldInfo: S.Schema<FieldInfo>;
export type FieldInfoList = FieldInfo[];
export declare const FieldInfoList: any;
export interface QueryInfo {
    SelectFields?: FieldInfo[];
}
export declare const QueryInfo: S.Schema<QueryInfo>;
export interface SelectAggregateResourceConfigResponse {
    Results?: string[];
    QueryInfo?: QueryInfo;
    NextToken?: string;
}
export declare const SelectAggregateResourceConfigResponse: S.Schema<SelectAggregateResourceConfigResponse>;
export interface SelectResourceConfigRequest {
    Expression: string;
    Limit?: number;
    NextToken?: string;
}
export declare const SelectResourceConfigRequest: S.Schema<SelectResourceConfigRequest>;
export interface SelectResourceConfigResponse {
    Results?: string[];
    QueryInfo?: QueryInfo;
    NextToken?: string;
}
export declare const SelectResourceConfigResponse: S.Schema<SelectResourceConfigResponse>;
export type ReevaluateConfigRuleNames = string[];
export declare const ReevaluateConfigRuleNames: any;
export interface StartConfigRulesEvaluationRequest {
    ConfigRuleNames?: string[];
}
export declare const StartConfigRulesEvaluationRequest: S.Schema<StartConfigRulesEvaluationRequest>;
export interface StartConfigRulesEvaluationResponse {
}
export declare const StartConfigRulesEvaluationResponse: S.Schema<StartConfigRulesEvaluationResponse>;
export interface StartConfigurationRecorderRequest {
    ConfigurationRecorderName: string;
}
export declare const StartConfigurationRecorderRequest: S.Schema<StartConfigurationRecorderRequest>;
export interface StartConfigurationRecorderResponse {
}
export declare const StartConfigurationRecorderResponse: S.Schema<StartConfigurationRecorderResponse>;
export interface StartRemediationExecutionRequest {
    ConfigRuleName: string;
    ResourceKeys: ResourceKey[];
}
export declare const StartRemediationExecutionRequest: S.Schema<StartRemediationExecutionRequest>;
export interface StartRemediationExecutionResponse {
    FailureMessage?: string;
    FailedItems?: ResourceKey[];
}
export declare const StartRemediationExecutionResponse: S.Schema<StartRemediationExecutionResponse>;
export type EvaluationTimeout = number;
export type ClientToken = string;
export interface StartResourceEvaluationRequest {
    ResourceDetails: ResourceDetails;
    EvaluationContext?: EvaluationContext;
    EvaluationMode: EvaluationMode;
    EvaluationTimeout?: number;
    ClientToken?: string;
}
export declare const StartResourceEvaluationRequest: S.Schema<StartResourceEvaluationRequest>;
export interface StartResourceEvaluationResponse {
    ResourceEvaluationId?: string;
}
export declare const StartResourceEvaluationResponse: S.Schema<StartResourceEvaluationResponse>;
export interface StopConfigurationRecorderRequest {
    ConfigurationRecorderName: string;
}
export declare const StopConfigurationRecorderRequest: S.Schema<StopConfigurationRecorderRequest>;
export interface StopConfigurationRecorderResponse {
}
export declare const StopConfigurationRecorderResponse: S.Schema<StopConfigurationRecorderResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type ErrorMessage = string;
export type AssociateResourceTypesError = ConflictException | NoSuchConfigurationRecorderException | ValidationException | CommonErrors;
/**
 * Adds all resource types specified in the `ResourceTypes` list to the RecordingGroup of specified configuration recorder and includes those resource types when recording.
 *
 * For this operation, the specified configuration recorder must use a RecordingStrategy that is either `INCLUSION_BY_RESOURCE_TYPES` or `EXCLUSION_BY_RESOURCE_TYPES`.
 */
export declare const associateResourceTypes: API.OperationMethod<AssociateResourceTypesRequest, AssociateResourceTypesResponse, AssociateResourceTypesError, Credentials | HttpClient.HttpClient>;
export type BatchGetAggregateResourceConfigError = NoSuchConfigurationAggregatorException | ValidationException | CommonErrors;
/**
 * Returns the current configuration items for resources that are present in your Config aggregator. The operation also returns a list of resources that are not processed in the current request.
 * If there are no unprocessed resources, the operation returns an empty `unprocessedResourceIdentifiers` list.
 *
 * - The API does not return results for deleted resources.
 *
 * - The API does not return tags and relationships.
 */
export declare const batchGetAggregateResourceConfig: API.OperationMethod<BatchGetAggregateResourceConfigRequest, BatchGetAggregateResourceConfigResponse, BatchGetAggregateResourceConfigError, Credentials | HttpClient.HttpClient>;
export type BatchGetResourceConfigError = NoAvailableConfigurationRecorderException | ValidationException | CommonErrors;
/**
 * Returns the `BaseConfigurationItem` for one or more requested resources.
 * The operation also returns a list of resources that are
 * not processed in the current request. If there are no unprocessed
 * resources, the operation returns an empty unprocessedResourceKeys
 * list.
 *
 * - The API does not return results for deleted
 * resources.
 *
 * - The API does not return any tags for the requested
 * resources. This information is filtered out of the
 * supplementaryConfiguration section of the API
 * response.
 */
export declare const batchGetResourceConfig: API.OperationMethod<BatchGetResourceConfigRequest, BatchGetResourceConfigResponse, BatchGetResourceConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteAggregationAuthorizationError = InvalidParameterValueException | CommonErrors;
/**
 * Deletes the authorization granted to the specified
 * configuration aggregator account in a specified region.
 */
export declare const deleteAggregationAuthorization: API.OperationMethod<DeleteAggregationAuthorizationRequest, DeleteAggregationAuthorizationResponse, DeleteAggregationAuthorizationError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigRuleError = NoSuchConfigRuleException | ResourceInUseException | CommonErrors;
/**
 * Deletes the specified Config rule and all of its evaluation
 * results.
 *
 * Config sets the state of a rule to `DELETING`
 * until the deletion is complete. You cannot update a rule while it is
 * in this state. If you make a `PutConfigRule` or
 * `DeleteConfigRule` request for the rule, you will
 * receive a `ResourceInUseException`.
 *
 * You can check the state of a rule by using the
 * `DescribeConfigRules` request.
 *
 * **Recommendation: Consider excluding the `AWS::Config::ResourceCompliance` resource type from recording before deleting rules**
 *
 * Deleting rules creates configuration items (CIs) for `AWS::Config::ResourceCompliance`
 * that can affect your costs for the configuration recorder. If you are deleting rules which evaluate a large number of resource types,
 * this can lead to a spike in the number of CIs recorded.
 *
 * To avoid the associated costs, you can opt to disable recording
 * for the `AWS::Config::ResourceCompliance` resource type before deleting rules, and re-enable recording after the rules have been deleted.
 *
 * However, since deleting rules is an asynchronous process, it might take an hour or more to complete. During the time
 * when recording is disabled for `AWS::Config::ResourceCompliance`, rule evaluations will not be recorded in the associated resource’s history.
 */
export declare const deleteConfigRule: API.OperationMethod<DeleteConfigRuleRequest, DeleteConfigRuleResponse, DeleteConfigRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationAggregatorError = NoSuchConfigurationAggregatorException | CommonErrors;
/**
 * Deletes the specified configuration aggregator and the
 * aggregated data associated with the aggregator.
 */
export declare const deleteConfigurationAggregator: API.OperationMethod<DeleteConfigurationAggregatorRequest, DeleteConfigurationAggregatorResponse, DeleteConfigurationAggregatorError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationRecorderError = NoSuchConfigurationRecorderException | UnmodifiableEntityException | CommonErrors;
/**
 * Deletes the customer managed configuration recorder.
 *
 * This operation does not delete the configuration information that
 * was previously recorded. You will be able to access the previously
 * recorded information by using the
 * GetResourceConfigHistory operation, but you will not
 * be able to access this information in the Config console until
 * you have created a new customer managed configuration recorder.
 */
export declare const deleteConfigurationRecorder: API.OperationMethod<DeleteConfigurationRecorderRequest, DeleteConfigurationRecorderResponse, DeleteConfigurationRecorderError, Credentials | HttpClient.HttpClient>;
export type DeleteConformancePackError = NoSuchConformancePackException | ResourceInUseException | CommonErrors;
/**
 * Deletes the specified conformance pack and all the Config rules, remediation actions, and all evaluation results within that
 * conformance pack.
 *
 * Config sets the conformance pack to `DELETE_IN_PROGRESS` until the deletion is complete.
 * You cannot update a conformance pack while it is in this state.
 *
 * **Recommendation: Consider excluding the `AWS::Config::ResourceCompliance` resource type from recording before deleting rules**
 *
 * Deleting rules creates configuration items (CIs) for `AWS::Config::ResourceCompliance`
 * that can affect your costs for the configuration recorder. If you are deleting rules which evaluate a large number of resource types,
 * this can lead to a spike in the number of CIs recorded.
 *
 * To avoid the associated costs, you can opt to disable recording
 * for the `AWS::Config::ResourceCompliance` resource type before deleting rules, and re-enable recording after the rules have been deleted.
 *
 * However, since deleting rules is an asynchronous process, it might take an hour or more to complete. During the time
 * when recording is disabled for `AWS::Config::ResourceCompliance`, rule evaluations will not be recorded in the associated resource’s history.
 */
export declare const deleteConformancePack: API.OperationMethod<DeleteConformancePackRequest, DeleteConformancePackResponse, DeleteConformancePackError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified connector.
 */
export declare const deleteConnector: API.OperationMethod<DeleteConnectorRequest, DeleteConnectorResponse, DeleteConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteDeliveryChannelError = LastDeliveryChannelDeleteFailedException | NoSuchDeliveryChannelException | CommonErrors;
/**
 * Deletes the delivery channel.
 *
 * Before you can delete the delivery channel, you must stop the customer managed configuration recorder. You can use the StopConfigurationRecorder operation to stop the customer managed configuration recorder.
 */
export declare const deleteDeliveryChannel: API.OperationMethod<DeleteDeliveryChannelRequest, DeleteDeliveryChannelResponse, DeleteDeliveryChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteEvaluationResultsError = NoSuchConfigRuleException | ResourceInUseException | CommonErrors;
/**
 * Deletes the evaluation results for the specified Config
 * rule. You can specify one Config rule per request. After you
 * delete the evaluation results, you can call the StartConfigRulesEvaluation API to start evaluating
 * your Amazon Web Services resources against the rule.
 */
export declare const deleteEvaluationResults: API.OperationMethod<DeleteEvaluationResultsRequest, DeleteEvaluationResultsResponse, DeleteEvaluationResultsError, Credentials | HttpClient.HttpClient>;
export type DeleteOrganizationConfigRuleError = NoSuchOrganizationConfigRuleException | OrganizationAccessDeniedException | ResourceInUseException | CommonErrors;
/**
 * Deletes the specified organization Config rule and all of its evaluation results from all member accounts in that organization.
 *
 * Only a management account and a delegated administrator account can delete an organization Config rule.
 * When calling this API with a delegated administrator, you must ensure Organizations
 * `ListDelegatedAdministrator` permissions are added.
 *
 * Config sets the state of a rule to DELETE_IN_PROGRESS until the deletion is complete.
 * You cannot update a rule while it is in this state.
 *
 * **Recommendation: Consider excluding the `AWS::Config::ResourceCompliance` resource type from recording before deleting rules**
 *
 * Deleting rules creates configuration items (CIs) for `AWS::Config::ResourceCompliance`
 * that can affect your costs for the configuration recorder. If you are deleting rules which evaluate a large number of resource types,
 * this can lead to a spike in the number of CIs recorded.
 *
 * To avoid the associated costs, you can opt to disable recording
 * for the `AWS::Config::ResourceCompliance` resource type before deleting rules, and re-enable recording after the rules have been deleted.
 *
 * However, since deleting rules is an asynchronous process, it might take an hour or more to complete. During the time
 * when recording is disabled for `AWS::Config::ResourceCompliance`, rule evaluations will not be recorded in the associated resource’s history.
 */
export declare const deleteOrganizationConfigRule: API.OperationMethod<DeleteOrganizationConfigRuleRequest, DeleteOrganizationConfigRuleResponse, DeleteOrganizationConfigRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteOrganizationConformancePackError = NoSuchOrganizationConformancePackException | OrganizationAccessDeniedException | ResourceInUseException | CommonErrors;
/**
 * Deletes the specified organization conformance pack and all of the Config rules and remediation actions from
 * all member accounts in that organization.
 *
 * Only a management account or a delegated administrator account can delete an organization conformance pack.
 * When calling this API with a delegated administrator, you must ensure Organizations
 * `ListDelegatedAdministrator` permissions are added.
 *
 * Config sets the state of a conformance pack to DELETE_IN_PROGRESS until the deletion is complete.
 * You cannot update a conformance pack while it is in this state.
 *
 * **Recommendation: Consider excluding the `AWS::Config::ResourceCompliance` resource type from recording before deleting rules**
 *
 * Deleting rules creates configuration items (CIs) for `AWS::Config::ResourceCompliance`
 * that can affect your costs for the configuration recorder. If you are deleting rules which evaluate a large number of resource types,
 * this can lead to a spike in the number of CIs recorded.
 *
 * To avoid the associated costs, you can opt to disable recording
 * for the `AWS::Config::ResourceCompliance` resource type before deleting rules, and re-enable recording after the rules have been deleted.
 *
 * However, since deleting rules is an asynchronous process, it might take an hour or more to complete. During the time
 * when recording is disabled for `AWS::Config::ResourceCompliance`, rule evaluations will not be recorded in the associated resource’s history.
 */
export declare const deleteOrganizationConformancePack: API.OperationMethod<DeleteOrganizationConformancePackRequest, DeleteOrganizationConformancePackResponse, DeleteOrganizationConformancePackError, Credentials | HttpClient.HttpClient>;
export type DeletePendingAggregationRequestError = InvalidParameterValueException | CommonErrors;
/**
 * Deletes pending authorization requests for a specified
 * aggregator account in a specified region.
 */
export declare const deletePendingAggregationRequest: API.OperationMethod<DeletePendingAggregationRequestRequest, DeletePendingAggregationRequestResponse, DeletePendingAggregationRequestError, Credentials | HttpClient.HttpClient>;
export type DeleteRemediationConfigurationError = InsufficientPermissionsException | InvalidParameterValueException | NoSuchRemediationConfigurationException | RemediationInProgressException | CommonErrors;
/**
 * Deletes the remediation configuration.
 */
export declare const deleteRemediationConfiguration: API.OperationMethod<DeleteRemediationConfigurationRequest, DeleteRemediationConfigurationResponse, DeleteRemediationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteRemediationExceptionsError = NoSuchRemediationExceptionException | CommonErrors;
/**
 * Deletes one or more remediation exceptions mentioned in the resource keys.
 *
 * Config generates a remediation exception when a problem occurs executing a remediation action to a specific resource.
 * Remediation exceptions blocks auto-remediation until the exception is cleared.
 */
export declare const deleteRemediationExceptions: API.OperationMethod<DeleteRemediationExceptionsRequest, DeleteRemediationExceptionsResponse, DeleteRemediationExceptionsError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceConfigError = NoRunningConfigurationRecorderException | ValidationException | CommonErrors;
/**
 * Records the configuration state for a custom resource that has been deleted. This API records a new ConfigurationItem with a ResourceDeleted status. You can retrieve the ConfigurationItems recorded for this resource in your Config History.
 */
export declare const deleteResourceConfig: API.OperationMethod<DeleteResourceConfigRequest, DeleteResourceConfigResponse, DeleteResourceConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteRetentionConfigurationError = InvalidParameterValueException | NoSuchRetentionConfigurationException | CommonErrors;
/**
 * Deletes the retention configuration.
 */
export declare const deleteRetentionConfiguration: API.OperationMethod<DeleteRetentionConfigurationRequest, DeleteRetentionConfigurationResponse, DeleteRetentionConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceLinkedConfigurationRecorderError = ConflictException | NoSuchConfigurationRecorderException | ValidationException | CommonErrors;
/**
 * Deletes an existing service-linked configuration recorder.
 *
 * This operation does not delete the configuration information that was previously recorded. You will be able to access the previously
 * recorded information by using the
 * GetResourceConfigHistory operation, but you will not
 * be able to access this information in the Config console until
 * you have created a new service-linked configuration recorder for the same service.
 *
 * **The recording scope determines if you receive configuration items**
 *
 * The recording scope is set by the service that is linked to the configuration recorder and determines whether you receive configuration items (CIs) in the delivery channel. If the recording scope is internal, you will not receive CIs in the delivery channel.
 */
export declare const deleteServiceLinkedConfigurationRecorder: API.OperationMethod<DeleteServiceLinkedConfigurationRecorderRequest, DeleteServiceLinkedConfigurationRecorderResponse, DeleteServiceLinkedConfigurationRecorderError, Credentials | HttpClient.HttpClient>;
export type DeleteStoredQueryError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the stored query for a single Amazon Web Services account and a single Amazon Web Services Region.
 */
export declare const deleteStoredQuery: API.OperationMethod<DeleteStoredQueryRequest, DeleteStoredQueryResponse, DeleteStoredQueryError, Credentials | HttpClient.HttpClient>;
export type DeliverConfigSnapshotError = NoAvailableConfigurationRecorderException | NoRunningConfigurationRecorderException | NoSuchDeliveryChannelException | CommonErrors;
/**
 * Schedules delivery of a configuration snapshot to the Amazon S3
 * bucket in the specified delivery channel. After the delivery has
 * started, Config sends the following notifications using an
 * Amazon SNS topic that you have specified.
 *
 * - Notification of the start of the delivery.
 *
 * - Notification of the completion of the delivery, if the
 * delivery was successfully completed.
 *
 * - Notification of delivery failure, if the delivery
 * failed.
 */
export declare const deliverConfigSnapshot: API.OperationMethod<DeliverConfigSnapshotRequest, DeliverConfigSnapshotResponse, DeliverConfigSnapshotError, Credentials | HttpClient.HttpClient>;
export type DescribeAggregateComplianceByConfigRulesError = InvalidLimitException | InvalidNextTokenException | NoSuchConfigurationAggregatorException | ValidationException | CommonErrors;
/**
 * Returns a list of compliant and noncompliant rules with the
 * number of resources for compliant and noncompliant rules. Does not display rules that do not have compliance results.
 *
 * The results can return an empty result page, but if you
 * have a `nextToken`, the results are displayed on the next
 * page.
 */
export declare const describeAggregateComplianceByConfigRules: API.PaginatedOperationMethod<DescribeAggregateComplianceByConfigRulesRequest, DescribeAggregateComplianceByConfigRulesResponse, DescribeAggregateComplianceByConfigRulesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeAggregateComplianceByConformancePacksError = InvalidLimitException | InvalidNextTokenException | NoSuchConfigurationAggregatorException | ValidationException | CommonErrors;
/**
 * Returns a list of the existing and deleted conformance packs and their associated compliance status with the count of compliant and noncompliant Config rules within each
 * conformance pack. Also returns the total rule count which includes compliant rules, noncompliant rules, and rules that cannot be evaluated due to insufficient data.
 *
 * The results can return an empty result page, but if you have a `nextToken`, the results are displayed on the next page.
 */
export declare const describeAggregateComplianceByConformancePacks: API.PaginatedOperationMethod<DescribeAggregateComplianceByConformancePacksRequest, DescribeAggregateComplianceByConformancePacksResponse, DescribeAggregateComplianceByConformancePacksError, Credentials | HttpClient.HttpClient, AggregateComplianceByConformancePack>;
export type DescribeAggregationAuthorizationsError = InvalidLimitException | InvalidNextTokenException | InvalidParameterValueException | CommonErrors;
/**
 * Returns a list of authorizations granted to various aggregator
 * accounts and regions.
 */
export declare const describeAggregationAuthorizations: API.PaginatedOperationMethod<DescribeAggregationAuthorizationsRequest, DescribeAggregationAuthorizationsResponse, DescribeAggregationAuthorizationsError, Credentials | HttpClient.HttpClient, AggregationAuthorization>;
export type DescribeComplianceByConfigRuleError = InvalidNextTokenException | InvalidParameterValueException | NoSuchConfigRuleException | CommonErrors;
/**
 * Indicates whether the specified Config rules are compliant.
 * If a rule is noncompliant, this operation returns the number of Amazon Web Services
 * resources that do not comply with the rule.
 *
 * A rule is compliant if all of the evaluated resources comply
 * with it. It is noncompliant if any of these resources do not
 * comply.
 *
 * If Config has no current evaluation results for the rule,
 * it returns `INSUFFICIENT_DATA`. This result might
 * indicate one of the following conditions:
 *
 * - Config has never invoked an evaluation for the
 * rule. To check whether it has, use the
 * `DescribeConfigRuleEvaluationStatus` action
 * to get the `LastSuccessfulInvocationTime` and
 * `LastFailedInvocationTime`.
 *
 * - The rule's Lambda function is failing to send
 * evaluation results to Config. Verify that the role you
 * assigned to your configuration recorder includes the
 * `config:PutEvaluations` permission. If the
 * rule is a custom rule, verify that the Lambda execution
 * role includes the `config:PutEvaluations`
 * permission.
 *
 * - The rule's Lambda function has returned
 * `NOT_APPLICABLE` for all evaluation results.
 * This can occur if the resources were deleted or removed from
 * the rule's scope.
 */
export declare const describeComplianceByConfigRule: API.PaginatedOperationMethod<DescribeComplianceByConfigRuleRequest, DescribeComplianceByConfigRuleResponse, DescribeComplianceByConfigRuleError, Credentials | HttpClient.HttpClient, ComplianceByConfigRule>;
export type DescribeComplianceByResourceError = InvalidNextTokenException | InvalidParameterValueException | CommonErrors;
/**
 * Indicates whether the specified Amazon Web Services resources are compliant. If
 * a resource is noncompliant, this operation returns the number of Config rules that the resource does not comply with.
 *
 * A resource is compliant if it complies with all the Config
 * rules that evaluate it. It is noncompliant if it does not comply
 * with one or more of these rules.
 *
 * If Config has no current evaluation results for the
 * resource, it returns `INSUFFICIENT_DATA`. This result
 * might indicate one of the following conditions about the rules that
 * evaluate the resource:
 *
 * - Config has never invoked an evaluation for the
 * rule. To check whether it has, use the
 * `DescribeConfigRuleEvaluationStatus` action
 * to get the `LastSuccessfulInvocationTime` and
 * `LastFailedInvocationTime`.
 *
 * - The rule's Lambda function is failing to send
 * evaluation results to Config. Verify that the role that
 * you assigned to your configuration recorder includes the
 * `config:PutEvaluations` permission. If the
 * rule is a custom rule, verify that the Lambda execution
 * role includes the `config:PutEvaluations`
 * permission.
 *
 * - The rule's Lambda function has returned
 * `NOT_APPLICABLE` for all evaluation results.
 * This can occur if the resources were deleted or removed from
 * the rule's scope.
 */
export declare const describeComplianceByResource: API.PaginatedOperationMethod<DescribeComplianceByResourceRequest, DescribeComplianceByResourceResponse, DescribeComplianceByResourceError, Credentials | HttpClient.HttpClient, ComplianceByResource>;
export type DescribeConfigRuleEvaluationStatusError = InvalidNextTokenException | InvalidParameterValueException | NoSuchConfigRuleException | CommonErrors;
/**
 * Returns status information for each of your Config managed rules. The status includes information such as the last time Config invoked the rule, the last time Config failed to invoke
 * the rule, and the related error for the last failure.
 */
export declare const describeConfigRuleEvaluationStatus: API.PaginatedOperationMethod<DescribeConfigRuleEvaluationStatusRequest, DescribeConfigRuleEvaluationStatusResponse, DescribeConfigRuleEvaluationStatusError, Credentials | HttpClient.HttpClient, ConfigRuleEvaluationStatus>;
export type DescribeConfigRulesError = InvalidNextTokenException | InvalidParameterValueException | NoSuchConfigRuleException | CommonErrors;
/**
 * Returns details about your Config rules.
 */
export declare const describeConfigRules: API.PaginatedOperationMethod<DescribeConfigRulesRequest, DescribeConfigRulesResponse, DescribeConfigRulesError, Credentials | HttpClient.HttpClient, ConfigRule>;
export type DescribeConfigurationAggregatorsError = InvalidLimitException | InvalidNextTokenException | InvalidParameterValueException | NoSuchConfigurationAggregatorException | CommonErrors;
/**
 * Returns the details of one or more configuration aggregators.
 * If the configuration aggregator is not specified, this operation
 * returns the details for all the configuration aggregators associated
 * with the account.
 */
export declare const describeConfigurationAggregators: API.PaginatedOperationMethod<DescribeConfigurationAggregatorsRequest, DescribeConfigurationAggregatorsResponse, DescribeConfigurationAggregatorsError, Credentials | HttpClient.HttpClient, ConfigurationAggregator>;
export type DescribeConfigurationAggregatorSourcesStatusError = InvalidLimitException | InvalidNextTokenException | InvalidParameterValueException | NoSuchConfigurationAggregatorException | CommonErrors;
/**
 * Returns status information for sources within an aggregator.
 * The status includes information about the last time Config verified authorization between the source account and an aggregator account. In case of a failure, the status contains the related error code or message.
 */
export declare const describeConfigurationAggregatorSourcesStatus: API.PaginatedOperationMethod<DescribeConfigurationAggregatorSourcesStatusRequest, DescribeConfigurationAggregatorSourcesStatusResponse, DescribeConfigurationAggregatorSourcesStatusError, Credentials | HttpClient.HttpClient, AggregatedSourceStatus>;
export type DescribeConfigurationRecordersError = NoSuchConfigurationRecorderException | ValidationException | CommonErrors;
/**
 * Returns details for the configuration recorder you specify.
 *
 * If a configuration recorder is not specified, this operation returns details for the customer managed configuration recorder configured for the
 * account, if applicable.
 *
 * When making a request to this operation, you can only specify one configuration recorder.
 */
export declare const describeConfigurationRecorders: API.OperationMethod<DescribeConfigurationRecordersRequest, DescribeConfigurationRecordersResponse, DescribeConfigurationRecordersError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationRecorderStatusError = NoSuchConfigurationRecorderException | ValidationException | CommonErrors;
/**
 * Returns the current status of the configuration
 * recorder you specify as well as the status of the last recording event for the configuration recorders.
 *
 * For a detailed status of recording events over time, add your Config events to Amazon CloudWatch metrics and use CloudWatch metrics.
 *
 * If a configuration recorder is not specified, this operation returns the status for the customer managed configuration recorder configured for the
 * account, if applicable.
 *
 * When making a request to this operation, you can only specify one configuration recorder.
 */
export declare const describeConfigurationRecorderStatus: API.OperationMethod<DescribeConfigurationRecorderStatusRequest, DescribeConfigurationRecorderStatusResponse, DescribeConfigurationRecorderStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeConformancePackComplianceError = InvalidLimitException | InvalidNextTokenException | InvalidParameterValueException | NoSuchConfigRuleInConformancePackException | NoSuchConformancePackException | CommonErrors;
/**
 * Returns compliance details for each rule in that conformance pack.
 *
 * You must provide exact rule names.
 */
export declare const describeConformancePackCompliance: API.PaginatedOperationMethod<DescribeConformancePackComplianceRequest, DescribeConformancePackComplianceResponse, DescribeConformancePackComplianceError, Credentials | HttpClient.HttpClient, ConformancePackRuleCompliance>;
export type DescribeConformancePacksError = InvalidLimitException | InvalidNextTokenException | InvalidParameterValueException | NoSuchConformancePackException | CommonErrors;
/**
 * Returns a list of one or more conformance packs.
 */
export declare const describeConformancePacks: API.PaginatedOperationMethod<DescribeConformancePacksRequest, DescribeConformancePacksResponse, DescribeConformancePacksError, Credentials | HttpClient.HttpClient, ConformancePackDetail>;
export type DescribeConformancePackStatusError = InvalidLimitException | InvalidNextTokenException | InvalidParameterValueException | CommonErrors;
/**
 * Provides one or more conformance packs deployment status.
 *
 * If there are no conformance packs then you will see an empty result.
 */
export declare const describeConformancePackStatus: API.PaginatedOperationMethod<DescribeConformancePackStatusRequest, DescribeConformancePackStatusResponse, DescribeConformancePackStatusError, Credentials | HttpClient.HttpClient, ConformancePackStatusDetail>;
export type DescribeDeliveryChannelsError = NoSuchDeliveryChannelException | CommonErrors;
/**
 * Returns details about the specified delivery channel. If a
 * delivery channel is not specified, this operation returns the details
 * of all delivery channels associated with the account.
 *
 * Currently, you can specify only one delivery channel per
 * region in your account.
 */
export declare const describeDeliveryChannels: API.OperationMethod<DescribeDeliveryChannelsRequest, DescribeDeliveryChannelsResponse, DescribeDeliveryChannelsError, Credentials | HttpClient.HttpClient>;
export type DescribeDeliveryChannelStatusError = NoSuchDeliveryChannelException | CommonErrors;
/**
 * Returns the current status of the specified delivery channel.
 * If a delivery channel is not specified, this operation returns the
 * current status of all delivery channels associated with the
 * account.
 *
 * Currently, you can specify only one delivery channel per
 * region in your account.
 */
export declare const describeDeliveryChannelStatus: API.OperationMethod<DescribeDeliveryChannelStatusRequest, DescribeDeliveryChannelStatusResponse, DescribeDeliveryChannelStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationConfigRulesError = InvalidLimitException | InvalidNextTokenException | NoSuchOrganizationConfigRuleException | OrganizationAccessDeniedException | CommonErrors;
/**
 * Returns a list of organization Config rules.
 *
 * When you specify the limit and the next token, you receive a paginated response.
 *
 * Limit and next token are not applicable if you specify organization Config rule names.
 * It is only applicable, when you request all the organization Config rules.
 *
 * *For accounts within an organization*
 *
 * If you deploy an organizational rule or conformance pack in an organization
 * administrator account, and then establish a delegated administrator and deploy an
 * organizational rule or conformance pack in the delegated administrator account, you
 * won't be able to see the organizational rule or conformance pack in the organization
 * administrator account from the delegated administrator account or see the organizational
 * rule or conformance pack in the delegated administrator account from organization
 * administrator account. The `DescribeOrganizationConfigRules` and
 * `DescribeOrganizationConformancePacks` APIs can only see and interact with
 * the organization-related resource that were deployed from within the account calling
 * those APIs.
 */
export declare const describeOrganizationConfigRules: API.PaginatedOperationMethod<DescribeOrganizationConfigRulesRequest, DescribeOrganizationConfigRulesResponse, DescribeOrganizationConfigRulesError, Credentials | HttpClient.HttpClient, OrganizationConfigRule>;
export type DescribeOrganizationConfigRuleStatusesError = InvalidLimitException | InvalidNextTokenException | NoSuchOrganizationConfigRuleException | OrganizationAccessDeniedException | CommonErrors;
/**
 * Provides organization Config rule deployment status for an organization.
 *
 * The status is not considered successful until organization Config rule is successfully deployed in all the member
 * accounts with an exception of excluded accounts.
 *
 * When you specify the limit and the next token, you receive a paginated response.
 * Limit and next token are not applicable if you specify organization Config rule names.
 * It is only applicable, when you request all the organization Config rules.
 */
export declare const describeOrganizationConfigRuleStatuses: API.PaginatedOperationMethod<DescribeOrganizationConfigRuleStatusesRequest, DescribeOrganizationConfigRuleStatusesResponse, DescribeOrganizationConfigRuleStatusesError, Credentials | HttpClient.HttpClient, OrganizationConfigRuleStatus>;
export type DescribeOrganizationConformancePacksError = InvalidLimitException | InvalidNextTokenException | NoSuchOrganizationConformancePackException | OrganizationAccessDeniedException | CommonErrors;
/**
 * Returns a list of organization conformance packs.
 *
 * When you specify the limit and the next token, you receive a paginated response.
 *
 * Limit and next token are not applicable if you specify organization conformance packs names. They are only applicable,
 * when you request all the organization conformance packs.
 *
 * *For accounts within an organization*
 *
 * If you deploy an organizational rule or conformance pack in an organization
 * administrator account, and then establish a delegated administrator and deploy an
 * organizational rule or conformance pack in the delegated administrator account, you
 * won't be able to see the organizational rule or conformance pack in the organization
 * administrator account from the delegated administrator account or see the organizational
 * rule or conformance pack in the delegated administrator account from organization
 * administrator account. The `DescribeOrganizationConfigRules` and
 * `DescribeOrganizationConformancePacks` APIs can only see and interact with
 * the organization-related resource that were deployed from within the account calling
 * those APIs.
 */
export declare const describeOrganizationConformancePacks: API.PaginatedOperationMethod<DescribeOrganizationConformancePacksRequest, DescribeOrganizationConformancePacksResponse, DescribeOrganizationConformancePacksError, Credentials | HttpClient.HttpClient, OrganizationConformancePack>;
export type DescribeOrganizationConformancePackStatusesError = InvalidLimitException | InvalidNextTokenException | NoSuchOrganizationConformancePackException | OrganizationAccessDeniedException | CommonErrors;
/**
 * Provides organization conformance pack deployment status for an organization.
 *
 * The status is not considered successful until organization conformance pack is successfully
 * deployed in all the member accounts with an exception of excluded accounts.
 *
 * When you specify the limit and the next token, you receive a paginated response.
 * Limit and next token are not applicable if you specify organization conformance pack names.
 * They are only applicable, when you request all the organization conformance packs.
 */
export declare const describeOrganizationConformancePackStatuses: API.PaginatedOperationMethod<DescribeOrganizationConformancePackStatusesRequest, DescribeOrganizationConformancePackStatusesResponse, DescribeOrganizationConformancePackStatusesError, Credentials | HttpClient.HttpClient, OrganizationConformancePackStatus>;
export type DescribePendingAggregationRequestsError = InvalidLimitException | InvalidNextTokenException | InvalidParameterValueException | CommonErrors;
/**
 * Returns a list of all pending aggregation requests.
 */
export declare const describePendingAggregationRequests: API.PaginatedOperationMethod<DescribePendingAggregationRequestsRequest, DescribePendingAggregationRequestsResponse, DescribePendingAggregationRequestsError, Credentials | HttpClient.HttpClient, PendingAggregationRequest>;
export type DescribeRemediationConfigurationsError = CommonErrors;
/**
 * Returns the details of one or more remediation configurations.
 */
export declare const describeRemediationConfigurations: API.OperationMethod<DescribeRemediationConfigurationsRequest, DescribeRemediationConfigurationsResponse, DescribeRemediationConfigurationsError, Credentials | HttpClient.HttpClient>;
export type DescribeRemediationExceptionsError = InvalidNextTokenException | InvalidParameterValueException | CommonErrors;
/**
 * Returns the details of one or more remediation exceptions. A detailed view of a remediation exception for a set of resources that includes an explanation of an exception and the time when the exception will be deleted.
 * When you specify the limit and the next token, you receive a paginated response.
 *
 * Config generates a remediation exception when a problem occurs executing a remediation action to a specific resource.
 * Remediation exceptions blocks auto-remediation until the exception is cleared.
 *
 * When you specify the limit and the next token, you receive a paginated response.
 *
 * Limit and next token are not applicable if you request resources in batch. It is only applicable, when you request all resources.
 */
export declare const describeRemediationExceptions: API.PaginatedOperationMethod<DescribeRemediationExceptionsRequest, DescribeRemediationExceptionsResponse, DescribeRemediationExceptionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeRemediationExecutionStatusError = InvalidNextTokenException | InvalidParameterValueException | NoSuchRemediationConfigurationException | CommonErrors;
/**
 * Provides a detailed view of a Remediation Execution for a set of resources including state, timestamps for when steps for the remediation execution occur, and any error messages for steps that have failed.
 * When you specify the limit and the next token, you receive a paginated response.
 */
export declare const describeRemediationExecutionStatus: API.PaginatedOperationMethod<DescribeRemediationExecutionStatusRequest, DescribeRemediationExecutionStatusResponse, DescribeRemediationExecutionStatusError, Credentials | HttpClient.HttpClient, RemediationExecutionStatus>;
export type DescribeRetentionConfigurationsError = InvalidNextTokenException | InvalidParameterValueException | NoSuchRetentionConfigurationException | CommonErrors;
/**
 * Returns the details of one or more retention configurations. If
 * the retention configuration name is not specified, this operation
 * returns the details for all the retention configurations for that
 * account.
 *
 * Currently, Config supports only one retention
 * configuration per region in your account.
 */
export declare const describeRetentionConfigurations: API.PaginatedOperationMethod<DescribeRetentionConfigurationsRequest, DescribeRetentionConfigurationsResponse, DescribeRetentionConfigurationsError, Credentials | HttpClient.HttpClient, RetentionConfiguration>;
export type DisassociateResourceTypesError = ConflictException | NoSuchConfigurationRecorderException | ValidationException | CommonErrors;
/**
 * Removes all resource types specified in the `ResourceTypes` list from the RecordingGroup of configuration recorder and excludes these resource types when recording.
 *
 * For this operation, the configuration recorder must use a RecordingStrategy that is either `INCLUSION_BY_RESOURCE_TYPES` or `EXCLUSION_BY_RESOURCE_TYPES`.
 */
export declare const disassociateResourceTypes: API.OperationMethod<DisassociateResourceTypesRequest, DisassociateResourceTypesResponse, DisassociateResourceTypesError, Credentials | HttpClient.HttpClient>;
export type GetAggregateComplianceDetailsByConfigRuleError = InvalidLimitException | InvalidNextTokenException | NoSuchConfigurationAggregatorException | ValidationException | CommonErrors;
/**
 * Returns the evaluation results for the specified Config
 * rule for a specific resource in a rule. The results indicate which
 * Amazon Web Services resources were evaluated by the rule, when each resource was
 * last evaluated, and whether each resource complies with the rule.
 *
 * The results can return an empty result page. But if you
 * have a `nextToken`, the results are displayed on the next
 * page.
 */
export declare const getAggregateComplianceDetailsByConfigRule: API.PaginatedOperationMethod<GetAggregateComplianceDetailsByConfigRuleRequest, GetAggregateComplianceDetailsByConfigRuleResponse, GetAggregateComplianceDetailsByConfigRuleError, Credentials | HttpClient.HttpClient, AggregateEvaluationResult>;
export type GetAggregateConfigRuleComplianceSummaryError = InvalidLimitException | InvalidNextTokenException | NoSuchConfigurationAggregatorException | ValidationException | CommonErrors;
/**
 * Returns the number of compliant and noncompliant rules for one
 * or more accounts and regions in an aggregator.
 *
 * The results can return an empty result page, but if you
 * have a nextToken, the results are displayed on the next
 * page.
 */
export declare const getAggregateConfigRuleComplianceSummary: API.PaginatedOperationMethod<GetAggregateConfigRuleComplianceSummaryRequest, GetAggregateConfigRuleComplianceSummaryResponse, GetAggregateConfigRuleComplianceSummaryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetAggregateConformancePackComplianceSummaryError = InvalidLimitException | InvalidNextTokenException | NoSuchConfigurationAggregatorException | ValidationException | CommonErrors;
/**
 * Returns the count of compliant and noncompliant conformance packs across all Amazon Web Services accounts and Amazon Web Services Regions in an aggregator. You can filter based on Amazon Web Services account ID or Amazon Web Services Region.
 *
 * The results can return an empty result page, but if you have a nextToken, the results are displayed on the next page.
 */
export declare const getAggregateConformancePackComplianceSummary: API.PaginatedOperationMethod<GetAggregateConformancePackComplianceSummaryRequest, GetAggregateConformancePackComplianceSummaryResponse, GetAggregateConformancePackComplianceSummaryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetAggregateDiscoveredResourceCountsError = InvalidLimitException | InvalidNextTokenException | NoSuchConfigurationAggregatorException | ValidationException | CommonErrors;
/**
 * Returns the resource counts across accounts and regions that are present in your Config aggregator. You can request the resource counts by providing filters and GroupByKey.
 *
 * For example, if the input contains accountID 12345678910 and region us-east-1 in filters, the API returns the count of resources in account ID 12345678910 and region us-east-1.
 * If the input contains ACCOUNT_ID as a GroupByKey, the API returns resource counts for all source accounts that are present in your aggregator.
 */
export declare const getAggregateDiscoveredResourceCounts: API.PaginatedOperationMethod<GetAggregateDiscoveredResourceCountsRequest, GetAggregateDiscoveredResourceCountsResponse, GetAggregateDiscoveredResourceCountsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetAggregateResourceConfigError = NoSuchConfigurationAggregatorException | OversizedConfigurationItemException | ResourceNotDiscoveredException | ValidationException | CommonErrors;
/**
 * Returns configuration item that is aggregated for your specific resource in a specific source account and region.
 *
 * The API does not return results for deleted resources.
 */
export declare const getAggregateResourceConfig: API.OperationMethod<GetAggregateResourceConfigRequest, GetAggregateResourceConfigResponse, GetAggregateResourceConfigError, Credentials | HttpClient.HttpClient>;
export type GetComplianceDetailsByConfigRuleError = InvalidNextTokenException | InvalidParameterValueException | NoSuchConfigRuleException | CommonErrors;
/**
 * Returns the evaluation results for the specified Config
 * rule. The results indicate which Amazon Web Services resources were evaluated by the
 * rule, when each resource was last evaluated, and whether each
 * resource complies with the rule.
 */
export declare const getComplianceDetailsByConfigRule: API.PaginatedOperationMethod<GetComplianceDetailsByConfigRuleRequest, GetComplianceDetailsByConfigRuleResponse, GetComplianceDetailsByConfigRuleError, Credentials | HttpClient.HttpClient, EvaluationResult>;
export type GetComplianceDetailsByResourceError = InvalidParameterValueException | CommonErrors;
/**
 * Returns the evaluation results for the specified Amazon Web Services resource.
 * The results indicate which Config rules were used to evaluate
 * the resource, when each rule was last invoked, and whether the resource
 * complies with each rule.
 */
export declare const getComplianceDetailsByResource: API.PaginatedOperationMethod<GetComplianceDetailsByResourceRequest, GetComplianceDetailsByResourceResponse, GetComplianceDetailsByResourceError, Credentials | HttpClient.HttpClient, EvaluationResult>;
export type GetComplianceSummaryByConfigRuleError = CommonErrors;
/**
 * Returns the number of Config rules that are compliant and
 * noncompliant, up to a maximum of 25 for each.
 */
export declare const getComplianceSummaryByConfigRule: API.OperationMethod<GetComplianceSummaryByConfigRuleRequest, GetComplianceSummaryByConfigRuleResponse, GetComplianceSummaryByConfigRuleError, Credentials | HttpClient.HttpClient>;
export type GetComplianceSummaryByResourceTypeError = InvalidParameterValueException | CommonErrors;
/**
 * Returns the number of resources that are compliant and the
 * number that are noncompliant. You can specify one or more resource
 * types to get these numbers for each resource type. The maximum
 * number returned is 100.
 */
export declare const getComplianceSummaryByResourceType: API.OperationMethod<GetComplianceSummaryByResourceTypeRequest, GetComplianceSummaryByResourceTypeResponse, GetComplianceSummaryByResourceTypeError, Credentials | HttpClient.HttpClient>;
export type GetConformancePackComplianceDetailsError = InvalidLimitException | InvalidNextTokenException | InvalidParameterValueException | NoSuchConfigRuleInConformancePackException | NoSuchConformancePackException | CommonErrors;
/**
 * Returns compliance details of a conformance pack for all Amazon Web Services resources that are monitered by conformance pack.
 */
export declare const getConformancePackComplianceDetails: API.PaginatedOperationMethod<GetConformancePackComplianceDetailsRequest, GetConformancePackComplianceDetailsResponse, GetConformancePackComplianceDetailsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetConformancePackComplianceSummaryError = InvalidLimitException | InvalidNextTokenException | NoSuchConformancePackException | CommonErrors;
/**
 * Returns compliance details for the conformance pack based on the cumulative compliance results of all the rules in that conformance pack.
 */
export declare const getConformancePackComplianceSummary: API.PaginatedOperationMethod<GetConformancePackComplianceSummaryRequest, GetConformancePackComplianceSummaryResponse, GetConformancePackComplianceSummaryError, Credentials | HttpClient.HttpClient, ConformancePackComplianceSummary>;
export type GetConnectorError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the details of the specified connector.
 */
export declare const getConnector: API.OperationMethod<GetConnectorRequest, GetConnectorResponse, GetConnectorError, Credentials | HttpClient.HttpClient>;
export type GetCustomRulePolicyError = NoSuchConfigRuleException | CommonErrors;
/**
 * Returns the policy definition containing the logic for your Config Custom Policy rule.
 */
export declare const getCustomRulePolicy: API.OperationMethod<GetCustomRulePolicyRequest, GetCustomRulePolicyResponse, GetCustomRulePolicyError, Credentials | HttpClient.HttpClient>;
export type GetDiscoveredResourceCountsError = InvalidLimitException | InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Returns the resource types, the number of each resource type,
 * and the total number of resources that Config is recording in
 * this region for your Amazon Web Services account.
 *
 * **Example**
 *
 * - Config is recording three resource types in the US
 * East (Ohio) Region for your account: 25 EC2 instances, 20
 * IAM users, and 15 S3 buckets.
 *
 * - You make a call to the
 * `GetDiscoveredResourceCounts` action and
 * specify that you want all resource types.
 *
 * - Config returns the following:
 *
 * - The resource types (EC2 instances, IAM users,
 * and S3 buckets).
 *
 * - The number of each resource type (25, 20, and
 * 15).
 *
 * - The total number of all resources
 * (60).
 *
 * The response is paginated. By default, Config lists 100
 * ResourceCount objects on each page. You can
 * customize this number with the `limit` parameter. The
 * response includes a `nextToken` string. To get the next
 * page of results, run the request again and specify the string for
 * the `nextToken` parameter.
 *
 * If you make a call to the GetDiscoveredResourceCounts action, you might
 * not immediately receive resource counts in the following
 * situations:
 *
 * - You are a new Config customer.
 *
 * - You just enabled resource recording.
 *
 * It might take a few minutes for Config to record and
 * count your resources. Wait a few minutes and then retry the
 * GetDiscoveredResourceCounts action.
 */
export declare const getDiscoveredResourceCounts: API.PaginatedOperationMethod<GetDiscoveredResourceCountsRequest, GetDiscoveredResourceCountsResponse, GetDiscoveredResourceCountsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetOrganizationConfigRuleDetailedStatusError = InvalidLimitException | InvalidNextTokenException | NoSuchOrganizationConfigRuleException | OrganizationAccessDeniedException | CommonErrors;
/**
 * Returns detailed status for each member account within an organization for a given organization Config rule.
 */
export declare const getOrganizationConfigRuleDetailedStatus: API.PaginatedOperationMethod<GetOrganizationConfigRuleDetailedStatusRequest, GetOrganizationConfigRuleDetailedStatusResponse, GetOrganizationConfigRuleDetailedStatusError, Credentials | HttpClient.HttpClient, MemberAccountStatus>;
export type GetOrganizationConformancePackDetailedStatusError = InvalidLimitException | InvalidNextTokenException | NoSuchOrganizationConformancePackException | OrganizationAccessDeniedException | CommonErrors;
/**
 * Returns detailed status for each member account within an organization for a given organization conformance pack.
 */
export declare const getOrganizationConformancePackDetailedStatus: API.PaginatedOperationMethod<GetOrganizationConformancePackDetailedStatusRequest, GetOrganizationConformancePackDetailedStatusResponse, GetOrganizationConformancePackDetailedStatusError, Credentials | HttpClient.HttpClient, OrganizationConformancePackDetailedStatus>;
export type GetOrganizationCustomRulePolicyError = NoSuchOrganizationConfigRuleException | OrganizationAccessDeniedException | CommonErrors;
/**
 * Returns the policy definition containing the logic for your organization Config Custom Policy rule.
 */
export declare const getOrganizationCustomRulePolicy: API.OperationMethod<GetOrganizationCustomRulePolicyRequest, GetOrganizationCustomRulePolicyResponse, GetOrganizationCustomRulePolicyError, Credentials | HttpClient.HttpClient>;
export type GetResourceConfigHistoryError = InvalidLimitException | InvalidNextTokenException | InvalidTimeRangeException | NoAvailableConfigurationRecorderException | ResourceNotDiscoveredException | ValidationException | CommonErrors;
/**
 * For accurate reporting on the compliance status, you must record the `AWS::Config::ResourceCompliance` resource type.
 *
 * For more information, see Recording Amazon Web Services Resources in the *Config Resources Developer Guide*.
 *
 * Returns a list of configurations items (CIs) for the specified resource.
 *
 * **Contents**
 *
 * The list contains details about each state of the resource
 * during the specified time interval. If you specified a retention
 * period to retain your CIs between a
 * minimum of 30 days and a maximum of 7 years (2557 days), Config
 * returns the CIs for the specified
 * retention period.
 *
 * **Pagination**
 *
 * The response is paginated. By default, Config returns a
 * limit of 10 configuration items per page. You can customize this
 * number with the `limit` parameter. The response includes
 * a `nextToken` string. To get the next page of results,
 * run the request again and specify the string for the
 * `nextToken` parameter.
 *
 * Each call to the API is limited to span a duration of seven
 * days. It is likely that the number of records returned is
 * smaller than the specified `limit`. In such cases,
 * you can make another call, using the
 * `nextToken`.
 */
export declare const getResourceConfigHistory: API.PaginatedOperationMethod<GetResourceConfigHistoryRequest, GetResourceConfigHistoryResponse, GetResourceConfigHistoryError, Credentials | HttpClient.HttpClient, ConfigurationItem>;
export type GetResourceEvaluationSummaryError = ResourceNotFoundException | CommonErrors;
/**
 * Returns a summary of resource evaluation for the specified resource evaluation ID from the proactive rules that were run.
 * The results indicate which evaluation context was used to evaluate the rules, which resource details were evaluated,
 * the evaluation mode that was run, and whether the resource details comply with the configuration of the proactive rules.
 *
 * To see additional information about the evaluation result, such as which rule flagged a resource as NON_COMPLIANT, use the GetComplianceDetailsByResource API.
 * For more information, see the Examples section.
 */
export declare const getResourceEvaluationSummary: API.OperationMethod<GetResourceEvaluationSummaryRequest, GetResourceEvaluationSummaryResponse, GetResourceEvaluationSummaryError, Credentials | HttpClient.HttpClient>;
export type GetStoredQueryError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the details of a specific stored query.
 */
export declare const getStoredQuery: API.OperationMethod<GetStoredQueryRequest, GetStoredQueryResponse, GetStoredQueryError, Credentials | HttpClient.HttpClient>;
export type ListAggregateDiscoveredResourcesError = InvalidLimitException | InvalidNextTokenException | NoSuchConfigurationAggregatorException | ValidationException | CommonErrors;
/**
 * Accepts a resource type and returns a list of resource identifiers that are aggregated for a specific resource type across accounts and regions.
 * A resource identifier includes the resource type, ID, (if available) the custom resource name, source account, and source region.
 * You can narrow the results to include only resources that have specific resource IDs, or a resource name, or source account ID, or source region.
 *
 * For example, if the input consists of accountID 12345678910 and the region is us-east-1 for resource type `AWS::EC2::Instance` then the API returns all the EC2 instance identifiers of accountID 12345678910 and region us-east-1.
 */
export declare const listAggregateDiscoveredResources: API.PaginatedOperationMethod<ListAggregateDiscoveredResourcesRequest, ListAggregateDiscoveredResourcesResponse, ListAggregateDiscoveredResourcesError, Credentials | HttpClient.HttpClient, AggregateResourceIdentifier>;
export type ListConfigurationRecordersError = ValidationException | CommonErrors;
/**
 * Returns a list of configuration recorders depending on the filters you specify.
 */
export declare const listConfigurationRecorders: API.PaginatedOperationMethod<ListConfigurationRecordersRequest, ListConfigurationRecordersResponse, ListConfigurationRecordersError, Credentials | HttpClient.HttpClient, ConfigurationRecorderSummary>;
export type ListConformancePackComplianceScoresError = InvalidLimitException | InvalidNextTokenException | InvalidParameterValueException | CommonErrors;
/**
 * Returns a list of conformance pack compliance scores.
 * A compliance score is the percentage of the number of compliant rule-resource combinations in a conformance pack compared to the number of total possible rule-resource combinations in the conformance pack.
 * This metric provides you with a high-level view of the compliance state of your conformance packs. You can use it to identify, investigate, and understand
 * the level of compliance in your conformance packs.
 *
 * Conformance packs with no evaluation results will have a compliance score of `INSUFFICIENT_DATA`.
 */
export declare const listConformancePackComplianceScores: API.PaginatedOperationMethod<ListConformancePackComplianceScoresRequest, ListConformancePackComplianceScoresResponse, ListConformancePackComplianceScoresError, Credentials | HttpClient.HttpClient, unknown>;
export type ListConnectorsError = ValidationException | CommonErrors;
/**
 * Returns a list of connectors depending on the filters you specify.
 */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient, ConnectorSummary>;
export type ListDiscoveredResourcesError = InvalidLimitException | InvalidNextTokenException | NoAvailableConfigurationRecorderException | ValidationException | CommonErrors;
/**
 * Returns a list of resource
 * resource identifiers for the specified resource types for the resources of that type. A *resource identifier*
 * includes the resource type, ID, and (if available) the custom
 * resource name.
 *
 * The results consist of resources that Config has
 * *discovered*, including those that Config is not currently
 * recording. You can narrow the results to include only resources that
 * have specific resource IDs or a resource name.
 *
 * You can specify either resource IDs or a resource name, but
 * not both, in the same request.
 *
 * *CloudFormation stack recording behavior in Config*
 *
 * When a CloudFormation stack fails to create (for example, it enters the `ROLLBACK_FAILED` state),
 * Config does not record a configuration item (CI) for that stack. Configuration items are only recorded for stacks that reach
 * the following states:
 *
 * - `CREATE_COMPLETE`
 *
 * - `UPDATE_COMPLETE`
 *
 * - `UPDATE_ROLLBACK_COMPLETE`
 *
 * - `UPDATE_ROLLBACK_FAILED`
 *
 * - `DELETE_FAILED`
 *
 * - `DELETE_COMPLETE`
 *
 * Because no CI is created for a failed stack creation, you won't see configuration history
 * for that stack in Config, even after the stack is deleted. This helps make sure that Config only
 * tracks resources that were successfully provisioned.
 */
export declare const listDiscoveredResources: API.PaginatedOperationMethod<ListDiscoveredResourcesRequest, ListDiscoveredResourcesResponse, ListDiscoveredResourcesError, Credentials | HttpClient.HttpClient, ResourceIdentifier>;
export type ListResourceEvaluationsError = InvalidNextTokenException | InvalidParameterValueException | InvalidTimeRangeException | CommonErrors;
/**
 * Returns a list of proactive resource evaluations.
 */
export declare const listResourceEvaluations: API.PaginatedOperationMethod<ListResourceEvaluationsRequest, ListResourceEvaluationsResponse, ListResourceEvaluationsError, Credentials | HttpClient.HttpClient, ResourceEvaluation>;
export type ListStoredQueriesError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Lists the stored queries for a single Amazon Web Services account and a single Amazon Web Services Region. The default is 100.
 */
export declare const listStoredQueries: API.PaginatedOperationMethod<ListStoredQueriesRequest, ListStoredQueriesResponse, ListStoredQueriesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InvalidLimitException | InvalidNextTokenException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List the tags for Config resource.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type PutAggregationAuthorizationError = InvalidParameterValueException | CommonErrors;
/**
 * Authorizes the aggregator account and region to collect data
 * from the source account and region.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * `PutAggregationAuthorization` is an idempotent API. Subsequent requests won’t create a duplicate resource if one was already created. If a following request has different `tags` values,
 * Config will ignore these differences and treat it as an idempotent request of the previous. In this case, `tags` will not be updated, even if they are different.
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export declare const putAggregationAuthorization: API.OperationMethod<PutAggregationAuthorizationRequest, PutAggregationAuthorizationResponse, PutAggregationAuthorizationError, Credentials | HttpClient.HttpClient>;
export type PutConfigRuleError = InsufficientPermissionsException | InvalidParameterValueException | MaxNumberOfConfigRulesExceededException | NoAvailableConfigurationRecorderException | ResourceInUseException | CommonErrors;
/**
 * Adds or updates an Config rule to evaluate if your
 * Amazon Web Services resources comply with your desired configurations. For information on how many Config rules you can have per account,
 * see
 * **Service Limits**
 * in the *Config Developer Guide*.
 *
 * There are two types of rules: *Config Managed Rules* and *Config Custom Rules*.
 * You can use `PutConfigRule` to create both Config Managed Rules and Config Custom Rules.
 *
 * Config Managed Rules are predefined,
 * customizable rules created by Config. For a list of managed rules, see
 * List of Config
 * Managed Rules. If you are adding an Config managed rule, you must specify the
 * rule's identifier for the `SourceIdentifier` key.
 *
 * Config Custom Rules are rules that you create from scratch. There are two ways to create Config custom rules: with Lambda functions
 * ( Lambda Developer Guide) and with Guard (Guard GitHub
 * Repository), a policy-as-code language.
 *
 * Config custom rules created with Lambda
 * are called *Config Custom Lambda Rules* and Config custom rules created with
 * Guard are called *Config Custom Policy Rules*.
 *
 * If you are adding a new Config Custom Lambda rule,
 * you first need to create an Lambda function that the rule invokes to evaluate
 * your resources. When you use `PutConfigRule` to add a Custom Lambda rule to Config, you must specify the Amazon Resource
 * Name (ARN) that Lambda assigns to the function. You specify the ARN
 * in the `SourceIdentifier` key. This key is part of the
 * `Source` object, which is part of the
 * `ConfigRule` object.
 *
 * For any new Config rule that you add, specify the
 * `ConfigRuleName` in the `ConfigRule`
 * object. Do not specify the `ConfigRuleArn` or the
 * `ConfigRuleId`. These values are generated by Config for new rules.
 *
 * If you are updating a rule that you added previously, you can
 * specify the rule by `ConfigRuleName`,
 * `ConfigRuleId`, or `ConfigRuleArn` in the
 * `ConfigRule` data type that you use in this
 * request.
 *
 * For more information about developing and using Config
 * rules, see Evaluating Resources with Config Rules
 * in the *Config Developer Guide*.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * `PutConfigRule` is an idempotent API. Subsequent requests won’t create a duplicate resource if one was already created. If a following request has different `tags` values,
 * Config will ignore these differences and treat it as an idempotent request of the previous. In this case, `tags` will not be updated, even if they are different.
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export declare const putConfigRule: API.OperationMethod<PutConfigRuleRequest, PutConfigRuleResponse, PutConfigRuleError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationAggregatorError = InvalidParameterValueException | InvalidRoleException | LimitExceededException | NoAvailableOrganizationException | OrganizationAccessDeniedException | OrganizationAllFeaturesNotEnabledException | CommonErrors;
/**
 * Creates and updates the configuration aggregator with the
 * selected source accounts and regions. The source account can be
 * individual account(s) or an organization.
 *
 * `accountIds` that are passed will be replaced with existing accounts.
 * If you want to add additional accounts into the aggregator, call `DescribeConfigurationAggregators` to get the previous accounts and then append new ones.
 *
 * Config should be enabled in source accounts and regions
 * you want to aggregate.
 *
 * If your source type is an organization, you must be signed in to the management account or a registered delegated administrator and all the features must be enabled in your organization.
 * If the caller is a management account, Config calls `EnableAwsServiceAccess` API to enable integration between Config and Organizations.
 * If the caller is a registered delegated administrator, Config calls `ListDelegatedAdministrators` API to verify whether the caller is a valid delegated administrator.
 *
 * To register a delegated administrator, see Register a Delegated Administrator in the *Config developer guide*.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * `PutConfigurationAggregator` is an idempotent API. Subsequent requests won’t create a duplicate resource if one was already created. If a following request has different `tags` values,
 * Config will ignore these differences and treat it as an idempotent request of the previous. In this case, `tags` will not be updated, even if they are different.
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export declare const putConfigurationAggregator: API.OperationMethod<PutConfigurationAggregatorRequest, PutConfigurationAggregatorResponse, PutConfigurationAggregatorError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationRecorderError = InvalidConfigurationRecorderNameException | InvalidRecordingGroupException | InvalidRoleException | MaxNumberOfConfigurationRecordersExceededException | UnmodifiableEntityException | ValidationException | CommonErrors;
/**
 * Creates or updates the customer managed configuration recorder.
 *
 * You can use this operation to create a new customer managed configuration recorder or to update the `roleARN` and the `recordingGroup` for an existing customer managed configuration recorder.
 *
 * To start the customer managed configuration recorder and begin recording configuration changes for the resource types you specify,
 * use the StartConfigurationRecorder operation.
 *
 * For more information, see
 * **Working with the Configuration Recorder**
 * in the *Config Developer Guide*.
 *
 * **One customer managed configuration recorder per account per Region**
 *
 * You can create only one customer managed configuration recorder for each account for each Amazon Web Services Region.
 *
 * **Default is to record all supported resource types, excluding the global IAM resource types**
 *
 * If you have not specified values for the `recordingGroup` field, the default for the customer managed configuration recorder is to record all supported resource
 * types, excluding the global IAM resource types: `AWS::IAM::Group`, `AWS::IAM::Policy`, `AWS::IAM::Role`, and `AWS::IAM::User`.
 *
 * **Tags are added at creation and cannot be updated**
 *
 * `PutConfigurationRecorder` is an idempotent API. Subsequent requests won’t create a duplicate resource if one was already created. If a following request has different tags values,
 * Config will ignore these differences and treat it as an idempotent request of the previous. In this case, tags will not be updated, even if they are different.
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export declare const putConfigurationRecorder: API.OperationMethod<PutConfigurationRecorderRequest, PutConfigurationRecorderResponse, PutConfigurationRecorderError, Credentials | HttpClient.HttpClient>;
export type PutConformancePackError = ConformancePackTemplateValidationException | InsufficientPermissionsException | InvalidParameterValueException | MaxNumberOfConformancePacksExceededException | ResourceInUseException | CommonErrors;
/**
 * Creates or updates a conformance pack. A conformance pack is a collection of Config rules that can be easily deployed in an account and a region and across an organization.
 * For information on how many conformance packs you can have per account,
 * see
 * **Service Limits**
 * in the *Config Developer Guide*.
 *
 * When you use `PutConformancePack` to deploy conformance packs in your account,
 * the operation can create Config rules and remediation actions without
 * requiring `config:PutConfigRule` or
 * `config:PutRemediationConfigurations` permissions in your account IAM
 * policies.
 *
 * This API uses the `AWSServiceRoleForConfigConforms` service-linked role in your
 * account to create conformance pack resources. This service-linked role includes the
 * permissions to create Config rules and remediation configurations, even
 * if your account IAM policies explicitly deny these actions.
 *
 * This API creates a service-linked role `AWSServiceRoleForConfigConforms` in your account.
 * The service-linked role is created only when the role does not exist in your account.
 *
 * You must specify only one of the follow parameters: `TemplateS3Uri`, `TemplateBody` or `TemplateSSMDocumentDetails`.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * `PutConformancePack` is an idempotent API. Subsequent requests won't create a duplicate resource if one was already created. If a following request has different `tags` values,
 * Config will ignore these differences and treat it as an idempotent request of the previous. In this case, `tags` will not be updated, even if they are different.
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export declare const putConformancePack: API.OperationMethod<PutConformancePackRequest, PutConformancePackResponse, PutConformancePackError, Credentials | HttpClient.HttpClient>;
export type PutConnectorError = ConflictException | InsufficientPermissionsException | MaxNumberOfConnectorsExceededException | ValidationException | CommonErrors;
/**
 * Creates a connector that specifies the connection between a third-party cloud service provider and Config.
 *
 * A connector is required to create a service-linked configuration recorder for a third-party cloud service provider using the PutThirdPartyServiceLinkedConfigurationRecorder operation.
 *
 * This API creates a service-linked role `AWSServiceRoleForConfigThirdParty` in your account. The service-linked role is created only when the role does not exist in your account.
 *
 * **Connectors cannot be updated**
 *
 * To update the connector configuration, you must delete all associated configuration recorders, delete the connector, and recreate it with the updated configuration.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export declare const putConnector: API.OperationMethod<PutConnectorRequest, PutConnectorResponse, PutConnectorError, Credentials | HttpClient.HttpClient>;
export type PutDeliveryChannelError = InsufficientDeliveryPolicyException | InvalidDeliveryChannelNameException | InvalidS3KeyPrefixException | InvalidS3KmsKeyArnException | InvalidSNSTopicARNException | MaxNumberOfDeliveryChannelsExceededException | NoAvailableConfigurationRecorderException | NoSuchBucketException | CommonErrors;
/**
 * Creates or updates a delivery channel to deliver configuration
 * information and other compliance information.
 *
 * You can use this operation to create a new delivery channel or to update the Amazon S3 bucket and the
 * Amazon SNS topic of an existing delivery channel.
 *
 * For more information, see
 * **Working with the Delivery Channel**
 * in the *Config Developer Guide.*
 *
 * **One delivery channel per account per Region**
 *
 * You can have only one delivery channel for each account for each Amazon Web Services Region.
 */
export declare const putDeliveryChannel: API.OperationMethod<PutDeliveryChannelRequest, PutDeliveryChannelResponse, PutDeliveryChannelError, Credentials | HttpClient.HttpClient>;
export type PutEvaluationsError = InvalidParameterValueException | InvalidResultTokenException | NoSuchConfigRuleException | CommonErrors;
/**
 * Used by an Lambda function to deliver evaluation results to
 * Config. This operation is required in every Lambda function
 * that is invoked by an Config rule.
 */
export declare const putEvaluations: API.OperationMethod<PutEvaluationsRequest, PutEvaluationsResponse, PutEvaluationsError, Credentials | HttpClient.HttpClient>;
export type PutExternalEvaluationError = InvalidParameterValueException | NoSuchConfigRuleException | CommonErrors;
/**
 * Add or updates the evaluations for process checks.
 * This API checks if the rule is a process check when the name of the Config rule is provided.
 */
export declare const putExternalEvaluation: API.OperationMethod<PutExternalEvaluationRequest, PutExternalEvaluationResponse, PutExternalEvaluationError, Credentials | HttpClient.HttpClient>;
export type PutOrganizationConfigRuleError = InsufficientPermissionsException | InvalidParameterValueException | MaxNumberOfOrganizationConfigRulesExceededException | NoAvailableOrganizationException | OrganizationAccessDeniedException | OrganizationAllFeaturesNotEnabledException | ResourceInUseException | ValidationException | CommonErrors;
/**
 * Adds or updates an Config rule for your entire organization to evaluate if your Amazon Web Services resources comply with your
 * desired configurations. For information on how many organization Config rules you can have per account,
 * see
 * **Service Limits**
 * in the *Config Developer Guide*.
 *
 * Only a management account and a delegated administrator can create or update an organization Config rule.
 * When calling this API with a delegated administrator, you must ensure Organizations
 * `ListDelegatedAdministrator` permissions are added. An organization can have up to 3 delegated administrators.
 *
 * This API enables organization service access through the `EnableAWSServiceAccess` action and creates a service-linked
 * role `AWSServiceRoleForConfigMultiAccountSetup` in the management or delegated administrator account of your organization.
 * The service-linked role is created only when the role does not exist in the caller account.
 * Config verifies the existence of role with `GetRole` action.
 *
 * To use this API with delegated administrator, register a delegated administrator by calling Amazon Web Services Organization
 * `register-delegated-administrator` for `config-multiaccountsetup.amazonaws.com`.
 *
 * There are two types of rules: *Config Managed Rules* and *Config Custom Rules*.
 * You can use `PutOrganizationConfigRule` to create both Config Managed Rules and Config Custom Rules.
 *
 * Config Managed Rules are predefined,
 * customizable rules created by Config. For a list of managed rules, see
 * List of Config
 * Managed Rules. If you are adding an Config managed rule, you must specify the rule's identifier for the `RuleIdentifier` key.
 *
 * Config Custom Rules are rules that you create from scratch. There are two ways to create Config custom rules: with Lambda functions
 * ( Lambda Developer Guide) and with Guard (Guard GitHub
 * Repository), a policy-as-code language.
 *
 * Config custom rules created with Lambda
 * are called *Config Custom Lambda Rules* and Config custom rules created with
 * Guard are called *Config Custom Policy Rules*.
 *
 * If you are adding a new Config Custom Lambda rule, you first need to create an Lambda function in the management account or a delegated
 * administrator that the rule invokes to evaluate your resources. You also need to create an IAM role in the managed account that can be assumed by the Lambda function.
 * When you use `PutOrganizationConfigRule` to add a Custom Lambda rule to Config, you must
 * specify the Amazon Resource Name (ARN) that Lambda assigns to the function.
 *
 * Prerequisite: Ensure you call `EnableAllFeatures` API to enable all features in an organization.
 *
 * Make sure to specify one of either `OrganizationCustomPolicyRuleMetadata` for Custom Policy rules, `OrganizationCustomRuleMetadata` for Custom Lambda rules, or `OrganizationManagedRuleMetadata` for managed rules.
 */
export declare const putOrganizationConfigRule: API.OperationMethod<PutOrganizationConfigRuleRequest, PutOrganizationConfigRuleResponse, PutOrganizationConfigRuleError, Credentials | HttpClient.HttpClient>;
export type PutOrganizationConformancePackError = InsufficientPermissionsException | MaxNumberOfOrganizationConformancePacksExceededException | NoAvailableOrganizationException | OrganizationAccessDeniedException | OrganizationAllFeaturesNotEnabledException | OrganizationConformancePackTemplateValidationException | ResourceInUseException | ValidationException | CommonErrors;
/**
 * Deploys conformance packs across member accounts in an Amazon Web Services Organization. For information on how many organization conformance packs and how many Config rules you can have per account,
 * see
 * **Service Limits**
 * in the *Config Developer Guide*.
 *
 * Only a management account and a delegated administrator can call this API.
 * When calling this API with a delegated administrator, you must ensure Organizations
 * `ListDelegatedAdministrator` permissions are added. An organization can have up to 3 delegated administrators.
 *
 * When you use `PutOrganizationConformancePack` to deploy conformance packs across
 * member accounts, the operation can create Config rules and remediation
 * actions without requiring `config:PutConfigRule` or
 * `config:PutRemediationConfigurations` permissions in member account
 * IAM policies.
 *
 * This API uses the `AWSServiceRoleForConfigConforms` service-linked role in each
 * member account to create conformance pack resources. This service-linked role
 * includes the permissions to create Config rules and remediation
 * configurations, even if member account IAM policies explicitly deny these
 * actions.
 *
 * This API enables organization service access for `config-multiaccountsetup.amazonaws.com`
 * through the `EnableAWSServiceAccess` action and creates a
 * service-linked role `AWSServiceRoleForConfigMultiAccountSetup` in the management or delegated administrator account of your organization.
 * The service-linked role is created only when the role does not exist in the caller account.
 * To use this API with delegated administrator, register a delegated administrator by calling Amazon Web Services Organization
 * `register-delegate-admin` for `config-multiaccountsetup.amazonaws.com`.
 *
 * Prerequisite: Ensure you call `EnableAllFeatures` API to enable all features in an organization.
 *
 * You must specify either the `TemplateS3Uri` or the `TemplateBody` parameter, but not both.
 * If you provide both Config uses the `TemplateS3Uri` parameter and ignores the `TemplateBody` parameter.
 *
 * Config sets the state of a conformance pack to CREATE_IN_PROGRESS and UPDATE_IN_PROGRESS until the conformance pack is created or updated.
 * You cannot update a conformance pack while it is in this state.
 */
export declare const putOrganizationConformancePack: API.OperationMethod<PutOrganizationConformancePackRequest, PutOrganizationConformancePackResponse, PutOrganizationConformancePackError, Credentials | HttpClient.HttpClient>;
export type PutRemediationConfigurationsError = InsufficientPermissionsException | InvalidParameterValueException | CommonErrors;
/**
 * Adds or updates the remediation configuration with a specific Config rule with the
 * selected target or action.
 * The API creates the `RemediationConfiguration` object for the Config rule.
 * The Config rule must already exist for you to add a remediation configuration.
 * The target (SSM document) must exist and have permissions to use the target.
 *
 * **Be aware of backward incompatible changes**
 *
 * If you make backward incompatible changes to the SSM document,
 * you must call this again to ensure the remediations can run.
 *
 * This API does not support adding remediation configurations for service-linked Config Rules such as Organization Config rules,
 * the rules deployed by conformance packs, and rules deployed by Amazon Web Services Security Hub.
 *
 * **Required fields**
 *
 * For manual remediation configuration, you need to provide a value for `automationAssumeRole` or use a value in the `assumeRole`field to remediate your resources. The SSM automation document can use either as long as it maps to a valid parameter.
 *
 * However, for automatic remediation configuration, the only valid `assumeRole` field value is `AutomationAssumeRole` and you need to provide a value for `AutomationAssumeRole` to remediate your resources.
 *
 * **Auto remediation can be initiated even for compliant resources**
 *
 * If you enable auto remediation for a specific Config rule using the PutRemediationConfigurations API or the Config console,
 * it initiates the remediation process for all non-compliant resources for that specific rule.
 * The auto remediation process relies on the compliance data snapshot which is captured on a periodic basis.
 * Any non-compliant resource that is updated between the snapshot schedule will continue to be remediated based on the last known compliance data snapshot.
 *
 * This means that in some cases auto remediation can be initiated even for compliant resources, since the bootstrap processor uses a database that can have stale evaluation results based on the last known compliance data snapshot.
 */
export declare const putRemediationConfigurations: API.OperationMethod<PutRemediationConfigurationsRequest, PutRemediationConfigurationsResponse, PutRemediationConfigurationsError, Credentials | HttpClient.HttpClient>;
export type PutRemediationExceptionsError = InsufficientPermissionsException | InvalidParameterValueException | CommonErrors;
/**
 * A remediation exception is when a specified resource is no longer considered for auto-remediation.
 * This API adds a new exception or updates an existing exception for a specified resource with a specified Config rule.
 *
 * **Exceptions block auto remediation**
 *
 * Config generates a remediation exception when a problem occurs running a remediation action for a specified resource.
 * Remediation exceptions blocks auto-remediation until the exception is cleared.
 *
 * **Manual remediation is recommended when placing an exception**
 *
 * When placing an exception on an Amazon Web Services resource, it is recommended that remediation is set as manual remediation until
 * the given Config rule for the specified resource evaluates the resource as `NON_COMPLIANT`.
 * Once the resource has been evaluated as `NON_COMPLIANT`, you can add remediation exceptions and change the remediation type back from Manual to Auto if you want to use auto-remediation.
 * Otherwise, using auto-remediation before a `NON_COMPLIANT` evaluation result can delete resources before the exception is applied.
 *
 * **Exceptions can only be performed on non-compliant resources**
 *
 * Placing an exception can only be performed on resources that are `NON_COMPLIANT`.
 * If you use this API for `COMPLIANT` resources or resources that are `NOT_APPLICABLE`, a remediation exception will not be generated.
 * For more information on the conditions that initiate the possible Config evaluation results,
 * see Concepts | Config Rules in the *Config Developer Guide*.
 *
 * **Exceptions cannot be placed on service-linked remediation actions**
 *
 * You cannot place an exception on service-linked remediation actions, such as remediation actions put by an organizational conformance pack.
 *
 * **Auto remediation can be initiated even for compliant resources**
 *
 * If you enable auto remediation for a specific Config rule using the PutRemediationConfigurations API or the Config console,
 * it initiates the remediation process for all non-compliant resources for that specific rule.
 * The auto remediation process relies on the compliance data snapshot which is captured on a periodic basis.
 * Any non-compliant resource that is updated between the snapshot schedule will continue to be remediated based on the last known compliance data snapshot.
 *
 * This means that in some cases auto remediation can be initiated even for compliant resources, since the bootstrap processor uses a database that can have stale evaluation results based on the last known compliance data snapshot.
 */
export declare const putRemediationExceptions: API.OperationMethod<PutRemediationExceptionsRequest, PutRemediationExceptionsResponse, PutRemediationExceptionsError, Credentials | HttpClient.HttpClient>;
export type PutResourceConfigError = InsufficientPermissionsException | MaxActiveResourcesExceededException | NoRunningConfigurationRecorderException | ValidationException | CommonErrors;
/**
 * Records the configuration state for the resource provided in the request.
 *
 * The configuration state of a resource is represented in Config as Configuration Items.
 * Once this API records the configuration item, you can retrieve the list of configuration items for the custom resource type using existing Config APIs.
 *
 * The custom resource type must be registered with CloudFormation. This API accepts the configuration item registered with CloudFormation.
 *
 * When you call this API, Config only stores configuration state of the resource provided in the request. This API does not change or remediate the configuration of the resource.
 *
 * Write-only schema properites are not recorded as part of the published configuration item.
 */
export declare const putResourceConfig: API.OperationMethod<PutResourceConfigRequest, PutResourceConfigResponse, PutResourceConfigError, Credentials | HttpClient.HttpClient>;
export type PutRetentionConfigurationError = InvalidParameterValueException | MaxNumberOfRetentionConfigurationsExceededException | CommonErrors;
/**
 * Creates and updates the retention configuration with details
 * about retention period (number of days) that Config stores your
 * historical information. The API creates the
 * `RetentionConfiguration` object and names the object
 * as **default**. When you have a
 * `RetentionConfiguration` object named **default**, calling the API modifies the
 * default object.
 *
 * Currently, Config supports only one retention
 * configuration per region in your account.
 */
export declare const putRetentionConfiguration: API.OperationMethod<PutRetentionConfigurationRequest, PutRetentionConfigurationResponse, PutRetentionConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutServiceLinkedConfigurationRecorderError = ConflictException | InsufficientPermissionsException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Creates a service-linked configuration recorder that is linked to a specific Amazon Web Services service based on the `ServicePrincipal` you specify.
 *
 * The configuration recorder's `name`, `recordingGroup`, `recordingMode`, and `recordingScope` is set by the service that is linked to the configuration recorder.
 *
 * For more information and a list of supported services/service principals, see
 * **Working with the Configuration Recorder**
 * in the *Config Developer Guide*.
 *
 * This API creates a service-linked role `AWSServiceRoleForConfig` in your account. The service-linked role is created only when the role does not exist in your account.
 *
 * **The recording scope determines if you receive configuration items**
 *
 * The recording scope is set by the service that is linked to the configuration recorder and determines whether you receive configuration items (CIs) in the delivery channel. If the recording scope is internal, you will not receive CIs in the delivery channel.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export declare const putServiceLinkedConfigurationRecorder: API.OperationMethod<PutServiceLinkedConfigurationRecorderRequest, PutServiceLinkedConfigurationRecorderResponse, PutServiceLinkedConfigurationRecorderError, Credentials | HttpClient.HttpClient>;
export type PutStoredQueryError = ResourceConcurrentModificationException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Saves a new query or updates an existing saved query. The `QueryName` must be unique for a single Amazon Web Services account and a single Amazon Web Services Region.
 * You can create upto 300 queries in a single Amazon Web Services account and a single Amazon Web Services Region.
 *
 * **Tags are added at creation and cannot be updated**
 *
 * `PutStoredQuery` is an idempotent API. Subsequent requests won’t create a duplicate resource if one was already created. If a following request has different `tags` values,
 * Config will ignore these differences and treat it as an idempotent request of the previous. In this case, `tags` will not be updated, even if they are different.
 */
export declare const putStoredQuery: API.OperationMethod<PutStoredQueryRequest, PutStoredQueryResponse, PutStoredQueryError, Credentials | HttpClient.HttpClient>;
export type PutThirdPartyServiceLinkedConfigurationRecorderError = ConflictException | InsufficientPermissionsException | ValidationException | CommonErrors;
/**
 * Creates or updates a service-linked configuration recorder that is linked to a third-party cloud service provider based on the `ConnectorArn` you specify.
 *
 * The configuration recorder's `name`, `recordingGroup`, `recordingMode`, and `recordingScope` is set by the service that is linked to the configuration recorder.
 *
 * If a service-linked configuration recorder already exists for the specified service principal and connector, calling this operation again updates the `ScopeConfiguration`.
 *
 * **This operation can only be called by the Amazon Web Services service linked to the configuration recorder**
 *
 * Customers cannot call this operation directly. Only the linked Amazon Web Services service can create or update the service-linked configuration recorder.
 *
 * **Tags are added at creation and cannot be updated with this operation**
 *
 * Use TagResource and UntagResource to update tags after creation.
 */
export declare const putThirdPartyServiceLinkedConfigurationRecorder: API.OperationMethod<PutThirdPartyServiceLinkedConfigurationRecorderRequest, PutThirdPartyServiceLinkedConfigurationRecorderResponse, PutThirdPartyServiceLinkedConfigurationRecorderError, Credentials | HttpClient.HttpClient>;
export type SelectAggregateResourceConfigError = InvalidExpressionException | InvalidLimitException | InvalidNextTokenException | NoSuchConfigurationAggregatorException | CommonErrors;
/**
 * Accepts a structured query language (SQL) SELECT command and an aggregator to query configuration state of Amazon Web Services resources across multiple accounts and regions,
 * performs the corresponding search, and returns resource configurations matching the properties.
 *
 * For more information about query components, see the
 *
 * **Query Components**
 * section in the *Config Developer Guide*.
 *
 * If you run an aggregation query (i.e., using `GROUP BY` or using aggregate functions such as `COUNT`; e.g., `SELECT resourceId, COUNT(*) WHERE resourceType = 'AWS::IAM::Role' GROUP BY resourceId`)
 * and do not specify the `MaxResults` or the `Limit` query parameters, the default page size is set to 500.
 *
 * If you run a non-aggregation query (i.e., not using `GROUP BY` or aggregate function; e.g., `SELECT * WHERE resourceType = 'AWS::IAM::Role'`)
 * and do not specify the `MaxResults` or the `Limit` query parameters, the default page size is set to 25.
 */
export declare const selectAggregateResourceConfig: API.PaginatedOperationMethod<SelectAggregateResourceConfigRequest, SelectAggregateResourceConfigResponse, SelectAggregateResourceConfigError, Credentials | HttpClient.HttpClient, string>;
export type SelectResourceConfigError = InvalidExpressionException | InvalidLimitException | InvalidNextTokenException | CommonErrors;
/**
 * Accepts a structured query language (SQL) `SELECT` command, performs the corresponding search, and returns resource configurations matching the properties.
 *
 * For more information about query components, see the
 *
 * **Query Components**
 * section in the *Config Developer Guide*.
 */
export declare const selectResourceConfig: API.PaginatedOperationMethod<SelectResourceConfigRequest, SelectResourceConfigResponse, SelectResourceConfigError, Credentials | HttpClient.HttpClient, string>;
export type StartConfigRulesEvaluationError = InvalidParameterValueException | LimitExceededException | NoSuchConfigRuleException | ResourceInUseException | CommonErrors;
/**
 * Runs an on-demand evaluation for the specified Config rules
 * against the last known configuration state of the resources. Use
 * `StartConfigRulesEvaluation` when you want to test
 * that a rule you updated is working as expected.
 * `StartConfigRulesEvaluation` does not re-record the
 * latest configuration state for your resources. It re-runs an
 * evaluation against the last known state of your resources.
 *
 * You can specify up to 25 Config rules per request.
 *
 * An existing `StartConfigRulesEvaluation` call for
 * the specified rules must complete before you can call the API again.
 * If you chose to have Config stream to an Amazon SNS topic, you
 * will receive a `ConfigRuleEvaluationStarted` notification
 * when the evaluation starts.
 *
 * You don't need to call the
 * `StartConfigRulesEvaluation` API to run an
 * evaluation for a new rule. When you create a rule, Config
 * evaluates your resources against the rule automatically.
 *
 * The `StartConfigRulesEvaluation` API is useful if
 * you want to run on-demand evaluations, such as the following
 * example:
 *
 * - You have a custom rule that evaluates your IAM
 * resources every 24 hours.
 *
 * - You update your Lambda function to add additional
 * conditions to your rule.
 *
 * - Instead of waiting for the next periodic evaluation,
 * you call the `StartConfigRulesEvaluation`
 * API.
 *
 * - Config invokes your Lambda function and evaluates
 * your IAM resources.
 *
 * - Your custom rule will still run periodic evaluations
 * every 24 hours.
 */
export declare const startConfigRulesEvaluation: API.OperationMethod<StartConfigRulesEvaluationRequest, StartConfigRulesEvaluationResponse, StartConfigRulesEvaluationError, Credentials | HttpClient.HttpClient>;
export type StartConfigurationRecorderError = NoAvailableDeliveryChannelException | NoSuchConfigurationRecorderException | UnmodifiableEntityException | CommonErrors;
/**
 * Starts the customer managed configuration recorder. The customer managed configuration recorder will begin recording configuration changes for the resource types you specify.
 *
 * You must have created a delivery channel to
 * successfully start the customer managed configuration recorder. You can use the PutDeliveryChannel operation to create a delivery channel.
 */
export declare const startConfigurationRecorder: API.OperationMethod<StartConfigurationRecorderRequest, StartConfigurationRecorderResponse, StartConfigurationRecorderError, Credentials | HttpClient.HttpClient>;
export type StartRemediationExecutionError = InsufficientPermissionsException | InvalidParameterValueException | NoSuchRemediationConfigurationException | CommonErrors;
/**
 * Runs an on-demand remediation for the specified Config rules against the last known remediation configuration. It runs an execution against the current state of your resources. Remediation execution is asynchronous.
 *
 * You can specify up to 100 resource keys per request. An existing StartRemediationExecution call for the specified resource keys must complete before you can call the API again.
 */
export declare const startRemediationExecution: API.OperationMethod<StartRemediationExecutionRequest, StartRemediationExecutionResponse, StartRemediationExecutionError, Credentials | HttpClient.HttpClient>;
export type StartResourceEvaluationError = IdempotentParameterMismatch | InvalidParameterValueException | CommonErrors;
/**
 * Runs an on-demand evaluation for the specified resource to determine whether the resource details will comply with configured Config rules.
 * You can also use it for evaluation purposes. Config recommends using an evaluation context. It runs an execution against the resource details with all
 * of the Config rules in your account that match with the specified proactive mode and resource type.
 *
 * Ensure you have the `cloudformation:DescribeType` role setup to validate the resource type schema.
 *
 * You can find the
 * Resource type schema in "*Amazon Web Services public extensions*" within the CloudFormation registry or with the following CLI commmand:
 * `aws cloudformation describe-type --type-name "AWS::S3::Bucket" --type RESOURCE`.
 *
 * For more information, see Managing extensions through the CloudFormation registry
 * and Amazon Web Services resource and property types reference in the CloudFormation User Guide.
 */
export declare const startResourceEvaluation: API.OperationMethod<StartResourceEvaluationRequest, StartResourceEvaluationResponse, StartResourceEvaluationError, Credentials | HttpClient.HttpClient>;
export type StopConfigurationRecorderError = NoSuchConfigurationRecorderException | UnmodifiableEntityException | CommonErrors;
/**
 * Stops the customer managed configuration recorder. The customer managed configuration recorder will stop recording configuration changes for the resource types you have specified.
 */
export declare const stopConfigurationRecorder: API.OperationMethod<StopConfigurationRecorderRequest, StopConfigurationRecorderResponse, StopConfigurationRecorderError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `ResourceArn`. If existing tags on a resource are not specified in the request parameters, they are not changed.
 * If existing tags are specified, however, then their values will be updated. When a resource is deleted, the tags associated with that resource are deleted as well.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=config-service.d.ts.map