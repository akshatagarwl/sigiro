import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalFailureException_base: S.Class<InternalFailureException, S.TaggedStruct<"InternalFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.Class<ResourceAlreadyExistsException, S.TaggedStruct<"ResourceAlreadyExistsException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceArn: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnsupportedOperationException_base: S.Class<UnsupportedOperationException, S.TaggedStruct<"UnsupportedOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export type AlarmModelName = string;
export type AlarmModelDescription = string;
export type AmazonResourceName = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export type AttributeJsonPath = string;
export type Severity = number;
export type InputProperty = string;
export type ComparisonOperator = "GREATER" | "GREATER_OR_EQUAL" | "LESS" | "LESS_OR_EQUAL" | "EQUAL" | "NOT_EQUAL" | (string & {});
export declare const ComparisonOperator: any;
export type Threshold = string;
export interface SimpleRule {
    inputProperty: string;
    comparisonOperator: ComparisonOperator;
    threshold: string;
}
export declare const SimpleRule: S.Schema<SimpleRule>;
export interface AlarmRule {
    simpleRule?: SimpleRule;
}
export declare const AlarmRule: S.Schema<AlarmRule>;
export type ContentExpression = string;
export type PayloadType = "STRING" | "JSON" | (string & {});
export declare const PayloadType: any;
export interface Payload {
    contentExpression: string;
    type: PayloadType;
}
export declare const Payload: S.Schema<Payload>;
export interface LambdaAction {
    functionArn: string;
    payload?: Payload;
}
export declare const LambdaAction: S.Schema<LambdaAction>;
export interface NotificationTargetActions {
    lambdaAction?: LambdaAction;
}
export declare const NotificationTargetActions: S.Schema<NotificationTargetActions>;
export type SMSSenderId = string;
export type NotificationAdditionalMessage = string;
export type IdentityStoreId = string;
export type SSOReferenceId = string;
export interface SSOIdentity {
    identityStoreId: string;
    userId?: string;
}
export declare const SSOIdentity: S.Schema<SSOIdentity>;
export interface RecipientDetail {
    ssoIdentity?: SSOIdentity;
}
export declare const RecipientDetail: S.Schema<RecipientDetail>;
export type RecipientDetails = RecipientDetail[];
export declare const RecipientDetails: any;
export interface SMSConfiguration {
    senderId?: string;
    additionalMessage?: string;
    recipients: RecipientDetail[];
}
export declare const SMSConfiguration: S.Schema<SMSConfiguration>;
export type SMSConfigurations = SMSConfiguration[];
export declare const SMSConfigurations: any;
export type FromEmail = string;
export type EmailSubject = string;
export interface EmailContent {
    subject?: string;
    additionalMessage?: string;
}
export declare const EmailContent: S.Schema<EmailContent>;
export interface EmailRecipients {
    to?: RecipientDetail[];
}
export declare const EmailRecipients: S.Schema<EmailRecipients>;
export interface EmailConfiguration {
    from: string;
    content?: EmailContent;
    recipients: EmailRecipients;
}
export declare const EmailConfiguration: S.Schema<EmailConfiguration>;
export type EmailConfigurations = EmailConfiguration[];
export declare const EmailConfigurations: any;
export interface NotificationAction {
    action: NotificationTargetActions;
    smsConfigurations?: SMSConfiguration[];
    emailConfigurations?: EmailConfiguration[];
}
export declare const NotificationAction: S.Schema<NotificationAction>;
export type NotificationActions = NotificationAction[];
export declare const NotificationActions: any;
export interface AlarmNotification {
    notificationActions?: NotificationAction[];
}
export declare const AlarmNotification: S.Schema<AlarmNotification>;
export interface SNSTopicPublishAction {
    targetArn: string;
    payload?: Payload;
}
export declare const SNSTopicPublishAction: S.Schema<SNSTopicPublishAction>;
export type MQTTTopic = string;
export interface IotTopicPublishAction {
    mqttTopic: string;
    payload?: Payload;
}
export declare const IotTopicPublishAction: S.Schema<IotTopicPublishAction>;
export type InputName = string;
export interface IotEventsAction {
    inputName: string;
    payload?: Payload;
}
export declare const IotEventsAction: S.Schema<IotEventsAction>;
export type QueueUrl = string;
export type UseBase64 = boolean;
export interface SqsAction {
    queueUrl: string;
    useBase64?: boolean;
    payload?: Payload;
}
export declare const SqsAction: S.Schema<SqsAction>;
export type DeliveryStreamName = string;
export type FirehoseSeparator = string;
export interface FirehoseAction {
    deliveryStreamName: string;
    separator?: string;
    payload?: Payload;
}
export declare const FirehoseAction: S.Schema<FirehoseAction>;
export type DynamoKeyType = string;
export type DynamoKeyField = string;
export type DynamoKeyValue = string;
export type DynamoOperation = string;
export type DynamoTableName = string;
export interface DynamoDBAction {
    hashKeyType?: string;
    hashKeyField: string;
    hashKeyValue: string;
    rangeKeyType?: string;
    rangeKeyField?: string;
    rangeKeyValue?: string;
    operation?: string;
    payloadField?: string;
    tableName: string;
    payload?: Payload;
}
export declare const DynamoDBAction: S.Schema<DynamoDBAction>;
export interface DynamoDBv2Action {
    tableName: string;
    payload?: Payload;
}
export declare const DynamoDBv2Action: S.Schema<DynamoDBv2Action>;
export type AssetPropertyEntryId = string;
export type AssetId = string;
export type AssetPropertyId = string;
export type AssetPropertyAlias = string;
export type AssetPropertyStringValue = string;
export type AssetPropertyIntegerValue = string;
export type AssetPropertyDoubleValue = string;
export type AssetPropertyBooleanValue = string;
export interface AssetPropertyVariant {
    stringValue?: string;
    integerValue?: string;
    doubleValue?: string;
    booleanValue?: string;
}
export declare const AssetPropertyVariant: S.Schema<AssetPropertyVariant>;
export type AssetPropertyTimeInSeconds = string;
export type AssetPropertyOffsetInNanos = string;
export interface AssetPropertyTimestamp {
    timeInSeconds: string;
    offsetInNanos?: string;
}
export declare const AssetPropertyTimestamp: S.Schema<AssetPropertyTimestamp>;
export type AssetPropertyQuality = string;
export interface AssetPropertyValue {
    value?: AssetPropertyVariant;
    timestamp?: AssetPropertyTimestamp;
    quality?: string;
}
export declare const AssetPropertyValue: S.Schema<AssetPropertyValue>;
export interface IotSiteWiseAction {
    entryId?: string;
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    propertyValue?: AssetPropertyValue;
}
export declare const IotSiteWiseAction: S.Schema<IotSiteWiseAction>;
export interface AlarmAction {
    sns?: SNSTopicPublishAction;
    iotTopicPublish?: IotTopicPublishAction;
    lambda?: LambdaAction;
    iotEvents?: IotEventsAction;
    sqs?: SqsAction;
    firehose?: FirehoseAction;
    dynamoDB?: DynamoDBAction;
    dynamoDBv2?: DynamoDBv2Action;
    iotSiteWise?: IotSiteWiseAction;
}
export declare const AlarmAction: S.Schema<AlarmAction>;
export type AlarmActions = AlarmAction[];
export declare const AlarmActions: any;
export interface AlarmEventActions {
    alarmActions?: AlarmAction[];
}
export declare const AlarmEventActions: S.Schema<AlarmEventActions>;
export type DisabledOnInitialization = boolean;
export interface InitializationConfiguration {
    disabledOnInitialization: boolean;
}
export declare const InitializationConfiguration: S.Schema<InitializationConfiguration>;
export type AcknowledgeFlowEnabled = boolean;
export interface AcknowledgeFlow {
    enabled: boolean;
}
export declare const AcknowledgeFlow: S.Schema<AcknowledgeFlow>;
export interface AlarmCapabilities {
    initializationConfiguration?: InitializationConfiguration;
    acknowledgeFlow?: AcknowledgeFlow;
}
export declare const AlarmCapabilities: S.Schema<AlarmCapabilities>;
export interface CreateAlarmModelRequest {
    alarmModelName: string;
    alarmModelDescription?: string;
    roleArn: string;
    tags?: Tag[];
    key?: string;
    severity?: number;
    alarmRule: AlarmRule;
    alarmNotification?: AlarmNotification;
    alarmEventActions?: AlarmEventActions;
    alarmCapabilities?: AlarmCapabilities;
}
export declare const CreateAlarmModelRequest: S.Schema<CreateAlarmModelRequest>;
export type AlarmModelArn = string;
export type AlarmModelVersion = string;
export type AlarmModelVersionStatus = "ACTIVE" | "ACTIVATING" | "INACTIVE" | "FAILED" | (string & {});
export declare const AlarmModelVersionStatus: any;
export interface CreateAlarmModelResponse {
    creationTime?: Date;
    alarmModelArn?: string;
    alarmModelVersion?: string;
    lastUpdateTime?: Date;
    status?: AlarmModelVersionStatus;
}
export declare const CreateAlarmModelResponse: S.Schema<CreateAlarmModelResponse>;
export type DetectorModelName = string;
export type StateName = string;
export type EventName = string;
export type Condition = string;
export type VariableName = string;
export type VariableValue = string;
export interface SetVariableAction {
    variableName: string;
    value: string;
}
export declare const SetVariableAction: S.Schema<SetVariableAction>;
export type TimerName = string;
export type Seconds = number;
export interface SetTimerAction {
    timerName: string;
    seconds?: number;
    durationExpression?: string;
}
export declare const SetTimerAction: S.Schema<SetTimerAction>;
export interface ClearTimerAction {
    timerName: string;
}
export declare const ClearTimerAction: S.Schema<ClearTimerAction>;
export interface ResetTimerAction {
    timerName: string;
}
export declare const ResetTimerAction: S.Schema<ResetTimerAction>;
export interface Action {
    setVariable?: SetVariableAction;
    sns?: SNSTopicPublishAction;
    iotTopicPublish?: IotTopicPublishAction;
    setTimer?: SetTimerAction;
    clearTimer?: ClearTimerAction;
    resetTimer?: ResetTimerAction;
    lambda?: LambdaAction;
    iotEvents?: IotEventsAction;
    sqs?: SqsAction;
    firehose?: FirehoseAction;
    dynamoDB?: DynamoDBAction;
    dynamoDBv2?: DynamoDBv2Action;
    iotSiteWise?: IotSiteWiseAction;
}
export declare const Action: S.Schema<Action>;
export type Actions = Action[];
export declare const Actions: any;
export interface Event {
    eventName: string;
    condition?: string;
    actions?: Action[];
}
export declare const Event: S.Schema<Event>;
export type Events = Event[];
export declare const Events: any;
export interface TransitionEvent {
    eventName: string;
    condition: string;
    actions?: Action[];
    nextState: string;
}
export declare const TransitionEvent: S.Schema<TransitionEvent>;
export type TransitionEvents = TransitionEvent[];
export declare const TransitionEvents: any;
export interface OnInputLifecycle {
    events?: Event[];
    transitionEvents?: TransitionEvent[];
}
export declare const OnInputLifecycle: S.Schema<OnInputLifecycle>;
export interface OnEnterLifecycle {
    events?: Event[];
}
export declare const OnEnterLifecycle: S.Schema<OnEnterLifecycle>;
export interface OnExitLifecycle {
    events?: Event[];
}
export declare const OnExitLifecycle: S.Schema<OnExitLifecycle>;
export interface State {
    stateName: string;
    onInput?: OnInputLifecycle;
    onEnter?: OnEnterLifecycle;
    onExit?: OnExitLifecycle;
}
export declare const State: S.Schema<State>;
export type States = State[];
export declare const States: any;
export interface DetectorModelDefinition {
    states: State[];
    initialStateName: string;
}
export declare const DetectorModelDefinition: S.Schema<DetectorModelDefinition>;
export type DetectorModelDescription = string;
export type EvaluationMethod = "BATCH" | "SERIAL" | (string & {});
export declare const EvaluationMethod: any;
export interface CreateDetectorModelRequest {
    detectorModelName: string;
    detectorModelDefinition: DetectorModelDefinition;
    detectorModelDescription?: string;
    key?: string;
    roleArn: string;
    tags?: Tag[];
    evaluationMethod?: EvaluationMethod;
}
export declare const CreateDetectorModelRequest: S.Schema<CreateDetectorModelRequest>;
export type DetectorModelVersion = string;
export type DetectorModelArn = string;
export type DetectorModelVersionStatus = "ACTIVE" | "ACTIVATING" | "INACTIVE" | "DEPRECATED" | "DRAFT" | "PAUSED" | "FAILED" | (string & {});
export declare const DetectorModelVersionStatus: any;
export interface DetectorModelConfiguration {
    detectorModelName?: string;
    detectorModelVersion?: string;
    detectorModelDescription?: string;
    detectorModelArn?: string;
    roleArn?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    status?: DetectorModelVersionStatus;
    key?: string;
    evaluationMethod?: EvaluationMethod;
}
export declare const DetectorModelConfiguration: S.Schema<DetectorModelConfiguration>;
export interface CreateDetectorModelResponse {
    detectorModelConfiguration?: DetectorModelConfiguration;
}
export declare const CreateDetectorModelResponse: S.Schema<CreateDetectorModelResponse>;
export type InputDescription = string;
export interface Attribute {
    jsonPath: string;
}
export declare const Attribute: S.Schema<Attribute>;
export type Attributes = Attribute[];
export declare const Attributes: any;
export interface InputDefinition {
    attributes: Attribute[];
}
export declare const InputDefinition: S.Schema<InputDefinition>;
export interface CreateInputRequest {
    inputName: string;
    inputDescription?: string;
    inputDefinition: InputDefinition;
    tags?: Tag[];
}
export declare const CreateInputRequest: S.Schema<CreateInputRequest>;
export type InputArn = string;
export type InputStatus = "CREATING" | "UPDATING" | "ACTIVE" | "DELETING" | (string & {});
export declare const InputStatus: any;
export interface InputConfiguration {
    inputName: string;
    inputDescription?: string;
    inputArn: string;
    creationTime: Date;
    lastUpdateTime: Date;
    status: InputStatus;
}
export declare const InputConfiguration: S.Schema<InputConfiguration>;
export interface CreateInputResponse {
    inputConfiguration?: InputConfiguration;
}
export declare const CreateInputResponse: S.Schema<CreateInputResponse>;
export interface DeleteAlarmModelRequest {
    alarmModelName: string;
}
export declare const DeleteAlarmModelRequest: S.Schema<DeleteAlarmModelRequest>;
export interface DeleteAlarmModelResponse {
}
export declare const DeleteAlarmModelResponse: S.Schema<DeleteAlarmModelResponse>;
export interface DeleteDetectorModelRequest {
    detectorModelName: string;
}
export declare const DeleteDetectorModelRequest: S.Schema<DeleteDetectorModelRequest>;
export interface DeleteDetectorModelResponse {
}
export declare const DeleteDetectorModelResponse: S.Schema<DeleteDetectorModelResponse>;
export interface DeleteInputRequest {
    inputName: string;
}
export declare const DeleteInputRequest: S.Schema<DeleteInputRequest>;
export interface DeleteInputResponse {
}
export declare const DeleteInputResponse: S.Schema<DeleteInputResponse>;
export interface DescribeAlarmModelRequest {
    alarmModelName: string;
    alarmModelVersion?: string;
}
export declare const DescribeAlarmModelRequest: S.Schema<DescribeAlarmModelRequest>;
export type StatusMessage = string;
export interface DescribeAlarmModelResponse {
    creationTime?: Date;
    alarmModelArn?: string;
    alarmModelVersion?: string;
    lastUpdateTime?: Date;
    status?: AlarmModelVersionStatus;
    statusMessage?: string;
    alarmModelName?: string;
    alarmModelDescription?: string;
    roleArn?: string;
    key?: string;
    severity?: number;
    alarmRule?: AlarmRule;
    alarmNotification?: AlarmNotification;
    alarmEventActions?: AlarmEventActions;
    alarmCapabilities?: AlarmCapabilities;
}
export declare const DescribeAlarmModelResponse: S.Schema<DescribeAlarmModelResponse>;
export interface DescribeDetectorModelRequest {
    detectorModelName: string;
    detectorModelVersion?: string;
}
export declare const DescribeDetectorModelRequest: S.Schema<DescribeDetectorModelRequest>;
export interface DetectorModel {
    detectorModelDefinition?: DetectorModelDefinition;
    detectorModelConfiguration?: DetectorModelConfiguration;
}
export declare const DetectorModel: S.Schema<DetectorModel>;
export interface DescribeDetectorModelResponse {
    detectorModel?: DetectorModel;
}
export declare const DescribeDetectorModelResponse: S.Schema<DescribeDetectorModelResponse>;
export type AnalysisId = string;
export interface DescribeDetectorModelAnalysisRequest {
    analysisId: string;
}
export declare const DescribeDetectorModelAnalysisRequest: S.Schema<DescribeDetectorModelAnalysisRequest>;
export type AnalysisStatus = "RUNNING" | "COMPLETE" | "FAILED" | (string & {});
export declare const AnalysisStatus: any;
export interface DescribeDetectorModelAnalysisResponse {
    status?: AnalysisStatus;
}
export declare const DescribeDetectorModelAnalysisResponse: S.Schema<DescribeDetectorModelAnalysisResponse>;
export interface DescribeInputRequest {
    inputName: string;
}
export declare const DescribeInputRequest: S.Schema<DescribeInputRequest>;
export interface Input {
    inputConfiguration?: InputConfiguration;
    inputDefinition?: InputDefinition;
}
export declare const Input: S.Schema<Input>;
export interface DescribeInputResponse {
    input?: Input;
}
export declare const DescribeInputResponse: S.Schema<DescribeInputResponse>;
export interface DescribeLoggingOptionsRequest {
}
export declare const DescribeLoggingOptionsRequest: S.Schema<DescribeLoggingOptionsRequest>;
export type LoggingLevel = "ERROR" | "INFO" | "DEBUG" | (string & {});
export declare const LoggingLevel: any;
export type LoggingEnabled = boolean;
export type KeyValue = string;
export interface DetectorDebugOption {
    detectorModelName: string;
    keyValue?: string;
}
export declare const DetectorDebugOption: S.Schema<DetectorDebugOption>;
export type DetectorDebugOptions = DetectorDebugOption[];
export declare const DetectorDebugOptions: any;
export interface LoggingOptions {
    roleArn: string;
    level: LoggingLevel;
    enabled: boolean;
    detectorDebugOptions?: DetectorDebugOption[];
}
export declare const LoggingOptions: S.Schema<LoggingOptions>;
export interface DescribeLoggingOptionsResponse {
    loggingOptions?: LoggingOptions;
}
export declare const DescribeLoggingOptionsResponse: S.Schema<DescribeLoggingOptionsResponse>;
export type NextToken = string;
export type MaxAnalysisResults = number;
export interface GetDetectorModelAnalysisResultsRequest {
    analysisId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetDetectorModelAnalysisResultsRequest: S.Schema<GetDetectorModelAnalysisResultsRequest>;
export type AnalysisType = string;
export type AnalysisResultLevel = "INFO" | "WARNING" | "ERROR" | (string & {});
export declare const AnalysisResultLevel: any;
export type AnalysisMessage = string;
export type AnalysisResultLocationPath = string;
export interface AnalysisResultLocation {
    path?: string;
}
export declare const AnalysisResultLocation: S.Schema<AnalysisResultLocation>;
export type AnalysisResultLocations = AnalysisResultLocation[];
export declare const AnalysisResultLocations: any;
export interface AnalysisResult {
    type?: string;
    level?: AnalysisResultLevel;
    message?: string;
    locations?: AnalysisResultLocation[];
}
export declare const AnalysisResult: S.Schema<AnalysisResult>;
export type AnalysisResults = AnalysisResult[];
export declare const AnalysisResults: any;
export interface GetDetectorModelAnalysisResultsResponse {
    analysisResults?: AnalysisResult[];
    nextToken?: string;
}
export declare const GetDetectorModelAnalysisResultsResponse: S.Schema<GetDetectorModelAnalysisResultsResponse>;
export type MaxResults = number;
export interface ListAlarmModelsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAlarmModelsRequest: S.Schema<ListAlarmModelsRequest>;
export interface AlarmModelSummary {
    creationTime?: Date;
    alarmModelDescription?: string;
    alarmModelName?: string;
}
export declare const AlarmModelSummary: S.Schema<AlarmModelSummary>;
export type AlarmModelSummaries = AlarmModelSummary[];
export declare const AlarmModelSummaries: any;
export interface ListAlarmModelsResponse {
    alarmModelSummaries?: AlarmModelSummary[];
    nextToken?: string;
}
export declare const ListAlarmModelsResponse: S.Schema<ListAlarmModelsResponse>;
export interface ListAlarmModelVersionsRequest {
    alarmModelName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAlarmModelVersionsRequest: S.Schema<ListAlarmModelVersionsRequest>;
export interface AlarmModelVersionSummary {
    alarmModelName?: string;
    alarmModelArn?: string;
    alarmModelVersion?: string;
    roleArn?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    status?: AlarmModelVersionStatus;
    statusMessage?: string;
}
export declare const AlarmModelVersionSummary: S.Schema<AlarmModelVersionSummary>;
export type AlarmModelVersionSummaries = AlarmModelVersionSummary[];
export declare const AlarmModelVersionSummaries: any;
export interface ListAlarmModelVersionsResponse {
    alarmModelVersionSummaries?: AlarmModelVersionSummary[];
    nextToken?: string;
}
export declare const ListAlarmModelVersionsResponse: S.Schema<ListAlarmModelVersionsResponse>;
export interface ListDetectorModelsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDetectorModelsRequest: S.Schema<ListDetectorModelsRequest>;
export interface DetectorModelSummary {
    detectorModelName?: string;
    detectorModelDescription?: string;
    creationTime?: Date;
}
export declare const DetectorModelSummary: S.Schema<DetectorModelSummary>;
export type DetectorModelSummaries = DetectorModelSummary[];
export declare const DetectorModelSummaries: any;
export interface ListDetectorModelsResponse {
    detectorModelSummaries?: DetectorModelSummary[];
    nextToken?: string;
}
export declare const ListDetectorModelsResponse: S.Schema<ListDetectorModelsResponse>;
export interface ListDetectorModelVersionsRequest {
    detectorModelName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDetectorModelVersionsRequest: S.Schema<ListDetectorModelVersionsRequest>;
export interface DetectorModelVersionSummary {
    detectorModelName?: string;
    detectorModelVersion?: string;
    detectorModelArn?: string;
    roleArn?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    status?: DetectorModelVersionStatus;
    evaluationMethod?: EvaluationMethod;
}
export declare const DetectorModelVersionSummary: S.Schema<DetectorModelVersionSummary>;
export type DetectorModelVersionSummaries = DetectorModelVersionSummary[];
export declare const DetectorModelVersionSummaries: any;
export interface ListDetectorModelVersionsResponse {
    detectorModelVersionSummaries?: DetectorModelVersionSummary[];
    nextToken?: string;
}
export declare const ListDetectorModelVersionsResponse: S.Schema<ListDetectorModelVersionsResponse>;
export interface IotEventsInputIdentifier {
    inputName: string;
}
export declare const IotEventsInputIdentifier: S.Schema<IotEventsInputIdentifier>;
export type AssetModelId = string;
export interface IotSiteWiseAssetModelPropertyIdentifier {
    assetModelId: string;
    propertyId: string;
}
export declare const IotSiteWiseAssetModelPropertyIdentifier: S.Schema<IotSiteWiseAssetModelPropertyIdentifier>;
export interface IotSiteWiseInputIdentifier {
    iotSiteWiseAssetModelPropertyIdentifier?: IotSiteWiseAssetModelPropertyIdentifier;
}
export declare const IotSiteWiseInputIdentifier: S.Schema<IotSiteWiseInputIdentifier>;
export interface InputIdentifier {
    iotEventsInputIdentifier?: IotEventsInputIdentifier;
    iotSiteWiseInputIdentifier?: IotSiteWiseInputIdentifier;
}
export declare const InputIdentifier: S.Schema<InputIdentifier>;
export interface ListInputRoutingsRequest {
    inputIdentifier: InputIdentifier;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListInputRoutingsRequest: S.Schema<ListInputRoutingsRequest>;
export type ResourceName = string;
export interface RoutedResource {
    name?: string;
    arn?: string;
}
export declare const RoutedResource: S.Schema<RoutedResource>;
export type RoutedResources = RoutedResource[];
export declare const RoutedResources: any;
export interface ListInputRoutingsResponse {
    routedResources?: RoutedResource[];
    nextToken?: string;
}
export declare const ListInputRoutingsResponse: S.Schema<ListInputRoutingsResponse>;
export interface ListInputsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListInputsRequest: S.Schema<ListInputsRequest>;
export interface InputSummary {
    inputName?: string;
    inputDescription?: string;
    inputArn?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    status?: InputStatus;
}
export declare const InputSummary: S.Schema<InputSummary>;
export type InputSummaries = InputSummary[];
export declare const InputSummaries: any;
export interface ListInputsResponse {
    inputSummaries?: InputSummary[];
    nextToken?: string;
}
export declare const ListInputsResponse: S.Schema<ListInputsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PutLoggingOptionsRequest {
    loggingOptions: LoggingOptions;
}
export declare const PutLoggingOptionsRequest: S.Schema<PutLoggingOptionsRequest>;
export interface PutLoggingOptionsResponse {
}
export declare const PutLoggingOptionsResponse: S.Schema<PutLoggingOptionsResponse>;
export interface StartDetectorModelAnalysisRequest {
    detectorModelDefinition: DetectorModelDefinition;
}
export declare const StartDetectorModelAnalysisRequest: S.Schema<StartDetectorModelAnalysisRequest>;
export interface StartDetectorModelAnalysisResponse {
    analysisId?: string;
}
export declare const StartDetectorModelAnalysisResponse: S.Schema<StartDetectorModelAnalysisResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAlarmModelRequest {
    alarmModelName: string;
    alarmModelDescription?: string;
    roleArn: string;
    severity?: number;
    alarmRule: AlarmRule;
    alarmNotification?: AlarmNotification;
    alarmEventActions?: AlarmEventActions;
    alarmCapabilities?: AlarmCapabilities;
}
export declare const UpdateAlarmModelRequest: S.Schema<UpdateAlarmModelRequest>;
export interface UpdateAlarmModelResponse {
    creationTime?: Date;
    alarmModelArn?: string;
    alarmModelVersion?: string;
    lastUpdateTime?: Date;
    status?: AlarmModelVersionStatus;
}
export declare const UpdateAlarmModelResponse: S.Schema<UpdateAlarmModelResponse>;
export interface UpdateDetectorModelRequest {
    detectorModelName: string;
    detectorModelDefinition: DetectorModelDefinition;
    detectorModelDescription?: string;
    roleArn: string;
    evaluationMethod?: EvaluationMethod;
}
export declare const UpdateDetectorModelRequest: S.Schema<UpdateDetectorModelRequest>;
export interface UpdateDetectorModelResponse {
    detectorModelConfiguration?: DetectorModelConfiguration;
}
export declare const UpdateDetectorModelResponse: S.Schema<UpdateDetectorModelResponse>;
export interface UpdateInputRequest {
    inputName: string;
    inputDescription?: string;
    inputDefinition: InputDefinition;
}
export declare const UpdateInputRequest: S.Schema<UpdateInputRequest>;
export interface UpdateInputResponse {
    inputConfiguration?: InputConfiguration;
}
export declare const UpdateInputResponse: S.Schema<UpdateInputResponse>;
export type ErrorMessage = string;
export type ResourceId = string;
export type ResourceArn = string;
export type CreateAlarmModelError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates an alarm model to monitor an AWS IoT Events input attribute. You can use the alarm to get
 * notified when the value is outside a specified range. For more information, see Create an
 * alarm model in the *AWS IoT Events Developer Guide*.
 */
export declare const createAlarmModel: API.OperationMethod<CreateAlarmModelRequest, CreateAlarmModelResponse, CreateAlarmModelError, Credentials | HttpClient.HttpClient>;
export type CreateDetectorModelError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates a detector model.
 */
export declare const createDetectorModel: API.OperationMethod<CreateDetectorModelRequest, CreateDetectorModelResponse, CreateDetectorModelError, Credentials | HttpClient.HttpClient>;
export type CreateInputError = InternalFailureException | InvalidRequestException | ResourceAlreadyExistsException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates an input.
 */
export declare const createInput: API.OperationMethod<CreateInputRequest, CreateInputResponse, CreateInputError, Credentials | HttpClient.HttpClient>;
export type DeleteAlarmModelError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes an alarm model. Any alarm instances that were created based on this alarm model
 * are also deleted. This action can't be undone.
 */
export declare const deleteAlarmModel: API.OperationMethod<DeleteAlarmModelRequest, DeleteAlarmModelResponse, DeleteAlarmModelError, Credentials | HttpClient.HttpClient>;
export type DeleteDetectorModelError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes a detector model. Any active instances of the detector model are also
 * deleted.
 */
export declare const deleteDetectorModel: API.OperationMethod<DeleteDetectorModelRequest, DeleteDetectorModelResponse, DeleteDetectorModelError, Credentials | HttpClient.HttpClient>;
export type DeleteInputError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes an input.
 */
export declare const deleteInput: API.OperationMethod<DeleteInputRequest, DeleteInputResponse, DeleteInputError, Credentials | HttpClient.HttpClient>;
export type DescribeAlarmModelError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an alarm model. If you don't specify a value for the
 * `alarmModelVersion` parameter, the latest version is returned.
 */
export declare const describeAlarmModel: API.OperationMethod<DescribeAlarmModelRequest, DescribeAlarmModelResponse, DescribeAlarmModelError, Credentials | HttpClient.HttpClient>;
export type DescribeDetectorModelError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Describes a detector model. If the `version` parameter is not specified,
 * information about the latest version is returned.
 */
export declare const describeDetectorModel: API.OperationMethod<DescribeDetectorModelRequest, DescribeDetectorModelResponse, DescribeDetectorModelError, Credentials | HttpClient.HttpClient>;
export type DescribeDetectorModelAnalysisError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves runtime information about a detector model analysis.
 *
 * After AWS IoT Events starts analyzing your detector model, you have up to 24 hours to retrieve the analysis results.
 */
export declare const describeDetectorModelAnalysis: API.OperationMethod<DescribeDetectorModelAnalysisRequest, DescribeDetectorModelAnalysisResponse, DescribeDetectorModelAnalysisError, Credentials | HttpClient.HttpClient>;
export type DescribeInputError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Describes an input.
 */
export declare const describeInput: API.OperationMethod<DescribeInputRequest, DescribeInputResponse, DescribeInputError, Credentials | HttpClient.HttpClient>;
export type DescribeLoggingOptionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves the current settings of the AWS IoT Events logging options.
 */
export declare const describeLoggingOptions: API.OperationMethod<DescribeLoggingOptionsRequest, DescribeLoggingOptionsResponse, DescribeLoggingOptionsError, Credentials | HttpClient.HttpClient>;
export type GetDetectorModelAnalysisResultsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves one or more analysis results of the detector model.
 *
 * After AWS IoT Events starts analyzing your detector model, you have up to 24 hours to retrieve the analysis results.
 */
export declare const getDetectorModelAnalysisResults: API.OperationMethod<GetDetectorModelAnalysisResultsRequest, GetDetectorModelAnalysisResultsResponse, GetDetectorModelAnalysisResultsError, Credentials | HttpClient.HttpClient>;
export type ListAlarmModelsError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the alarm models that you created. The operation returns only the metadata
 * associated with each alarm model.
 */
export declare const listAlarmModels: API.OperationMethod<ListAlarmModelsRequest, ListAlarmModelsResponse, ListAlarmModelsError, Credentials | HttpClient.HttpClient>;
export type ListAlarmModelVersionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists all the versions of an alarm model. The operation returns only the metadata
 * associated with each alarm model version.
 */
export declare const listAlarmModelVersions: API.OperationMethod<ListAlarmModelVersionsRequest, ListAlarmModelVersionsResponse, ListAlarmModelVersionsError, Credentials | HttpClient.HttpClient>;
export type ListDetectorModelsError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the detector models you have created. Only the metadata associated with each
 * detector model is returned.
 */
export declare const listDetectorModels: API.OperationMethod<ListDetectorModelsRequest, ListDetectorModelsResponse, ListDetectorModelsError, Credentials | HttpClient.HttpClient>;
export type ListDetectorModelVersionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists all the versions of a detector model. Only the metadata associated with each
 * detector model version is returned.
 */
export declare const listDetectorModelVersions: API.OperationMethod<ListDetectorModelVersionsRequest, ListDetectorModelVersionsResponse, ListDetectorModelVersionsError, Credentials | HttpClient.HttpClient>;
export type ListInputRoutingsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists one or more input routings.
 */
export declare const listInputRoutings: API.OperationMethod<ListInputRoutingsRequest, ListInputRoutingsResponse, ListInputRoutingsError, Credentials | HttpClient.HttpClient>;
export type ListInputsError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the inputs you have created.
 */
export declare const listInputs: API.OperationMethod<ListInputsRequest, ListInputsResponse, ListInputsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the tags (metadata) you have assigned to the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutLoggingOptionsError = InternalFailureException | InvalidRequestException | ResourceInUseException | ServiceUnavailableException | ThrottlingException | UnsupportedOperationException | CommonErrors;
/**
 * Sets or updates the AWS IoT Events logging options.
 *
 * If you update the value of any `loggingOptions` field, it takes up to one
 * minute for the change to take effect. If you change the policy attached to the role you
 * specified in the `roleArn` field (for example, to correct an invalid policy), it
 * takes up to five minutes for that change to take effect.
 */
export declare const putLoggingOptions: API.OperationMethod<PutLoggingOptionsRequest, PutLoggingOptionsResponse, PutLoggingOptionsError, Credentials | HttpClient.HttpClient>;
export type StartDetectorModelAnalysisError = InternalFailureException | InvalidRequestException | LimitExceededException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Performs an analysis of your detector model. For more information,
 * see Troubleshooting a detector model
 * in the *AWS IoT Events Developer Guide*.
 */
export declare const startDetectorModelAnalysis: API.OperationMethod<StartDetectorModelAnalysisRequest, StartDetectorModelAnalysisResponse, StartDetectorModelAnalysisError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds to or modifies the tags of the given resource. Tags are metadata that can be used to
 * manage a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the given tags (metadata) from the resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAlarmModelError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates an alarm model. Any alarms that were created based on the previous version are
 * deleted and then created again as new data arrives.
 */
export declare const updateAlarmModel: API.OperationMethod<UpdateAlarmModelRequest, UpdateAlarmModelResponse, UpdateAlarmModelError, Credentials | HttpClient.HttpClient>;
export type UpdateDetectorModelError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates a detector model. Detectors (instances) spawned by the previous version are
 * deleted and then re-created as new inputs arrive.
 */
export declare const updateDetectorModel: API.OperationMethod<UpdateDetectorModelRequest, UpdateDetectorModelResponse, UpdateDetectorModelError, Credentials | HttpClient.HttpClient>;
export type UpdateInputError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates an input.
 */
export declare const updateInput: API.OperationMethod<UpdateInputRequest, UpdateInputResponse, UpdateInputError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iot-events.d.ts.map