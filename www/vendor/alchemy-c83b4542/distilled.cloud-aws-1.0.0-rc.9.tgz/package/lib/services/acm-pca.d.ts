import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const CertificateMismatchException_base: S.Class<CertificateMismatchException, S.TaggedStruct<"CertificateMismatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CertificateMismatchException extends /*@__PURE__*/ CertificateMismatchException_base {
}
declare const ConcurrentModificationException_base: S.Class<ConcurrentModificationException, S.TaggedStruct<"ConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const InvalidArgsException_base: S.Class<InvalidArgsException, S.TaggedStruct<"InvalidArgsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidArgsException extends /*@__PURE__*/ InvalidArgsException_base {
}
declare const InvalidArnException_base: S.Class<InvalidArnException, S.TaggedStruct<"InvalidArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidArnException extends /*@__PURE__*/ InvalidArnException_base {
}
declare const InvalidNextTokenException_base: S.Class<InvalidNextTokenException, S.TaggedStruct<"InvalidNextTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidPolicyException_base: S.Class<InvalidPolicyException, S.TaggedStruct<"InvalidPolicyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidPolicyException extends /*@__PURE__*/ InvalidPolicyException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidStateException_base: S.Class<InvalidStateException, S.TaggedStruct<"InvalidStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const InvalidTagException_base: S.Class<InvalidTagException, S.TaggedStruct<"InvalidTagException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTagException extends /*@__PURE__*/ InvalidTagException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const LockoutPreventedException_base: S.Class<LockoutPreventedException, S.TaggedStruct<"LockoutPreventedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LockoutPreventedException extends /*@__PURE__*/ LockoutPreventedException_base {
}
declare const MalformedCertificateException_base: S.Class<MalformedCertificateException, S.TaggedStruct<"MalformedCertificateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MalformedCertificateException extends /*@__PURE__*/ MalformedCertificateException_base {
}
declare const MalformedCSRException_base: S.Class<MalformedCSRException, S.TaggedStruct<"MalformedCSRException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MalformedCSRException extends /*@__PURE__*/ MalformedCSRException_base {
}
declare const PermissionAlreadyExistsException_base: S.Class<PermissionAlreadyExistsException, S.TaggedStruct<"PermissionAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class PermissionAlreadyExistsException extends /*@__PURE__*/ PermissionAlreadyExistsException_base {
}
declare const RequestAlreadyProcessedException_base: S.Class<RequestAlreadyProcessedException, S.TaggedStruct<"RequestAlreadyProcessedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RequestAlreadyProcessedException extends /*@__PURE__*/ RequestAlreadyProcessedException_base {
}
declare const RequestFailedException_base: S.Class<RequestFailedException, S.TaggedStruct<"RequestFailedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RequestFailedException extends /*@__PURE__*/ RequestFailedException_base {
}
declare const RequestInProgressException_base: S.Class<RequestInProgressException, S.TaggedStruct<"RequestInProgressException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RequestInProgressException extends /*@__PURE__*/ RequestInProgressException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
export type KeyAlgorithm = "RSA_2048" | "RSA_3072" | "RSA_4096" | "EC_prime256v1" | "EC_secp384r1" | "EC_secp521r1" | "ML_DSA_44" | "ML_DSA_65" | "ML_DSA_87" | "SM2" | (string & {});
export declare const KeyAlgorithm: any;
export type SigningAlgorithm = "SHA256WITHECDSA" | "SHA384WITHECDSA" | "SHA512WITHECDSA" | "SHA256WITHRSA" | "SHA384WITHRSA" | "SHA512WITHRSA" | "SHA256WITHRSA_PSS" | "SHA384WITHRSA_PSS" | "SHA512WITHRSA_PSS" | "SM3WITHSM2" | "ML_DSA_44" | "ML_DSA_65" | "ML_DSA_87" | (string & {});
export declare const SigningAlgorithm: any;
export type CountryCodeString = string;
export type String64 = string;
export type ASN1PrintableString64 = string;
export type String128 = string;
export type String40 = string;
export type String16 = string;
export type String5 = string;
export type String3 = string;
export type CustomObjectIdentifier = string;
export type String1To256 = string;
export interface CustomAttribute {
    ObjectIdentifier: string;
    Value: string;
}
export declare const CustomAttribute: S.Schema<CustomAttribute>;
export type CustomAttributeList = CustomAttribute[];
export declare const CustomAttributeList: any;
export interface ASN1Subject {
    Country?: string;
    Organization?: string;
    OrganizationalUnit?: string;
    DistinguishedNameQualifier?: string;
    State?: string;
    CommonName?: string;
    SerialNumber?: string;
    Locality?: string;
    Title?: string;
    Surname?: string;
    GivenName?: string;
    Initials?: string;
    Pseudonym?: string;
    GenerationQualifier?: string;
    CustomAttributes?: CustomAttribute[];
}
export declare const ASN1Subject: S.Schema<ASN1Subject>;
export interface KeyUsage {
    DigitalSignature?: boolean;
    NonRepudiation?: boolean;
    KeyEncipherment?: boolean;
    DataEncipherment?: boolean;
    KeyAgreement?: boolean;
    KeyCertSign?: boolean;
    CRLSign?: boolean;
    EncipherOnly?: boolean;
    DecipherOnly?: boolean;
}
export declare const KeyUsage: S.Schema<KeyUsage>;
export type AccessMethodType = "CA_REPOSITORY" | "RESOURCE_PKI_MANIFEST" | "RESOURCE_PKI_NOTIFY" | (string & {});
export declare const AccessMethodType: any;
export interface AccessMethod {
    CustomObjectIdentifier?: string;
    AccessMethodType?: AccessMethodType;
}
export declare const AccessMethod: S.Schema<AccessMethod>;
export type String256 = string;
export interface OtherName {
    TypeId: string;
    Value: string;
}
export declare const OtherName: S.Schema<OtherName>;
export type String253 = string;
export interface EdiPartyName {
    PartyName: string;
    NameAssigner?: string;
}
export declare const EdiPartyName: S.Schema<EdiPartyName>;
export type String39 = string;
export interface GeneralName {
    OtherName?: OtherName;
    Rfc822Name?: string;
    DnsName?: string;
    DirectoryName?: ASN1Subject;
    EdiPartyName?: EdiPartyName;
    UniformResourceIdentifier?: string;
    IpAddress?: string;
    RegisteredId?: string;
}
export declare const GeneralName: S.Schema<GeneralName>;
export interface AccessDescription {
    AccessMethod: AccessMethod;
    AccessLocation: GeneralName;
}
export declare const AccessDescription: S.Schema<AccessDescription>;
export type AccessDescriptionList = AccessDescription[];
export declare const AccessDescriptionList: any;
export interface CsrExtensions {
    KeyUsage?: KeyUsage;
    SubjectInformationAccess?: AccessDescription[];
}
export declare const CsrExtensions: S.Schema<CsrExtensions>;
export interface CertificateAuthorityConfiguration {
    KeyAlgorithm: KeyAlgorithm;
    SigningAlgorithm: SigningAlgorithm;
    Subject: ASN1Subject;
    CsrExtensions?: CsrExtensions;
}
export declare const CertificateAuthorityConfiguration: S.Schema<CertificateAuthorityConfiguration>;
export type Integer1To5000 = number;
export type CnameString = string;
export type S3BucketName3To255 = string;
export type S3ObjectAcl = "PUBLIC_READ" | "BUCKET_OWNER_FULL_CONTROL" | (string & {});
export declare const S3ObjectAcl: any;
export interface CrlDistributionPointExtensionConfiguration {
    OmitExtension: boolean;
}
export declare const CrlDistributionPointExtensionConfiguration: S.Schema<CrlDistributionPointExtensionConfiguration>;
export type CrlType = "COMPLETE" | "PARTITIONED" | (string & {});
export declare const CrlType: any;
export type CrlPathString = string;
export interface CrlConfiguration {
    Enabled: boolean;
    ExpirationInDays?: number;
    CustomCname?: string;
    S3BucketName?: string;
    S3ObjectAcl?: S3ObjectAcl;
    CrlDistributionPointExtensionConfiguration?: CrlDistributionPointExtensionConfiguration;
    CrlType?: CrlType;
    CustomPath?: string;
}
export declare const CrlConfiguration: S.Schema<CrlConfiguration>;
export interface OcspConfiguration {
    Enabled: boolean;
    OcspCustomCname?: string;
}
export declare const OcspConfiguration: S.Schema<OcspConfiguration>;
export interface RevocationConfiguration {
    CrlConfiguration?: CrlConfiguration;
    OcspConfiguration?: OcspConfiguration;
}
export declare const RevocationConfiguration: S.Schema<RevocationConfiguration>;
export type CertificateAuthorityType = "ROOT" | "SUBORDINATE" | (string & {});
export declare const CertificateAuthorityType: any;
export type IdempotencyToken = string;
export type KeyStorageSecurityStandard = "FIPS_140_2_LEVEL_2_OR_HIGHER" | "FIPS_140_2_LEVEL_3_OR_HIGHER" | "CCPC_LEVEL_1_OR_HIGHER" | (string & {});
export declare const KeyStorageSecurityStandard: any;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type CertificateAuthorityUsageMode = "GENERAL_PURPOSE" | "SHORT_LIVED_CERTIFICATE" | (string & {});
export declare const CertificateAuthorityUsageMode: any;
export interface CreateCertificateAuthorityRequest {
    CertificateAuthorityConfiguration: CertificateAuthorityConfiguration;
    RevocationConfiguration?: RevocationConfiguration;
    CertificateAuthorityType: CertificateAuthorityType;
    IdempotencyToken?: string;
    KeyStorageSecurityStandard?: KeyStorageSecurityStandard;
    Tags?: Tag[];
    UsageMode?: CertificateAuthorityUsageMode;
}
export declare const CreateCertificateAuthorityRequest: S.Schema<CreateCertificateAuthorityRequest>;
export type Arn = string;
export interface CreateCertificateAuthorityResponse {
    CertificateAuthorityArn?: string;
}
export declare const CreateCertificateAuthorityResponse: S.Schema<CreateCertificateAuthorityResponse>;
export type S3BucketName = string;
export type AuditReportResponseFormat = "JSON" | "CSV" | (string & {});
export declare const AuditReportResponseFormat: any;
export interface CreateCertificateAuthorityAuditReportRequest {
    CertificateAuthorityArn: string;
    S3BucketName: string;
    AuditReportResponseFormat: AuditReportResponseFormat;
}
export declare const CreateCertificateAuthorityAuditReportRequest: S.Schema<CreateCertificateAuthorityAuditReportRequest>;
export type AuditReportId = string;
export type S3Key = string;
export interface CreateCertificateAuthorityAuditReportResponse {
    AuditReportId?: string;
    S3Key?: string;
}
export declare const CreateCertificateAuthorityAuditReportResponse: S.Schema<CreateCertificateAuthorityAuditReportResponse>;
export type Principal = string;
export type AccountId = string;
export type ActionType = "IssueCertificate" | "GetCertificate" | "ListPermissions" | (string & {});
export declare const ActionType: any;
export type ActionList = ActionType[];
export declare const ActionList: any;
export interface CreatePermissionRequest {
    CertificateAuthorityArn: string;
    Principal: string;
    SourceAccount?: string;
    Actions: ActionType[];
}
export declare const CreatePermissionRequest: S.Schema<CreatePermissionRequest>;
export interface CreatePermissionResponse {
}
export declare const CreatePermissionResponse: S.Schema<CreatePermissionResponse>;
export type PermanentDeletionTimeInDays = number;
export interface DeleteCertificateAuthorityRequest {
    CertificateAuthorityArn: string;
    PermanentDeletionTimeInDays?: number;
}
export declare const DeleteCertificateAuthorityRequest: S.Schema<DeleteCertificateAuthorityRequest>;
export interface DeleteCertificateAuthorityResponse {
}
export declare const DeleteCertificateAuthorityResponse: S.Schema<DeleteCertificateAuthorityResponse>;
export interface DeletePermissionRequest {
    CertificateAuthorityArn: string;
    Principal: string;
    SourceAccount?: string;
}
export declare const DeletePermissionRequest: S.Schema<DeletePermissionRequest>;
export interface DeletePermissionResponse {
}
export declare const DeletePermissionResponse: S.Schema<DeletePermissionResponse>;
export interface DeletePolicyRequest {
    ResourceArn: string;
}
export declare const DeletePolicyRequest: S.Schema<DeletePolicyRequest>;
export interface DeletePolicyResponse {
}
export declare const DeletePolicyResponse: S.Schema<DeletePolicyResponse>;
export interface DescribeCertificateAuthorityRequest {
    CertificateAuthorityArn: string;
}
export declare const DescribeCertificateAuthorityRequest: S.Schema<DescribeCertificateAuthorityRequest>;
export type CertificateAuthorityStatus = "CREATING" | "PENDING_CERTIFICATE" | "ACTIVE" | "DELETED" | "DISABLED" | "EXPIRED" | "FAILED" | (string & {});
export declare const CertificateAuthorityStatus: any;
export type FailureReason = "REQUEST_TIMED_OUT" | "UNSUPPORTED_ALGORITHM" | "OTHER" | (string & {});
export declare const FailureReason: any;
export interface CertificateAuthority {
    Arn?: string;
    OwnerAccount?: string;
    CreatedAt?: Date;
    LastStateChangeAt?: Date;
    Type?: CertificateAuthorityType;
    Serial?: string;
    Status?: CertificateAuthorityStatus;
    NotBefore?: Date;
    NotAfter?: Date;
    FailureReason?: FailureReason;
    CertificateAuthorityConfiguration?: CertificateAuthorityConfiguration;
    RevocationConfiguration?: RevocationConfiguration;
    RestorableUntil?: Date;
    KeyStorageSecurityStandard?: KeyStorageSecurityStandard;
    UsageMode?: CertificateAuthorityUsageMode;
}
export declare const CertificateAuthority: S.Schema<CertificateAuthority>;
export interface DescribeCertificateAuthorityResponse {
    CertificateAuthority?: CertificateAuthority;
}
export declare const DescribeCertificateAuthorityResponse: S.Schema<DescribeCertificateAuthorityResponse>;
export interface DescribeCertificateAuthorityAuditReportRequest {
    CertificateAuthorityArn: string;
    AuditReportId: string;
}
export declare const DescribeCertificateAuthorityAuditReportRequest: S.Schema<DescribeCertificateAuthorityAuditReportRequest>;
export type AuditReportStatus = "CREATING" | "SUCCESS" | "FAILED" | (string & {});
export declare const AuditReportStatus: any;
export interface DescribeCertificateAuthorityAuditReportResponse {
    AuditReportStatus?: AuditReportStatus;
    S3BucketName?: string;
    S3Key?: string;
    CreatedAt?: Date;
}
export declare const DescribeCertificateAuthorityAuditReportResponse: S.Schema<DescribeCertificateAuthorityAuditReportResponse>;
export interface GetCertificateRequest {
    CertificateAuthorityArn: string;
    CertificateArn: string;
}
export declare const GetCertificateRequest: S.Schema<GetCertificateRequest>;
export type CertificateBody = string;
export type CertificateChain = string;
export interface GetCertificateResponse {
    Certificate?: string;
    CertificateChain?: string;
}
export declare const GetCertificateResponse: S.Schema<GetCertificateResponse>;
export interface GetCertificateAuthorityCertificateRequest {
    CertificateAuthorityArn: string;
}
export declare const GetCertificateAuthorityCertificateRequest: S.Schema<GetCertificateAuthorityCertificateRequest>;
export interface GetCertificateAuthorityCertificateResponse {
    Certificate?: string;
    CertificateChain?: string;
}
export declare const GetCertificateAuthorityCertificateResponse: S.Schema<GetCertificateAuthorityCertificateResponse>;
export interface GetCertificateAuthorityCsrRequest {
    CertificateAuthorityArn: string;
}
export declare const GetCertificateAuthorityCsrRequest: S.Schema<GetCertificateAuthorityCsrRequest>;
export type CsrBody = string;
export interface GetCertificateAuthorityCsrResponse {
    Csr?: string;
}
export declare const GetCertificateAuthorityCsrResponse: S.Schema<GetCertificateAuthorityCsrResponse>;
export interface GetPolicyRequest {
    ResourceArn: string;
}
export declare const GetPolicyRequest: S.Schema<GetPolicyRequest>;
export type AWSPolicy = string;
export interface GetPolicyResponse {
    Policy?: string;
}
export declare const GetPolicyResponse: S.Schema<GetPolicyResponse>;
export type CertificateBodyBlob = Uint8Array;
export type CertificateChainBlob = Uint8Array;
export interface ImportCertificateAuthorityCertificateRequest {
    CertificateAuthorityArn: string;
    Certificate: Uint8Array;
    CertificateChain?: Uint8Array;
}
export declare const ImportCertificateAuthorityCertificateRequest: S.Schema<ImportCertificateAuthorityCertificateRequest>;
export interface ImportCertificateAuthorityCertificateResponse {
}
export declare const ImportCertificateAuthorityCertificateResponse: S.Schema<ImportCertificateAuthorityCertificateResponse>;
export type PolicyQualifierId = "CPS" | (string & {});
export declare const PolicyQualifierId: any;
export interface Qualifier {
    CpsUri: string;
}
export declare const Qualifier: S.Schema<Qualifier>;
export interface PolicyQualifierInfo {
    PolicyQualifierId: PolicyQualifierId;
    Qualifier: Qualifier;
}
export declare const PolicyQualifierInfo: S.Schema<PolicyQualifierInfo>;
export type PolicyQualifierInfoList = PolicyQualifierInfo[];
export declare const PolicyQualifierInfoList: any;
export interface PolicyInformation {
    CertPolicyId: string;
    PolicyQualifiers?: PolicyQualifierInfo[];
}
export declare const PolicyInformation: S.Schema<PolicyInformation>;
export type CertificatePolicyList = PolicyInformation[];
export declare const CertificatePolicyList: any;
export type ExtendedKeyUsageType = "SERVER_AUTH" | "CLIENT_AUTH" | "CODE_SIGNING" | "EMAIL_PROTECTION" | "TIME_STAMPING" | "OCSP_SIGNING" | "SMART_CARD_LOGIN" | "DOCUMENT_SIGNING" | "CERTIFICATE_TRANSPARENCY" | (string & {});
export declare const ExtendedKeyUsageType: any;
export interface ExtendedKeyUsage {
    ExtendedKeyUsageType?: ExtendedKeyUsageType;
    ExtendedKeyUsageObjectIdentifier?: string;
}
export declare const ExtendedKeyUsage: S.Schema<ExtendedKeyUsage>;
export type ExtendedKeyUsageList = ExtendedKeyUsage[];
export declare const ExtendedKeyUsageList: any;
export type GeneralNameList = GeneralName[];
export declare const GeneralNameList: any;
export type Base64String1To4096 = string;
export interface CustomExtension {
    ObjectIdentifier: string;
    Value: string;
    Critical?: boolean;
}
export declare const CustomExtension: S.Schema<CustomExtension>;
export type CustomExtensionList = CustomExtension[];
export declare const CustomExtensionList: any;
export interface Extensions {
    CertificatePolicies?: PolicyInformation[];
    ExtendedKeyUsage?: ExtendedKeyUsage[];
    KeyUsage?: KeyUsage;
    SubjectAlternativeNames?: GeneralName[];
    CustomExtensions?: CustomExtension[];
}
export declare const Extensions: S.Schema<Extensions>;
export interface ApiPassthrough {
    Extensions?: Extensions;
    Subject?: ASN1Subject;
}
export declare const ApiPassthrough: S.Schema<ApiPassthrough>;
export type CsrBlob = Uint8Array;
export type PositiveLong = number;
export type ValidityPeriodType = "END_DATE" | "ABSOLUTE" | "DAYS" | "MONTHS" | "YEARS" | (string & {});
export declare const ValidityPeriodType: any;
export interface Validity {
    Value: number;
    Type: ValidityPeriodType;
}
export declare const Validity: S.Schema<Validity>;
export interface IssueCertificateRequest {
    ApiPassthrough?: ApiPassthrough;
    CertificateAuthorityArn: string;
    Csr: Uint8Array;
    SigningAlgorithm: SigningAlgorithm;
    TemplateArn?: string;
    Validity: Validity;
    ValidityNotBefore?: Validity;
    IdempotencyToken?: string;
}
export declare const IssueCertificateRequest: S.Schema<IssueCertificateRequest>;
export interface IssueCertificateResponse {
    CertificateArn?: string;
}
export declare const IssueCertificateResponse: S.Schema<IssueCertificateResponse>;
export type MaxResults = number;
export type NextToken = string;
export type ResourceOwner = "SELF" | "OTHER_ACCOUNTS" | (string & {});
export declare const ResourceOwner: any;
export interface ListCertificateAuthoritiesRequest {
    MaxResults?: number;
    NextToken?: string;
    ResourceOwner?: ResourceOwner;
}
export declare const ListCertificateAuthoritiesRequest: S.Schema<ListCertificateAuthoritiesRequest>;
export type CertificateAuthorities = CertificateAuthority[];
export declare const CertificateAuthorities: any;
export interface ListCertificateAuthoritiesResponse {
    NextToken?: string;
    CertificateAuthorities?: CertificateAuthority[];
}
export declare const ListCertificateAuthoritiesResponse: S.Schema<ListCertificateAuthoritiesResponse>;
export interface ListPermissionsRequest {
    MaxResults?: number;
    NextToken?: string;
    CertificateAuthorityArn: string;
}
export declare const ListPermissionsRequest: S.Schema<ListPermissionsRequest>;
export interface Permission {
    CertificateAuthorityArn?: string;
    CreatedAt?: Date;
    Principal?: string;
    SourceAccount?: string;
    Actions?: ActionType[];
    Policy?: string;
}
export declare const Permission: S.Schema<Permission>;
export type PermissionList = Permission[];
export declare const PermissionList: any;
export interface ListPermissionsResponse {
    NextToken?: string;
    Permissions?: Permission[];
}
export declare const ListPermissionsResponse: S.Schema<ListPermissionsResponse>;
export interface ListTagsRequest {
    MaxResults?: number;
    NextToken?: string;
    CertificateAuthorityArn: string;
}
export declare const ListTagsRequest: S.Schema<ListTagsRequest>;
export interface ListTagsResponse {
    NextToken?: string;
    Tags?: Tag[];
}
export declare const ListTagsResponse: S.Schema<ListTagsResponse>;
export interface PutPolicyRequest {
    ResourceArn: string;
    Policy: string;
}
export declare const PutPolicyRequest: S.Schema<PutPolicyRequest>;
export interface PutPolicyResponse {
}
export declare const PutPolicyResponse: S.Schema<PutPolicyResponse>;
export interface RestoreCertificateAuthorityRequest {
    CertificateAuthorityArn: string;
}
export declare const RestoreCertificateAuthorityRequest: S.Schema<RestoreCertificateAuthorityRequest>;
export interface RestoreCertificateAuthorityResponse {
}
export declare const RestoreCertificateAuthorityResponse: S.Schema<RestoreCertificateAuthorityResponse>;
export type RevocationReason = "UNSPECIFIED" | "KEY_COMPROMISE" | "CERTIFICATE_AUTHORITY_COMPROMISE" | "AFFILIATION_CHANGED" | "SUPERSEDED" | "CESSATION_OF_OPERATION" | "PRIVILEGE_WITHDRAWN" | "A_A_COMPROMISE" | (string & {});
export declare const RevocationReason: any;
export interface RevokeCertificateRequest {
    CertificateAuthorityArn: string;
    CertificateSerial: string;
    RevocationReason: RevocationReason;
}
export declare const RevokeCertificateRequest: S.Schema<RevokeCertificateRequest>;
export interface RevokeCertificateResponse {
}
export declare const RevokeCertificateResponse: S.Schema<RevokeCertificateResponse>;
export interface TagCertificateAuthorityRequest {
    CertificateAuthorityArn: string;
    Tags: Tag[];
}
export declare const TagCertificateAuthorityRequest: S.Schema<TagCertificateAuthorityRequest>;
export interface TagCertificateAuthorityResponse {
}
export declare const TagCertificateAuthorityResponse: S.Schema<TagCertificateAuthorityResponse>;
export interface UntagCertificateAuthorityRequest {
    CertificateAuthorityArn: string;
    Tags: Tag[];
}
export declare const UntagCertificateAuthorityRequest: S.Schema<UntagCertificateAuthorityRequest>;
export interface UntagCertificateAuthorityResponse {
}
export declare const UntagCertificateAuthorityResponse: S.Schema<UntagCertificateAuthorityResponse>;
export interface UpdateCertificateAuthorityRequest {
    CertificateAuthorityArn: string;
    RevocationConfiguration?: RevocationConfiguration;
    Status?: CertificateAuthorityStatus;
}
export declare const UpdateCertificateAuthorityRequest: S.Schema<UpdateCertificateAuthorityRequest>;
export interface UpdateCertificateAuthorityResponse {
}
export declare const UpdateCertificateAuthorityResponse: S.Schema<UpdateCertificateAuthorityResponse>;
export type CreateCertificateAuthorityError = InvalidArgsException | InvalidPolicyException | InvalidTagException | LimitExceededException | CommonErrors;
/**
 * Creates a root or subordinate private certificate authority (CA). You must specify the CA configuration, an optional configuration for Online Certificate Status Protocol (OCSP) and/or a certificate revocation list (CRL), the CA type, and an optional idempotency token to avoid accidental creation of multiple CAs. The CA configuration specifies the name of the algorithm and key size to be used to create the CA private key, the type of signing algorithm that the CA uses, and X.500 subject information. The OCSP configuration can optionally specify a custom URL for the OCSP responder. The CRL configuration specifies the CRL expiration period in days (the validity period of the CRL), the Amazon S3 bucket that will contain the CRL, and a CNAME alias for the S3 bucket that is included in certificates issued by the CA. If successful, this action returns the Amazon Resource Name (ARN) of the CA.
 *
 * Both Amazon Web Services Private CA and the IAM principal must have permission to write to the S3 bucket that you specify. If the IAM principal making the call does not have permission to write to the bucket, then an exception is thrown. For more information, see Access policies for CRLs in Amazon S3.
 *
 * Amazon Web Services Private CA assets that are stored in Amazon S3 can be protected with encryption. For more information, see Encrypting Your CRLs.
 */
export declare const createCertificateAuthority: API.OperationMethod<CreateCertificateAuthorityRequest, CreateCertificateAuthorityResponse, CreateCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type CreateCertificateAuthorityAuditReportError = InvalidArgsException | InvalidArnException | InvalidStateException | RequestFailedException | RequestInProgressException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an audit report that lists every time that your CA private key is used to issue a certificate. The IssueCertificate and RevokeCertificate actions use the private key.
 *
 * To save the audit report to your designated Amazon S3 bucket, you must create a bucket policy that grants Amazon Web Services Private CA permission to access and write to it. For an example policy, see Prepare an Amazon S3 bucket for audit reports.
 *
 * Amazon Web Services Private CA assets that are stored in Amazon S3 can be protected with encryption. For more information, see Encrypting Your Audit Reports.
 *
 * You can generate a maximum of one report every 30 minutes.
 */
export declare const createCertificateAuthorityAuditReport: API.OperationMethod<CreateCertificateAuthorityAuditReportRequest, CreateCertificateAuthorityAuditReportResponse, CreateCertificateAuthorityAuditReportError, Credentials | HttpClient.HttpClient>;
export type CreatePermissionError = InvalidArnException | InvalidStateException | LimitExceededException | PermissionAlreadyExistsException | RequestFailedException | ResourceNotFoundException | CommonErrors;
/**
 * Grants one or more permissions on a private CA to the Certificate Manager (ACM) service principal (`acm.amazonaws.com`). These permissions allow ACM to issue and renew ACM certificates that reside in the same Amazon Web Services account as the CA.
 *
 * You can list current permissions with the ListPermissions action and revoke them with the DeletePermission action.
 * **About Permissions**
 *
 * - If the private CA and the certificates it issues reside in the same account, you can use `CreatePermission` to grant permissions for ACM to carry out automatic certificate renewals.
 *
 * - For automatic certificate renewal to succeed, the ACM service principal needs permissions to create, retrieve, and list certificates.
 *
 * - If the private CA and the ACM certificates reside in different accounts, then permissions cannot be used to enable automatic renewals. Instead, the ACM certificate owner must set up a resource-based policy to enable cross-account issuance and renewals. For more information, see Using a Resource Based Policy with Amazon Web Services Private CA.
 */
export declare const createPermission: API.OperationMethod<CreatePermissionRequest, CreatePermissionResponse, CreatePermissionError, Credentials | HttpClient.HttpClient>;
export type DeleteCertificateAuthorityError = ConcurrentModificationException | InvalidArnException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a private certificate authority (CA). You must provide the Amazon Resource Name (ARN) of the private CA that you want to delete. You can find the ARN by calling the ListCertificateAuthorities action.
 *
 * Deleting a CA will invalidate other CAs and certificates below it in your CA hierarchy.
 *
 * Before you can delete a CA that you have created and activated, you must disable it. To do this, call the UpdateCertificateAuthority action and set the **CertificateAuthorityStatus** parameter to `DISABLED`.
 *
 * Additionally, you can delete a CA if you are waiting for it to be created (that is, the status of the CA is `CREATING`). You can also delete it if the CA has been created but you haven't yet imported the signed certificate into Amazon Web Services Private CA (that is, the status of the CA is `PENDING_CERTIFICATE`).
 *
 * When you successfully call DeleteCertificateAuthority, the CA's status changes to `DELETED`. However, the CA won't be permanently deleted until the restoration period has passed. By default, if you do not set the `PermanentDeletionTimeInDays` parameter, the CA remains restorable for 30 days. You can set the parameter from 7 to 30 days. The DescribeCertificateAuthority action returns the time remaining in the restoration window of a private CA in the `DELETED` state. To restore an eligible CA, call the RestoreCertificateAuthority action.
 *
 * A private CA can be deleted if it is in the `PENDING_CERTIFICATE`, `CREATING`, `EXPIRED`, `DISABLED`, or `FAILED` state. To delete a CA in the `ACTIVE` state, you must first disable it, or else the delete request results in an exception. If you are deleting a private CA in the `PENDING_CERTIFICATE` or `DISABLED` state, you can set the length of its restoration period to 7-30 days. The default is 30. During this time, the status is set to `DELETED` and the CA can be restored. A private CA deleted in the `CREATING` or `FAILED` state has no assigned restoration period and cannot be restored.
 */
export declare const deleteCertificateAuthority: API.OperationMethod<DeleteCertificateAuthorityRequest, DeleteCertificateAuthorityResponse, DeleteCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type DeletePermissionError = InvalidArnException | InvalidStateException | RequestFailedException | ResourceNotFoundException | CommonErrors;
/**
 * Revokes permissions on a private CA granted to the Certificate Manager (ACM) service principal (acm.amazonaws.com).
 *
 * These permissions allow ACM to issue and renew ACM certificates that reside in the same Amazon Web Services account as the CA. If you revoke these permissions, ACM will no longer renew the affected certificates automatically.
 *
 * Permissions can be granted with the CreatePermission action and listed with the ListPermissions action.
 * **About Permissions**
 *
 * - If the private CA and the certificates it issues reside in the same account, you can use `CreatePermission` to grant permissions for ACM to carry out automatic certificate renewals.
 *
 * - For automatic certificate renewal to succeed, the ACM service principal needs permissions to create, retrieve, and list certificates.
 *
 * - If the private CA and the ACM certificates reside in different accounts, then permissions cannot be used to enable automatic renewals. Instead, the ACM certificate owner must set up a resource-based policy to enable cross-account issuance and renewals. For more information, see Using a Resource Based Policy with Amazon Web Services Private CA.
 */
export declare const deletePermission: API.OperationMethod<DeletePermissionRequest, DeletePermissionResponse, DeletePermissionError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = ConcurrentModificationException | InvalidArnException | InvalidStateException | LockoutPreventedException | RequestFailedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the resource-based policy attached to a private CA. Deletion will remove any access that the policy has granted. If there is no policy attached to the private CA, this action will return successful.
 *
 * If you delete a policy that was applied through Amazon Web Services Resource Access Manager (RAM), the CA will be removed from all shares in which it was included.
 *
 * The Certificate Manager Service Linked Role that the policy supports is not affected when you delete the policy.
 *
 * The current policy can be shown with GetPolicy and updated with PutPolicy.
 * **About Policies**
 *
 * - A policy grants access on a private CA to an Amazon Web Services customer account, to Amazon Web Services Organizations, or to an Amazon Web Services Organizations unit. Policies are under the control of a CA administrator. For more information, see Using a Resource Based Policy with Amazon Web Services Private CA.
 *
 * - A policy permits a user of Certificate Manager (ACM) to issue ACM certificates signed by a CA in another account.
 *
 * - For ACM to manage automatic renewal of these certificates, the ACM user must configure a Service Linked Role (SLR). The SLR allows the ACM service to assume the identity of the user, subject to confirmation against the Amazon Web Services Private CA policy. For more information, see Using a Service Linked Role with ACM.
 *
 * - Updates made in Amazon Web Services Resource Manager (RAM) are reflected in policies. For more information, see Attach a Policy for Cross-Account Access.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest, DeletePolicyResponse, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeCertificateAuthorityError = InvalidArnException | ResourceNotFoundException | CommonErrors;
/**
 * Lists information about your private certificate authority (CA) or one that has been shared with you. You specify the private CA on input by its ARN (Amazon Resource Name). The output contains the status of your CA. This can be any of the following:
 *
 * - `CREATING` - Amazon Web Services Private CA is creating your private certificate authority.
 *
 * - `PENDING_CERTIFICATE` - The certificate is pending. You must use your Amazon Web Services Private CA-hosted or on-premises root or subordinate CA to sign your private CA CSR and then import it into Amazon Web Services Private CA.
 *
 * - `ACTIVE` - Your private CA is active.
 *
 * - `DISABLED` - Your private CA has been disabled.
 *
 * - `EXPIRED` - Your private CA certificate has expired.
 *
 * - `FAILED` - Your private CA has failed. Your CA can fail because of problems such a network outage or back-end Amazon Web Services failure or other errors. A failed CA can never return to the pending state. You must create a new CA.
 *
 * - `DELETED` - Your private CA is within the restoration period, after which it is permanently deleted. The length of time remaining in the CA's restoration period is also included in this action's output.
 */
export declare const describeCertificateAuthority: API.OperationMethod<DescribeCertificateAuthorityRequest, DescribeCertificateAuthorityResponse, DescribeCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type DescribeCertificateAuthorityAuditReportError = InvalidArgsException | InvalidArnException | ResourceNotFoundException | CommonErrors;
/**
 * Lists information about a specific audit report created by calling the CreateCertificateAuthorityAuditReport action. Audit information is created every time the certificate authority (CA) private key is used. The private key is used when you call the IssueCertificate action or the RevokeCertificate action.
 */
export declare const describeCertificateAuthorityAuditReport: API.OperationMethod<DescribeCertificateAuthorityAuditReportRequest, DescribeCertificateAuthorityAuditReportResponse, DescribeCertificateAuthorityAuditReportError, Credentials | HttpClient.HttpClient>;
export type GetCertificateError = InvalidArnException | InvalidStateException | RequestFailedException | RequestInProgressException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a certificate from your private CA or one that has been shared with you. The ARN of the certificate is returned when you call the IssueCertificate action. You must specify both the ARN of your private CA and the ARN of the issued certificate when calling the **GetCertificate** action. You can retrieve the certificate if it is in the **ISSUED**, **EXPIRED**, or **REVOKED** state. You can call the CreateCertificateAuthorityAuditReport action to create a report that contains information about all of the certificates issued and revoked by your private CA.
 */
export declare const getCertificate: API.OperationMethod<GetCertificateRequest, GetCertificateResponse, GetCertificateError, Credentials | HttpClient.HttpClient>;
export type GetCertificateAuthorityCertificateError = InvalidArnException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the certificate and certificate chain for your private certificate authority (CA) or one that has been shared with you. Both the certificate and the chain are base64 PEM-encoded. The chain does not include the CA certificate. Each certificate in the chain signs the one before it.
 */
export declare const getCertificateAuthorityCertificate: API.OperationMethod<GetCertificateAuthorityCertificateRequest, GetCertificateAuthorityCertificateResponse, GetCertificateAuthorityCertificateError, Credentials | HttpClient.HttpClient>;
export type GetCertificateAuthorityCsrError = InvalidArnException | InvalidStateException | RequestFailedException | RequestInProgressException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the certificate signing request (CSR) for your private certificate authority (CA). The CSR is created when you call the CreateCertificateAuthority action. Sign the CSR with your Amazon Web Services Private CA-hosted or on-premises root or subordinate CA. Then import the signed certificate back into Amazon Web Services Private CA by calling the ImportCertificateAuthorityCertificate action. The CSR is returned as a base64 PEM-encoded string.
 */
export declare const getCertificateAuthorityCsr: API.OperationMethod<GetCertificateAuthorityCsrRequest, GetCertificateAuthorityCsrResponse, GetCertificateAuthorityCsrError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = InvalidArnException | InvalidStateException | RequestFailedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the resource-based policy attached to a private CA. If either the private CA resource or the policy cannot be found, this action returns a `ResourceNotFoundException`.
 *
 * The policy can be attached or updated with PutPolicy and removed with DeletePolicy.
 * **About Policies**
 *
 * - A policy grants access on a private CA to an Amazon Web Services customer account, to Amazon Web Services Organizations, or to an Amazon Web Services Organizations unit. Policies are under the control of a CA administrator. For more information, see Using a Resource Based Policy with Amazon Web Services Private CA.
 *
 * - A policy permits a user of Certificate Manager (ACM) to issue ACM certificates signed by a CA in another account.
 *
 * - For ACM to manage automatic renewal of these certificates, the ACM user must configure a Service Linked Role (SLR). The SLR allows the ACM service to assume the identity of the user, subject to confirmation against the Amazon Web Services Private CA policy. For more information, see Using a Service Linked Role with ACM.
 *
 * - Updates made in Amazon Web Services Resource Manager (RAM) are reflected in policies. For more information, see Attach a Policy for Cross-Account Access.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest, GetPolicyResponse, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type ImportCertificateAuthorityCertificateError = CertificateMismatchException | ConcurrentModificationException | InvalidArnException | InvalidRequestException | InvalidStateException | MalformedCertificateException | RequestFailedException | RequestInProgressException | ResourceNotFoundException | CommonErrors;
/**
 * Imports a signed private CA certificate into Amazon Web Services Private CA. This action is used when you are using a chain of trust whose root is located outside Amazon Web Services Private CA. Before you can call this action, the following preparations must in place:
 *
 * - In Amazon Web Services Private CA, call the CreateCertificateAuthority action to create the private CA that you plan to back with the imported certificate.
 *
 * - Call the GetCertificateAuthorityCsr action to generate a certificate signing request (CSR).
 *
 * - Sign the CSR using a root or intermediate CA hosted by either an on-premises PKI hierarchy or by a commercial CA.
 *
 * - Create a certificate chain and copy the signed certificate and the certificate chain to your working directory.
 *
 * Amazon Web Services Private CA supports three scenarios for installing a CA certificate:
 *
 * - Installing a certificate for a root CA hosted by Amazon Web Services Private CA.
 *
 * - Installing a subordinate CA certificate whose parent authority is hosted by Amazon Web Services Private CA.
 *
 * - Installing a subordinate CA certificate whose parent authority is externally hosted.
 *
 * The following additional requirements apply when you import a CA certificate.
 *
 * - Only a self-signed certificate can be imported as a root CA.
 *
 * - A self-signed certificate cannot be imported as a subordinate CA.
 *
 * - Your certificate chain must not include the private CA certificate that you are importing.
 *
 * - Your root CA must be the last certificate in your chain. The subordinate certificate, if any, that your root CA signed must be next to last. The subordinate certificate signed by the preceding subordinate CA must come next, and so on until your chain is built.
 *
 * - The chain must be PEM-encoded.
 *
 * - The maximum allowed size of a certificate is 32 KB.
 *
 * - The maximum allowed size of a certificate chain is 2 MB.
 *
 * *Enforcement of Critical Constraints*
 *
 * Amazon Web Services Private CA allows the following extensions to be marked critical in the imported CA certificate or chain.
 *
 * - Authority key identifier
 *
 * - Basic constraints (*must* be marked critical)
 *
 * - Certificate policies
 *
 * - Extended key usage
 *
 * - Inhibit anyPolicy
 *
 * - Issuer alternative name
 *
 * - Key usage
 *
 * - Name constraints
 *
 * - Policy mappings
 *
 * - Subject alternative name
 *
 * - Subject directory attributes
 *
 * - Subject key identifier
 *
 * - Subject information access
 *
 * Amazon Web Services Private CA rejects the following extensions when they are marked critical in an imported CA certificate or chain.
 *
 * - Authority information access
 *
 * - CRL distribution points
 *
 * - Freshest CRL
 *
 * - Policy constraints
 *
 * Amazon Web Services Private Certificate Authority will also reject any other extension marked as critical not contained on the preceding list of allowed extensions.
 */
export declare const importCertificateAuthorityCertificate: API.OperationMethod<ImportCertificateAuthorityCertificateRequest, ImportCertificateAuthorityCertificateResponse, ImportCertificateAuthorityCertificateError, Credentials | HttpClient.HttpClient>;
export type IssueCertificateError = InvalidArgsException | InvalidArnException | InvalidStateException | LimitExceededException | MalformedCSRException | ResourceNotFoundException | CommonErrors;
/**
 * Uses your private certificate authority (CA), or one that has been shared with you, to issue a client certificate. This action returns the Amazon Resource Name (ARN) of the certificate. You can retrieve the certificate by calling the GetCertificate action and specifying the ARN.
 *
 * You cannot use the ACM **ListCertificateAuthorities** action to retrieve the ARNs of the certificates that you issue by using Amazon Web Services Private CA.
 */
export declare const issueCertificate: API.OperationMethod<IssueCertificateRequest, IssueCertificateResponse, IssueCertificateError, Credentials | HttpClient.HttpClient>;
export type ListCertificateAuthoritiesError = InvalidNextTokenException | CommonErrors;
/**
 * Lists the private certificate authorities that you created by using the CreateCertificateAuthority action.
 */
export declare const listCertificateAuthorities: API.PaginatedOperationMethod<ListCertificateAuthoritiesRequest, ListCertificateAuthoritiesResponse, ListCertificateAuthoritiesError, Credentials | HttpClient.HttpClient, CertificateAuthority>;
export type ListPermissionsError = InvalidArnException | InvalidNextTokenException | InvalidStateException | RequestFailedException | ResourceNotFoundException | CommonErrors;
/**
 * List all permissions on a private CA, if any, granted to the Certificate Manager (ACM) service principal (acm.amazonaws.com).
 *
 * These permissions allow ACM to issue and renew ACM certificates that reside in the same Amazon Web Services account as the CA.
 *
 * Permissions can be granted with the CreatePermission action and revoked with the DeletePermission action.
 * **About Permissions**
 *
 * - If the private CA and the certificates it issues reside in the same account, you can use `CreatePermission` to grant permissions for ACM to carry out automatic certificate renewals.
 *
 * - For automatic certificate renewal to succeed, the ACM service principal needs permissions to create, retrieve, and list certificates.
 *
 * - If the private CA and the ACM certificates reside in different accounts, then permissions cannot be used to enable automatic renewals. Instead, the ACM certificate owner must set up a resource-based policy to enable cross-account issuance and renewals. For more information, see Using a Resource Based Policy with Amazon Web Services Private CA.
 */
export declare const listPermissions: API.PaginatedOperationMethod<ListPermissionsRequest, ListPermissionsResponse, ListPermissionsError, Credentials | HttpClient.HttpClient, Permission>;
export type ListTagsError = InvalidArnException | InvalidStateException | RequestFailedException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags, if any, that are associated with your private CA or one that has been shared with you. Tags are labels that you can use to identify and organize your CAs. Each tag consists of a key and an optional value. Call the TagCertificateAuthority action to add one or more tags to your CA. Call the UntagCertificateAuthority action to remove tags.
 */
export declare const listTags: API.PaginatedOperationMethod<ListTagsRequest, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient, Tag>;
export type PutPolicyError = ConcurrentModificationException | InvalidArnException | InvalidPolicyException | InvalidStateException | LockoutPreventedException | RequestFailedException | ResourceNotFoundException | CommonErrors;
/**
 * Attaches a resource-based policy to a private CA.
 *
 * A policy can also be applied by sharing a private CA through Amazon Web Services Resource Access Manager (RAM). For more information, see Attach a Policy for Cross-Account Access.
 *
 * The policy can be displayed with GetPolicy and removed with DeletePolicy.
 * **About Policies**
 *
 * - A policy grants access on a private CA to an Amazon Web Services customer account, to Amazon Web Services Organizations, or to an Amazon Web Services Organizations unit. Policies are under the control of a CA administrator. For more information, see Using a Resource Based Policy with Amazon Web Services Private CA.
 *
 * - A policy permits a user of Certificate Manager (ACM) to issue ACM certificates signed by a CA in another account.
 *
 * - For ACM to manage automatic renewal of these certificates, the ACM user must configure a Service Linked Role (SLR). The SLR allows the ACM service to assume the identity of the user, subject to confirmation against the Amazon Web Services Private CA policy. For more information, see Using a Service Linked Role with ACM.
 *
 * - Updates made in Amazon Web Services Resource Manager (RAM) are reflected in policies. For more information, see Attach a Policy for Cross-Account Access.
 */
export declare const putPolicy: API.OperationMethod<PutPolicyRequest, PutPolicyResponse, PutPolicyError, Credentials | HttpClient.HttpClient>;
export type RestoreCertificateAuthorityError = InvalidArnException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Restores a certificate authority (CA) that is in the `DELETED` state. You can restore a CA during the period that you defined in the **PermanentDeletionTimeInDays** parameter of the DeleteCertificateAuthority action. Currently, you can specify 7 to 30 days. If you did not specify a **PermanentDeletionTimeInDays** value, by default you can restore the CA at any time in a 30 day period. You can check the time remaining in the restoration period of a private CA in the `DELETED` state by calling the DescribeCertificateAuthority or ListCertificateAuthorities actions. The status of a restored CA is set to its pre-deletion status when the **RestoreCertificateAuthority** action returns. To change its status to `ACTIVE`, call the UpdateCertificateAuthority action. If the private CA was in the `PENDING_CERTIFICATE` state at deletion, you must use the ImportCertificateAuthorityCertificate action to import a certificate authority into the private CA before it can be activated. You cannot restore a CA after the restoration period has ended.
 */
export declare const restoreCertificateAuthority: API.OperationMethod<RestoreCertificateAuthorityRequest, RestoreCertificateAuthorityResponse, RestoreCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type RevokeCertificateError = ConcurrentModificationException | InvalidArnException | InvalidRequestException | InvalidStateException | LimitExceededException | RequestAlreadyProcessedException | RequestFailedException | RequestInProgressException | ResourceNotFoundException | CommonErrors;
/**
 * Revokes a certificate that was issued inside Amazon Web Services Private CA. If you enable a certificate revocation list (CRL) when you create or update your private CA, information about the revoked certificates will be included in the CRL. Amazon Web Services Private CA writes the CRL to an S3 bucket that you specify. A CRL is typically updated approximately 30 minutes after a certificate is revoked. If for any reason the CRL update fails, Amazon Web Services Private CA attempts makes further attempts every 15 minutes. With Amazon CloudWatch, you can create alarms for the metrics `CRLGenerated` and `MisconfiguredCRLBucket`. For more information, see Supported CloudWatch Metrics.
 *
 * Both Amazon Web Services Private CA and the IAM principal must have permission to write to the S3 bucket that you specify. If the IAM principal making the call does not have permission to write to the bucket, then an exception is thrown. For more information, see Access policies for CRLs in Amazon S3.
 *
 * Amazon Web Services Private CA also writes revocation information to the audit report. For more information, see CreateCertificateAuthorityAuditReport.
 *
 * You cannot revoke a root CA self-signed certificate.
 */
export declare const revokeCertificate: API.OperationMethod<RevokeCertificateRequest, RevokeCertificateResponse, RevokeCertificateError, Credentials | HttpClient.HttpClient>;
export type TagCertificateAuthorityError = InvalidArnException | InvalidStateException | InvalidTagException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Adds one or more tags to your private CA. Tags are labels that you can use to identify and organize your Amazon Web Services resources. Each tag consists of a key and an optional value. You specify the private CA on input by its Amazon Resource Name (ARN). You specify the tag by using a key-value pair. You can apply a tag to just one private CA if you want to identify a specific characteristic of that CA, or you can apply the same tag to multiple private CAs if you want to filter for a common relationship among those CAs. To remove one or more tags, use the UntagCertificateAuthority action. Call the ListTags action to see what tags are associated with your CA.
 *
 * To attach tags to a private CA during the creation procedure, a CA administrator must first associate an inline IAM policy with the `CreateCertificateAuthority` action and explicitly allow tagging. For more information, see Attaching tags to a CA at the time of creation.
 */
export declare const tagCertificateAuthority: API.OperationMethod<TagCertificateAuthorityRequest, TagCertificateAuthorityResponse, TagCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type UntagCertificateAuthorityError = InvalidArnException | InvalidStateException | InvalidTagException | ResourceNotFoundException | CommonErrors;
/**
 * Remove one or more tags from your private CA. A tag consists of a key-value pair. If you do not specify the value portion of the tag when calling this action, the tag will be removed regardless of value. If you specify a value, the tag is removed only if it is associated with the specified value. To add tags to a private CA, use the TagCertificateAuthority. Call the ListTags action to see what tags are associated with your CA.
 */
export declare const untagCertificateAuthority: API.OperationMethod<UntagCertificateAuthorityRequest, UntagCertificateAuthorityResponse, UntagCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type UpdateCertificateAuthorityError = ConcurrentModificationException | InvalidArgsException | InvalidArnException | InvalidPolicyException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the status or configuration of a private certificate authority (CA). Your private CA must be in the `ACTIVE` or `DISABLED` state before you can update it. You can disable a private CA that is in the `ACTIVE` state or make a CA that is in the `DISABLED` state active again.
 *
 * Both Amazon Web Services Private CA and the IAM principal must have permission to write to the S3 bucket that you specify. If the IAM principal making the call does not have permission to write to the bucket, then an exception is thrown. For more information, see Access policies for CRLs in Amazon S3.
 */
export declare const updateCertificateAuthority: API.OperationMethod<UpdateCertificateAuthorityRequest, UpdateCertificateAuthorityResponse, UpdateCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=acm-pca.d.ts.map