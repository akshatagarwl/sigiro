import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const CreateChimeWebhookConfigurationException_base: S.Class<CreateChimeWebhookConfigurationException, S.TaggedStruct<"CreateChimeWebhookConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class CreateChimeWebhookConfigurationException extends /*@__PURE__*/ CreateChimeWebhookConfigurationException_base {
}
declare const CreateSlackChannelConfigurationException_base: S.Class<CreateSlackChannelConfigurationException, S.TaggedStruct<"CreateSlackChannelConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class CreateSlackChannelConfigurationException extends /*@__PURE__*/ CreateSlackChannelConfigurationException_base {
}
declare const CreateTeamsChannelConfigurationException_base: S.Class<CreateTeamsChannelConfigurationException, S.TaggedStruct<"CreateTeamsChannelConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class CreateTeamsChannelConfigurationException extends /*@__PURE__*/ CreateTeamsChannelConfigurationException_base {
}
declare const DeleteChimeWebhookConfigurationException_base: S.Class<DeleteChimeWebhookConfigurationException, S.TaggedStruct<"DeleteChimeWebhookConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DeleteChimeWebhookConfigurationException extends /*@__PURE__*/ DeleteChimeWebhookConfigurationException_base {
}
declare const DeleteMicrosoftTeamsUserIdentityException_base: S.Class<DeleteMicrosoftTeamsUserIdentityException, S.TaggedStruct<"DeleteMicrosoftTeamsUserIdentityException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DeleteMicrosoftTeamsUserIdentityException extends /*@__PURE__*/ DeleteMicrosoftTeamsUserIdentityException_base {
}
declare const DeleteSlackChannelConfigurationException_base: S.Class<DeleteSlackChannelConfigurationException, S.TaggedStruct<"DeleteSlackChannelConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DeleteSlackChannelConfigurationException extends /*@__PURE__*/ DeleteSlackChannelConfigurationException_base {
}
declare const DeleteSlackUserIdentityException_base: S.Class<DeleteSlackUserIdentityException, S.TaggedStruct<"DeleteSlackUserIdentityException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DeleteSlackUserIdentityException extends /*@__PURE__*/ DeleteSlackUserIdentityException_base {
}
declare const DeleteSlackWorkspaceAuthorizationFault_base: S.Class<DeleteSlackWorkspaceAuthorizationFault, S.TaggedStruct<"DeleteSlackWorkspaceAuthorizationFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DeleteSlackWorkspaceAuthorizationFault extends /*@__PURE__*/ DeleteSlackWorkspaceAuthorizationFault_base {
}
declare const DeleteTeamsChannelConfigurationException_base: S.Class<DeleteTeamsChannelConfigurationException, S.TaggedStruct<"DeleteTeamsChannelConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DeleteTeamsChannelConfigurationException extends /*@__PURE__*/ DeleteTeamsChannelConfigurationException_base {
}
declare const DeleteTeamsConfiguredTeamException_base: S.Class<DeleteTeamsConfiguredTeamException, S.TaggedStruct<"DeleteTeamsConfiguredTeamException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DeleteTeamsConfiguredTeamException extends /*@__PURE__*/ DeleteTeamsConfiguredTeamException_base {
}
declare const DescribeChimeWebhookConfigurationsException_base: S.Class<DescribeChimeWebhookConfigurationsException, S.TaggedStruct<"DescribeChimeWebhookConfigurationsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DescribeChimeWebhookConfigurationsException extends /*@__PURE__*/ DescribeChimeWebhookConfigurationsException_base {
}
declare const DescribeSlackChannelConfigurationsException_base: S.Class<DescribeSlackChannelConfigurationsException, S.TaggedStruct<"DescribeSlackChannelConfigurationsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DescribeSlackChannelConfigurationsException extends /*@__PURE__*/ DescribeSlackChannelConfigurationsException_base {
}
declare const DescribeSlackUserIdentitiesException_base: S.Class<DescribeSlackUserIdentitiesException, S.TaggedStruct<"DescribeSlackUserIdentitiesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DescribeSlackUserIdentitiesException extends /*@__PURE__*/ DescribeSlackUserIdentitiesException_base {
}
declare const DescribeSlackWorkspacesException_base: S.Class<DescribeSlackWorkspacesException, S.TaggedStruct<"DescribeSlackWorkspacesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DescribeSlackWorkspacesException extends /*@__PURE__*/ DescribeSlackWorkspacesException_base {
}
declare const GetAccountPreferencesException_base: S.Class<GetAccountPreferencesException, S.TaggedStruct<"GetAccountPreferencesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class GetAccountPreferencesException extends /*@__PURE__*/ GetAccountPreferencesException_base {
}
declare const GetTeamsChannelConfigurationException_base: S.Class<GetTeamsChannelConfigurationException, S.TaggedStruct<"GetTeamsChannelConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class GetTeamsChannelConfigurationException extends /*@__PURE__*/ GetTeamsChannelConfigurationException_base {
}
declare const InternalServiceError_base: S.Class<InternalServiceError, S.TaggedStruct<"InternalServiceError", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceError extends /*@__PURE__*/ InternalServiceError_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ListMicrosoftTeamsConfiguredTeamsException_base: S.Class<ListMicrosoftTeamsConfiguredTeamsException, S.TaggedStruct<"ListMicrosoftTeamsConfiguredTeamsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ListMicrosoftTeamsConfiguredTeamsException extends /*@__PURE__*/ ListMicrosoftTeamsConfiguredTeamsException_base {
}
declare const ListMicrosoftTeamsUserIdentitiesException_base: S.Class<ListMicrosoftTeamsUserIdentitiesException, S.TaggedStruct<"ListMicrosoftTeamsUserIdentitiesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ListMicrosoftTeamsUserIdentitiesException extends /*@__PURE__*/ ListMicrosoftTeamsUserIdentitiesException_base {
}
declare const ListTeamsChannelConfigurationsException_base: S.Class<ListTeamsChannelConfigurationsException, S.TaggedStruct<"ListTeamsChannelConfigurationsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ListTeamsChannelConfigurationsException extends /*@__PURE__*/ ListTeamsChannelConfigurationsException_base {
}
declare const MicrosoftTeamsTeamNotConfigured_base: S.Class<MicrosoftTeamsTeamNotConfigured, S.TaggedStruct<"MicrosoftTeamsTeamNotConfigured", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MicrosoftTeamsTeamNotConfigured extends /*@__PURE__*/ MicrosoftTeamsTeamNotConfigured_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const SlackWorkspaceNotAuthorized_base: S.Class<SlackWorkspaceNotAuthorized, S.TaggedStruct<"SlackWorkspaceNotAuthorized", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SlackWorkspaceNotAuthorized extends /*@__PURE__*/ SlackWorkspaceNotAuthorized_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const UpdateAccountPreferencesException_base: S.Class<UpdateAccountPreferencesException, S.TaggedStruct<"UpdateAccountPreferencesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class UpdateAccountPreferencesException extends /*@__PURE__*/ UpdateAccountPreferencesException_base {
}
declare const UpdateChimeWebhookConfigurationException_base: S.Class<UpdateChimeWebhookConfigurationException, S.TaggedStruct<"UpdateChimeWebhookConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class UpdateChimeWebhookConfigurationException extends /*@__PURE__*/ UpdateChimeWebhookConfigurationException_base {
}
declare const UpdateSlackChannelConfigurationException_base: S.Class<UpdateSlackChannelConfigurationException, S.TaggedStruct<"UpdateSlackChannelConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class UpdateSlackChannelConfigurationException extends /*@__PURE__*/ UpdateSlackChannelConfigurationException_base {
}
declare const UpdateTeamsChannelConfigurationException_base: S.Class<UpdateTeamsChannelConfigurationException, S.TaggedStruct<"UpdateTeamsChannelConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class UpdateTeamsChannelConfigurationException extends /*@__PURE__*/ UpdateTeamsChannelConfigurationException_base {
}
export type ResourceIdentifier = string;
export type ChatConfigurationArn = string;
export interface AssociateToConfigurationRequest {
    Resource: string;
    ChatConfiguration: string;
}
export declare const AssociateToConfigurationRequest: S.Schema<AssociateToConfigurationRequest>;
export interface AssociateToConfigurationResult {
}
export declare const AssociateToConfigurationResult: S.Schema<AssociateToConfigurationResult>;
export type ChimeWebhookDescription = string | redacted.Redacted<string>;
export type ChimeWebhookUrl = string | redacted.Redacted<string>;
export type Arn = string;
export type SnsTopicArnList = string[];
export declare const SnsTopicArnList: any;
export type ConfigurationName = string;
export type CustomerCwLogLevel = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    TagKey: string;
    TagValue: string;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export interface CreateChimeWebhookConfigurationRequest {
    WebhookDescription: string | redacted.Redacted<string>;
    WebhookUrl: string | redacted.Redacted<string>;
    SnsTopicArns: string[];
    IamRoleArn: string;
    ConfigurationName: string;
    LoggingLevel?: string;
    Tags?: Tag[];
}
export declare const CreateChimeWebhookConfigurationRequest: S.Schema<CreateChimeWebhookConfigurationRequest>;
export type ResourceState = string;
export interface ChimeWebhookConfiguration {
    WebhookDescription: string | redacted.Redacted<string>;
    ChatConfigurationArn: string;
    IamRoleArn: string;
    SnsTopicArns: string[];
    ConfigurationName?: string;
    LoggingLevel?: string;
    Tags?: Tag[];
    State?: string;
    StateReason?: string;
}
export declare const ChimeWebhookConfiguration: S.Schema<ChimeWebhookConfiguration>;
export interface CreateChimeWebhookConfigurationResult {
    WebhookConfiguration?: ChimeWebhookConfiguration;
}
export declare const CreateChimeWebhookConfigurationResult: S.Schema<CreateChimeWebhookConfigurationResult>;
export interface CustomActionDefinition {
    CommandText: string;
}
export declare const CustomActionDefinition: S.Schema<CustomActionDefinition>;
export type CustomActionAliasName = string;
export type CustomActionAttachmentNotificationType = string;
export type CustomActionButtonText = string;
export type CustomActionAttachmentCriteriaOperator = "HAS_VALUE" | "EQUALS" | (string & {});
export declare const CustomActionAttachmentCriteriaOperator: any;
export interface CustomActionAttachmentCriteria {
    Operator: CustomActionAttachmentCriteriaOperator;
    VariableName: string;
    Value?: string;
}
export declare const CustomActionAttachmentCriteria: S.Schema<CustomActionAttachmentCriteria>;
export type CustomActionAttachmentCriteriaList = CustomActionAttachmentCriteria[];
export declare const CustomActionAttachmentCriteriaList: any;
export type CustomActionAttachmentVariables = {
    [key: string]: string | undefined;
};
export declare const CustomActionAttachmentVariables: any;
export interface CustomActionAttachment {
    NotificationType: string;
    ButtonText?: string;
    Criteria?: CustomActionAttachmentCriteria[];
    Variables?: {
        [key: string]: string | undefined;
    };
}
export declare const CustomActionAttachment: S.Schema<CustomActionAttachment>;
export type CustomActionAttachmentList = CustomActionAttachment[];
export declare const CustomActionAttachmentList: any;
export type TagList = Tag[];
export declare const TagList: any;
export type ClientToken = string;
export type CustomActionName = string;
export interface CreateCustomActionRequest {
    Definition: CustomActionDefinition;
    AliasName?: string;
    Attachments?: CustomActionAttachment[];
    Tags?: Tag[];
    ClientToken?: string;
    ActionName: string;
}
export declare const CreateCustomActionRequest: S.Schema<CreateCustomActionRequest>;
export type CustomActionArn = string;
export interface CreateCustomActionResult {
    CustomActionArn: string;
}
export declare const CreateCustomActionResult: S.Schema<CreateCustomActionResult>;
export type TeamsChannelId = string;
export type TeamsChannelName = string | redacted.Redacted<string>;
export type UUID = string;
export type TeamName = string | redacted.Redacted<string>;
export type GuardrailPolicyArn = string;
export type GuardrailPolicyArnList = string[];
export declare const GuardrailPolicyArnList: any;
export type BooleanAccountPreference = boolean;
export interface CreateTeamsChannelConfigurationRequest {
    ChannelId: string;
    ChannelName?: string | redacted.Redacted<string>;
    TeamId: string;
    TeamName?: string | redacted.Redacted<string>;
    TenantId: string;
    SnsTopicArns?: string[];
    IamRoleArn: string;
    ConfigurationName: string;
    LoggingLevel?: string;
    GuardrailPolicyArns?: string[];
    UserAuthorizationRequired?: boolean;
    Tags?: Tag[];
}
export declare const CreateTeamsChannelConfigurationRequest: S.Schema<CreateTeamsChannelConfigurationRequest>;
export interface TeamsChannelConfiguration {
    ChannelId: string;
    ChannelName?: string | redacted.Redacted<string>;
    TeamId: string;
    TeamName?: string | redacted.Redacted<string>;
    TenantId: string;
    ChatConfigurationArn: string;
    IamRoleArn: string;
    SnsTopicArns: string[];
    ConfigurationName?: string;
    LoggingLevel?: string;
    GuardrailPolicyArns?: string[];
    UserAuthorizationRequired?: boolean;
    Tags?: Tag[];
    State?: string;
    StateReason?: string;
}
export declare const TeamsChannelConfiguration: S.Schema<TeamsChannelConfiguration>;
export interface CreateTeamsChannelConfigurationResult {
    ChannelConfiguration?: TeamsChannelConfiguration;
}
export declare const CreateTeamsChannelConfigurationResult: S.Schema<CreateTeamsChannelConfigurationResult>;
export type SlackTeamId = string;
export type SlackChannelId = string;
export type SlackChannelDisplayName = string | redacted.Redacted<string>;
export interface CreateSlackChannelConfigurationRequest {
    SlackTeamId: string;
    SlackChannelId: string;
    SlackChannelName?: string | redacted.Redacted<string>;
    SnsTopicArns?: string[];
    IamRoleArn: string;
    ConfigurationName: string;
    LoggingLevel?: string;
    GuardrailPolicyArns?: string[];
    UserAuthorizationRequired?: boolean;
    Tags?: Tag[];
}
export declare const CreateSlackChannelConfigurationRequest: S.Schema<CreateSlackChannelConfigurationRequest>;
export type SlackTeamName = string;
export interface SlackChannelConfiguration {
    SlackTeamName: string;
    SlackTeamId: string;
    SlackChannelId: string;
    SlackChannelName: string | redacted.Redacted<string>;
    ChatConfigurationArn: string;
    IamRoleArn: string;
    SnsTopicArns: string[];
    ConfigurationName?: string;
    LoggingLevel?: string;
    GuardrailPolicyArns?: string[];
    UserAuthorizationRequired?: boolean;
    Tags?: Tag[];
    State?: string;
    StateReason?: string;
}
export declare const SlackChannelConfiguration: S.Schema<SlackChannelConfiguration>;
export interface CreateSlackChannelConfigurationResult {
    ChannelConfiguration?: SlackChannelConfiguration;
}
export declare const CreateSlackChannelConfigurationResult: S.Schema<CreateSlackChannelConfigurationResult>;
export interface DeleteChimeWebhookConfigurationRequest {
    ChatConfigurationArn: string;
}
export declare const DeleteChimeWebhookConfigurationRequest: S.Schema<DeleteChimeWebhookConfigurationRequest>;
export interface DeleteChimeWebhookConfigurationResult {
}
export declare const DeleteChimeWebhookConfigurationResult: S.Schema<DeleteChimeWebhookConfigurationResult>;
export interface DeleteCustomActionRequest {
    CustomActionArn: string;
}
export declare const DeleteCustomActionRequest: S.Schema<DeleteCustomActionRequest>;
export interface DeleteCustomActionResult {
}
export declare const DeleteCustomActionResult: S.Schema<DeleteCustomActionResult>;
export interface DeleteTeamsChannelConfigurationRequest {
    ChatConfigurationArn: string;
}
export declare const DeleteTeamsChannelConfigurationRequest: S.Schema<DeleteTeamsChannelConfigurationRequest>;
export interface DeleteTeamsChannelConfigurationResult {
}
export declare const DeleteTeamsChannelConfigurationResult: S.Schema<DeleteTeamsChannelConfigurationResult>;
export interface DeleteTeamsConfiguredTeamRequest {
    TeamId: string;
}
export declare const DeleteTeamsConfiguredTeamRequest: S.Schema<DeleteTeamsConfiguredTeamRequest>;
export interface DeleteTeamsConfiguredTeamResult {
}
export declare const DeleteTeamsConfiguredTeamResult: S.Schema<DeleteTeamsConfiguredTeamResult>;
export interface DeleteMicrosoftTeamsUserIdentityRequest {
    ChatConfigurationArn: string;
    UserId: string;
}
export declare const DeleteMicrosoftTeamsUserIdentityRequest: S.Schema<DeleteMicrosoftTeamsUserIdentityRequest>;
export interface DeleteMicrosoftTeamsUserIdentityResult {
}
export declare const DeleteMicrosoftTeamsUserIdentityResult: S.Schema<DeleteMicrosoftTeamsUserIdentityResult>;
export interface DeleteSlackChannelConfigurationRequest {
    ChatConfigurationArn: string;
}
export declare const DeleteSlackChannelConfigurationRequest: S.Schema<DeleteSlackChannelConfigurationRequest>;
export interface DeleteSlackChannelConfigurationResult {
}
export declare const DeleteSlackChannelConfigurationResult: S.Schema<DeleteSlackChannelConfigurationResult>;
export type SlackUserId = string;
export interface DeleteSlackUserIdentityRequest {
    ChatConfigurationArn: string;
    SlackTeamId: string;
    SlackUserId: string;
}
export declare const DeleteSlackUserIdentityRequest: S.Schema<DeleteSlackUserIdentityRequest>;
export interface DeleteSlackUserIdentityResult {
}
export declare const DeleteSlackUserIdentityResult: S.Schema<DeleteSlackUserIdentityResult>;
export interface DeleteSlackWorkspaceAuthorizationRequest {
    SlackTeamId: string;
}
export declare const DeleteSlackWorkspaceAuthorizationRequest: S.Schema<DeleteSlackWorkspaceAuthorizationRequest>;
export interface DeleteSlackWorkspaceAuthorizationResult {
}
export declare const DeleteSlackWorkspaceAuthorizationResult: S.Schema<DeleteSlackWorkspaceAuthorizationResult>;
export type MaxResults = number;
export type PaginationToken = string;
export interface DescribeChimeWebhookConfigurationsRequest {
    MaxResults?: number;
    NextToken?: string;
    ChatConfigurationArn?: string;
}
export declare const DescribeChimeWebhookConfigurationsRequest: S.Schema<DescribeChimeWebhookConfigurationsRequest>;
export type ChimeWebhookConfigurationList = ChimeWebhookConfiguration[];
export declare const ChimeWebhookConfigurationList: any;
export interface DescribeChimeWebhookConfigurationsResult {
    NextToken?: string;
    WebhookConfigurations?: ChimeWebhookConfiguration[];
}
export declare const DescribeChimeWebhookConfigurationsResult: S.Schema<DescribeChimeWebhookConfigurationsResult>;
export interface DescribeSlackChannelConfigurationsRequest {
    MaxResults?: number;
    NextToken?: string;
    ChatConfigurationArn?: string;
}
export declare const DescribeSlackChannelConfigurationsRequest: S.Schema<DescribeSlackChannelConfigurationsRequest>;
export type SlackChannelConfigurationList = SlackChannelConfiguration[];
export declare const SlackChannelConfigurationList: any;
export interface DescribeSlackChannelConfigurationsResult {
    NextToken?: string;
    SlackChannelConfigurations?: SlackChannelConfiguration[];
}
export declare const DescribeSlackChannelConfigurationsResult: S.Schema<DescribeSlackChannelConfigurationsResult>;
export interface DescribeSlackUserIdentitiesRequest {
    ChatConfigurationArn?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const DescribeSlackUserIdentitiesRequest: S.Schema<DescribeSlackUserIdentitiesRequest>;
export type AwsUserIdentity = string;
export interface SlackUserIdentity {
    IamRoleArn: string;
    ChatConfigurationArn: string;
    SlackTeamId: string;
    SlackUserId: string;
    AwsUserIdentity?: string;
}
export declare const SlackUserIdentity: S.Schema<SlackUserIdentity>;
export type SlackUserIdentitiesList = SlackUserIdentity[];
export declare const SlackUserIdentitiesList: any;
export interface DescribeSlackUserIdentitiesResult {
    SlackUserIdentities?: SlackUserIdentity[];
    NextToken?: string;
}
export declare const DescribeSlackUserIdentitiesResult: S.Schema<DescribeSlackUserIdentitiesResult>;
export interface DescribeSlackWorkspacesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeSlackWorkspacesRequest: S.Schema<DescribeSlackWorkspacesRequest>;
export interface SlackWorkspace {
    SlackTeamId: string;
    SlackTeamName: string;
    State?: string;
    StateReason?: string;
}
export declare const SlackWorkspace: S.Schema<SlackWorkspace>;
export type SlackWorkspacesList = SlackWorkspace[];
export declare const SlackWorkspacesList: any;
export interface DescribeSlackWorkspacesResult {
    SlackWorkspaces?: SlackWorkspace[];
    NextToken?: string;
}
export declare const DescribeSlackWorkspacesResult: S.Schema<DescribeSlackWorkspacesResult>;
export interface DisassociateFromConfigurationRequest {
    Resource: string;
    ChatConfiguration: string;
}
export declare const DisassociateFromConfigurationRequest: S.Schema<DisassociateFromConfigurationRequest>;
export interface DisassociateFromConfigurationResult {
}
export declare const DisassociateFromConfigurationResult: S.Schema<DisassociateFromConfigurationResult>;
export interface GetAccountPreferencesRequest {
}
export declare const GetAccountPreferencesRequest: S.Schema<GetAccountPreferencesRequest>;
export interface AccountPreferences {
    UserAuthorizationRequired?: boolean;
    TrainingDataCollectionEnabled?: boolean;
}
export declare const AccountPreferences: S.Schema<AccountPreferences>;
export interface GetAccountPreferencesResult {
    AccountPreferences?: AccountPreferences;
}
export declare const GetAccountPreferencesResult: S.Schema<GetAccountPreferencesResult>;
export interface GetCustomActionRequest {
    CustomActionArn: string;
}
export declare const GetCustomActionRequest: S.Schema<GetCustomActionRequest>;
export interface CustomAction {
    CustomActionArn: string;
    Definition: CustomActionDefinition;
    AliasName?: string;
    Attachments?: CustomActionAttachment[];
    ActionName?: string;
}
export declare const CustomAction: S.Schema<CustomAction>;
export interface GetCustomActionResult {
    CustomAction?: CustomAction;
}
export declare const GetCustomActionResult: S.Schema<GetCustomActionResult>;
export interface GetTeamsChannelConfigurationRequest {
    ChatConfigurationArn: string;
}
export declare const GetTeamsChannelConfigurationRequest: S.Schema<GetTeamsChannelConfigurationRequest>;
export interface GetTeamsChannelConfigurationResult {
    ChannelConfiguration?: TeamsChannelConfiguration;
}
export declare const GetTeamsChannelConfigurationResult: S.Schema<GetTeamsChannelConfigurationResult>;
export interface ListAssociationsRequest {
    ChatConfiguration: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListAssociationsRequest: S.Schema<ListAssociationsRequest>;
export interface AssociationListing {
    Resource: string;
}
export declare const AssociationListing: S.Schema<AssociationListing>;
export type AssociationList = AssociationListing[];
export declare const AssociationList: any;
export interface ListAssociationsResult {
    Associations: AssociationListing[];
    NextToken?: string;
}
export declare const ListAssociationsResult: S.Schema<ListAssociationsResult>;
export interface ListCustomActionsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListCustomActionsRequest: S.Schema<ListCustomActionsRequest>;
export type CustomActionArnList = string[];
export declare const CustomActionArnList: any;
export interface ListCustomActionsResult {
    CustomActions: string[];
    NextToken?: string;
}
export declare const ListCustomActionsResult: S.Schema<ListCustomActionsResult>;
export interface ListTeamsChannelConfigurationsRequest {
    MaxResults?: number;
    NextToken?: string;
    TeamId?: string;
}
export declare const ListTeamsChannelConfigurationsRequest: S.Schema<ListTeamsChannelConfigurationsRequest>;
export type TeamChannelConfigurationsList = TeamsChannelConfiguration[];
export declare const TeamChannelConfigurationsList: any;
export interface ListTeamsChannelConfigurationsResult {
    NextToken?: string;
    TeamChannelConfigurations?: TeamsChannelConfiguration[];
}
export declare const ListTeamsChannelConfigurationsResult: S.Schema<ListTeamsChannelConfigurationsResult>;
export interface ListMicrosoftTeamsConfiguredTeamsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListMicrosoftTeamsConfiguredTeamsRequest: S.Schema<ListMicrosoftTeamsConfiguredTeamsRequest>;
export interface ConfiguredTeam {
    TenantId: string;
    TeamId: string;
    TeamName?: string;
    State?: string;
    StateReason?: string;
}
export declare const ConfiguredTeam: S.Schema<ConfiguredTeam>;
export type ConfiguredTeamsList = ConfiguredTeam[];
export declare const ConfiguredTeamsList: any;
export interface ListMicrosoftTeamsConfiguredTeamsResult {
    ConfiguredTeams?: ConfiguredTeam[];
    NextToken?: string;
}
export declare const ListMicrosoftTeamsConfiguredTeamsResult: S.Schema<ListMicrosoftTeamsConfiguredTeamsResult>;
export interface ListMicrosoftTeamsUserIdentitiesRequest {
    ChatConfigurationArn?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListMicrosoftTeamsUserIdentitiesRequest: S.Schema<ListMicrosoftTeamsUserIdentitiesRequest>;
export interface TeamsUserIdentity {
    IamRoleArn: string;
    ChatConfigurationArn: string;
    TeamId: string;
    UserId?: string;
    AwsUserIdentity?: string;
    TeamsChannelId?: string;
    TeamsTenantId?: string;
}
export declare const TeamsUserIdentity: S.Schema<TeamsUserIdentity>;
export type TeamsUserIdentitiesList = TeamsUserIdentity[];
export declare const TeamsUserIdentitiesList: any;
export interface ListMicrosoftTeamsUserIdentitiesResult {
    TeamsUserIdentities?: TeamsUserIdentity[];
    NextToken?: string;
}
export declare const ListMicrosoftTeamsUserIdentitiesResult: S.Schema<ListMicrosoftTeamsUserIdentitiesResult>;
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAccountPreferencesRequest {
    UserAuthorizationRequired?: boolean;
    TrainingDataCollectionEnabled?: boolean;
}
export declare const UpdateAccountPreferencesRequest: S.Schema<UpdateAccountPreferencesRequest>;
export interface UpdateAccountPreferencesResult {
    AccountPreferences?: AccountPreferences;
}
export declare const UpdateAccountPreferencesResult: S.Schema<UpdateAccountPreferencesResult>;
export interface UpdateChimeWebhookConfigurationRequest {
    ChatConfigurationArn: string;
    WebhookDescription?: string | redacted.Redacted<string>;
    WebhookUrl?: string | redacted.Redacted<string>;
    SnsTopicArns?: string[];
    IamRoleArn?: string;
    LoggingLevel?: string;
}
export declare const UpdateChimeWebhookConfigurationRequest: S.Schema<UpdateChimeWebhookConfigurationRequest>;
export interface UpdateChimeWebhookConfigurationResult {
    WebhookConfiguration?: ChimeWebhookConfiguration;
}
export declare const UpdateChimeWebhookConfigurationResult: S.Schema<UpdateChimeWebhookConfigurationResult>;
export interface UpdateCustomActionRequest {
    CustomActionArn: string;
    Definition: CustomActionDefinition;
    AliasName?: string;
    Attachments?: CustomActionAttachment[];
}
export declare const UpdateCustomActionRequest: S.Schema<UpdateCustomActionRequest>;
export interface UpdateCustomActionResult {
    CustomActionArn: string;
}
export declare const UpdateCustomActionResult: S.Schema<UpdateCustomActionResult>;
export interface UpdateTeamsChannelConfigurationRequest {
    ChatConfigurationArn: string;
    ChannelId: string;
    ChannelName?: string | redacted.Redacted<string>;
    SnsTopicArns?: string[];
    IamRoleArn?: string;
    LoggingLevel?: string;
    GuardrailPolicyArns?: string[];
    UserAuthorizationRequired?: boolean;
}
export declare const UpdateTeamsChannelConfigurationRequest: S.Schema<UpdateTeamsChannelConfigurationRequest>;
export interface UpdateTeamsChannelConfigurationResult {
    ChannelConfiguration?: TeamsChannelConfiguration;
}
export declare const UpdateTeamsChannelConfigurationResult: S.Schema<UpdateTeamsChannelConfigurationResult>;
export interface UpdateSlackChannelConfigurationRequest {
    ChatConfigurationArn: string;
    SlackChannelId: string;
    SlackChannelName?: string | redacted.Redacted<string>;
    SnsTopicArns?: string[];
    IamRoleArn?: string;
    LoggingLevel?: string;
    GuardrailPolicyArns?: string[];
    UserAuthorizationRequired?: boolean;
}
export declare const UpdateSlackChannelConfigurationRequest: S.Schema<UpdateSlackChannelConfigurationRequest>;
export interface UpdateSlackChannelConfigurationResult {
    ChannelConfiguration?: SlackChannelConfiguration;
}
export declare const UpdateSlackChannelConfigurationResult: S.Schema<UpdateSlackChannelConfigurationResult>;
export type ErrorMessage = string;
export type AssociateToConfigurationError = InternalServiceError | InvalidRequestException | UnauthorizedException | ResourceNotFoundException | CommonErrors;
/**
 * Links a resource (for example, a custom action) to a channel configuration.
 */
export declare const associateToConfiguration: API.OperationMethod<AssociateToConfigurationRequest, AssociateToConfigurationResult, AssociateToConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateChimeWebhookConfigurationError = ConflictException | CreateChimeWebhookConfigurationException | InvalidParameterException | InvalidRequestException | LimitExceededException | CommonErrors;
/**
 * Creates an AWS Chatbot configuration for Amazon Chime.
 */
export declare const createChimeWebhookConfiguration: API.OperationMethod<CreateChimeWebhookConfigurationRequest, CreateChimeWebhookConfigurationResult, CreateChimeWebhookConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateCustomActionError = ConflictException | InternalServiceError | InvalidRequestException | LimitExceededException | UnauthorizedException | CommonErrors;
/**
 * Creates a custom action that can be invoked as an alias or as a button on a notification.
 */
export declare const createCustomAction: API.OperationMethod<CreateCustomActionRequest, CreateCustomActionResult, CreateCustomActionError, Credentials | HttpClient.HttpClient>;
export type CreateMicrosoftTeamsChannelConfigurationError = ConflictException | CreateTeamsChannelConfigurationException | InvalidParameterException | InvalidRequestException | LimitExceededException | MicrosoftTeamsTeamNotConfigured | CommonErrors;
/**
 * Creates an AWS Chatbot configuration for Microsoft Teams.
 */
export declare const createMicrosoftTeamsChannelConfiguration: API.OperationMethod<CreateTeamsChannelConfigurationRequest, CreateTeamsChannelConfigurationResult, CreateMicrosoftTeamsChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateSlackChannelConfigurationError = ConflictException | CreateSlackChannelConfigurationException | InvalidParameterException | InvalidRequestException | LimitExceededException | SlackWorkspaceNotAuthorized | CommonErrors;
/**
 * Creates an AWS Chatbot confugration for Slack.
 */
export declare const createSlackChannelConfiguration: API.OperationMethod<CreateSlackChannelConfigurationRequest, CreateSlackChannelConfigurationResult, CreateSlackChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteChimeWebhookConfigurationError = DeleteChimeWebhookConfigurationException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a Amazon Chime webhook configuration for AWS Chatbot.
 */
export declare const deleteChimeWebhookConfiguration: API.OperationMethod<DeleteChimeWebhookConfigurationRequest, DeleteChimeWebhookConfigurationResult, DeleteChimeWebhookConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomActionError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a custom action.
 */
export declare const deleteCustomAction: API.OperationMethod<DeleteCustomActionRequest, DeleteCustomActionResult, DeleteCustomActionError, Credentials | HttpClient.HttpClient>;
export type DeleteMicrosoftTeamsChannelConfigurationError = DeleteTeamsChannelConfigurationException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a Microsoft Teams channel configuration for AWS Chatbot
 */
export declare const deleteMicrosoftTeamsChannelConfiguration: API.OperationMethod<DeleteTeamsChannelConfigurationRequest, DeleteTeamsChannelConfigurationResult, DeleteMicrosoftTeamsChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteMicrosoftTeamsConfiguredTeamError = DeleteTeamsConfiguredTeamException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the Microsoft Teams team authorization allowing for channels to be configured in that Microsoft Teams team. Note that the Microsoft Teams team must have no channels configured to remove it.
 */
export declare const deleteMicrosoftTeamsConfiguredTeam: API.OperationMethod<DeleteTeamsConfiguredTeamRequest, DeleteTeamsConfiguredTeamResult, DeleteMicrosoftTeamsConfiguredTeamError, Credentials | HttpClient.HttpClient>;
export type DeleteMicrosoftTeamsUserIdentityError = DeleteMicrosoftTeamsUserIdentityException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Identifes a user level permission for a channel configuration.
 */
export declare const deleteMicrosoftTeamsUserIdentity: API.OperationMethod<DeleteMicrosoftTeamsUserIdentityRequest, DeleteMicrosoftTeamsUserIdentityResult, DeleteMicrosoftTeamsUserIdentityError, Credentials | HttpClient.HttpClient>;
export type DeleteSlackChannelConfigurationError = DeleteSlackChannelConfigurationException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a Slack channel configuration for AWS Chatbot
 */
export declare const deleteSlackChannelConfiguration: API.OperationMethod<DeleteSlackChannelConfigurationRequest, DeleteSlackChannelConfigurationResult, DeleteSlackChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteSlackUserIdentityError = DeleteSlackUserIdentityException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a user level permission for a Slack channel configuration.
 */
export declare const deleteSlackUserIdentity: API.OperationMethod<DeleteSlackUserIdentityRequest, DeleteSlackUserIdentityResult, DeleteSlackUserIdentityError, Credentials | HttpClient.HttpClient>;
export type DeleteSlackWorkspaceAuthorizationError = DeleteSlackWorkspaceAuthorizationFault | InvalidParameterException | CommonErrors;
/**
 * Deletes the Slack workspace authorization that allows channels to be configured in that workspace. This requires all configured channels in the workspace to be deleted.
 */
export declare const deleteSlackWorkspaceAuthorization: API.OperationMethod<DeleteSlackWorkspaceAuthorizationRequest, DeleteSlackWorkspaceAuthorizationResult, DeleteSlackWorkspaceAuthorizationError, Credentials | HttpClient.HttpClient>;
export type DescribeChimeWebhookConfigurationsError = DescribeChimeWebhookConfigurationsException | InvalidParameterException | InvalidRequestException | CommonErrors;
/**
 * Lists Amazon Chime webhook configurations optionally filtered by ChatConfigurationArn
 */
export declare const describeChimeWebhookConfigurations: API.PaginatedOperationMethod<DescribeChimeWebhookConfigurationsRequest, DescribeChimeWebhookConfigurationsResult, DescribeChimeWebhookConfigurationsError, Credentials | HttpClient.HttpClient, ChimeWebhookConfiguration>;
export type DescribeSlackChannelConfigurationsError = DescribeSlackChannelConfigurationsException | InvalidParameterException | InvalidRequestException | CommonErrors;
/**
 * Lists Slack channel configurations optionally filtered by ChatConfigurationArn
 */
export declare const describeSlackChannelConfigurations: API.PaginatedOperationMethod<DescribeSlackChannelConfigurationsRequest, DescribeSlackChannelConfigurationsResult, DescribeSlackChannelConfigurationsError, Credentials | HttpClient.HttpClient, SlackChannelConfiguration>;
export type DescribeSlackUserIdentitiesError = DescribeSlackUserIdentitiesException | InvalidParameterException | InvalidRequestException | CommonErrors;
/**
 * Lists all Slack user identities with a mapped role.
 */
export declare const describeSlackUserIdentities: API.PaginatedOperationMethod<DescribeSlackUserIdentitiesRequest, DescribeSlackUserIdentitiesResult, DescribeSlackUserIdentitiesError, Credentials | HttpClient.HttpClient, SlackUserIdentity>;
export type DescribeSlackWorkspacesError = DescribeSlackWorkspacesException | InvalidParameterException | InvalidRequestException | CommonErrors;
/**
 * List all authorized Slack workspaces connected to the AWS Account onboarded with AWS Chatbot.
 */
export declare const describeSlackWorkspaces: API.PaginatedOperationMethod<DescribeSlackWorkspacesRequest, DescribeSlackWorkspacesResult, DescribeSlackWorkspacesError, Credentials | HttpClient.HttpClient, SlackWorkspace>;
export type DisassociateFromConfigurationError = InternalServiceError | InvalidRequestException | UnauthorizedException | ResourceNotFoundException | CommonErrors;
/**
 * Unlink a resource, for example a custom action, from a channel configuration.
 */
export declare const disassociateFromConfiguration: API.OperationMethod<DisassociateFromConfigurationRequest, DisassociateFromConfigurationResult, DisassociateFromConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetAccountPreferencesError = GetAccountPreferencesException | InvalidRequestException | CommonErrors;
/**
 * Returns AWS Chatbot account preferences.
 */
export declare const getAccountPreferences: API.OperationMethod<GetAccountPreferencesRequest, GetAccountPreferencesResult, GetAccountPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetCustomActionError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns a custom action.
 */
export declare const getCustomAction: API.OperationMethod<GetCustomActionRequest, GetCustomActionResult, GetCustomActionError, Credentials | HttpClient.HttpClient>;
export type GetMicrosoftTeamsChannelConfigurationError = GetTeamsChannelConfigurationException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a Microsoft Teams channel configuration in an AWS account.
 */
export declare const getMicrosoftTeamsChannelConfiguration: API.OperationMethod<GetTeamsChannelConfigurationRequest, GetTeamsChannelConfigurationResult, GetMicrosoftTeamsChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListAssociationsError = InvalidRequestException | CommonErrors;
/**
 * Lists resources associated with a channel configuration.
 */
export declare const listAssociations: API.PaginatedOperationMethod<ListAssociationsRequest, ListAssociationsResult, ListAssociationsError, Credentials | HttpClient.HttpClient, AssociationListing>;
export type ListCustomActionsError = InternalServiceError | InvalidRequestException | UnauthorizedException | CommonErrors;
/**
 * Lists custom actions defined in this account.
 */
export declare const listCustomActions: API.PaginatedOperationMethod<ListCustomActionsRequest, ListCustomActionsResult, ListCustomActionsError, Credentials | HttpClient.HttpClient, CustomActionArn>;
export type ListMicrosoftTeamsChannelConfigurationsError = InvalidParameterException | InvalidRequestException | ListTeamsChannelConfigurationsException | CommonErrors;
/**
 * Lists all AWS Chatbot Microsoft Teams channel configurations in an AWS account.
 */
export declare const listMicrosoftTeamsChannelConfigurations: API.PaginatedOperationMethod<ListTeamsChannelConfigurationsRequest, ListTeamsChannelConfigurationsResult, ListMicrosoftTeamsChannelConfigurationsError, Credentials | HttpClient.HttpClient, TeamsChannelConfiguration>;
export type ListMicrosoftTeamsConfiguredTeamsError = InvalidParameterException | InvalidRequestException | ListMicrosoftTeamsConfiguredTeamsException | CommonErrors;
/**
 * Lists all authorized Microsoft Teams for an AWS Account
 */
export declare const listMicrosoftTeamsConfiguredTeams: API.PaginatedOperationMethod<ListMicrosoftTeamsConfiguredTeamsRequest, ListMicrosoftTeamsConfiguredTeamsResult, ListMicrosoftTeamsConfiguredTeamsError, Credentials | HttpClient.HttpClient, ConfiguredTeam>;
export type ListMicrosoftTeamsUserIdentitiesError = InvalidParameterException | InvalidRequestException | ListMicrosoftTeamsUserIdentitiesException | CommonErrors;
/**
 * A list all Microsoft Teams user identities with a mapped role.
 */
export declare const listMicrosoftTeamsUserIdentities: API.PaginatedOperationMethod<ListMicrosoftTeamsUserIdentitiesRequest, ListMicrosoftTeamsUserIdentitiesResult, ListMicrosoftTeamsUserIdentitiesError, Credentials | HttpClient.HttpClient, TeamsUserIdentity>;
export type ListTagsForResourceError = InternalServiceError | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists all of the tags associated with the Amazon Resource Name (ARN) that you specify. The resource can be a user, server, or role.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceError | ResourceNotFoundException | ServiceUnavailableException | TooManyTagsException | CommonErrors;
/**
 * Attaches a key-value pair to a resource, as identified by its Amazon Resource Name (ARN). Resources are users, servers, roles, and other entities.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceError | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Detaches a key-value pair from a resource, as identified by its Amazon Resource Name (ARN). Resources are users, servers, roles, and other entities.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountPreferencesError = InvalidParameterException | InvalidRequestException | UpdateAccountPreferencesException | CommonErrors;
/**
 * Updates AWS Chatbot account preferences.
 */
export declare const updateAccountPreferences: API.OperationMethod<UpdateAccountPreferencesRequest, UpdateAccountPreferencesResult, UpdateAccountPreferencesError, Credentials | HttpClient.HttpClient>;
export type UpdateChimeWebhookConfigurationError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | UpdateChimeWebhookConfigurationException | CommonErrors;
/**
 * Updates a Amazon Chime webhook configuration.
 */
export declare const updateChimeWebhookConfiguration: API.OperationMethod<UpdateChimeWebhookConfigurationRequest, UpdateChimeWebhookConfigurationResult, UpdateChimeWebhookConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomActionError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a custom action.
 */
export declare const updateCustomAction: API.OperationMethod<UpdateCustomActionRequest, UpdateCustomActionResult, UpdateCustomActionError, Credentials | HttpClient.HttpClient>;
export type UpdateMicrosoftTeamsChannelConfigurationError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | UpdateTeamsChannelConfigurationException | CommonErrors;
/**
 * Updates an Microsoft Teams channel configuration.
 */
export declare const updateMicrosoftTeamsChannelConfiguration: API.OperationMethod<UpdateTeamsChannelConfigurationRequest, UpdateTeamsChannelConfigurationResult, UpdateMicrosoftTeamsChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateSlackChannelConfigurationError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | UpdateSlackChannelConfigurationException | CommonErrors;
/**
 * Updates a Slack channel configuration.
 */
export declare const updateSlackChannelConfiguration: API.OperationMethod<UpdateSlackChannelConfigurationRequest, UpdateSlackChannelConfigurationResult, UpdateSlackChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=chatbot.d.ts.map