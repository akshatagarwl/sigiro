import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AnalysisNotFoundException_base: S.Class<AnalysisNotFoundException, S.TaggedStruct<"AnalysisNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AnalysisNotFoundException extends /*@__PURE__*/ AnalysisNotFoundException_base {
}
declare const AnomalyMonitorAlreadyExists_base: S.Class<AnomalyMonitorAlreadyExists, S.TaggedStruct<"AnomalyMonitorAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class AnomalyMonitorAlreadyExists extends /*@__PURE__*/ AnomalyMonitorAlreadyExists_base {
}
declare const AnomalySubscriptionAlreadyExists_base: S.Class<AnomalySubscriptionAlreadyExists, S.TaggedStruct<"AnomalySubscriptionAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class AnomalySubscriptionAlreadyExists extends /*@__PURE__*/ AnomalySubscriptionAlreadyExists_base {
}
declare const BackfillLimitExceededException_base: S.Class<BackfillLimitExceededException, S.TaggedStruct<"BackfillLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BackfillLimitExceededException extends /*@__PURE__*/ BackfillLimitExceededException_base {
}
declare const BillExpirationException_base: S.Class<BillExpirationException, S.TaggedStruct<"BillExpirationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BillExpirationException extends /*@__PURE__*/ BillExpirationException_base {
}
declare const BillingViewHealthStatusException_base: S.Class<BillingViewHealthStatusException, S.TaggedStruct<"BillingViewHealthStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BillingViewHealthStatusException extends /*@__PURE__*/ BillingViewHealthStatusException_base {
}
declare const DataUnavailableException_base: S.Class<DataUnavailableException, S.TaggedStruct<"DataUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DataUnavailableException extends /*@__PURE__*/ DataUnavailableException_base {
}
declare const GenerationExistsException_base: S.Class<GenerationExistsException, S.TaggedStruct<"GenerationExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GenerationExistsException extends /*@__PURE__*/ GenerationExistsException_base {
}
declare const InvalidNextTokenException_base: S.Class<InvalidNextTokenException, S.TaggedStruct<"InvalidNextTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const RequestChangedException_base: S.Class<RequestChangedException, S.TaggedStruct<"RequestChangedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RequestChangedException extends /*@__PURE__*/ RequestChangedException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const RightsizingRecommendationNotEnabled_base: S.Class<RightsizingRecommendationNotEnabled, S.TaggedStruct<"RightsizingRecommendationNotEnabled", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RightsizingRecommendationNotEnabled extends /*@__PURE__*/ RightsizingRecommendationNotEnabled_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
    readonly ResourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnknownMonitorException_base: S.Class<UnknownMonitorException, S.TaggedStruct<"UnknownMonitorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnknownMonitorException extends /*@__PURE__*/ UnknownMonitorException_base {
}
declare const UnknownSubscriptionException_base: S.Class<UnknownSubscriptionException, S.TaggedStruct<"UnknownSubscriptionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnknownSubscriptionException extends /*@__PURE__*/ UnknownSubscriptionException_base {
}
declare const UnresolvableUsageUnitException_base: S.Class<UnresolvableUsageUnitException, S.TaggedStruct<"UnresolvableUsageUnitException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnresolvableUsageUnitException extends /*@__PURE__*/ UnresolvableUsageUnitException_base {
}
export type YearMonthDay = string;
export type MonitorType = "DIMENSIONAL" | "CUSTOM" | (string & {});
export declare const MonitorType: any;
export type MonitorDimension = "SERVICE" | "LINKED_ACCOUNT" | "TAG" | "COST_CATEGORY" | (string & {});
export declare const MonitorDimension: any;
export type Expressions = Expression[];
export declare const Expressions: S.Schema<Expressions>;
export type Dimension = "AZ" | "INSTANCE_TYPE" | "LINKED_ACCOUNT" | "PAYER_ACCOUNT" | "LINKED_ACCOUNT_NAME" | "OPERATION" | "PURCHASE_TYPE" | "REGION" | "SERVICE" | "SERVICE_CODE" | "USAGE_TYPE" | "USAGE_TYPE_GROUP" | "RECORD_TYPE" | "OPERATING_SYSTEM" | "TENANCY" | "SCOPE" | "PLATFORM" | "SUBSCRIPTION_ID" | "LEGAL_ENTITY_NAME" | "DEPLOYMENT_OPTION" | "DATABASE_ENGINE" | "CACHE_ENGINE" | "INSTANCE_TYPE_FAMILY" | "BILLING_ENTITY" | "RESERVATION_ID" | "RESOURCE_ID" | "RIGHTSIZING_TYPE" | "SAVINGS_PLANS_TYPE" | "SAVINGS_PLAN_ARN" | "PAYMENT_OPTION" | "AGREEMENT_END_DATE_TIME_AFTER" | "AGREEMENT_END_DATE_TIME_BEFORE" | "INVOICING_ENTITY" | "ANOMALY_TOTAL_IMPACT_ABSOLUTE" | "ANOMALY_TOTAL_IMPACT_PERCENTAGE" | (string & {});
export declare const Dimension: any;
export type Value = string;
export type Values = string[];
export declare const Values: any;
export type MatchOption = "EQUALS" | "ABSENT" | "STARTS_WITH" | "ENDS_WITH" | "CONTAINS" | "CASE_SENSITIVE" | "CASE_INSENSITIVE" | "GREATER_THAN_OR_EQUAL" | (string & {});
export declare const MatchOption: any;
export type MatchOptions = MatchOption[];
export declare const MatchOptions: any;
export interface DimensionValues {
    Key?: Dimension;
    Values?: string[];
    MatchOptions?: MatchOption[];
}
export declare const DimensionValues: S.Schema<DimensionValues>;
export type TagKey = string;
export interface TagValues {
    Key?: string;
    Values?: string[];
    MatchOptions?: MatchOption[];
}
export declare const TagValues: S.Schema<TagValues>;
export type CostCategoryName = string;
export interface CostCategoryValues {
    Key?: string;
    Values?: string[];
    MatchOptions?: MatchOption[];
}
export declare const CostCategoryValues: S.Schema<CostCategoryValues>;
export interface Expression {
    Or?: Expression[];
    And?: Expression[];
    Not?: Expression;
    Dimensions?: DimensionValues;
    Tags?: TagValues;
    CostCategories?: CostCategoryValues;
}
export declare const Expression: S.Schema<Expression>;
export type NonNegativeInteger = number;
export interface AnomalyMonitor {
    MonitorArn?: string;
    MonitorName: string;
    CreationDate?: string;
    LastUpdatedDate?: string;
    LastEvaluatedDate?: string;
    MonitorType: MonitorType;
    MonitorDimension?: MonitorDimension;
    MonitorSpecification?: Expression;
    DimensionalValueCount?: number;
}
export declare const AnomalyMonitor: S.Schema<AnomalyMonitor>;
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    Key: string;
    Value: string;
}
export declare const ResourceTag: S.Schema<ResourceTag>;
export type ResourceTagList = ResourceTag[];
export declare const ResourceTagList: any;
export interface CreateAnomalyMonitorRequest {
    AnomalyMonitor: AnomalyMonitor;
    ResourceTags?: ResourceTag[];
}
export declare const CreateAnomalyMonitorRequest: S.Schema<CreateAnomalyMonitorRequest>;
export interface CreateAnomalyMonitorResponse {
    MonitorArn: string;
}
export declare const CreateAnomalyMonitorResponse: S.Schema<CreateAnomalyMonitorResponse>;
export type Arn = string;
export type MonitorArnList = string[];
export declare const MonitorArnList: any;
export type SubscriberAddress = string;
export type SubscriberType = "EMAIL" | "SNS" | (string & {});
export declare const SubscriberType: any;
export type SubscriberStatus = "CONFIRMED" | "DECLINED" | (string & {});
export declare const SubscriberStatus: any;
export interface Subscriber {
    Address?: string;
    Type?: SubscriberType;
    Status?: SubscriberStatus;
}
export declare const Subscriber: S.Schema<Subscriber>;
export type Subscribers = Subscriber[];
export declare const Subscribers: any;
export type NullableNonNegativeDouble = number;
export type AnomalySubscriptionFrequency = "DAILY" | "IMMEDIATE" | "WEEKLY" | (string & {});
export declare const AnomalySubscriptionFrequency: any;
export interface AnomalySubscription {
    SubscriptionArn?: string;
    AccountId?: string;
    MonitorArnList: string[];
    Subscribers: Subscriber[];
    Threshold?: number;
    Frequency: AnomalySubscriptionFrequency;
    SubscriptionName: string;
    ThresholdExpression?: Expression;
}
export declare const AnomalySubscription: S.Schema<AnomalySubscription>;
export interface CreateAnomalySubscriptionRequest {
    AnomalySubscription: AnomalySubscription;
    ResourceTags?: ResourceTag[];
}
export declare const CreateAnomalySubscriptionRequest: S.Schema<CreateAnomalySubscriptionRequest>;
export interface CreateAnomalySubscriptionResponse {
    SubscriptionArn: string;
}
export declare const CreateAnomalySubscriptionResponse: S.Schema<CreateAnomalySubscriptionResponse>;
export type ZonedDateTime = string;
export type CostCategoryRuleVersion = "CostCategoryExpression.v1" | (string & {});
export declare const CostCategoryRuleVersion: any;
export type CostCategoryValue = string;
export type CostCategoryInheritedValueDimensionName = "LINKED_ACCOUNT_NAME" | "TAG" | (string & {});
export declare const CostCategoryInheritedValueDimensionName: any;
export interface CostCategoryInheritedValueDimension {
    DimensionName?: CostCategoryInheritedValueDimensionName;
    DimensionKey?: string;
}
export declare const CostCategoryInheritedValueDimension: S.Schema<CostCategoryInheritedValueDimension>;
export type CostCategoryRuleType = "REGULAR" | "INHERITED_VALUE" | (string & {});
export declare const CostCategoryRuleType: any;
export interface CostCategoryRule {
    Value?: string;
    Rule?: Expression;
    InheritedValue?: CostCategoryInheritedValueDimension;
    Type?: CostCategoryRuleType;
}
export declare const CostCategoryRule: S.Schema<CostCategoryRule>;
export type CostCategoryRulesList = CostCategoryRule[];
export declare const CostCategoryRulesList: any;
export type CostCategorySplitChargeRuleTargetsList = string[];
export declare const CostCategorySplitChargeRuleTargetsList: any;
export type CostCategorySplitChargeMethod = "FIXED" | "PROPORTIONAL" | "EVEN" | (string & {});
export declare const CostCategorySplitChargeMethod: any;
export type CostCategorySplitChargeRuleParameterType = "ALLOCATION_PERCENTAGES" | (string & {});
export declare const CostCategorySplitChargeRuleParameterType: any;
export type CostCategorySplitChargeRuleParameterValuesList = string[];
export declare const CostCategorySplitChargeRuleParameterValuesList: any;
export interface CostCategorySplitChargeRuleParameter {
    Type: CostCategorySplitChargeRuleParameterType;
    Values: string[];
}
export declare const CostCategorySplitChargeRuleParameter: S.Schema<CostCategorySplitChargeRuleParameter>;
export type CostCategorySplitChargeRuleParametersList = CostCategorySplitChargeRuleParameter[];
export declare const CostCategorySplitChargeRuleParametersList: any;
export interface CostCategorySplitChargeRule {
    Source: string;
    Targets: string[];
    Method: CostCategorySplitChargeMethod;
    Parameters?: CostCategorySplitChargeRuleParameter[];
}
export declare const CostCategorySplitChargeRule: S.Schema<CostCategorySplitChargeRule>;
export type CostCategorySplitChargeRulesList = CostCategorySplitChargeRule[];
export declare const CostCategorySplitChargeRulesList: any;
export interface CreateCostCategoryDefinitionRequest {
    Name: string;
    EffectiveStart?: string;
    RuleVersion: CostCategoryRuleVersion;
    Rules: CostCategoryRule[];
    DefaultValue?: string;
    SplitChargeRules?: CostCategorySplitChargeRule[];
    ResourceTags?: ResourceTag[];
}
export declare const CreateCostCategoryDefinitionRequest: S.Schema<CreateCostCategoryDefinitionRequest>;
export interface CreateCostCategoryDefinitionResponse {
    CostCategoryArn?: string;
    EffectiveStart?: string;
}
export declare const CreateCostCategoryDefinitionResponse: S.Schema<CreateCostCategoryDefinitionResponse>;
export interface DeleteAnomalyMonitorRequest {
    MonitorArn: string;
}
export declare const DeleteAnomalyMonitorRequest: S.Schema<DeleteAnomalyMonitorRequest>;
export interface DeleteAnomalyMonitorResponse {
}
export declare const DeleteAnomalyMonitorResponse: S.Schema<DeleteAnomalyMonitorResponse>;
export interface DeleteAnomalySubscriptionRequest {
    SubscriptionArn: string;
}
export declare const DeleteAnomalySubscriptionRequest: S.Schema<DeleteAnomalySubscriptionRequest>;
export interface DeleteAnomalySubscriptionResponse {
}
export declare const DeleteAnomalySubscriptionResponse: S.Schema<DeleteAnomalySubscriptionResponse>;
export interface DeleteCostCategoryDefinitionRequest {
    CostCategoryArn: string;
}
export declare const DeleteCostCategoryDefinitionRequest: S.Schema<DeleteCostCategoryDefinitionRequest>;
export interface DeleteCostCategoryDefinitionResponse {
    CostCategoryArn?: string;
    EffectiveEnd?: string;
}
export declare const DeleteCostCategoryDefinitionResponse: S.Schema<DeleteCostCategoryDefinitionResponse>;
export interface DescribeCostCategoryDefinitionRequest {
    CostCategoryArn: string;
    EffectiveOn?: string;
}
export declare const DescribeCostCategoryDefinitionRequest: S.Schema<DescribeCostCategoryDefinitionRequest>;
export type CostCategoryStatusComponent = "COST_EXPLORER" | (string & {});
export declare const CostCategoryStatusComponent: any;
export type CostCategoryStatus = "PROCESSING" | "APPLIED" | (string & {});
export declare const CostCategoryStatus: any;
export interface CostCategoryProcessingStatus {
    Component?: CostCategoryStatusComponent;
    Status?: CostCategoryStatus;
}
export declare const CostCategoryProcessingStatus: S.Schema<CostCategoryProcessingStatus>;
export type CostCategoryProcessingStatusList = CostCategoryProcessingStatus[];
export declare const CostCategoryProcessingStatusList: any;
export interface CostCategory {
    CostCategoryArn: string;
    EffectiveStart: string;
    EffectiveEnd?: string;
    Name: string;
    RuleVersion: CostCategoryRuleVersion;
    Rules: CostCategoryRule[];
    SplitChargeRules?: CostCategorySplitChargeRule[];
    ProcessingStatus?: CostCategoryProcessingStatus[];
    DefaultValue?: string;
}
export declare const CostCategory: S.Schema<CostCategory>;
export interface DescribeCostCategoryDefinitionResponse {
    CostCategory?: CostCategory;
}
export declare const DescribeCostCategoryDefinitionResponse: S.Schema<DescribeCostCategoryDefinitionResponse>;
export interface AnomalyDateInterval {
    StartDate: string;
    EndDate?: string;
}
export declare const AnomalyDateInterval: S.Schema<AnomalyDateInterval>;
export type AnomalyFeedbackType = "YES" | "NO" | "PLANNED_ACTIVITY" | (string & {});
export declare const AnomalyFeedbackType: any;
export type NumericOperator = "EQUAL" | "GREATER_THAN_OR_EQUAL" | "LESS_THAN_OR_EQUAL" | "GREATER_THAN" | "LESS_THAN" | "BETWEEN" | (string & {});
export declare const NumericOperator: any;
export interface TotalImpactFilter {
    NumericOperator: NumericOperator;
    StartValue: number;
    EndValue?: number;
}
export declare const TotalImpactFilter: S.Schema<TotalImpactFilter>;
export type NextPageToken = string;
export type PageSize = number;
export interface GetAnomaliesRequest {
    MonitorArn?: string;
    DateInterval: AnomalyDateInterval;
    Feedback?: AnomalyFeedbackType;
    TotalImpact?: TotalImpactFilter;
    NextPageToken?: string;
    MaxResults?: number;
}
export declare const GetAnomaliesRequest: S.Schema<GetAnomaliesRequest>;
export interface RootCauseImpact {
    Contribution: number;
}
export declare const RootCauseImpact: S.Schema<RootCauseImpact>;
export interface RootCause {
    Service?: string;
    Region?: string;
    LinkedAccount?: string;
    LinkedAccountName?: string;
    UsageType?: string;
    Impact?: RootCauseImpact;
}
export declare const RootCause: S.Schema<RootCause>;
export type RootCauses = RootCause[];
export declare const RootCauses: any;
export interface AnomalyScore {
    MaxScore: number;
    CurrentScore: number;
}
export declare const AnomalyScore: S.Schema<AnomalyScore>;
export interface Impact {
    MaxImpact: number;
    TotalImpact?: number;
    TotalActualSpend?: number;
    TotalExpectedSpend?: number;
    TotalImpactPercentage?: number;
}
export declare const Impact: S.Schema<Impact>;
export interface Anomaly {
    AnomalyId: string;
    AnomalyStartDate?: string;
    AnomalyEndDate?: string;
    DimensionValue?: string;
    RootCauses?: RootCause[];
    AnomalyScore: AnomalyScore;
    Impact: Impact;
    MonitorArn: string;
    Feedback?: AnomalyFeedbackType;
}
export declare const Anomaly: S.Schema<Anomaly>;
export type Anomalies = Anomaly[];
export declare const Anomalies: any;
export interface GetAnomaliesResponse {
    Anomalies: Anomaly[];
    NextPageToken?: string;
}
export declare const GetAnomaliesResponse: S.Schema<GetAnomaliesResponse>;
export interface GetAnomalyMonitorsRequest {
    MonitorArnList?: string[];
    NextPageToken?: string;
    MaxResults?: number;
}
export declare const GetAnomalyMonitorsRequest: S.Schema<GetAnomalyMonitorsRequest>;
export type AnomalyMonitors = AnomalyMonitor[];
export declare const AnomalyMonitors: any;
export interface GetAnomalyMonitorsResponse {
    AnomalyMonitors: AnomalyMonitor[];
    NextPageToken?: string;
}
export declare const GetAnomalyMonitorsResponse: S.Schema<GetAnomalyMonitorsResponse>;
export interface GetAnomalySubscriptionsRequest {
    SubscriptionArnList?: string[];
    MonitorArn?: string;
    NextPageToken?: string;
    MaxResults?: number;
}
export declare const GetAnomalySubscriptionsRequest: S.Schema<GetAnomalySubscriptionsRequest>;
export type AnomalySubscriptions = AnomalySubscription[];
export declare const AnomalySubscriptions: any;
export interface GetAnomalySubscriptionsResponse {
    AnomalySubscriptions: AnomalySubscription[];
    NextPageToken?: string;
}
export declare const GetAnomalySubscriptionsResponse: S.Schema<GetAnomalySubscriptionsResponse>;
export type Granularity = "DAILY" | "MONTHLY" | "HOURLY" | (string & {});
export declare const Granularity: any;
export type UsageServices = string[];
export declare const UsageServices: any;
export type ApproximationDimension = "SERVICE" | "RESOURCE" | (string & {});
export declare const ApproximationDimension: any;
export interface GetApproximateUsageRecordsRequest {
    Granularity: Granularity;
    Services?: string[];
    ApproximationDimension: ApproximationDimension;
}
export declare const GetApproximateUsageRecordsRequest: S.Schema<GetApproximateUsageRecordsRequest>;
export type NonNegativeLong = number;
export type ApproximateUsageRecordsPerService = {
    [key: string]: number | undefined;
};
export declare const ApproximateUsageRecordsPerService: any;
export interface DateInterval {
    Start: string;
    End: string;
}
export declare const DateInterval: S.Schema<DateInterval>;
export interface GetApproximateUsageRecordsResponse {
    Services?: {
        [key: string]: number | undefined;
    };
    TotalRecords?: number;
    LookbackPeriod?: DateInterval;
}
export declare const GetApproximateUsageRecordsResponse: S.Schema<GetApproximateUsageRecordsResponse>;
export type AnalysisId = string;
export interface GetCommitmentPurchaseAnalysisRequest {
    AnalysisId: string;
}
export declare const GetCommitmentPurchaseAnalysisRequest: S.Schema<GetCommitmentPurchaseAnalysisRequest>;
export type AnalysisStatus = "SUCCEEDED" | "PROCESSING" | "FAILED" | (string & {});
export declare const AnalysisStatus: any;
export type ErrorCode = "NO_USAGE_FOUND" | "INTERNAL_FAILURE" | "INVALID_SAVINGS_PLANS_TO_ADD" | "INVALID_SAVINGS_PLANS_TO_EXCLUDE" | "INVALID_ACCOUNT_ID" | (string & {});
export declare const ErrorCode: any;
export interface RecommendationDetailHourlyMetrics {
    StartTime?: string;
    EstimatedOnDemandCost?: string;
    CurrentCoverage?: string;
    EstimatedCoverage?: string;
    EstimatedNewCommitmentUtilization?: string;
}
export declare const RecommendationDetailHourlyMetrics: S.Schema<RecommendationDetailHourlyMetrics>;
export type MetricsOverLookbackPeriod = RecommendationDetailHourlyMetrics[];
export declare const MetricsOverLookbackPeriod: any;
export interface SavingsPlansPurchaseAnalysisDetails {
    CurrencyCode?: string;
    LookbackPeriodInHours?: string;
    CurrentAverageCoverage?: string;
    CurrentAverageHourlyOnDemandSpend?: string;
    CurrentMaximumHourlyOnDemandSpend?: string;
    CurrentMinimumHourlyOnDemandSpend?: string;
    CurrentOnDemandSpend?: string;
    ExistingHourlyCommitment?: string;
    HourlyCommitmentToPurchase?: string;
    EstimatedAverageCoverage?: string;
    EstimatedAverageUtilization?: string;
    EstimatedMonthlySavingsAmount?: string;
    EstimatedOnDemandCost?: string;
    EstimatedOnDemandCostWithCurrentCommitment?: string;
    EstimatedROI?: string;
    EstimatedSavingsAmount?: string;
    EstimatedSavingsPercentage?: string;
    EstimatedCommitmentCost?: string;
    LatestUsageTimestamp?: string;
    UpfrontCost?: string;
    AdditionalMetadata?: string;
    MetricsOverLookbackPeriod?: RecommendationDetailHourlyMetrics[];
}
export declare const SavingsPlansPurchaseAnalysisDetails: S.Schema<SavingsPlansPurchaseAnalysisDetails>;
export interface AnalysisDetails {
    SavingsPlansPurchaseAnalysisDetails?: SavingsPlansPurchaseAnalysisDetails;
}
export declare const AnalysisDetails: S.Schema<AnalysisDetails>;
export type AccountScope = "PAYER" | "LINKED" | (string & {});
export declare const AccountScope: any;
export type AccountId = string;
export type AnalysisType = "MAX_SAVINGS" | "CUSTOM_COMMITMENT" | "TARGET_AVERAGE_COVERAGE" | (string & {});
export declare const AnalysisType: any;
export type PaymentOption = "NO_UPFRONT" | "PARTIAL_UPFRONT" | "ALL_UPFRONT" | "LIGHT_UTILIZATION" | "MEDIUM_UTILIZATION" | "HEAVY_UTILIZATION" | (string & {});
export declare const PaymentOption: any;
export type SupportedSavingsPlansType = "COMPUTE_SP" | "EC2_INSTANCE_SP" | "SAGEMAKER_SP" | "DATABASE_SP" | (string & {});
export declare const SupportedSavingsPlansType: any;
export type TermInYears = "ONE_YEAR" | "THREE_YEARS" | (string & {});
export declare const TermInYears: any;
export type SavingsPlansCommitment = number;
export interface SavingsPlans {
    PaymentOption?: PaymentOption;
    SavingsPlansType?: SupportedSavingsPlansType;
    Region?: string;
    InstanceFamily?: string;
    TermInYears?: TermInYears;
    SavingsPlansCommitment?: number;
    OfferingId?: string;
}
export declare const SavingsPlans: S.Schema<SavingsPlans>;
export type SavingsPlansToAdd = SavingsPlans[];
export declare const SavingsPlansToAdd: any;
export type SavingsPlansId = string;
export type SavingsPlansToExclude = string[];
export declare const SavingsPlansToExclude: any;
export type SavingsPlansTargetCoverage = number;
export interface SavingsPlansPurchaseAnalysisConfiguration {
    AccountScope?: AccountScope;
    AccountId?: string;
    AnalysisType: AnalysisType;
    SavingsPlansToAdd: SavingsPlans[];
    SavingsPlansToExclude?: string[];
    LookBackTimePeriod: DateInterval;
    SavingsPlansTargetCoverage?: number;
}
export declare const SavingsPlansPurchaseAnalysisConfiguration: S.Schema<SavingsPlansPurchaseAnalysisConfiguration>;
export interface CommitmentPurchaseAnalysisConfiguration {
    SavingsPlansPurchaseAnalysisConfiguration?: SavingsPlansPurchaseAnalysisConfiguration;
}
export declare const CommitmentPurchaseAnalysisConfiguration: S.Schema<CommitmentPurchaseAnalysisConfiguration>;
export interface GetCommitmentPurchaseAnalysisResponse {
    EstimatedCompletionTime: string;
    AnalysisCompletionTime?: string;
    AnalysisStartedTime: string;
    AnalysisId: string;
    AnalysisStatus: AnalysisStatus;
    ErrorCode?: ErrorCode;
    AnalysisDetails?: AnalysisDetails;
    CommitmentPurchaseAnalysisConfiguration: CommitmentPurchaseAnalysisConfiguration;
}
export declare const GetCommitmentPurchaseAnalysisResponse: S.Schema<GetCommitmentPurchaseAnalysisResponse>;
export type MetricName = string;
export type MetricNames = string[];
export declare const MetricNames: any;
export type GroupDefinitionType = "DIMENSION" | "TAG" | "COST_CATEGORY" | (string & {});
export declare const GroupDefinitionType: any;
export type GroupDefinitionKey = string;
export interface GroupDefinition {
    Type?: GroupDefinitionType;
    Key?: string;
}
export declare const GroupDefinition: S.Schema<GroupDefinition>;
export type GroupDefinitions = GroupDefinition[];
export declare const GroupDefinitions: any;
export type BillingViewArn = string;
export interface GetCostAndUsageRequest {
    TimePeriod: DateInterval;
    Granularity: Granularity;
    Filter?: Expression;
    Metrics: string[];
    GroupBy?: GroupDefinition[];
    BillingViewArn?: string;
    NextPageToken?: string;
}
export declare const GetCostAndUsageRequest: S.Schema<GetCostAndUsageRequest>;
export type MetricAmount = string;
export type MetricUnit = string;
export interface MetricValue {
    Amount?: string;
    Unit?: string;
}
export declare const MetricValue: S.Schema<MetricValue>;
export type Metrics = {
    [key: string]: MetricValue | undefined;
};
export declare const Metrics: any;
export type Key = string;
export type Keys = string[];
export declare const Keys: any;
export interface Group {
    Keys?: string[];
    Metrics?: {
        [key: string]: MetricValue | undefined;
    };
}
export declare const Group: S.Schema<Group>;
export type Groups = Group[];
export declare const Groups: any;
export type Estimated = boolean;
export interface ResultByTime {
    TimePeriod?: DateInterval;
    Total?: {
        [key: string]: MetricValue | undefined;
    };
    Groups?: Group[];
    Estimated?: boolean;
}
export declare const ResultByTime: S.Schema<ResultByTime>;
export type ResultsByTime = ResultByTime[];
export declare const ResultsByTime: any;
export type AttributeType = string;
export type AttributeValue = string;
export type Attributes = {
    [key: string]: string | undefined;
};
export declare const Attributes: any;
export interface DimensionValuesWithAttributes {
    Value?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
}
export declare const DimensionValuesWithAttributes: S.Schema<DimensionValuesWithAttributes>;
export type DimensionValuesWithAttributesList = DimensionValuesWithAttributes[];
export declare const DimensionValuesWithAttributesList: any;
export interface GetCostAndUsageResponse {
    NextPageToken?: string;
    GroupDefinitions?: GroupDefinition[];
    ResultsByTime?: ResultByTime[];
    DimensionValueAttributes?: DimensionValuesWithAttributes[];
}
export declare const GetCostAndUsageResponse: S.Schema<GetCostAndUsageResponse>;
export type CostAndUsageComparisonsMaxResults = number;
export interface GetCostAndUsageComparisonsRequest {
    BillingViewArn?: string;
    BaselineTimePeriod: DateInterval;
    ComparisonTimePeriod: DateInterval;
    MetricForComparison: string;
    Filter?: Expression;
    GroupBy?: GroupDefinition[];
    MaxResults?: number;
    NextPageToken?: string;
}
export declare const GetCostAndUsageComparisonsRequest: S.Schema<GetCostAndUsageComparisonsRequest>;
export interface ComparisonMetricValue {
    BaselineTimePeriodAmount?: string;
    ComparisonTimePeriodAmount?: string;
    Difference?: string;
    Unit?: string;
}
export declare const ComparisonMetricValue: S.Schema<ComparisonMetricValue>;
export type ComparisonMetrics = {
    [key: string]: ComparisonMetricValue | undefined;
};
export declare const ComparisonMetrics: any;
export interface CostAndUsageComparison {
    CostAndUsageSelector?: Expression;
    Metrics?: {
        [key: string]: ComparisonMetricValue | undefined;
    };
}
export declare const CostAndUsageComparison: S.Schema<CostAndUsageComparison>;
export type CostAndUsageComparisons = CostAndUsageComparison[];
export declare const CostAndUsageComparisons: any;
export interface GetCostAndUsageComparisonsResponse {
    CostAndUsageComparisons?: CostAndUsageComparison[];
    TotalCostAndUsage?: {
        [key: string]: ComparisonMetricValue | undefined;
    };
    NextPageToken?: string;
}
export declare const GetCostAndUsageComparisonsResponse: S.Schema<GetCostAndUsageComparisonsResponse>;
export interface GetCostAndUsageWithResourcesRequest {
    TimePeriod: DateInterval;
    Granularity: Granularity;
    Filter: Expression;
    Metrics?: string[];
    GroupBy?: GroupDefinition[];
    BillingViewArn?: string;
    NextPageToken?: string;
}
export declare const GetCostAndUsageWithResourcesRequest: S.Schema<GetCostAndUsageWithResourcesRequest>;
export interface GetCostAndUsageWithResourcesResponse {
    NextPageToken?: string;
    GroupDefinitions?: GroupDefinition[];
    ResultsByTime?: ResultByTime[];
    DimensionValueAttributes?: DimensionValuesWithAttributes[];
}
export declare const GetCostAndUsageWithResourcesResponse: S.Schema<GetCostAndUsageWithResourcesResponse>;
export type SearchString = string;
export type SortDefinitionKey = string;
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export declare const SortOrder: any;
export interface SortDefinition {
    Key: string;
    SortOrder?: SortOrder;
}
export declare const SortDefinition: S.Schema<SortDefinition>;
export type SortDefinitions = SortDefinition[];
export declare const SortDefinitions: any;
export type MaxResults = number;
export interface GetCostCategoriesRequest {
    SearchString?: string;
    TimePeriod: DateInterval;
    CostCategoryName?: string;
    Filter?: Expression;
    SortBy?: SortDefinition[];
    BillingViewArn?: string;
    MaxResults?: number;
    NextPageToken?: string;
}
export declare const GetCostCategoriesRequest: S.Schema<GetCostCategoriesRequest>;
export type CostCategoryNamesList = string[];
export declare const CostCategoryNamesList: any;
export type CostCategoryValuesList = string[];
export declare const CostCategoryValuesList: any;
export interface GetCostCategoriesResponse {
    NextPageToken?: string;
    CostCategoryNames?: string[];
    CostCategoryValues?: string[];
    ReturnSize: number;
    TotalSize: number;
}
export declare const GetCostCategoriesResponse: S.Schema<GetCostCategoriesResponse>;
export type CostComparisonDriversMaxResults = number;
export interface GetCostComparisonDriversRequest {
    BillingViewArn?: string;
    BaselineTimePeriod: DateInterval;
    ComparisonTimePeriod: DateInterval;
    MetricForComparison: string;
    Filter?: Expression;
    GroupBy?: GroupDefinition[];
    MaxResults?: number;
    NextPageToken?: string;
}
export declare const GetCostComparisonDriversRequest: S.Schema<GetCostComparisonDriversRequest>;
export interface CostDriver {
    Type?: string;
    Name?: string;
    Metrics?: {
        [key: string]: ComparisonMetricValue | undefined;
    };
}
export declare const CostDriver: S.Schema<CostDriver>;
export type CostDrivers = CostDriver[];
export declare const CostDrivers: any;
export interface CostComparisonDriver {
    CostSelector?: Expression;
    Metrics?: {
        [key: string]: ComparisonMetricValue | undefined;
    };
    CostDrivers?: CostDriver[];
}
export declare const CostComparisonDriver: S.Schema<CostComparisonDriver>;
export type CostComparisonDrivers = CostComparisonDriver[];
export declare const CostComparisonDrivers: any;
export interface GetCostComparisonDriversResponse {
    CostComparisonDrivers?: CostComparisonDriver[];
    NextPageToken?: string;
}
export declare const GetCostComparisonDriversResponse: S.Schema<GetCostComparisonDriversResponse>;
export type Metric = "BLENDED_COST" | "UNBLENDED_COST" | "AMORTIZED_COST" | "NET_UNBLENDED_COST" | "NET_AMORTIZED_COST" | "USAGE_QUANTITY" | "NORMALIZED_USAGE_AMOUNT" | (string & {});
export declare const Metric: any;
export type PredictionIntervalLevel = number;
export interface GetCostForecastRequest {
    TimePeriod: DateInterval;
    Metric: Metric;
    Granularity: Granularity;
    Filter?: Expression;
    BillingViewArn?: string;
    PredictionIntervalLevel?: number;
}
export declare const GetCostForecastRequest: S.Schema<GetCostForecastRequest>;
export interface ForecastResult {
    TimePeriod?: DateInterval;
    MeanValue?: string;
    PredictionIntervalLowerBound?: string;
    PredictionIntervalUpperBound?: string;
}
export declare const ForecastResult: S.Schema<ForecastResult>;
export type ForecastResultsByTime = ForecastResult[];
export declare const ForecastResultsByTime: any;
export interface GetCostForecastResponse {
    Total?: MetricValue;
    ForecastResultsByTime?: ForecastResult[];
}
export declare const GetCostForecastResponse: S.Schema<GetCostForecastResponse>;
export type Context = "COST_AND_USAGE" | "RESERVATIONS" | "SAVINGS_PLANS" | (string & {});
export declare const Context: any;
export interface GetDimensionValuesRequest {
    SearchString?: string;
    TimePeriod: DateInterval;
    Dimension: Dimension;
    Context?: Context;
    Filter?: Expression;
    SortBy?: SortDefinition[];
    BillingViewArn?: string;
    MaxResults?: number;
    NextPageToken?: string;
}
export declare const GetDimensionValuesRequest: S.Schema<GetDimensionValuesRequest>;
export interface GetDimensionValuesResponse {
    DimensionValues: DimensionValuesWithAttributes[];
    ReturnSize: number;
    TotalSize: number;
    NextPageToken?: string;
}
export declare const GetDimensionValuesResponse: S.Schema<GetDimensionValuesResponse>;
export interface GetReservationCoverageRequest {
    TimePeriod: DateInterval;
    GroupBy?: GroupDefinition[];
    Granularity?: Granularity;
    Filter?: Expression;
    Metrics?: string[];
    NextPageToken?: string;
    SortBy?: SortDefinition;
    MaxResults?: number;
}
export declare const GetReservationCoverageRequest: S.Schema<GetReservationCoverageRequest>;
export type OnDemandHours = string;
export type ReservedHours = string;
export type TotalRunningHours = string;
export type CoverageHoursPercentage = string;
export interface CoverageHours {
    OnDemandHours?: string;
    ReservedHours?: string;
    TotalRunningHours?: string;
    CoverageHoursPercentage?: string;
}
export declare const CoverageHours: S.Schema<CoverageHours>;
export type OnDemandNormalizedUnits = string;
export type ReservedNormalizedUnits = string;
export type TotalRunningNormalizedUnits = string;
export type CoverageNormalizedUnitsPercentage = string;
export interface CoverageNormalizedUnits {
    OnDemandNormalizedUnits?: string;
    ReservedNormalizedUnits?: string;
    TotalRunningNormalizedUnits?: string;
    CoverageNormalizedUnitsPercentage?: string;
}
export declare const CoverageNormalizedUnits: S.Schema<CoverageNormalizedUnits>;
export type OnDemandCost = string;
export interface CoverageCost {
    OnDemandCost?: string;
}
export declare const CoverageCost: S.Schema<CoverageCost>;
export interface Coverage {
    CoverageHours?: CoverageHours;
    CoverageNormalizedUnits?: CoverageNormalizedUnits;
    CoverageCost?: CoverageCost;
}
export declare const Coverage: S.Schema<Coverage>;
export interface ReservationCoverageGroup {
    Attributes?: {
        [key: string]: string | undefined;
    };
    Coverage?: Coverage;
}
export declare const ReservationCoverageGroup: S.Schema<ReservationCoverageGroup>;
export type ReservationCoverageGroups = ReservationCoverageGroup[];
export declare const ReservationCoverageGroups: any;
export interface CoverageByTime {
    TimePeriod?: DateInterval;
    Groups?: ReservationCoverageGroup[];
    Total?: Coverage;
}
export declare const CoverageByTime: S.Schema<CoverageByTime>;
export type CoveragesByTime = CoverageByTime[];
export declare const CoveragesByTime: any;
export interface GetReservationCoverageResponse {
    CoveragesByTime: CoverageByTime[];
    Total?: Coverage;
    NextPageToken?: string;
}
export declare const GetReservationCoverageResponse: S.Schema<GetReservationCoverageResponse>;
export type LookbackPeriodInDays = "SEVEN_DAYS" | "THIRTY_DAYS" | "SIXTY_DAYS" | (string & {});
export declare const LookbackPeriodInDays: any;
export type OfferingClass = "STANDARD" | "CONVERTIBLE" | (string & {});
export declare const OfferingClass: any;
export interface EC2Specification {
    OfferingClass?: OfferingClass;
}
export declare const EC2Specification: S.Schema<EC2Specification>;
export interface ServiceSpecification {
    EC2Specification?: EC2Specification;
}
export declare const ServiceSpecification: S.Schema<ServiceSpecification>;
export type RecommendationsPageSize = number;
export interface GetReservationPurchaseRecommendationRequest {
    AccountId?: string;
    Service: string;
    Filter?: Expression;
    AccountScope?: AccountScope;
    LookbackPeriodInDays?: LookbackPeriodInDays;
    TermInYears?: TermInYears;
    PaymentOption?: PaymentOption;
    ServiceSpecification?: ServiceSpecification;
    PageSize?: number;
    NextPageToken?: string;
}
export declare const GetReservationPurchaseRecommendationRequest: S.Schema<GetReservationPurchaseRecommendationRequest>;
export interface ReservationPurchaseRecommendationMetadata {
    RecommendationId?: string;
    GenerationTimestamp?: string;
    AdditionalMetadata?: string;
}
export declare const ReservationPurchaseRecommendationMetadata: S.Schema<ReservationPurchaseRecommendationMetadata>;
export interface EC2InstanceDetails {
    Family?: string;
    InstanceType?: string;
    Region?: string;
    AvailabilityZone?: string;
    Platform?: string;
    Tenancy?: string;
    CurrentGeneration?: boolean;
    SizeFlexEligible?: boolean;
}
export declare const EC2InstanceDetails: S.Schema<EC2InstanceDetails>;
export interface RDSInstanceDetails {
    Family?: string;
    InstanceType?: string;
    Region?: string;
    DatabaseEngine?: string;
    DatabaseEdition?: string;
    DeploymentOption?: string;
    LicenseModel?: string;
    CurrentGeneration?: boolean;
    SizeFlexEligible?: boolean;
    DeploymentModel?: string;
}
export declare const RDSInstanceDetails: S.Schema<RDSInstanceDetails>;
export interface RedshiftInstanceDetails {
    Family?: string;
    NodeType?: string;
    Region?: string;
    CurrentGeneration?: boolean;
    SizeFlexEligible?: boolean;
}
export declare const RedshiftInstanceDetails: S.Schema<RedshiftInstanceDetails>;
export interface ElastiCacheInstanceDetails {
    Family?: string;
    NodeType?: string;
    Region?: string;
    ProductDescription?: string;
    CurrentGeneration?: boolean;
    SizeFlexEligible?: boolean;
}
export declare const ElastiCacheInstanceDetails: S.Schema<ElastiCacheInstanceDetails>;
export interface ESInstanceDetails {
    InstanceClass?: string;
    InstanceSize?: string;
    Region?: string;
    CurrentGeneration?: boolean;
    SizeFlexEligible?: boolean;
}
export declare const ESInstanceDetails: S.Schema<ESInstanceDetails>;
export interface MemoryDBInstanceDetails {
    Family?: string;
    NodeType?: string;
    Region?: string;
    CurrentGeneration?: boolean;
    SizeFlexEligible?: boolean;
}
export declare const MemoryDBInstanceDetails: S.Schema<MemoryDBInstanceDetails>;
export interface InstanceDetails {
    EC2InstanceDetails?: EC2InstanceDetails;
    RDSInstanceDetails?: RDSInstanceDetails;
    RedshiftInstanceDetails?: RedshiftInstanceDetails;
    ElastiCacheInstanceDetails?: ElastiCacheInstanceDetails;
    ESInstanceDetails?: ESInstanceDetails;
    MemoryDBInstanceDetails?: MemoryDBInstanceDetails;
}
export declare const InstanceDetails: S.Schema<InstanceDetails>;
export interface DynamoDBCapacityDetails {
    CapacityUnits?: string;
    Region?: string;
}
export declare const DynamoDBCapacityDetails: S.Schema<DynamoDBCapacityDetails>;
export interface ReservedCapacityDetails {
    DynamoDBCapacityDetails?: DynamoDBCapacityDetails;
}
export declare const ReservedCapacityDetails: S.Schema<ReservedCapacityDetails>;
export interface ReservationPurchaseRecommendationDetail {
    AccountId?: string;
    InstanceDetails?: InstanceDetails;
    RecommendedNumberOfInstancesToPurchase?: string;
    RecommendedNormalizedUnitsToPurchase?: string;
    MinimumNumberOfInstancesUsedPerHour?: string;
    MinimumNormalizedUnitsUsedPerHour?: string;
    MaximumNumberOfInstancesUsedPerHour?: string;
    MaximumNormalizedUnitsUsedPerHour?: string;
    AverageNumberOfInstancesUsedPerHour?: string;
    AverageNormalizedUnitsUsedPerHour?: string;
    AverageUtilization?: string;
    EstimatedBreakEvenInMonths?: string;
    CurrencyCode?: string;
    EstimatedMonthlySavingsAmount?: string;
    EstimatedMonthlySavingsPercentage?: string;
    EstimatedMonthlyOnDemandCost?: string;
    EstimatedReservationCostForLookbackPeriod?: string;
    UpfrontCost?: string;
    RecurringStandardMonthlyCost?: string;
    ReservedCapacityDetails?: ReservedCapacityDetails;
    RecommendedNumberOfCapacityUnitsToPurchase?: string;
    MinimumNumberOfCapacityUnitsUsedPerHour?: string;
    MaximumNumberOfCapacityUnitsUsedPerHour?: string;
    AverageNumberOfCapacityUnitsUsedPerHour?: string;
}
export declare const ReservationPurchaseRecommendationDetail: S.Schema<ReservationPurchaseRecommendationDetail>;
export type ReservationPurchaseRecommendationDetails = ReservationPurchaseRecommendationDetail[];
export declare const ReservationPurchaseRecommendationDetails: any;
export interface ReservationPurchaseRecommendationSummary {
    TotalEstimatedMonthlySavingsAmount?: string;
    TotalEstimatedMonthlySavingsPercentage?: string;
    CurrencyCode?: string;
}
export declare const ReservationPurchaseRecommendationSummary: S.Schema<ReservationPurchaseRecommendationSummary>;
export interface ReservationPurchaseRecommendation {
    AccountScope?: AccountScope;
    LookbackPeriodInDays?: LookbackPeriodInDays;
    TermInYears?: TermInYears;
    PaymentOption?: PaymentOption;
    ServiceSpecification?: ServiceSpecification;
    RecommendationDetails?: ReservationPurchaseRecommendationDetail[];
    RecommendationSummary?: ReservationPurchaseRecommendationSummary;
}
export declare const ReservationPurchaseRecommendation: S.Schema<ReservationPurchaseRecommendation>;
export type ReservationPurchaseRecommendations = ReservationPurchaseRecommendation[];
export declare const ReservationPurchaseRecommendations: any;
export interface GetReservationPurchaseRecommendationResponse {
    Metadata?: ReservationPurchaseRecommendationMetadata;
    Recommendations?: ReservationPurchaseRecommendation[];
    NextPageToken?: string;
}
export declare const GetReservationPurchaseRecommendationResponse: S.Schema<GetReservationPurchaseRecommendationResponse>;
export interface GetReservationUtilizationRequest {
    TimePeriod: DateInterval;
    GroupBy?: GroupDefinition[];
    Granularity?: Granularity;
    Filter?: Expression;
    SortBy?: SortDefinition;
    NextPageToken?: string;
    MaxResults?: number;
}
export declare const GetReservationUtilizationRequest: S.Schema<GetReservationUtilizationRequest>;
export type ReservationGroupKey = string;
export type ReservationGroupValue = string;
export type UtilizationPercentage = string;
export type UtilizationPercentageInUnits = string;
export type PurchasedHours = string;
export type PurchasedUnits = string;
export type TotalActualHours = string;
export type TotalActualUnits = string;
export type UnusedHours = string;
export type UnusedUnits = string;
export type OnDemandCostOfRIHoursUsed = string;
export type NetRISavings = string;
export type TotalPotentialRISavings = string;
export type AmortizedUpfrontFee = string;
export type AmortizedRecurringFee = string;
export type TotalAmortizedFee = string;
export type RICostForUnusedHours = string;
export type RealizedSavings = string;
export type UnrealizedSavings = string;
export interface ReservationAggregates {
    UtilizationPercentage?: string;
    UtilizationPercentageInUnits?: string;
    PurchasedHours?: string;
    PurchasedUnits?: string;
    TotalActualHours?: string;
    TotalActualUnits?: string;
    UnusedHours?: string;
    UnusedUnits?: string;
    OnDemandCostOfRIHoursUsed?: string;
    NetRISavings?: string;
    TotalPotentialRISavings?: string;
    AmortizedUpfrontFee?: string;
    AmortizedRecurringFee?: string;
    TotalAmortizedFee?: string;
    RICostForUnusedHours?: string;
    RealizedSavings?: string;
    UnrealizedSavings?: string;
}
export declare const ReservationAggregates: S.Schema<ReservationAggregates>;
export interface ReservationUtilizationGroup {
    Key?: string;
    Value?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    Utilization?: ReservationAggregates;
}
export declare const ReservationUtilizationGroup: S.Schema<ReservationUtilizationGroup>;
export type ReservationUtilizationGroups = ReservationUtilizationGroup[];
export declare const ReservationUtilizationGroups: any;
export interface UtilizationByTime {
    TimePeriod?: DateInterval;
    Groups?: ReservationUtilizationGroup[];
    Total?: ReservationAggregates;
}
export declare const UtilizationByTime: S.Schema<UtilizationByTime>;
export type UtilizationsByTime = UtilizationByTime[];
export declare const UtilizationsByTime: any;
export interface GetReservationUtilizationResponse {
    UtilizationsByTime: UtilizationByTime[];
    Total?: ReservationAggregates;
    NextPageToken?: string;
}
export declare const GetReservationUtilizationResponse: S.Schema<GetReservationUtilizationResponse>;
export type RecommendationTarget = "SAME_INSTANCE_FAMILY" | "CROSS_INSTANCE_FAMILY" | (string & {});
export declare const RecommendationTarget: any;
export interface RightsizingRecommendationConfiguration {
    RecommendationTarget: RecommendationTarget;
    BenefitsConsidered: boolean;
}
export declare const RightsizingRecommendationConfiguration: S.Schema<RightsizingRecommendationConfiguration>;
export interface GetRightsizingRecommendationRequest {
    Filter?: Expression;
    Configuration?: RightsizingRecommendationConfiguration;
    Service: string;
    PageSize?: number;
    NextPageToken?: string;
}
export declare const GetRightsizingRecommendationRequest: S.Schema<GetRightsizingRecommendationRequest>;
export interface RightsizingRecommendationMetadata {
    RecommendationId?: string;
    GenerationTimestamp?: string;
    LookbackPeriodInDays?: LookbackPeriodInDays;
    AdditionalMetadata?: string;
}
export declare const RightsizingRecommendationMetadata: S.Schema<RightsizingRecommendationMetadata>;
export interface RightsizingRecommendationSummary {
    TotalRecommendationCount?: string;
    EstimatedTotalMonthlySavingsAmount?: string;
    SavingsCurrencyCode?: string;
    SavingsPercentage?: string;
}
export declare const RightsizingRecommendationSummary: S.Schema<RightsizingRecommendationSummary>;
export type TagValuesList = TagValues[];
export declare const TagValuesList: any;
export interface EC2ResourceDetails {
    HourlyOnDemandRate?: string;
    InstanceType?: string;
    Platform?: string;
    Region?: string;
    Sku?: string;
    Memory?: string;
    NetworkPerformance?: string;
    Storage?: string;
    Vcpu?: string;
}
export declare const EC2ResourceDetails: S.Schema<EC2ResourceDetails>;
export interface ResourceDetails {
    EC2ResourceDetails?: EC2ResourceDetails;
}
export declare const ResourceDetails: S.Schema<ResourceDetails>;
export interface EBSResourceUtilization {
    EbsReadOpsPerSecond?: string;
    EbsWriteOpsPerSecond?: string;
    EbsReadBytesPerSecond?: string;
    EbsWriteBytesPerSecond?: string;
}
export declare const EBSResourceUtilization: S.Schema<EBSResourceUtilization>;
export interface DiskResourceUtilization {
    DiskReadOpsPerSecond?: string;
    DiskWriteOpsPerSecond?: string;
    DiskReadBytesPerSecond?: string;
    DiskWriteBytesPerSecond?: string;
}
export declare const DiskResourceUtilization: S.Schema<DiskResourceUtilization>;
export interface NetworkResourceUtilization {
    NetworkInBytesPerSecond?: string;
    NetworkOutBytesPerSecond?: string;
    NetworkPacketsInPerSecond?: string;
    NetworkPacketsOutPerSecond?: string;
}
export declare const NetworkResourceUtilization: S.Schema<NetworkResourceUtilization>;
export interface EC2ResourceUtilization {
    MaxCpuUtilizationPercentage?: string;
    MaxMemoryUtilizationPercentage?: string;
    MaxStorageUtilizationPercentage?: string;
    EBSResourceUtilization?: EBSResourceUtilization;
    DiskResourceUtilization?: DiskResourceUtilization;
    NetworkResourceUtilization?: NetworkResourceUtilization;
}
export declare const EC2ResourceUtilization: S.Schema<EC2ResourceUtilization>;
export interface ResourceUtilization {
    EC2ResourceUtilization?: EC2ResourceUtilization;
}
export declare const ResourceUtilization: S.Schema<ResourceUtilization>;
export interface CurrentInstance {
    ResourceId?: string;
    InstanceName?: string;
    Tags?: TagValues[];
    ResourceDetails?: ResourceDetails;
    ResourceUtilization?: ResourceUtilization;
    ReservationCoveredHoursInLookbackPeriod?: string;
    SavingsPlansCoveredHoursInLookbackPeriod?: string;
    OnDemandHoursInLookbackPeriod?: string;
    TotalRunningHoursInLookbackPeriod?: string;
    MonthlyCost?: string;
    CurrencyCode?: string;
}
export declare const CurrentInstance: S.Schema<CurrentInstance>;
export type RightsizingType = "TERMINATE" | "MODIFY" | (string & {});
export declare const RightsizingType: any;
export type PlatformDifference = "HYPERVISOR" | "NETWORK_INTERFACE" | "STORAGE_INTERFACE" | "INSTANCE_STORE_AVAILABILITY" | "VIRTUALIZATION_TYPE" | (string & {});
export declare const PlatformDifference: any;
export type PlatformDifferences = PlatformDifference[];
export declare const PlatformDifferences: any;
export interface TargetInstance {
    EstimatedMonthlyCost?: string;
    EstimatedMonthlySavings?: string;
    CurrencyCode?: string;
    DefaultTargetInstance?: boolean;
    ResourceDetails?: ResourceDetails;
    ExpectedResourceUtilization?: ResourceUtilization;
    PlatformDifferences?: PlatformDifference[];
}
export declare const TargetInstance: S.Schema<TargetInstance>;
export type TargetInstancesList = TargetInstance[];
export declare const TargetInstancesList: any;
export interface ModifyRecommendationDetail {
    TargetInstances?: TargetInstance[];
}
export declare const ModifyRecommendationDetail: S.Schema<ModifyRecommendationDetail>;
export interface TerminateRecommendationDetail {
    EstimatedMonthlySavings?: string;
    CurrencyCode?: string;
}
export declare const TerminateRecommendationDetail: S.Schema<TerminateRecommendationDetail>;
export type FindingReasonCode = "CPU_OVER_PROVISIONED" | "CPU_UNDER_PROVISIONED" | "MEMORY_OVER_PROVISIONED" | "MEMORY_UNDER_PROVISIONED" | "EBS_THROUGHPUT_OVER_PROVISIONED" | "EBS_THROUGHPUT_UNDER_PROVISIONED" | "EBS_IOPS_OVER_PROVISIONED" | "EBS_IOPS_UNDER_PROVISIONED" | "NETWORK_BANDWIDTH_OVER_PROVISIONED" | "NETWORK_BANDWIDTH_UNDER_PROVISIONED" | "NETWORK_PPS_OVER_PROVISIONED" | "NETWORK_PPS_UNDER_PROVISIONED" | "DISK_IOPS_OVER_PROVISIONED" | "DISK_IOPS_UNDER_PROVISIONED" | "DISK_THROUGHPUT_OVER_PROVISIONED" | "DISK_THROUGHPUT_UNDER_PROVISIONED" | (string & {});
export declare const FindingReasonCode: any;
export type FindingReasonCodes = FindingReasonCode[];
export declare const FindingReasonCodes: any;
export interface RightsizingRecommendation {
    AccountId?: string;
    CurrentInstance?: CurrentInstance;
    RightsizingType?: RightsizingType;
    ModifyRecommendationDetail?: ModifyRecommendationDetail;
    TerminateRecommendationDetail?: TerminateRecommendationDetail;
    FindingReasonCodes?: FindingReasonCode[];
}
export declare const RightsizingRecommendation: S.Schema<RightsizingRecommendation>;
export type RightsizingRecommendationList = RightsizingRecommendation[];
export declare const RightsizingRecommendationList: any;
export interface GetRightsizingRecommendationResponse {
    Metadata?: RightsizingRecommendationMetadata;
    Summary?: RightsizingRecommendationSummary;
    RightsizingRecommendations?: RightsizingRecommendation[];
    NextPageToken?: string;
    Configuration?: RightsizingRecommendationConfiguration;
}
export declare const GetRightsizingRecommendationResponse: S.Schema<GetRightsizingRecommendationResponse>;
export type RecommendationDetailId = string;
export interface GetSavingsPlanPurchaseRecommendationDetailsRequest {
    RecommendationDetailId: string;
}
export declare const GetSavingsPlanPurchaseRecommendationDetailsRequest: S.Schema<GetSavingsPlanPurchaseRecommendationDetailsRequest>;
export interface RecommendationDetailData {
    AccountScope?: AccountScope;
    LookbackPeriodInDays?: LookbackPeriodInDays;
    SavingsPlansType?: SupportedSavingsPlansType;
    TermInYears?: TermInYears;
    PaymentOption?: PaymentOption;
    AccountId?: string;
    CurrencyCode?: string;
    InstanceFamily?: string;
    Region?: string;
    OfferingId?: string;
    GenerationTimestamp?: string;
    LatestUsageTimestamp?: string;
    CurrentAverageHourlyOnDemandSpend?: string;
    CurrentMaximumHourlyOnDemandSpend?: string;
    CurrentMinimumHourlyOnDemandSpend?: string;
    EstimatedAverageUtilization?: string;
    EstimatedMonthlySavingsAmount?: string;
    EstimatedOnDemandCost?: string;
    EstimatedOnDemandCostWithCurrentCommitment?: string;
    EstimatedROI?: string;
    EstimatedSPCost?: string;
    EstimatedSavingsAmount?: string;
    EstimatedSavingsPercentage?: string;
    ExistingHourlyCommitment?: string;
    HourlyCommitmentToPurchase?: string;
    UpfrontCost?: string;
    CurrentAverageCoverage?: string;
    EstimatedAverageCoverage?: string;
    MetricsOverLookbackPeriod?: RecommendationDetailHourlyMetrics[];
}
export declare const RecommendationDetailData: S.Schema<RecommendationDetailData>;
export interface GetSavingsPlanPurchaseRecommendationDetailsResponse {
    RecommendationDetailId?: string;
    RecommendationDetailData?: RecommendationDetailData;
}
export declare const GetSavingsPlanPurchaseRecommendationDetailsResponse: S.Schema<GetSavingsPlanPurchaseRecommendationDetailsResponse>;
export interface GetSavingsPlansCoverageRequest {
    TimePeriod: DateInterval;
    GroupBy?: GroupDefinition[];
    Granularity?: Granularity;
    Filter?: Expression;
    Metrics?: string[];
    NextToken?: string;
    MaxResults?: number;
    SortBy?: SortDefinition;
}
export declare const GetSavingsPlansCoverageRequest: S.Schema<GetSavingsPlansCoverageRequest>;
export interface SavingsPlansCoverageData {
    SpendCoveredBySavingsPlans?: string;
    OnDemandCost?: string;
    TotalCost?: string;
    CoveragePercentage?: string;
}
export declare const SavingsPlansCoverageData: S.Schema<SavingsPlansCoverageData>;
export interface SavingsPlansCoverage {
    Attributes?: {
        [key: string]: string | undefined;
    };
    Coverage?: SavingsPlansCoverageData;
    TimePeriod?: DateInterval;
}
export declare const SavingsPlansCoverage: S.Schema<SavingsPlansCoverage>;
export type SavingsPlansCoverages = SavingsPlansCoverage[];
export declare const SavingsPlansCoverages: any;
export interface GetSavingsPlansCoverageResponse {
    SavingsPlansCoverages: SavingsPlansCoverage[];
    NextToken?: string;
}
export declare const GetSavingsPlansCoverageResponse: S.Schema<GetSavingsPlansCoverageResponse>;
export interface GetSavingsPlansPurchaseRecommendationRequest {
    SavingsPlansType: SupportedSavingsPlansType;
    TermInYears: TermInYears;
    PaymentOption: PaymentOption;
    AccountScope?: AccountScope;
    NextPageToken?: string;
    PageSize?: number;
    LookbackPeriodInDays: LookbackPeriodInDays;
    Filter?: Expression;
}
export declare const GetSavingsPlansPurchaseRecommendationRequest: S.Schema<GetSavingsPlansPurchaseRecommendationRequest>;
export interface SavingsPlansPurchaseRecommendationMetadata {
    RecommendationId?: string;
    GenerationTimestamp?: string;
    AdditionalMetadata?: string;
}
export declare const SavingsPlansPurchaseRecommendationMetadata: S.Schema<SavingsPlansPurchaseRecommendationMetadata>;
export interface SavingsPlansDetails {
    Region?: string;
    InstanceFamily?: string;
    OfferingId?: string;
}
export declare const SavingsPlansDetails: S.Schema<SavingsPlansDetails>;
export interface SavingsPlansPurchaseRecommendationDetail {
    SavingsPlansDetails?: SavingsPlansDetails;
    AccountId?: string;
    UpfrontCost?: string;
    EstimatedROI?: string;
    CurrencyCode?: string;
    EstimatedSPCost?: string;
    EstimatedOnDemandCost?: string;
    EstimatedOnDemandCostWithCurrentCommitment?: string;
    EstimatedSavingsAmount?: string;
    EstimatedSavingsPercentage?: string;
    HourlyCommitmentToPurchase?: string;
    EstimatedAverageUtilization?: string;
    EstimatedMonthlySavingsAmount?: string;
    CurrentMinimumHourlyOnDemandSpend?: string;
    CurrentMaximumHourlyOnDemandSpend?: string;
    CurrentAverageHourlyOnDemandSpend?: string;
    RecommendationDetailId?: string;
}
export declare const SavingsPlansPurchaseRecommendationDetail: S.Schema<SavingsPlansPurchaseRecommendationDetail>;
export type SavingsPlansPurchaseRecommendationDetailList = SavingsPlansPurchaseRecommendationDetail[];
export declare const SavingsPlansPurchaseRecommendationDetailList: any;
export interface SavingsPlansPurchaseRecommendationSummary {
    EstimatedROI?: string;
    CurrencyCode?: string;
    EstimatedTotalCost?: string;
    CurrentOnDemandSpend?: string;
    EstimatedSavingsAmount?: string;
    TotalRecommendationCount?: string;
    DailyCommitmentToPurchase?: string;
    HourlyCommitmentToPurchase?: string;
    EstimatedSavingsPercentage?: string;
    EstimatedMonthlySavingsAmount?: string;
    EstimatedOnDemandCostWithCurrentCommitment?: string;
}
export declare const SavingsPlansPurchaseRecommendationSummary: S.Schema<SavingsPlansPurchaseRecommendationSummary>;
export interface SavingsPlansPurchaseRecommendation {
    AccountScope?: AccountScope;
    SavingsPlansType?: SupportedSavingsPlansType;
    TermInYears?: TermInYears;
    PaymentOption?: PaymentOption;
    LookbackPeriodInDays?: LookbackPeriodInDays;
    SavingsPlansPurchaseRecommendationDetails?: SavingsPlansPurchaseRecommendationDetail[];
    SavingsPlansPurchaseRecommendationSummary?: SavingsPlansPurchaseRecommendationSummary;
}
export declare const SavingsPlansPurchaseRecommendation: S.Schema<SavingsPlansPurchaseRecommendation>;
export interface GetSavingsPlansPurchaseRecommendationResponse {
    Metadata?: SavingsPlansPurchaseRecommendationMetadata;
    SavingsPlansPurchaseRecommendation?: SavingsPlansPurchaseRecommendation;
    NextPageToken?: string;
}
export declare const GetSavingsPlansPurchaseRecommendationResponse: S.Schema<GetSavingsPlansPurchaseRecommendationResponse>;
export interface GetSavingsPlansUtilizationRequest {
    TimePeriod: DateInterval;
    Granularity?: Granularity;
    Filter?: Expression;
    SortBy?: SortDefinition;
}
export declare const GetSavingsPlansUtilizationRequest: S.Schema<GetSavingsPlansUtilizationRequest>;
export interface SavingsPlansUtilization {
    TotalCommitment?: string;
    UsedCommitment?: string;
    UnusedCommitment?: string;
    UtilizationPercentage?: string;
}
export declare const SavingsPlansUtilization: S.Schema<SavingsPlansUtilization>;
export interface SavingsPlansSavings {
    NetSavings?: string;
    OnDemandCostEquivalent?: string;
}
export declare const SavingsPlansSavings: S.Schema<SavingsPlansSavings>;
export interface SavingsPlansAmortizedCommitment {
    AmortizedRecurringCommitment?: string;
    AmortizedUpfrontCommitment?: string;
    TotalAmortizedCommitment?: string;
}
export declare const SavingsPlansAmortizedCommitment: S.Schema<SavingsPlansAmortizedCommitment>;
export interface SavingsPlansUtilizationByTime {
    TimePeriod: DateInterval;
    Utilization: SavingsPlansUtilization;
    Savings?: SavingsPlansSavings;
    AmortizedCommitment?: SavingsPlansAmortizedCommitment;
}
export declare const SavingsPlansUtilizationByTime: S.Schema<SavingsPlansUtilizationByTime>;
export type SavingsPlansUtilizationsByTime = SavingsPlansUtilizationByTime[];
export declare const SavingsPlansUtilizationsByTime: any;
export interface SavingsPlansUtilizationAggregates {
    Utilization: SavingsPlansUtilization;
    Savings?: SavingsPlansSavings;
    AmortizedCommitment?: SavingsPlansAmortizedCommitment;
}
export declare const SavingsPlansUtilizationAggregates: S.Schema<SavingsPlansUtilizationAggregates>;
export interface GetSavingsPlansUtilizationResponse {
    SavingsPlansUtilizationsByTime?: SavingsPlansUtilizationByTime[];
    Total: SavingsPlansUtilizationAggregates;
}
export declare const GetSavingsPlansUtilizationResponse: S.Schema<GetSavingsPlansUtilizationResponse>;
export type SavingsPlansDataType = "ATTRIBUTES" | "UTILIZATION" | "AMORTIZED_COMMITMENT" | "SAVINGS" | (string & {});
export declare const SavingsPlansDataType: any;
export type SavingsPlansDataTypes = SavingsPlansDataType[];
export declare const SavingsPlansDataTypes: any;
export interface GetSavingsPlansUtilizationDetailsRequest {
    TimePeriod: DateInterval;
    Filter?: Expression;
    DataType?: SavingsPlansDataType[];
    NextToken?: string;
    MaxResults?: number;
    SortBy?: SortDefinition;
}
export declare const GetSavingsPlansUtilizationDetailsRequest: S.Schema<GetSavingsPlansUtilizationDetailsRequest>;
export type SavingsPlanArn = string;
export interface SavingsPlansUtilizationDetail {
    SavingsPlanArn?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    Utilization?: SavingsPlansUtilization;
    Savings?: SavingsPlansSavings;
    AmortizedCommitment?: SavingsPlansAmortizedCommitment;
}
export declare const SavingsPlansUtilizationDetail: S.Schema<SavingsPlansUtilizationDetail>;
export type SavingsPlansUtilizationDetails = SavingsPlansUtilizationDetail[];
export declare const SavingsPlansUtilizationDetails: any;
export interface GetSavingsPlansUtilizationDetailsResponse {
    SavingsPlansUtilizationDetails: SavingsPlansUtilizationDetail[];
    Total?: SavingsPlansUtilizationAggregates;
    TimePeriod: DateInterval;
    NextToken?: string;
}
export declare const GetSavingsPlansUtilizationDetailsResponse: S.Schema<GetSavingsPlansUtilizationDetailsResponse>;
export interface GetTagsRequest {
    SearchString?: string;
    TimePeriod: DateInterval;
    TagKey?: string;
    Filter?: Expression;
    SortBy?: SortDefinition[];
    BillingViewArn?: string;
    MaxResults?: number;
    NextPageToken?: string;
}
export declare const GetTagsRequest: S.Schema<GetTagsRequest>;
export type Entity = string;
export type TagList = string[];
export declare const TagList: any;
export interface GetTagsResponse {
    NextPageToken?: string;
    Tags: string[];
    ReturnSize: number;
    TotalSize: number;
}
export declare const GetTagsResponse: S.Schema<GetTagsResponse>;
export interface GetUsageForecastRequest {
    TimePeriod: DateInterval;
    Metric: Metric;
    Granularity: Granularity;
    Filter?: Expression;
    BillingViewArn?: string;
    PredictionIntervalLevel?: number;
}
export declare const GetUsageForecastRequest: S.Schema<GetUsageForecastRequest>;
export interface GetUsageForecastResponse {
    Total?: MetricValue;
    ForecastResultsByTime?: ForecastResult[];
}
export declare const GetUsageForecastResponse: S.Schema<GetUsageForecastResponse>;
export type AnalysesPageSize = number;
export type AnalysisIds = string[];
export declare const AnalysisIds: any;
export interface ListCommitmentPurchaseAnalysesRequest {
    AnalysisStatus?: AnalysisStatus;
    NextPageToken?: string;
    PageSize?: number;
    AnalysisIds?: string[];
}
export declare const ListCommitmentPurchaseAnalysesRequest: S.Schema<ListCommitmentPurchaseAnalysesRequest>;
export interface AnalysisSummary {
    EstimatedCompletionTime?: string;
    AnalysisCompletionTime?: string;
    AnalysisStartedTime?: string;
    AnalysisStatus?: AnalysisStatus;
    ErrorCode?: ErrorCode;
    AnalysisId?: string;
    CommitmentPurchaseAnalysisConfiguration?: CommitmentPurchaseAnalysisConfiguration;
}
export declare const AnalysisSummary: S.Schema<AnalysisSummary>;
export type AnalysisSummaryList = AnalysisSummary[];
export declare const AnalysisSummaryList: any;
export interface ListCommitmentPurchaseAnalysesResponse {
    AnalysisSummaryList?: AnalysisSummary[];
    NextPageToken?: string;
}
export declare const ListCommitmentPurchaseAnalysesResponse: S.Schema<ListCommitmentPurchaseAnalysesResponse>;
export type CostAllocationTagsMaxResults = number;
export interface ListCostAllocationTagBackfillHistoryRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListCostAllocationTagBackfillHistoryRequest: S.Schema<ListCostAllocationTagBackfillHistoryRequest>;
export type CostAllocationTagBackfillStatus = "SUCCEEDED" | "PROCESSING" | "FAILED" | (string & {});
export declare const CostAllocationTagBackfillStatus: any;
export interface CostAllocationTagBackfillRequest {
    BackfillFrom?: string;
    RequestedAt?: string;
    CompletedAt?: string;
    BackfillStatus?: CostAllocationTagBackfillStatus;
    LastUpdatedAt?: string;
}
export declare const CostAllocationTagBackfillRequest: S.Schema<CostAllocationTagBackfillRequest>;
export type CostAllocationTagBackfillRequestList = CostAllocationTagBackfillRequest[];
export declare const CostAllocationTagBackfillRequestList: any;
export interface ListCostAllocationTagBackfillHistoryResponse {
    BackfillRequests?: CostAllocationTagBackfillRequest[];
    NextToken?: string;
}
export declare const ListCostAllocationTagBackfillHistoryResponse: S.Schema<ListCostAllocationTagBackfillHistoryResponse>;
export type CostAllocationTagStatus = "Active" | "Inactive" | (string & {});
export declare const CostAllocationTagStatus: any;
export type CostAllocationTagKeyList = string[];
export declare const CostAllocationTagKeyList: any;
export type CostAllocationTagType = "AWSGenerated" | "UserDefined" | (string & {});
export declare const CostAllocationTagType: any;
export interface ListCostAllocationTagsRequest {
    Status?: CostAllocationTagStatus;
    TagKeys?: string[];
    Type?: CostAllocationTagType;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListCostAllocationTagsRequest: S.Schema<ListCostAllocationTagsRequest>;
export interface CostAllocationTag {
    TagKey: string;
    Type: CostAllocationTagType;
    Status: CostAllocationTagStatus;
    LastUpdatedDate?: string;
    LastUsedDate?: string;
}
export declare const CostAllocationTag: S.Schema<CostAllocationTag>;
export type CostAllocationTagList = CostAllocationTag[];
export declare const CostAllocationTagList: any;
export interface ListCostAllocationTagsResponse {
    CostAllocationTags?: CostAllocationTag[];
    NextToken?: string;
}
export declare const ListCostAllocationTagsResponse: S.Schema<ListCostAllocationTagsResponse>;
export type CostCategoryMaxResults = number;
export type ResourceType = string;
export type ResourceTypesFilterInput = string[];
export declare const ResourceTypesFilterInput: any;
export interface ListCostCategoryDefinitionsRequest {
    EffectiveOn?: string;
    NextToken?: string;
    MaxResults?: number;
    SupportedResourceTypes?: string[];
}
export declare const ListCostCategoryDefinitionsRequest: S.Schema<ListCostCategoryDefinitionsRequest>;
export type ResourceTypes = string[];
export declare const ResourceTypes: any;
export interface CostCategoryReference {
    CostCategoryArn?: string;
    Name?: string;
    EffectiveStart?: string;
    EffectiveEnd?: string;
    NumberOfRules?: number;
    ProcessingStatus?: CostCategoryProcessingStatus[];
    Values?: string[];
    DefaultValue?: string;
    SupportedResourceTypes?: string[];
}
export declare const CostCategoryReference: S.Schema<CostCategoryReference>;
export type CostCategoryReferencesList = CostCategoryReference[];
export declare const CostCategoryReferencesList: any;
export interface ListCostCategoryDefinitionsResponse {
    CostCategoryReferences?: CostCategoryReference[];
    NextToken?: string;
}
export declare const ListCostCategoryDefinitionsResponse: S.Schema<ListCostCategoryDefinitionsResponse>;
export interface ListCostCategoryResourceAssociationsRequest {
    CostCategoryArn?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListCostCategoryResourceAssociationsRequest: S.Schema<ListCostCategoryResourceAssociationsRequest>;
export type GenericArn = string;
export interface CostCategoryResourceAssociation {
    ResourceArn?: string;
    CostCategoryName?: string;
    CostCategoryArn?: string;
}
export declare const CostCategoryResourceAssociation: S.Schema<CostCategoryResourceAssociation>;
export type CostCategoryResourceAssociations = CostCategoryResourceAssociation[];
export declare const CostCategoryResourceAssociations: any;
export interface ListCostCategoryResourceAssociationsResponse {
    CostCategoryResourceAssociations?: CostCategoryResourceAssociation[];
    NextToken?: string;
}
export declare const ListCostCategoryResourceAssociationsResponse: S.Schema<ListCostCategoryResourceAssociationsResponse>;
export type GenerationStatus = "SUCCEEDED" | "PROCESSING" | "FAILED" | (string & {});
export declare const GenerationStatus: any;
export type RecommendationId = string;
export type RecommendationIdList = string[];
export declare const RecommendationIdList: any;
export interface ListSavingsPlansPurchaseRecommendationGenerationRequest {
    GenerationStatus?: GenerationStatus;
    RecommendationIds?: string[];
    PageSize?: number;
    NextPageToken?: string;
}
export declare const ListSavingsPlansPurchaseRecommendationGenerationRequest: S.Schema<ListSavingsPlansPurchaseRecommendationGenerationRequest>;
export interface GenerationSummary {
    RecommendationId?: string;
    GenerationStatus?: GenerationStatus;
    GenerationStartedTime?: string;
    GenerationCompletionTime?: string;
    EstimatedCompletionTime?: string;
}
export declare const GenerationSummary: S.Schema<GenerationSummary>;
export type GenerationSummaryList = GenerationSummary[];
export declare const GenerationSummaryList: any;
export interface ListSavingsPlansPurchaseRecommendationGenerationResponse {
    GenerationSummaryList?: GenerationSummary[];
    NextPageToken?: string;
}
export declare const ListSavingsPlansPurchaseRecommendationGenerationResponse: S.Schema<ListSavingsPlansPurchaseRecommendationGenerationResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    ResourceTags?: ResourceTag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ProvideAnomalyFeedbackRequest {
    AnomalyId: string;
    Feedback: AnomalyFeedbackType;
}
export declare const ProvideAnomalyFeedbackRequest: S.Schema<ProvideAnomalyFeedbackRequest>;
export interface ProvideAnomalyFeedbackResponse {
    AnomalyId: string;
}
export declare const ProvideAnomalyFeedbackResponse: S.Schema<ProvideAnomalyFeedbackResponse>;
export interface StartCommitmentPurchaseAnalysisRequest {
    CommitmentPurchaseAnalysisConfiguration: CommitmentPurchaseAnalysisConfiguration;
}
export declare const StartCommitmentPurchaseAnalysisRequest: S.Schema<StartCommitmentPurchaseAnalysisRequest>;
export interface StartCommitmentPurchaseAnalysisResponse {
    AnalysisId: string;
    AnalysisStartedTime: string;
    EstimatedCompletionTime: string;
}
export declare const StartCommitmentPurchaseAnalysisResponse: S.Schema<StartCommitmentPurchaseAnalysisResponse>;
export interface StartCostAllocationTagBackfillRequest {
    BackfillFrom: string;
}
export declare const StartCostAllocationTagBackfillRequest: S.Schema<StartCostAllocationTagBackfillRequest>;
export interface StartCostAllocationTagBackfillResponse {
    BackfillRequest?: CostAllocationTagBackfillRequest;
}
export declare const StartCostAllocationTagBackfillResponse: S.Schema<StartCostAllocationTagBackfillResponse>;
export interface StartSavingsPlansPurchaseRecommendationGenerationRequest {
}
export declare const StartSavingsPlansPurchaseRecommendationGenerationRequest: S.Schema<StartSavingsPlansPurchaseRecommendationGenerationRequest>;
export interface StartSavingsPlansPurchaseRecommendationGenerationResponse {
    RecommendationId?: string;
    GenerationStartedTime?: string;
    EstimatedCompletionTime?: string;
}
export declare const StartSavingsPlansPurchaseRecommendationGenerationResponse: S.Schema<StartSavingsPlansPurchaseRecommendationGenerationResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    ResourceTags: ResourceTag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type ResourceTagKeyList = string[];
export declare const ResourceTagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    ResourceTagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAnomalyMonitorRequest {
    MonitorArn: string;
    MonitorName?: string;
}
export declare const UpdateAnomalyMonitorRequest: S.Schema<UpdateAnomalyMonitorRequest>;
export interface UpdateAnomalyMonitorResponse {
    MonitorArn: string;
}
export declare const UpdateAnomalyMonitorResponse: S.Schema<UpdateAnomalyMonitorResponse>;
export interface UpdateAnomalySubscriptionRequest {
    SubscriptionArn: string;
    Threshold?: number;
    Frequency?: AnomalySubscriptionFrequency;
    MonitorArnList?: string[];
    Subscribers?: Subscriber[];
    SubscriptionName?: string;
    ThresholdExpression?: Expression;
}
export declare const UpdateAnomalySubscriptionRequest: S.Schema<UpdateAnomalySubscriptionRequest>;
export interface UpdateAnomalySubscriptionResponse {
    SubscriptionArn: string;
}
export declare const UpdateAnomalySubscriptionResponse: S.Schema<UpdateAnomalySubscriptionResponse>;
export interface CostAllocationTagStatusEntry {
    TagKey: string;
    Status: CostAllocationTagStatus;
}
export declare const CostAllocationTagStatusEntry: S.Schema<CostAllocationTagStatusEntry>;
export type CostAllocationTagStatusList = CostAllocationTagStatusEntry[];
export declare const CostAllocationTagStatusList: any;
export interface UpdateCostAllocationTagsStatusRequest {
    CostAllocationTagsStatus: CostAllocationTagStatusEntry[];
}
export declare const UpdateCostAllocationTagsStatusRequest: S.Schema<UpdateCostAllocationTagsStatusRequest>;
export type ErrorMessage = string;
export interface UpdateCostAllocationTagsStatusError_ {
    TagKey?: string;
    Code?: string;
    Message?: string;
}
export declare const UpdateCostAllocationTagsStatusError_: S.Schema<UpdateCostAllocationTagsStatusError_>;
export type UpdateCostAllocationTagsStatusErrors = UpdateCostAllocationTagsStatusError_[];
export declare const UpdateCostAllocationTagsStatusErrors: any;
export interface UpdateCostAllocationTagsStatusResponse {
    Errors?: UpdateCostAllocationTagsStatusError_[];
}
export declare const UpdateCostAllocationTagsStatusResponse: S.Schema<UpdateCostAllocationTagsStatusResponse>;
export interface UpdateCostCategoryDefinitionRequest {
    CostCategoryArn: string;
    EffectiveStart?: string;
    RuleVersion: CostCategoryRuleVersion;
    Rules: CostCategoryRule[];
    DefaultValue?: string;
    SplitChargeRules?: CostCategorySplitChargeRule[];
}
export declare const UpdateCostCategoryDefinitionRequest: S.Schema<UpdateCostCategoryDefinitionRequest>;
export interface UpdateCostCategoryDefinitionResponse {
    CostCategoryArn?: string;
    EffectiveStart?: string;
}
export declare const UpdateCostCategoryDefinitionResponse: S.Schema<UpdateCostCategoryDefinitionResponse>;
export type CreateAnomalyMonitorError = LimitExceededException | AnomalyMonitorAlreadyExists | CommonErrors;
/**
 * Creates a new cost anomaly detection monitor with the requested type and monitor
 * specification.
 */
export declare const createAnomalyMonitor: API.OperationMethod<CreateAnomalyMonitorRequest, CreateAnomalyMonitorResponse, CreateAnomalyMonitorError, Credentials | HttpClient.HttpClient>;
export type CreateAnomalySubscriptionError = LimitExceededException | UnknownMonitorException | AnomalySubscriptionAlreadyExists | CommonErrors;
/**
 * Adds an alert subscription to a cost anomaly detection monitor. You can use each
 * subscription to define subscribers with email or SNS notifications. Email subscribers can set
 * an absolute or percentage threshold and a time frequency for receiving notifications.
 */
export declare const createAnomalySubscription: API.OperationMethod<CreateAnomalySubscriptionRequest, CreateAnomalySubscriptionResponse, CreateAnomalySubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateCostCategoryDefinitionError = LimitExceededException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new cost category with the requested name and rules.
 */
export declare const createCostCategoryDefinition: API.OperationMethod<CreateCostCategoryDefinitionRequest, CreateCostCategoryDefinitionResponse, CreateCostCategoryDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteAnomalyMonitorError = LimitExceededException | UnknownMonitorException | CommonErrors;
/**
 * Deletes a cost anomaly monitor.
 */
export declare const deleteAnomalyMonitor: API.OperationMethod<DeleteAnomalyMonitorRequest, DeleteAnomalyMonitorResponse, DeleteAnomalyMonitorError, Credentials | HttpClient.HttpClient>;
export type DeleteAnomalySubscriptionError = LimitExceededException | UnknownSubscriptionException | CommonErrors;
/**
 * Deletes a cost anomaly subscription.
 */
export declare const deleteAnomalySubscription: API.OperationMethod<DeleteAnomalySubscriptionRequest, DeleteAnomalySubscriptionResponse, DeleteAnomalySubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteCostCategoryDefinitionError = LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a cost category. Expenses from this month going forward will no longer be
 * categorized with this cost category.
 */
export declare const deleteCostCategoryDefinition: API.OperationMethod<DeleteCostCategoryDefinitionRequest, DeleteCostCategoryDefinitionResponse, DeleteCostCategoryDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeCostCategoryDefinitionError = LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the name, Amazon Resource Name (ARN), rules, definition, and effective dates of a
 * cost category that's defined in the account.
 *
 * You have the option to use `EffectiveOn` to return a cost category that's
 * active on a specific date. If there's no `EffectiveOn` specified, you see a Cost
 * Category that's effective on the current date. If cost category is still effective,
 * `EffectiveEnd` is omitted in the response.
 */
export declare const describeCostCategoryDefinition: API.OperationMethod<DescribeCostCategoryDefinitionRequest, DescribeCostCategoryDefinitionResponse, DescribeCostCategoryDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetAnomaliesError = InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves all of the cost anomalies detected on your account during the time period that's
 * specified by the `DateInterval` object. Anomalies are available for up to 90
 * days.
 */
export declare const getAnomalies: API.PaginatedOperationMethod<GetAnomaliesRequest, GetAnomaliesResponse, GetAnomaliesError, Credentials | HttpClient.HttpClient, Anomaly>;
export type GetAnomalyMonitorsError = InvalidNextTokenException | LimitExceededException | UnknownMonitorException | CommonErrors;
/**
 * Retrieves the cost anomaly monitor definitions for your account. You can filter using a
 * list of cost anomaly monitor Amazon Resource Names (ARNs).
 */
export declare const getAnomalyMonitors: API.PaginatedOperationMethod<GetAnomalyMonitorsRequest, GetAnomalyMonitorsResponse, GetAnomalyMonitorsError, Credentials | HttpClient.HttpClient, AnomalyMonitor>;
export type GetAnomalySubscriptionsError = InvalidNextTokenException | LimitExceededException | UnknownSubscriptionException | CommonErrors;
/**
 * Retrieves the cost anomaly subscription objects for your account. You can filter using a
 * list of cost anomaly monitor Amazon Resource Names (ARNs).
 */
export declare const getAnomalySubscriptions: API.PaginatedOperationMethod<GetAnomalySubscriptionsRequest, GetAnomalySubscriptionsResponse, GetAnomalySubscriptionsError, Credentials | HttpClient.HttpClient, AnomalySubscription>;
export type GetApproximateUsageRecordsError = DataUnavailableException | LimitExceededException | CommonErrors;
/**
 * Retrieves estimated usage records for hourly granularity or resource-level data at daily
 * granularity.
 */
export declare const getApproximateUsageRecords: API.OperationMethod<GetApproximateUsageRecordsRequest, GetApproximateUsageRecordsResponse, GetApproximateUsageRecordsError, Credentials | HttpClient.HttpClient>;
export type GetCommitmentPurchaseAnalysisError = AnalysisNotFoundException | DataUnavailableException | LimitExceededException | CommonErrors;
/**
 * Retrieves a commitment purchase analysis result based on the
 * `AnalysisId`.
 */
export declare const getCommitmentPurchaseAnalysis: API.OperationMethod<GetCommitmentPurchaseAnalysisRequest, GetCommitmentPurchaseAnalysisResponse, GetCommitmentPurchaseAnalysisError, Credentials | HttpClient.HttpClient>;
export type GetCostAndUsageError = BillExpirationException | BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | RequestChangedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves cost and usage metrics for your account. You can specify which cost and
 * usage-related metric that you want the request to return. For example, you can specify
 * `BlendedCosts` or `UsageQuantity`. You can also filter and group your
 * data by various dimensions, such as `SERVICE` or `AZ`, in a specific
 * time range. For a complete list of valid dimensions, see the GetDimensionValues operation. Management account in an organization in Organizations have access to all member accounts.
 *
 * For information about filter limitations, see Quotas and restrictions
 * in the *Billing and Cost Management User Guide*.
 */
export declare const getCostAndUsage: API.OperationMethod<GetCostAndUsageRequest, GetCostAndUsageResponse, GetCostAndUsageError, Credentials | HttpClient.HttpClient>;
export type GetCostAndUsageComparisonsError = BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves cost and usage comparisons for your account between two periods within the last
 * 13 months. If you have enabled multi-year data at monthly granularity, you can go back up to
 * 38 months.
 */
export declare const getCostAndUsageComparisons: API.PaginatedOperationMethod<GetCostAndUsageComparisonsRequest, GetCostAndUsageComparisonsResponse, GetCostAndUsageComparisonsError, Credentials | HttpClient.HttpClient, CostAndUsageComparison>;
export type GetCostAndUsageWithResourcesError = BillExpirationException | BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | RequestChangedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves cost and usage metrics with resources for your account. You can specify which
 * cost and usage-related metric, such as `BlendedCosts` or
 * `UsageQuantity`, that you want the request to return. You can also filter and group
 * your data by various dimensions, such as `SERVICE` or `AZ`, in a
 * specific time range. For a complete list of valid dimensions, see the GetDimensionValues operation. Management account in an organization in Organizations have access to all member accounts.
 *
 * Hourly granularity is only available for EC2-Instances (Elastic Compute Cloud)
 * resource-level data. All other resource-level data is available at daily
 * granularity.
 *
 * This is an opt-in only feature. You can enable this feature from the Cost Explorer
 * Settings page. For information about how to access the Settings page, see Controlling
 * Access for Cost Explorer in the Billing and Cost Management User
 * Guide.
 */
export declare const getCostAndUsageWithResources: API.OperationMethod<GetCostAndUsageWithResourcesRequest, GetCostAndUsageWithResourcesResponse, GetCostAndUsageWithResourcesError, Credentials | HttpClient.HttpClient>;
export type GetCostCategoriesError = BillExpirationException | BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | RequestChangedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves an array of cost category names and values incurred cost.
 *
 * If some cost category names and values are not associated with any cost, they will not
 * be returned by this API.
 */
export declare const getCostCategories: API.OperationMethod<GetCostCategoriesRequest, GetCostCategoriesResponse, GetCostCategoriesError, Credentials | HttpClient.HttpClient>;
export type GetCostComparisonDriversError = BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves key factors driving cost changes between two time periods within the last 13
 * months, such as usage changes, discount changes, and commitment-based savings. If you have
 * enabled multi-year data at monthly granularity, you can go back up to 38 months.
 */
export declare const getCostComparisonDrivers: API.PaginatedOperationMethod<GetCostComparisonDriversRequest, GetCostComparisonDriversResponse, GetCostComparisonDriversError, Credentials | HttpClient.HttpClient, CostComparisonDriver>;
export type GetCostForecastError = BillingViewHealthStatusException | DataUnavailableException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a forecast for how much Amazon Web Services predicts that you will spend over
 * the forecast time period that you select, based on your past costs.
 */
export declare const getCostForecast: API.OperationMethod<GetCostForecastRequest, GetCostForecastResponse, GetCostForecastError, Credentials | HttpClient.HttpClient>;
export type GetDimensionValuesError = BillExpirationException | BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | RequestChangedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves all available filter values for a specified filter over a period of time. You
 * can search the dimension values for an arbitrary string.
 */
export declare const getDimensionValues: API.OperationMethod<GetDimensionValuesRequest, GetDimensionValuesResponse, GetDimensionValuesError, Credentials | HttpClient.HttpClient>;
export type GetReservationCoverageError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves the reservation coverage for your account, which you can use to see how much
 * of your Amazon Elastic Compute Cloud, Amazon ElastiCache, Amazon Relational Database Service,
 * or Amazon Redshift usage is covered by a reservation. An organization's management account can
 * see the coverage of the associated member accounts. This supports dimensions, cost categories,
 * and nested expressions. For any time period, you can filter data about reservation usage by
 * the following dimensions:
 *
 * - AZ
 *
 * - CACHE_ENGINE
 *
 * - DATABASE_ENGINE
 *
 * - DEPLOYMENT_OPTION
 *
 * - INSTANCE_TYPE
 *
 * - LINKED_ACCOUNT
 *
 * - OPERATING_SYSTEM
 *
 * - PLATFORM
 *
 * - REGION
 *
 * - SERVICE
 *
 * - TAG
 *
 * - TENANCY
 *
 * To determine valid values for a dimension, use the `GetDimensionValues`
 * operation.
 */
export declare const getReservationCoverage: API.OperationMethod<GetReservationCoverageRequest, GetReservationCoverageResponse, GetReservationCoverageError, Credentials | HttpClient.HttpClient>;
export type GetReservationPurchaseRecommendationError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Gets recommendations for reservation purchases. These recommendations might help you to
 * reduce your costs. Reservations provide a discounted hourly rate (up to 75%) compared to
 * On-Demand pricing.
 *
 * Amazon Web Services generates your recommendations by identifying your On-Demand usage
 * during a specific time period and collecting your usage into categories that are eligible for
 * a reservation. After Amazon Web Services has these categories, it simulates every combination
 * of reservations in each category of usage to identify the best number of each type of Reserved
 * Instance (RI) to purchase to maximize your estimated savings.
 *
 * For example, Amazon Web Services automatically aggregates your Amazon EC2 Linux, shared
 * tenancy, and c4 family usage in the US West (Oregon) Region and recommends that you buy
 * size-flexible regional reservations to apply to the c4 family usage. Amazon Web Services
 * recommends the smallest size instance in an instance family. This makes it easier to purchase
 * a size-flexible Reserved Instance (RI). Amazon Web Services also shows the equal number of
 * normalized units. This way, you can purchase any instance size that you want. For this
 * example, your RI recommendation is for `c4.large` because that is the smallest size
 * instance in the c4 instance family.
 */
export declare const getReservationPurchaseRecommendation: API.PaginatedOperationMethod<GetReservationPurchaseRecommendationRequest, GetReservationPurchaseRecommendationResponse, GetReservationPurchaseRecommendationError, Credentials | HttpClient.HttpClient, ReservationPurchaseRecommendation>;
export type GetReservationUtilizationError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves the reservation utilization for your account. Management account in an
 * organization have access to member accounts. You can filter data by dimensions in a time
 * period. You can use `GetDimensionValues` to determine the possible dimension
 * values. Currently, you can group only by `SUBSCRIPTION_ID`.
 */
export declare const getReservationUtilization: API.OperationMethod<GetReservationUtilizationRequest, GetReservationUtilizationResponse, GetReservationUtilizationError, Credentials | HttpClient.HttpClient>;
export type GetRightsizingRecommendationError = InvalidNextTokenException | LimitExceededException | RightsizingRecommendationNotEnabled | CommonErrors;
/**
 * Creates recommendations that help you save cost by identifying idle and underutilized
 * Amazon EC2 instances.
 *
 * Recommendations are generated to either downsize or terminate instances, along with
 * providing savings detail and metrics. For more information about calculation and function, see
 * Optimizing Your Cost with Rightsizing Recommendations in the *Billing and Cost Management User Guide*.
 */
export declare const getRightsizingRecommendation: API.PaginatedOperationMethod<GetRightsizingRecommendationRequest, GetRightsizingRecommendationResponse, GetRightsizingRecommendationError, Credentials | HttpClient.HttpClient, RightsizingRecommendation>;
export type GetSavingsPlanPurchaseRecommendationDetailsError = DataUnavailableException | LimitExceededException | CommonErrors;
/**
 * Retrieves the details for a Savings Plan recommendation. These details include the hourly
 * data-points that construct the cost, coverage, and utilization charts.
 */
export declare const getSavingsPlanPurchaseRecommendationDetails: API.OperationMethod<GetSavingsPlanPurchaseRecommendationDetailsRequest, GetSavingsPlanPurchaseRecommendationDetailsResponse, GetSavingsPlanPurchaseRecommendationDetailsError, Credentials | HttpClient.HttpClient>;
export type GetSavingsPlansCoverageError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves the Savings Plans covered for your account. This enables you to see how much of
 * your cost is covered by a Savings Plan. An organization’s management account can see the
 * coverage of the associated member accounts. This supports dimensions, cost categories, and
 * nested expressions. For any time period, you can filter data for Savings Plans usage with the
 * following dimensions:
 *
 * - `LINKED_ACCOUNT`
 *
 * - `REGION`
 *
 * - `SERVICE`
 *
 * - `INSTANCE_FAMILY`
 *
 * To determine valid values for a dimension, use the `GetDimensionValues`
 * operation.
 */
export declare const getSavingsPlansCoverage: API.PaginatedOperationMethod<GetSavingsPlansCoverageRequest, GetSavingsPlansCoverageResponse, GetSavingsPlansCoverageError, Credentials | HttpClient.HttpClient, unknown>;
export type GetSavingsPlansPurchaseRecommendationError = InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves the Savings Plans recommendations for your account. First use
 * `StartSavingsPlansPurchaseRecommendationGeneration` to generate a new set of
 * recommendations, and then use `GetSavingsPlansPurchaseRecommendation` to retrieve
 * them.
 */
export declare const getSavingsPlansPurchaseRecommendation: API.OperationMethod<GetSavingsPlansPurchaseRecommendationRequest, GetSavingsPlansPurchaseRecommendationResponse, GetSavingsPlansPurchaseRecommendationError, Credentials | HttpClient.HttpClient>;
export type GetSavingsPlansUtilizationError = DataUnavailableException | LimitExceededException | CommonErrors;
/**
 * Retrieves the Savings Plans utilization for your account across date ranges with daily or
 * monthly granularity. Management account in an organization have access to member accounts. You
 * can use `GetDimensionValues` in `SAVINGS_PLANS` to determine the
 * possible dimension values.
 *
 * You can't group by any dimension values for
 * `GetSavingsPlansUtilization`.
 */
export declare const getSavingsPlansUtilization: API.OperationMethod<GetSavingsPlansUtilizationRequest, GetSavingsPlansUtilizationResponse, GetSavingsPlansUtilizationError, Credentials | HttpClient.HttpClient>;
export type GetSavingsPlansUtilizationDetailsError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves attribute data along with aggregate utilization and savings data for a given
 * time period. This doesn't support granular or grouped data (daily/monthly) in response. You
 * can't retrieve data by dates in a single response similar to
 * `GetSavingsPlanUtilization`, but you have the option to make multiple calls to
 * `GetSavingsPlanUtilizationDetails` by providing individual dates. You can use
 * `GetDimensionValues` in `SAVINGS_PLANS` to determine the possible
 * dimension values.
 *
 * `GetSavingsPlanUtilizationDetails` internally groups data by
 * `SavingsPlansArn`.
 */
export declare const getSavingsPlansUtilizationDetails: API.PaginatedOperationMethod<GetSavingsPlansUtilizationDetailsRequest, GetSavingsPlansUtilizationDetailsResponse, GetSavingsPlansUtilizationDetailsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetTagsError = BillExpirationException | BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | RequestChangedException | ResourceNotFoundException | CommonErrors;
/**
 * Queries for available tag keys and tag values for a specified period. You can search
 * the tag values for an arbitrary string.
 */
export declare const getTags: API.OperationMethod<GetTagsRequest, GetTagsResponse, GetTagsError, Credentials | HttpClient.HttpClient>;
export type GetUsageForecastError = BillingViewHealthStatusException | DataUnavailableException | LimitExceededException | ResourceNotFoundException | UnresolvableUsageUnitException | CommonErrors;
/**
 * Retrieves a forecast for how much Amazon Web Services predicts that you will use
 * over the forecast time period that you select, based on your past usage.
 */
export declare const getUsageForecast: API.OperationMethod<GetUsageForecastRequest, GetUsageForecastResponse, GetUsageForecastError, Credentials | HttpClient.HttpClient>;
export type ListCommitmentPurchaseAnalysesError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Lists the commitment purchase analyses for your account.
 */
export declare const listCommitmentPurchaseAnalyses: API.PaginatedOperationMethod<ListCommitmentPurchaseAnalysesRequest, ListCommitmentPurchaseAnalysesResponse, ListCommitmentPurchaseAnalysesError, Credentials | HttpClient.HttpClient, AnalysisSummary>;
export type ListCostAllocationTagBackfillHistoryError = InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves a list of your historical cost allocation tag backfill requests.
 */
export declare const listCostAllocationTagBackfillHistory: API.PaginatedOperationMethod<ListCostAllocationTagBackfillHistoryRequest, ListCostAllocationTagBackfillHistoryResponse, ListCostAllocationTagBackfillHistoryError, Credentials | HttpClient.HttpClient, CostAllocationTagBackfillRequest>;
export type ListCostAllocationTagsError = InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Get a list of cost allocation tags. All inputs in the API are optional and serve as
 * filters. By default, all cost allocation tags are returned.
 */
export declare const listCostAllocationTags: API.PaginatedOperationMethod<ListCostAllocationTagsRequest, ListCostAllocationTagsResponse, ListCostAllocationTagsError, Credentials | HttpClient.HttpClient, CostAllocationTag>;
export type ListCostCategoryDefinitionsError = LimitExceededException | CommonErrors;
/**
 * Returns the name, Amazon Resource Name (ARN), `NumberOfRules` and effective
 * dates of all cost categories defined in the account. You have the option to use
 * `EffectiveOn` and `SupportedResourceTypes` to return a list of cost categories that were active on a specific
 * date. If there is no `EffectiveOn` specified, you’ll see cost categories that are
 * effective on the current date. If cost category is still effective, `EffectiveEnd`
 * is omitted in the response. `ListCostCategoryDefinitions` supports pagination. The
 * request can have a `MaxResults` range up to 100.
 */
export declare const listCostCategoryDefinitions: API.PaginatedOperationMethod<ListCostCategoryDefinitionsRequest, ListCostCategoryDefinitionsResponse, ListCostCategoryDefinitionsError, Credentials | HttpClient.HttpClient, CostCategoryReference>;
export type ListCostCategoryResourceAssociationsError = LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns resource associations of all cost categories defined in the account. You have the option to use `CostCategoryArn` to get the association for a specific cost category. `ListCostCategoryResourceAssociations` supports pagination. The request can have a `MaxResults` range up to 100.
 */
export declare const listCostCategoryResourceAssociations: API.PaginatedOperationMethod<ListCostCategoryResourceAssociationsRequest, ListCostCategoryResourceAssociationsResponse, ListCostCategoryResourceAssociationsError, Credentials | HttpClient.HttpClient, CostCategoryResourceAssociation>;
export type ListSavingsPlansPurchaseRecommendationGenerationError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves a list of your historical recommendation generations within the past 30
 * days.
 */
export declare const listSavingsPlansPurchaseRecommendationGeneration: API.PaginatedOperationMethod<ListSavingsPlansPurchaseRecommendationGenerationRequest, ListSavingsPlansPurchaseRecommendationGenerationResponse, ListSavingsPlansPurchaseRecommendationGenerationError, Credentials | HttpClient.HttpClient, GenerationSummary>;
export type ListTagsForResourceError = LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of resource tags associated with the resource specified by the Amazon
 * Resource Name (ARN).
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ProvideAnomalyFeedbackError = LimitExceededException | CommonErrors;
/**
 * Modifies the feedback property of a given cost anomaly.
 */
export declare const provideAnomalyFeedback: API.OperationMethod<ProvideAnomalyFeedbackRequest, ProvideAnomalyFeedbackResponse, ProvideAnomalyFeedbackError, Credentials | HttpClient.HttpClient>;
export type StartCommitmentPurchaseAnalysisError = DataUnavailableException | GenerationExistsException | LimitExceededException | ServiceQuotaExceededException | CommonErrors;
/**
 * Specifies the parameters of a planned commitment purchase and starts the generation of the
 * analysis. This enables you to estimate the cost, coverage, and utilization impact of your
 * planned commitment purchases.
 */
export declare const startCommitmentPurchaseAnalysis: API.OperationMethod<StartCommitmentPurchaseAnalysisRequest, StartCommitmentPurchaseAnalysisResponse, StartCommitmentPurchaseAnalysisError, Credentials | HttpClient.HttpClient>;
export type StartCostAllocationTagBackfillError = BackfillLimitExceededException | LimitExceededException | CommonErrors;
/**
 * Request a cost allocation tag backfill. This will backfill the activation status (either `active` or `inactive`) for all tag keys from `para:BackfillFrom` up to the time this request is made.
 *
 * You can request a backfill once every 24 hours.
 */
export declare const startCostAllocationTagBackfill: API.OperationMethod<StartCostAllocationTagBackfillRequest, StartCostAllocationTagBackfillResponse, StartCostAllocationTagBackfillError, Credentials | HttpClient.HttpClient>;
export type StartSavingsPlansPurchaseRecommendationGenerationError = DataUnavailableException | GenerationExistsException | LimitExceededException | ServiceQuotaExceededException | CommonErrors;
/**
 * Requests a Savings Plans recommendation generation. This enables you to calculate a fresh
 * set of Savings Plans recommendations that takes your latest usage data and current Savings
 * Plans inventory into account. You can refresh Savings Plans recommendations up to three times
 * daily for a consolidated billing family.
 *
 * `StartSavingsPlansPurchaseRecommendationGeneration` has no request syntax
 * because no input parameters are needed to support this operation.
 */
export declare const startSavingsPlansPurchaseRecommendationGeneration: API.OperationMethod<StartSavingsPlansPurchaseRecommendationGenerationRequest, StartSavingsPlansPurchaseRecommendationGenerationResponse, StartSavingsPlansPurchaseRecommendationGenerationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = LimitExceededException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * An API operation for adding one or more tags (key-value pairs) to a resource.
 *
 * You can use the `TagResource` operation with a resource that already has tags.
 * If you specify a new tag key for the resource, this tag is appended to the list of tags
 * associated with the resource. If you specify a tag key that is already associated with the
 * resource, the new tag value you specify replaces the previous value for that tag.
 *
 * Although the maximum number of array members is 200, user-tag maximum is 50. The remaining
 * are reserved for Amazon Web Services use.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from a resource. Specify only tag keys in your request. Don't
 * specify the value.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAnomalyMonitorError = LimitExceededException | UnknownMonitorException | CommonErrors;
/**
 * Updates an existing cost anomaly monitor. The changes made are applied going forward, and
 * doesn't change anomalies detected in the past.
 */
export declare const updateAnomalyMonitor: API.OperationMethod<UpdateAnomalyMonitorRequest, UpdateAnomalyMonitorResponse, UpdateAnomalyMonitorError, Credentials | HttpClient.HttpClient>;
export type UpdateAnomalySubscriptionError = LimitExceededException | UnknownMonitorException | UnknownSubscriptionException | CommonErrors;
/**
 * Updates an existing cost anomaly subscription. Specify the fields that you want to update.
 * Omitted fields are unchanged.
 *
 * The JSON below describes the generic construct for each type. See Request Parameters for possible values as they apply to
 * `AnomalySubscription`.
 */
export declare const updateAnomalySubscription: API.OperationMethod<UpdateAnomalySubscriptionRequest, UpdateAnomalySubscriptionResponse, UpdateAnomalySubscriptionError, Credentials | HttpClient.HttpClient>;
export type UpdateCostAllocationTagsStatusError = LimitExceededException | CommonErrors;
/**
 * Updates status for cost allocation tags in bulk, with maximum batch size of 20. If the tag
 * status that's updated is the same as the existing tag status, the request doesn't fail.
 * Instead, it doesn't have any effect on the tag status (for example, activating the active
 * tag).
 */
export declare const updateCostAllocationTagsStatus: API.OperationMethod<UpdateCostAllocationTagsStatusRequest, UpdateCostAllocationTagsStatusResponse, UpdateCostAllocationTagsStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateCostCategoryDefinitionError = LimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Updates an existing cost category. Changes made to the cost category rules will be used to
 * categorize the current month’s expenses and future expenses. This won’t change categorization
 * for the previous months.
 */
export declare const updateCostCategoryDefinition: API.OperationMethod<UpdateCostCategoryDefinitionRequest, UpdateCostCategoryDefinitionResponse, UpdateCostCategoryDefinitionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cost-explorer.d.ts.map