import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ConnectorAuthenticationException_base: S.Class<ConnectorAuthenticationException, S.TaggedStruct<"ConnectorAuthenticationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ConnectorAuthenticationException extends /*@__PURE__*/ ConnectorAuthenticationException_base {
}
declare const ConnectorServerException_base: S.Class<ConnectorServerException, S.TaggedStruct<"ConnectorServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConnectorServerException extends /*@__PURE__*/ ConnectorServerException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnsupportedOperationException_base: S.Class<UnsupportedOperationException, S.TaggedStruct<"UnsupportedOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type FlowName = string;
export type ExecutionId = string;
export type ExecutionIds = string[];
export declare const ExecutionIds: any;
export interface CancelFlowExecutionsRequest {
    flowName: string;
    executionIds?: string[];
}
export declare const CancelFlowExecutionsRequest: S.Schema<CancelFlowExecutionsRequest>;
export interface CancelFlowExecutionsResponse {
    invalidExecutions?: string[];
}
export declare const CancelFlowExecutionsResponse: S.Schema<CancelFlowExecutionsResponse>;
export type ConnectorProfileName = string;
export type KMSArn = string;
export type ConnectorType = "Salesforce" | "Singular" | "Slack" | "Redshift" | "S3" | "Marketo" | "Googleanalytics" | "Zendesk" | "Servicenow" | "Datadog" | "Trendmicro" | "Snowflake" | "Dynatrace" | "Infornexus" | "Amplitude" | "Veeva" | "EventBridge" | "LookoutMetrics" | "Upsolver" | "Honeycode" | "CustomerProfiles" | "SAPOData" | "CustomConnector" | "Pardot" | (string & {});
export declare const ConnectorType: any;
export type ConnectorLabel = string;
export type ConnectionMode = "Public" | "Private" | (string & {});
export declare const ConnectionMode: any;
export interface AmplitudeConnectorProfileProperties {
}
export declare const AmplitudeConnectorProfileProperties: S.Schema<AmplitudeConnectorProfileProperties>;
export type InstanceUrl = string;
export interface DatadogConnectorProfileProperties {
    instanceUrl: string;
}
export declare const DatadogConnectorProfileProperties: S.Schema<DatadogConnectorProfileProperties>;
export interface DynatraceConnectorProfileProperties {
    instanceUrl: string;
}
export declare const DynatraceConnectorProfileProperties: S.Schema<DynatraceConnectorProfileProperties>;
export interface GoogleAnalyticsConnectorProfileProperties {
}
export declare const GoogleAnalyticsConnectorProfileProperties: S.Schema<GoogleAnalyticsConnectorProfileProperties>;
export interface HoneycodeConnectorProfileProperties {
}
export declare const HoneycodeConnectorProfileProperties: S.Schema<HoneycodeConnectorProfileProperties>;
export interface InforNexusConnectorProfileProperties {
    instanceUrl: string;
}
export declare const InforNexusConnectorProfileProperties: S.Schema<InforNexusConnectorProfileProperties>;
export interface MarketoConnectorProfileProperties {
    instanceUrl: string;
}
export declare const MarketoConnectorProfileProperties: S.Schema<MarketoConnectorProfileProperties>;
export type DatabaseUrl = string;
export type BucketName = string;
export type BucketPrefix = string;
export type RoleArn = string;
export type DataApiRoleArn = string;
export type ClusterIdentifier = string;
export type WorkgroupName = string;
export type DatabaseName = string;
export interface RedshiftConnectorProfileProperties {
    databaseUrl?: string;
    bucketName: string;
    bucketPrefix?: string;
    roleArn: string;
    dataApiRoleArn?: string;
    isRedshiftServerless?: boolean;
    clusterIdentifier?: string;
    workgroupName?: string;
    databaseName?: string;
}
export declare const RedshiftConnectorProfileProperties: S.Schema<RedshiftConnectorProfileProperties>;
export interface SalesforceConnectorProfileProperties {
    instanceUrl?: string;
    isSandboxEnvironment?: boolean;
    usePrivateLinkForMetadataAndAuthorization?: boolean;
}
export declare const SalesforceConnectorProfileProperties: S.Schema<SalesforceConnectorProfileProperties>;
export interface ServiceNowConnectorProfileProperties {
    instanceUrl: string;
}
export declare const ServiceNowConnectorProfileProperties: S.Schema<ServiceNowConnectorProfileProperties>;
export interface SingularConnectorProfileProperties {
}
export declare const SingularConnectorProfileProperties: S.Schema<SingularConnectorProfileProperties>;
export interface SlackConnectorProfileProperties {
    instanceUrl: string;
}
export declare const SlackConnectorProfileProperties: S.Schema<SlackConnectorProfileProperties>;
export type Warehouse = string;
export type Stage = string;
export type PrivateLinkServiceName = string;
export type AccountName = string;
export type Region = string;
export interface SnowflakeConnectorProfileProperties {
    warehouse: string;
    stage: string;
    bucketName: string;
    bucketPrefix?: string;
    privateLinkServiceName?: string;
    accountName?: string;
    region?: string;
}
export declare const SnowflakeConnectorProfileProperties: S.Schema<SnowflakeConnectorProfileProperties>;
export interface TrendmicroConnectorProfileProperties {
}
export declare const TrendmicroConnectorProfileProperties: S.Schema<TrendmicroConnectorProfileProperties>;
export interface VeevaConnectorProfileProperties {
    instanceUrl: string;
}
export declare const VeevaConnectorProfileProperties: S.Schema<VeevaConnectorProfileProperties>;
export interface ZendeskConnectorProfileProperties {
    instanceUrl: string;
}
export declare const ZendeskConnectorProfileProperties: S.Schema<ZendeskConnectorProfileProperties>;
export type ApplicationHostUrl = string;
export type ApplicationServicePath = string;
export type PortNumber = number;
export type ClientNumber = string;
export type LogonLanguage = string;
export type TokenUrl = string;
export type AuthCodeUrl = string;
export type OAuthScope = string;
export type OAuthScopeList = string[];
export declare const OAuthScopeList: any;
export interface OAuthProperties {
    tokenUrl: string;
    authCodeUrl: string;
    oAuthScopes: string[];
}
export declare const OAuthProperties: S.Schema<OAuthProperties>;
export interface SAPODataConnectorProfileProperties {
    applicationHostUrl: string;
    applicationServicePath: string;
    portNumber: number;
    clientNumber: string;
    logonLanguage?: string;
    privateLinkServiceName?: string;
    oAuthProperties?: OAuthProperties;
    disableSSO?: boolean;
}
export declare const SAPODataConnectorProfileProperties: S.Schema<SAPODataConnectorProfileProperties>;
export type ProfilePropertyKey = string;
export type ProfilePropertyValue = string;
export type ProfilePropertiesMap = {
    [key: string]: string | undefined;
};
export declare const ProfilePropertiesMap: any;
export type OAuth2GrantType = "CLIENT_CREDENTIALS" | "AUTHORIZATION_CODE" | "JWT_BEARER" | (string & {});
export declare const OAuth2GrantType: any;
export type CustomPropertyKey = string;
export type CustomPropertyValue = string;
export type TokenUrlCustomProperties = {
    [key: string]: string | undefined;
};
export declare const TokenUrlCustomProperties: any;
export interface OAuth2Properties {
    tokenUrl: string;
    oAuth2GrantType: OAuth2GrantType;
    tokenUrlCustomProperties?: {
        [key: string]: string | undefined;
    };
}
export declare const OAuth2Properties: S.Schema<OAuth2Properties>;
export interface CustomConnectorProfileProperties {
    profileProperties?: {
        [key: string]: string | undefined;
    };
    oAuth2Properties?: OAuth2Properties;
}
export declare const CustomConnectorProfileProperties: S.Schema<CustomConnectorProfileProperties>;
export type BusinessUnitId = string;
export interface PardotConnectorProfileProperties {
    instanceUrl?: string;
    isSandboxEnvironment?: boolean;
    businessUnitId?: string;
}
export declare const PardotConnectorProfileProperties: S.Schema<PardotConnectorProfileProperties>;
export interface ConnectorProfileProperties {
    Amplitude?: AmplitudeConnectorProfileProperties;
    Datadog?: DatadogConnectorProfileProperties;
    Dynatrace?: DynatraceConnectorProfileProperties;
    GoogleAnalytics?: GoogleAnalyticsConnectorProfileProperties;
    Honeycode?: HoneycodeConnectorProfileProperties;
    InforNexus?: InforNexusConnectorProfileProperties;
    Marketo?: MarketoConnectorProfileProperties;
    Redshift?: RedshiftConnectorProfileProperties;
    Salesforce?: SalesforceConnectorProfileProperties;
    ServiceNow?: ServiceNowConnectorProfileProperties;
    Singular?: SingularConnectorProfileProperties;
    Slack?: SlackConnectorProfileProperties;
    Snowflake?: SnowflakeConnectorProfileProperties;
    Trendmicro?: TrendmicroConnectorProfileProperties;
    Veeva?: VeevaConnectorProfileProperties;
    Zendesk?: ZendeskConnectorProfileProperties;
    SAPOData?: SAPODataConnectorProfileProperties;
    CustomConnector?: CustomConnectorProfileProperties;
    Pardot?: PardotConnectorProfileProperties;
}
export declare const ConnectorProfileProperties: S.Schema<ConnectorProfileProperties>;
export type ApiKey = string | redacted.Redacted<string>;
export type SecretKey = string | redacted.Redacted<string>;
export interface AmplitudeConnectorProfileCredentials {
    apiKey: string | redacted.Redacted<string>;
    secretKey: string | redacted.Redacted<string>;
}
export declare const AmplitudeConnectorProfileCredentials: S.Schema<AmplitudeConnectorProfileCredentials>;
export type ApplicationKey = string;
export interface DatadogConnectorProfileCredentials {
    apiKey: string | redacted.Redacted<string>;
    applicationKey: string | redacted.Redacted<string>;
}
export declare const DatadogConnectorProfileCredentials: S.Schema<DatadogConnectorProfileCredentials>;
export type ApiToken = string;
export interface DynatraceConnectorProfileCredentials {
    apiToken: string | redacted.Redacted<string>;
}
export declare const DynatraceConnectorProfileCredentials: S.Schema<DynatraceConnectorProfileCredentials>;
export type ClientId = string;
export type ClientSecret = string | redacted.Redacted<string>;
export type AccessToken = string | redacted.Redacted<string>;
export type RefreshToken = string;
export type AuthCode = string;
export type RedirectUri = string;
export interface ConnectorOAuthRequest {
    authCode?: string;
    redirectUri?: string;
}
export declare const ConnectorOAuthRequest: S.Schema<ConnectorOAuthRequest>;
export interface GoogleAnalyticsConnectorProfileCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    refreshToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export declare const GoogleAnalyticsConnectorProfileCredentials: S.Schema<GoogleAnalyticsConnectorProfileCredentials>;
export interface HoneycodeConnectorProfileCredentials {
    accessToken?: string | redacted.Redacted<string>;
    refreshToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export declare const HoneycodeConnectorProfileCredentials: S.Schema<HoneycodeConnectorProfileCredentials>;
export type AccessKeyId = string | redacted.Redacted<string>;
export type Username = string;
export type Key = string;
export interface InforNexusConnectorProfileCredentials {
    accessKeyId: string | redacted.Redacted<string>;
    userId: string;
    secretAccessKey: string | redacted.Redacted<string>;
    datakey: string | redacted.Redacted<string>;
}
export declare const InforNexusConnectorProfileCredentials: S.Schema<InforNexusConnectorProfileCredentials>;
export interface MarketoConnectorProfileCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export declare const MarketoConnectorProfileCredentials: S.Schema<MarketoConnectorProfileCredentials>;
export type Password = string | redacted.Redacted<string>;
export interface RedshiftConnectorProfileCredentials {
    username?: string;
    password?: string | redacted.Redacted<string>;
}
export declare const RedshiftConnectorProfileCredentials: S.Schema<RedshiftConnectorProfileCredentials>;
export type ClientCredentialsArn = string | redacted.Redacted<string>;
export type JwtToken = string | redacted.Redacted<string>;
export interface SalesforceConnectorProfileCredentials {
    accessToken?: string | redacted.Redacted<string>;
    refreshToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
    clientCredentialsArn?: string | redacted.Redacted<string>;
    oAuth2GrantType?: OAuth2GrantType;
    jwtToken?: string | redacted.Redacted<string>;
}
export declare const SalesforceConnectorProfileCredentials: S.Schema<SalesforceConnectorProfileCredentials>;
export interface OAuth2Credentials {
    clientId?: string;
    clientSecret?: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    refreshToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export declare const OAuth2Credentials: S.Schema<OAuth2Credentials>;
export interface ServiceNowConnectorProfileCredentials {
    username?: string;
    password?: string | redacted.Redacted<string>;
    oAuth2Credentials?: OAuth2Credentials;
}
export declare const ServiceNowConnectorProfileCredentials: S.Schema<ServiceNowConnectorProfileCredentials>;
export interface SingularConnectorProfileCredentials {
    apiKey: string | redacted.Redacted<string>;
}
export declare const SingularConnectorProfileCredentials: S.Schema<SingularConnectorProfileCredentials>;
export interface SlackConnectorProfileCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export declare const SlackConnectorProfileCredentials: S.Schema<SlackConnectorProfileCredentials>;
export interface SnowflakeConnectorProfileCredentials {
    username: string;
    password: string | redacted.Redacted<string>;
}
export declare const SnowflakeConnectorProfileCredentials: S.Schema<SnowflakeConnectorProfileCredentials>;
export type ApiSecretKey = string | redacted.Redacted<string>;
export interface TrendmicroConnectorProfileCredentials {
    apiSecretKey: string | redacted.Redacted<string>;
}
export declare const TrendmicroConnectorProfileCredentials: S.Schema<TrendmicroConnectorProfileCredentials>;
export interface VeevaConnectorProfileCredentials {
    username: string;
    password: string | redacted.Redacted<string>;
}
export declare const VeevaConnectorProfileCredentials: S.Schema<VeevaConnectorProfileCredentials>;
export interface ZendeskConnectorProfileCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export declare const ZendeskConnectorProfileCredentials: S.Schema<ZendeskConnectorProfileCredentials>;
export interface BasicAuthCredentials {
    username: string;
    password: string | redacted.Redacted<string>;
}
export declare const BasicAuthCredentials: S.Schema<BasicAuthCredentials>;
export interface OAuthCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    refreshToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export declare const OAuthCredentials: S.Schema<OAuthCredentials>;
export interface SAPODataConnectorProfileCredentials {
    basicAuthCredentials?: BasicAuthCredentials;
    oAuthCredentials?: OAuthCredentials;
}
export declare const SAPODataConnectorProfileCredentials: S.Schema<SAPODataConnectorProfileCredentials>;
export type AuthenticationType = "OAUTH2" | "APIKEY" | "BASIC" | "CUSTOM" | (string & {});
export declare const AuthenticationType: any;
export interface ApiKeyCredentials {
    apiKey: string | redacted.Redacted<string>;
    apiSecretKey?: string | redacted.Redacted<string>;
}
export declare const ApiKeyCredentials: S.Schema<ApiKeyCredentials>;
export type CustomAuthenticationType = string;
export type CredentialsMapKey = string | redacted.Redacted<string>;
export type CredentialsMapValue = string | redacted.Redacted<string>;
export type CredentialsMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const CredentialsMap: any;
export interface CustomAuthCredentials {
    customAuthenticationType: string;
    credentialsMap?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export declare const CustomAuthCredentials: S.Schema<CustomAuthCredentials>;
export interface CustomConnectorProfileCredentials {
    authenticationType: AuthenticationType;
    basic?: BasicAuthCredentials;
    oauth2?: OAuth2Credentials;
    apiKey?: ApiKeyCredentials;
    custom?: CustomAuthCredentials;
}
export declare const CustomConnectorProfileCredentials: S.Schema<CustomConnectorProfileCredentials>;
export interface PardotConnectorProfileCredentials {
    accessToken?: string | redacted.Redacted<string>;
    refreshToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
    clientCredentialsArn?: string | redacted.Redacted<string>;
}
export declare const PardotConnectorProfileCredentials: S.Schema<PardotConnectorProfileCredentials>;
export interface ConnectorProfileCredentials {
    Amplitude?: AmplitudeConnectorProfileCredentials;
    Datadog?: DatadogConnectorProfileCredentials;
    Dynatrace?: DynatraceConnectorProfileCredentials;
    GoogleAnalytics?: GoogleAnalyticsConnectorProfileCredentials;
    Honeycode?: HoneycodeConnectorProfileCredentials;
    InforNexus?: InforNexusConnectorProfileCredentials;
    Marketo?: MarketoConnectorProfileCredentials;
    Redshift?: RedshiftConnectorProfileCredentials;
    Salesforce?: SalesforceConnectorProfileCredentials;
    ServiceNow?: ServiceNowConnectorProfileCredentials;
    Singular?: SingularConnectorProfileCredentials;
    Slack?: SlackConnectorProfileCredentials;
    Snowflake?: SnowflakeConnectorProfileCredentials;
    Trendmicro?: TrendmicroConnectorProfileCredentials;
    Veeva?: VeevaConnectorProfileCredentials;
    Zendesk?: ZendeskConnectorProfileCredentials;
    SAPOData?: SAPODataConnectorProfileCredentials;
    CustomConnector?: CustomConnectorProfileCredentials;
    Pardot?: PardotConnectorProfileCredentials;
}
export declare const ConnectorProfileCredentials: S.Schema<ConnectorProfileCredentials>;
export interface ConnectorProfileConfig {
    connectorProfileProperties: ConnectorProfileProperties;
    connectorProfileCredentials?: ConnectorProfileCredentials;
}
export declare const ConnectorProfileConfig: S.Schema<ConnectorProfileConfig>;
export type ClientToken = string;
export interface CreateConnectorProfileRequest {
    connectorProfileName: string;
    kmsArn?: string;
    connectorType: ConnectorType;
    connectorLabel?: string;
    connectionMode: ConnectionMode;
    connectorProfileConfig: ConnectorProfileConfig;
    clientToken?: string;
}
export declare const CreateConnectorProfileRequest: S.Schema<CreateConnectorProfileRequest>;
export type ConnectorProfileArn = string;
export interface CreateConnectorProfileResponse {
    connectorProfileArn?: string;
}
export declare const CreateConnectorProfileResponse: S.Schema<CreateConnectorProfileResponse>;
export type FlowDescription = string;
export type TriggerType = "Scheduled" | "Event" | "OnDemand" | (string & {});
export declare const TriggerType: any;
export type ScheduleExpression = string;
export type DataPullMode = "Incremental" | "Complete" | (string & {});
export declare const DataPullMode: any;
export type Timezone = string;
export type ScheduleOffset = number;
export type FlowErrorDeactivationThreshold = number;
export interface ScheduledTriggerProperties {
    scheduleExpression: string;
    dataPullMode?: DataPullMode;
    scheduleStartTime?: Date;
    scheduleEndTime?: Date;
    timezone?: string;
    scheduleOffset?: number;
    firstExecutionFrom?: Date;
    flowErrorDeactivationThreshold?: number;
}
export declare const ScheduledTriggerProperties: S.Schema<ScheduledTriggerProperties>;
export interface TriggerProperties {
    Scheduled?: ScheduledTriggerProperties;
}
export declare const TriggerProperties: S.Schema<TriggerProperties>;
export interface TriggerConfig {
    triggerType: TriggerType;
    triggerProperties?: TriggerProperties;
}
export declare const TriggerConfig: S.Schema<TriggerConfig>;
export type ApiVersion = string;
export interface AmplitudeSourceProperties {
    object: string;
}
export declare const AmplitudeSourceProperties: S.Schema<AmplitudeSourceProperties>;
export interface DatadogSourceProperties {
    object: string;
}
export declare const DatadogSourceProperties: S.Schema<DatadogSourceProperties>;
export interface DynatraceSourceProperties {
    object: string;
}
export declare const DynatraceSourceProperties: S.Schema<DynatraceSourceProperties>;
export interface GoogleAnalyticsSourceProperties {
    object: string;
}
export declare const GoogleAnalyticsSourceProperties: S.Schema<GoogleAnalyticsSourceProperties>;
export interface InforNexusSourceProperties {
    object: string;
}
export declare const InforNexusSourceProperties: S.Schema<InforNexusSourceProperties>;
export interface MarketoSourceProperties {
    object: string;
}
export declare const MarketoSourceProperties: S.Schema<MarketoSourceProperties>;
export type S3InputFileType = "CSV" | "JSON" | (string & {});
export declare const S3InputFileType: any;
export interface S3InputFormatConfig {
    s3InputFileType?: S3InputFileType;
}
export declare const S3InputFormatConfig: S.Schema<S3InputFormatConfig>;
export interface S3SourceProperties {
    bucketName: string;
    bucketPrefix?: string;
    s3InputFormatConfig?: S3InputFormatConfig;
}
export declare const S3SourceProperties: S.Schema<S3SourceProperties>;
export type SalesforceDataTransferApi = "AUTOMATIC" | "BULKV2" | "REST_SYNC" | (string & {});
export declare const SalesforceDataTransferApi: any;
export interface SalesforceSourceProperties {
    object: string;
    enableDynamicFieldUpdate?: boolean;
    includeDeletedRecords?: boolean;
    dataTransferApi?: SalesforceDataTransferApi;
}
export declare const SalesforceSourceProperties: S.Schema<SalesforceSourceProperties>;
export interface ServiceNowSourceProperties {
    object: string;
}
export declare const ServiceNowSourceProperties: S.Schema<ServiceNowSourceProperties>;
export interface SingularSourceProperties {
    object: string;
}
export declare const SingularSourceProperties: S.Schema<SingularSourceProperties>;
export interface SlackSourceProperties {
    object: string;
}
export declare const SlackSourceProperties: S.Schema<SlackSourceProperties>;
export interface TrendmicroSourceProperties {
    object: string;
}
export declare const TrendmicroSourceProperties: S.Schema<TrendmicroSourceProperties>;
export type DocumentType = string;
export interface VeevaSourceProperties {
    object: string;
    documentType?: string;
    includeSourceFiles?: boolean;
    includeRenditions?: boolean;
    includeAllVersions?: boolean;
}
export declare const VeevaSourceProperties: S.Schema<VeevaSourceProperties>;
export interface ZendeskSourceProperties {
    object: string;
}
export declare const ZendeskSourceProperties: S.Schema<ZendeskSourceProperties>;
export type SAPODataMaxParallelism = number;
export interface SAPODataParallelismConfig {
    maxParallelism: number;
}
export declare const SAPODataParallelismConfig: S.Schema<SAPODataParallelismConfig>;
export type SAPODataMaxPageSize = number;
export interface SAPODataPaginationConfig {
    maxPageSize: number;
}
export declare const SAPODataPaginationConfig: S.Schema<SAPODataPaginationConfig>;
export interface SAPODataSourceProperties {
    objectPath?: string;
    parallelismConfig?: SAPODataParallelismConfig;
    paginationConfig?: SAPODataPaginationConfig;
}
export declare const SAPODataSourceProperties: S.Schema<SAPODataSourceProperties>;
export type EntityName = string;
export type CustomProperties = {
    [key: string]: string | undefined;
};
export declare const CustomProperties: any;
export type DataTransferApiTypeName = string;
export type DataTransferApiType = "SYNC" | "ASYNC" | "AUTOMATIC" | (string & {});
export declare const DataTransferApiType: any;
export interface DataTransferApi {
    Name?: string;
    Type?: DataTransferApiType;
}
export declare const DataTransferApi: S.Schema<DataTransferApi>;
export interface CustomConnectorSourceProperties {
    entityName: string;
    customProperties?: {
        [key: string]: string | undefined;
    };
    dataTransferApi?: DataTransferApi;
}
export declare const CustomConnectorSourceProperties: S.Schema<CustomConnectorSourceProperties>;
export interface PardotSourceProperties {
    object: string;
}
export declare const PardotSourceProperties: S.Schema<PardotSourceProperties>;
export interface SourceConnectorProperties {
    Amplitude?: AmplitudeSourceProperties;
    Datadog?: DatadogSourceProperties;
    Dynatrace?: DynatraceSourceProperties;
    GoogleAnalytics?: GoogleAnalyticsSourceProperties;
    InforNexus?: InforNexusSourceProperties;
    Marketo?: MarketoSourceProperties;
    S3?: S3SourceProperties;
    Salesforce?: SalesforceSourceProperties;
    ServiceNow?: ServiceNowSourceProperties;
    Singular?: SingularSourceProperties;
    Slack?: SlackSourceProperties;
    Trendmicro?: TrendmicroSourceProperties;
    Veeva?: VeevaSourceProperties;
    Zendesk?: ZendeskSourceProperties;
    SAPOData?: SAPODataSourceProperties;
    CustomConnector?: CustomConnectorSourceProperties;
    Pardot?: PardotSourceProperties;
}
export declare const SourceConnectorProperties: S.Schema<SourceConnectorProperties>;
export type DatetimeTypeFieldName = string;
export interface IncrementalPullConfig {
    datetimeTypeFieldName?: string;
}
export declare const IncrementalPullConfig: S.Schema<IncrementalPullConfig>;
export interface SourceFlowConfig {
    connectorType: ConnectorType;
    apiVersion?: string;
    connectorProfileName?: string;
    sourceConnectorProperties: SourceConnectorProperties;
    incrementalPullConfig?: IncrementalPullConfig;
}
export declare const SourceFlowConfig: S.Schema<SourceFlowConfig>;
export interface ErrorHandlingConfig {
    failOnFirstDestinationError?: boolean;
    bucketPrefix?: string;
    bucketName?: string;
}
export declare const ErrorHandlingConfig: S.Schema<ErrorHandlingConfig>;
export interface RedshiftDestinationProperties {
    object: string;
    intermediateBucketName: string;
    bucketPrefix?: string;
    errorHandlingConfig?: ErrorHandlingConfig;
}
export declare const RedshiftDestinationProperties: S.Schema<RedshiftDestinationProperties>;
export type FileType = "CSV" | "JSON" | "PARQUET" | (string & {});
export declare const FileType: any;
export type PrefixType = "FILENAME" | "PATH" | "PATH_AND_FILENAME" | (string & {});
export declare const PrefixType: any;
export type PrefixFormat = "YEAR" | "MONTH" | "DAY" | "HOUR" | "MINUTE" | (string & {});
export declare const PrefixFormat: any;
export type PathPrefix = "EXECUTION_ID" | "SCHEMA_VERSION" | (string & {});
export declare const PathPrefix: any;
export type PathPrefixHierarchy = PathPrefix[];
export declare const PathPrefixHierarchy: any;
export interface PrefixConfig {
    prefixType?: PrefixType;
    prefixFormat?: PrefixFormat;
    pathPrefixHierarchy?: PathPrefix[];
}
export declare const PrefixConfig: S.Schema<PrefixConfig>;
export type AggregationType = "None" | "SingleFile" | (string & {});
export declare const AggregationType: any;
export interface AggregationConfig {
    aggregationType?: AggregationType;
    targetFileSize?: number;
}
export declare const AggregationConfig: S.Schema<AggregationConfig>;
export type JavaBoolean = boolean;
export interface S3OutputFormatConfig {
    fileType?: FileType;
    prefixConfig?: PrefixConfig;
    aggregationConfig?: AggregationConfig;
    preserveSourceDataTyping?: boolean;
}
export declare const S3OutputFormatConfig: S.Schema<S3OutputFormatConfig>;
export interface S3DestinationProperties {
    bucketName: string;
    bucketPrefix?: string;
    s3OutputFormatConfig?: S3OutputFormatConfig;
}
export declare const S3DestinationProperties: S.Schema<S3DestinationProperties>;
export type Name = string;
export type IdFieldNameList = string[];
export declare const IdFieldNameList: any;
export type WriteOperationType = "INSERT" | "UPSERT" | "UPDATE" | "DELETE" | (string & {});
export declare const WriteOperationType: any;
export interface SalesforceDestinationProperties {
    object: string;
    idFieldNames?: string[];
    errorHandlingConfig?: ErrorHandlingConfig;
    writeOperationType?: WriteOperationType;
    dataTransferApi?: SalesforceDataTransferApi;
}
export declare const SalesforceDestinationProperties: S.Schema<SalesforceDestinationProperties>;
export interface SnowflakeDestinationProperties {
    object: string;
    intermediateBucketName: string;
    bucketPrefix?: string;
    errorHandlingConfig?: ErrorHandlingConfig;
}
export declare const SnowflakeDestinationProperties: S.Schema<SnowflakeDestinationProperties>;
export interface EventBridgeDestinationProperties {
    object: string;
    errorHandlingConfig?: ErrorHandlingConfig;
}
export declare const EventBridgeDestinationProperties: S.Schema<EventBridgeDestinationProperties>;
export interface LookoutMetricsDestinationProperties {
}
export declare const LookoutMetricsDestinationProperties: S.Schema<LookoutMetricsDestinationProperties>;
export type UpsolverBucketName = string;
export interface UpsolverS3OutputFormatConfig {
    fileType?: FileType;
    prefixConfig: PrefixConfig;
    aggregationConfig?: AggregationConfig;
}
export declare const UpsolverS3OutputFormatConfig: S.Schema<UpsolverS3OutputFormatConfig>;
export interface UpsolverDestinationProperties {
    bucketName: string;
    bucketPrefix?: string;
    s3OutputFormatConfig: UpsolverS3OutputFormatConfig;
}
export declare const UpsolverDestinationProperties: S.Schema<UpsolverDestinationProperties>;
export interface HoneycodeDestinationProperties {
    object: string;
    errorHandlingConfig?: ErrorHandlingConfig;
}
export declare const HoneycodeDestinationProperties: S.Schema<HoneycodeDestinationProperties>;
export type DomainName = string;
export type ObjectTypeName = string;
export interface CustomerProfilesDestinationProperties {
    domainName: string;
    objectTypeName?: string;
}
export declare const CustomerProfilesDestinationProperties: S.Schema<CustomerProfilesDestinationProperties>;
export interface ZendeskDestinationProperties {
    object: string;
    idFieldNames?: string[];
    errorHandlingConfig?: ErrorHandlingConfig;
    writeOperationType?: WriteOperationType;
}
export declare const ZendeskDestinationProperties: S.Schema<ZendeskDestinationProperties>;
export interface MarketoDestinationProperties {
    object: string;
    errorHandlingConfig?: ErrorHandlingConfig;
}
export declare const MarketoDestinationProperties: S.Schema<MarketoDestinationProperties>;
export interface CustomConnectorDestinationProperties {
    entityName: string;
    errorHandlingConfig?: ErrorHandlingConfig;
    writeOperationType?: WriteOperationType;
    idFieldNames?: string[];
    customProperties?: {
        [key: string]: string | undefined;
    };
}
export declare const CustomConnectorDestinationProperties: S.Schema<CustomConnectorDestinationProperties>;
export interface SuccessResponseHandlingConfig {
    bucketPrefix?: string;
    bucketName?: string;
}
export declare const SuccessResponseHandlingConfig: S.Schema<SuccessResponseHandlingConfig>;
export interface SAPODataDestinationProperties {
    objectPath: string;
    successResponseHandlingConfig?: SuccessResponseHandlingConfig;
    idFieldNames?: string[];
    errorHandlingConfig?: ErrorHandlingConfig;
    writeOperationType?: WriteOperationType;
}
export declare const SAPODataDestinationProperties: S.Schema<SAPODataDestinationProperties>;
export interface DestinationConnectorProperties {
    Redshift?: RedshiftDestinationProperties;
    S3?: S3DestinationProperties;
    Salesforce?: SalesforceDestinationProperties;
    Snowflake?: SnowflakeDestinationProperties;
    EventBridge?: EventBridgeDestinationProperties;
    LookoutMetrics?: LookoutMetricsDestinationProperties;
    Upsolver?: UpsolverDestinationProperties;
    Honeycode?: HoneycodeDestinationProperties;
    CustomerProfiles?: CustomerProfilesDestinationProperties;
    Zendesk?: ZendeskDestinationProperties;
    Marketo?: MarketoDestinationProperties;
    CustomConnector?: CustomConnectorDestinationProperties;
    SAPOData?: SAPODataDestinationProperties;
}
export declare const DestinationConnectorProperties: S.Schema<DestinationConnectorProperties>;
export interface DestinationFlowConfig {
    connectorType: ConnectorType;
    apiVersion?: string;
    connectorProfileName?: string;
    destinationConnectorProperties: DestinationConnectorProperties;
}
export declare const DestinationFlowConfig: S.Schema<DestinationFlowConfig>;
export type DestinationFlowConfigList = DestinationFlowConfig[];
export declare const DestinationFlowConfigList: any;
export type SourceFields = string[];
export declare const SourceFields: any;
export type AmplitudeConnectorOperator = "BETWEEN" | (string & {});
export declare const AmplitudeConnectorOperator: any;
export type DatadogConnectorOperator = "PROJECTION" | "BETWEEN" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const DatadogConnectorOperator: any;
export type DynatraceConnectorOperator = "PROJECTION" | "BETWEEN" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const DynatraceConnectorOperator: any;
export type GoogleAnalyticsConnectorOperator = "PROJECTION" | "BETWEEN" | (string & {});
export declare const GoogleAnalyticsConnectorOperator: any;
export type InforNexusConnectorOperator = "PROJECTION" | "BETWEEN" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const InforNexusConnectorOperator: any;
export type MarketoConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const MarketoConnectorOperator: any;
export type S3ConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const S3ConnectorOperator: any;
export type SalesforceConnectorOperator = "PROJECTION" | "LESS_THAN" | "CONTAINS" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const SalesforceConnectorOperator: any;
export type ServiceNowConnectorOperator = "PROJECTION" | "CONTAINS" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const ServiceNowConnectorOperator: any;
export type SingularConnectorOperator = "PROJECTION" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const SingularConnectorOperator: any;
export type SlackConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const SlackConnectorOperator: any;
export type TrendmicroConnectorOperator = "PROJECTION" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const TrendmicroConnectorOperator: any;
export type VeevaConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "CONTAINS" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const VeevaConnectorOperator: any;
export type ZendeskConnectorOperator = "PROJECTION" | "GREATER_THAN" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const ZendeskConnectorOperator: any;
export type SAPODataConnectorOperator = "PROJECTION" | "LESS_THAN" | "CONTAINS" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const SAPODataConnectorOperator: any;
export type Operator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "CONTAINS" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const Operator: any;
export type PardotConnectorOperator = "PROJECTION" | "EQUAL_TO" | "NO_OP" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | (string & {});
export declare const PardotConnectorOperator: any;
export interface ConnectorOperator {
    Amplitude?: AmplitudeConnectorOperator;
    Datadog?: DatadogConnectorOperator;
    Dynatrace?: DynatraceConnectorOperator;
    GoogleAnalytics?: GoogleAnalyticsConnectorOperator;
    InforNexus?: InforNexusConnectorOperator;
    Marketo?: MarketoConnectorOperator;
    S3?: S3ConnectorOperator;
    Salesforce?: SalesforceConnectorOperator;
    ServiceNow?: ServiceNowConnectorOperator;
    Singular?: SingularConnectorOperator;
    Slack?: SlackConnectorOperator;
    Trendmicro?: TrendmicroConnectorOperator;
    Veeva?: VeevaConnectorOperator;
    Zendesk?: ZendeskConnectorOperator;
    SAPOData?: SAPODataConnectorOperator;
    CustomConnector?: Operator;
    Pardot?: PardotConnectorOperator;
}
export declare const ConnectorOperator: S.Schema<ConnectorOperator>;
export type DestinationField = string;
export type TaskType = "Arithmetic" | "Filter" | "Map" | "Map_all" | "Mask" | "Merge" | "Passthrough" | "Truncate" | "Validate" | "Partition" | (string & {});
export declare const TaskType: any;
export type OperatorPropertiesKeys = "VALUE" | "VALUES" | "DATA_TYPE" | "UPPER_BOUND" | "LOWER_BOUND" | "SOURCE_DATA_TYPE" | "DESTINATION_DATA_TYPE" | "VALIDATION_ACTION" | "MASK_VALUE" | "MASK_LENGTH" | "TRUNCATE_LENGTH" | "MATH_OPERATION_FIELDS_ORDER" | "CONCAT_FORMAT" | "SUBFIELD_CATEGORY_MAP" | "EXCLUDE_SOURCE_FIELDS_LIST" | "INCLUDE_NEW_FIELDS" | "ORDERED_PARTITION_KEYS_LIST" | (string & {});
export declare const OperatorPropertiesKeys: any;
export type Property = string;
export type TaskPropertiesMap = {
    [key in OperatorPropertiesKeys]?: string;
};
export declare const TaskPropertiesMap: any;
export interface Task {
    sourceFields: string[];
    connectorOperator?: ConnectorOperator;
    destinationField?: string;
    taskType: TaskType;
    taskProperties?: {
        [key: string]: string | undefined;
    };
}
export declare const Task: S.Schema<Task>;
export type Tasks = Task[];
export declare const Tasks: any;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type GlueDataCatalogIAMRole = string;
export type GlueDataCatalogDatabaseName = string;
export type GlueDataCatalogTablePrefix = string;
export interface GlueDataCatalogConfig {
    roleArn: string;
    databaseName: string;
    tablePrefix: string;
}
export declare const GlueDataCatalogConfig: S.Schema<GlueDataCatalogConfig>;
export interface MetadataCatalogConfig {
    glueDataCatalog?: GlueDataCatalogConfig;
}
export declare const MetadataCatalogConfig: S.Schema<MetadataCatalogConfig>;
export interface CreateFlowRequest {
    flowName: string;
    description?: string;
    kmsArn?: string;
    triggerConfig: TriggerConfig;
    sourceFlowConfig: SourceFlowConfig;
    destinationFlowConfigList: DestinationFlowConfig[];
    tasks: Task[];
    tags?: {
        [key: string]: string | undefined;
    };
    metadataCatalogConfig?: MetadataCatalogConfig;
    clientToken?: string;
}
export declare const CreateFlowRequest: S.Schema<CreateFlowRequest>;
export type FlowArn = string;
export type FlowStatus = "Active" | "Deprecated" | "Deleted" | "Draft" | "Errored" | "Suspended" | (string & {});
export declare const FlowStatus: any;
export interface CreateFlowResponse {
    flowArn?: string;
    flowStatus?: FlowStatus;
}
export declare const CreateFlowResponse: S.Schema<CreateFlowResponse>;
export interface DeleteConnectorProfileRequest {
    connectorProfileName: string;
    forceDelete?: boolean;
}
export declare const DeleteConnectorProfileRequest: S.Schema<DeleteConnectorProfileRequest>;
export interface DeleteConnectorProfileResponse {
}
export declare const DeleteConnectorProfileResponse: S.Schema<DeleteConnectorProfileResponse>;
export interface DeleteFlowRequest {
    flowName: string;
    forceDelete?: boolean;
}
export declare const DeleteFlowRequest: S.Schema<DeleteFlowRequest>;
export interface DeleteFlowResponse {
}
export declare const DeleteFlowResponse: S.Schema<DeleteFlowResponse>;
export interface DescribeConnectorRequest {
    connectorType: ConnectorType;
    connectorLabel?: string;
}
export declare const DescribeConnectorRequest: S.Schema<DescribeConnectorRequest>;
export type ConnectorTypeList = ConnectorType[];
export declare const ConnectorTypeList: any;
export type ScheduleFrequencyType = "BYMINUTE" | "HOURLY" | "DAILY" | "WEEKLY" | "MONTHLY" | "ONCE" | (string & {});
export declare const ScheduleFrequencyType: any;
export type SchedulingFrequencyTypeList = ScheduleFrequencyType[];
export declare const SchedulingFrequencyTypeList: any;
export type TriggerTypeList = TriggerType[];
export declare const TriggerTypeList: any;
export interface AmplitudeMetadata {
}
export declare const AmplitudeMetadata: S.Schema<AmplitudeMetadata>;
export interface DatadogMetadata {
}
export declare const DatadogMetadata: S.Schema<DatadogMetadata>;
export interface DynatraceMetadata {
}
export declare const DynatraceMetadata: S.Schema<DynatraceMetadata>;
export interface GoogleAnalyticsMetadata {
    oAuthScopes?: string[];
}
export declare const GoogleAnalyticsMetadata: S.Schema<GoogleAnalyticsMetadata>;
export interface InforNexusMetadata {
}
export declare const InforNexusMetadata: S.Schema<InforNexusMetadata>;
export interface MarketoMetadata {
}
export declare const MarketoMetadata: S.Schema<MarketoMetadata>;
export interface RedshiftMetadata {
}
export declare const RedshiftMetadata: S.Schema<RedshiftMetadata>;
export interface S3Metadata {
}
export declare const S3Metadata: S.Schema<S3Metadata>;
export type SalesforceDataTransferApiList = SalesforceDataTransferApi[];
export declare const SalesforceDataTransferApiList: any;
export type OAuth2GrantTypeSupportedList = OAuth2GrantType[];
export declare const OAuth2GrantTypeSupportedList: any;
export interface SalesforceMetadata {
    oAuthScopes?: string[];
    dataTransferApis?: SalesforceDataTransferApi[];
    oauth2GrantTypesSupported?: OAuth2GrantType[];
}
export declare const SalesforceMetadata: S.Schema<SalesforceMetadata>;
export interface ServiceNowMetadata {
}
export declare const ServiceNowMetadata: S.Schema<ServiceNowMetadata>;
export interface SingularMetadata {
}
export declare const SingularMetadata: S.Schema<SingularMetadata>;
export interface SlackMetadata {
    oAuthScopes?: string[];
}
export declare const SlackMetadata: S.Schema<SlackMetadata>;
export type RegionList = string[];
export declare const RegionList: any;
export interface SnowflakeMetadata {
    supportedRegions?: string[];
}
export declare const SnowflakeMetadata: S.Schema<SnowflakeMetadata>;
export interface TrendmicroMetadata {
}
export declare const TrendmicroMetadata: S.Schema<TrendmicroMetadata>;
export interface VeevaMetadata {
}
export declare const VeevaMetadata: S.Schema<VeevaMetadata>;
export interface ZendeskMetadata {
    oAuthScopes?: string[];
}
export declare const ZendeskMetadata: S.Schema<ZendeskMetadata>;
export interface EventBridgeMetadata {
}
export declare const EventBridgeMetadata: S.Schema<EventBridgeMetadata>;
export interface UpsolverMetadata {
}
export declare const UpsolverMetadata: S.Schema<UpsolverMetadata>;
export interface CustomerProfilesMetadata {
}
export declare const CustomerProfilesMetadata: S.Schema<CustomerProfilesMetadata>;
export interface HoneycodeMetadata {
    oAuthScopes?: string[];
}
export declare const HoneycodeMetadata: S.Schema<HoneycodeMetadata>;
export interface SAPODataMetadata {
}
export declare const SAPODataMetadata: S.Schema<SAPODataMetadata>;
export interface PardotMetadata {
}
export declare const PardotMetadata: S.Schema<PardotMetadata>;
export interface ConnectorMetadata {
    Amplitude?: AmplitudeMetadata;
    Datadog?: DatadogMetadata;
    Dynatrace?: DynatraceMetadata;
    GoogleAnalytics?: GoogleAnalyticsMetadata;
    InforNexus?: InforNexusMetadata;
    Marketo?: MarketoMetadata;
    Redshift?: RedshiftMetadata;
    S3?: S3Metadata;
    Salesforce?: SalesforceMetadata;
    ServiceNow?: ServiceNowMetadata;
    Singular?: SingularMetadata;
    Slack?: SlackMetadata;
    Snowflake?: SnowflakeMetadata;
    Trendmicro?: TrendmicroMetadata;
    Veeva?: VeevaMetadata;
    Zendesk?: ZendeskMetadata;
    EventBridge?: EventBridgeMetadata;
    Upsolver?: UpsolverMetadata;
    CustomerProfiles?: CustomerProfilesMetadata;
    Honeycode?: HoneycodeMetadata;
    SAPOData?: SAPODataMetadata;
    Pardot?: PardotMetadata;
}
export declare const ConnectorMetadata: S.Schema<ConnectorMetadata>;
export type ConnectorDescription = string;
export type ConnectorOwner = string;
export type ConnectorName = string;
export type ConnectorVersion = string;
export type ARN = string;
export type ConnectorMode = string;
export type ConnectorModeList = string[];
export declare const ConnectorModeList: any;
export type TokenUrlList = string[];
export declare const TokenUrlList: any;
export type AuthCodeUrlList = string[];
export declare const AuthCodeUrlList: any;
export type Label = string;
export type Description = string;
export type ConnectorSuppliedValue = string;
export type ConnectorSuppliedValueList = string[];
export declare const ConnectorSuppliedValueList: any;
export type OAuth2CustomPropType = "TOKEN_URL" | "AUTH_URL" | (string & {});
export declare const OAuth2CustomPropType: any;
export interface OAuth2CustomParameter {
    key?: string;
    isRequired?: boolean;
    label?: string;
    description?: string;
    isSensitiveField?: boolean;
    connectorSuppliedValues?: string[];
    type?: OAuth2CustomPropType;
}
export declare const OAuth2CustomParameter: S.Schema<OAuth2CustomParameter>;
export type OAuth2CustomPropertiesList = OAuth2CustomParameter[];
export declare const OAuth2CustomPropertiesList: any;
export interface OAuth2Defaults {
    oauthScopes?: string[];
    tokenUrls?: string[];
    authCodeUrls?: string[];
    oauth2GrantTypesSupported?: OAuth2GrantType[];
    oauth2CustomProperties?: OAuth2CustomParameter[];
}
export declare const OAuth2Defaults: S.Schema<OAuth2Defaults>;
export interface AuthParameter {
    key?: string;
    isRequired?: boolean;
    label?: string;
    description?: string;
    isSensitiveField?: boolean;
    connectorSuppliedValues?: string[];
}
export declare const AuthParameter: S.Schema<AuthParameter>;
export type AuthParameterList = AuthParameter[];
export declare const AuthParameterList: any;
export interface CustomAuthConfig {
    customAuthenticationType?: string;
    authParameters?: AuthParameter[];
}
export declare const CustomAuthConfig: S.Schema<CustomAuthConfig>;
export type CustomAuthConfigList = CustomAuthConfig[];
export declare const CustomAuthConfigList: any;
export interface AuthenticationConfig {
    isBasicAuthSupported?: boolean;
    isApiKeyAuthSupported?: boolean;
    isOAuth2Supported?: boolean;
    isCustomAuthSupported?: boolean;
    oAuth2Defaults?: OAuth2Defaults;
    customAuthConfigs?: CustomAuthConfig[];
}
export declare const AuthenticationConfig: S.Schema<AuthenticationConfig>;
export type ConnectorRuntimeSettingDataType = string;
export type ConnectorRuntimeSettingScope = string;
export type ConnectorSuppliedValueOptionList = string[];
export declare const ConnectorSuppliedValueOptionList: any;
export interface ConnectorRuntimeSetting {
    key?: string;
    dataType?: string;
    isRequired?: boolean;
    label?: string;
    description?: string;
    scope?: string;
    connectorSuppliedValueOptions?: string[];
}
export declare const ConnectorRuntimeSetting: S.Schema<ConnectorRuntimeSetting>;
export type ConnectorRuntimeSettingList = ConnectorRuntimeSetting[];
export declare const ConnectorRuntimeSettingList: any;
export type SupportedApiVersion = string;
export type SupportedApiVersionList = string[];
export declare const SupportedApiVersionList: any;
export type Operators = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "CONTAINS" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export declare const Operators: any;
export type SupportedOperatorList = Operators[];
export declare const SupportedOperatorList: any;
export type SupportedWriteOperationList = WriteOperationType[];
export declare const SupportedWriteOperationList: any;
export type ConnectorProvisioningType = "LAMBDA" | (string & {});
export declare const ConnectorProvisioningType: any;
export interface LambdaConnectorProvisioningConfig {
    lambdaArn: string;
}
export declare const LambdaConnectorProvisioningConfig: S.Schema<LambdaConnectorProvisioningConfig>;
export interface ConnectorProvisioningConfig {
    lambda?: LambdaConnectorProvisioningConfig;
}
export declare const ConnectorProvisioningConfig: S.Schema<ConnectorProvisioningConfig>;
export type LogoURL = string;
export type RegisteredBy = string;
export type SupportedDataTransferType = "RECORD" | "FILE" | (string & {});
export declare const SupportedDataTransferType: any;
export type SupportedDataTransferTypeList = SupportedDataTransferType[];
export declare const SupportedDataTransferTypeList: any;
export type SupportedDataTransferApis = DataTransferApi[];
export declare const SupportedDataTransferApis: any;
export interface ConnectorConfiguration {
    canUseAsSource?: boolean;
    canUseAsDestination?: boolean;
    supportedDestinationConnectors?: ConnectorType[];
    supportedSchedulingFrequencies?: ScheduleFrequencyType[];
    isPrivateLinkEnabled?: boolean;
    isPrivateLinkEndpointUrlRequired?: boolean;
    supportedTriggerTypes?: TriggerType[];
    connectorMetadata?: ConnectorMetadata;
    connectorType?: ConnectorType;
    connectorLabel?: string;
    connectorDescription?: string;
    connectorOwner?: string;
    connectorName?: string;
    connectorVersion?: string;
    connectorArn?: string;
    connectorModes?: string[];
    authenticationConfig?: AuthenticationConfig;
    connectorRuntimeSettings?: ConnectorRuntimeSetting[];
    supportedApiVersions?: string[];
    supportedOperators?: Operators[];
    supportedWriteOperations?: WriteOperationType[];
    connectorProvisioningType?: ConnectorProvisioningType;
    connectorProvisioningConfig?: ConnectorProvisioningConfig;
    logoURL?: string;
    registeredAt?: Date;
    registeredBy?: string;
    supportedDataTransferTypes?: SupportedDataTransferType[];
    supportedDataTransferApis?: DataTransferApi[];
}
export declare const ConnectorConfiguration: S.Schema<ConnectorConfiguration>;
export interface DescribeConnectorResponse {
    connectorConfiguration?: ConnectorConfiguration;
}
export declare const DescribeConnectorResponse: S.Schema<DescribeConnectorResponse>;
export interface DescribeConnectorEntityRequest {
    connectorEntityName: string;
    connectorType?: ConnectorType;
    connectorProfileName?: string;
    apiVersion?: string;
}
export declare const DescribeConnectorEntityRequest: S.Schema<DescribeConnectorEntityRequest>;
export type Identifier = string;
export type FieldType = string;
export type FilterOperatorList = Operator[];
export declare const FilterOperatorList: any;
export type Value = string;
export type SupportedValueList = string[];
export declare const SupportedValueList: any;
export interface Range {
    maximum?: number;
    minimum?: number;
}
export declare const Range: S.Schema<Range>;
export interface FieldTypeDetails {
    fieldType: string;
    filterOperators: Operator[];
    supportedValues?: string[];
    valueRegexPattern?: string;
    supportedDateFormat?: string;
    fieldValueRange?: Range;
    fieldLengthRange?: Range;
}
export declare const FieldTypeDetails: S.Schema<FieldTypeDetails>;
export interface SupportedFieldTypeDetails {
    v1: FieldTypeDetails;
}
export declare const SupportedFieldTypeDetails: S.Schema<SupportedFieldTypeDetails>;
export interface SourceFieldProperties {
    isRetrievable?: boolean;
    isQueryable?: boolean;
    isTimestampFieldForIncrementalQueries?: boolean;
}
export declare const SourceFieldProperties: S.Schema<SourceFieldProperties>;
export interface DestinationFieldProperties {
    isCreatable?: boolean;
    isNullable?: boolean;
    isUpsertable?: boolean;
    isUpdatable?: boolean;
    isDefaultedOnCreate?: boolean;
    supportedWriteOperations?: WriteOperationType[];
}
export declare const DestinationFieldProperties: S.Schema<DestinationFieldProperties>;
export interface ConnectorEntityField {
    identifier: string;
    parentIdentifier?: string;
    label?: string;
    isPrimaryKey?: boolean;
    defaultValue?: string;
    isDeprecated?: boolean;
    supportedFieldTypeDetails?: SupportedFieldTypeDetails;
    description?: string;
    sourceProperties?: SourceFieldProperties;
    destinationProperties?: DestinationFieldProperties;
    customProperties?: {
        [key: string]: string | undefined;
    };
}
export declare const ConnectorEntityField: S.Schema<ConnectorEntityField>;
export type ConnectorEntityFieldList = ConnectorEntityField[];
export declare const ConnectorEntityFieldList: any;
export interface DescribeConnectorEntityResponse {
    connectorEntityFields: ConnectorEntityField[];
}
export declare const DescribeConnectorEntityResponse: S.Schema<DescribeConnectorEntityResponse>;
export type ConnectorProfileNameList = string[];
export declare const ConnectorProfileNameList: any;
export type MaxResults = number;
export type NextToken = string;
export interface DescribeConnectorProfilesRequest {
    connectorProfileNames?: string[];
    connectorType?: ConnectorType;
    connectorLabel?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeConnectorProfilesRequest: S.Schema<DescribeConnectorProfilesRequest>;
export type PrivateConnectionProvisioningStatus = "FAILED" | "PENDING" | "CREATED" | (string & {});
export declare const PrivateConnectionProvisioningStatus: any;
export type PrivateConnectionProvisioningFailureMessage = string;
export type PrivateConnectionProvisioningFailureCause = "CONNECTOR_AUTHENTICATION" | "CONNECTOR_SERVER" | "INTERNAL_SERVER" | "ACCESS_DENIED" | "VALIDATION" | (string & {});
export declare const PrivateConnectionProvisioningFailureCause: any;
export interface PrivateConnectionProvisioningState {
    status?: PrivateConnectionProvisioningStatus;
    failureMessage?: string;
    failureCause?: PrivateConnectionProvisioningFailureCause;
}
export declare const PrivateConnectionProvisioningState: S.Schema<PrivateConnectionProvisioningState>;
export interface ConnectorProfile {
    connectorProfileArn?: string;
    connectorProfileName?: string;
    connectorType?: ConnectorType;
    connectorLabel?: string;
    connectionMode?: ConnectionMode;
    credentialsArn?: string;
    connectorProfileProperties?: ConnectorProfileProperties;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    privateConnectionProvisioningState?: PrivateConnectionProvisioningState;
}
export declare const ConnectorProfile: S.Schema<ConnectorProfile>;
export type ConnectorProfileDetailList = ConnectorProfile[];
export declare const ConnectorProfileDetailList: any;
export interface DescribeConnectorProfilesResponse {
    connectorProfileDetails?: ConnectorProfile[];
    nextToken?: string;
}
export declare const DescribeConnectorProfilesResponse: S.Schema<DescribeConnectorProfilesResponse>;
export interface DescribeConnectorsRequest {
    connectorTypes?: ConnectorType[];
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeConnectorsRequest: S.Schema<DescribeConnectorsRequest>;
export type ConnectorConfigurationsMap = {
    [key in ConnectorType]?: ConnectorConfiguration;
};
export declare const ConnectorConfigurationsMap: any;
export type ApplicationType = string;
export interface ConnectorDetail {
    connectorDescription?: string;
    connectorName?: string;
    connectorOwner?: string;
    connectorVersion?: string;
    applicationType?: string;
    connectorType?: ConnectorType;
    connectorLabel?: string;
    registeredAt?: Date;
    registeredBy?: string;
    connectorProvisioningType?: ConnectorProvisioningType;
    connectorModes?: string[];
    supportedDataTransferTypes?: SupportedDataTransferType[];
}
export declare const ConnectorDetail: S.Schema<ConnectorDetail>;
export type ConnectorList = ConnectorDetail[];
export declare const ConnectorList: any;
export interface DescribeConnectorsResponse {
    connectorConfigurations?: {
        [key: string]: ConnectorConfiguration | undefined;
    };
    connectors?: ConnectorDetail[];
    nextToken?: string;
}
export declare const DescribeConnectorsResponse: S.Schema<DescribeConnectorsResponse>;
export interface DescribeFlowRequest {
    flowName: string;
}
export declare const DescribeFlowRequest: S.Schema<DescribeFlowRequest>;
export type FlowStatusMessage = string;
export type MostRecentExecutionMessage = string;
export type ExecutionStatus = "InProgress" | "Successful" | "Error" | "CancelStarted" | "Canceled" | (string & {});
export declare const ExecutionStatus: any;
export interface ExecutionDetails {
    mostRecentExecutionMessage?: string;
    mostRecentExecutionTime?: Date;
    mostRecentExecutionStatus?: ExecutionStatus;
}
export declare const ExecutionDetails: S.Schema<ExecutionDetails>;
export type CreatedBy = string;
export type UpdatedBy = string;
export type CatalogType = "GLUE" | (string & {});
export declare const CatalogType: any;
export interface RegistrationOutput {
    message?: string;
    result?: string;
    status?: ExecutionStatus;
}
export declare const RegistrationOutput: S.Schema<RegistrationOutput>;
export interface MetadataCatalogDetail {
    catalogType?: CatalogType;
    tableName?: string;
    tableRegistrationOutput?: RegistrationOutput;
    partitionRegistrationOutput?: RegistrationOutput;
}
export declare const MetadataCatalogDetail: S.Schema<MetadataCatalogDetail>;
export type MetadataCatalogDetails = MetadataCatalogDetail[];
export declare const MetadataCatalogDetails: any;
export interface DescribeFlowResponse {
    flowArn?: string;
    description?: string;
    flowName?: string;
    kmsArn?: string;
    flowStatus?: FlowStatus;
    flowStatusMessage?: string;
    sourceFlowConfig?: SourceFlowConfig;
    destinationFlowConfigList?: DestinationFlowConfig[];
    lastRunExecutionDetails?: ExecutionDetails;
    triggerConfig?: TriggerConfig;
    tasks?: Task[];
    createdAt?: Date;
    lastUpdatedAt?: Date;
    createdBy?: string;
    lastUpdatedBy?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    metadataCatalogConfig?: MetadataCatalogConfig;
    lastRunMetadataCatalogDetails?: MetadataCatalogDetail[];
    schemaVersion?: number;
}
export declare const DescribeFlowResponse: S.Schema<DescribeFlowResponse>;
export interface DescribeFlowExecutionRecordsRequest {
    flowName: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeFlowExecutionRecordsRequest: S.Schema<DescribeFlowExecutionRecordsRequest>;
export type ExecutionMessage = string;
export interface ErrorInfo {
    putFailuresCount?: number;
    executionMessage?: string;
}
export declare const ErrorInfo: S.Schema<ErrorInfo>;
export interface ExecutionResult {
    errorInfo?: ErrorInfo;
    bytesProcessed?: number;
    bytesWritten?: number;
    recordsProcessed?: number;
    numParallelProcesses?: number;
    maxPageSize?: number;
}
export declare const ExecutionResult: S.Schema<ExecutionResult>;
export interface ExecutionRecord {
    executionId?: string;
    executionStatus?: ExecutionStatus;
    executionResult?: ExecutionResult;
    startedAt?: Date;
    lastUpdatedAt?: Date;
    dataPullStartTime?: Date;
    dataPullEndTime?: Date;
    metadataCatalogDetails?: MetadataCatalogDetail[];
}
export declare const ExecutionRecord: S.Schema<ExecutionRecord>;
export type FlowExecutionList = ExecutionRecord[];
export declare const FlowExecutionList: any;
export interface DescribeFlowExecutionRecordsResponse {
    flowExecutions?: ExecutionRecord[];
    nextToken?: string;
}
export declare const DescribeFlowExecutionRecordsResponse: S.Schema<DescribeFlowExecutionRecordsResponse>;
export type EntitiesPath = string;
export type ListEntitiesMaxResults = number;
export interface ListConnectorEntitiesRequest {
    connectorProfileName?: string;
    connectorType?: ConnectorType;
    entitiesPath?: string;
    apiVersion?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListConnectorEntitiesRequest: S.Schema<ListConnectorEntitiesRequest>;
export type Group = string;
export interface ConnectorEntity {
    name: string;
    label?: string;
    hasNestedEntities?: boolean;
}
export declare const ConnectorEntity: S.Schema<ConnectorEntity>;
export type ConnectorEntityList = ConnectorEntity[];
export declare const ConnectorEntityList: any;
export type ConnectorEntityMap = {
    [key: string]: ConnectorEntity[] | undefined;
};
export declare const ConnectorEntityMap: any;
export interface ListConnectorEntitiesResponse {
    connectorEntityMap: {
        [key: string]: ConnectorEntity[] | undefined;
    };
    nextToken?: string;
}
export declare const ListConnectorEntitiesResponse: S.Schema<ListConnectorEntitiesResponse>;
export interface ListConnectorsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListConnectorsRequest: S.Schema<ListConnectorsRequest>;
export interface ListConnectorsResponse {
    connectors?: ConnectorDetail[];
    nextToken?: string;
}
export declare const ListConnectorsResponse: S.Schema<ListConnectorsResponse>;
export interface ListFlowsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListFlowsRequest: S.Schema<ListFlowsRequest>;
export interface FlowDefinition {
    flowArn?: string;
    description?: string;
    flowName?: string;
    flowStatus?: FlowStatus;
    sourceConnectorType?: ConnectorType;
    sourceConnectorLabel?: string;
    destinationConnectorType?: ConnectorType;
    destinationConnectorLabel?: string;
    triggerType?: TriggerType;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    createdBy?: string;
    lastUpdatedBy?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    lastRunExecutionDetails?: ExecutionDetails;
}
export declare const FlowDefinition: S.Schema<FlowDefinition>;
export type FlowList = FlowDefinition[];
export declare const FlowList: any;
export interface ListFlowsResponse {
    flows?: FlowDefinition[];
    nextToken?: string;
}
export declare const ListFlowsResponse: S.Schema<ListFlowsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface RegisterConnectorRequest {
    connectorLabel?: string;
    description?: string;
    connectorProvisioningType?: ConnectorProvisioningType;
    connectorProvisioningConfig?: ConnectorProvisioningConfig;
    clientToken?: string;
}
export declare const RegisterConnectorRequest: S.Schema<RegisterConnectorRequest>;
export interface RegisterConnectorResponse {
    connectorArn?: string;
}
export declare const RegisterConnectorResponse: S.Schema<RegisterConnectorResponse>;
export interface ResetConnectorMetadataCacheRequest {
    connectorProfileName?: string;
    connectorType?: ConnectorType;
    connectorEntityName?: string;
    entitiesPath?: string;
    apiVersion?: string;
}
export declare const ResetConnectorMetadataCacheRequest: S.Schema<ResetConnectorMetadataCacheRequest>;
export interface ResetConnectorMetadataCacheResponse {
}
export declare const ResetConnectorMetadataCacheResponse: S.Schema<ResetConnectorMetadataCacheResponse>;
export interface StartFlowRequest {
    flowName: string;
    clientToken?: string;
}
export declare const StartFlowRequest: S.Schema<StartFlowRequest>;
export interface StartFlowResponse {
    flowArn?: string;
    flowStatus?: FlowStatus;
    executionId?: string;
}
export declare const StartFlowResponse: S.Schema<StartFlowResponse>;
export interface StopFlowRequest {
    flowName: string;
}
export declare const StopFlowRequest: S.Schema<StopFlowRequest>;
export interface StopFlowResponse {
    flowArn?: string;
    flowStatus?: FlowStatus;
}
export declare const StopFlowResponse: S.Schema<StopFlowResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface UnregisterConnectorRequest {
    connectorLabel: string;
    forceDelete?: boolean;
}
export declare const UnregisterConnectorRequest: S.Schema<UnregisterConnectorRequest>;
export interface UnregisterConnectorResponse {
}
export declare const UnregisterConnectorResponse: S.Schema<UnregisterConnectorResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateConnectorProfileRequest {
    connectorProfileName: string;
    connectionMode: ConnectionMode;
    connectorProfileConfig: ConnectorProfileConfig;
    clientToken?: string;
}
export declare const UpdateConnectorProfileRequest: S.Schema<UpdateConnectorProfileRequest>;
export interface UpdateConnectorProfileResponse {
    connectorProfileArn?: string;
}
export declare const UpdateConnectorProfileResponse: S.Schema<UpdateConnectorProfileResponse>;
export interface UpdateConnectorRegistrationRequest {
    connectorLabel: string;
    description?: string;
    connectorProvisioningConfig?: ConnectorProvisioningConfig;
    clientToken?: string;
}
export declare const UpdateConnectorRegistrationRequest: S.Schema<UpdateConnectorRegistrationRequest>;
export interface UpdateConnectorRegistrationResponse {
    connectorArn?: string;
}
export declare const UpdateConnectorRegistrationResponse: S.Schema<UpdateConnectorRegistrationResponse>;
export interface UpdateFlowRequest {
    flowName: string;
    description?: string;
    triggerConfig: TriggerConfig;
    sourceFlowConfig: SourceFlowConfig;
    destinationFlowConfigList: DestinationFlowConfig[];
    tasks: Task[];
    metadataCatalogConfig?: MetadataCatalogConfig;
    clientToken?: string;
}
export declare const UpdateFlowRequest: S.Schema<UpdateFlowRequest>;
export interface UpdateFlowResponse {
    flowStatus?: FlowStatus;
}
export declare const UpdateFlowResponse: S.Schema<UpdateFlowResponse>;
export type ErrorMessage = string;
export type CancelFlowExecutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels active runs for a flow.
 *
 * You can cancel all of the active runs for a flow, or you can cancel specific runs by
 * providing their IDs.
 *
 * You can cancel a flow run only when the run is in progress. You can't cancel a run that
 * has already completed or failed. You also can't cancel a run that's scheduled to occur but
 * hasn't started yet. To prevent a scheduled run, you can deactivate the flow with the
 * `StopFlow` action.
 *
 * You cannot resume a run after you cancel it.
 *
 * When you send your request, the status for each run becomes `CancelStarted`.
 * When the cancellation completes, the status becomes `Canceled`.
 *
 * When you cancel a run, you still incur charges for any data that the run already
 * processed before the cancellation. If the run had already written some data to the flow
 * destination, then that data remains in the destination. If you configured the flow to use a
 * batch API (such as the Salesforce Bulk API 2.0), then the run will finish reading or writing
 * its entire batch of data after the cancellation. For these operations, the data processing
 * charges for Amazon AppFlow apply. For the pricing information, see Amazon AppFlow pricing.
 */
export declare const cancelFlowExecutions: API.OperationMethod<CancelFlowExecutionsRequest, CancelFlowExecutionsResponse, CancelFlowExecutionsError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorProfileError = ConflictException | ConnectorAuthenticationException | InternalServerException | ServiceQuotaExceededException | ValidationException | ConnectorServerException | CommonErrors;
/**
 * Creates a new connector profile associated with your Amazon Web Services account. There is
 * a soft quota of 100 connector profiles per Amazon Web Services account. If you need more
 * connector profiles than this quota allows, you can submit a request to the Amazon AppFlow
 * team through the Amazon AppFlow support channel. In each connector profile that you
 * create, you can provide the credentials and properties for only one connector.
 */
export declare const createConnectorProfile: API.OperationMethod<CreateConnectorProfileRequest, CreateConnectorProfileResponse, CreateConnectorProfileError, Credentials | HttpClient.HttpClient>;
export type CreateFlowError = AccessDeniedException | ConflictException | ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Enables your application to create a new flow using Amazon AppFlow. You must create
 * a connector profile before calling this API. Please note that the Request Syntax below shows
 * syntax for multiple destinations, however, you can only transfer data to one item in this list
 * at a time. Amazon AppFlow does not currently support flows to multiple destinations at
 * once.
 */
export declare const createFlow: API.OperationMethod<CreateFlowRequest, CreateFlowResponse, CreateFlowError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorProfileError = ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Enables you to delete an existing connector profile.
 */
export declare const deleteConnectorProfile: API.OperationMethod<DeleteConnectorProfileRequest, DeleteConnectorProfileResponse, DeleteConnectorProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowError = ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Enables your application to delete an existing flow. Before deleting the flow, Amazon AppFlow validates the request by checking the flow configuration and status. You can
 * delete flows one at a time.
 */
export declare const deleteFlow: API.OperationMethod<DeleteFlowRequest, DeleteFlowResponse, DeleteFlowError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the given custom connector registered in your Amazon Web Services account. This
 * API can be used for custom connectors that are registered in your account and also for Amazon
 * authored connectors.
 */
export declare const describeConnector: API.OperationMethod<DescribeConnectorRequest, DescribeConnectorResponse, DescribeConnectorError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorEntityError = ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Provides details regarding the entity used with the connector, with a description of the
 * data model for each field in that entity.
 */
export declare const describeConnectorEntity: API.OperationMethod<DescribeConnectorEntityRequest, DescribeConnectorEntityResponse, DescribeConnectorEntityError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorProfilesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of `connector-profile` details matching the provided
 * `connector-profile` names and `connector-types`. Both input lists are
 * optional, and you can use them to filter the result.
 *
 * If no names or `connector-types` are provided, returns all connector profiles
 * in a paginated form. If there is no match, this operation returns an empty list.
 */
export declare const describeConnectorProfiles: API.PaginatedOperationMethod<DescribeConnectorProfilesRequest, DescribeConnectorProfilesResponse, DescribeConnectorProfilesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeConnectorsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Describes the connectors vended by Amazon AppFlow for specified connector types. If
 * you don't specify a connector type, this operation describes all connectors vended by Amazon AppFlow. If there are more connectors than can be returned in one page, the response
 * contains a `nextToken` object, which can be be passed in to the next call to the
 * `DescribeConnectors` API operation to retrieve the next page.
 */
export declare const describeConnectors: API.PaginatedOperationMethod<DescribeConnectorsRequest, DescribeConnectorsResponse, DescribeConnectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFlowError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Provides a description of the specified flow.
 */
export declare const describeFlow: API.OperationMethod<DescribeFlowRequest, DescribeFlowResponse, DescribeFlowError, Credentials | HttpClient.HttpClient>;
export type DescribeFlowExecutionRecordsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Fetches the execution history of the flow.
 */
export declare const describeFlowExecutionRecords: API.PaginatedOperationMethod<DescribeFlowExecutionRecordsRequest, DescribeFlowExecutionRecordsResponse, DescribeFlowExecutionRecordsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListConnectorEntitiesError = ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the list of available connector entities supported by Amazon AppFlow. For
 * example, you can query Salesforce for *Account* and
 * *Opportunity* entities, or query ServiceNow for the
 * *Incident* entity.
 */
export declare const listConnectorEntities: API.OperationMethod<ListConnectorEntitiesRequest, ListConnectorEntitiesResponse, ListConnectorEntitiesError, Credentials | HttpClient.HttpClient>;
export type ListConnectorsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns the list of all registered custom connectors in your Amazon Web Services account.
 * This API lists only custom connectors registered in this account, not the Amazon Web Services
 * authored connectors.
 */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFlowsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists all of the flows associated with your account.
 */
export declare const listFlows: API.PaginatedOperationMethod<ListFlowsRequest, ListFlowsResponse, ListFlowsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the tags that are associated with a specified flow.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterConnectorError = AccessDeniedException | ConflictException | ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers a new custom connector with your Amazon Web Services account. Before you can
 * register the connector, you must deploy the associated AWS lambda function in your
 * account.
 */
export declare const registerConnector: API.OperationMethod<RegisterConnectorRequest, RegisterConnectorResponse, RegisterConnectorError, Credentials | HttpClient.HttpClient>;
export type ResetConnectorMetadataCacheError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Resets metadata about your connector entities that Amazon AppFlow stored in its
 * cache. Use this action when you want Amazon AppFlow to return the latest information
 * about the data that you have in a source application.
 *
 * Amazon AppFlow returns metadata about your entities when you use the
 * ListConnectorEntities or DescribeConnectorEntities actions. Following these actions, Amazon AppFlow caches the metadata to reduce the number of API requests that it must send to
 * the source application. Amazon AppFlow automatically resets the cache once every hour,
 * but you can use this action when you want to get the latest metadata right away.
 */
export declare const resetConnectorMetadataCache: API.OperationMethod<ResetConnectorMetadataCacheRequest, ResetConnectorMetadataCacheResponse, ResetConnectorMetadataCacheError, Credentials | HttpClient.HttpClient>;
export type StartFlowError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Activates an existing flow. For on-demand flows, this operation runs the flow
 * immediately. For schedule and event-triggered flows, this operation activates the flow.
 */
export declare const startFlow: API.OperationMethod<StartFlowRequest, StartFlowResponse, StartFlowError, Credentials | HttpClient.HttpClient>;
export type StopFlowError = ConflictException | InternalServerException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Deactivates the existing flow. For on-demand flows, this operation returns an
 * `unsupportedOperationException` error message. For schedule and event-triggered
 * flows, this operation deactivates the flow.
 */
export declare const stopFlow: API.OperationMethod<StopFlowRequest, StopFlowResponse, StopFlowError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Applies a tag to the specified flow.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UnregisterConnectorError = ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Unregisters the custom connector registered in your account that matches the connector
 * label provided in the request.
 */
export declare const unregisterConnector: API.OperationMethod<UnregisterConnectorRequest, UnregisterConnectorResponse, UnregisterConnectorError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag from the specified flow.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorProfileError = ConflictException | ConnectorAuthenticationException | InternalServerException | ResourceNotFoundException | ValidationException | ConnectorServerException | CommonErrors;
/**
 * Updates a given connector profile associated with your account.
 */
export declare const updateConnectorProfile: API.OperationMethod<UpdateConnectorProfileRequest, UpdateConnectorProfileResponse, UpdateConnectorProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorRegistrationError = AccessDeniedException | ConflictException | ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a custom connector that you've previously registered. This operation updates the
 * connector with one of the following:
 *
 * - The latest version of the AWS Lambda function that's assigned to the connector
 *
 * - A new AWS Lambda function that you specify
 */
export declare const updateConnectorRegistration: API.OperationMethod<UpdateConnectorRegistrationRequest, UpdateConnectorRegistrationResponse, UpdateConnectorRegistrationError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowError = AccessDeniedException | ConflictException | ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates an existing flow.
 */
export declare const updateFlow: API.OperationMethod<UpdateFlowRequest, UpdateFlowResponse, UpdateFlowError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appflow.d.ts.map