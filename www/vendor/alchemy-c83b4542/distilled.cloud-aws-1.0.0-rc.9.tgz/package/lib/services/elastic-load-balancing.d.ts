import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessPointNotFoundException_base: S.Class<AccessPointNotFoundException, S.TaggedStruct<"AccessPointNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccessPointNotFoundException extends /*@__PURE__*/ AccessPointNotFoundException_base {
}
declare const CertificateNotFoundException_base: S.Class<CertificateNotFoundException, S.TaggedStruct<"CertificateNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CertificateNotFoundException extends /*@__PURE__*/ CertificateNotFoundException_base {
}
declare const DependencyThrottleException_base: S.Class<DependencyThrottleException, S.TaggedStruct<"DependencyThrottleException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DependencyThrottleException extends /*@__PURE__*/ DependencyThrottleException_base {
}
declare const DuplicateAccessPointNameException_base: S.Class<DuplicateAccessPointNameException, S.TaggedStruct<"DuplicateAccessPointNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateAccessPointNameException extends /*@__PURE__*/ DuplicateAccessPointNameException_base {
}
declare const DuplicateListenerException_base: S.Class<DuplicateListenerException, S.TaggedStruct<"DuplicateListenerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateListenerException extends /*@__PURE__*/ DuplicateListenerException_base {
}
declare const DuplicatePolicyNameException_base: S.Class<DuplicatePolicyNameException, S.TaggedStruct<"DuplicatePolicyNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicatePolicyNameException extends /*@__PURE__*/ DuplicatePolicyNameException_base {
}
declare const DuplicateTagKeysException_base: S.Class<DuplicateTagKeysException, S.TaggedStruct<"DuplicateTagKeysException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateTagKeysException extends /*@__PURE__*/ DuplicateTagKeysException_base {
}
declare const InvalidConfigurationRequestException_base: S.Class<InvalidConfigurationRequestException, S.TaggedStruct<"InvalidConfigurationRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidConfigurationRequestException extends /*@__PURE__*/ InvalidConfigurationRequestException_base {
}
declare const InvalidEndPointException_base: S.Class<InvalidEndPointException, S.TaggedStruct<"InvalidEndPointException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEndPointException extends /*@__PURE__*/ InvalidEndPointException_base {
}
declare const InvalidSchemeException_base: S.Class<InvalidSchemeException, S.TaggedStruct<"InvalidSchemeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSchemeException extends /*@__PURE__*/ InvalidSchemeException_base {
}
declare const InvalidSecurityGroupException_base: S.Class<InvalidSecurityGroupException, S.TaggedStruct<"InvalidSecurityGroupException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSecurityGroupException extends /*@__PURE__*/ InvalidSecurityGroupException_base {
}
declare const InvalidSubnetException_base: S.Class<InvalidSubnetException, S.TaggedStruct<"InvalidSubnetException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubnetException extends /*@__PURE__*/ InvalidSubnetException_base {
}
declare const ListenerNotFoundException_base: S.Class<ListenerNotFoundException, S.TaggedStruct<"ListenerNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ListenerNotFoundException extends /*@__PURE__*/ ListenerNotFoundException_base {
}
declare const LoadBalancerAttributeNotFoundException_base: S.Class<LoadBalancerAttributeNotFoundException, S.TaggedStruct<"LoadBalancerAttributeNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LoadBalancerAttributeNotFoundException extends /*@__PURE__*/ LoadBalancerAttributeNotFoundException_base {
}
declare const OperationNotPermittedException_base: S.Class<OperationNotPermittedException, S.TaggedStruct<"OperationNotPermittedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationNotPermittedException extends /*@__PURE__*/ OperationNotPermittedException_base {
}
declare const PolicyNotFoundException_base: S.Class<PolicyNotFoundException, S.TaggedStruct<"PolicyNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PolicyNotFoundException extends /*@__PURE__*/ PolicyNotFoundException_base {
}
declare const PolicyTypeNotFoundException_base: S.Class<PolicyTypeNotFoundException, S.TaggedStruct<"PolicyTypeNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PolicyTypeNotFoundException extends /*@__PURE__*/ PolicyTypeNotFoundException_base {
}
declare const SubnetNotFoundException_base: S.Class<SubnetNotFoundException, S.TaggedStruct<"SubnetNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetNotFoundException extends /*@__PURE__*/ SubnetNotFoundException_base {
}
declare const TooManyAccessPointsException_base: S.Class<TooManyAccessPointsException, S.TaggedStruct<"TooManyAccessPointsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyAccessPointsException extends /*@__PURE__*/ TooManyAccessPointsException_base {
}
declare const TooManyPoliciesException_base: S.Class<TooManyPoliciesException, S.TaggedStruct<"TooManyPoliciesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyPoliciesException extends /*@__PURE__*/ TooManyPoliciesException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnsupportedProtocolException_base: S.Class<UnsupportedProtocolException, S.TaggedStruct<"UnsupportedProtocolException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedProtocolException extends /*@__PURE__*/ UnsupportedProtocolException_base {
}
export type AccessPointName = string;
export type LoadBalancerNames = string[];
export declare const LoadBalancerNames: any;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface AddTagsInput {
    LoadBalancerNames: string[];
    Tags: Tag[];
}
export declare const AddTagsInput: S.Schema<AddTagsInput>;
export interface AddTagsOutput {
}
export declare const AddTagsOutput: S.Schema<AddTagsOutput>;
export type SecurityGroupId = string;
export type SecurityGroups = string[];
export declare const SecurityGroups: any;
export interface ApplySecurityGroupsToLoadBalancerInput {
    LoadBalancerName: string;
    SecurityGroups: string[];
}
export declare const ApplySecurityGroupsToLoadBalancerInput: S.Schema<ApplySecurityGroupsToLoadBalancerInput>;
export interface ApplySecurityGroupsToLoadBalancerOutput {
    SecurityGroups?: string[];
}
export declare const ApplySecurityGroupsToLoadBalancerOutput: S.Schema<ApplySecurityGroupsToLoadBalancerOutput>;
export type SubnetId = string;
export type Subnets = string[];
export declare const Subnets: any;
export interface AttachLoadBalancerToSubnetsInput {
    LoadBalancerName: string;
    Subnets: string[];
}
export declare const AttachLoadBalancerToSubnetsInput: S.Schema<AttachLoadBalancerToSubnetsInput>;
export interface AttachLoadBalancerToSubnetsOutput {
    Subnets?: string[];
}
export declare const AttachLoadBalancerToSubnetsOutput: S.Schema<AttachLoadBalancerToSubnetsOutput>;
export type HealthCheckTarget = string;
export type HealthCheckInterval = number;
export type HealthCheckTimeout = number;
export type UnhealthyThreshold = number;
export type HealthyThreshold = number;
export interface HealthCheck {
    Target: string;
    Interval: number;
    Timeout: number;
    UnhealthyThreshold: number;
    HealthyThreshold: number;
}
export declare const HealthCheck: S.Schema<HealthCheck>;
export interface ConfigureHealthCheckInput {
    LoadBalancerName: string;
    HealthCheck: HealthCheck;
}
export declare const ConfigureHealthCheckInput: S.Schema<ConfigureHealthCheckInput>;
export interface ConfigureHealthCheckOutput {
    HealthCheck?: HealthCheck;
}
export declare const ConfigureHealthCheckOutput: S.Schema<ConfigureHealthCheckOutput>;
export type PolicyName = string;
export type CookieName = string;
export interface CreateAppCookieStickinessPolicyInput {
    LoadBalancerName: string;
    PolicyName: string;
    CookieName: string;
}
export declare const CreateAppCookieStickinessPolicyInput: S.Schema<CreateAppCookieStickinessPolicyInput>;
export interface CreateAppCookieStickinessPolicyOutput {
}
export declare const CreateAppCookieStickinessPolicyOutput: S.Schema<CreateAppCookieStickinessPolicyOutput>;
export type CookieExpirationPeriod = number;
export interface CreateLBCookieStickinessPolicyInput {
    LoadBalancerName: string;
    PolicyName: string;
    CookieExpirationPeriod?: number;
}
export declare const CreateLBCookieStickinessPolicyInput: S.Schema<CreateLBCookieStickinessPolicyInput>;
export interface CreateLBCookieStickinessPolicyOutput {
}
export declare const CreateLBCookieStickinessPolicyOutput: S.Schema<CreateLBCookieStickinessPolicyOutput>;
export type Protocol = string;
export type AccessPointPort = number;
export type InstancePort = number;
export type SSLCertificateId = string;
export interface Listener {
    Protocol: string;
    LoadBalancerPort: number;
    InstanceProtocol?: string;
    InstancePort: number;
    SSLCertificateId?: string;
}
export declare const Listener: S.Schema<Listener>;
export type Listeners = Listener[];
export declare const Listeners: any;
export type AvailabilityZone = string;
export type AvailabilityZones = string[];
export declare const AvailabilityZones: any;
export type LoadBalancerScheme = string;
export interface CreateAccessPointInput {
    LoadBalancerName: string;
    Listeners: Listener[];
    AvailabilityZones?: string[];
    Subnets?: string[];
    SecurityGroups?: string[];
    Scheme?: string;
    Tags?: Tag[];
}
export declare const CreateAccessPointInput: S.Schema<CreateAccessPointInput>;
export type DNSName = string;
export interface CreateAccessPointOutput {
    DNSName?: string;
}
export declare const CreateAccessPointOutput: S.Schema<CreateAccessPointOutput>;
export interface CreateLoadBalancerListenerInput {
    LoadBalancerName: string;
    Listeners: Listener[];
}
export declare const CreateLoadBalancerListenerInput: S.Schema<CreateLoadBalancerListenerInput>;
export interface CreateLoadBalancerListenerOutput {
}
export declare const CreateLoadBalancerListenerOutput: S.Schema<CreateLoadBalancerListenerOutput>;
export type PolicyTypeName = string;
export type AttributeName = string;
export type AttributeValue = string;
export interface PolicyAttribute {
    AttributeName?: string;
    AttributeValue?: string;
}
export declare const PolicyAttribute: S.Schema<PolicyAttribute>;
export type PolicyAttributes = PolicyAttribute[];
export declare const PolicyAttributes: any;
export interface CreateLoadBalancerPolicyInput {
    LoadBalancerName: string;
    PolicyName: string;
    PolicyTypeName: string;
    PolicyAttributes?: PolicyAttribute[];
}
export declare const CreateLoadBalancerPolicyInput: S.Schema<CreateLoadBalancerPolicyInput>;
export interface CreateLoadBalancerPolicyOutput {
}
export declare const CreateLoadBalancerPolicyOutput: S.Schema<CreateLoadBalancerPolicyOutput>;
export interface DeleteAccessPointInput {
    LoadBalancerName: string;
}
export declare const DeleteAccessPointInput: S.Schema<DeleteAccessPointInput>;
export interface DeleteAccessPointOutput {
}
export declare const DeleteAccessPointOutput: S.Schema<DeleteAccessPointOutput>;
export type Ports = number[];
export declare const Ports: any;
export interface DeleteLoadBalancerListenerInput {
    LoadBalancerName: string;
    LoadBalancerPorts: number[];
}
export declare const DeleteLoadBalancerListenerInput: S.Schema<DeleteLoadBalancerListenerInput>;
export interface DeleteLoadBalancerListenerOutput {
}
export declare const DeleteLoadBalancerListenerOutput: S.Schema<DeleteLoadBalancerListenerOutput>;
export interface DeleteLoadBalancerPolicyInput {
    LoadBalancerName: string;
    PolicyName: string;
}
export declare const DeleteLoadBalancerPolicyInput: S.Schema<DeleteLoadBalancerPolicyInput>;
export interface DeleteLoadBalancerPolicyOutput {
}
export declare const DeleteLoadBalancerPolicyOutput: S.Schema<DeleteLoadBalancerPolicyOutput>;
export type InstanceId = string;
export interface Instance {
    InstanceId?: string;
}
export declare const Instance: S.Schema<Instance>;
export type Instances = Instance[];
export declare const Instances: any;
export interface DeregisterEndPointsInput {
    LoadBalancerName: string;
    Instances: Instance[];
}
export declare const DeregisterEndPointsInput: S.Schema<DeregisterEndPointsInput>;
export interface DeregisterEndPointsOutput {
    Instances?: Instance[];
}
export declare const DeregisterEndPointsOutput: S.Schema<DeregisterEndPointsOutput>;
export type Marker = string;
export type PageSize = number;
export interface DescribeAccountLimitsInput {
    Marker?: string;
    PageSize?: number;
}
export declare const DescribeAccountLimitsInput: S.Schema<DescribeAccountLimitsInput>;
export type Name = string;
export type Max = string;
export interface Limit {
    Name?: string;
    Max?: string;
}
export declare const Limit: S.Schema<Limit>;
export type Limits = Limit[];
export declare const Limits: any;
export interface DescribeAccountLimitsOutput {
    Limits?: Limit[];
    NextMarker?: string;
}
export declare const DescribeAccountLimitsOutput: S.Schema<DescribeAccountLimitsOutput>;
export interface DescribeEndPointStateInput {
    LoadBalancerName: string;
    Instances?: Instance[];
}
export declare const DescribeEndPointStateInput: S.Schema<DescribeEndPointStateInput>;
export type State = string;
export type ReasonCode = string;
export type Description = string;
export interface InstanceState {
    InstanceId?: string;
    State?: string;
    ReasonCode?: string;
    Description?: string;
}
export declare const InstanceState: S.Schema<InstanceState>;
export type InstanceStates = InstanceState[];
export declare const InstanceStates: any;
export interface DescribeEndPointStateOutput {
    InstanceStates?: InstanceState[];
}
export declare const DescribeEndPointStateOutput: S.Schema<DescribeEndPointStateOutput>;
export interface DescribeLoadBalancerAttributesInput {
    LoadBalancerName: string;
}
export declare const DescribeLoadBalancerAttributesInput: S.Schema<DescribeLoadBalancerAttributesInput>;
export type CrossZoneLoadBalancingEnabled = boolean;
export interface CrossZoneLoadBalancing {
    Enabled: boolean;
}
export declare const CrossZoneLoadBalancing: S.Schema<CrossZoneLoadBalancing>;
export type AccessLogEnabled = boolean;
export type S3BucketName = string;
export type AccessLogInterval = number;
export type AccessLogPrefix = string;
export interface AccessLog {
    Enabled: boolean;
    S3BucketName?: string;
    EmitInterval?: number;
    S3BucketPrefix?: string;
}
export declare const AccessLog: S.Schema<AccessLog>;
export type ConnectionDrainingEnabled = boolean;
export type ConnectionDrainingTimeout = number;
export interface ConnectionDraining {
    Enabled: boolean;
    Timeout?: number;
}
export declare const ConnectionDraining: S.Schema<ConnectionDraining>;
export type IdleTimeout = number;
export interface ConnectionSettings {
    IdleTimeout: number;
}
export declare const ConnectionSettings: S.Schema<ConnectionSettings>;
export type AdditionalAttributeKey = string;
export type AdditionalAttributeValue = string;
export interface AdditionalAttribute {
    Key?: string;
    Value?: string;
}
export declare const AdditionalAttribute: S.Schema<AdditionalAttribute>;
export type AdditionalAttributes = AdditionalAttribute[];
export declare const AdditionalAttributes: any;
export interface LoadBalancerAttributes {
    CrossZoneLoadBalancing?: CrossZoneLoadBalancing;
    AccessLog?: AccessLog;
    ConnectionDraining?: ConnectionDraining;
    ConnectionSettings?: ConnectionSettings;
    AdditionalAttributes?: AdditionalAttribute[];
}
export declare const LoadBalancerAttributes: S.Schema<LoadBalancerAttributes>;
export interface DescribeLoadBalancerAttributesOutput {
    LoadBalancerAttributes?: LoadBalancerAttributes;
}
export declare const DescribeLoadBalancerAttributesOutput: S.Schema<DescribeLoadBalancerAttributesOutput>;
export type PolicyNames = string[];
export declare const PolicyNames: any;
export interface DescribeLoadBalancerPoliciesInput {
    LoadBalancerName?: string;
    PolicyNames?: string[];
}
export declare const DescribeLoadBalancerPoliciesInput: S.Schema<DescribeLoadBalancerPoliciesInput>;
export interface PolicyAttributeDescription {
    AttributeName?: string;
    AttributeValue?: string;
}
export declare const PolicyAttributeDescription: S.Schema<PolicyAttributeDescription>;
export type PolicyAttributeDescriptions = PolicyAttributeDescription[];
export declare const PolicyAttributeDescriptions: any;
export interface PolicyDescription {
    PolicyName?: string;
    PolicyTypeName?: string;
    PolicyAttributeDescriptions?: PolicyAttributeDescription[];
}
export declare const PolicyDescription: S.Schema<PolicyDescription>;
export type PolicyDescriptions = PolicyDescription[];
export declare const PolicyDescriptions: any;
export interface DescribeLoadBalancerPoliciesOutput {
    PolicyDescriptions?: PolicyDescription[];
}
export declare const DescribeLoadBalancerPoliciesOutput: S.Schema<DescribeLoadBalancerPoliciesOutput>;
export type PolicyTypeNames = string[];
export declare const PolicyTypeNames: any;
export interface DescribeLoadBalancerPolicyTypesInput {
    PolicyTypeNames?: string[];
}
export declare const DescribeLoadBalancerPolicyTypesInput: S.Schema<DescribeLoadBalancerPolicyTypesInput>;
export type AttributeType = string;
export type DefaultValue = string;
export type Cardinality = string;
export interface PolicyAttributeTypeDescription {
    AttributeName?: string;
    AttributeType?: string;
    Description?: string;
    DefaultValue?: string;
    Cardinality?: string;
}
export declare const PolicyAttributeTypeDescription: S.Schema<PolicyAttributeTypeDescription>;
export type PolicyAttributeTypeDescriptions = PolicyAttributeTypeDescription[];
export declare const PolicyAttributeTypeDescriptions: any;
export interface PolicyTypeDescription {
    PolicyTypeName?: string;
    Description?: string;
    PolicyAttributeTypeDescriptions?: PolicyAttributeTypeDescription[];
}
export declare const PolicyTypeDescription: S.Schema<PolicyTypeDescription>;
export type PolicyTypeDescriptions = PolicyTypeDescription[];
export declare const PolicyTypeDescriptions: any;
export interface DescribeLoadBalancerPolicyTypesOutput {
    PolicyTypeDescriptions?: PolicyTypeDescription[];
}
export declare const DescribeLoadBalancerPolicyTypesOutput: S.Schema<DescribeLoadBalancerPolicyTypesOutput>;
export interface DescribeAccessPointsInput {
    LoadBalancerNames?: string[];
    Marker?: string;
    PageSize?: number;
}
export declare const DescribeAccessPointsInput: S.Schema<DescribeAccessPointsInput>;
export interface ListenerDescription {
    Listener?: Listener;
    PolicyNames?: string[];
}
export declare const ListenerDescription: S.Schema<ListenerDescription>;
export type ListenerDescriptions = ListenerDescription[];
export declare const ListenerDescriptions: any;
export interface AppCookieStickinessPolicy {
    PolicyName?: string;
    CookieName?: string;
}
export declare const AppCookieStickinessPolicy: S.Schema<AppCookieStickinessPolicy>;
export type AppCookieStickinessPolicies = AppCookieStickinessPolicy[];
export declare const AppCookieStickinessPolicies: any;
export interface LBCookieStickinessPolicy {
    PolicyName?: string;
    CookieExpirationPeriod?: number;
}
export declare const LBCookieStickinessPolicy: S.Schema<LBCookieStickinessPolicy>;
export type LBCookieStickinessPolicies = LBCookieStickinessPolicy[];
export declare const LBCookieStickinessPolicies: any;
export interface Policies {
    AppCookieStickinessPolicies?: AppCookieStickinessPolicy[];
    LBCookieStickinessPolicies?: LBCookieStickinessPolicy[];
    OtherPolicies?: string[];
}
export declare const Policies: S.Schema<Policies>;
export interface BackendServerDescription {
    InstancePort?: number;
    PolicyNames?: string[];
}
export declare const BackendServerDescription: S.Schema<BackendServerDescription>;
export type BackendServerDescriptions = BackendServerDescription[];
export declare const BackendServerDescriptions: any;
export type VPCId = string;
export type SecurityGroupOwnerAlias = string;
export type SecurityGroupName = string;
export interface SourceSecurityGroup {
    OwnerAlias?: string;
    GroupName?: string;
}
export declare const SourceSecurityGroup: S.Schema<SourceSecurityGroup>;
export type CreatedTime = Date;
export interface LoadBalancerDescription {
    LoadBalancerName?: string;
    DNSName?: string;
    CanonicalHostedZoneName?: string;
    CanonicalHostedZoneNameID?: string;
    ListenerDescriptions?: ListenerDescription[];
    Policies?: Policies;
    BackendServerDescriptions?: BackendServerDescription[];
    AvailabilityZones?: string[];
    Subnets?: string[];
    VPCId?: string;
    Instances?: Instance[];
    HealthCheck?: HealthCheck;
    SourceSecurityGroup?: SourceSecurityGroup;
    SecurityGroups?: string[];
    CreatedTime?: Date;
    Scheme?: string;
}
export declare const LoadBalancerDescription: S.Schema<LoadBalancerDescription>;
export type LoadBalancerDescriptions = LoadBalancerDescription[];
export declare const LoadBalancerDescriptions: any;
export interface DescribeAccessPointsOutput {
    LoadBalancerDescriptions?: LoadBalancerDescription[];
    NextMarker?: string;
}
export declare const DescribeAccessPointsOutput: S.Schema<DescribeAccessPointsOutput>;
export type LoadBalancerNamesMax20 = string[];
export declare const LoadBalancerNamesMax20: any;
export interface DescribeTagsInput {
    LoadBalancerNames: string[];
}
export declare const DescribeTagsInput: S.Schema<DescribeTagsInput>;
export interface TagDescription {
    LoadBalancerName?: string;
    Tags?: Tag[];
}
export declare const TagDescription: S.Schema<TagDescription>;
export type TagDescriptions = TagDescription[];
export declare const TagDescriptions: any;
export interface DescribeTagsOutput {
    TagDescriptions?: TagDescription[];
}
export declare const DescribeTagsOutput: S.Schema<DescribeTagsOutput>;
export interface DetachLoadBalancerFromSubnetsInput {
    LoadBalancerName: string;
    Subnets: string[];
}
export declare const DetachLoadBalancerFromSubnetsInput: S.Schema<DetachLoadBalancerFromSubnetsInput>;
export interface DetachLoadBalancerFromSubnetsOutput {
    Subnets?: string[];
}
export declare const DetachLoadBalancerFromSubnetsOutput: S.Schema<DetachLoadBalancerFromSubnetsOutput>;
export interface RemoveAvailabilityZonesInput {
    LoadBalancerName: string;
    AvailabilityZones: string[];
}
export declare const RemoveAvailabilityZonesInput: S.Schema<RemoveAvailabilityZonesInput>;
export interface RemoveAvailabilityZonesOutput {
    AvailabilityZones?: string[];
}
export declare const RemoveAvailabilityZonesOutput: S.Schema<RemoveAvailabilityZonesOutput>;
export interface AddAvailabilityZonesInput {
    LoadBalancerName: string;
    AvailabilityZones: string[];
}
export declare const AddAvailabilityZonesInput: S.Schema<AddAvailabilityZonesInput>;
export interface AddAvailabilityZonesOutput {
    AvailabilityZones?: string[];
}
export declare const AddAvailabilityZonesOutput: S.Schema<AddAvailabilityZonesOutput>;
export interface ModifyLoadBalancerAttributesInput {
    LoadBalancerName: string;
    LoadBalancerAttributes: LoadBalancerAttributes;
}
export declare const ModifyLoadBalancerAttributesInput: S.Schema<ModifyLoadBalancerAttributesInput>;
export interface ModifyLoadBalancerAttributesOutput {
    LoadBalancerName?: string;
    LoadBalancerAttributes?: LoadBalancerAttributes;
}
export declare const ModifyLoadBalancerAttributesOutput: S.Schema<ModifyLoadBalancerAttributesOutput>;
export interface RegisterEndPointsInput {
    LoadBalancerName: string;
    Instances: Instance[];
}
export declare const RegisterEndPointsInput: S.Schema<RegisterEndPointsInput>;
export interface RegisterEndPointsOutput {
    Instances?: Instance[];
}
export declare const RegisterEndPointsOutput: S.Schema<RegisterEndPointsOutput>;
export interface TagKeyOnly {
    Key?: string;
}
export declare const TagKeyOnly: S.Schema<TagKeyOnly>;
export type TagKeyList = TagKeyOnly[];
export declare const TagKeyList: any;
export interface RemoveTagsInput {
    LoadBalancerNames: string[];
    Tags: TagKeyOnly[];
}
export declare const RemoveTagsInput: S.Schema<RemoveTagsInput>;
export interface RemoveTagsOutput {
}
export declare const RemoveTagsOutput: S.Schema<RemoveTagsOutput>;
export interface SetLoadBalancerListenerSSLCertificateInput {
    LoadBalancerName: string;
    LoadBalancerPort: number;
    SSLCertificateId: string;
}
export declare const SetLoadBalancerListenerSSLCertificateInput: S.Schema<SetLoadBalancerListenerSSLCertificateInput>;
export interface SetLoadBalancerListenerSSLCertificateOutput {
}
export declare const SetLoadBalancerListenerSSLCertificateOutput: S.Schema<SetLoadBalancerListenerSSLCertificateOutput>;
export type EndPointPort = number;
export interface SetLoadBalancerPoliciesForBackendServerInput {
    LoadBalancerName: string;
    InstancePort: number;
    PolicyNames: string[];
}
export declare const SetLoadBalancerPoliciesForBackendServerInput: S.Schema<SetLoadBalancerPoliciesForBackendServerInput>;
export interface SetLoadBalancerPoliciesForBackendServerOutput {
}
export declare const SetLoadBalancerPoliciesForBackendServerOutput: S.Schema<SetLoadBalancerPoliciesForBackendServerOutput>;
export interface SetLoadBalancerPoliciesOfListenerInput {
    LoadBalancerName: string;
    LoadBalancerPort: number;
    PolicyNames: string[];
}
export declare const SetLoadBalancerPoliciesOfListenerInput: S.Schema<SetLoadBalancerPoliciesOfListenerInput>;
export interface SetLoadBalancerPoliciesOfListenerOutput {
}
export declare const SetLoadBalancerPoliciesOfListenerOutput: S.Schema<SetLoadBalancerPoliciesOfListenerOutput>;
export type ErrorDescription = string;
export type AddTagsError = AccessPointNotFoundException | DuplicateTagKeysException | TooManyTagsException | CommonErrors;
/**
 * Adds the specified tags to the specified load balancer. Each load balancer can have a maximum of 10 tags.
 *
 * Each tag consists of a key and an optional value. If a tag with the same key is already associated
 * with the load balancer, `AddTags` updates its value.
 *
 * For more information, see Tag Your Classic Load Balancer
 * in the *Classic Load Balancers Guide*.
 */
export declare const addTags: API.OperationMethod<AddTagsInput, AddTagsOutput, AddTagsError, Credentials | HttpClient.HttpClient>;
export type ApplySecurityGroupsToLoadBalancerError = AccessPointNotFoundException | InvalidConfigurationRequestException | InvalidSecurityGroupException | CommonErrors;
/**
 * Associates one or more security groups with your load balancer in a virtual private cloud (VPC). The specified security groups override the previously associated security groups.
 *
 * For more information, see Security Groups for Load Balancers in a VPC
 * in the *Classic Load Balancers Guide*.
 */
export declare const applySecurityGroupsToLoadBalancer: API.OperationMethod<ApplySecurityGroupsToLoadBalancerInput, ApplySecurityGroupsToLoadBalancerOutput, ApplySecurityGroupsToLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type AttachLoadBalancerToSubnetsError = AccessPointNotFoundException | InvalidConfigurationRequestException | InvalidSubnetException | SubnetNotFoundException | CommonErrors;
/**
 * Adds one or more subnets to the set of configured subnets for the specified load balancer.
 *
 * The load balancer evenly distributes requests across all registered subnets.
 * For more information, see Add or Remove Subnets for Your Load Balancer in a VPC
 * in the *Classic Load Balancers Guide*.
 */
export declare const attachLoadBalancerToSubnets: API.OperationMethod<AttachLoadBalancerToSubnetsInput, AttachLoadBalancerToSubnetsOutput, AttachLoadBalancerToSubnetsError, Credentials | HttpClient.HttpClient>;
export type ConfigureHealthCheckError = AccessPointNotFoundException | CommonErrors;
/**
 * Specifies the health check settings to use when evaluating the health state of your EC2 instances.
 *
 * For more information, see Configure Health Checks for Your Load Balancer
 * in the *Classic Load Balancers Guide*.
 */
export declare const configureHealthCheck: API.OperationMethod<ConfigureHealthCheckInput, ConfigureHealthCheckOutput, ConfigureHealthCheckError, Credentials | HttpClient.HttpClient>;
export type CreateAppCookieStickinessPolicyError = AccessPointNotFoundException | DuplicatePolicyNameException | InvalidConfigurationRequestException | TooManyPoliciesException | CommonErrors;
/**
 * Generates a stickiness policy with sticky session lifetimes that follow that of an application-generated cookie. This policy can be associated only with HTTP/HTTPS listeners.
 *
 * This policy is similar to the policy created by CreateLBCookieStickinessPolicy,
 * except that the lifetime of the special Elastic Load Balancing cookie, `AWSELB`,
 * follows the lifetime of the application-generated cookie specified in the policy configuration.
 * The load balancer only inserts a new stickiness cookie when the application response
 * includes a new application cookie.
 *
 * If the application cookie is explicitly removed or expires, the session stops being sticky until a new application cookie is issued.
 *
 * For more information, see Application-Controlled Session Stickiness
 * in the *Classic Load Balancers Guide*.
 */
export declare const createAppCookieStickinessPolicy: API.OperationMethod<CreateAppCookieStickinessPolicyInput, CreateAppCookieStickinessPolicyOutput, CreateAppCookieStickinessPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateLBCookieStickinessPolicyError = AccessPointNotFoundException | DuplicatePolicyNameException | InvalidConfigurationRequestException | TooManyPoliciesException | CommonErrors;
/**
 * Generates a stickiness policy with sticky session lifetimes controlled by the lifetime of the browser (user-agent) or a specified expiration period. This policy can be associated only with HTTP/HTTPS listeners.
 *
 * When a load balancer implements this policy, the load balancer uses a special cookie to track the instance for each request. When the load balancer receives a request, it first checks to see if this cookie is present in the request.
 * If so, the load balancer sends the request to the application server specified in the cookie. If not, the load balancer sends the request to a server that is chosen based on the existing load-balancing algorithm.
 *
 * A cookie is inserted into the response for binding subsequent requests from the same user to that server. The validity of the cookie is based on the cookie expiration time, which is specified in the policy configuration.
 *
 * For more information, see Duration-Based Session Stickiness
 * in the *Classic Load Balancers Guide*.
 */
export declare const createLBCookieStickinessPolicy: API.OperationMethod<CreateLBCookieStickinessPolicyInput, CreateLBCookieStickinessPolicyOutput, CreateLBCookieStickinessPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateLoadBalancerError = CertificateNotFoundException | DuplicateAccessPointNameException | DuplicateTagKeysException | InvalidConfigurationRequestException | InvalidSchemeException | InvalidSecurityGroupException | InvalidSubnetException | OperationNotPermittedException | SubnetNotFoundException | TooManyAccessPointsException | TooManyTagsException | UnsupportedProtocolException | CommonErrors;
/**
 * Creates a Classic Load Balancer.
 *
 * You can add listeners, security groups, subnets, and tags when you create your load balancer,
 * or you can add them later using CreateLoadBalancerListeners,
 * ApplySecurityGroupsToLoadBalancer, AttachLoadBalancerToSubnets,
 * and AddTags.
 *
 * To describe your current load balancers, see DescribeLoadBalancers.
 * When you are finished with a load balancer, you can delete it using
 * DeleteLoadBalancer.
 *
 * You can create up to 20 load balancers per region per account.
 * You can request an increase for the number of load balancers for your account.
 * For more information, see Limits for Your Classic Load Balancer
 * in the *Classic Load Balancers Guide*.
 */
export declare const createLoadBalancer: API.OperationMethod<CreateAccessPointInput, CreateAccessPointOutput, CreateLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type CreateLoadBalancerListenersError = AccessPointNotFoundException | CertificateNotFoundException | DuplicateListenerException | InvalidConfigurationRequestException | UnsupportedProtocolException | CommonErrors;
/**
 * Creates one or more listeners for the specified load balancer. If a listener with the specified port does not already exist, it is created; otherwise, the properties of the new listener must match the properties of the existing listener.
 *
 * For more information, see Listeners for Your Classic Load Balancer
 * in the *Classic Load Balancers Guide*.
 */
export declare const createLoadBalancerListeners: API.OperationMethod<CreateLoadBalancerListenerInput, CreateLoadBalancerListenerOutput, CreateLoadBalancerListenersError, Credentials | HttpClient.HttpClient>;
export type CreateLoadBalancerPolicyError = AccessPointNotFoundException | DuplicatePolicyNameException | InvalidConfigurationRequestException | PolicyTypeNotFoundException | TooManyPoliciesException | CommonErrors;
/**
 * Creates a policy with the specified attributes for the specified load balancer.
 *
 * Policies are settings that are saved for your load balancer and that can be applied to the listener or the application server, depending on the policy type.
 */
export declare const createLoadBalancerPolicy: API.OperationMethod<CreateLoadBalancerPolicyInput, CreateLoadBalancerPolicyOutput, CreateLoadBalancerPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteLoadBalancerError = CommonErrors;
/**
 * Deletes the specified load balancer.
 *
 * If you are attempting to recreate a load balancer, you must reconfigure all settings. The DNS name associated with a deleted load balancer are no longer usable. The name and associated DNS record of the deleted load balancer no longer exist and traffic sent to any of its IP addresses is no longer delivered to your instances.
 *
 * If the load balancer does not exist or has already been deleted, the call to
 * `DeleteLoadBalancer` still succeeds.
 */
export declare const deleteLoadBalancer: API.OperationMethod<DeleteAccessPointInput, DeleteAccessPointOutput, DeleteLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type DeleteLoadBalancerListenersError = AccessPointNotFoundException | CommonErrors;
/**
 * Deletes the specified listeners from the specified load balancer.
 */
export declare const deleteLoadBalancerListeners: API.OperationMethod<DeleteLoadBalancerListenerInput, DeleteLoadBalancerListenerOutput, DeleteLoadBalancerListenersError, Credentials | HttpClient.HttpClient>;
export type DeleteLoadBalancerPolicyError = AccessPointNotFoundException | InvalidConfigurationRequestException | CommonErrors;
/**
 * Deletes the specified policy from the specified load balancer. This policy must not be enabled for any listeners.
 */
export declare const deleteLoadBalancerPolicy: API.OperationMethod<DeleteLoadBalancerPolicyInput, DeleteLoadBalancerPolicyOutput, DeleteLoadBalancerPolicyError, Credentials | HttpClient.HttpClient>;
export type DeregisterInstancesFromLoadBalancerError = AccessPointNotFoundException | InvalidEndPointException | CommonErrors;
/**
 * Deregisters the specified instances from the specified load balancer. After the instance is deregistered, it no longer receives traffic from the load balancer.
 *
 * You can use DescribeLoadBalancers to verify that the instance is deregistered from the load balancer.
 *
 * For more information, see Register or De-Register EC2 Instances
 * in the *Classic Load Balancers Guide*.
 */
export declare const deregisterInstancesFromLoadBalancer: API.OperationMethod<DeregisterEndPointsInput, DeregisterEndPointsOutput, DeregisterInstancesFromLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountLimitsError = CommonErrors;
/**
 * Describes the current Elastic Load Balancing resource limits for your AWS account.
 *
 * For more information, see Limits for Your Classic Load Balancer
 * in the *Classic Load Balancers Guide*.
 */
export declare const describeAccountLimits: API.OperationMethod<DescribeAccountLimitsInput, DescribeAccountLimitsOutput, DescribeAccountLimitsError, Credentials | HttpClient.HttpClient>;
export type DescribeInstanceHealthError = AccessPointNotFoundException | InvalidEndPointException | CommonErrors;
/**
 * Describes the state of the specified instances with respect to the specified load balancer. If no instances are specified, the call describes the state of all instances that are currently registered with the load balancer. If instances are specified, their state is returned even if they are no longer registered with the load balancer. The state of terminated instances is not returned.
 */
export declare const describeInstanceHealth: API.OperationMethod<DescribeEndPointStateInput, DescribeEndPointStateOutput, DescribeInstanceHealthError, Credentials | HttpClient.HttpClient>;
export type DescribeLoadBalancerAttributesError = AccessPointNotFoundException | LoadBalancerAttributeNotFoundException | CommonErrors;
/**
 * Describes the attributes for the specified load balancer.
 */
export declare const describeLoadBalancerAttributes: API.OperationMethod<DescribeLoadBalancerAttributesInput, DescribeLoadBalancerAttributesOutput, DescribeLoadBalancerAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeLoadBalancerPoliciesError = AccessPointNotFoundException | PolicyNotFoundException | CommonErrors;
/**
 * Describes the specified policies.
 *
 * If you specify a load balancer name, the action returns the descriptions of all policies created for the load balancer.
 * If you specify a policy name associated with your load balancer, the action returns the description of that policy.
 * If you don't specify a load balancer name, the action returns descriptions of the specified sample policies, or descriptions of all sample policies.
 * The names of the sample policies have the `ELBSample-` prefix.
 */
export declare const describeLoadBalancerPolicies: API.OperationMethod<DescribeLoadBalancerPoliciesInput, DescribeLoadBalancerPoliciesOutput, DescribeLoadBalancerPoliciesError, Credentials | HttpClient.HttpClient>;
export type DescribeLoadBalancerPolicyTypesError = PolicyTypeNotFoundException | CommonErrors;
/**
 * Describes the specified load balancer policy types or all load balancer policy types.
 *
 * The description of each type indicates how it can be used. For example,
 * some policies can be used only with layer 7 listeners,
 * some policies can be used only with layer 4 listeners,
 * and some policies can be used only with your EC2 instances.
 *
 * You can use CreateLoadBalancerPolicy to create a policy configuration for any of these policy types.
 * Then, depending on the policy type, use either SetLoadBalancerPoliciesOfListener or
 * SetLoadBalancerPoliciesForBackendServer to set the policy.
 */
export declare const describeLoadBalancerPolicyTypes: API.OperationMethod<DescribeLoadBalancerPolicyTypesInput, DescribeLoadBalancerPolicyTypesOutput, DescribeLoadBalancerPolicyTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeLoadBalancersError = AccessPointNotFoundException | DependencyThrottleException | CommonErrors;
/**
 * Describes the specified the load balancers. If no load balancers are specified, the call describes all of your load balancers.
 */
export declare const describeLoadBalancers: API.PaginatedOperationMethod<DescribeAccessPointsInput, DescribeAccessPointsOutput, DescribeLoadBalancersError, Credentials | HttpClient.HttpClient, LoadBalancerDescription>;
export type DescribeTagsError = AccessPointNotFoundException | CommonErrors;
/**
 * Describes the tags associated with the specified load balancers.
 */
export declare const describeTags: API.OperationMethod<DescribeTagsInput, DescribeTagsOutput, DescribeTagsError, Credentials | HttpClient.HttpClient>;
export type DetachLoadBalancerFromSubnetsError = AccessPointNotFoundException | InvalidConfigurationRequestException | CommonErrors;
/**
 * Removes the specified subnets from the set of configured subnets for the load balancer.
 *
 * After a subnet is removed, all EC2 instances registered with the load balancer
 * in the removed subnet go into the `OutOfService` state. Then,
 * the load balancer balances the traffic among the remaining routable subnets.
 */
export declare const detachLoadBalancerFromSubnets: API.OperationMethod<DetachLoadBalancerFromSubnetsInput, DetachLoadBalancerFromSubnetsOutput, DetachLoadBalancerFromSubnetsError, Credentials | HttpClient.HttpClient>;
export type DisableAvailabilityZonesForLoadBalancerError = AccessPointNotFoundException | InvalidConfigurationRequestException | CommonErrors;
/**
 * Removes the specified Availability Zones from the set of Availability Zones for the specified load balancer
 * in EC2-Classic or a default VPC.
 *
 * For load balancers in a non-default VPC, use DetachLoadBalancerFromSubnets.
 *
 * There must be at least one Availability Zone registered with a load balancer at all times.
 * After an Availability Zone is removed, all instances registered with the load balancer that are in the removed
 * Availability Zone go into the `OutOfService` state. Then, the load balancer attempts to equally balance
 * the traffic among its remaining Availability Zones.
 *
 * For more information, see Add or Remove Availability Zones
 * in the *Classic Load Balancers Guide*.
 */
export declare const disableAvailabilityZonesForLoadBalancer: API.OperationMethod<RemoveAvailabilityZonesInput, RemoveAvailabilityZonesOutput, DisableAvailabilityZonesForLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type EnableAvailabilityZonesForLoadBalancerError = AccessPointNotFoundException | CommonErrors;
/**
 * Adds the specified Availability Zones to the set of Availability Zones for the specified load balancer
 * in EC2-Classic or a default VPC.
 *
 * For load balancers in a non-default VPC, use AttachLoadBalancerToSubnets.
 *
 * The load balancer evenly distributes requests across all its registered Availability Zones
 * that contain instances. For more information, see Add or Remove Availability Zones
 * in the *Classic Load Balancers Guide*.
 */
export declare const enableAvailabilityZonesForLoadBalancer: API.OperationMethod<AddAvailabilityZonesInput, AddAvailabilityZonesOutput, EnableAvailabilityZonesForLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type ModifyLoadBalancerAttributesError = AccessPointNotFoundException | InvalidConfigurationRequestException | LoadBalancerAttributeNotFoundException | CommonErrors;
/**
 * Modifies the attributes of the specified load balancer.
 *
 * You can modify the load balancer attributes, such as `AccessLogs`, `ConnectionDraining`, and
 * `CrossZoneLoadBalancing` by either enabling or disabling them. Or, you can modify the load balancer attribute
 * `ConnectionSettings` by specifying an idle connection timeout value for your load balancer.
 *
 * For more information, see the following in the *Classic Load Balancers Guide*:
 *
 * - Cross-Zone Load Balancing
 *
 * - Connection Draining
 *
 * - Access Logs
 *
 * - Idle Connection Timeout
 */
export declare const modifyLoadBalancerAttributes: API.OperationMethod<ModifyLoadBalancerAttributesInput, ModifyLoadBalancerAttributesOutput, ModifyLoadBalancerAttributesError, Credentials | HttpClient.HttpClient>;
export type RegisterInstancesWithLoadBalancerError = AccessPointNotFoundException | InvalidEndPointException | CommonErrors;
/**
 * Adds the specified instances to the specified load balancer.
 *
 * The instance must be a running instance in the same network as the load balancer (EC2-Classic or the same VPC). If you have EC2-Classic instances and a load balancer in a VPC with ClassicLink enabled, you can link the EC2-Classic instances to that VPC and then register the linked EC2-Classic instances with the load balancer in the VPC.
 *
 * Note that `RegisterInstanceWithLoadBalancer` completes when the request has been registered.
 * Instance registration takes a little time to complete. To check the state of the registered instances, use
 * DescribeLoadBalancers or DescribeInstanceHealth.
 *
 * After the instance is registered, it starts receiving traffic
 * and requests from the load balancer. Any instance that is not
 * in one of the Availability Zones registered for the load balancer
 * is moved to the `OutOfService` state. If an Availability Zone
 * is added to the load balancer later, any instances registered with the
 * load balancer move to the `InService` state.
 *
 * To deregister instances from a load balancer, use DeregisterInstancesFromLoadBalancer.
 *
 * For more information, see Register or De-Register EC2 Instances
 * in the *Classic Load Balancers Guide*.
 */
export declare const registerInstancesWithLoadBalancer: API.OperationMethod<RegisterEndPointsInput, RegisterEndPointsOutput, RegisterInstancesWithLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsError = AccessPointNotFoundException | CommonErrors;
/**
 * Removes one or more tags from the specified load balancer.
 */
export declare const removeTags: API.OperationMethod<RemoveTagsInput, RemoveTagsOutput, RemoveTagsError, Credentials | HttpClient.HttpClient>;
export type SetLoadBalancerListenerSSLCertificateError = AccessPointNotFoundException | CertificateNotFoundException | InvalidConfigurationRequestException | ListenerNotFoundException | UnsupportedProtocolException | CommonErrors;
/**
 * Sets the certificate that terminates the specified listener's SSL connections. The specified certificate replaces any prior certificate that was used on the same load balancer and port.
 *
 * For more information about updating your SSL certificate, see
 * Replace the SSL Certificate for Your Load Balancer
 * in the *Classic Load Balancers Guide*.
 */
export declare const setLoadBalancerListenerSSLCertificate: API.OperationMethod<SetLoadBalancerListenerSSLCertificateInput, SetLoadBalancerListenerSSLCertificateOutput, SetLoadBalancerListenerSSLCertificateError, Credentials | HttpClient.HttpClient>;
export type SetLoadBalancerPoliciesForBackendServerError = AccessPointNotFoundException | InvalidConfigurationRequestException | PolicyNotFoundException | CommonErrors;
/**
 * Replaces the set of policies associated with the specified port on which the EC2 instance is listening with a new set of policies.
 * At this time, only the back-end server authentication policy type can be applied to the instance ports; this policy type is composed of multiple public key policies.
 *
 * Each time you use `SetLoadBalancerPoliciesForBackendServer` to enable the policies,
 * use the `PolicyNames` parameter to list the policies that you want to enable.
 *
 * You can use DescribeLoadBalancers or DescribeLoadBalancerPolicies to verify that the policy
 * is associated with the EC2 instance.
 *
 * For more information about enabling back-end instance authentication, see Configure Back-end Instance Authentication
 * in the *Classic Load Balancers Guide*. For more information about Proxy Protocol, see
 * Configure Proxy Protocol Support
 * in the *Classic Load Balancers Guide*.
 */
export declare const setLoadBalancerPoliciesForBackendServer: API.OperationMethod<SetLoadBalancerPoliciesForBackendServerInput, SetLoadBalancerPoliciesForBackendServerOutput, SetLoadBalancerPoliciesForBackendServerError, Credentials | HttpClient.HttpClient>;
export type SetLoadBalancerPoliciesOfListenerError = AccessPointNotFoundException | InvalidConfigurationRequestException | ListenerNotFoundException | PolicyNotFoundException | CommonErrors;
/**
 * Replaces the current set of policies for the specified load balancer port with the specified set of policies.
 *
 * To enable back-end server authentication, use SetLoadBalancerPoliciesForBackendServer.
 *
 * For more information about setting policies, see
 * Update the SSL Negotiation Configuration,
 * Duration-Based Session Stickiness, and
 * Application-Controlled Session Stickiness
 * in the *Classic Load Balancers Guide*.
 */
export declare const setLoadBalancerPoliciesOfListener: API.OperationMethod<SetLoadBalancerPoliciesOfListenerInput, SetLoadBalancerPoliciesOfListenerOutput, SetLoadBalancerPoliciesOfListenerError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=elastic-load-balancing.d.ts.map