import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.Class<ForbiddenException, S.TaggedStruct<"ForbiddenException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceLimitExceededException_base: S.Class<ResourceLimitExceededException, S.TaggedStruct<"ResourceLimitExceededException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ServiceFailureException_base: S.Class<ServiceFailureException, S.TaggedStruct<"ServiceFailureException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceFailureException extends /*@__PURE__*/ ServiceFailureException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottledClientException_base: S.Class<ThrottledClientException, S.TaggedStruct<"ThrottledClientException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottledClientException extends /*@__PURE__*/ ThrottledClientException_base {
}
declare const UnauthorizedClientException_base: S.Class<UnauthorizedClientException, S.TaggedStruct<"UnauthorizedClientException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedClientException extends /*@__PURE__*/ UnauthorizedClientException_base {
}
export type MediaPipelineSourceType = "ChimeSdkMeeting" | (string & {});
export declare const MediaPipelineSourceType: any;
export type Arn = string | redacted.Redacted<string>;
export type MediaPipelineSinkType = "S3Bucket" | (string & {});
export declare const MediaPipelineSinkType: any;
export type ClientRequestToken = string | redacted.Redacted<string>;
export type GuidString = string;
export type AttendeeIdList = string[];
export declare const AttendeeIdList: any;
export type ExternalUserIdType = string | redacted.Redacted<string>;
export type ExternalUserIdList = (string | redacted.Redacted<string>)[];
export declare const ExternalUserIdList: any;
export interface SelectedVideoStreams {
    AttendeeIds?: string[];
    ExternalUserIds?: (string | redacted.Redacted<string>)[];
}
export declare const SelectedVideoStreams: S.Schema<SelectedVideoStreams>;
export interface SourceConfiguration {
    SelectedVideoStreams?: SelectedVideoStreams;
}
export declare const SourceConfiguration: S.Schema<SourceConfiguration>;
export type AudioMuxType = "AudioOnly" | "AudioWithActiveSpeakerVideo" | "AudioWithCompositedVideo" | (string & {});
export declare const AudioMuxType: any;
export interface AudioArtifactsConfiguration {
    MuxType: AudioMuxType;
}
export declare const AudioArtifactsConfiguration: S.Schema<AudioArtifactsConfiguration>;
export type ArtifactsState = "Enabled" | "Disabled" | (string & {});
export declare const ArtifactsState: any;
export type VideoMuxType = "VideoOnly" | (string & {});
export declare const VideoMuxType: any;
export interface VideoArtifactsConfiguration {
    State: ArtifactsState;
    MuxType?: VideoMuxType;
}
export declare const VideoArtifactsConfiguration: S.Schema<VideoArtifactsConfiguration>;
export type ContentMuxType = "ContentOnly" | (string & {});
export declare const ContentMuxType: any;
export interface ContentArtifactsConfiguration {
    State: ArtifactsState;
    MuxType?: ContentMuxType;
}
export declare const ContentArtifactsConfiguration: S.Schema<ContentArtifactsConfiguration>;
export type LayoutOption = "GridView" | (string & {});
export declare const LayoutOption: any;
export type ResolutionOption = "HD" | "FHD" | (string & {});
export declare const ResolutionOption: any;
export type ContentShareLayoutOption = "PresenterOnly" | "Horizontal" | "Vertical" | "ActiveSpeakerOnly" | (string & {});
export declare const ContentShareLayoutOption: any;
export type PresenterPosition = "TopLeft" | "TopRight" | "BottomLeft" | "BottomRight" | (string & {});
export declare const PresenterPosition: any;
export interface PresenterOnlyConfiguration {
    PresenterPosition?: PresenterPosition;
}
export declare const PresenterOnlyConfiguration: S.Schema<PresenterOnlyConfiguration>;
export type ActiveSpeakerPosition = "TopLeft" | "TopRight" | "BottomLeft" | "BottomRight" | (string & {});
export declare const ActiveSpeakerPosition: any;
export interface ActiveSpeakerOnlyConfiguration {
    ActiveSpeakerPosition?: ActiveSpeakerPosition;
}
export declare const ActiveSpeakerOnlyConfiguration: S.Schema<ActiveSpeakerOnlyConfiguration>;
export type TileOrder = "JoinSequence" | "SpeakerSequence" | (string & {});
export declare const TileOrder: any;
export type HorizontalTilePosition = "Top" | "Bottom" | (string & {});
export declare const HorizontalTilePosition: any;
export type TileCount = number;
export type TileAspectRatio = string;
export interface HorizontalLayoutConfiguration {
    TileOrder?: TileOrder;
    TilePosition?: HorizontalTilePosition;
    TileCount?: number;
    TileAspectRatio?: string;
}
export declare const HorizontalLayoutConfiguration: S.Schema<HorizontalLayoutConfiguration>;
export type VerticalTilePosition = "Left" | "Right" | (string & {});
export declare const VerticalTilePosition: any;
export interface VerticalLayoutConfiguration {
    TileOrder?: TileOrder;
    TilePosition?: VerticalTilePosition;
    TileCount?: number;
    TileAspectRatio?: string;
}
export declare const VerticalLayoutConfiguration: S.Schema<VerticalLayoutConfiguration>;
export type CornerRadius = number;
export type BorderColor = "Black" | "Blue" | "Red" | "Green" | "White" | "Yellow" | (string & {});
export declare const BorderColor: any;
export type HighlightColor = "Black" | "Blue" | "Red" | "Green" | "White" | "Yellow" | (string & {});
export declare const HighlightColor: any;
export type BorderThickness = number;
export interface VideoAttribute {
    CornerRadius?: number;
    BorderColor?: BorderColor;
    HighlightColor?: HighlightColor;
    BorderThickness?: number;
}
export declare const VideoAttribute: S.Schema<VideoAttribute>;
export type CanvasOrientation = "Landscape" | "Portrait" | (string & {});
export declare const CanvasOrientation: any;
export interface GridViewConfiguration {
    ContentShareLayout: ContentShareLayoutOption;
    PresenterOnlyConfiguration?: PresenterOnlyConfiguration;
    ActiveSpeakerOnlyConfiguration?: ActiveSpeakerOnlyConfiguration;
    HorizontalLayoutConfiguration?: HorizontalLayoutConfiguration;
    VerticalLayoutConfiguration?: VerticalLayoutConfiguration;
    VideoAttribute?: VideoAttribute;
    CanvasOrientation?: CanvasOrientation;
}
export declare const GridViewConfiguration: S.Schema<GridViewConfiguration>;
export interface CompositedVideoArtifactsConfiguration {
    Layout?: LayoutOption;
    Resolution?: ResolutionOption;
    GridViewConfiguration: GridViewConfiguration;
}
export declare const CompositedVideoArtifactsConfiguration: S.Schema<CompositedVideoArtifactsConfiguration>;
export interface ArtifactsConfiguration {
    Audio: AudioArtifactsConfiguration;
    Video: VideoArtifactsConfiguration;
    Content: ContentArtifactsConfiguration;
    CompositedVideo?: CompositedVideoArtifactsConfiguration;
}
export declare const ArtifactsConfiguration: S.Schema<ArtifactsConfiguration>;
export interface ChimeSdkMeetingConfiguration {
    SourceConfiguration?: SourceConfiguration;
    ArtifactsConfiguration?: ArtifactsConfiguration;
}
export declare const ChimeSdkMeetingConfiguration: S.Schema<ChimeSdkMeetingConfiguration>;
export interface SseAwsKeyManagementParams {
    AwsKmsKeyId: string;
    AwsKmsEncryptionContext?: string;
}
export declare const SseAwsKeyManagementParams: S.Schema<SseAwsKeyManagementParams>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateMediaCapturePipelineRequest {
    SourceType: MediaPipelineSourceType;
    SourceArn: string | redacted.Redacted<string>;
    SinkType: MediaPipelineSinkType;
    SinkArn: string | redacted.Redacted<string>;
    ClientRequestToken?: string | redacted.Redacted<string>;
    ChimeSdkMeetingConfiguration?: ChimeSdkMeetingConfiguration;
    SseAwsKeyManagementParams?: SseAwsKeyManagementParams;
    SinkIamRoleArn?: string | redacted.Redacted<string>;
    Tags?: Tag[];
}
export declare const CreateMediaCapturePipelineRequest: S.Schema<CreateMediaCapturePipelineRequest>;
export type AmazonResourceName = string;
export type MediaPipelineStatus = "Initializing" | "InProgress" | "Failed" | "Stopping" | "Stopped" | "Paused" | "NotStarted" | (string & {});
export declare const MediaPipelineStatus: any;
export type Iso8601Timestamp = Date;
export interface MediaCapturePipeline {
    MediaPipelineId?: string;
    MediaPipelineArn?: string;
    SourceType?: MediaPipelineSourceType;
    SourceArn?: string | redacted.Redacted<string>;
    Status?: MediaPipelineStatus;
    SinkType?: MediaPipelineSinkType;
    SinkArn?: string | redacted.Redacted<string>;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    ChimeSdkMeetingConfiguration?: ChimeSdkMeetingConfiguration;
    SseAwsKeyManagementParams?: SseAwsKeyManagementParams;
    SinkIamRoleArn?: string | redacted.Redacted<string>;
}
export declare const MediaCapturePipeline: S.Schema<MediaCapturePipeline>;
export interface CreateMediaCapturePipelineResponse {
    MediaCapturePipeline?: MediaCapturePipeline;
}
export declare const CreateMediaCapturePipelineResponse: S.Schema<CreateMediaCapturePipelineResponse>;
export type ConcatenationSourceType = "MediaCapturePipeline" | (string & {});
export declare const ConcatenationSourceType: any;
export type AudioArtifactsConcatenationState = "Enabled" | (string & {});
export declare const AudioArtifactsConcatenationState: any;
export interface AudioConcatenationConfiguration {
    State: AudioArtifactsConcatenationState;
}
export declare const AudioConcatenationConfiguration: S.Schema<AudioConcatenationConfiguration>;
export type ArtifactsConcatenationState = "Enabled" | "Disabled" | (string & {});
export declare const ArtifactsConcatenationState: any;
export interface VideoConcatenationConfiguration {
    State: ArtifactsConcatenationState;
}
export declare const VideoConcatenationConfiguration: S.Schema<VideoConcatenationConfiguration>;
export interface ContentConcatenationConfiguration {
    State: ArtifactsConcatenationState;
}
export declare const ContentConcatenationConfiguration: S.Schema<ContentConcatenationConfiguration>;
export interface DataChannelConcatenationConfiguration {
    State: ArtifactsConcatenationState;
}
export declare const DataChannelConcatenationConfiguration: S.Schema<DataChannelConcatenationConfiguration>;
export interface TranscriptionMessagesConcatenationConfiguration {
    State: ArtifactsConcatenationState;
}
export declare const TranscriptionMessagesConcatenationConfiguration: S.Schema<TranscriptionMessagesConcatenationConfiguration>;
export interface MeetingEventsConcatenationConfiguration {
    State: ArtifactsConcatenationState;
}
export declare const MeetingEventsConcatenationConfiguration: S.Schema<MeetingEventsConcatenationConfiguration>;
export interface CompositedVideoConcatenationConfiguration {
    State: ArtifactsConcatenationState;
}
export declare const CompositedVideoConcatenationConfiguration: S.Schema<CompositedVideoConcatenationConfiguration>;
export interface ArtifactsConcatenationConfiguration {
    Audio: AudioConcatenationConfiguration;
    Video: VideoConcatenationConfiguration;
    Content: ContentConcatenationConfiguration;
    DataChannel: DataChannelConcatenationConfiguration;
    TranscriptionMessages: TranscriptionMessagesConcatenationConfiguration;
    MeetingEvents: MeetingEventsConcatenationConfiguration;
    CompositedVideo: CompositedVideoConcatenationConfiguration;
}
export declare const ArtifactsConcatenationConfiguration: S.Schema<ArtifactsConcatenationConfiguration>;
export interface ChimeSdkMeetingConcatenationConfiguration {
    ArtifactsConfiguration: ArtifactsConcatenationConfiguration;
}
export declare const ChimeSdkMeetingConcatenationConfiguration: S.Schema<ChimeSdkMeetingConcatenationConfiguration>;
export interface MediaCapturePipelineSourceConfiguration {
    MediaPipelineArn: string | redacted.Redacted<string>;
    ChimeSdkMeetingConfiguration: ChimeSdkMeetingConcatenationConfiguration;
}
export declare const MediaCapturePipelineSourceConfiguration: S.Schema<MediaCapturePipelineSourceConfiguration>;
export interface ConcatenationSource {
    Type: ConcatenationSourceType;
    MediaCapturePipelineSourceConfiguration: MediaCapturePipelineSourceConfiguration;
}
export declare const ConcatenationSource: S.Schema<ConcatenationSource>;
export type ConcatenationSourceList = ConcatenationSource[];
export declare const ConcatenationSourceList: any;
export type ConcatenationSinkType = "S3Bucket" | (string & {});
export declare const ConcatenationSinkType: any;
export interface S3BucketSinkConfiguration {
    Destination: string | redacted.Redacted<string>;
}
export declare const S3BucketSinkConfiguration: S.Schema<S3BucketSinkConfiguration>;
export interface ConcatenationSink {
    Type: ConcatenationSinkType;
    S3BucketSinkConfiguration: S3BucketSinkConfiguration;
}
export declare const ConcatenationSink: S.Schema<ConcatenationSink>;
export type ConcatenationSinkList = ConcatenationSink[];
export declare const ConcatenationSinkList: any;
export interface CreateMediaConcatenationPipelineRequest {
    Sources: ConcatenationSource[];
    Sinks: ConcatenationSink[];
    ClientRequestToken?: string | redacted.Redacted<string>;
    Tags?: Tag[];
}
export declare const CreateMediaConcatenationPipelineRequest: S.Schema<CreateMediaConcatenationPipelineRequest>;
export interface MediaConcatenationPipeline {
    MediaPipelineId?: string;
    MediaPipelineArn?: string;
    Sources?: ConcatenationSource[];
    Sinks?: ConcatenationSink[];
    Status?: MediaPipelineStatus;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export declare const MediaConcatenationPipeline: S.Schema<MediaConcatenationPipeline>;
export interface CreateMediaConcatenationPipelineResponse {
    MediaConcatenationPipeline?: MediaConcatenationPipeline;
}
export declare const CreateMediaConcatenationPipelineResponse: S.Schema<CreateMediaConcatenationPipelineResponse>;
export type KinesisVideoStreamArn = string;
export type FragmentNumberString = string;
export type NumberOfChannels = number;
export type ChannelId = number;
export type ParticipantRole = "AGENT" | "CUSTOMER" | (string & {});
export declare const ParticipantRole: any;
export interface ChannelDefinition {
    ChannelId: number;
    ParticipantRole?: ParticipantRole;
}
export declare const ChannelDefinition: S.Schema<ChannelDefinition>;
export type ChannelDefinitions = ChannelDefinition[];
export declare const ChannelDefinitions: any;
export interface StreamChannelDefinition {
    NumberOfChannels: number;
    ChannelDefinitions?: ChannelDefinition[];
}
export declare const StreamChannelDefinition: S.Schema<StreamChannelDefinition>;
export interface StreamConfiguration {
    StreamArn: string;
    FragmentNumber?: string;
    StreamChannelDefinition: StreamChannelDefinition;
}
export declare const StreamConfiguration: S.Schema<StreamConfiguration>;
export type Streams = StreamConfiguration[];
export declare const Streams: any;
export type MediaEncoding = "pcm" | (string & {});
export declare const MediaEncoding: any;
export type MediaSampleRateHertz = number;
export interface KinesisVideoStreamSourceRuntimeConfiguration {
    Streams: StreamConfiguration[];
    MediaEncoding: MediaEncoding;
    MediaSampleRate: number;
}
export declare const KinesisVideoStreamSourceRuntimeConfiguration: S.Schema<KinesisVideoStreamSourceRuntimeConfiguration>;
export type NonEmptyString = string;
export type MediaInsightsRuntimeMetadata = {
    [key: string]: string | undefined;
};
export declare const MediaInsightsRuntimeMetadata: any;
export interface RecordingStreamConfiguration {
    StreamArn?: string;
}
export declare const RecordingStreamConfiguration: S.Schema<RecordingStreamConfiguration>;
export type RecordingStreamList = RecordingStreamConfiguration[];
export declare const RecordingStreamList: any;
export type FragmentSelectorType = "ProducerTimestamp" | "ServerTimestamp" | (string & {});
export declare const FragmentSelectorType: any;
export interface TimestampRange {
    StartTimestamp: Date;
    EndTimestamp: Date;
}
export declare const TimestampRange: S.Schema<TimestampRange>;
export interface FragmentSelector {
    FragmentSelectorType: FragmentSelectorType;
    TimestampRange: TimestampRange;
}
export declare const FragmentSelector: S.Schema<FragmentSelector>;
export interface KinesisVideoStreamRecordingSourceRuntimeConfiguration {
    Streams: RecordingStreamConfiguration[];
    FragmentSelector: FragmentSelector;
}
export declare const KinesisVideoStreamRecordingSourceRuntimeConfiguration: S.Schema<KinesisVideoStreamRecordingSourceRuntimeConfiguration>;
export type RecordingFileFormat = "Wav" | "Opus" | (string & {});
export declare const RecordingFileFormat: any;
export interface S3RecordingSinkRuntimeConfiguration {
    Destination: string | redacted.Redacted<string>;
    RecordingFileFormat: RecordingFileFormat;
}
export declare const S3RecordingSinkRuntimeConfiguration: S.Schema<S3RecordingSinkRuntimeConfiguration>;
export interface CreateMediaInsightsPipelineRequest {
    MediaInsightsPipelineConfigurationArn: string | redacted.Redacted<string>;
    KinesisVideoStreamSourceRuntimeConfiguration?: KinesisVideoStreamSourceRuntimeConfiguration;
    MediaInsightsRuntimeMetadata?: {
        [key: string]: string | undefined;
    };
    KinesisVideoStreamRecordingSourceRuntimeConfiguration?: KinesisVideoStreamRecordingSourceRuntimeConfiguration;
    S3RecordingSinkRuntimeConfiguration?: S3RecordingSinkRuntimeConfiguration;
    Tags?: Tag[];
    ClientRequestToken?: string | redacted.Redacted<string>;
}
export declare const CreateMediaInsightsPipelineRequest: S.Schema<CreateMediaInsightsPipelineRequest>;
export type MediaInsightsPipelineConfigurationElementType = "AmazonTranscribeCallAnalyticsProcessor" | "VoiceAnalyticsProcessor" | "AmazonTranscribeProcessor" | "KinesisDataStreamSink" | "LambdaFunctionSink" | "SqsQueueSink" | "SnsTopicSink" | "S3RecordingSink" | "VoiceEnhancementSink" | (string & {});
export declare const MediaInsightsPipelineConfigurationElementType: any;
export type MediaPipelineElementStatus = "NotStarted" | "NotSupported" | "Initializing" | "InProgress" | "Failed" | "Stopping" | "Stopped" | "Paused" | (string & {});
export declare const MediaPipelineElementStatus: any;
export interface MediaInsightsPipelineElementStatus {
    Type?: MediaInsightsPipelineConfigurationElementType;
    Status?: MediaPipelineElementStatus;
}
export declare const MediaInsightsPipelineElementStatus: S.Schema<MediaInsightsPipelineElementStatus>;
export type MediaInsightsPipelineElementStatuses = MediaInsightsPipelineElementStatus[];
export declare const MediaInsightsPipelineElementStatuses: any;
export interface MediaInsightsPipeline {
    MediaPipelineId?: string;
    MediaPipelineArn?: string | redacted.Redacted<string>;
    MediaInsightsPipelineConfigurationArn?: string | redacted.Redacted<string>;
    Status?: MediaPipelineStatus;
    KinesisVideoStreamSourceRuntimeConfiguration?: KinesisVideoStreamSourceRuntimeConfiguration;
    MediaInsightsRuntimeMetadata?: {
        [key: string]: string | undefined;
    };
    KinesisVideoStreamRecordingSourceRuntimeConfiguration?: KinesisVideoStreamRecordingSourceRuntimeConfiguration;
    S3RecordingSinkRuntimeConfiguration?: S3RecordingSinkRuntimeConfiguration;
    CreatedTimestamp?: Date;
    ElementStatuses?: MediaInsightsPipelineElementStatus[];
}
export declare const MediaInsightsPipeline: S.Schema<MediaInsightsPipeline>;
export interface CreateMediaInsightsPipelineResponse {
    MediaInsightsPipeline: MediaInsightsPipeline;
}
export declare const CreateMediaInsightsPipelineResponse: S.Schema<CreateMediaInsightsPipelineResponse>;
export type MediaInsightsPipelineConfigurationNameString = string;
export type RealTimeAlertRuleType = "KeywordMatch" | "Sentiment" | "IssueDetection" | (string & {});
export declare const RealTimeAlertRuleType: any;
export type RuleName = string;
export type Keyword = string;
export type KeywordMatchWordList = string[];
export declare const KeywordMatchWordList: any;
export interface KeywordMatchConfiguration {
    RuleName: string;
    Keywords: string[];
    Negate?: boolean;
}
export declare const KeywordMatchConfiguration: S.Schema<KeywordMatchConfiguration>;
export type SentimentType = "NEGATIVE" | (string & {});
export declare const SentimentType: any;
export type SentimentTimePeriodInSeconds = number;
export interface SentimentConfiguration {
    RuleName: string;
    SentimentType: SentimentType;
    TimePeriod: number;
}
export declare const SentimentConfiguration: S.Schema<SentimentConfiguration>;
export interface IssueDetectionConfiguration {
    RuleName: string;
}
export declare const IssueDetectionConfiguration: S.Schema<IssueDetectionConfiguration>;
export interface RealTimeAlertRule {
    Type: RealTimeAlertRuleType;
    KeywordMatchConfiguration?: KeywordMatchConfiguration;
    SentimentConfiguration?: SentimentConfiguration;
    IssueDetectionConfiguration?: IssueDetectionConfiguration;
}
export declare const RealTimeAlertRule: S.Schema<RealTimeAlertRule>;
export type RealTimeAlertRuleList = RealTimeAlertRule[];
export declare const RealTimeAlertRuleList: any;
export interface RealTimeAlertConfiguration {
    Disabled?: boolean;
    Rules?: RealTimeAlertRule[];
}
export declare const RealTimeAlertConfiguration: S.Schema<RealTimeAlertConfiguration>;
export type CallAnalyticsLanguageCode = "en-US" | "en-GB" | "es-US" | "fr-CA" | "fr-FR" | "en-AU" | "it-IT" | "de-DE" | "pt-BR" | (string & {});
export declare const CallAnalyticsLanguageCode: any;
export type VocabularyName = string;
export type VocabularyFilterName = string;
export type VocabularyFilterMethod = "remove" | "mask" | "tag" | (string & {});
export declare const VocabularyFilterMethod: any;
export type ModelName = string;
export type PartialResultsStability = "high" | "medium" | "low" | (string & {});
export declare const PartialResultsStability: any;
export type ContentType = "PII" | (string & {});
export declare const ContentType: any;
export type PiiEntityTypes = string;
export type ContentRedactionOutput = "redacted" | "redacted_and_unredacted" | (string & {});
export declare const ContentRedactionOutput: any;
export interface PostCallAnalyticsSettings {
    OutputLocation: string;
    DataAccessRoleArn: string;
    ContentRedactionOutput?: ContentRedactionOutput;
    OutputEncryptionKMSKeyId?: string;
}
export declare const PostCallAnalyticsSettings: S.Schema<PostCallAnalyticsSettings>;
export type CategoryName = string;
export type CategoryNameList = string[];
export declare const CategoryNameList: any;
export interface AmazonTranscribeCallAnalyticsProcessorConfiguration {
    LanguageCode: CallAnalyticsLanguageCode;
    VocabularyName?: string;
    VocabularyFilterName?: string;
    VocabularyFilterMethod?: VocabularyFilterMethod;
    LanguageModelName?: string;
    EnablePartialResultsStabilization?: boolean;
    PartialResultsStability?: PartialResultsStability;
    ContentIdentificationType?: ContentType;
    ContentRedactionType?: ContentType;
    PiiEntityTypes?: string;
    FilterPartialResults?: boolean;
    PostCallAnalyticsSettings?: PostCallAnalyticsSettings;
    CallAnalyticsStreamCategories?: string[];
}
export declare const AmazonTranscribeCallAnalyticsProcessorConfiguration: S.Schema<AmazonTranscribeCallAnalyticsProcessorConfiguration>;
export type LanguageOptions = string;
export type VocabularyNames = string;
export type VocabularyFilterNames = string;
export interface AmazonTranscribeProcessorConfiguration {
    LanguageCode?: CallAnalyticsLanguageCode;
    VocabularyName?: string;
    VocabularyFilterName?: string;
    VocabularyFilterMethod?: VocabularyFilterMethod;
    ShowSpeakerLabel?: boolean;
    EnablePartialResultsStabilization?: boolean;
    PartialResultsStability?: PartialResultsStability;
    ContentIdentificationType?: ContentType;
    ContentRedactionType?: ContentType;
    PiiEntityTypes?: string;
    LanguageModelName?: string;
    FilterPartialResults?: boolean;
    IdentifyLanguage?: boolean;
    IdentifyMultipleLanguages?: boolean;
    LanguageOptions?: string;
    PreferredLanguage?: CallAnalyticsLanguageCode;
    VocabularyNames?: string;
    VocabularyFilterNames?: string;
}
export declare const AmazonTranscribeProcessorConfiguration: S.Schema<AmazonTranscribeProcessorConfiguration>;
export interface KinesisDataStreamSinkConfiguration {
    InsightsTarget?: string | redacted.Redacted<string>;
}
export declare const KinesisDataStreamSinkConfiguration: S.Schema<KinesisDataStreamSinkConfiguration>;
export interface S3RecordingSinkConfiguration {
    Destination?: string | redacted.Redacted<string>;
    RecordingFileFormat?: RecordingFileFormat;
}
export declare const S3RecordingSinkConfiguration: S.Schema<S3RecordingSinkConfiguration>;
export type VoiceAnalyticsConfigurationStatus = "Enabled" | "Disabled" | (string & {});
export declare const VoiceAnalyticsConfigurationStatus: any;
export interface VoiceAnalyticsProcessorConfiguration {
    SpeakerSearchStatus?: VoiceAnalyticsConfigurationStatus;
    VoiceToneAnalysisStatus?: VoiceAnalyticsConfigurationStatus;
}
export declare const VoiceAnalyticsProcessorConfiguration: S.Schema<VoiceAnalyticsProcessorConfiguration>;
export interface LambdaFunctionSinkConfiguration {
    InsightsTarget?: string | redacted.Redacted<string>;
}
export declare const LambdaFunctionSinkConfiguration: S.Schema<LambdaFunctionSinkConfiguration>;
export interface SqsQueueSinkConfiguration {
    InsightsTarget?: string | redacted.Redacted<string>;
}
export declare const SqsQueueSinkConfiguration: S.Schema<SqsQueueSinkConfiguration>;
export interface SnsTopicSinkConfiguration {
    InsightsTarget?: string | redacted.Redacted<string>;
}
export declare const SnsTopicSinkConfiguration: S.Schema<SnsTopicSinkConfiguration>;
export interface VoiceEnhancementSinkConfiguration {
    Disabled?: boolean;
}
export declare const VoiceEnhancementSinkConfiguration: S.Schema<VoiceEnhancementSinkConfiguration>;
export interface MediaInsightsPipelineConfigurationElement {
    Type: MediaInsightsPipelineConfigurationElementType;
    AmazonTranscribeCallAnalyticsProcessorConfiguration?: AmazonTranscribeCallAnalyticsProcessorConfiguration;
    AmazonTranscribeProcessorConfiguration?: AmazonTranscribeProcessorConfiguration;
    KinesisDataStreamSinkConfiguration?: KinesisDataStreamSinkConfiguration;
    S3RecordingSinkConfiguration?: S3RecordingSinkConfiguration;
    VoiceAnalyticsProcessorConfiguration?: VoiceAnalyticsProcessorConfiguration;
    LambdaFunctionSinkConfiguration?: LambdaFunctionSinkConfiguration;
    SqsQueueSinkConfiguration?: SqsQueueSinkConfiguration;
    SnsTopicSinkConfiguration?: SnsTopicSinkConfiguration;
    VoiceEnhancementSinkConfiguration?: VoiceEnhancementSinkConfiguration;
}
export declare const MediaInsightsPipelineConfigurationElement: S.Schema<MediaInsightsPipelineConfigurationElement>;
export type MediaInsightsPipelineConfigurationElements = MediaInsightsPipelineConfigurationElement[];
export declare const MediaInsightsPipelineConfigurationElements: any;
export interface CreateMediaInsightsPipelineConfigurationRequest {
    MediaInsightsPipelineConfigurationName: string;
    ResourceAccessRoleArn: string | redacted.Redacted<string>;
    RealTimeAlertConfiguration?: RealTimeAlertConfiguration;
    Elements: MediaInsightsPipelineConfigurationElement[];
    Tags?: Tag[];
    ClientRequestToken?: string | redacted.Redacted<string>;
}
export declare const CreateMediaInsightsPipelineConfigurationRequest: S.Schema<CreateMediaInsightsPipelineConfigurationRequest>;
export interface MediaInsightsPipelineConfiguration {
    MediaInsightsPipelineConfigurationName?: string;
    MediaInsightsPipelineConfigurationArn?: string | redacted.Redacted<string>;
    ResourceAccessRoleArn?: string | redacted.Redacted<string>;
    RealTimeAlertConfiguration?: RealTimeAlertConfiguration;
    Elements?: MediaInsightsPipelineConfigurationElement[];
    MediaInsightsPipelineConfigurationId?: string;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export declare const MediaInsightsPipelineConfiguration: S.Schema<MediaInsightsPipelineConfiguration>;
export interface CreateMediaInsightsPipelineConfigurationResponse {
    MediaInsightsPipelineConfiguration?: MediaInsightsPipelineConfiguration;
}
export declare const CreateMediaInsightsPipelineConfigurationResponse: S.Schema<CreateMediaInsightsPipelineConfigurationResponse>;
export type LiveConnectorSourceType = "ChimeSdkMeeting" | (string & {});
export declare const LiveConnectorSourceType: any;
export type LiveConnectorMuxType = "AudioWithCompositedVideo" | "AudioWithActiveSpeakerVideo" | (string & {});
export declare const LiveConnectorMuxType: any;
export interface ChimeSdkMeetingLiveConnectorConfiguration {
    Arn: string | redacted.Redacted<string>;
    MuxType: LiveConnectorMuxType;
    CompositedVideo?: CompositedVideoArtifactsConfiguration;
    SourceConfiguration?: SourceConfiguration;
}
export declare const ChimeSdkMeetingLiveConnectorConfiguration: S.Schema<ChimeSdkMeetingLiveConnectorConfiguration>;
export interface LiveConnectorSourceConfiguration {
    SourceType: LiveConnectorSourceType;
    ChimeSdkMeetingLiveConnectorConfiguration: ChimeSdkMeetingLiveConnectorConfiguration;
}
export declare const LiveConnectorSourceConfiguration: S.Schema<LiveConnectorSourceConfiguration>;
export type LiveConnectorSourceList = LiveConnectorSourceConfiguration[];
export declare const LiveConnectorSourceList: any;
export type LiveConnectorSinkType = "RTMP" | (string & {});
export declare const LiveConnectorSinkType: any;
export type SensitiveString = string | redacted.Redacted<string>;
export type AudioChannelsOption = "Stereo" | "Mono" | (string & {});
export declare const AudioChannelsOption: any;
export type AudioSampleRateOption = string;
export interface LiveConnectorRTMPConfiguration {
    Url: string | redacted.Redacted<string>;
    AudioChannels?: AudioChannelsOption;
    AudioSampleRate?: string;
}
export declare const LiveConnectorRTMPConfiguration: S.Schema<LiveConnectorRTMPConfiguration>;
export interface LiveConnectorSinkConfiguration {
    SinkType: LiveConnectorSinkType;
    RTMPConfiguration: LiveConnectorRTMPConfiguration;
}
export declare const LiveConnectorSinkConfiguration: S.Schema<LiveConnectorSinkConfiguration>;
export type LiveConnectorSinkList = LiveConnectorSinkConfiguration[];
export declare const LiveConnectorSinkList: any;
export interface CreateMediaLiveConnectorPipelineRequest {
    Sources: LiveConnectorSourceConfiguration[];
    Sinks: LiveConnectorSinkConfiguration[];
    ClientRequestToken?: string | redacted.Redacted<string>;
    Tags?: Tag[];
}
export declare const CreateMediaLiveConnectorPipelineRequest: S.Schema<CreateMediaLiveConnectorPipelineRequest>;
export interface MediaLiveConnectorPipeline {
    Sources?: LiveConnectorSourceConfiguration[];
    Sinks?: LiveConnectorSinkConfiguration[];
    MediaPipelineId?: string;
    MediaPipelineArn?: string;
    Status?: MediaPipelineStatus;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export declare const MediaLiveConnectorPipeline: S.Schema<MediaLiveConnectorPipeline>;
export interface CreateMediaLiveConnectorPipelineResponse {
    MediaLiveConnectorPipeline?: MediaLiveConnectorPipeline;
}
export declare const CreateMediaLiveConnectorPipelineResponse: S.Schema<CreateMediaLiveConnectorPipelineResponse>;
export type AwsRegion = string;
export type DataRetentionInHours = number;
export interface KinesisVideoStreamConfiguration {
    Region: string;
    DataRetentionInHours?: number;
}
export declare const KinesisVideoStreamConfiguration: S.Schema<KinesisVideoStreamConfiguration>;
export type KinesisVideoStreamPoolName = string;
export interface CreateMediaPipelineKinesisVideoStreamPoolRequest {
    StreamConfiguration: KinesisVideoStreamConfiguration;
    PoolName: string;
    ClientRequestToken?: string | redacted.Redacted<string>;
    Tags?: Tag[];
}
export declare const CreateMediaPipelineKinesisVideoStreamPoolRequest: S.Schema<CreateMediaPipelineKinesisVideoStreamPoolRequest>;
export type KinesisVideoStreamPoolId = string;
export type KinesisVideoStreamPoolStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export declare const KinesisVideoStreamPoolStatus: any;
export type KinesisVideoStreamPoolSize = number;
export interface KinesisVideoStreamPoolConfiguration {
    PoolArn?: string | redacted.Redacted<string>;
    PoolName?: string;
    PoolId?: string;
    PoolStatus?: KinesisVideoStreamPoolStatus;
    PoolSize?: number;
    StreamConfiguration?: KinesisVideoStreamConfiguration;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export declare const KinesisVideoStreamPoolConfiguration: S.Schema<KinesisVideoStreamPoolConfiguration>;
export interface CreateMediaPipelineKinesisVideoStreamPoolResponse {
    KinesisVideoStreamPoolConfiguration?: KinesisVideoStreamPoolConfiguration;
}
export declare const CreateMediaPipelineKinesisVideoStreamPoolResponse: S.Schema<CreateMediaPipelineKinesisVideoStreamPoolResponse>;
export interface MediaStreamSource {
    SourceType: MediaPipelineSourceType;
    SourceArn: string | redacted.Redacted<string>;
}
export declare const MediaStreamSource: S.Schema<MediaStreamSource>;
export type MediaStreamSourceList = MediaStreamSource[];
export declare const MediaStreamSourceList: any;
export type MediaStreamPipelineSinkType = "KinesisVideoStreamPool" | (string & {});
export declare const MediaStreamPipelineSinkType: any;
export type ReservedStreamCapacity = number;
export type MediaStreamType = "MixedAudio" | "IndividualAudio" | (string & {});
export declare const MediaStreamType: any;
export interface MediaStreamSink {
    SinkArn: string | redacted.Redacted<string>;
    SinkType: MediaStreamPipelineSinkType;
    ReservedStreamCapacity: number;
    MediaStreamType: MediaStreamType;
}
export declare const MediaStreamSink: S.Schema<MediaStreamSink>;
export type MediaStreamSinkList = MediaStreamSink[];
export declare const MediaStreamSinkList: any;
export interface CreateMediaStreamPipelineRequest {
    Sources: MediaStreamSource[];
    Sinks: MediaStreamSink[];
    ClientRequestToken?: string | redacted.Redacted<string>;
    Tags?: Tag[];
}
export declare const CreateMediaStreamPipelineRequest: S.Schema<CreateMediaStreamPipelineRequest>;
export interface MediaStreamPipeline {
    MediaPipelineId?: string;
    MediaPipelineArn?: string;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    Status?: MediaPipelineStatus;
    Sources?: MediaStreamSource[];
    Sinks?: MediaStreamSink[];
}
export declare const MediaStreamPipeline: S.Schema<MediaStreamPipeline>;
export interface CreateMediaStreamPipelineResponse {
    MediaStreamPipeline?: MediaStreamPipeline;
}
export declare const CreateMediaStreamPipelineResponse: S.Schema<CreateMediaStreamPipelineResponse>;
export interface DeleteMediaCapturePipelineRequest {
    MediaPipelineId: string;
}
export declare const DeleteMediaCapturePipelineRequest: S.Schema<DeleteMediaCapturePipelineRequest>;
export interface DeleteMediaCapturePipelineResponse {
}
export declare const DeleteMediaCapturePipelineResponse: S.Schema<DeleteMediaCapturePipelineResponse>;
export interface DeleteMediaInsightsPipelineConfigurationRequest {
    Identifier: string;
}
export declare const DeleteMediaInsightsPipelineConfigurationRequest: S.Schema<DeleteMediaInsightsPipelineConfigurationRequest>;
export interface DeleteMediaInsightsPipelineConfigurationResponse {
}
export declare const DeleteMediaInsightsPipelineConfigurationResponse: S.Schema<DeleteMediaInsightsPipelineConfigurationResponse>;
export interface DeleteMediaPipelineRequest {
    MediaPipelineId: string;
}
export declare const DeleteMediaPipelineRequest: S.Schema<DeleteMediaPipelineRequest>;
export interface DeleteMediaPipelineResponse {
}
export declare const DeleteMediaPipelineResponse: S.Schema<DeleteMediaPipelineResponse>;
export interface DeleteMediaPipelineKinesisVideoStreamPoolRequest {
    Identifier: string;
}
export declare const DeleteMediaPipelineKinesisVideoStreamPoolRequest: S.Schema<DeleteMediaPipelineKinesisVideoStreamPoolRequest>;
export interface DeleteMediaPipelineKinesisVideoStreamPoolResponse {
}
export declare const DeleteMediaPipelineKinesisVideoStreamPoolResponse: S.Schema<DeleteMediaPipelineKinesisVideoStreamPoolResponse>;
export interface GetMediaCapturePipelineRequest {
    MediaPipelineId: string;
}
export declare const GetMediaCapturePipelineRequest: S.Schema<GetMediaCapturePipelineRequest>;
export interface GetMediaCapturePipelineResponse {
    MediaCapturePipeline?: MediaCapturePipeline;
}
export declare const GetMediaCapturePipelineResponse: S.Schema<GetMediaCapturePipelineResponse>;
export interface GetMediaInsightsPipelineConfigurationRequest {
    Identifier: string;
}
export declare const GetMediaInsightsPipelineConfigurationRequest: S.Schema<GetMediaInsightsPipelineConfigurationRequest>;
export interface GetMediaInsightsPipelineConfigurationResponse {
    MediaInsightsPipelineConfiguration?: MediaInsightsPipelineConfiguration;
}
export declare const GetMediaInsightsPipelineConfigurationResponse: S.Schema<GetMediaInsightsPipelineConfigurationResponse>;
export interface GetMediaPipelineRequest {
    MediaPipelineId: string;
}
export declare const GetMediaPipelineRequest: S.Schema<GetMediaPipelineRequest>;
export interface MediaPipeline {
    MediaCapturePipeline?: MediaCapturePipeline;
    MediaLiveConnectorPipeline?: MediaLiveConnectorPipeline;
    MediaConcatenationPipeline?: MediaConcatenationPipeline;
    MediaInsightsPipeline?: MediaInsightsPipeline;
    MediaStreamPipeline?: MediaStreamPipeline;
}
export declare const MediaPipeline: S.Schema<MediaPipeline>;
export interface GetMediaPipelineResponse {
    MediaPipeline?: MediaPipeline;
}
export declare const GetMediaPipelineResponse: S.Schema<GetMediaPipelineResponse>;
export interface GetMediaPipelineKinesisVideoStreamPoolRequest {
    Identifier: string;
}
export declare const GetMediaPipelineKinesisVideoStreamPoolRequest: S.Schema<GetMediaPipelineKinesisVideoStreamPoolRequest>;
export interface GetMediaPipelineKinesisVideoStreamPoolResponse {
    KinesisVideoStreamPoolConfiguration?: KinesisVideoStreamPoolConfiguration;
}
export declare const GetMediaPipelineKinesisVideoStreamPoolResponse: S.Schema<GetMediaPipelineKinesisVideoStreamPoolResponse>;
export interface GetSpeakerSearchTaskRequest {
    Identifier: string;
    SpeakerSearchTaskId: string;
}
export declare const GetSpeakerSearchTaskRequest: S.Schema<GetSpeakerSearchTaskRequest>;
export type MediaPipelineTaskStatus = "NotStarted" | "Initializing" | "InProgress" | "Failed" | "Stopping" | "Stopped" | (string & {});
export declare const MediaPipelineTaskStatus: any;
export interface SpeakerSearchTask {
    SpeakerSearchTaskId?: string;
    SpeakerSearchTaskStatus?: MediaPipelineTaskStatus;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export declare const SpeakerSearchTask: S.Schema<SpeakerSearchTask>;
export interface GetSpeakerSearchTaskResponse {
    SpeakerSearchTask?: SpeakerSearchTask;
}
export declare const GetSpeakerSearchTaskResponse: S.Schema<GetSpeakerSearchTaskResponse>;
export interface GetVoiceToneAnalysisTaskRequest {
    Identifier: string;
    VoiceToneAnalysisTaskId: string;
}
export declare const GetVoiceToneAnalysisTaskRequest: S.Schema<GetVoiceToneAnalysisTaskRequest>;
export interface VoiceToneAnalysisTask {
    VoiceToneAnalysisTaskId?: string;
    VoiceToneAnalysisTaskStatus?: MediaPipelineTaskStatus;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export declare const VoiceToneAnalysisTask: S.Schema<VoiceToneAnalysisTask>;
export interface GetVoiceToneAnalysisTaskResponse {
    VoiceToneAnalysisTask?: VoiceToneAnalysisTask;
}
export declare const GetVoiceToneAnalysisTaskResponse: S.Schema<GetVoiceToneAnalysisTaskResponse>;
export type ResultMax = number;
export interface ListMediaCapturePipelinesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListMediaCapturePipelinesRequest: S.Schema<ListMediaCapturePipelinesRequest>;
export interface MediaCapturePipelineSummary {
    MediaPipelineId?: string;
    MediaPipelineArn?: string;
}
export declare const MediaCapturePipelineSummary: S.Schema<MediaCapturePipelineSummary>;
export type MediaCapturePipelineSummaryList = MediaCapturePipelineSummary[];
export declare const MediaCapturePipelineSummaryList: any;
export interface ListMediaCapturePipelinesResponse {
    MediaCapturePipelines?: MediaCapturePipelineSummary[];
    NextToken?: string;
}
export declare const ListMediaCapturePipelinesResponse: S.Schema<ListMediaCapturePipelinesResponse>;
export interface ListMediaInsightsPipelineConfigurationsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListMediaInsightsPipelineConfigurationsRequest: S.Schema<ListMediaInsightsPipelineConfigurationsRequest>;
export interface MediaInsightsPipelineConfigurationSummary {
    MediaInsightsPipelineConfigurationName?: string;
    MediaInsightsPipelineConfigurationId?: string;
    MediaInsightsPipelineConfigurationArn?: string | redacted.Redacted<string>;
}
export declare const MediaInsightsPipelineConfigurationSummary: S.Schema<MediaInsightsPipelineConfigurationSummary>;
export type MediaInsightsPipelineConfigurationSummaryList = MediaInsightsPipelineConfigurationSummary[];
export declare const MediaInsightsPipelineConfigurationSummaryList: any;
export interface ListMediaInsightsPipelineConfigurationsResponse {
    MediaInsightsPipelineConfigurations?: MediaInsightsPipelineConfigurationSummary[];
    NextToken?: string;
}
export declare const ListMediaInsightsPipelineConfigurationsResponse: S.Schema<ListMediaInsightsPipelineConfigurationsResponse>;
export interface ListMediaPipelineKinesisVideoStreamPoolsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListMediaPipelineKinesisVideoStreamPoolsRequest: S.Schema<ListMediaPipelineKinesisVideoStreamPoolsRequest>;
export interface KinesisVideoStreamPoolSummary {
    PoolName?: string;
    PoolId?: string;
    PoolArn?: string | redacted.Redacted<string>;
}
export declare const KinesisVideoStreamPoolSummary: S.Schema<KinesisVideoStreamPoolSummary>;
export type KinesisVideoStreamPoolSummaryList = KinesisVideoStreamPoolSummary[];
export declare const KinesisVideoStreamPoolSummaryList: any;
export interface ListMediaPipelineKinesisVideoStreamPoolsResponse {
    KinesisVideoStreamPools?: KinesisVideoStreamPoolSummary[];
    NextToken?: string;
}
export declare const ListMediaPipelineKinesisVideoStreamPoolsResponse: S.Schema<ListMediaPipelineKinesisVideoStreamPoolsResponse>;
export interface ListMediaPipelinesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListMediaPipelinesRequest: S.Schema<ListMediaPipelinesRequest>;
export interface MediaPipelineSummary {
    MediaPipelineId?: string;
    MediaPipelineArn?: string;
}
export declare const MediaPipelineSummary: S.Schema<MediaPipelineSummary>;
export type MediaPipelineList = MediaPipelineSummary[];
export declare const MediaPipelineList: any;
export interface ListMediaPipelinesResponse {
    MediaPipelines?: MediaPipelineSummary[];
    NextToken?: string;
}
export declare const ListMediaPipelinesResponse: S.Schema<ListMediaPipelinesResponse>;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface KinesisVideoStreamSourceTaskConfiguration {
    StreamArn: string;
    ChannelId: number;
    FragmentNumber?: string;
}
export declare const KinesisVideoStreamSourceTaskConfiguration: S.Schema<KinesisVideoStreamSourceTaskConfiguration>;
export interface StartSpeakerSearchTaskRequest {
    Identifier: string;
    VoiceProfileDomainArn: string | redacted.Redacted<string>;
    KinesisVideoStreamSourceTaskConfiguration?: KinesisVideoStreamSourceTaskConfiguration;
    ClientRequestToken?: string | redacted.Redacted<string>;
}
export declare const StartSpeakerSearchTaskRequest: S.Schema<StartSpeakerSearchTaskRequest>;
export interface StartSpeakerSearchTaskResponse {
    SpeakerSearchTask?: SpeakerSearchTask;
}
export declare const StartSpeakerSearchTaskResponse: S.Schema<StartSpeakerSearchTaskResponse>;
export type VoiceAnalyticsLanguageCode = "en-US" | (string & {});
export declare const VoiceAnalyticsLanguageCode: any;
export interface StartVoiceToneAnalysisTaskRequest {
    Identifier: string;
    LanguageCode: VoiceAnalyticsLanguageCode;
    KinesisVideoStreamSourceTaskConfiguration?: KinesisVideoStreamSourceTaskConfiguration;
    ClientRequestToken?: string | redacted.Redacted<string>;
}
export declare const StartVoiceToneAnalysisTaskRequest: S.Schema<StartVoiceToneAnalysisTaskRequest>;
export interface StartVoiceToneAnalysisTaskResponse {
    VoiceToneAnalysisTask?: VoiceToneAnalysisTask;
}
export declare const StartVoiceToneAnalysisTaskResponse: S.Schema<StartVoiceToneAnalysisTaskResponse>;
export interface StopSpeakerSearchTaskRequest {
    Identifier: string;
    SpeakerSearchTaskId: string;
}
export declare const StopSpeakerSearchTaskRequest: S.Schema<StopSpeakerSearchTaskRequest>;
export interface StopSpeakerSearchTaskResponse {
}
export declare const StopSpeakerSearchTaskResponse: S.Schema<StopSpeakerSearchTaskResponse>;
export interface StopVoiceToneAnalysisTaskRequest {
    Identifier: string;
    VoiceToneAnalysisTaskId: string;
}
export declare const StopVoiceToneAnalysisTaskRequest: S.Schema<StopVoiceToneAnalysisTaskRequest>;
export interface StopVoiceToneAnalysisTaskResponse {
}
export declare const StopVoiceToneAnalysisTaskResponse: S.Schema<StopVoiceToneAnalysisTaskResponse>;
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateMediaInsightsPipelineConfigurationRequest {
    Identifier: string;
    ResourceAccessRoleArn: string | redacted.Redacted<string>;
    RealTimeAlertConfiguration?: RealTimeAlertConfiguration;
    Elements: MediaInsightsPipelineConfigurationElement[];
}
export declare const UpdateMediaInsightsPipelineConfigurationRequest: S.Schema<UpdateMediaInsightsPipelineConfigurationRequest>;
export interface UpdateMediaInsightsPipelineConfigurationResponse {
    MediaInsightsPipelineConfiguration?: MediaInsightsPipelineConfiguration;
}
export declare const UpdateMediaInsightsPipelineConfigurationResponse: S.Schema<UpdateMediaInsightsPipelineConfigurationResponse>;
export type MediaPipelineStatusUpdate = "Pause" | "Resume" | (string & {});
export declare const MediaPipelineStatusUpdate: any;
export interface UpdateMediaInsightsPipelineStatusRequest {
    Identifier: string;
    UpdateStatus: MediaPipelineStatusUpdate;
}
export declare const UpdateMediaInsightsPipelineStatusRequest: S.Schema<UpdateMediaInsightsPipelineStatusRequest>;
export interface UpdateMediaInsightsPipelineStatusResponse {
}
export declare const UpdateMediaInsightsPipelineStatusResponse: S.Schema<UpdateMediaInsightsPipelineStatusResponse>;
export type DataRetentionChangeInHours = number;
export interface KinesisVideoStreamConfigurationUpdate {
    DataRetentionInHours?: number;
}
export declare const KinesisVideoStreamConfigurationUpdate: S.Schema<KinesisVideoStreamConfigurationUpdate>;
export interface UpdateMediaPipelineKinesisVideoStreamPoolRequest {
    Identifier: string;
    StreamConfiguration?: KinesisVideoStreamConfigurationUpdate;
}
export declare const UpdateMediaPipelineKinesisVideoStreamPoolRequest: S.Schema<UpdateMediaPipelineKinesisVideoStreamPoolRequest>;
export interface UpdateMediaPipelineKinesisVideoStreamPoolResponse {
    KinesisVideoStreamPoolConfiguration?: KinesisVideoStreamPoolConfiguration;
}
export declare const UpdateMediaPipelineKinesisVideoStreamPoolResponse: S.Schema<UpdateMediaPipelineKinesisVideoStreamPoolResponse>;
export type ErrorCode = "BadRequest" | "Forbidden" | "NotFound" | "ResourceLimitExceeded" | "ServiceFailure" | "ServiceUnavailable" | "Throttling" | (string & {});
export declare const ErrorCode: any;
export type CreateMediaCapturePipelineError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a media pipeline.
 */
export declare const createMediaCapturePipeline: API.OperationMethod<CreateMediaCapturePipelineRequest, CreateMediaCapturePipelineResponse, CreateMediaCapturePipelineError, Credentials | HttpClient.HttpClient>;
export type CreateMediaConcatenationPipelineError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a media concatenation pipeline.
 */
export declare const createMediaConcatenationPipeline: API.OperationMethod<CreateMediaConcatenationPipelineRequest, CreateMediaConcatenationPipelineResponse, CreateMediaConcatenationPipelineError, Credentials | HttpClient.HttpClient>;
export type CreateMediaInsightsPipelineError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a media insights pipeline.
 */
export declare const createMediaInsightsPipeline: API.OperationMethod<CreateMediaInsightsPipelineRequest, CreateMediaInsightsPipelineResponse, CreateMediaInsightsPipelineError, Credentials | HttpClient.HttpClient>;
export type CreateMediaInsightsPipelineConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * A structure that contains the static configurations for a media insights
 * pipeline.
 */
export declare const createMediaInsightsPipelineConfiguration: API.OperationMethod<CreateMediaInsightsPipelineConfigurationRequest, CreateMediaInsightsPipelineConfigurationResponse, CreateMediaInsightsPipelineConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateMediaLiveConnectorPipelineError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a media live connector pipeline in an Amazon Chime SDK meeting.
 */
export declare const createMediaLiveConnectorPipeline: API.OperationMethod<CreateMediaLiveConnectorPipelineRequest, CreateMediaLiveConnectorPipelineResponse, CreateMediaLiveConnectorPipelineError, Credentials | HttpClient.HttpClient>;
export type CreateMediaPipelineKinesisVideoStreamPoolError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an Amazon Kinesis Video Stream pool for use with media stream
 * pipelines.
 *
 * If a meeting uses an opt-in Region as its
 * MediaRegion,
 * the KVS stream must be in that same Region. For example, if a meeting uses the `af-south-1` Region, the KVS stream must also be in `af-south-1`. However, if the meeting uses a
 * Region that AWS turns on by default, the KVS stream can be in any available Region, including an opt-in Region. For example, if the meeting uses `ca-central-1`, the KVS stream can be in
 * `eu-west-2`, `us-east-1`, `af-south-1`, or any other Region that the Amazon Chime SDK supports.
 *
 * To learn which AWS Region a meeting uses, call the GetMeeting API and
 * use the MediaRegion
 * parameter from the response.
 *
 * For more information about opt-in Regions, refer to Available Regions in the
 * *Amazon Chime SDK Developer Guide*, and
 * Specify which AWS Regions your account can use,
 * in the *AWS Account Management Reference Guide*.
 */
export declare const createMediaPipelineKinesisVideoStreamPool: API.OperationMethod<CreateMediaPipelineKinesisVideoStreamPoolRequest, CreateMediaPipelineKinesisVideoStreamPoolResponse, CreateMediaPipelineKinesisVideoStreamPoolError, Credentials | HttpClient.HttpClient>;
export type CreateMediaStreamPipelineError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a streaming media pipeline.
 */
export declare const createMediaStreamPipeline: API.OperationMethod<CreateMediaStreamPipelineRequest, CreateMediaStreamPipelineResponse, CreateMediaStreamPipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteMediaCapturePipelineError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the media pipeline.
 */
export declare const deleteMediaCapturePipeline: API.OperationMethod<DeleteMediaCapturePipelineRequest, DeleteMediaCapturePipelineResponse, DeleteMediaCapturePipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteMediaInsightsPipelineConfigurationError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the specified configuration settings.
 */
export declare const deleteMediaInsightsPipelineConfiguration: API.OperationMethod<DeleteMediaInsightsPipelineConfigurationRequest, DeleteMediaInsightsPipelineConfigurationResponse, DeleteMediaInsightsPipelineConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteMediaPipelineError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the media pipeline.
 */
export declare const deleteMediaPipeline: API.OperationMethod<DeleteMediaPipelineRequest, DeleteMediaPipelineResponse, DeleteMediaPipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteMediaPipelineKinesisVideoStreamPoolError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an Amazon Kinesis Video Stream pool.
 */
export declare const deleteMediaPipelineKinesisVideoStreamPool: API.OperationMethod<DeleteMediaPipelineKinesisVideoStreamPoolRequest, DeleteMediaPipelineKinesisVideoStreamPoolResponse, DeleteMediaPipelineKinesisVideoStreamPoolError, Credentials | HttpClient.HttpClient>;
export type GetMediaCapturePipelineError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets an existing media pipeline.
 */
export declare const getMediaCapturePipeline: API.OperationMethod<GetMediaCapturePipelineRequest, GetMediaCapturePipelineResponse, GetMediaCapturePipelineError, Credentials | HttpClient.HttpClient>;
export type GetMediaInsightsPipelineConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets the configuration settings for a media insights pipeline.
 */
export declare const getMediaInsightsPipelineConfiguration: API.OperationMethod<GetMediaInsightsPipelineConfigurationRequest, GetMediaInsightsPipelineConfigurationResponse, GetMediaInsightsPipelineConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetMediaPipelineError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets an existing media pipeline.
 */
export declare const getMediaPipeline: API.OperationMethod<GetMediaPipelineRequest, GetMediaPipelineResponse, GetMediaPipelineError, Credentials | HttpClient.HttpClient>;
export type GetMediaPipelineKinesisVideoStreamPoolError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets an Kinesis video stream pool.
 */
export declare const getMediaPipelineKinesisVideoStreamPool: API.OperationMethod<GetMediaPipelineKinesisVideoStreamPoolRequest, GetMediaPipelineKinesisVideoStreamPoolResponse, GetMediaPipelineKinesisVideoStreamPoolError, Credentials | HttpClient.HttpClient>;
export type GetSpeakerSearchTaskError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of the specified speaker search task.
 */
export declare const getSpeakerSearchTask: API.OperationMethod<GetSpeakerSearchTaskRequest, GetSpeakerSearchTaskResponse, GetSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type GetVoiceToneAnalysisTaskError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of a voice tone analysis task.
 */
export declare const getVoiceToneAnalysisTask: API.OperationMethod<GetVoiceToneAnalysisTaskRequest, GetVoiceToneAnalysisTaskResponse, GetVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type ListMediaCapturePipelinesError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns a list of media pipelines.
 */
export declare const listMediaCapturePipelines: API.PaginatedOperationMethod<ListMediaCapturePipelinesRequest, ListMediaCapturePipelinesResponse, ListMediaCapturePipelinesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMediaInsightsPipelineConfigurationsError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the available media insights pipeline configurations.
 */
export declare const listMediaInsightsPipelineConfigurations: API.PaginatedOperationMethod<ListMediaInsightsPipelineConfigurationsRequest, ListMediaInsightsPipelineConfigurationsResponse, ListMediaInsightsPipelineConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMediaPipelineKinesisVideoStreamPoolsError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the video stream pools in the media pipeline.
 */
export declare const listMediaPipelineKinesisVideoStreamPools: API.PaginatedOperationMethod<ListMediaPipelineKinesisVideoStreamPoolsRequest, ListMediaPipelineKinesisVideoStreamPoolsResponse, ListMediaPipelineKinesisVideoStreamPoolsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMediaPipelinesError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns a list of media pipelines.
 */
export declare const listMediaPipelines: API.PaginatedOperationMethod<ListMediaPipelinesRequest, ListMediaPipelinesResponse, ListMediaPipelinesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the tags available for a media pipeline.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartSpeakerSearchTaskError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Starts a speaker search task.
 *
 * Before starting any speaker search tasks, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 */
export declare const startSpeakerSearchTask: API.OperationMethod<StartSpeakerSearchTaskRequest, StartSpeakerSearchTaskResponse, StartSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type StartVoiceToneAnalysisTaskError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Starts a voice tone analysis task. For more information about voice tone analysis, see
 * Using Amazon Chime SDK voice analytics
 * in the *Amazon Chime SDK Developer Guide*.
 *
 * Before starting any voice tone analysis tasks, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 */
export declare const startVoiceToneAnalysisTask: API.OperationMethod<StartVoiceToneAnalysisTaskRequest, StartVoiceToneAnalysisTaskResponse, StartVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type StopSpeakerSearchTaskError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Stops a speaker search task.
 */
export declare const stopSpeakerSearchTask: API.OperationMethod<StopSpeakerSearchTaskRequest, StopSpeakerSearchTaskResponse, StopSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type StopVoiceToneAnalysisTaskError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Stops a voice tone analysis task.
 */
export declare const stopVoiceToneAnalysisTask: API.OperationMethod<StopVoiceToneAnalysisTaskRequest, StopVoiceToneAnalysisTaskResponse, StopVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * The ARN of the media pipeline that you want to tag. Consists of the pipeline's endpoint region, resource ID, and pipeline ID.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Removes any tags from a media pipeline.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateMediaInsightsPipelineConfigurationError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the media insights pipeline's configuration settings.
 */
export declare const updateMediaInsightsPipelineConfiguration: API.OperationMethod<UpdateMediaInsightsPipelineConfigurationRequest, UpdateMediaInsightsPipelineConfigurationResponse, UpdateMediaInsightsPipelineConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateMediaInsightsPipelineStatusError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the status of a media insights pipeline.
 */
export declare const updateMediaInsightsPipelineStatus: API.OperationMethod<UpdateMediaInsightsPipelineStatusRequest, UpdateMediaInsightsPipelineStatusResponse, UpdateMediaInsightsPipelineStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateMediaPipelineKinesisVideoStreamPoolError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates an Amazon Kinesis Video Stream pool in a media pipeline.
 */
export declare const updateMediaPipelineKinesisVideoStreamPool: API.OperationMethod<UpdateMediaPipelineKinesisVideoStreamPoolRequest, UpdateMediaPipelineKinesisVideoStreamPoolResponse, UpdateMediaPipelineKinesisVideoStreamPoolError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=chime-sdk-media-pipelines.d.ts.map