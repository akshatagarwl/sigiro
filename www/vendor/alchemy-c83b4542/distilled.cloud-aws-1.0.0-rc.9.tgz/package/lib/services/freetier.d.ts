import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ActivityId = string;
export type LanguageCode = "en-US" | "en-GB" | "id-ID" | "de-DE" | "es-ES" | "fr-FR" | "ja-JP" | "it-IT" | "pt-PT" | "ko-KR" | "zh-CN" | "zh-TW" | "tr-TR" | (string & {});
export declare const LanguageCode: any;
export interface GetAccountActivityRequest {
    activityId: string;
    languageCode?: LanguageCode;
}
export declare const GetAccountActivityRequest: S.Schema<GetAccountActivityRequest>;
export type ActivityStatus = "NOT_STARTED" | "IN_PROGRESS" | "COMPLETED" | "EXPIRING" | (string & {});
export declare const ActivityStatus: any;
export type CurrencyCode = "USD" | (string & {});
export declare const CurrencyCode: any;
export interface MonetaryAmount {
    amount: number;
    unit: CurrencyCode;
}
export declare const MonetaryAmount: S.Schema<MonetaryAmount>;
export type ActivityReward = {
    credit: MonetaryAmount;
};
export declare const ActivityReward: any;
export interface GetAccountActivityResponse {
    activityId: string;
    title: string;
    description: string;
    status: ActivityStatus;
    instructionsUrl: string;
    reward: ActivityReward;
    estimatedTimeToCompleteInMinutes?: number;
    expiresAt?: Date;
    startedAt?: Date;
    completedAt?: Date;
}
export declare const GetAccountActivityResponse: S.Schema<GetAccountActivityResponse>;
export interface GetAccountPlanStateRequest {
}
export declare const GetAccountPlanStateRequest: S.Schema<GetAccountPlanStateRequest>;
export type AccountId = string;
export type AccountPlanType = "FREE" | "PAID" | (string & {});
export declare const AccountPlanType: any;
export type AccountPlanStatus = "NOT_STARTED" | "ACTIVE" | "EXPIRED" | (string & {});
export declare const AccountPlanStatus: any;
export interface GetAccountPlanStateResponse {
    accountId: string;
    accountPlanType: AccountPlanType;
    accountPlanStatus: AccountPlanStatus;
    accountPlanRemainingCredits?: MonetaryAmount;
    accountPlanExpirationDate?: Date;
}
export declare const GetAccountPlanStateResponse: S.Schema<GetAccountPlanStateResponse>;
export type Expressions = Expression[];
export declare const Expressions: S.Schema<Expressions>;
export type Dimension = "SERVICE" | "OPERATION" | "USAGE_TYPE" | "REGION" | "FREE_TIER_TYPE" | "DESCRIPTION" | "USAGE_PERCENTAGE" | (string & {});
export declare const Dimension: any;
export type Value = string;
export type Values = string[];
export declare const Values: any;
export type MatchOption = "EQUALS" | "STARTS_WITH" | "ENDS_WITH" | "CONTAINS" | "GREATER_THAN_OR_EQUAL" | (string & {});
export declare const MatchOption: any;
export type MatchOptions = MatchOption[];
export declare const MatchOptions: any;
export interface DimensionValues {
    Key: Dimension;
    Values: string[];
    MatchOptions: MatchOption[];
}
export declare const DimensionValues: S.Schema<DimensionValues>;
export interface Expression {
    Or?: Expression[];
    And?: Expression[];
    Not?: Expression;
    Dimensions?: DimensionValues;
}
export declare const Expression: S.Schema<Expression>;
export type MaxResults = number;
export type NextPageToken = string;
export interface GetFreeTierUsageRequest {
    filter?: Expression;
    maxResults?: number;
    nextToken?: string;
}
export declare const GetFreeTierUsageRequest: S.Schema<GetFreeTierUsageRequest>;
export interface FreeTierUsage {
    service?: string;
    operation?: string;
    usageType?: string;
    region?: string;
    actualUsageAmount?: number;
    forecastedUsageAmount?: number;
    limit?: number;
    unit?: string;
    description?: string;
    freeTierType?: string;
}
export declare const FreeTierUsage: S.Schema<FreeTierUsage>;
export type FreeTierUsages = FreeTierUsage[];
export declare const FreeTierUsages: any;
export interface GetFreeTierUsageResponse {
    freeTierUsages: FreeTierUsage[];
    nextToken?: string;
}
export declare const GetFreeTierUsageResponse: S.Schema<GetFreeTierUsageResponse>;
export type FilterActivityStatuses = ActivityStatus[];
export declare const FilterActivityStatuses: any;
export interface ListAccountActivitiesRequest {
    filterActivityStatuses?: ActivityStatus[];
    nextToken?: string;
    maxResults?: number;
    languageCode?: LanguageCode;
}
export declare const ListAccountActivitiesRequest: S.Schema<ListAccountActivitiesRequest>;
export interface ActivitySummary {
    activityId: string;
    title: string;
    reward: ActivityReward;
    status: ActivityStatus;
}
export declare const ActivitySummary: S.Schema<ActivitySummary>;
export type Activities = ActivitySummary[];
export declare const Activities: any;
export interface ListAccountActivitiesResponse {
    activities: ActivitySummary[];
    nextToken?: string;
}
export declare const ListAccountActivitiesResponse: S.Schema<ListAccountActivitiesResponse>;
export interface UpgradeAccountPlanRequest {
    accountPlanType: AccountPlanType;
}
export declare const UpgradeAccountPlanRequest: S.Schema<UpgradeAccountPlanRequest>;
export interface UpgradeAccountPlanResponse {
    accountId: string;
    accountPlanType: AccountPlanType;
    accountPlanStatus: AccountPlanStatus;
}
export declare const UpgradeAccountPlanResponse: S.Schema<UpgradeAccountPlanResponse>;
export type GetAccountActivityError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a specific activity record that is available to the customer.
 */
export declare const getAccountActivity: API.OperationMethod<GetAccountActivityRequest, GetAccountActivityResponse, GetAccountActivityError, Credentials | HttpClient.HttpClient>;
export type GetAccountPlanStateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This returns all of the information related to the state of the account plan related to Free Tier.
 */
export declare const getAccountPlanState: API.OperationMethod<GetAccountPlanStateRequest, GetAccountPlanStateResponse, GetAccountPlanStateError, Credentials | HttpClient.HttpClient>;
export type GetFreeTierUsageError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all Free Tier usage objects that match your filters.
 */
export declare const getFreeTierUsage: API.PaginatedOperationMethod<GetFreeTierUsageRequest, GetFreeTierUsageResponse, GetFreeTierUsageError, Credentials | HttpClient.HttpClient, FreeTierUsage>;
export type ListAccountActivitiesError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of activities that are available. This operation supports pagination and filtering by status.
 */
export declare const listAccountActivities: API.PaginatedOperationMethod<ListAccountActivitiesRequest, ListAccountActivitiesResponse, ListAccountActivitiesError, Credentials | HttpClient.HttpClient, ActivitySummary>;
export type UpgradeAccountPlanError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The account plan type for the Amazon Web Services account.
 */
export declare const upgradeAccountPlan: API.OperationMethod<UpgradeAccountPlanRequest, UpgradeAccountPlanResponse, UpgradeAccountPlanError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=freetier.d.ts.map