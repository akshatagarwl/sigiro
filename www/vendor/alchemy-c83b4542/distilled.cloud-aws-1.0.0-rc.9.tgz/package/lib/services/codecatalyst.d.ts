import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
export type AccessTokenName = string;
export interface CreateAccessTokenRequest {
    name: string;
    expiresTime?: Date;
}
export declare const CreateAccessTokenRequest: S.Schema<CreateAccessTokenRequest>;
export type AccessTokenSecret = string | redacted.Redacted<string>;
export type AccessTokenId = string;
export interface CreateAccessTokenResponse {
    secret: string | redacted.Redacted<string>;
    name: string;
    expiresTime: Date;
    accessTokenId: string;
}
export declare const CreateAccessTokenResponse: S.Schema<CreateAccessTokenResponse>;
export type NameString = string;
export type SourceRepositoryNameString = string;
export type SourceRepositoryBranchString = string;
export interface RepositoryInput {
    repositoryName: string;
    branchName?: string;
}
export declare const RepositoryInput: S.Schema<RepositoryInput>;
export type RepositoriesInput = RepositoryInput[];
export declare const RepositoriesInput: any;
export type ClientToken = string;
export interface IdeConfiguration {
    runtime?: string;
    name?: string;
}
export declare const IdeConfiguration: S.Schema<IdeConfiguration>;
export type IdeConfigurationList = IdeConfiguration[];
export declare const IdeConfigurationList: any;
export type InstanceType = string;
export type InactivityTimeoutMinutes = number;
export interface PersistentStorageConfiguration {
    sizeInGiB: number;
}
export declare const PersistentStorageConfiguration: S.Schema<PersistentStorageConfiguration>;
export interface CreateDevEnvironmentRequest {
    spaceName: string;
    projectName: string;
    repositories?: RepositoryInput[];
    clientToken?: string;
    alias?: string;
    ides?: IdeConfiguration[];
    instanceType: string;
    inactivityTimeoutMinutes?: number;
    persistentStorage: PersistentStorageConfiguration;
    vpcConnectionName?: string;
}
export declare const CreateDevEnvironmentRequest: S.Schema<CreateDevEnvironmentRequest>;
export type Uuid = string;
export interface CreateDevEnvironmentResponse {
    spaceName: string;
    projectName: string;
    id: string;
    vpcConnectionName?: string;
}
export declare const CreateDevEnvironmentResponse: S.Schema<CreateDevEnvironmentResponse>;
export type ProjectDisplayName = string;
export type ProjectDescription = string;
export interface CreateProjectRequest {
    spaceName: string;
    displayName: string;
    description?: string;
}
export declare const CreateProjectRequest: S.Schema<CreateProjectRequest>;
export interface CreateProjectResponse {
    spaceName?: string;
    name: string;
    displayName?: string;
    description?: string;
}
export declare const CreateProjectResponse: S.Schema<CreateProjectResponse>;
export type SourceRepositoryDescriptionString = string;
export interface CreateSourceRepositoryRequest {
    spaceName: string;
    projectName: string;
    name: string;
    description?: string;
}
export declare const CreateSourceRepositoryRequest: S.Schema<CreateSourceRepositoryRequest>;
export interface CreateSourceRepositoryResponse {
    spaceName: string;
    projectName: string;
    name: string;
    description?: string;
}
export declare const CreateSourceRepositoryResponse: S.Schema<CreateSourceRepositoryResponse>;
export interface CreateSourceRepositoryBranchRequest {
    spaceName: string;
    projectName: string;
    sourceRepositoryName: string;
    name: string;
    headCommitId?: string;
}
export declare const CreateSourceRepositoryBranchRequest: S.Schema<CreateSourceRepositoryBranchRequest>;
export type SourceRepositoryBranchRefString = string;
export interface CreateSourceRepositoryBranchResponse {
    ref?: string;
    name?: string;
    lastUpdatedTime?: Date;
    headCommitId?: string;
}
export declare const CreateSourceRepositoryBranchResponse: S.Schema<CreateSourceRepositoryBranchResponse>;
export interface DeleteAccessTokenRequest {
    id: string;
}
export declare const DeleteAccessTokenRequest: S.Schema<DeleteAccessTokenRequest>;
export interface DeleteAccessTokenResponse {
}
export declare const DeleteAccessTokenResponse: S.Schema<DeleteAccessTokenResponse>;
export interface DeleteDevEnvironmentRequest {
    spaceName: string;
    projectName: string;
    id: string;
}
export declare const DeleteDevEnvironmentRequest: S.Schema<DeleteDevEnvironmentRequest>;
export interface DeleteDevEnvironmentResponse {
    spaceName: string;
    projectName: string;
    id: string;
}
export declare const DeleteDevEnvironmentResponse: S.Schema<DeleteDevEnvironmentResponse>;
export interface DeleteProjectRequest {
    spaceName: string;
    name: string;
}
export declare const DeleteProjectRequest: S.Schema<DeleteProjectRequest>;
export interface DeleteProjectResponse {
    spaceName: string;
    name: string;
    displayName?: string;
}
export declare const DeleteProjectResponse: S.Schema<DeleteProjectResponse>;
export interface DeleteSourceRepositoryRequest {
    spaceName: string;
    projectName: string;
    name: string;
}
export declare const DeleteSourceRepositoryRequest: S.Schema<DeleteSourceRepositoryRequest>;
export interface DeleteSourceRepositoryResponse {
    spaceName: string;
    projectName: string;
    name: string;
}
export declare const DeleteSourceRepositoryResponse: S.Schema<DeleteSourceRepositoryResponse>;
export interface DeleteSpaceRequest {
    name: string;
}
export declare const DeleteSpaceRequest: S.Schema<DeleteSpaceRequest>;
export interface DeleteSpaceResponse {
    name: string;
    displayName?: string;
}
export declare const DeleteSpaceResponse: S.Schema<DeleteSpaceResponse>;
export interface GetDevEnvironmentRequest {
    spaceName: string;
    projectName: string;
    id: string;
}
export declare const GetDevEnvironmentRequest: S.Schema<GetDevEnvironmentRequest>;
export type DevEnvironmentStatus = string;
export type StatusReason = string;
export interface DevEnvironmentRepositorySummary {
    repositoryName: string;
    branchName?: string;
}
export declare const DevEnvironmentRepositorySummary: S.Schema<DevEnvironmentRepositorySummary>;
export type DevEnvironmentRepositorySummaries = DevEnvironmentRepositorySummary[];
export declare const DevEnvironmentRepositorySummaries: any;
export interface Ide {
    runtime?: string;
    name?: string;
}
export declare const Ide: S.Schema<Ide>;
export type Ides = Ide[];
export declare const Ides: any;
export interface PersistentStorage {
    sizeInGiB: number;
}
export declare const PersistentStorage: S.Schema<PersistentStorage>;
export interface GetDevEnvironmentResponse {
    spaceName: string;
    projectName: string;
    id: string;
    lastUpdatedTime: Date;
    creatorId: string;
    status: string;
    statusReason?: string;
    repositories: DevEnvironmentRepositorySummary[];
    alias?: string;
    ides?: Ide[];
    instanceType: string;
    inactivityTimeoutMinutes: number;
    persistentStorage: PersistentStorage;
    vpcConnectionName?: string;
}
export declare const GetDevEnvironmentResponse: S.Schema<GetDevEnvironmentResponse>;
export interface GetProjectRequest {
    spaceName: string;
    name: string;
}
export declare const GetProjectRequest: S.Schema<GetProjectRequest>;
export interface GetProjectResponse {
    spaceName?: string;
    name: string;
    displayName?: string;
    description?: string;
}
export declare const GetProjectResponse: S.Schema<GetProjectResponse>;
export interface GetSourceRepositoryRequest {
    spaceName: string;
    projectName: string;
    name: string;
}
export declare const GetSourceRepositoryRequest: S.Schema<GetSourceRepositoryRequest>;
export interface GetSourceRepositoryResponse {
    spaceName: string;
    projectName: string;
    name: string;
    description?: string;
    lastUpdatedTime: Date;
    createdTime: Date;
}
export declare const GetSourceRepositoryResponse: S.Schema<GetSourceRepositoryResponse>;
export interface GetSourceRepositoryCloneUrlsRequest {
    spaceName: string;
    projectName: string;
    sourceRepositoryName: string;
}
export declare const GetSourceRepositoryCloneUrlsRequest: S.Schema<GetSourceRepositoryCloneUrlsRequest>;
export interface GetSourceRepositoryCloneUrlsResponse {
    https: string;
}
export declare const GetSourceRepositoryCloneUrlsResponse: S.Schema<GetSourceRepositoryCloneUrlsResponse>;
export interface GetSpaceRequest {
    name: string;
}
export declare const GetSpaceRequest: S.Schema<GetSpaceRequest>;
export type RegionString = string;
export interface GetSpaceResponse {
    name: string;
    regionName: string;
    displayName?: string;
    description?: string;
}
export declare const GetSpaceResponse: S.Schema<GetSpaceResponse>;
export interface GetSubscriptionRequest {
    spaceName: string;
}
export declare const GetSubscriptionRequest: S.Schema<GetSubscriptionRequest>;
export interface GetSubscriptionResponse {
    subscriptionType?: string;
    awsAccountName?: string;
    pendingSubscriptionType?: string;
    pendingSubscriptionStartTime?: Date;
}
export declare const GetSubscriptionResponse: S.Schema<GetSubscriptionResponse>;
export interface GetUserDetailsRequest {
    id?: string;
    userName?: string;
}
export declare const GetUserDetailsRequest: S.Schema<GetUserDetailsRequest>;
export interface EmailAddress {
    email?: string;
    verified?: boolean;
}
export declare const EmailAddress: S.Schema<EmailAddress>;
export interface GetUserDetailsResponse {
    userId?: string;
    userName?: string;
    displayName?: string;
    primaryEmail?: EmailAddress;
    version?: string;
}
export declare const GetUserDetailsResponse: S.Schema<GetUserDetailsResponse>;
export interface GetWorkflowRequest {
    spaceName: string;
    id: string;
    projectName: string;
}
export declare const GetWorkflowRequest: S.Schema<GetWorkflowRequest>;
export interface WorkflowDefinition {
    path: string;
}
export declare const WorkflowDefinition: S.Schema<WorkflowDefinition>;
export type WorkflowRunMode = string;
export type WorkflowStatus = string;
export interface GetWorkflowResponse {
    spaceName: string;
    projectName: string;
    id: string;
    name: string;
    sourceRepositoryName?: string;
    sourceBranchName?: string;
    definition: WorkflowDefinition;
    createdTime: Date;
    lastUpdatedTime: Date;
    runMode: string;
    status: string;
}
export declare const GetWorkflowResponse: S.Schema<GetWorkflowResponse>;
export interface GetWorkflowRunRequest {
    spaceName: string;
    id: string;
    projectName: string;
}
export declare const GetWorkflowRunRequest: S.Schema<GetWorkflowRunRequest>;
export type WorkflowRunStatus = string;
export interface WorkflowRunStatusReason {
}
export declare const WorkflowRunStatusReason: S.Schema<WorkflowRunStatusReason>;
export type WorkflowRunStatusReasons = WorkflowRunStatusReason[];
export declare const WorkflowRunStatusReasons: any;
export interface GetWorkflowRunResponse {
    spaceName: string;
    projectName: string;
    id: string;
    workflowId: string;
    status: string;
    statusReasons?: WorkflowRunStatusReason[];
    startTime: Date;
    endTime?: Date;
    lastUpdatedTime: Date;
}
export declare const GetWorkflowRunResponse: S.Schema<GetWorkflowRunResponse>;
export interface ListAccessTokensRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAccessTokensRequest: S.Schema<ListAccessTokensRequest>;
export interface AccessTokenSummary {
    id: string;
    name: string;
    expiresTime?: Date;
}
export declare const AccessTokenSummary: S.Schema<AccessTokenSummary>;
export type AccessTokenSummaries = AccessTokenSummary[];
export declare const AccessTokenSummaries: any;
export interface ListAccessTokensResponse {
    items: AccessTokenSummary[];
    nextToken?: string;
}
export declare const ListAccessTokensResponse: S.Schema<ListAccessTokensResponse>;
export type StringList = string[];
export declare const StringList: any;
export interface Filter {
    key: string;
    values: string[];
    comparisonOperator?: string;
}
export declare const Filter: S.Schema<Filter>;
export type Filters = Filter[];
export declare const Filters: any;
export interface ListDevEnvironmentsRequest {
    spaceName: string;
    projectName?: string;
    filters?: Filter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDevEnvironmentsRequest: S.Schema<ListDevEnvironmentsRequest>;
export interface DevEnvironmentSummary {
    spaceName?: string;
    projectName?: string;
    id: string;
    lastUpdatedTime: Date;
    creatorId: string;
    status: string;
    statusReason?: string;
    repositories: DevEnvironmentRepositorySummary[];
    alias?: string;
    ides?: Ide[];
    instanceType: string;
    inactivityTimeoutMinutes: number;
    persistentStorage: PersistentStorage;
    vpcConnectionName?: string;
}
export declare const DevEnvironmentSummary: S.Schema<DevEnvironmentSummary>;
export type DevEnvironmentSummaryList = DevEnvironmentSummary[];
export declare const DevEnvironmentSummaryList: any;
export interface ListDevEnvironmentsResponse {
    items: DevEnvironmentSummary[];
    nextToken?: string;
}
export declare const ListDevEnvironmentsResponse: S.Schema<ListDevEnvironmentsResponse>;
export interface ListDevEnvironmentSessionsRequest {
    spaceName: string;
    projectName: string;
    devEnvironmentId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDevEnvironmentSessionsRequest: S.Schema<ListDevEnvironmentSessionsRequest>;
export interface DevEnvironmentSessionSummary {
    spaceName: string;
    projectName: string;
    devEnvironmentId: string;
    startedTime: Date;
    id: string;
}
export declare const DevEnvironmentSessionSummary: S.Schema<DevEnvironmentSessionSummary>;
export type DevEnvironmentSessionsSummaryList = DevEnvironmentSessionSummary[];
export declare const DevEnvironmentSessionsSummaryList: any;
export interface ListDevEnvironmentSessionsResponse {
    items: DevEnvironmentSessionSummary[];
    nextToken?: string;
}
export declare const ListDevEnvironmentSessionsResponse: S.Schema<ListDevEnvironmentSessionsResponse>;
export interface ListEventLogsRequest {
    spaceName: string;
    startTime: Date;
    endTime: Date;
    eventName?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListEventLogsRequest: S.Schema<ListEventLogsRequest>;
export type OperationType = string;
export type UserType = string;
export interface UserIdentity {
    userType: string;
    principalId: string;
    userName?: string;
    awsAccountId?: string;
}
export declare const UserIdentity: S.Schema<UserIdentity>;
export interface ProjectInformation {
    name?: string;
    projectId?: string;
}
export declare const ProjectInformation: S.Schema<ProjectInformation>;
export interface EventPayload {
    contentType?: string;
    data?: string;
}
export declare const EventPayload: S.Schema<EventPayload>;
export interface EventLogEntry {
    id: string;
    eventName: string;
    eventType: string;
    eventCategory: string;
    eventSource: string;
    eventTime: Date;
    operationType: string;
    userIdentity: UserIdentity;
    projectInformation?: ProjectInformation;
    requestId?: string;
    requestPayload?: EventPayload;
    responsePayload?: EventPayload;
    errorCode?: string;
    sourceIpAddress?: string;
    userAgent?: string;
}
export declare const EventLogEntry: S.Schema<EventLogEntry>;
export type EventLogEntries = EventLogEntry[];
export declare const EventLogEntries: any;
export interface ListEventLogsResponse {
    nextToken?: string;
    items: EventLogEntry[];
}
export declare const ListEventLogsResponse: S.Schema<ListEventLogsResponse>;
export type FilterKey = string;
export type ComparisonOperator = string;
export interface ProjectListFilter {
    key: string;
    values: string[];
    comparisonOperator?: string;
}
export declare const ProjectListFilter: S.Schema<ProjectListFilter>;
export type ProjectListFilters = ProjectListFilter[];
export declare const ProjectListFilters: any;
export interface ListProjectsRequest {
    spaceName: string;
    nextToken?: string;
    maxResults?: number;
    filters?: ProjectListFilter[];
}
export declare const ListProjectsRequest: S.Schema<ListProjectsRequest>;
export interface ProjectSummary {
    name: string;
    displayName?: string;
    description?: string;
}
export declare const ProjectSummary: S.Schema<ProjectSummary>;
export type ProjectSummaries = ProjectSummary[];
export declare const ProjectSummaries: any;
export interface ListProjectsResponse {
    nextToken?: string;
    items?: ProjectSummary[];
}
export declare const ListProjectsResponse: S.Schema<ListProjectsResponse>;
export interface ListSourceRepositoriesRequest {
    spaceName: string;
    projectName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListSourceRepositoriesRequest: S.Schema<ListSourceRepositoriesRequest>;
export type SourceRepositoryIdString = string;
export interface ListSourceRepositoriesItem {
    id: string;
    name: string;
    description?: string;
    lastUpdatedTime: Date;
    createdTime: Date;
}
export declare const ListSourceRepositoriesItem: S.Schema<ListSourceRepositoriesItem>;
export type ListSourceRepositoriesItems = ListSourceRepositoriesItem[];
export declare const ListSourceRepositoriesItems: any;
export interface ListSourceRepositoriesResponse {
    items?: ListSourceRepositoriesItem[];
    nextToken?: string;
}
export declare const ListSourceRepositoriesResponse: S.Schema<ListSourceRepositoriesResponse>;
export interface ListSourceRepositoryBranchesRequest {
    spaceName: string;
    projectName: string;
    sourceRepositoryName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListSourceRepositoryBranchesRequest: S.Schema<ListSourceRepositoryBranchesRequest>;
export interface ListSourceRepositoryBranchesItem {
    ref?: string;
    name?: string;
    lastUpdatedTime?: Date;
    headCommitId?: string;
}
export declare const ListSourceRepositoryBranchesItem: S.Schema<ListSourceRepositoryBranchesItem>;
export type ListSourceRepositoryBranchesItems = ListSourceRepositoryBranchesItem[];
export declare const ListSourceRepositoryBranchesItems: any;
export interface ListSourceRepositoryBranchesResponse {
    nextToken?: string;
    items: ListSourceRepositoryBranchesItem[];
}
export declare const ListSourceRepositoryBranchesResponse: S.Schema<ListSourceRepositoryBranchesResponse>;
export interface ListSpacesRequest {
    nextToken?: string;
}
export declare const ListSpacesRequest: S.Schema<ListSpacesRequest>;
export interface SpaceSummary {
    name: string;
    regionName: string;
    displayName?: string;
    description?: string;
}
export declare const SpaceSummary: S.Schema<SpaceSummary>;
export type SpaceSummaries = SpaceSummary[];
export declare const SpaceSummaries: any;
export interface ListSpacesResponse {
    nextToken?: string;
    items?: SpaceSummary[];
}
export declare const ListSpacesResponse: S.Schema<ListSpacesResponse>;
export interface WorkflowRunSortCriteria {
}
export declare const WorkflowRunSortCriteria: S.Schema<WorkflowRunSortCriteria>;
export type WorkflowRunSortCriteriaList = WorkflowRunSortCriteria[];
export declare const WorkflowRunSortCriteriaList: any;
export interface ListWorkflowRunsRequest {
    spaceName: string;
    workflowId?: string;
    projectName: string;
    nextToken?: string;
    maxResults?: number;
    sortBy?: WorkflowRunSortCriteria[];
}
export declare const ListWorkflowRunsRequest: S.Schema<ListWorkflowRunsRequest>;
export interface WorkflowRunSummary {
    id: string;
    workflowId: string;
    workflowName: string;
    status: string;
    statusReasons?: WorkflowRunStatusReason[];
    startTime: Date;
    endTime?: Date;
    lastUpdatedTime: Date;
}
export declare const WorkflowRunSummary: S.Schema<WorkflowRunSummary>;
export type WorkflowRunSummaries = WorkflowRunSummary[];
export declare const WorkflowRunSummaries: any;
export interface ListWorkflowRunsResponse {
    nextToken?: string;
    items?: WorkflowRunSummary[];
}
export declare const ListWorkflowRunsResponse: S.Schema<ListWorkflowRunsResponse>;
export interface WorkflowSortCriteria {
}
export declare const WorkflowSortCriteria: S.Schema<WorkflowSortCriteria>;
export type WorkflowSortCriteriaList = WorkflowSortCriteria[];
export declare const WorkflowSortCriteriaList: any;
export interface ListWorkflowsRequest {
    spaceName: string;
    projectName: string;
    nextToken?: string;
    maxResults?: number;
    sortBy?: WorkflowSortCriteria[];
}
export declare const ListWorkflowsRequest: S.Schema<ListWorkflowsRequest>;
export interface WorkflowDefinitionSummary {
    path: string;
}
export declare const WorkflowDefinitionSummary: S.Schema<WorkflowDefinitionSummary>;
export interface WorkflowSummary {
    id: string;
    name: string;
    sourceRepositoryName: string;
    sourceBranchName: string;
    definition: WorkflowDefinitionSummary;
    createdTime: Date;
    lastUpdatedTime: Date;
    runMode: string;
    status: string;
}
export declare const WorkflowSummary: S.Schema<WorkflowSummary>;
export type WorkflowSummaries = WorkflowSummary[];
export declare const WorkflowSummaries: any;
export interface ListWorkflowsResponse {
    nextToken?: string;
    items?: WorkflowSummary[];
}
export declare const ListWorkflowsResponse: S.Schema<ListWorkflowsResponse>;
export interface StartDevEnvironmentRequest {
    spaceName: string;
    projectName: string;
    id: string;
    ides?: IdeConfiguration[];
    instanceType?: string;
    inactivityTimeoutMinutes?: number;
}
export declare const StartDevEnvironmentRequest: S.Schema<StartDevEnvironmentRequest>;
export interface StartDevEnvironmentResponse {
    spaceName: string;
    projectName: string;
    id: string;
    status: string;
}
export declare const StartDevEnvironmentResponse: S.Schema<StartDevEnvironmentResponse>;
export type DevEnvironmentSessionType = string;
export type ExecuteCommandSessionConfigurationArguments = string[];
export declare const ExecuteCommandSessionConfigurationArguments: any;
export interface ExecuteCommandSessionConfiguration {
    command: string;
    arguments?: string[];
}
export declare const ExecuteCommandSessionConfiguration: S.Schema<ExecuteCommandSessionConfiguration>;
export interface DevEnvironmentSessionConfiguration {
    sessionType: string;
    executeCommandSessionConfiguration?: ExecuteCommandSessionConfiguration;
}
export declare const DevEnvironmentSessionConfiguration: S.Schema<DevEnvironmentSessionConfiguration>;
export interface StartDevEnvironmentSessionRequest {
    spaceName: string;
    projectName: string;
    id: string;
    sessionConfiguration: DevEnvironmentSessionConfiguration;
}
export declare const StartDevEnvironmentSessionRequest: S.Schema<StartDevEnvironmentSessionRequest>;
export type SensitiveString = string | redacted.Redacted<string>;
export interface DevEnvironmentAccessDetails {
    streamUrl: string | redacted.Redacted<string>;
    tokenValue: string | redacted.Redacted<string>;
}
export declare const DevEnvironmentAccessDetails: S.Schema<DevEnvironmentAccessDetails>;
export interface StartDevEnvironmentSessionResponse {
    accessDetails: DevEnvironmentAccessDetails;
    sessionId?: string;
    spaceName: string;
    projectName: string;
    id: string;
}
export declare const StartDevEnvironmentSessionResponse: S.Schema<StartDevEnvironmentSessionResponse>;
export interface StartWorkflowRunRequest {
    spaceName: string;
    projectName: string;
    workflowId: string;
    clientToken?: string;
}
export declare const StartWorkflowRunRequest: S.Schema<StartWorkflowRunRequest>;
export interface StartWorkflowRunResponse {
    spaceName: string;
    projectName: string;
    id: string;
    workflowId: string;
}
export declare const StartWorkflowRunResponse: S.Schema<StartWorkflowRunResponse>;
export interface StopDevEnvironmentRequest {
    spaceName: string;
    projectName: string;
    id: string;
}
export declare const StopDevEnvironmentRequest: S.Schema<StopDevEnvironmentRequest>;
export interface StopDevEnvironmentResponse {
    spaceName: string;
    projectName: string;
    id: string;
    status: string;
}
export declare const StopDevEnvironmentResponse: S.Schema<StopDevEnvironmentResponse>;
export interface StopDevEnvironmentSessionRequest {
    spaceName: string;
    projectName: string;
    id: string;
    sessionId: string;
}
export declare const StopDevEnvironmentSessionRequest: S.Schema<StopDevEnvironmentSessionRequest>;
export interface StopDevEnvironmentSessionResponse {
    spaceName: string;
    projectName: string;
    id: string;
    sessionId: string;
}
export declare const StopDevEnvironmentSessionResponse: S.Schema<StopDevEnvironmentSessionResponse>;
export interface UpdateDevEnvironmentRequest {
    spaceName: string;
    projectName: string;
    id: string;
    alias?: string;
    ides?: IdeConfiguration[];
    instanceType?: string;
    inactivityTimeoutMinutes?: number;
    clientToken?: string;
}
export declare const UpdateDevEnvironmentRequest: S.Schema<UpdateDevEnvironmentRequest>;
export interface UpdateDevEnvironmentResponse {
    id: string;
    spaceName: string;
    projectName: string;
    alias?: string;
    ides?: IdeConfiguration[];
    instanceType?: string;
    inactivityTimeoutMinutes?: number;
    clientToken?: string;
}
export declare const UpdateDevEnvironmentResponse: S.Schema<UpdateDevEnvironmentResponse>;
export interface UpdateProjectRequest {
    spaceName: string;
    name: string;
    description?: string;
}
export declare const UpdateProjectRequest: S.Schema<UpdateProjectRequest>;
export interface UpdateProjectResponse {
    spaceName?: string;
    name?: string;
    displayName?: string;
    description?: string;
}
export declare const UpdateProjectResponse: S.Schema<UpdateProjectResponse>;
export type SpaceDescription = string;
export interface UpdateSpaceRequest {
    name: string;
    description?: string;
}
export declare const UpdateSpaceRequest: S.Schema<UpdateSpaceRequest>;
export interface UpdateSpaceResponse {
    name?: string;
    displayName?: string;
    description?: string;
}
export declare const UpdateSpaceResponse: S.Schema<UpdateSpaceResponse>;
export interface VerifySessionRequest {
}
export declare const VerifySessionRequest: S.Schema<VerifySessionRequest>;
export interface VerifySessionResponse {
    identity?: string;
}
export declare const VerifySessionResponse: S.Schema<VerifySessionResponse>;
export type CreateAccessTokenError = CommonErrors;
/**
 * Creates a personal access token (PAT) for the current user. A personal access token (PAT) is similar to a password.
 * It is associated with your user identity for use across all spaces and projects in Amazon CodeCatalyst. You use PATs to access CodeCatalyst
 * from resources that include integrated development environments (IDEs) and Git-based source repositories.
 * PATs represent you in Amazon CodeCatalyst and you can manage them in your user settings.For more information, see
 * Managing personal access tokens in Amazon CodeCatalyst.
 */
export declare const createAccessToken: API.OperationMethod<CreateAccessTokenRequest, CreateAccessTokenResponse, CreateAccessTokenError, Credentials | HttpClient.HttpClient>;
export type CreateDevEnvironmentError = CommonErrors;
/**
 * Creates a Dev Environment in Amazon CodeCatalyst, a cloud-based development environment that you can use to quickly work on the code stored
 * in the source repositories of your project.
 *
 * When created in the Amazon CodeCatalyst console, by default a Dev Environment is configured to have a 2 core processor, 4GB of RAM, and 16GB of persistent storage. None of these
 * defaults apply to a Dev Environment created programmatically.
 */
export declare const createDevEnvironment: API.OperationMethod<CreateDevEnvironmentRequest, CreateDevEnvironmentResponse, CreateDevEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateProjectError = CommonErrors;
/**
 * Creates a project in a specified space.
 */
export declare const createProject: API.OperationMethod<CreateProjectRequest, CreateProjectResponse, CreateProjectError, Credentials | HttpClient.HttpClient>;
export type CreateSourceRepositoryError = CommonErrors;
/**
 * Creates an empty Git-based source repository in a specified project. The repository is
 * created with an initial empty commit with a default branch named `main`.
 */
export declare const createSourceRepository: API.OperationMethod<CreateSourceRepositoryRequest, CreateSourceRepositoryResponse, CreateSourceRepositoryError, Credentials | HttpClient.HttpClient>;
export type CreateSourceRepositoryBranchError = CommonErrors;
/**
 * Creates a branch in a specified source repository in Amazon CodeCatalyst.
 *
 * This API only creates a branch in a source repository hosted in Amazon CodeCatalyst. You cannot use this API to create a branch in a linked repository.
 */
export declare const createSourceRepositoryBranch: API.OperationMethod<CreateSourceRepositoryBranchRequest, CreateSourceRepositoryBranchResponse, CreateSourceRepositoryBranchError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessTokenError = CommonErrors;
/**
 * Deletes a specified personal access token (PAT). A personal access token can only be deleted by the user who created it.
 */
export declare const deleteAccessToken: API.OperationMethod<DeleteAccessTokenRequest, DeleteAccessTokenResponse, DeleteAccessTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteDevEnvironmentError = CommonErrors;
/**
 * Deletes a Dev Environment.
 */
export declare const deleteDevEnvironment: API.OperationMethod<DeleteDevEnvironmentRequest, DeleteDevEnvironmentResponse, DeleteDevEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectError = CommonErrors;
/**
 * Deletes a project in a space.
 */
export declare const deleteProject: API.OperationMethod<DeleteProjectRequest, DeleteProjectResponse, DeleteProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteSourceRepositoryError = CommonErrors;
/**
 * Deletes a source repository in Amazon CodeCatalyst. You cannot use this API to delete a linked repository. It can only be used to delete a Amazon CodeCatalyst source repository.
 */
export declare const deleteSourceRepository: API.OperationMethod<DeleteSourceRepositoryRequest, DeleteSourceRepositoryResponse, DeleteSourceRepositoryError, Credentials | HttpClient.HttpClient>;
export type DeleteSpaceError = CommonErrors;
/**
 * Deletes a space.
 *
 * Deleting a space cannot be undone. Additionally, since space names must be unique across Amazon CodeCatalyst, you cannot reuse names of deleted spaces.
 */
export declare const deleteSpace: API.OperationMethod<DeleteSpaceRequest, DeleteSpaceResponse, DeleteSpaceError, Credentials | HttpClient.HttpClient>;
export type GetDevEnvironmentError = CommonErrors;
/**
 * Returns information about a Dev Environment for a source repository in a project. Dev Environments are specific to the user who creates them.
 */
export declare const getDevEnvironment: API.OperationMethod<GetDevEnvironmentRequest, GetDevEnvironmentResponse, GetDevEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetProjectError = CommonErrors;
/**
 * Returns information about a project.
 */
export declare const getProject: API.OperationMethod<GetProjectRequest, GetProjectResponse, GetProjectError, Credentials | HttpClient.HttpClient>;
export type GetSourceRepositoryError = CommonErrors;
/**
 * Returns information about a source repository.
 */
export declare const getSourceRepository: API.OperationMethod<GetSourceRepositoryRequest, GetSourceRepositoryResponse, GetSourceRepositoryError, Credentials | HttpClient.HttpClient>;
export type GetSourceRepositoryCloneUrlsError = CommonErrors;
/**
 * Returns information about the URLs that can be used with a Git client to clone a source
 * repository.
 */
export declare const getSourceRepositoryCloneUrls: API.OperationMethod<GetSourceRepositoryCloneUrlsRequest, GetSourceRepositoryCloneUrlsResponse, GetSourceRepositoryCloneUrlsError, Credentials | HttpClient.HttpClient>;
export type GetSpaceError = CommonErrors;
/**
 * Returns information about an space.
 */
export declare const getSpace: API.OperationMethod<GetSpaceRequest, GetSpaceResponse, GetSpaceError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionError = CommonErrors;
/**
 * Returns information about the Amazon Web Services account used for billing purposes
 * and the billing plan for the space.
 */
export declare const getSubscription: API.OperationMethod<GetSubscriptionRequest, GetSubscriptionResponse, GetSubscriptionError, Credentials | HttpClient.HttpClient>;
export type GetUserDetailsError = CommonErrors;
/**
 * Returns information about a user.
 */
export declare const getUserDetails: API.OperationMethod<GetUserDetailsRequest, GetUserDetailsResponse, GetUserDetailsError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowError = CommonErrors;
/**
 * Returns information about a workflow.
 */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest, GetWorkflowResponse, GetWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowRunError = CommonErrors;
/**
 * Returns information about a specified run of a workflow.
 */
export declare const getWorkflowRun: API.OperationMethod<GetWorkflowRunRequest, GetWorkflowRunResponse, GetWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type ListAccessTokensError = CommonErrors;
/**
 * Lists all personal access tokens (PATs) associated with the user who calls the API. You can only list PATs associated with your Amazon Web Services Builder ID.
 */
export declare const listAccessTokens: API.PaginatedOperationMethod<ListAccessTokensRequest, ListAccessTokensResponse, ListAccessTokensError, Credentials | HttpClient.HttpClient, AccessTokenSummary>;
export type ListDevEnvironmentsError = CommonErrors;
/**
 * Retrieves a list of Dev Environments in a project.
 */
export declare const listDevEnvironments: API.PaginatedOperationMethod<ListDevEnvironmentsRequest, ListDevEnvironmentsResponse, ListDevEnvironmentsError, Credentials | HttpClient.HttpClient, DevEnvironmentSummary>;
export type ListDevEnvironmentSessionsError = CommonErrors;
/**
 * Retrieves a list of active sessions for a Dev Environment in a project.
 */
export declare const listDevEnvironmentSessions: API.PaginatedOperationMethod<ListDevEnvironmentSessionsRequest, ListDevEnvironmentSessionsResponse, ListDevEnvironmentSessionsError, Credentials | HttpClient.HttpClient, DevEnvironmentSessionSummary>;
export type ListEventLogsError = CommonErrors;
/**
 * Retrieves a list of events that occurred during a specific time in a space. You can
 * use these events to audit user and system activity in a space. For more information, see
 * Monitoring in the *Amazon CodeCatalyst User Guide*.
 *
 * ListEventLogs guarantees events for the last 30 days in a given space. You can also
 * view and retrieve a list of management events over the last 90 days for Amazon CodeCatalyst in the
 * CloudTrail console by viewing Event history, or by creating a trail to create
 * and maintain a record of events that extends past 90 days. For more information, see Working with CloudTrail Event History and Working with
 * CloudTrail trails.
 */
export declare const listEventLogs: API.PaginatedOperationMethod<ListEventLogsRequest, ListEventLogsResponse, ListEventLogsError, Credentials | HttpClient.HttpClient, EventLogEntry>;
export type ListProjectsError = CommonErrors;
/**
 * Retrieves a list of projects.
 */
export declare const listProjects: API.PaginatedOperationMethod<ListProjectsRequest, ListProjectsResponse, ListProjectsError, Credentials | HttpClient.HttpClient, ProjectSummary>;
export type ListSourceRepositoriesError = CommonErrors;
/**
 * Retrieves a list of source repositories in a project.
 */
export declare const listSourceRepositories: API.PaginatedOperationMethod<ListSourceRepositoriesRequest, ListSourceRepositoriesResponse, ListSourceRepositoriesError, Credentials | HttpClient.HttpClient, ListSourceRepositoriesItem>;
export type ListSourceRepositoryBranchesError = CommonErrors;
/**
 * Retrieves a list of branches in a specified source repository.
 */
export declare const listSourceRepositoryBranches: API.PaginatedOperationMethod<ListSourceRepositoryBranchesRequest, ListSourceRepositoryBranchesResponse, ListSourceRepositoryBranchesError, Credentials | HttpClient.HttpClient, ListSourceRepositoryBranchesItem>;
export type ListSpacesError = CommonErrors;
/**
 * Retrieves a list of spaces.
 */
export declare const listSpaces: API.PaginatedOperationMethod<ListSpacesRequest, ListSpacesResponse, ListSpacesError, Credentials | HttpClient.HttpClient, SpaceSummary>;
export type ListWorkflowRunsError = CommonErrors;
/**
 * Retrieves a list of workflow runs of a specified workflow.
 */
export declare const listWorkflowRuns: API.PaginatedOperationMethod<ListWorkflowRunsRequest, ListWorkflowRunsResponse, ListWorkflowRunsError, Credentials | HttpClient.HttpClient, WorkflowRunSummary>;
export type ListWorkflowsError = CommonErrors;
/**
 * Retrieves a list of workflows in a specified project.
 */
export declare const listWorkflows: API.PaginatedOperationMethod<ListWorkflowsRequest, ListWorkflowsResponse, ListWorkflowsError, Credentials | HttpClient.HttpClient, WorkflowSummary>;
export type StartDevEnvironmentError = CommonErrors;
/**
 * Starts a specified Dev Environment and puts it into an active state.
 */
export declare const startDevEnvironment: API.OperationMethod<StartDevEnvironmentRequest, StartDevEnvironmentResponse, StartDevEnvironmentError, Credentials | HttpClient.HttpClient>;
export type StartDevEnvironmentSessionError = CommonErrors;
/**
 * Starts a session for a specified Dev Environment.
 */
export declare const startDevEnvironmentSession: API.OperationMethod<StartDevEnvironmentSessionRequest, StartDevEnvironmentSessionResponse, StartDevEnvironmentSessionError, Credentials | HttpClient.HttpClient>;
export type StartWorkflowRunError = CommonErrors;
/**
 * Begins a run of a specified workflow.
 */
export declare const startWorkflowRun: API.OperationMethod<StartWorkflowRunRequest, StartWorkflowRunResponse, StartWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type StopDevEnvironmentError = CommonErrors;
/**
 * Pauses a specified Dev Environment and places it in a non-running state. Stopped Dev Environments do not consume compute minutes.
 */
export declare const stopDevEnvironment: API.OperationMethod<StopDevEnvironmentRequest, StopDevEnvironmentResponse, StopDevEnvironmentError, Credentials | HttpClient.HttpClient>;
export type StopDevEnvironmentSessionError = CommonErrors;
/**
 * Stops a session for a specified Dev Environment.
 */
export declare const stopDevEnvironmentSession: API.OperationMethod<StopDevEnvironmentSessionRequest, StopDevEnvironmentSessionResponse, StopDevEnvironmentSessionError, Credentials | HttpClient.HttpClient>;
export type UpdateDevEnvironmentError = CommonErrors;
/**
 * Changes one or more values for a Dev Environment. Updating certain values of the Dev Environment will cause a restart.
 */
export declare const updateDevEnvironment: API.OperationMethod<UpdateDevEnvironmentRequest, UpdateDevEnvironmentResponse, UpdateDevEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateProjectError = CommonErrors;
/**
 * Changes one or more values for a project.
 */
export declare const updateProject: API.OperationMethod<UpdateProjectRequest, UpdateProjectResponse, UpdateProjectError, Credentials | HttpClient.HttpClient>;
export type UpdateSpaceError = CommonErrors;
/**
 * Changes one or more values for a space.
 */
export declare const updateSpace: API.OperationMethod<UpdateSpaceRequest, UpdateSpaceResponse, UpdateSpaceError, Credentials | HttpClient.HttpClient>;
export type VerifySessionError = CommonErrors;
/**
 * Verifies whether the calling user has a valid Amazon CodeCatalyst login and session. If successful, this returns the ID of the user in Amazon CodeCatalyst.
 */
export declare const verifySession: API.OperationMethod<VerifySessionRequest, VerifySessionResponse, VerifySessionError, Credentials | HttpClient.HttpClient>;
//# sourceMappingURL=codecatalyst.d.ts.map