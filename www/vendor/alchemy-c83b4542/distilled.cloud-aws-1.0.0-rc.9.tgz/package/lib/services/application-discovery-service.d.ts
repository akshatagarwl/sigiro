import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AuthorizationErrorException_base: S.Class<AuthorizationErrorException, S.TaggedStruct<"AuthorizationErrorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AuthorizationErrorException extends /*@__PURE__*/ AuthorizationErrorException_base {
}
declare const ConflictErrorException_base: S.Class<ConflictErrorException, S.TaggedStruct<"ConflictErrorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictErrorException extends /*@__PURE__*/ ConflictErrorException_base {
}
declare const HomeRegionNotSetException_base: S.Class<HomeRegionNotSetException, S.TaggedStruct<"HomeRegionNotSetException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class HomeRegionNotSetException extends /*@__PURE__*/ HomeRegionNotSetException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidParameterValueException_base: S.Class<InvalidParameterValueException, S.TaggedStruct<"InvalidParameterValueException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const OperationNotPermittedException_base: S.Class<OperationNotPermittedException, S.TaggedStruct<"OperationNotPermittedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class OperationNotPermittedException extends /*@__PURE__*/ OperationNotPermittedException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServerInternalErrorException_base: S.Class<ServerInternalErrorException, S.TaggedStruct<"ServerInternalErrorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServerInternalErrorException extends /*@__PURE__*/ ServerInternalErrorException_base {
}
export type ApplicationId = string;
export type ConfigurationId = string;
export type ConfigurationIdList = string[];
export declare const ConfigurationIdList: any;
export interface AssociateConfigurationItemsToApplicationRequest {
    applicationConfigurationId: string;
    configurationIds: string[];
}
export declare const AssociateConfigurationItemsToApplicationRequest: S.Schema<AssociateConfigurationItemsToApplicationRequest>;
export interface AssociateConfigurationItemsToApplicationResponse {
}
export declare const AssociateConfigurationItemsToApplicationResponse: S.Schema<AssociateConfigurationItemsToApplicationResponse>;
export type AgentId = string;
export interface DeleteAgent {
    agentId: string;
    force?: boolean;
}
export declare const DeleteAgent: S.Schema<DeleteAgent>;
export type DeleteAgents = DeleteAgent[];
export declare const DeleteAgents: any;
export interface BatchDeleteAgentsRequest {
    deleteAgents: DeleteAgent[];
}
export declare const BatchDeleteAgentsRequest: S.Schema<BatchDeleteAgentsRequest>;
export type DeleteAgentErrorCode = "NOT_FOUND" | "INTERNAL_SERVER_ERROR" | "AGENT_IN_USE" | (string & {});
export declare const DeleteAgentErrorCode: any;
export interface BatchDeleteAgentError {
    agentId: string;
    errorMessage: string;
    errorCode: DeleteAgentErrorCode;
}
export declare const BatchDeleteAgentError: S.Schema<BatchDeleteAgentError>;
export type BatchDeleteAgentErrors = BatchDeleteAgentError[];
export declare const BatchDeleteAgentErrors: any;
export interface BatchDeleteAgentsResponse {
    errors?: BatchDeleteAgentError[];
}
export declare const BatchDeleteAgentsResponse: S.Schema<BatchDeleteAgentsResponse>;
export type ImportTaskIdentifier = string;
export type ToDeleteIdentifierList = string[];
export declare const ToDeleteIdentifierList: any;
export interface BatchDeleteImportDataRequest {
    importTaskIds: string[];
    deleteHistory?: boolean;
}
export declare const BatchDeleteImportDataRequest: S.Schema<BatchDeleteImportDataRequest>;
export type BatchDeleteImportDataErrorCode = "NOT_FOUND" | "INTERNAL_SERVER_ERROR" | "OVER_LIMIT" | (string & {});
export declare const BatchDeleteImportDataErrorCode: any;
export type BatchDeleteImportDataErrorDescription = string;
export interface BatchDeleteImportDataError_ {
    importTaskId?: string;
    errorCode?: BatchDeleteImportDataErrorCode;
    errorDescription?: string;
}
export declare const BatchDeleteImportDataError_: S.Schema<BatchDeleteImportDataError_>;
export type BatchDeleteImportDataErrorList = BatchDeleteImportDataError_[];
export declare const BatchDeleteImportDataErrorList: any;
export interface BatchDeleteImportDataResponse {
    errors?: BatchDeleteImportDataError_[];
}
export declare const BatchDeleteImportDataResponse: S.Schema<BatchDeleteImportDataResponse>;
export type ApplicationName = string;
export type ApplicationDescription = string;
export type ApplicationWave = string;
export interface CreateApplicationRequest {
    name: string;
    description?: string;
    wave?: string;
}
export declare const CreateApplicationRequest: S.Schema<CreateApplicationRequest>;
export interface CreateApplicationResponse {
    configurationId?: string;
}
export declare const CreateApplicationResponse: S.Schema<CreateApplicationResponse>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagSet = Tag[];
export declare const TagSet: any;
export interface CreateTagsRequest {
    configurationIds: string[];
    tags: Tag[];
}
export declare const CreateTagsRequest: S.Schema<CreateTagsRequest>;
export interface CreateTagsResponse {
}
export declare const CreateTagsResponse: S.Schema<CreateTagsResponse>;
export type ApplicationIdsList = string[];
export declare const ApplicationIdsList: any;
export interface DeleteApplicationsRequest {
    configurationIds: string[];
}
export declare const DeleteApplicationsRequest: S.Schema<DeleteApplicationsRequest>;
export interface DeleteApplicationsResponse {
}
export declare const DeleteApplicationsResponse: S.Schema<DeleteApplicationsResponse>;
export interface DeleteTagsRequest {
    configurationIds: string[];
    tags?: Tag[];
}
export declare const DeleteTagsRequest: S.Schema<DeleteTagsRequest>;
export interface DeleteTagsResponse {
}
export declare const DeleteTagsResponse: S.Schema<DeleteTagsResponse>;
export type AgentIds = string[];
export declare const AgentIds: any;
export type FilterValue = string;
export type FilterValues = string[];
export declare const FilterValues: any;
export type Condition = string;
export interface Filter {
    name: string;
    values: string[];
    condition: string;
}
export declare const Filter: S.Schema<Filter>;
export type Filters = Filter[];
export declare const Filters: any;
export type NextToken = string;
export interface DescribeAgentsRequest {
    agentIds?: string[];
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeAgentsRequest: S.Schema<DescribeAgentsRequest>;
export interface AgentNetworkInfo {
    ipAddress?: string;
    macAddress?: string;
}
export declare const AgentNetworkInfo: S.Schema<AgentNetworkInfo>;
export type AgentNetworkInfoList = AgentNetworkInfo[];
export declare const AgentNetworkInfoList: any;
export type AgentStatus = "HEALTHY" | "UNHEALTHY" | "RUNNING" | "UNKNOWN" | "BLACKLISTED" | "SHUTDOWN" | (string & {});
export declare const AgentStatus: any;
export interface AgentInfo {
    agentId?: string;
    hostName?: string;
    agentNetworkInfoList?: AgentNetworkInfo[];
    connectorId?: string;
    version?: string;
    health?: AgentStatus;
    lastHealthPingTime?: string;
    collectionStatus?: string;
    agentType?: string;
    registeredTime?: string;
}
export declare const AgentInfo: S.Schema<AgentInfo>;
export type AgentsInfo = AgentInfo[];
export declare const AgentsInfo: any;
export interface DescribeAgentsResponse {
    agentsInfo?: AgentInfo[];
    nextToken?: string;
}
export declare const DescribeAgentsResponse: S.Schema<DescribeAgentsResponse>;
export type UUID = string;
export interface DescribeBatchDeleteConfigurationTaskRequest {
    taskId: string;
}
export declare const DescribeBatchDeleteConfigurationTaskRequest: S.Schema<DescribeBatchDeleteConfigurationTaskRequest>;
export type BatchDeleteConfigurationTaskStatus = "INITIALIZING" | "VALIDATING" | "DELETING" | "COMPLETED" | "FAILED" | (string & {});
export declare const BatchDeleteConfigurationTaskStatus: any;
export type DeletionConfigurationItemType = "SERVER" | (string & {});
export declare const DeletionConfigurationItemType: any;
export type ErrorStatusCode = number;
export type ErrorMessage = string;
export interface FailedConfiguration {
    configurationId?: string;
    errorStatusCode?: number;
    errorMessage?: string;
}
export declare const FailedConfiguration: S.Schema<FailedConfiguration>;
export type FailedConfigurationList = FailedConfiguration[];
export declare const FailedConfigurationList: any;
export type WarningCode = number;
export type WarningText = string;
export interface DeletionWarning {
    configurationId?: string;
    warningCode?: number;
    warningText?: string;
}
export declare const DeletionWarning: S.Schema<DeletionWarning>;
export type DeletionWarningsList = DeletionWarning[];
export declare const DeletionWarningsList: any;
export interface BatchDeleteConfigurationTask {
    taskId?: string;
    status?: BatchDeleteConfigurationTaskStatus;
    startTime?: Date;
    endTime?: Date;
    configurationType?: DeletionConfigurationItemType;
    requestedConfigurations?: string[];
    deletedConfigurations?: string[];
    failedConfigurations?: FailedConfiguration[];
    deletionWarnings?: DeletionWarning[];
}
export declare const BatchDeleteConfigurationTask: S.Schema<BatchDeleteConfigurationTask>;
export interface DescribeBatchDeleteConfigurationTaskResponse {
    task?: BatchDeleteConfigurationTask;
}
export declare const DescribeBatchDeleteConfigurationTaskResponse: S.Schema<DescribeBatchDeleteConfigurationTaskResponse>;
export interface DescribeConfigurationsRequest {
    configurationIds: string[];
}
export declare const DescribeConfigurationsRequest: S.Schema<DescribeConfigurationsRequest>;
export type DescribeConfigurationsAttribute = {
    [key: string]: string | undefined;
};
export declare const DescribeConfigurationsAttribute: any;
export type DescribeConfigurationsAttributes = {
    [key: string]: string | undefined;
}[];
export declare const DescribeConfigurationsAttributes: any;
export interface DescribeConfigurationsResponse {
    configurations?: {
        [key: string]: string | undefined;
    }[];
}
export declare const DescribeConfigurationsResponse: S.Schema<DescribeConfigurationsResponse>;
export type ConfigurationsExportId = string;
export type ContinuousExportIds = string[];
export declare const ContinuousExportIds: any;
export type DescribeContinuousExportsMaxResults = number;
export interface DescribeContinuousExportsRequest {
    exportIds?: string[];
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeContinuousExportsRequest: S.Schema<DescribeContinuousExportsRequest>;
export type ContinuousExportStatus = "START_IN_PROGRESS" | "START_FAILED" | "ACTIVE" | "ERROR" | "STOP_IN_PROGRESS" | "STOP_FAILED" | "INACTIVE" | (string & {});
export declare const ContinuousExportStatus: any;
export type StringMax255 = string;
export type S3Bucket = string;
export type DataSource = "AGENT" | (string & {});
export declare const DataSource: any;
export type DatabaseName = string;
export type SchemaStorageConfig = {
    [key: string]: string | undefined;
};
export declare const SchemaStorageConfig: any;
export interface ContinuousExportDescription {
    exportId?: string;
    status?: ContinuousExportStatus;
    statusDetail?: string;
    s3Bucket?: string;
    startTime?: Date;
    stopTime?: Date;
    dataSource?: DataSource;
    schemaStorageConfig?: {
        [key: string]: string | undefined;
    };
}
export declare const ContinuousExportDescription: S.Schema<ContinuousExportDescription>;
export type ContinuousExportDescriptions = ContinuousExportDescription[];
export declare const ContinuousExportDescriptions: any;
export interface DescribeContinuousExportsResponse {
    descriptions?: ContinuousExportDescription[];
    nextToken?: string;
}
export declare const DescribeContinuousExportsResponse: S.Schema<DescribeContinuousExportsResponse>;
export type ExportIds = string[];
export declare const ExportIds: any;
export interface DescribeExportConfigurationsRequest {
    exportIds?: string[];
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeExportConfigurationsRequest: S.Schema<DescribeExportConfigurationsRequest>;
export type ExportStatus = "FAILED" | "SUCCEEDED" | "IN_PROGRESS" | (string & {});
export declare const ExportStatus: any;
export type ExportStatusMessage = string;
export type ConfigurationsDownloadUrl = string;
export type ExportRequestTime = Date;
export interface ExportInfo {
    exportId: string;
    exportStatus: ExportStatus;
    statusMessage: string;
    configurationsDownloadUrl?: string;
    exportRequestTime: Date;
    isTruncated?: boolean;
    requestedStartTime?: Date;
    requestedEndTime?: Date;
}
export declare const ExportInfo: S.Schema<ExportInfo>;
export type ExportsInfo = ExportInfo[];
export declare const ExportsInfo: any;
export interface DescribeExportConfigurationsResponse {
    exportsInfo?: ExportInfo[];
    nextToken?: string;
}
export declare const DescribeExportConfigurationsResponse: S.Schema<DescribeExportConfigurationsResponse>;
export type FilterName = string;
export interface ExportFilter {
    name: string;
    values: string[];
    condition: string;
}
export declare const ExportFilter: S.Schema<ExportFilter>;
export type ExportFilters = ExportFilter[];
export declare const ExportFilters: any;
export interface DescribeExportTasksRequest {
    exportIds?: string[];
    filters?: ExportFilter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeExportTasksRequest: S.Schema<DescribeExportTasksRequest>;
export interface DescribeExportTasksResponse {
    exportsInfo?: ExportInfo[];
    nextToken?: string;
}
export declare const DescribeExportTasksResponse: S.Schema<DescribeExportTasksResponse>;
export type ImportTaskFilterName = "IMPORT_TASK_ID" | "STATUS" | "NAME" | "FILE_CLASSIFICATION" | (string & {});
export declare const ImportTaskFilterName: any;
export type ImportTaskFilterValue = string;
export type ImportTaskFilterValueList = string[];
export declare const ImportTaskFilterValueList: any;
export interface ImportTaskFilter {
    name?: ImportTaskFilterName;
    values?: string[];
}
export declare const ImportTaskFilter: S.Schema<ImportTaskFilter>;
export type DescribeImportTasksFilterList = ImportTaskFilter[];
export declare const DescribeImportTasksFilterList: any;
export type DescribeImportTasksMaxResults = number;
export interface DescribeImportTasksRequest {
    filters?: ImportTaskFilter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeImportTasksRequest: S.Schema<DescribeImportTasksRequest>;
export type ClientRequestToken = string;
export type ImportTaskName = string;
export type ImportURL = string;
export type ImportStatus = "IMPORT_IN_PROGRESS" | "IMPORT_COMPLETE" | "IMPORT_COMPLETE_WITH_ERRORS" | "IMPORT_FAILED" | "IMPORT_FAILED_SERVER_LIMIT_EXCEEDED" | "IMPORT_FAILED_RECORD_LIMIT_EXCEEDED" | "IMPORT_FAILED_UNSUPPORTED_FILE_TYPE" | "DELETE_IN_PROGRESS" | "DELETE_COMPLETE" | "DELETE_FAILED" | "DELETE_FAILED_LIMIT_EXCEEDED" | "INTERNAL_ERROR" | (string & {});
export declare const ImportStatus: any;
export type FileClassification = "MODELIZEIT_EXPORT" | "RVTOOLS_EXPORT" | "VMWARE_NSX_EXPORT" | "IMPORT_TEMPLATE" | (string & {});
export declare const FileClassification: any;
export type S3PresignedUrl = string;
export interface ImportTask {
    importTaskId?: string;
    clientRequestToken?: string;
    name?: string;
    importUrl?: string;
    status?: ImportStatus;
    importRequestTime?: Date;
    importCompletionTime?: Date;
    importDeletedTime?: Date;
    fileClassification?: FileClassification;
    serverImportSuccess?: number;
    serverImportFailure?: number;
    applicationImportSuccess?: number;
    applicationImportFailure?: number;
    errorsAndFailedEntriesZip?: string;
}
export declare const ImportTask: S.Schema<ImportTask>;
export type ImportTaskList = ImportTask[];
export declare const ImportTaskList: any;
export interface DescribeImportTasksResponse {
    nextToken?: string;
    tasks?: ImportTask[];
}
export declare const DescribeImportTasksResponse: S.Schema<DescribeImportTasksResponse>;
export interface TagFilter {
    name: string;
    values: string[];
}
export declare const TagFilter: S.Schema<TagFilter>;
export type TagFilters = TagFilter[];
export declare const TagFilters: any;
export interface DescribeTagsRequest {
    filters?: TagFilter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeTagsRequest: S.Schema<DescribeTagsRequest>;
export type ConfigurationItemType = "SERVER" | "PROCESS" | "CONNECTION" | "APPLICATION" | (string & {});
export declare const ConfigurationItemType: any;
export interface ConfigurationTag {
    configurationType?: ConfigurationItemType;
    configurationId?: string;
    key?: string;
    value?: string;
    timeOfCreation?: Date;
}
export declare const ConfigurationTag: S.Schema<ConfigurationTag>;
export type ConfigurationTagSet = ConfigurationTag[];
export declare const ConfigurationTagSet: any;
export interface DescribeTagsResponse {
    tags?: ConfigurationTag[];
    nextToken?: string;
}
export declare const DescribeTagsResponse: S.Schema<DescribeTagsResponse>;
export interface DisassociateConfigurationItemsFromApplicationRequest {
    applicationConfigurationId: string;
    configurationIds: string[];
}
export declare const DisassociateConfigurationItemsFromApplicationRequest: S.Schema<DisassociateConfigurationItemsFromApplicationRequest>;
export interface DisassociateConfigurationItemsFromApplicationResponse {
}
export declare const DisassociateConfigurationItemsFromApplicationResponse: S.Schema<DisassociateConfigurationItemsFromApplicationResponse>;
export interface ExportConfigurationsRequest {
}
export declare const ExportConfigurationsRequest: S.Schema<ExportConfigurationsRequest>;
export interface ExportConfigurationsResponse {
    exportId?: string;
}
export declare const ExportConfigurationsResponse: S.Schema<ExportConfigurationsResponse>;
export interface GetDiscoverySummaryRequest {
}
export declare const GetDiscoverySummaryRequest: S.Schema<GetDiscoverySummaryRequest>;
export interface CustomerAgentInfo {
    activeAgents: number;
    healthyAgents: number;
    blackListedAgents: number;
    shutdownAgents: number;
    unhealthyAgents: number;
    totalAgents: number;
    unknownAgents: number;
}
export declare const CustomerAgentInfo: S.Schema<CustomerAgentInfo>;
export interface CustomerConnectorInfo {
    activeConnectors: number;
    healthyConnectors: number;
    blackListedConnectors: number;
    shutdownConnectors: number;
    unhealthyConnectors: number;
    totalConnectors: number;
    unknownConnectors: number;
}
export declare const CustomerConnectorInfo: S.Schema<CustomerConnectorInfo>;
export interface CustomerMeCollectorInfo {
    activeMeCollectors: number;
    healthyMeCollectors: number;
    denyListedMeCollectors: number;
    shutdownMeCollectors: number;
    unhealthyMeCollectors: number;
    totalMeCollectors: number;
    unknownMeCollectors: number;
}
export declare const CustomerMeCollectorInfo: S.Schema<CustomerMeCollectorInfo>;
export interface CustomerAgentlessCollectorInfo {
    activeAgentlessCollectors: number;
    healthyAgentlessCollectors: number;
    denyListedAgentlessCollectors: number;
    shutdownAgentlessCollectors: number;
    unhealthyAgentlessCollectors: number;
    totalAgentlessCollectors: number;
    unknownAgentlessCollectors: number;
}
export declare const CustomerAgentlessCollectorInfo: S.Schema<CustomerAgentlessCollectorInfo>;
export interface GetDiscoverySummaryResponse {
    servers?: number;
    applications?: number;
    serversMappedToApplications?: number;
    serversMappedtoTags?: number;
    agentSummary?: CustomerAgentInfo;
    connectorSummary?: CustomerConnectorInfo;
    meCollectorSummary?: CustomerMeCollectorInfo;
    agentlessCollectorSummary?: CustomerAgentlessCollectorInfo;
}
export declare const GetDiscoverySummaryResponse: S.Schema<GetDiscoverySummaryResponse>;
export type OrderByElementFieldName = string;
export type OrderString = "ASC" | "DESC" | (string & {});
export declare const OrderString: any;
export interface OrderByElement {
    fieldName: string;
    sortOrder?: OrderString;
}
export declare const OrderByElement: S.Schema<OrderByElement>;
export type OrderByList = OrderByElement[];
export declare const OrderByList: any;
export interface ListConfigurationsRequest {
    configurationType: ConfigurationItemType;
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
    orderBy?: OrderByElement[];
}
export declare const ListConfigurationsRequest: S.Schema<ListConfigurationsRequest>;
export type Configuration = {
    [key: string]: string | undefined;
};
export declare const Configuration: any;
export type Configurations = {
    [key: string]: string | undefined;
}[];
export declare const Configurations: any;
export interface ListConfigurationsResponse {
    configurations?: {
        [key: string]: string | undefined;
    }[];
    nextToken?: string;
}
export declare const ListConfigurationsResponse: S.Schema<ListConfigurationsResponse>;
export interface ListServerNeighborsRequest {
    configurationId: string;
    portInformationNeeded?: boolean;
    neighborConfigurationIds?: string[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListServerNeighborsRequest: S.Schema<ListServerNeighborsRequest>;
export type BoxedInteger = number;
export interface NeighborConnectionDetail {
    sourceServerId: string;
    destinationServerId: string;
    destinationPort?: number;
    transportProtocol?: string;
    connectionsCount: number;
}
export declare const NeighborConnectionDetail: S.Schema<NeighborConnectionDetail>;
export type NeighborDetailsList = NeighborConnectionDetail[];
export declare const NeighborDetailsList: any;
export interface ListServerNeighborsResponse {
    neighbors: NeighborConnectionDetail[];
    nextToken?: string;
    knownDependencyCount?: number;
}
export declare const ListServerNeighborsResponse: S.Schema<ListServerNeighborsResponse>;
export interface StartBatchDeleteConfigurationTaskRequest {
    configurationType: DeletionConfigurationItemType;
    configurationIds: string[];
}
export declare const StartBatchDeleteConfigurationTaskRequest: S.Schema<StartBatchDeleteConfigurationTaskRequest>;
export interface StartBatchDeleteConfigurationTaskResponse {
    taskId?: string;
}
export declare const StartBatchDeleteConfigurationTaskResponse: S.Schema<StartBatchDeleteConfigurationTaskResponse>;
export interface StartContinuousExportRequest {
}
export declare const StartContinuousExportRequest: S.Schema<StartContinuousExportRequest>;
export interface StartContinuousExportResponse {
    exportId?: string;
    s3Bucket?: string;
    startTime?: Date;
    dataSource?: DataSource;
    schemaStorageConfig?: {
        [key: string]: string | undefined;
    };
}
export declare const StartContinuousExportResponse: S.Schema<StartContinuousExportResponse>;
export interface StartDataCollectionByAgentIdsRequest {
    agentIds: string[];
}
export declare const StartDataCollectionByAgentIdsRequest: S.Schema<StartDataCollectionByAgentIdsRequest>;
export interface AgentConfigurationStatus {
    agentId?: string;
    operationSucceeded?: boolean;
    description?: string;
}
export declare const AgentConfigurationStatus: S.Schema<AgentConfigurationStatus>;
export type AgentConfigurationStatusList = AgentConfigurationStatus[];
export declare const AgentConfigurationStatusList: any;
export interface StartDataCollectionByAgentIdsResponse {
    agentsConfigurationStatus?: AgentConfigurationStatus[];
}
export declare const StartDataCollectionByAgentIdsResponse: S.Schema<StartDataCollectionByAgentIdsResponse>;
export type ExportDataFormat = "CSV" | (string & {});
export declare const ExportDataFormat: any;
export type ExportDataFormats = ExportDataFormat[];
export declare const ExportDataFormats: any;
export type ExportEnabled = boolean;
export type UsageMetricBasisName = string;
export type UsageMetricPercentageAdjust = number;
export interface UsageMetricBasis {
    name?: string;
    percentageAdjust?: number;
}
export declare const UsageMetricBasis: S.Schema<UsageMetricBasis>;
export type Tenancy = "DEDICATED" | "SHARED" | (string & {});
export declare const Tenancy: any;
export type EC2InstanceType = string;
export type ExcludedInstanceTypes = string[];
export declare const ExcludedInstanceTypes: any;
export type UserPreferredRegion = string;
export type PurchasingOption = "ALL_UPFRONT" | "PARTIAL_UPFRONT" | "NO_UPFRONT" | (string & {});
export declare const PurchasingOption: any;
export type OfferingClass = "STANDARD" | "CONVERTIBLE" | (string & {});
export declare const OfferingClass: any;
export type TermLength = "ONE_YEAR" | "THREE_YEAR" | (string & {});
export declare const TermLength: any;
export interface ReservedInstanceOptions {
    purchasingOption: PurchasingOption;
    offeringClass: OfferingClass;
    termLength: TermLength;
}
export declare const ReservedInstanceOptions: S.Schema<ReservedInstanceOptions>;
export interface Ec2RecommendationsExportPreferences {
    enabled?: boolean;
    cpuPerformanceMetricBasis?: UsageMetricBasis;
    ramPerformanceMetricBasis?: UsageMetricBasis;
    tenancy?: Tenancy;
    excludedInstanceTypes?: string[];
    preferredRegion?: string;
    reservedInstanceOptions?: ReservedInstanceOptions;
}
export declare const Ec2RecommendationsExportPreferences: S.Schema<Ec2RecommendationsExportPreferences>;
export type ExportPreferences = {
    ec2RecommendationsPreferences: Ec2RecommendationsExportPreferences;
};
export declare const ExportPreferences: any;
export interface StartExportTaskRequest {
    exportDataFormat?: ExportDataFormat[];
    filters?: ExportFilter[];
    startTime?: Date;
    endTime?: Date;
    preferences?: ExportPreferences;
}
export declare const StartExportTaskRequest: S.Schema<StartExportTaskRequest>;
export interface StartExportTaskResponse {
    exportId?: string;
}
export declare const StartExportTaskResponse: S.Schema<StartExportTaskResponse>;
export interface StartImportTaskRequest {
    clientRequestToken?: string;
    name: string;
    importUrl: string;
}
export declare const StartImportTaskRequest: S.Schema<StartImportTaskRequest>;
export interface StartImportTaskResponse {
    task?: ImportTask;
}
export declare const StartImportTaskResponse: S.Schema<StartImportTaskResponse>;
export interface StopContinuousExportRequest {
    exportId: string;
}
export declare const StopContinuousExportRequest: S.Schema<StopContinuousExportRequest>;
export interface StopContinuousExportResponse {
    startTime?: Date;
    stopTime?: Date;
}
export declare const StopContinuousExportResponse: S.Schema<StopContinuousExportResponse>;
export interface StopDataCollectionByAgentIdsRequest {
    agentIds: string[];
}
export declare const StopDataCollectionByAgentIdsRequest: S.Schema<StopDataCollectionByAgentIdsRequest>;
export interface StopDataCollectionByAgentIdsResponse {
    agentsConfigurationStatus?: AgentConfigurationStatus[];
}
export declare const StopDataCollectionByAgentIdsResponse: S.Schema<StopDataCollectionByAgentIdsResponse>;
export interface UpdateApplicationRequest {
    configurationId: string;
    name?: string;
    description?: string;
    wave?: string;
}
export declare const UpdateApplicationRequest: S.Schema<UpdateApplicationRequest>;
export interface UpdateApplicationResponse {
}
export declare const UpdateApplicationResponse: S.Schema<UpdateApplicationResponse>;
export type Message = string;
export type AssociateConfigurationItemsToApplicationError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Associates one or more configuration items with an application.
 */
export declare const associateConfigurationItemsToApplication: API.OperationMethod<AssociateConfigurationItemsToApplicationRequest, AssociateConfigurationItemsToApplicationResponse, AssociateConfigurationItemsToApplicationError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteAgentsError = AuthorizationErrorException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Deletes one or more agents or collectors as specified by ID. Deleting an agent or collector does not
 * delete the previously discovered data.
 * To delete the data collected, use `StartBatchDeleteConfigurationTask`.
 */
export declare const batchDeleteAgents: API.OperationMethod<BatchDeleteAgentsRequest, BatchDeleteAgentsResponse, BatchDeleteAgentsError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteImportDataError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Deletes one or more import tasks, each identified by their import ID. Each import task has
 * a number of records that can identify servers or applications.
 *
 * Amazon Web Services Application Discovery Service has built-in matching logic that will identify when
 * discovered servers match existing entries that you've previously discovered, the information
 * for the already-existing discovered server is updated. When you delete an import task that
 * contains records that were used to match, the information in those matched records that comes
 * from the deleted records will also be deleted.
 */
export declare const batchDeleteImportData: API.OperationMethod<BatchDeleteImportDataRequest, BatchDeleteImportDataResponse, BatchDeleteImportDataError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Creates an application with the given name and description.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateTagsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * Creates one or more tags for configuration items. Tags are metadata that help you
 * categorize IT assets. This API accepts a list of multiple configuration items.
 *
 * Do not store sensitive information (like personal data) in tags.
 */
export declare const createTags: API.OperationMethod<CreateTagsRequest, CreateTagsResponse, CreateTagsError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Deletes a list of applications and their associations with configuration
 * items.
 */
export declare const deleteApplications: API.OperationMethod<DeleteApplicationsRequest, DeleteApplicationsResponse, DeleteApplicationsError, Credentials | HttpClient.HttpClient>;
export type DeleteTagsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * Deletes the association between configuration items and one or more tags. This API
 * accepts a list of multiple configuration items.
 */
export declare const deleteTags: API.OperationMethod<DeleteTagsRequest, DeleteTagsResponse, DeleteTagsError, Credentials | HttpClient.HttpClient>;
export type DescribeAgentsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Lists agents or collectors as specified by ID or other filters. All agents/collectors
 * associated with your user can be listed if you call `DescribeAgents` as is
 * without passing any parameters.
 */
export declare const describeAgents: API.PaginatedOperationMethod<DescribeAgentsRequest, DescribeAgentsResponse, DescribeAgentsError, Credentials | HttpClient.HttpClient, AgentInfo>;
export type DescribeBatchDeleteConfigurationTaskError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Takes a unique deletion task identifier as input and returns metadata about a configuration deletion task.
 */
export declare const describeBatchDeleteConfigurationTask: API.OperationMethod<DescribeBatchDeleteConfigurationTaskRequest, DescribeBatchDeleteConfigurationTaskResponse, DescribeBatchDeleteConfigurationTaskError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Retrieves attributes for a list of configuration item IDs.
 *
 * All of the supplied IDs must be for the same asset type from one of the
 * following:
 *
 * - server
 *
 * - application
 *
 * - process
 *
 * - connection
 *
 * Output fields are specific to the asset type specified. For example, the output for a
 * *server* configuration item includes a list of attributes about the
 * server, such as host name, operating system, number of network cards, etc.
 *
 * For a complete list of outputs for each asset type, see Using the DescribeConfigurations Action in the Amazon Web Services Application
 * Discovery Service User Guide.
 */
export declare const describeConfigurations: API.OperationMethod<DescribeConfigurationsRequest, DescribeConfigurationsResponse, DescribeConfigurationsError, Credentials | HttpClient.HttpClient>;
export type DescribeContinuousExportsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | OperationNotPermittedException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * Lists exports as specified by ID. All continuous exports associated with your user
 * can be listed if you call `DescribeContinuousExports` as is without passing
 * any parameters.
 */
export declare const describeContinuousExports: API.PaginatedOperationMethod<DescribeContinuousExportsRequest, DescribeContinuousExportsResponse, DescribeContinuousExportsError, Credentials | HttpClient.HttpClient, ContinuousExportDescription>;
export type DescribeExportConfigurationsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * `DescribeExportConfigurations` is deprecated. Use DescribeExportTasks, instead.
 */
export declare const describeExportConfigurations: API.PaginatedOperationMethod<DescribeExportConfigurationsRequest, DescribeExportConfigurationsResponse, DescribeExportConfigurationsError, Credentials | HttpClient.HttpClient, ExportInfo>;
export type DescribeExportTasksError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Retrieve status of one or more export tasks. You can retrieve the status of up to 100
 * export tasks.
 */
export declare const describeExportTasks: API.PaginatedOperationMethod<DescribeExportTasksRequest, DescribeExportTasksResponse, DescribeExportTasksError, Credentials | HttpClient.HttpClient, ExportInfo>;
export type DescribeImportTasksError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Returns an array of import tasks for your account, including status information, times,
 * IDs, the Amazon S3 Object URL for the import file, and more.
 */
export declare const describeImportTasks: API.PaginatedOperationMethod<DescribeImportTasksRequest, DescribeImportTasksResponse, DescribeImportTasksError, Credentials | HttpClient.HttpClient, ImportTask>;
export type DescribeTagsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * Retrieves a list of configuration items that have tags as specified by the key-value
 * pairs, name and value, passed to the optional parameter `filters`.
 *
 * There are three valid tag filter names:
 *
 * - tagKey
 *
 * - tagValue
 *
 * - configurationId
 *
 * Also, all configuration items associated with your user that have tags can be
 * listed if you call `DescribeTags` as is without passing any parameters.
 */
export declare const describeTags: API.PaginatedOperationMethod<DescribeTagsRequest, DescribeTagsResponse, DescribeTagsError, Credentials | HttpClient.HttpClient, ConfigurationTag>;
export type DisassociateConfigurationItemsFromApplicationError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Disassociates one or more configuration items from an application.
 */
export declare const disassociateConfigurationItemsFromApplication: API.OperationMethod<DisassociateConfigurationItemsFromApplicationRequest, DisassociateConfigurationItemsFromApplicationResponse, DisassociateConfigurationItemsFromApplicationError, Credentials | HttpClient.HttpClient>;
export type ExportConfigurationsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | OperationNotPermittedException | ServerInternalErrorException | CommonErrors;
/**
 * Deprecated. Use `StartExportTask` instead.
 *
 * Exports all discovered configuration data to an Amazon S3 bucket or an application that
 * enables you to view and evaluate the data. Data includes tags and tag associations, processes,
 * connections, servers, and system performance. This API returns an export ID that you can query
 * using the *DescribeExportConfigurations* API. The system imposes a limit of
 * two configuration exports in six hours.
 */
export declare const exportConfigurations: API.OperationMethod<ExportConfigurationsRequest, ExportConfigurationsResponse, ExportConfigurationsError, Credentials | HttpClient.HttpClient>;
export type GetDiscoverySummaryError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Retrieves a short summary of discovered assets.
 *
 * This API operation takes no request parameters and is called as is at the command
 * prompt as shown in the example.
 */
export declare const getDiscoverySummary: API.OperationMethod<GetDiscoverySummaryRequest, GetDiscoverySummaryResponse, GetDiscoverySummaryError, Credentials | HttpClient.HttpClient>;
export type ListConfigurationsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * Retrieves a list of configuration items as specified by the value passed to the
 * required parameter `configurationType`. Optional filtering may be applied to refine
 * search results.
 */
export declare const listConfigurations: API.PaginatedOperationMethod<ListConfigurationsRequest, ListConfigurationsResponse, ListConfigurationsError, Credentials | HttpClient.HttpClient, {
    [key: string]: string | undefined;
}>;
export type ListServerNeighborsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Retrieves a list of servers that are one network hop away from a specified
 * server.
 */
export declare const listServerNeighbors: API.OperationMethod<ListServerNeighborsRequest, ListServerNeighborsResponse, ListServerNeighborsError, Credentials | HttpClient.HttpClient>;
export type StartBatchDeleteConfigurationTaskError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | LimitExceededException | OperationNotPermittedException | ServerInternalErrorException | CommonErrors;
/**
 * Takes a list of configurationId as input and starts an asynchronous deletion
 * task to remove the configurationItems. Returns a unique deletion task identifier.
 */
export declare const startBatchDeleteConfigurationTask: API.OperationMethod<StartBatchDeleteConfigurationTaskRequest, StartBatchDeleteConfigurationTaskResponse, StartBatchDeleteConfigurationTaskError, Credentials | HttpClient.HttpClient>;
export type StartContinuousExportError = AuthorizationErrorException | ConflictErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | OperationNotPermittedException | ResourceInUseException | ServerInternalErrorException | CommonErrors;
/**
 * Start the continuous flow of agent's discovered data into Amazon Athena.
 */
export declare const startContinuousExport: API.OperationMethod<StartContinuousExportRequest, StartContinuousExportResponse, StartContinuousExportError, Credentials | HttpClient.HttpClient>;
export type StartDataCollectionByAgentIdsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Instructs the specified agents to start collecting data.
 */
export declare const startDataCollectionByAgentIds: API.OperationMethod<StartDataCollectionByAgentIdsRequest, StartDataCollectionByAgentIdsResponse, StartDataCollectionByAgentIdsError, Credentials | HttpClient.HttpClient>;
export type StartExportTaskError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | OperationNotPermittedException | ServerInternalErrorException | CommonErrors;
/**
 * Begins the export of a discovered data report to an Amazon S3 bucket managed by Amazon Web Services.
 *
 * Exports might provide an estimate of fees and savings based on certain information
 * that you provide. Fee estimates do not include any taxes that might apply.
 * Your actual fees and savings depend on a variety of factors, including your actual usage of Amazon Web Services
 * services, which might vary from the estimates provided in this report.
 *
 * If you do not specify `preferences` or `agentIds` in the filter, a
 * summary of all servers, applications, tags, and performance is generated. This data is an
 * aggregation of all server data collected through on-premises tooling, file import, application
 * grouping and applying tags.
 *
 * If you specify `agentIds` in a filter, the task exports up to 72 hours of
 * detailed data collected by the identified Application Discovery Agent, including network,
 * process, and performance details. A time range for exported agent data may be set by using
 * `startTime` and `endTime`. Export of detailed agent data is limited to
 * five concurrently running exports.
 * Export of detailed agent data is limited to two exports per day.
 *
 * If you enable `ec2RecommendationsPreferences` in `preferences`
 * , an
 * Amazon EC2 instance matching the characteristics of each server in Application Discovery Service is generated.
 * Changing the attributes of the `ec2RecommendationsPreferences` changes the
 * criteria of the recommendation.
 */
export declare const startExportTask: API.OperationMethod<StartExportTaskRequest, StartExportTaskResponse, StartExportTaskError, Credentials | HttpClient.HttpClient>;
export type StartImportTaskError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ResourceInUseException | ServerInternalErrorException | CommonErrors;
/**
 * Starts an import task, which allows you to import details of your on-premises environment
 * directly into Amazon Web Services Migration Hub without having to use the Amazon Web Services Application Discovery
 * Service (Application Discovery Service) tools such as the Amazon Web Services Application Discovery Service Agentless Collector
 * or Application Discovery Agent. This gives you the option to
 * perform migration assessment and planning directly from your imported data, including the
 * ability to group your devices as applications and track their migration status.
 *
 * To start an import request, do this:
 *
 * - Download the specially formatted comma separated value (CSV) import template, which
 * you can find here: https://s3.us-west-2.amazonaws.com/templates-7cffcf56-bd96-4b1c-b45b-a5b42f282e46/import_template.csv.
 *
 * - Fill out the template with your server and application data.
 *
 * - Upload your import file to an Amazon S3 bucket, and make a note of it's Object URL.
 * Your import file must be in the CSV format.
 *
 * - Use the console or the `StartImportTask` command with the Amazon Web Services CLI or one
 * of the Amazon Web Services SDKs to import the records from your file.
 *
 * For more information, including step-by-step procedures, see Migration Hub
 * Import in the Amazon Web Services Application Discovery Service User
 * Guide.
 *
 * There are limits to the number of import tasks you can create (and delete) in an Amazon Web Services
 * account. For more information, see Amazon Web Services Application
 * Discovery Service Limits in the Amazon Web Services Application Discovery Service User
 * Guide.
 */
export declare const startImportTask: API.OperationMethod<StartImportTaskRequest, StartImportTaskResponse, StartImportTaskError, Credentials | HttpClient.HttpClient>;
export type StopContinuousExportError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * Stop the continuous flow of agent's discovered data into Amazon Athena.
 */
export declare const stopContinuousExport: API.OperationMethod<StopContinuousExportRequest, StopContinuousExportResponse, StopContinuousExportError, Credentials | HttpClient.HttpClient>;
export type StopDataCollectionByAgentIdsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Instructs the specified agents to stop collecting data.
 */
export declare const stopDataCollectionByAgentIds: API.OperationMethod<StopDataCollectionByAgentIdsRequest, StopDataCollectionByAgentIdsResponse, StopDataCollectionByAgentIdsError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Updates metadata about an application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=application-discovery-service.d.ts.map