import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AuthException_base: S.Class<AuthException, S.TaggedStruct<"AuthException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AuthException extends /*@__PURE__*/ AuthException_base {
}
declare const EC2InstanceNotFoundException_base: S.Class<EC2InstanceNotFoundException, S.TaggedStruct<"EC2InstanceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EC2InstanceNotFoundException extends /*@__PURE__*/ EC2InstanceNotFoundException_base {
}
declare const EC2InstanceStateInvalidException_base: S.Class<EC2InstanceStateInvalidException, S.TaggedStruct<"EC2InstanceStateInvalidException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EC2InstanceStateInvalidException extends /*@__PURE__*/ EC2InstanceStateInvalidException_base {
}
declare const EC2InstanceTypeInvalidException_base: S.Class<EC2InstanceTypeInvalidException, S.TaggedStruct<"EC2InstanceTypeInvalidException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EC2InstanceTypeInvalidException extends /*@__PURE__*/ EC2InstanceTypeInvalidException_base {
}
declare const EC2InstanceUnavailableException_base: S.Class<EC2InstanceUnavailableException, S.TaggedStruct<"EC2InstanceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class EC2InstanceUnavailableException extends /*@__PURE__*/ EC2InstanceUnavailableException_base {
}
declare const InvalidArgsException_base: S.Class<InvalidArgsException, S.TaggedStruct<"InvalidArgsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidArgsException extends /*@__PURE__*/ InvalidArgsException_base {
}
declare const SerialConsoleAccessDisabledException_base: S.Class<SerialConsoleAccessDisabledException, S.TaggedStruct<"SerialConsoleAccessDisabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class SerialConsoleAccessDisabledException extends /*@__PURE__*/ SerialConsoleAccessDisabledException_base {
}
declare const SerialConsoleSessionLimitExceededException_base: S.Class<SerialConsoleSessionLimitExceededException, S.TaggedStruct<"SerialConsoleSessionLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SerialConsoleSessionLimitExceededException extends /*@__PURE__*/ SerialConsoleSessionLimitExceededException_base {
}
declare const SerialConsoleSessionUnavailableException_base: S.Class<SerialConsoleSessionUnavailableException, S.TaggedStruct<"SerialConsoleSessionUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class SerialConsoleSessionUnavailableException extends /*@__PURE__*/ SerialConsoleSessionUnavailableException_base {
}
declare const SerialConsoleSessionUnsupportedException_base: S.Class<SerialConsoleSessionUnsupportedException, S.TaggedStruct<"SerialConsoleSessionUnsupportedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SerialConsoleSessionUnsupportedException extends /*@__PURE__*/ SerialConsoleSessionUnsupportedException_base {
}
declare const ServiceException_base: S.Class<ServiceException, S.TaggedStruct<"ServiceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type InstanceId = string;
export type SerialPort = number;
export type SSHPublicKey = string;
export interface SendSerialConsoleSSHPublicKeyRequest {
    InstanceId: string;
    SerialPort?: number;
    SSHPublicKey: string;
}
export declare const SendSerialConsoleSSHPublicKeyRequest: S.Schema<SendSerialConsoleSSHPublicKeyRequest>;
export type RequestId = string;
export type Success = boolean;
export interface SendSerialConsoleSSHPublicKeyResponse {
    RequestId?: string;
    Success?: boolean;
}
export declare const SendSerialConsoleSSHPublicKeyResponse: S.Schema<SendSerialConsoleSSHPublicKeyResponse>;
export type InstanceOSUser = string;
export type AvailabilityZone = string;
export interface SendSSHPublicKeyRequest {
    InstanceId: string;
    InstanceOSUser: string;
    SSHPublicKey: string;
    AvailabilityZone?: string;
}
export declare const SendSSHPublicKeyRequest: S.Schema<SendSSHPublicKeyRequest>;
export interface SendSSHPublicKeyResponse {
    RequestId?: string;
    Success?: boolean;
}
export declare const SendSSHPublicKeyResponse: S.Schema<SendSSHPublicKeyResponse>;
export type SendSerialConsoleSSHPublicKeyError = AuthException | EC2InstanceNotFoundException | EC2InstanceStateInvalidException | EC2InstanceTypeInvalidException | EC2InstanceUnavailableException | InvalidArgsException | SerialConsoleAccessDisabledException | SerialConsoleSessionLimitExceededException | SerialConsoleSessionUnavailableException | SerialConsoleSessionUnsupportedException | ServiceException | ThrottlingException | CommonErrors;
/**
 * Pushes an SSH public key to the specified EC2 instance. The key remains for 60
 * seconds, which gives you 60 seconds to establish a serial console connection to the
 * instance using SSH. For more information, see EC2 Serial Console in
 * the *Amazon EC2 User Guide*.
 */
export declare const sendSerialConsoleSSHPublicKey: API.OperationMethod<SendSerialConsoleSSHPublicKeyRequest, SendSerialConsoleSSHPublicKeyResponse, SendSerialConsoleSSHPublicKeyError, Credentials | HttpClient.HttpClient>;
export type SendSSHPublicKeyError = AuthException | EC2InstanceNotFoundException | EC2InstanceStateInvalidException | EC2InstanceUnavailableException | InvalidArgsException | ServiceException | ThrottlingException | CommonErrors;
/**
 * Pushes an SSH public key to the specified EC2 instance for use by the specified user.
 * The key remains for 60 seconds. For more information, see Connect to
 * your Linux instance using EC2 Instance Connect in the Amazon EC2
 * User Guide.
 */
export declare const sendSSHPublicKey: API.OperationMethod<SendSSHPublicKeyRequest, SendSSHPublicKeyResponse, SendSSHPublicKeyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ec2-instance-connect.d.ts.map