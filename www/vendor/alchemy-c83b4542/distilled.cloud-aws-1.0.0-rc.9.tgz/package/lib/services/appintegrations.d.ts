import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const DuplicateResourceException_base: S.Class<DuplicateResourceException, S.TaggedStruct<"DuplicateResourceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateResourceException extends /*@__PURE__*/ DuplicateResourceException_base {
}
declare const InternalServiceError_base: S.Class<InternalServiceError, S.TaggedStruct<"InternalServiceError", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceError extends /*@__PURE__*/ InternalServiceError_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceQuotaExceededException_base: S.Class<ResourceQuotaExceededException, S.TaggedStruct<"ResourceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ResourceQuotaExceededException extends /*@__PURE__*/ ResourceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnsupportedOperationException_base: S.Class<UnsupportedOperationException, S.TaggedStruct<"UnsupportedOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export type ApplicationName = string;
export type ApplicationNamespace = string;
export type Description = string;
export type URL = string;
export type ApplicationTrustedSource = string;
export type ApplicationApprovedOrigins = string[];
export declare const ApplicationApprovedOrigins: any;
export interface ExternalUrlConfig {
    AccessUrl: string;
    ApprovedOrigins?: string[];
}
export declare const ExternalUrlConfig: S.Schema<ExternalUrlConfig>;
export interface ApplicationSourceConfig {
    ExternalUrlConfig?: ExternalUrlConfig;
}
export declare const ApplicationSourceConfig: S.Schema<ApplicationSourceConfig>;
export type EventName = string;
export interface Subscription {
    Event: string;
    Description?: string;
}
export declare const Subscription: S.Schema<Subscription>;
export type SubscriptionList = Subscription[];
export declare const SubscriptionList: any;
export type EventDefinitionSchema = string;
export interface Publication {
    Event: string;
    Schema: string;
    Description?: string;
}
export declare const Publication: S.Schema<Publication>;
export type PublicationList = Publication[];
export declare const PublicationList: any;
export type IdempotencyToken = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type Permission = string;
export type PermissionList = string[];
export declare const PermissionList: any;
export type InitializationTimeout = number;
export type ContactHandlingScope = "CROSS_CONTACTS" | "PER_CONTACT" | (string & {});
export declare const ContactHandlingScope: any;
export interface ContactHandling {
    Scope?: ContactHandlingScope;
}
export declare const ContactHandling: S.Schema<ContactHandling>;
export interface ApplicationConfig {
    ContactHandling?: ContactHandling;
}
export declare const ApplicationConfig: S.Schema<ApplicationConfig>;
export type IframePermission = string;
export type IframePermissionList = string[];
export declare const IframePermissionList: any;
export interface IframeConfig {
    Allow?: string[];
    Sandbox?: string[];
}
export declare const IframeConfig: S.Schema<IframeConfig>;
export type ApplicationType = "STANDARD" | "SERVICE" | "MCP_SERVER" | (string & {});
export declare const ApplicationType: any;
export interface CreateApplicationRequest {
    Name: string;
    Namespace: string;
    Description?: string;
    ApplicationSourceConfig: ApplicationSourceConfig;
    Subscriptions?: Subscription[];
    Publications?: Publication[];
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Permissions?: string[];
    IsService?: boolean;
    InitializationTimeout?: number;
    ApplicationConfig?: ApplicationConfig;
    IframeConfig?: IframeConfig;
    ApplicationType?: ApplicationType;
}
export declare const CreateApplicationRequest: S.Schema<CreateApplicationRequest>;
export type Arn = string;
export type UUID = string;
export interface CreateApplicationResponse {
    Arn?: string;
    Id?: string;
}
export declare const CreateApplicationResponse: S.Schema<CreateApplicationResponse>;
export type Name = string;
export type NonBlankString = string;
export type SourceURI = string;
export interface ScheduleConfiguration {
    FirstExecutionFrom?: string;
    Object?: string;
    ScheduleExpression: string;
}
export declare const ScheduleConfiguration: S.Schema<ScheduleConfiguration>;
export type NonBlankLongString = string;
export type FolderList = string[];
export declare const FolderList: any;
export type Fields = string;
export type FieldsList = string[];
export declare const FieldsList: any;
export type FieldsMap = {
    [key: string]: string[] | undefined;
};
export declare const FieldsMap: any;
export interface FileConfiguration {
    Folders: string[];
    Filters?: {
        [key: string]: string[] | undefined;
    };
}
export declare const FileConfiguration: S.Schema<FileConfiguration>;
export type ObjectConfiguration = {
    [key: string]: {
        [key: string]: string[] | undefined;
    } | undefined;
};
export declare const ObjectConfiguration: any;
export interface CreateDataIntegrationRequest {
    Name: string;
    Description?: string;
    KmsKey: string;
    SourceURI?: string;
    ScheduleConfig?: ScheduleConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
    FileConfiguration?: FileConfiguration;
    ObjectConfiguration?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    };
}
export declare const CreateDataIntegrationRequest: S.Schema<CreateDataIntegrationRequest>;
export interface CreateDataIntegrationResponse {
    Arn?: string;
    Id?: string;
    Name?: string;
    Description?: string;
    KmsKey?: string;
    SourceURI?: string;
    ScheduleConfiguration?: ScheduleConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
    FileConfiguration?: FileConfiguration;
    ObjectConfiguration?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    };
}
export declare const CreateDataIntegrationResponse: S.Schema<CreateDataIntegrationResponse>;
export type Identifier = string;
export type ClientId = string;
export type DestinationURI = string;
export type ClientAssociationMetadata = {
    [key: string]: string | undefined;
};
export declare const ClientAssociationMetadata: any;
export type ExecutionMode = "ON_DEMAND" | "SCHEDULED" | (string & {});
export declare const ExecutionMode: any;
export interface OnDemandConfiguration {
    StartTime: string;
    EndTime?: string;
}
export declare const OnDemandConfiguration: S.Schema<OnDemandConfiguration>;
export interface ExecutionConfiguration {
    ExecutionMode: ExecutionMode;
    OnDemandConfiguration?: OnDemandConfiguration;
    ScheduleConfiguration?: ScheduleConfiguration;
}
export declare const ExecutionConfiguration: S.Schema<ExecutionConfiguration>;
export interface CreateDataIntegrationAssociationRequest {
    DataIntegrationIdentifier: string;
    ClientId?: string;
    ObjectConfiguration?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    };
    DestinationURI?: string;
    ClientAssociationMetadata?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
    ExecutionConfiguration?: ExecutionConfiguration;
}
export declare const CreateDataIntegrationAssociationRequest: S.Schema<CreateDataIntegrationAssociationRequest>;
export interface CreateDataIntegrationAssociationResponse {
    DataIntegrationAssociationId?: string;
    DataIntegrationArn?: string;
}
export declare const CreateDataIntegrationAssociationResponse: S.Schema<CreateDataIntegrationAssociationResponse>;
export type Source = string;
export interface EventFilter {
    Source: string;
}
export declare const EventFilter: S.Schema<EventFilter>;
export type EventBridgeBus = string;
export interface CreateEventIntegrationRequest {
    Name: string;
    Description?: string;
    EventFilter: EventFilter;
    EventBridgeBus: string;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateEventIntegrationRequest: S.Schema<CreateEventIntegrationRequest>;
export interface CreateEventIntegrationResponse {
    EventIntegrationArn?: string;
}
export declare const CreateEventIntegrationResponse: S.Schema<CreateEventIntegrationResponse>;
export type ArnOrUUID = string;
export interface DeleteApplicationRequest {
    Arn: string;
}
export declare const DeleteApplicationRequest: S.Schema<DeleteApplicationRequest>;
export interface DeleteApplicationResponse {
}
export declare const DeleteApplicationResponse: S.Schema<DeleteApplicationResponse>;
export interface DeleteDataIntegrationRequest {
    DataIntegrationIdentifier: string;
}
export declare const DeleteDataIntegrationRequest: S.Schema<DeleteDataIntegrationRequest>;
export interface DeleteDataIntegrationResponse {
}
export declare const DeleteDataIntegrationResponse: S.Schema<DeleteDataIntegrationResponse>;
export interface DeleteEventIntegrationRequest {
    Name: string;
}
export declare const DeleteEventIntegrationRequest: S.Schema<DeleteEventIntegrationRequest>;
export interface DeleteEventIntegrationResponse {
}
export declare const DeleteEventIntegrationResponse: S.Schema<DeleteEventIntegrationResponse>;
export interface GetApplicationRequest {
    Arn: string;
}
export declare const GetApplicationRequest: S.Schema<GetApplicationRequest>;
export interface GetApplicationResponse {
    Arn?: string;
    Id?: string;
    Name?: string;
    Namespace?: string;
    Description?: string;
    ApplicationSourceConfig?: ApplicationSourceConfig;
    Subscriptions?: Subscription[];
    Publications?: Publication[];
    CreatedTime?: Date;
    LastModifiedTime?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
    Permissions?: string[];
    IsService?: boolean;
    InitializationTimeout?: number;
    ApplicationConfig?: ApplicationConfig;
    IframeConfig?: IframeConfig;
    ApplicationType?: ApplicationType;
}
export declare const GetApplicationResponse: S.Schema<GetApplicationResponse>;
export interface GetDataIntegrationRequest {
    Identifier: string;
}
export declare const GetDataIntegrationRequest: S.Schema<GetDataIntegrationRequest>;
export interface GetDataIntegrationResponse {
    Arn?: string;
    Id?: string;
    Name?: string;
    Description?: string;
    KmsKey?: string;
    SourceURI?: string;
    ScheduleConfiguration?: ScheduleConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
    FileConfiguration?: FileConfiguration;
    ObjectConfiguration?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    };
}
export declare const GetDataIntegrationResponse: S.Schema<GetDataIntegrationResponse>;
export interface GetEventIntegrationRequest {
    Name: string;
}
export declare const GetEventIntegrationRequest: S.Schema<GetEventIntegrationRequest>;
export interface GetEventIntegrationResponse {
    Name?: string;
    Description?: string;
    EventIntegrationArn?: string;
    EventBridgeBus?: string;
    EventFilter?: EventFilter;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetEventIntegrationResponse: S.Schema<GetEventIntegrationResponse>;
export type NextToken = string;
export type MaxResults = number;
export interface ListApplicationAssociationsRequest {
    ApplicationId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListApplicationAssociationsRequest: S.Schema<ListApplicationAssociationsRequest>;
export interface ApplicationAssociationSummary {
    ApplicationAssociationArn?: string;
    ApplicationArn?: string;
    ClientId?: string;
}
export declare const ApplicationAssociationSummary: S.Schema<ApplicationAssociationSummary>;
export type ApplicationAssociationsList = ApplicationAssociationSummary[];
export declare const ApplicationAssociationsList: any;
export interface ListApplicationAssociationsResponse {
    ApplicationAssociations?: ApplicationAssociationSummary[];
    NextToken?: string;
}
export declare const ListApplicationAssociationsResponse: S.Schema<ListApplicationAssociationsResponse>;
export interface ListApplicationsRequest {
    NextToken?: string;
    MaxResults?: number;
    ApplicationType?: ApplicationType;
}
export declare const ListApplicationsRequest: S.Schema<ListApplicationsRequest>;
export interface ApplicationSummary {
    Arn?: string;
    Id?: string;
    Name?: string;
    Namespace?: string;
    CreatedTime?: Date;
    LastModifiedTime?: Date;
    IsService?: boolean;
    ApplicationType?: ApplicationType;
}
export declare const ApplicationSummary: S.Schema<ApplicationSummary>;
export type ApplicationsList = ApplicationSummary[];
export declare const ApplicationsList: any;
export interface ListApplicationsResponse {
    Applications?: ApplicationSummary[];
    NextToken?: string;
}
export declare const ListApplicationsResponse: S.Schema<ListApplicationsResponse>;
export interface ListDataIntegrationAssociationsRequest {
    DataIntegrationIdentifier: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDataIntegrationAssociationsRequest: S.Schema<ListDataIntegrationAssociationsRequest>;
export type ExecutionStatus = "COMPLETED" | "IN_PROGRESS" | "FAILED" | (string & {});
export declare const ExecutionStatus: any;
export interface LastExecutionStatus {
    ExecutionStatus?: ExecutionStatus;
    StatusMessage?: string;
}
export declare const LastExecutionStatus: S.Schema<LastExecutionStatus>;
export interface DataIntegrationAssociationSummary {
    DataIntegrationAssociationArn?: string;
    DataIntegrationArn?: string;
    ClientId?: string;
    DestinationURI?: string;
    LastExecutionStatus?: LastExecutionStatus;
    ExecutionConfiguration?: ExecutionConfiguration;
}
export declare const DataIntegrationAssociationSummary: S.Schema<DataIntegrationAssociationSummary>;
export type DataIntegrationAssociationsList = DataIntegrationAssociationSummary[];
export declare const DataIntegrationAssociationsList: any;
export interface ListDataIntegrationAssociationsResponse {
    DataIntegrationAssociations?: DataIntegrationAssociationSummary[];
    NextToken?: string;
}
export declare const ListDataIntegrationAssociationsResponse: S.Schema<ListDataIntegrationAssociationsResponse>;
export interface ListDataIntegrationsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDataIntegrationsRequest: S.Schema<ListDataIntegrationsRequest>;
export interface DataIntegrationSummary {
    Arn?: string;
    Name?: string;
    SourceURI?: string;
}
export declare const DataIntegrationSummary: S.Schema<DataIntegrationSummary>;
export type DataIntegrationsList = DataIntegrationSummary[];
export declare const DataIntegrationsList: any;
export interface ListDataIntegrationsResponse {
    DataIntegrations?: DataIntegrationSummary[];
    NextToken?: string;
}
export declare const ListDataIntegrationsResponse: S.Schema<ListDataIntegrationsResponse>;
export interface ListEventIntegrationAssociationsRequest {
    EventIntegrationName: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEventIntegrationAssociationsRequest: S.Schema<ListEventIntegrationAssociationsRequest>;
export type EventBridgeRuleName = string;
export interface EventIntegrationAssociation {
    EventIntegrationAssociationArn?: string;
    EventIntegrationAssociationId?: string;
    EventIntegrationName?: string;
    ClientId?: string;
    EventBridgeRuleName?: string;
    ClientAssociationMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const EventIntegrationAssociation: S.Schema<EventIntegrationAssociation>;
export type EventIntegrationAssociationsList = EventIntegrationAssociation[];
export declare const EventIntegrationAssociationsList: any;
export interface ListEventIntegrationAssociationsResponse {
    EventIntegrationAssociations?: EventIntegrationAssociation[];
    NextToken?: string;
}
export declare const ListEventIntegrationAssociationsResponse: S.Schema<ListEventIntegrationAssociationsResponse>;
export interface ListEventIntegrationsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEventIntegrationsRequest: S.Schema<ListEventIntegrationsRequest>;
export interface EventIntegration {
    EventIntegrationArn?: string;
    Name?: string;
    Description?: string;
    EventFilter?: EventFilter;
    EventBridgeBus?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const EventIntegration: S.Schema<EventIntegration>;
export type EventIntegrationsList = EventIntegration[];
export declare const EventIntegrationsList: any;
export interface ListEventIntegrationsResponse {
    EventIntegrations?: EventIntegration[];
    NextToken?: string;
}
export declare const ListEventIntegrationsResponse: S.Schema<ListEventIntegrationsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateApplicationRequest {
    Arn: string;
    Name?: string;
    Description?: string;
    ApplicationSourceConfig?: ApplicationSourceConfig;
    Subscriptions?: Subscription[];
    Publications?: Publication[];
    Permissions?: string[];
    IsService?: boolean;
    InitializationTimeout?: number;
    ApplicationConfig?: ApplicationConfig;
    IframeConfig?: IframeConfig;
    ApplicationType?: ApplicationType;
}
export declare const UpdateApplicationRequest: S.Schema<UpdateApplicationRequest>;
export interface UpdateApplicationResponse {
}
export declare const UpdateApplicationResponse: S.Schema<UpdateApplicationResponse>;
export interface UpdateDataIntegrationRequest {
    Identifier: string;
    Name?: string;
    Description?: string;
}
export declare const UpdateDataIntegrationRequest: S.Schema<UpdateDataIntegrationRequest>;
export interface UpdateDataIntegrationResponse {
}
export declare const UpdateDataIntegrationResponse: S.Schema<UpdateDataIntegrationResponse>;
export interface UpdateDataIntegrationAssociationRequest {
    DataIntegrationIdentifier: string;
    DataIntegrationAssociationIdentifier: string;
    ExecutionConfiguration: ExecutionConfiguration;
}
export declare const UpdateDataIntegrationAssociationRequest: S.Schema<UpdateDataIntegrationAssociationRequest>;
export interface UpdateDataIntegrationAssociationResponse {
}
export declare const UpdateDataIntegrationAssociationResponse: S.Schema<UpdateDataIntegrationAssociationResponse>;
export interface UpdateEventIntegrationRequest {
    Name: string;
    Description?: string;
}
export declare const UpdateEventIntegrationRequest: S.Schema<UpdateEventIntegrationRequest>;
export interface UpdateEventIntegrationResponse {
}
export declare const UpdateEventIntegrationResponse: S.Schema<UpdateEventIntegrationResponse>;
export type Message = string;
export type CreateApplicationError = AccessDeniedException | DuplicateResourceException | InternalServiceError | InvalidRequestException | ResourceQuotaExceededException | ThrottlingException | UnsupportedOperationException | TooManyRequestsException | CommonErrors;
/**
 * Creates and persists an Application resource.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateDataIntegrationError = AccessDeniedException | DuplicateResourceException | InternalServiceError | InvalidRequestException | ResourceQuotaExceededException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Creates and persists a DataIntegration resource.
 *
 * You cannot create a DataIntegration association for a DataIntegration that has been
 * previously associated. Use a different DataIntegration, or recreate the DataIntegration
 * using the `CreateDataIntegration` API.
 */
export declare const createDataIntegration: API.OperationMethod<CreateDataIntegrationRequest, CreateDataIntegrationResponse, CreateDataIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateDataIntegrationAssociationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ResourceQuotaExceededException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Creates and persists a DataIntegrationAssociation resource.
 */
export declare const createDataIntegrationAssociation: API.OperationMethod<CreateDataIntegrationAssociationRequest, CreateDataIntegrationAssociationResponse, CreateDataIntegrationAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateEventIntegrationError = AccessDeniedException | DuplicateResourceException | InternalServiceError | InvalidRequestException | ResourceQuotaExceededException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Creates an EventIntegration, given a specified name, description, and a reference to an
 * Amazon EventBridge bus in your account and a partner event source that pushes events to
 * that bus. No objects are created in the your account, only metadata that is persisted on the
 * EventIntegration control plane.
 */
export declare const createEventIntegration: API.OperationMethod<CreateEventIntegrationRequest, CreateEventIntegrationResponse, CreateEventIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the Application. Only Applications that don't have any Application Associations
 * can be deleted.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteDataIntegrationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the DataIntegration. Only DataIntegrations that don't have any
 * DataIntegrationAssociations can be deleted. Deleting a DataIntegration also deletes the
 * underlying Amazon AppFlow flow and service linked role.
 *
 * You cannot create a DataIntegration association for a DataIntegration that has been previously associated.
 * Use a different DataIntegration, or recreate the DataIntegration using the
 * CreateDataIntegration API.
 */
export declare const deleteDataIntegration: API.OperationMethod<DeleteDataIntegrationRequest, DeleteDataIntegrationResponse, DeleteDataIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteEventIntegrationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the specified existing event integration. If the event integration is associated
 * with clients, the request is rejected.
 */
export declare const deleteEventIntegration: API.OperationMethod<DeleteEventIntegrationRequest, DeleteEventIntegrationResponse, DeleteEventIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Get an Application resource.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetDataIntegrationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns information about the DataIntegration.
 *
 * You cannot create a DataIntegration association for a DataIntegration that has been previously associated.
 * Use a different DataIntegration, or recreate the DataIntegration using the
 * CreateDataIntegration API.
 */
export declare const getDataIntegration: API.OperationMethod<GetDataIntegrationRequest, GetDataIntegrationResponse, GetDataIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetEventIntegrationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns information about the event integration.
 */
export declare const getEventIntegration: API.OperationMethod<GetEventIntegrationRequest, GetEventIntegrationResponse, GetEventIntegrationError, Credentials | HttpClient.HttpClient>;
export type ListApplicationAssociationsError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of application associations for an application.
 */
export declare const listApplicationAssociations: API.PaginatedOperationMethod<ListApplicationAssociationsRequest, ListApplicationAssociationsResponse, ListApplicationAssociationsError, Credentials | HttpClient.HttpClient, ApplicationAssociationSummary>;
export type ListApplicationsError = AccessDeniedException | InternalServiceError | InvalidRequestException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Lists applications in the account.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListDataIntegrationAssociationsError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of DataIntegration associations in the account.
 *
 * You cannot create a DataIntegration association for a DataIntegration that has been previously associated.
 * Use a different DataIntegration, or recreate the DataIntegration using the
 * CreateDataIntegration API.
 */
export declare const listDataIntegrationAssociations: API.PaginatedOperationMethod<ListDataIntegrationAssociationsRequest, ListDataIntegrationAssociationsResponse, ListDataIntegrationAssociationsError, Credentials | HttpClient.HttpClient, DataIntegrationAssociationSummary>;
export type ListDataIntegrationsError = AccessDeniedException | InternalServiceError | InvalidRequestException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of DataIntegrations in the account.
 *
 * You cannot create a DataIntegration association for a DataIntegration that has been previously associated.
 * Use a different DataIntegration, or recreate the DataIntegration using the
 * CreateDataIntegration API.
 */
export declare const listDataIntegrations: API.PaginatedOperationMethod<ListDataIntegrationsRequest, ListDataIntegrationsResponse, ListDataIntegrationsError, Credentials | HttpClient.HttpClient, DataIntegrationSummary>;
export type ListEventIntegrationAssociationsError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of event integration associations in the account.
 */
export declare const listEventIntegrationAssociations: API.PaginatedOperationMethod<ListEventIntegrationAssociationsRequest, ListEventIntegrationAssociationsResponse, ListEventIntegrationAssociationsError, Credentials | HttpClient.HttpClient, EventIntegrationAssociation>;
export type ListEventIntegrationsError = AccessDeniedException | InternalServiceError | InvalidRequestException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of event integrations in the account.
 */
export declare const listEventIntegrations: API.PaginatedOperationMethod<ListEventIntegrationsRequest, ListEventIntegrationsResponse, ListEventIntegrationsError, Credentials | HttpClient.HttpClient, EventIntegration>;
export type ListTagsForResourceError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Adds the specified tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnsupportedOperationException | TooManyRequestsException | CommonErrors;
/**
 * Updates and persists an Application resource.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateDataIntegrationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Updates the description of a DataIntegration.
 *
 * You cannot create a DataIntegration association for a DataIntegration that has been previously associated.
 * Use a different DataIntegration, or recreate the DataIntegration using the
 * CreateDataIntegration API.
 */
export declare const updateDataIntegration: API.OperationMethod<UpdateDataIntegrationRequest, UpdateDataIntegrationResponse, UpdateDataIntegrationError, Credentials | HttpClient.HttpClient>;
export type UpdateDataIntegrationAssociationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Updates and persists a DataIntegrationAssociation resource.
 *
 * Updating a DataIntegrationAssociation with ExecutionConfiguration will rerun the on-demand job.
 */
export declare const updateDataIntegrationAssociation: API.OperationMethod<UpdateDataIntegrationAssociationRequest, UpdateDataIntegrationAssociationResponse, UpdateDataIntegrationAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateEventIntegrationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Updates the description of an event integration.
 */
export declare const updateEventIntegration: API.OperationMethod<UpdateEventIntegrationRequest, UpdateEventIntegrationResponse, UpdateEventIntegrationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appintegrations.d.ts.map