import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ActiveInstanceRefreshNotFoundFault_base: S.Class<ActiveInstanceRefreshNotFoundFault, S.TaggedStruct<"ActiveInstanceRefreshNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ActiveInstanceRefreshNotFoundFault extends /*@__PURE__*/ ActiveInstanceRefreshNotFoundFault_base {
}
declare const AlreadyExistsFault_base: S.Class<AlreadyExistsFault, S.TaggedStruct<"AlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsFault extends /*@__PURE__*/ AlreadyExistsFault_base {
}
declare const AutoScalingGroupNotFound_base: S.Class<AutoScalingGroupNotFound, S.TaggedStruct<"AutoScalingGroupNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AutoScalingGroupNotFound extends /*@__PURE__*/ AutoScalingGroupNotFound_base {
}
declare const IdempotentCallInProgressFault_base: S.Class<IdempotentCallInProgressFault, S.TaggedStruct<"IdempotentCallInProgressFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class IdempotentCallInProgressFault extends /*@__PURE__*/ IdempotentCallInProgressFault_base {
}
declare const IdempotentParameterMismatchError_base: S.Class<IdempotentParameterMismatchError, S.TaggedStruct<"IdempotentParameterMismatchError", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IdempotentParameterMismatchError extends /*@__PURE__*/ IdempotentParameterMismatchError_base {
}
declare const InstanceRefreshInProgressFault_base: S.Class<InstanceRefreshInProgressFault, S.TaggedStruct<"InstanceRefreshInProgressFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InstanceRefreshInProgressFault extends /*@__PURE__*/ InstanceRefreshInProgressFault_base {
}
declare const InvalidNextToken_base: S.Class<InvalidNextToken, S.TaggedStruct<"InvalidNextToken", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextToken extends /*@__PURE__*/ InvalidNextToken_base {
}
declare const IrreversibleInstanceRefreshFault_base: S.Class<IrreversibleInstanceRefreshFault, S.TaggedStruct<"IrreversibleInstanceRefreshFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IrreversibleInstanceRefreshFault extends /*@__PURE__*/ IrreversibleInstanceRefreshFault_base {
}
declare const LimitExceededFault_base: S.Class<LimitExceededFault, S.TaggedStruct<"LimitExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededFault extends /*@__PURE__*/ LimitExceededFault_base {
}
declare const ResourceContentionFault_base: S.Class<ResourceContentionFault, S.TaggedStruct<"ResourceContentionFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ResourceContentionFault extends /*@__PURE__*/ ResourceContentionFault_base {
}
declare const ResourceInUseFault_base: S.Class<ResourceInUseFault, S.TaggedStruct<"ResourceInUseFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseFault extends /*@__PURE__*/ ResourceInUseFault_base {
}
declare const ScalingActivityInProgressFault_base: S.Class<ScalingActivityInProgressFault, S.TaggedStruct<"ScalingActivityInProgressFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ScalingActivityInProgressFault extends /*@__PURE__*/ ScalingActivityInProgressFault_base {
}
declare const ServiceLinkedRoleFailure_base: S.Class<ServiceLinkedRoleFailure, S.TaggedStruct<"ServiceLinkedRoleFailure", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceLinkedRoleFailure extends /*@__PURE__*/ ServiceLinkedRoleFailure_base {
}
export type XmlStringMaxLen19 = string;
export type InstanceIds = string[];
export declare const InstanceIds: any;
export type XmlStringMaxLen255 = string;
export interface AttachInstancesQuery {
    InstanceIds?: string[];
    AutoScalingGroupName?: string;
}
export declare const AttachInstancesQuery: S.Schema<AttachInstancesQuery>;
export interface AttachInstancesResponse {
}
export declare const AttachInstancesResponse: S.Schema<AttachInstancesResponse>;
export type LoadBalancerNames = string[];
export declare const LoadBalancerNames: any;
export interface AttachLoadBalancersType {
    AutoScalingGroupName?: string;
    LoadBalancerNames?: string[];
}
export declare const AttachLoadBalancersType: S.Schema<AttachLoadBalancersType>;
export interface AttachLoadBalancersResultType {
}
export declare const AttachLoadBalancersResultType: S.Schema<AttachLoadBalancersResultType>;
export type XmlStringMaxLen511 = string;
export type TargetGroupARNs = string[];
export declare const TargetGroupARNs: any;
export interface AttachLoadBalancerTargetGroupsType {
    AutoScalingGroupName?: string;
    TargetGroupARNs?: string[];
}
export declare const AttachLoadBalancerTargetGroupsType: S.Schema<AttachLoadBalancerTargetGroupsType>;
export interface AttachLoadBalancerTargetGroupsResultType {
}
export declare const AttachLoadBalancerTargetGroupsResultType: S.Schema<AttachLoadBalancerTargetGroupsResultType>;
export interface TrafficSourceIdentifier {
    Identifier?: string;
    Type?: string;
}
export declare const TrafficSourceIdentifier: S.Schema<TrafficSourceIdentifier>;
export type TrafficSources = TrafficSourceIdentifier[];
export declare const TrafficSources: any;
export type SkipZonalShiftValidation = boolean;
export interface AttachTrafficSourcesType {
    AutoScalingGroupName?: string;
    TrafficSources?: TrafficSourceIdentifier[];
    SkipZonalShiftValidation?: boolean;
}
export declare const AttachTrafficSourcesType: S.Schema<AttachTrafficSourcesType>;
export interface AttachTrafficSourcesResultType {
}
export declare const AttachTrafficSourcesResultType: S.Schema<AttachTrafficSourcesResultType>;
export type ScheduledActionNames = string[];
export declare const ScheduledActionNames: any;
export interface BatchDeleteScheduledActionType {
    AutoScalingGroupName?: string;
    ScheduledActionNames?: string[];
}
export declare const BatchDeleteScheduledActionType: S.Schema<BatchDeleteScheduledActionType>;
export type XmlStringMaxLen64 = string;
export type XmlString = string;
export interface FailedScheduledUpdateGroupActionRequest {
    ScheduledActionName?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const FailedScheduledUpdateGroupActionRequest: S.Schema<FailedScheduledUpdateGroupActionRequest>;
export type FailedScheduledUpdateGroupActionRequests = FailedScheduledUpdateGroupActionRequest[];
export declare const FailedScheduledUpdateGroupActionRequests: any;
export interface BatchDeleteScheduledActionAnswer {
    FailedScheduledActions?: (FailedScheduledUpdateGroupActionRequest & {
        ScheduledActionName: XmlStringMaxLen255;
    })[];
}
export declare const BatchDeleteScheduledActionAnswer: S.Schema<BatchDeleteScheduledActionAnswer>;
export type AutoScalingGroupMinSize = number;
export type AutoScalingGroupMaxSize = number;
export type AutoScalingGroupDesiredCapacity = number;
export interface ScheduledUpdateGroupActionRequest {
    ScheduledActionName?: string;
    StartTime?: Date;
    EndTime?: Date;
    Recurrence?: string;
    MinSize?: number;
    MaxSize?: number;
    DesiredCapacity?: number;
    TimeZone?: string;
}
export declare const ScheduledUpdateGroupActionRequest: S.Schema<ScheduledUpdateGroupActionRequest>;
export type ScheduledUpdateGroupActionRequests = ScheduledUpdateGroupActionRequest[];
export declare const ScheduledUpdateGroupActionRequests: any;
export interface BatchPutScheduledUpdateGroupActionType {
    AutoScalingGroupName?: string;
    ScheduledUpdateGroupActions?: ScheduledUpdateGroupActionRequest[];
}
export declare const BatchPutScheduledUpdateGroupActionType: S.Schema<BatchPutScheduledUpdateGroupActionType>;
export interface BatchPutScheduledUpdateGroupActionAnswer {
    FailedScheduledUpdateGroupActions?: (FailedScheduledUpdateGroupActionRequest & {
        ScheduledActionName: XmlStringMaxLen255;
    })[];
}
export declare const BatchPutScheduledUpdateGroupActionAnswer: S.Schema<BatchPutScheduledUpdateGroupActionAnswer>;
export interface CancelInstanceRefreshType {
    AutoScalingGroupName?: string;
    WaitForTransitioningInstances?: boolean;
}
export declare const CancelInstanceRefreshType: S.Schema<CancelInstanceRefreshType>;
export interface CancelInstanceRefreshAnswer {
    InstanceRefreshId?: string;
}
export declare const CancelInstanceRefreshAnswer: S.Schema<CancelInstanceRefreshAnswer>;
export type AsciiStringMaxLen255 = string;
export type ResourceName = string;
export type LifecycleActionToken = string;
export type LifecycleActionResult = string;
export interface CompleteLifecycleActionType {
    LifecycleHookName?: string;
    AutoScalingGroupName?: string;
    LifecycleActionToken?: string;
    LifecycleActionResult?: string;
    InstanceId?: string;
}
export declare const CompleteLifecycleActionType: S.Schema<CompleteLifecycleActionType>;
export interface CompleteLifecycleActionAnswer {
}
export declare const CompleteLifecycleActionAnswer: S.Schema<CompleteLifecycleActionAnswer>;
export type LaunchTemplateName = string;
export interface LaunchTemplateSpecification {
    LaunchTemplateId?: string;
    LaunchTemplateName?: string;
    Version?: string;
}
export declare const LaunchTemplateSpecification: S.Schema<LaunchTemplateSpecification>;
export type XmlStringMaxLen32 = string;
export type NullablePositiveInteger = number;
export interface VCpuCountRequest {
    Min?: number;
    Max?: number;
}
export declare const VCpuCountRequest: S.Schema<VCpuCountRequest>;
export interface MemoryMiBRequest {
    Min?: number;
    Max?: number;
}
export declare const MemoryMiBRequest: S.Schema<MemoryMiBRequest>;
export type CpuManufacturer = "intel" | "amd" | "amazon-web-services" | "apple" | (string & {});
export declare const CpuManufacturer: any;
export type CpuManufacturers = CpuManufacturer[];
export declare const CpuManufacturers: any;
export type NullablePositiveDouble = number;
export interface MemoryGiBPerVCpuRequest {
    Min?: number;
    Max?: number;
}
export declare const MemoryGiBPerVCpuRequest: S.Schema<MemoryGiBPerVCpuRequest>;
export type ExcludedInstance = string;
export type ExcludedInstanceTypes = string[];
export declare const ExcludedInstanceTypes: any;
export type InstanceGeneration = "current" | "previous" | (string & {});
export declare const InstanceGeneration: any;
export type InstanceGenerations = InstanceGeneration[];
export declare const InstanceGenerations: any;
export type BareMetal = "included" | "excluded" | "required" | (string & {});
export declare const BareMetal: any;
export type BurstablePerformance = "included" | "excluded" | "required" | (string & {});
export declare const BurstablePerformance: any;
export interface NetworkInterfaceCountRequest {
    Min?: number;
    Max?: number;
}
export declare const NetworkInterfaceCountRequest: S.Schema<NetworkInterfaceCountRequest>;
export type LocalStorage = "included" | "excluded" | "required" | (string & {});
export declare const LocalStorage: any;
export type LocalStorageType = "hdd" | "ssd" | (string & {});
export declare const LocalStorageType: any;
export type LocalStorageTypes = LocalStorageType[];
export declare const LocalStorageTypes: any;
export interface TotalLocalStorageGBRequest {
    Min?: number;
    Max?: number;
}
export declare const TotalLocalStorageGBRequest: S.Schema<TotalLocalStorageGBRequest>;
export interface BaselineEbsBandwidthMbpsRequest {
    Min?: number;
    Max?: number;
}
export declare const BaselineEbsBandwidthMbpsRequest: S.Schema<BaselineEbsBandwidthMbpsRequest>;
export type AcceleratorType = "gpu" | "fpga" | "inference" | (string & {});
export declare const AcceleratorType: any;
export type AcceleratorTypes = AcceleratorType[];
export declare const AcceleratorTypes: any;
export interface AcceleratorCountRequest {
    Min?: number;
    Max?: number;
}
export declare const AcceleratorCountRequest: S.Schema<AcceleratorCountRequest>;
export type AcceleratorManufacturer = "nvidia" | "amd" | "amazon-web-services" | "xilinx" | (string & {});
export declare const AcceleratorManufacturer: any;
export type AcceleratorManufacturers = AcceleratorManufacturer[];
export declare const AcceleratorManufacturers: any;
export type AcceleratorName = "a100" | "v100" | "k80" | "t4" | "m60" | "radeon-pro-v520" | "vu9p" | (string & {});
export declare const AcceleratorName: any;
export type AcceleratorNames = AcceleratorName[];
export declare const AcceleratorNames: any;
export interface AcceleratorTotalMemoryMiBRequest {
    Min?: number;
    Max?: number;
}
export declare const AcceleratorTotalMemoryMiBRequest: S.Schema<AcceleratorTotalMemoryMiBRequest>;
export interface NetworkBandwidthGbpsRequest {
    Min?: number;
    Max?: number;
}
export declare const NetworkBandwidthGbpsRequest: S.Schema<NetworkBandwidthGbpsRequest>;
export type AllowedInstanceType = string;
export type AllowedInstanceTypes = string[];
export declare const AllowedInstanceTypes: any;
export interface PerformanceFactorReferenceRequest {
    InstanceFamily?: string;
}
export declare const PerformanceFactorReferenceRequest: S.Schema<PerformanceFactorReferenceRequest>;
export type PerformanceFactorReferenceSetRequest = PerformanceFactorReferenceRequest[];
export declare const PerformanceFactorReferenceSetRequest: any;
export interface CpuPerformanceFactorRequest {
    References?: PerformanceFactorReferenceRequest[];
}
export declare const CpuPerformanceFactorRequest: S.Schema<CpuPerformanceFactorRequest>;
export interface BaselinePerformanceFactorsRequest {
    Cpu?: CpuPerformanceFactorRequest;
}
export declare const BaselinePerformanceFactorsRequest: S.Schema<BaselinePerformanceFactorsRequest>;
export interface InstanceRequirements {
    VCpuCount?: VCpuCountRequest;
    MemoryMiB?: MemoryMiBRequest;
    CpuManufacturers?: CpuManufacturer[];
    MemoryGiBPerVCpu?: MemoryGiBPerVCpuRequest;
    ExcludedInstanceTypes?: string[];
    InstanceGenerations?: InstanceGeneration[];
    SpotMaxPricePercentageOverLowestPrice?: number;
    MaxSpotPriceAsPercentageOfOptimalOnDemandPrice?: number;
    OnDemandMaxPricePercentageOverLowestPrice?: number;
    BareMetal?: BareMetal;
    BurstablePerformance?: BurstablePerformance;
    RequireHibernateSupport?: boolean;
    NetworkInterfaceCount?: NetworkInterfaceCountRequest;
    LocalStorage?: LocalStorage;
    LocalStorageTypes?: LocalStorageType[];
    TotalLocalStorageGB?: TotalLocalStorageGBRequest;
    BaselineEbsBandwidthMbps?: BaselineEbsBandwidthMbpsRequest;
    AcceleratorTypes?: AcceleratorType[];
    AcceleratorCount?: AcceleratorCountRequest;
    AcceleratorManufacturers?: AcceleratorManufacturer[];
    AcceleratorNames?: AcceleratorName[];
    AcceleratorTotalMemoryMiB?: AcceleratorTotalMemoryMiBRequest;
    NetworkBandwidthGbps?: NetworkBandwidthGbpsRequest;
    AllowedInstanceTypes?: string[];
    BaselinePerformanceFactors?: BaselinePerformanceFactorsRequest;
}
export declare const InstanceRequirements: S.Schema<InstanceRequirements>;
export type ImageId = string;
export interface LaunchTemplateOverrides {
    InstanceType?: string;
    WeightedCapacity?: string;
    LaunchTemplateSpecification?: LaunchTemplateSpecification;
    InstanceRequirements?: InstanceRequirements;
    ImageId?: string;
}
export declare const LaunchTemplateOverrides: S.Schema<LaunchTemplateOverrides>;
export type Overrides = LaunchTemplateOverrides[];
export declare const Overrides: any;
export interface LaunchTemplate {
    LaunchTemplateSpecification?: LaunchTemplateSpecification;
    Overrides?: LaunchTemplateOverrides[];
}
export declare const LaunchTemplate: S.Schema<LaunchTemplate>;
export type OnDemandBaseCapacity = number;
export type OnDemandPercentageAboveBaseCapacity = number;
export type SpotInstancePools = number;
export type MixedInstanceSpotPrice = string;
export type TargetCapacityType = "on-demand-capacity-reservation" | "capacity-block" | "interruptible-capacity-reservation" | "on-demand" | (string & {});
export declare const TargetCapacityType: any;
export type TargetCapacityTypes = TargetCapacityType[];
export declare const TargetCapacityTypes: any;
export interface DistributionSegment {
    TargetCapacityTypes?: TargetCapacityType[];
}
export declare const DistributionSegment: S.Schema<DistributionSegment>;
export type DistributionSegments = DistributionSegment[];
export declare const DistributionSegments: any;
export interface InstancesDistribution {
    OnDemandAllocationStrategy?: string;
    OnDemandBaseCapacity?: number;
    OnDemandPercentageAboveBaseCapacity?: number;
    SpotAllocationStrategy?: string;
    SpotInstancePools?: number;
    SpotMaxPrice?: string;
    DistributionSegments?: DistributionSegment[];
}
export declare const InstancesDistribution: S.Schema<InstancesDistribution>;
export interface MixedInstancesPolicy {
    LaunchTemplate?: LaunchTemplate;
    InstancesDistribution?: InstancesDistribution;
}
export declare const MixedInstancesPolicy: S.Schema<MixedInstancesPolicy>;
export type Cooldown = number;
export type AvailabilityZones = string[];
export declare const AvailabilityZones: any;
export type AvailabilityZoneIds = string[];
export declare const AvailabilityZoneIds: any;
export type HealthCheckGracePeriod = number;
export type XmlStringMaxLen5000 = string;
export type XmlStringMaxLen1600 = string;
export type TerminationPolicies = string[];
export declare const TerminationPolicies: any;
export type InstanceProtected = boolean;
export type CapacityRebalanceEnabled = boolean;
export type LifecycleTransition = string;
export type AnyPrintableAsciiStringMaxLen4000 = string;
export type HeartbeatTimeout = number;
export type NotificationTargetResourceName = string;
export interface LifecycleHookSpecification {
    LifecycleHookName?: string;
    LifecycleTransition?: string;
    NotificationMetadata?: string;
    HeartbeatTimeout?: number;
    DefaultResult?: string;
    NotificationTargetARN?: string;
    RoleARN?: string;
}
export declare const LifecycleHookSpecification: S.Schema<LifecycleHookSpecification>;
export type LifecycleHookSpecifications = LifecycleHookSpecification[];
export declare const LifecycleHookSpecifications: any;
export type DeletionProtection = "none" | "prevent-force-deletion" | "prevent-all-deletion" | (string & {});
export declare const DeletionProtection: any;
export type TagKey = string;
export type TagValue = string;
export type PropagateAtLaunch = boolean;
export interface Tag {
    ResourceId?: string;
    ResourceType?: string;
    Key?: string;
    Value?: string;
    PropagateAtLaunch?: boolean;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export type MaxInstanceLifetime = number;
export type Context = string;
export type DefaultInstanceWarmup = number;
export type IntPercentResettable = number;
export type IntPercent100To200Resettable = number;
export interface InstanceMaintenancePolicy {
    MinHealthyPercentage?: number;
    MaxHealthyPercentage?: number;
}
export declare const InstanceMaintenancePolicy: S.Schema<InstanceMaintenancePolicy>;
export type CapacityDistributionStrategy = "balanced-only" | "balanced-best-effort" | "reservations-then-balanced" | (string & {});
export declare const CapacityDistributionStrategy: any;
export interface AvailabilityZoneDistribution {
    CapacityDistributionStrategy?: CapacityDistributionStrategy;
}
export declare const AvailabilityZoneDistribution: S.Schema<AvailabilityZoneDistribution>;
export type ZonalShiftEnabled = boolean;
export type ImpairedZoneHealthCheckBehavior = "ReplaceUnhealthy" | "IgnoreUnhealthy" | (string & {});
export declare const ImpairedZoneHealthCheckBehavior: any;
export interface AvailabilityZoneImpairmentPolicy {
    ZonalShiftEnabled?: boolean;
    ImpairedZoneHealthCheckBehavior?: ImpairedZoneHealthCheckBehavior;
}
export declare const AvailabilityZoneImpairmentPolicy: S.Schema<AvailabilityZoneImpairmentPolicy>;
export type CapacityReservationPreference = "capacity-reservations-only" | "capacity-reservations-first" | "none" | "default" | (string & {});
export declare const CapacityReservationPreference: any;
export type CapacityReservationIds = string[];
export declare const CapacityReservationIds: any;
export type CapacityReservationResourceGroupArns = string[];
export declare const CapacityReservationResourceGroupArns: any;
export interface CapacityReservationTarget {
    CapacityReservationIds?: string[];
    CapacityReservationResourceGroupArns?: string[];
}
export declare const CapacityReservationTarget: S.Schema<CapacityReservationTarget>;
export interface CapacityReservationSpecification {
    CapacityReservationPreference?: CapacityReservationPreference;
    CapacityReservationTarget?: CapacityReservationTarget;
}
export declare const CapacityReservationSpecification: S.Schema<CapacityReservationSpecification>;
export type RetentionAction = "retain" | "terminate" | (string & {});
export declare const RetentionAction: any;
export interface RetentionTriggers {
    TerminateHookAbandon?: RetentionAction;
}
export declare const RetentionTriggers: S.Schema<RetentionTriggers>;
export interface InstanceLifecyclePolicy {
    RetentionTriggers?: RetentionTriggers;
}
export declare const InstanceLifecyclePolicy: S.Schema<InstanceLifecyclePolicy>;
export type ManagerIdentifier = string;
export interface Operator {
    Principal?: string;
}
export declare const Operator: S.Schema<Operator>;
export interface CreateAutoScalingGroupType {
    AutoScalingGroupName?: string;
    LaunchConfigurationName?: string;
    LaunchTemplate?: LaunchTemplateSpecification;
    MixedInstancesPolicy?: MixedInstancesPolicy;
    InstanceId?: string;
    MinSize?: number;
    MaxSize?: number;
    DesiredCapacity?: number;
    DefaultCooldown?: number;
    AvailabilityZones?: string[];
    AvailabilityZoneIds?: string[];
    LoadBalancerNames?: string[];
    TargetGroupARNs?: string[];
    HealthCheckType?: string;
    HealthCheckGracePeriod?: number;
    PlacementGroup?: string;
    VPCZoneIdentifier?: string;
    TerminationPolicies?: string[];
    NewInstancesProtectedFromScaleIn?: boolean;
    CapacityRebalance?: boolean;
    LifecycleHookSpecificationList?: LifecycleHookSpecification[];
    DeletionProtection?: DeletionProtection;
    Tags?: Tag[];
    ServiceLinkedRoleARN?: string;
    MaxInstanceLifetime?: number;
    Context?: string;
    DesiredCapacityType?: string;
    DefaultInstanceWarmup?: number;
    TrafficSources?: TrafficSourceIdentifier[];
    InstanceMaintenancePolicy?: InstanceMaintenancePolicy;
    AvailabilityZoneDistribution?: AvailabilityZoneDistribution;
    AvailabilityZoneImpairmentPolicy?: AvailabilityZoneImpairmentPolicy;
    SkipZonalShiftValidation?: boolean;
    CapacityReservationSpecification?: CapacityReservationSpecification;
    InstanceLifecyclePolicy?: InstanceLifecyclePolicy;
    Operator?: Operator;
}
export declare const CreateAutoScalingGroupType: S.Schema<CreateAutoScalingGroupType>;
export interface CreateAutoScalingGroupResponse {
}
export declare const CreateAutoScalingGroupResponse: S.Schema<CreateAutoScalingGroupResponse>;
export type SecurityGroups = string[];
export declare const SecurityGroups: any;
export type ClassicLinkVPCSecurityGroups = string[];
export declare const ClassicLinkVPCSecurityGroups: any;
export type XmlStringUserData = string;
export type BlockDeviceEbsVolumeSize = number;
export type BlockDeviceEbsVolumeType = string;
export type BlockDeviceEbsDeleteOnTermination = boolean;
export type BlockDeviceEbsIops = number;
export type BlockDeviceEbsEncrypted = boolean;
export type BlockDeviceEbsThroughput = number;
export interface Ebs {
    SnapshotId?: string;
    VolumeSize?: number;
    VolumeType?: string;
    DeleteOnTermination?: boolean;
    Iops?: number;
    Encrypted?: boolean;
    Throughput?: number;
}
export declare const Ebs: S.Schema<Ebs>;
export type NoDevice = boolean;
export interface BlockDeviceMapping {
    VirtualName?: string;
    DeviceName?: string;
    Ebs?: Ebs;
    NoDevice?: boolean;
}
export declare const BlockDeviceMapping: S.Schema<BlockDeviceMapping>;
export type BlockDeviceMappings = BlockDeviceMapping[];
export declare const BlockDeviceMappings: any;
export type MonitoringEnabled = boolean;
export interface InstanceMonitoring {
    Enabled?: boolean;
}
export declare const InstanceMonitoring: S.Schema<InstanceMonitoring>;
export type SpotPrice = string;
export type EbsOptimized = boolean;
export type AssociatePublicIpAddress = boolean;
export type InstanceMetadataHttpTokensState = "optional" | "required" | (string & {});
export declare const InstanceMetadataHttpTokensState: any;
export type InstanceMetadataHttpPutResponseHopLimit = number;
export type InstanceMetadataEndpointState = "disabled" | "enabled" | (string & {});
export declare const InstanceMetadataEndpointState: any;
export interface InstanceMetadataOptions {
    HttpTokens?: InstanceMetadataHttpTokensState;
    HttpPutResponseHopLimit?: number;
    HttpEndpoint?: InstanceMetadataEndpointState;
}
export declare const InstanceMetadataOptions: S.Schema<InstanceMetadataOptions>;
export interface CreateLaunchConfigurationType {
    LaunchConfigurationName?: string;
    ImageId?: string;
    KeyName?: string;
    SecurityGroups?: string[];
    ClassicLinkVPCId?: string;
    ClassicLinkVPCSecurityGroups?: string[];
    UserData?: string;
    InstanceId?: string;
    InstanceType?: string;
    KernelId?: string;
    RamdiskId?: string;
    BlockDeviceMappings?: BlockDeviceMapping[];
    InstanceMonitoring?: InstanceMonitoring;
    SpotPrice?: string;
    IamInstanceProfile?: string;
    EbsOptimized?: boolean;
    AssociatePublicIpAddress?: boolean;
    PlacementTenancy?: string;
    MetadataOptions?: InstanceMetadataOptions;
}
export declare const CreateLaunchConfigurationType: S.Schema<CreateLaunchConfigurationType>;
export interface CreateLaunchConfigurationResponse {
}
export declare const CreateLaunchConfigurationResponse: S.Schema<CreateLaunchConfigurationResponse>;
export interface CreateOrUpdateTagsType {
    Tags?: Tag[];
}
export declare const CreateOrUpdateTagsType: S.Schema<CreateOrUpdateTagsType>;
export interface CreateOrUpdateTagsResponse {
}
export declare const CreateOrUpdateTagsResponse: S.Schema<CreateOrUpdateTagsResponse>;
export type ForceDelete = boolean;
export interface DeleteAutoScalingGroupType {
    AutoScalingGroupName?: string;
    ForceDelete?: boolean;
}
export declare const DeleteAutoScalingGroupType: S.Schema<DeleteAutoScalingGroupType>;
export interface DeleteAutoScalingGroupResponse {
}
export declare const DeleteAutoScalingGroupResponse: S.Schema<DeleteAutoScalingGroupResponse>;
export interface LaunchConfigurationNameType {
    LaunchConfigurationName?: string;
}
export declare const LaunchConfigurationNameType: S.Schema<LaunchConfigurationNameType>;
export interface DeleteLaunchConfigurationResponse {
}
export declare const DeleteLaunchConfigurationResponse: S.Schema<DeleteLaunchConfigurationResponse>;
export interface DeleteLifecycleHookType {
    LifecycleHookName?: string;
    AutoScalingGroupName?: string;
}
export declare const DeleteLifecycleHookType: S.Schema<DeleteLifecycleHookType>;
export interface DeleteLifecycleHookAnswer {
}
export declare const DeleteLifecycleHookAnswer: S.Schema<DeleteLifecycleHookAnswer>;
export interface DeleteNotificationConfigurationType {
    AutoScalingGroupName?: string;
    TopicARN?: string;
}
export declare const DeleteNotificationConfigurationType: S.Schema<DeleteNotificationConfigurationType>;
export interface DeleteNotificationConfigurationResponse {
}
export declare const DeleteNotificationConfigurationResponse: S.Schema<DeleteNotificationConfigurationResponse>;
export interface DeletePolicyType {
    AutoScalingGroupName?: string;
    PolicyName?: string;
}
export declare const DeletePolicyType: S.Schema<DeletePolicyType>;
export interface DeletePolicyResponse {
}
export declare const DeletePolicyResponse: S.Schema<DeletePolicyResponse>;
export interface DeleteScheduledActionType {
    AutoScalingGroupName?: string;
    ScheduledActionName?: string;
}
export declare const DeleteScheduledActionType: S.Schema<DeleteScheduledActionType>;
export interface DeleteScheduledActionResponse {
}
export declare const DeleteScheduledActionResponse: S.Schema<DeleteScheduledActionResponse>;
export interface DeleteTagsType {
    Tags?: Tag[];
}
export declare const DeleteTagsType: S.Schema<DeleteTagsType>;
export interface DeleteTagsResponse {
}
export declare const DeleteTagsResponse: S.Schema<DeleteTagsResponse>;
export interface DeleteWarmPoolType {
    AutoScalingGroupName?: string;
    ForceDelete?: boolean;
}
export declare const DeleteWarmPoolType: S.Schema<DeleteWarmPoolType>;
export interface DeleteWarmPoolAnswer {
}
export declare const DeleteWarmPoolAnswer: S.Schema<DeleteWarmPoolAnswer>;
export interface DescribeAccountLimitsRequest {
}
export declare const DescribeAccountLimitsRequest: S.Schema<DescribeAccountLimitsRequest>;
export type MaxNumberOfAutoScalingGroups = number;
export type MaxNumberOfLaunchConfigurations = number;
export type NumberOfAutoScalingGroups = number;
export type NumberOfLaunchConfigurations = number;
export interface DescribeAccountLimitsAnswer {
    MaxNumberOfAutoScalingGroups?: number;
    MaxNumberOfLaunchConfigurations?: number;
    NumberOfAutoScalingGroups?: number;
    NumberOfLaunchConfigurations?: number;
}
export declare const DescribeAccountLimitsAnswer: S.Schema<DescribeAccountLimitsAnswer>;
export interface DescribeAdjustmentTypesRequest {
}
export declare const DescribeAdjustmentTypesRequest: S.Schema<DescribeAdjustmentTypesRequest>;
export interface AdjustmentType {
    AdjustmentType?: string;
}
export declare const AdjustmentType: S.Schema<AdjustmentType>;
export type AdjustmentTypes = AdjustmentType[];
export declare const AdjustmentTypes: any;
export interface DescribeAdjustmentTypesAnswer {
    AdjustmentTypes?: AdjustmentType[];
}
export declare const DescribeAdjustmentTypesAnswer: S.Schema<DescribeAdjustmentTypesAnswer>;
export type AutoScalingGroupNames = string[];
export declare const AutoScalingGroupNames: any;
export type IncludeInstances = boolean;
export type MaxRecords = number;
export type Values = string[];
export declare const Values: any;
export interface Filter {
    Name?: string;
    Values?: string[];
}
export declare const Filter: S.Schema<Filter>;
export type Filters = Filter[];
export declare const Filters: any;
export interface AutoScalingGroupNamesType {
    AutoScalingGroupNames?: string[];
    IncludeInstances?: boolean;
    NextToken?: string;
    MaxRecords?: number;
    Filters?: Filter[];
}
export declare const AutoScalingGroupNamesType: S.Schema<AutoScalingGroupNamesType>;
export type AutoScalingGroupPredictedCapacity = number;
export type LifecycleState = "Pending" | "Pending:Wait" | "Pending:Proceed" | "Quarantined" | "InService" | "Terminating" | "Terminating:Wait" | "Terminating:Proceed" | "Terminating:Retained" | "Terminated" | "Detaching" | "Detached" | "EnteringStandby" | "Standby" | "ReplacingRootVolume" | "ReplacingRootVolume:Wait" | "ReplacingRootVolume:Proceed" | "RootVolumeReplaced" | "Warmed:Pending" | "Warmed:Pending:Wait" | "Warmed:Pending:Proceed" | "Warmed:Pending:Retained" | "Warmed:Terminating" | "Warmed:Terminating:Wait" | "Warmed:Terminating:Proceed" | "Warmed:Terminating:Retained" | "Warmed:Terminated" | "Warmed:Stopped" | "Warmed:Running" | "Warmed:Hibernated" | (string & {});
export declare const LifecycleState: any;
export interface Instance {
    InstanceId?: string;
    InstanceType?: string;
    AvailabilityZone?: string;
    AvailabilityZoneId?: string;
    LifecycleState?: LifecycleState;
    HealthStatus?: string;
    LaunchConfigurationName?: string;
    LaunchTemplate?: LaunchTemplateSpecification;
    ImageId?: string;
    ProtectedFromScaleIn?: boolean;
    WeightedCapacity?: string;
}
export declare const Instance: S.Schema<Instance>;
export type Instances = Instance[];
export declare const Instances: any;
export interface SuspendedProcess {
    ProcessName?: string;
    SuspensionReason?: string;
}
export declare const SuspendedProcess: S.Schema<SuspendedProcess>;
export type SuspendedProcesses = SuspendedProcess[];
export declare const SuspendedProcesses: any;
export interface EnabledMetric {
    Metric?: string;
    Granularity?: string;
}
export declare const EnabledMetric: S.Schema<EnabledMetric>;
export type EnabledMetrics = EnabledMetric[];
export declare const EnabledMetrics: any;
export interface TagDescription {
    ResourceId?: string;
    ResourceType?: string;
    Key?: string;
    Value?: string;
    PropagateAtLaunch?: boolean;
}
export declare const TagDescription: S.Schema<TagDescription>;
export type TagDescriptionList = TagDescription[];
export declare const TagDescriptionList: any;
export type MaxGroupPreparedCapacity = number;
export type WarmPoolMinSize = number;
export type WarmPoolState = "Stopped" | "Running" | "Hibernated" | (string & {});
export declare const WarmPoolState: any;
export type WarmPoolStatus = "PendingDelete" | (string & {});
export declare const WarmPoolStatus: any;
export type ReuseOnScaleIn = boolean;
export interface InstanceReusePolicy {
    ReuseOnScaleIn?: boolean;
}
export declare const InstanceReusePolicy: S.Schema<InstanceReusePolicy>;
export interface WarmPoolConfiguration {
    MaxGroupPreparedCapacity?: number;
    MinSize?: number;
    PoolState?: WarmPoolState;
    Status?: WarmPoolStatus;
    InstanceReusePolicy?: InstanceReusePolicy;
}
export declare const WarmPoolConfiguration: S.Schema<WarmPoolConfiguration>;
export type WarmPoolSize = number;
export interface AutoScalingGroup {
    AutoScalingGroupName?: string;
    AutoScalingGroupARN?: string;
    LaunchConfigurationName?: string;
    LaunchTemplate?: LaunchTemplateSpecification;
    MixedInstancesPolicy?: MixedInstancesPolicy;
    MinSize?: number;
    MaxSize?: number;
    DesiredCapacity?: number;
    PredictedCapacity?: number;
    DefaultCooldown?: number;
    AvailabilityZones?: string[];
    AvailabilityZoneIds?: string[];
    LoadBalancerNames?: string[];
    TargetGroupARNs?: string[];
    HealthCheckType?: string;
    HealthCheckGracePeriod?: number;
    Instances?: Instance[];
    CreatedTime?: Date;
    SuspendedProcesses?: SuspendedProcess[];
    PlacementGroup?: string;
    VPCZoneIdentifier?: string;
    EnabledMetrics?: EnabledMetric[];
    Status?: string;
    Tags?: TagDescription[];
    TerminationPolicies?: string[];
    NewInstancesProtectedFromScaleIn?: boolean;
    ServiceLinkedRoleARN?: string;
    MaxInstanceLifetime?: number;
    CapacityRebalance?: boolean;
    WarmPoolConfiguration?: WarmPoolConfiguration;
    WarmPoolSize?: number;
    Context?: string;
    DesiredCapacityType?: string;
    DefaultInstanceWarmup?: number;
    TrafficSources?: TrafficSourceIdentifier[];
    InstanceMaintenancePolicy?: InstanceMaintenancePolicy;
    DeletionProtection?: DeletionProtection;
    AvailabilityZoneDistribution?: AvailabilityZoneDistribution;
    AvailabilityZoneImpairmentPolicy?: AvailabilityZoneImpairmentPolicy;
    CapacityReservationSpecification?: CapacityReservationSpecification;
    InstanceLifecyclePolicy?: InstanceLifecyclePolicy;
    Operator?: Operator;
}
export declare const AutoScalingGroup: S.Schema<AutoScalingGroup>;
export type AutoScalingGroups = AutoScalingGroup[];
export declare const AutoScalingGroups: any;
export interface AutoScalingGroupsType {
    AutoScalingGroups: (AutoScalingGroup & {
        AutoScalingGroupName: XmlStringMaxLen255;
        MinSize: AutoScalingGroupMinSize;
        MaxSize: AutoScalingGroupMaxSize;
        DesiredCapacity: AutoScalingGroupDesiredCapacity;
        DefaultCooldown: Cooldown;
        AvailabilityZones: AvailabilityZones;
        HealthCheckType: XmlStringMaxLen32;
        CreatedTime: Date;
        MixedInstancesPolicy: MixedInstancesPolicy & {
            LaunchTemplate: LaunchTemplate & {
                Overrides: (LaunchTemplateOverrides & {
                    InstanceRequirements: InstanceRequirements & {
                        VCpuCount: VCpuCountRequest & {
                            Min: NullablePositiveInteger;
                        };
                        MemoryMiB: MemoryMiBRequest & {
                            Min: NullablePositiveInteger;
                        };
                    };
                })[];
            };
        };
        Instances: (Instance & {
            InstanceId: XmlStringMaxLen19;
            AvailabilityZone: XmlStringMaxLen255;
            LifecycleState: LifecycleState;
            HealthStatus: XmlStringMaxLen32;
            ProtectedFromScaleIn: InstanceProtected;
        })[];
        TrafficSources: (TrafficSourceIdentifier & {
            Identifier: XmlStringMaxLen511;
        })[];
        Operator: Operator & {
            Principal: ManagerIdentifier;
        };
    })[];
    NextToken?: string;
}
export declare const AutoScalingGroupsType: S.Schema<AutoScalingGroupsType>;
export interface DescribeAutoScalingInstancesType {
    InstanceIds?: string[];
    MaxRecords?: number;
    NextToken?: string;
}
export declare const DescribeAutoScalingInstancesType: S.Schema<DescribeAutoScalingInstancesType>;
export interface AutoScalingInstanceDetails {
    InstanceId?: string;
    InstanceType?: string;
    AutoScalingGroupName?: string;
    AvailabilityZone?: string;
    AvailabilityZoneId?: string;
    LifecycleState?: string;
    HealthStatus?: string;
    LaunchConfigurationName?: string;
    LaunchTemplate?: LaunchTemplateSpecification;
    ImageId?: string;
    ProtectedFromScaleIn?: boolean;
    WeightedCapacity?: string;
}
export declare const AutoScalingInstanceDetails: S.Schema<AutoScalingInstanceDetails>;
export type AutoScalingInstances = AutoScalingInstanceDetails[];
export declare const AutoScalingInstances: any;
export interface AutoScalingInstancesType {
    AutoScalingInstances?: (AutoScalingInstanceDetails & {
        InstanceId: XmlStringMaxLen19;
        AutoScalingGroupName: XmlStringMaxLen255;
        AvailabilityZone: XmlStringMaxLen255;
        LifecycleState: XmlStringMaxLen32;
        HealthStatus: XmlStringMaxLen32;
        ProtectedFromScaleIn: InstanceProtected;
    })[];
    NextToken?: string;
}
export declare const AutoScalingInstancesType: S.Schema<AutoScalingInstancesType>;
export interface DescribeAutoScalingNotificationTypesRequest {
}
export declare const DescribeAutoScalingNotificationTypesRequest: S.Schema<DescribeAutoScalingNotificationTypesRequest>;
export type AutoScalingNotificationTypes = string[];
export declare const AutoScalingNotificationTypes: any;
export interface DescribeAutoScalingNotificationTypesAnswer {
    AutoScalingNotificationTypes?: string[];
}
export declare const DescribeAutoScalingNotificationTypesAnswer: S.Schema<DescribeAutoScalingNotificationTypesAnswer>;
export type InstanceRefreshIds = string[];
export declare const InstanceRefreshIds: any;
export interface DescribeInstanceRefreshesType {
    AutoScalingGroupName?: string;
    InstanceRefreshIds?: string[];
    NextToken?: string;
    MaxRecords?: number;
}
export declare const DescribeInstanceRefreshesType: S.Schema<DescribeInstanceRefreshesType>;
export type InstanceRefreshStatus = "Pending" | "InProgress" | "Successful" | "Failed" | "Cancelling" | "Cancelled" | "RollbackInProgress" | "RollbackFailed" | "RollbackSuccessful" | "Baking" | (string & {});
export declare const InstanceRefreshStatus: any;
export type XmlStringMaxLen1023 = string;
export type IntPercent = number;
export type InstancesToUpdate = number;
export interface InstanceRefreshLivePoolProgress {
    PercentageComplete?: number;
    InstancesToUpdate?: number;
}
export declare const InstanceRefreshLivePoolProgress: S.Schema<InstanceRefreshLivePoolProgress>;
export interface InstanceRefreshWarmPoolProgress {
    PercentageComplete?: number;
    InstancesToUpdate?: number;
}
export declare const InstanceRefreshWarmPoolProgress: S.Schema<InstanceRefreshWarmPoolProgress>;
export interface InstanceRefreshProgressDetails {
    LivePoolProgress?: InstanceRefreshLivePoolProgress;
    WarmPoolProgress?: InstanceRefreshWarmPoolProgress;
}
export declare const InstanceRefreshProgressDetails: S.Schema<InstanceRefreshProgressDetails>;
export type RefreshInstanceWarmup = number;
export type NonZeroIntPercent = number;
export type CheckpointPercentages = number[];
export declare const CheckpointPercentages: any;
export type CheckpointDelay = number;
export type SkipMatching = boolean;
export type AutoRollback = boolean;
export type ScaleInProtectedInstances = "Refresh" | "Ignore" | "Wait" | (string & {});
export declare const ScaleInProtectedInstances: any;
export type StandbyInstances = "Terminate" | "Ignore" | "Wait" | (string & {});
export declare const StandbyInstances: any;
export type AlarmList = string[];
export declare const AlarmList: any;
export interface AlarmSpecification {
    Alarms?: string[];
}
export declare const AlarmSpecification: S.Schema<AlarmSpecification>;
export type IntPercent100To200 = number;
export type BakeTime = number;
export interface RefreshPreferences {
    MinHealthyPercentage?: number;
    InstanceWarmup?: number;
    CheckpointPercentages?: number[];
    CheckpointDelay?: number;
    SkipMatching?: boolean;
    AutoRollback?: boolean;
    ScaleInProtectedInstances?: ScaleInProtectedInstances;
    StandbyInstances?: StandbyInstances;
    AlarmSpecification?: AlarmSpecification;
    MaxHealthyPercentage?: number;
    BakeTime?: number;
}
export declare const RefreshPreferences: S.Schema<RefreshPreferences>;
export interface DesiredConfiguration {
    LaunchTemplate?: LaunchTemplateSpecification;
    MixedInstancesPolicy?: MixedInstancesPolicy;
}
export declare const DesiredConfiguration: S.Schema<DesiredConfiguration>;
export interface RollbackDetails {
    RollbackReason?: string;
    RollbackStartTime?: Date;
    PercentageCompleteOnRollback?: number;
    InstancesToUpdateOnRollback?: number;
    ProgressDetailsOnRollback?: InstanceRefreshProgressDetails;
}
export declare const RollbackDetails: S.Schema<RollbackDetails>;
export type RefreshStrategy = "Rolling" | "ReplaceRootVolume" | (string & {});
export declare const RefreshStrategy: any;
export interface InstanceRefresh {
    InstanceRefreshId?: string;
    AutoScalingGroupName?: string;
    Status?: InstanceRefreshStatus;
    StatusReason?: string;
    StartTime?: Date;
    EndTime?: Date;
    PercentageComplete?: number;
    InstancesToUpdate?: number;
    ProgressDetails?: InstanceRefreshProgressDetails;
    Preferences?: RefreshPreferences;
    DesiredConfiguration?: DesiredConfiguration;
    RollbackDetails?: RollbackDetails;
    Strategy?: RefreshStrategy;
}
export declare const InstanceRefresh: S.Schema<InstanceRefresh>;
export type InstanceRefreshes = InstanceRefresh[];
export declare const InstanceRefreshes: any;
export interface DescribeInstanceRefreshesAnswer {
    InstanceRefreshes?: (InstanceRefresh & {
        DesiredConfiguration: DesiredConfiguration & {
            MixedInstancesPolicy: MixedInstancesPolicy & {
                LaunchTemplate: LaunchTemplate & {
                    Overrides: (LaunchTemplateOverrides & {
                        InstanceRequirements: InstanceRequirements & {
                            VCpuCount: VCpuCountRequest & {
                                Min: NullablePositiveInteger;
                            };
                            MemoryMiB: MemoryMiBRequest & {
                                Min: NullablePositiveInteger;
                            };
                        };
                    })[];
                };
            };
        };
    })[];
    NextToken?: string;
}
export declare const DescribeInstanceRefreshesAnswer: S.Schema<DescribeInstanceRefreshesAnswer>;
export type LaunchConfigurationNames = string[];
export declare const LaunchConfigurationNames: any;
export interface LaunchConfigurationNamesType {
    LaunchConfigurationNames?: string[];
    NextToken?: string;
    MaxRecords?: number;
}
export declare const LaunchConfigurationNamesType: S.Schema<LaunchConfigurationNamesType>;
export interface LaunchConfiguration {
    LaunchConfigurationName?: string;
    LaunchConfigurationARN?: string;
    ImageId?: string;
    KeyName?: string;
    SecurityGroups?: string[];
    ClassicLinkVPCId?: string;
    ClassicLinkVPCSecurityGroups?: string[];
    UserData?: string;
    InstanceType?: string;
    KernelId?: string;
    RamdiskId?: string;
    BlockDeviceMappings?: BlockDeviceMapping[];
    InstanceMonitoring?: InstanceMonitoring;
    SpotPrice?: string;
    IamInstanceProfile?: string;
    CreatedTime?: Date;
    EbsOptimized?: boolean;
    AssociatePublicIpAddress?: boolean;
    PlacementTenancy?: string;
    MetadataOptions?: InstanceMetadataOptions;
}
export declare const LaunchConfiguration: S.Schema<LaunchConfiguration>;
export type LaunchConfigurations = LaunchConfiguration[];
export declare const LaunchConfigurations: any;
export interface LaunchConfigurationsType {
    LaunchConfigurations: (LaunchConfiguration & {
        LaunchConfigurationName: XmlStringMaxLen255;
        ImageId: XmlStringMaxLen255;
        InstanceType: XmlStringMaxLen255;
        CreatedTime: Date;
        BlockDeviceMappings: (BlockDeviceMapping & {
            DeviceName: XmlStringMaxLen255;
        })[];
    })[];
    NextToken?: string;
}
export declare const LaunchConfigurationsType: S.Schema<LaunchConfigurationsType>;
export type LifecycleHookNames = string[];
export declare const LifecycleHookNames: any;
export interface DescribeLifecycleHooksType {
    AutoScalingGroupName?: string;
    LifecycleHookNames?: string[];
}
export declare const DescribeLifecycleHooksType: S.Schema<DescribeLifecycleHooksType>;
export type GlobalTimeout = number;
export interface LifecycleHook {
    LifecycleHookName?: string;
    AutoScalingGroupName?: string;
    LifecycleTransition?: string;
    NotificationTargetARN?: string;
    RoleARN?: string;
    NotificationMetadata?: string;
    HeartbeatTimeout?: number;
    GlobalTimeout?: number;
    DefaultResult?: string;
}
export declare const LifecycleHook: S.Schema<LifecycleHook>;
export type LifecycleHooks = LifecycleHook[];
export declare const LifecycleHooks: any;
export interface DescribeLifecycleHooksAnswer {
    LifecycleHooks?: LifecycleHook[];
}
export declare const DescribeLifecycleHooksAnswer: S.Schema<DescribeLifecycleHooksAnswer>;
export interface DescribeLifecycleHookTypesRequest {
}
export declare const DescribeLifecycleHookTypesRequest: S.Schema<DescribeLifecycleHookTypesRequest>;
export interface DescribeLifecycleHookTypesAnswer {
    LifecycleHookTypes?: string[];
}
export declare const DescribeLifecycleHookTypesAnswer: S.Schema<DescribeLifecycleHookTypesAnswer>;
export interface DescribeLoadBalancersRequest {
    AutoScalingGroupName?: string;
    NextToken?: string;
    MaxRecords?: number;
}
export declare const DescribeLoadBalancersRequest: S.Schema<DescribeLoadBalancersRequest>;
export interface LoadBalancerState {
    LoadBalancerName?: string;
    State?: string;
}
export declare const LoadBalancerState: S.Schema<LoadBalancerState>;
export type LoadBalancerStates = LoadBalancerState[];
export declare const LoadBalancerStates: any;
export interface DescribeLoadBalancersResponse {
    LoadBalancers?: LoadBalancerState[];
    NextToken?: string;
}
export declare const DescribeLoadBalancersResponse: S.Schema<DescribeLoadBalancersResponse>;
export interface DescribeLoadBalancerTargetGroupsRequest {
    AutoScalingGroupName?: string;
    NextToken?: string;
    MaxRecords?: number;
}
export declare const DescribeLoadBalancerTargetGroupsRequest: S.Schema<DescribeLoadBalancerTargetGroupsRequest>;
export interface LoadBalancerTargetGroupState {
    LoadBalancerTargetGroupARN?: string;
    State?: string;
}
export declare const LoadBalancerTargetGroupState: S.Schema<LoadBalancerTargetGroupState>;
export type LoadBalancerTargetGroupStates = LoadBalancerTargetGroupState[];
export declare const LoadBalancerTargetGroupStates: any;
export interface DescribeLoadBalancerTargetGroupsResponse {
    LoadBalancerTargetGroups?: LoadBalancerTargetGroupState[];
    NextToken?: string;
}
export declare const DescribeLoadBalancerTargetGroupsResponse: S.Schema<DescribeLoadBalancerTargetGroupsResponse>;
export interface DescribeMetricCollectionTypesRequest {
}
export declare const DescribeMetricCollectionTypesRequest: S.Schema<DescribeMetricCollectionTypesRequest>;
export interface MetricCollectionType {
    Metric?: string;
}
export declare const MetricCollectionType: S.Schema<MetricCollectionType>;
export type MetricCollectionTypes = MetricCollectionType[];
export declare const MetricCollectionTypes: any;
export interface MetricGranularityType {
    Granularity?: string;
}
export declare const MetricGranularityType: S.Schema<MetricGranularityType>;
export type MetricGranularityTypes = MetricGranularityType[];
export declare const MetricGranularityTypes: any;
export interface DescribeMetricCollectionTypesAnswer {
    Metrics?: MetricCollectionType[];
    Granularities?: MetricGranularityType[];
}
export declare const DescribeMetricCollectionTypesAnswer: S.Schema<DescribeMetricCollectionTypesAnswer>;
export interface DescribeNotificationConfigurationsType {
    AutoScalingGroupNames?: string[];
    NextToken?: string;
    MaxRecords?: number;
}
export declare const DescribeNotificationConfigurationsType: S.Schema<DescribeNotificationConfigurationsType>;
export interface NotificationConfiguration {
    AutoScalingGroupName?: string;
    TopicARN?: string;
    NotificationType?: string;
}
export declare const NotificationConfiguration: S.Schema<NotificationConfiguration>;
export type NotificationConfigurations = NotificationConfiguration[];
export declare const NotificationConfigurations: any;
export interface DescribeNotificationConfigurationsAnswer {
    NotificationConfigurations: NotificationConfiguration[];
    NextToken?: string;
}
export declare const DescribeNotificationConfigurationsAnswer: S.Schema<DescribeNotificationConfigurationsAnswer>;
export type PolicyNames = string[];
export declare const PolicyNames: any;
export type PolicyTypes = string[];
export declare const PolicyTypes: any;
export interface DescribePoliciesType {
    AutoScalingGroupName?: string;
    PolicyNames?: string[];
    PolicyTypes?: string[];
    NextToken?: string;
    MaxRecords?: number;
}
export declare const DescribePoliciesType: S.Schema<DescribePoliciesType>;
export type MinAdjustmentStep = number;
export type MinAdjustmentMagnitude = number;
export type PolicyIncrement = number;
export type MetricScale = number;
export interface StepAdjustment {
    MetricIntervalLowerBound?: number;
    MetricIntervalUpperBound?: number;
    ScalingAdjustment?: number;
}
export declare const StepAdjustment: S.Schema<StepAdjustment>;
export type StepAdjustments = StepAdjustment[];
export declare const StepAdjustments: any;
export type EstimatedInstanceWarmup = number;
export interface Alarm {
    AlarmName?: string;
    AlarmARN?: string;
}
export declare const Alarm: S.Schema<Alarm>;
export type Alarms = Alarm[];
export declare const Alarms: any;
export type MetricType = "ASGAverageCPUUtilization" | "ASGAverageNetworkIn" | "ASGAverageNetworkOut" | "ALBRequestCountPerTarget" | (string & {});
export declare const MetricType: any;
export interface PredefinedMetricSpecification {
    PredefinedMetricType?: MetricType;
    ResourceLabel?: string;
}
export declare const PredefinedMetricSpecification: S.Schema<PredefinedMetricSpecification>;
export type MetricName = string;
export type MetricNamespace = string;
export type MetricDimensionName = string;
export type MetricDimensionValue = string;
export interface MetricDimension {
    Name?: string;
    Value?: string;
}
export declare const MetricDimension: S.Schema<MetricDimension>;
export type MetricDimensions = MetricDimension[];
export declare const MetricDimensions: any;
export type MetricStatistic = "Average" | "Minimum" | "Maximum" | "SampleCount" | "Sum" | (string & {});
export declare const MetricStatistic: any;
export type MetricUnit = string;
export type MetricGranularityInSeconds = number;
export type XmlStringMaxLen2047 = string;
export interface Metric {
    Namespace?: string;
    MetricName?: string;
    Dimensions?: MetricDimension[];
}
export declare const Metric: S.Schema<Metric>;
export type XmlStringMetricStat = string;
export interface TargetTrackingMetricStat {
    Metric?: Metric;
    Stat?: string;
    Unit?: string;
    Period?: number;
}
export declare const TargetTrackingMetricStat: S.Schema<TargetTrackingMetricStat>;
export type XmlStringMetricLabel = string;
export type ReturnData = boolean;
export interface TargetTrackingMetricDataQuery {
    Id?: string;
    Expression?: string;
    MetricStat?: TargetTrackingMetricStat;
    Label?: string;
    Period?: number;
    ReturnData?: boolean;
}
export declare const TargetTrackingMetricDataQuery: S.Schema<TargetTrackingMetricDataQuery>;
export type TargetTrackingMetricDataQueries = TargetTrackingMetricDataQuery[];
export declare const TargetTrackingMetricDataQueries: any;
export interface CustomizedMetricSpecification {
    MetricName?: string;
    Namespace?: string;
    Dimensions?: MetricDimension[];
    Statistic?: MetricStatistic;
    Unit?: string;
    Period?: number;
    Metrics?: TargetTrackingMetricDataQuery[];
}
export declare const CustomizedMetricSpecification: S.Schema<CustomizedMetricSpecification>;
export type DisableScaleIn = boolean;
export interface TargetTrackingConfiguration {
    PredefinedMetricSpecification?: PredefinedMetricSpecification;
    CustomizedMetricSpecification?: CustomizedMetricSpecification;
    TargetValue?: number;
    DisableScaleIn?: boolean;
}
export declare const TargetTrackingConfiguration: S.Schema<TargetTrackingConfiguration>;
export type ScalingPolicyEnabled = boolean;
export type PredefinedMetricPairType = "ASGCPUUtilization" | "ASGNetworkIn" | "ASGNetworkOut" | "ALBRequestCount" | (string & {});
export declare const PredefinedMetricPairType: any;
export interface PredictiveScalingPredefinedMetricPair {
    PredefinedMetricType?: PredefinedMetricPairType;
    ResourceLabel?: string;
}
export declare const PredictiveScalingPredefinedMetricPair: S.Schema<PredictiveScalingPredefinedMetricPair>;
export type PredefinedScalingMetricType = "ASGAverageCPUUtilization" | "ASGAverageNetworkIn" | "ASGAverageNetworkOut" | "ALBRequestCountPerTarget" | (string & {});
export declare const PredefinedScalingMetricType: any;
export interface PredictiveScalingPredefinedScalingMetric {
    PredefinedMetricType?: PredefinedScalingMetricType;
    ResourceLabel?: string;
}
export declare const PredictiveScalingPredefinedScalingMetric: S.Schema<PredictiveScalingPredefinedScalingMetric>;
export type PredefinedLoadMetricType = "ASGTotalCPUUtilization" | "ASGTotalNetworkIn" | "ASGTotalNetworkOut" | "ALBTargetGroupRequestCount" | (string & {});
export declare const PredefinedLoadMetricType: any;
export interface PredictiveScalingPredefinedLoadMetric {
    PredefinedMetricType?: PredefinedLoadMetricType;
    ResourceLabel?: string;
}
export declare const PredictiveScalingPredefinedLoadMetric: S.Schema<PredictiveScalingPredefinedLoadMetric>;
export interface MetricStat {
    Metric?: Metric;
    Stat?: string;
    Unit?: string;
}
export declare const MetricStat: S.Schema<MetricStat>;
export interface MetricDataQuery {
    Id?: string;
    Expression?: string;
    MetricStat?: MetricStat;
    Label?: string;
    ReturnData?: boolean;
}
export declare const MetricDataQuery: S.Schema<MetricDataQuery>;
export type MetricDataQueries = MetricDataQuery[];
export declare const MetricDataQueries: any;
export interface PredictiveScalingCustomizedScalingMetric {
    MetricDataQueries?: MetricDataQuery[];
}
export declare const PredictiveScalingCustomizedScalingMetric: S.Schema<PredictiveScalingCustomizedScalingMetric>;
export interface PredictiveScalingCustomizedLoadMetric {
    MetricDataQueries?: MetricDataQuery[];
}
export declare const PredictiveScalingCustomizedLoadMetric: S.Schema<PredictiveScalingCustomizedLoadMetric>;
export interface PredictiveScalingCustomizedCapacityMetric {
    MetricDataQueries?: MetricDataQuery[];
}
export declare const PredictiveScalingCustomizedCapacityMetric: S.Schema<PredictiveScalingCustomizedCapacityMetric>;
export interface PredictiveScalingMetricSpecification {
    TargetValue?: number;
    PredefinedMetricPairSpecification?: PredictiveScalingPredefinedMetricPair;
    PredefinedScalingMetricSpecification?: PredictiveScalingPredefinedScalingMetric;
    PredefinedLoadMetricSpecification?: PredictiveScalingPredefinedLoadMetric;
    CustomizedScalingMetricSpecification?: PredictiveScalingCustomizedScalingMetric;
    CustomizedLoadMetricSpecification?: PredictiveScalingCustomizedLoadMetric;
    CustomizedCapacityMetricSpecification?: PredictiveScalingCustomizedCapacityMetric;
}
export declare const PredictiveScalingMetricSpecification: S.Schema<PredictiveScalingMetricSpecification>;
export type PredictiveScalingMetricSpecifications = PredictiveScalingMetricSpecification[];
export declare const PredictiveScalingMetricSpecifications: any;
export type PredictiveScalingMode = "ForecastAndScale" | "ForecastOnly" | (string & {});
export declare const PredictiveScalingMode: any;
export type PredictiveScalingSchedulingBufferTime = number;
export type PredictiveScalingMaxCapacityBreachBehavior = "HonorMaxCapacity" | "IncreaseMaxCapacity" | (string & {});
export declare const PredictiveScalingMaxCapacityBreachBehavior: any;
export type PredictiveScalingMaxCapacityBuffer = number;
export interface PredictiveScalingConfiguration {
    MetricSpecifications?: PredictiveScalingMetricSpecification[];
    Mode?: PredictiveScalingMode;
    SchedulingBufferTime?: number;
    MaxCapacityBreachBehavior?: PredictiveScalingMaxCapacityBreachBehavior;
    MaxCapacityBuffer?: number;
}
export declare const PredictiveScalingConfiguration: S.Schema<PredictiveScalingConfiguration>;
export interface ScalingPolicy {
    AutoScalingGroupName?: string;
    PolicyName?: string;
    PolicyARN?: string;
    PolicyType?: string;
    AdjustmentType?: string;
    MinAdjustmentStep?: number;
    MinAdjustmentMagnitude?: number;
    ScalingAdjustment?: number;
    Cooldown?: number;
    StepAdjustments?: StepAdjustment[];
    MetricAggregationType?: string;
    EstimatedInstanceWarmup?: number;
    Alarms?: Alarm[];
    TargetTrackingConfiguration?: TargetTrackingConfiguration;
    Enabled?: boolean;
    PredictiveScalingConfiguration?: PredictiveScalingConfiguration;
}
export declare const ScalingPolicy: S.Schema<ScalingPolicy>;
export type ScalingPolicies = ScalingPolicy[];
export declare const ScalingPolicies: any;
export interface PoliciesType {
    ScalingPolicies?: (ScalingPolicy & {
        StepAdjustments: (StepAdjustment & {
            ScalingAdjustment: PolicyIncrement;
        })[];
        TargetTrackingConfiguration: TargetTrackingConfiguration & {
            TargetValue: MetricScale;
            PredefinedMetricSpecification: PredefinedMetricSpecification & {
                PredefinedMetricType: MetricType;
            };
            CustomizedMetricSpecification: CustomizedMetricSpecification & {
                Dimensions: (MetricDimension & {
                    Name: MetricDimensionName;
                    Value: MetricDimensionValue;
                })[];
                Metrics: (TargetTrackingMetricDataQuery & {
                    Id: XmlStringMaxLen64;
                    MetricStat: TargetTrackingMetricStat & {
                        Metric: Metric & {
                            Namespace: MetricNamespace;
                            MetricName: MetricName;
                            Dimensions: (MetricDimension & {
                                Name: MetricDimensionName;
                                Value: MetricDimensionValue;
                            })[];
                        };
                        Stat: XmlStringMetricStat;
                    };
                })[];
            };
        };
        PredictiveScalingConfiguration: PredictiveScalingConfiguration & {
            MetricSpecifications: (PredictiveScalingMetricSpecification & {
                TargetValue: MetricScale;
                PredefinedMetricPairSpecification: PredictiveScalingPredefinedMetricPair & {
                    PredefinedMetricType: PredefinedMetricPairType;
                };
                PredefinedScalingMetricSpecification: PredictiveScalingPredefinedScalingMetric & {
                    PredefinedMetricType: PredefinedScalingMetricType;
                };
                PredefinedLoadMetricSpecification: PredictiveScalingPredefinedLoadMetric & {
                    PredefinedMetricType: PredefinedLoadMetricType;
                };
                CustomizedScalingMetricSpecification: PredictiveScalingCustomizedScalingMetric & {
                    MetricDataQueries: (MetricDataQuery & {
                        Id: XmlStringMaxLen255;
                        MetricStat: MetricStat & {
                            Metric: Metric & {
                                Namespace: MetricNamespace;
                                MetricName: MetricName;
                                Dimensions: (MetricDimension & {
                                    Name: MetricDimensionName;
                                    Value: MetricDimensionValue;
                                })[];
                            };
                            Stat: XmlStringMetricStat;
                        };
                    })[];
                };
                CustomizedLoadMetricSpecification: PredictiveScalingCustomizedLoadMetric & {
                    MetricDataQueries: (MetricDataQuery & {
                        Id: XmlStringMaxLen255;
                        MetricStat: MetricStat & {
                            Metric: Metric & {
                                Namespace: MetricNamespace;
                                MetricName: MetricName;
                                Dimensions: (MetricDimension & {
                                    Name: MetricDimensionName;
                                    Value: MetricDimensionValue;
                                })[];
                            };
                            Stat: XmlStringMetricStat;
                        };
                    })[];
                };
                CustomizedCapacityMetricSpecification: PredictiveScalingCustomizedCapacityMetric & {
                    MetricDataQueries: (MetricDataQuery & {
                        Id: XmlStringMaxLen255;
                        MetricStat: MetricStat & {
                            Metric: Metric & {
                                Namespace: MetricNamespace;
                                MetricName: MetricName;
                                Dimensions: (MetricDimension & {
                                    Name: MetricDimensionName;
                                    Value: MetricDimensionValue;
                                })[];
                            };
                            Stat: XmlStringMetricStat;
                        };
                    })[];
                };
            })[];
        };
    })[];
    NextToken?: string;
}
export declare const PoliciesType: S.Schema<PoliciesType>;
export type ActivityIds = string[];
export declare const ActivityIds: any;
export type IncludeDeletedGroups = boolean;
export interface DescribeScalingActivitiesType {
    ActivityIds?: string[];
    AutoScalingGroupName?: string;
    IncludeDeletedGroups?: boolean;
    MaxRecords?: number;
    NextToken?: string;
    Filters?: Filter[];
}
export declare const DescribeScalingActivitiesType: S.Schema<DescribeScalingActivitiesType>;
export type ScalingActivityStatusCode = "PendingSpotBidPlacement" | "WaitingForSpotInstanceRequestId" | "WaitingForSpotInstanceId" | "WaitingForInstanceId" | "PreInService" | "InProgress" | "WaitingForELBConnectionDraining" | "MidLifecycleAction" | "WaitingForInstanceWarmup" | "Successful" | "Failed" | "Cancelled" | "WaitingForConnectionDraining" | "WaitingForInPlaceUpdateToStart" | "WaitingForInPlaceUpdateToFinalize" | "InPlaceUpdateInProgress" | (string & {});
export declare const ScalingActivityStatusCode: any;
export type Progress = number;
export type AutoScalingGroupState = string;
export interface Activity {
    ActivityId?: string;
    AutoScalingGroupName?: string;
    Description?: string;
    Cause?: string;
    StartTime?: Date;
    EndTime?: Date;
    StatusCode?: ScalingActivityStatusCode;
    StatusMessage?: string;
    Progress?: number;
    Details?: string;
    AutoScalingGroupState?: string;
    AutoScalingGroupARN?: string;
}
export declare const Activity: S.Schema<Activity>;
export type Activities = Activity[];
export declare const Activities: any;
export interface ActivitiesType {
    Activities: (Activity & {
        ActivityId: XmlString;
        AutoScalingGroupName: XmlStringMaxLen255;
        Cause: XmlStringMaxLen1023;
        StartTime: Date;
        StatusCode: ScalingActivityStatusCode;
    })[];
    NextToken?: string;
}
export declare const ActivitiesType: S.Schema<ActivitiesType>;
export interface DescribeScalingProcessTypesRequest {
}
export declare const DescribeScalingProcessTypesRequest: S.Schema<DescribeScalingProcessTypesRequest>;
export interface ProcessType {
    ProcessName?: string;
}
export declare const ProcessType: S.Schema<ProcessType>;
export type Processes = ProcessType[];
export declare const Processes: any;
export interface ProcessesType {
    Processes?: (ProcessType & {
        ProcessName: XmlStringMaxLen255;
    })[];
}
export declare const ProcessesType: S.Schema<ProcessesType>;
export interface DescribeScheduledActionsType {
    AutoScalingGroupName?: string;
    ScheduledActionNames?: string[];
    StartTime?: Date;
    EndTime?: Date;
    NextToken?: string;
    MaxRecords?: number;
}
export declare const DescribeScheduledActionsType: S.Schema<DescribeScheduledActionsType>;
export interface ScheduledUpdateGroupAction {
    AutoScalingGroupName?: string;
    ScheduledActionName?: string;
    ScheduledActionARN?: string;
    Time?: Date;
    StartTime?: Date;
    EndTime?: Date;
    Recurrence?: string;
    MinSize?: number;
    MaxSize?: number;
    DesiredCapacity?: number;
    TimeZone?: string;
}
export declare const ScheduledUpdateGroupAction: S.Schema<ScheduledUpdateGroupAction>;
export type ScheduledUpdateGroupActions = ScheduledUpdateGroupAction[];
export declare const ScheduledUpdateGroupActions: any;
export interface ScheduledActionsType {
    ScheduledUpdateGroupActions?: ScheduledUpdateGroupAction[];
    NextToken?: string;
}
export declare const ScheduledActionsType: S.Schema<ScheduledActionsType>;
export interface DescribeTagsType {
    Filters?: Filter[];
    NextToken?: string;
    MaxRecords?: number;
}
export declare const DescribeTagsType: S.Schema<DescribeTagsType>;
export interface TagsType {
    Tags?: TagDescription[];
    NextToken?: string;
}
export declare const TagsType: S.Schema<TagsType>;
export interface DescribeTerminationPolicyTypesRequest {
}
export declare const DescribeTerminationPolicyTypesRequest: S.Schema<DescribeTerminationPolicyTypesRequest>;
export interface DescribeTerminationPolicyTypesAnswer {
    TerminationPolicyTypes?: string[];
}
export declare const DescribeTerminationPolicyTypesAnswer: S.Schema<DescribeTerminationPolicyTypesAnswer>;
export interface DescribeTrafficSourcesRequest {
    AutoScalingGroupName?: string;
    TrafficSourceType?: string;
    NextToken?: string;
    MaxRecords?: number;
}
export declare const DescribeTrafficSourcesRequest: S.Schema<DescribeTrafficSourcesRequest>;
export interface TrafficSourceState {
    TrafficSource?: string;
    State?: string;
    Identifier?: string;
    Type?: string;
}
export declare const TrafficSourceState: S.Schema<TrafficSourceState>;
export type TrafficSourceStates = TrafficSourceState[];
export declare const TrafficSourceStates: any;
export interface DescribeTrafficSourcesResponse {
    TrafficSources?: TrafficSourceState[];
    NextToken?: string;
}
export declare const DescribeTrafficSourcesResponse: S.Schema<DescribeTrafficSourcesResponse>;
export interface DescribeWarmPoolType {
    AutoScalingGroupName?: string;
    MaxRecords?: number;
    NextToken?: string;
}
export declare const DescribeWarmPoolType: S.Schema<DescribeWarmPoolType>;
export interface DescribeWarmPoolAnswer {
    WarmPoolConfiguration?: WarmPoolConfiguration;
    Instances?: (Instance & {
        InstanceId: XmlStringMaxLen19;
        AvailabilityZone: XmlStringMaxLen255;
        LifecycleState: LifecycleState;
        HealthStatus: XmlStringMaxLen32;
        ProtectedFromScaleIn: InstanceProtected;
    })[];
    NextToken?: string;
}
export declare const DescribeWarmPoolAnswer: S.Schema<DescribeWarmPoolAnswer>;
export type ShouldDecrementDesiredCapacity = boolean;
export interface DetachInstancesQuery {
    InstanceIds?: string[];
    AutoScalingGroupName?: string;
    ShouldDecrementDesiredCapacity?: boolean;
}
export declare const DetachInstancesQuery: S.Schema<DetachInstancesQuery>;
export interface DetachInstancesAnswer {
    Activities?: (Activity & {
        ActivityId: XmlString;
        AutoScalingGroupName: XmlStringMaxLen255;
        Cause: XmlStringMaxLen1023;
        StartTime: Date;
        StatusCode: ScalingActivityStatusCode;
    })[];
}
export declare const DetachInstancesAnswer: S.Schema<DetachInstancesAnswer>;
export interface DetachLoadBalancersType {
    AutoScalingGroupName?: string;
    LoadBalancerNames?: string[];
}
export declare const DetachLoadBalancersType: S.Schema<DetachLoadBalancersType>;
export interface DetachLoadBalancersResultType {
}
export declare const DetachLoadBalancersResultType: S.Schema<DetachLoadBalancersResultType>;
export interface DetachLoadBalancerTargetGroupsType {
    AutoScalingGroupName?: string;
    TargetGroupARNs?: string[];
}
export declare const DetachLoadBalancerTargetGroupsType: S.Schema<DetachLoadBalancerTargetGroupsType>;
export interface DetachLoadBalancerTargetGroupsResultType {
}
export declare const DetachLoadBalancerTargetGroupsResultType: S.Schema<DetachLoadBalancerTargetGroupsResultType>;
export interface DetachTrafficSourcesType {
    AutoScalingGroupName?: string;
    TrafficSources?: TrafficSourceIdentifier[];
}
export declare const DetachTrafficSourcesType: S.Schema<DetachTrafficSourcesType>;
export interface DetachTrafficSourcesResultType {
}
export declare const DetachTrafficSourcesResultType: S.Schema<DetachTrafficSourcesResultType>;
export type Metrics = string[];
export declare const Metrics: any;
export interface DisableMetricsCollectionQuery {
    AutoScalingGroupName?: string;
    Metrics?: string[];
}
export declare const DisableMetricsCollectionQuery: S.Schema<DisableMetricsCollectionQuery>;
export interface DisableMetricsCollectionResponse {
}
export declare const DisableMetricsCollectionResponse: S.Schema<DisableMetricsCollectionResponse>;
export interface EnableMetricsCollectionQuery {
    AutoScalingGroupName?: string;
    Metrics?: string[];
    Granularity?: string;
}
export declare const EnableMetricsCollectionQuery: S.Schema<EnableMetricsCollectionQuery>;
export interface EnableMetricsCollectionResponse {
}
export declare const EnableMetricsCollectionResponse: S.Schema<EnableMetricsCollectionResponse>;
export interface EnterStandbyQuery {
    InstanceIds?: string[];
    AutoScalingGroupName?: string;
    ShouldDecrementDesiredCapacity?: boolean;
}
export declare const EnterStandbyQuery: S.Schema<EnterStandbyQuery>;
export interface EnterStandbyAnswer {
    Activities?: (Activity & {
        ActivityId: XmlString;
        AutoScalingGroupName: XmlStringMaxLen255;
        Cause: XmlStringMaxLen1023;
        StartTime: Date;
        StatusCode: ScalingActivityStatusCode;
    })[];
}
export declare const EnterStandbyAnswer: S.Schema<EnterStandbyAnswer>;
export type HonorCooldown = boolean;
export interface ExecutePolicyType {
    AutoScalingGroupName?: string;
    PolicyName?: string;
    HonorCooldown?: boolean;
    MetricValue?: number;
    BreachThreshold?: number;
}
export declare const ExecutePolicyType: S.Schema<ExecutePolicyType>;
export interface ExecutePolicyResponse {
}
export declare const ExecutePolicyResponse: S.Schema<ExecutePolicyResponse>;
export interface ExitStandbyQuery {
    InstanceIds?: string[];
    AutoScalingGroupName?: string;
}
export declare const ExitStandbyQuery: S.Schema<ExitStandbyQuery>;
export interface ExitStandbyAnswer {
    Activities?: (Activity & {
        ActivityId: XmlString;
        AutoScalingGroupName: XmlStringMaxLen255;
        Cause: XmlStringMaxLen1023;
        StartTime: Date;
        StatusCode: ScalingActivityStatusCode;
    })[];
}
export declare const ExitStandbyAnswer: S.Schema<ExitStandbyAnswer>;
export interface GetPredictiveScalingForecastType {
    AutoScalingGroupName?: string;
    PolicyName?: string;
    StartTime?: Date;
    EndTime?: Date;
}
export declare const GetPredictiveScalingForecastType: S.Schema<GetPredictiveScalingForecastType>;
export type PredictiveScalingForecastTimestamps = Date[];
export declare const PredictiveScalingForecastTimestamps: any;
export type PredictiveScalingForecastValues = number[];
export declare const PredictiveScalingForecastValues: any;
export interface LoadForecast {
    Timestamps?: Date[];
    Values?: number[];
    MetricSpecification?: PredictiveScalingMetricSpecification;
}
export declare const LoadForecast: S.Schema<LoadForecast>;
export type LoadForecasts = LoadForecast[];
export declare const LoadForecasts: any;
export interface CapacityForecast {
    Timestamps?: Date[];
    Values?: number[];
}
export declare const CapacityForecast: S.Schema<CapacityForecast>;
export interface GetPredictiveScalingForecastAnswer {
    LoadForecast: (LoadForecast & {
        Timestamps: PredictiveScalingForecastTimestamps;
        Values: PredictiveScalingForecastValues;
        MetricSpecification: PredictiveScalingMetricSpecification & {
            TargetValue: MetricScale;
            PredefinedMetricPairSpecification: PredictiveScalingPredefinedMetricPair & {
                PredefinedMetricType: PredefinedMetricPairType;
            };
            PredefinedScalingMetricSpecification: PredictiveScalingPredefinedScalingMetric & {
                PredefinedMetricType: PredefinedScalingMetricType;
            };
            PredefinedLoadMetricSpecification: PredictiveScalingPredefinedLoadMetric & {
                PredefinedMetricType: PredefinedLoadMetricType;
            };
            CustomizedScalingMetricSpecification: PredictiveScalingCustomizedScalingMetric & {
                MetricDataQueries: (MetricDataQuery & {
                    Id: XmlStringMaxLen255;
                    MetricStat: MetricStat & {
                        Metric: Metric & {
                            Namespace: MetricNamespace;
                            MetricName: MetricName;
                            Dimensions: (MetricDimension & {
                                Name: MetricDimensionName;
                                Value: MetricDimensionValue;
                            })[];
                        };
                        Stat: XmlStringMetricStat;
                    };
                })[];
            };
            CustomizedLoadMetricSpecification: PredictiveScalingCustomizedLoadMetric & {
                MetricDataQueries: (MetricDataQuery & {
                    Id: XmlStringMaxLen255;
                    MetricStat: MetricStat & {
                        Metric: Metric & {
                            Namespace: MetricNamespace;
                            MetricName: MetricName;
                            Dimensions: (MetricDimension & {
                                Name: MetricDimensionName;
                                Value: MetricDimensionValue;
                            })[];
                        };
                        Stat: XmlStringMetricStat;
                    };
                })[];
            };
            CustomizedCapacityMetricSpecification: PredictiveScalingCustomizedCapacityMetric & {
                MetricDataQueries: (MetricDataQuery & {
                    Id: XmlStringMaxLen255;
                    MetricStat: MetricStat & {
                        Metric: Metric & {
                            Namespace: MetricNamespace;
                            MetricName: MetricName;
                            Dimensions: (MetricDimension & {
                                Name: MetricDimensionName;
                                Value: MetricDimensionValue;
                            })[];
                        };
                        Stat: XmlStringMetricStat;
                    };
                })[];
            };
        };
    })[];
    CapacityForecast: CapacityForecast & {
        Timestamps: PredictiveScalingForecastTimestamps;
        Values: PredictiveScalingForecastValues;
    };
    UpdateTime: Date;
}
export declare const GetPredictiveScalingForecastAnswer: S.Schema<GetPredictiveScalingForecastAnswer>;
export type RequestedCapacity = number;
export type ClientToken = string;
export type AvailabilityZonesLimit1 = string[];
export declare const AvailabilityZonesLimit1: any;
export type AvailabilityZoneIdsLimit1 = string[];
export declare const AvailabilityZoneIdsLimit1: any;
export type SubnetIdsLimit1 = string[];
export declare const SubnetIdsLimit1: any;
export type RetryStrategy = "retry-with-group-configuration" | "none" | (string & {});
export declare const RetryStrategy: any;
export interface LaunchInstancesRequest {
    AutoScalingGroupName?: string;
    RequestedCapacity?: number;
    ClientToken?: string;
    AvailabilityZones?: string[];
    AvailabilityZoneIds?: string[];
    SubnetIds?: string[];
    RetryStrategy?: RetryStrategy;
}
export declare const LaunchInstancesRequest: S.Schema<LaunchInstancesRequest>;
export interface InstanceCollection {
    InstanceType?: string;
    MarketType?: string;
    SubnetId?: string;
    AvailabilityZone?: string;
    AvailabilityZoneId?: string;
    InstanceIds?: string[];
}
export declare const InstanceCollection: S.Schema<InstanceCollection>;
export type InstanceCollections = InstanceCollection[];
export declare const InstanceCollections: any;
export interface LaunchInstancesError_ {
    InstanceType?: string;
    MarketType?: string;
    SubnetId?: string;
    AvailabilityZone?: string;
    AvailabilityZoneId?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const LaunchInstancesError_: S.Schema<LaunchInstancesError_>;
export type LaunchInstancesErrors = LaunchInstancesError_[];
export declare const LaunchInstancesErrors: any;
export interface LaunchInstancesResult {
    AutoScalingGroupName?: string;
    ClientToken?: string;
    Instances?: InstanceCollection[];
    Errors?: LaunchInstancesError_[];
}
export declare const LaunchInstancesResult: S.Schema<LaunchInstancesResult>;
export interface PutLifecycleHookType {
    LifecycleHookName?: string;
    AutoScalingGroupName?: string;
    LifecycleTransition?: string;
    RoleARN?: string;
    NotificationTargetARN?: string;
    NotificationMetadata?: string;
    HeartbeatTimeout?: number;
    DefaultResult?: string;
}
export declare const PutLifecycleHookType: S.Schema<PutLifecycleHookType>;
export interface PutLifecycleHookAnswer {
}
export declare const PutLifecycleHookAnswer: S.Schema<PutLifecycleHookAnswer>;
export interface PutNotificationConfigurationType {
    AutoScalingGroupName?: string;
    TopicARN?: string;
    NotificationTypes?: string[];
}
export declare const PutNotificationConfigurationType: S.Schema<PutNotificationConfigurationType>;
export interface PutNotificationConfigurationResponse {
}
export declare const PutNotificationConfigurationResponse: S.Schema<PutNotificationConfigurationResponse>;
export interface PutScalingPolicyType {
    AutoScalingGroupName?: string;
    PolicyName?: string;
    PolicyType?: string;
    AdjustmentType?: string;
    MinAdjustmentStep?: number;
    MinAdjustmentMagnitude?: number;
    ScalingAdjustment?: number;
    Cooldown?: number;
    MetricAggregationType?: string;
    StepAdjustments?: StepAdjustment[];
    EstimatedInstanceWarmup?: number;
    TargetTrackingConfiguration?: TargetTrackingConfiguration;
    Enabled?: boolean;
    PredictiveScalingConfiguration?: PredictiveScalingConfiguration;
}
export declare const PutScalingPolicyType: S.Schema<PutScalingPolicyType>;
export interface PolicyARNType {
    PolicyARN?: string;
    Alarms?: Alarm[];
}
export declare const PolicyARNType: S.Schema<PolicyARNType>;
export interface PutScheduledUpdateGroupActionType {
    AutoScalingGroupName?: string;
    ScheduledActionName?: string;
    Time?: Date;
    StartTime?: Date;
    EndTime?: Date;
    Recurrence?: string;
    MinSize?: number;
    MaxSize?: number;
    DesiredCapacity?: number;
    TimeZone?: string;
}
export declare const PutScheduledUpdateGroupActionType: S.Schema<PutScheduledUpdateGroupActionType>;
export interface PutScheduledUpdateGroupActionResponse {
}
export declare const PutScheduledUpdateGroupActionResponse: S.Schema<PutScheduledUpdateGroupActionResponse>;
export interface PutWarmPoolType {
    AutoScalingGroupName?: string;
    MaxGroupPreparedCapacity?: number;
    MinSize?: number;
    PoolState?: WarmPoolState;
    InstanceReusePolicy?: InstanceReusePolicy;
}
export declare const PutWarmPoolType: S.Schema<PutWarmPoolType>;
export interface PutWarmPoolAnswer {
}
export declare const PutWarmPoolAnswer: S.Schema<PutWarmPoolAnswer>;
export interface RecordLifecycleActionHeartbeatType {
    LifecycleHookName?: string;
    AutoScalingGroupName?: string;
    LifecycleActionToken?: string;
    InstanceId?: string;
}
export declare const RecordLifecycleActionHeartbeatType: S.Schema<RecordLifecycleActionHeartbeatType>;
export interface RecordLifecycleActionHeartbeatAnswer {
}
export declare const RecordLifecycleActionHeartbeatAnswer: S.Schema<RecordLifecycleActionHeartbeatAnswer>;
export type ProcessNames = string[];
export declare const ProcessNames: any;
export interface ScalingProcessQuery {
    AutoScalingGroupName?: string;
    ScalingProcesses?: string[];
}
export declare const ScalingProcessQuery: S.Schema<ScalingProcessQuery>;
export interface ResumeProcessesResponse {
}
export declare const ResumeProcessesResponse: S.Schema<ResumeProcessesResponse>;
export interface RollbackInstanceRefreshType {
    AutoScalingGroupName?: string;
}
export declare const RollbackInstanceRefreshType: S.Schema<RollbackInstanceRefreshType>;
export interface RollbackInstanceRefreshAnswer {
    InstanceRefreshId?: string;
}
export declare const RollbackInstanceRefreshAnswer: S.Schema<RollbackInstanceRefreshAnswer>;
export interface SetDesiredCapacityType {
    AutoScalingGroupName?: string;
    DesiredCapacity?: number;
    HonorCooldown?: boolean;
}
export declare const SetDesiredCapacityType: S.Schema<SetDesiredCapacityType>;
export interface SetDesiredCapacityResponse {
}
export declare const SetDesiredCapacityResponse: S.Schema<SetDesiredCapacityResponse>;
export type ShouldRespectGracePeriod = boolean;
export interface SetInstanceHealthQuery {
    InstanceId?: string;
    HealthStatus?: string;
    ShouldRespectGracePeriod?: boolean;
}
export declare const SetInstanceHealthQuery: S.Schema<SetInstanceHealthQuery>;
export interface SetInstanceHealthResponse {
}
export declare const SetInstanceHealthResponse: S.Schema<SetInstanceHealthResponse>;
export type ProtectedFromScaleIn = boolean;
export interface SetInstanceProtectionQuery {
    InstanceIds?: string[];
    AutoScalingGroupName?: string;
    ProtectedFromScaleIn?: boolean;
}
export declare const SetInstanceProtectionQuery: S.Schema<SetInstanceProtectionQuery>;
export interface SetInstanceProtectionAnswer {
}
export declare const SetInstanceProtectionAnswer: S.Schema<SetInstanceProtectionAnswer>;
export interface StartInstanceRefreshType {
    AutoScalingGroupName?: string;
    Strategy?: RefreshStrategy;
    DesiredConfiguration?: DesiredConfiguration;
    Preferences?: RefreshPreferences;
}
export declare const StartInstanceRefreshType: S.Schema<StartInstanceRefreshType>;
export interface StartInstanceRefreshAnswer {
    InstanceRefreshId?: string;
}
export declare const StartInstanceRefreshAnswer: S.Schema<StartInstanceRefreshAnswer>;
export interface SuspendProcessesResponse {
}
export declare const SuspendProcessesResponse: S.Schema<SuspendProcessesResponse>;
export type TerminationInstanceIds = string[];
export declare const TerminationInstanceIds: any;
export interface TerminateInstanceInAutoScalingGroupType {
    InstanceId?: string;
    InstanceIds?: string[];
    AutoScalingGroupName?: string;
    ShouldDecrementDesiredCapacity?: boolean;
}
export declare const TerminateInstanceInAutoScalingGroupType: S.Schema<TerminateInstanceInAutoScalingGroupType>;
export interface ActivityType {
    Activity?: Activity & {
        ActivityId: XmlString;
        AutoScalingGroupName: XmlStringMaxLen255;
        Cause: XmlStringMaxLen1023;
        StartTime: Date;
        StatusCode: ScalingActivityStatusCode;
    };
    Activities?: (Activity & {
        ActivityId: XmlString;
        AutoScalingGroupName: XmlStringMaxLen255;
        Cause: XmlStringMaxLen1023;
        StartTime: Date;
        StatusCode: ScalingActivityStatusCode;
    })[];
}
export declare const ActivityType: S.Schema<ActivityType>;
export type UpdatePlacementGroupParam = string;
export interface UpdateAutoScalingGroupType {
    AutoScalingGroupName?: string;
    LaunchConfigurationName?: string;
    LaunchTemplate?: LaunchTemplateSpecification;
    MixedInstancesPolicy?: MixedInstancesPolicy;
    MinSize?: number;
    MaxSize?: number;
    DesiredCapacity?: number;
    DefaultCooldown?: number;
    AvailabilityZones?: string[];
    AvailabilityZoneIds?: string[];
    HealthCheckType?: string;
    HealthCheckGracePeriod?: number;
    PlacementGroup?: string;
    VPCZoneIdentifier?: string;
    TerminationPolicies?: string[];
    NewInstancesProtectedFromScaleIn?: boolean;
    ServiceLinkedRoleARN?: string;
    MaxInstanceLifetime?: number;
    CapacityRebalance?: boolean;
    Context?: string;
    DesiredCapacityType?: string;
    DefaultInstanceWarmup?: number;
    InstanceMaintenancePolicy?: InstanceMaintenancePolicy;
    AvailabilityZoneDistribution?: AvailabilityZoneDistribution;
    AvailabilityZoneImpairmentPolicy?: AvailabilityZoneImpairmentPolicy;
    SkipZonalShiftValidation?: boolean;
    CapacityReservationSpecification?: CapacityReservationSpecification;
    InstanceLifecyclePolicy?: InstanceLifecyclePolicy;
    DeletionProtection?: DeletionProtection;
}
export declare const UpdateAutoScalingGroupType: S.Schema<UpdateAutoScalingGroupType>;
export interface UpdateAutoScalingGroupResponse {
}
export declare const UpdateAutoScalingGroupResponse: S.Schema<UpdateAutoScalingGroupResponse>;
export type AttachInstancesError = ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * Attaches one or more EC2 instances to the specified Auto Scaling group.
 *
 * When you attach instances, Amazon EC2 Auto Scaling increases the desired capacity of the group by the
 * number of instances being attached. If the number of instances being attached plus the
 * desired capacity of the group exceeds the maximum size of the group, the operation
 * fails.
 *
 * If there is a Classic Load Balancer attached to your Auto Scaling group, the instances are
 * also registered with the load balancer. If there are target groups attached to your Auto Scaling
 * group, the instances are also registered with the target groups.
 *
 * For more information, see Detach
 * or attach instances in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const attachInstances: API.OperationMethod<AttachInstancesQuery, AttachInstancesResponse, AttachInstancesError, Credentials | HttpClient.HttpClient>;
export type AttachLoadBalancersError = InstanceRefreshInProgressFault | ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * This API operation is superseded by AttachTrafficSources, which
 * can attach multiple traffic sources types. We recommend using
 * `AttachTrafficSources` to simplify how you manage traffic sources.
 * However, we continue to support `AttachLoadBalancers`. You can use both
 * the original `AttachLoadBalancers` API operation and
 * `AttachTrafficSources` on the same Auto Scaling group.
 *
 * Attaches one or more Classic Load Balancers to the specified Auto Scaling group. Amazon EC2 Auto Scaling registers the
 * running instances with these Classic Load Balancers.
 *
 * To describe the load balancers for an Auto Scaling group, call the DescribeLoadBalancers API.
 * To detach a load balancer from the Auto Scaling group, call the DetachLoadBalancers
 * API.
 *
 * This operation is additive and does not detach existing Classic Load Balancers or
 * target groups from the Auto Scaling group.
 *
 * For more information, see Use Elastic Load Balancing to
 * distribute traffic across the instances in your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const attachLoadBalancers: API.OperationMethod<AttachLoadBalancersType, AttachLoadBalancersResultType, AttachLoadBalancersError, Credentials | HttpClient.HttpClient>;
export type AttachLoadBalancerTargetGroupsError = InstanceRefreshInProgressFault | ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * This API operation is superseded by AttachTrafficSources, which
 * can attach multiple traffic sources types. We recommend using
 * `AttachTrafficSources` to simplify how you manage traffic sources.
 * However, we continue to support `AttachLoadBalancerTargetGroups`. You can
 * use both the original `AttachLoadBalancerTargetGroups` API operation and
 * `AttachTrafficSources` on the same Auto Scaling group.
 *
 * Attaches one or more target groups to the specified Auto Scaling group.
 *
 * This operation is used with the following load balancer types:
 *
 * - Application Load Balancer - Operates at the application layer (layer 7) and supports HTTP and
 * HTTPS.
 *
 * - Network Load Balancer - Operates at the transport layer (layer 4) and supports TCP, TLS, and
 * UDP.
 *
 * - Gateway Load Balancer - Operates at the network layer (layer 3).
 *
 * To describe the target groups for an Auto Scaling group, call the DescribeLoadBalancerTargetGroups
 * API. To detach the target group from
 * the Auto Scaling group, call the DetachLoadBalancerTargetGroups API.
 *
 * This operation is additive and does not detach existing target groups or Classic Load
 * Balancers from the Auto Scaling group.
 *
 * For more information, see Use Elastic Load Balancing to
 * distribute traffic across the instances in your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const attachLoadBalancerTargetGroups: API.OperationMethod<AttachLoadBalancerTargetGroupsType, AttachLoadBalancerTargetGroupsResultType, AttachLoadBalancerTargetGroupsError, Credentials | HttpClient.HttpClient>;
export type AttachTrafficSourcesError = InstanceRefreshInProgressFault | ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * Attaches one or more traffic sources to the specified Auto Scaling group.
 *
 * You can use any of the following as traffic sources for an Auto Scaling group:
 *
 * - Application Load Balancer
 *
 * - Classic Load Balancer
 *
 * - Gateway Load Balancer
 *
 * - Network Load Balancer
 *
 * - VPC Lattice
 *
 * This operation is additive and does not detach existing traffic sources from the Auto Scaling
 * group.
 *
 * After the operation completes, use the DescribeTrafficSources API to
 * return details about the state of the attachments between traffic sources and your Auto Scaling
 * group. To detach a traffic source from the Auto Scaling group, call the
 * DetachTrafficSources API.
 */
export declare const attachTrafficSources: API.OperationMethod<AttachTrafficSourcesType, AttachTrafficSourcesResultType, AttachTrafficSourcesError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteScheduledActionError = ResourceContentionFault | CommonErrors;
/**
 * Deletes one or more scheduled actions for the specified Auto Scaling group.
 */
export declare const batchDeleteScheduledAction: API.OperationMethod<BatchDeleteScheduledActionType, BatchDeleteScheduledActionAnswer, BatchDeleteScheduledActionError, Credentials | HttpClient.HttpClient>;
export type BatchPutScheduledUpdateGroupActionError = AlreadyExistsFault | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Creates or updates one or more scheduled scaling actions for an Auto Scaling group.
 */
export declare const batchPutScheduledUpdateGroupAction: API.OperationMethod<BatchPutScheduledUpdateGroupActionType, BatchPutScheduledUpdateGroupActionAnswer, BatchPutScheduledUpdateGroupActionError, Credentials | HttpClient.HttpClient>;
export type CancelInstanceRefreshError = ActiveInstanceRefreshNotFoundFault | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Cancels an instance refresh or rollback that is in progress. If an instance refresh or
 * rollback is not in progress, an `ActiveInstanceRefreshNotFound` error
 * occurs.
 *
 * This operation is part of the instance refresh
 * feature in Amazon EC2 Auto Scaling, which helps you update instances in your Auto Scaling group
 * after you make configuration changes.
 *
 * When you cancel an instance refresh, this does not roll back any changes that it made.
 * Use the RollbackInstanceRefresh API to roll back instead.
 */
export declare const cancelInstanceRefresh: API.OperationMethod<CancelInstanceRefreshType, CancelInstanceRefreshAnswer, CancelInstanceRefreshError, Credentials | HttpClient.HttpClient>;
export type CompleteLifecycleActionError = ResourceContentionFault | CommonErrors;
/**
 * Completes the lifecycle action for the specified token or instance with the specified
 * result.
 *
 * This step is a part of the procedure for adding a lifecycle hook to an Auto Scaling
 * group:
 *
 * - (Optional) Create a launch template or launch configuration with a user data
 * script that runs while an instance is in a wait state due to a lifecycle
 * hook.
 *
 * - (Optional) Create a Lambda function and a rule that allows Amazon EventBridge to invoke
 * your Lambda function when an instance is put into a wait state due to a
 * lifecycle hook.
 *
 * - (Optional) Create a notification target and an IAM role. The target can be
 * either an Amazon SQS queue or an Amazon SNS topic. The role allows Amazon EC2 Auto Scaling to publish
 * lifecycle notifications to the target.
 *
 * - Create the lifecycle hook. Specify whether the hook is used when the instances
 * launch or terminate.
 *
 * - If you need more time, record the lifecycle action heartbeat to keep the
 * instance in a wait state.
 *
 * - If you finish before the timeout period ends, send a
 * callback by using the CompleteLifecycleAction API
 * call.
 *
 * For more information, see Complete a lifecycle
 * action in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const completeLifecycleAction: API.OperationMethod<CompleteLifecycleActionType, CompleteLifecycleActionAnswer, CompleteLifecycleActionError, Credentials | HttpClient.HttpClient>;
export type CreateAutoScalingGroupError = AlreadyExistsFault | LimitExceededFault | ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * **We strongly recommend using a launch template when calling this operation to ensure full functionality for Amazon EC2 Auto Scaling and Amazon EC2.**
 *
 * Creates an Auto Scaling group with the specified name and attributes.
 *
 * If you exceed your maximum limit of Auto Scaling groups, the call fails. To query this limit,
 * call the DescribeAccountLimits API. For information about updating
 * this limit, see Quotas for
 * Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * If you're new to Amazon EC2 Auto Scaling, see the introductory tutorials in Get started
 * with Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * Every Auto Scaling group has three size properties (`DesiredCapacity`,
 * `MaxSize`, and `MinSize`). Usually, you set these sizes based
 * on a specific number of instances. However, if you configure a mixed instances policy
 * that defines weights for the instance types, you must specify these sizes with the same
 * units that you use for weighting instances.
 */
export declare const createAutoScalingGroup: API.OperationMethod<CreateAutoScalingGroupType, CreateAutoScalingGroupResponse, CreateAutoScalingGroupError, Credentials | HttpClient.HttpClient>;
export type CreateLaunchConfigurationError = AlreadyExistsFault | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Creates a launch configuration.
 *
 * If you exceed your maximum limit of launch configurations, the call fails. To query
 * this limit, call the DescribeAccountLimits API.
 * For information about updating this limit, see Quotas for
 * Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * For more information, see Launch
 * configurations in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * Amazon EC2 Auto Scaling configures instances launched as part of an Auto Scaling group using either a
 * launch template or a launch configuration. We strongly recommend that you do not use
 * launch configurations. They do not provide full functionality for Amazon EC2 Auto Scaling or Amazon EC2.
 * For information about using launch templates, see Launch templates in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const createLaunchConfiguration: API.OperationMethod<CreateLaunchConfigurationType, CreateLaunchConfigurationResponse, CreateLaunchConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateOrUpdateTagsError = AlreadyExistsFault | LimitExceededFault | ResourceContentionFault | ResourceInUseFault | CommonErrors;
/**
 * Creates or updates tags for the specified Auto Scaling group.
 *
 * When you specify a tag with a key that already exists, the operation overwrites the
 * previous tag definition, and you do not get an error message.
 *
 * For more information, see Tag Auto Scaling groups and
 * instances in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const createOrUpdateTags: API.OperationMethod<CreateOrUpdateTagsType, CreateOrUpdateTagsResponse, CreateOrUpdateTagsError, Credentials | HttpClient.HttpClient>;
export type DeleteAutoScalingGroupError = ResourceContentionFault | ResourceInUseFault | ScalingActivityInProgressFault | CommonErrors;
/**
 * Deletes the specified Auto Scaling group.
 *
 * If the group has instances or scaling activities in progress, you must specify the
 * option to force the deletion in order for it to succeed. The force delete operation will
 * also terminate the EC2 instances. If the group has a warm pool, the force delete option
 * also deletes the warm pool.
 *
 * To remove instances from the Auto Scaling group before deleting it, call the
 * DetachInstances API with the list of instances and the option to
 * decrement the desired capacity. This ensures that Amazon EC2 Auto Scaling does not launch replacement
 * instances.
 *
 * To terminate all instances before deleting the Auto Scaling group, call the
 * UpdateAutoScalingGroup API and set the minimum size and desired capacity
 * of the Auto Scaling group to
 * zero.
 *
 * If the group has scaling policies, deleting the group deletes the policies, the
 * underlying alarm actions, and any alarm that no longer has an associated action.
 *
 * For more information, see Delete your Auto Scaling
 * infrastructure in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const deleteAutoScalingGroup: API.OperationMethod<DeleteAutoScalingGroupType, DeleteAutoScalingGroupResponse, DeleteAutoScalingGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteLaunchConfigurationError = ResourceContentionFault | ResourceInUseFault | CommonErrors;
/**
 * Deletes the specified launch configuration.
 *
 * The launch configuration must not be attached to an Auto Scaling group. When this call
 * completes, the launch configuration is no longer available for use.
 */
export declare const deleteLaunchConfiguration: API.OperationMethod<LaunchConfigurationNameType, DeleteLaunchConfigurationResponse, DeleteLaunchConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteLifecycleHookError = ResourceContentionFault | AutoScalingGroupNotFound | CommonErrors;
/**
 * Deletes the specified lifecycle hook.
 *
 * If there are any outstanding lifecycle actions, they are completed first
 * (`ABANDON` for launching instances, `CONTINUE` for terminating
 * instances).
 */
export declare const deleteLifecycleHook: API.OperationMethod<DeleteLifecycleHookType, DeleteLifecycleHookAnswer, DeleteLifecycleHookError, Credentials | HttpClient.HttpClient>;
export type DeleteNotificationConfigurationError = ResourceContentionFault | CommonErrors;
/**
 * Deletes the specified notification.
 */
export declare const deleteNotificationConfiguration: API.OperationMethod<DeleteNotificationConfigurationType, DeleteNotificationConfigurationResponse, DeleteNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * Deletes the specified scaling policy.
 *
 * Deleting either a step scaling policy or a simple scaling policy deletes the
 * underlying alarm action, but does not delete the alarm, even if it no longer has an
 * associated action.
 *
 * For more information, see Delete a scaling
 * policy in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyType, DeletePolicyResponse, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduledActionError = ResourceContentionFault | AutoScalingGroupNotFound | CommonErrors;
/**
 * Deletes the specified scheduled action.
 */
export declare const deleteScheduledAction: API.OperationMethod<DeleteScheduledActionType, DeleteScheduledActionResponse, DeleteScheduledActionError, Credentials | HttpClient.HttpClient>;
export type DeleteTagsError = ResourceContentionFault | ResourceInUseFault | CommonErrors;
/**
 * Deletes the specified tags.
 */
export declare const deleteTags: API.OperationMethod<DeleteTagsType, DeleteTagsResponse, DeleteTagsError, Credentials | HttpClient.HttpClient>;
export type DeleteWarmPoolError = LimitExceededFault | ResourceContentionFault | ResourceInUseFault | ScalingActivityInProgressFault | CommonErrors;
/**
 * Deletes the warm pool for the specified Auto Scaling group.
 *
 * For more information, see Warm pools for
 * Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const deleteWarmPool: API.OperationMethod<DeleteWarmPoolType, DeleteWarmPoolAnswer, DeleteWarmPoolError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountLimitsError = ResourceContentionFault | CommonErrors;
/**
 * Describes the current Amazon EC2 Auto Scaling resource quotas for your account.
 *
 * When you establish an Amazon Web Services account, the account has initial quotas on the maximum
 * number of Auto Scaling groups and launch configurations that you can create in a given Region.
 * For more information, see Quotas for
 * Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const describeAccountLimits: API.OperationMethod<DescribeAccountLimitsRequest, DescribeAccountLimitsAnswer, DescribeAccountLimitsError, Credentials | HttpClient.HttpClient>;
export type DescribeAdjustmentTypesError = ResourceContentionFault | CommonErrors;
/**
 * Describes the available adjustment types for step scaling and simple scaling
 * policies.
 *
 * The following adjustment types are supported:
 *
 * - `ChangeInCapacity`
 *
 * - `ExactCapacity`
 *
 * - `PercentChangeInCapacity`
 */
export declare const describeAdjustmentTypes: API.OperationMethod<DescribeAdjustmentTypesRequest, DescribeAdjustmentTypesAnswer, DescribeAdjustmentTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeAutoScalingGroupsError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the Auto Scaling groups in the account and Region.
 *
 * If you specify Auto Scaling group names, the output includes information for only the
 * specified Auto Scaling groups. If you specify filters, the output includes information for only
 * those Auto Scaling groups that meet the filter criteria. If you do not specify group names or
 * filters, the output includes information for all Auto Scaling groups.
 *
 * This operation also returns information about instances in Auto Scaling groups. To retrieve
 * information about the instances in a warm pool, you must call the
 * DescribeWarmPool API.
 */
export declare const describeAutoScalingGroups: API.PaginatedOperationMethod<AutoScalingGroupNamesType, AutoScalingGroupsType, DescribeAutoScalingGroupsError, Credentials | HttpClient.HttpClient, AutoScalingGroup>;
export type DescribeAutoScalingInstancesError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the Auto Scaling instances in the account and Region.
 */
export declare const describeAutoScalingInstances: API.PaginatedOperationMethod<DescribeAutoScalingInstancesType, AutoScalingInstancesType, DescribeAutoScalingInstancesError, Credentials | HttpClient.HttpClient, AutoScalingInstanceDetails>;
export type DescribeAutoScalingNotificationTypesError = ResourceContentionFault | CommonErrors;
/**
 * Describes the notification types that are supported by Amazon EC2 Auto Scaling.
 */
export declare const describeAutoScalingNotificationTypes: API.OperationMethod<DescribeAutoScalingNotificationTypesRequest, DescribeAutoScalingNotificationTypesAnswer, DescribeAutoScalingNotificationTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeInstanceRefreshesError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the instance refreshes for the specified Auto Scaling group from the
 * previous six weeks.
 *
 * This operation is part of the instance refresh
 * feature in Amazon EC2 Auto Scaling, which helps you update instances in your Auto Scaling group
 * after you make configuration changes.
 *
 * To help you determine the status of an instance refresh, Amazon EC2 Auto Scaling returns information
 * about the instance refreshes you previously initiated, including their status, start
 * time, end time, the percentage of the instance refresh that is complete, and the number
 * of instances remaining to update before the instance refresh is complete. If a rollback
 * is initiated while an instance refresh is in progress, Amazon EC2 Auto Scaling also returns information
 * about the rollback of the instance refresh.
 */
export declare const describeInstanceRefreshes: API.PaginatedOperationMethod<DescribeInstanceRefreshesType, DescribeInstanceRefreshesAnswer, DescribeInstanceRefreshesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeLaunchConfigurationsError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the launch configurations in the account and Region.
 */
export declare const describeLaunchConfigurations: API.PaginatedOperationMethod<LaunchConfigurationNamesType, LaunchConfigurationsType, DescribeLaunchConfigurationsError, Credentials | HttpClient.HttpClient, LaunchConfiguration>;
export type DescribeLifecycleHooksError = ResourceContentionFault | AutoScalingGroupNotFound | CommonErrors;
/**
 * Gets information about the lifecycle hooks for the specified Auto Scaling group.
 */
export declare const describeLifecycleHooks: API.OperationMethod<DescribeLifecycleHooksType, DescribeLifecycleHooksAnswer, DescribeLifecycleHooksError, Credentials | HttpClient.HttpClient>;
export type DescribeLifecycleHookTypesError = ResourceContentionFault | CommonErrors;
/**
 * Describes the available types of lifecycle hooks.
 *
 * The following hook types are supported:
 *
 * - `autoscaling:EC2_INSTANCE_LAUNCHING`
 *
 * - `autoscaling:EC2_INSTANCE_TERMINATING`
 */
export declare const describeLifecycleHookTypes: API.OperationMethod<DescribeLifecycleHookTypesRequest, DescribeLifecycleHookTypesAnswer, DescribeLifecycleHookTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeLoadBalancersError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * This API operation is superseded by DescribeTrafficSources,
 * which can describe multiple traffic sources types. We recommend using
 * `DescribeTrafficSources` to simplify how you manage traffic sources.
 * However, we continue to support `DescribeLoadBalancers`. You can use both
 * the original `DescribeLoadBalancers` API operation and
 * `DescribeTrafficSources` on the same Auto Scaling group.
 *
 * Gets information about the load balancers for the specified Auto Scaling group.
 *
 * This operation describes only Classic Load Balancers. If you have Application Load Balancers, Network Load Balancers, or Gateway Load Balancers, use the
 * DescribeLoadBalancerTargetGroups API instead.
 *
 * To determine the attachment status of the load balancer, use the `State`
 * element in the response. When you attach a load balancer to an Auto Scaling group, the initial
 * `State` value is `Adding`. The state transitions to
 * `Added` after all Auto Scaling instances are registered with the load balancer.
 * If Elastic Load Balancing health checks are enabled for the Auto Scaling group, the state transitions to
 * `InService` after at least one Auto Scaling instance passes the health check.
 * When the load balancer is in the `InService` state, Amazon EC2 Auto Scaling can terminate
 * and replace any instances that are reported as unhealthy. If no registered instances
 * pass the health checks, the load balancer doesn't enter the `InService`
 * state.
 *
 * Load balancers also have an `InService` state if you attach them in the
 * CreateAutoScalingGroup API call. If your load balancer state is
 * `InService`, but it is not working properly, check the scaling activities
 * by calling DescribeScalingActivities and take any corrective actions
 * necessary.
 *
 * For help with failed health checks, see Troubleshooting Amazon EC2 Auto Scaling:
 * Health checks in the *Amazon EC2 Auto Scaling User Guide*. For more
 * information, see Use Elastic Load Balancing to
 * distribute traffic across the instances in your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const describeLoadBalancers: API.PaginatedOperationMethod<DescribeLoadBalancersRequest, DescribeLoadBalancersResponse, DescribeLoadBalancersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeLoadBalancerTargetGroupsError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * This API operation is superseded by DescribeTrafficSources,
 * which can describe multiple traffic sources types. We recommend using
 * `DetachTrafficSources` to simplify how you manage traffic sources.
 * However, we continue to support `DescribeLoadBalancerTargetGroups`. You
 * can use both the original `DescribeLoadBalancerTargetGroups` API
 * operation and `DescribeTrafficSources` on the same Auto Scaling group.
 *
 * Gets information about the Elastic Load Balancing target groups for the specified Auto Scaling group.
 *
 * To determine the attachment status of the target group, use the `State`
 * element in the response. When you attach a target group to an Auto Scaling group, the initial
 * `State` value is `Adding`. The state transitions to
 * `Added` after all Auto Scaling instances are registered with the target group. If
 * Elastic Load Balancing health checks are enabled for the Auto Scaling group, the state transitions to
 * `InService` after at least one Auto Scaling instance passes the health check.
 * When the target group is in the `InService` state, Amazon EC2 Auto Scaling can terminate and
 * replace any instances that are reported as unhealthy. If no registered instances pass
 * the health checks, the target group doesn't enter the `InService` state.
 *
 * Target groups also have an `InService` state if you attach them in the
 * CreateAutoScalingGroup API call. If your target group state is
 * `InService`, but it is not working properly, check the scaling activities
 * by calling DescribeScalingActivities and take any corrective actions
 * necessary.
 *
 * For help with failed health checks, see Troubleshooting Amazon EC2 Auto Scaling:
 * Health checks in the *Amazon EC2 Auto Scaling User Guide*. For more
 * information, see Use Elastic Load Balancing to
 * distribute traffic across the instances in your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 *
 * You can use this operation to describe target groups that were attached by using
 * AttachLoadBalancerTargetGroups, but not for target groups that
 * were attached by using AttachTrafficSources.
 */
export declare const describeLoadBalancerTargetGroups: API.PaginatedOperationMethod<DescribeLoadBalancerTargetGroupsRequest, DescribeLoadBalancerTargetGroupsResponse, DescribeLoadBalancerTargetGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMetricCollectionTypesError = ResourceContentionFault | CommonErrors;
/**
 * Describes the available CloudWatch metrics for Amazon EC2 Auto Scaling.
 */
export declare const describeMetricCollectionTypes: API.OperationMethod<DescribeMetricCollectionTypesRequest, DescribeMetricCollectionTypesAnswer, DescribeMetricCollectionTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeNotificationConfigurationsError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the Amazon SNS notifications that are configured for one or more
 * Auto Scaling groups.
 */
export declare const describeNotificationConfigurations: API.PaginatedOperationMethod<DescribeNotificationConfigurationsType, DescribeNotificationConfigurationsAnswer, DescribeNotificationConfigurationsError, Credentials | HttpClient.HttpClient, NotificationConfiguration>;
export type DescribePoliciesError = InvalidNextToken | ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * Gets information about the scaling policies in the account and Region.
 */
export declare const describePolicies: API.PaginatedOperationMethod<DescribePoliciesType, PoliciesType, DescribePoliciesError, Credentials | HttpClient.HttpClient, ScalingPolicy>;
export type DescribeScalingActivitiesError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the scaling activities in the account and Region.
 *
 * When scaling events occur, you see a record of the scaling activity in the scaling
 * activities. For more information, see Verify a scaling
 * activity for an Auto Scaling group in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * If the scaling event succeeds, the value of the `StatusCode` element in the
 * response is `Successful`. If an attempt to launch instances failed, the
 * `StatusCode` value is `Failed` or `Cancelled` and
 * the `StatusMessage` element in the response indicates the cause of the
 * failure. For help interpreting the `StatusMessage`, see Troubleshooting Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const describeScalingActivities: API.PaginatedOperationMethod<DescribeScalingActivitiesType, ActivitiesType, DescribeScalingActivitiesError, Credentials | HttpClient.HttpClient, Activity>;
export type DescribeScalingProcessTypesError = ResourceContentionFault | CommonErrors;
/**
 * Describes the scaling process types for use with the ResumeProcesses
 * and SuspendProcesses APIs.
 */
export declare const describeScalingProcessTypes: API.OperationMethod<DescribeScalingProcessTypesRequest, ProcessesType, DescribeScalingProcessTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeScheduledActionsError = InvalidNextToken | ResourceContentionFault | AutoScalingGroupNotFound | CommonErrors;
/**
 * Gets information about the scheduled actions that haven't run or that have not reached
 * their end time.
 *
 * To describe the scaling activities for scheduled actions that have already run, call
 * the DescribeScalingActivities API.
 */
export declare const describeScheduledActions: API.PaginatedOperationMethod<DescribeScheduledActionsType, ScheduledActionsType, DescribeScheduledActionsError, Credentials | HttpClient.HttpClient, ScheduledUpdateGroupAction>;
export type DescribeTagsError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Describes the specified tags.
 *
 * You can use filters to limit the results. For example, you can query for the tags for
 * a specific Auto Scaling group. You can specify multiple values for a filter. A tag must match at
 * least one of the specified values for it to be included in the results.
 *
 * You can also specify multiple filters. The result includes information for a
 * particular tag only if it matches all the filters. If there's no match, no special
 * message is returned.
 *
 * For more information, see Tag Auto Scaling groups and
 * instances in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const describeTags: API.PaginatedOperationMethod<DescribeTagsType, TagsType, DescribeTagsError, Credentials | HttpClient.HttpClient, TagDescription>;
export type DescribeTerminationPolicyTypesError = ResourceContentionFault | CommonErrors;
/**
 * Describes the termination policies supported by Amazon EC2 Auto Scaling.
 *
 * For more information, see Configure
 * termination policies for Amazon EC2 Auto Scaling in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const describeTerminationPolicyTypes: API.OperationMethod<DescribeTerminationPolicyTypesRequest, DescribeTerminationPolicyTypesAnswer, DescribeTerminationPolicyTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeTrafficSourcesError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the traffic sources for the specified Auto Scaling group.
 *
 * You can optionally provide a traffic source type. If you provide a traffic source
 * type, then the results only include that traffic source type.
 *
 * If you do not provide a traffic source type, then the results include all the traffic
 * sources for the specified Auto Scaling group.
 */
export declare const describeTrafficSources: API.PaginatedOperationMethod<DescribeTrafficSourcesRequest, DescribeTrafficSourcesResponse, DescribeTrafficSourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeWarmPoolError = InvalidNextToken | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Gets information about a warm pool and its instances.
 *
 * For more information, see Warm pools for
 * Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const describeWarmPool: API.PaginatedOperationMethod<DescribeWarmPoolType, DescribeWarmPoolAnswer, DescribeWarmPoolError, Credentials | HttpClient.HttpClient, Instance>;
export type DetachInstancesError = ResourceContentionFault | CommonErrors;
/**
 * Removes one or more instances from the specified Auto Scaling group.
 *
 * After the instances are detached, you can manage them independent of the Auto Scaling
 * group.
 *
 * If you do not specify the option to decrement the desired capacity, Amazon EC2 Auto Scaling launches
 * instances to replace the ones that are detached.
 *
 * If there is a Classic Load Balancer attached to the Auto Scaling group, the instances are
 * deregistered from the load balancer. If there are target groups attached to the Auto Scaling
 * group, the instances are deregistered from the target groups.
 *
 * For more information, see Detach
 * or attach instances in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const detachInstances: API.OperationMethod<DetachInstancesQuery, DetachInstancesAnswer, DetachInstancesError, Credentials | HttpClient.HttpClient>;
export type DetachLoadBalancersError = ResourceContentionFault | CommonErrors;
/**
 * This API operation is superseded by DetachTrafficSources, which
 * can detach multiple traffic sources types. We recommend using
 * `DetachTrafficSources` to simplify how you manage traffic sources.
 * However, we continue to support `DetachLoadBalancers`. You can use both
 * the original `DetachLoadBalancers` API operation and
 * `DetachTrafficSources` on the same Auto Scaling group.
 *
 * Detaches one or more Classic Load Balancers from the specified Auto Scaling group.
 *
 * This operation detaches only Classic Load Balancers. If you have Application Load Balancers, Network Load Balancers, or
 * Gateway Load Balancers, use the DetachLoadBalancerTargetGroups API instead.
 *
 * When you detach a load balancer, it enters the `Removing` state while
 * deregistering the instances in the group. When all instances are deregistered, then you
 * can no longer describe the load balancer using the DescribeLoadBalancers
 * API call. The instances remain running.
 */
export declare const detachLoadBalancers: API.OperationMethod<DetachLoadBalancersType, DetachLoadBalancersResultType, DetachLoadBalancersError, Credentials | HttpClient.HttpClient>;
export type DetachLoadBalancerTargetGroupsError = ResourceContentionFault | CommonErrors;
/**
 * This API operation is superseded by DetachTrafficSources, which
 * can detach multiple traffic sources types. We recommend using
 * `DetachTrafficSources` to simplify how you manage traffic sources.
 * However, we continue to support `DetachLoadBalancerTargetGroups`. You can
 * use both the original `DetachLoadBalancerTargetGroups` API operation and
 * `DetachTrafficSources` on the same Auto Scaling group.
 *
 * Detaches one or more target groups from the specified Auto Scaling group.
 *
 * When you detach a target group, it enters the `Removing` state while
 * deregistering the instances in the group. When all instances are deregistered, then you
 * can no longer describe the target group using the
 * DescribeLoadBalancerTargetGroups
 * API call. The instances remain running.
 *
 * You can use this operation to detach target groups that were attached by using
 * AttachLoadBalancerTargetGroups, but not for target groups that
 * were attached by using AttachTrafficSources.
 */
export declare const detachLoadBalancerTargetGroups: API.OperationMethod<DetachLoadBalancerTargetGroupsType, DetachLoadBalancerTargetGroupsResultType, DetachLoadBalancerTargetGroupsError, Credentials | HttpClient.HttpClient>;
export type DetachTrafficSourcesError = ResourceContentionFault | CommonErrors;
/**
 * Detaches one or more traffic sources from the specified Auto Scaling group.
 *
 * When you detach a traffic source, it enters the `Removing` state while
 * deregistering the instances in the group. When all instances are deregistered, then you
 * can no longer describe the traffic source using the
 * DescribeTrafficSources
 * API call. The instances continue to run.
 */
export declare const detachTrafficSources: API.OperationMethod<DetachTrafficSourcesType, DetachTrafficSourcesResultType, DetachTrafficSourcesError, Credentials | HttpClient.HttpClient>;
export type DisableMetricsCollectionError = ResourceContentionFault | CommonErrors;
/**
 * Disables group metrics collection for the specified Auto Scaling group.
 */
export declare const disableMetricsCollection: API.OperationMethod<DisableMetricsCollectionQuery, DisableMetricsCollectionResponse, DisableMetricsCollectionError, Credentials | HttpClient.HttpClient>;
export type EnableMetricsCollectionError = ResourceContentionFault | CommonErrors;
/**
 * Enables group metrics collection for the specified Auto Scaling group.
 *
 * You can use these metrics to track changes in an Auto Scaling group and to set alarms on
 * threshold values. You can view group metrics using the Amazon EC2 Auto Scaling console or the CloudWatch
 * console. For more information, see Monitor
 * CloudWatch metrics for your Auto Scaling groups and instances in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const enableMetricsCollection: API.OperationMethod<EnableMetricsCollectionQuery, EnableMetricsCollectionResponse, EnableMetricsCollectionError, Credentials | HttpClient.HttpClient>;
export type EnterStandbyError = ResourceContentionFault | CommonErrors;
/**
 * Moves the specified instances into the standby state.
 *
 * If you choose to decrement the desired capacity of the Auto Scaling group, the instances can
 * enter standby as long as the desired capacity of the Auto Scaling group after the instances are
 * placed into standby is equal to or greater than the minimum capacity of the
 * group.
 *
 * If you choose not to decrement the desired capacity of the Auto Scaling group, the Auto Scaling group
 * launches new instances to replace the instances on standby.
 *
 * For more information, see Temporarily removing
 * instances from your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const enterStandby: API.OperationMethod<EnterStandbyQuery, EnterStandbyAnswer, EnterStandbyError, Credentials | HttpClient.HttpClient>;
export type ExecutePolicyError = ResourceContentionFault | ScalingActivityInProgressFault | CommonErrors;
/**
 * Executes the specified policy. This can be useful for testing the design of your
 * scaling policy.
 */
export declare const executePolicy: API.OperationMethod<ExecutePolicyType, ExecutePolicyResponse, ExecutePolicyError, Credentials | HttpClient.HttpClient>;
export type ExitStandbyError = ResourceContentionFault | CommonErrors;
/**
 * Moves the specified instances out of the standby state.
 *
 * After you put the instances back in service, the desired capacity is
 * incremented.
 *
 * For more information, see Temporarily removing
 * instances from your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const exitStandby: API.OperationMethod<ExitStandbyQuery, ExitStandbyAnswer, ExitStandbyError, Credentials | HttpClient.HttpClient>;
export type GetPredictiveScalingForecastError = ResourceContentionFault | CommonErrors;
/**
 * Retrieves the forecast data for a predictive scaling policy.
 *
 * Load forecasts are predictions of the hourly load values using historical load data
 * from CloudWatch and an analysis of historical trends. Capacity forecasts are represented as
 * predicted values for the minimum capacity that is needed on an hourly basis, based on
 * the hourly load forecast.
 *
 * A minimum of 24 hours of data is required to create the initial forecasts. However,
 * having a full 14 days of historical data results in more accurate forecasts.
 *
 * For more information, see Predictive
 * scaling for Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const getPredictiveScalingForecast: API.OperationMethod<GetPredictiveScalingForecastType, GetPredictiveScalingForecastAnswer, GetPredictiveScalingForecastError, Credentials | HttpClient.HttpClient>;
export type LaunchInstancesError = IdempotentCallInProgressFault | IdempotentParameterMismatchError | ResourceContentionFault | CommonErrors;
/**
 * Launches a specified number of instances in an Auto Scaling group. Returns instance IDs and
 * other details if launch is successful or error details if launch is unsuccessful.
 */
export declare const launchInstances: API.OperationMethod<LaunchInstancesRequest, LaunchInstancesResult, LaunchInstancesError, Credentials | HttpClient.HttpClient>;
export type PutLifecycleHookError = LimitExceededFault | ResourceContentionFault | AutoScalingGroupNotFound | CommonErrors;
/**
 * Creates or updates a lifecycle hook for the specified Auto Scaling group.
 *
 * Lifecycle hooks let you create solutions that are aware of events in the Auto Scaling instance
 * lifecycle, and then perform a custom action on instances when the corresponding
 * lifecycle event occurs.
 *
 * This step is a part of the procedure for adding a lifecycle hook to an Auto Scaling
 * group:
 *
 * - (Optional) Create a launch template or launch configuration with a user data
 * script that runs while an instance is in a wait state due to a lifecycle
 * hook.
 *
 * - (Optional) Create a Lambda function and a rule that allows Amazon EventBridge to invoke
 * your Lambda function when an instance is put into a wait state due to a
 * lifecycle hook.
 *
 * - (Optional) Create a notification target and an IAM role. The target can be
 * either an Amazon SQS queue or an Amazon SNS topic. The role allows Amazon EC2 Auto Scaling to publish
 * lifecycle notifications to the target.
 *
 * - Create the lifecycle hook. Specify whether the hook is
 * used when the instances launch or terminate.
 *
 * - If you need more time, record the lifecycle action heartbeat to keep the
 * instance in a wait state using the RecordLifecycleActionHeartbeat API call.
 *
 * - If you finish before the timeout period ends, send a callback by using the
 * CompleteLifecycleAction API call.
 *
 * For more information, see Amazon EC2 Auto Scaling lifecycle
 * hooks in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * If you exceed your maximum limit of lifecycle hooks, which by default is 50 per Auto Scaling
 * group, the call fails.
 *
 * You can view the lifecycle hooks for an Auto Scaling group using the
 * DescribeLifecycleHooks API call. If you are no longer using a lifecycle
 * hook, you can delete it by calling the DeleteLifecycleHook API.
 */
export declare const putLifecycleHook: API.OperationMethod<PutLifecycleHookType, PutLifecycleHookAnswer, PutLifecycleHookError, Credentials | HttpClient.HttpClient>;
export type PutNotificationConfigurationError = LimitExceededFault | ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * Configures an Auto Scaling group to send notifications when specified events take place.
 * Subscribers to the specified topic can have messages delivered to an endpoint such as a
 * web server or an email address.
 *
 * This configuration overwrites any existing configuration.
 *
 * For more information, see Amazon SNS
 * notification options for Amazon EC2 Auto Scaling in the
 * *Amazon EC2 Auto Scaling User Guide*.
 *
 * If you exceed your maximum limit of SNS topics, which is 10 per Auto Scaling group, the call
 * fails.
 */
export declare const putNotificationConfiguration: API.OperationMethod<PutNotificationConfigurationType, PutNotificationConfigurationResponse, PutNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutScalingPolicyError = LimitExceededFault | ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * Creates or updates a scaling policy for an Auto Scaling group. Scaling policies are used to
 * scale an Auto Scaling group based on configurable metrics. If no policies are defined, the
 * dynamic scaling and predictive scaling features are not used.
 *
 * For more information about using dynamic scaling, see Target tracking
 * scaling policies and Step and simple scaling
 * policies in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * For more information about using predictive scaling, see Predictive
 * scaling for Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * You can view the scaling policies for an Auto Scaling group using the
 * DescribePolicies API call. If you are no longer using a scaling policy,
 * you can delete it by calling the DeletePolicy API.
 */
export declare const putScalingPolicy: API.OperationMethod<PutScalingPolicyType, PolicyARNType, PutScalingPolicyError, Credentials | HttpClient.HttpClient>;
export type PutScheduledUpdateGroupActionError = AlreadyExistsFault | LimitExceededFault | ResourceContentionFault | AutoScalingGroupNotFound | CommonErrors;
/**
 * Creates or updates a scheduled scaling action for an Auto Scaling group.
 *
 * For more information, see Scheduled scaling in the
 * *Amazon EC2 Auto Scaling User Guide*.
 *
 * You can view the scheduled actions for an Auto Scaling group using the
 * DescribeScheduledActions
 * API call. If you are no longer using a scheduled action, you can delete it by calling the
 * DeleteScheduledAction API.
 *
 * If you try to schedule your action in the past, Amazon EC2 Auto Scaling returns an error
 * message.
 */
export declare const putScheduledUpdateGroupAction: API.OperationMethod<PutScheduledUpdateGroupActionType, PutScheduledUpdateGroupActionResponse, PutScheduledUpdateGroupActionError, Credentials | HttpClient.HttpClient>;
export type PutWarmPoolError = InstanceRefreshInProgressFault | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Creates or updates a warm pool for the specified Auto Scaling group. A warm pool is a pool of
 * pre-initialized EC2 instances that sits alongside the Auto Scaling group. Whenever your
 * application needs to scale out, the Auto Scaling group can draw on the warm pool to meet its new
 * desired capacity.
 *
 * This operation must be called from the Region in which the Auto Scaling group was
 * created.
 *
 * You can view the instances in the warm pool using the DescribeWarmPool API call.
 * If you are no longer using a warm pool, you can delete it by calling the DeleteWarmPool API.
 *
 * For more information, see Warm pools for
 * Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const putWarmPool: API.OperationMethod<PutWarmPoolType, PutWarmPoolAnswer, PutWarmPoolError, Credentials | HttpClient.HttpClient>;
export type RecordLifecycleActionHeartbeatError = ResourceContentionFault | CommonErrors;
/**
 * Records a heartbeat for the lifecycle action associated with the specified token or
 * instance. This extends the timeout by the length of time defined using the
 * PutLifecycleHook API call.
 *
 * This step is a part of the procedure for adding a lifecycle hook to an Auto Scaling
 * group:
 *
 * - (Optional) Create a launch template or launch configuration with a user data
 * script that runs while an instance is in a wait state due to a lifecycle
 * hook.
 *
 * - (Optional) Create a Lambda function and a rule that allows Amazon EventBridge to invoke
 * your Lambda function when an instance is put into a wait state due to a
 * lifecycle hook.
 *
 * - (Optional) Create a notification target and an IAM role. The target can be
 * either an Amazon SQS queue or an Amazon SNS topic. The role allows Amazon EC2 Auto Scaling to publish
 * lifecycle notifications to the target.
 *
 * - Create the lifecycle hook. Specify whether the hook is used when the instances
 * launch or terminate.
 *
 * - If you need more time, record the lifecycle action
 * heartbeat to keep the instance in a wait state.
 *
 * - If you finish before the timeout period ends, send a callback by using the
 * CompleteLifecycleAction API call.
 *
 * For more information, see Amazon EC2 Auto Scaling lifecycle
 * hooks in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const recordLifecycleActionHeartbeat: API.OperationMethod<RecordLifecycleActionHeartbeatType, RecordLifecycleActionHeartbeatAnswer, RecordLifecycleActionHeartbeatError, Credentials | HttpClient.HttpClient>;
export type ResumeProcessesError = ResourceContentionFault | ResourceInUseFault | CommonErrors;
/**
 * Resumes the specified suspended auto scaling processes, or all suspended process, for
 * the specified Auto Scaling group.
 *
 * For more information, see Suspend and resume
 * Amazon EC2 Auto Scaling processes in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const resumeProcesses: API.OperationMethod<ScalingProcessQuery, ResumeProcessesResponse, ResumeProcessesError, Credentials | HttpClient.HttpClient>;
export type RollbackInstanceRefreshError = ActiveInstanceRefreshNotFoundFault | IrreversibleInstanceRefreshFault | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Cancels an instance refresh that is in progress and rolls back any changes that it
 * made. Amazon EC2 Auto Scaling replaces any instances that were replaced during the instance refresh.
 * This restores your Auto Scaling group to the configuration that it was using before the start of
 * the instance refresh.
 *
 * This operation is part of the instance refresh
 * feature in Amazon EC2 Auto Scaling, which helps you update instances in your Auto Scaling group
 * after you make configuration changes.
 *
 * A rollback is not supported in the following situations:
 *
 * - There is no desired configuration specified for the instance refresh.
 *
 * - The Auto Scaling group has a launch template that uses an Amazon Web Services Systems Manager parameter instead
 * of an AMI ID for the `ImageId` property.
 *
 * - The Auto Scaling group uses the launch template's `$Latest` or
 * `$Default` version.
 *
 * When you receive a successful response from this operation, Amazon EC2 Auto Scaling immediately
 * begins replacing instances. You can check the status of this operation through the
 * DescribeInstanceRefreshes API operation.
 */
export declare const rollbackInstanceRefresh: API.OperationMethod<RollbackInstanceRefreshType, RollbackInstanceRefreshAnswer, RollbackInstanceRefreshError, Credentials | HttpClient.HttpClient>;
export type SetDesiredCapacityError = ResourceContentionFault | ScalingActivityInProgressFault | CommonErrors;
/**
 * Sets the size of the specified Auto Scaling group.
 *
 * If a scale-in activity occurs as a result of a new `DesiredCapacity` value
 * that is lower than the current size of the group, the Auto Scaling group uses its termination
 * policy to determine which instances to terminate.
 *
 * For more information, see Manual
 * scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const setDesiredCapacity: API.OperationMethod<SetDesiredCapacityType, SetDesiredCapacityResponse, SetDesiredCapacityError, Credentials | HttpClient.HttpClient>;
export type SetInstanceHealthError = ResourceContentionFault | CommonErrors;
/**
 * Sets the health status of the specified instance.
 *
 * For more information, see Set up a custom
 * health check for your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const setInstanceHealth: API.OperationMethod<SetInstanceHealthQuery, SetInstanceHealthResponse, SetInstanceHealthError, Credentials | HttpClient.HttpClient>;
export type SetInstanceProtectionError = LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Updates the instance protection settings of the specified instances. This operation
 * cannot be called on instances in a warm pool.
 *
 * For more information, see Use
 * instance scale-in protection in the
 * *Amazon EC2 Auto Scaling User Guide*.
 *
 * If you exceed your maximum limit of instance IDs, which is 50 per Auto Scaling group, the call
 * fails.
 */
export declare const setInstanceProtection: API.OperationMethod<SetInstanceProtectionQuery, SetInstanceProtectionAnswer, SetInstanceProtectionError, Credentials | HttpClient.HttpClient>;
export type StartInstanceRefreshError = InstanceRefreshInProgressFault | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Starts an instance refresh.
 *
 * This operation is part of the instance refresh
 * feature in Amazon EC2 Auto Scaling, which helps you update instances in your Auto Scaling group.
 * This feature is helpful, for example, when you have a new AMI or a new user data script.
 * You just need to create a new launch template that specifies the new AMI or user data
 * script. Then start an instance refresh to immediately begin the process of updating
 * instances in the group.
 *
 * If successful, the request's response contains a unique ID that you can use to track
 * the progress of the instance refresh. To query its status, call the DescribeInstanceRefreshes API.
 * To describe the instance refreshes that
 * have already run, call the DescribeInstanceRefreshes API. To cancel an
 * instance refresh that is in progress, use the CancelInstanceRefresh
 * API.
 *
 * An instance refresh might fail for several reasons, such as EC2 launch failures,
 * misconfigured health checks, or not ignoring or allowing the termination of instances
 * that are in `Standby` state or protected from scale in. You can monitor for
 * failed EC2 launches using the scaling activities. To find the scaling activities, call
 * the DescribeScalingActivities API.
 *
 * If you enable auto rollback, your Auto Scaling group will be rolled back automatically when
 * the instance refresh fails. You can enable this feature before starting an instance
 * refresh by specifying the `AutoRollback` property in the instance refresh
 * preferences. Otherwise, to roll back an instance refresh before it finishes, use the
 * RollbackInstanceRefresh API.
 */
export declare const startInstanceRefresh: API.OperationMethod<StartInstanceRefreshType, StartInstanceRefreshAnswer, StartInstanceRefreshError, Credentials | HttpClient.HttpClient>;
export type SuspendProcessesError = ResourceContentionFault | ResourceInUseFault | CommonErrors;
/**
 * Suspends the specified auto scaling processes, or all processes, for the specified
 * Auto Scaling group.
 *
 * If you suspend either the `Launch` or `Terminate` process types,
 * it can prevent other process types from functioning properly. For more information, see
 * Suspend and resume
 * Amazon EC2 Auto Scaling processes in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * To resume processes that have been suspended, call the ResumeProcesses API.
 */
export declare const suspendProcesses: API.OperationMethod<ScalingProcessQuery, SuspendProcessesResponse, SuspendProcessesError, Credentials | HttpClient.HttpClient>;
export type TerminateInstanceInAutoScalingGroupError = ResourceContentionFault | ScalingActivityInProgressFault | CommonErrors;
/**
 * Terminates the specified instance and optionally adjusts the desired group size. This
 * operation cannot be called on instances in a warm pool.
 *
 * This call simply makes a termination request. The instances are not terminated
 * immediately. When an instance is terminated, the instance status changes to
 * `terminated`. You can't connect to or start an instance after you've
 * terminated it.
 *
 * If you do not specify the option to decrement the desired capacity, Amazon EC2 Auto Scaling launches
 * instances to replace the ones that are terminated.
 *
 * To terminate multiple instances in a single call, use the `InstanceIds`
 * and `AutoScalingGroupName` parameters instead of `InstanceId`.
 * When terminating multiple instances, the response populates
 * `Activities` instead of `Activity`.
 *
 * By default, Amazon EC2 Auto Scaling balances instances across all Availability Zones. If you
 * decrement the desired capacity, your Auto Scaling group can become unbalanced between
 * Availability Zones. Amazon EC2 Auto Scaling tries to rebalance the group, and rebalancing might
 * terminate instances in other zones. For more information, see Manual
 * scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const terminateInstanceInAutoScalingGroup: API.OperationMethod<TerminateInstanceInAutoScalingGroupType, ActivityType, TerminateInstanceInAutoScalingGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateAutoScalingGroupError = ResourceContentionFault | ScalingActivityInProgressFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * **We strongly recommend that all Auto Scaling groups use launch templates to ensure full functionality for Amazon EC2 Auto Scaling and Amazon EC2.**
 *
 * Updates the configuration for the specified Auto Scaling group.
 *
 * To update an Auto Scaling group, specify the name of the group and the property that you want
 * to change. Any properties that you don't specify are not changed by this update request.
 * The new settings take effect on any scaling activities after this call returns.
 *
 * If you associate a new launch configuration or template with an Auto Scaling group, all new
 * instances will get the updated configuration. Existing instances continue to run with
 * the configuration that they were originally launched with. When you update a group to
 * specify a mixed instances policy instead of a launch configuration or template, existing
 * instances may be replaced to match the new purchasing options that you specified in the
 * policy. For example, if the group currently has 100% On-Demand capacity and the policy
 * specifies 50% Spot capacity, this means that half of your instances will be gradually
 * terminated and relaunched as Spot Instances. When replacing instances, Amazon EC2 Auto Scaling launches
 * new instances before terminating the old ones, so that updating your group does not
 * compromise the performance or availability of your application.
 *
 * Note the following about changing `DesiredCapacity`, `MaxSize`,
 * or `MinSize`:
 *
 * - If a scale-in activity occurs as a result of a new
 * `DesiredCapacity` value that is lower than the current size of
 * the group, the Auto Scaling group uses its termination policy to determine which
 * instances to terminate.
 *
 * - If you specify a new value for `MinSize` without specifying a value
 * for `DesiredCapacity`, and the new `MinSize` is larger
 * than the current size of the group, this sets the group's
 * `DesiredCapacity` to the new `MinSize` value.
 *
 * - If you specify a new value for `MaxSize` without specifying a value
 * for `DesiredCapacity`, and the new `MaxSize` is smaller
 * than the current size of the group, this sets the group's
 * `DesiredCapacity` to the new `MaxSize` value.
 *
 * To see which properties have been set, call the DescribeAutoScalingGroups API.
 * To view the scaling policies for an Auto Scaling
 * group, call the DescribePolicies API. If the group has scaling
 * policies, you can update them by calling the PutScalingPolicy API.
 */
export declare const updateAutoScalingGroup: API.OperationMethod<UpdateAutoScalingGroupType, UpdateAutoScalingGroupResponse, UpdateAutoScalingGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=auto-scaling.d.ts.map