import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
    readonly Type: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly message: any;
    readonly Type: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly Type: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerErrorException_base: S.Class<InternalServerErrorException, S.TaggedStruct<"InternalServerErrorException", {
    readonly message: any;
    readonly Type: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly Type: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type DetectorId = string;
export interface AcceptAdministratorInvitationRequest {
    DetectorId: string;
    AdministratorId?: string;
    InvitationId?: string;
}
export declare const AcceptAdministratorInvitationRequest: S.Schema<AcceptAdministratorInvitationRequest>;
export interface AcceptAdministratorInvitationResponse {
}
export declare const AcceptAdministratorInvitationResponse: S.Schema<AcceptAdministratorInvitationResponse>;
export interface AcceptInvitationRequest {
    DetectorId: string;
    MasterId?: string;
    InvitationId?: string;
}
export declare const AcceptInvitationRequest: S.Schema<AcceptInvitationRequest>;
export interface AcceptInvitationResponse {
}
export declare const AcceptInvitationResponse: S.Schema<AcceptInvitationResponse>;
export type FindingId = string;
export type FindingIds = string[];
export declare const FindingIds: any;
export interface ArchiveFindingsRequest {
    DetectorId: string;
    FindingIds?: string[];
}
export declare const ArchiveFindingsRequest: S.Schema<ArchiveFindingsRequest>;
export interface ArchiveFindingsResponse {
}
export declare const ArchiveFindingsResponse: S.Schema<ArchiveFindingsResponse>;
export type ClientToken = string;
export type FindingPublishingFrequency = "FIFTEEN_MINUTES" | "ONE_HOUR" | "SIX_HOURS" | (string & {});
export declare const FindingPublishingFrequency: any;
export interface S3LogsConfiguration {
    Enable?: boolean;
}
export declare const S3LogsConfiguration: S.Schema<S3LogsConfiguration>;
export interface KubernetesAuditLogsConfiguration {
    Enable?: boolean;
}
export declare const KubernetesAuditLogsConfiguration: S.Schema<KubernetesAuditLogsConfiguration>;
export interface KubernetesConfiguration {
    AuditLogs?: KubernetesAuditLogsConfiguration;
}
export declare const KubernetesConfiguration: S.Schema<KubernetesConfiguration>;
export interface ScanEc2InstanceWithFindings {
    EbsVolumes?: boolean;
}
export declare const ScanEc2InstanceWithFindings: S.Schema<ScanEc2InstanceWithFindings>;
export interface MalwareProtectionConfiguration {
    ScanEc2InstanceWithFindings?: ScanEc2InstanceWithFindings;
}
export declare const MalwareProtectionConfiguration: S.Schema<MalwareProtectionConfiguration>;
export interface DataSourceConfigurations {
    S3Logs?: S3LogsConfiguration;
    Kubernetes?: KubernetesConfiguration;
    MalwareProtection?: MalwareProtectionConfiguration;
}
export declare const DataSourceConfigurations: S.Schema<DataSourceConfigurations>;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type DetectorFeature = "S3_DATA_EVENTS" | "EKS_AUDIT_LOGS" | "EBS_MALWARE_PROTECTION" | "RDS_LOGIN_EVENTS" | "LAMBDA_NETWORK_LOGS" | "EKS_RUNTIME_MONITORING" | "RUNTIME_MONITORING" | "AI_PROTECTION" | "AI_ANALYST" | (string & {});
export declare const DetectorFeature: any;
export type FeatureStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const FeatureStatus: any;
export type FeatureAdditionalConfiguration = "EKS_ADDON_MANAGEMENT" | "ECS_FARGATE_AGENT_MANAGEMENT" | "EC2_AGENT_MANAGEMENT" | (string & {});
export declare const FeatureAdditionalConfiguration: any;
export interface DetectorAdditionalConfiguration {
    Name?: FeatureAdditionalConfiguration;
    Status?: FeatureStatus;
}
export declare const DetectorAdditionalConfiguration: S.Schema<DetectorAdditionalConfiguration>;
export type DetectorAdditionalConfigurations = DetectorAdditionalConfiguration[];
export declare const DetectorAdditionalConfigurations: any;
export interface DetectorFeatureConfiguration {
    Name?: DetectorFeature;
    Status?: FeatureStatus;
    AdditionalConfiguration?: DetectorAdditionalConfiguration[];
}
export declare const DetectorFeatureConfiguration: S.Schema<DetectorFeatureConfiguration>;
export type DetectorFeatureConfigurations = DetectorFeatureConfiguration[];
export declare const DetectorFeatureConfigurations: any;
export interface CreateDetectorRequest {
    Enable?: boolean;
    ClientToken?: string;
    FindingPublishingFrequency?: FindingPublishingFrequency;
    DataSources?: DataSourceConfigurations;
    Tags?: {
        [key: string]: string | undefined;
    };
    Features?: DetectorFeatureConfiguration[];
}
export declare const CreateDetectorRequest: S.Schema<CreateDetectorRequest>;
export type DataSourceStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const DataSourceStatus: any;
export interface EbsVolumesResult {
    Status?: DataSourceStatus;
    Reason?: string;
}
export declare const EbsVolumesResult: S.Schema<EbsVolumesResult>;
export interface ScanEc2InstanceWithFindingsResult {
    EbsVolumes?: EbsVolumesResult;
}
export declare const ScanEc2InstanceWithFindingsResult: S.Schema<ScanEc2InstanceWithFindingsResult>;
export interface MalwareProtectionConfigurationResult {
    ScanEc2InstanceWithFindings?: ScanEc2InstanceWithFindingsResult;
    ServiceRole?: string;
}
export declare const MalwareProtectionConfigurationResult: S.Schema<MalwareProtectionConfigurationResult>;
export interface UnprocessedDataSourcesResult {
    MalwareProtection?: MalwareProtectionConfigurationResult;
}
export declare const UnprocessedDataSourcesResult: S.Schema<UnprocessedDataSourcesResult>;
export interface CreateDetectorResponse {
    DetectorId?: string;
    UnprocessedDataSources?: UnprocessedDataSourcesResult;
}
export declare const CreateDetectorResponse: S.Schema<CreateDetectorResponse>;
export type FilterName = string;
export type FilterDescription = string;
export type FilterAction = "NOOP" | "ARCHIVE" | (string & {});
export declare const FilterAction: any;
export type FilterRank = number;
export type Eq = string[];
export declare const Eq: any;
export type Neq = string[];
export declare const Neq: any;
export type Equals = string[];
export declare const Equals: any;
export type NotEquals = string[];
export declare const NotEquals: any;
export type Match = string;
export type Matches = string[];
export declare const Matches: any;
export type NotMatch = string;
export type NotMatches = string[];
export declare const NotMatches: any;
export interface Condition {
    Eq?: string[];
    Neq?: string[];
    Gt?: number;
    Gte?: number;
    Lt?: number;
    Lte?: number;
    Equals?: string[];
    NotEquals?: string[];
    GreaterThan?: number;
    GreaterThanOrEqual?: number;
    LessThan?: number;
    LessThanOrEqual?: number;
    Matches?: string[];
    NotMatches?: string[];
}
export declare const Condition: S.Schema<Condition>;
export type Criterion = {
    [key: string]: Condition | undefined;
};
export declare const Criterion: any;
export interface FindingCriteria {
    Criterion?: {
        [key: string]: Condition | undefined;
    };
}
export declare const FindingCriteria: S.Schema<FindingCriteria>;
export interface CreateFilterRequest {
    DetectorId: string;
    Name?: string;
    Description?: string;
    Action?: FilterAction;
    Rank?: number;
    FindingCriteria?: FindingCriteria;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateFilterRequest: S.Schema<CreateFilterRequest>;
export interface CreateFilterResponse {
    Name: string;
}
export declare const CreateFilterResponse: S.Schema<CreateFilterResponse>;
export type TriggerPrompt = string;
export interface CreateInvestigationRequest {
    DetectorId: string;
    TriggerPrompt?: string;
    ClientToken?: string;
}
export declare const CreateInvestigationRequest: S.Schema<CreateInvestigationRequest>;
export type InvestigationId = string;
export interface CreateInvestigationResponse {
    InvestigationId: string;
}
export declare const CreateInvestigationResponse: S.Schema<CreateInvestigationResponse>;
export type Name = string;
export type IpSetFormat = "TXT" | "STIX" | "OTX_CSV" | "ALIEN_VAULT" | "PROOF_POINT" | "FIRE_EYE" | (string & {});
export declare const IpSetFormat: any;
export type Location = string;
export type AccountId = string;
export interface CreateIPSetRequest {
    DetectorId: string;
    Name?: string;
    Format?: IpSetFormat;
    Location?: string;
    Activate?: boolean;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ExpectedBucketOwner?: string;
}
export declare const CreateIPSetRequest: S.Schema<CreateIPSetRequest>;
export interface CreateIPSetResponse {
    IpSetId: string;
}
export declare const CreateIPSetResponse: S.Schema<CreateIPSetResponse>;
export type MalwareProtectionPlanObjectPrefixesList = string[];
export declare const MalwareProtectionPlanObjectPrefixesList: any;
export interface CreateS3BucketResource {
    BucketName?: string;
    ObjectPrefixes?: string[];
}
export declare const CreateS3BucketResource: S.Schema<CreateS3BucketResource>;
export interface CreateProtectedResource {
    S3Bucket?: CreateS3BucketResource;
}
export declare const CreateProtectedResource: S.Schema<CreateProtectedResource>;
export type MalwareProtectionPlanTaggingActionStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const MalwareProtectionPlanTaggingActionStatus: any;
export interface MalwareProtectionPlanTaggingAction {
    Status?: MalwareProtectionPlanTaggingActionStatus;
}
export declare const MalwareProtectionPlanTaggingAction: S.Schema<MalwareProtectionPlanTaggingAction>;
export interface MalwareProtectionPlanActions {
    Tagging?: MalwareProtectionPlanTaggingAction;
}
export declare const MalwareProtectionPlanActions: S.Schema<MalwareProtectionPlanActions>;
export interface CreateMalwareProtectionPlanRequest {
    ClientToken?: string;
    Role?: string;
    ProtectedResource?: CreateProtectedResource;
    Actions?: MalwareProtectionPlanActions;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateMalwareProtectionPlanRequest: S.Schema<CreateMalwareProtectionPlanRequest>;
export interface CreateMalwareProtectionPlanResponse {
    MalwareProtectionPlanId?: string;
}
export declare const CreateMalwareProtectionPlanResponse: S.Schema<CreateMalwareProtectionPlanResponse>;
export type Email = string | redacted.Redacted<string>;
export interface AccountDetail {
    AccountId?: string;
    Email?: string | redacted.Redacted<string>;
}
export declare const AccountDetail: S.Schema<AccountDetail>;
export type AccountDetails = AccountDetail[];
export declare const AccountDetails: any;
export interface CreateMembersRequest {
    DetectorId: string;
    AccountDetails?: AccountDetail[];
}
export declare const CreateMembersRequest: S.Schema<CreateMembersRequest>;
export interface UnprocessedAccount {
    AccountId?: string;
    Result?: string;
}
export declare const UnprocessedAccount: S.Schema<UnprocessedAccount>;
export type UnprocessedAccounts = UnprocessedAccount[];
export declare const UnprocessedAccounts: any;
export interface CreateMembersResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export declare const CreateMembersResponse: S.Schema<CreateMembersResponse>;
export type DestinationType = "S3" | (string & {});
export declare const DestinationType: any;
export interface DestinationProperties {
    DestinationArn?: string;
    KmsKeyArn?: string;
}
export declare const DestinationProperties: S.Schema<DestinationProperties>;
export interface CreatePublishingDestinationRequest {
    DetectorId: string;
    DestinationType?: DestinationType;
    DestinationProperties?: DestinationProperties;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePublishingDestinationRequest: S.Schema<CreatePublishingDestinationRequest>;
export interface CreatePublishingDestinationResponse {
    DestinationId: string;
}
export declare const CreatePublishingDestinationResponse: S.Schema<CreatePublishingDestinationResponse>;
export type FindingType = string;
export type FindingTypes = string[];
export declare const FindingTypes: any;
export interface CreateSampleFindingsRequest {
    DetectorId: string;
    FindingTypes?: string[];
}
export declare const CreateSampleFindingsRequest: S.Schema<CreateSampleFindingsRequest>;
export interface CreateSampleFindingsResponse {
}
export declare const CreateSampleFindingsResponse: S.Schema<CreateSampleFindingsResponse>;
export type ThreatEntitySetFormat = "TXT" | "STIX" | "OTX_CSV" | "ALIEN_VAULT" | "PROOF_POINT" | "FIRE_EYE" | (string & {});
export declare const ThreatEntitySetFormat: any;
export type ExpectedBucketOwner = string;
export interface CreateThreatEntitySetRequest {
    DetectorId: string;
    Name?: string;
    Format?: ThreatEntitySetFormat;
    Location?: string;
    ExpectedBucketOwner?: string;
    Activate?: boolean;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateThreatEntitySetRequest: S.Schema<CreateThreatEntitySetRequest>;
export interface CreateThreatEntitySetResponse {
    ThreatEntitySetId: string;
}
export declare const CreateThreatEntitySetResponse: S.Schema<CreateThreatEntitySetResponse>;
export type ThreatIntelSetFormat = "TXT" | "STIX" | "OTX_CSV" | "ALIEN_VAULT" | "PROOF_POINT" | "FIRE_EYE" | (string & {});
export declare const ThreatIntelSetFormat: any;
export interface CreateThreatIntelSetRequest {
    DetectorId: string;
    Name?: string;
    Format?: ThreatIntelSetFormat;
    Location?: string;
    Activate?: boolean;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ExpectedBucketOwner?: string;
}
export declare const CreateThreatIntelSetRequest: S.Schema<CreateThreatIntelSetRequest>;
export interface CreateThreatIntelSetResponse {
    ThreatIntelSetId: string;
}
export declare const CreateThreatIntelSetResponse: S.Schema<CreateThreatIntelSetResponse>;
export type TrustedEntitySetFormat = "TXT" | "STIX" | "OTX_CSV" | "ALIEN_VAULT" | "PROOF_POINT" | "FIRE_EYE" | (string & {});
export declare const TrustedEntitySetFormat: any;
export interface CreateTrustedEntitySetRequest {
    DetectorId: string;
    Name?: string;
    Format?: TrustedEntitySetFormat;
    Location?: string;
    ExpectedBucketOwner?: string;
    Activate?: boolean;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateTrustedEntitySetRequest: S.Schema<CreateTrustedEntitySetRequest>;
export interface CreateTrustedEntitySetResponse {
    TrustedEntitySetId: string;
}
export declare const CreateTrustedEntitySetResponse: S.Schema<CreateTrustedEntitySetResponse>;
export type AccountIds = string[];
export declare const AccountIds: any;
export interface DeclineInvitationsRequest {
    AccountIds?: string[];
}
export declare const DeclineInvitationsRequest: S.Schema<DeclineInvitationsRequest>;
export interface DeclineInvitationsResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export declare const DeclineInvitationsResponse: S.Schema<DeclineInvitationsResponse>;
export interface DeleteDetectorRequest {
    DetectorId: string;
}
export declare const DeleteDetectorRequest: S.Schema<DeleteDetectorRequest>;
export interface DeleteDetectorResponse {
}
export declare const DeleteDetectorResponse: S.Schema<DeleteDetectorResponse>;
export interface DeleteFilterRequest {
    DetectorId: string;
    FilterName: string;
}
export declare const DeleteFilterRequest: S.Schema<DeleteFilterRequest>;
export interface DeleteFilterResponse {
}
export declare const DeleteFilterResponse: S.Schema<DeleteFilterResponse>;
export interface DeleteInvitationsRequest {
    AccountIds?: string[];
}
export declare const DeleteInvitationsRequest: S.Schema<DeleteInvitationsRequest>;
export interface DeleteInvitationsResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export declare const DeleteInvitationsResponse: S.Schema<DeleteInvitationsResponse>;
export interface DeleteIPSetRequest {
    DetectorId: string;
    IpSetId?: string;
}
export declare const DeleteIPSetRequest: S.Schema<DeleteIPSetRequest>;
export interface DeleteIPSetResponse {
}
export declare const DeleteIPSetResponse: S.Schema<DeleteIPSetResponse>;
export interface DeleteMalwareProtectionPlanRequest {
    MalwareProtectionPlanId?: string;
}
export declare const DeleteMalwareProtectionPlanRequest: S.Schema<DeleteMalwareProtectionPlanRequest>;
export interface DeleteMalwareProtectionPlanResponse {
}
export declare const DeleteMalwareProtectionPlanResponse: S.Schema<DeleteMalwareProtectionPlanResponse>;
export interface DeleteMembersRequest {
    DetectorId: string;
    AccountIds?: string[];
}
export declare const DeleteMembersRequest: S.Schema<DeleteMembersRequest>;
export interface DeleteMembersResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export declare const DeleteMembersResponse: S.Schema<DeleteMembersResponse>;
export interface DeletePublishingDestinationRequest {
    DetectorId: string;
    DestinationId: string;
}
export declare const DeletePublishingDestinationRequest: S.Schema<DeletePublishingDestinationRequest>;
export interface DeletePublishingDestinationResponse {
}
export declare const DeletePublishingDestinationResponse: S.Schema<DeletePublishingDestinationResponse>;
export interface DeleteThreatEntitySetRequest {
    DetectorId: string;
    ThreatEntitySetId?: string;
}
export declare const DeleteThreatEntitySetRequest: S.Schema<DeleteThreatEntitySetRequest>;
export interface DeleteThreatEntitySetResponse {
}
export declare const DeleteThreatEntitySetResponse: S.Schema<DeleteThreatEntitySetResponse>;
export interface DeleteThreatIntelSetRequest {
    DetectorId: string;
    ThreatIntelSetId: string;
}
export declare const DeleteThreatIntelSetRequest: S.Schema<DeleteThreatIntelSetRequest>;
export interface DeleteThreatIntelSetResponse {
}
export declare const DeleteThreatIntelSetResponse: S.Schema<DeleteThreatIntelSetResponse>;
export interface DeleteTrustedEntitySetRequest {
    DetectorId: string;
    TrustedEntitySetId: string;
}
export declare const DeleteTrustedEntitySetRequest: S.Schema<DeleteTrustedEntitySetRequest>;
export interface DeleteTrustedEntitySetResponse {
}
export declare const DeleteTrustedEntitySetResponse: S.Schema<DeleteTrustedEntitySetResponse>;
export type IntegerValueWithMax = number;
export type CriterionKey = "EC2_INSTANCE_ARN" | "SCAN_ID" | "ACCOUNT_ID" | "GUARDDUTY_FINDING_ID" | "SCAN_START_TIME" | "SCAN_STATUS" | "SCAN_TYPE" | (string & {});
export declare const CriterionKey: any;
export type NonEmptyString = string;
export type LongValue = number;
export interface FilterCondition {
    EqualsValue?: string;
    GreaterThan?: number;
    LessThan?: number;
}
export declare const FilterCondition: S.Schema<FilterCondition>;
export interface FilterCriterion {
    CriterionKey?: CriterionKey;
    FilterCondition?: FilterCondition;
}
export declare const FilterCriterion: S.Schema<FilterCriterion>;
export type FilterCriterionList = FilterCriterion[];
export declare const FilterCriterionList: any;
export interface FilterCriteria {
    FilterCriterion?: FilterCriterion[];
}
export declare const FilterCriteria: S.Schema<FilterCriteria>;
export type OrderBy = "ASC" | "DESC" | (string & {});
export declare const OrderBy: any;
export interface SortCriteria {
    AttributeName?: string;
    OrderBy?: OrderBy;
}
export declare const SortCriteria: S.Schema<SortCriteria>;
export interface DescribeMalwareScansRequest {
    DetectorId: string;
    NextToken?: string;
    MaxResults?: number;
    FilterCriteria?: FilterCriteria;
    SortCriteria?: SortCriteria;
}
export declare const DescribeMalwareScansRequest: S.Schema<DescribeMalwareScansRequest>;
export type ScanStatus = "RUNNING" | "COMPLETED" | "FAILED" | "SKIPPED" | (string & {});
export declare const ScanStatus: any;
export type TriggerType = "BACKUP" | "GUARDDUTY" | (string & {});
export declare const TriggerType: any;
export interface TriggerDetails {
    GuardDutyFindingId?: string;
    Description?: string;
    TriggerType?: TriggerType;
}
export declare const TriggerDetails: S.Schema<TriggerDetails>;
export type InstanceArn = string;
export interface ResourceDetails {
    InstanceArn?: string;
}
export declare const ResourceDetails: S.Schema<ResourceDetails>;
export type ScanResult = "CLEAN" | "INFECTED" | (string & {});
export declare const ScanResult: any;
export interface ScanResultDetails {
    ScanResult?: ScanResult;
}
export declare const ScanResultDetails: S.Schema<ScanResultDetails>;
export type PositiveLong = number;
export interface VolumeDetail {
    VolumeArn?: string;
    VolumeType?: string;
    DeviceName?: string;
    VolumeSizeInGB?: number;
    EncryptionType?: string;
    SnapshotArn?: string;
    KmsKeyArn?: string;
}
export declare const VolumeDetail: S.Schema<VolumeDetail>;
export type VolumeDetails = VolumeDetail[];
export declare const VolumeDetails: any;
export type ScanType = "GUARDDUTY_INITIATED" | "ON_DEMAND" | (string & {});
export declare const ScanType: any;
export interface Scan {
    DetectorId?: string;
    AdminDetectorId?: string;
    ScanId?: string;
    ScanStatus?: ScanStatus;
    FailureReason?: string;
    ScanStartTime?: Date;
    ScanEndTime?: Date;
    TriggerDetails?: TriggerDetails;
    ResourceDetails?: ResourceDetails;
    ScanResultDetails?: ScanResultDetails;
    AccountId?: string;
    TotalBytes?: number;
    FileCount?: number;
    AttachedVolumes?: VolumeDetail[];
    ScanType?: ScanType;
}
export declare const Scan: S.Schema<Scan>;
export type Scans = Scan[];
export declare const Scans: any;
export interface DescribeMalwareScansResponse {
    Scans: Scan[];
    NextToken?: string;
}
export declare const DescribeMalwareScansResponse: S.Schema<DescribeMalwareScansResponse>;
export type MaxResults = number;
export interface DescribeOrganizationConfigurationRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeOrganizationConfigurationRequest: S.Schema<DescribeOrganizationConfigurationRequest>;
export interface OrganizationS3LogsConfigurationResult {
    AutoEnable?: boolean;
}
export declare const OrganizationS3LogsConfigurationResult: S.Schema<OrganizationS3LogsConfigurationResult>;
export interface OrganizationKubernetesAuditLogsConfigurationResult {
    AutoEnable?: boolean;
}
export declare const OrganizationKubernetesAuditLogsConfigurationResult: S.Schema<OrganizationKubernetesAuditLogsConfigurationResult>;
export interface OrganizationKubernetesConfigurationResult {
    AuditLogs?: OrganizationKubernetesAuditLogsConfigurationResult;
}
export declare const OrganizationKubernetesConfigurationResult: S.Schema<OrganizationKubernetesConfigurationResult>;
export interface OrganizationEbsVolumesResult {
    AutoEnable?: boolean;
}
export declare const OrganizationEbsVolumesResult: S.Schema<OrganizationEbsVolumesResult>;
export interface OrganizationScanEc2InstanceWithFindingsResult {
    EbsVolumes?: OrganizationEbsVolumesResult;
}
export declare const OrganizationScanEc2InstanceWithFindingsResult: S.Schema<OrganizationScanEc2InstanceWithFindingsResult>;
export interface OrganizationMalwareProtectionConfigurationResult {
    ScanEc2InstanceWithFindings?: OrganizationScanEc2InstanceWithFindingsResult;
}
export declare const OrganizationMalwareProtectionConfigurationResult: S.Schema<OrganizationMalwareProtectionConfigurationResult>;
export interface OrganizationDataSourceConfigurationsResult {
    S3Logs?: OrganizationS3LogsConfigurationResult;
    Kubernetes?: OrganizationKubernetesConfigurationResult;
    MalwareProtection?: OrganizationMalwareProtectionConfigurationResult;
}
export declare const OrganizationDataSourceConfigurationsResult: S.Schema<OrganizationDataSourceConfigurationsResult>;
export type OrgFeature = "S3_DATA_EVENTS" | "EKS_AUDIT_LOGS" | "EBS_MALWARE_PROTECTION" | "RDS_LOGIN_EVENTS" | "LAMBDA_NETWORK_LOGS" | "EKS_RUNTIME_MONITORING" | "RUNTIME_MONITORING" | "AI_PROTECTION" | (string & {});
export declare const OrgFeature: any;
export type OrgFeatureStatus = "NEW" | "NONE" | "ALL" | (string & {});
export declare const OrgFeatureStatus: any;
export type OrgFeatureAdditionalConfiguration = "EKS_ADDON_MANAGEMENT" | "ECS_FARGATE_AGENT_MANAGEMENT" | "EC2_AGENT_MANAGEMENT" | (string & {});
export declare const OrgFeatureAdditionalConfiguration: any;
export interface OrganizationAdditionalConfigurationResult {
    Name?: OrgFeatureAdditionalConfiguration;
    AutoEnable?: OrgFeatureStatus;
}
export declare const OrganizationAdditionalConfigurationResult: S.Schema<OrganizationAdditionalConfigurationResult>;
export type OrganizationAdditionalConfigurationResults = OrganizationAdditionalConfigurationResult[];
export declare const OrganizationAdditionalConfigurationResults: any;
export interface OrganizationFeatureConfigurationResult {
    Name?: OrgFeature;
    AutoEnable?: OrgFeatureStatus;
    AdditionalConfiguration?: OrganizationAdditionalConfigurationResult[];
}
export declare const OrganizationFeatureConfigurationResult: S.Schema<OrganizationFeatureConfigurationResult>;
export type OrganizationFeaturesConfigurationsResults = OrganizationFeatureConfigurationResult[];
export declare const OrganizationFeaturesConfigurationsResults: any;
export type AutoEnableMembers = "NEW" | "ALL" | "NONE" | (string & {});
export declare const AutoEnableMembers: any;
export interface DescribeOrganizationConfigurationResponse {
    AutoEnable?: boolean;
    MemberAccountLimitReached: boolean;
    DataSources?: OrganizationDataSourceConfigurationsResult & {
        S3Logs: OrganizationS3LogsConfigurationResult & {
            AutoEnable: boolean;
        };
        Kubernetes: OrganizationKubernetesConfigurationResult & {
            AuditLogs: OrganizationKubernetesAuditLogsConfigurationResult & {
                AutoEnable: boolean;
            };
        };
    };
    Features?: OrganizationFeatureConfigurationResult[];
    NextToken?: string;
    AutoEnableOrganizationMembers?: AutoEnableMembers;
}
export declare const DescribeOrganizationConfigurationResponse: S.Schema<DescribeOrganizationConfigurationResponse>;
export interface DescribePublishingDestinationRequest {
    DetectorId: string;
    DestinationId: string;
}
export declare const DescribePublishingDestinationRequest: S.Schema<DescribePublishingDestinationRequest>;
export type PublishingStatus = "PENDING_VERIFICATION" | "PUBLISHING" | "UNABLE_TO_PUBLISH_FIX_DESTINATION_PROPERTY" | "STOPPED" | (string & {});
export declare const PublishingStatus: any;
export interface DescribePublishingDestinationResponse {
    DestinationId: string;
    DestinationType: DestinationType;
    Status: PublishingStatus;
    PublishingFailureStartTimestamp: number;
    DestinationProperties: DestinationProperties;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DescribePublishingDestinationResponse: S.Schema<DescribePublishingDestinationResponse>;
export interface DisableOrganizationAdminAccountRequest {
    AdminAccountId?: string;
}
export declare const DisableOrganizationAdminAccountRequest: S.Schema<DisableOrganizationAdminAccountRequest>;
export interface DisableOrganizationAdminAccountResponse {
}
export declare const DisableOrganizationAdminAccountResponse: S.Schema<DisableOrganizationAdminAccountResponse>;
export interface DisassociateFromAdministratorAccountRequest {
    DetectorId: string;
}
export declare const DisassociateFromAdministratorAccountRequest: S.Schema<DisassociateFromAdministratorAccountRequest>;
export interface DisassociateFromAdministratorAccountResponse {
}
export declare const DisassociateFromAdministratorAccountResponse: S.Schema<DisassociateFromAdministratorAccountResponse>;
export interface DisassociateFromMasterAccountRequest {
    DetectorId: string;
}
export declare const DisassociateFromMasterAccountRequest: S.Schema<DisassociateFromMasterAccountRequest>;
export interface DisassociateFromMasterAccountResponse {
}
export declare const DisassociateFromMasterAccountResponse: S.Schema<DisassociateFromMasterAccountResponse>;
export interface DisassociateMembersRequest {
    DetectorId: string;
    AccountIds?: string[];
}
export declare const DisassociateMembersRequest: S.Schema<DisassociateMembersRequest>;
export interface DisassociateMembersResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export declare const DisassociateMembersResponse: S.Schema<DisassociateMembersResponse>;
export interface EnableOrganizationAdminAccountRequest {
    AdminAccountId?: string;
}
export declare const EnableOrganizationAdminAccountRequest: S.Schema<EnableOrganizationAdminAccountRequest>;
export interface EnableOrganizationAdminAccountResponse {
}
export declare const EnableOrganizationAdminAccountResponse: S.Schema<EnableOrganizationAdminAccountResponse>;
export interface GetAdministratorAccountRequest {
    DetectorId: string;
}
export declare const GetAdministratorAccountRequest: S.Schema<GetAdministratorAccountRequest>;
export interface Administrator {
    AccountId?: string;
    InvitationId?: string;
    RelationshipStatus?: string;
    InvitedAt?: string;
}
export declare const Administrator: S.Schema<Administrator>;
export interface GetAdministratorAccountResponse {
    Administrator: Administrator;
}
export declare const GetAdministratorAccountResponse: S.Schema<GetAdministratorAccountResponse>;
export type CoverageFilterCriterionKey = "ACCOUNT_ID" | "RESOURCE_TYPE" | "COVERAGE_STATUS" | "ADDON_VERSION" | "CLUSTER_NAME" | "ECS_CLUSTER_NAME" | "MANAGEMENT_TYPE" | "EKS_CLUSTER_NAME" | "AGENT_VERSION" | "INSTANCE_ID" | "CLUSTER_ARN" | (string & {});
export declare const CoverageFilterCriterionKey: any;
export interface CoverageFilterCondition {
    Equals?: string[];
    NotEquals?: string[];
}
export declare const CoverageFilterCondition: S.Schema<CoverageFilterCondition>;
export interface CoverageFilterCriterion {
    CriterionKey?: CoverageFilterCriterionKey;
    FilterCondition?: CoverageFilterCondition;
}
export declare const CoverageFilterCriterion: S.Schema<CoverageFilterCriterion>;
export type CoverageFilterCriterionList = CoverageFilterCriterion[];
export declare const CoverageFilterCriterionList: any;
export interface CoverageFilterCriteria {
    FilterCriterion?: CoverageFilterCriterion[];
}
export declare const CoverageFilterCriteria: S.Schema<CoverageFilterCriteria>;
export type CoverageStatisticsType = "COUNT_BY_RESOURCE_TYPE" | "COUNT_BY_COVERAGE_STATUS" | (string & {});
export declare const CoverageStatisticsType: any;
export type CoverageStatisticsTypeList = CoverageStatisticsType[];
export declare const CoverageStatisticsTypeList: any;
export interface GetCoverageStatisticsRequest {
    DetectorId: string;
    FilterCriteria?: CoverageFilterCriteria;
    StatisticsType?: CoverageStatisticsType[];
}
export declare const GetCoverageStatisticsRequest: S.Schema<GetCoverageStatisticsRequest>;
export type ResourceType = "EKS" | "ECS" | "EC2" | (string & {});
export declare const ResourceType: any;
export type CountByResourceType = {
    [key in ResourceType]?: number;
};
export declare const CountByResourceType: any;
export type CoverageStatus = "HEALTHY" | "UNHEALTHY" | (string & {});
export declare const CoverageStatus: any;
export type CountByCoverageStatus = {
    [key in CoverageStatus]?: number;
};
export declare const CountByCoverageStatus: any;
export interface CoverageStatistics {
    CountByResourceType?: {
        [key: string]: number | undefined;
    };
    CountByCoverageStatus?: {
        [key: string]: number | undefined;
    };
}
export declare const CoverageStatistics: S.Schema<CoverageStatistics>;
export interface GetCoverageStatisticsResponse {
    CoverageStatistics?: CoverageStatistics;
}
export declare const GetCoverageStatisticsResponse: S.Schema<GetCoverageStatisticsResponse>;
export interface GetDetectorRequest {
    DetectorId: string;
}
export declare const GetDetectorRequest: S.Schema<GetDetectorRequest>;
export type DetectorStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const DetectorStatus: any;
export interface CloudTrailConfigurationResult {
    Status?: DataSourceStatus;
}
export declare const CloudTrailConfigurationResult: S.Schema<CloudTrailConfigurationResult>;
export interface DNSLogsConfigurationResult {
    Status?: DataSourceStatus;
}
export declare const DNSLogsConfigurationResult: S.Schema<DNSLogsConfigurationResult>;
export interface FlowLogsConfigurationResult {
    Status?: DataSourceStatus;
}
export declare const FlowLogsConfigurationResult: S.Schema<FlowLogsConfigurationResult>;
export interface S3LogsConfigurationResult {
    Status?: DataSourceStatus;
}
export declare const S3LogsConfigurationResult: S.Schema<S3LogsConfigurationResult>;
export interface KubernetesAuditLogsConfigurationResult {
    Status?: DataSourceStatus;
}
export declare const KubernetesAuditLogsConfigurationResult: S.Schema<KubernetesAuditLogsConfigurationResult>;
export interface KubernetesConfigurationResult {
    AuditLogs?: KubernetesAuditLogsConfigurationResult;
}
export declare const KubernetesConfigurationResult: S.Schema<KubernetesConfigurationResult>;
export interface DataSourceConfigurationsResult {
    CloudTrail?: CloudTrailConfigurationResult;
    DNSLogs?: DNSLogsConfigurationResult;
    FlowLogs?: FlowLogsConfigurationResult;
    S3Logs?: S3LogsConfigurationResult;
    Kubernetes?: KubernetesConfigurationResult;
    MalwareProtection?: MalwareProtectionConfigurationResult;
}
export declare const DataSourceConfigurationsResult: S.Schema<DataSourceConfigurationsResult>;
export type DetectorFeatureResult = "FLOW_LOGS" | "CLOUD_TRAIL" | "DNS_LOGS" | "S3_DATA_EVENTS" | "EKS_AUDIT_LOGS" | "EBS_MALWARE_PROTECTION" | "RDS_LOGIN_EVENTS" | "LAMBDA_NETWORK_LOGS" | "EKS_RUNTIME_MONITORING" | "RUNTIME_MONITORING" | "AI_PROTECTION" | "AI_ANALYST" | (string & {});
export declare const DetectorFeatureResult: any;
export interface DetectorAdditionalConfigurationResult {
    Name?: FeatureAdditionalConfiguration;
    Status?: FeatureStatus;
    UpdatedAt?: Date;
}
export declare const DetectorAdditionalConfigurationResult: S.Schema<DetectorAdditionalConfigurationResult>;
export type DetectorAdditionalConfigurationResults = DetectorAdditionalConfigurationResult[];
export declare const DetectorAdditionalConfigurationResults: any;
export interface DetectorFeatureConfigurationResult {
    Name?: DetectorFeatureResult;
    Status?: FeatureStatus;
    UpdatedAt?: Date;
    AdditionalConfiguration?: DetectorAdditionalConfigurationResult[];
}
export declare const DetectorFeatureConfigurationResult: S.Schema<DetectorFeatureConfigurationResult>;
export type DetectorFeatureConfigurationsResults = DetectorFeatureConfigurationResult[];
export declare const DetectorFeatureConfigurationsResults: any;
export interface GetDetectorResponse {
    CreatedAt?: string;
    FindingPublishingFrequency?: FindingPublishingFrequency;
    ServiceRole: string;
    Status: DetectorStatus;
    UpdatedAt?: string;
    DataSources?: DataSourceConfigurationsResult & {
        CloudTrail: CloudTrailConfigurationResult & {
            Status: DataSourceStatus;
        };
        DNSLogs: DNSLogsConfigurationResult & {
            Status: DataSourceStatus;
        };
        FlowLogs: FlowLogsConfigurationResult & {
            Status: DataSourceStatus;
        };
        S3Logs: S3LogsConfigurationResult & {
            Status: DataSourceStatus;
        };
        Kubernetes: KubernetesConfigurationResult & {
            AuditLogs: KubernetesAuditLogsConfigurationResult & {
                Status: DataSourceStatus;
            };
        };
    };
    Tags?: {
        [key: string]: string | undefined;
    };
    Features?: DetectorFeatureConfigurationResult[];
}
export declare const GetDetectorResponse: S.Schema<GetDetectorResponse>;
export interface GetFilterRequest {
    DetectorId: string;
    FilterName: string;
}
export declare const GetFilterRequest: S.Schema<GetFilterRequest>;
export type FilterVersion = number;
export interface GetFilterResponse {
    Name: string;
    Description?: string;
    Action: FilterAction;
    Rank?: number;
    FindingCriteria: FindingCriteria;
    Tags?: {
        [key: string]: string | undefined;
    };
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Version?: number;
}
export declare const GetFilterResponse: S.Schema<GetFilterResponse>;
export interface GetFindingsRequest {
    DetectorId: string;
    FindingIds?: string[];
    SortCriteria?: SortCriteria;
}
export declare const GetFindingsRequest: S.Schema<GetFindingsRequest>;
export interface AccessKeyDetails {
    AccessKeyId?: string;
    PrincipalId?: string;
    UserName?: string;
    UserType?: string;
}
export declare const AccessKeyDetails: S.Schema<AccessKeyDetails>;
export interface Owner {
    Id?: string;
}
export declare const Owner: S.Schema<Owner>;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export interface DefaultServerSideEncryption {
    EncryptionType?: string;
    KmsMasterKeyArn?: string;
}
export declare const DefaultServerSideEncryption: S.Schema<DefaultServerSideEncryption>;
export interface AccessControlList {
    AllowsPublicReadAccess?: boolean;
    AllowsPublicWriteAccess?: boolean;
}
export declare const AccessControlList: S.Schema<AccessControlList>;
export interface BucketPolicy {
    AllowsPublicReadAccess?: boolean;
    AllowsPublicWriteAccess?: boolean;
}
export declare const BucketPolicy: S.Schema<BucketPolicy>;
export interface BlockPublicAccess {
    IgnorePublicAcls?: boolean;
    RestrictPublicBuckets?: boolean;
    BlockPublicAcls?: boolean;
    BlockPublicPolicy?: boolean;
}
export declare const BlockPublicAccess: S.Schema<BlockPublicAccess>;
export interface BucketLevelPermissions {
    AccessControlList?: AccessControlList;
    BucketPolicy?: BucketPolicy;
    BlockPublicAccess?: BlockPublicAccess;
}
export declare const BucketLevelPermissions: S.Schema<BucketLevelPermissions>;
export interface AccountLevelPermissions {
    BlockPublicAccess?: BlockPublicAccess;
}
export declare const AccountLevelPermissions: S.Schema<AccountLevelPermissions>;
export interface PermissionConfiguration {
    BucketLevelPermissions?: BucketLevelPermissions;
    AccountLevelPermissions?: AccountLevelPermissions;
}
export declare const PermissionConfiguration: S.Schema<PermissionConfiguration>;
export interface PublicAccess {
    PermissionConfiguration?: PermissionConfiguration;
    EffectivePermission?: string;
}
export declare const PublicAccess: S.Schema<PublicAccess>;
export interface S3ObjectDetail {
    ObjectArn?: string;
    Key?: string;
    ETag?: string;
    Hash?: string;
    VersionId?: string;
}
export declare const S3ObjectDetail: S.Schema<S3ObjectDetail>;
export type S3ObjectDetails = S3ObjectDetail[];
export declare const S3ObjectDetails: any;
export interface S3BucketDetail {
    Arn?: string;
    Name?: string;
    Type?: string;
    CreatedAt?: Date;
    Owner?: Owner;
    Tags?: Tag[];
    DefaultServerSideEncryption?: DefaultServerSideEncryption;
    PublicAccess?: PublicAccess;
    S3ObjectDetails?: S3ObjectDetail[];
}
export declare const S3BucketDetail: S.Schema<S3BucketDetail>;
export type S3BucketDetails = S3BucketDetail[];
export declare const S3BucketDetails: any;
export interface IamInstanceProfile {
    Arn?: string;
    Id?: string;
}
export declare const IamInstanceProfile: S.Schema<IamInstanceProfile>;
export type Ipv6Addresses = string[];
export declare const Ipv6Addresses: any;
export type SensitiveString = string | redacted.Redacted<string>;
export interface PrivateIpAddressDetails {
    PrivateDnsName?: string;
    PrivateIpAddress?: string | redacted.Redacted<string>;
}
export declare const PrivateIpAddressDetails: S.Schema<PrivateIpAddressDetails>;
export type PrivateIpAddresses = PrivateIpAddressDetails[];
export declare const PrivateIpAddresses: any;
export interface SecurityGroup {
    GroupId?: string;
    GroupName?: string;
}
export declare const SecurityGroup: S.Schema<SecurityGroup>;
export type SecurityGroups = SecurityGroup[];
export declare const SecurityGroups: any;
export interface NetworkInterface {
    Ipv6Addresses?: string[];
    NetworkInterfaceId?: string;
    PrivateDnsName?: string;
    PrivateIpAddress?: string | redacted.Redacted<string>;
    PrivateIpAddresses?: PrivateIpAddressDetails[];
    PublicDnsName?: string;
    PublicIp?: string;
    SecurityGroups?: SecurityGroup[];
    SubnetId?: string;
    VpcId?: string;
}
export declare const NetworkInterface: S.Schema<NetworkInterface>;
export type NetworkInterfaces = NetworkInterface[];
export declare const NetworkInterfaces: any;
export interface ProductCode {
    Code?: string;
    ProductType?: string;
}
export declare const ProductCode: S.Schema<ProductCode>;
export type ProductCodes = ProductCode[];
export declare const ProductCodes: any;
export interface InstanceDetails {
    AvailabilityZone?: string;
    IamInstanceProfile?: IamInstanceProfile;
    ImageDescription?: string;
    ImageId?: string;
    InstanceId?: string;
    InstanceState?: string;
    InstanceType?: string;
    OutpostArn?: string;
    LaunchTime?: string;
    NetworkInterfaces?: NetworkInterface[];
    Platform?: string;
    ProductCodes?: ProductCode[];
    Tags?: Tag[];
}
export declare const InstanceDetails: S.Schema<InstanceDetails>;
export interface EksClusterDetails {
    Name?: string;
    Arn?: string;
    VpcId?: string;
    Status?: string;
    Tags?: Tag[];
    CreatedAt?: Date;
}
export declare const EksClusterDetails: S.Schema<EksClusterDetails>;
export type Groups = string[];
export declare const Groups: any;
export type SessionNameList = string[];
export declare const SessionNameList: any;
export interface ImpersonatedUser {
    Username?: string;
    Groups?: string[];
}
export declare const ImpersonatedUser: S.Schema<ImpersonatedUser>;
export interface KubernetesUserDetails {
    Username?: string;
    Uid?: string;
    Groups?: string[];
    SessionName?: string[];
    ImpersonatedUser?: ImpersonatedUser;
}
export declare const KubernetesUserDetails: S.Schema<KubernetesUserDetails>;
export interface VolumeMount {
    Name?: string;
    MountPath?: string;
}
export declare const VolumeMount: S.Schema<VolumeMount>;
export type VolumeMounts = VolumeMount[];
export declare const VolumeMounts: any;
export interface SecurityContext {
    Privileged?: boolean;
    AllowPrivilegeEscalation?: boolean;
}
export declare const SecurityContext: S.Schema<SecurityContext>;
export interface Container {
    ContainerRuntime?: string;
    Id?: string;
    Name?: string;
    Image?: string;
    ImagePrefix?: string;
    VolumeMounts?: VolumeMount[];
    SecurityContext?: SecurityContext;
}
export declare const Container: S.Schema<Container>;
export type Containers = Container[];
export declare const Containers: any;
export interface HostPath {
    Path?: string;
}
export declare const HostPath: S.Schema<HostPath>;
export interface Volume {
    Name?: string;
    HostPath?: HostPath;
}
export declare const Volume: S.Schema<Volume>;
export type Volumes = Volume[];
export declare const Volumes: any;
export interface KubernetesWorkloadDetails {
    Name?: string;
    Type?: string;
    Uid?: string;
    Namespace?: string;
    HostNetwork?: boolean;
    ServiceAccountName?: string;
    Containers?: Container[];
    Volumes?: Volume[];
    HostIPC?: boolean;
    HostPID?: boolean;
}
export declare const KubernetesWorkloadDetails: S.Schema<KubernetesWorkloadDetails>;
export interface KubernetesDetails {
    KubernetesUserDetails?: KubernetesUserDetails;
    KubernetesWorkloadDetails?: KubernetesWorkloadDetails;
}
export declare const KubernetesDetails: S.Schema<KubernetesDetails>;
export interface EbsVolumeDetails {
    ScannedVolumeDetails?: VolumeDetail[];
    SkippedVolumeDetails?: VolumeDetail[];
}
export declare const EbsVolumeDetails: S.Schema<EbsVolumeDetails>;
export interface EcsTaskDetails {
    Arn?: string;
    DefinitionArn?: string;
    Version?: string;
    TaskCreatedAt?: Date;
    StartedAt?: Date;
    StartedBy?: string;
    Tags?: Tag[];
    Volumes?: Volume[];
    Containers?: Container[];
    Group?: string;
    LaunchType?: string;
}
export declare const EcsTaskDetails: S.Schema<EcsTaskDetails>;
export interface EcsClusterDetails {
    Name?: string;
    Arn?: string;
    Status?: string;
    ActiveServicesCount?: number;
    RegisteredContainerInstancesCount?: number;
    RunningTasksCount?: number;
    Tags?: Tag[];
    TaskDetails?: EcsTaskDetails;
}
export declare const EcsClusterDetails: S.Schema<EcsClusterDetails>;
export type SubnetIds = string[];
export declare const SubnetIds: any;
export interface VpcConfig {
    SubnetIds?: string[];
    VpcId?: string;
    SecurityGroups?: SecurityGroup[];
}
export declare const VpcConfig: S.Schema<VpcConfig>;
export interface LambdaDetails {
    FunctionArn?: string;
    FunctionName?: string;
    Description?: string;
    LastModifiedAt?: Date;
    RevisionId?: string;
    FunctionVersion?: string;
    Role?: string;
    VpcConfig?: VpcConfig;
    Tags?: Tag[];
}
export declare const LambdaDetails: S.Schema<LambdaDetails>;
export interface RdsDbInstanceDetails {
    DbInstanceIdentifier?: string;
    Engine?: string;
    EngineVersion?: string;
    DbClusterIdentifier?: string;
    DbInstanceArn?: string;
    DbiResourceId?: string;
    Tags?: Tag[];
}
export declare const RdsDbInstanceDetails: S.Schema<RdsDbInstanceDetails>;
export interface RdsLimitlessDbDetails {
    DbShardGroupIdentifier?: string;
    DbShardGroupResourceId?: string;
    DbShardGroupArn?: string;
    Engine?: string;
    EngineVersion?: string;
    DbClusterIdentifier?: string;
    Tags?: Tag[];
}
export declare const RdsLimitlessDbDetails: S.Schema<RdsLimitlessDbDetails>;
export interface RdsDbUserDetails {
    User?: string;
    Application?: string;
    Database?: string;
    Ssl?: string;
    AuthMethod?: string;
}
export declare const RdsDbUserDetails: S.Schema<RdsDbUserDetails>;
export interface EbsSnapshotDetails {
    SnapshotArn?: string;
}
export declare const EbsSnapshotDetails: S.Schema<EbsSnapshotDetails>;
export interface Ec2ImageDetails {
    ImageArn?: string;
}
export declare const Ec2ImageDetails: S.Schema<Ec2ImageDetails>;
export interface ScanConfigurationContinuousScanDetails {
    StartTime?: Date;
    EndTime: Date;
}
export declare const ScanConfigurationContinuousScanDetails: S.Schema<ScanConfigurationContinuousScanDetails>;
export interface RecoveryPointDetails {
    RecoveryPointArn?: string;
    BackupVaultName?: string;
    ContinuousScanDetails?: ScanConfigurationContinuousScanDetails;
}
export declare const RecoveryPointDetails: S.Schema<RecoveryPointDetails>;
export interface BedrockGuardrail {
    Arn?: string;
    Version?: string;
}
export declare const BedrockGuardrail: S.Schema<BedrockGuardrail>;
export type BedrockGuardrails = BedrockGuardrail[];
export declare const BedrockGuardrails: any;
export type GuardrailAction = "GUARDRAIL_INTERVENED" | "NONE" | (string & {});
export declare const GuardrailAction: any;
export type GuardrailSource = "INPUT" | "OUTPUT" | (string & {});
export declare const GuardrailSource: any;
export type ContentPolicyFilterType = "PROMPT_ATTACK" | "JAILBREAK" | "HATE" | "INSULTS" | "SEXUAL" | "VIOLENCE" | "MISCONDUCT" | (string & {});
export declare const ContentPolicyFilterType: any;
export type ConfidenceLevel = "HIGH" | "MEDIUM" | "LOW" | "NONE" | (string & {});
export declare const ConfidenceLevel: any;
export type ContentPolicyFilterAction = "BLOCKED" | "NONE" | (string & {});
export declare const ContentPolicyFilterAction: any;
export interface ContentPolicyFilter {
    Type?: ContentPolicyFilterType;
    Confidence?: ConfidenceLevel;
    Action?: ContentPolicyFilterAction;
}
export declare const ContentPolicyFilter: S.Schema<ContentPolicyFilter>;
export type ContentPolicyFilters = ContentPolicyFilter[];
export declare const ContentPolicyFilters: any;
export interface BedrockGuardrailDetails {
    GuardrailArn?: string;
    GuardrailVersion?: string;
    Guardrails?: BedrockGuardrail[];
    GuardrailAction?: GuardrailAction;
    GuardrailSource?: GuardrailSource;
    ContentPolicyFilters?: ContentPolicyFilter[];
}
export declare const BedrockGuardrailDetails: S.Schema<BedrockGuardrailDetails>;
export interface ModelDetail {
    ModelId?: string;
}
export declare const ModelDetail: S.Schema<ModelDetail>;
export type ModelDetails = ModelDetail[];
export declare const ModelDetails: any;
export interface Resource {
    AccessKeyDetails?: AccessKeyDetails;
    S3BucketDetails?: S3BucketDetail[];
    InstanceDetails?: InstanceDetails;
    EksClusterDetails?: EksClusterDetails;
    KubernetesDetails?: KubernetesDetails;
    ResourceType?: string;
    EbsVolumeDetails?: EbsVolumeDetails;
    EcsClusterDetails?: EcsClusterDetails;
    ContainerDetails?: Container;
    LambdaDetails?: LambdaDetails;
    RdsDbInstanceDetails?: RdsDbInstanceDetails;
    RdsLimitlessDbDetails?: RdsLimitlessDbDetails;
    RdsDbUserDetails?: RdsDbUserDetails;
    EbsSnapshotDetails?: EbsSnapshotDetails;
    Ec2ImageDetails?: Ec2ImageDetails;
    RecoveryPointDetails?: RecoveryPointDetails;
    BedrockGuardrailDetails?: BedrockGuardrailDetails;
    ModelDetails?: ModelDetail[];
}
export declare const Resource: S.Schema<Resource>;
export interface DomainDetails {
    Domain?: string;
}
export declare const DomainDetails: S.Schema<DomainDetails>;
export interface City {
    CityName?: string;
}
export declare const City: S.Schema<City>;
export interface Country {
    CountryCode?: string;
    CountryName?: string;
}
export declare const Country: S.Schema<Country>;
export interface GeoLocation {
    Lat?: number;
    Lon?: number;
}
export declare const GeoLocation: S.Schema<GeoLocation>;
export interface Organization {
    Asn?: string;
    AsnOrg?: string;
    Isp?: string;
    Org?: string;
}
export declare const Organization: S.Schema<Organization>;
export interface RemoteIpDetails {
    City?: City;
    Country?: Country;
    GeoLocation?: GeoLocation;
    IpAddressV4?: string | redacted.Redacted<string>;
    IpAddressV6?: string | redacted.Redacted<string>;
    Organization?: Organization;
}
export declare const RemoteIpDetails: S.Schema<RemoteIpDetails>;
export interface RemoteAccountDetails {
    AccountId?: string;
    Affiliated?: boolean;
}
export declare const RemoteAccountDetails: S.Schema<RemoteAccountDetails>;
export type AffectedResources = {
    [key: string]: string | undefined;
};
export declare const AffectedResources: any;
export interface AwsApiCallAction {
    Api?: string;
    CallerType?: string;
    DomainDetails?: DomainDetails;
    ErrorCode?: string;
    UserAgent?: string;
    RemoteIpDetails?: RemoteIpDetails;
    ServiceName?: string;
    RemoteAccountDetails?: RemoteAccountDetails;
    AffectedResources?: {
        [key: string]: string | undefined;
    };
}
export declare const AwsApiCallAction: S.Schema<AwsApiCallAction>;
export interface DnsRequestAction {
    Domain?: string;
    Protocol?: string;
    Blocked?: boolean;
    DomainWithSuffix?: string;
    VpcOwnerAccountId?: string;
}
export declare const DnsRequestAction: S.Schema<DnsRequestAction>;
export interface LocalPortDetails {
    Port?: number;
    PortName?: string;
}
export declare const LocalPortDetails: S.Schema<LocalPortDetails>;
export interface LocalIpDetails {
    IpAddressV4?: string | redacted.Redacted<string>;
    IpAddressV6?: string | redacted.Redacted<string>;
}
export declare const LocalIpDetails: S.Schema<LocalIpDetails>;
export interface RemotePortDetails {
    Port?: number;
    PortName?: string;
}
export declare const RemotePortDetails: S.Schema<RemotePortDetails>;
export interface NetworkConnectionAction {
    Blocked?: boolean;
    ConnectionDirection?: string;
    LocalPortDetails?: LocalPortDetails;
    Protocol?: string;
    LocalIpDetails?: LocalIpDetails;
    LocalNetworkInterface?: string;
    RemoteIpDetails?: RemoteIpDetails;
    RemotePortDetails?: RemotePortDetails;
}
export declare const NetworkConnectionAction: S.Schema<NetworkConnectionAction>;
export interface PortProbeDetail {
    LocalPortDetails?: LocalPortDetails;
    LocalIpDetails?: LocalIpDetails;
    RemoteIpDetails?: RemoteIpDetails;
}
export declare const PortProbeDetail: S.Schema<PortProbeDetail>;
export type PortProbeDetails = PortProbeDetail[];
export declare const PortProbeDetails: any;
export interface PortProbeAction {
    Blocked?: boolean;
    PortProbeDetails?: PortProbeDetail[];
}
export declare const PortProbeAction: S.Schema<PortProbeAction>;
export type SourceIps = string[];
export declare const SourceIps: any;
export interface KubernetesApiCallAction {
    RequestUri?: string;
    Verb?: string;
    Resource?: string;
    Subresource?: string;
    Namespace?: string;
    ResourceName?: string;
    SourceIps?: string[];
    UserAgent?: string;
    RemoteIpDetails?: RemoteIpDetails;
    StatusCode?: number;
    Parameters?: string;
}
export declare const KubernetesApiCallAction: S.Schema<KubernetesApiCallAction>;
export interface KubernetesPermissionCheckedDetails {
    Verb?: string;
    Resource?: string;
    Namespace?: string;
    Allowed?: boolean;
}
export declare const KubernetesPermissionCheckedDetails: S.Schema<KubernetesPermissionCheckedDetails>;
export interface KubernetesRoleBindingDetails {
    Kind?: string;
    Name?: string;
    Uid?: string;
    RoleRefName?: string;
    RoleRefKind?: string;
}
export declare const KubernetesRoleBindingDetails: S.Schema<KubernetesRoleBindingDetails>;
export interface KubernetesRoleDetails {
    Kind?: string;
    Name?: string;
    Uid?: string;
}
export declare const KubernetesRoleDetails: S.Schema<KubernetesRoleDetails>;
export interface LoginAttribute {
    User?: string;
    Application?: string;
    FailedLoginAttempts?: number;
    SuccessfulLoginAttempts?: number;
}
export declare const LoginAttribute: S.Schema<LoginAttribute>;
export type LoginAttributes = LoginAttribute[];
export declare const LoginAttributes: any;
export interface RdsLoginAttemptAction {
    RemoteIpDetails?: RemoteIpDetails;
    LoginAttributes?: LoginAttribute[];
}
export declare const RdsLoginAttemptAction: S.Schema<RdsLoginAttemptAction>;
export interface Action {
    ActionType?: string;
    AwsApiCallAction?: AwsApiCallAction;
    DnsRequestAction?: DnsRequestAction;
    NetworkConnectionAction?: NetworkConnectionAction;
    PortProbeAction?: PortProbeAction;
    KubernetesApiCallAction?: KubernetesApiCallAction;
    KubernetesPermissionCheckedDetails?: KubernetesPermissionCheckedDetails;
    KubernetesRoleBindingDetails?: KubernetesRoleBindingDetails;
    KubernetesRoleDetails?: KubernetesRoleDetails;
    RdsLoginAttemptAction?: RdsLoginAttemptAction;
}
export declare const Action: S.Schema<Action>;
export type ThreatNames = string[];
export declare const ThreatNames: any;
export interface ThreatIntelligenceDetail {
    ThreatListName?: string;
    ThreatNames?: string[];
    ThreatFileSha256?: string;
}
export declare const ThreatIntelligenceDetail: S.Schema<ThreatIntelligenceDetail>;
export type ThreatIntelligenceDetails = ThreatIntelligenceDetail[];
export declare const ThreatIntelligenceDetails: any;
export interface Evidence {
    ThreatIntelligenceDetails?: ThreatIntelligenceDetail[];
}
export declare const Evidence: S.Schema<Evidence>;
export interface ServiceAdditionalInfo {
    Value?: string;
    Type?: string;
}
export declare const ServiceAdditionalInfo: S.Schema<ServiceAdditionalInfo>;
export type Sources = string[];
export declare const Sources: any;
export interface ScannedItemCount {
    TotalGb?: number;
    Files?: number;
    Volumes?: number;
}
export declare const ScannedItemCount: S.Schema<ScannedItemCount>;
export interface ThreatsDetectedItemCount {
    Files?: number;
}
export declare const ThreatsDetectedItemCount: S.Schema<ThreatsDetectedItemCount>;
export interface HighestSeverityThreatDetails {
    Severity?: string;
    ThreatName?: string;
    Count?: number;
}
export declare const HighestSeverityThreatDetails: S.Schema<HighestSeverityThreatDetails>;
export interface ScanFilePath {
    FilePath?: string;
    VolumeArn?: string;
    Hash?: string;
    FileName?: string;
}
export declare const ScanFilePath: S.Schema<ScanFilePath>;
export type FilePaths = ScanFilePath[];
export declare const FilePaths: any;
export interface ScanThreatName {
    Name?: string;
    Severity?: string;
    ItemCount?: number;
    FilePaths?: ScanFilePath[];
}
export declare const ScanThreatName: S.Schema<ScanThreatName>;
export type ScanThreatNames = ScanThreatName[];
export declare const ScanThreatNames: any;
export interface ThreatDetectedByName {
    ItemCount?: number;
    UniqueThreatNameCount?: number;
    Shortened?: boolean;
    ThreatNames?: ScanThreatName[];
}
export declare const ThreatDetectedByName: S.Schema<ThreatDetectedByName>;
export interface ScanDetections {
    ScannedItemCount?: ScannedItemCount;
    ThreatsDetectedItemCount?: ThreatsDetectedItemCount;
    HighestSeverityThreatDetails?: HighestSeverityThreatDetails;
    ThreatDetectedByName?: ThreatDetectedByName;
}
export declare const ScanDetections: S.Schema<ScanDetections>;
export interface EbsVolumeScanDetails {
    ScanId?: string;
    ScanStartedAt?: Date;
    ScanCompletedAt?: Date;
    TriggerFindingId?: string;
    Sources?: string[];
    ScanDetections?: ScanDetections;
    ScanType?: ScanType;
}
export declare const EbsVolumeScanDetails: S.Schema<EbsVolumeScanDetails>;
export interface LineageObject {
    StartTime?: Date;
    NamespacePid?: number;
    UserId?: number;
    Name?: string;
    Pid?: number;
    Uuid?: string;
    ExecutablePath?: string;
    Euid?: number;
    ParentUuid?: string;
}
export declare const LineageObject: S.Schema<LineageObject>;
export type Lineage = LineageObject[];
export declare const Lineage: any;
export interface ProcessDetails {
    Name?: string;
    ExecutablePath?: string;
    ExecutableSha256?: string;
    NamespacePid?: number;
    Pwd?: string;
    Pid?: number;
    StartTime?: Date;
    Uuid?: string;
    ParentUuid?: string;
    User?: string;
    UserId?: number;
    Euid?: number;
    Lineage?: LineageObject[];
}
export declare const ProcessDetails: S.Schema<ProcessDetails>;
export type FlagsList = string[];
export declare const FlagsList: any;
export type MemoryRegionsList = string[];
export declare const MemoryRegionsList: any;
export type RelatedFilePathsList = string[];
export declare const RelatedFilePathsList: any;
export interface RuntimeContext {
    ModifyingProcess?: ProcessDetails;
    ModifiedAt?: Date;
    ScriptPath?: string;
    LibraryPath?: string;
    LdPreloadValue?: string;
    SocketPath?: string;
    RuncBinaryPath?: string;
    ReleaseAgentPath?: string;
    MountSource?: string;
    MountTarget?: string;
    FileSystemType?: string;
    Flags?: string[];
    ModuleName?: string;
    ModuleFilePath?: string;
    ModuleSha256?: string;
    ShellHistoryFilePath?: string;
    TargetProcess?: ProcessDetails;
    AddressFamily?: string;
    IanaProtocolNumber?: number;
    MemoryRegions?: string[];
    ToolName?: string;
    ToolCategory?: string;
    ServiceName?: string;
    CommandLineExample?: string;
    ThreatFilePath?: string;
    FileOperation?: string;
    FilePath?: string;
    RelatedFilePaths?: string[];
}
export declare const RuntimeContext: S.Schema<RuntimeContext>;
export interface RuntimeDetails {
    Process?: ProcessDetails;
    Context?: RuntimeContext;
}
export declare const RuntimeDetails: S.Schema<RuntimeDetails>;
export type ProfileType = "FREQUENCY" | "VOLUME" | (string & {});
export declare const ProfileType: any;
export type ProfileSubtype = "FREQUENT" | "INFREQUENT" | "UNSEEN" | "RARE" | "COUNT" | "AVERAGE" | (string & {});
export declare const ProfileSubtype: any;
export type ObservationTexts = string[];
export declare const ObservationTexts: any;
export type ObservationNumbers = number[];
export declare const ObservationNumbers: any;
export interface Observations {
    Text?: string[];
    Number?: number[];
}
export declare const Observations: S.Schema<Observations>;
export interface AnomalyObject {
    ProfileType?: ProfileType;
    ProfileSubtype?: ProfileSubtype;
    Observations?: Observations;
}
export declare const AnomalyObject: S.Schema<AnomalyObject>;
export type AnomalyProfileFeatureObjects = AnomalyObject[];
export declare const AnomalyProfileFeatureObjects: any;
export type AnomalyProfileFeatures = {
    [key: string]: AnomalyObject[] | undefined;
};
export declare const AnomalyProfileFeatures: any;
export type AnomalyProfiles = {
    [key: string]: {
        [key: string]: AnomalyObject[] | undefined;
    } | undefined;
};
export declare const AnomalyProfiles: any;
export type AnomalyUnusualBehaviorFeature = {
    [key: string]: AnomalyObject | undefined;
};
export declare const AnomalyUnusualBehaviorFeature: any;
export type Behavior = {
    [key: string]: {
        [key: string]: AnomalyObject | undefined;
    } | undefined;
};
export declare const Behavior: any;
export interface AnomalyUnusual {
    Behavior?: {
        [key: string]: {
            [key: string]: AnomalyObject | undefined;
        } | undefined;
    };
}
export declare const AnomalyUnusual: S.Schema<AnomalyUnusual>;
export interface Anomaly {
    Profiles?: {
        [key: string]: {
            [key: string]: AnomalyObject[] | undefined;
        } | undefined;
    };
    Unusual?: AnomalyUnusual;
}
export declare const Anomaly: S.Schema<Anomaly>;
export type SequenceDescription = string;
export interface Account {
    Uid?: string;
    Name?: string;
}
export declare const Account: S.Schema<Account>;
export interface User {
    Name?: string;
    Uid?: string;
    Type?: string;
    CredentialUid?: string;
    Account?: Account;
}
export declare const User: S.Schema<User>;
export type MfaStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const MfaStatus: any;
export interface Session {
    Uid?: string;
    MfaStatus?: MfaStatus;
    CreatedTime?: Date;
    Issuer?: string;
}
export declare const Session: S.Schema<Session>;
export type ProcessName = string;
export type ProcessPath = string;
export type ProcessSha256 = string;
export interface ActorProcess {
    Name?: string;
    Path?: string;
    Sha256?: string;
}
export declare const ActorProcess: S.Schema<ActorProcess>;
export interface Actor {
    Id?: string;
    User?: User;
    Session?: Session;
    Process?: ActorProcess;
}
export declare const Actor: S.Schema<Actor>;
export type Actors = Actor[];
export declare const Actors: any;
export type FindingResourceType = "EC2_INSTANCE" | "EC2_NETWORK_INTERFACE" | "S3_BUCKET" | "S3_OBJECT" | "ACCESS_KEY" | "EKS_CLUSTER" | "KUBERNETES_WORKLOAD" | "CONTAINER" | "ECS_CLUSTER" | "ECS_TASK" | "AUTOSCALING_AUTO_SCALING_GROUP" | "IAM_INSTANCE_PROFILE" | "CLOUDFORMATION_STACK" | "EC2_LAUNCH_TEMPLATE" | "EC2_VPC" | "EC2_IMAGE" | (string & {});
export declare const FindingResourceType: any;
export type PublicAccessStatus = "BLOCKED" | "ALLOWED" | (string & {});
export declare const PublicAccessStatus: any;
export type PublicAclIgnoreBehavior = "IGNORED" | "NOT_IGNORED" | (string & {});
export declare const PublicAclIgnoreBehavior: any;
export type PublicBucketRestrictBehavior = "RESTRICTED" | "NOT_RESTRICTED" | (string & {});
export declare const PublicBucketRestrictBehavior: any;
export interface PublicAccessConfiguration {
    PublicAclAccess?: PublicAccessStatus;
    PublicPolicyAccess?: PublicAccessStatus;
    PublicAclIgnoreBehavior?: PublicAclIgnoreBehavior;
    PublicBucketRestrictBehavior?: PublicBucketRestrictBehavior;
}
export declare const PublicAccessConfiguration: S.Schema<PublicAccessConfiguration>;
export type S3ObjectUids = string[];
export declare const S3ObjectUids: any;
export interface S3Bucket {
    OwnerId?: string;
    CreatedAt?: Date;
    EncryptionType?: string;
    EncryptionKeyArn?: string;
    EffectivePermission?: string;
    PublicReadAccess?: PublicAccessStatus;
    PublicWriteAccess?: PublicAccessStatus;
    AccountPublicAccess?: PublicAccessConfiguration;
    BucketPublicAccess?: PublicAccessConfiguration;
    S3ObjectUids?: string[];
}
export declare const S3Bucket: S.Schema<S3Bucket>;
export type Ec2NetworkInterfaceUids = string[];
export declare const Ec2NetworkInterfaceUids: any;
export interface Ec2Instance {
    AvailabilityZone?: string;
    ImageDescription?: string;
    InstanceState?: string;
    IamInstanceProfile?: IamInstanceProfile;
    InstanceType?: string;
    OutpostArn?: string;
    Platform?: string;
    ProductCodes?: ProductCode[];
    Ec2NetworkInterfaceUids?: string[];
}
export declare const Ec2Instance: S.Schema<Ec2Instance>;
export interface AccessKey {
    PrincipalId?: string;
    UserName?: string;
    UserType?: string;
}
export declare const AccessKey: S.Schema<AccessKey>;
export interface Ec2NetworkInterface {
    Ipv6Addresses?: string[];
    PrivateIpAddresses?: PrivateIpAddressDetails[];
    PublicIp?: string;
    SecurityGroups?: SecurityGroup[];
    SubNetId?: string;
    VpcId?: string;
}
export declare const Ec2NetworkInterface: S.Schema<Ec2NetworkInterface>;
export interface S3Object {
    ETag?: string;
    Key?: string;
    VersionId?: string;
}
export declare const S3Object: S.Schema<S3Object>;
export type ClusterStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | "UPDATING" | "PENDING" | (string & {});
export declare const ClusterStatus: any;
export type Ec2InstanceUid = string;
export type Ec2InstanceUids = string[];
export declare const Ec2InstanceUids: any;
export interface EksCluster {
    Arn?: string;
    CreatedAt?: Date;
    Status?: ClusterStatus;
    VpcId?: string;
    Ec2InstanceUids?: string[];
}
export declare const EksCluster: S.Schema<EksCluster>;
export type ContainerUid = string;
export type ContainerUids = string[];
export declare const ContainerUids: any;
export type KubernetesResourcesTypes = "PODS" | "JOBS" | "CRONJOBS" | "DEPLOYMENTS" | "DAEMONSETS" | "STATEFULSETS" | "REPLICASETS" | "REPLICATIONCONTROLLERS" | (string & {});
export declare const KubernetesResourcesTypes: any;
export interface KubernetesWorkload {
    ContainerUids?: string[];
    Namespace?: string;
    KubernetesResourcesTypes?: KubernetesResourcesTypes;
}
export declare const KubernetesWorkload: S.Schema<KubernetesWorkload>;
export type ContainerImageUid = string;
export interface ContainerFindingResource {
    Image?: string;
    ImageUid?: string;
}
export declare const ContainerFindingResource: S.Schema<ContainerFindingResource>;
export type EcsClusterStatus = "ACTIVE" | "PROVISIONING" | "DEPROVISIONING" | "FAILED" | "INACTIVE" | (string & {});
export declare const EcsClusterStatus: any;
export interface EcsCluster {
    Status?: EcsClusterStatus;
    Ec2InstanceUids?: string[];
}
export declare const EcsCluster: S.Schema<EcsCluster>;
export type EcsLaunchType = "FARGATE" | "EC2" | (string & {});
export declare const EcsLaunchType: any;
export interface EcsTask {
    CreatedAt?: Date;
    TaskDefinitionArn?: string;
    LaunchType?: EcsLaunchType;
    ContainerUids?: string[];
}
export declare const EcsTask: S.Schema<EcsTask>;
export interface IamInstanceProfileV2 {
    Ec2InstanceUids?: string[];
}
export declare const IamInstanceProfileV2: S.Schema<IamInstanceProfileV2>;
export interface AutoscalingAutoScalingGroup {
    Ec2InstanceUids?: string[];
}
export declare const AutoscalingAutoScalingGroup: S.Schema<AutoscalingAutoScalingGroup>;
export type LaunchTemplateVersion = string;
export interface Ec2LaunchTemplate {
    Ec2InstanceUids?: string[];
    Version?: string;
}
export declare const Ec2LaunchTemplate: S.Schema<Ec2LaunchTemplate>;
export interface Ec2Vpc {
    Ec2InstanceUids?: string[];
}
export declare const Ec2Vpc: S.Schema<Ec2Vpc>;
export interface Ec2Image {
    Ec2InstanceUids?: string[];
}
export declare const Ec2Image: S.Schema<Ec2Image>;
export interface CloudformationStack {
    Ec2InstanceUids?: string[];
}
export declare const CloudformationStack: S.Schema<CloudformationStack>;
export interface ResourceData {
    S3Bucket?: S3Bucket;
    Ec2Instance?: Ec2Instance;
    AccessKey?: AccessKey;
    Ec2NetworkInterface?: Ec2NetworkInterface;
    S3Object?: S3Object;
    EksCluster?: EksCluster;
    KubernetesWorkload?: KubernetesWorkload;
    Container?: ContainerFindingResource;
    EcsCluster?: EcsCluster;
    EcsTask?: EcsTask;
    IamInstanceProfile?: IamInstanceProfileV2;
    AutoscalingAutoScalingGroup?: AutoscalingAutoScalingGroup;
    Ec2LaunchTemplate?: Ec2LaunchTemplate;
    Ec2Vpc?: Ec2Vpc;
    Ec2Image?: Ec2Image;
    CloudformationStack?: CloudformationStack;
}
export declare const ResourceData: S.Schema<ResourceData>;
export interface ResourceV2 {
    Uid?: string;
    Name?: string;
    AccountId?: string;
    ResourceType?: FindingResourceType;
    Region?: string;
    Service?: string;
    CloudPartition?: string;
    Tags?: Tag[];
    Data?: ResourceData;
}
export declare const ResourceV2: S.Schema<ResourceV2>;
export type Resources = ResourceV2[];
export declare const Resources: any;
export interface NetworkGeoLocation {
    City?: string;
    Country?: string;
    Latitude?: number;
    Longitude?: number;
}
export declare const NetworkGeoLocation: S.Schema<NetworkGeoLocation>;
export interface AutonomousSystem {
    Name?: string;
    Number?: number;
}
export declare const AutonomousSystem: S.Schema<AutonomousSystem>;
export type NetworkDirection = "INBOUND" | "OUTBOUND" | (string & {});
export declare const NetworkDirection: any;
export interface NetworkConnection {
    Direction?: NetworkDirection;
}
export declare const NetworkConnection: S.Schema<NetworkConnection>;
export interface NetworkEndpoint {
    Id?: string;
    Ip?: string;
    Domain?: string;
    Port?: number;
    Location?: NetworkGeoLocation;
    AutonomousSystem?: AutonomousSystem;
    Connection?: NetworkConnection;
}
export declare const NetworkEndpoint: S.Schema<NetworkEndpoint>;
export type NetworkEndpoints = NetworkEndpoint[];
export declare const NetworkEndpoints: any;
export type SignalType = "FINDING" | "CLOUD_TRAIL" | "S3_DATA_EVENTS" | "EKS_AUDIT_LOGS" | "FLOW_LOGS" | "DNS_LOGS" | "RUNTIME_MONITORING" | (string & {});
export declare const SignalType: any;
export type SignalDescription = string;
export type ResourceUids = string[];
export declare const ResourceUids: any;
export type ActorIds = string[];
export declare const ActorIds: any;
export type EndpointIds = string[];
export declare const EndpointIds: any;
export type IndicatorType = "SUSPICIOUS_USER_AGENT" | "SUSPICIOUS_NETWORK" | "MALICIOUS_IP" | "TOR_IP" | "ATTACK_TACTIC" | "HIGH_RISK_API" | "ATTACK_TECHNIQUE" | "UNUSUAL_API_FOR_ACCOUNT" | "UNUSUAL_ASN_FOR_ACCOUNT" | "UNUSUAL_ASN_FOR_USER" | "SUSPICIOUS_PROCESS" | "MALICIOUS_DOMAIN" | "MALICIOUS_PROCESS" | "CRYPTOMINING_IP" | "CRYPTOMINING_DOMAIN" | "CRYPTOMINING_PROCESS" | "MALICIOUS_FILE" | "VULNERABILITY" | "MALICIOUS_PACKAGE" | "MISCONFIGURATION" | "REACHABILITY" | "SENSITIVE_DATA" | (string & {});
export declare const IndicatorType: any;
export type IndicatorValueString = string;
export type IndicatorValues = string[];
export declare const IndicatorValues: any;
export type IndicatorTitle = string;
export interface Indicator {
    Key?: IndicatorType;
    Values?: string[];
    Title?: string;
}
export declare const Indicator: S.Schema<Indicator>;
export type Indicators = Indicator[];
export declare const Indicators: any;
export interface Signal {
    Uid?: string;
    Type?: SignalType;
    Description?: string;
    Name?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    FirstSeenAt?: Date;
    LastSeenAt?: Date;
    Severity?: number;
    Count?: number;
    ResourceUids?: string[];
    ActorIds?: string[];
    EndpointIds?: string[];
    SignalIndicators?: Indicator[];
}
export declare const Signal: S.Schema<Signal>;
export type Signals = Signal[];
export declare const Signals: any;
export type AdditionalSequenceTypes = string[];
export declare const AdditionalSequenceTypes: any;
export interface Sequence {
    Uid?: string;
    Description?: string;
    Actors?: Actor[];
    Resources?: ResourceV2[];
    Endpoints?: NetworkEndpoint[];
    Signals?: Signal[];
    SequenceIndicators?: Indicator[];
    AdditionalSequenceTypes?: string[];
}
export declare const Sequence: S.Schema<Sequence>;
export interface Detection {
    Anomaly?: Anomaly;
    Sequence?: Sequence;
}
export declare const Detection: S.Schema<Detection>;
export interface ItemPath {
    NestedItemPath?: string;
    Hash?: string;
}
export declare const ItemPath: S.Schema<ItemPath>;
export type ItemPaths = ItemPath[];
export declare const ItemPaths: any;
export interface AdditionalInfo {
    VersionId?: string;
    DeviceName?: string;
}
export declare const AdditionalInfo: S.Schema<AdditionalInfo>;
export interface ItemDetails {
    ResourceArn?: string;
    ItemPath?: string;
    Hash?: string;
    AdditionalInfo?: AdditionalInfo;
}
export declare const ItemDetails: S.Schema<ItemDetails>;
export type ItemDetailsList = ItemDetails[];
export declare const ItemDetailsList: any;
export interface Threat {
    Name?: string;
    Source?: string;
    ItemPaths?: ItemPath[];
    Count?: number;
    Hash?: string;
    ItemDetails?: ItemDetails[];
}
export declare const Threat: S.Schema<Threat>;
export type Threats = Threat[];
export declare const Threats: any;
export type MalwareProtectionScanType = "BACKUP_INITIATED" | "ON_DEMAND" | "GUARDDUTY_INITIATED" | (string & {});
export declare const MalwareProtectionScanType: any;
export type ScanCategory = "FULL_SCAN" | "INCREMENTAL_SCAN" | (string & {});
export declare const ScanCategory: any;
export interface IncrementalScanDetails {
    BaselineResourceArn?: string;
}
export declare const IncrementalScanDetails: S.Schema<IncrementalScanDetails>;
export interface MalwareProtectionFindingsScanConfiguration {
    TriggerType?: TriggerType;
    IncrementalScanDetails?: IncrementalScanDetails;
}
export declare const MalwareProtectionFindingsScanConfiguration: S.Schema<MalwareProtectionFindingsScanConfiguration>;
export interface MalwareScanDetails {
    Threats?: Threat[];
    ScanId?: string;
    ScanType?: MalwareProtectionScanType;
    ScanCategory?: ScanCategory;
    ScanConfiguration?: MalwareProtectionFindingsScanConfiguration;
    UniqueThreatCount?: number;
}
export declare const MalwareScanDetails: S.Schema<MalwareScanDetails>;
export interface Service {
    Action?: Action;
    Evidence?: Evidence;
    Archived?: boolean;
    Count?: number;
    DetectorId?: string;
    EventFirstSeen?: string;
    EventLastSeen?: string;
    ResourceRole?: string;
    ServiceName?: string;
    UserFeedback?: string;
    AdditionalInfo?: ServiceAdditionalInfo;
    FeatureName?: string;
    EbsVolumeScanDetails?: EbsVolumeScanDetails;
    RuntimeDetails?: RuntimeDetails;
    Detection?: Detection;
    MalwareScanDetails?: MalwareScanDetails;
}
export declare const Service: S.Schema<Service>;
export interface Finding {
    AccountId?: string;
    Arn?: string;
    Confidence?: number;
    CreatedAt?: string;
    Description?: string;
    Id?: string;
    Partition?: string;
    Region?: string;
    Resource?: Resource;
    SchemaVersion?: string;
    Service?: Service;
    Severity?: number;
    Title?: string;
    Type?: string;
    UpdatedAt?: string;
    AssociatedAttackSequenceArn?: string;
}
export declare const Finding: S.Schema<Finding>;
export type Findings = Finding[];
export declare const Findings: any;
export interface GetFindingsResponse {
    Findings: (Finding & {
        AccountId: string;
        Arn: string;
        CreatedAt: string;
        Id: string;
        Region: string;
        Resource: Resource;
        SchemaVersion: string;
        Severity: number;
        Type: FindingType;
        UpdatedAt: string;
        Service: Service & {
            Detection: Detection & {
                Sequence: Sequence & {
                    Uid: string;
                    Description: SequenceDescription;
                    Signals: (Signal & {
                        Uid: string;
                        Type: SignalType;
                        Name: string;
                        CreatedAt: Date;
                        UpdatedAt: Date;
                        FirstSeenAt: Date;
                        LastSeenAt: Date;
                        Count: number;
                        SignalIndicators: (Indicator & {
                            Key: IndicatorType;
                        })[];
                    })[];
                    Actors: (Actor & {
                        Id: string;
                        User: User & {
                            Name: string;
                            Uid: string;
                            Type: string;
                            Account: Account & {
                                Uid: string;
                            };
                        };
                        Process: ActorProcess & {
                            Name: ProcessName;
                            Path: ProcessPath;
                        };
                    })[];
                    Resources: (ResourceV2 & {
                        Uid: string;
                        ResourceType: FindingResourceType;
                        Data: ResourceData & {
                            Container: ContainerFindingResource & {
                                Image: string;
                            };
                        };
                    })[];
                    Endpoints: (NetworkEndpoint & {
                        Id: string;
                        Location: NetworkGeoLocation & {
                            City: string;
                            Country: string;
                            Latitude: number;
                            Longitude: number;
                        };
                        AutonomousSystem: AutonomousSystem & {
                            Name: string;
                            Number: number;
                        };
                        Connection: NetworkConnection & {
                            Direction: NetworkDirection;
                        };
                    })[];
                    SequenceIndicators: (Indicator & {
                        Key: IndicatorType;
                    })[];
                };
            };
            MalwareScanDetails: MalwareScanDetails & {
                ScanConfiguration: MalwareProtectionFindingsScanConfiguration & {
                    IncrementalScanDetails: IncrementalScanDetails & {
                        BaselineResourceArn: NonEmptyString;
                    };
                };
            };
        };
    })[];
}
export declare const GetFindingsResponse: S.Schema<GetFindingsResponse>;
export type FindingStatisticType = "COUNT_BY_SEVERITY" | (string & {});
export declare const FindingStatisticType: any;
export type FindingStatisticTypes = FindingStatisticType[];
export declare const FindingStatisticTypes: any;
export type GroupByType = "ACCOUNT" | "DATE" | "FINDING_TYPE" | "RESOURCE" | "SEVERITY" | (string & {});
export declare const GroupByType: any;
export type MaxResults100 = number;
export interface GetFindingsStatisticsRequest {
    DetectorId: string;
    FindingStatisticTypes?: FindingStatisticType[];
    FindingCriteria?: FindingCriteria;
    GroupBy?: GroupByType;
    OrderBy?: OrderBy;
    MaxResults?: number;
}
export declare const GetFindingsStatisticsRequest: S.Schema<GetFindingsStatisticsRequest>;
export type CountBySeverity = {
    [key: string]: number | undefined;
};
export declare const CountBySeverity: any;
export interface AccountStatistics {
    AccountId?: string;
    LastGeneratedAt?: Date;
    TotalFindings?: number;
}
export declare const AccountStatistics: S.Schema<AccountStatistics>;
export type GroupedByAccount = AccountStatistics[];
export declare const GroupedByAccount: any;
export interface DateStatistics {
    Date?: Date;
    LastGeneratedAt?: Date;
    Severity?: number;
    TotalFindings?: number;
}
export declare const DateStatistics: S.Schema<DateStatistics>;
export type GroupedByDate = DateStatistics[];
export declare const GroupedByDate: any;
export interface FindingTypeStatistics {
    FindingType?: string;
    LastGeneratedAt?: Date;
    TotalFindings?: number;
}
export declare const FindingTypeStatistics: S.Schema<FindingTypeStatistics>;
export type GroupedByFindingType = FindingTypeStatistics[];
export declare const GroupedByFindingType: any;
export interface ResourceStatistics {
    AccountId?: string;
    LastGeneratedAt?: Date;
    ResourceId?: string;
    ResourceType?: string;
    TotalFindings?: number;
}
export declare const ResourceStatistics: S.Schema<ResourceStatistics>;
export type GroupedByResource = ResourceStatistics[];
export declare const GroupedByResource: any;
export interface SeverityStatistics {
    LastGeneratedAt?: Date;
    Severity?: number;
    TotalFindings?: number;
}
export declare const SeverityStatistics: S.Schema<SeverityStatistics>;
export type GroupedBySeverity = SeverityStatistics[];
export declare const GroupedBySeverity: any;
export interface FindingStatistics {
    CountBySeverity?: {
        [key: string]: number | undefined;
    };
    GroupedByAccount?: AccountStatistics[];
    GroupedByDate?: DateStatistics[];
    GroupedByFindingType?: FindingTypeStatistics[];
    GroupedByResource?: ResourceStatistics[];
    GroupedBySeverity?: SeverityStatistics[];
}
export declare const FindingStatistics: S.Schema<FindingStatistics>;
export interface GetFindingsStatisticsResponse {
    FindingStatistics: FindingStatistics;
    NextToken?: string;
}
export declare const GetFindingsStatisticsResponse: S.Schema<GetFindingsStatisticsResponse>;
export interface GetInvestigationRequest {
    DetectorId: string;
    InvestigationId: string;
}
export declare const GetInvestigationRequest: S.Schema<GetInvestigationRequest>;
export type InvestigationStatus = "RUNNING" | "COMPLETED" | "FAILED" | (string & {});
export declare const InvestigationStatus: any;
export type TriggeredBy = string;
export interface Product {
    Name?: string;
    Feature?: string;
}
export declare const Product: S.Schema<Product>;
export interface InvestigationMetadata {
    Version?: string;
    Product?: Product;
}
export declare const InvestigationMetadata: S.Schema<InvestigationMetadata>;
export type CloudProvider = "AWS" | (string & {});
export declare const CloudProvider: any;
export interface CloudDetails {
    Provider?: CloudProvider;
    Region?: string;
    Account?: string;
}
export declare const CloudDetails: S.Schema<CloudDetails>;
export type RiskLevel = "Info" | "Low" | "Medium" | "High" | "Critical" | (string & {});
export declare const RiskLevel: any;
export type RiskDetails = string;
export type Confidence = "Unknown" | "Low" | "Medium" | "High" | (string & {});
export declare const Confidence: any;
export type InvestigationErrorDetails = string;
export interface Investigation {
    InvestigationId?: string;
    Status?: InvestigationStatus;
    TriggerPrompt?: string;
    TriggeredBy?: string;
    Metadata?: InvestigationMetadata;
    Cloud?: CloudDetails;
    RiskLevel?: RiskLevel;
    Risk?: string;
    Confidence?: Confidence;
    Summary?: string;
    StartTime?: Date;
    EndTime?: Date;
    Error?: string;
}
export declare const Investigation: S.Schema<Investigation>;
export interface GetInvestigationResponse {
    Investigation: Investigation & {
        InvestigationId: InvestigationId;
        Status: InvestigationStatus;
        TriggerPrompt: TriggerPrompt;
        TriggeredBy: TriggeredBy;
        Metadata: InvestigationMetadata & {
            Version: string;
            Product: Product & {
                Name: string;
            };
        };
        Cloud: CloudDetails & {
            Provider: CloudProvider;
            Region: string;
            Account: string;
        };
    };
}
export declare const GetInvestigationResponse: S.Schema<GetInvestigationResponse>;
export interface GetInvitationsCountRequest {
}
export declare const GetInvitationsCountRequest: S.Schema<GetInvitationsCountRequest>;
export interface GetInvitationsCountResponse {
    InvitationsCount?: number;
}
export declare const GetInvitationsCountResponse: S.Schema<GetInvitationsCountResponse>;
export interface GetIPSetRequest {
    DetectorId: string;
    IpSetId?: string;
}
export declare const GetIPSetRequest: S.Schema<GetIPSetRequest>;
export type IpSetStatus = "INACTIVE" | "ACTIVATING" | "ACTIVE" | "DEACTIVATING" | "ERROR" | "DELETE_PENDING" | "DELETED" | (string & {});
export declare const IpSetStatus: any;
export interface GetIPSetResponse {
    Name: string;
    Format: IpSetFormat;
    Location: string;
    Status: IpSetStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    ExpectedBucketOwner?: string;
}
export declare const GetIPSetResponse: S.Schema<GetIPSetResponse>;
export interface GetMalwareProtectionPlanRequest {
    MalwareProtectionPlanId?: string;
}
export declare const GetMalwareProtectionPlanRequest: S.Schema<GetMalwareProtectionPlanRequest>;
export type MalwareProtectionPlanStatus = "ACTIVE" | "WARNING" | "ERROR" | (string & {});
export declare const MalwareProtectionPlanStatus: any;
export interface MalwareProtectionPlanStatusReason {
    Code?: string;
    Message?: string;
}
export declare const MalwareProtectionPlanStatusReason: S.Schema<MalwareProtectionPlanStatusReason>;
export type MalwareProtectionPlanStatusReasonsList = MalwareProtectionPlanStatusReason[];
export declare const MalwareProtectionPlanStatusReasonsList: any;
export interface GetMalwareProtectionPlanResponse {
    Arn?: string;
    Role?: string;
    ProtectedResource?: CreateProtectedResource;
    Actions?: MalwareProtectionPlanActions;
    CreatedAt?: Date;
    Status?: MalwareProtectionPlanStatus;
    StatusReasons?: MalwareProtectionPlanStatusReason[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetMalwareProtectionPlanResponse: S.Schema<GetMalwareProtectionPlanResponse>;
export interface GetMalwareScanRequest {
    ScanId?: string;
}
export declare const GetMalwareScanRequest: S.Schema<GetMalwareScanRequest>;
export type MalwareProtectionResourceType = "EBS_RECOVERY_POINT" | "EBS_SNAPSHOT" | "EBS_VOLUME" | "EC2_AMI" | "EC2_INSTANCE" | "EC2_RECOVERY_POINT" | "S3_RECOVERY_POINT" | "S3_BUCKET" | "S3_POINT_IN_TIME_RECOVERY" | (string & {});
export declare const MalwareProtectionResourceType: any;
export type NonNegativeInteger = number;
export type MalwareProtectionScanStatus = "RUNNING" | "COMPLETED" | "COMPLETED_WITH_ISSUES" | "FAILED" | "SKIPPED" | (string & {});
export declare const MalwareProtectionScanStatus: any;
export type ScanStatusReason = "ACCESS_DENIED" | "RESOURCE_NOT_FOUND" | "SNAPSHOT_SIZE_LIMIT_EXCEEDED" | "RESOURCE_UNAVAILABLE" | "INCONSISTENT_SOURCE" | "INCREMENTAL_NO_DIFFERENCE" | "NO_EBS_VOLUMES_FOUND" | "UNSUPPORTED_PRODUCT_CODE_TYPE" | "AMI_SNAPSHOT_LIMIT_EXCEEDED" | "UNRELATED_RESOURCES" | "BASE_RESOURCE_NOT_SCANNED" | "BASE_CREATED_AFTER_TARGET" | "UNSUPPORTED_FOR_INCREMENTAL" | "UNSUPPORTED_AMI" | "UNSUPPORTED_SNAPSHOT" | "UNSUPPORTED_COMPOSITE_RECOVERY_POINT" | "ALL_FILES_SKIPPED_OR_FAILED" | (string & {});
export declare const ScanStatusReason: any;
export interface EbsSnapshot {
    DeviceName?: string;
}
export declare const EbsSnapshot: S.Schema<EbsSnapshot>;
export interface ScannedResourceDetails {
    EbsVolume?: VolumeDetail;
    EbsSnapshot?: EbsSnapshot;
}
export declare const ScannedResourceDetails: S.Schema<ScannedResourceDetails>;
export interface ScannedResource {
    ScannedResourceArn?: string;
    ScannedResourceType?: MalwareProtectionResourceType;
    ScannedResourceStatus?: MalwareProtectionScanStatus;
    ScanStatusReason?: ScanStatusReason;
    ResourceDetails?: ScannedResourceDetails;
}
export declare const ScannedResource: S.Schema<ScannedResource>;
export type ScannedResources = ScannedResource[];
export declare const ScannedResources: any;
export interface ScanConfigurationRecoveryPoint {
    BackupVaultName?: string;
    ContinuousScanDetails?: ScanConfigurationContinuousScanDetails;
}
export declare const ScanConfigurationRecoveryPoint: S.Schema<ScanConfigurationRecoveryPoint>;
export interface ScanConfiguration {
    Role?: string;
    TriggerDetails?: TriggerDetails;
    IncrementalScanDetails?: IncrementalScanDetails;
    RecoveryPoint?: ScanConfigurationRecoveryPoint;
}
export declare const ScanConfiguration: S.Schema<ScanConfiguration>;
export type ScanResultStatus = "NO_THREATS_FOUND" | "THREATS_FOUND" | (string & {});
export declare const ScanResultStatus: any;
export type DetectionSource = "AMAZON" | "BITDEFENDER" | (string & {});
export declare const DetectionSource: any;
export interface ScanResultThreat {
    Name?: string;
    Source?: DetectionSource;
    Count?: number;
    Hash?: string;
    ItemDetails?: ItemDetails[];
}
export declare const ScanResultThreat: S.Schema<ScanResultThreat>;
export type ScanResultThreats = ScanResultThreat[];
export declare const ScanResultThreats: any;
export interface GetMalwareScanResultDetails {
    ScanResultStatus?: ScanResultStatus;
    SkippedFileCount?: number;
    FailedFileCount?: number;
    ThreatFoundFileCount?: number;
    TotalFileCount?: number;
    TotalBytes?: number;
    UniqueThreatCount?: number;
    Threats?: ScanResultThreat[];
}
export declare const GetMalwareScanResultDetails: S.Schema<GetMalwareScanResultDetails>;
export interface GetMalwareScanResponse {
    ScanId?: string;
    DetectorId?: string;
    AdminDetectorId?: string;
    ResourceArn?: string;
    ResourceType?: MalwareProtectionResourceType;
    ScannedResourcesCount?: number;
    SkippedResourcesCount?: number;
    FailedResourcesCount?: number;
    ScannedResources?: ScannedResource[];
    ScanConfiguration?: ScanConfiguration & {
        IncrementalScanDetails: IncrementalScanDetails & {
            BaselineResourceArn: NonEmptyString;
        };
    };
    ScanCategory?: ScanCategory;
    ScanStatus?: MalwareProtectionScanStatus;
    ScanStatusReason?: ScanStatusReason;
    ScanType?: MalwareProtectionScanType;
    ScanStartedAt?: Date;
    ScanCompletedAt?: Date;
    ScanResultDetails?: GetMalwareScanResultDetails;
}
export declare const GetMalwareScanResponse: S.Schema<GetMalwareScanResponse>;
export interface GetMalwareScanSettingsRequest {
    DetectorId: string;
}
export declare const GetMalwareScanSettingsRequest: S.Schema<GetMalwareScanSettingsRequest>;
export type ScanCriterionKey = "EC2_INSTANCE_TAG" | (string & {});
export declare const ScanCriterionKey: any;
export interface ScanConditionPair {
    Key?: string;
    Value?: string;
}
export declare const ScanConditionPair: S.Schema<ScanConditionPair>;
export type MapEquals = ScanConditionPair[];
export declare const MapEquals: any;
export interface ScanCondition {
    MapEquals?: ScanConditionPair[];
}
export declare const ScanCondition: S.Schema<ScanCondition>;
export type ScanCriterion = {
    [key in ScanCriterionKey]?: ScanCondition;
};
export declare const ScanCriterion: any;
export interface ScanResourceCriteria {
    Include?: {
        [key: string]: ScanCondition | undefined;
    };
    Exclude?: {
        [key: string]: ScanCondition | undefined;
    };
}
export declare const ScanResourceCriteria: S.Schema<ScanResourceCriteria>;
export type EbsSnapshotPreservation = "NO_RETENTION" | "RETENTION_WITH_FINDING" | (string & {});
export declare const EbsSnapshotPreservation: any;
export interface GetMalwareScanSettingsResponse {
    ScanResourceCriteria?: ScanResourceCriteria & {
        Include: {
            [key: string]: (ScanCondition & {
                MapEquals: (ScanConditionPair & {
                    Key: TagKey;
                })[];
            }) | undefined;
        };
        Exclude: {
            [key: string]: (ScanCondition & {
                MapEquals: (ScanConditionPair & {
                    Key: TagKey;
                })[];
            }) | undefined;
        };
    };
    EbsSnapshotPreservation?: EbsSnapshotPreservation;
}
export declare const GetMalwareScanSettingsResponse: S.Schema<GetMalwareScanSettingsResponse>;
export interface GetMasterAccountRequest {
    DetectorId: string;
}
export declare const GetMasterAccountRequest: S.Schema<GetMasterAccountRequest>;
export interface Master {
    AccountId?: string;
    InvitationId?: string;
    RelationshipStatus?: string;
    InvitedAt?: string;
}
export declare const Master: S.Schema<Master>;
export interface GetMasterAccountResponse {
    Master: Master;
}
export declare const GetMasterAccountResponse: S.Schema<GetMasterAccountResponse>;
export interface GetMemberDetectorsRequest {
    DetectorId: string;
    AccountIds?: string[];
}
export declare const GetMemberDetectorsRequest: S.Schema<GetMemberDetectorsRequest>;
export interface MemberAdditionalConfigurationResult {
    Name?: OrgFeatureAdditionalConfiguration;
    Status?: FeatureStatus;
    UpdatedAt?: Date;
}
export declare const MemberAdditionalConfigurationResult: S.Schema<MemberAdditionalConfigurationResult>;
export type MemberAdditionalConfigurationResults = MemberAdditionalConfigurationResult[];
export declare const MemberAdditionalConfigurationResults: any;
export interface MemberFeaturesConfigurationResult {
    Name?: OrgFeature;
    Status?: FeatureStatus;
    UpdatedAt?: Date;
    AdditionalConfiguration?: MemberAdditionalConfigurationResult[];
}
export declare const MemberFeaturesConfigurationResult: S.Schema<MemberFeaturesConfigurationResult>;
export type MemberFeaturesConfigurationsResults = MemberFeaturesConfigurationResult[];
export declare const MemberFeaturesConfigurationsResults: any;
export interface MemberDataSourceConfiguration {
    AccountId?: string;
    DataSources?: DataSourceConfigurationsResult;
    Features?: MemberFeaturesConfigurationResult[];
}
export declare const MemberDataSourceConfiguration: S.Schema<MemberDataSourceConfiguration>;
export type MemberDataSourceConfigurations = MemberDataSourceConfiguration[];
export declare const MemberDataSourceConfigurations: any;
export interface GetMemberDetectorsResponse {
    MemberDataSourceConfigurations: (MemberDataSourceConfiguration & {
        AccountId: AccountId;
        DataSources: DataSourceConfigurationsResult & {
            CloudTrail: CloudTrailConfigurationResult & {
                Status: DataSourceStatus;
            };
            DNSLogs: DNSLogsConfigurationResult & {
                Status: DataSourceStatus;
            };
            FlowLogs: FlowLogsConfigurationResult & {
                Status: DataSourceStatus;
            };
            S3Logs: S3LogsConfigurationResult & {
                Status: DataSourceStatus;
            };
            Kubernetes: KubernetesConfigurationResult & {
                AuditLogs: KubernetesAuditLogsConfigurationResult & {
                    Status: DataSourceStatus;
                };
            };
        };
    })[];
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export declare const GetMemberDetectorsResponse: S.Schema<GetMemberDetectorsResponse>;
export interface GetMembersRequest {
    DetectorId: string;
    AccountIds?: string[];
}
export declare const GetMembersRequest: S.Schema<GetMembersRequest>;
export interface Member {
    AccountId?: string;
    DetectorId?: string;
    MasterId?: string;
    Email?: string | redacted.Redacted<string>;
    RelationshipStatus?: string;
    InvitedAt?: string;
    UpdatedAt?: string;
    AdministratorId?: string;
}
export declare const Member: S.Schema<Member>;
export type Members = Member[];
export declare const Members: any;
export interface GetMembersResponse {
    Members: (Member & {
        AccountId: AccountId;
        MasterId: string;
        Email: Email;
        RelationshipStatus: string;
        UpdatedAt: string;
    })[];
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export declare const GetMembersResponse: S.Schema<GetMembersResponse>;
export interface GetOrganizationStatisticsRequest {
}
export declare const GetOrganizationStatisticsRequest: S.Schema<GetOrganizationStatisticsRequest>;
export interface OrganizationFeatureStatisticsAdditionalConfiguration {
    Name?: OrgFeatureAdditionalConfiguration;
    EnabledAccountsCount?: number;
}
export declare const OrganizationFeatureStatisticsAdditionalConfiguration: S.Schema<OrganizationFeatureStatisticsAdditionalConfiguration>;
export type OrganizationFeatureStatisticsAdditionalConfigurations = OrganizationFeatureStatisticsAdditionalConfiguration[];
export declare const OrganizationFeatureStatisticsAdditionalConfigurations: any;
export interface OrganizationFeatureStatistics {
    Name?: OrgFeature;
    EnabledAccountsCount?: number;
    AdditionalConfiguration?: OrganizationFeatureStatisticsAdditionalConfiguration[];
}
export declare const OrganizationFeatureStatistics: S.Schema<OrganizationFeatureStatistics>;
export type OrganizationFeatureStatisticsResults = OrganizationFeatureStatistics[];
export declare const OrganizationFeatureStatisticsResults: any;
export interface OrganizationStatistics {
    TotalAccountsCount?: number;
    MemberAccountsCount?: number;
    ActiveAccountsCount?: number;
    EnabledAccountsCount?: number;
    CountByFeature?: OrganizationFeatureStatistics[];
}
export declare const OrganizationStatistics: S.Schema<OrganizationStatistics>;
export interface OrganizationDetails {
    UpdatedAt?: Date;
    OrganizationStatistics?: OrganizationStatistics;
}
export declare const OrganizationDetails: S.Schema<OrganizationDetails>;
export interface GetOrganizationStatisticsResponse {
    OrganizationDetails?: OrganizationDetails;
}
export declare const GetOrganizationStatisticsResponse: S.Schema<GetOrganizationStatisticsResponse>;
export interface GetRemainingFreeTrialDaysRequest {
    DetectorId: string;
    AccountIds: string[];
}
export declare const GetRemainingFreeTrialDaysRequest: S.Schema<GetRemainingFreeTrialDaysRequest>;
export interface DataSourceFreeTrial {
    FreeTrialDaysRemaining?: number;
}
export declare const DataSourceFreeTrial: S.Schema<DataSourceFreeTrial>;
export interface KubernetesDataSourceFreeTrial {
    AuditLogs?: DataSourceFreeTrial;
}
export declare const KubernetesDataSourceFreeTrial: S.Schema<KubernetesDataSourceFreeTrial>;
export interface MalwareProtectionDataSourceFreeTrial {
    ScanEc2InstanceWithFindings?: DataSourceFreeTrial;
}
export declare const MalwareProtectionDataSourceFreeTrial: S.Schema<MalwareProtectionDataSourceFreeTrial>;
export interface DataSourcesFreeTrial {
    CloudTrail?: DataSourceFreeTrial;
    DnsLogs?: DataSourceFreeTrial;
    FlowLogs?: DataSourceFreeTrial;
    S3Logs?: DataSourceFreeTrial;
    Kubernetes?: KubernetesDataSourceFreeTrial;
    MalwareProtection?: MalwareProtectionDataSourceFreeTrial;
}
export declare const DataSourcesFreeTrial: S.Schema<DataSourcesFreeTrial>;
export type FreeTrialFeatureResult = "FLOW_LOGS" | "CLOUD_TRAIL" | "DNS_LOGS" | "S3_DATA_EVENTS" | "EKS_AUDIT_LOGS" | "EBS_MALWARE_PROTECTION" | "RDS_LOGIN_EVENTS" | "LAMBDA_NETWORK_LOGS" | "EKS_RUNTIME_MONITORING" | "EC2_RUNTIME_MONITORING" | "FARGATE_RUNTIME_MONITORING" | "AI_PROTECTION" | (string & {});
export declare const FreeTrialFeatureResult: any;
export interface FreeTrialFeatureConfigurationResult {
    Name?: FreeTrialFeatureResult;
    FreeTrialDaysRemaining?: number;
}
export declare const FreeTrialFeatureConfigurationResult: S.Schema<FreeTrialFeatureConfigurationResult>;
export type FreeTrialFeatureConfigurationsResults = FreeTrialFeatureConfigurationResult[];
export declare const FreeTrialFeatureConfigurationsResults: any;
export interface AccountFreeTrialInfo {
    AccountId?: string;
    DataSources?: DataSourcesFreeTrial;
    Features?: FreeTrialFeatureConfigurationResult[];
}
export declare const AccountFreeTrialInfo: S.Schema<AccountFreeTrialInfo>;
export type AccountFreeTrialInfos = AccountFreeTrialInfo[];
export declare const AccountFreeTrialInfos: any;
export interface GetRemainingFreeTrialDaysResponse {
    Accounts?: AccountFreeTrialInfo[];
    UnprocessedAccounts?: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export declare const GetRemainingFreeTrialDaysResponse: S.Schema<GetRemainingFreeTrialDaysResponse>;
export interface GetThreatEntitySetRequest {
    DetectorId: string;
    ThreatEntitySetId?: string;
}
export declare const GetThreatEntitySetRequest: S.Schema<GetThreatEntitySetRequest>;
export type ThreatEntitySetStatus = "INACTIVE" | "ACTIVATING" | "ACTIVE" | "DEACTIVATING" | "ERROR" | "DELETE_PENDING" | "DELETED" | (string & {});
export declare const ThreatEntitySetStatus: any;
export interface GetThreatEntitySetResponse {
    Name: string;
    Format: ThreatEntitySetFormat;
    Location: string;
    ExpectedBucketOwner?: string;
    Status: ThreatEntitySetStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ErrorDetails?: string;
}
export declare const GetThreatEntitySetResponse: S.Schema<GetThreatEntitySetResponse>;
export interface GetThreatIntelSetRequest {
    DetectorId: string;
    ThreatIntelSetId: string;
}
export declare const GetThreatIntelSetRequest: S.Schema<GetThreatIntelSetRequest>;
export type ThreatIntelSetStatus = "INACTIVE" | "ACTIVATING" | "ACTIVE" | "DEACTIVATING" | "ERROR" | "DELETE_PENDING" | "DELETED" | (string & {});
export declare const ThreatIntelSetStatus: any;
export interface GetThreatIntelSetResponse {
    Name: string;
    Format: ThreatIntelSetFormat;
    Location: string;
    Status: ThreatIntelSetStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    ExpectedBucketOwner?: string;
}
export declare const GetThreatIntelSetResponse: S.Schema<GetThreatIntelSetResponse>;
export interface GetTrustedEntitySetRequest {
    DetectorId: string;
    TrustedEntitySetId: string;
}
export declare const GetTrustedEntitySetRequest: S.Schema<GetTrustedEntitySetRequest>;
export type TrustedEntitySetStatus = "INACTIVE" | "ACTIVATING" | "ACTIVE" | "DEACTIVATING" | "ERROR" | "DELETE_PENDING" | "DELETED" | (string & {});
export declare const TrustedEntitySetStatus: any;
export interface GetTrustedEntitySetResponse {
    Name: string;
    Format: TrustedEntitySetFormat;
    Location: string;
    ExpectedBucketOwner?: string;
    Status: TrustedEntitySetStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ErrorDetails?: string;
}
export declare const GetTrustedEntitySetResponse: S.Schema<GetTrustedEntitySetResponse>;
export type UsageStatisticType = "SUM_BY_ACCOUNT" | "SUM_BY_DATA_SOURCE" | "SUM_BY_RESOURCE" | "TOP_RESOURCES" | "SUM_BY_FEATURES" | "TOP_ACCOUNTS_BY_FEATURE" | (string & {});
export declare const UsageStatisticType: any;
export type DataSource = "FLOW_LOGS" | "CLOUD_TRAIL" | "DNS_LOGS" | "S3_LOGS" | "KUBERNETES_AUDIT_LOGS" | "EC2_MALWARE_SCAN" | (string & {});
export declare const DataSource: any;
export type DataSourceList = DataSource[];
export declare const DataSourceList: any;
export type ResourceList = string[];
export declare const ResourceList: any;
export type UsageFeature = "FLOW_LOGS" | "CLOUD_TRAIL" | "DNS_LOGS" | "S3_DATA_EVENTS" | "EKS_AUDIT_LOGS" | "EBS_MALWARE_PROTECTION" | "RDS_LOGIN_EVENTS" | "LAMBDA_NETWORK_LOGS" | "EKS_RUNTIME_MONITORING" | "EC2_RUNTIME_MONITORING" | "FARGATE_RUNTIME_MONITORING" | "RDS_DBI_PROTECTION_PROVISIONED" | "RDS_DBI_PROTECTION_SERVERLESS" | "AI_PROTECTION" | (string & {});
export declare const UsageFeature: any;
export type UsageFeatureList = UsageFeature[];
export declare const UsageFeatureList: any;
export interface UsageCriteria {
    AccountIds?: string[];
    DataSources?: DataSource[];
    Resources?: string[];
    Features?: UsageFeature[];
}
export declare const UsageCriteria: S.Schema<UsageCriteria>;
export interface GetUsageStatisticsRequest {
    DetectorId: string;
    UsageStatisticType?: UsageStatisticType;
    UsageCriteria?: UsageCriteria;
    Unit?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const GetUsageStatisticsRequest: S.Schema<GetUsageStatisticsRequest>;
export interface Total {
    Amount?: string;
    Unit?: string;
}
export declare const Total: S.Schema<Total>;
export interface UsageAccountResult {
    AccountId?: string;
    Total?: Total;
}
export declare const UsageAccountResult: S.Schema<UsageAccountResult>;
export type UsageAccountResultList = UsageAccountResult[];
export declare const UsageAccountResultList: any;
export interface UsageTopAccountResult {
    AccountId?: string;
    Total?: Total;
}
export declare const UsageTopAccountResult: S.Schema<UsageTopAccountResult>;
export type UsageTopAccountsByFeatureList = UsageTopAccountResult[];
export declare const UsageTopAccountsByFeatureList: any;
export interface UsageTopAccountsResult {
    Feature?: UsageFeature;
    Accounts?: UsageTopAccountResult[];
}
export declare const UsageTopAccountsResult: S.Schema<UsageTopAccountsResult>;
export type UsageTopAccountsResultList = UsageTopAccountsResult[];
export declare const UsageTopAccountsResultList: any;
export interface UsageDataSourceResult {
    DataSource?: DataSource;
    Total?: Total;
}
export declare const UsageDataSourceResult: S.Schema<UsageDataSourceResult>;
export type UsageDataSourceResultList = UsageDataSourceResult[];
export declare const UsageDataSourceResultList: any;
export interface UsageResourceResult {
    Resource?: string;
    Total?: Total;
}
export declare const UsageResourceResult: S.Schema<UsageResourceResult>;
export type UsageResourceResultList = UsageResourceResult[];
export declare const UsageResourceResultList: any;
export interface UsageFeatureResult {
    Feature?: UsageFeature;
    Total?: Total;
}
export declare const UsageFeatureResult: S.Schema<UsageFeatureResult>;
export type UsageFeatureResultList = UsageFeatureResult[];
export declare const UsageFeatureResultList: any;
export interface UsageStatistics {
    SumByAccount?: UsageAccountResult[];
    TopAccountsByFeature?: UsageTopAccountsResult[];
    SumByDataSource?: UsageDataSourceResult[];
    SumByResource?: UsageResourceResult[];
    TopResources?: UsageResourceResult[];
    SumByFeature?: UsageFeatureResult[];
}
export declare const UsageStatistics: S.Schema<UsageStatistics>;
export interface GetUsageStatisticsResponse {
    UsageStatistics?: UsageStatistics;
    NextToken?: string;
}
export declare const GetUsageStatisticsResponse: S.Schema<GetUsageStatisticsResponse>;
export interface InviteMembersRequest {
    DetectorId: string;
    AccountIds?: string[];
    DisableEmailNotification?: boolean;
    Message?: string;
}
export declare const InviteMembersRequest: S.Schema<InviteMembersRequest>;
export interface InviteMembersResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export declare const InviteMembersResponse: S.Schema<InviteMembersResponse>;
export type CoverageSortKey = "ACCOUNT_ID" | "COVERAGE_STATUS" | "ISSUE" | "ADDON_VERSION" | "UPDATED_AT" | "CLUSTER_NAME" | "EKS_CLUSTER_NAME" | "ECS_CLUSTER_NAME" | "INSTANCE_ID" | (string & {});
export declare const CoverageSortKey: any;
export interface CoverageSortCriteria {
    AttributeName?: CoverageSortKey;
    OrderBy?: OrderBy;
}
export declare const CoverageSortCriteria: S.Schema<CoverageSortCriteria>;
export interface ListCoverageRequest {
    DetectorId: string;
    NextToken?: string;
    MaxResults?: number;
    FilterCriteria?: CoverageFilterCriteria;
    SortCriteria?: CoverageSortCriteria;
}
export declare const ListCoverageRequest: S.Schema<ListCoverageRequest>;
export interface AddonDetails {
    AddonVersion?: string;
    AddonStatus?: string;
}
export declare const AddonDetails: S.Schema<AddonDetails>;
export type ManagementType = "AUTO_MANAGED" | "MANUAL" | "DISABLED" | (string & {});
export declare const ManagementType: any;
export interface CoverageEksClusterDetails {
    ClusterName?: string;
    CoveredNodes?: number;
    CompatibleNodes?: number;
    AddonDetails?: AddonDetails;
    ManagementType?: ManagementType;
}
export declare const CoverageEksClusterDetails: S.Schema<CoverageEksClusterDetails>;
export type Issues = string[];
export declare const Issues: any;
export interface FargateDetails {
    Issues?: string[];
    ManagementType?: ManagementType;
}
export declare const FargateDetails: S.Schema<FargateDetails>;
export interface ContainerInstanceDetails {
    CoveredContainerInstances?: number;
    CompatibleContainerInstances?: number;
}
export declare const ContainerInstanceDetails: S.Schema<ContainerInstanceDetails>;
export interface CoverageEcsClusterDetails {
    ClusterName?: string;
    FargateDetails?: FargateDetails;
    ContainerInstanceDetails?: ContainerInstanceDetails;
}
export declare const CoverageEcsClusterDetails: S.Schema<CoverageEcsClusterDetails>;
export interface AgentDetails {
    Version?: string;
}
export declare const AgentDetails: S.Schema<AgentDetails>;
export interface CoverageEc2InstanceDetails {
    InstanceId?: string;
    InstanceType?: string;
    ClusterArn?: string;
    AgentDetails?: AgentDetails;
    ManagementType?: ManagementType;
}
export declare const CoverageEc2InstanceDetails: S.Schema<CoverageEc2InstanceDetails>;
export interface CoverageResourceDetails {
    EksClusterDetails?: CoverageEksClusterDetails;
    EcsClusterDetails?: CoverageEcsClusterDetails;
    Ec2InstanceDetails?: CoverageEc2InstanceDetails;
    ResourceType?: ResourceType;
}
export declare const CoverageResourceDetails: S.Schema<CoverageResourceDetails>;
export interface CoverageResource {
    ResourceId?: string;
    DetectorId?: string;
    AccountId?: string;
    ResourceDetails?: CoverageResourceDetails;
    CoverageStatus?: CoverageStatus;
    Issue?: string;
    UpdatedAt?: Date;
}
export declare const CoverageResource: S.Schema<CoverageResource>;
export type CoverageResources = CoverageResource[];
export declare const CoverageResources: any;
export interface ListCoverageResponse {
    Resources: CoverageResource[];
    NextToken?: string;
}
export declare const ListCoverageResponse: S.Schema<ListCoverageResponse>;
export interface ListDetectorsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDetectorsRequest: S.Schema<ListDetectorsRequest>;
export type DetectorIds = string[];
export declare const DetectorIds: any;
export interface ListDetectorsResponse {
    DetectorIds: string[];
    NextToken?: string;
}
export declare const ListDetectorsResponse: S.Schema<ListDetectorsResponse>;
export interface ListFiltersRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListFiltersRequest: S.Schema<ListFiltersRequest>;
export type FilterNames = string[];
export declare const FilterNames: any;
export interface ListFiltersResponse {
    FilterNames: string[];
    NextToken?: string;
}
export declare const ListFiltersResponse: S.Schema<ListFiltersResponse>;
export interface ListFindingsRequest {
    DetectorId: string;
    FindingCriteria?: FindingCriteria;
    SortCriteria?: SortCriteria;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListFindingsRequest: S.Schema<ListFindingsRequest>;
export interface ListFindingsResponse {
    FindingIds: string[];
    NextToken?: string;
}
export declare const ListFindingsResponse: S.Schema<ListFindingsResponse>;
export type InvestigationSortField = "START_TIME" | "END_TIME" | "STATUS" | "RISK_LEVEL" | "CONFIDENCE" | (string & {});
export declare const InvestigationSortField: any;
export interface InvestigationSortCriteria {
    AttributeName?: InvestigationSortField;
    OrderBy?: OrderBy;
}
export declare const InvestigationSortCriteria: S.Schema<InvestigationSortCriteria>;
export type NextToken = string;
export interface ListInvestigationsRequest {
    DetectorId: string;
    SortCriteria?: InvestigationSortCriteria;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListInvestigationsRequest: S.Schema<ListInvestigationsRequest>;
export type InvestigationTitle = string;
export interface InvestigationSummary {
    InvestigationId?: string;
    Status?: InvestigationStatus;
    TriggerPrompt?: string;
    RiskLevel?: RiskLevel;
    Confidence?: Confidence;
    Title?: string;
    AccountId?: string;
    StartTime?: Date;
    EndTime?: Date;
}
export declare const InvestigationSummary: S.Schema<InvestigationSummary>;
export type InvestigationSummaries = InvestigationSummary[];
export declare const InvestigationSummaries: any;
export interface ListInvestigationsResponse {
    Investigations: InvestigationSummary[];
    NextToken?: string;
}
export declare const ListInvestigationsResponse: S.Schema<ListInvestigationsResponse>;
export interface ListInvitationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListInvitationsRequest: S.Schema<ListInvitationsRequest>;
export interface Invitation {
    AccountId?: string;
    InvitationId?: string;
    RelationshipStatus?: string;
    InvitedAt?: string;
}
export declare const Invitation: S.Schema<Invitation>;
export type Invitations = Invitation[];
export declare const Invitations: any;
export interface ListInvitationsResponse {
    Invitations?: Invitation[];
    NextToken?: string;
}
export declare const ListInvitationsResponse: S.Schema<ListInvitationsResponse>;
export interface ListIPSetsRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListIPSetsRequest: S.Schema<ListIPSetsRequest>;
export type IpSetIds = string[];
export declare const IpSetIds: any;
export interface ListIPSetsResponse {
    IpSetIds: string[];
    NextToken?: string;
}
export declare const ListIPSetsResponse: S.Schema<ListIPSetsResponse>;
export interface ListMalwareProtectionPlansRequest {
    NextToken?: string;
}
export declare const ListMalwareProtectionPlansRequest: S.Schema<ListMalwareProtectionPlansRequest>;
export interface MalwareProtectionPlanSummary {
    MalwareProtectionPlanId?: string;
}
export declare const MalwareProtectionPlanSummary: S.Schema<MalwareProtectionPlanSummary>;
export type MalwareProtectionPlansSummary = MalwareProtectionPlanSummary[];
export declare const MalwareProtectionPlansSummary: any;
export interface ListMalwareProtectionPlansResponse {
    MalwareProtectionPlans?: MalwareProtectionPlanSummary[];
    NextToken?: string;
}
export declare const ListMalwareProtectionPlansResponse: S.Schema<ListMalwareProtectionPlansResponse>;
export type ListMalwareScansCriterionKey = "RESOURCE_ARN" | "SCAN_ID" | "ACCOUNT_ID" | "GUARDDUTY_FINDING_ID" | "RESOURCE_TYPE" | "SCAN_START_TIME" | "SCAN_STATUS" | "SCAN_TYPE" | (string & {});
export declare const ListMalwareScansCriterionKey: any;
export interface ListMalwareScansFilterCriterion {
    ListMalwareScansCriterionKey?: ListMalwareScansCriterionKey;
    FilterCondition?: FilterCondition;
}
export declare const ListMalwareScansFilterCriterion: S.Schema<ListMalwareScansFilterCriterion>;
export type ListMalwareScansFilterCriterionList = ListMalwareScansFilterCriterion[];
export declare const ListMalwareScansFilterCriterionList: any;
export interface ListMalwareScansFilterCriteria {
    ListMalwareScansFilterCriterion?: ListMalwareScansFilterCriterion[];
}
export declare const ListMalwareScansFilterCriteria: S.Schema<ListMalwareScansFilterCriteria>;
export interface ListMalwareScansRequest {
    MaxResults?: number;
    NextToken?: string;
    FilterCriteria?: ListMalwareScansFilterCriteria;
    SortCriteria?: SortCriteria;
}
export declare const ListMalwareScansRequest: S.Schema<ListMalwareScansRequest>;
export interface MalwareScan {
    ResourceArn?: string;
    ResourceType?: MalwareProtectionResourceType;
    ScanId?: string;
    ScanStatus?: MalwareProtectionScanStatus;
    ScanResultStatus?: ScanResultStatus;
    ScanType?: MalwareProtectionScanType;
    ScanStartedAt?: Date;
    ScanCompletedAt?: Date;
}
export declare const MalwareScan: S.Schema<MalwareScan>;
export type MalwareScans = MalwareScan[];
export declare const MalwareScans: any;
export interface ListMalwareScansResponse {
    Scans: MalwareScan[];
    NextToken?: string;
}
export declare const ListMalwareScansResponse: S.Schema<ListMalwareScansResponse>;
export interface ListMembersRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
    OnlyAssociated?: string;
}
export declare const ListMembersRequest: S.Schema<ListMembersRequest>;
export interface ListMembersResponse {
    Members?: (Member & {
        AccountId: AccountId;
        MasterId: string;
        Email: Email;
        RelationshipStatus: string;
        UpdatedAt: string;
    })[];
    NextToken?: string;
}
export declare const ListMembersResponse: S.Schema<ListMembersResponse>;
export interface ListOrganizationAdminAccountsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListOrganizationAdminAccountsRequest: S.Schema<ListOrganizationAdminAccountsRequest>;
export type AdminStatus = "ENABLED" | "DISABLE_IN_PROGRESS" | (string & {});
export declare const AdminStatus: any;
export interface AdminAccount {
    AdminAccountId?: string;
    AdminStatus?: AdminStatus;
}
export declare const AdminAccount: S.Schema<AdminAccount>;
export type AdminAccounts = AdminAccount[];
export declare const AdminAccounts: any;
export interface ListOrganizationAdminAccountsResponse {
    AdminAccounts?: AdminAccount[];
    NextToken?: string;
}
export declare const ListOrganizationAdminAccountsResponse: S.Schema<ListOrganizationAdminAccountsResponse>;
export interface ListPublishingDestinationsRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListPublishingDestinationsRequest: S.Schema<ListPublishingDestinationsRequest>;
export interface Destination {
    DestinationId?: string;
    DestinationType?: DestinationType;
    Status?: PublishingStatus;
}
export declare const Destination: S.Schema<Destination>;
export type Destinations = Destination[];
export declare const Destinations: any;
export interface ListPublishingDestinationsResponse {
    Destinations: (Destination & {
        DestinationId: string;
        DestinationType: DestinationType;
        Status: PublishingStatus;
    })[];
    NextToken?: string;
}
export declare const ListPublishingDestinationsResponse: S.Schema<ListPublishingDestinationsResponse>;
export type GuardDutyArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListThreatEntitySetsRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListThreatEntitySetsRequest: S.Schema<ListThreatEntitySetsRequest>;
export type ThreatEntitySetIds = string[];
export declare const ThreatEntitySetIds: any;
export interface ListThreatEntitySetsResponse {
    ThreatEntitySetIds: string[];
    NextToken?: string;
}
export declare const ListThreatEntitySetsResponse: S.Schema<ListThreatEntitySetsResponse>;
export interface ListThreatIntelSetsRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListThreatIntelSetsRequest: S.Schema<ListThreatIntelSetsRequest>;
export type ThreatIntelSetIds = string[];
export declare const ThreatIntelSetIds: any;
export interface ListThreatIntelSetsResponse {
    ThreatIntelSetIds: string[];
    NextToken?: string;
}
export declare const ListThreatIntelSetsResponse: S.Schema<ListThreatIntelSetsResponse>;
export interface ListTrustedEntitySetsRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListTrustedEntitySetsRequest: S.Schema<ListTrustedEntitySetsRequest>;
export type TrustedEntitySetIds = string[];
export declare const TrustedEntitySetIds: any;
export interface ListTrustedEntitySetsResponse {
    TrustedEntitySetIds: string[];
    NextToken?: string;
}
export declare const ListTrustedEntitySetsResponse: S.Schema<ListTrustedEntitySetsResponse>;
export interface S3ObjectForSendObjectMalwareScan {
    Bucket?: string;
    Key?: string;
    VersionId?: string;
}
export declare const S3ObjectForSendObjectMalwareScan: S.Schema<S3ObjectForSendObjectMalwareScan>;
export interface SendObjectMalwareScanRequest {
    S3Object?: S3ObjectForSendObjectMalwareScan;
}
export declare const SendObjectMalwareScanRequest: S.Schema<SendObjectMalwareScanRequest>;
export interface SendObjectMalwareScanResponse {
}
export declare const SendObjectMalwareScanResponse: S.Schema<SendObjectMalwareScanResponse>;
export type ResourceArn = string;
export interface ContinuousScanDetails {
    StartTime?: Date;
    EndTime: Date;
}
export declare const ContinuousScanDetails: S.Schema<ContinuousScanDetails>;
export interface RecoveryPoint {
    BackupVaultName?: string;
    ContinuousScanDetails?: ContinuousScanDetails;
}
export declare const RecoveryPoint: S.Schema<RecoveryPoint>;
export interface StartMalwareScanConfiguration {
    Role?: string;
    IncrementalScanDetails?: IncrementalScanDetails;
    RecoveryPoint?: RecoveryPoint;
}
export declare const StartMalwareScanConfiguration: S.Schema<StartMalwareScanConfiguration>;
export interface StartMalwareScanRequest {
    ResourceArn?: string;
    ClientToken?: string;
    ScanConfiguration?: StartMalwareScanConfiguration;
}
export declare const StartMalwareScanRequest: S.Schema<StartMalwareScanRequest>;
export interface StartMalwareScanResponse {
    ScanId?: string;
}
export declare const StartMalwareScanResponse: S.Schema<StartMalwareScanResponse>;
export interface StartMonitoringMembersRequest {
    DetectorId: string;
    AccountIds?: string[];
}
export declare const StartMonitoringMembersRequest: S.Schema<StartMonitoringMembersRequest>;
export interface StartMonitoringMembersResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export declare const StartMonitoringMembersResponse: S.Schema<StartMonitoringMembersResponse>;
export interface StopMonitoringMembersRequest {
    DetectorId: string;
    AccountIds?: string[];
}
export declare const StopMonitoringMembersRequest: S.Schema<StopMonitoringMembersRequest>;
export interface StopMonitoringMembersResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export declare const StopMonitoringMembersResponse: S.Schema<StopMonitoringMembersResponse>;
export interface TagResourceRequest {
    ResourceArn?: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface UnarchiveFindingsRequest {
    DetectorId: string;
    FindingIds?: string[];
}
export declare const UnarchiveFindingsRequest: S.Schema<UnarchiveFindingsRequest>;
export interface UnarchiveFindingsResponse {
}
export declare const UnarchiveFindingsResponse: S.Schema<UnarchiveFindingsResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateDetectorRequest {
    DetectorId: string;
    Enable?: boolean;
    FindingPublishingFrequency?: FindingPublishingFrequency;
    DataSources?: DataSourceConfigurations;
    Features?: DetectorFeatureConfiguration[];
}
export declare const UpdateDetectorRequest: S.Schema<UpdateDetectorRequest>;
export interface UpdateDetectorResponse {
}
export declare const UpdateDetectorResponse: S.Schema<UpdateDetectorResponse>;
export interface UpdateFilterRequest {
    DetectorId: string;
    FilterName: string;
    Description?: string;
    Action?: FilterAction;
    Rank?: number;
    FindingCriteria?: FindingCriteria;
}
export declare const UpdateFilterRequest: S.Schema<UpdateFilterRequest>;
export interface UpdateFilterResponse {
    Name: string;
}
export declare const UpdateFilterResponse: S.Schema<UpdateFilterResponse>;
export type Feedback = "USEFUL" | "NOT_USEFUL" | (string & {});
export declare const Feedback: any;
export interface UpdateFindingsFeedbackRequest {
    DetectorId: string;
    FindingIds?: string[];
    Feedback?: Feedback;
    Comments?: string | redacted.Redacted<string>;
}
export declare const UpdateFindingsFeedbackRequest: S.Schema<UpdateFindingsFeedbackRequest>;
export interface UpdateFindingsFeedbackResponse {
}
export declare const UpdateFindingsFeedbackResponse: S.Schema<UpdateFindingsFeedbackResponse>;
export interface UpdateIPSetRequest {
    DetectorId: string;
    IpSetId?: string;
    Name?: string;
    Location?: string;
    Activate?: boolean;
    ExpectedBucketOwner?: string;
}
export declare const UpdateIPSetRequest: S.Schema<UpdateIPSetRequest>;
export interface UpdateIPSetResponse {
}
export declare const UpdateIPSetResponse: S.Schema<UpdateIPSetResponse>;
export interface UpdateS3BucketResource {
    ObjectPrefixes?: string[];
}
export declare const UpdateS3BucketResource: S.Schema<UpdateS3BucketResource>;
export interface UpdateProtectedResource {
    S3Bucket?: UpdateS3BucketResource;
}
export declare const UpdateProtectedResource: S.Schema<UpdateProtectedResource>;
export interface UpdateMalwareProtectionPlanRequest {
    MalwareProtectionPlanId: string;
    Role?: string;
    Actions?: MalwareProtectionPlanActions;
    ProtectedResource?: UpdateProtectedResource;
}
export declare const UpdateMalwareProtectionPlanRequest: S.Schema<UpdateMalwareProtectionPlanRequest>;
export interface UpdateMalwareProtectionPlanResponse {
}
export declare const UpdateMalwareProtectionPlanResponse: S.Schema<UpdateMalwareProtectionPlanResponse>;
export interface UpdateMalwareScanSettingsRequest {
    DetectorId: string;
    ScanResourceCriteria?: ScanResourceCriteria;
    EbsSnapshotPreservation?: EbsSnapshotPreservation;
}
export declare const UpdateMalwareScanSettingsRequest: S.Schema<UpdateMalwareScanSettingsRequest>;
export interface UpdateMalwareScanSettingsResponse {
}
export declare const UpdateMalwareScanSettingsResponse: S.Schema<UpdateMalwareScanSettingsResponse>;
export interface MemberAdditionalConfiguration {
    Name?: OrgFeatureAdditionalConfiguration;
    Status?: FeatureStatus;
}
export declare const MemberAdditionalConfiguration: S.Schema<MemberAdditionalConfiguration>;
export type MemberAdditionalConfigurations = MemberAdditionalConfiguration[];
export declare const MemberAdditionalConfigurations: any;
export interface MemberFeaturesConfiguration {
    Name?: OrgFeature;
    Status?: FeatureStatus;
    AdditionalConfiguration?: MemberAdditionalConfiguration[];
}
export declare const MemberFeaturesConfiguration: S.Schema<MemberFeaturesConfiguration>;
export type MemberFeaturesConfigurations = MemberFeaturesConfiguration[];
export declare const MemberFeaturesConfigurations: any;
export interface UpdateMemberDetectorsRequest {
    DetectorId: string;
    AccountIds?: string[];
    DataSources?: DataSourceConfigurations;
    Features?: MemberFeaturesConfiguration[];
}
export declare const UpdateMemberDetectorsRequest: S.Schema<UpdateMemberDetectorsRequest>;
export interface UpdateMemberDetectorsResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export declare const UpdateMemberDetectorsResponse: S.Schema<UpdateMemberDetectorsResponse>;
export interface OrganizationS3LogsConfiguration {
    AutoEnable?: boolean;
}
export declare const OrganizationS3LogsConfiguration: S.Schema<OrganizationS3LogsConfiguration>;
export interface OrganizationKubernetesAuditLogsConfiguration {
    AutoEnable?: boolean;
}
export declare const OrganizationKubernetesAuditLogsConfiguration: S.Schema<OrganizationKubernetesAuditLogsConfiguration>;
export interface OrganizationKubernetesConfiguration {
    AuditLogs?: OrganizationKubernetesAuditLogsConfiguration;
}
export declare const OrganizationKubernetesConfiguration: S.Schema<OrganizationKubernetesConfiguration>;
export interface OrganizationEbsVolumes {
    AutoEnable?: boolean;
}
export declare const OrganizationEbsVolumes: S.Schema<OrganizationEbsVolumes>;
export interface OrganizationScanEc2InstanceWithFindings {
    EbsVolumes?: OrganizationEbsVolumes;
}
export declare const OrganizationScanEc2InstanceWithFindings: S.Schema<OrganizationScanEc2InstanceWithFindings>;
export interface OrganizationMalwareProtectionConfiguration {
    ScanEc2InstanceWithFindings?: OrganizationScanEc2InstanceWithFindings;
}
export declare const OrganizationMalwareProtectionConfiguration: S.Schema<OrganizationMalwareProtectionConfiguration>;
export interface OrganizationDataSourceConfigurations {
    S3Logs?: OrganizationS3LogsConfiguration;
    Kubernetes?: OrganizationKubernetesConfiguration;
    MalwareProtection?: OrganizationMalwareProtectionConfiguration;
}
export declare const OrganizationDataSourceConfigurations: S.Schema<OrganizationDataSourceConfigurations>;
export interface OrganizationAdditionalConfiguration {
    Name?: OrgFeatureAdditionalConfiguration;
    AutoEnable?: OrgFeatureStatus;
}
export declare const OrganizationAdditionalConfiguration: S.Schema<OrganizationAdditionalConfiguration>;
export type OrganizationAdditionalConfigurations = OrganizationAdditionalConfiguration[];
export declare const OrganizationAdditionalConfigurations: any;
export interface OrganizationFeatureConfiguration {
    Name?: OrgFeature;
    AutoEnable?: OrgFeatureStatus;
    AdditionalConfiguration?: OrganizationAdditionalConfiguration[];
}
export declare const OrganizationFeatureConfiguration: S.Schema<OrganizationFeatureConfiguration>;
export type OrganizationFeaturesConfigurations = OrganizationFeatureConfiguration[];
export declare const OrganizationFeaturesConfigurations: any;
export interface UpdateOrganizationConfigurationRequest {
    DetectorId: string;
    AutoEnable?: boolean;
    DataSources?: OrganizationDataSourceConfigurations;
    Features?: OrganizationFeatureConfiguration[];
    AutoEnableOrganizationMembers?: AutoEnableMembers;
}
export declare const UpdateOrganizationConfigurationRequest: S.Schema<UpdateOrganizationConfigurationRequest>;
export interface UpdateOrganizationConfigurationResponse {
}
export declare const UpdateOrganizationConfigurationResponse: S.Schema<UpdateOrganizationConfigurationResponse>;
export interface UpdatePublishingDestinationRequest {
    DetectorId: string;
    DestinationId: string;
    DestinationProperties?: DestinationProperties;
}
export declare const UpdatePublishingDestinationRequest: S.Schema<UpdatePublishingDestinationRequest>;
export interface UpdatePublishingDestinationResponse {
}
export declare const UpdatePublishingDestinationResponse: S.Schema<UpdatePublishingDestinationResponse>;
export interface UpdateThreatEntitySetRequest {
    DetectorId: string;
    ThreatEntitySetId?: string;
    Name?: string;
    Location?: string;
    ExpectedBucketOwner?: string;
    Activate?: boolean;
}
export declare const UpdateThreatEntitySetRequest: S.Schema<UpdateThreatEntitySetRequest>;
export interface UpdateThreatEntitySetResponse {
}
export declare const UpdateThreatEntitySetResponse: S.Schema<UpdateThreatEntitySetResponse>;
export interface UpdateThreatIntelSetRequest {
    DetectorId: string;
    ThreatIntelSetId: string;
    Name?: string;
    Location?: string;
    Activate?: boolean;
    ExpectedBucketOwner?: string;
}
export declare const UpdateThreatIntelSetRequest: S.Schema<UpdateThreatIntelSetRequest>;
export interface UpdateThreatIntelSetResponse {
}
export declare const UpdateThreatIntelSetResponse: S.Schema<UpdateThreatIntelSetResponse>;
export interface UpdateTrustedEntitySetRequest {
    DetectorId: string;
    TrustedEntitySetId: string;
    Name?: string;
    Location?: string;
    ExpectedBucketOwner?: string;
    Activate?: boolean;
}
export declare const UpdateTrustedEntitySetRequest: S.Schema<UpdateTrustedEntitySetRequest>;
export interface UpdateTrustedEntitySetResponse {
}
export declare const UpdateTrustedEntitySetResponse: S.Schema<UpdateTrustedEntitySetResponse>;
export type AcceptAdministratorInvitationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Accepts the invitation to be a member account and get monitored by a GuardDuty administrator account that sent the invitation.
 */
export declare const acceptAdministratorInvitation: API.OperationMethod<AcceptAdministratorInvitationRequest, AcceptAdministratorInvitationResponse, AcceptAdministratorInvitationError, Credentials | HttpClient.HttpClient>;
export type AcceptInvitationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Accepts the invitation to be monitored by a GuardDuty administrator account.
 */
export declare const acceptInvitation: API.OperationMethod<AcceptInvitationRequest, AcceptInvitationResponse, AcceptInvitationError, Credentials | HttpClient.HttpClient>;
export type ArchiveFindingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Archives GuardDuty findings that are specified by the list of finding IDs.
 *
 * Only the administrator account can archive findings. Member accounts don't have permission to archive findings from their accounts.
 */
export declare const archiveFindings: API.OperationMethod<ArchiveFindingsRequest, ArchiveFindingsResponse, ArchiveFindingsError, Credentials | HttpClient.HttpClient>;
export type CreateDetectorError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a single GuardDuty detector. A detector is a resource that represents the GuardDuty service. To start using GuardDuty, you must create a detector in each Region where you enable the service. You can have only one detector per account per Region. All data sources are enabled in a new detector by default.
 *
 * - When you don't specify any `features`, with an exception to `RUNTIME_MONITORING`, all the optional features are enabled by default.
 *
 * - When you specify some of the `features`, any feature that is not specified in the API call gets enabled by default, with an exception to `RUNTIME_MONITORING`.
 *
 * Specifying both EKS Runtime Monitoring (`EKS_RUNTIME_MONITORING`) and Runtime Monitoring (`RUNTIME_MONITORING`) will cause an error. You can add only one of these two features because Runtime Monitoring already includes the threat detection for Amazon EKS resources. For more information, see Runtime Monitoring.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const createDetector: API.OperationMethod<CreateDetectorRequest, CreateDetectorResponse, CreateDetectorError, Credentials | HttpClient.HttpClient>;
export type CreateFilterError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a filter using the specified finding criteria. The maximum number of saved filters per Amazon Web Services account per Region is 100. For more information, see Quotas for GuardDuty.
 */
export declare const createFilter: API.OperationMethod<CreateFilterRequest, CreateFilterResponse, CreateFilterError, Credentials | HttpClient.HttpClient>;
export type CreateInvestigationError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * This API is currently available as a preview. During the preview, you can initiate up to 10 investigations per account per day, with a total limit of 100 investigations per account. This feature is available in the following Amazon Web Services Regions: US East (N. Virginia), US East (Ohio), US West (Oregon), Canada (Central), Europe (Frankfurt), Europe (Ireland), Europe (London), Europe (Paris), Europe (Stockholm), and Asia Pacific (Tokyo).
 *
 * Initiates a GuardDuty investigation that automatically analyzes security findings, correlates related activity, performs account-level analysis, and produces a structured investigation summary with recommended next steps.
 *
 * Only the administrator account can create an investigation. Member accounts don't have permission to create investigations from their accounts.
 *
 * To use this operation, the `AI_ANALYST` feature must be enabled on your detector.
 *
 * This feature uses Amazon Bedrock models that leverage Cross-Region Inference (CRIS), which automatically selects the optimal Amazon Web Services Region within your geography to process the investigation analysis and generate the investigation report. This maximizes available compute resources, model availability, and delivers the best customer experience. Your data remains stored only in the Region where the investigation request originates, however, investigation data and summary results may be processed outside that Region. All data is transmitted encrypted across Amazon's secure network. For more information, see GuardDuty Investigation.
 */
export declare const createInvestigation: API.OperationMethod<CreateInvestigationRequest, CreateInvestigationResponse, CreateInvestigationError, Credentials | HttpClient.HttpClient>;
export type CreateIPSetError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a new IPSet, which is called a trusted IP list in the console user interface. An IPSet is a list of IP addresses that are trusted for secure communication with Amazon Web Services infrastructure and applications. GuardDuty doesn't generate findings for IP addresses that are included in IPSets. Only users from the administrator account can use this operation.
 */
export declare const createIPSet: API.OperationMethod<CreateIPSetRequest, CreateIPSetResponse, CreateIPSetError, Credentials | HttpClient.HttpClient>;
export type CreateMalwareProtectionPlanError = AccessDeniedException | BadRequestException | ConflictException | InternalServerErrorException | CommonErrors;
/**
 * Creates a new Malware Protection plan for the protected resource.
 *
 * When you create a Malware Protection plan, the Amazon Web Services service terms for GuardDuty Malware Protection apply. For more information, see Amazon Web Services service terms for GuardDuty Malware Protection.
 */
export declare const createMalwareProtectionPlan: API.OperationMethod<CreateMalwareProtectionPlanRequest, CreateMalwareProtectionPlanResponse, CreateMalwareProtectionPlanError, Credentials | HttpClient.HttpClient>;
export type CreateMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates member accounts of the current Amazon Web Services account by specifying a list of Amazon Web Services account IDs. This step is a prerequisite for managing the associated member accounts either by invitation or through an organization.
 *
 * As a delegated administrator, using `CreateMembers` will enable GuardDuty in the added member accounts, with the exception of the organization delegated administrator account. A delegated administrator must enable GuardDuty prior to being added as a member.
 *
 * When you use CreateMembers as an Organizations delegated administrator, GuardDuty applies your organization's auto-enable settings to the member accounts in this request, irrespective of the accounts being new or existing members. For more information about the existing auto-enable settings for your organization, see DescribeOrganizationConfiguration.
 *
 * If you disassociate a member account that was added by invitation, the member account details obtained from this API, including the associated email addresses, will be retained. This is done so that the delegated administrator can invoke the InviteMembers API without the need to invoke the CreateMembers API again. To remove the details associated with a member account, the delegated administrator must invoke the DeleteMembers API.
 *
 * When the member accounts added through Organizations are later disassociated, you (administrator) can't invite them by calling the InviteMembers API. You can create an association with these member accounts again only by calling the CreateMembers API.
 */
export declare const createMembers: API.OperationMethod<CreateMembersRequest, CreateMembersResponse, CreateMembersError, Credentials | HttpClient.HttpClient>;
export type CreatePublishingDestinationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a publishing destination where you can export your GuardDuty findings. Before you start exporting the findings, the destination resource must exist.
 */
export declare const createPublishingDestination: API.OperationMethod<CreatePublishingDestinationRequest, CreatePublishingDestinationResponse, CreatePublishingDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateSampleFindingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Generates sample findings of types specified by the list of finding types. If 'NULL' is specified for `findingTypes`, the API generates sample findings of all supported finding types.
 */
export declare const createSampleFindings: API.OperationMethod<CreateSampleFindingsRequest, CreateSampleFindingsResponse, CreateSampleFindingsError, Credentials | HttpClient.HttpClient>;
export type CreateThreatEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a new threat entity set. In a threat entity set, you can provide known malicious threat entities for your Amazon Web Services environment. GuardDuty generates findings based on the entries in the threat entity sets. Only users of the administrator account can manage entity sets, which automatically apply to member accounts.
 */
export declare const createThreatEntitySet: API.OperationMethod<CreateThreatEntitySetRequest, CreateThreatEntitySetResponse, CreateThreatEntitySetError, Credentials | HttpClient.HttpClient>;
export type CreateThreatIntelSetError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a new ThreatIntelSet. ThreatIntelSets consist of known malicious IP addresses. GuardDuty generates findings based on ThreatIntelSets. Only users of the administrator account can use this operation.
 */
export declare const createThreatIntelSet: API.OperationMethod<CreateThreatIntelSetRequest, CreateThreatIntelSetResponse, CreateThreatIntelSetError, Credentials | HttpClient.HttpClient>;
export type CreateTrustedEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a new trusted entity set. In the trusted entity set, you can provide IP addresses and domains that you believe are secure for communication in your Amazon Web Services environment. GuardDuty will not generate findings for the entries that are specified in a trusted entity set. At any given time, you can have only one trusted entity set.
 *
 * Only users of the administrator account can manage the entity sets, which automatically apply to member accounts.
 */
export declare const createTrustedEntitySet: API.OperationMethod<CreateTrustedEntitySetRequest, CreateTrustedEntitySetResponse, CreateTrustedEntitySetError, Credentials | HttpClient.HttpClient>;
export type DeclineInvitationsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Declines invitations sent to the current member account by Amazon Web Services accounts specified by their account IDs.
 */
export declare const declineInvitations: API.OperationMethod<DeclineInvitationsRequest, DeclineInvitationsResponse, DeclineInvitationsError, Credentials | HttpClient.HttpClient>;
export type DeleteDetectorError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes an Amazon GuardDuty detector that is specified by the detector ID.
 */
export declare const deleteDetector: API.OperationMethod<DeleteDetectorRequest, DeleteDetectorResponse, DeleteDetectorError, Credentials | HttpClient.HttpClient>;
export type DeleteFilterError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes the filter specified by the filter name.
 */
export declare const deleteFilter: API.OperationMethod<DeleteFilterRequest, DeleteFilterResponse, DeleteFilterError, Credentials | HttpClient.HttpClient>;
export type DeleteInvitationsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes invitations sent to the current member account by Amazon Web Services accounts specified by their account IDs.
 */
export declare const deleteInvitations: API.OperationMethod<DeleteInvitationsRequest, DeleteInvitationsResponse, DeleteInvitationsError, Credentials | HttpClient.HttpClient>;
export type DeleteIPSetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes the IPSet specified by the `ipSetId`. IPSets are called trusted IP lists in the console user interface.
 */
export declare const deleteIPSet: API.OperationMethod<DeleteIPSetRequest, DeleteIPSetResponse, DeleteIPSetError, Credentials | HttpClient.HttpClient>;
export type DeleteMalwareProtectionPlanError = AccessDeniedException | BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the Malware Protection plan ID associated with the Malware Protection plan resource. Use this API only when you no longer want to protect the resource associated with this Malware Protection plan ID.
 */
export declare const deleteMalwareProtectionPlan: API.OperationMethod<DeleteMalwareProtectionPlanRequest, DeleteMalwareProtectionPlanResponse, DeleteMalwareProtectionPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes GuardDuty member accounts (to the current GuardDuty administrator account) specified by the account IDs.
 *
 * With `autoEnableOrganizationMembers` configuration for your organization set to `ALL`, you'll receive an error if you attempt to disable GuardDuty for a member account in your organization.
 */
export declare const deleteMembers: API.OperationMethod<DeleteMembersRequest, DeleteMembersResponse, DeleteMembersError, Credentials | HttpClient.HttpClient>;
export type DeletePublishingDestinationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes the publishing definition with the specified `destinationId`.
 */
export declare const deletePublishingDestination: API.OperationMethod<DeletePublishingDestinationRequest, DeletePublishingDestinationResponse, DeletePublishingDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteThreatEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes the threat entity set that is associated with the specified `threatEntitySetId`.
 */
export declare const deleteThreatEntitySet: API.OperationMethod<DeleteThreatEntitySetRequest, DeleteThreatEntitySetResponse, DeleteThreatEntitySetError, Credentials | HttpClient.HttpClient>;
export type DeleteThreatIntelSetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes the ThreatIntelSet specified by the ThreatIntelSet ID.
 */
export declare const deleteThreatIntelSet: API.OperationMethod<DeleteThreatIntelSetRequest, DeleteThreatIntelSetResponse, DeleteThreatIntelSetError, Credentials | HttpClient.HttpClient>;
export type DeleteTrustedEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes the trusted entity set that is associated with the specified `trustedEntitySetId`.
 */
export declare const deleteTrustedEntitySet: API.OperationMethod<DeleteTrustedEntitySetRequest, DeleteTrustedEntitySetResponse, DeleteTrustedEntitySetError, Credentials | HttpClient.HttpClient>;
export type DescribeMalwareScansError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns a list of malware scans. Each member account can view the malware scans for their own accounts. An administrator can view the malware scans for all the member accounts.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const describeMalwareScans: API.PaginatedOperationMethod<DescribeMalwareScansRequest, DescribeMalwareScansResponse, DescribeMalwareScansError, Credentials | HttpClient.HttpClient, Scan>;
export type DescribeOrganizationConfigurationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns information about the account selected as the delegated administrator for GuardDuty.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const describeOrganizationConfiguration: API.PaginatedOperationMethod<DescribeOrganizationConfigurationRequest, DescribeOrganizationConfigurationResponse, DescribeOrganizationConfigurationError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribePublishingDestinationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns information about the publishing destination specified by the provided `destinationId`.
 */
export declare const describePublishingDestination: API.OperationMethod<DescribePublishingDestinationRequest, DescribePublishingDestinationResponse, DescribePublishingDestinationError, Credentials | HttpClient.HttpClient>;
export type DisableOrganizationAdminAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Removes the existing GuardDuty delegated administrator of the organization. Only the organization's management account can run this API operation.
 */
export declare const disableOrganizationAdminAccount: API.OperationMethod<DisableOrganizationAdminAccountRequest, DisableOrganizationAdminAccountResponse, DisableOrganizationAdminAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateFromAdministratorAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Disassociates the current GuardDuty member account from its administrator account.
 *
 * When you disassociate an invited member from a GuardDuty delegated administrator, the member account details obtained from the CreateMembers API, including the associated email addresses, are retained. This is done so that the delegated administrator can invoke the InviteMembers API without the need to invoke the CreateMembers API again. To remove the details associated with a member account, the delegated administrator must invoke the DeleteMembers API.
 *
 * With `autoEnableOrganizationMembers` configuration for your organization set to `ALL`, you'll receive an error if you attempt to disable GuardDuty in a member account.
 */
export declare const disassociateFromAdministratorAccount: API.OperationMethod<DisassociateFromAdministratorAccountRequest, DisassociateFromAdministratorAccountResponse, DisassociateFromAdministratorAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateFromMasterAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Disassociates the current GuardDuty member account from its administrator account.
 *
 * When you disassociate an invited member from a GuardDuty delegated administrator, the member account details obtained from the CreateMembers API, including the associated email addresses, are retained. This is done so that the delegated administrator can invoke the InviteMembers API without the need to invoke the CreateMembers API again. To remove the details associated with a member account, the delegated administrator must invoke the DeleteMembers API.
 */
export declare const disassociateFromMasterAccount: API.OperationMethod<DisassociateFromMasterAccountRequest, DisassociateFromMasterAccountResponse, DisassociateFromMasterAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Disassociates GuardDuty member accounts (from the current administrator account) specified by the account IDs.
 *
 * When you disassociate an invited member from a GuardDuty delegated administrator, the member account details obtained from the CreateMembers API, including the associated email addresses, are retained. This is done so that the delegated administrator can invoke the InviteMembers API without the need to invoke the CreateMembers API again. To remove the details associated with a member account, the delegated administrator must invoke the DeleteMembers API.
 *
 * With `autoEnableOrganizationMembers` configuration for your organization set to `ALL`, you'll receive an error if you attempt to disassociate a member account before removing them from your organization.
 *
 * If you disassociate a member account that was added by invitation, the member account details obtained from this API, including the associated email addresses, will be retained. This is done so that the delegated administrator can invoke the InviteMembers API without the need to invoke the CreateMembers API again. To remove the details associated with a member account, the delegated administrator must invoke the DeleteMembers API.
 *
 * When the member accounts added through Organizations are later disassociated, you (administrator) can't invite them by calling the InviteMembers API. You can create an association with these member accounts again only by calling the CreateMembers API.
 */
export declare const disassociateMembers: API.OperationMethod<DisassociateMembersRequest, DisassociateMembersResponse, DisassociateMembersError, Credentials | HttpClient.HttpClient>;
export type EnableOrganizationAdminAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Designates an Amazon Web Services account within the organization as your GuardDuty delegated administrator. Only the organization's management account can run this API operation.
 */
export declare const enableOrganizationAdminAccount: API.OperationMethod<EnableOrganizationAdminAccountRequest, EnableOrganizationAdminAccountResponse, EnableOrganizationAdminAccountError, Credentials | HttpClient.HttpClient>;
export type GetAdministratorAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Provides the details of the GuardDuty administrator account associated with the current GuardDuty member account.
 *
 * Based on the type of account that runs this API, the following list shows how the API behavior varies:
 *
 * - When the GuardDuty administrator account runs this API, it will return success (`HTTP 200`) but no content.
 *
 * - When a member account runs this API, it will return the details of the GuardDuty administrator account that is associated with this calling member account.
 *
 * - When an individual account (not associated with an organization) runs this API, it will return success (`HTTP 200`) but no content.
 */
export declare const getAdministratorAccount: API.OperationMethod<GetAdministratorAccountRequest, GetAdministratorAccountResponse, GetAdministratorAccountError, Credentials | HttpClient.HttpClient>;
export type GetCoverageStatisticsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves aggregated statistics for your account. If you are a GuardDuty administrator, you can retrieve the statistics for all the resources associated with the active member accounts in your organization who have enabled Runtime Monitoring and have the GuardDuty security agent running on their resources.
 */
export declare const getCoverageStatistics: API.OperationMethod<GetCoverageStatisticsRequest, GetCoverageStatisticsResponse, GetCoverageStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetDetectorError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves a GuardDuty detector specified by the detectorId.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const getDetector: API.OperationMethod<GetDetectorRequest, GetDetectorResponse, GetDetectorError, Credentials | HttpClient.HttpClient>;
export type GetFilterError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns the details of the filter specified by the filter name.
 */
export declare const getFilter: API.OperationMethod<GetFilterRequest, GetFilterResponse, GetFilterError, Credentials | HttpClient.HttpClient>;
export type GetFindingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Describes Amazon GuardDuty findings specified by finding IDs.
 */
export declare const getFindings: API.OperationMethod<GetFindingsRequest, GetFindingsResponse, GetFindingsError, Credentials | HttpClient.HttpClient>;
export type GetFindingsStatisticsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists GuardDuty findings statistics for the specified detector ID.
 *
 * You must provide either `findingStatisticTypes` or `groupBy` parameter, and not both. You can use the `maxResults` and `orderBy` parameters only when using `groupBy`.
 *
 * There might be regional differences because some flags might not be available in all the Regions where GuardDuty is currently supported. For more information, see Regions and endpoints.
 */
export declare const getFindingsStatistics: API.OperationMethod<GetFindingsStatisticsRequest, GetFindingsStatisticsResponse, GetFindingsStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetInvestigationError = AccessDeniedException | BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * This API is currently available as a preview. This feature is available in the following Amazon Web Services Regions: US East (N. Virginia), US East (Ohio), US West (Oregon), Canada (Central), Europe (Frankfurt), Europe (Ireland), Europe (London), Europe (Paris), Europe (Stockholm), and Asia Pacific (Tokyo).
 *
 * Retrieves the results and status of a specific GuardDuty investigation.
 *
 * An administrator account can retrieve any investigation within the organization. Member accounts can only retrieve investigations that belong to them.
 */
export declare const getInvestigation: API.OperationMethod<GetInvestigationRequest, GetInvestigationResponse, GetInvestigationError, Credentials | HttpClient.HttpClient>;
export type GetInvitationsCountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns the count of all GuardDuty membership invitations that were sent to the current member account except the currently accepted invitation.
 */
export declare const getInvitationsCount: API.OperationMethod<GetInvitationsCountRequest, GetInvitationsCountResponse, GetInvitationsCountError, Credentials | HttpClient.HttpClient>;
export type GetIPSetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the IPSet specified by the `ipSetId`.
 */
export declare const getIPSet: API.OperationMethod<GetIPSetRequest, GetIPSetResponse, GetIPSetError, Credentials | HttpClient.HttpClient>;
export type GetMalwareProtectionPlanError = AccessDeniedException | BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the Malware Protection plan details associated with a Malware Protection plan ID.
 */
export declare const getMalwareProtectionPlan: API.OperationMethod<GetMalwareProtectionPlanRequest, GetMalwareProtectionPlanResponse, GetMalwareProtectionPlanError, Credentials | HttpClient.HttpClient>;
export type GetMalwareScanError = BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the detailed information for a specific malware scan. Each member account can view the malware scan details for their own account. An administrator can view malware scan details for all accounts in the organization.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const getMalwareScan: API.OperationMethod<GetMalwareScanRequest, GetMalwareScanResponse, GetMalwareScanError, Credentials | HttpClient.HttpClient>;
export type GetMalwareScanSettingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns the details of the malware scan settings.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const getMalwareScanSettings: API.OperationMethod<GetMalwareScanSettingsRequest, GetMalwareScanSettingsResponse, GetMalwareScanSettingsError, Credentials | HttpClient.HttpClient>;
export type GetMasterAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Provides the details for the GuardDuty administrator account associated with the current GuardDuty member account.
 */
export declare const getMasterAccount: API.OperationMethod<GetMasterAccountRequest, GetMasterAccountResponse, GetMasterAccountError, Credentials | HttpClient.HttpClient>;
export type GetMemberDetectorsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Describes which data sources are enabled for the member account's detector.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const getMemberDetectors: API.OperationMethod<GetMemberDetectorsRequest, GetMemberDetectorsResponse, GetMemberDetectorsError, Credentials | HttpClient.HttpClient>;
export type GetMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves GuardDuty member accounts (of the current GuardDuty administrator account) specified by the account IDs.
 */
export declare const getMembers: API.OperationMethod<GetMembersRequest, GetMembersResponse, GetMembersError, Credentials | HttpClient.HttpClient>;
export type GetOrganizationStatisticsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves how many active member accounts have each feature enabled within GuardDuty. Only a delegated GuardDuty administrator of an organization can run this API.
 *
 * When you create a new organization, it might take up to 24 hours to generate the statistics for the entire organization.
 */
export declare const getOrganizationStatistics: API.OperationMethod<GetOrganizationStatisticsRequest, GetOrganizationStatisticsResponse, GetOrganizationStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetRemainingFreeTrialDaysError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Provides the number of days left for each data source used in the free trial period.
 */
export declare const getRemainingFreeTrialDays: API.OperationMethod<GetRemainingFreeTrialDaysRequest, GetRemainingFreeTrialDaysResponse, GetRemainingFreeTrialDaysError, Credentials | HttpClient.HttpClient>;
export type GetThreatEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the threat entity set associated with the specified `threatEntitySetId`.
 */
export declare const getThreatEntitySet: API.OperationMethod<GetThreatEntitySetRequest, GetThreatEntitySetResponse, GetThreatEntitySetError, Credentials | HttpClient.HttpClient>;
export type GetThreatIntelSetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the ThreatIntelSet that is specified by the ThreatIntelSet ID.
 */
export declare const getThreatIntelSet: API.OperationMethod<GetThreatIntelSetRequest, GetThreatIntelSetResponse, GetThreatIntelSetError, Credentials | HttpClient.HttpClient>;
export type GetTrustedEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the trusted entity set associated with the specified `trustedEntitySetId`.
 */
export declare const getTrustedEntitySet: API.OperationMethod<GetTrustedEntitySetRequest, GetTrustedEntitySetResponse, GetTrustedEntitySetError, Credentials | HttpClient.HttpClient>;
export type GetUsageStatisticsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists Amazon GuardDuty usage statistics over the last 30 days for the specified detector ID. For newly enabled detectors or data sources, the cost returned will include only the usage so far under 30 days. This may differ from the cost metrics in the console, which project usage over 30 days to provide a monthly cost estimate. For more information, see Understanding How Usage Costs are Calculated.
 */
export declare const getUsageStatistics: API.PaginatedOperationMethod<GetUsageStatisticsRequest, GetUsageStatisticsResponse, GetUsageStatisticsError, Credentials | HttpClient.HttpClient, unknown>;
export type InviteMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Invites Amazon Web Services accounts to become members of an organization administered by the Amazon Web Services account that invokes this API. If you are using Amazon Web Services Organizations to manage your GuardDuty environment, this step is not needed. For more information, see Managing accounts with organizations.
 *
 * To invite Amazon Web Services accounts, the first step is to ensure that GuardDuty has been enabled in the potential member accounts. You can now invoke this API to add accounts by invitation. The invited accounts can either accept or decline the invitation from their GuardDuty accounts. Each invited Amazon Web Services account can choose to accept the invitation from only one Amazon Web Services account. For more information, see Managing GuardDuty accounts by invitation.
 *
 * After the invite has been accepted and you choose to disassociate a member account (by using DisassociateMembers) from your account, the details of the member account obtained by invoking CreateMembers, including the associated email addresses, will be retained. This is done so that you can invoke InviteMembers without the need to invoke CreateMembers again. To remove the details associated with a member account, you must also invoke DeleteMembers.
 *
 * If you disassociate a member account that was added by invitation, the member account details obtained from this API, including the associated email addresses, will be retained. This is done so that the delegated administrator can invoke the InviteMembers API without the need to invoke the CreateMembers API again. To remove the details associated with a member account, the delegated administrator must invoke the DeleteMembers API.
 *
 * When the member accounts added through Organizations are later disassociated, you (administrator) can't invite them by calling the InviteMembers API. You can create an association with these member accounts again only by calling the CreateMembers API.
 */
export declare const inviteMembers: API.OperationMethod<InviteMembersRequest, InviteMembersResponse, InviteMembersError, Credentials | HttpClient.HttpClient>;
export type ListCoverageError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists coverage details for your GuardDuty account. If you're a GuardDuty administrator, you can retrieve all resources associated with the active member accounts in your organization.
 *
 * Make sure the accounts have Runtime Monitoring enabled and GuardDuty agent running on their resources.
 */
export declare const listCoverage: API.PaginatedOperationMethod<ListCoverageRequest, ListCoverageResponse, ListCoverageError, Credentials | HttpClient.HttpClient, CoverageResource>;
export type ListDetectorsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists detectorIds of all the existing Amazon GuardDuty detector resources.
 */
export declare const listDetectors: API.PaginatedOperationMethod<ListDetectorsRequest, ListDetectorsResponse, ListDetectorsError, Credentials | HttpClient.HttpClient, DetectorId>;
export type ListFiltersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns a paginated list of the current filters.
 */
export declare const listFilters: API.PaginatedOperationMethod<ListFiltersRequest, ListFiltersResponse, ListFiltersError, Credentials | HttpClient.HttpClient, FilterName>;
export type ListFindingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists GuardDuty findings for the specified detector ID.
 *
 * There might be regional differences because some flags might not be available in all the Regions where GuardDuty is currently supported. For more information, see Regions and endpoints.
 */
export declare const listFindings: API.PaginatedOperationMethod<ListFindingsRequest, ListFindingsResponse, ListFindingsError, Credentials | HttpClient.HttpClient, FindingId>;
export type ListInvestigationsError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * This API is currently available as a preview. This feature is available in the following Amazon Web Services Regions: US East (N. Virginia), US East (Ohio), US West (Oregon), Canada (Central), Europe (Frankfurt), Europe (Ireland), Europe (London), Europe (Paris), Europe (Stockholm), and Asia Pacific (Tokyo).
 *
 * Returns a list of investigations associated with the specified GuardDuty detector.
 *
 * An administrator account sees all investigations across the organization. Member accounts see only the investigations that belong to them.
 */
export declare const listInvestigations: API.PaginatedOperationMethod<ListInvestigationsRequest, ListInvestigationsResponse, ListInvestigationsError, Credentials | HttpClient.HttpClient, InvestigationSummary>;
export type ListInvitationsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists all GuardDuty membership invitations that were sent to the current Amazon Web Services account.
 */
export declare const listInvitations: API.PaginatedOperationMethod<ListInvitationsRequest, ListInvitationsResponse, ListInvitationsError, Credentials | HttpClient.HttpClient, Invitation>;
export type ListIPSetsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists the IPSets of the GuardDuty service specified by the detector ID. If you use this operation from a member account, the IPSets returned are the IPSets from the associated administrator account.
 */
export declare const listIPSets: API.PaginatedOperationMethod<ListIPSetsRequest, ListIPSetsResponse, ListIPSetsError, Credentials | HttpClient.HttpClient, string>;
export type ListMalwareProtectionPlansError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists the Malware Protection plan IDs associated with the protected resources in your Amazon Web Services account.
 */
export declare const listMalwareProtectionPlans: API.OperationMethod<ListMalwareProtectionPlansRequest, ListMalwareProtectionPlansResponse, ListMalwareProtectionPlansError, Credentials | HttpClient.HttpClient>;
export type ListMalwareScansError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns a list of malware scans. Each member account can view the malware scans for their own accounts. An administrator can view the malware scans for all of its members' accounts.
 */
export declare const listMalwareScans: API.PaginatedOperationMethod<ListMalwareScansRequest, ListMalwareScansResponse, ListMalwareScansError, Credentials | HttpClient.HttpClient, MalwareScan>;
export type ListMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists details about all member accounts for the current GuardDuty administrator account.
 */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersRequest, ListMembersResponse, ListMembersError, Credentials | HttpClient.HttpClient, Member>;
export type ListOrganizationAdminAccountsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists the accounts designated as GuardDuty delegated administrators. Only the organization's management account can run this API operation.
 */
export declare const listOrganizationAdminAccounts: API.PaginatedOperationMethod<ListOrganizationAdminAccountsRequest, ListOrganizationAdminAccountsResponse, ListOrganizationAdminAccountsError, Credentials | HttpClient.HttpClient, AdminAccount>;
export type ListPublishingDestinationsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns a list of publishing destinations associated with the specified `detectorId`.
 */
export declare const listPublishingDestinations: API.PaginatedOperationMethod<ListPublishingDestinationsRequest, ListPublishingDestinationsResponse, ListPublishingDestinationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists tags for a resource. Tagging is currently supported for detectors, finding filters, IP sets, threat intel sets, and publishing destination, with a limit of 50 tags per resource. When invoked, this operation returns all assigned tags for a given resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListThreatEntitySetsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists the threat entity sets associated with the specified GuardDuty detector ID. If you use this operation from a member account, the threat entity sets that are returned as a response, belong to the administrator account.
 */
export declare const listThreatEntitySets: API.PaginatedOperationMethod<ListThreatEntitySetsRequest, ListThreatEntitySetsResponse, ListThreatEntitySetsError, Credentials | HttpClient.HttpClient, string>;
export type ListThreatIntelSetsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists the ThreatIntelSets of the GuardDuty service specified by the detector ID. If you use this operation from a member account, the ThreatIntelSets associated with the administrator account are returned.
 */
export declare const listThreatIntelSets: API.PaginatedOperationMethod<ListThreatIntelSetsRequest, ListThreatIntelSetsResponse, ListThreatIntelSetsError, Credentials | HttpClient.HttpClient, string>;
export type ListTrustedEntitySetsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists the trusted entity sets associated with the specified GuardDuty detector ID. If you use this operation from a member account, the trusted entity sets that are returned as a response, belong to the administrator account.
 */
export declare const listTrustedEntitySets: API.PaginatedOperationMethod<ListTrustedEntitySetsRequest, ListTrustedEntitySetsResponse, ListTrustedEntitySetsError, Credentials | HttpClient.HttpClient, string>;
export type SendObjectMalwareScanError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Initiates a malware scan for a specific S3 object. This API allows you to perform on-demand malware scanning of individual objects in S3 buckets that have Malware Protection for S3 enabled.
 *
 * When you use this API, the Amazon Web Services service terms for GuardDuty Malware Protection apply. For more information, see Amazon Web Services service terms for GuardDuty Malware Protection.
 */
export declare const sendObjectMalwareScan: API.OperationMethod<SendObjectMalwareScanRequest, SendObjectMalwareScanResponse, SendObjectMalwareScanError, Credentials | HttpClient.HttpClient>;
export type StartMalwareScanError = BadRequestException | ConflictException | InternalServerErrorException | CommonErrors;
/**
 * Initiates the malware scan. Invoking this API will automatically create the Service-linked role in the corresponding account if the resourceArn belongs to an EC2 instance.
 *
 * When the malware scan starts, you can use the associated scan ID to track the status of the scan. For more information, see ListMalwareScans and GetMalwareScan.
 *
 * When you use this API, the Amazon Web Services service terms for GuardDuty Malware Protection apply. For more information, see Amazon Web Services service terms for GuardDuty Malware Protection.
 */
export declare const startMalwareScan: API.OperationMethod<StartMalwareScanRequest, StartMalwareScanResponse, StartMalwareScanError, Credentials | HttpClient.HttpClient>;
export type StartMonitoringMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Turns on GuardDuty monitoring of the specified member accounts. Use this operation to restart monitoring of accounts that you stopped monitoring with the StopMonitoringMembers operation.
 */
export declare const startMonitoringMembers: API.OperationMethod<StartMonitoringMembersRequest, StartMonitoringMembersResponse, StartMonitoringMembersError, Credentials | HttpClient.HttpClient>;
export type StopMonitoringMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Stops GuardDuty monitoring for the specified member accounts. Use the `StartMonitoringMembers` operation to restart monitoring for those accounts.
 *
 * With `autoEnableOrganizationMembers` configuration for your organization set to `ALL`, you'll receive an error if you attempt to stop monitoring the member accounts in your organization.
 */
export declare const stopMonitoringMembers: API.OperationMethod<StopMonitoringMembersRequest, StopMonitoringMembersResponse, StopMonitoringMembersError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Adds tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UnarchiveFindingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Unarchives GuardDuty findings specified by the `findingIds`.
 */
export declare const unarchiveFindings: API.OperationMethod<UnarchiveFindingsRequest, UnarchiveFindingsResponse, UnarchiveFindingsError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDetectorError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the GuardDuty detector specified by the detector ID.
 *
 * Specifying both EKS Runtime Monitoring (`EKS_RUNTIME_MONITORING`) and Runtime Monitoring (`RUNTIME_MONITORING`) will cause an error. You can add only one of these two features because Runtime Monitoring already includes the threat detection for Amazon EKS resources. For more information, see Runtime Monitoring.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const updateDetector: API.OperationMethod<UpdateDetectorRequest, UpdateDetectorResponse, UpdateDetectorError, Credentials | HttpClient.HttpClient>;
export type UpdateFilterError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the filter specified by the filter name.
 */
export declare const updateFilter: API.OperationMethod<UpdateFilterRequest, UpdateFilterResponse, UpdateFilterError, Credentials | HttpClient.HttpClient>;
export type UpdateFindingsFeedbackError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Marks the specified GuardDuty findings as useful or not useful.
 */
export declare const updateFindingsFeedback: API.OperationMethod<UpdateFindingsFeedbackRequest, UpdateFindingsFeedbackResponse, UpdateFindingsFeedbackError, Credentials | HttpClient.HttpClient>;
export type UpdateIPSetError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the IPSet specified by the IPSet ID.
 */
export declare const updateIPSet: API.OperationMethod<UpdateIPSetRequest, UpdateIPSetResponse, UpdateIPSetError, Credentials | HttpClient.HttpClient>;
export type UpdateMalwareProtectionPlanError = AccessDeniedException | BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an existing Malware Protection plan resource.
 */
export declare const updateMalwareProtectionPlan: API.OperationMethod<UpdateMalwareProtectionPlanRequest, UpdateMalwareProtectionPlanResponse, UpdateMalwareProtectionPlanError, Credentials | HttpClient.HttpClient>;
export type UpdateMalwareScanSettingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the malware scan settings.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const updateMalwareScanSettings: API.OperationMethod<UpdateMalwareScanSettingsRequest, UpdateMalwareScanSettingsResponse, UpdateMalwareScanSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateMemberDetectorsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Contains information on member accounts to be updated.
 *
 * Specifying both EKS Runtime Monitoring (`EKS_RUNTIME_MONITORING`) and Runtime Monitoring (`RUNTIME_MONITORING`) will cause an error. You can add only one of these two features because Runtime Monitoring already includes the threat detection for Amazon EKS resources. For more information, see Runtime Monitoring.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const updateMemberDetectors: API.OperationMethod<UpdateMemberDetectorsRequest, UpdateMemberDetectorsResponse, UpdateMemberDetectorsError, Credentials | HttpClient.HttpClient>;
export type UpdateOrganizationConfigurationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Configures the delegated administrator account with the provided values. You must provide a value for either `autoEnableOrganizationMembers` or `autoEnable`, but not both.
 *
 * Specifying both EKS Runtime Monitoring (`EKS_RUNTIME_MONITORING`) and Runtime Monitoring (`RUNTIME_MONITORING`) will cause an error. You can add only one of these two features because Runtime Monitoring already includes the threat detection for Amazon EKS resources. For more information, see Runtime Monitoring.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const updateOrganizationConfiguration: API.OperationMethod<UpdateOrganizationConfigurationRequest, UpdateOrganizationConfigurationResponse, UpdateOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdatePublishingDestinationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates information about the publishing destination specified by the `destinationId`.
 */
export declare const updatePublishingDestination: API.OperationMethod<UpdatePublishingDestinationRequest, UpdatePublishingDestinationResponse, UpdatePublishingDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateThreatEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the threat entity set associated with the specified `threatEntitySetId`.
 */
export declare const updateThreatEntitySet: API.OperationMethod<UpdateThreatEntitySetRequest, UpdateThreatEntitySetResponse, UpdateThreatEntitySetError, Credentials | HttpClient.HttpClient>;
export type UpdateThreatIntelSetError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the ThreatIntelSet specified by the ThreatIntelSet ID.
 */
export declare const updateThreatIntelSet: API.OperationMethod<UpdateThreatIntelSetRequest, UpdateThreatIntelSetResponse, UpdateThreatIntelSetError, Credentials | HttpClient.HttpClient>;
export type UpdateTrustedEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the trusted entity set associated with the specified `trustedEntitySetId`.
 */
export declare const updateTrustedEntitySet: API.OperationMethod<UpdateTrustedEntitySetRequest, UpdateTrustedEntitySetResponse, UpdateTrustedEntitySetError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=guardduty.d.ts.map