import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const GatewayTimedOutException_base: S.Class<GatewayTimedOutException, S.TaggedStruct<"GatewayTimedOutException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class GatewayTimedOutException extends /*@__PURE__*/ GatewayTimedOutException_base {
}
declare const InternalServerErrorException_base: S.Class<InternalServerErrorException, S.TaggedStruct<"InternalServerErrorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestException_base: S.Class<TooManyRequestException, S.TaggedStruct<"TooManyRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestException extends /*@__PURE__*/ TooManyRequestException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type FeedId = string;
export type AssociatedResourceName = string;
export type ResourceName = string;
export type S3Uri = string;
export type TemplateUriList = string[];
export declare const TemplateUriList: any;
export interface TemplateGroup {
    name: string;
    templateUris: string[];
}
export declare const TemplateGroup: S.Schema<TemplateGroup>;
export type TemplateGroupList = TemplateGroup[];
export declare const TemplateGroupList: any;
export interface CroppingConfig {
    templateGroups?: TemplateGroup[];
}
export declare const CroppingConfig: S.Schema<CroppingConfig>;
export type ResourceDescription = string;
export type FixtureId = string;
export interface DataSourceConfiguration {
    fixtureId: string;
}
export declare const DataSourceConfiguration: S.Schema<DataSourceConfiguration>;
export interface ClippingConfig {
    callbackMetadata?: string;
    dataSourceConfiguration?: DataSourceConfiguration;
}
export declare const ClippingConfig: S.Schema<ClippingConfig>;
export type TranscriptionLanguage = "eng" | "eng-au" | "eng-gb" | "eng-us" | "fra" | "ita" | "deu" | "spa" | "por" | (string & {});
export declare const TranscriptionLanguage: any;
export interface AspectRatio {
    width: number;
    height: number;
}
export declare const AspectRatio: S.Schema<AspectRatio>;
export type DictionaryId = string;
export type ProfanityFilterMode = "DISABLED" | "CENSOR" | "DROP" | (string & {});
export declare const ProfanityFilterMode: any;
export interface SubtitlingConfig {
    language: TranscriptionLanguage;
    aspectRatio?: AspectRatio;
    dictionary?: string;
    profanityFilter?: ProfanityFilterMode;
}
export declare const SubtitlingConfig: S.Schema<SubtitlingConfig>;
export type OutputConfig = {
    cropping: CroppingConfig;
    clipping?: never;
    subtitling?: never;
} | {
    cropping?: never;
    clipping: ClippingConfig;
    subtitling?: never;
} | {
    cropping?: never;
    clipping?: never;
    subtitling: SubtitlingConfig;
};
export declare const OutputConfig: any;
export type OutputStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const OutputStatus: any;
export interface CreateOutput {
    name: string;
    outputConfig: OutputConfig;
    status: OutputStatus;
    description?: string;
}
export declare const CreateOutput: S.Schema<CreateOutput>;
export type CreateOutputList = CreateOutput[];
export declare const CreateOutputList: any;
export interface AssociateFeedRequest {
    id: string;
    associatedResourceName: string;
    outputs: CreateOutput[];
    dryRun?: boolean;
}
export declare const AssociateFeedRequest: S.Schema<AssociateFeedRequest>;
export type FeedArn = string;
export interface AssociateFeedResponse {
    arn: string;
    id: string;
}
export declare const AssociateFeedResponse: S.Schema<AssociateFeedResponse>;
export type DictionaryLanguage = "eng" | "fra" | "ita" | "deu" | "spa" | "por" | (string & {});
export declare const DictionaryLanguage: any;
export type DictionaryEntriesPayload = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateDictionaryRequest {
    name: string;
    language: DictionaryLanguage;
    entries?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDictionaryRequest: S.Schema<CreateDictionaryRequest>;
export type DictionaryArn = string;
export type DictionaryStatus = "CREATING" | "AVAILABLE" | "REFERENCED" | "DELETING" | "DELETED" | (string & {});
export declare const DictionaryStatus: any;
export type FeedReferences = string[];
export declare const FeedReferences: any;
export interface CreateDictionaryResponse {
    name: string;
    arn: string;
    id: string;
    language: DictionaryLanguage;
    status: DictionaryStatus;
    references?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDictionaryResponse: S.Schema<CreateDictionaryResponse>;
export type IamRoleArn = string;
export interface CreateFeedRequest {
    name: string;
    accessRoleArn?: string;
    outputs: CreateOutput[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateFeedRequest: S.Schema<CreateFeedRequest>;
export type StringList = string[];
export declare const StringList: any;
export interface GetOutput {
    name: string;
    outputConfig: OutputConfig;
    status: OutputStatus;
    description?: string;
    fromAssociation?: boolean;
}
export declare const GetOutput: S.Schema<GetOutput>;
export type GetOutputList = GetOutput[];
export declare const GetOutputList: any;
export type FeedStatus = "CREATING" | "AVAILABLE" | "ACTIVE" | "UPDATING" | "DELETING" | "DELETED" | "ARCHIVED" | (string & {});
export declare const FeedStatus: any;
export interface FeedAssociation {
    associatedResourceName: string;
}
export declare const FeedAssociation: S.Schema<FeedAssociation>;
export interface CreateFeedResponse {
    arn: string;
    name: string;
    id: string;
    dataEndpoints: string[];
    outputs: GetOutput[];
    accessRoleArn?: string;
    status: FeedStatus;
    association?: FeedAssociation;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateFeedResponse: S.Schema<CreateFeedResponse>;
export interface DeleteDictionaryRequest {
    id: string;
}
export declare const DeleteDictionaryRequest: S.Schema<DeleteDictionaryRequest>;
export interface DeleteDictionaryResponse {
    arn: string;
    id: string;
    status: DictionaryStatus;
}
export declare const DeleteDictionaryResponse: S.Schema<DeleteDictionaryResponse>;
export interface DeleteFeedRequest {
    id: string;
}
export declare const DeleteFeedRequest: S.Schema<DeleteFeedRequest>;
export interface DeleteFeedResponse {
    arn: string;
    id: string;
    status: FeedStatus;
}
export declare const DeleteFeedResponse: S.Schema<DeleteFeedResponse>;
export interface DisassociateFeedRequest {
    id: string;
    associatedResourceName: string;
    dryRun?: boolean;
}
export declare const DisassociateFeedRequest: S.Schema<DisassociateFeedRequest>;
export interface DisassociateFeedResponse {
    arn: string;
    id: string;
}
export declare const DisassociateFeedResponse: S.Schema<DisassociateFeedResponse>;
export interface ExportDictionaryEntriesRequest {
    id: string;
}
export declare const ExportDictionaryEntriesRequest: S.Schema<ExportDictionaryEntriesRequest>;
export interface ExportDictionaryEntriesResponse {
    entries?: string;
}
export declare const ExportDictionaryEntriesResponse: S.Schema<ExportDictionaryEntriesResponse>;
export interface GetDictionaryRequest {
    id: string;
}
export declare const GetDictionaryRequest: S.Schema<GetDictionaryRequest>;
export interface GetDictionaryResponse {
    name: string;
    arn: string;
    id: string;
    language: DictionaryLanguage;
    status: DictionaryStatus;
    references?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetDictionaryResponse: S.Schema<GetDictionaryResponse>;
export interface GetFeedRequest {
    id: string;
}
export declare const GetFeedRequest: S.Schema<GetFeedRequest>;
export interface GetFeedResponse {
    arn: string;
    name: string;
    id: string;
    dataEndpoints: string[];
    outputs: GetOutput[];
    accessRoleArn?: string;
    status: FeedStatus;
    association?: FeedAssociation;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetFeedResponse: S.Schema<GetFeedResponse>;
export interface GetFixtureRequest {
    fixtureId: string;
}
export declare const GetFixtureRequest: S.Schema<GetFixtureRequest>;
export interface Competitor {
    name?: string;
    isHome?: boolean;
}
export declare const Competitor: S.Schema<Competitor>;
export type CompetitorList = Competitor[];
export declare const CompetitorList: any;
export interface GetFixtureResponse {
    fixtureId: string;
    name: string;
    fixtureGroup?: string;
    scheduledStart?: Date;
    status: string;
    competitors: Competitor[];
}
export declare const GetFixtureResponse: S.Schema<GetFixtureResponse>;
export interface ListDictionariesRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDictionariesRequest: S.Schema<ListDictionariesRequest>;
export interface DictionarySummary {
    arn: string;
    id: string;
    name: string;
    language: DictionaryLanguage;
    status: DictionaryStatus;
}
export declare const DictionarySummary: S.Schema<DictionarySummary>;
export type DictionarySummaryList = DictionarySummary[];
export declare const DictionarySummaryList: any;
export interface ListDictionariesResponse {
    dictionaries: DictionarySummary[];
    nextToken?: string;
}
export declare const ListDictionariesResponse: S.Schema<ListDictionariesResponse>;
export interface ListFeedsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListFeedsRequest: S.Schema<ListFeedsRequest>;
export interface FeedSummary {
    arn: string;
    id: string;
    name: string;
    association?: FeedAssociation;
    status: FeedStatus;
}
export declare const FeedSummary: S.Schema<FeedSummary>;
export type FeedSummaryList = FeedSummary[];
export declare const FeedSummaryList: any;
export interface ListFeedsResponse {
    feeds: FeedSummary[];
    nextToken?: string;
}
export declare const ListFeedsResponse: S.Schema<ListFeedsResponse>;
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type DataSourceSport = "basketball" | "american-football" | (string & {});
export declare const DataSourceSport: any;
export type FixtureDate = string;
export type FilterName = "COMPETITOR" | (string & {});
export declare const FilterName: any;
export type FilterValue = string;
export type FilterValueList = string[];
export declare const FilterValueList: any;
export interface SearchFilter {
    name: FilterName;
    values: string[];
}
export declare const SearchFilter: S.Schema<SearchFilter>;
export type SearchFilterList = SearchFilter[];
export declare const SearchFilterList: any;
export interface SearchFixturesRequest {
    sport: DataSourceSport;
    startDate: string;
    endDate?: string;
    filters?: SearchFilter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const SearchFixturesRequest: S.Schema<SearchFixturesRequest>;
export interface FixtureSummary {
    fixtureId: string;
    name: string;
    fixtureGroup?: string;
    scheduledStart?: Date;
    status: string;
    competitors: Competitor[];
}
export declare const FixtureSummary: S.Schema<FixtureSummary>;
export type FixtureSummaryList = FixtureSummary[];
export declare const FixtureSummaryList: any;
export interface SearchFixturesResponse {
    fixtures: FixtureSummary[];
    nextToken?: string;
}
export declare const SearchFixturesResponse: S.Schema<SearchFixturesResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateDictionaryRequest {
    id: string;
    name?: string;
    language?: DictionaryLanguage;
    entries?: string;
}
export declare const UpdateDictionaryRequest: S.Schema<UpdateDictionaryRequest>;
export interface UpdateDictionaryResponse {
    name: string;
    arn: string;
    id: string;
    language: DictionaryLanguage;
    status: DictionaryStatus;
    references?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateDictionaryResponse: S.Schema<UpdateDictionaryResponse>;
export interface UpdateOutput {
    name: string;
    outputConfig: OutputConfig;
    status: OutputStatus;
    description?: string;
    fromAssociation?: boolean;
}
export declare const UpdateOutput: S.Schema<UpdateOutput>;
export type UpdateOutputList = UpdateOutput[];
export declare const UpdateOutputList: any;
export interface UpdateFeedRequest {
    name: string;
    accessRoleArn?: string;
    id: string;
    outputs: UpdateOutput[];
}
export declare const UpdateFeedRequest: S.Schema<UpdateFeedRequest>;
export interface UpdateFeedResponse {
    arn: string;
    name: string;
    id: string;
    dataEndpoints: string[];
    outputs: GetOutput[];
    accessRoleArn?: string;
    status: FeedStatus;
    association?: FeedAssociation;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateFeedResponse: S.Schema<UpdateFeedResponse>;
export type AssociateFeedError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Associates a resource with the feed. The resource provides the input that Elemental Inference needs in order to perform an Elemental Inference feature, such as cropping video. You always provide the resource by associating it with a feed. You can associate only one resource with each feed. With an association, a specific source media is claiming ownership of the feed.
 *
 * AssociateFeed is a PATCH operation, which means that you can include only parameters that you want to change. Parameters that you don't include will not be affected by the operation.
 *
 * Specifically:
 *
 * - You can add more outputs to the existing outputs. New outputs will be appended.
 *
 * - You can't modify an existing output (for example to change its name). Instead, use UpdateFeed.
 *
 * - You can't delete an existing output. Instead, use UpdateFeed.
 *
 * Also note that you can't change the feed name with AssociateFeed. Instead, use UpdateFeed.
 */
export declare const associateFeed: API.OperationMethod<AssociateFeedRequest, AssociateFeedResponse, AssociateFeedError, Credentials | HttpClient.HttpClient>;
export type CreateDictionaryError = AccessDeniedException | ConflictException | InternalServerErrorException | ServiceQuotaExceededException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Creates a custom dictionary for improving transcription accuracy. A dictionary contains custom words and phrases that the ASR engine might not recognize, such as brand names, technical terms, or proper nouns. You can reference a dictionary when configuring a smart subtitles output.
 */
export declare const createDictionary: API.OperationMethod<CreateDictionaryRequest, CreateDictionaryResponse, CreateDictionaryError, Credentials | HttpClient.HttpClient>;
export type CreateFeedError = AccessDeniedException | ConflictException | InternalServerErrorException | ServiceQuotaExceededException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Creates a feed. The feed is the target for the live media stream that is being sent by the calling application. An example of a calling application is AWS Elemental MediaLive.
 *
 * The key contents of the feed is an array of outputs. Each output represents an Elemental Inference feature. After you create the feed, you must associate a resource with the feed. At that point, you will have a useable feed: resource - feed - output or outputs.
 */
export declare const createFeed: API.OperationMethod<CreateFeedRequest, CreateFeedResponse, CreateFeedError, Credentials | HttpClient.HttpClient>;
export type DeleteDictionaryError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Deletes the specified dictionary. You cannot delete a dictionary that is referenced by a feed. You must first remove the dictionary reference from the feed's subtitling configuration.
 */
export declare const deleteDictionary: API.OperationMethod<DeleteDictionaryRequest, DeleteDictionaryResponse, DeleteDictionaryError, Credentials | HttpClient.HttpClient>;
export type DeleteFeedError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Deletes the specified feed. You can delete the feed at any time. Elemental Inference doesn't block you from deleting a feed when the calling application is calling PutMedia or GetMetadata on that feed, although both these calls will start to fail. For more information about managing inactive feeds, see the Elemental Inference User Guide.
 */
export declare const deleteFeed: API.OperationMethod<DeleteFeedRequest, DeleteFeedResponse, DeleteFeedError, Credentials | HttpClient.HttpClient>;
export type DisassociateFeedError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Releases the resource (the source media) that is associated with this feed. The outputs in the feed become DISABLED.
 */
export declare const disassociateFeed: API.OperationMethod<DisassociateFeedRequest, DisassociateFeedResponse, DisassociateFeedError, Credentials | HttpClient.HttpClient>;
export type ExportDictionaryEntriesError = AccessDeniedException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Exports the entries from the specified dictionary.
 */
export declare const exportDictionaryEntries: API.OperationMethod<ExportDictionaryEntriesRequest, ExportDictionaryEntriesResponse, ExportDictionaryEntriesError, Credentials | HttpClient.HttpClient>;
export type GetDictionaryError = AccessDeniedException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified dictionary.
 */
export declare const getDictionary: API.OperationMethod<GetDictionaryRequest, GetDictionaryResponse, GetDictionaryError, Credentials | HttpClient.HttpClient>;
export type GetFeedError = AccessDeniedException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | CommonErrors;
/**
 * Retrieves information about the specified feed.
 */
export declare const getFeed: API.OperationMethod<GetFeedRequest, GetFeedResponse, GetFeedError, Credentials | HttpClient.HttpClient>;
export type GetFixtureError = AccessDeniedException | GatewayTimedOutException | InternalServerErrorException | ResourceNotFoundException | ServiceUnavailableException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified fixture (a sports event, such as a specific basketball game). You obtain a fixtureId from SearchFixtures, or from the clipping output of a feed.
 */
export declare const getFixture: API.OperationMethod<GetFixtureRequest, GetFixtureResponse, GetFixtureError, Credentials | HttpClient.HttpClient>;
export type ListDictionariesError = AccessDeniedException | InternalServerErrorException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Lists the dictionaries in your account.
 */
export declare const listDictionaries: API.PaginatedOperationMethod<ListDictionariesRequest, ListDictionariesResponse, ListDictionariesError, Credentials | HttpClient.HttpClient, DictionarySummary>;
export type ListFeedsError = AccessDeniedException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Displays a list of feeds that belong to this AWS account.
 */
export declare const listFeeds: API.PaginatedOperationMethod<ListFeedsRequest, ListFeedsResponse, ListFeedsError, Credentials | HttpClient.HttpClient, FeedSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * List all tags that are on an Elemental Inference resource in the current region.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type SearchFixturesError = AccessDeniedException | GatewayTimedOutException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Searches for the fixtures (sports events, such as a specific basketball game) that are available for a sport in a date window. Each fixture in the response includes a fixtureId that you specify in the clipping output of a feed, so that Elemental Inference maps the event data for that fixture onto the clipping metadata. This operation is paginated: if there are more fixtures than fit in one page, the response includes a nextToken that you pass in a subsequent request.
 */
export declare const searchFixtures: API.PaginatedOperationMethod<SearchFixturesRequest, SearchFixturesResponse, SearchFixturesError, Credentials | HttpClient.HttpClient, FixtureSummary>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Associates the specified tags to the resource identified by the specified resourceArn in the current region. If existing tags on a resource are not specified in the request parameters, they are not changed. When a resource is deleted, the tags associated with that resource are also deleted.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Deletes specified tags from the specified resource in the current region.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDictionaryError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Updates the specified dictionary.
 */
export declare const updateDictionary: API.OperationMethod<UpdateDictionaryRequest, UpdateDictionaryResponse, UpdateDictionaryError, Credentials | HttpClient.HttpClient>;
export type UpdateFeedError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Updates the name and/or outputs in a feed.
 *
 * UpdateFeed is a PUT operation, which means that the payload that you specify completely overwrites the existing payload.
 *
 * This means that if you want to touch the array of outputs, you must pass in the full new list. So you must omit outputs you want to delete, and include outputs you want to add or modify.
 *
 * If you want to patch the array of outputs to make selective additions, use AssociateFeed.
 */
export declare const updateFeed: API.OperationMethod<UpdateFeedRequest, UpdateFeedResponse, UpdateFeedError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=elementalinference.d.ts.map