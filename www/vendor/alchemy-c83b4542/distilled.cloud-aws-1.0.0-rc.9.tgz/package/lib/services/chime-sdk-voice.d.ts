import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.Class<ForbiddenException, S.TaggedStruct<"ForbiddenException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GoneException_base: S.Class<GoneException, S.TaggedStruct<"GoneException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GoneException extends /*@__PURE__*/ GoneException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceLimitExceededException_base: S.Class<ResourceLimitExceededException, S.TaggedStruct<"ResourceLimitExceededException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ServiceFailureException_base: S.Class<ServiceFailureException, S.TaggedStruct<"ServiceFailureException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceFailureException extends /*@__PURE__*/ ServiceFailureException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottledClientException_base: S.Class<ThrottledClientException, S.TaggedStruct<"ThrottledClientException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottledClientException extends /*@__PURE__*/ ThrottledClientException_base {
}
declare const UnauthorizedClientException_base: S.Class<UnauthorizedClientException, S.TaggedStruct<"UnauthorizedClientException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedClientException extends /*@__PURE__*/ UnauthorizedClientException_base {
}
declare const UnprocessableEntityException_base: S.Class<UnprocessableEntityException, S.TaggedStruct<"UnprocessableEntityException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
export type VoiceConnectorId = string;
export type E164PhoneNumber = string | redacted.Redacted<string>;
export type E164PhoneNumberList = (string | redacted.Redacted<string>)[];
export declare const E164PhoneNumberList: any;
export interface AssociatePhoneNumbersWithVoiceConnectorRequest {
    VoiceConnectorId: string;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
    ForceAssociate?: boolean;
}
export declare const AssociatePhoneNumbersWithVoiceConnectorRequest: S.Schema<AssociatePhoneNumbersWithVoiceConnectorRequest>;
export type SensitiveNonEmptyString = string | redacted.Redacted<string>;
export type ErrorCode = "BadRequest" | "Conflict" | "Forbidden" | "NotFound" | "PreconditionFailed" | "ResourceLimitExceeded" | "ServiceFailure" | "AccessDenied" | "ServiceUnavailable" | "Throttled" | "Throttling" | "Unauthorized" | "Unprocessable" | "VoiceConnectorGroupAssociationsExist" | "PhoneNumberAssociationsExist" | "Gone" | "Validation" | (string & {});
export declare const ErrorCode: any;
export interface PhoneNumberError {
    PhoneNumberId?: string | redacted.Redacted<string>;
    ErrorCode?: ErrorCode;
    ErrorMessage?: string;
}
export declare const PhoneNumberError: S.Schema<PhoneNumberError>;
export type PhoneNumberErrorList = PhoneNumberError[];
export declare const PhoneNumberErrorList: any;
export interface AssociatePhoneNumbersWithVoiceConnectorResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export declare const AssociatePhoneNumbersWithVoiceConnectorResponse: S.Schema<AssociatePhoneNumbersWithVoiceConnectorResponse>;
export type NonEmptyString = string;
export interface AssociatePhoneNumbersWithVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
    ForceAssociate?: boolean;
}
export declare const AssociatePhoneNumbersWithVoiceConnectorGroupRequest: S.Schema<AssociatePhoneNumbersWithVoiceConnectorGroupRequest>;
export interface AssociatePhoneNumbersWithVoiceConnectorGroupResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export declare const AssociatePhoneNumbersWithVoiceConnectorGroupResponse: S.Schema<AssociatePhoneNumbersWithVoiceConnectorGroupResponse>;
export type NonEmptyStringList = string[];
export declare const NonEmptyStringList: any;
export interface BatchDeletePhoneNumberRequest {
    PhoneNumberIds: string[];
}
export declare const BatchDeletePhoneNumberRequest: S.Schema<BatchDeletePhoneNumberRequest>;
export interface BatchDeletePhoneNumberResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export declare const BatchDeletePhoneNumberResponse: S.Schema<BatchDeletePhoneNumberResponse>;
export type PhoneNumberProductType = "VoiceConnector" | "SipMediaApplicationDialIn" | (string & {});
export declare const PhoneNumberProductType: any;
export type CallingName = string | redacted.Redacted<string>;
export type PhoneNumberName = string | redacted.Redacted<string>;
export interface UpdatePhoneNumberRequestItem {
    PhoneNumberId: string | redacted.Redacted<string>;
    ProductType?: PhoneNumberProductType;
    CallingName?: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string>;
}
export declare const UpdatePhoneNumberRequestItem: S.Schema<UpdatePhoneNumberRequestItem>;
export type UpdatePhoneNumberRequestItemList = UpdatePhoneNumberRequestItem[];
export declare const UpdatePhoneNumberRequestItemList: any;
export interface BatchUpdatePhoneNumberRequest {
    UpdatePhoneNumberRequestItems: UpdatePhoneNumberRequestItem[];
}
export declare const BatchUpdatePhoneNumberRequest: S.Schema<BatchUpdatePhoneNumberRequest>;
export interface BatchUpdatePhoneNumberResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export declare const BatchUpdatePhoneNumberResponse: S.Schema<BatchUpdatePhoneNumberResponse>;
export interface CreatePhoneNumberOrderRequest {
    ProductType: PhoneNumberProductType;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
    Name?: string | redacted.Redacted<string>;
}
export declare const CreatePhoneNumberOrderRequest: S.Schema<CreatePhoneNumberOrderRequest>;
export type GuidString = string;
export type PhoneNumberOrderStatus = "Processing" | "Successful" | "Failed" | "Partial" | "PendingDocuments" | "Submitted" | "FOC" | "ChangeRequested" | "Exception" | "CancelRequested" | "Cancelled" | (string & {});
export declare const PhoneNumberOrderStatus: any;
export type PhoneNumberOrderType = "New" | "Porting" | (string & {});
export declare const PhoneNumberOrderType: any;
export type OrderedPhoneNumberStatus = "Processing" | "Acquired" | "Failed" | (string & {});
export declare const OrderedPhoneNumberStatus: any;
export interface OrderedPhoneNumber {
    E164PhoneNumber?: string | redacted.Redacted<string>;
    Status?: OrderedPhoneNumberStatus;
}
export declare const OrderedPhoneNumber: S.Schema<OrderedPhoneNumber>;
export type OrderedPhoneNumberList = OrderedPhoneNumber[];
export declare const OrderedPhoneNumberList: any;
export type Iso8601Timestamp = Date;
export interface PhoneNumberOrder {
    PhoneNumberOrderId?: string;
    ProductType?: PhoneNumberProductType;
    Status?: PhoneNumberOrderStatus;
    OrderType?: PhoneNumberOrderType;
    OrderedPhoneNumbers?: OrderedPhoneNumber[];
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    FocDate?: string;
}
export declare const PhoneNumberOrder: S.Schema<PhoneNumberOrder>;
export interface CreatePhoneNumberOrderResponse {
    PhoneNumberOrder?: PhoneNumberOrder;
}
export declare const CreatePhoneNumberOrderResponse: S.Schema<CreatePhoneNumberOrderResponse>;
export type ParticipantPhoneNumberList = (string | redacted.Redacted<string>)[];
export declare const ParticipantPhoneNumberList: any;
export type ProxySessionNameString = string | redacted.Redacted<string>;
export type PositiveInteger = number;
export type Capability = "Voice" | "SMS" | (string & {});
export declare const Capability: any;
export type CapabilityList = Capability[];
export declare const CapabilityList: any;
export type NumberSelectionBehavior = "PreferSticky" | "AvoidSticky" | (string & {});
export declare const NumberSelectionBehavior: any;
export type GeoMatchLevel = "Country" | "AreaCode" | (string & {});
export declare const GeoMatchLevel: any;
export type Country = string;
export type AreaCode = string;
export interface GeoMatchParams {
    Country: string;
    AreaCode: string;
}
export declare const GeoMatchParams: S.Schema<GeoMatchParams>;
export interface CreateProxySessionRequest {
    VoiceConnectorId: string;
    ParticipantPhoneNumbers: (string | redacted.Redacted<string>)[];
    Name?: string | redacted.Redacted<string>;
    ExpiryMinutes?: number;
    Capabilities: Capability[];
    NumberSelectionBehavior?: NumberSelectionBehavior;
    GeoMatchLevel?: GeoMatchLevel;
    GeoMatchParams?: GeoMatchParams;
}
export declare const CreateProxySessionRequest: S.Schema<CreateProxySessionRequest>;
export type NonEmptyString128 = string;
export type String128 = string;
export type ProxySessionStatus = "Open" | "InProgress" | "Closed" | (string & {});
export declare const ProxySessionStatus: any;
export interface Participant {
    PhoneNumber?: string | redacted.Redacted<string>;
    ProxyPhoneNumber?: string | redacted.Redacted<string>;
}
export declare const Participant: S.Schema<Participant>;
export type Participants = Participant[];
export declare const Participants: any;
export interface ProxySession {
    VoiceConnectorId?: string;
    ProxySessionId?: string;
    Name?: string;
    Status?: ProxySessionStatus;
    ExpiryMinutes?: number;
    Capabilities?: Capability[];
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    EndedTimestamp?: Date;
    Participants?: Participant[];
    NumberSelectionBehavior?: NumberSelectionBehavior;
    GeoMatchLevel?: GeoMatchLevel;
    GeoMatchParams?: GeoMatchParams;
}
export declare const ProxySession: S.Schema<ProxySession>;
export interface CreateProxySessionResponse {
    ProxySession?: ProxySession;
}
export declare const CreateProxySessionResponse: S.Schema<CreateProxySessionResponse>;
export type SipMediaApplicationName = string;
export type FunctionArn = string | redacted.Redacted<string>;
export interface SipMediaApplicationEndpoint {
    LambdaArn?: string | redacted.Redacted<string>;
}
export declare const SipMediaApplicationEndpoint: S.Schema<SipMediaApplicationEndpoint>;
export type SipMediaApplicationEndpointList = SipMediaApplicationEndpoint[];
export declare const SipMediaApplicationEndpointList: any;
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    Key: string | redacted.Redacted<string>;
    Value: string | redacted.Redacted<string>;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateSipMediaApplicationRequest {
    AwsRegion: string;
    Name: string;
    Endpoints: SipMediaApplicationEndpoint[];
    Tags?: Tag[];
}
export declare const CreateSipMediaApplicationRequest: S.Schema<CreateSipMediaApplicationRequest>;
export interface SipMediaApplication {
    SipMediaApplicationId?: string;
    AwsRegion?: string;
    Name?: string;
    Endpoints?: SipMediaApplicationEndpoint[];
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    SipMediaApplicationArn?: string;
}
export declare const SipMediaApplication: S.Schema<SipMediaApplication>;
export interface CreateSipMediaApplicationResponse {
    SipMediaApplication?: SipMediaApplication;
}
export declare const CreateSipMediaApplicationResponse: S.Schema<CreateSipMediaApplicationResponse>;
export type SensitiveString = string | redacted.Redacted<string>;
export type SipHeadersMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const SipHeadersMap: any;
export type SMACreateCallArgumentsMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const SMACreateCallArgumentsMap: any;
export interface CreateSipMediaApplicationCallRequest {
    FromPhoneNumber: string | redacted.Redacted<string>;
    ToPhoneNumber: string | redacted.Redacted<string>;
    SipMediaApplicationId: string;
    SipHeaders?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    ArgumentsMap?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export declare const CreateSipMediaApplicationCallRequest: S.Schema<CreateSipMediaApplicationCallRequest>;
export interface SipMediaApplicationCall {
    TransactionId?: string;
}
export declare const SipMediaApplicationCall: S.Schema<SipMediaApplicationCall>;
export interface CreateSipMediaApplicationCallResponse {
    SipMediaApplicationCall?: SipMediaApplicationCall;
}
export declare const CreateSipMediaApplicationCallResponse: S.Schema<CreateSipMediaApplicationCallResponse>;
export type SipRuleName = string;
export type SipRuleTriggerType = "ToPhoneNumber" | "RequestUriHostname" | (string & {});
export declare const SipRuleTriggerType: any;
export type SipApplicationPriority = number;
export interface SipRuleTargetApplication {
    SipMediaApplicationId?: string;
    Priority?: number;
    AwsRegion?: string;
}
export declare const SipRuleTargetApplication: S.Schema<SipRuleTargetApplication>;
export type SipRuleTargetApplicationList = SipRuleTargetApplication[];
export declare const SipRuleTargetApplicationList: any;
export interface CreateSipRuleRequest {
    Name: string;
    TriggerType: SipRuleTriggerType;
    TriggerValue: string;
    Disabled?: boolean;
    TargetApplications: SipRuleTargetApplication[];
}
export declare const CreateSipRuleRequest: S.Schema<CreateSipRuleRequest>;
export interface SipRule {
    SipRuleId?: string;
    Name?: string;
    Disabled?: boolean;
    TriggerType?: SipRuleTriggerType;
    TriggerValue?: string;
    TargetApplications?: SipRuleTargetApplication[];
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export declare const SipRule: S.Schema<SipRule>;
export interface CreateSipRuleResponse {
    SipRule?: SipRule;
}
export declare const CreateSipRuleResponse: S.Schema<CreateSipRuleResponse>;
export type VoiceConnectorName = string;
export type VoiceConnectorAwsRegion = "us-east-1" | "us-west-2" | "ca-central-1" | "eu-central-1" | "eu-west-1" | "eu-west-2" | "ap-northeast-2" | "ap-northeast-1" | "ap-southeast-1" | "ap-southeast-2" | (string & {});
export declare const VoiceConnectorAwsRegion: any;
export type VoiceConnectorIntegrationType = "CONNECT_CALL_TRANSFER_CONNECTOR" | "CONNECT_ANALYTICS_CONNECTOR" | (string & {});
export declare const VoiceConnectorIntegrationType: any;
export type NetworkType = "IPV4_ONLY" | "DUAL_STACK" | (string & {});
export declare const NetworkType: any;
export interface CreateVoiceConnectorRequest {
    Name: string;
    AwsRegion?: VoiceConnectorAwsRegion;
    RequireEncryption: boolean;
    Tags?: Tag[];
    IntegrationType?: VoiceConnectorIntegrationType;
    NetworkType?: NetworkType;
}
export declare const CreateVoiceConnectorRequest: S.Schema<CreateVoiceConnectorRequest>;
export interface VoiceConnector {
    VoiceConnectorId?: string;
    AwsRegion?: VoiceConnectorAwsRegion;
    Name?: string;
    OutboundHostName?: string;
    RequireEncryption?: boolean;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    VoiceConnectorArn?: string;
    IntegrationType?: VoiceConnectorIntegrationType;
    NetworkType?: NetworkType;
}
export declare const VoiceConnector: S.Schema<VoiceConnector>;
export interface CreateVoiceConnectorResponse {
    VoiceConnector?: VoiceConnector;
}
export declare const CreateVoiceConnectorResponse: S.Schema<CreateVoiceConnectorResponse>;
export type VoiceConnectorGroupName = string;
export type VoiceConnectorItemPriority = number;
export interface VoiceConnectorItem {
    VoiceConnectorId: string;
    Priority?: number;
}
export declare const VoiceConnectorItem: S.Schema<VoiceConnectorItem>;
export type VoiceConnectorItemList = VoiceConnectorItem[];
export declare const VoiceConnectorItemList: any;
export type CallDistributionType = "PriorityWeightedDistribution" | "LoadBalancedDistribution" | (string & {});
export declare const CallDistributionType: any;
export interface CreateVoiceConnectorGroupRequest {
    Name: string;
    VoiceConnectorItems?: VoiceConnectorItem[];
    CallDistributionType?: CallDistributionType;
}
export declare const CreateVoiceConnectorGroupRequest: S.Schema<CreateVoiceConnectorGroupRequest>;
export interface VoiceConnectorGroup {
    VoiceConnectorGroupId?: string;
    Name?: string;
    VoiceConnectorItems?: VoiceConnectorItem[];
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    VoiceConnectorGroupArn?: string;
    CallDistributionType?: CallDistributionType;
}
export declare const VoiceConnectorGroup: S.Schema<VoiceConnectorGroup>;
export interface CreateVoiceConnectorGroupResponse {
    VoiceConnectorGroup?: VoiceConnectorGroup;
}
export declare const CreateVoiceConnectorGroupResponse: S.Schema<CreateVoiceConnectorGroupResponse>;
export type NonEmptyString256 = string;
export interface CreateVoiceProfileRequest {
    SpeakerSearchTaskId: string;
}
export declare const CreateVoiceProfileRequest: S.Schema<CreateVoiceProfileRequest>;
export type Arn = string | redacted.Redacted<string>;
export interface VoiceProfile {
    VoiceProfileId?: string;
    VoiceProfileArn?: string | redacted.Redacted<string>;
    VoiceProfileDomainId?: string;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    ExpirationTimestamp?: Date;
}
export declare const VoiceProfile: S.Schema<VoiceProfile>;
export interface CreateVoiceProfileResponse {
    VoiceProfile?: VoiceProfile;
}
export declare const CreateVoiceProfileResponse: S.Schema<CreateVoiceProfileResponse>;
export type VoiceProfileDomainName = string;
export type VoiceProfileDomainDescription = string;
export interface ServerSideEncryptionConfiguration {
    KmsKeyArn: string | redacted.Redacted<string>;
}
export declare const ServerSideEncryptionConfiguration: S.Schema<ServerSideEncryptionConfiguration>;
export type ClientRequestId = string;
export interface CreateVoiceProfileDomainRequest {
    Name: string;
    Description?: string;
    ServerSideEncryptionConfiguration: ServerSideEncryptionConfiguration;
    ClientRequestToken?: string;
    Tags?: Tag[];
}
export declare const CreateVoiceProfileDomainRequest: S.Schema<CreateVoiceProfileDomainRequest>;
export interface VoiceProfileDomain {
    VoiceProfileDomainId?: string;
    VoiceProfileDomainArn?: string | redacted.Redacted<string>;
    Name?: string;
    Description?: string;
    ServerSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export declare const VoiceProfileDomain: S.Schema<VoiceProfileDomain>;
export interface CreateVoiceProfileDomainResponse {
    VoiceProfileDomain?: VoiceProfileDomain;
}
export declare const CreateVoiceProfileDomainResponse: S.Schema<CreateVoiceProfileDomainResponse>;
export interface DeletePhoneNumberRequest {
    PhoneNumberId: string | redacted.Redacted<string>;
}
export declare const DeletePhoneNumberRequest: S.Schema<DeletePhoneNumberRequest>;
export interface DeletePhoneNumberResponse {
}
export declare const DeletePhoneNumberResponse: S.Schema<DeletePhoneNumberResponse>;
export interface DeleteProxySessionRequest {
    VoiceConnectorId: string;
    ProxySessionId: string;
}
export declare const DeleteProxySessionRequest: S.Schema<DeleteProxySessionRequest>;
export interface DeleteProxySessionResponse {
}
export declare const DeleteProxySessionResponse: S.Schema<DeleteProxySessionResponse>;
export interface DeleteSipMediaApplicationRequest {
    SipMediaApplicationId: string;
}
export declare const DeleteSipMediaApplicationRequest: S.Schema<DeleteSipMediaApplicationRequest>;
export interface DeleteSipMediaApplicationResponse {
}
export declare const DeleteSipMediaApplicationResponse: S.Schema<DeleteSipMediaApplicationResponse>;
export interface DeleteSipRuleRequest {
    SipRuleId: string;
}
export declare const DeleteSipRuleRequest: S.Schema<DeleteSipRuleRequest>;
export interface DeleteSipRuleResponse {
}
export declare const DeleteSipRuleResponse: S.Schema<DeleteSipRuleResponse>;
export interface DeleteVoiceConnectorRequest {
    VoiceConnectorId: string;
}
export declare const DeleteVoiceConnectorRequest: S.Schema<DeleteVoiceConnectorRequest>;
export interface DeleteVoiceConnectorResponse {
}
export declare const DeleteVoiceConnectorResponse: S.Schema<DeleteVoiceConnectorResponse>;
export interface DeleteVoiceConnectorEmergencyCallingConfigurationRequest {
    VoiceConnectorId: string;
}
export declare const DeleteVoiceConnectorEmergencyCallingConfigurationRequest: S.Schema<DeleteVoiceConnectorEmergencyCallingConfigurationRequest>;
export interface DeleteVoiceConnectorEmergencyCallingConfigurationResponse {
}
export declare const DeleteVoiceConnectorEmergencyCallingConfigurationResponse: S.Schema<DeleteVoiceConnectorEmergencyCallingConfigurationResponse>;
export interface DeleteVoiceConnectorExternalSystemsConfigurationRequest {
    VoiceConnectorId: string;
}
export declare const DeleteVoiceConnectorExternalSystemsConfigurationRequest: S.Schema<DeleteVoiceConnectorExternalSystemsConfigurationRequest>;
export interface DeleteVoiceConnectorExternalSystemsConfigurationResponse {
}
export declare const DeleteVoiceConnectorExternalSystemsConfigurationResponse: S.Schema<DeleteVoiceConnectorExternalSystemsConfigurationResponse>;
export interface DeleteVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
}
export declare const DeleteVoiceConnectorGroupRequest: S.Schema<DeleteVoiceConnectorGroupRequest>;
export interface DeleteVoiceConnectorGroupResponse {
}
export declare const DeleteVoiceConnectorGroupResponse: S.Schema<DeleteVoiceConnectorGroupResponse>;
export interface DeleteVoiceConnectorOriginationRequest {
    VoiceConnectorId: string;
}
export declare const DeleteVoiceConnectorOriginationRequest: S.Schema<DeleteVoiceConnectorOriginationRequest>;
export interface DeleteVoiceConnectorOriginationResponse {
}
export declare const DeleteVoiceConnectorOriginationResponse: S.Schema<DeleteVoiceConnectorOriginationResponse>;
export interface DeleteVoiceConnectorProxyRequest {
    VoiceConnectorId: string;
}
export declare const DeleteVoiceConnectorProxyRequest: S.Schema<DeleteVoiceConnectorProxyRequest>;
export interface DeleteVoiceConnectorProxyResponse {
}
export declare const DeleteVoiceConnectorProxyResponse: S.Schema<DeleteVoiceConnectorProxyResponse>;
export interface DeleteVoiceConnectorStreamingConfigurationRequest {
    VoiceConnectorId: string;
}
export declare const DeleteVoiceConnectorStreamingConfigurationRequest: S.Schema<DeleteVoiceConnectorStreamingConfigurationRequest>;
export interface DeleteVoiceConnectorStreamingConfigurationResponse {
}
export declare const DeleteVoiceConnectorStreamingConfigurationResponse: S.Schema<DeleteVoiceConnectorStreamingConfigurationResponse>;
export interface DeleteVoiceConnectorTerminationRequest {
    VoiceConnectorId: string;
}
export declare const DeleteVoiceConnectorTerminationRequest: S.Schema<DeleteVoiceConnectorTerminationRequest>;
export interface DeleteVoiceConnectorTerminationResponse {
}
export declare const DeleteVoiceConnectorTerminationResponse: S.Schema<DeleteVoiceConnectorTerminationResponse>;
export type SensitiveStringList = (string | redacted.Redacted<string>)[];
export declare const SensitiveStringList: any;
export interface DeleteVoiceConnectorTerminationCredentialsRequest {
    VoiceConnectorId: string;
    Usernames: (string | redacted.Redacted<string>)[];
}
export declare const DeleteVoiceConnectorTerminationCredentialsRequest: S.Schema<DeleteVoiceConnectorTerminationCredentialsRequest>;
export interface DeleteVoiceConnectorTerminationCredentialsResponse {
}
export declare const DeleteVoiceConnectorTerminationCredentialsResponse: S.Schema<DeleteVoiceConnectorTerminationCredentialsResponse>;
export interface DeleteVoiceProfileRequest {
    VoiceProfileId: string;
}
export declare const DeleteVoiceProfileRequest: S.Schema<DeleteVoiceProfileRequest>;
export interface DeleteVoiceProfileResponse {
}
export declare const DeleteVoiceProfileResponse: S.Schema<DeleteVoiceProfileResponse>;
export interface DeleteVoiceProfileDomainRequest {
    VoiceProfileDomainId: string;
}
export declare const DeleteVoiceProfileDomainRequest: S.Schema<DeleteVoiceProfileDomainRequest>;
export interface DeleteVoiceProfileDomainResponse {
}
export declare const DeleteVoiceProfileDomainResponse: S.Schema<DeleteVoiceProfileDomainResponse>;
export interface DisassociatePhoneNumbersFromVoiceConnectorRequest {
    VoiceConnectorId: string;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
}
export declare const DisassociatePhoneNumbersFromVoiceConnectorRequest: S.Schema<DisassociatePhoneNumbersFromVoiceConnectorRequest>;
export interface DisassociatePhoneNumbersFromVoiceConnectorResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export declare const DisassociatePhoneNumbersFromVoiceConnectorResponse: S.Schema<DisassociatePhoneNumbersFromVoiceConnectorResponse>;
export interface DisassociatePhoneNumbersFromVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
}
export declare const DisassociatePhoneNumbersFromVoiceConnectorGroupRequest: S.Schema<DisassociatePhoneNumbersFromVoiceConnectorGroupRequest>;
export interface DisassociatePhoneNumbersFromVoiceConnectorGroupResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export declare const DisassociatePhoneNumbersFromVoiceConnectorGroupResponse: S.Schema<DisassociatePhoneNumbersFromVoiceConnectorGroupResponse>;
export interface GetGlobalSettingsRequest {
}
export declare const GetGlobalSettingsRequest: S.Schema<GetGlobalSettingsRequest>;
export type S3BucketName = string;
export interface VoiceConnectorSettings {
    CdrBucket?: string;
}
export declare const VoiceConnectorSettings: S.Schema<VoiceConnectorSettings>;
export interface GetGlobalSettingsResponse {
    VoiceConnector?: VoiceConnectorSettings;
}
export declare const GetGlobalSettingsResponse: S.Schema<GetGlobalSettingsResponse>;
export interface GetPhoneNumberRequest {
    PhoneNumberId: string | redacted.Redacted<string>;
}
export declare const GetPhoneNumberRequest: S.Schema<GetPhoneNumberRequest>;
export type Alpha2CountryCode = string;
export type PhoneNumberType = "Local" | "TollFree" | (string & {});
export declare const PhoneNumberType: any;
export type PhoneNumberStatus = "Cancelled" | "PortinCancelRequested" | "PortinInProgress" | "AcquireInProgress" | "AcquireFailed" | "Unassigned" | "Assigned" | "ReleaseInProgress" | "DeleteInProgress" | "ReleaseFailed" | "DeleteFailed" | (string & {});
export declare const PhoneNumberStatus: any;
export interface PhoneNumberCapabilities {
    InboundCall?: boolean;
    OutboundCall?: boolean;
    InboundSMS?: boolean;
    OutboundSMS?: boolean;
    InboundMMS?: boolean;
    OutboundMMS?: boolean;
}
export declare const PhoneNumberCapabilities: S.Schema<PhoneNumberCapabilities>;
export type PhoneNumberAssociationName = "VoiceConnectorId" | "VoiceConnectorGroupId" | "SipRuleId" | (string & {});
export declare const PhoneNumberAssociationName: any;
export interface PhoneNumberAssociation {
    Value?: string;
    Name?: PhoneNumberAssociationName;
    AssociatedTimestamp?: Date;
}
export declare const PhoneNumberAssociation: S.Schema<PhoneNumberAssociation>;
export type PhoneNumberAssociationList = PhoneNumberAssociation[];
export declare const PhoneNumberAssociationList: any;
export type CallingNameStatus = "Unassigned" | "UpdateInProgress" | "UpdateSucceeded" | "UpdateFailed" | (string & {});
export declare const CallingNameStatus: any;
export interface PhoneNumber {
    PhoneNumberId?: string | redacted.Redacted<string>;
    E164PhoneNumber?: string | redacted.Redacted<string>;
    PhoneNumberArn?: string;
    Country?: string;
    Type?: PhoneNumberType;
    ProductType?: PhoneNumberProductType;
    Status?: PhoneNumberStatus;
    Capabilities?: PhoneNumberCapabilities;
    Associations?: PhoneNumberAssociation[];
    CallingName?: string | redacted.Redacted<string>;
    CallingNameStatus?: CallingNameStatus;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    DeletionTimestamp?: Date;
    OrderId?: string;
    Name?: string | redacted.Redacted<string>;
}
export declare const PhoneNumber: S.Schema<PhoneNumber>;
export interface GetPhoneNumberResponse {
    PhoneNumber?: PhoneNumber;
}
export declare const GetPhoneNumberResponse: S.Schema<GetPhoneNumberResponse>;
export interface GetPhoneNumberOrderRequest {
    PhoneNumberOrderId: string;
}
export declare const GetPhoneNumberOrderRequest: S.Schema<GetPhoneNumberOrderRequest>;
export interface GetPhoneNumberOrderResponse {
    PhoneNumberOrder?: PhoneNumberOrder;
}
export declare const GetPhoneNumberOrderResponse: S.Schema<GetPhoneNumberOrderResponse>;
export interface GetPhoneNumberSettingsRequest {
}
export declare const GetPhoneNumberSettingsRequest: S.Schema<GetPhoneNumberSettingsRequest>;
export interface GetPhoneNumberSettingsResponse {
    CallingName?: string | redacted.Redacted<string>;
    CallingNameUpdatedTimestamp?: Date;
}
export declare const GetPhoneNumberSettingsResponse: S.Schema<GetPhoneNumberSettingsResponse>;
export interface GetProxySessionRequest {
    VoiceConnectorId: string;
    ProxySessionId: string;
}
export declare const GetProxySessionRequest: S.Schema<GetProxySessionRequest>;
export interface GetProxySessionResponse {
    ProxySession?: ProxySession;
}
export declare const GetProxySessionResponse: S.Schema<GetProxySessionResponse>;
export interface GetSipMediaApplicationRequest {
    SipMediaApplicationId: string;
}
export declare const GetSipMediaApplicationRequest: S.Schema<GetSipMediaApplicationRequest>;
export interface GetSipMediaApplicationResponse {
    SipMediaApplication?: SipMediaApplication;
}
export declare const GetSipMediaApplicationResponse: S.Schema<GetSipMediaApplicationResponse>;
export interface GetSipMediaApplicationAlexaSkillConfigurationRequest {
    SipMediaApplicationId: string;
}
export declare const GetSipMediaApplicationAlexaSkillConfigurationRequest: S.Schema<GetSipMediaApplicationAlexaSkillConfigurationRequest>;
export type AlexaSkillStatus = "ACTIVE" | "INACTIVE" | (string & {});
export declare const AlexaSkillStatus: any;
export type AlexaSkillId = string | redacted.Redacted<string>;
export type AlexaSkillIdList = (string | redacted.Redacted<string>)[];
export declare const AlexaSkillIdList: any;
export interface SipMediaApplicationAlexaSkillConfiguration {
    AlexaSkillStatus: AlexaSkillStatus;
    AlexaSkillIds: (string | redacted.Redacted<string>)[];
}
export declare const SipMediaApplicationAlexaSkillConfiguration: S.Schema<SipMediaApplicationAlexaSkillConfiguration>;
export interface GetSipMediaApplicationAlexaSkillConfigurationResponse {
    SipMediaApplicationAlexaSkillConfiguration?: SipMediaApplicationAlexaSkillConfiguration;
}
export declare const GetSipMediaApplicationAlexaSkillConfigurationResponse: S.Schema<GetSipMediaApplicationAlexaSkillConfigurationResponse>;
export interface GetSipMediaApplicationLoggingConfigurationRequest {
    SipMediaApplicationId: string;
}
export declare const GetSipMediaApplicationLoggingConfigurationRequest: S.Schema<GetSipMediaApplicationLoggingConfigurationRequest>;
export interface SipMediaApplicationLoggingConfiguration {
    EnableSipMediaApplicationMessageLogs?: boolean;
}
export declare const SipMediaApplicationLoggingConfiguration: S.Schema<SipMediaApplicationLoggingConfiguration>;
export interface GetSipMediaApplicationLoggingConfigurationResponse {
    SipMediaApplicationLoggingConfiguration?: SipMediaApplicationLoggingConfiguration;
}
export declare const GetSipMediaApplicationLoggingConfigurationResponse: S.Schema<GetSipMediaApplicationLoggingConfigurationResponse>;
export interface GetSipRuleRequest {
    SipRuleId: string;
}
export declare const GetSipRuleRequest: S.Schema<GetSipRuleRequest>;
export interface GetSipRuleResponse {
    SipRule?: SipRule;
}
export declare const GetSipRuleResponse: S.Schema<GetSipRuleResponse>;
export interface GetSpeakerSearchTaskRequest {
    VoiceConnectorId: string;
    SpeakerSearchTaskId: string;
}
export declare const GetSpeakerSearchTaskRequest: S.Schema<GetSpeakerSearchTaskRequest>;
export interface CallDetails {
    VoiceConnectorId?: string;
    TransactionId?: string;
    IsCaller?: boolean;
}
export declare const CallDetails: S.Schema<CallDetails>;
export type ConfidenceScore = number;
export interface SpeakerSearchResult {
    ConfidenceScore?: number;
    VoiceProfileId?: string;
}
export declare const SpeakerSearchResult: S.Schema<SpeakerSearchResult>;
export type SpeakerSearchResultList = SpeakerSearchResult[];
export declare const SpeakerSearchResultList: any;
export interface SpeakerSearchDetails {
    Results?: SpeakerSearchResult[];
    VoiceprintGenerationStatus?: string;
}
export declare const SpeakerSearchDetails: S.Schema<SpeakerSearchDetails>;
export interface SpeakerSearchTask {
    SpeakerSearchTaskId?: string;
    SpeakerSearchTaskStatus?: string;
    CallDetails?: CallDetails;
    SpeakerSearchDetails?: SpeakerSearchDetails;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    StartedTimestamp?: Date;
    StatusMessage?: string;
}
export declare const SpeakerSearchTask: S.Schema<SpeakerSearchTask>;
export interface GetSpeakerSearchTaskResponse {
    SpeakerSearchTask?: SpeakerSearchTask;
}
export declare const GetSpeakerSearchTaskResponse: S.Schema<GetSpeakerSearchTaskResponse>;
export interface GetVoiceConnectorRequest {
    VoiceConnectorId: string;
}
export declare const GetVoiceConnectorRequest: S.Schema<GetVoiceConnectorRequest>;
export interface GetVoiceConnectorResponse {
    VoiceConnector?: VoiceConnector;
}
export declare const GetVoiceConnectorResponse: S.Schema<GetVoiceConnectorResponse>;
export interface GetVoiceConnectorEmergencyCallingConfigurationRequest {
    VoiceConnectorId: string;
}
export declare const GetVoiceConnectorEmergencyCallingConfigurationRequest: S.Schema<GetVoiceConnectorEmergencyCallingConfigurationRequest>;
export interface DNISEmergencyCallingConfiguration {
    EmergencyPhoneNumber: string | redacted.Redacted<string>;
    TestPhoneNumber?: string | redacted.Redacted<string>;
    CallingCountry: string;
}
export declare const DNISEmergencyCallingConfiguration: S.Schema<DNISEmergencyCallingConfiguration>;
export type DNISEmergencyCallingConfigurationList = DNISEmergencyCallingConfiguration[];
export declare const DNISEmergencyCallingConfigurationList: any;
export interface EmergencyCallingConfiguration {
    DNIS?: DNISEmergencyCallingConfiguration[];
}
export declare const EmergencyCallingConfiguration: S.Schema<EmergencyCallingConfiguration>;
export interface GetVoiceConnectorEmergencyCallingConfigurationResponse {
    EmergencyCallingConfiguration?: EmergencyCallingConfiguration;
}
export declare const GetVoiceConnectorEmergencyCallingConfigurationResponse: S.Schema<GetVoiceConnectorEmergencyCallingConfigurationResponse>;
export interface GetVoiceConnectorExternalSystemsConfigurationRequest {
    VoiceConnectorId: string;
}
export declare const GetVoiceConnectorExternalSystemsConfigurationRequest: S.Schema<GetVoiceConnectorExternalSystemsConfigurationRequest>;
export type SessionBorderControllerType = "RIBBON_SBC" | "ORACLE_ACME_PACKET_SBC" | "AVAYA_SBCE" | "CISCO_UNIFIED_BORDER_ELEMENT" | "AUDIOCODES_MEDIANT_SBC" | (string & {});
export declare const SessionBorderControllerType: any;
export type SessionBorderControllerTypeList = SessionBorderControllerType[];
export declare const SessionBorderControllerTypeList: any;
export type ContactCenterSystemType = "GENESYS_ENGAGE_ON_PREMISES" | "AVAYA_AURA_CALL_CENTER_ELITE" | "AVAYA_AURA_CONTACT_CENTER" | "CISCO_UNIFIED_CONTACT_CENTER_ENTERPRISE" | (string & {});
export declare const ContactCenterSystemType: any;
export type ContactCenterSystemTypeList = ContactCenterSystemType[];
export declare const ContactCenterSystemTypeList: any;
export interface ExternalSystemsConfiguration {
    SessionBorderControllerTypes?: SessionBorderControllerType[];
    ContactCenterSystemTypes?: ContactCenterSystemType[];
}
export declare const ExternalSystemsConfiguration: S.Schema<ExternalSystemsConfiguration>;
export interface GetVoiceConnectorExternalSystemsConfigurationResponse {
    ExternalSystemsConfiguration?: ExternalSystemsConfiguration;
}
export declare const GetVoiceConnectorExternalSystemsConfigurationResponse: S.Schema<GetVoiceConnectorExternalSystemsConfigurationResponse>;
export interface GetVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
}
export declare const GetVoiceConnectorGroupRequest: S.Schema<GetVoiceConnectorGroupRequest>;
export interface GetVoiceConnectorGroupResponse {
    VoiceConnectorGroup?: VoiceConnectorGroup;
}
export declare const GetVoiceConnectorGroupResponse: S.Schema<GetVoiceConnectorGroupResponse>;
export interface GetVoiceConnectorLoggingConfigurationRequest {
    VoiceConnectorId: string;
}
export declare const GetVoiceConnectorLoggingConfigurationRequest: S.Schema<GetVoiceConnectorLoggingConfigurationRequest>;
export interface LoggingConfiguration {
    EnableSIPLogs?: boolean;
    EnableMediaMetricLogs?: boolean;
}
export declare const LoggingConfiguration: S.Schema<LoggingConfiguration>;
export interface GetVoiceConnectorLoggingConfigurationResponse {
    LoggingConfiguration?: LoggingConfiguration;
}
export declare const GetVoiceConnectorLoggingConfigurationResponse: S.Schema<GetVoiceConnectorLoggingConfigurationResponse>;
export interface GetVoiceConnectorOriginationRequest {
    VoiceConnectorId: string;
}
export declare const GetVoiceConnectorOriginationRequest: S.Schema<GetVoiceConnectorOriginationRequest>;
export type Port = number;
export type OriginationRouteProtocol = "TCP" | "UDP" | (string & {});
export declare const OriginationRouteProtocol: any;
export type OriginationRoutePriority = number;
export type OriginationRouteWeight = number;
export interface OriginationRoute {
    Host?: string;
    Port?: number;
    Protocol?: OriginationRouteProtocol;
    Priority?: number;
    Weight?: number;
}
export declare const OriginationRoute: S.Schema<OriginationRoute>;
export type OriginationRouteList = OriginationRoute[];
export declare const OriginationRouteList: any;
export interface Origination {
    Routes?: OriginationRoute[];
    Disabled?: boolean;
}
export declare const Origination: S.Schema<Origination>;
export interface GetVoiceConnectorOriginationResponse {
    Origination?: Origination;
}
export declare const GetVoiceConnectorOriginationResponse: S.Schema<GetVoiceConnectorOriginationResponse>;
export interface GetVoiceConnectorProxyRequest {
    VoiceConnectorId: string;
}
export declare const GetVoiceConnectorProxyRequest: S.Schema<GetVoiceConnectorProxyRequest>;
export type StringList = string[];
export declare const StringList: any;
export interface Proxy {
    DefaultSessionExpiryMinutes?: number;
    Disabled?: boolean;
    FallBackPhoneNumber?: string | redacted.Redacted<string>;
    PhoneNumberCountries?: string[];
}
export declare const Proxy: S.Schema<Proxy>;
export interface GetVoiceConnectorProxyResponse {
    Proxy?: Proxy;
}
export declare const GetVoiceConnectorProxyResponse: S.Schema<GetVoiceConnectorProxyResponse>;
export interface GetVoiceConnectorStreamingConfigurationRequest {
    VoiceConnectorId: string;
}
export declare const GetVoiceConnectorStreamingConfigurationRequest: S.Schema<GetVoiceConnectorStreamingConfigurationRequest>;
export type DataRetentionInHours = number;
export type NotificationTarget = "EventBridge" | "SNS" | "SQS" | (string & {});
export declare const NotificationTarget: any;
export interface StreamingNotificationTarget {
    NotificationTarget?: NotificationTarget;
}
export declare const StreamingNotificationTarget: S.Schema<StreamingNotificationTarget>;
export type StreamingNotificationTargetList = StreamingNotificationTarget[];
export declare const StreamingNotificationTargetList: any;
export interface MediaInsightsConfiguration {
    Disabled?: boolean;
    ConfigurationArn?: string | redacted.Redacted<string>;
}
export declare const MediaInsightsConfiguration: S.Schema<MediaInsightsConfiguration>;
export interface StreamingConfiguration {
    DataRetentionInHours: number;
    Disabled: boolean;
    StreamingNotificationTargets?: StreamingNotificationTarget[];
    MediaInsightsConfiguration?: MediaInsightsConfiguration;
}
export declare const StreamingConfiguration: S.Schema<StreamingConfiguration>;
export interface GetVoiceConnectorStreamingConfigurationResponse {
    StreamingConfiguration?: StreamingConfiguration;
}
export declare const GetVoiceConnectorStreamingConfigurationResponse: S.Schema<GetVoiceConnectorStreamingConfigurationResponse>;
export interface GetVoiceConnectorTerminationRequest {
    VoiceConnectorId: string;
}
export declare const GetVoiceConnectorTerminationRequest: S.Schema<GetVoiceConnectorTerminationRequest>;
export type CpsLimit = number;
export type CallingRegion = string;
export type CallingRegionList = string[];
export declare const CallingRegionList: any;
export interface Termination {
    CpsLimit?: number;
    DefaultPhoneNumber?: string | redacted.Redacted<string>;
    CallingRegions?: string[];
    CidrAllowedList?: string[];
    Disabled?: boolean;
}
export declare const Termination: S.Schema<Termination>;
export interface GetVoiceConnectorTerminationResponse {
    Termination?: Termination;
}
export declare const GetVoiceConnectorTerminationResponse: S.Schema<GetVoiceConnectorTerminationResponse>;
export interface GetVoiceConnectorTerminationHealthRequest {
    VoiceConnectorId: string;
}
export declare const GetVoiceConnectorTerminationHealthRequest: S.Schema<GetVoiceConnectorTerminationHealthRequest>;
export interface TerminationHealth {
    Timestamp?: Date;
    Source?: string;
}
export declare const TerminationHealth: S.Schema<TerminationHealth>;
export interface GetVoiceConnectorTerminationHealthResponse {
    TerminationHealth?: TerminationHealth;
}
export declare const GetVoiceConnectorTerminationHealthResponse: S.Schema<GetVoiceConnectorTerminationHealthResponse>;
export interface GetVoiceProfileRequest {
    VoiceProfileId: string;
}
export declare const GetVoiceProfileRequest: S.Schema<GetVoiceProfileRequest>;
export interface GetVoiceProfileResponse {
    VoiceProfile?: VoiceProfile;
}
export declare const GetVoiceProfileResponse: S.Schema<GetVoiceProfileResponse>;
export interface GetVoiceProfileDomainRequest {
    VoiceProfileDomainId: string;
}
export declare const GetVoiceProfileDomainRequest: S.Schema<GetVoiceProfileDomainRequest>;
export interface GetVoiceProfileDomainResponse {
    VoiceProfileDomain?: VoiceProfileDomain;
}
export declare const GetVoiceProfileDomainResponse: S.Schema<GetVoiceProfileDomainResponse>;
export interface GetVoiceToneAnalysisTaskRequest {
    VoiceConnectorId: string;
    VoiceToneAnalysisTaskId: string;
    IsCaller: boolean;
}
export declare const GetVoiceToneAnalysisTaskRequest: S.Schema<GetVoiceToneAnalysisTaskRequest>;
export interface VoiceToneAnalysisTask {
    VoiceToneAnalysisTaskId?: string;
    VoiceToneAnalysisTaskStatus?: string;
    CallDetails?: CallDetails;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    StartedTimestamp?: Date;
    StatusMessage?: string;
}
export declare const VoiceToneAnalysisTask: S.Schema<VoiceToneAnalysisTask>;
export interface GetVoiceToneAnalysisTaskResponse {
    VoiceToneAnalysisTask?: VoiceToneAnalysisTask;
}
export declare const GetVoiceToneAnalysisTaskResponse: S.Schema<GetVoiceToneAnalysisTaskResponse>;
export interface ListAvailableVoiceConnectorRegionsRequest {
}
export declare const ListAvailableVoiceConnectorRegionsRequest: S.Schema<ListAvailableVoiceConnectorRegionsRequest>;
export type VoiceConnectorAwsRegionList = VoiceConnectorAwsRegion[];
export declare const VoiceConnectorAwsRegionList: any;
export interface ListAvailableVoiceConnectorRegionsResponse {
    VoiceConnectorRegions?: VoiceConnectorAwsRegion[];
}
export declare const ListAvailableVoiceConnectorRegionsResponse: S.Schema<ListAvailableVoiceConnectorRegionsResponse>;
export type NextTokenString = string;
export type ResultMax = number;
export interface ListPhoneNumberOrdersRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListPhoneNumberOrdersRequest: S.Schema<ListPhoneNumberOrdersRequest>;
export type PhoneNumberOrderList = PhoneNumberOrder[];
export declare const PhoneNumberOrderList: any;
export interface ListPhoneNumberOrdersResponse {
    PhoneNumberOrders?: PhoneNumberOrder[];
    NextToken?: string;
}
export declare const ListPhoneNumberOrdersResponse: S.Schema<ListPhoneNumberOrdersResponse>;
export interface ListPhoneNumbersRequest {
    Status?: string;
    ProductType?: PhoneNumberProductType;
    FilterName?: PhoneNumberAssociationName;
    FilterValue?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListPhoneNumbersRequest: S.Schema<ListPhoneNumbersRequest>;
export type PhoneNumberList = PhoneNumber[];
export declare const PhoneNumberList: any;
export interface ListPhoneNumbersResponse {
    PhoneNumbers?: PhoneNumber[];
    NextToken?: string;
}
export declare const ListPhoneNumbersResponse: S.Schema<ListPhoneNumbersResponse>;
export interface ListProxySessionsRequest {
    VoiceConnectorId: string;
    Status?: ProxySessionStatus;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListProxySessionsRequest: S.Schema<ListProxySessionsRequest>;
export type ProxySessions = ProxySession[];
export declare const ProxySessions: any;
export interface ListProxySessionsResponse {
    ProxySessions?: ProxySession[];
    NextToken?: string;
}
export declare const ListProxySessionsResponse: S.Schema<ListProxySessionsResponse>;
export interface ListSipMediaApplicationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListSipMediaApplicationsRequest: S.Schema<ListSipMediaApplicationsRequest>;
export type SipMediaApplicationList = SipMediaApplication[];
export declare const SipMediaApplicationList: any;
export interface ListSipMediaApplicationsResponse {
    SipMediaApplications?: SipMediaApplication[];
    NextToken?: string;
}
export declare const ListSipMediaApplicationsResponse: S.Schema<ListSipMediaApplicationsResponse>;
export interface ListSipRulesRequest {
    SipMediaApplicationId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListSipRulesRequest: S.Schema<ListSipRulesRequest>;
export type SipRuleList = SipRule[];
export declare const SipRuleList: any;
export interface ListSipRulesResponse {
    SipRules?: SipRule[];
    NextToken?: string;
}
export declare const ListSipRulesResponse: S.Schema<ListSipRulesResponse>;
export interface ListSupportedPhoneNumberCountriesRequest {
    ProductType: PhoneNumberProductType;
}
export declare const ListSupportedPhoneNumberCountriesRequest: S.Schema<ListSupportedPhoneNumberCountriesRequest>;
export type PhoneNumberTypeList = PhoneNumberType[];
export declare const PhoneNumberTypeList: any;
export interface PhoneNumberCountry {
    CountryCode?: string;
    SupportedPhoneNumberTypes?: PhoneNumberType[];
}
export declare const PhoneNumberCountry: S.Schema<PhoneNumberCountry>;
export type PhoneNumberCountriesList = PhoneNumberCountry[];
export declare const PhoneNumberCountriesList: any;
export interface ListSupportedPhoneNumberCountriesResponse {
    PhoneNumberCountries?: PhoneNumberCountry[];
}
export declare const ListSupportedPhoneNumberCountriesResponse: S.Schema<ListSupportedPhoneNumberCountriesResponse>;
export interface ListTagsForResourceRequest {
    ResourceARN: string | redacted.Redacted<string>;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListVoiceConnectorGroupsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListVoiceConnectorGroupsRequest: S.Schema<ListVoiceConnectorGroupsRequest>;
export type VoiceConnectorGroupList = VoiceConnectorGroup[];
export declare const VoiceConnectorGroupList: any;
export interface ListVoiceConnectorGroupsResponse {
    VoiceConnectorGroups?: VoiceConnectorGroup[];
    NextToken?: string;
}
export declare const ListVoiceConnectorGroupsResponse: S.Schema<ListVoiceConnectorGroupsResponse>;
export interface ListVoiceConnectorsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListVoiceConnectorsRequest: S.Schema<ListVoiceConnectorsRequest>;
export type VoiceConnectorList = VoiceConnector[];
export declare const VoiceConnectorList: any;
export interface ListVoiceConnectorsResponse {
    VoiceConnectors?: VoiceConnector[];
    NextToken?: string;
}
export declare const ListVoiceConnectorsResponse: S.Schema<ListVoiceConnectorsResponse>;
export interface ListVoiceConnectorTerminationCredentialsRequest {
    VoiceConnectorId: string;
}
export declare const ListVoiceConnectorTerminationCredentialsRequest: S.Schema<ListVoiceConnectorTerminationCredentialsRequest>;
export interface ListVoiceConnectorTerminationCredentialsResponse {
    Usernames?: (string | redacted.Redacted<string>)[];
}
export declare const ListVoiceConnectorTerminationCredentialsResponse: S.Schema<ListVoiceConnectorTerminationCredentialsResponse>;
export interface ListVoiceProfileDomainsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListVoiceProfileDomainsRequest: S.Schema<ListVoiceProfileDomainsRequest>;
export interface VoiceProfileDomainSummary {
    VoiceProfileDomainId?: string;
    VoiceProfileDomainArn?: string | redacted.Redacted<string>;
    Name?: string;
    Description?: string;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export declare const VoiceProfileDomainSummary: S.Schema<VoiceProfileDomainSummary>;
export type VoiceProfileDomainSummaryList = VoiceProfileDomainSummary[];
export declare const VoiceProfileDomainSummaryList: any;
export interface ListVoiceProfileDomainsResponse {
    VoiceProfileDomains?: VoiceProfileDomainSummary[];
    NextToken?: string;
}
export declare const ListVoiceProfileDomainsResponse: S.Schema<ListVoiceProfileDomainsResponse>;
export interface ListVoiceProfilesRequest {
    VoiceProfileDomainId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListVoiceProfilesRequest: S.Schema<ListVoiceProfilesRequest>;
export interface VoiceProfileSummary {
    VoiceProfileId?: string;
    VoiceProfileArn?: string | redacted.Redacted<string>;
    VoiceProfileDomainId?: string;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    ExpirationTimestamp?: Date;
}
export declare const VoiceProfileSummary: S.Schema<VoiceProfileSummary>;
export type VoiceProfileSummaryList = VoiceProfileSummary[];
export declare const VoiceProfileSummaryList: any;
export interface ListVoiceProfilesResponse {
    VoiceProfiles?: VoiceProfileSummary[];
    NextToken?: string;
}
export declare const ListVoiceProfilesResponse: S.Schema<ListVoiceProfilesResponse>;
export interface PutSipMediaApplicationAlexaSkillConfigurationRequest {
    SipMediaApplicationId: string;
    SipMediaApplicationAlexaSkillConfiguration?: SipMediaApplicationAlexaSkillConfiguration;
}
export declare const PutSipMediaApplicationAlexaSkillConfigurationRequest: S.Schema<PutSipMediaApplicationAlexaSkillConfigurationRequest>;
export interface PutSipMediaApplicationAlexaSkillConfigurationResponse {
    SipMediaApplicationAlexaSkillConfiguration?: SipMediaApplicationAlexaSkillConfiguration;
}
export declare const PutSipMediaApplicationAlexaSkillConfigurationResponse: S.Schema<PutSipMediaApplicationAlexaSkillConfigurationResponse>;
export interface PutSipMediaApplicationLoggingConfigurationRequest {
    SipMediaApplicationId: string;
    SipMediaApplicationLoggingConfiguration?: SipMediaApplicationLoggingConfiguration;
}
export declare const PutSipMediaApplicationLoggingConfigurationRequest: S.Schema<PutSipMediaApplicationLoggingConfigurationRequest>;
export interface PutSipMediaApplicationLoggingConfigurationResponse {
    SipMediaApplicationLoggingConfiguration?: SipMediaApplicationLoggingConfiguration;
}
export declare const PutSipMediaApplicationLoggingConfigurationResponse: S.Schema<PutSipMediaApplicationLoggingConfigurationResponse>;
export interface PutVoiceConnectorEmergencyCallingConfigurationRequest {
    VoiceConnectorId: string;
    EmergencyCallingConfiguration: EmergencyCallingConfiguration;
}
export declare const PutVoiceConnectorEmergencyCallingConfigurationRequest: S.Schema<PutVoiceConnectorEmergencyCallingConfigurationRequest>;
export interface PutVoiceConnectorEmergencyCallingConfigurationResponse {
    EmergencyCallingConfiguration?: EmergencyCallingConfiguration;
}
export declare const PutVoiceConnectorEmergencyCallingConfigurationResponse: S.Schema<PutVoiceConnectorEmergencyCallingConfigurationResponse>;
export interface PutVoiceConnectorExternalSystemsConfigurationRequest {
    VoiceConnectorId: string;
    SessionBorderControllerTypes?: SessionBorderControllerType[];
    ContactCenterSystemTypes?: ContactCenterSystemType[];
}
export declare const PutVoiceConnectorExternalSystemsConfigurationRequest: S.Schema<PutVoiceConnectorExternalSystemsConfigurationRequest>;
export interface PutVoiceConnectorExternalSystemsConfigurationResponse {
    ExternalSystemsConfiguration?: ExternalSystemsConfiguration;
}
export declare const PutVoiceConnectorExternalSystemsConfigurationResponse: S.Schema<PutVoiceConnectorExternalSystemsConfigurationResponse>;
export interface PutVoiceConnectorLoggingConfigurationRequest {
    VoiceConnectorId: string;
    LoggingConfiguration: LoggingConfiguration;
}
export declare const PutVoiceConnectorLoggingConfigurationRequest: S.Schema<PutVoiceConnectorLoggingConfigurationRequest>;
export interface PutVoiceConnectorLoggingConfigurationResponse {
    LoggingConfiguration?: LoggingConfiguration;
}
export declare const PutVoiceConnectorLoggingConfigurationResponse: S.Schema<PutVoiceConnectorLoggingConfigurationResponse>;
export interface PutVoiceConnectorOriginationRequest {
    VoiceConnectorId: string;
    Origination: Origination;
}
export declare const PutVoiceConnectorOriginationRequest: S.Schema<PutVoiceConnectorOriginationRequest>;
export interface PutVoiceConnectorOriginationResponse {
    Origination?: Origination;
}
export declare const PutVoiceConnectorOriginationResponse: S.Schema<PutVoiceConnectorOriginationResponse>;
export type CountryList = string[];
export declare const CountryList: any;
export interface PutVoiceConnectorProxyRequest {
    VoiceConnectorId: string;
    DefaultSessionExpiryMinutes: number;
    PhoneNumberPoolCountries: string[];
    FallBackPhoneNumber?: string | redacted.Redacted<string>;
    Disabled?: boolean;
}
export declare const PutVoiceConnectorProxyRequest: S.Schema<PutVoiceConnectorProxyRequest>;
export interface PutVoiceConnectorProxyResponse {
    Proxy?: Proxy;
}
export declare const PutVoiceConnectorProxyResponse: S.Schema<PutVoiceConnectorProxyResponse>;
export interface PutVoiceConnectorStreamingConfigurationRequest {
    VoiceConnectorId: string;
    StreamingConfiguration: StreamingConfiguration;
}
export declare const PutVoiceConnectorStreamingConfigurationRequest: S.Schema<PutVoiceConnectorStreamingConfigurationRequest>;
export interface PutVoiceConnectorStreamingConfigurationResponse {
    StreamingConfiguration?: StreamingConfiguration;
}
export declare const PutVoiceConnectorStreamingConfigurationResponse: S.Schema<PutVoiceConnectorStreamingConfigurationResponse>;
export interface PutVoiceConnectorTerminationRequest {
    VoiceConnectorId: string;
    Termination: Termination;
}
export declare const PutVoiceConnectorTerminationRequest: S.Schema<PutVoiceConnectorTerminationRequest>;
export interface PutVoiceConnectorTerminationResponse {
    Termination?: Termination;
}
export declare const PutVoiceConnectorTerminationResponse: S.Schema<PutVoiceConnectorTerminationResponse>;
export interface Credential {
    Username?: string | redacted.Redacted<string>;
    Password?: string | redacted.Redacted<string>;
}
export declare const Credential: S.Schema<Credential>;
export type CredentialList = Credential[];
export declare const CredentialList: any;
export interface PutVoiceConnectorTerminationCredentialsRequest {
    VoiceConnectorId: string;
    Credentials?: Credential[];
}
export declare const PutVoiceConnectorTerminationCredentialsRequest: S.Schema<PutVoiceConnectorTerminationCredentialsRequest>;
export interface PutVoiceConnectorTerminationCredentialsResponse {
}
export declare const PutVoiceConnectorTerminationCredentialsResponse: S.Schema<PutVoiceConnectorTerminationCredentialsResponse>;
export interface RestorePhoneNumberRequest {
    PhoneNumberId: string | redacted.Redacted<string>;
}
export declare const RestorePhoneNumberRequest: S.Schema<RestorePhoneNumberRequest>;
export interface RestorePhoneNumberResponse {
    PhoneNumber?: PhoneNumber;
}
export declare const RestorePhoneNumberResponse: S.Schema<RestorePhoneNumberResponse>;
export type TollFreePrefix = string;
export type PhoneNumberMaxResults = number;
export interface SearchAvailablePhoneNumbersRequest {
    AreaCode?: string;
    City?: string;
    Country?: string;
    State?: string;
    TollFreePrefix?: string;
    PhoneNumberType?: PhoneNumberType;
    MaxResults?: number;
    NextToken?: string;
}
export declare const SearchAvailablePhoneNumbersRequest: S.Schema<SearchAvailablePhoneNumbersRequest>;
export interface SearchAvailablePhoneNumbersResponse {
    E164PhoneNumbers?: (string | redacted.Redacted<string>)[];
    NextToken?: string;
}
export declare const SearchAvailablePhoneNumbersResponse: S.Schema<SearchAvailablePhoneNumbersResponse>;
export type CallLegType = "Caller" | "Callee" | (string & {});
export declare const CallLegType: any;
export interface StartSpeakerSearchTaskRequest {
    VoiceConnectorId: string;
    TransactionId: string;
    VoiceProfileDomainId: string;
    ClientRequestToken?: string;
    CallLeg?: CallLegType;
}
export declare const StartSpeakerSearchTaskRequest: S.Schema<StartSpeakerSearchTaskRequest>;
export interface StartSpeakerSearchTaskResponse {
    SpeakerSearchTask?: SpeakerSearchTask;
}
export declare const StartSpeakerSearchTaskResponse: S.Schema<StartSpeakerSearchTaskResponse>;
export type LanguageCode = "en-US" | (string & {});
export declare const LanguageCode: any;
export interface StartVoiceToneAnalysisTaskRequest {
    VoiceConnectorId: string;
    TransactionId: string;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string;
}
export declare const StartVoiceToneAnalysisTaskRequest: S.Schema<StartVoiceToneAnalysisTaskRequest>;
export interface StartVoiceToneAnalysisTaskResponse {
    VoiceToneAnalysisTask?: VoiceToneAnalysisTask;
}
export declare const StartVoiceToneAnalysisTaskResponse: S.Schema<StartVoiceToneAnalysisTaskResponse>;
export interface StopSpeakerSearchTaskRequest {
    VoiceConnectorId: string;
    SpeakerSearchTaskId: string;
}
export declare const StopSpeakerSearchTaskRequest: S.Schema<StopSpeakerSearchTaskRequest>;
export interface StopSpeakerSearchTaskResponse {
}
export declare const StopSpeakerSearchTaskResponse: S.Schema<StopSpeakerSearchTaskResponse>;
export interface StopVoiceToneAnalysisTaskRequest {
    VoiceConnectorId: string;
    VoiceToneAnalysisTaskId: string;
}
export declare const StopVoiceToneAnalysisTaskRequest: S.Schema<StopVoiceToneAnalysisTaskRequest>;
export interface StopVoiceToneAnalysisTaskResponse {
}
export declare const StopVoiceToneAnalysisTaskResponse: S.Schema<StopVoiceToneAnalysisTaskResponse>;
export interface TagResourceRequest {
    ResourceARN: string | redacted.Redacted<string>;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = (string | redacted.Redacted<string>)[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string | redacted.Redacted<string>;
    TagKeys: (string | redacted.Redacted<string>)[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateGlobalSettingsRequest {
    VoiceConnector: VoiceConnectorSettings;
}
export declare const UpdateGlobalSettingsRequest: S.Schema<UpdateGlobalSettingsRequest>;
export interface UpdateGlobalSettingsResponse {
}
export declare const UpdateGlobalSettingsResponse: S.Schema<UpdateGlobalSettingsResponse>;
export interface UpdatePhoneNumberRequest {
    PhoneNumberId: string | redacted.Redacted<string>;
    ProductType?: PhoneNumberProductType;
    CallingName?: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string>;
}
export declare const UpdatePhoneNumberRequest: S.Schema<UpdatePhoneNumberRequest>;
export interface UpdatePhoneNumberResponse {
    PhoneNumber?: PhoneNumber;
}
export declare const UpdatePhoneNumberResponse: S.Schema<UpdatePhoneNumberResponse>;
export interface UpdatePhoneNumberSettingsRequest {
    CallingName: string | redacted.Redacted<string>;
}
export declare const UpdatePhoneNumberSettingsRequest: S.Schema<UpdatePhoneNumberSettingsRequest>;
export interface UpdatePhoneNumberSettingsResponse {
}
export declare const UpdatePhoneNumberSettingsResponse: S.Schema<UpdatePhoneNumberSettingsResponse>;
export interface UpdateProxySessionRequest {
    VoiceConnectorId: string;
    ProxySessionId: string;
    Capabilities: Capability[];
    ExpiryMinutes?: number;
}
export declare const UpdateProxySessionRequest: S.Schema<UpdateProxySessionRequest>;
export interface UpdateProxySessionResponse {
    ProxySession?: ProxySession;
}
export declare const UpdateProxySessionResponse: S.Schema<UpdateProxySessionResponse>;
export interface UpdateSipMediaApplicationRequest {
    SipMediaApplicationId: string;
    Name?: string;
    Endpoints?: SipMediaApplicationEndpoint[];
}
export declare const UpdateSipMediaApplicationRequest: S.Schema<UpdateSipMediaApplicationRequest>;
export interface UpdateSipMediaApplicationResponse {
    SipMediaApplication?: SipMediaApplication;
}
export declare const UpdateSipMediaApplicationResponse: S.Schema<UpdateSipMediaApplicationResponse>;
export type SMAUpdateCallArgumentsMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const SMAUpdateCallArgumentsMap: any;
export interface UpdateSipMediaApplicationCallRequest {
    SipMediaApplicationId: string;
    TransactionId: string;
    Arguments: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export declare const UpdateSipMediaApplicationCallRequest: S.Schema<UpdateSipMediaApplicationCallRequest>;
export interface UpdateSipMediaApplicationCallResponse {
    SipMediaApplicationCall?: SipMediaApplicationCall;
}
export declare const UpdateSipMediaApplicationCallResponse: S.Schema<UpdateSipMediaApplicationCallResponse>;
export interface UpdateSipRuleRequest {
    SipRuleId: string;
    Name: string;
    Disabled?: boolean;
    TargetApplications?: SipRuleTargetApplication[];
}
export declare const UpdateSipRuleRequest: S.Schema<UpdateSipRuleRequest>;
export interface UpdateSipRuleResponse {
    SipRule?: SipRule;
}
export declare const UpdateSipRuleResponse: S.Schema<UpdateSipRuleResponse>;
export interface UpdateVoiceConnectorRequest {
    VoiceConnectorId: string;
    Name: string;
    RequireEncryption: boolean;
}
export declare const UpdateVoiceConnectorRequest: S.Schema<UpdateVoiceConnectorRequest>;
export interface UpdateVoiceConnectorResponse {
    VoiceConnector?: VoiceConnector;
}
export declare const UpdateVoiceConnectorResponse: S.Schema<UpdateVoiceConnectorResponse>;
export interface UpdateVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
    Name: string;
    VoiceConnectorItems: VoiceConnectorItem[];
    CallDistributionType?: CallDistributionType;
}
export declare const UpdateVoiceConnectorGroupRequest: S.Schema<UpdateVoiceConnectorGroupRequest>;
export interface UpdateVoiceConnectorGroupResponse {
    VoiceConnectorGroup?: VoiceConnectorGroup;
}
export declare const UpdateVoiceConnectorGroupResponse: S.Schema<UpdateVoiceConnectorGroupResponse>;
export interface UpdateVoiceProfileRequest {
    VoiceProfileId: string;
    SpeakerSearchTaskId: string;
}
export declare const UpdateVoiceProfileRequest: S.Schema<UpdateVoiceProfileRequest>;
export interface UpdateVoiceProfileResponse {
    VoiceProfile?: VoiceProfile;
}
export declare const UpdateVoiceProfileResponse: S.Schema<UpdateVoiceProfileResponse>;
export interface UpdateVoiceProfileDomainRequest {
    VoiceProfileDomainId: string;
    Name?: string;
    Description?: string;
}
export declare const UpdateVoiceProfileDomainRequest: S.Schema<UpdateVoiceProfileDomainRequest>;
export interface UpdateVoiceProfileDomainResponse {
    VoiceProfileDomain?: VoiceProfileDomain;
}
export declare const UpdateVoiceProfileDomainResponse: S.Schema<UpdateVoiceProfileDomainResponse>;
export interface ValidateE911AddressRequest {
    AwsAccountId: string;
    StreetNumber: string | redacted.Redacted<string>;
    StreetInfo: string | redacted.Redacted<string>;
    City: string | redacted.Redacted<string>;
    State: string | redacted.Redacted<string>;
    Country: string | redacted.Redacted<string>;
    PostalCode: string | redacted.Redacted<string>;
}
export declare const ValidateE911AddressRequest: S.Schema<ValidateE911AddressRequest>;
export type ValidationResult = number;
export interface Address {
    streetName?: string | redacted.Redacted<string>;
    streetSuffix?: string | redacted.Redacted<string>;
    postDirectional?: string | redacted.Redacted<string>;
    preDirectional?: string | redacted.Redacted<string>;
    streetNumber?: string | redacted.Redacted<string>;
    city?: string | redacted.Redacted<string>;
    state?: string | redacted.Redacted<string>;
    postalCode?: string | redacted.Redacted<string>;
    postalCodePlus4?: string | redacted.Redacted<string>;
    country?: string | redacted.Redacted<string>;
}
export declare const Address: S.Schema<Address>;
export interface CandidateAddress {
    streetInfo?: string | redacted.Redacted<string>;
    streetNumber?: string | redacted.Redacted<string>;
    city?: string | redacted.Redacted<string>;
    state?: string | redacted.Redacted<string>;
    postalCode?: string | redacted.Redacted<string>;
    postalCodePlus4?: string | redacted.Redacted<string>;
    country?: string | redacted.Redacted<string>;
}
export declare const CandidateAddress: S.Schema<CandidateAddress>;
export type CandidateAddressList = CandidateAddress[];
export declare const CandidateAddressList: any;
export interface ValidateE911AddressResponse {
    ValidationResult?: number;
    AddressExternalId?: string;
    Address?: Address;
    CandidateAddressList?: CandidateAddress[];
}
export declare const ValidateE911AddressResponse: S.Schema<ValidateE911AddressResponse>;
export type AssociatePhoneNumbersWithVoiceConnectorError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Associates phone numbers with the specified Amazon Chime SDK Voice Connector.
 */
export declare const associatePhoneNumbersWithVoiceConnector: API.OperationMethod<AssociatePhoneNumbersWithVoiceConnectorRequest, AssociatePhoneNumbersWithVoiceConnectorResponse, AssociatePhoneNumbersWithVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type AssociatePhoneNumbersWithVoiceConnectorGroupError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Associates phone numbers with the specified Amazon Chime SDK Voice Connector group.
 */
export declare const associatePhoneNumbersWithVoiceConnectorGroup: API.OperationMethod<AssociatePhoneNumbersWithVoiceConnectorGroupRequest, AssociatePhoneNumbersWithVoiceConnectorGroupResponse, AssociatePhoneNumbersWithVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type BatchDeletePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Moves phone numbers into the
 * **Deletion queue**. Phone numbers must be disassociated from any users or Amazon Chime SDK Voice Connectors before they can be deleted.
 *
 * Phone numbers remain in the
 * **Deletion queue** for 7 days before they are deleted permanently.
 */
export declare const batchDeletePhoneNumber: API.OperationMethod<BatchDeletePhoneNumberRequest, BatchDeletePhoneNumberResponse, BatchDeletePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type BatchUpdatePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates phone number product types, calling names, or phone number names. You can update one attribute at a time for each
 * `UpdatePhoneNumberRequestItem`. For example, you can update the product type, the calling name, or phone name.
 *
 * You cannot have a duplicate `phoneNumberId` in a request.
 */
export declare const batchUpdatePhoneNumber: API.OperationMethod<BatchUpdatePhoneNumberRequest, BatchUpdatePhoneNumberResponse, BatchUpdatePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type CreatePhoneNumberOrderError = AccessDeniedException | BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an order for phone numbers to be provisioned. For numbers outside the U.S., you must use the Amazon Chime SDK SIP media application dial-in product type.
 */
export declare const createPhoneNumberOrder: API.OperationMethod<CreatePhoneNumberOrderRequest, CreatePhoneNumberOrderResponse, CreatePhoneNumberOrderError, Credentials | HttpClient.HttpClient>;
export type CreateProxySessionError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a proxy session for the specified Amazon Chime SDK Voice Connector for
 * the specified participant phone numbers.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const createProxySession: API.OperationMethod<CreateProxySessionRequest, CreateProxySessionResponse, CreateProxySessionError, Credentials | HttpClient.HttpClient>;
export type CreateSipMediaApplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a SIP media application. For more information about SIP media applications, see Managing SIP media applications
 * and rules in the *Amazon Chime SDK Administrator Guide*.
 */
export declare const createSipMediaApplication: API.OperationMethod<CreateSipMediaApplicationRequest, CreateSipMediaApplicationResponse, CreateSipMediaApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateSipMediaApplicationCallError = AccessDeniedException | BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an outbound call to a phone number from the phone number specified
 * in the request, and it invokes the endpoint of the specified
 * `sipMediaApplicationId`.
 */
export declare const createSipMediaApplicationCall: API.OperationMethod<CreateSipMediaApplicationCallRequest, CreateSipMediaApplicationCallResponse, CreateSipMediaApplicationCallError, Credentials | HttpClient.HttpClient>;
export type CreateSipRuleError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a SIP rule, which can be used to run a SIP media application as a target for a specific trigger type. For more information about SIP rules, see Managing SIP media applications
 * and rules in the *Amazon Chime SDK Administrator Guide*.
 */
export declare const createSipRule: API.OperationMethod<CreateSipRuleRequest, CreateSipRuleResponse, CreateSipRuleError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceConnectorError = AccessDeniedException | BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an Amazon Chime SDK Voice Connector. For more information about
 * Voice Connectors,
 * see Managing Amazon Chime SDK Voice Connector groups in the Amazon Chime SDK
 * Administrator Guide.
 */
export declare const createVoiceConnector: API.OperationMethod<CreateVoiceConnectorRequest, CreateVoiceConnectorResponse, CreateVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceConnectorGroupError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an Amazon Chime SDK Voice Connector group under the administrator's
 * AWS account. You can associate Amazon Chime SDK Voice Connectors with the
 * Voice Connector group by including `VoiceConnectorItems` in the
 * request.
 *
 * You can include Voice Connectors from different AWS Regions in your group.
 * This creates a fault tolerant mechanism for fallback in case of availability events.
 */
export declare const createVoiceConnectorGroup: API.OperationMethod<CreateVoiceConnectorGroupRequest, CreateVoiceConnectorGroupResponse, CreateVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceProfileError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | GoneException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a voice profile, which consists of an enrolled user and their latest voice print.
 *
 * Before creating any voice profiles, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 *
 * For more information about voice profiles and voice analytics, see Using Amazon Chime SDK Voice Analytics
 * in the *Amazon Chime SDK Developer Guide*.
 */
export declare const createVoiceProfile: API.OperationMethod<CreateVoiceProfileRequest, CreateVoiceProfileResponse, CreateVoiceProfileError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceProfileDomainError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a voice profile domain, a collection of voice profiles, their voice prints, and encrypted enrollment audio.
 *
 * Before creating any voice profiles, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 *
 * For more information about voice profile domains, see Using Amazon Chime SDK Voice Analytics
 * in the *Amazon Chime SDK Developer Guide*.
 */
export declare const createVoiceProfileDomain: API.OperationMethod<CreateVoiceProfileDomainRequest, CreateVoiceProfileDomainResponse, CreateVoiceProfileDomainError, Credentials | HttpClient.HttpClient>;
export type DeletePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Moves the specified phone number into the
 * **Deletion queue**. A phone number must
 * be disassociated from any users or Amazon Chime SDK Voice Connectors before it can be
 * deleted.
 *
 * Deleted phone numbers remain in the
 * **Deletion queue** queue for 7 days before
 * they are deleted permanently.
 */
export declare const deletePhoneNumber: API.OperationMethod<DeletePhoneNumberRequest, DeletePhoneNumberResponse, DeletePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type DeleteProxySessionError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the specified proxy session from the specified Amazon Chime SDK Voice
 * Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const deleteProxySession: API.OperationMethod<DeleteProxySessionRequest, DeleteProxySessionResponse, DeleteProxySessionError, Credentials | HttpClient.HttpClient>;
export type DeleteSipMediaApplicationError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes a SIP media application.
 */
export declare const deleteSipMediaApplication: API.OperationMethod<DeleteSipMediaApplicationRequest, DeleteSipMediaApplicationResponse, DeleteSipMediaApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteSipRuleError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes a SIP rule.
 */
export declare const deleteSipRule: API.OperationMethod<DeleteSipRuleRequest, DeleteSipRuleResponse, DeleteSipRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an Amazon Chime SDK Voice Connector. Any phone numbers associated
 * with the Amazon Chime SDK Voice Connector must be disassociated from it before it
 * can be deleted.
 */
export declare const deleteVoiceConnector: API.OperationMethod<DeleteVoiceConnectorRequest, DeleteVoiceConnectorResponse, DeleteVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorEmergencyCallingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the emergency calling details from the specified Amazon Chime SDK Voice
 * Connector.
 */
export declare const deleteVoiceConnectorEmergencyCallingConfiguration: API.OperationMethod<DeleteVoiceConnectorEmergencyCallingConfigurationRequest, DeleteVoiceConnectorEmergencyCallingConfigurationResponse, DeleteVoiceConnectorEmergencyCallingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorExternalSystemsConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the external systems configuration for a Voice Connector.
 */
export declare const deleteVoiceConnectorExternalSystemsConfiguration: API.OperationMethod<DeleteVoiceConnectorExternalSystemsConfigurationRequest, DeleteVoiceConnectorExternalSystemsConfigurationResponse, DeleteVoiceConnectorExternalSystemsConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorGroupError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an Amazon Chime SDK Voice Connector group. Any `VoiceConnectorItems`
 * and phone numbers associated with the group must be removed before it can be
 * deleted.
 */
export declare const deleteVoiceConnectorGroup: API.OperationMethod<DeleteVoiceConnectorGroupRequest, DeleteVoiceConnectorGroupResponse, DeleteVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorOriginationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the origination settings for the specified Amazon Chime SDK Voice Connector.
 *
 * If emergency calling is configured for the Voice Connector, it must be
 * deleted prior to deleting the origination settings.
 */
export declare const deleteVoiceConnectorOrigination: API.OperationMethod<DeleteVoiceConnectorOriginationRequest, DeleteVoiceConnectorOriginationResponse, DeleteVoiceConnectorOriginationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorProxyError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the proxy configuration from the specified Amazon Chime SDK Voice Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const deleteVoiceConnectorProxy: API.OperationMethod<DeleteVoiceConnectorProxyRequest, DeleteVoiceConnectorProxyResponse, DeleteVoiceConnectorProxyError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorStreamingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes a Voice Connector's streaming configuration.
 */
export declare const deleteVoiceConnectorStreamingConfiguration: API.OperationMethod<DeleteVoiceConnectorStreamingConfigurationRequest, DeleteVoiceConnectorStreamingConfigurationResponse, DeleteVoiceConnectorStreamingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorTerminationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the termination settings for the specified Amazon Chime SDK Voice Connector.
 *
 * If emergency calling is configured for the Voice Connector, it must be
 * deleted prior to deleting the termination settings.
 */
export declare const deleteVoiceConnectorTermination: API.OperationMethod<DeleteVoiceConnectorTerminationRequest, DeleteVoiceConnectorTerminationResponse, DeleteVoiceConnectorTerminationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorTerminationCredentialsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the specified SIP credentials used by your equipment to
 * authenticate during call termination.
 */
export declare const deleteVoiceConnectorTerminationCredentials: API.OperationMethod<DeleteVoiceConnectorTerminationCredentialsRequest, DeleteVoiceConnectorTerminationCredentialsResponse, DeleteVoiceConnectorTerminationCredentialsError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceProfileError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes a voice profile, including its voice print and enrollment data. WARNING: This action is not reversible.
 */
export declare const deleteVoiceProfile: API.OperationMethod<DeleteVoiceProfileRequest, DeleteVoiceProfileResponse, DeleteVoiceProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceProfileDomainError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes all voice profiles in the domain. WARNING: This action is not reversible.
 */
export declare const deleteVoiceProfileDomain: API.OperationMethod<DeleteVoiceProfileDomainRequest, DeleteVoiceProfileDomainResponse, DeleteVoiceProfileDomainError, Credentials | HttpClient.HttpClient>;
export type DisassociatePhoneNumbersFromVoiceConnectorError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Disassociates the specified phone numbers from the specified
 * Amazon Chime SDK Voice Connector.
 */
export declare const disassociatePhoneNumbersFromVoiceConnector: API.OperationMethod<DisassociatePhoneNumbersFromVoiceConnectorRequest, DisassociatePhoneNumbersFromVoiceConnectorResponse, DisassociatePhoneNumbersFromVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type DisassociatePhoneNumbersFromVoiceConnectorGroupError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Disassociates the specified phone numbers from the specified Amazon Chime SDK Voice
 * Connector group.
 */
export declare const disassociatePhoneNumbersFromVoiceConnectorGroup: API.OperationMethod<DisassociatePhoneNumbersFromVoiceConnectorGroupRequest, DisassociatePhoneNumbersFromVoiceConnectorGroupResponse, DisassociatePhoneNumbersFromVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type GetGlobalSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the global settings for the Amazon Chime SDK Voice Connectors in an AWS account.
 */
export declare const getGlobalSettings: API.OperationMethod<GetGlobalSettingsRequest, GetGlobalSettingsResponse, GetGlobalSettingsError, Credentials | HttpClient.HttpClient>;
export type GetPhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified phone number ID, such as associations,
 * capabilities, and product type.
 */
export declare const getPhoneNumber: API.OperationMethod<GetPhoneNumberRequest, GetPhoneNumberResponse, GetPhoneNumberError, Credentials | HttpClient.HttpClient>;
export type GetPhoneNumberOrderError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified phone number order, such as the order
 * creation timestamp, phone numbers in E.164 format, product type, and
 * order status.
 */
export declare const getPhoneNumberOrder: API.OperationMethod<GetPhoneNumberOrderRequest, GetPhoneNumberOrderResponse, GetPhoneNumberOrderError, Credentials | HttpClient.HttpClient>;
export type GetPhoneNumberSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the phone number settings for the administrator's AWS account,
 * such as the default outbound calling name.
 */
export declare const getPhoneNumberSettings: API.OperationMethod<GetPhoneNumberSettingsRequest, GetPhoneNumberSettingsResponse, GetPhoneNumberSettingsError, Credentials | HttpClient.HttpClient>;
export type GetProxySessionError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the specified proxy session details for the specified Amazon Chime SDK Voice Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const getProxySession: API.OperationMethod<GetProxySessionRequest, GetProxySessionResponse, GetProxySessionError, Credentials | HttpClient.HttpClient>;
export type GetSipMediaApplicationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the information for a SIP media application, including name,
 * AWS Region, and endpoints.
 */
export declare const getSipMediaApplication: API.OperationMethod<GetSipMediaApplicationRequest, GetSipMediaApplicationResponse, GetSipMediaApplicationError, Credentials | HttpClient.HttpClient>;
export type GetSipMediaApplicationAlexaSkillConfigurationError = BadRequestException | ForbiddenException | GoneException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets the Alexa Skill configuration for the SIP media application.
 *
 * Due to changes made by the Amazon Alexa service, this API is no longer available for use. For more information, refer to
 * the Alexa Smart Properties page.
 */
export declare const getSipMediaApplicationAlexaSkillConfiguration: API.OperationMethod<GetSipMediaApplicationAlexaSkillConfigurationRequest, GetSipMediaApplicationAlexaSkillConfigurationResponse, GetSipMediaApplicationAlexaSkillConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetSipMediaApplicationLoggingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the logging configuration for the specified SIP media application.
 */
export declare const getSipMediaApplicationLoggingConfiguration: API.OperationMethod<GetSipMediaApplicationLoggingConfigurationRequest, GetSipMediaApplicationLoggingConfigurationResponse, GetSipMediaApplicationLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetSipRuleError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of a SIP rule, such as the rule ID, name, triggers, and
 * target endpoints.
 */
export declare const getSipRule: API.OperationMethod<GetSipRuleRequest, GetSipRuleResponse, GetSipRuleError, Credentials | HttpClient.HttpClient>;
export type GetSpeakerSearchTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of the specified speaker search task.
 */
export declare const getSpeakerSearchTask: API.OperationMethod<GetSpeakerSearchTaskRequest, GetSpeakerSearchTaskResponse, GetSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified Amazon Chime SDK Voice Connector, such as
 * timestamps,name, outbound host, and encryption requirements.
 */
export declare const getVoiceConnector: API.OperationMethod<GetVoiceConnectorRequest, GetVoiceConnectorResponse, GetVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorEmergencyCallingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the emergency calling configuration details for the specified Voice Connector.
 */
export declare const getVoiceConnectorEmergencyCallingConfiguration: API.OperationMethod<GetVoiceConnectorEmergencyCallingConfigurationRequest, GetVoiceConnectorEmergencyCallingConfigurationResponse, GetVoiceConnectorEmergencyCallingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorExternalSystemsConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets information about an external systems configuration for a Voice
 * Connector.
 */
export declare const getVoiceConnectorExternalSystemsConfiguration: API.OperationMethod<GetVoiceConnectorExternalSystemsConfigurationRequest, GetVoiceConnectorExternalSystemsConfigurationResponse, GetVoiceConnectorExternalSystemsConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorGroupError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified Amazon Chime SDK Voice Connector group,
 * such as timestamps,name, and associated `VoiceConnectorItems`.
 */
export declare const getVoiceConnectorGroup: API.OperationMethod<GetVoiceConnectorGroupRequest, GetVoiceConnectorGroupResponse, GetVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorLoggingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the logging configuration settings for the specified Voice Connector.
 * Shows whether SIP message logs are enabled for sending to Amazon CloudWatch Logs.
 */
export declare const getVoiceConnectorLoggingConfiguration: API.OperationMethod<GetVoiceConnectorLoggingConfigurationRequest, GetVoiceConnectorLoggingConfigurationResponse, GetVoiceConnectorLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorOriginationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the origination settings for the specified Voice Connector.
 */
export declare const getVoiceConnectorOrigination: API.OperationMethod<GetVoiceConnectorOriginationRequest, GetVoiceConnectorOriginationResponse, GetVoiceConnectorOriginationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorProxyError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the proxy configuration details for the specified Amazon Chime SDK Voice
 * Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const getVoiceConnectorProxy: API.OperationMethod<GetVoiceConnectorProxyRequest, GetVoiceConnectorProxyResponse, GetVoiceConnectorProxyError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorStreamingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the streaming configuration details for the specified Amazon Chime SDK
 * Voice Connector. Shows whether media streaming is enabled for sending to Amazon
 * Kinesis. It also shows the retention period, in hours, for the Amazon Kinesis data.
 */
export declare const getVoiceConnectorStreamingConfiguration: API.OperationMethod<GetVoiceConnectorStreamingConfigurationRequest, GetVoiceConnectorStreamingConfigurationResponse, GetVoiceConnectorStreamingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorTerminationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the termination setting details for the specified Voice Connector.
 */
export declare const getVoiceConnectorTermination: API.OperationMethod<GetVoiceConnectorTerminationRequest, GetVoiceConnectorTerminationResponse, GetVoiceConnectorTerminationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorTerminationHealthError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves information about the last time a `SIP OPTIONS` ping
 * was received from your SIP infrastructure for the specified Amazon Chime SDK Voice
 * Connector.
 */
export declare const getVoiceConnectorTerminationHealth: API.OperationMethod<GetVoiceConnectorTerminationHealthRequest, GetVoiceConnectorTerminationHealthResponse, GetVoiceConnectorTerminationHealthError, Credentials | HttpClient.HttpClient>;
export type GetVoiceProfileError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of the specified voice profile.
 */
export declare const getVoiceProfile: API.OperationMethod<GetVoiceProfileRequest, GetVoiceProfileResponse, GetVoiceProfileError, Credentials | HttpClient.HttpClient>;
export type GetVoiceProfileDomainError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of the specified voice profile domain.
 */
export declare const getVoiceProfileDomain: API.OperationMethod<GetVoiceProfileDomainRequest, GetVoiceProfileDomainResponse, GetVoiceProfileDomainError, Credentials | HttpClient.HttpClient>;
export type GetVoiceToneAnalysisTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of a voice tone analysis task.
 */
export declare const getVoiceToneAnalysisTask: API.OperationMethod<GetVoiceToneAnalysisTaskRequest, GetVoiceToneAnalysisTaskResponse, GetVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type ListAvailableVoiceConnectorRegionsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the available AWS Regions in which you can create an Amazon Chime SDK Voice Connector.
 */
export declare const listAvailableVoiceConnectorRegions: API.OperationMethod<ListAvailableVoiceConnectorRegionsRequest, ListAvailableVoiceConnectorRegionsResponse, ListAvailableVoiceConnectorRegionsError, Credentials | HttpClient.HttpClient>;
export type ListPhoneNumberOrdersError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the phone numbers for an administrator's Amazon Chime SDK account.
 */
export declare const listPhoneNumberOrders: API.PaginatedOperationMethod<ListPhoneNumberOrdersRequest, ListPhoneNumberOrdersResponse, ListPhoneNumberOrdersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPhoneNumbersError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the phone numbers for the specified Amazon Chime SDK account,
 * Amazon Chime SDK user, Amazon Chime SDK Voice Connector, or Amazon Chime SDK Voice
 * Connector group.
 */
export declare const listPhoneNumbers: API.PaginatedOperationMethod<ListPhoneNumbersRequest, ListPhoneNumbersResponse, ListPhoneNumbersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProxySessionsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the proxy sessions for the specified Amazon Chime SDK Voice Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const listProxySessions: API.PaginatedOperationMethod<ListProxySessionsRequest, ListProxySessionsResponse, ListProxySessionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSipMediaApplicationsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the SIP media applications under the administrator's AWS account.
 */
export declare const listSipMediaApplications: API.PaginatedOperationMethod<ListSipMediaApplicationsRequest, ListSipMediaApplicationsResponse, ListSipMediaApplicationsError, Credentials | HttpClient.HttpClient, SipMediaApplication>;
export type ListSipRulesError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the SIP rules under the administrator's AWS account.
 */
export declare const listSipRules: API.PaginatedOperationMethod<ListSipRulesRequest, ListSipRulesResponse, ListSipRulesError, Credentials | HttpClient.HttpClient, SipRule>;
export type ListSupportedPhoneNumberCountriesError = AccessDeniedException | BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the countries that you can order phone numbers from.
 */
export declare const listSupportedPhoneNumberCountries: API.OperationMethod<ListSupportedPhoneNumberCountriesRequest, ListSupportedPhoneNumberCountriesResponse, ListSupportedPhoneNumberCountriesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | UnauthorizedClientException | CommonErrors;
/**
 * Returns a list of the tags in a given resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVoiceConnectorGroupsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the Amazon Chime SDK Voice Connector groups in the administrator's AWS
 * account.
 */
export declare const listVoiceConnectorGroups: API.PaginatedOperationMethod<ListVoiceConnectorGroupsRequest, ListVoiceConnectorGroupsResponse, ListVoiceConnectorGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVoiceConnectorsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the Amazon Chime SDK Voice Connectors in the administrators
 * AWS account.
 */
export declare const listVoiceConnectors: API.PaginatedOperationMethod<ListVoiceConnectorsRequest, ListVoiceConnectorsResponse, ListVoiceConnectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVoiceConnectorTerminationCredentialsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the SIP credentials for the specified Amazon Chime SDK Voice Connector.
 */
export declare const listVoiceConnectorTerminationCredentials: API.OperationMethod<ListVoiceConnectorTerminationCredentialsRequest, ListVoiceConnectorTerminationCredentialsResponse, ListVoiceConnectorTerminationCredentialsError, Credentials | HttpClient.HttpClient>;
export type ListVoiceProfileDomainsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the specified voice profile domains in the administrator's AWS account.
 */
export declare const listVoiceProfileDomains: API.PaginatedOperationMethod<ListVoiceProfileDomainsRequest, ListVoiceProfileDomainsResponse, ListVoiceProfileDomainsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVoiceProfilesError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the voice profiles in a voice profile domain.
 */
export declare const listVoiceProfiles: API.PaginatedOperationMethod<ListVoiceProfilesRequest, ListVoiceProfilesResponse, ListVoiceProfilesError, Credentials | HttpClient.HttpClient, unknown>;
export type PutSipMediaApplicationAlexaSkillConfigurationError = BadRequestException | ForbiddenException | GoneException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the Alexa Skill configuration for the SIP media application.
 *
 * Due to changes made by the Amazon Alexa service, this API is no longer available for use. For more information, refer to
 * the Alexa Smart Properties page.
 */
export declare const putSipMediaApplicationAlexaSkillConfiguration: API.OperationMethod<PutSipMediaApplicationAlexaSkillConfigurationRequest, PutSipMediaApplicationAlexaSkillConfigurationResponse, PutSipMediaApplicationAlexaSkillConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutSipMediaApplicationLoggingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the logging configuration for the specified SIP media application.
 */
export declare const putSipMediaApplicationLoggingConfiguration: API.OperationMethod<PutSipMediaApplicationLoggingConfigurationRequest, PutSipMediaApplicationLoggingConfigurationResponse, PutSipMediaApplicationLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorEmergencyCallingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's emergency calling configuration.
 */
export declare const putVoiceConnectorEmergencyCallingConfiguration: API.OperationMethod<PutVoiceConnectorEmergencyCallingConfigurationRequest, PutVoiceConnectorEmergencyCallingConfigurationResponse, PutVoiceConnectorEmergencyCallingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorExternalSystemsConfigurationError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Adds an external systems configuration to a Voice Connector.
 */
export declare const putVoiceConnectorExternalSystemsConfiguration: API.OperationMethod<PutVoiceConnectorExternalSystemsConfigurationRequest, PutVoiceConnectorExternalSystemsConfigurationResponse, PutVoiceConnectorExternalSystemsConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorLoggingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's logging configuration.
 */
export declare const putVoiceConnectorLoggingConfiguration: API.OperationMethod<PutVoiceConnectorLoggingConfigurationRequest, PutVoiceConnectorLoggingConfigurationResponse, PutVoiceConnectorLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorOriginationError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's origination settings.
 */
export declare const putVoiceConnectorOrigination: API.OperationMethod<PutVoiceConnectorOriginationRequest, PutVoiceConnectorOriginationResponse, PutVoiceConnectorOriginationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorProxyError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Puts the specified proxy configuration to the specified Amazon Chime SDK Voice Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const putVoiceConnectorProxy: API.OperationMethod<PutVoiceConnectorProxyRequest, PutVoiceConnectorProxyResponse, PutVoiceConnectorProxyError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorStreamingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's streaming configuration settings.
 */
export declare const putVoiceConnectorStreamingConfiguration: API.OperationMethod<PutVoiceConnectorStreamingConfigurationRequest, PutVoiceConnectorStreamingConfigurationResponse, PutVoiceConnectorStreamingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorTerminationError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's termination settings.
 */
export declare const putVoiceConnectorTermination: API.OperationMethod<PutVoiceConnectorTerminationRequest, PutVoiceConnectorTerminationResponse, PutVoiceConnectorTerminationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorTerminationCredentialsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's termination credentials.
 */
export declare const putVoiceConnectorTerminationCredentials: API.OperationMethod<PutVoiceConnectorTerminationCredentialsRequest, PutVoiceConnectorTerminationCredentialsResponse, PutVoiceConnectorTerminationCredentialsError, Credentials | HttpClient.HttpClient>;
export type RestorePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Restores a deleted phone number.
 */
export declare const restorePhoneNumber: API.OperationMethod<RestorePhoneNumberRequest, RestorePhoneNumberResponse, RestorePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type SearchAvailablePhoneNumbersError = AccessDeniedException | BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Searches the provisioned phone numbers in an organization.
 */
export declare const searchAvailablePhoneNumbers: API.PaginatedOperationMethod<SearchAvailablePhoneNumbersRequest, SearchAvailablePhoneNumbersResponse, SearchAvailablePhoneNumbersError, Credentials | HttpClient.HttpClient, unknown>;
export type StartSpeakerSearchTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | GoneException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | UnprocessableEntityException | CommonErrors;
/**
 * Starts a speaker search task.
 *
 * Before starting any speaker search tasks, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 */
export declare const startSpeakerSearchTask: API.OperationMethod<StartSpeakerSearchTaskRequest, StartSpeakerSearchTaskResponse, StartSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type StartVoiceToneAnalysisTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | GoneException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | UnprocessableEntityException | CommonErrors;
/**
 * Starts a voice tone analysis task. For more information about voice tone analysis, see
 * Using Amazon Chime SDK voice analytics
 * in the *Amazon Chime SDK Developer Guide*.
 *
 * Before starting any voice tone analysis tasks, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 */
export declare const startVoiceToneAnalysisTask: API.OperationMethod<StartVoiceToneAnalysisTaskRequest, StartVoiceToneAnalysisTaskResponse, StartVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type StopSpeakerSearchTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | UnprocessableEntityException | CommonErrors;
/**
 * Stops a speaker search task.
 */
export declare const stopSpeakerSearchTask: API.OperationMethod<StopSpeakerSearchTaskRequest, StopSpeakerSearchTaskResponse, StopSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type StopVoiceToneAnalysisTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | UnprocessableEntityException | CommonErrors;
/**
 * Stops a voice tone analysis task.
 */
export declare const stopVoiceToneAnalysisTask: API.OperationMethod<StopVoiceToneAnalysisTaskRequest, StopVoiceToneAnalysisTaskResponse, StopVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | UnauthorizedClientException | CommonErrors;
/**
 * Adds a tag to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | UnauthorizedClientException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateGlobalSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates global settings for the Amazon Chime SDK Voice Connectors in an AWS account.
 */
export declare const updateGlobalSettings: API.OperationMethod<UpdateGlobalSettingsRequest, UpdateGlobalSettingsResponse, UpdateGlobalSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdatePhoneNumberError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates phone number details, such as product type, calling name, or phone number name for the
 * specified phone number ID. You can update one phone number detail at a time. For
 * example, you can update either the product type, calling name, or phone number name in one action.
 *
 * For numbers outside the U.S., you must use the Amazon Chime SDK SIP Media
 * Application Dial-In product type.
 *
 * Updates to outbound calling names can take 72 hours to complete. Pending
 * updates to outbound calling names must be complete before you can request another
 * update.
 */
export declare const updatePhoneNumber: API.OperationMethod<UpdatePhoneNumberRequest, UpdatePhoneNumberResponse, UpdatePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type UpdatePhoneNumberSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the phone number settings for the administrator's AWS account, such
 * as the default outbound calling name. You can update the default outbound calling
 * name once every seven days. Outbound calling names can take up to 72 hours to
 * update.
 */
export declare const updatePhoneNumberSettings: API.OperationMethod<UpdatePhoneNumberSettingsRequest, UpdatePhoneNumberSettingsResponse, UpdatePhoneNumberSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateProxySessionError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the specified proxy session details, such as voice or SMS capabilities.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const updateProxySession: API.OperationMethod<UpdateProxySessionRequest, UpdateProxySessionResponse, UpdateProxySessionError, Credentials | HttpClient.HttpClient>;
export type UpdateSipMediaApplicationError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the details of the specified SIP media application.
 */
export declare const updateSipMediaApplication: API.OperationMethod<UpdateSipMediaApplicationRequest, UpdateSipMediaApplicationResponse, UpdateSipMediaApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateSipMediaApplicationCallError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Invokes the AWS Lambda function associated with the SIP media application and
 * transaction ID in an update request. The Lambda function can then return a new set
 * of actions.
 */
export declare const updateSipMediaApplicationCall: API.OperationMethod<UpdateSipMediaApplicationCallRequest, UpdateSipMediaApplicationCallResponse, UpdateSipMediaApplicationCallError, Credentials | HttpClient.HttpClient>;
export type UpdateSipRuleError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the details of the specified SIP rule.
 */
export declare const updateSipRule: API.OperationMethod<UpdateSipRuleRequest, UpdateSipRuleResponse, UpdateSipRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceConnectorError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the details for the specified Amazon Chime SDK Voice Connector.
 */
export declare const updateVoiceConnector: API.OperationMethod<UpdateVoiceConnectorRequest, UpdateVoiceConnectorResponse, UpdateVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceConnectorGroupError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the settings for the specified Amazon Chime SDK Voice Connector group.
 */
export declare const updateVoiceConnectorGroup: API.OperationMethod<UpdateVoiceConnectorGroupRequest, UpdateVoiceConnectorGroupResponse, UpdateVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceProfileError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | GoneException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the specified voice profile’s voice print and refreshes its expiration timestamp.
 *
 * As a condition of using this feature, you acknowledge that the collection, use, storage, and retention of
 * your caller’s biometric identifiers and biometric information (“biometric data”) in the form of a digital voiceprint
 * requires the caller’s informed consent via a written release. Such consent is required under various state laws,
 * including biometrics laws in Illinois, Texas, Washington and other state privacy laws.
 *
 * You must provide a written release to each caller through a process that clearly reflects each caller’s informed
 * consent before using Amazon Chime SDK Voice Insights service, as required under the terms of your agreement
 * with AWS governing your use of the service.
 */
export declare const updateVoiceProfile: API.OperationMethod<UpdateVoiceProfileRequest, UpdateVoiceProfileResponse, UpdateVoiceProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceProfileDomainError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the settings for the specified voice profile domain.
 */
export declare const updateVoiceProfileDomain: API.OperationMethod<UpdateVoiceProfileDomainRequest, UpdateVoiceProfileDomainResponse, UpdateVoiceProfileDomainError, Credentials | HttpClient.HttpClient>;
export type ValidateE911AddressError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Validates an address to be used for 911 calls made with Amazon Chime SDK Voice
 * Connectors. You can use validated addresses in a Presence Information Data Format
 * Location Object file that you include in SIP requests. That helps ensure that addresses
 * are routed to the appropriate Public Safety Answering Point.
 */
export declare const validateE911Address: API.OperationMethod<ValidateE911AddressRequest, ValidateE911AddressResponse, ValidateE911AddressError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=chime-sdk-voice.d.ts.map