import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as stream from "effect/Stream";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadGatewayException_base: S.Class<BadGatewayException, S.TaggedStruct<"BadGatewayException", {
    readonly message: any;
    readonly resourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class BadGatewayException extends /*@__PURE__*/ BadGatewayException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DependencyFailedException_base: S.Class<DependencyFailedException, S.TaggedStruct<"DependencyFailedException", {
    readonly message: any;
    readonly resourceName: any;
}>, import("effect/Cause").YieldableError>;
export declare class DependencyFailedException extends /*@__PURE__*/ DependencyFailedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ModelNotReadyException_base: S.Class<ModelNotReadyException, S.TaggedStruct<"ModelNotReadyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ModelNotReadyException extends /*@__PURE__*/ ModelNotReadyException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface AgenticRetrieveMessageContent {
    text?: string;
}
export declare const AgenticRetrieveMessageContent: S.Schema<AgenticRetrieveMessageContent>;
export type ConversationRole = "user" | "assistant" | (string & {});
export declare const ConversationRole: any;
export interface AgenticRetrieveMessage {
    content: AgenticRetrieveMessageContent;
    role: ConversationRole;
}
export declare const AgenticRetrieveMessage: S.Schema<AgenticRetrieveMessage>;
export type AgenticRetrieveMessages = AgenticRetrieveMessage[];
export declare const AgenticRetrieveMessages: any;
export type KnowledgeBaseId = string;
export type FilterKey = string;
export type FilterValue = unknown;
export interface FilterAttribute {
    key: string;
    value: any;
}
export declare const FilterAttribute: S.Schema<FilterAttribute>;
export type RetrievalFilterList = RetrievalFilter[];
export declare const RetrievalFilterList: S.Schema<RetrievalFilterList>;
export type RetrievalFilter = {
    equals: FilterAttribute;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals: FilterAttribute;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan: FilterAttribute;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals: FilterAttribute;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan: FilterAttribute;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals: FilterAttribute;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in: FilterAttribute;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn: FilterAttribute;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith: FilterAttribute;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains: FilterAttribute;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains: FilterAttribute;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll: RetrievalFilter[];
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll: RetrievalFilter[];
};
export declare const RetrievalFilter: S.Schema<RetrievalFilter>;
export interface RetrievalOverrides {
    filter?: RetrievalFilter;
    maxNumberOfResults?: number;
}
export declare const RetrievalOverrides: S.Schema<RetrievalOverrides>;
export interface KnowledgeBaseRetrieverConfiguration {
    knowledgeBaseId: string;
    retrievalOverrides?: RetrievalOverrides;
}
export declare const KnowledgeBaseRetrieverConfiguration: S.Schema<KnowledgeBaseRetrieverConfiguration>;
export type RetrieverConfiguration = {
    knowledgeBase: KnowledgeBaseRetrieverConfiguration;
};
export declare const RetrieverConfiguration: any;
export interface AgenticRetriever {
    description?: string;
    configuration: RetrieverConfiguration;
}
export declare const AgenticRetriever: S.Schema<AgenticRetriever>;
export type AgenticRetrievers = AgenticRetriever[];
export declare const AgenticRetrievers: any;
export type FoundationModelType = "CUSTOM" | "MANAGED" | (string & {});
export declare const FoundationModelType: any;
export type FoundationModelConfigurationType = "BEDROCK_FOUNDATION_MODEL" | (string & {});
export declare const FoundationModelConfigurationType: any;
export type BedrockModelArn = string;
export interface BedrockFoundationModelModelConfiguration {
    modelArn: string;
}
export declare const BedrockFoundationModelModelConfiguration: S.Schema<BedrockFoundationModelModelConfiguration>;
export interface BedrockFoundationModelConfiguration {
    modelConfiguration: BedrockFoundationModelModelConfiguration;
}
export declare const BedrockFoundationModelConfiguration: S.Schema<BedrockFoundationModelConfiguration>;
export interface FoundationModelConfiguration {
    type: FoundationModelConfigurationType;
    bedrockFoundationModelConfiguration?: BedrockFoundationModelConfiguration;
}
export declare const FoundationModelConfiguration: S.Schema<FoundationModelConfiguration>;
export type AgenticRetrieveRerankingModelType = "CUSTOM" | "MANAGED" | "NONE" | (string & {});
export declare const AgenticRetrieveRerankingModelType: any;
export type AgenticRetrieveRerankingConfigurationType = "BEDROCK_RERANKING_MODEL" | (string & {});
export declare const AgenticRetrieveRerankingConfigurationType: any;
export interface AgenticRetrieveBedrockRerankingModelConfiguration {
    modelArn: string;
}
export declare const AgenticRetrieveBedrockRerankingModelConfiguration: S.Schema<AgenticRetrieveBedrockRerankingModelConfiguration>;
export interface AgenticRetrieveBedrockRerankingConfiguration {
    modelConfiguration: AgenticRetrieveBedrockRerankingModelConfiguration;
}
export declare const AgenticRetrieveBedrockRerankingConfiguration: S.Schema<AgenticRetrieveBedrockRerankingConfiguration>;
export interface AgenticRetrieveRerankingConfiguration {
    type: AgenticRetrieveRerankingConfigurationType;
    bedrockRerankingConfiguration?: AgenticRetrieveBedrockRerankingConfiguration;
}
export declare const AgenticRetrieveRerankingConfiguration: S.Schema<AgenticRetrieveRerankingConfiguration>;
export interface AgenticRetrieveConfiguration {
    foundationModelType?: FoundationModelType;
    foundationModelConfiguration?: FoundationModelConfiguration;
    rerankingModelType?: AgenticRetrieveRerankingModelType;
    rerankingConfiguration?: AgenticRetrieveRerankingConfiguration;
    maxAgentIteration?: number;
}
export declare const AgenticRetrieveConfiguration: S.Schema<AgenticRetrieveConfiguration>;
export interface AgenticRetrieveBedrockGuardrailConfiguration {
    guardrailId: string;
    guardrailVersion: string;
}
export declare const AgenticRetrieveBedrockGuardrailConfiguration: S.Schema<AgenticRetrieveBedrockGuardrailConfiguration>;
export interface AgenticRetrievePolicyConfiguration {
    bedrockGuardrailConfiguration?: AgenticRetrieveBedrockGuardrailConfiguration;
}
export declare const AgenticRetrievePolicyConfiguration: S.Schema<AgenticRetrievePolicyConfiguration>;
export type NextToken = string;
export interface UserContext {
    userId: string;
}
export declare const UserContext: S.Schema<UserContext>;
export type AgentCoreMemoryId = string;
export type AgentCoreMemoryActorId = string;
export type AgentCoreMemorySessionId = string;
export interface AgenticRetrieveMemorySessionBinding {
    actorId: string;
    sessionId: string;
}
export declare const AgenticRetrieveMemorySessionBinding: S.Schema<AgenticRetrieveMemorySessionBinding>;
export type MemoryNamespace = string;
export type MemoryStrategyId = string;
export type AgenticRetrieveMemoryMetadataKey = string;
export type AgenticRetrieveMemoryMetadataFilterLeft = {
    metadataKey: string;
};
export declare const AgenticRetrieveMemoryMetadataFilterLeft: any;
export type AgenticRetrieveMemoryMetadataFilterOperator = "EQUALS_TO" | "EXISTS" | "NOT_EXISTS" | "BEFORE" | "AFTER" | "CONTAINS" | "GREATER_THAN" | "GREATER_THAN_OR_EQUALS" | "LESS_THAN" | "LESS_THAN_OR_EQUALS" | (string & {});
export declare const AgenticRetrieveMemoryMetadataFilterOperator: any;
export type AgenticRetrieveMemoryMetadataStringValue = string;
export type AgenticRetrieveMemoryMetadataStringListItem = string;
export type AgenticRetrieveMemoryMetadataStringList = string[];
export declare const AgenticRetrieveMemoryMetadataStringList: any;
export type AgenticRetrieveMemoryMetadataValue = {
    stringValue: string;
    numberValue?: never;
    stringListValue?: never;
    dateTimeValue?: never;
} | {
    stringValue?: never;
    numberValue: number;
    stringListValue?: never;
    dateTimeValue?: never;
} | {
    stringValue?: never;
    numberValue?: never;
    stringListValue: string[];
    dateTimeValue?: never;
} | {
    stringValue?: never;
    numberValue?: never;
    stringListValue?: never;
    dateTimeValue: Date;
};
export declare const AgenticRetrieveMemoryMetadataValue: any;
export type AgenticRetrieveMemoryMetadataFilterRight = {
    metadataValue: AgenticRetrieveMemoryMetadataValue;
};
export declare const AgenticRetrieveMemoryMetadataFilterRight: any;
export interface AgenticRetrieveMemoryMetadataFilter {
    left: AgenticRetrieveMemoryMetadataFilterLeft;
    operator: AgenticRetrieveMemoryMetadataFilterOperator;
    right?: AgenticRetrieveMemoryMetadataFilterRight;
}
export declare const AgenticRetrieveMemoryMetadataFilter: S.Schema<AgenticRetrieveMemoryMetadataFilter>;
export type AgenticRetrieveMemoryMetadataFilterList = AgenticRetrieveMemoryMetadataFilter[];
export declare const AgenticRetrieveMemoryMetadataFilterList: any;
export interface AgenticRetrieveMemoryRetrievalConfig {
    namespace?: string;
    namespacePath?: string;
    strategyId?: string;
    metadataFilters?: AgenticRetrieveMemoryMetadataFilter[];
}
export declare const AgenticRetrieveMemoryRetrievalConfig: S.Schema<AgenticRetrieveMemoryRetrievalConfig>;
export type AgenticRetrieveMemoryRetrievalConfigList = AgenticRetrieveMemoryRetrievalConfig[];
export declare const AgenticRetrieveMemoryRetrievalConfigList: any;
export type AgenticRetrieveMemoryPersistenceMode = "DEFAULT" | "NONE" | (string & {});
export declare const AgenticRetrieveMemoryPersistenceMode: any;
export interface AgenticRetrieveMemoryConfiguration {
    memoryId: string;
    sessionBinding?: AgenticRetrieveMemorySessionBinding;
    retrievalConfigs?: AgenticRetrieveMemoryRetrievalConfig[];
    persistenceMode?: AgenticRetrieveMemoryPersistenceMode;
}
export declare const AgenticRetrieveMemoryConfiguration: S.Schema<AgenticRetrieveMemoryConfiguration>;
export interface AgenticRetrieveStreamRequest {
    messages: AgenticRetrieveMessage[];
    retrievers: AgenticRetriever[];
    agenticRetrieveConfiguration: AgenticRetrieveConfiguration;
    policyConfiguration?: AgenticRetrievePolicyConfiguration;
    nextToken?: string;
    userContext?: UserContext;
    memoryConfiguration?: AgenticRetrieveMemoryConfiguration;
    generateResponse?: boolean;
}
export declare const AgenticRetrieveStreamRequest: S.Schema<AgenticRetrieveStreamRequest>;
export type MimeType = string;
export interface RetrievalContent {
    byteContent?: Uint8Array;
    text?: string;
    mimeType: string;
}
export declare const RetrievalContent: S.Schema<RetrievalContent>;
export type AgenticRetrieveMetadata = {
    [key: string]: any | undefined;
};
export declare const AgenticRetrieveMetadata: any;
export interface AgenticRetrieveSourceRetriever {
    identifier: string;
}
export declare const AgenticRetrieveSourceRetriever: S.Schema<AgenticRetrieveSourceRetriever>;
export interface AgenticRetrieveResultItem {
    content: RetrievalContent;
    metadata?: {
        [key: string]: any | undefined;
    };
    sourceRetriever: AgenticRetrieveSourceRetriever;
}
export declare const AgenticRetrieveResultItem: S.Schema<AgenticRetrieveResultItem>;
export type AgenticRetrieveResults = AgenticRetrieveResultItem[];
export declare const AgenticRetrieveResults: any;
export interface AgenticRetrieveCitationReference {
    resultIndex: number;
}
export declare const AgenticRetrieveCitationReference: S.Schema<AgenticRetrieveCitationReference>;
export type AgenticRetrieveCitationReferenceList = AgenticRetrieveCitationReference[];
export declare const AgenticRetrieveCitationReferenceList: any;
export interface AgenticRetrieveCitation {
    startIndex: number;
    endIndex: number;
    references: AgenticRetrieveCitationReference[];
}
export declare const AgenticRetrieveCitation: S.Schema<AgenticRetrieveCitation>;
export type AgenticRetrieveCitationList = AgenticRetrieveCitation[];
export declare const AgenticRetrieveCitationList: any;
export interface AgenticRetrieveGeneratedResponse {
    answer: string;
    citations?: AgenticRetrieveCitation[];
}
export declare const AgenticRetrieveGeneratedResponse: S.Schema<AgenticRetrieveGeneratedResponse>;
export interface AgenticRetrieveResultEvent {
    results: AgenticRetrieveResultItem[];
    generatedResponse?: AgenticRetrieveGeneratedResponse;
    nextToken?: string;
}
export declare const AgenticRetrieveResultEvent: S.Schema<AgenticRetrieveResultEvent>;
export type AgenticRetrieveStep = "Planning" | "Retrieval" | "SpeculativeRetrieval" | "FullDocumentExpansion" | "SessionHistoryLoad" | (string & {});
export declare const AgenticRetrieveStep: any;
export type AgenticRetrieveStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const AgenticRetrieveStatus: any;
export type AgenticRetrieveSourceRetrieverList = AgenticRetrieveSourceRetriever[];
export declare const AgenticRetrieveSourceRetrieverList: any;
export interface AgenticRetrieveActionDetails {
    inputQuery: AgenticRetrieveMessageContent;
    sourceRetrievers: AgenticRetrieveSourceRetriever[];
}
export declare const AgenticRetrieveActionDetails: S.Schema<AgenticRetrieveActionDetails>;
export interface AgenticRetrieveFullDocExpansionDetails {
    documentId?: string;
    sourceRetriever?: AgenticRetrieveSourceRetriever;
}
export declare const AgenticRetrieveFullDocExpansionDetails: S.Schema<AgenticRetrieveFullDocExpansionDetails>;
export interface AgenticRetrieveMemoryRetrieveDetails {
    inputQuery: AgenticRetrieveMessageContent;
    memoryId: string;
    namespace?: string;
    namespacePath?: string;
    strategyId?: string;
}
export declare const AgenticRetrieveMemoryRetrieveDetails: S.Schema<AgenticRetrieveMemoryRetrieveDetails>;
export interface AgenticRetrieveAction {
    retrieve?: AgenticRetrieveActionDetails;
    fullDocumentExpansion?: AgenticRetrieveFullDocExpansionDetails;
    memoryRetrieve?: AgenticRetrieveMemoryRetrieveDetails;
}
export declare const AgenticRetrieveAction: S.Schema<AgenticRetrieveAction>;
export type AgenticRetrieveActions = AgenticRetrieveAction[];
export declare const AgenticRetrieveActions: any;
export interface AgenticRetrieveWarningMessage {
    message: string;
}
export declare const AgenticRetrieveWarningMessage: S.Schema<AgenticRetrieveWarningMessage>;
export type GuardrailAction = "INTERVENED" | "NONE" | (string & {});
export declare const GuardrailAction: any;
export interface AgenticRetrieveGuardrailWarning {
    id: string;
    version: string;
    action: GuardrailAction;
    message?: string;
}
export declare const AgenticRetrieveGuardrailWarning: S.Schema<AgenticRetrieveGuardrailWarning>;
export type AgenticRetrieveWarning = {
    message: AgenticRetrieveWarningMessage;
    guardrail?: never;
} | {
    message?: never;
    guardrail: AgenticRetrieveGuardrailWarning;
};
export declare const AgenticRetrieveWarning: any;
export type AgenticRetrieveWarnings = AgenticRetrieveWarning[];
export declare const AgenticRetrieveWarnings: any;
export interface AgenticRetrieveFailure {
    message: string;
}
export declare const AgenticRetrieveFailure: S.Schema<AgenticRetrieveFailure>;
export type AgenticRetrieveFailures = AgenticRetrieveFailure[];
export declare const AgenticRetrieveFailures: any;
export type AgenticRetrieveType = "BedrockKnowledgeBase" | "BedrockAgentCoreMemory" | (string & {});
export declare const AgenticRetrieveType: any;
export interface AgenticRetrieveSourceMetadata {
    identifier?: string;
    retrievalType?: AgenticRetrieveType;
}
export declare const AgenticRetrieveSourceMetadata: S.Schema<AgenticRetrieveSourceMetadata>;
export type AgenticRetrieveSourceMetadataList = AgenticRetrieveSourceMetadata[];
export declare const AgenticRetrieveSourceMetadataList: any;
export interface AgenticRetrieveTraceResultItem {
    content?: RetrievalContent;
    metadata?: {
        [key: string]: any | undefined;
    };
    sourceRetriever?: AgenticRetrieveSourceRetriever;
}
export declare const AgenticRetrieveTraceResultItem: S.Schema<AgenticRetrieveTraceResultItem>;
export type AgenticRetrieveTraceResults = AgenticRetrieveTraceResultItem[];
export declare const AgenticRetrieveTraceResults: any;
export interface AgenticRetrieveTraceEventAttributes {
    step: AgenticRetrieveStep;
    status: AgenticRetrieveStatus;
    message: string;
    actions?: AgenticRetrieveAction[];
    warnings?: AgenticRetrieveWarning[];
    failures?: AgenticRetrieveFailure[];
    retrievalMetadata?: AgenticRetrieveSourceMetadata[];
    retrievalResponse?: AgenticRetrieveTraceResultItem[];
}
export declare const AgenticRetrieveTraceEventAttributes: S.Schema<AgenticRetrieveTraceEventAttributes>;
export interface AgenticRetrieveTraceEvent {
    id: string;
    timestamp: number;
    attributes: AgenticRetrieveTraceEventAttributes;
}
export declare const AgenticRetrieveTraceEvent: S.Schema<AgenticRetrieveTraceEvent>;
export interface AgenticRetrieveResponseEvent {
    text: string;
}
export declare const AgenticRetrieveResponseEvent: S.Schema<AgenticRetrieveResponseEvent>;
export type NonBlankString = string;
export type AgenticRetrieveStreamResponseOutput = {
    result: AgenticRetrieveResultEvent;
    traceEvent?: never;
    responseEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    result?: never;
    traceEvent: AgenticRetrieveTraceEvent;
    responseEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    result?: never;
    traceEvent?: never;
    responseEvent: AgenticRetrieveResponseEvent;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    result?: never;
    traceEvent?: never;
    responseEvent?: never;
    internalServerException: InternalServerException;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    result?: never;
    traceEvent?: never;
    responseEvent?: never;
    internalServerException?: never;
    validationException: ValidationException;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    result?: never;
    traceEvent?: never;
    responseEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    result?: never;
    traceEvent?: never;
    responseEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    result?: never;
    traceEvent?: never;
    responseEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException: ThrottlingException;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    result?: never;
    traceEvent?: never;
    responseEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException: AccessDeniedException;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    result?: never;
    traceEvent?: never;
    responseEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException: ConflictException;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    result?: never;
    traceEvent?: never;
    responseEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException: DependencyFailedException;
    badGatewayException?: never;
} | {
    result?: never;
    traceEvent?: never;
    responseEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException: BadGatewayException;
};
export declare const AgenticRetrieveStreamResponseOutput: S.Schema<stream.Stream<AgenticRetrieveStreamResponseOutput, Error, never>>;
export interface AgenticRetrieveStreamResponse {
    stream: stream.Stream<AgenticRetrieveStreamResponseOutput, Error, never>;
}
export declare const AgenticRetrieveStreamResponse: S.Schema<AgenticRetrieveStreamResponse>;
export type KnowledgeBaseIdentifier = string;
export type DataSourceId = string;
export type DocumentId = string;
export interface CheckIngestedDocumentAclRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    documentId: string;
    userContext: UserContext;
}
export declare const CheckIngestedDocumentAclRequest: S.Schema<CheckIngestedDocumentAclRequest>;
export interface CheckIngestedDocumentAclResponse {
    hasAccess: boolean;
}
export declare const CheckIngestedDocumentAclResponse: S.Schema<CheckIngestedDocumentAclResponse>;
export type Uuid = string;
export type InvocationDescription = string;
export type SessionIdentifier = string;
export interface CreateInvocationRequest {
    invocationId?: string;
    description?: string;
    sessionIdentifier: string;
}
export declare const CreateInvocationRequest: S.Schema<CreateInvocationRequest>;
export interface CreateInvocationResponse {
    sessionId: string;
    invocationId: string;
    createdAt: Date;
}
export declare const CreateInvocationResponse: S.Schema<CreateInvocationResponse>;
export type SessionMetadataKey = string;
export type SessionMetadataValue = string;
export type SessionMetadataMap = {
    [key: string]: string | undefined;
};
export declare const SessionMetadataMap: any;
export type KmsKeyArn = string;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export interface CreateSessionRequest {
    sessionMetadata?: {
        [key: string]: string | undefined;
    };
    encryptionKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateSessionRequest: S.Schema<CreateSessionRequest>;
export type SessionArn = string;
export type SessionStatus = "ACTIVE" | "EXPIRED" | "ENDED" | (string & {});
export declare const SessionStatus: any;
export interface CreateSessionResponse {
    sessionId: string;
    sessionArn: string;
    sessionStatus: SessionStatus;
    createdAt: Date;
}
export declare const CreateSessionResponse: S.Schema<CreateSessionResponse>;
export type AgentId = string;
export type AgentAliasId = string;
export type MemoryId = string;
export type SessionId = string;
export interface DeleteAgentMemoryRequest {
    agentId: string;
    agentAliasId: string;
    memoryId?: string;
    sessionId?: string;
}
export declare const DeleteAgentMemoryRequest: S.Schema<DeleteAgentMemoryRequest>;
export interface DeleteAgentMemoryResponse {
}
export declare const DeleteAgentMemoryResponse: S.Schema<DeleteAgentMemoryResponse>;
export interface DeleteSessionRequest {
    sessionIdentifier: string;
}
export declare const DeleteSessionRequest: S.Schema<DeleteSessionRequest>;
export interface DeleteSessionResponse {
}
export declare const DeleteSessionResponse: S.Schema<DeleteSessionResponse>;
export interface EndSessionRequest {
    sessionIdentifier: string;
}
export declare const EndSessionRequest: S.Schema<EndSessionRequest>;
export interface EndSessionResponse {
    sessionId: string;
    sessionArn: string;
    sessionStatus: SessionStatus;
}
export declare const EndSessionResponse: S.Schema<EndSessionResponse>;
export type InputQueryType = "TEXT" | (string & {});
export declare const InputQueryType: any;
export interface QueryGenerationInput {
    type: InputQueryType;
    text: string;
}
export declare const QueryGenerationInput: S.Schema<QueryGenerationInput>;
export type QueryTransformationMode = "TEXT_TO_SQL" | (string & {});
export declare const QueryTransformationMode: any;
export type TextToSqlConfigurationType = "KNOWLEDGE_BASE" | (string & {});
export declare const TextToSqlConfigurationType: any;
export type KnowledgeBaseArn = string;
export interface TextToSqlKnowledgeBaseConfiguration {
    knowledgeBaseArn: string;
}
export declare const TextToSqlKnowledgeBaseConfiguration: S.Schema<TextToSqlKnowledgeBaseConfiguration>;
export interface TextToSqlConfiguration {
    type: TextToSqlConfigurationType;
    knowledgeBaseConfiguration?: TextToSqlKnowledgeBaseConfiguration;
}
export declare const TextToSqlConfiguration: S.Schema<TextToSqlConfiguration>;
export interface TransformationConfiguration {
    mode: QueryTransformationMode;
    textToSqlConfiguration?: TextToSqlConfiguration;
}
export declare const TransformationConfiguration: S.Schema<TransformationConfiguration>;
export interface GenerateQueryRequest {
    queryGenerationInput: QueryGenerationInput;
    transformationConfiguration: TransformationConfiguration;
}
export declare const GenerateQueryRequest: S.Schema<GenerateQueryRequest>;
export type GeneratedQueryType = "REDSHIFT_SQL" | (string & {});
export declare const GeneratedQueryType: any;
export interface GeneratedQuery {
    type?: GeneratedQueryType;
    sql?: string;
}
export declare const GeneratedQuery: S.Schema<GeneratedQuery>;
export type GeneratedQueries = GeneratedQuery[];
export declare const GeneratedQueries: any;
export interface GenerateQueryResponse {
    queries?: GeneratedQuery[];
}
export declare const GenerateQueryResponse: S.Schema<GenerateQueryResponse>;
export type MaxResults = number;
export type MemoryType = "SESSION_SUMMARY" | (string & {});
export declare const MemoryType: any;
export interface GetAgentMemoryRequest {
    nextToken?: string;
    maxItems?: number;
    agentId: string;
    agentAliasId: string;
    memoryType: MemoryType;
    memoryId: string;
}
export declare const GetAgentMemoryRequest: S.Schema<GetAgentMemoryRequest>;
export type SummaryText = string;
export interface MemorySessionSummary {
    memoryId?: string;
    sessionId?: string;
    sessionStartTime?: Date;
    sessionExpiryTime?: Date;
    summaryText?: string;
}
export declare const MemorySessionSummary: S.Schema<MemorySessionSummary>;
export type Memory = {
    sessionSummary: MemorySessionSummary;
};
export declare const Memory: any;
export type Memories = Memory[];
export declare const Memories: any;
export interface GetAgentMemoryResponse {
    nextToken?: string;
    memoryContents?: Memory[];
}
export declare const GetAgentMemoryResponse: S.Schema<GetAgentMemoryResponse>;
export type DocumentOutputFormat = "RAW" | "EXTRACTED" | (string & {});
export declare const DocumentOutputFormat: any;
export interface GetDocumentContentRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    documentId: string;
    outputFormat?: DocumentOutputFormat;
    userContext?: UserContext;
}
export declare const GetDocumentContentRequest: S.Schema<GetDocumentContentRequest>;
export type PresignedUrl = string | redacted.Redacted<string>;
export interface GetDocumentContentResponse {
    mimeType: string;
    presignedUrl: string | redacted.Redacted<string>;
    documentContentLength?: number;
}
export declare const GetDocumentContentResponse: S.Schema<GetDocumentContentResponse>;
export type FlowIdentifier = string;
export type FlowAliasIdentifier = string;
export type FlowExecutionIdentifier = string;
export interface GetExecutionFlowSnapshotRequest {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    executionIdentifier: string;
}
export declare const GetExecutionFlowSnapshotRequest: S.Schema<GetExecutionFlowSnapshotRequest>;
export type Version = string;
export type FlowExecutionRoleArn = string;
export interface GetExecutionFlowSnapshotResponse {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    flowVersion: string;
    executionRoleArn: string;
    definition: string;
    customerEncryptionKeyArn?: string;
}
export declare const GetExecutionFlowSnapshotResponse: S.Schema<GetExecutionFlowSnapshotResponse>;
export interface GetFlowExecutionRequest {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    executionIdentifier: string;
}
export declare const GetFlowExecutionRequest: S.Schema<GetFlowExecutionRequest>;
export type FlowExecutionStatus = "Running" | "Succeeded" | "Failed" | "TimedOut" | "Aborted" | (string & {});
export declare const FlowExecutionStatus: any;
export type NodeName = string;
export type FlowExecutionErrorType = "ExecutionTimedOut" | (string & {});
export declare const FlowExecutionErrorType: any;
export interface FlowExecutionError {
    nodeName?: string;
    error?: FlowExecutionErrorType;
    message?: string;
}
export declare const FlowExecutionError: S.Schema<FlowExecutionError>;
export type FlowExecutionErrors = FlowExecutionError[];
export declare const FlowExecutionErrors: any;
export interface GetFlowExecutionResponse {
    executionArn: string;
    status: FlowExecutionStatus;
    startedAt: Date;
    endedAt?: Date;
    errors?: FlowExecutionError[];
    flowAliasIdentifier: string;
    flowIdentifier: string;
    flowVersion: string;
}
export declare const GetFlowExecutionResponse: S.Schema<GetFlowExecutionResponse>;
export interface GetIngestedDocumentAclRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    documentId: string;
}
export declare const GetIngestedDocumentAclRequest: S.Schema<GetIngestedDocumentAclRequest>;
export type DocumentAclMemberRelation = "AND" | "OR" | (string & {});
export declare const DocumentAclMemberRelation: any;
export type DocumentAclMembershipType = "KNOWLEDGE_BASE" | "DATA_SOURCE" | (string & {});
export declare const DocumentAclMembershipType: any;
export interface DocumentAclUser {
    id: string;
    type: DocumentAclMembershipType;
}
export declare const DocumentAclUser: S.Schema<DocumentAclUser>;
export type DocumentAclUserList = DocumentAclUser[];
export declare const DocumentAclUserList: any;
export interface DocumentAclGroup {
    id: string;
    type: DocumentAclMembershipType;
}
export declare const DocumentAclGroup: S.Schema<DocumentAclGroup>;
export type DocumentAclGroupList = DocumentAclGroup[];
export declare const DocumentAclGroupList: any;
export interface DocumentAclCondition {
    conditionOperator?: DocumentAclMemberRelation;
    users?: DocumentAclUser[];
    groups?: DocumentAclGroup[];
}
export declare const DocumentAclCondition: S.Schema<DocumentAclCondition>;
export type DocumentAclConditionList = DocumentAclCondition[];
export declare const DocumentAclConditionList: any;
export interface DocumentAclMembership {
    memberRelation?: DocumentAclMemberRelation;
    conditions?: DocumentAclCondition[];
}
export declare const DocumentAclMembership: S.Schema<DocumentAclMembership>;
export interface DocumentAcl {
    allowList?: DocumentAclMembership;
    denyList?: DocumentAclMembership;
}
export declare const DocumentAcl: S.Schema<DocumentAcl>;
export interface GetIngestedDocumentAclResponse {
    documentAcl: DocumentAcl;
}
export declare const GetIngestedDocumentAclResponse: S.Schema<GetIngestedDocumentAclResponse>;
export type InvocationIdentifier = string;
export interface GetInvocationStepRequest {
    invocationIdentifier: string;
    invocationStepId: string;
    sessionIdentifier: string;
}
export declare const GetInvocationStepRequest: S.Schema<GetInvocationStepRequest>;
export type ImageFormat = "png" | "jpeg" | "gif" | "webp" | (string & {});
export declare const ImageFormat: any;
export type S3Uri = string;
export interface S3Location {
    uri: string;
}
export declare const S3Location: S.Schema<S3Location>;
export type ImageSource = {
    bytes: Uint8Array;
    s3Location?: never;
} | {
    bytes?: never;
    s3Location: S3Location;
};
export declare const ImageSource: any;
export interface ImageBlock {
    format: ImageFormat;
    source: ImageSource;
}
export declare const ImageBlock: S.Schema<ImageBlock>;
export type BedrockSessionContentBlock = {
    text: string;
    image?: never;
} | {
    text?: never;
    image: ImageBlock;
};
export declare const BedrockSessionContentBlock: any;
export type BedrockSessionContentBlocks = BedrockSessionContentBlock[];
export declare const BedrockSessionContentBlocks: any;
export type InvocationStepPayload = {
    contentBlocks: BedrockSessionContentBlock[];
};
export declare const InvocationStepPayload: any;
export interface InvocationStep {
    sessionId: string;
    invocationId: string;
    invocationStepId: string;
    invocationStepTime: Date;
    payload: InvocationStepPayload;
}
export declare const InvocationStep: S.Schema<InvocationStep>;
export interface GetInvocationStepResponse {
    invocationStep: InvocationStep;
}
export declare const GetInvocationStepResponse: S.Schema<GetInvocationStepResponse>;
export interface GetSessionRequest {
    sessionIdentifier: string;
}
export declare const GetSessionRequest: S.Schema<GetSessionRequest>;
export interface GetSessionResponse {
    sessionId: string;
    sessionArn: string;
    sessionStatus: SessionStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
    sessionMetadata?: {
        [key: string]: string | undefined;
    };
    encryptionKeyArn?: string;
}
export declare const GetSessionResponse: S.Schema<GetSessionResponse>;
export type SessionAttributesMap = {
    [key: string]: string | undefined;
};
export declare const SessionAttributesMap: any;
export type PromptSessionAttributesMap = {
    [key: string]: string | undefined;
};
export declare const PromptSessionAttributesMap: any;
export type ApiPath = string | redacted.Redacted<string>;
export type ConfirmationState = "CONFIRM" | "DENY" | (string & {});
export declare const ConfirmationState: any;
export type ResponseState = "FAILURE" | "REPROMPT" | (string & {});
export declare const ResponseState: any;
export type ImageInputFormat = "png" | "jpeg" | "gif" | "webp" | (string & {});
export declare const ImageInputFormat: any;
export type ImageInputSource = {
    bytes: Uint8Array;
};
export declare const ImageInputSource: any;
export interface ImageInput {
    format: ImageInputFormat;
    source: ImageInputSource;
}
export declare const ImageInput: S.Schema<ImageInput>;
export type ImageInputs = ImageInput[];
export declare const ImageInputs: any;
export interface ContentBody {
    body?: string;
    images?: ImageInput[];
}
export declare const ContentBody: S.Schema<ContentBody>;
export type ResponseBody = {
    [key: string]: ContentBody | undefined;
};
export declare const ResponseBody: any;
export interface ApiResult {
    actionGroup: string;
    httpMethod?: string;
    apiPath?: string | redacted.Redacted<string>;
    confirmationState?: ConfirmationState;
    responseState?: ResponseState;
    httpStatusCode?: number;
    responseBody?: {
        [key: string]: ContentBody | undefined;
    };
    agentId?: string;
}
export declare const ApiResult: S.Schema<ApiResult>;
export interface FunctionResult {
    actionGroup: string;
    confirmationState?: ConfirmationState;
    function?: string;
    responseBody?: {
        [key: string]: ContentBody | undefined;
    };
    responseState?: ResponseState;
    agentId?: string;
}
export declare const FunctionResult: S.Schema<FunctionResult>;
export type InvocationResultMember = {
    apiResult: ApiResult;
    functionResult?: never;
} | {
    apiResult?: never;
    functionResult: FunctionResult;
};
export declare const InvocationResultMember: any;
export type ReturnControlInvocationResults = InvocationResultMember[];
export declare const ReturnControlInvocationResults: any;
export type FileSourceType = "S3" | "BYTE_CONTENT" | (string & {});
export declare const FileSourceType: any;
export interface S3ObjectFile {
    uri: string;
}
export declare const S3ObjectFile: S.Schema<S3ObjectFile>;
export type ByteContentBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface ByteContentFile {
    mediaType: string;
    data: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const ByteContentFile: S.Schema<ByteContentFile>;
export interface FileSource {
    sourceType: FileSourceType;
    s3Location?: S3ObjectFile;
    byteContent?: ByteContentFile;
}
export declare const FileSource: S.Schema<FileSource>;
export type FileUseCase = "CODE_INTERPRETER" | "CHAT" | (string & {});
export declare const FileUseCase: any;
export interface InputFile {
    name: string;
    source: FileSource;
    useCase: FileUseCase;
}
export declare const InputFile: S.Schema<InputFile>;
export type InputFiles = InputFile[];
export declare const InputFiles: any;
export type SearchType = "HYBRID" | "SEMANTIC" | (string & {});
export declare const SearchType: any;
export type VectorSearchRerankingConfigurationType = "BEDROCK_RERANKING_MODEL" | (string & {});
export declare const VectorSearchRerankingConfigurationType: any;
export type BedrockRerankingModelArn = string;
export type AdditionalModelRequestFieldsKey = string;
export type AdditionalModelRequestFieldsValue = unknown;
export type AdditionalModelRequestFields = {
    [key: string]: any | undefined;
};
export declare const AdditionalModelRequestFields: any;
export interface VectorSearchBedrockRerankingModelConfiguration {
    modelArn: string;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    };
}
export declare const VectorSearchBedrockRerankingModelConfiguration: S.Schema<VectorSearchBedrockRerankingModelConfiguration>;
export type RerankingMetadataSelectionMode = "SELECTIVE" | "ALL" | (string & {});
export declare const RerankingMetadataSelectionMode: any;
export interface FieldForReranking {
    fieldName: string;
}
export declare const FieldForReranking: S.Schema<FieldForReranking>;
export type FieldsForReranking = FieldForReranking[];
export declare const FieldsForReranking: any;
export type RerankingMetadataSelectiveModeConfiguration = {
    fieldsToInclude: FieldForReranking[];
    fieldsToExclude?: never;
} | {
    fieldsToInclude?: never;
    fieldsToExclude: FieldForReranking[];
};
export declare const RerankingMetadataSelectiveModeConfiguration: any;
export interface MetadataConfigurationForReranking {
    selectionMode: RerankingMetadataSelectionMode;
    selectiveModeConfiguration?: RerankingMetadataSelectiveModeConfiguration;
}
export declare const MetadataConfigurationForReranking: S.Schema<MetadataConfigurationForReranking>;
export interface VectorSearchBedrockRerankingConfiguration {
    modelConfiguration: VectorSearchBedrockRerankingModelConfiguration;
    numberOfRerankedResults?: number;
    metadataConfiguration?: MetadataConfigurationForReranking;
}
export declare const VectorSearchBedrockRerankingConfiguration: S.Schema<VectorSearchBedrockRerankingConfiguration>;
export interface VectorSearchRerankingConfiguration {
    type: VectorSearchRerankingConfigurationType;
    bedrockRerankingConfiguration?: VectorSearchBedrockRerankingConfiguration;
}
export declare const VectorSearchRerankingConfiguration: S.Schema<VectorSearchRerankingConfiguration>;
export type AttributeType = "STRING" | "NUMBER" | "BOOLEAN" | "STRING_LIST" | (string & {});
export declare const AttributeType: any;
export interface MetadataAttributeSchema {
    key: string;
    type: AttributeType;
    description: string;
}
export declare const MetadataAttributeSchema: S.Schema<MetadataAttributeSchema>;
export type MetadataAttributeSchemaList = MetadataAttributeSchema[];
export declare const MetadataAttributeSchemaList: any;
export interface ImplicitFilterConfiguration {
    metadataAttributes: MetadataAttributeSchema[];
    modelArn: string;
}
export declare const ImplicitFilterConfiguration: S.Schema<ImplicitFilterConfiguration>;
export interface KnowledgeBaseVectorSearchConfiguration {
    numberOfResults?: number;
    overrideSearchType?: SearchType;
    filter?: RetrievalFilter;
    rerankingConfiguration?: VectorSearchRerankingConfiguration;
    implicitFilterConfiguration?: ImplicitFilterConfiguration;
}
export declare const KnowledgeBaseVectorSearchConfiguration: S.Schema<KnowledgeBaseVectorSearchConfiguration>;
export type RerankingModelType = "CUSTOM" | "MANAGED" | "NONE" | (string & {});
export declare const RerankingModelType: any;
export type ManagedSearchRerankingConfigurationType = "BEDROCK_RERANKING_MODEL" | (string & {});
export declare const ManagedSearchRerankingConfigurationType: any;
export interface ManagedSearchBedrockRerankingModelConfiguration {
    modelArn: string;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    };
}
export declare const ManagedSearchBedrockRerankingModelConfiguration: S.Schema<ManagedSearchBedrockRerankingModelConfiguration>;
export interface ManagedSearchBedrockRerankingConfiguration {
    modelConfiguration: ManagedSearchBedrockRerankingModelConfiguration;
    numberOfRerankedResults?: number;
    metadataConfiguration?: MetadataConfigurationForReranking;
}
export declare const ManagedSearchBedrockRerankingConfiguration: S.Schema<ManagedSearchBedrockRerankingConfiguration>;
export interface ManagedSearchRerankingConfiguration {
    type: ManagedSearchRerankingConfigurationType;
    bedrockRerankingConfiguration?: ManagedSearchBedrockRerankingConfiguration;
}
export declare const ManagedSearchRerankingConfiguration: S.Schema<ManagedSearchRerankingConfiguration>;
export interface ManagedSearchConfiguration {
    numberOfResults?: number;
    filter?: RetrievalFilter;
    rerankingModelType?: RerankingModelType;
    rerankingConfiguration?: ManagedSearchRerankingConfiguration;
}
export declare const ManagedSearchConfiguration: S.Schema<ManagedSearchConfiguration>;
export interface KnowledgeBaseRetrievalConfiguration {
    vectorSearchConfiguration?: KnowledgeBaseVectorSearchConfiguration;
    managedSearchConfiguration?: ManagedSearchConfiguration;
}
export declare const KnowledgeBaseRetrievalConfiguration: S.Schema<KnowledgeBaseRetrievalConfiguration>;
export interface KnowledgeBaseConfiguration {
    knowledgeBaseId: string;
    retrievalConfiguration: KnowledgeBaseRetrievalConfiguration;
}
export declare const KnowledgeBaseConfiguration: S.Schema<KnowledgeBaseConfiguration>;
export type KnowledgeBaseConfigurations = KnowledgeBaseConfiguration[];
export declare const KnowledgeBaseConfigurations: any;
export type ContentBlock = {
    text: string;
};
export declare const ContentBlock: any;
export type ContentBlocks = ContentBlock[];
export declare const ContentBlocks: any;
export interface Message {
    role: ConversationRole;
    content: ContentBlock[];
}
export declare const Message: S.Schema<Message>;
export type Messages = Message[];
export declare const Messages: any;
export interface ConversationHistory {
    messages?: Message[];
}
export declare const ConversationHistory: S.Schema<ConversationHistory>;
export interface SessionState {
    sessionAttributes?: {
        [key: string]: string | undefined;
    };
    promptSessionAttributes?: {
        [key: string]: string | undefined;
    };
    returnControlInvocationResults?: InvocationResultMember[];
    invocationId?: string;
    files?: InputFile[];
    knowledgeBaseConfigurations?: KnowledgeBaseConfiguration[];
    conversationHistory?: ConversationHistory;
}
export declare const SessionState: S.Schema<SessionState>;
export type InputText = string | redacted.Redacted<string>;
export type PerformanceConfigLatency = "standard" | "optimized" | (string & {});
export declare const PerformanceConfigLatency: any;
export interface PerformanceConfiguration {
    latency?: PerformanceConfigLatency;
}
export declare const PerformanceConfiguration: S.Schema<PerformanceConfiguration>;
export interface BedrockModelConfigurations {
    performanceConfig?: PerformanceConfiguration;
}
export declare const BedrockModelConfigurations: S.Schema<BedrockModelConfigurations>;
export interface StreamingConfigurations {
    streamFinalResponse?: boolean;
    applyGuardrailInterval?: number;
}
export declare const StreamingConfigurations: S.Schema<StreamingConfigurations>;
export interface PromptCreationConfigurations {
    previousConversationTurnsToInclude?: number;
    excludePreviousThinkingSteps?: boolean;
}
export declare const PromptCreationConfigurations: S.Schema<PromptCreationConfigurations>;
export type AWSResourceARN = string;
export interface InvokeAgentRequest {
    sessionState?: SessionState;
    agentId: string;
    agentAliasId: string;
    sessionId: string;
    endSession?: boolean;
    enableTrace?: boolean;
    inputText?: string | redacted.Redacted<string>;
    memoryId?: string;
    bedrockModelConfigurations?: BedrockModelConfigurations;
    streamingConfigurations?: StreamingConfigurations;
    promptCreationConfigurations?: PromptCreationConfigurations;
    sourceArn?: string;
}
export declare const InvokeAgentRequest: S.Schema<InvokeAgentRequest>;
export type PartBody = Uint8Array | redacted.Redacted<Uint8Array>;
export interface Span {
    start?: number;
    end?: number;
}
export declare const Span: S.Schema<Span>;
export interface TextResponsePart {
    text?: string;
    span?: Span;
}
export declare const TextResponsePart: S.Schema<TextResponsePart>;
export interface GeneratedResponsePart {
    textResponsePart?: TextResponsePart;
}
export declare const GeneratedResponsePart: S.Schema<GeneratedResponsePart>;
export type RetrievalResultContentType = "TEXT" | "IMAGE" | "ROW" | "AUDIO" | "VIDEO" | (string & {});
export declare const RetrievalResultContentType: any;
export interface VideoSegment {
    s3Uri: string;
    summary?: string;
}
export declare const VideoSegment: S.Schema<VideoSegment>;
export interface AudioSegment {
    s3Uri: string;
    transcription?: string;
}
export declare const AudioSegment: S.Schema<AudioSegment>;
export type RetrievalResultContentColumnType = "BLOB" | "BOOLEAN" | "DOUBLE" | "NULL" | "LONG" | "STRING" | (string & {});
export declare const RetrievalResultContentColumnType: any;
export interface RetrievalResultContentColumn {
    columnName?: string;
    columnValue?: string;
    type?: RetrievalResultContentColumnType;
}
export declare const RetrievalResultContentColumn: S.Schema<RetrievalResultContentColumn>;
export type RetrievalResultContentRow = RetrievalResultContentColumn[];
export declare const RetrievalResultContentRow: any;
export interface RetrievalResultContent {
    type?: RetrievalResultContentType;
    text?: string;
    byteContent?: string;
    video?: VideoSegment;
    audio?: AudioSegment;
    row?: RetrievalResultContentColumn[];
}
export declare const RetrievalResultContent: S.Schema<RetrievalResultContent>;
export type RetrievalResultLocationType = "S3" | "WEB" | "CONFLUENCE" | "SALESFORCE" | "SHAREPOINT" | "CUSTOM" | "KENDRA" | "SQL" | "ONEDRIVE" | "GOOGLEDRIVE" | (string & {});
export declare const RetrievalResultLocationType: any;
export interface RetrievalResultS3Location {
    uri?: string;
}
export declare const RetrievalResultS3Location: S.Schema<RetrievalResultS3Location>;
export interface RetrievalResultWebLocation {
    url?: string;
}
export declare const RetrievalResultWebLocation: S.Schema<RetrievalResultWebLocation>;
export interface RetrievalResultConfluenceLocation {
    url?: string;
}
export declare const RetrievalResultConfluenceLocation: S.Schema<RetrievalResultConfluenceLocation>;
export interface RetrievalResultSalesforceLocation {
    url?: string;
}
export declare const RetrievalResultSalesforceLocation: S.Schema<RetrievalResultSalesforceLocation>;
export interface RetrievalResultSharePointLocation {
    url?: string;
}
export declare const RetrievalResultSharePointLocation: S.Schema<RetrievalResultSharePointLocation>;
export interface RetrievalResultCustomDocumentLocation {
    id?: string;
}
export declare const RetrievalResultCustomDocumentLocation: S.Schema<RetrievalResultCustomDocumentLocation>;
export interface RetrievalResultKendraDocumentLocation {
    uri?: string;
}
export declare const RetrievalResultKendraDocumentLocation: S.Schema<RetrievalResultKendraDocumentLocation>;
export interface RetrievalResultSqlLocation {
    query?: string;
}
export declare const RetrievalResultSqlLocation: S.Schema<RetrievalResultSqlLocation>;
export interface RetrievalResultOneDriveLocation {
    url?: string;
}
export declare const RetrievalResultOneDriveLocation: S.Schema<RetrievalResultOneDriveLocation>;
export interface RetrievalResultGoogleDriveLocation {
    url?: string;
}
export declare const RetrievalResultGoogleDriveLocation: S.Schema<RetrievalResultGoogleDriveLocation>;
export interface RetrievalResultLocation {
    type: RetrievalResultLocationType;
    s3Location?: RetrievalResultS3Location;
    webLocation?: RetrievalResultWebLocation;
    confluenceLocation?: RetrievalResultConfluenceLocation;
    salesforceLocation?: RetrievalResultSalesforceLocation;
    sharePointLocation?: RetrievalResultSharePointLocation;
    customDocumentLocation?: RetrievalResultCustomDocumentLocation;
    kendraDocumentLocation?: RetrievalResultKendraDocumentLocation;
    sqlLocation?: RetrievalResultSqlLocation;
    oneDriveLocation?: RetrievalResultOneDriveLocation;
    googleDriveLocation?: RetrievalResultGoogleDriveLocation;
}
export declare const RetrievalResultLocation: S.Schema<RetrievalResultLocation>;
export type RetrievalResultMetadataKey = string;
export type RetrievalResultMetadataValue = unknown;
export type RetrievalResultMetadata = {
    [key: string]: any | undefined;
};
export declare const RetrievalResultMetadata: any;
export interface RetrievedReference {
    content?: RetrievalResultContent;
    location?: RetrievalResultLocation;
    metadata?: {
        [key: string]: any | undefined;
    };
}
export declare const RetrievedReference: S.Schema<RetrievedReference>;
export type RetrievedReferences = RetrievedReference[];
export declare const RetrievedReferences: any;
export interface Citation {
    generatedResponsePart?: GeneratedResponsePart;
    retrievedReferences?: RetrievedReference[];
}
export declare const Citation: S.Schema<Citation>;
export type Citations = Citation[];
export declare const Citations: any;
export interface Attribution {
    citations?: Citation[];
}
export declare const Attribution: S.Schema<Attribution>;
export interface PayloadPart {
    bytes?: Uint8Array | redacted.Redacted<Uint8Array>;
    attribution?: Attribution;
}
export declare const PayloadPart: S.Schema<PayloadPart>;
export type TraceId = string;
export type GuardrailTopicType = "DENY" | (string & {});
export declare const GuardrailTopicType: any;
export type GuardrailTopicPolicyAction = "BLOCKED" | (string & {});
export declare const GuardrailTopicPolicyAction: any;
export interface GuardrailTopic {
    name?: string;
    type?: GuardrailTopicType;
    action?: GuardrailTopicPolicyAction;
}
export declare const GuardrailTopic: S.Schema<GuardrailTopic>;
export type GuardrailTopicList = GuardrailTopic[];
export declare const GuardrailTopicList: any;
export interface GuardrailTopicPolicyAssessment {
    topics?: GuardrailTopic[];
}
export declare const GuardrailTopicPolicyAssessment: S.Schema<GuardrailTopicPolicyAssessment>;
export type GuardrailContentFilterType = "INSULTS" | "HATE" | "SEXUAL" | "VIOLENCE" | "MISCONDUCT" | "PROMPT_ATTACK" | (string & {});
export declare const GuardrailContentFilterType: any;
export type GuardrailContentFilterConfidence = "NONE" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export declare const GuardrailContentFilterConfidence: any;
export type GuardrailContentPolicyAction = "BLOCKED" | (string & {});
export declare const GuardrailContentPolicyAction: any;
export interface GuardrailContentFilter {
    type?: GuardrailContentFilterType;
    confidence?: GuardrailContentFilterConfidence;
    action?: GuardrailContentPolicyAction;
}
export declare const GuardrailContentFilter: S.Schema<GuardrailContentFilter>;
export type GuardrailContentFilterList = GuardrailContentFilter[];
export declare const GuardrailContentFilterList: any;
export interface GuardrailContentPolicyAssessment {
    filters?: GuardrailContentFilter[];
}
export declare const GuardrailContentPolicyAssessment: S.Schema<GuardrailContentPolicyAssessment>;
export type GuardrailWordPolicyAction = "BLOCKED" | (string & {});
export declare const GuardrailWordPolicyAction: any;
export interface GuardrailCustomWord {
    match?: string;
    action?: GuardrailWordPolicyAction;
}
export declare const GuardrailCustomWord: S.Schema<GuardrailCustomWord>;
export type GuardrailCustomWordList = GuardrailCustomWord[];
export declare const GuardrailCustomWordList: any;
export type GuardrailManagedWordType = "PROFANITY" | (string & {});
export declare const GuardrailManagedWordType: any;
export interface GuardrailManagedWord {
    match?: string;
    type?: GuardrailManagedWordType;
    action?: GuardrailWordPolicyAction;
}
export declare const GuardrailManagedWord: S.Schema<GuardrailManagedWord>;
export type GuardrailManagedWordList = GuardrailManagedWord[];
export declare const GuardrailManagedWordList: any;
export interface GuardrailWordPolicyAssessment {
    customWords?: GuardrailCustomWord[];
    managedWordLists?: GuardrailManagedWord[];
}
export declare const GuardrailWordPolicyAssessment: S.Schema<GuardrailWordPolicyAssessment>;
export type GuardrailPiiEntityType = "ADDRESS" | "AGE" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "CREDIT_DEBIT_CARD_CVV" | "CREDIT_DEBIT_CARD_EXPIRY" | "CREDIT_DEBIT_CARD_NUMBER" | "DRIVER_ID" | "EMAIL" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "IP_ADDRESS" | "LICENSE_PLATE" | "MAC_ADDRESS" | "NAME" | "PASSWORD" | "PHONE" | "PIN" | "SWIFT_CODE" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | "URL" | "USERNAME" | "US_BANK_ACCOUNT_NUMBER" | "US_BANK_ROUTING_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "US_PASSPORT_NUMBER" | "US_SOCIAL_SECURITY_NUMBER" | "VEHICLE_IDENTIFICATION_NUMBER" | (string & {});
export declare const GuardrailPiiEntityType: any;
export type GuardrailSensitiveInformationPolicyAction = "BLOCKED" | "ANONYMIZED" | (string & {});
export declare const GuardrailSensitiveInformationPolicyAction: any;
export interface GuardrailPiiEntityFilter {
    type?: GuardrailPiiEntityType;
    match?: string;
    action?: GuardrailSensitiveInformationPolicyAction;
}
export declare const GuardrailPiiEntityFilter: S.Schema<GuardrailPiiEntityFilter>;
export type GuardrailPiiEntityFilterList = GuardrailPiiEntityFilter[];
export declare const GuardrailPiiEntityFilterList: any;
export interface GuardrailRegexFilter {
    name?: string;
    regex?: string;
    match?: string;
    action?: GuardrailSensitiveInformationPolicyAction;
}
export declare const GuardrailRegexFilter: S.Schema<GuardrailRegexFilter>;
export type GuardrailRegexFilterList = GuardrailRegexFilter[];
export declare const GuardrailRegexFilterList: any;
export interface GuardrailSensitiveInformationPolicyAssessment {
    piiEntities?: GuardrailPiiEntityFilter[];
    regexes?: GuardrailRegexFilter[];
}
export declare const GuardrailSensitiveInformationPolicyAssessment: S.Schema<GuardrailSensitiveInformationPolicyAssessment>;
export interface GuardrailAssessment {
    topicPolicy?: GuardrailTopicPolicyAssessment;
    contentPolicy?: GuardrailContentPolicyAssessment;
    wordPolicy?: GuardrailWordPolicyAssessment;
    sensitiveInformationPolicy?: GuardrailSensitiveInformationPolicyAssessment;
}
export declare const GuardrailAssessment: S.Schema<GuardrailAssessment>;
export type GuardrailAssessmentList = GuardrailAssessment[];
export declare const GuardrailAssessmentList: any;
export interface Usage {
    inputTokens?: number;
    outputTokens?: number;
}
export declare const Usage: S.Schema<Usage>;
export interface Metadata {
    startTime?: Date;
    endTime?: Date;
    totalTimeMs?: number;
    operationTotalTimeMs?: number;
    clientRequestId?: string;
    usage?: Usage;
}
export declare const Metadata: S.Schema<Metadata>;
export interface GuardrailTrace {
    action?: GuardrailAction;
    traceId?: string;
    inputAssessments?: GuardrailAssessment[];
    outputAssessments?: GuardrailAssessment[];
    metadata?: Metadata;
}
export declare const GuardrailTrace: S.Schema<GuardrailTrace>;
export type PromptText = string | redacted.Redacted<string>;
export type PromptType = "PRE_PROCESSING" | "ORCHESTRATION" | "KNOWLEDGE_BASE_RESPONSE_GENERATION" | "POST_PROCESSING" | "ROUTING_CLASSIFIER" | (string & {});
export declare const PromptType: any;
export type LambdaArn = string;
export type CreationMode = "DEFAULT" | "OVERRIDDEN" | (string & {});
export declare const CreationMode: any;
export type Temperature = number;
export type TopP = number;
export type TopK = number;
export type MaximumLength = number;
export type StopSequences = string[];
export declare const StopSequences: any;
export interface InferenceConfiguration {
    temperature?: number;
    topP?: number;
    topK?: number;
    maximumLength?: number;
    stopSequences?: string[];
}
export declare const InferenceConfiguration: S.Schema<InferenceConfiguration>;
export type ModelIdentifier = string;
export interface ModelInvocationInput {
    traceId?: string;
    text?: string | redacted.Redacted<string>;
    type?: PromptType;
    overrideLambda?: string;
    promptCreationMode?: CreationMode;
    inferenceConfiguration?: InferenceConfiguration;
    parserMode?: CreationMode;
    foundationModel?: string;
}
export declare const ModelInvocationInput: S.Schema<ModelInvocationInput>;
export type RationaleString = string | redacted.Redacted<string>;
export interface PreProcessingParsedResponse {
    rationale?: string | redacted.Redacted<string>;
    isValid?: boolean;
}
export declare const PreProcessingParsedResponse: S.Schema<PreProcessingParsedResponse>;
export interface RawResponse {
    content?: string;
}
export declare const RawResponse: S.Schema<RawResponse>;
export interface ReasoningTextBlock {
    text: string;
    signature?: string;
}
export declare const ReasoningTextBlock: S.Schema<ReasoningTextBlock>;
export type ReasoningContentBlock = {
    reasoningText: ReasoningTextBlock;
    redactedContent?: never;
} | {
    reasoningText?: never;
    redactedContent: Uint8Array;
};
export declare const ReasoningContentBlock: any;
export interface PreProcessingModelInvocationOutput {
    traceId?: string;
    parsedResponse?: PreProcessingParsedResponse;
    rawResponse?: RawResponse;
    metadata?: Metadata;
    reasoningContent?: ReasoningContentBlock;
}
export declare const PreProcessingModelInvocationOutput: S.Schema<PreProcessingModelInvocationOutput>;
export type PreProcessingTrace = {
    modelInvocationInput: ModelInvocationInput;
    modelInvocationOutput?: never;
} | {
    modelInvocationInput?: never;
    modelInvocationOutput: PreProcessingModelInvocationOutput;
};
export declare const PreProcessingTrace: any;
export interface Rationale {
    traceId?: string;
    text?: string | redacted.Redacted<string>;
}
export declare const Rationale: S.Schema<Rationale>;
export type InvocationType = "ACTION_GROUP" | "KNOWLEDGE_BASE" | "FINISH" | "ACTION_GROUP_CODE_INTERPRETER" | "AGENT_COLLABORATOR" | (string & {});
export declare const InvocationType: any;
export type ActionGroupName = string | redacted.Redacted<string>;
export type Verb = string | redacted.Redacted<string>;
export interface Parameter {
    name?: string;
    type?: string;
    value?: string;
}
export declare const Parameter: S.Schema<Parameter>;
export type Parameters = Parameter[];
export declare const Parameters: any;
export type ContentMap = {
    [key: string]: Parameter[] | undefined;
};
export declare const ContentMap: any;
export interface RequestBody {
    content?: {
        [key: string]: Parameter[] | undefined;
    };
}
export declare const RequestBody: S.Schema<RequestBody>;
export type ExecutionType = "LAMBDA" | "RETURN_CONTROL" | (string & {});
export declare const ExecutionType: any;
export interface ActionGroupInvocationInput {
    actionGroupName?: string | redacted.Redacted<string>;
    verb?: string | redacted.Redacted<string>;
    apiPath?: string | redacted.Redacted<string>;
    parameters?: Parameter[];
    requestBody?: RequestBody;
    function?: string | redacted.Redacted<string>;
    executionType?: ExecutionType;
    invocationId?: string;
}
export declare const ActionGroupInvocationInput: S.Schema<ActionGroupInvocationInput>;
export type KnowledgeBaseLookupInputString = string | redacted.Redacted<string>;
export type TraceKnowledgeBaseId = string | redacted.Redacted<string>;
export interface KnowledgeBaseLookupInput {
    text?: string | redacted.Redacted<string>;
    knowledgeBaseId?: string | redacted.Redacted<string>;
}
export declare const KnowledgeBaseLookupInput: S.Schema<KnowledgeBaseLookupInput>;
export type Files = string[];
export declare const Files: any;
export interface CodeInterpreterInvocationInput {
    code?: string;
    files?: string[];
}
export declare const CodeInterpreterInvocationInput: S.Schema<CodeInterpreterInvocationInput>;
export type AgentAliasArn = string;
export type PayloadType = "TEXT" | "RETURN_CONTROL" | (string & {});
export declare const PayloadType: any;
export type AgentCollaboratorPayloadString = string | redacted.Redacted<string>;
export interface ReturnControlResults {
    invocationId?: string;
    returnControlInvocationResults?: InvocationResultMember[];
}
export declare const ReturnControlResults: S.Schema<ReturnControlResults>;
export interface AgentCollaboratorInputPayload {
    type?: PayloadType;
    text?: string | redacted.Redacted<string>;
    returnControlResults?: ReturnControlResults;
}
export declare const AgentCollaboratorInputPayload: S.Schema<AgentCollaboratorInputPayload>;
export interface AgentCollaboratorInvocationInput {
    agentCollaboratorName?: string;
    agentCollaboratorAliasArn?: string;
    input?: AgentCollaboratorInputPayload;
}
export declare const AgentCollaboratorInvocationInput: S.Schema<AgentCollaboratorInvocationInput>;
export interface InvocationInput {
    traceId?: string;
    invocationType?: InvocationType;
    actionGroupInvocationInput?: ActionGroupInvocationInput;
    knowledgeBaseLookupInput?: KnowledgeBaseLookupInput;
    codeInterpreterInvocationInput?: CodeInterpreterInvocationInput;
    agentCollaboratorInvocationInput?: AgentCollaboratorInvocationInput;
}
export declare const InvocationInput: S.Schema<InvocationInput>;
export type Type = "ACTION_GROUP" | "AGENT_COLLABORATOR" | "KNOWLEDGE_BASE" | "FINISH" | "ASK_USER" | "REPROMPT" | (string & {});
export declare const Type: any;
export type ActionGroupOutputString = string | redacted.Redacted<string>;
export interface ActionGroupInvocationOutput {
    text?: string | redacted.Redacted<string>;
    metadata?: Metadata;
}
export declare const ActionGroupInvocationOutput: S.Schema<ActionGroupInvocationOutput>;
export interface ApiParameter {
    name?: string;
    type?: string;
    value?: string;
}
export declare const ApiParameter: S.Schema<ApiParameter>;
export type ApiParameters = ApiParameter[];
export declare const ApiParameters: any;
export type ParameterList = Parameter[];
export declare const ParameterList: any;
export interface PropertyParameters {
    properties?: Parameter[];
}
export declare const PropertyParameters: S.Schema<PropertyParameters>;
export type ApiContentMap = {
    [key: string]: PropertyParameters | undefined;
};
export declare const ApiContentMap: any;
export interface ApiRequestBody {
    content?: {
        [key: string]: PropertyParameters | undefined;
    };
}
export declare const ApiRequestBody: S.Schema<ApiRequestBody>;
export type ActionInvocationType = "RESULT" | "USER_CONFIRMATION" | "USER_CONFIRMATION_AND_RESULT" | (string & {});
export declare const ActionInvocationType: any;
export type Name = string | redacted.Redacted<string>;
export interface ApiInvocationInput {
    actionGroup: string;
    httpMethod?: string;
    apiPath?: string | redacted.Redacted<string>;
    parameters?: ApiParameter[];
    requestBody?: ApiRequestBody;
    actionInvocationType?: ActionInvocationType;
    agentId?: string;
    collaboratorName?: string | redacted.Redacted<string>;
}
export declare const ApiInvocationInput: S.Schema<ApiInvocationInput>;
export interface FunctionParameter {
    name?: string;
    type?: string;
    value?: string;
}
export declare const FunctionParameter: S.Schema<FunctionParameter>;
export type FunctionParameters = FunctionParameter[];
export declare const FunctionParameters: any;
export interface FunctionInvocationInput {
    actionGroup: string;
    parameters?: FunctionParameter[];
    function?: string;
    actionInvocationType?: ActionInvocationType;
    agentId?: string;
    collaboratorName?: string | redacted.Redacted<string>;
}
export declare const FunctionInvocationInput: S.Schema<FunctionInvocationInput>;
export type InvocationInputMember = {
    apiInvocationInput: ApiInvocationInput;
    functionInvocationInput?: never;
} | {
    apiInvocationInput?: never;
    functionInvocationInput: FunctionInvocationInput;
};
export declare const InvocationInputMember: any;
export type InvocationInputs = InvocationInputMember[];
export declare const InvocationInputs: any;
export interface ReturnControlPayload {
    invocationInputs?: InvocationInputMember[];
    invocationId?: string;
}
export declare const ReturnControlPayload: S.Schema<ReturnControlPayload>;
export interface AgentCollaboratorOutputPayload {
    type?: PayloadType;
    text?: string | redacted.Redacted<string>;
    returnControlPayload?: ReturnControlPayload;
}
export declare const AgentCollaboratorOutputPayload: S.Schema<AgentCollaboratorOutputPayload>;
export interface AgentCollaboratorInvocationOutput {
    agentCollaboratorName?: string;
    agentCollaboratorAliasArn?: string;
    output?: AgentCollaboratorOutputPayload;
    metadata?: Metadata;
}
export declare const AgentCollaboratorInvocationOutput: S.Schema<AgentCollaboratorInvocationOutput>;
export interface KnowledgeBaseLookupOutput {
    retrievedReferences?: RetrievedReference[];
    metadata?: Metadata;
}
export declare const KnowledgeBaseLookupOutput: S.Schema<KnowledgeBaseLookupOutput>;
export type FinalResponseString = string | redacted.Redacted<string>;
export interface FinalResponse {
    text?: string | redacted.Redacted<string>;
    metadata?: Metadata;
}
export declare const FinalResponse: S.Schema<FinalResponse>;
export type Source = "ACTION_GROUP" | "KNOWLEDGE_BASE" | "PARSER" | (string & {});
export declare const Source: any;
export interface RepromptResponse {
    text?: string;
    source?: Source;
}
export declare const RepromptResponse: S.Schema<RepromptResponse>;
export interface CodeInterpreterInvocationOutput {
    executionOutput?: string;
    executionError?: string;
    files?: string[];
    executionTimeout?: boolean;
    metadata?: Metadata;
}
export declare const CodeInterpreterInvocationOutput: S.Schema<CodeInterpreterInvocationOutput>;
export interface Observation {
    traceId?: string;
    type?: Type;
    actionGroupInvocationOutput?: ActionGroupInvocationOutput;
    agentCollaboratorInvocationOutput?: AgentCollaboratorInvocationOutput;
    knowledgeBaseLookupOutput?: KnowledgeBaseLookupOutput;
    finalResponse?: FinalResponse;
    repromptResponse?: RepromptResponse;
    codeInterpreterInvocationOutput?: CodeInterpreterInvocationOutput;
}
export declare const Observation: S.Schema<Observation>;
export interface OrchestrationModelInvocationOutput {
    traceId?: string;
    rawResponse?: RawResponse;
    metadata?: Metadata;
    reasoningContent?: ReasoningContentBlock;
}
export declare const OrchestrationModelInvocationOutput: S.Schema<OrchestrationModelInvocationOutput>;
export type OrchestrationTrace = {
    rationale: Rationale;
    invocationInput?: never;
    observation?: never;
    modelInvocationInput?: never;
    modelInvocationOutput?: never;
} | {
    rationale?: never;
    invocationInput: InvocationInput;
    observation?: never;
    modelInvocationInput?: never;
    modelInvocationOutput?: never;
} | {
    rationale?: never;
    invocationInput?: never;
    observation: Observation;
    modelInvocationInput?: never;
    modelInvocationOutput?: never;
} | {
    rationale?: never;
    invocationInput?: never;
    observation?: never;
    modelInvocationInput: ModelInvocationInput;
    modelInvocationOutput?: never;
} | {
    rationale?: never;
    invocationInput?: never;
    observation?: never;
    modelInvocationInput?: never;
    modelInvocationOutput: OrchestrationModelInvocationOutput;
};
export declare const OrchestrationTrace: any;
export type OutputString = string | redacted.Redacted<string>;
export interface PostProcessingParsedResponse {
    text?: string | redacted.Redacted<string>;
}
export declare const PostProcessingParsedResponse: S.Schema<PostProcessingParsedResponse>;
export interface PostProcessingModelInvocationOutput {
    traceId?: string;
    parsedResponse?: PostProcessingParsedResponse;
    rawResponse?: RawResponse;
    metadata?: Metadata;
    reasoningContent?: ReasoningContentBlock;
}
export declare const PostProcessingModelInvocationOutput: S.Schema<PostProcessingModelInvocationOutput>;
export type PostProcessingTrace = {
    modelInvocationInput: ModelInvocationInput;
    modelInvocationOutput?: never;
} | {
    modelInvocationInput?: never;
    modelInvocationOutput: PostProcessingModelInvocationOutput;
};
export declare const PostProcessingTrace: any;
export interface RoutingClassifierModelInvocationOutput {
    traceId?: string;
    rawResponse?: RawResponse;
    metadata?: Metadata;
}
export declare const RoutingClassifierModelInvocationOutput: S.Schema<RoutingClassifierModelInvocationOutput>;
export type RoutingClassifierTrace = {
    invocationInput: InvocationInput;
    observation?: never;
    modelInvocationInput?: never;
    modelInvocationOutput?: never;
} | {
    invocationInput?: never;
    observation: Observation;
    modelInvocationInput?: never;
    modelInvocationOutput?: never;
} | {
    invocationInput?: never;
    observation?: never;
    modelInvocationInput: ModelInvocationInput;
    modelInvocationOutput?: never;
} | {
    invocationInput?: never;
    observation?: never;
    modelInvocationInput?: never;
    modelInvocationOutput: RoutingClassifierModelInvocationOutput;
};
export declare const RoutingClassifierTrace: any;
export type FailureReasonString = string | redacted.Redacted<string>;
export interface FailureTrace {
    traceId?: string;
    failureReason?: string | redacted.Redacted<string>;
    failureCode?: number;
    metadata?: Metadata;
}
export declare const FailureTrace: S.Schema<FailureTrace>;
export interface CustomOrchestrationTraceEvent {
    text?: string;
}
export declare const CustomOrchestrationTraceEvent: S.Schema<CustomOrchestrationTraceEvent>;
export interface CustomOrchestrationTrace {
    traceId?: string;
    event?: CustomOrchestrationTraceEvent;
}
export declare const CustomOrchestrationTrace: S.Schema<CustomOrchestrationTrace>;
export type Trace = {
    guardrailTrace: GuardrailTrace;
    preProcessingTrace?: never;
    orchestrationTrace?: never;
    postProcessingTrace?: never;
    routingClassifierTrace?: never;
    failureTrace?: never;
    customOrchestrationTrace?: never;
} | {
    guardrailTrace?: never;
    preProcessingTrace: PreProcessingTrace;
    orchestrationTrace?: never;
    postProcessingTrace?: never;
    routingClassifierTrace?: never;
    failureTrace?: never;
    customOrchestrationTrace?: never;
} | {
    guardrailTrace?: never;
    preProcessingTrace?: never;
    orchestrationTrace: OrchestrationTrace;
    postProcessingTrace?: never;
    routingClassifierTrace?: never;
    failureTrace?: never;
    customOrchestrationTrace?: never;
} | {
    guardrailTrace?: never;
    preProcessingTrace?: never;
    orchestrationTrace?: never;
    postProcessingTrace: PostProcessingTrace;
    routingClassifierTrace?: never;
    failureTrace?: never;
    customOrchestrationTrace?: never;
} | {
    guardrailTrace?: never;
    preProcessingTrace?: never;
    orchestrationTrace?: never;
    postProcessingTrace?: never;
    routingClassifierTrace: RoutingClassifierTrace;
    failureTrace?: never;
    customOrchestrationTrace?: never;
} | {
    guardrailTrace?: never;
    preProcessingTrace?: never;
    orchestrationTrace?: never;
    postProcessingTrace?: never;
    routingClassifierTrace?: never;
    failureTrace: FailureTrace;
    customOrchestrationTrace?: never;
} | {
    guardrailTrace?: never;
    preProcessingTrace?: never;
    orchestrationTrace?: never;
    postProcessingTrace?: never;
    routingClassifierTrace?: never;
    failureTrace?: never;
    customOrchestrationTrace: CustomOrchestrationTrace;
};
export declare const Trace: any;
export type Caller = {
    agentAliasArn: string;
};
export declare const Caller: any;
export type CallerChain = Caller[];
export declare const CallerChain: any;
export type AgentVersion = string;
export interface TracePart {
    sessionId?: string;
    trace?: Trace;
    callerChain?: Caller[];
    eventTime?: Date;
    collaboratorName?: string | redacted.Redacted<string>;
    agentId?: string;
    agentAliasId?: string;
    agentVersion?: string;
}
export declare const TracePart: S.Schema<TracePart>;
export type FileBody = Uint8Array | redacted.Redacted<Uint8Array>;
export interface OutputFile {
    name?: string;
    type?: string;
    bytes?: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const OutputFile: S.Schema<OutputFile>;
export type OutputFiles = OutputFile[];
export declare const OutputFiles: any;
export interface FilePart {
    files?: OutputFile[];
}
export declare const FilePart: S.Schema<FilePart>;
export type ResponseStream = {
    chunk: PayloadPart;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    modelNotReadyException?: never;
    files?: never;
} | {
    chunk?: never;
    trace: TracePart;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    modelNotReadyException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl: ReturnControlPayload;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    modelNotReadyException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException: InternalServerException;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    modelNotReadyException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException: ValidationException;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    modelNotReadyException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    modelNotReadyException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    modelNotReadyException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException: ThrottlingException;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    modelNotReadyException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException: AccessDeniedException;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    modelNotReadyException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException: ConflictException;
    dependencyFailedException?: never;
    badGatewayException?: never;
    modelNotReadyException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException: DependencyFailedException;
    badGatewayException?: never;
    modelNotReadyException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException: BadGatewayException;
    modelNotReadyException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    modelNotReadyException: ModelNotReadyException;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    modelNotReadyException?: never;
    files: FilePart;
};
export declare const ResponseStream: S.Schema<stream.Stream<ResponseStream, Error, never>>;
export interface InvokeAgentResponse {
    completion: stream.Stream<ResponseStream, Error, never>;
    contentType: string;
    sessionId: string;
    memoryId?: string;
}
export declare const InvokeAgentResponse: S.Schema<InvokeAgentResponse>;
export type NodeOutputName = string;
export type FlowInputContent = {
    document: any;
};
export declare const FlowInputContent: any;
export type NodeInputName = string;
export interface FlowInput {
    nodeName: string;
    nodeOutputName?: string;
    content: FlowInputContent;
    nodeInputName?: string;
}
export declare const FlowInput: S.Schema<FlowInput>;
export type FlowInputs = FlowInput[];
export declare const FlowInputs: any;
export interface ModelPerformanceConfiguration {
    performanceConfig?: PerformanceConfiguration;
}
export declare const ModelPerformanceConfiguration: S.Schema<ModelPerformanceConfiguration>;
export type FlowExecutionId = string;
export interface InvokeFlowRequest {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    inputs: FlowInput[];
    enableTrace?: boolean;
    modelPerformanceConfiguration?: ModelPerformanceConfiguration;
    executionId?: string;
}
export declare const InvokeFlowRequest: S.Schema<InvokeFlowRequest>;
export type NodeType = "FlowInputNode" | "FlowOutputNode" | "LambdaFunctionNode" | "KnowledgeBaseNode" | "PromptNode" | "ConditionNode" | "LexNode" | (string & {});
export declare const NodeType: any;
export type FlowOutputContent = {
    document: any;
};
export declare const FlowOutputContent: any;
export interface FlowOutputEvent {
    nodeName: string;
    nodeType: NodeType;
    content: FlowOutputContent;
}
export declare const FlowOutputEvent: S.Schema<FlowOutputEvent>;
export type FlowCompletionReason = "SUCCESS" | "INPUT_REQUIRED" | (string & {});
export declare const FlowCompletionReason: any;
export interface FlowCompletionEvent {
    completionReason: FlowCompletionReason;
}
export declare const FlowCompletionEvent: S.Schema<FlowCompletionEvent>;
export type FlowTraceNodeInputContent = {
    document: any;
};
export declare const FlowTraceNodeInputContent: any;
export type FlowNodeOutputName = string;
export type FlowNodeInputExpression = string | redacted.Redacted<string>;
export interface FlowTraceNodeInputSource {
    nodeName: string;
    outputFieldName: string;
    expression: string | redacted.Redacted<string>;
}
export declare const FlowTraceNodeInputSource: S.Schema<FlowTraceNodeInputSource>;
export type FlowNodeIODataType = "String" | "Number" | "Boolean" | "Object" | "Array" | (string & {});
export declare const FlowNodeIODataType: any;
export type FlowNodeInputCategory = "LoopCondition" | "ReturnValueToLoopStart" | "ExitLoop" | (string & {});
export declare const FlowNodeInputCategory: any;
export type FlowControlNodeType = "Iterator" | "Loop" | (string & {});
export declare const FlowControlNodeType: any;
export interface FlowTraceNodeInputExecutionChainItem {
    nodeName: string;
    index?: number;
    type: FlowControlNodeType;
}
export declare const FlowTraceNodeInputExecutionChainItem: S.Schema<FlowTraceNodeInputExecutionChainItem>;
export type FlowTraceNodeInputExecutionChain = FlowTraceNodeInputExecutionChainItem[];
export declare const FlowTraceNodeInputExecutionChain: any;
export interface FlowTraceNodeInputField {
    nodeInputName: string;
    content: FlowTraceNodeInputContent;
    source?: FlowTraceNodeInputSource;
    type?: FlowNodeIODataType;
    category?: FlowNodeInputCategory;
    executionChain?: FlowTraceNodeInputExecutionChainItem[];
}
export declare const FlowTraceNodeInputField: S.Schema<FlowTraceNodeInputField>;
export type FlowTraceNodeInputFields = FlowTraceNodeInputField[];
export declare const FlowTraceNodeInputFields: any;
export interface FlowTraceNodeInputEvent {
    nodeName: string;
    timestamp: Date;
    fields: FlowTraceNodeInputField[];
}
export declare const FlowTraceNodeInputEvent: S.Schema<FlowTraceNodeInputEvent>;
export type FlowTraceNodeOutputContent = {
    document: any;
};
export declare const FlowTraceNodeOutputContent: any;
export type FlowNodeInputName = string;
export interface FlowTraceNodeOutputNext {
    nodeName: string;
    inputFieldName: string;
}
export declare const FlowTraceNodeOutputNext: S.Schema<FlowTraceNodeOutputNext>;
export type FlowTraceNodeOutputNextList = FlowTraceNodeOutputNext[];
export declare const FlowTraceNodeOutputNextList: any;
export interface FlowTraceNodeOutputField {
    nodeOutputName: string;
    content: FlowTraceNodeOutputContent;
    next?: FlowTraceNodeOutputNext[];
    type?: FlowNodeIODataType;
}
export declare const FlowTraceNodeOutputField: S.Schema<FlowTraceNodeOutputField>;
export type FlowTraceNodeOutputFields = FlowTraceNodeOutputField[];
export declare const FlowTraceNodeOutputFields: any;
export interface FlowTraceNodeOutputEvent {
    nodeName: string;
    timestamp: Date;
    fields: FlowTraceNodeOutputField[];
}
export declare const FlowTraceNodeOutputEvent: S.Schema<FlowTraceNodeOutputEvent>;
export interface FlowTraceCondition {
    conditionName: string;
}
export declare const FlowTraceCondition: S.Schema<FlowTraceCondition>;
export type FlowTraceConditions = FlowTraceCondition[];
export declare const FlowTraceConditions: any;
export interface FlowTraceConditionNodeResultEvent {
    nodeName: string;
    timestamp: Date;
    satisfiedConditions: FlowTraceCondition[];
}
export declare const FlowTraceConditionNodeResultEvent: S.Schema<FlowTraceConditionNodeResultEvent>;
export interface FlowTraceNodeActionEvent {
    nodeName: string;
    timestamp: Date;
    requestId: string;
    serviceName: string;
    operationName: string;
    operationRequest?: any;
    operationResponse?: any;
}
export declare const FlowTraceNodeActionEvent: S.Schema<FlowTraceNodeActionEvent>;
export type AgentTraces = TracePart[];
export declare const AgentTraces: any;
export type TraceElements = {
    agentTraces: TracePart[];
};
export declare const TraceElements: any;
export interface FlowTraceDependencyEvent {
    nodeName: string;
    timestamp: Date;
    traceElements: TraceElements;
}
export declare const FlowTraceDependencyEvent: S.Schema<FlowTraceDependencyEvent>;
export type FlowTrace = {
    nodeInputTrace: FlowTraceNodeInputEvent;
    nodeOutputTrace?: never;
    conditionNodeResultTrace?: never;
    nodeActionTrace?: never;
    nodeDependencyTrace?: never;
} | {
    nodeInputTrace?: never;
    nodeOutputTrace: FlowTraceNodeOutputEvent;
    conditionNodeResultTrace?: never;
    nodeActionTrace?: never;
    nodeDependencyTrace?: never;
} | {
    nodeInputTrace?: never;
    nodeOutputTrace?: never;
    conditionNodeResultTrace: FlowTraceConditionNodeResultEvent;
    nodeActionTrace?: never;
    nodeDependencyTrace?: never;
} | {
    nodeInputTrace?: never;
    nodeOutputTrace?: never;
    conditionNodeResultTrace?: never;
    nodeActionTrace: FlowTraceNodeActionEvent;
    nodeDependencyTrace?: never;
} | {
    nodeInputTrace?: never;
    nodeOutputTrace?: never;
    conditionNodeResultTrace?: never;
    nodeActionTrace?: never;
    nodeDependencyTrace: FlowTraceDependencyEvent;
};
export declare const FlowTrace: any;
export interface FlowTraceEvent {
    trace: FlowTrace;
}
export declare const FlowTraceEvent: S.Schema<FlowTraceEvent>;
export type FlowMultiTurnInputContent = {
    document: any;
};
export declare const FlowMultiTurnInputContent: any;
export interface FlowMultiTurnInputRequestEvent {
    nodeName: string;
    nodeType: NodeType;
    content: FlowMultiTurnInputContent;
}
export declare const FlowMultiTurnInputRequestEvent: S.Schema<FlowMultiTurnInputRequestEvent>;
export type FlowResponseStream = {
    flowOutputEvent: FlowOutputEvent;
    flowCompletionEvent?: never;
    flowTraceEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    flowMultiTurnInputRequestEvent?: never;
} | {
    flowOutputEvent?: never;
    flowCompletionEvent: FlowCompletionEvent;
    flowTraceEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    flowMultiTurnInputRequestEvent?: never;
} | {
    flowOutputEvent?: never;
    flowCompletionEvent?: never;
    flowTraceEvent: FlowTraceEvent;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    flowMultiTurnInputRequestEvent?: never;
} | {
    flowOutputEvent?: never;
    flowCompletionEvent?: never;
    flowTraceEvent?: never;
    internalServerException: InternalServerException;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    flowMultiTurnInputRequestEvent?: never;
} | {
    flowOutputEvent?: never;
    flowCompletionEvent?: never;
    flowTraceEvent?: never;
    internalServerException?: never;
    validationException: ValidationException;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    flowMultiTurnInputRequestEvent?: never;
} | {
    flowOutputEvent?: never;
    flowCompletionEvent?: never;
    flowTraceEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    flowMultiTurnInputRequestEvent?: never;
} | {
    flowOutputEvent?: never;
    flowCompletionEvent?: never;
    flowTraceEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    flowMultiTurnInputRequestEvent?: never;
} | {
    flowOutputEvent?: never;
    flowCompletionEvent?: never;
    flowTraceEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException: ThrottlingException;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    flowMultiTurnInputRequestEvent?: never;
} | {
    flowOutputEvent?: never;
    flowCompletionEvent?: never;
    flowTraceEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException: AccessDeniedException;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    flowMultiTurnInputRequestEvent?: never;
} | {
    flowOutputEvent?: never;
    flowCompletionEvent?: never;
    flowTraceEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException: ConflictException;
    dependencyFailedException?: never;
    badGatewayException?: never;
    flowMultiTurnInputRequestEvent?: never;
} | {
    flowOutputEvent?: never;
    flowCompletionEvent?: never;
    flowTraceEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException: DependencyFailedException;
    badGatewayException?: never;
    flowMultiTurnInputRequestEvent?: never;
} | {
    flowOutputEvent?: never;
    flowCompletionEvent?: never;
    flowTraceEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException: BadGatewayException;
    flowMultiTurnInputRequestEvent?: never;
} | {
    flowOutputEvent?: never;
    flowCompletionEvent?: never;
    flowTraceEvent?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    flowMultiTurnInputRequestEvent: FlowMultiTurnInputRequestEvent;
};
export declare const FlowResponseStream: S.Schema<stream.Stream<FlowResponseStream, Error, never>>;
export interface InvokeFlowResponse {
    responseStream: stream.Stream<FlowResponseStream, Error, never>;
    executionId?: string;
}
export declare const InvokeFlowResponse: S.Schema<InvokeFlowResponse>;
export type Instruction = string | redacted.Redacted<string>;
export type SessionTTL = number;
export type ResourceName = string | redacted.Redacted<string>;
export type ResourceDescription = string | redacted.Redacted<string>;
export type ActionGroupSignature = "AMAZON.UserInput" | "AMAZON.CodeInterpreter" | "ANTHROPIC.Computer" | "ANTHROPIC.Bash" | "ANTHROPIC.TextEditor" | (string & {});
export declare const ActionGroupSignature: any;
export type LambdaResourceArn = string;
export type CustomControlMethod = "RETURN_CONTROL" | (string & {});
export declare const CustomControlMethod: any;
export type ActionGroupExecutor = {
    lambda: string;
    customControl?: never;
} | {
    lambda?: never;
    customControl: CustomControlMethod;
};
export declare const ActionGroupExecutor: any;
export type S3BucketName = string;
export type S3ObjectKey = string;
export interface S3Identifier {
    s3BucketName?: string;
    s3ObjectKey?: string;
}
export declare const S3Identifier: S.Schema<S3Identifier>;
export type Payload = string | redacted.Redacted<string>;
export type APISchema = {
    s3: S3Identifier;
    payload?: never;
} | {
    s3?: never;
    payload: string | redacted.Redacted<string>;
};
export declare const APISchema: any;
export type FunctionDescription = string;
export type ParameterName = string;
export type ParameterDescription = string;
export type ParameterType = "string" | "number" | "integer" | "boolean" | "array" | (string & {});
export declare const ParameterType: any;
export interface ParameterDetail {
    description?: string;
    type: ParameterType;
    required?: boolean;
}
export declare const ParameterDetail: S.Schema<ParameterDetail>;
export type ParameterMap = {
    [key: string]: ParameterDetail | undefined;
};
export declare const ParameterMap: any;
export type RequireConfirmation = "ENABLED" | "DISABLED" | (string & {});
export declare const RequireConfirmation: any;
export interface FunctionDefinition {
    name: string | redacted.Redacted<string>;
    description?: string;
    parameters?: {
        [key: string]: ParameterDetail | undefined;
    };
    requireConfirmation?: RequireConfirmation;
}
export declare const FunctionDefinition: S.Schema<FunctionDefinition>;
export type Functions = FunctionDefinition[];
export declare const Functions: any;
export type FunctionSchema = {
    functions: FunctionDefinition[];
};
export declare const FunctionSchema: any;
export type ActionGroupSignatureParams = {
    [key: string]: string | undefined;
};
export declare const ActionGroupSignatureParams: any;
export interface AgentActionGroup {
    actionGroupName: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    parentActionGroupSignature?: ActionGroupSignature;
    actionGroupExecutor?: ActionGroupExecutor;
    apiSchema?: APISchema;
    functionSchema?: FunctionSchema;
    parentActionGroupSignatureParams?: {
        [key: string]: string | undefined;
    };
}
export declare const AgentActionGroup: S.Schema<AgentActionGroup>;
export type AgentActionGroups = AgentActionGroup[];
export declare const AgentActionGroups: any;
export interface KnowledgeBase {
    knowledgeBaseId: string;
    description: string | redacted.Redacted<string>;
    retrievalConfiguration?: KnowledgeBaseRetrievalConfiguration;
}
export declare const KnowledgeBase: S.Schema<KnowledgeBase>;
export type KnowledgeBases = KnowledgeBase[];
export declare const KnowledgeBases: any;
export type GuardrailIdentifierWithArn = string;
export type GuardrailVersion = string;
export interface GuardrailConfigurationWithArn {
    guardrailIdentifier: string;
    guardrailVersion: string;
}
export declare const GuardrailConfigurationWithArn: S.Schema<GuardrailConfigurationWithArn>;
export type PromptState = "ENABLED" | "DISABLED" | (string & {});
export declare const PromptState: any;
export type BasePromptTemplate = string | redacted.Redacted<string>;
export interface PromptConfiguration {
    promptType?: PromptType;
    promptCreationMode?: CreationMode;
    promptState?: PromptState;
    basePromptTemplate?: string | redacted.Redacted<string>;
    inferenceConfiguration?: InferenceConfiguration;
    parserMode?: CreationMode;
    foundationModel?: string;
    additionalModelRequestFields?: any;
}
export declare const PromptConfiguration: S.Schema<PromptConfiguration>;
export type PromptConfigurations = PromptConfiguration[];
export declare const PromptConfigurations: any;
export interface PromptOverrideConfiguration {
    promptConfigurations: PromptConfiguration[];
    overrideLambda?: string;
}
export declare const PromptOverrideConfiguration: S.Schema<PromptOverrideConfiguration>;
export type AgentCollaboration = "SUPERVISOR" | "SUPERVISOR_ROUTER" | "DISABLED" | (string & {});
export declare const AgentCollaboration: any;
export type CollaborationInstruction = string | redacted.Redacted<string>;
export type RelayConversationHistory = "TO_COLLABORATOR" | "DISABLED" | (string & {});
export declare const RelayConversationHistory: any;
export interface CollaboratorConfiguration {
    collaboratorName: string | redacted.Redacted<string>;
    collaboratorInstruction: string | redacted.Redacted<string>;
    agentAliasArn?: string;
    relayConversationHistory?: RelayConversationHistory;
}
export declare const CollaboratorConfiguration: S.Schema<CollaboratorConfiguration>;
export type CollaboratorConfigurations = CollaboratorConfiguration[];
export declare const CollaboratorConfigurations: any;
export interface InlineSessionState {
    sessionAttributes?: {
        [key: string]: string | undefined;
    };
    promptSessionAttributes?: {
        [key: string]: string | undefined;
    };
    returnControlInvocationResults?: InvocationResultMember[];
    invocationId?: string;
    files?: InputFile[];
    conversationHistory?: ConversationHistory;
}
export declare const InlineSessionState: S.Schema<InlineSessionState>;
export interface Collaborator {
    customerEncryptionKeyArn?: string;
    foundationModel: string;
    instruction: string | redacted.Redacted<string>;
    idleSessionTTLInSeconds?: number;
    actionGroups?: AgentActionGroup[];
    knowledgeBases?: KnowledgeBase[];
    guardrailConfiguration?: GuardrailConfigurationWithArn;
    promptOverrideConfiguration?: PromptOverrideConfiguration;
    agentCollaboration?: AgentCollaboration;
    collaboratorConfigurations?: CollaboratorConfiguration[];
    agentName?: string | redacted.Redacted<string>;
}
export declare const Collaborator: S.Schema<Collaborator>;
export type Collaborators = Collaborator[];
export declare const Collaborators: any;
export interface InlineBedrockModelConfigurations {
    performanceConfig?: PerformanceConfiguration;
}
export declare const InlineBedrockModelConfigurations: S.Schema<InlineBedrockModelConfigurations>;
export type OrchestrationType = "DEFAULT" | "CUSTOM_ORCHESTRATION" | (string & {});
export declare const OrchestrationType: any;
export type OrchestrationExecutor = {
    lambda: string;
};
export declare const OrchestrationExecutor: any;
export interface CustomOrchestration {
    executor?: OrchestrationExecutor;
}
export declare const CustomOrchestration: S.Schema<CustomOrchestration>;
export interface InvokeInlineAgentRequest {
    customerEncryptionKeyArn?: string;
    foundationModel: string;
    instruction: string | redacted.Redacted<string>;
    idleSessionTTLInSeconds?: number;
    actionGroups?: AgentActionGroup[];
    knowledgeBases?: KnowledgeBase[];
    guardrailConfiguration?: GuardrailConfigurationWithArn;
    promptOverrideConfiguration?: PromptOverrideConfiguration;
    agentCollaboration?: AgentCollaboration;
    collaboratorConfigurations?: CollaboratorConfiguration[];
    agentName?: string | redacted.Redacted<string>;
    sessionId: string;
    endSession?: boolean;
    enableTrace?: boolean;
    inputText?: string | redacted.Redacted<string>;
    streamingConfigurations?: StreamingConfigurations;
    promptCreationConfigurations?: PromptCreationConfigurations;
    inlineSessionState?: InlineSessionState;
    collaborators?: Collaborator[];
    bedrockModelConfigurations?: InlineBedrockModelConfigurations;
    orchestrationType?: OrchestrationType;
    customOrchestration?: CustomOrchestration;
}
export declare const InvokeInlineAgentRequest: S.Schema<InvokeInlineAgentRequest>;
export interface InlineAgentPayloadPart {
    bytes?: Uint8Array | redacted.Redacted<Uint8Array>;
    attribution?: Attribution;
}
export declare const InlineAgentPayloadPart: S.Schema<InlineAgentPayloadPart>;
export interface InlineAgentTracePart {
    sessionId?: string;
    trace?: Trace;
    callerChain?: Caller[];
    eventTime?: Date;
    collaboratorName?: string | redacted.Redacted<string>;
}
export declare const InlineAgentTracePart: S.Schema<InlineAgentTracePart>;
export interface InlineAgentReturnControlPayload {
    invocationInputs?: InvocationInputMember[];
    invocationId?: string;
}
export declare const InlineAgentReturnControlPayload: S.Schema<InlineAgentReturnControlPayload>;
export interface InlineAgentFilePart {
    files?: OutputFile[];
}
export declare const InlineAgentFilePart: S.Schema<InlineAgentFilePart>;
export type InlineAgentResponseStream = {
    chunk: InlineAgentPayloadPart;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    files?: never;
} | {
    chunk?: never;
    trace: InlineAgentTracePart;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl: InlineAgentReturnControlPayload;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException: InternalServerException;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException: ValidationException;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException: ThrottlingException;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException: AccessDeniedException;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException: ConflictException;
    dependencyFailedException?: never;
    badGatewayException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException: DependencyFailedException;
    badGatewayException?: never;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException: BadGatewayException;
    files?: never;
} | {
    chunk?: never;
    trace?: never;
    returnControl?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
    files: InlineAgentFilePart;
};
export declare const InlineAgentResponseStream: S.Schema<stream.Stream<InlineAgentResponseStream, Error, never>>;
export interface InvokeInlineAgentResponse {
    completion: stream.Stream<InlineAgentResponseStream, Error, never>;
    contentType: string;
    sessionId: string;
}
export declare const InvokeInlineAgentResponse: S.Schema<InvokeInlineAgentResponse>;
export type FlowExecutionEventType = "Node" | "Flow" | (string & {});
export declare const FlowExecutionEventType: any;
export interface ListFlowExecutionEventsRequest {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    executionIdentifier: string;
    maxResults?: number;
    nextToken?: string;
    eventType: FlowExecutionEventType;
}
export declare const ListFlowExecutionEventsRequest: S.Schema<ListFlowExecutionEventsRequest>;
export type FlowExecutionContent = {
    document: any;
};
export declare const FlowExecutionContent: any;
export interface FlowInputField {
    name: string;
    content: FlowExecutionContent;
}
export declare const FlowInputField: S.Schema<FlowInputField>;
export type FlowInputFields = FlowInputField[];
export declare const FlowInputFields: any;
export interface FlowExecutionInputEvent {
    nodeName: string;
    timestamp: Date;
    fields: FlowInputField[];
}
export declare const FlowExecutionInputEvent: S.Schema<FlowExecutionInputEvent>;
export interface FlowOutputField {
    name: string;
    content: FlowExecutionContent;
}
export declare const FlowOutputField: S.Schema<FlowOutputField>;
export type FlowOutputFields = FlowOutputField[];
export declare const FlowOutputFields: any;
export interface FlowExecutionOutputEvent {
    nodeName: string;
    timestamp: Date;
    fields: FlowOutputField[];
}
export declare const FlowExecutionOutputEvent: S.Schema<FlowExecutionOutputEvent>;
export type NodeExecutionContent = {
    document: any;
};
export declare const NodeExecutionContent: any;
export interface NodeInputSource {
    nodeName: string;
    outputFieldName: string;
    expression: string | redacted.Redacted<string>;
}
export declare const NodeInputSource: S.Schema<NodeInputSource>;
export interface NodeInputExecutionChainItem {
    nodeName: string;
    index?: number;
    type: FlowControlNodeType;
}
export declare const NodeInputExecutionChainItem: S.Schema<NodeInputExecutionChainItem>;
export type NodeInputExecutionChain = NodeInputExecutionChainItem[];
export declare const NodeInputExecutionChain: any;
export interface NodeInputField {
    name: string;
    content: NodeExecutionContent;
    source?: NodeInputSource;
    type?: FlowNodeIODataType;
    category?: FlowNodeInputCategory;
    executionChain?: NodeInputExecutionChainItem[];
}
export declare const NodeInputField: S.Schema<NodeInputField>;
export type NodeInputFields = NodeInputField[];
export declare const NodeInputFields: any;
export interface NodeInputEvent {
    nodeName: string;
    timestamp: Date;
    fields: NodeInputField[];
}
export declare const NodeInputEvent: S.Schema<NodeInputEvent>;
export interface NodeOutputNext {
    nodeName: string;
    inputFieldName: string;
}
export declare const NodeOutputNext: S.Schema<NodeOutputNext>;
export type NodeOutputNextList = NodeOutputNext[];
export declare const NodeOutputNextList: any;
export interface NodeOutputField {
    name: string;
    content: NodeExecutionContent;
    next?: NodeOutputNext[];
    type?: FlowNodeIODataType;
}
export declare const NodeOutputField: S.Schema<NodeOutputField>;
export type NodeOutputFields = NodeOutputField[];
export declare const NodeOutputFields: any;
export interface NodeOutputEvent {
    nodeName: string;
    timestamp: Date;
    fields: NodeOutputField[];
}
export declare const NodeOutputEvent: S.Schema<NodeOutputEvent>;
export interface SatisfiedCondition {
    conditionName: string;
}
export declare const SatisfiedCondition: S.Schema<SatisfiedCondition>;
export type SatisfiedConditions = SatisfiedCondition[];
export declare const SatisfiedConditions: any;
export interface ConditionResultEvent {
    nodeName: string;
    timestamp: Date;
    satisfiedConditions: SatisfiedCondition[];
}
export declare const ConditionResultEvent: S.Schema<ConditionResultEvent>;
export type NodeErrorCode = "VALIDATION" | "DEPENDENCY_FAILED" | "BAD_GATEWAY" | "INTERNAL_SERVER" | (string & {});
export declare const NodeErrorCode: any;
export interface NodeFailureEvent {
    nodeName: string;
    timestamp: Date;
    errorCode: NodeErrorCode;
    errorMessage: string;
}
export declare const NodeFailureEvent: S.Schema<NodeFailureEvent>;
export type FlowErrorCode = "VALIDATION" | "INTERNAL_SERVER" | "NODE_EXECUTION_FAILED" | (string & {});
export declare const FlowErrorCode: any;
export interface FlowFailureEvent {
    timestamp: Date;
    errorCode: FlowErrorCode;
    errorMessage: string;
}
export declare const FlowFailureEvent: S.Schema<FlowFailureEvent>;
export interface NodeActionEvent {
    nodeName: string;
    timestamp: Date;
    requestId: string;
    serviceName: string;
    operationName: string;
    operationRequest?: any;
    operationResponse?: any;
}
export declare const NodeActionEvent: S.Schema<NodeActionEvent>;
export type NodeTraceElements = {
    agentTraces: TracePart[];
};
export declare const NodeTraceElements: any;
export interface NodeDependencyEvent {
    nodeName: string;
    timestamp: Date;
    traceElements: NodeTraceElements;
}
export declare const NodeDependencyEvent: S.Schema<NodeDependencyEvent>;
export type FlowExecutionEvent = {
    flowInputEvent: FlowExecutionInputEvent;
    flowOutputEvent?: never;
    nodeInputEvent?: never;
    nodeOutputEvent?: never;
    conditionResultEvent?: never;
    nodeFailureEvent?: never;
    flowFailureEvent?: never;
    nodeActionEvent?: never;
    nodeDependencyEvent?: never;
} | {
    flowInputEvent?: never;
    flowOutputEvent: FlowExecutionOutputEvent;
    nodeInputEvent?: never;
    nodeOutputEvent?: never;
    conditionResultEvent?: never;
    nodeFailureEvent?: never;
    flowFailureEvent?: never;
    nodeActionEvent?: never;
    nodeDependencyEvent?: never;
} | {
    flowInputEvent?: never;
    flowOutputEvent?: never;
    nodeInputEvent: NodeInputEvent;
    nodeOutputEvent?: never;
    conditionResultEvent?: never;
    nodeFailureEvent?: never;
    flowFailureEvent?: never;
    nodeActionEvent?: never;
    nodeDependencyEvent?: never;
} | {
    flowInputEvent?: never;
    flowOutputEvent?: never;
    nodeInputEvent?: never;
    nodeOutputEvent: NodeOutputEvent;
    conditionResultEvent?: never;
    nodeFailureEvent?: never;
    flowFailureEvent?: never;
    nodeActionEvent?: never;
    nodeDependencyEvent?: never;
} | {
    flowInputEvent?: never;
    flowOutputEvent?: never;
    nodeInputEvent?: never;
    nodeOutputEvent?: never;
    conditionResultEvent: ConditionResultEvent;
    nodeFailureEvent?: never;
    flowFailureEvent?: never;
    nodeActionEvent?: never;
    nodeDependencyEvent?: never;
} | {
    flowInputEvent?: never;
    flowOutputEvent?: never;
    nodeInputEvent?: never;
    nodeOutputEvent?: never;
    conditionResultEvent?: never;
    nodeFailureEvent: NodeFailureEvent;
    flowFailureEvent?: never;
    nodeActionEvent?: never;
    nodeDependencyEvent?: never;
} | {
    flowInputEvent?: never;
    flowOutputEvent?: never;
    nodeInputEvent?: never;
    nodeOutputEvent?: never;
    conditionResultEvent?: never;
    nodeFailureEvent?: never;
    flowFailureEvent: FlowFailureEvent;
    nodeActionEvent?: never;
    nodeDependencyEvent?: never;
} | {
    flowInputEvent?: never;
    flowOutputEvent?: never;
    nodeInputEvent?: never;
    nodeOutputEvent?: never;
    conditionResultEvent?: never;
    nodeFailureEvent?: never;
    flowFailureEvent?: never;
    nodeActionEvent: NodeActionEvent;
    nodeDependencyEvent?: never;
} | {
    flowInputEvent?: never;
    flowOutputEvent?: never;
    nodeInputEvent?: never;
    nodeOutputEvent?: never;
    conditionResultEvent?: never;
    nodeFailureEvent?: never;
    flowFailureEvent?: never;
    nodeActionEvent?: never;
    nodeDependencyEvent: NodeDependencyEvent;
};
export declare const FlowExecutionEvent: any;
export type FlowExecutionEvents = FlowExecutionEvent[];
export declare const FlowExecutionEvents: any;
export interface ListFlowExecutionEventsResponse {
    flowExecutionEvents: FlowExecutionEvent[];
    nextToken?: string;
}
export declare const ListFlowExecutionEventsResponse: S.Schema<ListFlowExecutionEventsResponse>;
export interface ListFlowExecutionsRequest {
    flowIdentifier: string;
    flowAliasIdentifier?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListFlowExecutionsRequest: S.Schema<ListFlowExecutionsRequest>;
export interface FlowExecutionSummary {
    executionArn: string;
    flowAliasIdentifier: string;
    flowIdentifier: string;
    flowVersion: string;
    status: FlowExecutionStatus;
    createdAt: Date;
    endedAt?: Date;
}
export declare const FlowExecutionSummary: S.Schema<FlowExecutionSummary>;
export type FlowExecutionSummaries = FlowExecutionSummary[];
export declare const FlowExecutionSummaries: any;
export interface ListFlowExecutionsResponse {
    flowExecutionSummaries: FlowExecutionSummary[];
    nextToken?: string;
}
export declare const ListFlowExecutionsResponse: S.Schema<ListFlowExecutionsResponse>;
export interface ListInvocationsRequest {
    nextToken?: string;
    maxResults?: number;
    sessionIdentifier: string;
}
export declare const ListInvocationsRequest: S.Schema<ListInvocationsRequest>;
export interface InvocationSummary {
    sessionId: string;
    invocationId: string;
    createdAt: Date;
}
export declare const InvocationSummary: S.Schema<InvocationSummary>;
export type InvocationSummaries = InvocationSummary[];
export declare const InvocationSummaries: any;
export interface ListInvocationsResponse {
    invocationSummaries: InvocationSummary[];
    nextToken?: string;
}
export declare const ListInvocationsResponse: S.Schema<ListInvocationsResponse>;
export interface ListInvocationStepsRequest {
    invocationIdentifier?: string;
    nextToken?: string;
    maxResults?: number;
    sessionIdentifier: string;
}
export declare const ListInvocationStepsRequest: S.Schema<ListInvocationStepsRequest>;
export interface InvocationStepSummary {
    sessionId: string;
    invocationId: string;
    invocationStepId: string;
    invocationStepTime: Date;
}
export declare const InvocationStepSummary: S.Schema<InvocationStepSummary>;
export type InvocationStepSummaries = InvocationStepSummary[];
export declare const InvocationStepSummaries: any;
export interface ListInvocationStepsResponse {
    invocationStepSummaries: InvocationStepSummary[];
    nextToken?: string;
}
export declare const ListInvocationStepsResponse: S.Schema<ListInvocationStepsResponse>;
export interface ListSessionsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSessionsRequest: S.Schema<ListSessionsRequest>;
export interface SessionSummary {
    sessionId: string;
    sessionArn: string;
    sessionStatus: SessionStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export declare const SessionSummary: S.Schema<SessionSummary>;
export type SessionSummaries = SessionSummary[];
export declare const SessionSummaries: any;
export interface ListSessionsResponse {
    sessionSummaries: SessionSummary[];
    nextToken?: string;
}
export declare const ListSessionsResponse: S.Schema<ListSessionsResponse>;
export type TaggableResourcesArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TextPrompt {
    text: string;
}
export declare const TextPrompt: S.Schema<TextPrompt>;
export type InputPrompt = {
    textPrompt: TextPrompt;
};
export declare const InputPrompt: any;
export interface OptimizePromptRequest {
    input: InputPrompt;
    targetModelId: string;
}
export declare const OptimizePromptRequest: S.Schema<OptimizePromptRequest>;
export type OptimizedPrompt = {
    textPrompt: TextPrompt;
};
export declare const OptimizedPrompt: any;
export interface OptimizedPromptEvent {
    optimizedPrompt?: OptimizedPrompt;
}
export declare const OptimizedPromptEvent: S.Schema<OptimizedPromptEvent>;
export interface AnalyzePromptEvent {
    message?: string;
}
export declare const AnalyzePromptEvent: S.Schema<AnalyzePromptEvent>;
export type OptimizedPromptStream = {
    optimizedPromptEvent: OptimizedPromptEvent;
    analyzePromptEvent?: never;
    internalServerException?: never;
    throttlingException?: never;
    validationException?: never;
    dependencyFailedException?: never;
    accessDeniedException?: never;
    badGatewayException?: never;
} | {
    optimizedPromptEvent?: never;
    analyzePromptEvent: AnalyzePromptEvent;
    internalServerException?: never;
    throttlingException?: never;
    validationException?: never;
    dependencyFailedException?: never;
    accessDeniedException?: never;
    badGatewayException?: never;
} | {
    optimizedPromptEvent?: never;
    analyzePromptEvent?: never;
    internalServerException: InternalServerException;
    throttlingException?: never;
    validationException?: never;
    dependencyFailedException?: never;
    accessDeniedException?: never;
    badGatewayException?: never;
} | {
    optimizedPromptEvent?: never;
    analyzePromptEvent?: never;
    internalServerException?: never;
    throttlingException: ThrottlingException;
    validationException?: never;
    dependencyFailedException?: never;
    accessDeniedException?: never;
    badGatewayException?: never;
} | {
    optimizedPromptEvent?: never;
    analyzePromptEvent?: never;
    internalServerException?: never;
    throttlingException?: never;
    validationException: ValidationException;
    dependencyFailedException?: never;
    accessDeniedException?: never;
    badGatewayException?: never;
} | {
    optimizedPromptEvent?: never;
    analyzePromptEvent?: never;
    internalServerException?: never;
    throttlingException?: never;
    validationException?: never;
    dependencyFailedException: DependencyFailedException;
    accessDeniedException?: never;
    badGatewayException?: never;
} | {
    optimizedPromptEvent?: never;
    analyzePromptEvent?: never;
    internalServerException?: never;
    throttlingException?: never;
    validationException?: never;
    dependencyFailedException?: never;
    accessDeniedException: AccessDeniedException;
    badGatewayException?: never;
} | {
    optimizedPromptEvent?: never;
    analyzePromptEvent?: never;
    internalServerException?: never;
    throttlingException?: never;
    validationException?: never;
    dependencyFailedException?: never;
    accessDeniedException?: never;
    badGatewayException: BadGatewayException;
};
export declare const OptimizedPromptStream: S.Schema<stream.Stream<OptimizedPromptStream, Error, never>>;
export interface OptimizePromptResponse {
    optimizedPrompt: stream.Stream<OptimizedPromptStream, Error, never>;
}
export declare const OptimizePromptResponse: S.Schema<OptimizePromptResponse>;
export interface PutInvocationStepRequest {
    sessionIdentifier: string;
    invocationIdentifier: string;
    invocationStepTime: Date;
    payload: InvocationStepPayload;
    invocationStepId?: string;
}
export declare const PutInvocationStepRequest: S.Schema<PutInvocationStepRequest>;
export interface PutInvocationStepResponse {
    invocationStepId: string;
}
export declare const PutInvocationStepResponse: S.Schema<PutInvocationStepResponse>;
export type RerankQueryContentType = "TEXT" | (string & {});
export declare const RerankQueryContentType: any;
export interface RerankTextDocument {
    text?: string;
}
export declare const RerankTextDocument: S.Schema<RerankTextDocument>;
export interface RerankQuery {
    type: RerankQueryContentType;
    textQuery: RerankTextDocument;
}
export declare const RerankQuery: S.Schema<RerankQuery>;
export type RerankQueriesList = RerankQuery[];
export declare const RerankQueriesList: any;
export type RerankSourceType = "INLINE" | (string & {});
export declare const RerankSourceType: any;
export type RerankDocumentType = "TEXT" | "JSON" | (string & {});
export declare const RerankDocumentType: any;
export interface RerankDocument {
    type: RerankDocumentType;
    textDocument?: RerankTextDocument;
    jsonDocument?: any;
}
export declare const RerankDocument: S.Schema<RerankDocument>;
export interface RerankSource {
    type: RerankSourceType;
    inlineDocumentSource: RerankDocument;
}
export declare const RerankSource: S.Schema<RerankSource>;
export type RerankSourcesList = RerankSource[];
export declare const RerankSourcesList: any;
export type RerankingConfigurationType = "BEDROCK_RERANKING_MODEL" | (string & {});
export declare const RerankingConfigurationType: any;
export interface BedrockRerankingModelConfiguration {
    modelArn: string;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    };
}
export declare const BedrockRerankingModelConfiguration: S.Schema<BedrockRerankingModelConfiguration>;
export interface BedrockRerankingConfiguration {
    numberOfResults?: number;
    modelConfiguration: BedrockRerankingModelConfiguration;
}
export declare const BedrockRerankingConfiguration: S.Schema<BedrockRerankingConfiguration>;
export interface RerankingConfiguration {
    type: RerankingConfigurationType;
    bedrockRerankingConfiguration: BedrockRerankingConfiguration;
}
export declare const RerankingConfiguration: S.Schema<RerankingConfiguration>;
export interface RerankRequest {
    queries: RerankQuery[];
    sources: RerankSource[];
    rerankingConfiguration: RerankingConfiguration;
    nextToken?: string;
}
export declare const RerankRequest: S.Schema<RerankRequest>;
export interface RerankResult {
    index: number;
    relevanceScore: number;
    document?: RerankDocument;
}
export declare const RerankResult: S.Schema<RerankResult>;
export type RerankResultsList = RerankResult[];
export declare const RerankResultsList: any;
export interface RerankResponse {
    results: RerankResult[];
    nextToken?: string;
}
export declare const RerankResponse: S.Schema<RerankResponse>;
export type KnowledgeBaseQueryType = "TEXT" | "IMAGE" | (string & {});
export declare const KnowledgeBaseQueryType: any;
export type InputImageFormat = "png" | "jpeg" | "gif" | "webp" | (string & {});
export declare const InputImageFormat: any;
export interface InputImage {
    format: InputImageFormat;
    inlineContent: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const InputImage: S.Schema<InputImage>;
export interface KnowledgeBaseQuery {
    type?: KnowledgeBaseQueryType;
    text?: string;
    image?: InputImage;
}
export declare const KnowledgeBaseQuery: S.Schema<KnowledgeBaseQuery>;
export interface GuardrailConfiguration {
    guardrailId: string;
    guardrailVersion: string;
}
export declare const GuardrailConfiguration: S.Schema<GuardrailConfiguration>;
export interface RetrieveRequest {
    knowledgeBaseId: string;
    retrievalQuery: KnowledgeBaseQuery;
    retrievalConfiguration?: KnowledgeBaseRetrievalConfiguration;
    guardrailConfiguration?: GuardrailConfiguration;
    nextToken?: string;
    userContext?: UserContext;
}
export declare const RetrieveRequest: S.Schema<RetrieveRequest>;
export interface KnowledgeBaseRetrievalResult {
    content: RetrievalResultContent;
    location?: RetrievalResultLocation;
    score?: number;
    metadata?: {
        [key: string]: any | undefined;
    };
    documentId?: string;
}
export declare const KnowledgeBaseRetrievalResult: S.Schema<KnowledgeBaseRetrievalResult>;
export type KnowledgeBaseRetrievalResults = KnowledgeBaseRetrievalResult[];
export declare const KnowledgeBaseRetrievalResults: any;
export type GuadrailAction = "INTERVENED" | "NONE" | (string & {});
export declare const GuadrailAction: any;
export interface RetrieveResponse {
    retrievalResults: KnowledgeBaseRetrievalResult[];
    guardrailAction?: GuadrailAction;
    nextToken?: string;
}
export declare const RetrieveResponse: S.Schema<RetrieveResponse>;
export interface RetrieveAndGenerateInput {
    text: string;
}
export declare const RetrieveAndGenerateInput: S.Schema<RetrieveAndGenerateInput>;
export type RetrieveAndGenerateType = "KNOWLEDGE_BASE" | "EXTERNAL_SOURCES" | (string & {});
export declare const RetrieveAndGenerateType: any;
export type TextPromptTemplate = string | redacted.Redacted<string>;
export interface PromptTemplate {
    textPromptTemplate?: string | redacted.Redacted<string>;
}
export declare const PromptTemplate: S.Schema<PromptTemplate>;
export type MaxTokens = number;
export type RAGStopSequences = string[];
export declare const RAGStopSequences: any;
export interface TextInferenceConfig {
    temperature?: number;
    topP?: number;
    maxTokens?: number;
    stopSequences?: string[];
}
export declare const TextInferenceConfig: S.Schema<TextInferenceConfig>;
export interface InferenceConfig {
    textInferenceConfig?: TextInferenceConfig;
}
export declare const InferenceConfig: S.Schema<InferenceConfig>;
export interface GenerationConfiguration {
    promptTemplate?: PromptTemplate;
    guardrailConfiguration?: GuardrailConfiguration;
    inferenceConfig?: InferenceConfig;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    };
    performanceConfig?: PerformanceConfiguration;
}
export declare const GenerationConfiguration: S.Schema<GenerationConfiguration>;
export type QueryTransformationType = "QUERY_DECOMPOSITION" | (string & {});
export declare const QueryTransformationType: any;
export interface QueryTransformationConfiguration {
    type: QueryTransformationType;
}
export declare const QueryTransformationConfiguration: S.Schema<QueryTransformationConfiguration>;
export interface OrchestrationConfiguration {
    promptTemplate?: PromptTemplate;
    inferenceConfig?: InferenceConfig;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    };
    queryTransformationConfiguration?: QueryTransformationConfiguration;
    performanceConfig?: PerformanceConfiguration;
}
export declare const OrchestrationConfiguration: S.Schema<OrchestrationConfiguration>;
export interface KnowledgeBaseRetrieveAndGenerateConfiguration {
    knowledgeBaseId: string;
    modelArn: string;
    retrievalConfiguration?: KnowledgeBaseRetrievalConfiguration;
    generationConfiguration?: GenerationConfiguration;
    orchestrationConfiguration?: OrchestrationConfiguration;
}
export declare const KnowledgeBaseRetrieveAndGenerateConfiguration: S.Schema<KnowledgeBaseRetrieveAndGenerateConfiguration>;
export type ExternalSourceType = "S3" | "BYTE_CONTENT" | (string & {});
export declare const ExternalSourceType: any;
export interface S3ObjectDoc {
    uri: string;
}
export declare const S3ObjectDoc: S.Schema<S3ObjectDoc>;
export type Identifier = string | redacted.Redacted<string>;
export type ContentType = string;
export interface ByteContentDoc {
    identifier: string | redacted.Redacted<string>;
    contentType: string;
    data: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const ByteContentDoc: S.Schema<ByteContentDoc>;
export interface ExternalSource {
    sourceType: ExternalSourceType;
    s3Location?: S3ObjectDoc;
    byteContent?: ByteContentDoc;
}
export declare const ExternalSource: S.Schema<ExternalSource>;
export type ExternalSources = ExternalSource[];
export declare const ExternalSources: any;
export interface ExternalSourcesGenerationConfiguration {
    promptTemplate?: PromptTemplate;
    guardrailConfiguration?: GuardrailConfiguration;
    inferenceConfig?: InferenceConfig;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    };
    performanceConfig?: PerformanceConfiguration;
}
export declare const ExternalSourcesGenerationConfiguration: S.Schema<ExternalSourcesGenerationConfiguration>;
export interface ExternalSourcesRetrieveAndGenerateConfiguration {
    modelArn: string;
    sources: ExternalSource[];
    generationConfiguration?: ExternalSourcesGenerationConfiguration;
}
export declare const ExternalSourcesRetrieveAndGenerateConfiguration: S.Schema<ExternalSourcesRetrieveAndGenerateConfiguration>;
export interface RetrieveAndGenerateConfiguration {
    type: RetrieveAndGenerateType;
    knowledgeBaseConfiguration?: KnowledgeBaseRetrieveAndGenerateConfiguration;
    externalSourcesConfiguration?: ExternalSourcesRetrieveAndGenerateConfiguration;
}
export declare const RetrieveAndGenerateConfiguration: S.Schema<RetrieveAndGenerateConfiguration>;
export interface RetrieveAndGenerateSessionConfiguration {
    kmsKeyArn: string;
}
export declare const RetrieveAndGenerateSessionConfiguration: S.Schema<RetrieveAndGenerateSessionConfiguration>;
export interface RetrieveAndGenerateRequest {
    sessionId?: string;
    input: RetrieveAndGenerateInput;
    retrieveAndGenerateConfiguration?: RetrieveAndGenerateConfiguration;
    sessionConfiguration?: RetrieveAndGenerateSessionConfiguration;
    userContext?: UserContext;
}
export declare const RetrieveAndGenerateRequest: S.Schema<RetrieveAndGenerateRequest>;
export interface RetrieveAndGenerateOutput {
    text: string;
}
export declare const RetrieveAndGenerateOutput: S.Schema<RetrieveAndGenerateOutput>;
export interface RetrieveAndGenerateResponse {
    sessionId: string;
    output: RetrieveAndGenerateOutput;
    citations?: Citation[];
    guardrailAction?: GuadrailAction;
}
export declare const RetrieveAndGenerateResponse: S.Schema<RetrieveAndGenerateResponse>;
export interface RetrieveAndGenerateStreamRequest {
    sessionId?: string;
    input: RetrieveAndGenerateInput;
    retrieveAndGenerateConfiguration?: RetrieveAndGenerateConfiguration;
    sessionConfiguration?: RetrieveAndGenerateSessionConfiguration;
    userContext?: UserContext;
}
export declare const RetrieveAndGenerateStreamRequest: S.Schema<RetrieveAndGenerateStreamRequest>;
export interface RetrieveAndGenerateOutputEvent {
    text: string;
}
export declare const RetrieveAndGenerateOutputEvent: S.Schema<RetrieveAndGenerateOutputEvent>;
export interface CitationEvent {
    citation?: Citation;
    generatedResponsePart?: GeneratedResponsePart;
    retrievedReferences?: RetrievedReference[];
}
export declare const CitationEvent: S.Schema<CitationEvent>;
export interface GuardrailEvent {
    action?: GuadrailAction;
}
export declare const GuardrailEvent: S.Schema<GuardrailEvent>;
export type RetrieveAndGenerateStreamResponseOutput = {
    output: RetrieveAndGenerateOutputEvent;
    citation?: never;
    guardrail?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    output?: never;
    citation: CitationEvent;
    guardrail?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    output?: never;
    citation?: never;
    guardrail: GuardrailEvent;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    output?: never;
    citation?: never;
    guardrail?: never;
    internalServerException: InternalServerException;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    output?: never;
    citation?: never;
    guardrail?: never;
    internalServerException?: never;
    validationException: ValidationException;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    output?: never;
    citation?: never;
    guardrail?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    output?: never;
    citation?: never;
    guardrail?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    output?: never;
    citation?: never;
    guardrail?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException: ThrottlingException;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    output?: never;
    citation?: never;
    guardrail?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException: AccessDeniedException;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    output?: never;
    citation?: never;
    guardrail?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException: ConflictException;
    dependencyFailedException?: never;
    badGatewayException?: never;
} | {
    output?: never;
    citation?: never;
    guardrail?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException: DependencyFailedException;
    badGatewayException?: never;
} | {
    output?: never;
    citation?: never;
    guardrail?: never;
    internalServerException?: never;
    validationException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    accessDeniedException?: never;
    conflictException?: never;
    dependencyFailedException?: never;
    badGatewayException: BadGatewayException;
};
export declare const RetrieveAndGenerateStreamResponseOutput: S.Schema<stream.Stream<RetrieveAndGenerateStreamResponseOutput, Error, never>>;
export interface RetrieveAndGenerateStreamResponse {
    stream: stream.Stream<RetrieveAndGenerateStreamResponseOutput, Error, never>;
    sessionId: string;
}
export declare const RetrieveAndGenerateStreamResponse: S.Schema<RetrieveAndGenerateStreamResponse>;
export type FlowExecutionName = string;
export interface StartFlowExecutionRequest {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    flowExecutionName?: string;
    inputs: FlowInput[];
    modelPerformanceConfiguration?: ModelPerformanceConfiguration;
}
export declare const StartFlowExecutionRequest: S.Schema<StartFlowExecutionRequest>;
export interface StartFlowExecutionResponse {
    executionArn?: string;
}
export declare const StartFlowExecutionResponse: S.Schema<StartFlowExecutionResponse>;
export interface StopFlowExecutionRequest {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    executionIdentifier: string;
}
export declare const StopFlowExecutionRequest: S.Schema<StopFlowExecutionRequest>;
export interface StopFlowExecutionResponse {
    executionArn?: string;
    status: FlowExecutionStatus;
}
export declare const StopFlowExecutionResponse: S.Schema<StopFlowExecutionResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateSessionRequest {
    sessionMetadata?: {
        [key: string]: string | undefined;
    };
    sessionIdentifier: string;
}
export declare const UpdateSessionRequest: S.Schema<UpdateSessionRequest>;
export interface UpdateSessionResponse {
    sessionId: string;
    sessionArn: string;
    sessionStatus: SessionStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export declare const UpdateSessionResponse: S.Schema<UpdateSessionResponse>;
export type AgenticRetrieveStreamError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information from one or more knowledge bases using an agentic approach. Agentic retrieval uses a foundation model to intelligently decompose complex queries into sub-queries and iteratively retrieve relevant information from your knowledge bases. This approach improves retrieval accuracy for complex, multi-step questions that a single retrieval pass might not fully address.
 *
 * The operation returns results through a stream that includes retrieval results, trace events for visibility into the process, and a generated response synthesized from the results by default, which can be turned off.
 */
export declare const agenticRetrieveStream: API.OperationMethod<AgenticRetrieveStreamRequest, AgenticRetrieveStreamResponse, AgenticRetrieveStreamError, Credentials | HttpClient.HttpClient>;
export type CheckIngestedDocumentAclError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Checks whether a user has access to a specific document by verifying against the ingested access control list (ACL) in a knowledge base. Use this operation to validate that document-level access control is working as expected after ingestion. To use this operation, you must have the `bedrock:CheckIngestedDocumentAcl` permission.
 */
export declare const checkIngestedDocumentAcl: API.OperationMethod<CheckIngestedDocumentAclRequest, CheckIngestedDocumentAclResponse, CheckIngestedDocumentAclError, Credentials | HttpClient.HttpClient>;
export type CreateInvocationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new invocation within a session. An invocation groups the related invocation steps that store the content from a conversation. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 *
 * Related APIs
 *
 * - ListInvocations
 *
 * - ListSessions
 *
 * - GetSession
 */
export declare const createInvocation: API.OperationMethod<CreateInvocationRequest, CreateInvocationResponse, CreateInvocationError, Credentials | HttpClient.HttpClient>;
export type CreateSessionError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a session to temporarily store conversations for generative AI (GenAI) applications built with open-source frameworks such as LangGraph and LlamaIndex. Sessions enable you to save the state of conversations at checkpoints, with the added security and infrastructure of Amazon Web Services. For more information, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 *
 * By default, Amazon Bedrock uses Amazon Web Services-managed keys for session encryption, including session metadata, or you can use your own KMS key. For more information, see Amazon Bedrock session encryption.
 *
 * You use a session to store state and conversation history for generative AI applications built with open-source frameworks. For Amazon Bedrock Agents, the service automatically manages conversation context and associates them with the agent-specific sessionId you specify in the InvokeAgent API operation.
 *
 * Related APIs:
 *
 * - ListSessions
 *
 * - GetSession
 *
 * - EndSession
 *
 * - DeleteSession
 */
export declare const createSession: API.OperationMethod<CreateSessionRequest, CreateSessionResponse, CreateSessionError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentMemoryError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes memory from the specified memory identifier.
 */
export declare const deleteAgentMemory: API.OperationMethod<DeleteAgentMemoryRequest, DeleteAgentMemoryResponse, DeleteAgentMemoryError, Credentials | HttpClient.HttpClient>;
export type DeleteSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a session that you ended. You can't delete a session with an `ACTIVE` status. To delete an active session, you must first end it with the EndSession API operation. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const deleteSession: API.OperationMethod<DeleteSessionRequest, DeleteSessionResponse, DeleteSessionError, Credentials | HttpClient.HttpClient>;
export type EndSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Ends the session. After you end a session, you can still access its content but you can’t add to it. To delete the session and it's content, you use the DeleteSession API operation. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const endSession: API.OperationMethod<EndSessionRequest, EndSessionResponse, EndSessionError, Credentials | HttpClient.HttpClient>;
export type GenerateQueryError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates an SQL query from a natural language query. For more information, see Generate a query for structured data in the Amazon Bedrock User Guide.
 */
export declare const generateQuery: API.OperationMethod<GenerateQueryRequest, GenerateQueryResponse, GenerateQueryError, Credentials | HttpClient.HttpClient>;
export type GetAgentMemoryError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the sessions stored in the memory of the agent.
 */
export declare const getAgentMemory: API.PaginatedOperationMethod<GetAgentMemoryRequest, GetAgentMemoryResponse, GetAgentMemoryError, Credentials | HttpClient.HttpClient, Memory>;
export type GetDocumentContentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the content of an ingested document from a knowledge base. Returns a pre-signed URL for secure document access.
 */
export declare const getDocumentContent: API.OperationMethod<GetDocumentContentRequest, GetDocumentContentResponse, GetDocumentContentError, Credentials | HttpClient.HttpClient>;
export type GetExecutionFlowSnapshotError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the flow definition snapshot used for a flow execution. The snapshot represents the flow metadata and definition as it existed at the time the execution was started. Note that even if the flow is edited after an execution starts, the snapshot connected to the execution remains unchanged.
 *
 * Flow executions is in preview release for Amazon Bedrock and is subject to change.
 */
export declare const getExecutionFlowSnapshot: API.OperationMethod<GetExecutionFlowSnapshotRequest, GetExecutionFlowSnapshotResponse, GetExecutionFlowSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetFlowExecutionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a specific flow execution, including its status, start and end times, and any errors that occurred during execution.
 */
export declare const getFlowExecution: API.OperationMethod<GetFlowExecutionRequest, GetFlowExecutionResponse, GetFlowExecutionError, Credentials | HttpClient.HttpClient>;
export type GetIngestedDocumentAclError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the ingested access control list (ACL) for a specific document in a knowledge base. Use this operation to inspect the allow and deny lists that were ingested for a document to troubleshoot access control issues. To use this operation, you must have the `bedrock:GetIngestedDocumentAcl` permission.
 */
export declare const getIngestedDocumentAcl: API.OperationMethod<GetIngestedDocumentAclRequest, GetIngestedDocumentAclResponse, GetIngestedDocumentAclError, Credentials | HttpClient.HttpClient>;
export type GetInvocationStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a specific invocation step within an invocation in a session. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const getInvocationStep: API.OperationMethod<GetInvocationStepRequest, GetInvocationStepResponse, GetInvocationStepError, Credentials | HttpClient.HttpClient>;
export type GetSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a specific session. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const getSession: API.OperationMethod<GetSessionRequest, GetSessionResponse, GetSessionError, Credentials | HttpClient.HttpClient>;
export type InvokeAgentError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ModelNotReadyException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Bedrock Agents (now Amazon Bedrock Agents Classic) is no longer open to new customers. For capabilities similar to Bedrock Agents Classic, explore Amazon Bedrock AgentCore. Existing customers can continue to use the service as normal. For more information, see Amazon Bedrock Agents Classic availability change.
 *
 * Sends a prompt for the agent to process and respond to. Note the following fields for the request:
 *
 * - To continue the same conversation with an agent, use the same `sessionId` value in the request.
 *
 * - To activate trace enablement, turn `enableTrace` to `true`. Trace enablement helps you follow the agent's reasoning process that led it to the information it processed, the actions it took, and the final result it yielded. For more information, see Trace enablement.
 *
 * - End a conversation by setting `endSession` to `true`.
 *
 * - In the `sessionState` object, you can include attributes for the session or prompt or, if you configured an action group to return control, results from invocation of the action group.
 *
 * The response contains both **chunk** and **trace** attributes.
 *
 * The final response is returned in the `bytes` field of the `chunk` object. The `InvokeAgent` returns one chunk for the entire interaction.
 *
 * - The `attribution` object contains citations for parts of the response.
 *
 * - If you set `enableTrace` to `true` in the request, you can trace the agent's steps and reasoning process that led it to the response.
 *
 * - If the action predicted was configured to return control, the response returns parameters for the action, elicited from the user, in the `returnControl` field.
 *
 * - Errors are also surfaced in the response.
 */
export declare const invokeAgent: API.OperationMethod<InvokeAgentRequest, InvokeAgentResponse, InvokeAgentError, Credentials | HttpClient.HttpClient>;
export type InvokeFlowError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invokes an alias of a flow to run the inputs that you specify and return the output of each node as a stream. If there's an error, the error is returned. For more information, see Test a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 *
 * The CLI doesn't support streaming operations in Amazon Bedrock, including `InvokeFlow`.
 */
export declare const invokeFlow: API.OperationMethod<InvokeFlowRequest, InvokeFlowResponse, InvokeFlowError, Credentials | HttpClient.HttpClient>;
export type InvokeInlineAgentError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invokes an inline Amazon Bedrock agent using the configurations you provide with the request.
 *
 * - Specify the following fields for security purposes.
 *
 * - (Optional) `customerEncryptionKeyArn` – The Amazon Resource Name (ARN) of a KMS key to encrypt the creation of the agent.
 *
 * - (Optional) `idleSessionTTLinSeconds` – Specify the number of seconds for which the agent should maintain session information. After this time expires, the subsequent `InvokeInlineAgent` request begins a new session.
 *
 * - To override the default prompt behavior for agent orchestration and to use advanced prompts, include a `promptOverrideConfiguration` object. For more information, see Advanced prompts.
 *
 * - The agent instructions will not be honored if your agent has only one knowledge base, uses default prompts, has no action group, and user input is disabled.
 */
export declare const invokeInlineAgent: API.OperationMethod<InvokeInlineAgentRequest, InvokeInlineAgentResponse, InvokeInlineAgentError, Credentials | HttpClient.HttpClient>;
export type ListFlowExecutionEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists events that occurred during a flow execution. Events provide detailed information about the execution progress, including node inputs and outputs, flow inputs and outputs, condition results, and failure events.
 *
 * Flow executions is in preview release for Amazon Bedrock and is subject to change.
 */
export declare const listFlowExecutionEvents: API.PaginatedOperationMethod<ListFlowExecutionEventsRequest, ListFlowExecutionEventsResponse, ListFlowExecutionEventsError, Credentials | HttpClient.HttpClient, FlowExecutionEvent>;
export type ListFlowExecutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all executions of a flow. Results can be paginated and include summary information about each execution, such as status, start and end times, and the execution's Amazon Resource Name (ARN).
 *
 * Flow executions is in preview release for Amazon Bedrock and is subject to change.
 */
export declare const listFlowExecutions: API.PaginatedOperationMethod<ListFlowExecutionsRequest, ListFlowExecutionsResponse, ListFlowExecutionsError, Credentials | HttpClient.HttpClient, FlowExecutionSummary>;
export type ListInvocationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all invocations associated with a specific session. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const listInvocations: API.PaginatedOperationMethod<ListInvocationsRequest, ListInvocationsResponse, ListInvocationsError, Credentials | HttpClient.HttpClient, InvocationSummary>;
export type ListInvocationStepsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all invocation steps associated with a session and optionally, an invocation within the session. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const listInvocationSteps: API.PaginatedOperationMethod<ListInvocationStepsRequest, ListInvocationStepsResponse, ListInvocationStepsError, Credentials | HttpClient.HttpClient, InvocationStepSummary>;
export type ListSessionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all sessions in your Amazon Web Services account. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsRequest, ListSessionsResponse, ListSessionsError, Credentials | HttpClient.HttpClient, SessionSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all the tags for the resource you specify.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type OptimizePromptError = AccessDeniedException | BadGatewayException | DependencyFailedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Optimizes a prompt for the task that you specify. For more information, see Optimize a prompt in the Amazon Bedrock User Guide.
 */
export declare const optimizePrompt: API.OperationMethod<OptimizePromptRequest, OptimizePromptResponse, OptimizePromptError, Credentials | HttpClient.HttpClient>;
export type PutInvocationStepError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Add an invocation step to an invocation in a session. An invocation step stores fine-grained state checkpoints, including text and images, for each interaction. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 *
 * Related APIs:
 *
 * - GetInvocationStep
 *
 * - ListInvocationSteps
 *
 * - ListInvocations
 *
 * - ListSessions
 */
export declare const putInvocationStep: API.OperationMethod<PutInvocationStepRequest, PutInvocationStepResponse, PutInvocationStepError, Credentials | HttpClient.HttpClient>;
export type RerankError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Reranks the relevance of sources based on queries. For more information, see Improve the relevance of query responses with a reranker model.
 */
export declare const rerank: API.PaginatedOperationMethod<RerankRequest, RerankResponse, RerankError, Credentials | HttpClient.HttpClient, RerankResult>;
export type RetrieveError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Queries a knowledge base and retrieves information from it.
 */
export declare const retrieve: API.PaginatedOperationMethod<RetrieveRequest, RetrieveResponse, RetrieveError, Credentials | HttpClient.HttpClient, KnowledgeBaseRetrievalResult>;
export type RetrieveAndGenerateError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Queries a knowledge base and generates responses based on the retrieved results and using the specified foundation model or inference profile. The response only cites sources that are relevant to the query.
 *
 * This API cannot be used with managed knowledge bases. Use AgenticRetrieveStream or Retrieve with managed knowledge bases.
 */
export declare const retrieveAndGenerate: API.OperationMethod<RetrieveAndGenerateRequest, RetrieveAndGenerateResponse, RetrieveAndGenerateError, Credentials | HttpClient.HttpClient>;
export type RetrieveAndGenerateStreamError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Queries a knowledge base and generates responses based on the retrieved results, with output in streaming format.
 *
 * This API cannot be used with managed knowledge bases. Use AgenticRetrieveStream or Retrieve with managed knowledge bases.
 *
 * The CLI doesn't support streaming operations in Amazon Bedrock, including `InvokeModelWithResponseStream`.
 *
 * This operation requires permission for the ` bedrock:RetrieveAndGenerate` action.
 */
export declare const retrieveAndGenerateStream: API.OperationMethod<RetrieveAndGenerateStreamRequest, RetrieveAndGenerateStreamResponse, RetrieveAndGenerateStreamError, Credentials | HttpClient.HttpClient>;
export type StartFlowExecutionError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an execution of an Amazon Bedrock flow. Unlike flows that run until completion or time out after five minutes, flow executions let you run flows asynchronously for longer durations. Flow executions also yield control so that your application can perform other tasks.
 *
 * This operation returns an Amazon Resource Name (ARN) that you can use to track and manage your flow execution.
 *
 * Flow executions is in preview release for Amazon Bedrock and is subject to change.
 */
export declare const startFlowExecution: API.OperationMethod<StartFlowExecutionRequest, StartFlowExecutionResponse, StartFlowExecutionError, Credentials | HttpClient.HttpClient>;
export type StopFlowExecutionError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops an Amazon Bedrock flow's execution. This operation prevents further processing of the flow and changes the execution status to `Aborted`.
 */
export declare const stopFlowExecution: API.OperationMethod<StopFlowExecutionRequest, StopFlowExecutionResponse, StopFlowExecutionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associate tags with a resource. For more information, see Tagging resources in the Amazon Bedrock User Guide.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the metadata or encryption settings of a session. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const updateSession: API.OperationMethod<UpdateSessionRequest, UpdateSessionResponse, UpdateSessionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-agent-runtime.d.ts.map