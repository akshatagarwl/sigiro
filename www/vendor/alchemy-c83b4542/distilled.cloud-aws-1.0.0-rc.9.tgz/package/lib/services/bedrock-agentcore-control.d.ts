import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConcurrentModificationException_base: S.Class<ConcurrentModificationException, S.TaggedStruct<"ConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DecryptionFailure_base: S.Class<DecryptionFailure, S.TaggedStruct<"DecryptionFailure", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DecryptionFailure extends /*@__PURE__*/ DecryptionFailure_base {
}
declare const EncryptionFailure_base: S.Class<EncryptionFailure, S.TaggedStruct<"EncryptionFailure", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EncryptionFailure extends /*@__PURE__*/ EncryptionFailure_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceLimitExceededException_base: S.Class<ResourceLimitExceededException, S.TaggedStruct<"ResourceLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const RetryableConflictException_base: S.Class<RetryableConflictException, S.TaggedStruct<"RetryableConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RetryableConflictException extends /*@__PURE__*/ RetryableConflictException_base {
}
declare const ServiceException_base: S.Class<ServiceException, S.TaggedStruct<"ServiceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const SubscriptionRequiredException_base: S.Class<SubscriptionRequiredException, S.TaggedStruct<"SubscriptionRequiredException", {
    readonly message: any;
    readonly subscriptionUrl: any;
    readonly productName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class SubscriptionRequiredException extends /*@__PURE__*/ SubscriptionRequiredException_base {
}
declare const ThrottledException_base: S.Class<ThrottledException, S.TaggedStruct<"ThrottledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottledException extends /*@__PURE__*/ ThrottledException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DatasetId = string;
export type ClientToken = string;
export type SensitiveJson = unknown;
export type DatasetExampleList = any[];
export declare const DatasetExampleList: any;
export interface InlineExamplesSource {
    examples: any[];
}
export declare const InlineExamplesSource: S.Schema<InlineExamplesSource>;
export type S3Uri = string;
export interface S3Source {
    s3Uri: string;
}
export declare const S3Source: S.Schema<S3Source>;
export type DataSourceType = {
    inlineExamples: InlineExamplesSource;
    s3Source?: never;
} | {
    inlineExamples?: never;
    s3Source: S3Source;
};
export declare const DataSourceType: any;
export interface AddDatasetExamplesRequest {
    datasetId: string;
    clientToken?: string;
    source: DataSourceType;
}
export declare const AddDatasetExamplesRequest: S.Schema<AddDatasetExamplesRequest>;
export type DatasetArn = string;
export type DatasetStatus = "CREATING" | "UPDATING" | "DELETING" | "ACTIVE" | "CREATE_FAILED" | "UPDATE_FAILED" | "DELETE_FAILED" | (string & {});
export declare const DatasetStatus: any;
export type ExampleId = string;
export type ExampleIdList = string[];
export declare const ExampleIdList: any;
export interface AddDatasetExamplesResponse {
    datasetArn: string;
    datasetId: string;
    status: DatasetStatus;
    addedCount: number;
    updatedAt: Date;
    exampleIds: string[];
}
export declare const AddDatasetExamplesResponse: S.Schema<AddDatasetExamplesResponse>;
export type GatewayIdentifier = string;
export type GatewayRateLimitId = string;
export type GatewayRateLimitDescription = string;
export type DimensionKey = string;
export type DimensionKeys = string[];
export declare const DimensionKeys: any;
export type DimensionValue = string;
export type Dimensions = {
    [key: string]: string | undefined;
};
export declare const Dimensions: any;
export type Period = "second" | "minute" | (string & {});
export declare const Period: any;
export interface RateConfig {
    rate: number;
    period: Period;
}
export declare const RateConfig: S.Schema<RateConfig>;
export type RateConfigs = RateConfig[];
export declare const RateConfigs: any;
export interface LimitEntry {
    dimensions: {
        [key: string]: string | undefined;
    };
    requests?: RateConfig[];
    tokens?: RateConfig[];
    connections?: RateConfig[];
}
export declare const LimitEntry: S.Schema<LimitEntry>;
export type LimitEntries = LimitEntry[];
export declare const LimitEntries: any;
export interface BatchPutLimitEntry {
    rateLimitId?: string;
    description?: string;
    dimensionKeys: string[];
    entries: LimitEntry[];
}
export declare const BatchPutLimitEntry: S.Schema<BatchPutLimitEntry>;
export type BatchPutLimitEntries = BatchPutLimitEntry[];
export declare const BatchPutLimitEntries: any;
export interface BatchPutGatewayRateLimitsRequest {
    gatewayIdentifier: string;
    clientToken?: string;
    rateLimits: BatchPutLimitEntry[];
}
export declare const BatchPutGatewayRateLimitsRequest: S.Schema<BatchPutGatewayRateLimitsRequest>;
export type GatewayRateLimitStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | (string & {});
export declare const GatewayRateLimitStatus: any;
export interface GatewayRateLimitDetail {
    rateLimitId: string;
    gatewayIdentifier: string;
    description?: string;
    dimensionKeys: string[];
    entries: LimitEntry[];
    status: GatewayRateLimitStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const GatewayRateLimitDetail: S.Schema<GatewayRateLimitDetail>;
export type GatewayRateLimits = GatewayRateLimitDetail[];
export declare const GatewayRateLimits: any;
export interface BatchPutGatewayRateLimitsResponse {
    rateLimits: GatewayRateLimitDetail[];
}
export declare const BatchPutGatewayRateLimitsResponse: S.Schema<BatchPutGatewayRateLimitsResponse>;
export type AgentRuntimeName = string;
export type RuntimeContainerUri = string;
export interface ContainerConfiguration {
    containerUri: string;
}
export declare const ContainerConfiguration: S.Schema<ContainerConfiguration>;
export interface S3Location {
    bucket: string;
    prefix: string;
    versionId?: string;
}
export declare const S3Location: S.Schema<S3Location>;
export type Code = {
    s3: S3Location;
};
export declare const Code: any;
export type AgentManagedRuntimeType = "PYTHON_3_10" | "PYTHON_3_11" | "PYTHON_3_12" | "PYTHON_3_13" | "PYTHON_3_14" | "NODE_22" | (string & {});
export declare const AgentManagedRuntimeType: any;
export type EntryPoint = string;
export type EntryPoints = string[];
export declare const EntryPoints: any;
export interface CodeConfiguration {
    code: Code;
    runtime: AgentManagedRuntimeType;
    entryPoint: string[];
}
export declare const CodeConfiguration: S.Schema<CodeConfiguration>;
export type AgentRuntimeArtifact = {
    containerConfiguration: ContainerConfiguration;
    codeConfiguration?: never;
} | {
    containerConfiguration?: never;
    codeConfiguration: CodeConfiguration;
};
export declare const AgentRuntimeArtifact: any;
export type RoleArn = string;
export type NetworkMode = "PUBLIC" | "VPC" | (string & {});
export declare const NetworkMode: any;
export type SecurityGroupId = string;
export type SecurityGroups = string[];
export declare const SecurityGroups: any;
export type SubnetId = string;
export type Subnets = string[];
export declare const Subnets: any;
export interface VpcConfig {
    securityGroups: string[];
    subnets: string[];
    requireServiceS3Endpoint?: boolean;
}
export declare const VpcConfig: S.Schema<VpcConfig>;
export interface NetworkConfiguration {
    networkMode: NetworkMode;
    networkModeConfig?: VpcConfig;
}
export declare const NetworkConfiguration: S.Schema<NetworkConfiguration>;
export type Description = string | redacted.Redacted<string>;
export type DiscoveryUrl = string;
export type AllowedAudience = string;
export type AllowedAudienceList = string[];
export declare const AllowedAudienceList: any;
export type AllowedClient = string;
export type AllowedClientsList = string[];
export declare const AllowedClientsList: any;
export type AllowedScopeType = string;
export type AllowedScopesType = string[];
export declare const AllowedScopesType: any;
export type AdvertisedScopeMappingType = {
    [key: string]: string | undefined;
};
export declare const AdvertisedScopeMappingType: any;
export type InboundTokenClaimNameType = string;
export type InboundTokenClaimValueType = "STRING" | "STRING_ARRAY" | (string & {});
export declare const InboundTokenClaimValueType: any;
export type MatchValueString = string;
export type MatchValueStringList = string[];
export declare const MatchValueStringList: any;
export type ClaimMatchValueType = {
    matchValueString: string;
    matchValueStringList?: never;
} | {
    matchValueString?: never;
    matchValueStringList: string[];
};
export declare const ClaimMatchValueType: any;
export type ClaimMatchOperatorType = "EQUALS" | "CONTAINS" | "CONTAINS_ANY" | (string & {});
export declare const ClaimMatchOperatorType: any;
export interface AuthorizingClaimMatchValueType {
    claimMatchValue: ClaimMatchValueType;
    claimMatchOperator: ClaimMatchOperatorType;
}
export declare const AuthorizingClaimMatchValueType: S.Schema<AuthorizingClaimMatchValueType>;
export interface CustomClaimValidationType {
    inboundTokenClaimName: string;
    inboundTokenClaimValueType: InboundTokenClaimValueType;
    authorizingClaimMatchValue: AuthorizingClaimMatchValueType;
}
export declare const CustomClaimValidationType: S.Schema<CustomClaimValidationType>;
export type CustomClaimValidationsType = CustomClaimValidationType[];
export declare const CustomClaimValidationsType: any;
export type ResourceConfigurationIdentifier = string;
export type SelfManagedLatticeResource = {
    resourceConfigurationIdentifier: string;
};
export declare const SelfManagedLatticeResource: any;
export type VpcIdentifier = string;
export type SubnetIds = string[];
export declare const SubnetIds: any;
export type EndpointIpAddressType = "IPV4" | "IPV6" | (string & {});
export declare const EndpointIpAddressType: any;
export type SecurityGroupIdentifier = string;
export type SecurityGroupIds = string[];
export declare const SecurityGroupIds: any;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export type RoutingDomain = string;
export interface ManagedVpcResource {
    vpcIdentifier: string;
    subnetIds: string[];
    endpointIpAddressType: EndpointIpAddressType;
    securityGroupIds?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
    routingDomain?: string;
}
export declare const ManagedVpcResource: S.Schema<ManagedVpcResource>;
export type PrivateEndpoint = {
    selfManagedLatticeResource: SelfManagedLatticeResource;
    managedVpcResource?: never;
} | {
    selfManagedLatticeResource?: never;
    managedVpcResource: ManagedVpcResource;
};
export declare const PrivateEndpoint: any;
export type PrivateEndpointOverrideDomain = string;
export interface PrivateEndpointOverride {
    domain: string;
    privateEndpoint: PrivateEndpoint;
}
export declare const PrivateEndpointOverride: S.Schema<PrivateEndpointOverride>;
export type PrivateEndpointOverrides = PrivateEndpointOverride[];
export declare const PrivateEndpointOverrides: any;
export type BedrockAgentcoreResourceArn = string;
export interface HostingEnvironment {
    arn: string;
}
export declare const HostingEnvironment: S.Schema<HostingEnvironment>;
export type HostingEnvironmentListType = HostingEnvironment[];
export declare const HostingEnvironmentListType: any;
export type WorkloadIdentityNameType = string;
export type WorkloadIdentityNameListType = string[];
export declare const WorkloadIdentityNameListType: any;
export interface AllowedWorkloadConfiguration {
    hostingEnvironments?: HostingEnvironment[];
    workloadIdentities?: string[];
}
export declare const AllowedWorkloadConfiguration: S.Schema<AllowedWorkloadConfiguration>;
export interface CustomJWTAuthorizerConfiguration {
    discoveryUrl: string;
    allowedAudience?: string[];
    allowedClients?: string[];
    allowedScopes?: string[];
    advertisedScopeMapping?: {
        [key: string]: string | undefined;
    };
    customClaims?: CustomClaimValidationType[];
    privateEndpoint?: PrivateEndpoint;
    privateEndpointOverrides?: PrivateEndpointOverride[];
    allowedWorkloadConfiguration?: AllowedWorkloadConfiguration;
}
export declare const CustomJWTAuthorizerConfiguration: S.Schema<CustomJWTAuthorizerConfiguration>;
export type AuthorizerConfiguration = {
    customJWTAuthorizer: CustomJWTAuthorizerConfiguration;
};
export declare const AuthorizerConfiguration: any;
export type HeaderName = string;
export type RequestHeaderAllowlist = string[];
export declare const RequestHeaderAllowlist: any;
export type RequestHeaderConfiguration = {
    requestHeaderAllowlist: string[];
};
export declare const RequestHeaderConfiguration: any;
export type ServerProtocol = "MCP" | "HTTP" | "A2A" | "AGUI" | (string & {});
export declare const ServerProtocol: any;
export interface ProtocolConfiguration {
    serverProtocol: ServerProtocol;
}
export declare const ProtocolConfiguration: S.Schema<ProtocolConfiguration>;
export interface LifecycleConfiguration {
    idleRuntimeSessionTimeout?: number;
    maxLifetime?: number;
}
export declare const LifecycleConfiguration: S.Schema<LifecycleConfiguration>;
export type EnvironmentVariableKey = string;
export type EnvironmentVariableValue = string;
export type EnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export declare const EnvironmentVariablesMap: any;
export type MountPath = string;
export interface SessionStorageConfiguration {
    mountPath: string;
}
export declare const SessionStorageConfiguration: S.Schema<SessionStorageConfiguration>;
export type S3FilesAccessPointArn = string;
export interface S3FilesAccessPointConfiguration {
    accessPointArn: string;
    mountPath: string;
}
export declare const S3FilesAccessPointConfiguration: S.Schema<S3FilesAccessPointConfiguration>;
export type EfsAccessPointArn = string;
export interface EfsAccessPointConfiguration {
    accessPointArn: string;
    mountPath: string;
}
export declare const EfsAccessPointConfiguration: S.Schema<EfsAccessPointConfiguration>;
export type CapacityProviderVolumeName = string;
export interface CapacityProviderVolumeConfiguration {
    volumeName: string;
    mountPath: string;
}
export declare const CapacityProviderVolumeConfiguration: S.Schema<CapacityProviderVolumeConfiguration>;
export type FilesystemConfiguration = {
    sessionStorage: SessionStorageConfiguration;
    s3FilesAccessPoint?: never;
    efsAccessPoint?: never;
    capacityProviderVolume?: never;
} | {
    sessionStorage?: never;
    s3FilesAccessPoint: S3FilesAccessPointConfiguration;
    efsAccessPoint?: never;
    capacityProviderVolume?: never;
} | {
    sessionStorage?: never;
    s3FilesAccessPoint?: never;
    efsAccessPoint: EfsAccessPointConfiguration;
    capacityProviderVolume?: never;
} | {
    sessionStorage?: never;
    s3FilesAccessPoint?: never;
    efsAccessPoint?: never;
    capacityProviderVolume: CapacityProviderVolumeConfiguration;
};
export declare const FilesystemConfiguration: any;
export type FilesystemConfigurations = FilesystemConfiguration[];
export declare const FilesystemConfigurations: any;
export type CapacityProviderArn = string;
export interface CapacityProviderConfiguration {
    capacityProviderArn?: string;
}
export declare const CapacityProviderConfiguration: S.Schema<CapacityProviderConfiguration>;
export interface CreateAgentRuntimeRequest {
    agentRuntimeName: string;
    agentRuntimeArtifact: AgentRuntimeArtifact;
    roleArn: string;
    networkConfiguration?: NetworkConfiguration;
    clientToken?: string;
    description?: string | redacted.Redacted<string>;
    authorizerConfiguration?: AuthorizerConfiguration;
    requestHeaderConfiguration?: RequestHeaderConfiguration;
    protocolConfiguration?: ProtocolConfiguration;
    lifecycleConfiguration?: LifecycleConfiguration;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    filesystemConfigurations?: FilesystemConfiguration[];
    capacityProviderConfiguration?: CapacityProviderConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateAgentRuntimeRequest: S.Schema<CreateAgentRuntimeRequest>;
export type AgentRuntimeArn = string;
export type WorkloadIdentityArn = string;
export interface WorkloadIdentityDetails {
    workloadIdentityArn?: string;
}
export declare const WorkloadIdentityDetails: S.Schema<WorkloadIdentityDetails>;
export type AgentRuntimeId = string;
export type AgentRuntimeVersion = string;
export type AgentRuntimeStatus = "CREATING" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "READY" | "DELETING" | (string & {});
export declare const AgentRuntimeStatus: any;
export interface CreateAgentRuntimeResponse {
    agentRuntimeArn: string;
    workloadIdentityDetails?: WorkloadIdentityDetails;
    agentRuntimeId: string;
    agentRuntimeVersion: string;
    createdAt: Date;
    status: AgentRuntimeStatus;
}
export declare const CreateAgentRuntimeResponse: S.Schema<CreateAgentRuntimeResponse>;
export type EndpointName = string | redacted.Redacted<string>;
export type AgentEndpointDescription = string;
export interface CreateAgentRuntimeEndpointRequest {
    agentRuntimeId: string;
    name: string | redacted.Redacted<string>;
    agentRuntimeVersion?: string;
    description?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateAgentRuntimeEndpointRequest: S.Schema<CreateAgentRuntimeEndpointRequest>;
export type AgentRuntimeEndpointArn = string;
export type AgentRuntimeEndpointStatus = "CREATING" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "READY" | "DELETING" | (string & {});
export declare const AgentRuntimeEndpointStatus: any;
export interface CreateAgentRuntimeEndpointResponse {
    targetVersion: string;
    agentRuntimeEndpointArn: string;
    agentRuntimeArn: string;
    agentRuntimeId?: string;
    endpointName?: string | redacted.Redacted<string>;
    status: AgentRuntimeEndpointStatus;
    createdAt: Date;
}
export declare const CreateAgentRuntimeEndpointResponse: S.Schema<CreateAgentRuntimeEndpointResponse>;
export type CredentialProviderName = string;
export type DefaultApiKeyType = string | redacted.Redacted<string>;
export type SecretIdType = string;
export type SecretJsonKeyType = string;
export interface SecretReference {
    secretId: string;
    jsonKey: string;
}
export declare const SecretReference: S.Schema<SecretReference>;
export type SecretSourceType = "MANAGED" | "EXTERNAL" | (string & {});
export declare const SecretSourceType: any;
export interface CreateApiKeyCredentialProviderRequest {
    name: string;
    apiKey?: string | redacted.Redacted<string>;
    apiKeySecretConfig?: SecretReference;
    apiKeySecretSource?: SecretSourceType;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateApiKeyCredentialProviderRequest: S.Schema<CreateApiKeyCredentialProviderRequest>;
export type SecretArn = string;
export interface Secret {
    secretArn: string;
}
export declare const Secret: S.Schema<Secret>;
export type ApiKeyCredentialProviderArnType = string;
export interface CreateApiKeyCredentialProviderResponse {
    apiKeySecretArn: Secret;
    apiKeySecretJsonKey?: string;
    apiKeySecretSource?: SecretSourceType;
    name: string;
    credentialProviderArn: string;
}
export declare const CreateApiKeyCredentialProviderResponse: S.Schema<CreateApiKeyCredentialProviderResponse>;
export type SandboxName = string;
export type BrowserNetworkMode = "PUBLIC" | "VPC" | (string & {});
export declare const BrowserNetworkMode: any;
export interface BrowserNetworkConfiguration {
    networkMode: BrowserNetworkMode;
    vpcConfig?: VpcConfig;
}
export declare const BrowserNetworkConfiguration: S.Schema<BrowserNetworkConfiguration>;
export interface RecordingConfig {
    enabled?: boolean;
    s3Location?: S3Location;
}
export declare const RecordingConfig: S.Schema<RecordingConfig>;
export interface BrowserSigningConfigInput {
    enabled: boolean;
}
export declare const BrowserSigningConfigInput: S.Schema<BrowserSigningConfigInput>;
export type ResourceLocation = {
    s3: S3Location;
};
export declare const ResourceLocation: any;
export type BrowserEnterprisePolicyType = "MANAGED" | "RECOMMENDED" | (string & {});
export declare const BrowserEnterprisePolicyType: any;
export interface BrowserEnterprisePolicy {
    location: ResourceLocation;
    type?: BrowserEnterprisePolicyType;
}
export declare const BrowserEnterprisePolicy: S.Schema<BrowserEnterprisePolicy>;
export type BrowserEnterprisePolicies = BrowserEnterprisePolicy[];
export declare const BrowserEnterprisePolicies: any;
export type ToolSecretArn = string;
export interface SecretsManagerLocation {
    secretArn: string;
}
export declare const SecretsManagerLocation: S.Schema<SecretsManagerLocation>;
export type CertificateLocation = {
    secretsManager: SecretsManagerLocation;
};
export declare const CertificateLocation: any;
export interface Certificate {
    location: CertificateLocation;
}
export declare const Certificate: S.Schema<Certificate>;
export type Certificates = Certificate[];
export declare const Certificates: any;
export type S3FilesFileSystemArn = string;
export interface S3FilesConfiguration {
    accessPointArn: string;
    mountPath: string;
    fileSystemArn: string;
}
export declare const S3FilesConfiguration: S.Schema<S3FilesConfiguration>;
export type EfsFileSystemArn = string;
export interface EfsConfiguration {
    accessPointArn: string;
    mountPath: string;
    fileSystemArn: string;
}
export declare const EfsConfiguration: S.Schema<EfsConfiguration>;
export type ToolsFileSystemConfiguration = {
    s3FilesConfiguration: S3FilesConfiguration;
    efsConfiguration?: never;
} | {
    s3FilesConfiguration?: never;
    efsConfiguration: EfsConfiguration;
};
export declare const ToolsFileSystemConfiguration: any;
export type ToolsFileSystemConfigurations = ToolsFileSystemConfiguration[];
export declare const ToolsFileSystemConfigurations: any;
export interface CreateBrowserRequest {
    name: string;
    description?: string | redacted.Redacted<string>;
    executionRoleArn?: string;
    networkConfiguration: BrowserNetworkConfiguration;
    recording?: RecordingConfig;
    browserSigning?: BrowserSigningConfigInput;
    enterprisePolicies?: BrowserEnterprisePolicy[];
    certificates?: Certificate[];
    filesystemConfigurations?: ToolsFileSystemConfiguration[];
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateBrowserRequest: S.Schema<CreateBrowserRequest>;
export type BrowserId = string;
export type BrowserArn = string;
export type BrowserStatus = "CREATING" | "CREATE_FAILED" | "READY" | "DELETING" | "DELETE_FAILED" | "DELETED" | (string & {});
export declare const BrowserStatus: any;
export interface CreateBrowserResponse {
    browserId: string;
    browserArn: string;
    createdAt: Date;
    status: BrowserStatus;
}
export declare const CreateBrowserResponse: S.Schema<CreateBrowserResponse>;
export type BrowserProfileName = string;
export interface CreateBrowserProfileRequest {
    name: string;
    description?: string | redacted.Redacted<string>;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateBrowserProfileRequest: S.Schema<CreateBrowserProfileRequest>;
export type BrowserProfileId = string;
export type BrowserProfileArn = string;
export type BrowserProfileStatus = "READY" | "DELETING" | "DELETED" | "SAVING" | (string & {});
export declare const BrowserProfileStatus: any;
export interface CreateBrowserProfileResponse {
    profileId: string;
    profileArn: string;
    createdAt: Date;
    status: BrowserProfileStatus;
}
export declare const CreateBrowserProfileResponse: S.Schema<CreateBrowserProfileResponse>;
export type CapacityProviderName = string;
export interface PermissionsConfiguration {
    capacityProviderOperatorRoleArn: string;
}
export declare const PermissionsConfiguration: S.Schema<PermissionsConfiguration>;
export type OperatingSystem = "LINUX_X86_64" | "LINUX_ARM64" | (string & {});
export declare const OperatingSystem: any;
export type EC2InstanceType = string;
export type InstanceTypeList = string[];
export declare const InstanceTypeList: any;
export interface InstanceRequirements {
    allowedInstanceTypes: string[];
}
export declare const InstanceRequirements: S.Schema<InstanceRequirements>;
export type DeviceName = string;
export type VirtualDeviceName = string;
export type EbsVolumeType = "standard" | "io1" | "io2" | "gp2" | "sc1" | "st1" | "gp3" | (string & {});
export declare const EbsVolumeType: any;
export type VolumeIops = number;
export type VolumeThroughput = number;
export type KmsKeyId = string;
export type EbsSnapshotId = string;
export type VolumeSizeGiB = number;
export type EbsVolumeInitializationRate = number;
export type EbsCardIndex = number;
export interface EphemeralEBSVolumeConfiguration {
    volumeType?: EbsVolumeType;
    iops?: number;
    throughput?: number;
    encrypted?: boolean;
    kmsKeyId?: string;
    snapshotId?: string;
    volumeSize?: number;
    volumeInitializationRate?: number;
    ebsCardIndex?: number;
}
export declare const EphemeralEBSVolumeConfiguration: S.Schema<EphemeralEBSVolumeConfiguration>;
export interface EphemeralBlockDeviceMapping {
    deviceName?: string;
    virtualName?: string;
    ebs?: EphemeralEBSVolumeConfiguration;
}
export declare const EphemeralBlockDeviceMapping: S.Schema<EphemeralBlockDeviceMapping>;
export type EphemeralBlockDeviceMappingList = EphemeralBlockDeviceMapping[];
export declare const EphemeralBlockDeviceMappingList: any;
export type Monitoring = "BASIC" | "DETAILED" | (string & {});
export declare const Monitoring: any;
export type LicenseConfigurationArn = string;
export interface LicenseSpecification {
    licenseConfigurationArn: string;
}
export declare const LicenseSpecification: S.Schema<LicenseSpecification>;
export type LicenseSpecificationList = LicenseSpecification[];
export declare const LicenseSpecificationList: any;
export type CapacityReservationPreference = "capacity-reservations-only" | "open" | "none" | (string & {});
export declare const CapacityReservationPreference: any;
export type CapacityReservationId = string;
export type CapacityReservationResourceGroupArn = string;
export interface CapacityReservationTarget {
    capacityReservationId?: string;
    capacityReservationResourceGroupArn?: string;
}
export declare const CapacityReservationTarget: S.Schema<CapacityReservationTarget>;
export interface CapacityReservationSpecification {
    capacityReservationPreference?: CapacityReservationPreference;
    capacityReservationTarget?: CapacityReservationTarget;
}
export declare const CapacityReservationSpecification: S.Schema<CapacityReservationSpecification>;
export type SSHKeyName = string;
export type InstanceProfileArn = string;
export interface LaunchParameters {
    operatingSystem: OperatingSystem;
    instanceRequirements: InstanceRequirements;
    ephemeralVolumes?: EphemeralBlockDeviceMapping[];
    monitoring?: Monitoring;
    licenseSpecifications?: LicenseSpecification[];
    capacityReservationSpecification?: CapacityReservationSpecification;
    sshKeyName?: string;
    instanceProfileArn?: string;
    propagatedTags?: {
        [key: string]: string | undefined;
    };
}
export declare const LaunchParameters: S.Schema<LaunchParameters>;
export type LaunchTemplateSource = {
    launchParameters: LaunchParameters;
};
export declare const LaunchTemplateSource: any;
export type SubnetIdList = string[];
export declare const SubnetIdList: any;
export type SecurityGroupIdList = string[];
export declare const SecurityGroupIdList: any;
export interface VpcConfiguration {
    subnets: string[];
    securityGroups: string[];
}
export declare const VpcConfiguration: S.Schema<VpcConfiguration>;
export type VolumeName = string;
export interface EbsVolumeConfiguration {
    name: string;
    sizeGiB: number;
    volumeType?: EbsVolumeType;
    iops?: number;
    throughput?: number;
    encrypted?: boolean;
    kmsKeyId?: string;
    snapshotId?: string;
}
export declare const EbsVolumeConfiguration: S.Schema<EbsVolumeConfiguration>;
export type VolumeConfiguration = {
    ebsConfiguration: EbsVolumeConfiguration;
};
export declare const VolumeConfiguration: any;
export type VolumeConfigurationList = VolumeConfiguration[];
export declare const VolumeConfigurationList: any;
export interface InstanceLifecycleConfiguration {
    idleInstanceTimeout?: number;
    maxLifetime?: number;
}
export declare const InstanceLifecycleConfiguration: S.Schema<InstanceLifecycleConfiguration>;
export interface RootVolumeConfiguration {
    volumeType?: EbsVolumeType;
    iops?: number;
    throughput?: number;
    encrypted?: boolean;
    kmsKeyId?: string;
    freeSpaceGiB?: number;
}
export declare const RootVolumeConfiguration: S.Schema<RootVolumeConfiguration>;
export interface Ec2Configuration {
    launchTemplateSource: LaunchTemplateSource;
    vpcConfiguration: VpcConfiguration;
    volumes?: VolumeConfiguration[];
    lifecycleConfiguration?: InstanceLifecycleConfiguration;
    rootVolume?: RootVolumeConfiguration;
}
export declare const Ec2Configuration: S.Schema<Ec2Configuration>;
export type ComputeConfiguration = {
    ec2Configuration: Ec2Configuration;
};
export declare const ComputeConfiguration: any;
export interface CreateCapacityProviderInput {
    name: string;
    description?: string | redacted.Redacted<string>;
    permissionsConfiguration: PermissionsConfiguration;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    computeConfiguration: ComputeConfiguration;
}
export declare const CreateCapacityProviderInput: S.Schema<CreateCapacityProviderInput>;
export type CapacityProviderId = string;
export type CapacityProviderStatus = "CREATING" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "READY" | "DELETING" | "DELETE_FAILED" | (string & {});
export declare const CapacityProviderStatus: any;
export interface CreateCapacityProviderOutput {
    capacityProviderId: string;
    capacityProviderArn: string;
    name: string;
    status: CapacityProviderStatus;
}
export declare const CreateCapacityProviderOutput: S.Schema<CreateCapacityProviderOutput>;
export type CodeInterpreterNetworkMode = "PUBLIC" | "SANDBOX" | "VPC" | (string & {});
export declare const CodeInterpreterNetworkMode: any;
export interface CodeInterpreterNetworkConfiguration {
    networkMode: CodeInterpreterNetworkMode;
    vpcConfig?: VpcConfig;
}
export declare const CodeInterpreterNetworkConfiguration: S.Schema<CodeInterpreterNetworkConfiguration>;
export interface CreateCodeInterpreterRequest {
    name: string;
    description?: string | redacted.Redacted<string>;
    executionRoleArn?: string;
    networkConfiguration: CodeInterpreterNetworkConfiguration;
    certificates?: Certificate[];
    filesystemConfigurations?: ToolsFileSystemConfiguration[];
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateCodeInterpreterRequest: S.Schema<CreateCodeInterpreterRequest>;
export type CodeInterpreterId = string;
export type CodeInterpreterArn = string;
export type CodeInterpreterStatus = "CREATING" | "CREATE_FAILED" | "READY" | "DELETING" | "DELETE_FAILED" | "DELETED" | (string & {});
export declare const CodeInterpreterStatus: any;
export interface CreateCodeInterpreterResponse {
    codeInterpreterId: string;
    codeInterpreterArn: string;
    createdAt: Date;
    status: CodeInterpreterStatus;
}
export declare const CreateCodeInterpreterResponse: S.Schema<CreateCodeInterpreterResponse>;
export type ConfigurationBundleName = string;
export type ConfigurationBundleDescription = string | redacted.Redacted<string>;
export type ComponentIdentifier = string;
export interface ComponentConfiguration {
    configuration: any;
}
export declare const ComponentConfiguration: S.Schema<ComponentConfiguration>;
export type ComponentConfigurationMap = {
    [key: string]: ComponentConfiguration | undefined;
};
export declare const ComponentConfigurationMap: any;
export type BranchName = string;
export interface VersionCreatedBySource {
    name: string;
    arn?: string;
}
export declare const VersionCreatedBySource: S.Schema<VersionCreatedBySource>;
export type KmsKeyArn = string;
export interface CreateConfigurationBundleRequest {
    clientToken?: string;
    bundleName: string;
    description?: string | redacted.Redacted<string>;
    components: {
        [key: string]: ComponentConfiguration | undefined;
    };
    branchName?: string;
    commitMessage?: string;
    createdBy?: VersionCreatedBySource;
    kmsKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateConfigurationBundleRequest: S.Schema<CreateConfigurationBundleRequest>;
export type ConfigurationBundleArn = string;
export type ConfigurationBundleId = string;
export type ConfigurationBundleVersion = string;
export interface CreateConfigurationBundleResponse {
    bundleArn: string;
    bundleId: string;
    versionId: string;
    createdAt: Date;
}
export declare const CreateConfigurationBundleResponse: S.Schema<CreateConfigurationBundleResponse>;
export type DatasetName = string;
export type DatasetSchemaType = "AGENTCORE_EVALUATION_PREDEFINED_V1" | "AGENTCORE_EVALUATION_SIMULATED_V1" | "THIRD_PARTY_EVALUATION_V1" | (string & {});
export declare const DatasetSchemaType: any;
export interface CreateDatasetRequest {
    clientToken?: string;
    datasetName: string;
    description?: string;
    source: DataSourceType;
    schemaType: DatasetSchemaType;
    kmsKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDatasetRequest: S.Schema<CreateDatasetRequest>;
export interface CreateDatasetResponse {
    datasetArn: string;
    datasetId: string;
    status: DatasetStatus;
    createdAt: Date;
}
export declare const CreateDatasetResponse: S.Schema<CreateDatasetResponse>;
export interface CreateDatasetVersionRequest {
    datasetId: string;
    clientToken?: string;
}
export declare const CreateDatasetVersionRequest: S.Schema<CreateDatasetVersionRequest>;
export type DatasetVersion = string;
export interface CreateDatasetVersionResponse {
    datasetArn: string;
    datasetId: string;
    status: DatasetStatus;
    datasetVersion: string;
    createdAt: Date;
}
export declare const CreateDatasetVersionResponse: S.Schema<CreateDatasetVersionResponse>;
export type CustomEvaluatorName = string;
export type EvaluatorDescription = string | redacted.Redacted<string>;
export type EvaluatorInstructions = string | redacted.Redacted<string>;
export interface NumericalScaleDefinition {
    definition: string;
    value: number;
    label: string;
}
export declare const NumericalScaleDefinition: S.Schema<NumericalScaleDefinition>;
export type NumericalScaleDefinitions = NumericalScaleDefinition[];
export declare const NumericalScaleDefinitions: any;
export interface CategoricalScaleDefinition {
    definition: string;
    label: string;
}
export declare const CategoricalScaleDefinition: S.Schema<CategoricalScaleDefinition>;
export type CategoricalScaleDefinitions = CategoricalScaleDefinition[];
export declare const CategoricalScaleDefinitions: any;
export type RatingScale = {
    numerical: NumericalScaleDefinition[];
    categorical?: never;
} | {
    numerical?: never;
    categorical: CategoricalScaleDefinition[];
};
export declare const RatingScale: any;
export type ModelId = string;
export type NonEmptyString = string;
export type NonEmptyStringList = string[];
export declare const NonEmptyStringList: any;
export interface InferenceConfiguration {
    maxTokens?: number;
    temperature?: number;
    topP?: number;
    stopSequences?: string[];
}
export declare const InferenceConfiguration: S.Schema<InferenceConfiguration>;
export type AdditionalModelRequestFields = unknown;
export interface BedrockEvaluatorModelConfig {
    modelId: string;
    inferenceConfig?: InferenceConfiguration;
    additionalModelRequestFields?: any;
}
export declare const BedrockEvaluatorModelConfig: S.Schema<BedrockEvaluatorModelConfig>;
export interface ReasoningConfiguration {
    effort?: string;
}
export declare const ReasoningConfiguration: S.Schema<ReasoningConfiguration>;
export interface OpenResponsesEvaluatorModelConfig {
    modelId: string;
    maxOutputTokens?: number;
    temperature?: number;
    topP?: number;
    reasoning?: ReasoningConfiguration;
}
export declare const OpenResponsesEvaluatorModelConfig: S.Schema<OpenResponsesEvaluatorModelConfig>;
export type EvaluatorModelConfig = {
    bedrockEvaluatorModelConfig: BedrockEvaluatorModelConfig;
    responsesEvaluatorModelConfig?: never;
} | {
    bedrockEvaluatorModelConfig?: never;
    responsesEvaluatorModelConfig: OpenResponsesEvaluatorModelConfig;
};
export declare const EvaluatorModelConfig: any;
export interface LlmAsAJudgeEvaluatorConfig {
    instructions: string | redacted.Redacted<string>;
    ratingScale: RatingScale;
    modelConfig: EvaluatorModelConfig;
}
export declare const LlmAsAJudgeEvaluatorConfig: S.Schema<LlmAsAJudgeEvaluatorConfig>;
export type LambdaArn = string;
export interface LambdaEvaluatorConfig {
    lambdaArn: string;
    lambdaTimeoutInSeconds?: number;
}
export declare const LambdaEvaluatorConfig: S.Schema<LambdaEvaluatorConfig>;
export type CodeBasedEvaluatorConfig = {
    lambdaConfig: LambdaEvaluatorConfig;
};
export declare const CodeBasedEvaluatorConfig: any;
export type EvaluatorId = string;
export interface DerivedEvaluatorConfig {
    baseEvaluatorId: string;
    modelConfig: EvaluatorModelConfig;
}
export declare const DerivedEvaluatorConfig: S.Schema<DerivedEvaluatorConfig>;
export type EvaluatorConfig = {
    llmAsAJudge: LlmAsAJudgeEvaluatorConfig;
    codeBased?: never;
    derived?: never;
} | {
    llmAsAJudge?: never;
    codeBased: CodeBasedEvaluatorConfig;
    derived?: never;
} | {
    llmAsAJudge?: never;
    codeBased?: never;
    derived: DerivedEvaluatorConfig;
};
export declare const EvaluatorConfig: any;
export type EvaluatorLevel = "TOOL_CALL" | "TRACE" | "SESSION" | (string & {});
export declare const EvaluatorLevel: any;
export interface CreateEvaluatorRequest {
    clientToken?: string;
    evaluatorName: string;
    description?: string | redacted.Redacted<string>;
    evaluatorConfig: EvaluatorConfig;
    level: EvaluatorLevel;
    kmsKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateEvaluatorRequest: S.Schema<CreateEvaluatorRequest>;
export type CustomEvaluatorArn = string;
export type EvaluatorStatus = "ACTIVE" | "CREATING" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "DELETING" | (string & {});
export declare const EvaluatorStatus: any;
export interface CreateEvaluatorResponse {
    evaluatorArn: string;
    evaluatorId: string;
    createdAt: Date;
    status: EvaluatorStatus;
}
export declare const CreateEvaluatorResponse: S.Schema<CreateEvaluatorResponse>;
export type GatewayName = string;
export type GatewayDescription = string | redacted.Redacted<string>;
export type GatewayProtocolType = "MCP" | (string & {});
export declare const GatewayProtocolType: any;
export type McpVersion = string;
export type McpSupportedVersions = string[];
export declare const McpSupportedVersions: any;
export type McpInstructions = string | redacted.Redacted<string>;
export type SearchType = "SEMANTIC" | (string & {});
export declare const SearchType: any;
export interface SessionConfiguration {
    sessionTimeoutInSeconds?: number;
}
export declare const SessionConfiguration: S.Schema<SessionConfiguration>;
export interface StreamingConfiguration {
    enableResponseStreaming?: boolean;
}
export declare const StreamingConfiguration: S.Schema<StreamingConfiguration>;
export interface MCPGatewayConfiguration {
    supportedVersions?: string[];
    instructions?: string | redacted.Redacted<string>;
    searchType?: SearchType;
    sessionConfiguration?: SessionConfiguration;
    streamingConfiguration?: StreamingConfiguration;
}
export declare const MCPGatewayConfiguration: S.Schema<MCPGatewayConfiguration>;
export type GatewayProtocolConfiguration = {
    mcp: MCPGatewayConfiguration;
};
export declare const GatewayProtocolConfiguration: any;
export type AuthorizerType = "CUSTOM_JWT" | "AWS_IAM" | "NONE" | "AUTHENTICATE_ONLY" | (string & {});
export declare const AuthorizerType: any;
export type LambdaFunctionArn = string;
export interface LambdaInterceptorConfiguration {
    arn: string;
}
export declare const LambdaInterceptorConfiguration: S.Schema<LambdaInterceptorConfiguration>;
export type InterceptorConfiguration = {
    lambda: LambdaInterceptorConfiguration;
};
export declare const InterceptorConfiguration: any;
export type GatewayInterceptionPoint = "REQUEST" | "RESPONSE" | (string & {});
export declare const GatewayInterceptionPoint: any;
export type GatewayInterceptionPoints = GatewayInterceptionPoint[];
export declare const GatewayInterceptionPoints: any;
export type InterceptorPayloadExclusion = "RESPONSE_BODY" | (string & {});
export declare const InterceptorPayloadExclusion: any;
export type InterceptorPayloadExclusionSelector = {
    field: InterceptorPayloadExclusion;
};
export declare const InterceptorPayloadExclusionSelector: any;
export type InterceptorPayloadExclusionSelectorList = InterceptorPayloadExclusionSelector[];
export declare const InterceptorPayloadExclusionSelectorList: any;
export interface InterceptorPayloadFilter {
    exclude: InterceptorPayloadExclusionSelector[];
}
export declare const InterceptorPayloadFilter: S.Schema<InterceptorPayloadFilter>;
export interface InterceptorInputConfiguration {
    passRequestHeaders: boolean;
    payloadFilter?: InterceptorPayloadFilter;
}
export declare const InterceptorInputConfiguration: S.Schema<InterceptorInputConfiguration>;
export interface GatewayInterceptorConfiguration {
    interceptor: InterceptorConfiguration;
    interceptionPoints: GatewayInterceptionPoint[];
    inputConfiguration?: InterceptorInputConfiguration;
}
export declare const GatewayInterceptorConfiguration: S.Schema<GatewayInterceptorConfiguration>;
export type GatewayInterceptorConfigurations = GatewayInterceptorConfiguration[];
export declare const GatewayInterceptorConfigurations: any;
export type GatewayPolicyEngineArn = string;
export type GatewayPolicyEngineMode = "LOG_ONLY" | "ENFORCE" | (string & {});
export declare const GatewayPolicyEngineMode: any;
export interface GatewayPolicyEngineConfiguration {
    arn: string;
    mode: GatewayPolicyEngineMode;
}
export declare const GatewayPolicyEngineConfiguration: S.Schema<GatewayPolicyEngineConfiguration>;
export type ExceptionLevel = "DEBUG" | (string & {});
export declare const ExceptionLevel: any;
export interface CreateGatewayRequest {
    name: string;
    description?: string | redacted.Redacted<string>;
    clientToken?: string;
    roleArn: string;
    protocolType?: GatewayProtocolType;
    protocolConfiguration?: GatewayProtocolConfiguration;
    authorizerType: AuthorizerType;
    authorizerConfiguration?: AuthorizerConfiguration;
    kmsKeyArn?: string;
    interceptorConfigurations?: GatewayInterceptorConfiguration[];
    policyEngineConfiguration?: GatewayPolicyEngineConfiguration;
    exceptionLevel?: ExceptionLevel;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateGatewayRequest: S.Schema<CreateGatewayRequest>;
export type GatewayArn = string;
export type GatewayId = string;
export type GatewayUrl = string;
export type GatewayStatus = "CREATING" | "UPDATING" | "UPDATE_UNSUCCESSFUL" | "DELETING" | "READY" | "FAILED" | (string & {});
export declare const GatewayStatus: any;
export type StatusReason = string;
export type StatusReasons = string[];
export declare const StatusReasons: any;
export interface LambdaTransformConfiguration {
    arn?: string;
}
export declare const LambdaTransformConfiguration: S.Schema<LambdaTransformConfiguration>;
export interface CustomTransformConfiguration {
    lambda?: LambdaTransformConfiguration;
}
export declare const CustomTransformConfiguration: S.Schema<CustomTransformConfiguration>;
export type WebAclArn = string;
export type WafFailureMode = "FAIL_CLOSE" | "FAIL_OPEN" | (string & {});
export declare const WafFailureMode: any;
export interface WafConfiguration {
    failureMode?: WafFailureMode;
}
export declare const WafConfiguration: S.Schema<WafConfiguration>;
export interface CreateGatewayResponse {
    gatewayArn: string;
    gatewayId: string;
    gatewayUrl?: string;
    createdAt: Date;
    updatedAt: Date;
    status: GatewayStatus;
    statusReasons?: string[];
    name: string;
    description?: string | redacted.Redacted<string>;
    roleArn?: string;
    protocolType?: GatewayProtocolType;
    protocolConfiguration?: GatewayProtocolConfiguration;
    authorizerType: AuthorizerType;
    authorizerConfiguration?: AuthorizerConfiguration;
    kmsKeyArn?: string;
    customTransformConfiguration?: CustomTransformConfiguration;
    interceptorConfigurations?: GatewayInterceptorConfiguration[];
    policyEngineConfiguration?: GatewayPolicyEngineConfiguration;
    workloadIdentityDetails?: WorkloadIdentityDetails;
    exceptionLevel?: ExceptionLevel;
    webAclArn?: string;
    wafConfiguration?: WafConfiguration;
}
export declare const CreateGatewayResponse: S.Schema<CreateGatewayResponse>;
export interface CreateGatewayRateLimitRequest {
    gatewayIdentifier: string;
    clientToken?: string;
    rateLimitId?: string;
    description?: string;
    dimensionKeys: string[];
    entries: LimitEntry[];
}
export declare const CreateGatewayRateLimitRequest: S.Schema<CreateGatewayRateLimitRequest>;
export interface CreateGatewayRateLimitResponse {
    rateLimitId: string;
    gatewayIdentifier: string;
    description?: string;
    dimensionKeys: string[];
    entries: LimitEntry[];
    status: GatewayRateLimitStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const CreateGatewayRateLimitResponse: S.Schema<CreateGatewayRateLimitResponse>;
export type GatewayRulePriority = number;
export type IamPrincipalArn = string;
export type PrincipalMatchOperator = "StringEquals" | "StringLike" | (string & {});
export declare const PrincipalMatchOperator: any;
export interface IamPrincipal {
    arn: string;
    operator?: PrincipalMatchOperator;
}
export declare const IamPrincipal: S.Schema<IamPrincipal>;
export type MatchPrincipalEntry = {
    iamPrincipal: IamPrincipal;
};
export declare const MatchPrincipalEntry: any;
export type MatchPrincipalEntries = MatchPrincipalEntry[];
export declare const MatchPrincipalEntries: any;
export interface MatchPrincipals {
    anyOf: MatchPrincipalEntry[];
}
export declare const MatchPrincipals: S.Schema<MatchPrincipals>;
export type MatchPathPattern = string;
export type MatchPathPatterns = string[];
export declare const MatchPathPatterns: any;
export interface MatchPaths {
    anyOf: string[];
}
export declare const MatchPaths: S.Schema<MatchPaths>;
export type Condition = {
    matchPrincipals: MatchPrincipals;
    matchPaths?: never;
} | {
    matchPrincipals?: never;
    matchPaths: MatchPaths;
};
export declare const Condition: any;
export type Conditions = Condition[];
export declare const Conditions: any;
export type GatewayConfigurationBundleArn = string;
export interface StaticOverride {
    bundleArn: string;
    bundleVersion: string;
}
export declare const StaticOverride: S.Schema<StaticOverride>;
export interface ConfigurationBundleReference {
    bundleArn: string;
    bundleVersion: string;
}
export declare const ConfigurationBundleReference: S.Schema<ConfigurationBundleReference>;
export type TrafficSplitMetadataKey = string;
export type TrafficSplitMetadataValue = string;
export type TrafficSplitMetadataMap = {
    [key: string]: string | undefined;
};
export declare const TrafficSplitMetadataMap: any;
export interface TrafficSplitEntry {
    name: string;
    weight: number;
    configurationBundle: ConfigurationBundleReference;
    description?: string;
    metadata?: {
        [key: string]: string | undefined;
    };
}
export declare const TrafficSplitEntry: S.Schema<TrafficSplitEntry>;
export type TrafficSplitEntries = TrafficSplitEntry[];
export declare const TrafficSplitEntries: any;
export interface WeightedOverride {
    trafficSplit: TrafficSplitEntry[];
}
export declare const WeightedOverride: S.Schema<WeightedOverride>;
export type ConfigurationBundleAction = {
    staticOverride: StaticOverride;
    weightedOverride?: never;
} | {
    staticOverride?: never;
    weightedOverride: WeightedOverride;
};
export declare const ConfigurationBundleAction: any;
export type TargetName = string | redacted.Redacted<string>;
export interface StaticRoute {
    targetName: string | redacted.Redacted<string>;
}
export declare const StaticRoute: S.Schema<StaticRoute>;
export interface TargetTrafficSplitEntry {
    name: string;
    weight: number;
    targetName: string | redacted.Redacted<string>;
    description?: string;
    metadata?: {
        [key: string]: string | undefined;
    };
}
export declare const TargetTrafficSplitEntry: S.Schema<TargetTrafficSplitEntry>;
export type TargetTrafficSplitEntries = TargetTrafficSplitEntry[];
export declare const TargetTrafficSplitEntries: any;
export interface WeightedRoute {
    trafficSplit: TargetTrafficSplitEntry[];
}
export declare const WeightedRoute: S.Schema<WeightedRoute>;
export type RouteToTargetAction = {
    staticRoute: StaticRoute;
    weightedRoute?: never;
} | {
    staticRoute?: never;
    weightedRoute: WeightedRoute;
};
export declare const RouteToTargetAction: any;
export type Action = {
    configurationBundle: ConfigurationBundleAction;
    routeToTarget?: never;
} | {
    configurationBundle?: never;
    routeToTarget: RouteToTargetAction;
};
export declare const Action: any;
export type Actions = Action[];
export declare const Actions: any;
export type GatewayRuleDescription = string;
export interface CreateGatewayRuleRequest {
    gatewayIdentifier: string;
    clientToken?: string;
    priority: number;
    conditions?: Condition[];
    actions: Action[];
    description?: string;
}
export declare const CreateGatewayRuleRequest: S.Schema<CreateGatewayRuleRequest>;
export type GatewayRuleId = string;
export type GatewayRuleStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | (string & {});
export declare const GatewayRuleStatus: any;
export interface SystemManagedBlock {
    managedBy: string;
}
export declare const SystemManagedBlock: S.Schema<SystemManagedBlock>;
export interface CreateGatewayRuleResponse {
    ruleId: string;
    gatewayArn: string;
    priority: number;
    conditions?: Condition[];
    actions: Action[];
    description?: string;
    createdAt: Date;
    status: GatewayRuleStatus;
    system?: SystemManagedBlock;
}
export declare const CreateGatewayRuleResponse: S.Schema<CreateGatewayRuleResponse>;
export type TargetDescription = string | redacted.Redacted<string>;
export type S3BucketUri = string;
export type AwsAccountId = string;
export interface S3Configuration {
    uri?: string;
    bucketOwnerAccountId?: string;
}
export declare const S3Configuration: S.Schema<S3Configuration>;
export type InlinePayload = string | redacted.Redacted<string>;
export type ApiSchemaConfiguration = {
    s3: S3Configuration;
    inlinePayload?: never;
} | {
    s3?: never;
    inlinePayload: string | redacted.Redacted<string>;
};
export declare const ApiSchemaConfiguration: any;
export type SchemaType = "string" | "number" | "object" | "array" | "boolean" | "integer" | (string & {});
export declare const SchemaType: any;
export type SchemaProperties = {
    [key: string]: SchemaDefinition | undefined;
};
export declare const SchemaProperties: S.Schema<SchemaProperties>;
export type RequiredProperties = string[];
export declare const RequiredProperties: any;
export interface SchemaDefinition {
    type: SchemaType;
    properties?: {
        [key: string]: SchemaDefinition | undefined;
    };
    required?: string[];
    items?: SchemaDefinition;
    description?: string;
}
export declare const SchemaDefinition: S.Schema<SchemaDefinition>;
export interface ToolDefinition {
    name: string;
    description: string;
    inputSchema: SchemaDefinition;
    outputSchema?: SchemaDefinition;
}
export declare const ToolDefinition: S.Schema<ToolDefinition>;
export type ToolDefinitions = ToolDefinition[];
export declare const ToolDefinitions: any;
export type ToolSchema = {
    s3: S3Configuration;
    inlinePayload?: never;
} | {
    s3?: never;
    inlinePayload: ToolDefinition[];
};
export declare const ToolSchema: any;
export interface McpLambdaTargetConfiguration {
    lambdaArn: string;
    toolSchema: ToolSchema;
}
export declare const McpLambdaTargetConfiguration: S.Schema<McpLambdaTargetConfiguration>;
export type McpToolSchemaConfiguration = {
    s3: S3Configuration;
    inlinePayload?: never;
} | {
    s3?: never;
    inlinePayload: string | redacted.Redacted<string>;
};
export declare const McpToolSchemaConfiguration: any;
export type ListingMode = "DEFAULT" | "DYNAMIC" | (string & {});
export declare const ListingMode: any;
export type TargetResourcePriority = number;
export interface McpServerTargetConfiguration {
    endpoint: string;
    mcpToolSchema?: McpToolSchemaConfiguration;
    listingMode?: ListingMode;
    resourcePriority?: number;
}
export declare const McpServerTargetConfiguration: S.Schema<McpServerTargetConfiguration>;
export type RestApiMethod = "GET" | "DELETE" | "HEAD" | "OPTIONS" | "PATCH" | "PUT" | "POST" | (string & {});
export declare const RestApiMethod: any;
export interface ApiGatewayToolOverride {
    name: string;
    description?: string;
    path: string;
    method: RestApiMethod;
}
export declare const ApiGatewayToolOverride: S.Schema<ApiGatewayToolOverride>;
export type ApiGatewayToolOverrides = ApiGatewayToolOverride[];
export declare const ApiGatewayToolOverrides: any;
export type RestApiMethods = RestApiMethod[];
export declare const RestApiMethods: any;
export interface ApiGatewayToolFilter {
    filterPath: string;
    methods: RestApiMethod[];
}
export declare const ApiGatewayToolFilter: S.Schema<ApiGatewayToolFilter>;
export type ApiGatewayToolFilters = ApiGatewayToolFilter[];
export declare const ApiGatewayToolFilters: any;
export interface ApiGatewayToolConfiguration {
    toolOverrides?: ApiGatewayToolOverride[];
    toolFilters: ApiGatewayToolFilter[];
}
export declare const ApiGatewayToolConfiguration: S.Schema<ApiGatewayToolConfiguration>;
export interface ApiGatewayTargetConfiguration {
    restApiId: string;
    stage: string;
    apiGatewayToolConfiguration: ApiGatewayToolConfiguration;
}
export declare const ApiGatewayTargetConfiguration: S.Schema<ApiGatewayTargetConfiguration>;
export type ConnectorId = string;
export type ConnectorVersion = string;
export interface ConnectorSource {
    connectorId: string;
    version?: string;
}
export declare const ConnectorSource: S.Schema<ConnectorSource>;
export type EnabledConnectors = string[];
export declare const EnabledConnectors: any;
export interface ConnectorParameterOverride {
    path: string;
    description?: string;
    visible?: boolean;
}
export declare const ConnectorParameterOverride: S.Schema<ConnectorParameterOverride>;
export type ConnectorParameterOverrides = ConnectorParameterOverride[];
export declare const ConnectorParameterOverrides: any;
export interface ConnectorConfiguration {
    name: string;
    description?: string;
    parameterValues?: any;
    parameterOverrides?: ConnectorParameterOverride[];
}
export declare const ConnectorConfiguration: S.Schema<ConnectorConfiguration>;
export type ConnectorConfigurations = ConnectorConfiguration[];
export declare const ConnectorConfigurations: any;
export interface ConnectorTargetConfiguration {
    source: ConnectorSource;
    enabled?: string[];
    configurations?: ConnectorConfiguration[];
}
export declare const ConnectorTargetConfiguration: S.Schema<ConnectorTargetConfiguration>;
export type McpTargetConfiguration = {
    openApiSchema: ApiSchemaConfiguration;
    smithyModel?: never;
    lambda?: never;
    mcpServer?: never;
    apiGateway?: never;
    connector?: never;
} | {
    openApiSchema?: never;
    smithyModel: ApiSchemaConfiguration;
    lambda?: never;
    mcpServer?: never;
    apiGateway?: never;
    connector?: never;
} | {
    openApiSchema?: never;
    smithyModel?: never;
    lambda: McpLambdaTargetConfiguration;
    mcpServer?: never;
    apiGateway?: never;
    connector?: never;
} | {
    openApiSchema?: never;
    smithyModel?: never;
    lambda?: never;
    mcpServer: McpServerTargetConfiguration;
    apiGateway?: never;
    connector?: never;
} | {
    openApiSchema?: never;
    smithyModel?: never;
    lambda?: never;
    mcpServer?: never;
    apiGateway: ApiGatewayTargetConfiguration;
    connector?: never;
} | {
    openApiSchema?: never;
    smithyModel?: never;
    lambda?: never;
    mcpServer?: never;
    apiGateway?: never;
    connector: ConnectorTargetConfiguration;
};
export declare const McpTargetConfiguration: any;
export type RuntimeArn = string;
export type RuntimeQualifier = string;
export interface HttpApiSchemaConfiguration {
    source: ApiSchemaConfiguration;
}
export declare const HttpApiSchemaConfiguration: S.Schema<HttpApiSchemaConfiguration>;
export interface RuntimeTargetConfiguration {
    arn: string;
    qualifier?: string;
    schema?: HttpApiSchemaConfiguration;
}
export declare const RuntimeTargetConfiguration: S.Schema<RuntimeTargetConfiguration>;
export type PassthroughEndpoint = string;
export type PassthroughProtocolType = "MCP" | "A2A" | "INFERENCE" | "CUSTOM" | (string & {});
export declare const PassthroughProtocolType: any;
export type StickinessTimeout = number;
export type CompositeIdentifierEntry = string;
export type CompositeIdentifierList = string[];
export declare const CompositeIdentifierList: any;
export interface StickinessConfiguration {
    identifier: string;
    timeout?: number;
    compositeIdentifier?: string[];
}
export declare const StickinessConfiguration: S.Schema<StickinessConfiguration>;
export type StaticQueryParameterName = string;
export type StaticQueryParameterValue = string | redacted.Redacted<string>;
export type StaticQueryParameters = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const StaticQueryParameters: any;
export type StaticQueryParameterConflictResolution = "CLIENT_OVERRIDE" | "STATIC_OVERRIDE" | (string & {});
export declare const StaticQueryParameterConflictResolution: any;
export interface PassthroughTargetConfiguration {
    endpoint: string;
    protocolType: PassthroughProtocolType;
    schema?: HttpApiSchemaConfiguration;
    stickinessConfiguration?: StickinessConfiguration;
    staticQueryParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    staticQueryParameterConflictResolution?: StaticQueryParameterConflictResolution;
}
export declare const PassthroughTargetConfiguration: S.Schema<PassthroughTargetConfiguration>;
export interface HttpConnectorSource {
    connectorId: string;
}
export declare const HttpConnectorSource: S.Schema<HttpConnectorSource>;
export type ConnectorParameterName = string;
export type ConnectorParameterValue = string;
export type HttpConnectorParameters = {
    [key: string]: string | undefined;
};
export declare const HttpConnectorParameters: any;
export interface HttpConnectorTargetConfiguration {
    source: HttpConnectorSource;
    parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const HttpConnectorTargetConfiguration: S.Schema<HttpConnectorTargetConfiguration>;
export type HttpTargetConfiguration = {
    agentcoreRuntime: RuntimeTargetConfiguration;
    passthrough?: never;
    connector?: never;
} | {
    agentcoreRuntime?: never;
    passthrough: PassthroughTargetConfiguration;
    connector?: never;
} | {
    agentcoreRuntime?: never;
    passthrough?: never;
    connector: HttpConnectorTargetConfiguration;
};
export declare const HttpTargetConfiguration: any;
export type InferenceConnectorId = string;
export interface InferenceConnectorSource {
    connectorId: string;
}
export declare const InferenceConnectorSource: S.Schema<InferenceConnectorSource>;
export interface InferenceConnectorTargetConfiguration {
    source: InferenceConnectorSource;
}
export declare const InferenceConnectorTargetConfiguration: S.Schema<InferenceConnectorTargetConfiguration>;
export interface ProviderPrefix {
    strip?: boolean;
    separator?: string;
}
export declare const ProviderPrefix: S.Schema<ProviderPrefix>;
export interface ModelMapping {
    providerPrefix?: ProviderPrefix;
}
export declare const ModelMapping: S.Schema<ModelMapping>;
export type InferenceOperationPath = string;
export type ModelPattern = string;
export interface ModelEntry {
    model: string;
}
export declare const ModelEntry: S.Schema<ModelEntry>;
export type ModelEntries = ModelEntry[];
export declare const ModelEntries: any;
export interface InferenceOperationConfiguration {
    path: string;
    providerPath?: string;
    models?: ModelEntry[];
}
export declare const InferenceOperationConfiguration: S.Schema<InferenceOperationConfiguration>;
export type InferenceOperationConfigurations = InferenceOperationConfiguration[];
export declare const InferenceOperationConfigurations: any;
export interface InferenceProviderTargetConfiguration {
    endpoint: string;
    modelMapping?: ModelMapping;
    operations?: InferenceOperationConfiguration[];
}
export declare const InferenceProviderTargetConfiguration: S.Schema<InferenceProviderTargetConfiguration>;
export type InferenceTargetConfiguration = {
    connector: InferenceConnectorTargetConfiguration;
    provider?: never;
} | {
    connector?: never;
    provider: InferenceProviderTargetConfiguration;
};
export declare const InferenceTargetConfiguration: any;
export type TargetConfiguration = {
    mcp: McpTargetConfiguration;
    http?: never;
    inference?: never;
} | {
    mcp?: never;
    http: HttpTargetConfiguration;
    inference?: never;
} | {
    mcp?: never;
    http?: never;
    inference: InferenceTargetConfiguration;
};
export declare const TargetConfiguration: any;
export type CredentialProviderType = "GATEWAY_IAM_ROLE" | "OAUTH" | "API_KEY" | "CALLER_IAM_CREDENTIALS" | "JWT_PASSTHROUGH" | (string & {});
export declare const CredentialProviderType: any;
export type OAuthCredentialProviderArn = string;
export type OAuthScope = string;
export type OAuthScopes = string[];
export declare const OAuthScopes: any;
export type OAuthCustomParametersKey = string;
export type OAuthCustomParametersValue = string | redacted.Redacted<string>;
export type OAuthCustomParameters = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const OAuthCustomParameters: any;
export type OAuthGrantType = "CLIENT_CREDENTIALS" | "AUTHORIZATION_CODE" | "TOKEN_EXCHANGE" | (string & {});
export declare const OAuthGrantType: any;
export type OAuthDefaultReturnUrl = string;
export interface OAuthCredentialProvider {
    providerArn: string;
    scopes: string[];
    customParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    grantType?: OAuthGrantType;
    defaultReturnUrl?: string;
}
export declare const OAuthCredentialProvider: S.Schema<OAuthCredentialProvider>;
export type ApiKeyCredentialProviderArn = string;
export type ApiKeyCredentialParameterName = string;
export type ApiKeyCredentialPrefix = string;
export type ApiKeyCredentialLocation = "HEADER" | "QUERY_PARAMETER" | (string & {});
export declare const ApiKeyCredentialLocation: any;
export interface GatewayApiKeyCredentialProvider {
    providerArn: string;
    credentialParameterName?: string;
    credentialPrefix?: string;
    credentialLocation?: ApiKeyCredentialLocation;
}
export declare const GatewayApiKeyCredentialProvider: S.Schema<GatewayApiKeyCredentialProvider>;
export interface IamCredentialProvider {
    service: string;
    region?: string;
}
export declare const IamCredentialProvider: S.Schema<IamCredentialProvider>;
export type CredentialProvider = {
    oauthCredentialProvider: OAuthCredentialProvider;
    apiKeyCredentialProvider?: never;
    iamCredentialProvider?: never;
} | {
    oauthCredentialProvider?: never;
    apiKeyCredentialProvider: GatewayApiKeyCredentialProvider;
    iamCredentialProvider?: never;
} | {
    oauthCredentialProvider?: never;
    apiKeyCredentialProvider?: never;
    iamCredentialProvider: IamCredentialProvider;
};
export declare const CredentialProvider: any;
export interface CredentialProviderConfiguration {
    credentialProviderType: CredentialProviderType;
    credentialProvider?: CredentialProvider;
}
export declare const CredentialProviderConfiguration: S.Schema<CredentialProviderConfiguration>;
export type CredentialProviderConfigurations = CredentialProviderConfiguration[];
export declare const CredentialProviderConfigurations: any;
export type HttpHeaderName = string;
export type AllowedRequestHeaders = string[];
export declare const AllowedRequestHeaders: any;
export type HttpQueryParameterName = string;
export type AllowedQueryParameters = string[];
export declare const AllowedQueryParameters: any;
export type AllowedResponseHeaders = string[];
export declare const AllowedResponseHeaders: any;
export interface MetadataConfiguration {
    allowedRequestHeaders?: string[];
    allowedQueryParameters?: string[];
    allowedResponseHeaders?: string[];
}
export declare const MetadataConfiguration: S.Schema<MetadataConfiguration>;
export interface CreateGatewayTargetRequest {
    gatewayIdentifier: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    clientToken?: string;
    targetConfiguration: TargetConfiguration;
    credentialProviderConfigurations?: CredentialProviderConfiguration[];
    metadataConfiguration?: MetadataConfiguration;
    privateEndpoint?: PrivateEndpoint;
}
export declare const CreateGatewayTargetRequest: S.Schema<CreateGatewayTargetRequest>;
export type TargetId = string;
export type TargetStatus = "CREATING" | "UPDATING" | "UPDATE_UNSUCCESSFUL" | "DELETING" | "READY" | "FAILED" | "SYNCHRONIZING" | "SYNCHRONIZE_UNSUCCESSFUL" | "CREATE_PENDING_AUTH" | "UPDATE_PENDING_AUTH" | "SYNCHRONIZE_PENDING_AUTH" | (string & {});
export declare const TargetStatus: any;
export type DomainName = string;
export type ResourceGatewayArn = string;
export type ResourceAssociationArn = string;
export interface ManagedResourceDetails {
    domain?: string;
    resourceGatewayArn?: string;
    resourceAssociationArn?: string;
}
export declare const ManagedResourceDetails: S.Schema<ManagedResourceDetails>;
export type PrivateEndpointManagedResources = ManagedResourceDetails[];
export declare const PrivateEndpointManagedResources: any;
export interface OAuth2AuthorizationData {
    authorizationUrl: string;
    userId?: string;
}
export declare const OAuth2AuthorizationData: S.Schema<OAuth2AuthorizationData>;
export type AuthorizationData = {
    oauth2: OAuth2AuthorizationData;
};
export declare const AuthorizationData: any;
export type TargetProtocolType = "MCP" | "HTTP" | (string & {});
export declare const TargetProtocolType: any;
export interface CreateGatewayTargetResponse {
    gatewayArn: string;
    targetId: string;
    createdAt: Date;
    updatedAt: Date;
    status: TargetStatus;
    statusReasons?: string[];
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    targetConfiguration: TargetConfiguration;
    credentialProviderConfigurations: CredentialProviderConfiguration[];
    lastSynchronizedAt?: Date;
    metadataConfiguration?: MetadataConfiguration;
    privateEndpoint?: PrivateEndpoint;
    privateEndpointManagedResources?: ManagedResourceDetails[];
    authorizationData?: AuthorizationData;
    protocolType?: TargetProtocolType;
}
export declare const CreateGatewayTargetResponse: S.Schema<CreateGatewayTargetResponse>;
export type HarnessName = string;
export interface HarnessAgentCoreRuntimeEnvironmentRequest {
    lifecycleConfiguration?: LifecycleConfiguration;
    networkConfiguration?: NetworkConfiguration;
    filesystemConfigurations?: FilesystemConfiguration[];
}
export declare const HarnessAgentCoreRuntimeEnvironmentRequest: S.Schema<HarnessAgentCoreRuntimeEnvironmentRequest>;
export type HarnessEnvironmentProviderRequest = {
    agentCoreRuntimeEnvironment: HarnessAgentCoreRuntimeEnvironmentRequest;
};
export declare const HarnessEnvironmentProviderRequest: any;
export type HarnessEnvironmentArtifact = {
    containerConfiguration: ContainerConfiguration;
};
export declare const HarnessEnvironmentArtifact: any;
export type MaxTokens = number;
export type Temperature = number;
export type TopP = number;
export type HarnessBedrockApiFormat = "converse_stream" | "responses" | "chat_completions" | (string & {});
export declare const HarnessBedrockApiFormat: any;
export interface HarnessBedrockModelConfig {
    modelId: string;
    maxTokens?: number;
    temperature?: number;
    topP?: number;
    apiFormat?: HarnessBedrockApiFormat;
    additionalParams?: any;
}
export declare const HarnessBedrockModelConfig: S.Schema<HarnessBedrockModelConfig>;
export type ApiKeyArn = string;
export type HarnessOpenAiApiFormat = "chat_completions" | "responses" | (string & {});
export declare const HarnessOpenAiApiFormat: any;
export interface HarnessOpenAiModelConfig {
    modelId: string;
    apiKeyArn: string;
    maxTokens?: number;
    temperature?: number;
    topP?: number;
    apiFormat?: HarnessOpenAiApiFormat;
    additionalParams?: any;
}
export declare const HarnessOpenAiModelConfig: S.Schema<HarnessOpenAiModelConfig>;
export type TopK = number;
export interface HarnessGeminiModelConfig {
    modelId: string;
    apiKeyArn: string;
    maxTokens?: number;
    temperature?: number;
    topP?: number;
    topK?: number;
    additionalParams?: any;
}
export declare const HarnessGeminiModelConfig: S.Schema<HarnessGeminiModelConfig>;
export type HarnessLiteLlmApiBase = string | redacted.Redacted<string>;
export interface HarnessLiteLlmModelConfig {
    modelId: string;
    apiKeyArn?: string;
    apiBase?: string | redacted.Redacted<string>;
    maxTokens?: number;
    temperature?: number;
    topP?: number;
    additionalParams?: any;
}
export declare const HarnessLiteLlmModelConfig: S.Schema<HarnessLiteLlmModelConfig>;
export type HarnessModelConfiguration = {
    bedrockModelConfig: HarnessBedrockModelConfig;
    openAiModelConfig?: never;
    geminiModelConfig?: never;
    liteLlmModelConfig?: never;
} | {
    bedrockModelConfig?: never;
    openAiModelConfig: HarnessOpenAiModelConfig;
    geminiModelConfig?: never;
    liteLlmModelConfig?: never;
} | {
    bedrockModelConfig?: never;
    openAiModelConfig?: never;
    geminiModelConfig: HarnessGeminiModelConfig;
    liteLlmModelConfig?: never;
} | {
    bedrockModelConfig?: never;
    openAiModelConfig?: never;
    geminiModelConfig?: never;
    liteLlmModelConfig: HarnessLiteLlmModelConfig;
};
export declare const HarnessModelConfiguration: any;
export type SensitiveText = string | redacted.Redacted<string>;
export type HarnessSystemContentBlock = {
    text: string | redacted.Redacted<string>;
};
export declare const HarnessSystemContentBlock: any;
export type HarnessSystemPrompt = HarnessSystemContentBlock[];
export declare const HarnessSystemPrompt: any;
export type HarnessToolType = "remote_mcp" | "agentcore_browser" | "agentcore_gateway" | "inline_function" | "agentcore_code_interpreter" | (string & {});
export declare const HarnessToolType: any;
export type HarnessToolName = string;
export type HarnessRemoteMcpUrl = string | redacted.Redacted<string>;
export type HttpHeaderKey = string;
export type HttpHeaderValue = string;
export type HttpHeadersMap = {
    [key: string]: string | undefined;
};
export declare const HttpHeadersMap: any;
export interface HarnessRemoteMcpConfig {
    url: string | redacted.Redacted<string>;
    headers?: {
        [key: string]: string | undefined;
    };
}
export declare const HarnessRemoteMcpConfig: S.Schema<HarnessRemoteMcpConfig>;
export type HarnessBrowserArn = string;
export interface HarnessAgentCoreBrowserConfig {
    browserArn?: string;
}
export declare const HarnessAgentCoreBrowserConfig: S.Schema<HarnessAgentCoreBrowserConfig>;
export type HarnessGatewayOutboundAuth = {
    awsIam: Record<string, never>;
    none?: never;
    oauth?: never;
} | {
    awsIam?: never;
    none: Record<string, never>;
    oauth?: never;
} | {
    awsIam?: never;
    none?: never;
    oauth: OAuthCredentialProvider;
};
export declare const HarnessGatewayOutboundAuth: any;
export interface HarnessAgentCoreGatewayConfig {
    gatewayArn: string;
    outboundAuth?: HarnessGatewayOutboundAuth;
}
export declare const HarnessAgentCoreGatewayConfig: S.Schema<HarnessAgentCoreGatewayConfig>;
export type HarnessInlineFunctionDescription = string | redacted.Redacted<string>;
export interface HarnessInlineFunctionConfig {
    description: string | redacted.Redacted<string>;
    inputSchema: any;
}
export declare const HarnessInlineFunctionConfig: S.Schema<HarnessInlineFunctionConfig>;
export type HarnessCodeInterpreterArn = string;
export interface HarnessAgentCoreCodeInterpreterConfig {
    codeInterpreterArn?: string;
}
export declare const HarnessAgentCoreCodeInterpreterConfig: S.Schema<HarnessAgentCoreCodeInterpreterConfig>;
export type HarnessToolConfiguration = {
    remoteMcp: HarnessRemoteMcpConfig;
    agentCoreBrowser?: never;
    agentCoreGateway?: never;
    inlineFunction?: never;
    agentCoreCodeInterpreter?: never;
} | {
    remoteMcp?: never;
    agentCoreBrowser: HarnessAgentCoreBrowserConfig;
    agentCoreGateway?: never;
    inlineFunction?: never;
    agentCoreCodeInterpreter?: never;
} | {
    remoteMcp?: never;
    agentCoreBrowser?: never;
    agentCoreGateway: HarnessAgentCoreGatewayConfig;
    inlineFunction?: never;
    agentCoreCodeInterpreter?: never;
} | {
    remoteMcp?: never;
    agentCoreBrowser?: never;
    agentCoreGateway?: never;
    inlineFunction: HarnessInlineFunctionConfig;
    agentCoreCodeInterpreter?: never;
} | {
    remoteMcp?: never;
    agentCoreBrowser?: never;
    agentCoreGateway?: never;
    inlineFunction?: never;
    agentCoreCodeInterpreter: HarnessAgentCoreCodeInterpreterConfig;
};
export declare const HarnessToolConfiguration: any;
export interface HarnessTool {
    type: HarnessToolType;
    name?: string;
    config?: HarnessToolConfiguration;
}
export declare const HarnessTool: S.Schema<HarnessTool>;
export type HarnessTools = HarnessTool[];
export declare const HarnessTools: any;
export type HarnessSkillPath = string;
export type HarnessSkillS3Uri = string;
export interface HarnessSkillS3Source {
    uri: string;
}
export declare const HarnessSkillS3Source: S.Schema<HarnessSkillS3Source>;
export type HarnessSkillGitUrl = string;
export interface HarnessSkillGitAuth {
    credentialArn: string;
    username?: string;
}
export declare const HarnessSkillGitAuth: S.Schema<HarnessSkillGitAuth>;
export interface HarnessSkillGitSource {
    url: string;
    path?: string;
    auth?: HarnessSkillGitAuth;
}
export declare const HarnessSkillGitSource: S.Schema<HarnessSkillGitSource>;
export type HarnessAwsSkillPath = string;
export type HarnessAwsSkillPaths = string[];
export declare const HarnessAwsSkillPaths: any;
export interface HarnessSkillAwsSkillsSource {
    paths?: string[];
}
export declare const HarnessSkillAwsSkillsSource: S.Schema<HarnessSkillAwsSkillsSource>;
export type HarnessSkill = {
    path: string;
    s3?: never;
    git?: never;
    awsSkills?: never;
} | {
    path?: never;
    s3: HarnessSkillS3Source;
    git?: never;
    awsSkills?: never;
} | {
    path?: never;
    s3?: never;
    git: HarnessSkillGitSource;
    awsSkills?: never;
} | {
    path?: never;
    s3?: never;
    git?: never;
    awsSkills: HarnessSkillAwsSkillsSource;
};
export declare const HarnessSkill: any;
export type HarnessSkills = HarnessSkill[];
export declare const HarnessSkills: any;
export type HarnessAllowedTool = string;
export type HarnessAllowedTools = string[];
export declare const HarnessAllowedTools: any;
export type MemoryArn = string;
export interface HarnessAgentCoreMemoryRetrievalConfig {
    topK?: number;
    relevanceScore?: number;
    strategyId?: string;
}
export declare const HarnessAgentCoreMemoryRetrievalConfig: S.Schema<HarnessAgentCoreMemoryRetrievalConfig>;
export type HarnessAgentCoreMemoryRetrievalConfigs = {
    [key: string]: HarnessAgentCoreMemoryRetrievalConfig | undefined;
};
export declare const HarnessAgentCoreMemoryRetrievalConfigs: any;
export interface HarnessAgentCoreMemoryConfiguration {
    arn: string;
    actorId?: string;
    messagesCount?: number;
    retrievalConfig?: {
        [key: string]: HarnessAgentCoreMemoryRetrievalConfig | undefined;
    };
}
export declare const HarnessAgentCoreMemoryConfiguration: S.Schema<HarnessAgentCoreMemoryConfiguration>;
export type HarnessManagedMemoryStrategyType = "SEMANTIC" | "SUMMARIZATION" | "USER_PREFERENCE" | "EPISODIC" | (string & {});
export declare const HarnessManagedMemoryStrategyType: any;
export type HarnessManagedMemoryStrategyList = HarnessManagedMemoryStrategyType[];
export declare const HarnessManagedMemoryStrategyList: any;
export interface HarnessManagedMemoryConfiguration {
    arn?: string;
    strategies?: HarnessManagedMemoryStrategyType[];
    eventExpiryDuration?: number;
    encryptionKeyArn?: string;
}
export declare const HarnessManagedMemoryConfiguration: S.Schema<HarnessManagedMemoryConfiguration>;
export interface HarnessDisabledMemoryConfiguration {
}
export declare const HarnessDisabledMemoryConfiguration: S.Schema<HarnessDisabledMemoryConfiguration>;
export type HarnessMemoryConfiguration = {
    agentCoreMemoryConfiguration: HarnessAgentCoreMemoryConfiguration;
    managedMemoryConfiguration?: never;
    disabled?: never;
} | {
    agentCoreMemoryConfiguration?: never;
    managedMemoryConfiguration: HarnessManagedMemoryConfiguration;
    disabled?: never;
} | {
    agentCoreMemoryConfiguration?: never;
    managedMemoryConfiguration?: never;
    disabled: HarnessDisabledMemoryConfiguration;
};
export declare const HarnessMemoryConfiguration: any;
export type HarnessTruncationStrategy = "sliding_window" | "summarization" | "none" | (string & {});
export declare const HarnessTruncationStrategy: any;
export interface HarnessSlidingWindowConfiguration {
    messagesCount?: number;
}
export declare const HarnessSlidingWindowConfiguration: S.Schema<HarnessSlidingWindowConfiguration>;
export interface HarnessSummarizationConfiguration {
    summaryRatio?: number;
    preserveRecentMessages?: number;
    summarizationSystemPrompt?: string;
}
export declare const HarnessSummarizationConfiguration: S.Schema<HarnessSummarizationConfiguration>;
export type HarnessTruncationStrategyConfiguration = {
    slidingWindow: HarnessSlidingWindowConfiguration;
    summarization?: never;
} | {
    slidingWindow?: never;
    summarization: HarnessSummarizationConfiguration;
};
export declare const HarnessTruncationStrategyConfiguration: any;
export interface HarnessTruncationConfiguration {
    strategy: HarnessTruncationStrategy;
    config?: HarnessTruncationStrategyConfiguration;
}
export declare const HarnessTruncationConfiguration: S.Schema<HarnessTruncationConfiguration>;
export interface CreateHarnessRequest {
    harnessName: string;
    clientToken?: string;
    executionRoleArn: string;
    environment?: HarnessEnvironmentProviderRequest;
    environmentArtifact?: HarnessEnvironmentArtifact;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    authorizerConfiguration?: AuthorizerConfiguration;
    model?: HarnessModelConfiguration;
    systemPrompt?: HarnessSystemContentBlock[];
    tools?: HarnessTool[];
    skills?: HarnessSkill[];
    allowedTools?: string[];
    memory?: HarnessMemoryConfiguration;
    truncation?: HarnessTruncationConfiguration;
    maxIterations?: number;
    maxTokens?: number;
    timeoutSeconds?: number;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateHarnessRequest: S.Schema<CreateHarnessRequest>;
export type HarnessId = string;
export type HarnessArn = string;
export type HarnessStatus = "CREATING" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "READY" | "DELETING" | "DELETE_FAILED" | (string & {});
export declare const HarnessStatus: any;
export type HarnessVersion = string;
export interface HarnessAgentCoreRuntimeEnvironment {
    agentRuntimeArn: string;
    agentRuntimeName: string;
    agentRuntimeId: string;
    lifecycleConfiguration: LifecycleConfiguration;
    networkConfiguration: NetworkConfiguration;
    filesystemConfigurations?: FilesystemConfiguration[];
}
export declare const HarnessAgentCoreRuntimeEnvironment: S.Schema<HarnessAgentCoreRuntimeEnvironment>;
export type HarnessEnvironmentProvider = {
    agentCoreRuntimeEnvironment: HarnessAgentCoreRuntimeEnvironment;
};
export declare const HarnessEnvironmentProvider: any;
export interface Harness {
    harnessId: string;
    harnessName: string;
    arn: string;
    status: HarnessStatus;
    harnessVersion?: string;
    executionRoleArn: string;
    createdAt: Date;
    updatedAt: Date;
    model: HarnessModelConfiguration;
    systemPrompt: HarnessSystemContentBlock[];
    tools: HarnessTool[];
    skills: HarnessSkill[];
    allowedTools: string[];
    truncation: HarnessTruncationConfiguration;
    environment: HarnessEnvironmentProvider;
    environmentArtifact?: HarnessEnvironmentArtifact;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    authorizerConfiguration?: AuthorizerConfiguration;
    memory?: HarnessMemoryConfiguration;
    maxIterations?: number;
    maxTokens?: number;
    timeoutSeconds?: number;
    failureReason?: string;
}
export declare const Harness: S.Schema<Harness>;
export interface CreateHarnessResponse {
    harness: Harness;
}
export declare const CreateHarnessResponse: S.Schema<CreateHarnessResponse>;
export type HarnessEndpointName = string;
export type HarnessEndpointDescription = string;
export interface CreateHarnessEndpointRequest {
    harnessId: string;
    endpointName: string;
    targetVersion?: string;
    description?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateHarnessEndpointRequest: S.Schema<CreateHarnessEndpointRequest>;
export type HarnessEndpointArn = string;
export type HarnessEndpointStatus = "CREATING" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "READY" | "DELETING" | "DELETE_FAILED" | (string & {});
export declare const HarnessEndpointStatus: any;
export interface HarnessEndpoint {
    harnessId: string;
    harnessName: string;
    endpointName: string;
    arn: string;
    status: HarnessEndpointStatus;
    createdAt: Date;
    updatedAt: Date;
    liveVersion?: string;
    targetVersion?: string;
    description?: string;
    failureReason?: string;
}
export declare const HarnessEndpoint: S.Schema<HarnessEndpoint>;
export interface CreateHarnessEndpointResponse {
    endpoint: HarnessEndpoint;
}
export declare const CreateHarnessEndpointResponse: S.Schema<CreateHarnessEndpointResponse>;
export type Name = string;
export type Arn = string;
export type Namespace = string;
export type NamespacesList = string[];
export declare const NamespacesList: any;
export type MetadataKey = string;
export type MetadataValueType = "STRING" | "STRINGLIST" | "NUMBER" | (string & {});
export declare const MetadataValueType: any;
export type ExtractionType = "LLM_INFERRED" | "STRICTLY_CONSISTENT" | (string & {});
export declare const ExtractionType: any;
export type LlmExtractionInstruction = string | redacted.Redacted<string>;
export type Definition = string | redacted.Redacted<string>;
export type AllowedStringValue = string;
export type AllowedStringValuesList = string[];
export declare const AllowedStringValuesList: any;
export interface StringValidation {
    allowedValues: string[];
}
export declare const StringValidation: S.Schema<StringValidation>;
export type AllowedStringListValue = string;
export type AllowedStringListValuesList = string[];
export declare const AllowedStringListValuesList: any;
export interface StringListValidation {
    allowedValues?: string[];
    maxItems?: number;
}
export declare const StringListValidation: S.Schema<StringListValidation>;
export interface NumberValidation {
    minValue?: number;
    maxValue?: number;
}
export declare const NumberValidation: S.Schema<NumberValidation>;
export type Validation = {
    stringValidation: StringValidation;
    stringListValidation?: never;
    numberValidation?: never;
} | {
    stringValidation?: never;
    stringListValidation: StringListValidation;
    numberValidation?: never;
} | {
    stringValidation?: never;
    stringListValidation?: never;
    numberValidation: NumberValidation;
};
export declare const Validation: any;
export interface LlmExtractionConfig {
    llmExtractionInstruction?: string | redacted.Redacted<string>;
    definition: string | redacted.Redacted<string>;
    validation?: Validation;
}
export declare const LlmExtractionConfig: S.Schema<LlmExtractionConfig>;
export type ExtractionConfig = {
    llmExtractionConfig: LlmExtractionConfig;
};
export declare const ExtractionConfig: any;
export interface MetadataSchemaEntry {
    key: string;
    type?: MetadataValueType;
    extractionType?: ExtractionType;
    extractionConfig?: ExtractionConfig;
}
export declare const MetadataSchemaEntry: S.Schema<MetadataSchemaEntry>;
export type MetadataSchemaList = MetadataSchemaEntry[];
export declare const MetadataSchemaList: any;
export interface MemoryRecordSchema {
    metadataSchema?: MetadataSchemaEntry[];
}
export declare const MemoryRecordSchema: S.Schema<MemoryRecordSchema>;
export interface SemanticMemoryStrategyInput {
    name: string;
    description?: string | redacted.Redacted<string>;
    namespaces?: string[];
    namespaceTemplates?: string[];
    memoryRecordSchema?: MemoryRecordSchema;
}
export declare const SemanticMemoryStrategyInput: S.Schema<SemanticMemoryStrategyInput>;
export interface SummaryMemoryStrategyInput {
    name: string;
    description?: string | redacted.Redacted<string>;
    namespaces?: string[];
    namespaceTemplates?: string[];
    memoryRecordSchema?: MemoryRecordSchema;
}
export declare const SummaryMemoryStrategyInput: S.Schema<SummaryMemoryStrategyInput>;
export interface UserPreferenceMemoryStrategyInput {
    name: string;
    description?: string | redacted.Redacted<string>;
    namespaces?: string[];
    namespaceTemplates?: string[];
    memoryRecordSchema?: MemoryRecordSchema;
}
export declare const UserPreferenceMemoryStrategyInput: S.Schema<UserPreferenceMemoryStrategyInput>;
export type Prompt = string | redacted.Redacted<string>;
export interface SemanticOverrideExtractionConfigurationInput {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const SemanticOverrideExtractionConfigurationInput: S.Schema<SemanticOverrideExtractionConfigurationInput>;
export interface SemanticOverrideConsolidationConfigurationInput {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const SemanticOverrideConsolidationConfigurationInput: S.Schema<SemanticOverrideConsolidationConfigurationInput>;
export interface SemanticOverrideConfigurationInput {
    extraction?: SemanticOverrideExtractionConfigurationInput;
    consolidation?: SemanticOverrideConsolidationConfigurationInput;
}
export declare const SemanticOverrideConfigurationInput: S.Schema<SemanticOverrideConfigurationInput>;
export interface SummaryOverrideConsolidationConfigurationInput {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const SummaryOverrideConsolidationConfigurationInput: S.Schema<SummaryOverrideConsolidationConfigurationInput>;
export interface SummaryOverrideConfigurationInput {
    consolidation?: SummaryOverrideConsolidationConfigurationInput;
}
export declare const SummaryOverrideConfigurationInput: S.Schema<SummaryOverrideConfigurationInput>;
export interface UserPreferenceOverrideExtractionConfigurationInput {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const UserPreferenceOverrideExtractionConfigurationInput: S.Schema<UserPreferenceOverrideExtractionConfigurationInput>;
export interface UserPreferenceOverrideConsolidationConfigurationInput {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const UserPreferenceOverrideConsolidationConfigurationInput: S.Schema<UserPreferenceOverrideConsolidationConfigurationInput>;
export interface UserPreferenceOverrideConfigurationInput {
    extraction?: UserPreferenceOverrideExtractionConfigurationInput;
    consolidation?: UserPreferenceOverrideConsolidationConfigurationInput;
}
export declare const UserPreferenceOverrideConfigurationInput: S.Schema<UserPreferenceOverrideConfigurationInput>;
export interface EpisodicOverrideExtractionConfigurationInput {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const EpisodicOverrideExtractionConfigurationInput: S.Schema<EpisodicOverrideExtractionConfigurationInput>;
export interface EpisodicOverrideConsolidationConfigurationInput {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const EpisodicOverrideConsolidationConfigurationInput: S.Schema<EpisodicOverrideConsolidationConfigurationInput>;
export interface EpisodicOverrideReflectionConfigurationInput {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
    namespaces?: string[];
    namespaceTemplates?: string[];
    memoryRecordSchema?: MemoryRecordSchema;
}
export declare const EpisodicOverrideReflectionConfigurationInput: S.Schema<EpisodicOverrideReflectionConfigurationInput>;
export interface EpisodicOverrideConfigurationInput {
    extraction?: EpisodicOverrideExtractionConfigurationInput;
    consolidation?: EpisodicOverrideConsolidationConfigurationInput;
    reflection?: EpisodicOverrideReflectionConfigurationInput;
}
export declare const EpisodicOverrideConfigurationInput: S.Schema<EpisodicOverrideConfigurationInput>;
export interface MessageBasedTriggerInput {
    messageCount?: number;
}
export declare const MessageBasedTriggerInput: S.Schema<MessageBasedTriggerInput>;
export interface TokenBasedTriggerInput {
    tokenCount?: number;
}
export declare const TokenBasedTriggerInput: S.Schema<TokenBasedTriggerInput>;
export interface TimeBasedTriggerInput {
    idleSessionTimeout?: number;
}
export declare const TimeBasedTriggerInput: S.Schema<TimeBasedTriggerInput>;
export type TriggerConditionInput = {
    messageBasedTrigger: MessageBasedTriggerInput;
    tokenBasedTrigger?: never;
    timeBasedTrigger?: never;
} | {
    messageBasedTrigger?: never;
    tokenBasedTrigger: TokenBasedTriggerInput;
    timeBasedTrigger?: never;
} | {
    messageBasedTrigger?: never;
    tokenBasedTrigger?: never;
    timeBasedTrigger: TimeBasedTriggerInput;
};
export declare const TriggerConditionInput: any;
export type TriggerConditionInputList = TriggerConditionInput[];
export declare const TriggerConditionInputList: any;
export interface InvocationConfigurationInput {
    topicArn: string;
    payloadDeliveryBucketName: string;
}
export declare const InvocationConfigurationInput: S.Schema<InvocationConfigurationInput>;
export interface SelfManagedConfigurationInput {
    triggerConditions?: TriggerConditionInput[];
    invocationConfiguration: InvocationConfigurationInput;
    historicalContextWindowSize?: number;
}
export declare const SelfManagedConfigurationInput: S.Schema<SelfManagedConfigurationInput>;
export type CustomConfigurationInput = {
    semanticOverride: SemanticOverrideConfigurationInput;
    summaryOverride?: never;
    userPreferenceOverride?: never;
    episodicOverride?: never;
    selfManagedConfiguration?: never;
} | {
    semanticOverride?: never;
    summaryOverride: SummaryOverrideConfigurationInput;
    userPreferenceOverride?: never;
    episodicOverride?: never;
    selfManagedConfiguration?: never;
} | {
    semanticOverride?: never;
    summaryOverride?: never;
    userPreferenceOverride: UserPreferenceOverrideConfigurationInput;
    episodicOverride?: never;
    selfManagedConfiguration?: never;
} | {
    semanticOverride?: never;
    summaryOverride?: never;
    userPreferenceOverride?: never;
    episodicOverride: EpisodicOverrideConfigurationInput;
    selfManagedConfiguration?: never;
} | {
    semanticOverride?: never;
    summaryOverride?: never;
    userPreferenceOverride?: never;
    episodicOverride?: never;
    selfManagedConfiguration: SelfManagedConfigurationInput;
};
export declare const CustomConfigurationInput: any;
export interface CustomMemoryStrategyInput {
    name: string;
    description?: string | redacted.Redacted<string>;
    namespaces?: string[];
    namespaceTemplates?: string[];
    configuration?: CustomConfigurationInput;
    memoryRecordSchema?: MemoryRecordSchema;
}
export declare const CustomMemoryStrategyInput: S.Schema<CustomMemoryStrategyInput>;
export interface EpisodicReflectionConfigurationInput {
    namespaces?: string[];
    namespaceTemplates?: string[];
    memoryRecordSchema?: MemoryRecordSchema;
}
export declare const EpisodicReflectionConfigurationInput: S.Schema<EpisodicReflectionConfigurationInput>;
export interface EpisodicMemoryStrategyInput {
    name: string;
    description?: string | redacted.Redacted<string>;
    namespaces?: string[];
    namespaceTemplates?: string[];
    reflectionConfiguration?: EpisodicReflectionConfigurationInput;
    memoryRecordSchema?: MemoryRecordSchema;
}
export declare const EpisodicMemoryStrategyInput: S.Schema<EpisodicMemoryStrategyInput>;
export type MemoryStrategyInput = {
    semanticMemoryStrategy: SemanticMemoryStrategyInput;
    summaryMemoryStrategy?: never;
    userPreferenceMemoryStrategy?: never;
    customMemoryStrategy?: never;
    episodicMemoryStrategy?: never;
} | {
    semanticMemoryStrategy?: never;
    summaryMemoryStrategy: SummaryMemoryStrategyInput;
    userPreferenceMemoryStrategy?: never;
    customMemoryStrategy?: never;
    episodicMemoryStrategy?: never;
} | {
    semanticMemoryStrategy?: never;
    summaryMemoryStrategy?: never;
    userPreferenceMemoryStrategy: UserPreferenceMemoryStrategyInput;
    customMemoryStrategy?: never;
    episodicMemoryStrategy?: never;
} | {
    semanticMemoryStrategy?: never;
    summaryMemoryStrategy?: never;
    userPreferenceMemoryStrategy?: never;
    customMemoryStrategy: CustomMemoryStrategyInput;
    episodicMemoryStrategy?: never;
} | {
    semanticMemoryStrategy?: never;
    summaryMemoryStrategy?: never;
    userPreferenceMemoryStrategy?: never;
    customMemoryStrategy?: never;
    episodicMemoryStrategy: EpisodicMemoryStrategyInput;
};
export declare const MemoryStrategyInput: any;
export type MemoryStrategyInputList = MemoryStrategyInput[];
export declare const MemoryStrategyInputList: any;
export interface IndexedKey {
    key: string;
    type: MetadataValueType;
}
export declare const IndexedKey: S.Schema<IndexedKey>;
export type IndexedKeysList = IndexedKey[];
export declare const IndexedKeysList: any;
export type NamespaceVariableKey = string;
export type NamespaceAllowedValue = string;
export type NamespaceAllowedValuesList = string[];
export declare const NamespaceAllowedValuesList: any;
export type NamespaceRegexPattern = string;
export interface NamespaceKeyValidation {
    allowedValues?: string[];
    regexPattern?: string;
}
export declare const NamespaceKeyValidation: S.Schema<NamespaceKeyValidation>;
export interface NamespaceKeyEntry {
    key: string;
    validation?: NamespaceKeyValidation;
}
export declare const NamespaceKeyEntry: S.Schema<NamespaceKeyEntry>;
export type NamespaceKeysList = NamespaceKeyEntry[];
export declare const NamespaceKeysList: any;
export type ContentType = "MEMORY_RECORDS" | (string & {});
export declare const ContentType: any;
export type ContentLevel = "METADATA_ONLY" | "FULL_CONTENT" | (string & {});
export declare const ContentLevel: any;
export interface ContentConfiguration {
    type: ContentType;
    level?: ContentLevel;
}
export declare const ContentConfiguration: S.Schema<ContentConfiguration>;
export type ContentConfigurationList = ContentConfiguration[];
export declare const ContentConfigurationList: any;
export interface KinesisResource {
    dataStreamArn: string;
    contentConfigurations: ContentConfiguration[];
}
export declare const KinesisResource: S.Schema<KinesisResource>;
export type StreamDeliveryResource = {
    kinesis: KinesisResource;
};
export declare const StreamDeliveryResource: any;
export type StreamDeliveryResourcesList = StreamDeliveryResource[];
export declare const StreamDeliveryResourcesList: any;
export interface StreamDeliveryResources {
    resources: StreamDeliveryResource[];
}
export declare const StreamDeliveryResources: S.Schema<StreamDeliveryResources>;
export interface CreateMemoryInput {
    clientToken?: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    encryptionKeyArn?: string;
    memoryExecutionRoleArn?: string;
    eventExpiryDuration: number;
    memoryStrategies?: MemoryStrategyInput[];
    indexedKeys?: IndexedKey[];
    namespaceKeys?: NamespaceKeyEntry[];
    streamDeliveryResources?: StreamDeliveryResources;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateMemoryInput: S.Schema<CreateMemoryInput>;
export type MemoryId = string;
export type MemoryStatus = "CREATING" | "ACTIVE" | "FAILED" | "DELETING" | "UPDATING" | (string & {});
export declare const MemoryStatus: any;
export type MemoryStrategyId = string;
export type OverrideType = "SEMANTIC_OVERRIDE" | "SUMMARY_OVERRIDE" | "USER_PREFERENCE_OVERRIDE" | "SELF_MANAGED" | "EPISODIC_OVERRIDE" | (string & {});
export declare const OverrideType: any;
export interface SemanticExtractionOverride {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const SemanticExtractionOverride: S.Schema<SemanticExtractionOverride>;
export interface UserPreferenceExtractionOverride {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const UserPreferenceExtractionOverride: S.Schema<UserPreferenceExtractionOverride>;
export interface EpisodicExtractionOverride {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const EpisodicExtractionOverride: S.Schema<EpisodicExtractionOverride>;
export type CustomExtractionConfiguration = {
    semanticExtractionOverride: SemanticExtractionOverride;
    userPreferenceExtractionOverride?: never;
    episodicExtractionOverride?: never;
} | {
    semanticExtractionOverride?: never;
    userPreferenceExtractionOverride: UserPreferenceExtractionOverride;
    episodicExtractionOverride?: never;
} | {
    semanticExtractionOverride?: never;
    userPreferenceExtractionOverride?: never;
    episodicExtractionOverride: EpisodicExtractionOverride;
};
export declare const CustomExtractionConfiguration: any;
export type ExtractionConfiguration = {
    customExtractionConfiguration: CustomExtractionConfiguration;
};
export declare const ExtractionConfiguration: any;
export interface SemanticConsolidationOverride {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const SemanticConsolidationOverride: S.Schema<SemanticConsolidationOverride>;
export interface SummaryConsolidationOverride {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const SummaryConsolidationOverride: S.Schema<SummaryConsolidationOverride>;
export interface UserPreferenceConsolidationOverride {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const UserPreferenceConsolidationOverride: S.Schema<UserPreferenceConsolidationOverride>;
export interface EpisodicConsolidationOverride {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
}
export declare const EpisodicConsolidationOverride: S.Schema<EpisodicConsolidationOverride>;
export type CustomConsolidationConfiguration = {
    semanticConsolidationOverride: SemanticConsolidationOverride;
    summaryConsolidationOverride?: never;
    userPreferenceConsolidationOverride?: never;
    episodicConsolidationOverride?: never;
} | {
    semanticConsolidationOverride?: never;
    summaryConsolidationOverride: SummaryConsolidationOverride;
    userPreferenceConsolidationOverride?: never;
    episodicConsolidationOverride?: never;
} | {
    semanticConsolidationOverride?: never;
    summaryConsolidationOverride?: never;
    userPreferenceConsolidationOverride: UserPreferenceConsolidationOverride;
    episodicConsolidationOverride?: never;
} | {
    semanticConsolidationOverride?: never;
    summaryConsolidationOverride?: never;
    userPreferenceConsolidationOverride?: never;
    episodicConsolidationOverride: EpisodicConsolidationOverride;
};
export declare const CustomConsolidationConfiguration: any;
export type ConsolidationConfiguration = {
    customConsolidationConfiguration: CustomConsolidationConfiguration;
};
export declare const ConsolidationConfiguration: any;
export interface EpisodicReflectionOverride {
    appendToPrompt: string | redacted.Redacted<string>;
    modelId: string;
    namespaces?: string[];
    namespaceTemplates?: string[];
    memoryRecordSchema?: MemoryRecordSchema;
}
export declare const EpisodicReflectionOverride: S.Schema<EpisodicReflectionOverride>;
export type CustomReflectionConfiguration = {
    episodicReflectionOverride: EpisodicReflectionOverride;
};
export declare const CustomReflectionConfiguration: any;
export interface EpisodicReflectionConfiguration {
    namespaces?: string[];
    namespaceTemplates?: string[];
    memoryRecordSchema?: MemoryRecordSchema;
}
export declare const EpisodicReflectionConfiguration: S.Schema<EpisodicReflectionConfiguration>;
export type ReflectionConfiguration = {
    customReflectionConfiguration: CustomReflectionConfiguration;
    episodicReflectionConfiguration?: never;
} | {
    customReflectionConfiguration?: never;
    episodicReflectionConfiguration: EpisodicReflectionConfiguration;
};
export declare const ReflectionConfiguration: any;
export interface MessageBasedTrigger {
    messageCount?: number;
}
export declare const MessageBasedTrigger: S.Schema<MessageBasedTrigger>;
export interface TokenBasedTrigger {
    tokenCount?: number;
}
export declare const TokenBasedTrigger: S.Schema<TokenBasedTrigger>;
export interface TimeBasedTrigger {
    idleSessionTimeout?: number;
}
export declare const TimeBasedTrigger: S.Schema<TimeBasedTrigger>;
export type TriggerCondition = {
    messageBasedTrigger: MessageBasedTrigger;
    tokenBasedTrigger?: never;
    timeBasedTrigger?: never;
} | {
    messageBasedTrigger?: never;
    tokenBasedTrigger: TokenBasedTrigger;
    timeBasedTrigger?: never;
} | {
    messageBasedTrigger?: never;
    tokenBasedTrigger?: never;
    timeBasedTrigger: TimeBasedTrigger;
};
export declare const TriggerCondition: any;
export type TriggerConditionsList = TriggerCondition[];
export declare const TriggerConditionsList: any;
export interface InvocationConfiguration {
    topicArn: string;
    payloadDeliveryBucketName: string;
}
export declare const InvocationConfiguration: S.Schema<InvocationConfiguration>;
export interface SelfManagedConfiguration {
    triggerConditions: TriggerCondition[];
    invocationConfiguration: InvocationConfiguration;
    historicalContextWindowSize: number;
}
export declare const SelfManagedConfiguration: S.Schema<SelfManagedConfiguration>;
export interface StrategyConfiguration {
    type?: OverrideType;
    extraction?: ExtractionConfiguration;
    consolidation?: ConsolidationConfiguration;
    reflection?: ReflectionConfiguration;
    selfManagedConfiguration?: SelfManagedConfiguration;
}
export declare const StrategyConfiguration: S.Schema<StrategyConfiguration>;
export type MemoryStrategyType = "SEMANTIC" | "SUMMARIZATION" | "USER_PREFERENCE" | "CUSTOM" | "EPISODIC" | (string & {});
export declare const MemoryStrategyType: any;
export type MemoryStrategyStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export declare const MemoryStrategyStatus: any;
export interface MemoryStrategy {
    strategyId: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    configuration?: StrategyConfiguration;
    type: MemoryStrategyType;
    namespaces: string[];
    namespaceTemplates: string[];
    createdAt?: Date;
    updatedAt?: Date;
    status?: MemoryStrategyStatus;
    memoryRecordSchema?: MemoryRecordSchema;
}
export declare const MemoryStrategy: S.Schema<MemoryStrategy>;
export type MemoryStrategyList = MemoryStrategy[];
export declare const MemoryStrategyList: any;
export interface Memory {
    arn: string;
    id: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    encryptionKeyArn?: string;
    memoryExecutionRoleArn?: string;
    eventExpiryDuration: number;
    status: MemoryStatus;
    failureReason?: string;
    createdAt: Date;
    updatedAt: Date;
    strategies?: MemoryStrategy[];
    indexedKeys?: IndexedKey[];
    namespaceKeys?: NamespaceKeyEntry[];
    streamDeliveryResources?: StreamDeliveryResources;
    managedByResourceArn?: string;
}
export declare const Memory: S.Schema<Memory>;
export interface CreateMemoryOutput {
    memory?: Memory;
}
export declare const CreateMemoryOutput: S.Schema<CreateMemoryOutput>;
export type CredentialProviderVendorType = "GoogleOauth2" | "GithubOauth2" | "SlackOauth2" | "SalesforceOauth2" | "MicrosoftOauth2" | "CustomOauth2" | "AtlassianOauth2" | "LinkedinOauth2" | "XOauth2" | "OktaOauth2" | "OneLoginOauth2" | "PingOneOauth2" | "FacebookOauth2" | "YandexOauth2" | "RedditOauth2" | "ZoomOauth2" | "TwitchOauth2" | "SpotifyOauth2" | "DropboxOauth2" | "NotionOauth2" | "HubspotOauth2" | "CyberArkOauth2" | "FusionAuthOauth2" | "Auth0Oauth2" | "CognitoOauth2" | (string & {});
export declare const CredentialProviderVendorType: any;
export type DiscoveryUrlType = string;
export type IssuerUrlType = string;
export type AuthorizationEndpointType = string;
export type TokenEndpointType = string;
export type ResponseType = string;
export type ResponseListType = string[];
export declare const ResponseListType: any;
export type TokenAuthMethod = string;
export type TokenEndpointAuthMethodsType = string[];
export declare const TokenEndpointAuthMethodsType: any;
export interface Oauth2AuthorizationServerMetadata {
    issuer: string;
    authorizationEndpoint: string;
    tokenEndpoint: string;
    responseTypes?: string[];
    tokenEndpointAuthMethods?: string[];
}
export declare const Oauth2AuthorizationServerMetadata: S.Schema<Oauth2AuthorizationServerMetadata>;
export type Oauth2Discovery = {
    discoveryUrl: string;
    authorizationServerMetadata?: never;
} | {
    discoveryUrl?: never;
    authorizationServerMetadata: Oauth2AuthorizationServerMetadata;
};
export declare const Oauth2Discovery: any;
export type DefaultClientIdType = string;
export type DefaultClientSecretType = string | redacted.Redacted<string>;
export type OnBehalfOfTokenExchangeGrantTypeType = "TOKEN_EXCHANGE" | "JWT_AUTHORIZATION_GRANT" | (string & {});
export declare const OnBehalfOfTokenExchangeGrantTypeType: any;
export type ActorTokenContentType = "NONE" | "M2M" | "AWS_IAM_ID_TOKEN_JWT" | (string & {});
export declare const ActorTokenContentType: any;
export type ScopeType = string;
export type ScopesListType = string[];
export declare const ScopesListType: any;
export interface TokenExchangeGrantTypeConfigType {
    actorTokenContent: ActorTokenContentType;
    actorTokenScopes?: string[];
}
export declare const TokenExchangeGrantTypeConfigType: S.Schema<TokenExchangeGrantTypeConfigType>;
export interface OnBehalfOfTokenExchangeConfigType {
    grantType: OnBehalfOfTokenExchangeGrantTypeType;
    tokenExchangeGrantTypeConfig?: TokenExchangeGrantTypeConfigType;
}
export declare const OnBehalfOfTokenExchangeConfigType: S.Schema<OnBehalfOfTokenExchangeConfigType>;
export type ClientAuthenticationMethodType = "CLIENT_SECRET_BASIC" | "CLIENT_SECRET_POST" | "AWS_IAM_ID_TOKEN_JWT" | "PRIVATE_KEY_JWT" | (string & {});
export declare const ClientAuthenticationMethodType: any;
export interface KmsKeySourceType {
    kmsKeyArn: string;
}
export declare const KmsKeySourceType: S.Schema<KmsKeySourceType>;
export type PrivateKeySource = {
    kmsKeySource: KmsKeySourceType;
};
export declare const PrivateKeySource: any;
export type SigningAlgorithm = "RS256" | "PS256" | "ES256" | (string & {});
export declare const SigningAlgorithm: any;
export type AdditionalClaimName = string;
export type AdditionalClaimValue = string | redacted.Redacted<string>;
export type AdditionalClaims = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const AdditionalClaims: any;
export interface PrivateKeyJwtConfig {
    privateKeySource?: PrivateKeySource;
    signingAlgorithm?: SigningAlgorithm;
    additionalHeaderClaims?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    additionalPayloadClaims?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export declare const PrivateKeyJwtConfig: S.Schema<PrivateKeyJwtConfig>;
export interface CustomOauth2ProviderConfigInput {
    oauthDiscovery: Oauth2Discovery;
    clientId?: string;
    clientSecret?: string | redacted.Redacted<string>;
    clientSecretConfig?: SecretReference;
    clientSecretSource?: SecretSourceType;
    onBehalfOfTokenExchangeConfig?: OnBehalfOfTokenExchangeConfigType;
    clientAuthenticationMethod?: ClientAuthenticationMethodType;
    privateKeyJwtConfig?: PrivateKeyJwtConfig;
    privateEndpoint?: PrivateEndpoint;
    privateEndpointOverrides?: PrivateEndpointOverride[];
}
export declare const CustomOauth2ProviderConfigInput: S.Schema<CustomOauth2ProviderConfigInput>;
export type ClientIdType = string;
export interface GoogleOauth2ProviderConfigInput {
    clientId: string;
    clientSecret?: string | redacted.Redacted<string>;
    clientSecretConfig?: SecretReference;
    clientSecretSource?: SecretSourceType;
}
export declare const GoogleOauth2ProviderConfigInput: S.Schema<GoogleOauth2ProviderConfigInput>;
export interface GithubOauth2ProviderConfigInput {
    clientId: string;
    clientSecret?: string | redacted.Redacted<string>;
    clientSecretConfig?: SecretReference;
    clientSecretSource?: SecretSourceType;
}
export declare const GithubOauth2ProviderConfigInput: S.Schema<GithubOauth2ProviderConfigInput>;
export interface SlackOauth2ProviderConfigInput {
    clientId: string;
    clientSecret?: string | redacted.Redacted<string>;
    clientSecretConfig?: SecretReference;
    clientSecretSource?: SecretSourceType;
}
export declare const SlackOauth2ProviderConfigInput: S.Schema<SlackOauth2ProviderConfigInput>;
export interface SalesforceOauth2ProviderConfigInput {
    clientId: string;
    clientSecret?: string | redacted.Redacted<string>;
    clientSecretConfig?: SecretReference;
    clientSecretSource?: SecretSourceType;
}
export declare const SalesforceOauth2ProviderConfigInput: S.Schema<SalesforceOauth2ProviderConfigInput>;
export type TenantIdType = string;
export interface MicrosoftOauth2ProviderConfigInput {
    clientId: string;
    clientSecret?: string | redacted.Redacted<string>;
    clientSecretConfig?: SecretReference;
    clientSecretSource?: SecretSourceType;
    tenantId?: string;
}
export declare const MicrosoftOauth2ProviderConfigInput: S.Schema<MicrosoftOauth2ProviderConfigInput>;
export interface AtlassianOauth2ProviderConfigInput {
    clientId: string;
    clientSecret?: string | redacted.Redacted<string>;
    clientSecretConfig?: SecretReference;
    clientSecretSource?: SecretSourceType;
}
export declare const AtlassianOauth2ProviderConfigInput: S.Schema<AtlassianOauth2ProviderConfigInput>;
export interface LinkedinOauth2ProviderConfigInput {
    clientId: string;
    clientSecret?: string | redacted.Redacted<string>;
    clientSecretConfig?: SecretReference;
    clientSecretSource?: SecretSourceType;
}
export declare const LinkedinOauth2ProviderConfigInput: S.Schema<LinkedinOauth2ProviderConfigInput>;
export interface IncludedOauth2ProviderConfigInput {
    clientId: string;
    clientSecret?: string | redacted.Redacted<string>;
    clientSecretConfig?: SecretReference;
    clientSecretSource?: SecretSourceType;
    issuer?: string;
    authorizationEndpoint?: string;
    tokenEndpoint?: string;
}
export declare const IncludedOauth2ProviderConfigInput: S.Schema<IncludedOauth2ProviderConfigInput>;
export type Oauth2ProviderConfigInput = {
    customOauth2ProviderConfig: CustomOauth2ProviderConfigInput;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig: GoogleOauth2ProviderConfigInput;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig: GithubOauth2ProviderConfigInput;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig: SlackOauth2ProviderConfigInput;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig: SalesforceOauth2ProviderConfigInput;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig: MicrosoftOauth2ProviderConfigInput;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig: AtlassianOauth2ProviderConfigInput;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig: LinkedinOauth2ProviderConfigInput;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig: IncludedOauth2ProviderConfigInput;
};
export declare const Oauth2ProviderConfigInput: any;
export interface CreateOauth2CredentialProviderRequest {
    name: string;
    credentialProviderVendor: CredentialProviderVendorType;
    oauth2ProviderConfigInput: Oauth2ProviderConfigInput;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateOauth2CredentialProviderRequest: S.Schema<CreateOauth2CredentialProviderRequest>;
export type CredentialProviderArnType = string;
export interface CustomOauth2ProviderConfigOutput {
    oauthDiscovery: Oauth2Discovery;
    clientId?: string;
    onBehalfOfTokenExchangeConfig?: OnBehalfOfTokenExchangeConfigType;
    clientAuthenticationMethod?: ClientAuthenticationMethodType;
    privateEndpoint?: PrivateEndpoint;
    privateEndpointOverrides?: PrivateEndpointOverride[];
    privateKeyJwtConfig?: PrivateKeyJwtConfig;
}
export declare const CustomOauth2ProviderConfigOutput: S.Schema<CustomOauth2ProviderConfigOutput>;
export interface GoogleOauth2ProviderConfigOutput {
    oauthDiscovery: Oauth2Discovery;
    clientId?: string;
}
export declare const GoogleOauth2ProviderConfigOutput: S.Schema<GoogleOauth2ProviderConfigOutput>;
export interface GithubOauth2ProviderConfigOutput {
    oauthDiscovery: Oauth2Discovery;
    clientId?: string;
}
export declare const GithubOauth2ProviderConfigOutput: S.Schema<GithubOauth2ProviderConfigOutput>;
export interface SlackOauth2ProviderConfigOutput {
    oauthDiscovery: Oauth2Discovery;
    clientId?: string;
}
export declare const SlackOauth2ProviderConfigOutput: S.Schema<SlackOauth2ProviderConfigOutput>;
export interface SalesforceOauth2ProviderConfigOutput {
    oauthDiscovery: Oauth2Discovery;
    clientId?: string;
}
export declare const SalesforceOauth2ProviderConfigOutput: S.Schema<SalesforceOauth2ProviderConfigOutput>;
export interface MicrosoftOauth2ProviderConfigOutput {
    oauthDiscovery: Oauth2Discovery;
    clientId?: string;
}
export declare const MicrosoftOauth2ProviderConfigOutput: S.Schema<MicrosoftOauth2ProviderConfigOutput>;
export interface AtlassianOauth2ProviderConfigOutput {
    oauthDiscovery: Oauth2Discovery;
    clientId?: string;
}
export declare const AtlassianOauth2ProviderConfigOutput: S.Schema<AtlassianOauth2ProviderConfigOutput>;
export interface LinkedinOauth2ProviderConfigOutput {
    oauthDiscovery: Oauth2Discovery;
    clientId?: string;
}
export declare const LinkedinOauth2ProviderConfigOutput: S.Schema<LinkedinOauth2ProviderConfigOutput>;
export interface IncludedOauth2ProviderConfigOutput {
    oauthDiscovery: Oauth2Discovery;
    clientId?: string;
}
export declare const IncludedOauth2ProviderConfigOutput: S.Schema<IncludedOauth2ProviderConfigOutput>;
export type Oauth2ProviderConfigOutput = {
    customOauth2ProviderConfig: CustomOauth2ProviderConfigOutput;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig: GoogleOauth2ProviderConfigOutput;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig: GithubOauth2ProviderConfigOutput;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig: SlackOauth2ProviderConfigOutput;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig: SalesforceOauth2ProviderConfigOutput;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig: MicrosoftOauth2ProviderConfigOutput;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig: AtlassianOauth2ProviderConfigOutput;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig: LinkedinOauth2ProviderConfigOutput;
    includedOauth2ProviderConfig?: never;
} | {
    customOauth2ProviderConfig?: never;
    googleOauth2ProviderConfig?: never;
    githubOauth2ProviderConfig?: never;
    slackOauth2ProviderConfig?: never;
    salesforceOauth2ProviderConfig?: never;
    microsoftOauth2ProviderConfig?: never;
    atlassianOauth2ProviderConfig?: never;
    linkedinOauth2ProviderConfig?: never;
    includedOauth2ProviderConfig: IncludedOauth2ProviderConfigOutput;
};
export declare const Oauth2ProviderConfigOutput: any;
export type Status = "CREATING" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "READY" | "DELETING" | "DELETE_FAILED" | (string & {});
export declare const Status: any;
export interface CreateOauth2CredentialProviderResponse {
    clientSecretArn: Secret;
    clientSecretJsonKey?: string;
    clientSecretSource?: SecretSourceType;
    name: string;
    credentialProviderArn: string;
    callbackUrl?: string;
    oauth2ProviderConfigOutput?: Oauth2ProviderConfigOutput;
    status?: Status;
}
export declare const CreateOauth2CredentialProviderResponse: S.Schema<CreateOauth2CredentialProviderResponse>;
export type EvaluationConfigName = string;
export type EvaluationConfigDescription = string | redacted.Redacted<string>;
export type SamplingPercentage = number;
export interface SamplingConfig {
    samplingPercentage: number;
}
export declare const SamplingConfig: S.Schema<SamplingConfig>;
export type FilterOperator = "Equals" | "NotEquals" | "GreaterThan" | "LessThan" | "GreaterThanOrEqual" | "LessThanOrEqual" | "Contains" | "NotContains" | (string & {});
export declare const FilterOperator: any;
export type FilterValue = {
    stringValue: string;
    doubleValue?: never;
    booleanValue?: never;
} | {
    stringValue?: never;
    doubleValue: number;
    booleanValue?: never;
} | {
    stringValue?: never;
    doubleValue?: never;
    booleanValue: boolean;
};
export declare const FilterValue: any;
export interface Filter {
    key: string;
    operator: FilterOperator;
    value: FilterValue;
}
export declare const Filter: S.Schema<Filter>;
export type FilterList = Filter[];
export declare const FilterList: any;
export interface SessionConfig {
    sessionTimeoutMinutes: number;
}
export declare const SessionConfig: S.Schema<SessionConfig>;
export interface Rule {
    samplingConfig: SamplingConfig;
    filters?: Filter[];
    sessionConfig?: SessionConfig;
}
export declare const Rule: S.Schema<Rule>;
export type LogGroupName = string;
export type LogGroupNamesList = string[];
export declare const LogGroupNamesList: any;
export type ServiceName = string;
export type ServiceNamesList = string[];
export declare const ServiceNamesList: any;
export interface CloudWatchLogsInputConfig {
    logGroupNames: string[];
    serviceNames: string[];
}
export declare const CloudWatchLogsInputConfig: S.Schema<CloudWatchLogsInputConfig>;
export type DataSourceConfig = {
    cloudWatchLogs: CloudWatchLogsInputConfig;
};
export declare const DataSourceConfig: any;
export type EvaluatorReference = {
    evaluatorId: string;
};
export declare const EvaluatorReference: any;
export type EvaluatorList = EvaluatorReference[];
export declare const EvaluatorList: any;
export type InsightId = string;
export interface Insight {
    insightId: string;
}
export declare const Insight: S.Schema<Insight>;
export type InsightList = Insight[];
export declare const InsightList: any;
export type ClusteringFrequency = "DAILY" | "WEEKLY" | "MONTHLY" | (string & {});
export declare const ClusteringFrequency: any;
export type ClusteringFrequencyList = ClusteringFrequency[];
export declare const ClusteringFrequencyList: any;
export interface ClusteringConfig {
    frequencies: ClusteringFrequency[];
}
export declare const ClusteringConfig: S.Schema<ClusteringConfig>;
export interface CreateOnlineEvaluationConfigRequest {
    clientToken?: string;
    onlineEvaluationConfigName: string;
    description?: string | redacted.Redacted<string>;
    rule: Rule;
    dataSourceConfig: DataSourceConfig;
    evaluators?: EvaluatorReference[];
    insights?: Insight[];
    clusteringConfig?: ClusteringConfig;
    evaluationExecutionRoleArn: string;
    enableOnCreate: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateOnlineEvaluationConfigRequest: S.Schema<CreateOnlineEvaluationConfigRequest>;
export type OnlineEvaluationConfigArn = string;
export type OnlineEvaluationConfigId = string;
export interface CloudWatchOutputConfig {
    logGroupName: string;
}
export declare const CloudWatchOutputConfig: S.Schema<CloudWatchOutputConfig>;
export interface OutputConfig {
    cloudWatchConfig: CloudWatchOutputConfig;
}
export declare const OutputConfig: S.Schema<OutputConfig>;
export type OnlineEvaluationConfigStatus = "ACTIVE" | "CREATING" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "DELETING" | "ERROR" | (string & {});
export declare const OnlineEvaluationConfigStatus: any;
export type OnlineEvaluationExecutionStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const OnlineEvaluationExecutionStatus: any;
export interface CreateOnlineEvaluationConfigResponse {
    onlineEvaluationConfigArn: string;
    onlineEvaluationConfigId: string;
    createdAt: Date;
    outputConfig?: OutputConfig;
    status: OnlineEvaluationConfigStatus;
    executionStatus: OnlineEvaluationExecutionStatus;
    failureReason?: string;
}
export declare const CreateOnlineEvaluationConfigResponse: S.Schema<CreateOnlineEvaluationConfigResponse>;
export type PaymentManagerId = string;
export type PaymentConnectorName = string;
export type PaymentsDescription = string;
export type PaymentConnectorType = "CoinbaseCDP" | "StripePrivy" | (string & {});
export declare const PaymentConnectorType: any;
export type PaymentCredentialProviderArn = string;
export interface PaymentCredentialProviderConfiguration {
    credentialProviderArn: string;
}
export declare const PaymentCredentialProviderConfiguration: S.Schema<PaymentCredentialProviderConfiguration>;
export type CredentialsProviderConfiguration = {
    coinbaseCDP: PaymentCredentialProviderConfiguration;
    stripePrivy?: never;
} | {
    coinbaseCDP?: never;
    stripePrivy: PaymentCredentialProviderConfiguration;
};
export declare const CredentialsProviderConfiguration: any;
export type CredentialsProviderConfigurations = CredentialsProviderConfiguration[];
export declare const CredentialsProviderConfigurations: any;
export type PaymentConnectorProvisionMode = "MANUAL" | "QUICK_CREATE" | (string & {});
export declare const PaymentConnectorProvisionMode: any;
export interface CreatePaymentConnectorRequest {
    paymentManagerId: string;
    name: string;
    description?: string;
    type: PaymentConnectorType;
    credentialProviderConfigurations: CredentialsProviderConfiguration[];
    provisionMode?: PaymentConnectorProvisionMode;
    clientToken?: string;
}
export declare const CreatePaymentConnectorRequest: S.Schema<CreatePaymentConnectorRequest>;
export type PaymentConnectorId = string;
export type PaymentConnectorStatus = "CREATING" | "UPDATING" | "DELETING" | "READY" | "CREATE_FAILED" | "UPDATE_FAILED" | "DELETE_FAILED" | "AWS_MARKETPLACE_SUBSCRIPTION_REQUIRED" | "PENDING_AUTHENTICATION" | "PROVISIONING" | "AUTHENTICATION_EXPIRED" | "AUTHENTICATION_FAILED" | (string & {});
export declare const PaymentConnectorStatus: any;
export type PaymentConnectorAuthorizationUrl = string;
export interface CreatePaymentConnectorResponse {
    paymentConnectorId: string;
    paymentManagerId: string;
    name: string;
    type: PaymentConnectorType;
    credentialProviderConfigurations: CredentialsProviderConfiguration[];
    createdAt: Date;
    status: PaymentConnectorStatus;
    authorizationUrl?: string;
}
export declare const CreatePaymentConnectorResponse: S.Schema<CreatePaymentConnectorResponse>;
export type PaymentCredentialProviderVendorType = "CoinbaseCDP" | "StripePrivy" | (string & {});
export declare const PaymentCredentialProviderVendorType: any;
export type CoinbaseCdpApiKeyIdType = string;
export type DefaultCoinbaseCdpApiKeySecretType = string | redacted.Redacted<string>;
export type DefaultCoinbaseCdpWalletSecretType = string | redacted.Redacted<string>;
export interface CoinbaseCdpConfigurationInput {
    apiKeyId: string;
    apiKeySecret?: string | redacted.Redacted<string>;
    apiKeySecretSource?: SecretSourceType;
    apiKeySecretConfig?: SecretReference;
    walletSecret?: string | redacted.Redacted<string>;
    walletSecretSource?: SecretSourceType;
    walletSecretConfig?: SecretReference;
}
export declare const CoinbaseCdpConfigurationInput: S.Schema<CoinbaseCdpConfigurationInput>;
export type StripePrivyAppIdType = string;
export type DefaultStripePrivyAppSecretType = string | redacted.Redacted<string>;
export type DefaultStripePrivyAuthorizationPrivateKeyType = string | redacted.Redacted<string>;
export type StripePrivyAuthorizationIdType = string;
export interface StripePrivyConfigurationInput {
    appId: string;
    appSecret?: string | redacted.Redacted<string>;
    appSecretSource?: SecretSourceType;
    appSecretConfig?: SecretReference;
    authorizationPrivateKey?: string | redacted.Redacted<string>;
    authorizationPrivateKeySource?: SecretSourceType;
    authorizationPrivateKeyConfig?: SecretReference;
    authorizationId: string;
}
export declare const StripePrivyConfigurationInput: S.Schema<StripePrivyConfigurationInput>;
export type PaymentProviderConfigurationInput = {
    coinbaseCdpConfiguration: CoinbaseCdpConfigurationInput;
    stripePrivyConfiguration?: never;
} | {
    coinbaseCdpConfiguration?: never;
    stripePrivyConfiguration: StripePrivyConfigurationInput;
};
export declare const PaymentProviderConfigurationInput: any;
export interface CreatePaymentCredentialProviderRequest {
    name: string;
    credentialProviderVendor: PaymentCredentialProviderVendorType;
    providerConfigurationInput: PaymentProviderConfigurationInput;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePaymentCredentialProviderRequest: S.Schema<CreatePaymentCredentialProviderRequest>;
export type PaymentCredentialProviderArnType = string;
export interface CoinbaseCdpConfigurationOutput {
    apiKeyId: string;
    apiKeySecretArn: Secret;
    apiKeySecretJsonKey?: string;
    apiKeySecretSource?: SecretSourceType;
    walletSecretArn: Secret;
    walletSecretJsonKey?: string;
    walletSecretSource?: SecretSourceType;
}
export declare const CoinbaseCdpConfigurationOutput: S.Schema<CoinbaseCdpConfigurationOutput>;
export interface StripePrivyConfigurationOutput {
    appId: string;
    appSecretArn: Secret;
    appSecretJsonKey?: string;
    appSecretSource?: SecretSourceType;
    authorizationPrivateKeyArn: Secret;
    authorizationPrivateKeyJsonKey?: string;
    authorizationPrivateKeySource?: SecretSourceType;
    authorizationId: string;
}
export declare const StripePrivyConfigurationOutput: S.Schema<StripePrivyConfigurationOutput>;
export type PaymentProviderConfigurationOutput = {
    coinbaseCdpConfiguration: CoinbaseCdpConfigurationOutput;
    stripePrivyConfiguration?: never;
} | {
    coinbaseCdpConfiguration?: never;
    stripePrivyConfiguration: StripePrivyConfigurationOutput;
};
export declare const PaymentProviderConfigurationOutput: any;
export interface CreatePaymentCredentialProviderResponse {
    name: string;
    credentialProviderVendor: PaymentCredentialProviderVendorType;
    credentialProviderArn: string;
    providerConfigurationOutput: PaymentProviderConfigurationOutput;
}
export declare const CreatePaymentCredentialProviderResponse: S.Schema<CreatePaymentCredentialProviderResponse>;
export type PaymentManagerName = string;
export type PaymentsAuthorizerType = "CUSTOM_JWT" | "AWS_IAM" | (string & {});
export declare const PaymentsAuthorizerType: any;
export interface CreatePaymentManagerRequest {
    name: string;
    description?: string;
    authorizerType: PaymentsAuthorizerType;
    authorizerConfiguration?: AuthorizerConfiguration;
    roleArn: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    kmsKeyArn?: string;
}
export declare const CreatePaymentManagerRequest: S.Schema<CreatePaymentManagerRequest>;
export type PaymentManagerArn = string;
export type PaymentManagerStatus = "CREATING" | "UPDATING" | "DELETING" | "READY" | "CREATE_FAILED" | "UPDATE_FAILED" | "DELETE_FAILED" | (string & {});
export declare const PaymentManagerStatus: any;
export interface CreatePaymentManagerResponse {
    paymentManagerArn: string;
    paymentManagerId: string;
    name: string;
    authorizerType: PaymentsAuthorizerType;
    authorizerConfiguration?: AuthorizerConfiguration;
    roleArn: string;
    workloadIdentityDetails?: WorkloadIdentityDetails;
    createdAt: Date;
    status: PaymentManagerStatus;
    tags?: {
        [key: string]: string | undefined;
    };
    kmsKeyArn?: string;
}
export declare const CreatePaymentManagerResponse: S.Schema<CreatePaymentManagerResponse>;
export type PolicyName = string;
export type Statement = string;
export interface CedarPolicy {
    statement: string;
}
export declare const CedarPolicy: S.Schema<CedarPolicy>;
export type ResourceId = string;
export interface PolicyGenerationDetails {
    policyGenerationId: string;
    policyGenerationAssetId: string;
}
export declare const PolicyGenerationDetails: S.Schema<PolicyGenerationDetails>;
export interface PolicyStatement {
    statement: string;
}
export declare const PolicyStatement: S.Schema<PolicyStatement>;
export type PolicyDefinition = {
    cedar: CedarPolicy;
    policyGeneration?: never;
    policy?: never;
} | {
    cedar?: never;
    policyGeneration: PolicyGenerationDetails;
    policy?: never;
} | {
    cedar?: never;
    policyGeneration?: never;
    policy: PolicyStatement;
};
export declare const PolicyDefinition: any;
export type PolicyValidationMode = "FAIL_ON_ANY_FINDINGS" | "IGNORE_ALL_FINDINGS" | (string & {});
export declare const PolicyValidationMode: any;
export type EnforcementMode = "ACTIVE" | "LOG_ONLY" | (string & {});
export declare const EnforcementMode: any;
export interface CreatePolicyRequest {
    name: string;
    definition: PolicyDefinition;
    description?: string | redacted.Redacted<string>;
    validationMode?: PolicyValidationMode;
    enforcementMode?: EnforcementMode;
    policyEngineId: string;
    clientToken?: string;
}
export declare const CreatePolicyRequest: S.Schema<CreatePolicyRequest>;
export type PolicyArn = string;
export type PolicyStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "CREATE_FAILED" | "UPDATE_FAILED" | "DELETE_FAILED" | (string & {});
export declare const PolicyStatus: any;
export type PolicyStatusReasons = string[];
export declare const PolicyStatusReasons: any;
export interface CreatePolicyResponse {
    policyId: string;
    name: string;
    policyEngineId: string;
    createdAt: Date;
    updatedAt: Date;
    policyArn: string;
    status: PolicyStatus;
    enforcementMode?: EnforcementMode;
    definition: PolicyDefinition;
    description?: string | redacted.Redacted<string>;
    statusReasons: string[];
}
export declare const CreatePolicyResponse: S.Schema<CreatePolicyResponse>;
export type PolicyEngineName = string;
export interface CreatePolicyEngineRequest {
    name: string;
    description?: string | redacted.Redacted<string>;
    clientToken?: string;
    encryptionKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePolicyEngineRequest: S.Schema<CreatePolicyEngineRequest>;
export type PolicyEngineArn = string;
export type PolicyEngineStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "CREATE_FAILED" | "UPDATE_FAILED" | "DELETE_FAILED" | (string & {});
export declare const PolicyEngineStatus: any;
export interface CreatePolicyEngineResponse {
    policyEngineId: string;
    name: string;
    createdAt: Date;
    updatedAt: Date;
    policyEngineArn: string;
    status: PolicyEngineStatus;
    encryptionKeyArn?: string;
    description?: string | redacted.Redacted<string>;
    statusReasons: string[];
}
export declare const CreatePolicyEngineResponse: S.Schema<CreatePolicyEngineResponse>;
export type RegistryName = string;
export type RegistryAuthorizerType = "CUSTOM_JWT" | "AWS_IAM" | (string & {});
export declare const RegistryAuthorizerType: any;
export interface ApprovalConfiguration {
    autoApproval?: boolean;
}
export declare const ApprovalConfiguration: S.Schema<ApprovalConfiguration>;
export interface CreateRegistryRequest {
    name: string;
    description?: string | redacted.Redacted<string>;
    authorizerType?: RegistryAuthorizerType;
    authorizerConfiguration?: AuthorizerConfiguration;
    clientToken?: string;
    approvalConfiguration?: ApprovalConfiguration;
}
export declare const CreateRegistryRequest: S.Schema<CreateRegistryRequest>;
export type RegistryArn = string;
export interface CreateRegistryResponse {
    registryArn: string;
}
export declare const CreateRegistryResponse: S.Schema<CreateRegistryResponse>;
export type RegistryIdentifier = string;
export type RegistryRecordName = string;
export type DescriptorType = "MCP" | "A2A" | "CUSTOM" | "AGENT_SKILLS" | (string & {});
export declare const DescriptorType: any;
export type SchemaVersion = string;
export type InlineContent = string;
export interface ServerDefinition {
    schemaVersion?: string;
    inlineContent?: string;
}
export declare const ServerDefinition: S.Schema<ServerDefinition>;
export interface ToolsDefinition {
    protocolVersion?: string;
    inlineContent?: string;
}
export declare const ToolsDefinition: S.Schema<ToolsDefinition>;
export interface McpDescriptor {
    server?: ServerDefinition;
    tools?: ToolsDefinition;
}
export declare const McpDescriptor: S.Schema<McpDescriptor>;
export interface AgentCardDefinition {
    schemaVersion?: string;
    inlineContent?: string;
}
export declare const AgentCardDefinition: S.Schema<AgentCardDefinition>;
export interface A2aDescriptor {
    agentCard?: AgentCardDefinition;
}
export declare const A2aDescriptor: S.Schema<A2aDescriptor>;
export interface CustomDescriptor {
    inlineContent?: string;
}
export declare const CustomDescriptor: S.Schema<CustomDescriptor>;
export interface SkillMdDefinition {
    inlineContent?: string;
}
export declare const SkillMdDefinition: S.Schema<SkillMdDefinition>;
export interface SkillDefinition {
    schemaVersion?: string;
    inlineContent?: string;
}
export declare const SkillDefinition: S.Schema<SkillDefinition>;
export interface AgentSkillsDescriptor {
    skillMd?: SkillMdDefinition;
    skillDefinition?: SkillDefinition;
}
export declare const AgentSkillsDescriptor: S.Schema<AgentSkillsDescriptor>;
export interface Descriptors {
    mcp?: McpDescriptor;
    a2a?: A2aDescriptor;
    custom?: CustomDescriptor;
    agentSkills?: AgentSkillsDescriptor;
}
export declare const Descriptors: S.Schema<Descriptors>;
export type RegistryRecordVersion = string;
export type SynchronizationType = "URL" | (string & {});
export declare const SynchronizationType: any;
export type McpServerUrl = string;
export type RegistryRecordCredentialProviderType = "OAUTH" | "IAM" | (string & {});
export declare const RegistryRecordCredentialProviderType: any;
export type CredentialProviderArn = string;
export type RegistryRecordOAuthGrantType = "CLIENT_CREDENTIALS" | (string & {});
export declare const RegistryRecordOAuthGrantType: any;
export type ScopeList = string[];
export declare const ScopeList: any;
export type CustomParameterMap = {
    [key: string]: string | undefined;
};
export declare const CustomParameterMap: any;
export interface RegistryRecordOAuthCredentialProvider {
    providerArn: string;
    grantType?: RegistryRecordOAuthGrantType;
    scopes?: string[];
    customParameters?: {
        [key: string]: string | undefined;
    };
}
export declare const RegistryRecordOAuthCredentialProvider: S.Schema<RegistryRecordOAuthCredentialProvider>;
export type IamRoleArn = string;
export type IamSigningServiceName = string;
export type IamSigningRegion = string;
export interface RegistryRecordIamCredentialProvider {
    roleArn?: string;
    service?: string;
    region?: string;
}
export declare const RegistryRecordIamCredentialProvider: S.Schema<RegistryRecordIamCredentialProvider>;
export type RegistryRecordCredentialProviderUnion = {
    oauthCredentialProvider: RegistryRecordOAuthCredentialProvider;
    iamCredentialProvider?: never;
} | {
    oauthCredentialProvider?: never;
    iamCredentialProvider: RegistryRecordIamCredentialProvider;
};
export declare const RegistryRecordCredentialProviderUnion: any;
export interface RegistryRecordCredentialProviderConfiguration {
    credentialProviderType: RegistryRecordCredentialProviderType;
    credentialProvider: RegistryRecordCredentialProviderUnion;
}
export declare const RegistryRecordCredentialProviderConfiguration: S.Schema<RegistryRecordCredentialProviderConfiguration>;
export type RegistryRecordCredentialProviderConfigurationList = RegistryRecordCredentialProviderConfiguration[];
export declare const RegistryRecordCredentialProviderConfigurationList: any;
export interface FromUrlSynchronizationConfiguration {
    url: string;
    credentialProviderConfigurations?: RegistryRecordCredentialProviderConfiguration[];
}
export declare const FromUrlSynchronizationConfiguration: S.Schema<FromUrlSynchronizationConfiguration>;
export interface SynchronizationConfiguration {
    fromUrl?: FromUrlSynchronizationConfiguration;
}
export declare const SynchronizationConfiguration: S.Schema<SynchronizationConfiguration>;
export interface CreateRegistryRecordRequest {
    registryId: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    descriptorType: DescriptorType;
    descriptors?: Descriptors;
    recordVersion?: string;
    synchronizationType?: SynchronizationType;
    synchronizationConfiguration?: SynchronizationConfiguration;
    clientToken?: string;
}
export declare const CreateRegistryRecordRequest: S.Schema<CreateRegistryRecordRequest>;
export type RegistryRecordArn = string;
export type RegistryRecordStatus = "DRAFT" | "PENDING_APPROVAL" | "APPROVED" | "REJECTED" | "DEPRECATED" | "CREATING" | "UPDATING" | "CREATE_FAILED" | "UPDATE_FAILED" | (string & {});
export declare const RegistryRecordStatus: any;
export interface CreateRegistryRecordResponse {
    recordArn: string;
    status: RegistryRecordStatus;
}
export declare const CreateRegistryRecordResponse: S.Schema<CreateRegistryRecordResponse>;
export type ResourceOauth2ReturnUrlType = string;
export type ResourceOauth2ReturnUrlListType = string[];
export declare const ResourceOauth2ReturnUrlListType: any;
export interface CreateWorkloadIdentityRequest {
    name: string;
    allowedResourceOauth2ReturnUrls?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateWorkloadIdentityRequest: S.Schema<CreateWorkloadIdentityRequest>;
export type WorkloadIdentityArnType = string;
export interface CreateWorkloadIdentityResponse {
    name: string;
    workloadIdentityArn: string;
    allowedResourceOauth2ReturnUrls?: string[];
}
export declare const CreateWorkloadIdentityResponse: S.Schema<CreateWorkloadIdentityResponse>;
export interface DeleteAgentRuntimeRequest {
    agentRuntimeId: string;
    agentRuntimeVersion?: string;
    clientToken?: string;
}
export declare const DeleteAgentRuntimeRequest: S.Schema<DeleteAgentRuntimeRequest>;
export interface DeleteAgentRuntimeResponse {
    status: AgentRuntimeStatus;
    agentRuntimeId?: string;
    agentRuntimeVersion?: string;
}
export declare const DeleteAgentRuntimeResponse: S.Schema<DeleteAgentRuntimeResponse>;
export interface DeleteAgentRuntimeEndpointRequest {
    agentRuntimeId: string;
    endpointName: string | redacted.Redacted<string>;
    clientToken?: string;
}
export declare const DeleteAgentRuntimeEndpointRequest: S.Schema<DeleteAgentRuntimeEndpointRequest>;
export interface DeleteAgentRuntimeEndpointResponse {
    status: AgentRuntimeEndpointStatus;
    agentRuntimeId?: string;
    endpointName?: string | redacted.Redacted<string>;
}
export declare const DeleteAgentRuntimeEndpointResponse: S.Schema<DeleteAgentRuntimeEndpointResponse>;
export interface DeleteApiKeyCredentialProviderRequest {
    name: string;
}
export declare const DeleteApiKeyCredentialProviderRequest: S.Schema<DeleteApiKeyCredentialProviderRequest>;
export interface DeleteApiKeyCredentialProviderResponse {
}
export declare const DeleteApiKeyCredentialProviderResponse: S.Schema<DeleteApiKeyCredentialProviderResponse>;
export interface DeleteBrowserRequest {
    browserId: string;
    clientToken?: string;
}
export declare const DeleteBrowserRequest: S.Schema<DeleteBrowserRequest>;
export interface DeleteBrowserResponse {
    browserId: string;
    status: BrowserStatus;
    lastUpdatedAt: Date;
}
export declare const DeleteBrowserResponse: S.Schema<DeleteBrowserResponse>;
export interface DeleteBrowserProfileRequest {
    profileId: string;
    clientToken?: string;
}
export declare const DeleteBrowserProfileRequest: S.Schema<DeleteBrowserProfileRequest>;
export interface DeleteBrowserProfileResponse {
    profileId: string;
    profileArn: string;
    status: BrowserProfileStatus;
    lastUpdatedAt: Date;
    lastSavedAt?: Date;
}
export declare const DeleteBrowserProfileResponse: S.Schema<DeleteBrowserProfileResponse>;
export interface DeleteCapacityProviderInput {
    capacityProviderId: string;
    clientToken?: string;
}
export declare const DeleteCapacityProviderInput: S.Schema<DeleteCapacityProviderInput>;
export interface DeleteCapacityProviderOutput {
    capacityProviderId: string;
    status: CapacityProviderStatus;
}
export declare const DeleteCapacityProviderOutput: S.Schema<DeleteCapacityProviderOutput>;
export interface DeleteCodeInterpreterRequest {
    codeInterpreterId: string;
    clientToken?: string;
}
export declare const DeleteCodeInterpreterRequest: S.Schema<DeleteCodeInterpreterRequest>;
export interface DeleteCodeInterpreterResponse {
    codeInterpreterId: string;
    status: CodeInterpreterStatus;
    lastUpdatedAt: Date;
}
export declare const DeleteCodeInterpreterResponse: S.Schema<DeleteCodeInterpreterResponse>;
export interface DeleteConfigurationBundleRequest {
    bundleId: string;
}
export declare const DeleteConfigurationBundleRequest: S.Schema<DeleteConfigurationBundleRequest>;
export type ConfigurationBundleStatus = "ACTIVE" | "CREATING" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "DELETING" | "DELETE_FAILED" | (string & {});
export declare const ConfigurationBundleStatus: any;
export interface DeleteConfigurationBundleResponse {
    bundleId: string;
    status: ConfigurationBundleStatus;
}
export declare const DeleteConfigurationBundleResponse: S.Schema<DeleteConfigurationBundleResponse>;
export interface DeleteDatasetRequest {
    datasetId: string;
    datasetVersion?: string;
}
export declare const DeleteDatasetRequest: S.Schema<DeleteDatasetRequest>;
export interface DeleteDatasetResponse {
    datasetArn: string;
    datasetId: string;
    status: DatasetStatus;
    datasetVersion: string;
    updatedAt: Date;
}
export declare const DeleteDatasetResponse: S.Schema<DeleteDatasetResponse>;
export interface DeleteDatasetExamplesRequest {
    datasetId: string;
    clientToken?: string;
    exampleIds: string[];
}
export declare const DeleteDatasetExamplesRequest: S.Schema<DeleteDatasetExamplesRequest>;
export interface DeleteDatasetExamplesResponse {
    datasetArn: string;
    datasetId: string;
    status: DatasetStatus;
    deletedCount: number;
    updatedAt: Date;
}
export declare const DeleteDatasetExamplesResponse: S.Schema<DeleteDatasetExamplesResponse>;
export interface DeleteEvaluatorRequest {
    evaluatorId: string;
}
export declare const DeleteEvaluatorRequest: S.Schema<DeleteEvaluatorRequest>;
export type EvaluatorArn = string;
export interface DeleteEvaluatorResponse {
    evaluatorArn: string;
    evaluatorId: string;
    status: EvaluatorStatus;
}
export declare const DeleteEvaluatorResponse: S.Schema<DeleteEvaluatorResponse>;
export interface DeleteGatewayRequest {
    gatewayIdentifier: string;
}
export declare const DeleteGatewayRequest: S.Schema<DeleteGatewayRequest>;
export interface DeleteGatewayResponse {
    gatewayId: string;
    status: GatewayStatus;
    statusReasons?: string[];
}
export declare const DeleteGatewayResponse: S.Schema<DeleteGatewayResponse>;
export interface DeleteGatewayRateLimitRequest {
    gatewayIdentifier: string;
    rateLimitId: string;
}
export declare const DeleteGatewayRateLimitRequest: S.Schema<DeleteGatewayRateLimitRequest>;
export interface DeleteGatewayRateLimitResponse {
    rateLimitId: string;
    status: GatewayRateLimitStatus;
}
export declare const DeleteGatewayRateLimitResponse: S.Schema<DeleteGatewayRateLimitResponse>;
export interface DeleteGatewayRuleRequest {
    gatewayIdentifier: string;
    ruleId: string;
}
export declare const DeleteGatewayRuleRequest: S.Schema<DeleteGatewayRuleRequest>;
export interface DeleteGatewayRuleResponse {
    ruleId: string;
    status: GatewayRuleStatus;
}
export declare const DeleteGatewayRuleResponse: S.Schema<DeleteGatewayRuleResponse>;
export interface DeleteGatewayTargetRequest {
    gatewayIdentifier: string;
    targetId: string;
}
export declare const DeleteGatewayTargetRequest: S.Schema<DeleteGatewayTargetRequest>;
export interface DeleteGatewayTargetResponse {
    gatewayArn: string;
    targetId: string;
    status: TargetStatus;
    statusReasons?: string[];
}
export declare const DeleteGatewayTargetResponse: S.Schema<DeleteGatewayTargetResponse>;
export interface DeleteHarnessRequest {
    harnessId: string;
    clientToken?: string;
    deleteManagedMemory?: boolean;
}
export declare const DeleteHarnessRequest: S.Schema<DeleteHarnessRequest>;
export interface DeleteHarnessResponse {
    harness?: Harness;
}
export declare const DeleteHarnessResponse: S.Schema<DeleteHarnessResponse>;
export interface DeleteHarnessEndpointRequest {
    harnessId: string;
    endpointName: string;
    clientToken?: string;
}
export declare const DeleteHarnessEndpointRequest: S.Schema<DeleteHarnessEndpointRequest>;
export interface DeleteHarnessEndpointResponse {
    endpoint: HarnessEndpoint;
}
export declare const DeleteHarnessEndpointResponse: S.Schema<DeleteHarnessEndpointResponse>;
export interface DeleteMemoryInput {
    clientToken?: string;
    memoryId: string;
}
export declare const DeleteMemoryInput: S.Schema<DeleteMemoryInput>;
export interface DeleteMemoryOutput {
    memoryId: string;
    status?: MemoryStatus;
}
export declare const DeleteMemoryOutput: S.Schema<DeleteMemoryOutput>;
export interface DeleteOauth2CredentialProviderRequest {
    name: string;
}
export declare const DeleteOauth2CredentialProviderRequest: S.Schema<DeleteOauth2CredentialProviderRequest>;
export interface DeleteOauth2CredentialProviderResponse {
}
export declare const DeleteOauth2CredentialProviderResponse: S.Schema<DeleteOauth2CredentialProviderResponse>;
export interface DeleteOnlineEvaluationConfigRequest {
    onlineEvaluationConfigId: string;
}
export declare const DeleteOnlineEvaluationConfigRequest: S.Schema<DeleteOnlineEvaluationConfigRequest>;
export interface DeleteOnlineEvaluationConfigResponse {
    onlineEvaluationConfigArn: string;
    onlineEvaluationConfigId: string;
    status: OnlineEvaluationConfigStatus;
}
export declare const DeleteOnlineEvaluationConfigResponse: S.Schema<DeleteOnlineEvaluationConfigResponse>;
export interface DeletePaymentConnectorRequest {
    paymentManagerId: string;
    paymentConnectorId: string;
    clientToken?: string;
}
export declare const DeletePaymentConnectorRequest: S.Schema<DeletePaymentConnectorRequest>;
export interface DeletePaymentConnectorResponse {
    status: PaymentConnectorStatus;
    paymentConnectorId?: string;
}
export declare const DeletePaymentConnectorResponse: S.Schema<DeletePaymentConnectorResponse>;
export interface DeletePaymentCredentialProviderRequest {
    name: string;
}
export declare const DeletePaymentCredentialProviderRequest: S.Schema<DeletePaymentCredentialProviderRequest>;
export interface DeletePaymentCredentialProviderResponse {
}
export declare const DeletePaymentCredentialProviderResponse: S.Schema<DeletePaymentCredentialProviderResponse>;
export interface DeletePaymentManagerRequest {
    paymentManagerId: string;
    clientToken?: string;
}
export declare const DeletePaymentManagerRequest: S.Schema<DeletePaymentManagerRequest>;
export interface DeletePaymentManagerResponse {
    status: PaymentManagerStatus;
    paymentManagerId?: string;
}
export declare const DeletePaymentManagerResponse: S.Schema<DeletePaymentManagerResponse>;
export interface DeletePolicyRequest {
    policyEngineId: string;
    policyId: string;
}
export declare const DeletePolicyRequest: S.Schema<DeletePolicyRequest>;
export interface DeletePolicyResponse {
    policyId: string;
    name: string;
    policyEngineId: string;
    createdAt: Date;
    updatedAt: Date;
    policyArn: string;
    status: PolicyStatus;
    enforcementMode?: EnforcementMode;
    definition: PolicyDefinition;
    description?: string | redacted.Redacted<string>;
    statusReasons: string[];
}
export declare const DeletePolicyResponse: S.Schema<DeletePolicyResponse>;
export interface DeletePolicyEngineRequest {
    policyEngineId: string;
}
export declare const DeletePolicyEngineRequest: S.Schema<DeletePolicyEngineRequest>;
export interface DeletePolicyEngineResponse {
    policyEngineId: string;
    name: string;
    createdAt: Date;
    updatedAt: Date;
    policyEngineArn: string;
    status: PolicyEngineStatus;
    encryptionKeyArn?: string;
    description?: string | redacted.Redacted<string>;
    statusReasons: string[];
}
export declare const DeletePolicyEngineResponse: S.Schema<DeletePolicyEngineResponse>;
export interface DeleteRegistryRequest {
    registryId: string;
}
export declare const DeleteRegistryRequest: S.Schema<DeleteRegistryRequest>;
export type RegistryStatus = "CREATING" | "READY" | "UPDATING" | "CREATE_FAILED" | "UPDATE_FAILED" | "DELETING" | "DELETE_FAILED" | (string & {});
export declare const RegistryStatus: any;
export interface DeleteRegistryResponse {
    status: RegistryStatus;
}
export declare const DeleteRegistryResponse: S.Schema<DeleteRegistryResponse>;
export type RecordIdentifier = string;
export interface DeleteRegistryRecordRequest {
    registryId: string;
    recordId: string;
}
export declare const DeleteRegistryRecordRequest: S.Schema<DeleteRegistryRecordRequest>;
export interface DeleteRegistryRecordResponse {
}
export declare const DeleteRegistryRecordResponse: S.Schema<DeleteRegistryRecordResponse>;
export interface DeleteResourcePolicyRequest {
    resourceArn: string;
}
export declare const DeleteResourcePolicyRequest: S.Schema<DeleteResourcePolicyRequest>;
export interface DeleteResourcePolicyResponse {
}
export declare const DeleteResourcePolicyResponse: S.Schema<DeleteResourcePolicyResponse>;
export interface DeleteWorkloadIdentityRequest {
    name: string;
}
export declare const DeleteWorkloadIdentityRequest: S.Schema<DeleteWorkloadIdentityRequest>;
export interface DeleteWorkloadIdentityResponse {
}
export declare const DeleteWorkloadIdentityResponse: S.Schema<DeleteWorkloadIdentityResponse>;
export interface GetAgentRuntimeRequest {
    agentRuntimeId: string;
    agentRuntimeVersion?: string;
}
export declare const GetAgentRuntimeRequest: S.Schema<GetAgentRuntimeRequest>;
export interface RuntimeMetadataConfiguration {
    requireMMDSV2: boolean;
}
export declare const RuntimeMetadataConfiguration: S.Schema<RuntimeMetadataConfiguration>;
export interface GetAgentRuntimeResponse {
    agentRuntimeArn: string;
    agentRuntimeName: string;
    agentRuntimeId: string;
    agentRuntimeVersion: string;
    createdAt: Date;
    lastUpdatedAt: Date;
    roleArn: string;
    networkConfiguration?: NetworkConfiguration;
    status: AgentRuntimeStatus;
    lifecycleConfiguration: LifecycleConfiguration;
    failureReason?: string;
    description?: string | redacted.Redacted<string>;
    workloadIdentityDetails?: WorkloadIdentityDetails;
    agentRuntimeArtifact?: AgentRuntimeArtifact;
    protocolConfiguration?: ProtocolConfiguration;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    authorizerConfiguration?: AuthorizerConfiguration;
    requestHeaderConfiguration?: RequestHeaderConfiguration;
    metadataConfiguration?: RuntimeMetadataConfiguration;
    filesystemConfigurations?: FilesystemConfiguration[];
    capacityProviderConfiguration?: CapacityProviderConfiguration & {
        capacityProviderArn: CapacityProviderArn;
    };
}
export declare const GetAgentRuntimeResponse: S.Schema<GetAgentRuntimeResponse>;
export interface GetAgentRuntimeEndpointRequest {
    agentRuntimeId: string;
    endpointName: string | redacted.Redacted<string>;
}
export declare const GetAgentRuntimeEndpointRequest: S.Schema<GetAgentRuntimeEndpointRequest>;
export type AgentRuntimeEndpointId = string;
export interface GetAgentRuntimeEndpointResponse {
    liveVersion?: string;
    targetVersion?: string;
    agentRuntimeEndpointArn: string;
    agentRuntimeArn: string;
    description?: string;
    status: AgentRuntimeEndpointStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
    failureReason?: string;
    name: string | redacted.Redacted<string>;
    id: string;
}
export declare const GetAgentRuntimeEndpointResponse: S.Schema<GetAgentRuntimeEndpointResponse>;
export interface GetApiKeyCredentialProviderRequest {
    name: string;
}
export declare const GetApiKeyCredentialProviderRequest: S.Schema<GetApiKeyCredentialProviderRequest>;
export interface GetApiKeyCredentialProviderResponse {
    apiKeySecretArn: Secret;
    apiKeySecretJsonKey?: string;
    apiKeySecretSource?: SecretSourceType;
    name: string;
    credentialProviderArn: string;
    createdTime: Date;
    lastUpdatedTime: Date;
}
export declare const GetApiKeyCredentialProviderResponse: S.Schema<GetApiKeyCredentialProviderResponse>;
export interface GetBrowserRequest {
    browserId: string;
}
export declare const GetBrowserRequest: S.Schema<GetBrowserRequest>;
export interface BrowserSigningConfigOutput {
    enabled: boolean;
}
export declare const BrowserSigningConfigOutput: S.Schema<BrowserSigningConfigOutput>;
export interface GetBrowserResponse {
    browserId: string;
    browserArn: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    executionRoleArn?: string;
    networkConfiguration: BrowserNetworkConfiguration;
    recording?: RecordingConfig;
    browserSigning?: BrowserSigningConfigOutput;
    enterprisePolicies?: BrowserEnterprisePolicy[];
    certificates?: Certificate[];
    filesystemConfigurations?: ToolsFileSystemConfiguration[];
    status: BrowserStatus;
    failureReason?: string;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export declare const GetBrowserResponse: S.Schema<GetBrowserResponse>;
export interface GetBrowserProfileRequest {
    profileId: string;
}
export declare const GetBrowserProfileRequest: S.Schema<GetBrowserProfileRequest>;
export type BrowserSessionId = string;
export interface GetBrowserProfileResponse {
    profileId: string;
    profileArn: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    status: BrowserProfileStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
    lastSavedAt?: Date;
    lastSavedBrowserSessionId?: string;
    lastSavedBrowserId?: string;
}
export declare const GetBrowserProfileResponse: S.Schema<GetBrowserProfileResponse>;
export interface GetCapacityProviderInput {
    capacityProviderId: string;
}
export declare const GetCapacityProviderInput: S.Schema<GetCapacityProviderInput>;
export type CapacityProviderStatusCode = "VALIDATION_ERROR" | "QUOTA_EXCEEDED" | "THROTTLED" | "INTERNAL_SERVER_EXCEPTION" | (string & {});
export declare const CapacityProviderStatusCode: any;
export interface GetCapacityProviderOutput {
    capacityProviderId: string;
    capacityProviderArn: string;
    name: string;
    status: CapacityProviderStatus;
    description?: string | redacted.Redacted<string>;
    statusCode?: CapacityProviderStatusCode;
    statusReason?: string;
    permissionsConfiguration: PermissionsConfiguration;
    computeConfiguration: ComputeConfiguration;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export declare const GetCapacityProviderOutput: S.Schema<GetCapacityProviderOutput>;
export interface GetCodeInterpreterRequest {
    codeInterpreterId: string;
}
export declare const GetCodeInterpreterRequest: S.Schema<GetCodeInterpreterRequest>;
export interface GetCodeInterpreterResponse {
    codeInterpreterId: string;
    codeInterpreterArn: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    executionRoleArn?: string;
    networkConfiguration: CodeInterpreterNetworkConfiguration;
    status: CodeInterpreterStatus;
    certificates?: Certificate[];
    filesystemConfigurations?: ToolsFileSystemConfiguration[];
    failureReason?: string;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export declare const GetCodeInterpreterResponse: S.Schema<GetCodeInterpreterResponse>;
export interface GetConfigurationBundleRequest {
    bundleId: string;
    branchName?: string;
}
export declare const GetConfigurationBundleRequest: S.Schema<GetConfigurationBundleRequest>;
export type ConfigurationBundleVersionList = string[];
export declare const ConfigurationBundleVersionList: any;
export interface VersionLineageMetadata {
    parentVersionIds?: string[];
    branchName?: string;
    createdBy?: VersionCreatedBySource;
    commitMessage?: string;
}
export declare const VersionLineageMetadata: S.Schema<VersionLineageMetadata>;
export interface GetConfigurationBundleResponse {
    bundleArn: string;
    bundleId: string;
    bundleName: string;
    description?: string | redacted.Redacted<string>;
    versionId: string;
    components: {
        [key: string]: ComponentConfiguration | undefined;
    };
    lineageMetadata?: VersionLineageMetadata;
    createdAt: Date;
    updatedAt: Date;
    kmsKeyArn?: string;
}
export declare const GetConfigurationBundleResponse: S.Schema<GetConfigurationBundleResponse>;
export interface GetConfigurationBundleVersionRequest {
    bundleId: string;
    versionId: string;
}
export declare const GetConfigurationBundleVersionRequest: S.Schema<GetConfigurationBundleVersionRequest>;
export interface GetConfigurationBundleVersionResponse {
    bundleArn: string;
    bundleId: string;
    bundleName: string;
    description?: string | redacted.Redacted<string>;
    versionId: string;
    components: {
        [key: string]: ComponentConfiguration | undefined;
    };
    lineageMetadata?: VersionLineageMetadata;
    createdAt: Date;
    versionCreatedAt: Date;
    kmsKeyArn?: string;
}
export declare const GetConfigurationBundleVersionResponse: S.Schema<GetConfigurationBundleVersionResponse>;
export interface GetDatasetRequest {
    datasetId: string;
    datasetVersion?: string;
}
export declare const GetDatasetRequest: S.Schema<GetDatasetRequest>;
export type DraftStatus = "MODIFIED" | "UNMODIFIED" | (string & {});
export declare const DraftStatus: any;
export type DownloadUrl = string | redacted.Redacted<string>;
export interface GetDatasetResponse {
    datasetArn: string;
    datasetId: string;
    datasetVersion: string;
    datasetName: string;
    description?: string;
    status: DatasetStatus;
    draftStatus?: DraftStatus;
    failureReason?: string;
    schemaType: DatasetSchemaType;
    kmsKeyArn?: string;
    exampleCount: number;
    downloadUrl?: string | redacted.Redacted<string>;
    downloadUrlExpiresAt?: Date;
    createdAt: Date;
    updatedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetDatasetResponse: S.Schema<GetDatasetResponse>;
export type IncludedData = "ALL_DATA" | "METADATA_ONLY" | (string & {});
export declare const IncludedData: any;
export interface GetEvaluatorRequest {
    evaluatorId: string;
    includedData?: IncludedData;
}
export declare const GetEvaluatorRequest: S.Schema<GetEvaluatorRequest>;
export type EvaluatorName = string;
export type EvaluatorType = "Builtin" | "ThirdParty" | "Custom" | "CustomCode" | "CustomDerived" | (string & {});
export declare const EvaluatorType: any;
export type Provider = "AWS" | "DeepEval" | "AutoEval" | "Custom" | (string & {});
export declare const Provider: any;
export interface GetEvaluatorResponse {
    evaluatorArn: string;
    evaluatorId: string;
    evaluatorName: string;
    description?: string | redacted.Redacted<string>;
    evaluatorConfig: EvaluatorConfig;
    evaluatorType?: EvaluatorType;
    provider?: Provider;
    level: EvaluatorLevel;
    status: EvaluatorStatus;
    createdAt: Date;
    updatedAt: Date;
    lockedForModification?: boolean;
    kmsKeyArn?: string;
}
export declare const GetEvaluatorResponse: S.Schema<GetEvaluatorResponse>;
export interface GetGatewayRequest {
    gatewayIdentifier: string;
}
export declare const GetGatewayRequest: S.Schema<GetGatewayRequest>;
export interface GetGatewayResponse {
    gatewayArn: string;
    gatewayId: string;
    gatewayUrl?: string;
    createdAt: Date;
    updatedAt: Date;
    status: GatewayStatus;
    statusReasons?: string[];
    name: string;
    description?: string | redacted.Redacted<string>;
    roleArn?: string;
    protocolType?: GatewayProtocolType;
    protocolConfiguration?: GatewayProtocolConfiguration;
    authorizerType: AuthorizerType;
    authorizerConfiguration?: AuthorizerConfiguration;
    kmsKeyArn?: string;
    customTransformConfiguration?: CustomTransformConfiguration;
    interceptorConfigurations?: GatewayInterceptorConfiguration[];
    policyEngineConfiguration?: GatewayPolicyEngineConfiguration;
    workloadIdentityDetails?: WorkloadIdentityDetails;
    exceptionLevel?: ExceptionLevel;
    webAclArn?: string;
    wafConfiguration?: WafConfiguration;
}
export declare const GetGatewayResponse: S.Schema<GetGatewayResponse>;
export interface GetGatewayRateLimitRequest {
    gatewayIdentifier: string;
    rateLimitId: string;
}
export declare const GetGatewayRateLimitRequest: S.Schema<GetGatewayRateLimitRequest>;
export interface GetGatewayRateLimitResponse {
    rateLimitId: string;
    gatewayIdentifier: string;
    description?: string;
    dimensionKeys: string[];
    entries: LimitEntry[];
    status: GatewayRateLimitStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const GetGatewayRateLimitResponse: S.Schema<GetGatewayRateLimitResponse>;
export interface GetGatewayRuleRequest {
    gatewayIdentifier: string;
    ruleId: string;
}
export declare const GetGatewayRuleRequest: S.Schema<GetGatewayRuleRequest>;
export interface GetGatewayRuleResponse {
    ruleId: string;
    gatewayArn: string;
    priority: number;
    conditions?: Condition[];
    actions: Action[];
    description?: string;
    createdAt: Date;
    status: GatewayRuleStatus;
    system?: SystemManagedBlock;
    updatedAt?: Date;
}
export declare const GetGatewayRuleResponse: S.Schema<GetGatewayRuleResponse>;
export interface GetGatewayTargetRequest {
    gatewayIdentifier: string;
    targetId: string;
}
export declare const GetGatewayTargetRequest: S.Schema<GetGatewayTargetRequest>;
export interface GetGatewayTargetResponse {
    gatewayArn: string;
    targetId: string;
    createdAt: Date;
    updatedAt: Date;
    status: TargetStatus;
    statusReasons?: string[];
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    targetConfiguration: TargetConfiguration;
    credentialProviderConfigurations: CredentialProviderConfiguration[];
    lastSynchronizedAt?: Date;
    metadataConfiguration?: MetadataConfiguration;
    privateEndpoint?: PrivateEndpoint;
    privateEndpointManagedResources?: ManagedResourceDetails[];
    authorizationData?: AuthorizationData;
    protocolType?: TargetProtocolType;
}
export declare const GetGatewayTargetResponse: S.Schema<GetGatewayTargetResponse>;
export interface GetHarnessRequest {
    harnessId: string;
    harnessVersion?: string;
}
export declare const GetHarnessRequest: S.Schema<GetHarnessRequest>;
export interface GetHarnessResponse {
    harness: Harness;
}
export declare const GetHarnessResponse: S.Schema<GetHarnessResponse>;
export interface GetHarnessEndpointRequest {
    harnessId: string;
    endpointName: string;
}
export declare const GetHarnessEndpointRequest: S.Schema<GetHarnessEndpointRequest>;
export interface GetHarnessEndpointResponse {
    endpoint: HarnessEndpoint;
}
export declare const GetHarnessEndpointResponse: S.Schema<GetHarnessEndpointResponse>;
export type MemoryView = "full" | "without_decryption" | (string & {});
export declare const MemoryView: any;
export interface GetMemoryInput {
    memoryId: string;
    view?: MemoryView;
}
export declare const GetMemoryInput: S.Schema<GetMemoryInput>;
export interface GetMemoryOutput {
    memory: Memory;
}
export declare const GetMemoryOutput: S.Schema<GetMemoryOutput>;
export interface GetOauth2CredentialProviderRequest {
    name: string;
}
export declare const GetOauth2CredentialProviderRequest: S.Schema<GetOauth2CredentialProviderRequest>;
export interface GetOauth2CredentialProviderResponse {
    clientSecretArn: Secret;
    clientSecretJsonKey?: string;
    clientSecretSource?: SecretSourceType;
    name: string;
    credentialProviderArn: string;
    credentialProviderVendor: CredentialProviderVendorType;
    callbackUrl?: string;
    oauth2ProviderConfigOutput: Oauth2ProviderConfigOutput;
    createdTime: Date;
    lastUpdatedTime: Date;
    status?: Status;
    failureReason?: string;
}
export declare const GetOauth2CredentialProviderResponse: S.Schema<GetOauth2CredentialProviderResponse>;
export interface GetOnlineEvaluationConfigRequest {
    onlineEvaluationConfigId: string;
}
export declare const GetOnlineEvaluationConfigRequest: S.Schema<GetOnlineEvaluationConfigRequest>;
export interface GetOnlineEvaluationConfigResponse {
    onlineEvaluationConfigArn: string;
    onlineEvaluationConfigId: string;
    onlineEvaluationConfigName: string;
    description?: string | redacted.Redacted<string>;
    rule: Rule;
    dataSourceConfig: DataSourceConfig;
    evaluators?: EvaluatorReference[];
    insights?: Insight[];
    clusteringConfig?: ClusteringConfig;
    outputConfig?: OutputConfig;
    evaluationExecutionRoleArn?: string;
    status: OnlineEvaluationConfigStatus;
    executionStatus: OnlineEvaluationExecutionStatus;
    createdAt: Date;
    updatedAt: Date;
    failureReason?: string;
}
export declare const GetOnlineEvaluationConfigResponse: S.Schema<GetOnlineEvaluationConfigResponse>;
export interface GetPaymentConnectorRequest {
    paymentManagerId: string;
    paymentConnectorId: string;
}
export declare const GetPaymentConnectorRequest: S.Schema<GetPaymentConnectorRequest>;
export interface GetPaymentConnectorResponse {
    paymentConnectorId: string;
    name: string;
    description?: string;
    type: PaymentConnectorType;
    credentialProviderConfigurations: CredentialsProviderConfiguration[];
    createdAt: Date;
    lastUpdatedAt: Date;
    status: PaymentConnectorStatus;
    authorizationUrl?: string;
}
export declare const GetPaymentConnectorResponse: S.Schema<GetPaymentConnectorResponse>;
export interface GetPaymentCredentialProviderRequest {
    name: string;
}
export declare const GetPaymentCredentialProviderRequest: S.Schema<GetPaymentCredentialProviderRequest>;
export interface GetPaymentCredentialProviderResponse {
    name: string;
    credentialProviderArn: string;
    credentialProviderVendor: PaymentCredentialProviderVendorType;
    providerConfigurationOutput: PaymentProviderConfigurationOutput;
    createdTime: Date;
    lastUpdatedTime: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetPaymentCredentialProviderResponse: S.Schema<GetPaymentCredentialProviderResponse>;
export interface GetPaymentManagerRequest {
    paymentManagerId: string;
}
export declare const GetPaymentManagerRequest: S.Schema<GetPaymentManagerRequest>;
export interface GetPaymentManagerResponse {
    paymentManagerArn: string;
    paymentManagerId: string;
    name: string;
    description?: string;
    authorizerType: PaymentsAuthorizerType;
    authorizerConfiguration?: AuthorizerConfiguration;
    roleArn: string;
    workloadIdentityDetails?: WorkloadIdentityDetails;
    createdAt: Date;
    lastUpdatedAt: Date;
    status: PaymentManagerStatus;
    tags?: {
        [key: string]: string | undefined;
    };
    kmsKeyArn?: string;
}
export declare const GetPaymentManagerResponse: S.Schema<GetPaymentManagerResponse>;
export interface GetPolicyRequest {
    policyEngineId: string;
    policyId: string;
}
export declare const GetPolicyRequest: S.Schema<GetPolicyRequest>;
export interface GetPolicyResponse {
    policyId: string;
    name: string;
    policyEngineId: string;
    createdAt: Date;
    updatedAt: Date;
    policyArn: string;
    status: PolicyStatus;
    enforcementMode?: EnforcementMode;
    definition: PolicyDefinition;
    description?: string | redacted.Redacted<string>;
    statusReasons: string[];
}
export declare const GetPolicyResponse: S.Schema<GetPolicyResponse>;
export interface GetPolicyEngineRequest {
    policyEngineId: string;
}
export declare const GetPolicyEngineRequest: S.Schema<GetPolicyEngineRequest>;
export interface GetPolicyEngineResponse {
    policyEngineId: string;
    name: string;
    createdAt: Date;
    updatedAt: Date;
    policyEngineArn: string;
    status: PolicyEngineStatus;
    encryptionKeyArn?: string;
    description?: string | redacted.Redacted<string>;
    statusReasons: string[];
}
export declare const GetPolicyEngineResponse: S.Schema<GetPolicyEngineResponse>;
export interface GetPolicyEngineSummaryRequest {
    policyEngineId: string;
}
export declare const GetPolicyEngineSummaryRequest: S.Schema<GetPolicyEngineSummaryRequest>;
export interface GetPolicyEngineSummaryResponse {
    policyEngineId: string;
    name: string;
    createdAt: Date;
    updatedAt: Date;
    policyEngineArn: string;
    status: PolicyEngineStatus;
    encryptionKeyArn?: string;
}
export declare const GetPolicyEngineSummaryResponse: S.Schema<GetPolicyEngineSummaryResponse>;
export interface GetPolicyGenerationRequest {
    policyGenerationId: string;
    policyEngineId: string;
}
export declare const GetPolicyGenerationRequest: S.Schema<GetPolicyGenerationRequest>;
export type PolicyGenerationName = string;
export type PolicyGenerationArn = string;
export type Resource = {
    arn: string;
};
export declare const Resource: any;
export type PolicyGenerationStatus = "GENERATING" | "GENERATED" | "GENERATE_FAILED" | "DELETE_FAILED" | (string & {});
export declare const PolicyGenerationStatus: any;
export interface GetPolicyGenerationResponse {
    policyEngineId: string;
    policyGenerationId: string;
    name: string;
    policyGenerationArn: string;
    resource: Resource;
    createdAt: Date;
    updatedAt: Date;
    status: PolicyGenerationStatus;
    findings?: string;
    statusReasons: string[];
}
export declare const GetPolicyGenerationResponse: S.Schema<GetPolicyGenerationResponse>;
export interface GetPolicyGenerationSummaryRequest {
    policyGenerationId: string;
    policyEngineId: string;
}
export declare const GetPolicyGenerationSummaryRequest: S.Schema<GetPolicyGenerationSummaryRequest>;
export interface GetPolicyGenerationSummaryResponse {
    policyEngineId: string;
    policyGenerationId: string;
    name: string;
    policyGenerationArn: string;
    resource: Resource;
    createdAt: Date;
    updatedAt: Date;
    status: PolicyGenerationStatus;
    findings?: string;
}
export declare const GetPolicyGenerationSummaryResponse: S.Schema<GetPolicyGenerationSummaryResponse>;
export interface GetPolicySummaryRequest {
    policyEngineId: string;
    policyId: string;
}
export declare const GetPolicySummaryRequest: S.Schema<GetPolicySummaryRequest>;
export interface GetPolicySummaryResponse {
    policyId: string;
    name: string;
    policyEngineId: string;
    createdAt: Date;
    updatedAt: Date;
    policyArn: string;
    status: PolicyStatus;
    enforcementMode?: EnforcementMode;
}
export declare const GetPolicySummaryResponse: S.Schema<GetPolicySummaryResponse>;
export interface GetRegistryRequest {
    registryId: string;
}
export declare const GetRegistryRequest: S.Schema<GetRegistryRequest>;
export type RegistryId = string;
export interface GetRegistryResponse {
    name: string;
    description?: string | redacted.Redacted<string>;
    registryId: string;
    registryArn: string;
    authorizerType?: RegistryAuthorizerType;
    authorizerConfiguration?: AuthorizerConfiguration;
    approvalConfiguration?: ApprovalConfiguration;
    status: RegistryStatus;
    statusReason?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const GetRegistryResponse: S.Schema<GetRegistryResponse>;
export interface GetRegistryRecordRequest {
    registryId: string;
    recordId: string;
}
export declare const GetRegistryRecordRequest: S.Schema<GetRegistryRecordRequest>;
export type RegistryRecordId = string;
export interface GetRegistryRecordResponse {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    descriptorType: DescriptorType;
    descriptors: Descriptors;
    recordVersion?: string;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
    statusReason?: string;
    synchronizationType?: SynchronizationType;
    synchronizationConfiguration?: SynchronizationConfiguration;
}
export declare const GetRegistryRecordResponse: S.Schema<GetRegistryRecordResponse>;
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export declare const GetResourcePolicyRequest: S.Schema<GetResourcePolicyRequest>;
export type ResourcePolicyBody = string;
export interface GetResourcePolicyResponse {
    policy?: string;
}
export declare const GetResourcePolicyResponse: S.Schema<GetResourcePolicyResponse>;
export type TokenVaultIdType = string;
export interface GetTokenVaultRequest {
    tokenVaultId?: string;
}
export declare const GetTokenVaultRequest: S.Schema<GetTokenVaultRequest>;
export type KeyType = "CustomerManagedKey" | "ServiceManagedKey" | (string & {});
export declare const KeyType: any;
export interface KmsConfiguration {
    keyType: KeyType;
    kmsKeyArn?: string;
}
export declare const KmsConfiguration: S.Schema<KmsConfiguration>;
export interface GetTokenVaultResponse {
    tokenVaultId: string;
    kmsConfiguration: KmsConfiguration;
    lastModifiedDate: Date;
}
export declare const GetTokenVaultResponse: S.Schema<GetTokenVaultResponse>;
export interface GetWorkloadIdentityRequest {
    name: string;
}
export declare const GetWorkloadIdentityRequest: S.Schema<GetWorkloadIdentityRequest>;
export interface GetWorkloadIdentityResponse {
    name: string;
    workloadIdentityArn: string;
    allowedResourceOauth2ReturnUrls?: string[];
    createdTime: Date;
    lastUpdatedTime: Date;
}
export declare const GetWorkloadIdentityResponse: S.Schema<GetWorkloadIdentityResponse>;
export type MaxResults = number;
export type NextToken = string;
export interface ListAgentRuntimeEndpointsRequest {
    agentRuntimeId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAgentRuntimeEndpointsRequest: S.Schema<ListAgentRuntimeEndpointsRequest>;
export interface AgentRuntimeEndpoint {
    name: string | redacted.Redacted<string>;
    liveVersion?: string;
    targetVersion?: string;
    agentRuntimeEndpointArn: string;
    agentRuntimeArn: string;
    status: AgentRuntimeEndpointStatus;
    id: string;
    description?: string;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export declare const AgentRuntimeEndpoint: S.Schema<AgentRuntimeEndpoint>;
export type AgentRuntimeEndpoints = AgentRuntimeEndpoint[];
export declare const AgentRuntimeEndpoints: any;
export interface ListAgentRuntimeEndpointsResponse {
    runtimeEndpoints: AgentRuntimeEndpoint[];
    nextToken?: string;
}
export declare const ListAgentRuntimeEndpointsResponse: S.Schema<ListAgentRuntimeEndpointsResponse>;
export interface ListAgentRuntimesRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAgentRuntimesRequest: S.Schema<ListAgentRuntimesRequest>;
export interface AgentRuntime {
    agentRuntimeArn: string;
    agentRuntimeId: string;
    agentRuntimeVersion: string;
    agentRuntimeName: string;
    description: string | redacted.Redacted<string>;
    lastUpdatedAt: Date;
    status: AgentRuntimeStatus;
}
export declare const AgentRuntime: S.Schema<AgentRuntime>;
export type AgentRuntimes = AgentRuntime[];
export declare const AgentRuntimes: any;
export interface ListAgentRuntimesResponse {
    agentRuntimes: AgentRuntime[];
    nextToken?: string;
}
export declare const ListAgentRuntimesResponse: S.Schema<ListAgentRuntimesResponse>;
export interface ListAgentRuntimeVersionsRequest {
    agentRuntimeId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAgentRuntimeVersionsRequest: S.Schema<ListAgentRuntimeVersionsRequest>;
export interface ListAgentRuntimeVersionsResponse {
    agentRuntimes: AgentRuntime[];
    nextToken?: string;
}
export declare const ListAgentRuntimeVersionsResponse: S.Schema<ListAgentRuntimeVersionsResponse>;
export interface ListAgentRuntimeVersionsByCapacityProviderInput {
    capacityProviderId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAgentRuntimeVersionsByCapacityProviderInput: S.Schema<ListAgentRuntimeVersionsByCapacityProviderInput>;
export interface AgentRuntimeVersionSummary {
    agentRuntimeArn: string;
    agentRuntimeVersion: string;
    status: AgentRuntimeStatus;
}
export declare const AgentRuntimeVersionSummary: S.Schema<AgentRuntimeVersionSummary>;
export type AgentRuntimeVersionSummaryList = AgentRuntimeVersionSummary[];
export declare const AgentRuntimeVersionSummaryList: any;
export interface ListAgentRuntimeVersionsByCapacityProviderOutput {
    agentRuntimes: AgentRuntimeVersionSummary[];
    nextToken?: string;
}
export declare const ListAgentRuntimeVersionsByCapacityProviderOutput: S.Schema<ListAgentRuntimeVersionsByCapacityProviderOutput>;
export interface ListApiKeyCredentialProvidersRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListApiKeyCredentialProvidersRequest: S.Schema<ListApiKeyCredentialProvidersRequest>;
export interface ApiKeyCredentialProviderItem {
    name: string;
    credentialProviderArn: string;
    createdTime: Date;
    lastUpdatedTime: Date;
}
export declare const ApiKeyCredentialProviderItem: S.Schema<ApiKeyCredentialProviderItem>;
export type ApiKeyCredentialProviders = ApiKeyCredentialProviderItem[];
export declare const ApiKeyCredentialProviders: any;
export interface ListApiKeyCredentialProvidersResponse {
    credentialProviders: ApiKeyCredentialProviderItem[];
    nextToken?: string;
}
export declare const ListApiKeyCredentialProvidersResponse: S.Schema<ListApiKeyCredentialProvidersResponse>;
export interface ListBrowserProfilesRequest {
    maxResults?: number;
    nextToken?: string;
    name?: string;
}
export declare const ListBrowserProfilesRequest: S.Schema<ListBrowserProfilesRequest>;
export interface BrowserProfileSummary {
    profileId: string;
    profileArn: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    status: BrowserProfileStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
    lastSavedAt?: Date;
    lastSavedBrowserSessionId?: string;
    lastSavedBrowserId?: string;
}
export declare const BrowserProfileSummary: S.Schema<BrowserProfileSummary>;
export type BrowserProfileSummaries = BrowserProfileSummary[];
export declare const BrowserProfileSummaries: any;
export interface ListBrowserProfilesResponse {
    profileSummaries: BrowserProfileSummary[];
    nextToken?: string;
}
export declare const ListBrowserProfilesResponse: S.Schema<ListBrowserProfilesResponse>;
export type ResourceType = "SYSTEM" | "CUSTOM" | (string & {});
export declare const ResourceType: any;
export interface ListBrowsersRequest {
    maxResults?: number;
    nextToken?: string;
    type?: ResourceType;
}
export declare const ListBrowsersRequest: S.Schema<ListBrowsersRequest>;
export interface BrowserSummary {
    browserId: string;
    browserArn: string;
    name?: string;
    description?: string | redacted.Redacted<string>;
    status: BrowserStatus;
    createdAt: Date;
    lastUpdatedAt?: Date;
}
export declare const BrowserSummary: S.Schema<BrowserSummary>;
export type BrowserSummaries = BrowserSummary[];
export declare const BrowserSummaries: any;
export interface ListBrowsersResponse {
    browserSummaries: BrowserSummary[];
    nextToken?: string;
}
export declare const ListBrowsersResponse: S.Schema<ListBrowsersResponse>;
export interface ListCapacityProvidersInput {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListCapacityProvidersInput: S.Schema<ListCapacityProvidersInput>;
export interface CapacityProviderSummary {
    capacityProviderId: string;
    capacityProviderArn: string;
    name: string;
    status: CapacityProviderStatus;
    lastUpdatedAt: Date;
}
export declare const CapacityProviderSummary: S.Schema<CapacityProviderSummary>;
export type CapacityProviderList = CapacityProviderSummary[];
export declare const CapacityProviderList: any;
export interface ListCapacityProvidersOutput {
    capacityProviders: CapacityProviderSummary[];
    nextToken?: string;
}
export declare const ListCapacityProvidersOutput: S.Schema<ListCapacityProvidersOutput>;
export interface ListCodeInterpretersRequest {
    maxResults?: number;
    nextToken?: string;
    type?: ResourceType;
}
export declare const ListCodeInterpretersRequest: S.Schema<ListCodeInterpretersRequest>;
export interface CodeInterpreterSummary {
    codeInterpreterId: string;
    codeInterpreterArn: string;
    name?: string;
    description?: string | redacted.Redacted<string>;
    status: CodeInterpreterStatus;
    createdAt: Date;
    lastUpdatedAt?: Date;
}
export declare const CodeInterpreterSummary: S.Schema<CodeInterpreterSummary>;
export type CodeInterpreterSummaries = CodeInterpreterSummary[];
export declare const CodeInterpreterSummaries: any;
export interface ListCodeInterpretersResponse {
    codeInterpreterSummaries: CodeInterpreterSummary[];
    nextToken?: string;
}
export declare const ListCodeInterpretersResponse: S.Schema<ListCodeInterpretersResponse>;
export interface ListConfigurationBundlesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListConfigurationBundlesRequest: S.Schema<ListConfigurationBundlesRequest>;
export interface ConfigurationBundleSummary {
    bundleArn: string;
    bundleId: string;
    bundleName: string;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
}
export declare const ConfigurationBundleSummary: S.Schema<ConfigurationBundleSummary>;
export type ConfigurationBundleSummaryList = ConfigurationBundleSummary[];
export declare const ConfigurationBundleSummaryList: any;
export interface ListConfigurationBundlesResponse {
    bundles: ConfigurationBundleSummary[];
    nextToken?: string;
}
export declare const ListConfigurationBundlesResponse: S.Schema<ListConfigurationBundlesResponse>;
export interface VersionFilter {
    branchName?: string;
    createdByName?: string;
    latestPerBranch?: boolean;
}
export declare const VersionFilter: S.Schema<VersionFilter>;
export interface ListConfigurationBundleVersionsRequest {
    bundleId: string;
    nextToken?: string;
    maxResults?: number;
    filter?: VersionFilter;
}
export declare const ListConfigurationBundleVersionsRequest: S.Schema<ListConfigurationBundleVersionsRequest>;
export interface ConfigurationBundleVersionSummary {
    bundleArn: string;
    bundleId: string;
    versionId: string;
    lineageMetadata?: VersionLineageMetadata;
    versionCreatedAt: Date;
}
export declare const ConfigurationBundleVersionSummary: S.Schema<ConfigurationBundleVersionSummary>;
export type ConfigurationBundleVersionSummaryList = ConfigurationBundleVersionSummary[];
export declare const ConfigurationBundleVersionSummaryList: any;
export interface ListConfigurationBundleVersionsResponse {
    versions: ConfigurationBundleVersionSummary[];
    nextToken?: string;
}
export declare const ListConfigurationBundleVersionsResponse: S.Schema<ListConfigurationBundleVersionsResponse>;
export interface ListDatasetExamplesRequest {
    datasetId: string;
    datasetVersion?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDatasetExamplesRequest: S.Schema<ListDatasetExamplesRequest>;
export interface ListDatasetExamplesResponse {
    datasetArn: string;
    datasetId: string;
    datasetVersion: string;
    examples: any[];
    nextToken?: string;
}
export declare const ListDatasetExamplesResponse: S.Schema<ListDatasetExamplesResponse>;
export interface ListDatasetsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDatasetsRequest: S.Schema<ListDatasetsRequest>;
export interface DatasetSummary {
    datasetArn: string;
    datasetId: string;
    datasetName: string;
    description?: string;
    status: DatasetStatus;
    draftStatus?: DraftStatus;
    schemaType: DatasetSchemaType;
    exampleCount: number;
    createdAt: Date;
    updatedAt: Date;
}
export declare const DatasetSummary: S.Schema<DatasetSummary>;
export type DatasetSummaryList = DatasetSummary[];
export declare const DatasetSummaryList: any;
export interface ListDatasetsResponse {
    datasets: DatasetSummary[];
    nextToken?: string;
}
export declare const ListDatasetsResponse: S.Schema<ListDatasetsResponse>;
export interface ListDatasetVersionsRequest {
    datasetId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDatasetVersionsRequest: S.Schema<ListDatasetVersionsRequest>;
export interface DatasetVersionSummary {
    datasetVersion: string;
    exampleCount: number;
    createdAt: Date;
}
export declare const DatasetVersionSummary: S.Schema<DatasetVersionSummary>;
export type DatasetVersionSummaryList = DatasetVersionSummary[];
export declare const DatasetVersionSummaryList: any;
export interface ListDatasetVersionsResponse {
    versions: DatasetVersionSummary[];
    nextToken?: string;
}
export declare const ListDatasetVersionsResponse: S.Schema<ListDatasetVersionsResponse>;
export interface ListEvaluatorsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListEvaluatorsRequest: S.Schema<ListEvaluatorsRequest>;
export interface EvaluatorSummary {
    evaluatorArn: string;
    evaluatorId: string;
    evaluatorName: string;
    description?: string | redacted.Redacted<string>;
    evaluatorType: EvaluatorType;
    provider?: Provider;
    level?: EvaluatorLevel;
    status: EvaluatorStatus;
    createdAt: Date;
    updatedAt: Date;
    lockedForModification?: boolean;
    kmsKeyArn?: string;
}
export declare const EvaluatorSummary: S.Schema<EvaluatorSummary>;
export type EvaluatorSummaryList = EvaluatorSummary[];
export declare const EvaluatorSummaryList: any;
export interface ListEvaluatorsResponse {
    evaluators: EvaluatorSummary[];
    nextToken?: string;
}
export declare const ListEvaluatorsResponse: S.Schema<ListEvaluatorsResponse>;
export type GatewayRateLimitMaxResults = number;
export type GatewayRateLimitNextToken = string;
export interface ListGatewayRateLimitsRequest {
    gatewayIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListGatewayRateLimitsRequest: S.Schema<ListGatewayRateLimitsRequest>;
export interface ListGatewayRateLimitsResponse {
    rateLimits: GatewayRateLimitDetail[];
    nextToken?: string;
}
export declare const ListGatewayRateLimitsResponse: S.Schema<ListGatewayRateLimitsResponse>;
export type GatewayRuleMaxResults = number;
export type GatewayRuleNextToken = string;
export interface ListGatewayRulesRequest {
    gatewayIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListGatewayRulesRequest: S.Schema<ListGatewayRulesRequest>;
export interface GatewayRuleDetail {
    ruleId: string;
    gatewayArn: string;
    priority: number;
    conditions?: Condition[];
    actions: Action[];
    description?: string;
    createdAt: Date;
    status: GatewayRuleStatus;
    system?: SystemManagedBlock;
    updatedAt?: Date;
}
export declare const GatewayRuleDetail: S.Schema<GatewayRuleDetail>;
export type GatewayRules = GatewayRuleDetail[];
export declare const GatewayRules: any;
export interface ListGatewayRulesResponse {
    gatewayRules: GatewayRuleDetail[];
    nextToken?: string;
}
export declare const ListGatewayRulesResponse: S.Schema<ListGatewayRulesResponse>;
export type GatewayMaxResults = number;
export type GatewayNextToken = string;
export interface ListGatewaysRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListGatewaysRequest: S.Schema<ListGatewaysRequest>;
export interface GatewaySummary {
    gatewayId: string;
    name: string;
    status: GatewayStatus;
    description?: string | redacted.Redacted<string>;
    createdAt: Date;
    updatedAt: Date;
    authorizerType: AuthorizerType;
    protocolType?: GatewayProtocolType;
}
export declare const GatewaySummary: S.Schema<GatewaySummary>;
export type GatewaySummaries = GatewaySummary[];
export declare const GatewaySummaries: any;
export interface ListGatewaysResponse {
    items: GatewaySummary[];
    nextToken?: string;
}
export declare const ListGatewaysResponse: S.Schema<ListGatewaysResponse>;
export type TargetMaxResults = number;
export type TargetNextToken = string;
export interface ListGatewayTargetsRequest {
    gatewayIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListGatewayTargetsRequest: S.Schema<ListGatewayTargetsRequest>;
export type TargetType = "OPEN_API_SCHEMA" | "SMITHY_MODEL" | "MCP_SERVER" | "LAMBDA" | "API_GATEWAY" | "CONNECTOR" | "AGENTCORE_RUNTIME" | "PASSTHROUGH" | "PROVIDER" | "HTTP_CONNECTOR" | (string & {});
export declare const TargetType: any;
export interface TargetSummary {
    targetId: string;
    name: string | redacted.Redacted<string>;
    status: TargetStatus;
    description?: string | redacted.Redacted<string>;
    createdAt: Date;
    updatedAt: Date;
    resourcePriority?: number;
    lastSynchronizedAt?: Date;
    authorizationData?: AuthorizationData;
    targetType?: TargetType;
    listingMode?: ListingMode;
}
export declare const TargetSummary: S.Schema<TargetSummary>;
export type TargetSummaries = TargetSummary[];
export declare const TargetSummaries: any;
export interface ListGatewayTargetsResponse {
    items: TargetSummary[];
    nextToken?: string;
}
export declare const ListGatewayTargetsResponse: S.Schema<ListGatewayTargetsResponse>;
export interface ListHarnessEndpointsRequest {
    harnessId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListHarnessEndpointsRequest: S.Schema<ListHarnessEndpointsRequest>;
export type HarnessEndpoints = HarnessEndpoint[];
export declare const HarnessEndpoints: any;
export interface ListHarnessEndpointsResponse {
    endpoints: HarnessEndpoint[];
    nextToken?: string;
}
export declare const ListHarnessEndpointsResponse: S.Schema<ListHarnessEndpointsResponse>;
export interface ListHarnessesRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListHarnessesRequest: S.Schema<ListHarnessesRequest>;
export interface HarnessSummary {
    harnessId: string;
    harnessName: string;
    arn: string;
    status: HarnessStatus;
    createdAt: Date;
    updatedAt: Date;
    harnessVersion?: string;
}
export declare const HarnessSummary: S.Schema<HarnessSummary>;
export type HarnessSummaries = HarnessSummary[];
export declare const HarnessSummaries: any;
export interface ListHarnessesResponse {
    harnesses: HarnessSummary[];
    nextToken?: string;
}
export declare const ListHarnessesResponse: S.Schema<ListHarnessesResponse>;
export interface ListHarnessVersionsRequest {
    harnessId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListHarnessVersionsRequest: S.Schema<ListHarnessVersionsRequest>;
export interface HarnessVersionSummary {
    harnessId: string;
    harnessName: string;
    arn: string;
    harnessVersion: string;
    status: HarnessStatus;
    createdAt: Date;
    updatedAt: Date;
    failureReason?: string;
}
export declare const HarnessVersionSummary: S.Schema<HarnessVersionSummary>;
export type HarnessVersionSummaries = HarnessVersionSummary[];
export declare const HarnessVersionSummaries: any;
export interface ListHarnessVersionsResponse {
    harnessVersions: HarnessVersionSummary[];
    nextToken?: string;
}
export declare const ListHarnessVersionsResponse: S.Schema<ListHarnessVersionsResponse>;
export interface ListMemoriesInput {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListMemoriesInput: S.Schema<ListMemoriesInput>;
export interface MemorySummary {
    arn?: string;
    id?: string;
    status?: MemoryStatus;
    createdAt: Date;
    updatedAt: Date;
    managedByResourceArn?: string;
}
export declare const MemorySummary: S.Schema<MemorySummary>;
export type MemorySummaryList = MemorySummary[];
export declare const MemorySummaryList: any;
export interface ListMemoriesOutput {
    memories: MemorySummary[];
    nextToken?: string;
}
export declare const ListMemoriesOutput: S.Schema<ListMemoriesOutput>;
export interface ListOauth2CredentialProvidersRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListOauth2CredentialProvidersRequest: S.Schema<ListOauth2CredentialProvidersRequest>;
export interface Oauth2CredentialProviderItem {
    name: string;
    credentialProviderVendor: CredentialProviderVendorType;
    credentialProviderArn: string;
    createdTime: Date;
    lastUpdatedTime: Date;
}
export declare const Oauth2CredentialProviderItem: S.Schema<Oauth2CredentialProviderItem>;
export type Oauth2CredentialProviders = Oauth2CredentialProviderItem[];
export declare const Oauth2CredentialProviders: any;
export interface ListOauth2CredentialProvidersResponse {
    credentialProviders: Oauth2CredentialProviderItem[];
    nextToken?: string;
}
export declare const ListOauth2CredentialProvidersResponse: S.Schema<ListOauth2CredentialProvidersResponse>;
export interface ListOnlineEvaluationConfigsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListOnlineEvaluationConfigsRequest: S.Schema<ListOnlineEvaluationConfigsRequest>;
export interface OnlineEvaluationConfigSummary {
    onlineEvaluationConfigArn: string;
    onlineEvaluationConfigId: string;
    onlineEvaluationConfigName: string;
    description?: string | redacted.Redacted<string>;
    status: OnlineEvaluationConfigStatus;
    executionStatus: OnlineEvaluationExecutionStatus;
    createdAt: Date;
    updatedAt: Date;
    failureReason?: string;
    insights?: Insight[];
    clusteringConfig?: ClusteringConfig;
}
export declare const OnlineEvaluationConfigSummary: S.Schema<OnlineEvaluationConfigSummary>;
export type OnlineEvaluationConfigSummaryList = OnlineEvaluationConfigSummary[];
export declare const OnlineEvaluationConfigSummaryList: any;
export interface ListOnlineEvaluationConfigsResponse {
    onlineEvaluationConfigs: OnlineEvaluationConfigSummary[];
    nextToken?: string;
}
export declare const ListOnlineEvaluationConfigsResponse: S.Schema<ListOnlineEvaluationConfigsResponse>;
export interface ListPaymentConnectorsRequest {
    paymentManagerId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListPaymentConnectorsRequest: S.Schema<ListPaymentConnectorsRequest>;
export interface PaymentConnectorSummary {
    paymentConnectorId: string;
    name: string;
    type: PaymentConnectorType;
    status: PaymentConnectorStatus;
    lastUpdatedAt: Date;
}
export declare const PaymentConnectorSummary: S.Schema<PaymentConnectorSummary>;
export type PaymentConnectorSummaries = PaymentConnectorSummary[];
export declare const PaymentConnectorSummaries: any;
export interface ListPaymentConnectorsResponse {
    paymentConnectors: PaymentConnectorSummary[];
    nextToken?: string;
}
export declare const ListPaymentConnectorsResponse: S.Schema<ListPaymentConnectorsResponse>;
export interface ListPaymentCredentialProvidersRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPaymentCredentialProvidersRequest: S.Schema<ListPaymentCredentialProvidersRequest>;
export interface PaymentCredentialProviderItem {
    name: string;
    credentialProviderVendor: PaymentCredentialProviderVendorType;
    credentialProviderArn: string;
    createdTime: Date;
    lastUpdatedTime: Date;
}
export declare const PaymentCredentialProviderItem: S.Schema<PaymentCredentialProviderItem>;
export type PaymentCredentialProviders = PaymentCredentialProviderItem[];
export declare const PaymentCredentialProviders: any;
export interface ListPaymentCredentialProvidersResponse {
    credentialProviders: PaymentCredentialProviderItem[];
    nextToken?: string;
}
export declare const ListPaymentCredentialProvidersResponse: S.Schema<ListPaymentCredentialProvidersResponse>;
export interface ListPaymentManagersRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListPaymentManagersRequest: S.Schema<ListPaymentManagersRequest>;
export interface PaymentManagerSummary {
    paymentManagerArn: string;
    paymentManagerId: string;
    name: string;
    description?: string;
    authorizerType: PaymentsAuthorizerType;
    roleArn: string;
    status: PaymentManagerStatus;
    createdAt?: Date;
    lastUpdatedAt: Date;
    kmsKeyArn?: string;
}
export declare const PaymentManagerSummary: S.Schema<PaymentManagerSummary>;
export type PaymentManagerSummaries = PaymentManagerSummary[];
export declare const PaymentManagerSummaries: any;
export interface ListPaymentManagersResponse {
    paymentManagers: PaymentManagerSummary[];
    nextToken?: string;
}
export declare const ListPaymentManagersResponse: S.Schema<ListPaymentManagersResponse>;
export interface ListPoliciesRequest {
    nextToken?: string;
    maxResults?: number;
    policyEngineId: string;
    targetResourceScope?: string;
}
export declare const ListPoliciesRequest: S.Schema<ListPoliciesRequest>;
export interface Policy {
    policyId: string;
    name: string;
    policyEngineId: string;
    createdAt: Date;
    updatedAt: Date;
    policyArn: string;
    status: PolicyStatus;
    enforcementMode?: EnforcementMode;
    definition: PolicyDefinition;
    description?: string | redacted.Redacted<string>;
    statusReasons: string[];
}
export declare const Policy: S.Schema<Policy>;
export type Policies = Policy[];
export declare const Policies: any;
export interface ListPoliciesResponse {
    policies: Policy[];
    nextToken?: string;
}
export declare const ListPoliciesResponse: S.Schema<ListPoliciesResponse>;
export interface ListPolicyEnginesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPolicyEnginesRequest: S.Schema<ListPolicyEnginesRequest>;
export interface PolicyEngine {
    policyEngineId: string;
    name: string;
    createdAt: Date;
    updatedAt: Date;
    policyEngineArn: string;
    status: PolicyEngineStatus;
    encryptionKeyArn?: string;
    description?: string | redacted.Redacted<string>;
    statusReasons: string[];
}
export declare const PolicyEngine: S.Schema<PolicyEngine>;
export type PolicyEngines = PolicyEngine[];
export declare const PolicyEngines: any;
export interface ListPolicyEnginesResponse {
    policyEngines: PolicyEngine[];
    nextToken?: string;
}
export declare const ListPolicyEnginesResponse: S.Schema<ListPolicyEnginesResponse>;
export interface ListPolicyEngineSummariesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPolicyEngineSummariesRequest: S.Schema<ListPolicyEngineSummariesRequest>;
export interface PolicyEngineSummary {
    policyEngineId: string;
    name: string;
    createdAt: Date;
    updatedAt: Date;
    policyEngineArn: string;
    status: PolicyEngineStatus;
    encryptionKeyArn?: string;
}
export declare const PolicyEngineSummary: S.Schema<PolicyEngineSummary>;
export type PolicyEngineSummaryList = PolicyEngineSummary[];
export declare const PolicyEngineSummaryList: any;
export interface ListPolicyEngineSummariesResponse {
    policyEngines: PolicyEngineSummary[];
    nextToken?: string;
}
export declare const ListPolicyEngineSummariesResponse: S.Schema<ListPolicyEngineSummariesResponse>;
export interface ListPolicyGenerationAssetsRequest {
    policyGenerationId: string;
    policyEngineId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPolicyGenerationAssetsRequest: S.Schema<ListPolicyGenerationAssetsRequest>;
export type NaturalLanguage = string;
export type FindingType = "VALID" | "INVALID" | "NOT_TRANSLATABLE" | "ALLOW_ALL" | "ALLOW_NONE" | "DENY_ALL" | "DENY_NONE" | (string & {});
export declare const FindingType: any;
export interface Finding {
    type?: FindingType;
    description?: string;
}
export declare const Finding: S.Schema<Finding>;
export type Findings = Finding[];
export declare const Findings: any;
export interface PolicyGenerationAsset {
    policyGenerationAssetId: string;
    definition?: PolicyDefinition;
    rawTextFragment: string;
    findings: Finding[];
}
export declare const PolicyGenerationAsset: S.Schema<PolicyGenerationAsset>;
export type PolicyGenerationAssets = PolicyGenerationAsset[];
export declare const PolicyGenerationAssets: any;
export interface ListPolicyGenerationAssetsResponse {
    policyGenerationAssets?: PolicyGenerationAsset[];
    nextToken?: string;
}
export declare const ListPolicyGenerationAssetsResponse: S.Schema<ListPolicyGenerationAssetsResponse>;
export interface ListPolicyGenerationsRequest {
    nextToken?: string;
    maxResults?: number;
    policyEngineId: string;
}
export declare const ListPolicyGenerationsRequest: S.Schema<ListPolicyGenerationsRequest>;
export interface PolicyGeneration {
    policyEngineId: string;
    policyGenerationId: string;
    name: string;
    policyGenerationArn: string;
    resource: Resource;
    createdAt: Date;
    updatedAt: Date;
    status: PolicyGenerationStatus;
    findings?: string;
    statusReasons: string[];
}
export declare const PolicyGeneration: S.Schema<PolicyGeneration>;
export type PolicyGenerations = PolicyGeneration[];
export declare const PolicyGenerations: any;
export interface ListPolicyGenerationsResponse {
    policyGenerations: PolicyGeneration[];
    nextToken?: string;
}
export declare const ListPolicyGenerationsResponse: S.Schema<ListPolicyGenerationsResponse>;
export interface ListPolicyGenerationSummariesRequest {
    nextToken?: string;
    maxResults?: number;
    policyEngineId: string;
}
export declare const ListPolicyGenerationSummariesRequest: S.Schema<ListPolicyGenerationSummariesRequest>;
export interface PolicyGenerationSummary {
    policyEngineId: string;
    policyGenerationId: string;
    name: string;
    policyGenerationArn: string;
    resource: Resource;
    createdAt: Date;
    updatedAt: Date;
    status: PolicyGenerationStatus;
    findings?: string;
}
export declare const PolicyGenerationSummary: S.Schema<PolicyGenerationSummary>;
export type PolicyGenerationSummaryList = PolicyGenerationSummary[];
export declare const PolicyGenerationSummaryList: any;
export interface ListPolicyGenerationSummariesResponse {
    policyGenerations: PolicyGenerationSummary[];
    nextToken?: string;
}
export declare const ListPolicyGenerationSummariesResponse: S.Schema<ListPolicyGenerationSummariesResponse>;
export interface ListPolicySummariesRequest {
    nextToken?: string;
    maxResults?: number;
    policyEngineId: string;
    targetResourceScope?: string;
}
export declare const ListPolicySummariesRequest: S.Schema<ListPolicySummariesRequest>;
export interface PolicySummary {
    policyId: string;
    name: string;
    policyEngineId: string;
    createdAt: Date;
    updatedAt: Date;
    policyArn: string;
    status: PolicyStatus;
    enforcementMode?: EnforcementMode;
}
export declare const PolicySummary: S.Schema<PolicySummary>;
export type PolicySummaryList = PolicySummary[];
export declare const PolicySummaryList: any;
export interface ListPolicySummariesResponse {
    policies: PolicySummary[];
    nextToken?: string;
}
export declare const ListPolicySummariesResponse: S.Schema<ListPolicySummariesResponse>;
export interface ListRegistriesRequest {
    maxResults?: number;
    nextToken?: string;
    status?: RegistryStatus;
    authorizerType?: RegistryAuthorizerType;
}
export declare const ListRegistriesRequest: S.Schema<ListRegistriesRequest>;
export interface RegistrySummary {
    name: string;
    description?: string | redacted.Redacted<string>;
    registryId: string;
    registryArn: string;
    authorizerType?: RegistryAuthorizerType;
    status: RegistryStatus;
    statusReason?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const RegistrySummary: S.Schema<RegistrySummary>;
export type RegistrySummaryList = RegistrySummary[];
export declare const RegistrySummaryList: any;
export interface ListRegistriesResponse {
    registries: RegistrySummary[];
    nextToken?: string;
}
export declare const ListRegistriesResponse: S.Schema<ListRegistriesResponse>;
export interface ListRegistryRecordsRequest {
    registryId: string;
    maxResults?: number;
    nextToken?: string;
    name?: string;
    status?: RegistryRecordStatus;
    descriptorType?: DescriptorType;
}
export declare const ListRegistryRecordsRequest: S.Schema<ListRegistryRecordsRequest>;
export interface RegistryRecordSummary {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    descriptorType: DescriptorType;
    recordVersion: string;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const RegistryRecordSummary: S.Schema<RegistryRecordSummary>;
export type RegistryRecordSummaryList = RegistryRecordSummary[];
export declare const RegistryRecordSummaryList: any;
export interface ListRegistryRecordsResponse {
    registryRecords: RegistryRecordSummary[];
    nextToken?: string;
}
export declare const ListRegistryRecordsResponse: S.Schema<ListRegistryRecordsResponse>;
export type TaggableResourcesArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListWorkloadIdentitiesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListWorkloadIdentitiesRequest: S.Schema<ListWorkloadIdentitiesRequest>;
export interface WorkloadIdentityType {
    name: string;
    workloadIdentityArn: string;
}
export declare const WorkloadIdentityType: S.Schema<WorkloadIdentityType>;
export type WorkloadIdentityList = WorkloadIdentityType[];
export declare const WorkloadIdentityList: any;
export interface ListWorkloadIdentitiesResponse {
    workloadIdentities: WorkloadIdentityType[];
    nextToken?: string;
}
export declare const ListWorkloadIdentitiesResponse: S.Schema<ListWorkloadIdentitiesResponse>;
export interface PutResourcePolicyRequest {
    resourceArn: string;
    policy: string;
}
export declare const PutResourcePolicyRequest: S.Schema<PutResourcePolicyRequest>;
export interface PutResourcePolicyResponse {
    policy: string;
}
export declare const PutResourcePolicyResponse: S.Schema<PutResourcePolicyResponse>;
export interface SetTokenVaultCMKRequest {
    tokenVaultId?: string;
    kmsConfiguration: KmsConfiguration;
}
export declare const SetTokenVaultCMKRequest: S.Schema<SetTokenVaultCMKRequest>;
export interface SetTokenVaultCMKResponse {
    tokenVaultId: string;
    kmsConfiguration: KmsConfiguration;
    lastModifiedDate: Date;
}
export declare const SetTokenVaultCMKResponse: S.Schema<SetTokenVaultCMKResponse>;
export type Content = {
    rawText: string;
};
export declare const Content: any;
export interface StartPolicyGenerationRequest {
    policyEngineId: string;
    resource: Resource;
    content: Content;
    name: string;
    clientToken?: string;
}
export declare const StartPolicyGenerationRequest: S.Schema<StartPolicyGenerationRequest>;
export interface StartPolicyGenerationResponse {
    policyEngineId: string;
    policyGenerationId: string;
    name: string;
    policyGenerationArn: string;
    resource: Resource;
    createdAt: Date;
    updatedAt: Date;
    status: PolicyGenerationStatus;
    findings?: string;
    statusReasons: string[];
}
export declare const StartPolicyGenerationResponse: S.Schema<StartPolicyGenerationResponse>;
export interface SubmitRegistryRecordForApprovalRequest {
    registryId: string;
    recordId: string;
}
export declare const SubmitRegistryRecordForApprovalRequest: S.Schema<SubmitRegistryRecordForApprovalRequest>;
export interface SubmitRegistryRecordForApprovalResponse {
    registryArn: string;
    recordArn: string;
    recordId: string;
    status: RegistryRecordStatus;
    updatedAt: Date;
}
export declare const SubmitRegistryRecordForApprovalResponse: S.Schema<SubmitRegistryRecordForApprovalResponse>;
export type TargetIdList = string[];
export declare const TargetIdList: any;
export interface SynchronizeGatewayTargetsRequest {
    gatewayIdentifier: string;
    targetIdList: string[];
}
export declare const SynchronizeGatewayTargetsRequest: S.Schema<SynchronizeGatewayTargetsRequest>;
export interface GatewayTarget {
    gatewayArn: string;
    targetId: string;
    createdAt: Date;
    updatedAt: Date;
    status: TargetStatus;
    statusReasons?: string[];
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    targetConfiguration: TargetConfiguration;
    credentialProviderConfigurations: CredentialProviderConfiguration[];
    lastSynchronizedAt?: Date;
    metadataConfiguration?: MetadataConfiguration;
    privateEndpoint?: PrivateEndpoint;
    privateEndpointManagedResources?: ManagedResourceDetails[];
    authorizationData?: AuthorizationData;
    protocolType?: TargetProtocolType;
}
export declare const GatewayTarget: S.Schema<GatewayTarget>;
export type GatewayTargetList = GatewayTarget[];
export declare const GatewayTargetList: any;
export interface SynchronizeGatewayTargetsResponse {
    targets?: GatewayTarget[];
}
export declare const SynchronizeGatewayTargetsResponse: S.Schema<SynchronizeGatewayTargetsResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAgentRuntimeRequest {
    agentRuntimeId: string;
    agentRuntimeArtifact: AgentRuntimeArtifact;
    roleArn: string;
    networkConfiguration?: NetworkConfiguration;
    description?: string | redacted.Redacted<string>;
    authorizerConfiguration?: AuthorizerConfiguration;
    requestHeaderConfiguration?: RequestHeaderConfiguration;
    protocolConfiguration?: ProtocolConfiguration;
    lifecycleConfiguration?: LifecycleConfiguration;
    metadataConfiguration?: RuntimeMetadataConfiguration;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    filesystemConfigurations?: FilesystemConfiguration[];
    capacityProviderConfiguration?: CapacityProviderConfiguration;
    clientToken?: string;
}
export declare const UpdateAgentRuntimeRequest: S.Schema<UpdateAgentRuntimeRequest>;
export interface UpdateAgentRuntimeResponse {
    agentRuntimeArn: string;
    agentRuntimeId: string;
    workloadIdentityDetails?: WorkloadIdentityDetails;
    agentRuntimeVersion: string;
    createdAt: Date;
    lastUpdatedAt: Date;
    status: AgentRuntimeStatus;
}
export declare const UpdateAgentRuntimeResponse: S.Schema<UpdateAgentRuntimeResponse>;
export interface UpdateAgentRuntimeEndpointRequest {
    agentRuntimeId: string;
    endpointName: string | redacted.Redacted<string>;
    agentRuntimeVersion?: string;
    description?: string;
    clientToken?: string;
}
export declare const UpdateAgentRuntimeEndpointRequest: S.Schema<UpdateAgentRuntimeEndpointRequest>;
export interface UpdateAgentRuntimeEndpointResponse {
    liveVersion?: string;
    targetVersion?: string;
    agentRuntimeEndpointArn: string;
    agentRuntimeArn: string;
    status: AgentRuntimeEndpointStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export declare const UpdateAgentRuntimeEndpointResponse: S.Schema<UpdateAgentRuntimeEndpointResponse>;
export interface UpdateApiKeyCredentialProviderRequest {
    name: string;
    apiKey?: string | redacted.Redacted<string>;
    apiKeySecretConfig?: SecretReference;
    apiKeySecretSource?: SecretSourceType;
}
export declare const UpdateApiKeyCredentialProviderRequest: S.Schema<UpdateApiKeyCredentialProviderRequest>;
export interface UpdateApiKeyCredentialProviderResponse {
    apiKeySecretArn: Secret;
    apiKeySecretJsonKey?: string;
    apiKeySecretSource?: SecretSourceType;
    name: string;
    credentialProviderArn: string;
    createdTime: Date;
    lastUpdatedTime: Date;
}
export declare const UpdateApiKeyCredentialProviderResponse: S.Schema<UpdateApiKeyCredentialProviderResponse>;
export interface UpdatedDescription {
    optionalValue?: string | redacted.Redacted<string>;
}
export declare const UpdatedDescription: S.Schema<UpdatedDescription>;
export interface UpdateCapacityProviderInput {
    capacityProviderId: string;
    description?: UpdatedDescription;
    clientToken?: string;
}
export declare const UpdateCapacityProviderInput: S.Schema<UpdateCapacityProviderInput>;
export interface UpdateCapacityProviderOutput {
    capacityProviderId: string;
    capacityProviderArn: string;
    name: string;
    status: CapacityProviderStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export declare const UpdateCapacityProviderOutput: S.Schema<UpdateCapacityProviderOutput>;
export interface UpdateConfigurationBundleRequest {
    clientToken?: string;
    bundleId: string;
    bundleName?: string;
    description?: string | redacted.Redacted<string>;
    components?: {
        [key: string]: ComponentConfiguration | undefined;
    };
    parentVersionIds?: string[];
    branchName?: string;
    commitMessage?: string;
    createdBy?: VersionCreatedBySource;
    kmsKeyArn?: string;
}
export declare const UpdateConfigurationBundleRequest: S.Schema<UpdateConfigurationBundleRequest>;
export interface UpdateConfigurationBundleResponse {
    bundleArn: string;
    bundleId: string;
    versionId: string;
    updatedAt: Date;
}
export declare const UpdateConfigurationBundleResponse: S.Schema<UpdateConfigurationBundleResponse>;
export interface UpdateDatasetRequest {
    datasetId: string;
    clientToken?: string;
    description?: string;
}
export declare const UpdateDatasetRequest: S.Schema<UpdateDatasetRequest>;
export interface UpdateDatasetResponse {
    datasetArn: string;
    datasetId: string;
    updatedAt: Date;
}
export declare const UpdateDatasetResponse: S.Schema<UpdateDatasetResponse>;
export interface UpdateDatasetExamplesRequest {
    datasetId: string;
    clientToken?: string;
    examples: any[];
}
export declare const UpdateDatasetExamplesRequest: S.Schema<UpdateDatasetExamplesRequest>;
export interface UpdateDatasetExamplesResponse {
    datasetArn: string;
    datasetId: string;
    status: DatasetStatus;
    updatedCount: number;
    updatedAt: Date;
}
export declare const UpdateDatasetExamplesResponse: S.Schema<UpdateDatasetExamplesResponse>;
export interface UpdateEvaluatorRequest {
    clientToken?: string;
    evaluatorId: string;
    description?: string | redacted.Redacted<string>;
    evaluatorConfig?: EvaluatorConfig;
    level?: EvaluatorLevel;
    kmsKeyArn?: string;
}
export declare const UpdateEvaluatorRequest: S.Schema<UpdateEvaluatorRequest>;
export interface UpdateEvaluatorResponse {
    evaluatorArn: string;
    evaluatorId: string;
    updatedAt: Date;
    status: EvaluatorStatus;
}
export declare const UpdateEvaluatorResponse: S.Schema<UpdateEvaluatorResponse>;
export interface UpdateGatewayRequest {
    gatewayIdentifier: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    roleArn: string;
    protocolType?: GatewayProtocolType;
    protocolConfiguration?: GatewayProtocolConfiguration;
    authorizerType: AuthorizerType;
    authorizerConfiguration?: AuthorizerConfiguration;
    kmsKeyArn?: string;
    customTransformConfiguration?: CustomTransformConfiguration;
    interceptorConfigurations?: GatewayInterceptorConfiguration[];
    policyEngineConfiguration?: GatewayPolicyEngineConfiguration;
    exceptionLevel?: ExceptionLevel;
    wafConfiguration?: WafConfiguration;
}
export declare const UpdateGatewayRequest: S.Schema<UpdateGatewayRequest>;
export interface UpdateGatewayResponse {
    gatewayArn: string;
    gatewayId: string;
    gatewayUrl?: string;
    createdAt: Date;
    updatedAt: Date;
    status: GatewayStatus;
    statusReasons?: string[];
    name: string;
    description?: string | redacted.Redacted<string>;
    roleArn?: string;
    protocolType?: GatewayProtocolType;
    protocolConfiguration?: GatewayProtocolConfiguration;
    authorizerType: AuthorizerType;
    authorizerConfiguration?: AuthorizerConfiguration;
    kmsKeyArn?: string;
    customTransformConfiguration?: CustomTransformConfiguration;
    interceptorConfigurations?: GatewayInterceptorConfiguration[];
    policyEngineConfiguration?: GatewayPolicyEngineConfiguration;
    workloadIdentityDetails?: WorkloadIdentityDetails;
    exceptionLevel?: ExceptionLevel;
    webAclArn?: string;
    wafConfiguration?: WafConfiguration;
}
export declare const UpdateGatewayResponse: S.Schema<UpdateGatewayResponse>;
export interface UpdateGatewayRateLimitRequest {
    gatewayIdentifier: string;
    rateLimitId: string;
    description?: string;
    entries: LimitEntry[];
}
export declare const UpdateGatewayRateLimitRequest: S.Schema<UpdateGatewayRateLimitRequest>;
export interface UpdateGatewayRateLimitResponse {
    rateLimitId: string;
    gatewayIdentifier: string;
    description?: string;
    dimensionKeys: string[];
    entries: LimitEntry[];
    status: GatewayRateLimitStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const UpdateGatewayRateLimitResponse: S.Schema<UpdateGatewayRateLimitResponse>;
export interface UpdateGatewayRuleRequest {
    gatewayIdentifier: string;
    ruleId: string;
    priority?: number;
    conditions?: Condition[];
    actions?: Action[];
    description?: string;
}
export declare const UpdateGatewayRuleRequest: S.Schema<UpdateGatewayRuleRequest>;
export interface UpdateGatewayRuleResponse {
    ruleId: string;
    gatewayArn: string;
    priority: number;
    conditions?: Condition[];
    actions: Action[];
    description?: string;
    createdAt: Date;
    status: GatewayRuleStatus;
    system?: SystemManagedBlock;
    updatedAt?: Date;
}
export declare const UpdateGatewayRuleResponse: S.Schema<UpdateGatewayRuleResponse>;
export interface UpdateGatewayTargetRequest {
    gatewayIdentifier: string;
    targetId: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    targetConfiguration: TargetConfiguration;
    credentialProviderConfigurations?: CredentialProviderConfiguration[];
    metadataConfiguration?: MetadataConfiguration;
    privateEndpoint?: PrivateEndpoint;
}
export declare const UpdateGatewayTargetRequest: S.Schema<UpdateGatewayTargetRequest>;
export interface UpdateGatewayTargetResponse {
    gatewayArn: string;
    targetId: string;
    createdAt: Date;
    updatedAt: Date;
    status: TargetStatus;
    statusReasons?: string[];
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    targetConfiguration: TargetConfiguration;
    credentialProviderConfigurations: CredentialProviderConfiguration[];
    lastSynchronizedAt?: Date;
    metadataConfiguration?: MetadataConfiguration;
    privateEndpoint?: PrivateEndpoint;
    privateEndpointManagedResources?: ManagedResourceDetails[];
    authorizationData?: AuthorizationData;
    protocolType?: TargetProtocolType;
}
export declare const UpdateGatewayTargetResponse: S.Schema<UpdateGatewayTargetResponse>;
export interface UpdatedHarnessEnvironmentArtifact {
    optionalValue?: HarnessEnvironmentArtifact;
}
export declare const UpdatedHarnessEnvironmentArtifact: S.Schema<UpdatedHarnessEnvironmentArtifact>;
export interface UpdatedAuthorizerConfiguration {
    optionalValue?: AuthorizerConfiguration;
}
export declare const UpdatedAuthorizerConfiguration: S.Schema<UpdatedAuthorizerConfiguration>;
export interface UpdatedHarnessMemoryConfiguration {
    optionalValue?: HarnessMemoryConfiguration;
}
export declare const UpdatedHarnessMemoryConfiguration: S.Schema<UpdatedHarnessMemoryConfiguration>;
export interface UpdateHarnessRequest {
    harnessId: string;
    clientToken?: string;
    executionRoleArn?: string;
    environment?: HarnessEnvironmentProviderRequest;
    environmentArtifact?: UpdatedHarnessEnvironmentArtifact;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    authorizerConfiguration?: UpdatedAuthorizerConfiguration;
    model?: HarnessModelConfiguration;
    systemPrompt?: HarnessSystemContentBlock[];
    tools?: HarnessTool[];
    skills?: HarnessSkill[];
    allowedTools?: string[];
    memory?: UpdatedHarnessMemoryConfiguration;
    truncation?: HarnessTruncationConfiguration;
    maxIterations?: number;
    maxTokens?: number;
    timeoutSeconds?: number;
}
export declare const UpdateHarnessRequest: S.Schema<UpdateHarnessRequest>;
export interface UpdateHarnessResponse {
    harness: Harness;
}
export declare const UpdateHarnessResponse: S.Schema<UpdateHarnessResponse>;
export interface UpdateHarnessEndpointRequest {
    harnessId: string;
    endpointName: string;
    targetVersion?: string;
    description?: string;
    clientToken?: string;
}
export declare const UpdateHarnessEndpointRequest: S.Schema<UpdateHarnessEndpointRequest>;
export interface UpdateHarnessEndpointResponse {
    endpoint: HarnessEndpoint;
}
export declare const UpdateHarnessEndpointResponse: S.Schema<UpdateHarnessEndpointResponse>;
export type CustomExtractionConfigurationInput = {
    semanticExtractionOverride: SemanticOverrideExtractionConfigurationInput;
    userPreferenceExtractionOverride?: never;
    episodicExtractionOverride?: never;
} | {
    semanticExtractionOverride?: never;
    userPreferenceExtractionOverride: UserPreferenceOverrideExtractionConfigurationInput;
    episodicExtractionOverride?: never;
} | {
    semanticExtractionOverride?: never;
    userPreferenceExtractionOverride?: never;
    episodicExtractionOverride: EpisodicOverrideExtractionConfigurationInput;
};
export declare const CustomExtractionConfigurationInput: any;
export type ModifyExtractionConfiguration = {
    customExtractionConfiguration: CustomExtractionConfigurationInput;
};
export declare const ModifyExtractionConfiguration: any;
export type CustomConsolidationConfigurationInput = {
    semanticConsolidationOverride: SemanticOverrideConsolidationConfigurationInput;
    summaryConsolidationOverride?: never;
    userPreferenceConsolidationOverride?: never;
    episodicConsolidationOverride?: never;
} | {
    semanticConsolidationOverride?: never;
    summaryConsolidationOverride: SummaryOverrideConsolidationConfigurationInput;
    userPreferenceConsolidationOverride?: never;
    episodicConsolidationOverride?: never;
} | {
    semanticConsolidationOverride?: never;
    summaryConsolidationOverride?: never;
    userPreferenceConsolidationOverride: UserPreferenceOverrideConsolidationConfigurationInput;
    episodicConsolidationOverride?: never;
} | {
    semanticConsolidationOverride?: never;
    summaryConsolidationOverride?: never;
    userPreferenceConsolidationOverride?: never;
    episodicConsolidationOverride: EpisodicOverrideConsolidationConfigurationInput;
};
export declare const CustomConsolidationConfigurationInput: any;
export type ModifyConsolidationConfiguration = {
    customConsolidationConfiguration: CustomConsolidationConfigurationInput;
};
export declare const ModifyConsolidationConfiguration: any;
export type CustomReflectionConfigurationInput = {
    episodicReflectionOverride: EpisodicOverrideReflectionConfigurationInput;
};
export declare const CustomReflectionConfigurationInput: any;
export type ModifyReflectionConfiguration = {
    episodicReflectionConfiguration: EpisodicReflectionConfigurationInput;
    customReflectionConfiguration?: never;
} | {
    episodicReflectionConfiguration?: never;
    customReflectionConfiguration: CustomReflectionConfigurationInput;
};
export declare const ModifyReflectionConfiguration: any;
export interface ModifyInvocationConfigurationInput {
    topicArn?: string;
    payloadDeliveryBucketName?: string;
}
export declare const ModifyInvocationConfigurationInput: S.Schema<ModifyInvocationConfigurationInput>;
export interface ModifySelfManagedConfiguration {
    triggerConditions?: TriggerConditionInput[];
    invocationConfiguration?: ModifyInvocationConfigurationInput;
    historicalContextWindowSize?: number;
}
export declare const ModifySelfManagedConfiguration: S.Schema<ModifySelfManagedConfiguration>;
export interface ModifyStrategyConfiguration {
    extraction?: ModifyExtractionConfiguration;
    consolidation?: ModifyConsolidationConfiguration;
    reflection?: ModifyReflectionConfiguration;
    selfManagedConfiguration?: ModifySelfManagedConfiguration;
}
export declare const ModifyStrategyConfiguration: S.Schema<ModifyStrategyConfiguration>;
export interface ModifyMemoryStrategyInput {
    memoryStrategyId: string;
    description?: string | redacted.Redacted<string>;
    namespaces?: string[];
    namespaceTemplates?: string[];
    configuration?: ModifyStrategyConfiguration;
    memoryRecordSchema?: MemoryRecordSchema;
}
export declare const ModifyMemoryStrategyInput: S.Schema<ModifyMemoryStrategyInput>;
export type ModifyMemoryStrategiesList = ModifyMemoryStrategyInput[];
export declare const ModifyMemoryStrategiesList: any;
export interface DeleteMemoryStrategyInput {
    memoryStrategyId: string;
}
export declare const DeleteMemoryStrategyInput: S.Schema<DeleteMemoryStrategyInput>;
export type DeleteMemoryStrategiesList = DeleteMemoryStrategyInput[];
export declare const DeleteMemoryStrategiesList: any;
export interface ModifyMemoryStrategies {
    addMemoryStrategies?: MemoryStrategyInput[];
    modifyMemoryStrategies?: ModifyMemoryStrategyInput[];
    deleteMemoryStrategies?: DeleteMemoryStrategyInput[];
}
export declare const ModifyMemoryStrategies: S.Schema<ModifyMemoryStrategies>;
export interface UpdateMemoryInput {
    clientToken?: string;
    memoryId: string;
    description?: string | redacted.Redacted<string>;
    eventExpiryDuration?: number;
    memoryExecutionRoleArn?: string;
    memoryStrategies?: ModifyMemoryStrategies;
    addIndexedKeys?: IndexedKey[];
    namespaceKeys?: NamespaceKeyEntry[];
    streamDeliveryResources?: StreamDeliveryResources;
}
export declare const UpdateMemoryInput: S.Schema<UpdateMemoryInput>;
export interface UpdateMemoryOutput {
    memory?: Memory;
}
export declare const UpdateMemoryOutput: S.Schema<UpdateMemoryOutput>;
export interface UpdateOauth2CredentialProviderRequest {
    name: string;
    credentialProviderVendor: CredentialProviderVendorType;
    oauth2ProviderConfigInput: Oauth2ProviderConfigInput;
}
export declare const UpdateOauth2CredentialProviderRequest: S.Schema<UpdateOauth2CredentialProviderRequest>;
export interface UpdateOauth2CredentialProviderResponse {
    clientSecretArn: Secret;
    clientSecretJsonKey?: string;
    clientSecretSource?: SecretSourceType;
    name: string;
    credentialProviderVendor: CredentialProviderVendorType;
    credentialProviderArn: string;
    callbackUrl?: string;
    oauth2ProviderConfigOutput: Oauth2ProviderConfigOutput;
    createdTime: Date;
    lastUpdatedTime: Date;
    status?: Status;
}
export declare const UpdateOauth2CredentialProviderResponse: S.Schema<UpdateOauth2CredentialProviderResponse>;
export interface UpdateOnlineEvaluationConfigRequest {
    clientToken?: string;
    onlineEvaluationConfigId: string;
    description?: string | redacted.Redacted<string>;
    rule?: Rule;
    dataSourceConfig?: DataSourceConfig;
    evaluators?: EvaluatorReference[];
    insights?: Insight[];
    clusteringConfig?: ClusteringConfig;
    evaluationExecutionRoleArn?: string;
    executionStatus?: OnlineEvaluationExecutionStatus;
}
export declare const UpdateOnlineEvaluationConfigRequest: S.Schema<UpdateOnlineEvaluationConfigRequest>;
export interface UpdateOnlineEvaluationConfigResponse {
    onlineEvaluationConfigArn: string;
    onlineEvaluationConfigId: string;
    updatedAt: Date;
    status: OnlineEvaluationConfigStatus;
    executionStatus: OnlineEvaluationExecutionStatus;
    failureReason?: string;
}
export declare const UpdateOnlineEvaluationConfigResponse: S.Schema<UpdateOnlineEvaluationConfigResponse>;
export interface UpdatePaymentConnectorRequest {
    paymentManagerId: string;
    paymentConnectorId: string;
    description?: string;
    type?: PaymentConnectorType;
    credentialProviderConfigurations?: CredentialsProviderConfiguration[];
    clientToken?: string;
}
export declare const UpdatePaymentConnectorRequest: S.Schema<UpdatePaymentConnectorRequest>;
export interface UpdatePaymentConnectorResponse {
    paymentConnectorId: string;
    paymentManagerId: string;
    name: string;
    type: PaymentConnectorType;
    credentialProviderConfigurations: CredentialsProviderConfiguration[];
    lastUpdatedAt: Date;
    status: PaymentConnectorStatus;
    authorizationUrl?: string;
}
export declare const UpdatePaymentConnectorResponse: S.Schema<UpdatePaymentConnectorResponse>;
export interface UpdatePaymentCredentialProviderRequest {
    name: string;
    credentialProviderVendor: PaymentCredentialProviderVendorType;
    providerConfigurationInput: PaymentProviderConfigurationInput;
}
export declare const UpdatePaymentCredentialProviderRequest: S.Schema<UpdatePaymentCredentialProviderRequest>;
export interface UpdatePaymentCredentialProviderResponse {
    name: string;
    credentialProviderVendor: PaymentCredentialProviderVendorType;
    credentialProviderArn: string;
    providerConfigurationOutput: PaymentProviderConfigurationOutput;
    createdTime: Date;
    lastUpdatedTime: Date;
}
export declare const UpdatePaymentCredentialProviderResponse: S.Schema<UpdatePaymentCredentialProviderResponse>;
export interface UpdatePaymentManagerRequest {
    paymentManagerId: string;
    description?: string;
    authorizerType?: PaymentsAuthorizerType;
    authorizerConfiguration?: AuthorizerConfiguration;
    roleArn?: string;
    clientToken?: string;
    kmsKeyArn?: string;
}
export declare const UpdatePaymentManagerRequest: S.Schema<UpdatePaymentManagerRequest>;
export interface UpdatePaymentManagerResponse {
    paymentManagerArn: string;
    paymentManagerId: string;
    name: string;
    authorizerType: PaymentsAuthorizerType;
    roleArn: string;
    workloadIdentityDetails?: WorkloadIdentityDetails;
    lastUpdatedAt: Date;
    status: PaymentManagerStatus;
    kmsKeyArn?: string;
}
export declare const UpdatePaymentManagerResponse: S.Schema<UpdatePaymentManagerResponse>;
export interface UpdatePolicyRequest {
    policyEngineId: string;
    policyId: string;
    description?: UpdatedDescription;
    definition?: PolicyDefinition;
    validationMode?: PolicyValidationMode;
    enforcementMode?: EnforcementMode;
}
export declare const UpdatePolicyRequest: S.Schema<UpdatePolicyRequest>;
export interface UpdatePolicyResponse {
    policyId: string;
    name: string;
    policyEngineId: string;
    createdAt: Date;
    updatedAt: Date;
    policyArn: string;
    status: PolicyStatus;
    enforcementMode?: EnforcementMode;
    definition: PolicyDefinition;
    description?: string | redacted.Redacted<string>;
    statusReasons: string[];
}
export declare const UpdatePolicyResponse: S.Schema<UpdatePolicyResponse>;
export interface UpdatePolicyEngineRequest {
    policyEngineId: string;
    description?: UpdatedDescription;
}
export declare const UpdatePolicyEngineRequest: S.Schema<UpdatePolicyEngineRequest>;
export interface UpdatePolicyEngineResponse {
    policyEngineId: string;
    name: string;
    createdAt: Date;
    updatedAt: Date;
    policyEngineArn: string;
    status: PolicyEngineStatus;
    encryptionKeyArn?: string;
    description?: string | redacted.Redacted<string>;
    statusReasons: string[];
}
export declare const UpdatePolicyEngineResponse: S.Schema<UpdatePolicyEngineResponse>;
export interface UpdatedApprovalConfiguration {
    optionalValue?: ApprovalConfiguration;
}
export declare const UpdatedApprovalConfiguration: S.Schema<UpdatedApprovalConfiguration>;
export interface UpdateRegistryRequest {
    registryId: string;
    name?: string;
    description?: UpdatedDescription;
    authorizerConfiguration?: UpdatedAuthorizerConfiguration;
    approvalConfiguration?: UpdatedApprovalConfiguration;
}
export declare const UpdateRegistryRequest: S.Schema<UpdateRegistryRequest>;
export interface UpdateRegistryResponse {
    name: string;
    description?: string | redacted.Redacted<string>;
    registryId: string;
    registryArn: string;
    authorizerType?: RegistryAuthorizerType;
    authorizerConfiguration?: AuthorizerConfiguration;
    approvalConfiguration?: ApprovalConfiguration;
    status: RegistryStatus;
    statusReason?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const UpdateRegistryResponse: S.Schema<UpdateRegistryResponse>;
export interface UpdatedServerDefinition {
    optionalValue?: ServerDefinition;
}
export declare const UpdatedServerDefinition: S.Schema<UpdatedServerDefinition>;
export interface UpdatedToolsDefinition {
    optionalValue?: ToolsDefinition;
}
export declare const UpdatedToolsDefinition: S.Schema<UpdatedToolsDefinition>;
export interface UpdatedMcpDescriptorFields {
    server?: UpdatedServerDefinition;
    tools?: UpdatedToolsDefinition;
}
export declare const UpdatedMcpDescriptorFields: S.Schema<UpdatedMcpDescriptorFields>;
export interface UpdatedMcpDescriptor {
    optionalValue?: UpdatedMcpDescriptorFields;
}
export declare const UpdatedMcpDescriptor: S.Schema<UpdatedMcpDescriptor>;
export interface UpdatedA2aDescriptor {
    optionalValue?: A2aDescriptor;
}
export declare const UpdatedA2aDescriptor: S.Schema<UpdatedA2aDescriptor>;
export interface UpdatedCustomDescriptor {
    optionalValue?: CustomDescriptor;
}
export declare const UpdatedCustomDescriptor: S.Schema<UpdatedCustomDescriptor>;
export interface UpdatedSkillMdDefinition {
    optionalValue?: SkillMdDefinition;
}
export declare const UpdatedSkillMdDefinition: S.Schema<UpdatedSkillMdDefinition>;
export interface UpdatedSkillDefinition {
    optionalValue?: SkillDefinition;
}
export declare const UpdatedSkillDefinition: S.Schema<UpdatedSkillDefinition>;
export interface UpdatedAgentSkillsDescriptorFields {
    skillMd?: UpdatedSkillMdDefinition;
    skillDefinition?: UpdatedSkillDefinition;
}
export declare const UpdatedAgentSkillsDescriptorFields: S.Schema<UpdatedAgentSkillsDescriptorFields>;
export interface UpdatedAgentSkillsDescriptor {
    optionalValue?: UpdatedAgentSkillsDescriptorFields;
}
export declare const UpdatedAgentSkillsDescriptor: S.Schema<UpdatedAgentSkillsDescriptor>;
export interface UpdatedDescriptorsUnion {
    mcp?: UpdatedMcpDescriptor;
    a2a?: UpdatedA2aDescriptor;
    custom?: UpdatedCustomDescriptor;
    agentSkills?: UpdatedAgentSkillsDescriptor;
}
export declare const UpdatedDescriptorsUnion: S.Schema<UpdatedDescriptorsUnion>;
export interface UpdatedDescriptors {
    optionalValue?: UpdatedDescriptorsUnion;
}
export declare const UpdatedDescriptors: S.Schema<UpdatedDescriptors>;
export interface UpdatedSynchronizationType {
    optionalValue?: SynchronizationType;
}
export declare const UpdatedSynchronizationType: S.Schema<UpdatedSynchronizationType>;
export interface UpdatedSynchronizationConfiguration {
    optionalValue?: SynchronizationConfiguration;
}
export declare const UpdatedSynchronizationConfiguration: S.Schema<UpdatedSynchronizationConfiguration>;
export interface UpdateRegistryRecordRequest {
    registryId: string;
    recordId: string;
    name?: string;
    description?: UpdatedDescription;
    descriptorType?: DescriptorType;
    descriptors?: UpdatedDescriptors;
    recordVersion?: string;
    synchronizationType?: UpdatedSynchronizationType;
    synchronizationConfiguration?: UpdatedSynchronizationConfiguration;
    triggerSynchronization?: boolean;
}
export declare const UpdateRegistryRecordRequest: S.Schema<UpdateRegistryRecordRequest>;
export interface UpdateRegistryRecordResponse {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    descriptorType: DescriptorType;
    descriptors: Descriptors;
    recordVersion?: string;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
    statusReason?: string;
    synchronizationType?: SynchronizationType;
    synchronizationConfiguration?: SynchronizationConfiguration;
}
export declare const UpdateRegistryRecordResponse: S.Schema<UpdateRegistryRecordResponse>;
export interface UpdateRegistryRecordStatusRequest {
    registryId: string;
    recordId: string;
    status: RegistryRecordStatus;
    statusReason: string;
}
export declare const UpdateRegistryRecordStatusRequest: S.Schema<UpdateRegistryRecordStatusRequest>;
export interface UpdateRegistryRecordStatusResponse {
    registryArn: string;
    recordArn: string;
    recordId: string;
    status: RegistryRecordStatus;
    statusReason: string;
    updatedAt: Date;
}
export declare const UpdateRegistryRecordStatusResponse: S.Schema<UpdateRegistryRecordStatusResponse>;
export interface UpdateWorkloadIdentityRequest {
    name: string;
    allowedResourceOauth2ReturnUrls?: string[];
}
export declare const UpdateWorkloadIdentityRequest: S.Schema<UpdateWorkloadIdentityRequest>;
export interface UpdateWorkloadIdentityResponse {
    name: string;
    workloadIdentityArn: string;
    allowedResourceOauth2ReturnUrls?: string[];
    createdTime: Date;
    lastUpdatedTime: Date;
}
export declare const UpdateWorkloadIdentityResponse: S.Schema<UpdateWorkloadIdentityResponse>;
export type NonBlankString = string;
export type ValidationExceptionReason = "CannotParse" | "FieldValidationFailed" | "IdempotentParameterMismatchException" | "EventInOtherSession" | "ResourceConflict" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type AddDatasetExamplesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds examples to the dataset's DRAFT. All examples are validated against the dataset's schema type before any writes occur. If any example fails validation, the entire batch is rejected (all-or-nothing semantics).
 */
export declare const addDatasetExamples: API.OperationMethod<AddDatasetExamplesRequest, AddDatasetExamplesResponse, AddDatasetExamplesError, Credentials | HttpClient.HttpClient>;
export type BatchPutGatewayRateLimitsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Atomically creates or updates multiple rate limits for a gateway. The operation updates existing limits with matching keys and creates new limits for new keys. If the operation fails, the service applies no changes. Retry the request after resolving the issue.
 */
export declare const batchPutGatewayRateLimits: API.OperationMethod<BatchPutGatewayRateLimitsRequest, BatchPutGatewayRateLimitsResponse, BatchPutGatewayRateLimitsError, Credentials | HttpClient.HttpClient>;
export type CreateAgentRuntimeError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Bedrock AgentCore Runtime.
 */
export declare const createAgentRuntime: API.OperationMethod<CreateAgentRuntimeRequest, CreateAgentRuntimeResponse, CreateAgentRuntimeError, Credentials | HttpClient.HttpClient>;
export type CreateAgentRuntimeEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an AgentCore Runtime endpoint.
 */
export declare const createAgentRuntimeEndpoint: API.OperationMethod<CreateAgentRuntimeEndpointRequest, CreateAgentRuntimeEndpointResponse, CreateAgentRuntimeEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateApiKeyCredentialProviderError = AccessDeniedException | ConflictException | DecryptionFailure | EncryptionFailure | InternalServerException | ResourceLimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates a new API key credential provider.
 */
export declare const createApiKeyCredentialProvider: API.OperationMethod<CreateApiKeyCredentialProviderRequest, CreateApiKeyCredentialProviderResponse, CreateApiKeyCredentialProviderError, Credentials | HttpClient.HttpClient>;
export type CreateBrowserError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a custom browser.
 */
export declare const createBrowser: API.OperationMethod<CreateBrowserRequest, CreateBrowserResponse, CreateBrowserError, Credentials | HttpClient.HttpClient>;
export type CreateBrowserProfileError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a browser profile in Amazon Bedrock AgentCore. A browser profile stores persistent browser data such as cookies, local storage, session storage, and browsing history that can be saved from browser sessions and reused in subsequent sessions.
 */
export declare const createBrowserProfile: API.OperationMethod<CreateBrowserProfileRequest, CreateBrowserProfileResponse, CreateBrowserProfileError, Credentials | HttpClient.HttpClient>;
export type CreateCapacityProviderError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | RetryableConflictException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a capacity provider. A capacity provider defines the Amazon EC2 infrastructure for AgentCore Runtime, including the operating system, allowed instance types, networking, and storage. It also specifies the IAM permissions that AgentCore uses to manage those instances.
 *
 * The capacity provider name must be unique within your account. After you create the capacity provider, it enters a `CREATING` state and transitions to `READY` when it is available for use.
 */
export declare const createCapacityProvider: API.OperationMethod<CreateCapacityProviderInput, CreateCapacityProviderOutput, CreateCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type CreateCodeInterpreterError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a custom code interpreter.
 */
export declare const createCodeInterpreter: API.OperationMethod<CreateCodeInterpreterRequest, CreateCodeInterpreterResponse, CreateCodeInterpreterError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationBundleError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new configuration bundle resource. A configuration bundle stores versioned component configurations for agent evaluation workflows.
 */
export declare const createConfigurationBundle: API.OperationMethod<CreateConfigurationBundleRequest, CreateConfigurationBundleResponse, CreateConfigurationBundleError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new dataset resource asynchronously. Returns immediately with status CREATING. Poll `GetDataset` until status transitions to ACTIVE or CREATE_FAILED.
 */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest, CreateDatasetResponse, CreateDatasetError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Publishes the current DRAFT as a new numbered version. The DRAFT is preserved and remains editable after publishing. Returns immediately with status UPDATING. Poll `GetDataset` until status transitions to ACTIVE or UPDATE_FAILED.
 */
export declare const createDatasetVersion: API.OperationMethod<CreateDatasetVersionRequest, CreateDatasetVersionResponse, CreateDatasetVersionError, Credentials | HttpClient.HttpClient>;
export type CreateEvaluatorError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a custom evaluator for agent quality assessment. Custom evaluators can use either LLM-as-a-Judge configurations with user-defined prompts, rating scales, and model settings, or code-based configurations with customer-managed Lambda functions to evaluate agent performance at tool call, trace, or session levels.
 */
export declare const createEvaluator: API.OperationMethod<CreateEvaluatorRequest, CreateEvaluatorResponse, CreateEvaluatorError, Credentials | HttpClient.HttpClient>;
export type CreateGatewayError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a gateway for Amazon Bedrock Agent. A gateway serves as an integration point between your agent and external services.
 *
 * If you specify `CUSTOM_JWT` as the `authorizerType`, you must provide an `authorizerConfiguration`.
 */
export declare const createGateway: API.OperationMethod<CreateGatewayRequest, CreateGatewayResponse, CreateGatewayError, Credentials | HttpClient.HttpClient>;
export type CreateGatewayRateLimitError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a rate limit for a gateway. Rate limits define throttling rules for each dimension that control request rates, token consumption rates, and concurrent connections through the gateway.
 */
export declare const createGatewayRateLimit: API.OperationMethod<CreateGatewayRateLimitRequest, CreateGatewayRateLimitResponse, CreateGatewayRateLimitError, Credentials | HttpClient.HttpClient>;
export type CreateGatewayRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a rule for a gateway. Rules define conditions and actions that control how requests are routed and processed through the gateway, including principal-based access control and path-based routing.
 */
export declare const createGatewayRule: API.OperationMethod<CreateGatewayRuleRequest, CreateGatewayRuleResponse, CreateGatewayRuleError, Credentials | HttpClient.HttpClient>;
export type CreateGatewayTargetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a target for a gateway. A target defines an endpoint that the gateway can connect to.
 */
export declare const createGatewayTarget: API.OperationMethod<CreateGatewayTargetRequest, CreateGatewayTargetResponse, CreateGatewayTargetError, Credentials | HttpClient.HttpClient>;
export type CreateHarnessError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Operation to create a harness.
 */
export declare const createHarness: API.OperationMethod<CreateHarnessRequest, CreateHarnessResponse, CreateHarnessError, Credentials | HttpClient.HttpClient>;
export type CreateHarnessEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Operation to create a harness endpoint.
 */
export declare const createHarnessEndpoint: API.OperationMethod<CreateHarnessEndpointRequest, CreateHarnessEndpointResponse, CreateHarnessEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateMemoryError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Creates a new Amazon Bedrock AgentCore Memory resource.
 */
export declare const createMemory: API.OperationMethod<CreateMemoryInput, CreateMemoryOutput, CreateMemoryError, Credentials | HttpClient.HttpClient>;
export type CreateOauth2CredentialProviderError = AccessDeniedException | ConflictException | DecryptionFailure | EncryptionFailure | InternalServerException | ResourceLimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates a new OAuth2 credential provider.
 */
export declare const createOauth2CredentialProvider: API.OperationMethod<CreateOauth2CredentialProviderRequest, CreateOauth2CredentialProviderResponse, CreateOauth2CredentialProviderError, Credentials | HttpClient.HttpClient>;
export type CreateOnlineEvaluationConfigError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an online evaluation configuration for continuous monitoring of agent performance. Online evaluation automatically samples live traffic from CloudWatch logs at specified rates and applies evaluators to assess agent quality in production.
 */
export declare const createOnlineEvaluationConfig: API.OperationMethod<CreateOnlineEvaluationConfigRequest, CreateOnlineEvaluationConfigResponse, CreateOnlineEvaluationConfigError, Credentials | HttpClient.HttpClient>;
export type CreatePaymentConnectorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | SubscriptionRequiredException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new payment connector for a payment manager. A payment connector integrates with a supported payment provider to enable payment processing capabilities.
 */
export declare const createPaymentConnector: API.OperationMethod<CreatePaymentConnectorRequest, CreatePaymentConnectorResponse, CreatePaymentConnectorError, Credentials | HttpClient.HttpClient>;
export type CreatePaymentCredentialProviderError = AccessDeniedException | ConflictException | DecryptionFailure | EncryptionFailure | InternalServerException | ResourceLimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates a new payment credential provider for storing authentication credentials used by payment connectors to communicate with external payment providers.
 */
export declare const createPaymentCredentialProvider: API.OperationMethod<CreatePaymentCredentialProviderRequest, CreatePaymentCredentialProviderResponse, CreatePaymentCredentialProviderError, Credentials | HttpClient.HttpClient>;
export type CreatePaymentManagerError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new payment manager in your Amazon Web Services account. A payment manager serves as the top-level resource for managing payment processing capabilities, including payment connectors that integrate with supported payment providers.
 *
 * If you specify `CUSTOM_JWT` as the `authorizerType`, you must provide an `authorizerConfiguration`.
 */
export declare const createPaymentManager: API.OperationMethod<CreatePaymentManagerRequest, CreatePaymentManagerResponse, CreatePaymentManagerError, Credentials | HttpClient.HttpClient>;
export type CreatePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a policy within the AgentCore Policy system. Policies provide real-time, deterministic control over agentic interactions with AgentCore Gateway. Using the Cedar policy language, you can define fine-grained policies that specify which interactions with Gateway tools are permitted based on input parameters and OAuth claims, ensuring agents operate within defined boundaries and business rules. The policy is validated during creation against the Cedar schema generated from the Gateway's tools' input schemas, which defines the available tools, their parameters, and expected data types. This is an asynchronous operation. Use the GetPolicy operation to poll the `status` field to track completion.
 *
 * If the new policy is a temporal policy, creating it invalidates the policy engine's active temporal sessions. For more information about temporal policy sessions, see session-based temporal policies. The policy engine returns an HTTP 409 `ConflictException` to in-flight sessions. To resume, you must start a new session with a new session ID.
 */
export declare const createPolicy: API.OperationMethod<CreatePolicyRequest, CreatePolicyResponse, CreatePolicyError, Credentials | HttpClient.HttpClient>;
export type CreatePolicyEngineError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new policy engine within the AgentCore Policy system. A policy engine is a collection of policies that evaluates and authorizes agent tool calls. When associated with Gateways (each Gateway can be associated with at most one policy engine, but multiple Gateways can be associated with the same engine), the policy engine intercepts all agent requests and determines whether to allow or deny each action based on the defined policies. This is an asynchronous operation. Use the GetPolicyEngine operation to poll the `status` field to track completion.
 */
export declare const createPolicyEngine: API.OperationMethod<CreatePolicyEngineRequest, CreatePolicyEngineResponse, CreatePolicyEngineError, Credentials | HttpClient.HttpClient>;
export type CreateRegistryError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new registry in your Amazon Web Services account. A registry serves as a centralized catalog for organizing and managing registry records, including MCP servers, A2A agents, agent skills, and custom resource types.
 *
 * If you specify `CUSTOM_JWT` as the `authorizerType`, you must provide an `authorizerConfiguration`.
 */
export declare const createRegistry: API.OperationMethod<CreateRegistryRequest, CreateRegistryResponse, CreateRegistryError, Credentials | HttpClient.HttpClient>;
export type CreateRegistryRecordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new registry record within the specified registry. A registry record represents an individual AI resource's metadata in the registry. This could be an MCP server (and associated tools), A2A agent, agent skill, or a custom resource with a custom schema.
 *
 * The record is processed asynchronously and returns HTTP 202 Accepted.
 */
export declare const createRegistryRecord: API.OperationMethod<CreateRegistryRecordRequest, CreateRegistryRecordResponse, CreateRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type CreateWorkloadIdentityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates a new workload identity.
 */
export declare const createWorkloadIdentity: API.OperationMethod<CreateWorkloadIdentityRequest, CreateWorkloadIdentityResponse, CreateWorkloadIdentityError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentRuntimeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an Amazon Bedrock AgentCore Runtime, or a single version of an AgentCore Runtime when you provide the version qualifier.
 */
export declare const deleteAgentRuntime: API.OperationMethod<DeleteAgentRuntimeRequest, DeleteAgentRuntimeResponse, DeleteAgentRuntimeError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentRuntimeEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an AgentCore Runtime endpoint.
 */
export declare const deleteAgentRuntimeEndpoint: API.OperationMethod<DeleteAgentRuntimeEndpointRequest, DeleteAgentRuntimeEndpointResponse, DeleteAgentRuntimeEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteApiKeyCredentialProviderError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes an API key credential provider.
 */
export declare const deleteApiKeyCredentialProvider: API.OperationMethod<DeleteApiKeyCredentialProviderRequest, DeleteApiKeyCredentialProviderResponse, DeleteApiKeyCredentialProviderError, Credentials | HttpClient.HttpClient>;
export type DeleteBrowserError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a custom browser.
 */
export declare const deleteBrowser: API.OperationMethod<DeleteBrowserRequest, DeleteBrowserResponse, DeleteBrowserError, Credentials | HttpClient.HttpClient>;
export type DeleteBrowserProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a browser profile.
 */
export declare const deleteBrowserProfile: API.OperationMethod<DeleteBrowserProfileRequest, DeleteBrowserProfileResponse, DeleteBrowserProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteCapacityProviderError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | RetryableConflictException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a capacity provider. Before you delete a capacity provider, disassociate all agent runtimes and runtime versions that reference it. If any references remain, the operation fails.
 */
export declare const deleteCapacityProvider: API.OperationMethod<DeleteCapacityProviderInput, DeleteCapacityProviderOutput, DeleteCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type DeleteCodeInterpreterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a custom code interpreter.
 */
export declare const deleteCodeInterpreter: API.OperationMethod<DeleteCodeInterpreterRequest, DeleteCodeInterpreterResponse, DeleteCodeInterpreterError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationBundleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a configuration bundle and all of its versions.
 */
export declare const deleteConfigurationBundle: API.OperationMethod<DeleteConfigurationBundleRequest, DeleteConfigurationBundleResponse, DeleteConfigurationBundleError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a dataset version or an entire dataset asynchronously. If `datasetVersion` is absent, deletes all versions and the dataset record itself. If provided, deletes only that specific version.
 */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest, DeleteDatasetResponse, DeleteDatasetError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetExamplesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes specific examples by ID from DRAFT. All example IDs are validated before any deletes occur. If any ID does not exist in DRAFT, the entire batch is rejected (all-or-nothing semantics).
 */
export declare const deleteDatasetExamples: API.OperationMethod<DeleteDatasetExamplesRequest, DeleteDatasetExamplesResponse, DeleteDatasetExamplesError, Credentials | HttpClient.HttpClient>;
export type DeleteEvaluatorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a custom evaluator. Builtin evaluators cannot be deleted. The evaluator must not be referenced by any active online evaluation configurations.
 */
export declare const deleteEvaluator: API.OperationMethod<DeleteEvaluatorRequest, DeleteEvaluatorResponse, DeleteEvaluatorError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a gateway.
 */
export declare const deleteGateway: API.OperationMethod<DeleteGatewayRequest, DeleteGatewayResponse, DeleteGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayRateLimitError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a gateway rate limit.
 */
export declare const deleteGatewayRateLimit: API.OperationMethod<DeleteGatewayRateLimitRequest, DeleteGatewayRateLimitResponse, DeleteGatewayRateLimitError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a gateway rule.
 */
export declare const deleteGatewayRule: API.OperationMethod<DeleteGatewayRuleRequest, DeleteGatewayRuleResponse, DeleteGatewayRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayTargetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a gateway target.
 *
 * You cannot delete a target that is in a pending authorization state (`CREATE_PENDING_AUTH`, `UPDATE_PENDING_AUTH`, or `SYNCHRONIZE_PENDING_AUTH`). Wait for the authorization to complete or fail before deleting the target.
 */
export declare const deleteGatewayTarget: API.OperationMethod<DeleteGatewayTargetRequest, DeleteGatewayTargetResponse, DeleteGatewayTargetError, Credentials | HttpClient.HttpClient>;
export type DeleteHarnessError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Operation to delete a Harness.
 */
export declare const deleteHarness: API.OperationMethod<DeleteHarnessRequest, DeleteHarnessResponse, DeleteHarnessError, Credentials | HttpClient.HttpClient>;
export type DeleteHarnessEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Operation to delete a harness endpoint.
 */
export declare const deleteHarnessEndpoint: API.OperationMethod<DeleteHarnessEndpointRequest, DeleteHarnessEndpointResponse, DeleteHarnessEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteMemoryError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceException | ThrottledException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Bedrock AgentCore Memory resource. When you delete a memory resource, it is permanently removed.
 */
export declare const deleteMemory: API.OperationMethod<DeleteMemoryInput, DeleteMemoryOutput, DeleteMemoryError, Credentials | HttpClient.HttpClient>;
export type DeleteOauth2CredentialProviderError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes an OAuth2 credential provider.
 */
export declare const deleteOauth2CredentialProvider: API.OperationMethod<DeleteOauth2CredentialProviderRequest, DeleteOauth2CredentialProviderResponse, DeleteOauth2CredentialProviderError, Credentials | HttpClient.HttpClient>;
export type DeleteOnlineEvaluationConfigError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an online evaluation configuration and stops any ongoing evaluation processes associated with it.
 */
export declare const deleteOnlineEvaluationConfig: API.OperationMethod<DeleteOnlineEvaluationConfigRequest, DeleteOnlineEvaluationConfigResponse, DeleteOnlineEvaluationConfigError, Credentials | HttpClient.HttpClient>;
export type DeletePaymentConnectorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a payment connector.
 */
export declare const deletePaymentConnector: API.OperationMethod<DeletePaymentConnectorRequest, DeletePaymentConnectorResponse, DeletePaymentConnectorError, Credentials | HttpClient.HttpClient>;
export type DeletePaymentCredentialProviderError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes a payment credential provider and its associated stored credentials.
 */
export declare const deletePaymentCredentialProvider: API.OperationMethod<DeletePaymentCredentialProviderRequest, DeletePaymentCredentialProviderResponse, DeletePaymentCredentialProviderError, Credentials | HttpClient.HttpClient>;
export type DeletePaymentManagerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a payment manager. All payment connectors associated with the payment manager must be deleted before the payment manager can be deleted. This operation initiates the deletion process asynchronously.
 */
export declare const deletePaymentManager: API.OperationMethod<DeletePaymentManagerRequest, DeletePaymentManagerResponse, DeletePaymentManagerError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing policy from the AgentCore Policy system. Once deleted, the policy can no longer be used for agent behavior control and all references to it become invalid. This is an asynchronous operation. Use the `GetPolicy` operation to poll the `status` field to track completion.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest, DeletePolicyResponse, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyEngineError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing policy engine from the AgentCore Policy system. The policy engine must not have any associated policies before deletion. Once deleted, the policy engine and all its configurations become unavailable for policy management and evaluation. This is an asynchronous operation. Use the `GetPolicyEngine` operation to poll the `status` field to track completion.
 */
export declare const deletePolicyEngine: API.OperationMethod<DeletePolicyEngineRequest, DeletePolicyEngineResponse, DeletePolicyEngineError, Credentials | HttpClient.HttpClient>;
export type DeleteRegistryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a registry. The registry must contain zero records before it can be deleted. This operation initiates the deletion process asynchronously.
 */
export declare const deleteRegistry: API.OperationMethod<DeleteRegistryRequest, DeleteRegistryResponse, DeleteRegistryError, Credentials | HttpClient.HttpClient>;
export type DeleteRegistryRecordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a registry record. The record's status transitions to `DELETING` and the record is removed asynchronously.
 */
export declare const deleteRegistryRecord: API.OperationMethod<DeleteRegistryRecordRequest, DeleteRegistryRecordResponse, DeleteRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the resource-based policy for a specified resource.
 *
 * This feature is currently available only for AgentCore Runtime and Gateway.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkloadIdentityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes a workload identity.
 */
export declare const deleteWorkloadIdentity: API.OperationMethod<DeleteWorkloadIdentityRequest, DeleteWorkloadIdentityResponse, DeleteWorkloadIdentityError, Credentials | HttpClient.HttpClient>;
export type GetAgentRuntimeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon Bedrock AgentCore Runtime.
 */
export declare const getAgentRuntime: API.OperationMethod<GetAgentRuntimeRequest, GetAgentRuntimeResponse, GetAgentRuntimeError, Credentials | HttpClient.HttpClient>;
export type GetAgentRuntimeEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an Amazon Secure AgentEndpoint.
 */
export declare const getAgentRuntimeEndpoint: API.OperationMethod<GetAgentRuntimeEndpointRequest, GetAgentRuntimeEndpointResponse, GetAgentRuntimeEndpointError, Credentials | HttpClient.HttpClient>;
export type GetApiKeyCredentialProviderError = AccessDeniedException | DecryptionFailure | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves information about an API key credential provider.
 */
export declare const getApiKeyCredentialProvider: API.OperationMethod<GetApiKeyCredentialProviderRequest, GetApiKeyCredentialProviderResponse, GetApiKeyCredentialProviderError, Credentials | HttpClient.HttpClient>;
export type GetBrowserError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Gets information about a custom browser.
 */
export declare const getBrowser: API.OperationMethod<GetBrowserRequest, GetBrowserResponse, GetBrowserError, Credentials | HttpClient.HttpClient>;
export type GetBrowserProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a browser profile.
 */
export declare const getBrowserProfile: API.OperationMethod<GetBrowserProfileRequest, GetBrowserProfileResponse, GetBrowserProfileError, Credentials | HttpClient.HttpClient>;
export type GetCapacityProviderError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a capacity provider, including its status, permissions configuration, and compute configuration.
 */
export declare const getCapacityProvider: API.OperationMethod<GetCapacityProviderInput, GetCapacityProviderOutput, GetCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type GetCodeInterpreterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Gets information about a custom code interpreter.
 */
export declare const getCodeInterpreter: API.OperationMethod<GetCodeInterpreterRequest, GetCodeInterpreterResponse, GetCodeInterpreterError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationBundleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the latest version of a configuration bundle. By default, returns the latest version on the mainline branch. Use `GetConfigurationBundleVersion` to retrieve a specific historical version.
 */
export declare const getConfigurationBundle: API.OperationMethod<GetConfigurationBundleRequest, GetConfigurationBundleResponse, GetConfigurationBundleError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationBundleVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a specific version of a configuration bundle by its version identifier.
 */
export declare const getConfigurationBundleVersion: API.OperationMethod<GetConfigurationBundleVersionRequest, GetConfigurationBundleVersionResponse, GetConfigurationBundleVersionError, Credentials | HttpClient.HttpClient>;
export type GetDatasetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves dataset metadata. Use the `datasetVersion` query parameter to retrieve a specific version's metadata. If absent, defaults to DRAFT. For paginated example content, use `ListDatasetExamples`.
 */
export declare const getDataset: API.OperationMethod<GetDatasetRequest, GetDatasetResponse, GetDatasetError, Credentials | HttpClient.HttpClient>;
export type GetEvaluatorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about an evaluator, including its configuration, status, and metadata. Works with both built-in and custom evaluators.
 */
export declare const getEvaluator: API.OperationMethod<GetEvaluatorRequest, GetEvaluatorResponse, GetEvaluatorError, Credentials | HttpClient.HttpClient>;
export type GetGatewayError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific Gateway.
 */
export declare const getGateway: API.OperationMethod<GetGatewayRequest, GetGatewayResponse, GetGatewayError, Credentials | HttpClient.HttpClient>;
export type GetGatewayRateLimitError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a gateway rate limit.
 */
export declare const getGatewayRateLimit: API.OperationMethod<GetGatewayRateLimitRequest, GetGatewayRateLimitResponse, GetGatewayRateLimitError, Credentials | HttpClient.HttpClient>;
export type GetGatewayRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific gateway rule.
 */
export declare const getGatewayRule: API.OperationMethod<GetGatewayRuleRequest, GetGatewayRuleResponse, GetGatewayRuleError, Credentials | HttpClient.HttpClient>;
export type GetGatewayTargetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific gateway target.
 */
export declare const getGatewayTarget: API.OperationMethod<GetGatewayTargetRequest, GetGatewayTargetResponse, GetGatewayTargetError, Credentials | HttpClient.HttpClient>;
export type GetHarnessError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Operation to get a single harness.
 */
export declare const getHarness: API.OperationMethod<GetHarnessRequest, GetHarnessResponse, GetHarnessError, Credentials | HttpClient.HttpClient>;
export type GetHarnessEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Operation to get a single harness endpoint.
 */
export declare const getHarnessEndpoint: API.OperationMethod<GetHarnessEndpointRequest, GetHarnessEndpointResponse, GetHarnessEndpointError, Credentials | HttpClient.HttpClient>;
export type GetMemoryError = AccessDeniedException | ResourceNotFoundException | ServiceException | ThrottledException | ValidationException | CommonErrors;
/**
 * Retrieve an existing Amazon Bedrock AgentCore Memory resource.
 */
export declare const getMemory: API.OperationMethod<GetMemoryInput, GetMemoryOutput, GetMemoryError, Credentials | HttpClient.HttpClient>;
export type GetOauth2CredentialProviderError = AccessDeniedException | DecryptionFailure | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves information about an OAuth2 credential provider.
 */
export declare const getOauth2CredentialProvider: API.OperationMethod<GetOauth2CredentialProviderRequest, GetOauth2CredentialProviderResponse, GetOauth2CredentialProviderError, Credentials | HttpClient.HttpClient>;
export type GetOnlineEvaluationConfigError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about an online evaluation configuration, including its rules, data sources, evaluators, and execution status.
 */
export declare const getOnlineEvaluationConfig: API.OperationMethod<GetOnlineEvaluationConfigRequest, GetOnlineEvaluationConfigResponse, GetOnlineEvaluationConfigError, Credentials | HttpClient.HttpClient>;
export type GetPaymentConnectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific payment connector.
 */
export declare const getPaymentConnector: API.OperationMethod<GetPaymentConnectorRequest, GetPaymentConnectorResponse, GetPaymentConnectorError, Credentials | HttpClient.HttpClient>;
export type GetPaymentCredentialProviderError = AccessDeniedException | DecryptionFailure | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific payment credential provider.
 */
export declare const getPaymentCredentialProvider: API.OperationMethod<GetPaymentCredentialProviderRequest, GetPaymentCredentialProviderResponse, GetPaymentCredentialProviderError, Credentials | HttpClient.HttpClient>;
export type GetPaymentManagerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific payment manager.
 */
export declare const getPaymentManager: API.OperationMethod<GetPaymentManagerRequest, GetPaymentManagerResponse, GetPaymentManagerError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific policy within the AgentCore Policy system. This operation returns the complete policy definition, metadata, and current status, allowing administrators to review and manage policy configurations.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest, GetPolicyResponse, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetPolicyEngineError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific policy engine within the AgentCore Policy system. This operation returns the complete policy engine configuration, metadata, and current status, allowing administrators to review and manage policy engine settings.
 */
export declare const getPolicyEngine: API.OperationMethod<GetPolicyEngineRequest, GetPolicyEngineResponse, GetPolicyEngineError, Credentials | HttpClient.HttpClient>;
export type GetPolicyEngineSummaryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a metadata-only summary of a specific policy engine without decrypting customer content. This lightweight read operation returns resource identifiers, status, timestamps, and the encryption key ARN, but does not include the description or status reasons. Because this operation does not require access to the customer's KMS key, it is suitable for resource discovery, inventory, and integration scenarios where only metadata is needed.
 */
export declare const getPolicyEngineSummary: API.OperationMethod<GetPolicyEngineSummaryRequest, GetPolicyEngineSummaryResponse, GetPolicyEngineSummaryError, Credentials | HttpClient.HttpClient>;
export type GetPolicyGenerationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a policy generation request within the AgentCore Policy system. Policy generation converts natural language descriptions into Cedar policy statements using AI-powered translation, enabling non-technical users to create policies.
 */
export declare const getPolicyGeneration: API.OperationMethod<GetPolicyGenerationRequest, GetPolicyGenerationResponse, GetPolicyGenerationError, Credentials | HttpClient.HttpClient>;
export type GetPolicyGenerationSummaryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a metadata-only summary of a specific policy generation request without decrypting customer content. This lightweight read operation returns resource identifiers, status, timestamps, and findings, but does not include status reasons. Because this operation does not require access to the customer's KMS key, it is suitable for resource discovery, inventory, and integration scenarios where only metadata is needed.
 */
export declare const getPolicyGenerationSummary: API.OperationMethod<GetPolicyGenerationSummaryRequest, GetPolicyGenerationSummaryResponse, GetPolicyGenerationSummaryError, Credentials | HttpClient.HttpClient>;
export type GetPolicySummaryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a metadata-only summary of a specific policy without decrypting customer content. This lightweight read operation returns resource identifiers, status, and timestamps, but does not include the policy definition, description, or status reasons. Because this operation does not require access to the customer's KMS key, it is suitable for resource discovery, inventory, and integration scenarios where only metadata is needed.
 */
export declare const getPolicySummary: API.OperationMethod<GetPolicySummaryRequest, GetPolicySummaryResponse, GetPolicySummaryError, Credentials | HttpClient.HttpClient>;
export type GetRegistryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific registry.
 */
export declare const getRegistry: API.OperationMethod<GetRegistryRequest, GetRegistryResponse, GetRegistryError, Credentials | HttpClient.HttpClient>;
export type GetRegistryRecordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific registry record.
 */
export declare const getRegistryRecord: API.OperationMethod<GetRegistryRecordRequest, GetRegistryRecordResponse, GetRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the resource-based policy for a specified resource.
 *
 * This feature is currently available only for AgentCore Runtime and Gateway.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetTokenVaultError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves information about a token vault.
 */
export declare const getTokenVault: API.OperationMethod<GetTokenVaultRequest, GetTokenVaultResponse, GetTokenVaultError, Credentials | HttpClient.HttpClient>;
export type GetWorkloadIdentityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves information about a workload identity.
 */
export declare const getWorkloadIdentity: API.OperationMethod<GetWorkloadIdentityRequest, GetWorkloadIdentityResponse, GetWorkloadIdentityError, Credentials | HttpClient.HttpClient>;
export type ListAgentRuntimeEndpointsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all endpoints for a specific Amazon Secure Agent.
 */
export declare const listAgentRuntimeEndpoints: API.PaginatedOperationMethod<ListAgentRuntimeEndpointsRequest, ListAgentRuntimeEndpointsResponse, ListAgentRuntimeEndpointsError, Credentials | HttpClient.HttpClient, AgentRuntimeEndpoint>;
export type ListAgentRuntimesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all Amazon Secure Agents in your account.
 */
export declare const listAgentRuntimes: API.PaginatedOperationMethod<ListAgentRuntimesRequest, ListAgentRuntimesResponse, ListAgentRuntimesError, Credentials | HttpClient.HttpClient, AgentRuntime>;
export type ListAgentRuntimeVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all versions of a specific Amazon Secure Agent.
 */
export declare const listAgentRuntimeVersions: API.PaginatedOperationMethod<ListAgentRuntimeVersionsRequest, ListAgentRuntimeVersionsResponse, ListAgentRuntimeVersionsError, Credentials | HttpClient.HttpClient, AgentRuntime>;
export type ListAgentRuntimeVersionsByCapacityProviderError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the agent runtime versions that are associated with a capacity provider. Use this operation to identify the runtimes you must disassociate before you can delete the capacity provider. Results are paginated; use the `nextToken` parameter to retrieve additional results.
 */
export declare const listAgentRuntimeVersionsByCapacityProvider: API.PaginatedOperationMethod<ListAgentRuntimeVersionsByCapacityProviderInput, ListAgentRuntimeVersionsByCapacityProviderOutput, ListAgentRuntimeVersionsByCapacityProviderError, Credentials | HttpClient.HttpClient, AgentRuntimeVersionSummary>;
export type ListApiKeyCredentialProvidersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all API key credential providers in your account.
 */
export declare const listApiKeyCredentialProviders: API.PaginatedOperationMethod<ListApiKeyCredentialProvidersRequest, ListApiKeyCredentialProvidersResponse, ListApiKeyCredentialProvidersError, Credentials | HttpClient.HttpClient, ApiKeyCredentialProviderItem>;
export type ListBrowserProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all browser profiles in your account.
 */
export declare const listBrowserProfiles: API.PaginatedOperationMethod<ListBrowserProfilesRequest, ListBrowserProfilesResponse, ListBrowserProfilesError, Credentials | HttpClient.HttpClient, BrowserProfileSummary>;
export type ListBrowsersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all custom browsers in your account.
 */
export declare const listBrowsers: API.PaginatedOperationMethod<ListBrowsersRequest, ListBrowsersResponse, ListBrowsersError, Credentials | HttpClient.HttpClient, BrowserSummary>;
export type ListCapacityProvidersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the capacity providers in your account and returns summary information for each one. To retrieve the full configuration for a specific capacity provider, use `GetCapacityProvider`. Results are paginated; use the `nextToken` parameter to retrieve additional results.
 */
export declare const listCapacityProviders: API.PaginatedOperationMethod<ListCapacityProvidersInput, ListCapacityProvidersOutput, ListCapacityProvidersError, Credentials | HttpClient.HttpClient, CapacityProviderSummary>;
export type ListCodeInterpretersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all custom code interpreters in your account.
 */
export declare const listCodeInterpreters: API.PaginatedOperationMethod<ListCodeInterpretersRequest, ListCodeInterpretersResponse, ListCodeInterpretersError, Credentials | HttpClient.HttpClient, CodeInterpreterSummary>;
export type ListConfigurationBundlesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all configuration bundles in the account.
 */
export declare const listConfigurationBundles: API.PaginatedOperationMethod<ListConfigurationBundlesRequest, ListConfigurationBundlesResponse, ListConfigurationBundlesError, Credentials | HttpClient.HttpClient, ConfigurationBundleSummary>;
export type ListConfigurationBundleVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all versions of a configuration bundle, with optional filtering by branch name or creation source.
 */
export declare const listConfigurationBundleVersions: API.PaginatedOperationMethod<ListConfigurationBundleVersionsRequest, ListConfigurationBundleVersionsResponse, ListConfigurationBundleVersionsError, Credentials | HttpClient.HttpClient, ConfigurationBundleVersionSummary>;
export type ListDatasetExamplesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns paginated examples from the dataset. The server embeds the resolved version in the pagination token. Once pagination begins, all subsequent pages are pinned to that version regardless of concurrent mutations.
 */
export declare const listDatasetExamples: API.PaginatedOperationMethod<ListDatasetExamplesRequest, ListDatasetExamplesResponse, ListDatasetExamplesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDatasetsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all datasets in the caller's account, paginated.
 */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest, ListDatasetsResponse, ListDatasetsError, Credentials | HttpClient.HttpClient, DatasetSummary>;
export type ListDatasetVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all published versions of a dataset, sorted by version number descending (newest first). Does not include the DRAFT working copy.
 */
export declare const listDatasetVersions: API.PaginatedOperationMethod<ListDatasetVersionsRequest, ListDatasetVersionsResponse, ListDatasetVersionsError, Credentials | HttpClient.HttpClient, DatasetVersionSummary>;
export type ListEvaluatorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all available evaluators, including both builtin evaluators provided by the service and custom evaluators created by the user.
 */
export declare const listEvaluators: API.PaginatedOperationMethod<ListEvaluatorsRequest, ListEvaluatorsResponse, ListEvaluatorsError, Credentials | HttpClient.HttpClient, EvaluatorSummary>;
export type ListGatewayRateLimitsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all rate limits for a gateway. Results are paginated. Use the `nextToken` parameter to retrieve additional results.
 */
export declare const listGatewayRateLimits: API.PaginatedOperationMethod<ListGatewayRateLimitsRequest, ListGatewayRateLimitsResponse, ListGatewayRateLimitsError, Credentials | HttpClient.HttpClient, GatewayRateLimitDetail>;
export type ListGatewayRulesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all rules for a gateway.
 */
export declare const listGatewayRules: API.PaginatedOperationMethod<ListGatewayRulesRequest, ListGatewayRulesResponse, ListGatewayRulesError, Credentials | HttpClient.HttpClient, GatewayRuleDetail>;
export type ListGatewaysError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all gateways in the account.
 */
export declare const listGateways: API.PaginatedOperationMethod<ListGatewaysRequest, ListGatewaysResponse, ListGatewaysError, Credentials | HttpClient.HttpClient, GatewaySummary>;
export type ListGatewayTargetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all targets for a specific gateway.
 */
export declare const listGatewayTargets: API.PaginatedOperationMethod<ListGatewayTargetsRequest, ListGatewayTargetsResponse, ListGatewayTargetsError, Credentials | HttpClient.HttpClient, TargetSummary>;
export type ListHarnessEndpointsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Operation to list the endpoints of a harness.
 */
export declare const listHarnessEndpoints: API.PaginatedOperationMethod<ListHarnessEndpointsRequest, ListHarnessEndpointsResponse, ListHarnessEndpointsError, Credentials | HttpClient.HttpClient, HarnessEndpoint>;
export type ListHarnessesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Operation to list harnesses.
 */
export declare const listHarnesses: API.PaginatedOperationMethod<ListHarnessesRequest, ListHarnessesResponse, ListHarnessesError, Credentials | HttpClient.HttpClient, HarnessSummary>;
export type ListHarnessVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Operation to list the versions of a Harness.
 */
export declare const listHarnessVersions: API.PaginatedOperationMethod<ListHarnessVersionsRequest, ListHarnessVersionsResponse, ListHarnessVersionsError, Credentials | HttpClient.HttpClient, HarnessVersionSummary>;
export type ListMemoriesError = AccessDeniedException | ResourceNotFoundException | ServiceException | ThrottledException | ValidationException | CommonErrors;
/**
 * Lists the available Amazon Bedrock AgentCore Memory resources in the current Amazon Web Services Region.
 */
export declare const listMemories: API.PaginatedOperationMethod<ListMemoriesInput, ListMemoriesOutput, ListMemoriesError, Credentials | HttpClient.HttpClient, MemorySummary>;
export type ListOauth2CredentialProvidersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all OAuth2 credential providers in your account.
 */
export declare const listOauth2CredentialProviders: API.PaginatedOperationMethod<ListOauth2CredentialProvidersRequest, ListOauth2CredentialProvidersResponse, ListOauth2CredentialProvidersError, Credentials | HttpClient.HttpClient, Oauth2CredentialProviderItem>;
export type ListOnlineEvaluationConfigsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all online evaluation configurations in the account, providing summary information about each configuration's status and settings.
 */
export declare const listOnlineEvaluationConfigs: API.PaginatedOperationMethod<ListOnlineEvaluationConfigsRequest, ListOnlineEvaluationConfigsResponse, ListOnlineEvaluationConfigsError, Credentials | HttpClient.HttpClient, OnlineEvaluationConfigSummary>;
export type ListPaymentConnectorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all payment connectors for a specified payment manager.
 */
export declare const listPaymentConnectors: API.PaginatedOperationMethod<ListPaymentConnectorsRequest, ListPaymentConnectorsResponse, ListPaymentConnectorsError, Credentials | HttpClient.HttpClient, PaymentConnectorSummary>;
export type ListPaymentCredentialProvidersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all payment credential providers in the account.
 */
export declare const listPaymentCredentialProviders: API.PaginatedOperationMethod<ListPaymentCredentialProvidersRequest, ListPaymentCredentialProvidersResponse, ListPaymentCredentialProvidersError, Credentials | HttpClient.HttpClient, PaymentCredentialProviderItem>;
export type ListPaymentManagersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all payment managers in the account.
 */
export declare const listPaymentManagers: API.PaginatedOperationMethod<ListPaymentManagersRequest, ListPaymentManagersResponse, ListPaymentManagersError, Credentials | HttpClient.HttpClient, PaymentManagerSummary>;
export type ListPoliciesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of policies within the AgentCore Policy engine. This operation supports pagination and filtering to help administrators manage and discover policies across policy engines. Results can be filtered by policy engine or resource associations.
 */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesRequest, ListPoliciesResponse, ListPoliciesError, Credentials | HttpClient.HttpClient, Policy>;
export type ListPolicyEnginesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of policy engines within the AgentCore Policy system. This operation supports pagination to help administrators discover and manage policy engines across their account. Each policy engine serves as a container for related policies.
 */
export declare const listPolicyEngines: API.PaginatedOperationMethod<ListPolicyEnginesRequest, ListPolicyEnginesResponse, ListPolicyEnginesError, Credentials | HttpClient.HttpClient, PolicyEngine>;
export type ListPolicyEngineSummariesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of metadata-only policy engine summaries without decrypting customer content. This lightweight read operation returns resource identifiers, status, and timestamps for each policy engine, but does not include descriptions or status reasons. Because this operation does not require access to the customer's KMS key, it is suitable for resource discovery, inventory, and integration scenarios where only metadata is needed.
 */
export declare const listPolicyEngineSummaries: API.PaginatedOperationMethod<ListPolicyEngineSummariesRequest, ListPolicyEngineSummariesResponse, ListPolicyEngineSummariesError, Credentials | HttpClient.HttpClient, PolicyEngineSummary>;
export type ListPolicyGenerationAssetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of generated policy assets from a policy generation request within the AgentCore Policy system. This operation returns the actual Cedar policies and related artifacts produced by the AI-powered policy generation process, allowing users to review and select from multiple generated policy options.
 */
export declare const listPolicyGenerationAssets: API.PaginatedOperationMethod<ListPolicyGenerationAssetsRequest, ListPolicyGenerationAssetsResponse, ListPolicyGenerationAssetsError, Credentials | HttpClient.HttpClient, PolicyGenerationAsset>;
export type ListPolicyGenerationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of policy generation requests within the AgentCore Policy system. This operation supports pagination and filtering to help track and manage AI-powered policy generation operations.
 */
export declare const listPolicyGenerations: API.PaginatedOperationMethod<ListPolicyGenerationsRequest, ListPolicyGenerationsResponse, ListPolicyGenerationsError, Credentials | HttpClient.HttpClient, PolicyGeneration>;
export type ListPolicyGenerationSummariesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of metadata-only policy generation summaries within a policy engine without decrypting customer content. This lightweight read operation returns resource identifiers, status, timestamps, and findings for each policy generation, but does not include status reasons. Because this operation does not require access to the customer's KMS key, it is suitable for resource discovery, inventory, and integration scenarios where only metadata is needed.
 */
export declare const listPolicyGenerationSummaries: API.PaginatedOperationMethod<ListPolicyGenerationSummariesRequest, ListPolicyGenerationSummariesResponse, ListPolicyGenerationSummariesError, Credentials | HttpClient.HttpClient, PolicyGenerationSummary>;
export type ListPolicySummariesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of metadata-only policy summaries within a policy engine without decrypting customer content. This lightweight read operation returns resource identifiers, status, and timestamps for each policy, but does not include policy definitions, descriptions, or status reasons. Because this operation does not require access to the customer's KMS key, it is suitable for resource discovery, inventory, and integration scenarios where only metadata is needed.
 */
export declare const listPolicySummaries: API.PaginatedOperationMethod<ListPolicySummariesRequest, ListPolicySummariesResponse, ListPolicySummariesError, Credentials | HttpClient.HttpClient, PolicySummary>;
export type ListRegistriesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all registries in the account. You can optionally filter results by status using the `status` parameter, or by authorizer type using the `authorizerType` parameter.
 */
export declare const listRegistries: API.PaginatedOperationMethod<ListRegistriesRequest, ListRegistriesResponse, ListRegistriesError, Credentials | HttpClient.HttpClient, RegistrySummary>;
export type ListRegistryRecordsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists registry records within a registry. You can optionally filter results using the `name`, `status`, and `descriptorType` parameters. When multiple filters are specified, they are combined using AND logic.
 */
export declare const listRegistryRecords: API.PaginatedOperationMethod<ListRegistryRecordsRequest, ListRegistryRecordsResponse, ListRegistryRecordsError, Credentials | HttpClient.HttpClient, RegistryRecordSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags associated with the specified resource.
 *
 * This feature is currently available only for AgentCore Runtime, Browser, Browser Profile, Code Interpreter tool, and Gateway.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkloadIdentitiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all workload identities in your account.
 */
export declare const listWorkloadIdentities: API.PaginatedOperationMethod<ListWorkloadIdentitiesRequest, ListWorkloadIdentitiesResponse, ListWorkloadIdentitiesError, Credentials | HttpClient.HttpClient, WorkloadIdentityType>;
export type PutResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates a resource-based policy for a resource with the specified resourceArn.
 *
 * This feature is currently available only for AgentCore Runtime and Gateway.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type SetTokenVaultCMKError = AccessDeniedException | ConcurrentModificationException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Sets the customer master key (CMK) for a token vault.
 */
export declare const setTokenVaultCMK: API.OperationMethod<SetTokenVaultCMKRequest, SetTokenVaultCMKResponse, SetTokenVaultCMKError, Credentials | HttpClient.HttpClient>;
export type StartPolicyGenerationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates the AI-powered generation of Cedar policies from natural language descriptions within the AgentCore Policy system. This feature enables both technical and non-technical users to create policies by describing their authorization requirements in plain English, which is then automatically translated into formal Cedar policy statements. The generation process analyzes the natural language input along with the Gateway's tool context to produce validated policy options. Generated policy assets are automatically deleted after 7 days, so you should review and create policies from the generated assets within this timeframe. Once created, policies are permanent and not subject to this expiration. Generated policies should be reviewed and tested in log-only mode before deploying to production. Use this when you want to describe policy intent naturally rather than learning Cedar syntax, though generated policies may require refinement for complex scenarios.
 */
export declare const startPolicyGeneration: API.OperationMethod<StartPolicyGenerationRequest, StartPolicyGenerationResponse, StartPolicyGenerationError, Credentials | HttpClient.HttpClient>;
export type SubmitRegistryRecordForApprovalError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Submits a registry record for approval. This transitions the record from `DRAFT` status to `PENDING_APPROVAL` status. If the registry has auto-approval enabled, the record is automatically approved.
 */
export declare const submitRegistryRecordForApproval: API.OperationMethod<SubmitRegistryRecordForApprovalRequest, SubmitRegistryRecordForApprovalResponse, SubmitRegistryRecordForApprovalError, Credentials | HttpClient.HttpClient>;
export type SynchronizeGatewayTargetsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Synchronizes the gateway targets by fetching the latest tool definitions from the target endpoints.
 *
 * You cannot synchronize a target that is in a pending authorization state (`CREATE_PENDING_AUTH`, `UPDATE_PENDING_AUTH`, or `SYNCHRONIZE_PENDING_AUTH`). Wait for the authorization to complete or fail before synchronizing.
 *
 * You cannot synchronize a target that has a static tool schema (`mcpToolSchema`) configured. Remove the static schema through an `UpdateGatewayTarget` call to enable dynamic tool synchronization.
 */
export declare const synchronizeGatewayTargets: API.OperationMethod<SynchronizeGatewayTargetsRequest, SynchronizeGatewayTargetsResponse, SynchronizeGatewayTargetsError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified resourceArn. If existing tags on a resource are not specified in the request parameters, they are not changed. When a resource is deleted, the tags associated with that resource are also deleted.
 *
 * This feature is currently available only for AgentCore Runtime, Browser, Browser Profile, Code Interpreter tool, and Gateway.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 *
 * This feature is currently available only for AgentCore Runtime, Browser, Browser Profile, Code Interpreter tool, and Gateway.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentRuntimeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Secure Agent.
 */
export declare const updateAgentRuntime: API.OperationMethod<UpdateAgentRuntimeRequest, UpdateAgentRuntimeResponse, UpdateAgentRuntimeError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentRuntimeEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Bedrock AgentCore Runtime endpoint.
 */
export declare const updateAgentRuntimeEndpoint: API.OperationMethod<UpdateAgentRuntimeEndpointRequest, UpdateAgentRuntimeEndpointResponse, UpdateAgentRuntimeEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateApiKeyCredentialProviderError = AccessDeniedException | ConflictException | DecryptionFailure | EncryptionFailure | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates an existing API key credential provider.
 */
export declare const updateApiKeyCredentialProvider: API.OperationMethod<UpdateApiKeyCredentialProviderRequest, UpdateApiKeyCredentialProviderResponse, UpdateApiKeyCredentialProviderError, Credentials | HttpClient.HttpClient>;
export type UpdateCapacityProviderError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | RetryableConflictException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a capacity provider. Only the description can be changed. To change other configuration, such as instance types, networking, or storage, create a new capacity provider.
 */
export declare const updateCapacityProvider: API.OperationMethod<UpdateCapacityProviderInput, UpdateCapacityProviderOutput, UpdateCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationBundleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a configuration bundle by creating a new version with the specified changes. Each update creates a new version in the version history.
 */
export declare const updateConfigurationBundle: API.OperationMethod<UpdateConfigurationBundleRequest, UpdateConfigurationBundleResponse, UpdateConfigurationBundleError, Credentials | HttpClient.HttpClient>;
export type UpdateDatasetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a dataset's metadata. Synchronous operation. Only provided fields are updated; omitted fields remain unchanged. To modify dataset content, use `AddDatasetExamples`, `UpdateDatasetExamples`, or `DeleteDatasetExamples`.
 */
export declare const updateDataset: API.OperationMethod<UpdateDatasetRequest, UpdateDatasetResponse, UpdateDatasetError, Credentials | HttpClient.HttpClient>;
export type UpdateDatasetExamplesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates multiple existing examples in-place on DRAFT. All examples are validated against the dataset's schema type before any writes occur. If any example fails validation, the entire batch is rejected (all-or-nothing semantics).
 */
export declare const updateDatasetExamples: API.OperationMethod<UpdateDatasetExamplesRequest, UpdateDatasetExamplesResponse, UpdateDatasetExamplesError, Credentials | HttpClient.HttpClient>;
export type UpdateEvaluatorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a custom evaluator's configuration, description, or evaluation level. Built-in evaluators cannot be updated. The evaluator must not be locked for modification.
 */
export declare const updateEvaluator: API.OperationMethod<UpdateEvaluatorRequest, UpdateEvaluatorResponse, UpdateEvaluatorError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing gateway.
 */
export declare const updateGateway: API.OperationMethod<UpdateGatewayRequest, UpdateGatewayResponse, UpdateGatewayError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayRateLimitError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the entries of a gateway rate limit. The dimension keys are immutable after creation.
 */
export declare const updateGatewayRateLimit: API.OperationMethod<UpdateGatewayRateLimitRequest, UpdateGatewayRateLimitResponse, UpdateGatewayRateLimitError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a gateway rule's priority, conditions, actions, or description.
 */
export declare const updateGatewayRule: API.OperationMethod<UpdateGatewayRuleRequest, UpdateGatewayRuleResponse, UpdateGatewayRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayTargetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing gateway target.
 *
 * You cannot update a target that is in a pending authorization state (`CREATE_PENDING_AUTH`, `UPDATE_PENDING_AUTH`, or `SYNCHRONIZE_PENDING_AUTH`). Wait for the authorization to complete or fail before updating the target.
 */
export declare const updateGatewayTarget: API.OperationMethod<UpdateGatewayTargetRequest, UpdateGatewayTargetResponse, UpdateGatewayTargetError, Credentials | HttpClient.HttpClient>;
export type UpdateHarnessError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Operation to update a harness.
 */
export declare const updateHarness: API.OperationMethod<UpdateHarnessRequest, UpdateHarnessResponse, UpdateHarnessError, Credentials | HttpClient.HttpClient>;
export type UpdateHarnessEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Operation to update a harness endpoint.
 */
export declare const updateHarnessEndpoint: API.OperationMethod<UpdateHarnessEndpointRequest, UpdateHarnessEndpointResponse, UpdateHarnessEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateMemoryError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Update an Amazon Bedrock AgentCore Memory resource memory.
 */
export declare const updateMemory: API.OperationMethod<UpdateMemoryInput, UpdateMemoryOutput, UpdateMemoryError, Credentials | HttpClient.HttpClient>;
export type UpdateOauth2CredentialProviderError = AccessDeniedException | ConflictException | DecryptionFailure | EncryptionFailure | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates an existing OAuth2 credential provider.
 */
export declare const updateOauth2CredentialProvider: API.OperationMethod<UpdateOauth2CredentialProviderRequest, UpdateOauth2CredentialProviderResponse, UpdateOauth2CredentialProviderError, Credentials | HttpClient.HttpClient>;
export type UpdateOnlineEvaluationConfigError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an online evaluation configuration's settings, including rules, data sources, evaluators, and execution status. Changes take effect immediately for ongoing evaluations.
 */
export declare const updateOnlineEvaluationConfig: API.OperationMethod<UpdateOnlineEvaluationConfigRequest, UpdateOnlineEvaluationConfigResponse, UpdateOnlineEvaluationConfigError, Credentials | HttpClient.HttpClient>;
export type UpdatePaymentConnectorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | SubscriptionRequiredException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing payment connector. This operation uses PATCH semantics, so you only need to specify the fields you want to change.
 */
export declare const updatePaymentConnector: API.OperationMethod<UpdatePaymentConnectorRequest, UpdatePaymentConnectorResponse, UpdatePaymentConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdatePaymentCredentialProviderError = AccessDeniedException | ConflictException | DecryptionFailure | EncryptionFailure | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates an existing payment credential provider with new authentication credentials.
 */
export declare const updatePaymentCredentialProvider: API.OperationMethod<UpdatePaymentCredentialProviderRequest, UpdatePaymentCredentialProviderResponse, UpdatePaymentCredentialProviderError, Credentials | HttpClient.HttpClient>;
export type UpdatePaymentManagerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing payment manager. This operation uses PATCH semantics, so you only need to specify the fields you want to change.
 */
export declare const updatePaymentManager: API.OperationMethod<UpdatePaymentManagerRequest, UpdatePaymentManagerResponse, UpdatePaymentManagerError, Credentials | HttpClient.HttpClient>;
export type UpdatePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing policy within the AgentCore Policy system. This operation allows modification of the policy description and definition while maintaining the policy's identity. The updated policy is validated against the Cedar schema before being applied. This is an asynchronous operation. Use the `GetPolicy` operation to poll the `status` field to track completion.
 *
 * If the updated policy is a temporal policy, the policy engine invalidates all active temporal sessions. If the update adds or removes temporal operators, the policy engine also invalidates active temporal sessions. For more information about temporal policy sessions, see session-based temporal policies. The policy engine returns an HTTP 409 `ConflictException` to in-flight sessions. To resume, you must start a new session with a new session ID.
 */
export declare const updatePolicy: API.OperationMethod<UpdatePolicyRequest, UpdatePolicyResponse, UpdatePolicyError, Credentials | HttpClient.HttpClient>;
export type UpdatePolicyEngineError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing policy engine within the AgentCore Policy system. This operation allows modification of the policy engine description while maintaining its identity. This is an asynchronous operation. Use the `GetPolicyEngine` operation to poll the `status` field to track completion.
 */
export declare const updatePolicyEngine: API.OperationMethod<UpdatePolicyEngineRequest, UpdatePolicyEngineResponse, UpdatePolicyEngineError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing registry. This operation uses PATCH semantics, so you only need to specify the fields you want to change.
 */
export declare const updateRegistry: API.OperationMethod<UpdateRegistryRequest, UpdateRegistryResponse, UpdateRegistryError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistryRecordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing registry record. This operation uses PATCH semantics, so you only need to specify the fields you want to change. The update is processed asynchronously and returns HTTP 202 Accepted.
 */
export declare const updateRegistryRecord: API.OperationMethod<UpdateRegistryRecordRequest, UpdateRegistryRecordResponse, UpdateRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistryRecordStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status of a registry record. Use this operation to approve, reject, or deprecate a registry record.
 */
export declare const updateRegistryRecordStatus: API.OperationMethod<UpdateRegistryRecordStatusRequest, UpdateRegistryRecordStatusResponse, UpdateRegistryRecordStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkloadIdentityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates an existing workload identity.
 */
export declare const updateWorkloadIdentity: API.OperationMethod<UpdateWorkloadIdentityRequest, UpdateWorkloadIdentityResponse, UpdateWorkloadIdentityError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-agentcore-control.d.ts.map