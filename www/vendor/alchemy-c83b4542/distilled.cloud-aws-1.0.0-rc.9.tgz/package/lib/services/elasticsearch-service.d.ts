import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BaseException_base: S.Class<BaseException, S.TaggedStruct<"BaseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BaseException extends /*@__PURE__*/ BaseException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DisabledOperationException_base: S.Class<DisabledOperationException, S.TaggedStruct<"DisabledOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DisabledOperationException extends /*@__PURE__*/ DisabledOperationException_base {
}
declare const InternalException_base: S.Class<InternalException, S.TaggedStruct<"InternalException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InvalidPaginationTokenException_base: S.Class<InvalidPaginationTokenException, S.TaggedStruct<"InvalidPaginationTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPaginationTokenException extends /*@__PURE__*/ InvalidPaginationTokenException_base {
}
declare const InvalidTypeException_base: S.Class<InvalidTypeException, S.TaggedStruct<"InvalidTypeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidTypeException extends /*@__PURE__*/ InvalidTypeException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.Class<ResourceAlreadyExistsException, S.TaggedStruct<"ResourceAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CrossClusterSearchConnectionId = string;
export interface AcceptInboundCrossClusterSearchConnectionRequest {
    CrossClusterSearchConnectionId: string;
}
export declare const AcceptInboundCrossClusterSearchConnectionRequest: S.Schema<AcceptInboundCrossClusterSearchConnectionRequest>;
export type OwnerId = string;
export type DomainName = string;
export type Region = string;
export interface DomainInformation {
    OwnerId?: string;
    DomainName: string;
    Region?: string;
}
export declare const DomainInformation: S.Schema<DomainInformation>;
export type InboundCrossClusterSearchConnectionStatusCode = "PENDING_ACCEPTANCE" | "APPROVED" | "REJECTING" | "REJECTED" | "DELETING" | "DELETED" | (string & {});
export declare const InboundCrossClusterSearchConnectionStatusCode: any;
export type CrossClusterSearchConnectionStatusMessage = string;
export interface InboundCrossClusterSearchConnectionStatus {
    StatusCode?: InboundCrossClusterSearchConnectionStatusCode;
    Message?: string;
}
export declare const InboundCrossClusterSearchConnectionStatus: S.Schema<InboundCrossClusterSearchConnectionStatus>;
export interface InboundCrossClusterSearchConnection {
    SourceDomainInfo?: DomainInformation;
    DestinationDomainInfo?: DomainInformation;
    CrossClusterSearchConnectionId?: string;
    ConnectionStatus?: InboundCrossClusterSearchConnectionStatus;
}
export declare const InboundCrossClusterSearchConnection: S.Schema<InboundCrossClusterSearchConnection>;
export interface AcceptInboundCrossClusterSearchConnectionResponse {
    CrossClusterSearchConnection?: InboundCrossClusterSearchConnection;
}
export declare const AcceptInboundCrossClusterSearchConnectionResponse: S.Schema<AcceptInboundCrossClusterSearchConnectionResponse>;
export type ARN = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface AddTagsRequest {
    ARN: string;
    TagList: Tag[];
}
export declare const AddTagsRequest: S.Schema<AddTagsRequest>;
export interface AddTagsResponse {
}
export declare const AddTagsResponse: S.Schema<AddTagsResponse>;
export type PackageID = string;
export interface AssociatePackageRequest {
    PackageID: string;
    DomainName: string;
}
export declare const AssociatePackageRequest: S.Schema<AssociatePackageRequest>;
export type PackageName = string;
export type PackageType = "TXT-DICTIONARY" | (string & {});
export declare const PackageType: any;
export type LastUpdated = Date;
export type DomainPackageStatus = "ASSOCIATING" | "ASSOCIATION_FAILED" | "ACTIVE" | "DISSOCIATING" | "DISSOCIATION_FAILED" | (string & {});
export declare const DomainPackageStatus: any;
export type PackageVersion = string;
export type ReferencePath = string;
export type ErrorType = string;
export type ErrorMessage = string;
export interface ErrorDetails {
    ErrorType?: string;
    ErrorMessage?: string;
}
export declare const ErrorDetails: S.Schema<ErrorDetails>;
export interface DomainPackageDetails {
    PackageID?: string;
    PackageName?: string;
    PackageType?: PackageType;
    LastUpdated?: Date;
    DomainName?: string;
    DomainPackageStatus?: DomainPackageStatus;
    PackageVersion?: string;
    ReferencePath?: string;
    ErrorDetails?: ErrorDetails;
}
export declare const DomainPackageDetails: S.Schema<DomainPackageDetails>;
export interface AssociatePackageResponse {
    DomainPackageDetails?: DomainPackageDetails;
}
export declare const AssociatePackageResponse: S.Schema<AssociatePackageResponse>;
export type AWSAccount = string;
export interface AuthorizeVpcEndpointAccessRequest {
    DomainName: string;
    Account: string;
}
export declare const AuthorizeVpcEndpointAccessRequest: S.Schema<AuthorizeVpcEndpointAccessRequest>;
export type PrincipalType = "AWS_ACCOUNT" | "AWS_SERVICE" | (string & {});
export declare const PrincipalType: any;
export interface AuthorizedPrincipal {
    PrincipalType?: PrincipalType;
    Principal?: string;
}
export declare const AuthorizedPrincipal: S.Schema<AuthorizedPrincipal>;
export interface AuthorizeVpcEndpointAccessResponse {
    AuthorizedPrincipal: AuthorizedPrincipal;
}
export declare const AuthorizeVpcEndpointAccessResponse: S.Schema<AuthorizeVpcEndpointAccessResponse>;
export type DryRun = boolean;
export interface CancelDomainConfigChangeRequest {
    DomainName: string;
    DryRun?: boolean;
}
export declare const CancelDomainConfigChangeRequest: S.Schema<CancelDomainConfigChangeRequest>;
export type GUID = string;
export type GUIDList = string[];
export declare const GUIDList: any;
export interface CancelledChangeProperty {
    PropertyName?: string;
    CancelledValue?: string;
    ActiveValue?: string;
}
export declare const CancelledChangeProperty: S.Schema<CancelledChangeProperty>;
export type CancelledChangePropertyList = CancelledChangeProperty[];
export declare const CancelledChangePropertyList: any;
export interface CancelDomainConfigChangeResponse {
    DryRun?: boolean;
    CancelledChangeIds?: string[];
    CancelledChangeProperties?: CancelledChangeProperty[];
}
export declare const CancelDomainConfigChangeResponse: S.Schema<CancelDomainConfigChangeResponse>;
export interface CancelElasticsearchServiceSoftwareUpdateRequest {
    DomainName: string;
}
export declare const CancelElasticsearchServiceSoftwareUpdateRequest: S.Schema<CancelElasticsearchServiceSoftwareUpdateRequest>;
export type DeploymentStatus = "PENDING_UPDATE" | "IN_PROGRESS" | "COMPLETED" | "NOT_ELIGIBLE" | "ELIGIBLE" | (string & {});
export declare const DeploymentStatus: any;
export type DeploymentCloseDateTimeStamp = Date;
export interface ServiceSoftwareOptions {
    CurrentVersion?: string;
    NewVersion?: string;
    UpdateAvailable?: boolean;
    Cancellable?: boolean;
    UpdateStatus?: DeploymentStatus;
    Description?: string;
    AutomatedUpdateDate?: Date;
    OptionalDeployment?: boolean;
}
export declare const ServiceSoftwareOptions: S.Schema<ServiceSoftwareOptions>;
export interface CancelElasticsearchServiceSoftwareUpdateResponse {
    ServiceSoftwareOptions?: ServiceSoftwareOptions;
}
export declare const CancelElasticsearchServiceSoftwareUpdateResponse: S.Schema<CancelElasticsearchServiceSoftwareUpdateResponse>;
export type ElasticsearchVersionString = string;
export type ESPartitionInstanceType = "m3.medium.elasticsearch" | "m3.large.elasticsearch" | "m3.xlarge.elasticsearch" | "m3.2xlarge.elasticsearch" | "m4.large.elasticsearch" | "m4.xlarge.elasticsearch" | "m4.2xlarge.elasticsearch" | "m4.4xlarge.elasticsearch" | "m4.10xlarge.elasticsearch" | "m5.large.elasticsearch" | "m5.xlarge.elasticsearch" | "m5.2xlarge.elasticsearch" | "m5.4xlarge.elasticsearch" | "m5.12xlarge.elasticsearch" | "r5.large.elasticsearch" | "r5.xlarge.elasticsearch" | "r5.2xlarge.elasticsearch" | "r5.4xlarge.elasticsearch" | "r5.12xlarge.elasticsearch" | "c5.large.elasticsearch" | "c5.xlarge.elasticsearch" | "c5.2xlarge.elasticsearch" | "c5.4xlarge.elasticsearch" | "c5.9xlarge.elasticsearch" | "c5.18xlarge.elasticsearch" | "ultrawarm1.medium.elasticsearch" | "ultrawarm1.large.elasticsearch" | "t2.micro.elasticsearch" | "t2.small.elasticsearch" | "t2.medium.elasticsearch" | "r3.large.elasticsearch" | "r3.xlarge.elasticsearch" | "r3.2xlarge.elasticsearch" | "r3.4xlarge.elasticsearch" | "r3.8xlarge.elasticsearch" | "i2.xlarge.elasticsearch" | "i2.2xlarge.elasticsearch" | "d2.xlarge.elasticsearch" | "d2.2xlarge.elasticsearch" | "d2.4xlarge.elasticsearch" | "d2.8xlarge.elasticsearch" | "c4.large.elasticsearch" | "c4.xlarge.elasticsearch" | "c4.2xlarge.elasticsearch" | "c4.4xlarge.elasticsearch" | "c4.8xlarge.elasticsearch" | "r4.large.elasticsearch" | "r4.xlarge.elasticsearch" | "r4.2xlarge.elasticsearch" | "r4.4xlarge.elasticsearch" | "r4.8xlarge.elasticsearch" | "r4.16xlarge.elasticsearch" | "i3.large.elasticsearch" | "i3.xlarge.elasticsearch" | "i3.2xlarge.elasticsearch" | "i3.4xlarge.elasticsearch" | "i3.8xlarge.elasticsearch" | "i3.16xlarge.elasticsearch" | (string & {});
export declare const ESPartitionInstanceType: any;
export type IntegerClass = number;
export interface ZoneAwarenessConfig {
    AvailabilityZoneCount?: number;
}
export declare const ZoneAwarenessConfig: S.Schema<ZoneAwarenessConfig>;
export type ESWarmPartitionInstanceType = "ultrawarm1.medium.elasticsearch" | "ultrawarm1.large.elasticsearch" | (string & {});
export declare const ESWarmPartitionInstanceType: any;
export interface ColdStorageOptions {
    Enabled: boolean;
}
export declare const ColdStorageOptions: S.Schema<ColdStorageOptions>;
export interface ElasticsearchClusterConfig {
    InstanceType?: ESPartitionInstanceType;
    InstanceCount?: number;
    DedicatedMasterEnabled?: boolean;
    ZoneAwarenessEnabled?: boolean;
    ZoneAwarenessConfig?: ZoneAwarenessConfig;
    DedicatedMasterType?: ESPartitionInstanceType;
    DedicatedMasterCount?: number;
    WarmEnabled?: boolean;
    WarmType?: ESWarmPartitionInstanceType;
    WarmCount?: number;
    ColdStorageOptions?: ColdStorageOptions;
}
export declare const ElasticsearchClusterConfig: S.Schema<ElasticsearchClusterConfig>;
export type VolumeType = "standard" | "gp2" | "io1" | "gp3" | (string & {});
export declare const VolumeType: any;
export interface EBSOptions {
    EBSEnabled?: boolean;
    VolumeType?: VolumeType;
    VolumeSize?: number;
    Iops?: number;
    Throughput?: number;
}
export declare const EBSOptions: S.Schema<EBSOptions>;
export type PolicyDocument = string;
export interface SnapshotOptions {
    AutomatedSnapshotStartHour?: number;
}
export declare const SnapshotOptions: S.Schema<SnapshotOptions>;
export type StringList = string[];
export declare const StringList: any;
export interface VPCOptions {
    SubnetIds?: string[];
    SecurityGroupIds?: string[];
}
export declare const VPCOptions: S.Schema<VPCOptions>;
export type UserPoolId = string;
export type IdentityPoolId = string;
export type RoleArn = string;
export interface CognitoOptions {
    Enabled?: boolean;
    UserPoolId?: string;
    IdentityPoolId?: string;
    RoleArn?: string;
}
export declare const CognitoOptions: S.Schema<CognitoOptions>;
export type KmsKeyId = string;
export interface EncryptionAtRestOptions {
    Enabled?: boolean;
    KmsKeyId?: string;
}
export declare const EncryptionAtRestOptions: S.Schema<EncryptionAtRestOptions>;
export interface NodeToNodeEncryptionOptions {
    Enabled?: boolean;
}
export declare const NodeToNodeEncryptionOptions: S.Schema<NodeToNodeEncryptionOptions>;
export type AdvancedOptions = {
    [key: string]: string | undefined;
};
export declare const AdvancedOptions: any;
export type LogType = "INDEX_SLOW_LOGS" | "SEARCH_SLOW_LOGS" | "ES_APPLICATION_LOGS" | "AUDIT_LOGS" | (string & {});
export declare const LogType: any;
export type CloudWatchLogsLogGroupArn = string;
export interface LogPublishingOption {
    CloudWatchLogsLogGroupArn?: string;
    Enabled?: boolean;
}
export declare const LogPublishingOption: S.Schema<LogPublishingOption>;
export type LogPublishingOptions = {
    [key in LogType]?: LogPublishingOption;
};
export declare const LogPublishingOptions: any;
export type TLSSecurityPolicy = "Policy-Min-TLS-1-0-2019-07" | "Policy-Min-TLS-1-2-2019-07" | "Policy-Min-TLS-1-2-PFS-2023-10" | "Policy-Min-TLS-1-2-RFC9151-FIPS-2024-08" | (string & {});
export declare const TLSSecurityPolicy: any;
export type DomainNameFqdn = string;
export interface DomainEndpointOptions {
    EnforceHTTPS?: boolean;
    TLSSecurityPolicy?: TLSSecurityPolicy;
    CustomEndpointEnabled?: boolean;
    CustomEndpoint?: string;
    CustomEndpointCertificateArn?: string;
}
export declare const DomainEndpointOptions: S.Schema<DomainEndpointOptions>;
export type Username = string | redacted.Redacted<string>;
export type Password = string | redacted.Redacted<string>;
export interface MasterUserOptions {
    MasterUserARN?: string;
    MasterUserName?: string | redacted.Redacted<string>;
    MasterUserPassword?: string | redacted.Redacted<string>;
}
export declare const MasterUserOptions: S.Schema<MasterUserOptions>;
export type SAMLMetadata = string;
export type SAMLEntityId = string;
export interface SAMLIdp {
    MetadataContent: string;
    EntityId: string;
}
export declare const SAMLIdp: S.Schema<SAMLIdp>;
export type BackendRole = string;
export interface SAMLOptionsInput {
    Enabled?: boolean;
    Idp?: SAMLIdp;
    MasterUserName?: string | redacted.Redacted<string>;
    MasterBackendRole?: string;
    SubjectKey?: string;
    RolesKey?: string;
    SessionTimeoutMinutes?: number;
}
export declare const SAMLOptionsInput: S.Schema<SAMLOptionsInput>;
export interface AdvancedSecurityOptionsInput {
    Enabled?: boolean;
    InternalUserDatabaseEnabled?: boolean;
    MasterUserOptions?: MasterUserOptions;
    SAMLOptions?: SAMLOptionsInput;
    AnonymousAuthEnabled?: boolean;
}
export declare const AdvancedSecurityOptionsInput: S.Schema<AdvancedSecurityOptionsInput>;
export type AutoTuneDesiredState = "ENABLED" | "DISABLED" | (string & {});
export declare const AutoTuneDesiredState: any;
export type StartAt = Date;
export type DurationValue = number;
export type TimeUnit = "HOURS" | (string & {});
export declare const TimeUnit: any;
export interface Duration {
    Value?: number;
    Unit?: TimeUnit;
}
export declare const Duration: S.Schema<Duration>;
export interface AutoTuneMaintenanceSchedule {
    StartAt?: Date;
    Duration?: Duration;
    CronExpressionForRecurrence?: string;
}
export declare const AutoTuneMaintenanceSchedule: S.Schema<AutoTuneMaintenanceSchedule>;
export type AutoTuneMaintenanceScheduleList = AutoTuneMaintenanceSchedule[];
export declare const AutoTuneMaintenanceScheduleList: any;
export interface AutoTuneOptionsInput {
    DesiredState?: AutoTuneDesiredState;
    MaintenanceSchedules?: AutoTuneMaintenanceSchedule[];
}
export declare const AutoTuneOptionsInput: S.Schema<AutoTuneOptionsInput>;
export type DeploymentStrategy = "Default" | "CapacityOptimized" | (string & {});
export declare const DeploymentStrategy: any;
export interface DeploymentStrategyOptions {
    DeploymentStrategy: DeploymentStrategy;
}
export declare const DeploymentStrategyOptions: S.Schema<DeploymentStrategyOptions>;
export type UpdateTimestamp = Date;
export interface AutomatedSnapshotPauseRequestOptions {
    Enabled: boolean;
    StartTime?: Date;
    EndTime?: Date;
}
export declare const AutomatedSnapshotPauseRequestOptions: S.Schema<AutomatedSnapshotPauseRequestOptions>;
export type DomainUseCase = "SEARCH" | "VECTOR" | "OBSERVABILITY" | "MIXED" | (string & {});
export declare const DomainUseCase: any;
export type DomainEngineMode = "GENERAL" | "OPTIMIZED" | (string & {});
export declare const DomainEngineMode: any;
export interface CreateElasticsearchDomainRequest {
    DomainName: string;
    ElasticsearchVersion?: string;
    ElasticsearchClusterConfig?: ElasticsearchClusterConfig;
    EBSOptions?: EBSOptions;
    AccessPolicies?: string;
    SnapshotOptions?: SnapshotOptions;
    VPCOptions?: VPCOptions;
    CognitoOptions?: CognitoOptions;
    EncryptionAtRestOptions?: EncryptionAtRestOptions;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptions;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    };
    LogPublishingOptions?: {
        [key: string]: LogPublishingOption | undefined;
    };
    DomainEndpointOptions?: DomainEndpointOptions;
    AdvancedSecurityOptions?: AdvancedSecurityOptionsInput;
    AutoTuneOptions?: AutoTuneOptionsInput;
    TagList?: Tag[];
    DeploymentStrategyOptions?: DeploymentStrategyOptions;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseRequestOptions;
    UseCase?: DomainUseCase;
    EngineMode?: DomainEngineMode;
}
export declare const CreateElasticsearchDomainRequest: S.Schema<CreateElasticsearchDomainRequest>;
export type DomainId = string;
export type ServiceUrl = string;
export type EndpointsMap = {
    [key: string]: string | undefined;
};
export declare const EndpointsMap: any;
export interface VPCDerivedInfo {
    VPCId?: string;
    SubnetIds?: string[];
    AvailabilityZones?: string[];
    SecurityGroupIds?: string[];
}
export declare const VPCDerivedInfo: S.Schema<VPCDerivedInfo>;
export interface SAMLOptionsOutput {
    Enabled?: boolean;
    Idp?: SAMLIdp;
    SubjectKey?: string;
    RolesKey?: string;
    SessionTimeoutMinutes?: number;
}
export declare const SAMLOptionsOutput: S.Schema<SAMLOptionsOutput>;
export type DisableTimestamp = Date;
export interface AdvancedSecurityOptions {
    Enabled?: boolean;
    InternalUserDatabaseEnabled?: boolean;
    SAMLOptions?: SAMLOptionsOutput;
    AnonymousAuthDisableDate?: Date;
    AnonymousAuthEnabled?: boolean;
}
export declare const AdvancedSecurityOptions: S.Schema<AdvancedSecurityOptions>;
export type AutoTuneState = "ENABLED" | "DISABLED" | "ENABLE_IN_PROGRESS" | "DISABLE_IN_PROGRESS" | "DISABLED_AND_ROLLBACK_SCHEDULED" | "DISABLED_AND_ROLLBACK_IN_PROGRESS" | "DISABLED_AND_ROLLBACK_COMPLETE" | "DISABLED_AND_ROLLBACK_ERROR" | "ERROR" | (string & {});
export declare const AutoTuneState: any;
export interface AutoTuneOptionsOutput {
    State?: AutoTuneState;
    ErrorMessage?: string;
}
export declare const AutoTuneOptionsOutput: S.Schema<AutoTuneOptionsOutput>;
export type Message = string;
export type ConfigChangeStatus = "Pending" | "Initializing" | "Validating" | "ValidationFailed" | "ApplyingChanges" | "Completed" | "PendingUserInput" | "Cancelled" | (string & {});
export declare const ConfigChangeStatus: any;
export type InitiatedBy = "CUSTOMER" | "SERVICE" | (string & {});
export declare const InitiatedBy: any;
export interface ChangeProgressDetails {
    ChangeId?: string;
    Message?: string;
    ConfigChangeStatus?: ConfigChangeStatus;
    StartTime?: Date;
    LastUpdatedTime?: Date;
    InitiatedBy?: InitiatedBy;
}
export declare const ChangeProgressDetails: S.Schema<ChangeProgressDetails>;
export type DomainProcessingStatusType = "Creating" | "Active" | "Modifying" | "UpgradingEngineVersion" | "UpdatingServiceSoftware" | "Isolated" | "Deleting" | (string & {});
export declare const DomainProcessingStatusType: any;
export type PropertyValueType = "PLAIN_TEXT" | "STRINGIFIED_JSON" | (string & {});
export declare const PropertyValueType: any;
export interface ModifyingProperties {
    Name?: string;
    ActiveValue?: string;
    PendingValue?: string;
    ValueType?: PropertyValueType;
}
export declare const ModifyingProperties: S.Schema<ModifyingProperties>;
export type ModifyingPropertiesList = ModifyingProperties[];
export declare const ModifyingPropertiesList: any;
export type PauseState = "Active" | "Completed" | "Scheduled" | "Disabled" | (string & {});
export declare const PauseState: any;
export interface AutomatedSnapshotPauseOptions {
    Enabled: boolean;
    StartTime?: Date;
    EndTime?: Date;
    State?: PauseState;
}
export declare const AutomatedSnapshotPauseOptions: S.Schema<AutomatedSnapshotPauseOptions>;
export interface ElasticsearchDomainStatus {
    DomainId: string;
    DomainName: string;
    ARN: string;
    Created?: boolean;
    Deleted?: boolean;
    Endpoint?: string;
    Endpoints?: {
        [key: string]: string | undefined;
    };
    Processing?: boolean;
    UpgradeProcessing?: boolean;
    ElasticsearchVersion?: string;
    ElasticsearchClusterConfig: ElasticsearchClusterConfig;
    EBSOptions?: EBSOptions;
    AccessPolicies?: string;
    SnapshotOptions?: SnapshotOptions;
    VPCOptions?: VPCDerivedInfo;
    CognitoOptions?: CognitoOptions;
    EncryptionAtRestOptions?: EncryptionAtRestOptions;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptions;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    };
    LogPublishingOptions?: {
        [key: string]: LogPublishingOption | undefined;
    };
    ServiceSoftwareOptions?: ServiceSoftwareOptions;
    DomainEndpointOptions?: DomainEndpointOptions;
    AdvancedSecurityOptions?: AdvancedSecurityOptions;
    AutoTuneOptions?: AutoTuneOptionsOutput;
    ChangeProgressDetails?: ChangeProgressDetails;
    DomainProcessingStatus?: DomainProcessingStatusType;
    ModifyingProperties?: ModifyingProperties[];
    DeploymentStrategyOptions?: DeploymentStrategyOptions;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseOptions;
    UseCase?: DomainUseCase;
    EngineMode?: DomainEngineMode;
}
export declare const ElasticsearchDomainStatus: S.Schema<ElasticsearchDomainStatus>;
export interface CreateElasticsearchDomainResponse {
    DomainStatus?: ElasticsearchDomainStatus;
}
export declare const CreateElasticsearchDomainResponse: S.Schema<CreateElasticsearchDomainResponse>;
export type ConnectionAlias = string;
export interface CreateOutboundCrossClusterSearchConnectionRequest {
    SourceDomainInfo: DomainInformation;
    DestinationDomainInfo: DomainInformation;
    ConnectionAlias: string;
}
export declare const CreateOutboundCrossClusterSearchConnectionRequest: S.Schema<CreateOutboundCrossClusterSearchConnectionRequest>;
export type OutboundCrossClusterSearchConnectionStatusCode = "PENDING_ACCEPTANCE" | "VALIDATING" | "VALIDATION_FAILED" | "PROVISIONING" | "ACTIVE" | "REJECTED" | "DELETING" | "DELETED" | (string & {});
export declare const OutboundCrossClusterSearchConnectionStatusCode: any;
export interface OutboundCrossClusterSearchConnectionStatus {
    StatusCode?: OutboundCrossClusterSearchConnectionStatusCode;
    Message?: string;
}
export declare const OutboundCrossClusterSearchConnectionStatus: S.Schema<OutboundCrossClusterSearchConnectionStatus>;
export interface CreateOutboundCrossClusterSearchConnectionResponse {
    SourceDomainInfo?: DomainInformation;
    DestinationDomainInfo?: DomainInformation;
    ConnectionAlias?: string;
    ConnectionStatus?: OutboundCrossClusterSearchConnectionStatus;
    CrossClusterSearchConnectionId?: string;
}
export declare const CreateOutboundCrossClusterSearchConnectionResponse: S.Schema<CreateOutboundCrossClusterSearchConnectionResponse>;
export type PackageDescription = string;
export type S3BucketName = string;
export type S3Key = string;
export interface PackageSource {
    S3BucketName?: string;
    S3Key?: string;
}
export declare const PackageSource: S.Schema<PackageSource>;
export interface CreatePackageRequest {
    PackageName: string;
    PackageType: PackageType;
    PackageDescription?: string;
    PackageSource: PackageSource;
}
export declare const CreatePackageRequest: S.Schema<CreatePackageRequest>;
export type PackageStatus = "COPYING" | "COPY_FAILED" | "VALIDATING" | "VALIDATION_FAILED" | "AVAILABLE" | "DELETING" | "DELETED" | "DELETE_FAILED" | (string & {});
export declare const PackageStatus: any;
export type CreatedAt = Date;
export interface PackageDetails {
    PackageID?: string;
    PackageName?: string;
    PackageType?: PackageType;
    PackageDescription?: string;
    PackageStatus?: PackageStatus;
    CreatedAt?: Date;
    LastUpdatedAt?: Date;
    AvailablePackageVersion?: string;
    ErrorDetails?: ErrorDetails;
}
export declare const PackageDetails: S.Schema<PackageDetails>;
export interface CreatePackageResponse {
    PackageDetails?: PackageDetails;
}
export declare const CreatePackageResponse: S.Schema<CreatePackageResponse>;
export type DomainArn = string;
export type ClientToken = string;
export interface CreateVpcEndpointRequest {
    DomainArn: string;
    VpcOptions: VPCOptions;
    ClientToken?: string;
}
export declare const CreateVpcEndpointRequest: S.Schema<CreateVpcEndpointRequest>;
export type VpcEndpointId = string;
export type VpcEndpointStatus = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "UPDATING" | "UPDATE_FAILED" | "DELETING" | "DELETE_FAILED" | (string & {});
export declare const VpcEndpointStatus: any;
export type Endpoint = string;
export interface VpcEndpoint {
    VpcEndpointId?: string;
    VpcEndpointOwner?: string;
    DomainArn?: string;
    VpcOptions?: VPCDerivedInfo;
    Status?: VpcEndpointStatus;
    Endpoint?: string;
}
export declare const VpcEndpoint: S.Schema<VpcEndpoint>;
export interface CreateVpcEndpointResponse {
    VpcEndpoint: VpcEndpoint;
}
export declare const CreateVpcEndpointResponse: S.Schema<CreateVpcEndpointResponse>;
export interface DeleteElasticsearchDomainRequest {
    DomainName: string;
}
export declare const DeleteElasticsearchDomainRequest: S.Schema<DeleteElasticsearchDomainRequest>;
export interface DeleteElasticsearchDomainResponse {
    DomainStatus?: ElasticsearchDomainStatus;
}
export declare const DeleteElasticsearchDomainResponse: S.Schema<DeleteElasticsearchDomainResponse>;
export interface DeleteElasticsearchServiceRoleRequest {
}
export declare const DeleteElasticsearchServiceRoleRequest: S.Schema<DeleteElasticsearchServiceRoleRequest>;
export interface DeleteElasticsearchServiceRoleResponse {
}
export declare const DeleteElasticsearchServiceRoleResponse: S.Schema<DeleteElasticsearchServiceRoleResponse>;
export interface DeleteInboundCrossClusterSearchConnectionRequest {
    CrossClusterSearchConnectionId: string;
}
export declare const DeleteInboundCrossClusterSearchConnectionRequest: S.Schema<DeleteInboundCrossClusterSearchConnectionRequest>;
export interface DeleteInboundCrossClusterSearchConnectionResponse {
    CrossClusterSearchConnection?: InboundCrossClusterSearchConnection;
}
export declare const DeleteInboundCrossClusterSearchConnectionResponse: S.Schema<DeleteInboundCrossClusterSearchConnectionResponse>;
export interface DeleteOutboundCrossClusterSearchConnectionRequest {
    CrossClusterSearchConnectionId: string;
}
export declare const DeleteOutboundCrossClusterSearchConnectionRequest: S.Schema<DeleteOutboundCrossClusterSearchConnectionRequest>;
export interface OutboundCrossClusterSearchConnection {
    SourceDomainInfo?: DomainInformation;
    DestinationDomainInfo?: DomainInformation;
    CrossClusterSearchConnectionId?: string;
    ConnectionAlias?: string;
    ConnectionStatus?: OutboundCrossClusterSearchConnectionStatus;
}
export declare const OutboundCrossClusterSearchConnection: S.Schema<OutboundCrossClusterSearchConnection>;
export interface DeleteOutboundCrossClusterSearchConnectionResponse {
    CrossClusterSearchConnection?: OutboundCrossClusterSearchConnection;
}
export declare const DeleteOutboundCrossClusterSearchConnectionResponse: S.Schema<DeleteOutboundCrossClusterSearchConnectionResponse>;
export interface DeletePackageRequest {
    PackageID: string;
}
export declare const DeletePackageRequest: S.Schema<DeletePackageRequest>;
export interface DeletePackageResponse {
    PackageDetails?: PackageDetails;
}
export declare const DeletePackageResponse: S.Schema<DeletePackageResponse>;
export interface DeleteVpcEndpointRequest {
    VpcEndpointId: string;
}
export declare const DeleteVpcEndpointRequest: S.Schema<DeleteVpcEndpointRequest>;
export interface VpcEndpointSummary {
    VpcEndpointId?: string;
    VpcEndpointOwner?: string;
    DomainArn?: string;
    Status?: VpcEndpointStatus;
}
export declare const VpcEndpointSummary: S.Schema<VpcEndpointSummary>;
export interface DeleteVpcEndpointResponse {
    VpcEndpointSummary: VpcEndpointSummary;
}
export declare const DeleteVpcEndpointResponse: S.Schema<DeleteVpcEndpointResponse>;
export type MaxResults = number;
export type NextToken = string;
export interface DescribeDomainAutoTunesRequest {
    DomainName: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeDomainAutoTunesRequest: S.Schema<DescribeDomainAutoTunesRequest>;
export type AutoTuneType = "SCHEDULED_ACTION" | (string & {});
export declare const AutoTuneType: any;
export type AutoTuneDate = Date;
export type ScheduledAutoTuneActionType = "JVM_HEAP_SIZE_TUNING" | "JVM_YOUNG_GEN_TUNING" | (string & {});
export declare const ScheduledAutoTuneActionType: any;
export type ScheduledAutoTuneDescription = string;
export type ScheduledAutoTuneSeverityType = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export declare const ScheduledAutoTuneSeverityType: any;
export interface ScheduledAutoTuneDetails {
    Date?: Date;
    ActionType?: ScheduledAutoTuneActionType;
    Action?: string;
    Severity?: ScheduledAutoTuneSeverityType;
}
export declare const ScheduledAutoTuneDetails: S.Schema<ScheduledAutoTuneDetails>;
export interface AutoTuneDetails {
    ScheduledAutoTuneDetails?: ScheduledAutoTuneDetails;
}
export declare const AutoTuneDetails: S.Schema<AutoTuneDetails>;
export interface AutoTune {
    AutoTuneType?: AutoTuneType;
    AutoTuneDetails?: AutoTuneDetails;
}
export declare const AutoTune: S.Schema<AutoTune>;
export type AutoTuneList = AutoTune[];
export declare const AutoTuneList: any;
export interface DescribeDomainAutoTunesResponse {
    AutoTunes?: AutoTune[];
    NextToken?: string;
}
export declare const DescribeDomainAutoTunesResponse: S.Schema<DescribeDomainAutoTunesResponse>;
export interface DescribeDomainChangeProgressRequest {
    DomainName: string;
    ChangeId?: string;
}
export declare const DescribeDomainChangeProgressRequest: S.Schema<DescribeDomainChangeProgressRequest>;
export type OverallChangeStatus = "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED" | (string & {});
export declare const OverallChangeStatus: any;
export type TotalNumberOfStages = number;
export type ChangeProgressStageName = string;
export type ChangeProgressStageStatus = string;
export type Description = string;
export interface ChangeProgressStage {
    Name?: string;
    Status?: string;
    Description?: string;
    LastUpdated?: Date;
}
export declare const ChangeProgressStage: S.Schema<ChangeProgressStage>;
export type ChangeProgressStageList = ChangeProgressStage[];
export declare const ChangeProgressStageList: any;
export interface ChangeProgressStatusDetails {
    ChangeId?: string;
    StartTime?: Date;
    Status?: OverallChangeStatus;
    PendingProperties?: string[];
    CompletedProperties?: string[];
    TotalNumberOfStages?: number;
    ChangeProgressStages?: ChangeProgressStage[];
    ConfigChangeStatus?: ConfigChangeStatus;
    LastUpdatedTime?: Date;
    InitiatedBy?: InitiatedBy;
}
export declare const ChangeProgressStatusDetails: S.Schema<ChangeProgressStatusDetails>;
export interface DescribeDomainChangeProgressResponse {
    ChangeProgressStatus?: ChangeProgressStatusDetails;
}
export declare const DescribeDomainChangeProgressResponse: S.Schema<DescribeDomainChangeProgressResponse>;
export interface DescribeElasticsearchDomainRequest {
    DomainName: string;
}
export declare const DescribeElasticsearchDomainRequest: S.Schema<DescribeElasticsearchDomainRequest>;
export interface DescribeElasticsearchDomainResponse {
    DomainStatus: ElasticsearchDomainStatus;
}
export declare const DescribeElasticsearchDomainResponse: S.Schema<DescribeElasticsearchDomainResponse>;
export interface DescribeElasticsearchDomainConfigRequest {
    DomainName: string;
}
export declare const DescribeElasticsearchDomainConfigRequest: S.Schema<DescribeElasticsearchDomainConfigRequest>;
export type UIntValue = number;
export type OptionState = "RequiresIndexDocuments" | "Processing" | "Active" | (string & {});
export declare const OptionState: any;
export interface OptionStatus {
    CreationDate: Date;
    UpdateDate: Date;
    UpdateVersion?: number;
    State: OptionState;
    PendingDeletion?: boolean;
}
export declare const OptionStatus: S.Schema<OptionStatus>;
export interface ElasticsearchVersionStatus {
    Options: string;
    Status: OptionStatus;
}
export declare const ElasticsearchVersionStatus: S.Schema<ElasticsearchVersionStatus>;
export interface ElasticsearchClusterConfigStatus {
    Options: ElasticsearchClusterConfig;
    Status: OptionStatus;
}
export declare const ElasticsearchClusterConfigStatus: S.Schema<ElasticsearchClusterConfigStatus>;
export interface EBSOptionsStatus {
    Options: EBSOptions;
    Status: OptionStatus;
}
export declare const EBSOptionsStatus: S.Schema<EBSOptionsStatus>;
export interface AccessPoliciesStatus {
    Options: string;
    Status: OptionStatus;
}
export declare const AccessPoliciesStatus: S.Schema<AccessPoliciesStatus>;
export interface SnapshotOptionsStatus {
    Options: SnapshotOptions;
    Status: OptionStatus;
}
export declare const SnapshotOptionsStatus: S.Schema<SnapshotOptionsStatus>;
export interface VPCDerivedInfoStatus {
    Options: VPCDerivedInfo;
    Status: OptionStatus;
}
export declare const VPCDerivedInfoStatus: S.Schema<VPCDerivedInfoStatus>;
export interface CognitoOptionsStatus {
    Options: CognitoOptions;
    Status: OptionStatus;
}
export declare const CognitoOptionsStatus: S.Schema<CognitoOptionsStatus>;
export interface EncryptionAtRestOptionsStatus {
    Options: EncryptionAtRestOptions;
    Status: OptionStatus;
}
export declare const EncryptionAtRestOptionsStatus: S.Schema<EncryptionAtRestOptionsStatus>;
export interface NodeToNodeEncryptionOptionsStatus {
    Options: NodeToNodeEncryptionOptions;
    Status: OptionStatus;
}
export declare const NodeToNodeEncryptionOptionsStatus: S.Schema<NodeToNodeEncryptionOptionsStatus>;
export interface AdvancedOptionsStatus {
    Options: {
        [key: string]: string | undefined;
    };
    Status: OptionStatus;
}
export declare const AdvancedOptionsStatus: S.Schema<AdvancedOptionsStatus>;
export interface LogPublishingOptionsStatus {
    Options?: {
        [key: string]: LogPublishingOption | undefined;
    };
    Status?: OptionStatus;
}
export declare const LogPublishingOptionsStatus: S.Schema<LogPublishingOptionsStatus>;
export interface DomainEndpointOptionsStatus {
    Options: DomainEndpointOptions;
    Status: OptionStatus;
}
export declare const DomainEndpointOptionsStatus: S.Schema<DomainEndpointOptionsStatus>;
export interface AdvancedSecurityOptionsStatus {
    Options: AdvancedSecurityOptions;
    Status: OptionStatus;
}
export declare const AdvancedSecurityOptionsStatus: S.Schema<AdvancedSecurityOptionsStatus>;
export type RollbackOnDisable = "NO_ROLLBACK" | "DEFAULT_ROLLBACK" | (string & {});
export declare const RollbackOnDisable: any;
export interface AutoTuneOptions {
    DesiredState?: AutoTuneDesiredState;
    RollbackOnDisable?: RollbackOnDisable;
    MaintenanceSchedules?: AutoTuneMaintenanceSchedule[];
}
export declare const AutoTuneOptions: S.Schema<AutoTuneOptions>;
export interface AutoTuneStatus {
    CreationDate: Date;
    UpdateDate: Date;
    UpdateVersion?: number;
    State: AutoTuneState;
    ErrorMessage?: string;
    PendingDeletion?: boolean;
}
export declare const AutoTuneStatus: S.Schema<AutoTuneStatus>;
export interface AutoTuneOptionsStatus {
    Options?: AutoTuneOptions;
    Status?: AutoTuneStatus;
}
export declare const AutoTuneOptionsStatus: S.Schema<AutoTuneOptionsStatus>;
export interface DeploymentStrategyOptionsStatus {
    Options: DeploymentStrategyOptions;
    Status: OptionStatus;
}
export declare const DeploymentStrategyOptionsStatus: S.Schema<DeploymentStrategyOptionsStatus>;
export interface AutomatedSnapshotPauseOptionsStatus {
    Options: AutomatedSnapshotPauseOptions;
    Status: OptionStatus;
}
export declare const AutomatedSnapshotPauseOptionsStatus: S.Schema<AutomatedSnapshotPauseOptionsStatus>;
export interface UseCaseStatus {
    Options: DomainUseCase;
    Status: OptionStatus;
}
export declare const UseCaseStatus: S.Schema<UseCaseStatus>;
export interface EngineModeStatus {
    Options: DomainEngineMode;
    Status: OptionStatus;
}
export declare const EngineModeStatus: S.Schema<EngineModeStatus>;
export interface ElasticsearchDomainConfig {
    ElasticsearchVersion?: ElasticsearchVersionStatus;
    ElasticsearchClusterConfig?: ElasticsearchClusterConfigStatus;
    EBSOptions?: EBSOptionsStatus;
    AccessPolicies?: AccessPoliciesStatus;
    SnapshotOptions?: SnapshotOptionsStatus;
    VPCOptions?: VPCDerivedInfoStatus;
    CognitoOptions?: CognitoOptionsStatus;
    EncryptionAtRestOptions?: EncryptionAtRestOptionsStatus;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptionsStatus;
    AdvancedOptions?: AdvancedOptionsStatus;
    LogPublishingOptions?: LogPublishingOptionsStatus;
    DomainEndpointOptions?: DomainEndpointOptionsStatus;
    AdvancedSecurityOptions?: AdvancedSecurityOptionsStatus;
    AutoTuneOptions?: AutoTuneOptionsStatus;
    ChangeProgressDetails?: ChangeProgressDetails;
    ModifyingProperties?: ModifyingProperties[];
    DeploymentStrategyOptions?: DeploymentStrategyOptionsStatus;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseOptionsStatus;
    UseCase?: UseCaseStatus;
    EngineMode?: EngineModeStatus;
}
export declare const ElasticsearchDomainConfig: S.Schema<ElasticsearchDomainConfig>;
export interface DescribeElasticsearchDomainConfigResponse {
    DomainConfig: ElasticsearchDomainConfig;
}
export declare const DescribeElasticsearchDomainConfigResponse: S.Schema<DescribeElasticsearchDomainConfigResponse>;
export type DomainNameList = string[];
export declare const DomainNameList: any;
export interface DescribeElasticsearchDomainsRequest {
    DomainNames: string[];
}
export declare const DescribeElasticsearchDomainsRequest: S.Schema<DescribeElasticsearchDomainsRequest>;
export type ElasticsearchDomainStatusList = ElasticsearchDomainStatus[];
export declare const ElasticsearchDomainStatusList: any;
export interface DescribeElasticsearchDomainsResponse {
    DomainStatusList: ElasticsearchDomainStatus[];
}
export declare const DescribeElasticsearchDomainsResponse: S.Schema<DescribeElasticsearchDomainsResponse>;
export interface DescribeElasticsearchInstanceTypeLimitsRequest {
    DomainName?: string;
    InstanceType: ESPartitionInstanceType;
    ElasticsearchVersion: string;
}
export declare const DescribeElasticsearchInstanceTypeLimitsRequest: S.Schema<DescribeElasticsearchInstanceTypeLimitsRequest>;
export type InstanceRole = string;
export type StorageTypeName = string;
export type StorageSubTypeName = string;
export type LimitName = string;
export type LimitValue = string;
export type LimitValueList = string[];
export declare const LimitValueList: any;
export interface StorageTypeLimit {
    LimitName?: string;
    LimitValues?: string[];
}
export declare const StorageTypeLimit: S.Schema<StorageTypeLimit>;
export type StorageTypeLimitList = StorageTypeLimit[];
export declare const StorageTypeLimitList: any;
export interface StorageType {
    StorageTypeName?: string;
    StorageSubTypeName?: string;
    StorageTypeLimits?: StorageTypeLimit[];
}
export declare const StorageType: S.Schema<StorageType>;
export type StorageTypeList = StorageType[];
export declare const StorageTypeList: any;
export type MinimumInstanceCount = number;
export type MaximumInstanceCount = number;
export interface InstanceCountLimits {
    MinimumInstanceCount?: number;
    MaximumInstanceCount?: number;
}
export declare const InstanceCountLimits: S.Schema<InstanceCountLimits>;
export interface InstanceLimits {
    InstanceCountLimits?: InstanceCountLimits;
}
export declare const InstanceLimits: S.Schema<InstanceLimits>;
export interface AdditionalLimit {
    LimitName?: string;
    LimitValues?: string[];
}
export declare const AdditionalLimit: S.Schema<AdditionalLimit>;
export type AdditionalLimitList = AdditionalLimit[];
export declare const AdditionalLimitList: any;
export interface Limits {
    StorageTypes?: StorageType[];
    InstanceLimits?: InstanceLimits;
    AdditionalLimits?: AdditionalLimit[];
}
export declare const Limits: S.Schema<Limits>;
export type LimitsByRole = {
    [key: string]: Limits | undefined;
};
export declare const LimitsByRole: any;
export interface DescribeElasticsearchInstanceTypeLimitsResponse {
    LimitsByRole?: {
        [key: string]: Limits | undefined;
    };
}
export declare const DescribeElasticsearchInstanceTypeLimitsResponse: S.Schema<DescribeElasticsearchInstanceTypeLimitsResponse>;
export type NonEmptyString = string;
export type ValueStringList = string[];
export declare const ValueStringList: any;
export interface Filter {
    Name?: string;
    Values?: string[];
}
export declare const Filter: S.Schema<Filter>;
export type FilterList = Filter[];
export declare const FilterList: any;
export interface DescribeInboundCrossClusterSearchConnectionsRequest {
    Filters?: Filter[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeInboundCrossClusterSearchConnectionsRequest: S.Schema<DescribeInboundCrossClusterSearchConnectionsRequest>;
export type InboundCrossClusterSearchConnections = InboundCrossClusterSearchConnection[];
export declare const InboundCrossClusterSearchConnections: any;
export interface DescribeInboundCrossClusterSearchConnectionsResponse {
    CrossClusterSearchConnections?: InboundCrossClusterSearchConnection[];
    NextToken?: string;
}
export declare const DescribeInboundCrossClusterSearchConnectionsResponse: S.Schema<DescribeInboundCrossClusterSearchConnectionsResponse>;
export interface DescribeOutboundCrossClusterSearchConnectionsRequest {
    Filters?: Filter[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeOutboundCrossClusterSearchConnectionsRequest: S.Schema<DescribeOutboundCrossClusterSearchConnectionsRequest>;
export type OutboundCrossClusterSearchConnections = OutboundCrossClusterSearchConnection[];
export declare const OutboundCrossClusterSearchConnections: any;
export interface DescribeOutboundCrossClusterSearchConnectionsResponse {
    CrossClusterSearchConnections?: OutboundCrossClusterSearchConnection[];
    NextToken?: string;
}
export declare const DescribeOutboundCrossClusterSearchConnectionsResponse: S.Schema<DescribeOutboundCrossClusterSearchConnectionsResponse>;
export type DescribePackagesFilterName = "PackageID" | "PackageName" | "PackageStatus" | (string & {});
export declare const DescribePackagesFilterName: any;
export type DescribePackagesFilterValue = string;
export type DescribePackagesFilterValues = string[];
export declare const DescribePackagesFilterValues: any;
export interface DescribePackagesFilter {
    Name?: DescribePackagesFilterName;
    Value?: string[];
}
export declare const DescribePackagesFilter: S.Schema<DescribePackagesFilter>;
export type DescribePackagesFilterList = DescribePackagesFilter[];
export declare const DescribePackagesFilterList: any;
export interface DescribePackagesRequest {
    Filters?: DescribePackagesFilter[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribePackagesRequest: S.Schema<DescribePackagesRequest>;
export type PackageDetailsList = PackageDetails[];
export declare const PackageDetailsList: any;
export interface DescribePackagesResponse {
    PackageDetailsList?: PackageDetails[];
    NextToken?: string;
}
export declare const DescribePackagesResponse: S.Schema<DescribePackagesResponse>;
export interface DescribeReservedElasticsearchInstanceOfferingsRequest {
    ReservedElasticsearchInstanceOfferingId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeReservedElasticsearchInstanceOfferingsRequest: S.Schema<DescribeReservedElasticsearchInstanceOfferingsRequest>;
export type ReservedElasticsearchInstancePaymentOption = "ALL_UPFRONT" | "PARTIAL_UPFRONT" | "NO_UPFRONT" | (string & {});
export declare const ReservedElasticsearchInstancePaymentOption: any;
export interface RecurringCharge {
    RecurringChargeAmount?: number;
    RecurringChargeFrequency?: string;
}
export declare const RecurringCharge: S.Schema<RecurringCharge>;
export type RecurringChargeList = RecurringCharge[];
export declare const RecurringChargeList: any;
export interface ReservedElasticsearchInstanceOffering {
    ReservedElasticsearchInstanceOfferingId?: string;
    ElasticsearchInstanceType?: ESPartitionInstanceType;
    Duration?: number;
    FixedPrice?: number;
    UsagePrice?: number;
    CurrencyCode?: string;
    PaymentOption?: ReservedElasticsearchInstancePaymentOption;
    RecurringCharges?: RecurringCharge[];
}
export declare const ReservedElasticsearchInstanceOffering: S.Schema<ReservedElasticsearchInstanceOffering>;
export type ReservedElasticsearchInstanceOfferingList = ReservedElasticsearchInstanceOffering[];
export declare const ReservedElasticsearchInstanceOfferingList: any;
export interface DescribeReservedElasticsearchInstanceOfferingsResponse {
    NextToken?: string;
    ReservedElasticsearchInstanceOfferings?: ReservedElasticsearchInstanceOffering[];
}
export declare const DescribeReservedElasticsearchInstanceOfferingsResponse: S.Schema<DescribeReservedElasticsearchInstanceOfferingsResponse>;
export interface DescribeReservedElasticsearchInstancesRequest {
    ReservedElasticsearchInstanceId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeReservedElasticsearchInstancesRequest: S.Schema<DescribeReservedElasticsearchInstancesRequest>;
export type ReservationToken = string;
export interface ReservedElasticsearchInstance {
    ReservationName?: string;
    ReservedElasticsearchInstanceId?: string;
    ReservedElasticsearchInstanceOfferingId?: string;
    ElasticsearchInstanceType?: ESPartitionInstanceType;
    StartTime?: Date;
    Duration?: number;
    FixedPrice?: number;
    UsagePrice?: number;
    CurrencyCode?: string;
    ElasticsearchInstanceCount?: number;
    State?: string;
    PaymentOption?: ReservedElasticsearchInstancePaymentOption;
    RecurringCharges?: RecurringCharge[];
}
export declare const ReservedElasticsearchInstance: S.Schema<ReservedElasticsearchInstance>;
export type ReservedElasticsearchInstanceList = ReservedElasticsearchInstance[];
export declare const ReservedElasticsearchInstanceList: any;
export interface DescribeReservedElasticsearchInstancesResponse {
    NextToken?: string;
    ReservedElasticsearchInstances?: ReservedElasticsearchInstance[];
}
export declare const DescribeReservedElasticsearchInstancesResponse: S.Schema<DescribeReservedElasticsearchInstancesResponse>;
export type VpcEndpointIdList = string[];
export declare const VpcEndpointIdList: any;
export interface DescribeVpcEndpointsRequest {
    VpcEndpointIds: string[];
}
export declare const DescribeVpcEndpointsRequest: S.Schema<DescribeVpcEndpointsRequest>;
export type VpcEndpoints = VpcEndpoint[];
export declare const VpcEndpoints: any;
export type VpcEndpointErrorCode = "ENDPOINT_NOT_FOUND" | "SERVER_ERROR" | (string & {});
export declare const VpcEndpointErrorCode: any;
export interface VpcEndpointError {
    VpcEndpointId?: string;
    ErrorCode?: VpcEndpointErrorCode;
    ErrorMessage?: string;
}
export declare const VpcEndpointError: S.Schema<VpcEndpointError>;
export type VpcEndpointErrorList = VpcEndpointError[];
export declare const VpcEndpointErrorList: any;
export interface DescribeVpcEndpointsResponse {
    VpcEndpoints: VpcEndpoint[];
    VpcEndpointErrors: VpcEndpointError[];
}
export declare const DescribeVpcEndpointsResponse: S.Schema<DescribeVpcEndpointsResponse>;
export interface DissociatePackageRequest {
    PackageID: string;
    DomainName: string;
}
export declare const DissociatePackageRequest: S.Schema<DissociatePackageRequest>;
export interface DissociatePackageResponse {
    DomainPackageDetails?: DomainPackageDetails;
}
export declare const DissociatePackageResponse: S.Schema<DissociatePackageResponse>;
export interface GetCompatibleElasticsearchVersionsRequest {
    DomainName?: string;
}
export declare const GetCompatibleElasticsearchVersionsRequest: S.Schema<GetCompatibleElasticsearchVersionsRequest>;
export type ElasticsearchVersionList = string[];
export declare const ElasticsearchVersionList: any;
export interface CompatibleVersionsMap {
    SourceVersion?: string;
    TargetVersions?: string[];
}
export declare const CompatibleVersionsMap: S.Schema<CompatibleVersionsMap>;
export type CompatibleElasticsearchVersionsList = CompatibleVersionsMap[];
export declare const CompatibleElasticsearchVersionsList: any;
export interface GetCompatibleElasticsearchVersionsResponse {
    CompatibleElasticsearchVersions?: CompatibleVersionsMap[];
}
export declare const GetCompatibleElasticsearchVersionsResponse: S.Schema<GetCompatibleElasticsearchVersionsResponse>;
export interface GetPackageVersionHistoryRequest {
    PackageID: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const GetPackageVersionHistoryRequest: S.Schema<GetPackageVersionHistoryRequest>;
export type CommitMessage = string;
export interface PackageVersionHistory {
    PackageVersion?: string;
    CommitMessage?: string;
    CreatedAt?: Date;
}
export declare const PackageVersionHistory: S.Schema<PackageVersionHistory>;
export type PackageVersionHistoryList = PackageVersionHistory[];
export declare const PackageVersionHistoryList: any;
export interface GetPackageVersionHistoryResponse {
    PackageID?: string;
    PackageVersionHistoryList?: PackageVersionHistory[];
    NextToken?: string;
}
export declare const GetPackageVersionHistoryResponse: S.Schema<GetPackageVersionHistoryResponse>;
export interface GetUpgradeHistoryRequest {
    DomainName: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const GetUpgradeHistoryRequest: S.Schema<GetUpgradeHistoryRequest>;
export type UpgradeName = string;
export type StartTimestamp = Date;
export type UpgradeStatus = "IN_PROGRESS" | "SUCCEEDED" | "SUCCEEDED_WITH_ISSUES" | "FAILED" | (string & {});
export declare const UpgradeStatus: any;
export type UpgradeStep = "PRE_UPGRADE_CHECK" | "SNAPSHOT" | "UPGRADE" | (string & {});
export declare const UpgradeStep: any;
export type Issue = string;
export type Issues = string[];
export declare const Issues: any;
export interface UpgradeStepItem {
    UpgradeStep?: UpgradeStep;
    UpgradeStepStatus?: UpgradeStatus;
    Issues?: string[];
    ProgressPercent?: number;
}
export declare const UpgradeStepItem: S.Schema<UpgradeStepItem>;
export type UpgradeStepsList = UpgradeStepItem[];
export declare const UpgradeStepsList: any;
export interface UpgradeHistory {
    UpgradeName?: string;
    StartTimestamp?: Date;
    UpgradeStatus?: UpgradeStatus;
    StepsList?: UpgradeStepItem[];
}
export declare const UpgradeHistory: S.Schema<UpgradeHistory>;
export type UpgradeHistoryList = UpgradeHistory[];
export declare const UpgradeHistoryList: any;
export interface GetUpgradeHistoryResponse {
    UpgradeHistories?: UpgradeHistory[];
    NextToken?: string;
}
export declare const GetUpgradeHistoryResponse: S.Schema<GetUpgradeHistoryResponse>;
export interface GetUpgradeStatusRequest {
    DomainName: string;
}
export declare const GetUpgradeStatusRequest: S.Schema<GetUpgradeStatusRequest>;
export interface GetUpgradeStatusResponse {
    UpgradeStep?: UpgradeStep;
    StepStatus?: UpgradeStatus;
    UpgradeName?: string;
}
export declare const GetUpgradeStatusResponse: S.Schema<GetUpgradeStatusResponse>;
export type EngineType = "OpenSearch" | "Elasticsearch" | (string & {});
export declare const EngineType: any;
export interface ListDomainNamesRequest {
    EngineType?: EngineType;
}
export declare const ListDomainNamesRequest: S.Schema<ListDomainNamesRequest>;
export interface DomainInfo {
    DomainName?: string;
    EngineType?: EngineType;
}
export declare const DomainInfo: S.Schema<DomainInfo>;
export type DomainInfoList = DomainInfo[];
export declare const DomainInfoList: any;
export interface ListDomainNamesResponse {
    DomainNames?: DomainInfo[];
}
export declare const ListDomainNamesResponse: S.Schema<ListDomainNamesResponse>;
export interface ListDomainsForPackageRequest {
    PackageID: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDomainsForPackageRequest: S.Schema<ListDomainsForPackageRequest>;
export type DomainPackageDetailsList = DomainPackageDetails[];
export declare const DomainPackageDetailsList: any;
export interface ListDomainsForPackageResponse {
    DomainPackageDetailsList?: DomainPackageDetails[];
    NextToken?: string;
}
export declare const ListDomainsForPackageResponse: S.Schema<ListDomainsForPackageResponse>;
export interface ListElasticsearchInstanceTypesRequest {
    ElasticsearchVersion: string;
    DomainName?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListElasticsearchInstanceTypesRequest: S.Schema<ListElasticsearchInstanceTypesRequest>;
export type ElasticsearchInstanceTypeList = ESPartitionInstanceType[];
export declare const ElasticsearchInstanceTypeList: any;
export interface ListElasticsearchInstanceTypesResponse {
    ElasticsearchInstanceTypes?: ESPartitionInstanceType[];
    NextToken?: string;
}
export declare const ListElasticsearchInstanceTypesResponse: S.Schema<ListElasticsearchInstanceTypesResponse>;
export interface ListElasticsearchVersionsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListElasticsearchVersionsRequest: S.Schema<ListElasticsearchVersionsRequest>;
export interface ListElasticsearchVersionsResponse {
    ElasticsearchVersions?: string[];
    NextToken?: string;
}
export declare const ListElasticsearchVersionsResponse: S.Schema<ListElasticsearchVersionsResponse>;
export interface ListPackagesForDomainRequest {
    DomainName: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListPackagesForDomainRequest: S.Schema<ListPackagesForDomainRequest>;
export interface ListPackagesForDomainResponse {
    DomainPackageDetailsList?: DomainPackageDetails[];
    NextToken?: string;
}
export declare const ListPackagesForDomainResponse: S.Schema<ListPackagesForDomainResponse>;
export interface ListTagsRequest {
    ARN: string;
}
export declare const ListTagsRequest: S.Schema<ListTagsRequest>;
export interface ListTagsResponse {
    TagList?: Tag[];
}
export declare const ListTagsResponse: S.Schema<ListTagsResponse>;
export interface ListVpcEndpointAccessRequest {
    DomainName: string;
    NextToken?: string;
}
export declare const ListVpcEndpointAccessRequest: S.Schema<ListVpcEndpointAccessRequest>;
export type AuthorizedPrincipalList = AuthorizedPrincipal[];
export declare const AuthorizedPrincipalList: any;
export interface ListVpcEndpointAccessResponse {
    AuthorizedPrincipalList: AuthorizedPrincipal[];
    NextToken: string;
}
export declare const ListVpcEndpointAccessResponse: S.Schema<ListVpcEndpointAccessResponse>;
export interface ListVpcEndpointsRequest {
    NextToken?: string;
}
export declare const ListVpcEndpointsRequest: S.Schema<ListVpcEndpointsRequest>;
export type VpcEndpointSummaryList = VpcEndpointSummary[];
export declare const VpcEndpointSummaryList: any;
export interface ListVpcEndpointsResponse {
    VpcEndpointSummaryList: VpcEndpointSummary[];
    NextToken: string;
}
export declare const ListVpcEndpointsResponse: S.Schema<ListVpcEndpointsResponse>;
export interface ListVpcEndpointsForDomainRequest {
    DomainName: string;
    NextToken?: string;
}
export declare const ListVpcEndpointsForDomainRequest: S.Schema<ListVpcEndpointsForDomainRequest>;
export interface ListVpcEndpointsForDomainResponse {
    VpcEndpointSummaryList: VpcEndpointSummary[];
    NextToken: string;
}
export declare const ListVpcEndpointsForDomainResponse: S.Schema<ListVpcEndpointsForDomainResponse>;
export type InstanceCount = number;
export interface PurchaseReservedElasticsearchInstanceOfferingRequest {
    ReservedElasticsearchInstanceOfferingId: string;
    ReservationName: string;
    InstanceCount?: number;
}
export declare const PurchaseReservedElasticsearchInstanceOfferingRequest: S.Schema<PurchaseReservedElasticsearchInstanceOfferingRequest>;
export interface PurchaseReservedElasticsearchInstanceOfferingResponse {
    ReservedElasticsearchInstanceId?: string;
    ReservationName?: string;
}
export declare const PurchaseReservedElasticsearchInstanceOfferingResponse: S.Schema<PurchaseReservedElasticsearchInstanceOfferingResponse>;
export interface RejectInboundCrossClusterSearchConnectionRequest {
    CrossClusterSearchConnectionId: string;
}
export declare const RejectInboundCrossClusterSearchConnectionRequest: S.Schema<RejectInboundCrossClusterSearchConnectionRequest>;
export interface RejectInboundCrossClusterSearchConnectionResponse {
    CrossClusterSearchConnection?: InboundCrossClusterSearchConnection;
}
export declare const RejectInboundCrossClusterSearchConnectionResponse: S.Schema<RejectInboundCrossClusterSearchConnectionResponse>;
export interface RemoveTagsRequest {
    ARN: string;
    TagKeys: string[];
}
export declare const RemoveTagsRequest: S.Schema<RemoveTagsRequest>;
export interface RemoveTagsResponse {
}
export declare const RemoveTagsResponse: S.Schema<RemoveTagsResponse>;
export interface RevokeVpcEndpointAccessRequest {
    DomainName: string;
    Account: string;
}
export declare const RevokeVpcEndpointAccessRequest: S.Schema<RevokeVpcEndpointAccessRequest>;
export interface RevokeVpcEndpointAccessResponse {
}
export declare const RevokeVpcEndpointAccessResponse: S.Schema<RevokeVpcEndpointAccessResponse>;
export interface StartElasticsearchServiceSoftwareUpdateRequest {
    DomainName: string;
}
export declare const StartElasticsearchServiceSoftwareUpdateRequest: S.Schema<StartElasticsearchServiceSoftwareUpdateRequest>;
export interface StartElasticsearchServiceSoftwareUpdateResponse {
    ServiceSoftwareOptions?: ServiceSoftwareOptions;
}
export declare const StartElasticsearchServiceSoftwareUpdateResponse: S.Schema<StartElasticsearchServiceSoftwareUpdateResponse>;
export interface UpdateElasticsearchDomainConfigRequest {
    DomainName: string;
    ElasticsearchClusterConfig?: ElasticsearchClusterConfig;
    EBSOptions?: EBSOptions;
    SnapshotOptions?: SnapshotOptions;
    VPCOptions?: VPCOptions;
    CognitoOptions?: CognitoOptions;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    };
    AccessPolicies?: string;
    LogPublishingOptions?: {
        [key: string]: LogPublishingOption | undefined;
    };
    DomainEndpointOptions?: DomainEndpointOptions;
    AdvancedSecurityOptions?: AdvancedSecurityOptionsInput;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptions;
    EncryptionAtRestOptions?: EncryptionAtRestOptions;
    AutoTuneOptions?: AutoTuneOptions;
    DryRun?: boolean;
    DeploymentStrategyOptions?: DeploymentStrategyOptions;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseRequestOptions;
    UseCase?: DomainUseCase;
    EngineMode?: DomainEngineMode;
}
export declare const UpdateElasticsearchDomainConfigRequest: S.Schema<UpdateElasticsearchDomainConfigRequest>;
export type DeploymentType = string;
export interface DryRunResults {
    DeploymentType?: string;
    Message?: string;
}
export declare const DryRunResults: S.Schema<DryRunResults>;
export interface UpdateElasticsearchDomainConfigResponse {
    DomainConfig: ElasticsearchDomainConfig;
    DryRunResults?: DryRunResults;
}
export declare const UpdateElasticsearchDomainConfigResponse: S.Schema<UpdateElasticsearchDomainConfigResponse>;
export interface UpdatePackageRequest {
    PackageID: string;
    PackageSource: PackageSource;
    PackageDescription?: string;
    CommitMessage?: string;
}
export declare const UpdatePackageRequest: S.Schema<UpdatePackageRequest>;
export interface UpdatePackageResponse {
    PackageDetails?: PackageDetails;
}
export declare const UpdatePackageResponse: S.Schema<UpdatePackageResponse>;
export interface UpdateVpcEndpointRequest {
    VpcEndpointId: string;
    VpcOptions: VPCOptions;
}
export declare const UpdateVpcEndpointRequest: S.Schema<UpdateVpcEndpointRequest>;
export interface UpdateVpcEndpointResponse {
    VpcEndpoint: VpcEndpoint;
}
export declare const UpdateVpcEndpointResponse: S.Schema<UpdateVpcEndpointResponse>;
export interface UpgradeElasticsearchDomainRequest {
    DomainName: string;
    TargetVersion: string;
    PerformCheckOnly?: boolean;
}
export declare const UpgradeElasticsearchDomainRequest: S.Schema<UpgradeElasticsearchDomainRequest>;
export interface UpgradeElasticsearchDomainResponse {
    DomainName?: string;
    TargetVersion?: string;
    PerformCheckOnly?: boolean;
    ChangeProgressDetails?: ChangeProgressDetails;
}
export declare const UpgradeElasticsearchDomainResponse: S.Schema<UpgradeElasticsearchDomainResponse>;
export type AcceptInboundCrossClusterSearchConnectionError = DisabledOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the destination domain owner to accept an inbound cross-cluster search connection request.
 */
export declare const acceptInboundCrossClusterSearchConnection: API.OperationMethod<AcceptInboundCrossClusterSearchConnectionRequest, AcceptInboundCrossClusterSearchConnectionResponse, AcceptInboundCrossClusterSearchConnectionError, Credentials | HttpClient.HttpClient>;
export type AddTagsError = BaseException | InternalException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Attaches tags to an existing Elasticsearch domain. Tags are a set of case-sensitive key value pairs. An Elasticsearch domain may have up to 10 tags. See
 * Tagging Amazon Elasticsearch Service Domains for more information.
 */
export declare const addTags: API.OperationMethod<AddTagsRequest, AddTagsResponse, AddTagsError, Credentials | HttpClient.HttpClient>;
export type AssociatePackageError = AccessDeniedException | BaseException | ConflictException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Associates a package with an Amazon ES domain.
 */
export declare const associatePackage: API.OperationMethod<AssociatePackageRequest, AssociatePackageResponse, AssociatePackageError, Credentials | HttpClient.HttpClient>;
export type AuthorizeVpcEndpointAccessError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Provides access to an Amazon OpenSearch Service domain through the use of an interface VPC endpoint.
 */
export declare const authorizeVpcEndpointAccess: API.OperationMethod<AuthorizeVpcEndpointAccessRequest, AuthorizeVpcEndpointAccessResponse, AuthorizeVpcEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type CancelDomainConfigChangeError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Cancels a pending configuration change on an Amazon OpenSearch Service domain.
 */
export declare const cancelDomainConfigChange: API.OperationMethod<CancelDomainConfigChangeRequest, CancelDomainConfigChangeResponse, CancelDomainConfigChangeError, Credentials | HttpClient.HttpClient>;
export type CancelElasticsearchServiceSoftwareUpdateError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Cancels a scheduled service software update for an Amazon ES domain. You can only perform this operation before the `AutomatedUpdateDate` and when the `UpdateStatus` is in the `PENDING_UPDATE` state.
 */
export declare const cancelElasticsearchServiceSoftwareUpdate: API.OperationMethod<CancelElasticsearchServiceSoftwareUpdateRequest, CancelElasticsearchServiceSoftwareUpdateResponse, CancelElasticsearchServiceSoftwareUpdateError, Credentials | HttpClient.HttpClient>;
export type CreateElasticsearchDomainError = BaseException | DisabledOperationException | InternalException | InvalidTypeException | LimitExceededException | ResourceAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates a new Elasticsearch domain. For more information,
 * see Creating Elasticsearch Domains in the *Amazon Elasticsearch Service Developer Guide*.
 */
export declare const createElasticsearchDomain: API.OperationMethod<CreateElasticsearchDomainRequest, CreateElasticsearchDomainResponse, CreateElasticsearchDomainError, Credentials | HttpClient.HttpClient>;
export type CreateOutboundCrossClusterSearchConnectionError = DisabledOperationException | InternalException | LimitExceededException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates a new cross-cluster search connection from a source domain to a destination domain.
 */
export declare const createOutboundCrossClusterSearchConnection: API.OperationMethod<CreateOutboundCrossClusterSearchConnectionRequest, CreateOutboundCrossClusterSearchConnectionResponse, CreateOutboundCrossClusterSearchConnectionError, Credentials | HttpClient.HttpClient>;
export type CreatePackageError = AccessDeniedException | BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Create a package for use with Amazon ES domains.
 */
export declare const createPackage: API.OperationMethod<CreatePackageRequest, CreatePackageResponse, CreatePackageError, Credentials | HttpClient.HttpClient>;
export type CreateVpcEndpointError = BaseException | ConflictException | DisabledOperationException | InternalException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Creates an Amazon OpenSearch Service-managed VPC endpoint.
 */
export declare const createVpcEndpoint: API.OperationMethod<CreateVpcEndpointRequest, CreateVpcEndpointResponse, CreateVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteElasticsearchDomainError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Permanently deletes the specified Elasticsearch domain and all of its data. Once a domain is deleted, it cannot be recovered.
 */
export declare const deleteElasticsearchDomain: API.OperationMethod<DeleteElasticsearchDomainRequest, DeleteElasticsearchDomainResponse, DeleteElasticsearchDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteElasticsearchServiceRoleError = BaseException | InternalException | ValidationException | CommonErrors;
/**
 * Deletes the service-linked role that Elasticsearch Service uses to manage and maintain VPC domains. Role deletion will fail if any existing VPC domains use the role. You must delete any such Elasticsearch domains before deleting the role. See Deleting Elasticsearch Service Role in *VPC Endpoints for Amazon Elasticsearch Service Domains*.
 */
export declare const deleteElasticsearchServiceRole: API.OperationMethod<DeleteElasticsearchServiceRoleRequest, DeleteElasticsearchServiceRoleResponse, DeleteElasticsearchServiceRoleError, Credentials | HttpClient.HttpClient>;
export type DeleteInboundCrossClusterSearchConnectionError = DisabledOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the destination domain owner to delete an existing inbound cross-cluster search connection.
 */
export declare const deleteInboundCrossClusterSearchConnection: API.OperationMethod<DeleteInboundCrossClusterSearchConnectionRequest, DeleteInboundCrossClusterSearchConnectionResponse, DeleteInboundCrossClusterSearchConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteOutboundCrossClusterSearchConnectionError = DisabledOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the source domain owner to delete an existing outbound cross-cluster search connection.
 */
export declare const deleteOutboundCrossClusterSearchConnection: API.OperationMethod<DeleteOutboundCrossClusterSearchConnectionRequest, DeleteOutboundCrossClusterSearchConnectionResponse, DeleteOutboundCrossClusterSearchConnectionError, Credentials | HttpClient.HttpClient>;
export type DeletePackageError = AccessDeniedException | BaseException | ConflictException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete the package.
 */
export declare const deletePackage: API.OperationMethod<DeletePackageRequest, DeletePackageResponse, DeletePackageError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcEndpointError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Amazon OpenSearch Service-managed interface VPC endpoint.
 */
export declare const deleteVpcEndpoint: API.OperationMethod<DeleteVpcEndpointRequest, DeleteVpcEndpointResponse, DeleteVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainAutoTunesError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Provides scheduled Auto-Tune action details for the Elasticsearch domain, such as Auto-Tune action type, description, severity, and scheduled date.
 */
export declare const describeDomainAutoTunes: API.PaginatedOperationMethod<DescribeDomainAutoTunesRequest, DescribeDomainAutoTunesResponse, DescribeDomainAutoTunesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeDomainChangeProgressError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about the current blue/green deployment happening on a domain, including
 * a change ID, status, and progress stages.
 */
export declare const describeDomainChangeProgress: API.OperationMethod<DescribeDomainChangeProgressRequest, DescribeDomainChangeProgressResponse, DescribeDomainChangeProgressError, Credentials | HttpClient.HttpClient>;
export type DescribeElasticsearchDomainError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns domain configuration information about the specified Elasticsearch domain, including the domain ID, domain endpoint, and domain ARN.
 */
export declare const describeElasticsearchDomain: API.OperationMethod<DescribeElasticsearchDomainRequest, DescribeElasticsearchDomainResponse, DescribeElasticsearchDomainError, Credentials | HttpClient.HttpClient>;
export type DescribeElasticsearchDomainConfigError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Provides cluster configuration information about the specified Elasticsearch domain, such as the state, creation date, update version, and update date for cluster options.
 */
export declare const describeElasticsearchDomainConfig: API.OperationMethod<DescribeElasticsearchDomainConfigRequest, DescribeElasticsearchDomainConfigResponse, DescribeElasticsearchDomainConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeElasticsearchDomainsError = BaseException | InternalException | ValidationException | CommonErrors;
/**
 * Returns domain configuration information about the specified Elasticsearch domains, including the domain ID, domain endpoint, and domain ARN.
 */
export declare const describeElasticsearchDomains: API.OperationMethod<DescribeElasticsearchDomainsRequest, DescribeElasticsearchDomainsResponse, DescribeElasticsearchDomainsError, Credentials | HttpClient.HttpClient>;
export type DescribeElasticsearchInstanceTypeLimitsError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describe Elasticsearch Limits for a given InstanceType and ElasticsearchVersion.
 * When modifying existing Domain, specify the
 *
 * DomainName
 *
 * to know what Limits are supported for modifying.
 */
export declare const describeElasticsearchInstanceTypeLimits: API.OperationMethod<DescribeElasticsearchInstanceTypeLimitsRequest, DescribeElasticsearchInstanceTypeLimitsResponse, DescribeElasticsearchInstanceTypeLimitsError, Credentials | HttpClient.HttpClient>;
export type DescribeInboundCrossClusterSearchConnectionsError = DisabledOperationException | InvalidPaginationTokenException | CommonErrors;
/**
 * Lists all the inbound cross-cluster search connections for a destination domain.
 */
export declare const describeInboundCrossClusterSearchConnections: API.PaginatedOperationMethod<DescribeInboundCrossClusterSearchConnectionsRequest, DescribeInboundCrossClusterSearchConnectionsResponse, DescribeInboundCrossClusterSearchConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeOutboundCrossClusterSearchConnectionsError = DisabledOperationException | InvalidPaginationTokenException | CommonErrors;
/**
 * Lists all the outbound cross-cluster search connections for a source domain.
 */
export declare const describeOutboundCrossClusterSearchConnections: API.PaginatedOperationMethod<DescribeOutboundCrossClusterSearchConnectionsRequest, DescribeOutboundCrossClusterSearchConnectionsResponse, DescribeOutboundCrossClusterSearchConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribePackagesError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes all packages available to Amazon ES. Includes options for filtering, limiting the number of results, and pagination.
 */
export declare const describePackages: API.PaginatedOperationMethod<DescribePackagesRequest, DescribePackagesResponse, DescribePackagesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReservedElasticsearchInstanceOfferingsError = DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists available reserved Elasticsearch instance offerings.
 */
export declare const describeReservedElasticsearchInstanceOfferings: API.PaginatedOperationMethod<DescribeReservedElasticsearchInstanceOfferingsRequest, DescribeReservedElasticsearchInstanceOfferingsResponse, DescribeReservedElasticsearchInstanceOfferingsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReservedElasticsearchInstancesError = DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about reserved Elasticsearch instances for this account.
 */
export declare const describeReservedElasticsearchInstances: API.PaginatedOperationMethod<DescribeReservedElasticsearchInstancesRequest, DescribeReservedElasticsearchInstancesResponse, DescribeReservedElasticsearchInstancesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeVpcEndpointsError = BaseException | DisabledOperationException | InternalException | ValidationException | CommonErrors;
/**
 * Describes one or more Amazon OpenSearch Service-managed VPC endpoints.
 */
export declare const describeVpcEndpoints: API.OperationMethod<DescribeVpcEndpointsRequest, DescribeVpcEndpointsResponse, DescribeVpcEndpointsError, Credentials | HttpClient.HttpClient>;
export type DissociatePackageError = AccessDeniedException | BaseException | ConflictException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Dissociates a package from the Amazon ES domain.
 */
export declare const dissociatePackage: API.OperationMethod<DissociatePackageRequest, DissociatePackageResponse, DissociatePackageError, Credentials | HttpClient.HttpClient>;
export type GetCompatibleElasticsearchVersionsError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of upgrade compatible Elastisearch versions.
 * You can optionally pass a
 *
 * DomainName
 *
 * to get all upgrade compatible Elasticsearch versions for that specific domain.
 */
export declare const getCompatibleElasticsearchVersions: API.OperationMethod<GetCompatibleElasticsearchVersionsRequest, GetCompatibleElasticsearchVersionsResponse, GetCompatibleElasticsearchVersionsError, Credentials | HttpClient.HttpClient>;
export type GetPackageVersionHistoryError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of versions of the package, along with their creation time and commit message.
 */
export declare const getPackageVersionHistory: API.PaginatedOperationMethod<GetPackageVersionHistoryRequest, GetPackageVersionHistoryResponse, GetPackageVersionHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetUpgradeHistoryError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the complete history of the last 10 upgrades that were performed on the domain.
 */
export declare const getUpgradeHistory: API.PaginatedOperationMethod<GetUpgradeHistoryRequest, GetUpgradeHistoryResponse, GetUpgradeHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetUpgradeStatusError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the latest status of the last upgrade or upgrade eligibility check that was performed on the domain.
 */
export declare const getUpgradeStatus: API.OperationMethod<GetUpgradeStatusRequest, GetUpgradeStatusResponse, GetUpgradeStatusError, Credentials | HttpClient.HttpClient>;
export type ListDomainNamesError = BaseException | ValidationException | CommonErrors;
/**
 * Returns the name of all Elasticsearch domains owned by the current user's account.
 */
export declare const listDomainNames: API.OperationMethod<ListDomainNamesRequest, ListDomainNamesResponse, ListDomainNamesError, Credentials | HttpClient.HttpClient>;
export type ListDomainsForPackageError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all Amazon ES domains associated with the package.
 */
export declare const listDomainsForPackage: API.PaginatedOperationMethod<ListDomainsForPackageRequest, ListDomainsForPackageResponse, ListDomainsForPackageError, Credentials | HttpClient.HttpClient, unknown>;
export type ListElasticsearchInstanceTypesError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List all Elasticsearch instance types that are supported for given ElasticsearchVersion
 */
export declare const listElasticsearchInstanceTypes: API.PaginatedOperationMethod<ListElasticsearchInstanceTypesRequest, ListElasticsearchInstanceTypesResponse, ListElasticsearchInstanceTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListElasticsearchVersionsError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List all supported Elasticsearch versions
 */
export declare const listElasticsearchVersions: API.PaginatedOperationMethod<ListElasticsearchVersionsRequest, ListElasticsearchVersionsResponse, ListElasticsearchVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPackagesForDomainError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all packages associated with the Amazon ES domain.
 */
export declare const listPackagesForDomain: API.PaginatedOperationMethod<ListPackagesForDomainRequest, ListPackagesForDomainResponse, ListPackagesForDomainError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns all tags for the given Elasticsearch domain.
 */
export declare const listTags: API.OperationMethod<ListTagsRequest, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient>;
export type ListVpcEndpointAccessError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about each principal that is allowed to access a
 * given Amazon OpenSearch Service domain through the use of an interface VPC endpoint.
 */
export declare const listVpcEndpointAccess: API.OperationMethod<ListVpcEndpointAccessRequest, ListVpcEndpointAccessResponse, ListVpcEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type ListVpcEndpointsError = BaseException | DisabledOperationException | InternalException | CommonErrors;
/**
 * Retrieves all Amazon OpenSearch Service-managed VPC endpoints in the current account and Region.
 */
export declare const listVpcEndpoints: API.OperationMethod<ListVpcEndpointsRequest, ListVpcEndpointsResponse, ListVpcEndpointsError, Credentials | HttpClient.HttpClient>;
export type ListVpcEndpointsForDomainError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves all Amazon OpenSearch Service-managed VPC endpoints associated with a particular domain.
 */
export declare const listVpcEndpointsForDomain: API.OperationMethod<ListVpcEndpointsForDomainRequest, ListVpcEndpointsForDomainResponse, ListVpcEndpointsForDomainError, Credentials | HttpClient.HttpClient>;
export type PurchaseReservedElasticsearchInstanceOfferingError = DisabledOperationException | InternalException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Allows you to purchase reserved Elasticsearch instances.
 */
export declare const purchaseReservedElasticsearchInstanceOffering: API.OperationMethod<PurchaseReservedElasticsearchInstanceOfferingRequest, PurchaseReservedElasticsearchInstanceOfferingResponse, PurchaseReservedElasticsearchInstanceOfferingError, Credentials | HttpClient.HttpClient>;
export type RejectInboundCrossClusterSearchConnectionError = DisabledOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the destination domain owner to reject an inbound cross-cluster search connection request.
 */
export declare const rejectInboundCrossClusterSearchConnection: API.OperationMethod<RejectInboundCrossClusterSearchConnectionRequest, RejectInboundCrossClusterSearchConnectionResponse, RejectInboundCrossClusterSearchConnectionError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsError = BaseException | InternalException | ValidationException | CommonErrors;
/**
 * Removes the specified set of tags from the specified Elasticsearch domain.
 */
export declare const removeTags: API.OperationMethod<RemoveTagsRequest, RemoveTagsResponse, RemoveTagsError, Credentials | HttpClient.HttpClient>;
export type RevokeVpcEndpointAccessError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Revokes access to an Amazon OpenSearch Service domain that was provided through an interface
 * VPC endpoint.
 */
export declare const revokeVpcEndpointAccess: API.OperationMethod<RevokeVpcEndpointAccessRequest, RevokeVpcEndpointAccessResponse, RevokeVpcEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type StartElasticsearchServiceSoftwareUpdateError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Schedules a service software update for an Amazon ES domain.
 */
export declare const startElasticsearchServiceSoftwareUpdate: API.OperationMethod<StartElasticsearchServiceSoftwareUpdateRequest, StartElasticsearchServiceSoftwareUpdateResponse, StartElasticsearchServiceSoftwareUpdateError, Credentials | HttpClient.HttpClient>;
export type UpdateElasticsearchDomainConfigError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Modifies the cluster configuration of the specified Elasticsearch domain, setting as setting the instance type and the number of instances.
 */
export declare const updateElasticsearchDomainConfig: API.OperationMethod<UpdateElasticsearchDomainConfigRequest, UpdateElasticsearchDomainConfigResponse, UpdateElasticsearchDomainConfigError, Credentials | HttpClient.HttpClient>;
export type UpdatePackageError = AccessDeniedException | BaseException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a package for use with Amazon ES domains.
 */
export declare const updatePackage: API.OperationMethod<UpdatePackageRequest, UpdatePackageResponse, UpdatePackageError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcEndpointError = BaseException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Modifies an Amazon OpenSearch Service-managed interface VPC endpoint.
 */
export declare const updateVpcEndpoint: API.OperationMethod<UpdateVpcEndpointRequest, UpdateVpcEndpointResponse, UpdateVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type UpgradeElasticsearchDomainError = BaseException | DisabledOperationException | InternalException | ResourceAlreadyExistsException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Allows you to either upgrade your domain or perform an Upgrade eligibility check to a compatible Elasticsearch version.
 */
export declare const upgradeElasticsearchDomain: API.OperationMethod<UpgradeElasticsearchDomainRequest, UpgradeElasticsearchDomainResponse, UpgradeElasticsearchDomainError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=elasticsearch-service.d.ts.map