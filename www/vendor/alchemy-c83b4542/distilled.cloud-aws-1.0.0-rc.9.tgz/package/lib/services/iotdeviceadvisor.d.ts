import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SuiteDefinitionName = string;
export type AmazonResourceName = string;
export interface DeviceUnderTest {
    thingArn?: string;
    certificateArn?: string;
    deviceRoleArn?: string;
}
export declare const DeviceUnderTest: S.Schema<DeviceUnderTest>;
export type DeviceUnderTestList = DeviceUnderTest[];
export declare const DeviceUnderTestList: any;
export type IntendedForQualificationBoolean = boolean;
export type IsLongDurationTestBoolean = boolean;
export type RootGroup = string;
export type Protocol = "MqttV3_1_1" | "MqttV5" | "MqttV3_1_1_OverWebSocket" | "MqttV5_OverWebSocket" | (string & {});
export declare const Protocol: any;
export interface SuiteDefinitionConfiguration {
    suiteDefinitionName?: string;
    devices?: DeviceUnderTest[];
    intendedForQualification?: boolean;
    isLongDurationTest?: boolean;
    rootGroup?: string;
    devicePermissionRoleArn?: string;
    protocol?: Protocol;
}
export declare const SuiteDefinitionConfiguration: S.Schema<SuiteDefinitionConfiguration>;
export type String128 = string;
export type String256 = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type ClientToken = string;
export interface CreateSuiteDefinitionRequest {
    suiteDefinitionConfiguration?: SuiteDefinitionConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const CreateSuiteDefinitionRequest: S.Schema<CreateSuiteDefinitionRequest>;
export type UUID = string;
export interface CreateSuiteDefinitionResponse {
    suiteDefinitionId?: string;
    suiteDefinitionArn?: string;
    suiteDefinitionName?: string;
    createdAt?: Date;
}
export declare const CreateSuiteDefinitionResponse: S.Schema<CreateSuiteDefinitionResponse>;
export interface DeleteSuiteDefinitionRequest {
    suiteDefinitionId: string;
}
export declare const DeleteSuiteDefinitionRequest: S.Schema<DeleteSuiteDefinitionRequest>;
export interface DeleteSuiteDefinitionResponse {
}
export declare const DeleteSuiteDefinitionResponse: S.Schema<DeleteSuiteDefinitionResponse>;
export type AuthenticationMethod = "X509ClientCertificate" | "SignatureVersion4" | (string & {});
export declare const AuthenticationMethod: any;
export interface GetEndpointRequest {
    thingArn?: string;
    certificateArn?: string;
    deviceRoleArn?: string;
    authenticationMethod?: AuthenticationMethod;
}
export declare const GetEndpointRequest: S.Schema<GetEndpointRequest>;
export type Endpoint = string;
export interface GetEndpointResponse {
    endpoint?: string;
}
export declare const GetEndpointResponse: S.Schema<GetEndpointResponse>;
export type SuiteDefinitionVersion = string;
export interface GetSuiteDefinitionRequest {
    suiteDefinitionId: string;
    suiteDefinitionVersion?: string;
}
export declare const GetSuiteDefinitionRequest: S.Schema<GetSuiteDefinitionRequest>;
export interface GetSuiteDefinitionResponse {
    suiteDefinitionId?: string;
    suiteDefinitionArn?: string;
    suiteDefinitionVersion?: string;
    latestVersion?: string;
    suiteDefinitionConfiguration?: SuiteDefinitionConfiguration & {
        suiteDefinitionName: SuiteDefinitionName;
        rootGroup: RootGroup;
        devicePermissionRoleArn: AmazonResourceName;
    };
    createdAt?: Date;
    lastModifiedAt?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetSuiteDefinitionResponse: S.Schema<GetSuiteDefinitionResponse>;
export interface GetSuiteRunRequest {
    suiteDefinitionId: string;
    suiteRunId: string;
}
export declare const GetSuiteRunRequest: S.Schema<GetSuiteRunRequest>;
export type SelectedTestList = string[];
export declare const SelectedTestList: any;
export type ParallelRun = boolean;
export interface SuiteRunConfiguration {
    primaryDevice?: DeviceUnderTest;
    selectedTestList?: string[];
    parallelRun?: boolean;
}
export declare const SuiteRunConfiguration: S.Schema<SuiteRunConfiguration>;
export type GroupName = string;
export type TestCaseDefinitionName = string;
export type Status = "PASS" | "FAIL" | "CANCELED" | "PENDING" | "RUNNING" | "STOPPING" | "STOPPED" | "PASS_WITH_WARNINGS" | "ERROR" | (string & {});
export declare const Status: any;
export type LogUrl = string;
export type Warnings = string;
export type Failure = string;
export type TestCaseScenarioId = string;
export type TestCaseScenarioType = "Advanced" | "Basic" | (string & {});
export declare const TestCaseScenarioType: any;
export type TestCaseScenarioStatus = "PASS" | "FAIL" | "CANCELED" | "PENDING" | "RUNNING" | "STOPPING" | "STOPPED" | "PASS_WITH_WARNINGS" | "ERROR" | (string & {});
export declare const TestCaseScenarioStatus: any;
export type SystemMessage = string;
export interface TestCaseScenario {
    testCaseScenarioId?: string;
    testCaseScenarioType?: TestCaseScenarioType;
    status?: TestCaseScenarioStatus;
    failure?: string;
    systemMessage?: string;
}
export declare const TestCaseScenario: S.Schema<TestCaseScenario>;
export type TestCaseScenariosList = TestCaseScenario[];
export declare const TestCaseScenariosList: any;
export interface TestCaseRun {
    testCaseRunId?: string;
    testCaseDefinitionId?: string;
    testCaseDefinitionName?: string;
    status?: Status;
    startTime?: Date;
    endTime?: Date;
    logUrl?: string;
    warnings?: string;
    failure?: string;
    testScenarios?: TestCaseScenario[];
}
export declare const TestCaseRun: S.Schema<TestCaseRun>;
export type TestCaseRuns = TestCaseRun[];
export declare const TestCaseRuns: any;
export interface GroupResult {
    groupId?: string;
    groupName?: string;
    tests?: TestCaseRun[];
}
export declare const GroupResult: S.Schema<GroupResult>;
export type GroupResultList = GroupResult[];
export declare const GroupResultList: any;
export interface TestResult {
    groups?: GroupResult[];
}
export declare const TestResult: S.Schema<TestResult>;
export type SuiteRunStatus = "PASS" | "FAIL" | "CANCELED" | "PENDING" | "RUNNING" | "STOPPING" | "STOPPED" | "PASS_WITH_WARNINGS" | "ERROR" | (string & {});
export declare const SuiteRunStatus: any;
export type ErrorReason = string;
export interface GetSuiteRunResponse {
    suiteDefinitionId?: string;
    suiteDefinitionVersion?: string;
    suiteRunId?: string;
    suiteRunArn?: string;
    suiteRunConfiguration?: SuiteRunConfiguration & {
        primaryDevice: DeviceUnderTest;
    };
    testResult?: TestResult;
    startTime?: Date;
    endTime?: Date;
    status?: SuiteRunStatus;
    errorReason?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetSuiteRunResponse: S.Schema<GetSuiteRunResponse>;
export interface GetSuiteRunReportRequest {
    suiteDefinitionId: string;
    suiteRunId: string;
}
export declare const GetSuiteRunReportRequest: S.Schema<GetSuiteRunReportRequest>;
export type QualificationReportDownloadUrl = string;
export interface GetSuiteRunReportResponse {
    qualificationReportDownloadUrl?: string;
}
export declare const GetSuiteRunReportResponse: S.Schema<GetSuiteRunReportResponse>;
export type MaxResults = number;
export type Token = string;
export interface ListSuiteDefinitionsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSuiteDefinitionsRequest: S.Schema<ListSuiteDefinitionsRequest>;
export interface SuiteDefinitionInformation {
    suiteDefinitionId?: string;
    suiteDefinitionName?: string;
    defaultDevices?: DeviceUnderTest[];
    intendedForQualification?: boolean;
    isLongDurationTest?: boolean;
    protocol?: Protocol;
    createdAt?: Date;
}
export declare const SuiteDefinitionInformation: S.Schema<SuiteDefinitionInformation>;
export type SuiteDefinitionInformationList = SuiteDefinitionInformation[];
export declare const SuiteDefinitionInformationList: any;
export interface ListSuiteDefinitionsResponse {
    suiteDefinitionInformationList?: SuiteDefinitionInformation[];
    nextToken?: string;
}
export declare const ListSuiteDefinitionsResponse: S.Schema<ListSuiteDefinitionsResponse>;
export interface ListSuiteRunsRequest {
    suiteDefinitionId?: string;
    suiteDefinitionVersion?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSuiteRunsRequest: S.Schema<ListSuiteRunsRequest>;
export type SuiteRunResultCount = number;
export interface SuiteRunInformation {
    suiteDefinitionId?: string;
    suiteDefinitionVersion?: string;
    suiteDefinitionName?: string;
    suiteRunId?: string;
    createdAt?: Date;
    startedAt?: Date;
    endAt?: Date;
    status?: SuiteRunStatus;
    passed?: number;
    failed?: number;
}
export declare const SuiteRunInformation: S.Schema<SuiteRunInformation>;
export type SuiteRunsList = SuiteRunInformation[];
export declare const SuiteRunsList: any;
export interface ListSuiteRunsResponse {
    suiteRunsList?: SuiteRunInformation[];
    nextToken?: string;
}
export declare const ListSuiteRunsResponse: S.Schema<ListSuiteRunsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface StartSuiteRunRequest {
    suiteDefinitionId: string;
    suiteDefinitionVersion?: string;
    suiteRunConfiguration?: SuiteRunConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StartSuiteRunRequest: S.Schema<StartSuiteRunRequest>;
export interface StartSuiteRunResponse {
    suiteRunId?: string;
    suiteRunArn?: string;
    createdAt?: Date;
    endpoint?: string;
}
export declare const StartSuiteRunResponse: S.Schema<StartSuiteRunResponse>;
export interface StopSuiteRunRequest {
    suiteDefinitionId: string;
    suiteRunId: string;
}
export declare const StopSuiteRunRequest: S.Schema<StopSuiteRunRequest>;
export interface StopSuiteRunResponse {
}
export declare const StopSuiteRunResponse: S.Schema<StopSuiteRunResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys?: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateSuiteDefinitionRequest {
    suiteDefinitionId: string;
    suiteDefinitionConfiguration?: SuiteDefinitionConfiguration;
}
export declare const UpdateSuiteDefinitionRequest: S.Schema<UpdateSuiteDefinitionRequest>;
export interface UpdateSuiteDefinitionResponse {
    suiteDefinitionId?: string;
    suiteDefinitionArn?: string;
    suiteDefinitionName?: string;
    suiteDefinitionVersion?: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
}
export declare const UpdateSuiteDefinitionResponse: S.Schema<UpdateSuiteDefinitionResponse>;
export type Message = string;
export type CreateSuiteDefinitionError = InternalServerException | ValidationException | CommonErrors;
/**
 * Creates a Device Advisor test suite.
 *
 * Requires permission to access the CreateSuiteDefinition action.
 */
export declare const createSuiteDefinition: API.OperationMethod<CreateSuiteDefinitionRequest, CreateSuiteDefinitionResponse, CreateSuiteDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteSuiteDefinitionError = InternalServerException | ValidationException | CommonErrors;
/**
 * Deletes a Device Advisor test suite.
 *
 * Requires permission to access the DeleteSuiteDefinition action.
 */
export declare const deleteSuiteDefinition: API.OperationMethod<DeleteSuiteDefinitionRequest, DeleteSuiteDefinitionResponse, DeleteSuiteDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetEndpointError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about an Device Advisor endpoint.
 */
export declare const getEndpoint: API.OperationMethod<GetEndpointRequest, GetEndpointResponse, GetEndpointError, Credentials | HttpClient.HttpClient>;
export type GetSuiteDefinitionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about a Device Advisor test suite.
 *
 * Requires permission to access the GetSuiteDefinition action.
 */
export declare const getSuiteDefinition: API.OperationMethod<GetSuiteDefinitionRequest, GetSuiteDefinitionResponse, GetSuiteDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetSuiteRunError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about a Device Advisor test suite run.
 *
 * Requires permission to access the GetSuiteRun action.
 */
export declare const getSuiteRun: API.OperationMethod<GetSuiteRunRequest, GetSuiteRunResponse, GetSuiteRunError, Credentials | HttpClient.HttpClient>;
export type GetSuiteRunReportError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets a report download link for a successful Device Advisor qualifying test suite run.
 *
 * Requires permission to access the GetSuiteRunReport action.
 */
export declare const getSuiteRunReport: API.OperationMethod<GetSuiteRunReportRequest, GetSuiteRunReportResponse, GetSuiteRunReportError, Credentials | HttpClient.HttpClient>;
export type ListSuiteDefinitionsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the Device Advisor test suites you have created.
 *
 * Requires permission to access the ListSuiteDefinitions action.
 */
export declare const listSuiteDefinitions: API.PaginatedOperationMethod<ListSuiteDefinitionsRequest, ListSuiteDefinitionsResponse, ListSuiteDefinitionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSuiteRunsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists runs of the specified Device Advisor test suite. You can list all runs of the test
 * suite, or the runs of a specific version of the test suite.
 *
 * Requires permission to access the ListSuiteRuns action.
 */
export declare const listSuiteRuns: API.PaginatedOperationMethod<ListSuiteRunsRequest, ListSuiteRunsResponse, ListSuiteRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags attached to an IoT Device Advisor resource.
 *
 * Requires permission to access the ListTagsForResource action.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartSuiteRunError = ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Starts a Device Advisor test suite run.
 *
 * Requires permission to access the StartSuiteRun action.
 */
export declare const startSuiteRun: API.OperationMethod<StartSuiteRunRequest, StartSuiteRunResponse, StartSuiteRunError, Credentials | HttpClient.HttpClient>;
export type StopSuiteRunError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops a Device Advisor test suite run that is currently running.
 *
 * Requires permission to access the StopSuiteRun action.
 */
export declare const stopSuiteRun: API.OperationMethod<StopSuiteRunRequest, StopSuiteRunResponse, StopSuiteRunError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds to and modifies existing tags of an IoT Device Advisor resource.
 *
 * Requires permission to access the TagResource action.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from an IoT Device Advisor resource.
 *
 * Requires permission to access the UntagResource action.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateSuiteDefinitionError = InternalServerException | ValidationException | CommonErrors;
/**
 * Updates a Device Advisor test suite.
 *
 * Requires permission to access the UpdateSuiteDefinition action.
 */
export declare const updateSuiteDefinition: API.OperationMethod<UpdateSuiteDefinitionRequest, UpdateSuiteDefinitionResponse, UpdateSuiteDefinitionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iotdeviceadvisor.d.ts.map