import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SessionId = string;
export type ParticipantToken = string;
export interface CancelParticipantAuthenticationRequest {
    SessionId: string;
    ConnectionToken: string;
}
export declare const CancelParticipantAuthenticationRequest: S.Schema<CancelParticipantAuthenticationRequest>;
export interface CancelParticipantAuthenticationResponse {
}
export declare const CancelParticipantAuthenticationResponse: S.Schema<CancelParticipantAuthenticationResponse>;
export type ArtifactId = string;
export type AttachmentIdList = string[];
export declare const AttachmentIdList: any;
export type NonEmptyClientToken = string;
export interface CompleteAttachmentUploadRequest {
    AttachmentIds: string[];
    ClientToken: string;
    ConnectionToken: string;
}
export declare const CompleteAttachmentUploadRequest: S.Schema<CompleteAttachmentUploadRequest>;
export interface CompleteAttachmentUploadResponse {
}
export declare const CompleteAttachmentUploadResponse: S.Schema<CompleteAttachmentUploadResponse>;
export type ConnectionType = "WEBSOCKET" | "CONNECTION_CREDENTIALS" | "WEBRTC_CONNECTION" | (string & {});
export declare const ConnectionType: any;
export type ConnectionTypeList = ConnectionType[];
export declare const ConnectionTypeList: any;
export interface CreateParticipantConnectionRequest {
    Type?: ConnectionType[];
    ParticipantToken: string;
    ConnectParticipant?: boolean;
}
export declare const CreateParticipantConnectionRequest: S.Schema<CreateParticipantConnectionRequest>;
export type PreSignedConnectionUrl = string;
export type ISO8601Datetime = string;
export interface Websocket {
    Url?: string;
    ConnectionExpiry?: string;
}
export declare const Websocket: S.Schema<Websocket>;
export interface ConnectionCredentials {
    ConnectionToken?: string;
    Expiry?: string;
}
export declare const ConnectionCredentials: S.Schema<ConnectionCredentials>;
export type AttendeeId = string;
export type JoinToken = string | redacted.Redacted<string>;
export interface Attendee {
    AttendeeId?: string;
    JoinToken?: string | redacted.Redacted<string>;
}
export declare const Attendee: S.Schema<Attendee>;
export type URI = string;
export interface WebRTCMediaPlacement {
    AudioHostUrl?: string;
    AudioFallbackUrl?: string;
    SignalingUrl?: string;
    EventIngestionUrl?: string;
}
export declare const WebRTCMediaPlacement: S.Schema<WebRTCMediaPlacement>;
export type MeetingFeatureStatus = "AVAILABLE" | "UNAVAILABLE" | (string & {});
export declare const MeetingFeatureStatus: any;
export interface AudioFeatures {
    EchoReduction?: MeetingFeatureStatus;
}
export declare const AudioFeatures: S.Schema<AudioFeatures>;
export interface MeetingFeaturesConfiguration {
    Audio?: AudioFeatures;
}
export declare const MeetingFeaturesConfiguration: S.Schema<MeetingFeaturesConfiguration>;
export type GuidString = string;
export interface WebRTCMeeting {
    MediaPlacement?: WebRTCMediaPlacement;
    MeetingFeatures?: MeetingFeaturesConfiguration;
    MeetingId?: string;
}
export declare const WebRTCMeeting: S.Schema<WebRTCMeeting>;
export interface WebRTCConnection {
    Attendee?: Attendee;
    Meeting?: WebRTCMeeting;
}
export declare const WebRTCConnection: S.Schema<WebRTCConnection>;
export interface CreateParticipantConnectionResponse {
    Websocket?: Websocket;
    ConnectionCredentials?: ConnectionCredentials;
    WebRTCConnection?: WebRTCConnection;
}
export declare const CreateParticipantConnectionResponse: S.Schema<CreateParticipantConnectionResponse>;
export type ViewToken = string;
export interface DescribeViewRequest {
    ViewToken: string;
    ConnectionToken: string;
}
export declare const DescribeViewRequest: S.Schema<DescribeViewRequest>;
export type ViewId = string;
export type ARN = string;
export type ViewName = string | redacted.Redacted<string>;
export type ViewVersion = number;
export type ViewInputSchema = string | redacted.Redacted<string>;
export type ViewTemplate = string | redacted.Redacted<string>;
export type ViewAction = string | redacted.Redacted<string>;
export type ViewActions = (string | redacted.Redacted<string>)[];
export declare const ViewActions: any;
export interface ViewContent {
    InputSchema?: string | redacted.Redacted<string>;
    Template?: string | redacted.Redacted<string>;
    Actions?: (string | redacted.Redacted<string>)[];
}
export declare const ViewContent: S.Schema<ViewContent>;
export interface View {
    Id?: string;
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    Version?: number;
    Content?: ViewContent;
}
export declare const View: S.Schema<View>;
export interface DescribeViewResponse {
    View?: View;
}
export declare const DescribeViewResponse: S.Schema<DescribeViewResponse>;
export type ClientToken = string;
export interface DisconnectParticipantRequest {
    ClientToken?: string;
    ConnectionToken: string;
}
export declare const DisconnectParticipantRequest: S.Schema<DisconnectParticipantRequest>;
export interface DisconnectParticipantResponse {
}
export declare const DisconnectParticipantResponse: S.Schema<DisconnectParticipantResponse>;
export type URLExpiryInSeconds = number;
export interface GetAttachmentRequest {
    AttachmentId: string;
    ConnectionToken: string;
    UrlExpiryInSeconds?: number;
}
export declare const GetAttachmentRequest: S.Schema<GetAttachmentRequest>;
export type PreSignedAttachmentUrl = string;
export type AttachmentSizeInBytes = number;
export interface GetAttachmentResponse {
    Url?: string;
    UrlExpiry?: string;
    AttachmentSizeInBytes: number;
}
export declare const GetAttachmentResponse: S.Schema<GetAttachmentResponse>;
export type RedirectURI = string;
export interface GetAuthenticationUrlRequest {
    SessionId: string;
    RedirectUri: string;
    ConnectionToken: string;
}
export declare const GetAuthenticationUrlRequest: S.Schema<GetAuthenticationUrlRequest>;
export type AuthenticationUrl = string;
export interface GetAuthenticationUrlResponse {
    AuthenticationUrl?: string;
}
export declare const GetAuthenticationUrlResponse: S.Schema<GetAuthenticationUrlResponse>;
export type ContactId = string;
export type MaxResults = number;
export type NextToken = string;
export type ScanDirection = "FORWARD" | "BACKWARD" | (string & {});
export declare const ScanDirection: any;
export type SortKey = "DESCENDING" | "ASCENDING" | (string & {});
export declare const SortKey: any;
export type ChatItemId = string;
export type Instant = string;
export type MostRecent = number;
export interface StartPosition {
    Id?: string;
    AbsoluteTime?: string;
    MostRecent?: number;
}
export declare const StartPosition: S.Schema<StartPosition>;
export interface GetTranscriptRequest {
    ContactId?: string;
    MaxResults?: number;
    NextToken?: string;
    ScanDirection?: ScanDirection;
    SortOrder?: SortKey;
    StartPosition?: StartPosition;
    ConnectionToken: string;
}
export declare const GetTranscriptRequest: S.Schema<GetTranscriptRequest>;
export type ChatContent = string;
export type ChatContentType = string;
export type ChatItemType = "TYPING" | "PARTICIPANT_JOINED" | "PARTICIPANT_LEFT" | "CHAT_ENDED" | "TRANSFER_SUCCEEDED" | "TRANSFER_FAILED" | "MESSAGE" | "EVENT" | "ATTACHMENT" | "CONNECTION_ACK" | "MESSAGE_DELIVERED" | "MESSAGE_READ" | (string & {});
export declare const ChatItemType: any;
export type ParticipantId = string;
export type DisplayName = string;
export type ParticipantRole = "AGENT" | "CUSTOMER" | "SYSTEM" | "CUSTOM_BOT" | "SUPERVISOR" | (string & {});
export declare const ParticipantRole: any;
export type ContentType = string;
export type AttachmentName = string;
export type ArtifactStatus = "APPROVED" | "REJECTED" | "IN_PROGRESS" | (string & {});
export declare const ArtifactStatus: any;
export interface AttachmentItem {
    ContentType?: string;
    AttachmentId?: string;
    AttachmentName?: string;
    Status?: ArtifactStatus;
}
export declare const AttachmentItem: S.Schema<AttachmentItem>;
export type Attachments = AttachmentItem[];
export declare const Attachments: any;
export interface Receipt {
    DeliveredTimestamp?: string;
    ReadTimestamp?: string;
    RecipientParticipantId?: string;
}
export declare const Receipt: S.Schema<Receipt>;
export type Receipts = Receipt[];
export declare const Receipts: any;
export type MessageProcessingStatus = "PROCESSING" | "FAILED" | "REJECTED" | (string & {});
export declare const MessageProcessingStatus: any;
export interface MessageMetadata {
    MessageId?: string;
    Receipts?: Receipt[];
    MessageProcessingStatus?: MessageProcessingStatus;
}
export declare const MessageMetadata: S.Schema<MessageMetadata>;
export interface Item {
    AbsoluteTime?: string;
    Content?: string;
    ContentType?: string;
    Id?: string;
    Type?: ChatItemType;
    ParticipantId?: string;
    DisplayName?: string;
    ParticipantRole?: ParticipantRole;
    Attachments?: AttachmentItem[];
    MessageMetadata?: MessageMetadata;
    RelatedContactId?: string;
    ContactId?: string;
}
export declare const Item: S.Schema<Item>;
export type Transcript = Item[];
export declare const Transcript: any;
export interface GetTranscriptResponse {
    InitialContactId?: string;
    Transcript?: Item[];
    NextToken?: string;
}
export declare const GetTranscriptResponse: S.Schema<GetTranscriptResponse>;
export interface SendEventRequest {
    ContentType: string;
    Content?: string;
    ClientToken?: string;
    ConnectionToken: string;
}
export declare const SendEventRequest: S.Schema<SendEventRequest>;
export interface SendEventResponse {
    Id?: string;
    AbsoluteTime?: string;
}
export declare const SendEventResponse: S.Schema<SendEventResponse>;
export interface SendMessageRequest {
    ContentType: string;
    Content: string;
    ClientToken?: string;
    ConnectionToken: string;
}
export declare const SendMessageRequest: S.Schema<SendMessageRequest>;
export interface MessageProcessingMetadata {
    MessageProcessingStatus?: MessageProcessingStatus;
}
export declare const MessageProcessingMetadata: S.Schema<MessageProcessingMetadata>;
export interface SendMessageResponse {
    Id?: string;
    AbsoluteTime?: string;
    MessageMetadata?: MessageProcessingMetadata;
}
export declare const SendMessageResponse: S.Schema<SendMessageResponse>;
export interface StartAttachmentUploadRequest {
    ContentType: string;
    AttachmentSizeInBytes: number;
    AttachmentName: string;
    ClientToken: string;
    ConnectionToken: string;
}
export declare const StartAttachmentUploadRequest: S.Schema<StartAttachmentUploadRequest>;
export type UploadMetadataUrl = string;
export type UploadMetadataSignedHeadersKey = string;
export type UploadMetadataSignedHeadersValue = string;
export type UploadMetadataSignedHeaders = {
    [key: string]: string | undefined;
};
export declare const UploadMetadataSignedHeaders: any;
export interface UploadMetadata {
    Url?: string;
    UrlExpiry?: string;
    HeadersToInclude?: {
        [key: string]: string | undefined;
    };
}
export declare const UploadMetadata: S.Schema<UploadMetadata>;
export interface StartAttachmentUploadResponse {
    AttachmentId?: string;
    UploadMetadata?: UploadMetadata;
}
export declare const StartAttachmentUploadResponse: S.Schema<StartAttachmentUploadResponse>;
export type Message = string;
export type Reason = string;
export type ResourceId = string;
export type ResourceType = "CONTACT" | "CONTACT_FLOW" | "INSTANCE" | "PARTICIPANT" | "HIERARCHY_LEVEL" | "HIERARCHY_GROUP" | "USER" | "PHONE_NUMBER" | (string & {});
export declare const ResourceType: any;
export type CancelParticipantAuthenticationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the authentication session. The opted out branch of the Authenticate Customer
 * flow block will be taken.
 *
 * The current supported channel is chat. This API is not supported for Apple
 * Messages for Business, WhatsApp, or SMS chats.
 *
 * `ConnectionToken` is used for invoking this API instead of
 * `ParticipantToken`.
 *
 * The Amazon Connect Participant Service APIs do not use Signature Version 4
 * authentication.
 */
export declare const cancelParticipantAuthentication: API.OperationMethod<CancelParticipantAuthenticationRequest, CancelParticipantAuthenticationResponse, CancelParticipantAuthenticationError, Credentials | HttpClient.HttpClient>;
export type CompleteAttachmentUploadError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows you to confirm that the attachment has been uploaded using the pre-signed URL
 * provided in StartAttachmentUpload API. A conflict exception is thrown when an attachment
 * with that identifier is already being uploaded.
 *
 * For security recommendations, see Connect Customer Chat security best practices.
 *
 * `ConnectionToken` is used for invoking this API instead of
 * `ParticipantToken`.
 *
 * The Amazon Connect Participant Service APIs do not use Signature Version 4
 * authentication.
 */
export declare const completeAttachmentUpload: API.OperationMethod<CompleteAttachmentUploadRequest, CompleteAttachmentUploadResponse, CompleteAttachmentUploadError, Credentials | HttpClient.HttpClient>;
export type CreateParticipantConnectionError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates the participant's connection.
 *
 * For security recommendations, see Connect Customer Chat security best practices.
 *
 * For WebRTC security recommendations, see Connect Customer WebRTC security best practices.
 *
 * `ParticipantToken` is used for invoking this API instead of
 * `ConnectionToken`.
 *
 * The participant token is valid for the lifetime of the participant – until they are
 * part of a contact. For WebRTC participants, if they leave or are disconnected for 60
 * seconds, a new participant needs to be created using the CreateParticipant API.
 *
 * **For `WEBSOCKET` Type**:
 *
 * The response URL for has a connect expiry timeout of 100s. Clients must manually
 * connect to the returned websocket URL and subscribe to the desired topic.
 *
 * For chat, you need to publish the following on the established websocket
 * connection:
 *
 * `{"topic":"aws/subscribe","content":{"topics":["aws/chat"]}}`
 *
 * Upon websocket URL expiry, as specified in the response ConnectionExpiry parameter,
 * clients need to call this API again to obtain a new websocket URL and perform the same
 * steps as before.
 *
 * The expiry time for the connection token is different than the
 * `ChatDurationInMinutes`. Expiry time for the connection token is 1
 * day.
 *
 * **For `WEBRTC_CONNECTION` Type**:
 *
 * The response includes connection data required for the client application to join the
 * call using the Amazon Chime SDK client libraries. The WebRTCConnection response contains
 * Meeting and Attendee information needed to establish the media connection.
 *
 * The attendee join token in WebRTCConnection response is valid for the lifetime of the
 * participant in the call. If a participant leaves or is disconnected for 60 seconds,
 * their participant credentials will no longer be valid, and a new participant will need
 * to be created to rejoin the call.
 *
 * **Message streaming support**: This API can also be used
 * together with the StartContactStreaming API to create a participant connection for chat
 * contacts that are not using a websocket. For more information about message streaming,
 * Enable real-time chat
 * message streaming in the Amazon Connect Administrator
 * Guide.
 *
 * **Multi-user web, in-app, video calling support**:
 *
 * For WebRTC calls, this API is used in conjunction with the CreateParticipant API to
 * enable multi-party calling. The StartWebRTCContact API creates the initial contact and
 * routes it to an agent, while CreateParticipant adds additional participants to the
 * ongoing call. For more information about multi-party WebRTC calls, see Enable multi-user web, in-app, and video calling in the Amazon Connect
 * Administrator Guide.
 *
 * **Feature specifications**: For information about feature
 * specifications, such as the allowed number of open websocket connections per participant
 * or maximum number of WebRTC participants, see Feature specifications in the Amazon Connect Administrator
 * Guide.
 *
 * The Amazon Connect Participant Service APIs do not use Signature Version 4
 * authentication.
 */
export declare const createParticipantConnection: API.OperationMethod<CreateParticipantConnectionRequest, CreateParticipantConnectionResponse, CreateParticipantConnectionError, Credentials | HttpClient.HttpClient>;
export type DescribeViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the view for the specified view token.
 *
 * For security recommendations, see Connect Customer Chat security best practices.
 */
export declare const describeView: API.OperationMethod<DescribeViewRequest, DescribeViewResponse, DescribeViewError, Credentials | HttpClient.HttpClient>;
export type DisconnectParticipantError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disconnects a participant.
 *
 * For security recommendations, see Connect Customer Chat security best practices.
 *
 * `ConnectionToken` is used for invoking this API instead of
 * `ParticipantToken`.
 *
 * The Amazon Connect Participant Service APIs do not use Signature Version 4
 * authentication.
 */
export declare const disconnectParticipant: API.OperationMethod<DisconnectParticipantRequest, DisconnectParticipantResponse, DisconnectParticipantError, Credentials | HttpClient.HttpClient>;
export type GetAttachmentError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides a pre-signed URL for download of a completed attachment. This is an
 * asynchronous API for use with active contacts.
 *
 * For security recommendations, see Connect Customer Chat security best practices.
 *
 * - The participant role `CUSTOM_BOT` is not permitted to access
 * attachments customers may upload. An `AccessDeniedException` can
 * indicate that the participant may be a CUSTOM_BOT, and it doesn't have
 * access to attachments.
 *
 * - `ConnectionToken` is used for invoking this API instead of
 * `ParticipantToken`.
 *
 * The Amazon Connect Participant Service APIs do not use Signature Version 4
 * authentication.
 */
export declare const getAttachment: API.OperationMethod<GetAttachmentRequest, GetAttachmentResponse, GetAttachmentError, Credentials | HttpClient.HttpClient>;
export type GetAuthenticationUrlError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the AuthenticationUrl for the current authentication session for the
 * AuthenticateCustomer flow block.
 *
 * For security recommendations, see Connect Customer Chat security best practices.
 *
 * - This API can only be called within one minute of receiving the
 * authenticationInitiated event.
 *
 * - The current supported channel is chat. This API is not supported for Apple
 * Messages for Business, WhatsApp, or SMS chats.
 *
 * `ConnectionToken` is used for invoking this API instead of
 * `ParticipantToken`.
 *
 * The Amazon Connect Participant Service APIs do not use Signature Version 4
 * authentication.
 */
export declare const getAuthenticationUrl: API.OperationMethod<GetAuthenticationUrlRequest, GetAuthenticationUrlResponse, GetAuthenticationUrlError, Credentials | HttpClient.HttpClient>;
export type GetTranscriptError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a transcript of the session, including details about any attachments. For
 * information about accessing past chat contact transcripts for a persistent chat, see
 * Enable persistent chat.
 *
 * For security recommendations, see Connect Customer Chat security best practices.
 *
 * If you have a process that consumes events in the transcript of an chat that has
 * ended, note that chat transcripts contain the following event content types if the event
 * has occurred during the chat session:
 *
 * - `application/vnd.amazonaws.connect.event.participant.invited`
 *
 * - `application/vnd.amazonaws.connect.event.participant.joined`
 *
 * - `application/vnd.amazonaws.connect.event.participant.left`
 *
 * - `application/vnd.amazonaws.connect.event.chat.ended`
 *
 * - `application/vnd.amazonaws.connect.event.transfer.succeeded`
 *
 * - `application/vnd.amazonaws.connect.event.transfer.failed`
 *
 * `ConnectionToken` is used for invoking this API instead of
 * `ParticipantToken`.
 *
 * The Amazon Connect Participant Service APIs do not use Signature Version 4
 * authentication.
 */
export declare const getTranscript: API.PaginatedOperationMethod<GetTranscriptRequest, GetTranscriptResponse, GetTranscriptError, Credentials | HttpClient.HttpClient, unknown>;
export type SendEventError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The `application/vnd.amazonaws.connect.event.connection.acknowledged`
 * ContentType is no longer maintained since December 31, 2024. This event has been
 * migrated to the CreateParticipantConnection API using the
 * `ConnectParticipant` field.
 *
 * Sends an event. Message receipts are not supported when there are more than two active
 * participants in the chat. Using the SendEvent API for message receipts when a supervisor
 * is barged-in will result in a conflict exception.
 *
 * For security recommendations, see Connect Customer Chat security best practices.
 *
 * `ConnectionToken` is used for invoking this API instead of
 * `ParticipantToken`.
 *
 * The Amazon Connect Participant Service APIs do not use Signature Version 4
 * authentication.
 */
export declare const sendEvent: API.OperationMethod<SendEventRequest, SendEventResponse, SendEventError, Credentials | HttpClient.HttpClient>;
export type SendMessageError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends a message.
 *
 * For security recommendations, see Connect Customer Chat security best practices.
 *
 * `ConnectionToken` is used for invoking this API instead of
 * `ParticipantToken`.
 *
 * The Amazon Connect Participant Service APIs do not use Signature Version 4
 * authentication.
 */
export declare const sendMessage: API.OperationMethod<SendMessageRequest, SendMessageResponse, SendMessageError, Credentials | HttpClient.HttpClient>;
export type StartAttachmentUploadError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides a pre-signed Amazon S3 URL in response for uploading the file directly to
 * S3.
 *
 * For security recommendations, see Connect Customer Chat security best practices.
 *
 * `ConnectionToken` is used for invoking this API instead of
 * `ParticipantToken`.
 *
 * The Amazon Connect Participant Service APIs do not use Signature Version 4
 * authentication.
 */
export declare const startAttachmentUpload: API.OperationMethod<StartAttachmentUploadRequest, StartAttachmentUploadResponse, StartAttachmentUploadError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=connectparticipant.d.ts.map