import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BillingViewHealthStatusException_base: S.Class<BillingViewHealthStatusException, S.TaggedStruct<"BillingViewHealthStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BillingViewHealthStatusException extends /*@__PURE__*/ BillingViewHealthStatusException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type BillingViewArn = string;
export type BillingViewSourceViewsList = string[];
export declare const BillingViewSourceViewsList: any;
export interface AssociateSourceViewsRequest {
    arn: string;
    sourceViews: string[];
}
export declare const AssociateSourceViewsRequest: S.Schema<AssociateSourceViewsRequest>;
export interface AssociateSourceViewsResponse {
    arn: string;
}
export declare const AssociateSourceViewsResponse: S.Schema<AssociateSourceViewsResponse>;
export type BillingViewName = string | redacted.Redacted<string>;
export type BillingViewDescription = string | redacted.Redacted<string>;
export type Dimension = "LINKED_ACCOUNT" | (string & {});
export declare const Dimension: any;
export type Value = string;
export type Values = string[];
export declare const Values: any;
export interface DimensionValues {
    key: Dimension;
    values: string[];
}
export declare const DimensionValues: S.Schema<DimensionValues>;
export type TagKey = string;
export interface TagValues {
    key: string;
    values: string[];
}
export declare const TagValues: S.Schema<TagValues>;
export type CostCategoryName = string;
export interface CostCategoryValues {
    key: string;
    values: string[];
}
export declare const CostCategoryValues: S.Schema<CostCategoryValues>;
export interface TimeRange {
    beginDateInclusive?: Date;
    endDateInclusive?: Date;
}
export declare const TimeRange: S.Schema<TimeRange>;
export interface Expression {
    dimensions?: DimensionValues;
    tags?: TagValues;
    costCategories?: CostCategoryValues;
    timeRange?: TimeRange;
}
export declare const Expression: S.Schema<Expression>;
export type ClientToken = string;
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    key: string;
    value?: string;
}
export declare const ResourceTag: S.Schema<ResourceTag>;
export type ResourceTagList = ResourceTag[];
export declare const ResourceTagList: any;
export interface CreateBillingViewRequest {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    sourceViews: string[];
    dataFilterExpression?: Expression;
    clientToken?: string;
    resourceTags?: ResourceTag[];
}
export declare const CreateBillingViewRequest: S.Schema<CreateBillingViewRequest>;
export interface CreateBillingViewResponse {
    arn: string;
    createdAt?: Date;
}
export declare const CreateBillingViewResponse: S.Schema<CreateBillingViewResponse>;
export interface DeleteBillingViewRequest {
    arn: string;
    force?: boolean;
}
export declare const DeleteBillingViewRequest: S.Schema<DeleteBillingViewRequest>;
export interface DeleteBillingViewResponse {
    arn: string;
}
export declare const DeleteBillingViewResponse: S.Schema<DeleteBillingViewResponse>;
export interface DisassociateSourceViewsRequest {
    arn: string;
    sourceViews: string[];
}
export declare const DisassociateSourceViewsRequest: S.Schema<DisassociateSourceViewsRequest>;
export interface DisassociateSourceViewsResponse {
    arn: string;
}
export declare const DisassociateSourceViewsResponse: S.Schema<DisassociateSourceViewsResponse>;
export type PageToken = string;
export type BillingFeature = "RI_SHARING" | "RI_SHARING_HISTORY" | "CREDIT_SHARING" | "CREDIT_SHARING_HISTORY" | "CREDIT_LEVEL_SHARING" | "BILLING_ALERTS" | "CREDIT_PREFERENCE_OPTIONS" | (string & {});
export declare const BillingFeature: any;
export type BillingFeatures = BillingFeature[];
export declare const BillingFeatures: any;
export type BillingFeatureFilterName = "PREFERENCE_KEY" | (string & {});
export declare const BillingFeatureFilterName: any;
export type BillingFeatureFilterValue = string;
export type BillingFeatureFilterValues = string[];
export declare const BillingFeatureFilterValues: any;
export interface BillingFeatureFilter {
    name?: BillingFeatureFilterName;
    value?: string[];
}
export declare const BillingFeatureFilter: S.Schema<BillingFeatureFilter>;
export type BillingFeatureFilters = BillingFeatureFilter[];
export declare const BillingFeatureFilters: any;
export interface GetBillingPreferencesRequest {
    nextToken?: string;
    maxResults?: number;
    features: BillingFeature[];
    filters?: BillingFeatureFilter[];
}
export declare const GetBillingPreferencesRequest: S.Schema<GetBillingPreferencesRequest>;
export type PreferenceKey = string;
export type PreferenceValue = "ENABLED" | "DISABLED" | (string & {});
export declare const PreferenceValue: any;
export type AccountName = string;
export type AccountId = string;
export type BillingYear = number;
export type Month = number;
export interface BillingPeriod {
    year: number;
    month: number;
}
export declare const BillingPeriod: S.Schema<BillingPeriod>;
export interface BillingPreferenceSummary {
    feature: BillingFeature;
    key: string;
    value: PreferenceValue;
    accountName?: string;
    accountId?: string;
    billingPeriod?: BillingPeriod;
}
export declare const BillingPreferenceSummary: S.Schema<BillingPreferenceSummary>;
export type BillingPreferences = BillingPreferenceSummary[];
export declare const BillingPreferences: any;
export interface GetBillingPreferencesResponse {
    billingPreferences: BillingPreferenceSummary[];
    nextToken?: string;
}
export declare const GetBillingPreferencesResponse: S.Schema<GetBillingPreferencesResponse>;
export interface GetBillingViewRequest {
    arn: string;
}
export declare const GetBillingViewRequest: S.Schema<GetBillingViewRequest>;
export type BillingViewType = "PRIMARY" | "BILLING_GROUP" | "CUSTOM" | "BILLING_TRANSFER" | "BILLING_TRANSFER_SHOWBACK" | (string & {});
export declare const BillingViewType: any;
export type BillingViewStatus = "HEALTHY" | "UNHEALTHY" | "CREATING" | "UPDATING" | (string & {});
export declare const BillingViewStatus: any;
export type BillingViewStatusReason = "SOURCE_VIEW_UNHEALTHY" | "SOURCE_VIEW_UPDATING" | "SOURCE_VIEW_ACCESS_DENIED" | "SOURCE_VIEW_NOT_FOUND" | "CYCLIC_DEPENDENCY" | "SOURCE_VIEW_DEPTH_EXCEEDED" | "AGGREGATE_SOURCE" | "VIEW_OWNER_NOT_MANAGEMENT_ACCOUNT" | (string & {});
export declare const BillingViewStatusReason: any;
export type BillingViewStatusReasons = BillingViewStatusReason[];
export declare const BillingViewStatusReasons: any;
export interface BillingViewHealthStatus {
    statusCode?: BillingViewStatus;
    statusReasons?: BillingViewStatusReason[];
}
export declare const BillingViewHealthStatus: S.Schema<BillingViewHealthStatus>;
export interface BillingViewElement {
    arn?: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    billingViewType?: BillingViewType;
    ownerAccountId?: string;
    sourceAccountId?: string;
    dataFilterExpression?: Expression;
    createdAt?: Date;
    updatedAt?: Date;
    derivedViewCount?: number;
    sourceViewCount?: number;
    viewDefinitionLastUpdatedAt?: Date;
    healthStatus?: BillingViewHealthStatus;
}
export declare const BillingViewElement: S.Schema<BillingViewElement>;
export interface GetBillingViewResponse {
    billingView: BillingViewElement;
}
export declare const GetBillingViewResponse: S.Schema<GetBillingViewResponse>;
export interface GetCreditAllocationHistoryRequest {
    accountId: string;
    creditId?: number;
    startDate: Date;
    endDate: Date;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetCreditAllocationHistoryRequest: S.Schema<GetCreditAllocationHistoryRequest>;
export type CreditId = string;
export type CurrencyCode = string;
export type CurrencyAmount = string;
export interface Amount {
    currencyCode: string;
    currencyAmount: string;
}
export declare const Amount: S.Schema<Amount>;
export type BillingMonth = string;
export interface CreditAllocationHistoryEntry {
    creditId: string;
    creditAmount: Amount;
    description?: string;
    accountId: string;
    appliedServiceName: string;
    billingMonth: string;
    isEstimatedBill: boolean;
}
export declare const CreditAllocationHistoryEntry: S.Schema<CreditAllocationHistoryEntry>;
export type CreditAllocationHistoryList = CreditAllocationHistoryEntry[];
export declare const CreditAllocationHistoryList: any;
export type FailedMonthsList = string[];
export declare const FailedMonthsList: any;
export interface GetCreditAllocationHistoryResponse {
    creditAllocationHistoryList?: CreditAllocationHistoryEntry[];
    partialResults: boolean;
    failedMonths?: string[];
    nextToken?: string;
}
export declare const GetCreditAllocationHistoryResponse: S.Schema<GetCreditAllocationHistoryResponse>;
export interface GetCreditsRequest {
    accountId: string;
    startDate: Date;
    endDate?: Date;
    payerAccountFlag?: boolean;
}
export declare const GetCreditsRequest: S.Schema<GetCreditsRequest>;
export type ProductName = string;
export type ProductNames = string[];
export declare const ProductNames: any;
export type ApplicationType = "BEFORE_CROSS_SERVICE_DISCOUNTS" | "AFTER_DISCOUNTS" | (string & {});
export declare const ApplicationType: any;
export type ShareableAccountIds = string[];
export declare const ShareableAccountIds: any;
export type CreditSharingType = "DEFAULT" | "DISABLED" | "CUSTOM" | "COST_CATEGORY_RULE" | (string & {});
export declare const CreditSharingType: any;
export type CreditStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const CreditStatus: any;
export type PurchaseType = string;
export type PurchaseTypeApplications = string[];
export declare const PurchaseTypeApplications: any;
export interface CreditData {
    creditId: string;
    accountId: string;
    creditType: string;
    initialAmount: Amount;
    remainingAmount: Amount;
    estimatedAmount?: Amount;
    applicableProductNames?: string[];
    description: string;
    startDate: Date;
    endDate?: Date;
    exhaustDate?: Date;
    applicationType?: ApplicationType;
    shareableAccounts?: string[];
    accountHasCreditSharingEnabled?: boolean;
    creditConsoleVisibility?: string;
    creditSharingType?: CreditSharingType;
    costCategoryArn?: string;
    ruleName?: string;
    creditStatus?: CreditStatus;
    purchaseTypeApplications?: string[];
}
export declare const CreditData: S.Schema<CreditData>;
export type CreditDataList = CreditData[];
export declare const CreditDataList: any;
export interface GetCreditsResponse {
    credits?: CreditData[];
}
export declare const GetCreditsResponse: S.Schema<GetCreditsResponse>;
export type EnterpriseSupportBillingMonth = string;
export interface GetEnterpriseSupportChargeSummaryRequest {
    billingMonth: string;
}
export declare const GetEnterpriseSupportChargeSummaryRequest: S.Schema<GetEnterpriseSupportChargeSummaryRequest>;
export interface PricingPlanTier {
    tierMinimum: string;
    tierMaximum?: string;
    baseCharge: string;
    additionalPercentageOfAggregateCharges: string;
    aggregateChargesAdjustment: string;
    incremental: boolean;
    increment?: string;
    incrementCharge?: string;
}
export declare const PricingPlanTier: S.Schema<PricingPlanTier>;
export type PricingPlanTierList = PricingPlanTier[];
export declare const PricingPlanTierList: any;
export interface PricingPlan {
    pricingPlanId?: string;
    name?: string;
    description?: string;
    startDate?: Date;
    endDate?: Date;
    planDiscountPercent?: string;
    discountAppliesToMinimumCharge?: boolean;
    minimumCharge?: string;
    tiered?: string;
    tiers: PricingPlanTier[];
}
export declare const PricingPlan: S.Schema<PricingPlan>;
export interface GetEnterpriseSupportChargeSummaryResponse {
    payerAccountId: string;
    billingMonth: string;
    billingPeriodStartDate: Date;
    billingPeriodEndDate: Date;
    isEstimated: boolean;
    billDate: Date;
    supportCharge: string;
    totalSupportCharge: string;
    supportDiscount: string;
    totalSupportEligibleSpend: string;
    totalSupportEligibleUsageSpend: string;
    totalSupportEligibleReservedInstanceSpend: string;
    totalSupportEligibleSavingsPlanSpend: string;
    supportChargePercentage: string;
    supportEffectivePricingPlan: PricingPlan;
}
export declare const GetEnterpriseSupportChargeSummaryResponse: S.Schema<GetEnterpriseSupportChargeSummaryResponse>;
export interface GetEnterpriseSupportContractDetailsRequest {
    billingMonth: string;
}
export declare const GetEnterpriseSupportContractDetailsRequest: S.Schema<GetEnterpriseSupportContractDetailsRequest>;
export interface ContractAccount {
    accountId: string;
    isGdn: boolean;
}
export declare const ContractAccount: S.Schema<ContractAccount>;
export type ContractAccountList = ContractAccount[];
export declare const ContractAccountList: any;
export interface ChargeAccount {
    accountId: string;
    chargePercentage: string;
}
export declare const ChargeAccount: S.Schema<ChargeAccount>;
export type ChargeAccountList = ChargeAccount[];
export declare const ChargeAccountList: any;
export interface AdditionalCharge {
    description: string;
    amount?: string;
    chargeType?: string;
}
export declare const AdditionalCharge: S.Schema<AdditionalCharge>;
export type AdditionalChargeList = AdditionalCharge[];
export declare const AdditionalChargeList: any;
export type PricingPlanList = PricingPlan[];
export declare const PricingPlanList: any;
export interface GetEnterpriseSupportContractDetailsResponse {
    isContractActive?: boolean;
    supportAllocationMethod: string;
    supportReservedInstanceAmortizationStartDate?: Date;
    supportReservedInstanceTreatmentMethod?: string;
    supportSavingsPlansAmortizationStartDate?: Date;
    supportSavingsPlansTreatmentMethod?: string;
    supportProrateStartDate?: Date;
    contractPayerAccountIds: ContractAccount[];
    chargedPayerAccountIds: ChargeAccount[];
    additionalSupportCharge?: AdditionalCharge[];
    additionalSupportEligibleUsageSpend?: AdditionalCharge[];
    pricingPlans: PricingPlan[];
}
export declare const GetEnterpriseSupportContractDetailsResponse: S.Schema<GetEnterpriseSupportContractDetailsResponse>;
export type ResourceArn = string;
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export declare const GetResourcePolicyRequest: S.Schema<GetResourcePolicyRequest>;
export type PolicyDocument = string;
export interface GetResourcePolicyResponse {
    resourceArn: string;
    policy?: string;
}
export declare const GetResourcePolicyResponse: S.Schema<GetResourcePolicyResponse>;
export interface ActiveTimeRange {
    activeAfterInclusive: Date;
    activeBeforeInclusive: Date;
}
export declare const ActiveTimeRange: S.Schema<ActiveTimeRange>;
export type BillingViewArnList = string[];
export declare const BillingViewArnList: any;
export type BillingViewTypeList = BillingViewType[];
export declare const BillingViewTypeList: any;
export type SearchOption = "STARTS_WITH" | (string & {});
export declare const SearchOption: any;
export type SearchValue = string;
export interface StringSearch {
    searchOption: SearchOption;
    searchValue: string;
}
export declare const StringSearch: S.Schema<StringSearch>;
export type StringSearches = StringSearch[];
export declare const StringSearches: any;
export type BillingViewsMaxResults = number;
export interface ListBillingViewsRequest {
    activeTimeRange?: ActiveTimeRange;
    arns?: string[];
    billingViewTypes?: BillingViewType[];
    names?: StringSearch[];
    ownerAccountId?: string;
    sourceAccountId?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListBillingViewsRequest: S.Schema<ListBillingViewsRequest>;
export interface BillingViewListElement {
    arn?: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    ownerAccountId?: string;
    sourceAccountId?: string;
    billingViewType?: BillingViewType;
    healthStatus?: BillingViewHealthStatus;
}
export declare const BillingViewListElement: S.Schema<BillingViewListElement>;
export type BillingViewList = BillingViewListElement[];
export declare const BillingViewList: any;
export interface ListBillingViewsResponse {
    billingViews: BillingViewListElement[];
    nextToken?: string;
}
export declare const ListBillingViewsResponse: S.Schema<ListBillingViewsResponse>;
export interface ListEnterpriseSupportLinkedAccountChargesRequest {
    billingMonth: string;
    accountId?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListEnterpriseSupportLinkedAccountChargesRequest: S.Schema<ListEnterpriseSupportLinkedAccountChargesRequest>;
export interface EnterpriseSupportTimePeriod {
    beginDate: Date;
    endDate?: Date;
}
export declare const EnterpriseSupportTimePeriod: S.Schema<EnterpriseSupportTimePeriod>;
export type TimePeriodList = EnterpriseSupportTimePeriod[];
export declare const TimePeriodList: any;
export interface ServiceLevelAccountUsage {
    serviceCode?: string;
    totalSupportEligibleSpend?: string;
}
export declare const ServiceLevelAccountUsage: S.Schema<ServiceLevelAccountUsage>;
export type ServiceLevelAccountUsageList = ServiceLevelAccountUsage[];
export declare const ServiceLevelAccountUsageList: any;
export interface LinkedAccountCharge {
    accountId: string;
    payerAccountId: string;
    accountType?: string;
    billableSeconds: number;
    totalSeconds: number;
    totalSupportEligibleSpend: string;
    proratedTotalSupportEligibleSpend: string;
    linkedTimePeriods?: EnterpriseSupportTimePeriod[];
    subscriptionTimePeriods?: EnterpriseSupportTimePeriod[];
    totalSupportEligibleReservedInstanceSpend?: string;
    totalSupportEligibleSavingsPlanSpend?: string;
    supportEligibleSpendByService?: ServiceLevelAccountUsage[];
}
export declare const LinkedAccountCharge: S.Schema<LinkedAccountCharge>;
export type LinkedAccountChargeList = LinkedAccountCharge[];
export declare const LinkedAccountChargeList: any;
export interface ListEnterpriseSupportLinkedAccountChargesResponse {
    linkedAccount: LinkedAccountCharge[];
    nextToken?: string;
}
export declare const ListEnterpriseSupportLinkedAccountChargesResponse: S.Schema<ListEnterpriseSupportLinkedAccountChargesResponse>;
export interface ListSourceViewsForBillingViewRequest {
    arn: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSourceViewsForBillingViewRequest: S.Schema<ListSourceViewsForBillingViewRequest>;
export interface ListSourceViewsForBillingViewResponse {
    sourceViews: string[];
    nextToken?: string;
}
export declare const ListSourceViewsForBillingViewResponse: S.Schema<ListSourceViewsForBillingViewResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    resourceTags?: ResourceTag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type PromoCode = string;
export interface RedeemCreditsRequest {
    promoCode: string;
}
export declare const RedeemCreditsRequest: S.Schema<RedeemCreditsRequest>;
export interface RedeemCreditsResponse {
}
export declare const RedeemCreditsResponse: S.Schema<RedeemCreditsResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    resourceTags: ResourceTag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type ResourceTagKeyList = string[];
export declare const ResourceTagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    resourceTagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface BillingPreferenceForKey {
    key: string;
    value: PreferenceValue;
}
export declare const BillingPreferenceForKey: S.Schema<BillingPreferenceForKey>;
export type BillingPreferencesPerKey = BillingPreferenceForKey[];
export declare const BillingPreferencesPerKey: any;
export interface UpdateBillingPreferencesRequest {
    feature: BillingFeature;
    billingPreferencesPerKey: BillingPreferenceForKey[];
}
export declare const UpdateBillingPreferencesRequest: S.Schema<UpdateBillingPreferencesRequest>;
export interface UpdateBillingPreferencesResponse {
}
export declare const UpdateBillingPreferencesResponse: S.Schema<UpdateBillingPreferencesResponse>;
export interface UpdateBillingViewRequest {
    arn: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    dataFilterExpression?: Expression;
}
export declare const UpdateBillingViewRequest: S.Schema<UpdateBillingViewRequest>;
export interface UpdateBillingViewResponse {
    arn: string;
    updatedAt?: Date;
}
export declare const UpdateBillingViewResponse: S.Schema<UpdateBillingViewResponse>;
export type ErrorMessage = string;
export type ResourceId = string;
export type ResourceType = string;
export type ServiceCode = string;
export type QuotaCode = string;
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export declare const ValidationExceptionReason: any;
export type FieldName = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type AssociateSourceViewsError = AccessDeniedException | BillingViewHealthStatusException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates one or more source billing views with an existing billing view. This allows creating aggregate billing views that combine data from multiple sources.
 */
export declare const associateSourceViews: API.OperationMethod<AssociateSourceViewsRequest, AssociateSourceViewsResponse, AssociateSourceViewsError, Credentials | HttpClient.HttpClient>;
export type CreateBillingViewError = AccessDeniedException | BillingViewHealthStatusException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a billing view with the specified billing view attributes.
 */
export declare const createBillingView: API.OperationMethod<CreateBillingViewRequest, CreateBillingViewResponse, CreateBillingViewError, Credentials | HttpClient.HttpClient>;
export type DeleteBillingViewError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified billing view.
 */
export declare const deleteBillingView: API.OperationMethod<DeleteBillingViewRequest, DeleteBillingViewResponse, DeleteBillingViewError, Credentials | HttpClient.HttpClient>;
export type DisassociateSourceViewsError = AccessDeniedException | BillingViewHealthStatusException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the association between one or more source billing views and an existing billing view. This allows modifying the composition of aggregate billing views.
 */
export declare const disassociateSourceViews: API.OperationMethod<DisassociateSourceViewsRequest, DisassociateSourceViewsResponse, DisassociateSourceViewsError, Credentials | HttpClient.HttpClient>;
export type GetBillingPreferencesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves billing preferences for the specified feature. Each feature controls a distinct billing capability: which accounts can share Reserved Instances or credits, whether billing alerts are enabled, the historical record of sharing changes, and per-credit options.
 */
export declare const getBillingPreferences: API.OperationMethod<GetBillingPreferencesRequest, GetBillingPreferencesResponse, GetBillingPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetBillingViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the metadata associated to the specified billing view ARN.
 */
export declare const getBillingView: API.OperationMethod<GetBillingViewRequest, GetBillingViewResponse, GetBillingViewError, Credentials | HttpClient.HttpClient>;
export type GetCreditAllocationHistoryError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the per-billing-month allocation history for credits applied to an Amazon Web Services account's bills. Traverses the consolidated billing family to capture cross-account credit applications. Supports pagination and optional filtering to a single credit.
 */
export declare const getCreditAllocationHistory: API.PaginatedOperationMethod<GetCreditAllocationHistoryRequest, GetCreditAllocationHistoryResponse, GetCreditAllocationHistoryError, Credentials | HttpClient.HttpClient, CreditAllocationHistoryEntry>;
export type GetCreditsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the list of Amazon Web Services account credits for the specified account. Each credit includes its identifier, type, monetary amounts, applicable products, expiration, sharing configuration, and current enabled status.
 *
 * When the caller is the management account of a consolidated billing family and `payerAccountFlag` is `true`, the response aggregates credits across the entire family. Otherwise, the response includes only credits owned by the account specified in `accountId`.
 */
export declare const getCredits: API.OperationMethod<GetCreditsRequest, GetCreditsResponse, GetCreditsError, Credentials | HttpClient.HttpClient>;
export type GetEnterpriseSupportChargeSummaryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a summary of Enterprise Support data aggregated across all accounts in the Enterprise Support profile.
 */
export declare const getEnterpriseSupportChargeSummary: API.OperationMethod<GetEnterpriseSupportChargeSummaryRequest, GetEnterpriseSupportChargeSummaryResponse, GetEnterpriseSupportChargeSummaryError, Credentials | HttpClient.HttpClient>;
export type GetEnterpriseSupportContractDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns Enterprise Support contract details.
 */
export declare const getEnterpriseSupportContractDetails: API.OperationMethod<GetEnterpriseSupportContractDetailsRequest, GetEnterpriseSupportContractDetailsResponse, GetEnterpriseSupportContractDetailsError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the resource-based policy document attached to the resource in `JSON` format.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type ListBillingViewsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the billing views available for a given time period.
 *
 * Every Amazon Web Services account has a unique `PRIMARY` billing view that represents the billing data available by default. Accounts that use Billing Conductor also have `BILLING_GROUP` billing views representing pro forma costs associated with each created billing group.
 */
export declare const listBillingViews: API.PaginatedOperationMethod<ListBillingViewsRequest, ListBillingViewsResponse, ListBillingViewsError, Credentials | HttpClient.HttpClient, BillingViewListElement>;
export type ListEnterpriseSupportLinkedAccountChargesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns Support-eligible spend broken down at linked account level.
 */
export declare const listEnterpriseSupportLinkedAccountCharges: API.PaginatedOperationMethod<ListEnterpriseSupportLinkedAccountChargesRequest, ListEnterpriseSupportLinkedAccountChargesResponse, ListEnterpriseSupportLinkedAccountChargesError, Credentials | HttpClient.HttpClient, LinkedAccountCharge>;
export type ListSourceViewsForBillingViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the source views (managed Amazon Web Services billing views) associated with the billing view.
 */
export declare const listSourceViewsForBillingView: API.PaginatedOperationMethod<ListSourceViewsForBillingViewRequest, ListSourceViewsForBillingViewResponse, ListSourceViewsForBillingViewError, Credentials | HttpClient.HttpClient, BillingViewArn>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists tags associated with the billing view resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RedeemCreditsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Redeems an Amazon Web Services promotional credit code on behalf of the calling account. On success, a new credit is added to the account's credit ledger with the amount, validity period, and applicable products defined by the promotion. The credit is then automatically applied to subsequent bills according to the standard credit application order.
 */
export declare const redeemCredits: API.OperationMethod<RedeemCreditsRequest, RedeemCreditsResponse, RedeemCreditsError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * An API operation for adding one or more tags (key-value pairs) to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from a resource. Specify only tag keys in your request. Don't specify the value.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBillingPreferencesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates billing preferences for the specified feature. Each feature targets a distinct billing capability and has its own set of supported keys. The action sets the value for each provided key; keys not present in the request are unchanged.
 *
 * Sharing keys (`RI_SHARING`, `CREDIT_SHARING`, `CREDIT_LEVEL_SHARING`, and sharing keys under `CREDIT_PREFERENCE_OPTIONS`) may only be set by the management account of a consolidated billing family. The `credit/{creditId}/status` key may be set by member accounts for credits they own, or by the management account for any credit in the family.
 */
export declare const updateBillingPreferences: API.OperationMethod<UpdateBillingPreferencesRequest, UpdateBillingPreferencesResponse, UpdateBillingPreferencesError, Credentials | HttpClient.HttpClient>;
export type UpdateBillingViewError = AccessDeniedException | BillingViewHealthStatusException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * An API to update the attributes of the billing view.
 */
export declare const updateBillingView: API.OperationMethod<UpdateBillingViewRequest, UpdateBillingViewResponse, UpdateBillingViewError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=billing.d.ts.map