import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ArgumentException_base: S.Class<ArgumentException, S.TaggedStruct<"ArgumentException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ArgumentException extends /*@__PURE__*/ ArgumentException_base {
}
declare const CannotDeleteException_base: S.Class<CannotDeleteException, S.TaggedStruct<"CannotDeleteException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class CannotDeleteException extends /*@__PURE__*/ CannotDeleteException_base {
}
declare const IdempotencyException_base: S.Class<IdempotencyException, S.TaggedStruct<"IdempotencyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IdempotencyException extends /*@__PURE__*/ IdempotencyException_base {
}
declare const InternalServiceException_base: S.Class<InternalServiceException, S.TaggedStruct<"InternalServiceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidOperationException_base: S.Class<InvalidOperationException, S.TaggedStruct<"InvalidOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidOperationException extends /*@__PURE__*/ InvalidOperationException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotEligibleException_base: S.Class<NotEligibleException, S.TaggedStruct<"NotEligibleException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NotEligibleException extends /*@__PURE__*/ NotEligibleException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceAccountException_base: S.Class<ServiceAccountException, S.TaggedStruct<"ServiceAccountException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ServiceAccountException extends /*@__PURE__*/ ServiceAccountException_base {
}
declare const TagOperationException_base: S.Class<TagOperationException, S.TaggedStruct<"TagOperationException", {
    readonly message: any;
    readonly resourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagOperationException extends /*@__PURE__*/ TagOperationException_base {
}
declare const TagPolicyException_base: S.Class<TagPolicyException, S.TaggedStruct<"TagPolicyException", {
    readonly message: any;
    readonly resourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagPolicyException extends /*@__PURE__*/ TagPolicyException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
    readonly resourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
export type AmazonResourceName = string;
export type Name = string;
export type Message = string;
export type DeviceAttribute = "ARN" | "PLATFORM" | "FORM_FACTOR" | "MANUFACTURER" | "REMOTE_ACCESS_ENABLED" | "REMOTE_DEBUG_ENABLED" | "APPIUM_VERSION" | "INSTANCE_ARN" | "INSTANCE_LABELS" | "FLEET_TYPE" | "OS_VERSION" | "MODEL" | "AVAILABILITY" | (string & {});
export declare const DeviceAttribute: any;
export type RuleOperator = "EQUALS" | "LESS_THAN" | "LESS_THAN_OR_EQUALS" | "GREATER_THAN" | "GREATER_THAN_OR_EQUALS" | "IN" | "NOT_IN" | "CONTAINS" | (string & {});
export declare const RuleOperator: any;
export interface Rule {
    attribute?: DeviceAttribute;
    operator?: RuleOperator;
    value?: string;
}
export declare const Rule: S.Schema<Rule>;
export type Rules = Rule[];
export declare const Rules: any;
export interface CreateDevicePoolRequest {
    projectArn: string;
    name: string;
    description?: string;
    rules: Rule[];
    maxDevices?: number;
}
export declare const CreateDevicePoolRequest: S.Schema<CreateDevicePoolRequest>;
export type DevicePoolType = "CURATED" | "PRIVATE" | (string & {});
export declare const DevicePoolType: any;
export interface DevicePool {
    arn?: string;
    name?: string;
    description?: string;
    type?: DevicePoolType;
    rules?: Rule[];
    maxDevices?: number;
}
export declare const DevicePool: S.Schema<DevicePool>;
export interface CreateDevicePoolResult {
    devicePool?: DevicePool;
}
export declare const CreateDevicePoolResult: S.Schema<CreateDevicePoolResult>;
export type PackageIds = string[];
export declare const PackageIds: any;
export interface CreateInstanceProfileRequest {
    name: string;
    description?: string;
    packageCleanup?: boolean;
    excludeAppPackagesFromCleanup?: string[];
    rebootAfterUse?: boolean;
}
export declare const CreateInstanceProfileRequest: S.Schema<CreateInstanceProfileRequest>;
export interface InstanceProfile {
    arn?: string;
    packageCleanup?: boolean;
    excludeAppPackagesFromCleanup?: string[];
    rebootAfterUse?: boolean;
    name?: string;
    description?: string;
}
export declare const InstanceProfile: S.Schema<InstanceProfile>;
export interface CreateInstanceProfileResult {
    instanceProfile?: InstanceProfile;
}
export declare const CreateInstanceProfileResult: S.Schema<CreateInstanceProfileResult>;
export type NetworkProfileType = "CURATED" | "PRIVATE" | (string & {});
export declare const NetworkProfileType: any;
export type PercentInteger = number;
export interface CreateNetworkProfileRequest {
    projectArn: string;
    name: string;
    description?: string;
    type?: NetworkProfileType;
    uplinkBandwidthBits?: number;
    downlinkBandwidthBits?: number;
    uplinkDelayMs?: number;
    downlinkDelayMs?: number;
    uplinkJitterMs?: number;
    downlinkJitterMs?: number;
    uplinkLossPercent?: number;
    downlinkLossPercent?: number;
}
export declare const CreateNetworkProfileRequest: S.Schema<CreateNetworkProfileRequest>;
export interface NetworkProfile {
    arn?: string;
    name?: string;
    description?: string;
    type?: NetworkProfileType;
    uplinkBandwidthBits?: number;
    downlinkBandwidthBits?: number;
    uplinkDelayMs?: number;
    downlinkDelayMs?: number;
    uplinkJitterMs?: number;
    downlinkJitterMs?: number;
    uplinkLossPercent?: number;
    downlinkLossPercent?: number;
}
export declare const NetworkProfile: S.Schema<NetworkProfile>;
export interface CreateNetworkProfileResult {
    networkProfile?: NetworkProfile;
}
export declare const CreateNetworkProfileResult: S.Schema<CreateNetworkProfileResult>;
export type JobTimeoutMinutes = number;
export type SecurityGroupId = string;
export type VpcSecurityGroupIds = string[];
export declare const VpcSecurityGroupIds: any;
export type SubnetId = string;
export type VpcSubnetIds = string[];
export declare const VpcSubnetIds: any;
export type NonEmptyString = string;
export interface VpcConfig {
    securityGroupIds: string[];
    subnetIds: string[];
    vpcId: string;
}
export declare const VpcConfig: S.Schema<VpcConfig>;
export type EnvironmentVariableName = string;
export type EnvironmentVariableValue = string;
export interface EnvironmentVariable {
    name: string;
    value: string;
}
export declare const EnvironmentVariable: S.Schema<EnvironmentVariable>;
export type EnvironmentVariables = EnvironmentVariable[];
export declare const EnvironmentVariables: any;
export type AmazonRoleResourceName = string;
export interface CreateProjectRequest {
    name: string;
    defaultJobTimeoutMinutes?: number;
    vpcConfig?: VpcConfig;
    environmentVariables?: EnvironmentVariable[];
    executionRoleArn?: string;
}
export declare const CreateProjectRequest: S.Schema<CreateProjectRequest>;
export interface Project {
    arn?: string;
    name?: string;
    defaultJobTimeoutMinutes?: number;
    created?: Date;
    vpcConfig?: VpcConfig;
    environmentVariables?: EnvironmentVariable[];
    executionRoleArn?: string;
}
export declare const Project: S.Schema<Project>;
export interface CreateProjectResult {
    project?: Project;
}
export declare const CreateProjectResult: S.Schema<CreateProjectResult>;
export type AuxiliaryAppArnList = string[];
export declare const AuxiliaryAppArnList: any;
export type BillingMethod = "METERED" | "UNMETERED" | (string & {});
export declare const BillingMethod: any;
export type AmazonResourceNames = string[];
export declare const AmazonResourceNames: any;
export type DeviceProxyHost = string;
export type DeviceProxyPort = number;
export interface DeviceProxy {
    host: string;
    port: number;
}
export declare const DeviceProxy: S.Schema<DeviceProxy>;
export type RemoteAccessParameterKey = string;
export type RemoteAccessParameterValue = string;
export type RemoteAccessParameters = {
    [key: string]: string | undefined;
};
export declare const RemoteAccessParameters: any;
export interface CreateRemoteAccessSessionConfiguration {
    auxiliaryApps?: string[];
    billingMethod?: BillingMethod;
    vpceConfigurationArns?: string[];
    deviceProxy?: DeviceProxy;
    parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateRemoteAccessSessionConfiguration: S.Schema<CreateRemoteAccessSessionConfiguration>;
export type InteractionMode = "INTERACTIVE" | "NO_VIDEO" | "VIDEO_ONLY" | (string & {});
export declare const InteractionMode: any;
export interface CreateRemoteAccessSessionRequest {
    projectArn: string;
    deviceArn: string;
    appArn?: string;
    instanceArn?: string;
    name?: string;
    configuration?: CreateRemoteAccessSessionConfiguration;
    interactionMode?: InteractionMode;
    skipAppResign?: boolean;
}
export declare const CreateRemoteAccessSessionRequest: S.Schema<CreateRemoteAccessSessionRequest>;
export type ExecutionStatus = "PENDING" | "PENDING_CONCURRENCY" | "PENDING_DEVICE" | "PROCESSING" | "SCHEDULING" | "PREPARING" | "RUNNING" | "COMPLETED" | "STOPPING" | (string & {});
export declare const ExecutionStatus: any;
export type ExecutionResult = "PENDING" | "PASSED" | "WARNED" | "FAILED" | "SKIPPED" | "ERRORED" | "STOPPED" | (string & {});
export declare const ExecutionResult: any;
export type DeviceFormFactor = "PHONE" | "TABLET" | (string & {});
export declare const DeviceFormFactor: any;
export type DevicePlatform = "ANDROID" | "IOS" | (string & {});
export declare const DevicePlatform: any;
export interface CPU {
    frequency?: string;
    architecture?: string;
    clock?: number;
}
export declare const CPU: S.Schema<CPU>;
export interface Resolution {
    width?: number;
    height?: number;
}
export declare const Resolution: S.Schema<Resolution>;
export type InstanceLabels = string[];
export declare const InstanceLabels: any;
export type InstanceStatus = "IN_USE" | "PREPARING" | "AVAILABLE" | "NOT_AVAILABLE" | (string & {});
export declare const InstanceStatus: any;
export interface DeviceInstance {
    arn?: string;
    deviceArn?: string;
    labels?: string[];
    status?: InstanceStatus;
    udid?: string;
    instanceProfile?: InstanceProfile;
}
export declare const DeviceInstance: S.Schema<DeviceInstance>;
export type DeviceInstances = DeviceInstance[];
export declare const DeviceInstances: any;
export type DeviceAvailability = "TEMPORARY_NOT_AVAILABLE" | "BUSY" | "AVAILABLE" | "HIGHLY_AVAILABLE" | (string & {});
export declare const DeviceAvailability: any;
export interface Device {
    arn?: string;
    name?: string;
    manufacturer?: string;
    model?: string;
    modelId?: string;
    formFactor?: DeviceFormFactor;
    platform?: DevicePlatform;
    os?: string;
    cpu?: CPU;
    resolution?: Resolution;
    heapSize?: number;
    memory?: number;
    image?: string;
    carrier?: string;
    radio?: string;
    remoteAccessEnabled?: boolean;
    remoteDebugEnabled?: boolean;
    fleetType?: string;
    fleetName?: string;
    instances?: DeviceInstance[];
    availability?: DeviceAvailability;
}
export declare const Device: S.Schema<Device>;
export interface DeviceMinutes {
    total?: number;
    metered?: number;
    unmetered?: number;
}
export declare const DeviceMinutes: S.Schema<DeviceMinutes>;
export type SkipAppResign = boolean;
export type SensitiveURL = string | redacted.Redacted<string>;
export interface RemoteAccessEndpoints {
    remoteDriverEndpoint?: string | redacted.Redacted<string>;
    interactiveEndpoint?: string | redacted.Redacted<string>;
}
export declare const RemoteAccessEndpoints: S.Schema<RemoteAccessEndpoints>;
export interface RemoteAccessSession {
    arn?: string;
    name?: string;
    created?: Date;
    status?: ExecutionStatus;
    result?: ExecutionResult;
    message?: string;
    started?: Date;
    stopped?: Date;
    device?: Device;
    instanceArn?: string;
    billingMethod?: BillingMethod;
    deviceMinutes?: DeviceMinutes;
    endpoint?: string;
    deviceUdid?: string;
    interactionMode?: InteractionMode;
    skipAppResign?: boolean;
    vpcConfig?: VpcConfig;
    deviceProxy?: DeviceProxy;
    appUpload?: string;
    endpoints?: RemoteAccessEndpoints;
}
export declare const RemoteAccessSession: S.Schema<RemoteAccessSession>;
export interface CreateRemoteAccessSessionResult {
    remoteAccessSession?: RemoteAccessSession;
}
export declare const CreateRemoteAccessSessionResult: S.Schema<CreateRemoteAccessSessionResult>;
export type ResourceName = string;
export type ResourceDescription = string;
export type SecurityGroupIds = string[];
export declare const SecurityGroupIds: any;
export type SubnetIds = string[];
export declare const SubnetIds: any;
export interface TestGridVpcConfig {
    securityGroupIds: string[];
    subnetIds: string[];
    vpcId: string;
}
export declare const TestGridVpcConfig: S.Schema<TestGridVpcConfig>;
export interface CreateTestGridProjectRequest {
    name: string;
    description?: string;
    vpcConfig?: TestGridVpcConfig;
}
export declare const CreateTestGridProjectRequest: S.Schema<CreateTestGridProjectRequest>;
export type DeviceFarmArn = string;
export interface TestGridProject {
    arn?: string;
    name?: string;
    description?: string;
    vpcConfig?: TestGridVpcConfig;
    created?: Date;
}
export declare const TestGridProject: S.Schema<TestGridProject>;
export interface CreateTestGridProjectResult {
    testGridProject?: TestGridProject;
}
export declare const CreateTestGridProjectResult: S.Schema<CreateTestGridProjectResult>;
export type TestGridUrlExpiresInSecondsInput = number;
export interface CreateTestGridUrlRequest {
    projectArn: string;
    expiresInSeconds: number;
}
export declare const CreateTestGridUrlRequest: S.Schema<CreateTestGridUrlRequest>;
export type SensitiveString = string | redacted.Redacted<string>;
export interface CreateTestGridUrlResult {
    url?: string | redacted.Redacted<string>;
    expires?: Date;
}
export declare const CreateTestGridUrlResult: S.Schema<CreateTestGridUrlResult>;
export type UploadType = "ANDROID_APP" | "IOS_APP" | "WEB_APP" | "EXTERNAL_DATA" | "APPIUM_JAVA_JUNIT_TEST_PACKAGE" | "APPIUM_JAVA_TESTNG_TEST_PACKAGE" | "APPIUM_PYTHON_TEST_PACKAGE" | "APPIUM_NODE_TEST_PACKAGE" | "APPIUM_RUBY_TEST_PACKAGE" | "APPIUM_WEB_JAVA_JUNIT_TEST_PACKAGE" | "APPIUM_WEB_JAVA_TESTNG_TEST_PACKAGE" | "APPIUM_WEB_PYTHON_TEST_PACKAGE" | "APPIUM_WEB_NODE_TEST_PACKAGE" | "APPIUM_WEB_RUBY_TEST_PACKAGE" | "CALABASH_TEST_PACKAGE" | "INSTRUMENTATION_TEST_PACKAGE" | "UIAUTOMATION_TEST_PACKAGE" | "UIAUTOMATOR_TEST_PACKAGE" | "XCTEST_TEST_PACKAGE" | "XCTEST_UI_TEST_PACKAGE" | "APPIUM_JAVA_JUNIT_TEST_SPEC" | "APPIUM_JAVA_TESTNG_TEST_SPEC" | "APPIUM_PYTHON_TEST_SPEC" | "APPIUM_NODE_TEST_SPEC" | "APPIUM_RUBY_TEST_SPEC" | "APPIUM_WEB_JAVA_JUNIT_TEST_SPEC" | "APPIUM_WEB_JAVA_TESTNG_TEST_SPEC" | "APPIUM_WEB_PYTHON_TEST_SPEC" | "APPIUM_WEB_NODE_TEST_SPEC" | "APPIUM_WEB_RUBY_TEST_SPEC" | "INSTRUMENTATION_TEST_SPEC" | "XCTEST_UI_TEST_SPEC" | (string & {});
export declare const UploadType: any;
export type ContentType = string;
export interface CreateUploadRequest {
    projectArn: string;
    name: string;
    type: UploadType;
    contentType?: string;
}
export declare const CreateUploadRequest: S.Schema<CreateUploadRequest>;
export type UploadStatus = "INITIALIZED" | "PROCESSING" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const UploadStatus: any;
export type Metadata = string;
export type UploadCategory = "CURATED" | "PRIVATE" | (string & {});
export declare const UploadCategory: any;
export interface Upload {
    arn?: string;
    name?: string;
    created?: Date;
    type?: UploadType;
    status?: UploadStatus;
    url?: string | redacted.Redacted<string>;
    metadata?: string;
    contentType?: string;
    message?: string;
    category?: UploadCategory;
}
export declare const Upload: S.Schema<Upload>;
export interface CreateUploadResult {
    upload?: Upload;
}
export declare const CreateUploadResult: S.Schema<CreateUploadResult>;
export type VPCEConfigurationName = string;
export type VPCEServiceName = string;
export type ServiceDnsName = string;
export type VPCEConfigurationDescription = string;
export interface CreateVPCEConfigurationRequest {
    vpceConfigurationName: string;
    vpceServiceName: string;
    serviceDnsName: string;
    vpceConfigurationDescription?: string;
}
export declare const CreateVPCEConfigurationRequest: S.Schema<CreateVPCEConfigurationRequest>;
export interface VPCEConfiguration {
    arn?: string;
    vpceConfigurationName?: string;
    vpceServiceName?: string;
    serviceDnsName?: string;
    vpceConfigurationDescription?: string;
}
export declare const VPCEConfiguration: S.Schema<VPCEConfiguration>;
export interface CreateVPCEConfigurationResult {
    vpceConfiguration?: VPCEConfiguration;
}
export declare const CreateVPCEConfigurationResult: S.Schema<CreateVPCEConfigurationResult>;
export interface DeleteDevicePoolRequest {
    arn: string;
}
export declare const DeleteDevicePoolRequest: S.Schema<DeleteDevicePoolRequest>;
export interface DeleteDevicePoolResult {
}
export declare const DeleteDevicePoolResult: S.Schema<DeleteDevicePoolResult>;
export interface DeleteInstanceProfileRequest {
    arn: string;
}
export declare const DeleteInstanceProfileRequest: S.Schema<DeleteInstanceProfileRequest>;
export interface DeleteInstanceProfileResult {
}
export declare const DeleteInstanceProfileResult: S.Schema<DeleteInstanceProfileResult>;
export interface DeleteNetworkProfileRequest {
    arn: string;
}
export declare const DeleteNetworkProfileRequest: S.Schema<DeleteNetworkProfileRequest>;
export interface DeleteNetworkProfileResult {
}
export declare const DeleteNetworkProfileResult: S.Schema<DeleteNetworkProfileResult>;
export interface DeleteProjectRequest {
    arn: string;
}
export declare const DeleteProjectRequest: S.Schema<DeleteProjectRequest>;
export interface DeleteProjectResult {
}
export declare const DeleteProjectResult: S.Schema<DeleteProjectResult>;
export interface DeleteRemoteAccessSessionRequest {
    arn: string;
}
export declare const DeleteRemoteAccessSessionRequest: S.Schema<DeleteRemoteAccessSessionRequest>;
export interface DeleteRemoteAccessSessionResult {
}
export declare const DeleteRemoteAccessSessionResult: S.Schema<DeleteRemoteAccessSessionResult>;
export interface DeleteRunRequest {
    arn: string;
}
export declare const DeleteRunRequest: S.Schema<DeleteRunRequest>;
export interface DeleteRunResult {
}
export declare const DeleteRunResult: S.Schema<DeleteRunResult>;
export interface DeleteTestGridProjectRequest {
    projectArn: string;
}
export declare const DeleteTestGridProjectRequest: S.Schema<DeleteTestGridProjectRequest>;
export interface DeleteTestGridProjectResult {
}
export declare const DeleteTestGridProjectResult: S.Schema<DeleteTestGridProjectResult>;
export interface DeleteUploadRequest {
    arn: string;
}
export declare const DeleteUploadRequest: S.Schema<DeleteUploadRequest>;
export interface DeleteUploadResult {
}
export declare const DeleteUploadResult: S.Schema<DeleteUploadResult>;
export interface DeleteVPCEConfigurationRequest {
    arn: string;
}
export declare const DeleteVPCEConfigurationRequest: S.Schema<DeleteVPCEConfigurationRequest>;
export interface DeleteVPCEConfigurationResult {
}
export declare const DeleteVPCEConfigurationResult: S.Schema<DeleteVPCEConfigurationResult>;
export interface GetAccountSettingsRequest {
}
export declare const GetAccountSettingsRequest: S.Schema<GetAccountSettingsRequest>;
export type AWSAccountNumber = string;
export type PurchasedDevicesMap = {
    [key in DevicePlatform]?: number;
};
export declare const PurchasedDevicesMap: any;
export interface TrialMinutes {
    total?: number;
    remaining?: number;
}
export declare const TrialMinutes: S.Schema<TrialMinutes>;
export type MaxSlotMap = {
    [key: string]: number | undefined;
};
export declare const MaxSlotMap: any;
export interface AccountSettings {
    awsAccountNumber?: string;
    unmeteredDevices?: {
        [key: string]: number | undefined;
    };
    unmeteredRemoteAccessDevices?: {
        [key: string]: number | undefined;
    };
    maxJobTimeoutMinutes?: number;
    trialMinutes?: TrialMinutes;
    maxSlots?: {
        [key: string]: number | undefined;
    };
    defaultJobTimeoutMinutes?: number;
    skipAppResign?: boolean;
}
export declare const AccountSettings: S.Schema<AccountSettings>;
export interface GetAccountSettingsResult {
    accountSettings?: AccountSettings;
}
export declare const GetAccountSettingsResult: S.Schema<GetAccountSettingsResult>;
export interface GetDeviceRequest {
    arn: string;
}
export declare const GetDeviceRequest: S.Schema<GetDeviceRequest>;
export interface GetDeviceResult {
    device?: Device;
}
export declare const GetDeviceResult: S.Schema<GetDeviceResult>;
export interface GetDeviceInstanceRequest {
    arn: string;
}
export declare const GetDeviceInstanceRequest: S.Schema<GetDeviceInstanceRequest>;
export interface GetDeviceInstanceResult {
    deviceInstance?: DeviceInstance;
}
export declare const GetDeviceInstanceResult: S.Schema<GetDeviceInstanceResult>;
export interface GetDevicePoolRequest {
    arn: string;
}
export declare const GetDevicePoolRequest: S.Schema<GetDevicePoolRequest>;
export interface GetDevicePoolResult {
    devicePool?: DevicePool;
}
export declare const GetDevicePoolResult: S.Schema<GetDevicePoolResult>;
export type TestType = "BUILTIN_FUZZ" | "APPIUM_JAVA_JUNIT" | "APPIUM_JAVA_TESTNG" | "APPIUM_PYTHON" | "APPIUM_NODE" | "APPIUM_RUBY" | "APPIUM_WEB_JAVA_JUNIT" | "APPIUM_WEB_JAVA_TESTNG" | "APPIUM_WEB_PYTHON" | "APPIUM_WEB_NODE" | "APPIUM_WEB_RUBY" | "INSTRUMENTATION" | "XCTEST" | "XCTEST_UI" | (string & {});
export declare const TestType: any;
export type Filter = string;
export type TestParameters = {
    [key: string]: string | undefined;
};
export declare const TestParameters: any;
export interface ScheduleRunTest {
    type: TestType;
    testPackageArn?: string;
    testSpecArn?: string;
    filter?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const ScheduleRunTest: S.Schema<ScheduleRunTest>;
export interface Location {
    latitude: number;
    longitude: number;
}
export declare const Location: S.Schema<Location>;
export type IosPaths = string[];
export declare const IosPaths: any;
export type AndroidPaths = string[];
export declare const AndroidPaths: any;
export type DeviceHostPaths = string[];
export declare const DeviceHostPaths: any;
export interface CustomerArtifactPaths {
    iosPaths?: string[];
    androidPaths?: string[];
    deviceHostPaths?: string[];
}
export declare const CustomerArtifactPaths: S.Schema<CustomerArtifactPaths>;
export interface Radios {
    wifi?: boolean;
    bluetooth?: boolean;
    nfc?: boolean;
    gps?: boolean;
}
export declare const Radios: S.Schema<Radios>;
export type InsightsType = "TEST_REPORT" | (string & {});
export declare const InsightsType: any;
export type InsightsTypes = InsightsType[];
export declare const InsightsTypes: any;
export interface ScheduleRunConfiguration {
    extraDataPackageArn?: string;
    networkProfileArn?: string;
    locale?: string;
    location?: Location;
    vpceConfigurationArns?: string[];
    deviceProxy?: DeviceProxy;
    customerArtifactPaths?: CustomerArtifactPaths;
    radios?: Radios;
    auxiliaryApps?: string[];
    billingMethod?: BillingMethod;
    environmentVariables?: EnvironmentVariable[];
    executionRoleArn?: string;
    insightsTypes?: InsightsType[];
}
export declare const ScheduleRunConfiguration: S.Schema<ScheduleRunConfiguration>;
export interface GetDevicePoolCompatibilityRequest {
    devicePoolArn: string;
    appArn?: string;
    testType?: TestType;
    test?: ScheduleRunTest;
    configuration?: ScheduleRunConfiguration;
    projectArn?: string;
}
export declare const GetDevicePoolCompatibilityRequest: S.Schema<GetDevicePoolCompatibilityRequest>;
export interface IncompatibilityMessage {
    message?: string;
    type?: DeviceAttribute;
}
export declare const IncompatibilityMessage: S.Schema<IncompatibilityMessage>;
export type IncompatibilityMessages = IncompatibilityMessage[];
export declare const IncompatibilityMessages: any;
export interface DevicePoolCompatibilityResult {
    device?: Device;
    compatible?: boolean;
    incompatibilityMessages?: IncompatibilityMessage[];
}
export declare const DevicePoolCompatibilityResult: S.Schema<DevicePoolCompatibilityResult>;
export type DevicePoolCompatibilityResults = DevicePoolCompatibilityResult[];
export declare const DevicePoolCompatibilityResults: any;
export interface GetDevicePoolCompatibilityResult {
    compatibleDevices?: DevicePoolCompatibilityResult[];
    incompatibleDevices?: DevicePoolCompatibilityResult[];
}
export declare const GetDevicePoolCompatibilityResult: S.Schema<GetDevicePoolCompatibilityResult>;
export interface GetInstanceProfileRequest {
    arn: string;
}
export declare const GetInstanceProfileRequest: S.Schema<GetInstanceProfileRequest>;
export interface GetInstanceProfileResult {
    instanceProfile?: InstanceProfile;
}
export declare const GetInstanceProfileResult: S.Schema<GetInstanceProfileResult>;
export interface GetJobRequest {
    arn: string;
}
export declare const GetJobRequest: S.Schema<GetJobRequest>;
export interface Counters {
    total?: number;
    passed?: number;
    failed?: number;
    warned?: number;
    errored?: number;
    stopped?: number;
    skipped?: number;
}
export declare const Counters: S.Schema<Counters>;
export type VideoCapture = boolean;
export type ReportStatus = "PENDING" | "RUNNING" | "COMPLETED" | "SKIPPED" | "ERRORED" | (string & {});
export declare const ReportStatus: any;
export type ReportMessage = string;
export interface TestReportMetrics {
    testsTotal?: number;
    testsPassed?: number;
    testsFailed?: number;
    testsSkipped?: number;
    testsErrored?: number;
    testsOther?: number;
    testsPassedPercentage?: number;
    totalTestExecutionDurationSeconds?: number;
    medianTestExecutionDurationSeconds?: number;
}
export declare const TestReportMetrics: S.Schema<TestReportMetrics>;
export interface TestReport {
    message?: string;
    metrics?: TestReportMetrics;
    testDetailsUrl?: string | redacted.Redacted<string>;
}
export declare const TestReport: S.Schema<TestReport>;
export interface JobInsights {
    status?: ReportStatus;
    testReport?: TestReport;
}
export declare const JobInsights: S.Schema<JobInsights>;
export interface Job {
    arn?: string;
    name?: string;
    type?: TestType;
    created?: Date;
    status?: ExecutionStatus;
    result?: ExecutionResult;
    started?: Date;
    stopped?: Date;
    counters?: Counters;
    message?: string;
    device?: Device;
    instanceArn?: string;
    deviceMinutes?: DeviceMinutes;
    videoEndpoint?: string;
    videoCapture?: boolean;
    insights?: JobInsights;
}
export declare const Job: S.Schema<Job>;
export interface GetJobResult {
    job?: Job;
}
export declare const GetJobResult: S.Schema<GetJobResult>;
export interface GetNetworkProfileRequest {
    arn: string;
}
export declare const GetNetworkProfileRequest: S.Schema<GetNetworkProfileRequest>;
export interface GetNetworkProfileResult {
    networkProfile?: NetworkProfile;
}
export declare const GetNetworkProfileResult: S.Schema<GetNetworkProfileResult>;
export type PaginationToken = string;
export interface GetOfferingStatusRequest {
    nextToken?: string;
}
export declare const GetOfferingStatusRequest: S.Schema<GetOfferingStatusRequest>;
export type OfferingIdentifier = string;
export type OfferingTransactionType = "PURCHASE" | "RENEW" | "SYSTEM" | (string & {});
export declare const OfferingTransactionType: any;
export type OfferingType = "RECURRING" | (string & {});
export declare const OfferingType: any;
export type CurrencyCode = "USD" | (string & {});
export declare const CurrencyCode: any;
export interface MonetaryAmount {
    amount?: number;
    currencyCode?: CurrencyCode;
}
export declare const MonetaryAmount: S.Schema<MonetaryAmount>;
export type RecurringChargeFrequency = "MONTHLY" | (string & {});
export declare const RecurringChargeFrequency: any;
export interface RecurringCharge {
    cost?: MonetaryAmount;
    frequency?: RecurringChargeFrequency;
}
export declare const RecurringCharge: S.Schema<RecurringCharge>;
export type RecurringCharges = RecurringCharge[];
export declare const RecurringCharges: any;
export interface Offering {
    id?: string;
    description?: string;
    type?: OfferingType;
    platform?: DevicePlatform;
    recurringCharges?: RecurringCharge[];
}
export declare const Offering: S.Schema<Offering>;
export interface OfferingStatus {
    type?: OfferingTransactionType;
    offering?: Offering;
    quantity?: number;
    effectiveOn?: Date;
}
export declare const OfferingStatus: S.Schema<OfferingStatus>;
export type OfferingStatusMap = {
    [key: string]: OfferingStatus | undefined;
};
export declare const OfferingStatusMap: any;
export interface GetOfferingStatusResult {
    current?: {
        [key: string]: OfferingStatus | undefined;
    };
    nextPeriod?: {
        [key: string]: OfferingStatus | undefined;
    };
    nextToken?: string;
}
export declare const GetOfferingStatusResult: S.Schema<GetOfferingStatusResult>;
export interface GetProjectRequest {
    arn: string;
}
export declare const GetProjectRequest: S.Schema<GetProjectRequest>;
export interface GetProjectResult {
    project?: Project;
}
export declare const GetProjectResult: S.Schema<GetProjectResult>;
export interface GetRemoteAccessSessionRequest {
    arn: string;
}
export declare const GetRemoteAccessSessionRequest: S.Schema<GetRemoteAccessSessionRequest>;
export interface GetRemoteAccessSessionResult {
    remoteAccessSession?: RemoteAccessSession;
}
export declare const GetRemoteAccessSessionResult: S.Schema<GetRemoteAccessSessionResult>;
export interface GetRunRequest {
    arn: string;
}
export declare const GetRunRequest: S.Schema<GetRunRequest>;
export type ExecutionResultCode = "PARSING_FAILED" | "VPC_ENDPOINT_SETUP_FAILED" | (string & {});
export declare const ExecutionResultCode: any;
export type DeviceFilterAttribute = "ARN" | "PLATFORM" | "OS_VERSION" | "MODEL" | "AVAILABILITY" | "FORM_FACTOR" | "MANUFACTURER" | "REMOTE_ACCESS_ENABLED" | "REMOTE_DEBUG_ENABLED" | "INSTANCE_ARN" | "INSTANCE_LABELS" | "FLEET_TYPE" | (string & {});
export declare const DeviceFilterAttribute: any;
export type DeviceFilterValues = string[];
export declare const DeviceFilterValues: any;
export interface DeviceFilter {
    attribute: DeviceFilterAttribute;
    operator: RuleOperator;
    values: string[];
}
export declare const DeviceFilter: S.Schema<DeviceFilter>;
export type DeviceFilters = DeviceFilter[];
export declare const DeviceFilters: any;
export interface DeviceSelectionResult {
    filters?: DeviceFilter[];
    matchedDevicesCount?: number;
    maxDevices?: number;
}
export declare const DeviceSelectionResult: S.Schema<DeviceSelectionResult>;
export interface JobReportMetrics {
    jobsTotal?: number;
    jobsPassed?: number;
    jobsFailed?: number;
    jobsSkipped?: number;
    jobsErrored?: number;
    jobsStopped?: number;
    jobsPassedPercentage?: number;
    totalJobExecutionDurationSeconds?: number;
    averageJobExecutionDurationSeconds?: number;
    medianJobExecutionDurationSeconds?: number;
}
export declare const JobReportMetrics: S.Schema<JobReportMetrics>;
export interface JobReport {
    message?: string;
    metrics?: JobReportMetrics;
    jobDetailsUrl?: string | redacted.Redacted<string>;
}
export declare const JobReport: S.Schema<JobReport>;
export interface RunInsights {
    status?: ReportStatus;
    jobReport?: JobReport;
}
export declare const RunInsights: S.Schema<RunInsights>;
export interface Run {
    arn?: string;
    name?: string;
    type?: TestType;
    platform?: DevicePlatform;
    created?: Date;
    status?: ExecutionStatus;
    result?: ExecutionResult;
    started?: Date;
    stopped?: Date;
    counters?: Counters;
    message?: string;
    totalJobs?: number;
    completedJobs?: number;
    billingMethod?: BillingMethod;
    deviceMinutes?: DeviceMinutes;
    networkProfile?: NetworkProfile;
    deviceProxy?: DeviceProxy;
    parsingResultUrl?: string;
    resultCode?: ExecutionResultCode;
    seed?: number;
    appUpload?: string;
    eventCount?: number;
    jobTimeoutMinutes?: number;
    devicePoolArn?: string;
    locale?: string;
    radios?: Radios;
    location?: Location;
    customerArtifactPaths?: CustomerArtifactPaths;
    webUrl?: string;
    skipAppResign?: boolean;
    testSpecArn?: string;
    deviceSelectionResult?: DeviceSelectionResult;
    vpcConfig?: VpcConfig;
    executionRoleArn?: string;
    environmentVariables?: EnvironmentVariable[];
    insightsTypes?: InsightsType[];
    insights?: RunInsights;
}
export declare const Run: S.Schema<Run>;
export interface GetRunResult {
    run?: Run;
}
export declare const GetRunResult: S.Schema<GetRunResult>;
export interface GetSuiteRequest {
    arn: string;
}
export declare const GetSuiteRequest: S.Schema<GetSuiteRequest>;
export interface Suite {
    arn?: string;
    name?: string;
    type?: TestType;
    created?: Date;
    status?: ExecutionStatus;
    result?: ExecutionResult;
    started?: Date;
    stopped?: Date;
    counters?: Counters;
    message?: string;
    deviceMinutes?: DeviceMinutes;
}
export declare const Suite: S.Schema<Suite>;
export interface GetSuiteResult {
    suite?: Suite;
}
export declare const GetSuiteResult: S.Schema<GetSuiteResult>;
export interface GetTestRequest {
    arn: string;
}
export declare const GetTestRequest: S.Schema<GetTestRequest>;
export interface Test {
    arn?: string;
    name?: string;
    type?: TestType;
    created?: Date;
    status?: ExecutionStatus;
    result?: ExecutionResult;
    started?: Date;
    stopped?: Date;
    counters?: Counters;
    message?: string;
    deviceMinutes?: DeviceMinutes;
}
export declare const Test: S.Schema<Test>;
export interface GetTestResult {
    test?: Test;
}
export declare const GetTestResult: S.Schema<GetTestResult>;
export interface GetTestGridProjectRequest {
    projectArn: string;
}
export declare const GetTestGridProjectRequest: S.Schema<GetTestGridProjectRequest>;
export interface GetTestGridProjectResult {
    testGridProject?: TestGridProject;
}
export declare const GetTestGridProjectResult: S.Schema<GetTestGridProjectResult>;
export type ResourceId = string;
export interface GetTestGridSessionRequest {
    projectArn?: string;
    sessionId?: string;
    sessionArn?: string;
}
export declare const GetTestGridSessionRequest: S.Schema<GetTestGridSessionRequest>;
export type TestGridSessionStatus = "ACTIVE" | "CLOSED" | "ERRORED" | (string & {});
export declare const TestGridSessionStatus: any;
export interface TestGridSession {
    arn?: string;
    status?: TestGridSessionStatus;
    created?: Date;
    ended?: Date;
    billingMinutes?: number;
    seleniumProperties?: string;
}
export declare const TestGridSession: S.Schema<TestGridSession>;
export interface GetTestGridSessionResult {
    testGridSession?: TestGridSession;
}
export declare const GetTestGridSessionResult: S.Schema<GetTestGridSessionResult>;
export interface GetUploadRequest {
    arn: string;
}
export declare const GetUploadRequest: S.Schema<GetUploadRequest>;
export interface GetUploadResult {
    upload?: Upload;
}
export declare const GetUploadResult: S.Schema<GetUploadResult>;
export interface GetVPCEConfigurationRequest {
    arn: string;
}
export declare const GetVPCEConfigurationRequest: S.Schema<GetVPCEConfigurationRequest>;
export interface GetVPCEConfigurationResult {
    vpceConfiguration?: VPCEConfiguration;
}
export declare const GetVPCEConfigurationResult: S.Schema<GetVPCEConfigurationResult>;
export interface InstallToRemoteAccessSessionRequest {
    remoteAccessSessionArn: string;
    appArn: string;
}
export declare const InstallToRemoteAccessSessionRequest: S.Schema<InstallToRemoteAccessSessionRequest>;
export interface InstallToRemoteAccessSessionResult {
    appUpload?: Upload;
}
export declare const InstallToRemoteAccessSessionResult: S.Schema<InstallToRemoteAccessSessionResult>;
export type ArtifactCategory = "SCREENSHOT" | "FILE" | "LOG" | (string & {});
export declare const ArtifactCategory: any;
export interface ListArtifactsRequest {
    arn: string;
    type: ArtifactCategory;
    nextToken?: string;
}
export declare const ListArtifactsRequest: S.Schema<ListArtifactsRequest>;
export type ArtifactType = "UNKNOWN" | "SCREENSHOT" | "DEVICE_LOG" | "MESSAGE_LOG" | "VIDEO_LOG" | "RESULT_LOG" | "SERVICE_LOG" | "WEBKIT_LOG" | "INSTRUMENTATION_OUTPUT" | "EXERCISER_MONKEY_OUTPUT" | "CALABASH_JSON_OUTPUT" | "CALABASH_PRETTY_OUTPUT" | "CALABASH_STANDARD_OUTPUT" | "CALABASH_JAVA_XML_OUTPUT" | "AUTOMATION_OUTPUT" | "APPIUM_SERVER_OUTPUT" | "APPIUM_JAVA_OUTPUT" | "APPIUM_JAVA_XML_OUTPUT" | "APPIUM_PYTHON_OUTPUT" | "APPIUM_PYTHON_XML_OUTPUT" | "EXPLORER_EVENT_LOG" | "EXPLORER_SUMMARY_LOG" | "APPLICATION_CRASH_REPORT" | "XCTEST_LOG" | "VIDEO" | "CUSTOMER_ARTIFACT" | "CUSTOMER_ARTIFACT_LOG" | "TESTSPEC_OUTPUT" | (string & {});
export declare const ArtifactType: any;
export type URL = string;
export interface Artifact {
    arn?: string;
    name?: string;
    type?: ArtifactType;
    extension?: string;
    url?: string;
}
export declare const Artifact: S.Schema<Artifact>;
export type Artifacts = Artifact[];
export declare const Artifacts: any;
export interface ListArtifactsResult {
    artifacts?: Artifact[];
    nextToken?: string;
}
export declare const ListArtifactsResult: S.Schema<ListArtifactsResult>;
export interface ListDeviceInstancesRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDeviceInstancesRequest: S.Schema<ListDeviceInstancesRequest>;
export interface ListDeviceInstancesResult {
    deviceInstances?: DeviceInstance[];
    nextToken?: string;
}
export declare const ListDeviceInstancesResult: S.Schema<ListDeviceInstancesResult>;
export interface ListDevicePoolsRequest {
    arn: string;
    type?: DevicePoolType;
    nextToken?: string;
}
export declare const ListDevicePoolsRequest: S.Schema<ListDevicePoolsRequest>;
export type DevicePools = DevicePool[];
export declare const DevicePools: any;
export interface ListDevicePoolsResult {
    devicePools?: DevicePool[];
    nextToken?: string;
}
export declare const ListDevicePoolsResult: S.Schema<ListDevicePoolsResult>;
export interface ListDevicesRequest {
    arn?: string;
    nextToken?: string;
    filters?: DeviceFilter[];
}
export declare const ListDevicesRequest: S.Schema<ListDevicesRequest>;
export type Devices = Device[];
export declare const Devices: any;
export interface ListDevicesResult {
    devices?: Device[];
    nextToken?: string;
}
export declare const ListDevicesResult: S.Schema<ListDevicesResult>;
export interface ListInstanceProfilesRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListInstanceProfilesRequest: S.Schema<ListInstanceProfilesRequest>;
export type InstanceProfiles = InstanceProfile[];
export declare const InstanceProfiles: any;
export interface ListInstanceProfilesResult {
    instanceProfiles?: InstanceProfile[];
    nextToken?: string;
}
export declare const ListInstanceProfilesResult: S.Schema<ListInstanceProfilesResult>;
export interface ListJobsRequest {
    arn: string;
    nextToken?: string;
}
export declare const ListJobsRequest: S.Schema<ListJobsRequest>;
export type Jobs = Job[];
export declare const Jobs: any;
export interface ListJobsResult {
    jobs?: Job[];
    nextToken?: string;
}
export declare const ListJobsResult: S.Schema<ListJobsResult>;
export interface ListNetworkProfilesRequest {
    arn: string;
    type?: NetworkProfileType;
    nextToken?: string;
}
export declare const ListNetworkProfilesRequest: S.Schema<ListNetworkProfilesRequest>;
export type NetworkProfiles = NetworkProfile[];
export declare const NetworkProfiles: any;
export interface ListNetworkProfilesResult {
    networkProfiles?: NetworkProfile[];
    nextToken?: string;
}
export declare const ListNetworkProfilesResult: S.Schema<ListNetworkProfilesResult>;
export interface ListOfferingPromotionsRequest {
    nextToken?: string;
}
export declare const ListOfferingPromotionsRequest: S.Schema<ListOfferingPromotionsRequest>;
export type OfferingPromotionIdentifier = string;
export interface OfferingPromotion {
    id?: string;
    description?: string;
}
export declare const OfferingPromotion: S.Schema<OfferingPromotion>;
export type OfferingPromotions = OfferingPromotion[];
export declare const OfferingPromotions: any;
export interface ListOfferingPromotionsResult {
    offeringPromotions?: OfferingPromotion[];
    nextToken?: string;
}
export declare const ListOfferingPromotionsResult: S.Schema<ListOfferingPromotionsResult>;
export interface ListOfferingsRequest {
    nextToken?: string;
}
export declare const ListOfferingsRequest: S.Schema<ListOfferingsRequest>;
export type Offerings = Offering[];
export declare const Offerings: any;
export interface ListOfferingsResult {
    offerings?: Offering[];
    nextToken?: string;
}
export declare const ListOfferingsResult: S.Schema<ListOfferingsResult>;
export interface ListOfferingTransactionsRequest {
    nextToken?: string;
}
export declare const ListOfferingTransactionsRequest: S.Schema<ListOfferingTransactionsRequest>;
export type TransactionIdentifier = string;
export interface OfferingTransaction {
    offeringStatus?: OfferingStatus;
    transactionId?: string;
    offeringPromotionId?: string;
    createdOn?: Date;
    cost?: MonetaryAmount;
}
export declare const OfferingTransaction: S.Schema<OfferingTransaction>;
export type OfferingTransactions = OfferingTransaction[];
export declare const OfferingTransactions: any;
export interface ListOfferingTransactionsResult {
    offeringTransactions?: OfferingTransaction[];
    nextToken?: string;
}
export declare const ListOfferingTransactionsResult: S.Schema<ListOfferingTransactionsResult>;
export interface ListProjectsRequest {
    arn?: string;
    nextToken?: string;
}
export declare const ListProjectsRequest: S.Schema<ListProjectsRequest>;
export type Projects = Project[];
export declare const Projects: any;
export interface ListProjectsResult {
    projects?: Project[];
    nextToken?: string;
}
export declare const ListProjectsResult: S.Schema<ListProjectsResult>;
export interface ListRemoteAccessSessionsRequest {
    arn: string;
    nextToken?: string;
}
export declare const ListRemoteAccessSessionsRequest: S.Schema<ListRemoteAccessSessionsRequest>;
export type RemoteAccessSessions = RemoteAccessSession[];
export declare const RemoteAccessSessions: any;
export interface ListRemoteAccessSessionsResult {
    remoteAccessSessions?: RemoteAccessSession[];
    nextToken?: string;
}
export declare const ListRemoteAccessSessionsResult: S.Schema<ListRemoteAccessSessionsResult>;
export interface ListRunsRequest {
    arn: string;
    nextToken?: string;
}
export declare const ListRunsRequest: S.Schema<ListRunsRequest>;
export type Runs = Run[];
export declare const Runs: any;
export interface ListRunsResult {
    runs?: Run[];
    nextToken?: string;
}
export declare const ListRunsResult: S.Schema<ListRunsResult>;
export interface ListSamplesRequest {
    arn: string;
    nextToken?: string;
}
export declare const ListSamplesRequest: S.Schema<ListSamplesRequest>;
export type SampleType = "CPU" | "MEMORY" | "THREADS" | "RX_RATE" | "TX_RATE" | "RX" | "TX" | "NATIVE_FRAMES" | "NATIVE_FPS" | "NATIVE_MIN_DRAWTIME" | "NATIVE_AVG_DRAWTIME" | "NATIVE_MAX_DRAWTIME" | "OPENGL_FRAMES" | "OPENGL_FPS" | "OPENGL_MIN_DRAWTIME" | "OPENGL_AVG_DRAWTIME" | "OPENGL_MAX_DRAWTIME" | (string & {});
export declare const SampleType: any;
export interface Sample {
    arn?: string;
    type?: SampleType;
    url?: string;
}
export declare const Sample: S.Schema<Sample>;
export type Samples = Sample[];
export declare const Samples: any;
export interface ListSamplesResult {
    samples?: Sample[];
    nextToken?: string;
}
export declare const ListSamplesResult: S.Schema<ListSamplesResult>;
export interface ListSuitesRequest {
    arn: string;
    nextToken?: string;
}
export declare const ListSuitesRequest: S.Schema<ListSuitesRequest>;
export type Suites = Suite[];
export declare const Suites: any;
export interface ListSuitesResult {
    suites?: Suite[];
    nextToken?: string;
}
export declare const ListSuitesResult: S.Schema<ListSuitesResult>;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type MaxPageSize = number;
export interface ListTestGridProjectsRequest {
    maxResult?: number;
    nextToken?: string;
}
export declare const ListTestGridProjectsRequest: S.Schema<ListTestGridProjectsRequest>;
export type TestGridProjects = TestGridProject[];
export declare const TestGridProjects: any;
export interface ListTestGridProjectsResult {
    testGridProjects?: TestGridProject[];
    nextToken?: string;
}
export declare const ListTestGridProjectsResult: S.Schema<ListTestGridProjectsResult>;
export interface ListTestGridSessionActionsRequest {
    sessionArn: string;
    maxResult?: number;
    nextToken?: string;
}
export declare const ListTestGridSessionActionsRequest: S.Schema<ListTestGridSessionActionsRequest>;
export interface TestGridSessionAction {
    action?: string;
    started?: Date;
    duration?: number;
    statusCode?: string;
    requestMethod?: string;
}
export declare const TestGridSessionAction: S.Schema<TestGridSessionAction>;
export type TestGridSessionActions = TestGridSessionAction[];
export declare const TestGridSessionActions: any;
export interface ListTestGridSessionActionsResult {
    actions?: TestGridSessionAction[];
    nextToken?: string;
}
export declare const ListTestGridSessionActionsResult: S.Schema<ListTestGridSessionActionsResult>;
export type TestGridSessionArtifactCategory = "VIDEO" | "LOG" | (string & {});
export declare const TestGridSessionArtifactCategory: any;
export interface ListTestGridSessionArtifactsRequest {
    sessionArn: string;
    type?: TestGridSessionArtifactCategory;
    maxResult?: number;
    nextToken?: string;
}
export declare const ListTestGridSessionArtifactsRequest: S.Schema<ListTestGridSessionArtifactsRequest>;
export type TestGridSessionArtifactType = "UNKNOWN" | "VIDEO" | "SELENIUM_LOG" | (string & {});
export declare const TestGridSessionArtifactType: any;
export interface TestGridSessionArtifact {
    filename?: string;
    type?: TestGridSessionArtifactType;
    url?: string | redacted.Redacted<string>;
}
export declare const TestGridSessionArtifact: S.Schema<TestGridSessionArtifact>;
export type TestGridSessionArtifacts = TestGridSessionArtifact[];
export declare const TestGridSessionArtifacts: any;
export interface ListTestGridSessionArtifactsResult {
    artifacts?: TestGridSessionArtifact[];
    nextToken?: string;
}
export declare const ListTestGridSessionArtifactsResult: S.Schema<ListTestGridSessionArtifactsResult>;
export interface ListTestGridSessionsRequest {
    projectArn: string;
    status?: TestGridSessionStatus;
    creationTimeAfter?: Date;
    creationTimeBefore?: Date;
    endTimeAfter?: Date;
    endTimeBefore?: Date;
    maxResult?: number;
    nextToken?: string;
}
export declare const ListTestGridSessionsRequest: S.Schema<ListTestGridSessionsRequest>;
export type TestGridSessions = TestGridSession[];
export declare const TestGridSessions: any;
export interface ListTestGridSessionsResult {
    testGridSessions?: TestGridSession[];
    nextToken?: string;
}
export declare const ListTestGridSessionsResult: S.Schema<ListTestGridSessionsResult>;
export interface ListTestsRequest {
    arn: string;
    nextToken?: string;
}
export declare const ListTestsRequest: S.Schema<ListTestsRequest>;
export type Tests = Test[];
export declare const Tests: any;
export interface ListTestsResult {
    tests?: Test[];
    nextToken?: string;
}
export declare const ListTestsResult: S.Schema<ListTestsResult>;
export interface ListUniqueProblemsRequest {
    arn: string;
    nextToken?: string;
}
export declare const ListUniqueProblemsRequest: S.Schema<ListUniqueProblemsRequest>;
export interface ProblemDetail {
    arn?: string;
    name?: string;
}
export declare const ProblemDetail: S.Schema<ProblemDetail>;
export interface Problem {
    run?: ProblemDetail;
    job?: ProblemDetail;
    suite?: ProblemDetail;
    test?: ProblemDetail;
    device?: Device;
    result?: ExecutionResult;
    message?: string;
}
export declare const Problem: S.Schema<Problem>;
export type Problems = Problem[];
export declare const Problems: any;
export interface UniqueProblem {
    message?: string;
    problems?: Problem[];
}
export declare const UniqueProblem: S.Schema<UniqueProblem>;
export type UniqueProblems = UniqueProblem[];
export declare const UniqueProblems: any;
export type UniqueProblemsByExecutionResultMap = {
    [key in ExecutionResult]?: UniqueProblem[];
};
export declare const UniqueProblemsByExecutionResultMap: any;
export interface ListUniqueProblemsResult {
    uniqueProblems?: {
        [key: string]: UniqueProblem[] | undefined;
    };
    nextToken?: string;
}
export declare const ListUniqueProblemsResult: S.Schema<ListUniqueProblemsResult>;
export interface ListUploadsRequest {
    arn: string;
    type?: UploadType;
    nextToken?: string;
}
export declare const ListUploadsRequest: S.Schema<ListUploadsRequest>;
export type Uploads = Upload[];
export declare const Uploads: any;
export interface ListUploadsResult {
    uploads?: Upload[];
    nextToken?: string;
}
export declare const ListUploadsResult: S.Schema<ListUploadsResult>;
export interface ListVPCEConfigurationsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListVPCEConfigurationsRequest: S.Schema<ListVPCEConfigurationsRequest>;
export type VPCEConfigurations = VPCEConfiguration[];
export declare const VPCEConfigurations: any;
export interface ListVPCEConfigurationsResult {
    vpceConfigurations?: VPCEConfiguration[];
    nextToken?: string;
}
export declare const ListVPCEConfigurationsResult: S.Schema<ListVPCEConfigurationsResult>;
export interface PurchaseOfferingRequest {
    offeringId: string;
    quantity: number;
    offeringPromotionId?: string;
}
export declare const PurchaseOfferingRequest: S.Schema<PurchaseOfferingRequest>;
export interface PurchaseOfferingResult {
    offeringTransaction?: OfferingTransaction;
}
export declare const PurchaseOfferingResult: S.Schema<PurchaseOfferingResult>;
export interface RenewOfferingRequest {
    offeringId: string;
    quantity: number;
}
export declare const RenewOfferingRequest: S.Schema<RenewOfferingRequest>;
export interface RenewOfferingResult {
    offeringTransaction?: OfferingTransaction;
}
export declare const RenewOfferingResult: S.Schema<RenewOfferingResult>;
export interface DeviceSelectionConfiguration {
    filters: DeviceFilter[];
    maxDevices: number;
}
export declare const DeviceSelectionConfiguration: S.Schema<DeviceSelectionConfiguration>;
export type AccountsCleanup = boolean;
export type AppPackagesCleanup = boolean;
export interface ExecutionConfiguration {
    jobTimeoutMinutes?: number;
    accountsCleanup?: boolean;
    appPackagesCleanup?: boolean;
    videoCapture?: boolean;
    skipAppResign?: boolean;
}
export declare const ExecutionConfiguration: S.Schema<ExecutionConfiguration>;
export interface ScheduleRunRequest {
    projectArn: string;
    appArn?: string;
    devicePoolArn?: string;
    deviceSelectionConfiguration?: DeviceSelectionConfiguration;
    name?: string;
    test: ScheduleRunTest;
    configuration?: ScheduleRunConfiguration;
    executionConfiguration?: ExecutionConfiguration;
}
export declare const ScheduleRunRequest: S.Schema<ScheduleRunRequest>;
export interface ScheduleRunResult {
    run?: Run;
}
export declare const ScheduleRunResult: S.Schema<ScheduleRunResult>;
export interface StopJobRequest {
    arn: string;
}
export declare const StopJobRequest: S.Schema<StopJobRequest>;
export interface StopJobResult {
    job?: Job;
}
export declare const StopJobResult: S.Schema<StopJobResult>;
export interface StopRemoteAccessSessionRequest {
    arn: string;
}
export declare const StopRemoteAccessSessionRequest: S.Schema<StopRemoteAccessSessionRequest>;
export interface StopRemoteAccessSessionResult {
    remoteAccessSession?: RemoteAccessSession;
}
export declare const StopRemoteAccessSessionResult: S.Schema<StopRemoteAccessSessionResult>;
export interface StopRunRequest {
    arn: string;
}
export declare const StopRunRequest: S.Schema<StopRunRequest>;
export interface StopRunResult {
    run?: Run;
}
export declare const StopRunResult: S.Schema<StopRunResult>;
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateDeviceInstanceRequest {
    arn: string;
    profileArn?: string;
    labels?: string[];
}
export declare const UpdateDeviceInstanceRequest: S.Schema<UpdateDeviceInstanceRequest>;
export interface UpdateDeviceInstanceResult {
    deviceInstance?: DeviceInstance;
}
export declare const UpdateDeviceInstanceResult: S.Schema<UpdateDeviceInstanceResult>;
export interface UpdateDevicePoolRequest {
    arn: string;
    name?: string;
    description?: string;
    rules?: Rule[];
    maxDevices?: number;
    clearMaxDevices?: boolean;
}
export declare const UpdateDevicePoolRequest: S.Schema<UpdateDevicePoolRequest>;
export interface UpdateDevicePoolResult {
    devicePool?: DevicePool;
}
export declare const UpdateDevicePoolResult: S.Schema<UpdateDevicePoolResult>;
export interface UpdateInstanceProfileRequest {
    arn: string;
    name?: string;
    description?: string;
    packageCleanup?: boolean;
    excludeAppPackagesFromCleanup?: string[];
    rebootAfterUse?: boolean;
}
export declare const UpdateInstanceProfileRequest: S.Schema<UpdateInstanceProfileRequest>;
export interface UpdateInstanceProfileResult {
    instanceProfile?: InstanceProfile;
}
export declare const UpdateInstanceProfileResult: S.Schema<UpdateInstanceProfileResult>;
export interface UpdateNetworkProfileRequest {
    arn: string;
    name?: string;
    description?: string;
    type?: NetworkProfileType;
    uplinkBandwidthBits?: number;
    downlinkBandwidthBits?: number;
    uplinkDelayMs?: number;
    downlinkDelayMs?: number;
    uplinkJitterMs?: number;
    downlinkJitterMs?: number;
    uplinkLossPercent?: number;
    downlinkLossPercent?: number;
}
export declare const UpdateNetworkProfileRequest: S.Schema<UpdateNetworkProfileRequest>;
export interface UpdateNetworkProfileResult {
    networkProfile?: NetworkProfile;
}
export declare const UpdateNetworkProfileResult: S.Schema<UpdateNetworkProfileResult>;
export interface UpdateProjectRequest {
    arn: string;
    name?: string;
    defaultJobTimeoutMinutes?: number;
    vpcConfig?: VpcConfig;
    environmentVariables?: EnvironmentVariable[];
    executionRoleArn?: string;
}
export declare const UpdateProjectRequest: S.Schema<UpdateProjectRequest>;
export interface UpdateProjectResult {
    project?: Project;
}
export declare const UpdateProjectResult: S.Schema<UpdateProjectResult>;
export interface UpdateTestGridProjectRequest {
    projectArn: string;
    name?: string;
    description?: string;
    vpcConfig?: TestGridVpcConfig;
}
export declare const UpdateTestGridProjectRequest: S.Schema<UpdateTestGridProjectRequest>;
export interface UpdateTestGridProjectResult {
    testGridProject?: TestGridProject;
}
export declare const UpdateTestGridProjectResult: S.Schema<UpdateTestGridProjectResult>;
export interface UpdateUploadRequest {
    arn: string;
    name?: string;
    contentType?: string;
    editContent?: boolean;
}
export declare const UpdateUploadRequest: S.Schema<UpdateUploadRequest>;
export interface UpdateUploadResult {
    upload?: Upload;
}
export declare const UpdateUploadResult: S.Schema<UpdateUploadResult>;
export interface UpdateVPCEConfigurationRequest {
    arn: string;
    vpceConfigurationName?: string;
    vpceServiceName?: string;
    serviceDnsName?: string;
    vpceConfigurationDescription?: string;
}
export declare const UpdateVPCEConfigurationRequest: S.Schema<UpdateVPCEConfigurationRequest>;
export interface UpdateVPCEConfigurationResult {
    vpceConfiguration?: VPCEConfiguration;
}
export declare const UpdateVPCEConfigurationResult: S.Schema<UpdateVPCEConfigurationResult>;
export type ExceptionMessage = string;
export type CreateDevicePoolError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Creates a device pool.
 */
export declare const createDevicePool: API.OperationMethod<CreateDevicePoolRequest, CreateDevicePoolResult, CreateDevicePoolError, Credentials | HttpClient.HttpClient>;
export type CreateInstanceProfileError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Creates a profile that can be applied to one or more private fleet device
 * instances.
 */
export declare const createInstanceProfile: API.OperationMethod<CreateInstanceProfileRequest, CreateInstanceProfileResult, CreateInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type CreateNetworkProfileError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Creates a network profile.
 */
export declare const createNetworkProfile: API.OperationMethod<CreateNetworkProfileRequest, CreateNetworkProfileResult, CreateNetworkProfileError, Credentials | HttpClient.HttpClient>;
export type CreateProjectError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | TagOperationException | CommonErrors;
/**
 * Creates a project.
 */
export declare const createProject: API.OperationMethod<CreateProjectRequest, CreateProjectResult, CreateProjectError, Credentials | HttpClient.HttpClient>;
export type CreateRemoteAccessSessionError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Specifies and starts a remote access session.
 */
export declare const createRemoteAccessSession: API.OperationMethod<CreateRemoteAccessSessionRequest, CreateRemoteAccessSessionResult, CreateRemoteAccessSessionError, Credentials | HttpClient.HttpClient>;
export type CreateTestGridProjectError = ArgumentException | InternalServiceException | LimitExceededException | CommonErrors;
/**
 * Creates a Selenium testing project. Projects are used to track TestGridSession
 * instances.
 */
export declare const createTestGridProject: API.OperationMethod<CreateTestGridProjectRequest, CreateTestGridProjectResult, CreateTestGridProjectError, Credentials | HttpClient.HttpClient>;
export type CreateTestGridUrlError = ArgumentException | InternalServiceException | NotFoundException | CommonErrors;
/**
 * Creates a signed, short-term URL that can be passed to a Selenium `RemoteWebDriver`
 * constructor.
 */
export declare const createTestGridUrl: API.OperationMethod<CreateTestGridUrlRequest, CreateTestGridUrlResult, CreateTestGridUrlError, Credentials | HttpClient.HttpClient>;
export type CreateUploadError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Uploads an app or test scripts.
 */
export declare const createUpload: API.OperationMethod<CreateUploadRequest, CreateUploadResult, CreateUploadError, Credentials | HttpClient.HttpClient>;
export type CreateVPCEConfigurationError = ArgumentException | LimitExceededException | ServiceAccountException | CommonErrors;
/**
 * Creates a configuration record in Device Farm for your Amazon Virtual Private Cloud
 * (VPC) endpoint.
 */
export declare const createVPCEConfiguration: API.OperationMethod<CreateVPCEConfigurationRequest, CreateVPCEConfigurationResult, CreateVPCEConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteDevicePoolError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Deletes a device pool given the pool ARN. Does not allow deletion of curated pools
 * owned by the system.
 */
export declare const deleteDevicePool: API.OperationMethod<DeleteDevicePoolRequest, DeleteDevicePoolResult, DeleteDevicePoolError, Credentials | HttpClient.HttpClient>;
export type DeleteInstanceProfileError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Deletes a profile that can be applied to one or more private device instances.
 */
export declare const deleteInstanceProfile: API.OperationMethod<DeleteInstanceProfileRequest, DeleteInstanceProfileResult, DeleteInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteNetworkProfileError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Deletes a network profile.
 */
export declare const deleteNetworkProfile: API.OperationMethod<DeleteNetworkProfileRequest, DeleteNetworkProfileResult, DeleteNetworkProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Deletes an AWS Device Farm project, given the project ARN. You cannot delete a project if it has an active run or session.
 *
 * You cannot undo this operation.
 */
export declare const deleteProject: API.OperationMethod<DeleteProjectRequest, DeleteProjectResult, DeleteProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteRemoteAccessSessionError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Deletes a completed remote access session and its results. You cannot delete a remote access session if it is still active.
 *
 * You cannot undo this operation.
 */
export declare const deleteRemoteAccessSession: API.OperationMethod<DeleteRemoteAccessSessionRequest, DeleteRemoteAccessSessionResult, DeleteRemoteAccessSessionError, Credentials | HttpClient.HttpClient>;
export type DeleteRunError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Deletes the run, given the run ARN. You cannot delete a run if it is still active.
 *
 * You cannot undo this operation.
 */
export declare const deleteRun: API.OperationMethod<DeleteRunRequest, DeleteRunResult, DeleteRunError, Credentials | HttpClient.HttpClient>;
export type DeleteTestGridProjectError = ArgumentException | CannotDeleteException | InternalServiceException | NotFoundException | CommonErrors;
/**
 * Deletes a Selenium testing project and all content generated under it. You cannot delete a project if it has active sessions.
 *
 * You cannot undo this operation.
 */
export declare const deleteTestGridProject: API.OperationMethod<DeleteTestGridProjectRequest, DeleteTestGridProjectResult, DeleteTestGridProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteUploadError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Deletes an upload given the upload ARN.
 */
export declare const deleteUpload: API.OperationMethod<DeleteUploadRequest, DeleteUploadResult, DeleteUploadError, Credentials | HttpClient.HttpClient>;
export type DeleteVPCEConfigurationError = ArgumentException | InvalidOperationException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Deletes a configuration for your Amazon Virtual Private Cloud (VPC) endpoint.
 */
export declare const deleteVPCEConfiguration: API.OperationMethod<DeleteVPCEConfigurationRequest, DeleteVPCEConfigurationResult, DeleteVPCEConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetAccountSettingsError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Returns the number of unmetered iOS or unmetered Android devices that have been purchased by the
 * account.
 */
export declare const getAccountSettings: API.OperationMethod<GetAccountSettingsRequest, GetAccountSettingsResult, GetAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type GetDeviceError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about a unique device type.
 */
export declare const getDevice: API.OperationMethod<GetDeviceRequest, GetDeviceResult, GetDeviceError, Credentials | HttpClient.HttpClient>;
export type GetDeviceInstanceError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Returns information about a device instance that belongs to a private device fleet.
 */
export declare const getDeviceInstance: API.OperationMethod<GetDeviceInstanceRequest, GetDeviceInstanceResult, GetDeviceInstanceError, Credentials | HttpClient.HttpClient>;
export type GetDevicePoolError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about a device pool.
 */
export declare const getDevicePool: API.OperationMethod<GetDevicePoolRequest, GetDevicePoolResult, GetDevicePoolError, Credentials | HttpClient.HttpClient>;
export type GetDevicePoolCompatibilityError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about compatibility with a device pool.
 */
export declare const getDevicePoolCompatibility: API.OperationMethod<GetDevicePoolCompatibilityRequest, GetDevicePoolCompatibilityResult, GetDevicePoolCompatibilityError, Credentials | HttpClient.HttpClient>;
export type GetInstanceProfileError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Returns information about the specified instance profile.
 */
export declare const getInstanceProfile: API.OperationMethod<GetInstanceProfileRequest, GetInstanceProfileResult, GetInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type GetJobError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about a job.
 */
export declare const getJob: API.OperationMethod<GetJobRequest, GetJobResult, GetJobError, Credentials | HttpClient.HttpClient>;
export type GetNetworkProfileError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Returns information about a network profile.
 */
export declare const getNetworkProfile: API.OperationMethod<GetNetworkProfileRequest, GetNetworkProfileResult, GetNetworkProfileError, Credentials | HttpClient.HttpClient>;
export type GetOfferingStatusError = ArgumentException | LimitExceededException | NotEligibleException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets the current status and future status of all offerings purchased by an AWS account. The response
 * indicates how many offerings are currently available and the offerings that will be available in the next
 * period. The API returns a `NotEligible` error if the user is not permitted to invoke the
 * operation. If you must be able to invoke this operation, contact aws-devicefarm-support@amazon.com.
 */
export declare const getOfferingStatus: API.PaginatedOperationMethod<GetOfferingStatusRequest, GetOfferingStatusResult, GetOfferingStatusError, Credentials | HttpClient.HttpClient, unknown>;
export type GetProjectError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about a project.
 */
export declare const getProject: API.OperationMethod<GetProjectRequest, GetProjectResult, GetProjectError, Credentials | HttpClient.HttpClient>;
export type GetRemoteAccessSessionError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Returns a link to a currently running remote access session.
 */
export declare const getRemoteAccessSession: API.OperationMethod<GetRemoteAccessSessionRequest, GetRemoteAccessSessionResult, GetRemoteAccessSessionError, Credentials | HttpClient.HttpClient>;
export type GetRunError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about a run.
 */
export declare const getRun: API.OperationMethod<GetRunRequest, GetRunResult, GetRunError, Credentials | HttpClient.HttpClient>;
export type GetSuiteError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about a suite.
 */
export declare const getSuite: API.OperationMethod<GetSuiteRequest, GetSuiteResult, GetSuiteError, Credentials | HttpClient.HttpClient>;
export type GetTestError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about a test.
 */
export declare const getTest: API.OperationMethod<GetTestRequest, GetTestResult, GetTestError, Credentials | HttpClient.HttpClient>;
export type GetTestGridProjectError = ArgumentException | InternalServiceException | NotFoundException | CommonErrors;
/**
 * Retrieves information about a Selenium testing project.
 */
export declare const getTestGridProject: API.OperationMethod<GetTestGridProjectRequest, GetTestGridProjectResult, GetTestGridProjectError, Credentials | HttpClient.HttpClient>;
export type GetTestGridSessionError = ArgumentException | InternalServiceException | NotFoundException | CommonErrors;
/**
 * A session is an instance of a browser created through a `RemoteWebDriver` with the URL from
 * CreateTestGridUrlResult. You can use the following to look up sessions:
 *
 * - The session ARN.
 *
 * - The project ARN and a session ID.
 */
export declare const getTestGridSession: API.OperationMethod<GetTestGridSessionRequest, GetTestGridSessionResult, GetTestGridSessionError, Credentials | HttpClient.HttpClient>;
export type GetUploadError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about an upload.
 */
export declare const getUpload: API.OperationMethod<GetUploadRequest, GetUploadResult, GetUploadError, Credentials | HttpClient.HttpClient>;
export type GetVPCEConfigurationError = ArgumentException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Returns information about the configuration settings for your Amazon Virtual Private
 * Cloud (VPC) endpoint.
 */
export declare const getVPCEConfiguration: API.OperationMethod<GetVPCEConfigurationRequest, GetVPCEConfigurationResult, GetVPCEConfigurationError, Credentials | HttpClient.HttpClient>;
export type InstallToRemoteAccessSessionError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Installs an application to the device in a remote access session. For Android
 * applications, the file must be in .apk format. For iOS applications, the file must be in
 * .ipa format.
 */
export declare const installToRemoteAccessSession: API.OperationMethod<InstallToRemoteAccessSessionRequest, InstallToRemoteAccessSessionResult, InstallToRemoteAccessSessionError, Credentials | HttpClient.HttpClient>;
export type ListArtifactsError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about artifacts.
 */
export declare const listArtifacts: API.PaginatedOperationMethod<ListArtifactsRequest, ListArtifactsResult, ListArtifactsError, Credentials | HttpClient.HttpClient, Artifact>;
export type ListDeviceInstancesError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Returns information about the private device instances associated with one or more AWS
 * accounts.
 */
export declare const listDeviceInstances: API.OperationMethod<ListDeviceInstancesRequest, ListDeviceInstancesResult, ListDeviceInstancesError, Credentials | HttpClient.HttpClient>;
export type ListDevicePoolsError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about device pools.
 */
export declare const listDevicePools: API.PaginatedOperationMethod<ListDevicePoolsRequest, ListDevicePoolsResult, ListDevicePoolsError, Credentials | HttpClient.HttpClient, DevicePool>;
export type ListDevicesError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about unique device types.
 */
export declare const listDevices: API.PaginatedOperationMethod<ListDevicesRequest, ListDevicesResult, ListDevicesError, Credentials | HttpClient.HttpClient, Device>;
export type ListInstanceProfilesError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Returns information about all the instance profiles in an AWS account.
 */
export declare const listInstanceProfiles: API.OperationMethod<ListInstanceProfilesRequest, ListInstanceProfilesResult, ListInstanceProfilesError, Credentials | HttpClient.HttpClient>;
export type ListJobsError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about jobs for a given test run.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest, ListJobsResult, ListJobsError, Credentials | HttpClient.HttpClient, Job>;
export type ListNetworkProfilesError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Returns the list of available network profiles.
 */
export declare const listNetworkProfiles: API.OperationMethod<ListNetworkProfilesRequest, ListNetworkProfilesResult, ListNetworkProfilesError, Credentials | HttpClient.HttpClient>;
export type ListOfferingPromotionsError = ArgumentException | LimitExceededException | NotEligibleException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Returns a list of offering promotions. Each offering promotion record contains the ID and description
 * of the promotion. The API returns a `NotEligible` error if the caller is not permitted to invoke
 * the operation. Contact aws-devicefarm-support@amazon.com if you must be able to invoke this operation.
 */
export declare const listOfferingPromotions: API.OperationMethod<ListOfferingPromotionsRequest, ListOfferingPromotionsResult, ListOfferingPromotionsError, Credentials | HttpClient.HttpClient>;
export type ListOfferingsError = ArgumentException | LimitExceededException | NotEligibleException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Returns a list of products or offerings that the user can manage through the API. Each offering record
 * indicates the recurring price per unit and the frequency for that offering. The API returns a
 * `NotEligible` error if the user is not permitted to invoke the operation. If you must be
 * able to invoke this operation, contact aws-devicefarm-support@amazon.com.
 */
export declare const listOfferings: API.PaginatedOperationMethod<ListOfferingsRequest, ListOfferingsResult, ListOfferingsError, Credentials | HttpClient.HttpClient, Offering>;
export type ListOfferingTransactionsError = ArgumentException | LimitExceededException | NotEligibleException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Returns a list of all historical purchases, renewals, and system renewal transactions for an AWS
 * account. The list is paginated and ordered by a descending timestamp (most recent transactions are first).
 * The API returns a `NotEligible` error if the user is not permitted to invoke the operation. If
 * you must be able to invoke this operation, contact aws-devicefarm-support@amazon.com.
 */
export declare const listOfferingTransactions: API.PaginatedOperationMethod<ListOfferingTransactionsRequest, ListOfferingTransactionsResult, ListOfferingTransactionsError, Credentials | HttpClient.HttpClient, OfferingTransaction>;
export type ListProjectsError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about projects.
 */
export declare const listProjects: API.PaginatedOperationMethod<ListProjectsRequest, ListProjectsResult, ListProjectsError, Credentials | HttpClient.HttpClient, Project>;
export type ListRemoteAccessSessionsError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Returns a list of all currently running remote access sessions.
 */
export declare const listRemoteAccessSessions: API.OperationMethod<ListRemoteAccessSessionsRequest, ListRemoteAccessSessionsResult, ListRemoteAccessSessionsError, Credentials | HttpClient.HttpClient>;
export type ListRunsError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about runs, given an AWS Device Farm project ARN.
 */
export declare const listRuns: API.PaginatedOperationMethod<ListRunsRequest, ListRunsResult, ListRunsError, Credentials | HttpClient.HttpClient, Run>;
export type ListSamplesError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about samples, given an AWS Device Farm job ARN.
 *
 * Device Farm does not support performance data samples during test executions.
 */
export declare const listSamples: API.PaginatedOperationMethod<ListSamplesRequest, ListSamplesResult, ListSamplesError, Credentials | HttpClient.HttpClient, Sample>;
export type ListSuitesError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about test suites for a given job.
 */
export declare const listSuites: API.PaginatedOperationMethod<ListSuitesRequest, ListSuitesResult, ListSuitesError, Credentials | HttpClient.HttpClient, Suite>;
export type ListTagsForResourceError = ArgumentException | NotFoundException | TagOperationException | CommonErrors;
/**
 * List the tags for an AWS Device Farm resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTestGridProjectsError = ArgumentException | InternalServiceException | CommonErrors;
/**
 * Gets a list of all Selenium testing projects in your account.
 */
export declare const listTestGridProjects: API.PaginatedOperationMethod<ListTestGridProjectsRequest, ListTestGridProjectsResult, ListTestGridProjectsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTestGridSessionActionsError = ArgumentException | InternalServiceException | NotFoundException | CommonErrors;
/**
 * Returns a list of the actions taken in a TestGridSession.
 */
export declare const listTestGridSessionActions: API.PaginatedOperationMethod<ListTestGridSessionActionsRequest, ListTestGridSessionActionsResult, ListTestGridSessionActionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTestGridSessionArtifactsError = ArgumentException | InternalServiceException | NotFoundException | CommonErrors;
/**
 * Retrieves a list of artifacts created during the session.
 */
export declare const listTestGridSessionArtifacts: API.PaginatedOperationMethod<ListTestGridSessionArtifactsRequest, ListTestGridSessionArtifactsResult, ListTestGridSessionArtifactsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTestGridSessionsError = ArgumentException | InternalServiceException | NotFoundException | CommonErrors;
/**
 * Retrieves a list of sessions for a TestGridProject.
 */
export declare const listTestGridSessions: API.PaginatedOperationMethod<ListTestGridSessionsRequest, ListTestGridSessionsResult, ListTestGridSessionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTestsError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about tests in a given test suite.
 */
export declare const listTests: API.PaginatedOperationMethod<ListTestsRequest, ListTestsResult, ListTestsError, Credentials | HttpClient.HttpClient, Test>;
export type ListUniqueProblemsError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about unique problems, such as exceptions or crashes.
 *
 * Unique problems are defined as a single instance of an error across a run, job, or suite. For example,
 * if a call in your application consistently raises an exception (OutOfBoundsException in
 * MyActivity.java:386), `ListUniqueProblems` returns a single entry instead of many
 * individual entries for that exception.
 */
export declare const listUniqueProblems: API.PaginatedOperationMethod<ListUniqueProblemsRequest, ListUniqueProblemsResult, ListUniqueProblemsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListUploadsError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Gets information about uploads, given an AWS Device Farm project ARN.
 */
export declare const listUploads: API.PaginatedOperationMethod<ListUploadsRequest, ListUploadsResult, ListUploadsError, Credentials | HttpClient.HttpClient, Upload>;
export type ListVPCEConfigurationsError = ArgumentException | ServiceAccountException | CommonErrors;
/**
 * Returns information about all Amazon Virtual Private Cloud (VPC) endpoint
 * configurations in the AWS account.
 */
export declare const listVPCEConfigurations: API.OperationMethod<ListVPCEConfigurationsRequest, ListVPCEConfigurationsResult, ListVPCEConfigurationsError, Credentials | HttpClient.HttpClient>;
export type PurchaseOfferingError = ArgumentException | LimitExceededException | NotEligibleException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Immediately purchases offerings for an AWS account. Offerings renew with the latest total purchased
 * quantity for an offering, unless the renewal was overridden. The API returns a `NotEligible`
 * error if the user is not permitted to invoke the operation. If you must be able to invoke this operation,
 * contact aws-devicefarm-support@amazon.com.
 */
export declare const purchaseOffering: API.OperationMethod<PurchaseOfferingRequest, PurchaseOfferingResult, PurchaseOfferingError, Credentials | HttpClient.HttpClient>;
export type RenewOfferingError = ArgumentException | LimitExceededException | NotEligibleException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Explicitly sets the quantity of devices to renew for an offering, starting from the
 * `effectiveDate` of the next period. The API returns a `NotEligible` error if the
 * user is not permitted to invoke the operation. If you must be able to invoke this operation, contact aws-devicefarm-support@amazon.com.
 */
export declare const renewOffering: API.OperationMethod<RenewOfferingRequest, RenewOfferingResult, RenewOfferingError, Credentials | HttpClient.HttpClient>;
export type ScheduleRunError = ArgumentException | IdempotencyException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Schedules a run.
 */
export declare const scheduleRun: API.OperationMethod<ScheduleRunRequest, ScheduleRunResult, ScheduleRunError, Credentials | HttpClient.HttpClient>;
export type StopJobError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Initiates a stop request for the current job. AWS Device Farm immediately stops the job on the device
 * where tests have not started. You are not billed for this device. On the device where tests have started,
 * setup suite and teardown suite tests run to completion on the device. You are billed for setup, teardown,
 * and any tests that were in progress or already completed.
 */
export declare const stopJob: API.OperationMethod<StopJobRequest, StopJobResult, StopJobError, Credentials | HttpClient.HttpClient>;
export type StopRemoteAccessSessionError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Ends a specified remote access session.
 */
export declare const stopRemoteAccessSession: API.OperationMethod<StopRemoteAccessSessionRequest, StopRemoteAccessSessionResult, StopRemoteAccessSessionError, Credentials | HttpClient.HttpClient>;
export type StopRunError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Initiates a stop request for the current test run. AWS Device Farm immediately stops the run on devices
 * where tests have not started. You are not billed for these devices. On devices where tests have started
 * executing, setup suite and teardown suite tests run to completion on those devices. You are billed for
 * setup, teardown, and any tests that were in progress or already completed.
 */
export declare const stopRun: API.OperationMethod<StopRunRequest, StopRunResult, StopRunError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ArgumentException | NotFoundException | TagOperationException | TagPolicyException | TooManyTagsException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `resourceArn`. If existing tags
 * on a resource are not specified in the request parameters, they are not changed. When a resource is deleted,
 * the tags associated with that resource are also deleted.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ArgumentException | NotFoundException | TagOperationException | CommonErrors;
/**
 * Deletes the specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDeviceInstanceError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Updates information about a private device instance.
 */
export declare const updateDeviceInstance: API.OperationMethod<UpdateDeviceInstanceRequest, UpdateDeviceInstanceResult, UpdateDeviceInstanceError, Credentials | HttpClient.HttpClient>;
export type UpdateDevicePoolError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Modifies the name, description, and rules in a device pool given the attributes and
 * the pool ARN. Rule updates are all-or-nothing, meaning they can only be updated as a
 * whole (or not at all).
 */
export declare const updateDevicePool: API.OperationMethod<UpdateDevicePoolRequest, UpdateDevicePoolResult, UpdateDevicePoolError, Credentials | HttpClient.HttpClient>;
export type UpdateInstanceProfileError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Updates information about an existing private device instance profile.
 */
export declare const updateInstanceProfile: API.OperationMethod<UpdateInstanceProfileRequest, UpdateInstanceProfileResult, UpdateInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateNetworkProfileError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Updates the network profile.
 */
export declare const updateNetworkProfile: API.OperationMethod<UpdateNetworkProfileRequest, UpdateNetworkProfileResult, UpdateNetworkProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateProjectError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Modifies the specified project name, given the project ARN and a new
 * name.
 */
export declare const updateProject: API.OperationMethod<UpdateProjectRequest, UpdateProjectResult, UpdateProjectError, Credentials | HttpClient.HttpClient>;
export type UpdateTestGridProjectError = ArgumentException | InternalServiceException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Change details of a project.
 */
export declare const updateTestGridProject: API.OperationMethod<UpdateTestGridProjectRequest, UpdateTestGridProjectResult, UpdateTestGridProjectError, Credentials | HttpClient.HttpClient>;
export type UpdateUploadError = ArgumentException | LimitExceededException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Updates an uploaded test spec.
 */
export declare const updateUpload: API.OperationMethod<UpdateUploadRequest, UpdateUploadResult, UpdateUploadError, Credentials | HttpClient.HttpClient>;
export type UpdateVPCEConfigurationError = ArgumentException | InvalidOperationException | NotFoundException | ServiceAccountException | CommonErrors;
/**
 * Updates information about an Amazon Virtual Private Cloud (VPC) endpoint configuration.
 */
export declare const updateVPCEConfiguration: API.OperationMethod<UpdateVPCEConfigurationRequest, UpdateVPCEConfigurationResult, UpdateVPCEConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=device-farm.d.ts.map