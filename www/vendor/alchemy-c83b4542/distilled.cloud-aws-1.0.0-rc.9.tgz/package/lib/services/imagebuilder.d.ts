import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const CallRateLimitExceededException_base: S.Class<CallRateLimitExceededException, S.TaggedStruct<"CallRateLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class CallRateLimitExceededException extends /*@__PURE__*/ CallRateLimitExceededException_base {
}
declare const ClientException_base: S.Class<ClientException, S.TaggedStruct<"ClientException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClientException extends /*@__PURE__*/ ClientException_base {
}
declare const DryRunOperationException_base: S.Class<DryRunOperationException, S.TaggedStruct<"DryRunOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DryRunOperationException extends /*@__PURE__*/ DryRunOperationException_base {
}
declare const ForbiddenException_base: S.Class<ForbiddenException, S.TaggedStruct<"ForbiddenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const IdempotentParameterMismatchException_base: S.Class<IdempotentParameterMismatchException, S.TaggedStruct<"IdempotentParameterMismatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IdempotentParameterMismatchException extends /*@__PURE__*/ IdempotentParameterMismatchException_base {
}
declare const InvalidPaginationTokenException_base: S.Class<InvalidPaginationTokenException, S.TaggedStruct<"InvalidPaginationTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPaginationTokenException extends /*@__PURE__*/ InvalidPaginationTokenException_base {
}
declare const InvalidParameterCombinationException_base: S.Class<InvalidParameterCombinationException, S.TaggedStruct<"InvalidParameterCombinationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidParameterValueException_base: S.Class<InvalidParameterValueException, S.TaggedStruct<"InvalidParameterValueException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidVersionNumberException_base: S.Class<InvalidVersionNumberException, S.TaggedStruct<"InvalidVersionNumberException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVersionNumberException extends /*@__PURE__*/ InvalidVersionNumberException_base {
}
declare const ResourceAlreadyExistsException_base: S.Class<ResourceAlreadyExistsException, S.TaggedStruct<"ResourceAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceDependencyException_base: S.Class<ResourceDependencyException, S.TaggedStruct<"ResourceDependencyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceDependencyException extends /*@__PURE__*/ ResourceDependencyException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceException_base: S.Class<ServiceException, S.TaggedStruct<"ServiceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type ImageBuildVersionArn = string;
export type ClientToken = string;
export interface CancelImageCreationRequest {
    imageBuildVersionArn: string;
    clientToken: string;
}
export declare const CancelImageCreationRequest: S.Schema<CancelImageCreationRequest>;
export type NonEmptyString = string;
export interface CancelImageCreationResponse {
    requestId?: string;
    clientToken?: string;
    imageBuildVersionArn?: string;
}
export declare const CancelImageCreationResponse: S.Schema<CancelImageCreationResponse>;
export type LifecycleExecutionId = string;
export interface CancelLifecycleExecutionRequest {
    lifecycleExecutionId: string;
    clientToken: string;
}
export declare const CancelLifecycleExecutionRequest: S.Schema<CancelLifecycleExecutionRequest>;
export interface CancelLifecycleExecutionResponse {
    lifecycleExecutionId?: string;
}
export declare const CancelLifecycleExecutionResponse: S.Schema<CancelLifecycleExecutionResponse>;
export type ResourceName = string;
export type VersionNumber = string;
export type Platform = "Windows" | "Linux" | "macOS" | (string & {});
export declare const Platform: any;
export type OsVersion = string;
export type OsVersionList = string[];
export declare const OsVersionList: any;
export type InlineComponentData = string;
export type Uri = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateComponentRequest {
    name: string;
    semanticVersion: string;
    description?: string;
    changeDescription?: string;
    platform: Platform;
    supportedOsVersions?: string[];
    data?: string;
    uri?: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
    dryRun?: boolean;
}
export declare const CreateComponentRequest: S.Schema<CreateComponentRequest>;
export type ComponentBuildVersionArn = string;
export type ImageBuilderArn = string;
export interface LatestVersionReferences {
    latestVersionArn?: string;
    latestMajorVersionArn?: string;
    latestMinorVersionArn?: string;
    latestPatchVersionArn?: string;
}
export declare const LatestVersionReferences: S.Schema<LatestVersionReferences>;
export interface CreateComponentResponse {
    requestId?: string;
    clientToken?: string;
    componentBuildVersionArn?: string;
    latestVersionReferences?: LatestVersionReferences;
}
export declare const CreateComponentResponse: S.Schema<CreateComponentResponse>;
export type ContainerType = "DOCKER" | (string & {});
export declare const ContainerType: any;
export type WildcardVersionNumber = string;
export type ComponentVersionArnOrBuildVersionArn = string;
export type ComponentParameterName = string;
export type ComponentParameterValue = string;
export type ComponentParameterValueList = string[];
export declare const ComponentParameterValueList: any;
export interface ComponentParameter {
    name: string;
    value: string[];
}
export declare const ComponentParameter: S.Schema<ComponentParameter>;
export type ComponentParameterList = ComponentParameter[];
export declare const ComponentParameterList: any;
export interface ComponentConfiguration {
    componentArn: string;
    parameters?: ComponentParameter[];
}
export declare const ComponentConfiguration: S.Schema<ComponentConfiguration>;
export type ComponentConfigurationList = ComponentConfiguration[];
export declare const ComponentConfigurationList: any;
export type EbsIopsInteger = number;
export type EbsVolumeSizeInteger = number;
export type EbsVolumeType = "standard" | "io1" | "io2" | "gp2" | "gp3" | "sc1" | "st1" | (string & {});
export declare const EbsVolumeType: any;
export type EbsVolumeThroughput = number;
export interface EbsInstanceBlockDeviceSpecification {
    encrypted?: boolean;
    deleteOnTermination?: boolean;
    iops?: number;
    kmsKeyId?: string;
    snapshotId?: string;
    volumeSize?: number;
    volumeType?: EbsVolumeType;
    throughput?: number;
}
export declare const EbsInstanceBlockDeviceSpecification: S.Schema<EbsInstanceBlockDeviceSpecification>;
export type EmptyString = string;
export interface InstanceBlockDeviceMapping {
    deviceName?: string;
    ebs?: EbsInstanceBlockDeviceSpecification;
    virtualName?: string;
    noDevice?: string;
}
export declare const InstanceBlockDeviceMapping: S.Schema<InstanceBlockDeviceMapping>;
export type InstanceBlockDeviceMappings = InstanceBlockDeviceMapping[];
export declare const InstanceBlockDeviceMappings: any;
export interface InstanceConfiguration {
    image?: string;
    blockDeviceMappings?: InstanceBlockDeviceMapping[];
}
export declare const InstanceConfiguration: S.Schema<InstanceConfiguration>;
export type InlineDockerFileTemplate = string;
export type ContainerRepositoryService = "ECR" | (string & {});
export declare const ContainerRepositoryService: any;
export interface TargetContainerRepository {
    service: ContainerRepositoryService;
    repositoryName: string;
}
export declare const TargetContainerRepository: S.Schema<TargetContainerRepository>;
export interface CreateContainerRecipeRequest {
    containerType: ContainerType;
    name: string;
    description?: string;
    semanticVersion: string;
    components?: ComponentConfiguration[];
    instanceConfiguration?: InstanceConfiguration;
    dockerfileTemplateData?: string;
    dockerfileTemplateUri?: string;
    platformOverride?: Platform;
    imageOsVersionOverride?: string;
    parentImage: string;
    tags?: {
        [key: string]: string | undefined;
    };
    workingDirectory?: string;
    targetRepository: TargetContainerRepository;
    kmsKeyId?: string;
    clientToken: string;
}
export declare const CreateContainerRecipeRequest: S.Schema<CreateContainerRecipeRequest>;
export type ContainerRecipeArn = string;
export interface CreateContainerRecipeResponse {
    requestId?: string;
    clientToken?: string;
    containerRecipeArn?: string;
    latestVersionReferences?: LatestVersionReferences;
}
export declare const CreateContainerRecipeResponse: S.Schema<CreateContainerRecipeResponse>;
export type AmiNameString = string;
export type AccountId = string;
export type AccountList = string[];
export declare const AccountList: any;
export type StringList = string[];
export declare const StringList: any;
export type OrganizationArn = string;
export type OrganizationArnList = string[];
export declare const OrganizationArnList: any;
export type OrganizationalUnitArn = string;
export type OrganizationalUnitArnList = string[];
export declare const OrganizationalUnitArnList: any;
export interface LaunchPermissionConfiguration {
    userIds?: string[];
    userGroups?: string[];
    organizationArns?: string[];
    organizationalUnitArns?: string[];
}
export declare const LaunchPermissionConfiguration: S.Schema<LaunchPermissionConfiguration>;
export interface AmiDistributionConfiguration {
    name?: string;
    description?: string;
    targetAccountIds?: string[];
    amiTags?: {
        [key: string]: string | undefined;
    };
    kmsKeyId?: string;
    launchPermission?: LaunchPermissionConfiguration;
}
export declare const AmiDistributionConfiguration: S.Schema<AmiDistributionConfiguration>;
export interface ContainerDistributionConfiguration {
    description?: string;
    containerTags?: string[];
    targetRepository: TargetContainerRepository;
}
export declare const ContainerDistributionConfiguration: S.Schema<ContainerDistributionConfiguration>;
export type LicenseConfigurationArn = string;
export type LicenseConfigurationArnList = string[];
export declare const LicenseConfigurationArnList: any;
export type LaunchTemplateId = string;
export interface LaunchTemplateConfiguration {
    launchTemplateId: string;
    accountId?: string;
    setDefaultVersion?: boolean;
}
export declare const LaunchTemplateConfiguration: S.Schema<LaunchTemplateConfiguration>;
export type LaunchTemplateConfigurationList = LaunchTemplateConfiguration[];
export declare const LaunchTemplateConfigurationList: any;
export type DiskImageFormat = "VMDK" | "RAW" | "VHD" | (string & {});
export declare const DiskImageFormat: any;
export interface S3ExportConfiguration {
    roleName: string;
    diskImageFormat: DiskImageFormat;
    s3Bucket: string;
    s3Prefix?: string;
}
export declare const S3ExportConfiguration: S.Schema<S3ExportConfiguration>;
export type TargetResourceCount = number;
export interface FastLaunchSnapshotConfiguration {
    targetResourceCount?: number;
}
export declare const FastLaunchSnapshotConfiguration: S.Schema<FastLaunchSnapshotConfiguration>;
export type MaxParallelLaunches = number;
export interface FastLaunchLaunchTemplateSpecification {
    launchTemplateId?: string;
    launchTemplateName?: string;
    launchTemplateVersion?: string;
}
export declare const FastLaunchLaunchTemplateSpecification: S.Schema<FastLaunchLaunchTemplateSpecification>;
export interface FastLaunchConfiguration {
    enabled: boolean;
    snapshotConfiguration?: FastLaunchSnapshotConfiguration;
    maxParallelLaunches?: number;
    launchTemplate?: FastLaunchLaunchTemplateSpecification;
    accountId?: string;
}
export declare const FastLaunchConfiguration: S.Schema<FastLaunchConfiguration>;
export type FastLaunchConfigurationList = FastLaunchConfiguration[];
export declare const FastLaunchConfigurationList: any;
export type SsmParameterName = string;
export type SsmParameterDataType = "text" | "aws:ec2:image" | (string & {});
export declare const SsmParameterDataType: any;
export interface SsmParameterConfiguration {
    amiAccountId?: string;
    parameterName: string;
    dataType?: SsmParameterDataType;
}
export declare const SsmParameterConfiguration: S.Schema<SsmParameterConfiguration>;
export type SsmParameterConfigurationList = SsmParameterConfiguration[];
export declare const SsmParameterConfigurationList: any;
export interface Distribution {
    region: string;
    amiDistributionConfiguration?: AmiDistributionConfiguration;
    containerDistributionConfiguration?: ContainerDistributionConfiguration;
    licenseConfigurationArns?: string[];
    launchTemplateConfigurations?: LaunchTemplateConfiguration[];
    s3ExportConfiguration?: S3ExportConfiguration;
    fastLaunchConfigurations?: FastLaunchConfiguration[];
    ssmParameterConfigurations?: SsmParameterConfiguration[];
}
export declare const Distribution: S.Schema<Distribution>;
export type DistributionList = Distribution[];
export declare const DistributionList: any;
export interface CreateDistributionConfigurationRequest {
    name: string;
    description?: string;
    distributions: Distribution[];
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
}
export declare const CreateDistributionConfigurationRequest: S.Schema<CreateDistributionConfigurationRequest>;
export type DistributionConfigurationArn = string;
export interface CreateDistributionConfigurationResponse {
    requestId?: string;
    clientToken?: string;
    distributionConfigurationArn?: string;
}
export declare const CreateDistributionConfigurationResponse: S.Schema<CreateDistributionConfigurationResponse>;
export type ImageRecipeArn = string;
export type InfrastructureConfigurationArn = string;
export type ImageTestsTimeoutMinutes = number;
export interface ImageTestsConfiguration {
    imageTestsEnabled?: boolean;
    timeoutMinutes?: number;
}
export declare const ImageTestsConfiguration: S.Schema<ImageTestsConfiguration>;
export interface EcrConfiguration {
    repositoryName?: string;
    containerTags?: string[];
}
export declare const EcrConfiguration: S.Schema<EcrConfiguration>;
export interface ImageScanningConfiguration {
    imageScanningEnabled?: boolean;
    ecrConfiguration?: EcrConfiguration;
}
export declare const ImageScanningConfiguration: S.Schema<ImageScanningConfiguration>;
export type WorkflowVersionArnOrBuildVersionArn = string;
export type WorkflowParameterName = string;
export type WorkflowParameterValue = string;
export type WorkflowParameterValueList = string[];
export declare const WorkflowParameterValueList: any;
export interface WorkflowParameter {
    name: string;
    value: string[];
}
export declare const WorkflowParameter: S.Schema<WorkflowParameter>;
export type WorkflowParameterList = WorkflowParameter[];
export declare const WorkflowParameterList: any;
export type ParallelGroup = string;
export type OnWorkflowFailure = "CONTINUE" | "ABORT" | (string & {});
export declare const OnWorkflowFailure: any;
export interface WorkflowConfiguration {
    workflowArn: string;
    parameters?: WorkflowParameter[];
    parallelGroup?: string;
    onFailure?: OnWorkflowFailure;
}
export declare const WorkflowConfiguration: S.Schema<WorkflowConfiguration>;
export type WorkflowConfigurationList = WorkflowConfiguration[];
export declare const WorkflowConfigurationList: any;
export type RoleNameOrArn = string;
export type LogGroupName = string;
export interface ImageLoggingConfiguration {
    logGroupName?: string;
}
export declare const ImageLoggingConfiguration: S.Schema<ImageLoggingConfiguration>;
export interface CreateImageRequest {
    imageRecipeArn?: string;
    containerRecipeArn?: string;
    distributionConfigurationArn?: string;
    infrastructureConfigurationArn: string;
    imageTestsConfiguration?: ImageTestsConfiguration;
    enhancedImageMetadataEnabled?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
    imageScanningConfiguration?: ImageScanningConfiguration;
    workflows?: WorkflowConfiguration[];
    executionRole?: string;
    loggingConfiguration?: ImageLoggingConfiguration;
}
export declare const CreateImageRequest: S.Schema<CreateImageRequest>;
export interface CreateImageResponse {
    requestId?: string;
    clientToken?: string;
    imageBuildVersionArn?: string;
    latestVersionReferences?: LatestVersionReferences;
}
export declare const CreateImageResponse: S.Schema<CreateImageResponse>;
export type Timezone = string;
export type PipelineExecutionStartCondition = "EXPRESSION_MATCH_ONLY" | "EXPRESSION_MATCH_AND_DEPENDENCY_UPDATES_AVAILABLE" | (string & {});
export declare const PipelineExecutionStartCondition: any;
export type AutoDisableFailureCount = number;
export interface AutoDisablePolicy {
    failureCount: number;
}
export declare const AutoDisablePolicy: S.Schema<AutoDisablePolicy>;
export interface Schedule {
    scheduleExpression?: string;
    timezone?: string;
    pipelineExecutionStartCondition?: PipelineExecutionStartCondition;
    autoDisablePolicy?: AutoDisablePolicy;
}
export declare const Schedule: S.Schema<Schedule>;
export type PipelineStatus = "DISABLED" | "ENABLED" | (string & {});
export declare const PipelineStatus: any;
export interface PipelineLoggingConfiguration {
    imageLogGroupName?: string;
    pipelineLogGroupName?: string;
}
export declare const PipelineLoggingConfiguration: S.Schema<PipelineLoggingConfiguration>;
export interface CreateImagePipelineRequest {
    name: string;
    description?: string;
    imageRecipeArn?: string;
    containerRecipeArn?: string;
    infrastructureConfigurationArn: string;
    distributionConfigurationArn?: string;
    imageTestsConfiguration?: ImageTestsConfiguration;
    enhancedImageMetadataEnabled?: boolean;
    schedule?: Schedule;
    status?: PipelineStatus;
    tags?: {
        [key: string]: string | undefined;
    };
    imageTags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
    imageScanningConfiguration?: ImageScanningConfiguration;
    workflows?: WorkflowConfiguration[];
    executionRole?: string;
    loggingConfiguration?: PipelineLoggingConfiguration;
}
export declare const CreateImagePipelineRequest: S.Schema<CreateImagePipelineRequest>;
export type ImagePipelineArn = string;
export interface CreateImagePipelineResponse {
    requestId?: string;
    clientToken?: string;
    imagePipelineArn?: string;
}
export declare const CreateImagePipelineResponse: S.Schema<CreateImagePipelineResponse>;
export interface SystemsManagerAgent {
    uninstallAfterBuild?: boolean;
}
export declare const SystemsManagerAgent: S.Schema<SystemsManagerAgent>;
export type UserDataOverride = string;
export interface AdditionalInstanceConfiguration {
    systemsManagerAgent?: SystemsManagerAgent;
    userDataOverride?: string;
}
export declare const AdditionalInstanceConfiguration: S.Schema<AdditionalInstanceConfiguration>;
export type AmiWatermarkName = string;
export type AmiWatermarksList = string[];
export declare const AmiWatermarksList: any;
export interface CreateImageRecipeRequest {
    name: string;
    description?: string;
    semanticVersion: string;
    components?: ComponentConfiguration[];
    parentImage: string;
    blockDeviceMappings?: InstanceBlockDeviceMapping[];
    tags?: {
        [key: string]: string | undefined;
    };
    workingDirectory?: string;
    additionalInstanceConfiguration?: AdditionalInstanceConfiguration;
    amiTags?: {
        [key: string]: string | undefined;
    };
    amiWatermarks?: string[];
    clientToken: string;
}
export declare const CreateImageRecipeRequest: S.Schema<CreateImageRecipeRequest>;
export interface CreateImageRecipeResponse {
    requestId?: string;
    clientToken?: string;
    imageRecipeArn?: string;
    latestVersionReferences?: LatestVersionReferences;
}
export declare const CreateImageRecipeResponse: S.Schema<CreateImageRecipeResponse>;
export type InstanceType = string;
export type InstanceTypeList = string[];
export declare const InstanceTypeList: any;
export type InstanceProfileNameType = string;
export type SecurityGroupIds = string[];
export declare const SecurityGroupIds: any;
export interface S3Logs {
    s3BucketName?: string;
    s3KeyPrefix?: string;
}
export declare const S3Logs: S.Schema<S3Logs>;
export interface Logging {
    s3Logs?: S3Logs;
}
export declare const Logging: S.Schema<Logging>;
export type SnsTopicArn = string;
export type ResourceTagMap = {
    [key: string]: string | undefined;
};
export declare const ResourceTagMap: any;
export type HttpTokens = string;
export type HttpPutResponseHopLimit = number;
export interface InstanceMetadataOptions {
    httpTokens?: string;
    httpPutResponseHopLimit?: number;
}
export declare const InstanceMetadataOptions: S.Schema<InstanceMetadataOptions>;
export type TenancyType = "default" | "dedicated" | "host" | (string & {});
export declare const TenancyType: any;
export interface Placement {
    availabilityZone?: string;
    tenancy?: TenancyType;
    hostId?: string;
    hostResourceGroupArn?: string;
}
export declare const Placement: S.Schema<Placement>;
export interface CreateInfrastructureConfigurationRequest {
    name: string;
    description?: string;
    instanceTypes?: string[];
    instanceProfileName: string;
    securityGroupIds?: string[];
    subnetId?: string;
    logging?: Logging;
    keyPair?: string;
    terminateInstanceOnFailure?: boolean;
    snsTopicArn?: string;
    resourceTags?: {
        [key: string]: string | undefined;
    };
    instanceMetadataOptions?: InstanceMetadataOptions;
    tags?: {
        [key: string]: string | undefined;
    };
    placement?: Placement;
    clientToken: string;
}
export declare const CreateInfrastructureConfigurationRequest: S.Schema<CreateInfrastructureConfigurationRequest>;
export interface CreateInfrastructureConfigurationResponse {
    requestId?: string;
    clientToken?: string;
    infrastructureConfigurationArn?: string;
}
export declare const CreateInfrastructureConfigurationResponse: S.Schema<CreateInfrastructureConfigurationResponse>;
export type LifecyclePolicyStatus = "DISABLED" | "ENABLED" | (string & {});
export declare const LifecyclePolicyStatus: any;
export type LifecyclePolicyResourceType = "AMI_IMAGE" | "CONTAINER_IMAGE" | (string & {});
export declare const LifecyclePolicyResourceType: any;
export type LifecyclePolicyDetailActionType = "DELETE" | "DEPRECATE" | "DISABLE" | (string & {});
export declare const LifecyclePolicyDetailActionType: any;
export interface LifecyclePolicyDetailActionIncludeResources {
    amis?: boolean;
    snapshots?: boolean;
    containers?: boolean;
}
export declare const LifecyclePolicyDetailActionIncludeResources: S.Schema<LifecyclePolicyDetailActionIncludeResources>;
export interface LifecyclePolicyDetailAction {
    type: LifecyclePolicyDetailActionType;
    includeResources?: LifecyclePolicyDetailActionIncludeResources;
}
export declare const LifecyclePolicyDetailAction: S.Schema<LifecyclePolicyDetailAction>;
export type LifecyclePolicyDetailFilterType = "AGE" | "COUNT" | (string & {});
export declare const LifecyclePolicyDetailFilterType: any;
export type LifecyclePolicyDetailFilterValue = number;
export type LifecyclePolicyTimeUnit = "DAYS" | "WEEKS" | "MONTHS" | "YEARS" | (string & {});
export declare const LifecyclePolicyTimeUnit: any;
export type LifecyclePolicyDetailFilterRetainAtLeast = number;
export interface LifecyclePolicyDetailFilter {
    type: LifecyclePolicyDetailFilterType;
    value: number;
    unit?: LifecyclePolicyTimeUnit;
    retainAtLeast?: number;
}
export declare const LifecyclePolicyDetailFilter: S.Schema<LifecyclePolicyDetailFilter>;
export type LifecyclePolicyDetailExclusionRulesAmisLastLaunchedValue = number;
export interface LifecyclePolicyDetailExclusionRulesAmisLastLaunched {
    value: number;
    unit: LifecyclePolicyTimeUnit;
}
export declare const LifecyclePolicyDetailExclusionRulesAmisLastLaunched: S.Schema<LifecyclePolicyDetailExclusionRulesAmisLastLaunched>;
export interface LifecyclePolicyDetailExclusionRulesAmis {
    isPublic?: boolean;
    regions?: string[];
    sharedAccounts?: string[];
    lastLaunched?: LifecyclePolicyDetailExclusionRulesAmisLastLaunched;
    tagMap?: {
        [key: string]: string | undefined;
    };
}
export declare const LifecyclePolicyDetailExclusionRulesAmis: S.Schema<LifecyclePolicyDetailExclusionRulesAmis>;
export interface LifecyclePolicyDetailExclusionRules {
    tagMap?: {
        [key: string]: string | undefined;
    };
    amis?: LifecyclePolicyDetailExclusionRulesAmis;
}
export declare const LifecyclePolicyDetailExclusionRules: S.Schema<LifecyclePolicyDetailExclusionRules>;
export interface LifecyclePolicyDetail {
    action: LifecyclePolicyDetailAction;
    filter: LifecyclePolicyDetailFilter;
    exclusionRules?: LifecyclePolicyDetailExclusionRules;
}
export declare const LifecyclePolicyDetail: S.Schema<LifecyclePolicyDetail>;
export type LifecyclePolicyDetails = LifecyclePolicyDetail[];
export declare const LifecyclePolicyDetails: any;
export interface LifecyclePolicyResourceSelectionRecipe {
    name: string;
    semanticVersion: string;
}
export declare const LifecyclePolicyResourceSelectionRecipe: S.Schema<LifecyclePolicyResourceSelectionRecipe>;
export type LifecyclePolicyResourceSelectionRecipes = LifecyclePolicyResourceSelectionRecipe[];
export declare const LifecyclePolicyResourceSelectionRecipes: any;
export interface LifecyclePolicyResourceSelection {
    recipes?: LifecyclePolicyResourceSelectionRecipe[];
    tagMap?: {
        [key: string]: string | undefined;
    };
}
export declare const LifecyclePolicyResourceSelection: S.Schema<LifecyclePolicyResourceSelection>;
export interface CreateLifecyclePolicyRequest {
    name: string;
    description?: string;
    status?: LifecyclePolicyStatus;
    executionRole: string;
    resourceType: LifecyclePolicyResourceType;
    policyDetails: LifecyclePolicyDetail[];
    resourceSelection: LifecyclePolicyResourceSelection;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
}
export declare const CreateLifecyclePolicyRequest: S.Schema<CreateLifecyclePolicyRequest>;
export type LifecyclePolicyArn = string;
export interface CreateLifecyclePolicyResponse {
    clientToken?: string;
    lifecyclePolicyArn?: string;
}
export declare const CreateLifecyclePolicyResponse: S.Schema<CreateLifecyclePolicyResponse>;
export type InlineWorkflowData = string;
export type WorkflowType = "BUILD" | "TEST" | "DISTRIBUTION" | (string & {});
export declare const WorkflowType: any;
export interface CreateWorkflowRequest {
    name: string;
    semanticVersion: string;
    description?: string;
    changeDescription?: string;
    data?: string;
    uri?: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
    type: WorkflowType;
    dryRun?: boolean;
}
export declare const CreateWorkflowRequest: S.Schema<CreateWorkflowRequest>;
export type WorkflowBuildVersionArn = string;
export interface CreateWorkflowResponse {
    clientToken?: string;
    workflowBuildVersionArn?: string;
    latestVersionReferences?: LatestVersionReferences;
}
export declare const CreateWorkflowResponse: S.Schema<CreateWorkflowResponse>;
export interface DeleteComponentRequest {
    componentBuildVersionArn: string;
}
export declare const DeleteComponentRequest: S.Schema<DeleteComponentRequest>;
export interface DeleteComponentResponse {
    requestId?: string;
    componentBuildVersionArn?: string;
}
export declare const DeleteComponentResponse: S.Schema<DeleteComponentResponse>;
export interface DeleteContainerRecipeRequest {
    containerRecipeArn: string;
}
export declare const DeleteContainerRecipeRequest: S.Schema<DeleteContainerRecipeRequest>;
export interface DeleteContainerRecipeResponse {
    requestId?: string;
    containerRecipeArn?: string;
}
export declare const DeleteContainerRecipeResponse: S.Schema<DeleteContainerRecipeResponse>;
export interface DeleteDistributionConfigurationRequest {
    distributionConfigurationArn: string;
}
export declare const DeleteDistributionConfigurationRequest: S.Schema<DeleteDistributionConfigurationRequest>;
export interface DeleteDistributionConfigurationResponse {
    requestId?: string;
    distributionConfigurationArn?: string;
}
export declare const DeleteDistributionConfigurationResponse: S.Schema<DeleteDistributionConfigurationResponse>;
export interface DeleteImageRequest {
    imageBuildVersionArn: string;
}
export declare const DeleteImageRequest: S.Schema<DeleteImageRequest>;
export interface DeleteImageResponse {
    requestId?: string;
    imageBuildVersionArn?: string;
}
export declare const DeleteImageResponse: S.Schema<DeleteImageResponse>;
export interface DeleteImagePipelineRequest {
    imagePipelineArn: string;
}
export declare const DeleteImagePipelineRequest: S.Schema<DeleteImagePipelineRequest>;
export interface DeleteImagePipelineResponse {
    requestId?: string;
    imagePipelineArn?: string;
}
export declare const DeleteImagePipelineResponse: S.Schema<DeleteImagePipelineResponse>;
export interface DeleteImageRecipeRequest {
    imageRecipeArn: string;
}
export declare const DeleteImageRecipeRequest: S.Schema<DeleteImageRecipeRequest>;
export interface DeleteImageRecipeResponse {
    requestId?: string;
    imageRecipeArn?: string;
}
export declare const DeleteImageRecipeResponse: S.Schema<DeleteImageRecipeResponse>;
export interface DeleteInfrastructureConfigurationRequest {
    infrastructureConfigurationArn: string;
}
export declare const DeleteInfrastructureConfigurationRequest: S.Schema<DeleteInfrastructureConfigurationRequest>;
export interface DeleteInfrastructureConfigurationResponse {
    requestId?: string;
    infrastructureConfigurationArn?: string;
}
export declare const DeleteInfrastructureConfigurationResponse: S.Schema<DeleteInfrastructureConfigurationResponse>;
export interface DeleteLifecyclePolicyRequest {
    lifecyclePolicyArn: string;
}
export declare const DeleteLifecyclePolicyRequest: S.Schema<DeleteLifecyclePolicyRequest>;
export interface DeleteLifecyclePolicyResponse {
    lifecyclePolicyArn?: string;
}
export declare const DeleteLifecyclePolicyResponse: S.Schema<DeleteLifecyclePolicyResponse>;
export interface DeleteWorkflowRequest {
    workflowBuildVersionArn: string;
}
export declare const DeleteWorkflowRequest: S.Schema<DeleteWorkflowRequest>;
export interface DeleteWorkflowResponse {
    workflowBuildVersionArn?: string;
}
export declare const DeleteWorkflowResponse: S.Schema<DeleteWorkflowResponse>;
export interface DistributeImageRequest {
    sourceImage: string;
    distributionConfigurationArn: string;
    executionRole: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
    loggingConfiguration?: ImageLoggingConfiguration;
}
export declare const DistributeImageRequest: S.Schema<DistributeImageRequest>;
export interface DistributeImageResponse {
    clientToken?: string;
    imageBuildVersionArn?: string;
}
export declare const DistributeImageResponse: S.Schema<DistributeImageResponse>;
export interface GetComponentRequest {
    componentBuildVersionArn: string;
}
export declare const GetComponentRequest: S.Schema<GetComponentRequest>;
export type ComponentType = "BUILD" | "TEST" | (string & {});
export declare const ComponentType: any;
export type ComponentStatus = "DEPRECATED" | "DISABLED" | "ACTIVE" | (string & {});
export declare const ComponentStatus: any;
export interface ComponentState {
    status?: ComponentStatus;
    reason?: string;
}
export declare const ComponentState: S.Schema<ComponentState>;
export type ComponentParameterType = string;
export type ComponentParameterDescription = string;
export interface ComponentParameterDetail {
    name: string;
    type: string;
    defaultValue?: string[];
    description?: string;
}
export declare const ComponentParameterDetail: S.Schema<ComponentParameterDetail>;
export type ComponentParameterDetailList = ComponentParameterDetail[];
export declare const ComponentParameterDetailList: any;
export type ComponentData = string;
export type ProductCodeId = string;
export type ProductCodeType = "marketplace" | (string & {});
export declare const ProductCodeType: any;
export interface ProductCodeListItem {
    productCodeId: string;
    productCodeType: ProductCodeType;
}
export declare const ProductCodeListItem: S.Schema<ProductCodeListItem>;
export type ProductCodeList = ProductCodeListItem[];
export declare const ProductCodeList: any;
export interface Component {
    arn?: string;
    name?: string;
    version?: string;
    description?: string;
    changeDescription?: string;
    type?: ComponentType;
    platform?: Platform;
    supportedOsVersions?: string[];
    state?: ComponentState;
    parameters?: ComponentParameterDetail[];
    owner?: string;
    data?: string;
    kmsKeyId?: string;
    encrypted?: boolean;
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    publisher?: string;
    obfuscate?: boolean;
    productCodes?: ProductCodeListItem[];
}
export declare const Component: S.Schema<Component>;
export interface GetComponentResponse {
    requestId?: string;
    component?: Component;
    latestVersionReferences?: LatestVersionReferences;
}
export declare const GetComponentResponse: S.Schema<GetComponentResponse>;
export interface GetComponentPolicyRequest {
    componentArn: string;
}
export declare const GetComponentPolicyRequest: S.Schema<GetComponentPolicyRequest>;
export type ResourcePolicyDocument = string;
export interface GetComponentPolicyResponse {
    requestId?: string;
    policy?: string;
}
export declare const GetComponentPolicyResponse: S.Schema<GetComponentPolicyResponse>;
export interface GetContainerRecipeRequest {
    containerRecipeArn: string;
}
export declare const GetContainerRecipeRequest: S.Schema<GetContainerRecipeRequest>;
export type DockerFileTemplate = string;
export interface ContainerRecipe {
    arn?: string;
    containerType?: ContainerType;
    name?: string;
    description?: string;
    platform?: Platform;
    owner?: string;
    version?: string;
    components?: ComponentConfiguration[];
    instanceConfiguration?: InstanceConfiguration;
    dockerfileTemplateData?: string;
    kmsKeyId?: string;
    encrypted?: boolean;
    parentImage?: string;
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    workingDirectory?: string;
    targetRepository?: TargetContainerRepository;
}
export declare const ContainerRecipe: S.Schema<ContainerRecipe>;
export interface GetContainerRecipeResponse {
    requestId?: string;
    containerRecipe?: ContainerRecipe;
    latestVersionReferences?: LatestVersionReferences;
}
export declare const GetContainerRecipeResponse: S.Schema<GetContainerRecipeResponse>;
export interface GetContainerRecipePolicyRequest {
    containerRecipeArn: string;
}
export declare const GetContainerRecipePolicyRequest: S.Schema<GetContainerRecipePolicyRequest>;
export interface GetContainerRecipePolicyResponse {
    requestId?: string;
    policy?: string;
}
export declare const GetContainerRecipePolicyResponse: S.Schema<GetContainerRecipePolicyResponse>;
export interface GetDistributionConfigurationRequest {
    distributionConfigurationArn: string;
}
export declare const GetDistributionConfigurationRequest: S.Schema<GetDistributionConfigurationRequest>;
export type DistributionTimeoutMinutes = number;
export interface DistributionConfiguration {
    arn?: string;
    name?: string;
    description?: string;
    distributions?: Distribution[];
    timeoutMinutes?: number;
    dateCreated?: string;
    dateUpdated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DistributionConfiguration: S.Schema<DistributionConfiguration>;
export interface GetDistributionConfigurationResponse {
    requestId?: string;
    distributionConfiguration?: DistributionConfiguration;
}
export declare const GetDistributionConfigurationResponse: S.Schema<GetDistributionConfigurationResponse>;
export type ImageVersionArnOrBuildVersionArn = string;
export interface GetImageRequest {
    imageBuildVersionArn: string;
}
export declare const GetImageRequest: S.Schema<GetImageRequest>;
export type ImageType = "AMI" | "DOCKER" | (string & {});
export declare const ImageType: any;
export type ImageStatus = "PENDING" | "CREATING" | "BUILDING" | "TESTING" | "DISTRIBUTING" | "INTEGRATING" | "AVAILABLE" | "CANCELLED" | "FAILED" | "DEPRECATED" | "DELETED" | "DISABLED" | (string & {});
export declare const ImageStatus: any;
export interface ImageState {
    status?: ImageStatus;
    reason?: string;
}
export declare const ImageState: S.Schema<ImageState>;
export interface ImageRecipe {
    arn?: string;
    type?: ImageType;
    name?: string;
    description?: string;
    platform?: Platform;
    owner?: string;
    version?: string;
    components?: ComponentConfiguration[];
    parentImage?: string;
    blockDeviceMappings?: InstanceBlockDeviceMapping[];
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    workingDirectory?: string;
    additionalInstanceConfiguration?: AdditionalInstanceConfiguration;
    amiTags?: {
        [key: string]: string | undefined;
    };
    amiWatermarks?: string[];
}
export declare const ImageRecipe: S.Schema<ImageRecipe>;
export type Arn = string;
export interface InfrastructureConfiguration {
    arn?: string;
    name?: string;
    description?: string;
    instanceTypes?: string[];
    instanceProfileName?: string;
    securityGroupIds?: string[];
    subnetId?: string;
    logging?: Logging;
    keyPair?: string;
    terminateInstanceOnFailure?: boolean;
    snsTopicArn?: string;
    dateCreated?: string;
    dateUpdated?: string;
    resourceTags?: {
        [key: string]: string | undefined;
    };
    instanceMetadataOptions?: InstanceMetadataOptions;
    tags?: {
        [key: string]: string | undefined;
    };
    placement?: Placement;
}
export declare const InfrastructureConfiguration: S.Schema<InfrastructureConfiguration>;
export interface Ami {
    region?: string;
    image?: string;
    name?: string;
    description?: string;
    state?: ImageState;
    accountId?: string;
}
export declare const Ami: S.Schema<Ami>;
export type AmiList = Ami[];
export declare const AmiList: any;
export interface Container {
    region?: string;
    imageUris?: string[];
}
export declare const Container: S.Schema<Container>;
export type ContainerList = Container[];
export declare const ContainerList: any;
export interface OutputResources {
    amis?: Ami[];
    containers?: Container[];
}
export declare const OutputResources: S.Schema<OutputResources>;
export type BuildType = "USER_INITIATED" | "SCHEDULED" | "IMPORT" | "IMPORT_ISO" | (string & {});
export declare const BuildType: any;
export type ImageSource = "AMAZON_MANAGED" | "AWS_MARKETPLACE" | "IMPORTED" | "CUSTOM" | (string & {});
export declare const ImageSource: any;
export type ImageScanStatus = "PENDING" | "SCANNING" | "COLLECTING" | "COMPLETED" | "ABANDONED" | "FAILED" | "TIMED_OUT" | (string & {});
export declare const ImageScanStatus: any;
export interface ImageScanState {
    status?: ImageScanStatus;
    reason?: string;
}
export declare const ImageScanState: S.Schema<ImageScanState>;
export type DateTimeTimestamp = Date;
export interface Image {
    arn?: string;
    type?: ImageType;
    name?: string;
    version?: string;
    platform?: Platform;
    enhancedImageMetadataEnabled?: boolean;
    osVersion?: string;
    state?: ImageState;
    imageRecipe?: ImageRecipe;
    containerRecipe?: ContainerRecipe;
    sourcePipelineName?: string;
    sourcePipelineArn?: string;
    infrastructureConfiguration?: InfrastructureConfiguration;
    distributionConfiguration?: DistributionConfiguration;
    imageTestsConfiguration?: ImageTestsConfiguration;
    dateCreated?: string;
    outputResources?: OutputResources;
    tags?: {
        [key: string]: string | undefined;
    };
    buildType?: BuildType;
    imageSource?: ImageSource;
    scanState?: ImageScanState;
    imageScanningConfiguration?: ImageScanningConfiguration;
    deprecationTime?: Date;
    lifecycleExecutionId?: string;
    executionRole?: string;
    workflows?: WorkflowConfiguration[];
    loggingConfiguration?: ImageLoggingConfiguration;
}
export declare const Image: S.Schema<Image>;
export interface GetImageResponse {
    requestId?: string;
    image?: Image;
    latestVersionReferences?: LatestVersionReferences;
}
export declare const GetImageResponse: S.Schema<GetImageResponse>;
export interface GetImagePipelineRequest {
    imagePipelineArn: string;
}
export declare const GetImagePipelineRequest: S.Schema<GetImagePipelineRequest>;
export type ConsecutiveFailures = number;
export interface ImagePipeline {
    arn?: string;
    name?: string;
    description?: string;
    platform?: Platform;
    enhancedImageMetadataEnabled?: boolean;
    imageRecipeArn?: string;
    containerRecipeArn?: string;
    infrastructureConfigurationArn?: string;
    distributionConfigurationArn?: string;
    imageTestsConfiguration?: ImageTestsConfiguration;
    schedule?: Schedule;
    status?: PipelineStatus;
    dateCreated?: string;
    dateUpdated?: string;
    dateLastRun?: string;
    lastRunStatus?: ImageStatus;
    dateNextRun?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    imageScanningConfiguration?: ImageScanningConfiguration;
    imageTags?: {
        [key: string]: string | undefined;
    };
    executionRole?: string;
    workflows?: WorkflowConfiguration[];
    loggingConfiguration?: PipelineLoggingConfiguration;
    consecutiveFailures?: number;
}
export declare const ImagePipeline: S.Schema<ImagePipeline>;
export interface GetImagePipelineResponse {
    requestId?: string;
    imagePipeline?: ImagePipeline;
}
export declare const GetImagePipelineResponse: S.Schema<GetImagePipelineResponse>;
export interface GetImagePolicyRequest {
    imageArn: string;
}
export declare const GetImagePolicyRequest: S.Schema<GetImagePolicyRequest>;
export interface GetImagePolicyResponse {
    requestId?: string;
    policy?: string;
}
export declare const GetImagePolicyResponse: S.Schema<GetImagePolicyResponse>;
export interface GetImageRecipeRequest {
    imageRecipeArn: string;
}
export declare const GetImageRecipeRequest: S.Schema<GetImageRecipeRequest>;
export interface GetImageRecipeResponse {
    requestId?: string;
    imageRecipe?: ImageRecipe;
    latestVersionReferences?: LatestVersionReferences;
}
export declare const GetImageRecipeResponse: S.Schema<GetImageRecipeResponse>;
export interface GetImageRecipePolicyRequest {
    imageRecipeArn: string;
}
export declare const GetImageRecipePolicyRequest: S.Schema<GetImageRecipePolicyRequest>;
export interface GetImageRecipePolicyResponse {
    requestId?: string;
    policy?: string;
}
export declare const GetImageRecipePolicyResponse: S.Schema<GetImageRecipePolicyResponse>;
export interface GetInfrastructureConfigurationRequest {
    infrastructureConfigurationArn: string;
}
export declare const GetInfrastructureConfigurationRequest: S.Schema<GetInfrastructureConfigurationRequest>;
export interface GetInfrastructureConfigurationResponse {
    requestId?: string;
    infrastructureConfiguration?: InfrastructureConfiguration;
}
export declare const GetInfrastructureConfigurationResponse: S.Schema<GetInfrastructureConfigurationResponse>;
export interface GetLifecycleExecutionRequest {
    lifecycleExecutionId: string;
}
export declare const GetLifecycleExecutionRequest: S.Schema<GetLifecycleExecutionRequest>;
export interface LifecycleExecutionResourcesImpactedSummary {
    hasImpactedResources?: boolean;
}
export declare const LifecycleExecutionResourcesImpactedSummary: S.Schema<LifecycleExecutionResourcesImpactedSummary>;
export type LifecycleExecutionStatus = "IN_PROGRESS" | "CANCELLED" | "CANCELLING" | "FAILED" | "SUCCESS" | "PENDING" | (string & {});
export declare const LifecycleExecutionStatus: any;
export interface LifecycleExecutionState {
    status?: LifecycleExecutionStatus;
    reason?: string;
}
export declare const LifecycleExecutionState: S.Schema<LifecycleExecutionState>;
export interface LifecycleExecution {
    lifecycleExecutionId?: string;
    lifecyclePolicyArn?: string;
    resourcesImpactedSummary?: LifecycleExecutionResourcesImpactedSummary;
    state?: LifecycleExecutionState;
    startTime?: Date;
    endTime?: Date;
}
export declare const LifecycleExecution: S.Schema<LifecycleExecution>;
export interface GetLifecycleExecutionResponse {
    lifecycleExecution?: LifecycleExecution;
}
export declare const GetLifecycleExecutionResponse: S.Schema<GetLifecycleExecutionResponse>;
export interface GetLifecyclePolicyRequest {
    lifecyclePolicyArn: string;
}
export declare const GetLifecyclePolicyRequest: S.Schema<GetLifecyclePolicyRequest>;
export interface LifecyclePolicy {
    arn?: string;
    name?: string;
    description?: string;
    status?: LifecyclePolicyStatus;
    executionRole?: string;
    resourceType?: LifecyclePolicyResourceType;
    policyDetails?: LifecyclePolicyDetail[];
    resourceSelection?: LifecyclePolicyResourceSelection;
    dateCreated?: Date;
    dateUpdated?: Date;
    dateLastRun?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const LifecyclePolicy: S.Schema<LifecyclePolicy>;
export interface GetLifecyclePolicyResponse {
    lifecyclePolicy?: LifecyclePolicy;
}
export declare const GetLifecyclePolicyResponse: S.Schema<GetLifecyclePolicyResponse>;
export type MarketplaceResourceType = "COMPONENT_DATA" | "COMPONENT_ARTIFACT" | (string & {});
export declare const MarketplaceResourceType: any;
export type MarketplaceResourceLocation = string;
export interface GetMarketplaceResourceRequest {
    resourceType: MarketplaceResourceType;
    resourceArn: string;
    resourceLocation?: string;
}
export declare const GetMarketplaceResourceRequest: S.Schema<GetMarketplaceResourceRequest>;
export interface GetMarketplaceResourceResponse {
    resourceArn?: string;
    url?: string;
    data?: string;
}
export declare const GetMarketplaceResourceResponse: S.Schema<GetMarketplaceResourceResponse>;
export interface GetWorkflowRequest {
    workflowBuildVersionArn: string;
}
export declare const GetWorkflowRequest: S.Schema<GetWorkflowRequest>;
export type WorkflowStatus = "DEPRECATED" | (string & {});
export declare const WorkflowStatus: any;
export interface WorkflowState {
    status?: WorkflowStatus;
    reason?: string;
}
export declare const WorkflowState: S.Schema<WorkflowState>;
export type WorkflowData = string;
export type WorkflowParameterType = string;
export type WorkflowParameterDescription = string;
export interface WorkflowParameterDetail {
    name: string;
    type: string;
    defaultValue?: string[];
    description?: string;
}
export declare const WorkflowParameterDetail: S.Schema<WorkflowParameterDetail>;
export type WorkflowParameterDetailList = WorkflowParameterDetail[];
export declare const WorkflowParameterDetailList: any;
export interface Workflow {
    arn?: string;
    name?: string;
    version?: string;
    description?: string;
    changeDescription?: string;
    type?: WorkflowType;
    state?: WorkflowState;
    owner?: string;
    data?: string;
    kmsKeyId?: string;
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    parameters?: WorkflowParameterDetail[];
}
export declare const Workflow: S.Schema<Workflow>;
export interface GetWorkflowResponse {
    workflow?: Workflow;
    latestVersionReferences?: LatestVersionReferences;
}
export declare const GetWorkflowResponse: S.Schema<GetWorkflowResponse>;
export type WorkflowExecutionId = string;
export interface GetWorkflowExecutionRequest {
    workflowExecutionId: string;
}
export declare const GetWorkflowExecutionRequest: S.Schema<GetWorkflowExecutionRequest>;
export type WorkflowExecutionStatus = "PENDING" | "SKIPPED" | "RUNNING" | "COMPLETED" | "FAILED" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_COMPLETED" | "CANCELLED" | (string & {});
export declare const WorkflowExecutionStatus: any;
export type WorkflowExecutionMessage = string;
export type WorkflowStepCount = number;
export interface GetWorkflowExecutionResponse {
    requestId?: string;
    workflowBuildVersionArn?: string;
    workflowExecutionId?: string;
    imageBuildVersionArn?: string;
    type?: WorkflowType;
    status?: WorkflowExecutionStatus;
    message?: string;
    totalStepCount?: number;
    totalStepsSucceeded?: number;
    totalStepsFailed?: number;
    totalStepsSkipped?: number;
    startTime?: string;
    endTime?: string;
    parallelGroup?: string;
}
export declare const GetWorkflowExecutionResponse: S.Schema<GetWorkflowExecutionResponse>;
export type WorkflowStepExecutionId = string;
export interface GetWorkflowStepExecutionRequest {
    stepExecutionId: string;
}
export declare const GetWorkflowStepExecutionRequest: S.Schema<GetWorkflowStepExecutionRequest>;
export type WorkflowStepName = string;
export type WorkflowStepDescription = string;
export type WorkflowStepAction = string;
export type WorkflowStepExecutionStatus = "PENDING" | "SKIPPED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED" | (string & {});
export declare const WorkflowStepExecutionStatus: any;
export type WorkflowStepExecutionRollbackStatus = "RUNNING" | "COMPLETED" | "SKIPPED" | "FAILED" | (string & {});
export declare const WorkflowStepExecutionRollbackStatus: any;
export type WorkflowStepMessage = string;
export type WorkflowStepInputs = string;
export type WorkflowStepOutputs = string;
export type WorkflowStepTimeoutSecondsInteger = number;
export interface GetWorkflowStepExecutionResponse {
    requestId?: string;
    stepExecutionId?: string;
    workflowBuildVersionArn?: string;
    workflowExecutionId?: string;
    imageBuildVersionArn?: string;
    name?: string;
    description?: string;
    action?: string;
    status?: WorkflowStepExecutionStatus;
    rollbackStatus?: WorkflowStepExecutionRollbackStatus;
    message?: string;
    inputs?: string;
    outputs?: string;
    startTime?: string;
    endTime?: string;
    onFailure?: string;
    timeoutSeconds?: number;
}
export declare const GetWorkflowStepExecutionResponse: S.Schema<GetWorkflowStepExecutionResponse>;
export type ComponentFormat = "SHELL" | (string & {});
export declare const ComponentFormat: any;
export interface ImportComponentRequest {
    name: string;
    semanticVersion: string;
    description?: string;
    changeDescription?: string;
    type: ComponentType;
    format: ComponentFormat;
    platform: Platform;
    data?: string;
    uri?: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
}
export declare const ImportComponentRequest: S.Schema<ImportComponentRequest>;
export interface ImportComponentResponse {
    requestId?: string;
    clientToken?: string;
    componentBuildVersionArn?: string;
}
export declare const ImportComponentResponse: S.Schema<ImportComponentResponse>;
export type UefiData = string;
export interface RegisterImageOptions {
    secureBootEnabled?: boolean;
    uefiData?: string;
}
export declare const RegisterImageOptions: S.Schema<RegisterImageOptions>;
export type WindowsConfigurationImageIndex = number;
export interface WindowsConfiguration {
    imageIndex: number;
}
export declare const WindowsConfiguration: S.Schema<WindowsConfiguration>;
export interface ImportDiskImageRequest {
    name: string;
    semanticVersion: string;
    description?: string;
    platform: string;
    osVersion: string;
    executionRole?: string;
    infrastructureConfigurationArn: string;
    uri: string;
    loggingConfiguration?: ImageLoggingConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
    registerImageOptions?: RegisterImageOptions;
    windowsConfiguration?: WindowsConfiguration;
    clientToken: string;
}
export declare const ImportDiskImageRequest: S.Schema<ImportDiskImageRequest>;
export interface ImportDiskImageResponse {
    clientToken?: string;
    imageBuildVersionArn?: string;
}
export declare const ImportDiskImageResponse: S.Schema<ImportDiskImageResponse>;
export interface ImportVmImageRequest {
    name: string;
    semanticVersion: string;
    description?: string;
    platform: Platform;
    osVersion?: string;
    vmImportTaskId: string;
    loggingConfiguration?: ImageLoggingConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
}
export declare const ImportVmImageRequest: S.Schema<ImportVmImageRequest>;
export interface ImportVmImageResponse {
    requestId?: string;
    imageArn?: string;
    clientToken?: string;
}
export declare const ImportVmImageResponse: S.Schema<ImportVmImageResponse>;
export type ComponentVersionArn = string;
export type RestrictedInteger = number;
export type PaginationToken = string;
export interface ListComponentBuildVersionsRequest {
    componentVersionArn?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListComponentBuildVersionsRequest: S.Schema<ListComponentBuildVersionsRequest>;
export interface ComponentSummary {
    arn?: string;
    name?: string;
    version?: string;
    platform?: Platform;
    supportedOsVersions?: string[];
    state?: ComponentState;
    type?: ComponentType;
    owner?: string;
    description?: string;
    changeDescription?: string;
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    publisher?: string;
    obfuscate?: boolean;
}
export declare const ComponentSummary: S.Schema<ComponentSummary>;
export type ComponentSummaryList = ComponentSummary[];
export declare const ComponentSummaryList: any;
export interface ListComponentBuildVersionsResponse {
    requestId?: string;
    componentSummaryList?: ComponentSummary[];
    nextToken?: string;
}
export declare const ListComponentBuildVersionsResponse: S.Schema<ListComponentBuildVersionsResponse>;
export type Ownership = "Self" | "Shared" | "Amazon" | "ThirdParty" | "AWSMarketplace" | (string & {});
export declare const Ownership: any;
export type FilterName = string;
export type FilterValue = string;
export type FilterValues = string[];
export declare const FilterValues: any;
export interface Filter {
    name?: string;
    values?: string[];
}
export declare const Filter: S.Schema<Filter>;
export type FilterList = Filter[];
export declare const FilterList: any;
export interface ListComponentsRequest {
    owner?: Ownership;
    filters?: Filter[];
    byName?: boolean;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListComponentsRequest: S.Schema<ListComponentsRequest>;
export interface ComponentVersion {
    arn?: string;
    name?: string;
    version?: string;
    description?: string;
    platform?: Platform;
    supportedOsVersions?: string[];
    type?: ComponentType;
    owner?: string;
    dateCreated?: string;
    status?: ComponentStatus;
    productCodes?: ProductCodeListItem[];
}
export declare const ComponentVersion: S.Schema<ComponentVersion>;
export type ComponentVersionList = ComponentVersion[];
export declare const ComponentVersionList: any;
export interface ListComponentsResponse {
    requestId?: string;
    componentVersionList?: ComponentVersion[];
    nextToken?: string;
}
export declare const ListComponentsResponse: S.Schema<ListComponentsResponse>;
export interface ListContainerRecipesRequest {
    owner?: Ownership;
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListContainerRecipesRequest: S.Schema<ListContainerRecipesRequest>;
export interface ContainerRecipeSummary {
    arn?: string;
    containerType?: ContainerType;
    name?: string;
    platform?: Platform;
    owner?: string;
    parentImage?: string;
    dateCreated?: string;
    instanceImage?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ContainerRecipeSummary: S.Schema<ContainerRecipeSummary>;
export type ContainerRecipeSummaryList = ContainerRecipeSummary[];
export declare const ContainerRecipeSummaryList: any;
export interface ListContainerRecipesResponse {
    requestId?: string;
    containerRecipeSummaryList?: ContainerRecipeSummary[];
    nextToken?: string;
}
export declare const ListContainerRecipesResponse: S.Schema<ListContainerRecipesResponse>;
export interface ListDistributionConfigurationsRequest {
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDistributionConfigurationsRequest: S.Schema<ListDistributionConfigurationsRequest>;
export type RegionList = string[];
export declare const RegionList: any;
export interface DistributionConfigurationSummary {
    arn?: string;
    name?: string;
    description?: string;
    dateCreated?: string;
    dateUpdated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    regions?: string[];
}
export declare const DistributionConfigurationSummary: S.Schema<DistributionConfigurationSummary>;
export type DistributionConfigurationSummaryList = DistributionConfigurationSummary[];
export declare const DistributionConfigurationSummaryList: any;
export interface ListDistributionConfigurationsResponse {
    requestId?: string;
    distributionConfigurationSummaryList?: DistributionConfigurationSummary[];
    nextToken?: string;
}
export declare const ListDistributionConfigurationsResponse: S.Schema<ListDistributionConfigurationsResponse>;
export type ImageVersionArn = string;
export interface ListImageBuildVersionsRequest {
    imageVersionArn?: string;
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListImageBuildVersionsRequest: S.Schema<ListImageBuildVersionsRequest>;
export interface ImageSummary {
    arn?: string;
    name?: string;
    type?: ImageType;
    version?: string;
    platform?: Platform;
    osVersion?: string;
    state?: ImageState;
    owner?: string;
    dateCreated?: string;
    outputResources?: OutputResources;
    tags?: {
        [key: string]: string | undefined;
    };
    buildType?: BuildType;
    imageSource?: ImageSource;
    deprecationTime?: Date;
    lifecycleExecutionId?: string;
    loggingConfiguration?: ImageLoggingConfiguration;
}
export declare const ImageSummary: S.Schema<ImageSummary>;
export type ImageSummaryList = ImageSummary[];
export declare const ImageSummaryList: any;
export interface ListImageBuildVersionsResponse {
    requestId?: string;
    imageSummaryList?: ImageSummary[];
    nextToken?: string;
}
export declare const ListImageBuildVersionsResponse: S.Schema<ListImageBuildVersionsResponse>;
export interface ListImagePackagesRequest {
    imageBuildVersionArn: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListImagePackagesRequest: S.Schema<ListImagePackagesRequest>;
export interface ImagePackage {
    packageName?: string;
    packageVersion?: string;
}
export declare const ImagePackage: S.Schema<ImagePackage>;
export type ImagePackageList = ImagePackage[];
export declare const ImagePackageList: any;
export interface ListImagePackagesResponse {
    requestId?: string;
    imagePackageList?: ImagePackage[];
    nextToken?: string;
}
export declare const ListImagePackagesResponse: S.Schema<ListImagePackagesResponse>;
export interface ListImagePipelineImagesRequest {
    imagePipelineArn: string;
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListImagePipelineImagesRequest: S.Schema<ListImagePipelineImagesRequest>;
export interface ListImagePipelineImagesResponse {
    requestId?: string;
    imageSummaryList?: ImageSummary[];
    nextToken?: string;
}
export declare const ListImagePipelineImagesResponse: S.Schema<ListImagePipelineImagesResponse>;
export interface ListImagePipelinesRequest {
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListImagePipelinesRequest: S.Schema<ListImagePipelinesRequest>;
export type ImagePipelineList = ImagePipeline[];
export declare const ImagePipelineList: any;
export interface ListImagePipelinesResponse {
    requestId?: string;
    imagePipelineList?: ImagePipeline[];
    nextToken?: string;
}
export declare const ListImagePipelinesResponse: S.Schema<ListImagePipelinesResponse>;
export interface ListImageRecipesRequest {
    owner?: Ownership;
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListImageRecipesRequest: S.Schema<ListImageRecipesRequest>;
export interface ImageRecipeSummary {
    arn?: string;
    name?: string;
    platform?: Platform;
    owner?: string;
    parentImage?: string;
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ImageRecipeSummary: S.Schema<ImageRecipeSummary>;
export type ImageRecipeSummaryList = ImageRecipeSummary[];
export declare const ImageRecipeSummaryList: any;
export interface ListImageRecipesResponse {
    requestId?: string;
    imageRecipeSummaryList?: ImageRecipeSummary[];
    nextToken?: string;
}
export declare const ListImageRecipesResponse: S.Schema<ListImageRecipesResponse>;
export interface ListImagesRequest {
    owner?: Ownership;
    filters?: Filter[];
    byName?: boolean;
    maxResults?: number;
    nextToken?: string;
    includeDeprecated?: boolean;
}
export declare const ListImagesRequest: S.Schema<ListImagesRequest>;
export interface ImageVersion {
    arn?: string;
    name?: string;
    type?: ImageType;
    version?: string;
    platform?: Platform;
    osVersion?: string;
    owner?: string;
    dateCreated?: string;
    buildType?: BuildType;
    imageSource?: ImageSource;
}
export declare const ImageVersion: S.Schema<ImageVersion>;
export type ImageVersionList = ImageVersion[];
export declare const ImageVersionList: any;
export interface ListImagesResponse {
    requestId?: string;
    imageVersionList?: ImageVersion[];
    nextToken?: string;
}
export declare const ListImagesResponse: S.Schema<ListImagesResponse>;
export interface ListImageScanFindingAggregationsRequest {
    filter?: Filter;
    nextToken?: string;
}
export declare const ListImageScanFindingAggregationsRequest: S.Schema<ListImageScanFindingAggregationsRequest>;
export type SeverityCountNumber = number;
export interface SeverityCounts {
    all?: number;
    critical?: number;
    high?: number;
    medium?: number;
}
export declare const SeverityCounts: S.Schema<SeverityCounts>;
export interface AccountAggregation {
    accountId?: string;
    severityCounts?: SeverityCounts;
}
export declare const AccountAggregation: S.Schema<AccountAggregation>;
export interface ImageAggregation {
    imageBuildVersionArn?: string;
    severityCounts?: SeverityCounts;
}
export declare const ImageAggregation: S.Schema<ImageAggregation>;
export interface ImagePipelineAggregation {
    imagePipelineArn?: string;
    severityCounts?: SeverityCounts;
}
export declare const ImagePipelineAggregation: S.Schema<ImagePipelineAggregation>;
export interface VulnerabilityIdAggregation {
    vulnerabilityId?: string;
    severityCounts?: SeverityCounts;
}
export declare const VulnerabilityIdAggregation: S.Schema<VulnerabilityIdAggregation>;
export interface ImageScanFindingAggregation {
    accountAggregation?: AccountAggregation;
    imageAggregation?: ImageAggregation;
    imagePipelineAggregation?: ImagePipelineAggregation;
    vulnerabilityIdAggregation?: VulnerabilityIdAggregation;
}
export declare const ImageScanFindingAggregation: S.Schema<ImageScanFindingAggregation>;
export type ImageScanFindingAggregationsList = ImageScanFindingAggregation[];
export declare const ImageScanFindingAggregationsList: any;
export interface ListImageScanFindingAggregationsResponse {
    requestId?: string;
    aggregationType?: string;
    responses?: ImageScanFindingAggregation[];
    nextToken?: string;
}
export declare const ListImageScanFindingAggregationsResponse: S.Schema<ListImageScanFindingAggregationsResponse>;
export type ImageScanFindingsFilterValues = string[];
export declare const ImageScanFindingsFilterValues: any;
export interface ImageScanFindingsFilter {
    name?: string;
    values?: string[];
}
export declare const ImageScanFindingsFilter: S.Schema<ImageScanFindingsFilter>;
export type ImageScanFindingsFilterList = ImageScanFindingsFilter[];
export declare const ImageScanFindingsFilterList: any;
export interface ListImageScanFindingsRequest {
    filters?: ImageScanFindingsFilter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListImageScanFindingsRequest: S.Schema<ListImageScanFindingsRequest>;
export interface RemediationRecommendation {
    text?: string;
    url?: string;
}
export declare const RemediationRecommendation: S.Schema<RemediationRecommendation>;
export interface Remediation {
    recommendation?: RemediationRecommendation;
}
export declare const Remediation: S.Schema<Remediation>;
export type NonNegativeDouble = number;
export interface CvssScoreAdjustment {
    metric?: string;
    reason?: string;
}
export declare const CvssScoreAdjustment: S.Schema<CvssScoreAdjustment>;
export type CvssScoreAdjustmentList = CvssScoreAdjustment[];
export declare const CvssScoreAdjustmentList: any;
export interface CvssScoreDetails {
    scoreSource?: string;
    cvssSource?: string;
    version?: string;
    score?: number;
    scoringVector?: string;
    adjustments?: CvssScoreAdjustment[];
}
export declare const CvssScoreDetails: S.Schema<CvssScoreDetails>;
export interface InspectorScoreDetails {
    adjustedCvss?: CvssScoreDetails;
}
export declare const InspectorScoreDetails: S.Schema<InspectorScoreDetails>;
export type VulnerabilityId = string;
export type SourceLayerHash = string;
export type PackageEpoch = number;
export type PackageArchitecture = string;
export interface VulnerablePackage {
    name?: string;
    version?: string;
    sourceLayerHash?: string;
    epoch?: number;
    release?: string;
    arch?: string;
    packageManager?: string;
    filePath?: string;
    fixedInVersion?: string;
    remediation?: string;
}
export declare const VulnerablePackage: S.Schema<VulnerablePackage>;
export type VulnerablePackageList = VulnerablePackage[];
export declare const VulnerablePackageList: any;
export interface CvssScore {
    baseScore?: number;
    scoringVector?: string;
    version?: string;
    source?: string;
}
export declare const CvssScore: S.Schema<CvssScore>;
export type CvssScoreList = CvssScore[];
export declare const CvssScoreList: any;
export type VulnerabilityIdList = string[];
export declare const VulnerabilityIdList: any;
export type NonEmptyStringList = string[];
export declare const NonEmptyStringList: any;
export interface PackageVulnerabilityDetails {
    vulnerabilityId: string;
    vulnerablePackages?: VulnerablePackage[];
    source?: string;
    cvss?: CvssScore[];
    relatedVulnerabilities?: string[];
    sourceUrl?: string;
    vendorSeverity?: string;
    vendorCreatedAt?: Date;
    vendorUpdatedAt?: Date;
    referenceUrls?: string[];
}
export declare const PackageVulnerabilityDetails: S.Schema<PackageVulnerabilityDetails>;
export interface ImageScanFinding {
    awsAccountId?: string;
    imageBuildVersionArn?: string;
    imagePipelineArn?: string;
    type?: string;
    description?: string;
    title?: string;
    remediation?: Remediation;
    severity?: string;
    firstObservedAt?: Date;
    updatedAt?: Date;
    inspectorScore?: number;
    inspectorScoreDetails?: InspectorScoreDetails;
    packageVulnerabilityDetails?: PackageVulnerabilityDetails;
    fixAvailable?: string;
}
export declare const ImageScanFinding: S.Schema<ImageScanFinding>;
export type ImageScanFindingsList = ImageScanFinding[];
export declare const ImageScanFindingsList: any;
export interface ListImageScanFindingsResponse {
    requestId?: string;
    findings?: ImageScanFinding[];
    nextToken?: string;
}
export declare const ListImageScanFindingsResponse: S.Schema<ListImageScanFindingsResponse>;
export interface ListInfrastructureConfigurationsRequest {
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListInfrastructureConfigurationsRequest: S.Schema<ListInfrastructureConfigurationsRequest>;
export interface InfrastructureConfigurationSummary {
    arn?: string;
    name?: string;
    description?: string;
    dateCreated?: string;
    dateUpdated?: string;
    resourceTags?: {
        [key: string]: string | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
    instanceTypes?: string[];
    instanceProfileName?: string;
    placement?: Placement;
}
export declare const InfrastructureConfigurationSummary: S.Schema<InfrastructureConfigurationSummary>;
export type InfrastructureConfigurationSummaryList = InfrastructureConfigurationSummary[];
export declare const InfrastructureConfigurationSummaryList: any;
export interface ListInfrastructureConfigurationsResponse {
    requestId?: string;
    infrastructureConfigurationSummaryList?: InfrastructureConfigurationSummary[];
    nextToken?: string;
}
export declare const ListInfrastructureConfigurationsResponse: S.Schema<ListInfrastructureConfigurationsResponse>;
export interface ListLifecycleExecutionResourcesRequest {
    lifecycleExecutionId: string;
    parentResourceId?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListLifecycleExecutionResourcesRequest: S.Schema<ListLifecycleExecutionResourcesRequest>;
export type LifecycleExecutionResourceStatus = "FAILED" | "IN_PROGRESS" | "SKIPPED" | "SUCCESS" | (string & {});
export declare const LifecycleExecutionResourceStatus: any;
export interface LifecycleExecutionResourceState {
    status?: LifecycleExecutionResourceStatus;
    reason?: string;
}
export declare const LifecycleExecutionResourceState: S.Schema<LifecycleExecutionResourceState>;
export type LifecycleExecutionResourceActionName = "AVAILABLE" | "DELETE" | "DEPRECATE" | "DISABLE" | (string & {});
export declare const LifecycleExecutionResourceActionName: any;
export interface LifecycleExecutionResourceAction {
    name?: LifecycleExecutionResourceActionName;
    reason?: string;
}
export declare const LifecycleExecutionResourceAction: S.Schema<LifecycleExecutionResourceAction>;
export interface LifecycleExecutionSnapshotResource {
    snapshotId?: string;
    state?: LifecycleExecutionResourceState;
}
export declare const LifecycleExecutionSnapshotResource: S.Schema<LifecycleExecutionSnapshotResource>;
export type LifecycleExecutionSnapshotResourceList = LifecycleExecutionSnapshotResource[];
export declare const LifecycleExecutionSnapshotResourceList: any;
export interface LifecycleExecutionResource {
    accountId?: string;
    resourceId?: string;
    state?: LifecycleExecutionResourceState;
    action?: LifecycleExecutionResourceAction;
    region?: string;
    snapshots?: LifecycleExecutionSnapshotResource[];
    imageUris?: string[];
    startTime?: Date;
    endTime?: Date;
}
export declare const LifecycleExecutionResource: S.Schema<LifecycleExecutionResource>;
export type LifecycleExecutionResourceList = LifecycleExecutionResource[];
export declare const LifecycleExecutionResourceList: any;
export interface ListLifecycleExecutionResourcesResponse {
    lifecycleExecutionId?: string;
    lifecycleExecutionState?: LifecycleExecutionState;
    resources?: LifecycleExecutionResource[];
    nextToken?: string;
}
export declare const ListLifecycleExecutionResourcesResponse: S.Schema<ListLifecycleExecutionResourcesResponse>;
export interface ListLifecycleExecutionsRequest {
    maxResults?: number;
    nextToken?: string;
    resourceArn: string;
}
export declare const ListLifecycleExecutionsRequest: S.Schema<ListLifecycleExecutionsRequest>;
export type LifecycleExecutionsList = LifecycleExecution[];
export declare const LifecycleExecutionsList: any;
export interface ListLifecycleExecutionsResponse {
    lifecycleExecutions?: LifecycleExecution[];
    nextToken?: string;
}
export declare const ListLifecycleExecutionsResponse: S.Schema<ListLifecycleExecutionsResponse>;
export interface ListLifecyclePoliciesRequest {
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListLifecyclePoliciesRequest: S.Schema<ListLifecyclePoliciesRequest>;
export interface LifecyclePolicySummary {
    arn?: string;
    name?: string;
    description?: string;
    status?: LifecyclePolicyStatus;
    executionRole?: string;
    resourceType?: LifecyclePolicyResourceType;
    dateCreated?: Date;
    dateUpdated?: Date;
    dateLastRun?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const LifecyclePolicySummary: S.Schema<LifecyclePolicySummary>;
export type LifecyclePolicySummaryList = LifecyclePolicySummary[];
export declare const LifecyclePolicySummaryList: any;
export interface ListLifecyclePoliciesResponse {
    lifecyclePolicySummaryList?: LifecyclePolicySummary[];
    nextToken?: string;
}
export declare const ListLifecyclePoliciesResponse: S.Schema<ListLifecyclePoliciesResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListWaitingWorkflowStepsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListWaitingWorkflowStepsRequest: S.Schema<ListWaitingWorkflowStepsRequest>;
export interface WorkflowStepExecution {
    stepExecutionId?: string;
    imageBuildVersionArn?: string;
    workflowExecutionId?: string;
    workflowBuildVersionArn?: string;
    name?: string;
    action?: string;
    startTime?: string;
}
export declare const WorkflowStepExecution: S.Schema<WorkflowStepExecution>;
export type WorkflowStepExecutionList = WorkflowStepExecution[];
export declare const WorkflowStepExecutionList: any;
export interface ListWaitingWorkflowStepsResponse {
    steps?: WorkflowStepExecution[];
    nextToken?: string;
}
export declare const ListWaitingWorkflowStepsResponse: S.Schema<ListWaitingWorkflowStepsResponse>;
export type WorkflowWildcardVersionArn = string;
export interface ListWorkflowBuildVersionsRequest {
    workflowVersionArn?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListWorkflowBuildVersionsRequest: S.Schema<ListWorkflowBuildVersionsRequest>;
export type WorkflowNameArn = string;
export interface WorkflowSummary {
    arn?: string;
    name?: string;
    version?: string;
    description?: string;
    changeDescription?: string;
    type?: WorkflowType;
    owner?: string;
    state?: WorkflowState;
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const WorkflowSummary: S.Schema<WorkflowSummary>;
export type WorkflowSummaryList = WorkflowSummary[];
export declare const WorkflowSummaryList: any;
export interface ListWorkflowBuildVersionsResponse {
    workflowSummaryList?: WorkflowSummary[];
    nextToken?: string;
}
export declare const ListWorkflowBuildVersionsResponse: S.Schema<ListWorkflowBuildVersionsResponse>;
export interface ListWorkflowExecutionsRequest {
    maxResults?: number;
    nextToken?: string;
    imageBuildVersionArn: string;
}
export declare const ListWorkflowExecutionsRequest: S.Schema<ListWorkflowExecutionsRequest>;
export interface WorkflowExecutionMetadata {
    workflowBuildVersionArn?: string;
    workflowExecutionId?: string;
    type?: WorkflowType;
    status?: WorkflowExecutionStatus;
    message?: string;
    totalStepCount?: number;
    totalStepsSucceeded?: number;
    totalStepsFailed?: number;
    totalStepsSkipped?: number;
    startTime?: string;
    endTime?: string;
    parallelGroup?: string;
    retried?: boolean;
}
export declare const WorkflowExecutionMetadata: S.Schema<WorkflowExecutionMetadata>;
export type WorkflowExecutionsList = WorkflowExecutionMetadata[];
export declare const WorkflowExecutionsList: any;
export type ImageBuildMessage = string;
export interface ListWorkflowExecutionsResponse {
    requestId?: string;
    workflowExecutions?: WorkflowExecutionMetadata[];
    imageBuildVersionArn?: string;
    message?: string;
    nextToken?: string;
}
export declare const ListWorkflowExecutionsResponse: S.Schema<ListWorkflowExecutionsResponse>;
export interface ListWorkflowsRequest {
    owner?: Ownership;
    filters?: Filter[];
    byName?: boolean;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListWorkflowsRequest: S.Schema<ListWorkflowsRequest>;
export type WorkflowVersionArn = string;
export interface WorkflowVersion {
    arn?: string;
    name?: string;
    version?: string;
    description?: string;
    type?: WorkflowType;
    owner?: string;
    dateCreated?: string;
}
export declare const WorkflowVersion: S.Schema<WorkflowVersion>;
export type WorkflowVersionList = WorkflowVersion[];
export declare const WorkflowVersionList: any;
export interface ListWorkflowsResponse {
    workflowVersionList?: WorkflowVersion[];
    nextToken?: string;
}
export declare const ListWorkflowsResponse: S.Schema<ListWorkflowsResponse>;
export interface ListWorkflowStepExecutionsRequest {
    maxResults?: number;
    nextToken?: string;
    workflowExecutionId: string;
}
export declare const ListWorkflowStepExecutionsRequest: S.Schema<ListWorkflowStepExecutionsRequest>;
export interface WorkflowStepMetadata {
    stepExecutionId?: string;
    name?: string;
    description?: string;
    action?: string;
    status?: WorkflowStepExecutionStatus;
    rollbackStatus?: WorkflowStepExecutionRollbackStatus;
    message?: string;
    inputs?: string;
    outputs?: string;
    startTime?: string;
    endTime?: string;
}
export declare const WorkflowStepMetadata: S.Schema<WorkflowStepMetadata>;
export type WorkflowStepExecutionsList = WorkflowStepMetadata[];
export declare const WorkflowStepExecutionsList: any;
export interface ListWorkflowStepExecutionsResponse {
    requestId?: string;
    steps?: WorkflowStepMetadata[];
    workflowBuildVersionArn?: string;
    workflowExecutionId?: string;
    imageBuildVersionArn?: string;
    message?: string;
    nextToken?: string;
}
export declare const ListWorkflowStepExecutionsResponse: S.Schema<ListWorkflowStepExecutionsResponse>;
export interface PutComponentPolicyRequest {
    componentArn: string;
    policy: string;
}
export declare const PutComponentPolicyRequest: S.Schema<PutComponentPolicyRequest>;
export interface PutComponentPolicyResponse {
    requestId?: string;
    componentArn?: string;
}
export declare const PutComponentPolicyResponse: S.Schema<PutComponentPolicyResponse>;
export interface PutContainerRecipePolicyRequest {
    containerRecipeArn: string;
    policy: string;
}
export declare const PutContainerRecipePolicyRequest: S.Schema<PutContainerRecipePolicyRequest>;
export interface PutContainerRecipePolicyResponse {
    requestId?: string;
    containerRecipeArn?: string;
}
export declare const PutContainerRecipePolicyResponse: S.Schema<PutContainerRecipePolicyResponse>;
export interface PutImagePolicyRequest {
    imageArn: string;
    policy: string;
}
export declare const PutImagePolicyRequest: S.Schema<PutImagePolicyRequest>;
export interface PutImagePolicyResponse {
    requestId?: string;
    imageArn?: string;
}
export declare const PutImagePolicyResponse: S.Schema<PutImagePolicyResponse>;
export interface PutImageRecipePolicyRequest {
    imageRecipeArn: string;
    policy: string;
}
export declare const PutImageRecipePolicyRequest: S.Schema<PutImageRecipePolicyRequest>;
export interface PutImageRecipePolicyResponse {
    requestId?: string;
    imageRecipeArn?: string;
}
export declare const PutImageRecipePolicyResponse: S.Schema<PutImageRecipePolicyResponse>;
export interface RetryImageRequest {
    imageBuildVersionArn: string;
    clientToken: string;
}
export declare const RetryImageRequest: S.Schema<RetryImageRequest>;
export interface RetryImageResponse {
    clientToken?: string;
    imageBuildVersionArn?: string;
}
export declare const RetryImageResponse: S.Schema<RetryImageResponse>;
export type WorkflowStepActionType = "RESUME" | "STOP" | (string & {});
export declare const WorkflowStepActionType: any;
export interface SendWorkflowStepActionRequest {
    stepExecutionId: string;
    imageBuildVersionArn: string;
    action: WorkflowStepActionType;
    reason?: string;
    clientToken: string;
}
export declare const SendWorkflowStepActionRequest: S.Schema<SendWorkflowStepActionRequest>;
export interface SendWorkflowStepActionResponse {
    stepExecutionId?: string;
    imageBuildVersionArn?: string;
    clientToken?: string;
}
export declare const SendWorkflowStepActionResponse: S.Schema<SendWorkflowStepActionResponse>;
export interface StartImagePipelineExecutionRequest {
    imagePipelineArn: string;
    clientToken: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StartImagePipelineExecutionRequest: S.Schema<StartImagePipelineExecutionRequest>;
export interface StartImagePipelineExecutionResponse {
    requestId?: string;
    clientToken?: string;
    imageBuildVersionArn?: string;
}
export declare const StartImagePipelineExecutionResponse: S.Schema<StartImagePipelineExecutionResponse>;
export type ResourceStatus = "AVAILABLE" | "DELETED" | "DEPRECATED" | "DISABLED" | (string & {});
export declare const ResourceStatus: any;
export interface ResourceState {
    status?: ResourceStatus;
}
export declare const ResourceState: S.Schema<ResourceState>;
export interface ResourceStateUpdateIncludeResources {
    amis?: boolean;
    snapshots?: boolean;
    containers?: boolean;
}
export declare const ResourceStateUpdateIncludeResources: S.Schema<ResourceStateUpdateIncludeResources>;
export interface ResourceStateUpdateExclusionRules {
    amis?: LifecyclePolicyDetailExclusionRulesAmis;
}
export declare const ResourceStateUpdateExclusionRules: S.Schema<ResourceStateUpdateExclusionRules>;
export interface StartResourceStateUpdateRequest {
    resourceArn: string;
    state: ResourceState;
    executionRole?: string;
    includeResources?: ResourceStateUpdateIncludeResources;
    exclusionRules?: ResourceStateUpdateExclusionRules;
    updateAt?: Date;
    clientToken: string;
}
export declare const StartResourceStateUpdateRequest: S.Schema<StartResourceStateUpdateRequest>;
export interface StartResourceStateUpdateResponse {
    lifecycleExecutionId?: string;
    resourceArn?: string;
}
export declare const StartResourceStateUpdateResponse: S.Schema<StartResourceStateUpdateResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateDistributionConfigurationRequest {
    distributionConfigurationArn: string;
    description?: string;
    distributions: Distribution[];
    clientToken: string;
}
export declare const UpdateDistributionConfigurationRequest: S.Schema<UpdateDistributionConfigurationRequest>;
export interface UpdateDistributionConfigurationResponse {
    requestId?: string;
    clientToken?: string;
    distributionConfigurationArn?: string;
}
export declare const UpdateDistributionConfigurationResponse: S.Schema<UpdateDistributionConfigurationResponse>;
export interface UpdateImagePipelineRequest {
    imagePipelineArn: string;
    description?: string;
    imageRecipeArn?: string;
    containerRecipeArn?: string;
    infrastructureConfigurationArn: string;
    distributionConfigurationArn?: string;
    imageTestsConfiguration?: ImageTestsConfiguration;
    enhancedImageMetadataEnabled?: boolean;
    schedule?: Schedule;
    status?: PipelineStatus;
    clientToken: string;
    imageScanningConfiguration?: ImageScanningConfiguration;
    workflows?: WorkflowConfiguration[];
    loggingConfiguration?: PipelineLoggingConfiguration;
    executionRole?: string;
    imageTags?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateImagePipelineRequest: S.Schema<UpdateImagePipelineRequest>;
export interface UpdateImagePipelineResponse {
    requestId?: string;
    clientToken?: string;
    imagePipelineArn?: string;
}
export declare const UpdateImagePipelineResponse: S.Schema<UpdateImagePipelineResponse>;
export interface UpdateInfrastructureConfigurationRequest {
    infrastructureConfigurationArn: string;
    description?: string;
    instanceTypes?: string[];
    instanceProfileName: string;
    securityGroupIds?: string[];
    subnetId?: string;
    logging?: Logging;
    keyPair?: string;
    terminateInstanceOnFailure?: boolean;
    snsTopicArn?: string;
    resourceTags?: {
        [key: string]: string | undefined;
    };
    instanceMetadataOptions?: InstanceMetadataOptions;
    placement?: Placement;
    clientToken: string;
}
export declare const UpdateInfrastructureConfigurationRequest: S.Schema<UpdateInfrastructureConfigurationRequest>;
export interface UpdateInfrastructureConfigurationResponse {
    requestId?: string;
    clientToken?: string;
    infrastructureConfigurationArn?: string;
}
export declare const UpdateInfrastructureConfigurationResponse: S.Schema<UpdateInfrastructureConfigurationResponse>;
export interface UpdateLifecyclePolicyRequest {
    lifecyclePolicyArn: string;
    description?: string;
    status?: LifecyclePolicyStatus;
    executionRole: string;
    resourceType: LifecyclePolicyResourceType;
    policyDetails: LifecyclePolicyDetail[];
    resourceSelection: LifecyclePolicyResourceSelection;
    clientToken: string;
}
export declare const UpdateLifecyclePolicyRequest: S.Schema<UpdateLifecyclePolicyRequest>;
export interface UpdateLifecyclePolicyResponse {
    lifecyclePolicyArn?: string;
}
export declare const UpdateLifecyclePolicyResponse: S.Schema<UpdateLifecyclePolicyResponse>;
export type ErrorMessage = string;
export type CancelImageCreationError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * CancelImageCreation cancels the creation of Image. This operation can only be used on
 * images in a non-terminal state.
 */
export declare const cancelImageCreation: API.OperationMethod<CancelImageCreationRequest, CancelImageCreationResponse, CancelImageCreationError, Credentials | HttpClient.HttpClient>;
export type CancelLifecycleExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Cancel a specific image lifecycle policy runtime instance.
 */
export declare const cancelLifecycleExecution: API.OperationMethod<CancelLifecycleExecutionRequest, CancelLifecycleExecutionResponse, CancelLifecycleExecutionError, Credentials | HttpClient.HttpClient>;
export type CreateComponentError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | InvalidVersionNumberException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new component that can be used to build, validate, test, and assess your
 * image. The component is based on a YAML document that you specify using exactly one of
 * the following methods:
 *
 * - Inline, using the `data` property in the request body.
 *
 * - A URL that points to a YAML document file stored in Amazon S3, using the
 * `uri` property in the request body.
 */
export declare const createComponent: API.OperationMethod<CreateComponentRequest, CreateComponentResponse, CreateComponentError, Credentials | HttpClient.HttpClient>;
export type CreateContainerRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | InvalidVersionNumberException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new container recipe. Container recipes define how images are configured,
 * tested, and assessed.
 */
export declare const createContainerRecipe: API.OperationMethod<CreateContainerRecipeRequest, CreateContainerRecipeResponse, CreateContainerRecipeError, Credentials | HttpClient.HttpClient>;
export type CreateDistributionConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new distribution configuration. Distribution configurations define and
 * configure the outputs of your pipeline.
 */
export declare const createDistributionConfiguration: API.OperationMethod<CreateDistributionConfigurationRequest, CreateDistributionConfigurationResponse, CreateDistributionConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateImageError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new image. This request will create a new image along with all of the
 * configured output resources defined in the distribution configuration. You must specify
 * exactly one recipe for your image, using either a ContainerRecipeArn or an
 * ImageRecipeArn.
 */
export declare const createImage: API.OperationMethod<CreateImageRequest, CreateImageResponse, CreateImageError, Credentials | HttpClient.HttpClient>;
export type CreateImagePipelineError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new image pipeline. Image pipelines enable you to automate the creation and
 * distribution of images.
 */
export declare const createImagePipeline: API.OperationMethod<CreateImagePipelineRequest, CreateImagePipelineResponse, CreateImagePipelineError, Credentials | HttpClient.HttpClient>;
export type CreateImageRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | InvalidVersionNumberException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new image recipe. Image recipes define how images are configured, tested,
 * and assessed.
 */
export declare const createImageRecipe: API.OperationMethod<CreateImageRecipeRequest, CreateImageRecipeResponse, CreateImageRecipeError, Credentials | HttpClient.HttpClient>;
export type CreateInfrastructureConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | InvalidParameterValueException | CommonErrors;
/**
 * Creates a new infrastructure configuration. An infrastructure configuration defines
 * the environment in which your image will be built and tested.
 */
export declare const createInfrastructureConfiguration: API.OperationMethod<CreateInfrastructureConfigurationRequest, CreateInfrastructureConfigurationResponse, CreateInfrastructureConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateLifecyclePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Create a lifecycle policy resource.
 */
export declare const createLifecyclePolicy: API.OperationMethod<CreateLifecyclePolicyRequest, CreateLifecyclePolicyResponse, CreateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | InvalidVersionNumberException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Create a new workflow or a new version of an existing workflow.
 */
export declare const createWorkflow: API.OperationMethod<CreateWorkflowRequest, CreateWorkflowResponse, CreateWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeleteComponentError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a component build version.
 */
export declare const deleteComponent: API.OperationMethod<DeleteComponentRequest, DeleteComponentResponse, DeleteComponentError, Credentials | HttpClient.HttpClient>;
export type DeleteContainerRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a container recipe.
 */
export declare const deleteContainerRecipe: API.OperationMethod<DeleteContainerRecipeRequest, DeleteContainerRecipeResponse, DeleteContainerRecipeError, Credentials | HttpClient.HttpClient>;
export type DeleteDistributionConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a distribution configuration.
 */
export declare const deleteDistributionConfiguration: API.OperationMethod<DeleteDistributionConfigurationRequest, DeleteDistributionConfigurationResponse, DeleteDistributionConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteImageError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Image Builder image resource. This does not delete any EC2 AMIs or ECR container
 * images that are created during the image build process. You must clean those up
 * separately, using the appropriate Amazon EC2 or Amazon ECR console actions, or API or CLI
 * commands.
 *
 * - To deregister an EC2 Linux AMI, see Deregister your
 * Linux AMI in the
 * *Amazon EC2 User Guide*
 * .
 *
 * - To deregister an EC2 Windows AMI, see Deregister your
 * Windows AMI in the
 * *Amazon EC2 Windows Guide*
 * .
 *
 * - To delete a container image from Amazon ECR, see Deleting
 * an image in the *Amazon ECR User Guide*.
 */
export declare const deleteImage: API.OperationMethod<DeleteImageRequest, DeleteImageResponse, DeleteImageError, Credentials | HttpClient.HttpClient>;
export type DeleteImagePipelineError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an image pipeline.
 */
export declare const deleteImagePipeline: API.OperationMethod<DeleteImagePipelineRequest, DeleteImagePipelineResponse, DeleteImagePipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteImageRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an image recipe.
 */
export declare const deleteImageRecipe: API.OperationMethod<DeleteImageRecipeRequest, DeleteImageRecipeResponse, DeleteImageRecipeError, Credentials | HttpClient.HttpClient>;
export type DeleteInfrastructureConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an infrastructure configuration.
 */
export declare const deleteInfrastructureConfiguration: API.OperationMethod<DeleteInfrastructureConfigurationRequest, DeleteInfrastructureConfigurationResponse, DeleteInfrastructureConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteLifecyclePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Delete the specified lifecycle policy resource.
 */
export declare const deleteLifecyclePolicy: API.OperationMethod<DeleteLifecyclePolicyRequest, DeleteLifecyclePolicyResponse, DeleteLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a specific workflow resource.
 */
export declare const deleteWorkflow: API.OperationMethod<DeleteWorkflowRequest, DeleteWorkflowResponse, DeleteWorkflowError, Credentials | HttpClient.HttpClient>;
export type DistributeImageError = AccessDeniedException | CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Distributes an existing AMI to target Regions and accounts without running
 * the full image build process. This operation only runs the distribution
 * phase on an image that has already been built.
 */
export declare const distributeImage: API.OperationMethod<DistributeImageRequest, DistributeImageResponse, DistributeImageError, Credentials | HttpClient.HttpClient>;
export type GetComponentError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a component object.
 */
export declare const getComponent: API.OperationMethod<GetComponentRequest, GetComponentResponse, GetComponentError, Credentials | HttpClient.HttpClient>;
export type GetComponentPolicyError = CallRateLimitExceededException | ForbiddenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Gets a component policy.
 */
export declare const getComponentPolicy: API.OperationMethod<GetComponentPolicyRequest, GetComponentPolicyResponse, GetComponentPolicyError, Credentials | HttpClient.HttpClient>;
export type GetContainerRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves a container recipe.
 */
export declare const getContainerRecipe: API.OperationMethod<GetContainerRecipeRequest, GetContainerRecipeResponse, GetContainerRecipeError, Credentials | HttpClient.HttpClient>;
export type GetContainerRecipePolicyError = CallRateLimitExceededException | ForbiddenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves the policy for a container recipe.
 */
export declare const getContainerRecipePolicy: API.OperationMethod<GetContainerRecipePolicyRequest, GetContainerRecipePolicyResponse, GetContainerRecipePolicyError, Credentials | HttpClient.HttpClient>;
export type GetDistributionConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a distribution configuration.
 */
export declare const getDistributionConfiguration: API.OperationMethod<GetDistributionConfigurationRequest, GetDistributionConfigurationResponse, GetDistributionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetImageError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Gets an image.
 */
export declare const getImage: API.OperationMethod<GetImageRequest, GetImageResponse, GetImageError, Credentials | HttpClient.HttpClient>;
export type GetImagePipelineError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Gets an image pipeline.
 */
export declare const getImagePipeline: API.OperationMethod<GetImagePipelineRequest, GetImagePipelineResponse, GetImagePipelineError, Credentials | HttpClient.HttpClient>;
export type GetImagePolicyError = CallRateLimitExceededException | ForbiddenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Gets an image policy.
 */
export declare const getImagePolicy: API.OperationMethod<GetImagePolicyRequest, GetImagePolicyResponse, GetImagePolicyError, Credentials | HttpClient.HttpClient>;
export type GetImageRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Gets an image recipe.
 */
export declare const getImageRecipe: API.OperationMethod<GetImageRecipeRequest, GetImageRecipeResponse, GetImageRecipeError, Credentials | HttpClient.HttpClient>;
export type GetImageRecipePolicyError = CallRateLimitExceededException | ForbiddenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Gets an image recipe policy.
 */
export declare const getImageRecipePolicy: API.OperationMethod<GetImageRecipePolicyRequest, GetImageRecipePolicyResponse, GetImageRecipePolicyError, Credentials | HttpClient.HttpClient>;
export type GetInfrastructureConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Gets an infrastructure configuration.
 */
export declare const getInfrastructureConfiguration: API.OperationMethod<GetInfrastructureConfigurationRequest, GetInfrastructureConfigurationResponse, GetInfrastructureConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetLifecycleExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Get the runtime information that was logged for a specific runtime instance of the lifecycle policy.
 */
export declare const getLifecycleExecution: API.OperationMethod<GetLifecycleExecutionRequest, GetLifecycleExecutionResponse, GetLifecycleExecutionError, Credentials | HttpClient.HttpClient>;
export type GetLifecyclePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Get details for the specified image lifecycle policy.
 */
export declare const getLifecyclePolicy: API.OperationMethod<GetLifecyclePolicyRequest, GetLifecyclePolicyResponse, GetLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type GetMarketplaceResourceError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Verify the subscription and perform resource dependency checks on the requested
 * Amazon Web Services Marketplace resource. For Amazon Web Services Marketplace components, the response contains fields to download the
 * components and their artifacts.
 */
export declare const getMarketplaceResource: API.OperationMethod<GetMarketplaceResourceRequest, GetMarketplaceResourceResponse, GetMarketplaceResourceError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Get a workflow resource object.
 */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest, GetWorkflowResponse, GetWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Get the runtime information that was logged for a specific runtime instance
 * of the workflow.
 */
export declare const getWorkflowExecution: API.OperationMethod<GetWorkflowExecutionRequest, GetWorkflowExecutionResponse, GetWorkflowExecutionError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowStepExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Get the runtime information that was logged for a specific runtime instance of
 * the workflow step.
 */
export declare const getWorkflowStepExecution: API.OperationMethod<GetWorkflowStepExecutionRequest, GetWorkflowStepExecutionResponse, GetWorkflowStepExecutionError, Credentials | HttpClient.HttpClient>;
export type ImportComponentError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | InvalidVersionNumberException | ResourceInUseException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Imports a component and transforms its data into a component document.
 */
export declare const importComponent: API.OperationMethod<ImportComponentRequest, ImportComponentResponse, ImportComponentError, Credentials | HttpClient.HttpClient>;
export type ImportDiskImageError = AccessDeniedException | ClientException | ServiceException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Import a Windows operating system image from a verified Microsoft ISO disk
 * file. The following disk images are supported:
 *
 * - Windows 11 Enterprise
 */
export declare const importDiskImage: API.OperationMethod<ImportDiskImageRequest, ImportDiskImageResponse, ImportDiskImageError, Credentials | HttpClient.HttpClient>;
export type ImportVmImageError = ClientException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * When you export your virtual machine (VM) from its virtualization environment, that
 * process creates a set of one or more disk container files that act as snapshots of your
 * VM’s environment, settings, and data. The Amazon EC2 API ImportImage
 * action uses those files to import your VM and create an AMI. To import using the CLI
 * command, see import-image
 *
 * You can reference the task ID from the VM import to pull in the AMI that the import
 * created as the base image for your Image Builder recipe.
 */
export declare const importVmImage: API.OperationMethod<ImportVmImageRequest, ImportVmImageResponse, ImportVmImageError, Credentials | HttpClient.HttpClient>;
export type ListComponentBuildVersionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the list of component build versions for the specified component
 * version Amazon Resource Name (ARN).
 */
export declare const listComponentBuildVersions: API.PaginatedOperationMethod<ListComponentBuildVersionsRequest, ListComponentBuildVersionsResponse, ListComponentBuildVersionsError, Credentials | HttpClient.HttpClient, ComponentSummary>;
export type ListComponentsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the list of components that can be filtered by name, or by using the listed
 * `filters` to streamline results. Newly created components can take up to
 * two minutes to appear in the ListComponents API Results.
 *
 * The semantic version has four nodes: ../.
 * You can assign values for the first three, and can filter on all of them.
 *
 * **Filtering:** With semantic versioning, you have the flexibility to use wildcards (x)
 * to specify the most recent versions or nodes when selecting the base image or components for your
 * recipe. When you use a wildcard in any node, all nodes to the right of the first wildcard must also be
 * wildcards.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsRequest, ListComponentsResponse, ListComponentsError, Credentials | HttpClient.HttpClient, ComponentVersion>;
export type ListContainerRecipesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of container recipes.
 */
export declare const listContainerRecipes: API.PaginatedOperationMethod<ListContainerRecipesRequest, ListContainerRecipesResponse, ListContainerRecipesError, Credentials | HttpClient.HttpClient, ContainerRecipeSummary>;
export type ListDistributionConfigurationsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of distribution configurations.
 */
export declare const listDistributionConfigurations: API.PaginatedOperationMethod<ListDistributionConfigurationsRequest, ListDistributionConfigurationsResponse, ListDistributionConfigurationsError, Credentials | HttpClient.HttpClient, DistributionConfigurationSummary>;
export type ListImageBuildVersionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image build versions.
 */
export declare const listImageBuildVersions: API.PaginatedOperationMethod<ListImageBuildVersionsRequest, ListImageBuildVersionsResponse, ListImageBuildVersionsError, Credentials | HttpClient.HttpClient, ImageSummary>;
export type ListImagePackagesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * List the Packages that are associated with an Image Build Version, as determined by
 * Amazon Web Services Systems Manager Inventory at build time.
 */
export declare const listImagePackages: API.PaginatedOperationMethod<ListImagePackagesRequest, ListImagePackagesResponse, ListImagePackagesError, Credentials | HttpClient.HttpClient, ImagePackage>;
export type ListImagePipelineImagesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of images created by the specified pipeline.
 */
export declare const listImagePipelineImages: API.PaginatedOperationMethod<ListImagePipelineImagesRequest, ListImagePipelineImagesResponse, ListImagePipelineImagesError, Credentials | HttpClient.HttpClient, ImageSummary>;
export type ListImagePipelinesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image pipelines.
 */
export declare const listImagePipelines: API.PaginatedOperationMethod<ListImagePipelinesRequest, ListImagePipelinesResponse, ListImagePipelinesError, Credentials | HttpClient.HttpClient, ImagePipeline>;
export type ListImageRecipesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image recipes.
 */
export declare const listImageRecipes: API.PaginatedOperationMethod<ListImageRecipesRequest, ListImageRecipesResponse, ListImageRecipesError, Credentials | HttpClient.HttpClient, ImageRecipeSummary>;
export type ListImagesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the list of images that you have access to. Newly created images can take up
 * to two minutes to appear in the ListImages API Results.
 */
export declare const listImages: API.PaginatedOperationMethod<ListImagesRequest, ListImagesResponse, ListImagesError, Credentials | HttpClient.HttpClient, ImageVersion>;
export type ListImageScanFindingAggregationsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image scan aggregations for your account. You can filter by the type
 * of key that Image Builder uses to group results. For example, if you want to get a list of
 * findings by severity level for one of your pipelines, you might specify your pipeline
 * with the `imagePipelineArn` filter. If you don't specify a filter, Image Builder
 * returns an aggregation for your account.
 *
 * To streamline results, you can use the following filters in your request:
 *
 * - `accountId`
 *
 * - `imageBuildVersionArn`
 *
 * - `imagePipelineArn`
 *
 * - `vulnerabilityId`
 */
export declare const listImageScanFindingAggregations: API.PaginatedOperationMethod<ListImageScanFindingAggregationsRequest, ListImageScanFindingAggregationsResponse, ListImageScanFindingAggregationsError, Credentials | HttpClient.HttpClient, ImageScanFindingAggregation>;
export type ListImageScanFindingsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image scan findings for your account.
 */
export declare const listImageScanFindings: API.PaginatedOperationMethod<ListImageScanFindingsRequest, ListImageScanFindingsResponse, ListImageScanFindingsError, Credentials | HttpClient.HttpClient, ImageScanFinding>;
export type ListInfrastructureConfigurationsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of infrastructure configurations.
 */
export declare const listInfrastructureConfigurations: API.PaginatedOperationMethod<ListInfrastructureConfigurationsRequest, ListInfrastructureConfigurationsResponse, ListInfrastructureConfigurationsError, Credentials | HttpClient.HttpClient, InfrastructureConfigurationSummary>;
export type ListLifecycleExecutionResourcesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * List resources that the runtime instance of the image lifecycle identified for lifecycle actions.
 */
export declare const listLifecycleExecutionResources: API.PaginatedOperationMethod<ListLifecycleExecutionResourcesRequest, ListLifecycleExecutionResourcesResponse, ListLifecycleExecutionResourcesError, Credentials | HttpClient.HttpClient, LifecycleExecutionResource>;
export type ListLifecycleExecutionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Get the lifecycle runtime history for the specified resource.
 */
export declare const listLifecycleExecutions: API.PaginatedOperationMethod<ListLifecycleExecutionsRequest, ListLifecycleExecutionsResponse, ListLifecycleExecutionsError, Credentials | HttpClient.HttpClient, LifecycleExecution>;
export type ListLifecyclePoliciesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Get a list of lifecycle policies in your Amazon Web Services account.
 */
export declare const listLifecyclePolicies: API.PaginatedOperationMethod<ListLifecyclePoliciesRequest, ListLifecyclePoliciesResponse, ListLifecyclePoliciesError, Credentials | HttpClient.HttpClient, LifecyclePolicySummary>;
export type ListTagsForResourceError = InvalidParameterException | ResourceNotFoundException | ServiceException | CommonErrors;
/**
 * Returns the list of tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWaitingWorkflowStepsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Get a list of workflow steps that are waiting for action for workflows
 * in your Amazon Web Services account.
 */
export declare const listWaitingWorkflowSteps: API.PaginatedOperationMethod<ListWaitingWorkflowStepsRequest, ListWaitingWorkflowStepsResponse, ListWaitingWorkflowStepsError, Credentials | HttpClient.HttpClient, WorkflowStepExecution>;
export type ListWorkflowBuildVersionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of build versions for a specific workflow resource.
 */
export declare const listWorkflowBuildVersions: API.PaginatedOperationMethod<ListWorkflowBuildVersionsRequest, ListWorkflowBuildVersionsResponse, ListWorkflowBuildVersionsError, Credentials | HttpClient.HttpClient, WorkflowSummary>;
export type ListWorkflowExecutionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of workflow runtime instance metadata objects for a specific image build
 * version.
 */
export declare const listWorkflowExecutions: API.PaginatedOperationMethod<ListWorkflowExecutionsRequest, ListWorkflowExecutionsResponse, ListWorkflowExecutionsError, Credentials | HttpClient.HttpClient, WorkflowExecutionMetadata>;
export type ListWorkflowsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Lists workflow build versions based on filtering parameters.
 */
export declare const listWorkflows: API.PaginatedOperationMethod<ListWorkflowsRequest, ListWorkflowsResponse, ListWorkflowsError, Credentials | HttpClient.HttpClient, WorkflowVersion>;
export type ListWorkflowStepExecutionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns runtime data for each step in a runtime instance of the workflow
 * that you specify in the request.
 */
export declare const listWorkflowStepExecutions: API.PaginatedOperationMethod<ListWorkflowStepExecutionsRequest, ListWorkflowStepExecutionsResponse, ListWorkflowStepExecutionsError, Credentials | HttpClient.HttpClient, WorkflowStepMetadata>;
export type PutComponentPolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Applies a policy to a component. We recommend that you call the RAM API CreateResourceShare to share resources. If you call the Image Builder API
 * `PutComponentPolicy`, you must also call the RAM API PromoteResourceShareCreatedFromPolicy in order for the resource to be
 * visible to all principals with whom the resource is shared.
 */
export declare const putComponentPolicy: API.OperationMethod<PutComponentPolicyRequest, PutComponentPolicyResponse, PutComponentPolicyError, Credentials | HttpClient.HttpClient>;
export type PutContainerRecipePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Applies a policy to a container image. We recommend that you call the RAM API
 * CreateResourceShare
 * (https://docs.aws.amazon.com//ram/latest/APIReference/API_CreateResourceShare.html) to share
 * resources. If you call the Image Builder API `PutContainerImagePolicy`, you must also
 * call the RAM API PromoteResourceShareCreatedFromPolicy
 * (https://docs.aws.amazon.com//ram/latest/APIReference/API_PromoteResourceShareCreatedFromPolicy.html)
 * in order for the resource to be visible to all principals with whom the resource is
 * shared.
 */
export declare const putContainerRecipePolicy: API.OperationMethod<PutContainerRecipePolicyRequest, PutContainerRecipePolicyResponse, PutContainerRecipePolicyError, Credentials | HttpClient.HttpClient>;
export type PutImagePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Applies a policy to an image. We recommend that you call the RAM API CreateResourceShare to share resources. If you call the Image Builder API
 * `PutImagePolicy`, you must also call the RAM API PromoteResourceShareCreatedFromPolicy in order for the resource to be
 * visible to all principals with whom the resource is shared.
 */
export declare const putImagePolicy: API.OperationMethod<PutImagePolicyRequest, PutImagePolicyResponse, PutImagePolicyError, Credentials | HttpClient.HttpClient>;
export type PutImageRecipePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Applies a policy to an image recipe. We recommend that you call the RAM API CreateResourceShare to share resources. If you call the Image Builder API
 * `PutImageRecipePolicy`, you must also call the RAM API PromoteResourceShareCreatedFromPolicy in order for the resource to be
 * visible to all principals with whom the resource is shared.
 */
export declare const putImageRecipePolicy: API.OperationMethod<PutImageRecipePolicyRequest, PutImageRecipePolicyResponse, PutImageRecipePolicyError, Credentials | HttpClient.HttpClient>;
export type RetryImageError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * RetryImage retries an image distribution without rebuilding the image.
 */
export declare const retryImage: API.OperationMethod<RetryImageRequest, RetryImageResponse, RetryImageError, Credentials | HttpClient.HttpClient>;
export type SendWorkflowStepActionError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterValueException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Pauses or resumes image creation when the associated workflow runs a
 * `WaitForAction` step.
 */
export declare const sendWorkflowStepAction: API.OperationMethod<SendWorkflowStepActionRequest, SendWorkflowStepActionResponse, SendWorkflowStepActionError, Credentials | HttpClient.HttpClient>;
export type StartImagePipelineExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Manually triggers a pipeline to create an image.
 */
export declare const startImagePipelineExecution: API.OperationMethod<StartImagePipelineExecutionRequest, StartImagePipelineExecutionResponse, StartImagePipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type StartResourceStateUpdateError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Begin asynchronous resource state update for lifecycle changes to the
 * specified image resources.
 */
export declare const startResourceStateUpdate: API.OperationMethod<StartResourceStateUpdateRequest, StartResourceStateUpdateResponse, StartResourceStateUpdateError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidParameterException | ResourceNotFoundException | ServiceException | CommonErrors;
/**
 * Adds a tag to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidParameterException | ResourceNotFoundException | ServiceException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDistributionConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a new distribution configuration. Distribution configurations define and
 * configure the outputs of your pipeline.
 */
export declare const updateDistributionConfiguration: API.OperationMethod<UpdateDistributionConfigurationRequest, UpdateDistributionConfigurationResponse, UpdateDistributionConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateImagePipelineError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an image pipeline. Image pipelines enable you to automate the creation and
 * distribution of images. You must specify exactly one recipe for your image, using either
 * a `containerRecipeArn` or an `imageRecipeArn`.
 *
 * UpdateImagePipeline does not support selective updates for the pipeline. You must
 * specify all of the required properties in the update request, not just the
 * properties that have changed.
 */
export declare const updateImagePipeline: API.OperationMethod<UpdateImagePipelineRequest, UpdateImagePipelineResponse, UpdateImagePipelineError, Credentials | HttpClient.HttpClient>;
export type UpdateInfrastructureConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | InvalidParameterValueException | CommonErrors;
/**
 * Updates a new infrastructure configuration. An infrastructure configuration defines
 * the environment in which your image will be built and tested.
 */
export declare const updateInfrastructureConfiguration: API.OperationMethod<UpdateInfrastructureConfigurationRequest, UpdateInfrastructureConfigurationResponse, UpdateInfrastructureConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLifecyclePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Update the specified lifecycle policy.
 */
export declare const updateLifecyclePolicy: API.OperationMethod<UpdateLifecyclePolicyRequest, UpdateLifecyclePolicyResponse, UpdateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=imagebuilder.d.ts.map