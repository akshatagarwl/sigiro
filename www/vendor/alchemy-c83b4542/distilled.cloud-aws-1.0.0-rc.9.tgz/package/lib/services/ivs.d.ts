import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ChannelNotBroadcasting_base: S.Class<ChannelNotBroadcasting, S.TaggedStruct<"ChannelNotBroadcasting", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ChannelNotBroadcasting extends /*@__PURE__*/ ChannelNotBroadcasting_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const PendingVerification_base: S.Class<PendingVerification, S.TaggedStruct<"PendingVerification", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class PendingVerification extends /*@__PURE__*/ PendingVerification_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailable_base: S.Class<ServiceUnavailable, S.TaggedStruct<"ServiceUnavailable", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailable extends /*@__PURE__*/ ServiceUnavailable_base {
}
declare const StreamUnavailable_base: S.Class<StreamUnavailable, S.TaggedStruct<"StreamUnavailable", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class StreamUnavailable extends /*@__PURE__*/ StreamUnavailable_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ChannelArn = string;
export type ChannelArnList = string[];
export declare const ChannelArnList: any;
export interface BatchGetChannelRequest {
    arns: string[];
}
export declare const BatchGetChannelRequest: S.Schema<BatchGetChannelRequest>;
export type ChannelName = string;
export type ChannelLatencyMode = string;
export type ChannelType = "BASIC" | "STANDARD" | "ADVANCED_SD" | "ADVANCED_HD" | (string & {});
export declare const ChannelType: any;
export type ChannelRecordingConfigurationArn = string;
export type IngestEndpoint = string;
export type PlaybackURL = string;
export type IsAuthorized = boolean;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export type InsecureIngest = boolean;
export type TranscodePreset = "HIGHER_BANDWIDTH_DELIVERY" | "CONSTRAINED_BANDWIDTH_DELIVERY" | (string & {});
export declare const TranscodePreset: any;
export type SrtEndpoint = string;
export type SrtPassphrase = string | redacted.Redacted<string>;
export interface Srt {
    endpoint?: string;
    passphrase?: string | redacted.Redacted<string>;
}
export declare const Srt: S.Schema<Srt>;
export type ChannelPlaybackRestrictionPolicyArn = string;
export type IsMultitrackInputEnabled = boolean;
export type MultitrackPolicy = "ALLOW" | "REQUIRE" | (string & {});
export declare const MultitrackPolicy: any;
export type MultitrackMaximumResolution = "SD" | "HD" | "FULL_HD" | (string & {});
export declare const MultitrackMaximumResolution: any;
export interface MultitrackInputConfiguration {
    enabled?: boolean;
    policy?: MultitrackPolicy;
    maximumResolution?: MultitrackMaximumResolution;
}
export declare const MultitrackInputConfiguration: S.Schema<MultitrackInputConfiguration>;
export type ContainerFormat = string;
export type ChannelAdConfigurationArn = string;
export interface Channel {
    arn?: string;
    name?: string;
    latencyMode?: string;
    type?: ChannelType;
    recordingConfigurationArn?: string;
    ingestEndpoint?: string;
    playbackUrl?: string;
    authorized?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
    insecureIngest?: boolean;
    preset?: TranscodePreset;
    srt?: Srt;
    playbackRestrictionPolicyArn?: string;
    multitrackInputConfiguration?: MultitrackInputConfiguration;
    containerFormat?: string;
    adConfigurationArn?: string;
}
export declare const Channel: S.Schema<Channel>;
export type Channels = Channel[];
export declare const Channels: any;
export type ResourceArn = string;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface BatchError {
    arn?: string;
    code?: string;
    message?: string;
}
export declare const BatchError: S.Schema<BatchError>;
export type BatchErrors = BatchError[];
export declare const BatchErrors: any;
export interface BatchGetChannelResponse {
    accessControlAllowOrigin?: string;
    accessControlExposeHeaders?: string;
    cacheControl?: string;
    contentSecurityPolicy?: string;
    strictTransportSecurity?: string;
    xContentTypeOptions?: string;
    xFrameOptions?: string;
    channels?: Channel[];
    errors?: BatchError[];
}
export declare const BatchGetChannelResponse: S.Schema<BatchGetChannelResponse>;
export type StreamKeyArn = string;
export type StreamKeyArnList = string[];
export declare const StreamKeyArnList: any;
export interface BatchGetStreamKeyRequest {
    arns: string[];
}
export declare const BatchGetStreamKeyRequest: S.Schema<BatchGetStreamKeyRequest>;
export type StreamKeyValue = string | redacted.Redacted<string>;
export interface StreamKey {
    arn?: string;
    value?: string | redacted.Redacted<string>;
    channelArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StreamKey: S.Schema<StreamKey>;
export type StreamKeys = StreamKey[];
export declare const StreamKeys: any;
export interface BatchGetStreamKeyResponse {
    accessControlAllowOrigin?: string;
    accessControlExposeHeaders?: string;
    cacheControl?: string;
    contentSecurityPolicy?: string;
    strictTransportSecurity?: string;
    xContentTypeOptions?: string;
    xFrameOptions?: string;
    streamKeys?: StreamKey[];
    errors?: BatchError[];
}
export declare const BatchGetStreamKeyResponse: S.Schema<BatchGetStreamKeyResponse>;
export type ViewerId = string;
export type ViewerSessionVersion = number;
export interface BatchStartViewerSessionRevocationViewerSession {
    channelArn: string;
    viewerId: string;
    viewerSessionVersionsLessThanOrEqualTo?: number;
}
export declare const BatchStartViewerSessionRevocationViewerSession: S.Schema<BatchStartViewerSessionRevocationViewerSession>;
export type BatchStartViewerSessionRevocationViewerSessionList = BatchStartViewerSessionRevocationViewerSession[];
export declare const BatchStartViewerSessionRevocationViewerSessionList: any;
export interface BatchStartViewerSessionRevocationRequest {
    viewerSessions: BatchStartViewerSessionRevocationViewerSession[];
}
export declare const BatchStartViewerSessionRevocationRequest: S.Schema<BatchStartViewerSessionRevocationRequest>;
export interface BatchStartViewerSessionRevocationError_ {
    channelArn: string;
    viewerId: string;
    code?: string;
    message?: string;
}
export declare const BatchStartViewerSessionRevocationError_: S.Schema<BatchStartViewerSessionRevocationError_>;
export type BatchStartViewerSessionRevocationErrors = BatchStartViewerSessionRevocationError_[];
export declare const BatchStartViewerSessionRevocationErrors: any;
export interface BatchStartViewerSessionRevocationResponse {
    accessControlAllowOrigin?: string;
    accessControlExposeHeaders?: string;
    cacheControl?: string;
    contentSecurityPolicy?: string;
    strictTransportSecurity?: string;
    xContentTypeOptions?: string;
    xFrameOptions?: string;
    errors?: BatchStartViewerSessionRevocationError_[];
}
export declare const BatchStartViewerSessionRevocationResponse: S.Schema<BatchStartViewerSessionRevocationResponse>;
export type AdConfigurationName = string;
export type MediaTailorPlaybackConfigurationArn = string;
export interface MediaTailorPlaybackConfiguration {
    playbackConfigurationArn?: string;
}
export declare const MediaTailorPlaybackConfiguration: S.Schema<MediaTailorPlaybackConfiguration>;
export type MediaTailorPlaybackConfigurationsList = MediaTailorPlaybackConfiguration[];
export declare const MediaTailorPlaybackConfigurationsList: any;
export type AdDurationSeconds = number;
export interface PostRollConfiguration {
    durationSeconds: number;
    enabled: boolean;
}
export declare const PostRollConfiguration: S.Schema<PostRollConfiguration>;
export interface CreateAdConfigurationRequest {
    name?: string;
    mediaTailorPlaybackConfigurations: MediaTailorPlaybackConfiguration[];
    postRollConfiguration?: PostRollConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateAdConfigurationRequest: S.Schema<CreateAdConfigurationRequest>;
export type AdConfigurationArn = string;
export interface AdConfiguration {
    arn: string;
    name?: string;
    mediaTailorPlaybackConfigurations: MediaTailorPlaybackConfiguration[];
    postRollConfiguration?: PostRollConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const AdConfiguration: S.Schema<AdConfiguration>;
export interface CreateAdConfigurationResponse {
    adConfiguration: AdConfiguration;
}
export declare const CreateAdConfigurationResponse: S.Schema<CreateAdConfigurationResponse>;
export interface CreateChannelRequest {
    name?: string;
    latencyMode?: string;
    type?: ChannelType;
    authorized?: boolean;
    recordingConfigurationArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    insecureIngest?: boolean;
    preset?: TranscodePreset;
    playbackRestrictionPolicyArn?: string;
    multitrackInputConfiguration?: MultitrackInputConfiguration;
    containerFormat?: string;
    adConfigurationArn?: string;
}
export declare const CreateChannelRequest: S.Schema<CreateChannelRequest>;
export interface CreateChannelResponse {
    channel?: Channel;
    streamKey?: StreamKey;
}
export declare const CreateChannelResponse: S.Schema<CreateChannelResponse>;
export type PlaybackRestrictionPolicyAllowedCountry = string;
export type PlaybackRestrictionPolicyAllowedCountryList = string[];
export declare const PlaybackRestrictionPolicyAllowedCountryList: any;
export type PlaybackRestrictionPolicyAllowedOrigin = string;
export type PlaybackRestrictionPolicyAllowedOriginList = string[];
export declare const PlaybackRestrictionPolicyAllowedOriginList: any;
export type PlaybackRestrictionPolicyEnableStrictOriginEnforcement = boolean;
export type PlaybackRestrictionPolicyName = string;
export interface CreatePlaybackRestrictionPolicyRequest {
    allowedCountries?: string[];
    allowedOrigins?: string[];
    enableStrictOriginEnforcement?: boolean;
    name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePlaybackRestrictionPolicyRequest: S.Schema<CreatePlaybackRestrictionPolicyRequest>;
export type PlaybackRestrictionPolicyArn = string;
export interface PlaybackRestrictionPolicy {
    arn: string;
    allowedCountries: string[];
    allowedOrigins: string[];
    enableStrictOriginEnforcement?: boolean;
    name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const PlaybackRestrictionPolicy: S.Schema<PlaybackRestrictionPolicy>;
export interface CreatePlaybackRestrictionPolicyResponse {
    playbackRestrictionPolicy?: PlaybackRestrictionPolicy;
}
export declare const CreatePlaybackRestrictionPolicyResponse: S.Schema<CreatePlaybackRestrictionPolicyResponse>;
export type RecordingConfigurationName = string;
export type S3DestinationBucketName = string;
export interface S3DestinationConfiguration {
    bucketName: string;
}
export declare const S3DestinationConfiguration: S.Schema<S3DestinationConfiguration>;
export interface DestinationConfiguration {
    s3?: S3DestinationConfiguration;
}
export declare const DestinationConfiguration: S.Schema<DestinationConfiguration>;
export type RecordingMode = string;
export type TargetIntervalSeconds = number;
export type ThumbnailConfigurationResolution = "SD" | "HD" | "FULL_HD" | "LOWEST_RESOLUTION" | (string & {});
export declare const ThumbnailConfigurationResolution: any;
export type ThumbnailConfigurationStorage = string;
export type ThumbnailConfigurationStorageList = string[];
export declare const ThumbnailConfigurationStorageList: any;
export interface ThumbnailConfiguration {
    recordingMode?: string;
    targetIntervalSeconds?: number;
    resolution?: ThumbnailConfigurationResolution;
    storage?: string[];
}
export declare const ThumbnailConfiguration: S.Schema<ThumbnailConfiguration>;
export type RecordingReconnectWindowSeconds = number;
export type RenditionConfigurationRenditionSelection = string;
export type RenditionConfigurationRendition = "SD" | "HD" | "FULL_HD" | "LOWEST_RESOLUTION" | (string & {});
export declare const RenditionConfigurationRendition: any;
export type RenditionConfigurationRenditionList = RenditionConfigurationRendition[];
export declare const RenditionConfigurationRenditionList: any;
export interface RenditionConfiguration {
    renditionSelection?: string;
    renditions?: RenditionConfigurationRendition[];
}
export declare const RenditionConfiguration: S.Schema<RenditionConfiguration>;
export interface CreateRecordingConfigurationRequest {
    name?: string;
    destinationConfiguration: DestinationConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
    thumbnailConfiguration?: ThumbnailConfiguration;
    recordingReconnectWindowSeconds?: number;
    renditionConfiguration?: RenditionConfiguration;
}
export declare const CreateRecordingConfigurationRequest: S.Schema<CreateRecordingConfigurationRequest>;
export type RecordingConfigurationArn = string;
export type RecordingConfigurationState = string;
export interface RecordingConfiguration {
    arn: string;
    name?: string;
    destinationConfiguration: DestinationConfiguration;
    state: string;
    tags?: {
        [key: string]: string | undefined;
    };
    thumbnailConfiguration?: ThumbnailConfiguration;
    recordingReconnectWindowSeconds?: number;
    renditionConfiguration?: RenditionConfiguration;
}
export declare const RecordingConfiguration: S.Schema<RecordingConfiguration>;
export interface CreateRecordingConfigurationResponse {
    recordingConfiguration?: RecordingConfiguration;
}
export declare const CreateRecordingConfigurationResponse: S.Schema<CreateRecordingConfigurationResponse>;
export interface CreateStreamKeyRequest {
    channelArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateStreamKeyRequest: S.Schema<CreateStreamKeyRequest>;
export interface CreateStreamKeyResponse {
    streamKey?: StreamKey;
}
export declare const CreateStreamKeyResponse: S.Schema<CreateStreamKeyResponse>;
export interface DeleteAdConfigurationRequest {
    arn: string;
}
export declare const DeleteAdConfigurationRequest: S.Schema<DeleteAdConfigurationRequest>;
export interface DeleteAdConfigurationResponse {
}
export declare const DeleteAdConfigurationResponse: S.Schema<DeleteAdConfigurationResponse>;
export interface DeleteChannelRequest {
    arn: string;
}
export declare const DeleteChannelRequest: S.Schema<DeleteChannelRequest>;
export interface DeleteChannelResponse {
}
export declare const DeleteChannelResponse: S.Schema<DeleteChannelResponse>;
export type PlaybackKeyPairArn = string;
export interface DeletePlaybackKeyPairRequest {
    arn: string;
}
export declare const DeletePlaybackKeyPairRequest: S.Schema<DeletePlaybackKeyPairRequest>;
export interface DeletePlaybackKeyPairResponse {
}
export declare const DeletePlaybackKeyPairResponse: S.Schema<DeletePlaybackKeyPairResponse>;
export interface DeletePlaybackRestrictionPolicyRequest {
    arn: string;
}
export declare const DeletePlaybackRestrictionPolicyRequest: S.Schema<DeletePlaybackRestrictionPolicyRequest>;
export interface DeletePlaybackRestrictionPolicyResponse {
}
export declare const DeletePlaybackRestrictionPolicyResponse: S.Schema<DeletePlaybackRestrictionPolicyResponse>;
export interface DeleteRecordingConfigurationRequest {
    arn: string;
}
export declare const DeleteRecordingConfigurationRequest: S.Schema<DeleteRecordingConfigurationRequest>;
export interface DeleteRecordingConfigurationResponse {
}
export declare const DeleteRecordingConfigurationResponse: S.Schema<DeleteRecordingConfigurationResponse>;
export interface DeleteStreamKeyRequest {
    arn: string;
}
export declare const DeleteStreamKeyRequest: S.Schema<DeleteStreamKeyRequest>;
export interface DeleteStreamKeyResponse {
}
export declare const DeleteStreamKeyResponse: S.Schema<DeleteStreamKeyResponse>;
export interface GetAdConfigurationRequest {
    arn: string;
}
export declare const GetAdConfigurationRequest: S.Schema<GetAdConfigurationRequest>;
export interface GetAdConfigurationResponse {
    adConfiguration?: AdConfiguration;
}
export declare const GetAdConfigurationResponse: S.Schema<GetAdConfigurationResponse>;
export interface GetChannelRequest {
    arn: string;
}
export declare const GetChannelRequest: S.Schema<GetChannelRequest>;
export interface GetChannelResponse {
    channel?: Channel;
}
export declare const GetChannelResponse: S.Schema<GetChannelResponse>;
export interface GetPlaybackKeyPairRequest {
    arn: string;
}
export declare const GetPlaybackKeyPairRequest: S.Schema<GetPlaybackKeyPairRequest>;
export type PlaybackKeyPairName = string;
export type PlaybackKeyPairFingerprint = string;
export interface PlaybackKeyPair {
    arn?: string;
    name?: string;
    fingerprint?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const PlaybackKeyPair: S.Schema<PlaybackKeyPair>;
export interface GetPlaybackKeyPairResponse {
    keyPair?: PlaybackKeyPair;
}
export declare const GetPlaybackKeyPairResponse: S.Schema<GetPlaybackKeyPairResponse>;
export interface GetPlaybackRestrictionPolicyRequest {
    arn: string;
}
export declare const GetPlaybackRestrictionPolicyRequest: S.Schema<GetPlaybackRestrictionPolicyRequest>;
export interface GetPlaybackRestrictionPolicyResponse {
    playbackRestrictionPolicy?: PlaybackRestrictionPolicy;
}
export declare const GetPlaybackRestrictionPolicyResponse: S.Schema<GetPlaybackRestrictionPolicyResponse>;
export interface GetRecordingConfigurationRequest {
    arn: string;
}
export declare const GetRecordingConfigurationRequest: S.Schema<GetRecordingConfigurationRequest>;
export interface GetRecordingConfigurationResponse {
    recordingConfiguration?: RecordingConfiguration;
}
export declare const GetRecordingConfigurationResponse: S.Schema<GetRecordingConfigurationResponse>;
export interface GetStreamRequest {
    channelArn: string;
}
export declare const GetStreamRequest: S.Schema<GetStreamRequest>;
export type StreamId = string;
export type StreamStartTime = Date;
export type StreamState = string;
export type StreamHealth = string;
export type StreamViewerCount = number;
export interface Stream {
    channelArn?: string;
    streamId?: string;
    playbackUrl?: string;
    startTime?: Date;
    state?: string;
    health?: string;
    viewerCount?: number;
}
export declare const Stream: S.Schema<Stream>;
export interface GetStreamResponse {
    stream?: Stream;
}
export declare const GetStreamResponse: S.Schema<GetStreamResponse>;
export interface GetStreamKeyRequest {
    arn: string;
}
export declare const GetStreamKeyRequest: S.Schema<GetStreamKeyRequest>;
export interface GetStreamKeyResponse {
    streamKey?: StreamKey;
}
export declare const GetStreamKeyResponse: S.Schema<GetStreamKeyResponse>;
export interface GetStreamSessionRequest {
    channelArn: string;
    streamId?: string;
}
export declare const GetStreamSessionRequest: S.Schema<GetStreamSessionRequest>;
export interface VideoConfiguration {
    avcProfile?: string;
    avcLevel?: string;
    codec?: string;
    encoder?: string;
    targetBitrate?: number;
    targetFramerate?: number;
    videoHeight?: number;
    videoWidth?: number;
    level?: string;
    track?: string;
    profile?: string;
}
export declare const VideoConfiguration: S.Schema<VideoConfiguration>;
export interface AudioConfiguration {
    codec?: string;
    targetBitrate?: number;
    sampleRate?: number;
    channels?: number;
    track?: string;
}
export declare const AudioConfiguration: S.Schema<AudioConfiguration>;
export interface IngestConfiguration {
    video?: VideoConfiguration;
    audio?: AudioConfiguration;
}
export declare const IngestConfiguration: S.Schema<IngestConfiguration>;
export type VideoConfigurationList = VideoConfiguration[];
export declare const VideoConfigurationList: any;
export type AudioConfigurationList = AudioConfiguration[];
export declare const AudioConfigurationList: any;
export interface IngestConfigurations {
    videoConfigurations: VideoConfiguration[];
    audioConfigurations: AudioConfiguration[];
}
export declare const IngestConfigurations: S.Schema<IngestConfigurations>;
export interface StreamEvent {
    name?: string;
    type?: string;
    eventTime?: Date;
    code?: string;
}
export declare const StreamEvent: S.Schema<StreamEvent>;
export type StreamEvents = StreamEvent[];
export declare const StreamEvents: any;
export interface StreamSession {
    streamId?: string;
    startTime?: Date;
    endTime?: Date;
    channel?: Channel;
    ingestConfiguration?: IngestConfiguration;
    ingestConfigurations?: IngestConfigurations;
    recordingConfiguration?: RecordingConfiguration;
    truncatedEvents?: StreamEvent[];
}
export declare const StreamSession: S.Schema<StreamSession>;
export interface GetStreamSessionResponse {
    streamSession?: StreamSession;
}
export declare const GetStreamSessionResponse: S.Schema<GetStreamSessionResponse>;
export type PlaybackPublicKeyMaterial = string;
export interface ImportPlaybackKeyPairRequest {
    publicKeyMaterial: string;
    name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ImportPlaybackKeyPairRequest: S.Schema<ImportPlaybackKeyPairRequest>;
export interface ImportPlaybackKeyPairResponse {
    keyPair?: PlaybackKeyPair;
}
export declare const ImportPlaybackKeyPairResponse: S.Schema<ImportPlaybackKeyPairResponse>;
export interface InsertAdBreakRequest {
    channelArn: string;
    durationSeconds: number;
}
export declare const InsertAdBreakRequest: S.Schema<InsertAdBreakRequest>;
export type AdBreakId = string;
export interface InsertAdBreakResponse {
    adBreakId?: string;
}
export declare const InsertAdBreakResponse: S.Schema<InsertAdBreakResponse>;
export type PaginationToken = string;
export type MaxAdConfigurationResults = number;
export interface ListAdConfigurationsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAdConfigurationsRequest: S.Schema<ListAdConfigurationsRequest>;
export interface AdConfigurationSummary {
    arn: string;
    name?: string;
    mediaTailorPlaybackConfigurations: MediaTailorPlaybackConfiguration[];
    postRollConfiguration?: PostRollConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const AdConfigurationSummary: S.Schema<AdConfigurationSummary>;
export type AdConfigurationList = AdConfigurationSummary[];
export declare const AdConfigurationList: any;
export interface ListAdConfigurationsResponse {
    adConfigurations: AdConfigurationSummary[];
    nextToken?: string;
}
export declare const ListAdConfigurationsResponse: S.Schema<ListAdConfigurationsResponse>;
export type MaxChannelResults = number;
export interface ListChannelsRequest {
    filterByName?: string;
    filterByRecordingConfigurationArn?: string;
    filterByPlaybackRestrictionPolicyArn?: string;
    filterByAdConfigurationArn?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListChannelsRequest: S.Schema<ListChannelsRequest>;
export interface ChannelSummary {
    arn?: string;
    name?: string;
    latencyMode?: string;
    authorized?: boolean;
    recordingConfigurationArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    insecureIngest?: boolean;
    type?: ChannelType;
    preset?: TranscodePreset;
    playbackRestrictionPolicyArn?: string;
    adConfigurationArn?: string;
}
export declare const ChannelSummary: S.Schema<ChannelSummary>;
export type ChannelList = ChannelSummary[];
export declare const ChannelList: any;
export interface ListChannelsResponse {
    channels: ChannelSummary[];
    nextToken?: string;
}
export declare const ListChannelsResponse: S.Schema<ListChannelsResponse>;
export type MaxPlaybackKeyPairResults = number;
export interface ListPlaybackKeyPairsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPlaybackKeyPairsRequest: S.Schema<ListPlaybackKeyPairsRequest>;
export interface PlaybackKeyPairSummary {
    arn?: string;
    name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const PlaybackKeyPairSummary: S.Schema<PlaybackKeyPairSummary>;
export type PlaybackKeyPairList = PlaybackKeyPairSummary[];
export declare const PlaybackKeyPairList: any;
export interface ListPlaybackKeyPairsResponse {
    keyPairs: PlaybackKeyPairSummary[];
    nextToken?: string;
}
export declare const ListPlaybackKeyPairsResponse: S.Schema<ListPlaybackKeyPairsResponse>;
export type MaxPlaybackRestrictionPolicyResults = number;
export interface ListPlaybackRestrictionPoliciesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPlaybackRestrictionPoliciesRequest: S.Schema<ListPlaybackRestrictionPoliciesRequest>;
export interface PlaybackRestrictionPolicySummary {
    arn: string;
    allowedCountries: string[];
    allowedOrigins: string[];
    enableStrictOriginEnforcement?: boolean;
    name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const PlaybackRestrictionPolicySummary: S.Schema<PlaybackRestrictionPolicySummary>;
export type PlaybackRestrictionPolicyList = PlaybackRestrictionPolicySummary[];
export declare const PlaybackRestrictionPolicyList: any;
export interface ListPlaybackRestrictionPoliciesResponse {
    playbackRestrictionPolicies: PlaybackRestrictionPolicySummary[];
    nextToken?: string;
}
export declare const ListPlaybackRestrictionPoliciesResponse: S.Schema<ListPlaybackRestrictionPoliciesResponse>;
export type MaxRecordingConfigurationResults = number;
export interface ListRecordingConfigurationsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListRecordingConfigurationsRequest: S.Schema<ListRecordingConfigurationsRequest>;
export interface RecordingConfigurationSummary {
    arn: string;
    name?: string;
    destinationConfiguration: DestinationConfiguration;
    state: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const RecordingConfigurationSummary: S.Schema<RecordingConfigurationSummary>;
export type RecordingConfigurationList = RecordingConfigurationSummary[];
export declare const RecordingConfigurationList: any;
export interface ListRecordingConfigurationsResponse {
    recordingConfigurations: RecordingConfigurationSummary[];
    nextToken?: string;
}
export declare const ListRecordingConfigurationsResponse: S.Schema<ListRecordingConfigurationsResponse>;
export type MaxStreamKeyResults = number;
export interface ListStreamKeysRequest {
    channelArn: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListStreamKeysRequest: S.Schema<ListStreamKeysRequest>;
export interface StreamKeySummary {
    arn?: string;
    channelArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StreamKeySummary: S.Schema<StreamKeySummary>;
export type StreamKeyList = StreamKeySummary[];
export declare const StreamKeyList: any;
export interface ListStreamKeysResponse {
    streamKeys: StreamKeySummary[];
    nextToken?: string;
}
export declare const ListStreamKeysResponse: S.Schema<ListStreamKeysResponse>;
export interface StreamFilters {
    health?: string;
}
export declare const StreamFilters: S.Schema<StreamFilters>;
export type MaxStreamResults = number;
export interface ListStreamsRequest {
    filterBy?: StreamFilters;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListStreamsRequest: S.Schema<ListStreamsRequest>;
export interface StreamSummary {
    channelArn?: string;
    streamId?: string;
    state?: string;
    health?: string;
    viewerCount?: number;
    startTime?: Date;
}
export declare const StreamSummary: S.Schema<StreamSummary>;
export type StreamList = StreamSummary[];
export declare const StreamList: any;
export interface ListStreamsResponse {
    streams: StreamSummary[];
    nextToken?: string;
}
export declare const ListStreamsResponse: S.Schema<ListStreamsResponse>;
export interface ListStreamSessionsRequest {
    channelArn: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListStreamSessionsRequest: S.Schema<ListStreamSessionsRequest>;
export interface StreamSessionSummary {
    streamId?: string;
    startTime?: Date;
    endTime?: Date;
    hasErrorEvent?: boolean;
}
export declare const StreamSessionSummary: S.Schema<StreamSessionSummary>;
export type StreamSessionList = StreamSessionSummary[];
export declare const StreamSessionList: any;
export interface ListStreamSessionsResponse {
    streamSessions: StreamSessionSummary[];
    nextToken?: string;
}
export declare const ListStreamSessionsResponse: S.Schema<ListStreamSessionsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type StreamMetadata = string | redacted.Redacted<string>;
export interface PutMetadataRequest {
    channelArn: string;
    metadata: string | redacted.Redacted<string>;
}
export declare const PutMetadataRequest: S.Schema<PutMetadataRequest>;
export interface PutMetadataResponse {
}
export declare const PutMetadataResponse: S.Schema<PutMetadataResponse>;
export interface StartViewerSessionRevocationRequest {
    channelArn: string;
    viewerId: string;
    viewerSessionVersionsLessThanOrEqualTo?: number;
}
export declare const StartViewerSessionRevocationRequest: S.Schema<StartViewerSessionRevocationRequest>;
export interface StartViewerSessionRevocationResponse {
}
export declare const StartViewerSessionRevocationResponse: S.Schema<StartViewerSessionRevocationResponse>;
export interface StopStreamRequest {
    channelArn: string;
}
export declare const StopStreamRequest: S.Schema<StopStreamRequest>;
export interface StopStreamResponse {
}
export declare const StopStreamResponse: S.Schema<StopStreamResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAdConfigurationRequest {
    arn: string;
    name?: string;
    mediaTailorPlaybackConfigurations?: MediaTailorPlaybackConfiguration[];
    postRollConfiguration?: PostRollConfiguration;
}
export declare const UpdateAdConfigurationRequest: S.Schema<UpdateAdConfigurationRequest>;
export interface UpdateAdConfigurationResponse {
    adConfiguration: AdConfiguration;
}
export declare const UpdateAdConfigurationResponse: S.Schema<UpdateAdConfigurationResponse>;
export interface UpdateChannelRequest {
    arn: string;
    name?: string;
    latencyMode?: string;
    type?: ChannelType;
    authorized?: boolean;
    recordingConfigurationArn?: string;
    insecureIngest?: boolean;
    preset?: TranscodePreset;
    playbackRestrictionPolicyArn?: string;
    multitrackInputConfiguration?: MultitrackInputConfiguration;
    containerFormat?: string;
    adConfigurationArn?: string;
}
export declare const UpdateChannelRequest: S.Schema<UpdateChannelRequest>;
export interface UpdateChannelResponse {
    channel?: Channel;
}
export declare const UpdateChannelResponse: S.Schema<UpdateChannelResponse>;
export interface UpdatePlaybackRestrictionPolicyRequest {
    arn: string;
    allowedCountries?: string[];
    allowedOrigins?: string[];
    enableStrictOriginEnforcement?: boolean;
    name?: string;
}
export declare const UpdatePlaybackRestrictionPolicyRequest: S.Schema<UpdatePlaybackRestrictionPolicyRequest>;
export interface UpdatePlaybackRestrictionPolicyResponse {
    playbackRestrictionPolicy?: PlaybackRestrictionPolicy;
}
export declare const UpdatePlaybackRestrictionPolicyResponse: S.Schema<UpdatePlaybackRestrictionPolicyResponse>;
export type BatchGetChannelError = AccessDeniedException | ServiceUnavailable | ValidationException | CommonErrors;
/**
 * Performs GetChannel on multiple ARNs simultaneously.
 */
export declare const batchGetChannel: API.OperationMethod<BatchGetChannelRequest, BatchGetChannelResponse, BatchGetChannelError, Credentials | HttpClient.HttpClient>;
export type BatchGetStreamKeyError = AccessDeniedException | ServiceUnavailable | ValidationException | CommonErrors;
/**
 * Performs GetStreamKey on multiple ARNs simultaneously.
 */
export declare const batchGetStreamKey: API.OperationMethod<BatchGetStreamKeyRequest, BatchGetStreamKeyResponse, BatchGetStreamKeyError, Credentials | HttpClient.HttpClient>;
export type BatchStartViewerSessionRevocationError = AccessDeniedException | PendingVerification | ThrottlingException | ValidationException | CommonErrors;
/**
 * Performs StartViewerSessionRevocation on multiple channel ARN and viewer ID pairs simultaneously.
 */
export declare const batchStartViewerSessionRevocation: API.OperationMethod<BatchStartViewerSessionRevocationRequest, BatchStartViewerSessionRevocationResponse, BatchStartViewerSessionRevocationError, Credentials | HttpClient.HttpClient>;
export type CreateAdConfigurationError = AccessDeniedException | ConflictException | InternalServerException | PendingVerification | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new ad configuration to be used for server-side ad insertion.
 */
export declare const createAdConfiguration: API.OperationMethod<CreateAdConfigurationRequest, CreateAdConfigurationResponse, CreateAdConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates a new channel and an associated stream key to start streaming.
 */
export declare const createChannel: API.OperationMethod<CreateChannelRequest, CreateChannelResponse, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreatePlaybackRestrictionPolicyError = AccessDeniedException | PendingVerification | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new playback restriction policy, for constraining playback by countries and/or origins.
 */
export declare const createPlaybackRestrictionPolicy: API.OperationMethod<CreatePlaybackRestrictionPolicyRequest, CreatePlaybackRestrictionPolicyResponse, CreatePlaybackRestrictionPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateRecordingConfigurationError = AccessDeniedException | ConflictException | InternalServerException | PendingVerification | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates a new recording configuration, used to enable recording to Amazon S3.
 *
 * **Known issue:** In the us-east-1 region, if you use the Amazon Web Services CLI to create a recording configuration, it returns success even if the S3 bucket is in a different region. In this case, the `state` of the recording configuration is `CREATE_FAILED` (instead of `ACTIVE`). (In other regions, the CLI correctly returns failure if the bucket is in a different region.)
 *
 * **Workaround:** Ensure that your S3 bucket is in the same region as the recording configuration. If you create a recording configuration in a different region as your S3 bucket, delete that recording configuration and create a new one with an S3 bucket from the correct region.
 */
export declare const createRecordingConfiguration: API.OperationMethod<CreateRecordingConfigurationRequest, CreateRecordingConfigurationResponse, CreateRecordingConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateStreamKeyError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates a stream key, used to initiate a stream, for the specified channel ARN.
 *
 * Note that CreateChannel creates a stream key. If you subsequently use CreateStreamKey on the same channel, it will fail because a stream key already exists and there is a limit of 1 stream key per channel. To reset the stream key on a channel, use DeleteStreamKey and then CreateStreamKey.
 */
export declare const createStreamKey: API.OperationMethod<CreateStreamKeyRequest, CreateStreamKeyResponse, CreateStreamKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteAdConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified ad configuration.
 */
export declare const deleteAdConfiguration: API.OperationMethod<DeleteAdConfigurationRequest, DeleteAdConfigurationResponse, DeleteAdConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified channel and its associated stream keys.
 *
 * If you try to delete a live channel, you will get an error (409 ConflictException). To delete a channel that is live, call StopStream, wait for the Amazon EventBridge "Stream End" event (to verify that the stream's state is no longer Live), then call DeleteChannel. (See Using EventBridge with Amazon IVS.)
 */
export declare const deleteChannel: API.OperationMethod<DeleteChannelRequest, DeleteChannelResponse, DeleteChannelError, Credentials | HttpClient.HttpClient>;
export type DeletePlaybackKeyPairError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | InternalServerException | CommonErrors;
/**
 * Deletes a specified authorization key pair. This invalidates future viewer tokens generated using the key pair’s `privateKey`. For more information, see Setting Up Private Channels in the *Amazon IVS User Guide*.
 */
export declare const deletePlaybackKeyPair: API.OperationMethod<DeletePlaybackKeyPairRequest, DeletePlaybackKeyPairResponse, DeletePlaybackKeyPairError, Credentials | HttpClient.HttpClient>;
export type DeletePlaybackRestrictionPolicyError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified playback restriction policy.
 */
export declare const deletePlaybackRestrictionPolicy: API.OperationMethod<DeletePlaybackRestrictionPolicyRequest, DeletePlaybackRestrictionPolicyResponse, DeletePlaybackRestrictionPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteRecordingConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the recording configuration for the specified ARN.
 *
 * If you try to delete a recording configuration that is associated with a channel, you will get an error (409 ConflictException). To avoid this, for all channels that reference the recording configuration, first use UpdateChannel to set the `recordingConfigurationArn` field to an empty string, then use DeleteRecordingConfiguration.
 */
export declare const deleteRecordingConfiguration: API.OperationMethod<DeleteRecordingConfigurationRequest, DeleteRecordingConfigurationResponse, DeleteRecordingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteStreamKeyError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the stream key for the specified ARN, so it can no longer be used to stream.
 */
export declare const deleteStreamKey: API.OperationMethod<DeleteStreamKeyRequest, DeleteStreamKeyResponse, DeleteStreamKeyError, Credentials | HttpClient.HttpClient>;
export type GetAdConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets the ad configuration represented by the specified ARN.
 */
export declare const getAdConfiguration: API.OperationMethod<GetAdConfigurationRequest, GetAdConfigurationResponse, GetAdConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetChannelError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets the channel configuration for the specified channel ARN. See also BatchGetChannel.
 */
export declare const getChannel: API.OperationMethod<GetChannelRequest, GetChannelResponse, GetChannelError, Credentials | HttpClient.HttpClient>;
export type GetPlaybackKeyPairError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets a specified playback authorization key pair and returns the `arn` and `fingerprint`. The `privateKey` held by the caller can be used to generate viewer authorization tokens, to grant viewers access to private channels. For more information, see Setting Up Private Channels in the *Amazon IVS User Guide*.
 */
export declare const getPlaybackKeyPair: API.OperationMethod<GetPlaybackKeyPairRequest, GetPlaybackKeyPairResponse, GetPlaybackKeyPairError, Credentials | HttpClient.HttpClient>;
export type GetPlaybackRestrictionPolicyError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets the specified playback restriction policy.
 */
export declare const getPlaybackRestrictionPolicy: API.OperationMethod<GetPlaybackRestrictionPolicyRequest, GetPlaybackRestrictionPolicyResponse, GetPlaybackRestrictionPolicyError, Credentials | HttpClient.HttpClient>;
export type GetRecordingConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets the recording configuration for the specified ARN.
 */
export declare const getRecordingConfiguration: API.OperationMethod<GetRecordingConfigurationRequest, GetRecordingConfigurationResponse, GetRecordingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetStreamError = AccessDeniedException | ChannelNotBroadcasting | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets information about the active (live) stream on a specified channel.
 */
export declare const getStream: API.OperationMethod<GetStreamRequest, GetStreamResponse, GetStreamError, Credentials | HttpClient.HttpClient>;
export type GetStreamKeyError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets stream-key information for a specified ARN.
 */
export declare const getStreamKey: API.OperationMethod<GetStreamKeyRequest, GetStreamKeyResponse, GetStreamKeyError, Credentials | HttpClient.HttpClient>;
export type GetStreamSessionError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets metadata on a specified stream.
 */
export declare const getStreamSession: API.OperationMethod<GetStreamSessionRequest, GetStreamSessionResponse, GetStreamSessionError, Credentials | HttpClient.HttpClient>;
export type ImportPlaybackKeyPairError = AccessDeniedException | ConflictException | PendingVerification | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Imports the public portion of a new key pair and returns its `arn` and `fingerprint`. The `privateKey` can then be used to generate viewer authorization tokens, to grant viewers access to private channels. For more information, see Setting Up Private Channels in the *Amazon IVS User Guide*.
 */
export declare const importPlaybackKeyPair: API.OperationMethod<ImportPlaybackKeyPairRequest, ImportPlaybackKeyPairResponse, ImportPlaybackKeyPairError, Credentials | HttpClient.HttpClient>;
export type InsertAdBreakError = AccessDeniedException | ChannelNotBroadcasting | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Inserts an ad marker in the playlist for the specified channel and duration using the ad configuration associated with the channel.
 *
 * **Note:** AWS Elemental MediaTailor (EMT), the service that handles ad requests, provides CloudWatch metrics to help you monitor the success or failure of each InsertAdBreak operation. See Monitoring AWS Elemental MediaTailor with Amazon CloudWatch metrics in the *AWS Elemental MediaTailor User Guide* for details on available metrics.
 */
export declare const insertAdBreak: API.OperationMethod<InsertAdBreakRequest, InsertAdBreakResponse, InsertAdBreakError, Credentials | HttpClient.HttpClient>;
export type ListAdConfigurationsError = AccessDeniedException | InternalServerException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about all ad configurations in your account, in the AWS region where the API request is processed.
 */
export declare const listAdConfigurations: API.PaginatedOperationMethod<ListAdConfigurationsRequest, ListAdConfigurationsResponse, ListAdConfigurationsError, Credentials | HttpClient.HttpClient, AdConfigurationSummary>;
export type ListChannelsError = AccessDeniedException | ConflictException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about all channels in your account, in the Amazon Web Services region where the API request is processed. This list can be filtered to match a specified name or recording-configuration ARN. Filters are mutually exclusive and cannot be used together. If you try to use both filters, you will get an error (409 ConflictException).
 */
export declare const listChannels: API.PaginatedOperationMethod<ListChannelsRequest, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPlaybackKeyPairsError = AccessDeniedException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about playback key pairs. For more information, see Setting Up Private Channels in the *Amazon IVS User Guide*.
 */
export declare const listPlaybackKeyPairs: API.PaginatedOperationMethod<ListPlaybackKeyPairsRequest, ListPlaybackKeyPairsResponse, ListPlaybackKeyPairsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPlaybackRestrictionPoliciesError = AccessDeniedException | ConflictException | PendingVerification | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about playback restriction policies.
 */
export declare const listPlaybackRestrictionPolicies: API.PaginatedOperationMethod<ListPlaybackRestrictionPoliciesRequest, ListPlaybackRestrictionPoliciesResponse, ListPlaybackRestrictionPoliciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRecordingConfigurationsError = AccessDeniedException | InternalServerException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about all recording configurations in your account, in the Amazon Web Services region where the API request is processed.
 */
export declare const listRecordingConfigurations: API.PaginatedOperationMethod<ListRecordingConfigurationsRequest, ListRecordingConfigurationsResponse, ListRecordingConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListStreamKeysError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about stream keys for the specified channel.
 */
export declare const listStreamKeys: API.PaginatedOperationMethod<ListStreamKeysRequest, ListStreamKeysResponse, ListStreamKeysError, Credentials | HttpClient.HttpClient, unknown>;
export type ListStreamsError = AccessDeniedException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about live streams in your account, in the Amazon Web Services region where the API request is processed.
 */
export declare const listStreams: API.PaginatedOperationMethod<ListStreamsRequest, ListStreamsResponse, ListStreamsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListStreamSessionsError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets a summary of current and previous streams for a specified channel in your account, in the AWS region where the API request is processed.
 */
export declare const listStreamSessions: API.PaginatedOperationMethod<ListStreamSessionsRequest, ListStreamSessionsResponse, ListStreamSessionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets information about Amazon Web Services tags for the specified ARN.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutMetadataError = AccessDeniedException | ChannelNotBroadcasting | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Inserts metadata into the active stream of the specified channel. At most 5 requests per second per channel are allowed, each with a maximum 1 KB payload. (If 5 TPS is not sufficient for your needs, we recommend batching your data into a single PutMetadata call.) At most 155 requests per second per account are allowed. Also see Embedding Metadata within a Video Stream in the *Amazon IVS User Guide*.
 */
export declare const putMetadata: API.OperationMethod<PutMetadataRequest, PutMetadataResponse, PutMetadataError, Credentials | HttpClient.HttpClient>;
export type StartViewerSessionRevocationError = AccessDeniedException | InternalServerException | PendingVerification | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the process of revoking the viewer session associated with a specified channel ARN and viewer ID. Optionally, you can provide a version to revoke viewer sessions less than and including that version. For instructions on associating a viewer ID with a viewer session, see Setting Up Private Channels.
 */
export declare const startViewerSessionRevocation: API.OperationMethod<StartViewerSessionRevocationRequest, StartViewerSessionRevocationResponse, StartViewerSessionRevocationError, Credentials | HttpClient.HttpClient>;
export type StopStreamError = AccessDeniedException | ChannelNotBroadcasting | ResourceNotFoundException | StreamUnavailable | ValidationException | ThrottlingException | CommonErrors;
/**
 * Disconnects the incoming RTMPS stream for the specified channel. Can be used in conjunction with DeleteStreamKey to prevent further streaming to a channel.
 *
 * Many streaming client-software libraries automatically reconnect a dropped RTMPS session, so to stop the stream permanently, you may want to first revoke the `streamKey` attached to the channel.
 */
export declare const stopStream: API.OperationMethod<StopStreamRequest, StopStreamResponse, StopStreamError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Adds or updates tags for the Amazon Web Services resource with the specified ARN.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Removes tags from the resource with the specified ARN.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAdConfigurationError = AccessDeniedException | ConflictException | InternalServerException | PendingVerification | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a specified ad configuration.
 */
export declare const updateAdConfiguration: API.OperationMethod<UpdateAdConfigurationRequest, UpdateAdConfigurationResponse, UpdateAdConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Updates a channel's configuration. Live channels cannot be updated. You must stop the ongoing stream, update the channel, and restart the stream for the changes to take effect.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelRequest, UpdateChannelResponse, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdatePlaybackRestrictionPolicyError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a specified playback restriction policy.
 */
export declare const updatePlaybackRestrictionPolicy: API.OperationMethod<UpdatePlaybackRestrictionPolicyRequest, UpdatePlaybackRestrictionPolicyResponse, UpdatePlaybackRestrictionPolicyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ivs.d.ts.map