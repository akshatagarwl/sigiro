import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ForbiddenException_base: S.Class<ForbiddenException, S.TaggedStruct<"ForbiddenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GoneException_base: S.Class<GoneException, S.TaggedStruct<"GoneException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GoneException extends /*@__PURE__*/ GoneException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const PayloadTooLargeException_base: S.Class<PayloadTooLargeException, S.TaggedStruct<"PayloadTooLargeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PayloadTooLargeException extends /*@__PURE__*/ PayloadTooLargeException_base {
}
export interface DeleteConnectionRequest {
    ConnectionId: string;
}
export declare const DeleteConnectionRequest: S.Schema<DeleteConnectionRequest>;
export interface DeleteConnectionResponse {
}
export declare const DeleteConnectionResponse: S.Schema<DeleteConnectionResponse>;
export interface GetConnectionRequest {
    ConnectionId: string;
}
export declare const GetConnectionRequest: S.Schema<GetConnectionRequest>;
export type __timestampIso8601 = Date;
export interface Identity {
    SourceIp?: string;
    UserAgent?: string;
}
export declare const Identity: S.Schema<Identity>;
export interface GetConnectionResponse {
    ConnectedAt?: Date;
    Identity?: Identity & {
        SourceIp: string;
        UserAgent: string;
    };
    LastActiveAt?: Date;
}
export declare const GetConnectionResponse: S.Schema<GetConnectionResponse>;
export interface PostToConnectionRequest {
    Data?: T.StreamingInputBody;
    ConnectionId: string;
}
export declare const PostToConnectionRequest: S.Schema<PostToConnectionRequest>;
export interface PostToConnectionResponse {
}
export declare const PostToConnectionResponse: S.Schema<PostToConnectionResponse>;
export type DeleteConnectionError = ForbiddenException | GoneException | LimitExceededException | CommonErrors;
/**
 * Delete the connection with the provided id.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionRequest, DeleteConnectionResponse, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type GetConnectionError = ForbiddenException | GoneException | LimitExceededException | CommonErrors;
/**
 * Get information about the connection with the provided id.
 */
export declare const getConnection: API.OperationMethod<GetConnectionRequest, GetConnectionResponse, GetConnectionError, Credentials | HttpClient.HttpClient>;
export type PostToConnectionError = ForbiddenException | GoneException | LimitExceededException | PayloadTooLargeException | CommonErrors;
/**
 * Sends the provided data to the specified connection.
 */
export declare const postToConnection: API.OperationMethod<PostToConnectionRequest, PostToConnectionResponse, PostToConnectionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=apigatewaymanagementapi.d.ts.map