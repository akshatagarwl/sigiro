import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const DependentServiceFailureException_base: S.Class<DependentServiceFailureException, S.TaggedStruct<"DependentServiceFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DependentServiceFailureException extends /*@__PURE__*/ DependentServiceFailureException_base {
}
declare const InternalFailureException_base: S.Class<InternalFailureException, S.TaggedStruct<"InternalFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TimeoutException_base: S.Class<TimeoutException, S.TaggedStruct<"TimeoutException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TimeoutException extends /*@__PURE__*/ TimeoutException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type Name = string;
export type Description = string;
export type Repository = string;
export type Platform = "WEB" | "WEB_DYNAMIC" | "WEB_COMPUTE" | (string & {});
export declare const Platform: any;
export type ComputeRoleArn = string;
export type ServiceRoleArn = string;
export type OauthToken = string | redacted.Redacted<string>;
export type AccessToken = string | redacted.Redacted<string>;
export type EnvKey = string;
export type EnvValue = string;
export type EnvironmentVariables = {
    [key: string]: string | undefined;
};
export declare const EnvironmentVariables: any;
export type EnableBranchAutoBuild = boolean;
export type EnableBranchAutoDeletion = boolean;
export type EnableBasicAuth = boolean;
export type BasicAuthCredentials = string | redacted.Redacted<string>;
export type Source = string;
export type Target = string;
export type Status = string;
export type Condition = string;
export interface CustomRule {
    source: string;
    target: string;
    status?: string;
    condition?: string;
}
export declare const CustomRule: S.Schema<CustomRule>;
export type CustomRules = CustomRule[];
export declare const CustomRules: any;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type BuildSpec = string | redacted.Redacted<string>;
export type CustomHeaders = string;
export type EnableAutoBranchCreation = boolean;
export type AutoBranchCreationPattern = string;
export type AutoBranchCreationPatterns = string[];
export declare const AutoBranchCreationPatterns: any;
export type Stage = "PRODUCTION" | "BETA" | "DEVELOPMENT" | "EXPERIMENTAL" | "PULL_REQUEST" | (string & {});
export declare const Stage: any;
export type Framework = string;
export type EnableAutoBuild = boolean;
export type EnablePerformanceMode = boolean;
export type EnablePullRequestPreview = boolean;
export type PullRequestEnvironmentName = string;
export interface AutoBranchCreationConfig {
    stage?: Stage;
    framework?: string;
    enableAutoBuild?: boolean;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    basicAuthCredentials?: string | redacted.Redacted<string>;
    enableBasicAuth?: boolean;
    enablePerformanceMode?: boolean;
    buildSpec?: string | redacted.Redacted<string>;
    enablePullRequestPreview?: boolean;
    pullRequestEnvironmentName?: string;
}
export declare const AutoBranchCreationConfig: S.Schema<AutoBranchCreationConfig>;
export type BuildComputeType = "STANDARD_8GB" | "LARGE_16GB" | "XLARGE_72GB" | (string & {});
export declare const BuildComputeType: any;
export interface JobConfig {
    buildComputeType: BuildComputeType;
}
export declare const JobConfig: S.Schema<JobConfig>;
export type CacheConfigType = "AMPLIFY_MANAGED" | "AMPLIFY_MANAGED_NO_COOKIES" | (string & {});
export declare const CacheConfigType: any;
export interface CacheConfig {
    type: CacheConfigType;
}
export declare const CacheConfig: S.Schema<CacheConfig>;
export interface CreateAppRequest {
    name: string;
    description?: string;
    repository?: string;
    platform?: Platform;
    computeRoleArn?: string;
    iamServiceRoleArn?: string;
    oauthToken?: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    enableBranchAutoBuild?: boolean;
    enableBranchAutoDeletion?: boolean;
    enableBasicAuth?: boolean;
    basicAuthCredentials?: string | redacted.Redacted<string>;
    customRules?: CustomRule[];
    tags?: {
        [key: string]: string | undefined;
    };
    buildSpec?: string | redacted.Redacted<string>;
    customHeaders?: string;
    enableAutoBranchCreation?: boolean;
    autoBranchCreationPatterns?: string[];
    autoBranchCreationConfig?: AutoBranchCreationConfig;
    jobConfig?: JobConfig;
    cacheConfig?: CacheConfig;
}
export declare const CreateAppRequest: S.Schema<CreateAppRequest>;
export type AppId = string;
export type AppArn = string;
export type CreateTime = Date;
export type UpdateTime = Date;
export type DefaultDomain = string;
export type LastDeployTime = Date;
export type ThumbnailUrl = string;
export type BranchName = string;
export interface ProductionBranch {
    lastDeployTime?: Date;
    status?: string;
    thumbnailUrl?: string;
    branchName?: string;
}
export declare const ProductionBranch: S.Schema<ProductionBranch>;
export type RepositoryCloneMethod = "SSH" | "TOKEN" | "SIGV4" | (string & {});
export declare const RepositoryCloneMethod: any;
export type WebhookCreateTime = Date;
export type WebAclArn = string;
export type WafStatus = "ASSOCIATING" | "ASSOCIATION_FAILED" | "ASSOCIATION_SUCCESS" | "DISASSOCIATING" | "DISASSOCIATION_FAILED" | (string & {});
export declare const WafStatus: any;
export type StatusReason = string;
export interface WafConfiguration {
    webAclArn?: string;
    wafStatus?: WafStatus;
    statusReason?: string;
}
export declare const WafConfiguration: S.Schema<WafConfiguration>;
export interface App {
    appId: string;
    appArn: string;
    name: string;
    tags?: {
        [key: string]: string | undefined;
    };
    description?: string;
    repository?: string;
    platform?: Platform;
    createTime: Date;
    updateTime: Date;
    computeRoleArn?: string;
    iamServiceRoleArn?: string;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    defaultDomain?: string;
    enableBranchAutoBuild?: boolean;
    enableBranchAutoDeletion?: boolean;
    enableBasicAuth?: boolean;
    basicAuthCredentials?: string | redacted.Redacted<string>;
    customRules?: CustomRule[];
    productionBranch?: ProductionBranch;
    buildSpec?: string | redacted.Redacted<string>;
    customHeaders?: string;
    enableAutoBranchCreation?: boolean;
    autoBranchCreationPatterns?: string[];
    autoBranchCreationConfig?: AutoBranchCreationConfig;
    repositoryCloneMethod?: RepositoryCloneMethod;
    cacheConfig?: CacheConfig;
    webhookCreateTime?: Date;
    wafConfiguration?: WafConfiguration;
    jobConfig?: JobConfig;
}
export declare const App: S.Schema<App>;
export interface CreateAppResult {
    app: App;
}
export declare const CreateAppResult: S.Schema<CreateAppResult>;
export type EnvironmentName = string;
export type StackName = string;
export type DeploymentArtifacts = string;
export interface CreateBackendEnvironmentRequest {
    appId: string;
    environmentName: string;
    stackName?: string;
    deploymentArtifacts?: string;
}
export declare const CreateBackendEnvironmentRequest: S.Schema<CreateBackendEnvironmentRequest>;
export type BackendEnvironmentArn = string;
export interface BackendEnvironment {
    backendEnvironmentArn: string;
    environmentName: string;
    stackName?: string;
    deploymentArtifacts?: string;
    createTime: Date;
    updateTime: Date;
}
export declare const BackendEnvironment: S.Schema<BackendEnvironment>;
export interface CreateBackendEnvironmentResult {
    backendEnvironment: BackendEnvironment;
}
export declare const CreateBackendEnvironmentResult: S.Schema<CreateBackendEnvironmentResult>;
export type EnableNotification = boolean;
export type EnableSkewProtection = boolean;
export type TTL = string;
export type DisplayName = string;
export type StackArn = string;
export interface Backend {
    stackArn?: string;
}
export declare const Backend: S.Schema<Backend>;
export interface CreateBranchRequest {
    appId: string;
    branchName: string;
    description?: string;
    stage?: Stage;
    framework?: string;
    enableNotification?: boolean;
    enableAutoBuild?: boolean;
    enableSkewProtection?: boolean;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    basicAuthCredentials?: string | redacted.Redacted<string>;
    enableBasicAuth?: boolean;
    enablePerformanceMode?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
    buildSpec?: string | redacted.Redacted<string>;
    ttl?: string;
    displayName?: string;
    enablePullRequestPreview?: boolean;
    pullRequestEnvironmentName?: string;
    backendEnvironmentArn?: string;
    backend?: Backend;
    computeRoleArn?: string;
}
export declare const CreateBranchRequest: S.Schema<CreateBranchRequest>;
export type BranchArn = string;
export type CustomDomain = string;
export type CustomDomains = string[];
export declare const CustomDomains: any;
export type ActiveJobId = string;
export type TotalNumberOfJobs = string;
export type AssociatedResource = string;
export type AssociatedResources = string[];
export declare const AssociatedResources: any;
export interface Branch {
    branchArn: string;
    branchName: string;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    stage?: Stage;
    displayName?: string;
    enableNotification?: boolean;
    createTime: Date;
    updateTime: Date;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    enableAutoBuild?: boolean;
    enableSkewProtection?: boolean;
    customDomains?: string[];
    framework?: string;
    activeJobId?: string;
    totalNumberOfJobs?: string;
    enableBasicAuth?: boolean;
    enablePerformanceMode?: boolean;
    thumbnailUrl?: string;
    basicAuthCredentials?: string | redacted.Redacted<string>;
    buildSpec?: string | redacted.Redacted<string>;
    ttl?: string;
    associatedResources?: string[];
    enablePullRequestPreview?: boolean;
    pullRequestEnvironmentName?: string;
    destinationBranch?: string;
    sourceBranch?: string;
    backendEnvironmentArn?: string;
    backend?: Backend;
    computeRoleArn?: string;
}
export declare const Branch: S.Schema<Branch>;
export interface CreateBranchResult {
    branch: Branch;
}
export declare const CreateBranchResult: S.Schema<CreateBranchResult>;
export type FileName = string;
export type MD5Hash = string;
export type FileMap = {
    [key: string]: string | undefined;
};
export declare const FileMap: any;
export interface CreateDeploymentRequest {
    appId: string;
    branchName: string;
    fileMap?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDeploymentRequest: S.Schema<CreateDeploymentRequest>;
export type JobId = string;
export type UploadUrl = string;
export type FileUploadUrls = {
    [key: string]: string | undefined;
};
export declare const FileUploadUrls: any;
export interface CreateDeploymentResult {
    jobId?: string;
    fileUploadUrls?: {
        [key: string]: string | undefined;
    };
    zipUploadUrl: string;
}
export declare const CreateDeploymentResult: S.Schema<CreateDeploymentResult>;
export type DomainName = string;
export type EnableAutoSubDomain = boolean;
export type DomainPrefix = string;
export interface SubDomainSetting {
    prefix: string;
    branchName: string;
}
export declare const SubDomainSetting: S.Schema<SubDomainSetting>;
export type SubDomainSettings = SubDomainSetting[];
export declare const SubDomainSettings: any;
export type AutoSubDomainCreationPattern = string;
export type AutoSubDomainCreationPatterns = string[];
export declare const AutoSubDomainCreationPatterns: any;
export type AutoSubDomainIAMRole = string;
export type CertificateType = "AMPLIFY_MANAGED" | "CUSTOM" | (string & {});
export declare const CertificateType: any;
export type CertificateArn = string;
export interface CertificateSettings {
    type: CertificateType;
    customCertificateArn?: string;
}
export declare const CertificateSettings: S.Schema<CertificateSettings>;
export interface CreateDomainAssociationRequest {
    appId: string;
    domainName: string;
    enableAutoSubDomain?: boolean;
    subDomainSettings: SubDomainSetting[];
    autoSubDomainCreationPatterns?: string[];
    autoSubDomainIAMRole?: string;
    certificateSettings?: CertificateSettings;
}
export declare const CreateDomainAssociationRequest: S.Schema<CreateDomainAssociationRequest>;
export type DomainAssociationArn = string;
export type DomainStatus = "PENDING_VERIFICATION" | "IN_PROGRESS" | "AVAILABLE" | "IMPORTING_CUSTOM_CERTIFICATE" | "PENDING_DEPLOYMENT" | "AWAITING_APP_CNAME" | "FAILED" | "CREATING" | "REQUESTING_CERTIFICATE" | "UPDATING" | (string & {});
export declare const DomainStatus: any;
export type UpdateStatus = "REQUESTING_CERTIFICATE" | "PENDING_VERIFICATION" | "IMPORTING_CUSTOM_CERTIFICATE" | "PENDING_DEPLOYMENT" | "AWAITING_APP_CNAME" | "UPDATE_COMPLETE" | "UPDATE_FAILED" | (string & {});
export declare const UpdateStatus: any;
export type CertificateVerificationDNSRecord = string;
export type Verified = boolean;
export type DNSRecord = string;
export interface SubDomain {
    subDomainSetting: SubDomainSetting;
    verified: boolean;
    dnsRecord: string;
}
export declare const SubDomain: S.Schema<SubDomain>;
export type SubDomains = SubDomain[];
export declare const SubDomains: any;
export interface Certificate {
    type: CertificateType;
    customCertificateArn?: string;
    certificateVerificationDNSRecord?: string;
}
export declare const Certificate: S.Schema<Certificate>;
export interface DomainAssociation {
    domainAssociationArn: string;
    domainName: string;
    enableAutoSubDomain: boolean;
    autoSubDomainCreationPatterns?: string[];
    autoSubDomainIAMRole?: string;
    domainStatus: DomainStatus;
    updateStatus?: UpdateStatus;
    statusReason: string;
    certificateVerificationDNSRecord?: string;
    subDomains: SubDomain[];
    certificate?: Certificate;
}
export declare const DomainAssociation: S.Schema<DomainAssociation>;
export interface CreateDomainAssociationResult {
    domainAssociation: DomainAssociation;
}
export declare const CreateDomainAssociationResult: S.Schema<CreateDomainAssociationResult>;
export interface CreateWebhookRequest {
    appId: string;
    branchName: string;
    description?: string;
}
export declare const CreateWebhookRequest: S.Schema<CreateWebhookRequest>;
export type WebhookArn = string;
export type WebhookId = string;
export type WebhookUrl = string;
export interface Webhook {
    webhookArn: string;
    webhookId: string;
    webhookUrl: string;
    appId?: string;
    branchName: string;
    description: string;
    createTime: Date;
    updateTime: Date;
}
export declare const Webhook: S.Schema<Webhook>;
export interface CreateWebhookResult {
    webhook: Webhook;
}
export declare const CreateWebhookResult: S.Schema<CreateWebhookResult>;
export interface DeleteAppRequest {
    appId: string;
}
export declare const DeleteAppRequest: S.Schema<DeleteAppRequest>;
export interface DeleteAppResult {
    app: App;
}
export declare const DeleteAppResult: S.Schema<DeleteAppResult>;
export interface DeleteBackendEnvironmentRequest {
    appId: string;
    environmentName: string;
}
export declare const DeleteBackendEnvironmentRequest: S.Schema<DeleteBackendEnvironmentRequest>;
export interface DeleteBackendEnvironmentResult {
    backendEnvironment: BackendEnvironment;
}
export declare const DeleteBackendEnvironmentResult: S.Schema<DeleteBackendEnvironmentResult>;
export interface DeleteBranchRequest {
    appId: string;
    branchName: string;
}
export declare const DeleteBranchRequest: S.Schema<DeleteBranchRequest>;
export interface DeleteBranchResult {
    branch: Branch;
}
export declare const DeleteBranchResult: S.Schema<DeleteBranchResult>;
export interface DeleteDomainAssociationRequest {
    appId: string;
    domainName: string;
}
export declare const DeleteDomainAssociationRequest: S.Schema<DeleteDomainAssociationRequest>;
export interface DeleteDomainAssociationResult {
    domainAssociation: DomainAssociation;
}
export declare const DeleteDomainAssociationResult: S.Schema<DeleteDomainAssociationResult>;
export interface DeleteJobRequest {
    appId: string;
    branchName: string;
    jobId: string;
}
export declare const DeleteJobRequest: S.Schema<DeleteJobRequest>;
export type JobArn = string;
export type CommitId = string;
export type CommitMessage = string;
export type CommitTime = Date;
export type StartTime = Date;
export type JobStatus = "CREATED" | "PENDING" | "PROVISIONING" | "RUNNING" | "FAILED" | "SUCCEED" | "CANCELLING" | "CANCELLED" | (string & {});
export declare const JobStatus: any;
export type EndTime = Date;
export type JobType = "RELEASE" | "RETRY" | "MANUAL" | "WEB_HOOK" | (string & {});
export declare const JobType: any;
export type SourceUrl = string;
export type SourceUrlType = "ZIP" | "BUCKET_PREFIX" | (string & {});
export declare const SourceUrlType: any;
export interface JobSummary {
    jobArn: string;
    jobId: string;
    commitId?: string;
    commitMessage?: string;
    commitTime?: Date;
    startTime: Date;
    status: JobStatus;
    endTime?: Date;
    jobType?: JobType;
    sourceUrl?: string;
    sourceUrlType?: SourceUrlType;
}
export declare const JobSummary: S.Schema<JobSummary>;
export interface DeleteJobResult {
    jobSummary: JobSummary;
}
export declare const DeleteJobResult: S.Schema<DeleteJobResult>;
export interface DeleteWebhookRequest {
    webhookId: string;
}
export declare const DeleteWebhookRequest: S.Schema<DeleteWebhookRequest>;
export interface DeleteWebhookResult {
    webhook: Webhook;
}
export declare const DeleteWebhookResult: S.Schema<DeleteWebhookResult>;
export interface GenerateAccessLogsRequest {
    startTime?: Date;
    endTime?: Date;
    domainName: string;
    appId: string;
}
export declare const GenerateAccessLogsRequest: S.Schema<GenerateAccessLogsRequest>;
export type LogUrl = string;
export interface GenerateAccessLogsResult {
    logUrl?: string;
}
export declare const GenerateAccessLogsResult: S.Schema<GenerateAccessLogsResult>;
export interface GetAppRequest {
    appId: string;
}
export declare const GetAppRequest: S.Schema<GetAppRequest>;
export interface GetAppResult {
    app: App;
}
export declare const GetAppResult: S.Schema<GetAppResult>;
export type ArtifactId = string;
export interface GetArtifactUrlRequest {
    artifactId: string;
}
export declare const GetArtifactUrlRequest: S.Schema<GetArtifactUrlRequest>;
export type ArtifactUrl = string;
export interface GetArtifactUrlResult {
    artifactId: string;
    artifactUrl: string;
}
export declare const GetArtifactUrlResult: S.Schema<GetArtifactUrlResult>;
export interface GetBackendEnvironmentRequest {
    appId: string;
    environmentName: string;
}
export declare const GetBackendEnvironmentRequest: S.Schema<GetBackendEnvironmentRequest>;
export interface GetBackendEnvironmentResult {
    backendEnvironment: BackendEnvironment;
}
export declare const GetBackendEnvironmentResult: S.Schema<GetBackendEnvironmentResult>;
export interface GetBranchRequest {
    appId: string;
    branchName: string;
}
export declare const GetBranchRequest: S.Schema<GetBranchRequest>;
export interface GetBranchResult {
    branch: Branch;
}
export declare const GetBranchResult: S.Schema<GetBranchResult>;
export interface GetDomainAssociationRequest {
    appId: string;
    domainName: string;
}
export declare const GetDomainAssociationRequest: S.Schema<GetDomainAssociationRequest>;
export interface GetDomainAssociationResult {
    domainAssociation: DomainAssociation;
}
export declare const GetDomainAssociationResult: S.Schema<GetDomainAssociationResult>;
export interface GetJobRequest {
    appId: string;
    branchName: string;
    jobId: string;
}
export declare const GetJobRequest: S.Schema<GetJobRequest>;
export type StepName = string;
export type ArtifactsUrl = string;
export type TestArtifactsUrl = string;
export type TestConfigUrl = string;
export type ThumbnailName = string;
export type Screenshots = {
    [key: string]: string | undefined;
};
export declare const Screenshots: any;
export type Context = string;
export interface Step {
    stepName: string;
    startTime: Date;
    status: JobStatus;
    endTime?: Date;
    logUrl?: string;
    artifactsUrl?: string;
    testArtifactsUrl?: string;
    testConfigUrl?: string;
    screenshots?: {
        [key: string]: string | undefined;
    };
    statusReason?: string;
    context?: string;
}
export declare const Step: S.Schema<Step>;
export type Steps = Step[];
export declare const Steps: any;
export interface Job {
    summary: JobSummary;
    steps: Step[];
}
export declare const Job: S.Schema<Job>;
export interface GetJobResult {
    job: Job;
}
export declare const GetJobResult: S.Schema<GetJobResult>;
export interface GetWebhookRequest {
    webhookId: string;
}
export declare const GetWebhookRequest: S.Schema<GetWebhookRequest>;
export interface GetWebhookResult {
    webhook: Webhook;
}
export declare const GetWebhookResult: S.Schema<GetWebhookResult>;
export type NextToken = string;
export type MaxResultsForListApps = number;
export interface ListAppsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAppsRequest: S.Schema<ListAppsRequest>;
export type Apps = App[];
export declare const Apps: any;
export interface ListAppsResult {
    apps: App[];
    nextToken?: string;
}
export declare const ListAppsResult: S.Schema<ListAppsResult>;
export type MaxResults = number;
export interface ListArtifactsRequest {
    appId: string;
    branchName: string;
    jobId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListArtifactsRequest: S.Schema<ListArtifactsRequest>;
export type ArtifactFileName = string;
export interface Artifact {
    artifactFileName: string;
    artifactId: string;
}
export declare const Artifact: S.Schema<Artifact>;
export type Artifacts = Artifact[];
export declare const Artifacts: any;
export interface ListArtifactsResult {
    artifacts: Artifact[];
    nextToken?: string;
}
export declare const ListArtifactsResult: S.Schema<ListArtifactsResult>;
export interface ListBackendEnvironmentsRequest {
    appId: string;
    environmentName?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListBackendEnvironmentsRequest: S.Schema<ListBackendEnvironmentsRequest>;
export type BackendEnvironments = BackendEnvironment[];
export declare const BackendEnvironments: any;
export interface ListBackendEnvironmentsResult {
    backendEnvironments: BackendEnvironment[];
    nextToken?: string;
}
export declare const ListBackendEnvironmentsResult: S.Schema<ListBackendEnvironmentsResult>;
export interface ListBranchesRequest {
    appId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListBranchesRequest: S.Schema<ListBranchesRequest>;
export type Branches = Branch[];
export declare const Branches: any;
export interface ListBranchesResult {
    branches: Branch[];
    nextToken?: string;
}
export declare const ListBranchesResult: S.Schema<ListBranchesResult>;
export interface ListDomainAssociationsRequest {
    appId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDomainAssociationsRequest: S.Schema<ListDomainAssociationsRequest>;
export type DomainAssociations = DomainAssociation[];
export declare const DomainAssociations: any;
export interface ListDomainAssociationsResult {
    domainAssociations: DomainAssociation[];
    nextToken?: string;
}
export declare const ListDomainAssociationsResult: S.Schema<ListDomainAssociationsResult>;
export interface ListJobsRequest {
    appId: string;
    branchName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListJobsRequest: S.Schema<ListJobsRequest>;
export type JobSummaries = JobSummary[];
export declare const JobSummaries: any;
export interface ListJobsResult {
    jobSummaries: JobSummary[];
    nextToken?: string;
}
export declare const ListJobsResult: S.Schema<ListJobsResult>;
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListWebhooksRequest {
    appId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListWebhooksRequest: S.Schema<ListWebhooksRequest>;
export type Webhooks = Webhook[];
export declare const Webhooks: any;
export interface ListWebhooksResult {
    webhooks: Webhook[];
    nextToken?: string;
}
export declare const ListWebhooksResult: S.Schema<ListWebhooksResult>;
export interface StartDeploymentRequest {
    appId: string;
    branchName: string;
    jobId?: string;
    sourceUrl?: string;
    sourceUrlType?: SourceUrlType;
}
export declare const StartDeploymentRequest: S.Schema<StartDeploymentRequest>;
export interface StartDeploymentResult {
    jobSummary: JobSummary;
}
export declare const StartDeploymentResult: S.Schema<StartDeploymentResult>;
export type JobReason = string;
export interface StartJobRequest {
    appId: string;
    branchName: string;
    jobId?: string;
    jobType: JobType;
    jobReason?: string;
    commitId?: string;
    commitMessage?: string;
    commitTime?: Date;
}
export declare const StartJobRequest: S.Schema<StartJobRequest>;
export interface StartJobResult {
    jobSummary: JobSummary;
}
export declare const StartJobResult: S.Schema<StartJobResult>;
export interface StopJobRequest {
    appId: string;
    branchName: string;
    jobId: string;
}
export declare const StopJobRequest: S.Schema<StopJobRequest>;
export interface StopJobResult {
    jobSummary: JobSummary;
}
export declare const StopJobResult: S.Schema<StopJobResult>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAppRequest {
    appId: string;
    name?: string;
    description?: string;
    platform?: Platform;
    computeRoleArn?: string;
    iamServiceRoleArn?: string;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    enableBranchAutoBuild?: boolean;
    enableBranchAutoDeletion?: boolean;
    enableBasicAuth?: boolean;
    basicAuthCredentials?: string | redacted.Redacted<string>;
    customRules?: CustomRule[];
    buildSpec?: string | redacted.Redacted<string>;
    customHeaders?: string;
    enableAutoBranchCreation?: boolean;
    autoBranchCreationPatterns?: string[];
    autoBranchCreationConfig?: AutoBranchCreationConfig;
    repository?: string;
    oauthToken?: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    jobConfig?: JobConfig;
    cacheConfig?: CacheConfig;
}
export declare const UpdateAppRequest: S.Schema<UpdateAppRequest>;
export interface UpdateAppResult {
    app: App;
}
export declare const UpdateAppResult: S.Schema<UpdateAppResult>;
export interface UpdateBranchRequest {
    appId: string;
    branchName: string;
    description?: string;
    framework?: string;
    stage?: Stage;
    enableNotification?: boolean;
    enableAutoBuild?: boolean;
    enableSkewProtection?: boolean;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    basicAuthCredentials?: string | redacted.Redacted<string>;
    enableBasicAuth?: boolean;
    enablePerformanceMode?: boolean;
    buildSpec?: string | redacted.Redacted<string>;
    ttl?: string;
    displayName?: string;
    enablePullRequestPreview?: boolean;
    pullRequestEnvironmentName?: string;
    backendEnvironmentArn?: string;
    backend?: Backend;
    computeRoleArn?: string;
}
export declare const UpdateBranchRequest: S.Schema<UpdateBranchRequest>;
export interface UpdateBranchResult {
    branch: Branch;
}
export declare const UpdateBranchResult: S.Schema<UpdateBranchResult>;
export interface UpdateDomainAssociationRequest {
    appId: string;
    domainName: string;
    enableAutoSubDomain?: boolean;
    subDomainSettings?: SubDomainSetting[];
    autoSubDomainCreationPatterns?: string[];
    autoSubDomainIAMRole?: string;
    certificateSettings?: CertificateSettings;
}
export declare const UpdateDomainAssociationRequest: S.Schema<UpdateDomainAssociationRequest>;
export interface UpdateDomainAssociationResult {
    domainAssociation: DomainAssociation;
}
export declare const UpdateDomainAssociationResult: S.Schema<UpdateDomainAssociationResult>;
export interface UpdateWebhookRequest {
    webhookId: string;
    branchName?: string;
    description?: string;
}
export declare const UpdateWebhookRequest: S.Schema<UpdateWebhookRequest>;
export interface UpdateWebhookResult {
    webhook: Webhook;
}
export declare const UpdateWebhookResult: S.Schema<UpdateWebhookResult>;
export type ErrorMessage = string;
export type Code = string;
export type CreateAppError = BadRequestException | DependentServiceFailureException | InternalFailureException | LimitExceededException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a new Amplify app.
 */
export declare const createApp: API.OperationMethod<CreateAppRequest, CreateAppResult, CreateAppError, Credentials | HttpClient.HttpClient>;
export type CreateBackendEnvironmentError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a new backend environment for an Amplify app.
 *
 * This API is available only to Amplify Gen 1 applications where the
 * backend is created using Amplify Studio or the Amplify
 * command line interface (CLI). This API isn’t available to Amplify Gen 2
 * applications. When you deploy an application with Amplify Gen 2, you provision the app's
 * backend infrastructure using Typescript code.
 */
export declare const createBackendEnvironment: API.OperationMethod<CreateBackendEnvironmentRequest, CreateBackendEnvironmentResult, CreateBackendEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateBranchError = BadRequestException | DependentServiceFailureException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a new branch for an Amplify app.
 */
export declare const createBranch: API.OperationMethod<CreateBranchRequest, CreateBranchResult, CreateBranchError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = BadRequestException | InternalFailureException | LimitExceededException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a deployment for a manually deployed Amplify app. Manually deployed apps are
 * not connected to a Git repository.
 *
 * The maximum duration between the `CreateDeployment` call and the
 * `StartDeployment` call cannot exceed 8 hours. If the duration exceeds 8
 * hours, the `StartDeployment` call and the associated `Job` will
 * fail.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest, CreateDeploymentResult, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateDomainAssociationError = BadRequestException | DependentServiceFailureException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a new domain association for an Amplify app. This action associates a custom
 * domain with the Amplify app
 */
export declare const createDomainAssociation: API.OperationMethod<CreateDomainAssociationRequest, CreateDomainAssociationResult, CreateDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateWebhookError = BadRequestException | DependentServiceFailureException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a new webhook on an Amplify app.
 */
export declare const createWebhook: API.OperationMethod<CreateWebhookRequest, CreateWebhookResult, CreateWebhookError, Credentials | HttpClient.HttpClient>;
export type DeleteAppError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Deletes an existing Amplify app specified by an app ID.
 */
export declare const deleteApp: API.OperationMethod<DeleteAppRequest, DeleteAppResult, DeleteAppError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendEnvironmentError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Deletes a backend environment for an Amplify app.
 *
 * This API is available only to Amplify Gen 1 applications where the
 * backend is created using Amplify Studio or the Amplify
 * command line interface (CLI). This API isn’t available to Amplify Gen 2
 * applications. When you deploy an application with Amplify Gen 2, you provision the app's
 * backend infrastructure using Typescript code.
 */
export declare const deleteBackendEnvironment: API.OperationMethod<DeleteBackendEnvironmentRequest, DeleteBackendEnvironmentResult, DeleteBackendEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteBranchError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Deletes a branch for an Amplify app.
 */
export declare const deleteBranch: API.OperationMethod<DeleteBranchRequest, DeleteBranchResult, DeleteBranchError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainAssociationError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Deletes a domain association for an Amplify app.
 */
export declare const deleteDomainAssociation: API.OperationMethod<DeleteDomainAssociationRequest, DeleteDomainAssociationResult, DeleteDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteJobError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Deletes a job for a branch of an Amplify app.
 */
export declare const deleteJob: API.OperationMethod<DeleteJobRequest, DeleteJobResult, DeleteJobError, Credentials | HttpClient.HttpClient>;
export type DeleteWebhookError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Deletes a webhook.
 */
export declare const deleteWebhook: API.OperationMethod<DeleteWebhookRequest, DeleteWebhookResult, DeleteWebhookError, Credentials | HttpClient.HttpClient>;
export type GenerateAccessLogsError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns the website access logs for a specific time range using a presigned URL.
 */
export declare const generateAccessLogs: API.OperationMethod<GenerateAccessLogsRequest, GenerateAccessLogsResult, GenerateAccessLogsError, Credentials | HttpClient.HttpClient>;
export type GetAppError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns an existing Amplify app specified by an app ID.
 */
export declare const getApp: API.OperationMethod<GetAppRequest, GetAppResult, GetAppError, Credentials | HttpClient.HttpClient>;
export type GetArtifactUrlError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns the artifact info that corresponds to an artifact id.
 */
export declare const getArtifactUrl: API.OperationMethod<GetArtifactUrlRequest, GetArtifactUrlResult, GetArtifactUrlError, Credentials | HttpClient.HttpClient>;
export type GetBackendEnvironmentError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns a backend environment for an Amplify app.
 *
 * This API is available only to Amplify Gen 1 applications where the
 * backend is created using Amplify Studio or the Amplify
 * command line interface (CLI). This API isn’t available to Amplify Gen 2
 * applications. When you deploy an application with Amplify Gen 2, you provision the app's
 * backend infrastructure using Typescript code.
 */
export declare const getBackendEnvironment: API.OperationMethod<GetBackendEnvironmentRequest, GetBackendEnvironmentResult, GetBackendEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetBranchError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns a branch for an Amplify app.
 */
export declare const getBranch: API.OperationMethod<GetBranchRequest, GetBranchResult, GetBranchError, Credentials | HttpClient.HttpClient>;
export type GetDomainAssociationError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns the domain information for an Amplify app.
 */
export declare const getDomainAssociation: API.OperationMethod<GetDomainAssociationRequest, GetDomainAssociationResult, GetDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type GetJobError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns a job for a branch of an Amplify app.
 */
export declare const getJob: API.OperationMethod<GetJobRequest, GetJobResult, GetJobError, Credentials | HttpClient.HttpClient>;
export type GetWebhookError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns the webhook information that corresponds to a specified webhook ID.
 */
export declare const getWebhook: API.OperationMethod<GetWebhookRequest, GetWebhookResult, GetWebhookError, Credentials | HttpClient.HttpClient>;
export type ListAppsError = BadRequestException | InternalFailureException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns a list of the existing Amplify apps.
 */
export declare const listApps: API.PaginatedOperationMethod<ListAppsRequest, ListAppsResult, ListAppsError, Credentials | HttpClient.HttpClient, App>;
export type ListArtifactsError = BadRequestException | InternalFailureException | LimitExceededException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns a list of end-to-end testing artifacts for a specified app, branch, and
 * job.
 *
 * To return the build artifacts, use the GetJob API.
 *
 * For more information about Amplify testing support, see Setting up
 * end-to-end Cypress tests for your Amplify application in the
 * *Amplify Hosting User Guide*.
 */
export declare const listArtifacts: API.OperationMethod<ListArtifactsRequest, ListArtifactsResult, ListArtifactsError, Credentials | HttpClient.HttpClient>;
export type ListBackendEnvironmentsError = BadRequestException | InternalFailureException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Lists the backend environments for an Amplify app.
 *
 * This API is available only to Amplify Gen 1 applications where the
 * backend is created using Amplify Studio or the Amplify
 * command line interface (CLI). This API isn’t available to Amplify Gen 2
 * applications. When you deploy an application with Amplify Gen 2, you provision the app's
 * backend infrastructure using Typescript code.
 */
export declare const listBackendEnvironments: API.OperationMethod<ListBackendEnvironmentsRequest, ListBackendEnvironmentsResult, ListBackendEnvironmentsError, Credentials | HttpClient.HttpClient>;
export type ListBranchesError = BadRequestException | InternalFailureException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Lists the branches of an Amplify app.
 */
export declare const listBranches: API.PaginatedOperationMethod<ListBranchesRequest, ListBranchesResult, ListBranchesError, Credentials | HttpClient.HttpClient, Branch>;
export type ListDomainAssociationsError = BadRequestException | InternalFailureException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns the domain associations for an Amplify app.
 */
export declare const listDomainAssociations: API.PaginatedOperationMethod<ListDomainAssociationsRequest, ListDomainAssociationsResult, ListDomainAssociationsError, Credentials | HttpClient.HttpClient, DomainAssociation>;
export type ListJobsError = BadRequestException | InternalFailureException | LimitExceededException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Lists the jobs for a branch of an Amplify app.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest, ListJobsResult, ListJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListTagsForResourceError = BadRequestException | InternalFailureException | ResourceNotFoundException | TimeoutException | CommonErrors;
/**
 * Returns a list of tags for a specified Amazon Resource Name (ARN).
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWebhooksError = BadRequestException | InternalFailureException | LimitExceededException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns a list of webhooks for an Amplify app.
 */
export declare const listWebhooks: API.OperationMethod<ListWebhooksRequest, ListWebhooksResult, ListWebhooksError, Credentials | HttpClient.HttpClient>;
export type StartDeploymentError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Starts a deployment for a manually deployed app. Manually deployed apps are not
 * connected to a Git repository.
 *
 * The maximum duration between the `CreateDeployment` call and the
 * `StartDeployment` call cannot exceed 8 hours. If the duration exceeds 8
 * hours, the `StartDeployment` call and the associated `Job` will
 * fail.
 */
export declare const startDeployment: API.OperationMethod<StartDeploymentRequest, StartDeploymentResult, StartDeploymentError, Credentials | HttpClient.HttpClient>;
export type StartJobError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Starts a new job for a branch of an Amplify app.
 */
export declare const startJob: API.OperationMethod<StartJobRequest, StartJobResult, StartJobError, Credentials | HttpClient.HttpClient>;
export type StopJobError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Stops a job that is in progress for a branch of an Amplify app.
 */
export declare const stopJob: API.OperationMethod<StopJobRequest, StopJobResult, StopJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | InternalFailureException | ResourceNotFoundException | TimeoutException | CommonErrors;
/**
 * Tags the resource with a tag key and value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | InternalFailureException | ResourceNotFoundException | TimeoutException | CommonErrors;
/**
 * Untags a resource with a specified Amazon Resource Name (ARN).
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAppError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Updates an existing Amplify app.
 */
export declare const updateApp: API.OperationMethod<UpdateAppRequest, UpdateAppResult, UpdateAppError, Credentials | HttpClient.HttpClient>;
export type UpdateBranchError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Updates a branch for an Amplify app.
 */
export declare const updateBranch: API.OperationMethod<UpdateBranchRequest, UpdateBranchResult, UpdateBranchError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainAssociationError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a new domain association for an Amplify app.
 */
export declare const updateDomainAssociation: API.OperationMethod<UpdateDomainAssociationRequest, UpdateDomainAssociationResult, UpdateDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateWebhookError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Updates a webhook.
 */
export declare const updateWebhook: API.OperationMethod<UpdateWebhookRequest, UpdateWebhookResult, UpdateWebhookError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=amplify.d.ts.map