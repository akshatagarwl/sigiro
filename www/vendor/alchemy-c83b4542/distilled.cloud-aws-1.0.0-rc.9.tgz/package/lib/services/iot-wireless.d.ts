import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
    readonly ResourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AmazonId = string;
export type AppServerPrivateKey = string | redacted.Redacted<string>;
export interface SidewalkAccountInfo {
    AmazonId?: string;
    AppServerPrivateKey?: string | redacted.Redacted<string>;
}
export declare const SidewalkAccountInfo: S.Schema<SidewalkAccountInfo>;
export type ClientRequestToken = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface AssociateAwsAccountWithPartnerAccountRequest {
    Sidewalk: SidewalkAccountInfo;
    ClientRequestToken?: string;
    Tags?: Tag[];
}
export declare const AssociateAwsAccountWithPartnerAccountRequest: S.Schema<AssociateAwsAccountWithPartnerAccountRequest>;
export type PartnerAccountArn = string;
export interface AssociateAwsAccountWithPartnerAccountResponse {
    Sidewalk?: SidewalkAccountInfo;
    Arn?: string;
}
export declare const AssociateAwsAccountWithPartnerAccountResponse: S.Schema<AssociateAwsAccountWithPartnerAccountResponse>;
export type FuotaTaskId = string;
export type MulticastGroupId = string;
export interface AssociateMulticastGroupWithFuotaTaskRequest {
    Id: string;
    MulticastGroupId: string;
}
export declare const AssociateMulticastGroupWithFuotaTaskRequest: S.Schema<AssociateMulticastGroupWithFuotaTaskRequest>;
export interface AssociateMulticastGroupWithFuotaTaskResponse {
}
export declare const AssociateMulticastGroupWithFuotaTaskResponse: S.Schema<AssociateMulticastGroupWithFuotaTaskResponse>;
export type WirelessDeviceId = string;
export interface AssociateWirelessDeviceWithFuotaTaskRequest {
    Id: string;
    WirelessDeviceId: string;
}
export declare const AssociateWirelessDeviceWithFuotaTaskRequest: S.Schema<AssociateWirelessDeviceWithFuotaTaskRequest>;
export interface AssociateWirelessDeviceWithFuotaTaskResponse {
}
export declare const AssociateWirelessDeviceWithFuotaTaskResponse: S.Schema<AssociateWirelessDeviceWithFuotaTaskResponse>;
export interface AssociateWirelessDeviceWithMulticastGroupRequest {
    Id: string;
    WirelessDeviceId: string;
}
export declare const AssociateWirelessDeviceWithMulticastGroupRequest: S.Schema<AssociateWirelessDeviceWithMulticastGroupRequest>;
export interface AssociateWirelessDeviceWithMulticastGroupResponse {
}
export declare const AssociateWirelessDeviceWithMulticastGroupResponse: S.Schema<AssociateWirelessDeviceWithMulticastGroupResponse>;
export type ThingArn = string;
export interface AssociateWirelessDeviceWithThingRequest {
    Id: string;
    ThingArn: string;
}
export declare const AssociateWirelessDeviceWithThingRequest: S.Schema<AssociateWirelessDeviceWithThingRequest>;
export interface AssociateWirelessDeviceWithThingResponse {
}
export declare const AssociateWirelessDeviceWithThingResponse: S.Schema<AssociateWirelessDeviceWithThingResponse>;
export type WirelessGatewayId = string;
export type IotCertificateId = string;
export interface AssociateWirelessGatewayWithCertificateRequest {
    Id: string;
    IotCertificateId: string;
}
export declare const AssociateWirelessGatewayWithCertificateRequest: S.Schema<AssociateWirelessGatewayWithCertificateRequest>;
export interface AssociateWirelessGatewayWithCertificateResponse {
    IotCertificateId?: string;
}
export declare const AssociateWirelessGatewayWithCertificateResponse: S.Schema<AssociateWirelessGatewayWithCertificateResponse>;
export interface AssociateWirelessGatewayWithThingRequest {
    Id: string;
    ThingArn: string;
}
export declare const AssociateWirelessGatewayWithThingRequest: S.Schema<AssociateWirelessGatewayWithThingRequest>;
export interface AssociateWirelessGatewayWithThingResponse {
}
export declare const AssociateWirelessGatewayWithThingResponse: S.Schema<AssociateWirelessGatewayWithThingResponse>;
export interface CancelMulticastGroupSessionRequest {
    Id: string;
}
export declare const CancelMulticastGroupSessionRequest: S.Schema<CancelMulticastGroupSessionRequest>;
export interface CancelMulticastGroupSessionResponse {
}
export declare const CancelMulticastGroupSessionResponse: S.Schema<CancelMulticastGroupSessionResponse>;
export type DestinationName = string;
export type ExpressionType = "RuleName" | "MqttTopic" | (string & {});
export declare const ExpressionType: any;
export type Expression = string;
export type Description = string;
export type RoleArn = string;
export interface CreateDestinationRequest {
    Name: string;
    ExpressionType: ExpressionType;
    Expression: string;
    Description?: string;
    RoleArn: string;
    Tags?: Tag[];
    ClientRequestToken?: string;
}
export declare const CreateDestinationRequest: S.Schema<CreateDestinationRequest>;
export type DestinationArn = string;
export interface CreateDestinationResponse {
    Arn?: string;
    Name?: string;
}
export declare const CreateDestinationResponse: S.Schema<CreateDestinationResponse>;
export type DeviceProfileName = string;
export type SupportsClassB = boolean;
export type ClassBTimeout = number;
export type PingSlotPeriod = number;
export type PingSlotDr = number;
export type PingSlotFreq = number;
export type SupportsClassC = boolean;
export type ClassCTimeout = number;
export type MacVersion = string;
export type RegParamsRevision = string;
export type RxDelay1 = number;
export type RxDrOffset1 = number;
export type RxDataRate2 = number;
export type RxFreq2 = number;
export type PresetFreq = number;
export type FactoryPresetFreqsList = number[];
export declare const FactoryPresetFreqsList: any;
export type MaxEirp = number;
export type MaxDutyCycle = number;
export type RfRegion = string;
export type SupportsJoin = boolean;
export type Supports32BitFCnt = boolean;
export interface LoRaWANDeviceProfile {
    SupportsClassB?: boolean;
    ClassBTimeout?: number;
    PingSlotPeriod?: number;
    PingSlotDr?: number;
    PingSlotFreq?: number;
    SupportsClassC?: boolean;
    ClassCTimeout?: number;
    MacVersion?: string;
    RegParamsRevision?: string;
    RxDelay1?: number;
    RxDrOffset1?: number;
    RxDataRate2?: number;
    RxFreq2?: number;
    FactoryPresetFreqsList?: number[];
    MaxEirp?: number;
    MaxDutyCycle?: number;
    RfRegion?: string;
    SupportsJoin?: boolean;
    Supports32BitFCnt?: boolean;
}
export declare const LoRaWANDeviceProfile: S.Schema<LoRaWANDeviceProfile>;
export interface SidewalkCreateDeviceProfile {
}
export declare const SidewalkCreateDeviceProfile: S.Schema<SidewalkCreateDeviceProfile>;
export interface CreateDeviceProfileRequest {
    Name?: string;
    LoRaWAN?: LoRaWANDeviceProfile;
    Tags?: Tag[];
    ClientRequestToken?: string;
    Sidewalk?: SidewalkCreateDeviceProfile;
}
export declare const CreateDeviceProfileRequest: S.Schema<CreateDeviceProfileRequest>;
export type DeviceProfileArn = string;
export type DeviceProfileId = string;
export interface CreateDeviceProfileResponse {
    Arn?: string;
    Id?: string;
}
export declare const CreateDeviceProfileResponse: S.Schema<CreateDeviceProfileResponse>;
export type FuotaTaskName = string;
export type SupportedRfRegion = "EU868" | "US915" | "AU915" | "AS923-1" | "AS923-2" | "AS923-3" | "AS923-4" | "EU433" | "CN470" | "CN779" | "RU864" | "KR920" | "IN865" | (string & {});
export declare const SupportedRfRegion: any;
export interface LoRaWANFuotaTask {
    RfRegion?: SupportedRfRegion;
}
export declare const LoRaWANFuotaTask: S.Schema<LoRaWANFuotaTask>;
export type FirmwareUpdateImage = string;
export type FirmwareUpdateRole = string;
export type RedundancyPercent = number;
export type FragmentSizeBytes = number;
export type FragmentIntervalMS = number;
export type FileDescriptor = string;
export interface CreateFuotaTaskRequest {
    Name?: string;
    Description?: string;
    ClientRequestToken?: string;
    LoRaWAN?: LoRaWANFuotaTask;
    FirmwareUpdateImage: string;
    FirmwareUpdateRole: string;
    Tags?: Tag[];
    RedundancyPercent?: number;
    FragmentSizeBytes?: number;
    FragmentIntervalMS?: number;
    Descriptor?: string;
}
export declare const CreateFuotaTaskRequest: S.Schema<CreateFuotaTaskRequest>;
export type FuotaTaskArn = string;
export interface CreateFuotaTaskResponse {
    Arn?: string;
    Id?: string;
}
export declare const CreateFuotaTaskResponse: S.Schema<CreateFuotaTaskResponse>;
export type MulticastGroupName = string;
export type DlClass = "ClassB" | "ClassC" | (string & {});
export declare const DlClass: any;
export type GatewayListMulticast = string[];
export declare const GatewayListMulticast: any;
export type TransmissionIntervalMulticast = number;
export interface ParticipatingGatewaysMulticast {
    GatewayList?: string[];
    TransmissionInterval?: number;
}
export declare const ParticipatingGatewaysMulticast: S.Schema<ParticipatingGatewaysMulticast>;
export type DlDr = number;
export type DlFreq = number;
export interface DefaultSessionParametersMulticast {
    DlDr?: number;
    DlFreq?: number;
}
export declare const DefaultSessionParametersMulticast: S.Schema<DefaultSessionParametersMulticast>;
export interface LoRaWANMulticast {
    RfRegion?: SupportedRfRegion;
    DlClass?: DlClass;
    ParticipatingGateways?: ParticipatingGatewaysMulticast;
    DefaultSessionParameters?: DefaultSessionParametersMulticast;
}
export declare const LoRaWANMulticast: S.Schema<LoRaWANMulticast>;
export interface CreateMulticastGroupRequest {
    Name?: string;
    Description?: string;
    ClientRequestToken?: string;
    LoRaWAN: LoRaWANMulticast;
    Tags?: Tag[];
}
export declare const CreateMulticastGroupRequest: S.Schema<CreateMulticastGroupRequest>;
export type MulticastGroupArn = string;
export interface CreateMulticastGroupResponse {
    Arn?: string;
    Id?: string;
}
export declare const CreateMulticastGroupResponse: S.Schema<CreateMulticastGroupResponse>;
export type NetworkAnalyzerConfigurationName = string;
export type WirelessDeviceFrameInfo = "ENABLED" | "DISABLED" | (string & {});
export declare const WirelessDeviceFrameInfo: any;
export type LogLevel = "INFO" | "ERROR" | "DISABLED" | (string & {});
export declare const LogLevel: any;
export type MulticastFrameInfo = "ENABLED" | "DISABLED" | (string & {});
export declare const MulticastFrameInfo: any;
export interface TraceContent {
    WirelessDeviceFrameInfo?: WirelessDeviceFrameInfo;
    LogLevel?: LogLevel;
    MulticastFrameInfo?: MulticastFrameInfo;
}
export declare const TraceContent: S.Schema<TraceContent>;
export type WirelessDeviceList = string[];
export declare const WirelessDeviceList: any;
export type WirelessGatewayList = string[];
export declare const WirelessGatewayList: any;
export type NetworkAnalyzerMulticastGroupList = string[];
export declare const NetworkAnalyzerMulticastGroupList: any;
export interface CreateNetworkAnalyzerConfigurationRequest {
    Name: string;
    TraceContent?: TraceContent;
    WirelessDevices?: string[];
    WirelessGateways?: string[];
    Description?: string;
    Tags?: Tag[];
    ClientRequestToken?: string;
    MulticastGroups?: string[];
}
export declare const CreateNetworkAnalyzerConfigurationRequest: S.Schema<CreateNetworkAnalyzerConfigurationRequest>;
export type NetworkAnalyzerConfigurationArn = string;
export interface CreateNetworkAnalyzerConfigurationResponse {
    Arn?: string;
    Name?: string;
}
export declare const CreateNetworkAnalyzerConfigurationResponse: S.Schema<CreateNetworkAnalyzerConfigurationResponse>;
export type ServiceProfileName = string;
export type AddGwMetadata = boolean;
export type DrMinBox = number;
export type DrMaxBox = number;
export type PrAllowed = boolean;
export type RaAllowed = boolean;
export type TxPowerIndexMin = number;
export type TxPowerIndexMax = number;
export type NbTransMin = number;
export type NbTransMax = number;
export interface LoRaWANServiceProfile {
    AddGwMetadata?: boolean;
    DrMin?: number;
    DrMax?: number;
    PrAllowed?: boolean;
    RaAllowed?: boolean;
    TxPowerIndexMin?: number;
    TxPowerIndexMax?: number;
    NbTransMin?: number;
    NbTransMax?: number;
}
export declare const LoRaWANServiceProfile: S.Schema<LoRaWANServiceProfile>;
export interface CreateServiceProfileRequest {
    Name?: string;
    LoRaWAN?: LoRaWANServiceProfile;
    Tags?: Tag[];
    ClientRequestToken?: string;
}
export declare const CreateServiceProfileRequest: S.Schema<CreateServiceProfileRequest>;
export type ServiceProfileArn = string;
export type ServiceProfileId = string;
export interface CreateServiceProfileResponse {
    Arn?: string;
    Id?: string;
}
export declare const CreateServiceProfileResponse: S.Schema<CreateServiceProfileResponse>;
export type WirelessDeviceType = "Sidewalk" | "LoRaWAN" | (string & {});
export declare const WirelessDeviceType: any;
export type WirelessDeviceName = string;
export type DevEui = string;
export type AppKey = string;
export type NwkKey = string;
export type JoinEui = string;
export interface OtaaV1_1 {
    AppKey?: string | redacted.Redacted<string>;
    NwkKey?: string | redacted.Redacted<string>;
    JoinEui?: string;
}
export declare const OtaaV1_1: S.Schema<OtaaV1_1>;
export type AppEui = string;
export type GenAppKey = string;
export interface OtaaV1_0_x {
    AppKey?: string | redacted.Redacted<string>;
    AppEui?: string;
    JoinEui?: string;
    GenAppKey?: string | redacted.Redacted<string>;
}
export declare const OtaaV1_0_x: S.Schema<OtaaV1_0_x>;
export type DevAddr = string;
export type FNwkSIntKey = string;
export type SNwkSIntKey = string;
export type NwkSEncKey = string;
export type AppSKey = string;
export interface SessionKeysAbpV1_1 {
    FNwkSIntKey?: string | redacted.Redacted<string>;
    SNwkSIntKey?: string | redacted.Redacted<string>;
    NwkSEncKey?: string | redacted.Redacted<string>;
    AppSKey?: string | redacted.Redacted<string>;
}
export declare const SessionKeysAbpV1_1: S.Schema<SessionKeysAbpV1_1>;
export type FCntStart = number;
export interface AbpV1_1 {
    DevAddr?: string;
    SessionKeys?: SessionKeysAbpV1_1;
    FCntStart?: number;
}
export declare const AbpV1_1: S.Schema<AbpV1_1>;
export type NwkSKey = string;
export interface SessionKeysAbpV1_0_x {
    NwkSKey?: string | redacted.Redacted<string>;
    AppSKey?: string | redacted.Redacted<string>;
}
export declare const SessionKeysAbpV1_0_x: S.Schema<SessionKeysAbpV1_0_x>;
export interface AbpV1_0_x {
    DevAddr?: string;
    SessionKeys?: SessionKeysAbpV1_0_x;
    FCntStart?: number;
}
export declare const AbpV1_0_x: S.Schema<AbpV1_0_x>;
export type FPort = number;
export interface Positioning {
    ClockSync?: number;
    Stream?: number;
    Gnss?: number;
}
export declare const Positioning: S.Schema<Positioning>;
export type ApplicationConfigType = "SemtechGeolocation" | (string & {});
export declare const ApplicationConfigType: any;
export interface ApplicationConfig {
    FPort?: number;
    Type?: ApplicationConfigType;
    DestinationName?: string;
}
export declare const ApplicationConfig: S.Schema<ApplicationConfig>;
export type Applications = ApplicationConfig[];
export declare const Applications: any;
export interface FPorts {
    Fuota?: number;
    Multicast?: number;
    ClockSync?: number;
    Positioning?: Positioning;
    Applications?: ApplicationConfig[];
}
export declare const FPorts: S.Schema<FPorts>;
export interface LoRaWANDevice {
    DevEui?: string;
    DeviceProfileId?: string;
    ServiceProfileId?: string;
    OtaaV1_1?: OtaaV1_1;
    OtaaV1_0_x?: OtaaV1_0_x;
    AbpV1_1?: AbpV1_1;
    AbpV1_0_x?: AbpV1_0_x;
    FPorts?: FPorts;
}
export declare const LoRaWANDevice: S.Schema<LoRaWANDevice>;
export type PositioningConfigStatus = "Enabled" | "Disabled" | (string & {});
export declare const PositioningConfigStatus: any;
export interface SidewalkPositioning {
    DestinationName?: string;
}
export declare const SidewalkPositioning: S.Schema<SidewalkPositioning>;
export type SidewalkManufacturingSn = string;
export interface SidewalkCreateWirelessDevice {
    DeviceProfileId?: string;
    Positioning?: SidewalkPositioning;
    SidewalkManufacturingSn?: string;
}
export declare const SidewalkCreateWirelessDevice: S.Schema<SidewalkCreateWirelessDevice>;
export interface CreateWirelessDeviceRequest {
    Type: WirelessDeviceType;
    Name?: string;
    Description?: string;
    DestinationName: string;
    ClientRequestToken?: string;
    LoRaWAN?: LoRaWANDevice;
    Tags?: Tag[];
    Positioning?: PositioningConfigStatus;
    Sidewalk?: SidewalkCreateWirelessDevice;
}
export declare const CreateWirelessDeviceRequest: S.Schema<CreateWirelessDeviceRequest>;
export type WirelessDeviceArn = string;
export interface CreateWirelessDeviceResponse {
    Arn?: string;
    Id?: string;
}
export declare const CreateWirelessDeviceResponse: S.Schema<CreateWirelessDeviceResponse>;
export type WirelessGatewayName = string;
export type GatewayEui = string;
export type JoinEuiRange = string[];
export declare const JoinEuiRange: any;
export type JoinEuiFilters = string[][];
export declare const JoinEuiFilters: any;
export type NetId = string;
export type NetIdFilters = string[];
export declare const NetIdFilters: any;
export type SubBand = number;
export type SubBands = number[];
export declare const SubBands: any;
export type BeaconingDataRate = number;
export type BeaconingFrequency = number;
export type BeaconingFrequencies = number[];
export declare const BeaconingFrequencies: any;
export interface Beaconing {
    DataRate?: number;
    Frequencies?: number[];
}
export declare const Beaconing: S.Schema<Beaconing>;
export type GatewayMaxEirp = number;
export interface LoRaWANGateway {
    GatewayEui?: string;
    RfRegion?: string;
    JoinEuiFilters?: string[][];
    NetIdFilters?: string[];
    SubBands?: number[];
    Beaconing?: Beaconing;
    MaxEirp?: number;
}
export declare const LoRaWANGateway: S.Schema<LoRaWANGateway>;
export interface CreateWirelessGatewayRequest {
    Name?: string;
    Description?: string;
    LoRaWAN: LoRaWANGateway;
    Tags?: Tag[];
    ClientRequestToken?: string;
}
export declare const CreateWirelessGatewayRequest: S.Schema<CreateWirelessGatewayRequest>;
export type WirelessGatewayArn = string;
export interface CreateWirelessGatewayResponse {
    Arn?: string;
    Id?: string;
}
export declare const CreateWirelessGatewayResponse: S.Schema<CreateWirelessGatewayResponse>;
export type WirelessGatewayTaskDefinitionId = string;
export interface CreateWirelessGatewayTaskRequest {
    Id: string;
    WirelessGatewayTaskDefinitionId: string;
}
export declare const CreateWirelessGatewayTaskRequest: S.Schema<CreateWirelessGatewayTaskRequest>;
export type WirelessGatewayTaskStatus = "PENDING" | "IN_PROGRESS" | "FIRST_RETRY" | "SECOND_RETRY" | "COMPLETED" | "FAILED" | (string & {});
export declare const WirelessGatewayTaskStatus: any;
export interface CreateWirelessGatewayTaskResponse {
    WirelessGatewayTaskDefinitionId?: string;
    Status?: WirelessGatewayTaskStatus;
}
export declare const CreateWirelessGatewayTaskResponse: S.Schema<CreateWirelessGatewayTaskResponse>;
export type AutoCreateTasks = boolean;
export type WirelessGatewayTaskName = string;
export type UpdateDataSource = string;
export type UpdateSignature = string;
export type Crc = number;
export type PackageVersion = string;
export type Model = string;
export type Station = string;
export interface LoRaWANGatewayVersion {
    PackageVersion?: string;
    Model?: string;
    Station?: string;
}
export declare const LoRaWANGatewayVersion: S.Schema<LoRaWANGatewayVersion>;
export interface LoRaWANUpdateGatewayTaskCreate {
    UpdateSignature?: string;
    SigKeyCrc?: number;
    CurrentVersion?: LoRaWANGatewayVersion;
    UpdateVersion?: LoRaWANGatewayVersion;
}
export declare const LoRaWANUpdateGatewayTaskCreate: S.Schema<LoRaWANUpdateGatewayTaskCreate>;
export interface UpdateWirelessGatewayTaskCreate {
    UpdateDataSource?: string;
    UpdateDataRole?: string;
    LoRaWAN?: LoRaWANUpdateGatewayTaskCreate;
}
export declare const UpdateWirelessGatewayTaskCreate: S.Schema<UpdateWirelessGatewayTaskCreate>;
export interface CreateWirelessGatewayTaskDefinitionRequest {
    AutoCreateTasks: boolean;
    Name?: string;
    Update?: UpdateWirelessGatewayTaskCreate;
    ClientRequestToken?: string;
    Tags?: Tag[];
}
export declare const CreateWirelessGatewayTaskDefinitionRequest: S.Schema<CreateWirelessGatewayTaskDefinitionRequest>;
export type WirelessGatewayTaskDefinitionArn = string;
export interface CreateWirelessGatewayTaskDefinitionResponse {
    Id?: string;
    Arn?: string;
}
export declare const CreateWirelessGatewayTaskDefinitionResponse: S.Schema<CreateWirelessGatewayTaskDefinitionResponse>;
export interface DeleteDestinationRequest {
    Name: string;
}
export declare const DeleteDestinationRequest: S.Schema<DeleteDestinationRequest>;
export interface DeleteDestinationResponse {
}
export declare const DeleteDestinationResponse: S.Schema<DeleteDestinationResponse>;
export interface DeleteDeviceProfileRequest {
    Id: string;
}
export declare const DeleteDeviceProfileRequest: S.Schema<DeleteDeviceProfileRequest>;
export interface DeleteDeviceProfileResponse {
}
export declare const DeleteDeviceProfileResponse: S.Schema<DeleteDeviceProfileResponse>;
export interface DeleteFuotaTaskRequest {
    Id: string;
}
export declare const DeleteFuotaTaskRequest: S.Schema<DeleteFuotaTaskRequest>;
export interface DeleteFuotaTaskResponse {
}
export declare const DeleteFuotaTaskResponse: S.Schema<DeleteFuotaTaskResponse>;
export interface DeleteMulticastGroupRequest {
    Id: string;
}
export declare const DeleteMulticastGroupRequest: S.Schema<DeleteMulticastGroupRequest>;
export interface DeleteMulticastGroupResponse {
}
export declare const DeleteMulticastGroupResponse: S.Schema<DeleteMulticastGroupResponse>;
export interface DeleteNetworkAnalyzerConfigurationRequest {
    ConfigurationName: string;
}
export declare const DeleteNetworkAnalyzerConfigurationRequest: S.Schema<DeleteNetworkAnalyzerConfigurationRequest>;
export interface DeleteNetworkAnalyzerConfigurationResponse {
}
export declare const DeleteNetworkAnalyzerConfigurationResponse: S.Schema<DeleteNetworkAnalyzerConfigurationResponse>;
export type MessageId = string;
export interface DeleteQueuedMessagesRequest {
    Id: string;
    MessageId: string;
    WirelessDeviceType?: WirelessDeviceType;
}
export declare const DeleteQueuedMessagesRequest: S.Schema<DeleteQueuedMessagesRequest>;
export interface DeleteQueuedMessagesResponse {
}
export declare const DeleteQueuedMessagesResponse: S.Schema<DeleteQueuedMessagesResponse>;
export interface DeleteServiceProfileRequest {
    Id: string;
}
export declare const DeleteServiceProfileRequest: S.Schema<DeleteServiceProfileRequest>;
export interface DeleteServiceProfileResponse {
}
export declare const DeleteServiceProfileResponse: S.Schema<DeleteServiceProfileResponse>;
export interface DeleteWirelessDeviceRequest {
    Id: string;
}
export declare const DeleteWirelessDeviceRequest: S.Schema<DeleteWirelessDeviceRequest>;
export interface DeleteWirelessDeviceResponse {
}
export declare const DeleteWirelessDeviceResponse: S.Schema<DeleteWirelessDeviceResponse>;
export type ImportTaskId = string;
export interface DeleteWirelessDeviceImportTaskRequest {
    Id: string;
}
export declare const DeleteWirelessDeviceImportTaskRequest: S.Schema<DeleteWirelessDeviceImportTaskRequest>;
export interface DeleteWirelessDeviceImportTaskResponse {
}
export declare const DeleteWirelessDeviceImportTaskResponse: S.Schema<DeleteWirelessDeviceImportTaskResponse>;
export interface DeleteWirelessGatewayRequest {
    Id: string;
}
export declare const DeleteWirelessGatewayRequest: S.Schema<DeleteWirelessGatewayRequest>;
export interface DeleteWirelessGatewayResponse {
}
export declare const DeleteWirelessGatewayResponse: S.Schema<DeleteWirelessGatewayResponse>;
export interface DeleteWirelessGatewayTaskRequest {
    Id: string;
}
export declare const DeleteWirelessGatewayTaskRequest: S.Schema<DeleteWirelessGatewayTaskRequest>;
export interface DeleteWirelessGatewayTaskResponse {
}
export declare const DeleteWirelessGatewayTaskResponse: S.Schema<DeleteWirelessGatewayTaskResponse>;
export interface DeleteWirelessGatewayTaskDefinitionRequest {
    Id: string;
}
export declare const DeleteWirelessGatewayTaskDefinitionRequest: S.Schema<DeleteWirelessGatewayTaskDefinitionRequest>;
export interface DeleteWirelessGatewayTaskDefinitionResponse {
}
export declare const DeleteWirelessGatewayTaskDefinitionResponse: S.Schema<DeleteWirelessGatewayTaskDefinitionResponse>;
export type Identifier = string;
export interface DeregisterWirelessDeviceRequest {
    Identifier: string;
    WirelessDeviceType?: WirelessDeviceType;
}
export declare const DeregisterWirelessDeviceRequest: S.Schema<DeregisterWirelessDeviceRequest>;
export interface DeregisterWirelessDeviceResponse {
}
export declare const DeregisterWirelessDeviceResponse: S.Schema<DeregisterWirelessDeviceResponse>;
export type PartnerAccountId = string;
export type PartnerType = "Sidewalk" | (string & {});
export declare const PartnerType: any;
export interface DisassociateAwsAccountFromPartnerAccountRequest {
    PartnerAccountId: string;
    PartnerType: PartnerType;
}
export declare const DisassociateAwsAccountFromPartnerAccountRequest: S.Schema<DisassociateAwsAccountFromPartnerAccountRequest>;
export interface DisassociateAwsAccountFromPartnerAccountResponse {
}
export declare const DisassociateAwsAccountFromPartnerAccountResponse: S.Schema<DisassociateAwsAccountFromPartnerAccountResponse>;
export interface DisassociateMulticastGroupFromFuotaTaskRequest {
    Id: string;
    MulticastGroupId: string;
}
export declare const DisassociateMulticastGroupFromFuotaTaskRequest: S.Schema<DisassociateMulticastGroupFromFuotaTaskRequest>;
export interface DisassociateMulticastGroupFromFuotaTaskResponse {
}
export declare const DisassociateMulticastGroupFromFuotaTaskResponse: S.Schema<DisassociateMulticastGroupFromFuotaTaskResponse>;
export interface DisassociateWirelessDeviceFromFuotaTaskRequest {
    Id: string;
    WirelessDeviceId: string;
}
export declare const DisassociateWirelessDeviceFromFuotaTaskRequest: S.Schema<DisassociateWirelessDeviceFromFuotaTaskRequest>;
export interface DisassociateWirelessDeviceFromFuotaTaskResponse {
}
export declare const DisassociateWirelessDeviceFromFuotaTaskResponse: S.Schema<DisassociateWirelessDeviceFromFuotaTaskResponse>;
export interface DisassociateWirelessDeviceFromMulticastGroupRequest {
    Id: string;
    WirelessDeviceId: string;
}
export declare const DisassociateWirelessDeviceFromMulticastGroupRequest: S.Schema<DisassociateWirelessDeviceFromMulticastGroupRequest>;
export interface DisassociateWirelessDeviceFromMulticastGroupResponse {
}
export declare const DisassociateWirelessDeviceFromMulticastGroupResponse: S.Schema<DisassociateWirelessDeviceFromMulticastGroupResponse>;
export interface DisassociateWirelessDeviceFromThingRequest {
    Id: string;
}
export declare const DisassociateWirelessDeviceFromThingRequest: S.Schema<DisassociateWirelessDeviceFromThingRequest>;
export interface DisassociateWirelessDeviceFromThingResponse {
}
export declare const DisassociateWirelessDeviceFromThingResponse: S.Schema<DisassociateWirelessDeviceFromThingResponse>;
export interface DisassociateWirelessGatewayFromCertificateRequest {
    Id: string;
}
export declare const DisassociateWirelessGatewayFromCertificateRequest: S.Schema<DisassociateWirelessGatewayFromCertificateRequest>;
export interface DisassociateWirelessGatewayFromCertificateResponse {
}
export declare const DisassociateWirelessGatewayFromCertificateResponse: S.Schema<DisassociateWirelessGatewayFromCertificateResponse>;
export interface DisassociateWirelessGatewayFromThingRequest {
    Id: string;
}
export declare const DisassociateWirelessGatewayFromThingRequest: S.Schema<DisassociateWirelessGatewayFromThingRequest>;
export interface DisassociateWirelessGatewayFromThingResponse {
}
export declare const DisassociateWirelessGatewayFromThingResponse: S.Schema<DisassociateWirelessGatewayFromThingResponse>;
export interface GetDestinationRequest {
    Name: string;
}
export declare const GetDestinationRequest: S.Schema<GetDestinationRequest>;
export interface GetDestinationResponse {
    Arn?: string;
    Name?: string;
    Expression?: string;
    ExpressionType?: ExpressionType;
    Description?: string;
    RoleArn?: string;
}
export declare const GetDestinationResponse: S.Schema<GetDestinationResponse>;
export interface GetDeviceProfileRequest {
    Id: string;
}
export declare const GetDeviceProfileRequest: S.Schema<GetDeviceProfileRequest>;
export type ApplicationServerPublicKey = string | redacted.Redacted<string>;
export type QualificationStatus = boolean;
export type DakCertificateId = string;
export type MaxAllowedSignature = number;
export type FactorySupport = boolean;
export type ApId = string;
export type DeviceTypeId = string;
export interface DakCertificateMetadata {
    CertificateId: string;
    MaxAllowedSignature?: number;
    FactorySupport?: boolean;
    ApId?: string;
    DeviceTypeId?: string;
}
export declare const DakCertificateMetadata: S.Schema<DakCertificateMetadata>;
export type DakCertificateMetadataList = DakCertificateMetadata[];
export declare const DakCertificateMetadataList: any;
export interface SidewalkGetDeviceProfile {
    ApplicationServerPublicKey?: string | redacted.Redacted<string>;
    QualificationStatus?: boolean;
    DakCertificateMetadata?: DakCertificateMetadata[];
}
export declare const SidewalkGetDeviceProfile: S.Schema<SidewalkGetDeviceProfile>;
export interface GetDeviceProfileResponse {
    Arn?: string;
    Name?: string;
    Id?: string;
    LoRaWAN?: LoRaWANDeviceProfile;
    Sidewalk?: SidewalkGetDeviceProfile;
}
export declare const GetDeviceProfileResponse: S.Schema<GetDeviceProfileResponse>;
export interface GetEventConfigurationByResourceTypesRequest {
}
export declare const GetEventConfigurationByResourceTypesRequest: S.Schema<GetEventConfigurationByResourceTypesRequest>;
export type EventNotificationTopicStatus = "Enabled" | "Disabled" | (string & {});
export declare const EventNotificationTopicStatus: any;
export interface SidewalkResourceTypeEventConfiguration {
    WirelessDeviceEventTopic?: EventNotificationTopicStatus;
}
export declare const SidewalkResourceTypeEventConfiguration: S.Schema<SidewalkResourceTypeEventConfiguration>;
export interface DeviceRegistrationStateResourceTypeEventConfiguration {
    Sidewalk?: SidewalkResourceTypeEventConfiguration;
}
export declare const DeviceRegistrationStateResourceTypeEventConfiguration: S.Schema<DeviceRegistrationStateResourceTypeEventConfiguration>;
export interface ProximityResourceTypeEventConfiguration {
    Sidewalk?: SidewalkResourceTypeEventConfiguration;
}
export declare const ProximityResourceTypeEventConfiguration: S.Schema<ProximityResourceTypeEventConfiguration>;
export interface LoRaWANJoinResourceTypeEventConfiguration {
    WirelessDeviceEventTopic?: EventNotificationTopicStatus;
}
export declare const LoRaWANJoinResourceTypeEventConfiguration: S.Schema<LoRaWANJoinResourceTypeEventConfiguration>;
export interface JoinResourceTypeEventConfiguration {
    LoRaWAN?: LoRaWANJoinResourceTypeEventConfiguration;
}
export declare const JoinResourceTypeEventConfiguration: S.Schema<JoinResourceTypeEventConfiguration>;
export interface LoRaWANConnectionStatusResourceTypeEventConfiguration {
    WirelessGatewayEventTopic?: EventNotificationTopicStatus;
}
export declare const LoRaWANConnectionStatusResourceTypeEventConfiguration: S.Schema<LoRaWANConnectionStatusResourceTypeEventConfiguration>;
export interface ConnectionStatusResourceTypeEventConfiguration {
    LoRaWAN?: LoRaWANConnectionStatusResourceTypeEventConfiguration;
}
export declare const ConnectionStatusResourceTypeEventConfiguration: S.Schema<ConnectionStatusResourceTypeEventConfiguration>;
export interface MessageDeliveryStatusResourceTypeEventConfiguration {
    Sidewalk?: SidewalkResourceTypeEventConfiguration;
}
export declare const MessageDeliveryStatusResourceTypeEventConfiguration: S.Schema<MessageDeliveryStatusResourceTypeEventConfiguration>;
export interface GetEventConfigurationByResourceTypesResponse {
    DeviceRegistrationState?: DeviceRegistrationStateResourceTypeEventConfiguration;
    Proximity?: ProximityResourceTypeEventConfiguration;
    Join?: JoinResourceTypeEventConfiguration;
    ConnectionStatus?: ConnectionStatusResourceTypeEventConfiguration;
    MessageDeliveryStatus?: MessageDeliveryStatusResourceTypeEventConfiguration;
}
export declare const GetEventConfigurationByResourceTypesResponse: S.Schema<GetEventConfigurationByResourceTypesResponse>;
export interface GetFuotaTaskRequest {
    Id: string;
}
export declare const GetFuotaTaskRequest: S.Schema<GetFuotaTaskRequest>;
export type FuotaTaskStatus = "Pending" | "FuotaSession_Waiting" | "In_FuotaSession" | "FuotaDone" | "Delete_Waiting" | (string & {});
export declare const FuotaTaskStatus: any;
export type StartTime = Date;
export interface LoRaWANFuotaTaskGetInfo {
    RfRegion?: string;
    StartTime?: Date;
}
export declare const LoRaWANFuotaTaskGetInfo: S.Schema<LoRaWANFuotaTaskGetInfo>;
export type CreatedAt = Date;
export interface GetFuotaTaskResponse {
    Arn?: string;
    Id?: string;
    Status?: FuotaTaskStatus;
    Name?: string;
    Description?: string;
    LoRaWAN?: LoRaWANFuotaTaskGetInfo;
    FirmwareUpdateImage?: string;
    FirmwareUpdateRole?: string;
    CreatedAt?: Date;
    RedundancyPercent?: number;
    FragmentSizeBytes?: number;
    FragmentIntervalMS?: number;
    Descriptor?: string;
}
export declare const GetFuotaTaskResponse: S.Schema<GetFuotaTaskResponse>;
export interface GetLogLevelsByResourceTypesRequest {
}
export declare const GetLogLevelsByResourceTypesRequest: S.Schema<GetLogLevelsByResourceTypesRequest>;
export type WirelessGatewayType = "LoRaWAN" | (string & {});
export declare const WirelessGatewayType: any;
export type WirelessGatewayEvent = "CUPS_Request" | "Certificate" | (string & {});
export declare const WirelessGatewayEvent: any;
export interface WirelessGatewayEventLogOption {
    Event: WirelessGatewayEvent;
    LogLevel: LogLevel;
}
export declare const WirelessGatewayEventLogOption: S.Schema<WirelessGatewayEventLogOption>;
export type WirelessGatewayEventLogOptionList = WirelessGatewayEventLogOption[];
export declare const WirelessGatewayEventLogOptionList: any;
export interface WirelessGatewayLogOption {
    Type: WirelessGatewayType;
    LogLevel: LogLevel;
    Events?: WirelessGatewayEventLogOption[];
}
export declare const WirelessGatewayLogOption: S.Schema<WirelessGatewayLogOption>;
export type WirelessGatewayLogOptionList = WirelessGatewayLogOption[];
export declare const WirelessGatewayLogOptionList: any;
export type WirelessDeviceEvent = "Join" | "Rejoin" | "Uplink_Data" | "Downlink_Data" | "Registration" | (string & {});
export declare const WirelessDeviceEvent: any;
export interface WirelessDeviceEventLogOption {
    Event: WirelessDeviceEvent;
    LogLevel: LogLevel;
}
export declare const WirelessDeviceEventLogOption: S.Schema<WirelessDeviceEventLogOption>;
export type WirelessDeviceEventLogOptionList = WirelessDeviceEventLogOption[];
export declare const WirelessDeviceEventLogOptionList: any;
export interface WirelessDeviceLogOption {
    Type: WirelessDeviceType;
    LogLevel: LogLevel;
    Events?: WirelessDeviceEventLogOption[];
}
export declare const WirelessDeviceLogOption: S.Schema<WirelessDeviceLogOption>;
export type WirelessDeviceLogOptionList = WirelessDeviceLogOption[];
export declare const WirelessDeviceLogOptionList: any;
export type FuotaTaskType = "LoRaWAN" | (string & {});
export declare const FuotaTaskType: any;
export type FuotaTaskEvent = "Fuota" | (string & {});
export declare const FuotaTaskEvent: any;
export interface FuotaTaskEventLogOption {
    Event: FuotaTaskEvent;
    LogLevel: LogLevel;
}
export declare const FuotaTaskEventLogOption: S.Schema<FuotaTaskEventLogOption>;
export type FuotaTaskEventLogOptionList = FuotaTaskEventLogOption[];
export declare const FuotaTaskEventLogOptionList: any;
export interface FuotaTaskLogOption {
    Type: FuotaTaskType;
    LogLevel: LogLevel;
    Events?: FuotaTaskEventLogOption[];
}
export declare const FuotaTaskLogOption: S.Schema<FuotaTaskLogOption>;
export type FuotaTaskLogOptionList = FuotaTaskLogOption[];
export declare const FuotaTaskLogOptionList: any;
export interface GetLogLevelsByResourceTypesResponse {
    DefaultLogLevel?: LogLevel;
    WirelessGatewayLogOptions?: WirelessGatewayLogOption[];
    WirelessDeviceLogOptions?: WirelessDeviceLogOption[];
    FuotaTaskLogOptions?: FuotaTaskLogOption[];
}
export declare const GetLogLevelsByResourceTypesResponse: S.Schema<GetLogLevelsByResourceTypesResponse>;
export interface GetMetricConfigurationRequest {
}
export declare const GetMetricConfigurationRequest: S.Schema<GetMetricConfigurationRequest>;
export type SummaryMetricConfigurationStatus = "Enabled" | "Disabled" | (string & {});
export declare const SummaryMetricConfigurationStatus: any;
export interface SummaryMetricConfiguration {
    Status?: SummaryMetricConfigurationStatus;
}
export declare const SummaryMetricConfiguration: S.Schema<SummaryMetricConfiguration>;
export interface GetMetricConfigurationResponse {
    SummaryMetric?: SummaryMetricConfiguration;
}
export declare const GetMetricConfigurationResponse: S.Schema<GetMetricConfigurationResponse>;
export type MetricQueryId = string;
export type MetricName = "DeviceRSSI" | "DeviceSNR" | "DeviceRoamingRSSI" | "DeviceRoamingSNR" | "DeviceUplinkCount" | "DeviceDownlinkCount" | "DeviceUplinkLostCount" | "DeviceUplinkLostRate" | "DeviceJoinRequestCount" | "DeviceJoinAcceptCount" | "DeviceRoamingUplinkCount" | "DeviceRoamingDownlinkCount" | "GatewayUpTime" | "GatewayDownTime" | "GatewayRSSI" | "GatewaySNR" | "GatewayUplinkCount" | "GatewayDownlinkCount" | "GatewayJoinRequestCount" | "GatewayJoinAcceptCount" | "AwsAccountUplinkCount" | "AwsAccountDownlinkCount" | "AwsAccountUplinkLostCount" | "AwsAccountUplinkLostRate" | "AwsAccountJoinRequestCount" | "AwsAccountJoinAcceptCount" | "AwsAccountRoamingUplinkCount" | "AwsAccountRoamingDownlinkCount" | "AwsAccountDeviceCount" | "AwsAccountGatewayCount" | "AwsAccountActiveDeviceCount" | "AwsAccountActiveGatewayCount" | (string & {});
export declare const MetricName: any;
export type DimensionName = "DeviceId" | "GatewayId" | (string & {});
export declare const DimensionName: any;
export type DimensionValue = string;
export interface Dimension {
    name?: DimensionName;
    value?: string;
}
export declare const Dimension: S.Schema<Dimension>;
export type Dimensions = Dimension[];
export declare const Dimensions: any;
export type AggregationPeriod = "OneHour" | "OneDay" | "OneWeek" | (string & {});
export declare const AggregationPeriod: any;
export type MetricQueryStartTimestamp = Date;
export type MetricQueryEndTimestamp = Date;
export interface SummaryMetricQuery {
    QueryId?: string;
    MetricName?: MetricName;
    Dimensions?: Dimension[];
    AggregationPeriod?: AggregationPeriod;
    StartTimestamp?: Date;
    EndTimestamp?: Date;
}
export declare const SummaryMetricQuery: S.Schema<SummaryMetricQuery>;
export type SummaryMetricQueries = SummaryMetricQuery[];
export declare const SummaryMetricQueries: any;
export interface GetMetricsRequest {
    SummaryMetricQueries?: SummaryMetricQuery[];
}
export declare const GetMetricsRequest: S.Schema<GetMetricsRequest>;
export type MetricQueryStatus = "Succeeded" | "Failed" | (string & {});
export declare const MetricQueryStatus: any;
export type MetricQueryError = string;
export type MetricQueryTimestamp = Date;
export type MetricQueryTimestamps = Date[];
export declare const MetricQueryTimestamps: any;
export type Min = number;
export type Max = number;
export type Sum = number;
export type Avg = number;
export type Std = number;
export type P90 = number;
export interface MetricQueryValue {
    Min?: number;
    Max?: number;
    Sum?: number;
    Avg?: number;
    Std?: number;
    P90?: number;
}
export declare const MetricQueryValue: S.Schema<MetricQueryValue>;
export type MetricQueryValues = MetricQueryValue[];
export declare const MetricQueryValues: any;
export type MetricUnit = string;
export interface SummaryMetricQueryResult {
    QueryId?: string;
    QueryStatus?: MetricQueryStatus;
    Error?: string;
    MetricName?: MetricName;
    Dimensions?: Dimension[];
    AggregationPeriod?: AggregationPeriod;
    StartTimestamp?: Date;
    EndTimestamp?: Date;
    Timestamps?: Date[];
    Values?: MetricQueryValue[];
    Unit?: string;
}
export declare const SummaryMetricQueryResult: S.Schema<SummaryMetricQueryResult>;
export type SummaryMetricQueryResults = SummaryMetricQueryResult[];
export declare const SummaryMetricQueryResults: any;
export interface GetMetricsResponse {
    SummaryMetricQueryResults?: SummaryMetricQueryResult[];
}
export declare const GetMetricsResponse: S.Schema<GetMetricsResponse>;
export interface GetMulticastGroupRequest {
    Id: string;
}
export declare const GetMulticastGroupRequest: S.Schema<GetMulticastGroupRequest>;
export type MulticastGroupStatus = string;
export type NumberOfDevicesRequested = number;
export type NumberOfDevicesInGroup = number;
export interface LoRaWANMulticastGet {
    RfRegion?: SupportedRfRegion;
    DlClass?: DlClass;
    NumberOfDevicesRequested?: number;
    NumberOfDevicesInGroup?: number;
    ParticipatingGateways?: ParticipatingGatewaysMulticast;
    DefaultSessionParameters?: DefaultSessionParametersMulticast;
}
export declare const LoRaWANMulticastGet: S.Schema<LoRaWANMulticastGet>;
export interface GetMulticastGroupResponse {
    Arn?: string;
    Id?: string;
    Name?: string;
    Description?: string;
    Status?: string;
    LoRaWAN?: LoRaWANMulticastGet;
    CreatedAt?: Date;
}
export declare const GetMulticastGroupResponse: S.Schema<GetMulticastGroupResponse>;
export interface GetMulticastGroupSessionRequest {
    Id: string;
}
export declare const GetMulticastGroupSessionRequest: S.Schema<GetMulticastGroupSessionRequest>;
export type SessionStartTimeTimestamp = Date;
export type SessionTimeout = number;
export interface LoRaWANMulticastSession {
    DlDr?: number;
    DlFreq?: number;
    SessionStartTime?: Date;
    SessionTimeout?: number;
    PingSlotPeriod?: number;
}
export declare const LoRaWANMulticastSession: S.Schema<LoRaWANMulticastSession>;
export interface GetMulticastGroupSessionResponse {
    LoRaWAN?: LoRaWANMulticastSession;
}
export declare const GetMulticastGroupSessionResponse: S.Schema<GetMulticastGroupSessionResponse>;
export interface GetNetworkAnalyzerConfigurationRequest {
    ConfigurationName: string;
}
export declare const GetNetworkAnalyzerConfigurationRequest: S.Schema<GetNetworkAnalyzerConfigurationRequest>;
export interface GetNetworkAnalyzerConfigurationResponse {
    TraceContent?: TraceContent;
    WirelessDevices?: string[];
    WirelessGateways?: string[];
    Description?: string;
    Arn?: string;
    Name?: string;
    MulticastGroups?: string[];
}
export declare const GetNetworkAnalyzerConfigurationResponse: S.Schema<GetNetworkAnalyzerConfigurationResponse>;
export interface GetPartnerAccountRequest {
    PartnerAccountId: string;
    PartnerType: PartnerType;
}
export declare const GetPartnerAccountRequest: S.Schema<GetPartnerAccountRequest>;
export type Fingerprint = string | redacted.Redacted<string>;
export interface SidewalkAccountInfoWithFingerprint {
    AmazonId?: string;
    Fingerprint?: string | redacted.Redacted<string>;
    Arn?: string;
}
export declare const SidewalkAccountInfoWithFingerprint: S.Schema<SidewalkAccountInfoWithFingerprint>;
export type AccountLinked = boolean;
export interface GetPartnerAccountResponse {
    Sidewalk?: SidewalkAccountInfoWithFingerprint;
    AccountLinked?: boolean;
}
export declare const GetPartnerAccountResponse: S.Schema<GetPartnerAccountResponse>;
export type PositionResourceIdentifier = string;
export type PositionResourceType = "WirelessDevice" | "WirelessGateway" | (string & {});
export declare const PositionResourceType: any;
export interface GetPositionRequest {
    ResourceIdentifier: string;
    ResourceType: PositionResourceType;
}
export declare const GetPositionRequest: S.Schema<GetPositionRequest>;
export type PositionCoordinateValue = number;
export type PositionCoordinate = number[];
export declare const PositionCoordinate: any;
export type HorizontalAccuracy = number;
export type VerticalAccuracy = number;
export interface Accuracy {
    HorizontalAccuracy?: number;
    VerticalAccuracy?: number;
}
export declare const Accuracy: S.Schema<Accuracy>;
export type PositionSolverType = "GNSS" | (string & {});
export declare const PositionSolverType: any;
export type PositionSolverProvider = "Semtech" | (string & {});
export declare const PositionSolverProvider: any;
export type PositionSolverVersion = string;
export type ISODateTimeString = string;
export interface GetPositionResponse {
    Position?: number[];
    Accuracy?: Accuracy;
    SolverType?: PositionSolverType;
    SolverProvider?: PositionSolverProvider;
    SolverVersion?: string;
    Timestamp?: string;
}
export declare const GetPositionResponse: S.Schema<GetPositionResponse>;
export interface GetPositionConfigurationRequest {
    ResourceIdentifier: string;
    ResourceType: PositionResourceType;
}
export declare const GetPositionConfigurationRequest: S.Schema<GetPositionConfigurationRequest>;
export type PositionConfigurationStatus = "Enabled" | "Disabled" | (string & {});
export declare const PositionConfigurationStatus: any;
export type PositionConfigurationFec = "ROSE" | "NONE" | (string & {});
export declare const PositionConfigurationFec: any;
export interface SemtechGnssDetail {
    Provider?: PositionSolverProvider;
    Type?: PositionSolverType;
    Status?: PositionConfigurationStatus;
    Fec?: PositionConfigurationFec;
}
export declare const SemtechGnssDetail: S.Schema<SemtechGnssDetail>;
export interface PositionSolverDetails {
    SemtechGnss?: SemtechGnssDetail;
}
export declare const PositionSolverDetails: S.Schema<PositionSolverDetails>;
export interface GetPositionConfigurationResponse {
    Solvers?: PositionSolverDetails;
    Destination?: string;
}
export declare const GetPositionConfigurationResponse: S.Schema<GetPositionConfigurationResponse>;
export type MacAddress = string;
export type RSS = number;
export interface WiFiAccessPoint {
    MacAddress: string;
    Rss: number;
}
export declare const WiFiAccessPoint: S.Schema<WiFiAccessPoint>;
export type WiFiAccessPoints = WiFiAccessPoint[];
export declare const WiFiAccessPoints: any;
export type MCC = number;
export type MNC = number;
export type LAC = number;
export type GeranCid = number;
export type BSIC = number;
export type BCCH = number;
export interface GsmLocalId {
    Bsic: number;
    Bcch: number;
}
export declare const GsmLocalId: S.Schema<GsmLocalId>;
export type GsmTimingAdvance = number;
export type RxLevel = number;
export interface GlobalIdentity {
    Lac: number;
    GeranCid: number;
}
export declare const GlobalIdentity: S.Schema<GlobalIdentity>;
export interface GsmNmrObj {
    Bsic: number;
    Bcch: number;
    RxLevel?: number;
    GlobalIdentity?: GlobalIdentity;
}
export declare const GsmNmrObj: S.Schema<GsmNmrObj>;
export type GsmNmrList = GsmNmrObj[];
export declare const GsmNmrList: any;
export interface GsmObj {
    Mcc: number;
    Mnc: number;
    Lac: number;
    GeranCid: number;
    GsmLocalId?: GsmLocalId;
    GsmTimingAdvance?: number;
    RxLevel?: number;
    GsmNmr?: GsmNmrObj[];
}
export declare const GsmObj: S.Schema<GsmObj>;
export type GsmList = GsmObj[];
export declare const GsmList: any;
export type UtranCid = number;
export type UARFCNDL = number;
export type PSC = number;
export interface WcdmaLocalId {
    Uarfcndl: number;
    Psc: number;
}
export declare const WcdmaLocalId: S.Schema<WcdmaLocalId>;
export type RSCP = number;
export type PathLoss = number;
export interface WcdmaNmrObj {
    Uarfcndl: number;
    Psc: number;
    UtranCid: number;
    Rscp?: number;
    PathLoss?: number;
}
export declare const WcdmaNmrObj: S.Schema<WcdmaNmrObj>;
export type WcdmaNmrList = WcdmaNmrObj[];
export declare const WcdmaNmrList: any;
export interface WcdmaObj {
    Mcc: number;
    Mnc: number;
    Lac?: number;
    UtranCid: number;
    WcdmaLocalId?: WcdmaLocalId;
    Rscp?: number;
    PathLoss?: number;
    WcdmaNmr?: WcdmaNmrObj[];
}
export declare const WcdmaObj: S.Schema<WcdmaObj>;
export type WcdmaList = WcdmaObj[];
export declare const WcdmaList: any;
export type UARFCN = number;
export type CellParams = number;
export interface TdscdmaLocalId {
    Uarfcn: number;
    CellParams: number;
}
export declare const TdscdmaLocalId: S.Schema<TdscdmaLocalId>;
export type TdscdmaTimingAdvance = number;
export interface TdscdmaNmrObj {
    Uarfcn: number;
    CellParams: number;
    UtranCid?: number;
    Rscp?: number;
    PathLoss?: number;
}
export declare const TdscdmaNmrObj: S.Schema<TdscdmaNmrObj>;
export type TdscdmaNmrList = TdscdmaNmrObj[];
export declare const TdscdmaNmrList: any;
export interface TdscdmaObj {
    Mcc: number;
    Mnc: number;
    Lac?: number;
    UtranCid: number;
    TdscdmaLocalId?: TdscdmaLocalId;
    TdscdmaTimingAdvance?: number;
    Rscp?: number;
    PathLoss?: number;
    TdscdmaNmr?: TdscdmaNmrObj[];
}
export declare const TdscdmaObj: S.Schema<TdscdmaObj>;
export type TdscdmaList = TdscdmaObj[];
export declare const TdscdmaList: any;
export type EutranCid = number;
export type TAC = number;
export type PCI = number;
export type EARFCN = number;
export interface LteLocalId {
    Pci: number;
    Earfcn: number;
}
export declare const LteLocalId: S.Schema<LteLocalId>;
export type LteTimingAdvance = number;
export type RSRP = number;
export type RSRQ = number;
export type NRCapable = boolean;
export interface LteNmrObj {
    Pci: number;
    Earfcn: number;
    EutranCid?: number;
    Rsrp?: number;
    Rsrq?: number;
}
export declare const LteNmrObj: S.Schema<LteNmrObj>;
export type LteNmrList = LteNmrObj[];
export declare const LteNmrList: any;
export interface LteObj {
    Mcc: number;
    Mnc: number;
    EutranCid: number;
    Tac?: number;
    LteLocalId?: LteLocalId;
    LteTimingAdvance?: number;
    Rsrp?: number;
    Rsrq?: number;
    NrCapable?: boolean;
    LteNmr?: LteNmrObj[];
}
export declare const LteObj: S.Schema<LteObj>;
export type LteList = LteObj[];
export declare const LteList: any;
export type SystemId = number;
export type NetworkId = number;
export type BaseStationId = number;
export type RegistrationZone = number;
export type PnOffset = number;
export type CdmaChannel = number;
export interface CdmaLocalId {
    PnOffset: number;
    CdmaChannel: number;
}
export declare const CdmaLocalId: S.Schema<CdmaLocalId>;
export type PilotPower = number;
export type BaseLat = number;
export type BaseLng = number;
export interface CdmaNmrObj {
    PnOffset: number;
    CdmaChannel: number;
    PilotPower?: number;
    BaseStationId?: number;
}
export declare const CdmaNmrObj: S.Schema<CdmaNmrObj>;
export type CdmaNmrList = CdmaNmrObj[];
export declare const CdmaNmrList: any;
export interface CdmaObj {
    SystemId: number;
    NetworkId: number;
    BaseStationId: number;
    RegistrationZone?: number;
    CdmaLocalId?: CdmaLocalId;
    PilotPower?: number;
    BaseLat?: number;
    BaseLng?: number;
    CdmaNmr?: CdmaNmrObj[];
}
export declare const CdmaObj: S.Schema<CdmaObj>;
export type CdmaList = CdmaObj[];
export declare const CdmaList: any;
export interface CellTowers {
    Gsm?: GsmObj[];
    Wcdma?: WcdmaObj[];
    Tdscdma?: TdscdmaObj[];
    Lte?: LteObj[];
    Cdma?: CdmaObj[];
}
export declare const CellTowers: S.Schema<CellTowers>;
export type IPAddress = string;
export interface Ip {
    IpAddress: string;
}
export declare const Ip: S.Schema<Ip>;
export type GnssNav = string;
export type GPST = number;
export type CaptureTimeAccuracy = number;
export type Coordinate = number;
export type AssistPosition = number[];
export declare const AssistPosition: any;
export type Use2DSolver = boolean;
export interface Gnss {
    Payload: string;
    CaptureTime?: number;
    CaptureTimeAccuracy?: number;
    AssistPosition?: number[];
    AssistAltitude?: number;
    Use2DSolver?: boolean;
}
export declare const Gnss: S.Schema<Gnss>;
export type CreationDate = Date;
export type ConfidencePercent = number;
export interface WiFiCellular {
    ConfidencePercent?: number;
}
export declare const WiFiCellular: S.Schema<WiFiCellular>;
export interface AdvancedConfiguration {
    WiFiCellular?: WiFiCellular;
}
export declare const AdvancedConfiguration: S.Schema<AdvancedConfiguration>;
export interface GetPositionEstimateRequest {
    WiFiAccessPoints?: WiFiAccessPoint[];
    CellTowers?: CellTowers;
    Ip?: Ip;
    Gnss?: Gnss;
    Timestamp?: Date;
    AdvancedConfiguration?: AdvancedConfiguration;
}
export declare const GetPositionEstimateRequest: S.Schema<GetPositionEstimateRequest>;
export interface GetPositionEstimateResponse {
    GeoJsonPayload?: T.StreamingOutputBody;
}
export declare const GetPositionEstimateResponse: S.Schema<GetPositionEstimateResponse>;
export type IdentifierType = "PartnerAccountId" | "DevEui" | "GatewayEui" | "WirelessDeviceId" | "WirelessGatewayId" | (string & {});
export declare const IdentifierType: any;
export type EventNotificationPartnerType = "Sidewalk" | (string & {});
export declare const EventNotificationPartnerType: any;
export interface GetResourceEventConfigurationRequest {
    Identifier: string;
    IdentifierType: IdentifierType;
    PartnerType?: EventNotificationPartnerType;
}
export declare const GetResourceEventConfigurationRequest: S.Schema<GetResourceEventConfigurationRequest>;
export interface SidewalkEventNotificationConfigurations {
    AmazonIdEventTopic?: EventNotificationTopicStatus;
}
export declare const SidewalkEventNotificationConfigurations: S.Schema<SidewalkEventNotificationConfigurations>;
export interface DeviceRegistrationStateEventConfiguration {
    Sidewalk?: SidewalkEventNotificationConfigurations;
    WirelessDeviceIdEventTopic?: EventNotificationTopicStatus;
}
export declare const DeviceRegistrationStateEventConfiguration: S.Schema<DeviceRegistrationStateEventConfiguration>;
export interface ProximityEventConfiguration {
    Sidewalk?: SidewalkEventNotificationConfigurations;
    WirelessDeviceIdEventTopic?: EventNotificationTopicStatus;
}
export declare const ProximityEventConfiguration: S.Schema<ProximityEventConfiguration>;
export interface LoRaWANJoinEventNotificationConfigurations {
    DevEuiEventTopic?: EventNotificationTopicStatus;
}
export declare const LoRaWANJoinEventNotificationConfigurations: S.Schema<LoRaWANJoinEventNotificationConfigurations>;
export interface JoinEventConfiguration {
    LoRaWAN?: LoRaWANJoinEventNotificationConfigurations;
    WirelessDeviceIdEventTopic?: EventNotificationTopicStatus;
}
export declare const JoinEventConfiguration: S.Schema<JoinEventConfiguration>;
export interface LoRaWANConnectionStatusEventNotificationConfigurations {
    GatewayEuiEventTopic?: EventNotificationTopicStatus;
}
export declare const LoRaWANConnectionStatusEventNotificationConfigurations: S.Schema<LoRaWANConnectionStatusEventNotificationConfigurations>;
export interface ConnectionStatusEventConfiguration {
    LoRaWAN?: LoRaWANConnectionStatusEventNotificationConfigurations;
    WirelessGatewayIdEventTopic?: EventNotificationTopicStatus;
}
export declare const ConnectionStatusEventConfiguration: S.Schema<ConnectionStatusEventConfiguration>;
export interface MessageDeliveryStatusEventConfiguration {
    Sidewalk?: SidewalkEventNotificationConfigurations;
    WirelessDeviceIdEventTopic?: EventNotificationTopicStatus;
}
export declare const MessageDeliveryStatusEventConfiguration: S.Schema<MessageDeliveryStatusEventConfiguration>;
export interface GetResourceEventConfigurationResponse {
    DeviceRegistrationState?: DeviceRegistrationStateEventConfiguration;
    Proximity?: ProximityEventConfiguration;
    Join?: JoinEventConfiguration;
    ConnectionStatus?: ConnectionStatusEventConfiguration;
    MessageDeliveryStatus?: MessageDeliveryStatusEventConfiguration;
}
export declare const GetResourceEventConfigurationResponse: S.Schema<GetResourceEventConfigurationResponse>;
export type ResourceIdentifier = string;
export type ResourceType = string;
export interface GetResourceLogLevelRequest {
    ResourceIdentifier: string;
    ResourceType: string;
}
export declare const GetResourceLogLevelRequest: S.Schema<GetResourceLogLevelRequest>;
export interface GetResourceLogLevelResponse {
    LogLevel?: LogLevel;
}
export declare const GetResourceLogLevelResponse: S.Schema<GetResourceLogLevelResponse>;
export interface GetResourcePositionRequest {
    ResourceIdentifier: string;
    ResourceType: PositionResourceType;
}
export declare const GetResourcePositionRequest: S.Schema<GetResourcePositionRequest>;
export interface GetResourcePositionResponse {
    GeoJsonPayload?: T.StreamingOutputBody;
}
export declare const GetResourcePositionResponse: S.Schema<GetResourcePositionResponse>;
export type WirelessGatewayServiceType = "CUPS" | "LNS" | (string & {});
export declare const WirelessGatewayServiceType: any;
export interface GetServiceEndpointRequest {
    ServiceType?: WirelessGatewayServiceType;
}
export declare const GetServiceEndpointRequest: S.Schema<GetServiceEndpointRequest>;
export type EndPoint = string;
export type CertificatePEM = string;
export interface GetServiceEndpointResponse {
    ServiceType?: WirelessGatewayServiceType;
    ServiceEndpoint?: string;
    ServerTrust?: string;
}
export declare const GetServiceEndpointResponse: S.Schema<GetServiceEndpointResponse>;
export interface GetServiceProfileRequest {
    Id: string;
}
export declare const GetServiceProfileRequest: S.Schema<GetServiceProfileRequest>;
export type UlRate = number;
export type UlBucketSize = number;
export type UlRatePolicy = string;
export type DlRate = number;
export type DlBucketSize = number;
export type DlRatePolicy = string;
export type DevStatusReqFreq = number;
export type ReportDevStatusBattery = boolean;
export type ReportDevStatusMargin = boolean;
export type DrMin = number;
export type DrMax = number;
export type ChannelMask = string;
export type HrAllowed = boolean;
export type NwkGeoLoc = boolean;
export type TargetPer = number;
export type MinGwDiversity = number;
export interface LoRaWANGetServiceProfileInfo {
    UlRate?: number;
    UlBucketSize?: number;
    UlRatePolicy?: string;
    DlRate?: number;
    DlBucketSize?: number;
    DlRatePolicy?: string;
    AddGwMetadata?: boolean;
    DevStatusReqFreq?: number;
    ReportDevStatusBattery?: boolean;
    ReportDevStatusMargin?: boolean;
    DrMin?: number;
    DrMax?: number;
    ChannelMask?: string;
    PrAllowed?: boolean;
    HrAllowed?: boolean;
    RaAllowed?: boolean;
    NwkGeoLoc?: boolean;
    TargetPer?: number;
    MinGwDiversity?: number;
    TxPowerIndexMin?: number;
    TxPowerIndexMax?: number;
    NbTransMin?: number;
    NbTransMax?: number;
}
export declare const LoRaWANGetServiceProfileInfo: S.Schema<LoRaWANGetServiceProfileInfo>;
export interface GetServiceProfileResponse {
    Arn?: string;
    Name?: string;
    Id?: string;
    LoRaWAN?: LoRaWANGetServiceProfileInfo;
}
export declare const GetServiceProfileResponse: S.Schema<GetServiceProfileResponse>;
export type WirelessDeviceIdType = "WirelessDeviceId" | "DevEui" | "ThingName" | "SidewalkManufacturingSn" | (string & {});
export declare const WirelessDeviceIdType: any;
export interface GetWirelessDeviceRequest {
    Identifier: string;
    IdentifierType: WirelessDeviceIdType;
}
export declare const GetWirelessDeviceRequest: S.Schema<GetWirelessDeviceRequest>;
export type ThingName = string;
export type SidewalkId = string;
export type SigningAlg = "Ed25519" | "P256r1" | (string & {});
export declare const SigningAlg: any;
export type CertificateValue = string;
export interface CertificateList {
    SigningAlg: SigningAlg;
    Value: string;
}
export declare const CertificateList: S.Schema<CertificateList>;
export type DeviceCertificateList = CertificateList[];
export declare const DeviceCertificateList: any;
export type PrivateKeysList = CertificateList[];
export declare const PrivateKeysList: any;
export type WirelessDeviceSidewalkStatus = "PROVISIONED" | "REGISTERED" | "ACTIVATED" | "UNKNOWN" | (string & {});
export declare const WirelessDeviceSidewalkStatus: any;
export interface SidewalkDevice {
    AmazonId?: string;
    SidewalkId?: string;
    SidewalkManufacturingSn?: string;
    DeviceCertificates?: CertificateList[];
    PrivateKeys?: CertificateList[];
    DeviceProfileId?: string;
    CertificateId?: string;
    Status?: WirelessDeviceSidewalkStatus;
    Positioning?: SidewalkPositioning;
}
export declare const SidewalkDevice: S.Schema<SidewalkDevice>;
export interface GetWirelessDeviceResponse {
    Type?: WirelessDeviceType;
    Name?: string;
    Description?: string;
    DestinationName?: string;
    Id?: string;
    Arn?: string;
    ThingName?: string;
    ThingArn?: string;
    LoRaWAN?: LoRaWANDevice;
    Sidewalk?: SidewalkDevice;
    Positioning?: PositioningConfigStatus;
}
export declare const GetWirelessDeviceResponse: S.Schema<GetWirelessDeviceResponse>;
export interface GetWirelessDeviceImportTaskRequest {
    Id: string;
}
export declare const GetWirelessDeviceImportTaskRequest: S.Schema<GetWirelessDeviceImportTaskRequest>;
export type ImportTaskArn = string;
export type DeviceCreationFile = string;
export type DeviceCreationFileList = string[];
export declare const DeviceCreationFileList: any;
export type Role = string;
export interface SidewalkGetStartImportInfo {
    DeviceCreationFileList?: string[];
    Role?: string;
    Positioning?: SidewalkPositioning;
}
export declare const SidewalkGetStartImportInfo: S.Schema<SidewalkGetStartImportInfo>;
export type CreationTime = Date;
export type ImportTaskStatus = "INITIALIZING" | "INITIALIZED" | "PENDING" | "COMPLETE" | "FAILED" | "DELETING" | (string & {});
export declare const ImportTaskStatus: any;
export type StatusReason = string;
export type ImportedWirelessDeviceCount = number;
export interface GetWirelessDeviceImportTaskResponse {
    Id?: string;
    Arn?: string;
    DestinationName?: string;
    Positioning?: PositioningConfigStatus;
    Sidewalk?: SidewalkGetStartImportInfo;
    CreationTime?: Date;
    Status?: ImportTaskStatus;
    StatusReason?: string;
    InitializedImportedDeviceCount?: number;
    PendingImportedDeviceCount?: number;
    OnboardedImportedDeviceCount?: number;
    FailedImportedDeviceCount?: number;
}
export declare const GetWirelessDeviceImportTaskResponse: S.Schema<GetWirelessDeviceImportTaskResponse>;
export interface GetWirelessDeviceStatisticsRequest {
    WirelessDeviceId: string;
}
export declare const GetWirelessDeviceStatisticsRequest: S.Schema<GetWirelessDeviceStatisticsRequest>;
export interface LoRaWANGatewayMetadata {
    GatewayEui?: string;
    Snr?: number;
    Rssi?: number;
}
export declare const LoRaWANGatewayMetadata: S.Schema<LoRaWANGatewayMetadata>;
export type LoRaWANGatewayMetadataList = LoRaWANGatewayMetadata[];
export declare const LoRaWANGatewayMetadataList: any;
export type ProviderNetId = string;
export type Id = string;
export type DlAllowed = boolean;
export interface LoRaWANPublicGatewayMetadata {
    ProviderNetId?: string;
    Id?: string;
    Rssi?: number;
    Snr?: number;
    RfRegion?: string;
    DlAllowed?: boolean;
}
export declare const LoRaWANPublicGatewayMetadata: S.Schema<LoRaWANPublicGatewayMetadata>;
export type LoRaWANPublicGatewayMetadataList = LoRaWANPublicGatewayMetadata[];
export declare const LoRaWANPublicGatewayMetadataList: any;
export interface LoRaWANDeviceMetadata {
    DevEui?: string;
    FPort?: number;
    DataRate?: number;
    Frequency?: number;
    Timestamp?: string;
    Gateways?: LoRaWANGatewayMetadata[];
    PublicGateways?: LoRaWANPublicGatewayMetadata[];
}
export declare const LoRaWANDeviceMetadata: S.Schema<LoRaWANDeviceMetadata>;
export type BatteryLevel = "normal" | "low" | "critical" | (string & {});
export declare const BatteryLevel: any;
export type Event = "discovered" | "lost" | "ack" | "nack" | "passthrough" | (string & {});
export declare const Event: any;
export type DeviceState = "Provisioned" | "RegisteredNotSeen" | "RegisteredReachable" | "RegisteredUnreachable" | (string & {});
export declare const DeviceState: any;
export interface SidewalkDeviceMetadata {
    Rssi?: number;
    BatteryLevel?: BatteryLevel;
    Event?: Event;
    DeviceState?: DeviceState;
}
export declare const SidewalkDeviceMetadata: S.Schema<SidewalkDeviceMetadata>;
export interface GetWirelessDeviceStatisticsResponse {
    WirelessDeviceId?: string;
    LastUplinkReceivedAt?: string;
    LoRaWAN?: LoRaWANDeviceMetadata;
    Sidewalk?: SidewalkDeviceMetadata;
}
export declare const GetWirelessDeviceStatisticsResponse: S.Schema<GetWirelessDeviceStatisticsResponse>;
export type WirelessGatewayIdType = "GatewayEui" | "WirelessGatewayId" | "ThingName" | (string & {});
export declare const WirelessGatewayIdType: any;
export interface GetWirelessGatewayRequest {
    Identifier: string;
    IdentifierType: WirelessGatewayIdType;
}
export declare const GetWirelessGatewayRequest: S.Schema<GetWirelessGatewayRequest>;
export interface GetWirelessGatewayResponse {
    Name?: string;
    Id?: string;
    Description?: string;
    LoRaWAN?: LoRaWANGateway;
    Arn?: string;
    ThingName?: string;
    ThingArn?: string;
}
export declare const GetWirelessGatewayResponse: S.Schema<GetWirelessGatewayResponse>;
export interface GetWirelessGatewayCertificateRequest {
    Id: string;
}
export declare const GetWirelessGatewayCertificateRequest: S.Schema<GetWirelessGatewayCertificateRequest>;
export interface GetWirelessGatewayCertificateResponse {
    IotCertificateId?: string;
    LoRaWANNetworkServerCertificateId?: string;
}
export declare const GetWirelessGatewayCertificateResponse: S.Schema<GetWirelessGatewayCertificateResponse>;
export interface GetWirelessGatewayFirmwareInformationRequest {
    Id: string;
}
export declare const GetWirelessGatewayFirmwareInformationRequest: S.Schema<GetWirelessGatewayFirmwareInformationRequest>;
export interface LoRaWANGatewayCurrentVersion {
    CurrentVersion?: LoRaWANGatewayVersion;
}
export declare const LoRaWANGatewayCurrentVersion: S.Schema<LoRaWANGatewayCurrentVersion>;
export interface GetWirelessGatewayFirmwareInformationResponse {
    LoRaWAN?: LoRaWANGatewayCurrentVersion;
}
export declare const GetWirelessGatewayFirmwareInformationResponse: S.Schema<GetWirelessGatewayFirmwareInformationResponse>;
export interface GetWirelessGatewayStatisticsRequest {
    WirelessGatewayId: string;
}
export declare const GetWirelessGatewayStatisticsRequest: S.Schema<GetWirelessGatewayStatisticsRequest>;
export type ConnectionStatus = "Connected" | "Disconnected" | (string & {});
export declare const ConnectionStatus: any;
export interface GetWirelessGatewayStatisticsResponse {
    WirelessGatewayId?: string;
    LastUplinkReceivedAt?: string;
    ConnectionStatus?: ConnectionStatus;
}
export declare const GetWirelessGatewayStatisticsResponse: S.Schema<GetWirelessGatewayStatisticsResponse>;
export interface GetWirelessGatewayTaskRequest {
    Id: string;
}
export declare const GetWirelessGatewayTaskRequest: S.Schema<GetWirelessGatewayTaskRequest>;
export interface GetWirelessGatewayTaskResponse {
    WirelessGatewayId?: string;
    WirelessGatewayTaskDefinitionId?: string;
    LastUplinkReceivedAt?: string;
    TaskCreatedAt?: string;
    Status?: WirelessGatewayTaskStatus;
}
export declare const GetWirelessGatewayTaskResponse: S.Schema<GetWirelessGatewayTaskResponse>;
export interface GetWirelessGatewayTaskDefinitionRequest {
    Id: string;
}
export declare const GetWirelessGatewayTaskDefinitionRequest: S.Schema<GetWirelessGatewayTaskDefinitionRequest>;
export interface GetWirelessGatewayTaskDefinitionResponse {
    AutoCreateTasks?: boolean;
    Name?: string;
    Update?: UpdateWirelessGatewayTaskCreate;
    Arn?: string;
}
export declare const GetWirelessGatewayTaskDefinitionResponse: S.Schema<GetWirelessGatewayTaskDefinitionResponse>;
export type MaxResults = number;
export type NextToken = string;
export interface ListDestinationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDestinationsRequest: S.Schema<ListDestinationsRequest>;
export interface Destinations {
    Arn?: string;
    Name?: string;
    ExpressionType?: ExpressionType;
    Expression?: string;
    Description?: string;
    RoleArn?: string;
}
export declare const Destinations: S.Schema<Destinations>;
export type DestinationList = Destinations[];
export declare const DestinationList: any;
export interface ListDestinationsResponse {
    NextToken?: string;
    DestinationList?: Destinations[];
}
export declare const ListDestinationsResponse: S.Schema<ListDestinationsResponse>;
export type DeviceProfileType = "Sidewalk" | "LoRaWAN" | (string & {});
export declare const DeviceProfileType: any;
export interface ListDeviceProfilesRequest {
    NextToken?: string;
    MaxResults?: number;
    DeviceProfileType?: DeviceProfileType;
}
export declare const ListDeviceProfilesRequest: S.Schema<ListDeviceProfilesRequest>;
export interface DeviceProfile {
    Arn?: string;
    Name?: string;
    Id?: string;
}
export declare const DeviceProfile: S.Schema<DeviceProfile>;
export type DeviceProfileList = DeviceProfile[];
export declare const DeviceProfileList: any;
export interface ListDeviceProfilesResponse {
    NextToken?: string;
    DeviceProfileList?: DeviceProfile[];
}
export declare const ListDeviceProfilesResponse: S.Schema<ListDeviceProfilesResponse>;
export type OnboardStatus = "INITIALIZED" | "PENDING" | "ONBOARDED" | "FAILED" | (string & {});
export declare const OnboardStatus: any;
export interface ListDevicesForWirelessDeviceImportTaskRequest {
    Id: string;
    MaxResults?: number;
    NextToken?: string;
    Status?: OnboardStatus;
}
export declare const ListDevicesForWirelessDeviceImportTaskRequest: S.Schema<ListDevicesForWirelessDeviceImportTaskRequest>;
export interface SidewalkListDevicesForImportInfo {
    Positioning?: SidewalkPositioning;
}
export declare const SidewalkListDevicesForImportInfo: S.Schema<SidewalkListDevicesForImportInfo>;
export type OnboardStatusReason = string;
export type LastUpdateTime = Date;
export interface ImportedSidewalkDevice {
    SidewalkManufacturingSn?: string;
    OnboardingStatus?: OnboardStatus;
    OnboardingStatusReason?: string;
    LastUpdateTime?: Date;
}
export declare const ImportedSidewalkDevice: S.Schema<ImportedSidewalkDevice>;
export interface ImportedWirelessDevice {
    Sidewalk?: ImportedSidewalkDevice;
}
export declare const ImportedWirelessDevice: S.Schema<ImportedWirelessDevice>;
export type ImportedWirelessDeviceList = ImportedWirelessDevice[];
export declare const ImportedWirelessDeviceList: any;
export interface ListDevicesForWirelessDeviceImportTaskResponse {
    NextToken?: string;
    DestinationName?: string;
    Positioning?: PositioningConfigStatus;
    Sidewalk?: SidewalkListDevicesForImportInfo;
    ImportedWirelessDeviceList?: ImportedWirelessDevice[];
}
export declare const ListDevicesForWirelessDeviceImportTaskResponse: S.Schema<ListDevicesForWirelessDeviceImportTaskResponse>;
export type EventNotificationResourceType = "SidewalkAccount" | "WirelessDevice" | "WirelessGateway" | (string & {});
export declare const EventNotificationResourceType: any;
export interface ListEventConfigurationsRequest {
    ResourceType: EventNotificationResourceType;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListEventConfigurationsRequest: S.Schema<ListEventConfigurationsRequest>;
export interface EventNotificationItemConfigurations {
    DeviceRegistrationState?: DeviceRegistrationStateEventConfiguration;
    Proximity?: ProximityEventConfiguration;
    Join?: JoinEventConfiguration;
    ConnectionStatus?: ConnectionStatusEventConfiguration;
    MessageDeliveryStatus?: MessageDeliveryStatusEventConfiguration;
}
export declare const EventNotificationItemConfigurations: S.Schema<EventNotificationItemConfigurations>;
export interface EventConfigurationItem {
    Identifier?: string;
    IdentifierType?: IdentifierType;
    PartnerType?: EventNotificationPartnerType;
    Events?: EventNotificationItemConfigurations;
}
export declare const EventConfigurationItem: S.Schema<EventConfigurationItem>;
export type EventConfigurationsList = EventConfigurationItem[];
export declare const EventConfigurationsList: any;
export interface ListEventConfigurationsResponse {
    NextToken?: string;
    EventConfigurationsList?: EventConfigurationItem[];
}
export declare const ListEventConfigurationsResponse: S.Schema<ListEventConfigurationsResponse>;
export interface ListFuotaTasksRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListFuotaTasksRequest: S.Schema<ListFuotaTasksRequest>;
export interface FuotaTask {
    Id?: string;
    Arn?: string;
    Name?: string;
}
export declare const FuotaTask: S.Schema<FuotaTask>;
export type FuotaTaskList = FuotaTask[];
export declare const FuotaTaskList: any;
export interface ListFuotaTasksResponse {
    NextToken?: string;
    FuotaTaskList?: FuotaTask[];
}
export declare const ListFuotaTasksResponse: S.Schema<ListFuotaTasksResponse>;
export interface ListMulticastGroupsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListMulticastGroupsRequest: S.Schema<ListMulticastGroupsRequest>;
export interface MulticastGroup {
    Id?: string;
    Arn?: string;
    Name?: string;
}
export declare const MulticastGroup: S.Schema<MulticastGroup>;
export type MulticastGroupList = MulticastGroup[];
export declare const MulticastGroupList: any;
export interface ListMulticastGroupsResponse {
    NextToken?: string;
    MulticastGroupList?: MulticastGroup[];
}
export declare const ListMulticastGroupsResponse: S.Schema<ListMulticastGroupsResponse>;
export interface ListMulticastGroupsByFuotaTaskRequest {
    Id: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListMulticastGroupsByFuotaTaskRequest: S.Schema<ListMulticastGroupsByFuotaTaskRequest>;
export interface MulticastGroupByFuotaTask {
    Id?: string;
}
export declare const MulticastGroupByFuotaTask: S.Schema<MulticastGroupByFuotaTask>;
export type MulticastGroupListByFuotaTask = MulticastGroupByFuotaTask[];
export declare const MulticastGroupListByFuotaTask: any;
export interface ListMulticastGroupsByFuotaTaskResponse {
    NextToken?: string;
    MulticastGroupList?: MulticastGroupByFuotaTask[];
}
export declare const ListMulticastGroupsByFuotaTaskResponse: S.Schema<ListMulticastGroupsByFuotaTaskResponse>;
export interface ListNetworkAnalyzerConfigurationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListNetworkAnalyzerConfigurationsRequest: S.Schema<ListNetworkAnalyzerConfigurationsRequest>;
export interface NetworkAnalyzerConfigurations {
    Arn?: string;
    Name?: string;
}
export declare const NetworkAnalyzerConfigurations: S.Schema<NetworkAnalyzerConfigurations>;
export type NetworkAnalyzerConfigurationList = NetworkAnalyzerConfigurations[];
export declare const NetworkAnalyzerConfigurationList: any;
export interface ListNetworkAnalyzerConfigurationsResponse {
    NextToken?: string;
    NetworkAnalyzerConfigurationList?: NetworkAnalyzerConfigurations[];
}
export declare const ListNetworkAnalyzerConfigurationsResponse: S.Schema<ListNetworkAnalyzerConfigurationsResponse>;
export interface ListPartnerAccountsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListPartnerAccountsRequest: S.Schema<ListPartnerAccountsRequest>;
export type SidewalkAccountList = SidewalkAccountInfoWithFingerprint[];
export declare const SidewalkAccountList: any;
export interface ListPartnerAccountsResponse {
    NextToken?: string;
    Sidewalk?: SidewalkAccountInfoWithFingerprint[];
}
export declare const ListPartnerAccountsResponse: S.Schema<ListPartnerAccountsResponse>;
export interface ListPositionConfigurationsRequest {
    ResourceType?: PositionResourceType;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListPositionConfigurationsRequest: S.Schema<ListPositionConfigurationsRequest>;
export interface PositionConfigurationItem {
    ResourceIdentifier?: string;
    ResourceType?: PositionResourceType;
    Solvers?: PositionSolverDetails;
    Destination?: string;
}
export declare const PositionConfigurationItem: S.Schema<PositionConfigurationItem>;
export type PositionConfigurationList = PositionConfigurationItem[];
export declare const PositionConfigurationList: any;
export interface ListPositionConfigurationsResponse {
    PositionConfigurationList?: PositionConfigurationItem[];
    NextToken?: string;
}
export declare const ListPositionConfigurationsResponse: S.Schema<ListPositionConfigurationsResponse>;
export interface ListQueuedMessagesRequest {
    Id: string;
    NextToken?: string;
    MaxResults?: number;
    WirelessDeviceType?: WirelessDeviceType;
}
export declare const ListQueuedMessagesRequest: S.Schema<ListQueuedMessagesRequest>;
export type TransmitMode = number;
export type DownlinkMode = "SEQUENTIAL" | "CONCURRENT" | "USING_UPLINK_GATEWAY" | (string & {});
export declare const DownlinkMode: any;
export type DownlinkFrequency = number;
export interface GatewayListItem {
    GatewayId: string;
    DownlinkFrequency: number;
}
export declare const GatewayListItem: S.Schema<GatewayListItem>;
export type GatewayList = GatewayListItem[];
export declare const GatewayList: any;
export type TransmissionInterval = number;
export interface ParticipatingGateways {
    DownlinkMode: DownlinkMode;
    GatewayList: GatewayListItem[];
    TransmissionInterval: number;
}
export declare const ParticipatingGateways: S.Schema<ParticipatingGateways>;
export interface LoRaWANSendDataToDevice {
    FPort?: number;
    ParticipatingGateways?: ParticipatingGateways;
}
export declare const LoRaWANSendDataToDevice: S.Schema<LoRaWANSendDataToDevice>;
export interface DownlinkQueueMessage {
    MessageId?: string;
    TransmitMode?: number;
    ReceivedAt?: string;
    LoRaWAN?: LoRaWANSendDataToDevice;
}
export declare const DownlinkQueueMessage: S.Schema<DownlinkQueueMessage>;
export type DownlinkQueueMessagesList = DownlinkQueueMessage[];
export declare const DownlinkQueueMessagesList: any;
export interface ListQueuedMessagesResponse {
    NextToken?: string;
    DownlinkQueueMessagesList?: DownlinkQueueMessage[];
}
export declare const ListQueuedMessagesResponse: S.Schema<ListQueuedMessagesResponse>;
export interface ListServiceProfilesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListServiceProfilesRequest: S.Schema<ListServiceProfilesRequest>;
export interface ServiceProfile {
    Arn?: string;
    Name?: string;
    Id?: string;
}
export declare const ServiceProfile: S.Schema<ServiceProfile>;
export type ServiceProfileList = ServiceProfile[];
export declare const ServiceProfileList: any;
export interface ListServiceProfilesResponse {
    NextToken?: string;
    ServiceProfileList?: ServiceProfile[];
}
export declare const ListServiceProfilesResponse: S.Schema<ListServiceProfilesResponse>;
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListWirelessDeviceImportTasksRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListWirelessDeviceImportTasksRequest: S.Schema<ListWirelessDeviceImportTasksRequest>;
export interface WirelessDeviceImportTask {
    Id?: string;
    Arn?: string;
    DestinationName?: string;
    Positioning?: PositioningConfigStatus;
    Sidewalk?: SidewalkGetStartImportInfo;
    CreationTime?: Date;
    Status?: ImportTaskStatus;
    StatusReason?: string;
    InitializedImportedDeviceCount?: number;
    PendingImportedDeviceCount?: number;
    OnboardedImportedDeviceCount?: number;
    FailedImportedDeviceCount?: number;
}
export declare const WirelessDeviceImportTask: S.Schema<WirelessDeviceImportTask>;
export type WirelessDeviceImportTaskList = WirelessDeviceImportTask[];
export declare const WirelessDeviceImportTaskList: any;
export interface ListWirelessDeviceImportTasksResponse {
    NextToken?: string;
    WirelessDeviceImportTaskList?: WirelessDeviceImportTask[];
}
export declare const ListWirelessDeviceImportTasksResponse: S.Schema<ListWirelessDeviceImportTasksResponse>;
export interface ListWirelessDevicesRequest {
    MaxResults?: number;
    NextToken?: string;
    DestinationName?: string;
    DeviceProfileId?: string;
    ServiceProfileId?: string;
    WirelessDeviceType?: WirelessDeviceType;
    FuotaTaskId?: string;
    MulticastGroupId?: string;
}
export declare const ListWirelessDevicesRequest: S.Schema<ListWirelessDevicesRequest>;
export interface LoRaWANListDevice {
    DevEui?: string;
}
export declare const LoRaWANListDevice: S.Schema<LoRaWANListDevice>;
export interface SidewalkListDevice {
    AmazonId?: string;
    SidewalkId?: string;
    SidewalkManufacturingSn?: string;
    DeviceCertificates?: CertificateList[];
    DeviceProfileId?: string;
    Status?: WirelessDeviceSidewalkStatus;
    Positioning?: SidewalkPositioning;
}
export declare const SidewalkListDevice: S.Schema<SidewalkListDevice>;
export type FuotaDeviceStatus = "Initial" | "Package_Not_Supported" | "FragAlgo_unsupported" | "Not_enough_memory" | "FragIndex_unsupported" | "Wrong_descriptor" | "SessionCnt_replay" | "MissingFrag" | "MemoryError" | "MICError" | "Successful" | "Device_exist_in_conflict_fuota_task" | (string & {});
export declare const FuotaDeviceStatus: any;
export type MulticastDeviceStatus = string;
export type McGroupId = number;
export interface WirelessDeviceStatistics {
    Arn?: string;
    Id?: string;
    Type?: WirelessDeviceType;
    Name?: string;
    DestinationName?: string;
    LastUplinkReceivedAt?: string;
    LoRaWAN?: LoRaWANListDevice;
    Sidewalk?: SidewalkListDevice;
    FuotaDeviceStatus?: FuotaDeviceStatus;
    MulticastDeviceStatus?: string;
    McGroupId?: number;
    Positioning?: PositioningConfigStatus;
}
export declare const WirelessDeviceStatistics: S.Schema<WirelessDeviceStatistics>;
export type WirelessDeviceStatisticsList = WirelessDeviceStatistics[];
export declare const WirelessDeviceStatisticsList: any;
export interface ListWirelessDevicesResponse {
    NextToken?: string;
    WirelessDeviceList?: WirelessDeviceStatistics[];
}
export declare const ListWirelessDevicesResponse: S.Schema<ListWirelessDevicesResponse>;
export interface ListWirelessGatewaysRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListWirelessGatewaysRequest: S.Schema<ListWirelessGatewaysRequest>;
export interface WirelessGatewayStatistics {
    Arn?: string;
    Id?: string;
    Name?: string;
    Description?: string;
    LoRaWAN?: LoRaWANGateway;
    LastUplinkReceivedAt?: string;
}
export declare const WirelessGatewayStatistics: S.Schema<WirelessGatewayStatistics>;
export type WirelessGatewayStatisticsList = WirelessGatewayStatistics[];
export declare const WirelessGatewayStatisticsList: any;
export interface ListWirelessGatewaysResponse {
    NextToken?: string;
    WirelessGatewayList?: WirelessGatewayStatistics[];
}
export declare const ListWirelessGatewaysResponse: S.Schema<ListWirelessGatewaysResponse>;
export type WirelessGatewayTaskDefinitionType = "UPDATE" | (string & {});
export declare const WirelessGatewayTaskDefinitionType: any;
export interface ListWirelessGatewayTaskDefinitionsRequest {
    MaxResults?: number;
    NextToken?: string;
    TaskDefinitionType?: WirelessGatewayTaskDefinitionType;
}
export declare const ListWirelessGatewayTaskDefinitionsRequest: S.Schema<ListWirelessGatewayTaskDefinitionsRequest>;
export interface LoRaWANUpdateGatewayTaskEntry {
    CurrentVersion?: LoRaWANGatewayVersion;
    UpdateVersion?: LoRaWANGatewayVersion;
}
export declare const LoRaWANUpdateGatewayTaskEntry: S.Schema<LoRaWANUpdateGatewayTaskEntry>;
export interface UpdateWirelessGatewayTaskEntry {
    Id?: string;
    LoRaWAN?: LoRaWANUpdateGatewayTaskEntry;
    Arn?: string;
}
export declare const UpdateWirelessGatewayTaskEntry: S.Schema<UpdateWirelessGatewayTaskEntry>;
export type WirelessGatewayTaskDefinitionList = UpdateWirelessGatewayTaskEntry[];
export declare const WirelessGatewayTaskDefinitionList: any;
export interface ListWirelessGatewayTaskDefinitionsResponse {
    NextToken?: string;
    TaskDefinitions?: UpdateWirelessGatewayTaskEntry[];
}
export declare const ListWirelessGatewayTaskDefinitionsResponse: S.Schema<ListWirelessGatewayTaskDefinitionsResponse>;
export interface SemtechGnssConfiguration {
    Status: PositionConfigurationStatus;
    Fec: PositionConfigurationFec;
}
export declare const SemtechGnssConfiguration: S.Schema<SemtechGnssConfiguration>;
export interface PositionSolverConfigurations {
    SemtechGnss?: SemtechGnssConfiguration;
}
export declare const PositionSolverConfigurations: S.Schema<PositionSolverConfigurations>;
export interface PutPositionConfigurationRequest {
    ResourceIdentifier: string;
    ResourceType: PositionResourceType;
    Solvers?: PositionSolverConfigurations;
    Destination?: string;
}
export declare const PutPositionConfigurationRequest: S.Schema<PutPositionConfigurationRequest>;
export interface PutPositionConfigurationResponse {
}
export declare const PutPositionConfigurationResponse: S.Schema<PutPositionConfigurationResponse>;
export interface PutResourceLogLevelRequest {
    ResourceIdentifier: string;
    ResourceType: string;
    LogLevel: LogLevel;
}
export declare const PutResourceLogLevelRequest: S.Schema<PutResourceLogLevelRequest>;
export interface PutResourceLogLevelResponse {
}
export declare const PutResourceLogLevelResponse: S.Schema<PutResourceLogLevelResponse>;
export interface ResetAllResourceLogLevelsRequest {
}
export declare const ResetAllResourceLogLevelsRequest: S.Schema<ResetAllResourceLogLevelsRequest>;
export interface ResetAllResourceLogLevelsResponse {
}
export declare const ResetAllResourceLogLevelsResponse: S.Schema<ResetAllResourceLogLevelsResponse>;
export interface ResetResourceLogLevelRequest {
    ResourceIdentifier: string;
    ResourceType: string;
}
export declare const ResetResourceLogLevelRequest: S.Schema<ResetResourceLogLevelRequest>;
export interface ResetResourceLogLevelResponse {
}
export declare const ResetResourceLogLevelResponse: S.Schema<ResetResourceLogLevelResponse>;
export type PayloadData = string;
export interface LoRaWANMulticastMetadata {
    FPort?: number;
}
export declare const LoRaWANMulticastMetadata: S.Schema<LoRaWANMulticastMetadata>;
export interface MulticastWirelessMetadata {
    LoRaWAN?: LoRaWANMulticastMetadata;
}
export declare const MulticastWirelessMetadata: S.Schema<MulticastWirelessMetadata>;
export interface SendDataToMulticastGroupRequest {
    Id: string;
    PayloadData: string;
    WirelessMetadata: MulticastWirelessMetadata;
}
export declare const SendDataToMulticastGroupRequest: S.Schema<SendDataToMulticastGroupRequest>;
export type MulticastGroupMessageId = string;
export interface SendDataToMulticastGroupResponse {
    MessageId?: string;
}
export declare const SendDataToMulticastGroupResponse: S.Schema<SendDataToMulticastGroupResponse>;
export type Seq = number;
export type MessageType = "CUSTOM_COMMAND_ID_NOTIFY" | "CUSTOM_COMMAND_ID_GET" | "CUSTOM_COMMAND_ID_SET" | "CUSTOM_COMMAND_ID_RESP" | (string & {});
export declare const MessageType: any;
export type AckModeRetryDurationSecs = number;
export interface SidewalkSendDataToDevice {
    Seq?: number;
    MessageType?: MessageType;
    AckModeRetryDurationSecs?: number;
}
export declare const SidewalkSendDataToDevice: S.Schema<SidewalkSendDataToDevice>;
export interface WirelessMetadata {
    LoRaWAN?: LoRaWANSendDataToDevice;
    Sidewalk?: SidewalkSendDataToDevice;
}
export declare const WirelessMetadata: S.Schema<WirelessMetadata>;
export interface SendDataToWirelessDeviceRequest {
    Id: string;
    TransmitMode: number;
    PayloadData: string;
    WirelessMetadata?: WirelessMetadata;
}
export declare const SendDataToWirelessDeviceRequest: S.Schema<SendDataToWirelessDeviceRequest>;
export interface SendDataToWirelessDeviceResponse {
    MessageId?: string;
}
export declare const SendDataToWirelessDeviceResponse: S.Schema<SendDataToWirelessDeviceResponse>;
export type QueryString = string;
export interface StartBulkAssociateWirelessDeviceWithMulticastGroupRequest {
    Id: string;
    QueryString?: string;
    Tags?: Tag[];
}
export declare const StartBulkAssociateWirelessDeviceWithMulticastGroupRequest: S.Schema<StartBulkAssociateWirelessDeviceWithMulticastGroupRequest>;
export interface StartBulkAssociateWirelessDeviceWithMulticastGroupResponse {
}
export declare const StartBulkAssociateWirelessDeviceWithMulticastGroupResponse: S.Schema<StartBulkAssociateWirelessDeviceWithMulticastGroupResponse>;
export interface StartBulkDisassociateWirelessDeviceFromMulticastGroupRequest {
    Id: string;
    QueryString?: string;
    Tags?: Tag[];
}
export declare const StartBulkDisassociateWirelessDeviceFromMulticastGroupRequest: S.Schema<StartBulkDisassociateWirelessDeviceFromMulticastGroupRequest>;
export interface StartBulkDisassociateWirelessDeviceFromMulticastGroupResponse {
}
export declare const StartBulkDisassociateWirelessDeviceFromMulticastGroupResponse: S.Schema<StartBulkDisassociateWirelessDeviceFromMulticastGroupResponse>;
export interface LoRaWANStartFuotaTask {
    StartTime?: Date;
}
export declare const LoRaWANStartFuotaTask: S.Schema<LoRaWANStartFuotaTask>;
export interface StartFuotaTaskRequest {
    Id: string;
    LoRaWAN?: LoRaWANStartFuotaTask;
}
export declare const StartFuotaTaskRequest: S.Schema<StartFuotaTaskRequest>;
export interface StartFuotaTaskResponse {
}
export declare const StartFuotaTaskResponse: S.Schema<StartFuotaTaskResponse>;
export interface StartMulticastGroupSessionRequest {
    Id: string;
    LoRaWAN: LoRaWANMulticastSession;
}
export declare const StartMulticastGroupSessionRequest: S.Schema<StartMulticastGroupSessionRequest>;
export interface StartMulticastGroupSessionResponse {
}
export declare const StartMulticastGroupSessionResponse: S.Schema<StartMulticastGroupSessionResponse>;
export type DeviceName = string;
export interface SidewalkSingleStartImportInfo {
    SidewalkManufacturingSn?: string;
    Positioning?: SidewalkPositioning;
}
export declare const SidewalkSingleStartImportInfo: S.Schema<SidewalkSingleStartImportInfo>;
export interface StartSingleWirelessDeviceImportTaskRequest {
    DestinationName: string;
    ClientRequestToken?: string;
    DeviceName?: string;
    Tags?: Tag[];
    Positioning?: PositioningConfigStatus;
    Sidewalk: SidewalkSingleStartImportInfo;
}
export declare const StartSingleWirelessDeviceImportTaskRequest: S.Schema<StartSingleWirelessDeviceImportTaskRequest>;
export interface StartSingleWirelessDeviceImportTaskResponse {
    Id?: string;
    Arn?: string;
}
export declare const StartSingleWirelessDeviceImportTaskResponse: S.Schema<StartSingleWirelessDeviceImportTaskResponse>;
export interface SidewalkStartImportInfo {
    DeviceCreationFile?: string;
    Role?: string;
    Positioning?: SidewalkPositioning;
}
export declare const SidewalkStartImportInfo: S.Schema<SidewalkStartImportInfo>;
export interface StartWirelessDeviceImportTaskRequest {
    DestinationName: string;
    ClientRequestToken?: string;
    Tags?: Tag[];
    Positioning?: PositioningConfigStatus;
    Sidewalk: SidewalkStartImportInfo;
}
export declare const StartWirelessDeviceImportTaskRequest: S.Schema<StartWirelessDeviceImportTaskRequest>;
export interface StartWirelessDeviceImportTaskResponse {
    Id?: string;
    Arn?: string;
}
export declare const StartWirelessDeviceImportTaskResponse: S.Schema<StartWirelessDeviceImportTaskResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface TestWirelessDeviceRequest {
    Id: string;
}
export declare const TestWirelessDeviceRequest: S.Schema<TestWirelessDeviceRequest>;
export type Result = string;
export interface TestWirelessDeviceResponse {
    Result?: string;
}
export declare const TestWirelessDeviceResponse: S.Schema<TestWirelessDeviceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateDestinationRequest {
    Name: string;
    ExpressionType?: ExpressionType;
    Expression?: string;
    Description?: string;
    RoleArn?: string;
}
export declare const UpdateDestinationRequest: S.Schema<UpdateDestinationRequest>;
export interface UpdateDestinationResponse {
}
export declare const UpdateDestinationResponse: S.Schema<UpdateDestinationResponse>;
export interface UpdateEventConfigurationByResourceTypesRequest {
    DeviceRegistrationState?: DeviceRegistrationStateResourceTypeEventConfiguration;
    Proximity?: ProximityResourceTypeEventConfiguration;
    Join?: JoinResourceTypeEventConfiguration;
    ConnectionStatus?: ConnectionStatusResourceTypeEventConfiguration;
    MessageDeliveryStatus?: MessageDeliveryStatusResourceTypeEventConfiguration;
}
export declare const UpdateEventConfigurationByResourceTypesRequest: S.Schema<UpdateEventConfigurationByResourceTypesRequest>;
export interface UpdateEventConfigurationByResourceTypesResponse {
}
export declare const UpdateEventConfigurationByResourceTypesResponse: S.Schema<UpdateEventConfigurationByResourceTypesResponse>;
export interface UpdateFuotaTaskRequest {
    Id: string;
    Name?: string;
    Description?: string;
    LoRaWAN?: LoRaWANFuotaTask;
    FirmwareUpdateImage?: string;
    FirmwareUpdateRole?: string;
    RedundancyPercent?: number;
    FragmentSizeBytes?: number;
    FragmentIntervalMS?: number;
    Descriptor?: string;
}
export declare const UpdateFuotaTaskRequest: S.Schema<UpdateFuotaTaskRequest>;
export interface UpdateFuotaTaskResponse {
}
export declare const UpdateFuotaTaskResponse: S.Schema<UpdateFuotaTaskResponse>;
export interface UpdateLogLevelsByResourceTypesRequest {
    DefaultLogLevel?: LogLevel;
    FuotaTaskLogOptions?: FuotaTaskLogOption[];
    WirelessDeviceLogOptions?: WirelessDeviceLogOption[];
    WirelessGatewayLogOptions?: WirelessGatewayLogOption[];
}
export declare const UpdateLogLevelsByResourceTypesRequest: S.Schema<UpdateLogLevelsByResourceTypesRequest>;
export interface UpdateLogLevelsByResourceTypesResponse {
}
export declare const UpdateLogLevelsByResourceTypesResponse: S.Schema<UpdateLogLevelsByResourceTypesResponse>;
export interface UpdateMetricConfigurationRequest {
    SummaryMetric?: SummaryMetricConfiguration;
}
export declare const UpdateMetricConfigurationRequest: S.Schema<UpdateMetricConfigurationRequest>;
export interface UpdateMetricConfigurationResponse {
}
export declare const UpdateMetricConfigurationResponse: S.Schema<UpdateMetricConfigurationResponse>;
export interface UpdateMulticastGroupRequest {
    Id: string;
    Name?: string;
    Description?: string;
    LoRaWAN?: LoRaWANMulticast;
}
export declare const UpdateMulticastGroupRequest: S.Schema<UpdateMulticastGroupRequest>;
export interface UpdateMulticastGroupResponse {
}
export declare const UpdateMulticastGroupResponse: S.Schema<UpdateMulticastGroupResponse>;
export interface UpdateNetworkAnalyzerConfigurationRequest {
    ConfigurationName: string;
    TraceContent?: TraceContent;
    WirelessDevicesToAdd?: string[];
    WirelessDevicesToRemove?: string[];
    WirelessGatewaysToAdd?: string[];
    WirelessGatewaysToRemove?: string[];
    Description?: string;
    MulticastGroupsToAdd?: string[];
    MulticastGroupsToRemove?: string[];
}
export declare const UpdateNetworkAnalyzerConfigurationRequest: S.Schema<UpdateNetworkAnalyzerConfigurationRequest>;
export interface UpdateNetworkAnalyzerConfigurationResponse {
}
export declare const UpdateNetworkAnalyzerConfigurationResponse: S.Schema<UpdateNetworkAnalyzerConfigurationResponse>;
export interface SidewalkUpdateAccount {
    AppServerPrivateKey?: string | redacted.Redacted<string>;
}
export declare const SidewalkUpdateAccount: S.Schema<SidewalkUpdateAccount>;
export interface UpdatePartnerAccountRequest {
    Sidewalk: SidewalkUpdateAccount;
    PartnerAccountId: string;
    PartnerType: PartnerType;
}
export declare const UpdatePartnerAccountRequest: S.Schema<UpdatePartnerAccountRequest>;
export interface UpdatePartnerAccountResponse {
}
export declare const UpdatePartnerAccountResponse: S.Schema<UpdatePartnerAccountResponse>;
export interface UpdatePositionRequest {
    ResourceIdentifier: string;
    ResourceType: PositionResourceType;
    Position: number[];
}
export declare const UpdatePositionRequest: S.Schema<UpdatePositionRequest>;
export interface UpdatePositionResponse {
}
export declare const UpdatePositionResponse: S.Schema<UpdatePositionResponse>;
export interface UpdateResourceEventConfigurationRequest {
    Identifier: string;
    IdentifierType: IdentifierType;
    PartnerType?: EventNotificationPartnerType;
    DeviceRegistrationState?: DeviceRegistrationStateEventConfiguration;
    Proximity?: ProximityEventConfiguration;
    Join?: JoinEventConfiguration;
    ConnectionStatus?: ConnectionStatusEventConfiguration;
    MessageDeliveryStatus?: MessageDeliveryStatusEventConfiguration;
}
export declare const UpdateResourceEventConfigurationRequest: S.Schema<UpdateResourceEventConfigurationRequest>;
export interface UpdateResourceEventConfigurationResponse {
}
export declare const UpdateResourceEventConfigurationResponse: S.Schema<UpdateResourceEventConfigurationResponse>;
export interface UpdateResourcePositionRequest {
    ResourceIdentifier: string;
    ResourceType: PositionResourceType;
    GeoJsonPayload?: T.StreamingInputBody;
}
export declare const UpdateResourcePositionRequest: S.Schema<UpdateResourcePositionRequest>;
export interface UpdateResourcePositionResponse {
}
export declare const UpdateResourcePositionResponse: S.Schema<UpdateResourcePositionResponse>;
export interface UpdateAbpV1_1 {
    FCntStart?: number;
}
export declare const UpdateAbpV1_1: S.Schema<UpdateAbpV1_1>;
export interface UpdateAbpV1_0_x {
    FCntStart?: number;
}
export declare const UpdateAbpV1_0_x: S.Schema<UpdateAbpV1_0_x>;
export interface UpdateFPorts {
    Positioning?: Positioning;
    Applications?: ApplicationConfig[];
}
export declare const UpdateFPorts: S.Schema<UpdateFPorts>;
export interface LoRaWANUpdateDevice {
    DeviceProfileId?: string;
    ServiceProfileId?: string;
    AbpV1_1?: UpdateAbpV1_1;
    AbpV1_0_x?: UpdateAbpV1_0_x;
    FPorts?: UpdateFPorts;
}
export declare const LoRaWANUpdateDevice: S.Schema<LoRaWANUpdateDevice>;
export interface SidewalkUpdateWirelessDevice {
    Positioning?: SidewalkPositioning;
}
export declare const SidewalkUpdateWirelessDevice: S.Schema<SidewalkUpdateWirelessDevice>;
export interface UpdateWirelessDeviceRequest {
    Id: string;
    DestinationName?: string;
    Name?: string;
    Description?: string;
    LoRaWAN?: LoRaWANUpdateDevice;
    Positioning?: PositioningConfigStatus;
    Sidewalk?: SidewalkUpdateWirelessDevice;
}
export declare const UpdateWirelessDeviceRequest: S.Schema<UpdateWirelessDeviceRequest>;
export interface UpdateWirelessDeviceResponse {
}
export declare const UpdateWirelessDeviceResponse: S.Schema<UpdateWirelessDeviceResponse>;
export interface SidewalkUpdateImportInfo {
    DeviceCreationFile?: string;
}
export declare const SidewalkUpdateImportInfo: S.Schema<SidewalkUpdateImportInfo>;
export interface UpdateWirelessDeviceImportTaskRequest {
    Id: string;
    Sidewalk: SidewalkUpdateImportInfo;
}
export declare const UpdateWirelessDeviceImportTaskRequest: S.Schema<UpdateWirelessDeviceImportTaskRequest>;
export interface UpdateWirelessDeviceImportTaskResponse {
}
export declare const UpdateWirelessDeviceImportTaskResponse: S.Schema<UpdateWirelessDeviceImportTaskResponse>;
export interface UpdateWirelessGatewayRequest {
    Id: string;
    Name?: string;
    Description?: string;
    JoinEuiFilters?: string[][];
    NetIdFilters?: string[];
    MaxEirp?: number;
}
export declare const UpdateWirelessGatewayRequest: S.Schema<UpdateWirelessGatewayRequest>;
export interface UpdateWirelessGatewayResponse {
}
export declare const UpdateWirelessGatewayResponse: S.Schema<UpdateWirelessGatewayResponse>;
export type Message = string;
export type ResourceId = string;
export type AssociateAwsAccountWithPartnerAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a partner account with your AWS account.
 */
export declare const associateAwsAccountWithPartnerAccount: API.OperationMethod<AssociateAwsAccountWithPartnerAccountRequest, AssociateAwsAccountWithPartnerAccountResponse, AssociateAwsAccountWithPartnerAccountError, Credentials | HttpClient.HttpClient>;
export type AssociateMulticastGroupWithFuotaTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associate a multicast group with a FUOTA task.
 */
export declare const associateMulticastGroupWithFuotaTask: API.OperationMethod<AssociateMulticastGroupWithFuotaTaskRequest, AssociateMulticastGroupWithFuotaTaskResponse, AssociateMulticastGroupWithFuotaTaskError, Credentials | HttpClient.HttpClient>;
export type AssociateWirelessDeviceWithFuotaTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associate a wireless device with a FUOTA task.
 */
export declare const associateWirelessDeviceWithFuotaTask: API.OperationMethod<AssociateWirelessDeviceWithFuotaTaskRequest, AssociateWirelessDeviceWithFuotaTaskResponse, AssociateWirelessDeviceWithFuotaTaskError, Credentials | HttpClient.HttpClient>;
export type AssociateWirelessDeviceWithMulticastGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a wireless device with a multicast group.
 */
export declare const associateWirelessDeviceWithMulticastGroup: API.OperationMethod<AssociateWirelessDeviceWithMulticastGroupRequest, AssociateWirelessDeviceWithMulticastGroupResponse, AssociateWirelessDeviceWithMulticastGroupError, Credentials | HttpClient.HttpClient>;
export type AssociateWirelessDeviceWithThingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a wireless device with a thing.
 */
export declare const associateWirelessDeviceWithThing: API.OperationMethod<AssociateWirelessDeviceWithThingRequest, AssociateWirelessDeviceWithThingResponse, AssociateWirelessDeviceWithThingError, Credentials | HttpClient.HttpClient>;
export type AssociateWirelessGatewayWithCertificateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a wireless gateway with a certificate.
 */
export declare const associateWirelessGatewayWithCertificate: API.OperationMethod<AssociateWirelessGatewayWithCertificateRequest, AssociateWirelessGatewayWithCertificateResponse, AssociateWirelessGatewayWithCertificateError, Credentials | HttpClient.HttpClient>;
export type AssociateWirelessGatewayWithThingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a wireless gateway with a thing.
 */
export declare const associateWirelessGatewayWithThing: API.OperationMethod<AssociateWirelessGatewayWithThingRequest, AssociateWirelessGatewayWithThingResponse, AssociateWirelessGatewayWithThingError, Credentials | HttpClient.HttpClient>;
export type CancelMulticastGroupSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels an existing multicast group session.
 */
export declare const cancelMulticastGroupSession: API.OperationMethod<CancelMulticastGroupSessionRequest, CancelMulticastGroupSessionResponse, CancelMulticastGroupSessionError, Credentials | HttpClient.HttpClient>;
export type CreateDestinationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new destination that maps a device message to an AWS IoT rule.
 */
export declare const createDestination: API.OperationMethod<CreateDestinationRequest, CreateDestinationResponse, CreateDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateDeviceProfileError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new device profile.
 */
export declare const createDeviceProfile: API.OperationMethod<CreateDeviceProfileRequest, CreateDeviceProfileResponse, CreateDeviceProfileError, Credentials | HttpClient.HttpClient>;
export type CreateFuotaTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a FUOTA task.
 */
export declare const createFuotaTask: API.OperationMethod<CreateFuotaTaskRequest, CreateFuotaTaskResponse, CreateFuotaTaskError, Credentials | HttpClient.HttpClient>;
export type CreateMulticastGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a multicast group.
 */
export declare const createMulticastGroup: API.OperationMethod<CreateMulticastGroupRequest, CreateMulticastGroupResponse, CreateMulticastGroupError, Credentials | HttpClient.HttpClient>;
export type CreateNetworkAnalyzerConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new network analyzer configuration.
 */
export declare const createNetworkAnalyzerConfiguration: API.OperationMethod<CreateNetworkAnalyzerConfigurationRequest, CreateNetworkAnalyzerConfigurationResponse, CreateNetworkAnalyzerConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateServiceProfileError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new service profile.
 */
export declare const createServiceProfile: API.OperationMethod<CreateServiceProfileRequest, CreateServiceProfileResponse, CreateServiceProfileError, Credentials | HttpClient.HttpClient>;
export type CreateWirelessDeviceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provisions a wireless device.
 */
export declare const createWirelessDevice: API.OperationMethod<CreateWirelessDeviceRequest, CreateWirelessDeviceResponse, CreateWirelessDeviceError, Credentials | HttpClient.HttpClient>;
export type CreateWirelessGatewayError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provisions a wireless gateway.
 *
 * When provisioning a wireless gateway, you might run into duplication errors for
 * the following reasons.
 *
 * - If you specify a `GatewayEui` value that already exists.
 *
 * - If you used a `ClientRequestToken` with the same parameters
 * within the last 10 minutes.
 *
 * To avoid this error, make sure that you use unique identifiers and parameters for
 * each request within the specified time period.
 */
export declare const createWirelessGateway: API.OperationMethod<CreateWirelessGatewayRequest, CreateWirelessGatewayResponse, CreateWirelessGatewayError, Credentials | HttpClient.HttpClient>;
export type CreateWirelessGatewayTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a task for a wireless gateway.
 */
export declare const createWirelessGatewayTask: API.OperationMethod<CreateWirelessGatewayTaskRequest, CreateWirelessGatewayTaskResponse, CreateWirelessGatewayTaskError, Credentials | HttpClient.HttpClient>;
export type CreateWirelessGatewayTaskDefinitionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a gateway task definition.
 */
export declare const createWirelessGatewayTaskDefinition: API.OperationMethod<CreateWirelessGatewayTaskDefinitionRequest, CreateWirelessGatewayTaskDefinitionResponse, CreateWirelessGatewayTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteDestinationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a destination.
 */
export declare const deleteDestination: API.OperationMethod<DeleteDestinationRequest, DeleteDestinationResponse, DeleteDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteDeviceProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a device profile.
 */
export declare const deleteDeviceProfile: API.OperationMethod<DeleteDeviceProfileRequest, DeleteDeviceProfileResponse, DeleteDeviceProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteFuotaTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a FUOTA task.
 */
export declare const deleteFuotaTask: API.OperationMethod<DeleteFuotaTaskRequest, DeleteFuotaTaskResponse, DeleteFuotaTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteMulticastGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a multicast group if it is not in use by a FUOTA task.
 */
export declare const deleteMulticastGroup: API.OperationMethod<DeleteMulticastGroupRequest, DeleteMulticastGroupResponse, DeleteMulticastGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteNetworkAnalyzerConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a network analyzer configuration.
 */
export declare const deleteNetworkAnalyzerConfiguration: API.OperationMethod<DeleteNetworkAnalyzerConfigurationRequest, DeleteNetworkAnalyzerConfigurationResponse, DeleteNetworkAnalyzerConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteQueuedMessagesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove queued messages from the downlink queue.
 */
export declare const deleteQueuedMessages: API.OperationMethod<DeleteQueuedMessagesRequest, DeleteQueuedMessagesResponse, DeleteQueuedMessagesError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a service profile.
 */
export declare const deleteServiceProfile: API.OperationMethod<DeleteServiceProfileRequest, DeleteServiceProfileResponse, DeleteServiceProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteWirelessDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a wireless device.
 */
export declare const deleteWirelessDevice: API.OperationMethod<DeleteWirelessDeviceRequest, DeleteWirelessDeviceResponse, DeleteWirelessDeviceError, Credentials | HttpClient.HttpClient>;
export type DeleteWirelessDeviceImportTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an import task.
 */
export declare const deleteWirelessDeviceImportTask: API.OperationMethod<DeleteWirelessDeviceImportTaskRequest, DeleteWirelessDeviceImportTaskResponse, DeleteWirelessDeviceImportTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteWirelessGatewayError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a wireless gateway.
 *
 * When deleting a wireless gateway, you might run into duplication errors for the
 * following reasons.
 *
 * - If you specify a `GatewayEui` value that already exists.
 *
 * - If you used a `ClientRequestToken` with the same parameters
 * within the last 10 minutes.
 *
 * To avoid this error, make sure that you use unique identifiers and parameters for
 * each request within the specified time period.
 */
export declare const deleteWirelessGateway: API.OperationMethod<DeleteWirelessGatewayRequest, DeleteWirelessGatewayResponse, DeleteWirelessGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteWirelessGatewayTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a wireless gateway task.
 */
export declare const deleteWirelessGatewayTask: API.OperationMethod<DeleteWirelessGatewayTaskRequest, DeleteWirelessGatewayTaskResponse, DeleteWirelessGatewayTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteWirelessGatewayTaskDefinitionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a wireless gateway task definition. Deleting this task definition does not
 * affect tasks that are currently in progress.
 */
export declare const deleteWirelessGatewayTaskDefinition: API.OperationMethod<DeleteWirelessGatewayTaskDefinitionRequest, DeleteWirelessGatewayTaskDefinitionResponse, DeleteWirelessGatewayTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeregisterWirelessDeviceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deregister a wireless device from AWS IoT Wireless.
 */
export declare const deregisterWirelessDevice: API.OperationMethod<DeregisterWirelessDeviceRequest, DeregisterWirelessDeviceResponse, DeregisterWirelessDeviceError, Credentials | HttpClient.HttpClient>;
export type DisassociateAwsAccountFromPartnerAccountError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates your AWS account from a partner account. If
 * `PartnerAccountId` and `PartnerType` are `null`,
 * disassociates your AWS account from all partner accounts.
 */
export declare const disassociateAwsAccountFromPartnerAccount: API.OperationMethod<DisassociateAwsAccountFromPartnerAccountRequest, DisassociateAwsAccountFromPartnerAccountResponse, DisassociateAwsAccountFromPartnerAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateMulticastGroupFromFuotaTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Disassociates a multicast group from a FUOTA task.
 */
export declare const disassociateMulticastGroupFromFuotaTask: API.OperationMethod<DisassociateMulticastGroupFromFuotaTaskRequest, DisassociateMulticastGroupFromFuotaTaskResponse, DisassociateMulticastGroupFromFuotaTaskError, Credentials | HttpClient.HttpClient>;
export type DisassociateWirelessDeviceFromFuotaTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a wireless device from a FUOTA task.
 */
export declare const disassociateWirelessDeviceFromFuotaTask: API.OperationMethod<DisassociateWirelessDeviceFromFuotaTaskRequest, DisassociateWirelessDeviceFromFuotaTaskResponse, DisassociateWirelessDeviceFromFuotaTaskError, Credentials | HttpClient.HttpClient>;
export type DisassociateWirelessDeviceFromMulticastGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a wireless device from a multicast group.
 */
export declare const disassociateWirelessDeviceFromMulticastGroup: API.OperationMethod<DisassociateWirelessDeviceFromMulticastGroupRequest, DisassociateWirelessDeviceFromMulticastGroupResponse, DisassociateWirelessDeviceFromMulticastGroupError, Credentials | HttpClient.HttpClient>;
export type DisassociateWirelessDeviceFromThingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a wireless device from its currently associated thing.
 */
export declare const disassociateWirelessDeviceFromThing: API.OperationMethod<DisassociateWirelessDeviceFromThingRequest, DisassociateWirelessDeviceFromThingResponse, DisassociateWirelessDeviceFromThingError, Credentials | HttpClient.HttpClient>;
export type DisassociateWirelessGatewayFromCertificateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a wireless gateway from its currently associated certificate.
 */
export declare const disassociateWirelessGatewayFromCertificate: API.OperationMethod<DisassociateWirelessGatewayFromCertificateRequest, DisassociateWirelessGatewayFromCertificateResponse, DisassociateWirelessGatewayFromCertificateError, Credentials | HttpClient.HttpClient>;
export type DisassociateWirelessGatewayFromThingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a wireless gateway from its currently associated thing.
 */
export declare const disassociateWirelessGatewayFromThing: API.OperationMethod<DisassociateWirelessGatewayFromThingRequest, DisassociateWirelessGatewayFromThingResponse, DisassociateWirelessGatewayFromThingError, Credentials | HttpClient.HttpClient>;
export type GetDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a destination.
 */
export declare const getDestination: API.OperationMethod<GetDestinationRequest, GetDestinationResponse, GetDestinationError, Credentials | HttpClient.HttpClient>;
export type GetDeviceProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a device profile.
 */
export declare const getDeviceProfile: API.OperationMethod<GetDeviceProfileRequest, GetDeviceProfileResponse, GetDeviceProfileError, Credentials | HttpClient.HttpClient>;
export type GetEventConfigurationByResourceTypesError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Get the event configuration based on resource types.
 */
export declare const getEventConfigurationByResourceTypes: API.OperationMethod<GetEventConfigurationByResourceTypesRequest, GetEventConfigurationByResourceTypesResponse, GetEventConfigurationByResourceTypesError, Credentials | HttpClient.HttpClient>;
export type GetFuotaTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a FUOTA task.
 */
export declare const getFuotaTask: API.OperationMethod<GetFuotaTaskRequest, GetFuotaTaskResponse, GetFuotaTaskError, Credentials | HttpClient.HttpClient>;
export type GetLogLevelsByResourceTypesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns current default log levels or log levels by resource types. Based on the
 * resource type, log levels can be returned for wireless device, wireless gateway, or
 * FUOTA task log options.
 */
export declare const getLogLevelsByResourceTypes: API.OperationMethod<GetLogLevelsByResourceTypesRequest, GetLogLevelsByResourceTypesResponse, GetLogLevelsByResourceTypesError, Credentials | HttpClient.HttpClient>;
export type GetMetricConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the metric configuration status for this AWS account.
 */
export declare const getMetricConfiguration: API.OperationMethod<GetMetricConfigurationRequest, GetMetricConfigurationResponse, GetMetricConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetMetricsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the summary metrics for this AWS account.
 */
export declare const getMetrics: API.OperationMethod<GetMetricsRequest, GetMetricsResponse, GetMetricsError, Credentials | HttpClient.HttpClient>;
export type GetMulticastGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a multicast group.
 */
export declare const getMulticastGroup: API.OperationMethod<GetMulticastGroupRequest, GetMulticastGroupResponse, GetMulticastGroupError, Credentials | HttpClient.HttpClient>;
export type GetMulticastGroupSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a multicast group session.
 */
export declare const getMulticastGroupSession: API.OperationMethod<GetMulticastGroupSessionRequest, GetMulticastGroupSessionResponse, GetMulticastGroupSessionError, Credentials | HttpClient.HttpClient>;
export type GetNetworkAnalyzerConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get network analyzer configuration.
 */
export declare const getNetworkAnalyzerConfiguration: API.OperationMethod<GetNetworkAnalyzerConfigurationRequest, GetNetworkAnalyzerConfigurationResponse, GetNetworkAnalyzerConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetPartnerAccountError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a partner account. If `PartnerAccountId` and
 * `PartnerType` are `null`, returns all partner accounts.
 */
export declare const getPartnerAccount: API.OperationMethod<GetPartnerAccountRequest, GetPartnerAccountResponse, GetPartnerAccountError, Credentials | HttpClient.HttpClient>;
export type GetPositionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the position information for a given resource.
 *
 * This action is no longer supported. Calls to retrieve the position information
 * should use the GetResourcePosition API operation instead.
 */
export declare const getPosition: API.OperationMethod<GetPositionRequest, GetPositionResponse, GetPositionError, Credentials | HttpClient.HttpClient>;
export type GetPositionConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get position configuration for a given resource.
 *
 * This action is no longer supported. Calls to retrieve the position configuration
 * should use the GetResourcePosition API operation instead.
 */
export declare const getPositionConfiguration: API.OperationMethod<GetPositionConfigurationRequest, GetPositionConfigurationResponse, GetPositionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetPositionEstimateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get estimated position information as a payload in GeoJSON format. The payload
 * measurement data is resolved using solvers that are provided by third-party
 * vendors.
 */
export declare const getPositionEstimate: API.OperationMethod<GetPositionEstimateRequest, GetPositionEstimateResponse, GetPositionEstimateError, Credentials | HttpClient.HttpClient>;
export type GetResourceEventConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the event configuration for a particular resource identifier.
 */
export declare const getResourceEventConfiguration: API.OperationMethod<GetResourceEventConfigurationRequest, GetResourceEventConfigurationResponse, GetResourceEventConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetResourceLogLevelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Fetches the log-level override, if any, for a given resource ID and resource
 * type..
 */
export declare const getResourceLogLevel: API.OperationMethod<GetResourceLogLevelRequest, GetResourceLogLevelResponse, GetResourceLogLevelError, Credentials | HttpClient.HttpClient>;
export type GetResourcePositionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the position information for a given wireless device or a wireless gateway
 * resource. The position information uses the World Geodetic System
 * (WGS84).
 */
export declare const getResourcePosition: API.OperationMethod<GetResourcePositionRequest, GetResourcePositionResponse, GetResourcePositionError, Credentials | HttpClient.HttpClient>;
export type GetServiceEndpointError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the account-specific endpoint for Configuration and Update Server (CUPS) protocol
 * or LoRaWAN Network Server (LNS) connections.
 */
export declare const getServiceEndpoint: API.OperationMethod<GetServiceEndpointRequest, GetServiceEndpointResponse, GetServiceEndpointError, Credentials | HttpClient.HttpClient>;
export type GetServiceProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a service profile.
 */
export declare const getServiceProfile: API.OperationMethod<GetServiceProfileRequest, GetServiceProfileResponse, GetServiceProfileError, Credentials | HttpClient.HttpClient>;
export type GetWirelessDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a wireless device.
 */
export declare const getWirelessDevice: API.OperationMethod<GetWirelessDeviceRequest, GetWirelessDeviceResponse, GetWirelessDeviceError, Credentials | HttpClient.HttpClient>;
export type GetWirelessDeviceImportTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get information about an import task and count of device onboarding summary
 * information for the import task.
 */
export declare const getWirelessDeviceImportTask: API.OperationMethod<GetWirelessDeviceImportTaskRequest, GetWirelessDeviceImportTaskResponse, GetWirelessDeviceImportTaskError, Credentials | HttpClient.HttpClient>;
export type GetWirelessDeviceStatisticsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets operating information about a wireless device.
 */
export declare const getWirelessDeviceStatistics: API.OperationMethod<GetWirelessDeviceStatisticsRequest, GetWirelessDeviceStatisticsResponse, GetWirelessDeviceStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetWirelessGatewayError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a wireless gateway.
 */
export declare const getWirelessGateway: API.OperationMethod<GetWirelessGatewayRequest, GetWirelessGatewayResponse, GetWirelessGatewayError, Credentials | HttpClient.HttpClient>;
export type GetWirelessGatewayCertificateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the ID of the certificate that is currently associated with a wireless
 * gateway.
 */
export declare const getWirelessGatewayCertificate: API.OperationMethod<GetWirelessGatewayCertificateRequest, GetWirelessGatewayCertificateResponse, GetWirelessGatewayCertificateError, Credentials | HttpClient.HttpClient>;
export type GetWirelessGatewayFirmwareInformationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the firmware version and other information about a wireless gateway.
 */
export declare const getWirelessGatewayFirmwareInformation: API.OperationMethod<GetWirelessGatewayFirmwareInformationRequest, GetWirelessGatewayFirmwareInformationResponse, GetWirelessGatewayFirmwareInformationError, Credentials | HttpClient.HttpClient>;
export type GetWirelessGatewayStatisticsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets operating information about a wireless gateway.
 */
export declare const getWirelessGatewayStatistics: API.OperationMethod<GetWirelessGatewayStatisticsRequest, GetWirelessGatewayStatisticsResponse, GetWirelessGatewayStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetWirelessGatewayTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a wireless gateway task.
 */
export declare const getWirelessGatewayTask: API.OperationMethod<GetWirelessGatewayTaskRequest, GetWirelessGatewayTaskResponse, GetWirelessGatewayTaskError, Credentials | HttpClient.HttpClient>;
export type GetWirelessGatewayTaskDefinitionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a wireless gateway task definition.
 */
export declare const getWirelessGatewayTaskDefinition: API.OperationMethod<GetWirelessGatewayTaskDefinitionRequest, GetWirelessGatewayTaskDefinitionResponse, GetWirelessGatewayTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type ListDestinationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the destinations registered to your AWS account.
 */
export declare const listDestinations: API.PaginatedOperationMethod<ListDestinationsRequest, ListDestinationsResponse, ListDestinationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDeviceProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the device profiles registered to your AWS account.
 */
export declare const listDeviceProfiles: API.PaginatedOperationMethod<ListDeviceProfilesRequest, ListDeviceProfilesResponse, ListDeviceProfilesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDevicesForWirelessDeviceImportTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the Sidewalk devices in an import task and their onboarding status.
 */
export declare const listDevicesForWirelessDeviceImportTask: API.OperationMethod<ListDevicesForWirelessDeviceImportTaskRequest, ListDevicesForWirelessDeviceImportTaskResponse, ListDevicesForWirelessDeviceImportTaskError, Credentials | HttpClient.HttpClient>;
export type ListEventConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List event configurations where at least one event topic has been enabled.
 */
export declare const listEventConfigurations: API.OperationMethod<ListEventConfigurationsRequest, ListEventConfigurationsResponse, ListEventConfigurationsError, Credentials | HttpClient.HttpClient>;
export type ListFuotaTasksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the FUOTA tasks registered to your AWS account.
 */
export declare const listFuotaTasks: API.PaginatedOperationMethod<ListFuotaTasksRequest, ListFuotaTasksResponse, ListFuotaTasksError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMulticastGroupsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the multicast groups registered to your AWS account.
 */
export declare const listMulticastGroups: API.PaginatedOperationMethod<ListMulticastGroupsRequest, ListMulticastGroupsResponse, ListMulticastGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMulticastGroupsByFuotaTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all multicast groups associated with a FUOTA task.
 */
export declare const listMulticastGroupsByFuotaTask: API.PaginatedOperationMethod<ListMulticastGroupsByFuotaTaskRequest, ListMulticastGroupsByFuotaTaskResponse, ListMulticastGroupsByFuotaTaskError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNetworkAnalyzerConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the network analyzer configurations.
 */
export declare const listNetworkAnalyzerConfigurations: API.PaginatedOperationMethod<ListNetworkAnalyzerConfigurationsRequest, ListNetworkAnalyzerConfigurationsResponse, ListNetworkAnalyzerConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPartnerAccountsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the partner accounts associated with your AWS account.
 */
export declare const listPartnerAccounts: API.OperationMethod<ListPartnerAccountsRequest, ListPartnerAccountsResponse, ListPartnerAccountsError, Credentials | HttpClient.HttpClient>;
export type ListPositionConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List position configurations for a given resource, such as positioning solvers.
 *
 * This action is no longer supported. Calls to retrieve position information should
 * use the GetResourcePosition API operation instead.
 */
export declare const listPositionConfigurations: API.PaginatedOperationMethod<ListPositionConfigurationsRequest, ListPositionConfigurationsResponse, ListPositionConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListQueuedMessagesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List queued messages in the downlink queue.
 */
export declare const listQueuedMessages: API.PaginatedOperationMethod<ListQueuedMessagesRequest, ListQueuedMessagesResponse, ListQueuedMessagesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListServiceProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the service profiles registered to your AWS account.
 */
export declare const listServiceProfiles: API.PaginatedOperationMethod<ListServiceProfilesRequest, ListServiceProfilesResponse, ListServiceProfilesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags (metadata) you have assigned to the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWirelessDeviceImportTasksError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List of import tasks and summary information of onboarding status of devices in each
 * import task.
 */
export declare const listWirelessDeviceImportTasks: API.OperationMethod<ListWirelessDeviceImportTasksRequest, ListWirelessDeviceImportTasksResponse, ListWirelessDeviceImportTasksError, Credentials | HttpClient.HttpClient>;
export type ListWirelessDevicesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the wireless devices registered to your AWS account.
 */
export declare const listWirelessDevices: API.PaginatedOperationMethod<ListWirelessDevicesRequest, ListWirelessDevicesResponse, ListWirelessDevicesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListWirelessGatewaysError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the wireless gateways registered to your AWS account.
 */
export declare const listWirelessGateways: API.PaginatedOperationMethod<ListWirelessGatewaysRequest, ListWirelessGatewaysResponse, ListWirelessGatewaysError, Credentials | HttpClient.HttpClient, unknown>;
export type ListWirelessGatewayTaskDefinitionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the wireless gateway tasks definitions registered to your AWS account.
 */
export declare const listWirelessGatewayTaskDefinitions: API.OperationMethod<ListWirelessGatewayTaskDefinitionsRequest, ListWirelessGatewayTaskDefinitionsResponse, ListWirelessGatewayTaskDefinitionsError, Credentials | HttpClient.HttpClient>;
export type PutPositionConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Put position configuration for a given resource.
 *
 * This action is no longer supported. Calls to update the position configuration
 * should use the UpdateResourcePosition API operation instead.
 */
export declare const putPositionConfiguration: API.OperationMethod<PutPositionConfigurationRequest, PutPositionConfigurationResponse, PutPositionConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutResourceLogLevelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets the log-level override for a resource ID and resource type. A limit of 200 log
 * level override can be set per account.
 */
export declare const putResourceLogLevel: API.OperationMethod<PutResourceLogLevelRequest, PutResourceLogLevelResponse, PutResourceLogLevelError, Credentials | HttpClient.HttpClient>;
export type ResetAllResourceLogLevelsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the log-level overrides for all resources; wireless devices, wireless
 * gateways, and FUOTA tasks.
 */
export declare const resetAllResourceLogLevels: API.OperationMethod<ResetAllResourceLogLevelsRequest, ResetAllResourceLogLevelsResponse, ResetAllResourceLogLevelsError, Credentials | HttpClient.HttpClient>;
export type ResetResourceLogLevelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the log-level override, if any, for a specific resource ID and resource type.
 * It can be used for a wireless device, a wireless gateway, or a FUOTA task.
 */
export declare const resetResourceLogLevel: API.OperationMethod<ResetResourceLogLevelRequest, ResetResourceLogLevelResponse, ResetResourceLogLevelError, Credentials | HttpClient.HttpClient>;
export type SendDataToMulticastGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends the specified data to a multicast group.
 */
export declare const sendDataToMulticastGroup: API.OperationMethod<SendDataToMulticastGroupRequest, SendDataToMulticastGroupResponse, SendDataToMulticastGroupError, Credentials | HttpClient.HttpClient>;
export type SendDataToWirelessDeviceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends a decrypted application data frame to a device.
 */
export declare const sendDataToWirelessDevice: API.OperationMethod<SendDataToWirelessDeviceRequest, SendDataToWirelessDeviceResponse, SendDataToWirelessDeviceError, Credentials | HttpClient.HttpClient>;
export type StartBulkAssociateWirelessDeviceWithMulticastGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a bulk association of all qualifying wireless devices with a multicast
 * group.
 */
export declare const startBulkAssociateWirelessDeviceWithMulticastGroup: API.OperationMethod<StartBulkAssociateWirelessDeviceWithMulticastGroupRequest, StartBulkAssociateWirelessDeviceWithMulticastGroupResponse, StartBulkAssociateWirelessDeviceWithMulticastGroupError, Credentials | HttpClient.HttpClient>;
export type StartBulkDisassociateWirelessDeviceFromMulticastGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a bulk disassociatin of all qualifying wireless devices from a multicast
 * group.
 */
export declare const startBulkDisassociateWirelessDeviceFromMulticastGroup: API.OperationMethod<StartBulkDisassociateWirelessDeviceFromMulticastGroupRequest, StartBulkDisassociateWirelessDeviceFromMulticastGroupResponse, StartBulkDisassociateWirelessDeviceFromMulticastGroupError, Credentials | HttpClient.HttpClient>;
export type StartFuotaTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a FUOTA task.
 */
export declare const startFuotaTask: API.OperationMethod<StartFuotaTaskRequest, StartFuotaTaskResponse, StartFuotaTaskError, Credentials | HttpClient.HttpClient>;
export type StartMulticastGroupSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a multicast group session.
 */
export declare const startMulticastGroupSession: API.OperationMethod<StartMulticastGroupSessionRequest, StartMulticastGroupSessionResponse, StartMulticastGroupSessionError, Credentials | HttpClient.HttpClient>;
export type StartSingleWirelessDeviceImportTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Start import task for a single wireless device.
 */
export declare const startSingleWirelessDeviceImportTask: API.OperationMethod<StartSingleWirelessDeviceImportTaskRequest, StartSingleWirelessDeviceImportTaskResponse, StartSingleWirelessDeviceImportTaskError, Credentials | HttpClient.HttpClient>;
export type StartWirelessDeviceImportTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Start import task for provisioning Sidewalk devices in bulk using an S3 CSV
 * file.
 */
export declare const startWirelessDeviceImportTask: API.OperationMethod<StartWirelessDeviceImportTaskRequest, StartWirelessDeviceImportTaskResponse, StartWirelessDeviceImportTaskError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Adds a tag to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestWirelessDeviceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Simulates a provisioned device by sending an uplink data payload of
 * `Hello`.
 */
export declare const testWirelessDevice: API.OperationMethod<TestWirelessDeviceRequest, TestWirelessDeviceResponse, TestWirelessDeviceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates properties of a destination.
 */
export declare const updateDestination: API.OperationMethod<UpdateDestinationRequest, UpdateDestinationResponse, UpdateDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateEventConfigurationByResourceTypesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the event configuration based on resource types.
 */
export declare const updateEventConfigurationByResourceTypes: API.OperationMethod<UpdateEventConfigurationByResourceTypesRequest, UpdateEventConfigurationByResourceTypesResponse, UpdateEventConfigurationByResourceTypesError, Credentials | HttpClient.HttpClient>;
export type UpdateFuotaTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates properties of a FUOTA task.
 */
export declare const updateFuotaTask: API.OperationMethod<UpdateFuotaTaskRequest, UpdateFuotaTaskResponse, UpdateFuotaTaskError, Credentials | HttpClient.HttpClient>;
export type UpdateLogLevelsByResourceTypesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Set default log level, or log levels by resource types. This can be for wireless
 * device, wireless gateway, or FUOTA task log options, and is used to control the log
 * messages that'll be displayed in CloudWatch.
 */
export declare const updateLogLevelsByResourceTypes: API.OperationMethod<UpdateLogLevelsByResourceTypesRequest, UpdateLogLevelsByResourceTypesResponse, UpdateLogLevelsByResourceTypesError, Credentials | HttpClient.HttpClient>;
export type UpdateMetricConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the summary metric configuration.
 */
export declare const updateMetricConfiguration: API.OperationMethod<UpdateMetricConfigurationRequest, UpdateMetricConfigurationResponse, UpdateMetricConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateMulticastGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates properties of a multicast group session.
 */
export declare const updateMulticastGroup: API.OperationMethod<UpdateMulticastGroupRequest, UpdateMulticastGroupResponse, UpdateMulticastGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateNetworkAnalyzerConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update network analyzer configuration.
 */
export declare const updateNetworkAnalyzerConfiguration: API.OperationMethod<UpdateNetworkAnalyzerConfigurationRequest, UpdateNetworkAnalyzerConfigurationResponse, UpdateNetworkAnalyzerConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdatePartnerAccountError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates properties of a partner account.
 */
export declare const updatePartnerAccount: API.OperationMethod<UpdatePartnerAccountRequest, UpdatePartnerAccountResponse, UpdatePartnerAccountError, Credentials | HttpClient.HttpClient>;
export type UpdatePositionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the position information of a resource.
 *
 * This action is no longer supported. Calls to update the position information
 * should use the UpdateResourcePosition API operation instead.
 */
export declare const updatePosition: API.OperationMethod<UpdatePositionRequest, UpdatePositionResponse, UpdatePositionError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceEventConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the event configuration for a particular resource identifier.
 */
export declare const updateResourceEventConfiguration: API.OperationMethod<UpdateResourceEventConfigurationRequest, UpdateResourceEventConfigurationResponse, UpdateResourceEventConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateResourcePositionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the position information of a given wireless device or a wireless gateway
 * resource. The position coordinates are based on the World Geodetic System
 * (WGS84).
 */
export declare const updateResourcePosition: API.OperationMethod<UpdateResourcePositionRequest, UpdateResourcePositionResponse, UpdateResourcePositionError, Credentials | HttpClient.HttpClient>;
export type UpdateWirelessDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates properties of a wireless device.
 */
export declare const updateWirelessDevice: API.OperationMethod<UpdateWirelessDeviceRequest, UpdateWirelessDeviceResponse, UpdateWirelessDeviceError, Credentials | HttpClient.HttpClient>;
export type UpdateWirelessDeviceImportTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an import task to add more devices to the task.
 */
export declare const updateWirelessDeviceImportTask: API.OperationMethod<UpdateWirelessDeviceImportTaskRequest, UpdateWirelessDeviceImportTaskResponse, UpdateWirelessDeviceImportTaskError, Credentials | HttpClient.HttpClient>;
export type UpdateWirelessGatewayError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates properties of a wireless gateway.
 */
export declare const updateWirelessGateway: API.OperationMethod<UpdateWirelessGatewayRequest, UpdateWirelessGatewayResponse, UpdateWirelessGatewayError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iot-wireless.d.ts.map