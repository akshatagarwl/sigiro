import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ClientException_base: S.Class<ClientException, S.TaggedStruct<"ClientException", {
    readonly clusterName: any;
    readonly nodegroupName: any;
    readonly addonName: any;
    readonly subscriptionId: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClientException extends /*@__PURE__*/ ClientException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly clusterName: any;
    readonly nodegroupName: any;
    readonly fargateProfileName: any;
    readonly addonName: any;
    readonly subscriptionId: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly clusterName: any;
    readonly nodegroupName: any;
    readonly addonName: any;
    readonly subscriptionId: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidStateException_base: S.Class<InvalidStateException, S.TaggedStruct<"InvalidStateException", {
    readonly clusterName: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly clusterName: any;
    readonly nodegroupName: any;
    readonly addonName: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceLimitExceededException_base: S.Class<ResourceLimitExceededException, S.TaggedStruct<"ResourceLimitExceededException", {
    readonly clusterName: any;
    readonly nodegroupName: any;
    readonly subscriptionId: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly clusterName: any;
    readonly nodegroupName: any;
    readonly fargateProfileName: any;
    readonly addonName: any;
    readonly subscriptionId: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourcePropagationDelayException_base: S.Class<ResourcePropagationDelayException, S.TaggedStruct<"ResourcePropagationDelayException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourcePropagationDelayException extends /*@__PURE__*/ ResourcePropagationDelayException_base {
}
declare const ServerException_base: S.Class<ServerException, S.TaggedStruct<"ServerException", {
    readonly clusterName: any;
    readonly nodegroupName: any;
    readonly addonName: any;
    readonly subscriptionId: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServerException extends /*@__PURE__*/ ServerException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly clusterName: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnsupportedAvailabilityZoneException_base: S.Class<UnsupportedAvailabilityZoneException, S.TaggedStruct<"UnsupportedAvailabilityZoneException", {
    readonly message: any;
    readonly clusterName: any;
    readonly nodegroupName: any;
    readonly validZones: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedAvailabilityZoneException extends /*@__PURE__*/ UnsupportedAvailabilityZoneException_base {
}
export interface ActivateCertificateAuthorityRequest {
    clusterName: string;
    certificateAuthorityId: string;
    clientRequestToken?: string;
}
export declare const ActivateCertificateAuthorityRequest: S.Schema<ActivateCertificateAuthorityRequest>;
export type UpdateStatus = "InProgress" | "Failed" | "Cancelled" | "Successful" | (string & {});
export declare const UpdateStatus: any;
export type UpdateType = "VersionUpdate" | "EndpointAccessUpdate" | "LoggingUpdate" | "ConfigUpdate" | "AssociateIdentityProviderConfig" | "DisassociateIdentityProviderConfig" | "AssociateEncryptionConfig" | "AddonUpdate" | "VpcConfigUpdate" | "AccessConfigUpdate" | "UpgradePolicyUpdate" | "ZonalShiftConfigUpdate" | "AutoModeUpdate" | "RemoteNetworkConfigUpdate" | "DeletionProtectionUpdate" | "CapabilityUpdate" | "ControlPlaneScalingConfigUpdate" | "VendedLogsUpdate" | "ControlPlaneEgressUpdate" | "VersionRollback" | "ControlPlaneComponentConfigUpdate" | "CertificateAuthorityUpdate" | (string & {});
export declare const UpdateType: any;
export type UpdateParamType = "Version" | "PlatformVersion" | "EndpointPrivateAccess" | "EndpointPublicAccess" | "ClusterLogging" | "DesiredSize" | "LabelsToAdd" | "LabelsToRemove" | "TaintsToAdd" | "TaintsToRemove" | "MaxSize" | "MinSize" | "ReleaseVersion" | "PublicAccessCidrs" | "LaunchTemplateName" | "LaunchTemplateVersion" | "IdentityProviderConfig" | "EncryptionConfig" | "AddonVersion" | "ServiceAccountRoleArn" | "ResolveConflicts" | "MaxUnavailable" | "MaxUnavailablePercentage" | "NodeRepairEnabled" | "UpdateStrategy" | "ConfigurationValues" | "SecurityGroups" | "Subnets" | "AuthenticationMode" | "PodIdentityAssociations" | "UpgradePolicy" | "ZonalShiftConfig" | "ComputeConfig" | "StorageConfig" | "KubernetesNetworkConfig" | "RemoteNetworkConfig" | "DeletionProtection" | "NodeRepairConfig" | "RoleArn" | "RoleMappingsToAddOrUpdate" | "RoleMappingsToRemove" | "NetworkAccess" | "VendedLogs" | "UpdatedTier" | "PreviousTier" | "WarmPoolEnabled" | "WarmPoolMaxGroupPreparedCapacity" | "WarmPoolMinSize" | "WarmPoolState" | "WarmPoolReuseOnScaleIn" | "ControlPlaneEgressMode" | "KubeApiServerConfig" | "KubeSchedulerConfig" | "KubeControllerManagerConfig" | "ActiveCertificateAuthority" | "TrustedCertificateAuthorities" | "CertificateAuthorityId" | "SigningStatus" | (string & {});
export declare const UpdateParamType: any;
export interface UpdateParam {
    type?: UpdateParamType;
    value?: string;
}
export declare const UpdateParam: S.Schema<UpdateParam>;
export type UpdateParams = UpdateParam[];
export declare const UpdateParams: any;
export type ErrorCode = "SubnetNotFound" | "SecurityGroupNotFound" | "EniLimitReached" | "IpNotAvailable" | "AccessDenied" | "OperationNotPermitted" | "VpcIdNotFound" | "Unknown" | "NodeCreationFailure" | "PodEvictionFailure" | "InsufficientFreeAddresses" | "ClusterUnreachable" | "InsufficientNumberOfReplicas" | "ConfigurationConflict" | "AdmissionRequestDenied" | "UnsupportedAddonModification" | "K8sResourceNotFound" | (string & {});
export declare const ErrorCode: any;
export type StringList = string[];
export declare const StringList: any;
export interface ErrorDetail {
    errorCode?: ErrorCode;
    errorMessage?: string;
    resourceIds?: string[];
}
export declare const ErrorDetail: S.Schema<ErrorDetail>;
export type ErrorDetails = ErrorDetail[];
export declare const ErrorDetails: any;
export type CancellationStatus = "InProgress" | "Failed" | "Successful" | (string & {});
export declare const CancellationStatus: any;
export interface Cancellation {
    status?: CancellationStatus;
    reason?: string;
}
export declare const Cancellation: S.Schema<Cancellation>;
export interface Update {
    id?: string;
    status?: UpdateStatus;
    type?: UpdateType;
    params?: UpdateParam[];
    createdAt?: Date;
    errors?: ErrorDetail[];
    cancellation?: Cancellation;
}
export declare const Update: S.Schema<Update>;
export type CertificateAuthorityCreatedBy = "EKS" | "CUSTOMER" | (string & {});
export declare const CertificateAuthorityCreatedBy: any;
export type CertificateAuthorityActivatedBy = "EKS" | "CUSTOMER" | (string & {});
export declare const CertificateAuthorityActivatedBy: any;
export type CertificateAuthoritySigningStatus = "NOT_USED" | "ACTIVATING" | "IN_USE" | (string & {});
export declare const CertificateAuthoritySigningStatus: any;
export type CertificateAuthorityDistributionStatus = "IN_PROGRESS" | "COMPLETE" | "FAILED" | "DELETING" | (string & {});
export declare const CertificateAuthorityDistributionStatus: any;
export interface CertificateAuthoritySummary {
    id?: string;
    createdAt?: Date;
    createdBy?: CertificateAuthorityCreatedBy;
    activatedAt?: Date;
    activatedBy?: CertificateAuthorityActivatedBy;
    signingStatus?: CertificateAuthoritySigningStatus;
    distributionStatus?: CertificateAuthorityDistributionStatus;
}
export declare const CertificateAuthoritySummary: S.Schema<CertificateAuthoritySummary>;
export interface ActivateCertificateAuthorityResponse {
    update?: Update;
    certificateAuthority?: CertificateAuthoritySummary;
}
export declare const ActivateCertificateAuthorityResponse: S.Schema<ActivateCertificateAuthorityResponse>;
export type AccessScopeType = "cluster" | "namespace" | (string & {});
export declare const AccessScopeType: any;
export interface AccessScope {
    type?: AccessScopeType;
    namespaces?: string[];
}
export declare const AccessScope: S.Schema<AccessScope>;
export interface AssociateAccessPolicyRequest {
    clusterName: string;
    principalArn: string;
    policyArn: string;
    accessScope: AccessScope;
}
export declare const AssociateAccessPolicyRequest: S.Schema<AssociateAccessPolicyRequest>;
export interface AssociatedAccessPolicy {
    policyArn?: string;
    accessScope?: AccessScope;
    associatedAt?: Date;
    modifiedAt?: Date;
}
export declare const AssociatedAccessPolicy: S.Schema<AssociatedAccessPolicy>;
export interface AssociateAccessPolicyResponse {
    clusterName?: string;
    principalArn?: string;
    associatedAccessPolicy?: AssociatedAccessPolicy;
}
export declare const AssociateAccessPolicyResponse: S.Schema<AssociateAccessPolicyResponse>;
export interface Provider {
    keyArn?: string;
}
export declare const Provider: S.Schema<Provider>;
export interface EncryptionConfig {
    resources?: string[];
    provider?: Provider;
}
export declare const EncryptionConfig: S.Schema<EncryptionConfig>;
export type EncryptionConfigList = EncryptionConfig[];
export declare const EncryptionConfigList: any;
export interface AssociateEncryptionConfigRequest {
    clusterName: string;
    encryptionConfig: EncryptionConfig[];
    clientRequestToken?: string;
}
export declare const AssociateEncryptionConfigRequest: S.Schema<AssociateEncryptionConfigRequest>;
export interface AssociateEncryptionConfigResponse {
    update?: Update;
}
export declare const AssociateEncryptionConfigResponse: S.Schema<AssociateEncryptionConfigResponse>;
export type RequiredClaimsKey = string;
export type RequiredClaimsValue = string;
export type RequiredClaimsMap = {
    [key: string]: string | undefined;
};
export declare const RequiredClaimsMap: any;
export interface OidcIdentityProviderConfigRequest {
    identityProviderConfigName: string;
    issuerUrl: string;
    clientId: string;
    usernameClaim?: string;
    usernamePrefix?: string;
    groupsClaim?: string;
    groupsPrefix?: string;
    requiredClaims?: {
        [key: string]: string | undefined;
    };
}
export declare const OidcIdentityProviderConfigRequest: S.Schema<OidcIdentityProviderConfigRequest>;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface AssociateIdentityProviderConfigRequest {
    clusterName: string;
    oidc: OidcIdentityProviderConfigRequest;
    tags?: {
        [key: string]: string | undefined;
    };
    clientRequestToken?: string;
}
export declare const AssociateIdentityProviderConfigRequest: S.Schema<AssociateIdentityProviderConfigRequest>;
export interface AssociateIdentityProviderConfigResponse {
    update?: Update;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const AssociateIdentityProviderConfigResponse: S.Schema<AssociateIdentityProviderConfigResponse>;
export interface CancelUpdateRequest {
    name: string;
    updateId: string;
    clientRequestToken?: string;
}
export declare const CancelUpdateRequest: S.Schema<CancelUpdateRequest>;
export interface CancelUpdateResponse {
    update?: Update;
}
export declare const CancelUpdateResponse: S.Schema<CancelUpdateResponse>;
export interface CreateAccessEntryRequest {
    clusterName: string;
    principalArn: string;
    kubernetesGroups?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
    clientRequestToken?: string;
    username?: string;
    type?: string;
}
export declare const CreateAccessEntryRequest: S.Schema<CreateAccessEntryRequest>;
export interface AccessEntry {
    clusterName?: string;
    principalArn?: string;
    kubernetesGroups?: string[];
    accessEntryArn?: string;
    createdAt?: Date;
    modifiedAt?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    username?: string;
    type?: string;
}
export declare const AccessEntry: S.Schema<AccessEntry>;
export interface CreateAccessEntryResponse {
    accessEntry?: AccessEntry;
}
export declare const CreateAccessEntryResponse: S.Schema<CreateAccessEntryResponse>;
export type ClusterName = string;
export type RoleArn = string;
export type ResolveConflicts = "OVERWRITE" | "NONE" | "PRESERVE" | (string & {});
export declare const ResolveConflicts: any;
export interface AddonPodIdentityAssociations {
    serviceAccount: string;
    roleArn: string;
}
export declare const AddonPodIdentityAssociations: S.Schema<AddonPodIdentityAssociations>;
export type AddonPodIdentityAssociationsList = AddonPodIdentityAssociations[];
export declare const AddonPodIdentityAssociationsList: any;
export type Namespace = string;
export interface AddonNamespaceConfigRequest {
    namespace?: string;
}
export declare const AddonNamespaceConfigRequest: S.Schema<AddonNamespaceConfigRequest>;
export interface CreateAddonRequest {
    clusterName: string;
    addonName: string;
    addonVersion?: string;
    serviceAccountRoleArn?: string;
    resolveConflicts?: ResolveConflicts;
    clientRequestToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    configurationValues?: string;
    podIdentityAssociations?: AddonPodIdentityAssociations[];
    namespaceConfig?: AddonNamespaceConfigRequest;
}
export declare const CreateAddonRequest: S.Schema<CreateAddonRequest>;
export type AddonStatus = "CREATING" | "ACTIVE" | "CREATE_FAILED" | "UPDATING" | "DELETING" | "DELETE_FAILED" | "DEGRADED" | "UPDATE_FAILED" | (string & {});
export declare const AddonStatus: any;
export type AddonIssueCode = "AccessDenied" | "InternalFailure" | "ClusterUnreachable" | "InsufficientNumberOfReplicas" | "ConfigurationConflict" | "AdmissionRequestDenied" | "UnsupportedAddonModification" | "K8sResourceNotFound" | "AddonSubscriptionNeeded" | "AddonPermissionFailure" | (string & {});
export declare const AddonIssueCode: any;
export interface AddonIssue {
    code?: AddonIssueCode;
    message?: string;
    resourceIds?: string[];
}
export declare const AddonIssue: S.Schema<AddonIssue>;
export type AddonIssueList = AddonIssue[];
export declare const AddonIssueList: any;
export interface AddonHealth {
    issues?: AddonIssue[];
}
export declare const AddonHealth: S.Schema<AddonHealth>;
export interface MarketplaceInformation {
    productId?: string;
    productUrl?: string;
}
export declare const MarketplaceInformation: S.Schema<MarketplaceInformation>;
export interface AddonNamespaceConfigResponse {
    namespace?: string;
}
export declare const AddonNamespaceConfigResponse: S.Schema<AddonNamespaceConfigResponse>;
export interface Addon {
    addonName?: string;
    clusterName?: string;
    status?: AddonStatus;
    addonVersion?: string;
    health?: AddonHealth;
    addonArn?: string;
    createdAt?: Date;
    modifiedAt?: Date;
    serviceAccountRoleArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    publisher?: string;
    owner?: string;
    marketplaceInformation?: MarketplaceInformation;
    configurationValues?: string;
    podIdentityAssociations?: string[];
    namespaceConfig?: AddonNamespaceConfigResponse;
}
export declare const Addon: S.Schema<Addon>;
export interface CreateAddonResponse {
    addon?: Addon;
}
export declare const CreateAddonResponse: S.Schema<CreateAddonResponse>;
export type CapabilityType = "ACK" | "KRO" | "ARGOCD" | (string & {});
export declare const CapabilityType: any;
export interface ArgoCdAwsIdcConfigRequest {
    idcInstanceArn: string;
    idcRegion?: string;
}
export declare const ArgoCdAwsIdcConfigRequest: S.Schema<ArgoCdAwsIdcConfigRequest>;
export type ArgoCdRole = "ADMIN" | "EDITOR" | "VIEWER" | (string & {});
export declare const ArgoCdRole: any;
export type SsoIdentityType = "SSO_USER" | "SSO_GROUP" | (string & {});
export declare const SsoIdentityType: any;
export interface SsoIdentity {
    id: string;
    type: SsoIdentityType;
}
export declare const SsoIdentity: S.Schema<SsoIdentity>;
export type SsoIdentityList = SsoIdentity[];
export declare const SsoIdentityList: any;
export interface ArgoCdRoleMapping {
    role: ArgoCdRole;
    identities: SsoIdentity[];
}
export declare const ArgoCdRoleMapping: S.Schema<ArgoCdRoleMapping>;
export type ArgoCdRoleMappingList = ArgoCdRoleMapping[];
export declare const ArgoCdRoleMappingList: any;
export interface ArgoCdNetworkAccessConfigRequest {
    vpceIds?: string[];
}
export declare const ArgoCdNetworkAccessConfigRequest: S.Schema<ArgoCdNetworkAccessConfigRequest>;
export interface ArgoCdConfigRequest {
    namespace?: string;
    awsIdc: ArgoCdAwsIdcConfigRequest;
    rbacRoleMappings?: ArgoCdRoleMapping[];
    networkAccess?: ArgoCdNetworkAccessConfigRequest;
}
export declare const ArgoCdConfigRequest: S.Schema<ArgoCdConfigRequest>;
export interface CapabilityConfigurationRequest {
    argoCd?: ArgoCdConfigRequest;
}
export declare const CapabilityConfigurationRequest: S.Schema<CapabilityConfigurationRequest>;
export type CapabilityDeletePropagationPolicy = "RETAIN" | (string & {});
export declare const CapabilityDeletePropagationPolicy: any;
export interface CreateCapabilityRequest {
    capabilityName: string;
    clusterName: string;
    clientRequestToken?: string;
    type: CapabilityType;
    roleArn: string;
    configuration?: CapabilityConfigurationRequest;
    tags?: {
        [key: string]: string | undefined;
    };
    deletePropagationPolicy: CapabilityDeletePropagationPolicy;
}
export declare const CreateCapabilityRequest: S.Schema<CreateCapabilityRequest>;
export type CapabilityStatus = "CREATING" | "CREATE_FAILED" | "UPDATING" | "DELETING" | "DELETE_FAILED" | "ACTIVE" | "DEGRADED" | (string & {});
export declare const CapabilityStatus: any;
export interface ArgoCdAwsIdcConfigResponse {
    idcInstanceArn?: string;
    idcRegion?: string;
    idcManagedApplicationArn?: string;
}
export declare const ArgoCdAwsIdcConfigResponse: S.Schema<ArgoCdAwsIdcConfigResponse>;
export interface ArgoCdNetworkAccessConfigResponse {
    vpceIds?: string[];
}
export declare const ArgoCdNetworkAccessConfigResponse: S.Schema<ArgoCdNetworkAccessConfigResponse>;
export interface ArgoCdConfigResponse {
    namespace?: string;
    awsIdc?: ArgoCdAwsIdcConfigResponse;
    rbacRoleMappings?: ArgoCdRoleMapping[];
    networkAccess?: ArgoCdNetworkAccessConfigResponse;
    serverUrl?: string;
}
export declare const ArgoCdConfigResponse: S.Schema<ArgoCdConfigResponse>;
export interface CapabilityConfigurationResponse {
    argoCd?: ArgoCdConfigResponse;
}
export declare const CapabilityConfigurationResponse: S.Schema<CapabilityConfigurationResponse>;
export type CapabilityIssueCode = "AccessDenied" | "ClusterUnreachable" | (string & {});
export declare const CapabilityIssueCode: any;
export interface CapabilityIssue {
    code?: CapabilityIssueCode;
    message?: string;
}
export declare const CapabilityIssue: S.Schema<CapabilityIssue>;
export type CapabilityIssueList = CapabilityIssue[];
export declare const CapabilityIssueList: any;
export interface CapabilityHealth {
    issues?: CapabilityIssue[];
}
export declare const CapabilityHealth: S.Schema<CapabilityHealth>;
export interface Capability {
    capabilityName?: string;
    arn?: string;
    clusterName?: string;
    type?: CapabilityType;
    roleArn?: string;
    status?: CapabilityStatus;
    version?: string;
    configuration?: CapabilityConfigurationResponse;
    tags?: {
        [key: string]: string | undefined;
    };
    health?: CapabilityHealth;
    createdAt?: Date;
    modifiedAt?: Date;
    deletePropagationPolicy?: CapabilityDeletePropagationPolicy;
}
export declare const Capability: S.Schema<Capability>;
export interface CreateCapabilityResponse {
    capability?: Capability;
}
export declare const CreateCapabilityResponse: S.Schema<CreateCapabilityResponse>;
export interface CreateCertificateAuthorityRequest {
    clusterName: string;
    clientRequestToken?: string;
}
export declare const CreateCertificateAuthorityRequest: S.Schema<CreateCertificateAuthorityRequest>;
export interface CreateCertificateAuthorityResponse {
    update?: Update;
    certificateAuthority?: CertificateAuthoritySummary;
}
export declare const CreateCertificateAuthorityResponse: S.Schema<CreateCertificateAuthorityResponse>;
export type BoxedBoolean = boolean;
export type ControlPlaneEgressModeType = "AWS_MANAGED" | "CUSTOMER_ROUTED" | "CUSTOMER_ISOLATED" | (string & {});
export declare const ControlPlaneEgressModeType: any;
export interface VpcConfigRequest {
    subnetIds?: string[];
    securityGroupIds?: string[];
    endpointPublicAccess?: boolean;
    endpointPrivateAccess?: boolean;
    publicAccessCidrs?: string[];
    controlPlaneEgressMode?: ControlPlaneEgressModeType;
}
export declare const VpcConfigRequest: S.Schema<VpcConfigRequest>;
export type IpFamily = "ipv4" | "ipv6" | (string & {});
export declare const IpFamily: any;
export interface ElasticLoadBalancing {
    enabled?: boolean;
}
export declare const ElasticLoadBalancing: S.Schema<ElasticLoadBalancing>;
export interface KubernetesNetworkConfigRequest {
    serviceIpv4Cidr?: string;
    ipFamily?: IpFamily;
    elasticLoadBalancing?: ElasticLoadBalancing;
}
export declare const KubernetesNetworkConfigRequest: S.Schema<KubernetesNetworkConfigRequest>;
export type LogType = "api" | "audit" | "authenticator" | "controllerManager" | "scheduler" | (string & {});
export declare const LogType: any;
export type LogTypes = LogType[];
export declare const LogTypes: any;
export interface LogSetup {
    types?: LogType[];
    enabled?: boolean;
}
export declare const LogSetup: S.Schema<LogSetup>;
export type LogSetups = LogSetup[];
export declare const LogSetups: any;
export interface Logging {
    clusterLogging?: LogSetup[];
}
export declare const Logging: S.Schema<Logging>;
export type SpreadLevel = "host" | "rack" | (string & {});
export declare const SpreadLevel: any;
export interface ControlPlanePlacementRequest {
    groupName?: string;
    spreadLevel?: SpreadLevel;
}
export declare const ControlPlanePlacementRequest: S.Schema<ControlPlanePlacementRequest>;
export interface EtcdPlacementRequest {
    spreadLevel?: SpreadLevel;
}
export declare const EtcdPlacementRequest: S.Schema<EtcdPlacementRequest>;
export interface OutpostConfigRequest {
    outpostArns: string[];
    controlPlaneInstanceType: string;
    controlPlanePlacement?: ControlPlanePlacementRequest;
    etcdInstanceType?: string;
    etcdPlacement?: EtcdPlacementRequest;
}
export declare const OutpostConfigRequest: S.Schema<OutpostConfigRequest>;
export type AuthenticationMode = "API" | "API_AND_CONFIG_MAP" | "CONFIG_MAP" | (string & {});
export declare const AuthenticationMode: any;
export interface CreateAccessConfigRequest {
    bootstrapClusterCreatorAdminPermissions?: boolean;
    authenticationMode?: AuthenticationMode;
}
export declare const CreateAccessConfigRequest: S.Schema<CreateAccessConfigRequest>;
export type SupportType = "STANDARD" | "EXTENDED" | (string & {});
export declare const SupportType: any;
export interface UpgradePolicyRequest {
    supportType?: SupportType;
}
export declare const UpgradePolicyRequest: S.Schema<UpgradePolicyRequest>;
export interface ZonalShiftConfigRequest {
    enabled?: boolean;
}
export declare const ZonalShiftConfigRequest: S.Schema<ZonalShiftConfigRequest>;
export interface RemoteNodeNetwork {
    cidrs?: string[];
}
export declare const RemoteNodeNetwork: S.Schema<RemoteNodeNetwork>;
export type RemoteNodeNetworkList = RemoteNodeNetwork[];
export declare const RemoteNodeNetworkList: any;
export interface RemotePodNetwork {
    cidrs?: string[];
}
export declare const RemotePodNetwork: S.Schema<RemotePodNetwork>;
export type RemotePodNetworkList = RemotePodNetwork[];
export declare const RemotePodNetworkList: any;
export interface RemoteNetworkConfigRequest {
    remoteNodeNetworks?: RemoteNodeNetwork[];
    remotePodNetworks?: RemotePodNetwork[];
}
export declare const RemoteNetworkConfigRequest: S.Schema<RemoteNetworkConfigRequest>;
export interface ComputeConfigRequest {
    enabled?: boolean;
    nodePools?: string[];
    nodeRoleArn?: string;
}
export declare const ComputeConfigRequest: S.Schema<ComputeConfigRequest>;
export interface BlockStorage {
    enabled?: boolean;
}
export declare const BlockStorage: S.Schema<BlockStorage>;
export interface StorageConfigRequest {
    blockStorage?: BlockStorage;
}
export declare const StorageConfigRequest: S.Schema<StorageConfigRequest>;
export type ProvisionedControlPlaneTier = "standard" | "tier-xl" | "tier-2xl" | "tier-4xl" | "tier-8xl" | (string & {});
export declare const ProvisionedControlPlaneTier: any;
export interface ControlPlaneScalingConfig {
    tier?: ProvisionedControlPlaneTier;
}
export declare const ControlPlaneScalingConfig: S.Schema<ControlPlaneScalingConfig>;
export interface ServiceNodePortRange {
    minPort?: number;
    maxPort?: number;
}
export declare const ServiceNodePortRange: S.Schema<ServiceNodePortRange>;
export interface KubeApiServerConfigRequest {
    eventTtl?: string;
    serviceNodePortRange?: ServiceNodePortRange;
}
export declare const KubeApiServerConfigRequest: S.Schema<KubeApiServerConfigRequest>;
export type ScoringStrategyType = "LeastAllocated" | "MostAllocated" | (string & {});
export declare const ScoringStrategyType: any;
export type ResourceWeightName = string;
export type ResourceWeightValue = number;
export interface ResourceWeight {
    name?: string;
    weight?: number;
}
export declare const ResourceWeight: S.Schema<ResourceWeight>;
export type ResourceWeightList = ResourceWeight[];
export declare const ResourceWeightList: any;
export interface ScoringStrategy {
    type?: ScoringStrategyType;
    resources?: ResourceWeight[];
}
export declare const ScoringStrategy: S.Schema<ScoringStrategy>;
export interface NodeResourcesFitConfig {
    scoringStrategy?: ScoringStrategy;
}
export declare const NodeResourcesFitConfig: S.Schema<NodeResourcesFitConfig>;
export interface KubeSchedulerConfigRequest {
    nodeResourcesFit?: NodeResourcesFitConfig;
}
export declare const KubeSchedulerConfigRequest: S.Schema<KubeSchedulerConfigRequest>;
export type TerminatedPodGcThresholdValue = number;
export interface PodGcControllerConfigRequest {
    terminatedPodGcThreshold?: number;
}
export declare const PodGcControllerConfigRequest: S.Schema<PodGcControllerConfigRequest>;
export interface HorizontalPodAutoscalerControllerConfigRequest {
    horizontalPodAutoscalerSyncPeriod?: string;
}
export declare const HorizontalPodAutoscalerControllerConfigRequest: S.Schema<HorizontalPodAutoscalerControllerConfigRequest>;
export interface KubeControllerManagerConfigRequest {
    podGcControllerConfig?: PodGcControllerConfigRequest;
    horizontalPodAutoscalerControllerConfig?: HorizontalPodAutoscalerControllerConfigRequest;
}
export declare const KubeControllerManagerConfigRequest: S.Schema<KubeControllerManagerConfigRequest>;
export interface CreateClusterRequest {
    name: string;
    version?: string;
    roleArn: string;
    resourcesVpcConfig: VpcConfigRequest;
    kubernetesNetworkConfig?: KubernetesNetworkConfigRequest;
    logging?: Logging;
    clientRequestToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    encryptionConfig?: EncryptionConfig[];
    outpostConfig?: OutpostConfigRequest;
    accessConfig?: CreateAccessConfigRequest;
    bootstrapSelfManagedAddons?: boolean;
    upgradePolicy?: UpgradePolicyRequest;
    zonalShiftConfig?: ZonalShiftConfigRequest;
    remoteNetworkConfig?: RemoteNetworkConfigRequest;
    computeConfig?: ComputeConfigRequest;
    storageConfig?: StorageConfigRequest;
    deletionProtection?: boolean;
    controlPlaneScalingConfig?: ControlPlaneScalingConfig;
    kubeApiServerConfig?: KubeApiServerConfigRequest;
    kubeSchedulerConfig?: KubeSchedulerConfigRequest;
    kubeControllerManagerConfig?: KubeControllerManagerConfigRequest;
}
export declare const CreateClusterRequest: S.Schema<CreateClusterRequest>;
export interface VpcConfigResponse {
    subnetIds?: string[];
    securityGroupIds?: string[];
    clusterSecurityGroupId?: string;
    vpcId?: string;
    endpointPublicAccess?: boolean;
    endpointPrivateAccess?: boolean;
    publicAccessCidrs?: string[];
    controlPlaneEgressMode?: ControlPlaneEgressModeType;
}
export declare const VpcConfigResponse: S.Schema<VpcConfigResponse>;
export interface KubernetesNetworkConfigResponse {
    serviceIpv4Cidr?: string;
    serviceIpv6Cidr?: string;
    ipFamily?: IpFamily;
    elasticLoadBalancing?: ElasticLoadBalancing;
}
export declare const KubernetesNetworkConfigResponse: S.Schema<KubernetesNetworkConfigResponse>;
export interface OIDC {
    issuer?: string;
}
export declare const OIDC: S.Schema<OIDC>;
export interface Identity {
    oidc?: OIDC;
}
export declare const Identity: S.Schema<Identity>;
export type ClusterStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | "UPDATING" | "PENDING" | (string & {});
export declare const ClusterStatus: any;
export interface ActiveCertificateAuthority {
    id?: string;
    activatedBy?: CertificateAuthorityActivatedBy;
}
export declare const ActiveCertificateAuthority: S.Schema<ActiveCertificateAuthority>;
export interface Certificate {
    data?: string;
    active?: ActiveCertificateAuthority;
}
export declare const Certificate: S.Schema<Certificate>;
export interface ConnectorConfigResponse {
    activationId?: string;
    activationCode?: string;
    activationExpiry?: Date;
    provider?: string;
    roleArn?: string;
}
export declare const ConnectorConfigResponse: S.Schema<ConnectorConfigResponse>;
export type ClusterIssueCode = "AccessDenied" | "ClusterUnreachable" | "ConfigurationConflict" | "InternalFailure" | "ResourceLimitExceeded" | "ResourceNotFound" | "IamRoleNotFound" | "VpcNotFound" | "InsufficientFreeAddresses" | "Ec2ServiceNotSubscribed" | "Ec2SubnetNotFound" | "Ec2SecurityGroupNotFound" | "KmsGrantRevoked" | "KmsKeyNotFound" | "KmsKeyMarkedForDeletion" | "KmsKeyDisabled" | "StsRegionalEndpointDisabled" | "UnsupportedVersion" | "Other" | (string & {});
export declare const ClusterIssueCode: any;
export interface ClusterIssue {
    code?: ClusterIssueCode;
    message?: string;
    resourceIds?: string[];
}
export declare const ClusterIssue: S.Schema<ClusterIssue>;
export type ClusterIssueList = ClusterIssue[];
export declare const ClusterIssueList: any;
export interface ClusterHealth {
    issues?: ClusterIssue[];
}
export declare const ClusterHealth: S.Schema<ClusterHealth>;
export interface ControlPlanePlacementResponse {
    groupName?: string;
    spreadLevel?: SpreadLevel;
}
export declare const ControlPlanePlacementResponse: S.Schema<ControlPlanePlacementResponse>;
export interface EtcdPlacementResponse {
    spreadLevel?: SpreadLevel;
}
export declare const EtcdPlacementResponse: S.Schema<EtcdPlacementResponse>;
export interface OutpostConfigResponse {
    outpostArns: string[];
    controlPlaneInstanceType: string;
    controlPlanePlacement?: ControlPlanePlacementResponse;
    etcdInstanceType?: string;
    etcdPlacement?: EtcdPlacementResponse;
}
export declare const OutpostConfigResponse: S.Schema<OutpostConfigResponse>;
export interface AccessConfigResponse {
    bootstrapClusterCreatorAdminPermissions?: boolean;
    authenticationMode?: AuthenticationMode;
}
export declare const AccessConfigResponse: S.Schema<AccessConfigResponse>;
export interface UpgradePolicyResponse {
    supportType?: SupportType;
}
export declare const UpgradePolicyResponse: S.Schema<UpgradePolicyResponse>;
export interface ZonalShiftConfigResponse {
    enabled?: boolean;
}
export declare const ZonalShiftConfigResponse: S.Schema<ZonalShiftConfigResponse>;
export interface RemoteNetworkConfigResponse {
    remoteNodeNetworks?: RemoteNodeNetwork[];
    remotePodNetworks?: RemotePodNetwork[];
}
export declare const RemoteNetworkConfigResponse: S.Schema<RemoteNetworkConfigResponse>;
export interface ComputeConfigResponse {
    enabled?: boolean;
    nodePools?: string[];
    nodeRoleArn?: string;
}
export declare const ComputeConfigResponse: S.Schema<ComputeConfigResponse>;
export interface StorageConfigResponse {
    blockStorage?: BlockStorage;
}
export declare const StorageConfigResponse: S.Schema<StorageConfigResponse>;
export interface KubeApiServerConfigResponse {
    eventTtl?: string;
    serviceNodePortRange?: ServiceNodePortRange;
}
export declare const KubeApiServerConfigResponse: S.Schema<KubeApiServerConfigResponse>;
export interface KubeSchedulerConfigResponse {
    nodeResourcesFit?: NodeResourcesFitConfig;
}
export declare const KubeSchedulerConfigResponse: S.Schema<KubeSchedulerConfigResponse>;
export interface PodGcControllerConfigResponse {
    terminatedPodGcThreshold?: number;
}
export declare const PodGcControllerConfigResponse: S.Schema<PodGcControllerConfigResponse>;
export interface HorizontalPodAutoscalerControllerConfigResponse {
    horizontalPodAutoscalerSyncPeriod?: string;
}
export declare const HorizontalPodAutoscalerControllerConfigResponse: S.Schema<HorizontalPodAutoscalerControllerConfigResponse>;
export interface KubeControllerManagerConfigResponse {
    podGcControllerConfig?: PodGcControllerConfigResponse;
    horizontalPodAutoscalerControllerConfig?: HorizontalPodAutoscalerControllerConfigResponse;
}
export declare const KubeControllerManagerConfigResponse: S.Schema<KubeControllerManagerConfigResponse>;
export interface Cluster {
    name?: string;
    arn?: string;
    createdAt?: Date;
    version?: string;
    endpoint?: string;
    roleArn?: string;
    resourcesVpcConfig?: VpcConfigResponse;
    kubernetesNetworkConfig?: KubernetesNetworkConfigResponse;
    logging?: Logging;
    identity?: Identity;
    status?: ClusterStatus;
    certificateAuthority?: Certificate;
    clientRequestToken?: string;
    platformVersion?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    encryptionConfig?: EncryptionConfig[];
    connectorConfig?: ConnectorConfigResponse;
    id?: string;
    health?: ClusterHealth;
    outpostConfig?: OutpostConfigResponse;
    accessConfig?: AccessConfigResponse;
    upgradePolicy?: UpgradePolicyResponse;
    zonalShiftConfig?: ZonalShiftConfigResponse;
    remoteNetworkConfig?: RemoteNetworkConfigResponse;
    computeConfig?: ComputeConfigResponse;
    storageConfig?: StorageConfigResponse;
    deletionProtection?: boolean;
    controlPlaneScalingConfig?: ControlPlaneScalingConfig;
    kubeApiServerConfig?: KubeApiServerConfigResponse;
    kubeSchedulerConfig?: KubeSchedulerConfigResponse;
    kubeControllerManagerConfig?: KubeControllerManagerConfigResponse;
}
export declare const Cluster: S.Schema<Cluster>;
export interface CreateClusterResponse {
    cluster?: Cluster;
}
export declare const CreateClusterResponse: S.Schema<CreateClusterResponse>;
export type EksAnywhereSubscriptionName = string;
export type EksAnywhereSubscriptionTermUnit = "MONTHS" | (string & {});
export declare const EksAnywhereSubscriptionTermUnit: any;
export interface EksAnywhereSubscriptionTerm {
    duration?: number;
    unit?: EksAnywhereSubscriptionTermUnit;
}
export declare const EksAnywhereSubscriptionTerm: S.Schema<EksAnywhereSubscriptionTerm>;
export type EksAnywhereSubscriptionLicenseType = "Cluster" | (string & {});
export declare const EksAnywhereSubscriptionLicenseType: any;
export interface CreateEksAnywhereSubscriptionRequest {
    name: string;
    term: EksAnywhereSubscriptionTerm;
    licenseQuantity?: number;
    licenseType?: EksAnywhereSubscriptionLicenseType;
    autoRenew?: boolean;
    clientRequestToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateEksAnywhereSubscriptionRequest: S.Schema<CreateEksAnywhereSubscriptionRequest>;
export interface License {
    id?: string;
    token?: string;
}
export declare const License: S.Schema<License>;
export type LicenseList = License[];
export declare const LicenseList: any;
export interface EksAnywhereSubscription {
    id?: string;
    arn?: string;
    createdAt?: Date;
    effectiveDate?: Date;
    expirationDate?: Date;
    licenseQuantity?: number;
    licenseType?: EksAnywhereSubscriptionLicenseType;
    term?: EksAnywhereSubscriptionTerm;
    status?: string;
    autoRenew?: boolean;
    licenseArns?: string[];
    licenses?: License[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const EksAnywhereSubscription: S.Schema<EksAnywhereSubscription>;
export interface CreateEksAnywhereSubscriptionResponse {
    subscription?: EksAnywhereSubscription;
}
export declare const CreateEksAnywhereSubscriptionResponse: S.Schema<CreateEksAnywhereSubscriptionResponse>;
export type FargateProfileLabel = {
    [key: string]: string | undefined;
};
export declare const FargateProfileLabel: any;
export interface FargateProfileSelector {
    namespace?: string;
    labels?: {
        [key: string]: string | undefined;
    };
}
export declare const FargateProfileSelector: S.Schema<FargateProfileSelector>;
export type FargateProfileSelectors = FargateProfileSelector[];
export declare const FargateProfileSelectors: any;
export interface CreateFargateProfileRequest {
    fargateProfileName: string;
    clusterName: string;
    podExecutionRoleArn: string;
    subnets?: string[];
    selectors?: FargateProfileSelector[];
    clientRequestToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateFargateProfileRequest: S.Schema<CreateFargateProfileRequest>;
export type FargateProfileStatus = "CREATING" | "ACTIVE" | "DELETING" | "CREATE_FAILED" | "DELETE_FAILED" | (string & {});
export declare const FargateProfileStatus: any;
export type FargateProfileIssueCode = "PodExecutionRoleAlreadyInUse" | "AccessDenied" | "ClusterUnreachable" | "InternalFailure" | (string & {});
export declare const FargateProfileIssueCode: any;
export interface FargateProfileIssue {
    code?: FargateProfileIssueCode;
    message?: string;
    resourceIds?: string[];
}
export declare const FargateProfileIssue: S.Schema<FargateProfileIssue>;
export type FargateProfileIssueList = FargateProfileIssue[];
export declare const FargateProfileIssueList: any;
export interface FargateProfileHealth {
    issues?: FargateProfileIssue[];
}
export declare const FargateProfileHealth: S.Schema<FargateProfileHealth>;
export interface FargateProfile {
    fargateProfileName?: string;
    fargateProfileArn?: string;
    clusterName?: string;
    createdAt?: Date;
    podExecutionRoleArn?: string;
    subnets?: string[];
    selectors?: FargateProfileSelector[];
    status?: FargateProfileStatus;
    tags?: {
        [key: string]: string | undefined;
    };
    health?: FargateProfileHealth;
}
export declare const FargateProfile: S.Schema<FargateProfile>;
export interface CreateFargateProfileResponse {
    fargateProfile?: FargateProfile;
}
export declare const CreateFargateProfileResponse: S.Schema<CreateFargateProfileResponse>;
export type ZeroCapacity = number;
export type Capacity = number;
export interface NodegroupScalingConfig {
    minSize?: number;
    maxSize?: number;
    desiredSize?: number;
}
export declare const NodegroupScalingConfig: S.Schema<NodegroupScalingConfig>;
export type BoxedInteger = number;
export type AMITypes = "AL2_x86_64" | "AL2_x86_64_GPU" | "AL2_ARM_64" | "CUSTOM" | "BOTTLEROCKET_ARM_64" | "BOTTLEROCKET_x86_64" | "BOTTLEROCKET_ARM_64_FIPS" | "BOTTLEROCKET_x86_64_FIPS" | "BOTTLEROCKET_ARM_64_NVIDIA" | "BOTTLEROCKET_x86_64_NVIDIA" | "BOTTLEROCKET_ARM_64_NVIDIA_FIPS" | "BOTTLEROCKET_x86_64_NVIDIA_FIPS" | "WINDOWS_CORE_2019_x86_64" | "WINDOWS_FULL_2019_x86_64" | "WINDOWS_CORE_2022_x86_64" | "WINDOWS_FULL_2022_x86_64" | "WINDOWS_CORE_2025_x86_64" | "WINDOWS_FULL_2025_x86_64" | "AL2023_x86_64_STANDARD" | "AL2023_ARM_64_STANDARD" | "AL2023_x86_64_NEURON" | "AL2023_x86_64_NVIDIA" | "AL2023_ARM_64_NVIDIA" | (string & {});
export declare const AMITypes: any;
export interface RemoteAccessConfig {
    ec2SshKey?: string;
    sourceSecurityGroups?: string[];
}
export declare const RemoteAccessConfig: S.Schema<RemoteAccessConfig>;
export type LabelKey = string;
export type LabelValue = string;
export type LabelsMap = {
    [key: string]: string | undefined;
};
export declare const LabelsMap: any;
export type TaintKey = string;
export type TaintValue = string;
export type TaintEffect = "NO_SCHEDULE" | "NO_EXECUTE" | "PREFER_NO_SCHEDULE" | (string & {});
export declare const TaintEffect: any;
export interface Taint {
    key?: string;
    value?: string;
    effect?: TaintEffect;
}
export declare const Taint: S.Schema<Taint>;
export type TaintsList = Taint[];
export declare const TaintsList: any;
export interface LaunchTemplateSpecification {
    name?: string;
    version?: string;
    id?: string;
}
export declare const LaunchTemplateSpecification: S.Schema<LaunchTemplateSpecification>;
export type NonZeroInteger = number;
export type PercentCapacity = number;
export type NodegroupUpdateStrategies = "DEFAULT" | "MINIMAL" | (string & {});
export declare const NodegroupUpdateStrategies: any;
export interface NodegroupUpdateConfig {
    maxUnavailable?: number;
    maxUnavailablePercentage?: number;
    updateStrategy?: NodegroupUpdateStrategies;
}
export declare const NodegroupUpdateConfig: S.Schema<NodegroupUpdateConfig>;
export type RepairAction = "Replace" | "Reboot" | "NoAction" | (string & {});
export declare const RepairAction: any;
export interface NodeRepairConfigOverrides {
    nodeMonitoringCondition?: string;
    nodeUnhealthyReason?: string;
    minRepairWaitTimeMins?: number;
    repairAction?: RepairAction;
}
export declare const NodeRepairConfigOverrides: S.Schema<NodeRepairConfigOverrides>;
export type NodeRepairConfigOverridesList = NodeRepairConfigOverrides[];
export declare const NodeRepairConfigOverridesList: any;
export interface NodeRepairConfig {
    enabled?: boolean;
    maxUnhealthyNodeThresholdCount?: number;
    maxUnhealthyNodeThresholdPercentage?: number;
    maxParallelNodesRepairedCount?: number;
    maxParallelNodesRepairedPercentage?: number;
    nodeRepairConfigOverrides?: NodeRepairConfigOverrides[];
}
export declare const NodeRepairConfig: S.Schema<NodeRepairConfig>;
export type CapacityTypes = "ON_DEMAND" | "SPOT" | "CAPACITY_BLOCK" | (string & {});
export declare const CapacityTypes: any;
export type WarmPoolState = "STOPPED" | "RUNNING" | "HIBERNATED" | (string & {});
export declare const WarmPoolState: any;
export interface WarmPoolConfig {
    enabled?: boolean;
    minSize?: number;
    maxGroupPreparedCapacity?: number;
    poolState?: WarmPoolState;
    reuseOnScaleIn?: boolean;
}
export declare const WarmPoolConfig: S.Schema<WarmPoolConfig>;
export interface CreateNodegroupRequest {
    clusterName: string;
    nodegroupName: string;
    scalingConfig?: NodegroupScalingConfig;
    diskSize?: number;
    subnets: string[];
    instanceTypes?: string[];
    amiType?: AMITypes;
    remoteAccess?: RemoteAccessConfig;
    nodeRole: string;
    labels?: {
        [key: string]: string | undefined;
    };
    taints?: Taint[];
    tags?: {
        [key: string]: string | undefined;
    };
    clientRequestToken?: string;
    launchTemplate?: LaunchTemplateSpecification;
    updateConfig?: NodegroupUpdateConfig;
    nodeRepairConfig?: NodeRepairConfig;
    capacityType?: CapacityTypes;
    version?: string;
    releaseVersion?: string;
    warmPoolConfig?: WarmPoolConfig;
}
export declare const CreateNodegroupRequest: S.Schema<CreateNodegroupRequest>;
export type NodegroupStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "CREATE_FAILED" | "DELETE_FAILED" | "DEGRADED" | (string & {});
export declare const NodegroupStatus: any;
export interface AutoScalingGroup {
    name?: string;
}
export declare const AutoScalingGroup: S.Schema<AutoScalingGroup>;
export type AutoScalingGroupList = AutoScalingGroup[];
export declare const AutoScalingGroupList: any;
export interface NodegroupResources {
    autoScalingGroups?: AutoScalingGroup[];
    remoteAccessSecurityGroup?: string;
}
export declare const NodegroupResources: S.Schema<NodegroupResources>;
export type NodegroupIssueCode = "AutoScalingGroupNotFound" | "AutoScalingGroupInvalidConfiguration" | "Ec2SecurityGroupNotFound" | "Ec2SecurityGroupDeletionFailure" | "Ec2LaunchTemplateNotFound" | "Ec2LaunchTemplateVersionMismatch" | "Ec2SubnetNotFound" | "Ec2SubnetInvalidConfiguration" | "IamInstanceProfileNotFound" | "Ec2SubnetMissingIpv6Assignment" | "IamLimitExceeded" | "IamNodeRoleNotFound" | "NodeCreationFailure" | "AsgInstanceLaunchFailures" | "InstanceLimitExceeded" | "InsufficientFreeAddresses" | "AccessDenied" | "InternalFailure" | "ClusterUnreachable" | "AmiIdNotFound" | "AutoScalingGroupOptInRequired" | "AutoScalingGroupRateLimitExceeded" | "Ec2LaunchTemplateDeletionFailure" | "Ec2LaunchTemplateInvalidConfiguration" | "Ec2LaunchTemplateMaxLimitExceeded" | "Ec2SubnetListTooLong" | "IamThrottling" | "NodeTerminationFailure" | "PodEvictionFailure" | "SourceEc2LaunchTemplateNotFound" | "LimitExceeded" | "Unknown" | "AutoScalingGroupInstanceRefreshActive" | "KubernetesLabelInvalid" | "Ec2LaunchTemplateVersionMaxLimitExceeded" | "Ec2InstanceTypeDoesNotExist" | (string & {});
export declare const NodegroupIssueCode: any;
export interface Issue {
    code?: NodegroupIssueCode;
    message?: string;
    resourceIds?: string[];
}
export declare const Issue: S.Schema<Issue>;
export type IssueList = Issue[];
export declare const IssueList: any;
export interface NodegroupHealth {
    issues?: Issue[];
}
export declare const NodegroupHealth: S.Schema<NodegroupHealth>;
export interface Nodegroup {
    nodegroupName?: string;
    nodegroupArn?: string;
    clusterName?: string;
    version?: string;
    releaseVersion?: string;
    createdAt?: Date;
    modifiedAt?: Date;
    status?: NodegroupStatus;
    capacityType?: CapacityTypes;
    scalingConfig?: NodegroupScalingConfig;
    instanceTypes?: string[];
    subnets?: string[];
    remoteAccess?: RemoteAccessConfig;
    amiType?: AMITypes;
    nodeRole?: string;
    labels?: {
        [key: string]: string | undefined;
    };
    taints?: Taint[];
    resources?: NodegroupResources;
    diskSize?: number;
    health?: NodegroupHealth;
    updateConfig?: NodegroupUpdateConfig;
    nodeRepairConfig?: NodeRepairConfig;
    launchTemplate?: LaunchTemplateSpecification;
    tags?: {
        [key: string]: string | undefined;
    };
    warmPoolConfig?: WarmPoolConfig;
}
export declare const Nodegroup: S.Schema<Nodegroup>;
export interface CreateNodegroupResponse {
    nodegroup?: Nodegroup;
}
export declare const CreateNodegroupResponse: S.Schema<CreateNodegroupResponse>;
export interface CreatePodIdentityAssociationRequest {
    clusterName: string;
    namespace: string;
    serviceAccount: string;
    roleArn: string;
    clientRequestToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    disableSessionTags?: boolean;
    targetRoleArn?: string;
    policy?: string;
}
export declare const CreatePodIdentityAssociationRequest: S.Schema<CreatePodIdentityAssociationRequest>;
export interface PodIdentityAssociation {
    clusterName?: string;
    namespace?: string;
    serviceAccount?: string;
    roleArn?: string;
    associationArn?: string;
    associationId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    createdAt?: Date;
    modifiedAt?: Date;
    ownerArn?: string;
    disableSessionTags?: boolean;
    targetRoleArn?: string;
    externalId?: string;
    policy?: string;
}
export declare const PodIdentityAssociation: S.Schema<PodIdentityAssociation>;
export interface CreatePodIdentityAssociationResponse {
    association?: PodIdentityAssociation;
}
export declare const CreatePodIdentityAssociationResponse: S.Schema<CreatePodIdentityAssociationResponse>;
export interface DeleteAccessEntryRequest {
    clusterName: string;
    principalArn: string;
}
export declare const DeleteAccessEntryRequest: S.Schema<DeleteAccessEntryRequest>;
export interface DeleteAccessEntryResponse {
}
export declare const DeleteAccessEntryResponse: S.Schema<DeleteAccessEntryResponse>;
export interface DeleteAddonRequest {
    clusterName: string;
    addonName: string;
    preserve?: boolean;
}
export declare const DeleteAddonRequest: S.Schema<DeleteAddonRequest>;
export interface DeleteAddonResponse {
    addon?: Addon;
}
export declare const DeleteAddonResponse: S.Schema<DeleteAddonResponse>;
export interface DeleteCapabilityRequest {
    clusterName: string;
    capabilityName: string;
}
export declare const DeleteCapabilityRequest: S.Schema<DeleteCapabilityRequest>;
export interface DeleteCapabilityResponse {
    capability?: Capability;
}
export declare const DeleteCapabilityResponse: S.Schema<DeleteCapabilityResponse>;
export interface DeleteCertificateAuthorityRequest {
    clusterName: string;
    certificateAuthorityId: string;
    clientRequestToken?: string;
}
export declare const DeleteCertificateAuthorityRequest: S.Schema<DeleteCertificateAuthorityRequest>;
export interface DeleteCertificateAuthorityResponse {
    update?: Update;
    certificateAuthority?: CertificateAuthoritySummary;
}
export declare const DeleteCertificateAuthorityResponse: S.Schema<DeleteCertificateAuthorityResponse>;
export interface DeleteClusterRequest {
    name: string;
}
export declare const DeleteClusterRequest: S.Schema<DeleteClusterRequest>;
export interface DeleteClusterResponse {
    cluster?: Cluster;
}
export declare const DeleteClusterResponse: S.Schema<DeleteClusterResponse>;
export interface DeleteEksAnywhereSubscriptionRequest {
    id: string;
}
export declare const DeleteEksAnywhereSubscriptionRequest: S.Schema<DeleteEksAnywhereSubscriptionRequest>;
export interface DeleteEksAnywhereSubscriptionResponse {
    subscription?: EksAnywhereSubscription;
}
export declare const DeleteEksAnywhereSubscriptionResponse: S.Schema<DeleteEksAnywhereSubscriptionResponse>;
export interface DeleteFargateProfileRequest {
    clusterName: string;
    fargateProfileName: string;
}
export declare const DeleteFargateProfileRequest: S.Schema<DeleteFargateProfileRequest>;
export interface DeleteFargateProfileResponse {
    fargateProfile?: FargateProfile;
}
export declare const DeleteFargateProfileResponse: S.Schema<DeleteFargateProfileResponse>;
export interface DeleteNodegroupRequest {
    clusterName: string;
    nodegroupName: string;
}
export declare const DeleteNodegroupRequest: S.Schema<DeleteNodegroupRequest>;
export interface DeleteNodegroupResponse {
    nodegroup?: Nodegroup;
}
export declare const DeleteNodegroupResponse: S.Schema<DeleteNodegroupResponse>;
export interface DeletePodIdentityAssociationRequest {
    clusterName: string;
    associationId: string;
}
export declare const DeletePodIdentityAssociationRequest: S.Schema<DeletePodIdentityAssociationRequest>;
export interface DeletePodIdentityAssociationResponse {
    association?: PodIdentityAssociation;
}
export declare const DeletePodIdentityAssociationResponse: S.Schema<DeletePodIdentityAssociationResponse>;
export interface DeregisterClusterRequest {
    name: string;
}
export declare const DeregisterClusterRequest: S.Schema<DeregisterClusterRequest>;
export interface DeregisterClusterResponse {
    cluster?: Cluster;
}
export declare const DeregisterClusterResponse: S.Schema<DeregisterClusterResponse>;
export interface DescribeAccessEntryRequest {
    clusterName: string;
    principalArn: string;
}
export declare const DescribeAccessEntryRequest: S.Schema<DescribeAccessEntryRequest>;
export interface DescribeAccessEntryResponse {
    accessEntry?: AccessEntry;
}
export declare const DescribeAccessEntryResponse: S.Schema<DescribeAccessEntryResponse>;
export interface DescribeAddonRequest {
    clusterName: string;
    addonName: string;
}
export declare const DescribeAddonRequest: S.Schema<DescribeAddonRequest>;
export interface DescribeAddonResponse {
    addon?: Addon;
}
export declare const DescribeAddonResponse: S.Schema<DescribeAddonResponse>;
export interface DescribeAddonConfigurationRequest {
    addonName: string;
    addonVersion: string;
}
export declare const DescribeAddonConfigurationRequest: S.Schema<DescribeAddonConfigurationRequest>;
export interface AddonPodIdentityConfiguration {
    serviceAccount?: string;
    recommendedManagedPolicies?: string[];
}
export declare const AddonPodIdentityConfiguration: S.Schema<AddonPodIdentityConfiguration>;
export type AddonPodIdentityConfigurationList = AddonPodIdentityConfiguration[];
export declare const AddonPodIdentityConfigurationList: any;
export interface DescribeAddonConfigurationResponse {
    addonName?: string;
    addonVersion?: string;
    configurationSchema?: string;
    podIdentityConfiguration?: AddonPodIdentityConfiguration[];
}
export declare const DescribeAddonConfigurationResponse: S.Schema<DescribeAddonConfigurationResponse>;
export type DescribeAddonVersionsRequestMaxResults = number;
export interface DescribeAddonVersionsRequest {
    kubernetesVersion?: string;
    maxResults?: number;
    nextToken?: string;
    addonName?: string;
    types?: string[];
    publishers?: string[];
    owners?: string[];
}
export declare const DescribeAddonVersionsRequest: S.Schema<DescribeAddonVersionsRequest>;
export interface Compatibility {
    clusterVersion?: string;
    platformVersions?: string[];
    defaultVersion?: boolean;
}
export declare const Compatibility: S.Schema<Compatibility>;
export type Compatibilities = Compatibility[];
export declare const Compatibilities: any;
export interface AddonVersionInfo {
    addonVersion?: string;
    architecture?: string[];
    computeTypes?: string[];
    compatibilities?: Compatibility[];
    requiresConfiguration?: boolean;
    requiresIamPermissions?: boolean;
}
export declare const AddonVersionInfo: S.Schema<AddonVersionInfo>;
export type AddonVersionInfoList = AddonVersionInfo[];
export declare const AddonVersionInfoList: any;
export interface AddonInfo {
    addonName?: string;
    type?: string;
    addonVersions?: AddonVersionInfo[];
    publisher?: string;
    owner?: string;
    marketplaceInformation?: MarketplaceInformation;
    defaultNamespace?: string;
}
export declare const AddonInfo: S.Schema<AddonInfo>;
export type Addons = AddonInfo[];
export declare const Addons: any;
export interface DescribeAddonVersionsResponse {
    addons?: AddonInfo[];
    nextToken?: string;
}
export declare const DescribeAddonVersionsResponse: S.Schema<DescribeAddonVersionsResponse>;
export interface DescribeCapabilityRequest {
    clusterName: string;
    capabilityName: string;
}
export declare const DescribeCapabilityRequest: S.Schema<DescribeCapabilityRequest>;
export interface DescribeCapabilityResponse {
    capability?: Capability;
}
export declare const DescribeCapabilityResponse: S.Schema<DescribeCapabilityResponse>;
export interface DescribeCertificateAuthorityRequest {
    clusterName: string;
    certificateAuthorityId: string;
}
export declare const DescribeCertificateAuthorityRequest: S.Schema<DescribeCertificateAuthorityRequest>;
export interface CertificateAuthorityValidity {
    notBefore?: Date;
    notAfter?: Date;
}
export declare const CertificateAuthorityValidity: S.Schema<CertificateAuthorityValidity>;
export interface CertificateAuthorityScheduledEvents {
    firstAutoActivation?: Date;
    finalAutoActivation?: Date;
}
export declare const CertificateAuthorityScheduledEvents: S.Schema<CertificateAuthorityScheduledEvents>;
export interface CertificateAuthority {
    id?: string;
    createdAt?: Date;
    createdBy?: CertificateAuthorityCreatedBy;
    activatedAt?: Date;
    activatedBy?: CertificateAuthorityActivatedBy;
    signingStatus?: CertificateAuthoritySigningStatus;
    distributionStatus?: CertificateAuthorityDistributionStatus;
    validity?: CertificateAuthorityValidity;
    scheduledEvents?: CertificateAuthorityScheduledEvents;
    rollbackAvailable?: boolean;
    data?: string;
}
export declare const CertificateAuthority: S.Schema<CertificateAuthority>;
export interface DescribeCertificateAuthorityResponse {
    certificateAuthority?: CertificateAuthority;
}
export declare const DescribeCertificateAuthorityResponse: S.Schema<DescribeCertificateAuthorityResponse>;
export interface DescribeClusterRequest {
    name: string;
}
export declare const DescribeClusterRequest: S.Schema<DescribeClusterRequest>;
export interface DescribeClusterResponse {
    cluster?: Cluster;
}
export declare const DescribeClusterResponse: S.Schema<DescribeClusterResponse>;
export type DescribeClusterVersionMaxResults = number;
export type ClusterVersionStatus = "unsupported" | "standard-support" | "extended-support" | (string & {});
export declare const ClusterVersionStatus: any;
export type VersionStatus = "UNSUPPORTED" | "STANDARD_SUPPORT" | "EXTENDED_SUPPORT" | (string & {});
export declare const VersionStatus: any;
export interface DescribeClusterVersionsRequest {
    clusterType?: string;
    maxResults?: number;
    nextToken?: string;
    defaultOnly?: boolean;
    includeAll?: boolean;
    clusterVersions?: string[];
    status?: ClusterVersionStatus;
    versionStatus?: VersionStatus;
}
export declare const DescribeClusterVersionsRequest: S.Schema<DescribeClusterVersionsRequest>;
export interface DurationConstraints {
    min?: string;
    max?: string;
}
export declare const DurationConstraints: S.Schema<DurationConstraints>;
export interface DurationParameterConfig {
    defaultValue?: string;
    constraints?: DurationConstraints;
}
export declare const DurationParameterConfig: S.Schema<DurationParameterConfig>;
export interface IntegerRangeConstraint {
    min?: number;
    max?: number;
}
export declare const IntegerRangeConstraint: S.Schema<IntegerRangeConstraint>;
export interface PortRangeConstraints {
    minPort?: IntegerRangeConstraint;
    maxPort?: IntegerRangeConstraint;
}
export declare const PortRangeConstraints: S.Schema<PortRangeConstraints>;
export interface PortRangeParameterConfig {
    defaultValue?: ServiceNodePortRange;
    constraints?: PortRangeConstraints;
}
export declare const PortRangeParameterConfig: S.Schema<PortRangeParameterConfig>;
export interface KubeApiServerVersionConfig {
    eventTtl?: DurationParameterConfig;
    serviceNodePortRange?: PortRangeParameterConfig;
}
export declare const KubeApiServerVersionConfig: S.Schema<KubeApiServerVersionConfig>;
export type AllowedValuesList = string[];
export declare const AllowedValuesList: any;
export interface AllowedValuesConstraint {
    allowedValues?: string[];
}
export declare const AllowedValuesConstraint: S.Schema<AllowedValuesConstraint>;
export interface ResourceConstraints {
    name?: AllowedValuesConstraint;
    weight?: IntegerRangeConstraint;
}
export declare const ResourceConstraints: S.Schema<ResourceConstraints>;
export interface ScoringStrategyConstraints {
    scoringStrategy?: AllowedValuesConstraint;
    resources?: ResourceConstraints;
}
export declare const ScoringStrategyConstraints: S.Schema<ScoringStrategyConstraints>;
export interface ScoringStrategyConfig {
    defaultValue?: ScoringStrategy;
    constraints?: ScoringStrategyConstraints;
}
export declare const ScoringStrategyConfig: S.Schema<ScoringStrategyConfig>;
export interface NodeResourcesFitVersionConfig {
    scoringStrategy?: ScoringStrategyConfig;
}
export declare const NodeResourcesFitVersionConfig: S.Schema<NodeResourcesFitVersionConfig>;
export interface KubeSchedulerVersionConfig {
    nodeResourcesFit?: NodeResourcesFitVersionConfig;
}
export declare const KubeSchedulerVersionConfig: S.Schema<KubeSchedulerVersionConfig>;
export interface IntegerConstraints {
    min?: number;
    max?: number;
}
export declare const IntegerConstraints: S.Schema<IntegerConstraints>;
export interface IntegerParameterConfig {
    defaultValue?: number;
    constraints?: IntegerConstraints;
}
export declare const IntegerParameterConfig: S.Schema<IntegerParameterConfig>;
export interface PodGcControllerVersionConfig {
    terminatedPodGcThreshold?: IntegerParameterConfig;
}
export declare const PodGcControllerVersionConfig: S.Schema<PodGcControllerVersionConfig>;
export interface HorizontalPodAutoscalerControllerVersionConfig {
    horizontalPodAutoscalerSyncPeriod?: DurationParameterConfig;
}
export declare const HorizontalPodAutoscalerControllerVersionConfig: S.Schema<HorizontalPodAutoscalerControllerVersionConfig>;
export interface KubeControllerManagerVersionConfig {
    podGcControllerConfig?: PodGcControllerVersionConfig;
    horizontalPodAutoscalerControllerConfig?: HorizontalPodAutoscalerControllerVersionConfig;
}
export declare const KubeControllerManagerVersionConfig: S.Schema<KubeControllerManagerVersionConfig>;
export interface ControlPlaneConfigInfo {
    kubeApiServerConfig?: KubeApiServerVersionConfig;
    kubeSchedulerConfig?: KubeSchedulerVersionConfig;
    kubeControllerManagerConfig?: KubeControllerManagerVersionConfig;
}
export declare const ControlPlaneConfigInfo: S.Schema<ControlPlaneConfigInfo>;
export interface ControlPlaneScalingTierInfo {
    tierName?: string;
    apiRequestConcurrency?: number;
    podSchedulingRatePerSecond?: number;
    clusterDatabaseSizeGb?: number;
    controlPlaneComponentConfigOverrides?: ControlPlaneConfigInfo;
}
export declare const ControlPlaneScalingTierInfo: S.Schema<ControlPlaneScalingTierInfo>;
export type ControlPlaneScalingTierList = ControlPlaneScalingTierInfo[];
export declare const ControlPlaneScalingTierList: any;
export interface ClusterVersionInformation {
    clusterVersion?: string;
    clusterType?: string;
    defaultPlatformVersion?: string;
    defaultVersion?: boolean;
    releaseDate?: Date;
    endOfStandardSupportDate?: Date;
    endOfExtendedSupportDate?: Date;
    status?: ClusterVersionStatus;
    versionStatus?: VersionStatus;
    kubernetesPatchVersion?: string;
    controlPlaneScalingTiers?: ControlPlaneScalingTierInfo[];
    controlPlaneComponentConfig?: ControlPlaneConfigInfo;
}
export declare const ClusterVersionInformation: S.Schema<ClusterVersionInformation>;
export type ClusterVersionList = ClusterVersionInformation[];
export declare const ClusterVersionList: any;
export interface DescribeClusterVersionsResponse {
    nextToken?: string;
    clusterVersions?: ClusterVersionInformation[];
}
export declare const DescribeClusterVersionsResponse: S.Schema<DescribeClusterVersionsResponse>;
export interface DescribeEksAnywhereSubscriptionRequest {
    id: string;
}
export declare const DescribeEksAnywhereSubscriptionRequest: S.Schema<DescribeEksAnywhereSubscriptionRequest>;
export interface DescribeEksAnywhereSubscriptionResponse {
    subscription?: EksAnywhereSubscription;
}
export declare const DescribeEksAnywhereSubscriptionResponse: S.Schema<DescribeEksAnywhereSubscriptionResponse>;
export interface DescribeFargateProfileRequest {
    clusterName: string;
    fargateProfileName: string;
}
export declare const DescribeFargateProfileRequest: S.Schema<DescribeFargateProfileRequest>;
export interface DescribeFargateProfileResponse {
    fargateProfile?: FargateProfile;
}
export declare const DescribeFargateProfileResponse: S.Schema<DescribeFargateProfileResponse>;
export interface IdentityProviderConfig {
    type: string;
    name: string;
}
export declare const IdentityProviderConfig: S.Schema<IdentityProviderConfig>;
export interface DescribeIdentityProviderConfigRequest {
    clusterName: string;
    identityProviderConfig: IdentityProviderConfig;
}
export declare const DescribeIdentityProviderConfigRequest: S.Schema<DescribeIdentityProviderConfigRequest>;
export type ConfigStatus = "CREATING" | "DELETING" | "ACTIVE" | (string & {});
export declare const ConfigStatus: any;
export interface OidcIdentityProviderConfig {
    identityProviderConfigName?: string;
    identityProviderConfigArn?: string;
    clusterName?: string;
    issuerUrl?: string;
    clientId?: string;
    usernameClaim?: string;
    usernamePrefix?: string;
    groupsClaim?: string;
    groupsPrefix?: string;
    requiredClaims?: {
        [key: string]: string | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
    status?: ConfigStatus;
}
export declare const OidcIdentityProviderConfig: S.Schema<OidcIdentityProviderConfig>;
export interface IdentityProviderConfigResponse {
    oidc?: OidcIdentityProviderConfig;
}
export declare const IdentityProviderConfigResponse: S.Schema<IdentityProviderConfigResponse>;
export interface DescribeIdentityProviderConfigResponse {
    identityProviderConfig?: IdentityProviderConfigResponse;
}
export declare const DescribeIdentityProviderConfigResponse: S.Schema<DescribeIdentityProviderConfigResponse>;
export interface DescribeInsightRequest {
    clusterName: string;
    id: string;
}
export declare const DescribeInsightRequest: S.Schema<DescribeInsightRequest>;
export type Category = "UPGRADE_READINESS" | "MISCONFIGURATION" | "ROLLBACK_READINESS" | (string & {});
export declare const Category: any;
export type InsightStatusValue = "PASSING" | "WARNING" | "ERROR" | "UNKNOWN" | (string & {});
export declare const InsightStatusValue: any;
export interface InsightStatus {
    status?: InsightStatusValue;
    reason?: string;
}
export declare const InsightStatus: S.Schema<InsightStatus>;
export type AdditionalInfoMap = {
    [key: string]: string | undefined;
};
export declare const AdditionalInfoMap: any;
export interface InsightResourceDetail {
    insightStatus?: InsightStatus;
    kubernetesResourceUri?: string;
    arn?: string;
}
export declare const InsightResourceDetail: S.Schema<InsightResourceDetail>;
export type InsightResourceDetails = InsightResourceDetail[];
export declare const InsightResourceDetails: any;
export interface ClientStat {
    userAgent?: string;
    numberOfRequestsLast30Days?: number;
    lastRequestTime?: Date;
}
export declare const ClientStat: S.Schema<ClientStat>;
export type ClientStats = ClientStat[];
export declare const ClientStats: any;
export interface DeprecationDetail {
    usage?: string;
    replacedWith?: string;
    stopServingVersion?: string;
    startServingReplacementVersion?: string;
    clientStats?: ClientStat[];
}
export declare const DeprecationDetail: S.Schema<DeprecationDetail>;
export type DeprecationDetails = DeprecationDetail[];
export declare const DeprecationDetails: any;
export interface AddonCompatibilityDetail {
    name?: string;
    compatibleVersions?: string[];
}
export declare const AddonCompatibilityDetail: S.Schema<AddonCompatibilityDetail>;
export type AddonCompatibilityDetails = AddonCompatibilityDetail[];
export declare const AddonCompatibilityDetails: any;
export interface InsightCategorySpecificSummary {
    deprecationDetails?: DeprecationDetail[];
    addonCompatibilityDetails?: AddonCompatibilityDetail[];
}
export declare const InsightCategorySpecificSummary: S.Schema<InsightCategorySpecificSummary>;
export interface Insight {
    id?: string;
    name?: string;
    category?: Category;
    kubernetesVersion?: string;
    lastRefreshTime?: Date;
    lastTransitionTime?: Date;
    description?: string;
    insightStatus?: InsightStatus;
    recommendation?: string;
    additionalInfo?: {
        [key: string]: string | undefined;
    };
    resources?: InsightResourceDetail[];
    categorySpecificSummary?: InsightCategorySpecificSummary;
}
export declare const Insight: S.Schema<Insight>;
export interface DescribeInsightResponse {
    insight?: Insight;
}
export declare const DescribeInsightResponse: S.Schema<DescribeInsightResponse>;
export interface DescribeInsightsRefreshRequest {
    clusterName: string;
}
export declare const DescribeInsightsRefreshRequest: S.Schema<DescribeInsightsRefreshRequest>;
export type InsightsRefreshStatus = "IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export declare const InsightsRefreshStatus: any;
export interface DescribeInsightsRefreshResponse {
    message?: string;
    status?: InsightsRefreshStatus;
    startedAt?: Date;
    endedAt?: Date;
}
export declare const DescribeInsightsRefreshResponse: S.Schema<DescribeInsightsRefreshResponse>;
export interface DescribeNodegroupRequest {
    clusterName: string;
    nodegroupName: string;
}
export declare const DescribeNodegroupRequest: S.Schema<DescribeNodegroupRequest>;
export interface DescribeNodegroupResponse {
    nodegroup?: Nodegroup;
}
export declare const DescribeNodegroupResponse: S.Schema<DescribeNodegroupResponse>;
export interface DescribePodIdentityAssociationRequest {
    clusterName: string;
    associationId: string;
}
export declare const DescribePodIdentityAssociationRequest: S.Schema<DescribePodIdentityAssociationRequest>;
export interface DescribePodIdentityAssociationResponse {
    association?: PodIdentityAssociation;
}
export declare const DescribePodIdentityAssociationResponse: S.Schema<DescribePodIdentityAssociationResponse>;
export interface DescribeUpdateRequest {
    name: string;
    updateId: string;
    nodegroupName?: string;
    addonName?: string;
    capabilityName?: string;
}
export declare const DescribeUpdateRequest: S.Schema<DescribeUpdateRequest>;
export interface DescribeUpdateResponse {
    update?: Update;
}
export declare const DescribeUpdateResponse: S.Schema<DescribeUpdateResponse>;
export interface DisassociateAccessPolicyRequest {
    clusterName: string;
    principalArn: string;
    policyArn: string;
}
export declare const DisassociateAccessPolicyRequest: S.Schema<DisassociateAccessPolicyRequest>;
export interface DisassociateAccessPolicyResponse {
}
export declare const DisassociateAccessPolicyResponse: S.Schema<DisassociateAccessPolicyResponse>;
export interface DisassociateIdentityProviderConfigRequest {
    clusterName: string;
    identityProviderConfig: IdentityProviderConfig;
    clientRequestToken?: string;
}
export declare const DisassociateIdentityProviderConfigRequest: S.Schema<DisassociateIdentityProviderConfigRequest>;
export interface DisassociateIdentityProviderConfigResponse {
    update?: Update;
}
export declare const DisassociateIdentityProviderConfigResponse: S.Schema<DisassociateIdentityProviderConfigResponse>;
export type ListAccessEntriesRequestMaxResults = number;
export interface ListAccessEntriesRequest {
    clusterName: string;
    associatedPolicyArn?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAccessEntriesRequest: S.Schema<ListAccessEntriesRequest>;
export interface ListAccessEntriesResponse {
    accessEntries?: string[];
    nextToken?: string;
}
export declare const ListAccessEntriesResponse: S.Schema<ListAccessEntriesResponse>;
export type ListAccessPoliciesRequestMaxResults = number;
export interface ListAccessPoliciesRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAccessPoliciesRequest: S.Schema<ListAccessPoliciesRequest>;
export interface AccessPolicy {
    name?: string;
    arn?: string;
}
export declare const AccessPolicy: S.Schema<AccessPolicy>;
export type AccessPoliciesList = AccessPolicy[];
export declare const AccessPoliciesList: any;
export interface ListAccessPoliciesResponse {
    accessPolicies?: AccessPolicy[];
    nextToken?: string;
}
export declare const ListAccessPoliciesResponse: S.Schema<ListAccessPoliciesResponse>;
export type ListAddonsRequestMaxResults = number;
export interface ListAddonsRequest {
    clusterName: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAddonsRequest: S.Schema<ListAddonsRequest>;
export interface ListAddonsResponse {
    addons?: string[];
    nextToken?: string;
}
export declare const ListAddonsResponse: S.Schema<ListAddonsResponse>;
export type ListAssociatedAccessPoliciesRequestMaxResults = number;
export interface ListAssociatedAccessPoliciesRequest {
    clusterName: string;
    principalArn: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAssociatedAccessPoliciesRequest: S.Schema<ListAssociatedAccessPoliciesRequest>;
export type AssociatedAccessPoliciesList = AssociatedAccessPolicy[];
export declare const AssociatedAccessPoliciesList: any;
export interface ListAssociatedAccessPoliciesResponse {
    clusterName?: string;
    principalArn?: string;
    nextToken?: string;
    associatedAccessPolicies?: AssociatedAccessPolicy[];
}
export declare const ListAssociatedAccessPoliciesResponse: S.Schema<ListAssociatedAccessPoliciesResponse>;
export type ListCapabilitiesRequestMaxResults = number;
export interface ListCapabilitiesRequest {
    clusterName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListCapabilitiesRequest: S.Schema<ListCapabilitiesRequest>;
export interface CapabilitySummary {
    capabilityName?: string;
    arn?: string;
    type?: CapabilityType;
    status?: CapabilityStatus;
    version?: string;
    createdAt?: Date;
    modifiedAt?: Date;
}
export declare const CapabilitySummary: S.Schema<CapabilitySummary>;
export type CapabilitySummaryList = CapabilitySummary[];
export declare const CapabilitySummaryList: any;
export interface ListCapabilitiesResponse {
    capabilities?: CapabilitySummary[];
    nextToken?: string;
}
export declare const ListCapabilitiesResponse: S.Schema<ListCapabilitiesResponse>;
export type CertificateAuthorityMaxResults = number;
export interface ListCertificateAuthoritiesRequest {
    clusterName: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListCertificateAuthoritiesRequest: S.Schema<ListCertificateAuthoritiesRequest>;
export type CertificateAuthoritySummaryList = CertificateAuthoritySummary[];
export declare const CertificateAuthoritySummaryList: any;
export interface ListCertificateAuthoritiesResponse {
    certificateAuthorities?: CertificateAuthoritySummary[];
    nextToken?: string;
}
export declare const ListCertificateAuthoritiesResponse: S.Schema<ListCertificateAuthoritiesResponse>;
export type ListClustersRequestMaxResults = number;
export type IncludeClustersList = string[];
export declare const IncludeClustersList: any;
export interface ListClustersRequest {
    maxResults?: number;
    nextToken?: string;
    include?: string[];
}
export declare const ListClustersRequest: S.Schema<ListClustersRequest>;
export interface ListClustersResponse {
    clusters?: string[];
    nextToken?: string;
}
export declare const ListClustersResponse: S.Schema<ListClustersResponse>;
export type ListEksAnywhereSubscriptionsRequestMaxResults = number;
export type EksAnywhereSubscriptionStatus = "CREATING" | "ACTIVE" | "UPDATING" | "EXPIRING" | "EXPIRED" | "DELETING" | (string & {});
export declare const EksAnywhereSubscriptionStatus: any;
export type EksAnywhereSubscriptionStatusValues = EksAnywhereSubscriptionStatus[];
export declare const EksAnywhereSubscriptionStatusValues: any;
export interface ListEksAnywhereSubscriptionsRequest {
    maxResults?: number;
    nextToken?: string;
    includeStatus?: EksAnywhereSubscriptionStatus[];
}
export declare const ListEksAnywhereSubscriptionsRequest: S.Schema<ListEksAnywhereSubscriptionsRequest>;
export type EksAnywhereSubscriptionList = EksAnywhereSubscription[];
export declare const EksAnywhereSubscriptionList: any;
export interface ListEksAnywhereSubscriptionsResponse {
    subscriptions?: EksAnywhereSubscription[];
    nextToken?: string;
}
export declare const ListEksAnywhereSubscriptionsResponse: S.Schema<ListEksAnywhereSubscriptionsResponse>;
export type FargateProfilesRequestMaxResults = number;
export interface ListFargateProfilesRequest {
    clusterName: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListFargateProfilesRequest: S.Schema<ListFargateProfilesRequest>;
export interface ListFargateProfilesResponse {
    fargateProfileNames?: string[];
    nextToken?: string;
}
export declare const ListFargateProfilesResponse: S.Schema<ListFargateProfilesResponse>;
export type ListIdentityProviderConfigsRequestMaxResults = number;
export interface ListIdentityProviderConfigsRequest {
    clusterName: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListIdentityProviderConfigsRequest: S.Schema<ListIdentityProviderConfigsRequest>;
export type IdentityProviderConfigs = IdentityProviderConfig[];
export declare const IdentityProviderConfigs: any;
export interface ListIdentityProviderConfigsResponse {
    identityProviderConfigs?: IdentityProviderConfig[];
    nextToken?: string;
}
export declare const ListIdentityProviderConfigsResponse: S.Schema<ListIdentityProviderConfigsResponse>;
export type CategoryList = Category[];
export declare const CategoryList: any;
export type InsightStatusValueList = InsightStatusValue[];
export declare const InsightStatusValueList: any;
export interface InsightsFilter {
    categories?: Category[];
    kubernetesVersions?: string[];
    statuses?: InsightStatusValue[];
}
export declare const InsightsFilter: S.Schema<InsightsFilter>;
export type ListInsightsMaxResults = number;
export interface ListInsightsRequest {
    clusterName: string;
    filter?: InsightsFilter;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListInsightsRequest: S.Schema<ListInsightsRequest>;
export interface InsightSummary {
    id?: string;
    name?: string;
    category?: Category;
    kubernetesVersion?: string;
    lastRefreshTime?: Date;
    lastTransitionTime?: Date;
    description?: string;
    insightStatus?: InsightStatus;
}
export declare const InsightSummary: S.Schema<InsightSummary>;
export type InsightSummaries = InsightSummary[];
export declare const InsightSummaries: any;
export interface ListInsightsResponse {
    insights?: InsightSummary[];
    nextToken?: string;
}
export declare const ListInsightsResponse: S.Schema<ListInsightsResponse>;
export type ListNodegroupsRequestMaxResults = number;
export interface ListNodegroupsRequest {
    clusterName: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListNodegroupsRequest: S.Schema<ListNodegroupsRequest>;
export interface ListNodegroupsResponse {
    nodegroups?: string[];
    nextToken?: string;
}
export declare const ListNodegroupsResponse: S.Schema<ListNodegroupsResponse>;
export type ListPodIdentityAssociationsMaxResults = number;
export interface ListPodIdentityAssociationsRequest {
    clusterName: string;
    namespace?: string;
    serviceAccount?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListPodIdentityAssociationsRequest: S.Schema<ListPodIdentityAssociationsRequest>;
export interface PodIdentityAssociationSummary {
    clusterName?: string;
    namespace?: string;
    serviceAccount?: string;
    associationArn?: string;
    associationId?: string;
    ownerArn?: string;
}
export declare const PodIdentityAssociationSummary: S.Schema<PodIdentityAssociationSummary>;
export type PodIdentityAssociationSummaries = PodIdentityAssociationSummary[];
export declare const PodIdentityAssociationSummaries: any;
export interface ListPodIdentityAssociationsResponse {
    associations?: PodIdentityAssociationSummary[];
    nextToken?: string;
}
export declare const ListPodIdentityAssociationsResponse: S.Schema<ListPodIdentityAssociationsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type ListUpdatesRequestMaxResults = number;
export interface ListUpdatesRequest {
    name: string;
    nodegroupName?: string;
    addonName?: string;
    capabilityName?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListUpdatesRequest: S.Schema<ListUpdatesRequest>;
export interface ListUpdatesResponse {
    updateIds?: string[];
    nextToken?: string;
}
export declare const ListUpdatesResponse: S.Schema<ListUpdatesResponse>;
export type ConnectorConfigProvider = "EKS_ANYWHERE" | "ANTHOS" | "GKE" | "AKS" | "OPENSHIFT" | "TANZU" | "RANCHER" | "EC2" | "OTHER" | (string & {});
export declare const ConnectorConfigProvider: any;
export interface ConnectorConfigRequest {
    roleArn: string;
    provider: ConnectorConfigProvider;
}
export declare const ConnectorConfigRequest: S.Schema<ConnectorConfigRequest>;
export interface RegisterClusterRequest {
    name: string;
    connectorConfig: ConnectorConfigRequest;
    clientRequestToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const RegisterClusterRequest: S.Schema<RegisterClusterRequest>;
export interface RegisterClusterResponse {
    cluster?: Cluster;
}
export declare const RegisterClusterResponse: S.Schema<RegisterClusterResponse>;
export interface StartInsightsRefreshRequest {
    clusterName: string;
}
export declare const StartInsightsRefreshRequest: S.Schema<StartInsightsRefreshRequest>;
export interface StartInsightsRefreshResponse {
    message?: string;
    status?: InsightsRefreshStatus;
}
export declare const StartInsightsRefreshResponse: S.Schema<StartInsightsRefreshResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAccessEntryRequest {
    clusterName: string;
    principalArn: string;
    kubernetesGroups?: string[];
    clientRequestToken?: string;
    username?: string;
}
export declare const UpdateAccessEntryRequest: S.Schema<UpdateAccessEntryRequest>;
export interface UpdateAccessEntryResponse {
    accessEntry?: AccessEntry;
}
export declare const UpdateAccessEntryResponse: S.Schema<UpdateAccessEntryResponse>;
export interface UpdateAddonRequest {
    clusterName: string;
    addonName: string;
    addonVersion?: string;
    serviceAccountRoleArn?: string;
    resolveConflicts?: ResolveConflicts;
    clientRequestToken?: string;
    configurationValues?: string;
    podIdentityAssociations?: AddonPodIdentityAssociations[];
}
export declare const UpdateAddonRequest: S.Schema<UpdateAddonRequest>;
export interface UpdateAddonResponse {
    update?: Update;
}
export declare const UpdateAddonResponse: S.Schema<UpdateAddonResponse>;
export interface UpdateRoleMappings {
    addOrUpdateRoleMappings?: ArgoCdRoleMapping[];
    removeRoleMappings?: ArgoCdRoleMapping[];
}
export declare const UpdateRoleMappings: S.Schema<UpdateRoleMappings>;
export interface UpdateArgoCdConfig {
    rbacRoleMappings?: UpdateRoleMappings;
    networkAccess?: ArgoCdNetworkAccessConfigRequest;
}
export declare const UpdateArgoCdConfig: S.Schema<UpdateArgoCdConfig>;
export interface UpdateCapabilityConfiguration {
    argoCd?: UpdateArgoCdConfig;
}
export declare const UpdateCapabilityConfiguration: S.Schema<UpdateCapabilityConfiguration>;
export interface UpdateCapabilityRequest {
    clusterName: string;
    capabilityName: string;
    roleArn?: string;
    configuration?: UpdateCapabilityConfiguration;
    clientRequestToken?: string;
    deletePropagationPolicy?: CapabilityDeletePropagationPolicy;
}
export declare const UpdateCapabilityRequest: S.Schema<UpdateCapabilityRequest>;
export interface UpdateCapabilityResponse {
    update?: Update;
}
export declare const UpdateCapabilityResponse: S.Schema<UpdateCapabilityResponse>;
export interface UpdateAccessConfigRequest {
    authenticationMode?: AuthenticationMode;
}
export declare const UpdateAccessConfigRequest: S.Schema<UpdateAccessConfigRequest>;
export interface UpdateClusterConfigRequest {
    name: string;
    resourcesVpcConfig?: VpcConfigRequest;
    logging?: Logging;
    clientRequestToken?: string;
    accessConfig?: UpdateAccessConfigRequest;
    upgradePolicy?: UpgradePolicyRequest;
    zonalShiftConfig?: ZonalShiftConfigRequest;
    computeConfig?: ComputeConfigRequest;
    kubernetesNetworkConfig?: KubernetesNetworkConfigRequest;
    storageConfig?: StorageConfigRequest;
    remoteNetworkConfig?: RemoteNetworkConfigRequest;
    deletionProtection?: boolean;
    controlPlaneScalingConfig?: ControlPlaneScalingConfig;
    kubeApiServerConfig?: KubeApiServerConfigRequest;
    kubeSchedulerConfig?: KubeSchedulerConfigRequest;
    kubeControllerManagerConfig?: KubeControllerManagerConfigRequest;
}
export declare const UpdateClusterConfigRequest: S.Schema<UpdateClusterConfigRequest>;
export interface UpdateClusterConfigResponse {
    update?: Update;
}
export declare const UpdateClusterConfigResponse: S.Schema<UpdateClusterConfigResponse>;
export interface RollbackConfig {
    timeoutMinutes?: number;
}
export declare const RollbackConfig: S.Schema<RollbackConfig>;
export interface UpdateClusterVersionRequest {
    name: string;
    version: string;
    clientRequestToken?: string;
    force?: boolean;
    rollbackConfig?: RollbackConfig;
}
export declare const UpdateClusterVersionRequest: S.Schema<UpdateClusterVersionRequest>;
export interface UpdateClusterVersionResponse {
    update?: Update;
}
export declare const UpdateClusterVersionResponse: S.Schema<UpdateClusterVersionResponse>;
export interface UpdateEksAnywhereSubscriptionRequest {
    id: string;
    autoRenew: boolean;
    clientRequestToken?: string;
}
export declare const UpdateEksAnywhereSubscriptionRequest: S.Schema<UpdateEksAnywhereSubscriptionRequest>;
export interface UpdateEksAnywhereSubscriptionResponse {
    subscription?: EksAnywhereSubscription;
}
export declare const UpdateEksAnywhereSubscriptionResponse: S.Schema<UpdateEksAnywhereSubscriptionResponse>;
export type LabelsKeyList = string[];
export declare const LabelsKeyList: any;
export interface UpdateLabelsPayload {
    addOrUpdateLabels?: {
        [key: string]: string | undefined;
    };
    removeLabels?: string[];
}
export declare const UpdateLabelsPayload: S.Schema<UpdateLabelsPayload>;
export interface UpdateTaintsPayload {
    addOrUpdateTaints?: Taint[];
    removeTaints?: Taint[];
}
export declare const UpdateTaintsPayload: S.Schema<UpdateTaintsPayload>;
export interface UpdateNodegroupConfigRequest {
    clusterName: string;
    nodegroupName: string;
    labels?: UpdateLabelsPayload;
    taints?: UpdateTaintsPayload;
    scalingConfig?: NodegroupScalingConfig;
    updateConfig?: NodegroupUpdateConfig;
    nodeRepairConfig?: NodeRepairConfig;
    warmPoolConfig?: WarmPoolConfig;
    clientRequestToken?: string;
}
export declare const UpdateNodegroupConfigRequest: S.Schema<UpdateNodegroupConfigRequest>;
export interface UpdateNodegroupConfigResponse {
    update?: Update;
}
export declare const UpdateNodegroupConfigResponse: S.Schema<UpdateNodegroupConfigResponse>;
export interface UpdateNodegroupVersionRequest {
    clusterName: string;
    nodegroupName: string;
    version?: string;
    releaseVersion?: string;
    launchTemplate?: LaunchTemplateSpecification;
    force?: boolean;
    clientRequestToken?: string;
}
export declare const UpdateNodegroupVersionRequest: S.Schema<UpdateNodegroupVersionRequest>;
export interface UpdateNodegroupVersionResponse {
    update?: Update;
}
export declare const UpdateNodegroupVersionResponse: S.Schema<UpdateNodegroupVersionResponse>;
export interface UpdatePodIdentityAssociationRequest {
    clusterName: string;
    associationId: string;
    roleArn?: string;
    clientRequestToken?: string;
    disableSessionTags?: boolean;
    targetRoleArn?: string;
    policy?: string;
}
export declare const UpdatePodIdentityAssociationRequest: S.Schema<UpdatePodIdentityAssociationRequest>;
export interface UpdatePodIdentityAssociationResponse {
    association?: PodIdentityAssociation;
}
export declare const UpdatePodIdentityAssociationResponse: S.Schema<UpdatePodIdentityAssociationResponse>;
export type ActivateCertificateAuthorityError = InvalidParameterException | ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Activates a successor certificate authority (CA) as the signing certificate authority
 * for your cluster, completing a CA rotation.
 *
 * When you activate a successor CA, Amazon EKS promotes it to be the cluster's signer (its
 * `signingStatus` becomes `IN_USE`) and the outgoing CA is
 * retired (`NOT_USED`). The outgoing CA remains in the cluster's trust bundle but
 * no longer signs certificates. The successor CA you activate must already be present on
 * the cluster and fully distributed (its `distributionStatus` must be
 * `COMPLETE`). This is an asynchronous operation that returns an
 * `update` object you can track with
 * `DescribeUpdate`
 * .
 *
 * Before you activate the successor CA, make sure the worker nodes you manage and your
 * external clients have been updated to trust it, so they maintain connectivity to the API
 * server after activation. For a limited period after activation, CA rollback is available
 * to revert to the outgoing CA if needed. If you don't activate the successor CA yourself,
 * Amazon EKS activates it automatically as the expiration deadline approaches. For more
 * information, see Rotate the Amazon EKS
 * cluster certificate authority in the *Amazon EKS User Guide*.
 */
export declare const activateCertificateAuthority: API.OperationMethod<ActivateCertificateAuthorityRequest, ActivateCertificateAuthorityResponse, ActivateCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type AssociateAccessPolicyError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Associates an access policy and its scope to an access entry. For more information
 * about associating access policies, see Associating and disassociating
 * access policies to and from access entries in the *Amazon EKS User Guide*.
 */
export declare const associateAccessPolicy: API.OperationMethod<AssociateAccessPolicyRequest, AssociateAccessPolicyResponse, AssociateAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type AssociateEncryptionConfigError = ClientException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServerException | ThrottlingException | CommonErrors;
/**
 * Associates an encryption configuration to an existing cluster.
 *
 * Use this API to enable encryption on existing clusters that don't already have
 * encryption enabled. This allows you to implement a defense-in-depth security strategy
 * without migrating applications to new Amazon EKS clusters.
 */
export declare const associateEncryptionConfig: API.OperationMethod<AssociateEncryptionConfigRequest, AssociateEncryptionConfigResponse, AssociateEncryptionConfigError, Credentials | HttpClient.HttpClient>;
export type AssociateIdentityProviderConfigError = ClientException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServerException | ThrottlingException | CommonErrors;
/**
 * Associates an identity provider configuration to a cluster.
 *
 * If you want to authenticate identities using an identity provider, you can create an
 * identity provider configuration and associate it to your cluster. After configuring
 * authentication to your cluster you can create Kubernetes `Role` and
 * `ClusterRole` objects, assign permissions to them, and then bind them to
 * the identities using Kubernetes `RoleBinding` and `ClusterRoleBinding`
 * objects. For more information see Using RBAC
 * Authorization in the Kubernetes documentation.
 */
export declare const associateIdentityProviderConfig: API.OperationMethod<AssociateIdentityProviderConfigRequest, AssociateIdentityProviderConfigResponse, AssociateIdentityProviderConfigError, Credentials | HttpClient.HttpClient>;
export type CancelUpdateError = ClientException | InvalidParameterException | InvalidRequestException | InvalidStateException | ResourceInUseException | ResourceNotFoundException | ServerException | ThrottlingException | CommonErrors;
/**
 * Cancels an in-progress update to an Amazon EKS cluster on a best-effort basis. Cancellation
 * is only performed if the update can be cancelled. Currently, this is supported for
 * `VersionRollback` update types on EKS Auto Mode clusters when nodes are
 * rolling back.
 *
 * A successful cancellation stops the node rollback. After cancellation, nodes converge
 * to the current cluster version honoring configured disruption controls. If the control
 * plane rollback has already begun, the cancellation request fails.
 */
export declare const cancelUpdate: API.OperationMethod<CancelUpdateRequest, CancelUpdateResponse, CancelUpdateError, Credentials | HttpClient.HttpClient>;
export type CreateAccessEntryError = InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceLimitExceededException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Creates an access entry.
 *
 * An access entry allows an IAM principal to access your cluster. Access
 * entries can replace the need to maintain entries in the `aws-auth`
 * `ConfigMap` for authentication. You have the following options for
 * authorizing an IAM principal to access Kubernetes objects on your cluster: Kubernetes
 * role-based access control (RBAC), Amazon EKS, or both. Kubernetes RBAC authorization requires you
 * to create and manage Kubernetes `Role`, `ClusterRole`,
 * `RoleBinding`, and `ClusterRoleBinding` objects, in addition
 * to managing access entries. If you use Amazon EKS authorization exclusively, you don't need
 * to create and manage Kubernetes `Role`, `ClusterRole`,
 * `RoleBinding`, and `ClusterRoleBinding` objects.
 *
 * For more information about access entries, see Access entries in the
 * *Amazon EKS User Guide*.
 */
export declare const createAccessEntry: API.OperationMethod<CreateAccessEntryRequest, CreateAccessEntryResponse, CreateAccessEntryError, Credentials | HttpClient.HttpClient>;
export type CreateAddonError = ClientException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Creates an Amazon EKS add-on.
 *
 * Amazon EKS add-ons help to automate the provisioning and lifecycle management of common
 * operational software for Amazon EKS clusters. For more information, see Amazon EKS
 * add-ons in the *Amazon EKS User Guide*.
 */
export declare const createAddon: API.OperationMethod<CreateAddonRequest, CreateAddonResponse, CreateAddonError, Credentials | HttpClient.HttpClient>;
export type CreateCapabilityError = AccessDeniedException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceLimitExceededException | ServerException | ThrottlingException | CommonErrors;
/**
 * Creates a managed capability resource for an Amazon EKS cluster.
 *
 * Capabilities provide fully managed capabilities to build and scale with Kubernetes. When you create a capability, Amazon EKSprovisions and manages the infrastructure required to run the capability outside of your cluster. This approach reduces operational overhead and preserves cluster resources.
 *
 * You can only create one Capability of each type on a given Amazon EKS cluster. Valid types are Argo CD for declarative GitOps deployment, Amazon Web Services Controllers for Kubernetes (ACK) for resource management, and Kube Resource Orchestrator (KRO) for Kubernetes custom resource orchestration.
 *
 * For more information, see EKS Capabilities in the *Amazon EKS User Guide*.
 */
export declare const createCapability: API.OperationMethod<CreateCapabilityRequest, CreateCapabilityResponse, CreateCapabilityError, Credentials | HttpClient.HttpClient>;
export type CreateCertificateAuthorityError = InvalidParameterException | ResourceInUseException | ResourceLimitExceededException | ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Appends a successor certificate authority (CA) to your cluster, beginning the CA
 * rotation process.
 *
 * A cluster certificate authority is the root of trust for your cluster's control plane.
 * It signs the certificates that secure communication between the Kubernetes API server and its
 * clients, and its public certificate is distributed to your cluster's trust bundle so that
 * worker nodes and clients can verify the API server's identity. Each cluster can have at
 * most two certificate authorities at a time: the outgoing CA that's currently signing (its
 * `signingStatus` is `IN_USE`) and one successor CA
 * (`signingStatus` of `NOT_USED`) that you can later activate to
 * complete the rotation.
 *
 * Appending a successor CA adds its public certificate to the cluster's trust bundle so
 * that the cluster trusts both CAs simultaneously (the dual trust period), but it doesn't
 * begin signing certificates. Amazon EKS then distributes the successor CA to the Amazon Web Services managed
 * components in your cluster; you can track this through the CA's
 * `distributionStatus`. The successor CA can't be activated until its
 * `distributionStatus` is `COMPLETE`. To activate it as the
 * cluster's signer, use
 * `ActivateCertificateAuthority`
 * . This is an asynchronous operation
 * that returns an `update` object. If you don't append a successor CA yourself,
 * Amazon EKS appends one automatically before the outgoing CA approaches expiration.
 *
 * For more information, see Rotate the Amazon EKS
 * cluster certificate authority in the *Amazon EKS User Guide*.
 */
export declare const createCertificateAuthority: API.OperationMethod<CreateCertificateAuthorityRequest, CreateCertificateAuthorityResponse, CreateCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type CreateClusterError = ClientException | InvalidParameterException | ResourceInUseException | ResourceLimitExceededException | ServerException | ServiceUnavailableException | UnsupportedAvailabilityZoneException | CommonErrors;
/**
 * Creates an Amazon EKS control plane.
 *
 * The Amazon EKS control plane consists of control plane instances that run the Kubernetes
 * software, such as `etcd` and the API server. The control plane runs in an
 * account managed by Amazon Web Services, and the Kubernetes API is exposed by the Amazon EKS API server endpoint.
 * Each Amazon EKS cluster control plane is single tenant and unique. It runs on its own set of
 * Amazon EC2 instances.
 *
 * The cluster control plane is provisioned across multiple Availability Zones and fronted by an Elastic Load Balancing
 * Network Load Balancer. Amazon EKS also provisions elastic network interfaces in your VPC subnets to provide
 * connectivity from the control plane instances to the nodes (for example, to support
 * `kubectl exec`, `logs`, and `proxy` data
 * flows).
 *
 * Amazon EKS nodes run in your Amazon Web Services account and connect to your cluster's control plane over
 * the Kubernetes API server endpoint and a certificate file that is created for your
 * cluster.
 *
 * You can use the `endpointPublicAccess` and
 * `endpointPrivateAccess` parameters to enable or disable public and
 * private access to your cluster's Kubernetes API server endpoint. By default, public access is
 * enabled, and private access is disabled. The
 * endpoint domain name and IP address family depends on the value of the
 * `ipFamily` for the cluster. For more information, see Amazon EKS Cluster
 * Endpoint Access Control in the
 * *Amazon EKS User Guide*
 * .
 *
 * You can use the `logging` parameter to enable or disable exporting the
 * Kubernetes control plane logs for your cluster to CloudWatch Logs. By default, cluster control plane
 * logs aren't exported to CloudWatch Logs. For more information, see Amazon EKS
 * Cluster Control Plane Logs in the
 *
 * *Amazon EKS User Guide*
 * .
 *
 * CloudWatch Logs ingestion, archive storage, and data scanning rates apply to exported
 * control plane logs. For more information, see CloudWatch Pricing.
 *
 * In most cases, it takes several minutes to create a cluster. After you create an Amazon EKS
 * cluster, you must configure your Kubernetes tooling to communicate with the API server and
 * launch nodes into your cluster. For more information, see Allowing users to
 * access your cluster and Launching Amazon EKS
 * nodes in the *Amazon EKS User Guide*.
 */
export declare const createCluster: API.OperationMethod<CreateClusterRequest, CreateClusterResponse, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateEksAnywhereSubscriptionError = ClientException | InvalidParameterException | ResourceLimitExceededException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Creates an EKS Anywhere subscription. When a subscription is created, it is a contract
 * agreement for the length of the term specified in the request. Licenses that are used to
 * validate support are provisioned in Amazon Web Services License Manager and the caller account is
 * granted access to EKS Anywhere Curated Packages.
 */
export declare const createEksAnywhereSubscription: API.OperationMethod<CreateEksAnywhereSubscriptionRequest, CreateEksAnywhereSubscriptionResponse, CreateEksAnywhereSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateFargateProfileError = ClientException | InvalidParameterException | InvalidRequestException | ResourceLimitExceededException | ServerException | UnsupportedAvailabilityZoneException | ResourceInUseException | CommonErrors;
/**
 * Creates an Fargate profile for your Amazon EKS cluster. You must have at least one
 * Fargate profile in a cluster to be able to run pods on Fargate.
 *
 * The Fargate profile allows an administrator to declare which pods run on Fargate
 * and specify which pods run on which Fargate profile. This declaration is done through
 * the profile's selectors. Each profile can have up to five selectors that contain a
 * namespace and labels. A namespace is required for every selector. The label field
 * consists of multiple optional key-value pairs. Pods that match the selectors are
 * scheduled on Fargate. If a to-be-scheduled pod matches any of the selectors in the
 * Fargate profile, then that pod is run on Fargate.
 *
 * When you create a Fargate profile, you must specify a pod execution role to use with
 * the pods that are scheduled with the profile. This role is added to the cluster's Kubernetes
 * Role
 * Based Access Control (RBAC) for authorization so that the
 * `kubelet` that is running on the Fargate infrastructure can register
 * with your Amazon EKS cluster so that it can appear in your cluster as a node. The pod
 * execution role also provides IAM permissions to the Fargate infrastructure to allow
 * read access to Amazon ECR image repositories. For more information, see Pod
 * Execution Role in the *Amazon EKS User Guide*.
 *
 * Fargate profiles are immutable. However, you can create a new updated profile to
 * replace an existing profile and then delete the original after the updated profile has
 * finished creating.
 *
 * If any Fargate profiles in a cluster are in the `DELETING` status, you
 * must wait for that Fargate profile to finish deleting before you can create any other
 * profiles in that cluster.
 *
 * For more information, see Fargate profile in the *Amazon EKS User Guide*.
 */
export declare const createFargateProfile: API.OperationMethod<CreateFargateProfileRequest, CreateFargateProfileResponse, CreateFargateProfileError, Credentials | HttpClient.HttpClient>;
export type CreateNodegroupError = ClientException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceLimitExceededException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a managed node group for an Amazon EKS cluster.
 *
 * You can only create a node group for your cluster that is equal to the current Kubernetes
 * version for the cluster. All node groups are created with the latest AMI release version
 * for the respective minor Kubernetes version of the cluster, unless you deploy a custom AMI
 * using a launch template.
 *
 * For later updates, you will only be able to update a node group using a launch
 * template only if it was originally deployed with a launch template. Additionally, the
 * launch template ID or name must match what was used when the node group was created. You
 * can update the launch template version with necessary changes. For more information
 * about using launch templates, see Customizing managed nodes with
 * launch templates.
 *
 * An Amazon EKS managed node group is an Amazon EC2 Auto Scaling group and associated Amazon EC2 instances that
 * are managed by Amazon Web Services for an Amazon EKS cluster. For more information, see Managed
 * node groups in the *Amazon EKS User Guide*.
 *
 * Windows AMI types are only supported for commercial Amazon Web Services Regions that support
 * Windows on Amazon EKS.
 */
export declare const createNodegroup: API.OperationMethod<CreateNodegroupRequest, CreateNodegroupResponse, CreateNodegroupError, Credentials | HttpClient.HttpClient>;
export type CreatePodIdentityAssociationError = InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceLimitExceededException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Creates an EKS Pod Identity association between a service account in an Amazon EKS cluster and an IAM role
 * with *EKS Pod Identity*. Use EKS Pod Identity to give temporary IAM credentials to
 * Pods and the credentials are rotated automatically.
 *
 * Amazon EKS Pod Identity associations provide the ability to manage credentials for your applications, similar to the way that Amazon EC2 instance profiles provide credentials to Amazon EC2 instances.
 *
 * If a Pod uses a service account that has an association, Amazon EKS sets environment variables
 * in the containers of the Pod. The environment variables configure the Amazon Web Services SDKs,
 * including the Command Line Interface, to use the EKS Pod Identity credentials.
 *
 * EKS Pod Identity is a simpler method than IAM roles for service
 * accounts, as this method doesn't use OIDC identity providers.
 * Additionally, you can configure a role for EKS Pod Identity once, and reuse it across
 * clusters.
 *
 * Similar to Amazon Web Services IAM behavior, EKS Pod Identity associations are eventually consistent,
 * and may take several seconds to be effective after the initial API call returns
 * successfully. You must design your applications to account for these potential delays.
 * We recommend that you don’t include association create/updates in the
 * critical, high-availability code paths of your application. Instead, make changes in a
 * separate initialization or setup routine that you run less frequently.
 *
 * You can set a *target IAM role* in the same or a different
 * account for advanced scenarios. With a target role, EKS Pod Identity automatically performs two
 * role assumptions in sequence: first assuming the role in the association that is in this
 * account, then using those credentials to assume the target IAM role. This process
 * provides your Pod with temporary credentials that have the permissions defined in the
 * target role, allowing secure access to resources in another Amazon Web Services account.
 */
export declare const createPodIdentityAssociation: API.OperationMethod<CreatePodIdentityAssociationRequest, CreatePodIdentityAssociationResponse, CreatePodIdentityAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessEntryError = InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Deletes an access entry.
 *
 * Deleting an access entry of a type other than `Standard` can cause your
 * cluster to function improperly. If you delete an access entry in error, you can recreate
 * it.
 */
export declare const deleteAccessEntry: API.OperationMethod<DeleteAccessEntryRequest, DeleteAccessEntryResponse, DeleteAccessEntryError, Credentials | HttpClient.HttpClient>;
export type DeleteAddonError = ClientException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Deletes an Amazon EKS add-on.
 *
 * When you remove an add-on, it's deleted from the cluster. You can always manually
 * start an add-on on the cluster using the Kubernetes API.
 */
export declare const deleteAddon: API.OperationMethod<DeleteAddonRequest, DeleteAddonResponse, DeleteAddonError, Credentials | HttpClient.HttpClient>;
export type DeleteCapabilityError = AccessDeniedException | InvalidParameterException | ResourceInUseException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Deletes a managed capability from your Amazon EKS cluster. When you delete a capability, Amazon EKS removes the capability infrastructure but retains all resources that were managed by the capability.
 *
 * Before deleting a capability, you should delete all Kubernetes resources that were created by the capability. After the capability is deleted, these resources become difficult to manage because the controller that managed them is no longer available. To delete resources before removing the capability, use `kubectl delete` or remove them through your GitOps workflow.
 */
export declare const deleteCapability: API.OperationMethod<DeleteCapabilityRequest, DeleteCapabilityResponse, DeleteCapabilityError, Credentials | HttpClient.HttpClient>;
export type DeleteCertificateAuthorityError = InvalidParameterException | ResourceInUseException | ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a certificate authority (CA) from your cluster.
 *
 * Deleting a certificate authority removes its public certificate from the cluster's
 * trust bundle. You can't delete the certificate authority that's currently signing
 * certificates for the cluster (its `signingStatus` is `IN_USE`) — to
 * remove the outgoing CA, first activate the successor CA with
 * `ActivateCertificateAuthority`
 * . Amazon EKS also protects a successor CA
 * from deletion in certain cases to keep a valid rotation path — for example, a successor
 * that Amazon EKS appended can't be deleted while it's the only successor on the cluster. This is
 * an asynchronous operation that returns an `update` object.
 */
export declare const deleteCertificateAuthority: API.OperationMethod<DeleteCertificateAuthorityRequest, DeleteCertificateAuthorityResponse, DeleteCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = ClientException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes an Amazon EKS cluster control plane.
 *
 * If you have active services and ingress resources in your cluster that are associated with a load balancer,
 * you must delete those services before deleting the cluster so that the load balancers
 * are deleted properly. Otherwise, you can have orphaned resources in your VPC that
 * prevent you from being able to delete the VPC. For more information, see Deleting a
 * cluster in the *Amazon EKS User Guide*.
 *
 * If you have managed node groups or Fargate profiles attached to the cluster, you
 * must delete them first. For more information, see `DeleteNodgroup` and
 * `DeleteFargateProfile`.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterRequest, DeleteClusterResponse, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteEksAnywhereSubscriptionError = ClientException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Deletes an expired or inactive subscription. Deleting inactive subscriptions removes
 * them from the Amazon Web Services Management Console view and from list/describe API responses. Subscriptions can
 * only be cancelled within 7 days of creation and are cancelled by creating a ticket in
 * the Amazon Web Services Support Center.
 */
export declare const deleteEksAnywhereSubscription: API.OperationMethod<DeleteEksAnywhereSubscriptionRequest, DeleteEksAnywhereSubscriptionResponse, DeleteEksAnywhereSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteFargateProfileError = ClientException | InvalidParameterException | ResourceNotFoundException | ServerException | ResourceInUseException | CommonErrors;
/**
 * Deletes an Fargate profile.
 *
 * When you delete a Fargate profile, any `Pod` running on Fargate that
 * was created with the profile is deleted. If the `Pod` matches another
 * Fargate profile, then it is scheduled on Fargate with that profile. If it no longer
 * matches any Fargate profiles, then it's not scheduled on Fargate and may remain in a
 * pending state.
 *
 * Only one Fargate profile in a cluster can be in the `DELETING` status at
 * a time. You must wait for a Fargate profile to finish deleting before you can delete
 * any other profiles in that cluster.
 */
export declare const deleteFargateProfile: API.OperationMethod<DeleteFargateProfileRequest, DeleteFargateProfileResponse, DeleteFargateProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteNodegroupError = ClientException | InvalidParameterException | ResourceInUseException | ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a managed node group.
 */
export declare const deleteNodegroup: API.OperationMethod<DeleteNodegroupRequest, DeleteNodegroupResponse, DeleteNodegroupError, Credentials | HttpClient.HttpClient>;
export type DeletePodIdentityAssociationError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Deletes a EKS Pod Identity association.
 *
 * The temporary Amazon Web Services credentials from the previous IAM role session might still be valid until the session expiry. If you need to immediately revoke the temporary session credentials, then go to the role in the IAM console.
 */
export declare const deletePodIdentityAssociation: API.OperationMethod<DeletePodIdentityAssociationRequest, DeletePodIdentityAssociationResponse, DeletePodIdentityAssociationError, Credentials | HttpClient.HttpClient>;
export type DeregisterClusterError = AccessDeniedException | ClientException | ResourceInUseException | ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Deregisters a connected cluster to remove it from the Amazon EKS control plane.
 *
 * A connected cluster is a Kubernetes cluster that you've connected to your control plane
 * using the Amazon EKS Connector.
 */
export declare const deregisterCluster: API.OperationMethod<DeregisterClusterRequest, DeregisterClusterResponse, DeregisterClusterError, Credentials | HttpClient.HttpClient>;
export type DescribeAccessEntryError = InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Describes an access entry.
 */
export declare const describeAccessEntry: API.OperationMethod<DescribeAccessEntryRequest, DescribeAccessEntryResponse, DescribeAccessEntryError, Credentials | HttpClient.HttpClient>;
export type DescribeAddonError = ClientException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Describes an Amazon EKS add-on.
 */
export declare const describeAddon: API.OperationMethod<DescribeAddonRequest, DescribeAddonResponse, DescribeAddonError, Credentials | HttpClient.HttpClient>;
export type DescribeAddonConfigurationError = InvalidParameterException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Returns configuration options.
 */
export declare const describeAddonConfiguration: API.OperationMethod<DescribeAddonConfigurationRequest, DescribeAddonConfigurationResponse, DescribeAddonConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeAddonVersionsError = InvalidParameterException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Describes the versions for an add-on.
 *
 * Information such as the Kubernetes versions that you can use the add-on with, the
 * `owner`, `publisher`, and the `type` of the add-on
 * are returned.
 */
export declare const describeAddonVersions: API.PaginatedOperationMethod<DescribeAddonVersionsRequest, DescribeAddonVersionsResponse, DescribeAddonVersionsError, Credentials | HttpClient.HttpClient, AddonInfo>;
export type DescribeCapabilityError = AccessDeniedException | InvalidParameterException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Returns detailed information about a specific managed capability in your Amazon EKS cluster, including its current status, configuration, health information, and any issues that may be affecting its operation.
 */
export declare const describeCapability: API.OperationMethod<DescribeCapabilityRequest, DescribeCapabilityResponse, DescribeCapabilityError, Credentials | HttpClient.HttpClient>;
export type DescribeCertificateAuthorityError = ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Returns detailed information about a certificate authority (CA) in your cluster,
 * including its validity period, signing and distribution status, provenance, scheduled
 * auto-activation events, and public certificate data.
 */
export declare const describeCertificateAuthority: API.OperationMethod<DescribeCertificateAuthorityRequest, DescribeCertificateAuthorityResponse, DescribeCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterError = ClientException | ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Describes an Amazon EKS cluster.
 *
 * The API server endpoint and certificate authority data returned by this operation are
 * required for `kubelet` and `kubectl` to communicate with your
 * Kubernetes API server. For more information, see Creating or
 * updating a `kubeconfig` file for an Amazon EKS cluster.
 *
 * The API server endpoint and certificate authority data aren't available until the
 * cluster reaches the `ACTIVE` state.
 */
export declare const describeCluster: API.OperationMethod<DescribeClusterRequest, DescribeClusterResponse, DescribeClusterError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterVersionsError = InvalidParameterException | InvalidRequestException | ServerException | CommonErrors;
/**
 * Lists available Kubernetes versions for Amazon EKS clusters.
 */
export declare const describeClusterVersions: API.PaginatedOperationMethod<DescribeClusterVersionsRequest, DescribeClusterVersionsResponse, DescribeClusterVersionsError, Credentials | HttpClient.HttpClient, ClusterVersionInformation>;
export type DescribeEksAnywhereSubscriptionError = ClientException | ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Returns descriptive information about a subscription.
 */
export declare const describeEksAnywhereSubscription: API.OperationMethod<DescribeEksAnywhereSubscriptionRequest, DescribeEksAnywhereSubscriptionResponse, DescribeEksAnywhereSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DescribeFargateProfileError = ClientException | InvalidParameterException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Describes an Fargate profile.
 */
export declare const describeFargateProfile: API.OperationMethod<DescribeFargateProfileRequest, DescribeFargateProfileResponse, DescribeFargateProfileError, Credentials | HttpClient.HttpClient>;
export type DescribeIdentityProviderConfigError = ClientException | InvalidParameterException | ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Describes an identity provider configuration.
 */
export declare const describeIdentityProviderConfig: API.OperationMethod<DescribeIdentityProviderConfigRequest, DescribeIdentityProviderConfigResponse, DescribeIdentityProviderConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeInsightError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Returns details about an insight that you specify using its ID.
 */
export declare const describeInsight: API.OperationMethod<DescribeInsightRequest, DescribeInsightResponse, DescribeInsightError, Credentials | HttpClient.HttpClient>;
export type DescribeInsightsRefreshError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Returns the status of the latest on-demand cluster insights refresh operation.
 */
export declare const describeInsightsRefresh: API.OperationMethod<DescribeInsightsRefreshRequest, DescribeInsightsRefreshResponse, DescribeInsightsRefreshError, Credentials | HttpClient.HttpClient>;
export type DescribeNodegroupError = ClientException | InvalidParameterException | ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Describes a managed node group.
 */
export declare const describeNodegroup: API.OperationMethod<DescribeNodegroupRequest, DescribeNodegroupResponse, DescribeNodegroupError, Credentials | HttpClient.HttpClient>;
export type DescribePodIdentityAssociationError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Returns descriptive information about an EKS Pod Identity association.
 *
 * This action requires the ID of the association. You can get the ID from the response to
 * the `CreatePodIdentityAssocation` for newly created associations. Or, you can
 * list the IDs for associations with `ListPodIdentityAssociations` and filter the
 * list by namespace or service account.
 */
export declare const describePodIdentityAssociation: API.OperationMethod<DescribePodIdentityAssociationRequest, DescribePodIdentityAssociationResponse, DescribePodIdentityAssociationError, Credentials | HttpClient.HttpClient>;
export type DescribeUpdateError = ClientException | InvalidParameterException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Describes an update to an Amazon EKS resource.
 *
 * When the status of the update is `Successful`, the update is complete. If
 * an update fails, the status is `Failed`, and an error detail explains the
 * reason for the failure.
 */
export declare const describeUpdate: API.OperationMethod<DescribeUpdateRequest, DescribeUpdateResponse, DescribeUpdateError, Credentials | HttpClient.HttpClient>;
export type DisassociateAccessPolicyError = InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Disassociates an access policy from an access entry.
 */
export declare const disassociateAccessPolicy: API.OperationMethod<DisassociateAccessPolicyRequest, DisassociateAccessPolicyResponse, DisassociateAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type DisassociateIdentityProviderConfigError = ClientException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServerException | ThrottlingException | CommonErrors;
/**
 * Disassociates an identity provider configuration from a cluster.
 *
 * If you disassociate an identity provider from your cluster, users included in the
 * provider can no longer access the cluster. However, you can still access the cluster
 * with IAM principals.
 */
export declare const disassociateIdentityProviderConfig: API.OperationMethod<DisassociateIdentityProviderConfigRequest, DisassociateIdentityProviderConfigResponse, DisassociateIdentityProviderConfigError, Credentials | HttpClient.HttpClient>;
export type ListAccessEntriesError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Lists the access entries for your cluster.
 */
export declare const listAccessEntries: API.PaginatedOperationMethod<ListAccessEntriesRequest, ListAccessEntriesResponse, ListAccessEntriesError, Credentials | HttpClient.HttpClient, string>;
export type ListAccessPoliciesError = ServerException | CommonErrors;
/**
 * Lists the available access policies.
 */
export declare const listAccessPolicies: API.PaginatedOperationMethod<ListAccessPoliciesRequest, ListAccessPoliciesResponse, ListAccessPoliciesError, Credentials | HttpClient.HttpClient, AccessPolicy>;
export type ListAddonsError = ClientException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Lists the installed add-ons.
 */
export declare const listAddons: API.PaginatedOperationMethod<ListAddonsRequest, ListAddonsResponse, ListAddonsError, Credentials | HttpClient.HttpClient, string>;
export type ListAssociatedAccessPoliciesError = InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Lists the access policies associated with an access entry.
 */
export declare const listAssociatedAccessPolicies: API.PaginatedOperationMethod<ListAssociatedAccessPoliciesRequest, ListAssociatedAccessPoliciesResponse, ListAssociatedAccessPoliciesError, Credentials | HttpClient.HttpClient, AssociatedAccessPolicy>;
export type ListCapabilitiesError = InvalidParameterException | ServerException | CommonErrors;
/**
 * Lists all managed capabilities in your Amazon EKS cluster. You can use this operation to get an overview of all capabilities and their current status.
 */
export declare const listCapabilities: API.PaginatedOperationMethod<ListCapabilitiesRequest, ListCapabilitiesResponse, ListCapabilitiesError, Credentials | HttpClient.HttpClient, CapabilitySummary>;
export type ListCertificateAuthoritiesError = InvalidParameterException | ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the certificate authorities (CAs) for your cluster. A cluster has at most two
 * certificate authorities: the outgoing CA that's currently signing and, during a rotation,
 * one successor CA.
 */
export declare const listCertificateAuthorities: API.PaginatedOperationMethod<ListCertificateAuthoritiesRequest, ListCertificateAuthoritiesResponse, ListCertificateAuthoritiesError, Credentials | HttpClient.HttpClient, CertificateAuthoritySummary>;
export type ListClustersError = ClientException | InvalidParameterException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the Amazon EKS clusters in your Amazon Web Services account in the specified Amazon Web Services Region.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersRequest, ListClustersResponse, ListClustersError, Credentials | HttpClient.HttpClient, string>;
export type ListEksAnywhereSubscriptionsError = ClientException | InvalidParameterException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Displays the full description of the subscription.
 */
export declare const listEksAnywhereSubscriptions: API.PaginatedOperationMethod<ListEksAnywhereSubscriptionsRequest, ListEksAnywhereSubscriptionsResponse, ListEksAnywhereSubscriptionsError, Credentials | HttpClient.HttpClient, EksAnywhereSubscription>;
export type ListFargateProfilesError = ClientException | InvalidParameterException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Lists the Fargate profiles associated with the specified cluster in your Amazon Web Services
 * account in the specified Amazon Web Services Region.
 */
export declare const listFargateProfiles: API.PaginatedOperationMethod<ListFargateProfilesRequest, ListFargateProfilesResponse, ListFargateProfilesError, Credentials | HttpClient.HttpClient, string>;
export type ListIdentityProviderConfigsError = ClientException | InvalidParameterException | ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the identity provider configurations for your cluster.
 */
export declare const listIdentityProviderConfigs: API.PaginatedOperationMethod<ListIdentityProviderConfigsRequest, ListIdentityProviderConfigsResponse, ListIdentityProviderConfigsError, Credentials | HttpClient.HttpClient, IdentityProviderConfig>;
export type ListInsightsError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Returns a list of all insights checked for against the specified cluster. You can
 * filter which insights are returned by category, associated Kubernetes version, and
 * status. The default filter lists all categories and every status.
 *
 * The following lists the available categories:
 *
 * - `UPGRADE_READINESS`: Amazon EKS identifies issues that could impact your
 * ability to upgrade to new versions of Kubernetes. These are called upgrade insights.
 *
 * - `MISCONFIGURATION`: Amazon EKS identifies misconfiguration in your EKS
 * Hybrid Nodes setup that could impair functionality of your cluster or
 * workloads. These are called configuration insights.
 */
export declare const listInsights: API.PaginatedOperationMethod<ListInsightsRequest, ListInsightsResponse, ListInsightsError, Credentials | HttpClient.HttpClient, InsightSummary>;
export type ListNodegroupsError = ClientException | InvalidParameterException | ResourceNotFoundException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the managed node groups associated with the specified cluster in your Amazon Web Services
 * account in the specified Amazon Web Services Region. Self-managed node groups aren't listed.
 */
export declare const listNodegroups: API.PaginatedOperationMethod<ListNodegroupsRequest, ListNodegroupsResponse, ListNodegroupsError, Credentials | HttpClient.HttpClient, string>;
export type ListPodIdentityAssociationsError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * List the EKS Pod Identity associations in a cluster. You can filter the list by the namespace that the
 * association is in or the service account that the association uses.
 */
export declare const listPodIdentityAssociations: API.PaginatedOperationMethod<ListPodIdentityAssociationsRequest, ListPodIdentityAssociationsResponse, ListPodIdentityAssociationsError, Credentials | HttpClient.HttpClient, PodIdentityAssociationSummary>;
export type ListTagsForResourceError = BadRequestException | NotFoundException | CommonErrors;
/**
 * List the tags for an Amazon EKS resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListUpdatesError = ClientException | InvalidParameterException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Lists the updates associated with an Amazon EKS resource in your Amazon Web Services account, in the
 * specified Amazon Web Services Region.
 */
export declare const listUpdates: API.PaginatedOperationMethod<ListUpdatesRequest, ListUpdatesResponse, ListUpdatesError, Credentials | HttpClient.HttpClient, string>;
export type RegisterClusterError = AccessDeniedException | ClientException | InvalidParameterException | ResourceInUseException | ResourceLimitExceededException | ResourcePropagationDelayException | ServerException | ServiceUnavailableException | CommonErrors;
/**
 * Connects a Kubernetes cluster to the Amazon EKS control plane.
 *
 * Any Kubernetes cluster can be connected to the Amazon EKS control plane to view current
 * information about the cluster and its nodes.
 *
 * Cluster connection requires two steps. First, send a
 * `RegisterClusterRequest`
 * to add it to the Amazon EKS control
 * plane.
 *
 * Second, a Manifest containing the `activationID` and
 * `activationCode` must be applied to the Kubernetes cluster through it's native
 * provider to provide visibility.
 *
 * After the manifest is updated and applied, the connected cluster is visible to the
 * Amazon EKS control plane. If the manifest isn't applied within three days, the connected
 * cluster will no longer be visible and must be deregistered using
 * `DeregisterCluster`.
 */
export declare const registerCluster: API.OperationMethod<RegisterClusterRequest, RegisterClusterResponse, RegisterClusterError, Credentials | HttpClient.HttpClient>;
export type StartInsightsRefreshError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Initiates an on-demand refresh operation for cluster insights, getting the latest analysis outside of the standard refresh schedule.
 */
export declare const startInsightsRefresh: API.OperationMethod<StartInsightsRefreshRequest, StartInsightsRefreshResponse, StartInsightsRefreshError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | NotFoundException | CommonErrors;
/**
 * Associates the specified tags to an Amazon EKS resource with the specified
 * `resourceArn`. If existing tags on a resource are not specified in the
 * request parameters, they aren't changed. When a resource is deleted, the tags associated
 * with that resource are also deleted. Tags that you create for Amazon EKS resources don't
 * propagate to any other resources associated with the cluster. For example, if you tag a
 * cluster with this operation, that tag doesn't automatically propagate to the subnets and
 * nodes associated with the cluster.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | NotFoundException | CommonErrors;
/**
 * Deletes specified tags from an Amazon EKS resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccessEntryError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Updates an access entry.
 */
export declare const updateAccessEntry: API.OperationMethod<UpdateAccessEntryRequest, UpdateAccessEntryResponse, UpdateAccessEntryError, Credentials | HttpClient.HttpClient>;
export type UpdateAddonError = ClientException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Updates an Amazon EKS add-on.
 */
export declare const updateAddon: API.OperationMethod<UpdateAddonRequest, UpdateAddonResponse, UpdateAddonError, Credentials | HttpClient.HttpClient>;
export type UpdateCapabilityError = AccessDeniedException | InvalidParameterException | ResourceInUseException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Updates the configuration of a managed capability in your Amazon EKS cluster. You can update the IAM role, configuration settings, and delete propagation policy for a capability.
 *
 * When you update a capability, Amazon EKS applies the changes and may restart capability components as needed. The capability remains available during the update process, but some operations may be temporarily unavailable.
 */
export declare const updateCapability: API.OperationMethod<UpdateCapabilityRequest, UpdateCapabilityResponse, UpdateCapabilityError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterConfigError = ClientException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServerException | ThrottlingException | CommonErrors;
/**
 * Updates an Amazon EKS cluster configuration. Your cluster continues to function during the
 * update. The response output includes an update ID that you can use to track the status
 * of your cluster update with `DescribeUpdate`.
 *
 * You can use this operation to do the following actions:
 *
 * - You can use this API operation to enable or disable exporting the Kubernetes
 * control plane logs for your cluster to CloudWatch Logs. By default, cluster control plane
 * logs aren't exported to CloudWatch Logs. For more information, see Amazon EKS Cluster control plane logs in the
 *
 * *Amazon EKS User Guide*
 * .
 *
 * CloudWatch Logs ingestion, archive storage, and data scanning rates apply to
 * exported control plane logs. For more information, see CloudWatch Pricing.
 *
 * - You can also use this API operation to enable or disable public and private
 * access to your cluster's Kubernetes API server endpoint. By default, public access is
 * enabled, and private access is disabled. For more information, see
 * Cluster API server endpoint in the
 *
 * *Amazon EKS User Guide*
 * .
 *
 * - You can also use this API operation to choose different subnets and security
 * groups for the cluster. You must specify at least two subnets that are in
 * different Availability Zones. You can't change which VPC the subnets are from, the subnets
 * must be in the same VPC as the subnets that the cluster was created with. For
 * more information about the VPC requirements, see https://docs.aws.amazon.com/eks/latest/userguide/network_reqs.html in the
 *
 * *Amazon EKS User Guide*
 * .
 *
 * - You can also use this API operation to enable or disable ARC zonal shift. If
 * zonal shift is enabled, Amazon Web Services configures zonal autoshift for the cluster.
 *
 * - You can also use this API operation to add, change, or remove the
 * configuration in the cluster for EKS Hybrid Nodes. To remove the configuration,
 * use the `remoteNetworkConfig` key with an object containing both
 * subkeys with empty arrays for each. Here is an inline example:
 * "remoteNetworkConfig": { "remoteNodeNetworks": [],
 * "remotePodNetworks": [] }.
 *
 * Cluster updates are asynchronous, and they should finish within a few minutes. During
 * an update, the cluster status moves to `UPDATING` (this status transition is
 * eventually consistent). When the update is complete (either `Failed` or
 * `Successful`), the cluster status moves to `Active`.
 */
export declare const updateClusterConfig: API.OperationMethod<UpdateClusterConfigRequest, UpdateClusterConfigResponse, UpdateClusterConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterVersionError = ClientException | InvalidParameterException | InvalidRequestException | InvalidStateException | ResourceInUseException | ResourceNotFoundException | ServerException | ThrottlingException | CommonErrors;
/**
 * Updates an Amazon EKS cluster to the specified Kubernetes version. Your cluster continues to
 * function during the update. The response output includes an update ID that you can use
 * to track the status of your cluster update with the
 * `DescribeUpdate`
 * API operation.
 *
 * Cluster updates are asynchronous, and they should finish within a few minutes. During
 * an update, the cluster status moves to `UPDATING` (this status transition is
 * eventually consistent). When the update is complete (either `Failed` or
 * `Successful`), the cluster status moves to `Active`.
 *
 * If your cluster has managed node groups attached to it, all of your node groups' Kubernetes
 * versions must match the cluster's Kubernetes version in order to update the cluster to a new
 * Kubernetes version.
 */
export declare const updateClusterVersion: API.OperationMethod<UpdateClusterVersionRequest, UpdateClusterVersionResponse, UpdateClusterVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateEksAnywhereSubscriptionError = ClientException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Update an EKS Anywhere Subscription. Only auto renewal and tags can be updated after
 * subscription creation.
 */
export declare const updateEksAnywhereSubscription: API.OperationMethod<UpdateEksAnywhereSubscriptionRequest, UpdateEksAnywhereSubscriptionResponse, UpdateEksAnywhereSubscriptionError, Credentials | HttpClient.HttpClient>;
export type UpdateNodegroupConfigError = ClientException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Updates an Amazon EKS managed node group configuration. Your node group continues to
 * function during the update. The response output includes an update ID that you can use
 * to track the status of your node group update with the
 * `DescribeUpdate`
 * API operation. You can update the Kubernetes labels
 * and taints for a node group and the scaling and version update configuration.
 */
export declare const updateNodegroupConfig: API.OperationMethod<UpdateNodegroupConfigRequest, UpdateNodegroupConfigResponse, UpdateNodegroupConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateNodegroupVersionError = ClientException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Updates the Kubernetes version or AMI version of an Amazon EKS managed node group.
 *
 * You can update a node group using a launch template only if the node group was
 * originally deployed with a launch template. Additionally, the launch template ID or name
 * must match what was used when the node group was created. You can update the launch
 * template version with necessary changes.
 *
 * If you need to update a custom AMI in a node group that was deployed with a launch
 * template, then update your custom AMI, specify the new ID in a new version of the launch
 * template, and then update the node group to the new version of the launch
 * template.
 *
 * If you update without a launch template, then you can update to the latest available
 * AMI version of a node group's current Kubernetes version by not specifying a Kubernetes version in
 * the request. You can update to the latest AMI version of your cluster's current Kubernetes
 * version by specifying your cluster's Kubernetes version in the request. For information about
 * Linux versions, see Amazon EKS optimized Amazon Linux AMI versions in the
 * *Amazon EKS User Guide*. For information about Windows versions, see Amazon EKS
 * optimized Windows AMI versions in the *Amazon EKS User Guide*.
 *
 * You cannot roll back a node group to an earlier Kubernetes version or AMI version.
 *
 * When a node in a managed node group is terminated due to a scaling action or update,
 * every `Pod` on that node is drained first. Amazon EKS attempts to drain the nodes
 * gracefully and will fail if it is unable to do so. You can `force` the update
 * if Amazon EKS is unable to drain the nodes as a result of a `Pod` disruption
 * budget issue.
 */
export declare const updateNodegroupVersion: API.OperationMethod<UpdateNodegroupVersionRequest, UpdateNodegroupVersionResponse, UpdateNodegroupVersionError, Credentials | HttpClient.HttpClient>;
export type UpdatePodIdentityAssociationError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Updates a EKS Pod Identity association. In an update, you can change the IAM role, the target IAM role, or `disableSessionTags`.
 * You must change at least one of these in an update. An association can't be moved
 * between clusters, namespaces, or service accounts. If you need to edit the namespace
 * or service account, you need to delete the association and then create a new
 * association with your desired settings.
 *
 * Similar to Amazon Web Services IAM behavior, EKS Pod Identity associations are eventually consistent,
 * and may take several seconds to be effective after the initial API call returns
 * successfully. You must design your applications to account for these potential delays.
 * We recommend that you don’t include association create/updates in the
 * critical, high-availability code paths of your application. Instead, make changes in a
 * separate initialization or setup routine that you run less frequently.
 *
 * You can set a *target IAM role* in the same or a different
 * account for advanced scenarios. With a target role, EKS Pod Identity automatically performs two
 * role assumptions in sequence: first assuming the role in the association that is in this
 * account, then using those credentials to assume the target IAM role. This process
 * provides your Pod with temporary credentials that have the permissions defined in the
 * target role, allowing secure access to resources in another Amazon Web Services account.
 */
export declare const updatePodIdentityAssociation: API.OperationMethod<UpdatePodIdentityAssociationRequest, UpdatePodIdentityAssociationResponse, UpdatePodIdentityAssociationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=eks.d.ts.map