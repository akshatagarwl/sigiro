import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ConnectorFailureException_base: S.Class<ConnectorFailureException, S.TaggedStruct<"ConnectorFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConnectorFailureException extends /*@__PURE__*/ ConnectorFailureException_base {
}
declare const ConnectorTimeoutException_base: S.Class<ConnectorTimeoutException, S.TaggedStruct<"ConnectorTimeoutException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConnectorTimeoutException extends /*@__PURE__*/ ConnectorTimeoutException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const QueryTimeoutException_base: S.Class<QueryTimeoutException, S.TaggedStruct<"QueryTimeoutException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class QueryTimeoutException extends /*@__PURE__*/ QueryTimeoutException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Id = string;
export type Name = string;
export type ComponentPath = string;
export type ExternalIdProperty = {
    [key: string]: string | undefined;
};
export declare const ExternalIdProperty: any;
export type EntityId = string;
export interface EntityPropertyReference {
    componentName?: string;
    componentPath?: string;
    externalIdProperty?: {
        [key: string]: string | undefined;
    };
    entityId?: string;
    propertyName: string;
}
export declare const EntityPropertyReference: S.Schema<EntityPropertyReference>;
export type DataValueList = DataValue[];
export declare const DataValueList: S.Schema<DataValueList>;
export type DataValueMap = {
    [key: string]: DataValue | undefined;
};
export declare const DataValueMap: S.Schema<DataValueMap>;
export interface RelationshipValue {
    targetEntityId?: string;
    targetComponentName?: string;
}
export declare const RelationshipValue: S.Schema<RelationshipValue>;
export type Expression = string;
export interface DataValue {
    booleanValue?: boolean;
    doubleValue?: number;
    integerValue?: number;
    longValue?: number;
    stringValue?: string;
    listValue?: DataValue[];
    mapValue?: {
        [key: string]: DataValue | undefined;
    };
    relationshipValue?: RelationshipValue;
    expression?: string;
}
export declare const DataValue: S.Schema<DataValue>;
export interface PropertyValue {
    timestamp?: Date;
    value: DataValue;
    time?: string;
}
export declare const PropertyValue: S.Schema<PropertyValue>;
export type PropertyValues = PropertyValue[];
export declare const PropertyValues: any;
export interface PropertyValueEntry {
    entityPropertyReference: EntityPropertyReference;
    propertyValues?: PropertyValue[];
}
export declare const PropertyValueEntry: S.Schema<PropertyValueEntry>;
export type Entries = PropertyValueEntry[];
export declare const Entries: any;
export interface BatchPutPropertyValuesRequest {
    workspaceId: string;
    entries: PropertyValueEntry[];
}
export declare const BatchPutPropertyValuesRequest: S.Schema<BatchPutPropertyValuesRequest>;
export interface BatchPutPropertyError {
    errorCode: string;
    errorMessage: string;
    entry: PropertyValueEntry;
}
export declare const BatchPutPropertyError: S.Schema<BatchPutPropertyError>;
export type Errors = BatchPutPropertyError[];
export declare const Errors: any;
export interface BatchPutPropertyErrorEntry {
    errors: BatchPutPropertyError[];
}
export declare const BatchPutPropertyErrorEntry: S.Schema<BatchPutPropertyErrorEntry>;
export type ErrorEntries = BatchPutPropertyErrorEntry[];
export declare const ErrorEntries: any;
export interface BatchPutPropertyValuesResponse {
    errorEntries: BatchPutPropertyErrorEntry[];
}
export declare const BatchPutPropertyValuesResponse: S.Schema<BatchPutPropertyValuesResponse>;
export interface CancelMetadataTransferJobRequest {
    metadataTransferJobId: string;
}
export declare const CancelMetadataTransferJobRequest: S.Schema<CancelMetadataTransferJobRequest>;
export type TwinMakerArn = string;
export type MetadataTransferJobState = string;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface ErrorDetails {
    code?: string;
    message?: string;
}
export declare const ErrorDetails: S.Schema<ErrorDetails>;
export interface MetadataTransferJobStatus {
    state?: string;
    error?: ErrorDetails;
    queuedPosition?: number;
}
export declare const MetadataTransferJobStatus: S.Schema<MetadataTransferJobStatus>;
export interface MetadataTransferJobProgress {
    totalCount?: number;
    succeededCount?: number;
    skippedCount?: number;
    failedCount?: number;
}
export declare const MetadataTransferJobProgress: S.Schema<MetadataTransferJobProgress>;
export interface CancelMetadataTransferJobResponse {
    metadataTransferJobId: string;
    arn: string;
    updateDateTime: Date;
    status: MetadataTransferJobStatus;
    progress?: MetadataTransferJobProgress;
}
export declare const CancelMetadataTransferJobResponse: S.Schema<CancelMetadataTransferJobResponse>;
export type ComponentTypeId = string;
export type Description = string;
export type Type = string;
export interface Relationship {
    targetComponentTypeId?: string;
    relationshipType?: string;
}
export declare const Relationship: S.Schema<Relationship>;
export interface DataType {
    type: string;
    nestedType?: DataType;
    allowedValues?: DataValue[];
    unitOfMeasure?: string;
    relationship?: Relationship;
}
export declare const DataType: S.Schema<DataType>;
export type Value = string;
export type Configuration = {
    [key: string]: string | undefined;
};
export declare const Configuration: any;
export type PropertyDisplayName = string;
export interface PropertyDefinitionRequest {
    dataType?: DataType;
    isRequiredInEntity?: boolean;
    isExternalId?: boolean;
    isStoredExternally?: boolean;
    isTimeSeries?: boolean;
    defaultValue?: DataValue;
    configuration?: {
        [key: string]: string | undefined;
    };
    displayName?: string;
}
export declare const PropertyDefinitionRequest: S.Schema<PropertyDefinitionRequest>;
export type PropertyDefinitionsRequest = {
    [key: string]: PropertyDefinitionRequest | undefined;
};
export declare const PropertyDefinitionsRequest: any;
export type ExtendsFrom = string[];
export declare const ExtendsFrom: any;
export type RequiredProperties = string[];
export declare const RequiredProperties: any;
export type Scope = string;
export type LambdaArn = string;
export interface LambdaFunction {
    arn: string;
}
export declare const LambdaFunction: S.Schema<LambdaFunction>;
export interface DataConnector {
    lambda?: LambdaFunction;
    isNative?: boolean;
}
export declare const DataConnector: S.Schema<DataConnector>;
export interface FunctionRequest {
    requiredProperties?: string[];
    scope?: string;
    implementedBy?: DataConnector;
}
export declare const FunctionRequest: S.Schema<FunctionRequest>;
export type FunctionsRequest = {
    [key: string]: FunctionRequest | undefined;
};
export declare const FunctionsRequest: any;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type GroupType = string;
export type PropertyNames = string[];
export declare const PropertyNames: any;
export interface PropertyGroupRequest {
    groupType?: string;
    propertyNames?: string[];
}
export declare const PropertyGroupRequest: S.Schema<PropertyGroupRequest>;
export type PropertyGroupsRequest = {
    [key: string]: PropertyGroupRequest | undefined;
};
export declare const PropertyGroupsRequest: any;
export type ComponentTypeName = string;
export interface CompositeComponentTypeRequest {
    componentTypeId?: string;
}
export declare const CompositeComponentTypeRequest: S.Schema<CompositeComponentTypeRequest>;
export type CompositeComponentTypesRequest = {
    [key: string]: CompositeComponentTypeRequest | undefined;
};
export declare const CompositeComponentTypesRequest: any;
export interface CreateComponentTypeRequest {
    workspaceId: string;
    isSingleton?: boolean;
    componentTypeId: string;
    description?: string;
    propertyDefinitions?: {
        [key: string]: PropertyDefinitionRequest | undefined;
    };
    extendsFrom?: string[];
    functions?: {
        [key: string]: FunctionRequest | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
    propertyGroups?: {
        [key: string]: PropertyGroupRequest | undefined;
    };
    componentTypeName?: string;
    compositeComponentTypes?: {
        [key: string]: CompositeComponentTypeRequest | undefined;
    };
}
export declare const CreateComponentTypeRequest: S.Schema<CreateComponentTypeRequest>;
export type State = string;
export interface CreateComponentTypeResponse {
    arn: string;
    creationDateTime: Date;
    state: string;
}
export declare const CreateComponentTypeResponse: S.Schema<CreateComponentTypeResponse>;
export type EntityName = string;
export type PropertyUpdateType = string;
export interface PropertyRequest {
    definition?: PropertyDefinitionRequest;
    value?: DataValue;
    updateType?: string;
}
export declare const PropertyRequest: S.Schema<PropertyRequest>;
export type PropertyRequests = {
    [key: string]: PropertyRequest | undefined;
};
export declare const PropertyRequests: any;
export type PropertyGroupUpdateType = string;
export interface ComponentPropertyGroupRequest {
    groupType?: string;
    propertyNames?: string[];
    updateType?: string;
}
export declare const ComponentPropertyGroupRequest: S.Schema<ComponentPropertyGroupRequest>;
export type ComponentPropertyGroupRequests = {
    [key: string]: ComponentPropertyGroupRequest | undefined;
};
export declare const ComponentPropertyGroupRequests: any;
export interface ComponentRequest {
    description?: string;
    componentTypeId?: string;
    properties?: {
        [key: string]: PropertyRequest | undefined;
    };
    propertyGroups?: {
        [key: string]: ComponentPropertyGroupRequest | undefined;
    };
}
export declare const ComponentRequest: S.Schema<ComponentRequest>;
export type ComponentsMapRequest = {
    [key: string]: ComponentRequest | undefined;
};
export declare const ComponentsMapRequest: any;
export interface CompositeComponentRequest {
    description?: string;
    properties?: {
        [key: string]: PropertyRequest | undefined;
    };
    propertyGroups?: {
        [key: string]: ComponentPropertyGroupRequest | undefined;
    };
}
export declare const CompositeComponentRequest: S.Schema<CompositeComponentRequest>;
export type CompositeComponentsMapRequest = {
    [key: string]: CompositeComponentRequest | undefined;
};
export declare const CompositeComponentsMapRequest: any;
export type ParentEntityId = string;
export interface CreateEntityRequest {
    workspaceId: string;
    entityId?: string;
    entityName: string;
    description?: string;
    components?: {
        [key: string]: ComponentRequest | undefined;
    };
    compositeComponents?: {
        [key: string]: CompositeComponentRequest | undefined;
    };
    parentEntityId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateEntityRequest: S.Schema<CreateEntityRequest>;
export interface CreateEntityResponse {
    entityId: string;
    arn: string;
    creationDateTime: Date;
    state: string;
}
export declare const CreateEntityResponse: S.Schema<CreateEntityResponse>;
export type SourceType = string;
export type S3SourceLocation = string;
export interface S3SourceConfiguration {
    location: string;
}
export declare const S3SourceConfiguration: S.Schema<S3SourceConfiguration>;
export type Uuid = string;
export type SiteWiseExternalId = string;
export interface FilterByAssetModel {
    assetModelId?: string;
    assetModelExternalId?: string;
    includeOffspring?: boolean;
    includeAssets?: boolean;
}
export declare const FilterByAssetModel: S.Schema<FilterByAssetModel>;
export interface FilterByAsset {
    assetId?: string;
    assetExternalId?: string;
    includeOffspring?: boolean;
    includeAssetModel?: boolean;
}
export declare const FilterByAsset: S.Schema<FilterByAsset>;
export type IotSiteWiseSourceConfigurationFilter = {
    filterByAssetModel: FilterByAssetModel;
    filterByAsset?: never;
} | {
    filterByAssetModel?: never;
    filterByAsset: FilterByAsset;
};
export declare const IotSiteWiseSourceConfigurationFilter: any;
export type IotSiteWiseSourceConfigurationFilters = IotSiteWiseSourceConfigurationFilter[];
export declare const IotSiteWiseSourceConfigurationFilters: any;
export interface IotSiteWiseSourceConfiguration {
    filters?: IotSiteWiseSourceConfigurationFilter[];
}
export declare const IotSiteWiseSourceConfiguration: S.Schema<IotSiteWiseSourceConfiguration>;
export interface FilterByComponentType {
    componentTypeId: string;
}
export declare const FilterByComponentType: S.Schema<FilterByComponentType>;
export interface FilterByEntity {
    entityId: string;
}
export declare const FilterByEntity: S.Schema<FilterByEntity>;
export type IotTwinMakerSourceConfigurationFilter = {
    filterByComponentType: FilterByComponentType;
    filterByEntity?: never;
} | {
    filterByComponentType?: never;
    filterByEntity: FilterByEntity;
};
export declare const IotTwinMakerSourceConfigurationFilter: any;
export type IotTwinMakerSourceConfigurationFilters = IotTwinMakerSourceConfigurationFilter[];
export declare const IotTwinMakerSourceConfigurationFilters: any;
export interface IotTwinMakerSourceConfiguration {
    workspace: string;
    filters?: IotTwinMakerSourceConfigurationFilter[];
}
export declare const IotTwinMakerSourceConfiguration: S.Schema<IotTwinMakerSourceConfiguration>;
export interface SourceConfiguration {
    type: string;
    s3Configuration?: S3SourceConfiguration;
    iotSiteWiseConfiguration?: IotSiteWiseSourceConfiguration;
    iotTwinMakerConfiguration?: IotTwinMakerSourceConfiguration;
}
export declare const SourceConfiguration: S.Schema<SourceConfiguration>;
export type SourceConfigurations = SourceConfiguration[];
export declare const SourceConfigurations: any;
export type DestinationType = string;
export type S3DestinationLocation = string;
export interface S3DestinationConfiguration {
    location: string;
}
export declare const S3DestinationConfiguration: S.Schema<S3DestinationConfiguration>;
export interface IotTwinMakerDestinationConfiguration {
    workspace: string;
}
export declare const IotTwinMakerDestinationConfiguration: S.Schema<IotTwinMakerDestinationConfiguration>;
export interface DestinationConfiguration {
    type: string;
    s3Configuration?: S3DestinationConfiguration;
    iotTwinMakerConfiguration?: IotTwinMakerDestinationConfiguration;
}
export declare const DestinationConfiguration: S.Schema<DestinationConfiguration>;
export interface CreateMetadataTransferJobRequest {
    metadataTransferJobId?: string;
    description?: string;
    sources: SourceConfiguration[];
    destination: DestinationConfiguration;
}
export declare const CreateMetadataTransferJobRequest: S.Schema<CreateMetadataTransferJobRequest>;
export interface CreateMetadataTransferJobResponse {
    metadataTransferJobId: string;
    arn: string;
    creationDateTime: Date;
    status: MetadataTransferJobStatus;
}
export declare const CreateMetadataTransferJobResponse: S.Schema<CreateMetadataTransferJobResponse>;
export type S3Url = string;
export type SceneCapability = string;
export type SceneCapabilities = string[];
export declare const SceneCapabilities: any;
export type SceneMetadataValue = string;
export type SceneMetadataMap = {
    [key: string]: string | undefined;
};
export declare const SceneMetadataMap: any;
export interface CreateSceneRequest {
    workspaceId: string;
    sceneId: string;
    contentLocation: string;
    description?: string;
    capabilities?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
    sceneMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateSceneRequest: S.Schema<CreateSceneRequest>;
export interface CreateSceneResponse {
    arn: string;
    creationDateTime: Date;
}
export declare const CreateSceneResponse: S.Schema<CreateSceneResponse>;
export type SyncSource = string;
export type RoleArn = string;
export interface CreateSyncJobRequest {
    workspaceId: string;
    syncSource: string;
    syncRole: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateSyncJobRequest: S.Schema<CreateSyncJobRequest>;
export type SyncJobState = string;
export interface CreateSyncJobResponse {
    arn: string;
    creationDateTime: Date;
    state: string;
}
export declare const CreateSyncJobResponse: S.Schema<CreateSyncJobResponse>;
export type S3Location = string;
export interface CreateWorkspaceRequest {
    workspaceId: string;
    description?: string;
    s3Location?: string;
    role?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateWorkspaceRequest: S.Schema<CreateWorkspaceRequest>;
export interface CreateWorkspaceResponse {
    arn: string;
    creationDateTime: Date;
}
export declare const CreateWorkspaceResponse: S.Schema<CreateWorkspaceResponse>;
export interface DeleteComponentTypeRequest {
    workspaceId: string;
    componentTypeId: string;
}
export declare const DeleteComponentTypeRequest: S.Schema<DeleteComponentTypeRequest>;
export interface DeleteComponentTypeResponse {
    state: string;
}
export declare const DeleteComponentTypeResponse: S.Schema<DeleteComponentTypeResponse>;
export interface DeleteEntityRequest {
    workspaceId: string;
    entityId: string;
    isRecursive?: boolean;
}
export declare const DeleteEntityRequest: S.Schema<DeleteEntityRequest>;
export interface DeleteEntityResponse {
    state: string;
}
export declare const DeleteEntityResponse: S.Schema<DeleteEntityResponse>;
export interface DeleteSceneRequest {
    workspaceId: string;
    sceneId: string;
}
export declare const DeleteSceneRequest: S.Schema<DeleteSceneRequest>;
export interface DeleteSceneResponse {
}
export declare const DeleteSceneResponse: S.Schema<DeleteSceneResponse>;
export interface DeleteSyncJobRequest {
    workspaceId: string;
    syncSource: string;
}
export declare const DeleteSyncJobRequest: S.Schema<DeleteSyncJobRequest>;
export interface DeleteSyncJobResponse {
    state: string;
}
export declare const DeleteSyncJobResponse: S.Schema<DeleteSyncJobResponse>;
export interface DeleteWorkspaceRequest {
    workspaceId: string;
}
export declare const DeleteWorkspaceRequest: S.Schema<DeleteWorkspaceRequest>;
export type WorkspaceDeleteMessage = string;
export interface DeleteWorkspaceResponse {
    message?: string;
}
export declare const DeleteWorkspaceResponse: S.Schema<DeleteWorkspaceResponse>;
export type QueryStatement = string;
export type QueryServiceMaxResults = number;
export type NextToken = string;
export interface ExecuteQueryRequest {
    workspaceId: string;
    queryStatement: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ExecuteQueryRequest: S.Schema<ExecuteQueryRequest>;
export type ColumnName = string;
export type ColumnType = string;
export interface ColumnDescription {
    name?: string;
    type?: string;
}
export declare const ColumnDescription: S.Schema<ColumnDescription>;
export type ColumnDescriptions = ColumnDescription[];
export declare const ColumnDescriptions: any;
export type QueryResultValue = unknown;
export type RowData = any[];
export declare const RowData: any;
export interface Row {
    rowData?: any[];
}
export declare const Row: S.Schema<Row>;
export type Rows = Row[];
export declare const Rows: any;
export interface ExecuteQueryResponse {
    columnDescriptions?: ColumnDescription[];
    rows?: Row[];
    nextToken?: string;
}
export declare const ExecuteQueryResponse: S.Schema<ExecuteQueryResponse>;
export interface GetComponentTypeRequest {
    workspaceId: string;
    componentTypeId: string;
}
export declare const GetComponentTypeRequest: S.Schema<GetComponentTypeRequest>;
export interface PropertyDefinitionResponse {
    dataType: DataType;
    isTimeSeries: boolean;
    isRequiredInEntity: boolean;
    isExternalId: boolean;
    isStoredExternally: boolean;
    isImported: boolean;
    isFinal: boolean;
    isInherited: boolean;
    defaultValue?: DataValue;
    configuration?: {
        [key: string]: string | undefined;
    };
    displayName?: string;
}
export declare const PropertyDefinitionResponse: S.Schema<PropertyDefinitionResponse>;
export type PropertyDefinitionsResponse = {
    [key: string]: PropertyDefinitionResponse | undefined;
};
export declare const PropertyDefinitionsResponse: any;
export interface FunctionResponse {
    requiredProperties?: string[];
    scope?: string;
    implementedBy?: DataConnector;
    isInherited?: boolean;
}
export declare const FunctionResponse: S.Schema<FunctionResponse>;
export type FunctionsResponse = {
    [key: string]: FunctionResponse | undefined;
};
export declare const FunctionsResponse: any;
export interface Status {
    state?: string;
    error?: ErrorDetails;
}
export declare const Status: S.Schema<Status>;
export interface PropertyGroupResponse {
    groupType: string;
    propertyNames: string[];
    isInherited: boolean;
}
export declare const PropertyGroupResponse: S.Schema<PropertyGroupResponse>;
export type PropertyGroupsResponse = {
    [key: string]: PropertyGroupResponse | undefined;
};
export declare const PropertyGroupsResponse: any;
export interface CompositeComponentTypeResponse {
    componentTypeId?: string;
    isInherited?: boolean;
}
export declare const CompositeComponentTypeResponse: S.Schema<CompositeComponentTypeResponse>;
export type CompositeComponentTypesResponse = {
    [key: string]: CompositeComponentTypeResponse | undefined;
};
export declare const CompositeComponentTypesResponse: any;
export interface GetComponentTypeResponse {
    workspaceId: string;
    isSingleton?: boolean;
    componentTypeId: string;
    description?: string;
    propertyDefinitions?: {
        [key: string]: PropertyDefinitionResponse | undefined;
    };
    extendsFrom?: string[];
    functions?: {
        [key: string]: FunctionResponse | undefined;
    };
    creationDateTime: Date;
    updateDateTime: Date;
    arn: string;
    isAbstract?: boolean;
    isSchemaInitialized?: boolean;
    status?: Status;
    propertyGroups?: {
        [key: string]: PropertyGroupResponse | undefined;
    };
    syncSource?: string;
    componentTypeName?: string;
    compositeComponentTypes?: {
        [key: string]: CompositeComponentTypeResponse | undefined;
    };
}
export declare const GetComponentTypeResponse: S.Schema<GetComponentTypeResponse>;
export interface GetEntityRequest {
    workspaceId: string;
    entityId: string;
}
export declare const GetEntityRequest: S.Schema<GetEntityRequest>;
export interface PropertyResponse {
    definition?: PropertyDefinitionResponse;
    value?: DataValue;
    areAllPropertyValuesReturned?: boolean;
}
export declare const PropertyResponse: S.Schema<PropertyResponse>;
export type PropertyResponses = {
    [key: string]: PropertyResponse | undefined;
};
export declare const PropertyResponses: any;
export interface ComponentPropertyGroupResponse {
    groupType: string;
    propertyNames: string[];
    isInherited: boolean;
}
export declare const ComponentPropertyGroupResponse: S.Schema<ComponentPropertyGroupResponse>;
export type ComponentPropertyGroupResponses = {
    [key: string]: ComponentPropertyGroupResponse | undefined;
};
export declare const ComponentPropertyGroupResponses: any;
export interface ComponentSummary {
    componentName: string;
    componentTypeId: string;
    definedIn?: string;
    description?: string;
    propertyGroups?: {
        [key: string]: ComponentPropertyGroupResponse | undefined;
    };
    status: Status;
    syncSource?: string;
    componentPath?: string;
}
export declare const ComponentSummary: S.Schema<ComponentSummary>;
export type CompositeComponentResponse = {
    [key: string]: ComponentSummary | undefined;
};
export declare const CompositeComponentResponse: any;
export interface ComponentResponse {
    componentName?: string;
    description?: string;
    componentTypeId?: string;
    status?: Status;
    definedIn?: string;
    properties?: {
        [key: string]: PropertyResponse | undefined;
    };
    propertyGroups?: {
        [key: string]: ComponentPropertyGroupResponse | undefined;
    };
    syncSource?: string;
    areAllPropertiesReturned?: boolean;
    compositeComponents?: {
        [key: string]: ComponentSummary | undefined;
    };
    areAllCompositeComponentsReturned?: boolean;
}
export declare const ComponentResponse: S.Schema<ComponentResponse>;
export type ComponentsMap = {
    [key: string]: ComponentResponse | undefined;
};
export declare const ComponentsMap: any;
export interface GetEntityResponse {
    entityId: string;
    entityName: string;
    arn: string;
    status: Status;
    workspaceId: string;
    description?: string;
    components?: {
        [key: string]: ComponentResponse | undefined;
    };
    parentEntityId: string;
    hasChildEntities: boolean;
    creationDateTime: Date;
    updateDateTime: Date;
    syncSource?: string;
    areAllComponentsReturned?: boolean;
}
export declare const GetEntityResponse: S.Schema<GetEntityResponse>;
export interface GetMetadataTransferJobRequest {
    metadataTransferJobId: string;
}
export declare const GetMetadataTransferJobRequest: S.Schema<GetMetadataTransferJobRequest>;
export interface GetMetadataTransferJobResponse {
    metadataTransferJobId: string;
    arn: string;
    description?: string;
    sources: SourceConfiguration[];
    destination: DestinationConfiguration;
    metadataTransferJobRole: string;
    reportUrl?: string;
    creationDateTime: Date;
    updateDateTime: Date;
    status: MetadataTransferJobStatus;
    progress?: MetadataTransferJobProgress;
}
export declare const GetMetadataTransferJobResponse: S.Schema<GetMetadataTransferJobResponse>;
export interface GetPricingPlanRequest {
}
export declare const GetPricingPlanRequest: S.Schema<GetPricingPlanRequest>;
export type BundleName = string;
export type PricingBundles = string[];
export declare const PricingBundles: any;
export type PricingTier = string;
export interface BundleInformation {
    bundleNames: string[];
    pricingTier?: string;
}
export declare const BundleInformation: S.Schema<BundleInformation>;
export type PricingMode = string;
export type UpdateReason = string;
export interface PricingPlan {
    billableEntityCount?: number;
    bundleInformation?: BundleInformation;
    effectiveDateTime: Date;
    pricingMode: string;
    updateDateTime: Date;
    updateReason: string;
}
export declare const PricingPlan: S.Schema<PricingPlan>;
export interface GetPricingPlanResponse {
    currentPricingPlan: PricingPlan;
    pendingPricingPlan?: PricingPlan;
}
export declare const GetPricingPlanResponse: S.Schema<GetPricingPlanResponse>;
export type SelectedPropertyList = string[];
export declare const SelectedPropertyList: any;
export type MaxResults = number;
export type Order = string;
export interface OrderBy {
    order?: string;
    propertyName: string;
}
export declare const OrderBy: S.Schema<OrderBy>;
export type OrderByList = OrderBy[];
export declare const OrderByList: any;
export interface PropertyFilter {
    propertyName?: string;
    operator?: string;
    value?: DataValue;
}
export declare const PropertyFilter: S.Schema<PropertyFilter>;
export type PropertyFilters = PropertyFilter[];
export declare const PropertyFilters: any;
export interface TabularConditions {
    orderBy?: OrderBy[];
    propertyFilters?: PropertyFilter[];
}
export declare const TabularConditions: S.Schema<TabularConditions>;
export interface GetPropertyValueRequest {
    componentName?: string;
    componentPath?: string;
    componentTypeId?: string;
    entityId?: string;
    selectedProperties: string[];
    workspaceId: string;
    maxResults?: number;
    nextToken?: string;
    propertyGroupName?: string;
    tabularConditions?: TabularConditions;
}
export declare const GetPropertyValueRequest: S.Schema<GetPropertyValueRequest>;
export interface PropertyLatestValue {
    propertyReference: EntityPropertyReference;
    propertyValue?: DataValue;
}
export declare const PropertyLatestValue: S.Schema<PropertyLatestValue>;
export type PropertyLatestValueMap = {
    [key: string]: PropertyLatestValue | undefined;
};
export declare const PropertyLatestValueMap: any;
export type PropertyTableValue = {
    [key: string]: DataValue | undefined;
};
export declare const PropertyTableValue: any;
export type TabularPropertyValue = {
    [key: string]: DataValue | undefined;
}[];
export declare const TabularPropertyValue: any;
export type TabularPropertyValues = {
    [key: string]: DataValue | undefined;
}[][];
export declare const TabularPropertyValues: any;
export interface GetPropertyValueResponse {
    propertyValues?: {
        [key: string]: PropertyLatestValue | undefined;
    };
    nextToken?: string;
    tabularPropertyValues?: {
        [key: string]: DataValue | undefined;
    }[][];
}
export declare const GetPropertyValueResponse: S.Schema<GetPropertyValueResponse>;
export type InterpolationType = string;
export type IntervalInSeconds = number;
export interface InterpolationParameters {
    interpolationType?: string;
    intervalInSeconds?: number;
}
export declare const InterpolationParameters: S.Schema<InterpolationParameters>;
export type OrderByTime = string;
export interface GetPropertyValueHistoryRequest {
    workspaceId: string;
    entityId?: string;
    componentName?: string;
    componentPath?: string;
    componentTypeId?: string;
    selectedProperties: string[];
    propertyFilters?: PropertyFilter[];
    startDateTime?: Date;
    endDateTime?: Date;
    interpolation?: InterpolationParameters;
    nextToken?: string;
    maxResults?: number;
    orderByTime?: string;
    startTime?: string;
    endTime?: string;
}
export declare const GetPropertyValueHistoryRequest: S.Schema<GetPropertyValueHistoryRequest>;
export type Values = PropertyValue[];
export declare const Values: any;
export interface PropertyValueHistory {
    entityPropertyReference: EntityPropertyReference;
    values?: PropertyValue[];
}
export declare const PropertyValueHistory: S.Schema<PropertyValueHistory>;
export type PropertyValueList = PropertyValueHistory[];
export declare const PropertyValueList: any;
export interface GetPropertyValueHistoryResponse {
    propertyValues: PropertyValueHistory[];
    nextToken?: string;
}
export declare const GetPropertyValueHistoryResponse: S.Schema<GetPropertyValueHistoryResponse>;
export interface GetSceneRequest {
    workspaceId: string;
    sceneId: string;
}
export declare const GetSceneRequest: S.Schema<GetSceneRequest>;
export type GeneratedSceneMetadataMap = {
    [key: string]: string | undefined;
};
export declare const GeneratedSceneMetadataMap: any;
export type SceneErrorCode = string;
export interface SceneError {
    code?: string;
    message?: string;
}
export declare const SceneError: S.Schema<SceneError>;
export interface GetSceneResponse {
    workspaceId: string;
    sceneId: string;
    contentLocation: string;
    arn: string;
    creationDateTime: Date;
    updateDateTime: Date;
    description?: string;
    capabilities?: string[];
    sceneMetadata?: {
        [key: string]: string | undefined;
    };
    generatedSceneMetadata?: {
        [key: string]: string | undefined;
    };
    error?: SceneError;
}
export declare const GetSceneResponse: S.Schema<GetSceneResponse>;
export interface GetSyncJobRequest {
    syncSource: string;
    workspaceId?: string;
}
export declare const GetSyncJobRequest: S.Schema<GetSyncJobRequest>;
export interface SyncJobStatus {
    state?: string;
    error?: ErrorDetails;
}
export declare const SyncJobStatus: S.Schema<SyncJobStatus>;
export interface GetSyncJobResponse {
    arn: string;
    workspaceId: string;
    syncSource: string;
    syncRole: string;
    status: SyncJobStatus;
    creationDateTime: Date;
    updateDateTime: Date;
}
export declare const GetSyncJobResponse: S.Schema<GetSyncJobResponse>;
export type IdOrArn = string;
export interface GetWorkspaceRequest {
    workspaceId: string;
}
export declare const GetWorkspaceRequest: S.Schema<GetWorkspaceRequest>;
export type LinkedService = string;
export type LinkedServices = string[];
export declare const LinkedServices: any;
export interface GetWorkspaceResponse {
    workspaceId: string;
    arn: string;
    description?: string;
    linkedServices?: string[];
    s3Location?: string;
    role?: string;
    creationDateTime: Date;
    updateDateTime: Date;
}
export declare const GetWorkspaceResponse: S.Schema<GetWorkspaceResponse>;
export interface ListComponentsRequest {
    workspaceId: string;
    entityId: string;
    componentPath?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListComponentsRequest: S.Schema<ListComponentsRequest>;
export type ComponentSummaries = ComponentSummary[];
export declare const ComponentSummaries: any;
export interface ListComponentsResponse {
    componentSummaries: ComponentSummary[];
    nextToken?: string;
}
export declare const ListComponentsResponse: S.Schema<ListComponentsResponse>;
export type ListComponentTypesFilter = {
    extendsFrom: string;
    namespace?: never;
    isAbstract?: never;
} | {
    extendsFrom?: never;
    namespace: string;
    isAbstract?: never;
} | {
    extendsFrom?: never;
    namespace?: never;
    isAbstract: boolean;
};
export declare const ListComponentTypesFilter: any;
export type ListComponentTypesFilters = ListComponentTypesFilter[];
export declare const ListComponentTypesFilters: any;
export interface ListComponentTypesRequest {
    workspaceId: string;
    filters?: ListComponentTypesFilter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const ListComponentTypesRequest: S.Schema<ListComponentTypesRequest>;
export interface ComponentTypeSummary {
    arn: string;
    componentTypeId: string;
    creationDateTime: Date;
    updateDateTime: Date;
    description?: string;
    status?: Status;
    componentTypeName?: string;
}
export declare const ComponentTypeSummary: S.Schema<ComponentTypeSummary>;
export type ComponentTypeSummaries = ComponentTypeSummary[];
export declare const ComponentTypeSummaries: any;
export interface ListComponentTypesResponse {
    workspaceId: string;
    componentTypeSummaries: ComponentTypeSummary[];
    nextToken?: string;
    maxResults?: number;
}
export declare const ListComponentTypesResponse: S.Schema<ListComponentTypesResponse>;
export type ListEntitiesFilter = {
    parentEntityId: string;
    componentTypeId?: never;
    externalId?: never;
} | {
    parentEntityId?: never;
    componentTypeId: string;
    externalId?: never;
} | {
    parentEntityId?: never;
    componentTypeId?: never;
    externalId: string;
};
export declare const ListEntitiesFilter: any;
export type ListEntitiesFilters = ListEntitiesFilter[];
export declare const ListEntitiesFilters: any;
export interface ListEntitiesRequest {
    workspaceId: string;
    filters?: ListEntitiesFilter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListEntitiesRequest: S.Schema<ListEntitiesRequest>;
export interface EntitySummary {
    entityId: string;
    entityName: string;
    arn: string;
    parentEntityId?: string;
    status: Status;
    description?: string;
    hasChildEntities?: boolean;
    creationDateTime: Date;
    updateDateTime: Date;
}
export declare const EntitySummary: S.Schema<EntitySummary>;
export type EntitySummaries = EntitySummary[];
export declare const EntitySummaries: any;
export interface ListEntitiesResponse {
    entitySummaries?: EntitySummary[];
    nextToken?: string;
}
export declare const ListEntitiesResponse: S.Schema<ListEntitiesResponse>;
export type ListMetadataTransferJobsFilter = {
    workspaceId: string;
    state?: never;
} | {
    workspaceId?: never;
    state: string;
};
export declare const ListMetadataTransferJobsFilter: any;
export type ListMetadataTransferJobsFilters = ListMetadataTransferJobsFilter[];
export declare const ListMetadataTransferJobsFilters: any;
export interface ListMetadataTransferJobsRequest {
    sourceType: string;
    destinationType: string;
    filters?: ListMetadataTransferJobsFilter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const ListMetadataTransferJobsRequest: S.Schema<ListMetadataTransferJobsRequest>;
export interface MetadataTransferJobSummary {
    metadataTransferJobId: string;
    arn: string;
    creationDateTime: Date;
    updateDateTime: Date;
    status: MetadataTransferJobStatus;
    progress?: MetadataTransferJobProgress;
}
export declare const MetadataTransferJobSummary: S.Schema<MetadataTransferJobSummary>;
export type MetadataTransferJobSummaries = MetadataTransferJobSummary[];
export declare const MetadataTransferJobSummaries: any;
export interface ListMetadataTransferJobsResponse {
    metadataTransferJobSummaries: MetadataTransferJobSummary[];
    nextToken?: string;
}
export declare const ListMetadataTransferJobsResponse: S.Schema<ListMetadataTransferJobsResponse>;
export interface ListPropertiesRequest {
    workspaceId: string;
    componentName?: string;
    componentPath?: string;
    entityId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListPropertiesRequest: S.Schema<ListPropertiesRequest>;
export interface PropertySummary {
    definition?: PropertyDefinitionResponse;
    propertyName: string;
    value?: DataValue;
    areAllPropertyValuesReturned?: boolean;
}
export declare const PropertySummary: S.Schema<PropertySummary>;
export type PropertySummaries = PropertySummary[];
export declare const PropertySummaries: any;
export interface ListPropertiesResponse {
    propertySummaries: PropertySummary[];
    nextToken?: string;
}
export declare const ListPropertiesResponse: S.Schema<ListPropertiesResponse>;
export interface ListScenesRequest {
    workspaceId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListScenesRequest: S.Schema<ListScenesRequest>;
export interface SceneSummary {
    sceneId: string;
    contentLocation: string;
    arn: string;
    creationDateTime: Date;
    updateDateTime: Date;
    description?: string;
}
export declare const SceneSummary: S.Schema<SceneSummary>;
export type SceneSummaries = SceneSummary[];
export declare const SceneSummaries: any;
export interface ListScenesResponse {
    sceneSummaries?: SceneSummary[];
    nextToken?: string;
}
export declare const ListScenesResponse: S.Schema<ListScenesResponse>;
export interface ListSyncJobsRequest {
    workspaceId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSyncJobsRequest: S.Schema<ListSyncJobsRequest>;
export interface SyncJobSummary {
    arn?: string;
    workspaceId?: string;
    syncSource?: string;
    status?: SyncJobStatus;
    creationDateTime?: Date;
    updateDateTime?: Date;
}
export declare const SyncJobSummary: S.Schema<SyncJobSummary>;
export type SyncJobSummaries = SyncJobSummary[];
export declare const SyncJobSummaries: any;
export interface ListSyncJobsResponse {
    syncJobSummaries?: SyncJobSummary[];
    nextToken?: string;
}
export declare const ListSyncJobsResponse: S.Schema<ListSyncJobsResponse>;
export type SyncResourceState = string;
export type SyncResourceType = string;
export type SyncResourceFilter = {
    state: string;
    resourceType?: never;
    resourceId?: never;
    externalId?: never;
} | {
    state?: never;
    resourceType: string;
    resourceId?: never;
    externalId?: never;
} | {
    state?: never;
    resourceType?: never;
    resourceId: string;
    externalId?: never;
} | {
    state?: never;
    resourceType?: never;
    resourceId?: never;
    externalId: string;
};
export declare const SyncResourceFilter: any;
export type SyncResourceFilters = SyncResourceFilter[];
export declare const SyncResourceFilters: any;
export interface ListSyncResourcesRequest {
    workspaceId: string;
    syncSource: string;
    filters?: SyncResourceFilter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSyncResourcesRequest: S.Schema<ListSyncResourcesRequest>;
export interface SyncResourceStatus {
    state?: string;
    error?: ErrorDetails;
}
export declare const SyncResourceStatus: S.Schema<SyncResourceStatus>;
export interface SyncResourceSummary {
    resourceType?: string;
    externalId?: string;
    resourceId?: string;
    status?: SyncResourceStatus;
    updateDateTime?: Date;
}
export declare const SyncResourceSummary: S.Schema<SyncResourceSummary>;
export type SyncResourceSummaries = SyncResourceSummary[];
export declare const SyncResourceSummaries: any;
export interface ListSyncResourcesResponse {
    syncResources?: SyncResourceSummary[];
    nextToken?: string;
}
export declare const ListSyncResourcesResponse: S.Schema<ListSyncResourcesResponse>;
export interface ListTagsForResourceRequest {
    resourceARN: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
    nextToken?: string;
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListWorkspacesRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListWorkspacesRequest: S.Schema<ListWorkspacesRequest>;
export interface WorkspaceSummary {
    workspaceId: string;
    arn: string;
    description?: string;
    linkedServices?: string[];
    creationDateTime: Date;
    updateDateTime: Date;
}
export declare const WorkspaceSummary: S.Schema<WorkspaceSummary>;
export type WorkspaceSummaries = WorkspaceSummary[];
export declare const WorkspaceSummaries: any;
export interface ListWorkspacesResponse {
    workspaceSummaries?: WorkspaceSummary[];
    nextToken?: string;
}
export declare const ListWorkspacesResponse: S.Schema<ListWorkspacesResponse>;
export interface TagResourceRequest {
    resourceARN: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateComponentTypeRequest {
    workspaceId: string;
    isSingleton?: boolean;
    componentTypeId: string;
    description?: string;
    propertyDefinitions?: {
        [key: string]: PropertyDefinitionRequest | undefined;
    };
    extendsFrom?: string[];
    functions?: {
        [key: string]: FunctionRequest | undefined;
    };
    propertyGroups?: {
        [key: string]: PropertyGroupRequest | undefined;
    };
    componentTypeName?: string;
    compositeComponentTypes?: {
        [key: string]: CompositeComponentTypeRequest | undefined;
    };
}
export declare const UpdateComponentTypeRequest: S.Schema<UpdateComponentTypeRequest>;
export interface UpdateComponentTypeResponse {
    workspaceId: string;
    arn: string;
    componentTypeId: string;
    state: string;
}
export declare const UpdateComponentTypeResponse: S.Schema<UpdateComponentTypeResponse>;
export type ComponentUpdateType = string;
export interface ComponentUpdateRequest {
    updateType?: string;
    description?: string;
    componentTypeId?: string;
    propertyUpdates?: {
        [key: string]: PropertyRequest | undefined;
    };
    propertyGroupUpdates?: {
        [key: string]: ComponentPropertyGroupRequest | undefined;
    };
}
export declare const ComponentUpdateRequest: S.Schema<ComponentUpdateRequest>;
export type ComponentUpdatesMapRequest = {
    [key: string]: ComponentUpdateRequest | undefined;
};
export declare const ComponentUpdatesMapRequest: any;
export interface CompositeComponentUpdateRequest {
    updateType?: string;
    description?: string;
    propertyUpdates?: {
        [key: string]: PropertyRequest | undefined;
    };
    propertyGroupUpdates?: {
        [key: string]: ComponentPropertyGroupRequest | undefined;
    };
}
export declare const CompositeComponentUpdateRequest: S.Schema<CompositeComponentUpdateRequest>;
export type CompositeComponentUpdatesMapRequest = {
    [key: string]: CompositeComponentUpdateRequest | undefined;
};
export declare const CompositeComponentUpdatesMapRequest: any;
export type ParentEntityUpdateType = string;
export interface ParentEntityUpdateRequest {
    updateType: string;
    parentEntityId?: string;
}
export declare const ParentEntityUpdateRequest: S.Schema<ParentEntityUpdateRequest>;
export interface UpdateEntityRequest {
    workspaceId: string;
    entityId: string;
    entityName?: string;
    description?: string;
    componentUpdates?: {
        [key: string]: ComponentUpdateRequest | undefined;
    };
    compositeComponentUpdates?: {
        [key: string]: CompositeComponentUpdateRequest | undefined;
    };
    parentEntityUpdate?: ParentEntityUpdateRequest;
}
export declare const UpdateEntityRequest: S.Schema<UpdateEntityRequest>;
export interface UpdateEntityResponse {
    updateDateTime: Date;
    state: string;
}
export declare const UpdateEntityResponse: S.Schema<UpdateEntityResponse>;
export interface UpdatePricingPlanRequest {
    pricingMode: string;
    bundleNames?: string[];
}
export declare const UpdatePricingPlanRequest: S.Schema<UpdatePricingPlanRequest>;
export interface UpdatePricingPlanResponse {
    currentPricingPlan: PricingPlan;
    pendingPricingPlan?: PricingPlan;
}
export declare const UpdatePricingPlanResponse: S.Schema<UpdatePricingPlanResponse>;
export interface UpdateSceneRequest {
    workspaceId: string;
    sceneId: string;
    contentLocation?: string;
    description?: string;
    capabilities?: string[];
    sceneMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateSceneRequest: S.Schema<UpdateSceneRequest>;
export interface UpdateSceneResponse {
    updateDateTime: Date;
}
export declare const UpdateSceneResponse: S.Schema<UpdateSceneResponse>;
export interface UpdateWorkspaceRequest {
    workspaceId: string;
    description?: string;
    role?: string;
    s3Location?: string;
}
export declare const UpdateWorkspaceRequest: S.Schema<UpdateWorkspaceRequest>;
export interface UpdateWorkspaceResponse {
    updateDateTime: Date;
}
export declare const UpdateWorkspaceResponse: S.Schema<UpdateWorkspaceResponse>;
export type ExceptionMessage = string;
export type BatchPutPropertyValuesError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets values for multiple time series properties.
 */
export declare const batchPutPropertyValues: API.OperationMethod<BatchPutPropertyValuesRequest, BatchPutPropertyValuesResponse, BatchPutPropertyValuesError, Credentials | HttpClient.HttpClient>;
export type CancelMetadataTransferJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the metadata transfer job.
 */
export declare const cancelMetadataTransferJob: API.OperationMethod<CancelMetadataTransferJobRequest, CancelMetadataTransferJobResponse, CancelMetadataTransferJobError, Credentials | HttpClient.HttpClient>;
export type CreateComponentTypeError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a component type.
 */
export declare const createComponentType: API.OperationMethod<CreateComponentTypeRequest, CreateComponentTypeResponse, CreateComponentTypeError, Credentials | HttpClient.HttpClient>;
export type CreateEntityError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an entity.
 */
export declare const createEntity: API.OperationMethod<CreateEntityRequest, CreateEntityResponse, CreateEntityError, Credentials | HttpClient.HttpClient>;
export type CreateMetadataTransferJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new metadata transfer job.
 */
export declare const createMetadataTransferJob: API.OperationMethod<CreateMetadataTransferJobRequest, CreateMetadataTransferJobResponse, CreateMetadataTransferJobError, Credentials | HttpClient.HttpClient>;
export type CreateSceneError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a scene.
 */
export declare const createScene: API.OperationMethod<CreateSceneRequest, CreateSceneResponse, CreateSceneError, Credentials | HttpClient.HttpClient>;
export type CreateSyncJobError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action creates a SyncJob.
 */
export declare const createSyncJob: API.OperationMethod<CreateSyncJobRequest, CreateSyncJobResponse, CreateSyncJobError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspaceError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a workplace.
 */
export declare const createWorkspace: API.OperationMethod<CreateWorkspaceRequest, CreateWorkspaceResponse, CreateWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DeleteComponentTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a component type.
 */
export declare const deleteComponentType: API.OperationMethod<DeleteComponentTypeRequest, DeleteComponentTypeResponse, DeleteComponentTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteEntityError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an entity.
 */
export declare const deleteEntity: API.OperationMethod<DeleteEntityRequest, DeleteEntityResponse, DeleteEntityError, Credentials | HttpClient.HttpClient>;
export type DeleteSceneError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a scene.
 */
export declare const deleteScene: API.OperationMethod<DeleteSceneRequest, DeleteSceneResponse, DeleteSceneError, Credentials | HttpClient.HttpClient>;
export type DeleteSyncJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete the SyncJob.
 */
export declare const deleteSyncJob: API.OperationMethod<DeleteSyncJobRequest, DeleteSyncJobResponse, DeleteSyncJobError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkspaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a workspace.
 */
export declare const deleteWorkspace: API.OperationMethod<DeleteWorkspaceRequest, DeleteWorkspaceResponse, DeleteWorkspaceError, Credentials | HttpClient.HttpClient>;
export type ExecuteQueryError = AccessDeniedException | InternalServerException | QueryTimeoutException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Run queries to access information from your knowledge graph of entities within
 * individual workspaces.
 *
 * The ExecuteQuery action only works with Amazon Web Services Java SDK2.
 * ExecuteQuery will not work with any Amazon Web Services Java SDK version < 2.x.
 */
export declare const executeQuery: API.PaginatedOperationMethod<ExecuteQueryRequest, ExecuteQueryResponse, ExecuteQueryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetComponentTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a component type.
 */
export declare const getComponentType: API.OperationMethod<GetComponentTypeRequest, GetComponentTypeResponse, GetComponentTypeError, Credentials | HttpClient.HttpClient>;
export type GetEntityError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an entity.
 */
export declare const getEntity: API.OperationMethod<GetEntityRequest, GetEntityResponse, GetEntityError, Credentials | HttpClient.HttpClient>;
export type GetMetadataTransferJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a nmetadata transfer job.
 */
export declare const getMetadataTransferJob: API.OperationMethod<GetMetadataTransferJobRequest, GetMetadataTransferJobResponse, GetMetadataTransferJobError, Credentials | HttpClient.HttpClient>;
export type GetPricingPlanError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the pricing plan.
 */
export declare const getPricingPlan: API.OperationMethod<GetPricingPlanRequest, GetPricingPlanResponse, GetPricingPlanError, Credentials | HttpClient.HttpClient>;
export type GetPropertyValueError = AccessDeniedException | ConnectorFailureException | ConnectorTimeoutException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the property values for a component, component type, entity, or workspace.
 *
 * You must specify a value for either `componentName`,
 * `componentTypeId`, `entityId`, or `workspaceId`.
 */
export declare const getPropertyValue: API.PaginatedOperationMethod<GetPropertyValueRequest, GetPropertyValueResponse, GetPropertyValueError, Credentials | HttpClient.HttpClient, unknown>;
export type GetPropertyValueHistoryError = AccessDeniedException | ConnectorFailureException | ConnectorTimeoutException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the history of a time series property value for a component,
 * component type, entity, or workspace.
 *
 * You must specify a value for `workspaceId`. For entity-specific queries,
 * specify values for `componentName` and `entityId`. For cross-entity
 * quries, specify a value for `componentTypeId`.
 */
export declare const getPropertyValueHistory: API.PaginatedOperationMethod<GetPropertyValueHistoryRequest, GetPropertyValueHistoryResponse, GetPropertyValueHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetSceneError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a scene.
 */
export declare const getScene: API.OperationMethod<GetSceneRequest, GetSceneResponse, GetSceneError, Credentials | HttpClient.HttpClient>;
export type GetSyncJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the SyncJob.
 */
export declare const getSyncJob: API.OperationMethod<GetSyncJobRequest, GetSyncJobResponse, GetSyncJobError, Credentials | HttpClient.HttpClient>;
export type GetWorkspaceError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a workspace.
 */
export declare const getWorkspace: API.OperationMethod<GetWorkspaceRequest, GetWorkspaceResponse, GetWorkspaceError, Credentials | HttpClient.HttpClient>;
export type ListComponentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This API lists the components of an entity.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsRequest, ListComponentsResponse, ListComponentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListComponentTypesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all component types in a workspace.
 */
export declare const listComponentTypes: API.PaginatedOperationMethod<ListComponentTypesRequest, ListComponentTypesResponse, ListComponentTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEntitiesError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all entities in a workspace.
 */
export declare const listEntities: API.PaginatedOperationMethod<ListEntitiesRequest, ListEntitiesResponse, ListEntitiesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMetadataTransferJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the metadata transfer jobs.
 */
export declare const listMetadataTransferJobs: API.PaginatedOperationMethod<ListMetadataTransferJobsRequest, ListMetadataTransferJobsResponse, ListMetadataTransferJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPropertiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This API lists the properties of a component.
 */
export declare const listProperties: API.PaginatedOperationMethod<ListPropertiesRequest, ListPropertiesResponse, ListPropertiesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListScenesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all scenes in a workspace.
 */
export declare const listScenes: API.PaginatedOperationMethod<ListScenesRequest, ListScenesResponse, ListScenesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSyncJobsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all SyncJobs.
 */
export declare const listSyncJobs: API.PaginatedOperationMethod<ListSyncJobsRequest, ListSyncJobsResponse, ListSyncJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSyncResourcesError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the sync resources.
 */
export declare const listSyncResources: API.PaginatedOperationMethod<ListSyncResourcesRequest, ListSyncResourcesResponse, ListSyncResourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Lists all tags associated with a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkspacesError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about workspaces in the current account.
 */
export declare const listWorkspaces: API.PaginatedOperationMethod<ListWorkspacesRequest, ListWorkspacesResponse, ListWorkspacesError, Credentials | HttpClient.HttpClient, unknown>;
export type TagResourceError = AccessDeniedException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Adds tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateComponentTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates information in a component type.
 */
export declare const updateComponentType: API.OperationMethod<UpdateComponentTypeRequest, UpdateComponentTypeResponse, UpdateComponentTypeError, Credentials | HttpClient.HttpClient>;
export type UpdateEntityError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an entity.
 */
export declare const updateEntity: API.OperationMethod<UpdateEntityRequest, UpdateEntityResponse, UpdateEntityError, Credentials | HttpClient.HttpClient>;
export type UpdatePricingPlanError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the pricing plan.
 */
export declare const updatePricingPlan: API.OperationMethod<UpdatePricingPlanRequest, UpdatePricingPlanResponse, UpdatePricingPlanError, Credentials | HttpClient.HttpClient>;
export type UpdateSceneError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a scene.
 */
export declare const updateScene: API.OperationMethod<UpdateSceneRequest, UpdateSceneResponse, UpdateSceneError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkspaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a workspace.
 */
export declare const updateWorkspace: API.OperationMethod<UpdateWorkspaceRequest, UpdateWorkspaceResponse, UpdateWorkspaceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iottwinmaker.d.ts.map