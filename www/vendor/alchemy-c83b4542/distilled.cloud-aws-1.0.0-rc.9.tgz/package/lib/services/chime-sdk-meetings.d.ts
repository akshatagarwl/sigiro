import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.Class<ForbiddenException, S.TaggedStruct<"ForbiddenException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
    readonly ResourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceFailureException_base: S.Class<ServiceFailureException, S.TaggedStruct<"ServiceFailureException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceFailureException extends /*@__PURE__*/ ServiceFailureException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
    readonly RetryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
    readonly ResourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const UnprocessableEntityException_base: S.Class<UnprocessableEntityException, S.TaggedStruct<"UnprocessableEntityException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
export type GuidString = string;
export type ExternalUserId = string | redacted.Redacted<string>;
export type MediaCapabilities = "SendReceive" | "Send" | "Receive" | "None" | (string & {});
export declare const MediaCapabilities: any;
export interface AttendeeCapabilities {
    Audio: MediaCapabilities;
    Video: MediaCapabilities;
    Content: MediaCapabilities;
}
export declare const AttendeeCapabilities: S.Schema<AttendeeCapabilities>;
export interface CreateAttendeeRequestItem {
    ExternalUserId: string | redacted.Redacted<string>;
    Capabilities?: AttendeeCapabilities;
}
export declare const CreateAttendeeRequestItem: S.Schema<CreateAttendeeRequestItem>;
export type CreateAttendeeRequestItemList = CreateAttendeeRequestItem[];
export declare const CreateAttendeeRequestItemList: any;
export interface BatchCreateAttendeeRequest {
    MeetingId: string;
    Attendees: CreateAttendeeRequestItem[];
}
export declare const BatchCreateAttendeeRequest: S.Schema<BatchCreateAttendeeRequest>;
export type JoinTokenString = string | redacted.Redacted<string>;
export interface Attendee {
    ExternalUserId?: string | redacted.Redacted<string>;
    AttendeeId?: string;
    JoinToken?: string | redacted.Redacted<string>;
    Capabilities?: AttendeeCapabilities;
}
export declare const Attendee: S.Schema<Attendee>;
export type AttendeeList = Attendee[];
export declare const AttendeeList: any;
export interface CreateAttendeeError_ {
    ExternalUserId?: string | redacted.Redacted<string>;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const CreateAttendeeError_: S.Schema<CreateAttendeeError_>;
export type BatchCreateAttendeeErrorList = CreateAttendeeError_[];
export declare const BatchCreateAttendeeErrorList: any;
export interface BatchCreateAttendeeResponse {
    Attendees?: Attendee[];
    Errors?: CreateAttendeeError_[];
}
export declare const BatchCreateAttendeeResponse: S.Schema<BatchCreateAttendeeResponse>;
export interface AttendeeIdItem {
    AttendeeId: string;
}
export declare const AttendeeIdItem: S.Schema<AttendeeIdItem>;
export type AttendeeIdsList = AttendeeIdItem[];
export declare const AttendeeIdsList: any;
export interface BatchUpdateAttendeeCapabilitiesExceptRequest {
    MeetingId: string;
    ExcludedAttendeeIds: AttendeeIdItem[];
    Capabilities: AttendeeCapabilities;
}
export declare const BatchUpdateAttendeeCapabilitiesExceptRequest: S.Schema<BatchUpdateAttendeeCapabilitiesExceptRequest>;
export interface BatchUpdateAttendeeCapabilitiesExceptResponse {
}
export declare const BatchUpdateAttendeeCapabilitiesExceptResponse: S.Schema<BatchUpdateAttendeeCapabilitiesExceptResponse>;
export interface CreateAttendeeRequest {
    MeetingId: string;
    ExternalUserId: string | redacted.Redacted<string>;
    Capabilities?: AttendeeCapabilities;
}
export declare const CreateAttendeeRequest: S.Schema<CreateAttendeeRequest>;
export interface CreateAttendeeResponse {
    Attendee?: Attendee;
}
export declare const CreateAttendeeResponse: S.Schema<CreateAttendeeResponse>;
export type ClientRequestToken = string | redacted.Redacted<string>;
export type MediaRegion = string;
export type ExternalMeetingId = string | redacted.Redacted<string>;
export type Arn = string | redacted.Redacted<string>;
export interface NotificationsConfiguration {
    LambdaFunctionArn?: string | redacted.Redacted<string>;
    SnsTopicArn?: string | redacted.Redacted<string>;
    SqsQueueArn?: string | redacted.Redacted<string>;
}
export declare const NotificationsConfiguration: S.Schema<NotificationsConfiguration>;
export type MeetingFeatureStatus = "AVAILABLE" | "UNAVAILABLE" | (string & {});
export declare const MeetingFeatureStatus: any;
export interface AudioFeatures {
    EchoReduction?: MeetingFeatureStatus;
}
export declare const AudioFeatures: S.Schema<AudioFeatures>;
export type VideoResolution = "None" | "HD" | "FHD" | (string & {});
export declare const VideoResolution: any;
export interface VideoFeatures {
    MaxResolution?: VideoResolution;
}
export declare const VideoFeatures: S.Schema<VideoFeatures>;
export type ContentResolution = "None" | "FHD" | "UHD" | (string & {});
export declare const ContentResolution: any;
export interface ContentFeatures {
    MaxResolution?: ContentResolution;
}
export declare const ContentFeatures: S.Schema<ContentFeatures>;
export type AttendeeMax = number;
export interface AttendeeFeatures {
    MaxCount?: number;
}
export declare const AttendeeFeatures: S.Schema<AttendeeFeatures>;
export interface MeetingFeaturesConfiguration {
    Audio?: AudioFeatures;
    Video?: VideoFeatures;
    Content?: ContentFeatures;
    Attendee?: AttendeeFeatures;
}
export declare const MeetingFeaturesConfiguration: S.Schema<MeetingFeaturesConfiguration>;
export type PrimaryMeetingId = string;
export type TenantId = string;
export type TenantIdList = string[];
export declare const TenantIdList: any;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type MediaPlacementNetworkType = "Ipv4Only" | "DualStack" | (string & {});
export declare const MediaPlacementNetworkType: any;
export interface CreateMeetingRequest {
    ClientRequestToken: string | redacted.Redacted<string>;
    MediaRegion: string;
    MeetingHostId?: string | redacted.Redacted<string>;
    ExternalMeetingId: string | redacted.Redacted<string>;
    NotificationsConfiguration?: NotificationsConfiguration;
    MeetingFeatures?: MeetingFeaturesConfiguration;
    PrimaryMeetingId?: string;
    TenantIds?: string[];
    Tags?: Tag[];
    MediaPlacementNetworkType?: MediaPlacementNetworkType;
}
export declare const CreateMeetingRequest: S.Schema<CreateMeetingRequest>;
export interface MediaPlacement {
    AudioHostUrl?: string;
    AudioFallbackUrl?: string;
    SignalingUrl?: string;
    TurnControlUrl?: string;
    ScreenDataUrl?: string;
    ScreenViewingUrl?: string;
    ScreenSharingUrl?: string;
    EventIngestionUrl?: string;
}
export declare const MediaPlacement: S.Schema<MediaPlacement>;
export type AmazonResourceName = string;
export interface Meeting {
    MeetingId?: string;
    MeetingHostId?: string | redacted.Redacted<string>;
    ExternalMeetingId?: string | redacted.Redacted<string>;
    MediaRegion?: string;
    MediaPlacement?: MediaPlacement;
    MeetingFeatures?: MeetingFeaturesConfiguration;
    PrimaryMeetingId?: string;
    TenantIds?: string[];
    MeetingArn?: string;
}
export declare const Meeting: S.Schema<Meeting>;
export interface CreateMeetingResponse {
    Meeting?: Meeting;
}
export declare const CreateMeetingResponse: S.Schema<CreateMeetingResponse>;
export type CreateMeetingWithAttendeesRequestItemList = CreateAttendeeRequestItem[];
export declare const CreateMeetingWithAttendeesRequestItemList: any;
export interface CreateMeetingWithAttendeesRequest {
    ClientRequestToken: string | redacted.Redacted<string>;
    MediaRegion: string;
    MeetingHostId?: string | redacted.Redacted<string>;
    ExternalMeetingId: string | redacted.Redacted<string>;
    MeetingFeatures?: MeetingFeaturesConfiguration;
    NotificationsConfiguration?: NotificationsConfiguration;
    Attendees: CreateAttendeeRequestItem[];
    PrimaryMeetingId?: string;
    TenantIds?: string[];
    Tags?: Tag[];
    MediaPlacementNetworkType?: MediaPlacementNetworkType;
}
export declare const CreateMeetingWithAttendeesRequest: S.Schema<CreateMeetingWithAttendeesRequest>;
export interface CreateMeetingWithAttendeesResponse {
    Meeting?: Meeting;
    Attendees?: Attendee[];
    Errors?: CreateAttendeeError_[];
}
export declare const CreateMeetingWithAttendeesResponse: S.Schema<CreateMeetingWithAttendeesResponse>;
export interface DeleteAttendeeRequest {
    MeetingId: string;
    AttendeeId: string;
}
export declare const DeleteAttendeeRequest: S.Schema<DeleteAttendeeRequest>;
export interface DeleteAttendeeResponse {
}
export declare const DeleteAttendeeResponse: S.Schema<DeleteAttendeeResponse>;
export interface DeleteMeetingRequest {
    MeetingId: string;
}
export declare const DeleteMeetingRequest: S.Schema<DeleteMeetingRequest>;
export interface DeleteMeetingResponse {
}
export declare const DeleteMeetingResponse: S.Schema<DeleteMeetingResponse>;
export interface GetAttendeeRequest {
    MeetingId: string;
    AttendeeId: string;
}
export declare const GetAttendeeRequest: S.Schema<GetAttendeeRequest>;
export interface GetAttendeeResponse {
    Attendee?: Attendee;
}
export declare const GetAttendeeResponse: S.Schema<GetAttendeeResponse>;
export interface GetMeetingRequest {
    MeetingId: string;
}
export declare const GetMeetingRequest: S.Schema<GetMeetingRequest>;
export interface GetMeetingResponse {
    Meeting?: Meeting;
}
export declare const GetMeetingResponse: S.Schema<GetMeetingResponse>;
export type ResultMax = number;
export interface ListAttendeesRequest {
    MeetingId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListAttendeesRequest: S.Schema<ListAttendeesRequest>;
export interface ListAttendeesResponse {
    Attendees?: Attendee[];
    NextToken?: string;
}
export declare const ListAttendeesResponse: S.Schema<ListAttendeesResponse>;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type TranscribeLanguageCode = "en-US" | "en-GB" | "es-US" | "fr-CA" | "fr-FR" | "en-AU" | "it-IT" | "de-DE" | "pt-BR" | "ja-JP" | "ko-KR" | "zh-CN" | "th-TH" | "hi-IN" | (string & {});
export declare const TranscribeLanguageCode: any;
export type TranscribeVocabularyFilterMethod = "remove" | "mask" | "tag" | (string & {});
export declare const TranscribeVocabularyFilterMethod: any;
export type TranscribeRegion = "us-east-2" | "us-east-1" | "us-west-2" | "ap-northeast-2" | "ap-southeast-2" | "ap-northeast-1" | "ca-central-1" | "eu-central-1" | "eu-west-1" | "eu-west-2" | "sa-east-1" | "auto" | "us-gov-west-1" | (string & {});
export declare const TranscribeRegion: any;
export type TranscribePartialResultsStability = "low" | "medium" | "high" | (string & {});
export declare const TranscribePartialResultsStability: any;
export type TranscribeContentIdentificationType = "PII" | (string & {});
export declare const TranscribeContentIdentificationType: any;
export type TranscribeContentRedactionType = "PII" | (string & {});
export declare const TranscribeContentRedactionType: any;
export type TranscribePiiEntityTypes = string;
export type TranscribeLanguageModelName = string;
export type TranscribeLanguageOptions = string;
export type TranscribeVocabularyNamesOrFilterNamesString = string;
export interface EngineTranscribeSettings {
    LanguageCode?: TranscribeLanguageCode;
    VocabularyFilterMethod?: TranscribeVocabularyFilterMethod;
    VocabularyFilterName?: string;
    VocabularyName?: string;
    Region?: TranscribeRegion;
    EnablePartialResultsStabilization?: boolean;
    PartialResultsStability?: TranscribePartialResultsStability;
    ContentIdentificationType?: TranscribeContentIdentificationType;
    ContentRedactionType?: TranscribeContentRedactionType;
    PiiEntityTypes?: string;
    LanguageModelName?: string;
    IdentifyLanguage?: boolean;
    LanguageOptions?: string;
    PreferredLanguage?: TranscribeLanguageCode;
    VocabularyNames?: string;
    VocabularyFilterNames?: string;
}
export declare const EngineTranscribeSettings: S.Schema<EngineTranscribeSettings>;
export type TranscribeMedicalLanguageCode = "en-US" | (string & {});
export declare const TranscribeMedicalLanguageCode: any;
export type TranscribeMedicalSpecialty = "PRIMARYCARE" | "CARDIOLOGY" | "NEUROLOGY" | "ONCOLOGY" | "RADIOLOGY" | "UROLOGY" | (string & {});
export declare const TranscribeMedicalSpecialty: any;
export type TranscribeMedicalType = "CONVERSATION" | "DICTATION" | (string & {});
export declare const TranscribeMedicalType: any;
export type TranscribeMedicalRegion = "us-east-1" | "us-east-2" | "us-west-2" | "ap-southeast-2" | "ca-central-1" | "eu-west-1" | "auto" | (string & {});
export declare const TranscribeMedicalRegion: any;
export type TranscribeMedicalContentIdentificationType = "PHI" | (string & {});
export declare const TranscribeMedicalContentIdentificationType: any;
export interface EngineTranscribeMedicalSettings {
    LanguageCode: TranscribeMedicalLanguageCode;
    Specialty: TranscribeMedicalSpecialty;
    Type: TranscribeMedicalType;
    VocabularyName?: string;
    Region?: TranscribeMedicalRegion;
    ContentIdentificationType?: TranscribeMedicalContentIdentificationType;
}
export declare const EngineTranscribeMedicalSettings: S.Schema<EngineTranscribeMedicalSettings>;
export interface TranscriptionConfiguration {
    EngineTranscribeSettings?: EngineTranscribeSettings;
    EngineTranscribeMedicalSettings?: EngineTranscribeMedicalSettings;
}
export declare const TranscriptionConfiguration: S.Schema<TranscriptionConfiguration>;
export interface StartMeetingTranscriptionRequest {
    MeetingId: string;
    TranscriptionConfiguration: TranscriptionConfiguration;
}
export declare const StartMeetingTranscriptionRequest: S.Schema<StartMeetingTranscriptionRequest>;
export interface StartMeetingTranscriptionResponse {
}
export declare const StartMeetingTranscriptionResponse: S.Schema<StartMeetingTranscriptionResponse>;
export interface StopMeetingTranscriptionRequest {
    MeetingId: string;
}
export declare const StopMeetingTranscriptionRequest: S.Schema<StopMeetingTranscriptionRequest>;
export interface StopMeetingTranscriptionResponse {
}
export declare const StopMeetingTranscriptionResponse: S.Schema<StopMeetingTranscriptionResponse>;
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAttendeeCapabilitiesRequest {
    MeetingId: string;
    AttendeeId: string;
    Capabilities: AttendeeCapabilities;
}
export declare const UpdateAttendeeCapabilitiesRequest: S.Schema<UpdateAttendeeCapabilitiesRequest>;
export interface UpdateAttendeeCapabilitiesResponse {
    Attendee?: Attendee;
}
export declare const UpdateAttendeeCapabilitiesResponse: S.Schema<UpdateAttendeeCapabilitiesResponse>;
export type RetryAfterSeconds = string;
export type BatchCreateAttendeeError = BadRequestException | ForbiddenException | LimitExceededException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | UnprocessableEntityException | CommonErrors;
/**
 * Creates up to 100 attendees for an active Amazon Chime SDK meeting. For more information about the Amazon Chime SDK, see
 * Using the Amazon Chime SDK in the *Amazon Chime Developer Guide*.
 */
export declare const batchCreateAttendee: API.OperationMethod<BatchCreateAttendeeRequest, BatchCreateAttendeeResponse, BatchCreateAttendeeError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateAttendeeCapabilitiesExceptError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Updates `AttendeeCapabilities` except the capabilities listed in an `ExcludedAttendeeIds` table.
 *
 * You use the capabilities with a set of values that control what the capabilities can do, such as `SendReceive` data. For more information about those values, see
 * .
 *
 * When using capabilities, be aware of these corner cases:
 *
 * - If you specify `MeetingFeatures:Video:MaxResolution:None` when you create a meeting, all API requests
 * that include `SendReceive`, `Send`, or `Receive` for `AttendeeCapabilities:Video` will be rejected with `ValidationError 400`.
 *
 * - If you specify `MeetingFeatures:Content:MaxResolution:None` when you create a meeting, all API requests that include `SendReceive`, `Send`, or
 * `Receive` for `AttendeeCapabilities:Content` will be rejected with `ValidationError 400`.
 *
 * - You can't set `content` capabilities to `SendReceive` or `Receive` unless you also set `video` capabilities to `SendReceive`
 * or `Receive`. If you don't set the `video` capability to receive, the response will contain an HTTP 400 Bad Request status code. However, you can set your `video` capability
 * to receive and you set your `content` capability to not receive.
 *
 * - If meeting features is defined as `Video:MaxResolution:None` but
 * `Content:MaxResolution` is defined as something other than
 * `None` and attendee capabilities are not defined in the API
 * request, then the default attendee video capability is set to
 * `Receive` and attendee content capability is set to
 * `SendReceive`. This is because content `SendReceive`
 * requires video to be at least `Receive`.
 *
 * - When you change an `audio` capability from `None` or `Receive` to `Send` or `SendReceive` ,
 * and if the attendee left their microphone unmuted, audio will flow from the attendee to the other meeting participants.
 *
 * - When you change a `video` or `content` capability from `None` or `Receive` to `Send` or `SendReceive` ,
 * and if the attendee turned on their video or content streams, remote attendees can receive those streams, but only after media renegotiation between the client and the Amazon Chime back-end server.
 */
export declare const batchUpdateAttendeeCapabilitiesExcept: API.OperationMethod<BatchUpdateAttendeeCapabilitiesExceptRequest, BatchUpdateAttendeeCapabilitiesExceptResponse, BatchUpdateAttendeeCapabilitiesExceptError, Credentials | HttpClient.HttpClient>;
export type CreateAttendeeError = BadRequestException | ForbiddenException | LimitExceededException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | UnprocessableEntityException | CommonErrors;
/**
 * Creates a new attendee for an active Amazon Chime SDK meeting. For more information about the Amazon Chime SDK, see
 * Using the Amazon Chime SDK
 * in the
 * *Amazon Chime Developer Guide*.
 */
export declare const createAttendee: API.OperationMethod<CreateAttendeeRequest, CreateAttendeeResponse, CreateAttendeeError, Credentials | HttpClient.HttpClient>;
export type CreateMeetingError = BadRequestException | ConflictException | ForbiddenException | LimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Creates a new Amazon Chime SDK meeting in the specified media Region with no initial attendees. For more information about specifying media Regions, see
 * Available Regions and
 * Using meeting Regions, both
 * in the *Amazon Chime SDK Developer Guide*. For more information about the Amazon Chime SDK, see
 * Using the Amazon Chime SDK
 * in the
 * *Amazon Chime SDK Developer Guide*.
 *
 * If you use this API in conjuction with the and APIs, and you don't specify the
 * `MeetingFeatures.Content.MaxResolution` or `MeetingFeatures.Video.MaxResolution` parameters, the following defaults are used:
 *
 * - Content.MaxResolution: FHD
 *
 * - Video.MaxResolution: HD
 */
export declare const createMeeting: API.OperationMethod<CreateMeetingRequest, CreateMeetingResponse, CreateMeetingError, Credentials | HttpClient.HttpClient>;
export type CreateMeetingWithAttendeesError = BadRequestException | ConflictException | ForbiddenException | LimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Creates a new Amazon Chime SDK meeting in the specified media Region, with attendees. For more information about specifying media Regions, see
 * Available Regions and
 * Using meeting Regions, both
 * in the *Amazon Chime SDK Developer Guide*. For more information about the Amazon Chime SDK, see
 * Using the Amazon Chime SDK
 * in the
 * *Amazon Chime SDK Developer Guide*.
 *
 * If you use this API in conjuction with the and APIs, and you don't specify the
 * `MeetingFeatures.Content.MaxResolution` or `MeetingFeatures.Video.MaxResolution` parameters, the following defaults are used:
 *
 * - Content.MaxResolution: FHD
 *
 * - Video.MaxResolution: HD
 */
export declare const createMeetingWithAttendees: API.OperationMethod<CreateMeetingWithAttendeesRequest, CreateMeetingWithAttendeesResponse, CreateMeetingWithAttendeesError, Credentials | HttpClient.HttpClient>;
export type DeleteAttendeeError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Deletes an attendee from the specified Amazon Chime SDK meeting and deletes their
 * `JoinToken`. Attendees are automatically deleted when a Amazon Chime SDK meeting is deleted. For more information about the Amazon Chime SDK, see
 * Using the Amazon Chime SDK
 * in the *Amazon Chime Developer Guide*.
 */
export declare const deleteAttendee: API.OperationMethod<DeleteAttendeeRequest, DeleteAttendeeResponse, DeleteAttendeeError, Credentials | HttpClient.HttpClient>;
export type DeleteMeetingError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified Amazon Chime SDK meeting. The operation deletes all attendees, disconnects all clients, and prevents new clients from
 * joining the meeting. For more information about the Amazon Chime SDK, see
 * Using the Amazon Chime SDK in the
 * *Amazon Chime Developer Guide*.
 */
export declare const deleteMeeting: API.OperationMethod<DeleteMeetingRequest, DeleteMeetingResponse, DeleteMeetingError, Credentials | HttpClient.HttpClient>;
export type GetAttendeeError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Gets the Amazon Chime SDK attendee details for a specified meeting ID and attendee ID. For more information about the Amazon Chime SDK, see
 * Using the Amazon Chime SDK
 * in the *Amazon Chime Developer Guide*.
 */
export declare const getAttendee: API.OperationMethod<GetAttendeeRequest, GetAttendeeResponse, GetAttendeeError, Credentials | HttpClient.HttpClient>;
export type GetMeetingError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Gets the Amazon Chime SDK meeting details for the specified meeting ID. For more information about the Amazon Chime SDK, see
 * Using the Amazon Chime SDK
 * in the *Amazon Chime Developer Guide*.
 */
export declare const getMeeting: API.OperationMethod<GetMeetingRequest, GetMeetingResponse, GetMeetingError, Credentials | HttpClient.HttpClient>;
export type ListAttendeesError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Lists the attendees for the specified Amazon Chime SDK meeting. For more information about the Amazon Chime SDK, see
 * Using the Amazon Chime SDK
 * in the *Amazon Chime Developer Guide*.
 */
export declare const listAttendees: API.PaginatedOperationMethod<ListAttendeesRequest, ListAttendeesResponse, ListAttendeesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | LimitExceededException | ResourceNotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of the tags available for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartMeetingTranscriptionError = BadRequestException | ForbiddenException | LimitExceededException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | UnprocessableEntityException | CommonErrors;
/**
 * Starts transcription for the specified `meetingId`. For more information, refer to
 * Using Amazon Chime SDK live transcription
 * in the *Amazon Chime SDK Developer Guide*.
 *
 * If you specify an invalid configuration, a `TranscriptFailed` event will be sent with the contents of the `BadRequestException` generated by Amazon Transcribe.
 * For more information on each parameter and which combinations are valid, refer to the
 * StartStreamTranscription API in the
 * *Amazon Transcribe Developer Guide*.
 *
 * By default, Amazon Transcribe may use and store audio content processed by the service to develop and improve Amazon Web Services AI/ML services as
 * further described in section 50 of the Amazon Web Services Service Terms. Using Amazon Transcribe
 * may be subject to federal and state laws or regulations regarding the recording or interception of electronic communications. It is your and your end users’
 * responsibility to comply with all applicable laws regarding the recording, including properly notifying all participants in a recorded session or communication
 * that the session or communication is being recorded, and obtaining all necessary consents. You can opt out from Amazon Web Services using audio content to develop and
 * improve AWS AI/ML services by configuring an AI services opt out policy using Amazon Web Services Organizations.
 */
export declare const startMeetingTranscription: API.OperationMethod<StartMeetingTranscriptionRequest, StartMeetingTranscriptionResponse, StartMeetingTranscriptionError, Credentials | HttpClient.HttpClient>;
export type StopMeetingTranscriptionError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | UnprocessableEntityException | CommonErrors;
/**
 * Stops transcription for the specified `meetingId`. For more information, refer to
 * Using Amazon Chime SDK live transcription
 * in the *Amazon Chime SDK Developer Guide*.
 *
 * By default, Amazon Transcribe may use and store audio content processed by the service to develop and improve Amazon Web Services AI/ML services as
 * further described in section 50 of the Amazon Web Services Service Terms. Using Amazon Transcribe
 * may be subject to federal and state laws or regulations regarding the recording or interception of electronic communications. It is your and your end users’
 * responsibility to comply with all applicable laws regarding the recording, including properly notifying all participants in a recorded session or communication
 * that the session or communication is being recorded, and obtaining all necessary consents. You can opt out from Amazon Web Services using audio content to develop and
 * improve Amazon Web Services AI/ML services by configuring an AI services opt out policy using Amazon Web Services Organizations.
 */
export declare const stopMeetingTranscription: API.OperationMethod<StopMeetingTranscriptionRequest, StopMeetingTranscriptionResponse, StopMeetingTranscriptionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ForbiddenException | LimitExceededException | ResourceNotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | TooManyTagsException | UnauthorizedException | CommonErrors;
/**
 * The resource that supports tags.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | LimitExceededException | ResourceNotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Removes the specified tags from the specified resources. When you specify a tag key, the action removes both that key and its associated value. The operation succeeds even if you
 * attempt to remove tags from a resource that were already removed. Note the following:
 *
 * - To remove tags from a resource, you need the necessary permissions for the service that the resource belongs to as well as permissions for removing tags. For more information,
 * see the documentation for the service whose resource you want to untag.
 *
 * - You can only tag resources that are located in the specified Amazon Web Services Region for the calling Amazon Web Services account.
 *
 * **Minimum permissions**
 *
 * In addition to the `tag:UntagResources` permission required by this operation, you must also have the remove tags permission defined by the service that created the resource.
 * For example, to remove the tags from an Amazon EC2 instance using the `UntagResources` operation, you must have both of the following permissions:
 *
 * `tag:UntagResource`
 *
 * `ChimeSDKMeetings:DeleteTags`
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAttendeeCapabilitiesError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * The capabilities that you want to update.
 *
 * You use the capabilities with a set of values that control what the capabilities can do, such as `SendReceive` data. For more information about those values, see
 * .
 *
 * When using capabilities, be aware of these corner cases:
 *
 * - If you specify `MeetingFeatures:Video:MaxResolution:None` when you create a meeting, all API requests
 * that include `SendReceive`, `Send`, or `Receive` for `AttendeeCapabilities:Video` will be rejected with `ValidationError 400`.
 *
 * - If you specify `MeetingFeatures:Content:MaxResolution:None` when you create a meeting, all API requests that include `SendReceive`, `Send`, or
 * `Receive` for `AttendeeCapabilities:Content` will be rejected with `ValidationError 400`.
 *
 * - You can't set `content` capabilities to `SendReceive` or `Receive` unless you also set `video` capabilities to `SendReceive`
 * or `Receive`. If you don't set the `video` capability to receive, the response will contain an HTTP 400 Bad Request status code. However, you can set your `video` capability
 * to receive and you set your `content` capability to not receive.
 *
 * - If meeting features is defined as `Video:MaxResolution:None` but
 * `Content:MaxResolution` is defined as something other than
 * `None` and attendee capabilities are not defined in the API
 * request, then the default attendee video capability is set to
 * `Receive` and attendee content capability is set to
 * `SendReceive`. This is because content `SendReceive`
 * requires video to be at least `Receive`.
 *
 * - When you change an `audio` capability from `None` or `Receive` to `Send` or `SendReceive` ,
 * and if the attendee left their microphone unmuted, audio will flow from the attendee to the other meeting participants.
 *
 * - When you change a `video` or `content` capability from `None` or `Receive` to `Send` or `SendReceive` ,
 * and if the attendee turned on their video or content streams, remote attendees can receive those streams, but only after media renegotiation between the client and the Amazon Chime back-end server.
 */
export declare const updateAttendeeCapabilities: API.OperationMethod<UpdateAttendeeCapabilitiesRequest, UpdateAttendeeCapabilitiesResponse, UpdateAttendeeCapabilitiesError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=chime-sdk-meetings.d.ts.map