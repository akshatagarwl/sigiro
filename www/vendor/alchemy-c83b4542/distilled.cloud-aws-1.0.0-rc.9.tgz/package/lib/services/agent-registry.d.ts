import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RegistryIdentifier = string;
export type RecordIdentifier = string;
export type RegistryRecordIdList = string[];
export declare const RegistryRecordIdList: any;
export interface RegistryRecordsEntry {
    registryId: string;
    recordIds: string[];
}
export declare const RegistryRecordsEntry: S.Schema<RegistryRecordsEntry>;
export type RegistryRecordsEntryList = RegistryRecordsEntry[];
export declare const RegistryRecordsEntryList: any;
export interface BatchGetDiscoverableRegistryRecordRequest {
    entries: RegistryRecordsEntry[];
}
export declare const BatchGetDiscoverableRegistryRecordRequest: S.Schema<BatchGetDiscoverableRegistryRecordRequest>;
export type RegistryArn = string;
export type RegistryRecordArn = string;
export type RegistryRecordId = string;
export type RegistryRecordName = string;
export type Description = string | redacted.Redacted<string>;
export type RegistryRecordDisplayName = string;
export type RecordType = "MCP" | "AGENT" | "CUSTOM" | "SKILL" | (string & {});
export declare const RecordType: any;
export type DescriptorData = string | redacted.Redacted<string>;
export type DataSchemaVersion = string;
export interface McpToolsDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
}
export declare const McpToolsDescriptor: S.Schema<McpToolsDescriptor>;
export interface McpServerAdditionalData {
    tools?: McpToolsDescriptor;
}
export declare const McpServerAdditionalData: S.Schema<McpServerAdditionalData>;
export type DescriptorSourceUrl = string;
export interface DescriptorSourceFromUrl {
    url: string;
}
export declare const DescriptorSourceFromUrl: S.Schema<DescriptorSourceFromUrl>;
export interface DescriptorSource {
    fromUrl?: DescriptorSourceFromUrl;
}
export declare const DescriptorSource: S.Schema<DescriptorSource>;
export interface McpServerDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
    additionalData?: McpServerAdditionalData;
    source?: DescriptorSource;
}
export declare const McpServerDescriptor: S.Schema<McpServerDescriptor>;
export interface A2aAgentCardDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
    source?: DescriptorSource;
}
export declare const A2aAgentCardDescriptor: S.Schema<A2aAgentCardDescriptor>;
export interface AgentSkillsMdDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
    source?: DescriptorSource;
}
export declare const AgentSkillsMdDescriptor: S.Schema<AgentSkillsMdDescriptor>;
export interface AgentSkillsAdditionalData {
    skillMd?: AgentSkillsMdDescriptor;
}
export declare const AgentSkillsAdditionalData: S.Schema<AgentSkillsAdditionalData>;
export interface AgentSkillsDefinitionDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
    additionalData?: AgentSkillsAdditionalData;
}
export declare const AgentSkillsDefinitionDescriptor: S.Schema<AgentSkillsDefinitionDescriptor>;
export interface CustomDescriptor {
    data?: string | redacted.Redacted<string>;
}
export declare const CustomDescriptor: S.Schema<CustomDescriptor>;
export interface Descriptors {
    mcpServer?: McpServerDescriptor;
    a2aAgentCard?: A2aAgentCardDescriptor;
    agentSkillsDefinition?: AgentSkillsDefinitionDescriptor;
    custom?: CustomDescriptor;
}
export declare const Descriptors: S.Schema<Descriptors>;
export type RegistryRecordVersion = string;
export type RegistryRecordStatus = "DRAFT" | "PENDING_APPROVAL" | "APPROVED" | "REJECTED" | "DEPRECATED" | "CREATING" | "UPDATING" | "CREATE_FAILED" | "UPDATE_FAILED" | (string & {});
export declare const RegistryRecordStatus: any;
export interface RegistryRecordSummary {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    displayName?: string;
    recordType: RecordType;
    descriptors: Descriptors;
    recordVersion: string;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const RegistryRecordSummary: S.Schema<RegistryRecordSummary>;
export type RegistryRecordSummaryList = RegistryRecordSummary[];
export declare const RegistryRecordSummaryList: any;
export type BatchGetDiscoverableRegistryRecordErrorCode = "RESOURCE_NOT_FOUND" | "ACCESS_DENIED" | "INTERNAL_ERROR" | (string & {});
export declare const BatchGetDiscoverableRegistryRecordErrorCode: any;
export interface BatchGetDiscoverableRegistryRecordError_ {
    registryId: string;
    recordId: string;
    errorCode: BatchGetDiscoverableRegistryRecordErrorCode;
    message?: string;
}
export declare const BatchGetDiscoverableRegistryRecordError_: S.Schema<BatchGetDiscoverableRegistryRecordError_>;
export type BatchGetDiscoverableRegistryRecordErrorList = BatchGetDiscoverableRegistryRecordError_[];
export declare const BatchGetDiscoverableRegistryRecordErrorList: any;
export interface BatchGetDiscoverableRegistryRecordResponse {
    registryRecords: RegistryRecordSummary[];
    errors: BatchGetDiscoverableRegistryRecordError_[];
}
export declare const BatchGetDiscoverableRegistryRecordResponse: S.Schema<BatchGetDiscoverableRegistryRecordResponse>;
export type RegistryRecordFilterName = "recordType" | "descriptorType" | (string & {});
export declare const RegistryRecordFilterName: any;
export type FilterValue = string;
export type DiscoverableFilterValues = string[];
export declare const DiscoverableFilterValues: any;
export interface RegistryRecordFilter {
    name: RegistryRecordFilterName;
    values: string[];
}
export declare const RegistryRecordFilter: S.Schema<RegistryRecordFilter>;
export type RegistryRecordFilterList = RegistryRecordFilter[];
export declare const RegistryRecordFilterList: any;
export interface ListDiscoverableRegistryRecordsRequest {
    registryId: string;
    maxResults?: number;
    nextToken?: string;
    filters?: RegistryRecordFilter[];
}
export declare const ListDiscoverableRegistryRecordsRequest: S.Schema<ListDiscoverableRegistryRecordsRequest>;
export interface DiscoverableRegistryRecordSummary {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    displayName?: string;
    recordType: RecordType;
    recordVersion: string;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const DiscoverableRegistryRecordSummary: S.Schema<DiscoverableRegistryRecordSummary>;
export type DiscoverableRegistryRecordSummaryList = DiscoverableRegistryRecordSummary[];
export declare const DiscoverableRegistryRecordSummaryList: any;
export interface ListDiscoverableRegistryRecordsResponse {
    registryRecords: DiscoverableRegistryRecordSummary[];
    nextToken?: string;
}
export declare const ListDiscoverableRegistryRecordsResponse: S.Schema<ListDiscoverableRegistryRecordsResponse>;
export type SearchQuery = string | redacted.Redacted<string>;
export type RegistryIdList = string[];
export declare const RegistryIdList: any;
export type MetadataFilterExpression = unknown;
export interface SearchDiscoverableRegistryRecordsRequest {
    searchQuery: string | redacted.Redacted<string>;
    registryIds: string[];
    maxResults?: number;
    filters?: any;
}
export declare const SearchDiscoverableRegistryRecordsRequest: S.Schema<SearchDiscoverableRegistryRecordsRequest>;
export interface SearchDiscoverableRegistryRecordsResponse {
    registryRecords: RegistryRecordSummary[];
}
export declare const SearchDiscoverableRegistryRecordsResponse: S.Schema<SearchDiscoverableRegistryRecordsResponse>;
export type NonBlankString = string;
export type ValidationExceptionReason = "CannotParse" | "FieldValidationFailed" | "IdempotentParameterMismatchException" | "EventInOtherSession" | "ResourceConflict" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type BatchGetDiscoverableRegistryRecordError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves multiple discoverable registry records by ID from a single registry. Records that cannot be retrieved are reported individually in the `errors` list rather than failing the entire request.
 */
export declare const batchGetDiscoverableRegistryRecord: API.OperationMethod<BatchGetDiscoverableRegistryRecordRequest, BatchGetDiscoverableRegistryRecordResponse, BatchGetDiscoverableRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type ListDiscoverableRegistryRecordsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists the discoverable registry records in a registry. You can optionally filter and paginate the results.
 */
export declare const listDiscoverableRegistryRecords: API.PaginatedOperationMethod<ListDiscoverableRegistryRecordsRequest, ListDiscoverableRegistryRecordsResponse, ListDiscoverableRegistryRecordsError, Credentials | HttpClient.HttpClient, DiscoverableRegistryRecordSummary>;
export type SearchDiscoverableRegistryRecordsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Searches the discoverable registry records in a registry using a natural language query. Returns metadata for the matching records ordered by relevance.
 */
export declare const searchDiscoverableRegistryRecords: API.OperationMethod<SearchDiscoverableRegistryRecordsRequest, SearchDiscoverableRegistryRecordsResponse, SearchDiscoverableRegistryRecordsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=agent-registry.d.ts.map