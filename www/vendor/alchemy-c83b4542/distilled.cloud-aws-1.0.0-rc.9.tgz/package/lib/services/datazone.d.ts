import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DomainId = string;
export type AssetIdentifier = string;
export type Revision = string;
export type AcceptRuleBehavior = "ALL" | "NONE" | (string & {});
export declare const AcceptRuleBehavior: any;
export interface AcceptRule {
    rule?: AcceptRuleBehavior;
    threshold?: number;
}
export declare const AcceptRule: S.Schema<AcceptRule>;
export type EditedValue = string | redacted.Redacted<string>;
export interface AcceptChoice {
    predictionTarget?: string;
    predictionChoice?: number;
    editedValue?: string | redacted.Redacted<string>;
}
export declare const AcceptChoice: S.Schema<AcceptChoice>;
export type AcceptChoices = AcceptChoice[];
export declare const AcceptChoices: any;
export type ClientToken = string;
export interface AcceptPredictionsInput {
    domainIdentifier: string;
    identifier: string;
    revision?: string;
    acceptRule?: AcceptRule;
    acceptChoices?: AcceptChoice[];
    clientToken?: string;
}
export declare const AcceptPredictionsInput: S.Schema<AcceptPredictionsInput>;
export type AssetId = string;
export interface AcceptPredictionsOutput {
    domainId: string;
    assetId: string;
    revision: string;
}
export declare const AcceptPredictionsOutput: S.Schema<AcceptPredictionsOutput>;
export type SubscriptionRequestId = string;
export type DecisionComment = string | redacted.Redacted<string>;
export type FilterId = string;
export type FilterIds = string[];
export declare const FilterIds: any;
export interface AcceptedAssetScope {
    assetId: string;
    filterIds: string[];
}
export declare const AcceptedAssetScope: S.Schema<AcceptedAssetScope>;
export type AcceptedAssetScopes = AcceptedAssetScope[];
export declare const AcceptedAssetScopes: any;
export type S3Permission = "READ" | "WRITE" | (string & {});
export declare const S3Permission: any;
export type S3Permissions = S3Permission[];
export declare const S3Permissions: any;
export type Permissions = {
    s3: S3Permission[];
};
export declare const Permissions: any;
export interface AssetPermission {
    assetId: string;
    permissions: Permissions;
}
export declare const AssetPermission: S.Schema<AssetPermission>;
export type AssetPermissions = AssetPermission[];
export declare const AssetPermissions: any;
export interface AcceptSubscriptionRequestInput {
    domainIdentifier: string;
    identifier: string;
    decisionComment?: string | redacted.Redacted<string>;
    assetScopes?: AcceptedAssetScope[];
    assetPermissions?: AssetPermission[];
}
export declare const AcceptSubscriptionRequestInput: S.Schema<AcceptSubscriptionRequestInput>;
export type CreatedBy = string;
export type UpdatedBy = string;
export type SubscriptionRequestStatus = "PENDING" | "ACCEPTED" | "REJECTED" | (string & {});
export declare const SubscriptionRequestStatus: any;
export type CreatedAt = Date;
export type UpdatedAt = Date;
export type RequestReason = string | redacted.Redacted<string>;
export type ProjectId = string;
export type ProjectName = string | redacted.Redacted<string>;
export interface SubscribedProject {
    id?: string;
    name?: string | redacted.Redacted<string>;
}
export declare const SubscribedProject: S.Schema<SubscribedProject>;
export type UserProfileId = string;
export interface IamUserProfileDetails {
    arn?: string;
    principalId?: string;
    sessionName?: string;
    groupProfileId?: string;
}
export declare const IamUserProfileDetails: S.Schema<IamUserProfileDetails>;
export type UserProfileName = string | redacted.Redacted<string>;
export type FirstName = string | redacted.Redacted<string>;
export type LastName = string | redacted.Redacted<string>;
export interface SsoUserProfileDetails {
    username?: string | redacted.Redacted<string>;
    firstName?: string | redacted.Redacted<string>;
    lastName?: string | redacted.Redacted<string>;
}
export declare const SsoUserProfileDetails: S.Schema<SsoUserProfileDetails>;
export type UserProfileDetails = {
    iam: IamUserProfileDetails;
    sso?: never;
} | {
    iam?: never;
    sso: SsoUserProfileDetails;
};
export declare const UserProfileDetails: any;
export interface SubscribedUser {
    id?: string;
    details?: UserProfileDetails;
}
export declare const SubscribedUser: S.Schema<SubscribedUser>;
export type GroupProfileId = string;
export type GroupProfileName = string | redacted.Redacted<string>;
export interface SubscribedGroup {
    id?: string;
    name?: string | redacted.Redacted<string>;
}
export declare const SubscribedGroup: S.Schema<SubscribedGroup>;
export type IamPrincipalArn = string;
export interface SubscribedIamPrincipal {
    principalArn?: string;
}
export declare const SubscribedIamPrincipal: S.Schema<SubscribedIamPrincipal>;
export type SubscribedPrincipal = {
    project: SubscribedProject;
    user?: never;
    group?: never;
    iam?: never;
} | {
    project?: never;
    user: SubscribedUser;
    group?: never;
    iam?: never;
} | {
    project?: never;
    user?: never;
    group: SubscribedGroup;
    iam?: never;
} | {
    project?: never;
    user?: never;
    group?: never;
    iam: SubscribedIamPrincipal;
};
export declare const SubscribedPrincipal: any;
export type SubscribedPrincipals = SubscribedPrincipal[];
export declare const SubscribedPrincipals: any;
export type ListingId = string;
export type ListingName = string;
export type Description = string | redacted.Redacted<string>;
export type TypeName = string;
export type Forms = string;
export type GlossaryTermName = string | redacted.Redacted<string>;
export type ShortDescription = string | redacted.Redacted<string>;
export interface DetailedGlossaryTerm {
    name?: string | redacted.Redacted<string>;
    shortDescription?: string | redacted.Redacted<string>;
}
export declare const DetailedGlossaryTerm: S.Schema<DetailedGlossaryTerm>;
export type DetailedGlossaryTerms = DetailedGlossaryTerm[];
export declare const DetailedGlossaryTerms: any;
export interface AssetScope {
    assetId: string;
    filterIds: string[];
    status: string;
    scopeName?: string;
    errorMessage?: string;
}
export declare const AssetScope: S.Schema<AssetScope>;
export interface SubscribedAssetListing {
    entityId?: string;
    entityRevision?: string;
    entityType?: string;
    forms?: string;
    glossaryTerms?: DetailedGlossaryTerm[];
    assetScope?: AssetScope;
    permissions?: Permissions;
}
export declare const SubscribedAssetListing: S.Schema<SubscribedAssetListing>;
export interface AssetInDataProductListingItem {
    entityId?: string;
    entityRevision?: string;
    entityType?: string;
}
export declare const AssetInDataProductListingItem: S.Schema<AssetInDataProductListingItem>;
export type AssetInDataProductListingItems = AssetInDataProductListingItem[];
export declare const AssetInDataProductListingItems: any;
export interface SubscribedProductListing {
    entityId?: string;
    entityRevision?: string;
    glossaryTerms?: DetailedGlossaryTerm[];
    name?: string;
    description?: string;
    assetListings?: AssetInDataProductListingItem[];
}
export declare const SubscribedProductListing: S.Schema<SubscribedProductListing>;
export type SubscribedListingItem = {
    assetListing: SubscribedAssetListing;
    productListing?: never;
} | {
    assetListing?: never;
    productListing: SubscribedProductListing;
};
export declare const SubscribedListingItem: any;
export interface SubscribedListing {
    id: string;
    revision?: string;
    name: string;
    description: string | redacted.Redacted<string>;
    item: SubscribedListingItem;
    ownerProjectId: string;
    ownerProjectName?: string;
}
export declare const SubscribedListing: S.Schema<SubscribedListing>;
export type SubscribedListings = SubscribedListing[];
export declare const SubscribedListings: any;
export type SubscriptionId = string;
export type FormName = string;
export type FormTypeName = string | redacted.Redacted<string>;
export interface FormOutput {
    formName: string;
    typeName?: string | redacted.Redacted<string>;
    typeRevision?: string;
    content?: string;
}
export declare const FormOutput: S.Schema<FormOutput>;
export type MetadataForms = FormOutput[];
export declare const MetadataForms: any;
export interface AcceptSubscriptionRequestOutput {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    status: SubscriptionRequestStatus;
    createdAt: Date;
    updatedAt: Date;
    requestReason: string | redacted.Redacted<string>;
    subscribedPrincipals: SubscribedPrincipal[];
    subscribedListings: SubscribedListing[];
    reviewerId?: string;
    decisionComment?: string | redacted.Redacted<string>;
    existingSubscriptionId?: string;
    metadataForms?: FormOutput[];
}
export declare const AcceptSubscriptionRequestOutput: S.Schema<AcceptSubscriptionRequestOutput>;
export type DataZoneEntityType = "DOMAIN_UNIT" | (string & {});
export declare const DataZoneEntityType: any;
export type UserIdentifier = string;
export interface OwnerUserProperties {
    userIdentifier: string;
}
export declare const OwnerUserProperties: S.Schema<OwnerUserProperties>;
export type GroupIdentifier = string;
export interface OwnerGroupProperties {
    groupIdentifier: string;
}
export declare const OwnerGroupProperties: S.Schema<OwnerGroupProperties>;
export type OwnerProperties = {
    user: OwnerUserProperties;
    group?: never;
} | {
    user?: never;
    group: OwnerGroupProperties;
};
export declare const OwnerProperties: any;
export interface AddEntityOwnerInput {
    domainIdentifier: string;
    entityType: DataZoneEntityType;
    entityIdentifier: string;
    owner: OwnerProperties;
    clientToken?: string;
}
export declare const AddEntityOwnerInput: S.Schema<AddEntityOwnerInput>;
export interface AddEntityOwnerOutput {
}
export declare const AddEntityOwnerOutput: S.Schema<AddEntityOwnerOutput>;
export type TargetEntityType = "DOMAIN_UNIT" | "ENVIRONMENT_BLUEPRINT_CONFIGURATION" | "ENVIRONMENT_PROFILE" | "ASSET_TYPE" | (string & {});
export declare const TargetEntityType: any;
export type ManagedPolicyType = "CREATE_DOMAIN_UNIT" | "OVERRIDE_DOMAIN_UNIT_OWNERS" | "ADD_TO_PROJECT_MEMBER_POOL" | "OVERRIDE_PROJECT_OWNERS" | "CREATE_GLOSSARY" | "CREATE_FORM_TYPE" | "CREATE_ASSET_TYPE" | "CREATE_PROJECT" | "CREATE_ENVIRONMENT_PROFILE" | "DELEGATE_CREATE_ENVIRONMENT_PROFILE" | "CREATE_ENVIRONMENT" | "CREATE_ENVIRONMENT_FROM_BLUEPRINT" | "CREATE_PROJECT_FROM_PROJECT_PROFILE" | "USE_ASSET_TYPE" | (string & {});
export declare const ManagedPolicyType: any;
export interface AllUsersGrantFilter {
}
export declare const AllUsersGrantFilter: S.Schema<AllUsersGrantFilter>;
export type UserPolicyGrantPrincipal = {
    userIdentifier: string;
    allUsersGrantFilter?: never;
} | {
    userIdentifier?: never;
    allUsersGrantFilter: AllUsersGrantFilter;
};
export declare const UserPolicyGrantPrincipal: any;
export type GroupPolicyGrantPrincipal = {
    groupIdentifier: string;
};
export declare const GroupPolicyGrantPrincipal: any;
export type ProjectDesignation = "OWNER" | "CONTRIBUTOR" | "PROJECT_CATALOG_STEWARD" | (string & {});
export declare const ProjectDesignation: any;
export type DomainUnitId = string;
export interface DomainUnitFilterForProject {
    domainUnit: string;
    includeChildDomainUnits?: boolean;
}
export declare const DomainUnitFilterForProject: S.Schema<DomainUnitFilterForProject>;
export type ProjectGrantFilter = {
    domainUnitFilter: DomainUnitFilterForProject;
};
export declare const ProjectGrantFilter: any;
export interface ProjectPolicyGrantPrincipal {
    projectDesignation: ProjectDesignation;
    projectIdentifier?: string;
    projectGrantFilter?: ProjectGrantFilter;
}
export declare const ProjectPolicyGrantPrincipal: S.Schema<ProjectPolicyGrantPrincipal>;
export type DomainUnitDesignation = "OWNER" | (string & {});
export declare const DomainUnitDesignation: any;
export interface AllDomainUnitsGrantFilter {
}
export declare const AllDomainUnitsGrantFilter: S.Schema<AllDomainUnitsGrantFilter>;
export type DomainUnitGrantFilter = {
    allDomainUnitsGrantFilter: AllDomainUnitsGrantFilter;
};
export declare const DomainUnitGrantFilter: any;
export interface DomainUnitPolicyGrantPrincipal {
    domainUnitDesignation: DomainUnitDesignation;
    domainUnitIdentifier?: string;
    domainUnitGrantFilter?: DomainUnitGrantFilter;
}
export declare const DomainUnitPolicyGrantPrincipal: S.Schema<DomainUnitPolicyGrantPrincipal>;
export type PolicyGrantPrincipal = {
    user: UserPolicyGrantPrincipal;
    group?: never;
    project?: never;
    domainUnit?: never;
} | {
    user?: never;
    group: GroupPolicyGrantPrincipal;
    project?: never;
    domainUnit?: never;
} | {
    user?: never;
    group?: never;
    project: ProjectPolicyGrantPrincipal;
    domainUnit?: never;
} | {
    user?: never;
    group?: never;
    project?: never;
    domainUnit: DomainUnitPolicyGrantPrincipal;
};
export declare const PolicyGrantPrincipal: any;
export interface CreateDomainUnitPolicyGrantDetail {
    includeChildDomainUnits?: boolean;
}
export declare const CreateDomainUnitPolicyGrantDetail: S.Schema<CreateDomainUnitPolicyGrantDetail>;
export interface OverrideDomainUnitOwnersPolicyGrantDetail {
    includeChildDomainUnits?: boolean;
}
export declare const OverrideDomainUnitOwnersPolicyGrantDetail: S.Schema<OverrideDomainUnitOwnersPolicyGrantDetail>;
export interface AddToProjectMemberPoolPolicyGrantDetail {
    includeChildDomainUnits?: boolean;
}
export declare const AddToProjectMemberPoolPolicyGrantDetail: S.Schema<AddToProjectMemberPoolPolicyGrantDetail>;
export interface OverrideProjectOwnersPolicyGrantDetail {
    includeChildDomainUnits?: boolean;
}
export declare const OverrideProjectOwnersPolicyGrantDetail: S.Schema<OverrideProjectOwnersPolicyGrantDetail>;
export interface CreateGlossaryPolicyGrantDetail {
    includeChildDomainUnits?: boolean;
}
export declare const CreateGlossaryPolicyGrantDetail: S.Schema<CreateGlossaryPolicyGrantDetail>;
export interface CreateFormTypePolicyGrantDetail {
    includeChildDomainUnits?: boolean;
}
export declare const CreateFormTypePolicyGrantDetail: S.Schema<CreateFormTypePolicyGrantDetail>;
export interface CreateAssetTypePolicyGrantDetail {
    includeChildDomainUnits?: boolean;
}
export declare const CreateAssetTypePolicyGrantDetail: S.Schema<CreateAssetTypePolicyGrantDetail>;
export interface CreateProjectPolicyGrantDetail {
    includeChildDomainUnits?: boolean;
}
export declare const CreateProjectPolicyGrantDetail: S.Schema<CreateProjectPolicyGrantDetail>;
export interface CreateEnvironmentProfilePolicyGrantDetail {
    domainUnitId?: string;
}
export declare const CreateEnvironmentProfilePolicyGrantDetail: S.Schema<CreateEnvironmentProfilePolicyGrantDetail>;
export interface Unit {
}
export declare const Unit: S.Schema<Unit>;
export type ProjectProfileList = string[];
export declare const ProjectProfileList: any;
export interface CreateProjectFromProjectProfilePolicyGrantDetail {
    includeChildDomainUnits?: boolean;
    projectProfiles?: string[];
}
export declare const CreateProjectFromProjectProfilePolicyGrantDetail: S.Schema<CreateProjectFromProjectProfilePolicyGrantDetail>;
export interface UseAssetTypePolicyGrantDetail {
    domainUnitId?: string;
}
export declare const UseAssetTypePolicyGrantDetail: S.Schema<UseAssetTypePolicyGrantDetail>;
export type PolicyGrantDetail = {
    createDomainUnit: CreateDomainUnitPolicyGrantDetail;
    overrideDomainUnitOwners?: never;
    addToProjectMemberPool?: never;
    overrideProjectOwners?: never;
    createGlossary?: never;
    createFormType?: never;
    createAssetType?: never;
    createProject?: never;
    createEnvironmentProfile?: never;
    delegateCreateEnvironmentProfile?: never;
    createEnvironment?: never;
    createEnvironmentFromBlueprint?: never;
    createProjectFromProjectProfile?: never;
    useAssetType?: never;
} | {
    createDomainUnit?: never;
    overrideDomainUnitOwners: OverrideDomainUnitOwnersPolicyGrantDetail;
    addToProjectMemberPool?: never;
    overrideProjectOwners?: never;
    createGlossary?: never;
    createFormType?: never;
    createAssetType?: never;
    createProject?: never;
    createEnvironmentProfile?: never;
    delegateCreateEnvironmentProfile?: never;
    createEnvironment?: never;
    createEnvironmentFromBlueprint?: never;
    createProjectFromProjectProfile?: never;
    useAssetType?: never;
} | {
    createDomainUnit?: never;
    overrideDomainUnitOwners?: never;
    addToProjectMemberPool: AddToProjectMemberPoolPolicyGrantDetail;
    overrideProjectOwners?: never;
    createGlossary?: never;
    createFormType?: never;
    createAssetType?: never;
    createProject?: never;
    createEnvironmentProfile?: never;
    delegateCreateEnvironmentProfile?: never;
    createEnvironment?: never;
    createEnvironmentFromBlueprint?: never;
    createProjectFromProjectProfile?: never;
    useAssetType?: never;
} | {
    createDomainUnit?: never;
    overrideDomainUnitOwners?: never;
    addToProjectMemberPool?: never;
    overrideProjectOwners: OverrideProjectOwnersPolicyGrantDetail;
    createGlossary?: never;
    createFormType?: never;
    createAssetType?: never;
    createProject?: never;
    createEnvironmentProfile?: never;
    delegateCreateEnvironmentProfile?: never;
    createEnvironment?: never;
    createEnvironmentFromBlueprint?: never;
    createProjectFromProjectProfile?: never;
    useAssetType?: never;
} | {
    createDomainUnit?: never;
    overrideDomainUnitOwners?: never;
    addToProjectMemberPool?: never;
    overrideProjectOwners?: never;
    createGlossary: CreateGlossaryPolicyGrantDetail;
    createFormType?: never;
    createAssetType?: never;
    createProject?: never;
    createEnvironmentProfile?: never;
    delegateCreateEnvironmentProfile?: never;
    createEnvironment?: never;
    createEnvironmentFromBlueprint?: never;
    createProjectFromProjectProfile?: never;
    useAssetType?: never;
} | {
    createDomainUnit?: never;
    overrideDomainUnitOwners?: never;
    addToProjectMemberPool?: never;
    overrideProjectOwners?: never;
    createGlossary?: never;
    createFormType: CreateFormTypePolicyGrantDetail;
    createAssetType?: never;
    createProject?: never;
    createEnvironmentProfile?: never;
    delegateCreateEnvironmentProfile?: never;
    createEnvironment?: never;
    createEnvironmentFromBlueprint?: never;
    createProjectFromProjectProfile?: never;
    useAssetType?: never;
} | {
    createDomainUnit?: never;
    overrideDomainUnitOwners?: never;
    addToProjectMemberPool?: never;
    overrideProjectOwners?: never;
    createGlossary?: never;
    createFormType?: never;
    createAssetType: CreateAssetTypePolicyGrantDetail;
    createProject?: never;
    createEnvironmentProfile?: never;
    delegateCreateEnvironmentProfile?: never;
    createEnvironment?: never;
    createEnvironmentFromBlueprint?: never;
    createProjectFromProjectProfile?: never;
    useAssetType?: never;
} | {
    createDomainUnit?: never;
    overrideDomainUnitOwners?: never;
    addToProjectMemberPool?: never;
    overrideProjectOwners?: never;
    createGlossary?: never;
    createFormType?: never;
    createAssetType?: never;
    createProject: CreateProjectPolicyGrantDetail;
    createEnvironmentProfile?: never;
    delegateCreateEnvironmentProfile?: never;
    createEnvironment?: never;
    createEnvironmentFromBlueprint?: never;
    createProjectFromProjectProfile?: never;
    useAssetType?: never;
} | {
    createDomainUnit?: never;
    overrideDomainUnitOwners?: never;
    addToProjectMemberPool?: never;
    overrideProjectOwners?: never;
    createGlossary?: never;
    createFormType?: never;
    createAssetType?: never;
    createProject?: never;
    createEnvironmentProfile: CreateEnvironmentProfilePolicyGrantDetail;
    delegateCreateEnvironmentProfile?: never;
    createEnvironment?: never;
    createEnvironmentFromBlueprint?: never;
    createProjectFromProjectProfile?: never;
    useAssetType?: never;
} | {
    createDomainUnit?: never;
    overrideDomainUnitOwners?: never;
    addToProjectMemberPool?: never;
    overrideProjectOwners?: never;
    createGlossary?: never;
    createFormType?: never;
    createAssetType?: never;
    createProject?: never;
    createEnvironmentProfile?: never;
    delegateCreateEnvironmentProfile: Unit;
    createEnvironment?: never;
    createEnvironmentFromBlueprint?: never;
    createProjectFromProjectProfile?: never;
    useAssetType?: never;
} | {
    createDomainUnit?: never;
    overrideDomainUnitOwners?: never;
    addToProjectMemberPool?: never;
    overrideProjectOwners?: never;
    createGlossary?: never;
    createFormType?: never;
    createAssetType?: never;
    createProject?: never;
    createEnvironmentProfile?: never;
    delegateCreateEnvironmentProfile?: never;
    createEnvironment: Unit;
    createEnvironmentFromBlueprint?: never;
    createProjectFromProjectProfile?: never;
    useAssetType?: never;
} | {
    createDomainUnit?: never;
    overrideDomainUnitOwners?: never;
    addToProjectMemberPool?: never;
    overrideProjectOwners?: never;
    createGlossary?: never;
    createFormType?: never;
    createAssetType?: never;
    createProject?: never;
    createEnvironmentProfile?: never;
    delegateCreateEnvironmentProfile?: never;
    createEnvironment?: never;
    createEnvironmentFromBlueprint: Unit;
    createProjectFromProjectProfile?: never;
    useAssetType?: never;
} | {
    createDomainUnit?: never;
    overrideDomainUnitOwners?: never;
    addToProjectMemberPool?: never;
    overrideProjectOwners?: never;
    createGlossary?: never;
    createFormType?: never;
    createAssetType?: never;
    createProject?: never;
    createEnvironmentProfile?: never;
    delegateCreateEnvironmentProfile?: never;
    createEnvironment?: never;
    createEnvironmentFromBlueprint?: never;
    createProjectFromProjectProfile: CreateProjectFromProjectProfilePolicyGrantDetail;
    useAssetType?: never;
} | {
    createDomainUnit?: never;
    overrideDomainUnitOwners?: never;
    addToProjectMemberPool?: never;
    overrideProjectOwners?: never;
    createGlossary?: never;
    createFormType?: never;
    createAssetType?: never;
    createProject?: never;
    createEnvironmentProfile?: never;
    delegateCreateEnvironmentProfile?: never;
    createEnvironment?: never;
    createEnvironmentFromBlueprint?: never;
    createProjectFromProjectProfile?: never;
    useAssetType: UseAssetTypePolicyGrantDetail;
};
export declare const PolicyGrantDetail: any;
export interface AddPolicyGrantInput {
    domainIdentifier: string;
    entityType: TargetEntityType;
    entityIdentifier: string;
    policyType: ManagedPolicyType;
    principal: PolicyGrantPrincipal;
    detail: PolicyGrantDetail;
    clientToken?: string;
}
export declare const AddPolicyGrantInput: S.Schema<AddPolicyGrantInput>;
export type GrantIdentifier = string;
export interface AddPolicyGrantOutput {
    grantId?: string;
}
export declare const AddPolicyGrantOutput: S.Schema<AddPolicyGrantOutput>;
export type EnvironmentId = string;
export interface AssociateEnvironmentRoleInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    environmentRoleArn: string;
}
export declare const AssociateEnvironmentRoleInput: S.Schema<AssociateEnvironmentRoleInput>;
export interface AssociateEnvironmentRoleOutput {
}
export declare const AssociateEnvironmentRoleOutput: S.Schema<AssociateEnvironmentRoleOutput>;
export type EntityIdentifier = string;
export type GovernedEntityType = "ASSET" | (string & {});
export declare const GovernedEntityType: any;
export type GlossaryTermId = string;
export type GovernedGlossaryTerms = string[];
export declare const GovernedGlossaryTerms: any;
export interface AssociateGovernedTermsInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: GovernedEntityType;
    governedGlossaryTerms: string[];
}
export declare const AssociateGovernedTermsInput: S.Schema<AssociateGovernedTermsInput>;
export interface AssociateGovernedTermsOutput {
}
export declare const AssociateGovernedTermsOutput: S.Schema<AssociateGovernedTermsOutput>;
export type AttributeEntityType = "ASSET" | "LISTING" | (string & {});
export declare const AttributeEntityType: any;
export type EntityId = string;
export type AttributeIdentifier = string;
export type AttributesList = string[];
export declare const AttributesList: any;
export interface BatchGetAttributesMetadataInput {
    domainIdentifier: string;
    entityType: AttributeEntityType;
    entityIdentifier: string;
    entityRevision?: string;
    attributeIdentifiers: string[];
}
export declare const BatchGetAttributesMetadataInput: S.Schema<BatchGetAttributesMetadataInput>;
export type FormOutputList = FormOutput[];
export declare const FormOutputList: any;
export interface BatchGetAttributeOutput {
    attributeIdentifier: string;
    forms?: FormOutput[];
}
export declare const BatchGetAttributeOutput: S.Schema<BatchGetAttributeOutput>;
export type BatchGetAttributeItems = BatchGetAttributeOutput[];
export declare const BatchGetAttributeItems: any;
export interface AttributeError {
    attributeIdentifier: string;
    code: string;
    message: string;
}
export declare const AttributeError: S.Schema<AttributeError>;
export type AttributesErrors = AttributeError[];
export declare const AttributesErrors: any;
export interface BatchGetAttributesMetadataOutput {
    attributes?: BatchGetAttributeOutput[];
    errors: AttributeError[];
}
export declare const BatchGetAttributesMetadataOutput: S.Schema<BatchGetAttributesMetadataOutput>;
export type FormTypeIdentifier = string;
export type RevisionInput = string;
export interface FormInput {
    formName: string;
    typeIdentifier?: string;
    typeRevision?: string;
    content?: string;
}
export declare const FormInput: S.Schema<FormInput>;
export type FormInputList = FormInput[];
export declare const FormInputList: any;
export interface AttributeInput {
    attributeIdentifier: string;
    forms: FormInput[];
}
export declare const AttributeInput: S.Schema<AttributeInput>;
export type Attributes = AttributeInput[];
export declare const Attributes: any;
export interface BatchPutAttributesMetadataInput {
    domainIdentifier: string;
    entityType: AttributeEntityType;
    entityIdentifier: string;
    clientToken?: string;
    attributes: AttributeInput[];
}
export declare const BatchPutAttributesMetadataInput: S.Schema<BatchPutAttributesMetadataInput>;
export interface BatchPutAttributeOutput {
    attributeIdentifier: string;
}
export declare const BatchPutAttributeOutput: S.Schema<BatchPutAttributeOutput>;
export type BatchPutAttributeItems = BatchPutAttributeOutput[];
export declare const BatchPutAttributeItems: any;
export interface BatchPutAttributesMetadataOutput {
    errors?: AttributeError[];
    attributes?: BatchPutAttributeOutput[];
}
export declare const BatchPutAttributesMetadataOutput: S.Schema<BatchPutAttributesMetadataOutput>;
export type MetadataGenerationRunIdentifier = string;
export interface CancelMetadataGenerationRunInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const CancelMetadataGenerationRunInput: S.Schema<CancelMetadataGenerationRunInput>;
export interface CancelMetadataGenerationRunOutput {
}
export declare const CancelMetadataGenerationRunOutput: S.Schema<CancelMetadataGenerationRunOutput>;
export interface CancelSubscriptionInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const CancelSubscriptionInput: S.Schema<CancelSubscriptionInput>;
export type SubscriptionStatus = "APPROVED" | "REVOKED" | "CANCELLED" | (string & {});
export declare const SubscriptionStatus: any;
export interface CancelSubscriptionOutput {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    status: SubscriptionStatus;
    createdAt: Date;
    updatedAt: Date;
    subscribedPrincipal: SubscribedPrincipal;
    subscribedListing: SubscribedListing;
    subscriptionRequestId?: string;
    retainPermissions?: boolean;
}
export declare const CancelSubscriptionOutput: S.Schema<CancelSubscriptionOutput>;
export type AccountPoolName = string | redacted.Redacted<string>;
export type ResolutionStrategy = "MANUAL" | (string & {});
export declare const ResolutionStrategy: any;
export type AwsAccountId = string;
export type AwsRegion = string;
export type AwsRegionList = string[];
export declare const AwsRegionList: any;
export type AwsAccountName = string | redacted.Redacted<string>;
export interface AccountInfo {
    awsAccountId: string;
    supportedRegions: string[];
    awsAccountName?: string | redacted.Redacted<string>;
}
export declare const AccountInfo: S.Schema<AccountInfo>;
export type AccountInfoList = AccountInfo[];
export declare const AccountInfoList: any;
export type LambdaFunctionArn = string;
export type LambdaExecutionRoleArn = string;
export interface CustomAccountPoolHandler {
    lambdaFunctionArn: string;
    lambdaExecutionRoleArn?: string;
}
export declare const CustomAccountPoolHandler: S.Schema<CustomAccountPoolHandler>;
export type AccountSource = {
    accounts: AccountInfo[];
    customAccountPoolHandler?: never;
} | {
    accounts?: never;
    customAccountPoolHandler: CustomAccountPoolHandler;
};
export declare const AccountSource: any;
export interface CreateAccountPoolInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    resolutionStrategy: ResolutionStrategy;
    accountSource: AccountSource;
}
export declare const CreateAccountPoolInput: S.Schema<CreateAccountPoolInput>;
export type AccountPoolId = string;
export interface CreateAccountPoolOutput {
    domainId?: string;
    name?: string | redacted.Redacted<string>;
    id?: string;
    description?: string | redacted.Redacted<string>;
    resolutionStrategy?: ResolutionStrategy;
    accountSource: AccountSource;
    createdBy: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    updatedBy?: string;
    domainUnitId?: string;
}
export declare const CreateAccountPoolOutput: S.Schema<CreateAccountPoolOutput>;
export type AssetName = string | redacted.Redacted<string>;
export type ExternalIdentifier = string;
export type AssetTypeIdentifier = string;
export type GlossaryTerms = string[];
export declare const GlossaryTerms: any;
export interface BusinessNameGenerationConfiguration {
    enabled?: boolean;
}
export declare const BusinessNameGenerationConfiguration: S.Schema<BusinessNameGenerationConfiguration>;
export interface PredictionConfiguration {
    businessNameGeneration?: BusinessNameGenerationConfiguration;
}
export declare const PredictionConfiguration: S.Schema<PredictionConfiguration>;
export interface CreateAssetInput {
    name: string | redacted.Redacted<string>;
    domainIdentifier: string;
    externalIdentifier?: string;
    typeIdentifier: string;
    typeRevision?: string;
    description?: string | redacted.Redacted<string>;
    glossaryTerms?: string[];
    formsInput?: FormInput[];
    owningProjectIdentifier: string;
    predictionConfiguration?: PredictionConfiguration;
    clientToken?: string;
}
export declare const CreateAssetInput: S.Schema<CreateAssetInput>;
export type ListingStatus = "CREATING" | "ACTIVE" | "INACTIVE" | (string & {});
export declare const ListingStatus: any;
export interface AssetListingDetails {
    listingId: string;
    listingStatus: ListingStatus;
}
export declare const AssetListingDetails: S.Schema<AssetListingDetails>;
export type TimeSeriesFormName = string;
export type DataPointIdentifier = string;
export interface TimeSeriesDataPointSummaryFormOutput {
    formName: string;
    typeIdentifier: string;
    typeRevision?: string;
    timestamp: Date;
    contentSummary?: string;
    id?: string;
}
export declare const TimeSeriesDataPointSummaryFormOutput: S.Schema<TimeSeriesDataPointSummaryFormOutput>;
export type TimeSeriesDataPointSummaryFormOutputList = TimeSeriesDataPointSummaryFormOutput[];
export declare const TimeSeriesDataPointSummaryFormOutputList: any;
export interface CreateAssetOutput {
    id: string;
    name: string | redacted.Redacted<string>;
    typeIdentifier: string;
    typeRevision: string;
    externalIdentifier?: string;
    revision: string;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    createdBy?: string;
    firstRevisionCreatedAt?: Date;
    firstRevisionCreatedBy?: string;
    glossaryTerms?: string[];
    governedGlossaryTerms?: string[];
    owningProjectId: string;
    domainId: string;
    listing?: AssetListingDetails;
    formsOutput: FormOutput[];
    readOnlyFormsOutput?: FormOutput[];
    latestTimeSeriesDataPointFormsOutput?: TimeSeriesDataPointSummaryFormOutput[];
    predictionConfiguration?: PredictionConfiguration;
}
export declare const CreateAssetOutput: S.Schema<CreateAssetOutput>;
export type FilterName = string | redacted.Redacted<string>;
export type ColumnNameList = string[];
export declare const ColumnNameList: any;
export interface ColumnFilterConfiguration {
    includedColumnNames?: string[];
}
export declare const ColumnFilterConfiguration: S.Schema<ColumnFilterConfiguration>;
export interface EqualToExpression {
    columnName: string;
    value: string;
}
export declare const EqualToExpression: S.Schema<EqualToExpression>;
export interface NotEqualToExpression {
    columnName: string;
    value: string;
}
export declare const NotEqualToExpression: S.Schema<NotEqualToExpression>;
export interface GreaterThanExpression {
    columnName: string;
    value: string;
}
export declare const GreaterThanExpression: S.Schema<GreaterThanExpression>;
export interface LessThanExpression {
    columnName: string;
    value: string;
}
export declare const LessThanExpression: S.Schema<LessThanExpression>;
export interface GreaterThanOrEqualToExpression {
    columnName: string;
    value: string;
}
export declare const GreaterThanOrEqualToExpression: S.Schema<GreaterThanOrEqualToExpression>;
export interface LessThanOrEqualToExpression {
    columnName: string;
    value: string;
}
export declare const LessThanOrEqualToExpression: S.Schema<LessThanOrEqualToExpression>;
export interface IsNullExpression {
    columnName: string;
}
export declare const IsNullExpression: S.Schema<IsNullExpression>;
export interface IsNotNullExpression {
    columnName: string;
}
export declare const IsNotNullExpression: S.Schema<IsNotNullExpression>;
export type StringList = string[];
export declare const StringList: any;
export interface InExpression {
    columnName: string;
    values: string[];
}
export declare const InExpression: S.Schema<InExpression>;
export interface NotInExpression {
    columnName: string;
    values: string[];
}
export declare const NotInExpression: S.Schema<NotInExpression>;
export interface LikeExpression {
    columnName: string;
    value: string;
}
export declare const LikeExpression: S.Schema<LikeExpression>;
export interface NotLikeExpression {
    columnName: string;
    value: string;
}
export declare const NotLikeExpression: S.Schema<NotLikeExpression>;
export type RowFilterExpression = {
    equalTo: EqualToExpression;
    notEqualTo?: never;
    greaterThan?: never;
    lessThan?: never;
    greaterThanOrEqualTo?: never;
    lessThanOrEqualTo?: never;
    isNull?: never;
    isNotNull?: never;
    in?: never;
    notIn?: never;
    like?: never;
    notLike?: never;
} | {
    equalTo?: never;
    notEqualTo: NotEqualToExpression;
    greaterThan?: never;
    lessThan?: never;
    greaterThanOrEqualTo?: never;
    lessThanOrEqualTo?: never;
    isNull?: never;
    isNotNull?: never;
    in?: never;
    notIn?: never;
    like?: never;
    notLike?: never;
} | {
    equalTo?: never;
    notEqualTo?: never;
    greaterThan: GreaterThanExpression;
    lessThan?: never;
    greaterThanOrEqualTo?: never;
    lessThanOrEqualTo?: never;
    isNull?: never;
    isNotNull?: never;
    in?: never;
    notIn?: never;
    like?: never;
    notLike?: never;
} | {
    equalTo?: never;
    notEqualTo?: never;
    greaterThan?: never;
    lessThan: LessThanExpression;
    greaterThanOrEqualTo?: never;
    lessThanOrEqualTo?: never;
    isNull?: never;
    isNotNull?: never;
    in?: never;
    notIn?: never;
    like?: never;
    notLike?: never;
} | {
    equalTo?: never;
    notEqualTo?: never;
    greaterThan?: never;
    lessThan?: never;
    greaterThanOrEqualTo: GreaterThanOrEqualToExpression;
    lessThanOrEqualTo?: never;
    isNull?: never;
    isNotNull?: never;
    in?: never;
    notIn?: never;
    like?: never;
    notLike?: never;
} | {
    equalTo?: never;
    notEqualTo?: never;
    greaterThan?: never;
    lessThan?: never;
    greaterThanOrEqualTo?: never;
    lessThanOrEqualTo: LessThanOrEqualToExpression;
    isNull?: never;
    isNotNull?: never;
    in?: never;
    notIn?: never;
    like?: never;
    notLike?: never;
} | {
    equalTo?: never;
    notEqualTo?: never;
    greaterThan?: never;
    lessThan?: never;
    greaterThanOrEqualTo?: never;
    lessThanOrEqualTo?: never;
    isNull: IsNullExpression;
    isNotNull?: never;
    in?: never;
    notIn?: never;
    like?: never;
    notLike?: never;
} | {
    equalTo?: never;
    notEqualTo?: never;
    greaterThan?: never;
    lessThan?: never;
    greaterThanOrEqualTo?: never;
    lessThanOrEqualTo?: never;
    isNull?: never;
    isNotNull: IsNotNullExpression;
    in?: never;
    notIn?: never;
    like?: never;
    notLike?: never;
} | {
    equalTo?: never;
    notEqualTo?: never;
    greaterThan?: never;
    lessThan?: never;
    greaterThanOrEqualTo?: never;
    lessThanOrEqualTo?: never;
    isNull?: never;
    isNotNull?: never;
    in: InExpression;
    notIn?: never;
    like?: never;
    notLike?: never;
} | {
    equalTo?: never;
    notEqualTo?: never;
    greaterThan?: never;
    lessThan?: never;
    greaterThanOrEqualTo?: never;
    lessThanOrEqualTo?: never;
    isNull?: never;
    isNotNull?: never;
    in?: never;
    notIn: NotInExpression;
    like?: never;
    notLike?: never;
} | {
    equalTo?: never;
    notEqualTo?: never;
    greaterThan?: never;
    lessThan?: never;
    greaterThanOrEqualTo?: never;
    lessThanOrEqualTo?: never;
    isNull?: never;
    isNotNull?: never;
    in?: never;
    notIn?: never;
    like: LikeExpression;
    notLike?: never;
} | {
    equalTo?: never;
    notEqualTo?: never;
    greaterThan?: never;
    lessThan?: never;
    greaterThanOrEqualTo?: never;
    lessThanOrEqualTo?: never;
    isNull?: never;
    isNotNull?: never;
    in?: never;
    notIn?: never;
    like?: never;
    notLike: NotLikeExpression;
};
export declare const RowFilterExpression: any;
export type RowFilterList = RowFilter[];
export declare const RowFilterList: S.Schema<RowFilterList>;
export type RowFilter = {
    expression: RowFilterExpression;
    and?: never;
    or?: never;
} | {
    expression?: never;
    and: RowFilter[];
    or?: never;
} | {
    expression?: never;
    and?: never;
    or: RowFilter[];
};
export declare const RowFilter: S.Schema<RowFilter>;
export interface RowFilterConfiguration {
    rowFilter: RowFilter;
    sensitive?: boolean;
}
export declare const RowFilterConfiguration: S.Schema<RowFilterConfiguration>;
export type AssetFilterConfiguration = {
    columnConfiguration: ColumnFilterConfiguration;
    rowConfiguration?: never;
} | {
    columnConfiguration?: never;
    rowConfiguration: RowFilterConfiguration;
};
export declare const AssetFilterConfiguration: any;
export interface CreateAssetFilterInput {
    domainIdentifier: string;
    assetIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    configuration: AssetFilterConfiguration;
    clientToken?: string;
}
export declare const CreateAssetFilterInput: S.Schema<CreateAssetFilterInput>;
export type FilterStatus = "VALID" | "INVALID" | (string & {});
export declare const FilterStatus: any;
export interface CreateAssetFilterOutput {
    id: string;
    domainId: string;
    assetId: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    status?: FilterStatus;
    configuration: AssetFilterConfiguration;
    createdAt?: Date;
    errorMessage?: string;
    effectiveColumnNames?: string[];
    effectiveRowFilter?: string;
}
export declare const CreateAssetFilterOutput: S.Schema<CreateAssetFilterOutput>;
export interface CreateAssetRevisionInput {
    name: string | redacted.Redacted<string>;
    domainIdentifier: string;
    identifier: string;
    typeRevision?: string;
    description?: string | redacted.Redacted<string>;
    glossaryTerms?: string[];
    formsInput?: FormInput[];
    predictionConfiguration?: PredictionConfiguration;
    clientToken?: string;
}
export declare const CreateAssetRevisionInput: S.Schema<CreateAssetRevisionInput>;
export interface CreateAssetRevisionOutput {
    id: string;
    name: string | redacted.Redacted<string>;
    typeIdentifier: string;
    typeRevision: string;
    externalIdentifier?: string;
    revision: string;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    createdBy?: string;
    firstRevisionCreatedAt?: Date;
    firstRevisionCreatedBy?: string;
    glossaryTerms?: string[];
    governedGlossaryTerms?: string[];
    owningProjectId: string;
    domainId: string;
    listing?: AssetListingDetails;
    formsOutput: FormOutput[];
    readOnlyFormsOutput?: FormOutput[];
    latestTimeSeriesDataPointFormsOutput?: TimeSeriesDataPointSummaryFormOutput[];
    predictionConfiguration?: PredictionConfiguration;
}
export declare const CreateAssetRevisionOutput: S.Schema<CreateAssetRevisionOutput>;
export interface FormEntryInput {
    typeIdentifier: string;
    typeRevision: string;
    required?: boolean;
}
export declare const FormEntryInput: S.Schema<FormEntryInput>;
export type FormsInputMap = {
    [key: string]: FormEntryInput | undefined;
};
export declare const FormsInputMap: any;
export interface CreateAssetTypeInput {
    domainIdentifier: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    formsInput: {
        [key: string]: FormEntryInput | undefined;
    };
    owningProjectIdentifier: string;
}
export declare const CreateAssetTypeInput: S.Schema<CreateAssetTypeInput>;
export interface FormEntryOutput {
    typeName: string | redacted.Redacted<string>;
    typeRevision: string;
    required?: boolean;
}
export declare const FormEntryOutput: S.Schema<FormEntryOutput>;
export type FormsOutputMap = {
    [key: string]: FormEntryOutput | undefined;
};
export declare const FormsOutputMap: any;
export interface CreateAssetTypeOutput {
    domainId: string;
    name: string;
    revision: string;
    description?: string | redacted.Redacted<string>;
    formsOutput: {
        [key: string]: FormEntryOutput | undefined;
    };
    owningProjectId?: string;
    originDomainId?: string;
    originProjectId?: string;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
}
export declare const CreateAssetTypeOutput: S.Schema<CreateAssetTypeOutput>;
export type ConnectionId = string;
export interface AwsLocation {
    accessRole?: string;
    awsAccountId?: string;
    awsRegion?: string;
    iamConnectionId?: string;
}
export declare const AwsLocation: S.Schema<AwsLocation>;
export type PropertyMap = {
    [key: string]: string | undefined;
};
export declare const PropertyMap: any;
export interface Configuration {
    classification?: string;
    properties?: {
        [key: string]: string | undefined;
    };
}
export declare const Configuration: S.Schema<Configuration>;
export type Configurations = Configuration[];
export declare const Configurations: any;
export type ConnectionName = string;
export interface AthenaPropertiesInput {
    workgroupName?: string;
}
export declare const AthenaPropertiesInput: S.Schema<AthenaPropertiesInput>;
export type ConnectionProperties = {
    [key: string]: string | undefined;
};
export declare const ConnectionProperties: any;
export type SubnetId = string;
export type SubnetIdList = string[];
export declare const SubnetIdList: any;
export type SecurityGroupIdList = string[];
export declare const SecurityGroupIdList: any;
export interface PhysicalConnectionRequirements {
    subnetId?: string;
    subnetIdList?: string[];
    securityGroupIdList?: string[];
    availabilityZone?: string;
}
export declare const PhysicalConnectionRequirements: S.Schema<PhysicalConnectionRequirements>;
export type GlueConnectionType = "SNOWFLAKE" | "BIGQUERY" | "DOCUMENTDB" | "DYNAMODB" | "MYSQL" | "OPENSEARCH" | "ORACLE" | "POSTGRESQL" | "REDSHIFT" | "SAPHANA" | "SQLSERVER" | "TERADATA" | "VERTICA" | (string & {});
export declare const GlueConnectionType: any;
export type ComputeEnvironments = "SPARK" | "ATHENA" | "PYTHON" | (string & {});
export declare const ComputeEnvironments: any;
export type ComputeEnvironmentsList = ComputeEnvironments[];
export declare const ComputeEnvironmentsList: any;
export type AuthenticationType = "BASIC" | "OAUTH2" | "CUSTOM" | (string & {});
export declare const AuthenticationType: any;
export type OAuth2GrantType = "AUTHORIZATION_CODE" | "CLIENT_CREDENTIALS" | "JWT_BEARER" | (string & {});
export declare const OAuth2GrantType: any;
export interface OAuth2ClientApplication {
    userManagedClientApplicationClientId?: string;
    aWSManagedClientApplicationReference?: string;
}
export declare const OAuth2ClientApplication: S.Schema<OAuth2ClientApplication>;
export type TokenUrlParametersMap = {
    [key: string]: string | undefined;
};
export declare const TokenUrlParametersMap: any;
export interface AuthorizationCodeProperties {
    authorizationCode?: string;
    redirectUri?: string;
}
export declare const AuthorizationCodeProperties: S.Schema<AuthorizationCodeProperties>;
export interface GlueOAuth2Credentials {
    userManagedClientApplicationClientSecret?: string;
    accessToken?: string;
    refreshToken?: string;
    jwtToken?: string;
}
export declare const GlueOAuth2Credentials: S.Schema<GlueOAuth2Credentials>;
export interface OAuth2Properties {
    oAuth2GrantType?: OAuth2GrantType;
    oAuth2ClientApplication?: OAuth2ClientApplication;
    tokenUrl?: string;
    tokenUrlParametersMap?: {
        [key: string]: string | undefined;
    };
    authorizationCodeProperties?: AuthorizationCodeProperties;
    oAuth2Credentials?: GlueOAuth2Credentials;
}
export declare const OAuth2Properties: S.Schema<OAuth2Properties>;
export interface BasicAuthenticationCredentials {
    userName?: string;
    password?: string;
}
export declare const BasicAuthenticationCredentials: S.Schema<BasicAuthenticationCredentials>;
export type CredentialMap = {
    [key: string]: string | undefined;
};
export declare const CredentialMap: any;
export interface AuthenticationConfigurationInput {
    authenticationType?: AuthenticationType;
    oAuth2Properties?: OAuth2Properties;
    secretArn?: string;
    kmsKeyArn?: string;
    basicAuthenticationCredentials?: BasicAuthenticationCredentials;
    customAuthenticationCredentials?: {
        [key: string]: string | undefined;
    };
}
export declare const AuthenticationConfigurationInput: S.Schema<AuthenticationConfigurationInput>;
export interface GlueConnectionInput {
    connectionProperties?: {
        [key: string]: string | undefined;
    };
    physicalConnectionRequirements?: PhysicalConnectionRequirements;
    name?: string;
    description?: string;
    connectionType?: GlueConnectionType;
    matchCriteria?: string;
    validateCredentials?: boolean;
    validateForComputeEnvironments?: ComputeEnvironments[];
    sparkProperties?: {
        [key: string]: string | undefined;
    };
    athenaProperties?: {
        [key: string]: string | undefined;
    };
    pythonProperties?: {
        [key: string]: string | undefined;
    };
    authenticationConfiguration?: AuthenticationConfigurationInput;
}
export declare const GlueConnectionInput: S.Schema<GlueConnectionInput>;
export interface GluePropertiesInput {
    glueConnectionInput?: GlueConnectionInput;
}
export declare const GluePropertiesInput: S.Schema<GluePropertiesInput>;
export interface HyperPodPropertiesInput {
    clusterName: string;
}
export declare const HyperPodPropertiesInput: S.Schema<HyperPodPropertiesInput>;
export interface IamPropertiesInput {
    glueLineageSyncEnabled?: boolean;
}
export declare const IamPropertiesInput: S.Schema<IamPropertiesInput>;
export type RedshiftStorageProperties = {
    clusterName: string;
    workgroupName?: never;
} | {
    clusterName?: never;
    workgroupName: string;
};
export declare const RedshiftStorageProperties: any;
export type Password = string | redacted.Redacted<string>;
export type Username = string;
export interface UsernamePassword {
    password: string | redacted.Redacted<string>;
    username: string;
}
export declare const UsernamePassword: S.Schema<UsernamePassword>;
export type RedshiftCredentials = {
    secretArn: string;
    usernamePassword?: never;
} | {
    secretArn?: never;
    usernamePassword: UsernamePassword;
};
export declare const RedshiftCredentials: any;
export interface LineageSyncSchedule {
    schedule?: string;
}
export declare const LineageSyncSchedule: S.Schema<LineageSyncSchedule>;
export interface RedshiftLineageSyncConfigurationInput {
    enabled?: boolean;
    schedule?: LineageSyncSchedule;
}
export declare const RedshiftLineageSyncConfigurationInput: S.Schema<RedshiftLineageSyncConfigurationInput>;
export interface RedshiftPropertiesInput {
    storage?: RedshiftStorageProperties;
    databaseName?: string;
    host?: string;
    port?: number;
    credentials?: RedshiftCredentials;
    lineageSync?: RedshiftLineageSyncConfigurationInput;
}
export declare const RedshiftPropertiesInput: S.Schema<RedshiftPropertiesInput>;
export interface SparkEmrPropertiesInput {
    computeArn?: string;
    instanceProfileArn?: string;
    javaVirtualEnv?: string;
    logUri?: string;
    pythonVirtualEnv?: string;
    runtimeRole?: string;
    trustedCertificatesS3Uri?: string;
    managedEndpointArn?: string;
}
export declare const SparkEmrPropertiesInput: S.Schema<SparkEmrPropertiesInput>;
export interface SparkGlueArgs {
    connection?: string;
}
export declare const SparkGlueArgs: S.Schema<SparkGlueArgs>;
export type GlueConnectionName = string;
export type GlueConnectionNames = string[];
export declare const GlueConnectionNames: any;
export interface SparkGluePropertiesInput {
    additionalArgs?: SparkGlueArgs;
    glueConnectionName?: string;
    glueConnectionNames?: string[];
    glueVersion?: string;
    idleTimeout?: number;
    javaVirtualEnv?: string;
    numberOfWorkers?: number;
    pythonVirtualEnv?: string;
    workerType?: string;
}
export declare const SparkGluePropertiesInput: S.Schema<SparkGluePropertiesInput>;
export type S3Uri = string;
export type S3AccessGrantLocationId = string;
export interface S3PropertiesInput {
    s3Uri: string;
    s3AccessGrantLocationId?: string;
    registerS3AccessGrantLocation?: boolean;
}
export declare const S3PropertiesInput: S.Schema<S3PropertiesInput>;
export interface ConnectivityProperties {
    connectionProperties?: {
        [key: string]: string | undefined;
    };
    physicalConnectionRequirements?: PhysicalConnectionRequirements;
    name?: string;
    description?: string;
    validateCredentials?: boolean;
    validateForComputeEnvironments?: ComputeEnvironments[];
    sparkProperties?: {
        [key: string]: string | undefined;
    };
    athenaProperties?: {
        [key: string]: string | undefined;
    };
    pythonProperties?: {
        [key: string]: string | undefined;
    };
    authenticationConfiguration?: AuthenticationConfigurationInput;
}
export declare const ConnectivityProperties: S.Schema<ConnectivityProperties>;
export type SnowflakeRole = string;
export interface IdentityMapping {
    usernameAttribute: string;
    prefix?: string;
}
export declare const IdentityMapping: S.Schema<IdentityMapping>;
export type Timezone = "UTC" | "AFRICA_JOHANNESBURG" | "AMERICA_MONTREAL" | "AMERICA_SAO_PAULO" | "ASIA_BAHRAIN" | "ASIA_BANGKOK" | "ASIA_CALCUTTA" | "ASIA_DUBAI" | "ASIA_HONG_KONG" | "ASIA_JAKARTA" | "ASIA_KUALA_LUMPUR" | "ASIA_SEOUL" | "ASIA_SHANGHAI" | "ASIA_SINGAPORE" | "ASIA_TAIPEI" | "ASIA_TOKYO" | "AUSTRALIA_MELBOURNE" | "AUSTRALIA_SYDNEY" | "CANADA_CENTRAL" | "CET" | "CST6CDT" | "ETC_GMT" | "ETC_GMT0" | "ETC_GMT_ADD_0" | "ETC_GMT_ADD_1" | "ETC_GMT_ADD_10" | "ETC_GMT_ADD_11" | "ETC_GMT_ADD_12" | "ETC_GMT_ADD_2" | "ETC_GMT_ADD_3" | "ETC_GMT_ADD_4" | "ETC_GMT_ADD_5" | "ETC_GMT_ADD_6" | "ETC_GMT_ADD_7" | "ETC_GMT_ADD_8" | "ETC_GMT_ADD_9" | "ETC_GMT_NEG_0" | "ETC_GMT_NEG_1" | "ETC_GMT_NEG_10" | "ETC_GMT_NEG_11" | "ETC_GMT_NEG_12" | "ETC_GMT_NEG_13" | "ETC_GMT_NEG_14" | "ETC_GMT_NEG_2" | "ETC_GMT_NEG_3" | "ETC_GMT_NEG_4" | "ETC_GMT_NEG_5" | "ETC_GMT_NEG_6" | "ETC_GMT_NEG_7" | "ETC_GMT_NEG_8" | "ETC_GMT_NEG_9" | "EUROPE_DUBLIN" | "EUROPE_LONDON" | "EUROPE_PARIS" | "EUROPE_STOCKHOLM" | "EUROPE_ZURICH" | "ISRAEL" | "MEXICO_GENERAL" | "MST7MDT" | "PACIFIC_AUCKLAND" | "US_CENTRAL" | "US_EASTERN" | "US_MOUNTAIN" | "US_PACIFIC" | (string & {});
export declare const Timezone: any;
export type LineageSyncScheduleCronString = string;
export interface LineageSyncInput {
    timezone?: Timezone;
    enabled: boolean;
    schedule?: string;
}
export declare const LineageSyncInput: S.Schema<LineageSyncInput>;
export interface SnowflakePropertiesInput {
    connectivityProperties?: ConnectivityProperties;
    snowflakeRole: string;
    identityMapping: IdentityMapping;
    lineageSync?: LineageSyncInput;
}
export declare const SnowflakePropertiesInput: S.Schema<SnowflakePropertiesInput>;
export interface AmazonQPropertiesInput {
    isEnabled: boolean;
    profileArn?: string;
    authMode?: string;
}
export declare const AmazonQPropertiesInput: S.Schema<AmazonQPropertiesInput>;
export interface MlflowPropertiesInput {
    trackingServerArn?: string;
}
export declare const MlflowPropertiesInput: S.Schema<MlflowPropertiesInput>;
export interface WorkflowsMwaaPropertiesInput {
    mwaaEnvironmentName?: string;
}
export declare const WorkflowsMwaaPropertiesInput: S.Schema<WorkflowsMwaaPropertiesInput>;
export interface WorkflowsServerlessPropertiesInput {
}
export declare const WorkflowsServerlessPropertiesInput: S.Schema<WorkflowsServerlessPropertiesInput>;
export interface LakehousePropertiesInput {
    glueLineageSyncEnabled?: boolean;
}
export declare const LakehousePropertiesInput: S.Schema<LakehousePropertiesInput>;
export type VpcId = string;
export type VpcConnectionSubnetIdList = string[];
export declare const VpcConnectionSubnetIdList: any;
export type SecurityGroupId = string;
export interface VpcPropertiesInput {
    vpcId: string;
    subnetIds: string[];
    securityGroupId?: string;
}
export declare const VpcPropertiesInput: S.Schema<VpcPropertiesInput>;
export interface GitPropertiesInput {
    codeConnectionArn: string;
    repositoryId: string;
    defaultBranch: string;
}
export declare const GitPropertiesInput: S.Schema<GitPropertiesInput>;
export type ConnectionPropertiesInput = {
    athenaProperties: AthenaPropertiesInput;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties: GluePropertiesInput;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties: HyperPodPropertiesInput;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties: IamPropertiesInput;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties: RedshiftPropertiesInput;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties: SparkEmrPropertiesInput;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties: SparkGluePropertiesInput;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties: S3PropertiesInput;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties: SnowflakePropertiesInput;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties: AmazonQPropertiesInput;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties: MlflowPropertiesInput;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties: WorkflowsMwaaPropertiesInput;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties: WorkflowsServerlessPropertiesInput;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties: LakehousePropertiesInput;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties: VpcPropertiesInput;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties: GitPropertiesInput;
};
export declare const ConnectionPropertiesInput: any;
export type ConnectionScope = "DOMAIN" | "PROJECT" | (string & {});
export declare const ConnectionScope: any;
export interface CreateConnectionInput {
    awsLocation?: AwsLocation;
    clientToken?: string;
    configurations?: Configuration[];
    description?: string | redacted.Redacted<string>;
    domainIdentifier: string;
    environmentIdentifier?: string;
    name: string;
    props?: ConnectionPropertiesInput;
    enableTrustedIdentityPropagation?: boolean;
    scope?: ConnectionScope;
}
export declare const CreateConnectionInput: S.Schema<CreateConnectionInput>;
export type ConnectionType = "ATHENA" | "BIGQUERY" | "DATABRICKS" | "DOCUMENTDB" | "DYNAMODB" | "HYPERPOD" | "IAM" | "MYSQL" | "OPENSEARCH" | "ORACLE" | "POSTGRESQL" | "REDSHIFT" | "S3" | "SAPHANA" | "SNOWFLAKE" | "SPARK" | "SQLSERVER" | "TERADATA" | "VERTICA" | "WORKFLOWS_MWAA" | "AMAZON_Q" | "MLFLOW" | "VPC" | "GIT" | (string & {});
export declare const ConnectionType: any;
export type MatchCriteria = string[];
export declare const MatchCriteria: any;
export type ConnectionStatus = "CREATING" | "CREATE_FAILED" | "DELETING" | "DELETE_FAILED" | "READY" | "UPDATING" | "UPDATE_FAILED" | "DELETED" | (string & {});
export declare const ConnectionStatus: any;
export interface AuthenticationConfiguration {
    authenticationType?: AuthenticationType;
    secretArn?: string;
    oAuth2Properties?: OAuth2Properties;
}
export declare const AuthenticationConfiguration: S.Schema<AuthenticationConfiguration>;
export interface GlueConnection {
    name?: string;
    description?: string;
    connectionType?: ConnectionType;
    matchCriteria?: string[];
    connectionProperties?: {
        [key: string]: string | undefined;
    };
    sparkProperties?: {
        [key: string]: string | undefined;
    };
    athenaProperties?: {
        [key: string]: string | undefined;
    };
    pythonProperties?: {
        [key: string]: string | undefined;
    };
    physicalConnectionRequirements?: PhysicalConnectionRequirements;
    creationTime?: Date;
    lastUpdatedTime?: Date;
    lastUpdatedBy?: string;
    status?: ConnectionStatus;
    statusReason?: string;
    lastConnectionValidationTime?: Date;
    authenticationConfiguration?: AuthenticationConfiguration;
    connectionSchemaVersion?: number;
    compatibleComputeEnvironments?: ComputeEnvironments[];
}
export declare const GlueConnection: S.Schema<GlueConnection>;
export type Protocol = "ATHENA" | "GLUE_INTERACTIVE_SESSION" | "HTTPS" | "JDBC" | "LIVY" | "ODBC" | "PRISM" | (string & {});
export declare const Protocol: any;
export interface PhysicalEndpoint {
    awsLocation?: AwsLocation;
    glueConnectionName?: string;
    glueConnectionNames?: string[];
    glueConnection?: GlueConnection;
    enableTrustedIdentityPropagation?: boolean;
    host?: string;
    port?: number;
    protocol?: Protocol;
    stage?: string;
}
export declare const PhysicalEndpoint: S.Schema<PhysicalEndpoint>;
export type PhysicalEndpoints = PhysicalEndpoint[];
export declare const PhysicalEndpoints: any;
export interface AthenaPropertiesOutput {
    workgroupName?: string;
}
export declare const AthenaPropertiesOutput: S.Schema<AthenaPropertiesOutput>;
export interface GluePropertiesOutput {
    status?: ConnectionStatus;
    errorMessage?: string;
}
export declare const GluePropertiesOutput: S.Schema<GluePropertiesOutput>;
export type HyperPodOrchestrator = "EKS" | "SLURM" | (string & {});
export declare const HyperPodOrchestrator: any;
export interface HyperPodPropertiesOutput {
    clusterName: string;
    clusterArn?: string;
    orchestrator?: HyperPodOrchestrator;
}
export declare const HyperPodPropertiesOutput: S.Schema<HyperPodPropertiesOutput>;
export interface IamPropertiesOutput {
    environmentId?: string;
    glueLineageSyncEnabled?: boolean;
}
export declare const IamPropertiesOutput: S.Schema<IamPropertiesOutput>;
export interface RedshiftLineageSyncConfigurationOutput {
    lineageJobId?: string;
    enabled?: boolean;
    schedule?: LineageSyncSchedule;
}
export declare const RedshiftLineageSyncConfigurationOutput: S.Schema<RedshiftLineageSyncConfigurationOutput>;
export interface RedshiftPropertiesOutput {
    storage?: RedshiftStorageProperties;
    credentials?: RedshiftCredentials;
    isProvisionedSecret?: boolean;
    jdbcIamUrl?: string;
    jdbcUrl?: string;
    redshiftTempDir?: string;
    lineageSync?: RedshiftLineageSyncConfigurationOutput;
    status?: ConnectionStatus;
    databaseName?: string;
}
export declare const RedshiftPropertiesOutput: S.Schema<RedshiftPropertiesOutput>;
export type GovernanceType = "AWS_MANAGED" | "USER_MANAGED" | (string & {});
export declare const GovernanceType: any;
export interface ManagedEndpointCredentials {
    id?: string;
    token?: string;
}
export declare const ManagedEndpointCredentials: S.Schema<ManagedEndpointCredentials>;
export interface SparkEmrPropertiesOutput {
    computeArn?: string;
    credentials?: UsernamePassword;
    credentialsExpiration?: Date;
    governanceType?: GovernanceType;
    instanceProfileArn?: string;
    javaVirtualEnv?: string;
    livyEndpoint?: string;
    logUri?: string;
    pythonVirtualEnv?: string;
    runtimeRole?: string;
    trustedCertificatesS3Uri?: string;
    certificateData?: string;
    managedEndpointArn?: string;
    managedEndpointCredentials?: ManagedEndpointCredentials;
}
export declare const SparkEmrPropertiesOutput: S.Schema<SparkEmrPropertiesOutput>;
export interface SparkGluePropertiesOutput {
    additionalArgs?: SparkGlueArgs;
    glueConnectionName?: string;
    glueConnectionNames?: string[];
    glueVersion?: string;
    idleTimeout?: number;
    javaVirtualEnv?: string;
    numberOfWorkers?: number;
    pythonVirtualEnv?: string;
    workerType?: string;
}
export declare const SparkGluePropertiesOutput: S.Schema<SparkGluePropertiesOutput>;
export interface S3PropertiesOutput {
    s3Uri: string;
    s3AccessGrantLocationId?: string;
    registerS3AccessGrantLocation?: boolean;
    status?: ConnectionStatus;
    errorMessage?: string;
}
export declare const S3PropertiesOutput: S.Schema<S3PropertiesOutput>;
export interface LineageSyncOutput {
    lineageJobId?: string;
    timezone?: Timezone;
    enabled?: boolean;
    schedule?: string;
}
export declare const LineageSyncOutput: S.Schema<LineageSyncOutput>;
export interface SnowflakePropertiesOutput {
    snowflakeRole: string;
    identityMapping: IdentityMapping;
    lineageSync: LineageSyncOutput;
    status: ConnectionStatus;
    errorMessage?: string;
}
export declare const SnowflakePropertiesOutput: S.Schema<SnowflakePropertiesOutput>;
export interface AmazonQPropertiesOutput {
    isEnabled: boolean;
    profileArn?: string;
    authMode?: string;
}
export declare const AmazonQPropertiesOutput: S.Schema<AmazonQPropertiesOutput>;
export interface MlflowPropertiesOutput {
    trackingServerArn?: string;
}
export declare const MlflowPropertiesOutput: S.Schema<MlflowPropertiesOutput>;
export interface WorkflowsMwaaPropertiesOutput {
    mwaaEnvironmentName?: string;
}
export declare const WorkflowsMwaaPropertiesOutput: S.Schema<WorkflowsMwaaPropertiesOutput>;
export interface WorkflowsServerlessPropertiesOutput {
}
export declare const WorkflowsServerlessPropertiesOutput: S.Schema<WorkflowsServerlessPropertiesOutput>;
export interface LakehousePropertiesOutput {
    glueLineageSyncEnabled?: boolean;
}
export declare const LakehousePropertiesOutput: S.Schema<LakehousePropertiesOutput>;
export interface VpcPropertiesOutput {
    vpcId: string;
    subnetIds: string[];
    status: ConnectionStatus;
    securityGroupId?: string;
    glueConnectionNames?: string[];
}
export declare const VpcPropertiesOutput: S.Schema<VpcPropertiesOutput>;
export interface GitPropertiesOutput {
    codeConnectionArn: string;
    repositoryId: string;
    defaultBranch: string;
    status?: ConnectionStatus;
    errorMessage?: string;
}
export declare const GitPropertiesOutput: S.Schema<GitPropertiesOutput>;
export type ConnectionPropertiesOutput = {
    athenaProperties: AthenaPropertiesOutput;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties: GluePropertiesOutput;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties: HyperPodPropertiesOutput;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties: IamPropertiesOutput;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties: RedshiftPropertiesOutput;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties: SparkEmrPropertiesOutput;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties: SparkGluePropertiesOutput;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties: S3PropertiesOutput;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties: SnowflakePropertiesOutput;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties: AmazonQPropertiesOutput;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties: MlflowPropertiesOutput;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties: WorkflowsMwaaPropertiesOutput;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties: WorkflowsServerlessPropertiesOutput;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties: LakehousePropertiesOutput;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties: VpcPropertiesOutput;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    hyperPodProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    sparkGlueProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    workflowsMwaaProperties?: never;
    workflowsServerlessProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties: GitPropertiesOutput;
};
export declare const ConnectionPropertiesOutput: any;
export interface CreateConnectionOutput {
    connectionId: string;
    configurations?: Configuration[];
    description?: string | redacted.Redacted<string>;
    domainId: string;
    domainUnitId: string;
    environmentId?: string;
    name: string;
    physicalEndpoints: PhysicalEndpoint[];
    projectId?: string;
    props?: ConnectionPropertiesOutput;
    type: ConnectionType;
    scope?: ConnectionScope;
}
export declare const CreateConnectionOutput: S.Schema<CreateConnectionOutput>;
export type DataProductName = string | redacted.Redacted<string>;
export type DataProductDescription = string | redacted.Redacted<string>;
export type DataProductItemType = "ASSET" | (string & {});
export declare const DataProductItemType: any;
export type ItemGlossaryTerms = string[];
export declare const ItemGlossaryTerms: any;
export interface DataProductItem {
    itemType: DataProductItemType;
    identifier: string;
    revision?: string;
    glossaryTerms?: string[];
}
export declare const DataProductItem: S.Schema<DataProductItem>;
export type DataProductItems = DataProductItem[];
export declare const DataProductItems: any;
export interface CreateDataProductInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    owningProjectIdentifier: string;
    description?: string | redacted.Redacted<string>;
    glossaryTerms?: string[];
    formsInput?: FormInput[];
    items?: DataProductItem[];
    clientToken?: string;
}
export declare const CreateDataProductInput: S.Schema<CreateDataProductInput>;
export type DataProductId = string;
export type DataProductStatus = "CREATED" | "CREATING" | "CREATE_FAILED" | (string & {});
export declare const DataProductStatus: any;
export interface CreateDataProductOutput {
    domainId: string;
    id: string;
    revision: string;
    owningProjectId: string;
    name: string | redacted.Redacted<string>;
    status: DataProductStatus;
    description?: string | redacted.Redacted<string>;
    glossaryTerms?: string[];
    items?: DataProductItem[];
    formsOutput?: FormOutput[];
    createdAt?: Date;
    createdBy?: string;
    firstRevisionCreatedAt?: Date;
    firstRevisionCreatedBy?: string;
}
export declare const CreateDataProductOutput: S.Schema<CreateDataProductOutput>;
export interface CreateDataProductRevisionInput {
    domainIdentifier: string;
    identifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    glossaryTerms?: string[];
    items?: DataProductItem[];
    formsInput?: FormInput[];
    clientToken?: string;
}
export declare const CreateDataProductRevisionInput: S.Schema<CreateDataProductRevisionInput>;
export interface CreateDataProductRevisionOutput {
    domainId: string;
    id: string;
    revision: string;
    owningProjectId: string;
    name: string | redacted.Redacted<string>;
    status: DataProductStatus;
    description?: string | redacted.Redacted<string>;
    glossaryTerms?: string[];
    items?: DataProductItem[];
    formsOutput?: FormOutput[];
    createdAt?: Date;
    createdBy?: string;
    firstRevisionCreatedAt?: Date;
    firstRevisionCreatedBy?: string;
}
export declare const CreateDataProductRevisionOutput: S.Schema<CreateDataProductRevisionOutput>;
export type Name = string | redacted.Redacted<string>;
export type DataSourceType = string;
export type FilterExpressionType = "INCLUDE" | "EXCLUDE" | (string & {});
export declare const FilterExpressionType: any;
export interface FilterExpression {
    type: FilterExpressionType;
    expression: string;
}
export declare const FilterExpression: S.Schema<FilterExpression>;
export type FilterExpressions = FilterExpression[];
export declare const FilterExpressions: any;
export interface RelationalFilterConfiguration {
    databaseName: string;
    schemaName?: string;
    filterExpressions?: FilterExpression[];
}
export declare const RelationalFilterConfiguration: S.Schema<RelationalFilterConfiguration>;
export type RelationalFilterConfigurations = RelationalFilterConfiguration[];
export declare const RelationalFilterConfigurations: any;
export interface GlueRunConfigurationInput {
    dataAccessRole?: string;
    relationalFilterConfigurations: RelationalFilterConfiguration[];
    autoImportDataQualityResult?: boolean;
    catalogName?: string;
}
export declare const GlueRunConfigurationInput: S.Schema<GlueRunConfigurationInput>;
export interface RedshiftCredentialConfiguration {
    secretManagerArn: string;
}
export declare const RedshiftCredentialConfiguration: S.Schema<RedshiftCredentialConfiguration>;
export interface RedshiftClusterStorage {
    clusterName: string;
}
export declare const RedshiftClusterStorage: S.Schema<RedshiftClusterStorage>;
export interface RedshiftServerlessStorage {
    workgroupName: string;
}
export declare const RedshiftServerlessStorage: S.Schema<RedshiftServerlessStorage>;
export type RedshiftStorage = {
    redshiftClusterSource: RedshiftClusterStorage;
    redshiftServerlessSource?: never;
} | {
    redshiftClusterSource?: never;
    redshiftServerlessSource: RedshiftServerlessStorage;
};
export declare const RedshiftStorage: any;
export interface RedshiftRunConfigurationInput {
    dataAccessRole?: string;
    relationalFilterConfigurations: RelationalFilterConfiguration[];
    redshiftCredentialConfiguration?: RedshiftCredentialConfiguration;
    redshiftStorage?: RedshiftStorage;
}
export declare const RedshiftRunConfigurationInput: S.Schema<RedshiftRunConfigurationInput>;
export type SageMakerAssetType = string;
export type SageMakerResourceArn = string;
export type TrackingAssetArns = string[];
export declare const TrackingAssetArns: any;
export type TrackingAssets = {
    [key: string]: string[] | undefined;
};
export declare const TrackingAssets: any;
export interface SageMakerRunConfigurationInput {
    trackingAssets: {
        [key: string]: string[] | undefined;
    };
}
export declare const SageMakerRunConfigurationInput: S.Schema<SageMakerRunConfigurationInput>;
export type DataSourceConfigurationInput = {
    glueRunConfiguration: GlueRunConfigurationInput;
    redshiftRunConfiguration?: never;
    sageMakerRunConfiguration?: never;
} | {
    glueRunConfiguration?: never;
    redshiftRunConfiguration: RedshiftRunConfigurationInput;
    sageMakerRunConfiguration?: never;
} | {
    glueRunConfiguration?: never;
    redshiftRunConfiguration?: never;
    sageMakerRunConfiguration: SageMakerRunConfigurationInput;
};
export declare const DataSourceConfigurationInput: any;
export interface RecommendationConfiguration {
    enableBusinessNameGeneration?: boolean;
}
export declare const RecommendationConfiguration: S.Schema<RecommendationConfiguration>;
export type EnableSetting = "ENABLED" | "DISABLED" | (string & {});
export declare const EnableSetting: any;
export type CronString = string;
export interface ScheduleConfiguration {
    timezone?: Timezone;
    schedule?: string;
}
export declare const ScheduleConfiguration: S.Schema<ScheduleConfiguration>;
export interface CreateDataSourceInput {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    domainIdentifier: string;
    projectIdentifier: string;
    environmentIdentifier?: string;
    connectionIdentifier?: string;
    type: string;
    configuration?: DataSourceConfigurationInput;
    recommendation?: RecommendationConfiguration;
    enableSetting?: EnableSetting;
    schedule?: ScheduleConfiguration;
    publishOnImport?: boolean;
    assetFormsInput?: FormInput[];
    clientToken?: string;
}
export declare const CreateDataSourceInput: S.Schema<CreateDataSourceInput>;
export type DataSourceId = string;
export type DataSourceStatus = "CREATING" | "FAILED_CREATION" | "READY" | "UPDATING" | "FAILED_UPDATE" | "RUNNING" | "DELETING" | "FAILED_DELETION" | (string & {});
export declare const DataSourceStatus: any;
export interface GlueRunConfigurationOutput {
    accountId?: string;
    region?: string;
    dataAccessRole?: string;
    relationalFilterConfigurations: RelationalFilterConfiguration[];
    autoImportDataQualityResult?: boolean;
    catalogName?: string;
}
export declare const GlueRunConfigurationOutput: S.Schema<GlueRunConfigurationOutput>;
export interface RedshiftRunConfigurationOutput {
    accountId?: string;
    region?: string;
    dataAccessRole?: string;
    relationalFilterConfigurations: RelationalFilterConfiguration[];
    redshiftCredentialConfiguration?: RedshiftCredentialConfiguration;
    redshiftStorage: RedshiftStorage;
}
export declare const RedshiftRunConfigurationOutput: S.Schema<RedshiftRunConfigurationOutput>;
export interface SageMakerRunConfigurationOutput {
    accountId?: string;
    region?: string;
    trackingAssets: {
        [key: string]: string[] | undefined;
    };
}
export declare const SageMakerRunConfigurationOutput: S.Schema<SageMakerRunConfigurationOutput>;
export type DataSourceConfigurationOutput = {
    glueRunConfiguration: GlueRunConfigurationOutput;
    redshiftRunConfiguration?: never;
    sageMakerRunConfiguration?: never;
} | {
    glueRunConfiguration?: never;
    redshiftRunConfiguration: RedshiftRunConfigurationOutput;
    sageMakerRunConfiguration?: never;
} | {
    glueRunConfiguration?: never;
    redshiftRunConfiguration?: never;
    sageMakerRunConfiguration: SageMakerRunConfigurationOutput;
};
export declare const DataSourceConfigurationOutput: any;
export type DataSourceRunStatus = "REQUESTED" | "RUNNING" | "FAILED" | "PARTIALLY_SUCCEEDED" | "SUCCESS" | (string & {});
export declare const DataSourceRunStatus: any;
export type DataSourceErrorType = "ACCESS_DENIED_EXCEPTION" | "CONFLICT_EXCEPTION" | "INTERNAL_SERVER_EXCEPTION" | "RESOURCE_NOT_FOUND_EXCEPTION" | "SERVICE_QUOTA_EXCEEDED_EXCEPTION" | "THROTTLING_EXCEPTION" | "VALIDATION_EXCEPTION" | (string & {});
export declare const DataSourceErrorType: any;
export interface DataSourceErrorMessage {
    errorType: DataSourceErrorType;
    errorDetail?: string;
}
export declare const DataSourceErrorMessage: S.Schema<DataSourceErrorMessage>;
export interface CreateDataSourceOutput {
    id: string;
    status?: DataSourceStatus;
    type?: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    domainId: string;
    projectId: string;
    environmentId?: string;
    connectionId?: string;
    configuration?: DataSourceConfigurationOutput;
    recommendation?: RecommendationConfiguration;
    enableSetting?: EnableSetting;
    publishOnImport?: boolean;
    assetFormsOutput?: FormOutput[];
    schedule?: ScheduleConfiguration;
    lastRunStatus?: DataSourceRunStatus;
    lastRunAt?: Date;
    lastRunErrorMessage?: DataSourceErrorMessage;
    errorMessage?: DataSourceErrorMessage;
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const CreateDataSourceOutput: S.Schema<CreateDataSourceOutput>;
export type AuthType = "IAM_IDC" | "DISABLED" | (string & {});
export declare const AuthType: any;
export type UserAssignment = "AUTOMATIC" | "MANUAL" | (string & {});
export declare const UserAssignment: any;
export interface SingleSignOn {
    type?: AuthType;
    userAssignment?: UserAssignment;
    idcInstanceArn?: string;
}
export declare const SingleSignOn: S.Schema<SingleSignOn>;
export type RoleArn = string;
export type KmsKeyArn = string;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export type DomainVersion = "V1" | "V2" | (string & {});
export declare const DomainVersion: any;
export interface CreateDomainInput {
    name: string;
    description?: string;
    singleSignOn?: SingleSignOn;
    domainExecutionRole?: string;
    kmsKeyIdentifier?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    domainVersion?: DomainVersion;
    serviceRole?: string;
    clientToken?: string;
}
export declare const CreateDomainInput: S.Schema<CreateDomainInput>;
export type DomainStatus = "CREATING" | "AVAILABLE" | "CREATION_FAILED" | "DELETING" | "DELETED" | "DELETION_FAILED" | (string & {});
export declare const DomainStatus: any;
export interface CreateDomainOutput {
    id: string;
    rootDomainUnitId?: string;
    name?: string;
    description?: string;
    singleSignOn?: SingleSignOn;
    domainExecutionRole?: string;
    arn?: string;
    kmsKeyIdentifier?: string;
    status?: DomainStatus;
    portalUrl?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    domainVersion?: DomainVersion;
    serviceRole?: string;
}
export declare const CreateDomainOutput: S.Schema<CreateDomainOutput>;
export type DomainUnitName = string | redacted.Redacted<string>;
export type DomainUnitDescription = string | redacted.Redacted<string>;
export interface CreateDomainUnitInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    parentDomainUnitIdentifier: string;
    description?: string | redacted.Redacted<string>;
    clientToken?: string;
}
export declare const CreateDomainUnitInput: S.Schema<CreateDomainUnitInput>;
export interface DomainUnitUserProperties {
    userId?: string;
}
export declare const DomainUnitUserProperties: S.Schema<DomainUnitUserProperties>;
export interface DomainUnitGroupProperties {
    groupId?: string;
}
export declare const DomainUnitGroupProperties: S.Schema<DomainUnitGroupProperties>;
export type DomainUnitOwnerProperties = {
    user: DomainUnitUserProperties;
    group?: never;
} | {
    user?: never;
    group: DomainUnitGroupProperties;
};
export declare const DomainUnitOwnerProperties: any;
export type DomainUnitOwners = DomainUnitOwnerProperties[];
export declare const DomainUnitOwners: any;
export type DomainUnitIds = string[];
export declare const DomainUnitIds: any;
export interface CreateDomainUnitOutput {
    id: string;
    domainId: string;
    name: string | redacted.Redacted<string>;
    parentDomainUnitId?: string;
    description?: string | redacted.Redacted<string>;
    owners: DomainUnitOwnerProperties[];
    ancestorDomainUnitIds: string[];
    createdAt?: Date;
    createdBy?: string;
}
export declare const CreateDomainUnitOutput: S.Schema<CreateDomainUnitOutput>;
export type EnvironmentProfileId = string;
export interface EnvironmentParameter {
    name?: string;
    value?: string;
}
export declare const EnvironmentParameter: S.Schema<EnvironmentParameter>;
export type EnvironmentParametersList = EnvironmentParameter[];
export declare const EnvironmentParametersList: any;
export type EnvironmentConfigurationName = string | redacted.Redacted<string>;
export interface CreateEnvironmentInput {
    projectIdentifier: string;
    domainIdentifier: string;
    description?: string;
    name: string;
    environmentProfileIdentifier?: string;
    userParameters?: EnvironmentParameter[];
    glossaryTerms?: string[];
    environmentAccountIdentifier?: string;
    environmentAccountRegion?: string;
    environmentBlueprintIdentifier?: string;
    deploymentOrder?: number;
    environmentConfigurationId?: string;
    environmentConfigurationName?: string | redacted.Redacted<string>;
}
export declare const CreateEnvironmentInput: S.Schema<CreateEnvironmentInput>;
export type EnvironmentName = string | redacted.Redacted<string>;
export interface Resource {
    provider?: string;
    name?: string;
    value: string;
    type: string;
}
export declare const Resource: S.Schema<Resource>;
export type ResourceList = Resource[];
export declare const ResourceList: any;
export type EnvironmentStatus = "ACTIVE" | "CREATING" | "UPDATING" | "DELETING" | "CREATE_FAILED" | "UPDATE_FAILED" | "DELETE_FAILED" | "VALIDATION_FAILED" | "SUSPENDED" | "DISABLED" | "EXPIRED" | "DELETED" | "INACCESSIBLE" | (string & {});
export declare const EnvironmentStatus: any;
export type ConfigurableActionTypeAuthorization = "IAM" | "HTTPS" | (string & {});
export declare const ConfigurableActionTypeAuthorization: any;
export interface ConfigurableActionParameter {
    key?: string;
    value?: string;
}
export declare const ConfigurableActionParameter: S.Schema<ConfigurableActionParameter>;
export type ConfigurableActionParameterList = ConfigurableActionParameter[];
export declare const ConfigurableActionParameterList: any;
export interface ConfigurableEnvironmentAction {
    type: string;
    auth?: ConfigurableActionTypeAuthorization;
    parameters: ConfigurableActionParameter[];
}
export declare const ConfigurableEnvironmentAction: S.Schema<ConfigurableEnvironmentAction>;
export type EnvironmentActionList = ConfigurableEnvironmentAction[];
export declare const EnvironmentActionList: any;
export interface CustomParameter {
    keyName: string;
    description?: string | redacted.Redacted<string>;
    fieldType: string;
    defaultValue?: string;
    isEditable?: boolean;
    isOptional?: boolean;
    isUpdateSupported?: boolean;
}
export declare const CustomParameter: S.Schema<CustomParameter>;
export type CustomParameterList = CustomParameter[];
export declare const CustomParameterList: any;
export type DeploymentType = "CREATE" | "UPDATE" | "DELETE" | (string & {});
export declare const DeploymentType: any;
export type DeploymentStatus = "IN_PROGRESS" | "SUCCESSFUL" | "FAILED" | "PENDING_DEPLOYMENT" | (string & {});
export declare const DeploymentStatus: any;
export interface EnvironmentError {
    code?: string;
    message: string;
}
export declare const EnvironmentError: S.Schema<EnvironmentError>;
export type DeploymentMessage = string;
export type DeploymentMessagesList = string[];
export declare const DeploymentMessagesList: any;
export interface Deployment {
    deploymentId?: string;
    deploymentType?: DeploymentType;
    deploymentStatus?: DeploymentStatus;
    failureReason?: EnvironmentError;
    messages?: string[];
    isDeploymentComplete?: boolean;
}
export declare const Deployment: S.Schema<Deployment>;
export interface CloudFormationProperties {
    templateUrl: string;
}
export declare const CloudFormationProperties: S.Schema<CloudFormationProperties>;
export type ProvisioningProperties = {
    cloudFormation: CloudFormationProperties;
    manual?: never;
} | {
    cloudFormation?: never;
    manual: Record<string, never>;
};
export declare const ProvisioningProperties: any;
export interface DeploymentProperties {
    startTimeoutMinutes?: number;
    endTimeoutMinutes?: number;
}
export declare const DeploymentProperties: S.Schema<DeploymentProperties>;
export type EnvironmentBlueprintId = string;
export type EnvironmentConfigurationId = string | redacted.Redacted<string>;
export interface CreateEnvironmentOutput {
    projectId: string;
    id?: string;
    domainId: string;
    createdBy: string;
    createdAt?: Date;
    updatedAt?: Date;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    environmentProfileId?: string;
    awsAccountId?: string;
    awsAccountRegion?: string;
    provider: string;
    provisionedResources?: Resource[];
    status?: EnvironmentStatus;
    environmentActions?: ConfigurableEnvironmentAction[];
    glossaryTerms?: string[];
    userParameters?: CustomParameter[];
    lastDeployment?: Deployment;
    provisioningProperties?: ProvisioningProperties;
    deploymentProperties?: DeploymentProperties;
    environmentBlueprintId?: string;
    environmentConfigurationId?: string | redacted.Redacted<string>;
    environmentConfigurationName?: string | redacted.Redacted<string>;
}
export declare const CreateEnvironmentOutput: S.Schema<CreateEnvironmentOutput>;
export interface AwsConsoleLinkParameters {
    uri?: string;
}
export declare const AwsConsoleLinkParameters: S.Schema<AwsConsoleLinkParameters>;
export type ActionParameters = {
    awsConsoleLink: AwsConsoleLinkParameters;
};
export declare const ActionParameters: any;
export interface CreateEnvironmentActionInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    name: string;
    parameters: ActionParameters;
    description?: string;
}
export declare const CreateEnvironmentActionInput: S.Schema<CreateEnvironmentActionInput>;
export type EnvironmentActionId = string;
export interface CreateEnvironmentActionOutput {
    domainId: string;
    environmentId: string;
    id: string;
    name: string;
    parameters: ActionParameters;
    description?: string;
}
export declare const CreateEnvironmentActionOutput: S.Schema<CreateEnvironmentActionOutput>;
export type EnvironmentBlueprintName = string;
export interface CreateEnvironmentBlueprintInput {
    domainIdentifier: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    provisioningProperties: ProvisioningProperties;
    userParameters?: CustomParameter[];
}
export declare const CreateEnvironmentBlueprintInput: S.Schema<CreateEnvironmentBlueprintInput>;
export interface CreateEnvironmentBlueprintOutput {
    id: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    provider: string;
    provisioningProperties: ProvisioningProperties;
    deploymentProperties?: DeploymentProperties;
    userParameters?: CustomParameter[];
    glossaryTerms?: string[];
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const CreateEnvironmentBlueprintOutput: S.Schema<CreateEnvironmentBlueprintOutput>;
export type EnvironmentProfileName = string | redacted.Redacted<string>;
export interface CreateEnvironmentProfileInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    environmentBlueprintIdentifier: string;
    projectIdentifier: string;
    userParameters?: EnvironmentParameter[];
    awsAccountId?: string;
    awsAccountRegion?: string;
}
export declare const CreateEnvironmentProfileInput: S.Schema<CreateEnvironmentProfileInput>;
export interface CreateEnvironmentProfileOutput {
    id: string;
    domainId: string;
    awsAccountId?: string;
    awsAccountRegion?: string;
    createdBy: string;
    createdAt?: Date;
    updatedAt?: Date;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    environmentBlueprintId: string;
    projectId?: string;
    userParameters?: CustomParameter[];
}
export declare const CreateEnvironmentProfileOutput: S.Schema<CreateEnvironmentProfileOutput>;
export type Smithy = string;
export type Model = {
    smithy: string;
};
export declare const Model: any;
export type FormTypeStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const FormTypeStatus: any;
export interface CreateFormTypeInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    model: Model;
    owningProjectIdentifier: string;
    status?: FormTypeStatus;
    description?: string | redacted.Redacted<string>;
}
export declare const CreateFormTypeInput: S.Schema<CreateFormTypeInput>;
export interface CreateFormTypeOutput {
    domainId: string;
    name: string | redacted.Redacted<string>;
    revision: string;
    description?: string | redacted.Redacted<string>;
    owningProjectId?: string;
    originDomainId?: string;
    originProjectId?: string;
}
export declare const CreateFormTypeOutput: S.Schema<CreateFormTypeOutput>;
export type GlossaryName = string | redacted.Redacted<string>;
export type GlossaryDescription = string | redacted.Redacted<string>;
export type GlossaryStatus = "DISABLED" | "ENABLED" | (string & {});
export declare const GlossaryStatus: any;
export type GlossaryUsageRestriction = "ASSET_GOVERNED_TERMS" | (string & {});
export declare const GlossaryUsageRestriction: any;
export type GlossaryUsageRestrictions = GlossaryUsageRestriction[];
export declare const GlossaryUsageRestrictions: any;
export interface CreateGlossaryInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    owningProjectIdentifier: string;
    description?: string | redacted.Redacted<string>;
    status?: GlossaryStatus;
    usageRestrictions?: GlossaryUsageRestriction[];
    clientToken?: string;
}
export declare const CreateGlossaryInput: S.Schema<CreateGlossaryInput>;
export type GlossaryId = string;
export interface CreateGlossaryOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    description?: string | redacted.Redacted<string>;
    status?: GlossaryStatus;
    usageRestrictions?: GlossaryUsageRestriction[];
}
export declare const CreateGlossaryOutput: S.Schema<CreateGlossaryOutput>;
export type GlossaryTermStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const GlossaryTermStatus: any;
export type LongDescription = string | redacted.Redacted<string>;
export interface TermRelations {
    isA?: string[];
    classifies?: string[];
}
export declare const TermRelations: S.Schema<TermRelations>;
export interface CreateGlossaryTermInput {
    domainIdentifier: string;
    glossaryIdentifier: string;
    name: string | redacted.Redacted<string>;
    status?: GlossaryTermStatus;
    shortDescription?: string | redacted.Redacted<string>;
    longDescription?: string | redacted.Redacted<string>;
    termRelations?: TermRelations;
    clientToken?: string;
}
export declare const CreateGlossaryTermInput: S.Schema<CreateGlossaryTermInput>;
export interface CreateGlossaryTermOutput {
    id: string;
    domainId: string;
    glossaryId: string;
    name: string | redacted.Redacted<string>;
    status: GlossaryTermStatus;
    shortDescription?: string | redacted.Redacted<string>;
    longDescription?: string | redacted.Redacted<string>;
    termRelations?: TermRelations;
    usageRestrictions?: GlossaryUsageRestriction[];
}
export declare const CreateGlossaryTermOutput: S.Schema<CreateGlossaryTermOutput>;
export interface CreateGroupProfileInput {
    domainIdentifier: string;
    groupIdentifier?: string;
    rolePrincipalArn?: string;
    clientToken?: string;
}
export declare const CreateGroupProfileInput: S.Schema<CreateGroupProfileInput>;
export type GroupProfileStatus = "ASSIGNED" | "NOT_ASSIGNED" | (string & {});
export declare const GroupProfileStatus: any;
export interface CreateGroupProfileOutput {
    domainId?: string;
    id?: string;
    status?: GroupProfileStatus;
    groupName?: string | redacted.Redacted<string>;
    rolePrincipalArn?: string;
    rolePrincipalId?: string;
}
export declare const CreateGroupProfileOutput: S.Schema<CreateGroupProfileOutput>;
export type EntityType = "ASSET" | "DATA_PRODUCT" | (string & {});
export declare const EntityType: any;
export type ChangeAction = "PUBLISH" | "UNPUBLISH" | (string & {});
export declare const ChangeAction: any;
export interface CreateListingChangeSetInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: EntityType;
    entityRevision?: string;
    action: ChangeAction;
    clientToken?: string;
}
export declare const CreateListingChangeSetInput: S.Schema<CreateListingChangeSetInput>;
export interface CreateListingChangeSetOutput {
    listingId: string;
    listingRevision: string;
    status: ListingStatus;
}
export declare const CreateListingChangeSetOutput: S.Schema<CreateListingChangeSetOutput>;
export type NotebookName = string | redacted.Redacted<string>;
export type MetadataKey = string;
export type MetadataValue = string | redacted.Redacted<string>;
export type Metadata = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const Metadata: any;
export type ParameterKey = string;
export type ParameterValue = string;
export type Parameters = {
    [key: string]: string | undefined;
};
export declare const Parameters: any;
export interface CreateNotebookInput {
    domainIdentifier: string;
    owningProjectIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    parameters?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const CreateNotebookInput: S.Schema<CreateNotebookInput>;
export type NotebookId = string;
export interface CellInformation {
}
export declare const CellInformation: S.Schema<CellInformation>;
export type CellOrder = CellInformation[];
export declare const CellOrder: any;
export type NotebookStatus = "ACTIVE" | "ARCHIVED" | "SYNC_IN_PROGRESS" | "SYNC_FAILED" | (string & {});
export declare const NotebookStatus: any;
export type ComputeId = string;
export type PackageManager = "UV" | (string & {});
export declare const PackageManager: any;
export interface PackageConfig {
    packageManager: PackageManager;
    packageSpecification?: string;
}
export declare const PackageConfig: S.Schema<PackageConfig>;
export interface EnvironmentConfig {
    imageVersion?: string;
    packageConfig?: PackageConfig;
}
export declare const EnvironmentConfig: S.Schema<EnvironmentConfig>;
export interface NotebookError {
    message: string;
}
export declare const NotebookError: S.Schema<NotebookError>;
export type GitConnectionId = string;
export type GitRepository = string | redacted.Redacted<string>;
export type GitBranch = string | redacted.Redacted<string>;
export type CommitHash = string;
export type FileName = string;
export type CommitMessage = string | redacted.Redacted<string>;
export interface GitMetadata {
    connectionId: string;
    repository: string | redacted.Redacted<string>;
    branch: string | redacted.Redacted<string>;
    commitHash: string;
    fileName?: string;
    committedAt?: Date;
    commitMessage?: string | redacted.Redacted<string>;
}
export declare const GitMetadata: S.Schema<GitMetadata>;
export interface CreateNotebookOutput {
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    domainId: string;
    cellOrder: CellInformation[];
    status: NotebookStatus;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    lockedBy?: string;
    lockedAt?: Date;
    lockExpiresAt?: Date;
    computeId?: string;
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    parameters?: {
        [key: string]: string | undefined;
    };
    environmentConfiguration?: EnvironmentConfig;
    error?: NotebookError;
    gitMetadata?: GitMetadata;
}
export declare const CreateNotebookOutput: S.Schema<CreateNotebookOutput>;
export type ProjectProfileId = string;
export interface EnvironmentResolvedAccount {
    awsAccountId: string;
    regionName: string;
    sourceAccountPoolId?: string;
}
export declare const EnvironmentResolvedAccount: S.Schema<EnvironmentResolvedAccount>;
export interface EnvironmentConfigurationUserParameter {
    environmentId?: string;
    environmentResolvedAccount?: EnvironmentResolvedAccount;
    environmentConfigurationName?: string | redacted.Redacted<string>;
    environmentParameters?: EnvironmentParameter[];
}
export declare const EnvironmentConfigurationUserParameter: S.Schema<EnvironmentConfigurationUserParameter>;
export type EnvironmentConfigurationUserParametersList = EnvironmentConfigurationUserParameter[];
export declare const EnvironmentConfigurationUserParametersList: any;
export type Member = {
    userIdentifier: string;
    groupIdentifier?: never;
} | {
    userIdentifier?: never;
    groupIdentifier: string;
};
export declare const Member: any;
export type UserDesignation = "PROJECT_OWNER" | "PROJECT_CONTRIBUTOR" | "PROJECT_CATALOG_VIEWER" | "PROJECT_CATALOG_CONSUMER" | "PROJECT_CATALOG_STEWARD" | (string & {});
export declare const UserDesignation: any;
export interface ProjectMembershipAssignment {
    member: Member;
    designation: UserDesignation;
}
export declare const ProjectMembershipAssignment: S.Schema<ProjectMembershipAssignment>;
export type ProjectMembershipAssignments = ProjectMembershipAssignment[];
export declare const ProjectMembershipAssignments: any;
export interface CreateProjectInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    resourceTags?: {
        [key: string]: string | undefined;
    };
    glossaryTerms?: string[];
    domainUnitId?: string;
    projectProfileId?: string;
    userParameters?: EnvironmentConfigurationUserParameter[];
    projectCategory?: string;
    projectExecutionRole?: string;
    membershipAssignments?: ProjectMembershipAssignment[];
}
export declare const CreateProjectInput: S.Schema<CreateProjectInput>;
export type ProjectStatus = "ACTIVE" | "DELETING" | "DELETE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "MOVING" | (string & {});
export declare const ProjectStatus: any;
export interface ProjectDeletionError {
    code?: string;
    message?: string;
}
export declare const ProjectDeletionError: S.Schema<ProjectDeletionError>;
export type FailureReasons = ProjectDeletionError[];
export declare const FailureReasons: any;
export type ResourceTagSource = "PROJECT" | "PROJECT_PROFILE" | (string & {});
export declare const ResourceTagSource: any;
export interface ResourceTag {
    key: string;
    value: string;
    source: ResourceTagSource;
}
export declare const ResourceTag: S.Schema<ResourceTag>;
export type ResourceTags = ResourceTag[];
export declare const ResourceTags: any;
export type OverallDeploymentStatus = "PENDING_DEPLOYMENT" | "IN_PROGRESS" | "SUCCESSFUL" | "FAILED_VALIDATION" | "FAILED_DEPLOYMENT" | (string & {});
export declare const OverallDeploymentStatus: any;
export type EnvironmentFailureReasonsList = EnvironmentError[];
export declare const EnvironmentFailureReasonsList: any;
export type EnvironmentFailureReasons = {
    [key: string]: EnvironmentError[] | undefined;
};
export declare const EnvironmentFailureReasons: any;
export interface EnvironmentDeploymentDetails {
    overallDeploymentStatus?: OverallDeploymentStatus;
    environmentFailureReasons?: {
        [key: string]: EnvironmentError[] | undefined;
    };
}
export declare const EnvironmentDeploymentDetails: S.Schema<EnvironmentDeploymentDetails>;
export interface CreateProjectOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    projectStatus?: ProjectStatus;
    failureReasons?: ProjectDeletionError[];
    createdBy: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    resourceTags?: ResourceTag[];
    glossaryTerms?: string[];
    domainUnitId?: string;
    projectProfileId?: string;
    userParameters?: EnvironmentConfigurationUserParameter[];
    environmentDeploymentDetails?: EnvironmentDeploymentDetails;
    projectCategory?: string;
}
export declare const CreateProjectOutput: S.Schema<CreateProjectOutput>;
export interface CreateProjectMembershipInput {
    domainIdentifier: string;
    projectIdentifier: string;
    member: Member;
    designation: UserDesignation;
}
export declare const CreateProjectMembershipInput: S.Schema<CreateProjectMembershipInput>;
export interface CreateProjectMembershipOutput {
}
export declare const CreateProjectMembershipOutput: S.Schema<CreateProjectMembershipOutput>;
export type ProjectProfileName = string | redacted.Redacted<string>;
export type Status = "ENABLED" | "DISABLED" | (string & {});
export declare const Status: any;
export interface ResourceTagParameter {
    key: string;
    value: string;
    isValueEditable: boolean;
}
export declare const ResourceTagParameter: S.Schema<ResourceTagParameter>;
export type ProjectResourceTagParameters = ResourceTagParameter[];
export declare const ProjectResourceTagParameters: any;
export type DeploymentMode = "ON_CREATE" | "ON_DEMAND" | (string & {});
export declare const DeploymentMode: any;
export type ParameterStorePath = string;
export type EnvironmentConfigurationParameterName = string;
export interface EnvironmentConfigurationParameter {
    name?: string;
    value?: string;
    isEditable?: boolean;
}
export declare const EnvironmentConfigurationParameter: S.Schema<EnvironmentConfigurationParameter>;
export type EnvironmentConfigurationParametersList = EnvironmentConfigurationParameter[];
export declare const EnvironmentConfigurationParametersList: any;
export interface EnvironmentConfigurationParametersDetails {
    ssmPath?: string;
    parameterOverrides?: EnvironmentConfigurationParameter[];
    resolvedParameters?: EnvironmentConfigurationParameter[];
}
export declare const EnvironmentConfigurationParametersDetails: S.Schema<EnvironmentConfigurationParametersDetails>;
export type AwsAccount = {
    awsAccountId: string;
    awsAccountIdPath?: never;
} | {
    awsAccountId?: never;
    awsAccountIdPath: string;
};
export declare const AwsAccount: any;
export type AccountPoolList = string[];
export declare const AccountPoolList: any;
export type RegionName = string;
export type Region = {
    regionName: string;
    regionNamePath?: never;
} | {
    regionName?: never;
    regionNamePath: string;
};
export declare const Region: any;
export type DeploymentOrder = number;
export interface EnvironmentConfiguration {
    name: string | redacted.Redacted<string>;
    id?: string | redacted.Redacted<string>;
    environmentBlueprintId: string;
    description?: string | redacted.Redacted<string>;
    deploymentMode?: DeploymentMode;
    configurationParameters?: EnvironmentConfigurationParametersDetails;
    awsAccount?: AwsAccount;
    accountPools?: string[];
    awsRegion?: Region;
    deploymentOrder?: number;
}
export declare const EnvironmentConfiguration: S.Schema<EnvironmentConfiguration>;
export type EnvironmentConfigurationsList = EnvironmentConfiguration[];
export declare const EnvironmentConfigurationsList: any;
export interface CreateProjectProfileInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    status?: Status;
    projectResourceTags?: ResourceTagParameter[];
    allowCustomProjectResourceTags?: boolean;
    projectResourceTagsDescription?: string | redacted.Redacted<string>;
    environmentConfigurations?: EnvironmentConfiguration[];
    domainUnitIdentifier?: string;
}
export declare const CreateProjectProfileInput: S.Schema<CreateProjectProfileInput>;
export interface CreateProjectProfileOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    status?: Status;
    projectResourceTags?: ResourceTagParameter[];
    allowCustomProjectResourceTags?: boolean;
    projectResourceTagsDescription?: string | redacted.Redacted<string>;
    environmentConfigurations?: EnvironmentConfiguration[];
    createdBy: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    domainUnitId?: string;
}
export declare const CreateProjectProfileOutput: S.Schema<CreateProjectProfileOutput>;
export type RuleName = string | redacted.Redacted<string>;
export interface DomainUnitTarget {
    domainUnitId: string;
    includeChildDomainUnits?: boolean;
}
export declare const DomainUnitTarget: S.Schema<DomainUnitTarget>;
export type RuleTarget = {
    domainUnitTarget: DomainUnitTarget;
};
export declare const RuleTarget: any;
export type RuleAction = "CREATE_LISTING_CHANGE_SET" | "CREATE_SUBSCRIPTION_REQUEST" | (string & {});
export declare const RuleAction: any;
export type RuleScopeSelectionMode = "ALL" | "SPECIFIC" | (string & {});
export declare const RuleScopeSelectionMode: any;
export type RuleAssetTypeList = string[];
export declare const RuleAssetTypeList: any;
export interface AssetTypesForRule {
    selectionMode: RuleScopeSelectionMode;
    specificAssetTypes?: string[];
}
export declare const AssetTypesForRule: S.Schema<AssetTypesForRule>;
export type RuleProjectIdentifierList = string[];
export declare const RuleProjectIdentifierList: any;
export interface ProjectsForRule {
    selectionMode: RuleScopeSelectionMode;
    specificProjects?: string[];
}
export declare const ProjectsForRule: S.Schema<ProjectsForRule>;
export interface RuleScope {
    assetType?: AssetTypesForRule;
    dataProduct?: boolean;
    project?: ProjectsForRule;
}
export declare const RuleScope: S.Schema<RuleScope>;
export interface MetadataFormReference {
    typeIdentifier: string;
    typeRevision: string;
}
export declare const MetadataFormReference: S.Schema<MetadataFormReference>;
export type RequiredMetadataFormList = MetadataFormReference[];
export declare const RequiredMetadataFormList: any;
export interface MetadataFormEnforcementDetail {
    requiredMetadataForms?: MetadataFormReference[];
}
export declare const MetadataFormEnforcementDetail: S.Schema<MetadataFormEnforcementDetail>;
export type GlossaryTermIdentifiers = string[];
export declare const GlossaryTermIdentifiers: any;
export interface GlossaryTermEnforcementDetail {
    requiredGlossaryTermIds?: string[];
}
export declare const GlossaryTermEnforcementDetail: S.Schema<GlossaryTermEnforcementDetail>;
export type RuleDetail = {
    metadataFormEnforcementDetail: MetadataFormEnforcementDetail;
    glossaryTermEnforcementDetail?: never;
} | {
    metadataFormEnforcementDetail?: never;
    glossaryTermEnforcementDetail: GlossaryTermEnforcementDetail;
};
export declare const RuleDetail: any;
export interface CreateRuleInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    target: RuleTarget;
    action: RuleAction;
    scope: RuleScope;
    detail: RuleDetail;
    description?: string | redacted.Redacted<string>;
    clientToken?: string;
}
export declare const CreateRuleInput: S.Schema<CreateRuleInput>;
export type RuleId = string;
export type RuleType = "METADATA_FORM_ENFORCEMENT" | "GLOSSARY_TERM_ENFORCEMENT" | (string & {});
export declare const RuleType: any;
export type RuleTargetType = "DOMAIN_UNIT" | (string & {});
export declare const RuleTargetType: any;
export interface CreateRuleOutput {
    identifier: string;
    name: string | redacted.Redacted<string>;
    ruleType: RuleType;
    target: RuleTarget;
    action: RuleAction;
    scope: RuleScope;
    detail: RuleDetail;
    targetType?: RuleTargetType;
    description?: string | redacted.Redacted<string>;
    createdAt: Date;
    createdBy: string;
}
export declare const CreateRuleOutput: S.Schema<CreateRuleOutput>;
export type SubscriptionTargetId = string;
export interface ListingRevisionInput {
    identifier: string;
    revision: string;
}
export declare const ListingRevisionInput: S.Schema<ListingRevisionInput>;
export type GrantedEntityInput = {
    listing: ListingRevisionInput;
};
export declare const GrantedEntityInput: any;
export interface AssetTargetNameMap {
    assetId: string;
    targetName: string;
}
export declare const AssetTargetNameMap: S.Schema<AssetTargetNameMap>;
export type AssetTargetNames = AssetTargetNameMap[];
export declare const AssetTargetNames: any;
export interface CreateSubscriptionGrantInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    subscriptionTargetIdentifier?: string;
    grantedEntity: GrantedEntityInput;
    assetTargetNames?: AssetTargetNameMap[];
    clientToken?: string;
}
export declare const CreateSubscriptionGrantInput: S.Schema<CreateSubscriptionGrantInput>;
export type SubscriptionGrantId = string;
export interface ListingRevision {
    id: string;
    revision: string;
}
export declare const ListingRevision: S.Schema<ListingRevision>;
export type GrantedEntity = {
    listing: ListingRevision;
};
export declare const GrantedEntity: any;
export type SubscriptionGrantOverallStatus = "PENDING" | "IN_PROGRESS" | "GRANT_FAILED" | "REVOKE_FAILED" | "GRANT_AND_REVOKE_FAILED" | "COMPLETED" | "INACCESSIBLE" | (string & {});
export declare const SubscriptionGrantOverallStatus: any;
export type SubscriptionGrantStatus = "GRANT_PENDING" | "REVOKE_PENDING" | "GRANT_IN_PROGRESS" | "REVOKE_IN_PROGRESS" | "GRANTED" | "REVOKED" | "GRANT_FAILED" | "REVOKE_FAILED" | (string & {});
export declare const SubscriptionGrantStatus: any;
export interface FailureCause {
    message?: string;
}
export declare const FailureCause: S.Schema<FailureCause>;
export interface SubscribedAsset {
    assetId: string;
    assetRevision: string;
    status: SubscriptionGrantStatus;
    targetName?: string;
    failureCause?: FailureCause;
    grantedTimestamp?: Date;
    failureTimestamp?: Date;
    assetScope?: AssetScope;
    permissions?: Permissions;
}
export declare const SubscribedAsset: S.Schema<SubscribedAsset>;
export type SubscribedAssets = SubscribedAsset[];
export declare const SubscribedAssets: any;
export interface CreateSubscriptionGrantOutput {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    createdAt: Date;
    updatedAt: Date;
    environmentId?: string;
    subscriptionTargetId: string;
    grantedEntity: GrantedEntity;
    status: SubscriptionGrantOverallStatus;
    assets?: SubscribedAsset[];
    subscriptionId?: string;
}
export declare const CreateSubscriptionGrantOutput: S.Schema<CreateSubscriptionGrantOutput>;
export interface SubscribedProjectInput {
    identifier?: string;
}
export declare const SubscribedProjectInput: S.Schema<SubscribedProjectInput>;
export interface SubscribedUserInput {
    identifier?: string;
}
export declare const SubscribedUserInput: S.Schema<SubscribedUserInput>;
export interface SubscribedGroupInput {
    identifier?: string;
}
export declare const SubscribedGroupInput: S.Schema<SubscribedGroupInput>;
export interface SubscribedIamPrincipalInput {
    identifier?: string;
}
export declare const SubscribedIamPrincipalInput: S.Schema<SubscribedIamPrincipalInput>;
export type SubscribedPrincipalInput = {
    project: SubscribedProjectInput;
    user?: never;
    group?: never;
    iam?: never;
} | {
    project?: never;
    user: SubscribedUserInput;
    group?: never;
    iam?: never;
} | {
    project?: never;
    user?: never;
    group: SubscribedGroupInput;
    iam?: never;
} | {
    project?: never;
    user?: never;
    group?: never;
    iam: SubscribedIamPrincipalInput;
};
export declare const SubscribedPrincipalInput: any;
export type SubscribedPrincipalInputs = SubscribedPrincipalInput[];
export declare const SubscribedPrincipalInputs: any;
export interface SubscribedListingInput {
    identifier: string;
}
export declare const SubscribedListingInput: S.Schema<SubscribedListingInput>;
export type SubscribedListingInputs = SubscribedListingInput[];
export declare const SubscribedListingInputs: any;
export type MetadataFormInputs = FormInput[];
export declare const MetadataFormInputs: any;
export interface CreateSubscriptionRequestInput {
    domainIdentifier: string;
    subscribedPrincipals: SubscribedPrincipalInput[];
    subscribedListings: SubscribedListingInput[];
    requestReason: string | redacted.Redacted<string>;
    clientToken?: string;
    metadataForms?: FormInput[];
    assetPermissions?: AssetPermission[];
    assetScopes?: AcceptedAssetScope[];
}
export declare const CreateSubscriptionRequestInput: S.Schema<CreateSubscriptionRequestInput>;
export interface CreateSubscriptionRequestOutput {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    status: SubscriptionRequestStatus;
    createdAt: Date;
    updatedAt: Date;
    requestReason: string | redacted.Redacted<string>;
    subscribedPrincipals: SubscribedPrincipal[];
    subscribedListings: SubscribedListing[];
    reviewerId?: string;
    decisionComment?: string | redacted.Redacted<string>;
    existingSubscriptionId?: string;
    metadataForms?: FormOutput[];
}
export declare const CreateSubscriptionRequestOutput: S.Schema<CreateSubscriptionRequestOutput>;
export type SubscriptionTargetName = string | redacted.Redacted<string>;
export interface SubscriptionTargetForm {
    formName: string;
    content: string;
}
export declare const SubscriptionTargetForm: S.Schema<SubscriptionTargetForm>;
export type SubscriptionTargetForms = SubscriptionTargetForm[];
export declare const SubscriptionTargetForms: any;
export type AuthorizedPrincipalIdentifier = string;
export type AuthorizedPrincipalIdentifiers = string[];
export declare const AuthorizedPrincipalIdentifiers: any;
export type IamRoleArn = string;
export type ApplicableAssetTypes = string[];
export declare const ApplicableAssetTypes: any;
export type SubscriptionGrantCreationMode = "AUTOMATIC" | "MANUAL" | (string & {});
export declare const SubscriptionGrantCreationMode: any;
export interface CreateSubscriptionTargetInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    name: string | redacted.Redacted<string>;
    type: string;
    subscriptionTargetConfig: SubscriptionTargetForm[];
    authorizedPrincipals: string[];
    manageAccessRole: string;
    applicableAssetTypes: string[];
    provider?: string;
    clientToken?: string;
    subscriptionGrantCreationMode?: SubscriptionGrantCreationMode;
}
export declare const CreateSubscriptionTargetInput: S.Schema<CreateSubscriptionTargetInput>;
export interface CreateSubscriptionTargetOutput {
    id: string;
    authorizedPrincipals: string[];
    domainId: string;
    projectId: string;
    environmentId: string;
    name: string | redacted.Redacted<string>;
    type: string;
    createdBy: string;
    updatedBy?: string;
    createdAt: Date;
    updatedAt?: Date;
    manageAccessRole?: string;
    applicableAssetTypes: string[];
    subscriptionTargetConfig: SubscriptionTargetForm[];
    provider: string;
    subscriptionGrantCreationMode?: SubscriptionGrantCreationMode;
}
export declare const CreateSubscriptionTargetOutput: S.Schema<CreateSubscriptionTargetOutput>;
export type UserType = "IAM_USER" | "IAM_ROLE" | "SSO_USER" | "IAM_ROLE_SESSION" | (string & {});
export declare const UserType: any;
export interface CreateUserProfileInput {
    domainIdentifier: string;
    userIdentifier: string;
    userType?: UserType;
    sessionName?: string;
    clientToken?: string;
}
export declare const CreateUserProfileInput: S.Schema<CreateUserProfileInput>;
export type UserProfileType = "IAM" | "SSO" | (string & {});
export declare const UserProfileType: any;
export type UserProfileStatus = "ASSIGNED" | "NOT_ASSIGNED" | "ACTIVATED" | "DEACTIVATED" | (string & {});
export declare const UserProfileStatus: any;
export interface CreateUserProfileOutput {
    domainId?: string;
    id?: string;
    type?: UserProfileType;
    status?: UserProfileStatus;
    details?: UserProfileDetails;
}
export declare const CreateUserProfileOutput: S.Schema<CreateUserProfileOutput>;
export interface DeleteAccountPoolInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteAccountPoolInput: S.Schema<DeleteAccountPoolInput>;
export interface DeleteAccountPoolOutput {
}
export declare const DeleteAccountPoolOutput: S.Schema<DeleteAccountPoolOutput>;
export interface DeleteAssetInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteAssetInput: S.Schema<DeleteAssetInput>;
export interface DeleteAssetOutput {
}
export declare const DeleteAssetOutput: S.Schema<DeleteAssetOutput>;
export interface DeleteAssetFilterInput {
    domainIdentifier: string;
    assetIdentifier: string;
    identifier: string;
}
export declare const DeleteAssetFilterInput: S.Schema<DeleteAssetFilterInput>;
export interface DeleteAssetFilterResponse {
}
export declare const DeleteAssetFilterResponse: S.Schema<DeleteAssetFilterResponse>;
export interface DeleteAssetTypeInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteAssetTypeInput: S.Schema<DeleteAssetTypeInput>;
export interface DeleteAssetTypeOutput {
}
export declare const DeleteAssetTypeOutput: S.Schema<DeleteAssetTypeOutput>;
export interface DeleteConnectionInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteConnectionInput: S.Schema<DeleteConnectionInput>;
export interface DeleteConnectionOutput {
    status?: string;
}
export declare const DeleteConnectionOutput: S.Schema<DeleteConnectionOutput>;
export interface DeleteDataExportConfigurationInput {
    domainIdentifier: string;
}
export declare const DeleteDataExportConfigurationInput: S.Schema<DeleteDataExportConfigurationInput>;
export interface DeleteDataExportConfigurationOutput {
}
export declare const DeleteDataExportConfigurationOutput: S.Schema<DeleteDataExportConfigurationOutput>;
export interface DeleteDataProductInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteDataProductInput: S.Schema<DeleteDataProductInput>;
export interface DeleteDataProductOutput {
}
export declare const DeleteDataProductOutput: S.Schema<DeleteDataProductOutput>;
export interface DeleteDataSourceInput {
    domainIdentifier: string;
    identifier: string;
    clientToken?: string;
    retainPermissionsOnRevokeFailure?: boolean;
}
export declare const DeleteDataSourceInput: S.Schema<DeleteDataSourceInput>;
export type SelfGrantStatus = "GRANT_PENDING" | "REVOKE_PENDING" | "GRANT_IN_PROGRESS" | "REVOKE_IN_PROGRESS" | "GRANTED" | "GRANT_FAILED" | "REVOKE_FAILED" | (string & {});
export declare const SelfGrantStatus: any;
export interface SelfGrantStatusDetail {
    databaseName: string;
    schemaName?: string;
    status: SelfGrantStatus;
    failureCause?: string;
}
export declare const SelfGrantStatusDetail: S.Schema<SelfGrantStatusDetail>;
export type SelfGrantStatusDetails = SelfGrantStatusDetail[];
export declare const SelfGrantStatusDetails: any;
export interface GlueSelfGrantStatusOutput {
    selfGrantStatusDetails: SelfGrantStatusDetail[];
}
export declare const GlueSelfGrantStatusOutput: S.Schema<GlueSelfGrantStatusOutput>;
export interface RedshiftSelfGrantStatusOutput {
    selfGrantStatusDetails: SelfGrantStatusDetail[];
}
export declare const RedshiftSelfGrantStatusOutput: S.Schema<RedshiftSelfGrantStatusOutput>;
export type SelfGrantStatusOutput = {
    glueSelfGrantStatus: GlueSelfGrantStatusOutput;
    redshiftSelfGrantStatus?: never;
} | {
    glueSelfGrantStatus?: never;
    redshiftSelfGrantStatus: RedshiftSelfGrantStatusOutput;
};
export declare const SelfGrantStatusOutput: any;
export interface DeleteDataSourceOutput {
    id: string;
    status?: DataSourceStatus;
    type?: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    domainId: string;
    projectId: string;
    environmentId?: string;
    connectionId?: string;
    configuration?: DataSourceConfigurationOutput;
    enableSetting?: EnableSetting;
    publishOnImport?: boolean;
    assetFormsOutput?: FormOutput[];
    schedule?: ScheduleConfiguration;
    lastRunStatus?: DataSourceRunStatus;
    lastRunAt?: Date;
    lastRunErrorMessage?: DataSourceErrorMessage;
    errorMessage?: DataSourceErrorMessage;
    createdAt?: Date;
    updatedAt?: Date;
    selfGrantStatus?: SelfGrantStatusOutput;
    retainPermissionsOnRevokeFailure?: boolean;
}
export declare const DeleteDataSourceOutput: S.Schema<DeleteDataSourceOutput>;
export interface DeleteDomainInput {
    identifier: string;
    clientToken?: string;
    skipDeletionCheck?: boolean;
    cascadeDelete?: boolean;
}
export declare const DeleteDomainInput: S.Schema<DeleteDomainInput>;
export interface DeleteDomainOutput {
    status: DomainStatus;
}
export declare const DeleteDomainOutput: S.Schema<DeleteDomainOutput>;
export interface DeleteDomainUnitInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteDomainUnitInput: S.Schema<DeleteDomainUnitInput>;
export interface DeleteDomainUnitOutput {
}
export declare const DeleteDomainUnitOutput: S.Schema<DeleteDomainUnitOutput>;
export interface DeleteEnvironmentInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteEnvironmentInput: S.Schema<DeleteEnvironmentInput>;
export interface DeleteEnvironmentResponse {
}
export declare const DeleteEnvironmentResponse: S.Schema<DeleteEnvironmentResponse>;
export interface DeleteEnvironmentActionInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    identifier: string;
}
export declare const DeleteEnvironmentActionInput: S.Schema<DeleteEnvironmentActionInput>;
export interface DeleteEnvironmentActionResponse {
}
export declare const DeleteEnvironmentActionResponse: S.Schema<DeleteEnvironmentActionResponse>;
export interface DeleteEnvironmentBlueprintInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteEnvironmentBlueprintInput: S.Schema<DeleteEnvironmentBlueprintInput>;
export interface DeleteEnvironmentBlueprintResponse {
}
export declare const DeleteEnvironmentBlueprintResponse: S.Schema<DeleteEnvironmentBlueprintResponse>;
export interface DeleteEnvironmentBlueprintConfigurationInput {
    domainIdentifier: string;
    environmentBlueprintIdentifier: string;
}
export declare const DeleteEnvironmentBlueprintConfigurationInput: S.Schema<DeleteEnvironmentBlueprintConfigurationInput>;
export interface DeleteEnvironmentBlueprintConfigurationOutput {
}
export declare const DeleteEnvironmentBlueprintConfigurationOutput: S.Schema<DeleteEnvironmentBlueprintConfigurationOutput>;
export interface DeleteEnvironmentProfileInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteEnvironmentProfileInput: S.Schema<DeleteEnvironmentProfileInput>;
export interface DeleteEnvironmentProfileResponse {
}
export declare const DeleteEnvironmentProfileResponse: S.Schema<DeleteEnvironmentProfileResponse>;
export interface DeleteFormTypeInput {
    domainIdentifier: string;
    formTypeIdentifier: string;
}
export declare const DeleteFormTypeInput: S.Schema<DeleteFormTypeInput>;
export interface DeleteFormTypeOutput {
}
export declare const DeleteFormTypeOutput: S.Schema<DeleteFormTypeOutput>;
export interface DeleteGlossaryInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteGlossaryInput: S.Schema<DeleteGlossaryInput>;
export interface DeleteGlossaryOutput {
}
export declare const DeleteGlossaryOutput: S.Schema<DeleteGlossaryOutput>;
export interface DeleteGlossaryTermInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteGlossaryTermInput: S.Schema<DeleteGlossaryTermInput>;
export interface DeleteGlossaryTermOutput {
}
export declare const DeleteGlossaryTermOutput: S.Schema<DeleteGlossaryTermOutput>;
export type LineageEventIdentifier = string;
export interface DeleteLineageEventInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteLineageEventInput: S.Schema<DeleteLineageEventInput>;
export type LineageEventProcessingStatus = "REQUESTED" | "PROCESSING" | "SUCCESS" | "FAILED" | (string & {});
export declare const LineageEventProcessingStatus: any;
export interface DeleteLineageEventOutput {
    id?: string;
    domainId?: string;
    processingStatus?: LineageEventProcessingStatus;
}
export declare const DeleteLineageEventOutput: S.Schema<DeleteLineageEventOutput>;
export interface DeleteListingInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteListingInput: S.Schema<DeleteListingInput>;
export interface DeleteListingOutput {
}
export declare const DeleteListingOutput: S.Schema<DeleteListingOutput>;
export interface DeleteNotebookInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteNotebookInput: S.Schema<DeleteNotebookInput>;
export interface DeleteNotebookOutput {
}
export declare const DeleteNotebookOutput: S.Schema<DeleteNotebookOutput>;
export interface DeleteProjectInput {
    domainIdentifier: string;
    identifier: string;
    skipDeletionCheck?: boolean;
}
export declare const DeleteProjectInput: S.Schema<DeleteProjectInput>;
export interface DeleteProjectOutput {
}
export declare const DeleteProjectOutput: S.Schema<DeleteProjectOutput>;
export interface DeleteProjectMembershipInput {
    domainIdentifier: string;
    projectIdentifier: string;
    member: Member;
}
export declare const DeleteProjectMembershipInput: S.Schema<DeleteProjectMembershipInput>;
export interface DeleteProjectMembershipOutput {
}
export declare const DeleteProjectMembershipOutput: S.Schema<DeleteProjectMembershipOutput>;
export interface DeleteProjectProfileInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteProjectProfileInput: S.Schema<DeleteProjectProfileInput>;
export interface DeleteProjectProfileOutput {
}
export declare const DeleteProjectProfileOutput: S.Schema<DeleteProjectProfileOutput>;
export interface DeleteRuleInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteRuleInput: S.Schema<DeleteRuleInput>;
export interface DeleteRuleOutput {
}
export declare const DeleteRuleOutput: S.Schema<DeleteRuleOutput>;
export interface DeleteSubscriptionGrantInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteSubscriptionGrantInput: S.Schema<DeleteSubscriptionGrantInput>;
export interface DeleteSubscriptionGrantOutput {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    createdAt: Date;
    updatedAt: Date;
    environmentId?: string;
    subscriptionTargetId: string;
    grantedEntity: GrantedEntity;
    status: SubscriptionGrantOverallStatus;
    assets?: SubscribedAsset[];
    subscriptionId?: string;
}
export declare const DeleteSubscriptionGrantOutput: S.Schema<DeleteSubscriptionGrantOutput>;
export interface DeleteSubscriptionRequestInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const DeleteSubscriptionRequestInput: S.Schema<DeleteSubscriptionRequestInput>;
export interface DeleteSubscriptionRequestResponse {
}
export declare const DeleteSubscriptionRequestResponse: S.Schema<DeleteSubscriptionRequestResponse>;
export interface DeleteSubscriptionTargetInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    identifier: string;
}
export declare const DeleteSubscriptionTargetInput: S.Schema<DeleteSubscriptionTargetInput>;
export interface DeleteSubscriptionTargetResponse {
}
export declare const DeleteSubscriptionTargetResponse: S.Schema<DeleteSubscriptionTargetResponse>;
export type TimeSeriesEntityType = "ASSET" | "LISTING" | (string & {});
export declare const TimeSeriesEntityType: any;
export interface DeleteTimeSeriesDataPointsInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: TimeSeriesEntityType;
    formName: string;
    clientToken?: string;
}
export declare const DeleteTimeSeriesDataPointsInput: S.Schema<DeleteTimeSeriesDataPointsInput>;
export interface DeleteTimeSeriesDataPointsOutput {
}
export declare const DeleteTimeSeriesDataPointsOutput: S.Schema<DeleteTimeSeriesDataPointsOutput>;
export interface DisassociateEnvironmentRoleInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    environmentRoleArn: string;
}
export declare const DisassociateEnvironmentRoleInput: S.Schema<DisassociateEnvironmentRoleInput>;
export interface DisassociateEnvironmentRoleOutput {
}
export declare const DisassociateEnvironmentRoleOutput: S.Schema<DisassociateEnvironmentRoleOutput>;
export interface DisassociateGovernedTermsInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: GovernedEntityType;
    governedGlossaryTerms: string[];
}
export declare const DisassociateGovernedTermsInput: S.Schema<DisassociateGovernedTermsInput>;
export interface DisassociateGovernedTermsOutput {
}
export declare const DisassociateGovernedTermsOutput: S.Schema<DisassociateGovernedTermsOutput>;
export interface GetAccountPoolInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetAccountPoolInput: S.Schema<GetAccountPoolInput>;
export interface GetAccountPoolOutput {
    domainId?: string;
    name?: string | redacted.Redacted<string>;
    id?: string;
    description?: string | redacted.Redacted<string>;
    resolutionStrategy?: ResolutionStrategy;
    accountSource: AccountSource;
    createdBy: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    updatedBy?: string;
    domainUnitId?: string;
}
export declare const GetAccountPoolOutput: S.Schema<GetAccountPoolOutput>;
export interface GetAssetInput {
    domainIdentifier: string;
    identifier: string;
    revision?: string;
}
export declare const GetAssetInput: S.Schema<GetAssetInput>;
export interface GetAssetOutput {
    id: string;
    name: string | redacted.Redacted<string>;
    typeIdentifier: string;
    typeRevision: string;
    externalIdentifier?: string;
    revision: string;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    createdBy?: string;
    firstRevisionCreatedAt?: Date;
    firstRevisionCreatedBy?: string;
    glossaryTerms?: string[];
    governedGlossaryTerms?: string[];
    owningProjectId: string;
    domainId: string;
    listing?: AssetListingDetails;
    formsOutput: FormOutput[];
    readOnlyFormsOutput?: FormOutput[];
    latestTimeSeriesDataPointFormsOutput?: TimeSeriesDataPointSummaryFormOutput[];
}
export declare const GetAssetOutput: S.Schema<GetAssetOutput>;
export interface GetAssetFilterInput {
    domainIdentifier: string;
    assetIdentifier: string;
    identifier: string;
}
export declare const GetAssetFilterInput: S.Schema<GetAssetFilterInput>;
export interface GetAssetFilterOutput {
    id: string;
    domainId: string;
    assetId: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    status?: FilterStatus;
    configuration: AssetFilterConfiguration;
    createdAt?: Date;
    errorMessage?: string;
    effectiveColumnNames?: string[];
    effectiveRowFilter?: string;
}
export declare const GetAssetFilterOutput: S.Schema<GetAssetFilterOutput>;
export interface GetAssetTypeInput {
    domainIdentifier: string;
    identifier: string;
    revision?: string;
}
export declare const GetAssetTypeInput: S.Schema<GetAssetTypeInput>;
export interface GetAssetTypeOutput {
    domainId: string;
    name: string;
    revision: string;
    description?: string | redacted.Redacted<string>;
    formsOutput: {
        [key: string]: FormEntryOutput | undefined;
    };
    owningProjectId: string;
    originDomainId?: string;
    originProjectId?: string;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
}
export declare const GetAssetTypeOutput: S.Schema<GetAssetTypeOutput>;
export interface GetConnectionInput {
    domainIdentifier: string;
    identifier: string;
    withSecret?: boolean;
}
export declare const GetConnectionInput: S.Schema<GetConnectionInput>;
export interface ConnectionCredentials {
    accessKeyId?: string;
    secretAccessKey?: string | redacted.Redacted<string>;
    sessionToken?: string | redacted.Redacted<string>;
    expiration?: Date;
}
export declare const ConnectionCredentials: S.Schema<ConnectionCredentials>;
export interface GetConnectionOutput {
    connectionCredentials?: ConnectionCredentials;
    configurations?: Configuration[];
    connectionId: string;
    description?: string | redacted.Redacted<string>;
    domainId: string;
    domainUnitId: string;
    environmentId?: string;
    environmentUserRole?: string;
    name: string;
    physicalEndpoints: PhysicalEndpoint[];
    projectId?: string;
    props?: ConnectionPropertiesOutput;
    type: ConnectionType;
    scope?: ConnectionScope;
}
export declare const GetConnectionOutput: S.Schema<GetConnectionOutput>;
export interface GetDataExportConfigurationInput {
    domainIdentifier: string;
}
export declare const GetDataExportConfigurationInput: S.Schema<GetDataExportConfigurationInput>;
export type ConfigurationStatus = "COMPLETED" | "FAILED" | (string & {});
export declare const ConfigurationStatus: any;
export interface EncryptionConfiguration {
    kmsKeyArn?: string;
    sseAlgorithm?: string;
}
export declare const EncryptionConfiguration: S.Schema<EncryptionConfiguration>;
export interface GetDataExportConfigurationOutput {
    isExportEnabled?: boolean;
    status?: ConfigurationStatus;
    encryptionConfiguration?: EncryptionConfiguration;
    s3TableBucketArn?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const GetDataExportConfigurationOutput: S.Schema<GetDataExportConfigurationOutput>;
export interface GetDataProductInput {
    domainIdentifier: string;
    identifier: string;
    revision?: string;
}
export declare const GetDataProductInput: S.Schema<GetDataProductInput>;
export interface GetDataProductOutput {
    domainId: string;
    id: string;
    revision: string;
    owningProjectId: string;
    name: string | redacted.Redacted<string>;
    status: DataProductStatus;
    description?: string | redacted.Redacted<string>;
    glossaryTerms?: string[];
    items?: DataProductItem[];
    formsOutput?: FormOutput[];
    createdAt?: Date;
    createdBy?: string;
    firstRevisionCreatedAt?: Date;
    firstRevisionCreatedBy?: string;
}
export declare const GetDataProductOutput: S.Schema<GetDataProductOutput>;
export interface GetDataSourceInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetDataSourceInput: S.Schema<GetDataSourceInput>;
export interface GetDataSourceOutput {
    id: string;
    status?: DataSourceStatus;
    type?: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    domainId: string;
    projectId: string;
    environmentId?: string;
    connectionId?: string;
    configuration?: DataSourceConfigurationOutput;
    recommendation?: RecommendationConfiguration;
    enableSetting?: EnableSetting;
    publishOnImport?: boolean;
    assetFormsOutput?: FormOutput[];
    schedule?: ScheduleConfiguration;
    lastRunStatus?: DataSourceRunStatus;
    lastRunAt?: Date;
    lastRunErrorMessage?: DataSourceErrorMessage;
    lastRunAssetCount?: number;
    errorMessage?: DataSourceErrorMessage;
    createdAt?: Date;
    updatedAt?: Date;
    selfGrantStatus?: SelfGrantStatusOutput;
}
export declare const GetDataSourceOutput: S.Schema<GetDataSourceOutput>;
export type DataSourceRunId = string;
export interface GetDataSourceRunInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetDataSourceRunInput: S.Schema<GetDataSourceRunInput>;
export type DataSourceRunType = "PRIORITIZED" | "SCHEDULED" | (string & {});
export declare const DataSourceRunType: any;
export interface RunStatisticsForAssets {
    added?: number;
    updated?: number;
    unchanged?: number;
    skipped?: number;
    failed?: number;
}
export declare const RunStatisticsForAssets: S.Schema<RunStatisticsForAssets>;
export type LineageImportStatus = "IN_PROGRESS" | "SUCCESS" | "FAILED" | "PARTIALLY_SUCCEEDED" | (string & {});
export declare const LineageImportStatus: any;
export interface DataSourceRunLineageSummary {
    importStatus?: LineageImportStatus;
}
export declare const DataSourceRunLineageSummary: S.Schema<DataSourceRunLineageSummary>;
export interface GetDataSourceRunOutput {
    domainId: string;
    dataSourceId: string;
    id: string;
    projectId: string;
    status: DataSourceRunStatus;
    type: DataSourceRunType;
    dataSourceConfigurationSnapshot?: string;
    runStatisticsForAssets?: RunStatisticsForAssets;
    lineageSummary?: DataSourceRunLineageSummary;
    errorMessage?: DataSourceErrorMessage;
    createdAt: Date;
    updatedAt: Date;
    startedAt?: Date;
    stoppedAt?: Date;
}
export declare const GetDataSourceRunOutput: S.Schema<GetDataSourceRunOutput>;
export interface GetDomainInput {
    identifier: string;
}
export declare const GetDomainInput: S.Schema<GetDomainInput>;
export interface FailureReason {
    id?: string;
    message?: string;
}
export declare const FailureReason: S.Schema<FailureReason>;
export type FailureReasonsList = FailureReason[];
export declare const FailureReasonsList: any;
export interface DeleteProgress {
    successfullyDeletedProjectCount?: number;
}
export declare const DeleteProgress: S.Schema<DeleteProgress>;
export interface GetDomainOutput {
    id: string;
    rootDomainUnitId?: string;
    name?: string;
    description?: string;
    singleSignOn?: SingleSignOn;
    domainExecutionRole: string;
    arn?: string;
    kmsKeyIdentifier?: string;
    status: DomainStatus;
    portalUrl?: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    domainVersion?: DomainVersion;
    serviceRole?: string;
    failureReasons?: FailureReason[];
    deleteProgress?: DeleteProgress;
}
export declare const GetDomainOutput: S.Schema<GetDomainOutput>;
export interface GetDomainUnitInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetDomainUnitInput: S.Schema<GetDomainUnitInput>;
export interface GetDomainUnitOutput {
    id: string;
    domainId: string;
    name: string | redacted.Redacted<string>;
    parentDomainUnitId?: string;
    description?: string | redacted.Redacted<string>;
    owners: DomainUnitOwnerProperties[];
    createdAt?: Date;
    lastUpdatedAt?: Date;
    createdBy?: string;
    lastUpdatedBy?: string;
}
export declare const GetDomainUnitOutput: S.Schema<GetDomainUnitOutput>;
export interface GetEnvironmentInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetEnvironmentInput: S.Schema<GetEnvironmentInput>;
export interface GetEnvironmentOutput {
    projectId: string;
    id?: string;
    domainId: string;
    createdBy: string;
    createdAt?: Date;
    updatedAt?: Date;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    environmentProfileId?: string;
    awsAccountId?: string;
    awsAccountRegion?: string;
    provider: string;
    provisionedResources?: Resource[];
    status?: EnvironmentStatus;
    environmentActions?: ConfigurableEnvironmentAction[];
    glossaryTerms?: string[];
    userParameters?: CustomParameter[];
    lastDeployment?: Deployment;
    provisioningProperties?: ProvisioningProperties;
    deploymentProperties?: DeploymentProperties;
    environmentBlueprintId?: string;
    environmentConfigurationId?: string | redacted.Redacted<string>;
    environmentConfigurationName?: string | redacted.Redacted<string>;
}
export declare const GetEnvironmentOutput: S.Schema<GetEnvironmentOutput>;
export interface GetEnvironmentActionInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    identifier: string;
}
export declare const GetEnvironmentActionInput: S.Schema<GetEnvironmentActionInput>;
export interface GetEnvironmentActionOutput {
    domainId: string;
    environmentId: string;
    id: string;
    name: string;
    parameters: ActionParameters;
    description?: string;
}
export declare const GetEnvironmentActionOutput: S.Schema<GetEnvironmentActionOutput>;
export interface GetEnvironmentBlueprintInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetEnvironmentBlueprintInput: S.Schema<GetEnvironmentBlueprintInput>;
export interface GetEnvironmentBlueprintOutput {
    id: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    provider: string;
    provisioningProperties: ProvisioningProperties;
    deploymentProperties?: DeploymentProperties;
    userParameters?: CustomParameter[];
    glossaryTerms?: string[];
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const GetEnvironmentBlueprintOutput: S.Schema<GetEnvironmentBlueprintOutput>;
export interface GetEnvironmentBlueprintConfigurationInput {
    domainIdentifier: string;
    environmentBlueprintIdentifier: string;
}
export declare const GetEnvironmentBlueprintConfigurationInput: S.Schema<GetEnvironmentBlueprintConfigurationInput>;
export type PolicyArn = string;
export type EnabledRegionList = string[];
export declare const EnabledRegionList: any;
export type RegionalParameter = {
    [key: string]: string | undefined;
};
export declare const RegionalParameter: any;
export type RegionalParameterMap = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export declare const RegionalParameterMap: any;
export type ResourceConfigurationParameterMap = {
    [key: string]: string | undefined;
};
export declare const ResourceConfigurationParameterMap: any;
export interface ResourceConfiguration {
    identifier: string;
    name: string;
    description?: string;
    region: string;
    parameters: {
        [key: string]: string | undefined;
    };
}
export declare const ResourceConfiguration: S.Schema<ResourceConfiguration>;
export type ResourceConfigurations = ResourceConfiguration[];
export declare const ResourceConfigurations: any;
export type S3Location = string;
export type S3LocationList = string[];
export declare const S3LocationList: any;
export interface LakeFormationConfiguration {
    locationRegistrationRole?: string;
    locationRegistrationExcludeS3Locations?: string[];
}
export declare const LakeFormationConfiguration: S.Schema<LakeFormationConfiguration>;
export type ProvisioningConfiguration = {
    lakeFormationConfiguration: LakeFormationConfiguration;
};
export declare const ProvisioningConfiguration: any;
export type ProvisioningConfigurationList = ProvisioningConfiguration[];
export declare const ProvisioningConfigurationList: any;
export interface GetEnvironmentBlueprintConfigurationOutput {
    domainId: string;
    environmentBlueprintId: string;
    provisioningRoleArn?: string;
    environmentRolePermissionBoundary?: string;
    manageAccessRoleArn?: string;
    enabledRegions?: string[];
    regionalParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    allowUserProvidedConfigurations?: boolean;
    createdAt?: Date;
    updatedAt?: Date;
    resourceConfigurations?: ResourceConfiguration[];
    provisioningConfigurations?: ProvisioningConfiguration[];
}
export declare const GetEnvironmentBlueprintConfigurationOutput: S.Schema<GetEnvironmentBlueprintConfigurationOutput>;
export interface GetEnvironmentCredentialsInput {
    domainIdentifier: string;
    environmentIdentifier: string;
}
export declare const GetEnvironmentCredentialsInput: S.Schema<GetEnvironmentCredentialsInput>;
export interface GetEnvironmentCredentialsOutput {
    accessKeyId?: string;
    secretAccessKey?: string | redacted.Redacted<string>;
    sessionToken?: string | redacted.Redacted<string>;
    expiration?: Date;
}
export declare const GetEnvironmentCredentialsOutput: S.Schema<GetEnvironmentCredentialsOutput>;
export interface GetEnvironmentProfileInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetEnvironmentProfileInput: S.Schema<GetEnvironmentProfileInput>;
export interface GetEnvironmentProfileOutput {
    id: string;
    domainId: string;
    awsAccountId?: string;
    awsAccountRegion?: string;
    createdBy: string;
    createdAt?: Date;
    updatedAt?: Date;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    environmentBlueprintId: string;
    projectId?: string;
    userParameters?: CustomParameter[];
}
export declare const GetEnvironmentProfileOutput: S.Schema<GetEnvironmentProfileOutput>;
export interface GetFormTypeInput {
    domainIdentifier: string;
    formTypeIdentifier: string;
    revision?: string;
}
export declare const GetFormTypeInput: S.Schema<GetFormTypeInput>;
export interface Import {
    name: string | redacted.Redacted<string>;
    revision: string;
}
export declare const Import: S.Schema<Import>;
export type ImportList = Import[];
export declare const ImportList: any;
export interface GetFormTypeOutput {
    domainId: string;
    name: string | redacted.Redacted<string>;
    revision: string;
    model: Model;
    owningProjectId?: string;
    originDomainId?: string;
    originProjectId?: string;
    status?: FormTypeStatus;
    createdAt?: Date;
    createdBy?: string;
    description?: string | redacted.Redacted<string>;
    imports?: Import[];
}
export declare const GetFormTypeOutput: S.Schema<GetFormTypeOutput>;
export interface GetGlossaryInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetGlossaryInput: S.Schema<GetGlossaryInput>;
export interface GetGlossaryOutput {
    domainId: string;
    id: string;
    owningProjectId: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    status: GlossaryStatus;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    usageRestrictions?: GlossaryUsageRestriction[];
}
export declare const GetGlossaryOutput: S.Schema<GetGlossaryOutput>;
export interface GetGlossaryTermInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetGlossaryTermInput: S.Schema<GetGlossaryTermInput>;
export interface GetGlossaryTermOutput {
    domainId: string;
    glossaryId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    shortDescription?: string | redacted.Redacted<string>;
    longDescription?: string | redacted.Redacted<string>;
    termRelations?: TermRelations;
    status: GlossaryTermStatus;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    usageRestrictions?: GlossaryUsageRestriction[];
}
export declare const GetGlossaryTermOutput: S.Schema<GetGlossaryTermOutput>;
export interface GetGroupProfileInput {
    domainIdentifier: string;
    groupIdentifier: string;
}
export declare const GetGroupProfileInput: S.Schema<GetGroupProfileInput>;
export interface GetGroupProfileOutput {
    domainId?: string;
    id?: string;
    status?: GroupProfileStatus;
    groupName?: string | redacted.Redacted<string>;
    rolePrincipalArn?: string;
    rolePrincipalId?: string;
}
export declare const GetGroupProfileOutput: S.Schema<GetGroupProfileOutput>;
export interface GetIamPortalLoginUrlInput {
    domainIdentifier: string;
}
export declare const GetIamPortalLoginUrlInput: S.Schema<GetIamPortalLoginUrlInput>;
export interface GetIamPortalLoginUrlOutput {
    authCodeUrl?: string;
    userProfileId: string;
}
export declare const GetIamPortalLoginUrlOutput: S.Schema<GetIamPortalLoginUrlOutput>;
export type RunIdentifier = string;
export interface GetJobRunInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetJobRunInput: S.Schema<GetJobRunInput>;
export type JobType = "LINEAGE" | (string & {});
export declare const JobType: any;
export type JobRunMode = "SCHEDULED" | "ON_DEMAND" | (string & {});
export declare const JobRunMode: any;
export type FailedQueryProcessingErrorMessages = string[];
export declare const FailedQueryProcessingErrorMessages: any;
export interface LineageSqlQueryRunDetails {
    queryStartTime?: Date;
    queryEndTime?: Date;
    totalQueriesProcessed?: number;
    numQueriesFailed?: number;
    errorMessages?: string[];
}
export declare const LineageSqlQueryRunDetails: S.Schema<LineageSqlQueryRunDetails>;
export interface LineageRunDetails {
    sqlQueryRunDetails?: LineageSqlQueryRunDetails;
}
export declare const LineageRunDetails: S.Schema<LineageRunDetails>;
export type JobRunDetails = {
    lineageRunDetails: LineageRunDetails;
};
export declare const JobRunDetails: any;
export type JobRunStatus = "SCHEDULED" | "IN_PROGRESS" | "SUCCESS" | "PARTIALLY_SUCCEEDED" | "FAILED" | "ABORTED" | "TIMED_OUT" | "CANCELED" | (string & {});
export declare const JobRunStatus: any;
export interface JobRunError {
    message: string;
}
export declare const JobRunError: S.Schema<JobRunError>;
export interface GetJobRunOutput {
    domainId?: string;
    id?: string;
    jobId?: string;
    jobType?: JobType;
    runMode?: JobRunMode;
    details?: JobRunDetails;
    status?: JobRunStatus;
    error?: JobRunError;
    createdBy?: string;
    createdAt?: Date;
    startTime?: Date;
    endTime?: Date;
}
export declare const GetJobRunOutput: S.Schema<GetJobRunOutput>;
export interface GetLineageEventInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetLineageEventInput: S.Schema<GetLineageEventInput>;
export interface GetLineageEventOutput {
    domainId?: string;
    id?: string;
    event?: T.StreamingOutputBody;
    createdBy?: string;
    processingStatus?: LineageEventProcessingStatus;
    eventTime?: Date;
    createdAt?: Date;
}
export declare const GetLineageEventOutput: S.Schema<GetLineageEventOutput>;
export type LineageNodeIdentifier = string;
export interface GetLineageNodeInput {
    domainIdentifier: string;
    identifier: string;
    eventTimestamp?: Date;
}
export declare const GetLineageNodeInput: S.Schema<GetLineageNodeInput>;
export type LineageNodeId = string;
export interface LineageNodeReference {
    id?: string;
    eventTimestamp?: Date;
}
export declare const LineageNodeReference: S.Schema<LineageNodeReference>;
export type LineageNodeReferenceList = LineageNodeReference[];
export declare const LineageNodeReferenceList: any;
export interface GetLineageNodeOutput {
    domainId: string;
    name?: string;
    description?: string;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    id: string;
    typeName: string;
    typeRevision?: string;
    sourceIdentifier?: string;
    eventTimestamp?: Date;
    formsOutput?: FormOutput[];
    upstreamNodes?: LineageNodeReference[];
    downstreamNodes?: LineageNodeReference[];
}
export declare const GetLineageNodeOutput: S.Schema<GetLineageNodeOutput>;
export interface GetListingInput {
    domainIdentifier: string;
    identifier: string;
    listingRevision?: string;
}
export declare const GetListingInput: S.Schema<GetListingInput>;
export interface AssetListing {
    assetId?: string;
    assetRevision?: string;
    assetType?: string;
    createdAt?: Date;
    forms?: string;
    latestTimeSeriesDataPointForms?: TimeSeriesDataPointSummaryFormOutput[];
    glossaryTerms?: DetailedGlossaryTerm[];
    governedGlossaryTerms?: DetailedGlossaryTerm[];
    owningProjectId?: string;
}
export declare const AssetListing: S.Schema<AssetListing>;
export interface ListingSummary {
    listingId?: string;
    listingRevision?: string;
    glossaryTerms?: DetailedGlossaryTerm[];
}
export declare const ListingSummary: S.Schema<ListingSummary>;
export type ListingSummaries = ListingSummary[];
export declare const ListingSummaries: any;
export interface DataProductListing {
    dataProductId?: string;
    dataProductRevision?: string;
    createdAt?: Date;
    forms?: string;
    glossaryTerms?: DetailedGlossaryTerm[];
    owningProjectId?: string;
    items?: ListingSummary[];
}
export declare const DataProductListing: S.Schema<DataProductListing>;
export type ListingItem = {
    assetListing: AssetListing;
    dataProductListing?: never;
} | {
    assetListing?: never;
    dataProductListing: DataProductListing;
};
export declare const ListingItem: any;
export interface GetListingOutput {
    domainId: string;
    id: string;
    listingRevision: string;
    createdAt?: Date;
    updatedAt?: Date;
    createdBy?: string;
    updatedBy?: string;
    item?: ListingItem;
    name?: string;
    description?: string | redacted.Redacted<string>;
    status?: ListingStatus;
}
export declare const GetListingOutput: S.Schema<GetListingOutput>;
export type MetadataGenerationRunType = "BUSINESS_DESCRIPTIONS" | "BUSINESS_NAMES" | "BUSINESS_GLOSSARY_ASSOCIATIONS" | (string & {});
export declare const MetadataGenerationRunType: any;
export interface GetMetadataGenerationRunInput {
    domainIdentifier: string;
    identifier: string;
    type?: MetadataGenerationRunType;
}
export declare const GetMetadataGenerationRunInput: S.Schema<GetMetadataGenerationRunInput>;
export type MetadataGenerationTargetType = "ASSET" | (string & {});
export declare const MetadataGenerationTargetType: any;
export interface MetadataGenerationRunTarget {
    type: MetadataGenerationTargetType;
    identifier: string;
    revision?: string;
}
export declare const MetadataGenerationRunTarget: S.Schema<MetadataGenerationRunTarget>;
export type MetadataGenerationRunStatus = "SUBMITTED" | "IN_PROGRESS" | "CANCELED" | "SUCCEEDED" | "FAILED" | "PARTIALLY_SUCCEEDED" | (string & {});
export declare const MetadataGenerationRunStatus: any;
export type MetadataGenerationRunTypes = MetadataGenerationRunType[];
export declare const MetadataGenerationRunTypes: any;
export interface MetadataGenerationRunTypeStat {
    type: MetadataGenerationRunType;
    status: MetadataGenerationRunStatus;
    errorMessage?: string;
}
export declare const MetadataGenerationRunTypeStat: S.Schema<MetadataGenerationRunTypeStat>;
export type MetadataGenerationRunTypeStats = MetadataGenerationRunTypeStat[];
export declare const MetadataGenerationRunTypeStats: any;
export interface GetMetadataGenerationRunOutput {
    domainId: string;
    id: string;
    target?: MetadataGenerationRunTarget;
    status?: MetadataGenerationRunStatus;
    type?: MetadataGenerationRunType;
    types?: MetadataGenerationRunType[];
    createdAt?: Date;
    createdBy?: string;
    owningProjectId: string;
    typeStats?: MetadataGenerationRunTypeStat[];
}
export declare const GetMetadataGenerationRunOutput: S.Schema<GetMetadataGenerationRunOutput>;
export interface GetNotebookInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetNotebookInput: S.Schema<GetNotebookInput>;
export interface GetNotebookOutput {
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    domainId: string;
    cellOrder: CellInformation[];
    status: NotebookStatus;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    lockedBy?: string;
    lockedAt?: Date;
    lockExpiresAt?: Date;
    computeId?: string;
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    parameters?: {
        [key: string]: string | undefined;
    };
    environmentConfiguration?: EnvironmentConfig;
    error?: NotebookError;
    gitMetadata?: GitMetadata;
}
export declare const GetNotebookOutput: S.Schema<GetNotebookOutput>;
export type ExportId = string;
export interface GetNotebookExportInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetNotebookExportInput: S.Schema<GetNotebookExportInput>;
export type FileFormat = "PDF" | "IPYNB" | (string & {});
export declare const FileFormat: any;
export type NotebookExportStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const NotebookExportStatus: any;
export type NotebookS3Uri = string | redacted.Redacted<string>;
export interface S3Destination {
    uri?: string | redacted.Redacted<string>;
}
export declare const S3Destination: S.Schema<S3Destination>;
export type OutputLocation = {
    s3: S3Destination;
};
export declare const OutputLocation: any;
export interface NotebookExportError {
    message: string;
}
export declare const NotebookExportError: S.Schema<NotebookExportError>;
export type CompletedAt = Date;
export interface GetNotebookExportOutput {
    id: string;
    domainId: string;
    owningProjectId: string;
    notebookId: string;
    fileFormat: FileFormat;
    status: NotebookExportStatus;
    outputLocation?: OutputLocation;
    error?: NotebookExportError;
    completedAt?: Date;
    createdAt?: Date;
    createdBy?: string;
}
export declare const GetNotebookExportOutput: S.Schema<GetNotebookExportOutput>;
export type NotebookRunId = string;
export interface GetNotebookRunInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetNotebookRunInput: S.Schema<GetNotebookRunInput>;
export type ScheduleId = string;
export type NotebookRunStatus = "QUEUED" | "STARTING" | "RUNNING" | "STOPPING" | "STOPPED" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const NotebookRunStatus: any;
export type InstanceType = string;
export interface ComputeConfig {
    instanceType?: string;
    environmentVersion?: string;
}
export declare const ComputeConfig: S.Schema<ComputeConfig>;
export type NetworkAccessType = "PUBLIC_INTERNET_ONLY" | "VPC_ONLY" | (string & {});
export declare const NetworkAccessType: any;
export type SubnetIds = string[];
export declare const SubnetIds: any;
export type SecurityGroupIds = string[];
export declare const SecurityGroupIds: any;
export interface NetworkConfig {
    networkAccessType: NetworkAccessType;
    vpcId?: string;
    subnetIds?: string[];
    securityGroupIds?: string[];
}
export declare const NetworkConfig: S.Schema<NetworkConfig>;
export interface TimeoutConfig {
    runTimeoutInMinutes?: number;
}
export declare const TimeoutConfig: S.Schema<TimeoutConfig>;
export type S3Path = string;
export interface StorageConfig {
    projectS3Path?: string;
    kmsKeyArn?: string;
}
export declare const StorageConfig: S.Schema<StorageConfig>;
export type TriggerSourceType = "MANUAL" | "SCHEDULED" | "WORKFLOW" | (string & {});
export declare const TriggerSourceType: any;
export interface TriggerSource {
    type?: TriggerSourceType;
    name?: string;
}
export declare const TriggerSource: S.Schema<TriggerSource>;
export interface NotebookRunError {
    message: string;
}
export declare const NotebookRunError: S.Schema<NotebookRunError>;
export interface GetNotebookRunOutput {
    id: string;
    domainId: string;
    owningProjectId: string;
    notebookId: string;
    scheduleId?: string;
    status: NotebookRunStatus;
    cellOrder?: CellInformation[];
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    parameters?: {
        [key: string]: string | undefined;
    };
    computeConfiguration?: ComputeConfig;
    networkConfiguration?: NetworkConfig;
    timeoutConfiguration?: TimeoutConfig;
    environmentConfiguration?: EnvironmentConfig;
    storageConfiguration?: StorageConfig;
    triggerSource?: TriggerSource;
    error?: NotebookRunError;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    startedAt?: Date;
    completedAt?: Date;
}
export declare const GetNotebookRunOutput: S.Schema<GetNotebookRunOutput>;
export interface GetProjectInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetProjectInput: S.Schema<GetProjectInput>;
export interface GetProjectOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    projectStatus?: ProjectStatus;
    failureReasons?: ProjectDeletionError[];
    createdBy: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    resourceTags?: ResourceTag[];
    glossaryTerms?: string[];
    domainUnitId?: string;
    projectProfileId?: string;
    userParameters?: EnvironmentConfigurationUserParameter[];
    environmentDeploymentDetails?: EnvironmentDeploymentDetails;
    projectCategory?: string;
}
export declare const GetProjectOutput: S.Schema<GetProjectOutput>;
export interface GetProjectProfileInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetProjectProfileInput: S.Schema<GetProjectProfileInput>;
export interface GetProjectProfileOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    status?: Status;
    projectResourceTags?: ResourceTagParameter[];
    allowCustomProjectResourceTags?: boolean;
    projectResourceTagsDescription?: string | redacted.Redacted<string>;
    environmentConfigurations?: EnvironmentConfiguration[];
    createdBy: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    domainUnitId?: string;
}
export declare const GetProjectProfileOutput: S.Schema<GetProjectProfileOutput>;
export interface GetRuleInput {
    domainIdentifier: string;
    identifier: string;
    revision?: string;
}
export declare const GetRuleInput: S.Schema<GetRuleInput>;
export interface GetRuleOutput {
    identifier: string;
    revision: string;
    name: string | redacted.Redacted<string>;
    ruleType: RuleType;
    target: RuleTarget;
    action: RuleAction;
    scope: RuleScope;
    detail: RuleDetail;
    targetType?: RuleTargetType;
    description?: string | redacted.Redacted<string>;
    createdAt: Date;
    updatedAt: Date;
    createdBy: string;
    lastUpdatedBy: string;
}
export declare const GetRuleOutput: S.Schema<GetRuleOutput>;
export interface GetSubscriptionInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetSubscriptionInput: S.Schema<GetSubscriptionInput>;
export interface GetSubscriptionOutput {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    status: SubscriptionStatus;
    createdAt: Date;
    updatedAt: Date;
    subscribedPrincipal: SubscribedPrincipal;
    subscribedListing: SubscribedListing;
    subscriptionRequestId?: string;
    retainPermissions?: boolean;
}
export declare const GetSubscriptionOutput: S.Schema<GetSubscriptionOutput>;
export interface GetSubscriptionGrantInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetSubscriptionGrantInput: S.Schema<GetSubscriptionGrantInput>;
export interface GetSubscriptionGrantOutput {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    createdAt: Date;
    updatedAt: Date;
    environmentId?: string;
    subscriptionTargetId: string;
    grantedEntity: GrantedEntity;
    status: SubscriptionGrantOverallStatus;
    assets?: SubscribedAsset[];
    subscriptionId?: string;
}
export declare const GetSubscriptionGrantOutput: S.Schema<GetSubscriptionGrantOutput>;
export interface GetSubscriptionRequestDetailsInput {
    domainIdentifier: string;
    identifier: string;
}
export declare const GetSubscriptionRequestDetailsInput: S.Schema<GetSubscriptionRequestDetailsInput>;
export interface GetSubscriptionRequestDetailsOutput {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    status: SubscriptionRequestStatus;
    createdAt: Date;
    updatedAt: Date;
    requestReason: string | redacted.Redacted<string>;
    subscribedPrincipals: SubscribedPrincipal[];
    subscribedListings: SubscribedListing[];
    reviewerId?: string;
    decisionComment?: string | redacted.Redacted<string>;
    existingSubscriptionId?: string;
    metadataForms?: FormOutput[];
}
export declare const GetSubscriptionRequestDetailsOutput: S.Schema<GetSubscriptionRequestDetailsOutput>;
export interface GetSubscriptionTargetInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    identifier: string;
}
export declare const GetSubscriptionTargetInput: S.Schema<GetSubscriptionTargetInput>;
export interface GetSubscriptionTargetOutput {
    id: string;
    authorizedPrincipals: string[];
    domainId: string;
    projectId: string;
    environmentId: string;
    name: string | redacted.Redacted<string>;
    type: string;
    createdBy: string;
    updatedBy?: string;
    createdAt: Date;
    updatedAt?: Date;
    manageAccessRole?: string;
    applicableAssetTypes: string[];
    subscriptionTargetConfig: SubscriptionTargetForm[];
    provider: string;
    subscriptionGrantCreationMode?: SubscriptionGrantCreationMode;
}
export declare const GetSubscriptionTargetOutput: S.Schema<GetSubscriptionTargetOutput>;
export type TimeSeriesDataPointIdentifier = string;
export interface GetTimeSeriesDataPointInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: TimeSeriesEntityType;
    identifier: string;
    formName: string;
}
export declare const GetTimeSeriesDataPointInput: S.Schema<GetTimeSeriesDataPointInput>;
export interface TimeSeriesDataPointFormOutput {
    formName: string;
    typeIdentifier: string;
    typeRevision?: string;
    timestamp: Date;
    content?: string;
    id?: string;
}
export declare const TimeSeriesDataPointFormOutput: S.Schema<TimeSeriesDataPointFormOutput>;
export interface GetTimeSeriesDataPointOutput {
    domainId?: string;
    entityId?: string;
    entityType?: TimeSeriesEntityType;
    formName?: string;
    form?: TimeSeriesDataPointFormOutput;
}
export declare const GetTimeSeriesDataPointOutput: S.Schema<GetTimeSeriesDataPointOutput>;
export interface GetUserProfileInput {
    domainIdentifier: string;
    userIdentifier: string;
    type?: UserProfileType;
    sessionName?: string;
}
export declare const GetUserProfileInput: S.Schema<GetUserProfileInput>;
export interface GetUserProfileOutput {
    domainId?: string;
    id?: string;
    type?: UserProfileType;
    status?: UserProfileStatus;
    details?: UserProfileDetails;
}
export declare const GetUserProfileOutput: S.Schema<GetUserProfileOutput>;
export type SortFieldAccountPool = "NAME" | (string & {});
export declare const SortFieldAccountPool: any;
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export declare const SortOrder: any;
export type PaginationToken = string;
export type MaxResults = number;
export interface ListAccountPoolsInput {
    domainIdentifier: string;
    name?: string | redacted.Redacted<string>;
    sortBy?: SortFieldAccountPool;
    sortOrder?: SortOrder;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAccountPoolsInput: S.Schema<ListAccountPoolsInput>;
export interface AccountPoolSummary {
    domainId?: string;
    id?: string;
    name?: string | redacted.Redacted<string>;
    resolutionStrategy?: ResolutionStrategy;
    domainUnitId?: string;
    createdBy?: string;
    updatedBy?: string;
}
export declare const AccountPoolSummary: S.Schema<AccountPoolSummary>;
export type AccountPoolSummaries = AccountPoolSummary[];
export declare const AccountPoolSummaries: any;
export interface ListAccountPoolsOutput {
    items?: AccountPoolSummary[];
    nextToken?: string;
}
export declare const ListAccountPoolsOutput: S.Schema<ListAccountPoolsOutput>;
export interface ListAccountsInAccountPoolInput {
    domainIdentifier: string;
    identifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAccountsInAccountPoolInput: S.Schema<ListAccountsInAccountPoolInput>;
export interface ListAccountsInAccountPoolOutput {
    items?: AccountInfo[];
    nextToken?: string;
}
export declare const ListAccountsInAccountPoolOutput: S.Schema<ListAccountsInAccountPoolOutput>;
export interface ListAssetFiltersInput {
    domainIdentifier: string;
    assetIdentifier: string;
    status?: FilterStatus;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAssetFiltersInput: S.Schema<ListAssetFiltersInput>;
export interface AssetFilterSummary {
    id: string;
    domainId: string;
    assetId: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    status?: FilterStatus;
    effectiveColumnNames?: string[];
    effectiveRowFilter?: string;
    createdAt?: Date;
    errorMessage?: string;
}
export declare const AssetFilterSummary: S.Schema<AssetFilterSummary>;
export type AssetFilters = AssetFilterSummary[];
export declare const AssetFilters: any;
export interface ListAssetFiltersOutput {
    items: AssetFilterSummary[];
    nextToken?: string;
}
export declare const ListAssetFiltersOutput: S.Schema<ListAssetFiltersOutput>;
export interface ListAssetRevisionsInput {
    domainIdentifier: string;
    identifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAssetRevisionsInput: S.Schema<ListAssetRevisionsInput>;
export interface AssetRevision {
    domainId?: string;
    id?: string;
    revision?: string;
    createdBy?: string;
    createdAt?: Date;
}
export declare const AssetRevision: S.Schema<AssetRevision>;
export type AssetRevisions = AssetRevision[];
export declare const AssetRevisions: any;
export interface ListAssetRevisionsOutput {
    items?: AssetRevision[];
    nextToken?: string;
}
export declare const ListAssetRevisionsOutput: S.Schema<ListAssetRevisionsOutput>;
export type SortFieldConnection = "NAME" | (string & {});
export declare const SortFieldConnection: any;
export interface ListConnectionsInput {
    domainIdentifier: string;
    maxResults?: number;
    nextToken?: string;
    sortBy?: SortFieldConnection;
    sortOrder?: SortOrder;
    name?: string;
    environmentIdentifier?: string;
    projectIdentifier?: string;
    type?: ConnectionType;
    scope?: ConnectionScope;
}
export declare const ListConnectionsInput: S.Schema<ListConnectionsInput>;
export interface ConnectionSummary {
    configurations?: Configuration[];
    connectionId: string;
    domainId: string;
    domainUnitId: string;
    environmentId?: string;
    name: string;
    physicalEndpoints: PhysicalEndpoint[];
    projectId?: string;
    props?: ConnectionPropertiesOutput;
    type: ConnectionType;
    scope?: ConnectionScope;
}
export declare const ConnectionSummary: S.Schema<ConnectionSummary>;
export type ConnectionSummaries = ConnectionSummary[];
export declare const ConnectionSummaries: any;
export interface ListConnectionsOutput {
    items: ConnectionSummary[];
    nextToken?: string;
}
export declare const ListConnectionsOutput: S.Schema<ListConnectionsOutput>;
export interface ListDataProductRevisionsInput {
    domainIdentifier: string;
    identifier: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDataProductRevisionsInput: S.Schema<ListDataProductRevisionsInput>;
export interface DataProductRevision {
    domainId?: string;
    id?: string;
    revision?: string;
    createdAt?: Date;
    createdBy?: string;
}
export declare const DataProductRevision: S.Schema<DataProductRevision>;
export type DataProductRevisions = DataProductRevision[];
export declare const DataProductRevisions: any;
export interface ListDataProductRevisionsOutput {
    items: DataProductRevision[];
    nextToken?: string;
}
export declare const ListDataProductRevisionsOutput: S.Schema<ListDataProductRevisionsOutput>;
export type DataAssetActivityStatus = "FAILED" | "PUBLISHING_FAILED" | "SUCCEEDED_CREATED" | "SUCCEEDED_UPDATED" | "SKIPPED_ALREADY_IMPORTED" | "SKIPPED_ARCHIVED" | "SKIPPED_NO_ACCESS" | "UNCHANGED" | (string & {});
export declare const DataAssetActivityStatus: any;
export interface ListDataSourceRunActivitiesInput {
    domainIdentifier: string;
    identifier: string;
    status?: DataAssetActivityStatus;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDataSourceRunActivitiesInput: S.Schema<ListDataSourceRunActivitiesInput>;
export type LineageEventErrorMessage = string;
export interface LineageInfo {
    eventId?: string;
    eventStatus?: LineageEventProcessingStatus;
    errorMessage?: string;
}
export declare const LineageInfo: S.Schema<LineageInfo>;
export interface DataSourceRunActivity {
    database: string | redacted.Redacted<string>;
    dataSourceRunId: string;
    technicalName: string | redacted.Redacted<string>;
    dataAssetStatus: DataAssetActivityStatus;
    projectId: string;
    dataAssetId?: string;
    technicalDescription?: string | redacted.Redacted<string>;
    errorMessage?: DataSourceErrorMessage;
    lineageSummary?: LineageInfo;
    createdAt: Date;
    updatedAt: Date;
}
export declare const DataSourceRunActivity: S.Schema<DataSourceRunActivity>;
export type DataSourceRunActivities = DataSourceRunActivity[];
export declare const DataSourceRunActivities: any;
export interface ListDataSourceRunActivitiesOutput {
    items: DataSourceRunActivity[];
    nextToken?: string;
}
export declare const ListDataSourceRunActivitiesOutput: S.Schema<ListDataSourceRunActivitiesOutput>;
export interface ListDataSourceRunsInput {
    domainIdentifier: string;
    dataSourceIdentifier: string;
    status?: DataSourceRunStatus;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDataSourceRunsInput: S.Schema<ListDataSourceRunsInput>;
export interface DataSourceRunSummary {
    id: string;
    dataSourceId: string;
    type: DataSourceRunType;
    status: DataSourceRunStatus;
    projectId: string;
    runStatisticsForAssets?: RunStatisticsForAssets;
    errorMessage?: DataSourceErrorMessage;
    createdAt: Date;
    updatedAt: Date;
    startedAt?: Date;
    stoppedAt?: Date;
    lineageSummary?: DataSourceRunLineageSummary;
}
export declare const DataSourceRunSummary: S.Schema<DataSourceRunSummary>;
export type DataSourceRunSummaries = DataSourceRunSummary[];
export declare const DataSourceRunSummaries: any;
export interface ListDataSourceRunsOutput {
    items: DataSourceRunSummary[];
    nextToken?: string;
}
export declare const ListDataSourceRunsOutput: S.Schema<ListDataSourceRunsOutput>;
export interface ListDataSourcesInput {
    domainIdentifier: string;
    projectIdentifier: string;
    environmentIdentifier?: string;
    connectionIdentifier?: string;
    type?: string;
    status?: DataSourceStatus;
    name?: string | redacted.Redacted<string>;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDataSourcesInput: S.Schema<ListDataSourcesInput>;
export interface DataSourceSummary {
    domainId: string;
    environmentId?: string;
    connectionId?: string;
    dataSourceId: string;
    name: string | redacted.Redacted<string>;
    type: string;
    status: DataSourceStatus;
    enableSetting?: EnableSetting;
    schedule?: ScheduleConfiguration;
    lastRunStatus?: DataSourceRunStatus;
    lastRunAt?: Date;
    lastRunErrorMessage?: DataSourceErrorMessage;
    lastRunAssetCount?: number;
    createdAt?: Date;
    updatedAt?: Date;
    description?: string | redacted.Redacted<string>;
}
export declare const DataSourceSummary: S.Schema<DataSourceSummary>;
export type DataSourceSummaries = DataSourceSummary[];
export declare const DataSourceSummaries: any;
export interface ListDataSourcesOutput {
    items: DataSourceSummary[];
    nextToken?: string;
}
export declare const ListDataSourcesOutput: S.Schema<ListDataSourcesOutput>;
export type MaxResultsForListDomains = number;
export interface ListDomainsInput {
    status?: DomainStatus;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDomainsInput: S.Schema<ListDomainsInput>;
export type DomainName = string | redacted.Redacted<string>;
export type DomainDescription = string | redacted.Redacted<string>;
export interface DomainSummary {
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    arn: string;
    managedAccountId: string;
    status: DomainStatus;
    portalUrl?: string;
    createdAt: Date;
    lastUpdatedAt?: Date;
    domainVersion?: DomainVersion;
}
export declare const DomainSummary: S.Schema<DomainSummary>;
export type DomainSummaries = DomainSummary[];
export declare const DomainSummaries: any;
export interface ListDomainsOutput {
    items: DomainSummary[];
    nextToken?: string;
}
export declare const ListDomainsOutput: S.Schema<ListDomainsOutput>;
export interface ListDomainUnitsForParentInput {
    domainIdentifier: string;
    parentDomainUnitIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDomainUnitsForParentInput: S.Schema<ListDomainUnitsForParentInput>;
export interface DomainUnitSummary {
    name: string;
    id: string;
}
export declare const DomainUnitSummary: S.Schema<DomainUnitSummary>;
export type DomainUnitSummaries = DomainUnitSummary[];
export declare const DomainUnitSummaries: any;
export interface ListDomainUnitsForParentOutput {
    items: DomainUnitSummary[];
    nextToken?: string;
}
export declare const ListDomainUnitsForParentOutput: S.Schema<ListDomainUnitsForParentOutput>;
export interface ListEntityOwnersInput {
    domainIdentifier: string;
    entityType: DataZoneEntityType;
    entityIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListEntityOwnersInput: S.Schema<ListEntityOwnersInput>;
export interface OwnerUserPropertiesOutput {
    userId?: string;
}
export declare const OwnerUserPropertiesOutput: S.Schema<OwnerUserPropertiesOutput>;
export interface OwnerGroupPropertiesOutput {
    groupId?: string;
}
export declare const OwnerGroupPropertiesOutput: S.Schema<OwnerGroupPropertiesOutput>;
export type OwnerPropertiesOutput = {
    user: OwnerUserPropertiesOutput;
    group?: never;
} | {
    user?: never;
    group: OwnerGroupPropertiesOutput;
};
export declare const OwnerPropertiesOutput: any;
export type EntityOwners = OwnerPropertiesOutput[];
export declare const EntityOwners: any;
export interface ListEntityOwnersOutput {
    owners: OwnerPropertiesOutput[];
    nextToken?: string;
}
export declare const ListEntityOwnersOutput: S.Schema<ListEntityOwnersOutput>;
export interface ListEnvironmentActionsInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListEnvironmentActionsInput: S.Schema<ListEnvironmentActionsInput>;
export interface EnvironmentActionSummary {
    domainId: string;
    environmentId: string;
    id: string;
    name: string;
    parameters: ActionParameters;
    description?: string;
}
export declare const EnvironmentActionSummary: S.Schema<EnvironmentActionSummary>;
export type ListEnvironmentActionSummaries = EnvironmentActionSummary[];
export declare const ListEnvironmentActionSummaries: any;
export interface ListEnvironmentActionsOutput {
    items?: EnvironmentActionSummary[];
    nextToken?: string;
}
export declare const ListEnvironmentActionsOutput: S.Schema<ListEnvironmentActionsOutput>;
export interface ListEnvironmentBlueprintConfigurationsInput {
    domainIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListEnvironmentBlueprintConfigurationsInput: S.Schema<ListEnvironmentBlueprintConfigurationsInput>;
export interface EnvironmentBlueprintConfigurationItem {
    domainId: string;
    environmentBlueprintId: string;
    provisioningRoleArn?: string;
    environmentRolePermissionBoundary?: string;
    manageAccessRoleArn?: string;
    enabledRegions?: string[];
    regionalParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    allowUserProvidedConfigurations?: boolean;
    createdAt?: Date;
    updatedAt?: Date;
    resourceConfigurations?: ResourceConfiguration[];
    provisioningConfigurations?: ProvisioningConfiguration[];
}
export declare const EnvironmentBlueprintConfigurationItem: S.Schema<EnvironmentBlueprintConfigurationItem>;
export type EnvironmentBlueprintConfigurations = EnvironmentBlueprintConfigurationItem[];
export declare const EnvironmentBlueprintConfigurations: any;
export interface ListEnvironmentBlueprintConfigurationsOutput {
    items?: EnvironmentBlueprintConfigurationItem[];
    nextToken?: string;
}
export declare const ListEnvironmentBlueprintConfigurationsOutput: S.Schema<ListEnvironmentBlueprintConfigurationsOutput>;
export interface ListEnvironmentBlueprintsInput {
    domainIdentifier: string;
    maxResults?: number;
    nextToken?: string;
    name?: string;
    managed?: boolean;
}
export declare const ListEnvironmentBlueprintsInput: S.Schema<ListEnvironmentBlueprintsInput>;
export interface EnvironmentBlueprintSummary {
    id: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    provider: string;
    provisioningProperties: ProvisioningProperties;
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const EnvironmentBlueprintSummary: S.Schema<EnvironmentBlueprintSummary>;
export type EnvironmentBlueprintSummaries = EnvironmentBlueprintSummary[];
export declare const EnvironmentBlueprintSummaries: any;
export interface ListEnvironmentBlueprintsOutput {
    items: EnvironmentBlueprintSummary[];
    nextToken?: string;
}
export declare const ListEnvironmentBlueprintsOutput: S.Schema<ListEnvironmentBlueprintsOutput>;
export interface ListEnvironmentProfilesInput {
    domainIdentifier: string;
    awsAccountId?: string;
    awsAccountRegion?: string;
    environmentBlueprintIdentifier?: string;
    projectIdentifier?: string;
    name?: string | redacted.Redacted<string>;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListEnvironmentProfilesInput: S.Schema<ListEnvironmentProfilesInput>;
export interface EnvironmentProfileSummary {
    id: string;
    domainId: string;
    awsAccountId?: string;
    awsAccountRegion?: string;
    createdBy: string;
    createdAt?: Date;
    updatedAt?: Date;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    environmentBlueprintId: string;
    projectId?: string;
}
export declare const EnvironmentProfileSummary: S.Schema<EnvironmentProfileSummary>;
export type EnvironmentProfileSummaries = EnvironmentProfileSummary[];
export declare const EnvironmentProfileSummaries: any;
export interface ListEnvironmentProfilesOutput {
    items: EnvironmentProfileSummary[];
    nextToken?: string;
}
export declare const ListEnvironmentProfilesOutput: S.Schema<ListEnvironmentProfilesOutput>;
export interface ListEnvironmentsInput {
    domainIdentifier: string;
    awsAccountId?: string;
    status?: EnvironmentStatus;
    awsAccountRegion?: string;
    projectIdentifier: string;
    environmentProfileIdentifier?: string;
    environmentBlueprintIdentifier?: string;
    provider?: string;
    name?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListEnvironmentsInput: S.Schema<ListEnvironmentsInput>;
export interface EnvironmentSummary {
    projectId: string;
    id?: string;
    domainId: string;
    createdBy: string;
    createdAt?: Date;
    updatedAt?: Date;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    environmentProfileId?: string;
    awsAccountId?: string;
    awsAccountRegion?: string;
    provider: string;
    status?: EnvironmentStatus;
    environmentConfigurationId?: string | redacted.Redacted<string>;
    environmentConfigurationName?: string | redacted.Redacted<string>;
}
export declare const EnvironmentSummary: S.Schema<EnvironmentSummary>;
export type EnvironmentSummaries = EnvironmentSummary[];
export declare const EnvironmentSummaries: any;
export interface ListEnvironmentsOutput {
    items: EnvironmentSummary[];
    nextToken?: string;
}
export declare const ListEnvironmentsOutput: S.Schema<ListEnvironmentsOutput>;
export interface ListJobRunsInput {
    domainIdentifier: string;
    jobIdentifier: string;
    status?: JobRunStatus;
    sortOrder?: SortOrder;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListJobRunsInput: S.Schema<ListJobRunsInput>;
export interface JobRunSummary {
    domainId?: string;
    jobId?: string;
    jobType?: JobType;
    runId?: string;
    runMode?: JobRunMode;
    status?: JobRunStatus;
    error?: JobRunError;
    createdBy?: string;
    createdAt?: Date;
    startTime?: Date;
    endTime?: Date;
}
export declare const JobRunSummary: S.Schema<JobRunSummary>;
export type JobRunSummaries = JobRunSummary[];
export declare const JobRunSummaries: any;
export interface ListJobRunsOutput {
    items?: JobRunSummary[];
    nextToken?: string;
}
export declare const ListJobRunsOutput: S.Schema<ListJobRunsOutput>;
export interface ListLineageEventsInput {
    domainIdentifier: string;
    maxResults?: number;
    timestampAfter?: Date;
    timestampBefore?: Date;
    processingStatus?: LineageEventProcessingStatus;
    sortOrder?: SortOrder;
    nextToken?: string;
}
export declare const ListLineageEventsInput: S.Schema<ListLineageEventsInput>;
export type OpenLineageRunState = "START" | "RUNNING" | "COMPLETE" | "ABORT" | "FAIL" | "OTHER" | (string & {});
export declare const OpenLineageRunState: any;
export interface NameIdentifier {
    name?: string;
    namespace?: string;
}
export declare const NameIdentifier: S.Schema<NameIdentifier>;
export type NameIdentifiers = NameIdentifier[];
export declare const NameIdentifiers: any;
export interface OpenLineageRunEventSummary {
    eventType?: OpenLineageRunState;
    runId?: string;
    job?: NameIdentifier;
    inputs?: NameIdentifier[];
    outputs?: NameIdentifier[];
}
export declare const OpenLineageRunEventSummary: S.Schema<OpenLineageRunEventSummary>;
export type EventSummary = {
    openLineageRunEventSummary: OpenLineageRunEventSummary;
};
export declare const EventSummary: any;
export interface LineageEventSummary {
    id?: string;
    domainId?: string;
    processingStatus?: LineageEventProcessingStatus;
    eventTime?: Date;
    eventSummary?: EventSummary;
    createdBy?: string;
    createdAt?: Date;
}
export declare const LineageEventSummary: S.Schema<LineageEventSummary>;
export type LineageEventSummaries = LineageEventSummary[];
export declare const LineageEventSummaries: any;
export interface ListLineageEventsOutput {
    items?: LineageEventSummary[];
    nextToken?: string;
}
export declare const ListLineageEventsOutput: S.Schema<ListLineageEventsOutput>;
export type EdgeDirection = "UPSTREAM" | "DOWNSTREAM" | (string & {});
export declare const EdgeDirection: any;
export interface ListLineageNodeHistoryInput {
    domainIdentifier: string;
    maxResults?: number;
    nextToken?: string;
    identifier: string;
    direction?: EdgeDirection;
    eventTimestampGTE?: Date;
    eventTimestampLTE?: Date;
    sortOrder?: SortOrder;
}
export declare const ListLineageNodeHistoryInput: S.Schema<ListLineageNodeHistoryInput>;
export interface LineageNodeSummary {
    domainId: string;
    name?: string;
    description?: string;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    id: string;
    typeName: string;
    typeRevision?: string;
    sourceIdentifier?: string;
    eventTimestamp?: Date;
}
export declare const LineageNodeSummary: S.Schema<LineageNodeSummary>;
export type LineageNodeSummaries = LineageNodeSummary[];
export declare const LineageNodeSummaries: any;
export interface ListLineageNodeHistoryOutput {
    nodes?: LineageNodeSummary[];
    nextToken?: string;
}
export declare const ListLineageNodeHistoryOutput: S.Schema<ListLineageNodeHistoryOutput>;
export interface ListMetadataGenerationRunsInput {
    domainIdentifier: string;
    status?: MetadataGenerationRunStatus;
    type?: MetadataGenerationRunType;
    nextToken?: string;
    maxResults?: number;
    targetIdentifier?: string;
}
export declare const ListMetadataGenerationRunsInput: S.Schema<ListMetadataGenerationRunsInput>;
export interface MetadataGenerationRunItem {
    domainId: string;
    id: string;
    target?: MetadataGenerationRunTarget;
    status?: MetadataGenerationRunStatus;
    type?: MetadataGenerationRunType;
    types?: MetadataGenerationRunType[];
    createdAt?: Date;
    createdBy?: string;
    owningProjectId: string;
}
export declare const MetadataGenerationRunItem: S.Schema<MetadataGenerationRunItem>;
export type MetadataGenerationRuns = MetadataGenerationRunItem[];
export declare const MetadataGenerationRuns: any;
export interface ListMetadataGenerationRunsOutput {
    items?: MetadataGenerationRunItem[];
    nextToken?: string;
}
export declare const ListMetadataGenerationRunsOutput: S.Schema<ListMetadataGenerationRunsOutput>;
export interface ListNotebookRunsInput {
    domainIdentifier: string;
    owningProjectIdentifier: string;
    notebookIdentifier?: string;
    status?: NotebookRunStatus;
    scheduleIdentifier?: string;
    maxResults?: number;
    sortOrder?: SortOrder;
    nextToken?: string;
}
export declare const ListNotebookRunsInput: S.Schema<ListNotebookRunsInput>;
export interface NotebookRunSummary {
    id: string;
    domainId: string;
    owningProjectId: string;
    notebookId: string;
    scheduleId?: string;
    status: NotebookRunStatus;
    triggerSource?: TriggerSource;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    startedAt?: Date;
    completedAt?: Date;
}
export declare const NotebookRunSummary: S.Schema<NotebookRunSummary>;
export type NotebookRunSummaryList = NotebookRunSummary[];
export declare const NotebookRunSummaryList: any;
export interface ListNotebookRunsOutput {
    items?: NotebookRunSummary[];
    nextToken?: string;
}
export declare const ListNotebookRunsOutput: S.Schema<ListNotebookRunsOutput>;
export type SortKey = "CREATED_AT" | "UPDATED_AT" | (string & {});
export declare const SortKey: any;
export interface ListNotebooksInput {
    domainIdentifier: string;
    owningProjectIdentifier: string;
    maxResults?: number;
    sortOrder?: SortOrder;
    sortBy?: SortKey;
    status?: NotebookStatus;
    nextToken?: string;
}
export declare const ListNotebooksInput: S.Schema<ListNotebooksInput>;
export interface NotebookSummary {
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    domainId: string;
    status: NotebookStatus;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
}
export declare const NotebookSummary: S.Schema<NotebookSummary>;
export type NotebookSummaryList = NotebookSummary[];
export declare const NotebookSummaryList: any;
export interface ListNotebooksOutput {
    items?: NotebookSummary[];
    nextToken?: string;
}
export declare const ListNotebooksOutput: S.Schema<ListNotebooksOutput>;
export type NotificationType = "TASK" | "EVENT" | (string & {});
export declare const NotificationType: any;
export type NotificationSubjects = string[];
export declare const NotificationSubjects: any;
export type TaskStatus = "ACTIVE" | "INACTIVE" | (string & {});
export declare const TaskStatus: any;
export interface ListNotificationsInput {
    domainIdentifier: string;
    type: NotificationType;
    afterTimestamp?: Date;
    beforeTimestamp?: Date;
    subjects?: string[];
    taskStatus?: TaskStatus;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListNotificationsInput: S.Schema<ListNotificationsInput>;
export type TaskId = string;
export type NotificationResourceType = "PROJECT" | (string & {});
export declare const NotificationResourceType: any;
export interface NotificationResource {
    type: NotificationResourceType;
    id: string;
    name?: string;
}
export declare const NotificationResource: S.Schema<NotificationResource>;
export type NotificationRole = "PROJECT_OWNER" | "PROJECT_CONTRIBUTOR" | "PROJECT_VIEWER" | "DOMAIN_OWNER" | "PROJECT_SUBSCRIBER" | (string & {});
export declare const NotificationRole: any;
export interface Topic {
    subject: string;
    resource: NotificationResource;
    role: NotificationRole;
}
export declare const Topic: S.Schema<Topic>;
export type Title = string | redacted.Redacted<string>;
export type Message = string | redacted.Redacted<string>;
export type ActionLink = string | redacted.Redacted<string>;
export type MetadataMap = {
    [key: string]: string | undefined;
};
export declare const MetadataMap: any;
export interface NotificationOutput {
    identifier: string;
    domainIdentifier: string;
    type: NotificationType;
    topic: Topic;
    title: string | redacted.Redacted<string>;
    message: string | redacted.Redacted<string>;
    status?: TaskStatus;
    actionLink: string | redacted.Redacted<string>;
    creationTimestamp: Date;
    lastUpdatedTimestamp: Date;
    metadata?: {
        [key: string]: string | undefined;
    };
}
export declare const NotificationOutput: S.Schema<NotificationOutput>;
export type NotificationsList = NotificationOutput[];
export declare const NotificationsList: any;
export interface ListNotificationsOutput {
    notifications?: NotificationOutput[];
    nextToken?: string;
}
export declare const ListNotificationsOutput: S.Schema<ListNotificationsOutput>;
export interface ListPolicyGrantsInput {
    domainIdentifier: string;
    entityType: TargetEntityType;
    entityIdentifier: string;
    policyType: ManagedPolicyType;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListPolicyGrantsInput: S.Schema<ListPolicyGrantsInput>;
export interface PolicyGrantMember {
    principal?: PolicyGrantPrincipal;
    detail?: PolicyGrantDetail;
    createdAt?: Date;
    createdBy?: string;
    grantId?: string;
}
export declare const PolicyGrantMember: S.Schema<PolicyGrantMember>;
export type PolicyGrantList = PolicyGrantMember[];
export declare const PolicyGrantList: any;
export interface ListPolicyGrantsOutput {
    grantList: PolicyGrantMember[];
    nextToken?: string;
}
export declare const ListPolicyGrantsOutput: S.Schema<ListPolicyGrantsOutput>;
export type SortFieldProject = "NAME" | (string & {});
export declare const SortFieldProject: any;
export interface ListProjectMembershipsInput {
    domainIdentifier: string;
    projectIdentifier: string;
    sortBy?: SortFieldProject;
    sortOrder?: SortOrder;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListProjectMembershipsInput: S.Schema<ListProjectMembershipsInput>;
export interface UserDetails {
    userId: string;
}
export declare const UserDetails: S.Schema<UserDetails>;
export interface GroupDetails {
    groupId: string;
}
export declare const GroupDetails: S.Schema<GroupDetails>;
export type MemberDetails = {
    user: UserDetails;
    group?: never;
} | {
    user?: never;
    group: GroupDetails;
};
export declare const MemberDetails: any;
export interface ProjectMember {
    memberDetails: MemberDetails;
    designation: UserDesignation;
}
export declare const ProjectMember: S.Schema<ProjectMember>;
export type ProjectMembers = ProjectMember[];
export declare const ProjectMembers: any;
export interface ListProjectMembershipsOutput {
    members: ProjectMember[];
    nextToken?: string;
}
export declare const ListProjectMembershipsOutput: S.Schema<ListProjectMembershipsOutput>;
export interface ListProjectProfilesInput {
    domainIdentifier: string;
    name?: string | redacted.Redacted<string>;
    sortBy?: SortFieldProject;
    sortOrder?: SortOrder;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListProjectProfilesInput: S.Schema<ListProjectProfilesInput>;
export interface ProjectProfileSummary {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    status?: Status;
    createdBy: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    domainUnitId?: string;
}
export declare const ProjectProfileSummary: S.Schema<ProjectProfileSummary>;
export type ProjectProfileSummaries = ProjectProfileSummary[];
export declare const ProjectProfileSummaries: any;
export interface ListProjectProfilesOutput {
    items?: ProjectProfileSummary[];
    nextToken?: string;
}
export declare const ListProjectProfilesOutput: S.Schema<ListProjectProfilesOutput>;
export interface ListProjectsInput {
    domainIdentifier: string;
    userIdentifier?: string;
    groupIdentifier?: string;
    name?: string | redacted.Redacted<string>;
    projectCategory?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListProjectsInput: S.Schema<ListProjectsInput>;
export interface ProjectSummary {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    projectStatus?: ProjectStatus;
    failureReasons?: ProjectDeletionError[];
    createdBy: string;
    createdAt?: Date;
    updatedAt?: Date;
    domainUnitId?: string;
    projectCategory?: string;
}
export declare const ProjectSummary: S.Schema<ProjectSummary>;
export type ProjectSummaries = ProjectSummary[];
export declare const ProjectSummaries: any;
export interface ListProjectsOutput {
    items?: ProjectSummary[];
    nextToken?: string;
}
export declare const ListProjectsOutput: S.Schema<ListProjectsOutput>;
export type ProjectIds = string[];
export declare const ProjectIds: any;
export type AssetTypeIdentifiers = string[];
export declare const AssetTypeIdentifiers: any;
export interface ListRulesInput {
    domainIdentifier: string;
    targetType: RuleTargetType;
    targetIdentifier: string;
    ruleType?: RuleType;
    action?: RuleAction;
    projectIds?: string[];
    assetTypes?: string[];
    dataProduct?: boolean;
    includeCascaded?: boolean;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRulesInput: S.Schema<ListRulesInput>;
export interface RuleSummary {
    identifier?: string;
    revision?: string;
    ruleType?: RuleType;
    name?: string | redacted.Redacted<string>;
    targetType?: RuleTargetType;
    target?: RuleTarget;
    action?: RuleAction;
    scope?: RuleScope;
    updatedAt?: Date;
    lastUpdatedBy?: string;
}
export declare const RuleSummary: S.Schema<RuleSummary>;
export type RuleSummaries = RuleSummary[];
export declare const RuleSummaries: any;
export interface ListRulesOutput {
    items: RuleSummary[];
    nextToken?: string;
}
export declare const ListRulesOutput: S.Schema<ListRulesOutput>;
export interface ListSubscriptionGrantsInput {
    domainIdentifier: string;
    environmentId?: string;
    subscriptionTargetId?: string;
    subscribedListingId?: string;
    subscriptionId?: string;
    owningProjectId?: string;
    owningIamPrincipalArn?: string;
    owningUserId?: string;
    owningGroupId?: string;
    sortBy?: SortKey;
    sortOrder?: SortOrder;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSubscriptionGrantsInput: S.Schema<ListSubscriptionGrantsInput>;
export interface SubscriptionGrantSummary {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    createdAt: Date;
    updatedAt: Date;
    environmentId?: string;
    subscriptionTargetId: string;
    grantedEntity: GrantedEntity;
    status: SubscriptionGrantOverallStatus;
    assets?: SubscribedAsset[];
    subscriptionId?: string;
}
export declare const SubscriptionGrantSummary: S.Schema<SubscriptionGrantSummary>;
export type SubscriptionGrants = SubscriptionGrantSummary[];
export declare const SubscriptionGrants: any;
export interface ListSubscriptionGrantsOutput {
    items: SubscriptionGrantSummary[];
    nextToken?: string;
}
export declare const ListSubscriptionGrantsOutput: S.Schema<ListSubscriptionGrantsOutput>;
export interface ListSubscriptionRequestsInput {
    domainIdentifier: string;
    status?: SubscriptionRequestStatus;
    subscribedListingId?: string;
    owningProjectId?: string;
    owningIamPrincipalArn?: string;
    approverProjectId?: string;
    owningUserId?: string;
    owningGroupId?: string;
    sortBy?: SortKey;
    sortOrder?: SortOrder;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSubscriptionRequestsInput: S.Schema<ListSubscriptionRequestsInput>;
export interface MetadataFormSummary {
    formName?: string;
    typeName: string | redacted.Redacted<string>;
    typeRevision: string;
}
export declare const MetadataFormSummary: S.Schema<MetadataFormSummary>;
export type MetadataFormsSummary = MetadataFormSummary[];
export declare const MetadataFormsSummary: any;
export interface SubscriptionRequestSummary {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    status: SubscriptionRequestStatus;
    createdAt: Date;
    updatedAt: Date;
    requestReason: string | redacted.Redacted<string>;
    subscribedPrincipals: SubscribedPrincipal[];
    subscribedListings: SubscribedListing[];
    reviewerId?: string;
    decisionComment?: string | redacted.Redacted<string>;
    existingSubscriptionId?: string;
    metadataFormsSummary?: MetadataFormSummary[];
}
export declare const SubscriptionRequestSummary: S.Schema<SubscriptionRequestSummary>;
export type SubscriptionRequests = SubscriptionRequestSummary[];
export declare const SubscriptionRequests: any;
export interface ListSubscriptionRequestsOutput {
    items: SubscriptionRequestSummary[];
    nextToken?: string;
}
export declare const ListSubscriptionRequestsOutput: S.Schema<ListSubscriptionRequestsOutput>;
export interface ListSubscriptionsInput {
    domainIdentifier: string;
    subscriptionRequestIdentifier?: string;
    status?: SubscriptionStatus;
    subscribedListingId?: string;
    owningProjectId?: string;
    owningIamPrincipalArn?: string;
    owningUserId?: string;
    owningGroupId?: string;
    approverProjectId?: string;
    sortBy?: SortKey;
    sortOrder?: SortOrder;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSubscriptionsInput: S.Schema<ListSubscriptionsInput>;
export interface SubscriptionSummary {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    status: SubscriptionStatus;
    createdAt: Date;
    updatedAt: Date;
    subscribedPrincipal: SubscribedPrincipal;
    subscribedListing: SubscribedListing;
    subscriptionRequestId?: string;
    retainPermissions?: boolean;
}
export declare const SubscriptionSummary: S.Schema<SubscriptionSummary>;
export type Subscriptions = SubscriptionSummary[];
export declare const Subscriptions: any;
export interface ListSubscriptionsOutput {
    items: SubscriptionSummary[];
    nextToken?: string;
}
export declare const ListSubscriptionsOutput: S.Schema<ListSubscriptionsOutput>;
export interface ListSubscriptionTargetsInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    sortBy?: SortKey;
    sortOrder?: SortOrder;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSubscriptionTargetsInput: S.Schema<ListSubscriptionTargetsInput>;
export interface SubscriptionTargetSummary {
    id: string;
    authorizedPrincipals: string[];
    domainId: string;
    projectId: string;
    environmentId: string;
    name: string | redacted.Redacted<string>;
    type: string;
    createdBy: string;
    updatedBy?: string;
    createdAt: Date;
    updatedAt?: Date;
    manageAccessRole?: string;
    applicableAssetTypes: string[];
    subscriptionTargetConfig: SubscriptionTargetForm[];
    provider: string;
    subscriptionGrantCreationMode?: SubscriptionGrantCreationMode;
}
export declare const SubscriptionTargetSummary: S.Schema<SubscriptionTargetSummary>;
export type SubscriptionTargets = SubscriptionTargetSummary[];
export declare const SubscriptionTargets: any;
export interface ListSubscriptionTargetsOutput {
    items: SubscriptionTargetSummary[];
    nextToken?: string;
}
export declare const ListSubscriptionTargetsOutput: S.Schema<ListSubscriptionTargetsOutput>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListTimeSeriesDataPointsInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: TimeSeriesEntityType;
    formName: string;
    startedAt?: Date;
    endedAt?: Date;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListTimeSeriesDataPointsInput: S.Schema<ListTimeSeriesDataPointsInput>;
export interface ListTimeSeriesDataPointsOutput {
    items?: TimeSeriesDataPointSummaryFormOutput[];
    nextToken?: string;
}
export declare const ListTimeSeriesDataPointsOutput: S.Schema<ListTimeSeriesDataPointsOutput>;
export interface PostLineageEventInput {
    domainIdentifier: string;
    event: T.StreamingInputBody;
    clientToken?: string;
}
export declare const PostLineageEventInput: S.Schema<PostLineageEventInput>;
export interface PostLineageEventOutput {
    id?: string;
    domainId?: string;
}
export declare const PostLineageEventOutput: S.Schema<PostLineageEventOutput>;
export interface TimeSeriesDataPointFormInput {
    formName: string;
    typeIdentifier: string;
    typeRevision?: string;
    timestamp: Date;
    content?: string;
}
export declare const TimeSeriesDataPointFormInput: S.Schema<TimeSeriesDataPointFormInput>;
export type TimeSeriesDataPointFormInputList = TimeSeriesDataPointFormInput[];
export declare const TimeSeriesDataPointFormInputList: any;
export interface PostTimeSeriesDataPointsInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: TimeSeriesEntityType;
    forms: TimeSeriesDataPointFormInput[];
    clientToken?: string;
}
export declare const PostTimeSeriesDataPointsInput: S.Schema<PostTimeSeriesDataPointsInput>;
export type TimeSeriesDataPointFormOutputList = TimeSeriesDataPointFormOutput[];
export declare const TimeSeriesDataPointFormOutputList: any;
export interface PostTimeSeriesDataPointsOutput {
    domainId?: string;
    entityId?: string;
    entityType?: TimeSeriesEntityType;
    forms?: TimeSeriesDataPointFormOutput[];
}
export declare const PostTimeSeriesDataPointsOutput: S.Schema<PostTimeSeriesDataPointsOutput>;
export interface PutDataExportConfigurationInput {
    domainIdentifier: string;
    enableExport: boolean;
    encryptionConfiguration?: EncryptionConfiguration;
    clientToken?: string;
}
export declare const PutDataExportConfigurationInput: S.Schema<PutDataExportConfigurationInput>;
export interface PutDataExportConfigurationOutput {
}
export declare const PutDataExportConfigurationOutput: S.Schema<PutDataExportConfigurationOutput>;
export interface PutResourceConfiguration {
    name: string;
    description?: string;
    region: string;
    parameters: {
        [key: string]: string | undefined;
    };
}
export declare const PutResourceConfiguration: S.Schema<PutResourceConfiguration>;
export type PutResourceConfigurations = PutResourceConfiguration[];
export declare const PutResourceConfigurations: any;
export type GlobalParameterMap = {
    [key: string]: string | undefined;
};
export declare const GlobalParameterMap: any;
export interface PutEnvironmentBlueprintConfigurationInput {
    domainIdentifier: string;
    environmentBlueprintIdentifier: string;
    provisioningRoleArn?: string;
    manageAccessRoleArn?: string;
    environmentRolePermissionBoundary?: string;
    enabledRegions: string[];
    regionalParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    resourceConfigurations?: PutResourceConfiguration[];
    allowUserProvidedConfigurations?: boolean;
    globalParameters?: {
        [key: string]: string | undefined;
    };
    provisioningConfigurations?: ProvisioningConfiguration[];
}
export declare const PutEnvironmentBlueprintConfigurationInput: S.Schema<PutEnvironmentBlueprintConfigurationInput>;
export interface PutEnvironmentBlueprintConfigurationOutput {
    domainId: string;
    environmentBlueprintId: string;
    provisioningRoleArn?: string;
    environmentRolePermissionBoundary?: string;
    manageAccessRoleArn?: string;
    enabledRegions?: string[];
    regionalParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    allowUserProvidedConfigurations?: boolean;
    createdAt?: Date;
    updatedAt?: Date;
    resourceConfigurations?: ResourceConfiguration[];
    provisioningConfigurations?: ProvisioningConfiguration[];
}
export declare const PutEnvironmentBlueprintConfigurationOutput: S.Schema<PutEnvironmentBlueprintConfigurationOutput>;
export type RelationType = "LINEAGE" | (string & {});
export declare const RelationType: any;
export type RelationDirection = "IN" | "OUT" | (string & {});
export declare const RelationDirection: any;
export interface RelationPattern {
    relationType: RelationType;
    relationDirection: RelationDirection;
    maxPathLength?: number;
}
export declare const RelationPattern: S.Schema<RelationPattern>;
export type GraphEntityType = "LINEAGE_NODE" | (string & {});
export declare const GraphEntityType: any;
export type Attribute = string;
export type FilterOperator = "EQ" | "LE" | "LT" | "GE" | "GT" | "TEXT_SEARCH" | (string & {});
export declare const FilterOperator: any;
export interface Filter {
    attribute: string;
    value?: string;
    intValue?: number;
    operator?: FilterOperator;
}
export declare const Filter: S.Schema<Filter>;
export type FilterList = FilterClause[];
export declare const FilterList: S.Schema<FilterList>;
export type FilterClause = {
    filter: Filter;
    and?: never;
    or?: never;
} | {
    filter?: never;
    and: FilterClause[];
    or?: never;
} | {
    filter?: never;
    and?: never;
    or: FilterClause[];
};
export declare const FilterClause: S.Schema<FilterClause>;
export interface EntityPattern {
    entityType: GraphEntityType;
    identifier: string;
    filters?: FilterClause;
}
export declare const EntityPattern: S.Schema<EntityPattern>;
export type MatchClause = {
    relationPattern: RelationPattern;
    entityPattern?: never;
} | {
    relationPattern?: never;
    entityPattern: EntityPattern;
};
export declare const MatchClause: any;
export type MatchClauses = MatchClause[];
export declare const MatchClauses: any;
export type FormNameList = string[];
export declare const FormNameList: any;
export interface AdditionalAttributes {
    formNames?: string[];
}
export declare const AdditionalAttributes: S.Schema<AdditionalAttributes>;
export interface QueryGraphInput {
    domainIdentifier: string;
    match: MatchClause[];
    maxResults?: number;
    nextToken?: string;
    additionalAttributes?: AdditionalAttributes;
}
export declare const QueryGraphInput: S.Schema<QueryGraphInput>;
export type LineageNodeIds = string[];
export declare const LineageNodeIds: any;
export interface LineageNodeItem {
    domainId: string;
    name?: string;
    description?: string;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    id: string;
    typeName: string;
    typeRevision?: string;
    sourceIdentifier?: string;
    eventTimestamp?: Date;
    formsOutput?: FormOutput[];
    upstreamLineageNodeIds?: string[];
    downstreamLineageNodeIds?: string[];
}
export declare const LineageNodeItem: S.Schema<LineageNodeItem>;
export type ResultItem = {
    lineageNode: LineageNodeItem;
};
export declare const ResultItem: any;
export type ResultItemList = ResultItem[];
export declare const ResultItemList: any;
export interface QueryGraphOutput {
    items?: ResultItem[];
    nextToken?: string;
}
export declare const QueryGraphOutput: S.Schema<QueryGraphOutput>;
export type RejectRuleBehavior = "ALL" | "NONE" | (string & {});
export declare const RejectRuleBehavior: any;
export interface RejectRule {
    rule?: RejectRuleBehavior;
    threshold?: number;
}
export declare const RejectRule: S.Schema<RejectRule>;
export type PredictionChoices = number[];
export declare const PredictionChoices: any;
export interface RejectChoice {
    predictionTarget?: string;
    predictionChoices?: number[];
}
export declare const RejectChoice: S.Schema<RejectChoice>;
export type RejectChoices = RejectChoice[];
export declare const RejectChoices: any;
export interface RejectPredictionsInput {
    domainIdentifier: string;
    identifier: string;
    revision?: string;
    rejectRule?: RejectRule;
    rejectChoices?: RejectChoice[];
    clientToken?: string;
}
export declare const RejectPredictionsInput: S.Schema<RejectPredictionsInput>;
export interface RejectPredictionsOutput {
    domainId: string;
    assetId: string;
    assetRevision: string;
}
export declare const RejectPredictionsOutput: S.Schema<RejectPredictionsOutput>;
export interface RejectSubscriptionRequestInput {
    domainIdentifier: string;
    identifier: string;
    decisionComment?: string | redacted.Redacted<string>;
}
export declare const RejectSubscriptionRequestInput: S.Schema<RejectSubscriptionRequestInput>;
export interface RejectSubscriptionRequestOutput {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    status: SubscriptionRequestStatus;
    createdAt: Date;
    updatedAt: Date;
    requestReason: string | redacted.Redacted<string>;
    subscribedPrincipals: SubscribedPrincipal[];
    subscribedListings: SubscribedListing[];
    reviewerId?: string;
    decisionComment?: string | redacted.Redacted<string>;
    existingSubscriptionId?: string;
    metadataForms?: FormOutput[];
}
export declare const RejectSubscriptionRequestOutput: S.Schema<RejectSubscriptionRequestOutput>;
export interface RemoveEntityOwnerInput {
    domainIdentifier: string;
    entityType: DataZoneEntityType;
    entityIdentifier: string;
    owner: OwnerProperties;
    clientToken?: string;
}
export declare const RemoveEntityOwnerInput: S.Schema<RemoveEntityOwnerInput>;
export interface RemoveEntityOwnerOutput {
}
export declare const RemoveEntityOwnerOutput: S.Schema<RemoveEntityOwnerOutput>;
export interface RemovePolicyGrantInput {
    domainIdentifier: string;
    entityType: TargetEntityType;
    entityIdentifier: string;
    policyType: ManagedPolicyType;
    principal: PolicyGrantPrincipal;
    grantIdentifier?: string;
    clientToken?: string;
}
export declare const RemovePolicyGrantInput: S.Schema<RemovePolicyGrantInput>;
export interface RemovePolicyGrantOutput {
}
export declare const RemovePolicyGrantOutput: S.Schema<RemovePolicyGrantOutput>;
export interface RevokeSubscriptionInput {
    domainIdentifier: string;
    identifier: string;
    retainPermissions?: boolean;
}
export declare const RevokeSubscriptionInput: S.Schema<RevokeSubscriptionInput>;
export interface RevokeSubscriptionOutput {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    status: SubscriptionStatus;
    createdAt: Date;
    updatedAt: Date;
    subscribedPrincipal: SubscribedPrincipal;
    subscribedListing: SubscribedListing;
    subscriptionRequestId?: string;
    retainPermissions?: boolean;
}
export declare const RevokeSubscriptionOutput: S.Schema<RevokeSubscriptionOutput>;
export type InventorySearchScope = "ASSET" | "GLOSSARY" | "GLOSSARY_TERM" | "DATA_PRODUCT" | (string & {});
export declare const InventorySearchScope: any;
export type SearchText = string;
export interface SearchInItem {
    attribute: string;
}
export declare const SearchInItem: S.Schema<SearchInItem>;
export type SearchInList = SearchInItem[];
export declare const SearchInList: any;
export interface SearchSort {
    attribute: string;
    order?: SortOrder;
}
export declare const SearchSort: S.Schema<SearchSort>;
export type SearchOutputAdditionalAttribute = "FORMS" | "TIME_SERIES_DATA_POINT_FORMS" | "TEXT_MATCH_RATIONALE" | (string & {});
export declare const SearchOutputAdditionalAttribute: any;
export type SearchOutputAdditionalAttributes = SearchOutputAdditionalAttribute[];
export declare const SearchOutputAdditionalAttributes: any;
export interface SearchInput {
    domainIdentifier: string;
    owningProjectIdentifier?: string;
    maxResults?: number;
    nextToken?: string;
    searchScope: InventorySearchScope;
    searchText?: string;
    searchIn?: SearchInItem[];
    filters?: FilterClause;
    sort?: SearchSort;
    additionalAttributes?: SearchOutputAdditionalAttribute[];
}
export declare const SearchInput: S.Schema<SearchInput>;
export interface MatchOffset {
    startOffset?: number;
    endOffset?: number;
}
export declare const MatchOffset: S.Schema<MatchOffset>;
export type MatchOffsets = MatchOffset[];
export declare const MatchOffsets: any;
export interface TextMatchItem {
    attribute?: string;
    text?: string;
    matchOffsets?: MatchOffset[];
}
export declare const TextMatchItem: S.Schema<TextMatchItem>;
export type TextMatches = TextMatchItem[];
export declare const TextMatches: any;
export type MatchRationaleItem = {
    textMatches: TextMatchItem[];
};
export declare const MatchRationaleItem: any;
export type MatchRationale = MatchRationaleItem[];
export declare const MatchRationale: any;
export interface GlossaryItemAdditionalAttributes {
    matchRationale?: MatchRationaleItem[];
}
export declare const GlossaryItemAdditionalAttributes: S.Schema<GlossaryItemAdditionalAttributes>;
export interface GlossaryItem {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    description?: string | redacted.Redacted<string>;
    status: GlossaryStatus;
    usageRestrictions?: GlossaryUsageRestriction[];
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    additionalAttributes?: GlossaryItemAdditionalAttributes;
}
export declare const GlossaryItem: S.Schema<GlossaryItem>;
export interface GlossaryTermItemAdditionalAttributes {
    matchRationale?: MatchRationaleItem[];
}
export declare const GlossaryTermItemAdditionalAttributes: S.Schema<GlossaryTermItemAdditionalAttributes>;
export interface GlossaryTermItem {
    domainId: string;
    glossaryId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    shortDescription?: string | redacted.Redacted<string>;
    usageRestrictions?: GlossaryUsageRestriction[];
    longDescription?: string | redacted.Redacted<string>;
    termRelations?: TermRelations;
    status: GlossaryTermStatus;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    additionalAttributes?: GlossaryTermItemAdditionalAttributes;
}
export declare const GlossaryTermItem: S.Schema<GlossaryTermItem>;
export interface AssetItemAdditionalAttributes {
    formsOutput?: FormOutput[];
    readOnlyFormsOutput?: FormOutput[];
    latestTimeSeriesDataPointFormsOutput?: TimeSeriesDataPointSummaryFormOutput[];
    matchRationale?: MatchRationaleItem[];
}
export declare const AssetItemAdditionalAttributes: S.Schema<AssetItemAdditionalAttributes>;
export interface AssetItem {
    domainId: string;
    identifier: string;
    name: string | redacted.Redacted<string>;
    typeIdentifier: string;
    typeRevision: string;
    externalIdentifier?: string;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    createdBy?: string;
    firstRevisionCreatedAt?: Date;
    firstRevisionCreatedBy?: string;
    glossaryTerms?: string[];
    owningProjectId: string;
    additionalAttributes?: AssetItemAdditionalAttributes;
    governedGlossaryTerms?: string[];
}
export declare const AssetItem: S.Schema<AssetItem>;
export interface DataProductItemAdditionalAttributes {
    matchRationale?: MatchRationaleItem[];
}
export declare const DataProductItemAdditionalAttributes: S.Schema<DataProductItemAdditionalAttributes>;
export interface DataProductResultItem {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    description?: string | redacted.Redacted<string>;
    glossaryTerms?: string[];
    createdAt?: Date;
    createdBy?: string;
    firstRevisionCreatedAt?: Date;
    firstRevisionCreatedBy?: string;
    additionalAttributes?: DataProductItemAdditionalAttributes;
}
export declare const DataProductResultItem: S.Schema<DataProductResultItem>;
export type SearchInventoryResultItem = {
    glossaryItem: GlossaryItem;
    glossaryTermItem?: never;
    assetItem?: never;
    dataProductItem?: never;
} | {
    glossaryItem?: never;
    glossaryTermItem: GlossaryTermItem;
    assetItem?: never;
    dataProductItem?: never;
} | {
    glossaryItem?: never;
    glossaryTermItem?: never;
    assetItem: AssetItem;
    dataProductItem?: never;
} | {
    glossaryItem?: never;
    glossaryTermItem?: never;
    assetItem?: never;
    dataProductItem: DataProductResultItem;
};
export declare const SearchInventoryResultItem: any;
export type SearchInventoryResultItems = SearchInventoryResultItem[];
export declare const SearchInventoryResultItems: any;
export interface SearchOutput {
    items?: SearchInventoryResultItem[];
    nextToken?: string;
    totalMatchCount?: number;
}
export declare const SearchOutput: S.Schema<SearchOutput>;
export type GroupSearchType = "SSO_GROUP" | "DATAZONE_SSO_GROUP" | "IAM_ROLE_SESSION_GROUP" | (string & {});
export declare const GroupSearchType: any;
export type GroupSearchText = string | redacted.Redacted<string>;
export interface SearchGroupProfilesInput {
    domainIdentifier: string;
    groupType: GroupSearchType;
    searchText?: string | redacted.Redacted<string>;
    maxResults?: number;
    nextToken?: string;
}
export declare const SearchGroupProfilesInput: S.Schema<SearchGroupProfilesInput>;
export interface GroupProfileSummary {
    domainId?: string;
    id?: string;
    status?: GroupProfileStatus;
    groupName?: string | redacted.Redacted<string>;
    rolePrincipalArn?: string;
    rolePrincipalId?: string;
}
export declare const GroupProfileSummary: S.Schema<GroupProfileSummary>;
export type GroupProfileSummaries = GroupProfileSummary[];
export declare const GroupProfileSummaries: any;
export interface SearchGroupProfilesOutput {
    items?: GroupProfileSummary[];
    nextToken?: string;
}
export declare const SearchGroupProfilesOutput: S.Schema<SearchGroupProfilesOutput>;
export type AggregationDisplayValue = string;
export interface AggregationListItem {
    attribute: string;
    displayValue?: string;
}
export declare const AggregationListItem: S.Schema<AggregationListItem>;
export type AggregationList = AggregationListItem[];
export declare const AggregationList: any;
export interface SearchListingsInput {
    domainIdentifier: string;
    searchText?: string;
    searchIn?: SearchInItem[];
    maxResults?: number;
    nextToken?: string;
    filters?: FilterClause;
    aggregations?: AggregationListItem[];
    sort?: SearchSort;
    additionalAttributes?: SearchOutputAdditionalAttribute[];
}
export declare const SearchListingsInput: S.Schema<SearchListingsInput>;
export interface AssetListingItemAdditionalAttributes {
    forms?: string;
    matchRationale?: MatchRationaleItem[];
    latestTimeSeriesDataPointForms?: TimeSeriesDataPointSummaryFormOutput[];
}
export declare const AssetListingItemAdditionalAttributes: S.Schema<AssetListingItemAdditionalAttributes>;
export interface AssetListingItem {
    listingId?: string;
    listingRevision?: string;
    name?: string | redacted.Redacted<string>;
    entityId?: string;
    entityRevision?: string;
    entityType?: string;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    listingCreatedBy?: string;
    listingUpdatedBy?: string;
    glossaryTerms?: DetailedGlossaryTerm[];
    governedGlossaryTerms?: DetailedGlossaryTerm[];
    owningProjectId?: string;
    additionalAttributes?: AssetListingItemAdditionalAttributes;
}
export declare const AssetListingItem: S.Schema<AssetListingItem>;
export interface DataProductListingItemAdditionalAttributes {
    forms?: string;
    matchRationale?: MatchRationaleItem[];
}
export declare const DataProductListingItemAdditionalAttributes: S.Schema<DataProductListingItemAdditionalAttributes>;
export interface ListingSummaryItem {
    listingId?: string;
    listingRevision?: string;
    glossaryTerms?: DetailedGlossaryTerm[];
}
export declare const ListingSummaryItem: S.Schema<ListingSummaryItem>;
export type ListingSummaryItems = ListingSummaryItem[];
export declare const ListingSummaryItems: any;
export interface DataProductListingItem {
    listingId?: string;
    listingRevision?: string;
    name?: string | redacted.Redacted<string>;
    entityId?: string;
    entityRevision?: string;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    listingCreatedBy?: string;
    listingUpdatedBy?: string;
    glossaryTerms?: DetailedGlossaryTerm[];
    owningProjectId?: string;
    additionalAttributes?: DataProductListingItemAdditionalAttributes;
    items?: ListingSummaryItem[];
}
export declare const DataProductListingItem: S.Schema<DataProductListingItem>;
export type SearchResultItem = {
    assetListing: AssetListingItem;
    dataProductListing?: never;
} | {
    assetListing?: never;
    dataProductListing: DataProductListingItem;
};
export declare const SearchResultItem: any;
export type SearchResultItems = SearchResultItem[];
export declare const SearchResultItems: any;
export type AggregationAttributeValue = string;
export type AggregationAttributeDisplayValue = string;
export interface AggregationOutputItem {
    value?: string;
    count?: number;
    displayValue?: string;
}
export declare const AggregationOutputItem: S.Schema<AggregationOutputItem>;
export type AggregationOutputItems = AggregationOutputItem[];
export declare const AggregationOutputItems: any;
export interface AggregationOutput {
    attribute?: string;
    displayValue?: string;
    items?: AggregationOutputItem[];
}
export declare const AggregationOutput: S.Schema<AggregationOutput>;
export type AggregationOutputList = AggregationOutput[];
export declare const AggregationOutputList: any;
export interface SearchListingsOutput {
    items?: SearchResultItem[];
    nextToken?: string;
    totalMatchCount?: number;
    aggregates?: AggregationOutput[];
}
export declare const SearchListingsOutput: S.Schema<SearchListingsOutput>;
export type TypesSearchScope = "ASSET_TYPE" | "FORM_TYPE" | "LINEAGE_NODE_TYPE" | (string & {});
export declare const TypesSearchScope: any;
export interface SearchTypesInput {
    domainIdentifier: string;
    maxResults?: number;
    nextToken?: string;
    searchScope: TypesSearchScope;
    searchText?: string;
    searchIn?: SearchInItem[];
    filters?: FilterClause;
    sort?: SearchSort;
    managed: boolean;
}
export declare const SearchTypesInput: S.Schema<SearchTypesInput>;
export interface AssetTypeItem {
    domainId: string;
    name: string;
    revision: string;
    description?: string | redacted.Redacted<string>;
    formsOutput: {
        [key: string]: FormEntryOutput | undefined;
    };
    owningProjectId: string;
    originDomainId?: string;
    originProjectId?: string;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
}
export declare const AssetTypeItem: S.Schema<AssetTypeItem>;
export interface FormTypeData {
    domainId: string;
    name: string | redacted.Redacted<string>;
    revision: string;
    model?: Model;
    status?: FormTypeStatus;
    owningProjectId?: string;
    originDomainId?: string;
    originProjectId?: string;
    createdAt?: Date;
    createdBy?: string;
    description?: string | redacted.Redacted<string>;
    imports?: Import[];
}
export declare const FormTypeData: S.Schema<FormTypeData>;
export interface LineageNodeTypeItem {
    domainId: string;
    name?: string;
    description?: string;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    revision: string;
    formsOutput: {
        [key: string]: FormEntryOutput | undefined;
    };
}
export declare const LineageNodeTypeItem: S.Schema<LineageNodeTypeItem>;
export type SearchTypesResultItem = {
    assetTypeItem: AssetTypeItem;
    formTypeItem?: never;
    lineageNodeTypeItem?: never;
} | {
    assetTypeItem?: never;
    formTypeItem: FormTypeData;
    lineageNodeTypeItem?: never;
} | {
    assetTypeItem?: never;
    formTypeItem?: never;
    lineageNodeTypeItem: LineageNodeTypeItem;
};
export declare const SearchTypesResultItem: any;
export type SearchTypesResultItems = SearchTypesResultItem[];
export declare const SearchTypesResultItems: any;
export interface SearchTypesOutput {
    items?: SearchTypesResultItem[];
    nextToken?: string;
    totalMatchCount?: number;
}
export declare const SearchTypesOutput: S.Schema<SearchTypesOutput>;
export type UserSearchType = "SSO_USER" | "DATAZONE_USER" | "DATAZONE_SSO_USER" | "DATAZONE_IAM_USER" | (string & {});
export declare const UserSearchType: any;
export type UserSearchText = string | redacted.Redacted<string>;
export interface SearchUserProfilesInput {
    domainIdentifier: string;
    userType: UserSearchType;
    searchText?: string | redacted.Redacted<string>;
    maxResults?: number;
    nextToken?: string;
}
export declare const SearchUserProfilesInput: S.Schema<SearchUserProfilesInput>;
export interface UserProfileSummary {
    domainId?: string;
    id?: string;
    type?: UserProfileType;
    status?: UserProfileStatus;
    details?: UserProfileDetails;
}
export declare const UserProfileSummary: S.Schema<UserProfileSummary>;
export type UserProfileSummaries = UserProfileSummary[];
export declare const UserProfileSummaries: any;
export interface SearchUserProfilesOutput {
    items?: UserProfileSummary[];
    nextToken?: string;
}
export declare const SearchUserProfilesOutput: S.Schema<SearchUserProfilesOutput>;
export interface StartDataSourceRunInput {
    domainIdentifier: string;
    dataSourceIdentifier: string;
    clientToken?: string;
}
export declare const StartDataSourceRunInput: S.Schema<StartDataSourceRunInput>;
export interface StartDataSourceRunOutput {
    domainId: string;
    dataSourceId: string;
    id: string;
    projectId: string;
    status: DataSourceRunStatus;
    type: DataSourceRunType;
    dataSourceConfigurationSnapshot?: string;
    runStatisticsForAssets?: RunStatisticsForAssets;
    errorMessage?: DataSourceErrorMessage;
    createdAt: Date;
    updatedAt: Date;
    startedAt?: Date;
    stoppedAt?: Date;
}
export declare const StartDataSourceRunOutput: S.Schema<StartDataSourceRunOutput>;
export interface StartMetadataGenerationRunInput {
    domainIdentifier: string;
    type?: MetadataGenerationRunType;
    types?: MetadataGenerationRunType[];
    target: MetadataGenerationRunTarget;
    clientToken?: string;
    owningProjectIdentifier: string;
}
export declare const StartMetadataGenerationRunInput: S.Schema<StartMetadataGenerationRunInput>;
export interface StartMetadataGenerationRunOutput {
    domainId: string;
    id: string;
    status?: MetadataGenerationRunStatus;
    type?: MetadataGenerationRunType;
    types?: MetadataGenerationRunType[];
    createdAt?: Date;
    createdBy?: string;
    owningProjectId?: string;
}
export declare const StartMetadataGenerationRunOutput: S.Schema<StartMetadataGenerationRunOutput>;
export interface StartNotebookExportInput {
    domainIdentifier: string;
    notebookIdentifier: string;
    owningProjectIdentifier: string;
    fileFormat: FileFormat;
    clientToken?: string;
}
export declare const StartNotebookExportInput: S.Schema<StartNotebookExportInput>;
export interface StartNotebookExportOutput {
    id: string;
    domainId: string;
    owningProjectId: string;
    notebookId: string;
    fileFormat: FileFormat;
    status: NotebookExportStatus;
    createdAt?: Date;
    createdBy?: string;
}
export declare const StartNotebookExportOutput: S.Schema<StartNotebookExportOutput>;
export type S3SourceLocation = string | redacted.Redacted<string>;
export type SourceLocation = {
    s3: string | redacted.Redacted<string>;
};
export declare const SourceLocation: any;
export interface StartNotebookImportInput {
    domainIdentifier: string;
    owningProjectIdentifier: string;
    sourceLocation: SourceLocation;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    clientToken?: string;
}
export declare const StartNotebookImportInput: S.Schema<StartNotebookImportInput>;
export interface StartNotebookImportOutput {
    notebookId?: string;
    status?: NotebookStatus;
    domainId?: string;
    owningProjectId?: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    sourceLocation?: SourceLocation;
    createdAt?: Date;
    createdBy?: string;
}
export declare const StartNotebookImportOutput: S.Schema<StartNotebookImportOutput>;
export interface StartNotebookRunInput {
    domainIdentifier: string;
    owningProjectIdentifier: string;
    notebookIdentifier: string;
    scheduleIdentifier?: string;
    computeConfiguration?: ComputeConfig;
    networkConfiguration?: NetworkConfig;
    timeoutConfiguration?: TimeoutConfig;
    triggerSource?: TriggerSource;
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    parameters?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const StartNotebookRunInput: S.Schema<StartNotebookRunInput>;
export interface StartNotebookRunOutput {
    id: string;
    domainId: string;
    owningProjectId: string;
    notebookId: string;
    scheduleId?: string;
    status: NotebookRunStatus;
    cellOrder?: CellInformation[];
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    parameters?: {
        [key: string]: string | undefined;
    };
    computeConfiguration?: ComputeConfig;
    networkConfiguration?: NetworkConfig;
    timeoutConfiguration?: TimeoutConfig;
    environmentConfiguration?: EnvironmentConfig;
    storageConfiguration?: StorageConfig;
    triggerSource?: TriggerSource;
    error?: NotebookRunError;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    startedAt?: Date;
    completedAt?: Date;
}
export declare const StartNotebookRunOutput: S.Schema<StartNotebookRunOutput>;
export interface StartNotebookSyncInput {
    domainIdentifier: string;
    owningProjectIdentifier: string;
    sourceLocation: SourceLocation;
    gitMetadata?: GitMetadata;
    notebookId?: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    clientToken?: string;
}
export declare const StartNotebookSyncInput: S.Schema<StartNotebookSyncInput>;
export interface StartNotebookSyncOutput {
    notebookId?: string;
    status?: NotebookStatus;
    domainId?: string;
    owningProjectId?: string;
    sourceLocation?: SourceLocation;
    gitMetadata?: GitMetadata;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    createdBy?: string;
}
export declare const StartNotebookSyncOutput: S.Schema<StartNotebookSyncOutput>;
export interface StopNotebookRunInput {
    domainIdentifier: string;
    identifier: string;
    clientToken?: string;
}
export declare const StopNotebookRunInput: S.Schema<StopNotebookRunInput>;
export interface StopNotebookRunOutput {
    id: string;
    domainId: string;
    owningProjectId: string;
    status: NotebookRunStatus;
}
export declare const StopNotebookRunOutput: S.Schema<StopNotebookRunOutput>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAccountPoolInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    resolutionStrategy?: ResolutionStrategy;
    accountSource?: AccountSource;
}
export declare const UpdateAccountPoolInput: S.Schema<UpdateAccountPoolInput>;
export interface UpdateAccountPoolOutput {
    domainId?: string;
    name?: string | redacted.Redacted<string>;
    id?: string;
    description?: string | redacted.Redacted<string>;
    resolutionStrategy?: ResolutionStrategy;
    accountSource: AccountSource;
    createdBy: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    updatedBy?: string;
    domainUnitId?: string;
}
export declare const UpdateAccountPoolOutput: S.Schema<UpdateAccountPoolOutput>;
export interface UpdateAssetFilterInput {
    domainIdentifier: string;
    assetIdentifier: string;
    identifier: string;
    name?: string;
    description?: string | redacted.Redacted<string>;
    configuration?: AssetFilterConfiguration;
}
export declare const UpdateAssetFilterInput: S.Schema<UpdateAssetFilterInput>;
export interface UpdateAssetFilterOutput {
    id: string;
    domainId: string;
    assetId: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    status?: FilterStatus;
    configuration: AssetFilterConfiguration;
    createdAt?: Date;
    errorMessage?: string;
    effectiveColumnNames?: string[];
    effectiveRowFilter?: string;
}
export declare const UpdateAssetFilterOutput: S.Schema<UpdateAssetFilterOutput>;
export interface AthenaPropertiesPatch {
    workgroupName?: string;
}
export declare const AthenaPropertiesPatch: S.Schema<AthenaPropertiesPatch>;
export interface AuthenticationConfigurationPatch {
    secretArn?: string;
    basicAuthenticationCredentials?: BasicAuthenticationCredentials;
}
export declare const AuthenticationConfigurationPatch: S.Schema<AuthenticationConfigurationPatch>;
export interface GlueConnectionPatch {
    description?: string;
    connectionProperties?: {
        [key: string]: string | undefined;
    };
    authenticationConfiguration?: AuthenticationConfigurationPatch;
}
export declare const GlueConnectionPatch: S.Schema<GlueConnectionPatch>;
export interface GluePropertiesPatch {
    glueConnectionInput?: GlueConnectionPatch;
}
export declare const GluePropertiesPatch: S.Schema<GluePropertiesPatch>;
export interface IamPropertiesPatch {
    glueLineageSyncEnabled?: boolean;
}
export declare const IamPropertiesPatch: S.Schema<IamPropertiesPatch>;
export interface RedshiftPropertiesPatch {
    storage?: RedshiftStorageProperties;
    databaseName?: string;
    host?: string;
    port?: number;
    credentials?: RedshiftCredentials;
    lineageSync?: RedshiftLineageSyncConfigurationInput;
}
export declare const RedshiftPropertiesPatch: S.Schema<RedshiftPropertiesPatch>;
export interface SparkEmrPropertiesPatch {
    computeArn?: string;
    instanceProfileArn?: string;
    javaVirtualEnv?: string;
    logUri?: string;
    pythonVirtualEnv?: string;
    runtimeRole?: string;
    trustedCertificatesS3Uri?: string;
    managedEndpointArn?: string;
}
export declare const SparkEmrPropertiesPatch: S.Schema<SparkEmrPropertiesPatch>;
export interface S3PropertiesPatch {
    s3Uri: string;
    s3AccessGrantLocationId?: string;
    registerS3AccessGrantLocation?: boolean;
}
export declare const S3PropertiesPatch: S.Schema<S3PropertiesPatch>;
export interface ConnectivityPropertiesPatch {
    description?: string;
    connectionProperties?: {
        [key: string]: string | undefined;
    };
    authenticationConfiguration?: AuthenticationConfigurationPatch;
}
export declare const ConnectivityPropertiesPatch: S.Schema<ConnectivityPropertiesPatch>;
export interface SnowflakePropertiesPatch {
    connectivityPropertiesPatch?: ConnectivityPropertiesPatch;
    snowflakeRole?: string;
    lineageSync?: LineageSyncInput;
}
export declare const SnowflakePropertiesPatch: S.Schema<SnowflakePropertiesPatch>;
export interface AmazonQPropertiesPatch {
    isEnabled: boolean;
    profileArn?: string;
    authMode?: string;
}
export declare const AmazonQPropertiesPatch: S.Schema<AmazonQPropertiesPatch>;
export interface MlflowPropertiesPatch {
    trackingServerArn?: string;
}
export declare const MlflowPropertiesPatch: S.Schema<MlflowPropertiesPatch>;
export interface LakehousePropertiesPatch {
    glueLineageSyncEnabled?: boolean;
}
export declare const LakehousePropertiesPatch: S.Schema<LakehousePropertiesPatch>;
export interface VpcPropertiesPatch {
    vpcId?: string;
    subnetIds?: string[];
    securityGroupId?: string;
}
export declare const VpcPropertiesPatch: S.Schema<VpcPropertiesPatch>;
export interface GitPropertiesPatch {
    codeConnectionArn?: string;
    defaultBranch?: string;
}
export declare const GitPropertiesPatch: S.Schema<GitPropertiesPatch>;
export type ConnectionPropertiesPatch = {
    athenaProperties: AthenaPropertiesPatch;
    glueProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties: GluePropertiesPatch;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    iamProperties: IamPropertiesPatch;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    iamProperties?: never;
    redshiftProperties: RedshiftPropertiesPatch;
    sparkEmrProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties: SparkEmrPropertiesPatch;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    s3Properties: S3PropertiesPatch;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    s3Properties?: never;
    snowflakeProperties: SnowflakePropertiesPatch;
    amazonQProperties?: never;
    mlflowProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties: AmazonQPropertiesPatch;
    mlflowProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties: MlflowPropertiesPatch;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    lakehouseProperties: LakehousePropertiesPatch;
    vpcProperties?: never;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    lakehouseProperties?: never;
    vpcProperties: VpcPropertiesPatch;
    gitProperties?: never;
} | {
    athenaProperties?: never;
    glueProperties?: never;
    iamProperties?: never;
    redshiftProperties?: never;
    sparkEmrProperties?: never;
    s3Properties?: never;
    snowflakeProperties?: never;
    amazonQProperties?: never;
    mlflowProperties?: never;
    lakehouseProperties?: never;
    vpcProperties?: never;
    gitProperties: GitPropertiesPatch;
};
export declare const ConnectionPropertiesPatch: any;
export interface UpdateConnectionInput {
    configurations?: Configuration[];
    domainIdentifier: string;
    identifier: string;
    description?: string | redacted.Redacted<string>;
    awsLocation?: AwsLocation;
    props?: ConnectionPropertiesPatch;
}
export declare const UpdateConnectionInput: S.Schema<UpdateConnectionInput>;
export interface UpdateConnectionOutput {
    configurations?: Configuration[];
    connectionId: string;
    description?: string | redacted.Redacted<string>;
    domainId: string;
    domainUnitId: string;
    environmentId?: string;
    name: string;
    physicalEndpoints: PhysicalEndpoint[];
    projectId?: string;
    props?: ConnectionPropertiesOutput;
    type: ConnectionType;
    scope?: ConnectionScope;
}
export declare const UpdateConnectionOutput: S.Schema<UpdateConnectionOutput>;
export interface UpdateDataSourceInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    enableSetting?: EnableSetting;
    publishOnImport?: boolean;
    assetFormsInput?: FormInput[];
    schedule?: ScheduleConfiguration;
    configuration?: DataSourceConfigurationInput;
    recommendation?: RecommendationConfiguration;
    retainPermissionsOnRevokeFailure?: boolean;
}
export declare const UpdateDataSourceInput: S.Schema<UpdateDataSourceInput>;
export interface UpdateDataSourceOutput {
    id: string;
    status?: DataSourceStatus;
    type?: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    domainId: string;
    projectId: string;
    environmentId?: string;
    connectionId?: string;
    configuration?: DataSourceConfigurationOutput;
    recommendation?: RecommendationConfiguration;
    enableSetting?: EnableSetting;
    publishOnImport?: boolean;
    assetFormsOutput?: FormOutput[];
    schedule?: ScheduleConfiguration;
    lastRunStatus?: DataSourceRunStatus;
    lastRunAt?: Date;
    lastRunErrorMessage?: DataSourceErrorMessage;
    errorMessage?: DataSourceErrorMessage;
    createdAt?: Date;
    updatedAt?: Date;
    selfGrantStatus?: SelfGrantStatusOutput;
    retainPermissionsOnRevokeFailure?: boolean;
}
export declare const UpdateDataSourceOutput: S.Schema<UpdateDataSourceOutput>;
export interface UpdateDomainInput {
    identifier: string;
    description?: string;
    singleSignOn?: SingleSignOn;
    domainExecutionRole?: string;
    serviceRole?: string;
    name?: string;
    clientToken?: string;
}
export declare const UpdateDomainInput: S.Schema<UpdateDomainInput>;
export interface UpdateDomainOutput {
    id: string;
    rootDomainUnitId?: string;
    description?: string;
    singleSignOn?: SingleSignOn;
    domainExecutionRole?: string;
    serviceRole?: string;
    name?: string;
    lastUpdatedAt?: Date;
}
export declare const UpdateDomainOutput: S.Schema<UpdateDomainOutput>;
export interface UpdateDomainUnitInput {
    domainIdentifier: string;
    identifier: string;
    description?: string | redacted.Redacted<string>;
    name?: string | redacted.Redacted<string>;
}
export declare const UpdateDomainUnitInput: S.Schema<UpdateDomainUnitInput>;
export interface UpdateDomainUnitOutput {
    id: string;
    domainId: string;
    name: string | redacted.Redacted<string>;
    owners: DomainUnitOwnerProperties[];
    description?: string | redacted.Redacted<string>;
    parentDomainUnitId?: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    createdBy?: string;
    lastUpdatedBy?: string;
}
export declare const UpdateDomainUnitOutput: S.Schema<UpdateDomainUnitOutput>;
export interface UpdateEnvironmentInput {
    domainIdentifier: string;
    identifier: string;
    name?: string;
    description?: string;
    glossaryTerms?: string[];
    blueprintVersion?: string;
    userParameters?: EnvironmentParameter[];
    environmentConfigurationName?: string | redacted.Redacted<string>;
}
export declare const UpdateEnvironmentInput: S.Schema<UpdateEnvironmentInput>;
export interface UpdateEnvironmentOutput {
    projectId: string;
    id?: string;
    domainId: string;
    createdBy: string;
    createdAt?: Date;
    updatedAt?: Date;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    environmentProfileId?: string;
    awsAccountId?: string;
    awsAccountRegion?: string;
    provider: string;
    provisionedResources?: Resource[];
    status?: EnvironmentStatus;
    environmentActions?: ConfigurableEnvironmentAction[];
    glossaryTerms?: string[];
    userParameters?: CustomParameter[];
    lastDeployment?: Deployment;
    provisioningProperties?: ProvisioningProperties;
    deploymentProperties?: DeploymentProperties;
    environmentBlueprintId?: string;
    environmentConfigurationId?: string | redacted.Redacted<string>;
    environmentConfigurationName?: string | redacted.Redacted<string>;
}
export declare const UpdateEnvironmentOutput: S.Schema<UpdateEnvironmentOutput>;
export interface UpdateEnvironmentActionInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    identifier: string;
    parameters?: ActionParameters;
    name?: string;
    description?: string;
}
export declare const UpdateEnvironmentActionInput: S.Schema<UpdateEnvironmentActionInput>;
export interface UpdateEnvironmentActionOutput {
    domainId: string;
    environmentId: string;
    id: string;
    name: string;
    parameters: ActionParameters;
    description?: string;
}
export declare const UpdateEnvironmentActionOutput: S.Schema<UpdateEnvironmentActionOutput>;
export interface UpdateEnvironmentBlueprintInput {
    domainIdentifier: string;
    identifier: string;
    description?: string;
    provisioningProperties?: ProvisioningProperties;
    userParameters?: CustomParameter[];
}
export declare const UpdateEnvironmentBlueprintInput: S.Schema<UpdateEnvironmentBlueprintInput>;
export interface UpdateEnvironmentBlueprintOutput {
    id: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    provider: string;
    provisioningProperties: ProvisioningProperties;
    deploymentProperties?: DeploymentProperties;
    userParameters?: CustomParameter[];
    glossaryTerms?: string[];
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const UpdateEnvironmentBlueprintOutput: S.Schema<UpdateEnvironmentBlueprintOutput>;
export interface UpdateEnvironmentProfileInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string>;
    description?: string;
    userParameters?: EnvironmentParameter[];
    awsAccountId?: string;
    awsAccountRegion?: string;
}
export declare const UpdateEnvironmentProfileInput: S.Schema<UpdateEnvironmentProfileInput>;
export interface UpdateEnvironmentProfileOutput {
    id: string;
    domainId: string;
    awsAccountId?: string;
    awsAccountRegion?: string;
    createdBy: string;
    createdAt?: Date;
    updatedAt?: Date;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    environmentBlueprintId: string;
    projectId?: string;
    userParameters?: CustomParameter[];
}
export declare const UpdateEnvironmentProfileOutput: S.Schema<UpdateEnvironmentProfileOutput>;
export interface UpdateGlossaryInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    status?: GlossaryStatus;
    clientToken?: string;
}
export declare const UpdateGlossaryInput: S.Schema<UpdateGlossaryInput>;
export interface UpdateGlossaryOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    description?: string | redacted.Redacted<string>;
    status?: GlossaryStatus;
    usageRestrictions?: GlossaryUsageRestriction[];
}
export declare const UpdateGlossaryOutput: S.Schema<UpdateGlossaryOutput>;
export interface UpdateGlossaryTermInput {
    domainIdentifier: string;
    glossaryIdentifier?: string;
    identifier: string;
    name?: string | redacted.Redacted<string>;
    shortDescription?: string | redacted.Redacted<string>;
    longDescription?: string | redacted.Redacted<string>;
    termRelations?: TermRelations;
    status?: GlossaryTermStatus;
}
export declare const UpdateGlossaryTermInput: S.Schema<UpdateGlossaryTermInput>;
export interface UpdateGlossaryTermOutput {
    id: string;
    domainId: string;
    glossaryId: string;
    name: string | redacted.Redacted<string>;
    status: GlossaryTermStatus;
    shortDescription?: string | redacted.Redacted<string>;
    longDescription?: string | redacted.Redacted<string>;
    termRelations?: TermRelations;
    usageRestrictions?: GlossaryUsageRestriction[];
}
export declare const UpdateGlossaryTermOutput: S.Schema<UpdateGlossaryTermOutput>;
export interface UpdateGroupProfileInput {
    domainIdentifier: string;
    groupIdentifier: string;
    status: GroupProfileStatus;
}
export declare const UpdateGroupProfileInput: S.Schema<UpdateGroupProfileInput>;
export interface UpdateGroupProfileOutput {
    domainId?: string;
    id?: string;
    status?: GroupProfileStatus;
    groupName?: string | redacted.Redacted<string>;
    rolePrincipalArn?: string;
    rolePrincipalId?: string;
}
export declare const UpdateGroupProfileOutput: S.Schema<UpdateGroupProfileOutput>;
export interface UpdateNotebookInput {
    domainIdentifier: string;
    identifier: string;
    description?: string | redacted.Redacted<string>;
    status?: NotebookStatus;
    name?: string | redacted.Redacted<string>;
    cellOrder?: CellInformation[];
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    parameters?: {
        [key: string]: string | undefined;
    };
    environmentConfiguration?: EnvironmentConfig;
    clientToken?: string;
}
export declare const UpdateNotebookInput: S.Schema<UpdateNotebookInput>;
export interface UpdateNotebookOutput {
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    domainId: string;
    cellOrder: CellInformation[];
    status: NotebookStatus;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    lockedBy?: string;
    lockedAt?: Date;
    lockExpiresAt?: Date;
    computeId?: string;
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    parameters?: {
        [key: string]: string | undefined;
    };
    environmentConfiguration?: EnvironmentConfig;
    error?: NotebookError;
    gitMetadata?: GitMetadata;
}
export declare const UpdateNotebookOutput: S.Schema<UpdateNotebookOutput>;
export interface UpdateProjectInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    resourceTags?: {
        [key: string]: string | undefined;
    };
    glossaryTerms?: string[];
    domainUnitId?: string;
    environmentDeploymentDetails?: EnvironmentDeploymentDetails;
    userParameters?: EnvironmentConfigurationUserParameter[];
    projectProfileVersion?: string;
}
export declare const UpdateProjectInput: S.Schema<UpdateProjectInput>;
export interface UpdateProjectOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    projectStatus?: ProjectStatus;
    failureReasons?: ProjectDeletionError[];
    createdBy: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    resourceTags?: ResourceTag[];
    glossaryTerms?: string[];
    domainUnitId?: string;
    projectProfileId?: string;
    userParameters?: EnvironmentConfigurationUserParameter[];
    environmentDeploymentDetails?: EnvironmentDeploymentDetails;
    projectCategory?: string;
}
export declare const UpdateProjectOutput: S.Schema<UpdateProjectOutput>;
export interface UpdateProjectProfileInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    status?: Status;
    projectResourceTags?: ResourceTagParameter[];
    allowCustomProjectResourceTags?: boolean;
    projectResourceTagsDescription?: string | redacted.Redacted<string>;
    environmentConfigurations?: EnvironmentConfiguration[];
    domainUnitIdentifier?: string;
}
export declare const UpdateProjectProfileInput: S.Schema<UpdateProjectProfileInput>;
export interface UpdateProjectProfileOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    status?: Status;
    projectResourceTags?: ResourceTagParameter[];
    allowCustomProjectResourceTags?: boolean;
    projectResourceTagsDescription?: string | redacted.Redacted<string>;
    environmentConfigurations?: EnvironmentConfiguration[];
    createdBy: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    domainUnitId?: string;
}
export declare const UpdateProjectProfileOutput: S.Schema<UpdateProjectProfileOutput>;
export interface UpdateRootDomainUnitOwnerInput {
    domainIdentifier: string;
    currentOwner: string;
    newOwner: string;
    clientToken?: string;
}
export declare const UpdateRootDomainUnitOwnerInput: S.Schema<UpdateRootDomainUnitOwnerInput>;
export interface UpdateRootDomainUnitOwnerOutput {
}
export declare const UpdateRootDomainUnitOwnerOutput: S.Schema<UpdateRootDomainUnitOwnerOutput>;
export interface UpdateRuleInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    scope?: RuleScope;
    detail?: RuleDetail;
    includeChildDomainUnits?: boolean;
}
export declare const UpdateRuleInput: S.Schema<UpdateRuleInput>;
export interface UpdateRuleOutput {
    identifier: string;
    revision: string;
    name: string | redacted.Redacted<string>;
    ruleType: RuleType;
    target: RuleTarget;
    action: RuleAction;
    scope: RuleScope;
    detail: RuleDetail;
    description?: string | redacted.Redacted<string>;
    createdAt: Date;
    updatedAt: Date;
    createdBy: string;
    lastUpdatedBy: string;
}
export declare const UpdateRuleOutput: S.Schema<UpdateRuleOutput>;
export interface UpdateSubscriptionGrantStatusInput {
    domainIdentifier: string;
    identifier: string;
    assetIdentifier: string;
    status: SubscriptionGrantStatus;
    failureCause?: FailureCause;
    targetName?: string;
}
export declare const UpdateSubscriptionGrantStatusInput: S.Schema<UpdateSubscriptionGrantStatusInput>;
export interface UpdateSubscriptionGrantStatusOutput {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    createdAt: Date;
    updatedAt: Date;
    environmentId?: string;
    subscriptionTargetId: string;
    grantedEntity: GrantedEntity;
    status: SubscriptionGrantOverallStatus;
    assets?: SubscribedAsset[];
    subscriptionId?: string;
}
export declare const UpdateSubscriptionGrantStatusOutput: S.Schema<UpdateSubscriptionGrantStatusOutput>;
export interface UpdateSubscriptionRequestInput {
    domainIdentifier: string;
    identifier: string;
    requestReason: string | redacted.Redacted<string>;
}
export declare const UpdateSubscriptionRequestInput: S.Schema<UpdateSubscriptionRequestInput>;
export interface UpdateSubscriptionRequestOutput {
    id: string;
    createdBy: string;
    updatedBy?: string;
    domainId: string;
    status: SubscriptionRequestStatus;
    createdAt: Date;
    updatedAt: Date;
    requestReason: string | redacted.Redacted<string>;
    subscribedPrincipals: SubscribedPrincipal[];
    subscribedListings: SubscribedListing[];
    reviewerId?: string;
    decisionComment?: string | redacted.Redacted<string>;
    existingSubscriptionId?: string;
    metadataForms?: FormOutput[];
}
export declare const UpdateSubscriptionRequestOutput: S.Schema<UpdateSubscriptionRequestOutput>;
export interface UpdateSubscriptionTargetInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string>;
    authorizedPrincipals?: string[];
    applicableAssetTypes?: string[];
    subscriptionTargetConfig?: SubscriptionTargetForm[];
    manageAccessRole?: string;
    provider?: string;
    subscriptionGrantCreationMode?: SubscriptionGrantCreationMode;
}
export declare const UpdateSubscriptionTargetInput: S.Schema<UpdateSubscriptionTargetInput>;
export interface UpdateSubscriptionTargetOutput {
    id: string;
    authorizedPrincipals: string[];
    domainId: string;
    projectId: string;
    environmentId: string;
    name: string | redacted.Redacted<string>;
    type: string;
    createdBy: string;
    updatedBy?: string;
    createdAt: Date;
    updatedAt?: Date;
    manageAccessRole?: string;
    applicableAssetTypes: string[];
    subscriptionTargetConfig: SubscriptionTargetForm[];
    provider: string;
    subscriptionGrantCreationMode?: SubscriptionGrantCreationMode;
}
export declare const UpdateSubscriptionTargetOutput: S.Schema<UpdateSubscriptionTargetOutput>;
export interface UpdateUserProfileInput {
    domainIdentifier: string;
    userIdentifier: string;
    type?: UserProfileType;
    status: UserProfileStatus;
    sessionName?: string;
}
export declare const UpdateUserProfileInput: S.Schema<UpdateUserProfileInput>;
export interface UpdateUserProfileOutput {
    domainId?: string;
    id?: string;
    type?: UserProfileType;
    status?: UserProfileStatus;
    details?: UserProfileDetails;
}
export declare const UpdateUserProfileOutput: S.Schema<UpdateUserProfileOutput>;
export type ErrorMessage = string;
export type AcceptPredictionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Accepts automatically generated business-friendly metadata for your Amazon DataZone assets.
 */
export declare const acceptPredictions: API.OperationMethod<AcceptPredictionsInput, AcceptPredictionsOutput, AcceptPredictionsError, Credentials | HttpClient.HttpClient>;
export type AcceptSubscriptionRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Accepts a subscription request to a specific asset.
 */
export declare const acceptSubscriptionRequest: API.OperationMethod<AcceptSubscriptionRequestInput, AcceptSubscriptionRequestOutput, AcceptSubscriptionRequestError, Credentials | HttpClient.HttpClient>;
export type AddEntityOwnerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds the owner of an entity (a domain unit).
 */
export declare const addEntityOwner: API.OperationMethod<AddEntityOwnerInput, AddEntityOwnerOutput, AddEntityOwnerError, Credentials | HttpClient.HttpClient>;
export type AddPolicyGrantError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a policy grant (an authorization policy) to a specified entity, including domain units, environment blueprint configurations, or environment profiles.
 */
export declare const addPolicyGrant: API.OperationMethod<AddPolicyGrantInput, AddPolicyGrantOutput, AddPolicyGrantError, Credentials | HttpClient.HttpClient>;
export type AssociateEnvironmentRoleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates the environment role in Amazon DataZone.
 */
export declare const associateEnvironmentRole: API.OperationMethod<AssociateEnvironmentRoleInput, AssociateEnvironmentRoleOutput, AssociateEnvironmentRoleError, Credentials | HttpClient.HttpClient>;
export type AssociateGovernedTermsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates governed terms with an asset.
 */
export declare const associateGovernedTerms: API.OperationMethod<AssociateGovernedTermsInput, AssociateGovernedTermsOutput, AssociateGovernedTermsError, Credentials | HttpClient.HttpClient>;
export type BatchGetAttributesMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the attribute metadata.
 */
export declare const batchGetAttributesMetadata: API.OperationMethod<BatchGetAttributesMetadataInput, BatchGetAttributesMetadataOutput, BatchGetAttributesMetadataError, Credentials | HttpClient.HttpClient>;
export type BatchPutAttributesMetadataError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Writes the attribute metadata.
 */
export declare const batchPutAttributesMetadata: API.OperationMethod<BatchPutAttributesMetadataInput, BatchPutAttributesMetadataOutput, BatchPutAttributesMetadataError, Credentials | HttpClient.HttpClient>;
export type CancelMetadataGenerationRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the metadata generation run.
 *
 * Prerequisites:
 *
 * - The run must exist and be in a cancelable status (e.g., SUBMITTED, IN_PROGRESS).
 *
 * - Runs in SUCCEEDED status cannot be cancelled.
 *
 * - User must have access to the run and cancel permissions.
 */
export declare const cancelMetadataGenerationRun: API.OperationMethod<CancelMetadataGenerationRunInput, CancelMetadataGenerationRunOutput, CancelMetadataGenerationRunError, Credentials | HttpClient.HttpClient>;
export type CancelSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the subscription to the specified asset.
 */
export declare const cancelSubscription: API.OperationMethod<CancelSubscriptionInput, CancelSubscriptionOutput, CancelSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateAccountPoolError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an account pool.
 */
export declare const createAccountPool: API.OperationMethod<CreateAccountPoolInput, CreateAccountPoolOutput, CreateAccountPoolError, Credentials | HttpClient.HttpClient>;
export type CreateAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an asset in Amazon DataZone catalog.
 *
 * Before creating assets, make sure that the following requirements are met:
 *
 * - `--domain-identifier` must refer to an existing domain.
 *
 * - `--owning-project-identifier` must be a valid project within the domain.
 *
 * - Asset type must be created beforehand using `create-asset-type`, or be a supported system-defined type. For more information, see create-asset-type.
 *
 * - `--type-revision` (if used) must match a valid revision of the asset type.
 *
 * - `formsInput` is required when it is associated as required in the `asset-type`. For more information, see create-form-type.
 *
 * - Form content must include all required fields as per the form schema (e.g., `bucketArn`).
 *
 * You must invoke the following pre-requisite commands before invoking this API:
 *
 * - CreateFormType
 *
 * - CreateAssetType
 */
export declare const createAsset: API.OperationMethod<CreateAssetInput, CreateAssetOutput, CreateAssetError, Credentials | HttpClient.HttpClient>;
export type CreateAssetFilterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a data asset filter.
 *
 * Asset filters provide a sophisticated way to create controlled views of data assets by selecting specific columns or applying row-level filters. This capability is crucial for organizations that need to share data while maintaining security and privacy controls. For example, your database might be filtered to show only non-PII fields to certain users, or sales data might be filtered by region for different regional teams. Asset filters enable fine-grained access control while maintaining a single source of truth.
 *
 * Prerequisites:
 *
 * - A valid domain (`--domain-identifier`) must exist.
 *
 * - A data asset (`--asset-identifier`) must already be created under that domain.
 *
 * - The asset must have the referenced columns available in its schema for column-based filtering.
 *
 * - You cannot specify both (`columnConfiguration`, `rowConfiguration`)at the same time.
 */
export declare const createAssetFilter: API.OperationMethod<CreateAssetFilterInput, CreateAssetFilterOutput, CreateAssetFilterError, Credentials | HttpClient.HttpClient>;
export type CreateAssetRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a revision of the asset.
 *
 * Asset revisions represent new versions of existing assets, capturing changes to either the underlying data or its metadata. They maintain a historical record of how assets evolve over time, who made changes, and when those changes occurred. This versioning capability is crucial for governance and compliance, allowing organizations to track changes, understand their impact, and roll back if necessary.
 *
 * Prerequisites:
 *
 * - Asset must already exist in the domain with identifier.
 *
 * - `formsInput` is required when asset has the form type. `typeRevision` should be the latest version of form type.
 *
 * - The form content must include all required fields (e.g., `bucketArn` for `S3ObjectCollectionForm`).
 *
 * - The owning project of the original asset must still exist and be active.
 *
 * - User must have write access to the project and domain.
 */
export declare const createAssetRevision: API.OperationMethod<CreateAssetRevisionInput, CreateAssetRevisionOutput, CreateAssetRevisionError, Credentials | HttpClient.HttpClient>;
export type CreateAssetTypeError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a custom asset type.
 *
 * Prerequisites:
 *
 * - The `formsInput` field is required, however, can be passed as empty (e.g. `-forms-input {})`.
 *
 * - You must have `CreateAssetType` permissions.
 *
 * - The domain-identifier and owning-project-identifier must be valid and active.
 *
 * - The name of the asset type must be unique within the domain — duplicate names will cause failure.
 *
 * - JSON input must be valid — incorrect formatting causes Invalid JSON errors.
 */
export declare const createAssetType: API.OperationMethod<CreateAssetTypeInput, CreateAssetTypeOutput, CreateAssetTypeError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new connection. In Amazon DataZone, a connection enables you to connect your resources (domains, projects, and environments) to external resources and services.
 */
export declare const createConnection: API.OperationMethod<CreateConnectionInput, CreateConnectionOutput, CreateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateDataProductError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a data product.
 *
 * A data product is a comprehensive package that combines data assets with their associated metadata, documentation, and access controls. It's designed to serve specific business needs or use cases, making it easier for users to find and consume data appropriately. Data products include important information about data quality, freshness, and usage guidelines, effectively bridging the gap between data producers and consumers while ensuring proper governance.
 *
 * Prerequisites:
 *
 * - The domain must exist and be accessible.
 *
 * - The owning project must be valid and active.
 *
 * - The name must be unique within the domain (no existing data product with the same name).
 *
 * - User must have create permissions for data products in the project.
 */
export declare const createDataProduct: API.OperationMethod<CreateDataProductInput, CreateDataProductOutput, CreateDataProductError, Credentials | HttpClient.HttpClient>;
export type CreateDataProductRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a data product revision.
 *
 * Prerequisites:
 *
 * - The original data product must exist in the given domain.
 *
 * - User must have permissions on the data product.
 *
 * - The domain must be valid and accessible.
 *
 * - The new revision name must comply with naming constraints (if required).
 */
export declare const createDataProductRevision: API.OperationMethod<CreateDataProductRevisionInput, CreateDataProductRevisionOutput, CreateDataProductRevisionError, Credentials | HttpClient.HttpClient>;
export type CreateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon DataZone data source.
 */
export declare const createDataSource: API.OperationMethod<CreateDataSourceInput, CreateDataSourceOutput, CreateDataSourceError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon DataZone domain.
 */
export declare const createDomain: API.OperationMethod<CreateDomainInput, CreateDomainOutput, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreateDomainUnitError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a domain unit in Amazon DataZone.
 */
export declare const createDomainUnit: API.OperationMethod<CreateDomainUnitInput, CreateDomainUnitOutput, CreateDomainUnitError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create an Amazon DataZone environment.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentInput, CreateEnvironmentOutput, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentActionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an action for the environment, for example, creates a console link for an analytics tool that is available in this environment.
 */
export declare const createEnvironmentAction: API.OperationMethod<CreateEnvironmentActionInput, CreateEnvironmentActionOutput, CreateEnvironmentActionError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentBlueprintError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Amazon DataZone blueprint.
 */
export declare const createEnvironmentBlueprint: API.OperationMethod<CreateEnvironmentBlueprintInput, CreateEnvironmentBlueprintOutput, CreateEnvironmentBlueprintError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon DataZone environment profile.
 */
export declare const createEnvironmentProfile: API.OperationMethod<CreateEnvironmentProfileInput, CreateEnvironmentProfileOutput, CreateEnvironmentProfileError, Credentials | HttpClient.HttpClient>;
export type CreateFormTypeError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a metadata form type.
 *
 * Prerequisites:
 *
 * - The domain must exist and be in an `ENABLED` state.
 *
 * - The owning project must exist and be accessible.
 *
 * - The name must be unique within the domain.
 *
 * For custom form types, to indicate that a field should be searchable, annotate it with `@amazon.datazone#searchable`. By default, searchable fields are indexed for semantic search, where related query terms will match the attribute value even if they are not stemmed or keyword matches. To indicate that a field should be indexed for lexical search (which disables semantic search but supports stemmed and partial matches), annotate it with `@amazon.datazone#searchable(modes:["LEXICAL"])`. To indicate that a field should be indexed for technical identifier search (for more information on technical identifier search, see: https://aws.amazon.com/blogs/big-data/streamline-data-discovery-with-precise-technical-identifier-search-in-amazon-sagemaker-unified-studio/), annotate it with `@amazon.datazone#searchable(modes:["TECHNICAL"])`.
 *
 * To denote that a field will store glossary term ids (which are filterable via the Search/SearchListings APIs), annotate it with `@amazon.datazone#glossaryterm("${GLOSSARY_ID}")`, where `${GLOSSARY_ID}` is the id of the glossary that the glossary terms stored in the field belong to.
 */
export declare const createFormType: API.OperationMethod<CreateFormTypeInput, CreateFormTypeOutput, CreateFormTypeError, Credentials | HttpClient.HttpClient>;
export type CreateGlossaryError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon DataZone business glossary.
 *
 * Specifies that this is a create glossary policy.
 *
 * A glossary serves as the central repository for business terminology and definitions within an organization. It helps establish and maintain a common language across different departments and teams, reducing miscommunication and ensuring consistent interpretation of business concepts. Glossaries can include hierarchical relationships between terms, cross-references, and links to actual data assets, making them invaluable for both business users and technical teams trying to understand and use data correctly.
 *
 * Prerequisites:
 *
 * - Domain must exist and be in an active state.
 *
 * - Owning project must exist and be accessible by the caller.
 *
 * - The glossary name must be unique within the domain.
 */
export declare const createGlossary: API.OperationMethod<CreateGlossaryInput, CreateGlossaryOutput, CreateGlossaryError, Credentials | HttpClient.HttpClient>;
export type CreateGlossaryTermError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a business glossary term.
 *
 * A glossary term represents an individual entry within the Amazon DataZone glossary, serving as a standardized definition for a specific business concept or data element. Each term can include rich metadata such as detailed definitions, synonyms, related terms, and usage examples. Glossary terms can be linked directly to data assets, providing business context to technical data elements. This linking capability helps users understand the business meaning of data fields and ensures consistent interpretation across different systems and teams. Terms can also have relationships with other terms, creating a semantic network that reflects the complexity of business concepts.
 *
 * Prerequisites:
 *
 * - Domain must exist.
 *
 * - Glossary must exist.
 *
 * - The term name must be unique within the glossary.
 *
 * - Ensure term does not conflict with existing terms in hierarchy.
 */
export declare const createGlossaryTerm: API.OperationMethod<CreateGlossaryTermInput, CreateGlossaryTermOutput, CreateGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type CreateGroupProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a group profile in Amazon DataZone.
 */
export declare const createGroupProfile: API.OperationMethod<CreateGroupProfileInput, CreateGroupProfileOutput, CreateGroupProfileError, Credentials | HttpClient.HttpClient>;
export type CreateListingChangeSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Publishes a listing (a record of an asset at a given time) or removes a listing from the catalog.
 */
export declare const createListingChangeSet: API.OperationMethod<CreateListingChangeSetInput, CreateListingChangeSetOutput, CreateListingChangeSetError, Credentials | HttpClient.HttpClient>;
export type CreateNotebookError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a notebook in Amazon SageMaker Unified Studio. A notebook is a collaborative document within a project that contains code cells for interactive computing.
 */
export declare const createNotebook: API.OperationMethod<CreateNotebookInput, CreateNotebookOutput, CreateNotebookError, Credentials | HttpClient.HttpClient>;
export type CreateProjectError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon DataZone project.
 */
export declare const createProject: API.OperationMethod<CreateProjectInput, CreateProjectOutput, CreateProjectError, Credentials | HttpClient.HttpClient>;
export type CreateProjectMembershipError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a project membership in Amazon DataZone.
 */
export declare const createProjectMembership: API.OperationMethod<CreateProjectMembershipInput, CreateProjectMembershipOutput, CreateProjectMembershipError, Credentials | HttpClient.HttpClient>;
export type CreateProjectProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a project profile.
 */
export declare const createProjectProfile: API.OperationMethod<CreateProjectProfileInput, CreateProjectProfileOutput, CreateProjectProfileError, Credentials | HttpClient.HttpClient>;
export type CreateRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a rule in Amazon DataZone. A rule is a formal agreement that enforces specific requirements across user workflows (e.g., publishing assets to the catalog, requesting subscriptions, creating projects) within the Amazon DataZone data portal. These rules help maintain consistency, ensure compliance, and uphold governance standards in data management processes. For instance, a metadata enforcement rule can specify the required information for creating a subscription request or publishing a data asset to the catalog, ensuring alignment with organizational standards.
 */
export declare const createRule: API.OperationMethod<CreateRuleInput, CreateRuleOutput, CreateRuleError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionGrantError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a subsscription grant in Amazon DataZone.
 */
export declare const createSubscriptionGrant: API.OperationMethod<CreateSubscriptionGrantInput, CreateSubscriptionGrantOutput, CreateSubscriptionGrantError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a subscription request in Amazon DataZone.
 */
export declare const createSubscriptionRequest: API.OperationMethod<CreateSubscriptionRequestInput, CreateSubscriptionRequestOutput, CreateSubscriptionRequestError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionTargetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a subscription target in Amazon DataZone.
 */
export declare const createSubscriptionTarget: API.OperationMethod<CreateSubscriptionTargetInput, CreateSubscriptionTargetOutput, CreateSubscriptionTargetError, Credentials | HttpClient.HttpClient>;
export type CreateUserProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a user profile in Amazon DataZone.
 */
export declare const createUserProfile: API.OperationMethod<CreateUserProfileInput, CreateUserProfileOutput, CreateUserProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountPoolError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an account pool.
 */
export declare const deleteAccountPool: API.OperationMethod<DeleteAccountPoolInput, DeleteAccountPoolOutput, DeleteAccountPoolError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an asset in Amazon DataZone.
 *
 * - --domain-identifier must refer to a valid and existing domain.
 *
 * - --identifier must refer to an existing asset in the specified domain.
 *
 * - Asset must not be referenced in any existing asset filters.
 *
 * - Asset must not be linked to any draft or published data product.
 *
 * - User must have delete permissions for the domain and project.
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetInput, DeleteAssetOutput, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetFilterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an asset filter.
 *
 * Prerequisites:
 *
 * - The asset filter must exist.
 *
 * - The domain and asset must not have been deleted.
 *
 * - Ensure the --identifier refers to a valid filter ID.
 */
export declare const deleteAssetFilter: API.OperationMethod<DeleteAssetFilterInput, DeleteAssetFilterResponse, DeleteAssetFilterError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetTypeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an asset type in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The asset type must exist in the domain.
 *
 * - You must have DeleteAssetType permission.
 *
 * - The asset type must not be in use (e.g., assigned to any asset). If used, deletion will fail.
 *
 * - You should retrieve the asset type using get-asset-type to confirm its presence before deletion.
 */
export declare const deleteAssetType: API.OperationMethod<DeleteAssetTypeInput, DeleteAssetTypeOutput, DeleteAssetTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes and connection. In Amazon DataZone, a connection enables you to connect your resources (domains, projects, and environments) to external resources and services.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionInput, DeleteConnectionOutput, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteDataExportConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes data export configuration for a domain.
 *
 * This operation does not delete the S3 table created by the PutDataExportConfiguration operation.
 *
 * To temporarily disable export without deleting the configuration, use the PutDataExportConfiguration operation with the `--no-enable-export` flag instead. This allows you to re-enable export for the same domain using the `--enable-export` flag without deleting S3 table.
 */
export declare const deleteDataExportConfiguration: API.OperationMethod<DeleteDataExportConfigurationInput, DeleteDataExportConfigurationOutput, DeleteDataExportConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteDataProductError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a data product in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The data product must exist and not be deleted or archived.
 *
 * - The user must have delete permissions for the data product.
 *
 * - Domain and project must be active.
 */
export declare const deleteDataProduct: API.OperationMethod<DeleteDataProductInput, DeleteDataProductOutput, DeleteDataProductError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a data source in Amazon DataZone.
 */
export declare const deleteDataSource: API.OperationMethod<DeleteDataSourceInput, DeleteDataSourceOutput, DeleteDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Amazon DataZone domain.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainInput, DeleteDomainOutput, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainUnitError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a domain unit.
 */
export declare const deleteDomainUnit: API.OperationMethod<DeleteDomainUnitInput, DeleteDomainUnitOutput, DeleteDomainUnitError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an environment in Amazon DataZone.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentInput, DeleteEnvironmentResponse, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentActionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an action for the environment, for example, deletes a console link for an analytics tool that is available in this environment.
 */
export declare const deleteEnvironmentAction: API.OperationMethod<DeleteEnvironmentActionInput, DeleteEnvironmentActionResponse, DeleteEnvironmentActionError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentBlueprintError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a blueprint in Amazon DataZone.
 */
export declare const deleteEnvironmentBlueprint: API.OperationMethod<DeleteEnvironmentBlueprintInput, DeleteEnvironmentBlueprintResponse, DeleteEnvironmentBlueprintError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentBlueprintConfigurationError = AccessDeniedException | InternalServerException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the blueprint configuration in Amazon DataZone.
 */
export declare const deleteEnvironmentBlueprintConfiguration: API.OperationMethod<DeleteEnvironmentBlueprintConfigurationInput, DeleteEnvironmentBlueprintConfigurationOutput, DeleteEnvironmentBlueprintConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an environment profile in Amazon DataZone.
 */
export declare const deleteEnvironmentProfile: API.OperationMethod<DeleteEnvironmentProfileInput, DeleteEnvironmentProfileResponse, DeleteEnvironmentProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteFormTypeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes and metadata form type in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The form type must exist in the domain.
 *
 * - The form type must not be in use by any asset types or assets.
 *
 * - The domain must be valid and accessible.
 *
 * - User must have delete permissions on the form type.
 *
 * - Any dependencies (such as linked asset types) must be removed first.
 */
export declare const deleteFormType: API.OperationMethod<DeleteFormTypeInput, DeleteFormTypeOutput, DeleteFormTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteGlossaryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a business glossary in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The glossary must be in DISABLED state.
 *
 * - The glossary must not have any glossary terms associated with it.
 *
 * - The glossary must exist in the specified domain.
 *
 * - The caller must have the `datazone:DeleteGlossary` permission in the domain and glossary.
 *
 * - Glossary should not be linked to any active metadata forms.
 */
export declare const deleteGlossary: API.OperationMethod<DeleteGlossaryInput, DeleteGlossaryOutput, DeleteGlossaryError, Credentials | HttpClient.HttpClient>;
export type DeleteGlossaryTermError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a business glossary term in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - Glossary term must exist and be active.
 *
 * - The term must not be linked to other assets or child terms.
 *
 * - Caller must have delete permissions in the domain/glossary.
 *
 * - Ensure all associations (such as to assets or parent terms) are removed before deletion.
 */
export declare const deleteGlossaryTerm: API.OperationMethod<DeleteGlossaryTermInput, DeleteGlossaryTermOutput, DeleteGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type DeleteLineageEventError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified lineage event.
 */
export declare const deleteLineageEvent: API.OperationMethod<DeleteLineageEventInput, DeleteLineageEventOutput, DeleteLineageEventError, Credentials | HttpClient.HttpClient>;
export type DeleteListingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a listing (a record of an asset at a given time).
 */
export declare const deleteListing: API.OperationMethod<DeleteListingInput, DeleteListingOutput, DeleteListingError, Credentials | HttpClient.HttpClient>;
export type DeleteNotebookError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a notebook in Amazon SageMaker Unified Studio.
 */
export declare const deleteNotebook: API.OperationMethod<DeleteNotebookInput, DeleteNotebookOutput, DeleteNotebookError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a project in Amazon DataZone.
 */
export declare const deleteProject: API.OperationMethod<DeleteProjectInput, DeleteProjectOutput, DeleteProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectMembershipError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes project membership in Amazon DataZone.
 */
export declare const deleteProjectMembership: API.OperationMethod<DeleteProjectMembershipInput, DeleteProjectMembershipOutput, DeleteProjectMembershipError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a project profile.
 */
export declare const deleteProjectProfile: API.OperationMethod<DeleteProjectProfileInput, DeleteProjectProfileOutput, DeleteProjectProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a rule in Amazon DataZone. A rule is a formal agreement that enforces specific requirements across user workflows (e.g., publishing assets to the catalog, requesting subscriptions, creating projects) within the Amazon DataZone data portal. These rules help maintain consistency, ensure compliance, and uphold governance standards in data management processes. For instance, a metadata enforcement rule can specify the required information for creating a subscription request or publishing a data asset to the catalog, ensuring alignment with organizational standards.
 */
export declare const deleteRule: API.OperationMethod<DeleteRuleInput, DeleteRuleOutput, DeleteRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteSubscriptionGrantError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes and subscription grant in Amazon DataZone.
 */
export declare const deleteSubscriptionGrant: API.OperationMethod<DeleteSubscriptionGrantInput, DeleteSubscriptionGrantOutput, DeleteSubscriptionGrantError, Credentials | HttpClient.HttpClient>;
export type DeleteSubscriptionRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a subscription request in Amazon DataZone.
 */
export declare const deleteSubscriptionRequest: API.OperationMethod<DeleteSubscriptionRequestInput, DeleteSubscriptionRequestResponse, DeleteSubscriptionRequestError, Credentials | HttpClient.HttpClient>;
export type DeleteSubscriptionTargetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a subscription target in Amazon DataZone.
 */
export declare const deleteSubscriptionTarget: API.OperationMethod<DeleteSubscriptionTargetInput, DeleteSubscriptionTargetResponse, DeleteSubscriptionTargetError, Credentials | HttpClient.HttpClient>;
export type DeleteTimeSeriesDataPointsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified time series form for the specified asset.
 */
export declare const deleteTimeSeriesDataPoints: API.OperationMethod<DeleteTimeSeriesDataPointsInput, DeleteTimeSeriesDataPointsOutput, DeleteTimeSeriesDataPointsError, Credentials | HttpClient.HttpClient>;
export type DisassociateEnvironmentRoleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates the environment role in Amazon DataZone.
 */
export declare const disassociateEnvironmentRole: API.OperationMethod<DisassociateEnvironmentRoleInput, DisassociateEnvironmentRoleOutput, DisassociateEnvironmentRoleError, Credentials | HttpClient.HttpClient>;
export type DisassociateGovernedTermsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates restricted terms from an asset.
 */
export declare const disassociateGovernedTerms: API.OperationMethod<DisassociateGovernedTermsInput, DisassociateGovernedTermsOutput, DisassociateGovernedTermsError, Credentials | HttpClient.HttpClient>;
export type GetAccountPoolError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of the account pool.
 */
export declare const getAccountPool: API.OperationMethod<GetAccountPoolInput, GetAccountPoolOutput, GetAccountPoolError, Credentials | HttpClient.HttpClient>;
export type GetAssetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon DataZone asset.
 *
 * An asset is the fundamental building block in Amazon DataZone, representing any data resource that needs to be cataloged and managed. It can take many forms, from Amazon S3 buckets and database tables to dashboards and machine learning models. Each asset contains comprehensive metadata about the resource, including its location, schema, ownership, and lineage information. Assets are essential for organizing and managing data resources across an organization, making them discoverable and usable while maintaining proper governance.
 *
 * Before using the Amazon DataZone GetAsset command, ensure the following prerequisites are met:
 *
 * - Domain identifier must exist and be valid
 *
 * - Asset identifier must exist
 *
 * - User must have the required permissions to perform the action
 */
export declare const getAsset: API.OperationMethod<GetAssetInput, GetAssetOutput, GetAssetError, Credentials | HttpClient.HttpClient>;
export type GetAssetFilterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an asset filter.
 *
 * Prerequisites:
 *
 * - Domain (`--domain-identifier`), asset (`--asset-identifier`), and filter (`--identifier`) must all exist.
 *
 * - The asset filter should not have been deleted.
 *
 * - The asset must still exist (since the filter is linked to it).
 */
export declare const getAssetFilter: API.OperationMethod<GetAssetFilterInput, GetAssetFilterOutput, GetAssetFilterError, Credentials | HttpClient.HttpClient>;
export type GetAssetTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon DataZone asset type.
 *
 * Asset types define the categories and characteristics of different kinds of data assets within Amazon DataZone.. They determine what metadata fields are required, what operations are possible, and how the asset integrates with other Amazon Web Services services. Asset types can range from built-in types like Amazon S3 buckets and Amazon Web Services Glue tables to custom types defined for specific organizational needs. Understanding asset types is crucial for properly organizing and managing different kinds of data resources.
 *
 * Prerequisites:
 *
 * - The asset type with identifier must exist in the domain. ResourceNotFoundException.
 *
 * - You must have the GetAssetType permission.
 *
 * - Ensure the domain-identifier value is correct and accessible.
 */
export declare const getAssetType: API.OperationMethod<GetAssetTypeInput, GetAssetTypeOutput, GetAssetTypeError, Credentials | HttpClient.HttpClient>;
export type GetConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a connection. In Amazon DataZone, a connection enables you to connect your resources (domains, projects, and environments) to external resources and services.
 */
export declare const getConnection: API.OperationMethod<GetConnectionInput, GetConnectionOutput, GetConnectionError, Credentials | HttpClient.HttpClient>;
export type GetDataExportConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets data export configuration details.
 */
export declare const getDataExportConfiguration: API.OperationMethod<GetDataExportConfigurationInput, GetDataExportConfigurationOutput, GetDataExportConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDataProductError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the data product.
 *
 * Prerequisites:
 *
 * - The data product ID must exist.
 *
 * - The domain must be valid and accessible.
 *
 * - User must have read or discovery permissions for the data product.
 */
export declare const getDataProduct: API.OperationMethod<GetDataProductInput, GetDataProductOutput, GetDataProductError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon DataZone data source.
 */
export declare const getDataSource: API.OperationMethod<GetDataSourceInput, GetDataSourceOutput, GetDataSourceError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon DataZone data source run.
 */
export declare const getDataSourceRun: API.OperationMethod<GetDataSourceRunInput, GetDataSourceRunOutput, GetDataSourceRunError, Credentials | HttpClient.HttpClient>;
export type GetDomainError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon DataZone domain.
 */
export declare const getDomain: API.OperationMethod<GetDomainInput, GetDomainOutput, GetDomainError, Credentials | HttpClient.HttpClient>;
export type GetDomainUnitError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of the specified domain unit.
 */
export declare const getDomainUnit: API.OperationMethod<GetDomainUnitInput, GetDomainUnitOutput, GetDomainUnitError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon DataZone environment.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentInput, GetEnvironmentOutput, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentActionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the specified environment action.
 */
export declare const getEnvironmentAction: API.OperationMethod<GetEnvironmentActionInput, GetEnvironmentActionOutput, GetEnvironmentActionError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentBlueprintError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon DataZone blueprint.
 */
export declare const getEnvironmentBlueprint: API.OperationMethod<GetEnvironmentBlueprintInput, GetEnvironmentBlueprintOutput, GetEnvironmentBlueprintError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentBlueprintConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets the blueprint configuration in Amazon DataZone.
 */
export declare const getEnvironmentBlueprintConfiguration: API.OperationMethod<GetEnvironmentBlueprintConfigurationInput, GetEnvironmentBlueprintConfigurationOutput, GetEnvironmentBlueprintConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentCredentialsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the credentials of an environment in Amazon DataZone.
 */
export declare const getEnvironmentCredentials: API.OperationMethod<GetEnvironmentCredentialsInput, GetEnvironmentCredentialsOutput, GetEnvironmentCredentialsError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an evinronment profile in Amazon DataZone.
 */
export declare const getEnvironmentProfile: API.OperationMethod<GetEnvironmentProfileInput, GetEnvironmentProfileOutput, GetEnvironmentProfileError, Credentials | HttpClient.HttpClient>;
export type GetFormTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a metadata form type in Amazon DataZone.
 *
 * Form types define the structure and validation rules for collecting metadata about assets in Amazon DataZone. They act as templates that ensure consistent metadata capture across similar types of assets, while allowing for customization to meet specific organizational needs. Form types can include required fields, validation rules, and dependencies, helping maintain high-quality metadata that makes data assets more discoverable and usable.
 *
 * - The form type with the specified identifier must exist in the given domain.
 *
 * - The domain must be valid and active.
 *
 * - User must have permission on the form type.
 *
 * - The form type should not be deleted or in an invalid state.
 *
 * One use case for this API is to determine whether a form field is indexed for search.
 *
 * A searchable field will be annotated with `@amazon.datazone#searchable`. By default, searchable fields are indexed for semantic search, where related query terms will match the attribute value even if they are not stemmed or keyword matches. If a field is indexed technical identifier search, it will be annotated with `@amazon.datazone#searchable(modes:["TECHNICAL"])`. If a field is indexed for lexical search (supports stemmed and prefix matches but not semantic matches), it will be annotated with `@amazon.datazone#searchable(modes:["LEXICAL"])`.
 *
 * A field storing glossary term IDs (which is filterable) will be annotated with `@amazon.datazone#glossaryterm("${glossaryId}")`.
 */
export declare const getFormType: API.OperationMethod<GetFormTypeInput, GetFormTypeOutput, GetFormTypeError, Credentials | HttpClient.HttpClient>;
export type GetGlossaryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a business glossary in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The specified glossary ID must exist and be associated with the given domain.
 *
 * - The caller must have the `datazone:GetGlossary` permission on the domain.
 */
export declare const getGlossary: API.OperationMethod<GetGlossaryInput, GetGlossaryOutput, GetGlossaryError, Credentials | HttpClient.HttpClient>;
export type GetGlossaryTermError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a business glossary term in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - Glossary term with identifier must exist in the domain.
 *
 * - User must have permission on the glossary term.
 *
 * - Domain must be accessible and active.
 */
export declare const getGlossaryTerm: API.OperationMethod<GetGlossaryTermInput, GetGlossaryTermOutput, GetGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type GetGroupProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets a group profile in Amazon DataZone.
 */
export declare const getGroupProfile: API.OperationMethod<GetGroupProfileInput, GetGroupProfileOutput, GetGroupProfileError, Credentials | HttpClient.HttpClient>;
export type GetIamPortalLoginUrlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the data portal URL for the specified Amazon DataZone domain.
 */
export declare const getIamPortalLoginUrl: API.OperationMethod<GetIamPortalLoginUrlInput, GetIamPortalLoginUrlOutput, GetIamPortalLoginUrlError, Credentials | HttpClient.HttpClient>;
export type GetJobRunError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The details of the job run.
 */
export declare const getJobRun: API.OperationMethod<GetJobRunInput, GetJobRunOutput, GetJobRunError, Credentials | HttpClient.HttpClient>;
export type GetLineageEventError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the lineage event.
 */
export declare const getLineageEvent: API.OperationMethod<GetLineageEventInput, GetLineageEventOutput, GetLineageEventError, Credentials | HttpClient.HttpClient>;
export type GetLineageNodeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the data lineage node.
 */
export declare const getLineageNode: API.OperationMethod<GetLineageNodeInput, GetLineageNodeOutput, GetLineageNodeError, Credentials | HttpClient.HttpClient>;
export type GetListingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a listing (a record of an asset at a given time). If you specify a listing version, only details that are specific to that version are returned.
 */
export declare const getListing: API.OperationMethod<GetListingInput, GetListingOutput, GetListingError, Credentials | HttpClient.HttpClient>;
export type GetMetadataGenerationRunError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a metadata generation run in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - Valid domain and run identifier.
 *
 * - The metadata generation run must exist.
 *
 * - User must have read access to the metadata run.
 */
export declare const getMetadataGenerationRun: API.OperationMethod<GetMetadataGenerationRunInput, GetMetadataGenerationRunOutput, GetMetadataGenerationRunError, Credentials | HttpClient.HttpClient>;
export type GetNotebookError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of a notebook in Amazon SageMaker Unified Studio.
 */
export declare const getNotebook: API.OperationMethod<GetNotebookInput, GetNotebookOutput, GetNotebookError, Credentials | HttpClient.HttpClient>;
export type GetNotebookExportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of a notebook export in Amazon SageMaker Unified Studio.
 */
export declare const getNotebookExport: API.OperationMethod<GetNotebookExportInput, GetNotebookExportOutput, GetNotebookExportError, Credentials | HttpClient.HttpClient>;
export type GetNotebookRunError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of a notebook run in Amazon SageMaker Unified Studio.
 */
export declare const getNotebookRun: API.OperationMethod<GetNotebookRunInput, GetNotebookRunOutput, GetNotebookRunError, Credentials | HttpClient.HttpClient>;
export type GetProjectError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a project in Amazon DataZone.
 */
export declare const getProject: API.OperationMethod<GetProjectInput, GetProjectOutput, GetProjectError, Credentials | HttpClient.HttpClient>;
export type GetProjectProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The details of the project profile.
 */
export declare const getProjectProfile: API.OperationMethod<GetProjectProfileInput, GetProjectProfileOutput, GetProjectProfileError, Credentials | HttpClient.HttpClient>;
export type GetRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of a rule in Amazon DataZone. A rule is a formal agreement that enforces specific requirements across user workflows (e.g., publishing assets to the catalog, requesting subscriptions, creating projects) within the Amazon DataZone data portal. These rules help maintain consistency, ensure compliance, and uphold governance standards in data management processes. For instance, a metadata enforcement rule can specify the required information for creating a subscription request or publishing a data asset to the catalog, ensuring alignment with organizational standards.
 */
export declare const getRule: API.OperationMethod<GetRuleInput, GetRuleOutput, GetRuleError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a subscription in Amazon DataZone.
 */
export declare const getSubscription: API.OperationMethod<GetSubscriptionInput, GetSubscriptionOutput, GetSubscriptionError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the subscription grant in Amazon DataZone.
 */
export declare const getSubscriptionGrant: API.OperationMethod<GetSubscriptionGrantInput, GetSubscriptionGrantOutput, GetSubscriptionGrantError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionRequestDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of the specified subscription request.
 */
export declare const getSubscriptionRequestDetails: API.OperationMethod<GetSubscriptionRequestDetailsInput, GetSubscriptionRequestDetailsOutput, GetSubscriptionRequestDetailsError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionTargetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the subscription target in Amazon DataZone.
 */
export declare const getSubscriptionTarget: API.OperationMethod<GetSubscriptionTargetInput, GetSubscriptionTargetOutput, GetSubscriptionTargetError, Credentials | HttpClient.HttpClient>;
export type GetTimeSeriesDataPointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the existing data point for the asset.
 */
export declare const getTimeSeriesDataPoint: API.OperationMethod<GetTimeSeriesDataPointInput, GetTimeSeriesDataPointOutput, GetTimeSeriesDataPointError, Credentials | HttpClient.HttpClient>;
export type GetUserProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets a user profile in Amazon DataZone.
 */
export declare const getUserProfile: API.OperationMethod<GetUserProfileInput, GetUserProfileOutput, GetUserProfileError, Credentials | HttpClient.HttpClient>;
export type ListAccountPoolsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists existing account pools.
 */
export declare const listAccountPools: API.PaginatedOperationMethod<ListAccountPoolsInput, ListAccountPoolsOutput, ListAccountPoolsError, Credentials | HttpClient.HttpClient, AccountPoolSummary>;
export type ListAccountsInAccountPoolError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the accounts in the specified account pool.
 */
export declare const listAccountsInAccountPool: API.PaginatedOperationMethod<ListAccountsInAccountPoolInput, ListAccountsInAccountPoolOutput, ListAccountsInAccountPoolError, Credentials | HttpClient.HttpClient, AccountInfo>;
export type ListAssetFiltersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists asset filters.
 *
 * Prerequisites:
 *
 * - A valid domain and asset must exist.
 *
 * - The asset must have at least one filter created to return results.
 */
export declare const listAssetFilters: API.PaginatedOperationMethod<ListAssetFiltersInput, ListAssetFiltersOutput, ListAssetFiltersError, Credentials | HttpClient.HttpClient, AssetFilterSummary>;
export type ListAssetRevisionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the revisions for the asset.
 *
 * Prerequisites:
 *
 * - The asset must exist in the domain.
 *
 * - There must be at least one revision of the asset (which happens automatically after creation).
 *
 * - The domain must be valid and active.
 *
 * - User must have permissions on the asset and domain.
 */
export declare const listAssetRevisions: API.PaginatedOperationMethod<ListAssetRevisionsInput, ListAssetRevisionsOutput, ListAssetRevisionsError, Credentials | HttpClient.HttpClient, AssetRevision>;
export type ListConnectionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists connections. In Amazon DataZone, a connection enables you to connect your resources (domains, projects, and environments) to external resources and services.
 */
export declare const listConnections: API.PaginatedOperationMethod<ListConnectionsInput, ListConnectionsOutput, ListConnectionsError, Credentials | HttpClient.HttpClient, ConnectionSummary>;
export type ListDataProductRevisionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists data product revisions.
 *
 * Prerequisites:
 *
 * - The data product ID must exist within the domain.
 *
 * - User must have view permissions on the data product.
 *
 * - The domain must be in a valid and accessible state.
 */
export declare const listDataProductRevisions: API.PaginatedOperationMethod<ListDataProductRevisionsInput, ListDataProductRevisionsOutput, ListDataProductRevisionsError, Credentials | HttpClient.HttpClient, DataProductRevision>;
export type ListDataSourceRunActivitiesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists data source run activities.
 */
export declare const listDataSourceRunActivities: API.PaginatedOperationMethod<ListDataSourceRunActivitiesInput, ListDataSourceRunActivitiesOutput, ListDataSourceRunActivitiesError, Credentials | HttpClient.HttpClient, DataSourceRunActivity>;
export type ListDataSourceRunsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists data source runs in Amazon DataZone.
 */
export declare const listDataSourceRuns: API.PaginatedOperationMethod<ListDataSourceRunsInput, ListDataSourceRunsOutput, ListDataSourceRunsError, Credentials | HttpClient.HttpClient, DataSourceRunSummary>;
export type ListDataSourcesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists data sources in Amazon DataZone.
 */
export declare const listDataSources: API.PaginatedOperationMethod<ListDataSourcesInput, ListDataSourcesOutput, ListDataSourcesError, Credentials | HttpClient.HttpClient, DataSourceSummary>;
export type ListDomainsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists Amazon DataZone domains.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsInput, ListDomainsOutput, ListDomainsError, Credentials | HttpClient.HttpClient, DomainSummary>;
export type ListDomainUnitsForParentError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists child domain units for the specified parent domain unit.
 */
export declare const listDomainUnitsForParent: API.PaginatedOperationMethod<ListDomainUnitsForParentInput, ListDomainUnitsForParentOutput, ListDomainUnitsForParentError, Credentials | HttpClient.HttpClient, DomainUnitSummary>;
export type ListEntityOwnersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the entity (domain units) owners.
 */
export declare const listEntityOwners: API.PaginatedOperationMethod<ListEntityOwnersInput, ListEntityOwnersOutput, ListEntityOwnersError, Credentials | HttpClient.HttpClient, OwnerPropertiesOutput>;
export type ListEnvironmentActionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists existing environment actions.
 */
export declare const listEnvironmentActions: API.PaginatedOperationMethod<ListEnvironmentActionsInput, ListEnvironmentActionsOutput, ListEnvironmentActionsError, Credentials | HttpClient.HttpClient, EnvironmentActionSummary>;
export type ListEnvironmentBlueprintConfigurationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists blueprint configurations for a Amazon DataZone environment.
 */
export declare const listEnvironmentBlueprintConfigurations: API.PaginatedOperationMethod<ListEnvironmentBlueprintConfigurationsInput, ListEnvironmentBlueprintConfigurationsOutput, ListEnvironmentBlueprintConfigurationsError, Credentials | HttpClient.HttpClient, EnvironmentBlueprintConfigurationItem>;
export type ListEnvironmentBlueprintsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists blueprints in an Amazon DataZone environment.
 */
export declare const listEnvironmentBlueprints: API.PaginatedOperationMethod<ListEnvironmentBlueprintsInput, ListEnvironmentBlueprintsOutput, ListEnvironmentBlueprintsError, Credentials | HttpClient.HttpClient, EnvironmentBlueprintSummary>;
export type ListEnvironmentProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists Amazon DataZone environment profiles.
 */
export declare const listEnvironmentProfiles: API.PaginatedOperationMethod<ListEnvironmentProfilesInput, ListEnvironmentProfilesOutput, ListEnvironmentProfilesError, Credentials | HttpClient.HttpClient, EnvironmentProfileSummary>;
export type ListEnvironmentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Lists Amazon DataZone environments.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsInput, ListEnvironmentsOutput, ListEnvironmentsError, Credentials | HttpClient.HttpClient, EnvironmentSummary>;
export type ListJobRunsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists job runs.
 */
export declare const listJobRuns: API.PaginatedOperationMethod<ListJobRunsInput, ListJobRunsOutput, ListJobRunsError, Credentials | HttpClient.HttpClient, JobRunSummary>;
export type ListLineageEventsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists lineage events.
 */
export declare const listLineageEvents: API.PaginatedOperationMethod<ListLineageEventsInput, ListLineageEventsOutput, ListLineageEventsError, Credentials | HttpClient.HttpClient, LineageEventSummary>;
export type ListLineageNodeHistoryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the history of the specified data lineage node.
 */
export declare const listLineageNodeHistory: API.PaginatedOperationMethod<ListLineageNodeHistoryInput, ListLineageNodeHistoryOutput, ListLineageNodeHistoryError, Credentials | HttpClient.HttpClient, LineageNodeSummary>;
export type ListMetadataGenerationRunsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all metadata generation runs.
 *
 * Metadata generation runs represent automated processes that leverage AI/ML capabilities to create or enhance asset metadata at scale. This feature helps organizations maintain comprehensive and consistent metadata across large numbers of assets without manual intervention. It can automatically generate business descriptions, tags, and other metadata elements, significantly reducing the time and effort required for metadata management while improving consistency and completeness.
 *
 * Prerequisites:
 *
 * - Valid domain identifier.
 *
 * - User must have access to metadata generation runs in the domain.
 */
export declare const listMetadataGenerationRuns: API.PaginatedOperationMethod<ListMetadataGenerationRunsInput, ListMetadataGenerationRunsOutput, ListMetadataGenerationRunsError, Credentials | HttpClient.HttpClient, MetadataGenerationRunItem>;
export type ListNotebookRunsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists notebook runs in Amazon SageMaker Unified Studio.
 */
export declare const listNotebookRuns: API.PaginatedOperationMethod<ListNotebookRunsInput, ListNotebookRunsOutput, ListNotebookRunsError, Credentials | HttpClient.HttpClient, NotebookRunSummary>;
export type ListNotebooksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists notebooks in Amazon SageMaker Unified Studio.
 */
export declare const listNotebooks: API.PaginatedOperationMethod<ListNotebooksInput, ListNotebooksOutput, ListNotebooksError, Credentials | HttpClient.HttpClient, NotebookSummary>;
export type ListNotificationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all Amazon DataZone notifications.
 */
export declare const listNotifications: API.PaginatedOperationMethod<ListNotificationsInput, ListNotificationsOutput, ListNotificationsError, Credentials | HttpClient.HttpClient, NotificationOutput>;
export type ListPolicyGrantsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists policy grants.
 */
export declare const listPolicyGrants: API.PaginatedOperationMethod<ListPolicyGrantsInput, ListPolicyGrantsOutput, ListPolicyGrantsError, Credentials | HttpClient.HttpClient, PolicyGrantMember>;
export type ListProjectMembershipsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all members of the specified project.
 */
export declare const listProjectMemberships: API.PaginatedOperationMethod<ListProjectMembershipsInput, ListProjectMembershipsOutput, ListProjectMembershipsError, Credentials | HttpClient.HttpClient, ProjectMember>;
export type ListProjectProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists project profiles.
 */
export declare const listProjectProfiles: API.PaginatedOperationMethod<ListProjectProfilesInput, ListProjectProfilesOutput, ListProjectProfilesError, Credentials | HttpClient.HttpClient, ProjectProfileSummary>;
export type ListProjectsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Lists Amazon DataZone projects.
 */
export declare const listProjects: API.PaginatedOperationMethod<ListProjectsInput, ListProjectsOutput, ListProjectsError, Credentials | HttpClient.HttpClient, ProjectSummary>;
export type ListRulesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists existing rules. In Amazon DataZone, a rule is a formal agreement that enforces specific requirements across user workflows (e.g., publishing assets to the catalog, requesting subscriptions, creating projects) within the Amazon DataZone data portal. These rules help maintain consistency, ensure compliance, and uphold governance standards in data management processes. For instance, a metadata enforcement rule can specify the required information for creating a subscription request or publishing a data asset to the catalog, ensuring alignment with organizational standards.
 */
export declare const listRules: API.PaginatedOperationMethod<ListRulesInput, ListRulesOutput, ListRulesError, Credentials | HttpClient.HttpClient, RuleSummary>;
export type ListSubscriptionGrantsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists subscription grants.
 */
export declare const listSubscriptionGrants: API.PaginatedOperationMethod<ListSubscriptionGrantsInput, ListSubscriptionGrantsOutput, ListSubscriptionGrantsError, Credentials | HttpClient.HttpClient, SubscriptionGrantSummary>;
export type ListSubscriptionRequestsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists Amazon DataZone subscription requests.
 */
export declare const listSubscriptionRequests: API.PaginatedOperationMethod<ListSubscriptionRequestsInput, ListSubscriptionRequestsOutput, ListSubscriptionRequestsError, Credentials | HttpClient.HttpClient, SubscriptionRequestSummary>;
export type ListSubscriptionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists subscriptions in Amazon DataZone.
 */
export declare const listSubscriptions: API.PaginatedOperationMethod<ListSubscriptionsInput, ListSubscriptionsOutput, ListSubscriptionsError, Credentials | HttpClient.HttpClient, SubscriptionSummary>;
export type ListSubscriptionTargetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists subscription targets in Amazon DataZone.
 */
export declare const listSubscriptionTargets: API.PaginatedOperationMethod<ListSubscriptionTargetsInput, ListSubscriptionTargetsOutput, ListSubscriptionTargetsError, Credentials | HttpClient.HttpClient, SubscriptionTargetSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists tags for the specified resource in Amazon DataZone.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTimeSeriesDataPointsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists time series data points.
 */
export declare const listTimeSeriesDataPoints: API.PaginatedOperationMethod<ListTimeSeriesDataPointsInput, ListTimeSeriesDataPointsOutput, ListTimeSeriesDataPointsError, Credentials | HttpClient.HttpClient, TimeSeriesDataPointSummaryFormOutput>;
export type PostLineageEventError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Posts a data lineage event.
 */
export declare const postLineageEvent: API.OperationMethod<PostLineageEventInput, PostLineageEventOutput, PostLineageEventError, Credentials | HttpClient.HttpClient>;
export type PostTimeSeriesDataPointsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Posts time series data points to Amazon DataZone for the specified asset.
 */
export declare const postTimeSeriesDataPoints: API.OperationMethod<PostTimeSeriesDataPointsInput, PostTimeSeriesDataPointsOutput, PostTimeSeriesDataPointsError, Credentials | HttpClient.HttpClient>;
export type PutDataExportConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates data export configuration details.
 *
 * If you want to temporarily disable export and later re-enable it for the same domain, use the `--no-enable-export` flag to disable and the `--enable-export` flag to re-enable. This preserves the configuration and allows you to re-enable export without deleting S3 table.
 *
 * You can enable asset metadata export for only one domain per account per Region. To enable export for a different domain, complete the following steps:
 *
 * - Delete the export configuration for the currently enabled domain using the DeleteDataExportConfiguration operation.
 *
 * - Delete the asset S3 table under the aws-sagemaker-catalog S3 table bucket. We recommend backing up the S3 table before deletion.
 *
 * - Call the PutDataExportConfiguration API to enable export for the new domain.
 */
export declare const putDataExportConfiguration: API.OperationMethod<PutDataExportConfigurationInput, PutDataExportConfigurationOutput, PutDataExportConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutEnvironmentBlueprintConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Writes the configuration for the specified environment blueprint in Amazon DataZone.
 */
export declare const putEnvironmentBlueprintConfiguration: API.OperationMethod<PutEnvironmentBlueprintConfigurationInput, PutEnvironmentBlueprintConfigurationOutput, PutEnvironmentBlueprintConfigurationError, Credentials | HttpClient.HttpClient>;
export type QueryGraphError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Queries entities in the graph store.
 */
export declare const queryGraph: API.PaginatedOperationMethod<QueryGraphInput, QueryGraphOutput, QueryGraphError, Credentials | HttpClient.HttpClient, ResultItem>;
export type RejectPredictionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Rejects automatically generated business-friendly metadata for your Amazon DataZone assets.
 */
export declare const rejectPredictions: API.OperationMethod<RejectPredictionsInput, RejectPredictionsOutput, RejectPredictionsError, Credentials | HttpClient.HttpClient>;
export type RejectSubscriptionRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Rejects the specified subscription request.
 */
export declare const rejectSubscriptionRequest: API.OperationMethod<RejectSubscriptionRequestInput, RejectSubscriptionRequestOutput, RejectSubscriptionRequestError, Credentials | HttpClient.HttpClient>;
export type RemoveEntityOwnerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes an owner from an entity.
 */
export declare const removeEntityOwner: API.OperationMethod<RemoveEntityOwnerInput, RemoveEntityOwnerOutput, RemoveEntityOwnerError, Credentials | HttpClient.HttpClient>;
export type RemovePolicyGrantError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a policy grant.
 */
export declare const removePolicyGrant: API.OperationMethod<RemovePolicyGrantInput, RemovePolicyGrantOutput, RemovePolicyGrantError, Credentials | HttpClient.HttpClient>;
export type RevokeSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Revokes a specified subscription in Amazon DataZone.
 */
export declare const revokeSubscription: API.OperationMethod<RevokeSubscriptionInput, RevokeSubscriptionOutput, RevokeSubscriptionError, Credentials | HttpClient.HttpClient>;
export type SearchError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches for assets in Amazon DataZone.
 *
 * Search in Amazon DataZone is a powerful capability that enables users to discover and explore data assets, glossary terms, and data products across their organization. It provides both basic and advanced search functionality, allowing users to find resources based on names, descriptions, metadata, and other attributes. Search can be scoped to specific types of resources (like assets, glossary terms, or data products) and can be filtered using various criteria such as creation date, owner, or status. The search functionality is essential for making the wealth of data resources in an organization discoverable and usable, helping users find the right data for their needs quickly and efficiently.
 *
 * Many search commands in Amazon DataZone are paginated, including `search` and `search-types`. When the result set is large, Amazon DataZone returns a `nextToken` in the response. This token can be used to retrieve the next page of results.
 *
 * Prerequisites:
 *
 * - The --domain-identifier must refer to an existing Amazon DataZone domain.
 *
 * - --search-scope must be one of: ASSET, GLOSSARY_TERM, DATA_PRODUCT, or GLOSSARY.
 *
 * - The user must have search permissions in the specified domain.
 *
 * - If using --filters, ensure that the JSON is well-formed and that each filter includes valid attribute and value keys.
 *
 * - For paginated results, be prepared to use --next-token to fetch additional pages.
 *
 * To run a standard free-text search, the `searchText` parameter must be supplied. By default, all searchable fields are indexed for semantic search and will return semantic matches for SearchListings queries. To prevent semantic search indexing for a custom form attribute, see the CreateFormType API documentation. To run a lexical search query, enclose the query with double quotes (""). This will disable semantic search even for fields that have semantic search enabled and will only return results that contain the keywords wrapped by double quotes (order of tokens in the query is not enforced). Free-text search is supported for all attributes annotated with @amazon.datazone#searchable.
 *
 * To run a filtered search, provide filter clause using the `filters` parameter. To filter on glossary terms, use the special attribute `__DataZoneGlossaryTerms`. To filter on an indexed numeric attribute (i.e., a numeric attribute annotated with `@amazon.datazone#sortable`), provide a filter using the `intValue` parameter. The filters parameter can also be used to run more advanced free-text searches that target specific attributes (attributes must be annotated with `@amazon.datazone#searchable` for free-text search). Create/update timestamp filtering is supported using the special `creationTime`/`lastUpdatedTime` attributes. Filter types can be mixed and matched to power complex queries.
 *
 * To find out whether an attribute has been annotated and indexed for a given search type, use the GetFormType API to retrieve the form containing the attribute.
 */
export declare const search: API.PaginatedOperationMethod<SearchInput, SearchOutput, SearchError, Credentials | HttpClient.HttpClient, SearchInventoryResultItem>;
export type SearchGroupProfilesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Searches group profiles in Amazon DataZone.
 */
export declare const searchGroupProfiles: API.PaginatedOperationMethod<SearchGroupProfilesInput, SearchGroupProfilesOutput, SearchGroupProfilesError, Credentials | HttpClient.HttpClient, GroupProfileSummary>;
export type SearchListingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches listings in Amazon DataZone.
 *
 * SearchListings is a powerful capability that enables users to discover and explore published assets and data products across their organization. It provides both basic and advanced search functionality, allowing users to find resources based on names, descriptions, metadata, and other attributes. SearchListings also supports filtering using various criteria such as creation date, owner, or status. This API is essential for making the wealth of data resources in an organization discoverable and usable, helping users find the right data for their needs quickly and efficiently.
 *
 * SearchListings returns results in a paginated format. When the result set is large, the response will include a nextToken, which can be used to retrieve the next page of results.
 *
 * The SearchListings API gives users flexibility in specifying what kind of search is run.
 *
 * To run a standard free-text search, the `searchText` parameter must be supplied. By default, all searchable fields are indexed for semantic search and will return semantic matches for SearchListings queries. To prevent semantic search indexing for a custom form attribute, see the CreateFormType API documentation. To run a lexical search query, enclose the query with double quotes (""). This will disable semantic search even for fields that have semantic search enabled and will only return results that contain the keywords wrapped by double quotes (order of tokens in the query is not enforced). Free-text search is supported for all attributes annotated with @amazon.datazone#searchable.
 *
 * To run a filtered search, provide filter clause using the `filters` parameter. To filter on glossary terms, use the special attribute `__DataZoneGlossaryTerms`. To filter on an indexed numeric attribute (i.e., a numeric attribute annotated with `@amazon.datazone#sortable`), provide a filter using the `intValue` parameter. The filters parameter can also be used to run more advanced free-text searches that target specific attributes (attributes must be annotated with `@amazon.datazone#searchable` for free-text search). Create/update timestamp filtering is supported using the special `creationTime`/`lastUpdatedTime` attributes. Filter types can be mixed and matched to power complex queries.
 *
 * To find out whether an attribute has been annotated and indexed for a given search type, use the GetFormType API to retrieve the form containing the attribute.
 */
export declare const searchListings: API.PaginatedOperationMethod<SearchListingsInput, SearchListingsOutput, SearchListingsError, Credentials | HttpClient.HttpClient, SearchResultItem>;
export type SearchTypesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches for types in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The --domain-identifier must refer to an existing Amazon DataZone domain.
 *
 * - --search-scope must be one of the valid values including: ASSET_TYPE, GLOSSARY_TERM_TYPE, DATA_PRODUCT_TYPE.
 *
 * - The --managed flag must be present without a value.
 *
 * - The user must have permissions for form or asset types in the domain.
 *
 * - If using --filters, ensure that the JSON is valid.
 *
 * - Filters contain correct structure (attribute, value, operator).
 */
export declare const searchTypes: API.PaginatedOperationMethod<SearchTypesInput, SearchTypesOutput, SearchTypesError, Credentials | HttpClient.HttpClient, SearchTypesResultItem>;
export type SearchUserProfilesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Searches user profiles in Amazon DataZone.
 */
export declare const searchUserProfiles: API.PaginatedOperationMethod<SearchUserProfilesInput, SearchUserProfilesOutput, SearchUserProfilesError, Credentials | HttpClient.HttpClient, UserProfileSummary>;
export type StartDataSourceRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Start the run of the specified data source in Amazon DataZone.
 */
export declare const startDataSourceRun: API.OperationMethod<StartDataSourceRunInput, StartDataSourceRunOutput, StartDataSourceRunError, Credentials | HttpClient.HttpClient>;
export type StartMetadataGenerationRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the metadata generation run.
 *
 * Prerequisites:
 *
 * - Asset must be created and belong to the specified domain and project.
 *
 * - Asset type must be supported for metadata generation (e.g., Amazon Web Services Glue table).
 *
 * - Asset must have a structured schema with valid rows and columns.
 *
 * - Valid values for --type: BUSINESS_DESCRIPTIONS, BUSINESS_NAMES, BUSINESS_GLOSSARY_ASSOCIATIONS.
 *
 * - The user must have permission to run metadata generation in the domain/project.
 */
export declare const startMetadataGenerationRun: API.OperationMethod<StartMetadataGenerationRunInput, StartMetadataGenerationRunOutput, StartMetadataGenerationRunError, Credentials | HttpClient.HttpClient>;
export type StartNotebookExportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a notebook export in Amazon SageMaker Unified Studio. This operation exports a notebook to a specified file format and stores the output in Amazon Simple Storage Service.
 */
export declare const startNotebookExport: API.OperationMethod<StartNotebookExportInput, StartNotebookExportOutput, StartNotebookExportError, Credentials | HttpClient.HttpClient>;
export type StartNotebookImportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a notebook import in Amazon SageMaker Unified Studio. This operation imports a notebook from an Amazon Simple Storage Service location into a project.
 */
export declare const startNotebookImport: API.OperationMethod<StartNotebookImportInput, StartNotebookImportOutput, StartNotebookImportError, Credentials | HttpClient.HttpClient>;
export type StartNotebookRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a notebook run in Amazon SageMaker Unified Studio. A notebook run represents the execution of an Amazon SageMaker notebook within a project. You can configure compute, network, timeout, and environment settings for the run.
 */
export declare const startNotebookRun: API.OperationMethod<StartNotebookRunInput, StartNotebookRunOutput, StartNotebookRunError, Credentials | HttpClient.HttpClient>;
export type StartNotebookSyncError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a notebook sync in Amazon SageMaker Unified Studio. This operation syncs a notebook from a Git repository into a project.
 */
export declare const startNotebookSync: API.OperationMethod<StartNotebookSyncInput, StartNotebookSyncOutput, StartNotebookSyncError, Credentials | HttpClient.HttpClient>;
export type StopNotebookRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a running notebook run in Amazon SageMaker Unified Studio.
 */
export declare const stopNotebookRun: API.OperationMethod<StopNotebookRunInput, StopNotebookRunOutput, StopNotebookRunError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Tags a resource in Amazon DataZone.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Untags a resource in Amazon DataZone.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountPoolError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the account pool.
 */
export declare const updateAccountPool: API.OperationMethod<UpdateAccountPoolInput, UpdateAccountPoolOutput, UpdateAccountPoolError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetFilterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an asset filter.
 *
 * Prerequisites:
 *
 * - The domain, asset, and asset filter identifier must all exist.
 *
 * - The asset must contain the columns being referenced in the update.
 *
 * - If applying a row filter, ensure the column referenced in the expression exists in the asset schema.
 */
export declare const updateAssetFilter: API.OperationMethod<UpdateAssetFilterInput, UpdateAssetFilterOutput, UpdateAssetFilterError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a connection. In Amazon DataZone, a connection enables you to connect your resources (domains, projects, and environments) to external resources and services.
 */
export declare const updateConnection: API.OperationMethod<UpdateConnectionInput, UpdateConnectionOutput, UpdateConnectionError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified data source in Amazon DataZone.
 */
export declare const updateDataSource: API.OperationMethod<UpdateDataSourceInput, UpdateDataSourceOutput, UpdateDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a Amazon DataZone domain.
 */
export declare const updateDomain: API.OperationMethod<UpdateDomainInput, UpdateDomainOutput, UpdateDomainError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainUnitError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the domain unit.
 */
export declare const updateDomainUnit: API.OperationMethod<UpdateDomainUnitInput, UpdateDomainUnitOutput, UpdateDomainUnitError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified environment in Amazon DataZone.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentInput, UpdateEnvironmentOutput, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentActionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an environment action.
 */
export declare const updateEnvironmentAction: API.OperationMethod<UpdateEnvironmentActionInput, UpdateEnvironmentActionOutput, UpdateEnvironmentActionError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentBlueprintError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an environment blueprint in Amazon DataZone.
 */
export declare const updateEnvironmentBlueprint: API.OperationMethod<UpdateEnvironmentBlueprintInput, UpdateEnvironmentBlueprintOutput, UpdateEnvironmentBlueprintError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified environment profile in Amazon DataZone.
 */
export declare const updateEnvironmentProfile: API.OperationMethod<UpdateEnvironmentProfileInput, UpdateEnvironmentProfileOutput, UpdateEnvironmentProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateGlossaryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the business glossary in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The glossary must exist in the given domain.
 *
 * - The caller must have the `datazone:UpdateGlossary` permission to update it.
 *
 * - When updating the name, the new name must be unique within the domain.
 *
 * - The glossary must not be deleted or in a terminal state.
 */
export declare const updateGlossary: API.OperationMethod<UpdateGlossaryInput, UpdateGlossaryOutput, UpdateGlossaryError, Credentials | HttpClient.HttpClient>;
export type UpdateGlossaryTermError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a business glossary term in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - Glossary term must exist in the specified domain.
 *
 * - New name must not conflict with existing terms in the same glossary.
 *
 * - User must have permissions on the term.
 *
 * - The term must not be in DELETED status.
 */
export declare const updateGlossaryTerm: API.OperationMethod<UpdateGlossaryTermInput, UpdateGlossaryTermOutput, UpdateGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the specified group profile in Amazon DataZone.
 */
export declare const updateGroupProfile: API.OperationMethod<UpdateGroupProfileInput, UpdateGroupProfileOutput, UpdateGroupProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateNotebookError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a notebook in Amazon SageMaker Unified Studio.
 */
export declare const updateNotebook: API.OperationMethod<UpdateNotebookInput, UpdateNotebookOutput, UpdateNotebookError, Credentials | HttpClient.HttpClient>;
export type UpdateProjectError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified project in Amazon DataZone.
 */
export declare const updateProject: API.OperationMethod<UpdateProjectInput, UpdateProjectOutput, UpdateProjectError, Credentials | HttpClient.HttpClient>;
export type UpdateProjectProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a project profile.
 */
export declare const updateProjectProfile: API.OperationMethod<UpdateProjectProfileInput, UpdateProjectProfileOutput, UpdateProjectProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateRootDomainUnitOwnerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the owner of the root domain unit.
 */
export declare const updateRootDomainUnitOwner: API.OperationMethod<UpdateRootDomainUnitOwnerInput, UpdateRootDomainUnitOwnerOutput, UpdateRootDomainUnitOwnerError, Credentials | HttpClient.HttpClient>;
export type UpdateRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a rule. In Amazon DataZone, a rule is a formal agreement that enforces specific requirements across user workflows (e.g., publishing assets to the catalog, requesting subscriptions, creating projects) within the Amazon DataZone data portal. These rules help maintain consistency, ensure compliance, and uphold governance standards in data management processes. For instance, a metadata enforcement rule can specify the required information for creating a subscription request or publishing a data asset to the catalog, ensuring alignment with organizational standards.
 */
export declare const updateRule: API.OperationMethod<UpdateRuleInput, UpdateRuleOutput, UpdateRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriptionGrantStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status of the specified subscription grant status in Amazon DataZone.
 */
export declare const updateSubscriptionGrantStatus: API.OperationMethod<UpdateSubscriptionGrantStatusInput, UpdateSubscriptionGrantStatusOutput, UpdateSubscriptionGrantStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriptionRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a specified subscription request in Amazon DataZone.
 */
export declare const updateSubscriptionRequest: API.OperationMethod<UpdateSubscriptionRequestInput, UpdateSubscriptionRequestOutput, UpdateSubscriptionRequestError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriptionTargetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified subscription target in Amazon DataZone.
 */
export declare const updateSubscriptionTarget: API.OperationMethod<UpdateSubscriptionTargetInput, UpdateSubscriptionTargetOutput, UpdateSubscriptionTargetError, Credentials | HttpClient.HttpClient>;
export type UpdateUserProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the specified user profile in Amazon DataZone.
 */
export declare const updateUserProfile: API.OperationMethod<UpdateUserProfileInput, UpdateUserProfileOutput, UpdateUserProfileError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=datazone.d.ts.map