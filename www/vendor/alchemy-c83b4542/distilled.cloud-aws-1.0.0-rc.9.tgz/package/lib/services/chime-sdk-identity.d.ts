import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.Class<ForbiddenException, S.TaggedStruct<"ForbiddenException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceLimitExceededException_base: S.Class<ResourceLimitExceededException, S.TaggedStruct<"ResourceLimitExceededException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ServiceFailureException_base: S.Class<ServiceFailureException, S.TaggedStruct<"ServiceFailureException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceFailureException extends /*@__PURE__*/ ServiceFailureException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottledClientException_base: S.Class<ThrottledClientException, S.TaggedStruct<"ThrottledClientException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottledClientException extends /*@__PURE__*/ ThrottledClientException_base {
}
declare const UnauthorizedClientException_base: S.Class<UnauthorizedClientException, S.TaggedStruct<"UnauthorizedClientException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedClientException extends /*@__PURE__*/ UnauthorizedClientException_base {
}
export type NonEmptyResourceName = string | redacted.Redacted<string>;
export type Metadata = string | redacted.Redacted<string>;
export type ClientRequestToken = string;
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    Key: string | redacted.Redacted<string>;
    Value: string | redacted.Redacted<string>;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateAppInstanceRequest {
    Name: string | redacted.Redacted<string>;
    Metadata?: string | redacted.Redacted<string>;
    ClientRequestToken: string;
    Tags?: Tag[];
}
export declare const CreateAppInstanceRequest: S.Schema<CreateAppInstanceRequest>;
export type ChimeArn = string;
export interface CreateAppInstanceResponse {
    AppInstanceArn?: string;
}
export declare const CreateAppInstanceResponse: S.Schema<CreateAppInstanceResponse>;
export interface CreateAppInstanceAdminRequest {
    AppInstanceAdminArn: string;
    AppInstanceArn: string;
}
export declare const CreateAppInstanceAdminRequest: S.Schema<CreateAppInstanceAdminRequest>;
export type ResourceName = string | redacted.Redacted<string>;
export interface Identity {
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
}
export declare const Identity: S.Schema<Identity>;
export interface CreateAppInstanceAdminResponse {
    AppInstanceAdmin?: Identity;
    AppInstanceArn?: string;
}
export declare const CreateAppInstanceAdminResponse: S.Schema<CreateAppInstanceAdminResponse>;
export type RespondsTo = "STANDARD_MESSAGES" | (string & {});
export declare const RespondsTo: any;
export type StandardMessages = "AUTO" | "ALL" | "MENTIONS" | "NONE" | (string & {});
export declare const StandardMessages: any;
export type TargetedMessages = "ALL" | "NONE" | (string & {});
export declare const TargetedMessages: any;
export interface InvokedBy {
    StandardMessages: StandardMessages;
    TargetedMessages: TargetedMessages;
}
export declare const InvokedBy: S.Schema<InvokedBy>;
export type LexBotAliasArn = string;
export type LexIntentName = string;
export interface LexConfiguration {
    RespondsTo?: RespondsTo;
    InvokedBy?: InvokedBy;
    LexBotAliasArn: string;
    LocaleId: string;
    WelcomeIntent?: string;
}
export declare const LexConfiguration: S.Schema<LexConfiguration>;
export interface Configuration {
    Lex: LexConfiguration;
}
export declare const Configuration: S.Schema<Configuration>;
export interface CreateAppInstanceBotRequest {
    AppInstanceArn: string;
    Name?: string | redacted.Redacted<string>;
    Metadata?: string | redacted.Redacted<string>;
    ClientRequestToken: string;
    Tags?: Tag[];
    Configuration: Configuration;
}
export declare const CreateAppInstanceBotRequest: S.Schema<CreateAppInstanceBotRequest>;
export interface CreateAppInstanceBotResponse {
    AppInstanceBotArn?: string;
}
export declare const CreateAppInstanceBotResponse: S.Schema<CreateAppInstanceBotResponse>;
export type UserId = string | redacted.Redacted<string>;
export type UserName = string | redacted.Redacted<string>;
export type ExpirationDays = number;
export type ExpirationCriterion = "CREATED_TIMESTAMP" | (string & {});
export declare const ExpirationCriterion: any;
export interface ExpirationSettings {
    ExpirationDays: number;
    ExpirationCriterion: ExpirationCriterion;
}
export declare const ExpirationSettings: S.Schema<ExpirationSettings>;
export interface CreateAppInstanceUserRequest {
    AppInstanceArn: string;
    AppInstanceUserId: string | redacted.Redacted<string>;
    Name: string | redacted.Redacted<string>;
    Metadata?: string | redacted.Redacted<string>;
    ClientRequestToken: string;
    Tags?: Tag[];
    ExpirationSettings?: ExpirationSettings;
}
export declare const CreateAppInstanceUserRequest: S.Schema<CreateAppInstanceUserRequest>;
export interface CreateAppInstanceUserResponse {
    AppInstanceUserArn?: string;
}
export declare const CreateAppInstanceUserResponse: S.Schema<CreateAppInstanceUserResponse>;
export interface DeleteAppInstanceRequest {
    AppInstanceArn: string;
}
export declare const DeleteAppInstanceRequest: S.Schema<DeleteAppInstanceRequest>;
export interface DeleteAppInstanceResponse {
}
export declare const DeleteAppInstanceResponse: S.Schema<DeleteAppInstanceResponse>;
export interface DeleteAppInstanceAdminRequest {
    AppInstanceAdminArn: string;
    AppInstanceArn: string;
}
export declare const DeleteAppInstanceAdminRequest: S.Schema<DeleteAppInstanceAdminRequest>;
export interface DeleteAppInstanceAdminResponse {
}
export declare const DeleteAppInstanceAdminResponse: S.Schema<DeleteAppInstanceAdminResponse>;
export interface DeleteAppInstanceBotRequest {
    AppInstanceBotArn: string;
}
export declare const DeleteAppInstanceBotRequest: S.Schema<DeleteAppInstanceBotRequest>;
export interface DeleteAppInstanceBotResponse {
}
export declare const DeleteAppInstanceBotResponse: S.Schema<DeleteAppInstanceBotResponse>;
export interface DeleteAppInstanceUserRequest {
    AppInstanceUserArn: string;
}
export declare const DeleteAppInstanceUserRequest: S.Schema<DeleteAppInstanceUserRequest>;
export interface DeleteAppInstanceUserResponse {
}
export declare const DeleteAppInstanceUserResponse: S.Schema<DeleteAppInstanceUserResponse>;
export type String64 = string;
export interface DeregisterAppInstanceUserEndpointRequest {
    AppInstanceUserArn: string;
    EndpointId: string;
}
export declare const DeregisterAppInstanceUserEndpointRequest: S.Schema<DeregisterAppInstanceUserEndpointRequest>;
export interface DeregisterAppInstanceUserEndpointResponse {
}
export declare const DeregisterAppInstanceUserEndpointResponse: S.Schema<DeregisterAppInstanceUserEndpointResponse>;
export interface DescribeAppInstanceRequest {
    AppInstanceArn: string;
}
export declare const DescribeAppInstanceRequest: S.Schema<DescribeAppInstanceRequest>;
export interface AppInstance {
    AppInstanceArn?: string;
    Name?: string | redacted.Redacted<string>;
    CreatedTimestamp?: Date;
    LastUpdatedTimestamp?: Date;
    Metadata?: string | redacted.Redacted<string>;
}
export declare const AppInstance: S.Schema<AppInstance>;
export interface DescribeAppInstanceResponse {
    AppInstance?: AppInstance;
}
export declare const DescribeAppInstanceResponse: S.Schema<DescribeAppInstanceResponse>;
export interface DescribeAppInstanceAdminRequest {
    AppInstanceAdminArn: string;
    AppInstanceArn: string;
}
export declare const DescribeAppInstanceAdminRequest: S.Schema<DescribeAppInstanceAdminRequest>;
export interface AppInstanceAdmin {
    Admin?: Identity;
    AppInstanceArn?: string;
    CreatedTimestamp?: Date;
}
export declare const AppInstanceAdmin: S.Schema<AppInstanceAdmin>;
export interface DescribeAppInstanceAdminResponse {
    AppInstanceAdmin?: AppInstanceAdmin;
}
export declare const DescribeAppInstanceAdminResponse: S.Schema<DescribeAppInstanceAdminResponse>;
export interface DescribeAppInstanceBotRequest {
    AppInstanceBotArn: string;
}
export declare const DescribeAppInstanceBotRequest: S.Schema<DescribeAppInstanceBotRequest>;
export interface AppInstanceBot {
    AppInstanceBotArn?: string;
    Name?: string | redacted.Redacted<string>;
    Configuration?: Configuration;
    CreatedTimestamp?: Date;
    LastUpdatedTimestamp?: Date;
    Metadata?: string | redacted.Redacted<string>;
}
export declare const AppInstanceBot: S.Schema<AppInstanceBot>;
export interface DescribeAppInstanceBotResponse {
    AppInstanceBot?: AppInstanceBot;
}
export declare const DescribeAppInstanceBotResponse: S.Schema<DescribeAppInstanceBotResponse>;
export interface DescribeAppInstanceUserRequest {
    AppInstanceUserArn: string;
}
export declare const DescribeAppInstanceUserRequest: S.Schema<DescribeAppInstanceUserRequest>;
export interface AppInstanceUser {
    AppInstanceUserArn?: string;
    Name?: string | redacted.Redacted<string>;
    Metadata?: string | redacted.Redacted<string>;
    CreatedTimestamp?: Date;
    LastUpdatedTimestamp?: Date;
    ExpirationSettings?: ExpirationSettings;
}
export declare const AppInstanceUser: S.Schema<AppInstanceUser>;
export interface DescribeAppInstanceUserResponse {
    AppInstanceUser?: AppInstanceUser;
}
export declare const DescribeAppInstanceUserResponse: S.Schema<DescribeAppInstanceUserResponse>;
export type String1600 = string;
export interface DescribeAppInstanceUserEndpointRequest {
    AppInstanceUserArn: string;
    EndpointId: string;
}
export declare const DescribeAppInstanceUserEndpointRequest: S.Schema<DescribeAppInstanceUserEndpointRequest>;
export type SensitiveString1600 = string | redacted.Redacted<string>;
export type AppInstanceUserEndpointType = "APNS" | "APNS_SANDBOX" | "GCM" | (string & {});
export declare const AppInstanceUserEndpointType: any;
export type NonEmptySensitiveString1600 = string | redacted.Redacted<string>;
export interface EndpointAttributes {
    DeviceToken: string | redacted.Redacted<string>;
    VoipDeviceToken?: string | redacted.Redacted<string>;
}
export declare const EndpointAttributes: S.Schema<EndpointAttributes>;
export type AllowMessages = "ALL" | "NONE" | (string & {});
export declare const AllowMessages: any;
export type EndpointStatus = "ACTIVE" | "INACTIVE" | (string & {});
export declare const EndpointStatus: any;
export type EndpointStatusReason = "INVALID_DEVICE_TOKEN" | "INVALID_PINPOINT_ARN" | (string & {});
export declare const EndpointStatusReason: any;
export interface EndpointState {
    Status: EndpointStatus;
    StatusReason?: EndpointStatusReason;
}
export declare const EndpointState: S.Schema<EndpointState>;
export interface AppInstanceUserEndpoint {
    AppInstanceUserArn?: string;
    EndpointId?: string;
    Name?: string | redacted.Redacted<string>;
    Type?: AppInstanceUserEndpointType;
    ResourceArn?: string;
    EndpointAttributes?: EndpointAttributes;
    CreatedTimestamp?: Date;
    LastUpdatedTimestamp?: Date;
    AllowMessages?: AllowMessages;
    EndpointState?: EndpointState;
}
export declare const AppInstanceUserEndpoint: S.Schema<AppInstanceUserEndpoint>;
export interface DescribeAppInstanceUserEndpointResponse {
    AppInstanceUserEndpoint?: AppInstanceUserEndpoint;
}
export declare const DescribeAppInstanceUserEndpointResponse: S.Schema<DescribeAppInstanceUserEndpointResponse>;
export interface GetAppInstanceRetentionSettingsRequest {
    AppInstanceArn: string;
}
export declare const GetAppInstanceRetentionSettingsRequest: S.Schema<GetAppInstanceRetentionSettingsRequest>;
export type RetentionDays = number;
export interface ChannelRetentionSettings {
    RetentionDays?: number;
}
export declare const ChannelRetentionSettings: S.Schema<ChannelRetentionSettings>;
export interface AppInstanceRetentionSettings {
    ChannelRetentionSettings?: ChannelRetentionSettings;
}
export declare const AppInstanceRetentionSettings: S.Schema<AppInstanceRetentionSettings>;
export interface GetAppInstanceRetentionSettingsResponse {
    AppInstanceRetentionSettings?: AppInstanceRetentionSettings;
    InitiateDeletionTimestamp?: Date;
}
export declare const GetAppInstanceRetentionSettingsResponse: S.Schema<GetAppInstanceRetentionSettingsResponse>;
export type MaxResults = number;
export type NextToken = string | redacted.Redacted<string>;
export interface ListAppInstanceAdminsRequest {
    AppInstanceArn: string;
    MaxResults?: number;
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListAppInstanceAdminsRequest: S.Schema<ListAppInstanceAdminsRequest>;
export interface AppInstanceAdminSummary {
    Admin?: Identity;
}
export declare const AppInstanceAdminSummary: S.Schema<AppInstanceAdminSummary>;
export type AppInstanceAdminList = AppInstanceAdminSummary[];
export declare const AppInstanceAdminList: any;
export interface ListAppInstanceAdminsResponse {
    AppInstanceArn?: string;
    AppInstanceAdmins?: AppInstanceAdminSummary[];
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListAppInstanceAdminsResponse: S.Schema<ListAppInstanceAdminsResponse>;
export interface ListAppInstanceBotsRequest {
    AppInstanceArn: string;
    MaxResults?: number;
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListAppInstanceBotsRequest: S.Schema<ListAppInstanceBotsRequest>;
export interface AppInstanceBotSummary {
    AppInstanceBotArn?: string;
    Name?: string | redacted.Redacted<string>;
    Metadata?: string | redacted.Redacted<string>;
}
export declare const AppInstanceBotSummary: S.Schema<AppInstanceBotSummary>;
export type AppInstanceBotList = AppInstanceBotSummary[];
export declare const AppInstanceBotList: any;
export interface ListAppInstanceBotsResponse {
    AppInstanceArn?: string;
    AppInstanceBots?: AppInstanceBotSummary[];
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListAppInstanceBotsResponse: S.Schema<ListAppInstanceBotsResponse>;
export interface ListAppInstancesRequest {
    MaxResults?: number;
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListAppInstancesRequest: S.Schema<ListAppInstancesRequest>;
export interface AppInstanceSummary {
    AppInstanceArn?: string;
    Name?: string | redacted.Redacted<string>;
    Metadata?: string | redacted.Redacted<string>;
}
export declare const AppInstanceSummary: S.Schema<AppInstanceSummary>;
export type AppInstanceList = AppInstanceSummary[];
export declare const AppInstanceList: any;
export interface ListAppInstancesResponse {
    AppInstances?: AppInstanceSummary[];
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListAppInstancesResponse: S.Schema<ListAppInstancesResponse>;
export type SensitiveChimeArn = string | redacted.Redacted<string>;
export interface ListAppInstanceUserEndpointsRequest {
    AppInstanceUserArn: string | redacted.Redacted<string>;
    MaxResults?: number;
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListAppInstanceUserEndpointsRequest: S.Schema<ListAppInstanceUserEndpointsRequest>;
export interface AppInstanceUserEndpointSummary {
    AppInstanceUserArn?: string;
    EndpointId?: string;
    Name?: string | redacted.Redacted<string>;
    Type?: AppInstanceUserEndpointType;
    AllowMessages?: AllowMessages;
    EndpointState?: EndpointState;
}
export declare const AppInstanceUserEndpointSummary: S.Schema<AppInstanceUserEndpointSummary>;
export type AppInstanceUserEndpointSummaryList = AppInstanceUserEndpointSummary[];
export declare const AppInstanceUserEndpointSummaryList: any;
export interface ListAppInstanceUserEndpointsResponse {
    AppInstanceUserEndpoints?: AppInstanceUserEndpointSummary[];
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListAppInstanceUserEndpointsResponse: S.Schema<ListAppInstanceUserEndpointsResponse>;
export interface ListAppInstanceUsersRequest {
    AppInstanceArn: string;
    MaxResults?: number;
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListAppInstanceUsersRequest: S.Schema<ListAppInstanceUsersRequest>;
export interface AppInstanceUserSummary {
    AppInstanceUserArn?: string;
    Name?: string | redacted.Redacted<string>;
    Metadata?: string | redacted.Redacted<string>;
}
export declare const AppInstanceUserSummary: S.Schema<AppInstanceUserSummary>;
export type AppInstanceUserList = AppInstanceUserSummary[];
export declare const AppInstanceUserList: any;
export interface ListAppInstanceUsersResponse {
    AppInstanceArn?: string;
    AppInstanceUsers?: AppInstanceUserSummary[];
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListAppInstanceUsersResponse: S.Schema<ListAppInstanceUsersResponse>;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PutAppInstanceRetentionSettingsRequest {
    AppInstanceArn: string;
    AppInstanceRetentionSettings: AppInstanceRetentionSettings;
}
export declare const PutAppInstanceRetentionSettingsRequest: S.Schema<PutAppInstanceRetentionSettingsRequest>;
export interface PutAppInstanceRetentionSettingsResponse {
    AppInstanceRetentionSettings?: AppInstanceRetentionSettings;
    InitiateDeletionTimestamp?: Date;
}
export declare const PutAppInstanceRetentionSettingsResponse: S.Schema<PutAppInstanceRetentionSettingsResponse>;
export interface PutAppInstanceUserExpirationSettingsRequest {
    AppInstanceUserArn: string;
    ExpirationSettings?: ExpirationSettings;
}
export declare const PutAppInstanceUserExpirationSettingsRequest: S.Schema<PutAppInstanceUserExpirationSettingsRequest>;
export interface PutAppInstanceUserExpirationSettingsResponse {
    AppInstanceUserArn?: string;
    ExpirationSettings?: ExpirationSettings;
}
export declare const PutAppInstanceUserExpirationSettingsResponse: S.Schema<PutAppInstanceUserExpirationSettingsResponse>;
export interface RegisterAppInstanceUserEndpointRequest {
    AppInstanceUserArn: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string>;
    Type: AppInstanceUserEndpointType;
    ResourceArn: string;
    EndpointAttributes: EndpointAttributes;
    ClientRequestToken: string;
    AllowMessages?: AllowMessages;
}
export declare const RegisterAppInstanceUserEndpointRequest: S.Schema<RegisterAppInstanceUserEndpointRequest>;
export interface RegisterAppInstanceUserEndpointResponse {
    AppInstanceUserArn?: string;
    EndpointId?: string;
}
export declare const RegisterAppInstanceUserEndpointResponse: S.Schema<RegisterAppInstanceUserEndpointResponse>;
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = (string | redacted.Redacted<string>)[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: (string | redacted.Redacted<string>)[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAppInstanceRequest {
    AppInstanceArn: string;
    Name: string | redacted.Redacted<string>;
    Metadata: string | redacted.Redacted<string>;
}
export declare const UpdateAppInstanceRequest: S.Schema<UpdateAppInstanceRequest>;
export interface UpdateAppInstanceResponse {
    AppInstanceArn?: string;
}
export declare const UpdateAppInstanceResponse: S.Schema<UpdateAppInstanceResponse>;
export interface UpdateAppInstanceBotRequest {
    AppInstanceBotArn: string;
    Name: string | redacted.Redacted<string>;
    Metadata: string | redacted.Redacted<string>;
    Configuration?: Configuration;
}
export declare const UpdateAppInstanceBotRequest: S.Schema<UpdateAppInstanceBotRequest>;
export interface UpdateAppInstanceBotResponse {
    AppInstanceBotArn?: string;
}
export declare const UpdateAppInstanceBotResponse: S.Schema<UpdateAppInstanceBotResponse>;
export interface UpdateAppInstanceUserRequest {
    AppInstanceUserArn: string;
    Name: string | redacted.Redacted<string>;
    Metadata: string | redacted.Redacted<string>;
}
export declare const UpdateAppInstanceUserRequest: S.Schema<UpdateAppInstanceUserRequest>;
export interface UpdateAppInstanceUserResponse {
    AppInstanceUserArn?: string;
}
export declare const UpdateAppInstanceUserResponse: S.Schema<UpdateAppInstanceUserResponse>;
export interface UpdateAppInstanceUserEndpointRequest {
    AppInstanceUserArn: string;
    EndpointId: string;
    Name?: string | redacted.Redacted<string>;
    AllowMessages?: AllowMessages;
}
export declare const UpdateAppInstanceUserEndpointRequest: S.Schema<UpdateAppInstanceUserEndpointRequest>;
export interface UpdateAppInstanceUserEndpointResponse {
    AppInstanceUserArn?: string;
    EndpointId?: string;
}
export declare const UpdateAppInstanceUserEndpointResponse: S.Schema<UpdateAppInstanceUserEndpointResponse>;
export type ErrorCode = "BadRequest" | "Conflict" | "Forbidden" | "NotFound" | "PreconditionFailed" | "ResourceLimitExceeded" | "ServiceFailure" | "AccessDenied" | "ServiceUnavailable" | "Throttled" | "Throttling" | "Unauthorized" | "Unprocessable" | "VoiceConnectorGroupAssociationsExist" | "PhoneNumberAssociationsExist" | (string & {});
export declare const ErrorCode: any;
export type CreateAppInstanceError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an Amazon Chime SDK messaging `AppInstance` under an AWS account.
 * Only SDK messaging customers use this API. `CreateAppInstance` supports
 * idempotency behavior as described in the AWS API Standard.
 *
 * identity
 */
export declare const createAppInstance: API.OperationMethod<CreateAppInstanceRequest, CreateAppInstanceResponse, CreateAppInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateAppInstanceAdminError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Promotes an `AppInstanceUser` or `AppInstanceBot` to an
 * `AppInstanceAdmin`. The
 * promoted entity can perform the following actions.
 *
 * - `ChannelModerator` actions across all channels in the
 * `AppInstance`.
 *
 * - `DeleteChannelMessage` actions.
 *
 * Only an `AppInstanceUser` and `AppInstanceBot` can be promoted to an `AppInstanceAdmin`
 * role.
 */
export declare const createAppInstanceAdmin: API.OperationMethod<CreateAppInstanceAdminRequest, CreateAppInstanceAdminResponse, CreateAppInstanceAdminError, Credentials | HttpClient.HttpClient>;
export type CreateAppInstanceBotError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a bot under an Amazon Chime `AppInstance`. The request consists of a
 * unique `Configuration` and `Name` for that bot.
 */
export declare const createAppInstanceBot: API.OperationMethod<CreateAppInstanceBotRequest, CreateAppInstanceBotResponse, CreateAppInstanceBotError, Credentials | HttpClient.HttpClient>;
export type CreateAppInstanceUserError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a user under an Amazon Chime `AppInstance`. The request consists of a
 * unique `appInstanceUserId` and `Name` for that user.
 */
export declare const createAppInstanceUser: API.OperationMethod<CreateAppInstanceUserRequest, CreateAppInstanceUserResponse, CreateAppInstanceUserError, Credentials | HttpClient.HttpClient>;
export type DeleteAppInstanceError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an `AppInstance` and all associated data asynchronously.
 */
export declare const deleteAppInstance: API.OperationMethod<DeleteAppInstanceRequest, DeleteAppInstanceResponse, DeleteAppInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteAppInstanceAdminError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Demotes an `AppInstanceAdmin` to an `AppInstanceUser` or
 * `AppInstanceBot`. This action
 * does not delete the user.
 */
export declare const deleteAppInstanceAdmin: API.OperationMethod<DeleteAppInstanceAdminRequest, DeleteAppInstanceAdminResponse, DeleteAppInstanceAdminError, Credentials | HttpClient.HttpClient>;
export type DeleteAppInstanceBotError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an `AppInstanceBot`.
 */
export declare const deleteAppInstanceBot: API.OperationMethod<DeleteAppInstanceBotRequest, DeleteAppInstanceBotResponse, DeleteAppInstanceBotError, Credentials | HttpClient.HttpClient>;
export type DeleteAppInstanceUserError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an `AppInstanceUser`.
 */
export declare const deleteAppInstanceUser: API.OperationMethod<DeleteAppInstanceUserRequest, DeleteAppInstanceUserResponse, DeleteAppInstanceUserError, Credentials | HttpClient.HttpClient>;
export type DeregisterAppInstanceUserEndpointError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deregisters an `AppInstanceUserEndpoint`.
 */
export declare const deregisterAppInstanceUserEndpoint: API.OperationMethod<DeregisterAppInstanceUserEndpointRequest, DeregisterAppInstanceUserEndpointResponse, DeregisterAppInstanceUserEndpointError, Credentials | HttpClient.HttpClient>;
export type DescribeAppInstanceError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns the full details of an `AppInstance`.
 */
export declare const describeAppInstance: API.OperationMethod<DescribeAppInstanceRequest, DescribeAppInstanceResponse, DescribeAppInstanceError, Credentials | HttpClient.HttpClient>;
export type DescribeAppInstanceAdminError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns the full details of an `AppInstanceAdmin`.
 */
export declare const describeAppInstanceAdmin: API.OperationMethod<DescribeAppInstanceAdminRequest, DescribeAppInstanceAdminResponse, DescribeAppInstanceAdminError, Credentials | HttpClient.HttpClient>;
export type DescribeAppInstanceBotError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * The `AppInstanceBot's` information.
 */
export declare const describeAppInstanceBot: API.OperationMethod<DescribeAppInstanceBotRequest, DescribeAppInstanceBotResponse, DescribeAppInstanceBotError, Credentials | HttpClient.HttpClient>;
export type DescribeAppInstanceUserError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns the full details of an `AppInstanceUser`.
 */
export declare const describeAppInstanceUser: API.OperationMethod<DescribeAppInstanceUserRequest, DescribeAppInstanceUserResponse, DescribeAppInstanceUserError, Credentials | HttpClient.HttpClient>;
export type DescribeAppInstanceUserEndpointError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns the full details of an `AppInstanceUserEndpoint`.
 */
export declare const describeAppInstanceUserEndpoint: API.OperationMethod<DescribeAppInstanceUserEndpointRequest, DescribeAppInstanceUserEndpointResponse, DescribeAppInstanceUserEndpointError, Credentials | HttpClient.HttpClient>;
export type GetAppInstanceRetentionSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets the retention settings for an `AppInstance`.
 */
export declare const getAppInstanceRetentionSettings: API.OperationMethod<GetAppInstanceRetentionSettingsRequest, GetAppInstanceRetentionSettingsResponse, GetAppInstanceRetentionSettingsError, Credentials | HttpClient.HttpClient>;
export type ListAppInstanceAdminsError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns a list of the administrators in the `AppInstance`.
 */
export declare const listAppInstanceAdmins: API.PaginatedOperationMethod<ListAppInstanceAdminsRequest, ListAppInstanceAdminsResponse, ListAppInstanceAdminsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAppInstanceBotsError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists all `AppInstanceBots` created under a single `AppInstance`.
 */
export declare const listAppInstanceBots: API.PaginatedOperationMethod<ListAppInstanceBotsRequest, ListAppInstanceBotsResponse, ListAppInstanceBotsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAppInstancesError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists all Amazon Chime `AppInstance`s created under a single AWS
 * account.
 */
export declare const listAppInstances: API.PaginatedOperationMethod<ListAppInstancesRequest, ListAppInstancesResponse, ListAppInstancesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAppInstanceUserEndpointsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists all the `AppInstanceUserEndpoints` created under a single `AppInstanceUser`.
 */
export declare const listAppInstanceUserEndpoints: API.PaginatedOperationMethod<ListAppInstanceUserEndpointsRequest, ListAppInstanceUserEndpointsResponse, ListAppInstanceUserEndpointsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAppInstanceUsersError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * List all `AppInstanceUsers` created under a single
 * `AppInstance`.
 */
export declare const listAppInstanceUsers: API.PaginatedOperationMethod<ListAppInstanceUsersRequest, ListAppInstanceUsersResponse, ListAppInstanceUsersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the tags applied to an Amazon Chime SDK identity resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutAppInstanceRetentionSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Sets the amount of time in days that a given `AppInstance` retains
 * data.
 */
export declare const putAppInstanceRetentionSettings: API.OperationMethod<PutAppInstanceRetentionSettingsRequest, PutAppInstanceRetentionSettingsResponse, PutAppInstanceRetentionSettingsError, Credentials | HttpClient.HttpClient>;
export type PutAppInstanceUserExpirationSettingsError = BadRequestException | ConflictException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Sets the number of days before the `AppInstanceUser` is automatically deleted.
 *
 * A background process deletes expired `AppInstanceUsers` within 6 hours of expiration.
 * Actual deletion times may vary.
 *
 * Expired `AppInstanceUsers` that have not yet been deleted appear as active, and you can update
 * their expiration settings. The system honors the new settings.
 */
export declare const putAppInstanceUserExpirationSettings: API.OperationMethod<PutAppInstanceUserExpirationSettingsRequest, PutAppInstanceUserExpirationSettingsResponse, PutAppInstanceUserExpirationSettingsError, Credentials | HttpClient.HttpClient>;
export type RegisterAppInstanceUserEndpointError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Registers an endpoint under an Amazon Chime `AppInstanceUser`. The endpoint receives messages for a user. For push notifications, the endpoint is a mobile device used to receive mobile push notifications for a user.
 */
export declare const registerAppInstanceUserEndpoint: API.OperationMethod<RegisterAppInstanceUserEndpointRequest, RegisterAppInstanceUserEndpointResponse, RegisterAppInstanceUserEndpointError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Applies the specified tags to the specified Amazon Chime SDK identity resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Removes the specified tags from the specified Amazon Chime SDK identity resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAppInstanceError = BadRequestException | ConflictException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates `AppInstance` metadata.
 */
export declare const updateAppInstance: API.OperationMethod<UpdateAppInstanceRequest, UpdateAppInstanceResponse, UpdateAppInstanceError, Credentials | HttpClient.HttpClient>;
export type UpdateAppInstanceBotError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the name and metadata of an `AppInstanceBot`.
 */
export declare const updateAppInstanceBot: API.OperationMethod<UpdateAppInstanceBotRequest, UpdateAppInstanceBotResponse, UpdateAppInstanceBotError, Credentials | HttpClient.HttpClient>;
export type UpdateAppInstanceUserError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the details of an `AppInstanceUser`. You can update names and
 * metadata.
 */
export declare const updateAppInstanceUser: API.OperationMethod<UpdateAppInstanceUserRequest, UpdateAppInstanceUserResponse, UpdateAppInstanceUserError, Credentials | HttpClient.HttpClient>;
export type UpdateAppInstanceUserEndpointError = BadRequestException | ConflictException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the details of an `AppInstanceUserEndpoint`. You can update the name and `AllowMessage` values.
 */
export declare const updateAppInstanceUserEndpoint: API.OperationMethod<UpdateAppInstanceUserEndpointRequest, UpdateAppInstanceUserEndpointResponse, UpdateAppInstanceUserEndpointError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=chime-sdk-identity.d.ts.map