import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Name = string;
export interface CodeCommitRepository {
    Name: string;
}
export declare const CodeCommitRepository: S.Schema<CodeCommitRepository>;
export type ConnectionArn = string;
export type Owner = string;
export interface ThirdPartySourceRepository {
    Name: string;
    ConnectionArn: string;
    Owner: string;
}
export declare const ThirdPartySourceRepository: S.Schema<ThirdPartySourceRepository>;
export type S3BucketName = string;
export interface S3Repository {
    Name: string;
    BucketName: string;
}
export declare const S3Repository: S.Schema<S3Repository>;
export interface Repository {
    CodeCommit?: CodeCommitRepository;
    Bitbucket?: ThirdPartySourceRepository;
    GitHubEnterpriseServer?: ThirdPartySourceRepository;
    S3Bucket?: S3Repository;
}
export declare const Repository: S.Schema<Repository>;
export type ClientRequestToken = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type KMSKeyId = string;
export type EncryptionOption = "AWS_OWNED_CMK" | "CUSTOMER_MANAGED_CMK" | (string & {});
export declare const EncryptionOption: any;
export interface KMSKeyDetails {
    KMSKeyId?: string;
    EncryptionOption?: EncryptionOption;
}
export declare const KMSKeyDetails: S.Schema<KMSKeyDetails>;
export interface AssociateRepositoryRequest {
    Repository: Repository;
    ClientRequestToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    KMSKeyDetails?: KMSKeyDetails;
}
export declare const AssociateRepositoryRequest: S.Schema<AssociateRepositoryRequest>;
export type AssociationId = string;
export type Arn = string;
export type ProviderType = "CodeCommit" | "GitHub" | "Bitbucket" | "GitHubEnterpriseServer" | "S3Bucket" | (string & {});
export declare const ProviderType: any;
export type RepositoryAssociationState = "Associated" | "Associating" | "Failed" | "Disassociating" | "Disassociated" | (string & {});
export declare const RepositoryAssociationState: any;
export type StateReason = string;
export type SourceCodeArtifactsObjectKey = string;
export type BuildArtifactsObjectKey = string;
export interface CodeArtifacts {
    SourceCodeArtifactsObjectKey: string;
    BuildArtifactsObjectKey?: string;
}
export declare const CodeArtifacts: S.Schema<CodeArtifacts>;
export interface S3RepositoryDetails {
    BucketName?: string;
    CodeArtifacts?: CodeArtifacts;
}
export declare const S3RepositoryDetails: S.Schema<S3RepositoryDetails>;
export interface RepositoryAssociation {
    AssociationId?: string;
    AssociationArn?: string;
    ConnectionArn?: string;
    Name?: string;
    Owner?: string;
    ProviderType?: ProviderType;
    State?: RepositoryAssociationState;
    StateReason?: string;
    LastUpdatedTimeStamp?: Date;
    CreatedTimeStamp?: Date;
    KMSKeyDetails?: KMSKeyDetails;
    S3RepositoryDetails?: S3RepositoryDetails;
}
export declare const RepositoryAssociation: S.Schema<RepositoryAssociation>;
export interface AssociateRepositoryResponse {
    RepositoryAssociation?: RepositoryAssociation;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const AssociateRepositoryResponse: S.Schema<AssociateRepositoryResponse>;
export type CodeReviewName = string;
export type AssociationArn = string;
export type BranchName = string;
export interface RepositoryHeadSourceCodeType {
    BranchName: string;
}
export declare const RepositoryHeadSourceCodeType: S.Schema<RepositoryHeadSourceCodeType>;
export type CommitId = string;
export interface CommitDiffSourceCodeType {
    SourceCommit?: string;
    DestinationCommit?: string;
    MergeBaseCommit?: string;
}
export declare const CommitDiffSourceCodeType: S.Schema<CommitDiffSourceCodeType>;
export interface BranchDiffSourceCodeType {
    SourceBranchName: string;
    DestinationBranchName: string;
}
export declare const BranchDiffSourceCodeType: S.Schema<BranchDiffSourceCodeType>;
export interface S3BucketRepository {
    Name: string;
    Details?: S3RepositoryDetails;
}
export declare const S3BucketRepository: S.Schema<S3BucketRepository>;
export type RequestId = string;
export type Requester = string;
export type EventName = string;
export type EventState = string;
export interface EventInfo {
    Name?: string;
    State?: string;
}
export declare const EventInfo: S.Schema<EventInfo>;
export type VendorName = "GitHub" | "GitLab" | "NativeS3" | (string & {});
export declare const VendorName: any;
export interface RequestMetadata {
    RequestId?: string;
    Requester?: string;
    EventInfo?: EventInfo;
    VendorName?: VendorName;
}
export declare const RequestMetadata: S.Schema<RequestMetadata>;
export interface SourceCodeType {
    CommitDiff?: CommitDiffSourceCodeType;
    RepositoryHead?: RepositoryHeadSourceCodeType;
    BranchDiff?: BranchDiffSourceCodeType;
    S3BucketRepository?: S3BucketRepository;
    RequestMetadata?: RequestMetadata;
}
export declare const SourceCodeType: S.Schema<SourceCodeType>;
export interface RepositoryAnalysis {
    RepositoryHead?: RepositoryHeadSourceCodeType;
    SourceCodeType?: SourceCodeType;
}
export declare const RepositoryAnalysis: S.Schema<RepositoryAnalysis>;
export type AnalysisType = "Security" | "CodeQuality" | (string & {});
export declare const AnalysisType: any;
export type AnalysisTypes = AnalysisType[];
export declare const AnalysisTypes: any;
export interface CodeReviewType {
    RepositoryAnalysis: RepositoryAnalysis;
    AnalysisTypes?: AnalysisType[];
}
export declare const CodeReviewType: S.Schema<CodeReviewType>;
export interface CreateCodeReviewRequest {
    Name: string;
    RepositoryAssociationArn: string;
    Type: CodeReviewType;
    ClientRequestToken?: string;
}
export declare const CreateCodeReviewRequest: S.Schema<CreateCodeReviewRequest>;
export type JobState = "Completed" | "Pending" | "Failed" | "Deleting" | (string & {});
export declare const JobState: any;
export type Type = "PullRequest" | "RepositoryAnalysis" | (string & {});
export declare const Type: any;
export type PullRequestId = string;
export type LinesOfCodeCount = number;
export type FindingsCount = number;
export interface Metrics {
    MeteredLinesOfCodeCount?: number;
    SuppressedLinesOfCodeCount?: number;
    FindingsCount?: number;
}
export declare const Metrics: S.Schema<Metrics>;
export type ConfigFileState = "Present" | "Absent" | "PresentWithErrors" | (string & {});
export declare const ConfigFileState: any;
export interface CodeReview {
    Name?: string;
    CodeReviewArn?: string;
    RepositoryName?: string;
    Owner?: string;
    ProviderType?: ProviderType;
    State?: JobState;
    StateReason?: string;
    CreatedTimeStamp?: Date;
    LastUpdatedTimeStamp?: Date;
    Type?: Type;
    PullRequestId?: string;
    SourceCodeType?: SourceCodeType;
    AssociationArn?: string;
    Metrics?: Metrics;
    AnalysisTypes?: AnalysisType[];
    ConfigFileState?: ConfigFileState;
}
export declare const CodeReview: S.Schema<CodeReview>;
export interface CreateCodeReviewResponse {
    CodeReview?: CodeReview;
}
export declare const CreateCodeReviewResponse: S.Schema<CreateCodeReviewResponse>;
export interface DescribeCodeReviewRequest {
    CodeReviewArn: string;
}
export declare const DescribeCodeReviewRequest: S.Schema<DescribeCodeReviewRequest>;
export interface DescribeCodeReviewResponse {
    CodeReview?: CodeReview;
}
export declare const DescribeCodeReviewResponse: S.Schema<DescribeCodeReviewResponse>;
export type RecommendationId = string;
export type UserId = string;
export interface DescribeRecommendationFeedbackRequest {
    CodeReviewArn: string;
    RecommendationId: string;
    UserId?: string;
}
export declare const DescribeRecommendationFeedbackRequest: S.Schema<DescribeRecommendationFeedbackRequest>;
export type Reaction = "ThumbsUp" | "ThumbsDown" | (string & {});
export declare const Reaction: any;
export type Reactions = Reaction[];
export declare const Reactions: any;
export interface RecommendationFeedback {
    CodeReviewArn?: string;
    RecommendationId?: string;
    Reactions?: Reaction[];
    UserId?: string;
    CreatedTimeStamp?: Date;
    LastUpdatedTimeStamp?: Date;
}
export declare const RecommendationFeedback: S.Schema<RecommendationFeedback>;
export interface DescribeRecommendationFeedbackResponse {
    RecommendationFeedback?: RecommendationFeedback;
}
export declare const DescribeRecommendationFeedbackResponse: S.Schema<DescribeRecommendationFeedbackResponse>;
export interface DescribeRepositoryAssociationRequest {
    AssociationArn: string;
}
export declare const DescribeRepositoryAssociationRequest: S.Schema<DescribeRepositoryAssociationRequest>;
export interface DescribeRepositoryAssociationResponse {
    RepositoryAssociation?: RepositoryAssociation;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DescribeRepositoryAssociationResponse: S.Schema<DescribeRepositoryAssociationResponse>;
export interface DisassociateRepositoryRequest {
    AssociationArn: string;
}
export declare const DisassociateRepositoryRequest: S.Schema<DisassociateRepositoryRequest>;
export interface DisassociateRepositoryResponse {
    RepositoryAssociation?: RepositoryAssociation;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DisassociateRepositoryResponse: S.Schema<DisassociateRepositoryResponse>;
export type ProviderTypes = ProviderType[];
export declare const ProviderTypes: any;
export type JobStates = JobState[];
export declare const JobStates: any;
export type RepositoryNames = string[];
export declare const RepositoryNames: any;
export type ListCodeReviewsMaxResults = number;
export type NextToken = string;
export interface ListCodeReviewsRequest {
    ProviderTypes?: ProviderType[];
    States?: JobState[];
    RepositoryNames?: string[];
    Type: Type;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListCodeReviewsRequest: S.Schema<ListCodeReviewsRequest>;
export interface MetricsSummary {
    MeteredLinesOfCodeCount?: number;
    SuppressedLinesOfCodeCount?: number;
    FindingsCount?: number;
}
export declare const MetricsSummary: S.Schema<MetricsSummary>;
export interface CodeReviewSummary {
    Name?: string;
    CodeReviewArn?: string;
    RepositoryName?: string;
    Owner?: string;
    ProviderType?: ProviderType;
    State?: JobState;
    CreatedTimeStamp?: Date;
    LastUpdatedTimeStamp?: Date;
    Type?: Type;
    PullRequestId?: string;
    MetricsSummary?: MetricsSummary;
    SourceCodeType?: SourceCodeType;
}
export declare const CodeReviewSummary: S.Schema<CodeReviewSummary>;
export type CodeReviewSummaries = CodeReviewSummary[];
export declare const CodeReviewSummaries: any;
export interface ListCodeReviewsResponse {
    CodeReviewSummaries?: CodeReviewSummary[];
    NextToken?: string;
}
export declare const ListCodeReviewsResponse: S.Schema<ListCodeReviewsResponse>;
export type MaxResults = number;
export type UserIds = string[];
export declare const UserIds: any;
export type RecommendationIds = string[];
export declare const RecommendationIds: any;
export interface ListRecommendationFeedbackRequest {
    NextToken?: string;
    MaxResults?: number;
    CodeReviewArn: string;
    UserIds?: string[];
    RecommendationIds?: string[];
}
export declare const ListRecommendationFeedbackRequest: S.Schema<ListRecommendationFeedbackRequest>;
export interface RecommendationFeedbackSummary {
    RecommendationId?: string;
    Reactions?: Reaction[];
    UserId?: string;
}
export declare const RecommendationFeedbackSummary: S.Schema<RecommendationFeedbackSummary>;
export type RecommendationFeedbackSummaries = RecommendationFeedbackSummary[];
export declare const RecommendationFeedbackSummaries: any;
export interface ListRecommendationFeedbackResponse {
    RecommendationFeedbackSummaries?: RecommendationFeedbackSummary[];
    NextToken?: string;
}
export declare const ListRecommendationFeedbackResponse: S.Schema<ListRecommendationFeedbackResponse>;
export type ListRecommendationsMaxResults = number;
export interface ListRecommendationsRequest {
    NextToken?: string;
    MaxResults?: number;
    CodeReviewArn: string;
}
export declare const ListRecommendationsRequest: S.Schema<ListRecommendationsRequest>;
export type FilePath = string;
export type LineNumber = number;
export type Text = string;
export type RecommendationCategory = "AWSBestPractices" | "AWSCloudFormationIssues" | "DuplicateCode" | "CodeMaintenanceIssues" | "ConcurrencyIssues" | "InputValidations" | "PythonBestPractices" | "JavaBestPractices" | "ResourceLeaks" | "SecurityIssues" | "CodeInconsistencies" | (string & {});
export declare const RecommendationCategory: any;
export type RuleId = string;
export type RuleName = string;
export type ShortDescription = string;
export type LongDescription = string;
export type RuleTag = string;
export type RuleTags = string[];
export declare const RuleTags: any;
export interface RuleMetadata {
    RuleId?: string;
    RuleName?: string;
    ShortDescription?: string;
    LongDescription?: string;
    RuleTags?: string[];
}
export declare const RuleMetadata: S.Schema<RuleMetadata>;
export type Severity = "Info" | "Low" | "Medium" | "High" | "Critical" | (string & {});
export declare const Severity: any;
export interface RecommendationSummary {
    FilePath?: string;
    RecommendationId?: string;
    StartLine?: number;
    EndLine?: number;
    Description?: string;
    RecommendationCategory?: RecommendationCategory;
    RuleMetadata?: RuleMetadata;
    Severity?: Severity;
}
export declare const RecommendationSummary: S.Schema<RecommendationSummary>;
export type RecommendationSummaries = RecommendationSummary[];
export declare const RecommendationSummaries: any;
export interface ListRecommendationsResponse {
    RecommendationSummaries?: RecommendationSummary[];
    NextToken?: string;
}
export declare const ListRecommendationsResponse: S.Schema<ListRecommendationsResponse>;
export type RepositoryAssociationStates = RepositoryAssociationState[];
export declare const RepositoryAssociationStates: any;
export type Names = string[];
export declare const Names: any;
export type Owners = string[];
export declare const Owners: any;
export interface ListRepositoryAssociationsRequest {
    ProviderTypes?: ProviderType[];
    States?: RepositoryAssociationState[];
    Names?: string[];
    Owners?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListRepositoryAssociationsRequest: S.Schema<ListRepositoryAssociationsRequest>;
export interface RepositoryAssociationSummary {
    AssociationArn?: string;
    ConnectionArn?: string;
    LastUpdatedTimeStamp?: Date;
    AssociationId?: string;
    Name?: string;
    Owner?: string;
    ProviderType?: ProviderType;
    State?: RepositoryAssociationState;
}
export declare const RepositoryAssociationSummary: S.Schema<RepositoryAssociationSummary>;
export type RepositoryAssociationSummaries = RepositoryAssociationSummary[];
export declare const RepositoryAssociationSummaries: any;
export interface ListRepositoryAssociationsResponse {
    RepositoryAssociationSummaries?: RepositoryAssociationSummary[];
    NextToken?: string;
}
export declare const ListRepositoryAssociationsResponse: S.Schema<ListRepositoryAssociationsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PutRecommendationFeedbackRequest {
    CodeReviewArn: string;
    RecommendationId: string;
    Reactions: Reaction[];
}
export declare const PutRecommendationFeedbackRequest: S.Schema<PutRecommendationFeedbackRequest>;
export interface PutRecommendationFeedbackResponse {
}
export declare const PutRecommendationFeedbackResponse: S.Schema<PutRecommendationFeedbackResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type ErrorMessage = string;
export type AssociateRepositoryError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use to associate an Amazon Web Services CodeCommit repository or a repository managed by Amazon Web Services
 * CodeStar Connections with Amazon CodeGuru Reviewer. When you associate a repository, CodeGuru Reviewer reviews
 * source code changes in the repository's pull requests and provides automatic
 * recommendations. You can view recommendations using the CodeGuru Reviewer console. For more
 * information, see Recommendations in
 * Amazon CodeGuru Reviewer in the *Amazon CodeGuru Reviewer User Guide.*
 *
 * If you associate a CodeCommit or S3 repository, it must be in the same Amazon Web Services Region and
 * Amazon Web Services account where its CodeGuru Reviewer code reviews are configured.
 *
 * Bitbucket and GitHub Enterprise Server repositories are managed by Amazon Web Services CodeStar
 * Connections to connect to CodeGuru Reviewer. For more information, see Associate a
 * repository in the *Amazon CodeGuru Reviewer User Guide.*
 *
 * You cannot use the CodeGuru Reviewer SDK or the Amazon Web Services CLI to associate a GitHub repository with
 * Amazon CodeGuru Reviewer. To associate a GitHub repository, use the console. For more information, see
 * Getting started with
 * CodeGuru Reviewer in the *CodeGuru Reviewer User Guide.*
 */
export declare const associateRepository: API.OperationMethod<AssociateRepositoryRequest, AssociateRepositoryResponse, AssociateRepositoryError, Credentials | HttpClient.HttpClient>;
export type CreateCodeReviewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use to create a code review with a CodeReviewType of
 * `RepositoryAnalysis`. This type of code review analyzes all code under a
 * specified branch in an associated repository. `PullRequest` code reviews are
 * automatically triggered by a pull request.
 */
export declare const createCodeReview: API.OperationMethod<CreateCodeReviewRequest, CreateCodeReviewResponse, CreateCodeReviewError, Credentials | HttpClient.HttpClient>;
export type DescribeCodeReviewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the metadata associated with the code review along with its status.
 */
export declare const describeCodeReview: API.OperationMethod<DescribeCodeReviewRequest, DescribeCodeReviewResponse, DescribeCodeReviewError, Credentials | HttpClient.HttpClient>;
export type DescribeRecommendationFeedbackError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the customer feedback for a CodeGuru Reviewer recommendation.
 */
export declare const describeRecommendationFeedback: API.OperationMethod<DescribeRecommendationFeedbackRequest, DescribeRecommendationFeedbackResponse, DescribeRecommendationFeedbackError, Credentials | HttpClient.HttpClient>;
export type DescribeRepositoryAssociationError = AccessDeniedException | InternalServerException | NotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a RepositoryAssociation object that contains information about the requested
 * repository association.
 */
export declare const describeRepositoryAssociation: API.OperationMethod<DescribeRepositoryAssociationRequest, DescribeRepositoryAssociationResponse, DescribeRepositoryAssociationError, Credentials | HttpClient.HttpClient>;
export type DisassociateRepositoryError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the association between Amazon CodeGuru Reviewer and a repository.
 */
export declare const disassociateRepository: API.OperationMethod<DisassociateRepositoryRequest, DisassociateRepositoryResponse, DisassociateRepositoryError, Credentials | HttpClient.HttpClient>;
export type ListCodeReviewsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the code reviews that the customer has created in the past 90 days.
 */
export declare const listCodeReviews: API.PaginatedOperationMethod<ListCodeReviewsRequest, ListCodeReviewsResponse, ListCodeReviewsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRecommendationFeedbackError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of RecommendationFeedbackSummary objects that contain customer recommendation
 * feedback for all CodeGuru Reviewer users.
 */
export declare const listRecommendationFeedback: API.PaginatedOperationMethod<ListRecommendationFeedbackRequest, ListRecommendationFeedbackResponse, ListRecommendationFeedbackError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRecommendationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the list of all recommendations for a completed code review.
 */
export declare const listRecommendations: API.PaginatedOperationMethod<ListRecommendationsRequest, ListRecommendationsResponse, ListRecommendationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRepositoryAssociationsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of RepositoryAssociationSummary objects that contain summary information about a
 * repository association. You can filter the returned list by ProviderType, Name, State, and Owner.
 */
export declare const listRepositoryAssociations: API.PaginatedOperationMethod<ListRepositoryAssociationsRequest, ListRepositoryAssociationsResponse, ListRepositoryAssociationsError, Credentials | HttpClient.HttpClient, RepositoryAssociationSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the list of tags associated with an associated repository resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutRecommendationFeedbackError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stores customer feedback for a CodeGuru Reviewer recommendation. When this API is called again with
 * different reactions the previous feedback is overwritten.
 */
export declare const putRecommendationFeedback: API.OperationMethod<PutRecommendationFeedbackRequest, PutRecommendationFeedbackResponse, PutRecommendationFeedbackError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds one or more tags to an associated repository.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag from an associated repository.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codeguru-reviewer.d.ts.map