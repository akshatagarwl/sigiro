import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ClientToken = string;
export type ExperimentTemplateDescription = string;
export type StopConditionSource = string;
export type StopConditionValue = string;
export interface CreateExperimentTemplateStopConditionInput {
    source: string;
    value?: string;
}
export declare const CreateExperimentTemplateStopConditionInput: S.Schema<CreateExperimentTemplateStopConditionInput>;
export type CreateExperimentTemplateStopConditionInputList = CreateExperimentTemplateStopConditionInput[];
export declare const CreateExperimentTemplateStopConditionInputList: any;
export type ExperimentTemplateTargetName = string;
export type TargetResourceTypeId = string;
export type ResourceArn = string;
export type ResourceArnList = string[];
export declare const ResourceArnList: any;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type ExperimentTemplateTargetFilterPath = string;
export type ExperimentTemplateTargetFilterValue = string;
export type ExperimentTemplateTargetFilterValues = string[];
export declare const ExperimentTemplateTargetFilterValues: any;
export interface ExperimentTemplateTargetInputFilter {
    path: string;
    values: string[];
}
export declare const ExperimentTemplateTargetInputFilter: S.Schema<ExperimentTemplateTargetInputFilter>;
export type ExperimentTemplateTargetFilterInputList = ExperimentTemplateTargetInputFilter[];
export declare const ExperimentTemplateTargetFilterInputList: any;
export type ExperimentTemplateTargetSelectionMode = string;
export type ExperimentTemplateTargetParameterName = string;
export type ExperimentTemplateTargetParameterValue = string;
export type ExperimentTemplateTargetParameterMap = {
    [key: string]: string | undefined;
};
export declare const ExperimentTemplateTargetParameterMap: any;
export interface CreateExperimentTemplateTargetInput {
    resourceType: string;
    resourceArns?: string[];
    resourceTags?: {
        [key: string]: string | undefined;
    };
    filters?: ExperimentTemplateTargetInputFilter[];
    selectionMode: string;
    parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateExperimentTemplateTargetInput: S.Schema<CreateExperimentTemplateTargetInput>;
export type CreateExperimentTemplateTargetInputMap = {
    [key: string]: CreateExperimentTemplateTargetInput | undefined;
};
export declare const CreateExperimentTemplateTargetInputMap: any;
export type ExperimentTemplateActionName = string;
export type ActionId = string;
export type ExperimentTemplateActionDescription = string;
export type ExperimentTemplateActionParameterName = string;
export type ExperimentTemplateActionParameter = string;
export type ExperimentTemplateActionParameterMap = {
    [key: string]: string | undefined;
};
export declare const ExperimentTemplateActionParameterMap: any;
export type ExperimentTemplateActionTargetName = string;
export type ExperimentTemplateActionTargetMap = {
    [key: string]: string | undefined;
};
export declare const ExperimentTemplateActionTargetMap: any;
export type ExperimentTemplateActionStartAfter = string;
export type ExperimentTemplateActionStartAfterList = string[];
export declare const ExperimentTemplateActionStartAfterList: any;
export interface CreateExperimentTemplateActionInput {
    actionId: string;
    description?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
    targets?: {
        [key: string]: string | undefined;
    };
    startAfter?: string[];
}
export declare const CreateExperimentTemplateActionInput: S.Schema<CreateExperimentTemplateActionInput>;
export type CreateExperimentTemplateActionInputMap = {
    [key: string]: CreateExperimentTemplateActionInput | undefined;
};
export declare const CreateExperimentTemplateActionInputMap: any;
export type RoleArn = string;
export type CloudWatchLogGroupArn = string;
export interface ExperimentTemplateCloudWatchLogsLogConfigurationInput {
    logGroupArn: string;
}
export declare const ExperimentTemplateCloudWatchLogsLogConfigurationInput: S.Schema<ExperimentTemplateCloudWatchLogsLogConfigurationInput>;
export type S3BucketName = string;
export type S3ObjectKey = string;
export interface ExperimentTemplateS3LogConfigurationInput {
    bucketName: string;
    prefix?: string;
}
export declare const ExperimentTemplateS3LogConfigurationInput: S.Schema<ExperimentTemplateS3LogConfigurationInput>;
export type LogSchemaVersion = number;
export interface CreateExperimentTemplateLogConfigurationInput {
    cloudWatchLogsConfiguration?: ExperimentTemplateCloudWatchLogsLogConfigurationInput;
    s3Configuration?: ExperimentTemplateS3LogConfigurationInput;
    logSchemaVersion: number;
}
export declare const CreateExperimentTemplateLogConfigurationInput: S.Schema<CreateExperimentTemplateLogConfigurationInput>;
export type AccountTargeting = "single-account" | "multi-account" | (string & {});
export declare const AccountTargeting: any;
export type EmptyTargetResolutionMode = "fail" | "skip" | (string & {});
export declare const EmptyTargetResolutionMode: any;
export interface CreateExperimentTemplateExperimentOptionsInput {
    accountTargeting?: AccountTargeting;
    emptyTargetResolutionMode?: EmptyTargetResolutionMode;
}
export declare const CreateExperimentTemplateExperimentOptionsInput: S.Schema<CreateExperimentTemplateExperimentOptionsInput>;
export type ReportConfigurationS3OutputPrefix = string;
export interface ReportConfigurationS3OutputInput {
    bucketName?: string;
    prefix?: string;
}
export declare const ReportConfigurationS3OutputInput: S.Schema<ReportConfigurationS3OutputInput>;
export interface ExperimentTemplateReportConfigurationOutputsInput {
    s3Configuration?: ReportConfigurationS3OutputInput;
}
export declare const ExperimentTemplateReportConfigurationOutputsInput: S.Schema<ExperimentTemplateReportConfigurationOutputsInput>;
export type ReportConfigurationCloudWatchDashboardIdentifier = string;
export interface ReportConfigurationCloudWatchDashboardInput {
    dashboardIdentifier?: string;
}
export declare const ReportConfigurationCloudWatchDashboardInput: S.Schema<ReportConfigurationCloudWatchDashboardInput>;
export type ReportConfigurationCloudWatchDashboardInputList = ReportConfigurationCloudWatchDashboardInput[];
export declare const ReportConfigurationCloudWatchDashboardInputList: any;
export interface ExperimentTemplateReportConfigurationDataSourcesInput {
    cloudWatchDashboards?: ReportConfigurationCloudWatchDashboardInput[];
}
export declare const ExperimentTemplateReportConfigurationDataSourcesInput: S.Schema<ExperimentTemplateReportConfigurationDataSourcesInput>;
export type ReportConfigurationDuration = string;
export interface CreateExperimentTemplateReportConfigurationInput {
    outputs?: ExperimentTemplateReportConfigurationOutputsInput;
    dataSources?: ExperimentTemplateReportConfigurationDataSourcesInput;
    preExperimentDuration?: string;
    postExperimentDuration?: string;
}
export declare const CreateExperimentTemplateReportConfigurationInput: S.Schema<CreateExperimentTemplateReportConfigurationInput>;
export interface CreateExperimentTemplateRequest {
    clientToken: string;
    description: string;
    stopConditions: CreateExperimentTemplateStopConditionInput[];
    targets?: {
        [key: string]: CreateExperimentTemplateTargetInput | undefined;
    };
    actions: {
        [key: string]: CreateExperimentTemplateActionInput | undefined;
    };
    roleArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
    logConfiguration?: CreateExperimentTemplateLogConfigurationInput;
    experimentOptions?: CreateExperimentTemplateExperimentOptionsInput;
    experimentReportConfiguration?: CreateExperimentTemplateReportConfigurationInput;
}
export declare const CreateExperimentTemplateRequest: S.Schema<CreateExperimentTemplateRequest>;
export type ExperimentTemplateId = string;
export interface ExperimentTemplateTargetFilter {
    path?: string;
    values?: string[];
}
export declare const ExperimentTemplateTargetFilter: S.Schema<ExperimentTemplateTargetFilter>;
export type ExperimentTemplateTargetFilterList = ExperimentTemplateTargetFilter[];
export declare const ExperimentTemplateTargetFilterList: any;
export interface ExperimentTemplateTarget {
    resourceType?: string;
    resourceArns?: string[];
    resourceTags?: {
        [key: string]: string | undefined;
    };
    filters?: ExperimentTemplateTargetFilter[];
    selectionMode?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const ExperimentTemplateTarget: S.Schema<ExperimentTemplateTarget>;
export type ExperimentTemplateTargetMap = {
    [key: string]: ExperimentTemplateTarget | undefined;
};
export declare const ExperimentTemplateTargetMap: any;
export interface ExperimentTemplateAction {
    actionId?: string;
    description?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
    targets?: {
        [key: string]: string | undefined;
    };
    startAfter?: string[];
}
export declare const ExperimentTemplateAction: S.Schema<ExperimentTemplateAction>;
export type ExperimentTemplateActionMap = {
    [key: string]: ExperimentTemplateAction | undefined;
};
export declare const ExperimentTemplateActionMap: any;
export interface ExperimentTemplateStopCondition {
    source?: string;
    value?: string;
}
export declare const ExperimentTemplateStopCondition: S.Schema<ExperimentTemplateStopCondition>;
export type ExperimentTemplateStopConditionList = ExperimentTemplateStopCondition[];
export declare const ExperimentTemplateStopConditionList: any;
export type CreationTime = Date;
export type LastUpdateTime = Date;
export interface ExperimentTemplateCloudWatchLogsLogConfiguration {
    logGroupArn?: string;
}
export declare const ExperimentTemplateCloudWatchLogsLogConfiguration: S.Schema<ExperimentTemplateCloudWatchLogsLogConfiguration>;
export interface ExperimentTemplateS3LogConfiguration {
    bucketName?: string;
    prefix?: string;
}
export declare const ExperimentTemplateS3LogConfiguration: S.Schema<ExperimentTemplateS3LogConfiguration>;
export interface ExperimentTemplateLogConfiguration {
    cloudWatchLogsConfiguration?: ExperimentTemplateCloudWatchLogsLogConfiguration;
    s3Configuration?: ExperimentTemplateS3LogConfiguration;
    logSchemaVersion?: number;
}
export declare const ExperimentTemplateLogConfiguration: S.Schema<ExperimentTemplateLogConfiguration>;
export interface ExperimentTemplateExperimentOptions {
    accountTargeting?: AccountTargeting;
    emptyTargetResolutionMode?: EmptyTargetResolutionMode;
}
export declare const ExperimentTemplateExperimentOptions: S.Schema<ExperimentTemplateExperimentOptions>;
export type TargetAccountConfigurationsCount = number;
export interface ReportConfigurationS3Output {
    bucketName?: string;
    prefix?: string;
}
export declare const ReportConfigurationS3Output: S.Schema<ReportConfigurationS3Output>;
export interface ExperimentTemplateReportConfigurationOutputs {
    s3Configuration?: ReportConfigurationS3Output;
}
export declare const ExperimentTemplateReportConfigurationOutputs: S.Schema<ExperimentTemplateReportConfigurationOutputs>;
export interface ExperimentTemplateReportConfigurationCloudWatchDashboard {
    dashboardIdentifier?: string;
}
export declare const ExperimentTemplateReportConfigurationCloudWatchDashboard: S.Schema<ExperimentTemplateReportConfigurationCloudWatchDashboard>;
export type ExperimentTemplateReportConfigurationCloudWatchDashboardList = ExperimentTemplateReportConfigurationCloudWatchDashboard[];
export declare const ExperimentTemplateReportConfigurationCloudWatchDashboardList: any;
export interface ExperimentTemplateReportConfigurationDataSources {
    cloudWatchDashboards?: ExperimentTemplateReportConfigurationCloudWatchDashboard[];
}
export declare const ExperimentTemplateReportConfigurationDataSources: S.Schema<ExperimentTemplateReportConfigurationDataSources>;
export interface ExperimentTemplateReportConfiguration {
    outputs?: ExperimentTemplateReportConfigurationOutputs;
    dataSources?: ExperimentTemplateReportConfigurationDataSources;
    preExperimentDuration?: string;
    postExperimentDuration?: string;
}
export declare const ExperimentTemplateReportConfiguration: S.Schema<ExperimentTemplateReportConfiguration>;
export interface ExperimentTemplate {
    id?: string;
    arn?: string;
    description?: string;
    targets?: {
        [key: string]: ExperimentTemplateTarget | undefined;
    };
    actions?: {
        [key: string]: ExperimentTemplateAction | undefined;
    };
    stopConditions?: ExperimentTemplateStopCondition[];
    creationTime?: Date;
    lastUpdateTime?: Date;
    roleArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    logConfiguration?: ExperimentTemplateLogConfiguration;
    experimentOptions?: ExperimentTemplateExperimentOptions;
    targetAccountConfigurationsCount?: number;
    experimentReportConfiguration?: ExperimentTemplateReportConfiguration;
}
export declare const ExperimentTemplate: S.Schema<ExperimentTemplate>;
export interface CreateExperimentTemplateResponse {
    experimentTemplate?: ExperimentTemplate;
}
export declare const CreateExperimentTemplateResponse: S.Schema<CreateExperimentTemplateResponse>;
export type TargetAccountId = string;
export type TargetAccountConfigurationDescription = string;
export interface CreateTargetAccountConfigurationRequest {
    clientToken?: string;
    experimentTemplateId: string;
    accountId: string;
    roleArn: string;
    description?: string;
}
export declare const CreateTargetAccountConfigurationRequest: S.Schema<CreateTargetAccountConfigurationRequest>;
export interface TargetAccountConfiguration {
    roleArn?: string;
    accountId?: string;
    description?: string;
}
export declare const TargetAccountConfiguration: S.Schema<TargetAccountConfiguration>;
export interface CreateTargetAccountConfigurationResponse {
    targetAccountConfiguration?: TargetAccountConfiguration;
}
export declare const CreateTargetAccountConfigurationResponse: S.Schema<CreateTargetAccountConfigurationResponse>;
export interface DeleteExperimentTemplateRequest {
    id: string;
}
export declare const DeleteExperimentTemplateRequest: S.Schema<DeleteExperimentTemplateRequest>;
export interface DeleteExperimentTemplateResponse {
    experimentTemplate?: ExperimentTemplate;
}
export declare const DeleteExperimentTemplateResponse: S.Schema<DeleteExperimentTemplateResponse>;
export interface DeleteTargetAccountConfigurationRequest {
    experimentTemplateId: string;
    accountId: string;
}
export declare const DeleteTargetAccountConfigurationRequest: S.Schema<DeleteTargetAccountConfigurationRequest>;
export interface DeleteTargetAccountConfigurationResponse {
    targetAccountConfiguration?: TargetAccountConfiguration;
}
export declare const DeleteTargetAccountConfigurationResponse: S.Schema<DeleteTargetAccountConfigurationResponse>;
export interface GetActionRequest {
    id: string;
}
export declare const GetActionRequest: S.Schema<GetActionRequest>;
export type ActionDescription = string;
export type ActionParameterName = string;
export type ActionParameterDescription = string;
export type ActionParameterRequired = boolean;
export interface ActionParameter {
    description?: string;
    required?: boolean;
}
export declare const ActionParameter: S.Schema<ActionParameter>;
export type ActionParameterMap = {
    [key: string]: ActionParameter | undefined;
};
export declare const ActionParameterMap: any;
export type ActionTargetName = string;
export interface ActionTarget {
    resourceType?: string;
}
export declare const ActionTarget: S.Schema<ActionTarget>;
export type ActionTargetMap = {
    [key: string]: ActionTarget | undefined;
};
export declare const ActionTargetMap: any;
export interface Action {
    id?: string;
    arn?: string;
    description?: string;
    parameters?: {
        [key: string]: ActionParameter | undefined;
    };
    targets?: {
        [key: string]: ActionTarget | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Action: S.Schema<Action>;
export interface GetActionResponse {
    action?: Action;
}
export declare const GetActionResponse: S.Schema<GetActionResponse>;
export type ExperimentId = string;
export interface GetExperimentRequest {
    id: string;
}
export declare const GetExperimentRequest: S.Schema<GetExperimentRequest>;
export type ExperimentStatus = "pending" | "initiating" | "running" | "completed" | "stopping" | "stopped" | "failed" | "cancelled" | (string & {});
export declare const ExperimentStatus: any;
export type ExperimentStatusReason = string;
export type ExperimentErrorAccountId = string;
export type ExperimentErrorCode = string;
export type ExperimentErrorLocation = string;
export interface ExperimentError {
    accountId?: string;
    code?: string;
    location?: string;
}
export declare const ExperimentError: S.Schema<ExperimentError>;
export interface ExperimentState {
    status?: ExperimentStatus;
    reason?: string;
    error?: ExperimentError;
}
export declare const ExperimentState: S.Schema<ExperimentState>;
export type ExperimentTargetName = string;
export type ExperimentTargetFilterPath = string;
export type ExperimentTargetFilterValue = string;
export type ExperimentTargetFilterValues = string[];
export declare const ExperimentTargetFilterValues: any;
export interface ExperimentTargetFilter {
    path?: string;
    values?: string[];
}
export declare const ExperimentTargetFilter: S.Schema<ExperimentTargetFilter>;
export type ExperimentTargetFilterList = ExperimentTargetFilter[];
export declare const ExperimentTargetFilterList: any;
export type ExperimentTargetSelectionMode = string;
export type ExperimentTargetParameterName = string;
export type ExperimentTargetParameterValue = string;
export type ExperimentTargetParameterMap = {
    [key: string]: string | undefined;
};
export declare const ExperimentTargetParameterMap: any;
export interface ExperimentTarget {
    resourceType?: string;
    resourceArns?: string[];
    resourceTags?: {
        [key: string]: string | undefined;
    };
    filters?: ExperimentTargetFilter[];
    selectionMode?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const ExperimentTarget: S.Schema<ExperimentTarget>;
export type ExperimentTargetMap = {
    [key: string]: ExperimentTarget | undefined;
};
export declare const ExperimentTargetMap: any;
export type ExperimentActionName = string;
export type ExperimentActionDescription = string;
export type ExperimentActionParameterName = string;
export type ExperimentActionParameter = string;
export type ExperimentActionParameterMap = {
    [key: string]: string | undefined;
};
export declare const ExperimentActionParameterMap: any;
export type ExperimentActionTargetName = string;
export type ExperimentActionTargetMap = {
    [key: string]: string | undefined;
};
export declare const ExperimentActionTargetMap: any;
export type ExperimentActionStartAfter = string;
export type ExperimentActionStartAfterList = string[];
export declare const ExperimentActionStartAfterList: any;
export type ExperimentActionStatus = "pending" | "initiating" | "running" | "completed" | "cancelled" | "stopping" | "stopped" | "failed" | "skipped" | (string & {});
export declare const ExperimentActionStatus: any;
export type ExperimentActionStatusReason = string;
export interface ExperimentActionState {
    status?: ExperimentActionStatus;
    reason?: string;
}
export declare const ExperimentActionState: S.Schema<ExperimentActionState>;
export type ExperimentActionStartTime = Date;
export type ExperimentActionEndTime = Date;
export interface ExperimentAction {
    actionId?: string;
    description?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
    targets?: {
        [key: string]: string | undefined;
    };
    startAfter?: string[];
    state?: ExperimentActionState;
    startTime?: Date;
    endTime?: Date;
}
export declare const ExperimentAction: S.Schema<ExperimentAction>;
export type ExperimentActionMap = {
    [key: string]: ExperimentAction | undefined;
};
export declare const ExperimentActionMap: any;
export interface ExperimentStopCondition {
    source?: string;
    value?: string;
}
export declare const ExperimentStopCondition: S.Schema<ExperimentStopCondition>;
export type ExperimentStopConditionList = ExperimentStopCondition[];
export declare const ExperimentStopConditionList: any;
export type ExperimentStartTime = Date;
export type ExperimentEndTime = Date;
export interface ExperimentCloudWatchLogsLogConfiguration {
    logGroupArn?: string;
}
export declare const ExperimentCloudWatchLogsLogConfiguration: S.Schema<ExperimentCloudWatchLogsLogConfiguration>;
export interface ExperimentS3LogConfiguration {
    bucketName?: string;
    prefix?: string;
}
export declare const ExperimentS3LogConfiguration: S.Schema<ExperimentS3LogConfiguration>;
export interface ExperimentLogConfiguration {
    cloudWatchLogsConfiguration?: ExperimentCloudWatchLogsLogConfiguration;
    s3Configuration?: ExperimentS3LogConfiguration;
    logSchemaVersion?: number;
}
export declare const ExperimentLogConfiguration: S.Schema<ExperimentLogConfiguration>;
export type ActionsMode = "skip-all" | "run-all" | (string & {});
export declare const ActionsMode: any;
export interface ExperimentOptions {
    accountTargeting?: AccountTargeting;
    emptyTargetResolutionMode?: EmptyTargetResolutionMode;
    actionsMode?: ActionsMode;
}
export declare const ExperimentOptions: S.Schema<ExperimentOptions>;
export interface ExperimentReportConfigurationOutputsS3Configuration {
    bucketName?: string;
    prefix?: string;
}
export declare const ExperimentReportConfigurationOutputsS3Configuration: S.Schema<ExperimentReportConfigurationOutputsS3Configuration>;
export interface ExperimentReportConfigurationOutputs {
    s3Configuration?: ExperimentReportConfigurationOutputsS3Configuration;
}
export declare const ExperimentReportConfigurationOutputs: S.Schema<ExperimentReportConfigurationOutputs>;
export interface ExperimentReportConfigurationCloudWatchDashboard {
    dashboardIdentifier?: string;
}
export declare const ExperimentReportConfigurationCloudWatchDashboard: S.Schema<ExperimentReportConfigurationCloudWatchDashboard>;
export type ExperimentReportConfigurationCloudWatchDashboardList = ExperimentReportConfigurationCloudWatchDashboard[];
export declare const ExperimentReportConfigurationCloudWatchDashboardList: any;
export interface ExperimentReportConfigurationDataSources {
    cloudWatchDashboards?: ExperimentReportConfigurationCloudWatchDashboard[];
}
export declare const ExperimentReportConfigurationDataSources: S.Schema<ExperimentReportConfigurationDataSources>;
export interface ExperimentReportConfiguration {
    outputs?: ExperimentReportConfigurationOutputs;
    dataSources?: ExperimentReportConfigurationDataSources;
    preExperimentDuration?: string;
    postExperimentDuration?: string;
}
export declare const ExperimentReportConfiguration: S.Schema<ExperimentReportConfiguration>;
export type ExperimentReportStatus = "pending" | "running" | "completed" | "cancelled" | "failed" | (string & {});
export declare const ExperimentReportStatus: any;
export type ExperimentReportReason = string;
export type ExperimentReportErrorCode = string;
export interface ExperimentReportError {
    code?: string;
}
export declare const ExperimentReportError: S.Schema<ExperimentReportError>;
export interface ExperimentReportState {
    status?: ExperimentReportStatus;
    reason?: string;
    error?: ExperimentReportError;
}
export declare const ExperimentReportState: S.Schema<ExperimentReportState>;
export type ExperimentReportS3ReportArn = string;
export type ExperimentReportS3ReportType = string;
export interface ExperimentReportS3Report {
    arn?: string;
    reportType?: string;
}
export declare const ExperimentReportS3Report: S.Schema<ExperimentReportS3Report>;
export type ExperimentReportS3ReportList = ExperimentReportS3Report[];
export declare const ExperimentReportS3ReportList: any;
export interface ExperimentReport {
    state?: ExperimentReportState;
    s3Reports?: ExperimentReportS3Report[];
}
export declare const ExperimentReport: S.Schema<ExperimentReport>;
export interface Experiment {
    id?: string;
    arn?: string;
    experimentTemplateId?: string;
    roleArn?: string;
    state?: ExperimentState;
    targets?: {
        [key: string]: ExperimentTarget | undefined;
    };
    actions?: {
        [key: string]: ExperimentAction | undefined;
    };
    stopConditions?: ExperimentStopCondition[];
    creationTime?: Date;
    startTime?: Date;
    endTime?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    logConfiguration?: ExperimentLogConfiguration;
    experimentOptions?: ExperimentOptions;
    targetAccountConfigurationsCount?: number;
    experimentReportConfiguration?: ExperimentReportConfiguration;
    experimentReport?: ExperimentReport;
}
export declare const Experiment: S.Schema<Experiment>;
export interface GetExperimentResponse {
    experiment?: Experiment;
}
export declare const GetExperimentResponse: S.Schema<GetExperimentResponse>;
export interface GetExperimentTargetAccountConfigurationRequest {
    experimentId: string;
    accountId: string;
}
export declare const GetExperimentTargetAccountConfigurationRequest: S.Schema<GetExperimentTargetAccountConfigurationRequest>;
export interface ExperimentTargetAccountConfiguration {
    roleArn?: string;
    accountId?: string;
    description?: string;
}
export declare const ExperimentTargetAccountConfiguration: S.Schema<ExperimentTargetAccountConfiguration>;
export interface GetExperimentTargetAccountConfigurationResponse {
    targetAccountConfiguration?: ExperimentTargetAccountConfiguration;
}
export declare const GetExperimentTargetAccountConfigurationResponse: S.Schema<GetExperimentTargetAccountConfigurationResponse>;
export interface GetExperimentTemplateRequest {
    id: string;
}
export declare const GetExperimentTemplateRequest: S.Schema<GetExperimentTemplateRequest>;
export interface GetExperimentTemplateResponse {
    experimentTemplate?: ExperimentTemplate;
}
export declare const GetExperimentTemplateResponse: S.Schema<GetExperimentTemplateResponse>;
export type SafetyLeverId = string;
export interface GetSafetyLeverRequest {
    id: string;
}
export declare const GetSafetyLeverRequest: S.Schema<GetSafetyLeverRequest>;
export type SafetyLeverStatus = "disengaged" | "engaged" | "engaging" | (string & {});
export declare const SafetyLeverStatus: any;
export type SafetyLeverStatusReason = string;
export interface SafetyLeverState {
    status?: SafetyLeverStatus;
    reason?: string;
}
export declare const SafetyLeverState: S.Schema<SafetyLeverState>;
export interface SafetyLever {
    id?: string;
    arn?: string;
    state?: SafetyLeverState;
}
export declare const SafetyLever: S.Schema<SafetyLever>;
export interface GetSafetyLeverResponse {
    safetyLever?: SafetyLever;
}
export declare const GetSafetyLeverResponse: S.Schema<GetSafetyLeverResponse>;
export interface GetTargetAccountConfigurationRequest {
    experimentTemplateId: string;
    accountId: string;
}
export declare const GetTargetAccountConfigurationRequest: S.Schema<GetTargetAccountConfigurationRequest>;
export interface GetTargetAccountConfigurationResponse {
    targetAccountConfiguration?: TargetAccountConfiguration;
}
export declare const GetTargetAccountConfigurationResponse: S.Schema<GetTargetAccountConfigurationResponse>;
export interface GetTargetResourceTypeRequest {
    resourceType: string;
}
export declare const GetTargetResourceTypeRequest: S.Schema<GetTargetResourceTypeRequest>;
export type TargetResourceTypeDescription = string;
export type TargetResourceTypeParameterName = string;
export type TargetResourceTypeParameterDescription = string;
export type TargetResourceTypeParameterRequired = boolean;
export interface TargetResourceTypeParameter {
    description?: string;
    required?: boolean;
}
export declare const TargetResourceTypeParameter: S.Schema<TargetResourceTypeParameter>;
export type TargetResourceTypeParameterMap = {
    [key: string]: TargetResourceTypeParameter | undefined;
};
export declare const TargetResourceTypeParameterMap: any;
export interface TargetResourceType {
    resourceType?: string;
    description?: string;
    parameters?: {
        [key: string]: TargetResourceTypeParameter | undefined;
    };
}
export declare const TargetResourceType: S.Schema<TargetResourceType>;
export interface GetTargetResourceTypeResponse {
    targetResourceType?: TargetResourceType;
}
export declare const GetTargetResourceTypeResponse: S.Schema<GetTargetResourceTypeResponse>;
export type ListActionsMaxResults = number;
export type NextToken = string;
export interface ListActionsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListActionsRequest: S.Schema<ListActionsRequest>;
export interface ActionSummary {
    id?: string;
    arn?: string;
    description?: string;
    targets?: {
        [key: string]: ActionTarget | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ActionSummary: S.Schema<ActionSummary>;
export type ActionSummaryList = ActionSummary[];
export declare const ActionSummaryList: any;
export interface ListActionsResponse {
    actions?: ActionSummary[];
    nextToken?: string;
}
export declare const ListActionsResponse: S.Schema<ListActionsResponse>;
export type ListExperimentResolvedTargetsMaxResults = number;
export type TargetName = string;
export interface ListExperimentResolvedTargetsRequest {
    experimentId: string;
    maxResults?: number;
    nextToken?: string;
    targetName?: string;
}
export declare const ListExperimentResolvedTargetsRequest: S.Schema<ListExperimentResolvedTargetsRequest>;
export type TargetInformationKey = string;
export type TargetInformationValue = string;
export type TargetInformationMap = {
    [key: string]: string | undefined;
};
export declare const TargetInformationMap: any;
export interface ResolvedTarget {
    resourceType?: string;
    targetName?: string;
    targetInformation?: {
        [key: string]: string | undefined;
    };
}
export declare const ResolvedTarget: S.Schema<ResolvedTarget>;
export type ResolvedTargetList = ResolvedTarget[];
export declare const ResolvedTargetList: any;
export interface ListExperimentResolvedTargetsResponse {
    resolvedTargets?: ResolvedTarget[];
    nextToken?: string;
}
export declare const ListExperimentResolvedTargetsResponse: S.Schema<ListExperimentResolvedTargetsResponse>;
export type ListExperimentsMaxResults = number;
export interface ListExperimentsRequest {
    maxResults?: number;
    nextToken?: string;
    experimentTemplateId?: string;
}
export declare const ListExperimentsRequest: S.Schema<ListExperimentsRequest>;
export interface ExperimentSummary {
    id?: string;
    arn?: string;
    experimentTemplateId?: string;
    state?: ExperimentState;
    creationTime?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    experimentOptions?: ExperimentOptions;
}
export declare const ExperimentSummary: S.Schema<ExperimentSummary>;
export type ExperimentSummaryList = ExperimentSummary[];
export declare const ExperimentSummaryList: any;
export interface ListExperimentsResponse {
    experiments?: ExperimentSummary[];
    nextToken?: string;
}
export declare const ListExperimentsResponse: S.Schema<ListExperimentsResponse>;
export interface ListExperimentTargetAccountConfigurationsRequest {
    experimentId: string;
    nextToken?: string;
}
export declare const ListExperimentTargetAccountConfigurationsRequest: S.Schema<ListExperimentTargetAccountConfigurationsRequest>;
export interface ExperimentTargetAccountConfigurationSummary {
    roleArn?: string;
    accountId?: string;
    description?: string;
}
export declare const ExperimentTargetAccountConfigurationSummary: S.Schema<ExperimentTargetAccountConfigurationSummary>;
export type ExperimentTargetAccountConfigurationList = ExperimentTargetAccountConfigurationSummary[];
export declare const ExperimentTargetAccountConfigurationList: any;
export interface ListExperimentTargetAccountConfigurationsResponse {
    targetAccountConfigurations?: ExperimentTargetAccountConfigurationSummary[];
    nextToken?: string;
}
export declare const ListExperimentTargetAccountConfigurationsResponse: S.Schema<ListExperimentTargetAccountConfigurationsResponse>;
export type ListExperimentTemplatesMaxResults = number;
export interface ListExperimentTemplatesRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListExperimentTemplatesRequest: S.Schema<ListExperimentTemplatesRequest>;
export interface ExperimentTemplateSummary {
    id?: string;
    arn?: string;
    description?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ExperimentTemplateSummary: S.Schema<ExperimentTemplateSummary>;
export type ExperimentTemplateSummaryList = ExperimentTemplateSummary[];
export declare const ExperimentTemplateSummaryList: any;
export interface ListExperimentTemplatesResponse {
    experimentTemplates?: ExperimentTemplateSummary[];
    nextToken?: string;
}
export declare const ListExperimentTemplatesResponse: S.Schema<ListExperimentTemplatesResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type ListTargetAccountConfigurationsMaxResults = number;
export interface ListTargetAccountConfigurationsRequest {
    experimentTemplateId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListTargetAccountConfigurationsRequest: S.Schema<ListTargetAccountConfigurationsRequest>;
export interface TargetAccountConfigurationSummary {
    roleArn?: string;
    accountId?: string;
    description?: string;
}
export declare const TargetAccountConfigurationSummary: S.Schema<TargetAccountConfigurationSummary>;
export type TargetAccountConfigurationList = TargetAccountConfigurationSummary[];
export declare const TargetAccountConfigurationList: any;
export interface ListTargetAccountConfigurationsResponse {
    targetAccountConfigurations?: TargetAccountConfigurationSummary[];
    nextToken?: string;
}
export declare const ListTargetAccountConfigurationsResponse: S.Schema<ListTargetAccountConfigurationsResponse>;
export type ListTargetResourceTypesMaxResults = number;
export interface ListTargetResourceTypesRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListTargetResourceTypesRequest: S.Schema<ListTargetResourceTypesRequest>;
export interface TargetResourceTypeSummary {
    resourceType?: string;
    description?: string;
}
export declare const TargetResourceTypeSummary: S.Schema<TargetResourceTypeSummary>;
export type TargetResourceTypeSummaryList = TargetResourceTypeSummary[];
export declare const TargetResourceTypeSummaryList: any;
export interface ListTargetResourceTypesResponse {
    targetResourceTypes?: TargetResourceTypeSummary[];
    nextToken?: string;
}
export declare const ListTargetResourceTypesResponse: S.Schema<ListTargetResourceTypesResponse>;
export interface StartExperimentExperimentOptionsInput {
    actionsMode?: ActionsMode;
}
export declare const StartExperimentExperimentOptionsInput: S.Schema<StartExperimentExperimentOptionsInput>;
export interface StartExperimentRequest {
    clientToken: string;
    experimentTemplateId: string;
    experimentOptions?: StartExperimentExperimentOptionsInput;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StartExperimentRequest: S.Schema<StartExperimentRequest>;
export interface StartExperimentResponse {
    experiment?: Experiment;
}
export declare const StartExperimentResponse: S.Schema<StartExperimentResponse>;
export interface StopExperimentRequest {
    id: string;
}
export declare const StopExperimentRequest: S.Schema<StopExperimentRequest>;
export interface StopExperimentResponse {
    experiment?: Experiment;
}
export declare const StopExperimentResponse: S.Schema<StopExperimentResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys?: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateExperimentTemplateStopConditionInput {
    source: string;
    value?: string;
}
export declare const UpdateExperimentTemplateStopConditionInput: S.Schema<UpdateExperimentTemplateStopConditionInput>;
export type UpdateExperimentTemplateStopConditionInputList = UpdateExperimentTemplateStopConditionInput[];
export declare const UpdateExperimentTemplateStopConditionInputList: any;
export interface UpdateExperimentTemplateTargetInput {
    resourceType: string;
    resourceArns?: string[];
    resourceTags?: {
        [key: string]: string | undefined;
    };
    filters?: ExperimentTemplateTargetInputFilter[];
    selectionMode: string;
    parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateExperimentTemplateTargetInput: S.Schema<UpdateExperimentTemplateTargetInput>;
export type UpdateExperimentTemplateTargetInputMap = {
    [key: string]: UpdateExperimentTemplateTargetInput | undefined;
};
export declare const UpdateExperimentTemplateTargetInputMap: any;
export interface UpdateExperimentTemplateActionInputItem {
    actionId?: string;
    description?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
    targets?: {
        [key: string]: string | undefined;
    };
    startAfter?: string[];
}
export declare const UpdateExperimentTemplateActionInputItem: S.Schema<UpdateExperimentTemplateActionInputItem>;
export type UpdateExperimentTemplateActionInputMap = {
    [key: string]: UpdateExperimentTemplateActionInputItem | undefined;
};
export declare const UpdateExperimentTemplateActionInputMap: any;
export interface UpdateExperimentTemplateLogConfigurationInput {
    cloudWatchLogsConfiguration?: ExperimentTemplateCloudWatchLogsLogConfigurationInput;
    s3Configuration?: ExperimentTemplateS3LogConfigurationInput;
    logSchemaVersion?: number;
}
export declare const UpdateExperimentTemplateLogConfigurationInput: S.Schema<UpdateExperimentTemplateLogConfigurationInput>;
export interface UpdateExperimentTemplateExperimentOptionsInput {
    emptyTargetResolutionMode?: EmptyTargetResolutionMode;
}
export declare const UpdateExperimentTemplateExperimentOptionsInput: S.Schema<UpdateExperimentTemplateExperimentOptionsInput>;
export interface UpdateExperimentTemplateReportConfigurationInput {
    outputs?: ExperimentTemplateReportConfigurationOutputsInput;
    dataSources?: ExperimentTemplateReportConfigurationDataSourcesInput;
    preExperimentDuration?: string;
    postExperimentDuration?: string;
}
export declare const UpdateExperimentTemplateReportConfigurationInput: S.Schema<UpdateExperimentTemplateReportConfigurationInput>;
export interface UpdateExperimentTemplateRequest {
    id: string;
    description?: string;
    stopConditions?: UpdateExperimentTemplateStopConditionInput[];
    targets?: {
        [key: string]: UpdateExperimentTemplateTargetInput | undefined;
    };
    actions?: {
        [key: string]: UpdateExperimentTemplateActionInputItem | undefined;
    };
    roleArn?: string;
    logConfiguration?: UpdateExperimentTemplateLogConfigurationInput;
    experimentOptions?: UpdateExperimentTemplateExperimentOptionsInput;
    experimentReportConfiguration?: UpdateExperimentTemplateReportConfigurationInput;
}
export declare const UpdateExperimentTemplateRequest: S.Schema<UpdateExperimentTemplateRequest>;
export interface UpdateExperimentTemplateResponse {
    experimentTemplate?: ExperimentTemplate;
}
export declare const UpdateExperimentTemplateResponse: S.Schema<UpdateExperimentTemplateResponse>;
export type SafetyLeverStatusInput = "disengaged" | "engaged" | (string & {});
export declare const SafetyLeverStatusInput: any;
export interface UpdateSafetyLeverStateInput {
    status: SafetyLeverStatusInput;
    reason: string;
}
export declare const UpdateSafetyLeverStateInput: S.Schema<UpdateSafetyLeverStateInput>;
export interface UpdateSafetyLeverStateRequest {
    id: string;
    state: UpdateSafetyLeverStateInput;
}
export declare const UpdateSafetyLeverStateRequest: S.Schema<UpdateSafetyLeverStateRequest>;
export interface UpdateSafetyLeverStateResponse {
    safetyLever?: SafetyLever;
}
export declare const UpdateSafetyLeverStateResponse: S.Schema<UpdateSafetyLeverStateResponse>;
export interface UpdateTargetAccountConfigurationRequest {
    experimentTemplateId: string;
    accountId: string;
    roleArn?: string;
    description?: string;
}
export declare const UpdateTargetAccountConfigurationRequest: S.Schema<UpdateTargetAccountConfigurationRequest>;
export interface UpdateTargetAccountConfigurationResponse {
    targetAccountConfiguration?: TargetAccountConfiguration;
}
export declare const UpdateTargetAccountConfigurationResponse: S.Schema<UpdateTargetAccountConfigurationResponse>;
export type ExceptionMessage = string;
export type CreateExperimentTemplateError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an experiment template.
 *
 * An experiment template includes the following components:
 *
 * - **Targets**: A target can be a specific resource in
 * your Amazon Web Services environment, or one or more resources that match criteria that you
 * specify, for example, resources that have specific tags.
 *
 * - **Actions**: The actions to carry out on the
 * target. You can specify multiple actions, the duration of each action, and when to start each action during an experiment.
 *
 * - **Stop conditions**: If a stop condition is
 * triggered while an experiment is running, the experiment is automatically
 * stopped. You can define a stop condition as a CloudWatch alarm.
 *
 * For more information, see experiment templates
 * in the *Fault Injection Service User Guide*.
 */
export declare const createExperimentTemplate: API.OperationMethod<CreateExperimentTemplateRequest, CreateExperimentTemplateResponse, CreateExperimentTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateTargetAccountConfigurationError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a target account configuration for the experiment template. A target account configuration
 * is required when `accountTargeting` of `experimentOptions` is set to `multi-account`.
 * For more information, see experiment options
 * in the *Fault Injection Service User Guide*.
 */
export declare const createTargetAccountConfiguration: API.OperationMethod<CreateTargetAccountConfigurationRequest, CreateTargetAccountConfigurationResponse, CreateTargetAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteExperimentTemplateError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified experiment template.
 */
export declare const deleteExperimentTemplate: API.OperationMethod<DeleteExperimentTemplateRequest, DeleteExperimentTemplateResponse, DeleteExperimentTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteTargetAccountConfigurationError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified target account configuration of the experiment template.
 */
export declare const deleteTargetAccountConfiguration: API.OperationMethod<DeleteTargetAccountConfigurationRequest, DeleteTargetAccountConfigurationResponse, DeleteTargetAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetActionError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified FIS action.
 */
export declare const getAction: API.OperationMethod<GetActionRequest, GetActionResponse, GetActionError, Credentials | HttpClient.HttpClient>;
export type GetExperimentError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified experiment.
 */
export declare const getExperiment: API.OperationMethod<GetExperimentRequest, GetExperimentResponse, GetExperimentError, Credentials | HttpClient.HttpClient>;
export type GetExperimentTargetAccountConfigurationError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified target account configuration of the experiment.
 */
export declare const getExperimentTargetAccountConfiguration: API.OperationMethod<GetExperimentTargetAccountConfigurationRequest, GetExperimentTargetAccountConfigurationResponse, GetExperimentTargetAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetExperimentTemplateError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified experiment template.
 */
export declare const getExperimentTemplate: API.OperationMethod<GetExperimentTemplateRequest, GetExperimentTemplateResponse, GetExperimentTemplateError, Credentials | HttpClient.HttpClient>;
export type GetSafetyLeverError = ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the specified safety lever.
 */
export declare const getSafetyLever: API.OperationMethod<GetSafetyLeverRequest, GetSafetyLeverResponse, GetSafetyLeverError, Credentials | HttpClient.HttpClient>;
export type GetTargetAccountConfigurationError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified target account configuration of the experiment template.
 */
export declare const getTargetAccountConfiguration: API.OperationMethod<GetTargetAccountConfigurationRequest, GetTargetAccountConfigurationResponse, GetTargetAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetTargetResourceTypeError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified resource type.
 */
export declare const getTargetResourceType: API.OperationMethod<GetTargetResourceTypeRequest, GetTargetResourceTypeResponse, GetTargetResourceTypeError, Credentials | HttpClient.HttpClient>;
export type ListActionsError = ValidationException | CommonErrors;
/**
 * Lists the available FIS actions.
 */
export declare const listActions: API.PaginatedOperationMethod<ListActionsRequest, ListActionsResponse, ListActionsError, Credentials | HttpClient.HttpClient, ActionSummary>;
export type ListExperimentResolvedTargetsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the resolved targets information of the specified experiment.
 */
export declare const listExperimentResolvedTargets: API.PaginatedOperationMethod<ListExperimentResolvedTargetsRequest, ListExperimentResolvedTargetsResponse, ListExperimentResolvedTargetsError, Credentials | HttpClient.HttpClient, ResolvedTarget>;
export type ListExperimentsError = ValidationException | CommonErrors;
/**
 * Lists your experiments.
 */
export declare const listExperiments: API.PaginatedOperationMethod<ListExperimentsRequest, ListExperimentsResponse, ListExperimentsError, Credentials | HttpClient.HttpClient, ExperimentSummary>;
export type ListExperimentTargetAccountConfigurationsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the target account configurations of the specified experiment.
 */
export declare const listExperimentTargetAccountConfigurations: API.OperationMethod<ListExperimentTargetAccountConfigurationsRequest, ListExperimentTargetAccountConfigurationsResponse, ListExperimentTargetAccountConfigurationsError, Credentials | HttpClient.HttpClient>;
export type ListExperimentTemplatesError = ValidationException | CommonErrors;
/**
 * Lists your experiment templates.
 */
export declare const listExperimentTemplates: API.PaginatedOperationMethod<ListExperimentTemplatesRequest, ListExperimentTemplatesResponse, ListExperimentTemplatesError, Credentials | HttpClient.HttpClient, ExperimentTemplateSummary>;
export type ListTagsForResourceError = CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTargetAccountConfigurationsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the target account configurations of the specified experiment template.
 */
export declare const listTargetAccountConfigurations: API.PaginatedOperationMethod<ListTargetAccountConfigurationsRequest, ListTargetAccountConfigurationsResponse, ListTargetAccountConfigurationsError, Credentials | HttpClient.HttpClient, TargetAccountConfigurationSummary>;
export type ListTargetResourceTypesError = ValidationException | CommonErrors;
/**
 * Lists the target resource types.
 */
export declare const listTargetResourceTypes: API.PaginatedOperationMethod<ListTargetResourceTypesRequest, ListTargetResourceTypesResponse, ListTargetResourceTypesError, Credentials | HttpClient.HttpClient, TargetResourceTypeSummary>;
export type StartExperimentError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Starts running an experiment from the specified experiment template.
 */
export declare const startExperiment: API.OperationMethod<StartExperimentRequest, StartExperimentResponse, StartExperimentError, Credentials | HttpClient.HttpClient>;
export type StopExperimentError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops the specified experiment.
 */
export declare const stopExperiment: API.OperationMethod<StopExperimentRequest, StopExperimentResponse, StopExperimentError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * Applies the specified tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateExperimentTemplateError = ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates the specified experiment template.
 */
export declare const updateExperimentTemplate: API.OperationMethod<UpdateExperimentTemplateRequest, UpdateExperimentTemplateResponse, UpdateExperimentTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateSafetyLeverStateError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the specified safety lever state.
 */
export declare const updateSafetyLeverState: API.OperationMethod<UpdateSafetyLeverStateRequest, UpdateSafetyLeverStateResponse, UpdateSafetyLeverStateError, Credentials | HttpClient.HttpClient>;
export type UpdateTargetAccountConfigurationError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the target account configuration for the specified experiment template.
 */
export declare const updateTargetAccountConfiguration: API.OperationMethod<UpdateTargetAccountConfigurationRequest, UpdateTargetAccountConfigurationResponse, UpdateTargetAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=fis.d.ts.map