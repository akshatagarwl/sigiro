import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
    readonly resourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly retryAfterSeconds: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly resourceName: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AccountIdString = string;
export type AccountIdList = string[];
export declare const AccountIdList: any;
export interface BatchGetInvoiceProfileRequest {
    AccountIds: string[];
}
export declare const BatchGetInvoiceProfileRequest: S.Schema<BatchGetInvoiceProfileRequest>;
export type BasicStringWithoutSpace = string;
export type BasicString = string;
export interface ReceiverAddress {
    AddressLine1?: string;
    AddressLine2?: string;
    AddressLine3?: string;
    DistrictOrCounty?: string;
    City?: string;
    StateOrRegion?: string;
    CountryCode?: string;
    CompanyName?: string;
    PostalCode?: string;
}
export declare const ReceiverAddress: S.Schema<ReceiverAddress>;
export type SensitiveBasicStringWithoutSpace = string | redacted.Redacted<string>;
export interface InvoiceProfile {
    AccountId?: string;
    ReceiverName?: string;
    ReceiverAddress?: ReceiverAddress;
    ReceiverEmail?: string | redacted.Redacted<string>;
    Issuer?: string;
    TaxRegistrationNumber?: string | redacted.Redacted<string>;
}
export declare const InvoiceProfile: S.Schema<InvoiceProfile>;
export type ProfileList = InvoiceProfile[];
export declare const ProfileList: any;
export interface BatchGetInvoiceProfileResponse {
    Profiles?: InvoiceProfile[];
}
export declare const BatchGetInvoiceProfileResponse: S.Schema<BatchGetInvoiceProfileResponse>;
export type InvoiceUnitName = string;
export type DescriptionString = string;
export type TaxInheritanceDisabledFlag = boolean;
export type RuleAccountIdList = string[];
export declare const RuleAccountIdList: any;
export interface InvoiceUnitRule {
    LinkedAccounts?: string[];
    BillSourceAccounts?: string[];
}
export declare const InvoiceUnitRule: S.Schema<InvoiceUnitRule>;
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    Key: string;
    Value: string;
}
export declare const ResourceTag: S.Schema<ResourceTag>;
export type ResourceTagList = ResourceTag[];
export declare const ResourceTagList: any;
export interface CreateInvoiceUnitRequest {
    Name: string;
    InvoiceReceiver: string;
    Description?: string;
    TaxInheritanceDisabled?: boolean;
    Rule: InvoiceUnitRule;
    ResourceTags?: ResourceTag[];
    ClientToken?: string;
}
export declare const CreateInvoiceUnitRequest: S.Schema<CreateInvoiceUnitRequest>;
export type InvoiceUnitArnString = string;
export interface CreateInvoiceUnitResponse {
    InvoiceUnitArn?: string;
}
export declare const CreateInvoiceUnitResponse: S.Schema<CreateInvoiceUnitResponse>;
export type ProcurementPortalName = "SAP_BUSINESS_NETWORK" | "COUPA" | (string & {});
export declare const ProcurementPortalName: any;
export type BuyerDomain = "NetworkID" | (string & {});
export declare const BuyerDomain: any;
export type SupplierDomain = "NetworkID" | (string & {});
export declare const SupplierDomain: any;
export type InvoiceUnitArns = string[];
export declare const InvoiceUnitArns: any;
export type SellerOfRecords = string[];
export declare const SellerOfRecords: any;
export interface ProcurementPortalPreferenceSelector {
    InvoiceUnitArns?: string[];
    SellerOfRecords?: string[];
}
export declare const ProcurementPortalPreferenceSelector: S.Schema<ProcurementPortalPreferenceSelector>;
export interface TestEnvPreferenceInput {
    BuyerDomain: BuyerDomain;
    BuyerIdentifier: string;
    SupplierDomain: SupplierDomain;
    SupplierIdentifier: string;
    ProcurementPortalSharedSecret?: string;
    ProcurementPortalInstanceEndpoint?: string;
}
export declare const TestEnvPreferenceInput: S.Schema<TestEnvPreferenceInput>;
export type EinvoiceDeliveryDocumentType = "AWS_CLOUD_INVOICE" | "AWS_CLOUD_CREDIT_MEMO" | "AWS_MARKETPLACE_INVOICE" | "AWS_MARKETPLACE_CREDIT_MEMO" | "AWS_REQUEST_FOR_PAYMENT" | (string & {});
export declare const EinvoiceDeliveryDocumentType: any;
export type EinvoiceDeliveryDocumentTypes = EinvoiceDeliveryDocumentType[];
export declare const EinvoiceDeliveryDocumentTypes: any;
export type EinvoiceDeliveryAttachmentType = "INVOICE_PDF" | "RFP_PDF" | (string & {});
export declare const EinvoiceDeliveryAttachmentType: any;
export type EinvoiceDeliveryAttachmentTypes = EinvoiceDeliveryAttachmentType[];
export declare const EinvoiceDeliveryAttachmentTypes: any;
export type Protocol = "CXML" | (string & {});
export declare const Protocol: any;
export type PurchaseOrderDataSourceType = "ASSOCIATED_PURCHASE_ORDER_REQUIRED" | "PURCHASE_ORDER_NOT_REQUIRED" | (string & {});
export declare const PurchaseOrderDataSourceType: any;
export interface PurchaseOrderDataSource {
    EinvoiceDeliveryDocumentType?: EinvoiceDeliveryDocumentType;
    PurchaseOrderDataSourceType?: PurchaseOrderDataSourceType;
}
export declare const PurchaseOrderDataSource: S.Schema<PurchaseOrderDataSource>;
export type PurchaseOrderDataSources = PurchaseOrderDataSource[];
export declare const PurchaseOrderDataSources: any;
export type ConnectionTestingMethod = "PROD_ENV_DOLLAR_TEST" | "TEST_ENV_REPLAY_TEST" | (string & {});
export declare const ConnectionTestingMethod: any;
export interface EinvoiceDeliveryPreference {
    EinvoiceDeliveryDocumentTypes: EinvoiceDeliveryDocumentType[];
    EinvoiceDeliveryAttachmentTypes?: EinvoiceDeliveryAttachmentType[];
    Protocol: Protocol;
    PurchaseOrderDataSources: PurchaseOrderDataSource[];
    ConnectionTestingMethod: ConnectionTestingMethod;
    EinvoiceDeliveryActivationDate: Date;
}
export declare const EinvoiceDeliveryPreference: S.Schema<EinvoiceDeliveryPreference>;
export type EmailString = string;
export interface Contact {
    Name?: string;
    Email?: string;
}
export declare const Contact: S.Schema<Contact>;
export type Contacts = Contact[];
export declare const Contacts: any;
export interface CreateProcurementPortalPreferenceRequest {
    ProcurementPortalName: ProcurementPortalName;
    BuyerDomain: BuyerDomain;
    BuyerIdentifier: string;
    SupplierDomain: SupplierDomain;
    SupplierIdentifier: string;
    Selector?: ProcurementPortalPreferenceSelector;
    ProcurementPortalSharedSecret?: string | redacted.Redacted<string>;
    ProcurementPortalInstanceEndpoint?: string;
    TestEnvPreference?: TestEnvPreferenceInput;
    EinvoiceDeliveryEnabled: boolean;
    EinvoiceDeliveryPreference?: EinvoiceDeliveryPreference;
    PurchaseOrderRetrievalEnabled: boolean;
    Contacts: Contact[];
    ResourceTags?: ResourceTag[];
    ClientToken?: string;
}
export declare const CreateProcurementPortalPreferenceRequest: S.Schema<CreateProcurementPortalPreferenceRequest>;
export type ProcurementPortalPreferenceArnString = string;
export interface CreateProcurementPortalPreferenceResponse {
    ProcurementPortalPreferenceArn: string;
}
export declare const CreateProcurementPortalPreferenceResponse: S.Schema<CreateProcurementPortalPreferenceResponse>;
export interface DeleteInvoiceUnitRequest {
    InvoiceUnitArn: string;
    ClientToken?: string;
}
export declare const DeleteInvoiceUnitRequest: S.Schema<DeleteInvoiceUnitRequest>;
export interface DeleteInvoiceUnitResponse {
    InvoiceUnitArn?: string;
}
export declare const DeleteInvoiceUnitResponse: S.Schema<DeleteInvoiceUnitResponse>;
export interface DeleteProcurementPortalPreferenceRequest {
    ProcurementPortalPreferenceArn: string;
    ClientToken?: string;
}
export declare const DeleteProcurementPortalPreferenceRequest: S.Schema<DeleteProcurementPortalPreferenceRequest>;
export interface DeleteProcurementPortalPreferenceResponse {
    ProcurementPortalPreferenceArn: string;
}
export declare const DeleteProcurementPortalPreferenceResponse: S.Schema<DeleteProcurementPortalPreferenceResponse>;
export type StringWithoutNewLine = string;
export interface GetInvoicePDFRequest {
    InvoiceId: string;
}
export declare const GetInvoicePDFRequest: S.Schema<GetInvoicePDFRequest>;
export type SupplementalDocumentType = "GOVERNMENT_INVOICE" | "TAX_E_INVOICE" | "PAYMENT_RECEIPT" | "SUPPLEMENT" | (string & {});
export declare const SupplementalDocumentType: any;
export interface SupplementalDocument {
    DocumentType?: SupplementalDocumentType;
    DocumentId?: string;
    DocumentUrl?: string;
    DocumentUrlExpirationDate?: Date;
}
export declare const SupplementalDocument: S.Schema<SupplementalDocument>;
export type SupplementalDocuments = SupplementalDocument[];
export declare const SupplementalDocuments: any;
export interface InvoicePDF {
    InvoiceId?: string;
    DocumentUrl?: string;
    DocumentUrlExpirationDate?: Date;
    SupplementalDocuments?: SupplementalDocument[];
}
export declare const InvoicePDF: S.Schema<InvoicePDF>;
export interface GetInvoicePDFResponse {
    InvoicePDF?: InvoicePDF;
}
export declare const GetInvoicePDFResponse: S.Schema<GetInvoicePDFResponse>;
export type AsOfTimestamp = Date;
export interface GetInvoiceUnitRequest {
    InvoiceUnitArn: string;
    AsOf?: Date;
}
export declare const GetInvoiceUnitRequest: S.Schema<GetInvoiceUnitRequest>;
export type LastModifiedTimestamp = Date;
export interface GetInvoiceUnitResponse {
    InvoiceUnitArn?: string;
    InvoiceReceiver?: string;
    Name?: string;
    Description?: string;
    TaxInheritanceDisabled?: boolean;
    Rule?: InvoiceUnitRule;
    LastModified?: Date;
}
export declare const GetInvoiceUnitResponse: S.Schema<GetInvoiceUnitResponse>;
export interface GetProcurementPortalPreferenceRequest {
    ProcurementPortalPreferenceArn: string;
}
export declare const GetProcurementPortalPreferenceRequest: S.Schema<GetProcurementPortalPreferenceRequest>;
export interface TestEnvPreference {
    BuyerDomain: BuyerDomain;
    BuyerIdentifier: string;
    SupplierDomain: SupplierDomain;
    SupplierIdentifier: string;
    ProcurementPortalSharedSecret?: string;
    ProcurementPortalInstanceEndpoint?: string;
    PurchaseOrderRetrievalEndpoint?: string;
}
export declare const TestEnvPreference: S.Schema<TestEnvPreference>;
export type ProcurementPortalPreferenceStatus = "PENDING_VERIFICATION" | "VALIDATED" | "TEST_INITIALIZED" | "TEST_INITIALIZATION_FAILED" | "TEST_FAILED" | "ACTIVE" | "SUSPENDED" | (string & {});
export declare const ProcurementPortalPreferenceStatus: any;
export interface ProcurementPortalPreference {
    AwsAccountId: string;
    ProcurementPortalPreferenceArn: string;
    ProcurementPortalName: ProcurementPortalName;
    BuyerDomain: BuyerDomain;
    BuyerIdentifier: string;
    SupplierDomain: SupplierDomain;
    SupplierIdentifier: string;
    Selector?: ProcurementPortalPreferenceSelector;
    ProcurementPortalSharedSecret?: string;
    ProcurementPortalInstanceEndpoint?: string;
    PurchaseOrderRetrievalEndpoint?: string;
    TestEnvPreference?: TestEnvPreference;
    EinvoiceDeliveryEnabled: boolean;
    EinvoiceDeliveryPreference?: EinvoiceDeliveryPreference;
    PurchaseOrderRetrievalEnabled: boolean;
    Contacts?: Contact[];
    EinvoiceDeliveryPreferenceStatus?: ProcurementPortalPreferenceStatus;
    EinvoiceDeliveryPreferenceStatusReason?: string;
    PurchaseOrderRetrievalPreferenceStatus?: ProcurementPortalPreferenceStatus;
    PurchaseOrderRetrievalPreferenceStatusReason?: string;
    Version: number;
    CreateDate: Date;
    LastUpdateDate: Date;
}
export declare const ProcurementPortalPreference: S.Schema<ProcurementPortalPreference>;
export interface GetProcurementPortalPreferenceResponse {
    ProcurementPortalPreference: ProcurementPortalPreference;
}
export declare const GetProcurementPortalPreferenceResponse: S.Schema<GetProcurementPortalPreferenceResponse>;
export type ListInvoiceSummariesResourceType = "ACCOUNT_ID" | "INVOICE_ID" | (string & {});
export declare const ListInvoiceSummariesResourceType: any;
export interface InvoiceSummariesSelector {
    ResourceType: ListInvoiceSummariesResourceType;
    Value: string;
}
export declare const InvoiceSummariesSelector: S.Schema<InvoiceSummariesSelector>;
export interface DateInterval {
    StartDate: Date;
    EndDate: Date;
}
export declare const DateInterval: S.Schema<DateInterval>;
export type Month = number;
export type Year = number;
export interface BillingPeriod {
    Month: number;
    Year: number;
}
export declare const BillingPeriod: S.Schema<BillingPeriod>;
export type ReceiverRole = "SELLER" | "RESELLER" | "BUYER" | (string & {});
export declare const ReceiverRole: any;
export interface InvoiceSummariesFilter {
    TimeInterval?: DateInterval;
    BillingPeriod?: BillingPeriod;
    InvoicingEntity?: string;
    ReceiverRole?: ReceiverRole;
}
export declare const InvoiceSummariesFilter: S.Schema<InvoiceSummariesFilter>;
export type NextTokenString = string;
export type InvoiceSummariesMaxResults = number;
export interface ListInvoiceSummariesRequest {
    Selector: InvoiceSummariesSelector;
    Filter?: InvoiceSummariesFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListInvoiceSummariesRequest: S.Schema<ListInvoiceSummariesRequest>;
export type BillSourceAccountList = string[];
export declare const BillSourceAccountList: any;
export type BillingEntity = "AWS" | "AWS_MARKETPLACE" | (string & {});
export declare const BillingEntity: any;
export interface Entity {
    InvoicingEntity?: string;
    BillingEntity?: BillingEntity;
}
export declare const Entity: S.Schema<Entity>;
export type InvoiceFrequency = "ONE_TIME" | "RECURRING" | (string & {});
export declare const InvoiceFrequency: any;
export type BillType = "ANNIVERSARY" | "PURCHASE" | "REFUND" | (string & {});
export declare const BillType: any;
export type InvoiceType = "INVOICE" | "CREDIT_MEMO" | "PAYMENT_RECEIPT" | (string & {});
export declare const InvoiceType: any;
export type EinvoiceDeliveryStatus = "DELIVERED" | "NOT_DELIVERED" | (string & {});
export declare const EinvoiceDeliveryStatus: any;
export type TaxAuthorityStatus = "ISSUED" | "CANCELLED" | (string & {});
export declare const TaxAuthorityStatus: any;
export type CurrencyCode = string;
export interface DiscountsBreakdownAmount {
    Description?: string;
    Amount?: string;
    Rate?: string;
}
export declare const DiscountsBreakdownAmount: S.Schema<DiscountsBreakdownAmount>;
export type DiscountsBreakdownAmountList = DiscountsBreakdownAmount[];
export declare const DiscountsBreakdownAmountList: any;
export interface DiscountsBreakdown {
    Breakdown?: DiscountsBreakdownAmount[];
    TotalAmount?: string;
}
export declare const DiscountsBreakdown: S.Schema<DiscountsBreakdown>;
export interface TaxesBreakdownAmount {
    Description?: string;
    Amount?: string;
    Rate?: string;
}
export declare const TaxesBreakdownAmount: S.Schema<TaxesBreakdownAmount>;
export type TaxesBreakdownAmountList = TaxesBreakdownAmount[];
export declare const TaxesBreakdownAmountList: any;
export interface TaxesBreakdown {
    Breakdown?: TaxesBreakdownAmount[];
    TotalAmount?: string;
}
export declare const TaxesBreakdown: S.Schema<TaxesBreakdown>;
export interface FeesBreakdownAmount {
    Description?: string;
    Amount?: string;
    Rate?: string;
}
export declare const FeesBreakdownAmount: S.Schema<FeesBreakdownAmount>;
export type FeesBreakdownAmountList = FeesBreakdownAmount[];
export declare const FeesBreakdownAmountList: any;
export interface FeesBreakdown {
    Breakdown?: FeesBreakdownAmount[];
    TotalAmount?: string;
}
export declare const FeesBreakdown: S.Schema<FeesBreakdown>;
export interface AmountBreakdown {
    SubTotalAmount?: string;
    Discounts?: DiscountsBreakdown;
    Taxes?: TaxesBreakdown;
    Fees?: FeesBreakdown;
}
export declare const AmountBreakdown: S.Schema<AmountBreakdown>;
export interface CurrencyExchangeDetails {
    SourceCurrencyCode?: string;
    TargetCurrencyCode?: string;
    Rate?: string;
}
export declare const CurrencyExchangeDetails: S.Schema<CurrencyExchangeDetails>;
export interface InvoiceCurrencyAmount {
    TotalAmount?: string;
    TotalAmountBeforeTax?: string;
    CurrencyCode?: string;
    AmountBreakdown?: AmountBreakdown;
    CurrencyExchangeDetails?: CurrencyExchangeDetails;
}
export declare const InvoiceCurrencyAmount: S.Schema<InvoiceCurrencyAmount>;
export interface InvoiceSummary {
    AccountId?: string;
    InvoiceId?: string;
    IssuedDate?: Date;
    DueDate?: Date;
    BillSourceAccounts?: string[];
    BillSourceAccountsTotalCount?: number;
    ReceiverRole?: ReceiverRole;
    Entity?: Entity;
    BillingPeriod?: BillingPeriod;
    InvoiceFrequency?: InvoiceFrequency;
    BillType?: BillType;
    InvoiceType?: InvoiceType;
    CommercialInvoiceId?: string;
    OriginalInvoiceId?: string;
    PurchaseOrderNumber?: string;
    EinvoiceDeliveryStatus?: EinvoiceDeliveryStatus;
    TaxAuthorityStatus?: TaxAuthorityStatus;
    BaseCurrencyAmount?: InvoiceCurrencyAmount;
    TaxCurrencyAmount?: InvoiceCurrencyAmount;
    PaymentCurrencyAmount?: InvoiceCurrencyAmount;
}
export declare const InvoiceSummary: S.Schema<InvoiceSummary>;
export type InvoiceSummaries = InvoiceSummary[];
export declare const InvoiceSummaries: any;
export interface ListInvoiceSummariesResponse {
    InvoiceSummaries: InvoiceSummary[];
    NextToken?: string;
}
export declare const ListInvoiceSummariesResponse: S.Schema<ListInvoiceSummariesResponse>;
export type InvoiceUnitNames = string[];
export declare const InvoiceUnitNames: any;
export interface Filters {
    Names?: string[];
    InvoiceReceivers?: string[];
    Accounts?: string[];
    BillSourceAccounts?: string[];
}
export declare const Filters: S.Schema<Filters>;
export type MaxResultsInteger = number;
export interface ListInvoiceUnitsRequest {
    Filters?: Filters;
    NextToken?: string;
    MaxResults?: number;
    AsOf?: Date;
}
export declare const ListInvoiceUnitsRequest: S.Schema<ListInvoiceUnitsRequest>;
export interface InvoiceUnit {
    InvoiceUnitArn?: string;
    InvoiceReceiver?: string;
    Name?: string;
    Description?: string;
    TaxInheritanceDisabled?: boolean;
    Rule?: InvoiceUnitRule;
    LastModified?: Date;
}
export declare const InvoiceUnit: S.Schema<InvoiceUnit>;
export type InvoiceUnits = InvoiceUnit[];
export declare const InvoiceUnits: any;
export interface ListInvoiceUnitsResponse {
    InvoiceUnits?: InvoiceUnit[];
    NextToken?: string;
}
export declare const ListInvoiceUnitsResponse: S.Schema<ListInvoiceUnitsResponse>;
export type MaxResults = number;
export interface ListProcurementPortalPreferencesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListProcurementPortalPreferencesRequest: S.Schema<ListProcurementPortalPreferencesRequest>;
export interface ProcurementPortalPreferenceSummary {
    AwsAccountId: string;
    ProcurementPortalPreferenceArn: string;
    ProcurementPortalName: ProcurementPortalName;
    BuyerDomain: BuyerDomain;
    BuyerIdentifier: string;
    SupplierDomain: SupplierDomain;
    SupplierIdentifier: string;
    Selector?: ProcurementPortalPreferenceSelector;
    EinvoiceDeliveryEnabled: boolean;
    PurchaseOrderRetrievalEnabled: boolean;
    EinvoiceDeliveryPreferenceStatus?: ProcurementPortalPreferenceStatus;
    EinvoiceDeliveryPreferenceStatusReason?: string;
    PurchaseOrderRetrievalPreferenceStatus?: ProcurementPortalPreferenceStatus;
    PurchaseOrderRetrievalPreferenceStatusReason?: string;
    Version: number;
    CreateDate: Date;
    LastUpdateDate: Date;
}
export declare const ProcurementPortalPreferenceSummary: S.Schema<ProcurementPortalPreferenceSummary>;
export type ProcurementPortalPreferenceSummaries = ProcurementPortalPreferenceSummary[];
export declare const ProcurementPortalPreferenceSummaries: any;
export interface ListProcurementPortalPreferencesResponse {
    ProcurementPortalPreferences?: ProcurementPortalPreferenceSummary[];
    NextToken?: string;
}
export declare const ListProcurementPortalPreferencesResponse: S.Schema<ListProcurementPortalPreferencesResponse>;
export type TagrisArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    ResourceTags?: ResourceTag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PutProcurementPortalPreferenceRequest {
    ProcurementPortalPreferenceArn: string;
    Selector?: ProcurementPortalPreferenceSelector;
    ProcurementPortalSharedSecret?: string | redacted.Redacted<string>;
    ProcurementPortalInstanceEndpoint?: string;
    TestEnvPreference?: TestEnvPreferenceInput;
    EinvoiceDeliveryEnabled: boolean;
    EinvoiceDeliveryPreference?: EinvoiceDeliveryPreference;
    PurchaseOrderRetrievalEnabled: boolean;
    Contacts: Contact[];
    ClientToken?: string;
}
export declare const PutProcurementPortalPreferenceRequest: S.Schema<PutProcurementPortalPreferenceRequest>;
export interface PutProcurementPortalPreferenceResponse {
    ProcurementPortalPreferenceArn: string;
}
export declare const PutProcurementPortalPreferenceResponse: S.Schema<PutProcurementPortalPreferenceResponse>;
export interface SendProcurementPortalValidationRequest {
    ProcurementPortalPreferenceArn: string;
    ClientToken?: string;
}
export declare const SendProcurementPortalValidationRequest: S.Schema<SendProcurementPortalValidationRequest>;
export interface SendProcurementPortalValidationResponse {
    ProcurementPortalPreferenceArn: string;
}
export declare const SendProcurementPortalValidationResponse: S.Schema<SendProcurementPortalValidationResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    ResourceTags: ResourceTag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type ResourceTagKeyList = string[];
export declare const ResourceTagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    ResourceTagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateInvoiceUnitRequest {
    InvoiceUnitArn: string;
    Description?: string;
    TaxInheritanceDisabled?: boolean;
    Rule?: InvoiceUnitRule;
    ClientToken?: string;
}
export declare const UpdateInvoiceUnitRequest: S.Schema<UpdateInvoiceUnitRequest>;
export interface UpdateInvoiceUnitResponse {
    InvoiceUnitArn?: string;
}
export declare const UpdateInvoiceUnitResponse: S.Schema<UpdateInvoiceUnitResponse>;
export interface UpdateProcurementPortalPreferenceStatusRequest {
    ProcurementPortalPreferenceArn: string;
    EinvoiceDeliveryPreferenceStatus?: ProcurementPortalPreferenceStatus;
    EinvoiceDeliveryPreferenceStatusReason?: string;
    PurchaseOrderRetrievalPreferenceStatus?: ProcurementPortalPreferenceStatus;
    PurchaseOrderRetrievalPreferenceStatusReason?: string;
    ClientToken?: string;
}
export declare const UpdateProcurementPortalPreferenceStatusRequest: S.Schema<UpdateProcurementPortalPreferenceStatusRequest>;
export interface UpdateProcurementPortalPreferenceStatusResponse {
    ProcurementPortalPreferenceArn: string;
}
export declare const UpdateProcurementPortalPreferenceStatusResponse: S.Schema<UpdateProcurementPortalPreferenceStatusResponse>;
export interface VerifyProcurementPortalValidationRequest {
    ProcurementPortalPreferenceArn: string;
    Code: string;
    ClientToken?: string;
}
export declare const VerifyProcurementPortalValidationRequest: S.Schema<VerifyProcurementPortalValidationRequest>;
export interface VerifyProcurementPortalValidationResponse {
    ProcurementPortalPreferenceArn: string;
}
export declare const VerifyProcurementPortalValidationResponse: S.Schema<VerifyProcurementPortalValidationResponse>;
export type ValidationExceptionReason = "nonMemberPresent" | "maxAccountsExceeded" | "maxInvoiceUnitsExceeded" | "duplicateInvoiceUnit" | "mutualExclusionError" | "accountMembershipError" | "taxSettingsError" | "expiredNextToken" | "invalidNextToken" | "invalidInput" | "fieldValidationFailed" | "cannotParse" | "unknownOperation" | "other" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type BatchGetInvoiceProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This gets the invoice profile associated with a set of accounts. The accounts must be linked accounts under the requester management account organization.
 */
export declare const batchGetInvoiceProfile: API.OperationMethod<BatchGetInvoiceProfileRequest, BatchGetInvoiceProfileResponse, BatchGetInvoiceProfileError, Credentials | HttpClient.HttpClient>;
export type CreateInvoiceUnitError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This creates a new invoice unit with the provided definition.
 */
export declare const createInvoiceUnit: API.OperationMethod<CreateInvoiceUnitRequest, CreateInvoiceUnitResponse, CreateInvoiceUnitError, Credentials | HttpClient.HttpClient>;
export type CreateProcurementPortalPreferenceError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Creates a procurement portal preference configuration for e-invoice delivery and purchase order retrieval. This preference defines how invoices are delivered to a procurement portal and how purchase orders are retrieved.
 */
export declare const createProcurementPortalPreference: API.OperationMethod<CreateProcurementPortalPreferenceRequest, CreateProcurementPortalPreferenceResponse, CreateProcurementPortalPreferenceError, Credentials | HttpClient.HttpClient>;
export type DeleteInvoiceUnitError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This deletes an invoice unit with the provided invoice unit ARN.
 */
export declare const deleteInvoiceUnit: API.OperationMethod<DeleteInvoiceUnitRequest, DeleteInvoiceUnitResponse, DeleteInvoiceUnitError, Credentials | HttpClient.HttpClient>;
export type DeleteProcurementPortalPreferenceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Deletes an existing procurement portal preference. This action cannot be undone. Active e-invoice delivery and PO retrieval configurations will be terminated.
 */
export declare const deleteProcurementPortalPreference: API.OperationMethod<DeleteProcurementPortalPreferenceRequest, DeleteProcurementPortalPreferenceResponse, DeleteProcurementPortalPreferenceError, Credentials | HttpClient.HttpClient>;
export type GetInvoicePDFError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a URL to download the invoice document and supplemental documents associated with an invoice. The URLs are pre-signed and have expiration time. For special cases like Brazil, where Amazon Web Services generated invoice identifiers and government provided identifiers do not match, use the Amazon Web Services generated invoice identifier when making API requests. To grant IAM permission to use this operation, the caller needs the `invoicing:GetInvoicePDF` policy action.
 */
export declare const getInvoicePDF: API.OperationMethod<GetInvoicePDFRequest, GetInvoicePDFResponse, GetInvoicePDFError, Credentials | HttpClient.HttpClient>;
export type GetInvoiceUnitError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This retrieves the invoice unit definition.
 */
export declare const getInvoiceUnit: API.OperationMethod<GetInvoiceUnitRequest, GetInvoiceUnitResponse, GetInvoiceUnitError, Credentials | HttpClient.HttpClient>;
export type GetProcurementPortalPreferenceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Retrieves the details of a specific procurement portal preference configuration.
 */
export declare const getProcurementPortalPreference: API.OperationMethod<GetProcurementPortalPreferenceRequest, GetProcurementPortalPreferenceResponse, GetProcurementPortalPreferenceError, Credentials | HttpClient.HttpClient>;
export type ListInvoiceSummariesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves your invoice details programmatically, without line item details.
 */
export declare const listInvoiceSummaries: API.PaginatedOperationMethod<ListInvoiceSummariesRequest, ListInvoiceSummariesResponse, ListInvoiceSummariesError, Credentials | HttpClient.HttpClient, InvoiceSummary>;
export type ListInvoiceUnitsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This fetches a list of all invoice unit definitions for a given account, as of the provided `AsOf` date.
 */
export declare const listInvoiceUnits: API.PaginatedOperationMethod<ListInvoiceUnitsRequest, ListInvoiceUnitsResponse, ListInvoiceUnitsError, Credentials | HttpClient.HttpClient, InvoiceUnit>;
export type ListProcurementPortalPreferencesError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Retrieves a list of procurement portal preferences associated with the Amazon Web Services account.
 */
export declare const listProcurementPortalPreferences: API.PaginatedOperationMethod<ListProcurementPortalPreferencesRequest, ListProcurementPortalPreferencesResponse, ListProcurementPortalPreferencesError, Credentials | HttpClient.HttpClient, ProcurementPortalPreferenceSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutProcurementPortalPreferenceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Updates an existing procurement portal preference configuration. This operation can modify settings for e-invoice delivery and purchase order retrieval.
 */
export declare const putProcurementPortalPreference: API.OperationMethod<PutProcurementPortalPreferenceRequest, PutProcurementPortalPreferenceResponse, PutProcurementPortalPreferenceError, Credentials | HttpClient.HttpClient>;
export type SendProcurementPortalValidationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Sends a validation request for a procurement portal preference. This operation initiates the validation process by issuing a validation code that confirms ownership and connectivity of the configured procurement portal endpoint. Use `VerifyProcurementPortalValidation` to submit the received code and complete validation.
 */
export declare const sendProcurementPortalValidation: API.OperationMethod<SendProcurementPortalValidationRequest, SendProcurementPortalValidationResponse, SendProcurementPortalValidationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a tag to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateInvoiceUnitError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * You can update the invoice unit configuration at any time, and Amazon Web Services will use the latest configuration at the end of the month.
 */
export declare const updateInvoiceUnit: API.OperationMethod<UpdateInvoiceUnitRequest, UpdateInvoiceUnitResponse, UpdateInvoiceUnitError, Credentials | HttpClient.HttpClient>;
export type UpdateProcurementPortalPreferenceStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Updates the status of a procurement portal preference, including the activation state of e-invoice delivery and purchase order retrieval features.
 */
export declare const updateProcurementPortalPreferenceStatus: API.OperationMethod<UpdateProcurementPortalPreferenceStatusRequest, UpdateProcurementPortalPreferenceStatusResponse, UpdateProcurementPortalPreferenceStatusError, Credentials | HttpClient.HttpClient>;
export type VerifyProcurementPortalValidationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Submits a validation code to complete the validation of a procurement portal preference. Use this operation after calling `SendProcurementPortalValidation` to confirm ownership and connectivity of the configured procurement portal endpoint.
 */
export declare const verifyProcurementPortalValidation: API.OperationMethod<VerifyProcurementPortalValidationRequest, VerifyProcurementPortalValidationResponse, VerifyProcurementPortalValidationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=invoicing.d.ts.map