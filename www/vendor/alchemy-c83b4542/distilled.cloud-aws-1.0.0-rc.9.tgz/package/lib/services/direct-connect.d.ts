import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const DirectConnectClientException_base: S.Class<DirectConnectClientException, S.TaggedStruct<"DirectConnectClientException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DirectConnectClientException extends /*@__PURE__*/ DirectConnectClientException_base {
}
declare const DirectConnectServerException_base: S.Class<DirectConnectServerException, S.TaggedStruct<"DirectConnectServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DirectConnectServerException extends /*@__PURE__*/ DirectConnectServerException_base {
}
declare const DuplicateTagKeysException_base: S.Class<DuplicateTagKeysException, S.TaggedStruct<"DuplicateTagKeysException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DuplicateTagKeysException extends /*@__PURE__*/ DuplicateTagKeysException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
export type DirectConnectGatewayId = string;
export type DirectConnectGatewayAssociationProposalId = string;
export type OwnerAccount = string;
export type CIDR = string;
export interface RouteFilterPrefix {
    cidr?: string;
}
export declare const RouteFilterPrefix: S.Schema<RouteFilterPrefix>;
export type RouteFilterPrefixList = RouteFilterPrefix[];
export declare const RouteFilterPrefixList: any;
export interface AcceptDirectConnectGatewayAssociationProposalRequest {
    directConnectGatewayId: string;
    proposalId: string;
    associatedGatewayOwnerAccount: string;
    overrideAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[];
}
export declare const AcceptDirectConnectGatewayAssociationProposalRequest: S.Schema<AcceptDirectConnectGatewayAssociationProposalRequest>;
export type DirectConnectGatewayAssociationState = "associating" | "associated" | "disassociating" | "disassociated" | "updating" | (string & {});
export declare const DirectConnectGatewayAssociationState: any;
export type StateChangeError = string;
export type GatewayIdentifier = string;
export type GatewayType = "virtualPrivateGateway" | "transitGateway" | (string & {});
export declare const GatewayType: any;
export type Region = string;
export interface AssociatedGateway {
    id?: string;
    type?: GatewayType;
    ownerAccount?: string;
    region?: string;
}
export declare const AssociatedGateway: S.Schema<AssociatedGateway>;
export type DirectConnectGatewayAssociationId = string;
export type CoreNetworkIdentifier = string;
export type CoreNetworkAttachmentId = string;
export interface AssociatedCoreNetwork {
    id?: string;
    ownerAccount?: string;
    attachmentId?: string;
}
export declare const AssociatedCoreNetwork: S.Schema<AssociatedCoreNetwork>;
export type VirtualGatewayId = string;
export type VirtualGatewayRegion = string;
export interface DirectConnectGatewayAssociation {
    directConnectGatewayId?: string;
    directConnectGatewayOwnerAccount?: string;
    associationState?: DirectConnectGatewayAssociationState;
    stateChangeError?: string;
    associatedGateway?: AssociatedGateway;
    associationId?: string;
    allowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[];
    associatedCoreNetwork?: AssociatedCoreNetwork;
    virtualGatewayId?: string;
    virtualGatewayRegion?: string;
    virtualGatewayOwnerAccount?: string;
}
export declare const DirectConnectGatewayAssociation: S.Schema<DirectConnectGatewayAssociation>;
export interface AcceptDirectConnectGatewayAssociationProposalResult {
    directConnectGatewayAssociation?: DirectConnectGatewayAssociation;
}
export declare const AcceptDirectConnectGatewayAssociationProposalResult: S.Schema<AcceptDirectConnectGatewayAssociationProposalResult>;
export type Bandwidth = string;
export type ConnectionName = string;
export type InterconnectId = string;
export type VLAN = number;
export interface AllocateConnectionOnInterconnectRequest {
    bandwidth: string;
    connectionName: string;
    ownerAccount: string;
    interconnectId: string;
    vlan: number;
}
export declare const AllocateConnectionOnInterconnectRequest: S.Schema<AllocateConnectionOnInterconnectRequest>;
export type ConnectionId = string;
export type ConnectionState = "ordering" | "requested" | "pending" | "available" | "down" | "deleting" | "deleted" | "rejected" | "unknown" | (string & {});
export declare const ConnectionState: any;
export type LocationCode = string;
export type PartnerName = string;
export type LoaIssueTime = Date;
export type LagId = string;
export type AwsDevice = string;
export type JumboFrameCapable = boolean;
export type AwsDeviceV2 = string;
export type AwsLogicalDeviceId = string;
export type HasLogicalRedundancy = "unknown" | "yes" | "no" | (string & {});
export declare const HasLogicalRedundancy: any;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type ProviderName = string;
export type MacSecCapable = boolean;
export type PortEncryptionStatus = string;
export type EncryptionMode = string;
export type SecretARN = string;
export type Ckn = string;
export type State = string;
export type StartOnDate = string;
export interface MacSecKey {
    secretARN?: string;
    ckn?: string;
    state?: string;
    startOn?: string;
}
export declare const MacSecKey: S.Schema<MacSecKey>;
export type MacSecKeyList = MacSecKey[];
export declare const MacSecKeyList: any;
export type Count = number;
export interface RateLimiterStatus {
    maxAllowed?: number;
    inUse?: number;
    remaining?: number;
    totalBandwidth?: string;
}
export declare const RateLimiterStatus: S.Schema<RateLimiterStatus>;
export type PartnerInterconnectMacSecCapable = boolean;
export type PrefixPoolSize = number;
export type PrefixPoolUnallocatedCount = number;
export interface Connection {
    ownerAccount?: string;
    connectionId?: string;
    connectionName?: string;
    connectionState?: ConnectionState;
    region?: string;
    location?: string;
    bandwidth?: string;
    vlan?: number;
    partnerName?: string;
    loaIssueTime?: Date;
    lagId?: string;
    awsDevice?: string;
    jumboFrameCapable?: boolean;
    awsDeviceV2?: string;
    awsLogicalDeviceId?: string;
    hasLogicalRedundancy?: HasLogicalRedundancy;
    tags?: Tag[];
    providerName?: string;
    macSecCapable?: boolean;
    portEncryptionStatus?: string;
    encryptionMode?: string;
    macSecKeys?: MacSecKey[];
    rateLimiterStatus?: RateLimiterStatus;
    partnerInterconnectMacSecCapable?: boolean;
    prefixPoolSizeIpv4?: number;
    prefixPoolSizeIpv6?: number;
    prefixPoolUnallocatedCountIpv4?: number;
    prefixPoolUnallocatedCountIpv6?: number;
}
export declare const Connection: S.Schema<Connection>;
export interface AllocateHostedConnectionRequest {
    connectionId: string;
    ownerAccount: string;
    bandwidth: string;
    connectionName: string;
    vlan: number;
    tags?: Tag[];
}
export declare const AllocateHostedConnectionRequest: S.Schema<AllocateHostedConnectionRequest>;
export type VirtualInterfaceName = string;
export type ASN = number;
export type LongAsn = number;
export type MTU = number;
export type BGPAuthKey = string;
export type AmazonAddress = string;
export type AddressFamily = "ipv4" | "ipv6" | (string & {});
export declare const AddressFamily: any;
export type CustomerAddress = string;
export type RateLimit = string;
export interface NewPrivateVirtualInterfaceAllocation {
    virtualInterfaceName: string;
    vlan: number;
    asn?: number;
    asnLong?: number;
    mtu?: number;
    authKey?: string;
    amazonAddress?: string;
    addressFamily?: AddressFamily;
    customerAddress?: string;
    tags?: Tag[];
    rateLimit?: string;
}
export declare const NewPrivateVirtualInterfaceAllocation: S.Schema<NewPrivateVirtualInterfaceAllocation>;
export interface AllocatePrivateVirtualInterfaceRequest {
    connectionId: string;
    ownerAccount: string;
    newPrivateVirtualInterfaceAllocation: NewPrivateVirtualInterfaceAllocation;
}
export declare const AllocatePrivateVirtualInterfaceRequest: S.Schema<AllocatePrivateVirtualInterfaceRequest>;
export type VirtualInterfaceId = string;
export type VirtualInterfaceType = string;
export type VirtualInterfaceState = "confirming" | "verifying" | "pending" | "available" | "down" | "testing" | "deleting" | "deleted" | "rejected" | "unknown" | (string & {});
export declare const VirtualInterfaceState: any;
export type RouterConfig = string;
export type BGPPeerId = string;
export type BGPPeerState = "verifying" | "pending" | "available" | "deleting" | "deleted" | (string & {});
export declare const BGPPeerState: any;
export type BGPStatus = "up" | "down" | "unknown" | (string & {});
export declare const BGPStatus: any;
export interface BGPPeer {
    bgpPeerId?: string;
    asn?: number;
    asnLong?: number;
    authKey?: string;
    addressFamily?: AddressFamily;
    amazonAddress?: string;
    customerAddress?: string;
    bgpPeerState?: BGPPeerState;
    bgpStatus?: BGPStatus;
    awsDeviceV2?: string;
    awsLogicalDeviceId?: string;
}
export declare const BGPPeer: S.Schema<BGPPeer>;
export type BGPPeerList = BGPPeer[];
export declare const BGPPeerList: any;
export type SiteLinkEnabled = boolean;
export type PrefixPoolAllocatedCount = number;
export interface VirtualInterface {
    ownerAccount?: string;
    virtualInterfaceId?: string;
    location?: string;
    connectionId?: string;
    virtualInterfaceType?: string;
    virtualInterfaceName?: string;
    vlan?: number;
    asn?: number;
    asnLong?: number;
    amazonSideAsn?: number;
    authKey?: string;
    amazonAddress?: string;
    customerAddress?: string;
    addressFamily?: AddressFamily;
    virtualInterfaceState?: VirtualInterfaceState;
    customerRouterConfig?: string;
    mtu?: number;
    jumboFrameCapable?: boolean;
    virtualGatewayId?: string;
    directConnectGatewayId?: string;
    routeFilterPrefixes?: RouteFilterPrefix[];
    bgpPeers?: BGPPeer[];
    region?: string;
    awsDeviceV2?: string;
    awsLogicalDeviceId?: string;
    tags?: Tag[];
    siteLinkEnabled?: boolean;
    prefixPoolAllocatedCountIpv4?: number;
    prefixPoolAllocatedCountIpv6?: number;
    rateLimit?: string;
}
export declare const VirtualInterface: S.Schema<VirtualInterface>;
export interface NewPublicVirtualInterfaceAllocation {
    virtualInterfaceName: string;
    vlan: number;
    asn?: number;
    asnLong?: number;
    authKey?: string;
    amazonAddress?: string;
    customerAddress?: string;
    addressFamily?: AddressFamily;
    routeFilterPrefixes?: RouteFilterPrefix[];
    tags?: Tag[];
    rateLimit?: string;
}
export declare const NewPublicVirtualInterfaceAllocation: S.Schema<NewPublicVirtualInterfaceAllocation>;
export interface AllocatePublicVirtualInterfaceRequest {
    connectionId: string;
    ownerAccount: string;
    newPublicVirtualInterfaceAllocation: NewPublicVirtualInterfaceAllocation;
}
export declare const AllocatePublicVirtualInterfaceRequest: S.Schema<AllocatePublicVirtualInterfaceRequest>;
export interface NewTransitVirtualInterfaceAllocation {
    virtualInterfaceName?: string;
    vlan?: number;
    asn?: number;
    asnLong?: number;
    mtu?: number;
    authKey?: string;
    amazonAddress?: string;
    customerAddress?: string;
    addressFamily?: AddressFamily;
    tags?: Tag[];
    rateLimit?: string;
}
export declare const NewTransitVirtualInterfaceAllocation: S.Schema<NewTransitVirtualInterfaceAllocation>;
export interface AllocateTransitVirtualInterfaceRequest {
    connectionId: string;
    ownerAccount: string;
    newTransitVirtualInterfaceAllocation: NewTransitVirtualInterfaceAllocation;
}
export declare const AllocateTransitVirtualInterfaceRequest: S.Schema<AllocateTransitVirtualInterfaceRequest>;
export interface AllocateTransitVirtualInterfaceResult {
    virtualInterface?: VirtualInterface;
}
export declare const AllocateTransitVirtualInterfaceResult: S.Schema<AllocateTransitVirtualInterfaceResult>;
export interface AssociateConnectionWithLagRequest {
    connectionId: string;
    lagId: string;
}
export declare const AssociateConnectionWithLagRequest: S.Schema<AssociateConnectionWithLagRequest>;
export interface AssociateHostedConnectionRequest {
    connectionId: string;
    parentConnectionId: string;
}
export declare const AssociateHostedConnectionRequest: S.Schema<AssociateHostedConnectionRequest>;
export type Cak = string;
export interface AssociateMacSecKeyRequest {
    connectionId: string;
    secretARN?: string;
    ckn?: string;
    cak?: string;
}
export declare const AssociateMacSecKeyRequest: S.Schema<AssociateMacSecKeyRequest>;
export interface AssociateMacSecKeyResponse {
    connectionId?: string;
    macSecKeys?: MacSecKey[];
}
export declare const AssociateMacSecKeyResponse: S.Schema<AssociateMacSecKeyResponse>;
export interface AssociateVirtualInterfaceRequest {
    virtualInterfaceId: string;
    connectionId: string;
}
export declare const AssociateVirtualInterfaceRequest: S.Schema<AssociateVirtualInterfaceRequest>;
export interface ConfirmConnectionRequest {
    connectionId: string;
}
export declare const ConfirmConnectionRequest: S.Schema<ConfirmConnectionRequest>;
export interface ConfirmConnectionResponse {
    connectionState?: ConnectionState;
}
export declare const ConfirmConnectionResponse: S.Schema<ConfirmConnectionResponse>;
export type AgreementName = string;
export interface ConfirmCustomerAgreementRequest {
    agreementName?: string;
}
export declare const ConfirmCustomerAgreementRequest: S.Schema<ConfirmCustomerAgreementRequest>;
export type Status = string;
export interface ConfirmCustomerAgreementResponse {
    status?: string;
}
export declare const ConfirmCustomerAgreementResponse: S.Schema<ConfirmCustomerAgreementResponse>;
export interface ConfirmPrivateVirtualInterfaceRequest {
    virtualInterfaceId: string;
    virtualGatewayId?: string;
    directConnectGatewayId?: string;
}
export declare const ConfirmPrivateVirtualInterfaceRequest: S.Schema<ConfirmPrivateVirtualInterfaceRequest>;
export interface ConfirmPrivateVirtualInterfaceResponse {
    virtualInterfaceState?: VirtualInterfaceState;
}
export declare const ConfirmPrivateVirtualInterfaceResponse: S.Schema<ConfirmPrivateVirtualInterfaceResponse>;
export interface ConfirmPublicVirtualInterfaceRequest {
    virtualInterfaceId: string;
}
export declare const ConfirmPublicVirtualInterfaceRequest: S.Schema<ConfirmPublicVirtualInterfaceRequest>;
export interface ConfirmPublicVirtualInterfaceResponse {
    virtualInterfaceState?: VirtualInterfaceState;
}
export declare const ConfirmPublicVirtualInterfaceResponse: S.Schema<ConfirmPublicVirtualInterfaceResponse>;
export interface ConfirmTransitVirtualInterfaceRequest {
    virtualInterfaceId: string;
    directConnectGatewayId: string;
}
export declare const ConfirmTransitVirtualInterfaceRequest: S.Schema<ConfirmTransitVirtualInterfaceRequest>;
export interface ConfirmTransitVirtualInterfaceResponse {
    virtualInterfaceState?: VirtualInterfaceState;
}
export declare const ConfirmTransitVirtualInterfaceResponse: S.Schema<ConfirmTransitVirtualInterfaceResponse>;
export interface NewBGPPeer {
    asn?: number;
    asnLong?: number;
    authKey?: string;
    addressFamily?: AddressFamily;
    amazonAddress?: string;
    customerAddress?: string;
}
export declare const NewBGPPeer: S.Schema<NewBGPPeer>;
export interface CreateBGPPeerRequest {
    virtualInterfaceId?: string;
    newBGPPeer?: NewBGPPeer;
}
export declare const CreateBGPPeerRequest: S.Schema<CreateBGPPeerRequest>;
export interface CreateBGPPeerResponse {
    virtualInterface?: VirtualInterface;
}
export declare const CreateBGPPeerResponse: S.Schema<CreateBGPPeerResponse>;
export type RequestMACSec = boolean;
export interface CreateConnectionRequest {
    location: string;
    bandwidth: string;
    connectionName: string;
    lagId?: string;
    tags?: Tag[];
    providerName?: string;
    requestMACSec?: boolean;
}
export declare const CreateConnectionRequest: S.Schema<CreateConnectionRequest>;
export type DirectConnectGatewayName = string;
export interface CreateDirectConnectGatewayRequest {
    directConnectGatewayName: string;
    tags?: Tag[];
    amazonSideAsn?: number;
}
export declare const CreateDirectConnectGatewayRequest: S.Schema<CreateDirectConnectGatewayRequest>;
export type DirectConnectGatewayState = "pending" | "available" | "deleting" | "deleted" | (string & {});
export declare const DirectConnectGatewayState: any;
export interface DirectConnectGateway {
    directConnectGatewayId?: string;
    directConnectGatewayName?: string;
    amazonSideAsn?: number;
    ownerAccount?: string;
    directConnectGatewayState?: DirectConnectGatewayState;
    stateChangeError?: string;
    totalPrefixPoolAllocations?: number;
    tags?: Tag[];
}
export declare const DirectConnectGateway: S.Schema<DirectConnectGateway>;
export interface CreateDirectConnectGatewayResult {
    directConnectGateway?: DirectConnectGateway;
}
export declare const CreateDirectConnectGatewayResult: S.Schema<CreateDirectConnectGatewayResult>;
export type GatewayIdToAssociate = string;
export interface CreateDirectConnectGatewayAssociationRequest {
    directConnectGatewayId: string;
    gatewayId?: string;
    addAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[];
    virtualGatewayId?: string;
}
export declare const CreateDirectConnectGatewayAssociationRequest: S.Schema<CreateDirectConnectGatewayAssociationRequest>;
export interface CreateDirectConnectGatewayAssociationResult {
    directConnectGatewayAssociation?: DirectConnectGatewayAssociation;
}
export declare const CreateDirectConnectGatewayAssociationResult: S.Schema<CreateDirectConnectGatewayAssociationResult>;
export interface CreateDirectConnectGatewayAssociationProposalRequest {
    directConnectGatewayId: string;
    directConnectGatewayOwnerAccount: string;
    gatewayId: string;
    addAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[];
    removeAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[];
}
export declare const CreateDirectConnectGatewayAssociationProposalRequest: S.Schema<CreateDirectConnectGatewayAssociationProposalRequest>;
export type DirectConnectGatewayAssociationProposalState = "requested" | "accepted" | "deleted" | (string & {});
export declare const DirectConnectGatewayAssociationProposalState: any;
export interface DirectConnectGatewayAssociationProposal {
    proposalId?: string;
    directConnectGatewayId?: string;
    directConnectGatewayOwnerAccount?: string;
    proposalState?: DirectConnectGatewayAssociationProposalState;
    associatedGateway?: AssociatedGateway;
    existingAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[];
    requestedAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[];
}
export declare const DirectConnectGatewayAssociationProposal: S.Schema<DirectConnectGatewayAssociationProposal>;
export interface CreateDirectConnectGatewayAssociationProposalResult {
    directConnectGatewayAssociationProposal?: DirectConnectGatewayAssociationProposal;
}
export declare const CreateDirectConnectGatewayAssociationProposalResult: S.Schema<CreateDirectConnectGatewayAssociationProposalResult>;
export type InterconnectName = string;
export interface CreateInterconnectRequest {
    interconnectName: string;
    bandwidth: string;
    location: string;
    lagId?: string;
    tags?: Tag[];
    providerName?: string;
    requestMACSec?: boolean;
}
export declare const CreateInterconnectRequest: S.Schema<CreateInterconnectRequest>;
export type InterconnectState = "requested" | "pending" | "available" | "down" | "deleting" | "deleted" | "unknown" | (string & {});
export declare const InterconnectState: any;
export interface Interconnect {
    interconnectId?: string;
    interconnectName?: string;
    interconnectState?: InterconnectState;
    region?: string;
    location?: string;
    bandwidth?: string;
    loaIssueTime?: Date;
    lagId?: string;
    awsDevice?: string;
    jumboFrameCapable?: boolean;
    awsDeviceV2?: string;
    awsLogicalDeviceId?: string;
    hasLogicalRedundancy?: HasLogicalRedundancy;
    tags?: Tag[];
    providerName?: string;
    macSecCapable?: boolean;
    portEncryptionStatus?: string;
    encryptionMode?: string;
    macSecKeys?: MacSecKey[];
}
export declare const Interconnect: S.Schema<Interconnect>;
export type LagName = string;
export interface CreateLagRequest {
    numberOfConnections: number;
    location: string;
    connectionsBandwidth: string;
    lagName: string;
    connectionId?: string;
    tags?: Tag[];
    childConnectionTags?: Tag[];
    providerName?: string;
    requestMACSec?: boolean;
}
export declare const CreateLagRequest: S.Schema<CreateLagRequest>;
export type LagState = "requested" | "pending" | "available" | "down" | "deleting" | "deleted" | "unknown" | (string & {});
export declare const LagState: any;
export type ConnectionList = Connection[];
export declare const ConnectionList: any;
export type BooleanFlag = boolean;
export interface Lag {
    connectionsBandwidth?: string;
    numberOfConnections?: number;
    lagId?: string;
    ownerAccount?: string;
    lagName?: string;
    lagState?: LagState;
    location?: string;
    region?: string;
    minimumLinks?: number;
    awsDevice?: string;
    awsDeviceV2?: string;
    awsLogicalDeviceId?: string;
    connections?: Connection[];
    allowsHostedConnections?: boolean;
    jumboFrameCapable?: boolean;
    hasLogicalRedundancy?: HasLogicalRedundancy;
    tags?: Tag[];
    providerName?: string;
    macSecCapable?: boolean;
    encryptionMode?: string;
    macSecKeys?: MacSecKey[];
    prefixPoolSizeIpv4?: number;
    prefixPoolSizeIpv6?: number;
    prefixPoolUnallocatedCountIpv4?: number;
    prefixPoolUnallocatedCountIpv6?: number;
    rateLimiterStatus?: RateLimiterStatus;
}
export declare const Lag: S.Schema<Lag>;
export type EnableSiteLink = boolean;
export interface NewPrivateVirtualInterface {
    virtualInterfaceName: string;
    vlan: number;
    asn?: number;
    asnLong?: number;
    mtu?: number;
    authKey?: string;
    amazonAddress?: string;
    customerAddress?: string;
    addressFamily?: AddressFamily;
    virtualGatewayId?: string;
    directConnectGatewayId?: string;
    tags?: Tag[];
    enableSiteLink?: boolean;
    prefixPoolAllocatedCountIpv4?: number;
    prefixPoolAllocatedCountIpv6?: number;
    rateLimit?: string;
}
export declare const NewPrivateVirtualInterface: S.Schema<NewPrivateVirtualInterface>;
export interface CreatePrivateVirtualInterfaceRequest {
    connectionId: string;
    newPrivateVirtualInterface: NewPrivateVirtualInterface;
}
export declare const CreatePrivateVirtualInterfaceRequest: S.Schema<CreatePrivateVirtualInterfaceRequest>;
export interface NewPublicVirtualInterface {
    virtualInterfaceName: string;
    vlan: number;
    asn?: number;
    asnLong?: number;
    authKey?: string;
    amazonAddress?: string;
    customerAddress?: string;
    addressFamily?: AddressFamily;
    routeFilterPrefixes?: RouteFilterPrefix[];
    tags?: Tag[];
    rateLimit?: string;
}
export declare const NewPublicVirtualInterface: S.Schema<NewPublicVirtualInterface>;
export interface CreatePublicVirtualInterfaceRequest {
    connectionId: string;
    newPublicVirtualInterface: NewPublicVirtualInterface;
}
export declare const CreatePublicVirtualInterfaceRequest: S.Schema<CreatePublicVirtualInterfaceRequest>;
export interface NewTransitVirtualInterface {
    virtualInterfaceName?: string;
    vlan?: number;
    asn?: number;
    asnLong?: number;
    mtu?: number;
    authKey?: string;
    amazonAddress?: string;
    customerAddress?: string;
    addressFamily?: AddressFamily;
    directConnectGatewayId?: string;
    tags?: Tag[];
    enableSiteLink?: boolean;
    prefixPoolAllocatedCountIpv4?: number;
    prefixPoolAllocatedCountIpv6?: number;
    rateLimit?: string;
}
export declare const NewTransitVirtualInterface: S.Schema<NewTransitVirtualInterface>;
export interface CreateTransitVirtualInterfaceRequest {
    connectionId: string;
    newTransitVirtualInterface: NewTransitVirtualInterface;
}
export declare const CreateTransitVirtualInterfaceRequest: S.Schema<CreateTransitVirtualInterfaceRequest>;
export interface CreateTransitVirtualInterfaceResult {
    virtualInterface?: VirtualInterface;
}
export declare const CreateTransitVirtualInterfaceResult: S.Schema<CreateTransitVirtualInterfaceResult>;
export interface DeleteBGPPeerRequest {
    virtualInterfaceId?: string;
    asn?: number;
    asnLong?: number;
    customerAddress?: string;
    bgpPeerId?: string;
}
export declare const DeleteBGPPeerRequest: S.Schema<DeleteBGPPeerRequest>;
export interface DeleteBGPPeerResponse {
    virtualInterface?: VirtualInterface;
}
export declare const DeleteBGPPeerResponse: S.Schema<DeleteBGPPeerResponse>;
export interface DeleteConnectionRequest {
    connectionId: string;
}
export declare const DeleteConnectionRequest: S.Schema<DeleteConnectionRequest>;
export interface DeleteDirectConnectGatewayRequest {
    directConnectGatewayId: string;
}
export declare const DeleteDirectConnectGatewayRequest: S.Schema<DeleteDirectConnectGatewayRequest>;
export interface DeleteDirectConnectGatewayResult {
    directConnectGateway?: DirectConnectGateway;
}
export declare const DeleteDirectConnectGatewayResult: S.Schema<DeleteDirectConnectGatewayResult>;
export interface DeleteDirectConnectGatewayAssociationRequest {
    associationId?: string;
    directConnectGatewayId?: string;
    virtualGatewayId?: string;
}
export declare const DeleteDirectConnectGatewayAssociationRequest: S.Schema<DeleteDirectConnectGatewayAssociationRequest>;
export interface DeleteDirectConnectGatewayAssociationResult {
    directConnectGatewayAssociation?: DirectConnectGatewayAssociation;
}
export declare const DeleteDirectConnectGatewayAssociationResult: S.Schema<DeleteDirectConnectGatewayAssociationResult>;
export interface DeleteDirectConnectGatewayAssociationProposalRequest {
    proposalId: string;
}
export declare const DeleteDirectConnectGatewayAssociationProposalRequest: S.Schema<DeleteDirectConnectGatewayAssociationProposalRequest>;
export interface DeleteDirectConnectGatewayAssociationProposalResult {
    directConnectGatewayAssociationProposal?: DirectConnectGatewayAssociationProposal;
}
export declare const DeleteDirectConnectGatewayAssociationProposalResult: S.Schema<DeleteDirectConnectGatewayAssociationProposalResult>;
export interface DeleteInterconnectRequest {
    interconnectId: string;
}
export declare const DeleteInterconnectRequest: S.Schema<DeleteInterconnectRequest>;
export interface DeleteInterconnectResponse {
    interconnectState?: InterconnectState;
}
export declare const DeleteInterconnectResponse: S.Schema<DeleteInterconnectResponse>;
export interface DeleteLagRequest {
    lagId: string;
}
export declare const DeleteLagRequest: S.Schema<DeleteLagRequest>;
export interface DeleteVirtualInterfaceRequest {
    virtualInterfaceId: string;
}
export declare const DeleteVirtualInterfaceRequest: S.Schema<DeleteVirtualInterfaceRequest>;
export interface DeleteVirtualInterfaceResponse {
    virtualInterfaceState?: VirtualInterfaceState;
}
export declare const DeleteVirtualInterfaceResponse: S.Schema<DeleteVirtualInterfaceResponse>;
export type LoaContentType = "application/pdf" | (string & {});
export declare const LoaContentType: any;
export interface DescribeConnectionLoaRequest {
    connectionId: string;
    providerName?: string;
    loaContentType?: LoaContentType;
}
export declare const DescribeConnectionLoaRequest: S.Schema<DescribeConnectionLoaRequest>;
export type LoaContent = Uint8Array;
export interface Loa {
    loaContent?: Uint8Array;
    loaContentType?: LoaContentType;
}
export declare const Loa: S.Schema<Loa>;
export interface DescribeConnectionLoaResponse {
    loa?: Loa;
}
export declare const DescribeConnectionLoaResponse: S.Schema<DescribeConnectionLoaResponse>;
export type MaxResultSetSize = number;
export type PaginationToken = string;
export interface DescribeConnectionsRequest {
    connectionId?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeConnectionsRequest: S.Schema<DescribeConnectionsRequest>;
export interface Connections {
    connections?: Connection[];
    nextToken?: string;
}
export declare const Connections: S.Schema<Connections>;
export interface DescribeConnectionsOnInterconnectRequest {
    interconnectId: string;
}
export declare const DescribeConnectionsOnInterconnectRequest: S.Schema<DescribeConnectionsOnInterconnectRequest>;
export interface DescribeCustomerMetadataRequest {
}
export declare const DescribeCustomerMetadataRequest: S.Schema<DescribeCustomerMetadataRequest>;
export interface CustomerAgreement {
    agreementName?: string;
    status?: string;
}
export declare const CustomerAgreement: S.Schema<CustomerAgreement>;
export type AgreementList = CustomerAgreement[];
export declare const AgreementList: any;
export type NniPartnerType = "v1" | "v2" | "nonPartner" | (string & {});
export declare const NniPartnerType: any;
export interface DescribeCustomerMetadataResponse {
    agreements?: CustomerAgreement[];
    nniPartnerType?: NniPartnerType;
}
export declare const DescribeCustomerMetadataResponse: S.Schema<DescribeCustomerMetadataResponse>;
export type AssociatedGatewayId = string;
export interface DescribeDirectConnectGatewayAssociationProposalsRequest {
    directConnectGatewayId?: string;
    proposalId?: string;
    associatedGatewayId?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeDirectConnectGatewayAssociationProposalsRequest: S.Schema<DescribeDirectConnectGatewayAssociationProposalsRequest>;
export type DirectConnectGatewayAssociationProposalList = DirectConnectGatewayAssociationProposal[];
export declare const DirectConnectGatewayAssociationProposalList: any;
export interface DescribeDirectConnectGatewayAssociationProposalsResult {
    directConnectGatewayAssociationProposals?: DirectConnectGatewayAssociationProposal[];
    nextToken?: string;
}
export declare const DescribeDirectConnectGatewayAssociationProposalsResult: S.Schema<DescribeDirectConnectGatewayAssociationProposalsResult>;
export interface DescribeDirectConnectGatewayAssociationsRequest {
    associationId?: string;
    associatedGatewayId?: string;
    directConnectGatewayId?: string;
    maxResults?: number;
    nextToken?: string;
    virtualGatewayId?: string;
}
export declare const DescribeDirectConnectGatewayAssociationsRequest: S.Schema<DescribeDirectConnectGatewayAssociationsRequest>;
export type DirectConnectGatewayAssociationList = DirectConnectGatewayAssociation[];
export declare const DirectConnectGatewayAssociationList: any;
export interface DescribeDirectConnectGatewayAssociationsResult {
    directConnectGatewayAssociations?: DirectConnectGatewayAssociation[];
    nextToken?: string;
}
export declare const DescribeDirectConnectGatewayAssociationsResult: S.Schema<DescribeDirectConnectGatewayAssociationsResult>;
export interface DescribeDirectConnectGatewayAttachmentsRequest {
    directConnectGatewayId?: string;
    virtualInterfaceId?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeDirectConnectGatewayAttachmentsRequest: S.Schema<DescribeDirectConnectGatewayAttachmentsRequest>;
export type VirtualInterfaceRegion = string;
export type DirectConnectGatewayAttachmentState = "attaching" | "attached" | "detaching" | "detached" | (string & {});
export declare const DirectConnectGatewayAttachmentState: any;
export type DirectConnectGatewayAttachmentType = "TransitVirtualInterface" | "PrivateVirtualInterface" | (string & {});
export declare const DirectConnectGatewayAttachmentType: any;
export interface DirectConnectGatewayAttachment {
    directConnectGatewayId?: string;
    virtualInterfaceId?: string;
    virtualInterfaceRegion?: string;
    virtualInterfaceOwnerAccount?: string;
    attachmentState?: DirectConnectGatewayAttachmentState;
    attachmentType?: DirectConnectGatewayAttachmentType;
    stateChangeError?: string;
}
export declare const DirectConnectGatewayAttachment: S.Schema<DirectConnectGatewayAttachment>;
export type DirectConnectGatewayAttachmentList = DirectConnectGatewayAttachment[];
export declare const DirectConnectGatewayAttachmentList: any;
export interface DescribeDirectConnectGatewayAttachmentsResult {
    directConnectGatewayAttachments?: DirectConnectGatewayAttachment[];
    nextToken?: string;
}
export declare const DescribeDirectConnectGatewayAttachmentsResult: S.Schema<DescribeDirectConnectGatewayAttachmentsResult>;
export interface DescribeDirectConnectGatewaysRequest {
    directConnectGatewayId?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeDirectConnectGatewaysRequest: S.Schema<DescribeDirectConnectGatewaysRequest>;
export type DirectConnectGatewayList = DirectConnectGateway[];
export declare const DirectConnectGatewayList: any;
export interface DescribeDirectConnectGatewaysResult {
    directConnectGateways?: DirectConnectGateway[];
    nextToken?: string;
}
export declare const DescribeDirectConnectGatewaysResult: S.Schema<DescribeDirectConnectGatewaysResult>;
export interface DescribeHostedConnectionsRequest {
    connectionId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeHostedConnectionsRequest: S.Schema<DescribeHostedConnectionsRequest>;
export interface DescribeInterconnectLoaRequest {
    interconnectId: string;
    providerName?: string;
    loaContentType?: LoaContentType;
}
export declare const DescribeInterconnectLoaRequest: S.Schema<DescribeInterconnectLoaRequest>;
export interface DescribeInterconnectLoaResponse {
    loa?: Loa;
}
export declare const DescribeInterconnectLoaResponse: S.Schema<DescribeInterconnectLoaResponse>;
export interface DescribeInterconnectsRequest {
    interconnectId?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeInterconnectsRequest: S.Schema<DescribeInterconnectsRequest>;
export type InterconnectList = Interconnect[];
export declare const InterconnectList: any;
export interface Interconnects {
    interconnects?: Interconnect[];
    nextToken?: string;
}
export declare const Interconnects: S.Schema<Interconnects>;
export interface DescribeLagsRequest {
    lagId?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeLagsRequest: S.Schema<DescribeLagsRequest>;
export type LagList = Lag[];
export declare const LagList: any;
export interface Lags {
    lags?: Lag[];
    nextToken?: string;
}
export declare const Lags: S.Schema<Lags>;
export interface DescribeLoaRequest {
    connectionId: string;
    providerName?: string;
    loaContentType?: LoaContentType;
}
export declare const DescribeLoaRequest: S.Schema<DescribeLoaRequest>;
export interface DescribeLocationsRequest {
}
export declare const DescribeLocationsRequest: S.Schema<DescribeLocationsRequest>;
export type LocationName = string;
export type PortSpeed = string;
export type AvailablePortSpeeds = string[];
export declare const AvailablePortSpeeds: any;
export type ProviderList = string[];
export declare const ProviderList: any;
export type AvailableMacSecPortSpeeds = string[];
export declare const AvailableMacSecPortSpeeds: any;
export interface Location {
    locationCode?: string;
    locationName?: string;
    region?: string;
    availablePortSpeeds?: string[];
    availableProviders?: string[];
    availableMacSecPortSpeeds?: string[];
}
export declare const Location: S.Schema<Location>;
export type LocationList = Location[];
export declare const LocationList: any;
export interface Locations {
    locations?: Location[];
}
export declare const Locations: S.Schema<Locations>;
export type RouterTypeIdentifier = string;
export interface DescribeRouterConfigurationRequest {
    virtualInterfaceId: string;
    routerTypeIdentifier?: string;
}
export declare const DescribeRouterConfigurationRequest: S.Schema<DescribeRouterConfigurationRequest>;
export type Vendor = string;
export type Platform = string;
export type Software = string;
export type XsltTemplateName = string;
export type XsltTemplateNameForMacSec = string;
export interface RouterType {
    vendor?: string;
    platform?: string;
    software?: string;
    xsltTemplateName?: string;
    xsltTemplateNameForMacSec?: string;
    routerTypeIdentifier?: string;
}
export declare const RouterType: S.Schema<RouterType>;
export interface DescribeRouterConfigurationResponse {
    customerRouterConfig?: string;
    router?: RouterType;
    virtualInterfaceId?: string;
    virtualInterfaceName?: string;
}
export declare const DescribeRouterConfigurationResponse: S.Schema<DescribeRouterConfigurationResponse>;
export type ResourceArn = string;
export type ResourceArnList = string[];
export declare const ResourceArnList: any;
export interface DescribeTagsRequest {
    resourceArns: string[];
}
export declare const DescribeTagsRequest: S.Schema<DescribeTagsRequest>;
export interface ResourceTag {
    resourceArn?: string;
    tags?: Tag[];
}
export declare const ResourceTag: S.Schema<ResourceTag>;
export type ResourceTagList = ResourceTag[];
export declare const ResourceTagList: any;
export interface DescribeTagsResponse {
    resourceTags?: ResourceTag[];
}
export declare const DescribeTagsResponse: S.Schema<DescribeTagsResponse>;
export interface DescribeVirtualGatewaysRequest {
}
export declare const DescribeVirtualGatewaysRequest: S.Schema<DescribeVirtualGatewaysRequest>;
export type VirtualGatewayState = string;
export interface VirtualGateway {
    virtualGatewayId?: string;
    virtualGatewayState?: string;
}
export declare const VirtualGateway: S.Schema<VirtualGateway>;
export type VirtualGatewayList = VirtualGateway[];
export declare const VirtualGatewayList: any;
export interface VirtualGateways {
    virtualGateways?: VirtualGateway[];
}
export declare const VirtualGateways: S.Schema<VirtualGateways>;
export interface DescribeVirtualInterfacesRequest {
    connectionId?: string;
    virtualInterfaceId?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeVirtualInterfacesRequest: S.Schema<DescribeVirtualInterfacesRequest>;
export type VirtualInterfaceList = VirtualInterface[];
export declare const VirtualInterfaceList: any;
export interface VirtualInterfaces {
    virtualInterfaces?: VirtualInterface[];
    nextToken?: string;
}
export declare const VirtualInterfaces: S.Schema<VirtualInterfaces>;
export interface DisassociateConnectionFromLagRequest {
    connectionId: string;
    lagId: string;
}
export declare const DisassociateConnectionFromLagRequest: S.Schema<DisassociateConnectionFromLagRequest>;
export interface DisassociateMacSecKeyRequest {
    connectionId: string;
    secretARN: string;
}
export declare const DisassociateMacSecKeyRequest: S.Schema<DisassociateMacSecKeyRequest>;
export interface DisassociateMacSecKeyResponse {
    connectionId?: string;
    macSecKeys?: MacSecKey[];
}
export declare const DisassociateMacSecKeyResponse: S.Schema<DisassociateMacSecKeyResponse>;
export type RouteDirection = "accepted" | "advertised" | (string & {});
export declare const RouteDirection: any;
export type RouteFilterCidrString = string;
export type RouteFilterCidrStringList = string[];
export declare const RouteFilterCidrStringList: any;
export type AsPathList = number[];
export declare const AsPathList: any;
export type CommunityEntry = string;
export type CommunityList = string[];
export declare const CommunityList: any;
export interface RouteFilters {
    routeDirection?: RouteDirection;
    addressFamily?: AddressFamily;
    cidrs?: string[];
    asPath?: number[];
    communities?: string[];
}
export declare const RouteFilters: S.Schema<RouteFilters>;
export interface ListVirtualInterfaceRoutesRequest {
    virtualInterfaceId?: string;
    filters?: RouteFilters;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListVirtualInterfaceRoutesRequest: S.Schema<ListVirtualInterfaceRoutesRequest>;
export type RouteCidr = string;
export type AsPathType = "seq" | "set" | (string & {});
export declare const AsPathType: any;
export interface AsPathSegment {
    pathType?: AsPathType;
    path?: number[];
}
export declare const AsPathSegment: S.Schema<AsPathSegment>;
export type AsPathSegmentList = AsPathSegment[];
export declare const AsPathSegmentList: any;
export type RouteInstalledAt = Date;
export interface Route {
    cidr?: string;
    routeDirection?: RouteDirection;
    addressFamily?: AddressFamily;
    asPath?: AsPathSegment[];
    communities?: string[];
    awsLogicalDeviceId?: string;
    routeInstalledAt?: Date;
}
export declare const Route: S.Schema<Route>;
export type RouteList = Route[];
export declare const RouteList: any;
export interface ListVirtualInterfaceRoutesResponse {
    virtualInterfaceId?: string;
    routes?: Route[];
    nextToken?: string;
}
export declare const ListVirtualInterfaceRoutesResponse: S.Schema<ListVirtualInterfaceRoutesResponse>;
export type TestId = string;
export type BGPPeerIdList = string[];
export declare const BGPPeerIdList: any;
export type FailureTestHistoryStatus = string;
export interface ListVirtualInterfaceTestHistoryRequest {
    testId?: string;
    virtualInterfaceId?: string;
    bgpPeers?: string[];
    status?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListVirtualInterfaceTestHistoryRequest: S.Schema<ListVirtualInterfaceTestHistoryRequest>;
export type TestDuration = number;
export type StartTime = Date;
export type EndTime = Date;
export interface VirtualInterfaceTestHistory {
    testId?: string;
    virtualInterfaceId?: string;
    bgpPeers?: string[];
    status?: string;
    ownerAccount?: string;
    testDurationInMinutes?: number;
    startTime?: Date;
    endTime?: Date;
}
export declare const VirtualInterfaceTestHistory: S.Schema<VirtualInterfaceTestHistory>;
export type VirtualInterfaceTestHistoryList = VirtualInterfaceTestHistory[];
export declare const VirtualInterfaceTestHistoryList: any;
export interface ListVirtualInterfaceTestHistoryResponse {
    virtualInterfaceTestHistory?: VirtualInterfaceTestHistory[];
    nextToken?: string;
}
export declare const ListVirtualInterfaceTestHistoryResponse: S.Schema<ListVirtualInterfaceTestHistoryResponse>;
export interface StartBgpFailoverTestRequest {
    virtualInterfaceId: string;
    bgpPeers?: string[];
    testDurationInMinutes?: number;
}
export declare const StartBgpFailoverTestRequest: S.Schema<StartBgpFailoverTestRequest>;
export interface StartBgpFailoverTestResponse {
    virtualInterfaceTest?: VirtualInterfaceTestHistory;
}
export declare const StartBgpFailoverTestResponse: S.Schema<StartBgpFailoverTestResponse>;
export interface StopBgpFailoverTestRequest {
    virtualInterfaceId: string;
}
export declare const StopBgpFailoverTestRequest: S.Schema<StopBgpFailoverTestRequest>;
export interface StopBgpFailoverTestResponse {
    virtualInterfaceTest?: VirtualInterfaceTestHistory;
}
export declare const StopBgpFailoverTestResponse: S.Schema<StopBgpFailoverTestResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateConnectionRequest {
    connectionId: string;
    connectionName?: string;
    encryptionMode?: string;
}
export declare const UpdateConnectionRequest: S.Schema<UpdateConnectionRequest>;
export interface UpdateDirectConnectGatewayRequest {
    directConnectGatewayId: string;
    newDirectConnectGatewayName: string;
}
export declare const UpdateDirectConnectGatewayRequest: S.Schema<UpdateDirectConnectGatewayRequest>;
export interface UpdateDirectConnectGatewayResponse {
    directConnectGateway?: DirectConnectGateway;
}
export declare const UpdateDirectConnectGatewayResponse: S.Schema<UpdateDirectConnectGatewayResponse>;
export interface UpdateDirectConnectGatewayAssociationRequest {
    associationId?: string;
    addAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[];
    removeAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[];
}
export declare const UpdateDirectConnectGatewayAssociationRequest: S.Schema<UpdateDirectConnectGatewayAssociationRequest>;
export interface UpdateDirectConnectGatewayAssociationResult {
    directConnectGatewayAssociation?: DirectConnectGatewayAssociation;
}
export declare const UpdateDirectConnectGatewayAssociationResult: S.Schema<UpdateDirectConnectGatewayAssociationResult>;
export interface UpdateLagRequest {
    lagId: string;
    lagName?: string;
    minimumLinks?: number;
    encryptionMode?: string;
}
export declare const UpdateLagRequest: S.Schema<UpdateLagRequest>;
export interface UpdateVirtualInterfaceAttributesRequest {
    virtualInterfaceId: string;
    mtu?: number;
    enableSiteLink?: boolean;
    virtualInterfaceName?: string;
    prefixPoolAllocatedCountIpv4?: number;
    prefixPoolAllocatedCountIpv6?: number;
    rateLimit?: string;
}
export declare const UpdateVirtualInterfaceAttributesRequest: S.Schema<UpdateVirtualInterfaceAttributesRequest>;
export type ErrorMessage = string;
export type AcceptDirectConnectGatewayAssociationProposalError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Accepts a proposal request to attach a virtual private gateway or transit gateway to a Direct Connect gateway.
 */
export declare const acceptDirectConnectGatewayAssociationProposal: API.OperationMethod<AcceptDirectConnectGatewayAssociationProposalRequest, AcceptDirectConnectGatewayAssociationProposalResult, AcceptDirectConnectGatewayAssociationProposalError, Credentials | HttpClient.HttpClient>;
export type AllocateConnectionOnInterconnectError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deprecated. Use AllocateHostedConnection instead.
 *
 * Creates a hosted connection on an interconnect.
 *
 * Allocates a VLAN number and a specified amount of bandwidth for use by a hosted connection on the specified interconnect.
 *
 * Intended for use by Direct Connect Partners only.
 */
export declare const allocateConnectionOnInterconnect: API.OperationMethod<AllocateConnectionOnInterconnectRequest, Connection, AllocateConnectionOnInterconnectError, Credentials | HttpClient.HttpClient>;
export type AllocateHostedConnectionError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | TooManyTagsException | CommonErrors;
/**
 * Creates a hosted connection on the specified interconnect or a link aggregation group (LAG) of interconnects.
 *
 * Allocates a VLAN number and a specified amount of capacity (bandwidth) for use by a hosted connection on the specified interconnect or LAG of interconnects.
 * Amazon Web Services polices the hosted connection for the specified capacity and the Direct Connect Partner must also police the hosted connection for the specified capacity.
 *
 * Intended for use by Direct Connect Partners only.
 */
export declare const allocateHostedConnection: API.OperationMethod<AllocateHostedConnectionRequest, Connection, AllocateHostedConnectionError, Credentials | HttpClient.HttpClient>;
export type AllocatePrivateVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | LimitExceededException | TooManyTagsException | CommonErrors;
/**
 * Provisions a private virtual interface to be owned by the specified Amazon Web Services account.
 *
 * Virtual interfaces created using this action must be confirmed by the owner using ConfirmPrivateVirtualInterface.
 * Until then, the virtual interface is in the `Confirming` state and is not available to handle traffic.
 */
export declare const allocatePrivateVirtualInterface: API.OperationMethod<AllocatePrivateVirtualInterfaceRequest, VirtualInterface, AllocatePrivateVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type AllocatePublicVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | LimitExceededException | TooManyTagsException | CommonErrors;
/**
 * Provisions a public virtual interface to be owned by the specified Amazon Web Services account.
 *
 * The owner of a connection calls this function to provision a public virtual interface to be owned by the specified Amazon Web Services account.
 *
 * Virtual interfaces created using this function must be confirmed by the owner using ConfirmPublicVirtualInterface.
 * Until this step has been completed, the virtual interface is in the `confirming` state and is not available to handle traffic.
 *
 * When creating an IPv6 public virtual interface, omit the Amazon address and customer address. IPv6 addresses are automatically assigned from
 * the Amazon pool of IPv6 addresses; you cannot specify custom IPv6 addresses.
 */
export declare const allocatePublicVirtualInterface: API.OperationMethod<AllocatePublicVirtualInterfaceRequest, VirtualInterface, AllocatePublicVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type AllocateTransitVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | LimitExceededException | TooManyTagsException | CommonErrors;
/**
 * Provisions a transit virtual interface to be owned by the specified Amazon Web Services account. Use this type of interface to connect a transit gateway to your Direct Connect gateway.
 *
 * The owner of a connection provisions a transit virtual interface to be owned by the specified Amazon Web Services account.
 *
 * After you create a transit virtual interface, it must be confirmed by the owner using ConfirmTransitVirtualInterface. Until this step has been completed, the transit virtual interface is in the `requested` state and is not available to handle traffic.
 */
export declare const allocateTransitVirtualInterface: API.OperationMethod<AllocateTransitVirtualInterfaceRequest, AllocateTransitVirtualInterfaceResult, AllocateTransitVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type AssociateConnectionWithLagError = DirectConnectClientException | DirectConnectServerException | LimitExceededException | CommonErrors;
/**
 * Associates an existing connection with a link aggregation group (LAG). The connection
 * is interrupted and re-established as a member of the LAG (connectivity to Amazon Web Services is
 * interrupted). The connection must be hosted on the same Direct Connect endpoint as the LAG, and its
 * bandwidth must match the bandwidth for the LAG. You can re-associate a connection that's
 * currently associated with a different LAG; however, if removing the connection would cause
 * the original LAG to fall below its setting for minimum number of operational connections,
 * the request fails.
 *
 * Any virtual interfaces that are directly associated with the connection are
 * automatically re-associated with the LAG. If the connection was originally associated
 * with a different LAG, the virtual interfaces remain associated with the original
 * LAG.
 *
 * For interconnects, any hosted connections are automatically re-associated with the
 * LAG. If the interconnect was originally associated with a different LAG, the hosted
 * connections remain associated with the original LAG.
 */
export declare const associateConnectionWithLag: API.OperationMethod<AssociateConnectionWithLagRequest, Connection, AssociateConnectionWithLagError, Credentials | HttpClient.HttpClient>;
export type AssociateHostedConnectionError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Associates a hosted connection and its virtual interfaces with a link aggregation
 * group (LAG) or interconnect. If the target interconnect or LAG has an existing hosted
 * connection with a conflicting VLAN number or IP address, the operation fails. This
 * action temporarily interrupts the hosted connection's connectivity to Amazon Web Services
 * as it is being migrated.
 *
 * Intended for use by Direct Connect Partners only.
 */
export declare const associateHostedConnection: API.OperationMethod<AssociateHostedConnectionRequest, Connection, AssociateHostedConnectionError, Credentials | HttpClient.HttpClient>;
export type AssociateMacSecKeyError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Associates a MAC Security (MACsec) Connection Key Name (CKN)/ Connectivity Association Key (CAK) pair with a Direct Connect connection.
 *
 * You must supply either the `secretARN,` or the CKN/CAK (`ckn` and `cak`) pair in the request.
 *
 * For information about MAC Security (MACsec) key considerations, see MACsec pre-shared CKN/CAK key considerations in the *Direct Connect User Guide*.
 */
export declare const associateMacSecKey: API.OperationMethod<AssociateMacSecKeyRequest, AssociateMacSecKeyResponse, AssociateMacSecKeyError, Credentials | HttpClient.HttpClient>;
export type AssociateVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Associates a virtual interface with a specified link aggregation group (LAG) or
 * connection. Connectivity to Amazon Web Services is temporarily interrupted as the virtual interface is
 * being migrated. If the target connection or LAG has an associated virtual interface with
 * a conflicting VLAN number or a conflicting IP address, the operation fails.
 *
 * Virtual interfaces associated with a hosted connection cannot be associated with a
 * LAG; hosted connections must be migrated along with their virtual interfaces using AssociateHostedConnection.
 *
 * To reassociate a virtual interface to a new connection or LAG, the requester
 * must own either the virtual interface itself or the connection to which the virtual
 * interface is currently associated. Additionally, the requester must own the connection
 * or LAG for the association.
 */
export declare const associateVirtualInterface: API.OperationMethod<AssociateVirtualInterfaceRequest, VirtualInterface, AssociateVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type ConfirmConnectionError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Confirms the creation of the specified hosted connection on an interconnect.
 *
 * Upon creation, the hosted connection is initially in the `Ordering` state, and
 * remains in this state until the owner confirms creation of the hosted connection.
 */
export declare const confirmConnection: API.OperationMethod<ConfirmConnectionRequest, ConfirmConnectionResponse, ConfirmConnectionError, Credentials | HttpClient.HttpClient>;
export type ConfirmCustomerAgreementError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * The confirmation of the terms of agreement when creating the connection/link aggregation group (LAG).
 */
export declare const confirmCustomerAgreement: API.OperationMethod<ConfirmCustomerAgreementRequest, ConfirmCustomerAgreementResponse, ConfirmCustomerAgreementError, Credentials | HttpClient.HttpClient>;
export type ConfirmPrivateVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Accepts ownership of a private virtual interface created by another Amazon Web Services account.
 *
 * After the virtual interface owner makes this call, the virtual interface is
 * created and attached to the specified virtual private gateway or Direct Connect gateway, and is
 * made available to handle traffic.
 */
export declare const confirmPrivateVirtualInterface: API.OperationMethod<ConfirmPrivateVirtualInterfaceRequest, ConfirmPrivateVirtualInterfaceResponse, ConfirmPrivateVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type ConfirmPublicVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Accepts ownership of a public virtual interface created by another Amazon Web Services account.
 *
 * After the virtual interface owner makes this call, the specified virtual interface is
 * created and made available to handle traffic.
 */
export declare const confirmPublicVirtualInterface: API.OperationMethod<ConfirmPublicVirtualInterfaceRequest, ConfirmPublicVirtualInterfaceResponse, ConfirmPublicVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type ConfirmTransitVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Accepts ownership of a transit virtual interface created by another Amazon Web Services account.
 *
 * After the owner of the transit virtual interface makes this call, the specified transit virtual interface is created and made available to handle traffic.
 */
export declare const confirmTransitVirtualInterface: API.OperationMethod<ConfirmTransitVirtualInterfaceRequest, ConfirmTransitVirtualInterfaceResponse, ConfirmTransitVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type CreateBGPPeerError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Creates a BGP peer on the specified virtual interface.
 *
 * You must create a BGP peer for the corresponding address family (IPv4/IPv6) in order to
 * access Amazon Web Services resources that also use that address family.
 *
 * If logical redundancy is not supported by the connection, interconnect, or LAG, the BGP peer cannot
 * be in the same address family as an existing BGP peer on the virtual interface.
 *
 * When creating a IPv6 BGP peer, omit the Amazon address and customer address. IPv6 addresses are automatically assigned from
 * the Amazon pool of IPv6 addresses; you cannot specify custom IPv6 addresses.
 *
 * If you let Amazon Web Services auto-assign IPv4 addresses, a /30 CIDR will be allocated
 * from 169.254.0.0/16. Amazon Web Services does not recommend this option if you intend to use
 * the customer router peer IP address as the source and destination for traffic. Instead you
 * should use RFC 1918 or other addressing, and specify the address yourself. For more
 * information about RFC 1918 see
 * Address Allocation for Private Internets.
 *
 * For a public virtual interface, the Autonomous System Number (ASN) must be private or already on the allow list for the virtual interface.
 */
export declare const createBGPPeer: API.OperationMethod<CreateBGPPeerRequest, CreateBGPPeerResponse, CreateBGPPeerError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | TooManyTagsException | CommonErrors;
/**
 * Creates a connection between a customer network and a specific Direct Connect location.
 *
 * A connection links your internal network to an Direct Connect location over a standard Ethernet fiber-optic
 * cable. One end of the cable is connected to your router, the other to an Direct Connect router.
 *
 * To find the locations for your Region, use DescribeLocations.
 *
 * You can automatically add the new connection to a link aggregation group (LAG) by
 * specifying a LAG ID in the request. This ensures that the new connection is allocated on the
 * same Direct Connect endpoint that hosts the specified LAG. If there are no available ports on the endpoint,
 * the request fails and no connection is created.
 */
export declare const createConnection: API.OperationMethod<CreateConnectionRequest, Connection, CreateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateDirectConnectGatewayError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Creates a Direct Connect gateway, which is an intermediate object that enables you to connect a set
 * of virtual interfaces and virtual private gateways. A Direct Connect gateway is global and visible in any
 * Amazon Web Services Region after it is created. The virtual interfaces and virtual private gateways that
 * are connected through a Direct Connect gateway can be in different Amazon Web Services Regions. This enables you to
 * connect to a VPC in any Region, regardless of the Region in which the virtual interfaces
 * are located, and pass traffic between them.
 */
export declare const createDirectConnectGateway: API.OperationMethod<CreateDirectConnectGatewayRequest, CreateDirectConnectGatewayResult, CreateDirectConnectGatewayError, Credentials | HttpClient.HttpClient>;
export type CreateDirectConnectGatewayAssociationError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Creates an association between a Direct Connect gateway and a virtual private gateway. The virtual
 * private gateway must be attached to a VPC and must not be associated with another Direct Connect gateway.
 */
export declare const createDirectConnectGatewayAssociation: API.OperationMethod<CreateDirectConnectGatewayAssociationRequest, CreateDirectConnectGatewayAssociationResult, CreateDirectConnectGatewayAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateDirectConnectGatewayAssociationProposalError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Creates a proposal to associate the specified virtual private gateway or transit gateway with the specified Direct Connect gateway.
 *
 * You can associate a Direct Connect gateway and virtual private gateway or transit gateway that is owned by any Amazon Web Services account.
 */
export declare const createDirectConnectGatewayAssociationProposal: API.OperationMethod<CreateDirectConnectGatewayAssociationProposalRequest, CreateDirectConnectGatewayAssociationProposalResult, CreateDirectConnectGatewayAssociationProposalError, Credentials | HttpClient.HttpClient>;
export type CreateInterconnectError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | TooManyTagsException | CommonErrors;
/**
 * Creates an interconnect between an Direct Connect Partner's network and a specific Direct Connect location.
 *
 * An interconnect is a connection that is capable of hosting other connections. The
 * Direct Connect Partner can use an interconnect to provide Direct Connect hosted
 * connections to customers through their own network services. Like a standard connection, an
 * interconnect links the partner's network to an Direct Connect location over a standard Ethernet
 * fiber-optic cable. One end is connected to the partner's router, the other to an Direct Connect
 * router.
 *
 * You can automatically add the new interconnect to a link aggregation group (LAG) by
 * specifying a LAG ID in the request. This ensures that the new interconnect is allocated on
 * the same Direct Connect endpoint that hosts the specified LAG. If there are no available ports on the
 * endpoint, the request fails and no interconnect is created.
 *
 * For each end customer, the Direct Connect Partner provisions a connection on their interconnect by calling AllocateHostedConnection.
 * The end customer can then connect to Amazon Web Services resources by creating a virtual interface on their connection, using the VLAN assigned to them by the Direct Connect Partner.
 *
 * Intended for use by Direct Connect Partners only.
 */
export declare const createInterconnect: API.OperationMethod<CreateInterconnectRequest, Interconnect, CreateInterconnectError, Credentials | HttpClient.HttpClient>;
export type CreateLagError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | TooManyTagsException | CommonErrors;
/**
 * Creates a link aggregation group (LAG) with the specified number of bundled
 * physical dedicated connections between the customer network and a specific Direct Connect location.
 * A LAG is a logical interface that uses the Link Aggregation Control Protocol
 * (LACP) to aggregate multiple interfaces, enabling you to treat them as a single
 * interface.
 *
 * All connections in a LAG must use the same bandwidth (either 1Gbps, 10Gbps, 100Gbps,
 * or 400Gbps) and must terminate at the same Direct Connect endpoint.
 *
 * You can have up to 10 dedicated connections per location. Regardless of this limit, if you
 * request more connections for the LAG than Direct Connect can allocate on a single endpoint, no LAG is
 * created..
 *
 * You can specify an existing physical dedicated connection or interconnect to include in
 * the LAG (which counts towards the total number of connections). Doing so interrupts the
 * current physical dedicated connection, and re-establishes them as a member of the LAG. The LAG
 * will be created on the same Direct Connect endpoint to which the dedicated connection terminates. Any
 * virtual interfaces associated with the dedicated connection are automatically disassociated
 * and re-associated with the LAG. The connection ID does not change.
 *
 * If the Amazon Web Services account used to create a LAG is a registered Direct Connect Partner, the LAG is
 * automatically enabled to host sub-connections. For a LAG owned by a partner, any associated virtual
 * interfaces cannot be directly configured.
 */
export declare const createLag: API.OperationMethod<CreateLagRequest, Lag, CreateLagError, Credentials | HttpClient.HttpClient>;
export type CreatePrivateVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | LimitExceededException | TooManyTagsException | CommonErrors;
/**
 * Creates a private virtual interface. A virtual interface is the VLAN that transports Direct Connect traffic.
 * A private virtual interface can be connected to either a Direct Connect gateway or a Virtual Private Gateway (VGW).
 * Connecting the private virtual interface to a Direct Connect gateway enables the possibility for connecting to multiple
 * VPCs, including VPCs in different Amazon Web Services Regions. Connecting the private virtual interface
 * to a VGW only provides access to a single VPC within the same Region.
 *
 * Setting the MTU of a virtual interface to 8500 (jumbo frames) can cause an update to
 * the underlying physical connection if it wasn't updated to support jumbo frames. Updating
 * the connection disrupts network connectivity for all virtual interfaces associated with
 * the connection for up to 30 seconds. To check whether your connection supports jumbo
 * frames, call DescribeConnections. To check whether your virtual
 * interface supports jumbo frames, call DescribeVirtualInterfaces.
 */
export declare const createPrivateVirtualInterface: API.OperationMethod<CreatePrivateVirtualInterfaceRequest, VirtualInterface, CreatePrivateVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type CreatePublicVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | LimitExceededException | TooManyTagsException | CommonErrors;
/**
 * Creates a public virtual interface. A virtual interface is the VLAN that transports Direct Connect traffic.
 * A public virtual interface supports sending traffic to public services of Amazon Web Services such as Amazon S3.
 *
 * When creating an IPv6 public virtual interface (`addressFamily` is `ipv6`), leave the `customer`
 * and `amazon` address fields blank to use auto-assigned IPv6 space. Custom IPv6 addresses are not supported.
 */
export declare const createPublicVirtualInterface: API.OperationMethod<CreatePublicVirtualInterfaceRequest, VirtualInterface, CreatePublicVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type CreateTransitVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | LimitExceededException | TooManyTagsException | CommonErrors;
/**
 * Creates a transit virtual interface. A transit virtual interface should be used to access one or more transit gateways associated with Direct Connect gateways. A transit virtual interface enables the connection of multiple VPCs attached to a transit gateway to a Direct Connect gateway.
 *
 * If you associate your transit gateway with one or more Direct Connect gateways, the Autonomous System Number (ASN) used by the transit gateway and the Direct Connect gateway must be different. For example, if you use the default ASN 64512 for both your the transit gateway and Direct Connect gateway, the association request fails.
 *
 * A jumbo MTU value must be either 1500 or 8500. No other values will be accepted. Setting
 * the MTU of a virtual interface to 8500 (jumbo frames) can cause an update to the underlying
 * physical connection if it wasn't updated to support jumbo frames. Updating the connection
 * disrupts network connectivity for all virtual interfaces associated with the connection for up
 * to 30 seconds. To check whether your connection supports jumbo frames, call DescribeConnections. To check whether your virtual interface supports jumbo
 * frames, call DescribeVirtualInterfaces.
 */
export declare const createTransitVirtualInterface: API.OperationMethod<CreateTransitVirtualInterfaceRequest, CreateTransitVirtualInterfaceResult, CreateTransitVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type DeleteBGPPeerError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the specified BGP peer on the specified virtual interface with the specified customer address and ASN.
 *
 * You cannot delete the last BGP peer from a virtual interface.
 */
export declare const deleteBGPPeer: API.OperationMethod<DeleteBGPPeerRequest, DeleteBGPPeerResponse, DeleteBGPPeerError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the specified connection.
 *
 * Deleting a connection only stops the Direct Connect port hour and data transfer charges.
 * If you are partnering with any third parties to connect with the Direct Connect location,
 * you must cancel your service with them separately.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionRequest, Connection, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectConnectGatewayError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the specified Direct Connect gateway. You must first delete all virtual interfaces that are
 * attached to the Direct Connect gateway and disassociate all virtual private gateways associated
 * with the Direct Connect gateway.
 */
export declare const deleteDirectConnectGateway: API.OperationMethod<DeleteDirectConnectGatewayRequest, DeleteDirectConnectGatewayResult, DeleteDirectConnectGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectConnectGatewayAssociationError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the association between the specified Direct Connect gateway and virtual private gateway.
 *
 * We recommend that you specify the `associationID` to delete the association. Alternatively, if you own virtual gateway and a Direct Connect gateway association, you can specify the `virtualGatewayId` and `directConnectGatewayId` to delete an association.
 */
export declare const deleteDirectConnectGatewayAssociation: API.OperationMethod<DeleteDirectConnectGatewayAssociationRequest, DeleteDirectConnectGatewayAssociationResult, DeleteDirectConnectGatewayAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectConnectGatewayAssociationProposalError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the association proposal request between the specified Direct Connect gateway and virtual private gateway or transit gateway.
 */
export declare const deleteDirectConnectGatewayAssociationProposal: API.OperationMethod<DeleteDirectConnectGatewayAssociationProposalRequest, DeleteDirectConnectGatewayAssociationProposalResult, DeleteDirectConnectGatewayAssociationProposalError, Credentials | HttpClient.HttpClient>;
export type DeleteInterconnectError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the specified interconnect.
 *
 * Intended for use
 * by Direct Connect Partners only.
 */
export declare const deleteInterconnect: API.OperationMethod<DeleteInterconnectRequest, DeleteInterconnectResponse, DeleteInterconnectError, Credentials | HttpClient.HttpClient>;
export type DeleteLagError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the specified link aggregation group (LAG). You cannot delete a LAG if it has active
 * virtual interfaces or hosted connections.
 */
export declare const deleteLag: API.OperationMethod<DeleteLagRequest, Lag, DeleteLagError, Credentials | HttpClient.HttpClient>;
export type DeleteVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes a virtual interface.
 */
export declare const deleteVirtualInterface: API.OperationMethod<DeleteVirtualInterfaceRequest, DeleteVirtualInterfaceResponse, DeleteVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionLoaError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deprecated. Use DescribeLoa instead.
 *
 * Gets the LOA-CFA for a connection.
 *
 * The Letter of Authorization - Connecting Facility Assignment (LOA-CFA) is a document that your APN partner or
 * service provider uses when establishing your cross connect to Amazon Web Services at the colocation facility. For more information,
 * see Requesting Cross Connects
 * at Direct Connect Locations in the *Direct Connect User Guide*.
 */
export declare const describeConnectionLoa: API.OperationMethod<DescribeConnectionLoaRequest, DescribeConnectionLoaResponse, DescribeConnectionLoaError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Displays the specified connection or all connections in this Region.
 */
export declare const describeConnections: API.OperationMethod<DescribeConnectionsRequest, Connections, DescribeConnectionsError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionsOnInterconnectError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deprecated. Use DescribeHostedConnections instead.
 *
 * Lists the connections that have been provisioned on the specified interconnect.
 *
 * Intended for use by Direct Connect Partners only.
 */
export declare const describeConnectionsOnInterconnect: API.OperationMethod<DescribeConnectionsOnInterconnectRequest, Connections, DescribeConnectionsOnInterconnectError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomerMetadataError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Get and view a list of customer agreements, along with their signed status and whether the customer is an NNIPartner, NNIPartnerV2, or a nonPartner.
 */
export declare const describeCustomerMetadata: API.OperationMethod<DescribeCustomerMetadataRequest, DescribeCustomerMetadataResponse, DescribeCustomerMetadataError, Credentials | HttpClient.HttpClient>;
export type DescribeDirectConnectGatewayAssociationProposalsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Describes one or more association proposals for connection between a virtual private gateway or transit gateway and a Direct Connect gateway.
 */
export declare const describeDirectConnectGatewayAssociationProposals: API.OperationMethod<DescribeDirectConnectGatewayAssociationProposalsRequest, DescribeDirectConnectGatewayAssociationProposalsResult, DescribeDirectConnectGatewayAssociationProposalsError, Credentials | HttpClient.HttpClient>;
export type DescribeDirectConnectGatewayAssociationsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the associations between your Direct Connect gateways and virtual private gateways and transit gateways. You must specify one of the following:
 *
 * - A Direct Connect gateway
 *
 * The response contains all virtual private gateways and transit gateways associated with the Direct Connect gateway.
 *
 * - A virtual private gateway
 *
 * The response contains the Direct Connect gateway.
 *
 * - A transit gateway
 *
 * The response contains the Direct Connect gateway.
 *
 * - A Direct Connect gateway and a virtual private gateway
 *
 * The response contains the association between the Direct Connect gateway and virtual private gateway.
 *
 * - A Direct Connect gateway and a transit gateway
 *
 * The response contains the association between the Direct Connect gateway and transit gateway.
 *
 * - A Direct Connect gateway and a virtual private gateway
 *
 * The response contains the association between the Direct Connect gateway and virtual private gateway.
 *
 * - A Direct Connect gateway association to a Cloud WAN core network
 *
 * The response contains the Cloud WAN core network ID that the Direct Connect gateway is associated to.
 */
export declare const describeDirectConnectGatewayAssociations: API.OperationMethod<DescribeDirectConnectGatewayAssociationsRequest, DescribeDirectConnectGatewayAssociationsResult, DescribeDirectConnectGatewayAssociationsError, Credentials | HttpClient.HttpClient>;
export type DescribeDirectConnectGatewayAttachmentsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the attachments between your Direct Connect gateways and virtual interfaces. You must specify
 * a Direct Connect gateway, a virtual interface, or both. If you specify a Direct Connect gateway, the response contains
 * all virtual interfaces attached to the Direct Connect gateway. If you specify a virtual interface, the
 * response contains all Direct Connect gateways attached to the virtual interface. If you specify both,
 * the response contains the attachment between the Direct Connect gateway and the virtual interface.
 */
export declare const describeDirectConnectGatewayAttachments: API.OperationMethod<DescribeDirectConnectGatewayAttachmentsRequest, DescribeDirectConnectGatewayAttachmentsResult, DescribeDirectConnectGatewayAttachmentsError, Credentials | HttpClient.HttpClient>;
export type DescribeDirectConnectGatewaysError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists all your Direct Connect gateways or only the specified Direct Connect gateway. Deleted Direct Connect gateways are not returned.
 */
export declare const describeDirectConnectGateways: API.OperationMethod<DescribeDirectConnectGatewaysRequest, DescribeDirectConnectGatewaysResult, DescribeDirectConnectGatewaysError, Credentials | HttpClient.HttpClient>;
export type DescribeHostedConnectionsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the hosted connections that have been provisioned on the specified
 * interconnect or link aggregation group (LAG).
 *
 * Intended for use by Direct Connect Partners only.
 */
export declare const describeHostedConnections: API.OperationMethod<DescribeHostedConnectionsRequest, Connections, DescribeHostedConnectionsError, Credentials | HttpClient.HttpClient>;
export type DescribeInterconnectLoaError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deprecated. Use DescribeLoa instead.
 *
 * Gets the LOA-CFA for the specified interconnect.
 *
 * The Letter of Authorization - Connecting Facility Assignment (LOA-CFA) is a document that is used when establishing your cross connect to Amazon Web Services at the colocation facility.
 * For more information, see Requesting Cross Connects at Direct Connect Locations
 * in the *Direct Connect User Guide*.
 */
export declare const describeInterconnectLoa: API.OperationMethod<DescribeInterconnectLoaRequest, DescribeInterconnectLoaResponse, DescribeInterconnectLoaError, Credentials | HttpClient.HttpClient>;
export type DescribeInterconnectsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the interconnects owned by the Amazon Web Services account or only the specified interconnect.
 */
export declare const describeInterconnects: API.OperationMethod<DescribeInterconnectsRequest, Interconnects, DescribeInterconnectsError, Credentials | HttpClient.HttpClient>;
export type DescribeLagsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Describes all your link aggregation groups (LAG) or the specified LAG.
 */
export declare const describeLags: API.OperationMethod<DescribeLagsRequest, Lags, DescribeLagsError, Credentials | HttpClient.HttpClient>;
export type DescribeLoaError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Gets the LOA-CFA for a connection, interconnect, or link aggregation group (LAG).
 *
 * The Letter of Authorization - Connecting Facility Assignment (LOA-CFA) is a document that is used when establishing
 * your cross connect to Amazon Web Services at the colocation facility. For more information, see Requesting Cross Connects at Direct Connect Locations
 * in the *Direct Connect User Guide*.
 */
export declare const describeLoa: API.OperationMethod<DescribeLoaRequest, Loa, DescribeLoaError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the Direct Connect locations in the current Amazon Web Services Region. These are the locations that can be selected when calling
 * CreateConnection or CreateInterconnect.
 */
export declare const describeLocations: API.OperationMethod<DescribeLocationsRequest, Locations, DescribeLocationsError, Credentials | HttpClient.HttpClient>;
export type DescribeRouterConfigurationError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Details about the router.
 */
export declare const describeRouterConfiguration: API.OperationMethod<DescribeRouterConfigurationRequest, DescribeRouterConfigurationResponse, DescribeRouterConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeTagsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Describes the tags associated with the specified Direct Connect resources.
 */
export declare const describeTags: API.OperationMethod<DescribeTagsRequest, DescribeTagsResponse, DescribeTagsError, Credentials | HttpClient.HttpClient>;
export type DescribeVirtualGatewaysError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deprecated. Use `DescribeVpnGateways` instead. See DescribeVPNGateways in the *Amazon Elastic Compute Cloud API Reference*.
 *
 * Lists the virtual private gateways owned by the Amazon Web Services account.
 *
 * You can create one or more Direct Connect private virtual interfaces linked to a virtual private gateway.
 */
export declare const describeVirtualGateways: API.OperationMethod<DescribeVirtualGatewaysRequest, VirtualGateways, DescribeVirtualGatewaysError, Credentials | HttpClient.HttpClient>;
export type DescribeVirtualInterfacesError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Displays all virtual interfaces for an Amazon Web Services account. Virtual interfaces deleted fewer
 * than 15 minutes before you make the request are also returned. If you specify a
 * connection ID, only the virtual interfaces associated with the connection are returned.
 * If you specify a virtual interface ID, then only a single virtual interface is returned.
 *
 * A virtual interface (VLAN) transmits the traffic between the Direct Connect location and the customer network.
 *
 * - If you're using an `asn`, the response includes the ASN value in both the `asn` and `asnLong` fields.
 *
 * - If you're using `asnLong`, the response returns a value of `0` (zero) for the `asn` attribute because it exceeds the highest ASN value of 2,147,483,647 that it can support
 */
export declare const describeVirtualInterfaces: API.OperationMethod<DescribeVirtualInterfacesRequest, VirtualInterfaces, DescribeVirtualInterfacesError, Credentials | HttpClient.HttpClient>;
export type DisassociateConnectionFromLagError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Disassociates a connection from a link aggregation group (LAG). The connection is
 * interrupted and re-established as a standalone connection (the connection is not
 * deleted; to delete the connection, use the DeleteConnection request).
 * If the LAG has associated virtual interfaces or hosted connections, they remain
 * associated with the LAG. A disassociated connection owned by an Direct Connect Partner is
 * automatically converted to an interconnect.
 *
 * If disassociating the connection would cause the LAG to fall below its setting for
 * minimum number of operational connections, the request fails, except when it's the last
 * member of the LAG. If all connections are disassociated, the LAG continues to exist as
 * an empty LAG with no physical connections.
 */
export declare const disassociateConnectionFromLag: API.OperationMethod<DisassociateConnectionFromLagRequest, Connection, DisassociateConnectionFromLagError, Credentials | HttpClient.HttpClient>;
export type DisassociateMacSecKeyError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Removes the association between a MAC Security (MACsec) security key and a Direct Connect connection.
 */
export declare const disassociateMacSecKey: API.OperationMethod<DisassociateMacSecKeyRequest, DisassociateMacSecKeyResponse, DisassociateMacSecKeyError, Credentials | HttpClient.HttpClient>;
export type ListVirtualInterfaceRoutesError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the routes for the specified virtual interface.
 *
 * Use the `routeDirection` filter to control which routes are returned:
 *
 * - `accepted`: routes received from the customer network over the virtual interface.
 *
 * - `advertised`: routes advertised to the customer network over the virtual interface.
 */
export declare const listVirtualInterfaceRoutes: API.OperationMethod<ListVirtualInterfaceRoutesRequest, ListVirtualInterfaceRoutesResponse, ListVirtualInterfaceRoutesError, Credentials | HttpClient.HttpClient>;
export type ListVirtualInterfaceTestHistoryError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the virtual interface failover test history.
 */
export declare const listVirtualInterfaceTestHistory: API.OperationMethod<ListVirtualInterfaceTestHistoryRequest, ListVirtualInterfaceTestHistoryResponse, ListVirtualInterfaceTestHistoryError, Credentials | HttpClient.HttpClient>;
export type StartBgpFailoverTestError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Starts the virtual interface failover test that verifies your configuration meets your resiliency requirements by placing the BGP peering session in the DOWN state. You can then send traffic to verify that there are no outages.
 *
 * You can run the test on public, private, transit, and hosted virtual interfaces.
 *
 * You can use ListVirtualInterfaceTestHistory to view the virtual interface test history.
 *
 * If you need to stop the test before the test interval completes, use StopBgpFailoverTest.
 */
export declare const startBgpFailoverTest: API.OperationMethod<StartBgpFailoverTestRequest, StartBgpFailoverTestResponse, StartBgpFailoverTestError, Credentials | HttpClient.HttpClient>;
export type StopBgpFailoverTestError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Stops the virtual interface failover test.
 */
export declare const stopBgpFailoverTest: API.OperationMethod<StopBgpFailoverTestRequest, StopBgpFailoverTestResponse, StopBgpFailoverTestError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | TooManyTagsException | CommonErrors;
/**
 * Adds the specified tags to the specified Direct Connect resource. Each resource can have a maximum of 50 tags.
 *
 * Each tag consists of a key and an optional value. If a tag with the same key is already associated with the resource, this action updates its value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Removes one or more tags from the specified Direct Connect resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Updates the Direct Connect connection configuration.
 *
 * You can update the following parameters for a connection:
 *
 * - The connection name
 *
 * - The connection's MAC Security (MACsec) encryption mode.
 */
export declare const updateConnection: API.OperationMethod<UpdateConnectionRequest, Connection, UpdateConnectionError, Credentials | HttpClient.HttpClient>;
export type UpdateDirectConnectGatewayError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Updates the name of a current Direct Connect gateway.
 */
export declare const updateDirectConnectGateway: API.OperationMethod<UpdateDirectConnectGatewayRequest, UpdateDirectConnectGatewayResponse, UpdateDirectConnectGatewayError, Credentials | HttpClient.HttpClient>;
export type UpdateDirectConnectGatewayAssociationError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Updates the specified attributes of the Direct Connect gateway association.
 *
 * Add or remove prefixes from the association.
 */
export declare const updateDirectConnectGatewayAssociation: API.OperationMethod<UpdateDirectConnectGatewayAssociationRequest, UpdateDirectConnectGatewayAssociationResult, UpdateDirectConnectGatewayAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateLagError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Updates the attributes of the specified link aggregation group (LAG).
 *
 * You can update the following LAG attributes:
 *
 * - The name of the LAG.
 *
 * - The value for the minimum number of connections that must be operational
 * for the LAG itself to be operational.
 *
 * - The LAG's MACsec encryption mode.
 *
 * Amazon Web Services assigns this value to each connection which is part of the LAG.
 *
 * - The tags
 *
 * If you adjust the threshold value for the minimum number of operational connections, ensure
 * that the new value does not cause the LAG to fall below the threshold and become
 * non-operational.
 */
export declare const updateLag: API.OperationMethod<UpdateLagRequest, Lag, UpdateLagError, Credentials | HttpClient.HttpClient>;
export type UpdateVirtualInterfaceAttributesError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Updates the specified attributes of the specified virtual private interface.
 *
 * Setting the MTU of a virtual interface to 8500 (jumbo frames) can cause an update to
 * the underlying physical connection if it wasn't updated to support jumbo frames. Updating
 * the connection disrupts network connectivity for all virtual interfaces associated with
 * the connection for up to 30 seconds. To check whether your connection supports jumbo
 * frames, call DescribeConnections. To check whether your virtual
 * interface supports jumbo frames, call DescribeVirtualInterfaces.
 */
export declare const updateVirtualInterfaceAttributes: API.OperationMethod<UpdateVirtualInterfaceAttributesRequest, VirtualInterface, UpdateVirtualInterfaceAttributesError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=direct-connect.d.ts.map