import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
    readonly code: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly code: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly code: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly code: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UninitializedAccountException_base: S.Class<UninitializedAccountException, S.TaggedStruct<"UninitializedAccountException", {
    readonly message: any;
    readonly code: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UninitializedAccountException extends /*@__PURE__*/ UninitializedAccountException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly code: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SourceNetworkID = string;
export type CfnStackName = string | redacted.Redacted<string>;
export interface AssociateSourceNetworkStackRequest {
    sourceNetworkID: string;
    cfnStackName: string | redacted.Redacted<string>;
}
export declare const AssociateSourceNetworkStackRequest: S.Schema<AssociateSourceNetworkStackRequest>;
export type JobID = string;
export type ARN = string;
export type JobType = string;
export type InitiatedBy = string;
export type ISO8601DatetimeString = string;
export type JobStatus = string;
export type SourceServerID = string;
export type RecoveryInstanceID = string;
export type LaunchStatus = string;
export type LaunchActionId = string;
export type SsmDocumentName = string;
export type LaunchActionType = string;
export type LaunchActionName = string;
export type LaunchActionOrder = number;
export type LaunchActionVersion = string;
export type LaunchActionParameterName = string;
export type LaunchActionParameterValue = string;
export type LaunchActionParameterType = string;
export interface LaunchActionParameter {
    value?: string;
    type?: string;
}
export declare const LaunchActionParameter: S.Schema<LaunchActionParameter>;
export type LaunchActionParameters = {
    [key: string]: LaunchActionParameter | undefined;
};
export declare const LaunchActionParameters: any;
export type LaunchActionDescription = string;
export type LaunchActionCategory = string;
export interface LaunchAction {
    actionId?: string;
    actionCode?: string;
    type?: string;
    name?: string;
    active?: boolean;
    order?: number;
    actionVersion?: string;
    optional?: boolean;
    parameters?: {
        [key: string]: LaunchActionParameter | undefined;
    };
    description?: string;
    category?: string;
}
export declare const LaunchAction: S.Schema<LaunchAction>;
export type LaunchActionRunId = string;
export type LaunchActionRunStatus = string;
export type FailureReason = string;
export interface LaunchActionRun {
    action?: LaunchAction;
    runId?: string;
    status?: string;
    failureReason?: string;
}
export declare const LaunchActionRun: S.Schema<LaunchActionRun>;
export type LaunchActionRuns = LaunchActionRun[];
export declare const LaunchActionRuns: any;
export interface LaunchActionsStatus {
    ssmAgentDiscoveryDatetime?: string;
    runs?: LaunchActionRun[];
}
export declare const LaunchActionsStatus: S.Schema<LaunchActionsStatus>;
export interface ParticipatingServer {
    sourceServerID?: string;
    recoveryInstanceID?: string;
    launchStatus?: string;
    launchActionsStatus?: LaunchActionsStatus;
}
export declare const ParticipatingServer: S.Schema<ParticipatingServer>;
export type ParticipatingServers = ParticipatingServer[];
export declare const ParticipatingServers: any;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export type ParticipatingResourceID = {
    sourceNetworkID: string;
};
export declare const ParticipatingResourceID: any;
export interface ParticipatingResource {
    participatingResourceID?: ParticipatingResourceID;
    launchStatus?: string;
}
export declare const ParticipatingResource: S.Schema<ParticipatingResource>;
export type ParticipatingResources = ParticipatingResource[];
export declare const ParticipatingResources: any;
export interface Job {
    jobID: string;
    arn?: string;
    type?: string;
    initiatedBy?: string;
    creationDateTime?: string;
    endDateTime?: string;
    status?: string;
    participatingServers?: ParticipatingServer[];
    tags?: {
        [key: string]: string | undefined;
    };
    participatingResources?: ParticipatingResource[];
}
export declare const Job: S.Schema<Job>;
export interface AssociateSourceNetworkStackResponse {
    job?: Job;
}
export declare const AssociateSourceNetworkStackResponse: S.Schema<AssociateSourceNetworkStackResponse>;
export type StrictDRSARN = string;
export interface CancelRecoveryPlanExecutionRequest {
    recoveryPlanExecutionArn: string;
}
export declare const CancelRecoveryPlanExecutionRequest: S.Schema<CancelRecoveryPlanExecutionRequest>;
export type RecoveryPlanExecutionMode = string;
export type RecoveryPlanExecutionStatus = string;
export interface ErrorDetail {
    message: string;
    code: string;
}
export declare const ErrorDetail: S.Schema<ErrorDetail>;
export interface RecoveryPlanExecution {
    recoveryPlanExecutionArn: string;
    recoveryPlanArn: string;
    mode: string;
    status: string;
    startedAt: string;
    completedAt?: string;
    errorDetail?: ErrorDetail;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const RecoveryPlanExecution: S.Schema<RecoveryPlanExecution>;
export interface CancelRecoveryPlanExecutionResponse {
    recoveryPlanExecution: RecoveryPlanExecution;
}
export declare const CancelRecoveryPlanExecutionResponse: S.Schema<CancelRecoveryPlanExecutionResponse>;
export type SourceServerARN = string;
export interface CreateExtendedSourceServerRequest {
    sourceServerArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateExtendedSourceServerRequest: S.Schema<CreateExtendedSourceServerRequest>;
export type LastLaunchResult = string;
export type ISO8601DurationString = string;
export type BoundedString = string;
export type PositiveInteger = number;
export type VolumeStatus = string;
export interface DataReplicationInfoReplicatedDisk {
    deviceName?: string;
    totalStorageBytes?: number;
    replicatedStorageBytes?: number;
    rescannedStorageBytes?: number;
    backloggedStorageBytes?: number;
    volumeStatus?: string;
}
export declare const DataReplicationInfoReplicatedDisk: S.Schema<DataReplicationInfoReplicatedDisk>;
export type DataReplicationInfoReplicatedDisks = DataReplicationInfoReplicatedDisk[];
export declare const DataReplicationInfoReplicatedDisks: any;
export type DataReplicationState = string;
export type DataReplicationInitiationStepName = string;
export type DataReplicationInitiationStepStatus = string;
export interface DataReplicationInitiationStep {
    name?: string;
    status?: string;
}
export declare const DataReplicationInitiationStep: S.Schema<DataReplicationInitiationStep>;
export type DataReplicationInitiationSteps = DataReplicationInitiationStep[];
export declare const DataReplicationInitiationSteps: any;
export interface DataReplicationInitiation {
    startDateTime?: string;
    nextAttemptDateTime?: string;
    steps?: DataReplicationInitiationStep[];
}
export declare const DataReplicationInitiation: S.Schema<DataReplicationInitiation>;
export type DataReplicationErrorString = string;
export type LargeBoundedString = string;
export interface DataReplicationError {
    error?: string;
    rawError?: string;
}
export declare const DataReplicationError: S.Schema<DataReplicationError>;
export type AwsAvailabilityZone = string;
export type OutpostARN = string;
export interface DataReplicationInfo {
    lagDuration?: string;
    etaDateTime?: string;
    replicatedDisks?: DataReplicationInfoReplicatedDisk[];
    dataReplicationState?: string;
    dataReplicationInitiation?: DataReplicationInitiation;
    dataReplicationError?: DataReplicationError;
    stagingAvailabilityZone?: string;
    stagingOutpostArn?: string;
}
export declare const DataReplicationInfo: S.Schema<DataReplicationInfo>;
export type LastLaunchType = string;
export interface LifeCycleLastLaunchInitiated {
    apiCallDateTime?: string;
    jobID?: string;
    type?: string;
}
export declare const LifeCycleLastLaunchInitiated: S.Schema<LifeCycleLastLaunchInitiated>;
export interface LifeCycleLastLaunch {
    initiated?: LifeCycleLastLaunchInitiated;
    status?: string;
}
export declare const LifeCycleLastLaunch: S.Schema<LifeCycleLastLaunch>;
export interface LifeCycle {
    addedToServiceDateTime?: string;
    firstByteDateTime?: string;
    elapsedReplicationDuration?: string;
    lastSeenByServiceDateTime?: string;
    lastLaunch?: LifeCycleLastLaunch;
}
export declare const LifeCycle: S.Schema<LifeCycle>;
export type EC2InstanceType = string;
export type EC2InstanceID = string;
export interface IdentificationHints {
    fqdn?: string;
    hostname?: string;
    vmWareUuid?: string;
    awsInstanceID?: string;
}
export declare const IdentificationHints: S.Schema<IdentificationHints>;
export type IPsList = string[];
export declare const IPsList: any;
export interface NetworkInterface {
    macAddress?: string;
    ips?: string[];
    isPrimary?: boolean;
}
export declare const NetworkInterface: S.Schema<NetworkInterface>;
export type NetworkInterfaces = NetworkInterface[];
export declare const NetworkInterfaces: any;
export interface Disk {
    deviceName?: string;
    bytes?: number;
}
export declare const Disk: S.Schema<Disk>;
export type Disks = Disk[];
export declare const Disks: any;
export interface CPU {
    cores?: number;
    modelName?: string;
}
export declare const CPU: S.Schema<CPU>;
export type Cpus = CPU[];
export declare const Cpus: any;
export interface OS {
    fullString?: string;
}
export declare const OS: S.Schema<OS>;
export interface SourceProperties {
    lastUpdatedDateTime?: string;
    recommendedInstanceType?: string;
    identificationHints?: IdentificationHints;
    networkInterfaces?: NetworkInterface[];
    disks?: Disk[];
    cpus?: CPU[];
    ramBytes?: number;
    os?: OS;
    supportsNitroInstances?: boolean;
}
export declare const SourceProperties: S.Schema<SourceProperties>;
export type ExtensionStatus = string;
export type AccountID = string;
export interface StagingArea {
    status?: string;
    stagingAccountID?: string;
    stagingSourceServerArn?: string;
    errorMessage?: string;
}
export declare const StagingArea: S.Schema<StagingArea>;
export type AwsRegion = string;
export interface SourceCloudProperties {
    originAccountID?: string;
    originRegion?: string;
    originAvailabilityZone?: string;
    sourceOutpostArn?: string;
}
export declare const SourceCloudProperties: S.Schema<SourceCloudProperties>;
export type ReplicationDirection = string;
export type AgentVersion = string;
export interface SourceServer {
    sourceServerID?: string;
    arn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    recoveryInstanceId?: string;
    lastLaunchResult?: string;
    dataReplicationInfo?: DataReplicationInfo;
    lifeCycle?: LifeCycle;
    sourceProperties?: SourceProperties;
    stagingArea?: StagingArea;
    sourceCloudProperties?: SourceCloudProperties;
    replicationDirection?: string;
    reversedDirectionSourceServerArn?: string;
    sourceNetworkID?: string;
    agentVersion?: string;
}
export declare const SourceServer: S.Schema<SourceServer>;
export interface CreateExtendedSourceServerResponse {
    sourceServer?: SourceServer;
}
export declare const CreateExtendedSourceServerResponse: S.Schema<CreateExtendedSourceServerResponse>;
export type LaunchDisposition = string;
export type TargetInstanceTypeRightSizingMethod = string;
export interface Licensing {
    osByol?: boolean;
}
export declare const Licensing: S.Schema<Licensing>;
export type RecoveryMode = string;
export interface CreateLaunchConfigurationTemplateRequest {
    tags?: {
        [key: string]: string | undefined;
    };
    launchDisposition?: string;
    targetInstanceTypeRightSizingMethod?: string;
    copyPrivateIp?: boolean;
    copyTags?: boolean;
    licensing?: Licensing;
    exportBucketArn?: string;
    postLaunchEnabled?: boolean;
    launchIntoSourceInstance?: boolean;
    recoveryMode?: string;
}
export declare const CreateLaunchConfigurationTemplateRequest: S.Schema<CreateLaunchConfigurationTemplateRequest>;
export type LaunchConfigurationTemplateID = string;
export interface LaunchConfigurationTemplate {
    launchConfigurationTemplateID?: string;
    arn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    launchDisposition?: string;
    targetInstanceTypeRightSizingMethod?: string;
    copyPrivateIp?: boolean;
    copyTags?: boolean;
    licensing?: Licensing;
    exportBucketArn?: string;
    postLaunchEnabled?: boolean;
    launchIntoSourceInstance?: boolean;
    recoveryMode?: string;
}
export declare const LaunchConfigurationTemplate: S.Schema<LaunchConfigurationTemplate>;
export interface CreateLaunchConfigurationTemplateResponse {
    launchConfigurationTemplate?: LaunchConfigurationTemplate;
}
export declare const CreateLaunchConfigurationTemplateResponse: S.Schema<CreateLaunchConfigurationTemplateResponse>;
export type RecoveryPlanName = string;
export type RecoveryPlanDescription = string;
export type ClientIdempotencyToken = string;
export interface CreateRecoveryPlanRequest {
    name: string;
    description?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateRecoveryPlanRequest: S.Schema<CreateRecoveryPlanRequest>;
export type RecoveryPlanStatus = string;
export interface RecoveryPlan {
    recoveryPlanArn: string;
    name: string;
    description?: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const RecoveryPlan: S.Schema<RecoveryPlan>;
export interface CreateRecoveryPlanResponse {
    recoveryPlan: RecoveryPlan;
}
export declare const CreateRecoveryPlanResponse: S.Schema<CreateRecoveryPlanResponse>;
export type RecoveryPlanStepName = string;
export type RecoveryPlanStepOrder = number;
export type RecoveryPlanServerImpactLevel = string;
export interface RecoveryPlanServer {
    serverArn: string;
    impactLevel?: string;
}
export declare const RecoveryPlanServer: S.Schema<RecoveryPlanServer>;
export type RecoveryPlanServers = RecoveryPlanServer[];
export declare const RecoveryPlanServers: any;
export interface ServerStepConfiguration {
    servers: RecoveryPlanServer[];
}
export declare const ServerStepConfiguration: S.Schema<ServerStepConfiguration>;
export type WaitDurationMinutes = number;
export interface WaitStepConfiguration {
    waitDurationMinutes: number;
}
export declare const WaitStepConfiguration: S.Schema<WaitStepConfiguration>;
export type RecoveryPlanStepConfiguration = {
    serverStepConfiguration: ServerStepConfiguration;
    waitStepConfiguration?: never;
} | {
    serverStepConfiguration?: never;
    waitStepConfiguration: WaitStepConfiguration;
};
export declare const RecoveryPlanStepConfiguration: any;
export interface CreateRecoveryPlanStepRequest {
    recoveryPlanArn: string;
    stepName: string;
    stepOrder?: number;
    configuration: RecoveryPlanStepConfiguration;
    clientToken?: string;
}
export declare const CreateRecoveryPlanStepRequest: S.Schema<CreateRecoveryPlanStepRequest>;
export interface RecoveryPlanStep {
    recoveryPlanStepArn: string;
    stepOrder: number;
    stepName: string;
    configuration: RecoveryPlanStepConfiguration;
    createdAt: string;
    updatedAt: string;
}
export declare const RecoveryPlanStep: S.Schema<RecoveryPlanStep>;
export interface CreateRecoveryPlanStepResponse {
    recoveryPlanStep: RecoveryPlanStep;
}
export declare const CreateRecoveryPlanStepResponse: S.Schema<CreateRecoveryPlanStepResponse>;
export type SubnetID = string;
export type SecurityGroupID = string;
export type ReplicationServersSecurityGroupsIDs = string[];
export declare const ReplicationServersSecurityGroupsIDs: any;
export type ReplicationConfigurationDefaultLargeStagingDiskType = string;
export type ReplicationConfigurationEbsEncryption = string;
export type ReplicationConfigurationDataPlaneRouting = string;
export type PITPolicyRuleUnits = string;
export type StrictlyPositiveInteger = number;
export interface PITPolicyRule {
    ruleID?: number;
    units: string;
    interval: number;
    retentionDuration: number;
    enabled?: boolean;
}
export declare const PITPolicyRule: S.Schema<PITPolicyRule>;
export type PITPolicy = PITPolicyRule[];
export declare const PITPolicy: any;
export type InternetProtocol = string;
export interface CreateReplicationConfigurationTemplateRequest {
    stagingAreaSubnetId: string;
    associateDefaultSecurityGroup?: boolean;
    replicationServersSecurityGroupsIDs: string[];
    replicationServerInstanceType?: string;
    useDedicatedReplicationServer?: boolean;
    defaultLargeStagingDiskType?: string;
    ebsEncryption: string;
    ebsEncryptionKeyArn?: string;
    bandwidthThrottling: number;
    dataPlaneRouting?: string;
    createPublicIP?: boolean;
    stagingAreaTags: {
        [key: string]: string | undefined;
    };
    pitPolicy: PITPolicyRule[];
    tags?: {
        [key: string]: string | undefined;
    };
    autoReplicateNewDisks?: boolean;
    internetProtocol?: string;
}
export declare const CreateReplicationConfigurationTemplateRequest: S.Schema<CreateReplicationConfigurationTemplateRequest>;
export type ReplicationConfigurationTemplateID = string;
export interface ReplicationConfigurationTemplate {
    replicationConfigurationTemplateID: string;
    arn?: string;
    stagingAreaSubnetId?: string;
    associateDefaultSecurityGroup?: boolean;
    replicationServersSecurityGroupsIDs?: string[];
    replicationServerInstanceType?: string;
    useDedicatedReplicationServer?: boolean;
    defaultLargeStagingDiskType?: string;
    ebsEncryption?: string;
    ebsEncryptionKeyArn?: string;
    bandwidthThrottling?: number;
    dataPlaneRouting?: string;
    createPublicIP?: boolean;
    stagingAreaTags?: {
        [key: string]: string | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
    pitPolicy?: PITPolicyRule[];
    autoReplicateNewDisks?: boolean;
    internetProtocol?: string;
}
export declare const ReplicationConfigurationTemplate: S.Schema<ReplicationConfigurationTemplate>;
export type VpcID = string;
export interface CreateSourceNetworkRequest {
    vpcID: string;
    originAccountID: string;
    originRegion: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateSourceNetworkRequest: S.Schema<CreateSourceNetworkRequest>;
export interface CreateSourceNetworkResponse {
    sourceNetworkID?: string;
}
export declare const CreateSourceNetworkResponse: S.Schema<CreateSourceNetworkResponse>;
export interface DeleteJobRequest {
    jobID: string;
}
export declare const DeleteJobRequest: S.Schema<DeleteJobRequest>;
export interface DeleteJobResponse {
}
export declare const DeleteJobResponse: S.Schema<DeleteJobResponse>;
export type LaunchActionResourceId = string;
export interface DeleteLaunchActionRequest {
    resourceId: string;
    actionId: string;
}
export declare const DeleteLaunchActionRequest: S.Schema<DeleteLaunchActionRequest>;
export interface DeleteLaunchActionResponse {
}
export declare const DeleteLaunchActionResponse: S.Schema<DeleteLaunchActionResponse>;
export interface DeleteLaunchConfigurationTemplateRequest {
    launchConfigurationTemplateID: string;
}
export declare const DeleteLaunchConfigurationTemplateRequest: S.Schema<DeleteLaunchConfigurationTemplateRequest>;
export interface DeleteLaunchConfigurationTemplateResponse {
}
export declare const DeleteLaunchConfigurationTemplateResponse: S.Schema<DeleteLaunchConfigurationTemplateResponse>;
export interface DeleteRecoveryInstanceRequest {
    recoveryInstanceID: string;
}
export declare const DeleteRecoveryInstanceRequest: S.Schema<DeleteRecoveryInstanceRequest>;
export interface DeleteRecoveryInstanceResponse {
}
export declare const DeleteRecoveryInstanceResponse: S.Schema<DeleteRecoveryInstanceResponse>;
export interface DeleteRecoveryPlanRequest {
    recoveryPlanArn: string;
}
export declare const DeleteRecoveryPlanRequest: S.Schema<DeleteRecoveryPlanRequest>;
export interface DeleteRecoveryPlanResponse {
    recoveryPlanArn: string;
}
export declare const DeleteRecoveryPlanResponse: S.Schema<DeleteRecoveryPlanResponse>;
export interface DeleteRecoveryPlanExecutionRequest {
    recoveryPlanExecutionArn: string;
}
export declare const DeleteRecoveryPlanExecutionRequest: S.Schema<DeleteRecoveryPlanExecutionRequest>;
export interface DeleteRecoveryPlanExecutionResponse {
    recoveryPlanExecutionArn: string;
}
export declare const DeleteRecoveryPlanExecutionResponse: S.Schema<DeleteRecoveryPlanExecutionResponse>;
export interface DeleteRecoveryPlanStepRequest {
    recoveryPlanStepArn: string;
}
export declare const DeleteRecoveryPlanStepRequest: S.Schema<DeleteRecoveryPlanStepRequest>;
export interface DeleteRecoveryPlanStepResponse {
    recoveryPlanStepArn: string;
}
export declare const DeleteRecoveryPlanStepResponse: S.Schema<DeleteRecoveryPlanStepResponse>;
export interface DeleteReplicationConfigurationTemplateRequest {
    replicationConfigurationTemplateID: string;
}
export declare const DeleteReplicationConfigurationTemplateRequest: S.Schema<DeleteReplicationConfigurationTemplateRequest>;
export interface DeleteReplicationConfigurationTemplateResponse {
}
export declare const DeleteReplicationConfigurationTemplateResponse: S.Schema<DeleteReplicationConfigurationTemplateResponse>;
export interface DeleteSourceNetworkRequest {
    sourceNetworkID: string;
}
export declare const DeleteSourceNetworkRequest: S.Schema<DeleteSourceNetworkRequest>;
export interface DeleteSourceNetworkResponse {
}
export declare const DeleteSourceNetworkResponse: S.Schema<DeleteSourceNetworkResponse>;
export interface DeleteSourceServerRequest {
    sourceServerID: string;
}
export declare const DeleteSourceServerRequest: S.Schema<DeleteSourceServerRequest>;
export interface DeleteSourceServerResponse {
}
export declare const DeleteSourceServerResponse: S.Schema<DeleteSourceServerResponse>;
export type PaginationToken = string;
export interface DescribeJobLogItemsRequest {
    jobID: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeJobLogItemsRequest: S.Schema<DescribeJobLogItemsRequest>;
export type JobLogEvent = string;
export type EbsSnapshot = string;
export type ConversionMap = {
    [key: string]: string | undefined;
};
export declare const ConversionMap: any;
export type VolumeToConversionMap = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export declare const VolumeToConversionMap: any;
export type VolumeToSizeMap = {
    [key: string]: number | undefined;
};
export declare const VolumeToSizeMap: any;
export type ProductCodeId = string;
export type ProductCodeMode = string;
export interface ProductCode {
    productCodeId?: string;
    productCodeMode?: string;
}
export declare const ProductCode: S.Schema<ProductCode>;
export type ProductCodes = ProductCode[];
export declare const ProductCodes: any;
export type VolumeToProductCodes = {
    [key: string]: ProductCode[] | undefined;
};
export declare const VolumeToProductCodes: any;
export interface ConversionProperties {
    volumeToConversionMap?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    rootVolumeName?: string;
    forceUefi?: boolean;
    dataTimestamp?: string;
    volumeToVolumeSize?: {
        [key: string]: number | undefined;
    };
    volumeToProductCodes?: {
        [key: string]: ProductCode[] | undefined;
    };
}
export declare const ConversionProperties: S.Schema<ConversionProperties>;
export interface SourceNetworkData {
    sourceNetworkID?: string;
    sourceVpc?: string;
    targetVpc?: string;
    stackName?: string;
}
export declare const SourceNetworkData: S.Schema<SourceNetworkData>;
export type EventResourceData = {
    sourceNetworkData: SourceNetworkData;
};
export declare const EventResourceData: any;
export type JobEventAttemptCount = number;
export interface JobLogEventData {
    sourceServerID?: string;
    conversionServerID?: string;
    targetInstanceID?: string;
    rawError?: string;
    conversionProperties?: ConversionProperties;
    eventResourceData?: EventResourceData;
    attemptCount?: number;
    maxAttemptsCount?: number;
}
export declare const JobLogEventData: S.Schema<JobLogEventData>;
export interface JobLog {
    logDateTime?: string;
    event?: string;
    eventData?: JobLogEventData;
}
export declare const JobLog: S.Schema<JobLog>;
export type JobLogs = JobLog[];
export declare const JobLogs: any;
export interface DescribeJobLogItemsResponse {
    items?: JobLog[];
    nextToken?: string;
}
export declare const DescribeJobLogItemsResponse: S.Schema<DescribeJobLogItemsResponse>;
export type DescribeJobsRequestFiltersJobIDs = string[];
export declare const DescribeJobsRequestFiltersJobIDs: any;
export interface DescribeJobsRequestFilters {
    jobIDs?: string[];
    fromDate?: string;
    toDate?: string;
}
export declare const DescribeJobsRequestFilters: S.Schema<DescribeJobsRequestFilters>;
export interface DescribeJobsRequest {
    filters?: DescribeJobsRequestFilters;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeJobsRequest: S.Schema<DescribeJobsRequest>;
export type JobsList = Job[];
export declare const JobsList: any;
export interface DescribeJobsResponse {
    items?: Job[];
    nextToken?: string;
}
export declare const DescribeJobsResponse: S.Schema<DescribeJobsResponse>;
export type LaunchConfigurationTemplateIDs = string[];
export declare const LaunchConfigurationTemplateIDs: any;
export type MaxResultsType = number;
export interface DescribeLaunchConfigurationTemplatesRequest {
    launchConfigurationTemplateIDs?: string[];
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeLaunchConfigurationTemplatesRequest: S.Schema<DescribeLaunchConfigurationTemplatesRequest>;
export type LaunchConfigurationTemplates = LaunchConfigurationTemplate[];
export declare const LaunchConfigurationTemplates: any;
export interface DescribeLaunchConfigurationTemplatesResponse {
    items?: LaunchConfigurationTemplate[];
    nextToken?: string;
}
export declare const DescribeLaunchConfigurationTemplatesResponse: S.Schema<DescribeLaunchConfigurationTemplatesResponse>;
export type RecoveryInstanceIDs = string[];
export declare const RecoveryInstanceIDs: any;
export type SourceServerIDs = string[];
export declare const SourceServerIDs: any;
export interface DescribeRecoveryInstancesRequestFilters {
    recoveryInstanceIDs?: string[];
    sourceServerIDs?: string[];
}
export declare const DescribeRecoveryInstancesRequestFilters: S.Schema<DescribeRecoveryInstancesRequestFilters>;
export interface DescribeRecoveryInstancesRequest {
    filters?: DescribeRecoveryInstancesRequestFilters;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeRecoveryInstancesRequest: S.Schema<DescribeRecoveryInstancesRequest>;
export type EC2InstanceState = string;
export type FailbackState = string;
export type FailbackLaunchType = string;
export interface RecoveryInstanceFailback {
    failbackClientID?: string;
    failbackJobID?: string;
    failbackInitiationTime?: string;
    state?: string;
    agentLastSeenByServiceDateTime?: string;
    failbackClientLastSeenByServiceDateTime?: string;
    failbackToOriginalServer?: boolean;
    firstByteDateTime?: string;
    elapsedReplicationDuration?: string;
    failbackLaunchType?: string;
}
export declare const RecoveryInstanceFailback: S.Schema<RecoveryInstanceFailback>;
export interface RecoveryInstanceDataReplicationInfoReplicatedDisk {
    deviceName?: string;
    totalStorageBytes?: number;
    replicatedStorageBytes?: number;
    rescannedStorageBytes?: number;
    backloggedStorageBytes?: number;
}
export declare const RecoveryInstanceDataReplicationInfoReplicatedDisk: S.Schema<RecoveryInstanceDataReplicationInfoReplicatedDisk>;
export type RecoveryInstanceDataReplicationInfoReplicatedDisks = RecoveryInstanceDataReplicationInfoReplicatedDisk[];
export declare const RecoveryInstanceDataReplicationInfoReplicatedDisks: any;
export type RecoveryInstanceDataReplicationState = string;
export type RecoveryInstanceDataReplicationInitiationStepName = string;
export type RecoveryInstanceDataReplicationInitiationStepStatus = string;
export interface RecoveryInstanceDataReplicationInitiationStep {
    name?: string;
    status?: string;
}
export declare const RecoveryInstanceDataReplicationInitiationStep: S.Schema<RecoveryInstanceDataReplicationInitiationStep>;
export type RecoveryInstanceDataReplicationInitiationSteps = RecoveryInstanceDataReplicationInitiationStep[];
export declare const RecoveryInstanceDataReplicationInitiationSteps: any;
export interface RecoveryInstanceDataReplicationInitiation {
    startDateTime?: string;
    steps?: RecoveryInstanceDataReplicationInitiationStep[];
}
export declare const RecoveryInstanceDataReplicationInitiation: S.Schema<RecoveryInstanceDataReplicationInitiation>;
export type FailbackReplicationError = string;
export interface RecoveryInstanceDataReplicationError {
    error?: string;
    rawError?: string;
}
export declare const RecoveryInstanceDataReplicationError: S.Schema<RecoveryInstanceDataReplicationError>;
export interface RecoveryInstanceDataReplicationInfo {
    lagDuration?: string;
    etaDateTime?: string;
    replicatedDisks?: RecoveryInstanceDataReplicationInfoReplicatedDisk[];
    dataReplicationState?: string;
    dataReplicationInitiation?: RecoveryInstanceDataReplicationInitiation;
    dataReplicationError?: RecoveryInstanceDataReplicationError;
    stagingAvailabilityZone?: string;
    stagingOutpostArn?: string;
}
export declare const RecoveryInstanceDataReplicationInfo: S.Schema<RecoveryInstanceDataReplicationInfo>;
export type EbsVolumeID = string;
export interface RecoveryInstanceDisk {
    internalDeviceName?: string;
    bytes?: number;
    ebsVolumeID?: string;
}
export declare const RecoveryInstanceDisk: S.Schema<RecoveryInstanceDisk>;
export type RecoveryInstanceDisks = RecoveryInstanceDisk[];
export declare const RecoveryInstanceDisks: any;
export interface RecoveryInstanceProperties {
    lastUpdatedDateTime?: string;
    identificationHints?: IdentificationHints;
    networkInterfaces?: NetworkInterface[];
    disks?: RecoveryInstanceDisk[];
    cpus?: CPU[];
    ramBytes?: number;
    os?: OS;
}
export declare const RecoveryInstanceProperties: S.Schema<RecoveryInstanceProperties>;
export type OriginEnvironment = string;
export interface RecoveryInstance {
    ec2InstanceID?: string;
    ec2InstanceState?: string;
    jobID?: string;
    recoveryInstanceID?: string;
    sourceServerID?: string;
    arn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    failback?: RecoveryInstanceFailback;
    dataReplicationInfo?: RecoveryInstanceDataReplicationInfo;
    recoveryInstanceProperties?: RecoveryInstanceProperties;
    pointInTimeSnapshotDateTime?: string;
    isDrill?: boolean;
    originEnvironment?: string;
    originAvailabilityZone?: string;
    agentVersion?: string;
    sourceOutpostArn?: string;
}
export declare const RecoveryInstance: S.Schema<RecoveryInstance>;
export type DescribeRecoveryInstancesItems = RecoveryInstance[];
export declare const DescribeRecoveryInstancesItems: any;
export interface DescribeRecoveryInstancesResponse {
    nextToken?: string;
    items?: RecoveryInstance[];
}
export declare const DescribeRecoveryInstancesResponse: S.Schema<DescribeRecoveryInstancesResponse>;
export interface DescribeRecoverySnapshotsRequestFilters {
    fromDateTime?: string;
    toDateTime?: string;
}
export declare const DescribeRecoverySnapshotsRequestFilters: S.Schema<DescribeRecoverySnapshotsRequestFilters>;
export type RecoverySnapshotsOrder = string;
export interface DescribeRecoverySnapshotsRequest {
    sourceServerID: string;
    filters?: DescribeRecoverySnapshotsRequestFilters;
    order?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeRecoverySnapshotsRequest: S.Schema<DescribeRecoverySnapshotsRequest>;
export type RecoverySnapshotID = string;
export type EbsSnapshotsList = string[];
export declare const EbsSnapshotsList: any;
export interface RecoverySnapshot {
    snapshotID: string;
    sourceServerID: string;
    expectedTimestamp: string;
    timestamp?: string;
    ebsSnapshots?: string[];
}
export declare const RecoverySnapshot: S.Schema<RecoverySnapshot>;
export type RecoverySnapshotsList = RecoverySnapshot[];
export declare const RecoverySnapshotsList: any;
export interface DescribeRecoverySnapshotsResponse {
    items?: RecoverySnapshot[];
    nextToken?: string;
}
export declare const DescribeRecoverySnapshotsResponse: S.Schema<DescribeRecoverySnapshotsResponse>;
export type ReplicationConfigurationTemplateIDs = string[];
export declare const ReplicationConfigurationTemplateIDs: any;
export interface DescribeReplicationConfigurationTemplatesRequest {
    replicationConfigurationTemplateIDs?: string[];
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeReplicationConfigurationTemplatesRequest: S.Schema<DescribeReplicationConfigurationTemplatesRequest>;
export type ReplicationConfigurationTemplates = ReplicationConfigurationTemplate[];
export declare const ReplicationConfigurationTemplates: any;
export interface DescribeReplicationConfigurationTemplatesResponse {
    items?: ReplicationConfigurationTemplate[];
    nextToken?: string;
}
export declare const DescribeReplicationConfigurationTemplatesResponse: S.Schema<DescribeReplicationConfigurationTemplatesResponse>;
export type DescribeSourceNetworksRequestFiltersIDs = string[];
export declare const DescribeSourceNetworksRequestFiltersIDs: any;
export interface DescribeSourceNetworksRequestFilters {
    sourceNetworkIDs?: string[];
    originAccountID?: string;
    originRegion?: string;
}
export declare const DescribeSourceNetworksRequestFilters: S.Schema<DescribeSourceNetworksRequestFilters>;
export interface DescribeSourceNetworksRequest {
    filters?: DescribeSourceNetworksRequestFilters;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeSourceNetworksRequest: S.Schema<DescribeSourceNetworksRequest>;
export type ReplicationStatus = string;
export type SensitiveBoundedString = string | redacted.Redacted<string>;
export type RecoveryResult = string;
export interface RecoveryLifeCycle {
    apiCallDateTime?: Date;
    jobID?: string;
    lastRecoveryResult?: string;
}
export declare const RecoveryLifeCycle: S.Schema<RecoveryLifeCycle>;
export interface SourceNetwork {
    sourceNetworkID?: string;
    sourceVpcID?: string;
    arn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    replicationStatus?: string;
    replicationStatusDetails?: string | redacted.Redacted<string>;
    cfnStackName?: string | redacted.Redacted<string>;
    sourceRegion?: string;
    sourceAccountID?: string;
    lastRecovery?: RecoveryLifeCycle;
    launchedVpcID?: string;
}
export declare const SourceNetwork: S.Schema<SourceNetwork>;
export type SourceNetworksList = SourceNetwork[];
export declare const SourceNetworksList: any;
export interface DescribeSourceNetworksResponse {
    items?: SourceNetwork[];
    nextToken?: string;
}
export declare const DescribeSourceNetworksResponse: S.Schema<DescribeSourceNetworksResponse>;
export type DescribeSourceServersRequestFiltersIDs = string[];
export declare const DescribeSourceServersRequestFiltersIDs: any;
export type AccountIDs = string[];
export declare const AccountIDs: any;
export interface DescribeSourceServersRequestFilters {
    sourceServerIDs?: string[];
    hardwareId?: string;
    stagingAccountIDs?: string[];
}
export declare const DescribeSourceServersRequestFilters: S.Schema<DescribeSourceServersRequestFilters>;
export interface DescribeSourceServersRequest {
    filters?: DescribeSourceServersRequestFilters;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeSourceServersRequest: S.Schema<DescribeSourceServersRequest>;
export type SourceServersList = SourceServer[];
export declare const SourceServersList: any;
export interface DescribeSourceServersResponse {
    items?: SourceServer[];
    nextToken?: string;
}
export declare const DescribeSourceServersResponse: S.Schema<DescribeSourceServersResponse>;
export interface DisconnectRecoveryInstanceRequest {
    recoveryInstanceID: string;
}
export declare const DisconnectRecoveryInstanceRequest: S.Schema<DisconnectRecoveryInstanceRequest>;
export interface DisconnectRecoveryInstanceResponse {
}
export declare const DisconnectRecoveryInstanceResponse: S.Schema<DisconnectRecoveryInstanceResponse>;
export interface DisconnectSourceServerRequest {
    sourceServerID: string;
}
export declare const DisconnectSourceServerRequest: S.Schema<DisconnectSourceServerRequest>;
export interface ExportSourceNetworkCfnTemplateRequest {
    sourceNetworkID: string;
}
export declare const ExportSourceNetworkCfnTemplateRequest: S.Schema<ExportSourceNetworkCfnTemplateRequest>;
export interface ExportSourceNetworkCfnTemplateResponse {
    s3DestinationUrl?: string;
}
export declare const ExportSourceNetworkCfnTemplateResponse: S.Schema<ExportSourceNetworkCfnTemplateResponse>;
export interface GetFailbackReplicationConfigurationRequest {
    recoveryInstanceID: string;
}
export declare const GetFailbackReplicationConfigurationRequest: S.Schema<GetFailbackReplicationConfigurationRequest>;
export interface GetFailbackReplicationConfigurationResponse {
    recoveryInstanceID: string;
    name?: string;
    bandwidthThrottling?: number;
    usePrivateIP?: boolean;
    internetProtocol?: string;
}
export declare const GetFailbackReplicationConfigurationResponse: S.Schema<GetFailbackReplicationConfigurationResponse>;
export interface GetLaunchConfigurationRequest {
    sourceServerID: string;
}
export declare const GetLaunchConfigurationRequest: S.Schema<GetLaunchConfigurationRequest>;
export type SmallBoundedString = string;
export interface LaunchIntoInstanceProperties {
    launchIntoEC2InstanceID?: string;
}
export declare const LaunchIntoInstanceProperties: S.Schema<LaunchIntoInstanceProperties>;
export interface LaunchConfiguration {
    sourceServerID?: string;
    name?: string;
    ec2LaunchTemplateID?: string;
    launchDisposition?: string;
    targetInstanceTypeRightSizingMethod?: string;
    copyPrivateIp?: boolean;
    copyTags?: boolean;
    licensing?: Licensing;
    postLaunchEnabled?: boolean;
    launchIntoInstanceProperties?: LaunchIntoInstanceProperties;
    recoveryMode?: string;
}
export declare const LaunchConfiguration: S.Schema<LaunchConfiguration>;
export interface GetRecoveryPlanRequest {
    recoveryPlanArn: string;
}
export declare const GetRecoveryPlanRequest: S.Schema<GetRecoveryPlanRequest>;
export interface GetRecoveryPlanResponse {
    recoveryPlan: RecoveryPlan;
}
export declare const GetRecoveryPlanResponse: S.Schema<GetRecoveryPlanResponse>;
export interface GetRecoveryPlanExecutionRequest {
    recoveryPlanExecutionArn: string;
}
export declare const GetRecoveryPlanExecutionRequest: S.Schema<GetRecoveryPlanExecutionRequest>;
export interface GetRecoveryPlanExecutionResponse {
    recoveryPlanExecution: RecoveryPlanExecution;
}
export declare const GetRecoveryPlanExecutionResponse: S.Schema<GetRecoveryPlanExecutionResponse>;
export interface GetRecoveryPlanExecutionStepRequest {
    recoveryPlanExecutionStepArn: string;
}
export declare const GetRecoveryPlanExecutionStepRequest: S.Schema<GetRecoveryPlanExecutionStepRequest>;
export type RecoveryPlanExecutionStepStatus = string;
export interface RecoveryPlanExecutionServer {
    serverArn: string;
    impactLevel?: string;
    jobID?: string;
}
export declare const RecoveryPlanExecutionServer: S.Schema<RecoveryPlanExecutionServer>;
export type RecoveryPlanExecutionServers = RecoveryPlanExecutionServer[];
export declare const RecoveryPlanExecutionServers: any;
export interface ExecutionServerStepConfiguration {
    servers: RecoveryPlanExecutionServer[];
}
export declare const ExecutionServerStepConfiguration: S.Schema<ExecutionServerStepConfiguration>;
export type RecoveryPlanExecutionStepConfiguration = {
    executionServerStepConfiguration: ExecutionServerStepConfiguration;
    waitStepConfiguration?: never;
} | {
    executionServerStepConfiguration?: never;
    waitStepConfiguration: WaitStepConfiguration;
};
export declare const RecoveryPlanExecutionStepConfiguration: any;
export interface RecoveryPlanExecutionStep {
    recoveryPlanExecutionStepArn: string;
    stepIndex: number;
    status: string;
    stepName: string;
    configuration: RecoveryPlanExecutionStepConfiguration;
    errorDetail?: ErrorDetail;
    attempt: number;
    createdAt: string;
    updatedAt: string;
}
export declare const RecoveryPlanExecutionStep: S.Schema<RecoveryPlanExecutionStep>;
export interface GetRecoveryPlanExecutionStepResponse {
    recoveryPlanExecutionStep: RecoveryPlanExecutionStep;
}
export declare const GetRecoveryPlanExecutionStepResponse: S.Schema<GetRecoveryPlanExecutionStepResponse>;
export interface GetRecoveryPlanStepRequest {
    recoveryPlanStepArn: string;
}
export declare const GetRecoveryPlanStepRequest: S.Schema<GetRecoveryPlanStepRequest>;
export interface GetRecoveryPlanStepResponse {
    recoveryPlanStep: RecoveryPlanStep;
}
export declare const GetRecoveryPlanStepResponse: S.Schema<GetRecoveryPlanStepResponse>;
export interface GetReplicationConfigurationRequest {
    sourceServerID: string;
}
export declare const GetReplicationConfigurationRequest: S.Schema<GetReplicationConfigurationRequest>;
export type ReplicationConfigurationReplicatedDiskStagingDiskType = string;
export interface ReplicationConfigurationReplicatedDisk {
    deviceName?: string;
    isBootDisk?: boolean;
    stagingDiskType?: string;
    iops?: number;
    throughput?: number;
    optimizedStagingDiskType?: string;
}
export declare const ReplicationConfigurationReplicatedDisk: S.Schema<ReplicationConfigurationReplicatedDisk>;
export type ReplicationConfigurationReplicatedDisks = ReplicationConfigurationReplicatedDisk[];
export declare const ReplicationConfigurationReplicatedDisks: any;
export interface ReplicationConfiguration {
    sourceServerID?: string;
    name?: string;
    stagingAreaSubnetId?: string;
    associateDefaultSecurityGroup?: boolean;
    replicationServersSecurityGroupsIDs?: string[];
    replicationServerInstanceType?: string;
    useDedicatedReplicationServer?: boolean;
    defaultLargeStagingDiskType?: string;
    replicatedDisks?: ReplicationConfigurationReplicatedDisk[];
    ebsEncryption?: string;
    ebsEncryptionKeyArn?: string;
    bandwidthThrottling?: number;
    dataPlaneRouting?: string;
    createPublicIP?: boolean;
    stagingAreaTags?: {
        [key: string]: string | undefined;
    };
    pitPolicy?: PITPolicyRule[];
    autoReplicateNewDisks?: boolean;
    internetProtocol?: string;
}
export declare const ReplicationConfiguration: S.Schema<ReplicationConfiguration>;
export interface InitializeServiceRequest {
}
export declare const InitializeServiceRequest: S.Schema<InitializeServiceRequest>;
export interface InitializeServiceResponse {
}
export declare const InitializeServiceResponse: S.Schema<InitializeServiceResponse>;
export type MaxResultsReplicatingSourceServers = number;
export interface ListExtensibleSourceServersRequest {
    stagingAccountID: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListExtensibleSourceServersRequest: S.Schema<ListExtensibleSourceServersRequest>;
export interface StagingSourceServer {
    hostname?: string;
    arn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StagingSourceServer: S.Schema<StagingSourceServer>;
export type StagingSourceServersList = StagingSourceServer[];
export declare const StagingSourceServersList: any;
export interface ListExtensibleSourceServersResponse {
    items?: StagingSourceServer[];
    nextToken?: string;
}
export declare const ListExtensibleSourceServersResponse: S.Schema<ListExtensibleSourceServersResponse>;
export type LaunchActionIds = string[];
export declare const LaunchActionIds: any;
export interface LaunchActionsRequestFilters {
    actionIds?: string[];
}
export declare const LaunchActionsRequestFilters: S.Schema<LaunchActionsRequestFilters>;
export interface ListLaunchActionsRequest {
    resourceId: string;
    filters?: LaunchActionsRequestFilters;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListLaunchActionsRequest: S.Schema<ListLaunchActionsRequest>;
export type LaunchActions = LaunchAction[];
export declare const LaunchActions: any;
export interface ListLaunchActionsResponse {
    items?: LaunchAction[];
    nextToken?: string;
}
export declare const ListLaunchActionsResponse: S.Schema<ListLaunchActionsResponse>;
export interface ListRecoveryPlanExecutionsRequest {
    recoveryPlanArn?: string;
    status?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRecoveryPlanExecutionsRequest: S.Schema<ListRecoveryPlanExecutionsRequest>;
export interface RecoveryPlanExecutionSummary {
    recoveryPlanExecutionArn: string;
    recoveryPlanArn: string;
    mode: string;
    status: string;
    startedAt: string;
    errorDetail?: ErrorDetail;
}
export declare const RecoveryPlanExecutionSummary: S.Schema<RecoveryPlanExecutionSummary>;
export type RecoveryPlanExecutionSummaryList = RecoveryPlanExecutionSummary[];
export declare const RecoveryPlanExecutionSummaryList: any;
export interface ListRecoveryPlanExecutionsResponse {
    recoveryPlanExecutions: RecoveryPlanExecutionSummary[];
    nextToken?: string;
}
export declare const ListRecoveryPlanExecutionsResponse: S.Schema<ListRecoveryPlanExecutionsResponse>;
export interface ListRecoveryPlanExecutionStepsFilter {
    status?: string;
}
export declare const ListRecoveryPlanExecutionStepsFilter: S.Schema<ListRecoveryPlanExecutionStepsFilter>;
export interface ListRecoveryPlanExecutionStepsRequest {
    recoveryPlanExecutionArn: string;
    filter?: ListRecoveryPlanExecutionStepsFilter;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRecoveryPlanExecutionStepsRequest: S.Schema<ListRecoveryPlanExecutionStepsRequest>;
export interface RecoveryPlanExecutionStepSummary {
    recoveryPlanExecutionStepArn: string;
    stepName: string;
    stepIndex: number;
    status: string;
    configuration: RecoveryPlanExecutionStepConfiguration;
    errorDetail?: ErrorDetail;
}
export declare const RecoveryPlanExecutionStepSummary: S.Schema<RecoveryPlanExecutionStepSummary>;
export type RecoveryPlanExecutionStepSummaryList = RecoveryPlanExecutionStepSummary[];
export declare const RecoveryPlanExecutionStepSummaryList: any;
export interface ListRecoveryPlanExecutionStepsResponse {
    recoveryPlanExecutionSteps: RecoveryPlanExecutionStepSummary[];
    nextToken?: string;
}
export declare const ListRecoveryPlanExecutionStepsResponse: S.Schema<ListRecoveryPlanExecutionStepsResponse>;
export interface ListRecoveryPlansRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRecoveryPlansRequest: S.Schema<ListRecoveryPlansRequest>;
export interface RecoveryPlanSummary {
    recoveryPlanArn: string;
    name: string;
    status: string;
    createdAt: string;
    updatedAt: string;
}
export declare const RecoveryPlanSummary: S.Schema<RecoveryPlanSummary>;
export type RecoveryPlanSummaryList = RecoveryPlanSummary[];
export declare const RecoveryPlanSummaryList: any;
export interface ListRecoveryPlansResponse {
    recoveryPlans: RecoveryPlanSummary[];
    nextToken?: string;
}
export declare const ListRecoveryPlansResponse: S.Schema<ListRecoveryPlansResponse>;
export interface ListRecoveryPlanStepsRequest {
    recoveryPlanArn: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRecoveryPlanStepsRequest: S.Schema<ListRecoveryPlanStepsRequest>;
export type RecoveryPlanStepList = RecoveryPlanStep[];
export declare const RecoveryPlanStepList: any;
export interface ListRecoveryPlanStepsResponse {
    recoveryPlanSteps: RecoveryPlanStep[];
    nextToken?: string;
}
export declare const ListRecoveryPlanStepsResponse: S.Schema<ListRecoveryPlanStepsResponse>;
export interface ListStagingAccountsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListStagingAccountsRequest: S.Schema<ListStagingAccountsRequest>;
export interface Account {
    accountID?: string;
}
export declare const Account: S.Schema<Account>;
export type Accounts = Account[];
export declare const Accounts: any;
export interface ListStagingAccountsResponse {
    accounts?: Account[];
    nextToken?: string;
}
export declare const ListStagingAccountsResponse: S.Schema<ListStagingAccountsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PutLaunchActionRequest {
    resourceId: string;
    actionCode: string;
    order: number;
    actionId: string;
    optional: boolean;
    active: boolean;
    name: string;
    actionVersion: string;
    category: string;
    parameters?: {
        [key: string]: LaunchActionParameter | undefined;
    };
    description: string;
}
export declare const PutLaunchActionRequest: S.Schema<PutLaunchActionRequest>;
export interface PutLaunchActionResponse {
    resourceId?: string;
    actionId?: string;
    actionCode?: string;
    type?: string;
    name?: string;
    active?: boolean;
    order?: number;
    actionVersion?: string;
    optional?: boolean;
    parameters?: {
        [key: string]: LaunchActionParameter | undefined;
    };
    description?: string;
    category?: string;
}
export declare const PutLaunchActionResponse: S.Schema<PutLaunchActionResponse>;
export type RecoveryPlanStepArnList = string[];
export declare const RecoveryPlanStepArnList: any;
export interface ReorderRecoveryPlanStepsRequest {
    recoveryPlanArn: string;
    orderedStepArns: string[];
}
export declare const ReorderRecoveryPlanStepsRequest: S.Schema<ReorderRecoveryPlanStepsRequest>;
export interface ReorderRecoveryPlanStepsResponse {
    recoveryPlanSteps: RecoveryPlanStep[];
}
export declare const ReorderRecoveryPlanStepsResponse: S.Schema<ReorderRecoveryPlanStepsResponse>;
export interface RetryDataReplicationRequest {
    sourceServerID: string;
}
export declare const RetryDataReplicationRequest: S.Schema<RetryDataReplicationRequest>;
export interface RetryRecoveryPlanExecutionStepRequest {
    recoveryPlanExecutionStepArn: string;
}
export declare const RetryRecoveryPlanExecutionStepRequest: S.Schema<RetryRecoveryPlanExecutionStepRequest>;
export interface RetryRecoveryPlanExecutionStepResponse {
    recoveryPlanExecutionStep: RecoveryPlanExecutionStep;
}
export declare const RetryRecoveryPlanExecutionStepResponse: S.Schema<RetryRecoveryPlanExecutionStepResponse>;
export interface ReverseReplicationRequest {
    recoveryInstanceID: string;
}
export declare const ReverseReplicationRequest: S.Schema<ReverseReplicationRequest>;
export interface ReverseReplicationResponse {
    reversedDirectionSourceServerArn?: string;
}
export declare const ReverseReplicationResponse: S.Schema<ReverseReplicationResponse>;
export type StartFailbackRequestRecoveryInstanceIDs = string[];
export declare const StartFailbackRequestRecoveryInstanceIDs: any;
export interface StartFailbackLaunchRequest {
    recoveryInstanceIDs: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StartFailbackLaunchRequest: S.Schema<StartFailbackLaunchRequest>;
export interface StartFailbackLaunchResponse {
    job?: Job;
}
export declare const StartFailbackLaunchResponse: S.Schema<StartFailbackLaunchResponse>;
export interface StartRecoveryRequestSourceServer {
    sourceServerID: string;
    recoverySnapshotID?: string;
}
export declare const StartRecoveryRequestSourceServer: S.Schema<StartRecoveryRequestSourceServer>;
export type StartRecoveryRequestSourceServers = StartRecoveryRequestSourceServer[];
export declare const StartRecoveryRequestSourceServers: any;
export interface StartRecoveryRequest {
    sourceServers: StartRecoveryRequestSourceServer[];
    isDrill?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StartRecoveryRequest: S.Schema<StartRecoveryRequest>;
export interface StartRecoveryResponse {
    job?: Job;
}
export declare const StartRecoveryResponse: S.Schema<StartRecoveryResponse>;
export interface RecoveryPlanExecutionSourceServer {
    sourceServerID: string;
    recoverySnapshotID: string;
}
export declare const RecoveryPlanExecutionSourceServer: S.Schema<RecoveryPlanExecutionSourceServer>;
export type RecoveryPlanExecutionSourceServerList = RecoveryPlanExecutionSourceServer[];
export declare const RecoveryPlanExecutionSourceServerList: any;
export interface StartRecoveryPlanExecutionRequest {
    recoveryPlanArn: string;
    mode: string;
    clientToken?: string;
    sourceServers?: RecoveryPlanExecutionSourceServer[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StartRecoveryPlanExecutionRequest: S.Schema<StartRecoveryPlanExecutionRequest>;
export interface StartRecoveryPlanExecutionResponse {
    recoveryPlanExecution: RecoveryPlanExecution;
}
export declare const StartRecoveryPlanExecutionResponse: S.Schema<StartRecoveryPlanExecutionResponse>;
export interface StartReplicationRequest {
    sourceServerID: string;
}
export declare const StartReplicationRequest: S.Schema<StartReplicationRequest>;
export interface StartReplicationResponse {
    sourceServer?: SourceServer;
}
export declare const StartReplicationResponse: S.Schema<StartReplicationResponse>;
export interface StartSourceNetworkRecoveryRequestNetworkEntry {
    sourceNetworkID: string;
    cfnStackName?: string | redacted.Redacted<string>;
}
export declare const StartSourceNetworkRecoveryRequestNetworkEntry: S.Schema<StartSourceNetworkRecoveryRequestNetworkEntry>;
export type StartSourceNetworkRecoveryRequestNetworkEntries = StartSourceNetworkRecoveryRequestNetworkEntry[];
export declare const StartSourceNetworkRecoveryRequestNetworkEntries: any;
export interface StartSourceNetworkRecoveryRequest {
    sourceNetworks: StartSourceNetworkRecoveryRequestNetworkEntry[];
    deployAsNew?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StartSourceNetworkRecoveryRequest: S.Schema<StartSourceNetworkRecoveryRequest>;
export interface StartSourceNetworkRecoveryResponse {
    job?: Job;
}
export declare const StartSourceNetworkRecoveryResponse: S.Schema<StartSourceNetworkRecoveryResponse>;
export interface StartSourceNetworkReplicationRequest {
    sourceNetworkID: string;
}
export declare const StartSourceNetworkReplicationRequest: S.Schema<StartSourceNetworkReplicationRequest>;
export interface StartSourceNetworkReplicationResponse {
    sourceNetwork?: SourceNetwork;
}
export declare const StartSourceNetworkReplicationResponse: S.Schema<StartSourceNetworkReplicationResponse>;
export interface StopFailbackRequest {
    recoveryInstanceID: string;
}
export declare const StopFailbackRequest: S.Schema<StopFailbackRequest>;
export interface StopFailbackResponse {
}
export declare const StopFailbackResponse: S.Schema<StopFailbackResponse>;
export interface StopReplicationRequest {
    sourceServerID: string;
}
export declare const StopReplicationRequest: S.Schema<StopReplicationRequest>;
export interface StopReplicationResponse {
    sourceServer?: SourceServer;
}
export declare const StopReplicationResponse: S.Schema<StopReplicationResponse>;
export interface StopSourceNetworkReplicationRequest {
    sourceNetworkID: string;
}
export declare const StopSourceNetworkReplicationRequest: S.Schema<StopSourceNetworkReplicationRequest>;
export interface StopSourceNetworkReplicationResponse {
    sourceNetwork?: SourceNetwork;
}
export declare const StopSourceNetworkReplicationResponse: S.Schema<StopSourceNetworkReplicationResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type RecoveryInstancesForTerminationRequest = string[];
export declare const RecoveryInstancesForTerminationRequest: any;
export interface TerminateRecoveryInstancesRequest {
    recoveryInstanceIDs: string[];
}
export declare const TerminateRecoveryInstancesRequest: S.Schema<TerminateRecoveryInstancesRequest>;
export interface TerminateRecoveryInstancesResponse {
    job?: Job;
}
export declare const TerminateRecoveryInstancesResponse: S.Schema<TerminateRecoveryInstancesResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateFailbackReplicationConfigurationRequest {
    recoveryInstanceID: string;
    name?: string;
    bandwidthThrottling?: number;
    usePrivateIP?: boolean;
    internetProtocol?: string;
}
export declare const UpdateFailbackReplicationConfigurationRequest: S.Schema<UpdateFailbackReplicationConfigurationRequest>;
export interface UpdateFailbackReplicationConfigurationResponse {
}
export declare const UpdateFailbackReplicationConfigurationResponse: S.Schema<UpdateFailbackReplicationConfigurationResponse>;
export interface UpdateLaunchConfigurationRequest {
    sourceServerID: string;
    name?: string;
    launchDisposition?: string;
    targetInstanceTypeRightSizingMethod?: string;
    copyPrivateIp?: boolean;
    copyTags?: boolean;
    licensing?: Licensing;
    postLaunchEnabled?: boolean;
    launchIntoInstanceProperties?: LaunchIntoInstanceProperties;
    recoveryMode?: string;
}
export declare const UpdateLaunchConfigurationRequest: S.Schema<UpdateLaunchConfigurationRequest>;
export interface UpdateLaunchConfigurationTemplateRequest {
    launchConfigurationTemplateID: string;
    launchDisposition?: string;
    targetInstanceTypeRightSizingMethod?: string;
    copyPrivateIp?: boolean;
    copyTags?: boolean;
    licensing?: Licensing;
    exportBucketArn?: string;
    postLaunchEnabled?: boolean;
    launchIntoSourceInstance?: boolean;
    recoveryMode?: string;
}
export declare const UpdateLaunchConfigurationTemplateRequest: S.Schema<UpdateLaunchConfigurationTemplateRequest>;
export interface UpdateLaunchConfigurationTemplateResponse {
    launchConfigurationTemplate?: LaunchConfigurationTemplate;
}
export declare const UpdateLaunchConfigurationTemplateResponse: S.Schema<UpdateLaunchConfigurationTemplateResponse>;
export interface UpdateRecoveryPlanRequest {
    recoveryPlanArn: string;
    name?: string;
    description?: string;
}
export declare const UpdateRecoveryPlanRequest: S.Schema<UpdateRecoveryPlanRequest>;
export interface UpdateRecoveryPlanResponse {
    recoveryPlan: RecoveryPlan;
}
export declare const UpdateRecoveryPlanResponse: S.Schema<UpdateRecoveryPlanResponse>;
export interface UpdateRecoveryPlanExecutionStepRequest {
    recoveryPlanExecutionStepArn: string;
    status?: string;
    servers?: RecoveryPlanServer[];
    waitDurationMinutes?: number;
}
export declare const UpdateRecoveryPlanExecutionStepRequest: S.Schema<UpdateRecoveryPlanExecutionStepRequest>;
export interface UpdateRecoveryPlanExecutionStepResponse {
    recoveryPlanExecutionStep: RecoveryPlanExecutionStep;
}
export declare const UpdateRecoveryPlanExecutionStepResponse: S.Schema<UpdateRecoveryPlanExecutionStepResponse>;
export interface UpdateRecoveryPlanStepRequest {
    recoveryPlanStepArn: string;
    stepName?: string;
    configuration?: RecoveryPlanStepConfiguration;
}
export declare const UpdateRecoveryPlanStepRequest: S.Schema<UpdateRecoveryPlanStepRequest>;
export interface UpdateRecoveryPlanStepResponse {
    recoveryPlanStep: RecoveryPlanStep;
}
export declare const UpdateRecoveryPlanStepResponse: S.Schema<UpdateRecoveryPlanStepResponse>;
export interface UpdateReplicationConfigurationRequest {
    sourceServerID: string;
    name?: string;
    stagingAreaSubnetId?: string;
    associateDefaultSecurityGroup?: boolean;
    replicationServersSecurityGroupsIDs?: string[];
    replicationServerInstanceType?: string;
    useDedicatedReplicationServer?: boolean;
    defaultLargeStagingDiskType?: string;
    replicatedDisks?: ReplicationConfigurationReplicatedDisk[];
    ebsEncryption?: string;
    ebsEncryptionKeyArn?: string;
    bandwidthThrottling?: number;
    dataPlaneRouting?: string;
    createPublicIP?: boolean;
    stagingAreaTags?: {
        [key: string]: string | undefined;
    };
    pitPolicy?: PITPolicyRule[];
    autoReplicateNewDisks?: boolean;
    internetProtocol?: string;
}
export declare const UpdateReplicationConfigurationRequest: S.Schema<UpdateReplicationConfigurationRequest>;
export interface UpdateReplicationConfigurationTemplateRequest {
    replicationConfigurationTemplateID: string;
    arn?: string;
    stagingAreaSubnetId?: string;
    associateDefaultSecurityGroup?: boolean;
    replicationServersSecurityGroupsIDs?: string[];
    replicationServerInstanceType?: string;
    useDedicatedReplicationServer?: boolean;
    defaultLargeStagingDiskType?: string;
    ebsEncryption?: string;
    ebsEncryptionKeyArn?: string;
    bandwidthThrottling?: number;
    dataPlaneRouting?: string;
    createPublicIP?: boolean;
    stagingAreaTags?: {
        [key: string]: string | undefined;
    };
    pitPolicy?: PITPolicyRule[];
    autoReplicateNewDisks?: boolean;
    internetProtocol?: string;
}
export declare const UpdateReplicationConfigurationTemplateRequest: S.Schema<UpdateReplicationConfigurationTemplateRequest>;
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name?: string;
    message?: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type AssociateSourceNetworkStackError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Associate a Source Network to an existing CloudFormation Stack and modify launch templates to use this network. Can be used for reverting to previously deployed CloudFormation stacks.
 */
export declare const associateSourceNetworkStack: API.OperationMethod<AssociateSourceNetworkStackRequest, AssociateSourceNetworkStackResponse, AssociateSourceNetworkStackError, Credentials | HttpClient.HttpClient>;
export type CancelRecoveryPlanExecutionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Cancels an in-progress Recovery Plan execution. Remaining steps are skipped.
 */
export declare const cancelRecoveryPlanExecution: API.OperationMethod<CancelRecoveryPlanExecutionRequest, CancelRecoveryPlanExecutionResponse, CancelRecoveryPlanExecutionError, Credentials | HttpClient.HttpClient>;
export type CreateExtendedSourceServerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Create an extended source server in the target Account based on the source server in staging account.
 */
export declare const createExtendedSourceServer: API.OperationMethod<CreateExtendedSourceServerRequest, CreateExtendedSourceServerResponse, CreateExtendedSourceServerError, Credentials | HttpClient.HttpClient>;
export type CreateLaunchConfigurationTemplateError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Creates a new Launch Configuration Template.
 */
export declare const createLaunchConfigurationTemplate: API.OperationMethod<CreateLaunchConfigurationTemplateRequest, CreateLaunchConfigurationTemplateResponse, CreateLaunchConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateRecoveryPlanError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Creates a Recovery Plan to orchestrate multi-server disaster recovery.
 */
export declare const createRecoveryPlan: API.OperationMethod<CreateRecoveryPlanRequest, CreateRecoveryPlanResponse, CreateRecoveryPlanError, Credentials | HttpClient.HttpClient>;
export type CreateRecoveryPlanStepError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Creates a step in a Recovery Plan. A step is either `SERVER` type (servers to recover in parallel) or `WAIT` type (timed pause between steps).
 */
export declare const createRecoveryPlanStep: API.OperationMethod<CreateRecoveryPlanStepRequest, CreateRecoveryPlanStepResponse, CreateRecoveryPlanStepError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationConfigurationTemplateError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Creates a new ReplicationConfigurationTemplate.
 */
export declare const createReplicationConfigurationTemplate: API.OperationMethod<CreateReplicationConfigurationTemplateRequest, ReplicationConfigurationTemplate, CreateReplicationConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateSourceNetworkError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Create a new Source Network resource for a provided VPC ID.
 */
export declare const createSourceNetwork: API.OperationMethod<CreateSourceNetworkRequest, CreateSourceNetworkResponse, CreateSourceNetworkError, Credentials | HttpClient.HttpClient>;
export type DeleteJobError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single Job by ID.
 */
export declare const deleteJob: API.OperationMethod<DeleteJobRequest, DeleteJobResponse, DeleteJobError, Credentials | HttpClient.HttpClient>;
export type DeleteLaunchActionError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Deletes a resource launch action.
 */
export declare const deleteLaunchAction: API.OperationMethod<DeleteLaunchActionRequest, DeleteLaunchActionResponse, DeleteLaunchActionError, Credentials | HttpClient.HttpClient>;
export type DeleteLaunchConfigurationTemplateError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single Launch Configuration Template by ID.
 */
export declare const deleteLaunchConfigurationTemplate: API.OperationMethod<DeleteLaunchConfigurationTemplateRequest, DeleteLaunchConfigurationTemplateResponse, DeleteLaunchConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteRecoveryInstanceError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single Recovery Instance by ID. This deletes the Recovery Instance resource from Elastic Disaster Recovery. The Recovery Instance must be disconnected first in order to delete it.
 */
export declare const deleteRecoveryInstance: API.OperationMethod<DeleteRecoveryInstanceRequest, DeleteRecoveryInstanceResponse, DeleteRecoveryInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteRecoveryPlanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Deletes a Recovery Plan. Cannot delete a plan that has an execution in a non-terminal status (`CREATED`, `IN_PROGRESS`).
 */
export declare const deleteRecoveryPlan: API.OperationMethod<DeleteRecoveryPlanRequest, DeleteRecoveryPlanResponse, DeleteRecoveryPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteRecoveryPlanExecutionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Deletes a Recovery Plan execution record. Must be in a terminal status.
 */
export declare const deleteRecoveryPlanExecution: API.OperationMethod<DeleteRecoveryPlanExecutionRequest, DeleteRecoveryPlanExecutionResponse, DeleteRecoveryPlanExecutionError, Credentials | HttpClient.HttpClient>;
export type DeleteRecoveryPlanStepError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Deletes a step from a Recovery Plan.
 */
export declare const deleteRecoveryPlanStep: API.OperationMethod<DeleteRecoveryPlanStepRequest, DeleteRecoveryPlanStepResponse, DeleteRecoveryPlanStepError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationConfigurationTemplateError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single Replication Configuration Template by ID
 */
export declare const deleteReplicationConfigurationTemplate: API.OperationMethod<DeleteReplicationConfigurationTemplateRequest, DeleteReplicationConfigurationTemplateResponse, DeleteReplicationConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteSourceNetworkError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Delete Source Network resource.
 */
export declare const deleteSourceNetwork: API.OperationMethod<DeleteSourceNetworkRequest, DeleteSourceNetworkResponse, DeleteSourceNetworkError, Credentials | HttpClient.HttpClient>;
export type DeleteSourceServerError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single Source Server by ID. The Source Server must be disconnected first.
 */
export declare const deleteSourceServer: API.OperationMethod<DeleteSourceServerRequest, DeleteSourceServerResponse, DeleteSourceServerError, Credentials | HttpClient.HttpClient>;
export type DescribeJobLogItemsError = InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Retrieves a detailed Job log with pagination.
 */
export declare const describeJobLogItems: API.PaginatedOperationMethod<DescribeJobLogItemsRequest, DescribeJobLogItemsResponse, DescribeJobLogItemsError, Credentials | HttpClient.HttpClient, JobLog>;
export type DescribeJobsError = InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Returns a list of Jobs. Use the JobsID and fromDate and toDate filters to limit which jobs are returned. The response is sorted by creationDataTime - latest date first. Jobs are created by the StartRecovery, TerminateRecoveryInstances and StartFailbackLaunch APIs. Jobs are also created by DiagnosticLaunch and TerminateDiagnosticInstances, which are APIs available only to *Support* and only used in response to relevant support tickets.
 */
export declare const describeJobs: API.PaginatedOperationMethod<DescribeJobsRequest, DescribeJobsResponse, DescribeJobsError, Credentials | HttpClient.HttpClient, Job>;
export type DescribeLaunchConfigurationTemplatesError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all Launch Configuration Templates, filtered by Launch Configuration Template IDs
 */
export declare const describeLaunchConfigurationTemplates: API.PaginatedOperationMethod<DescribeLaunchConfigurationTemplatesRequest, DescribeLaunchConfigurationTemplatesResponse, DescribeLaunchConfigurationTemplatesError, Credentials | HttpClient.HttpClient, LaunchConfigurationTemplate>;
export type DescribeRecoveryInstancesError = AccessDeniedException | InternalServerException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Lists all Recovery Instances or multiple Recovery Instances by ID.
 */
export declare const describeRecoveryInstances: API.PaginatedOperationMethod<DescribeRecoveryInstancesRequest, DescribeRecoveryInstancesResponse, DescribeRecoveryInstancesError, Credentials | HttpClient.HttpClient, RecoveryInstance>;
export type DescribeRecoverySnapshotsError = AccessDeniedException | InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all Recovery Snapshots for a single Source Server.
 */
export declare const describeRecoverySnapshots: API.PaginatedOperationMethod<DescribeRecoverySnapshotsRequest, DescribeRecoverySnapshotsResponse, DescribeRecoverySnapshotsError, Credentials | HttpClient.HttpClient, RecoverySnapshot>;
export type DescribeReplicationConfigurationTemplatesError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all ReplicationConfigurationTemplates, filtered by Source Server IDs.
 */
export declare const describeReplicationConfigurationTemplates: API.PaginatedOperationMethod<DescribeReplicationConfigurationTemplatesRequest, DescribeReplicationConfigurationTemplatesResponse, DescribeReplicationConfigurationTemplatesError, Credentials | HttpClient.HttpClient, ReplicationConfigurationTemplate>;
export type DescribeSourceNetworksError = InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all Source Networks or multiple Source Networks filtered by ID.
 */
export declare const describeSourceNetworks: API.PaginatedOperationMethod<DescribeSourceNetworksRequest, DescribeSourceNetworksResponse, DescribeSourceNetworksError, Credentials | HttpClient.HttpClient, SourceNetwork>;
export type DescribeSourceServersError = InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all Source Servers or multiple Source Servers filtered by ID.
 */
export declare const describeSourceServers: API.PaginatedOperationMethod<DescribeSourceServersRequest, DescribeSourceServersResponse, DescribeSourceServersError, Credentials | HttpClient.HttpClient, SourceServer>;
export type DisconnectRecoveryInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Disconnect a Recovery Instance from Elastic Disaster Recovery. Data replication is stopped immediately. All AWS resources created by Elastic Disaster Recovery for enabling the replication of the Recovery Instance will be terminated / deleted within 90 minutes. If the agent on the Recovery Instance has not been prevented from communicating with the Elastic Disaster Recovery service, then it will receive a command to uninstall itself (within approximately 10 minutes). The following properties of the Recovery Instance will be changed immediately: dataReplicationInfo.dataReplicationState will be set to DISCONNECTED; The totalStorageBytes property for each of dataReplicationInfo.replicatedDisks will be set to zero; dataReplicationInfo.lagDuration and dataReplicationInfo.lagDuration will be nullified.
 */
export declare const disconnectRecoveryInstance: API.OperationMethod<DisconnectRecoveryInstanceRequest, DisconnectRecoveryInstanceResponse, DisconnectRecoveryInstanceError, Credentials | HttpClient.HttpClient>;
export type DisconnectSourceServerError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Disconnects a specific Source Server from Elastic Disaster Recovery. Data replication is stopped immediately. All AWS resources created by Elastic Disaster Recovery for enabling the replication of the Source Server will be terminated / deleted within 90 minutes. You cannot disconnect a Source Server if it has a Recovery Instance. If the agent on the Source Server has not been prevented from communicating with the Elastic Disaster Recovery service, then it will receive a command to uninstall itself (within approximately 10 minutes). The following properties of the SourceServer will be changed immediately: dataReplicationInfo.dataReplicationState will be set to DISCONNECTED; The totalStorageBytes property for each of dataReplicationInfo.replicatedDisks will be set to zero; dataReplicationInfo.lagDuration and dataReplicationInfo.lagDuration will be nullified.
 */
export declare const disconnectSourceServer: API.OperationMethod<DisconnectSourceServerRequest, SourceServer, DisconnectSourceServerError, Credentials | HttpClient.HttpClient>;
export type ExportSourceNetworkCfnTemplateError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Export the Source Network CloudFormation template to an S3 bucket.
 */
export declare const exportSourceNetworkCfnTemplate: API.OperationMethod<ExportSourceNetworkCfnTemplateRequest, ExportSourceNetworkCfnTemplateResponse, ExportSourceNetworkCfnTemplateError, Credentials | HttpClient.HttpClient>;
export type GetFailbackReplicationConfigurationError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Lists all Failback ReplicationConfigurations, filtered by Recovery Instance ID.
 */
export declare const getFailbackReplicationConfiguration: API.OperationMethod<GetFailbackReplicationConfigurationRequest, GetFailbackReplicationConfigurationResponse, GetFailbackReplicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetLaunchConfigurationError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Gets a LaunchConfiguration, filtered by Source Server IDs.
 */
export declare const getLaunchConfiguration: API.OperationMethod<GetLaunchConfigurationRequest, LaunchConfiguration, GetLaunchConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetRecoveryPlanError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Gets a Recovery Plan by ARN.
 */
export declare const getRecoveryPlan: API.OperationMethod<GetRecoveryPlanRequest, GetRecoveryPlanResponse, GetRecoveryPlanError, Credentials | HttpClient.HttpClient>;
export type GetRecoveryPlanExecutionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Gets the details of a Recovery Plan execution.
 */
export declare const getRecoveryPlanExecution: API.OperationMethod<GetRecoveryPlanExecutionRequest, GetRecoveryPlanExecutionResponse, GetRecoveryPlanExecutionError, Credentials | HttpClient.HttpClient>;
export type GetRecoveryPlanExecutionStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Gets the details of a step within a Recovery Plan execution.
 */
export declare const getRecoveryPlanExecutionStep: API.OperationMethod<GetRecoveryPlanExecutionStepRequest, GetRecoveryPlanExecutionStepResponse, GetRecoveryPlanExecutionStepError, Credentials | HttpClient.HttpClient>;
export type GetRecoveryPlanStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Gets a Recovery Plan step by ARN.
 */
export declare const getRecoveryPlanStep: API.OperationMethod<GetRecoveryPlanStepRequest, GetRecoveryPlanStepResponse, GetRecoveryPlanStepError, Credentials | HttpClient.HttpClient>;
export type GetReplicationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Gets a ReplicationConfiguration, filtered by Source Server ID.
 */
export declare const getReplicationConfiguration: API.OperationMethod<GetReplicationConfigurationRequest, ReplicationConfiguration, GetReplicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type InitializeServiceError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initialize Elastic Disaster Recovery.
 */
export declare const initializeService: API.OperationMethod<InitializeServiceRequest, InitializeServiceResponse, InitializeServiceError, Credentials | HttpClient.HttpClient>;
export type ListExtensibleSourceServersError = AccessDeniedException | InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Returns a list of source servers on a staging account that are extensible, which means that: a. The source server is not already extended into this Account. b. The source server on the Account we’re reading from is not an extension of another source server.
 */
export declare const listExtensibleSourceServers: API.PaginatedOperationMethod<ListExtensibleSourceServersRequest, ListExtensibleSourceServersResponse, ListExtensibleSourceServersError, Credentials | HttpClient.HttpClient, StagingSourceServer>;
export type ListLaunchActionsError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Lists resource launch actions.
 */
export declare const listLaunchActions: API.PaginatedOperationMethod<ListLaunchActionsRequest, ListLaunchActionsResponse, ListLaunchActionsError, Credentials | HttpClient.HttpClient, LaunchAction>;
export type ListRecoveryPlanExecutionsError = AccessDeniedException | InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists executions of Recovery Plans, optionally filtered by plan or status.
 */
export declare const listRecoveryPlanExecutions: API.PaginatedOperationMethod<ListRecoveryPlanExecutionsRequest, ListRecoveryPlanExecutionsResponse, ListRecoveryPlanExecutionsError, Credentials | HttpClient.HttpClient, RecoveryPlanExecutionSummary>;
export type ListRecoveryPlanExecutionStepsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all steps within a Recovery Plan execution.
 */
export declare const listRecoveryPlanExecutionSteps: API.PaginatedOperationMethod<ListRecoveryPlanExecutionStepsRequest, ListRecoveryPlanExecutionStepsResponse, ListRecoveryPlanExecutionStepsError, Credentials | HttpClient.HttpClient, RecoveryPlanExecutionStepSummary>;
export type ListRecoveryPlansError = AccessDeniedException | InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all Recovery Plans in the account.
 */
export declare const listRecoveryPlans: API.PaginatedOperationMethod<ListRecoveryPlansRequest, ListRecoveryPlansResponse, ListRecoveryPlansError, Credentials | HttpClient.HttpClient, RecoveryPlanSummary>;
export type ListRecoveryPlanStepsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all steps in a Recovery Plan.
 */
export declare const listRecoveryPlanSteps: API.PaginatedOperationMethod<ListRecoveryPlanStepsRequest, ListRecoveryPlanStepsResponse, ListRecoveryPlanStepsError, Credentials | HttpClient.HttpClient, RecoveryPlanStep>;
export type ListStagingAccountsError = AccessDeniedException | InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Returns an array of staging accounts for existing extended source servers.
 */
export declare const listStagingAccounts: API.PaginatedOperationMethod<ListStagingAccountsRequest, ListStagingAccountsResponse, ListStagingAccountsError, Credentials | HttpClient.HttpClient, Account>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all tags for your Elastic Disaster Recovery resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutLaunchActionError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Puts a resource launch action.
 */
export declare const putLaunchAction: API.OperationMethod<PutLaunchActionRequest, PutLaunchActionResponse, PutLaunchActionError, Credentials | HttpClient.HttpClient>;
export type ReorderRecoveryPlanStepsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Reorders steps in a Recovery Plan. Accepts a complete ordered list of step ARNs.
 */
export declare const reorderRecoveryPlanSteps: API.OperationMethod<ReorderRecoveryPlanStepsRequest, ReorderRecoveryPlanStepsResponse, ReorderRecoveryPlanStepsError, Credentials | HttpClient.HttpClient>;
export type RetryDataReplicationError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * WARNING: RetryDataReplication is deprecated. Causes the data replication initiation sequence to begin immediately upon next Handshake for the specified Source Server ID, regardless of when the previous initiation started. This command will work only if the Source Server is stalled or is in a DISCONNECTED or STOPPED state.
 */
export declare const retryDataReplication: API.OperationMethod<RetryDataReplicationRequest, SourceServer, RetryDataReplicationError, Credentials | HttpClient.HttpClient>;
export type RetryRecoveryPlanExecutionStepError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Retries a failed `SERVER` type execution step.
 */
export declare const retryRecoveryPlanExecutionStep: API.OperationMethod<RetryRecoveryPlanExecutionStepRequest, RetryRecoveryPlanExecutionStepResponse, RetryRecoveryPlanExecutionStepError, Credentials | HttpClient.HttpClient>;
export type ReverseReplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Start replication to origin / target region - applies only to protected instances that originated in EC2. For recovery instances on target region - starts replication back to origin region. For failback instances on origin region - starts replication to target region to re-protect them.
 */
export declare const reverseReplication: API.OperationMethod<ReverseReplicationRequest, ReverseReplicationResponse, ReverseReplicationError, Credentials | HttpClient.HttpClient>;
export type StartFailbackLaunchError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Initiates a Job for launching the machine that is being failed back to from the specified Recovery Instance. This will run conversion on the failback client and will reboot your machine, thus completing the failback process.
 */
export declare const startFailbackLaunch: API.OperationMethod<StartFailbackLaunchRequest, StartFailbackLaunchResponse, StartFailbackLaunchError, Credentials | HttpClient.HttpClient>;
export type StartRecoveryError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Launches Recovery Instances for the specified Source Servers. For each Source Server you may choose a point in time snapshot to launch from, or use an on demand snapshot.
 */
export declare const startRecovery: API.OperationMethod<StartRecoveryRequest, StartRecoveryResponse, StartRecoveryError, Credentials | HttpClient.HttpClient>;
export type StartRecoveryPlanExecutionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Starts executing a Recovery Plan in `DRILL` or `RECOVERY` mode. A plan cannot have more than one execution in a non-terminal status at a time.
 */
export declare const startRecoveryPlanExecution: API.OperationMethod<StartRecoveryPlanExecutionRequest, StartRecoveryPlanExecutionResponse, StartRecoveryPlanExecutionError, Credentials | HttpClient.HttpClient>;
export type StartReplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Starts replication for a stopped Source Server. This action would make the Source Server protected again and restart billing for it.
 */
export declare const startReplication: API.OperationMethod<StartReplicationRequest, StartReplicationResponse, StartReplicationError, Credentials | HttpClient.HttpClient>;
export type StartSourceNetworkRecoveryError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Deploy VPC for the specified Source Network and modify launch templates to use this network. The VPC will be deployed using a dedicated CloudFormation stack.
 */
export declare const startSourceNetworkRecovery: API.OperationMethod<StartSourceNetworkRecoveryRequest, StartSourceNetworkRecoveryResponse, StartSourceNetworkRecoveryError, Credentials | HttpClient.HttpClient>;
export type StartSourceNetworkReplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Starts replication for a Source Network. This action would make the Source Network protected.
 */
export declare const startSourceNetworkReplication: API.OperationMethod<StartSourceNetworkReplicationRequest, StartSourceNetworkReplicationResponse, StartSourceNetworkReplicationError, Credentials | HttpClient.HttpClient>;
export type StopFailbackError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Stops the failback process for a specified Recovery Instance. This changes the Failback State of the Recovery Instance back to FAILBACK_NOT_STARTED.
 */
export declare const stopFailback: API.OperationMethod<StopFailbackRequest, StopFailbackResponse, StopFailbackError, Credentials | HttpClient.HttpClient>;
export type StopReplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Stops replication for a Source Server. This action would make the Source Server unprotected, delete its existing snapshots and stop billing for it.
 */
export declare const stopReplication: API.OperationMethod<StopReplicationRequest, StopReplicationResponse, StopReplicationError, Credentials | HttpClient.HttpClient>;
export type StopSourceNetworkReplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Stops replication for a Source Network. This action would make the Source Network unprotected.
 */
export declare const stopSourceNetworkReplication: API.OperationMethod<StopSourceNetworkReplicationRequest, StopSourceNetworkReplicationResponse, StopSourceNetworkReplicationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or overwrites only the specified tags for the specified Elastic Disaster Recovery resource or resources. When you specify an existing tag key, the value is overwritten with the new value. Each resource can have a maximum of 50 tags. Each tag consists of a key and optional value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateRecoveryInstancesError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Initiates a Job for terminating the EC2 resources associated with the specified Recovery Instances, and then will delete the Recovery Instances from the Elastic Disaster Recovery service.
 */
export declare const terminateRecoveryInstances: API.OperationMethod<TerminateRecoveryInstancesRequest, TerminateRecoveryInstancesResponse, TerminateRecoveryInstancesError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified set of tags from the specified set of Elastic Disaster Recovery resources.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateFailbackReplicationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Allows you to update the failback replication configuration of a Recovery Instance by ID.
 */
export declare const updateFailbackReplicationConfiguration: API.OperationMethod<UpdateFailbackReplicationConfigurationRequest, UpdateFailbackReplicationConfigurationResponse, UpdateFailbackReplicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLaunchConfigurationError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates a LaunchConfiguration by Source Server ID.
 */
export declare const updateLaunchConfiguration: API.OperationMethod<UpdateLaunchConfigurationRequest, LaunchConfiguration, UpdateLaunchConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLaunchConfigurationTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates an existing Launch Configuration Template by ID.
 */
export declare const updateLaunchConfigurationTemplate: API.OperationMethod<UpdateLaunchConfigurationTemplateRequest, UpdateLaunchConfigurationTemplateResponse, UpdateLaunchConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateRecoveryPlanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates a Recovery Plan's name or description.
 */
export declare const updateRecoveryPlan: API.OperationMethod<UpdateRecoveryPlanRequest, UpdateRecoveryPlanResponse, UpdateRecoveryPlanError, Credentials | HttpClient.HttpClient>;
export type UpdateRecoveryPlanExecutionStepError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates an execution step. Supports two actions: (1) skip a step that is in `NOT_STARTED` or `FAILED` status; (2) update the wait duration of a `WAIT` type step that is in `NOT_STARTED` status.
 */
export declare const updateRecoveryPlanExecutionStep: API.OperationMethod<UpdateRecoveryPlanExecutionStepRequest, UpdateRecoveryPlanExecutionStepResponse, UpdateRecoveryPlanExecutionStepError, Credentials | HttpClient.HttpClient>;
export type UpdateRecoveryPlanStepError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates a Recovery Plan step's name or configuration. Step type is immutable.
 */
export declare const updateRecoveryPlanStep: API.OperationMethod<UpdateRecoveryPlanStepRequest, UpdateRecoveryPlanStepResponse, UpdateRecoveryPlanStepError, Credentials | HttpClient.HttpClient>;
export type UpdateReplicationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Allows you to update a ReplicationConfiguration by Source Server ID.
 */
export declare const updateReplicationConfiguration: API.OperationMethod<UpdateReplicationConfigurationRequest, ReplicationConfiguration, UpdateReplicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateReplicationConfigurationTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates a ReplicationConfigurationTemplate by ID.
 */
export declare const updateReplicationConfigurationTemplate: API.OperationMethod<UpdateReplicationConfigurationTemplateRequest, ReplicationConfigurationTemplate, UpdateReplicationConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=drs.d.ts.map