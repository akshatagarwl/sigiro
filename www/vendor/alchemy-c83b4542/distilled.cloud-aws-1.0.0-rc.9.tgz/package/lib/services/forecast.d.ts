import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InvalidInputException_base: S.Class<InvalidInputException, S.TaggedStruct<"InvalidInputException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidNextTokenException_base: S.Class<InvalidNextTokenException, S.TaggedStruct<"InvalidNextTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.Class<ResourceAlreadyExistsException, S.TaggedStruct<"ResourceAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type Name = string;
export type ForecastType = string;
export type ForecastTypes = string[];
export declare const ForecastTypes: any;
export type ForecastDimensions = string[];
export declare const ForecastDimensions: any;
export type Frequency = string;
export type Arn = string;
export type Value = string;
export type Transformations = {
    [key: string]: string | undefined;
};
export declare const Transformations: any;
export interface AttributeConfig {
    AttributeName: string;
    Transformations: {
        [key: string]: string | undefined;
    };
}
export declare const AttributeConfig: S.Schema<AttributeConfig>;
export type AttributeConfigs = AttributeConfig[];
export declare const AttributeConfigs: any;
export type Values = string[];
export declare const Values: any;
export type Configuration = {
    [key: string]: string[] | undefined;
};
export declare const Configuration: any;
export interface AdditionalDataset {
    Name: string;
    Configuration?: {
        [key: string]: string[] | undefined;
    };
}
export declare const AdditionalDataset: S.Schema<AdditionalDataset>;
export type AdditionalDatasets = AdditionalDataset[];
export declare const AdditionalDatasets: any;
export interface DataConfig {
    DatasetGroupArn: string;
    AttributeConfigs?: AttributeConfig[];
    AdditionalDatasets?: AdditionalDataset[];
}
export declare const DataConfig: S.Schema<DataConfig>;
export type KMSKeyArn = string;
export interface EncryptionConfig {
    RoleArn: string;
    KMSKeyArn: string;
}
export declare const EncryptionConfig: S.Schema<EncryptionConfig>;
export type OptimizationMetric = "WAPE" | "RMSE" | "AverageWeightedQuantileLoss" | "MASE" | "MAPE" | (string & {});
export declare const OptimizationMetric: any;
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    Key: string | redacted.Redacted<string>;
    Value: string | redacted.Redacted<string>;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export interface MonitorConfig {
    MonitorName: string;
}
export declare const MonitorConfig: S.Schema<MonitorConfig>;
export type Month = "JANUARY" | "FEBRUARY" | "MARCH" | "APRIL" | "MAY" | "JUNE" | "JULY" | "AUGUST" | "SEPTEMBER" | "OCTOBER" | "NOVEMBER" | "DECEMBER" | (string & {});
export declare const Month: any;
export type DayOfMonth = number;
export type DayOfWeek = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export declare const DayOfWeek: any;
export type Hour = number;
export interface TimeAlignmentBoundary {
    Month?: Month;
    DayOfMonth?: number;
    DayOfWeek?: DayOfWeek;
    Hour?: number;
}
export declare const TimeAlignmentBoundary: S.Schema<TimeAlignmentBoundary>;
export interface CreateAutoPredictorRequest {
    PredictorName: string;
    ForecastHorizon?: number;
    ForecastTypes?: string[];
    ForecastDimensions?: string[];
    ForecastFrequency?: string;
    DataConfig?: DataConfig;
    EncryptionConfig?: EncryptionConfig;
    ReferencePredictorArn?: string;
    OptimizationMetric?: OptimizationMetric;
    ExplainPredictor?: boolean;
    Tags?: Tag[];
    MonitorConfig?: MonitorConfig;
    TimeAlignmentBoundary?: TimeAlignmentBoundary;
}
export declare const CreateAutoPredictorRequest: S.Schema<CreateAutoPredictorRequest>;
export interface CreateAutoPredictorResponse {
    PredictorArn?: string;
}
export declare const CreateAutoPredictorResponse: S.Schema<CreateAutoPredictorResponse>;
export type Domain = "RETAIL" | "CUSTOM" | "INVENTORY_PLANNING" | "EC2_CAPACITY" | "WORK_FORCE" | "WEB_TRAFFIC" | "METRICS" | (string & {});
export declare const Domain: any;
export type DatasetType = "TARGET_TIME_SERIES" | "RELATED_TIME_SERIES" | "ITEM_METADATA" | (string & {});
export declare const DatasetType: any;
export type AttributeType = "string" | "integer" | "float" | "timestamp" | "geolocation" | (string & {});
export declare const AttributeType: any;
export interface SchemaAttribute {
    AttributeName?: string;
    AttributeType?: AttributeType;
}
export declare const SchemaAttribute: S.Schema<SchemaAttribute>;
export type SchemaAttributes = SchemaAttribute[];
export declare const SchemaAttributes: any;
export interface Schema {
    Attributes?: SchemaAttribute[];
}
export declare const Schema: S.Schema<Schema>;
export interface CreateDatasetRequest {
    DatasetName: string;
    Domain: Domain;
    DatasetType: DatasetType;
    DataFrequency?: string;
    Schema: Schema;
    EncryptionConfig?: EncryptionConfig;
    Tags?: Tag[];
}
export declare const CreateDatasetRequest: S.Schema<CreateDatasetRequest>;
export interface CreateDatasetResponse {
    DatasetArn?: string;
}
export declare const CreateDatasetResponse: S.Schema<CreateDatasetResponse>;
export type ArnList = string[];
export declare const ArnList: any;
export interface CreateDatasetGroupRequest {
    DatasetGroupName: string;
    Domain: Domain;
    DatasetArns?: string[];
    Tags?: Tag[];
}
export declare const CreateDatasetGroupRequest: S.Schema<CreateDatasetGroupRequest>;
export interface CreateDatasetGroupResponse {
    DatasetGroupArn?: string;
}
export declare const CreateDatasetGroupResponse: S.Schema<CreateDatasetGroupResponse>;
export type S3Path = string;
export interface S3Config {
    Path: string;
    RoleArn: string;
    KMSKeyArn?: string;
}
export declare const S3Config: S.Schema<S3Config>;
export interface DataSource {
    S3Config: S3Config;
}
export declare const DataSource: S.Schema<DataSource>;
export type TimestampFormat = string;
export type TimeZone = string;
export type UseGeolocationForTimeZone = boolean;
export type GeolocationFormat = string;
export type Format = string;
export type ImportMode = "FULL" | "INCREMENTAL" | (string & {});
export declare const ImportMode: any;
export interface CreateDatasetImportJobRequest {
    DatasetImportJobName: string;
    DatasetArn: string;
    DataSource: DataSource;
    TimestampFormat?: string;
    TimeZone?: string;
    UseGeolocationForTimeZone?: boolean;
    GeolocationFormat?: string;
    Tags?: Tag[];
    Format?: string;
    ImportMode?: ImportMode;
}
export declare const CreateDatasetImportJobRequest: S.Schema<CreateDatasetImportJobRequest>;
export interface CreateDatasetImportJobResponse {
    DatasetImportJobArn?: string;
}
export declare const CreateDatasetImportJobResponse: S.Schema<CreateDatasetImportJobResponse>;
export type TimeSeriesGranularity = "ALL" | "SPECIFIC" | (string & {});
export declare const TimeSeriesGranularity: any;
export type TimePointGranularity = "ALL" | "SPECIFIC" | (string & {});
export declare const TimePointGranularity: any;
export interface ExplainabilityConfig {
    TimeSeriesGranularity: TimeSeriesGranularity;
    TimePointGranularity: TimePointGranularity;
}
export declare const ExplainabilityConfig: S.Schema<ExplainabilityConfig>;
export type LocalDateTime = string;
export interface CreateExplainabilityRequest {
    ExplainabilityName: string;
    ResourceArn: string;
    ExplainabilityConfig: ExplainabilityConfig;
    DataSource?: DataSource;
    Schema?: Schema;
    EnableVisualization?: boolean;
    StartDateTime?: string;
    EndDateTime?: string;
    Tags?: Tag[];
}
export declare const CreateExplainabilityRequest: S.Schema<CreateExplainabilityRequest>;
export interface CreateExplainabilityResponse {
    ExplainabilityArn?: string;
}
export declare const CreateExplainabilityResponse: S.Schema<CreateExplainabilityResponse>;
export interface DataDestination {
    S3Config: S3Config;
}
export declare const DataDestination: S.Schema<DataDestination>;
export interface CreateExplainabilityExportRequest {
    ExplainabilityExportName: string;
    ExplainabilityArn: string;
    Destination: DataDestination;
    Tags?: Tag[];
    Format?: string;
}
export declare const CreateExplainabilityExportRequest: S.Schema<CreateExplainabilityExportRequest>;
export interface CreateExplainabilityExportResponse {
    ExplainabilityExportArn?: string;
}
export declare const CreateExplainabilityExportResponse: S.Schema<CreateExplainabilityExportResponse>;
export interface TimeSeriesIdentifiers {
    DataSource?: DataSource;
    Schema?: Schema;
    Format?: string;
}
export declare const TimeSeriesIdentifiers: S.Schema<TimeSeriesIdentifiers>;
export interface TimeSeriesSelector {
    TimeSeriesIdentifiers?: TimeSeriesIdentifiers;
}
export declare const TimeSeriesSelector: S.Schema<TimeSeriesSelector>;
export interface CreateForecastRequest {
    ForecastName: string;
    PredictorArn: string;
    ForecastTypes?: string[];
    Tags?: Tag[];
    TimeSeriesSelector?: TimeSeriesSelector;
}
export declare const CreateForecastRequest: S.Schema<CreateForecastRequest>;
export interface CreateForecastResponse {
    ForecastArn?: string;
}
export declare const CreateForecastResponse: S.Schema<CreateForecastResponse>;
export interface CreateForecastExportJobRequest {
    ForecastExportJobName: string;
    ForecastArn: string;
    Destination: DataDestination;
    Tags?: Tag[];
    Format?: string;
}
export declare const CreateForecastExportJobRequest: S.Schema<CreateForecastExportJobRequest>;
export interface CreateForecastExportJobResponse {
    ForecastExportJobArn?: string;
}
export declare const CreateForecastExportJobResponse: S.Schema<CreateForecastExportJobResponse>;
export interface CreateMonitorRequest {
    MonitorName: string;
    ResourceArn: string;
    Tags?: Tag[];
}
export declare const CreateMonitorRequest: S.Schema<CreateMonitorRequest>;
export interface CreateMonitorResponse {
    MonitorArn?: string;
}
export declare const CreateMonitorResponse: S.Schema<CreateMonitorResponse>;
export type AutoMLOverrideStrategy = "LatencyOptimized" | "AccuracyOptimized" | (string & {});
export declare const AutoMLOverrideStrategy: any;
export type ParameterKey = string;
export type ParameterValue = string;
export type TrainingParameters = {
    [key: string]: string | undefined;
};
export declare const TrainingParameters: any;
export interface EvaluationParameters {
    NumberOfBacktestWindows?: number;
    BackTestWindowOffset?: number;
}
export declare const EvaluationParameters: S.Schema<EvaluationParameters>;
export interface CategoricalParameterRange {
    Name: string;
    Values: string[];
}
export declare const CategoricalParameterRange: S.Schema<CategoricalParameterRange>;
export type CategoricalParameterRanges = CategoricalParameterRange[];
export declare const CategoricalParameterRanges: any;
export type ScalingType = "Auto" | "Linear" | "Logarithmic" | "ReverseLogarithmic" | (string & {});
export declare const ScalingType: any;
export interface ContinuousParameterRange {
    Name: string;
    MaxValue: number;
    MinValue: number;
    ScalingType?: ScalingType;
}
export declare const ContinuousParameterRange: S.Schema<ContinuousParameterRange>;
export type ContinuousParameterRanges = ContinuousParameterRange[];
export declare const ContinuousParameterRanges: any;
export interface IntegerParameterRange {
    Name: string;
    MaxValue: number;
    MinValue: number;
    ScalingType?: ScalingType;
}
export declare const IntegerParameterRange: S.Schema<IntegerParameterRange>;
export type IntegerParameterRanges = IntegerParameterRange[];
export declare const IntegerParameterRanges: any;
export interface ParameterRanges {
    CategoricalParameterRanges?: CategoricalParameterRange[];
    ContinuousParameterRanges?: ContinuousParameterRange[];
    IntegerParameterRanges?: IntegerParameterRange[];
}
export declare const ParameterRanges: S.Schema<ParameterRanges>;
export interface HyperParameterTuningJobConfig {
    ParameterRanges?: ParameterRanges;
}
export declare const HyperParameterTuningJobConfig: S.Schema<HyperParameterTuningJobConfig>;
export interface SupplementaryFeature {
    Name: string;
    Value: string;
}
export declare const SupplementaryFeature: S.Schema<SupplementaryFeature>;
export type SupplementaryFeatures = SupplementaryFeature[];
export declare const SupplementaryFeatures: any;
export interface InputDataConfig {
    DatasetGroupArn: string;
    SupplementaryFeatures?: SupplementaryFeature[];
}
export declare const InputDataConfig: S.Schema<InputDataConfig>;
export type FeaturizationMethodName = "filling" | (string & {});
export declare const FeaturizationMethodName: any;
export type FeaturizationMethodParameters = {
    [key: string]: string | undefined;
};
export declare const FeaturizationMethodParameters: any;
export interface FeaturizationMethod {
    FeaturizationMethodName: FeaturizationMethodName;
    FeaturizationMethodParameters?: {
        [key: string]: string | undefined;
    };
}
export declare const FeaturizationMethod: S.Schema<FeaturizationMethod>;
export type FeaturizationPipeline = FeaturizationMethod[];
export declare const FeaturizationPipeline: any;
export interface Featurization {
    AttributeName: string;
    FeaturizationPipeline?: FeaturizationMethod[];
}
export declare const Featurization: S.Schema<Featurization>;
export type Featurizations = Featurization[];
export declare const Featurizations: any;
export interface FeaturizationConfig {
    ForecastFrequency: string;
    ForecastDimensions?: string[];
    Featurizations?: Featurization[];
}
export declare const FeaturizationConfig: S.Schema<FeaturizationConfig>;
export interface CreatePredictorRequest {
    PredictorName: string;
    AlgorithmArn?: string;
    ForecastHorizon: number;
    ForecastTypes?: string[];
    PerformAutoML?: boolean;
    AutoMLOverrideStrategy?: AutoMLOverrideStrategy;
    PerformHPO?: boolean;
    TrainingParameters?: {
        [key: string]: string | undefined;
    };
    EvaluationParameters?: EvaluationParameters;
    HPOConfig?: HyperParameterTuningJobConfig;
    InputDataConfig: InputDataConfig;
    FeaturizationConfig: FeaturizationConfig;
    EncryptionConfig?: EncryptionConfig;
    Tags?: Tag[];
    OptimizationMetric?: OptimizationMetric;
}
export declare const CreatePredictorRequest: S.Schema<CreatePredictorRequest>;
export interface CreatePredictorResponse {
    PredictorArn?: string;
}
export declare const CreatePredictorResponse: S.Schema<CreatePredictorResponse>;
export interface CreatePredictorBacktestExportJobRequest {
    PredictorBacktestExportJobName: string;
    PredictorArn: string;
    Destination: DataDestination;
    Tags?: Tag[];
    Format?: string;
}
export declare const CreatePredictorBacktestExportJobRequest: S.Schema<CreatePredictorBacktestExportJobRequest>;
export interface CreatePredictorBacktestExportJobResponse {
    PredictorBacktestExportJobArn?: string;
}
export declare const CreatePredictorBacktestExportJobResponse: S.Schema<CreatePredictorBacktestExportJobResponse>;
export interface CreateWhatIfAnalysisRequest {
    WhatIfAnalysisName: string;
    ForecastArn: string;
    TimeSeriesSelector?: TimeSeriesSelector;
    Tags?: Tag[];
}
export declare const CreateWhatIfAnalysisRequest: S.Schema<CreateWhatIfAnalysisRequest>;
export interface CreateWhatIfAnalysisResponse {
    WhatIfAnalysisArn?: string;
}
export declare const CreateWhatIfAnalysisResponse: S.Schema<CreateWhatIfAnalysisResponse>;
export type Operation = "ADD" | "SUBTRACT" | "MULTIPLY" | "DIVIDE" | (string & {});
export declare const Operation: any;
export interface Action {
    AttributeName: string;
    Operation: Operation;
    Value: number;
}
export declare const Action: S.Schema<Action>;
export type AttributeValue = string;
export type Condition = "EQUALS" | "NOT_EQUALS" | "LESS_THAN" | "GREATER_THAN" | (string & {});
export declare const Condition: any;
export interface TimeSeriesCondition {
    AttributeName: string;
    AttributeValue: string;
    Condition: Condition;
}
export declare const TimeSeriesCondition: S.Schema<TimeSeriesCondition>;
export type TimeSeriesConditions = TimeSeriesCondition[];
export declare const TimeSeriesConditions: any;
export interface TimeSeriesTransformation {
    Action?: Action;
    TimeSeriesConditions?: TimeSeriesCondition[];
}
export declare const TimeSeriesTransformation: S.Schema<TimeSeriesTransformation>;
export type TimeSeriesTransformations = TimeSeriesTransformation[];
export declare const TimeSeriesTransformations: any;
export interface TimeSeriesReplacementsDataSource {
    S3Config: S3Config;
    Schema: Schema;
    Format?: string;
    TimestampFormat?: string;
}
export declare const TimeSeriesReplacementsDataSource: S.Schema<TimeSeriesReplacementsDataSource>;
export interface CreateWhatIfForecastRequest {
    WhatIfForecastName: string;
    WhatIfAnalysisArn: string;
    TimeSeriesTransformations?: TimeSeriesTransformation[];
    TimeSeriesReplacementsDataSource?: TimeSeriesReplacementsDataSource;
    Tags?: Tag[];
}
export declare const CreateWhatIfForecastRequest: S.Schema<CreateWhatIfForecastRequest>;
export type LongArn = string;
export interface CreateWhatIfForecastResponse {
    WhatIfForecastArn?: string;
}
export declare const CreateWhatIfForecastResponse: S.Schema<CreateWhatIfForecastResponse>;
export type WhatIfForecastArnListForExport = string[];
export declare const WhatIfForecastArnListForExport: any;
export interface CreateWhatIfForecastExportRequest {
    WhatIfForecastExportName: string;
    WhatIfForecastArns: string[];
    Destination: DataDestination;
    Tags?: Tag[];
    Format?: string;
}
export declare const CreateWhatIfForecastExportRequest: S.Schema<CreateWhatIfForecastExportRequest>;
export interface CreateWhatIfForecastExportResponse {
    WhatIfForecastExportArn?: string;
}
export declare const CreateWhatIfForecastExportResponse: S.Schema<CreateWhatIfForecastExportResponse>;
export interface DeleteDatasetRequest {
    DatasetArn: string;
}
export declare const DeleteDatasetRequest: S.Schema<DeleteDatasetRequest>;
export interface DeleteDatasetResponse {
}
export declare const DeleteDatasetResponse: S.Schema<DeleteDatasetResponse>;
export interface DeleteDatasetGroupRequest {
    DatasetGroupArn: string;
}
export declare const DeleteDatasetGroupRequest: S.Schema<DeleteDatasetGroupRequest>;
export interface DeleteDatasetGroupResponse {
}
export declare const DeleteDatasetGroupResponse: S.Schema<DeleteDatasetGroupResponse>;
export interface DeleteDatasetImportJobRequest {
    DatasetImportJobArn: string;
}
export declare const DeleteDatasetImportJobRequest: S.Schema<DeleteDatasetImportJobRequest>;
export interface DeleteDatasetImportJobResponse {
}
export declare const DeleteDatasetImportJobResponse: S.Schema<DeleteDatasetImportJobResponse>;
export interface DeleteExplainabilityRequest {
    ExplainabilityArn: string;
}
export declare const DeleteExplainabilityRequest: S.Schema<DeleteExplainabilityRequest>;
export interface DeleteExplainabilityResponse {
}
export declare const DeleteExplainabilityResponse: S.Schema<DeleteExplainabilityResponse>;
export interface DeleteExplainabilityExportRequest {
    ExplainabilityExportArn: string;
}
export declare const DeleteExplainabilityExportRequest: S.Schema<DeleteExplainabilityExportRequest>;
export interface DeleteExplainabilityExportResponse {
}
export declare const DeleteExplainabilityExportResponse: S.Schema<DeleteExplainabilityExportResponse>;
export interface DeleteForecastRequest {
    ForecastArn: string;
}
export declare const DeleteForecastRequest: S.Schema<DeleteForecastRequest>;
export interface DeleteForecastResponse {
}
export declare const DeleteForecastResponse: S.Schema<DeleteForecastResponse>;
export interface DeleteForecastExportJobRequest {
    ForecastExportJobArn: string;
}
export declare const DeleteForecastExportJobRequest: S.Schema<DeleteForecastExportJobRequest>;
export interface DeleteForecastExportJobResponse {
}
export declare const DeleteForecastExportJobResponse: S.Schema<DeleteForecastExportJobResponse>;
export interface DeleteMonitorRequest {
    MonitorArn: string;
}
export declare const DeleteMonitorRequest: S.Schema<DeleteMonitorRequest>;
export interface DeleteMonitorResponse {
}
export declare const DeleteMonitorResponse: S.Schema<DeleteMonitorResponse>;
export interface DeletePredictorRequest {
    PredictorArn: string;
}
export declare const DeletePredictorRequest: S.Schema<DeletePredictorRequest>;
export interface DeletePredictorResponse {
}
export declare const DeletePredictorResponse: S.Schema<DeletePredictorResponse>;
export interface DeletePredictorBacktestExportJobRequest {
    PredictorBacktestExportJobArn: string;
}
export declare const DeletePredictorBacktestExportJobRequest: S.Schema<DeletePredictorBacktestExportJobRequest>;
export interface DeletePredictorBacktestExportJobResponse {
}
export declare const DeletePredictorBacktestExportJobResponse: S.Schema<DeletePredictorBacktestExportJobResponse>;
export interface DeleteResourceTreeRequest {
    ResourceArn: string;
}
export declare const DeleteResourceTreeRequest: S.Schema<DeleteResourceTreeRequest>;
export interface DeleteResourceTreeResponse {
}
export declare const DeleteResourceTreeResponse: S.Schema<DeleteResourceTreeResponse>;
export interface DeleteWhatIfAnalysisRequest {
    WhatIfAnalysisArn: string;
}
export declare const DeleteWhatIfAnalysisRequest: S.Schema<DeleteWhatIfAnalysisRequest>;
export interface DeleteWhatIfAnalysisResponse {
}
export declare const DeleteWhatIfAnalysisResponse: S.Schema<DeleteWhatIfAnalysisResponse>;
export interface DeleteWhatIfForecastRequest {
    WhatIfForecastArn: string;
}
export declare const DeleteWhatIfForecastRequest: S.Schema<DeleteWhatIfForecastRequest>;
export interface DeleteWhatIfForecastResponse {
}
export declare const DeleteWhatIfForecastResponse: S.Schema<DeleteWhatIfForecastResponse>;
export interface DeleteWhatIfForecastExportRequest {
    WhatIfForecastExportArn: string;
}
export declare const DeleteWhatIfForecastExportRequest: S.Schema<DeleteWhatIfForecastExportRequest>;
export interface DeleteWhatIfForecastExportResponse {
}
export declare const DeleteWhatIfForecastExportResponse: S.Schema<DeleteWhatIfForecastExportResponse>;
export interface DescribeAutoPredictorRequest {
    PredictorArn: string;
}
export declare const DescribeAutoPredictorRequest: S.Schema<DescribeAutoPredictorRequest>;
export type State = "Active" | "Deleted" | (string & {});
export declare const State: any;
export interface ReferencePredictorSummary {
    Arn?: string;
    State?: State;
}
export declare const ReferencePredictorSummary: S.Schema<ReferencePredictorSummary>;
export type Status = string;
export type Message = string;
export interface ExplainabilityInfo {
    ExplainabilityArn?: string;
    Status?: string;
}
export declare const ExplainabilityInfo: S.Schema<ExplainabilityInfo>;
export interface MonitorInfo {
    MonitorArn?: string;
    Status?: string;
}
export declare const MonitorInfo: S.Schema<MonitorInfo>;
export interface DescribeAutoPredictorResponse {
    PredictorArn?: string;
    PredictorName?: string;
    ForecastHorizon?: number;
    ForecastTypes?: string[];
    ForecastFrequency?: string;
    ForecastDimensions?: string[];
    DatasetImportJobArns?: string[];
    DataConfig?: DataConfig;
    EncryptionConfig?: EncryptionConfig;
    ReferencePredictorSummary?: ReferencePredictorSummary;
    EstimatedTimeRemainingInMinutes?: number;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
    OptimizationMetric?: OptimizationMetric;
    ExplainabilityInfo?: ExplainabilityInfo;
    MonitorInfo?: MonitorInfo;
    TimeAlignmentBoundary?: TimeAlignmentBoundary;
}
export declare const DescribeAutoPredictorResponse: S.Schema<DescribeAutoPredictorResponse>;
export interface DescribeDatasetRequest {
    DatasetArn: string;
}
export declare const DescribeDatasetRequest: S.Schema<DescribeDatasetRequest>;
export interface DescribeDatasetResponse {
    DatasetArn?: string;
    DatasetName?: string;
    Domain?: Domain;
    DatasetType?: DatasetType;
    DataFrequency?: string;
    Schema?: Schema;
    EncryptionConfig?: EncryptionConfig;
    Status?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const DescribeDatasetResponse: S.Schema<DescribeDatasetResponse>;
export interface DescribeDatasetGroupRequest {
    DatasetGroupArn: string;
}
export declare const DescribeDatasetGroupRequest: S.Schema<DescribeDatasetGroupRequest>;
export interface DescribeDatasetGroupResponse {
    DatasetGroupName?: string;
    DatasetGroupArn?: string;
    DatasetArns?: string[];
    Domain?: Domain;
    Status?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const DescribeDatasetGroupResponse: S.Schema<DescribeDatasetGroupResponse>;
export interface DescribeDatasetImportJobRequest {
    DatasetImportJobArn: string;
}
export declare const DescribeDatasetImportJobRequest: S.Schema<DescribeDatasetImportJobRequest>;
export interface Statistics {
    Count?: number;
    CountDistinct?: number;
    CountNull?: number;
    CountNan?: number;
    Min?: string;
    Max?: string;
    Avg?: number;
    Stddev?: number;
    CountLong?: number;
    CountDistinctLong?: number;
    CountNullLong?: number;
    CountNanLong?: number;
}
export declare const Statistics: S.Schema<Statistics>;
export type FieldStatistics = {
    [key: string]: Statistics | undefined;
};
export declare const FieldStatistics: any;
export interface DescribeDatasetImportJobResponse {
    DatasetImportJobName?: string;
    DatasetImportJobArn?: string;
    DatasetArn?: string;
    TimestampFormat?: string;
    TimeZone?: string;
    UseGeolocationForTimeZone?: boolean;
    GeolocationFormat?: string;
    DataSource?: DataSource;
    EstimatedTimeRemainingInMinutes?: number;
    FieldStatistics?: {
        [key: string]: Statistics | undefined;
    };
    DataSize?: number;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
    Format?: string;
    ImportMode?: ImportMode;
}
export declare const DescribeDatasetImportJobResponse: S.Schema<DescribeDatasetImportJobResponse>;
export interface DescribeExplainabilityRequest {
    ExplainabilityArn: string;
}
export declare const DescribeExplainabilityRequest: S.Schema<DescribeExplainabilityRequest>;
export interface DescribeExplainabilityResponse {
    ExplainabilityArn?: string;
    ExplainabilityName?: string;
    ResourceArn?: string;
    ExplainabilityConfig?: ExplainabilityConfig;
    EnableVisualization?: boolean;
    DataSource?: DataSource;
    Schema?: Schema;
    StartDateTime?: string;
    EndDateTime?: string;
    EstimatedTimeRemainingInMinutes?: number;
    Message?: string;
    Status?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const DescribeExplainabilityResponse: S.Schema<DescribeExplainabilityResponse>;
export interface DescribeExplainabilityExportRequest {
    ExplainabilityExportArn: string;
}
export declare const DescribeExplainabilityExportRequest: S.Schema<DescribeExplainabilityExportRequest>;
export interface DescribeExplainabilityExportResponse {
    ExplainabilityExportArn?: string;
    ExplainabilityExportName?: string;
    ExplainabilityArn?: string;
    Destination?: DataDestination;
    Message?: string;
    Status?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
    Format?: string;
}
export declare const DescribeExplainabilityExportResponse: S.Schema<DescribeExplainabilityExportResponse>;
export interface DescribeForecastRequest {
    ForecastArn: string;
}
export declare const DescribeForecastRequest: S.Schema<DescribeForecastRequest>;
export type ErrorMessage = string;
export interface DescribeForecastResponse {
    ForecastArn?: string;
    ForecastName?: string;
    ForecastTypes?: string[];
    PredictorArn?: string;
    DatasetGroupArn?: string;
    EstimatedTimeRemainingInMinutes?: number;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
    TimeSeriesSelector?: TimeSeriesSelector;
}
export declare const DescribeForecastResponse: S.Schema<DescribeForecastResponse>;
export interface DescribeForecastExportJobRequest {
    ForecastExportJobArn: string;
}
export declare const DescribeForecastExportJobRequest: S.Schema<DescribeForecastExportJobRequest>;
export interface DescribeForecastExportJobResponse {
    ForecastExportJobArn?: string;
    ForecastExportJobName?: string;
    ForecastArn?: string;
    Destination?: DataDestination;
    Message?: string;
    Status?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
    Format?: string;
}
export declare const DescribeForecastExportJobResponse: S.Schema<DescribeForecastExportJobResponse>;
export interface DescribeMonitorRequest {
    MonitorArn: string;
}
export declare const DescribeMonitorRequest: S.Schema<DescribeMonitorRequest>;
export type EvaluationState = string;
export interface BaselineMetric {
    Name?: string;
    Value?: number;
}
export declare const BaselineMetric: S.Schema<BaselineMetric>;
export type BaselineMetrics = BaselineMetric[];
export declare const BaselineMetrics: any;
export interface PredictorBaseline {
    BaselineMetrics?: BaselineMetric[];
}
export declare const PredictorBaseline: S.Schema<PredictorBaseline>;
export interface Baseline {
    PredictorBaseline?: PredictorBaseline;
}
export declare const Baseline: S.Schema<Baseline>;
export interface DescribeMonitorResponse {
    MonitorName?: string;
    MonitorArn?: string;
    ResourceArn?: string;
    Status?: string;
    LastEvaluationTime?: Date;
    LastEvaluationState?: string;
    Baseline?: Baseline;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
    EstimatedEvaluationTimeRemainingInMinutes?: number;
}
export declare const DescribeMonitorResponse: S.Schema<DescribeMonitorResponse>;
export interface DescribePredictorRequest {
    PredictorArn: string;
}
export declare const DescribePredictorRequest: S.Schema<DescribePredictorRequest>;
export interface TestWindowSummary {
    TestWindowStart?: Date;
    TestWindowEnd?: Date;
    Status?: string;
    Message?: string;
}
export declare const TestWindowSummary: S.Schema<TestWindowSummary>;
export type TestWindowDetails = TestWindowSummary[];
export declare const TestWindowDetails: any;
export interface PredictorExecution {
    AlgorithmArn?: string;
    TestWindows?: TestWindowSummary[];
}
export declare const PredictorExecution: S.Schema<PredictorExecution>;
export type PredictorExecutions = PredictorExecution[];
export declare const PredictorExecutions: any;
export interface PredictorExecutionDetails {
    PredictorExecutions?: PredictorExecution[];
}
export declare const PredictorExecutionDetails: S.Schema<PredictorExecutionDetails>;
export interface DescribePredictorResponse {
    PredictorArn?: string;
    PredictorName?: string;
    AlgorithmArn?: string;
    AutoMLAlgorithmArns?: string[];
    ForecastHorizon?: number;
    ForecastTypes?: string[];
    PerformAutoML?: boolean;
    AutoMLOverrideStrategy?: AutoMLOverrideStrategy;
    PerformHPO?: boolean;
    TrainingParameters?: {
        [key: string]: string | undefined;
    };
    EvaluationParameters?: EvaluationParameters;
    HPOConfig?: HyperParameterTuningJobConfig;
    InputDataConfig?: InputDataConfig;
    FeaturizationConfig?: FeaturizationConfig;
    EncryptionConfig?: EncryptionConfig;
    PredictorExecutionDetails?: PredictorExecutionDetails;
    EstimatedTimeRemainingInMinutes?: number;
    IsAutoPredictor?: boolean;
    DatasetImportJobArns?: string[];
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
    OptimizationMetric?: OptimizationMetric;
}
export declare const DescribePredictorResponse: S.Schema<DescribePredictorResponse>;
export interface DescribePredictorBacktestExportJobRequest {
    PredictorBacktestExportJobArn: string;
}
export declare const DescribePredictorBacktestExportJobRequest: S.Schema<DescribePredictorBacktestExportJobRequest>;
export interface DescribePredictorBacktestExportJobResponse {
    PredictorBacktestExportJobArn?: string;
    PredictorBacktestExportJobName?: string;
    PredictorArn?: string;
    Destination?: DataDestination;
    Message?: string;
    Status?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
    Format?: string;
}
export declare const DescribePredictorBacktestExportJobResponse: S.Schema<DescribePredictorBacktestExportJobResponse>;
export interface DescribeWhatIfAnalysisRequest {
    WhatIfAnalysisArn: string;
}
export declare const DescribeWhatIfAnalysisRequest: S.Schema<DescribeWhatIfAnalysisRequest>;
export interface DescribeWhatIfAnalysisResponse {
    WhatIfAnalysisName?: string;
    WhatIfAnalysisArn?: string;
    ForecastArn?: string;
    EstimatedTimeRemainingInMinutes?: number;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
    TimeSeriesSelector?: TimeSeriesSelector;
}
export declare const DescribeWhatIfAnalysisResponse: S.Schema<DescribeWhatIfAnalysisResponse>;
export interface DescribeWhatIfForecastRequest {
    WhatIfForecastArn: string;
}
export declare const DescribeWhatIfForecastRequest: S.Schema<DescribeWhatIfForecastRequest>;
export interface DescribeWhatIfForecastResponse {
    WhatIfForecastName?: string;
    WhatIfForecastArn?: string;
    WhatIfAnalysisArn?: string;
    EstimatedTimeRemainingInMinutes?: number;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
    TimeSeriesTransformations?: TimeSeriesTransformation[];
    TimeSeriesReplacementsDataSource?: TimeSeriesReplacementsDataSource;
    ForecastTypes?: string[];
}
export declare const DescribeWhatIfForecastResponse: S.Schema<DescribeWhatIfForecastResponse>;
export interface DescribeWhatIfForecastExportRequest {
    WhatIfForecastExportArn: string;
}
export declare const DescribeWhatIfForecastExportRequest: S.Schema<DescribeWhatIfForecastExportRequest>;
export type LongArnList = string[];
export declare const LongArnList: any;
export interface DescribeWhatIfForecastExportResponse {
    WhatIfForecastExportArn?: string;
    WhatIfForecastExportName?: string;
    WhatIfForecastArns?: string[];
    Destination?: DataDestination;
    Message?: string;
    Status?: string;
    CreationTime?: Date;
    EstimatedTimeRemainingInMinutes?: number;
    LastModificationTime?: Date;
    Format?: string;
}
export declare const DescribeWhatIfForecastExportResponse: S.Schema<DescribeWhatIfForecastExportResponse>;
export interface GetAccuracyMetricsRequest {
    PredictorArn: string;
}
export declare const GetAccuracyMetricsRequest: S.Schema<GetAccuracyMetricsRequest>;
export type EvaluationType = "SUMMARY" | "COMPUTED" | (string & {});
export declare const EvaluationType: any;
export interface WeightedQuantileLoss {
    Quantile?: number;
    LossValue?: number;
}
export declare const WeightedQuantileLoss: S.Schema<WeightedQuantileLoss>;
export type WeightedQuantileLosses = WeightedQuantileLoss[];
export declare const WeightedQuantileLosses: any;
export interface ErrorMetric {
    ForecastType?: string;
    WAPE?: number;
    RMSE?: number;
    MASE?: number;
    MAPE?: number;
}
export declare const ErrorMetric: S.Schema<ErrorMetric>;
export type ErrorMetrics = ErrorMetric[];
export declare const ErrorMetrics: any;
export interface Metrics {
    RMSE?: number;
    WeightedQuantileLosses?: WeightedQuantileLoss[];
    ErrorMetrics?: ErrorMetric[];
    AverageWeightedQuantileLoss?: number;
}
export declare const Metrics: S.Schema<Metrics>;
export interface WindowSummary {
    TestWindowStart?: Date;
    TestWindowEnd?: Date;
    ItemCount?: number;
    EvaluationType?: EvaluationType;
    Metrics?: Metrics;
}
export declare const WindowSummary: S.Schema<WindowSummary>;
export type TestWindows = WindowSummary[];
export declare const TestWindows: any;
export interface EvaluationResult {
    AlgorithmArn?: string;
    TestWindows?: WindowSummary[];
}
export declare const EvaluationResult: S.Schema<EvaluationResult>;
export type PredictorEvaluationResults = EvaluationResult[];
export declare const PredictorEvaluationResults: any;
export interface GetAccuracyMetricsResponse {
    PredictorEvaluationResults?: EvaluationResult[];
    IsAutoPredictor?: boolean;
    AutoMLOverrideStrategy?: AutoMLOverrideStrategy;
    OptimizationMetric?: OptimizationMetric;
}
export declare const GetAccuracyMetricsResponse: S.Schema<GetAccuracyMetricsResponse>;
export type NextToken = string;
export type MaxResults = number;
export interface ListDatasetGroupsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDatasetGroupsRequest: S.Schema<ListDatasetGroupsRequest>;
export interface DatasetGroupSummary {
    DatasetGroupArn?: string;
    DatasetGroupName?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const DatasetGroupSummary: S.Schema<DatasetGroupSummary>;
export type DatasetGroups = DatasetGroupSummary[];
export declare const DatasetGroups: any;
export interface ListDatasetGroupsResponse {
    DatasetGroups?: DatasetGroupSummary[];
    NextToken?: string;
}
export declare const ListDatasetGroupsResponse: S.Schema<ListDatasetGroupsResponse>;
export type FilterConditionString = "IS" | "IS_NOT" | (string & {});
export declare const FilterConditionString: any;
export interface Filter {
    Key: string;
    Value: string;
    Condition: FilterConditionString;
}
export declare const Filter: S.Schema<Filter>;
export type Filters = Filter[];
export declare const Filters: any;
export interface ListDatasetImportJobsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filters?: Filter[];
}
export declare const ListDatasetImportJobsRequest: S.Schema<ListDatasetImportJobsRequest>;
export interface DatasetImportJobSummary {
    DatasetImportJobArn?: string;
    DatasetImportJobName?: string;
    DataSource?: DataSource;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
    ImportMode?: ImportMode;
}
export declare const DatasetImportJobSummary: S.Schema<DatasetImportJobSummary>;
export type DatasetImportJobs = DatasetImportJobSummary[];
export declare const DatasetImportJobs: any;
export interface ListDatasetImportJobsResponse {
    DatasetImportJobs?: DatasetImportJobSummary[];
    NextToken?: string;
}
export declare const ListDatasetImportJobsResponse: S.Schema<ListDatasetImportJobsResponse>;
export interface ListDatasetsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDatasetsRequest: S.Schema<ListDatasetsRequest>;
export interface DatasetSummary {
    DatasetArn?: string;
    DatasetName?: string;
    DatasetType?: DatasetType;
    Domain?: Domain;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const DatasetSummary: S.Schema<DatasetSummary>;
export type Datasets = DatasetSummary[];
export declare const Datasets: any;
export interface ListDatasetsResponse {
    Datasets?: DatasetSummary[];
    NextToken?: string;
}
export declare const ListDatasetsResponse: S.Schema<ListDatasetsResponse>;
export interface ListExplainabilitiesRequest {
    NextToken?: string;
    MaxResults?: number;
    Filters?: Filter[];
}
export declare const ListExplainabilitiesRequest: S.Schema<ListExplainabilitiesRequest>;
export interface ExplainabilitySummary {
    ExplainabilityArn?: string;
    ExplainabilityName?: string;
    ResourceArn?: string;
    ExplainabilityConfig?: ExplainabilityConfig;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const ExplainabilitySummary: S.Schema<ExplainabilitySummary>;
export type Explainabilities = ExplainabilitySummary[];
export declare const Explainabilities: any;
export interface ListExplainabilitiesResponse {
    Explainabilities?: ExplainabilitySummary[];
    NextToken?: string;
}
export declare const ListExplainabilitiesResponse: S.Schema<ListExplainabilitiesResponse>;
export interface ListExplainabilityExportsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filters?: Filter[];
}
export declare const ListExplainabilityExportsRequest: S.Schema<ListExplainabilityExportsRequest>;
export interface ExplainabilityExportSummary {
    ExplainabilityExportArn?: string;
    ExplainabilityExportName?: string;
    Destination?: DataDestination;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const ExplainabilityExportSummary: S.Schema<ExplainabilityExportSummary>;
export type ExplainabilityExports = ExplainabilityExportSummary[];
export declare const ExplainabilityExports: any;
export interface ListExplainabilityExportsResponse {
    ExplainabilityExports?: ExplainabilityExportSummary[];
    NextToken?: string;
}
export declare const ListExplainabilityExportsResponse: S.Schema<ListExplainabilityExportsResponse>;
export interface ListForecastExportJobsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filters?: Filter[];
}
export declare const ListForecastExportJobsRequest: S.Schema<ListForecastExportJobsRequest>;
export interface ForecastExportJobSummary {
    ForecastExportJobArn?: string;
    ForecastExportJobName?: string;
    Destination?: DataDestination;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const ForecastExportJobSummary: S.Schema<ForecastExportJobSummary>;
export type ForecastExportJobs = ForecastExportJobSummary[];
export declare const ForecastExportJobs: any;
export interface ListForecastExportJobsResponse {
    ForecastExportJobs?: ForecastExportJobSummary[];
    NextToken?: string;
}
export declare const ListForecastExportJobsResponse: S.Schema<ListForecastExportJobsResponse>;
export interface ListForecastsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filters?: Filter[];
}
export declare const ListForecastsRequest: S.Schema<ListForecastsRequest>;
export interface ForecastSummary {
    ForecastArn?: string;
    ForecastName?: string;
    PredictorArn?: string;
    CreatedUsingAutoPredictor?: boolean;
    DatasetGroupArn?: string;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const ForecastSummary: S.Schema<ForecastSummary>;
export type Forecasts = ForecastSummary[];
export declare const Forecasts: any;
export interface ListForecastsResponse {
    Forecasts?: ForecastSummary[];
    NextToken?: string;
}
export declare const ListForecastsResponse: S.Schema<ListForecastsResponse>;
export interface ListMonitorEvaluationsRequest {
    NextToken?: string;
    MaxResults?: number;
    MonitorArn: string;
    Filters?: Filter[];
}
export declare const ListMonitorEvaluationsRequest: S.Schema<ListMonitorEvaluationsRequest>;
export type Detail = string;
export interface PredictorEvent {
    Detail?: string;
    Datetime?: Date;
}
export declare const PredictorEvent: S.Schema<PredictorEvent>;
export interface MonitorDataSource {
    DatasetImportJobArn?: string;
    ForecastArn?: string;
    PredictorArn?: string;
}
export declare const MonitorDataSource: S.Schema<MonitorDataSource>;
export type MetricName = string;
export interface MetricResult {
    MetricName?: string;
    MetricValue?: number;
}
export declare const MetricResult: S.Schema<MetricResult>;
export type MetricResults = MetricResult[];
export declare const MetricResults: any;
export interface PredictorMonitorEvaluation {
    ResourceArn?: string;
    MonitorArn?: string;
    EvaluationTime?: Date;
    EvaluationState?: string;
    WindowStartDatetime?: Date;
    WindowEndDatetime?: Date;
    PredictorEvent?: PredictorEvent;
    MonitorDataSource?: MonitorDataSource;
    MetricResults?: MetricResult[];
    NumItemsEvaluated?: number;
    Message?: string;
}
export declare const PredictorMonitorEvaluation: S.Schema<PredictorMonitorEvaluation>;
export type PredictorMonitorEvaluations = PredictorMonitorEvaluation[];
export declare const PredictorMonitorEvaluations: any;
export interface ListMonitorEvaluationsResponse {
    NextToken?: string;
    PredictorMonitorEvaluations?: PredictorMonitorEvaluation[];
}
export declare const ListMonitorEvaluationsResponse: S.Schema<ListMonitorEvaluationsResponse>;
export interface ListMonitorsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filters?: Filter[];
}
export declare const ListMonitorsRequest: S.Schema<ListMonitorsRequest>;
export interface MonitorSummary {
    MonitorArn?: string;
    MonitorName?: string;
    ResourceArn?: string;
    Status?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const MonitorSummary: S.Schema<MonitorSummary>;
export type Monitors = MonitorSummary[];
export declare const Monitors: any;
export interface ListMonitorsResponse {
    Monitors?: MonitorSummary[];
    NextToken?: string;
}
export declare const ListMonitorsResponse: S.Schema<ListMonitorsResponse>;
export interface ListPredictorBacktestExportJobsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filters?: Filter[];
}
export declare const ListPredictorBacktestExportJobsRequest: S.Schema<ListPredictorBacktestExportJobsRequest>;
export interface PredictorBacktestExportJobSummary {
    PredictorBacktestExportJobArn?: string;
    PredictorBacktestExportJobName?: string;
    Destination?: DataDestination;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const PredictorBacktestExportJobSummary: S.Schema<PredictorBacktestExportJobSummary>;
export type PredictorBacktestExportJobs = PredictorBacktestExportJobSummary[];
export declare const PredictorBacktestExportJobs: any;
export interface ListPredictorBacktestExportJobsResponse {
    PredictorBacktestExportJobs?: PredictorBacktestExportJobSummary[];
    NextToken?: string;
}
export declare const ListPredictorBacktestExportJobsResponse: S.Schema<ListPredictorBacktestExportJobsResponse>;
export interface ListPredictorsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filters?: Filter[];
}
export declare const ListPredictorsRequest: S.Schema<ListPredictorsRequest>;
export interface PredictorSummary {
    PredictorArn?: string;
    PredictorName?: string;
    DatasetGroupArn?: string;
    IsAutoPredictor?: boolean;
    ReferencePredictorSummary?: ReferencePredictorSummary;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const PredictorSummary: S.Schema<PredictorSummary>;
export type Predictors = PredictorSummary[];
export declare const Predictors: any;
export interface ListPredictorsResponse {
    Predictors?: PredictorSummary[];
    NextToken?: string;
}
export declare const ListPredictorsResponse: S.Schema<ListPredictorsResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListWhatIfAnalysesRequest {
    NextToken?: string;
    MaxResults?: number;
    Filters?: Filter[];
}
export declare const ListWhatIfAnalysesRequest: S.Schema<ListWhatIfAnalysesRequest>;
export interface WhatIfAnalysisSummary {
    WhatIfAnalysisArn?: string;
    WhatIfAnalysisName?: string;
    ForecastArn?: string;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const WhatIfAnalysisSummary: S.Schema<WhatIfAnalysisSummary>;
export type WhatIfAnalyses = WhatIfAnalysisSummary[];
export declare const WhatIfAnalyses: any;
export interface ListWhatIfAnalysesResponse {
    WhatIfAnalyses?: WhatIfAnalysisSummary[];
    NextToken?: string;
}
export declare const ListWhatIfAnalysesResponse: S.Schema<ListWhatIfAnalysesResponse>;
export interface ListWhatIfForecastExportsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filters?: Filter[];
}
export declare const ListWhatIfForecastExportsRequest: S.Schema<ListWhatIfForecastExportsRequest>;
export interface WhatIfForecastExportSummary {
    WhatIfForecastExportArn?: string;
    WhatIfForecastArns?: string[];
    WhatIfForecastExportName?: string;
    Destination?: DataDestination;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const WhatIfForecastExportSummary: S.Schema<WhatIfForecastExportSummary>;
export type WhatIfForecastExports = WhatIfForecastExportSummary[];
export declare const WhatIfForecastExports: any;
export interface ListWhatIfForecastExportsResponse {
    WhatIfForecastExports?: WhatIfForecastExportSummary[];
    NextToken?: string;
}
export declare const ListWhatIfForecastExportsResponse: S.Schema<ListWhatIfForecastExportsResponse>;
export interface ListWhatIfForecastsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filters?: Filter[];
}
export declare const ListWhatIfForecastsRequest: S.Schema<ListWhatIfForecastsRequest>;
export interface WhatIfForecastSummary {
    WhatIfForecastArn?: string;
    WhatIfForecastName?: string;
    WhatIfAnalysisArn?: string;
    Status?: string;
    Message?: string;
    CreationTime?: Date;
    LastModificationTime?: Date;
}
export declare const WhatIfForecastSummary: S.Schema<WhatIfForecastSummary>;
export type WhatIfForecasts = WhatIfForecastSummary[];
export declare const WhatIfForecasts: any;
export interface ListWhatIfForecastsResponse {
    WhatIfForecasts?: WhatIfForecastSummary[];
    NextToken?: string;
}
export declare const ListWhatIfForecastsResponse: S.Schema<ListWhatIfForecastsResponse>;
export interface ResumeResourceRequest {
    ResourceArn: string;
}
export declare const ResumeResourceRequest: S.Schema<ResumeResourceRequest>;
export interface ResumeResourceResponse {
}
export declare const ResumeResourceResponse: S.Schema<ResumeResourceResponse>;
export interface StopResourceRequest {
    ResourceArn: string;
}
export declare const StopResourceRequest: S.Schema<StopResourceRequest>;
export interface StopResourceResponse {
}
export declare const StopResourceResponse: S.Schema<StopResourceResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = (string | redacted.Redacted<string>)[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: (string | redacted.Redacted<string>)[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateDatasetGroupRequest {
    DatasetGroupArn: string;
    DatasetArns: string[];
}
export declare const UpdateDatasetGroupRequest: S.Schema<UpdateDatasetGroupRequest>;
export interface UpdateDatasetGroupResponse {
}
export declare const UpdateDatasetGroupResponse: S.Schema<UpdateDatasetGroupResponse>;
export type CreateAutoPredictorError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an Amazon Forecast predictor.
 *
 * Amazon Forecast creates predictors with AutoPredictor, which involves applying the
 * optimal combination of algorithms to each time series in your datasets. You can use
 * CreateAutoPredictor to create new predictors or upgrade/retrain
 * existing predictors.
 *
 * **Creating new predictors**
 *
 * The following parameters are required when creating a new predictor:
 *
 * - `PredictorName` - A unique name for the predictor.
 *
 * - `DatasetGroupArn` - The ARN of the dataset group used to train the
 * predictor.
 *
 * - `ForecastFrequency` - The granularity of your forecasts (hourly,
 * daily, weekly, etc).
 *
 * - `ForecastHorizon` - The number of time-steps that the model
 * predicts. The forecast horizon is also called the prediction length.
 *
 * When creating a new predictor, do not specify a value for
 * `ReferencePredictorArn`.
 *
 * **Upgrading and retraining predictors**
 *
 * The following parameters are required when retraining or upgrading a predictor:
 *
 * - `PredictorName` - A unique name for the predictor.
 *
 * - `ReferencePredictorArn` - The ARN of the predictor to retrain or
 * upgrade.
 *
 * When upgrading or retraining a predictor, only specify values for the
 * `ReferencePredictorArn` and `PredictorName`.
 */
export declare const createAutoPredictor: API.OperationMethod<CreateAutoPredictorRequest, CreateAutoPredictorResponse, CreateAutoPredictorError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates an Amazon Forecast dataset. The information about the dataset that you provide helps
 * Forecast understand how to consume the data for model training. This includes the
 * following:
 *
 * -
 * `DataFrequency`
 * - How frequently your historical
 * time-series data is collected.
 *
 * -
 * `Domain`
 * and
 *
 * `DatasetType`
 * - Each dataset has an associated dataset
 * domain and a type within the domain. Amazon Forecast provides a list of predefined domains and
 * types within each domain. For each unique dataset domain and type within the domain,
 * Amazon Forecast requires your data to include a minimum set of predefined fields.
 *
 * -
 * `Schema`
 * - A schema specifies the fields in the dataset,
 * including the field name and data type.
 *
 * After creating a dataset, you import your training data into it and add the dataset to a
 * dataset group. You use the dataset group to create a predictor. For more information, see
 * Importing datasets.
 *
 * To get a list of all your datasets, use the ListDatasets operation.
 *
 * For example Forecast datasets, see the Amazon Forecast Sample GitHub
 * repository.
 *
 * The `Status` of a dataset must be `ACTIVE` before you can import
 * training data. Use the DescribeDataset operation to get
 * the status.
 */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest, CreateDatasetResponse, CreateDatasetError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetGroupError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a dataset group, which holds a collection of related datasets. You can add
 * datasets to the dataset group when you create the dataset group, or later by using the UpdateDatasetGroup operation.
 *
 * After creating a dataset group and adding datasets, you use the dataset group when you
 * create a predictor. For more information, see Dataset groups.
 *
 * To get a list of all your datasets groups, use the ListDatasetGroups
 * operation.
 *
 * The `Status` of a dataset group must be `ACTIVE` before you can
 * use the dataset group to create a predictor. To get the status, use the DescribeDatasetGroup operation.
 */
export declare const createDatasetGroup: API.OperationMethod<CreateDatasetGroupRequest, CreateDatasetGroupResponse, CreateDatasetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetImportJobError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Imports your training data to an Amazon Forecast dataset. You provide the location of your
 * training data in an Amazon Simple Storage Service (Amazon S3) bucket and the Amazon Resource Name (ARN) of the dataset
 * that you want to import the data to.
 *
 * You must specify a DataSource object that includes an
 * Identity and Access Management (IAM) role that Amazon Forecast can assume to access the data, as Amazon Forecast makes a copy
 * of your data and processes it in an internal Amazon Web Services system. For more information, see Set up
 * permissions.
 *
 * The training data must be in CSV or Parquet format. The delimiter must be a comma (,).
 *
 * You can specify the path to a specific file, the S3 bucket, or to a folder in the S3
 * bucket. For the latter two cases, Amazon Forecast imports all files up to the limit of 10,000
 * files.
 *
 * Because dataset imports are not aggregated, your most recent dataset import is the one
 * that is used when training a predictor or generating a forecast. Make sure that your most
 * recent dataset import contains all of the data you want to model off of, and not just the new
 * data collected since the previous import.
 *
 * To get a list of all your dataset import jobs, filtered by specified criteria, use the
 * ListDatasetImportJobs operation.
 */
export declare const createDatasetImportJob: API.OperationMethod<CreateDatasetImportJobRequest, CreateDatasetImportJobResponse, CreateDatasetImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateExplainabilityError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Explainability is only available for Forecasts and Predictors generated from an
 * AutoPredictor (CreateAutoPredictor)
 *
 * Creates an Amazon Forecast Explainability.
 *
 * Explainability helps you better understand how the attributes in your datasets impact
 * forecast. Amazon Forecast uses a metric called Impact scores to quantify the relative
 * impact of each attribute and determine whether they increase or decrease forecast
 * values.
 *
 * To enable Forecast Explainability, your predictor must include at least one of the
 * following: related time series, item metadata, or additional datasets like Holidays and
 * the Weather Index.
 *
 * CreateExplainability accepts either a Predictor ARN or Forecast ARN. To receive
 * aggregated Impact scores for all time series and time points in your datasets, provide a
 * Predictor ARN. To receive Impact scores for specific time series and time points,
 * provide a Forecast ARN.
 *
 * **CreateExplainability with a Predictor ARN**
 *
 * You can only have one Explainability resource per predictor. If you already
 * enabled `ExplainPredictor` in CreateAutoPredictor, that
 * predictor already has an Explainability resource.
 *
 * The following parameters are required when providing a Predictor ARN:
 *
 * - `ExplainabilityName` - A unique name for the Explainability.
 *
 * - `ResourceArn` - The Arn of the predictor.
 *
 * - `TimePointGranularity` - Must be set to “ALL”.
 *
 * - `TimeSeriesGranularity` - Must be set to “ALL”.
 *
 * Do not specify a value for the following parameters:
 *
 * - `DataSource` - Only valid when TimeSeriesGranularity is
 * “SPECIFIC”.
 *
 * - `Schema` - Only valid when TimeSeriesGranularity is
 * “SPECIFIC”.
 *
 * - `StartDateTime` - Only valid when TimePointGranularity is
 * “SPECIFIC”.
 *
 * - `EndDateTime` - Only valid when TimePointGranularity is
 * “SPECIFIC”.
 *
 * **CreateExplainability with a Forecast ARN**
 *
 * You can specify a maximum of 50 time series and 500 time points.
 *
 * The following parameters are required when providing a Predictor ARN:
 *
 * - `ExplainabilityName` - A unique name for the Explainability.
 *
 * - `ResourceArn` - The Arn of the forecast.
 *
 * - `TimePointGranularity` - Either “ALL” or “SPECIFIC”.
 *
 * - `TimeSeriesGranularity` - Either “ALL” or “SPECIFIC”.
 *
 * If you set TimeSeriesGranularity to “SPECIFIC”, you must also provide the
 * following:
 *
 * - `DataSource` - The S3 location of the CSV file specifying your time
 * series.
 *
 * - `Schema` - The Schema defines the attributes and attribute types
 * listed in the Data Source.
 *
 * If you set TimePointGranularity to “SPECIFIC”, you must also provide the
 * following:
 *
 * - `StartDateTime` - The first timestamp in the range of time
 * points.
 *
 * - `EndDateTime` - The last timestamp in the range of time
 * points.
 */
export declare const createExplainability: API.OperationMethod<CreateExplainabilityRequest, CreateExplainabilityResponse, CreateExplainabilityError, Credentials | HttpClient.HttpClient>;
export type CreateExplainabilityExportError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Exports an Explainability resource created by the CreateExplainability operation. Exported files are exported to an Amazon Simple Storage Service (Amazon
 * S3) bucket.
 *
 * You must specify a DataDestination object that includes an Amazon S3
 * bucket and an Identity and Access Management (IAM) role that Amazon Forecast can assume to access the Amazon S3
 * bucket. For more information, see aws-forecast-iam-roles.
 *
 * The `Status` of the export job must be `ACTIVE` before you
 * can access the export in your Amazon S3 bucket. To get the status, use the DescribeExplainabilityExport operation.
 */
export declare const createExplainabilityExport: API.OperationMethod<CreateExplainabilityExportRequest, CreateExplainabilityExportResponse, CreateExplainabilityExportError, Credentials | HttpClient.HttpClient>;
export type CreateForecastError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a forecast for each item in the `TARGET_TIME_SERIES` dataset that was
 * used to train the predictor. This is known as inference. To retrieve the forecast for a single
 * item at low latency, use the operation. To
 * export the complete forecast into your Amazon Simple Storage Service (Amazon S3) bucket, use the CreateForecastExportJob operation.
 *
 * The range of the forecast is determined by the `ForecastHorizon` value, which
 * you specify in the CreatePredictor request. When you query a forecast, you
 * can request a specific date range within the forecast.
 *
 * To get a list of all your forecasts, use the ListForecasts
 * operation.
 *
 * The forecasts generated by Amazon Forecast are in the same time zone as the dataset that was
 * used to create the predictor.
 *
 * For more information, see howitworks-forecast.
 *
 * The `Status` of the forecast must be `ACTIVE` before you can query
 * or export the forecast. Use the DescribeForecast operation to get the
 * status.
 *
 * By default, a forecast includes predictions for every item (`item_id`) in the dataset group that was used to train the predictor.
 * However, you can use the `TimeSeriesSelector` object to generate a forecast on a subset of time series. Forecast creation is skipped for any time series that you specify that are not in the input dataset. The forecast export file will not contain these time series or their forecasted values.
 */
export declare const createForecast: API.OperationMethod<CreateForecastRequest, CreateForecastResponse, CreateForecastError, Credentials | HttpClient.HttpClient>;
export type CreateForecastExportJobError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Exports a forecast created by the CreateForecast operation to your
 * Amazon Simple Storage Service (Amazon S3) bucket. The forecast file name will match the following conventions:
 *
 * __
 *
 * where the component is in Java SimpleDateFormat
 * (yyyy-MM-ddTHH-mm-ssZ).
 *
 * You must specify a DataDestination object that includes an Identity and Access Management
 * (IAM) role that Amazon Forecast can assume to access the Amazon S3 bucket. For more information, see
 * aws-forecast-iam-roles.
 *
 * For more information, see howitworks-forecast.
 *
 * To get a list of all your forecast export jobs, use the ListForecastExportJobs operation.
 *
 * The `Status` of the forecast export job must be `ACTIVE` before
 * you can access the forecast in your Amazon S3 bucket. To get the status, use the DescribeForecastExportJob operation.
 */
export declare const createForecastExportJob: API.OperationMethod<CreateForecastExportJobRequest, CreateForecastExportJobResponse, CreateForecastExportJobError, Credentials | HttpClient.HttpClient>;
export type CreateMonitorError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a predictor monitor resource for an existing auto predictor. Predictor monitoring allows you to see how your predictor's performance changes over time.
 * For more information, see Predictor Monitoring.
 */
export declare const createMonitor: API.OperationMethod<CreateMonitorRequest, CreateMonitorResponse, CreateMonitorError, Credentials | HttpClient.HttpClient>;
export type CreatePredictorError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * This operation creates a legacy predictor that does not include all the predictor
 * functionalities provided by Amazon Forecast. To create a predictor that is compatible with all
 * aspects of Forecast, use CreateAutoPredictor.
 *
 * Creates an Amazon Forecast predictor.
 *
 * In the request, provide a dataset group and either specify an algorithm or let Amazon Forecast
 * choose an algorithm for you using AutoML. If you specify an algorithm, you also can override
 * algorithm-specific hyperparameters.
 *
 * Amazon Forecast uses the algorithm to train a predictor using the latest version of the datasets
 * in the specified dataset group. You can then generate a forecast using the CreateForecast operation.
 *
 * To see the evaluation metrics, use the GetAccuracyMetrics operation.
 *
 * You can specify a featurization configuration to fill and aggregate the data fields in the
 * `TARGET_TIME_SERIES` dataset to improve model training. For more information, see
 * FeaturizationConfig.
 *
 * For RELATED_TIME_SERIES datasets, `CreatePredictor` verifies that the
 * `DataFrequency` specified when the dataset was created matches the
 * `ForecastFrequency`. TARGET_TIME_SERIES datasets don't have this restriction.
 * Amazon Forecast also verifies the delimiter and timestamp format. For more information, see howitworks-datasets-groups.
 *
 * By default, predictors are trained and evaluated at the 0.1 (P10), 0.5 (P50), and 0.9
 * (P90) quantiles. You can choose custom forecast types to train and evaluate your predictor by
 * setting the `ForecastTypes`.
 *
 * **AutoML**
 *
 * If you want Amazon Forecast to evaluate each algorithm and choose the one that minimizes the
 * `objective function`, set `PerformAutoML` to `true`. The
 * `objective function` is defined as the mean of the weighted losses over the
 * forecast types. By default, these are the p10, p50, and p90 quantile losses. For more
 * information, see EvaluationResult.
 *
 * When AutoML is enabled, the following properties are disallowed:
 *
 * - `AlgorithmArn`
 *
 * - `HPOConfig`
 *
 * - `PerformHPO`
 *
 * - `TrainingParameters`
 *
 * To get a list of all of your predictors, use the ListPredictors
 * operation.
 *
 * Before you can use the predictor to create a forecast, the `Status` of the
 * predictor must be `ACTIVE`, signifying that training has completed. To get the
 * status, use the DescribePredictor operation.
 */
export declare const createPredictor: API.OperationMethod<CreatePredictorRequest, CreatePredictorResponse, CreatePredictorError, Credentials | HttpClient.HttpClient>;
export type CreatePredictorBacktestExportJobError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Exports backtest forecasts and accuracy metrics generated by the CreateAutoPredictor or CreatePredictor operations. Two
 * folders containing CSV or Parquet files are exported to your specified S3 bucket.
 *
 * The export file names will match the following conventions:
 *
 * `__.csv`
 *
 * The component is in Java SimpleDate format
 * (yyyy-MM-ddTHH-mm-ssZ).
 *
 * You must specify a DataDestination object that includes an Amazon S3
 * bucket and an Identity and Access Management (IAM) role that Amazon Forecast can assume to access the Amazon S3
 * bucket. For more information, see aws-forecast-iam-roles.
 *
 * The `Status` of the export job must be `ACTIVE` before you
 * can access the export in your Amazon S3 bucket. To get the status, use the DescribePredictorBacktestExportJob operation.
 */
export declare const createPredictorBacktestExportJob: API.OperationMethod<CreatePredictorBacktestExportJobRequest, CreatePredictorBacktestExportJobResponse, CreatePredictorBacktestExportJobError, Credentials | HttpClient.HttpClient>;
export type CreateWhatIfAnalysisError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * What-if analysis is a scenario modeling technique where you make a hypothetical change to a time series and
 * compare the forecasts generated by these changes against the baseline, unchanged time series. It is important to
 * remember that the purpose of a what-if analysis is to understand how a forecast can change given different
 * modifications to the baseline time series.
 *
 * For example, imagine you are a clothing retailer who is considering an end of season sale
 * to clear space for new styles. After creating a baseline forecast, you can use a what-if
 * analysis to investigate how different sales tactics might affect your goals.
 *
 * You could create a scenario where everything is given a 25% markdown, and another where
 * everything is given a fixed dollar markdown. You could create a scenario where the sale lasts for one week and
 * another where the sale lasts for one month.
 * With a what-if analysis, you can compare many different scenarios against each other.
 *
 * Note that a what-if analysis is meant to display what the forecasting model has learned and how it will behave in the scenarios that you are evaluating. Do not blindly use the results of the what-if analysis to make business decisions. For instance, forecasts might not be accurate for novel scenarios where there is no reference available to determine whether a forecast is good.
 *
 * The TimeSeriesSelector object defines the items that you want in the what-if analysis.
 */
export declare const createWhatIfAnalysis: API.OperationMethod<CreateWhatIfAnalysisRequest, CreateWhatIfAnalysisResponse, CreateWhatIfAnalysisError, Credentials | HttpClient.HttpClient>;
export type CreateWhatIfForecastError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * A what-if forecast is a forecast that is created from a modified version of the baseline forecast. Each
 * what-if forecast incorporates either a replacement dataset or a set of transformations to the original dataset.
 */
export declare const createWhatIfForecast: API.OperationMethod<CreateWhatIfForecastRequest, CreateWhatIfForecastResponse, CreateWhatIfForecastError, Credentials | HttpClient.HttpClient>;
export type CreateWhatIfForecastExportError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Exports a forecast created by the CreateWhatIfForecast operation to your
 * Amazon Simple Storage Service (Amazon S3) bucket. The forecast file name will match the following conventions:
 *
 * `≈__`
 *
 * The component is in Java SimpleDateFormat
 * (yyyy-MM-ddTHH-mm-ssZ).
 *
 * You must specify a DataDestination object that includes an Identity and Access Management
 * (IAM) role that Amazon Forecast can assume to access the Amazon S3 bucket. For more information, see
 * aws-forecast-iam-roles.
 *
 * For more information, see howitworks-forecast.
 *
 * To get a list of all your what-if forecast export jobs, use the ListWhatIfForecastExports
 * operation.
 *
 * The `Status` of the forecast export job must be `ACTIVE` before
 * you can access the forecast in your Amazon S3 bucket. To get the status, use the DescribeWhatIfForecastExport operation.
 */
export declare const createWhatIfForecastExport: API.OperationMethod<CreateWhatIfForecastExportRequest, CreateWhatIfForecastExportResponse, CreateWhatIfForecastExportError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Amazon Forecast dataset that was created using the CreateDataset operation. You can
 * only delete datasets that have a status of `ACTIVE` or `CREATE_FAILED`.
 * To get the status use the DescribeDataset operation.
 *
 * Forecast does not automatically update any dataset groups that contain the deleted dataset.
 * In order to update the dataset group, use the UpdateDatasetGroup operation,
 * omitting the deleted dataset's ARN.
 */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest, DeleteDatasetResponse, DeleteDatasetError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetGroupError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a dataset group created using the CreateDatasetGroup operation.
 * You can only delete dataset groups that have a status of `ACTIVE`,
 * `CREATE_FAILED`, or `UPDATE_FAILED`. To get the status, use the DescribeDatasetGroup operation.
 *
 * This operation deletes only the dataset group, not the datasets in the group.
 */
export declare const deleteDatasetGroup: API.OperationMethod<DeleteDatasetGroupRequest, DeleteDatasetGroupResponse, DeleteDatasetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetImportJobError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a dataset import job created using the CreateDatasetImportJob
 * operation. You can delete only dataset import jobs that have a status of `ACTIVE`
 * or `CREATE_FAILED`. To get the status, use the DescribeDatasetImportJob
 * operation.
 */
export declare const deleteDatasetImportJob: API.OperationMethod<DeleteDatasetImportJobRequest, DeleteDatasetImportJobResponse, DeleteDatasetImportJobError, Credentials | HttpClient.HttpClient>;
export type DeleteExplainabilityError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Explainability resource.
 *
 * You can delete only predictor that have a status of `ACTIVE` or
 * `CREATE_FAILED`. To get the status, use the DescribeExplainability operation.
 */
export declare const deleteExplainability: API.OperationMethod<DeleteExplainabilityRequest, DeleteExplainabilityResponse, DeleteExplainabilityError, Credentials | HttpClient.HttpClient>;
export type DeleteExplainabilityExportError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Explainability export.
 */
export declare const deleteExplainabilityExport: API.OperationMethod<DeleteExplainabilityExportRequest, DeleteExplainabilityExportResponse, DeleteExplainabilityExportError, Credentials | HttpClient.HttpClient>;
export type DeleteForecastError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a forecast created using the CreateForecast operation. You can
 * delete only forecasts that have a status of `ACTIVE` or `CREATE_FAILED`.
 * To get the status, use the DescribeForecast operation.
 *
 * You can't delete a forecast while it is being exported. After a forecast is deleted, you
 * can no longer query the forecast.
 */
export declare const deleteForecast: API.OperationMethod<DeleteForecastRequest, DeleteForecastResponse, DeleteForecastError, Credentials | HttpClient.HttpClient>;
export type DeleteForecastExportJobError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a forecast export job created using the CreateForecastExportJob
 * operation. You can delete only export jobs that have a status of `ACTIVE` or
 * `CREATE_FAILED`. To get the status, use the DescribeForecastExportJob operation.
 */
export declare const deleteForecastExportJob: API.OperationMethod<DeleteForecastExportJobRequest, DeleteForecastExportJobResponse, DeleteForecastExportJobError, Credentials | HttpClient.HttpClient>;
export type DeleteMonitorError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a monitor resource. You can only delete a monitor resource with a status of `ACTIVE`, `ACTIVE_STOPPED`, `CREATE_FAILED`, or `CREATE_STOPPED`.
 */
export declare const deleteMonitor: API.OperationMethod<DeleteMonitorRequest, DeleteMonitorResponse, DeleteMonitorError, Credentials | HttpClient.HttpClient>;
export type DeletePredictorError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a predictor created using the DescribePredictor or CreatePredictor operations. You can delete only predictor that have a status of
 * `ACTIVE` or `CREATE_FAILED`. To get the status, use the DescribePredictor operation.
 */
export declare const deletePredictor: API.OperationMethod<DeletePredictorRequest, DeletePredictorResponse, DeletePredictorError, Credentials | HttpClient.HttpClient>;
export type DeletePredictorBacktestExportJobError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a predictor backtest export job.
 */
export declare const deletePredictorBacktestExportJob: API.OperationMethod<DeletePredictorBacktestExportJobRequest, DeletePredictorBacktestExportJobResponse, DeletePredictorBacktestExportJobError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceTreeError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an entire resource tree. This operation will delete the parent resource and
 * its child resources.
 *
 * Child resources are resources that were created from another resource. For example,
 * when a forecast is generated from a predictor, the forecast is the child resource and
 * the predictor is the parent resource.
 *
 * Amazon Forecast resources possess the following parent-child resource hierarchies:
 *
 * - **Dataset**: dataset import jobs
 *
 * - **Dataset Group**: predictors, predictor backtest
 * export jobs, forecasts, forecast export jobs
 *
 * - **Predictor**: predictor backtest export jobs,
 * forecasts, forecast export jobs
 *
 * - **Forecast**: forecast export jobs
 *
 * `DeleteResourceTree` will only delete Amazon Forecast resources, and will not
 * delete datasets or exported files stored in Amazon S3.
 */
export declare const deleteResourceTree: API.OperationMethod<DeleteResourceTreeRequest, DeleteResourceTreeResponse, DeleteResourceTreeError, Credentials | HttpClient.HttpClient>;
export type DeleteWhatIfAnalysisError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a what-if analysis created using the CreateWhatIfAnalysis
 * operation. You can delete only what-if analyses that have a status of `ACTIVE` or `CREATE_FAILED`. To get the status, use the DescribeWhatIfAnalysis operation.
 *
 * You can't delete a what-if analysis while any of its forecasts are being exported.
 */
export declare const deleteWhatIfAnalysis: API.OperationMethod<DeleteWhatIfAnalysisRequest, DeleteWhatIfAnalysisResponse, DeleteWhatIfAnalysisError, Credentials | HttpClient.HttpClient>;
export type DeleteWhatIfForecastError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a what-if forecast created using the CreateWhatIfForecast
 * operation. You can delete only what-if forecasts that have a status of `ACTIVE` or `CREATE_FAILED`. To get the status, use the DescribeWhatIfForecast operation.
 *
 * You can't delete a what-if forecast while it is being exported. After a what-if forecast is deleted, you can no longer query the what-if analysis.
 */
export declare const deleteWhatIfForecast: API.OperationMethod<DeleteWhatIfForecastRequest, DeleteWhatIfForecastResponse, DeleteWhatIfForecastError, Credentials | HttpClient.HttpClient>;
export type DeleteWhatIfForecastExportError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a what-if forecast export created using the CreateWhatIfForecastExport
 * operation. You can delete only what-if forecast exports that have a status of `ACTIVE` or `CREATE_FAILED`. To get the status, use the DescribeWhatIfForecastExport operation.
 */
export declare const deleteWhatIfForecastExport: API.OperationMethod<DeleteWhatIfForecastExportRequest, DeleteWhatIfForecastExportResponse, DeleteWhatIfForecastExportError, Credentials | HttpClient.HttpClient>;
export type DescribeAutoPredictorError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a predictor created using the CreateAutoPredictor operation.
 */
export declare const describeAutoPredictor: API.OperationMethod<DescribeAutoPredictorRequest, DescribeAutoPredictorResponse, DescribeAutoPredictorError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes an Amazon Forecast dataset created using the CreateDataset operation.
 *
 * In addition to listing the parameters specified in the `CreateDataset` request,
 * this operation includes the following dataset properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Status`
 */
export declare const describeDataset: API.OperationMethod<DescribeDatasetRequest, DescribeDatasetResponse, DescribeDatasetError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetGroupError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a dataset group created using the CreateDatasetGroup
 * operation.
 *
 * In addition to listing the parameters provided in the `CreateDatasetGroup`
 * request, this operation includes the following properties:
 *
 * - `DatasetArns` - The datasets belonging to the group.
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Status`
 */
export declare const describeDatasetGroup: API.OperationMethod<DescribeDatasetGroupRequest, DescribeDatasetGroupResponse, DescribeDatasetGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetImportJobError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a dataset import job created using the CreateDatasetImportJob
 * operation.
 *
 * In addition to listing the parameters provided in the `CreateDatasetImportJob`
 * request, this operation includes the following properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `DataSize`
 *
 * - `FieldStatistics`
 *
 * - `Status`
 *
 * - `Message` - If an error occurred, information about the error.
 */
export declare const describeDatasetImportJob: API.OperationMethod<DescribeDatasetImportJobRequest, DescribeDatasetImportJobResponse, DescribeDatasetImportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeExplainabilityError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes an Explainability resource created using the CreateExplainability operation.
 */
export declare const describeExplainability: API.OperationMethod<DescribeExplainabilityRequest, DescribeExplainabilityResponse, DescribeExplainabilityError, Credentials | HttpClient.HttpClient>;
export type DescribeExplainabilityExportError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes an Explainability export created using the CreateExplainabilityExport operation.
 */
export declare const describeExplainabilityExport: API.OperationMethod<DescribeExplainabilityExportRequest, DescribeExplainabilityExportResponse, DescribeExplainabilityExportError, Credentials | HttpClient.HttpClient>;
export type DescribeForecastError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a forecast created using the CreateForecast operation.
 *
 * In addition to listing the properties provided in the `CreateForecast` request,
 * this operation lists the following properties:
 *
 * - `DatasetGroupArn` - The dataset group that provided the training
 * data.
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Status`
 *
 * - `Message` - If an error occurred, information about the error.
 */
export declare const describeForecast: API.OperationMethod<DescribeForecastRequest, DescribeForecastResponse, DescribeForecastError, Credentials | HttpClient.HttpClient>;
export type DescribeForecastExportJobError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a forecast export job created using the CreateForecastExportJob operation.
 *
 * In addition to listing the properties provided by the user in the
 * `CreateForecastExportJob` request, this operation lists the following
 * properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Status`
 *
 * - `Message` - If an error occurred, information about the error.
 */
export declare const describeForecastExportJob: API.OperationMethod<DescribeForecastExportJobRequest, DescribeForecastExportJobResponse, DescribeForecastExportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeMonitorError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a monitor resource. In addition to listing the properties provided in the CreateMonitor request, this operation lists the following properties:
 *
 * - `Baseline`
 *
 * - `CreationTime`
 *
 * - `LastEvaluationTime`
 *
 * - `LastEvaluationState`
 *
 * - `LastModificationTime`
 *
 * - `Message`
 *
 * - `Status`
 */
export declare const describeMonitor: API.OperationMethod<DescribeMonitorRequest, DescribeMonitorResponse, DescribeMonitorError, Credentials | HttpClient.HttpClient>;
export type DescribePredictorError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * This operation is only valid for legacy predictors created with CreatePredictor. If you
 * are not using a legacy predictor, use DescribeAutoPredictor.
 *
 * Describes a predictor created using the CreatePredictor
 * operation.
 *
 * In addition to listing the properties provided in the `CreatePredictor`
 * request, this operation lists the following properties:
 *
 * - `DatasetImportJobArns` - The dataset import jobs used to import training
 * data.
 *
 * - `AutoMLAlgorithmArns` - If AutoML is performed, the algorithms that were
 * evaluated.
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Status`
 *
 * - `Message` - If an error occurred, information about the error.
 */
export declare const describePredictor: API.OperationMethod<DescribePredictorRequest, DescribePredictorResponse, DescribePredictorError, Credentials | HttpClient.HttpClient>;
export type DescribePredictorBacktestExportJobError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a predictor backtest export job created using the CreatePredictorBacktestExportJob operation.
 *
 * In addition to listing the properties provided by the user in the
 * `CreatePredictorBacktestExportJob` request, this operation lists the
 * following properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Status`
 *
 * - `Message` (if an error occurred)
 */
export declare const describePredictorBacktestExportJob: API.OperationMethod<DescribePredictorBacktestExportJobRequest, DescribePredictorBacktestExportJobResponse, DescribePredictorBacktestExportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeWhatIfAnalysisError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the what-if analysis created using the CreateWhatIfAnalysis operation.
 *
 * In addition to listing the properties provided in the `CreateWhatIfAnalysis` request, this operation lists the following properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Message` - If an error occurred, information about the error.
 *
 * - `Status`
 */
export declare const describeWhatIfAnalysis: API.OperationMethod<DescribeWhatIfAnalysisRequest, DescribeWhatIfAnalysisResponse, DescribeWhatIfAnalysisError, Credentials | HttpClient.HttpClient>;
export type DescribeWhatIfForecastError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the what-if forecast created using the CreateWhatIfForecast operation.
 *
 * In addition to listing the properties provided in the `CreateWhatIfForecast` request, this operation lists the following properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Message` - If an error occurred, information about the error.
 *
 * - `Status`
 */
export declare const describeWhatIfForecast: API.OperationMethod<DescribeWhatIfForecastRequest, DescribeWhatIfForecastResponse, DescribeWhatIfForecastError, Credentials | HttpClient.HttpClient>;
export type DescribeWhatIfForecastExportError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the what-if forecast export created using the CreateWhatIfForecastExport operation.
 *
 * In addition to listing the properties provided in the `CreateWhatIfForecastExport` request, this operation lists the following properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Message` - If an error occurred, information about the error.
 *
 * - `Status`
 */
export declare const describeWhatIfForecastExport: API.OperationMethod<DescribeWhatIfForecastExportRequest, DescribeWhatIfForecastExportResponse, DescribeWhatIfForecastExportError, Credentials | HttpClient.HttpClient>;
export type GetAccuracyMetricsError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Provides metrics on the accuracy of the models that were trained by the CreatePredictor operation. Use metrics to see how well the model performed and
 * to decide whether to use the predictor to generate a forecast. For more information, see
 * Predictor
 * Metrics.
 *
 * This operation generates metrics for each backtest window that was evaluated. The number
 * of backtest windows (`NumberOfBacktestWindows`) is specified using the EvaluationParameters object, which is optionally included in the
 * `CreatePredictor` request. If `NumberOfBacktestWindows` isn't
 * specified, the number defaults to one.
 *
 * The parameters of the `filling` method determine which items contribute to the
 * metrics. If you want all items to contribute, specify `zero`. If you want only
 * those items that have complete data in the range being evaluated to contribute, specify
 * `nan`. For more information, see FeaturizationMethod.
 *
 * Before you can get accuracy metrics, the `Status` of the predictor must be
 * `ACTIVE`, signifying that training has completed. To get the status, use the
 * DescribePredictor operation.
 */
export declare const getAccuracyMetrics: API.OperationMethod<GetAccuracyMetricsRequest, GetAccuracyMetricsResponse, GetAccuracyMetricsError, Credentials | HttpClient.HttpClient>;
export type ListDatasetGroupsError = InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of dataset groups created using the CreateDatasetGroup operation.
 * For each dataset group, this operation returns a summary of its properties, including its
 * Amazon Resource Name (ARN). You can retrieve the complete set of properties by using the
 * dataset group ARN with the DescribeDatasetGroup
 * operation.
 */
export declare const listDatasetGroups: API.PaginatedOperationMethod<ListDatasetGroupsRequest, ListDatasetGroupsResponse, ListDatasetGroupsError, Credentials | HttpClient.HttpClient, DatasetGroupSummary>;
export type ListDatasetImportJobsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of dataset import jobs created using the CreateDatasetImportJob
 * operation. For each import job, this operation returns a summary of its properties, including
 * its Amazon Resource Name (ARN). You can retrieve the complete set of properties by using the
 * ARN with the DescribeDatasetImportJob
 * operation. You can filter the list by providing an array of Filter objects.
 */
export declare const listDatasetImportJobs: API.PaginatedOperationMethod<ListDatasetImportJobsRequest, ListDatasetImportJobsResponse, ListDatasetImportJobsError, Credentials | HttpClient.HttpClient, DatasetImportJobSummary>;
export type ListDatasetsError = InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of datasets created using the CreateDataset operation. For each
 * dataset, a summary of its properties, including its Amazon Resource Name (ARN), is returned.
 * To retrieve the complete set of properties, use the ARN with the DescribeDataset operation.
 */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest, ListDatasetsResponse, ListDatasetsError, Credentials | HttpClient.HttpClient, DatasetSummary>;
export type ListExplainabilitiesError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of Explainability resources created using the CreateExplainability operation. This operation returns a summary for
 * each Explainability. You can filter the list using an array of Filter
 * objects.
 *
 * To retrieve the complete set of properties for a particular Explainability resource,
 * use the ARN with the DescribeExplainability operation.
 */
export declare const listExplainabilities: API.PaginatedOperationMethod<ListExplainabilitiesRequest, ListExplainabilitiesResponse, ListExplainabilitiesError, Credentials | HttpClient.HttpClient, ExplainabilitySummary>;
export type ListExplainabilityExportsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of Explainability exports created using the CreateExplainabilityExport operation. This operation returns a summary
 * for each Explainability export. You can filter the list using an array of Filter objects.
 *
 * To retrieve the complete set of properties for a particular Explainability export, use
 * the ARN with the DescribeExplainability operation.
 */
export declare const listExplainabilityExports: API.PaginatedOperationMethod<ListExplainabilityExportsRequest, ListExplainabilityExportsResponse, ListExplainabilityExportsError, Credentials | HttpClient.HttpClient, ExplainabilityExportSummary>;
export type ListForecastExportJobsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of forecast export jobs created using the CreateForecastExportJob operation. For each forecast export job, this operation
 * returns a summary of its properties, including its Amazon Resource Name (ARN). To retrieve the
 * complete set of properties, use the ARN with the DescribeForecastExportJob
 * operation. You can filter the list using an array of Filter objects.
 */
export declare const listForecastExportJobs: API.PaginatedOperationMethod<ListForecastExportJobsRequest, ListForecastExportJobsResponse, ListForecastExportJobsError, Credentials | HttpClient.HttpClient, ForecastExportJobSummary>;
export type ListForecastsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of forecasts created using the CreateForecast operation.
 * For each forecast, this operation returns a summary of its properties, including its Amazon
 * Resource Name (ARN). To retrieve the complete set of properties, specify the ARN with the
 * DescribeForecast operation. You can filter the list using an array of
 * Filter objects.
 */
export declare const listForecasts: API.PaginatedOperationMethod<ListForecastsRequest, ListForecastsResponse, ListForecastsError, Credentials | HttpClient.HttpClient, ForecastSummary>;
export type ListMonitorEvaluationsError = InvalidInputException | InvalidNextTokenException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of the monitoring evaluation results and predictor events collected by
 * the monitor resource during different windows of time.
 *
 * For information about monitoring see predictor-monitoring. For
 * more information about retrieving monitoring results see Viewing Monitoring Results.
 */
export declare const listMonitorEvaluations: API.PaginatedOperationMethod<ListMonitorEvaluationsRequest, ListMonitorEvaluationsResponse, ListMonitorEvaluationsError, Credentials | HttpClient.HttpClient, PredictorMonitorEvaluation>;
export type ListMonitorsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of monitors created with the CreateMonitor operation and CreateAutoPredictor operation. For each monitor resource, this operation returns of a summary of its properties, including its Amazon Resource Name (ARN). You
 * can retrieve a complete set of properties of a monitor resource by specify the monitor's ARN in the DescribeMonitor operation.
 */
export declare const listMonitors: API.PaginatedOperationMethod<ListMonitorsRequest, ListMonitorsResponse, ListMonitorsError, Credentials | HttpClient.HttpClient, MonitorSummary>;
export type ListPredictorBacktestExportJobsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of predictor backtest export jobs created using the CreatePredictorBacktestExportJob operation. This operation returns a
 * summary for each backtest export job. You can filter the list using an array of Filter objects.
 *
 * To retrieve the complete set of properties for a particular backtest export job, use
 * the ARN with the DescribePredictorBacktestExportJob operation.
 */
export declare const listPredictorBacktestExportJobs: API.PaginatedOperationMethod<ListPredictorBacktestExportJobsRequest, ListPredictorBacktestExportJobsResponse, ListPredictorBacktestExportJobsError, Credentials | HttpClient.HttpClient, PredictorBacktestExportJobSummary>;
export type ListPredictorsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of predictors created using the CreateAutoPredictor or
 * CreatePredictor operations. For each predictor, this operation returns a
 * summary of its properties, including its Amazon Resource Name (ARN).
 *
 * You can retrieve the complete set of properties by using the ARN with the DescribeAutoPredictor and DescribePredictor operations. You
 * can filter the list using an array of Filter objects.
 */
export declare const listPredictors: API.PaginatedOperationMethod<ListPredictorsRequest, ListPredictorsResponse, ListPredictorsError, Credentials | HttpClient.HttpClient, PredictorSummary>;
export type ListTagsForResourceError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags for an Amazon Forecast resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWhatIfAnalysesError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of what-if analyses created using the CreateWhatIfAnalysis operation. For each what-if analysis, this operation returns a summary of its properties, including its Amazon Resource Name (ARN). You can retrieve the complete set of properties by using the what-if analysis ARN with the DescribeWhatIfAnalysis operation.
 */
export declare const listWhatIfAnalyses: API.PaginatedOperationMethod<ListWhatIfAnalysesRequest, ListWhatIfAnalysesResponse, ListWhatIfAnalysesError, Credentials | HttpClient.HttpClient, WhatIfAnalysisSummary>;
export type ListWhatIfForecastExportsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of what-if forecast exports created using the CreateWhatIfForecastExport operation. For each what-if forecast export, this operation returns a summary of its properties, including its Amazon Resource Name (ARN). You can retrieve the complete set of properties by using the what-if forecast export ARN with the DescribeWhatIfForecastExport operation.
 */
export declare const listWhatIfForecastExports: API.PaginatedOperationMethod<ListWhatIfForecastExportsRequest, ListWhatIfForecastExportsResponse, ListWhatIfForecastExportsError, Credentials | HttpClient.HttpClient, WhatIfForecastExportSummary>;
export type ListWhatIfForecastsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of what-if forecasts created using the CreateWhatIfForecast operation. For each what-if forecast, this operation returns a summary of its properties, including its Amazon Resource Name (ARN). You can retrieve the complete set of properties by using the what-if forecast ARN with the DescribeWhatIfForecast operation.
 */
export declare const listWhatIfForecasts: API.PaginatedOperationMethod<ListWhatIfForecastsRequest, ListWhatIfForecastsResponse, ListWhatIfForecastsError, Credentials | HttpClient.HttpClient, WhatIfForecastSummary>;
export type ResumeResourceError = InvalidInputException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Resumes a stopped monitor resource.
 */
export declare const resumeResource: API.OperationMethod<ResumeResourceRequest, ResumeResourceResponse, ResumeResourceError, Credentials | HttpClient.HttpClient>;
export type StopResourceError = InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Stops a resource.
 *
 * The resource undergoes the following states: `CREATE_STOPPING` and
 * `CREATE_STOPPED`. You cannot resume a resource once it has been
 * stopped.
 *
 * This operation can be applied to the following resources (and their corresponding child
 * resources):
 *
 * - Dataset Import Job
 *
 * - Predictor Job
 *
 * - Forecast Job
 *
 * - Forecast Export Job
 *
 * - Predictor Backtest Export Job
 *
 * - Explainability Job
 *
 * - Explainability Export Job
 */
export declare const stopResource: API.OperationMethod<StopResourceRequest, StopResourceResponse, StopResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `resourceArn`.
 * If existing tags on a resource are not specified in the request parameters, they are not
 * changed. When a resource is deleted, the tags associated with that resource are also
 * deleted.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDatasetGroupError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Replaces the datasets in a dataset group with the specified datasets.
 *
 * The `Status` of the dataset group must be `ACTIVE` before you can
 * use the dataset group to create a predictor. Use the DescribeDatasetGroup
 * operation to get the status.
 */
export declare const updateDatasetGroup: API.OperationMethod<UpdateDatasetGroupRequest, UpdateDatasetGroupResponse, UpdateDatasetGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=forecast.d.ts.map