import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type LandingZoneVersion = string;
export type RemediationType = "INHERITANCE_DRIFT" | (string & {});
export declare const RemediationType: any;
export type RemediationTypes = RemediationType[];
export declare const RemediationTypes: any;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type Manifest = unknown;
export interface CreateLandingZoneInput {
    version: string;
    remediationTypes?: RemediationType[];
    tags?: {
        [key: string]: string | undefined;
    };
    manifest?: any;
}
export declare const CreateLandingZoneInput: S.Schema<CreateLandingZoneInput>;
export type Arn = string;
export type OperationIdentifier = string;
export interface CreateLandingZoneOutput {
    arn: string;
    operationIdentifier: string;
}
export declare const CreateLandingZoneOutput: S.Schema<CreateLandingZoneOutput>;
export interface DeleteLandingZoneInput {
    landingZoneIdentifier: string;
}
export declare const DeleteLandingZoneInput: S.Schema<DeleteLandingZoneInput>;
export interface DeleteLandingZoneOutput {
    operationIdentifier: string;
}
export declare const DeleteLandingZoneOutput: S.Schema<DeleteLandingZoneOutput>;
export interface DisableBaselineInput {
    enabledBaselineIdentifier: string;
}
export declare const DisableBaselineInput: S.Schema<DisableBaselineInput>;
export interface DisableBaselineOutput {
    operationIdentifier: string;
}
export declare const DisableBaselineOutput: S.Schema<DisableBaselineOutput>;
export type ControlIdentifier = string;
export type TargetIdentifier = string;
export interface DisableControlInput {
    controlIdentifier?: string;
    targetIdentifier?: string;
    enabledControlIdentifier?: string;
}
export declare const DisableControlInput: S.Schema<DisableControlInput>;
export interface DisableControlOutput {
    operationIdentifier: string;
}
export declare const DisableControlOutput: S.Schema<DisableControlOutput>;
export type BaselineVersion = string;
export type EnabledBaselineParameterDocument = unknown;
export interface EnabledBaselineParameter {
    key: string;
    value: any;
}
export declare const EnabledBaselineParameter: S.Schema<EnabledBaselineParameter>;
export type EnabledBaselineParameters = EnabledBaselineParameter[];
export declare const EnabledBaselineParameters: any;
export interface EnableBaselineInput {
    baselineVersion: string;
    parameters?: EnabledBaselineParameter[];
    baselineIdentifier: string;
    targetIdentifier: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const EnableBaselineInput: S.Schema<EnableBaselineInput>;
export interface EnableBaselineOutput {
    operationIdentifier: string;
    arn: string;
}
export declare const EnableBaselineOutput: S.Schema<EnableBaselineOutput>;
export interface EnabledControlParameter {
    key: string;
    value: any;
}
export declare const EnabledControlParameter: S.Schema<EnabledControlParameter>;
export type EnabledControlParameters = EnabledControlParameter[];
export declare const EnabledControlParameters: any;
export interface EnableControlInput {
    controlIdentifier: string;
    targetIdentifier: string;
    tags?: {
        [key: string]: string | undefined;
    };
    parameters?: EnabledControlParameter[];
}
export declare const EnableControlInput: S.Schema<EnableControlInput>;
export interface EnableControlOutput {
    operationIdentifier: string;
    arn?: string;
}
export declare const EnableControlOutput: S.Schema<EnableControlOutput>;
export type BaselineArn = string;
export interface GetBaselineInput {
    baselineIdentifier: string;
}
export declare const GetBaselineInput: S.Schema<GetBaselineInput>;
export interface GetBaselineOutput {
    arn: string;
    name: string;
    description?: string;
}
export declare const GetBaselineOutput: S.Schema<GetBaselineOutput>;
export interface GetBaselineOperationInput {
    operationIdentifier: string;
}
export declare const GetBaselineOperationInput: S.Schema<GetBaselineOperationInput>;
export type BaselineOperationType = "ENABLE_BASELINE" | "DISABLE_BASELINE" | "UPDATE_ENABLED_BASELINE" | "RESET_ENABLED_BASELINE" | (string & {});
export declare const BaselineOperationType: any;
export type BaselineOperationStatus = "SUCCEEDED" | "FAILED" | "IN_PROGRESS" | (string & {});
export declare const BaselineOperationStatus: any;
export interface BaselineOperation {
    operationIdentifier?: string;
    operationType?: BaselineOperationType;
    status?: BaselineOperationStatus;
    startTime?: Date;
    endTime?: Date;
    statusMessage?: string;
}
export declare const BaselineOperation: S.Schema<BaselineOperation>;
export interface GetBaselineOperationOutput {
    baselineOperation: BaselineOperation;
}
export declare const GetBaselineOperationOutput: S.Schema<GetBaselineOperationOutput>;
export interface GetControlOperationInput {
    operationIdentifier: string;
}
export declare const GetControlOperationInput: S.Schema<GetControlOperationInput>;
export type ControlOperationType = "ENABLE_CONTROL" | "DISABLE_CONTROL" | "UPDATE_ENABLED_CONTROL" | "RESET_ENABLED_CONTROL" | (string & {});
export declare const ControlOperationType: any;
export type ControlOperationStatus = "SUCCEEDED" | "FAILED" | "IN_PROGRESS" | (string & {});
export declare const ControlOperationStatus: any;
export interface ControlOperation {
    operationType?: ControlOperationType;
    startTime?: Date;
    endTime?: Date;
    status?: ControlOperationStatus;
    statusMessage?: string;
    operationIdentifier?: string;
    controlIdentifier?: string;
    targetIdentifier?: string;
    enabledControlIdentifier?: string;
}
export declare const ControlOperation: S.Schema<ControlOperation>;
export interface GetControlOperationOutput {
    controlOperation: ControlOperation;
}
export declare const GetControlOperationOutput: S.Schema<GetControlOperationOutput>;
export interface GetEnabledBaselineInput {
    enabledBaselineIdentifier: string;
}
export declare const GetEnabledBaselineInput: S.Schema<GetEnabledBaselineInput>;
export type EnabledBaselineDriftStatus = "IN_SYNC" | "DRIFTED" | (string & {});
export declare const EnabledBaselineDriftStatus: any;
export interface EnabledBaselineInheritanceDrift {
    status?: EnabledBaselineDriftStatus;
}
export declare const EnabledBaselineInheritanceDrift: S.Schema<EnabledBaselineInheritanceDrift>;
export interface EnabledBaselineDriftTypes {
    inheritance?: EnabledBaselineInheritanceDrift;
}
export declare const EnabledBaselineDriftTypes: S.Schema<EnabledBaselineDriftTypes>;
export interface EnabledBaselineDriftStatusSummary {
    types?: EnabledBaselineDriftTypes;
}
export declare const EnabledBaselineDriftStatusSummary: S.Schema<EnabledBaselineDriftStatusSummary>;
export type EnablementStatus = "SUCCEEDED" | "FAILED" | "UNDER_CHANGE" | (string & {});
export declare const EnablementStatus: any;
export interface EnablementStatusSummary {
    status?: EnablementStatus;
    lastOperationIdentifier?: string;
}
export declare const EnablementStatusSummary: S.Schema<EnablementStatusSummary>;
export interface EnabledBaselineParameterSummary {
    key: string;
    value: any;
}
export declare const EnabledBaselineParameterSummary: S.Schema<EnabledBaselineParameterSummary>;
export type EnabledBaselineParameterSummaries = EnabledBaselineParameterSummary[];
export declare const EnabledBaselineParameterSummaries: any;
export interface EnabledBaselineDetails {
    arn: string;
    baselineIdentifier: string;
    baselineVersion?: string;
    driftStatusSummary?: EnabledBaselineDriftStatusSummary;
    targetIdentifier: string;
    parentIdentifier?: string;
    statusSummary: EnablementStatusSummary;
    parameters?: EnabledBaselineParameterSummary[];
}
export declare const EnabledBaselineDetails: S.Schema<EnabledBaselineDetails>;
export interface GetEnabledBaselineOutput {
    enabledBaselineDetails?: EnabledBaselineDetails;
}
export declare const GetEnabledBaselineOutput: S.Schema<GetEnabledBaselineOutput>;
export interface GetEnabledControlInput {
    enabledControlIdentifier: string;
}
export declare const GetEnabledControlInput: S.Schema<GetEnabledControlInput>;
export type DriftStatus = "DRIFTED" | "IN_SYNC" | "NOT_CHECKING" | "UNKNOWN" | (string & {});
export declare const DriftStatus: any;
export interface EnabledControlInheritanceDrift {
    status?: DriftStatus;
}
export declare const EnabledControlInheritanceDrift: S.Schema<EnabledControlInheritanceDrift>;
export interface EnabledControlResourceDrift {
    status?: DriftStatus;
}
export declare const EnabledControlResourceDrift: S.Schema<EnabledControlResourceDrift>;
export interface EnabledControlDriftTypes {
    inheritance?: EnabledControlInheritanceDrift;
    resource?: EnabledControlResourceDrift;
}
export declare const EnabledControlDriftTypes: S.Schema<EnabledControlDriftTypes>;
export interface DriftStatusSummary {
    driftStatus?: DriftStatus;
    types?: EnabledControlDriftTypes;
}
export declare const DriftStatusSummary: S.Schema<DriftStatusSummary>;
export type ParentIdentifier = string;
export type RegionName = string;
export interface Region {
    name?: string;
}
export declare const Region: S.Schema<Region>;
export type TargetRegions = Region[];
export declare const TargetRegions: any;
export interface EnabledControlParameterSummary {
    key: string;
    value: any;
}
export declare const EnabledControlParameterSummary: S.Schema<EnabledControlParameterSummary>;
export type EnabledControlParameterSummaries = EnabledControlParameterSummary[];
export declare const EnabledControlParameterSummaries: any;
export interface EnabledControlDetails {
    arn?: string;
    controlIdentifier?: string;
    targetIdentifier?: string;
    statusSummary?: EnablementStatusSummary;
    driftStatusSummary?: DriftStatusSummary;
    parentIdentifier?: string;
    targetRegions?: Region[];
    parameters?: EnabledControlParameterSummary[];
}
export declare const EnabledControlDetails: S.Schema<EnabledControlDetails>;
export interface GetEnabledControlOutput {
    enabledControlDetails: EnabledControlDetails;
}
export declare const GetEnabledControlOutput: S.Schema<GetEnabledControlOutput>;
export interface GetLandingZoneInput {
    landingZoneIdentifier: string;
}
export declare const GetLandingZoneInput: S.Schema<GetLandingZoneInput>;
export type LandingZoneStatus = "ACTIVE" | "PROCESSING" | "FAILED" | (string & {});
export declare const LandingZoneStatus: any;
export type LandingZoneDriftStatus = "DRIFTED" | "IN_SYNC" | (string & {});
export declare const LandingZoneDriftStatus: any;
export interface LandingZoneDriftStatusSummary {
    status?: LandingZoneDriftStatus;
}
export declare const LandingZoneDriftStatusSummary: S.Schema<LandingZoneDriftStatusSummary>;
export interface LandingZoneDetail {
    version: string;
    remediationTypes?: RemediationType[];
    arn?: string;
    status?: LandingZoneStatus;
    latestAvailableVersion?: string;
    driftStatus?: LandingZoneDriftStatusSummary;
    manifest: any;
}
export declare const LandingZoneDetail: S.Schema<LandingZoneDetail>;
export interface GetLandingZoneOutput {
    landingZone: LandingZoneDetail;
}
export declare const GetLandingZoneOutput: S.Schema<GetLandingZoneOutput>;
export interface GetLandingZoneOperationInput {
    operationIdentifier: string;
}
export declare const GetLandingZoneOperationInput: S.Schema<GetLandingZoneOperationInput>;
export type LandingZoneOperationType = "DELETE" | "CREATE" | "UPDATE" | "RESET" | (string & {});
export declare const LandingZoneOperationType: any;
export type LandingZoneOperationStatus = "SUCCEEDED" | "FAILED" | "IN_PROGRESS" | (string & {});
export declare const LandingZoneOperationStatus: any;
export interface LandingZoneOperationDetail {
    operationType?: LandingZoneOperationType;
    operationIdentifier?: string;
    status?: LandingZoneOperationStatus;
    startTime?: Date;
    endTime?: Date;
    statusMessage?: string;
}
export declare const LandingZoneOperationDetail: S.Schema<LandingZoneOperationDetail>;
export interface GetLandingZoneOperationOutput {
    operationDetails: LandingZoneOperationDetail;
}
export declare const GetLandingZoneOperationOutput: S.Schema<GetLandingZoneOperationOutput>;
export type ListBaselinesMaxResults = number;
export interface ListBaselinesInput {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListBaselinesInput: S.Schema<ListBaselinesInput>;
export interface BaselineSummary {
    arn: string;
    name: string;
    description?: string;
}
export declare const BaselineSummary: S.Schema<BaselineSummary>;
export type Baselines = BaselineSummary[];
export declare const Baselines: any;
export interface ListBaselinesOutput {
    baselines: BaselineSummary[];
    nextToken?: string;
}
export declare const ListBaselinesOutput: S.Schema<ListBaselinesOutput>;
export type ControlIdentifiers = string[];
export declare const ControlIdentifiers: any;
export type TargetIdentifiers = string[];
export declare const TargetIdentifiers: any;
export type EnabledControlIdentifiers = string[];
export declare const EnabledControlIdentifiers: any;
export type ControlOperationStatuses = ControlOperationStatus[];
export declare const ControlOperationStatuses: any;
export type ControlOperationTypes = ControlOperationType[];
export declare const ControlOperationTypes: any;
export interface ControlOperationFilter {
    controlIdentifiers?: string[];
    targetIdentifiers?: string[];
    enabledControlIdentifiers?: string[];
    statuses?: ControlOperationStatus[];
    controlOperationTypes?: ControlOperationType[];
}
export declare const ControlOperationFilter: S.Schema<ControlOperationFilter>;
export type ListControlOperationsNextToken = string;
export type ListControlOperationsMaxResults = number;
export interface ListControlOperationsInput {
    filter?: ControlOperationFilter;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListControlOperationsInput: S.Schema<ListControlOperationsInput>;
export interface ControlOperationSummary {
    operationType?: ControlOperationType;
    startTime?: Date;
    endTime?: Date;
    status?: ControlOperationStatus;
    statusMessage?: string;
    operationIdentifier?: string;
    controlIdentifier?: string;
    targetIdentifier?: string;
    enabledControlIdentifier?: string;
}
export declare const ControlOperationSummary: S.Schema<ControlOperationSummary>;
export type ControlOperations = ControlOperationSummary[];
export declare const ControlOperations: any;
export interface ListControlOperationsOutput {
    controlOperations: ControlOperationSummary[];
    nextToken?: string;
}
export declare const ListControlOperationsOutput: S.Schema<ListControlOperationsOutput>;
export type EnabledBaselineTargetIdentifiers = string[];
export declare const EnabledBaselineTargetIdentifiers: any;
export type EnabledBaselineBaselineIdentifiers = string[];
export declare const EnabledBaselineBaselineIdentifiers: any;
export type EnabledBaselineParentIdentifiers = string[];
export declare const EnabledBaselineParentIdentifiers: any;
export type EnabledBaselineEnablementStatuses = EnablementStatus[];
export declare const EnabledBaselineEnablementStatuses: any;
export type EnabledBaselineDriftStatuses = EnabledBaselineDriftStatus[];
export declare const EnabledBaselineDriftStatuses: any;
export interface EnabledBaselineFilter {
    targetIdentifiers?: string[];
    baselineIdentifiers?: string[];
    parentIdentifiers?: string[];
    statuses?: EnablementStatus[];
    inheritanceDriftStatuses?: EnabledBaselineDriftStatus[];
}
export declare const EnabledBaselineFilter: S.Schema<EnabledBaselineFilter>;
export type ListEnabledBaselinesNextToken = string;
export type ListEnabledBaselinesMaxResults = number;
export interface ListEnabledBaselinesInput {
    filter?: EnabledBaselineFilter;
    nextToken?: string;
    maxResults?: number;
    includeChildren?: boolean;
}
export declare const ListEnabledBaselinesInput: S.Schema<ListEnabledBaselinesInput>;
export interface EnabledBaselineSummary {
    arn: string;
    baselineIdentifier: string;
    baselineVersion?: string;
    driftStatusSummary?: EnabledBaselineDriftStatusSummary;
    targetIdentifier: string;
    parentIdentifier?: string;
    statusSummary: EnablementStatusSummary;
}
export declare const EnabledBaselineSummary: S.Schema<EnabledBaselineSummary>;
export type EnabledBaselines = EnabledBaselineSummary[];
export declare const EnabledBaselines: any;
export interface ListEnabledBaselinesOutput {
    enabledBaselines: EnabledBaselineSummary[];
    nextToken?: string;
}
export declare const ListEnabledBaselinesOutput: S.Schema<ListEnabledBaselinesOutput>;
export type MaxResults = number;
export type EnablementStatuses = EnablementStatus[];
export declare const EnablementStatuses: any;
export type DriftStatuses = DriftStatus[];
export declare const DriftStatuses: any;
export type ParentIdentifiers = string[];
export declare const ParentIdentifiers: any;
export interface EnabledControlFilter {
    controlIdentifiers?: string[];
    statuses?: EnablementStatus[];
    driftStatuses?: DriftStatus[];
    parentIdentifiers?: string[];
    inheritanceDriftStatuses?: DriftStatus[];
    resourceDriftStatuses?: DriftStatus[];
}
export declare const EnabledControlFilter: S.Schema<EnabledControlFilter>;
export interface ListEnabledControlsInput {
    targetIdentifier?: string;
    nextToken?: string;
    maxResults?: number;
    filter?: EnabledControlFilter;
    includeChildren?: boolean;
}
export declare const ListEnabledControlsInput: S.Schema<ListEnabledControlsInput>;
export interface EnabledControlSummary {
    arn?: string;
    controlIdentifier?: string;
    targetIdentifier?: string;
    statusSummary?: EnablementStatusSummary;
    driftStatusSummary?: DriftStatusSummary;
    parentIdentifier?: string;
}
export declare const EnabledControlSummary: S.Schema<EnabledControlSummary>;
export type EnabledControls = EnabledControlSummary[];
export declare const EnabledControls: any;
export interface ListEnabledControlsOutput {
    enabledControls: EnabledControlSummary[];
    nextToken?: string;
}
export declare const ListEnabledControlsOutput: S.Schema<ListEnabledControlsOutput>;
export type LandingZoneOperationTypes = LandingZoneOperationType[];
export declare const LandingZoneOperationTypes: any;
export type LandingZoneOperationStatuses = LandingZoneOperationStatus[];
export declare const LandingZoneOperationStatuses: any;
export interface LandingZoneOperationFilter {
    types?: LandingZoneOperationType[];
    statuses?: LandingZoneOperationStatus[];
}
export declare const LandingZoneOperationFilter: S.Schema<LandingZoneOperationFilter>;
export type ListLandingZoneOperationsMaxResults = number;
export interface ListLandingZoneOperationsInput {
    filter?: LandingZoneOperationFilter;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListLandingZoneOperationsInput: S.Schema<ListLandingZoneOperationsInput>;
export interface LandingZoneOperationSummary {
    operationType?: LandingZoneOperationType;
    operationIdentifier?: string;
    status?: LandingZoneOperationStatus;
}
export declare const LandingZoneOperationSummary: S.Schema<LandingZoneOperationSummary>;
export type LandingZoneOperations = LandingZoneOperationSummary[];
export declare const LandingZoneOperations: any;
export interface ListLandingZoneOperationsOutput {
    landingZoneOperations: LandingZoneOperationSummary[];
    nextToken?: string;
}
export declare const ListLandingZoneOperationsOutput: S.Schema<ListLandingZoneOperationsOutput>;
export type ListLandingZonesMaxResults = number;
export interface ListLandingZonesInput {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListLandingZonesInput: S.Schema<ListLandingZonesInput>;
export interface LandingZoneSummary {
    arn?: string;
}
export declare const LandingZoneSummary: S.Schema<LandingZoneSummary>;
export type LandingZoneSummaries = LandingZoneSummary[];
export declare const LandingZoneSummaries: any;
export interface ListLandingZonesOutput {
    landingZones: LandingZoneSummary[];
    nextToken?: string;
}
export declare const ListLandingZonesOutput: S.Schema<ListLandingZonesOutput>;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export declare const ListTagsForResourceInput: S.Schema<ListTagsForResourceInput>;
export interface ListTagsForResourceOutput {
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceOutput: S.Schema<ListTagsForResourceOutput>;
export interface ResetEnabledBaselineInput {
    enabledBaselineIdentifier: string;
}
export declare const ResetEnabledBaselineInput: S.Schema<ResetEnabledBaselineInput>;
export interface ResetEnabledBaselineOutput {
    operationIdentifier: string;
}
export declare const ResetEnabledBaselineOutput: S.Schema<ResetEnabledBaselineOutput>;
export interface ResetEnabledControlInput {
    enabledControlIdentifier: string;
}
export declare const ResetEnabledControlInput: S.Schema<ResetEnabledControlInput>;
export interface ResetEnabledControlOutput {
    operationIdentifier: string;
}
export declare const ResetEnabledControlOutput: S.Schema<ResetEnabledControlOutput>;
export interface ResetLandingZoneInput {
    landingZoneIdentifier: string;
}
export declare const ResetLandingZoneInput: S.Schema<ResetLandingZoneInput>;
export interface ResetLandingZoneOutput {
    operationIdentifier: string;
}
export declare const ResetLandingZoneOutput: S.Schema<ResetLandingZoneOutput>;
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceInput: S.Schema<TagResourceInput>;
export interface TagResourceOutput {
}
export declare const TagResourceOutput: S.Schema<TagResourceOutput>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceInput: S.Schema<UntagResourceInput>;
export interface UntagResourceOutput {
}
export declare const UntagResourceOutput: S.Schema<UntagResourceOutput>;
export interface UpdateEnabledBaselineInput {
    baselineVersion: string;
    parameters?: EnabledBaselineParameter[];
    enabledBaselineIdentifier: string;
}
export declare const UpdateEnabledBaselineInput: S.Schema<UpdateEnabledBaselineInput>;
export interface UpdateEnabledBaselineOutput {
    operationIdentifier: string;
}
export declare const UpdateEnabledBaselineOutput: S.Schema<UpdateEnabledBaselineOutput>;
export interface UpdateEnabledControlInput {
    parameters: EnabledControlParameter[];
    enabledControlIdentifier: string;
}
export declare const UpdateEnabledControlInput: S.Schema<UpdateEnabledControlInput>;
export interface UpdateEnabledControlOutput {
    operationIdentifier: string;
}
export declare const UpdateEnabledControlOutput: S.Schema<UpdateEnabledControlOutput>;
export interface UpdateLandingZoneInput {
    version: string;
    remediationTypes?: RemediationType[];
    landingZoneIdentifier: string;
    manifest?: any;
}
export declare const UpdateLandingZoneInput: S.Schema<UpdateLandingZoneInput>;
export interface UpdateLandingZoneOutput {
    operationIdentifier: string;
}
export declare const UpdateLandingZoneOutput: S.Schema<UpdateLandingZoneOutput>;
export type CreateLandingZoneError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a new landing zone. This API call starts an asynchronous operation that creates and configures a landing zone, based on the parameters specified in the manifest JSON file.
 */
export declare const createLandingZone: API.OperationMethod<CreateLandingZoneInput, CreateLandingZoneOutput, CreateLandingZoneError, Credentials | HttpClient.HttpClient>;
export type DeleteLandingZoneError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Decommissions a landing zone. This API call starts an asynchronous operation that deletes Amazon Web Services Control Tower resources deployed in accounts managed by Amazon Web Services Control Tower.
 *
 * Decommissioning a landing zone is a process with significant consequences, and it cannot be undone. We strongly recommend that you perform this decommissioning process only if you intend to stop using your landing zone.
 */
export declare const deleteLandingZone: API.OperationMethod<DeleteLandingZoneInput, DeleteLandingZoneOutput, DeleteLandingZoneError, Credentials | HttpClient.HttpClient>;
export type DisableBaselineError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Disable an `EnabledBaseline` resource on the specified Target. This API starts an asynchronous operation to remove all resources deployed as part of the baseline enablement. The resource will vary depending on the enabled baseline. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const disableBaseline: API.OperationMethod<DisableBaselineInput, DisableBaselineOutput, DisableBaselineError, Credentials | HttpClient.HttpClient>;
export type DisableControlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This API call turns off a control. It starts an asynchronous operation that deletes Amazon Web Services resources on the specified organizational unit and the accounts it contains. The resources will vary according to the control that you specify. For usage examples, see the *Controls Reference Guide* .
 */
export declare const disableControl: API.OperationMethod<DisableControlInput, DisableControlOutput, DisableControlError, Credentials | HttpClient.HttpClient>;
export type EnableBaselineError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Enable (apply) a `Baseline` to a Target. This API starts an asynchronous operation to deploy resources specified by the `Baseline` to the specified Target. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const enableBaseline: API.OperationMethod<EnableBaselineInput, EnableBaselineOutput, EnableBaselineError, Credentials | HttpClient.HttpClient>;
export type EnableControlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This API call activates a control. It starts an asynchronous operation that creates Amazon Web Services resources on the specified organizational unit and the accounts it contains. The resources created will vary according to the control that you specify. For usage examples, see the *Controls Reference Guide* .
 */
export declare const enableControl: API.OperationMethod<EnableControlInput, EnableControlOutput, EnableControlError, Credentials | HttpClient.HttpClient>;
export type GetBaselineError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Retrieve details about an existing `Baseline` resource by specifying its identifier. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const getBaseline: API.OperationMethod<GetBaselineInput, GetBaselineOutput, GetBaselineError, Credentials | HttpClient.HttpClient>;
export type GetBaselineOperationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Returns the details of an asynchronous baseline operation, as initiated by any of these APIs: `EnableBaseline`, `DisableBaseline`, `UpdateEnabledBaseline`, `ResetEnabledBaseline`. A status message is displayed in case of operation failure. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const getBaselineOperation: API.OperationMethod<GetBaselineOperationInput, GetBaselineOperationOutput, GetBaselineOperationError, Credentials | HttpClient.HttpClient>;
export type GetControlOperationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the status of a particular `EnableControl` or `DisableControl` operation. Displays a message in case of error. Details for an operation are available for 90 days. For usage examples, see the *Controls Reference Guide* .
 */
export declare const getControlOperation: API.OperationMethod<GetControlOperationInput, GetControlOperationOutput, GetControlOperationError, Credentials | HttpClient.HttpClient>;
export type GetEnabledBaselineError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Retrieve details of an `EnabledBaseline` resource by specifying its identifier.
 */
export declare const getEnabledBaseline: API.OperationMethod<GetEnabledBaselineInput, GetEnabledBaselineOutput, GetEnabledBaselineError, Credentials | HttpClient.HttpClient>;
export type GetEnabledControlError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about an enabled control. For usage examples, see the *Controls Reference Guide* .
 */
export declare const getEnabledControl: API.OperationMethod<GetEnabledControlInput, GetEnabledControlOutput, GetEnabledControlError, Credentials | HttpClient.HttpClient>;
export type GetLandingZoneError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Returns details about the landing zone. Displays a message in case of error.
 */
export declare const getLandingZone: API.OperationMethod<GetLandingZoneInput, GetLandingZoneOutput, GetLandingZoneError, Credentials | HttpClient.HttpClient>;
export type GetLandingZoneOperationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Returns the status of the specified landing zone operation. Details for an operation are available for 90 days.
 */
export declare const getLandingZoneOperation: API.OperationMethod<GetLandingZoneOperationInput, GetLandingZoneOperationOutput, GetLandingZoneOperationError, Credentials | HttpClient.HttpClient>;
export type ListBaselinesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Returns a summary list of all available baselines. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const listBaselines: API.PaginatedOperationMethod<ListBaselinesInput, ListBaselinesOutput, ListBaselinesError, Credentials | HttpClient.HttpClient, BaselineSummary>;
export type ListControlOperationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides a list of operations in progress or queued. For usage examples, see ListControlOperation examples.
 */
export declare const listControlOperations: API.PaginatedOperationMethod<ListControlOperationsInput, ListControlOperationsOutput, ListControlOperationsError, Credentials | HttpClient.HttpClient, ControlOperationSummary>;
export type ListEnabledBaselinesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of summaries describing `EnabledBaseline` resources. You can filter the list by the corresponding `Baseline` or `Target` of the `EnabledBaseline` resources. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const listEnabledBaselines: API.PaginatedOperationMethod<ListEnabledBaselinesInput, ListEnabledBaselinesOutput, ListEnabledBaselinesError, Credentials | HttpClient.HttpClient, EnabledBaselineSummary>;
export type ListEnabledControlsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the controls enabled by Amazon Web Services Control Tower on the specified organizational unit and the accounts it contains. For usage examples, see the *Controls Reference Guide* .
 */
export declare const listEnabledControls: API.PaginatedOperationMethod<ListEnabledControlsInput, ListEnabledControlsOutput, ListEnabledControlsError, Credentials | HttpClient.HttpClient, EnabledControlSummary>;
export type ListLandingZoneOperationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists all landing zone operations from the past 90 days. Results are sorted by time, with the most recent operation first.
 */
export declare const listLandingZoneOperations: API.PaginatedOperationMethod<ListLandingZoneOperationsInput, ListLandingZoneOperationsOutput, ListLandingZoneOperationsError, Credentials | HttpClient.HttpClient, LandingZoneOperationSummary>;
export type ListLandingZonesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Returns the landing zone ARN for the landing zone deployed in your managed account. This API also creates an ARN for existing accounts that do not yet have a landing zone ARN.
 *
 * Returns one landing zone ARN.
 */
export declare const listLandingZones: API.PaginatedOperationMethod<ListLandingZonesInput, ListLandingZonesOutput, ListLandingZonesError, Credentials | HttpClient.HttpClient, LandingZoneSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | BadRequestException | CommonErrors;
/**
 * Returns a list of tags associated with the resource. For usage examples, see the *Controls Reference Guide* .
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ResetEnabledBaselineError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Re-enables an `EnabledBaseline` resource. For example, this API can re-apply the existing `Baseline` after a new member account is moved to the target OU. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const resetEnabledBaseline: API.OperationMethod<ResetEnabledBaselineInput, ResetEnabledBaselineOutput, ResetEnabledBaselineError, Credentials | HttpClient.HttpClient>;
export type ResetEnabledControlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Resets an enabled control. Does not work for controls implemented with SCPs.
 */
export declare const resetEnabledControl: API.OperationMethod<ResetEnabledControlInput, ResetEnabledControlOutput, ResetEnabledControlError, Credentials | HttpClient.HttpClient>;
export type ResetLandingZoneError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * This API call resets a landing zone. It starts an asynchronous operation that resets the landing zone to the parameters specified in the original configuration, which you specified in the manifest file. Nothing in the manifest file's original landing zone configuration is changed during the reset process, by default. This API is not the same as a rollback of a landing zone version, which is not a supported operation.
 */
export declare const resetLandingZone: API.OperationMethod<ResetLandingZoneInput, ResetLandingZoneOutput, ResetLandingZoneError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | BadRequestException | CommonErrors;
/**
 * Applies tags to a resource. For usage examples, see the *Controls Reference Guide* .
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | BadRequestException | CommonErrors;
/**
 * Removes tags from a resource. For usage examples, see the *Controls Reference Guide* .
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEnabledBaselineError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates an `EnabledBaseline` resource's applied parameters or version. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const updateEnabledBaseline: API.OperationMethod<UpdateEnabledBaselineInput, UpdateEnabledBaselineOutput, UpdateEnabledBaselineError, Credentials | HttpClient.HttpClient>;
export type UpdateEnabledControlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an already enabled control.
 *
 * If the enabled control shows an `EnablementStatus` of SUCCEEDED, supply parameters that are different from the currently configured parameters. Otherwise, Amazon Web Services Control Tower will not accept the request.
 *
 * If the enabled control shows an `EnablementStatus` of FAILED, Amazon Web Services Control Tower updates the control to match any valid parameters that you supply.
 *
 * If the `DriftSummary` status for the control shows as `DRIFTED`, you cannot call this API. Instead, you can update the control by calling the `ResetEnabledControl` API. Alternatively, you can call `DisableControl` and then call `EnableControl` again. Also, you can run an extending governance operation to repair drift. For usage examples, see the *Controls Reference Guide* .
 */
export declare const updateEnabledControl: API.OperationMethod<UpdateEnabledControlInput, UpdateEnabledControlOutput, UpdateEnabledControlError, Credentials | HttpClient.HttpClient>;
export type UpdateLandingZoneError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * This API call updates the landing zone. It starts an asynchronous operation that updates the landing zone based on the new landing zone version, or on the changed parameters specified in the updated manifest file.
 */
export declare const updateLandingZone: API.OperationMethod<UpdateLandingZoneInput, UpdateLandingZoneOutput, UpdateLandingZoneError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=controltower.d.ts.map