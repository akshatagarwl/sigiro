import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type InvocationArn = string;
export interface GetDataAutomationStatusRequest {
    invocationArn: string;
}
export declare const GetDataAutomationStatusRequest: S.Schema<GetDataAutomationStatusRequest>;
export type AutomationJobStatus = "Created" | "InProgress" | "Success" | "ServiceError" | "ClientError" | (string & {});
export declare const AutomationJobStatus: any;
export type S3Uri = string;
export interface OutputConfiguration {
    s3Uri: string;
}
export declare const OutputConfiguration: S.Schema<OutputConfiguration>;
export interface GetDataAutomationStatusResponse {
    status?: AutomationJobStatus;
    errorType?: string;
    errorMessage?: string;
    outputConfiguration?: OutputConfiguration;
    jobSubmissionTime?: Date;
    jobCompletionTime?: Date;
    jobDurationInSeconds?: number;
}
export declare const GetDataAutomationStatusResponse: S.Schema<GetDataAutomationStatusResponse>;
export interface SyncInputConfiguration {
    bytes?: Uint8Array;
    s3Uri?: string;
}
export declare const SyncInputConfiguration: S.Schema<SyncInputConfiguration>;
export type DataAutomationArn = string;
export type DataAutomationStage = "LIVE" | "DEVELOPMENT" | (string & {});
export declare const DataAutomationStage: any;
export interface DataAutomationConfiguration {
    dataAutomationProjectArn: string;
    stage?: DataAutomationStage;
}
export declare const DataAutomationConfiguration: S.Schema<DataAutomationConfiguration>;
export type BlueprintArn = string;
export type BlueprintVersion = string;
export type BlueprintStage = "DEVELOPMENT" | "LIVE" | (string & {});
export declare const BlueprintStage: any;
export interface Blueprint {
    blueprintArn: string;
    version?: string;
    stage?: BlueprintStage;
}
export declare const Blueprint: S.Schema<Blueprint>;
export type BlueprintList = Blueprint[];
export declare const BlueprintList: any;
export type DataAutomationProfileArn = string;
export type KMSKeyId = string;
export type EncryptionContextKey = string;
export type EncryptionContextValue = string;
export type EncryptionContextMap = {
    [key: string]: string | undefined;
};
export declare const EncryptionContextMap: any;
export interface EncryptionConfiguration {
    kmsKeyId: string;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    };
}
export declare const EncryptionConfiguration: S.Schema<EncryptionConfiguration>;
export interface InvokeDataAutomationRequest {
    inputConfiguration: SyncInputConfiguration;
    dataAutomationConfiguration?: DataAutomationConfiguration;
    blueprints?: Blueprint[];
    dataAutomationProfileArn: string;
    encryptionConfiguration?: EncryptionConfiguration;
    outputConfiguration?: OutputConfiguration;
}
export declare const InvokeDataAutomationRequest: S.Schema<InvokeDataAutomationRequest>;
export type SemanticModality = "DOCUMENT" | "IMAGE" | "AUDIO" | "VIDEO" | (string & {});
export declare const SemanticModality: any;
export type CustomOutputStatus = "MATCH" | "NO_MATCH" | (string & {});
export declare const CustomOutputStatus: any;
export interface OutputSegment {
    customOutputStatus?: CustomOutputStatus;
    customOutput?: string;
    standardOutput?: string;
}
export declare const OutputSegment: S.Schema<OutputSegment>;
export type OutputSegmentList = OutputSegment[];
export declare const OutputSegmentList: any;
export interface InvokeDataAutomationResponse {
    outputConfiguration?: OutputConfiguration;
    semanticModality: SemanticModality;
    outputSegments?: OutputSegment[];
}
export declare const InvokeDataAutomationResponse: S.Schema<InvokeDataAutomationResponse>;
export type IdempotencyToken = string;
export interface TimestampSegment {
    startTimeMillis: number;
    endTimeMillis: number;
}
export declare const TimestampSegment: S.Schema<TimestampSegment>;
export type VideoSegmentConfiguration = {
    timestampSegment: TimestampSegment;
};
export declare const VideoSegmentConfiguration: any;
export interface VideoAssetProcessingConfiguration {
    segmentConfiguration?: VideoSegmentConfiguration;
}
export declare const VideoAssetProcessingConfiguration: S.Schema<VideoAssetProcessingConfiguration>;
export interface AssetProcessingConfiguration {
    video?: VideoAssetProcessingConfiguration;
}
export declare const AssetProcessingConfiguration: S.Schema<AssetProcessingConfiguration>;
export interface InputConfiguration {
    s3Uri: string;
    assetProcessingConfiguration?: AssetProcessingConfiguration;
}
export declare const InputConfiguration: S.Schema<InputConfiguration>;
export interface EventBridgeConfiguration {
    eventBridgeEnabled: boolean;
}
export declare const EventBridgeConfiguration: S.Schema<EventBridgeConfiguration>;
export interface NotificationConfiguration {
    eventBridgeConfiguration: EventBridgeConfiguration;
}
export declare const NotificationConfiguration: S.Schema<NotificationConfiguration>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface InvokeDataAutomationAsyncRequest {
    clientToken?: string;
    inputConfiguration: InputConfiguration;
    outputConfiguration: OutputConfiguration;
    dataAutomationConfiguration?: DataAutomationConfiguration;
    encryptionConfiguration?: EncryptionConfiguration;
    notificationConfiguration?: NotificationConfiguration;
    blueprints?: Blueprint[];
    dataAutomationProfileArn: string;
    tags?: Tag[];
}
export declare const InvokeDataAutomationAsyncRequest: S.Schema<InvokeDataAutomationAsyncRequest>;
export interface InvokeDataAutomationAsyncResponse {
    invocationArn: string;
}
export declare const InvokeDataAutomationAsyncResponse: S.Schema<InvokeDataAutomationAsyncResponse>;
export type TaggableResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TagResourceRequest {
    resourceARN: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type NonBlankString = string;
export type GetDataAutomationStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * API used to get data automation status.
 */
export declare const getDataAutomationStatus: API.OperationMethod<GetDataAutomationStatusRequest, GetDataAutomationStatusResponse, GetDataAutomationStatusError, Credentials | HttpClient.HttpClient>;
export type InvokeDataAutomationError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sync API: Invoke data automation.
 */
export declare const invokeDataAutomation: API.OperationMethod<InvokeDataAutomationRequest, InvokeDataAutomationResponse, InvokeDataAutomationError, Credentials | HttpClient.HttpClient>;
export type InvokeDataAutomationAsyncError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Async API: Invoke data automation.
 */
export declare const invokeDataAutomationAsync: API.OperationMethod<InvokeDataAutomationAsyncRequest, InvokeDataAutomationAsyncResponse, InvokeDataAutomationAsyncError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List tags for an Amazon Bedrock Data Automation resource
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tag an Amazon Bedrock Data Automation resource
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Untag an Amazon Bedrock Data Automation resource
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-data-automation-runtime.d.ts.map