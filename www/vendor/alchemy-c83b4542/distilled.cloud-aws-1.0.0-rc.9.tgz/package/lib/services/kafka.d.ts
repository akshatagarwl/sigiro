import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ClusterConnectivityException_base: S.Class<ClusterConnectivityException, S.TaggedStruct<"ClusterConnectivityException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ClusterConnectivityException extends /*@__PURE__*/ ClusterConnectivityException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ControllerMovedException_base: S.Class<ControllerMovedException, S.TaggedStruct<"ControllerMovedException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ControllerMovedException extends /*@__PURE__*/ ControllerMovedException_base {
}
declare const ForbiddenException_base: S.Class<ForbiddenException, S.TaggedStruct<"ForbiddenException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GroupSubscribedToTopicException_base: S.Class<GroupSubscribedToTopicException, S.TaggedStruct<"GroupSubscribedToTopicException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class GroupSubscribedToTopicException extends /*@__PURE__*/ GroupSubscribedToTopicException_base {
}
declare const InternalServerErrorException_base: S.Class<InternalServerErrorException, S.TaggedStruct<"InternalServerErrorException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const KafkaRequestException_base: S.Class<KafkaRequestException, S.TaggedStruct<"KafkaRequestException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KafkaRequestException extends /*@__PURE__*/ KafkaRequestException_base {
}
declare const KafkaTimeoutException_base: S.Class<KafkaTimeoutException, S.TaggedStruct<"KafkaTimeoutException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class KafkaTimeoutException extends /*@__PURE__*/ KafkaTimeoutException_base {
}
declare const NotControllerException_base: S.Class<NotControllerException, S.TaggedStruct<"NotControllerException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class NotControllerException extends /*@__PURE__*/ NotControllerException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ReassignmentInProgressException_base: S.Class<ReassignmentInProgressException, S.TaggedStruct<"ReassignmentInProgressException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ReassignmentInProgressException extends /*@__PURE__*/ ReassignmentInProgressException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const TopicExistsException_base: S.Class<TopicExistsException, S.TaggedStruct<"TopicExistsException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class TopicExistsException extends /*@__PURE__*/ TopicExistsException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const UnknownTopicOrPartitionException_base: S.Class<UnknownTopicOrPartitionException, S.TaggedStruct<"UnknownTopicOrPartitionException", {
    readonly InvalidParameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnknownTopicOrPartitionException extends /*@__PURE__*/ UnknownTopicOrPartitionException_base {
}
export type __listOf__string = string[];
export declare const __listOf__string: any;
export interface BatchAssociateScramSecretRequest {
    ClusterArn: string;
    SecretArnList?: string[];
}
export declare const BatchAssociateScramSecretRequest: S.Schema<BatchAssociateScramSecretRequest>;
export interface UnprocessedScramSecret {
    ErrorCode?: string;
    ErrorMessage?: string;
    SecretArn?: string;
}
export declare const UnprocessedScramSecret: S.Schema<UnprocessedScramSecret>;
export type __listOfUnprocessedScramSecret = UnprocessedScramSecret[];
export declare const __listOfUnprocessedScramSecret: any;
export interface BatchAssociateScramSecretResponse {
    ClusterArn?: string;
    UnprocessedScramSecrets?: UnprocessedScramSecret[];
}
export declare const BatchAssociateScramSecretResponse: S.Schema<BatchAssociateScramSecretResponse>;
export interface BatchDisassociateScramSecretRequest {
    ClusterArn: string;
    SecretArnList?: string[];
}
export declare const BatchDisassociateScramSecretRequest: S.Schema<BatchDisassociateScramSecretRequest>;
export interface BatchDisassociateScramSecretResponse {
    ClusterArn?: string;
    UnprocessedScramSecrets?: UnprocessedScramSecret[];
}
export declare const BatchDisassociateScramSecretResponse: S.Schema<BatchDisassociateScramSecretResponse>;
export interface EncryptionConfiguration {
    KmsKeyArn?: string;
}
export declare const EncryptionConfiguration: S.Schema<EncryptionConfiguration>;
export interface Catalog {
    CatalogArn?: string;
    WarehouseLocation?: string;
}
export declare const Catalog: S.Schema<Catalog>;
export interface DeadLetterQueueS3 {
    BucketArn?: string;
    ErrorOutputPrefix?: string;
    ExpectedBucketOwner?: string;
}
export declare const DeadLetterQueueS3: S.Schema<DeadLetterQueueS3>;
export type PartitionStrategy = "TIME_HOUR" | (string & {});
export declare const PartitionStrategy: any;
export interface PartitionSource {
    SourceName?: string;
}
export declare const PartitionSource: S.Schema<PartitionSource>;
export type __listOfPartitionSource = PartitionSource[];
export declare const __listOfPartitionSource: any;
export interface PartitionSpec {
    PartitionStrategy?: PartitionStrategy;
    SourceList?: PartitionSource[];
}
export declare const PartitionSpec: S.Schema<PartitionSpec>;
export interface DestinationTable {
    DestinationDatabaseName?: string;
    DestinationTableName?: string;
    PartitionSpec?: PartitionSpec;
}
export declare const DestinationTable: S.Schema<DestinationTable>;
export type __listOfDestinationTable = DestinationTable[];
export declare const __listOfDestinationTable: any;
export interface SchemaEvolution {
    EnableSchemaEvolution?: boolean;
}
export declare const SchemaEvolution: S.Schema<SchemaEvolution>;
export interface TableCreation {
    EnableTableCreation?: boolean;
}
export declare const TableCreation: S.Schema<TableCreation>;
export type IcebergCompressionType = "ZSTD" | "SNAPPY" | (string & {});
export declare const IcebergCompressionType: any;
export interface IcebergDestinationConfiguration {
    AppendOnly?: boolean;
    Catalog?: Catalog;
    DataFreshnessInSeconds?: number;
    DeadLetterQueueS3?: DeadLetterQueueS3;
    DestinationTableList?: DestinationTable[];
    SchemaEvolution?: SchemaEvolution;
    ServiceExecutionRoleArn?: string;
    TableCreation?: TableCreation;
    CompressionType?: IcebergCompressionType;
}
export declare const IcebergDestinationConfiguration: S.Schema<IcebergDestinationConfiguration>;
export type S3CompressionType = "NONE" | "GZIP" | "ZSTD" | (string & {});
export declare const S3CompressionType: any;
export type S3StorageClass = "STANDARD" | "INTELLIGENT_TIERING" | "GLACIER_IR" | (string & {});
export declare const S3StorageClass: any;
export interface S3Storage {
    BucketArn?: string;
    CompressionType?: S3CompressionType;
    OutputPrefix?: string;
    OutputKeyTemplate?: string;
    StorageClass?: S3StorageClass;
    ExpectedBucketOwner?: string;
}
export declare const S3Storage: S.Schema<S3Storage>;
export interface S3DestinationConfiguration {
    DataFreshnessInSeconds?: number;
    DeadLetterQueueS3?: DeadLetterQueueS3;
    ServiceExecutionRoleArn?: string;
    Storage?: S3Storage;
}
export declare const S3DestinationConfiguration: S.Schema<S3DestinationConfiguration>;
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export declare const __mapOf__string: any;
export type ValueConverter = "BYTE_ARRAY" | "JSON" | "JSON_SCHEMA_GSR" | "STRING" | (string & {});
export declare const ValueConverter: any;
export interface RecordConverter {
    ValueConverter?: ValueConverter;
}
export declare const RecordConverter: S.Schema<RecordConverter>;
export interface RecordSchema {
    GsrArn?: string;
}
export declare const RecordSchema: S.Schema<RecordSchema>;
export interface TopicConfiguration {
    RecordConverter?: RecordConverter;
    RecordSchema?: RecordSchema;
    TopicArn?: string;
}
export declare const TopicConfiguration: S.Schema<TopicConfiguration>;
export type __listOfTopicConfiguration = TopicConfiguration[];
export declare const __listOfTopicConfiguration: any;
export interface CloudWatchLogs {
    Enabled?: boolean;
    LogGroup?: string;
}
export declare const CloudWatchLogs: S.Schema<CloudWatchLogs>;
export interface Firehose {
    DeliveryStream?: string;
    Enabled?: boolean;
}
export declare const Firehose: S.Schema<Firehose>;
export interface S3 {
    Bucket?: string;
    Enabled?: boolean;
    Prefix?: string;
}
export declare const S3: S.Schema<S3>;
export interface ChannelLoggingInfo {
    CloudWatchLogs?: CloudWatchLogs;
    Firehose?: Firehose;
    S3?: S3;
}
export declare const ChannelLoggingInfo: S.Schema<ChannelLoggingInfo>;
export interface CreateChannelRequest {
    ChannelName?: string;
    ClusterArn: string;
    EncryptionConfiguration?: EncryptionConfiguration;
    IcebergDestinationConfiguration?: IcebergDestinationConfiguration;
    S3DestinationConfiguration?: S3DestinationConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
    TopicConfigurationList?: TopicConfiguration[];
    LoggingInfo?: ChannelLoggingInfo;
}
export declare const CreateChannelRequest: S.Schema<CreateChannelRequest>;
export interface CreateChannelResponse {
    ChannelArn: string;
    ClusterOperationArn?: string;
}
export declare const CreateChannelResponse: S.Schema<CreateChannelResponse>;
export type BrokerAZDistribution = "DEFAULT" | (string & {});
export declare const BrokerAZDistribution: any;
export type __stringMin5Max32 = string;
export interface ProvisionedThroughput {
    Enabled?: boolean;
    VolumeThroughput?: number;
}
export declare const ProvisionedThroughput: S.Schema<ProvisionedThroughput>;
export type __integerMin1Max16384 = number;
export interface EBSStorageInfo {
    ProvisionedThroughput?: ProvisionedThroughput;
    VolumeSize?: number;
}
export declare const EBSStorageInfo: S.Schema<EBSStorageInfo>;
export interface StorageInfo {
    EbsStorageInfo?: EBSStorageInfo;
}
export declare const StorageInfo: S.Schema<StorageInfo>;
export interface PublicAccess {
    Type?: string;
}
export declare const PublicAccess: S.Schema<PublicAccess>;
export interface VpcConnectivityScram {
    Enabled?: boolean;
}
export declare const VpcConnectivityScram: S.Schema<VpcConnectivityScram>;
export interface VpcConnectivityIam {
    Enabled?: boolean;
}
export declare const VpcConnectivityIam: S.Schema<VpcConnectivityIam>;
export interface VpcConnectivitySasl {
    Scram?: VpcConnectivityScram;
    Iam?: VpcConnectivityIam;
}
export declare const VpcConnectivitySasl: S.Schema<VpcConnectivitySasl>;
export interface VpcConnectivityTls {
    Enabled?: boolean;
}
export declare const VpcConnectivityTls: S.Schema<VpcConnectivityTls>;
export interface VpcConnectivityClientAuthentication {
    Sasl?: VpcConnectivitySasl;
    Tls?: VpcConnectivityTls;
}
export declare const VpcConnectivityClientAuthentication: S.Schema<VpcConnectivityClientAuthentication>;
export interface VpcConnectivity {
    ClientAuthentication?: VpcConnectivityClientAuthentication;
}
export declare const VpcConnectivity: S.Schema<VpcConnectivity>;
export type NetworkType = "IPV4" | "DUAL" | (string & {});
export declare const NetworkType: any;
export interface ConnectivityInfo {
    PublicAccess?: PublicAccess;
    VpcConnectivity?: VpcConnectivity;
    NetworkType?: NetworkType;
}
export declare const ConnectivityInfo: S.Schema<ConnectivityInfo>;
export interface BrokerNodeGroupInfo {
    BrokerAZDistribution?: BrokerAZDistribution;
    ClientSubnets?: string[];
    InstanceType?: string;
    SecurityGroups?: string[];
    StorageInfo?: StorageInfo;
    ConnectivityInfo?: ConnectivityInfo;
    ZoneIds?: string[];
}
export declare const BrokerNodeGroupInfo: S.Schema<BrokerNodeGroupInfo>;
export type RebalancingStatus = "PAUSED" | "ACTIVE" | (string & {});
export declare const RebalancingStatus: any;
export interface Rebalancing {
    Status?: RebalancingStatus;
}
export declare const Rebalancing: S.Schema<Rebalancing>;
export interface Scram {
    Enabled?: boolean;
}
export declare const Scram: S.Schema<Scram>;
export interface Iam {
    Enabled?: boolean;
}
export declare const Iam: S.Schema<Iam>;
export interface Sasl {
    Scram?: Scram;
    Iam?: Iam;
}
export declare const Sasl: S.Schema<Sasl>;
export interface Tls {
    CertificateAuthorityArnList?: string[];
    Enabled?: boolean;
}
export declare const Tls: S.Schema<Tls>;
export interface Unauthenticated {
    Enabled?: boolean;
}
export declare const Unauthenticated: S.Schema<Unauthenticated>;
export interface ClientAuthentication {
    Sasl?: Sasl;
    Tls?: Tls;
    Unauthenticated?: Unauthenticated;
}
export declare const ClientAuthentication: S.Schema<ClientAuthentication>;
export type __stringMin1Max64 = string;
export interface ConfigurationInfo {
    Arn?: string;
    Revision?: number;
}
export declare const ConfigurationInfo: S.Schema<ConfigurationInfo>;
export interface EncryptionAtRest {
    DataVolumeKMSKeyId?: string;
}
export declare const EncryptionAtRest: S.Schema<EncryptionAtRest>;
export type ClientBroker = "TLS" | "TLS_PLAINTEXT" | "PLAINTEXT" | (string & {});
export declare const ClientBroker: any;
export interface EncryptionInTransit {
    ClientBroker?: ClientBroker;
    InCluster?: boolean;
}
export declare const EncryptionInTransit: S.Schema<EncryptionInTransit>;
export interface EncryptionInfo {
    EncryptionAtRest?: EncryptionAtRest;
    EncryptionInTransit?: EncryptionInTransit;
}
export declare const EncryptionInfo: S.Schema<EncryptionInfo>;
export type EnhancedMonitoring = "DEFAULT" | "PER_BROKER" | "PER_TOPIC_PER_BROKER" | "PER_TOPIC_PER_PARTITION" | (string & {});
export declare const EnhancedMonitoring: any;
export interface JmxExporterInfo {
    EnabledInBroker?: boolean;
}
export declare const JmxExporterInfo: S.Schema<JmxExporterInfo>;
export interface NodeExporterInfo {
    EnabledInBroker?: boolean;
}
export declare const NodeExporterInfo: S.Schema<NodeExporterInfo>;
export interface PrometheusInfo {
    JmxExporter?: JmxExporterInfo;
    NodeExporter?: NodeExporterInfo;
}
export declare const PrometheusInfo: S.Schema<PrometheusInfo>;
export interface OpenMonitoringInfo {
    Prometheus?: PrometheusInfo;
}
export declare const OpenMonitoringInfo: S.Schema<OpenMonitoringInfo>;
export type __stringMin1Max128 = string;
export interface AuthorizerLogs {
    CloudWatchLogs?: CloudWatchLogs;
    Firehose?: Firehose;
    S3?: S3;
}
export declare const AuthorizerLogs: S.Schema<AuthorizerLogs>;
export interface BrokerLogs {
    CloudWatchLogs?: CloudWatchLogs;
    Firehose?: Firehose;
    S3?: S3;
}
export declare const BrokerLogs: S.Schema<BrokerLogs>;
export interface LoggingInfo {
    AuthorizerLogs?: AuthorizerLogs;
    BrokerLogs?: BrokerLogs;
}
export declare const LoggingInfo: S.Schema<LoggingInfo>;
export type __integerMin1Max15 = number;
export type StorageMode = "LOCAL" | "TIERED" | (string & {});
export declare const StorageMode: any;
export interface CreateClusterRequest {
    BrokerNodeGroupInfo?: BrokerNodeGroupInfo;
    Rebalancing?: Rebalancing;
    ClientAuthentication?: ClientAuthentication;
    ClusterName?: string;
    ConfigurationInfo?: ConfigurationInfo;
    EncryptionInfo?: EncryptionInfo;
    EnhancedMonitoring?: EnhancedMonitoring;
    OpenMonitoring?: OpenMonitoringInfo;
    KafkaVersion?: string;
    LoggingInfo?: LoggingInfo;
    NumberOfBrokerNodes?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    StorageMode?: StorageMode;
}
export declare const CreateClusterRequest: S.Schema<CreateClusterRequest>;
export type ClusterState = "ACTIVE" | "CREATING" | "DELETING" | "FAILED" | "HEALING" | "MAINTENANCE" | "REBOOTING_BROKER" | "UPDATING" | (string & {});
export declare const ClusterState: any;
export interface CreateClusterResponse {
    ClusterArn?: string;
    ClusterName?: string;
    State?: ClusterState;
}
export declare const CreateClusterResponse: S.Schema<CreateClusterResponse>;
export interface ProvisionedRequest {
    BrokerNodeGroupInfo?: BrokerNodeGroupInfo;
    Rebalancing?: Rebalancing;
    ClientAuthentication?: ClientAuthentication;
    ConfigurationInfo?: ConfigurationInfo;
    EncryptionInfo?: EncryptionInfo;
    EnhancedMonitoring?: EnhancedMonitoring;
    OpenMonitoring?: OpenMonitoringInfo;
    KafkaVersion?: string;
    LoggingInfo?: LoggingInfo;
    NumberOfBrokerNodes?: number;
    StorageMode?: StorageMode;
}
export declare const ProvisionedRequest: S.Schema<ProvisionedRequest>;
export interface VpcConfig {
    SubnetIds?: string[];
    SecurityGroupIds?: string[];
}
export declare const VpcConfig: S.Schema<VpcConfig>;
export type __listOfVpcConfig = VpcConfig[];
export declare const __listOfVpcConfig: any;
export interface ServerlessSasl {
    Iam?: Iam;
}
export declare const ServerlessSasl: S.Schema<ServerlessSasl>;
export interface ServerlessClientAuthentication {
    Sasl?: ServerlessSasl;
}
export declare const ServerlessClientAuthentication: S.Schema<ServerlessClientAuthentication>;
export interface ServerlessRequest {
    VpcConfigs?: VpcConfig[];
    ClientAuthentication?: ServerlessClientAuthentication;
}
export declare const ServerlessRequest: S.Schema<ServerlessRequest>;
export interface CreateClusterV2Request {
    ClusterName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Provisioned?: ProvisionedRequest;
    Serverless?: ServerlessRequest;
}
export declare const CreateClusterV2Request: S.Schema<CreateClusterV2Request>;
export type ClusterType = "PROVISIONED" | "SERVERLESS" | (string & {});
export declare const ClusterType: any;
export interface CreateClusterV2Response {
    ClusterArn?: string;
    ClusterName?: string;
    State?: ClusterState;
    ClusterType?: ClusterType;
}
export declare const CreateClusterV2Response: S.Schema<CreateClusterV2Response>;
export type __blob = Uint8Array;
export interface CreateConfigurationRequest {
    Description?: string;
    KafkaVersions?: string[];
    Name?: string;
    ServerProperties?: Uint8Array;
}
export declare const CreateConfigurationRequest: S.Schema<CreateConfigurationRequest>;
export type __timestampIso8601 = Date;
export interface ConfigurationRevision {
    CreationTime?: Date;
    Description?: string;
    Revision?: number;
}
export declare const ConfigurationRevision: S.Schema<ConfigurationRevision>;
export type ConfigurationState = "ACTIVE" | "DELETING" | "DELETE_FAILED" | (string & {});
export declare const ConfigurationState: any;
export interface CreateConfigurationResponse {
    Arn?: string;
    CreationTime?: Date;
    LatestRevision?: ConfigurationRevision & {
        CreationTime: __timestampIso8601;
        Revision: number;
    };
    Name?: string;
    State?: ConfigurationState;
}
export declare const CreateConfigurationResponse: S.Schema<CreateConfigurationResponse>;
export type __stringMax1024 = string;
export interface AmazonMskCluster {
    MskClusterArn?: string;
}
export declare const AmazonMskCluster: S.Schema<AmazonMskCluster>;
export interface ApacheKafkaCluster {
    ApacheKafkaClusterId?: string;
    BootstrapBrokerString?: string;
}
export declare const ApacheKafkaCluster: S.Schema<ApacheKafkaCluster>;
export interface KafkaClusterClientVpcConfig {
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
}
export declare const KafkaClusterClientVpcConfig: S.Schema<KafkaClusterClientVpcConfig>;
export type KafkaClusterSaslScramMechanism = "SHA256" | "SHA512" | (string & {});
export declare const KafkaClusterSaslScramMechanism: any;
export interface KafkaClusterSaslScramAuthentication {
    Mechanism?: KafkaClusterSaslScramMechanism;
    SecretArn?: string;
}
export declare const KafkaClusterSaslScramAuthentication: S.Schema<KafkaClusterSaslScramAuthentication>;
export interface KafkaClusterMTLSAuthentication {
    SecretArn?: string;
}
export declare const KafkaClusterMTLSAuthentication: S.Schema<KafkaClusterMTLSAuthentication>;
export interface KafkaClusterOAuthClientCredentials {
    TokenRequestSecretArn?: string;
}
export declare const KafkaClusterOAuthClientCredentials: S.Schema<KafkaClusterOAuthClientCredentials>;
export type JwtSigningAlgorithm = "RS256" | "ES384" | (string & {});
export declare const JwtSigningAlgorithm: any;
export interface KafkaClusterOAuthIamJwtBearer {
    Audience?: string;
    SigningAlgorithm?: JwtSigningAlgorithm;
    TokenRequestSecretArn?: string;
}
export declare const KafkaClusterOAuthIamJwtBearer: S.Schema<KafkaClusterOAuthIamJwtBearer>;
export interface KafkaClusterOAuthClientCredentialsAssertion {
    Audience?: string;
    SigningAlgorithm?: JwtSigningAlgorithm;
    TokenRequestSecretArn?: string;
}
export declare const KafkaClusterOAuthClientCredentialsAssertion: S.Schema<KafkaClusterOAuthClientCredentialsAssertion>;
export type TokenEndpointAuthenticationMethod = "POST" | "BASIC" | "NONE" | (string & {});
export declare const TokenEndpointAuthenticationMethod: any;
export interface KafkaClusterSaslOAuthBearerAuthentication {
    TokenEndpointUrl?: string;
    ClientCredentials?: KafkaClusterOAuthClientCredentials;
    IamJwtBearer?: KafkaClusterOAuthIamJwtBearer;
    ClientCredentialsAssertion?: KafkaClusterOAuthClientCredentialsAssertion;
    TokenEndpointAuthenticationMethod?: TokenEndpointAuthenticationMethod;
    Scope?: string;
    TokenEndpointTlsCertificateArn?: string;
}
export declare const KafkaClusterSaslOAuthBearerAuthentication: S.Schema<KafkaClusterSaslOAuthBearerAuthentication>;
export interface KafkaClusterClientAuthentication {
    SaslScram?: KafkaClusterSaslScramAuthentication;
    MTLS?: KafkaClusterMTLSAuthentication;
    SaslOAuthBearer?: KafkaClusterSaslOAuthBearerAuthentication;
}
export declare const KafkaClusterClientAuthentication: S.Schema<KafkaClusterClientAuthentication>;
export type KafkaClusterEncryptionInTransitType = "TLS" | (string & {});
export declare const KafkaClusterEncryptionInTransitType: any;
export interface KafkaClusterEncryptionInTransit {
    EncryptionType?: KafkaClusterEncryptionInTransitType;
    RootCaCertificate?: string;
}
export declare const KafkaClusterEncryptionInTransit: S.Schema<KafkaClusterEncryptionInTransit>;
export interface KafkaCluster {
    AmazonMskCluster?: AmazonMskCluster;
    ApacheKafkaCluster?: ApacheKafkaCluster;
    VpcConfig?: KafkaClusterClientVpcConfig;
    ClientAuthentication?: KafkaClusterClientAuthentication;
    EncryptionInTransit?: KafkaClusterEncryptionInTransit;
}
export declare const KafkaCluster: S.Schema<KafkaCluster>;
export type __listOfKafkaCluster = KafkaCluster[];
export declare const __listOfKafkaCluster: any;
export type __stringMax256 = string;
export type __listOf__stringMax256 = string[];
export declare const __listOf__stringMax256: any;
export type ConsumerGroupOffsetSyncMode = "LEGACY" | "ENHANCED" | (string & {});
export declare const ConsumerGroupOffsetSyncMode: any;
export interface ConsumerGroupReplication {
    ConsumerGroupsToExclude?: string[];
    ConsumerGroupsToReplicate?: string[];
    DetectAndCopyNewConsumerGroups?: boolean;
    SynchroniseConsumerGroupOffsets?: boolean;
    ConsumerGroupOffsetSyncMode?: ConsumerGroupOffsetSyncMode;
}
export declare const ConsumerGroupReplication: S.Schema<ConsumerGroupReplication>;
export type TargetCompressionType = "NONE" | "GZIP" | "SNAPPY" | "LZ4" | "ZSTD" | (string & {});
export declare const TargetCompressionType: any;
export type ReplicationStartingPositionType = "LATEST" | "EARLIEST" | (string & {});
export declare const ReplicationStartingPositionType: any;
export interface ReplicationStartingPosition {
    Type?: ReplicationStartingPositionType;
}
export declare const ReplicationStartingPosition: S.Schema<ReplicationStartingPosition>;
export type ReplicationTopicNameConfigurationType = "PREFIXED_WITH_SOURCE_CLUSTER_ALIAS" | "IDENTICAL" | (string & {});
export declare const ReplicationTopicNameConfigurationType: any;
export interface ReplicationTopicNameConfiguration {
    Type?: ReplicationTopicNameConfigurationType;
}
export declare const ReplicationTopicNameConfiguration: S.Schema<ReplicationTopicNameConfiguration>;
export type __stringMax249 = string;
export type __listOf__stringMax249 = string[];
export declare const __listOf__stringMax249: any;
export interface TopicReplication {
    CopyAccessControlListsForTopics?: boolean;
    CopyTopicConfigurations?: boolean;
    DetectAndCopyNewTopics?: boolean;
    StartingPosition?: ReplicationStartingPosition;
    TopicNameConfiguration?: ReplicationTopicNameConfiguration;
    TopicsToExclude?: string[];
    TopicsToReplicate?: string[];
}
export declare const TopicReplication: S.Schema<TopicReplication>;
export interface ReplicationInfo {
    ConsumerGroupReplication?: ConsumerGroupReplication;
    SourceKafkaClusterArn?: string;
    SourceKafkaClusterId?: string;
    TargetCompressionType?: TargetCompressionType;
    TargetKafkaClusterArn?: string;
    TargetKafkaClusterId?: string;
    TopicReplication?: TopicReplication;
}
export declare const ReplicationInfo: S.Schema<ReplicationInfo>;
export type __listOfReplicationInfo = ReplicationInfo[];
export declare const __listOfReplicationInfo: any;
export type __stringMin1Max128Pattern09AZaZ09AZaZ0 = string;
export interface ReplicatorCloudWatchLogs {
    Enabled?: boolean;
    LogGroup?: string;
}
export declare const ReplicatorCloudWatchLogs: S.Schema<ReplicatorCloudWatchLogs>;
export interface ReplicatorFirehose {
    Enabled?: boolean;
    DeliveryStream?: string;
}
export declare const ReplicatorFirehose: S.Schema<ReplicatorFirehose>;
export interface ReplicatorS3 {
    Enabled?: boolean;
    Bucket?: string;
    Prefix?: string;
}
export declare const ReplicatorS3: S.Schema<ReplicatorS3>;
export interface ReplicatorLogDelivery {
    CloudWatchLogs?: ReplicatorCloudWatchLogs;
    Firehose?: ReplicatorFirehose;
    S3?: ReplicatorS3;
}
export declare const ReplicatorLogDelivery: S.Schema<ReplicatorLogDelivery>;
export interface LogDelivery {
    ReplicatorLogDelivery?: ReplicatorLogDelivery;
}
export declare const LogDelivery: S.Schema<LogDelivery>;
export interface CreateReplicatorRequest {
    Description?: string;
    KafkaClusters?: KafkaCluster[];
    ReplicationInfoList?: ReplicationInfo[];
    ReplicatorName?: string;
    ServiceExecutionRoleArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    LogDelivery?: LogDelivery;
}
export declare const CreateReplicatorRequest: S.Schema<CreateReplicatorRequest>;
export type ReplicatorState = "RUNNING" | "CREATING" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export declare const ReplicatorState: any;
export interface CreateReplicatorResponse {
    ReplicatorArn?: string;
    ReplicatorName?: string;
    ReplicatorState?: ReplicatorState;
}
export declare const CreateReplicatorResponse: S.Schema<CreateReplicatorResponse>;
export type __integerMin1 = number;
export interface CreateTopicRequest {
    ClusterArn: string;
    TopicName?: string;
    PartitionCount?: number;
    ReplicationFactor?: number;
    Configs?: string;
}
export declare const CreateTopicRequest: S.Schema<CreateTopicRequest>;
export type TopicState = "CREATING" | "UPDATING" | "DELETING" | "ACTIVE" | (string & {});
export declare const TopicState: any;
export interface CreateTopicResponse {
    TopicArn?: string;
    TopicName?: string;
    Status?: TopicState;
}
export declare const CreateTopicResponse: S.Schema<CreateTopicResponse>;
export interface CreateVpcConnectionRequest {
    TargetClusterArn?: string;
    Authentication?: string;
    VpcId?: string;
    ClientSubnets?: string[];
    SecurityGroups?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateVpcConnectionRequest: S.Schema<CreateVpcConnectionRequest>;
export type VpcConnectionState = "CREATING" | "AVAILABLE" | "INACTIVE" | "DEACTIVATING" | "DELETING" | "FAILED" | "REJECTED" | "REJECTING" | (string & {});
export declare const VpcConnectionState: any;
export interface CreateVpcConnectionResponse {
    VpcConnectionArn?: string;
    State?: VpcConnectionState;
    Authentication?: string;
    VpcId?: string;
    ClientSubnets?: string[];
    SecurityGroups?: string[];
    CreationTime?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateVpcConnectionResponse: S.Schema<CreateVpcConnectionResponse>;
export interface DeleteChannelRequest {
    ChannelArn: string;
    ClusterArn: string;
}
export declare const DeleteChannelRequest: S.Schema<DeleteChannelRequest>;
export interface DeleteChannelResponse {
    ChannelArn: string;
    ClusterOperationArn?: string;
}
export declare const DeleteChannelResponse: S.Schema<DeleteChannelResponse>;
export interface DeleteClusterRequest {
    ClusterArn: string;
    CurrentVersion?: string;
}
export declare const DeleteClusterRequest: S.Schema<DeleteClusterRequest>;
export interface DeleteClusterResponse {
    ClusterArn?: string;
    State?: ClusterState;
}
export declare const DeleteClusterResponse: S.Schema<DeleteClusterResponse>;
export interface DeleteClusterPolicyRequest {
    ClusterArn: string;
}
export declare const DeleteClusterPolicyRequest: S.Schema<DeleteClusterPolicyRequest>;
export interface DeleteClusterPolicyResponse {
}
export declare const DeleteClusterPolicyResponse: S.Schema<DeleteClusterPolicyResponse>;
export interface DeleteConfigurationRequest {
    Arn: string;
}
export declare const DeleteConfigurationRequest: S.Schema<DeleteConfigurationRequest>;
export interface DeleteConfigurationResponse {
    Arn?: string;
    State?: ConfigurationState;
}
export declare const DeleteConfigurationResponse: S.Schema<DeleteConfigurationResponse>;
export interface DeleteReplicatorRequest {
    CurrentVersion?: string;
    ReplicatorArn: string;
}
export declare const DeleteReplicatorRequest: S.Schema<DeleteReplicatorRequest>;
export interface DeleteReplicatorResponse {
    ReplicatorArn?: string;
    ReplicatorState?: ReplicatorState;
}
export declare const DeleteReplicatorResponse: S.Schema<DeleteReplicatorResponse>;
export interface DeleteTopicRequest {
    ClusterArn: string;
    TopicName: string;
}
export declare const DeleteTopicRequest: S.Schema<DeleteTopicRequest>;
export interface DeleteTopicResponse {
    TopicArn?: string;
    TopicName?: string;
    Status?: TopicState;
}
export declare const DeleteTopicResponse: S.Schema<DeleteTopicResponse>;
export interface DeleteVpcConnectionRequest {
    Arn: string;
}
export declare const DeleteVpcConnectionRequest: S.Schema<DeleteVpcConnectionRequest>;
export interface DeleteVpcConnectionResponse {
    VpcConnectionArn?: string;
    State?: VpcConnectionState;
}
export declare const DeleteVpcConnectionResponse: S.Schema<DeleteVpcConnectionResponse>;
export interface DescribeChannelRequest {
    ChannelArn: string;
    ClusterArn: string;
}
export declare const DescribeChannelRequest: S.Schema<DescribeChannelRequest>;
export type ChannelStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | "SUSPENDING" | "SUSPENDED" | (string & {});
export declare const ChannelStatus: any;
export type ChannelDestinationType = "ICEBERG" | "S3" | (string & {});
export declare const ChannelDestinationType: any;
export interface ChannelStateInfo {
    Code?: string;
    Message?: string;
}
export declare const ChannelStateInfo: S.Schema<ChannelStateInfo>;
export interface DescribeChannelResponse {
    ChannelArn: string;
    ChannelName: string;
    EncryptionConfiguration?: EncryptionConfiguration & {
        KmsKeyArn: string;
    };
    IcebergDestinationConfiguration?: IcebergDestinationConfiguration & {
        AppendOnly: boolean;
        DeadLetterQueueS3: DeadLetterQueueS3 & {
            BucketArn: string;
        };
        DestinationTableList: (DestinationTable & {
            PartitionSpec: PartitionSpec & {
                PartitionStrategy: PartitionStrategy;
            };
        })[];
        SchemaEvolution: SchemaEvolution;
        ServiceExecutionRoleArn: string;
        TableCreation: TableCreation;
    };
    S3DestinationConfiguration?: S3DestinationConfiguration & {
        DeadLetterQueueS3: DeadLetterQueueS3 & {
            BucketArn: string;
        };
        ServiceExecutionRoleArn: string;
        Storage: S3Storage & {
            BucketArn: string;
            CompressionType: S3CompressionType;
            StorageClass: S3StorageClass;
        };
    };
    Status: ChannelStatus;
    DestinationType: ChannelDestinationType;
    CreationTime: Date;
    TopicConfigurationList: (TopicConfiguration & {
        RecordConverter: RecordConverter & {
            ValueConverter: ValueConverter;
        };
        TopicArn: string;
        RecordSchema: RecordSchema & {
            GsrArn: string;
        };
    })[];
    LoggingInfo?: ChannelLoggingInfo & {
        CloudWatchLogs: CloudWatchLogs & {
            Enabled: boolean;
        };
        Firehose: Firehose & {
            Enabled: boolean;
        };
        S3: S3 & {
            Enabled: boolean;
        };
    };
    StateInfo?: ChannelStateInfo;
    ClusterOperationArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DescribeChannelResponse: S.Schema<DescribeChannelResponse>;
export interface DescribeClusterRequest {
    ClusterArn: string;
}
export declare const DescribeClusterRequest: S.Schema<DescribeClusterRequest>;
export interface BrokerSoftwareInfo {
    ConfigurationArn?: string;
    ConfigurationRevision?: number;
    KafkaVersion?: string;
}
export declare const BrokerSoftwareInfo: S.Schema<BrokerSoftwareInfo>;
export interface JmxExporter {
    EnabledInBroker?: boolean;
}
export declare const JmxExporter: S.Schema<JmxExporter>;
export interface NodeExporter {
    EnabledInBroker?: boolean;
}
export declare const NodeExporter: S.Schema<NodeExporter>;
export interface Prometheus {
    JmxExporter?: JmxExporter;
    NodeExporter?: NodeExporter;
}
export declare const Prometheus: S.Schema<Prometheus>;
export interface OpenMonitoring {
    Prometheus?: Prometheus;
}
export declare const OpenMonitoring: S.Schema<OpenMonitoring>;
export interface StateInfo {
    Code?: string;
    Message?: string;
}
export declare const StateInfo: S.Schema<StateInfo>;
export type CustomerActionStatus = "CRITICAL_ACTION_REQUIRED" | "ACTION_RECOMMENDED" | "NONE" | (string & {});
export declare const CustomerActionStatus: any;
export interface ClusterInfo {
    ActiveOperationArn?: string;
    BrokerNodeGroupInfo?: BrokerNodeGroupInfo;
    Rebalancing?: Rebalancing;
    ClientAuthentication?: ClientAuthentication;
    ClusterArn?: string;
    ClusterName?: string;
    CreationTime?: Date;
    CurrentBrokerSoftwareInfo?: BrokerSoftwareInfo;
    CurrentVersion?: string;
    EncryptionInfo?: EncryptionInfo;
    EnhancedMonitoring?: EnhancedMonitoring;
    OpenMonitoring?: OpenMonitoring;
    LoggingInfo?: LoggingInfo;
    NumberOfBrokerNodes?: number;
    State?: ClusterState;
    StateInfo?: StateInfo;
    Tags?: {
        [key: string]: string | undefined;
    };
    ZookeeperConnectString?: string;
    ZookeeperConnectStringTls?: string;
    StorageMode?: StorageMode;
    CustomerActionStatus?: CustomerActionStatus;
}
export declare const ClusterInfo: S.Schema<ClusterInfo>;
export interface DescribeClusterResponse {
    ClusterInfo?: ClusterInfo & {
        BrokerNodeGroupInfo: BrokerNodeGroupInfo & {
            ClientSubnets: __listOf__string;
            InstanceType: __stringMin5Max32;
        };
        EncryptionInfo: EncryptionInfo & {
            EncryptionAtRest: EncryptionAtRest & {
                DataVolumeKMSKeyId: string;
            };
        };
        OpenMonitoring: OpenMonitoring & {
            Prometheus: Prometheus & {
                JmxExporter: JmxExporter & {
                    EnabledInBroker: boolean;
                };
                NodeExporter: NodeExporter & {
                    EnabledInBroker: boolean;
                };
            };
        };
        LoggingInfo: LoggingInfo & {
            BrokerLogs: BrokerLogs & {
                CloudWatchLogs: CloudWatchLogs & {
                    Enabled: boolean;
                };
                Firehose: Firehose & {
                    Enabled: boolean;
                };
                S3: S3 & {
                    Enabled: boolean;
                };
            };
            AuthorizerLogs: AuthorizerLogs & {
                CloudWatchLogs: CloudWatchLogs & {
                    Enabled: boolean;
                };
                Firehose: Firehose & {
                    Enabled: boolean;
                };
                S3: S3 & {
                    Enabled: boolean;
                };
            };
        };
    };
}
export declare const DescribeClusterResponse: S.Schema<DescribeClusterResponse>;
export interface DescribeClusterOperationRequest {
    ClusterOperationArn: string;
}
export declare const DescribeClusterOperationRequest: S.Schema<DescribeClusterOperationRequest>;
export interface ErrorInfo {
    ErrorCode?: string;
    ErrorString?: string;
}
export declare const ErrorInfo: S.Schema<ErrorInfo>;
export interface ClusterOperationStepInfo {
    StepStatus?: string;
}
export declare const ClusterOperationStepInfo: S.Schema<ClusterOperationStepInfo>;
export interface ClusterOperationStep {
    StepInfo?: ClusterOperationStepInfo;
    StepName?: string;
}
export declare const ClusterOperationStep: S.Schema<ClusterOperationStep>;
export type __listOfClusterOperationStep = ClusterOperationStep[];
export declare const __listOfClusterOperationStep: any;
export interface BrokerEBSVolumeInfo {
    KafkaBrokerNodeId?: string;
    ProvisionedThroughput?: ProvisionedThroughput;
    VolumeSizeGB?: number;
}
export declare const BrokerEBSVolumeInfo: S.Schema<BrokerEBSVolumeInfo>;
export type __listOfBrokerEBSVolumeInfo = BrokerEBSVolumeInfo[];
export declare const __listOfBrokerEBSVolumeInfo: any;
export interface ZookeeperAccess {
    Enabled?: boolean;
}
export declare const ZookeeperAccess: S.Schema<ZookeeperAccess>;
export type __listOf__double = number[];
export declare const __listOf__double: any;
export interface BrokerCountUpdateInfo {
    CreatedBrokerIds?: number[];
    DeletedBrokerIds?: number[];
}
export declare const BrokerCountUpdateInfo: S.Schema<BrokerCountUpdateInfo>;
export interface MutableClusterInfo {
    BrokerEBSVolumeInfo?: BrokerEBSVolumeInfo[];
    ConfigurationInfo?: ConfigurationInfo;
    NumberOfBrokerNodes?: number;
    EnhancedMonitoring?: EnhancedMonitoring;
    OpenMonitoring?: OpenMonitoring;
    ZookeeperAccess?: ZookeeperAccess;
    KafkaVersion?: string;
    LoggingInfo?: LoggingInfo;
    InstanceType?: string;
    ClientAuthentication?: ClientAuthentication;
    EncryptionInfo?: EncryptionInfo;
    ConnectivityInfo?: ConnectivityInfo;
    StorageMode?: StorageMode;
    BrokerCountUpdateInfo?: BrokerCountUpdateInfo;
    Rebalancing?: Rebalancing;
}
export declare const MutableClusterInfo: S.Schema<MutableClusterInfo>;
export type UserIdentityType = "AWSACCOUNT" | "AWSSERVICE" | (string & {});
export declare const UserIdentityType: any;
export interface UserIdentity {
    Type?: UserIdentityType;
    PrincipalId?: string;
}
export declare const UserIdentity: S.Schema<UserIdentity>;
export interface VpcConnectionInfo {
    VpcConnectionArn?: string;
    Owner?: string;
    UserIdentity?: UserIdentity;
    CreationTime?: Date;
}
export declare const VpcConnectionInfo: S.Schema<VpcConnectionInfo>;
export interface ClusterOperationInfo {
    ClientRequestId?: string;
    ClusterArn?: string;
    CreationTime?: Date;
    EndTime?: Date;
    ErrorInfo?: ErrorInfo;
    OperationArn?: string;
    OperationState?: string;
    OperationSteps?: ClusterOperationStep[];
    OperationType?: string;
    SourceClusterInfo?: MutableClusterInfo;
    TargetClusterInfo?: MutableClusterInfo;
    VpcConnectionInfo?: VpcConnectionInfo;
}
export declare const ClusterOperationInfo: S.Schema<ClusterOperationInfo>;
export interface DescribeClusterOperationResponse {
    ClusterOperationInfo?: ClusterOperationInfo & {
        SourceClusterInfo: MutableClusterInfo & {
            BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                KafkaBrokerNodeId: string;
            })[];
            ConfigurationInfo: ConfigurationInfo & {
                Arn: string;
                Revision: number;
            };
            OpenMonitoring: OpenMonitoring & {
                Prometheus: Prometheus & {
                    JmxExporter: JmxExporter & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporter & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
        };
        TargetClusterInfo: MutableClusterInfo & {
            BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                KafkaBrokerNodeId: string;
            })[];
            ConfigurationInfo: ConfigurationInfo & {
                Arn: string;
                Revision: number;
            };
            OpenMonitoring: OpenMonitoring & {
                Prometheus: Prometheus & {
                    JmxExporter: JmxExporter & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporter & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
        };
    };
}
export declare const DescribeClusterOperationResponse: S.Schema<DescribeClusterOperationResponse>;
export interface DescribeClusterOperationV2Request {
    ClusterOperationArn: string;
}
export declare const DescribeClusterOperationV2Request: S.Schema<DescribeClusterOperationV2Request>;
export interface ClusterOperationV2Provisioned {
    OperationSteps?: ClusterOperationStep[];
    SourceClusterInfo?: MutableClusterInfo;
    TargetClusterInfo?: MutableClusterInfo;
    VpcConnectionInfo?: VpcConnectionInfo;
}
export declare const ClusterOperationV2Provisioned: S.Schema<ClusterOperationV2Provisioned>;
export interface ServerlessConnectivityInfo {
    NetworkType?: NetworkType;
}
export declare const ServerlessConnectivityInfo: S.Schema<ServerlessConnectivityInfo>;
export interface VpcConnectionInfoServerless {
    CreationTime?: Date;
    Owner?: string;
    UserIdentity?: UserIdentity;
    VpcConnectionArn?: string;
}
export declare const VpcConnectionInfoServerless: S.Schema<VpcConnectionInfoServerless>;
export interface ClusterOperationV2Serverless {
    SourceClusterInfo?: ServerlessConnectivityInfo;
    TargetClusterInfo?: ServerlessConnectivityInfo;
    VpcConnectionInfo?: VpcConnectionInfoServerless;
}
export declare const ClusterOperationV2Serverless: S.Schema<ClusterOperationV2Serverless>;
export interface ClusterOperationV2 {
    ClusterArn?: string;
    ClusterType?: ClusterType;
    StartTime?: Date;
    EndTime?: Date;
    ErrorInfo?: ErrorInfo;
    OperationArn?: string;
    OperationState?: string;
    OperationType?: string;
    Provisioned?: ClusterOperationV2Provisioned;
    Serverless?: ClusterOperationV2Serverless;
}
export declare const ClusterOperationV2: S.Schema<ClusterOperationV2>;
export interface DescribeClusterOperationV2Response {
    ClusterOperationInfo?: ClusterOperationV2 & {
        Provisioned: ClusterOperationV2Provisioned & {
            SourceClusterInfo: MutableClusterInfo & {
                BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                    KafkaBrokerNodeId: string;
                })[];
                ConfigurationInfo: ConfigurationInfo & {
                    Arn: string;
                    Revision: number;
                };
                OpenMonitoring: OpenMonitoring & {
                    Prometheus: Prometheus & {
                        JmxExporter: JmxExporter & {
                            EnabledInBroker: boolean;
                        };
                        NodeExporter: NodeExporter & {
                            EnabledInBroker: boolean;
                        };
                    };
                };
                LoggingInfo: LoggingInfo & {
                    BrokerLogs: BrokerLogs & {
                        CloudWatchLogs: CloudWatchLogs & {
                            Enabled: boolean;
                        };
                        Firehose: Firehose & {
                            Enabled: boolean;
                        };
                        S3: S3 & {
                            Enabled: boolean;
                        };
                    };
                    AuthorizerLogs: AuthorizerLogs & {
                        CloudWatchLogs: CloudWatchLogs & {
                            Enabled: boolean;
                        };
                        Firehose: Firehose & {
                            Enabled: boolean;
                        };
                        S3: S3 & {
                            Enabled: boolean;
                        };
                    };
                };
                EncryptionInfo: EncryptionInfo & {
                    EncryptionAtRest: EncryptionAtRest & {
                        DataVolumeKMSKeyId: string;
                    };
                };
            };
            TargetClusterInfo: MutableClusterInfo & {
                BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                    KafkaBrokerNodeId: string;
                })[];
                ConfigurationInfo: ConfigurationInfo & {
                    Arn: string;
                    Revision: number;
                };
                OpenMonitoring: OpenMonitoring & {
                    Prometheus: Prometheus & {
                        JmxExporter: JmxExporter & {
                            EnabledInBroker: boolean;
                        };
                        NodeExporter: NodeExporter & {
                            EnabledInBroker: boolean;
                        };
                    };
                };
                LoggingInfo: LoggingInfo & {
                    BrokerLogs: BrokerLogs & {
                        CloudWatchLogs: CloudWatchLogs & {
                            Enabled: boolean;
                        };
                        Firehose: Firehose & {
                            Enabled: boolean;
                        };
                        S3: S3 & {
                            Enabled: boolean;
                        };
                    };
                    AuthorizerLogs: AuthorizerLogs & {
                        CloudWatchLogs: CloudWatchLogs & {
                            Enabled: boolean;
                        };
                        Firehose: Firehose & {
                            Enabled: boolean;
                        };
                        S3: S3 & {
                            Enabled: boolean;
                        };
                    };
                };
                EncryptionInfo: EncryptionInfo & {
                    EncryptionAtRest: EncryptionAtRest & {
                        DataVolumeKMSKeyId: string;
                    };
                };
            };
        };
    };
}
export declare const DescribeClusterOperationV2Response: S.Schema<DescribeClusterOperationV2Response>;
export interface DescribeClusterV2Request {
    ClusterArn: string;
}
export declare const DescribeClusterV2Request: S.Schema<DescribeClusterV2Request>;
export interface Provisioned {
    BrokerNodeGroupInfo?: BrokerNodeGroupInfo;
    Rebalancing?: Rebalancing;
    CurrentBrokerSoftwareInfo?: BrokerSoftwareInfo;
    ClientAuthentication?: ClientAuthentication;
    EncryptionInfo?: EncryptionInfo;
    EnhancedMonitoring?: EnhancedMonitoring;
    OpenMonitoring?: OpenMonitoringInfo;
    LoggingInfo?: LoggingInfo;
    NumberOfBrokerNodes?: number;
    ZookeeperConnectString?: string;
    ZookeeperConnectStringTls?: string;
    StorageMode?: StorageMode;
    CustomerActionStatus?: CustomerActionStatus;
}
export declare const Provisioned: S.Schema<Provisioned>;
export interface Serverless {
    VpcConfigs?: VpcConfig[];
    ClientAuthentication?: ServerlessClientAuthentication;
    ConnectivityInfo?: ServerlessConnectivityInfo;
}
export declare const Serverless: S.Schema<Serverless>;
export interface Cluster {
    ActiveOperationArn?: string;
    ClusterType?: ClusterType;
    ClusterArn?: string;
    ClusterName?: string;
    CreationTime?: Date;
    CurrentVersion?: string;
    State?: ClusterState;
    StateInfo?: StateInfo;
    Tags?: {
        [key: string]: string | undefined;
    };
    Provisioned?: Provisioned;
    Serverless?: Serverless;
}
export declare const Cluster: S.Schema<Cluster>;
export interface DescribeClusterV2Response {
    ClusterInfo?: Cluster & {
        Provisioned: Provisioned & {
            BrokerNodeGroupInfo: BrokerNodeGroupInfo & {
                ClientSubnets: __listOf__string;
                InstanceType: __stringMin5Max32;
            };
            NumberOfBrokerNodes: __integerMin1Max15;
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
            OpenMonitoring: OpenMonitoringInfo & {
                Prometheus: PrometheusInfo & {
                    JmxExporter: JmxExporterInfo & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporterInfo & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
        };
        Serverless: Serverless & {
            VpcConfigs: (VpcConfig & {
                SubnetIds: __listOf__string;
            })[];
        };
    };
}
export declare const DescribeClusterV2Response: S.Schema<DescribeClusterV2Response>;
export interface DescribeConfigurationRequest {
    Arn: string;
}
export declare const DescribeConfigurationRequest: S.Schema<DescribeConfigurationRequest>;
export interface DescribeConfigurationResponse {
    Arn?: string;
    CreationTime?: Date;
    Description?: string;
    KafkaVersions?: string[];
    LatestRevision?: ConfigurationRevision & {
        CreationTime: __timestampIso8601;
        Revision: number;
    };
    Name?: string;
    State?: ConfigurationState;
}
export declare const DescribeConfigurationResponse: S.Schema<DescribeConfigurationResponse>;
export interface DescribeConfigurationRevisionRequest {
    Arn: string;
    Revision: number;
}
export declare const DescribeConfigurationRevisionRequest: S.Schema<DescribeConfigurationRevisionRequest>;
export interface DescribeConfigurationRevisionResponse {
    Arn?: string;
    CreationTime?: Date;
    Description?: string;
    Revision?: number;
    ServerProperties?: Uint8Array;
}
export declare const DescribeConfigurationRevisionResponse: S.Schema<DescribeConfigurationRevisionResponse>;
export interface DescribeReplicatorRequest {
    ReplicatorArn: string;
}
export declare const DescribeReplicatorRequest: S.Schema<DescribeReplicatorRequest>;
export interface KafkaClusterDescription {
    AmazonMskCluster?: AmazonMskCluster;
    ApacheKafkaCluster?: ApacheKafkaCluster;
    KafkaClusterAlias?: string;
    VpcConfig?: KafkaClusterClientVpcConfig;
    ClientAuthentication?: KafkaClusterClientAuthentication;
    EncryptionInTransit?: KafkaClusterEncryptionInTransit;
}
export declare const KafkaClusterDescription: S.Schema<KafkaClusterDescription>;
export type __listOfKafkaClusterDescription = KafkaClusterDescription[];
export declare const __listOfKafkaClusterDescription: any;
export interface ReplicationInfoDescription {
    ConsumerGroupReplication?: ConsumerGroupReplication;
    SourceKafkaClusterAlias?: string;
    TargetCompressionType?: TargetCompressionType;
    TargetKafkaClusterAlias?: string;
    TopicReplication?: TopicReplication;
}
export declare const ReplicationInfoDescription: S.Schema<ReplicationInfoDescription>;
export type __listOfReplicationInfoDescription = ReplicationInfoDescription[];
export declare const __listOfReplicationInfoDescription: any;
export interface ReplicationStateInfo {
    Code?: string;
    Message?: string;
}
export declare const ReplicationStateInfo: S.Schema<ReplicationStateInfo>;
export interface DescribeReplicatorResponse {
    CreationTime?: Date;
    CurrentVersion?: string;
    IsReplicatorReference?: boolean;
    KafkaClusters?: (KafkaClusterDescription & {
        AmazonMskCluster: AmazonMskCluster & {
            MskClusterArn: string;
        };
        ApacheKafkaCluster: ApacheKafkaCluster & {
            ApacheKafkaClusterId: string;
            BootstrapBrokerString: string;
        };
        VpcConfig: KafkaClusterClientVpcConfig & {
            SubnetIds: __listOf__string;
        };
        ClientAuthentication: KafkaClusterClientAuthentication & {
            SaslScram: KafkaClusterSaslScramAuthentication & {
                Mechanism: KafkaClusterSaslScramMechanism;
                SecretArn: string;
            };
            MTLS: KafkaClusterMTLSAuthentication & {
                SecretArn: string;
            };
            SaslOAuthBearer: KafkaClusterSaslOAuthBearerAuthentication & {
                TokenEndpointUrl: string;
                TokenEndpointAuthenticationMethod: TokenEndpointAuthenticationMethod;
                ClientCredentials: KafkaClusterOAuthClientCredentials & {
                    TokenRequestSecretArn: string;
                };
                IamJwtBearer: KafkaClusterOAuthIamJwtBearer & {
                    Audience: string;
                    SigningAlgorithm: JwtSigningAlgorithm;
                };
                ClientCredentialsAssertion: KafkaClusterOAuthClientCredentialsAssertion & {
                    Audience: string;
                    SigningAlgorithm: JwtSigningAlgorithm;
                };
            };
        };
        EncryptionInTransit: KafkaClusterEncryptionInTransit & {
            EncryptionType: KafkaClusterEncryptionInTransitType;
        };
    })[];
    ReplicationInfoList?: (ReplicationInfoDescription & {
        ConsumerGroupReplication: ConsumerGroupReplication & {
            ConsumerGroupsToReplicate: __listOf__stringMax256;
        };
        TopicReplication: TopicReplication & {
            TopicsToReplicate: __listOf__stringMax249;
        };
    })[];
    ReplicatorArn?: string;
    ReplicatorDescription?: string;
    ReplicatorName?: string;
    ReplicatorResourceArn?: string;
    ReplicatorState?: ReplicatorState;
    ServiceExecutionRoleArn?: string;
    StateInfo?: ReplicationStateInfo;
    Tags?: {
        [key: string]: string | undefined;
    };
    LogDelivery?: LogDelivery & {
        ReplicatorLogDelivery: ReplicatorLogDelivery & {
            CloudWatchLogs: ReplicatorCloudWatchLogs & {
                Enabled: boolean;
            };
            Firehose: ReplicatorFirehose & {
                Enabled: boolean;
            };
            S3: ReplicatorS3 & {
                Enabled: boolean;
            };
        };
    };
}
export declare const DescribeReplicatorResponse: S.Schema<DescribeReplicatorResponse>;
export interface DescribeTopicRequest {
    ClusterArn: string;
    TopicName: string;
}
export declare const DescribeTopicRequest: S.Schema<DescribeTopicRequest>;
export interface DescribeTopicResponse {
    TopicArn?: string;
    TopicName?: string;
    ReplicationFactor?: number;
    PartitionCount?: number;
    Configs?: string;
    Status?: TopicState;
}
export declare const DescribeTopicResponse: S.Schema<DescribeTopicResponse>;
export type MaxResults = number;
export interface DescribeTopicPartitionsRequest {
    ClusterArn: string;
    TopicName: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeTopicPartitionsRequest: S.Schema<DescribeTopicPartitionsRequest>;
export type __listOf__integer = number[];
export declare const __listOf__integer: any;
export interface TopicPartitionInfo {
    Partition?: number;
    Leader?: number;
    Replicas?: number[];
    Isr?: number[];
}
export declare const TopicPartitionInfo: S.Schema<TopicPartitionInfo>;
export type __listOfTopicPartitionInfo = TopicPartitionInfo[];
export declare const __listOfTopicPartitionInfo: any;
export interface DescribeTopicPartitionsResponse {
    Partitions?: TopicPartitionInfo[];
    NextToken?: string;
}
export declare const DescribeTopicPartitionsResponse: S.Schema<DescribeTopicPartitionsResponse>;
export interface DescribeVpcConnectionRequest {
    Arn: string;
}
export declare const DescribeVpcConnectionRequest: S.Schema<DescribeVpcConnectionRequest>;
export interface DescribeVpcConnectionResponse {
    VpcConnectionArn?: string;
    TargetClusterArn?: string;
    State?: VpcConnectionState;
    Authentication?: string;
    VpcId?: string;
    Subnets?: string[];
    SecurityGroups?: string[];
    CreationTime?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DescribeVpcConnectionResponse: S.Schema<DescribeVpcConnectionResponse>;
export interface GetBootstrapBrokersRequest {
    ClusterArn: string;
}
export declare const GetBootstrapBrokersRequest: S.Schema<GetBootstrapBrokersRequest>;
export interface GetBootstrapBrokersResponse {
    BootstrapBrokerString?: string;
    BootstrapBrokerStringTls?: string;
    BootstrapBrokerStringSaslScram?: string;
    BootstrapBrokerStringSaslIam?: string;
    BootstrapBrokerStringPublicTls?: string;
    BootstrapBrokerStringPublicSaslScram?: string;
    BootstrapBrokerStringPublicSaslIam?: string;
    BootstrapBrokerStringVpcConnectivityTls?: string;
    BootstrapBrokerStringVpcConnectivitySaslScram?: string;
    BootstrapBrokerStringVpcConnectivitySaslIam?: string;
    BootstrapBrokerStringIpv6?: string;
    BootstrapBrokerStringTlsIpv6?: string;
    BootstrapBrokerStringSaslScramIpv6?: string;
    BootstrapBrokerStringSaslIamIpv6?: string;
}
export declare const GetBootstrapBrokersResponse: S.Schema<GetBootstrapBrokersResponse>;
export interface GetClusterPolicyRequest {
    ClusterArn: string;
}
export declare const GetClusterPolicyRequest: S.Schema<GetClusterPolicyRequest>;
export interface GetClusterPolicyResponse {
    CurrentVersion?: string;
    Policy?: string;
}
export declare const GetClusterPolicyResponse: S.Schema<GetClusterPolicyResponse>;
export interface GetCompatibleKafkaVersionsRequest {
    ClusterArn?: string;
}
export declare const GetCompatibleKafkaVersionsRequest: S.Schema<GetCompatibleKafkaVersionsRequest>;
export interface CompatibleKafkaVersion {
    SourceVersion?: string;
    TargetVersions?: string[];
}
export declare const CompatibleKafkaVersion: S.Schema<CompatibleKafkaVersion>;
export type __listOfCompatibleKafkaVersion = CompatibleKafkaVersion[];
export declare const __listOfCompatibleKafkaVersion: any;
export interface GetCompatibleKafkaVersionsResponse {
    CompatibleKafkaVersions?: CompatibleKafkaVersion[];
}
export declare const GetCompatibleKafkaVersionsResponse: S.Schema<GetCompatibleKafkaVersionsResponse>;
export interface ListChannelsRequest {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
    TopicNameFilter?: string;
}
export declare const ListChannelsRequest: S.Schema<ListChannelsRequest>;
export interface ChannelInfo {
    ChannelArn?: string;
    ChannelName?: string;
    Status?: ChannelStatus;
    CreationTime?: Date;
    DestinationType?: ChannelDestinationType;
    ClusterOperationArn?: string;
}
export declare const ChannelInfo: S.Schema<ChannelInfo>;
export type __listOfChannelInfo = ChannelInfo[];
export declare const __listOfChannelInfo: any;
export interface ListChannelsResponse {
    Channels?: (ChannelInfo & {
        ChannelArn: string;
        ChannelName: string;
        Status: ChannelStatus;
        CreationTime: __timestampIso8601;
        DestinationType: ChannelDestinationType;
    })[];
    NextToken?: string;
}
export declare const ListChannelsResponse: S.Schema<ListChannelsResponse>;
export interface ListClientVpcConnectionsRequest {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListClientVpcConnectionsRequest: S.Schema<ListClientVpcConnectionsRequest>;
export interface ClientVpcConnection {
    Authentication?: string;
    CreationTime?: Date;
    State?: VpcConnectionState;
    VpcConnectionArn?: string;
    Owner?: string;
}
export declare const ClientVpcConnection: S.Schema<ClientVpcConnection>;
export type __listOfClientVpcConnection = ClientVpcConnection[];
export declare const __listOfClientVpcConnection: any;
export interface ListClientVpcConnectionsResponse {
    ClientVpcConnections?: (ClientVpcConnection & {
        VpcConnectionArn: string;
    })[];
    NextToken?: string;
}
export declare const ListClientVpcConnectionsResponse: S.Schema<ListClientVpcConnectionsResponse>;
export interface ListClusterOperationsRequest {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListClusterOperationsRequest: S.Schema<ListClusterOperationsRequest>;
export type __listOfClusterOperationInfo = ClusterOperationInfo[];
export declare const __listOfClusterOperationInfo: any;
export interface ListClusterOperationsResponse {
    ClusterOperationInfoList?: (ClusterOperationInfo & {
        SourceClusterInfo: MutableClusterInfo & {
            BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                KafkaBrokerNodeId: string;
            })[];
            ConfigurationInfo: ConfigurationInfo & {
                Arn: string;
                Revision: number;
            };
            OpenMonitoring: OpenMonitoring & {
                Prometheus: Prometheus & {
                    JmxExporter: JmxExporter & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporter & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
        };
        TargetClusterInfo: MutableClusterInfo & {
            BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                KafkaBrokerNodeId: string;
            })[];
            ConfigurationInfo: ConfigurationInfo & {
                Arn: string;
                Revision: number;
            };
            OpenMonitoring: OpenMonitoring & {
                Prometheus: Prometheus & {
                    JmxExporter: JmxExporter & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporter & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
        };
    })[];
    NextToken?: string;
}
export declare const ListClusterOperationsResponse: S.Schema<ListClusterOperationsResponse>;
export interface ListClusterOperationsV2Request {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListClusterOperationsV2Request: S.Schema<ListClusterOperationsV2Request>;
export interface ClusterOperationV2Summary {
    ClusterArn?: string;
    ClusterType?: ClusterType;
    StartTime?: Date;
    EndTime?: Date;
    OperationArn?: string;
    OperationState?: string;
    OperationType?: string;
}
export declare const ClusterOperationV2Summary: S.Schema<ClusterOperationV2Summary>;
export type __listOfClusterOperationV2Summary = ClusterOperationV2Summary[];
export declare const __listOfClusterOperationV2Summary: any;
export interface ListClusterOperationsV2Response {
    ClusterOperationInfoList?: ClusterOperationV2Summary[];
    NextToken?: string;
}
export declare const ListClusterOperationsV2Response: S.Schema<ListClusterOperationsV2Response>;
export interface ListClustersRequest {
    ClusterNameFilter?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListClustersRequest: S.Schema<ListClustersRequest>;
export type __listOfClusterInfo = ClusterInfo[];
export declare const __listOfClusterInfo: any;
export interface ListClustersResponse {
    ClusterInfoList?: (ClusterInfo & {
        BrokerNodeGroupInfo: BrokerNodeGroupInfo & {
            ClientSubnets: __listOf__string;
            InstanceType: __stringMin5Max32;
        };
        EncryptionInfo: EncryptionInfo & {
            EncryptionAtRest: EncryptionAtRest & {
                DataVolumeKMSKeyId: string;
            };
        };
        OpenMonitoring: OpenMonitoring & {
            Prometheus: Prometheus & {
                JmxExporter: JmxExporter & {
                    EnabledInBroker: boolean;
                };
                NodeExporter: NodeExporter & {
                    EnabledInBroker: boolean;
                };
            };
        };
        LoggingInfo: LoggingInfo & {
            BrokerLogs: BrokerLogs & {
                CloudWatchLogs: CloudWatchLogs & {
                    Enabled: boolean;
                };
                Firehose: Firehose & {
                    Enabled: boolean;
                };
                S3: S3 & {
                    Enabled: boolean;
                };
            };
            AuthorizerLogs: AuthorizerLogs & {
                CloudWatchLogs: CloudWatchLogs & {
                    Enabled: boolean;
                };
                Firehose: Firehose & {
                    Enabled: boolean;
                };
                S3: S3 & {
                    Enabled: boolean;
                };
            };
        };
    })[];
    NextToken?: string;
}
export declare const ListClustersResponse: S.Schema<ListClustersResponse>;
export interface ListClustersV2Request {
    ClusterNameFilter?: string;
    ClusterTypeFilter?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListClustersV2Request: S.Schema<ListClustersV2Request>;
export type __listOfCluster = Cluster[];
export declare const __listOfCluster: any;
export interface ListClustersV2Response {
    ClusterInfoList?: (Cluster & {
        Provisioned: Provisioned & {
            BrokerNodeGroupInfo: BrokerNodeGroupInfo & {
                ClientSubnets: __listOf__string;
                InstanceType: __stringMin5Max32;
            };
            NumberOfBrokerNodes: __integerMin1Max15;
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
            OpenMonitoring: OpenMonitoringInfo & {
                Prometheus: PrometheusInfo & {
                    JmxExporter: JmxExporterInfo & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporterInfo & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
        };
        Serverless: Serverless & {
            VpcConfigs: (VpcConfig & {
                SubnetIds: __listOf__string;
            })[];
        };
    })[];
    NextToken?: string;
}
export declare const ListClustersV2Response: S.Schema<ListClustersV2Response>;
export interface ListConfigurationRevisionsRequest {
    Arn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListConfigurationRevisionsRequest: S.Schema<ListConfigurationRevisionsRequest>;
export type __listOfConfigurationRevision = ConfigurationRevision[];
export declare const __listOfConfigurationRevision: any;
export interface ListConfigurationRevisionsResponse {
    NextToken?: string;
    Revisions?: (ConfigurationRevision & {
        CreationTime: __timestampIso8601;
        Revision: number;
    })[];
}
export declare const ListConfigurationRevisionsResponse: S.Schema<ListConfigurationRevisionsResponse>;
export interface ListConfigurationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListConfigurationsRequest: S.Schema<ListConfigurationsRequest>;
export interface Configuration {
    Arn?: string;
    CreationTime?: Date;
    Description?: string;
    KafkaVersions?: string[];
    LatestRevision?: ConfigurationRevision;
    Name?: string;
    State?: ConfigurationState;
}
export declare const Configuration: S.Schema<Configuration>;
export type __listOfConfiguration = Configuration[];
export declare const __listOfConfiguration: any;
export interface ListConfigurationsResponse {
    Configurations?: (Configuration & {
        Arn: string;
        CreationTime: __timestampIso8601;
        Description: string;
        KafkaVersions: __listOf__string;
        LatestRevision: ConfigurationRevision & {
            CreationTime: __timestampIso8601;
            Revision: number;
        };
        Name: string;
        State: ConfigurationState;
    })[];
    NextToken?: string;
}
export declare const ListConfigurationsResponse: S.Schema<ListConfigurationsResponse>;
export interface ListKafkaVersionsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListKafkaVersionsRequest: S.Schema<ListKafkaVersionsRequest>;
export type KafkaVersionStatus = "ACTIVE" | "DEPRECATED" | (string & {});
export declare const KafkaVersionStatus: any;
export interface KafkaVersion {
    Version?: string;
    Status?: KafkaVersionStatus;
}
export declare const KafkaVersion: S.Schema<KafkaVersion>;
export type __listOfKafkaVersion = KafkaVersion[];
export declare const __listOfKafkaVersion: any;
export interface ListKafkaVersionsResponse {
    KafkaVersions?: KafkaVersion[];
    NextToken?: string;
}
export declare const ListKafkaVersionsResponse: S.Schema<ListKafkaVersionsResponse>;
export interface ListNodesRequest {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListNodesRequest: S.Schema<ListNodesRequest>;
export interface BrokerNodeInfo {
    AttachedENIId?: string;
    BrokerId?: number;
    ClientSubnet?: string;
    ClientVpcIpAddress?: string;
    CurrentBrokerSoftwareInfo?: BrokerSoftwareInfo;
    Endpoints?: string[];
}
export declare const BrokerNodeInfo: S.Schema<BrokerNodeInfo>;
export interface ControllerNodeInfo {
    Endpoints?: string[];
}
export declare const ControllerNodeInfo: S.Schema<ControllerNodeInfo>;
export type NodeType = "BROKER" | (string & {});
export declare const NodeType: any;
export interface ZookeeperNodeInfo {
    AttachedENIId?: string;
    ClientVpcIpAddress?: string;
    Endpoints?: string[];
    ZookeeperId?: number;
    ZookeeperVersion?: string;
}
export declare const ZookeeperNodeInfo: S.Schema<ZookeeperNodeInfo>;
export interface NodeInfo {
    AddedToClusterTime?: string;
    BrokerNodeInfo?: BrokerNodeInfo;
    ControllerNodeInfo?: ControllerNodeInfo;
    InstanceType?: string;
    NodeARN?: string;
    NodeType?: NodeType;
    ZookeeperNodeInfo?: ZookeeperNodeInfo;
}
export declare const NodeInfo: S.Schema<NodeInfo>;
export type __listOfNodeInfo = NodeInfo[];
export declare const __listOfNodeInfo: any;
export interface ListNodesResponse {
    NextToken?: string;
    NodeInfoList?: NodeInfo[];
}
export declare const ListNodesResponse: S.Schema<ListNodesResponse>;
export interface ListReplicatorsRequest {
    MaxResults?: number;
    NextToken?: string;
    ReplicatorNameFilter?: string;
}
export declare const ListReplicatorsRequest: S.Schema<ListReplicatorsRequest>;
export interface KafkaClusterSummary {
    AmazonMskCluster?: AmazonMskCluster;
    ApacheKafkaCluster?: ApacheKafkaCluster;
    KafkaClusterAlias?: string;
}
export declare const KafkaClusterSummary: S.Schema<KafkaClusterSummary>;
export type __listOfKafkaClusterSummary = KafkaClusterSummary[];
export declare const __listOfKafkaClusterSummary: any;
export interface ReplicationInfoSummary {
    SourceKafkaClusterAlias?: string;
    TargetKafkaClusterAlias?: string;
}
export declare const ReplicationInfoSummary: S.Schema<ReplicationInfoSummary>;
export type __listOfReplicationInfoSummary = ReplicationInfoSummary[];
export declare const __listOfReplicationInfoSummary: any;
export interface ReplicatorSummary {
    CreationTime?: Date;
    CurrentVersion?: string;
    IsReplicatorReference?: boolean;
    KafkaClustersSummary?: KafkaClusterSummary[];
    ReplicationInfoSummaryList?: ReplicationInfoSummary[];
    ReplicatorArn?: string;
    ReplicatorName?: string;
    ReplicatorResourceArn?: string;
    ReplicatorState?: ReplicatorState;
}
export declare const ReplicatorSummary: S.Schema<ReplicatorSummary>;
export type __listOfReplicatorSummary = ReplicatorSummary[];
export declare const __listOfReplicatorSummary: any;
export interface ListReplicatorsResponse {
    NextToken?: string;
    Replicators?: (ReplicatorSummary & {
        KafkaClustersSummary: (KafkaClusterSummary & {
            AmazonMskCluster: AmazonMskCluster & {
                MskClusterArn: string;
            };
            ApacheKafkaCluster: ApacheKafkaCluster & {
                ApacheKafkaClusterId: string;
                BootstrapBrokerString: string;
            };
        })[];
    })[];
}
export declare const ListReplicatorsResponse: S.Schema<ListReplicatorsResponse>;
export interface ListScramSecretsRequest {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListScramSecretsRequest: S.Schema<ListScramSecretsRequest>;
export interface ListScramSecretsResponse {
    NextToken?: string;
    SecretArnList?: string[];
}
export declare const ListScramSecretsResponse: S.Schema<ListScramSecretsResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListTopicsRequest {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
    TopicNameFilter?: string;
}
export declare const ListTopicsRequest: S.Schema<ListTopicsRequest>;
export interface TopicInfo {
    TopicArn?: string;
    TopicName?: string;
    ReplicationFactor?: number;
    PartitionCount?: number;
    OutOfSyncReplicaCount?: number;
}
export declare const TopicInfo: S.Schema<TopicInfo>;
export type __listOfTopicInfo = TopicInfo[];
export declare const __listOfTopicInfo: any;
export interface ListTopicsResponse {
    Topics?: TopicInfo[];
    NextToken?: string;
}
export declare const ListTopicsResponse: S.Schema<ListTopicsResponse>;
export interface ListVpcConnectionsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListVpcConnectionsRequest: S.Schema<ListVpcConnectionsRequest>;
export interface VpcConnection {
    VpcConnectionArn?: string;
    TargetClusterArn?: string;
    CreationTime?: Date;
    Authentication?: string;
    VpcId?: string;
    State?: VpcConnectionState;
}
export declare const VpcConnection: S.Schema<VpcConnection>;
export type __listOfVpcConnection = VpcConnection[];
export declare const __listOfVpcConnection: any;
export interface ListVpcConnectionsResponse {
    VpcConnections?: (VpcConnection & {
        VpcConnectionArn: string;
        TargetClusterArn: string;
    })[];
    NextToken?: string;
}
export declare const ListVpcConnectionsResponse: S.Schema<ListVpcConnectionsResponse>;
export interface PutClusterPolicyRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    Policy?: string;
}
export declare const PutClusterPolicyRequest: S.Schema<PutClusterPolicyRequest>;
export interface PutClusterPolicyResponse {
    CurrentVersion?: string;
}
export declare const PutClusterPolicyResponse: S.Schema<PutClusterPolicyResponse>;
export interface RebootBrokerRequest {
    BrokerIds?: string[];
    ClusterArn: string;
}
export declare const RebootBrokerRequest: S.Schema<RebootBrokerRequest>;
export interface RebootBrokerResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export declare const RebootBrokerResponse: S.Schema<RebootBrokerResponse>;
export interface RejectClientVpcConnectionRequest {
    ClusterArn: string;
    VpcConnectionArn?: string;
}
export declare const RejectClientVpcConnectionRequest: S.Schema<RejectClientVpcConnectionRequest>;
export interface RejectClientVpcConnectionResponse {
}
export declare const RejectClientVpcConnectionResponse: S.Schema<RejectClientVpcConnectionResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateBrokerCountRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    TargetNumberOfBrokerNodes?: number;
}
export declare const UpdateBrokerCountRequest: S.Schema<UpdateBrokerCountRequest>;
export interface UpdateBrokerCountResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export declare const UpdateBrokerCountResponse: S.Schema<UpdateBrokerCountResponse>;
export interface UpdateBrokerStorageRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    TargetBrokerEBSVolumeInfo?: BrokerEBSVolumeInfo[];
}
export declare const UpdateBrokerStorageRequest: S.Schema<UpdateBrokerStorageRequest>;
export interface UpdateBrokerStorageResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export declare const UpdateBrokerStorageResponse: S.Schema<UpdateBrokerStorageResponse>;
export interface UpdateBrokerTypeRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    TargetInstanceType?: string;
}
export declare const UpdateBrokerTypeRequest: S.Schema<UpdateBrokerTypeRequest>;
export interface UpdateBrokerTypeResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export declare const UpdateBrokerTypeResponse: S.Schema<UpdateBrokerTypeResponse>;
export interface IcebergDestinationUpdate {
    DataFreshnessInSeconds?: number;
}
export declare const IcebergDestinationUpdate: S.Schema<IcebergDestinationUpdate>;
export interface S3DestinationUpdate {
    DataFreshnessInSeconds?: number;
}
export declare const S3DestinationUpdate: S.Schema<S3DestinationUpdate>;
export interface UpdateChannelRequest {
    ChannelArn: string;
    ClusterArn: string;
    IcebergDestinationUpdate?: IcebergDestinationUpdate;
    S3DestinationUpdate?: S3DestinationUpdate;
}
export declare const UpdateChannelRequest: S.Schema<UpdateChannelRequest>;
export interface UpdateChannelResponse {
    ChannelArn: string;
    ClusterOperationArn?: string;
}
export declare const UpdateChannelResponse: S.Schema<UpdateChannelResponse>;
export interface UpdateClusterConfigurationRequest {
    ClusterArn: string;
    ConfigurationInfo?: ConfigurationInfo;
    CurrentVersion?: string;
}
export declare const UpdateClusterConfigurationRequest: S.Schema<UpdateClusterConfigurationRequest>;
export interface UpdateClusterConfigurationResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export declare const UpdateClusterConfigurationResponse: S.Schema<UpdateClusterConfigurationResponse>;
export interface UpdateClusterKafkaVersionRequest {
    ClusterArn: string;
    ConfigurationInfo?: ConfigurationInfo;
    CurrentVersion?: string;
    TargetKafkaVersion?: string;
}
export declare const UpdateClusterKafkaVersionRequest: S.Schema<UpdateClusterKafkaVersionRequest>;
export interface UpdateClusterKafkaVersionResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export declare const UpdateClusterKafkaVersionResponse: S.Schema<UpdateClusterKafkaVersionResponse>;
export interface UpdateConfigurationRequest {
    Arn: string;
    Description?: string;
    ServerProperties?: Uint8Array;
}
export declare const UpdateConfigurationRequest: S.Schema<UpdateConfigurationRequest>;
export interface UpdateConfigurationResponse {
    Arn?: string;
    LatestRevision?: ConfigurationRevision & {
        CreationTime: __timestampIso8601;
        Revision: number;
    };
}
export declare const UpdateConfigurationResponse: S.Schema<UpdateConfigurationResponse>;
export interface UpdateConnectivityRequest {
    ClusterArn: string;
    ConnectivityInfo?: ConnectivityInfo;
    CurrentVersion?: string;
    ZookeeperAccess?: ZookeeperAccess;
}
export declare const UpdateConnectivityRequest: S.Schema<UpdateConnectivityRequest>;
export interface UpdateConnectivityResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export declare const UpdateConnectivityResponse: S.Schema<UpdateConnectivityResponse>;
export interface UpdateMonitoringRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    EnhancedMonitoring?: EnhancedMonitoring;
    OpenMonitoring?: OpenMonitoringInfo;
    LoggingInfo?: LoggingInfo;
}
export declare const UpdateMonitoringRequest: S.Schema<UpdateMonitoringRequest>;
export interface UpdateMonitoringResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export declare const UpdateMonitoringResponse: S.Schema<UpdateMonitoringResponse>;
export interface UpdateRebalancingRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    Rebalancing?: Rebalancing;
}
export declare const UpdateRebalancingRequest: S.Schema<UpdateRebalancingRequest>;
export interface UpdateRebalancingResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export declare const UpdateRebalancingResponse: S.Schema<UpdateRebalancingResponse>;
export interface ConsumerGroupReplicationUpdate {
    ConsumerGroupsToExclude?: string[];
    ConsumerGroupsToReplicate?: string[];
    DetectAndCopyNewConsumerGroups?: boolean;
    SynchroniseConsumerGroupOffsets?: boolean;
}
export declare const ConsumerGroupReplicationUpdate: S.Schema<ConsumerGroupReplicationUpdate>;
export interface TopicReplicationUpdate {
    CopyAccessControlListsForTopics?: boolean;
    CopyTopicConfigurations?: boolean;
    DetectAndCopyNewTopics?: boolean;
    TopicsToExclude?: string[];
    TopicsToReplicate?: string[];
}
export declare const TopicReplicationUpdate: S.Schema<TopicReplicationUpdate>;
export interface UpdateReplicationInfoRequest {
    ConsumerGroupReplication?: ConsumerGroupReplicationUpdate;
    CurrentVersion?: string;
    ReplicatorArn: string;
    SourceKafkaClusterArn?: string;
    SourceKafkaClusterId?: string;
    TargetKafkaClusterArn?: string;
    TargetKafkaClusterId?: string;
    TopicReplication?: TopicReplicationUpdate;
    LogDelivery?: LogDelivery;
}
export declare const UpdateReplicationInfoRequest: S.Schema<UpdateReplicationInfoRequest>;
export interface UpdateReplicationInfoResponse {
    ReplicatorArn?: string;
    ReplicatorState?: ReplicatorState;
}
export declare const UpdateReplicationInfoResponse: S.Schema<UpdateReplicationInfoResponse>;
export interface UpdateSecurityRequest {
    ClientAuthentication?: ClientAuthentication;
    ClusterArn: string;
    CurrentVersion?: string;
    EncryptionInfo?: EncryptionInfo;
}
export declare const UpdateSecurityRequest: S.Schema<UpdateSecurityRequest>;
export interface UpdateSecurityResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export declare const UpdateSecurityResponse: S.Schema<UpdateSecurityResponse>;
export interface UpdateStorageRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    ProvisionedThroughput?: ProvisionedThroughput;
    StorageMode?: StorageMode;
    VolumeSizeGB?: number;
}
export declare const UpdateStorageRequest: S.Schema<UpdateStorageRequest>;
export interface UpdateStorageResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export declare const UpdateStorageResponse: S.Schema<UpdateStorageResponse>;
export interface UpdateTopicRequest {
    ClusterArn: string;
    TopicName: string;
    Configs?: string;
    PartitionCount?: number;
}
export declare const UpdateTopicRequest: S.Schema<UpdateTopicRequest>;
export interface UpdateTopicResponse {
    TopicArn?: string;
    TopicName?: string;
    Status?: TopicState;
}
export declare const UpdateTopicResponse: S.Schema<UpdateTopicResponse>;
export type BatchAssociateScramSecretError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Associates one or more Scram Secrets with an Amazon MSK cluster.
 */
export declare const batchAssociateScramSecret: API.OperationMethod<BatchAssociateScramSecretRequest, BatchAssociateScramSecretResponse, BatchAssociateScramSecretError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateScramSecretError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Disassociates one or more Scram Secrets from an Amazon MSK cluster.
 */
export declare const batchDisassociateScramSecret: API.OperationMethod<BatchDisassociateScramSecretRequest, BatchDisassociateScramSecretResponse, BatchDisassociateScramSecretError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a Channel that streams records from an Amazon MSK Express cluster topic to Amazon S3 or Apache Iceberg.
 */
export declare const createChannel: API.OperationMethod<CreateChannelRequest, CreateChannelResponse, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreateClusterError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new MSK cluster.
 */
export declare const createCluster: API.OperationMethod<CreateClusterRequest, CreateClusterResponse, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateClusterV2Error = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new MSK cluster.
 */
export declare const createClusterV2: API.OperationMethod<CreateClusterV2Request, CreateClusterV2Response, CreateClusterV2Error, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new MSK configuration.
 */
export declare const createConfiguration: API.OperationMethod<CreateConfigurationRequest, CreateConfigurationResponse, CreateConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateReplicatorError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates the replicator.
 */
export declare const createReplicator: API.OperationMethod<CreateReplicatorRequest, CreateReplicatorResponse, CreateReplicatorError, Credentials | HttpClient.HttpClient>;
export type CreateTopicError = BadRequestException | ClusterConnectivityException | ConflictException | ControllerMovedException | ForbiddenException | GroupSubscribedToTopicException | InternalServerErrorException | KafkaRequestException | KafkaTimeoutException | NotControllerException | ReassignmentInProgressException | ServiceUnavailableException | TooManyRequestsException | TopicExistsException | UnauthorizedException | UnknownTopicOrPartitionException | CommonErrors;
/**
 * Creates a topic in the specified MSK cluster.
 */
export declare const createTopic: API.OperationMethod<CreateTopicRequest, CreateTopicResponse, CreateTopicError, Credentials | HttpClient.HttpClient>;
export type CreateVpcConnectionError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new MSK VPC connection.
 */
export declare const createVpcConnection: API.OperationMethod<CreateVpcConnectionRequest, CreateVpcConnectionResponse, CreateVpcConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the channel specified by channelArn from the cluster specified by clusterArn. The channel transitions through DELETING and is removed when the asynchronous delete completes.
 */
export declare const deleteChannel: API.OperationMethod<DeleteChannelRequest, DeleteChannelResponse, DeleteChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes the MSK cluster specified by the Amazon Resource Name (ARN) in the request.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterRequest, DeleteClusterResponse, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterPolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes the MSK cluster policy specified by the Amazon Resource Name (ARN) in the request.
 */
export declare const deleteClusterPolicy: API.OperationMethod<DeleteClusterPolicyRequest, DeleteClusterPolicyResponse, DeleteClusterPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes an MSK Configuration.
 */
export declare const deleteConfiguration: API.OperationMethod<DeleteConfigurationRequest, DeleteConfigurationResponse, DeleteConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicatorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a replicator.
 */
export declare const deleteReplicator: API.OperationMethod<DeleteReplicatorRequest, DeleteReplicatorResponse, DeleteReplicatorError, Credentials | HttpClient.HttpClient>;
export type DeleteTopicError = BadRequestException | ClusterConnectivityException | ControllerMovedException | ForbiddenException | GroupSubscribedToTopicException | InternalServerErrorException | KafkaRequestException | KafkaTimeoutException | NotControllerException | NotFoundException | ReassignmentInProgressException | UnknownTopicOrPartitionException | CommonErrors;
/**
 * Deletes a topic in the specified MSK cluster.
 */
export declare const deleteTopic: API.OperationMethod<DeleteTopicRequest, DeleteTopicResponse, DeleteTopicError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcConnectionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes a MSK VPC connection.
 */
export declare const deleteVpcConnection: API.OperationMethod<DeleteVpcConnectionRequest, DeleteVpcConnectionResponse, DeleteVpcConnectionError, Credentials | HttpClient.HttpClient>;
export type DescribeChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns the current configuration and state of a channel.
 */
export declare const describeChannel: API.OperationMethod<DescribeChannelRequest, DescribeChannelResponse, DescribeChannelError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of the MSK cluster whose Amazon Resource Name (ARN) is specified in the request.
 */
export declare const describeCluster: API.OperationMethod<DescribeClusterRequest, DescribeClusterResponse, DescribeClusterError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterOperationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of the cluster operation specified by the ARN.
 */
export declare const describeClusterOperation: API.OperationMethod<DescribeClusterOperationRequest, DescribeClusterOperationResponse, DescribeClusterOperationError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterOperationV2Error = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of the cluster operation specified by the ARN.
 */
export declare const describeClusterOperationV2: API.OperationMethod<DescribeClusterOperationV2Request, DescribeClusterOperationV2Response, DescribeClusterOperationV2Error, Credentials | HttpClient.HttpClient>;
export type DescribeClusterV2Error = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of the MSK cluster whose Amazon Resource Name (ARN) is specified in the request.
 */
export declare const describeClusterV2: API.OperationMethod<DescribeClusterV2Request, DescribeClusterV2Response, DescribeClusterV2Error, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of this MSK configuration.
 */
export declare const describeConfiguration: API.OperationMethod<DescribeConfigurationRequest, DescribeConfigurationResponse, DescribeConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationRevisionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of this revision of the configuration.
 */
export declare const describeConfigurationRevision: API.OperationMethod<DescribeConfigurationRevisionRequest, DescribeConfigurationRevisionResponse, DescribeConfigurationRevisionError, Credentials | HttpClient.HttpClient>;
export type DescribeReplicatorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describes a replicator.
 */
export declare const describeReplicator: API.OperationMethod<DescribeReplicatorRequest, DescribeReplicatorResponse, DescribeReplicatorError, Credentials | HttpClient.HttpClient>;
export type DescribeTopicError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns topic details of this topic on a MSK cluster.
 */
export declare const describeTopic: API.OperationMethod<DescribeTopicRequest, DescribeTopicResponse, DescribeTopicError, Credentials | HttpClient.HttpClient>;
export type DescribeTopicPartitionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns partition details of this topic on a MSK cluster.
 */
export declare const describeTopicPartitions: API.PaginatedOperationMethod<DescribeTopicPartitionsRequest, DescribeTopicPartitionsResponse, DescribeTopicPartitionsError, Credentials | HttpClient.HttpClient, TopicPartitionInfo>;
export type DescribeVpcConnectionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of this MSK VPC connection.
 */
export declare const describeVpcConnection: API.OperationMethod<DescribeVpcConnectionRequest, DescribeVpcConnectionResponse, DescribeVpcConnectionError, Credentials | HttpClient.HttpClient>;
export type GetBootstrapBrokersError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | UnauthorizedException | NotFoundException | CommonErrors;
/**
 * A list of brokers that a client application can use to bootstrap. This list doesn't necessarily include all of the brokers in the cluster. The following Python 3.6 example shows how you can use the Amazon Resource Name (ARN) of a cluster to get its bootstrap brokers. If you don't know the ARN of your cluster, you can use the `ListClusters` operation to get the ARNs of all the clusters in this account and Region.
 */
export declare const getBootstrapBrokers: API.OperationMethod<GetBootstrapBrokersRequest, GetBootstrapBrokersResponse, GetBootstrapBrokersError, Credentials | HttpClient.HttpClient>;
export type GetClusterPolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Get the MSK cluster policy specified by the Amazon Resource Name (ARN) in the request.
 */
export declare const getClusterPolicy: API.OperationMethod<GetClusterPolicyRequest, GetClusterPolicyResponse, GetClusterPolicyError, Credentials | HttpClient.HttpClient>;
export type GetCompatibleKafkaVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets the Apache Kafka versions to which you can update the MSK cluster.
 */
export declare const getCompatibleKafkaVersions: API.OperationMethod<GetCompatibleKafkaVersionsRequest, GetCompatibleKafkaVersionsResponse, GetCompatibleKafkaVersionsError, Credentials | HttpClient.HttpClient>;
export type ListChannelsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns the list of channels in a cluster.
 */
export declare const listChannels: API.OperationMethod<ListChannelsRequest, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient>;
export type ListClientVpcConnectionsError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the VPC connections in this Region.
 */
export declare const listClientVpcConnections: API.PaginatedOperationMethod<ListClientVpcConnectionsRequest, ListClientVpcConnectionsResponse, ListClientVpcConnectionsError, Credentials | HttpClient.HttpClient, ClientVpcConnection>;
export type ListClusterOperationsError = BadRequestException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the operations that have been performed on the specified MSK cluster.
 */
export declare const listClusterOperations: API.PaginatedOperationMethod<ListClusterOperationsRequest, ListClusterOperationsResponse, ListClusterOperationsError, Credentials | HttpClient.HttpClient, ClusterOperationInfo>;
export type ListClusterOperationsV2Error = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the operations that have been performed on the specified MSK cluster.
 */
export declare const listClusterOperationsV2: API.PaginatedOperationMethod<ListClusterOperationsV2Request, ListClusterOperationsV2Response, ListClusterOperationsV2Error, Credentials | HttpClient.HttpClient, ClusterOperationV2Summary>;
export type ListClustersError = BadRequestException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the MSK clusters in the current Region.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersRequest, ListClustersResponse, ListClustersError, Credentials | HttpClient.HttpClient, ClusterInfo>;
export type ListClustersV2Error = BadRequestException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the MSK clusters in the current Region.
 */
export declare const listClustersV2: API.PaginatedOperationMethod<ListClustersV2Request, ListClustersV2Response, ListClustersV2Error, Credentials | HttpClient.HttpClient, Cluster>;
export type ListConfigurationRevisionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the MSK configurations in this Region.
 */
export declare const listConfigurationRevisions: API.PaginatedOperationMethod<ListConfigurationRevisionsRequest, ListConfigurationRevisionsResponse, ListConfigurationRevisionsError, Credentials | HttpClient.HttpClient, ConfigurationRevision>;
export type ListConfigurationsError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the MSK configurations in this Region.
 */
export declare const listConfigurations: API.PaginatedOperationMethod<ListConfigurationsRequest, ListConfigurationsResponse, ListConfigurationsError, Credentials | HttpClient.HttpClient, Configuration>;
export type ListKafkaVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of Apache Kafka versions.
 */
export declare const listKafkaVersions: API.PaginatedOperationMethod<ListKafkaVersionsRequest, ListKafkaVersionsResponse, ListKafkaVersionsError, Credentials | HttpClient.HttpClient, KafkaVersion>;
export type ListNodesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns a list of the broker nodes in the cluster.
 */
export declare const listNodes: API.PaginatedOperationMethod<ListNodesRequest, ListNodesResponse, ListNodesError, Credentials | HttpClient.HttpClient, NodeInfo>;
export type ListReplicatorsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists the replicators.
 */
export declare const listReplicators: API.PaginatedOperationMethod<ListReplicatorsRequest, ListReplicatorsResponse, ListReplicatorsError, Credentials | HttpClient.HttpClient, ReplicatorSummary>;
export type ListScramSecretsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of the Scram Secrets associated with an Amazon MSK cluster.
 */
export declare const listScramSecrets: API.PaginatedOperationMethod<ListScramSecretsRequest, ListScramSecretsResponse, ListScramSecretsError, Credentials | HttpClient.HttpClient, string>;
export type ListTagsForResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns a list of the tags associated with the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTopicsError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | NotFoundException | CommonErrors;
/**
 * List topics in a MSK cluster.
 */
export declare const listTopics: API.PaginatedOperationMethod<ListTopicsRequest, ListTopicsResponse, ListTopicsError, Credentials | HttpClient.HttpClient, TopicInfo>;
export type ListVpcConnectionsError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the VPC connections in this Region.
 */
export declare const listVpcConnections: API.PaginatedOperationMethod<ListVpcConnectionsRequest, ListVpcConnectionsResponse, ListVpcConnectionsError, Credentials | HttpClient.HttpClient, VpcConnection>;
export type PutClusterPolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | CommonErrors;
/**
 * Creates or updates the MSK cluster policy specified by the cluster Amazon Resource Name (ARN) in the request.
 */
export declare const putClusterPolicy: API.OperationMethod<PutClusterPolicyRequest, PutClusterPolicyResponse, PutClusterPolicyError, Credentials | HttpClient.HttpClient>;
export type RebootBrokerError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Reboots brokers.
 */
export declare const rebootBroker: API.OperationMethod<RebootBrokerRequest, RebootBrokerResponse, RebootBrokerError, Credentials | HttpClient.HttpClient>;
export type RejectClientVpcConnectionError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns empty response.
 */
export declare const rejectClientVpcConnection: API.OperationMethod<RejectClientVpcConnectionRequest, RejectClientVpcConnectionResponse, RejectClientVpcConnectionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Adds tags to the specified MSK resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Removes the tags associated with the keys that are provided in the query.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBrokerCountError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the number of broker nodes in the cluster.
 */
export declare const updateBrokerCount: API.OperationMethod<UpdateBrokerCountRequest, UpdateBrokerCountResponse, UpdateBrokerCountError, Credentials | HttpClient.HttpClient>;
export type UpdateBrokerStorageError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the EBS storage associated with MSK brokers.
 */
export declare const updateBrokerStorage: API.OperationMethod<UpdateBrokerStorageRequest, UpdateBrokerStorageResponse, UpdateBrokerStorageError, Credentials | HttpClient.HttpClient>;
export type UpdateBrokerTypeError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates EC2 instance type.
 */
export declare const updateBrokerType: API.OperationMethod<UpdateBrokerTypeRequest, UpdateBrokerTypeResponse, UpdateBrokerTypeError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates the destination configuration of an existing channel. Exactly one of icebergDestinationUpdate or s3DestinationUpdate must be supplied.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelRequest, UpdateChannelResponse, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the cluster with the configuration that is specified in the request body.
 */
export declare const updateClusterConfiguration: API.OperationMethod<UpdateClusterConfigurationRequest, UpdateClusterConfigurationResponse, UpdateClusterConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterKafkaVersionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates the Apache Kafka version for the cluster.
 */
export declare const updateClusterKafkaVersion: API.OperationMethod<UpdateClusterKafkaVersionRequest, UpdateClusterKafkaVersionResponse, UpdateClusterKafkaVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates an MSK configuration.
 */
export declare const updateConfiguration: API.OperationMethod<UpdateConfigurationRequest, UpdateConfigurationResponse, UpdateConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectivityError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the cluster's connectivity configuration.
 */
export declare const updateConnectivity: API.OperationMethod<UpdateConnectivityRequest, UpdateConnectivityResponse, UpdateConnectivityError, Credentials | HttpClient.HttpClient>;
export type UpdateMonitoringError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the monitoring settings for the cluster. You can use this operation to specify which Apache Kafka metrics you want Amazon MSK to send to Amazon CloudWatch. You can also specify settings for open monitoring with Prometheus.
 */
export declare const updateMonitoring: API.OperationMethod<UpdateMonitoringRequest, UpdateMonitoringResponse, UpdateMonitoringError, Credentials | HttpClient.HttpClient>;
export type UpdateRebalancingError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Use this resource to update the intelligent rebalancing status of an Amazon MSK Provisioned cluster with Express brokers.
 */
export declare const updateRebalancing: API.OperationMethod<UpdateRebalancingRequest, UpdateRebalancingResponse, UpdateRebalancingError, Credentials | HttpClient.HttpClient>;
export type UpdateReplicationInfoError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates replication info of a replicator.
 */
export declare const updateReplicationInfo: API.OperationMethod<UpdateReplicationInfoRequest, UpdateReplicationInfoResponse, UpdateReplicationInfoError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates the security settings for the cluster. You can use this operation to specify encryption and authentication on existing clusters.
 */
export declare const updateSecurity: API.OperationMethod<UpdateSecurityRequest, UpdateSecurityResponse, UpdateSecurityError, Credentials | HttpClient.HttpClient>;
export type UpdateStorageError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates cluster broker volume size (or) sets cluster storage mode to TIERED.
 */
export declare const updateStorage: API.OperationMethod<UpdateStorageRequest, UpdateStorageResponse, UpdateStorageError, Credentials | HttpClient.HttpClient>;
export type UpdateTopicError = BadRequestException | ClusterConnectivityException | ControllerMovedException | ForbiddenException | GroupSubscribedToTopicException | InternalServerErrorException | KafkaRequestException | KafkaTimeoutException | NotControllerException | NotFoundException | ReassignmentInProgressException | ServiceUnavailableException | UnauthorizedException | UnknownTopicOrPartitionException | CommonErrors;
/**
 * Updates the configuration of the specified topic.
 */
export declare const updateTopic: API.OperationMethod<UpdateTopicRequest, UpdateTopicResponse, UpdateTopicError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=kafka.d.ts.map