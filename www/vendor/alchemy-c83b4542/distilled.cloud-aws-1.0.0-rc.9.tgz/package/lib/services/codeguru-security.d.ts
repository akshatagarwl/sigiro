import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly errorCode: any;
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly errorCode: any;
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly error: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly errorCode: any;
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly errorCode: any;
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly errorCode: any;
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface FindingIdentifier {
    scanName: string;
    findingId: string;
}
export declare const FindingIdentifier: S.Schema<FindingIdentifier>;
export type FindingIdentifiers = FindingIdentifier[];
export declare const FindingIdentifiers: any;
export interface BatchGetFindingsRequest {
    findingIdentifiers: FindingIdentifier[];
}
export declare const BatchGetFindingsRequest: S.Schema<BatchGetFindingsRequest>;
export type Status = "Closed" | "Open" | "All" | (string & {});
export declare const Status: any;
export interface Resource {
    id?: string;
    subResourceId?: string;
}
export declare const Resource: S.Schema<Resource>;
export type ReferenceUrls = string[];
export declare const ReferenceUrls: any;
export type RelatedVulnerabilities = string[];
export declare const RelatedVulnerabilities: any;
export interface CodeLine {
    number?: number;
    content?: string;
}
export declare const CodeLine: S.Schema<CodeLine>;
export type CodeSnippet = CodeLine[];
export declare const CodeSnippet: any;
export interface FilePath {
    name?: string;
    path?: string;
    startLine?: number;
    endLine?: number;
    codeSnippet?: CodeLine[];
}
export declare const FilePath: S.Schema<FilePath>;
export interface Vulnerability {
    referenceUrls?: string[];
    relatedVulnerabilities?: string[];
    id?: string;
    filePath?: FilePath;
    itemCount?: number;
}
export declare const Vulnerability: S.Schema<Vulnerability>;
export type Severity = "Critical" | "High" | "Medium" | "Low" | "Info" | (string & {});
export declare const Severity: any;
export interface Recommendation {
    text?: string;
    url?: string;
}
export declare const Recommendation: S.Schema<Recommendation>;
export interface SuggestedFix {
    description?: string;
    code?: string;
}
export declare const SuggestedFix: S.Schema<SuggestedFix>;
export type SuggestedFixes = SuggestedFix[];
export declare const SuggestedFixes: any;
export interface Remediation {
    recommendation?: Recommendation;
    suggestedFixes?: SuggestedFix[];
}
export declare const Remediation: S.Schema<Remediation>;
export type DetectorTags = string[];
export declare const DetectorTags: any;
export interface Finding {
    createdAt?: Date;
    description?: string;
    generatorId?: string;
    id?: string;
    updatedAt?: Date;
    type?: string;
    status?: Status;
    resource?: Resource;
    vulnerability?: Vulnerability;
    severity?: Severity;
    remediation?: Remediation;
    title?: string;
    detectorTags?: string[];
    detectorId?: string;
    detectorName?: string;
    ruleId?: string;
}
export declare const Finding: S.Schema<Finding>;
export type Findings = Finding[];
export declare const Findings: any;
export type ScanName = string;
export type ErrorCode = "DUPLICATE_IDENTIFIER" | "ITEM_DOES_NOT_EXIST" | "INTERNAL_ERROR" | "INVALID_FINDING_ID" | "INVALID_SCAN_NAME" | (string & {});
export declare const ErrorCode: any;
export interface BatchGetFindingsError_ {
    scanName: string;
    findingId: string;
    errorCode: ErrorCode;
    message: string;
}
export declare const BatchGetFindingsError_: S.Schema<BatchGetFindingsError_>;
export type BatchGetFindingsErrors = BatchGetFindingsError_[];
export declare const BatchGetFindingsErrors: any;
export interface BatchGetFindingsResponse {
    findings: Finding[];
    failedFindings: BatchGetFindingsError_[];
}
export declare const BatchGetFindingsResponse: S.Schema<BatchGetFindingsResponse>;
export type ClientToken = string;
export type Uuid = string;
export type ResourceId = {
    codeArtifactId: string;
};
export declare const ResourceId: any;
export type ScanType = "Standard" | "Express" | (string & {});
export declare const ScanType: any;
export type AnalysisType = "Security" | "All" | (string & {});
export declare const AnalysisType: any;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateScanRequest {
    clientToken?: string;
    resourceId: ResourceId;
    scanName: string;
    scanType?: ScanType;
    analysisType?: AnalysisType;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateScanRequest: S.Schema<CreateScanRequest>;
export type ScanState = "InProgress" | "Successful" | "Failed" | (string & {});
export declare const ScanState: any;
export type ScanNameArn = string;
export interface CreateScanResponse {
    scanName: string;
    runId: string;
    resourceId: ResourceId;
    scanState: ScanState;
    scanNameArn?: string;
}
export declare const CreateScanResponse: S.Schema<CreateScanResponse>;
export interface CreateUploadUrlRequest {
    scanName: string;
}
export declare const CreateUploadUrlRequest: S.Schema<CreateUploadUrlRequest>;
export type S3Url = string | redacted.Redacted<string>;
export type HeaderKey = string;
export type HeaderValue = string;
export type RequestHeaderMap = {
    [key: string]: string | undefined;
};
export declare const RequestHeaderMap: any;
export interface CreateUploadUrlResponse {
    s3Url: string | redacted.Redacted<string>;
    requestHeaders: {
        [key: string]: string | undefined;
    };
    codeArtifactId: string;
}
export declare const CreateUploadUrlResponse: S.Schema<CreateUploadUrlResponse>;
export interface GetAccountConfigurationRequest {
}
export declare const GetAccountConfigurationRequest: S.Schema<GetAccountConfigurationRequest>;
export type KmsKeyArn = string;
export interface EncryptionConfig {
    kmsKeyArn?: string;
}
export declare const EncryptionConfig: S.Schema<EncryptionConfig>;
export interface GetAccountConfigurationResponse {
    encryptionConfig: EncryptionConfig;
}
export declare const GetAccountConfigurationResponse: S.Schema<GetAccountConfigurationResponse>;
export type NextToken = string;
export interface GetFindingsRequest {
    scanName: string;
    nextToken?: string;
    maxResults?: number;
    status?: Status;
}
export declare const GetFindingsRequest: S.Schema<GetFindingsRequest>;
export interface GetFindingsResponse {
    findings?: Finding[];
    nextToken?: string;
}
export declare const GetFindingsResponse: S.Schema<GetFindingsResponse>;
export interface GetMetricsSummaryRequest {
    date: Date;
}
export declare const GetMetricsSummaryRequest: S.Schema<GetMetricsSummaryRequest>;
export interface FindingMetricsValuePerSeverity {
    info?: number;
    low?: number;
    medium?: number;
    high?: number;
    critical?: number;
}
export declare const FindingMetricsValuePerSeverity: S.Schema<FindingMetricsValuePerSeverity>;
export interface CategoryWithFindingNum {
    categoryName?: string;
    findingNumber?: number;
}
export declare const CategoryWithFindingNum: S.Schema<CategoryWithFindingNum>;
export type CategoriesWithMostFindings = CategoryWithFindingNum[];
export declare const CategoriesWithMostFindings: any;
export interface ScanNameWithFindingNum {
    scanName?: string;
    findingNumber?: number;
}
export declare const ScanNameWithFindingNum: S.Schema<ScanNameWithFindingNum>;
export type ScansWithMostOpenFindings = ScanNameWithFindingNum[];
export declare const ScansWithMostOpenFindings: any;
export type ScansWithMostOpenCriticalFindings = ScanNameWithFindingNum[];
export declare const ScansWithMostOpenCriticalFindings: any;
export interface MetricsSummary {
    date?: Date;
    openFindings?: FindingMetricsValuePerSeverity;
    categoriesWithMostFindings?: CategoryWithFindingNum[];
    scansWithMostOpenFindings?: ScanNameWithFindingNum[];
    scansWithMostOpenCriticalFindings?: ScanNameWithFindingNum[];
}
export declare const MetricsSummary: S.Schema<MetricsSummary>;
export interface GetMetricsSummaryResponse {
    metricsSummary?: MetricsSummary;
}
export declare const GetMetricsSummaryResponse: S.Schema<GetMetricsSummaryResponse>;
export interface GetScanRequest {
    scanName: string;
    runId?: string;
}
export declare const GetScanRequest: S.Schema<GetScanRequest>;
export type ErrorMessage = string;
export interface GetScanResponse {
    scanName: string;
    runId: string;
    scanState: ScanState;
    createdAt: Date;
    analysisType: AnalysisType;
    updatedAt?: Date;
    numberOfRevisions?: number;
    scanNameArn?: string;
    errorMessage?: string;
}
export declare const GetScanResponse: S.Schema<GetScanResponse>;
export interface ListFindingsMetricsRequest {
    nextToken?: string;
    maxResults?: number;
    startDate: Date;
    endDate: Date;
}
export declare const ListFindingsMetricsRequest: S.Schema<ListFindingsMetricsRequest>;
export interface AccountFindingsMetric {
    date?: Date;
    newFindings?: FindingMetricsValuePerSeverity;
    closedFindings?: FindingMetricsValuePerSeverity;
    openFindings?: FindingMetricsValuePerSeverity;
    meanTimeToClose?: FindingMetricsValuePerSeverity;
}
export declare const AccountFindingsMetric: S.Schema<AccountFindingsMetric>;
export type FindingsMetricList = AccountFindingsMetric[];
export declare const FindingsMetricList: any;
export interface ListFindingsMetricsResponse {
    findingsMetrics?: AccountFindingsMetric[];
    nextToken?: string;
}
export declare const ListFindingsMetricsResponse: S.Schema<ListFindingsMetricsResponse>;
export interface ListScansRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListScansRequest: S.Schema<ListScansRequest>;
export interface ScanSummary {
    scanState: ScanState;
    createdAt: Date;
    updatedAt?: Date;
    scanName: string;
    runId: string;
    scanNameArn?: string;
}
export declare const ScanSummary: S.Schema<ScanSummary>;
export type ScanSummaries = ScanSummary[];
export declare const ScanSummaries: any;
export interface ListScansResponse {
    summaries?: ScanSummary[];
    nextToken?: string;
}
export declare const ListScansResponse: S.Schema<ListScansResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAccountConfigurationRequest {
    encryptionConfig: EncryptionConfig;
}
export declare const UpdateAccountConfigurationRequest: S.Schema<UpdateAccountConfigurationRequest>;
export interface UpdateAccountConfigurationResponse {
    encryptionConfig: EncryptionConfig;
}
export declare const UpdateAccountConfigurationResponse: S.Schema<UpdateAccountConfigurationResponse>;
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | "lambdaCodeShaMisMatch" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type BatchGetFindingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of requested findings from standard scans.
 */
export declare const batchGetFindings: API.OperationMethod<BatchGetFindingsRequest, BatchGetFindingsResponse, BatchGetFindingsError, Credentials | HttpClient.HttpClient>;
export type CreateScanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use to create a scan using code uploaded to an Amazon S3 bucket.
 */
export declare const createScan: API.OperationMethod<CreateScanRequest, CreateScanResponse, CreateScanError, Credentials | HttpClient.HttpClient>;
export type CreateUploadUrlError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates a pre-signed URL, request headers used to upload a code resource, and code artifact identifier for the uploaded resource.
 *
 * You can upload your code resource to the URL with the request headers using any HTTP client.
 */
export declare const createUploadUrl: API.OperationMethod<CreateUploadUrlRequest, CreateUploadUrlResponse, CreateUploadUrlError, Credentials | HttpClient.HttpClient>;
export type GetAccountConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use to get the encryption configuration for an account.
 */
export declare const getAccountConfiguration: API.OperationMethod<GetAccountConfigurationRequest, GetAccountConfigurationResponse, GetAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetFindingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all findings generated by a particular scan.
 */
export declare const getFindings: API.PaginatedOperationMethod<GetFindingsRequest, GetFindingsResponse, GetFindingsError, Credentials | HttpClient.HttpClient, Finding>;
export type GetMetricsSummaryError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a summary of metrics for an account from a specified date, including number of open findings, the categories with most findings, the scans with most open findings, and scans with most open critical findings.
 */
export declare const getMetricsSummary: API.OperationMethod<GetMetricsSummaryRequest, GetMetricsSummaryResponse, GetMetricsSummaryError, Credentials | HttpClient.HttpClient>;
export type GetScanError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about a scan, including whether or not a scan has completed.
 */
export declare const getScan: API.OperationMethod<GetScanRequest, GetScanResponse, GetScanError, Credentials | HttpClient.HttpClient>;
export type ListFindingsMetricsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns metrics about all findings in an account within a specified time range.
 */
export declare const listFindingsMetrics: API.PaginatedOperationMethod<ListFindingsMetricsRequest, ListFindingsMetricsResponse, ListFindingsMetricsError, Credentials | HttpClient.HttpClient, AccountFindingsMetric>;
export type ListScansError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all scans in an account. Does not return `EXPRESS` scans.
 */
export declare const listScans: API.PaginatedOperationMethod<ListScansRequest, ListScansResponse, ListScansError, Credentials | HttpClient.HttpClient, ScanSummary>;
export type ListTagsForResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all tags associated with a scan.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use to add one or more tags to an existing scan.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use to remove one or more tags from an existing scan.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use to update the encryption configuration for an account.
 */
export declare const updateAccountConfiguration: API.OperationMethod<UpdateAccountConfigurationRequest, UpdateAccountConfigurationResponse, UpdateAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codeguru-security.d.ts.map