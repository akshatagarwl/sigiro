import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceArn: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type KeyspaceName = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type Rs = string;
export type Region = string;
export type RegionList = string[];
export declare const RegionList: any;
export interface ReplicationSpecification {
    replicationStrategy: string;
    regionList?: string[];
}
export declare const ReplicationSpecification: S.Schema<ReplicationSpecification>;
export interface CreateKeyspaceRequest {
    keyspaceName: string;
    tags?: Tag[];
    replicationSpecification?: ReplicationSpecification;
}
export declare const CreateKeyspaceRequest: S.Schema<CreateKeyspaceRequest>;
export type ARN = string;
export interface CreateKeyspaceResponse {
    resourceArn: string;
}
export declare const CreateKeyspaceResponse: S.Schema<CreateKeyspaceResponse>;
export type TableName = string;
export interface ColumnDefinition {
    name: string;
    type: string;
}
export declare const ColumnDefinition: S.Schema<ColumnDefinition>;
export type ColumnDefinitionList = ColumnDefinition[];
export declare const ColumnDefinitionList: any;
export interface PartitionKey {
    name: string;
}
export declare const PartitionKey: S.Schema<PartitionKey>;
export type PartitionKeyList = PartitionKey[];
export declare const PartitionKeyList: any;
export type SortOrder = string;
export interface ClusteringKey {
    name: string;
    orderBy: string;
}
export declare const ClusteringKey: S.Schema<ClusteringKey>;
export type ClusteringKeyList = ClusteringKey[];
export declare const ClusteringKeyList: any;
export interface StaticColumn {
    name: string;
}
export declare const StaticColumn: S.Schema<StaticColumn>;
export type StaticColumnList = StaticColumn[];
export declare const StaticColumnList: any;
export interface SchemaDefinition {
    allColumns: ColumnDefinition[];
    partitionKeys: PartitionKey[];
    clusteringKeys?: ClusteringKey[];
    staticColumns?: StaticColumn[];
}
export declare const SchemaDefinition: S.Schema<SchemaDefinition>;
export interface Comment {
    message: string;
}
export declare const Comment: S.Schema<Comment>;
export type ThroughputMode = string;
export type CapacityUnits = number;
export interface CapacitySpecification {
    throughputMode: string;
    readCapacityUnits?: number;
    writeCapacityUnits?: number;
}
export declare const CapacitySpecification: S.Schema<CapacitySpecification>;
export type EncryptionType = string;
export type KmsKeyARN = string;
export interface EncryptionSpecification {
    type: string;
    kmsKeyIdentifier?: string;
}
export declare const EncryptionSpecification: S.Schema<EncryptionSpecification>;
export type PointInTimeRecoveryStatus = string;
export interface PointInTimeRecovery {
    status: string;
}
export declare const PointInTimeRecovery: S.Schema<PointInTimeRecovery>;
export type TimeToLiveStatus = string;
export interface TimeToLive {
    status: string;
}
export declare const TimeToLive: S.Schema<TimeToLive>;
export type DefaultTimeToLive = number;
export type ClientSideTimestampsStatus = string;
export interface ClientSideTimestamps {
    status: string;
}
export declare const ClientSideTimestamps: S.Schema<ClientSideTimestamps>;
export type IntegerObject = number;
export type DoubleObject = number;
export interface TargetTrackingScalingPolicyConfiguration {
    disableScaleIn?: boolean;
    scaleInCooldown?: number;
    scaleOutCooldown?: number;
    targetValue: number;
}
export declare const TargetTrackingScalingPolicyConfiguration: S.Schema<TargetTrackingScalingPolicyConfiguration>;
export interface AutoScalingPolicy {
    targetTrackingScalingPolicyConfiguration?: TargetTrackingScalingPolicyConfiguration;
}
export declare const AutoScalingPolicy: S.Schema<AutoScalingPolicy>;
export interface AutoScalingSettings {
    autoScalingDisabled?: boolean;
    minimumUnits?: number;
    maximumUnits?: number;
    scalingPolicy?: AutoScalingPolicy;
}
export declare const AutoScalingSettings: S.Schema<AutoScalingSettings>;
export interface AutoScalingSpecification {
    writeCapacityAutoScaling?: AutoScalingSettings;
    readCapacityAutoScaling?: AutoScalingSettings;
}
export declare const AutoScalingSpecification: S.Schema<AutoScalingSpecification>;
export interface ReplicaSpecification {
    region: string;
    readCapacityUnits?: number;
    readCapacityAutoScaling?: AutoScalingSettings;
}
export declare const ReplicaSpecification: S.Schema<ReplicaSpecification>;
export type ReplicaSpecificationList = ReplicaSpecification[];
export declare const ReplicaSpecificationList: any;
export type CdcStatus = string;
export type ViewType = string;
export type CdcPropagateTags = string;
export interface CdcSpecification {
    status: string;
    viewType?: string;
    tags?: Tag[];
    propagateTags?: string;
}
export declare const CdcSpecification: S.Schema<CdcSpecification>;
export interface WarmThroughputSpecification {
    readUnitsPerSecond?: number;
    writeUnitsPerSecond?: number;
}
export declare const WarmThroughputSpecification: S.Schema<WarmThroughputSpecification>;
export interface CreateTableRequest {
    keyspaceName: string;
    tableName: string;
    schemaDefinition: SchemaDefinition;
    comment?: Comment;
    capacitySpecification?: CapacitySpecification;
    encryptionSpecification?: EncryptionSpecification;
    pointInTimeRecovery?: PointInTimeRecovery;
    ttl?: TimeToLive;
    defaultTimeToLive?: number;
    tags?: Tag[];
    clientSideTimestamps?: ClientSideTimestamps;
    autoScalingSpecification?: AutoScalingSpecification;
    replicaSpecifications?: ReplicaSpecification[];
    cdcSpecification?: CdcSpecification;
    warmThroughputSpecification?: WarmThroughputSpecification;
}
export declare const CreateTableRequest: S.Schema<CreateTableRequest>;
export interface CreateTableResponse {
    resourceArn: string;
}
export declare const CreateTableResponse: S.Schema<CreateTableResponse>;
export type TypeName = string;
export interface FieldDefinition {
    name: string;
    type: string;
}
export declare const FieldDefinition: S.Schema<FieldDefinition>;
export type FieldList = FieldDefinition[];
export declare const FieldList: any;
export interface CreateTypeRequest {
    keyspaceName: string;
    typeName: string;
    fieldDefinitions: FieldDefinition[];
}
export declare const CreateTypeRequest: S.Schema<CreateTypeRequest>;
export interface CreateTypeResponse {
    keyspaceArn: string;
    typeName: string;
}
export declare const CreateTypeResponse: S.Schema<CreateTypeResponse>;
export interface DeleteKeyspaceRequest {
    keyspaceName: string;
}
export declare const DeleteKeyspaceRequest: S.Schema<DeleteKeyspaceRequest>;
export interface DeleteKeyspaceResponse {
}
export declare const DeleteKeyspaceResponse: S.Schema<DeleteKeyspaceResponse>;
export interface DeleteTableRequest {
    keyspaceName: string;
    tableName: string;
}
export declare const DeleteTableRequest: S.Schema<DeleteTableRequest>;
export interface DeleteTableResponse {
}
export declare const DeleteTableResponse: S.Schema<DeleteTableResponse>;
export interface DeleteTypeRequest {
    keyspaceName: string;
    typeName: string;
}
export declare const DeleteTypeRequest: S.Schema<DeleteTypeRequest>;
export interface DeleteTypeResponse {
    keyspaceArn: string;
    typeName: string;
}
export declare const DeleteTypeResponse: S.Schema<DeleteTypeResponse>;
export interface GetKeyspaceRequest {
    keyspaceName: string;
}
export declare const GetKeyspaceRequest: S.Schema<GetKeyspaceRequest>;
export type KeyspaceStatus = string;
export type TablesReplicationProgress = string;
export interface ReplicationGroupStatus {
    region: string;
    keyspaceStatus: string;
    tablesReplicationProgress?: string;
}
export declare const ReplicationGroupStatus: S.Schema<ReplicationGroupStatus>;
export type ReplicationGroupStatusList = ReplicationGroupStatus[];
export declare const ReplicationGroupStatusList: any;
export interface GetKeyspaceResponse {
    keyspaceName: string;
    resourceArn: string;
    replicationStrategy: string;
    replicationRegions?: string[];
    replicationGroupStatuses?: ReplicationGroupStatus[];
}
export declare const GetKeyspaceResponse: S.Schema<GetKeyspaceResponse>;
export interface GetTableRequest {
    keyspaceName: string;
    tableName: string;
}
export declare const GetTableRequest: S.Schema<GetTableRequest>;
export type TableStatus = string;
export interface CapacitySpecificationSummary {
    throughputMode: string;
    readCapacityUnits?: number;
    writeCapacityUnits?: number;
    lastUpdateToPayPerRequestTimestamp?: Date;
}
export declare const CapacitySpecificationSummary: S.Schema<CapacitySpecificationSummary>;
export interface PointInTimeRecoverySummary {
    status: string;
    earliestRestorableTimestamp?: Date;
}
export declare const PointInTimeRecoverySummary: S.Schema<PointInTimeRecoverySummary>;
export type WarmThroughputStatus = string;
export interface WarmThroughputSpecificationSummary {
    readUnitsPerSecond: number;
    writeUnitsPerSecond: number;
    status: string;
}
export declare const WarmThroughputSpecificationSummary: S.Schema<WarmThroughputSpecificationSummary>;
export interface ReplicaSpecificationSummary {
    region?: string;
    status?: string;
    capacitySpecification?: CapacitySpecificationSummary;
    warmThroughputSpecification?: WarmThroughputSpecificationSummary;
}
export declare const ReplicaSpecificationSummary: S.Schema<ReplicaSpecificationSummary>;
export type ReplicaSpecificationSummaryList = ReplicaSpecificationSummary[];
export declare const ReplicaSpecificationSummaryList: any;
export type StreamArn = string;
export interface CdcSpecificationSummary {
    status: string;
    viewType?: string;
}
export declare const CdcSpecificationSummary: S.Schema<CdcSpecificationSummary>;
export interface GetTableResponse {
    keyspaceName: string;
    tableName: string;
    resourceArn: string;
    creationTimestamp?: Date;
    status?: string;
    schemaDefinition?: SchemaDefinition;
    capacitySpecification?: CapacitySpecificationSummary;
    encryptionSpecification?: EncryptionSpecification;
    pointInTimeRecovery?: PointInTimeRecoverySummary;
    ttl?: TimeToLive;
    defaultTimeToLive?: number;
    comment?: Comment;
    clientSideTimestamps?: ClientSideTimestamps;
    replicaSpecifications?: ReplicaSpecificationSummary[];
    latestStreamArn?: string;
    cdcSpecification?: CdcSpecificationSummary;
    warmThroughputSpecification?: WarmThroughputSpecificationSummary;
}
export declare const GetTableResponse: S.Schema<GetTableResponse>;
export interface GetTableAutoScalingSettingsRequest {
    keyspaceName: string;
    tableName: string;
}
export declare const GetTableAutoScalingSettingsRequest: S.Schema<GetTableAutoScalingSettingsRequest>;
export interface ReplicaAutoScalingSpecification {
    region?: string;
    autoScalingSpecification?: AutoScalingSpecification;
}
export declare const ReplicaAutoScalingSpecification: S.Schema<ReplicaAutoScalingSpecification>;
export type ReplicaAutoScalingSpecificationList = ReplicaAutoScalingSpecification[];
export declare const ReplicaAutoScalingSpecificationList: any;
export interface GetTableAutoScalingSettingsResponse {
    keyspaceName: string;
    tableName: string;
    resourceArn: string;
    autoScalingSpecification?: AutoScalingSpecification;
    replicaSpecifications?: ReplicaAutoScalingSpecification[];
}
export declare const GetTableAutoScalingSettingsResponse: S.Schema<GetTableAutoScalingSettingsResponse>;
export interface GetTypeRequest {
    keyspaceName: string;
    typeName: string;
}
export declare const GetTypeRequest: S.Schema<GetTypeRequest>;
export type TypeStatus = string;
export type TableNameList = string[];
export declare const TableNameList: any;
export type TypeNameList = string[];
export declare const TypeNameList: any;
export type Depth = number;
export interface GetTypeResponse {
    keyspaceName: string;
    typeName: string;
    fieldDefinitions?: FieldDefinition[];
    lastModifiedTimestamp?: Date;
    status?: string;
    directReferringTables?: string[];
    directParentTypes?: string[];
    maxNestingDepth?: number;
    keyspaceArn: string;
}
export declare const GetTypeResponse: S.Schema<GetTypeResponse>;
export type NextToken = string;
export type MaxResults = number;
export interface ListKeyspacesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListKeyspacesRequest: S.Schema<ListKeyspacesRequest>;
export interface KeyspaceSummary {
    keyspaceName: string;
    resourceArn: string;
    replicationStrategy: string;
    replicationRegions?: string[];
}
export declare const KeyspaceSummary: S.Schema<KeyspaceSummary>;
export type KeyspaceSummaryList = KeyspaceSummary[];
export declare const KeyspaceSummaryList: any;
export interface ListKeyspacesResponse {
    nextToken?: string;
    keyspaces: KeyspaceSummary[];
}
export declare const ListKeyspacesResponse: S.Schema<ListKeyspacesResponse>;
export interface ListTablesRequest {
    nextToken?: string;
    maxResults?: number;
    keyspaceName: string;
}
export declare const ListTablesRequest: S.Schema<ListTablesRequest>;
export interface TableSummary {
    keyspaceName: string;
    tableName: string;
    resourceArn: string;
}
export declare const TableSummary: S.Schema<TableSummary>;
export type TableSummaryList = TableSummary[];
export declare const TableSummaryList: any;
export interface ListTablesResponse {
    nextToken?: string;
    tables?: TableSummary[];
}
export declare const ListTablesResponse: S.Schema<ListTablesResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    nextToken?: string;
    tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListTypesRequest {
    nextToken?: string;
    maxResults?: number;
    keyspaceName: string;
}
export declare const ListTypesRequest: S.Schema<ListTypesRequest>;
export interface ListTypesResponse {
    nextToken?: string;
    types: string[];
}
export declare const ListTypesResponse: S.Schema<ListTypesResponse>;
export interface RestoreTableRequest {
    sourceKeyspaceName: string;
    sourceTableName: string;
    targetKeyspaceName: string;
    targetTableName: string;
    restoreTimestamp?: Date;
    capacitySpecificationOverride?: CapacitySpecification;
    encryptionSpecificationOverride?: EncryptionSpecification;
    pointInTimeRecoveryOverride?: PointInTimeRecovery;
    tagsOverride?: Tag[];
    autoScalingSpecification?: AutoScalingSpecification;
    replicaSpecifications?: ReplicaSpecification[];
}
export declare const RestoreTableRequest: S.Schema<RestoreTableRequest>;
export interface RestoreTableResponse {
    restoredTableARN: string;
}
export declare const RestoreTableResponse: S.Schema<RestoreTableResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface UntagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateKeyspaceRequest {
    keyspaceName: string;
    replicationSpecification: ReplicationSpecification;
    clientSideTimestamps?: ClientSideTimestamps;
}
export declare const UpdateKeyspaceRequest: S.Schema<UpdateKeyspaceRequest>;
export interface UpdateKeyspaceResponse {
    resourceArn: string;
}
export declare const UpdateKeyspaceResponse: S.Schema<UpdateKeyspaceResponse>;
export interface UpdateTableRequest {
    keyspaceName: string;
    tableName: string;
    addColumns?: ColumnDefinition[];
    capacitySpecification?: CapacitySpecification;
    encryptionSpecification?: EncryptionSpecification;
    pointInTimeRecovery?: PointInTimeRecovery;
    ttl?: TimeToLive;
    defaultTimeToLive?: number;
    clientSideTimestamps?: ClientSideTimestamps;
    autoScalingSpecification?: AutoScalingSpecification;
    replicaSpecifications?: ReplicaSpecification[];
    cdcSpecification?: CdcSpecification;
    warmThroughputSpecification?: WarmThroughputSpecification;
}
export declare const UpdateTableRequest: S.Schema<UpdateTableRequest>;
export interface UpdateTableResponse {
    resourceArn: string;
}
export declare const UpdateTableResponse: S.Schema<UpdateTableResponse>;
export type CreateKeyspaceError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * The `CreateKeyspace` operation adds a new keyspace to your account. In an Amazon Web Services account, keyspace names must be unique within each Region.
 *
 * `CreateKeyspace` is an asynchronous operation. You can monitor the creation status of the new keyspace by using the `GetKeyspace` operation.
 *
 * For more information, see Create a keyspace in the *Amazon Keyspaces Developer Guide*.
 */
export declare const createKeyspace: API.OperationMethod<CreateKeyspaceRequest, CreateKeyspaceResponse, CreateKeyspaceError, Credentials | HttpClient.HttpClient>;
export type CreateTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * The `CreateTable` operation adds a new table to the specified keyspace. Within a keyspace, table names must be unique.
 *
 * `CreateTable` is an asynchronous operation. When the request is received, the status of the table is set to `CREATING`. You can monitor the creation status of the new table by using the `GetTable` operation, which returns the current `status` of the table. You can start using a table when the status is `ACTIVE`.
 *
 * For more information, see Create a table in the *Amazon Keyspaces Developer Guide*.
 */
export declare const createTable: API.OperationMethod<CreateTableRequest, CreateTableResponse, CreateTableError, Credentials | HttpClient.HttpClient>;
export type CreateTypeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * The `CreateType` operation creates a new user-defined type in the specified keyspace.
 *
 * To configure the required permissions, see Permissions to create a UDT in the *Amazon Keyspaces Developer Guide*.
 *
 * For more information, see User-defined types (UDTs) in the *Amazon Keyspaces Developer Guide*.
 */
export declare const createType: API.OperationMethod<CreateTypeRequest, CreateTypeResponse, CreateTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteKeyspaceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * The `DeleteKeyspace` operation deletes a keyspace and all of its tables.
 */
export declare const deleteKeyspace: API.OperationMethod<DeleteKeyspaceRequest, DeleteKeyspaceResponse, DeleteKeyspaceError, Credentials | HttpClient.HttpClient>;
export type DeleteTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * The `DeleteTable` operation deletes a table and all of its data. After a `DeleteTable` request is received, the specified table is in the `DELETING` state until Amazon Keyspaces completes the deletion. If the table is in the `ACTIVE` state, you can delete it. If a table is either in the `CREATING` or `UPDATING` states, then Amazon Keyspaces returns a `ResourceInUseException`. If the specified table does not exist, Amazon Keyspaces returns a `ResourceNotFoundException`. If the table is already in the `DELETING` state, no error is returned.
 */
export declare const deleteTable: API.OperationMethod<DeleteTableRequest, DeleteTableResponse, DeleteTableError, Credentials | HttpClient.HttpClient>;
export type DeleteTypeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * The `DeleteType` operation deletes a user-defined type (UDT). You can only delete a type that is not used in a table or another UDT.
 *
 * To configure the required permissions, see Permissions to delete a UDT in the *Amazon Keyspaces Developer Guide*.
 */
export declare const deleteType: API.OperationMethod<DeleteTypeRequest, DeleteTypeResponse, DeleteTypeError, Credentials | HttpClient.HttpClient>;
export type GetKeyspaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Returns the name of the specified keyspace, the Amazon Resource Name (ARN), the replication strategy, the Amazon Web Services Regions of a multi-Region keyspace, and the status of newly added Regions after an `UpdateKeyspace` operation.
 */
export declare const getKeyspace: API.OperationMethod<GetKeyspaceRequest, GetKeyspaceResponse, GetKeyspaceError, Credentials | HttpClient.HttpClient>;
export type GetTableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Returns information about the table, including the table's name and current status, the keyspace name, configuration settings, and metadata.
 *
 * To read table metadata using `GetTable`, the IAM principal needs `Select` action permissions for the table and the system keyspace.
 */
export declare const getTable: API.OperationMethod<GetTableRequest, GetTableResponse, GetTableError, Credentials | HttpClient.HttpClient>;
export type GetTableAutoScalingSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Returns auto scaling related settings of the specified table in JSON format. If the table is a multi-Region table, the Amazon Web Services Region specific auto scaling settings of the table are included.
 *
 * Amazon Keyspaces auto scaling helps you provision throughput capacity for variable workloads efficiently by increasing and decreasing your table's read and write capacity automatically in response to application traffic. For more information, see Managing throughput capacity automatically with Amazon Keyspaces auto scaling in the *Amazon Keyspaces Developer Guide*.
 *
 * `GetTableAutoScalingSettings` can't be used as an action in an IAM policy.
 *
 * To define permissions for `GetTableAutoScalingSettings`, you must allow the following two actions in the IAM policy statement's `Action` element:
 *
 * - `application-autoscaling:DescribeScalableTargets`
 *
 * - `application-autoscaling:DescribeScalingPolicies`
 */
export declare const getTableAutoScalingSettings: API.OperationMethod<GetTableAutoScalingSettingsRequest, GetTableAutoScalingSettingsResponse, GetTableAutoScalingSettingsError, Credentials | HttpClient.HttpClient>;
export type GetTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * The `GetType` operation returns information about the type, for example the field definitions, the timestamp when the type was last modified, the level of nesting, the status, and details about if the type is used in other types and tables.
 *
 * To read keyspace metadata using `GetType`, the IAM principal needs `Select` action permissions for the system keyspace. To configure the required permissions, see Permissions to view a UDT in the *Amazon Keyspaces Developer Guide*.
 */
export declare const getType: API.OperationMethod<GetTypeRequest, GetTypeResponse, GetTypeError, Credentials | HttpClient.HttpClient>;
export type ListKeyspacesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * The `ListKeyspaces` operation returns a list of keyspaces.
 */
export declare const listKeyspaces: API.PaginatedOperationMethod<ListKeyspacesRequest, ListKeyspacesResponse, ListKeyspacesError, Credentials | HttpClient.HttpClient, KeyspaceSummary>;
export type ListTablesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * The `ListTables` operation returns a list of tables for a specified keyspace.
 *
 * To read keyspace metadata using `ListTables`, the IAM principal needs `Select` action permissions for the system keyspace.
 */
export declare const listTables: API.PaginatedOperationMethod<ListTablesRequest, ListTablesResponse, ListTablesError, Credentials | HttpClient.HttpClient, TableSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Returns a list of all tags associated with the specified Amazon Keyspaces resource.
 *
 * To read keyspace metadata using `ListTagsForResource`, the IAM principal needs `Select` action permissions for the specified resource and the system keyspace.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type ListTypesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * The `ListTypes` operation returns a list of types for a specified keyspace.
 *
 * To read keyspace metadata using `ListTypes`, the IAM principal needs `Select` action permissions for the system keyspace. To configure the required permissions, see Permissions to view a UDT in the *Amazon Keyspaces Developer Guide*.
 */
export declare const listTypes: API.PaginatedOperationMethod<ListTypesRequest, ListTypesResponse, ListTypesError, Credentials | HttpClient.HttpClient, TypeName>;
export type RestoreTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Restores the table to the specified point in time within the `earliest_restorable_timestamp` and the current time. For more information about restore points, see Time window for PITR continuous backups in the *Amazon Keyspaces Developer Guide*.
 *
 * Any number of users can execute up to 4 concurrent restores (any type of restore) in a given account.
 *
 * When you restore using point in time recovery, Amazon Keyspaces restores your source table's schema and data to the state based on the selected timestamp `(day:hour:minute:second)` to a new table. The Time to Live (TTL) settings are also restored to the state based on the selected timestamp.
 *
 * In addition to the table's schema, data, and TTL settings, `RestoreTable` restores the capacity mode, auto scaling settings, encryption settings, and point-in-time recovery settings from the source table. Unlike the table's schema data and TTL settings, which are restored based on the selected timestamp, these settings are always restored based on the table's settings as of the current time or when the table was deleted.
 *
 * You can also overwrite these settings during restore:
 *
 * - Read/write capacity mode
 *
 * - Provisioned throughput capacity units
 *
 * - Auto scaling settings
 *
 * - Point-in-time (PITR) settings
 *
 * - Tags
 *
 * For more information, see PITR restore settings in the *Amazon Keyspaces Developer Guide*.
 *
 * Note that the following settings are not restored, and you must configure them manually for the new table:
 *
 * - Identity and Access Management (IAM) policies
 *
 * - Amazon CloudWatch metrics and alarms
 */
export declare const restoreTable: API.OperationMethod<RestoreTableRequest, RestoreTableResponse, RestoreTableError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Associates a set of tags with a Amazon Keyspaces resource. You can then activate these user-defined tags so that they appear on the Cost Management Console for cost allocation tracking. For more information, see Adding tags and labels to Amazon Keyspaces resources in the *Amazon Keyspaces Developer Guide*.
 *
 * For IAM policy examples that show how to control access to Amazon Keyspaces resources based on tags, see Amazon Keyspaces resource access based on tags in the *Amazon Keyspaces Developer Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Removes the association of tags from a Amazon Keyspaces resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateKeyspaceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Adds a new Amazon Web Services Region to the keyspace. You can add a new Region to a keyspace that is either a single or a multi-Region keyspace. Amazon Keyspaces is going to replicate all tables in the keyspace to the new Region. To successfully replicate all tables to the new Region, they must use client-side timestamps for conflict resolution. To enable client-side timestamps, specify `clientSideTimestamps.status = enabled` when invoking the API. For more information about client-side timestamps, see Client-side timestamps in Amazon Keyspaces in the *Amazon Keyspaces Developer Guide*.
 *
 * To add a Region to a keyspace using the `UpdateKeyspace` API, the IAM principal needs permissions for the following IAM actions:
 *
 * - `cassandra:Alter`
 *
 * - `cassandra:AlterMultiRegionResource`
 *
 * - `cassandra:Create`
 *
 * - `cassandra:CreateMultiRegionResource`
 *
 * - `cassandra:Select`
 *
 * - `cassandra:SelectMultiRegionResource`
 *
 * - `cassandra:Modify`
 *
 * - `cassandra:ModifyMultiRegionResource`
 *
 * If the keyspace contains a table that is configured in provisioned mode with auto scaling enabled, the following additional IAM actions need to be allowed.
 *
 * - `application-autoscaling:RegisterScalableTarget`
 *
 * - `application-autoscaling:DeregisterScalableTarget`
 *
 * - `application-autoscaling:DescribeScalableTargets`
 *
 * - `application-autoscaling:PutScalingPolicy`
 *
 * - `application-autoscaling:DescribeScalingPolicies`
 *
 * To use the `UpdateKeyspace` API, the IAM principal also needs permissions to create a service-linked role with the following elements:
 *
 * - `iam:CreateServiceLinkedRole` - The **action** the principal can perform.
 *
 * - `arn:aws:iam::*:role/aws-service-role/replication.cassandra.amazonaws.com/AWSServiceRoleForKeyspacesReplication` - The **resource** that the action can be performed on.
 *
 * - `iam:AWSServiceName: replication.cassandra.amazonaws.com` - The only Amazon Web Services service that this role can be attached to is Amazon Keyspaces.
 *
 * For more information, see Configure the IAM permissions required to add an Amazon Web Services Region to a keyspace in the *Amazon Keyspaces Developer Guide*.
 */
export declare const updateKeyspace: API.OperationMethod<UpdateKeyspaceRequest, UpdateKeyspaceResponse, UpdateKeyspaceError, Credentials | HttpClient.HttpClient>;
export type UpdateTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Adds new columns to the table or updates one of the table's settings, for example capacity mode, auto scaling, encryption, point-in-time recovery, or ttl settings. Note that you can only update one specific table setting per update operation.
 */
export declare const updateTable: API.OperationMethod<UpdateTableRequest, UpdateTableResponse, UpdateTableError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=keyspaces.d.ts.map