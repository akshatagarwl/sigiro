import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly errorCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ShardIterator = string;
export interface GetRecordsInput {
    shardIterator: string;
    maxResults?: number;
}
export declare const GetRecordsInput: S.Schema<GetRecordsInput>;
export type OriginType = "USER" | "REPLICATION" | "TTL" | (string & {});
export declare const OriginType: any;
export interface KeyspacesMetadata {
    expirationTime?: string;
    writeTime?: string;
}
export declare const KeyspacesMetadata: S.Schema<KeyspacesMetadata>;
export interface KeyspacesCell {
    value?: KeyspacesCellValue;
    metadata?: KeyspacesMetadata;
}
export declare const KeyspacesCell: S.Schema<KeyspacesCell>;
export type KeyspacesCellList = KeyspacesCell[];
export declare const KeyspacesCellList: S.Schema<KeyspacesCellList>;
export interface KeyspacesCellMapDefinition {
    key?: KeyspacesCellValue;
    value?: KeyspacesCellValue;
    metadata?: KeyspacesMetadata;
}
export declare const KeyspacesCellMapDefinition: S.Schema<KeyspacesCellMapDefinition>;
export type KeyspacesCellMap = KeyspacesCellMapDefinition[];
export declare const KeyspacesCellMap: S.Schema<KeyspacesCellMap>;
export type KeyspacesUdtMap = {
    [key: string]: KeyspacesCell | undefined;
};
export declare const KeyspacesUdtMap: S.Schema<KeyspacesUdtMap>;
export type KeyspacesCellValue = {
    asciiT: string;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT: string;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT: Uint8Array;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT: boolean;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT: string;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT: string;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT: string;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT: string;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT: string;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT: string;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT: string;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT: string;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT: KeyspacesCell[];
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT: KeyspacesCellMapDefinition[];
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT: KeyspacesCell[];
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT: string;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT: string;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT: string;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT: string;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT: string;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT: string;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT: KeyspacesCell[];
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT: string;
    varcharT?: never;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT: string;
    varintT?: never;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT: string;
    udtT?: never;
} | {
    asciiT?: never;
    bigintT?: never;
    blobT?: never;
    boolT?: never;
    counterT?: never;
    dateT?: never;
    decimalT?: never;
    doubleT?: never;
    durationT?: never;
    floatT?: never;
    inetT?: never;
    intT?: never;
    listT?: never;
    mapT?: never;
    setT?: never;
    smallintT?: never;
    textT?: never;
    timeT?: never;
    timestampT?: never;
    timeuuidT?: never;
    tinyintT?: never;
    tupleT?: never;
    uuidT?: never;
    varcharT?: never;
    varintT?: never;
    udtT: {
        [key: string]: KeyspacesCell | undefined;
    };
};
export declare const KeyspacesCellValue: S.Schema<KeyspacesCellValue>;
export type KeyspacesKeysMap = {
    [key: string]: KeyspacesCellValue | undefined;
};
export declare const KeyspacesKeysMap: any;
export type KeyspacesCells = {
    [key: string]: KeyspacesCell | undefined;
};
export declare const KeyspacesCells: any;
export interface KeyspacesRow {
    valueCells?: {
        [key: string]: KeyspacesCell | undefined;
    };
    staticCells?: {
        [key: string]: KeyspacesCell | undefined;
    };
    rowMetadata?: KeyspacesMetadata;
}
export declare const KeyspacesRow: S.Schema<KeyspacesRow>;
export type SequenceNumber = string;
export interface Record {
    eventVersion?: string;
    createdAt?: Date;
    origin?: OriginType;
    partitionKeys?: {
        [key: string]: KeyspacesCellValue | undefined;
    };
    clusteringKeys?: {
        [key: string]: KeyspacesCellValue | undefined;
    };
    newImage?: KeyspacesRow;
    oldImage?: KeyspacesRow;
    sequenceNumber?: string;
}
export declare const Record: S.Schema<Record>;
export type RecordList = Record[];
export declare const RecordList: any;
export type IteratorPosition = "AT_TIP" | "BEHIND_TIP" | (string & {});
export declare const IteratorPosition: any;
export interface IteratorDescription {
    iteratorPosition?: IteratorPosition;
}
export declare const IteratorDescription: S.Schema<IteratorDescription>;
export interface GetRecordsOutput {
    changeRecords?: Record[];
    nextShardIterator?: string;
    iteratorDescription?: IteratorDescription;
}
export declare const GetRecordsOutput: S.Schema<GetRecordsOutput>;
export type StreamArn = string;
export type ShardId = string;
export type ShardIteratorType = "TRIM_HORIZON" | "LATEST" | "AT_SEQUENCE_NUMBER" | "AFTER_SEQUENCE_NUMBER" | (string & {});
export declare const ShardIteratorType: any;
export interface GetShardIteratorInput {
    streamArn: string;
    shardId: string;
    shardIteratorType: ShardIteratorType;
    sequenceNumber?: string;
}
export declare const GetShardIteratorInput: S.Schema<GetShardIteratorInput>;
export interface GetShardIteratorOutput {
    shardIterator?: string;
}
export declare const GetShardIteratorOutput: S.Schema<GetShardIteratorOutput>;
export type ShardFilterType = "CHILD_SHARDS" | (string & {});
export declare const ShardFilterType: any;
export interface ShardFilter {
    type?: ShardFilterType;
    shardId?: string;
}
export declare const ShardFilter: S.Schema<ShardFilter>;
export type ShardIdToken = string;
export interface GetStreamInput {
    streamArn: string;
    maxResults?: number;
    shardFilter?: ShardFilter;
    nextToken?: string;
}
export declare const GetStreamInput: S.Schema<GetStreamInput>;
export type StreamStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | (string & {});
export declare const StreamStatus: any;
export type StreamViewType = "NEW_IMAGE" | "OLD_IMAGE" | "NEW_AND_OLD_IMAGES" | "KEYS_ONLY" | (string & {});
export declare const StreamViewType: any;
export type KeyspaceName = string;
export type TableName = string;
export interface SequenceNumberRange {
    startingSequenceNumber?: string;
    endingSequenceNumber?: string;
}
export declare const SequenceNumberRange: S.Schema<SequenceNumberRange>;
export type ShardIdList = string[];
export declare const ShardIdList: any;
export interface Shard {
    shardId?: string;
    sequenceNumberRange?: SequenceNumberRange;
    parentShardIds?: string[];
}
export declare const Shard: S.Schema<Shard>;
export type ShardDescriptionList = Shard[];
export declare const ShardDescriptionList: any;
export interface GetStreamOutput {
    streamArn: string;
    streamLabel: string;
    streamStatus: StreamStatus;
    streamViewType: StreamViewType;
    creationRequestDateTime: Date;
    keyspaceName: string;
    tableName: string;
    shards?: Shard[];
    nextToken?: string;
}
export declare const GetStreamOutput: S.Schema<GetStreamOutput>;
export type StreamArnToken = string;
export interface ListStreamsInput {
    keyspaceName?: string;
    tableName?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListStreamsInput: S.Schema<ListStreamsInput>;
export interface Stream {
    streamArn: string;
    keyspaceName: string;
    tableName: string;
    streamLabel: string;
}
export declare const Stream: S.Schema<Stream>;
export type StreamList = Stream[];
export declare const StreamList: any;
export interface ListStreamsOutput {
    streams?: Stream[];
    nextToken?: string;
}
export declare const ListStreamsOutput: S.Schema<ListStreamsOutput>;
export type ValidationExceptionType = "InvalidFormat" | "TrimmedDataAccess" | "ExpiredIterator" | "ExpiredNextToken" | (string & {});
export declare const ValidationExceptionType: any;
export type GetRecordsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves data records from a specified shard in an Amazon Keyspaces data stream. This operation returns a collection of data records from the shard, including the primary key columns and information about modifications made to the captured table data. Each record represents a single data modification in the Amazon Keyspaces table and includes metadata about when the change occurred.
 */
export declare const getRecords: API.OperationMethod<GetRecordsInput, GetRecordsOutput, GetRecordsError, Credentials | HttpClient.HttpClient>;
export type GetShardIteratorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a shard iterator that serves as a bookmark for reading data from a specific position in an Amazon Keyspaces data stream's shard. The shard iterator specifies the shard position from which to start reading data records sequentially. You can specify whether to begin reading at the latest record, the oldest record, or at a particular sequence number within the shard.
 */
export declare const getShardIterator: API.OperationMethod<GetShardIteratorInput, GetShardIteratorOutput, GetShardIteratorError, Credentials | HttpClient.HttpClient>;
export type GetStreamError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed information about a specific data capture stream for an Amazon Keyspaces table. The information includes the stream's Amazon Resource Name (ARN), creation time, current status, retention period, shard composition, and associated table details. This operation helps you monitor and manage the configuration of your Amazon Keyspaces data streams.
 */
export declare const getStream: API.PaginatedOperationMethod<GetStreamInput, GetStreamOutput, GetStreamError, Credentials | HttpClient.HttpClient, Shard>;
export type ListStreamsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all data capture streams associated with your Amazon Keyspaces account or for a specific keyspace or table. The response includes information such as stream ARNs, table associations, creation timestamps, and current status. This operation helps you discover and manage all active data streams in your Amazon Keyspaces environment.
 */
export declare const listStreams: API.PaginatedOperationMethod<ListStreamsInput, ListStreamsOutput, ListStreamsError, Credentials | HttpClient.HttpClient, Stream>;
export {};
//# sourceMappingURL=keyspacesstreams.d.ts.map