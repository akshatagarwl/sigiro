import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
export type GenericId = string;
export interface GetSearchJobInput {
    SearchJobIdentifier: string;
}
export declare const GetSearchJobInput: S.Schema<GetSearchJobInput>;
export interface SearchScopeSummary {
    TotalRecoveryPointsToScanCount?: number;
    TotalItemsToScanCount?: number;
}
export declare const SearchScopeSummary: S.Schema<SearchScopeSummary>;
export interface CurrentSearchProgress {
    RecoveryPointsScannedCount?: number;
    ItemsScannedCount?: number;
    ItemsMatchedCount?: number;
}
export declare const CurrentSearchProgress: S.Schema<CurrentSearchProgress>;
export type EncryptionKeyArn = string;
export type SearchJobState = "RUNNING" | "COMPLETED" | "STOPPING" | "STOPPED" | "FAILED" | (string & {});
export declare const SearchJobState: any;
export type ResourceType = "S3" | "EBS" | (string & {});
export declare const ResourceType: any;
export type ResourceTypeList = ResourceType[];
export declare const ResourceTypeList: any;
export interface BackupCreationTimeFilter {
    CreatedAfter?: Date;
    CreatedBefore?: Date;
}
export declare const BackupCreationTimeFilter: S.Schema<BackupCreationTimeFilter>;
export type ResourceArnList = string[];
export declare const ResourceArnList: any;
export type RecoveryPoint = string;
export type RecoveryPointArnList = string[];
export declare const RecoveryPointArnList: any;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface SearchScope {
    BackupResourceTypes: ResourceType[];
    BackupResourceCreationTime?: BackupCreationTimeFilter;
    SourceResourceArns?: string[];
    BackupResourceArns?: string[];
    BackupResourceTags?: {
        [key: string]: string | undefined;
    };
}
export declare const SearchScope: S.Schema<SearchScope>;
export type StringConditionOperator = "EQUALS_TO" | "NOT_EQUALS_TO" | "CONTAINS" | "DOES_NOT_CONTAIN" | "BEGINS_WITH" | "ENDS_WITH" | "DOES_NOT_BEGIN_WITH" | "DOES_NOT_END_WITH" | (string & {});
export declare const StringConditionOperator: any;
export interface StringCondition {
    Value: string;
    Operator?: StringConditionOperator;
}
export declare const StringCondition: S.Schema<StringCondition>;
export type StringConditionList = StringCondition[];
export declare const StringConditionList: any;
export type LongConditionOperator = "EQUALS_TO" | "NOT_EQUALS_TO" | "LESS_THAN_EQUAL_TO" | "GREATER_THAN_EQUAL_TO" | (string & {});
export declare const LongConditionOperator: any;
export interface LongCondition {
    Value: number;
    Operator?: LongConditionOperator;
}
export declare const LongCondition: S.Schema<LongCondition>;
export type LongConditionList = LongCondition[];
export declare const LongConditionList: any;
export type TimeConditionOperator = "EQUALS_TO" | "NOT_EQUALS_TO" | "LESS_THAN_EQUAL_TO" | "GREATER_THAN_EQUAL_TO" | (string & {});
export declare const TimeConditionOperator: any;
export interface TimeCondition {
    Value: Date;
    Operator?: TimeConditionOperator;
}
export declare const TimeCondition: S.Schema<TimeCondition>;
export type TimeConditionList = TimeCondition[];
export declare const TimeConditionList: any;
export interface S3ItemFilter {
    ObjectKeys?: StringCondition[];
    Sizes?: LongCondition[];
    CreationTimes?: TimeCondition[];
    VersionIds?: StringCondition[];
    ETags?: StringCondition[];
}
export declare const S3ItemFilter: S.Schema<S3ItemFilter>;
export type S3ItemFilters = S3ItemFilter[];
export declare const S3ItemFilters: any;
export interface EBSItemFilter {
    FilePaths?: StringCondition[];
    Sizes?: LongCondition[];
    CreationTimes?: TimeCondition[];
    LastModificationTimes?: TimeCondition[];
}
export declare const EBSItemFilter: S.Schema<EBSItemFilter>;
export type EBSItemFilters = EBSItemFilter[];
export declare const EBSItemFilters: any;
export interface ItemFilters {
    S3ItemFilters?: S3ItemFilter[];
    EBSItemFilters?: EBSItemFilter[];
}
export declare const ItemFilters: S.Schema<ItemFilters>;
export type SearchJobArn = string;
export interface GetSearchJobOutput {
    Name?: string;
    SearchScopeSummary?: SearchScopeSummary;
    CurrentSearchProgress?: CurrentSearchProgress;
    StatusMessage?: string;
    EncryptionKeyArn?: string;
    CompletionTime?: Date;
    Status: SearchJobState;
    SearchScope: SearchScope;
    ItemFilters: ItemFilters;
    CreationTime: Date;
    SearchJobIdentifier: string;
    SearchJobArn: string;
}
export declare const GetSearchJobOutput: S.Schema<GetSearchJobOutput>;
export interface GetSearchResultExportJobInput {
    ExportJobIdentifier: string;
}
export declare const GetSearchResultExportJobInput: S.Schema<GetSearchResultExportJobInput>;
export type ExportJobArn = string;
export type ExportJobStatus = "RUNNING" | "FAILED" | "COMPLETED" | (string & {});
export declare const ExportJobStatus: any;
export interface S3ExportSpecification {
    DestinationBucket: string;
    DestinationPrefix?: string;
}
export declare const S3ExportSpecification: S.Schema<S3ExportSpecification>;
export type ExportSpecification = {
    s3ExportSpecification: S3ExportSpecification;
};
export declare const ExportSpecification: any;
export interface GetSearchResultExportJobOutput {
    ExportJobIdentifier: string;
    ExportJobArn?: string;
    Status?: ExportJobStatus;
    CreationTime?: Date;
    CompletionTime?: Date;
    StatusMessage?: string;
    ExportSpecification?: ExportSpecification;
    SearchJobArn?: string;
}
export declare const GetSearchResultExportJobOutput: S.Schema<GetSearchResultExportJobOutput>;
export interface ListSearchJobBackupsInput {
    SearchJobIdentifier: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListSearchJobBackupsInput: S.Schema<ListSearchJobBackupsInput>;
export interface SearchJobBackupsResult {
    Status?: SearchJobState;
    StatusMessage?: string;
    ResourceType?: ResourceType;
    BackupResourceArn?: string;
    SourceResourceArn?: string;
    IndexCreationTime?: Date;
    BackupCreationTime?: Date;
}
export declare const SearchJobBackupsResult: S.Schema<SearchJobBackupsResult>;
export type SearchJobBackupsResults = SearchJobBackupsResult[];
export declare const SearchJobBackupsResults: any;
export interface ListSearchJobBackupsOutput {
    Results: SearchJobBackupsResult[];
    NextToken?: string;
}
export declare const ListSearchJobBackupsOutput: S.Schema<ListSearchJobBackupsOutput>;
export interface ListSearchJobResultsInput {
    SearchJobIdentifier: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListSearchJobResultsInput: S.Schema<ListSearchJobResultsInput>;
export type ObjectKey = string | redacted.Redacted<string>;
export interface S3ResultItem {
    BackupResourceArn?: string;
    SourceResourceArn?: string;
    BackupVaultName?: string;
    ObjectKey?: string | redacted.Redacted<string>;
    ObjectSize?: number;
    CreationTime?: Date;
    ETag?: string;
    VersionId?: string;
}
export declare const S3ResultItem: S.Schema<S3ResultItem>;
export type FilePath = string | redacted.Redacted<string>;
export interface EBSResultItem {
    BackupResourceArn?: string;
    SourceResourceArn?: string;
    BackupVaultName?: string;
    FileSystemIdentifier?: string;
    FilePath?: string | redacted.Redacted<string>;
    FileSize?: number;
    CreationTime?: Date;
    LastModifiedTime?: Date;
}
export declare const EBSResultItem: S.Schema<EBSResultItem>;
export type ResultItem = {
    S3ResultItem: S3ResultItem;
    EBSResultItem?: never;
} | {
    S3ResultItem?: never;
    EBSResultItem: EBSResultItem;
};
export declare const ResultItem: any;
export type Results = ResultItem[];
export declare const Results: any;
export interface ListSearchJobResultsOutput {
    Results: ResultItem[];
    NextToken?: string;
}
export declare const ListSearchJobResultsOutput: S.Schema<ListSearchJobResultsOutput>;
export interface ListSearchJobsInput {
    ByStatus?: SearchJobState;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListSearchJobsInput: S.Schema<ListSearchJobsInput>;
export interface SearchJobSummary {
    SearchJobIdentifier?: string;
    SearchJobArn?: string;
    Name?: string;
    Status?: SearchJobState;
    CreationTime?: Date;
    CompletionTime?: Date;
    SearchScopeSummary?: SearchScopeSummary;
    StatusMessage?: string;
}
export declare const SearchJobSummary: S.Schema<SearchJobSummary>;
export type SearchJobs = SearchJobSummary[];
export declare const SearchJobs: any;
export interface ListSearchJobsOutput {
    SearchJobs: SearchJobSummary[];
    NextToken?: string;
}
export declare const ListSearchJobsOutput: S.Schema<ListSearchJobsOutput>;
export interface ListSearchResultExportJobsInput {
    Status?: ExportJobStatus;
    SearchJobIdentifier?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListSearchResultExportJobsInput: S.Schema<ListSearchResultExportJobsInput>;
export interface ExportJobSummary {
    ExportJobIdentifier: string;
    ExportJobArn?: string;
    Status?: ExportJobStatus;
    CreationTime?: Date;
    CompletionTime?: Date;
    StatusMessage?: string;
    SearchJobArn?: string;
}
export declare const ExportJobSummary: S.Schema<ExportJobSummary>;
export type ExportJobSummaries = ExportJobSummary[];
export declare const ExportJobSummaries: any;
export interface ListSearchResultExportJobsOutput {
    ExportJobs: ExportJobSummary[];
    NextToken?: string;
}
export declare const ListSearchResultExportJobsOutput: S.Schema<ListSearchResultExportJobsOutput>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface StartSearchJobInput {
    Tags?: {
        [key: string]: string | undefined;
    };
    Name?: string;
    EncryptionKeyArn?: string;
    ClientToken?: string;
    SearchScope: SearchScope;
    ItemFilters?: ItemFilters;
}
export declare const StartSearchJobInput: S.Schema<StartSearchJobInput>;
export interface StartSearchJobOutput {
    SearchJobArn?: string;
    CreationTime?: Date;
    SearchJobIdentifier?: string;
}
export declare const StartSearchJobOutput: S.Schema<StartSearchJobOutput>;
export type IamRoleArn = string;
export interface StartSearchResultExportJobInput {
    SearchJobIdentifier: string;
    ExportSpecification: ExportSpecification;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    RoleArn?: string;
}
export declare const StartSearchResultExportJobInput: S.Schema<StartSearchResultExportJobInput>;
export interface StartSearchResultExportJobOutput {
    ExportJobArn?: string;
    ExportJobIdentifier: string;
}
export declare const StartSearchResultExportJobOutput: S.Schema<StartSearchResultExportJobOutput>;
export interface StopSearchJobInput {
    SearchJobIdentifier: string;
}
export declare const StopSearchJobInput: S.Schema<StopSearchJobInput>;
export interface StopSearchJobOutput {
}
export declare const StopSearchJobOutput: S.Schema<StopSearchJobOutput>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type GetSearchJobError = ResourceNotFoundException | CommonErrors;
/**
 * This operation retrieves metadata of a search job, including its progress.
 */
export declare const getSearchJob: API.OperationMethod<GetSearchJobInput, GetSearchJobOutput, GetSearchJobError, Credentials | HttpClient.HttpClient>;
export type GetSearchResultExportJobError = ResourceNotFoundException | CommonErrors;
/**
 * This operation retrieves the metadata of an export job.
 *
 * An export job is an operation that transmits the results of a search job to a specified S3 bucket in a .csv file.
 *
 * An export job allows you to retain results of a search beyond the search job's scheduled retention of 7 days.
 */
export declare const getSearchResultExportJob: API.OperationMethod<GetSearchResultExportJobInput, GetSearchResultExportJobOutput, GetSearchResultExportJobError, Credentials | HttpClient.HttpClient>;
export type ListSearchJobBackupsError = ResourceNotFoundException | CommonErrors;
/**
 * This operation returns a list of all backups (recovery points) in a paginated format that were included in the search job.
 *
 * If a search does not display an expected backup in the results, you can call this operation to display each backup included in the search. Any backups that were not included because they have a `FAILED` status from a permissions issue will be displayed, along with a status message.
 *
 * Only recovery points with a backup index that has a status of `ACTIVE` will be included in search results. If the index has any other status, its status will be displayed along with a status message.
 */
export declare const listSearchJobBackups: API.PaginatedOperationMethod<ListSearchJobBackupsInput, ListSearchJobBackupsOutput, ListSearchJobBackupsError, Credentials | HttpClient.HttpClient, SearchJobBackupsResult>;
export type ListSearchJobResultsError = ResourceNotFoundException | CommonErrors;
/**
 * This operation returns a list of a specified search job.
 */
export declare const listSearchJobResults: API.PaginatedOperationMethod<ListSearchJobResultsInput, ListSearchJobResultsOutput, ListSearchJobResultsError, Credentials | HttpClient.HttpClient, ResultItem>;
export type ListSearchJobsError = CommonErrors;
/**
 * This operation returns a list of search jobs belonging to an account.
 */
export declare const listSearchJobs: API.PaginatedOperationMethod<ListSearchJobsInput, ListSearchJobsOutput, ListSearchJobsError, Credentials | HttpClient.HttpClient, SearchJobSummary>;
export type ListSearchResultExportJobsError = ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * This operation exports search results of a search job to a specified destination S3 bucket.
 */
export declare const listSearchResultExportJobs: API.PaginatedOperationMethod<ListSearchResultExportJobsInput, ListSearchResultExportJobsOutput, ListSearchResultExportJobsError, Credentials | HttpClient.HttpClient, ExportJobSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * This operation returns the tags for a resource type.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartSearchJobError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * This operation creates a search job which returns recovery points filtered by SearchScope and items filtered by ItemFilters.
 *
 * You can optionally include ClientToken, EncryptionKeyArn, Name, and/or Tags.
 */
export declare const startSearchJob: API.OperationMethod<StartSearchJobInput, StartSearchJobOutput, StartSearchJobError, Credentials | HttpClient.HttpClient>;
export type StartSearchResultExportJobError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * This operations starts a job to export the results of search job to a designated S3 bucket.
 */
export declare const startSearchResultExportJob: API.OperationMethod<StartSearchResultExportJobInput, StartSearchResultExportJobOutput, StartSearchResultExportJobError, Credentials | HttpClient.HttpClient>;
export type StopSearchJobError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * This operations ends a search job.
 *
 * Only a search job with a status of `RUNNING` can be stopped.
 */
export declare const stopSearchJob: API.OperationMethod<StopSearchJobInput, StopSearchJobOutput, StopSearchJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * This operation puts tags on the resource you indicate.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * This operation removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=backupsearch.d.ts.map