import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedFault_base: S.Class<AccessDeniedFault, S.TaggedStruct<"AccessDeniedFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedFault extends /*@__PURE__*/ AccessDeniedFault_base {
}
declare const CollectorNotFoundFault_base: S.Class<CollectorNotFoundFault, S.TaggedStruct<"CollectorNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CollectorNotFoundFault extends /*@__PURE__*/ CollectorNotFoundFault_base {
}
declare const FailedDependencyFault_base: S.Class<FailedDependencyFault, S.TaggedStruct<"FailedDependencyFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FailedDependencyFault extends /*@__PURE__*/ FailedDependencyFault_base {
}
declare const InsufficientResourceCapacityFault_base: S.Class<InsufficientResourceCapacityFault, S.TaggedStruct<"InsufficientResourceCapacityFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InsufficientResourceCapacityFault extends /*@__PURE__*/ InsufficientResourceCapacityFault_base {
}
declare const InvalidCertificateFault_base: S.Class<InvalidCertificateFault, S.TaggedStruct<"InvalidCertificateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidCertificateFault extends /*@__PURE__*/ InvalidCertificateFault_base {
}
declare const InvalidOperationFault_base: S.Class<InvalidOperationFault, S.TaggedStruct<"InvalidOperationFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidOperationFault extends /*@__PURE__*/ InvalidOperationFault_base {
}
declare const InvalidResourceStateFault_base: S.Class<InvalidResourceStateFault, S.TaggedStruct<"InvalidResourceStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidResourceStateFault extends /*@__PURE__*/ InvalidResourceStateFault_base {
}
declare const InvalidSubnet_base: S.Class<InvalidSubnet, S.TaggedStruct<"InvalidSubnet", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSubnet extends /*@__PURE__*/ InvalidSubnet_base {
}
declare const KMSAccessDeniedFault_base: S.Class<KMSAccessDeniedFault, S.TaggedStruct<"KMSAccessDeniedFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class KMSAccessDeniedFault extends /*@__PURE__*/ KMSAccessDeniedFault_base {
}
declare const KMSDisabledFault_base: S.Class<KMSDisabledFault, S.TaggedStruct<"KMSDisabledFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class KMSDisabledFault extends /*@__PURE__*/ KMSDisabledFault_base {
}
declare const KMSFault_base: S.Class<KMSFault, S.TaggedStruct<"KMSFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class KMSFault extends /*@__PURE__*/ KMSFault_base {
}
declare const KMSInvalidStateFault_base: S.Class<KMSInvalidStateFault, S.TaggedStruct<"KMSInvalidStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class KMSInvalidStateFault extends /*@__PURE__*/ KMSInvalidStateFault_base {
}
declare const KMSKeyNotAccessibleFault_base: S.Class<KMSKeyNotAccessibleFault, S.TaggedStruct<"KMSKeyNotAccessibleFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class KMSKeyNotAccessibleFault extends /*@__PURE__*/ KMSKeyNotAccessibleFault_base {
}
declare const KMSNotFoundFault_base: S.Class<KMSNotFoundFault, S.TaggedStruct<"KMSNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class KMSNotFoundFault extends /*@__PURE__*/ KMSNotFoundFault_base {
}
declare const KMSThrottlingFault_base: S.Class<KMSThrottlingFault, S.TaggedStruct<"KMSThrottlingFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class KMSThrottlingFault extends /*@__PURE__*/ KMSThrottlingFault_base {
}
declare const ReplicationSubnetGroupDoesNotCoverEnoughAZs_base: S.Class<ReplicationSubnetGroupDoesNotCoverEnoughAZs, S.TaggedStruct<"ReplicationSubnetGroupDoesNotCoverEnoughAZs", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ReplicationSubnetGroupDoesNotCoverEnoughAZs extends /*@__PURE__*/ ReplicationSubnetGroupDoesNotCoverEnoughAZs_base {
}
declare const ResourceAlreadyExistsFault_base: S.Class<ResourceAlreadyExistsFault, S.TaggedStruct<"ResourceAlreadyExistsFault", {
    readonly message: any;
    readonly resourceArn: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsFault extends /*@__PURE__*/ ResourceAlreadyExistsFault_base {
}
declare const ResourceNotFoundFault_base: S.Class<ResourceNotFoundFault, S.TaggedStruct<"ResourceNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotFoundFault extends /*@__PURE__*/ ResourceNotFoundFault_base {
}
declare const ResourceQuotaExceededFault_base: S.Class<ResourceQuotaExceededFault, S.TaggedStruct<"ResourceQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceQuotaExceededFault extends /*@__PURE__*/ ResourceQuotaExceededFault_base {
}
declare const S3AccessDeniedFault_base: S.Class<S3AccessDeniedFault, S.TaggedStruct<"S3AccessDeniedFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class S3AccessDeniedFault extends /*@__PURE__*/ S3AccessDeniedFault_base {
}
declare const S3ResourceNotFoundFault_base: S.Class<S3ResourceNotFoundFault, S.TaggedStruct<"S3ResourceNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class S3ResourceNotFoundFault extends /*@__PURE__*/ S3ResourceNotFoundFault_base {
}
declare const SNSInvalidTopicFault_base: S.Class<SNSInvalidTopicFault, S.TaggedStruct<"SNSInvalidTopicFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SNSInvalidTopicFault extends /*@__PURE__*/ SNSInvalidTopicFault_base {
}
declare const SNSNoAuthorizationFault_base: S.Class<SNSNoAuthorizationFault, S.TaggedStruct<"SNSNoAuthorizationFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SNSNoAuthorizationFault extends /*@__PURE__*/ SNSNoAuthorizationFault_base {
}
declare const StorageQuotaExceededFault_base: S.Class<StorageQuotaExceededFault, S.TaggedStruct<"StorageQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class StorageQuotaExceededFault extends /*@__PURE__*/ StorageQuotaExceededFault_base {
}
declare const SubnetAlreadyInUse_base: S.Class<SubnetAlreadyInUse, S.TaggedStruct<"SubnetAlreadyInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class SubnetAlreadyInUse extends /*@__PURE__*/ SubnetAlreadyInUse_base {
}
declare const UpgradeDependencyFailureFault_base: S.Class<UpgradeDependencyFailureFault, S.TaggedStruct<"UpgradeDependencyFailureFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UpgradeDependencyFailureFault extends /*@__PURE__*/ UpgradeDependencyFailureFault_base {
}
export interface Tag {
    Key?: string;
    Value?: string;
    ResourceArn?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface AddTagsToResourceMessage {
    ResourceArn: string;
    Tags: Tag[];
}
export declare const AddTagsToResourceMessage: S.Schema<AddTagsToResourceMessage>;
export interface AddTagsToResourceResponse {
}
export declare const AddTagsToResourceResponse: S.Schema<AddTagsToResourceResponse>;
export interface ApplyPendingMaintenanceActionMessage {
    ReplicationInstanceArn: string;
    ApplyAction: string;
    OptInType: string;
}
export declare const ApplyPendingMaintenanceActionMessage: S.Schema<ApplyPendingMaintenanceActionMessage>;
export interface PendingMaintenanceAction {
    Action?: string;
    AutoAppliedAfterDate?: Date;
    ForcedApplyDate?: Date;
    OptInStatus?: string;
    CurrentApplyDate?: Date;
    Description?: string;
}
export declare const PendingMaintenanceAction: S.Schema<PendingMaintenanceAction>;
export type PendingMaintenanceActionDetails = PendingMaintenanceAction[];
export declare const PendingMaintenanceActionDetails: any;
export interface ResourcePendingMaintenanceActions {
    ResourceIdentifier?: string;
    PendingMaintenanceActionDetails?: PendingMaintenanceAction[];
}
export declare const ResourcePendingMaintenanceActions: S.Schema<ResourcePendingMaintenanceActions>;
export interface ApplyPendingMaintenanceActionResponse {
    ResourcePendingMaintenanceActions?: ResourcePendingMaintenanceActions;
}
export declare const ApplyPendingMaintenanceActionResponse: S.Schema<ApplyPendingMaintenanceActionResponse>;
export interface RecommendationSettings {
    InstanceSizingType: string;
    WorkloadType: string;
}
export declare const RecommendationSettings: S.Schema<RecommendationSettings>;
export interface StartRecommendationsRequestEntry {
    DatabaseId: string;
    Settings: RecommendationSettings;
}
export declare const StartRecommendationsRequestEntry: S.Schema<StartRecommendationsRequestEntry>;
export type StartRecommendationsRequestEntryList = StartRecommendationsRequestEntry[];
export declare const StartRecommendationsRequestEntryList: any;
export interface BatchStartRecommendationsRequest {
    Data?: StartRecommendationsRequestEntry[];
}
export declare const BatchStartRecommendationsRequest: S.Schema<BatchStartRecommendationsRequest>;
export interface BatchStartRecommendationsErrorEntry {
    DatabaseId?: string;
    Message?: string;
    Code?: string;
}
export declare const BatchStartRecommendationsErrorEntry: S.Schema<BatchStartRecommendationsErrorEntry>;
export type BatchStartRecommendationsErrorEntryList = BatchStartRecommendationsErrorEntry[];
export declare const BatchStartRecommendationsErrorEntryList: any;
export interface BatchStartRecommendationsResponse {
    ErrorEntries?: BatchStartRecommendationsErrorEntry[];
}
export declare const BatchStartRecommendationsResponse: S.Schema<BatchStartRecommendationsResponse>;
export type MigrationProjectIdentifier = string;
export interface CancelMetadataModelConversionMessage {
    MigrationProjectIdentifier: string;
    RequestIdentifier: string;
}
export declare const CancelMetadataModelConversionMessage: S.Schema<CancelMetadataModelConversionMessage>;
export interface DefaultErrorDetails {
    Message?: string;
}
export declare const DefaultErrorDetails: S.Schema<DefaultErrorDetails>;
export type ErrorDetails = {
    defaultErrorDetails: DefaultErrorDetails;
};
export declare const ErrorDetails: any;
export interface ExportSqlDetails {
    S3ObjectKey?: string;
    ObjectURL?: string;
}
export declare const ExportSqlDetails: S.Schema<ExportSqlDetails>;
export interface ProcessedObject {
    Name?: string;
    Type?: string;
    EndpointType?: string;
}
export declare const ProcessedObject: S.Schema<ProcessedObject>;
export interface Progress {
    ProgressPercent?: number;
    TotalObjects?: number;
    ProgressStep?: string;
    ProcessedObject?: ProcessedObject;
}
export declare const Progress: S.Schema<Progress>;
export interface SchemaConversionRequest {
    Status?: string;
    RequestIdentifier?: string;
    MigrationProjectArn?: string;
    Error?: ErrorDetails;
    ExportSqlDetails?: ExportSqlDetails;
    Progress?: Progress;
}
export declare const SchemaConversionRequest: S.Schema<SchemaConversionRequest>;
export interface CancelMetadataModelConversionResponse {
    Request?: SchemaConversionRequest;
}
export declare const CancelMetadataModelConversionResponse: S.Schema<CancelMetadataModelConversionResponse>;
export interface CancelMetadataModelCreationMessage {
    MigrationProjectIdentifier: string;
    RequestIdentifier: string;
}
export declare const CancelMetadataModelCreationMessage: S.Schema<CancelMetadataModelCreationMessage>;
export interface CancelMetadataModelCreationResponse {
    Request?: SchemaConversionRequest;
}
export declare const CancelMetadataModelCreationResponse: S.Schema<CancelMetadataModelCreationResponse>;
export interface CancelReplicationTaskAssessmentRunMessage {
    ReplicationTaskAssessmentRunArn: string;
}
export declare const CancelReplicationTaskAssessmentRunMessage: S.Schema<CancelReplicationTaskAssessmentRunMessage>;
export interface ReplicationTaskAssessmentRunProgress {
    IndividualAssessmentCount?: number;
    IndividualAssessmentCompletedCount?: number;
}
export declare const ReplicationTaskAssessmentRunProgress: S.Schema<ReplicationTaskAssessmentRunProgress>;
export interface ReplicationTaskAssessmentRunResultStatistic {
    Passed?: number;
    Failed?: number;
    Error?: number;
    Warning?: number;
    Cancelled?: number;
    Skipped?: number;
}
export declare const ReplicationTaskAssessmentRunResultStatistic: S.Schema<ReplicationTaskAssessmentRunResultStatistic>;
export interface ReplicationTaskAssessmentRun {
    ReplicationTaskAssessmentRunArn?: string;
    ReplicationTaskArn?: string;
    Status?: string;
    ReplicationTaskAssessmentRunCreationDate?: Date;
    AssessmentProgress?: ReplicationTaskAssessmentRunProgress;
    LastFailureMessage?: string;
    ServiceAccessRoleArn?: string;
    ResultLocationBucket?: string;
    ResultLocationFolder?: string;
    ResultEncryptionMode?: string;
    ResultKmsKeyArn?: string;
    AssessmentRunName?: string;
    IsLatestTaskAssessmentRun?: boolean;
    ResultStatistic?: ReplicationTaskAssessmentRunResultStatistic;
}
export declare const ReplicationTaskAssessmentRun: S.Schema<ReplicationTaskAssessmentRun>;
export interface CancelReplicationTaskAssessmentRunResponse {
    ReplicationTaskAssessmentRun?: ReplicationTaskAssessmentRun;
}
export declare const CancelReplicationTaskAssessmentRunResponse: S.Schema<CancelReplicationTaskAssessmentRunResponse>;
export type MigrationTypeValue = "full-load" | "cdc" | "full-load-and-cdc" | (string & {});
export declare const MigrationTypeValue: any;
export type Iso8601DateTime = Date;
export interface SourceDataSetting {
    CDCStartPosition?: string;
    CDCStartTime?: Date;
    CDCStopTime?: Date;
    SlotName?: string;
}
export declare const SourceDataSetting: S.Schema<SourceDataSetting>;
export type SourceDataSettings = SourceDataSetting[];
export declare const SourceDataSettings: any;
export type TablePreparationMode = "do-nothing" | "truncate" | "drop-tables-on-target" | (string & {});
export declare const TablePreparationMode: any;
export interface TargetDataSetting {
    TablePreparationMode?: TablePreparationMode;
}
export declare const TargetDataSetting: S.Schema<TargetDataSetting>;
export type TargetDataSettings = TargetDataSetting[];
export declare const TargetDataSettings: any;
export type SecretString = string | redacted.Redacted<string>;
export interface CreateDataMigrationMessage {
    DataMigrationName?: string;
    MigrationProjectIdentifier: string;
    DataMigrationType: MigrationTypeValue;
    ServiceAccessRoleArn: string;
    EnableCloudwatchLogs?: boolean;
    SourceDataSettings?: SourceDataSetting[];
    TargetDataSettings?: TargetDataSetting[];
    NumberOfJobs?: number;
    Tags?: Tag[];
    SelectionRules?: string | redacted.Redacted<string>;
}
export declare const CreateDataMigrationMessage: S.Schema<CreateDataMigrationMessage>;
export interface DataMigrationSettings {
    NumberOfJobs?: number;
    CloudwatchLogsEnabled?: boolean;
    SelectionRules?: string | redacted.Redacted<string>;
}
export declare const DataMigrationSettings: S.Schema<DataMigrationSettings>;
export interface DataMigrationStatistics {
    TablesLoaded?: number;
    ElapsedTimeMillis?: number;
    TablesLoading?: number;
    FullLoadPercentage?: number;
    CDCLatency?: number;
    TablesQueued?: number;
    TablesErrored?: number;
    StartTime?: Date;
    StopTime?: Date;
}
export declare const DataMigrationStatistics: S.Schema<DataMigrationStatistics>;
export type PublicIpAddressList = string[];
export declare const PublicIpAddressList: any;
export type DataMigrationCidrBlock = string[];
export declare const DataMigrationCidrBlock: any;
export interface DataMigration {
    DataMigrationName?: string;
    DataMigrationArn?: string;
    DataMigrationCreateTime?: Date;
    DataMigrationStartTime?: Date;
    DataMigrationEndTime?: Date;
    ServiceAccessRoleArn?: string;
    MigrationProjectArn?: string;
    DataMigrationType?: MigrationTypeValue;
    DataMigrationSettings?: DataMigrationSettings;
    SourceDataSettings?: SourceDataSetting[];
    TargetDataSettings?: TargetDataSetting[];
    DataMigrationStatistics?: DataMigrationStatistics;
    DataMigrationStatus?: string;
    PublicIpAddresses?: string[];
    DataMigrationCidrBlocks?: string[];
    LastFailureMessage?: string;
    StopReason?: string;
}
export declare const DataMigration: S.Schema<DataMigration>;
export interface CreateDataMigrationResponse {
    DataMigration?: DataMigration;
}
export declare const CreateDataMigrationResponse: S.Schema<CreateDataMigrationResponse>;
export interface RedshiftDataProviderSettings {
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    S3Path?: string;
    S3AccessRoleArn?: string;
}
export declare const RedshiftDataProviderSettings: S.Schema<RedshiftDataProviderSettings>;
export type DmsSslModeValue = "none" | "require" | "verify-ca" | "verify-full" | (string & {});
export declare const DmsSslModeValue: any;
export interface PostgreSqlDataProviderSettings {
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    SslMode?: DmsSslModeValue;
    CertificateArn?: string;
    S3Path?: string;
    S3AccessRoleArn?: string;
}
export declare const PostgreSqlDataProviderSettings: S.Schema<PostgreSqlDataProviderSettings>;
export interface MySqlDataProviderSettings {
    ServerName?: string;
    Port?: number;
    SslMode?: DmsSslModeValue;
    CertificateArn?: string;
    S3Path?: string;
    S3AccessRoleArn?: string;
}
export declare const MySqlDataProviderSettings: S.Schema<MySqlDataProviderSettings>;
export interface OracleDataProviderSettings {
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    SslMode?: DmsSslModeValue;
    CertificateArn?: string;
    AsmServer?: string;
    SecretsManagerOracleAsmSecretId?: string;
    SecretsManagerOracleAsmAccessRoleArn?: string;
    SecretsManagerSecurityDbEncryptionSecretId?: string;
    SecretsManagerSecurityDbEncryptionAccessRoleArn?: string;
    S3Path?: string;
    S3AccessRoleArn?: string;
}
export declare const OracleDataProviderSettings: S.Schema<OracleDataProviderSettings>;
export interface SybaseAseDataProviderSettings {
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    SslMode?: DmsSslModeValue;
    EncryptPassword?: boolean;
    CertificateArn?: string;
}
export declare const SybaseAseDataProviderSettings: S.Schema<SybaseAseDataProviderSettings>;
export interface MicrosoftSqlServerDataProviderSettings {
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    SslMode?: DmsSslModeValue;
    CertificateArn?: string;
    S3Path?: string;
    S3AccessRoleArn?: string;
}
export declare const MicrosoftSqlServerDataProviderSettings: S.Schema<MicrosoftSqlServerDataProviderSettings>;
export interface DocDbDataProviderSettings {
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    SslMode?: DmsSslModeValue;
    CertificateArn?: string;
}
export declare const DocDbDataProviderSettings: S.Schema<DocDbDataProviderSettings>;
export interface MariaDbDataProviderSettings {
    ServerName?: string;
    Port?: number;
    SslMode?: DmsSslModeValue;
    CertificateArn?: string;
    S3Path?: string;
    S3AccessRoleArn?: string;
}
export declare const MariaDbDataProviderSettings: S.Schema<MariaDbDataProviderSettings>;
export interface IbmDb2LuwDataProviderSettings {
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    SslMode?: DmsSslModeValue;
    CertificateArn?: string;
    EncryptionAlgorithm?: number;
    SecurityMechanism?: number;
    S3Path?: string;
    S3AccessRoleArn?: string;
}
export declare const IbmDb2LuwDataProviderSettings: S.Schema<IbmDb2LuwDataProviderSettings>;
export interface IbmDb2zOsDataProviderSettings {
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    SslMode?: DmsSslModeValue;
    CertificateArn?: string;
    S3Path?: string;
    S3AccessRoleArn?: string;
}
export declare const IbmDb2zOsDataProviderSettings: S.Schema<IbmDb2zOsDataProviderSettings>;
export type AuthTypeValue = "no" | "password" | (string & {});
export declare const AuthTypeValue: any;
export type AuthMechanismValue = "default" | "mongodb_cr" | "scram_sha_1" | (string & {});
export declare const AuthMechanismValue: any;
export interface MongoDbDataProviderSettings {
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    SslMode?: DmsSslModeValue;
    CertificateArn?: string;
    AuthType?: AuthTypeValue;
    AuthSource?: string;
    AuthMechanism?: AuthMechanismValue;
}
export declare const MongoDbDataProviderSettings: S.Schema<MongoDbDataProviderSettings>;
export type DataProviderSettings = {
    RedshiftSettings: RedshiftDataProviderSettings;
    PostgreSqlSettings?: never;
    MySqlSettings?: never;
    OracleSettings?: never;
    SybaseAseSettings?: never;
    MicrosoftSqlServerSettings?: never;
    DocDbSettings?: never;
    MariaDbSettings?: never;
    IbmDb2LuwSettings?: never;
    IbmDb2zOsSettings?: never;
    MongoDbSettings?: never;
} | {
    RedshiftSettings?: never;
    PostgreSqlSettings: PostgreSqlDataProviderSettings;
    MySqlSettings?: never;
    OracleSettings?: never;
    SybaseAseSettings?: never;
    MicrosoftSqlServerSettings?: never;
    DocDbSettings?: never;
    MariaDbSettings?: never;
    IbmDb2LuwSettings?: never;
    IbmDb2zOsSettings?: never;
    MongoDbSettings?: never;
} | {
    RedshiftSettings?: never;
    PostgreSqlSettings?: never;
    MySqlSettings: MySqlDataProviderSettings;
    OracleSettings?: never;
    SybaseAseSettings?: never;
    MicrosoftSqlServerSettings?: never;
    DocDbSettings?: never;
    MariaDbSettings?: never;
    IbmDb2LuwSettings?: never;
    IbmDb2zOsSettings?: never;
    MongoDbSettings?: never;
} | {
    RedshiftSettings?: never;
    PostgreSqlSettings?: never;
    MySqlSettings?: never;
    OracleSettings: OracleDataProviderSettings;
    SybaseAseSettings?: never;
    MicrosoftSqlServerSettings?: never;
    DocDbSettings?: never;
    MariaDbSettings?: never;
    IbmDb2LuwSettings?: never;
    IbmDb2zOsSettings?: never;
    MongoDbSettings?: never;
} | {
    RedshiftSettings?: never;
    PostgreSqlSettings?: never;
    MySqlSettings?: never;
    OracleSettings?: never;
    SybaseAseSettings: SybaseAseDataProviderSettings;
    MicrosoftSqlServerSettings?: never;
    DocDbSettings?: never;
    MariaDbSettings?: never;
    IbmDb2LuwSettings?: never;
    IbmDb2zOsSettings?: never;
    MongoDbSettings?: never;
} | {
    RedshiftSettings?: never;
    PostgreSqlSettings?: never;
    MySqlSettings?: never;
    OracleSettings?: never;
    SybaseAseSettings?: never;
    MicrosoftSqlServerSettings: MicrosoftSqlServerDataProviderSettings;
    DocDbSettings?: never;
    MariaDbSettings?: never;
    IbmDb2LuwSettings?: never;
    IbmDb2zOsSettings?: never;
    MongoDbSettings?: never;
} | {
    RedshiftSettings?: never;
    PostgreSqlSettings?: never;
    MySqlSettings?: never;
    OracleSettings?: never;
    SybaseAseSettings?: never;
    MicrosoftSqlServerSettings?: never;
    DocDbSettings: DocDbDataProviderSettings;
    MariaDbSettings?: never;
    IbmDb2LuwSettings?: never;
    IbmDb2zOsSettings?: never;
    MongoDbSettings?: never;
} | {
    RedshiftSettings?: never;
    PostgreSqlSettings?: never;
    MySqlSettings?: never;
    OracleSettings?: never;
    SybaseAseSettings?: never;
    MicrosoftSqlServerSettings?: never;
    DocDbSettings?: never;
    MariaDbSettings: MariaDbDataProviderSettings;
    IbmDb2LuwSettings?: never;
    IbmDb2zOsSettings?: never;
    MongoDbSettings?: never;
} | {
    RedshiftSettings?: never;
    PostgreSqlSettings?: never;
    MySqlSettings?: never;
    OracleSettings?: never;
    SybaseAseSettings?: never;
    MicrosoftSqlServerSettings?: never;
    DocDbSettings?: never;
    MariaDbSettings?: never;
    IbmDb2LuwSettings: IbmDb2LuwDataProviderSettings;
    IbmDb2zOsSettings?: never;
    MongoDbSettings?: never;
} | {
    RedshiftSettings?: never;
    PostgreSqlSettings?: never;
    MySqlSettings?: never;
    OracleSettings?: never;
    SybaseAseSettings?: never;
    MicrosoftSqlServerSettings?: never;
    DocDbSettings?: never;
    MariaDbSettings?: never;
    IbmDb2LuwSettings?: never;
    IbmDb2zOsSettings: IbmDb2zOsDataProviderSettings;
    MongoDbSettings?: never;
} | {
    RedshiftSettings?: never;
    PostgreSqlSettings?: never;
    MySqlSettings?: never;
    OracleSettings?: never;
    SybaseAseSettings?: never;
    MicrosoftSqlServerSettings?: never;
    DocDbSettings?: never;
    MariaDbSettings?: never;
    IbmDb2LuwSettings?: never;
    IbmDb2zOsSettings?: never;
    MongoDbSettings: MongoDbDataProviderSettings;
};
export declare const DataProviderSettings: any;
export interface CreateDataProviderMessage {
    DataProviderName?: string;
    Description?: string;
    Engine: string;
    Virtual?: boolean;
    Settings: DataProviderSettings;
    Tags?: Tag[];
}
export declare const CreateDataProviderMessage: S.Schema<CreateDataProviderMessage>;
export interface DataProvider {
    DataProviderName?: string;
    DataProviderArn?: string;
    DataProviderCreationTime?: Date;
    Description?: string;
    Engine?: string;
    Virtual?: boolean;
    Settings?: DataProviderSettings;
}
export declare const DataProvider: S.Schema<DataProvider>;
export interface CreateDataProviderResponse {
    DataProvider?: DataProvider;
}
export declare const CreateDataProviderResponse: S.Schema<CreateDataProviderResponse>;
export type ReplicationEndpointTypeValue = "source" | "target" | (string & {});
export declare const ReplicationEndpointTypeValue: any;
export interface DynamoDbSettings {
    ServiceAccessRoleArn: string;
}
export declare const DynamoDbSettings: S.Schema<DynamoDbSettings>;
export type CompressionTypeValue = "none" | "gzip" | (string & {});
export declare const CompressionTypeValue: any;
export type EncryptionModeValue = "sse-s3" | "sse-kms" | (string & {});
export declare const EncryptionModeValue: any;
export type DataFormatValue = "csv" | "parquet" | (string & {});
export declare const DataFormatValue: any;
export type EncodingTypeValue = "plain" | "plain-dictionary" | "rle-dictionary" | (string & {});
export declare const EncodingTypeValue: any;
export type ParquetVersionValue = "parquet-1-0" | "parquet-2-0" | (string & {});
export declare const ParquetVersionValue: any;
export type DatePartitionSequenceValue = "YYYYMMDD" | "YYYYMMDDHH" | "YYYYMM" | "MMYYYYDD" | "DDMMYYYY" | (string & {});
export declare const DatePartitionSequenceValue: any;
export type DatePartitionDelimiterValue = "SLASH" | "UNDERSCORE" | "DASH" | "NONE" | (string & {});
export declare const DatePartitionDelimiterValue: any;
export type CannedAclForObjectsValue = "none" | "private" | "public-read" | "public-read-write" | "authenticated-read" | "aws-exec-read" | "bucket-owner-read" | "bucket-owner-full-control" | (string & {});
export declare const CannedAclForObjectsValue: any;
export interface S3Settings {
    ServiceAccessRoleArn?: string;
    ExternalTableDefinition?: string;
    CsvRowDelimiter?: string;
    CsvDelimiter?: string;
    BucketFolder?: string;
    BucketName?: string;
    CompressionType?: CompressionTypeValue;
    EncryptionMode?: EncryptionModeValue;
    ServerSideEncryptionKmsKeyId?: string;
    DataFormat?: DataFormatValue;
    EncodingType?: EncodingTypeValue;
    DictPageSizeLimit?: number;
    RowGroupLength?: number;
    DataPageSize?: number;
    ParquetVersion?: ParquetVersionValue;
    EnableStatistics?: boolean;
    IncludeOpForFullLoad?: boolean;
    CdcInsertsOnly?: boolean;
    TimestampColumnName?: string;
    ParquetTimestampInMillisecond?: boolean;
    CdcInsertsAndUpdates?: boolean;
    DatePartitionEnabled?: boolean;
    DatePartitionSequence?: DatePartitionSequenceValue;
    DatePartitionDelimiter?: DatePartitionDelimiterValue;
    UseCsvNoSupValue?: boolean;
    CsvNoSupValue?: string;
    PreserveTransactions?: boolean;
    CdcPath?: string;
    UseTaskStartTimeForFullLoadTimestamp?: boolean;
    CannedAclForObjects?: CannedAclForObjectsValue;
    AddColumnName?: boolean;
    CdcMaxBatchInterval?: number;
    CdcMinFileSize?: number;
    CsvNullValue?: string;
    IgnoreHeaderRows?: number;
    MaxFileSize?: number;
    Rfc4180?: boolean;
    DatePartitionTimezone?: string;
    AddTrailingPaddingCharacter?: boolean;
    ExpectedBucketOwner?: string;
    GlueCatalogGeneration?: boolean;
}
export declare const S3Settings: S.Schema<S3Settings>;
export interface DmsTransferSettings {
    ServiceAccessRoleArn?: string;
    BucketName?: string;
}
export declare const DmsTransferSettings: S.Schema<DmsTransferSettings>;
export type NestingLevelValue = "none" | "one" | (string & {});
export declare const NestingLevelValue: any;
export interface MongoDbSettings {
    Username?: string;
    Password?: string | redacted.Redacted<string>;
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    AuthType?: AuthTypeValue;
    AuthMechanism?: AuthMechanismValue;
    NestingLevel?: NestingLevelValue;
    ExtractDocId?: string;
    DocsToInvestigate?: string;
    AuthSource?: string;
    KmsKeyId?: string;
    SecretsManagerAccessRoleArn?: string;
    SecretsManagerSecretId?: string;
    UseUpdateLookUp?: boolean;
    ReplicateShardCollections?: boolean;
}
export declare const MongoDbSettings: S.Schema<MongoDbSettings>;
export type MessageFormatValue = "json" | "json-unformatted" | (string & {});
export declare const MessageFormatValue: any;
export interface KinesisSettings {
    StreamArn?: string;
    MessageFormat?: MessageFormatValue;
    ServiceAccessRoleArn?: string;
    IncludeTransactionDetails?: boolean;
    IncludePartitionValue?: boolean;
    PartitionIncludeSchemaTable?: boolean;
    IncludeTableAlterOperations?: boolean;
    IncludeControlDetails?: boolean;
    IncludeNullAndEmpty?: boolean;
    NoHexPrefix?: boolean;
    UseLargeIntegerValue?: boolean;
}
export declare const KinesisSettings: S.Schema<KinesisSettings>;
export type KafkaSecurityProtocol = "plaintext" | "ssl-authentication" | "ssl-encryption" | "sasl-ssl" | (string & {});
export declare const KafkaSecurityProtocol: any;
export type KafkaSaslMechanism = "scram-sha-512" | "plain" | (string & {});
export declare const KafkaSaslMechanism: any;
export type KafkaSslEndpointIdentificationAlgorithm = "none" | "https" | (string & {});
export declare const KafkaSslEndpointIdentificationAlgorithm: any;
export interface KafkaSettings {
    Broker?: string;
    Topic?: string;
    MessageFormat?: MessageFormatValue;
    IncludeTransactionDetails?: boolean;
    IncludePartitionValue?: boolean;
    PartitionIncludeSchemaTable?: boolean;
    IncludeTableAlterOperations?: boolean;
    IncludeControlDetails?: boolean;
    MessageMaxBytes?: number;
    IncludeNullAndEmpty?: boolean;
    SecurityProtocol?: KafkaSecurityProtocol;
    SslClientCertificateArn?: string;
    SslClientKeyArn?: string;
    SslClientKeyPassword?: string | redacted.Redacted<string>;
    SslCaCertificateArn?: string;
    SaslUsername?: string;
    SaslPassword?: string | redacted.Redacted<string>;
    NoHexPrefix?: boolean;
    SaslMechanism?: KafkaSaslMechanism;
    SslEndpointIdentificationAlgorithm?: KafkaSslEndpointIdentificationAlgorithm;
    UseLargeIntegerValue?: boolean;
}
export declare const KafkaSettings: S.Schema<KafkaSettings>;
export interface ElasticsearchSettings {
    ServiceAccessRoleArn: string;
    EndpointUri: string;
    FullLoadErrorPercentage?: number;
    ErrorRetryDuration?: number;
    UseNewMappingType?: boolean;
}
export declare const ElasticsearchSettings: S.Schema<ElasticsearchSettings>;
export interface NeptuneSettings {
    ServiceAccessRoleArn?: string;
    S3BucketName: string;
    S3BucketFolder: string;
    ErrorRetryDuration?: number;
    MaxFileSize?: number;
    MaxRetryCount?: number;
    IamAuthEnabled?: boolean;
}
export declare const NeptuneSettings: S.Schema<NeptuneSettings>;
export interface RedshiftSettings {
    AcceptAnyDate?: boolean;
    AfterConnectScript?: string;
    BucketFolder?: string;
    BucketName?: string;
    CaseSensitiveNames?: boolean;
    CompUpdate?: boolean;
    ConnectionTimeout?: number;
    DatabaseName?: string;
    DateFormat?: string;
    EmptyAsNull?: boolean;
    EncryptionMode?: EncryptionModeValue;
    ExplicitIds?: boolean;
    FileTransferUploadStreams?: number;
    LoadTimeout?: number;
    MaxFileSize?: number;
    Password?: string | redacted.Redacted<string>;
    Port?: number;
    RemoveQuotes?: boolean;
    ReplaceInvalidChars?: string;
    ReplaceChars?: string;
    ServerName?: string;
    ServiceAccessRoleArn?: string;
    ServerSideEncryptionKmsKeyId?: string;
    TimeFormat?: string;
    TrimBlanks?: boolean;
    TruncateColumns?: boolean;
    Username?: string;
    WriteBufferSize?: number;
    SecretsManagerAccessRoleArn?: string;
    SecretsManagerSecretId?: string;
    MapBooleanAsBoolean?: boolean;
}
export declare const RedshiftSettings: S.Schema<RedshiftSettings>;
export type PluginNameValue = "no-preference" | "test-decoding" | "pglogical" | (string & {});
export declare const PluginNameValue: any;
export type LongVarcharMappingType = "wstring" | "clob" | "nclob" | (string & {});
export declare const LongVarcharMappingType: any;
export type DatabaseMode = "default" | "babelfish" | (string & {});
export declare const DatabaseMode: any;
export type PostgreSQLAuthenticationMethod = "password" | "iam" | (string & {});
export declare const PostgreSQLAuthenticationMethod: any;
export interface PostgreSQLSettings {
    AfterConnectScript?: string;
    CaptureDdls?: boolean;
    MaxFileSize?: number;
    DatabaseName?: string;
    DdlArtifactsSchema?: string;
    ExecuteTimeout?: number;
    FailTasksOnLobTruncation?: boolean;
    HeartbeatEnable?: boolean;
    HeartbeatSchema?: string;
    HeartbeatFrequency?: number;
    Password?: string | redacted.Redacted<string>;
    Port?: number;
    ServerName?: string;
    Username?: string;
    SlotName?: string;
    PluginName?: PluginNameValue;
    SecretsManagerAccessRoleArn?: string;
    SecretsManagerSecretId?: string;
    TrimSpaceInChar?: boolean;
    MapBooleanAsBoolean?: boolean;
    MapJsonbAsClob?: boolean;
    MapLongVarcharAs?: LongVarcharMappingType;
    DatabaseMode?: DatabaseMode;
    BabelfishDatabaseName?: string;
    DisableUnicodeSourceFilter?: boolean;
    ServiceAccessRoleArn?: string;
    AuthenticationMethod?: PostgreSQLAuthenticationMethod;
}
export declare const PostgreSQLSettings: S.Schema<PostgreSQLSettings>;
export type TargetDbType = "specific-database" | "multiple-databases" | (string & {});
export declare const TargetDbType: any;
export type MySQLAuthenticationMethod = "password" | "iam" | (string & {});
export declare const MySQLAuthenticationMethod: any;
export interface MySQLSettings {
    AfterConnectScript?: string;
    CleanSourceMetadataOnMismatch?: boolean;
    DatabaseName?: string;
    EventsPollInterval?: number;
    TargetDbType?: TargetDbType;
    MaxFileSize?: number;
    ParallelLoadThreads?: number;
    Password?: string | redacted.Redacted<string>;
    Port?: number;
    ServerName?: string;
    ServerTimezone?: string;
    Username?: string;
    SecretsManagerAccessRoleArn?: string;
    SecretsManagerSecretId?: string;
    ExecuteTimeout?: number;
    ServiceAccessRoleArn?: string;
    AuthenticationMethod?: MySQLAuthenticationMethod;
}
export declare const MySQLSettings: S.Schema<MySQLSettings>;
export type IntegerList = number[];
export declare const IntegerList: any;
export type CharLengthSemantics = "default" | "char" | "byte" | (string & {});
export declare const CharLengthSemantics: any;
export type OracleAuthenticationMethod = "password" | "kerberos" | (string & {});
export declare const OracleAuthenticationMethod: any;
export interface OracleSettings {
    AddSupplementalLogging?: boolean;
    ArchivedLogDestId?: number;
    AdditionalArchivedLogDestId?: number;
    ExtraArchivedLogDestIds?: number[];
    AllowSelectNestedTables?: boolean;
    ParallelAsmReadThreads?: number;
    ReadAheadBlocks?: number;
    AccessAlternateDirectly?: boolean;
    UseAlternateFolderForOnline?: boolean;
    OraclePathPrefix?: string;
    UsePathPrefix?: string;
    ReplacePathPrefix?: boolean;
    EnableHomogenousTablespace?: boolean;
    DirectPathNoLog?: boolean;
    ArchivedLogsOnly?: boolean;
    AsmPassword?: string | redacted.Redacted<string>;
    AsmServer?: string;
    AsmUser?: string;
    CharLengthSemantics?: CharLengthSemantics;
    DatabaseName?: string;
    DirectPathParallelLoad?: boolean;
    FailTasksOnLobTruncation?: boolean;
    NumberDatatypeScale?: number;
    Password?: string | redacted.Redacted<string>;
    Port?: number;
    ReadTableSpaceName?: boolean;
    RetryInterval?: number;
    SecurityDbEncryption?: string | redacted.Redacted<string>;
    SecurityDbEncryptionName?: string;
    ServerName?: string;
    SpatialDataOptionToGeoJsonFunctionName?: string;
    StandbyDelayTime?: number;
    Username?: string;
    UseBFile?: boolean;
    UseDirectPathFullLoad?: boolean;
    UseLogminerReader?: boolean;
    SecretsManagerAccessRoleArn?: string;
    SecretsManagerSecretId?: string;
    SecretsManagerOracleAsmAccessRoleArn?: string;
    SecretsManagerOracleAsmSecretId?: string;
    TrimSpaceInChar?: boolean;
    ConvertTimestampWithZoneToUTC?: boolean;
    OpenTransactionWindow?: number;
    AuthenticationMethod?: OracleAuthenticationMethod;
}
export declare const OracleSettings: S.Schema<OracleSettings>;
export interface SybaseSettings {
    DatabaseName?: string;
    Password?: string | redacted.Redacted<string>;
    Port?: number;
    ServerName?: string;
    Username?: string;
    SecretsManagerAccessRoleArn?: string;
    SecretsManagerSecretId?: string;
}
export declare const SybaseSettings: S.Schema<SybaseSettings>;
export type SafeguardPolicy = "rely-on-sql-server-replication-agent" | "exclusive-automatic-truncation" | "shared-automatic-truncation" | (string & {});
export declare const SafeguardPolicy: any;
export type TlogAccessMode = "BackupOnly" | "PreferBackup" | "PreferTlog" | "TlogOnly" | (string & {});
export declare const TlogAccessMode: any;
export type SqlServerAuthenticationMethod = "password" | "kerberos" | (string & {});
export declare const SqlServerAuthenticationMethod: any;
export interface MicrosoftSQLServerSettings {
    Port?: number;
    BcpPacketSize?: number;
    DatabaseName?: string;
    ControlTablesFileGroup?: string;
    Password?: string | redacted.Redacted<string>;
    QuerySingleAlwaysOnNode?: boolean;
    ReadBackupOnly?: boolean;
    SafeguardPolicy?: SafeguardPolicy;
    ServerName?: string;
    Username?: string;
    UseBcpFullLoad?: boolean;
    UseThirdPartyBackupDevice?: boolean;
    SecretsManagerAccessRoleArn?: string;
    SecretsManagerSecretId?: string;
    TrimSpaceInChar?: boolean;
    TlogAccessMode?: TlogAccessMode;
    ForceLobLookup?: boolean;
    AuthenticationMethod?: SqlServerAuthenticationMethod;
}
export declare const MicrosoftSQLServerSettings: S.Schema<MicrosoftSQLServerSettings>;
export interface IBMDb2Settings {
    DatabaseName?: string;
    Password?: string | redacted.Redacted<string>;
    Port?: number;
    ServerName?: string;
    SetDataCaptureChanges?: boolean;
    CurrentLsn?: string;
    MaxKBytesPerRead?: number;
    Username?: string;
    SecretsManagerAccessRoleArn?: string;
    SecretsManagerSecretId?: string;
    LoadTimeout?: number;
    WriteBufferSize?: number;
    MaxFileSize?: number;
    KeepCsvFiles?: boolean;
}
export declare const IBMDb2Settings: S.Schema<IBMDb2Settings>;
export interface DocDbSettings {
    Username?: string;
    Password?: string | redacted.Redacted<string>;
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    NestingLevel?: NestingLevelValue;
    ExtractDocId?: boolean;
    DocsToInvestigate?: number;
    KmsKeyId?: string;
    SecretsManagerAccessRoleArn?: string;
    SecretsManagerSecretId?: string;
    UseUpdateLookUp?: boolean;
    ReplicateShardCollections?: boolean;
}
export declare const DocDbSettings: S.Schema<DocDbSettings>;
export type SslSecurityProtocolValue = "plaintext" | "ssl-encryption" | (string & {});
export declare const SslSecurityProtocolValue: any;
export type RedisAuthTypeValue = "none" | "auth-role" | "auth-token" | (string & {});
export declare const RedisAuthTypeValue: any;
export interface RedisSettings {
    ServerName: string;
    Port: number;
    SslSecurityProtocol?: SslSecurityProtocolValue;
    AuthType?: RedisAuthTypeValue;
    AuthUserName?: string;
    AuthPassword?: string | redacted.Redacted<string>;
    SslCaCertificateArn?: string;
}
export declare const RedisSettings: S.Schema<RedisSettings>;
export interface GcpMySQLSettings {
    AfterConnectScript?: string;
    CleanSourceMetadataOnMismatch?: boolean;
    DatabaseName?: string;
    EventsPollInterval?: number;
    TargetDbType?: TargetDbType;
    MaxFileSize?: number;
    ParallelLoadThreads?: number;
    Password?: string | redacted.Redacted<string>;
    Port?: number;
    ServerName?: string;
    ServerTimezone?: string;
    Username?: string;
    SecretsManagerAccessRoleArn?: string;
    SecretsManagerSecretId?: string;
}
export declare const GcpMySQLSettings: S.Schema<GcpMySQLSettings>;
export interface TimestreamSettings {
    DatabaseName: string;
    MemoryDuration: number;
    MagneticDuration: number;
    CdcInsertsAndUpdates?: boolean;
    EnableMagneticStoreWrites?: boolean;
}
export declare const TimestreamSettings: S.Schema<TimestreamSettings>;
export interface CreateEndpointMessage {
    EndpointIdentifier: string;
    EndpointType: ReplicationEndpointTypeValue;
    EngineName: string;
    Username?: string;
    Password?: string | redacted.Redacted<string>;
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    ExtraConnectionAttributes?: string;
    KmsKeyId?: string;
    Tags?: Tag[];
    CertificateArn?: string;
    SslMode?: DmsSslModeValue;
    ServiceAccessRoleArn?: string;
    ExternalTableDefinition?: string;
    DynamoDbSettings?: DynamoDbSettings;
    S3Settings?: S3Settings;
    DmsTransferSettings?: DmsTransferSettings;
    MongoDbSettings?: MongoDbSettings;
    KinesisSettings?: KinesisSettings;
    KafkaSettings?: KafkaSettings;
    ElasticsearchSettings?: ElasticsearchSettings;
    NeptuneSettings?: NeptuneSettings;
    RedshiftSettings?: RedshiftSettings;
    PostgreSQLSettings?: PostgreSQLSettings;
    MySQLSettings?: MySQLSettings;
    OracleSettings?: OracleSettings;
    SybaseSettings?: SybaseSettings;
    MicrosoftSQLServerSettings?: MicrosoftSQLServerSettings;
    IBMDb2Settings?: IBMDb2Settings;
    ResourceIdentifier?: string;
    DocDbSettings?: DocDbSettings;
    RedisSettings?: RedisSettings;
    GcpMySQLSettings?: GcpMySQLSettings;
    TimestreamSettings?: TimestreamSettings;
}
export declare const CreateEndpointMessage: S.Schema<CreateEndpointMessage>;
export interface LakehouseSettings {
    Arn: string;
}
export declare const LakehouseSettings: S.Schema<LakehouseSettings>;
export interface Endpoint {
    EndpointIdentifier?: string;
    EndpointType?: ReplicationEndpointTypeValue;
    EngineName?: string;
    EngineDisplayName?: string;
    Username?: string;
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    ExtraConnectionAttributes?: string;
    Status?: string;
    KmsKeyId?: string;
    EndpointArn?: string;
    CertificateArn?: string;
    SslMode?: DmsSslModeValue;
    ServiceAccessRoleArn?: string;
    ExternalTableDefinition?: string;
    ExternalId?: string;
    IsReadOnly?: boolean;
    DynamoDbSettings?: DynamoDbSettings;
    S3Settings?: S3Settings;
    DmsTransferSettings?: DmsTransferSettings;
    MongoDbSettings?: MongoDbSettings;
    KinesisSettings?: KinesisSettings;
    KafkaSettings?: KafkaSettings;
    ElasticsearchSettings?: ElasticsearchSettings;
    NeptuneSettings?: NeptuneSettings;
    RedshiftSettings?: RedshiftSettings;
    PostgreSQLSettings?: PostgreSQLSettings;
    MySQLSettings?: MySQLSettings;
    OracleSettings?: OracleSettings;
    SybaseSettings?: SybaseSettings;
    MicrosoftSQLServerSettings?: MicrosoftSQLServerSettings;
    IBMDb2Settings?: IBMDb2Settings;
    DocDbSettings?: DocDbSettings;
    RedisSettings?: RedisSettings;
    GcpMySQLSettings?: GcpMySQLSettings;
    TimestreamSettings?: TimestreamSettings;
    LakehouseSettings?: LakehouseSettings;
}
export declare const Endpoint: S.Schema<Endpoint>;
export interface CreateEndpointResponse {
    Endpoint?: Endpoint;
}
export declare const CreateEndpointResponse: S.Schema<CreateEndpointResponse>;
export type EventCategoriesList = string[];
export declare const EventCategoriesList: any;
export type SourceIdsList = string[];
export declare const SourceIdsList: any;
export interface CreateEventSubscriptionMessage {
    SubscriptionName: string;
    SnsTopicArn: string;
    SourceType?: string;
    EventCategories?: string[];
    SourceIds?: string[];
    Enabled?: boolean;
    Tags?: Tag[];
}
export declare const CreateEventSubscriptionMessage: S.Schema<CreateEventSubscriptionMessage>;
export interface EventSubscription {
    CustomerAwsId?: string;
    CustSubscriptionId?: string;
    SnsTopicArn?: string;
    Status?: string;
    SubscriptionCreationTime?: string;
    SourceType?: string;
    SourceIdsList?: string[];
    EventCategoriesList?: string[];
    Enabled?: boolean;
}
export declare const EventSubscription: S.Schema<EventSubscription>;
export interface CreateEventSubscriptionResponse {
    EventSubscription?: EventSubscription;
}
export declare const CreateEventSubscriptionResponse: S.Schema<CreateEventSubscriptionResponse>;
export interface CreateFleetAdvisorCollectorRequest {
    CollectorName: string;
    Description?: string;
    ServiceAccessRoleArn: string;
    S3BucketName: string;
}
export declare const CreateFleetAdvisorCollectorRequest: S.Schema<CreateFleetAdvisorCollectorRequest>;
export interface CreateFleetAdvisorCollectorResponse {
    CollectorReferencedId?: string;
    CollectorName?: string;
    Description?: string;
    ServiceAccessRoleArn?: string;
    S3BucketName?: string;
}
export declare const CreateFleetAdvisorCollectorResponse: S.Schema<CreateFleetAdvisorCollectorResponse>;
export type StringList = string[];
export declare const StringList: any;
export interface CreateInstanceProfileMessage {
    AvailabilityZone?: string;
    KmsKeyArn?: string;
    PubliclyAccessible?: boolean;
    Tags?: Tag[];
    NetworkType?: string;
    InstanceProfileName?: string;
    Description?: string;
    SubnetGroupIdentifier?: string;
    VpcSecurityGroups?: string[];
}
export declare const CreateInstanceProfileMessage: S.Schema<CreateInstanceProfileMessage>;
export interface InstanceProfile {
    InstanceProfileArn?: string;
    AvailabilityZone?: string;
    KmsKeyArn?: string;
    PubliclyAccessible?: boolean;
    NetworkType?: string;
    InstanceProfileName?: string;
    Description?: string;
    InstanceProfileCreationTime?: Date;
    SubnetGroupIdentifier?: string;
    VpcSecurityGroups?: string[];
}
export declare const InstanceProfile: S.Schema<InstanceProfile>;
export interface CreateInstanceProfileResponse {
    InstanceProfile?: InstanceProfile;
}
export declare const CreateInstanceProfileResponse: S.Schema<CreateInstanceProfileResponse>;
export interface DataProviderDescriptorDefinition {
    DataProviderIdentifier: string;
    SecretsManagerSecretId?: string;
    SecretsManagerAccessRoleArn?: string;
}
export declare const DataProviderDescriptorDefinition: S.Schema<DataProviderDescriptorDefinition>;
export type DataProviderDescriptorDefinitionList = DataProviderDescriptorDefinition[];
export declare const DataProviderDescriptorDefinitionList: any;
export interface SCApplicationAttributes {
    S3BucketPath?: string;
    S3BucketRoleArn?: string;
}
export declare const SCApplicationAttributes: S.Schema<SCApplicationAttributes>;
export interface CreateMigrationProjectMessage {
    MigrationProjectName?: string;
    SourceDataProviderDescriptors: DataProviderDescriptorDefinition[];
    TargetDataProviderDescriptors: DataProviderDescriptorDefinition[];
    InstanceProfileIdentifier: string;
    TransformationRules?: string;
    Description?: string;
    Tags?: Tag[];
    SchemaConversionApplicationAttributes?: SCApplicationAttributes;
}
export declare const CreateMigrationProjectMessage: S.Schema<CreateMigrationProjectMessage>;
export interface DataProviderDescriptor {
    SecretsManagerSecretId?: string;
    SecretsManagerAccessRoleArn?: string;
    DataProviderName?: string;
    DataProviderArn?: string;
}
export declare const DataProviderDescriptor: S.Schema<DataProviderDescriptor>;
export type DataProviderDescriptorList = DataProviderDescriptor[];
export declare const DataProviderDescriptorList: any;
export interface MigrationProject {
    MigrationProjectName?: string;
    MigrationProjectArn?: string;
    MigrationProjectCreationTime?: Date;
    SourceDataProviderDescriptors?: DataProviderDescriptor[];
    TargetDataProviderDescriptors?: DataProviderDescriptor[];
    InstanceProfileArn?: string;
    InstanceProfileName?: string;
    TransformationRules?: string;
    Description?: string;
    SchemaConversionApplicationAttributes?: SCApplicationAttributes;
}
export declare const MigrationProject: S.Schema<MigrationProject>;
export interface CreateMigrationProjectResponse {
    MigrationProject?: MigrationProject;
}
export declare const CreateMigrationProjectResponse: S.Schema<CreateMigrationProjectResponse>;
export interface ComputeConfig {
    AvailabilityZone?: string;
    DnsNameServers?: string;
    KmsKeyId?: string;
    MaxCapacityUnits?: number;
    MinCapacityUnits?: number;
    MultiAZ?: boolean;
    PreferredMaintenanceWindow?: string;
    ReplicationSubnetGroupId?: string;
    VpcSecurityGroupIds?: string[];
}
export declare const ComputeConfig: S.Schema<ComputeConfig>;
export interface CreateReplicationConfigMessage {
    ReplicationConfigIdentifier: string;
    SourceEndpointArn: string;
    TargetEndpointArn: string;
    ComputeConfig: ComputeConfig;
    ReplicationType: MigrationTypeValue;
    TableMappings: string;
    ReplicationSettings?: string;
    SupplementalSettings?: string;
    ResourceIdentifier?: string;
    Tags?: Tag[];
}
export declare const CreateReplicationConfigMessage: S.Schema<CreateReplicationConfigMessage>;
export interface ReplicationConfig {
    ReplicationConfigIdentifier?: string;
    ReplicationConfigArn?: string;
    SourceEndpointArn?: string;
    TargetEndpointArn?: string;
    ReplicationType?: MigrationTypeValue;
    ComputeConfig?: ComputeConfig;
    ReplicationSettings?: string;
    SupplementalSettings?: string;
    TableMappings?: string;
    ReplicationConfigCreateTime?: Date;
    ReplicationConfigUpdateTime?: Date;
    IsReadOnly?: boolean;
}
export declare const ReplicationConfig: S.Schema<ReplicationConfig>;
export interface CreateReplicationConfigResponse {
    ReplicationConfig?: ReplicationConfig;
}
export declare const CreateReplicationConfigResponse: S.Schema<CreateReplicationConfigResponse>;
export type ReplicationInstanceClass = string;
export type VpcSecurityGroupIdList = string[];
export declare const VpcSecurityGroupIdList: any;
export interface KerberosAuthenticationSettings {
    KeyCacheSecretId?: string;
    KeyCacheSecretIamArn?: string;
    Krb5FileContents?: string;
}
export declare const KerberosAuthenticationSettings: S.Schema<KerberosAuthenticationSettings>;
export interface CreateReplicationInstanceMessage {
    ReplicationInstanceIdentifier: string;
    AllocatedStorage?: number;
    ReplicationInstanceClass: string;
    VpcSecurityGroupIds?: string[];
    AvailabilityZone?: string;
    ReplicationSubnetGroupIdentifier?: string;
    PreferredMaintenanceWindow?: string;
    MultiAZ?: boolean;
    EngineVersion?: string;
    AutoMinorVersionUpgrade?: boolean;
    Tags?: Tag[];
    KmsKeyId?: string;
    PubliclyAccessible?: boolean;
    DnsNameServers?: string;
    ResourceIdentifier?: string;
    NetworkType?: string;
    KerberosAuthenticationSettings?: KerberosAuthenticationSettings;
}
export declare const CreateReplicationInstanceMessage: S.Schema<CreateReplicationInstanceMessage>;
export interface VpcSecurityGroupMembership {
    VpcSecurityGroupId?: string;
    Status?: string;
}
export declare const VpcSecurityGroupMembership: S.Schema<VpcSecurityGroupMembership>;
export type VpcSecurityGroupMembershipList = VpcSecurityGroupMembership[];
export declare const VpcSecurityGroupMembershipList: any;
export interface AvailabilityZone {
    Name?: string;
}
export declare const AvailabilityZone: S.Schema<AvailabilityZone>;
export interface Subnet {
    SubnetIdentifier?: string;
    SubnetAvailabilityZone?: AvailabilityZone;
    SubnetStatus?: string;
}
export declare const Subnet: S.Schema<Subnet>;
export type SubnetList = Subnet[];
export declare const SubnetList: any;
export interface ReplicationSubnetGroup {
    ReplicationSubnetGroupIdentifier?: string;
    ReplicationSubnetGroupDescription?: string;
    VpcId?: string;
    SubnetGroupStatus?: string;
    Subnets?: Subnet[];
    SupportedNetworkTypes?: string[];
    IsReadOnly?: boolean;
}
export declare const ReplicationSubnetGroup: S.Schema<ReplicationSubnetGroup>;
export interface ReplicationPendingModifiedValues {
    ReplicationInstanceClass?: string;
    AllocatedStorage?: number;
    MultiAZ?: boolean;
    EngineVersion?: string;
    NetworkType?: string;
}
export declare const ReplicationPendingModifiedValues: S.Schema<ReplicationPendingModifiedValues>;
export type ReplicationInstancePublicIpAddressList = string[];
export declare const ReplicationInstancePublicIpAddressList: any;
export type ReplicationInstancePrivateIpAddressList = string[];
export declare const ReplicationInstancePrivateIpAddressList: any;
export type ReplicationInstanceIpv6AddressList = string[];
export declare const ReplicationInstanceIpv6AddressList: any;
export interface ReplicationInstance {
    ReplicationInstanceIdentifier?: string;
    ReplicationInstanceClass?: string;
    ReplicationInstanceStatus?: string;
    AllocatedStorage?: number;
    InstanceCreateTime?: Date;
    VpcSecurityGroups?: VpcSecurityGroupMembership[];
    AvailabilityZone?: string;
    ReplicationSubnetGroup?: ReplicationSubnetGroup;
    PreferredMaintenanceWindow?: string;
    PendingModifiedValues?: ReplicationPendingModifiedValues;
    MultiAZ?: boolean;
    EngineVersion?: string;
    AutoMinorVersionUpgrade?: boolean;
    KmsKeyId?: string;
    ReplicationInstanceArn?: string;
    ReplicationInstancePublicIpAddress?: string;
    ReplicationInstancePrivateIpAddress?: string;
    ReplicationInstancePublicIpAddresses?: string[];
    ReplicationInstancePrivateIpAddresses?: string[];
    ReplicationInstanceIpv6Addresses?: string[];
    PubliclyAccessible?: boolean;
    SecondaryAvailabilityZone?: string;
    FreeUntil?: Date;
    DnsNameServers?: string;
    NetworkType?: string;
    KerberosAuthenticationSettings?: KerberosAuthenticationSettings;
}
export declare const ReplicationInstance: S.Schema<ReplicationInstance>;
export interface CreateReplicationInstanceResponse {
    ReplicationInstance?: ReplicationInstance;
}
export declare const CreateReplicationInstanceResponse: S.Schema<CreateReplicationInstanceResponse>;
export type SubnetIdentifierList = string[];
export declare const SubnetIdentifierList: any;
export interface CreateReplicationSubnetGroupMessage {
    ReplicationSubnetGroupIdentifier: string;
    ReplicationSubnetGroupDescription: string;
    SubnetIds: string[];
    Tags?: Tag[];
}
export declare const CreateReplicationSubnetGroupMessage: S.Schema<CreateReplicationSubnetGroupMessage>;
export interface CreateReplicationSubnetGroupResponse {
    ReplicationSubnetGroup?: ReplicationSubnetGroup;
}
export declare const CreateReplicationSubnetGroupResponse: S.Schema<CreateReplicationSubnetGroupResponse>;
export interface CreateReplicationTaskMessage {
    ReplicationTaskIdentifier: string;
    SourceEndpointArn: string;
    TargetEndpointArn: string;
    ReplicationInstanceArn: string;
    MigrationType: MigrationTypeValue;
    TableMappings: string;
    ReplicationTaskSettings?: string;
    CdcStartTime?: Date;
    CdcStartPosition?: string;
    CdcStopPosition?: string;
    Tags?: Tag[];
    TaskData?: string;
    ResourceIdentifier?: string;
}
export declare const CreateReplicationTaskMessage: S.Schema<CreateReplicationTaskMessage>;
export interface ReplicationTaskStats {
    FullLoadProgressPercent?: number;
    ElapsedTimeMillis?: number;
    TablesLoaded?: number;
    TablesLoading?: number;
    TablesQueued?: number;
    TablesErrored?: number;
    FreshStartDate?: Date;
    StartDate?: Date;
    StopDate?: Date;
    FullLoadStartDate?: Date;
    FullLoadFinishDate?: Date;
}
export declare const ReplicationTaskStats: S.Schema<ReplicationTaskStats>;
export interface ReplicationTask {
    ReplicationTaskIdentifier?: string;
    SourceEndpointArn?: string;
    TargetEndpointArn?: string;
    ReplicationInstanceArn?: string;
    MigrationType?: MigrationTypeValue;
    TableMappings?: string;
    ReplicationTaskSettings?: string;
    Status?: string;
    LastFailureMessage?: string;
    StopReason?: string;
    ReplicationTaskCreationDate?: Date;
    ReplicationTaskStartDate?: Date;
    CdcStartPosition?: string;
    CdcStopPosition?: string;
    RecoveryCheckpoint?: string;
    ReplicationTaskArn?: string;
    ReplicationTaskStats?: ReplicationTaskStats;
    TaskData?: string;
    TargetReplicationInstanceArn?: string;
}
export declare const ReplicationTask: S.Schema<ReplicationTask>;
export interface CreateReplicationTaskResponse {
    ReplicationTask?: ReplicationTask;
}
export declare const CreateReplicationTaskResponse: S.Schema<CreateReplicationTaskResponse>;
export interface DeleteCertificateMessage {
    CertificateArn: string;
}
export declare const DeleteCertificateMessage: S.Schema<DeleteCertificateMessage>;
export type CertificateWallet = Uint8Array;
export interface Certificate {
    CertificateIdentifier?: string;
    CertificateCreationDate?: Date;
    CertificatePem?: string;
    CertificateWallet?: Uint8Array;
    CertificateArn?: string;
    CertificateOwner?: string;
    ValidFromDate?: Date;
    ValidToDate?: Date;
    SigningAlgorithm?: string;
    KeyLength?: number;
    KmsKeyId?: string;
}
export declare const Certificate: S.Schema<Certificate>;
export interface DeleteCertificateResponse {
    Certificate?: Certificate;
}
export declare const DeleteCertificateResponse: S.Schema<DeleteCertificateResponse>;
export interface DeleteConnectionMessage {
    EndpointArn: string;
    ReplicationInstanceArn: string;
}
export declare const DeleteConnectionMessage: S.Schema<DeleteConnectionMessage>;
export interface Connection {
    ReplicationInstanceArn?: string;
    EndpointArn?: string;
    Status?: string;
    LastFailureMessage?: string;
    EndpointIdentifier?: string;
    ReplicationInstanceIdentifier?: string;
}
export declare const Connection: S.Schema<Connection>;
export interface DeleteConnectionResponse {
    Connection?: Connection;
}
export declare const DeleteConnectionResponse: S.Schema<DeleteConnectionResponse>;
export interface DeleteDataMigrationMessage {
    DataMigrationIdentifier: string;
}
export declare const DeleteDataMigrationMessage: S.Schema<DeleteDataMigrationMessage>;
export interface DeleteDataMigrationResponse {
    DataMigration?: DataMigration;
}
export declare const DeleteDataMigrationResponse: S.Schema<DeleteDataMigrationResponse>;
export interface DeleteDataProviderMessage {
    DataProviderIdentifier: string;
}
export declare const DeleteDataProviderMessage: S.Schema<DeleteDataProviderMessage>;
export interface DeleteDataProviderResponse {
    DataProvider?: DataProvider;
}
export declare const DeleteDataProviderResponse: S.Schema<DeleteDataProviderResponse>;
export interface DeleteEndpointMessage {
    EndpointArn: string;
}
export declare const DeleteEndpointMessage: S.Schema<DeleteEndpointMessage>;
export interface DeleteEndpointResponse {
    Endpoint?: Endpoint;
}
export declare const DeleteEndpointResponse: S.Schema<DeleteEndpointResponse>;
export interface DeleteEventSubscriptionMessage {
    SubscriptionName: string;
}
export declare const DeleteEventSubscriptionMessage: S.Schema<DeleteEventSubscriptionMessage>;
export interface DeleteEventSubscriptionResponse {
    EventSubscription?: EventSubscription;
}
export declare const DeleteEventSubscriptionResponse: S.Schema<DeleteEventSubscriptionResponse>;
export interface DeleteCollectorRequest {
    CollectorReferencedId: string;
}
export declare const DeleteCollectorRequest: S.Schema<DeleteCollectorRequest>;
export interface DeleteFleetAdvisorCollectorResponse {
}
export declare const DeleteFleetAdvisorCollectorResponse: S.Schema<DeleteFleetAdvisorCollectorResponse>;
export interface DeleteFleetAdvisorDatabasesRequest {
    DatabaseIds: string[];
}
export declare const DeleteFleetAdvisorDatabasesRequest: S.Schema<DeleteFleetAdvisorDatabasesRequest>;
export interface DeleteFleetAdvisorDatabasesResponse {
    DatabaseIds?: string[];
}
export declare const DeleteFleetAdvisorDatabasesResponse: S.Schema<DeleteFleetAdvisorDatabasesResponse>;
export interface DeleteInstanceProfileMessage {
    InstanceProfileIdentifier: string;
}
export declare const DeleteInstanceProfileMessage: S.Schema<DeleteInstanceProfileMessage>;
export interface DeleteInstanceProfileResponse {
    InstanceProfile?: InstanceProfile;
}
export declare const DeleteInstanceProfileResponse: S.Schema<DeleteInstanceProfileResponse>;
export interface DeleteMigrationProjectMessage {
    MigrationProjectIdentifier: string;
}
export declare const DeleteMigrationProjectMessage: S.Schema<DeleteMigrationProjectMessage>;
export interface DeleteMigrationProjectResponse {
    MigrationProject?: MigrationProject;
}
export declare const DeleteMigrationProjectResponse: S.Schema<DeleteMigrationProjectResponse>;
export interface DeleteReplicationConfigMessage {
    ReplicationConfigArn: string;
}
export declare const DeleteReplicationConfigMessage: S.Schema<DeleteReplicationConfigMessage>;
export interface DeleteReplicationConfigResponse {
    ReplicationConfig?: ReplicationConfig;
}
export declare const DeleteReplicationConfigResponse: S.Schema<DeleteReplicationConfigResponse>;
export interface DeleteReplicationInstanceMessage {
    ReplicationInstanceArn: string;
}
export declare const DeleteReplicationInstanceMessage: S.Schema<DeleteReplicationInstanceMessage>;
export interface DeleteReplicationInstanceResponse {
    ReplicationInstance?: ReplicationInstance;
}
export declare const DeleteReplicationInstanceResponse: S.Schema<DeleteReplicationInstanceResponse>;
export interface DeleteReplicationSubnetGroupMessage {
    ReplicationSubnetGroupIdentifier: string;
}
export declare const DeleteReplicationSubnetGroupMessage: S.Schema<DeleteReplicationSubnetGroupMessage>;
export interface DeleteReplicationSubnetGroupResponse {
}
export declare const DeleteReplicationSubnetGroupResponse: S.Schema<DeleteReplicationSubnetGroupResponse>;
export interface DeleteReplicationTaskMessage {
    ReplicationTaskArn: string;
}
export declare const DeleteReplicationTaskMessage: S.Schema<DeleteReplicationTaskMessage>;
export interface DeleteReplicationTaskResponse {
    ReplicationTask?: ReplicationTask;
}
export declare const DeleteReplicationTaskResponse: S.Schema<DeleteReplicationTaskResponse>;
export interface DeleteReplicationTaskAssessmentRunMessage {
    ReplicationTaskAssessmentRunArn: string;
}
export declare const DeleteReplicationTaskAssessmentRunMessage: S.Schema<DeleteReplicationTaskAssessmentRunMessage>;
export interface DeleteReplicationTaskAssessmentRunResponse {
    ReplicationTaskAssessmentRun?: ReplicationTaskAssessmentRun;
}
export declare const DeleteReplicationTaskAssessmentRunResponse: S.Schema<DeleteReplicationTaskAssessmentRunResponse>;
export interface DescribeAccountAttributesMessage {
}
export declare const DescribeAccountAttributesMessage: S.Schema<DescribeAccountAttributesMessage>;
export interface AccountQuota {
    AccountQuotaName?: string;
    Used?: number;
    Max?: number;
}
export declare const AccountQuota: S.Schema<AccountQuota>;
export type AccountQuotaList = AccountQuota[];
export declare const AccountQuotaList: any;
export interface DescribeAccountAttributesResponse {
    AccountQuotas?: AccountQuota[];
    UniqueAccountIdentifier?: string;
}
export declare const DescribeAccountAttributesResponse: S.Schema<DescribeAccountAttributesResponse>;
export interface DescribeApplicableIndividualAssessmentsMessage {
    ReplicationTaskArn?: string;
    ReplicationInstanceArn?: string;
    ReplicationConfigArn?: string;
    SourceEngineName?: string;
    TargetEngineName?: string;
    MigrationType?: MigrationTypeValue;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeApplicableIndividualAssessmentsMessage: S.Schema<DescribeApplicableIndividualAssessmentsMessage>;
export type IndividualAssessmentNameList = string[];
export declare const IndividualAssessmentNameList: any;
export interface DescribeApplicableIndividualAssessmentsResponse {
    IndividualAssessmentNames?: string[];
    Marker?: string;
}
export declare const DescribeApplicableIndividualAssessmentsResponse: S.Schema<DescribeApplicableIndividualAssessmentsResponse>;
export type FilterValueList = string[];
export declare const FilterValueList: any;
export interface Filter {
    Name: string;
    Values: string[];
}
export declare const Filter: S.Schema<Filter>;
export type FilterList = Filter[];
export declare const FilterList: any;
export interface DescribeCertificatesMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeCertificatesMessage: S.Schema<DescribeCertificatesMessage>;
export type CertificateList = Certificate[];
export declare const CertificateList: any;
export interface DescribeCertificatesResponse {
    Marker?: string;
    Certificates?: Certificate[];
}
export declare const DescribeCertificatesResponse: S.Schema<DescribeCertificatesResponse>;
export interface DescribeConnectionsMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeConnectionsMessage: S.Schema<DescribeConnectionsMessage>;
export type ConnectionList = Connection[];
export declare const ConnectionList: any;
export interface DescribeConnectionsResponse {
    Marker?: string;
    Connections?: Connection[];
}
export declare const DescribeConnectionsResponse: S.Schema<DescribeConnectionsResponse>;
export interface DescribeConversionConfigurationMessage {
    MigrationProjectIdentifier: string;
}
export declare const DescribeConversionConfigurationMessage: S.Schema<DescribeConversionConfigurationMessage>;
export interface DescribeConversionConfigurationResponse {
    MigrationProjectIdentifier?: string;
    ConversionConfiguration?: string;
}
export declare const DescribeConversionConfigurationResponse: S.Schema<DescribeConversionConfigurationResponse>;
export type Marker = string;
export interface DescribeDataMigrationsMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
    WithoutSettings?: boolean;
    WithoutStatistics?: boolean;
}
export declare const DescribeDataMigrationsMessage: S.Schema<DescribeDataMigrationsMessage>;
export type DataMigrations = DataMigration[];
export declare const DataMigrations: any;
export interface DescribeDataMigrationsResponse {
    DataMigrations?: DataMigration[];
    Marker?: string;
}
export declare const DescribeDataMigrationsResponse: S.Schema<DescribeDataMigrationsResponse>;
export interface DescribeDataProvidersMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeDataProvidersMessage: S.Schema<DescribeDataProvidersMessage>;
export type DataProviderList = DataProvider[];
export declare const DataProviderList: any;
export interface DescribeDataProvidersResponse {
    Marker?: string;
    DataProviders?: DataProvider[];
}
export declare const DescribeDataProvidersResponse: S.Schema<DescribeDataProvidersResponse>;
export interface DescribeEndpointsMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeEndpointsMessage: S.Schema<DescribeEndpointsMessage>;
export type EndpointList = Endpoint[];
export declare const EndpointList: any;
export interface DescribeEndpointsResponse {
    Marker?: string;
    Endpoints?: Endpoint[];
}
export declare const DescribeEndpointsResponse: S.Schema<DescribeEndpointsResponse>;
export interface DescribeEndpointSettingsMessage {
    EngineName: string;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeEndpointSettingsMessage: S.Schema<DescribeEndpointSettingsMessage>;
export type EndpointSettingTypeValue = "string" | "boolean" | "integer" | "enum" | (string & {});
export declare const EndpointSettingTypeValue: any;
export type EndpointSettingEnumValues = string[];
export declare const EndpointSettingEnumValues: any;
export interface EndpointSetting {
    Name?: string;
    Type?: EndpointSettingTypeValue;
    EnumValues?: string[];
    Sensitive?: boolean;
    Units?: string;
    Applicability?: string;
    IntValueMin?: number;
    IntValueMax?: number;
    DefaultValue?: string;
}
export declare const EndpointSetting: S.Schema<EndpointSetting>;
export type EndpointSettingsList = EndpointSetting[];
export declare const EndpointSettingsList: any;
export interface DescribeEndpointSettingsResponse {
    Marker?: string;
    EndpointSettings?: EndpointSetting[];
}
export declare const DescribeEndpointSettingsResponse: S.Schema<DescribeEndpointSettingsResponse>;
export interface DescribeEndpointTypesMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeEndpointTypesMessage: S.Schema<DescribeEndpointTypesMessage>;
export interface SupportedEndpointType {
    EngineName?: string;
    SupportsCDC?: boolean;
    EndpointType?: ReplicationEndpointTypeValue;
    ReplicationInstanceEngineMinimumVersion?: string;
    EngineDisplayName?: string;
}
export declare const SupportedEndpointType: S.Schema<SupportedEndpointType>;
export type SupportedEndpointTypeList = SupportedEndpointType[];
export declare const SupportedEndpointTypeList: any;
export interface DescribeEndpointTypesResponse {
    Marker?: string;
    SupportedEndpointTypes?: SupportedEndpointType[];
}
export declare const DescribeEndpointTypesResponse: S.Schema<DescribeEndpointTypesResponse>;
export interface DescribeEngineVersionsMessage {
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeEngineVersionsMessage: S.Schema<DescribeEngineVersionsMessage>;
export type ReleaseStatusValues = "beta" | "prod" | (string & {});
export declare const ReleaseStatusValues: any;
export type AvailableUpgradesList = string[];
export declare const AvailableUpgradesList: any;
export interface EngineVersion {
    Version?: string;
    Lifecycle?: string;
    ReleaseStatus?: ReleaseStatusValues;
    LaunchDate?: Date;
    AutoUpgradeDate?: Date;
    DeprecationDate?: Date;
    ForceUpgradeDate?: Date;
    AvailableUpgrades?: string[];
}
export declare const EngineVersion: S.Schema<EngineVersion>;
export type EngineVersionList = EngineVersion[];
export declare const EngineVersionList: any;
export interface DescribeEngineVersionsResponse {
    EngineVersions?: EngineVersion[];
    Marker?: string;
}
export declare const DescribeEngineVersionsResponse: S.Schema<DescribeEngineVersionsResponse>;
export interface DescribeEventCategoriesMessage {
    SourceType?: string;
    Filters?: Filter[];
}
export declare const DescribeEventCategoriesMessage: S.Schema<DescribeEventCategoriesMessage>;
export interface EventCategoryGroup {
    SourceType?: string;
    EventCategories?: string[];
}
export declare const EventCategoryGroup: S.Schema<EventCategoryGroup>;
export type EventCategoryGroupList = EventCategoryGroup[];
export declare const EventCategoryGroupList: any;
export interface DescribeEventCategoriesResponse {
    EventCategoryGroupList?: EventCategoryGroup[];
}
export declare const DescribeEventCategoriesResponse: S.Schema<DescribeEventCategoriesResponse>;
export type SourceType = "replication-instance" | (string & {});
export declare const SourceType: any;
export interface DescribeEventsMessage {
    SourceIdentifier?: string;
    SourceType?: SourceType;
    StartTime?: Date;
    EndTime?: Date;
    Duration?: number;
    EventCategories?: string[];
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeEventsMessage: S.Schema<DescribeEventsMessage>;
export interface Event {
    SourceIdentifier?: string;
    SourceType?: SourceType;
    Message?: string;
    EventCategories?: string[];
    Date?: Date;
}
export declare const Event: S.Schema<Event>;
export type EventList = Event[];
export declare const EventList: any;
export interface DescribeEventsResponse {
    Marker?: string;
    Events?: Event[];
}
export declare const DescribeEventsResponse: S.Schema<DescribeEventsResponse>;
export interface DescribeEventSubscriptionsMessage {
    SubscriptionName?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeEventSubscriptionsMessage: S.Schema<DescribeEventSubscriptionsMessage>;
export type EventSubscriptionsList = EventSubscription[];
export declare const EventSubscriptionsList: any;
export interface DescribeEventSubscriptionsResponse {
    Marker?: string;
    EventSubscriptionsList?: EventSubscription[];
}
export declare const DescribeEventSubscriptionsResponse: S.Schema<DescribeEventSubscriptionsResponse>;
export interface DescribeExtensionPackAssociationsMessage {
    MigrationProjectIdentifier: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export declare const DescribeExtensionPackAssociationsMessage: S.Schema<DescribeExtensionPackAssociationsMessage>;
export type SchemaConversionRequestList = SchemaConversionRequest[];
export declare const SchemaConversionRequestList: any;
export interface DescribeExtensionPackAssociationsResponse {
    Marker?: string;
    Requests?: SchemaConversionRequest[];
}
export declare const DescribeExtensionPackAssociationsResponse: S.Schema<DescribeExtensionPackAssociationsResponse>;
export interface DescribeFleetAdvisorCollectorsRequest {
    Filters?: Filter[];
    MaxRecords?: number;
    NextToken?: string;
}
export declare const DescribeFleetAdvisorCollectorsRequest: S.Schema<DescribeFleetAdvisorCollectorsRequest>;
export type VersionStatus = "UP_TO_DATE" | "OUTDATED" | "UNSUPPORTED" | (string & {});
export declare const VersionStatus: any;
export type CollectorStatus = "UNREGISTERED" | "ACTIVE" | (string & {});
export declare const CollectorStatus: any;
export interface CollectorHealthCheck {
    CollectorStatus?: CollectorStatus;
    LocalCollectorS3Access?: boolean;
    WebCollectorS3Access?: boolean;
    WebCollectorGrantedRoleBasedAccess?: boolean;
}
export declare const CollectorHealthCheck: S.Schema<CollectorHealthCheck>;
export interface InventoryData {
    NumberOfDatabases?: number;
    NumberOfSchemas?: number;
}
export declare const InventoryData: S.Schema<InventoryData>;
export interface CollectorResponse {
    CollectorReferencedId?: string;
    CollectorName?: string;
    CollectorVersion?: string;
    VersionStatus?: VersionStatus;
    Description?: string;
    S3BucketName?: string;
    ServiceAccessRoleArn?: string;
    CollectorHealthCheck?: CollectorHealthCheck;
    LastDataReceived?: string;
    RegisteredDate?: string;
    CreatedDate?: string;
    ModifiedDate?: string;
    InventoryData?: InventoryData;
}
export declare const CollectorResponse: S.Schema<CollectorResponse>;
export type CollectorResponses = CollectorResponse[];
export declare const CollectorResponses: any;
export interface DescribeFleetAdvisorCollectorsResponse {
    Collectors?: CollectorResponse[];
    NextToken?: string;
}
export declare const DescribeFleetAdvisorCollectorsResponse: S.Schema<DescribeFleetAdvisorCollectorsResponse>;
export interface DescribeFleetAdvisorDatabasesRequest {
    Filters?: Filter[];
    MaxRecords?: number;
    NextToken?: string;
}
export declare const DescribeFleetAdvisorDatabasesRequest: S.Schema<DescribeFleetAdvisorDatabasesRequest>;
export interface ServerShortInfoResponse {
    ServerId?: string;
    IpAddress?: string;
    ServerName?: string;
}
export declare const ServerShortInfoResponse: S.Schema<ServerShortInfoResponse>;
export interface DatabaseInstanceSoftwareDetailsResponse {
    Engine?: string;
    EngineVersion?: string;
    EngineEdition?: string;
    ServicePack?: string;
    SupportLevel?: string;
    OsArchitecture?: number;
    Tooltip?: string;
}
export declare const DatabaseInstanceSoftwareDetailsResponse: S.Schema<DatabaseInstanceSoftwareDetailsResponse>;
export interface CollectorShortInfoResponse {
    CollectorReferencedId?: string;
    CollectorName?: string;
}
export declare const CollectorShortInfoResponse: S.Schema<CollectorShortInfoResponse>;
export type CollectorsList = CollectorShortInfoResponse[];
export declare const CollectorsList: any;
export interface DatabaseResponse {
    DatabaseId?: string;
    DatabaseName?: string;
    IpAddress?: string;
    NumberOfSchemas?: number;
    Server?: ServerShortInfoResponse;
    SoftwareDetails?: DatabaseInstanceSoftwareDetailsResponse;
    Collectors?: CollectorShortInfoResponse[];
}
export declare const DatabaseResponse: S.Schema<DatabaseResponse>;
export type DatabaseList = DatabaseResponse[];
export declare const DatabaseList: any;
export interface DescribeFleetAdvisorDatabasesResponse {
    Databases?: DatabaseResponse[];
    NextToken?: string;
}
export declare const DescribeFleetAdvisorDatabasesResponse: S.Schema<DescribeFleetAdvisorDatabasesResponse>;
export interface DescribeFleetAdvisorLsaAnalysisRequest {
    MaxRecords?: number;
    NextToken?: string;
}
export declare const DescribeFleetAdvisorLsaAnalysisRequest: S.Schema<DescribeFleetAdvisorLsaAnalysisRequest>;
export interface FleetAdvisorLsaAnalysisResponse {
    LsaAnalysisId?: string;
    Status?: string;
}
export declare const FleetAdvisorLsaAnalysisResponse: S.Schema<FleetAdvisorLsaAnalysisResponse>;
export type FleetAdvisorLsaAnalysisResponseList = FleetAdvisorLsaAnalysisResponse[];
export declare const FleetAdvisorLsaAnalysisResponseList: any;
export interface DescribeFleetAdvisorLsaAnalysisResponse {
    Analysis?: FleetAdvisorLsaAnalysisResponse[];
    NextToken?: string;
}
export declare const DescribeFleetAdvisorLsaAnalysisResponse: S.Schema<DescribeFleetAdvisorLsaAnalysisResponse>;
export interface DescribeFleetAdvisorSchemaObjectSummaryRequest {
    Filters?: Filter[];
    MaxRecords?: number;
    NextToken?: string;
}
export declare const DescribeFleetAdvisorSchemaObjectSummaryRequest: S.Schema<DescribeFleetAdvisorSchemaObjectSummaryRequest>;
export interface FleetAdvisorSchemaObjectResponse {
    SchemaId?: string;
    ObjectType?: string;
    NumberOfObjects?: number;
    CodeLineCount?: number;
    CodeSize?: number;
}
export declare const FleetAdvisorSchemaObjectResponse: S.Schema<FleetAdvisorSchemaObjectResponse>;
export type FleetAdvisorSchemaObjectList = FleetAdvisorSchemaObjectResponse[];
export declare const FleetAdvisorSchemaObjectList: any;
export interface DescribeFleetAdvisorSchemaObjectSummaryResponse {
    FleetAdvisorSchemaObjects?: FleetAdvisorSchemaObjectResponse[];
    NextToken?: string;
}
export declare const DescribeFleetAdvisorSchemaObjectSummaryResponse: S.Schema<DescribeFleetAdvisorSchemaObjectSummaryResponse>;
export interface DescribeFleetAdvisorSchemasRequest {
    Filters?: Filter[];
    MaxRecords?: number;
    NextToken?: string;
}
export declare const DescribeFleetAdvisorSchemasRequest: S.Schema<DescribeFleetAdvisorSchemasRequest>;
export interface DatabaseShortInfoResponse {
    DatabaseId?: string;
    DatabaseName?: string;
    DatabaseIpAddress?: string;
    DatabaseEngine?: string;
}
export declare const DatabaseShortInfoResponse: S.Schema<DatabaseShortInfoResponse>;
export interface SchemaShortInfoResponse {
    SchemaId?: string;
    SchemaName?: string;
    DatabaseId?: string;
    DatabaseName?: string;
    DatabaseIpAddress?: string;
}
export declare const SchemaShortInfoResponse: S.Schema<SchemaShortInfoResponse>;
export interface SchemaResponse {
    CodeLineCount?: number;
    CodeSize?: number;
    Complexity?: string;
    Server?: ServerShortInfoResponse;
    DatabaseInstance?: DatabaseShortInfoResponse;
    SchemaId?: string;
    SchemaName?: string;
    OriginalSchema?: SchemaShortInfoResponse;
    Similarity?: number;
}
export declare const SchemaResponse: S.Schema<SchemaResponse>;
export type FleetAdvisorSchemaList = SchemaResponse[];
export declare const FleetAdvisorSchemaList: any;
export interface DescribeFleetAdvisorSchemasResponse {
    FleetAdvisorSchemas?: SchemaResponse[];
    NextToken?: string;
}
export declare const DescribeFleetAdvisorSchemasResponse: S.Schema<DescribeFleetAdvisorSchemasResponse>;
export interface DescribeInstanceProfilesMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeInstanceProfilesMessage: S.Schema<DescribeInstanceProfilesMessage>;
export type InstanceProfileList = InstanceProfile[];
export declare const InstanceProfileList: any;
export interface DescribeInstanceProfilesResponse {
    Marker?: string;
    InstanceProfiles?: InstanceProfile[];
}
export declare const DescribeInstanceProfilesResponse: S.Schema<DescribeInstanceProfilesResponse>;
export type OriginTypeValue = "SOURCE" | "TARGET" | (string & {});
export declare const OriginTypeValue: any;
export interface DescribeMetadataModelMessage {
    SelectionRules: string;
    MigrationProjectIdentifier: string;
    Origin: OriginTypeValue;
}
export declare const DescribeMetadataModelMessage: S.Schema<DescribeMetadataModelMessage>;
export interface MetadataModelReference {
    MetadataModelName?: string;
    SelectionRules?: string;
}
export declare const MetadataModelReference: S.Schema<MetadataModelReference>;
export type MetadataModelReferenceList = MetadataModelReference[];
export declare const MetadataModelReferenceList: any;
export interface DescribeMetadataModelResponse {
    MetadataModelName?: string;
    MetadataModelType?: string;
    TargetMetadataModels?: MetadataModelReference[];
    Definition?: string;
}
export declare const DescribeMetadataModelResponse: S.Schema<DescribeMetadataModelResponse>;
export interface DescribeMetadataModelAssessmentsMessage {
    MigrationProjectIdentifier: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export declare const DescribeMetadataModelAssessmentsMessage: S.Schema<DescribeMetadataModelAssessmentsMessage>;
export interface DescribeMetadataModelAssessmentsResponse {
    Marker?: string;
    Requests?: SchemaConversionRequest[];
}
export declare const DescribeMetadataModelAssessmentsResponse: S.Schema<DescribeMetadataModelAssessmentsResponse>;
export interface DescribeMetadataModelChildrenMessage {
    SelectionRules: string;
    MigrationProjectIdentifier: string;
    Origin: OriginTypeValue;
    Marker?: string;
    MaxRecords?: number;
}
export declare const DescribeMetadataModelChildrenMessage: S.Schema<DescribeMetadataModelChildrenMessage>;
export interface DescribeMetadataModelChildrenResponse {
    Marker?: string;
    MetadataModelChildren?: MetadataModelReference[];
}
export declare const DescribeMetadataModelChildrenResponse: S.Schema<DescribeMetadataModelChildrenResponse>;
export interface DescribeMetadataModelConversionsMessage {
    MigrationProjectIdentifier: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export declare const DescribeMetadataModelConversionsMessage: S.Schema<DescribeMetadataModelConversionsMessage>;
export interface DescribeMetadataModelConversionsResponse {
    Marker?: string;
    Requests?: SchemaConversionRequest[];
}
export declare const DescribeMetadataModelConversionsResponse: S.Schema<DescribeMetadataModelConversionsResponse>;
export interface DescribeMetadataModelCreationsMessage {
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
    MigrationProjectIdentifier: string;
}
export declare const DescribeMetadataModelCreationsMessage: S.Schema<DescribeMetadataModelCreationsMessage>;
export interface DescribeMetadataModelCreationsResponse {
    Marker?: string;
    Requests?: SchemaConversionRequest[];
}
export declare const DescribeMetadataModelCreationsResponse: S.Schema<DescribeMetadataModelCreationsResponse>;
export interface DescribeMetadataModelExportsAsScriptMessage {
    MigrationProjectIdentifier: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export declare const DescribeMetadataModelExportsAsScriptMessage: S.Schema<DescribeMetadataModelExportsAsScriptMessage>;
export interface DescribeMetadataModelExportsAsScriptResponse {
    Marker?: string;
    Requests?: SchemaConversionRequest[];
}
export declare const DescribeMetadataModelExportsAsScriptResponse: S.Schema<DescribeMetadataModelExportsAsScriptResponse>;
export interface DescribeMetadataModelExportsToTargetMessage {
    MigrationProjectIdentifier: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export declare const DescribeMetadataModelExportsToTargetMessage: S.Schema<DescribeMetadataModelExportsToTargetMessage>;
export interface DescribeMetadataModelExportsToTargetResponse {
    Marker?: string;
    Requests?: SchemaConversionRequest[];
}
export declare const DescribeMetadataModelExportsToTargetResponse: S.Schema<DescribeMetadataModelExportsToTargetResponse>;
export interface DescribeMetadataModelImportsMessage {
    MigrationProjectIdentifier: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export declare const DescribeMetadataModelImportsMessage: S.Schema<DescribeMetadataModelImportsMessage>;
export interface DescribeMetadataModelImportsResponse {
    Marker?: string;
    Requests?: SchemaConversionRequest[];
}
export declare const DescribeMetadataModelImportsResponse: S.Schema<DescribeMetadataModelImportsResponse>;
export interface DescribeMigrationProjectsMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeMigrationProjectsMessage: S.Schema<DescribeMigrationProjectsMessage>;
export type MigrationProjectList = MigrationProject[];
export declare const MigrationProjectList: any;
export interface DescribeMigrationProjectsResponse {
    Marker?: string;
    MigrationProjects?: MigrationProject[];
}
export declare const DescribeMigrationProjectsResponse: S.Schema<DescribeMigrationProjectsResponse>;
export interface DescribeOrderableReplicationInstancesMessage {
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeOrderableReplicationInstancesMessage: S.Schema<DescribeOrderableReplicationInstancesMessage>;
export type AvailabilityZonesList = string[];
export declare const AvailabilityZonesList: any;
export interface OrderableReplicationInstance {
    EngineVersion?: string;
    ReplicationInstanceClass?: string;
    StorageType?: string;
    MinAllocatedStorage?: number;
    MaxAllocatedStorage?: number;
    DefaultAllocatedStorage?: number;
    IncludedAllocatedStorage?: number;
    AvailabilityZones?: string[];
    ReleaseStatus?: ReleaseStatusValues;
}
export declare const OrderableReplicationInstance: S.Schema<OrderableReplicationInstance>;
export type OrderableReplicationInstanceList = OrderableReplicationInstance[];
export declare const OrderableReplicationInstanceList: any;
export interface DescribeOrderableReplicationInstancesResponse {
    OrderableReplicationInstances?: OrderableReplicationInstance[];
    Marker?: string;
}
export declare const DescribeOrderableReplicationInstancesResponse: S.Schema<DescribeOrderableReplicationInstancesResponse>;
export interface DescribePendingMaintenanceActionsMessage {
    ReplicationInstanceArn?: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export declare const DescribePendingMaintenanceActionsMessage: S.Schema<DescribePendingMaintenanceActionsMessage>;
export type PendingMaintenanceActions = ResourcePendingMaintenanceActions[];
export declare const PendingMaintenanceActions: any;
export interface DescribePendingMaintenanceActionsResponse {
    PendingMaintenanceActions?: ResourcePendingMaintenanceActions[];
    Marker?: string;
}
export declare const DescribePendingMaintenanceActionsResponse: S.Schema<DescribePendingMaintenanceActionsResponse>;
export interface DescribeRecommendationLimitationsRequest {
    Filters?: Filter[];
    MaxRecords?: number;
    NextToken?: string;
}
export declare const DescribeRecommendationLimitationsRequest: S.Schema<DescribeRecommendationLimitationsRequest>;
export interface Limitation {
    DatabaseId?: string;
    EngineName?: string;
    Name?: string;
    Description?: string;
    Impact?: string;
    Type?: string;
}
export declare const Limitation: S.Schema<Limitation>;
export type LimitationList = Limitation[];
export declare const LimitationList: any;
export interface DescribeRecommendationLimitationsResponse {
    NextToken?: string;
    Limitations?: Limitation[];
}
export declare const DescribeRecommendationLimitationsResponse: S.Schema<DescribeRecommendationLimitationsResponse>;
export interface DescribeRecommendationsRequest {
    Filters?: Filter[];
    MaxRecords?: number;
    NextToken?: string;
}
export declare const DescribeRecommendationsRequest: S.Schema<DescribeRecommendationsRequest>;
export interface RdsRequirements {
    EngineEdition?: string;
    InstanceVcpu?: number;
    InstanceMemory?: number;
    StorageSize?: number;
    StorageIops?: number;
    DeploymentOption?: string;
    EngineVersion?: string;
}
export declare const RdsRequirements: S.Schema<RdsRequirements>;
export interface RdsConfiguration {
    EngineEdition?: string;
    InstanceType?: string;
    InstanceVcpu?: number;
    InstanceMemory?: number;
    StorageType?: string;
    StorageSize?: number;
    StorageIops?: number;
    DeploymentOption?: string;
    EngineVersion?: string;
}
export declare const RdsConfiguration: S.Schema<RdsConfiguration>;
export interface RdsRecommendation {
    RequirementsToTarget?: RdsRequirements;
    TargetConfiguration?: RdsConfiguration;
}
export declare const RdsRecommendation: S.Schema<RdsRecommendation>;
export interface RecommendationData {
    RdsEngine?: RdsRecommendation;
}
export declare const RecommendationData: S.Schema<RecommendationData>;
export interface Recommendation {
    DatabaseId?: string;
    EngineName?: string;
    CreatedDate?: string;
    Status?: string;
    Preferred?: boolean;
    Settings?: RecommendationSettings;
    Data?: RecommendationData;
}
export declare const Recommendation: S.Schema<Recommendation>;
export type RecommendationList = Recommendation[];
export declare const RecommendationList: any;
export interface DescribeRecommendationsResponse {
    NextToken?: string;
    Recommendations?: Recommendation[];
}
export declare const DescribeRecommendationsResponse: S.Schema<DescribeRecommendationsResponse>;
export interface DescribeRefreshSchemasStatusMessage {
    EndpointArn: string;
}
export declare const DescribeRefreshSchemasStatusMessage: S.Schema<DescribeRefreshSchemasStatusMessage>;
export type RefreshSchemasStatusTypeValue = "successful" | "failed" | "refreshing" | (string & {});
export declare const RefreshSchemasStatusTypeValue: any;
export interface RefreshSchemasStatus {
    EndpointArn?: string;
    ReplicationInstanceArn?: string;
    Status?: RefreshSchemasStatusTypeValue;
    LastRefreshDate?: Date;
    LastFailureMessage?: string;
}
export declare const RefreshSchemasStatus: S.Schema<RefreshSchemasStatus>;
export interface DescribeRefreshSchemasStatusResponse {
    RefreshSchemasStatus?: RefreshSchemasStatus;
}
export declare const DescribeRefreshSchemasStatusResponse: S.Schema<DescribeRefreshSchemasStatusResponse>;
export interface DescribeReplicationConfigsMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeReplicationConfigsMessage: S.Schema<DescribeReplicationConfigsMessage>;
export type ReplicationConfigList = ReplicationConfig[];
export declare const ReplicationConfigList: any;
export interface DescribeReplicationConfigsResponse {
    Marker?: string;
    ReplicationConfigs?: ReplicationConfig[];
}
export declare const DescribeReplicationConfigsResponse: S.Schema<DescribeReplicationConfigsResponse>;
export interface DescribeReplicationInstancesMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeReplicationInstancesMessage: S.Schema<DescribeReplicationInstancesMessage>;
export type ReplicationInstanceList = ReplicationInstance[];
export declare const ReplicationInstanceList: any;
export interface DescribeReplicationInstancesResponse {
    Marker?: string;
    ReplicationInstances?: ReplicationInstance[];
}
export declare const DescribeReplicationInstancesResponse: S.Schema<DescribeReplicationInstancesResponse>;
export interface DescribeReplicationInstanceTaskLogsMessage {
    ReplicationInstanceArn: string;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeReplicationInstanceTaskLogsMessage: S.Schema<DescribeReplicationInstanceTaskLogsMessage>;
export interface ReplicationInstanceTaskLog {
    ReplicationTaskName?: string;
    ReplicationTaskArn?: string;
    ReplicationInstanceTaskLogSize?: number;
}
export declare const ReplicationInstanceTaskLog: S.Schema<ReplicationInstanceTaskLog>;
export type ReplicationInstanceTaskLogsList = ReplicationInstanceTaskLog[];
export declare const ReplicationInstanceTaskLogsList: any;
export interface DescribeReplicationInstanceTaskLogsResponse {
    ReplicationInstanceArn?: string;
    ReplicationInstanceTaskLogs?: ReplicationInstanceTaskLog[];
    Marker?: string;
}
export declare const DescribeReplicationInstanceTaskLogsResponse: S.Schema<DescribeReplicationInstanceTaskLogsResponse>;
export interface DescribeReplicationsMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeReplicationsMessage: S.Schema<DescribeReplicationsMessage>;
export interface ProvisionData {
    ProvisionState?: string;
    ProvisionedCapacityUnits?: number;
    DateProvisioned?: Date;
    IsNewProvisioningAvailable?: boolean;
    DateNewProvisioningDataAvailable?: Date;
    ReasonForNewProvisioningData?: string;
}
export declare const ProvisionData: S.Schema<ProvisionData>;
export interface PremigrationAssessmentStatus {
    PremigrationAssessmentRunArn?: string;
    FailOnAssessmentFailure?: boolean;
    Status?: string;
    PremigrationAssessmentRunCreationDate?: Date;
    AssessmentProgress?: ReplicationTaskAssessmentRunProgress;
    LastFailureMessage?: string;
    ResultLocationBucket?: string;
    ResultLocationFolder?: string;
    ResultEncryptionMode?: string;
    ResultKmsKeyArn?: string;
    ResultStatistic?: ReplicationTaskAssessmentRunResultStatistic;
}
export declare const PremigrationAssessmentStatus: S.Schema<PremigrationAssessmentStatus>;
export type PremigrationAssessmentStatusList = PremigrationAssessmentStatus[];
export declare const PremigrationAssessmentStatusList: any;
export interface ReplicationStats {
    FullLoadProgressPercent?: number;
    ElapsedTimeMillis?: number;
    TablesLoaded?: number;
    TablesLoading?: number;
    TablesQueued?: number;
    TablesErrored?: number;
    FreshStartDate?: Date;
    StartDate?: Date;
    StopDate?: Date;
    FullLoadStartDate?: Date;
    FullLoadFinishDate?: Date;
}
export declare const ReplicationStats: S.Schema<ReplicationStats>;
export interface Replication {
    ReplicationConfigIdentifier?: string;
    ReplicationConfigArn?: string;
    SourceEndpointArn?: string;
    TargetEndpointArn?: string;
    ReplicationType?: MigrationTypeValue;
    Status?: string;
    ProvisionData?: ProvisionData;
    PremigrationAssessmentStatuses?: PremigrationAssessmentStatus[];
    StopReason?: string;
    FailureMessages?: string[];
    ReplicationStats?: ReplicationStats;
    StartReplicationType?: string;
    CdcStartTime?: Date;
    CdcStartPosition?: string;
    CdcStopPosition?: string;
    RecoveryCheckpoint?: string;
    ReplicationCreateTime?: Date;
    ReplicationUpdateTime?: Date;
    ReplicationLastStopTime?: Date;
    ReplicationDeprovisionTime?: Date;
    IsReadOnly?: boolean;
}
export declare const Replication: S.Schema<Replication>;
export type ReplicationList = Replication[];
export declare const ReplicationList: any;
export interface DescribeReplicationsResponse {
    Marker?: string;
    Replications?: Replication[];
}
export declare const DescribeReplicationsResponse: S.Schema<DescribeReplicationsResponse>;
export interface DescribeReplicationSubnetGroupsMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeReplicationSubnetGroupsMessage: S.Schema<DescribeReplicationSubnetGroupsMessage>;
export type ReplicationSubnetGroups = ReplicationSubnetGroup[];
export declare const ReplicationSubnetGroups: any;
export interface DescribeReplicationSubnetGroupsResponse {
    Marker?: string;
    ReplicationSubnetGroups?: ReplicationSubnetGroup[];
}
export declare const DescribeReplicationSubnetGroupsResponse: S.Schema<DescribeReplicationSubnetGroupsResponse>;
export interface DescribeReplicationTableStatisticsMessage {
    ReplicationConfigArn: string;
    MaxRecords?: number;
    Marker?: string;
    Filters?: Filter[];
}
export declare const DescribeReplicationTableStatisticsMessage: S.Schema<DescribeReplicationTableStatisticsMessage>;
export interface TableStatistics {
    SchemaName?: string;
    TableName?: string;
    Inserts?: number;
    Deletes?: number;
    Updates?: number;
    Ddls?: number;
    AppliedInserts?: number;
    AppliedDeletes?: number;
    AppliedUpdates?: number;
    AppliedDdls?: number;
    FullLoadRows?: number;
    FullLoadCondtnlChkFailedRows?: number;
    FullLoadErrorRows?: number;
    FullLoadStartTime?: Date;
    FullLoadEndTime?: Date;
    FullLoadReloaded?: boolean;
    LastUpdateTime?: Date;
    TableState?: string;
    ValidationPendingRecords?: number;
    ValidationFailedRecords?: number;
    ValidationSuspendedRecords?: number;
    ValidationState?: string;
    ValidationStateDetails?: string;
    ResyncState?: string;
    ResyncRowsAttempted?: number;
    ResyncRowsSucceeded?: number;
    ResyncRowsFailed?: number;
    ResyncProgress?: number;
}
export declare const TableStatistics: S.Schema<TableStatistics>;
export type ReplicationTableStatisticsList = TableStatistics[];
export declare const ReplicationTableStatisticsList: any;
export interface DescribeReplicationTableStatisticsResponse {
    ReplicationConfigArn?: string;
    Marker?: string;
    ReplicationTableStatistics?: TableStatistics[];
}
export declare const DescribeReplicationTableStatisticsResponse: S.Schema<DescribeReplicationTableStatisticsResponse>;
export interface DescribeReplicationTaskAssessmentResultsMessage {
    ReplicationTaskArn?: string;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeReplicationTaskAssessmentResultsMessage: S.Schema<DescribeReplicationTaskAssessmentResultsMessage>;
export interface ReplicationTaskAssessmentResult {
    ReplicationTaskIdentifier?: string;
    ReplicationTaskArn?: string;
    ReplicationTaskLastAssessmentDate?: Date;
    AssessmentStatus?: string;
    AssessmentResultsFile?: string;
    AssessmentResults?: string;
    S3ObjectUrl?: string | redacted.Redacted<string>;
}
export declare const ReplicationTaskAssessmentResult: S.Schema<ReplicationTaskAssessmentResult>;
export type ReplicationTaskAssessmentResultList = ReplicationTaskAssessmentResult[];
export declare const ReplicationTaskAssessmentResultList: any;
export interface DescribeReplicationTaskAssessmentResultsResponse {
    Marker?: string;
    BucketName?: string;
    ReplicationTaskAssessmentResults?: ReplicationTaskAssessmentResult[];
}
export declare const DescribeReplicationTaskAssessmentResultsResponse: S.Schema<DescribeReplicationTaskAssessmentResultsResponse>;
export interface DescribeReplicationTaskAssessmentRunsMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeReplicationTaskAssessmentRunsMessage: S.Schema<DescribeReplicationTaskAssessmentRunsMessage>;
export type ReplicationTaskAssessmentRunList = ReplicationTaskAssessmentRun[];
export declare const ReplicationTaskAssessmentRunList: any;
export interface DescribeReplicationTaskAssessmentRunsResponse {
    Marker?: string;
    ReplicationTaskAssessmentRuns?: ReplicationTaskAssessmentRun[];
}
export declare const DescribeReplicationTaskAssessmentRunsResponse: S.Schema<DescribeReplicationTaskAssessmentRunsResponse>;
export interface DescribeReplicationTaskIndividualAssessmentsMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeReplicationTaskIndividualAssessmentsMessage: S.Schema<DescribeReplicationTaskIndividualAssessmentsMessage>;
export interface ReplicationTaskIndividualAssessment {
    ReplicationTaskIndividualAssessmentArn?: string;
    ReplicationTaskAssessmentRunArn?: string;
    IndividualAssessmentName?: string;
    Status?: string;
    ReplicationTaskIndividualAssessmentStartDate?: Date;
}
export declare const ReplicationTaskIndividualAssessment: S.Schema<ReplicationTaskIndividualAssessment>;
export type ReplicationTaskIndividualAssessmentList = ReplicationTaskIndividualAssessment[];
export declare const ReplicationTaskIndividualAssessmentList: any;
export interface DescribeReplicationTaskIndividualAssessmentsResponse {
    Marker?: string;
    ReplicationTaskIndividualAssessments?: ReplicationTaskIndividualAssessment[];
}
export declare const DescribeReplicationTaskIndividualAssessmentsResponse: S.Schema<DescribeReplicationTaskIndividualAssessmentsResponse>;
export interface DescribeReplicationTasksMessage {
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
    WithoutSettings?: boolean;
}
export declare const DescribeReplicationTasksMessage: S.Schema<DescribeReplicationTasksMessage>;
export type ReplicationTaskList = ReplicationTask[];
export declare const ReplicationTaskList: any;
export interface DescribeReplicationTasksResponse {
    Marker?: string;
    ReplicationTasks?: ReplicationTask[];
}
export declare const DescribeReplicationTasksResponse: S.Schema<DescribeReplicationTasksResponse>;
export interface DescribeSchemasMessage {
    EndpointArn: string;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeSchemasMessage: S.Schema<DescribeSchemasMessage>;
export type SchemaList = string[];
export declare const SchemaList: any;
export interface DescribeSchemasResponse {
    Marker?: string;
    Schemas?: string[];
}
export declare const DescribeSchemasResponse: S.Schema<DescribeSchemasResponse>;
export interface DescribeTableStatisticsMessage {
    ReplicationTaskArn: string;
    MaxRecords?: number;
    Marker?: string;
    Filters?: Filter[];
}
export declare const DescribeTableStatisticsMessage: S.Schema<DescribeTableStatisticsMessage>;
export type TableStatisticsList = TableStatistics[];
export declare const TableStatisticsList: any;
export interface DescribeTableStatisticsResponse {
    ReplicationTaskArn?: string;
    TableStatistics?: TableStatistics[];
    Marker?: string;
}
export declare const DescribeTableStatisticsResponse: S.Schema<DescribeTableStatisticsResponse>;
export type AssessmentReportType = "pdf" | "csv" | (string & {});
export declare const AssessmentReportType: any;
export type AssessmentReportTypesList = AssessmentReportType[];
export declare const AssessmentReportTypesList: any;
export interface ExportMetadataModelAssessmentMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
    FileName?: string;
    AssessmentReportTypes?: AssessmentReportType[];
}
export declare const ExportMetadataModelAssessmentMessage: S.Schema<ExportMetadataModelAssessmentMessage>;
export interface ExportMetadataModelAssessmentResultEntry {
    S3ObjectKey?: string;
    ObjectURL?: string;
}
export declare const ExportMetadataModelAssessmentResultEntry: S.Schema<ExportMetadataModelAssessmentResultEntry>;
export interface ExportMetadataModelAssessmentResponse {
    PdfReport?: ExportMetadataModelAssessmentResultEntry;
    CsvReport?: ExportMetadataModelAssessmentResultEntry;
}
export declare const ExportMetadataModelAssessmentResponse: S.Schema<ExportMetadataModelAssessmentResponse>;
export interface GetTargetSelectionRulesMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
}
export declare const GetTargetSelectionRulesMessage: S.Schema<GetTargetSelectionRulesMessage>;
export interface GetTargetSelectionRulesResponse {
    TargetSelectionRules?: string;
}
export declare const GetTargetSelectionRulesResponse: S.Schema<GetTargetSelectionRulesResponse>;
export interface ImportCertificateMessage {
    CertificateIdentifier: string;
    CertificatePem?: string | redacted.Redacted<string>;
    CertificateWallet?: Uint8Array;
    Tags?: Tag[];
    KmsKeyId?: string;
}
export declare const ImportCertificateMessage: S.Schema<ImportCertificateMessage>;
export interface ImportCertificateResponse {
    Certificate?: Certificate;
}
export declare const ImportCertificateResponse: S.Schema<ImportCertificateResponse>;
export type ArnList = string[];
export declare const ArnList: any;
export interface ListTagsForResourceMessage {
    ResourceArn?: string;
    ResourceArnList?: string[];
}
export declare const ListTagsForResourceMessage: S.Schema<ListTagsForResourceMessage>;
export interface ListTagsForResourceResponse {
    TagList?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ModifyConversionConfigurationMessage {
    MigrationProjectIdentifier: string;
    ConversionConfiguration: string;
}
export declare const ModifyConversionConfigurationMessage: S.Schema<ModifyConversionConfigurationMessage>;
export interface ModifyConversionConfigurationResponse {
    MigrationProjectIdentifier?: string;
}
export declare const ModifyConversionConfigurationResponse: S.Schema<ModifyConversionConfigurationResponse>;
export interface ModifyDataMigrationMessage {
    DataMigrationIdentifier: string;
    DataMigrationName?: string;
    EnableCloudwatchLogs?: boolean;
    ServiceAccessRoleArn?: string;
    DataMigrationType?: MigrationTypeValue;
    SourceDataSettings?: SourceDataSetting[];
    TargetDataSettings?: TargetDataSetting[];
    NumberOfJobs?: number;
    SelectionRules?: string | redacted.Redacted<string>;
}
export declare const ModifyDataMigrationMessage: S.Schema<ModifyDataMigrationMessage>;
export interface ModifyDataMigrationResponse {
    DataMigration?: DataMigration;
}
export declare const ModifyDataMigrationResponse: S.Schema<ModifyDataMigrationResponse>;
export interface ModifyDataProviderMessage {
    DataProviderIdentifier: string;
    DataProviderName?: string;
    Description?: string;
    Engine?: string;
    Virtual?: boolean;
    ExactSettings?: boolean;
    Settings?: DataProviderSettings;
}
export declare const ModifyDataProviderMessage: S.Schema<ModifyDataProviderMessage>;
export interface ModifyDataProviderResponse {
    DataProvider?: DataProvider;
}
export declare const ModifyDataProviderResponse: S.Schema<ModifyDataProviderResponse>;
export interface ModifyEndpointMessage {
    EndpointArn: string;
    EndpointIdentifier?: string;
    EndpointType?: ReplicationEndpointTypeValue;
    EngineName?: string;
    Username?: string;
    Password?: string | redacted.Redacted<string>;
    ServerName?: string;
    Port?: number;
    DatabaseName?: string;
    ExtraConnectionAttributes?: string;
    CertificateArn?: string;
    SslMode?: DmsSslModeValue;
    ServiceAccessRoleArn?: string;
    ExternalTableDefinition?: string;
    DynamoDbSettings?: DynamoDbSettings;
    S3Settings?: S3Settings;
    DmsTransferSettings?: DmsTransferSettings;
    MongoDbSettings?: MongoDbSettings;
    KinesisSettings?: KinesisSettings;
    KafkaSettings?: KafkaSettings;
    ElasticsearchSettings?: ElasticsearchSettings;
    NeptuneSettings?: NeptuneSettings;
    RedshiftSettings?: RedshiftSettings;
    PostgreSQLSettings?: PostgreSQLSettings;
    MySQLSettings?: MySQLSettings;
    OracleSettings?: OracleSettings;
    SybaseSettings?: SybaseSettings;
    MicrosoftSQLServerSettings?: MicrosoftSQLServerSettings;
    IBMDb2Settings?: IBMDb2Settings;
    DocDbSettings?: DocDbSettings;
    RedisSettings?: RedisSettings;
    ExactSettings?: boolean;
    GcpMySQLSettings?: GcpMySQLSettings;
    TimestreamSettings?: TimestreamSettings;
}
export declare const ModifyEndpointMessage: S.Schema<ModifyEndpointMessage>;
export interface ModifyEndpointResponse {
    Endpoint?: Endpoint;
}
export declare const ModifyEndpointResponse: S.Schema<ModifyEndpointResponse>;
export interface ModifyEventSubscriptionMessage {
    SubscriptionName: string;
    SnsTopicArn?: string;
    SourceType?: string;
    EventCategories?: string[];
    Enabled?: boolean;
}
export declare const ModifyEventSubscriptionMessage: S.Schema<ModifyEventSubscriptionMessage>;
export interface ModifyEventSubscriptionResponse {
    EventSubscription?: EventSubscription;
}
export declare const ModifyEventSubscriptionResponse: S.Schema<ModifyEventSubscriptionResponse>;
export interface ModifyInstanceProfileMessage {
    InstanceProfileIdentifier: string;
    AvailabilityZone?: string;
    KmsKeyArn?: string;
    PubliclyAccessible?: boolean;
    NetworkType?: string;
    InstanceProfileName?: string;
    Description?: string;
    SubnetGroupIdentifier?: string;
    VpcSecurityGroups?: string[];
}
export declare const ModifyInstanceProfileMessage: S.Schema<ModifyInstanceProfileMessage>;
export interface ModifyInstanceProfileResponse {
    InstanceProfile?: InstanceProfile;
}
export declare const ModifyInstanceProfileResponse: S.Schema<ModifyInstanceProfileResponse>;
export interface ModifyMigrationProjectMessage {
    MigrationProjectIdentifier: string;
    MigrationProjectName?: string;
    SourceDataProviderDescriptors?: DataProviderDescriptorDefinition[];
    TargetDataProviderDescriptors?: DataProviderDescriptorDefinition[];
    InstanceProfileIdentifier?: string;
    TransformationRules?: string;
    Description?: string;
    SchemaConversionApplicationAttributes?: SCApplicationAttributes;
}
export declare const ModifyMigrationProjectMessage: S.Schema<ModifyMigrationProjectMessage>;
export interface ModifyMigrationProjectResponse {
    MigrationProject?: MigrationProject;
}
export declare const ModifyMigrationProjectResponse: S.Schema<ModifyMigrationProjectResponse>;
export interface ModifyReplicationConfigMessage {
    ReplicationConfigArn: string;
    ReplicationConfigIdentifier?: string;
    ReplicationType?: MigrationTypeValue;
    TableMappings?: string;
    ReplicationSettings?: string;
    SupplementalSettings?: string;
    ComputeConfig?: ComputeConfig;
    SourceEndpointArn?: string;
    TargetEndpointArn?: string;
}
export declare const ModifyReplicationConfigMessage: S.Schema<ModifyReplicationConfigMessage>;
export interface ModifyReplicationConfigResponse {
    ReplicationConfig?: ReplicationConfig;
}
export declare const ModifyReplicationConfigResponse: S.Schema<ModifyReplicationConfigResponse>;
export interface ModifyReplicationInstanceMessage {
    ReplicationInstanceArn: string;
    AllocatedStorage?: number;
    ApplyImmediately?: boolean;
    ReplicationInstanceClass?: string;
    VpcSecurityGroupIds?: string[];
    PreferredMaintenanceWindow?: string;
    MultiAZ?: boolean;
    EngineVersion?: string;
    AllowMajorVersionUpgrade?: boolean;
    AutoMinorVersionUpgrade?: boolean;
    ReplicationInstanceIdentifier?: string;
    NetworkType?: string;
    KerberosAuthenticationSettings?: KerberosAuthenticationSettings;
}
export declare const ModifyReplicationInstanceMessage: S.Schema<ModifyReplicationInstanceMessage>;
export interface ModifyReplicationInstanceResponse {
    ReplicationInstance?: ReplicationInstance;
}
export declare const ModifyReplicationInstanceResponse: S.Schema<ModifyReplicationInstanceResponse>;
export interface ModifyReplicationSubnetGroupMessage {
    ReplicationSubnetGroupIdentifier: string;
    ReplicationSubnetGroupDescription?: string;
    SubnetIds: string[];
}
export declare const ModifyReplicationSubnetGroupMessage: S.Schema<ModifyReplicationSubnetGroupMessage>;
export interface ModifyReplicationSubnetGroupResponse {
    ReplicationSubnetGroup?: ReplicationSubnetGroup;
}
export declare const ModifyReplicationSubnetGroupResponse: S.Schema<ModifyReplicationSubnetGroupResponse>;
export interface ModifyReplicationTaskMessage {
    ReplicationTaskArn: string;
    ReplicationTaskIdentifier?: string;
    MigrationType?: MigrationTypeValue;
    TableMappings?: string;
    ReplicationTaskSettings?: string;
    CdcStartTime?: Date;
    CdcStartPosition?: string;
    CdcStopPosition?: string;
    TaskData?: string;
}
export declare const ModifyReplicationTaskMessage: S.Schema<ModifyReplicationTaskMessage>;
export interface ModifyReplicationTaskResponse {
    ReplicationTask?: ReplicationTask;
}
export declare const ModifyReplicationTaskResponse: S.Schema<ModifyReplicationTaskResponse>;
export interface MoveReplicationTaskMessage {
    ReplicationTaskArn: string;
    TargetReplicationInstanceArn: string;
}
export declare const MoveReplicationTaskMessage: S.Schema<MoveReplicationTaskMessage>;
export interface MoveReplicationTaskResponse {
    ReplicationTask?: ReplicationTask;
}
export declare const MoveReplicationTaskResponse: S.Schema<MoveReplicationTaskResponse>;
export interface RebootReplicationInstanceMessage {
    ReplicationInstanceArn: string;
    ForceFailover?: boolean;
    ForcePlannedFailover?: boolean;
}
export declare const RebootReplicationInstanceMessage: S.Schema<RebootReplicationInstanceMessage>;
export interface RebootReplicationInstanceResponse {
    ReplicationInstance?: ReplicationInstance;
}
export declare const RebootReplicationInstanceResponse: S.Schema<RebootReplicationInstanceResponse>;
export interface RefreshSchemasMessage {
    EndpointArn: string;
    ReplicationInstanceArn: string;
}
export declare const RefreshSchemasMessage: S.Schema<RefreshSchemasMessage>;
export interface RefreshSchemasResponse {
    RefreshSchemasStatus?: RefreshSchemasStatus;
}
export declare const RefreshSchemasResponse: S.Schema<RefreshSchemasResponse>;
export interface TableToReload {
    SchemaName: string;
    TableName: string;
}
export declare const TableToReload: S.Schema<TableToReload>;
export type TableListToReload = TableToReload[];
export declare const TableListToReload: any;
export type ReloadOptionValue = "data-reload" | "validate-only" | (string & {});
export declare const ReloadOptionValue: any;
export interface ReloadReplicationTablesMessage {
    ReplicationConfigArn: string;
    TablesToReload: TableToReload[];
    ReloadOption?: ReloadOptionValue;
}
export declare const ReloadReplicationTablesMessage: S.Schema<ReloadReplicationTablesMessage>;
export interface ReloadReplicationTablesResponse {
    ReplicationConfigArn?: string;
}
export declare const ReloadReplicationTablesResponse: S.Schema<ReloadReplicationTablesResponse>;
export interface ReloadTablesMessage {
    ReplicationTaskArn: string;
    TablesToReload: TableToReload[];
    ReloadOption?: ReloadOptionValue;
}
export declare const ReloadTablesMessage: S.Schema<ReloadTablesMessage>;
export interface ReloadTablesResponse {
    ReplicationTaskArn?: string;
}
export declare const ReloadTablesResponse: S.Schema<ReloadTablesResponse>;
export type KeyList = string[];
export declare const KeyList: any;
export interface RemoveTagsFromResourceMessage {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const RemoveTagsFromResourceMessage: S.Schema<RemoveTagsFromResourceMessage>;
export interface RemoveTagsFromResourceResponse {
}
export declare const RemoveTagsFromResourceResponse: S.Schema<RemoveTagsFromResourceResponse>;
export interface RunFleetAdvisorLsaAnalysisRequest {
}
export declare const RunFleetAdvisorLsaAnalysisRequest: S.Schema<RunFleetAdvisorLsaAnalysisRequest>;
export interface RunFleetAdvisorLsaAnalysisResponse {
    LsaAnalysisId?: string;
    Status?: string;
}
export declare const RunFleetAdvisorLsaAnalysisResponse: S.Schema<RunFleetAdvisorLsaAnalysisResponse>;
export type StartReplicationMigrationTypeValue = "reload-target" | "resume-processing" | "start-replication" | (string & {});
export declare const StartReplicationMigrationTypeValue: any;
export interface StartDataMigrationMessage {
    DataMigrationIdentifier: string;
    StartType: StartReplicationMigrationTypeValue;
}
export declare const StartDataMigrationMessage: S.Schema<StartDataMigrationMessage>;
export interface StartDataMigrationResponse {
    DataMigration?: DataMigration;
}
export declare const StartDataMigrationResponse: S.Schema<StartDataMigrationResponse>;
export interface StartExtensionPackAssociationMessage {
    MigrationProjectIdentifier: string;
}
export declare const StartExtensionPackAssociationMessage: S.Schema<StartExtensionPackAssociationMessage>;
export interface StartExtensionPackAssociationResponse {
    RequestIdentifier?: string;
}
export declare const StartExtensionPackAssociationResponse: S.Schema<StartExtensionPackAssociationResponse>;
export interface StartMetadataModelAssessmentMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
}
export declare const StartMetadataModelAssessmentMessage: S.Schema<StartMetadataModelAssessmentMessage>;
export interface StartMetadataModelAssessmentResponse {
    RequestIdentifier?: string;
}
export declare const StartMetadataModelAssessmentResponse: S.Schema<StartMetadataModelAssessmentResponse>;
export interface StartMetadataModelConversionMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
}
export declare const StartMetadataModelConversionMessage: S.Schema<StartMetadataModelConversionMessage>;
export interface StartMetadataModelConversionResponse {
    RequestIdentifier?: string;
}
export declare const StartMetadataModelConversionResponse: S.Schema<StartMetadataModelConversionResponse>;
export interface StatementProperties {
    Definition: string;
}
export declare const StatementProperties: S.Schema<StatementProperties>;
export type MetadataModelProperties = {
    StatementProperties: StatementProperties;
};
export declare const MetadataModelProperties: any;
export interface StartMetadataModelCreationMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
    MetadataModelName: string;
    Properties: MetadataModelProperties;
}
export declare const StartMetadataModelCreationMessage: S.Schema<StartMetadataModelCreationMessage>;
export interface StartMetadataModelCreationResponse {
    RequestIdentifier?: string;
}
export declare const StartMetadataModelCreationResponse: S.Schema<StartMetadataModelCreationResponse>;
export interface StartMetadataModelExportAsScriptMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
    Origin: OriginTypeValue;
    FileName?: string;
}
export declare const StartMetadataModelExportAsScriptMessage: S.Schema<StartMetadataModelExportAsScriptMessage>;
export interface StartMetadataModelExportAsScriptResponse {
    RequestIdentifier?: string;
}
export declare const StartMetadataModelExportAsScriptResponse: S.Schema<StartMetadataModelExportAsScriptResponse>;
export interface StartMetadataModelExportToTargetMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
    OverwriteExtensionPack?: boolean;
}
export declare const StartMetadataModelExportToTargetMessage: S.Schema<StartMetadataModelExportToTargetMessage>;
export interface StartMetadataModelExportToTargetResponse {
    RequestIdentifier?: string;
}
export declare const StartMetadataModelExportToTargetResponse: S.Schema<StartMetadataModelExportToTargetResponse>;
export interface StartMetadataModelImportMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
    Origin: OriginTypeValue;
    Refresh?: boolean;
}
export declare const StartMetadataModelImportMessage: S.Schema<StartMetadataModelImportMessage>;
export interface StartMetadataModelImportResponse {
    RequestIdentifier?: string;
}
export declare const StartMetadataModelImportResponse: S.Schema<StartMetadataModelImportResponse>;
export interface StartRecommendationsRequest {
    DatabaseId: string;
    Settings: RecommendationSettings;
}
export declare const StartRecommendationsRequest: S.Schema<StartRecommendationsRequest>;
export interface StartRecommendationsResponse {
}
export declare const StartRecommendationsResponse: S.Schema<StartRecommendationsResponse>;
export interface StartReplicationMessage {
    ReplicationConfigArn: string;
    StartReplicationType: string;
    PremigrationAssessmentSettings?: string;
    CdcStartTime?: Date;
    CdcStartPosition?: string;
    CdcStopPosition?: string;
}
export declare const StartReplicationMessage: S.Schema<StartReplicationMessage>;
export interface StartReplicationResponse {
    Replication?: Replication;
}
export declare const StartReplicationResponse: S.Schema<StartReplicationResponse>;
export type StartReplicationTaskTypeValue = "start-replication" | "resume-processing" | "reload-target" | (string & {});
export declare const StartReplicationTaskTypeValue: any;
export interface StartReplicationTaskMessage {
    ReplicationTaskArn: string;
    StartReplicationTaskType: StartReplicationTaskTypeValue;
    CdcStartTime?: Date;
    CdcStartPosition?: string;
    CdcStopPosition?: string;
}
export declare const StartReplicationTaskMessage: S.Schema<StartReplicationTaskMessage>;
export interface StartReplicationTaskResponse {
    ReplicationTask?: ReplicationTask;
}
export declare const StartReplicationTaskResponse: S.Schema<StartReplicationTaskResponse>;
export interface StartReplicationTaskAssessmentMessage {
    ReplicationTaskArn: string;
}
export declare const StartReplicationTaskAssessmentMessage: S.Schema<StartReplicationTaskAssessmentMessage>;
export interface StartReplicationTaskAssessmentResponse {
    ReplicationTask?: ReplicationTask;
}
export declare const StartReplicationTaskAssessmentResponse: S.Schema<StartReplicationTaskAssessmentResponse>;
export type IncludeTestList = string[];
export declare const IncludeTestList: any;
export type ExcludeTestList = string[];
export declare const ExcludeTestList: any;
export interface StartReplicationTaskAssessmentRunMessage {
    ReplicationTaskArn: string;
    ServiceAccessRoleArn: string;
    ResultLocationBucket: string;
    ResultLocationFolder?: string;
    ResultEncryptionMode?: string;
    ResultKmsKeyArn?: string;
    AssessmentRunName: string;
    IncludeOnly?: string[];
    Exclude?: string[];
    Tags?: Tag[];
}
export declare const StartReplicationTaskAssessmentRunMessage: S.Schema<StartReplicationTaskAssessmentRunMessage>;
export interface StartReplicationTaskAssessmentRunResponse {
    ReplicationTaskAssessmentRun?: ReplicationTaskAssessmentRun;
}
export declare const StartReplicationTaskAssessmentRunResponse: S.Schema<StartReplicationTaskAssessmentRunResponse>;
export interface StopDataMigrationMessage {
    DataMigrationIdentifier: string;
}
export declare const StopDataMigrationMessage: S.Schema<StopDataMigrationMessage>;
export interface StopDataMigrationResponse {
    DataMigration?: DataMigration;
}
export declare const StopDataMigrationResponse: S.Schema<StopDataMigrationResponse>;
export interface StopReplicationMessage {
    ReplicationConfigArn: string;
}
export declare const StopReplicationMessage: S.Schema<StopReplicationMessage>;
export interface StopReplicationResponse {
    Replication?: Replication;
}
export declare const StopReplicationResponse: S.Schema<StopReplicationResponse>;
export interface StopReplicationTaskMessage {
    ReplicationTaskArn: string;
}
export declare const StopReplicationTaskMessage: S.Schema<StopReplicationTaskMessage>;
export interface StopReplicationTaskResponse {
    ReplicationTask?: ReplicationTask;
}
export declare const StopReplicationTaskResponse: S.Schema<StopReplicationTaskResponse>;
export interface TestConnectionMessage {
    ReplicationInstanceArn: string;
    EndpointArn: string;
}
export declare const TestConnectionMessage: S.Schema<TestConnectionMessage>;
export interface TestConnectionResponse {
    Connection?: Connection;
}
export declare const TestConnectionResponse: S.Schema<TestConnectionResponse>;
export interface UpdateSubscriptionsToEventBridgeMessage {
    ForceMove?: boolean;
}
export declare const UpdateSubscriptionsToEventBridgeMessage: S.Schema<UpdateSubscriptionsToEventBridgeMessage>;
export interface UpdateSubscriptionsToEventBridgeResponse {
    Result?: string;
}
export declare const UpdateSubscriptionsToEventBridgeResponse: S.Schema<UpdateSubscriptionsToEventBridgeResponse>;
export type ExceptionMessage = string;
export type ResourceArn = string;
export type AddTagsToResourceError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Adds metadata tags to an DMS resource, including replication instance, endpoint,
 * subnet group, and migration task. These tags can also be used with cost allocation
 * reporting to track cost associated with DMS resources, or used in a Condition statement in
 * an IAM policy for DMS. For more information, see
 * `Tag`
 * data type
 * description.
 */
export declare const addTagsToResource: API.OperationMethod<AddTagsToResourceMessage, AddTagsToResourceResponse, AddTagsToResourceError, Credentials | HttpClient.HttpClient>;
export type ApplyPendingMaintenanceActionError = ResourceNotFoundFault | CommonErrors;
/**
 * Applies a pending maintenance action to a resource (for example, to a replication
 * instance).
 */
export declare const applyPendingMaintenanceAction: API.OperationMethod<ApplyPendingMaintenanceActionMessage, ApplyPendingMaintenanceActionResponse, ApplyPendingMaintenanceActionError, Credentials | HttpClient.HttpClient>;
export type BatchStartRecommendationsError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Starts the analysis of up to 20 source databases to recommend target engines for each
 * source database. This is a batch version of StartRecommendations.
 *
 * The result of analysis of each source database is reported individually in the
 * response. Because the batch request can result in a combination of successful and
 * unsuccessful actions, you should check for batch errors even when the call returns an
 * HTTP status code of `200`.
 */
export declare const batchStartRecommendations: API.OperationMethod<BatchStartRecommendationsRequest, BatchStartRecommendationsResponse, BatchStartRecommendationsError, Credentials | HttpClient.HttpClient>;
export type CancelMetadataModelConversionError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Cancels a single metadata model conversion operation that was started with `StartMetadataModelConversion`.
 *
 * **Required permissions:**
 * `dms:CancelMetadataModelConversion`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const cancelMetadataModelConversion: API.OperationMethod<CancelMetadataModelConversionMessage, CancelMetadataModelConversionResponse, CancelMetadataModelConversionError, Credentials | HttpClient.HttpClient>;
export type CancelMetadataModelCreationError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Cancels a single metadata model creation operation that was started with `StartMetadataModelCreation`.
 *
 * **Required permissions:**
 * `dms:CancelMetadataModelCreation`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const cancelMetadataModelCreation: API.OperationMethod<CancelMetadataModelCreationMessage, CancelMetadataModelCreationResponse, CancelMetadataModelCreationError, Credentials | HttpClient.HttpClient>;
export type CancelReplicationTaskAssessmentRunError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Cancels a single premigration assessment run.
 *
 * This operation prevents any individual assessments from running if they haven't started
 * running. It also attempts to cancel any individual assessments that are currently
 * running.
 */
export declare const cancelReplicationTaskAssessmentRun: API.OperationMethod<CancelReplicationTaskAssessmentRunMessage, CancelReplicationTaskAssessmentRunResponse, CancelReplicationTaskAssessmentRunError, Credentials | HttpClient.HttpClient>;
export type CreateDataMigrationError = FailedDependencyFault | InvalidOperationFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Creates a data migration using the provided settings.
 */
export declare const createDataMigration: API.OperationMethod<CreateDataMigrationMessage, CreateDataMigrationResponse, CreateDataMigrationError, Credentials | HttpClient.HttpClient>;
export type CreateDataProviderError = AccessDeniedFault | FailedDependencyFault | ResourceAlreadyExistsFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Creates a data provider using the provided settings. A data provider stores a data store
 * type and location information about your database.
 *
 * **Required permissions:**
 * `dms:CreateDataProvider`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const createDataProvider: API.OperationMethod<CreateDataProviderMessage, CreateDataProviderResponse, CreateDataProviderError, Credentials | HttpClient.HttpClient>;
export type CreateEndpointError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | CommonErrors;
/**
 * Creates an endpoint using the provided settings.
 *
 * For a MySQL source or target endpoint, don't explicitly specify the database using
 * the `DatabaseName` request parameter on the `CreateEndpoint` API
 * call. Specifying `DatabaseName` when you create a MySQL endpoint replicates
 * all the task tables to this single database. For MySQL endpoints, you specify the
 * database only when you specify the schema in the table-mapping rules of the DMS
 * task.
 */
export declare const createEndpoint: API.OperationMethod<CreateEndpointMessage, CreateEndpointResponse, CreateEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateEventSubscriptionError = KMSAccessDeniedFault | KMSDisabledFault | KMSInvalidStateFault | KMSNotFoundFault | KMSThrottlingFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | CommonErrors;
/**
 * Creates an DMS event notification subscription.
 *
 * You can specify the type of source (`SourceType`) you want to be notified of,
 * provide a list of DMS source IDs (`SourceIds`) that triggers the events, and
 * provide a list of event categories (`EventCategories`) for events you want to be
 * notified of. If you specify both the `SourceType` and `SourceIds`,
 * such as `SourceType = replication-instance` and SourceIdentifier =
 * my-replinstance, you will be notified of all the replication instance events for
 * the specified source. If you specify a `SourceType` but don't specify a
 * `SourceIdentifier`, you receive notice of the events for that source type for
 * all your DMS sources. If you don't specify either `SourceType` nor
 * `SourceIdentifier`, you will be notified of events generated from all DMS
 * sources belonging to your customer account.
 *
 * For more information about DMS events, see Working with Events and
 * Notifications in the *Database Migration Service User Guide.*
 */
export declare const createEventSubscription: API.OperationMethod<CreateEventSubscriptionMessage, CreateEventSubscriptionResponse, CreateEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateFleetAdvisorCollectorError = AccessDeniedFault | InvalidResourceStateFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Creates a Fleet Advisor collector using the specified parameters.
 */
export declare const createFleetAdvisorCollector: API.OperationMethod<CreateFleetAdvisorCollectorRequest, CreateFleetAdvisorCollectorResponse, CreateFleetAdvisorCollectorError, Credentials | HttpClient.HttpClient>;
export type CreateInstanceProfileError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Creates the instance profile using the specified parameters.
 *
 * **Required permissions:**
 * `dms:CreateInstanceProfile`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const createInstanceProfile: API.OperationMethod<CreateInstanceProfileMessage, CreateInstanceProfileResponse, CreateInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type CreateMigrationProjectError = AccessDeniedFault | FailedDependencyFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Creates the migration project using the specified parameters.
 *
 * You can run this action only after you create an instance profile and data providers
 * using CreateInstanceProfile and CreateDataProvider.
 *
 * **Required permissions:**
 * `dms:CreateMigrationProject`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const createMigrationProject: API.OperationMethod<CreateMigrationProjectMessage, CreateMigrationProjectResponse, CreateMigrationProjectError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationConfigError = AccessDeniedFault | InvalidResourceStateFault | InvalidSubnet | KMSKeyNotAccessibleFault | ReplicationSubnetGroupDoesNotCoverEnoughAZs | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Creates a configuration that you can later provide to configure and start an DMS
 * Serverless replication. You can also provide options to validate the configuration inputs
 * before you start the replication.
 */
export declare const createReplicationConfig: API.OperationMethod<CreateReplicationConfigMessage, CreateReplicationConfigResponse, CreateReplicationConfigError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationInstanceError = AccessDeniedFault | InsufficientResourceCapacityFault | InvalidResourceStateFault | InvalidSubnet | KMSKeyNotAccessibleFault | ReplicationSubnetGroupDoesNotCoverEnoughAZs | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | StorageQuotaExceededFault | CommonErrors;
/**
 * Creates the replication instance using the specified parameters.
 *
 * DMS requires that your account have certain roles with appropriate permissions before
 * you can create a replication instance. For information on the required roles, see Creating the IAM Roles to Use With the CLI and DMS API. For information on
 * the required permissions, see IAM
 * Permissions Needed to Use DMS.
 *
 * If you don't specify a version when creating a replication instance, DMS will
 * create the instance using the default engine version. For information about the default
 * engine version, see Release Notes.
 */
export declare const createReplicationInstance: API.OperationMethod<CreateReplicationInstanceMessage, CreateReplicationInstanceResponse, CreateReplicationInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationSubnetGroupError = AccessDeniedFault | InvalidSubnet | ReplicationSubnetGroupDoesNotCoverEnoughAZs | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Creates a replication subnet group given a list of the subnet IDs in a VPC.
 *
 * The VPC needs to have at least one subnet in at least two availability zones in the
 * Amazon Web Services Region, otherwise the service will throw a
 * `ReplicationSubnetGroupDoesNotCoverEnoughAZs` exception.
 *
 * If a replication subnet group exists in your Amazon Web Services account, the
 * CreateReplicationSubnetGroup action returns the following error message: The Replication
 * Subnet Group already exists. In this case, delete the existing replication subnet group. To
 * do so, use the DeleteReplicationSubnetGroup action. Optionally, choose Subnet groups in the
 * DMS console, then choose your subnet group. Next, choose Delete from Actions.
 */
export declare const createReplicationSubnetGroup: API.OperationMethod<CreateReplicationSubnetGroupMessage, CreateReplicationSubnetGroupResponse, CreateReplicationSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationTaskError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Creates a replication task using the specified parameters.
 */
export declare const createReplicationTask: API.OperationMethod<CreateReplicationTaskMessage, CreateReplicationTaskResponse, CreateReplicationTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteCertificateError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified certificate.
 */
export declare const deleteCertificate: API.OperationMethod<DeleteCertificateMessage, DeleteCertificateResponse, DeleteCertificateError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the connection between a replication instance and an endpoint.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionMessage, DeleteConnectionResponse, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteDataMigrationError = FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified data migration.
 */
export declare const deleteDataMigration: API.OperationMethod<DeleteDataMigrationMessage, DeleteDataMigrationResponse, DeleteDataMigrationError, Credentials | HttpClient.HttpClient>;
export type DeleteDataProviderError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified data provider.
 *
 * **Required permissions:**
 * `dms:DeleteDataProvider`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 *
 * All migration projects associated with the data provider must be deleted or modified
 * before you can delete the data provider.
 */
export declare const deleteDataProvider: API.OperationMethod<DeleteDataProviderMessage, DeleteDataProviderResponse, DeleteDataProviderError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified endpoint.
 *
 * All tasks associated with the endpoint must be deleted before you can delete the
 * endpoint.
 */
export declare const deleteEndpoint: API.OperationMethod<DeleteEndpointMessage, DeleteEndpointResponse, DeleteEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteEventSubscriptionError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes an DMS event subscription.
 */
export declare const deleteEventSubscription: API.OperationMethod<DeleteEventSubscriptionMessage, DeleteEventSubscriptionResponse, DeleteEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteFleetAdvisorCollectorError = AccessDeniedFault | CollectorNotFoundFault | InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Deletes the specified Fleet Advisor collector.
 */
export declare const deleteFleetAdvisorCollector: API.OperationMethod<DeleteCollectorRequest, DeleteFleetAdvisorCollectorResponse, DeleteFleetAdvisorCollectorError, Credentials | HttpClient.HttpClient>;
export type DeleteFleetAdvisorDatabasesError = AccessDeniedFault | InvalidOperationFault | ResourceNotFoundFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Deletes the specified Fleet Advisor collector databases.
 */
export declare const deleteFleetAdvisorDatabases: API.OperationMethod<DeleteFleetAdvisorDatabasesRequest, DeleteFleetAdvisorDatabasesResponse, DeleteFleetAdvisorDatabasesError, Credentials | HttpClient.HttpClient>;
export type DeleteInstanceProfileError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified instance profile.
 *
 * **Required permissions:**
 * `dms:DeleteInstanceProfile`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 *
 * All migration projects associated with the instance profile must be deleted or
 * modified before you can delete the instance profile.
 */
export declare const deleteInstanceProfile: API.OperationMethod<DeleteInstanceProfileMessage, DeleteInstanceProfileResponse, DeleteInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteMigrationProjectError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified migration project.
 *
 * **Required permissions:**
 * `dms:DeleteMigrationProject`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 *
 * The migration project must be closed before you can delete it.
 */
export declare const deleteMigrationProject: API.OperationMethod<DeleteMigrationProjectMessage, DeleteMigrationProjectResponse, DeleteMigrationProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationConfigError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes an DMS Serverless replication configuration. This effectively deprovisions any
 * and all replications that use this configuration. You can't delete the configuration for an
 * DMS Serverless replication that is ongoing. You can delete the configuration when the
 * replication is in a non-RUNNING and non-STARTING state.
 */
export declare const deleteReplicationConfig: API.OperationMethod<DeleteReplicationConfigMessage, DeleteReplicationConfigResponse, DeleteReplicationConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationInstanceError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified replication instance.
 *
 * You must delete any migration tasks that are associated with the replication instance
 * before you can delete it.
 */
export declare const deleteReplicationInstance: API.OperationMethod<DeleteReplicationInstanceMessage, DeleteReplicationInstanceResponse, DeleteReplicationInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationSubnetGroupError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes a subnet group.
 */
export declare const deleteReplicationSubnetGroup: API.OperationMethod<DeleteReplicationSubnetGroupMessage, DeleteReplicationSubnetGroupResponse, DeleteReplicationSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationTaskError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified replication task.
 */
export declare const deleteReplicationTask: API.OperationMethod<DeleteReplicationTaskMessage, DeleteReplicationTaskResponse, DeleteReplicationTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationTaskAssessmentRunError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the record of a single premigration assessment run.
 *
 * This operation removes all metadata that DMS maintains about this assessment run.
 * However, the operation leaves untouched all information about this assessment run that is
 * stored in your Amazon S3 bucket.
 */
export declare const deleteReplicationTaskAssessmentRun: API.OperationMethod<DeleteReplicationTaskAssessmentRunMessage, DeleteReplicationTaskAssessmentRunResponse, DeleteReplicationTaskAssessmentRunError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountAttributesError = CommonErrors;
/**
 * Lists all of the DMS attributes for a customer account. These attributes include DMS
 * quotas for the account and a unique account identifier in a particular DMS region. DMS
 * quotas include a list of resource quotas supported by the account, such as the number of
 * replication instances allowed. The description for each resource quota, includes the quota
 * name, current usage toward that quota, and the quota's maximum value. DMS uses the unique
 * account identifier to name each artifact used by DMS in the given region.
 *
 * This command does not take any parameters.
 */
export declare const describeAccountAttributes: API.OperationMethod<DescribeAccountAttributesMessage, DescribeAccountAttributesResponse, DescribeAccountAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicableIndividualAssessmentsError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Provides a list of individual assessments that you can specify for a new premigration
 * assessment run, given one or more parameters.
 *
 * If you specify an existing migration task, this operation provides the default
 * individual assessments you can specify for that task. Otherwise, the specified parameters
 * model elements of a possible migration task on which to base a premigration assessment
 * run.
 *
 * To use these migration task modeling parameters, you must specify an existing
 * replication instance, a source database engine, a target database engine, and a migration
 * type. This combination of parameters potentially limits the default individual assessments
 * available for an assessment run created for a corresponding migration task.
 *
 * If you specify no parameters, this operation provides a list of all possible individual
 * assessments that you can specify for an assessment run. If you specify any one of the task
 * modeling parameters, you must specify all of them or the operation cannot provide a list of
 * individual assessments. The only parameter that you can specify alone is for an existing
 * migration task. The specified task definition then determines the default list of
 * individual assessments that you can specify in an assessment run for the task.
 */
export declare const describeApplicableIndividualAssessments: API.PaginatedOperationMethod<DescribeApplicableIndividualAssessmentsMessage, DescribeApplicableIndividualAssessmentsResponse, DescribeApplicableIndividualAssessmentsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeCertificatesError = ResourceNotFoundFault | CommonErrors;
/**
 * Provides a description of the certificate.
 */
export declare const describeCertificates: API.PaginatedOperationMethod<DescribeCertificatesMessage, DescribeCertificatesResponse, DescribeCertificatesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeConnectionsError = ResourceNotFoundFault | CommonErrors;
/**
 * Describes the status of the connections that have been made between the replication
 * instance and an endpoint. Connections are created when you test an endpoint.
 */
export declare const describeConnections: API.PaginatedOperationMethod<DescribeConnectionsMessage, DescribeConnectionsResponse, DescribeConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeConversionConfigurationError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns configuration parameters for a schema conversion project.
 *
 * **Required permissions:**
 * `dms:DescribeConversionConfiguration`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeConversionConfiguration: API.OperationMethod<DescribeConversionConfigurationMessage, DescribeConversionConfigurationResponse, DescribeConversionConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeDataMigrationsError = FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about data migrations.
 */
export declare const describeDataMigrations: API.PaginatedOperationMethod<DescribeDataMigrationsMessage, DescribeDataMigrationsResponse, DescribeDataMigrationsError, Credentials | HttpClient.HttpClient, DataMigration>;
export type DescribeDataProvidersError = AccessDeniedFault | FailedDependencyFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of data providers for your account in the current
 * region.
 *
 * **Required permissions:**
 * `dms:ListDataProviders`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeDataProviders: API.PaginatedOperationMethod<DescribeDataProvidersMessage, DescribeDataProvidersResponse, DescribeDataProvidersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEndpointsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about the endpoints for your account in the current region.
 */
export declare const describeEndpoints: API.PaginatedOperationMethod<DescribeEndpointsMessage, DescribeEndpointsResponse, DescribeEndpointsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEndpointSettingsError = CommonErrors;
/**
 * Returns information about the possible endpoint settings available when you create an
 * endpoint for a specific database engine.
 */
export declare const describeEndpointSettings: API.PaginatedOperationMethod<DescribeEndpointSettingsMessage, DescribeEndpointSettingsResponse, DescribeEndpointSettingsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEndpointTypesError = CommonErrors;
/**
 * Returns information about the type of endpoints available.
 */
export declare const describeEndpointTypes: API.PaginatedOperationMethod<DescribeEndpointTypesMessage, DescribeEndpointTypesResponse, DescribeEndpointTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEngineVersionsError = CommonErrors;
/**
 * Returns information about the replication instance versions used in the project.
 */
export declare const describeEngineVersions: API.PaginatedOperationMethod<DescribeEngineVersionsMessage, DescribeEngineVersionsResponse, DescribeEngineVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEventCategoriesError = CommonErrors;
/**
 * Lists categories for all event source types, or, if specified, for a specified source
 * type. You can see a list of the event categories and source types in Working with Events
 * and Notifications in the *Database Migration Service User Guide.*
 */
export declare const describeEventCategories: API.OperationMethod<DescribeEventCategoriesMessage, DescribeEventCategoriesResponse, DescribeEventCategoriesError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsError = CommonErrors;
/**
 * Lists events for a given source identifier and source type. You can also specify a
 * start and end time. For more information on DMS events, see Working with Events and
 * Notifications in the *Database Migration Service User Guide.*
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsMessage, DescribeEventsResponse, DescribeEventsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEventSubscriptionsError = ResourceNotFoundFault | CommonErrors;
/**
 * Lists all the event subscriptions for a customer account. The description of a
 * subscription includes `SubscriptionName`, `SNSTopicARN`,
 * `CustomerID`, `SourceType`, `SourceID`,
 * `CreationTime`, and `Status`.
 *
 * If you specify `SubscriptionName`, this action lists the description for that
 * subscription.
 */
export declare const describeEventSubscriptions: API.PaginatedOperationMethod<DescribeEventSubscriptionsMessage, DescribeEventSubscriptionsResponse, DescribeEventSubscriptionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeExtensionPackAssociationsError = CommonErrors;
/**
 * Returns a paginated list of extension pack installation requests for a migration
 * project, initiated by
 * StartExtensionPackAssociation.
 *
 * **Required permissions:**
 * `dms:ListExtensionPacks`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeExtensionPackAssociations: API.PaginatedOperationMethod<DescribeExtensionPackAssociationsMessage, DescribeExtensionPackAssociationsResponse, DescribeExtensionPackAssociationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFleetAdvisorCollectorsError = InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Returns a list of the Fleet Advisor collectors in your account.
 */
export declare const describeFleetAdvisorCollectors: API.PaginatedOperationMethod<DescribeFleetAdvisorCollectorsRequest, DescribeFleetAdvisorCollectorsResponse, DescribeFleetAdvisorCollectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFleetAdvisorDatabasesError = InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Returns a list of Fleet Advisor databases in your account.
 */
export declare const describeFleetAdvisorDatabases: API.PaginatedOperationMethod<DescribeFleetAdvisorDatabasesRequest, DescribeFleetAdvisorDatabasesResponse, DescribeFleetAdvisorDatabasesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFleetAdvisorLsaAnalysisError = InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Provides descriptions of large-scale assessment (LSA) analyses produced by your Fleet
 * Advisor collectors.
 */
export declare const describeFleetAdvisorLsaAnalysis: API.PaginatedOperationMethod<DescribeFleetAdvisorLsaAnalysisRequest, DescribeFleetAdvisorLsaAnalysisResponse, DescribeFleetAdvisorLsaAnalysisError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFleetAdvisorSchemaObjectSummaryError = InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Provides descriptions of the schemas discovered by your Fleet Advisor
 * collectors.
 */
export declare const describeFleetAdvisorSchemaObjectSummary: API.PaginatedOperationMethod<DescribeFleetAdvisorSchemaObjectSummaryRequest, DescribeFleetAdvisorSchemaObjectSummaryResponse, DescribeFleetAdvisorSchemaObjectSummaryError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFleetAdvisorSchemasError = InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Returns a list of schemas detected by Fleet Advisor Collectors in your account.
 */
export declare const describeFleetAdvisorSchemas: API.PaginatedOperationMethod<DescribeFleetAdvisorSchemasRequest, DescribeFleetAdvisorSchemasResponse, DescribeFleetAdvisorSchemasError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeInstanceProfilesError = AccessDeniedFault | FailedDependencyFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of instance profiles for your account in the current
 * region.
 *
 * **Required permissions:**
 * `dms:ListInstanceProfiles`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeInstanceProfiles: API.PaginatedOperationMethod<DescribeInstanceProfilesMessage, DescribeInstanceProfilesResponse, DescribeInstanceProfilesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMetadataModelError = AccessDeniedFault | ResourceNotFoundFault | CommonErrors;
/**
 * Gets detailed information about the specified metadata model, including its definition and corresponding converted objects in the target database if applicable.
 *
 * **Required permissions:**
 * `dms:DescribeMetadataModel`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModel: API.OperationMethod<DescribeMetadataModelMessage, DescribeMetadataModelResponse, DescribeMetadataModelError, Credentials | HttpClient.HttpClient>;
export type DescribeMetadataModelAssessmentsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of metadata model assessment requests for a migration
 * project, initiated by
 * StartMetadataModelAssessment.
 *
 * **Required permissions:**
 * `dms:ListMetadataModelAssessments`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelAssessments: API.PaginatedOperationMethod<DescribeMetadataModelAssessmentsMessage, DescribeMetadataModelAssessmentsResponse, DescribeMetadataModelAssessmentsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMetadataModelChildrenError = AccessDeniedFault | ResourceNotFoundFault | CommonErrors;
/**
 * Gets a list of child metadata models for the specified metadata model in the database hierarchy.
 *
 * **Required permissions:**
 * `dms:DescribeMetadataModelChildren`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelChildren: API.PaginatedOperationMethod<DescribeMetadataModelChildrenMessage, DescribeMetadataModelChildrenResponse, DescribeMetadataModelChildrenError, Credentials | HttpClient.HttpClient, MetadataModelReference>;
export type DescribeMetadataModelConversionsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of metadata model conversion requests for a migration
 * project, initiated by
 * StartMetadataModelConversion.
 *
 * To cancel a queued or in-progress request, call
 * CancelMetadataModelConversion.
 *
 * **Required permissions:**
 * `dms:ListMetadataModelConversions`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelConversions: API.PaginatedOperationMethod<DescribeMetadataModelConversionsMessage, DescribeMetadataModelConversionsResponse, DescribeMetadataModelConversionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMetadataModelCreationsError = AccessDeniedFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of metadata model creation requests for a migration
 * project, initiated by
 * StartMetadataModelCreation.
 *
 * To cancel a queued or in-progress request, call
 * CancelMetadataModelCreation.
 *
 * **Required permissions:**
 * `dms:DescribeMetadataModelCreations`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelCreations: API.PaginatedOperationMethod<DescribeMetadataModelCreationsMessage, DescribeMetadataModelCreationsResponse, DescribeMetadataModelCreationsError, Credentials | HttpClient.HttpClient, SchemaConversionRequest>;
export type DescribeMetadataModelExportsAsScriptError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of metadata model export requests for a migration
 * project, initiated by
 * StartMetadataModelExportAsScript.
 *
 * **Required permissions:**
 * `dms:ListMetadataModelExports`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelExportsAsScript: API.PaginatedOperationMethod<DescribeMetadataModelExportsAsScriptMessage, DescribeMetadataModelExportsAsScriptResponse, DescribeMetadataModelExportsAsScriptError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMetadataModelExportsToTargetError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of metadata model export requests for a migration
 * project, initiated by
 * StartMetadataModelExportToTarget.
 *
 * **Required permissions:**
 * `dms:ListMetadataModelExports`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelExportsToTarget: API.PaginatedOperationMethod<DescribeMetadataModelExportsToTargetMessage, DescribeMetadataModelExportsToTargetResponse, DescribeMetadataModelExportsToTargetError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMetadataModelImportsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of metadata model import requests for a migration
 * project, initiated by
 * StartMetadataModelImport.
 *
 * **Required permissions:**
 * `dms:DescribeMetadataModelImports`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelImports: API.PaginatedOperationMethod<DescribeMetadataModelImportsMessage, DescribeMetadataModelImportsResponse, DescribeMetadataModelImportsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMigrationProjectsError = AccessDeniedFault | FailedDependencyFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of migration projects for your account in the current
 * region.
 *
 * **Required permissions:**
 * `dms:ListMigrationProjects`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMigrationProjects: API.PaginatedOperationMethod<DescribeMigrationProjectsMessage, DescribeMigrationProjectsResponse, DescribeMigrationProjectsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeOrderableReplicationInstancesError = CommonErrors;
/**
 * Returns information about the replication instance types that can be created in the
 * specified region.
 */
export declare const describeOrderableReplicationInstances: API.PaginatedOperationMethod<DescribeOrderableReplicationInstancesMessage, DescribeOrderableReplicationInstancesResponse, DescribeOrderableReplicationInstancesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribePendingMaintenanceActionsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a list of upcoming maintenance events for replication instances in your account
 * in the current Region.
 */
export declare const describePendingMaintenanceActions: API.PaginatedOperationMethod<DescribePendingMaintenanceActionsMessage, DescribePendingMaintenanceActionsResponse, DescribePendingMaintenanceActionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeRecommendationLimitationsError = AccessDeniedFault | InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Returns a paginated list of limitations for recommendations of target Amazon Web Services
 * engines.
 */
export declare const describeRecommendationLimitations: API.PaginatedOperationMethod<DescribeRecommendationLimitationsRequest, DescribeRecommendationLimitationsResponse, DescribeRecommendationLimitationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeRecommendationsError = AccessDeniedFault | InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Returns a paginated list of target engine recommendations for your source
 * databases.
 */
export declare const describeRecommendations: API.PaginatedOperationMethod<DescribeRecommendationsRequest, DescribeRecommendationsResponse, DescribeRecommendationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeRefreshSchemasStatusError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns the status of the RefreshSchemas operation.
 */
export declare const describeRefreshSchemasStatus: API.OperationMethod<DescribeRefreshSchemasStatusMessage, DescribeRefreshSchemasStatusResponse, DescribeRefreshSchemasStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeReplicationConfigsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns one or more existing DMS Serverless replication configurations as a list of
 * structures.
 */
export declare const describeReplicationConfigs: API.PaginatedOperationMethod<DescribeReplicationConfigsMessage, DescribeReplicationConfigsResponse, DescribeReplicationConfigsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationInstancesError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about replication instances for your account in the current
 * region.
 */
export declare const describeReplicationInstances: API.PaginatedOperationMethod<DescribeReplicationInstancesMessage, DescribeReplicationInstancesResponse, DescribeReplicationInstancesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationInstanceTaskLogsError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about the task logs for the specified task.
 */
export declare const describeReplicationInstanceTaskLogs: API.PaginatedOperationMethod<DescribeReplicationInstanceTaskLogsMessage, DescribeReplicationInstanceTaskLogsResponse, DescribeReplicationInstanceTaskLogsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationsError = ResourceNotFoundFault | CommonErrors;
/**
 * Provides details on replication progress by returning status information for one or more
 * provisioned DMS Serverless replications.
 */
export declare const describeReplications: API.PaginatedOperationMethod<DescribeReplicationsMessage, DescribeReplicationsResponse, DescribeReplicationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationSubnetGroupsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about the replication subnet groups.
 */
export declare const describeReplicationSubnetGroups: API.PaginatedOperationMethod<DescribeReplicationSubnetGroupsMessage, DescribeReplicationSubnetGroupsResponse, DescribeReplicationSubnetGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationTableStatisticsError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns table and schema statistics for one or more provisioned replications that use a
 * given DMS Serverless replication configuration.
 */
export declare const describeReplicationTableStatistics: API.PaginatedOperationMethod<DescribeReplicationTableStatisticsMessage, DescribeReplicationTableStatisticsResponse, DescribeReplicationTableStatisticsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationTaskAssessmentResultsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns the task assessment results from the Amazon S3 bucket that DMS creates in your
 * Amazon Web Services account. This action always returns the latest results.
 *
 * For more information about DMS task assessments, see Creating a task assessment
 * report in the *Database Migration Service User Guide*.
 */
export declare const describeReplicationTaskAssessmentResults: API.PaginatedOperationMethod<DescribeReplicationTaskAssessmentResultsMessage, DescribeReplicationTaskAssessmentResultsResponse, DescribeReplicationTaskAssessmentResultsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationTaskAssessmentRunsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of premigration assessment runs based on filter
 * settings.
 *
 * These filter settings can specify a combination of premigration assessment runs,
 * migration tasks, replication instances, and assessment run status values.
 *
 * This operation doesn't return information about individual assessments. For this
 * information, see the `DescribeReplicationTaskIndividualAssessments`
 * operation.
 */
export declare const describeReplicationTaskAssessmentRuns: API.PaginatedOperationMethod<DescribeReplicationTaskAssessmentRunsMessage, DescribeReplicationTaskAssessmentRunsResponse, DescribeReplicationTaskAssessmentRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationTaskIndividualAssessmentsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of individual assessments based on filter settings.
 *
 * These filter settings can specify a combination of premigration assessment runs,
 * migration tasks, and assessment status values.
 */
export declare const describeReplicationTaskIndividualAssessments: API.PaginatedOperationMethod<DescribeReplicationTaskIndividualAssessmentsMessage, DescribeReplicationTaskIndividualAssessmentsResponse, DescribeReplicationTaskIndividualAssessmentsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationTasksError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about replication tasks for your account in the current
 * region.
 */
export declare const describeReplicationTasks: API.PaginatedOperationMethod<DescribeReplicationTasksMessage, DescribeReplicationTasksResponse, DescribeReplicationTasksError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeSchemasError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about the schema for the specified endpoint.
 */
export declare const describeSchemas: API.PaginatedOperationMethod<DescribeSchemasMessage, DescribeSchemasResponse, DescribeSchemasError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeTableStatisticsError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns table statistics on the database migration task, including table name, rows
 * inserted, rows updated, and rows deleted.
 *
 * Note that the "last updated" column the DMS console only indicates the time that DMS
 * last updated the table statistics record for a table. It does not indicate the time of the
 * last update to the table.
 */
export declare const describeTableStatistics: API.PaginatedOperationMethod<DescribeTableStatisticsMessage, DescribeTableStatisticsResponse, DescribeTableStatisticsError, Credentials | HttpClient.HttpClient, unknown>;
export type ExportMetadataModelAssessmentError = ResourceNotFoundFault | CommonErrors;
/**
 * Saves a copy of a database migration assessment report to your Amazon S3 bucket. DMS can
 * save your assessment report as a comma-separated value (CSV) or a PDF file.
 *
 * **Required permissions:**
 * `dms:ExportMetadataModelAssessment`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const exportMetadataModelAssessment: API.OperationMethod<ExportMetadataModelAssessmentMessage, ExportMetadataModelAssessmentResponse, ExportMetadataModelAssessmentError, Credentials | HttpClient.HttpClient>;
export type GetTargetSelectionRulesError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Converts source selection rules into their target counterparts for schema conversion operations.
 *
 * **Required permissions:**
 * `dms:GetTargetSelectionRules`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const getTargetSelectionRules: API.OperationMethod<GetTargetSelectionRulesMessage, GetTargetSelectionRulesResponse, GetTargetSelectionRulesError, Credentials | HttpClient.HttpClient>;
export type ImportCertificateError = InvalidCertificateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Uploads the specified certificate.
 */
export declare const importCertificate: API.OperationMethod<ImportCertificateMessage, ImportCertificateResponse, ImportCertificateError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Lists all metadata tags attached to an DMS resource, including replication instance,
 * endpoint, subnet group, and migration task. For more information, see
 * `Tag`
 *
 * data type description.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceMessage, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ModifyConversionConfigurationError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Modifies the specified schema conversion configuration using the provided parameters.
 *
 * **Required permissions:**
 * `dms:UpdateConversionConfiguration`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const modifyConversionConfiguration: API.OperationMethod<ModifyConversionConfigurationMessage, ModifyConversionConfigurationResponse, ModifyConversionConfigurationError, Credentials | HttpClient.HttpClient>;
export type ModifyDataMigrationError = FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Modifies an existing DMS data migration.
 */
export declare const modifyDataMigration: API.OperationMethod<ModifyDataMigrationMessage, ModifyDataMigrationResponse, ModifyDataMigrationError, Credentials | HttpClient.HttpClient>;
export type ModifyDataProviderError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Modifies the specified data provider using the provided settings.
 *
 * **Required permissions:**
 * `dms:UpdateDataProvider`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 *
 * You must remove the data provider from all migration projects before you can modify
 * it.
 */
export declare const modifyDataProvider: API.OperationMethod<ModifyDataProviderMessage, ModifyDataProviderResponse, ModifyDataProviderError, Credentials | HttpClient.HttpClient>;
export type ModifyEndpointError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | CommonErrors;
/**
 * Modifies the specified endpoint.
 *
 * For a MySQL source or target endpoint, don't explicitly specify the database using
 * the `DatabaseName` request parameter on the `ModifyEndpoint` API
 * call. Specifying `DatabaseName` when you modify a MySQL endpoint replicates
 * all the task tables to this single database. For MySQL endpoints, you specify the
 * database only when you specify the schema in the table-mapping rules of the DMS
 * task.
 */
export declare const modifyEndpoint: API.OperationMethod<ModifyEndpointMessage, ModifyEndpointResponse, ModifyEndpointError, Credentials | HttpClient.HttpClient>;
export type ModifyEventSubscriptionError = AccessDeniedFault | KMSAccessDeniedFault | KMSDisabledFault | KMSInvalidStateFault | KMSNotFoundFault | KMSThrottlingFault | ResourceNotFoundFault | ResourceQuotaExceededFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | CommonErrors;
/**
 * Modifies an existing DMS event notification subscription.
 */
export declare const modifyEventSubscription: API.OperationMethod<ModifyEventSubscriptionMessage, ModifyEventSubscriptionResponse, ModifyEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type ModifyInstanceProfileError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceNotFoundFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Modifies the specified instance profile using the provided parameters.
 *
 * **Required permissions:**
 * `dms:UpdateInstanceProfile`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 *
 * All migration projects associated with the instance profile must be deleted or
 * modified before you can modify the instance profile.
 */
export declare const modifyInstanceProfile: API.OperationMethod<ModifyInstanceProfileMessage, ModifyInstanceProfileResponse, ModifyInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type ModifyMigrationProjectError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Modifies the specified migration project using the provided parameters.
 *
 * **Required permissions:**
 * `dms:UpdateMigrationProject`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 *
 * The migration project must be closed before you can modify it.
 */
export declare const modifyMigrationProject: API.OperationMethod<ModifyMigrationProjectMessage, ModifyMigrationProjectResponse, ModifyMigrationProjectError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationConfigError = AccessDeniedFault | InvalidResourceStateFault | InvalidSubnet | KMSKeyNotAccessibleFault | ReplicationSubnetGroupDoesNotCoverEnoughAZs | ResourceNotFoundFault | CommonErrors;
/**
 * Modifies an existing DMS Serverless replication configuration that you can use to
 * start a replication. This command includes input validation and logic to check the state of
 * any replication that uses this configuration. You can only modify a replication
 * configuration before any replication that uses it has started. As soon as you have
 * initially started a replication with a given configuiration, you can't modify that
 * configuration, even if you stop it.
 *
 * Other run statuses that allow you to run this command include FAILED and CREATED. A
 * provisioning state that allows you to run this command is FAILED_PROVISION.
 */
export declare const modifyReplicationConfig: API.OperationMethod<ModifyReplicationConfigMessage, ModifyReplicationConfigResponse, ModifyReplicationConfigError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationInstanceError = AccessDeniedFault | InsufficientResourceCapacityFault | InvalidResourceStateFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | StorageQuotaExceededFault | UpgradeDependencyFailureFault | CommonErrors;
/**
 * Modifies the replication instance to apply new settings. You can change one or more
 * parameters by specifying these parameters and the new values in the request.
 *
 * Some settings are applied during the maintenance window.
 */
export declare const modifyReplicationInstance: API.OperationMethod<ModifyReplicationInstanceMessage, ModifyReplicationInstanceResponse, ModifyReplicationInstanceError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationSubnetGroupError = AccessDeniedFault | InvalidSubnet | ReplicationSubnetGroupDoesNotCoverEnoughAZs | ResourceNotFoundFault | ResourceQuotaExceededFault | SubnetAlreadyInUse | CommonErrors;
/**
 * Modifies the settings for the specified replication subnet group.
 */
export declare const modifyReplicationSubnetGroup: API.OperationMethod<ModifyReplicationSubnetGroupMessage, ModifyReplicationSubnetGroupResponse, ModifyReplicationSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationTaskError = InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | CommonErrors;
/**
 * Modifies the specified replication task.
 *
 * You can't modify the task endpoints. The task must be stopped before you can modify it.
 *
 * For more information about DMS tasks, see Working with Migration Tasks in the
 * *Database Migration Service User Guide*.
 */
export declare const modifyReplicationTask: API.OperationMethod<ModifyReplicationTaskMessage, ModifyReplicationTaskResponse, ModifyReplicationTaskError, Credentials | HttpClient.HttpClient>;
export type MoveReplicationTaskError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Moves a replication task from its current replication instance to a different target
 * replication instance using the specified parameters. The target replication instance must
 * be created with the same or later DMS version as the current replication instance.
 */
export declare const moveReplicationTask: API.OperationMethod<MoveReplicationTaskMessage, MoveReplicationTaskResponse, MoveReplicationTaskError, Credentials | HttpClient.HttpClient>;
export type RebootReplicationInstanceError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Reboots a replication instance. Rebooting results in a momentary outage, until the
 * replication instance becomes available again.
 */
export declare const rebootReplicationInstance: API.OperationMethod<RebootReplicationInstanceMessage, RebootReplicationInstanceResponse, RebootReplicationInstanceError, Credentials | HttpClient.HttpClient>;
export type RefreshSchemasError = InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Populates the schema for the specified endpoint. This is an asynchronous operation and
 * can take several minutes. You can check the status of this operation by calling the
 * DescribeRefreshSchemasStatus operation.
 */
export declare const refreshSchemas: API.OperationMethod<RefreshSchemasMessage, RefreshSchemasResponse, RefreshSchemasError, Credentials | HttpClient.HttpClient>;
export type ReloadReplicationTablesError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Reloads the target database table with the source data for a given DMS Serverless
 * replication configuration.
 *
 * You can only use this operation with a task in the RUNNING state, otherwise the service
 * will throw an `InvalidResourceStateFault` exception.
 */
export declare const reloadReplicationTables: API.OperationMethod<ReloadReplicationTablesMessage, ReloadReplicationTablesResponse, ReloadReplicationTablesError, Credentials | HttpClient.HttpClient>;
export type ReloadTablesError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Reloads the target database table with the source data.
 *
 * You can only use this operation with a task in the `RUNNING` state, otherwise
 * the service will throw an `InvalidResourceStateFault` exception.
 */
export declare const reloadTables: API.OperationMethod<ReloadTablesMessage, ReloadTablesResponse, ReloadTablesError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromResourceError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Removes metadata tags from an DMS resource, including replication instance, endpoint,
 * subnet group, and migration task. For more information, see
 * `Tag`
 * data type
 * description.
 */
export declare const removeTagsFromResource: API.OperationMethod<RemoveTagsFromResourceMessage, RemoveTagsFromResourceResponse, RemoveTagsFromResourceError, Credentials | HttpClient.HttpClient>;
export type RunFleetAdvisorLsaAnalysisError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Runs large-scale assessment (LSA) analysis on every Fleet Advisor collector in your account.
 */
export declare const runFleetAdvisorLsaAnalysis: API.OperationMethod<RunFleetAdvisorLsaAnalysisRequest, RunFleetAdvisorLsaAnalysisResponse, RunFleetAdvisorLsaAnalysisError, Credentials | HttpClient.HttpClient>;
export type StartDataMigrationError = FailedDependencyFault | InvalidOperationFault | InvalidResourceStateFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Starts the specified data migration.
 */
export declare const startDataMigration: API.OperationMethod<StartDataMigrationMessage, StartDataMigrationResponse, StartDataMigrationError, Credentials | HttpClient.HttpClient>;
export type StartExtensionPackAssociationError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Queues the installation of the extension pack on your target database. If other
 * requests created by `Start*` operations are already in the migration project's
 * queue, the installation begins after they complete.
 *
 * This operation requires a non-virtual target data provider.
 *
 * If the extension pack already exists, the operation reinstalls it. To ensure
 * compatibility, reconvert your database objects if the version has changed since your last
 * conversion. For more information, see Using extension packs in DMS Schema Conversion.
 *
 * To check the status of the request, call
 * DescribeExtensionPackAssociations using the returned
 * `RequestIdentifier` as a filter.
 *
 * **Required permissions:**
 * `dms:AssociateExtensionPack`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startExtensionPackAssociation: API.OperationMethod<StartExtensionPackAssociationMessage, StartExtensionPackAssociationResponse, StartExtensionPackAssociationError, Credentials | HttpClient.HttpClient>;
export type StartMetadataModelAssessmentError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Queues an assessment of the selected source metadata models (database objects such as
 * tables, views, and procedures) to evaluate conversion complexity to the target database
 * format. If other requests created by `Start*` operations are already in the
 * migration project's queue, the assessment begins after they complete.
 *
 * The assessment request loads metadata models that are not yet in the metadata tree, but
 * does not reload metadata models that are already present. If your source database has
 * changed since the metadata was loaded, refresh the affected metadata models with
 * StartMetadataModelImport before calling this operation.
 *
 * To check the status of the assessment request, call
 * DescribeMetadataModelAssessments using the returned
 * `RequestIdentifier` as a filter.
 *
 * To export the conversion assessment report after the request completes successfully,
 * call ExportMetadataModelAssessment.
 *
 * **Required permissions:**
 * `dms:StartMetadataModelAssessment`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startMetadataModelAssessment: API.OperationMethod<StartMetadataModelAssessmentMessage, StartMetadataModelAssessmentResponse, StartMetadataModelAssessmentError, Credentials | HttpClient.HttpClient>;
export type StartMetadataModelConversionError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Queues a conversion of the selected source metadata models (database objects such as
 * tables, views, and procedures) to the target database format. If other requests created
 * by `Start*` operations are already in the migration project's queue, the
 * conversion begins after they complete.
 *
 * The conversion request loads metadata models that are not yet in the metadata tree, but
 * does not reload metadata models that are already present. If your source database has
 * changed since the metadata was loaded, refresh the affected metadata models with
 * StartMetadataModelImport before calling this operation.
 *
 * If converted objects already exist in the target metadata tree, the conversion
 * overwrites them, including any manual edits.
 *
 * To check the status of the conversion request, call
 * DescribeMetadataModelConversions using the returned
 * `RequestIdentifier` as a filter.
 *
 * To cancel a queued or in-progress request, call
 * CancelMetadataModelConversion with the returned
 * `RequestIdentifier`.
 *
 * After the conversion completes successfully:
 *
 * - To export a post-conversion assessment report, call
 * ExportMetadataModelAssessment.
 *
 * - To retrieve converted code, use any of the following
 * options:
 *
 * - DescribeMetadataModel and
 * DescribeMetadataModelChildren – navigate the target metadata
 * tree and retrieve converted definitions.
 *
 * - StartMetadataModelExportAsScript – export as data definition
 * language (DDL) scripts to your Amazon S3 bucket.
 *
 * - StartMetadataModelExportToTarget – apply directly to your
 * target database.
 *
 * **Required permissions:**
 * `dms:StartMetadataModelConversion`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startMetadataModelConversion: API.OperationMethod<StartMetadataModelConversionMessage, StartMetadataModelConversionResponse, StartMetadataModelConversionError, Credentials | HttpClient.HttpClient>;
export type StartMetadataModelCreationError = AccessDeniedFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Queues the creation of a metadata model in the source metadata tree. If other requests
 * created by `Start*` operations are already in the migration project's queue, the
 * creation begins after they complete.
 *
 * This operation supports only Microsoft SQL Server to Aurora PostgreSQL and
 * Microsoft SQL Server to Amazon RDS for PostgreSQL conversion paths.
 *
 * To check the status of the creation request, call
 * DescribeMetadataModelCreations using the returned
 * `RequestIdentifier` as a filter.
 *
 * To cancel a queued or in-progress request, call
 * CancelMetadataModelCreation with the returned
 * `RequestIdentifier`.
 *
 * Calling
 * StartMetadataModelImport with `Refresh` deletes metadata models
 * created by this operation.
 *
 * After the creation completes successfully:
 *
 * - To evaluate conversion complexity, call
 * StartMetadataModelAssessment.
 *
 * - To convert to the target database format, call
 * StartMetadataModelConversion.
 *
 * **Required permissions:**
 * `dms:StartMetadataModelCreation`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startMetadataModelCreation: API.OperationMethod<StartMetadataModelCreationMessage, StartMetadataModelCreationResponse, StartMetadataModelCreationError, Credentials | HttpClient.HttpClient>;
export type StartMetadataModelExportAsScriptError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Queues an export of metadata models (database objects such as tables, views, and
 * procedures) as a data definition language (DDL) script. The script is stored as a ZIP
 * archive in the Amazon S3 bucket associated with the migration project. If other requests
 * created by `Start*` operations are already in the migration project's queue,
 * the export begins after they complete.
 *
 * When exporting from the target metadata tree, the export applies only to metadata
 * models created by conversion. Metadata models imported from the database are
 * skipped.
 *
 * To check the status of the export request, call
 * DescribeMetadataModelExportsAsScript using the returned
 * `RequestIdentifier` as a filter.
 *
 * **Required permissions:**
 * `dms:StartMetadataModelExportAsScripts`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startMetadataModelExportAsScript: API.OperationMethod<StartMetadataModelExportAsScriptMessage, StartMetadataModelExportAsScriptResponse, StartMetadataModelExportAsScriptError, Credentials | HttpClient.HttpClient>;
export type StartMetadataModelExportToTargetError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Queues an export of the selected converted metadata models (database objects such as
 * tables, views, and procedures) to your target database. If other requests created by
 * `Start*` operations are already in the migration project's queue, the export
 * begins after they complete.
 *
 * This operation requires a non-virtual target data provider.
 *
 * The export applies only metadata models created by conversion. Metadata models
 * imported from the database are skipped.
 *
 * If objects with the same name already exist on the target database, the export
 * overwrites them.
 *
 * The operation installs the extension pack on the target database. For more
 * information, see Using extension packs in DMS Schema Conversion.
 *
 * To check the status of the export request, call
 * DescribeMetadataModelExportsToTarget using the returned
 * `RequestIdentifier` as a filter.
 *
 * **Required permissions:**
 * `dms:StartMetadataModelExportToTarget`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startMetadataModelExportToTarget: API.OperationMethod<StartMetadataModelExportToTargetMessage, StartMetadataModelExportToTargetResponse, StartMetadataModelExportToTargetError, Credentials | HttpClient.HttpClient>;
export type StartMetadataModelImportError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Queues an import of metadata models (database objects such as tables, views, and
 * procedures) from your data provider into the metadata tree. If other requests created
 * by `Start*` operations are already in the migration project's queue, the
 * import begins after they complete.
 *
 * To check the status of the import request, call
 * DescribeMetadataModelImports using the returned
 * `RequestIdentifier` as a filter.
 *
 * **Required permissions:**
 * `dms:StartMetadataModelImport`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startMetadataModelImport: API.OperationMethod<StartMetadataModelImportMessage, StartMetadataModelImportResponse, StartMetadataModelImportError, Credentials | HttpClient.HttpClient>;
export type StartRecommendationsError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Starts the analysis of your source database to provide recommendations of target
 * engines.
 *
 * You can create recommendations for multiple source databases using BatchStartRecommendations.
 */
export declare const startRecommendations: API.OperationMethod<StartRecommendationsRequest, StartRecommendationsResponse, StartRecommendationsError, Credentials | HttpClient.HttpClient>;
export type StartReplicationError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * For a given DMS Serverless replication configuration, DMS connects to the source
 * endpoint and collects the metadata to analyze the replication workload. Using this
 * metadata, DMS then computes and provisions the required capacity and starts replicating
 * to the target endpoint using the server resources that DMS has provisioned for the DMS
 * Serverless replication.
 */
export declare const startReplication: API.OperationMethod<StartReplicationMessage, StartReplicationResponse, StartReplicationError, Credentials | HttpClient.HttpClient>;
export type StartReplicationTaskError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Starts the replication task.
 *
 * For more information about DMS tasks, see Working with Migration Tasks in the
 * *Database Migration Service User Guide.*
 */
export declare const startReplicationTask: API.OperationMethod<StartReplicationTaskMessage, StartReplicationTaskResponse, StartReplicationTaskError, Credentials | HttpClient.HttpClient>;
export type StartReplicationTaskAssessmentError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Starts the replication task assessment for unsupported data types in the source
 * database.
 *
 * You can only use this operation for a task if the following conditions are true:
 *
 * - The task must be in the `stopped` state.
 *
 * - The task must have successful connections to the source and target.
 *
 * If either of these conditions are not met, an `InvalidResourceStateFault`
 * error will result.
 *
 * For information about DMS task assessments, see Creating a task assessment report in the Database Migration Service User
 * Guide.
 */
export declare const startReplicationTaskAssessment: API.OperationMethod<StartReplicationTaskAssessmentMessage, StartReplicationTaskAssessmentResponse, StartReplicationTaskAssessmentError, Credentials | HttpClient.HttpClient>;
export type StartReplicationTaskAssessmentRunError = AccessDeniedFault | InvalidResourceStateFault | KMSAccessDeniedFault | KMSDisabledFault | KMSFault | KMSInvalidStateFault | KMSKeyNotAccessibleFault | KMSNotFoundFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Starts a new premigration assessment run for one or more individual assessments of a
 * migration task.
 *
 * The assessments that you can specify depend on the source and target database engine and
 * the migration type defined for the given task. To run this operation, your migration task
 * must already be created. After you run this operation, you can review the status of each
 * individual assessment. You can also run the migration task manually after the assessment
 * run and its individual assessments complete.
 */
export declare const startReplicationTaskAssessmentRun: API.OperationMethod<StartReplicationTaskAssessmentRunMessage, StartReplicationTaskAssessmentRunResponse, StartReplicationTaskAssessmentRunError, Credentials | HttpClient.HttpClient>;
export type StopDataMigrationError = FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Stops the specified data migration.
 */
export declare const stopDataMigration: API.OperationMethod<StopDataMigrationMessage, StopDataMigrationResponse, StopDataMigrationError, Credentials | HttpClient.HttpClient>;
export type StopReplicationError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * For a given DMS Serverless replication configuration, DMS stops any and all ongoing
 * DMS Serverless replications. This command doesn't deprovision the stopped
 * replications.
 */
export declare const stopReplication: API.OperationMethod<StopReplicationMessage, StopReplicationResponse, StopReplicationError, Credentials | HttpClient.HttpClient>;
export type StopReplicationTaskError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Stops the replication task.
 */
export declare const stopReplicationTask: API.OperationMethod<StopReplicationTaskMessage, StopReplicationTaskResponse, StopReplicationTaskError, Credentials | HttpClient.HttpClient>;
export type TestConnectionError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Tests the connection between the replication instance and the endpoint.
 */
export declare const testConnection: API.OperationMethod<TestConnectionMessage, TestConnectionResponse, TestConnectionError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriptionsToEventBridgeError = AccessDeniedFault | InvalidResourceStateFault | CommonErrors;
/**
 * Migrates 10 active and enabled Amazon SNS subscriptions at a time and converts them to
 * corresponding Amazon EventBridge rules. By default, this operation migrates subscriptions
 * only when all your replication instance versions are 3.4.5 or higher. If any replication
 * instances are from versions earlier than 3.4.5, the operation raises an error and tells you
 * to upgrade these instances to version 3.4.5 or higher. To enable migration regardless of
 * version, set the `Force` option to true. However, if you don't upgrade instances
 * earlier than version 3.4.5, some types of events might not be available when you use Amazon
 * EventBridge.
 *
 * To call this operation, make sure that you have certain permissions added to your user
 * account. For more information, see Migrating event subscriptions to Amazon EventBridge in the
 * *Amazon Web Services Database Migration Service User Guide*.
 */
export declare const updateSubscriptionsToEventBridge: API.OperationMethod<UpdateSubscriptionsToEventBridgeMessage, UpdateSubscriptionsToEventBridgeResponse, UpdateSubscriptionsToEventBridgeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=database-migration-service.d.ts.map