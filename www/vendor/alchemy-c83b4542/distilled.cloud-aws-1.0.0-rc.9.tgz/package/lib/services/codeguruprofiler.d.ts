import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ProfilingGroupName = string;
export type ChannelId = string;
export type ChannelUri = string;
export type EventPublisher = string;
export type EventPublishers = string[];
export declare const EventPublishers: any;
export interface Channel {
    id?: string;
    uri: string;
    eventPublishers: string[];
}
export declare const Channel: S.Schema<Channel>;
export type Channels = Channel[];
export declare const Channels: any;
export interface AddNotificationChannelsRequest {
    profilingGroupName: string;
    channels: Channel[];
}
export declare const AddNotificationChannelsRequest: S.Schema<AddNotificationChannelsRequest>;
export interface NotificationConfiguration {
    channels?: Channel[];
}
export declare const NotificationConfiguration: S.Schema<NotificationConfiguration>;
export interface AddNotificationChannelsResponse {
    notificationConfiguration?: NotificationConfiguration;
}
export declare const AddNotificationChannelsResponse: S.Schema<AddNotificationChannelsResponse>;
export type Period = string;
export type AggregationPeriod = string;
export type MetricType = string;
export type ThreadStates = string[];
export declare const ThreadStates: any;
export interface FrameMetric {
    frameName: string;
    type: string;
    threadStates: string[];
}
export declare const FrameMetric: S.Schema<FrameMetric>;
export type FrameMetrics = FrameMetric[];
export declare const FrameMetrics: any;
export interface BatchGetFrameMetricDataRequest {
    profilingGroupName: string;
    startTime?: Date;
    endTime?: Date;
    period?: string;
    targetResolution?: string;
    frameMetrics?: FrameMetric[];
}
export declare const BatchGetFrameMetricDataRequest: S.Schema<BatchGetFrameMetricDataRequest>;
export interface TimestampStructure {
    value: Date;
}
export declare const TimestampStructure: S.Schema<TimestampStructure>;
export type ListOfTimestamps = TimestampStructure[];
export declare const ListOfTimestamps: any;
export type UnprocessedEndTimeMap = {
    [key: string]: TimestampStructure[] | undefined;
};
export declare const UnprocessedEndTimeMap: any;
export type FrameMetricValue = number;
export type FrameMetricValues = number[];
export declare const FrameMetricValues: any;
export interface FrameMetricDatum {
    frameMetric: FrameMetric;
    values: number[];
}
export declare const FrameMetricDatum: S.Schema<FrameMetricDatum>;
export type FrameMetricData = FrameMetricDatum[];
export declare const FrameMetricData: any;
export interface BatchGetFrameMetricDataResponse {
    startTime: Date;
    endTime: Date;
    resolution: string;
    endTimes: TimestampStructure[];
    unprocessedEndTimes: {
        [key: string]: TimestampStructure[] | undefined;
    };
    frameMetricData: FrameMetricDatum[];
}
export declare const BatchGetFrameMetricDataResponse: S.Schema<BatchGetFrameMetricDataResponse>;
export type FleetInstanceId = string;
export type MetadataField = string;
export type Metadata = {
    [key: string]: string | undefined;
};
export declare const Metadata: any;
export interface ConfigureAgentRequest {
    profilingGroupName: string;
    fleetInstanceId?: string;
    metadata?: {
        [key: string]: string | undefined;
    };
}
export declare const ConfigureAgentRequest: S.Schema<ConfigureAgentRequest>;
export type AgentParameterField = string;
export type AgentParameters = {
    [key: string]: string | undefined;
};
export declare const AgentParameters: any;
export interface AgentConfiguration {
    shouldProfile: boolean;
    periodInSeconds: number;
    agentParameters?: {
        [key: string]: string | undefined;
    };
}
export declare const AgentConfiguration: S.Schema<AgentConfiguration>;
export interface ConfigureAgentResponse {
    configuration: AgentConfiguration;
}
export declare const ConfigureAgentResponse: S.Schema<ConfigureAgentResponse>;
export type ComputePlatform = string;
export type ClientToken = string;
export interface AgentOrchestrationConfig {
    profilingEnabled: boolean;
}
export declare const AgentOrchestrationConfig: S.Schema<AgentOrchestrationConfig>;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export interface CreateProfilingGroupRequest {
    profilingGroupName: string;
    computePlatform?: string;
    clientToken: string;
    agentOrchestrationConfig?: AgentOrchestrationConfig;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateProfilingGroupRequest: S.Schema<CreateProfilingGroupRequest>;
export type ProfilingGroupArn = string;
export interface AggregatedProfileTime {
    start?: Date;
    period?: string;
}
export declare const AggregatedProfileTime: S.Schema<AggregatedProfileTime>;
export interface ProfilingStatus {
    latestAgentProfileReportedAt?: Date;
    latestAggregatedProfile?: AggregatedProfileTime;
    latestAgentOrchestratedAt?: Date;
}
export declare const ProfilingStatus: S.Schema<ProfilingStatus>;
export interface ProfilingGroupDescription {
    name?: string;
    agentOrchestrationConfig?: AgentOrchestrationConfig;
    arn?: string;
    createdAt?: Date;
    updatedAt?: Date;
    profilingStatus?: ProfilingStatus;
    computePlatform?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ProfilingGroupDescription: S.Schema<ProfilingGroupDescription>;
export interface CreateProfilingGroupResponse {
    profilingGroup: ProfilingGroupDescription;
}
export declare const CreateProfilingGroupResponse: S.Schema<CreateProfilingGroupResponse>;
export interface DeleteProfilingGroupRequest {
    profilingGroupName: string;
}
export declare const DeleteProfilingGroupRequest: S.Schema<DeleteProfilingGroupRequest>;
export interface DeleteProfilingGroupResponse {
}
export declare const DeleteProfilingGroupResponse: S.Schema<DeleteProfilingGroupResponse>;
export interface DescribeProfilingGroupRequest {
    profilingGroupName: string;
}
export declare const DescribeProfilingGroupRequest: S.Schema<DescribeProfilingGroupRequest>;
export interface DescribeProfilingGroupResponse {
    profilingGroup: ProfilingGroupDescription;
}
export declare const DescribeProfilingGroupResponse: S.Schema<DescribeProfilingGroupResponse>;
export type PaginationToken = string;
export type MaxResults = number;
export interface GetFindingsReportAccountSummaryRequest {
    nextToken?: string;
    maxResults?: number;
    dailyReportsOnly?: boolean;
}
export declare const GetFindingsReportAccountSummaryRequest: S.Schema<GetFindingsReportAccountSummaryRequest>;
export type FindingsReportId = string;
export interface FindingsReportSummary {
    id?: string;
    profilingGroupName?: string;
    profileStartTime?: Date;
    profileEndTime?: Date;
    totalNumberOfFindings?: number;
}
export declare const FindingsReportSummary: S.Schema<FindingsReportSummary>;
export type FindingsReportSummaries = FindingsReportSummary[];
export declare const FindingsReportSummaries: any;
export interface GetFindingsReportAccountSummaryResponse {
    reportSummaries: FindingsReportSummary[];
    nextToken?: string;
}
export declare const GetFindingsReportAccountSummaryResponse: S.Schema<GetFindingsReportAccountSummaryResponse>;
export interface GetNotificationConfigurationRequest {
    profilingGroupName: string;
}
export declare const GetNotificationConfigurationRequest: S.Schema<GetNotificationConfigurationRequest>;
export interface GetNotificationConfigurationResponse {
    notificationConfiguration: NotificationConfiguration;
}
export declare const GetNotificationConfigurationResponse: S.Schema<GetNotificationConfigurationResponse>;
export interface GetPolicyRequest {
    profilingGroupName: string;
}
export declare const GetPolicyRequest: S.Schema<GetPolicyRequest>;
export type RevisionId = string;
export interface GetPolicyResponse {
    policy: string;
    revisionId: string;
}
export declare const GetPolicyResponse: S.Schema<GetPolicyResponse>;
export type MaxDepth = number;
export interface GetProfileRequest {
    profilingGroupName: string;
    startTime?: Date;
    period?: string;
    endTime?: Date;
    maxDepth?: number;
    accept?: string;
}
export declare const GetProfileRequest: S.Schema<GetProfileRequest>;
export interface GetProfileResponse {
    profile: T.StreamingOutputBody;
    contentType: string;
    contentEncoding?: string;
}
export declare const GetProfileResponse: S.Schema<GetProfileResponse>;
export type Locale = string;
export interface GetRecommendationsRequest {
    profilingGroupName: string;
    startTime: Date;
    endTime: Date;
    locale?: string;
}
export declare const GetRecommendationsRequest: S.Schema<GetRecommendationsRequest>;
export type TargetFrame = string[];
export declare const TargetFrame: any;
export type TargetFrames = string[][];
export declare const TargetFrames: any;
export type Percentage = number;
export type Strings = string[];
export declare const Strings: any;
export interface Pattern {
    id?: string;
    name?: string;
    description?: string;
    resolutionSteps?: string;
    targetFrames?: string[][];
    thresholdPercent?: number;
    countersToAggregate?: string[];
}
export declare const Pattern: S.Schema<Pattern>;
export interface Match {
    targetFramesIndex?: number;
    frameAddress?: string;
    thresholdBreachValue?: number;
}
export declare const Match: S.Schema<Match>;
export type Matches = Match[];
export declare const Matches: any;
export interface Recommendation {
    allMatchesCount: number;
    allMatchesSum: number;
    pattern: Pattern;
    topMatches: Match[];
    startTime: Date;
    endTime: Date;
}
export declare const Recommendation: S.Schema<Recommendation>;
export type Recommendations = Recommendation[];
export declare const Recommendations: any;
export interface Metric {
    frameName: string;
    type: string;
    threadStates: string[];
}
export declare const Metric: S.Schema<Metric>;
export type FeedbackType = string;
export interface UserFeedback {
    type: string;
}
export declare const UserFeedback: S.Schema<UserFeedback>;
export interface AnomalyInstance {
    id: string;
    startTime: Date;
    endTime?: Date;
    userFeedback?: UserFeedback;
}
export declare const AnomalyInstance: S.Schema<AnomalyInstance>;
export type AnomalyInstances = AnomalyInstance[];
export declare const AnomalyInstances: any;
export interface Anomaly {
    metric: Metric;
    reason: string;
    instances: AnomalyInstance[];
}
export declare const Anomaly: S.Schema<Anomaly>;
export type Anomalies = Anomaly[];
export declare const Anomalies: any;
export interface GetRecommendationsResponse {
    profilingGroupName: string;
    profileStartTime: Date;
    profileEndTime: Date;
    recommendations: Recommendation[];
    anomalies: Anomaly[];
}
export declare const GetRecommendationsResponse: S.Schema<GetRecommendationsResponse>;
export interface ListFindingsReportsRequest {
    profilingGroupName: string;
    startTime: Date;
    endTime: Date;
    nextToken?: string;
    maxResults?: number;
    dailyReportsOnly?: boolean;
}
export declare const ListFindingsReportsRequest: S.Schema<ListFindingsReportsRequest>;
export interface ListFindingsReportsResponse {
    findingsReportSummaries: FindingsReportSummary[];
    nextToken?: string;
}
export declare const ListFindingsReportsResponse: S.Schema<ListFindingsReportsResponse>;
export type OrderBy = string;
export interface ListProfileTimesRequest {
    profilingGroupName: string;
    startTime: Date;
    endTime: Date;
    period: string;
    orderBy?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListProfileTimesRequest: S.Schema<ListProfileTimesRequest>;
export interface ProfileTime {
    start?: Date;
}
export declare const ProfileTime: S.Schema<ProfileTime>;
export type ProfileTimes = ProfileTime[];
export declare const ProfileTimes: any;
export interface ListProfileTimesResponse {
    profileTimes: ProfileTime[];
    nextToken?: string;
}
export declare const ListProfileTimesResponse: S.Schema<ListProfileTimesResponse>;
export interface ListProfilingGroupsRequest {
    nextToken?: string;
    maxResults?: number;
    includeDescription?: boolean;
}
export declare const ListProfilingGroupsRequest: S.Schema<ListProfilingGroupsRequest>;
export type ProfilingGroupNames = string[];
export declare const ProfilingGroupNames: any;
export type ProfilingGroupDescriptions = ProfilingGroupDescription[];
export declare const ProfilingGroupDescriptions: any;
export interface ListProfilingGroupsResponse {
    profilingGroupNames: string[];
    profilingGroups?: ProfilingGroupDescription[];
    nextToken?: string;
}
export declare const ListProfilingGroupsResponse: S.Schema<ListProfilingGroupsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PostAgentProfileRequest {
    profilingGroupName: string;
    agentProfile: T.StreamingInputBody;
    profileToken?: string;
    contentType: string;
}
export declare const PostAgentProfileRequest: S.Schema<PostAgentProfileRequest>;
export interface PostAgentProfileResponse {
}
export declare const PostAgentProfileResponse: S.Schema<PostAgentProfileResponse>;
export type ActionGroup = string;
export type Principal = string;
export type Principals = string[];
export declare const Principals: any;
export interface PutPermissionRequest {
    profilingGroupName: string;
    actionGroup: string;
    principals: string[];
    revisionId?: string;
}
export declare const PutPermissionRequest: S.Schema<PutPermissionRequest>;
export interface PutPermissionResponse {
    policy: string;
    revisionId: string;
}
export declare const PutPermissionResponse: S.Schema<PutPermissionResponse>;
export interface RemoveNotificationChannelRequest {
    profilingGroupName: string;
    channelId: string;
}
export declare const RemoveNotificationChannelRequest: S.Schema<RemoveNotificationChannelRequest>;
export interface RemoveNotificationChannelResponse {
    notificationConfiguration?: NotificationConfiguration;
}
export declare const RemoveNotificationChannelResponse: S.Schema<RemoveNotificationChannelResponse>;
export interface RemovePermissionRequest {
    profilingGroupName: string;
    actionGroup: string;
    revisionId: string;
}
export declare const RemovePermissionRequest: S.Schema<RemovePermissionRequest>;
export interface RemovePermissionResponse {
    policy: string;
    revisionId: string;
}
export declare const RemovePermissionResponse: S.Schema<RemovePermissionResponse>;
export type AnomalyInstanceId = string;
export interface SubmitFeedbackRequest {
    profilingGroupName: string;
    anomalyInstanceId: string;
    type: string;
    comment?: string;
}
export declare const SubmitFeedbackRequest: S.Schema<SubmitFeedbackRequest>;
export interface SubmitFeedbackResponse {
}
export declare const SubmitFeedbackResponse: S.Schema<SubmitFeedbackResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateProfilingGroupRequest {
    profilingGroupName: string;
    agentOrchestrationConfig: AgentOrchestrationConfig;
}
export declare const UpdateProfilingGroupRequest: S.Schema<UpdateProfilingGroupRequest>;
export interface UpdateProfilingGroupResponse {
    profilingGroup: ProfilingGroupDescription;
}
export declare const UpdateProfilingGroupResponse: S.Schema<UpdateProfilingGroupResponse>;
export type AddNotificationChannelsError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Add up to 2 anomaly notifications channels for a profiling group.
 */
export declare const addNotificationChannels: API.OperationMethod<AddNotificationChannelsRequest, AddNotificationChannelsResponse, AddNotificationChannelsError, Credentials | HttpClient.HttpClient>;
export type BatchGetFrameMetricDataError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the time series of values for a requested list
 * of frame metrics from a time period.
 */
export declare const batchGetFrameMetricData: API.OperationMethod<BatchGetFrameMetricDataRequest, BatchGetFrameMetricDataResponse, BatchGetFrameMetricDataError, Credentials | HttpClient.HttpClient>;
export type ConfigureAgentError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Used by profiler agents to report their current state and to receive remote
 * configuration updates. For example, `ConfigureAgent` can be used
 * to tell an agent whether to profile or not and for how long to return profiling data.
 */
export declare const configureAgent: API.OperationMethod<ConfigureAgentRequest, ConfigureAgentResponse, ConfigureAgentError, Credentials | HttpClient.HttpClient>;
export type CreateProfilingGroupError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a profiling group.
 */
export declare const createProfilingGroup: API.OperationMethod<CreateProfilingGroupRequest, CreateProfilingGroupResponse, CreateProfilingGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteProfilingGroupError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a profiling group.
 */
export declare const deleteProfilingGroup: API.OperationMethod<DeleteProfilingGroupRequest, DeleteProfilingGroupResponse, DeleteProfilingGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeProfilingGroupError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a
 * `ProfilingGroupDescription`
 *
 * object that contains information about the requested profiling group.
 */
export declare const describeProfilingGroup: API.OperationMethod<DescribeProfilingGroupRequest, DescribeProfilingGroupResponse, DescribeProfilingGroupError, Credentials | HttpClient.HttpClient>;
export type GetFindingsReportAccountSummaryError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of
 *
 * `FindingsReportSummary`
 *
 * objects that contain analysis results for all profiling groups in your AWS account.
 */
export declare const getFindingsReportAccountSummary: API.PaginatedOperationMethod<GetFindingsReportAccountSummaryRequest, GetFindingsReportAccountSummaryResponse, GetFindingsReportAccountSummaryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetNotificationConfigurationError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the current configuration for anomaly notifications for a profiling group.
 */
export declare const getNotificationConfiguration: API.OperationMethod<GetNotificationConfigurationRequest, GetNotificationConfigurationResponse, GetNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the JSON-formatted resource-based policy on a profiling group.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest, GetPolicyResponse, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetProfileError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the aggregated profile of a profiling group for a specified time range.
 * Amazon CodeGuru Profiler collects posted agent profiles for a profiling group
 * into aggregated profiles.
 *
 * Because aggregated profiles expire over time `GetProfile` is not idempotent.
 *
 * Specify the time range for the requested aggregated profile using 1 or 2 of the following parameters: `startTime`,
 * `endTime`, `period`. The maximum time range allowed is 7 days. If you specify all 3 parameters,
 * an exception is thrown. If you specify only `period`, the latest aggregated profile is returned.
 *
 * Aggregated profiles are available with aggregation periods of 5 minutes, 1 hour, and 1 day, aligned to
 * UTC. The aggregation period of an aggregated profile determines how long it is retained. For more
 * information, see
 * `AggregatedProfileTime`
 * . The aggregated profile's aggregation period determines how long
 * it is retained by CodeGuru Profiler.
 *
 * - If the aggregation period is 5 minutes, the aggregated profile is retained for 15 days.
 *
 * - If the aggregation period is 1 hour, the aggregated profile is retained for 60 days.
 *
 * - If the aggregation period is 1 day, the aggregated profile is retained for 3 years.
 *
 * There are two use cases for calling `GetProfile`.
 *
 * - If you want to return an aggregated profile that already exists, use
 *
 * `ListProfileTimes`
 * to
 * view the time ranges of existing aggregated profiles. Use them in a `GetProfile` request to return a specific,
 * existing aggregated profile.
 *
 * - If you want to return an aggregated profile for a time range that doesn't align with an existing aggregated profile,
 * then CodeGuru Profiler makes a best effort to combine existing aggregated profiles from the requested time
 * range and return them as one aggregated profile.
 *
 * If aggregated profiles do not exist for the full time range requested, then
 * aggregated profiles for a smaller time range are returned. For example, if the
 * requested time range is from 00:00 to 00:20, and the existing aggregated profiles are
 * from 00:15 and 00:25, then the aggregated profiles from 00:15 to 00:20 are returned.
 */
export declare const getProfile: API.OperationMethod<GetProfileRequest, GetProfileResponse, GetProfileError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of
 *
 * `Recommendation`
 *
 * objects that contain recommendations for a profiling group for a given time period. A list of
 *
 * `Anomaly`
 *
 * objects that contains details about anomalies detected in the profiling group for the same time period is also
 * returned.
 */
export declare const getRecommendations: API.OperationMethod<GetRecommendationsRequest, GetRecommendationsResponse, GetRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ListFindingsReportsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the available reports for a given profiling group and time range.
 */
export declare const listFindingsReports: API.PaginatedOperationMethod<ListFindingsReportsRequest, ListFindingsReportsResponse, ListFindingsReportsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProfileTimesError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the start times of the available aggregated profiles of a profiling group
 * for an aggregation period within the specified time range.
 */
export declare const listProfileTimes: API.PaginatedOperationMethod<ListProfileTimesRequest, ListProfileTimesResponse, ListProfileTimesError, Credentials | HttpClient.HttpClient, ProfileTime>;
export type ListProfilingGroupsError = InternalServerException | ThrottlingException | CommonErrors;
/**
 * Returns a list of profiling groups. The profiling groups are returned as
 *
 * `ProfilingGroupDescription`
 *
 * objects.
 */
export declare const listProfilingGroups: API.PaginatedOperationMethod<ListProfilingGroupsRequest, ListProfilingGroupsResponse, ListProfilingGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of the tags that are assigned to a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PostAgentProfileError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Submits profiling data to an aggregated profile of a profiling group. To get an
 * aggregated profile that is created with this profiling data, use
 *
 * `GetProfile`
 * .
 */
export declare const postAgentProfile: API.OperationMethod<PostAgentProfileRequest, PostAgentProfileResponse, PostAgentProfileError, Credentials | HttpClient.HttpClient>;
export type PutPermissionError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds permissions to a profiling group's resource-based policy
 * that are provided using an action group. If a profiling group doesn't have
 * a resource-based policy, one is created for it using the permissions in the action group and
 * the roles and users in the `principals` parameter.
 *
 * The one supported action group that can be added is `agentPermission`
 * which grants `ConfigureAgent` and `PostAgent` permissions. For
 * more information, see Resource-based
 * policies in CodeGuru Profiler in the Amazon CodeGuru Profiler User
 * Guide,
 * `ConfigureAgent`
 * , and
 * `PostAgentProfile`
 * .
 *
 * The first time you call `PutPermission` on a profiling group, do not specify a `revisionId` because
 * it doesn't have a resource-based policy. Subsequent calls must provide a `revisionId` to specify
 * which revision of the resource-based policy to add the permissions to.
 *
 * The response contains the profiling group's JSON-formatted resource policy.
 */
export declare const putPermission: API.OperationMethod<PutPermissionRequest, PutPermissionResponse, PutPermissionError, Credentials | HttpClient.HttpClient>;
export type RemoveNotificationChannelError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove one anomaly notifications channel for a profiling group.
 */
export declare const removeNotificationChannel: API.OperationMethod<RemoveNotificationChannelRequest, RemoveNotificationChannelResponse, RemoveNotificationChannelError, Credentials | HttpClient.HttpClient>;
export type RemovePermissionError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes permissions from a profiling group's resource-based policy that are provided
 * using an action group. The one supported action group that can be removed is
 * `agentPermission` which grants `ConfigureAgent` and
 * `PostAgent` permissions. For more information, see Resource-based policies in CodeGuru Profiler in the Amazon
 * CodeGuru Profiler User Guide,
 * `ConfigureAgent`
 * , and
 * `PostAgentProfile`
 * .
 */
export declare const removePermission: API.OperationMethod<RemovePermissionRequest, RemovePermissionResponse, RemovePermissionError, Credentials | HttpClient.HttpClient>;
export type SubmitFeedbackError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends feedback to CodeGuru Profiler about whether the anomaly detected by the analysis is
 * useful or not.
 */
export declare const submitFeedback: API.OperationMethod<SubmitFeedbackRequest, SubmitFeedbackResponse, SubmitFeedbackError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Use to assign one or more tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Use to remove one or more tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateProfilingGroupError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a profiling group.
 */
export declare const updateProfilingGroup: API.OperationMethod<UpdateProfilingGroupRequest, UpdateProfilingGroupResponse, UpdateProfilingGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codeguruprofiler.d.ts.map