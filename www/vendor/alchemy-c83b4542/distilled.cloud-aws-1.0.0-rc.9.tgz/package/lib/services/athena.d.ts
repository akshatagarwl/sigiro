import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const DataCatalogNotFound_base: S.Class<DataCatalogNotFound, S.TaggedStruct<"DataCatalogNotFound", {
    readonly AthenaErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class DataCatalogNotFound extends /*@__PURE__*/ DataCatalogNotFound_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly AthenaErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const MetadataException_base: S.Class<MetadataException, S.TaggedStruct<"MetadataException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MetadataException extends /*@__PURE__*/ MetadataException_base {
}
declare const NamedQueryNotFound_base: S.Class<NamedQueryNotFound, S.TaggedStruct<"NamedQueryNotFound", {
    readonly AthenaErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class NamedQueryNotFound extends /*@__PURE__*/ NamedQueryNotFound_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceName: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const SessionAlreadyExistsException_base: S.Class<SessionAlreadyExistsException, S.TaggedStruct<"SessionAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class SessionAlreadyExistsException extends /*@__PURE__*/ SessionAlreadyExistsException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly message: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError>;
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const WorkGroupNotFound_base: S.Class<WorkGroupNotFound, S.TaggedStruct<"WorkGroupNotFound", {
    readonly AthenaErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class WorkGroupNotFound extends /*@__PURE__*/ WorkGroupNotFound_base {
}
export type NamedQueryId = string;
export type NamedQueryIdList = string[];
export declare const NamedQueryIdList: any;
export interface BatchGetNamedQueryInput {
    NamedQueryIds: string[];
}
export declare const BatchGetNamedQueryInput: S.Schema<BatchGetNamedQueryInput>;
export type NameString = string;
export type DescriptionString = string;
export type DatabaseString = string;
export type QueryString = string;
export type WorkGroupName = string;
export interface NamedQuery {
    Name: string;
    Description?: string;
    Database: string;
    QueryString: string;
    NamedQueryId?: string;
    WorkGroup?: string;
}
export declare const NamedQuery: S.Schema<NamedQuery>;
export type NamedQueryList = NamedQuery[];
export declare const NamedQueryList: any;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface UnprocessedNamedQueryId {
    NamedQueryId?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const UnprocessedNamedQueryId: S.Schema<UnprocessedNamedQueryId>;
export type UnprocessedNamedQueryIdList = UnprocessedNamedQueryId[];
export declare const UnprocessedNamedQueryIdList: any;
export interface BatchGetNamedQueryOutput {
    NamedQueries?: NamedQuery[];
    UnprocessedNamedQueryIds?: UnprocessedNamedQueryId[];
}
export declare const BatchGetNamedQueryOutput: S.Schema<BatchGetNamedQueryOutput>;
export type StatementName = string;
export type PreparedStatementNameList = string[];
export declare const PreparedStatementNameList: any;
export interface BatchGetPreparedStatementInput {
    PreparedStatementNames: string[];
    WorkGroup: string;
}
export declare const BatchGetPreparedStatementInput: S.Schema<BatchGetPreparedStatementInput>;
export interface PreparedStatement {
    StatementName?: string;
    QueryStatement?: string;
    WorkGroupName?: string;
    Description?: string;
    LastModifiedTime?: Date;
}
export declare const PreparedStatement: S.Schema<PreparedStatement>;
export type PreparedStatementDetailsList = PreparedStatement[];
export declare const PreparedStatementDetailsList: any;
export interface UnprocessedPreparedStatementName {
    StatementName?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const UnprocessedPreparedStatementName: S.Schema<UnprocessedPreparedStatementName>;
export type UnprocessedPreparedStatementNameList = UnprocessedPreparedStatementName[];
export declare const UnprocessedPreparedStatementNameList: any;
export interface BatchGetPreparedStatementOutput {
    PreparedStatements?: PreparedStatement[];
    UnprocessedPreparedStatementNames?: UnprocessedPreparedStatementName[];
}
export declare const BatchGetPreparedStatementOutput: S.Schema<BatchGetPreparedStatementOutput>;
export type QueryExecutionId = string;
export type QueryExecutionIdList = string[];
export declare const QueryExecutionIdList: any;
export interface BatchGetQueryExecutionInput {
    QueryExecutionIds: string[];
}
export declare const BatchGetQueryExecutionInput: S.Schema<BatchGetQueryExecutionInput>;
export type StatementType = "DDL" | "DML" | "UTILITY" | (string & {});
export declare const StatementType: any;
export type KmsKey = string;
export interface ManagedQueryResultsEncryptionConfiguration {
    KmsKey: string;
}
export declare const ManagedQueryResultsEncryptionConfiguration: S.Schema<ManagedQueryResultsEncryptionConfiguration>;
export interface ManagedQueryResultsConfiguration {
    Enabled: boolean;
    EncryptionConfiguration?: ManagedQueryResultsEncryptionConfiguration;
}
export declare const ManagedQueryResultsConfiguration: S.Schema<ManagedQueryResultsConfiguration>;
export type ResultOutputLocation = string;
export type EncryptionOption = "SSE_S3" | "SSE_KMS" | "CSE_KMS" | (string & {});
export declare const EncryptionOption: any;
export interface EncryptionConfiguration {
    EncryptionOption: EncryptionOption;
    KmsKey?: string;
}
export declare const EncryptionConfiguration: S.Schema<EncryptionConfiguration>;
export type AwsAccountId = string;
export type S3AclOption = "BUCKET_OWNER_FULL_CONTROL" | (string & {});
export declare const S3AclOption: any;
export interface AclConfiguration {
    S3AclOption: S3AclOption;
}
export declare const AclConfiguration: S.Schema<AclConfiguration>;
export interface ResultConfiguration {
    OutputLocation?: string;
    EncryptionConfiguration?: EncryptionConfiguration;
    ExpectedBucketOwner?: string;
    AclConfiguration?: AclConfiguration;
}
export declare const ResultConfiguration: S.Schema<ResultConfiguration>;
export type Age = number;
export interface ResultReuseByAgeConfiguration {
    Enabled: boolean;
    MaxAgeInMinutes?: number;
}
export declare const ResultReuseByAgeConfiguration: S.Schema<ResultReuseByAgeConfiguration>;
export interface ResultReuseConfiguration {
    ResultReuseByAgeConfiguration?: ResultReuseByAgeConfiguration;
}
export declare const ResultReuseConfiguration: S.Schema<ResultReuseConfiguration>;
export type CatalogNameString = string;
export interface QueryExecutionContext {
    Database?: string;
    Catalog?: string;
}
export declare const QueryExecutionContext: S.Schema<QueryExecutionContext>;
export type QueryExecutionState = "QUEUED" | "RUNNING" | "SUCCEEDED" | "FAILED" | "CANCELLED" | (string & {});
export declare const QueryExecutionState: any;
export type ErrorCategory = number;
export type ErrorType = number;
export interface AthenaError {
    ErrorCategory?: number;
    ErrorType?: number;
    Retryable?: boolean;
    ErrorMessage?: string;
}
export declare const AthenaError: S.Schema<AthenaError>;
export interface QueryExecutionStatus {
    State?: QueryExecutionState;
    StateChangeReason?: string;
    SubmissionDateTime?: Date;
    CompletionDateTime?: Date;
    AthenaError?: AthenaError;
}
export declare const QueryExecutionStatus: S.Schema<QueryExecutionStatus>;
export interface ResultReuseInformation {
    ReusedPreviousResult: boolean;
}
export declare const ResultReuseInformation: S.Schema<ResultReuseInformation>;
export type DpuCount = number;
export interface QueryExecutionStatistics {
    EngineExecutionTimeInMillis?: number;
    DataScannedInBytes?: number;
    DataManifestLocation?: string;
    TotalExecutionTimeInMillis?: number;
    QueryQueueTimeInMillis?: number;
    ServicePreProcessingTimeInMillis?: number;
    QueryPlanningTimeInMillis?: number;
    ServiceProcessingTimeInMillis?: number;
    ResultReuseInformation?: ResultReuseInformation;
    DpuCount?: number;
}
export declare const QueryExecutionStatistics: S.Schema<QueryExecutionStatistics>;
export interface EngineVersion {
    SelectedEngineVersion?: string;
    EffectiveEngineVersion?: string;
}
export declare const EngineVersion: S.Schema<EngineVersion>;
export type ExecutionParameter = string;
export type ExecutionParameters = string[];
export declare const ExecutionParameters: any;
export type BoxedBoolean = boolean;
export type AuthenticationType = "DIRECTORY_IDENTITY" | (string & {});
export declare const AuthenticationType: any;
export interface QueryResultsS3AccessGrantsConfiguration {
    EnableS3AccessGrants: boolean;
    CreateUserLevelPrefix?: boolean;
    AuthenticationType: AuthenticationType;
}
export declare const QueryResultsS3AccessGrantsConfiguration: S.Schema<QueryResultsS3AccessGrantsConfiguration>;
export interface QueryExecution {
    QueryExecutionId?: string;
    Query?: string;
    StatementType?: StatementType;
    ManagedQueryResultsConfiguration?: ManagedQueryResultsConfiguration;
    ResultConfiguration?: ResultConfiguration;
    ResultReuseConfiguration?: ResultReuseConfiguration;
    QueryExecutionContext?: QueryExecutionContext;
    Status?: QueryExecutionStatus;
    Statistics?: QueryExecutionStatistics;
    WorkGroup?: string;
    EngineVersion?: EngineVersion;
    ExecutionParameters?: string[];
    SubstatementType?: string;
    QueryResultsS3AccessGrantsConfiguration?: QueryResultsS3AccessGrantsConfiguration;
}
export declare const QueryExecution: S.Schema<QueryExecution>;
export type QueryExecutionList = QueryExecution[];
export declare const QueryExecutionList: any;
export interface UnprocessedQueryExecutionId {
    QueryExecutionId?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const UnprocessedQueryExecutionId: S.Schema<UnprocessedQueryExecutionId>;
export type UnprocessedQueryExecutionIdList = UnprocessedQueryExecutionId[];
export declare const UnprocessedQueryExecutionIdList: any;
export interface BatchGetQueryExecutionOutput {
    QueryExecutions?: QueryExecution[];
    UnprocessedQueryExecutionIds?: UnprocessedQueryExecutionId[];
}
export declare const BatchGetQueryExecutionOutput: S.Schema<BatchGetQueryExecutionOutput>;
export type CapacityReservationName = string;
export interface CancelCapacityReservationInput {
    Name: string;
}
export declare const CancelCapacityReservationInput: S.Schema<CancelCapacityReservationInput>;
export interface CancelCapacityReservationOutput {
}
export declare const CancelCapacityReservationOutput: S.Schema<CancelCapacityReservationOutput>;
export type TargetDpusInteger = number;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateCapacityReservationInput {
    TargetDpus: number;
    Name: string;
    Tags?: Tag[];
}
export declare const CreateCapacityReservationInput: S.Schema<CreateCapacityReservationInput>;
export interface CreateCapacityReservationOutput {
}
export declare const CreateCapacityReservationOutput: S.Schema<CreateCapacityReservationOutput>;
export type DataCatalogType = "LAMBDA" | "GLUE" | "HIVE" | "FEDERATED" | (string & {});
export declare const DataCatalogType: any;
export type KeyString = string;
export type ParametersMapValue = string;
export type ParametersMap = {
    [key: string]: string | undefined;
};
export declare const ParametersMap: any;
export interface CreateDataCatalogInput {
    Name: string;
    Type: DataCatalogType;
    Description?: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
    Tags?: Tag[];
}
export declare const CreateDataCatalogInput: S.Schema<CreateDataCatalogInput>;
export type DataCatalogStatus = "CREATE_IN_PROGRESS" | "CREATE_COMPLETE" | "CREATE_FAILED" | "CREATE_FAILED_CLEANUP_IN_PROGRESS" | "CREATE_FAILED_CLEANUP_COMPLETE" | "CREATE_FAILED_CLEANUP_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_COMPLETE" | "DELETE_FAILED" | (string & {});
export declare const DataCatalogStatus: any;
export type ConnectionType = "DYNAMODB" | "MYSQL" | "POSTGRESQL" | "REDSHIFT" | "ORACLE" | "SYNAPSE" | "SQLSERVER" | "DB2" | "OPENSEARCH" | "BIGQUERY" | "GOOGLECLOUDSTORAGE" | "HBASE" | "DOCUMENTDB" | "CMDB" | "TPCDS" | "TIMESTREAM" | "SAPHANA" | "SNOWFLAKE" | "DATALAKEGEN2" | "DB2AS400" | (string & {});
export declare const ConnectionType: any;
export interface DataCatalog {
    Name: string;
    Description?: string;
    Type: DataCatalogType;
    Parameters?: {
        [key: string]: string | undefined;
    };
    Status?: DataCatalogStatus;
    ConnectionType?: ConnectionType;
    Error?: string;
}
export declare const DataCatalog: S.Schema<DataCatalog>;
export interface CreateDataCatalogOutput {
    DataCatalog?: DataCatalog;
}
export declare const CreateDataCatalogOutput: S.Schema<CreateDataCatalogOutput>;
export type IdempotencyToken = string;
export interface CreateNamedQueryInput {
    Name: string;
    Description?: string;
    Database: string;
    QueryString: string;
    ClientRequestToken?: string;
    WorkGroup?: string;
}
export declare const CreateNamedQueryInput: S.Schema<CreateNamedQueryInput>;
export interface CreateNamedQueryOutput {
    NamedQueryId?: string;
}
export declare const CreateNamedQueryOutput: S.Schema<CreateNamedQueryOutput>;
export type NotebookName = string;
export type ClientRequestToken = string;
export interface CreateNotebookInput {
    WorkGroup: string;
    Name: string;
    ClientRequestToken?: string;
}
export declare const CreateNotebookInput: S.Schema<CreateNotebookInput>;
export type NotebookId = string;
export interface CreateNotebookOutput {
    NotebookId?: string;
}
export declare const CreateNotebookOutput: S.Schema<CreateNotebookOutput>;
export interface CreatePreparedStatementInput {
    StatementName: string;
    WorkGroup: string;
    QueryStatement: string;
    Description?: string;
}
export declare const CreatePreparedStatementInput: S.Schema<CreatePreparedStatementInput>;
export interface CreatePreparedStatementOutput {
}
export declare const CreatePreparedStatementOutput: S.Schema<CreatePreparedStatementOutput>;
export type SessionId = string;
export interface CreatePresignedNotebookUrlRequest {
    SessionId: string;
}
export declare const CreatePresignedNotebookUrlRequest: S.Schema<CreatePresignedNotebookUrlRequest>;
export type AuthToken = string;
export interface CreatePresignedNotebookUrlResponse {
    NotebookUrl: string;
    AuthToken: string;
    AuthTokenExpirationTime: number;
}
export declare const CreatePresignedNotebookUrlResponse: S.Schema<CreatePresignedNotebookUrlResponse>;
export type BytesScannedCutoffValue = number;
export type RoleArn = string;
export type LogGroupName = string;
export type LogStreamNamePrefix = string;
export type LogTypeKey = string;
export type LogTypeValue = string;
export type LogTypeValuesList = string[];
export declare const LogTypeValuesList: any;
export type LogTypesMap = {
    [key: string]: string[] | undefined;
};
export declare const LogTypesMap: any;
export interface CloudWatchLoggingConfiguration {
    Enabled: boolean;
    LogGroup?: string;
    LogStreamNamePrefix?: string;
    LogTypes?: {
        [key: string]: string[] | undefined;
    };
}
export declare const CloudWatchLoggingConfiguration: S.Schema<CloudWatchLoggingConfiguration>;
export interface ManagedLoggingConfiguration {
    Enabled: boolean;
    KmsKey?: string;
}
export declare const ManagedLoggingConfiguration: S.Schema<ManagedLoggingConfiguration>;
export type S3OutputLocation = string;
export interface S3LoggingConfiguration {
    Enabled: boolean;
    KmsKey?: string;
    LogLocation?: string;
}
export declare const S3LoggingConfiguration: S.Schema<S3LoggingConfiguration>;
export interface MonitoringConfiguration {
    CloudWatchLoggingConfiguration?: CloudWatchLoggingConfiguration;
    ManagedLoggingConfiguration?: ManagedLoggingConfiguration;
    S3LoggingConfiguration?: S3LoggingConfiguration;
}
export declare const MonitoringConfiguration: S.Schema<MonitoringConfiguration>;
export type CoordinatorDpuSize = number;
export type MaxConcurrentDpus = number;
export type DefaultExecutorDpuSize = number;
export interface Classification {
    Name?: string;
    Properties?: {
        [key: string]: string | undefined;
    };
}
export declare const Classification: S.Schema<Classification>;
export type ClassificationList = Classification[];
export declare const ClassificationList: any;
export interface EngineConfiguration {
    CoordinatorDpuSize?: number;
    MaxConcurrentDpus?: number;
    DefaultExecutorDpuSize?: number;
    AdditionalConfigs?: {
        [key: string]: string | undefined;
    };
    SparkProperties?: {
        [key: string]: string | undefined;
    };
    Classifications?: Classification[];
}
export declare const EngineConfiguration: S.Schema<EngineConfiguration>;
export interface CustomerContentEncryptionConfiguration {
    KmsKey: string;
}
export declare const CustomerContentEncryptionConfiguration: S.Schema<CustomerContentEncryptionConfiguration>;
export type IdentityCenterInstanceArn = string;
export interface IdentityCenterConfiguration {
    EnableIdentityCenter?: boolean;
    IdentityCenterInstanceArn?: string;
}
export declare const IdentityCenterConfiguration: S.Schema<IdentityCenterConfiguration>;
export interface WorkGroupConfiguration {
    ResultConfiguration?: ResultConfiguration;
    ManagedQueryResultsConfiguration?: ManagedQueryResultsConfiguration;
    EnforceWorkGroupConfiguration?: boolean;
    PublishCloudWatchMetricsEnabled?: boolean;
    BytesScannedCutoffPerQuery?: number;
    RequesterPaysEnabled?: boolean;
    EngineVersion?: EngineVersion;
    AdditionalConfiguration?: string;
    ExecutionRole?: string;
    MonitoringConfiguration?: MonitoringConfiguration;
    EngineConfiguration?: EngineConfiguration;
    CustomerContentEncryptionConfiguration?: CustomerContentEncryptionConfiguration;
    EnableMinimumEncryptionConfiguration?: boolean;
    IdentityCenterConfiguration?: IdentityCenterConfiguration;
    QueryResultsS3AccessGrantsConfiguration?: QueryResultsS3AccessGrantsConfiguration;
}
export declare const WorkGroupConfiguration: S.Schema<WorkGroupConfiguration>;
export type WorkGroupDescriptionString = string;
export interface CreateWorkGroupInput {
    Name: string;
    Configuration?: WorkGroupConfiguration;
    Description?: string;
    Tags?: Tag[];
}
export declare const CreateWorkGroupInput: S.Schema<CreateWorkGroupInput>;
export interface CreateWorkGroupOutput {
}
export declare const CreateWorkGroupOutput: S.Schema<CreateWorkGroupOutput>;
export interface DeleteCapacityReservationInput {
    Name: string;
}
export declare const DeleteCapacityReservationInput: S.Schema<DeleteCapacityReservationInput>;
export interface DeleteCapacityReservationOutput {
}
export declare const DeleteCapacityReservationOutput: S.Schema<DeleteCapacityReservationOutput>;
export interface DeleteDataCatalogInput {
    Name: string;
    DeleteCatalogOnly?: boolean;
}
export declare const DeleteDataCatalogInput: S.Schema<DeleteDataCatalogInput>;
export interface DeleteDataCatalogOutput {
    DataCatalog?: DataCatalog;
}
export declare const DeleteDataCatalogOutput: S.Schema<DeleteDataCatalogOutput>;
export interface DeleteNamedQueryInput {
    NamedQueryId: string;
}
export declare const DeleteNamedQueryInput: S.Schema<DeleteNamedQueryInput>;
export interface DeleteNamedQueryOutput {
}
export declare const DeleteNamedQueryOutput: S.Schema<DeleteNamedQueryOutput>;
export interface DeleteNotebookInput {
    NotebookId: string;
}
export declare const DeleteNotebookInput: S.Schema<DeleteNotebookInput>;
export interface DeleteNotebookOutput {
}
export declare const DeleteNotebookOutput: S.Schema<DeleteNotebookOutput>;
export interface DeletePreparedStatementInput {
    StatementName: string;
    WorkGroup: string;
}
export declare const DeletePreparedStatementInput: S.Schema<DeletePreparedStatementInput>;
export interface DeletePreparedStatementOutput {
}
export declare const DeletePreparedStatementOutput: S.Schema<DeletePreparedStatementOutput>;
export interface DeleteWorkGroupInput {
    WorkGroup: string;
    RecursiveDeleteOption?: boolean;
}
export declare const DeleteWorkGroupInput: S.Schema<DeleteWorkGroupInput>;
export interface DeleteWorkGroupOutput {
}
export declare const DeleteWorkGroupOutput: S.Schema<DeleteWorkGroupOutput>;
export interface ExportNotebookInput {
    NotebookId: string;
}
export declare const ExportNotebookInput: S.Schema<ExportNotebookInput>;
export type NotebookType = "IPYNB" | (string & {});
export declare const NotebookType: any;
export interface NotebookMetadata {
    NotebookId?: string;
    Name?: string;
    WorkGroup?: string;
    CreationTime?: Date;
    Type?: NotebookType;
    LastModifiedTime?: Date;
}
export declare const NotebookMetadata: S.Schema<NotebookMetadata>;
export type Payload = string;
export interface ExportNotebookOutput {
    NotebookMetadata?: NotebookMetadata;
    Payload?: string;
}
export declare const ExportNotebookOutput: S.Schema<ExportNotebookOutput>;
export type CalculationExecutionId = string;
export interface GetCalculationExecutionRequest {
    CalculationExecutionId: string;
}
export declare const GetCalculationExecutionRequest: S.Schema<GetCalculationExecutionRequest>;
export type S3Uri = string;
export type CalculationExecutionState = "CREATING" | "CREATED" | "QUEUED" | "RUNNING" | "CANCELING" | "CANCELED" | "COMPLETED" | "FAILED" | (string & {});
export declare const CalculationExecutionState: any;
export interface CalculationStatus {
    SubmissionDateTime?: Date;
    CompletionDateTime?: Date;
    State?: CalculationExecutionState;
    StateChangeReason?: string;
}
export declare const CalculationStatus: S.Schema<CalculationStatus>;
export interface CalculationStatistics {
    DpuExecutionInMillis?: number;
    Progress?: string;
}
export declare const CalculationStatistics: S.Schema<CalculationStatistics>;
export type CalculationResultType = string;
export interface CalculationResult {
    StdOutS3Uri?: string;
    StdErrorS3Uri?: string;
    ResultS3Uri?: string;
    ResultType?: string;
}
export declare const CalculationResult: S.Schema<CalculationResult>;
export interface GetCalculationExecutionResponse {
    CalculationExecutionId?: string;
    SessionId?: string;
    Description?: string;
    WorkingDirectory?: string;
    Status?: CalculationStatus;
    Statistics?: CalculationStatistics;
    Result?: CalculationResult;
}
export declare const GetCalculationExecutionResponse: S.Schema<GetCalculationExecutionResponse>;
export interface GetCalculationExecutionCodeRequest {
    CalculationExecutionId: string;
}
export declare const GetCalculationExecutionCodeRequest: S.Schema<GetCalculationExecutionCodeRequest>;
export type CodeBlock = string;
export interface GetCalculationExecutionCodeResponse {
    CodeBlock?: string;
}
export declare const GetCalculationExecutionCodeResponse: S.Schema<GetCalculationExecutionCodeResponse>;
export interface GetCalculationExecutionStatusRequest {
    CalculationExecutionId: string;
}
export declare const GetCalculationExecutionStatusRequest: S.Schema<GetCalculationExecutionStatusRequest>;
export interface GetCalculationExecutionStatusResponse {
    Status?: CalculationStatus;
    Statistics?: CalculationStatistics;
}
export declare const GetCalculationExecutionStatusResponse: S.Schema<GetCalculationExecutionStatusResponse>;
export interface GetCapacityAssignmentConfigurationInput {
    CapacityReservationName: string;
}
export declare const GetCapacityAssignmentConfigurationInput: S.Schema<GetCapacityAssignmentConfigurationInput>;
export type WorkGroupNamesList = string[];
export declare const WorkGroupNamesList: any;
export interface CapacityAssignment {
    WorkGroupNames?: string[];
}
export declare const CapacityAssignment: S.Schema<CapacityAssignment>;
export type CapacityAssignmentsList = CapacityAssignment[];
export declare const CapacityAssignmentsList: any;
export interface CapacityAssignmentConfiguration {
    CapacityReservationName?: string;
    CapacityAssignments?: CapacityAssignment[];
}
export declare const CapacityAssignmentConfiguration: S.Schema<CapacityAssignmentConfiguration>;
export interface GetCapacityAssignmentConfigurationOutput {
    CapacityAssignmentConfiguration: CapacityAssignmentConfiguration;
}
export declare const GetCapacityAssignmentConfigurationOutput: S.Schema<GetCapacityAssignmentConfigurationOutput>;
export interface GetCapacityReservationInput {
    Name: string;
}
export declare const GetCapacityReservationInput: S.Schema<GetCapacityReservationInput>;
export type CapacityReservationStatus = "PENDING" | "ACTIVE" | "CANCELLING" | "CANCELLED" | "FAILED" | "UPDATE_PENDING" | (string & {});
export declare const CapacityReservationStatus: any;
export type AllocatedDpusInteger = number;
export type CapacityAllocationStatus = "PENDING" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const CapacityAllocationStatus: any;
export interface CapacityAllocation {
    Status: CapacityAllocationStatus;
    StatusMessage?: string;
    RequestTime: Date;
    RequestCompletionTime?: Date;
}
export declare const CapacityAllocation: S.Schema<CapacityAllocation>;
export interface CapacityReservation {
    Name: string;
    Status: CapacityReservationStatus;
    TargetDpus: number;
    AllocatedDpus: number;
    LastAllocation?: CapacityAllocation;
    LastSuccessfulAllocationTime?: Date;
    CreationTime: Date;
}
export declare const CapacityReservation: S.Schema<CapacityReservation>;
export interface GetCapacityReservationOutput {
    CapacityReservation: CapacityReservation;
}
export declare const GetCapacityReservationOutput: S.Schema<GetCapacityReservationOutput>;
export interface GetDatabaseInput {
    CatalogName: string;
    DatabaseName: string;
    WorkGroup?: string;
}
export declare const GetDatabaseInput: S.Schema<GetDatabaseInput>;
export interface Database {
    Name: string;
    Description?: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const Database: S.Schema<Database>;
export interface GetDatabaseOutput {
    Database?: Database;
}
export declare const GetDatabaseOutput: S.Schema<GetDatabaseOutput>;
export interface GetDataCatalogInput {
    Name: string;
    WorkGroup?: string;
}
export declare const GetDataCatalogInput: S.Schema<GetDataCatalogInput>;
export interface GetDataCatalogOutput {
    DataCatalog?: DataCatalog;
}
export declare const GetDataCatalogOutput: S.Schema<GetDataCatalogOutput>;
export interface GetNamedQueryInput {
    NamedQueryId: string;
}
export declare const GetNamedQueryInput: S.Schema<GetNamedQueryInput>;
export interface GetNamedQueryOutput {
    NamedQuery?: NamedQuery;
}
export declare const GetNamedQueryOutput: S.Schema<GetNamedQueryOutput>;
export interface GetNotebookMetadataInput {
    NotebookId: string;
}
export declare const GetNotebookMetadataInput: S.Schema<GetNotebookMetadataInput>;
export interface GetNotebookMetadataOutput {
    NotebookMetadata?: NotebookMetadata;
}
export declare const GetNotebookMetadataOutput: S.Schema<GetNotebookMetadataOutput>;
export interface GetPreparedStatementInput {
    StatementName: string;
    WorkGroup: string;
}
export declare const GetPreparedStatementInput: S.Schema<GetPreparedStatementInput>;
export interface GetPreparedStatementOutput {
    PreparedStatement?: PreparedStatement;
}
export declare const GetPreparedStatementOutput: S.Schema<GetPreparedStatementOutput>;
export interface GetQueryExecutionInput {
    QueryExecutionId: string;
}
export declare const GetQueryExecutionInput: S.Schema<GetQueryExecutionInput>;
export interface GetQueryExecutionOutput {
    QueryExecution?: QueryExecution;
}
export declare const GetQueryExecutionOutput: S.Schema<GetQueryExecutionOutput>;
export type Token = string;
export type MaxQueryResults = number;
export type QueryResultType = "DATA_MANIFEST" | "DATA_ROWS" | (string & {});
export declare const QueryResultType: any;
export interface GetQueryResultsInput {
    QueryExecutionId: string;
    NextToken?: string;
    MaxResults?: number;
    QueryResultType?: QueryResultType;
}
export declare const GetQueryResultsInput: S.Schema<GetQueryResultsInput>;
export type DatumString = string;
export interface Datum {
    VarCharValue?: string;
}
export declare const Datum: S.Schema<Datum>;
export type DatumList = Datum[];
export declare const DatumList: any;
export interface Row {
    Data?: Datum[];
}
export declare const Row: S.Schema<Row>;
export type RowList = Row[];
export declare const RowList: any;
export type ColumnNullable = "NOT_NULL" | "NULLABLE" | "UNKNOWN" | (string & {});
export declare const ColumnNullable: any;
export interface ColumnInfo {
    CatalogName?: string;
    SchemaName?: string;
    TableName?: string;
    Name: string;
    Label?: string;
    Type: string;
    Precision?: number;
    Scale?: number;
    Nullable?: ColumnNullable;
    CaseSensitive?: boolean;
}
export declare const ColumnInfo: S.Schema<ColumnInfo>;
export type ColumnInfoList = ColumnInfo[];
export declare const ColumnInfoList: any;
export interface ResultSetMetadata {
    ColumnInfo?: ColumnInfo[];
}
export declare const ResultSetMetadata: S.Schema<ResultSetMetadata>;
export interface ResultSet {
    Rows?: Row[];
    ResultSetMetadata?: ResultSetMetadata;
}
export declare const ResultSet: S.Schema<ResultSet>;
export interface GetQueryResultsOutput {
    UpdateCount?: number;
    ResultSet?: ResultSet;
    NextToken?: string;
}
export declare const GetQueryResultsOutput: S.Schema<GetQueryResultsOutput>;
export interface GetQueryRuntimeStatisticsInput {
    QueryExecutionId: string;
}
export declare const GetQueryRuntimeStatisticsInput: S.Schema<GetQueryRuntimeStatisticsInput>;
export interface QueryRuntimeStatisticsTimeline {
    QueryQueueTimeInMillis?: number;
    ServicePreProcessingTimeInMillis?: number;
    QueryPlanningTimeInMillis?: number;
    EngineExecutionTimeInMillis?: number;
    ServiceProcessingTimeInMillis?: number;
    TotalExecutionTimeInMillis?: number;
}
export declare const QueryRuntimeStatisticsTimeline: S.Schema<QueryRuntimeStatisticsTimeline>;
export interface QueryRuntimeStatisticsRows {
    InputRows?: number;
    InputBytes?: number;
    OutputBytes?: number;
    OutputRows?: number;
}
export declare const QueryRuntimeStatisticsRows: S.Schema<QueryRuntimeStatisticsRows>;
export type QueryStagePlanNodes = QueryStagePlanNode[];
export declare const QueryStagePlanNodes: S.Schema<QueryStagePlanNodes>;
export type StringList = string[];
export declare const StringList: any;
export interface QueryStagePlanNode {
    Name?: string;
    Identifier?: string;
    Children?: QueryStagePlanNode[];
    RemoteSources?: string[];
}
export declare const QueryStagePlanNode: S.Schema<QueryStagePlanNode>;
export type QueryStages = QueryStage[];
export declare const QueryStages: S.Schema<QueryStages>;
export interface QueryStage {
    StageId?: number;
    State?: string;
    OutputBytes?: number;
    OutputRows?: number;
    InputBytes?: number;
    InputRows?: number;
    ExecutionTime?: number;
    QueryStagePlan?: QueryStagePlanNode;
    SubStages?: QueryStage[];
}
export declare const QueryStage: S.Schema<QueryStage>;
export interface QueryRuntimeStatistics {
    Timeline?: QueryRuntimeStatisticsTimeline;
    Rows?: QueryRuntimeStatisticsRows;
    OutputStage?: QueryStage;
}
export declare const QueryRuntimeStatistics: S.Schema<QueryRuntimeStatistics>;
export interface GetQueryRuntimeStatisticsOutput {
    QueryRuntimeStatistics?: QueryRuntimeStatistics;
}
export declare const GetQueryRuntimeStatisticsOutput: S.Schema<GetQueryRuntimeStatisticsOutput>;
export type AmazonResourceName = string;
export interface GetResourceDashboardRequest {
    ResourceARN: string;
}
export declare const GetResourceDashboardRequest: S.Schema<GetResourceDashboardRequest>;
export interface GetResourceDashboardResponse {
    Url: string;
}
export declare const GetResourceDashboardResponse: S.Schema<GetResourceDashboardResponse>;
export interface GetSessionRequest {
    SessionId: string;
}
export declare const GetSessionRequest: S.Schema<GetSessionRequest>;
export type SessionIdleTimeoutInMinutes = number;
export interface SessionConfiguration {
    ExecutionRole?: string;
    WorkingDirectory?: string;
    IdleTimeoutSeconds?: number;
    SessionIdleTimeoutInMinutes?: number;
    EncryptionConfiguration?: EncryptionConfiguration;
}
export declare const SessionConfiguration: S.Schema<SessionConfiguration>;
export type SessionState = "CREATING" | "CREATED" | "IDLE" | "BUSY" | "TERMINATING" | "TERMINATED" | "DEGRADED" | "FAILED" | (string & {});
export declare const SessionState: any;
export interface SessionStatus {
    StartDateTime?: Date;
    LastModifiedDateTime?: Date;
    EndDateTime?: Date;
    IdleSinceDateTime?: Date;
    State?: SessionState;
    StateChangeReason?: string;
}
export declare const SessionStatus: S.Schema<SessionStatus>;
export interface SessionStatistics {
    DpuExecutionInMillis?: number;
}
export declare const SessionStatistics: S.Schema<SessionStatistics>;
export interface GetSessionResponse {
    SessionId?: string;
    Description?: string;
    WorkGroup?: string;
    EngineVersion?: string;
    EngineConfiguration?: EngineConfiguration;
    NotebookVersion?: string;
    MonitoringConfiguration?: MonitoringConfiguration;
    SessionConfiguration?: SessionConfiguration;
    Status?: SessionStatus;
    Statistics?: SessionStatistics;
}
export declare const GetSessionResponse: S.Schema<GetSessionResponse>;
export interface GetSessionEndpointRequest {
    SessionId: string;
}
export declare const GetSessionEndpointRequest: S.Schema<GetSessionEndpointRequest>;
export interface GetSessionEndpointResponse {
    EndpointUrl: string;
    AuthToken: string;
    AuthTokenExpirationTime: Date;
}
export declare const GetSessionEndpointResponse: S.Schema<GetSessionEndpointResponse>;
export interface GetSessionStatusRequest {
    SessionId: string;
}
export declare const GetSessionStatusRequest: S.Schema<GetSessionStatusRequest>;
export interface GetSessionStatusResponse {
    SessionId?: string;
    Status?: SessionStatus;
}
export declare const GetSessionStatusResponse: S.Schema<GetSessionStatusResponse>;
export interface GetTableMetadataInput {
    CatalogName: string;
    DatabaseName: string;
    TableName: string;
    WorkGroup?: string;
}
export declare const GetTableMetadataInput: S.Schema<GetTableMetadataInput>;
export type TableTypeString = string;
export type TypeString = string;
export type CommentString = string;
export interface Column {
    Name: string;
    Type?: string;
    Comment?: string;
}
export declare const Column: S.Schema<Column>;
export type ColumnList = Column[];
export declare const ColumnList: any;
export interface TableMetadata {
    Name: string;
    CreateTime?: Date;
    LastAccessTime?: Date;
    TableType?: string;
    Columns?: Column[];
    PartitionKeys?: Column[];
    Parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const TableMetadata: S.Schema<TableMetadata>;
export interface GetTableMetadataOutput {
    TableMetadata?: TableMetadata;
}
export declare const GetTableMetadataOutput: S.Schema<GetTableMetadataOutput>;
export interface GetWorkGroupInput {
    WorkGroup: string;
}
export declare const GetWorkGroupInput: S.Schema<GetWorkGroupInput>;
export type WorkGroupState = "ENABLED" | "DISABLED" | (string & {});
export declare const WorkGroupState: any;
export type IdentityCenterApplicationArn = string;
export interface WorkGroup {
    Name: string;
    State?: WorkGroupState;
    Configuration?: WorkGroupConfiguration;
    Description?: string;
    CreationTime?: Date;
    IdentityCenterApplicationArn?: string;
}
export declare const WorkGroup: S.Schema<WorkGroup>;
export interface GetWorkGroupOutput {
    WorkGroup?: WorkGroup;
}
export declare const GetWorkGroupOutput: S.Schema<GetWorkGroupOutput>;
export interface ImportNotebookInput {
    WorkGroup: string;
    Name: string;
    Payload?: string;
    Type: NotebookType;
    NotebookS3LocationUri?: string;
    ClientRequestToken?: string;
}
export declare const ImportNotebookInput: S.Schema<ImportNotebookInput>;
export interface ImportNotebookOutput {
    NotebookId?: string;
}
export declare const ImportNotebookOutput: S.Schema<ImportNotebookOutput>;
export type MaxApplicationDPUSizesCount = number;
export interface ListApplicationDPUSizesInput {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListApplicationDPUSizesInput: S.Schema<ListApplicationDPUSizesInput>;
export type SupportedDPUSizeList = number[];
export declare const SupportedDPUSizeList: any;
export interface ApplicationDPUSizes {
    ApplicationRuntimeId?: string;
    SupportedDPUSizes?: number[];
}
export declare const ApplicationDPUSizes: S.Schema<ApplicationDPUSizes>;
export type ApplicationDPUSizesList = ApplicationDPUSizes[];
export declare const ApplicationDPUSizesList: any;
export interface ListApplicationDPUSizesOutput {
    ApplicationDPUSizes?: ApplicationDPUSizes[];
    NextToken?: string;
}
export declare const ListApplicationDPUSizesOutput: S.Schema<ListApplicationDPUSizesOutput>;
export type MaxCalculationsCount = number;
export type SessionManagerToken = string;
export interface ListCalculationExecutionsRequest {
    SessionId: string;
    StateFilter?: CalculationExecutionState;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListCalculationExecutionsRequest: S.Schema<ListCalculationExecutionsRequest>;
export interface CalculationSummary {
    CalculationExecutionId?: string;
    Description?: string;
    Status?: CalculationStatus;
}
export declare const CalculationSummary: S.Schema<CalculationSummary>;
export type CalculationsList = CalculationSummary[];
export declare const CalculationsList: any;
export interface ListCalculationExecutionsResponse {
    NextToken?: string;
    Calculations?: CalculationSummary[];
}
export declare const ListCalculationExecutionsResponse: S.Schema<ListCalculationExecutionsResponse>;
export type MaxCapacityReservationsCount = number;
export interface ListCapacityReservationsInput {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListCapacityReservationsInput: S.Schema<ListCapacityReservationsInput>;
export type CapacityReservationsList = CapacityReservation[];
export declare const CapacityReservationsList: any;
export interface ListCapacityReservationsOutput {
    NextToken?: string;
    CapacityReservations: CapacityReservation[];
}
export declare const ListCapacityReservationsOutput: S.Schema<ListCapacityReservationsOutput>;
export type MaxDatabasesCount = number;
export interface ListDatabasesInput {
    CatalogName: string;
    NextToken?: string;
    MaxResults?: number;
    WorkGroup?: string;
}
export declare const ListDatabasesInput: S.Schema<ListDatabasesInput>;
export type DatabaseList = Database[];
export declare const DatabaseList: any;
export interface ListDatabasesOutput {
    DatabaseList?: Database[];
    NextToken?: string;
}
export declare const ListDatabasesOutput: S.Schema<ListDatabasesOutput>;
export type MaxDataCatalogsCount = number;
export interface ListDataCatalogsInput {
    NextToken?: string;
    MaxResults?: number;
    WorkGroup?: string;
}
export declare const ListDataCatalogsInput: S.Schema<ListDataCatalogsInput>;
export interface DataCatalogSummary {
    CatalogName?: string;
    Type?: DataCatalogType;
    Status?: DataCatalogStatus;
    ConnectionType?: ConnectionType;
    Error?: string;
}
export declare const DataCatalogSummary: S.Schema<DataCatalogSummary>;
export type DataCatalogSummaryList = DataCatalogSummary[];
export declare const DataCatalogSummaryList: any;
export interface ListDataCatalogsOutput {
    DataCatalogsSummary?: DataCatalogSummary[];
    NextToken?: string;
}
export declare const ListDataCatalogsOutput: S.Schema<ListDataCatalogsOutput>;
export type MaxEngineVersionsCount = number;
export interface ListEngineVersionsInput {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEngineVersionsInput: S.Schema<ListEngineVersionsInput>;
export type EngineVersionsList = EngineVersion[];
export declare const EngineVersionsList: any;
export interface ListEngineVersionsOutput {
    EngineVersions?: EngineVersion[];
    NextToken?: string;
}
export declare const ListEngineVersionsOutput: S.Schema<ListEngineVersionsOutput>;
export type ExecutorState = "CREATING" | "CREATED" | "REGISTERED" | "TERMINATING" | "TERMINATED" | "FAILED" | (string & {});
export declare const ExecutorState: any;
export type MaxListExecutorsCount = number;
export interface ListExecutorsRequest {
    SessionId: string;
    ExecutorStateFilter?: ExecutorState;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListExecutorsRequest: S.Schema<ListExecutorsRequest>;
export type ExecutorId = string;
export type ExecutorType = "COORDINATOR" | "GATEWAY" | "WORKER" | (string & {});
export declare const ExecutorType: any;
export interface ExecutorsSummary {
    ExecutorId: string;
    ExecutorType?: ExecutorType;
    StartDateTime?: number;
    TerminationDateTime?: number;
    ExecutorState?: ExecutorState;
    ExecutorSize?: number;
}
export declare const ExecutorsSummary: S.Schema<ExecutorsSummary>;
export type ExecutorsSummaryList = ExecutorsSummary[];
export declare const ExecutorsSummaryList: any;
export interface ListExecutorsResponse {
    SessionId: string;
    NextToken?: string;
    ExecutorsSummary?: ExecutorsSummary[];
}
export declare const ListExecutorsResponse: S.Schema<ListExecutorsResponse>;
export type MaxNamedQueriesCount = number;
export interface ListNamedQueriesInput {
    NextToken?: string;
    MaxResults?: number;
    WorkGroup?: string;
}
export declare const ListNamedQueriesInput: S.Schema<ListNamedQueriesInput>;
export interface ListNamedQueriesOutput {
    NamedQueryIds?: string[];
    NextToken?: string;
}
export declare const ListNamedQueriesOutput: S.Schema<ListNamedQueriesOutput>;
export interface FilterDefinition {
    Name?: string;
}
export declare const FilterDefinition: S.Schema<FilterDefinition>;
export type MaxNotebooksCount = number;
export interface ListNotebookMetadataInput {
    Filters?: FilterDefinition;
    NextToken?: string;
    MaxResults?: number;
    WorkGroup: string;
}
export declare const ListNotebookMetadataInput: S.Schema<ListNotebookMetadataInput>;
export type NotebookMetadataArray = NotebookMetadata[];
export declare const NotebookMetadataArray: any;
export interface ListNotebookMetadataOutput {
    NextToken?: string;
    NotebookMetadataList?: NotebookMetadata[];
}
export declare const ListNotebookMetadataOutput: S.Schema<ListNotebookMetadataOutput>;
export type MaxSessionsCount = number;
export interface ListNotebookSessionsRequest {
    NotebookId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListNotebookSessionsRequest: S.Schema<ListNotebookSessionsRequest>;
export interface NotebookSessionSummary {
    SessionId?: string;
    CreationTime?: Date;
}
export declare const NotebookSessionSummary: S.Schema<NotebookSessionSummary>;
export type NotebookSessionsList = NotebookSessionSummary[];
export declare const NotebookSessionsList: any;
export interface ListNotebookSessionsResponse {
    NotebookSessionsList: NotebookSessionSummary[];
    NextToken?: string;
}
export declare const ListNotebookSessionsResponse: S.Schema<ListNotebookSessionsResponse>;
export type MaxPreparedStatementsCount = number;
export interface ListPreparedStatementsInput {
    WorkGroup: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListPreparedStatementsInput: S.Schema<ListPreparedStatementsInput>;
export interface PreparedStatementSummary {
    StatementName?: string;
    LastModifiedTime?: Date;
}
export declare const PreparedStatementSummary: S.Schema<PreparedStatementSummary>;
export type PreparedStatementsList = PreparedStatementSummary[];
export declare const PreparedStatementsList: any;
export interface ListPreparedStatementsOutput {
    PreparedStatements?: PreparedStatementSummary[];
    NextToken?: string;
}
export declare const ListPreparedStatementsOutput: S.Schema<ListPreparedStatementsOutput>;
export type MaxQueryExecutionsCount = number;
export interface ListQueryExecutionsInput {
    NextToken?: string;
    MaxResults?: number;
    WorkGroup?: string;
}
export declare const ListQueryExecutionsInput: S.Schema<ListQueryExecutionsInput>;
export interface ListQueryExecutionsOutput {
    QueryExecutionIds?: string[];
    NextToken?: string;
}
export declare const ListQueryExecutionsOutput: S.Schema<ListQueryExecutionsOutput>;
export interface ListSessionsRequest {
    WorkGroup: string;
    StateFilter?: SessionState;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListSessionsRequest: S.Schema<ListSessionsRequest>;
export interface SessionSummary {
    SessionId?: string;
    Description?: string;
    EngineVersion?: EngineVersion;
    NotebookVersion?: string;
    Status?: SessionStatus;
}
export declare const SessionSummary: S.Schema<SessionSummary>;
export type SessionsList = SessionSummary[];
export declare const SessionsList: any;
export interface ListSessionsResponse {
    NextToken?: string;
    Sessions?: SessionSummary[];
}
export declare const ListSessionsResponse: S.Schema<ListSessionsResponse>;
export type ExpressionString = string;
export type MaxTableMetadataCount = number;
export interface ListTableMetadataInput {
    CatalogName: string;
    DatabaseName: string;
    Expression?: string;
    NextToken?: string;
    MaxResults?: number;
    WorkGroup?: string;
}
export declare const ListTableMetadataInput: S.Schema<ListTableMetadataInput>;
export type TableMetadataList = TableMetadata[];
export declare const TableMetadataList: any;
export interface ListTableMetadataOutput {
    TableMetadataList?: TableMetadata[];
    NextToken?: string;
}
export declare const ListTableMetadataOutput: S.Schema<ListTableMetadataOutput>;
export type MaxTagsCount = number;
export interface ListTagsForResourceInput {
    ResourceARN: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListTagsForResourceInput: S.Schema<ListTagsForResourceInput>;
export interface ListTagsForResourceOutput {
    Tags?: Tag[];
    NextToken?: string;
}
export declare const ListTagsForResourceOutput: S.Schema<ListTagsForResourceOutput>;
export type MaxWorkGroupsCount = number;
export interface ListWorkGroupsInput {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListWorkGroupsInput: S.Schema<ListWorkGroupsInput>;
export interface WorkGroupSummary {
    Name?: string;
    State?: WorkGroupState;
    Description?: string;
    CreationTime?: Date;
    EngineVersion?: EngineVersion;
    IdentityCenterApplicationArn?: string;
}
export declare const WorkGroupSummary: S.Schema<WorkGroupSummary>;
export type WorkGroupsList = WorkGroupSummary[];
export declare const WorkGroupsList: any;
export interface ListWorkGroupsOutput {
    WorkGroups?: WorkGroupSummary[];
    NextToken?: string;
}
export declare const ListWorkGroupsOutput: S.Schema<ListWorkGroupsOutput>;
export interface PutCapacityAssignmentConfigurationInput {
    CapacityReservationName: string;
    CapacityAssignments: CapacityAssignment[];
}
export declare const PutCapacityAssignmentConfigurationInput: S.Schema<PutCapacityAssignmentConfigurationInput>;
export interface PutCapacityAssignmentConfigurationOutput {
}
export declare const PutCapacityAssignmentConfigurationOutput: S.Schema<PutCapacityAssignmentConfigurationOutput>;
export interface CalculationConfiguration {
    CodeBlock?: string;
}
export declare const CalculationConfiguration: S.Schema<CalculationConfiguration>;
export interface StartCalculationExecutionRequest {
    SessionId: string;
    Description?: string;
    CalculationConfiguration?: CalculationConfiguration;
    CodeBlock?: string;
    ClientRequestToken?: string;
}
export declare const StartCalculationExecutionRequest: S.Schema<StartCalculationExecutionRequest>;
export interface StartCalculationExecutionResponse {
    CalculationExecutionId?: string;
    State?: CalculationExecutionState;
}
export declare const StartCalculationExecutionResponse: S.Schema<StartCalculationExecutionResponse>;
export interface StartQueryExecutionInput {
    QueryString: string;
    ClientRequestToken?: string;
    QueryExecutionContext?: QueryExecutionContext;
    ResultConfiguration?: ResultConfiguration;
    WorkGroup?: string;
    ExecutionParameters?: string[];
    ResultReuseConfiguration?: ResultReuseConfiguration;
    EngineConfiguration?: EngineConfiguration;
}
export declare const StartQueryExecutionInput: S.Schema<StartQueryExecutionInput>;
export interface StartQueryExecutionOutput {
    QueryExecutionId?: string;
}
export declare const StartQueryExecutionOutput: S.Schema<StartQueryExecutionOutput>;
export interface StartSessionRequest {
    Description?: string;
    WorkGroup: string;
    EngineConfiguration: EngineConfiguration;
    ExecutionRole?: string;
    MonitoringConfiguration?: MonitoringConfiguration;
    NotebookVersion?: string;
    SessionIdleTimeoutInMinutes?: number;
    ClientRequestToken?: string;
    Tags?: Tag[];
    CopyWorkGroupTags?: boolean;
}
export declare const StartSessionRequest: S.Schema<StartSessionRequest>;
export interface StartSessionResponse {
    SessionId?: string;
    State?: SessionState;
}
export declare const StartSessionResponse: S.Schema<StartSessionResponse>;
export interface StopCalculationExecutionRequest {
    CalculationExecutionId: string;
}
export declare const StopCalculationExecutionRequest: S.Schema<StopCalculationExecutionRequest>;
export interface StopCalculationExecutionResponse {
    State?: CalculationExecutionState;
}
export declare const StopCalculationExecutionResponse: S.Schema<StopCalculationExecutionResponse>;
export interface StopQueryExecutionInput {
    QueryExecutionId: string;
}
export declare const StopQueryExecutionInput: S.Schema<StopQueryExecutionInput>;
export interface StopQueryExecutionOutput {
}
export declare const StopQueryExecutionOutput: S.Schema<StopQueryExecutionOutput>;
export interface TagResourceInput {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceInput: S.Schema<TagResourceInput>;
export interface TagResourceOutput {
}
export declare const TagResourceOutput: S.Schema<TagResourceOutput>;
export interface TerminateSessionRequest {
    SessionId: string;
}
export declare const TerminateSessionRequest: S.Schema<TerminateSessionRequest>;
export interface TerminateSessionResponse {
    State?: SessionState;
}
export declare const TerminateSessionResponse: S.Schema<TerminateSessionResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceInput {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceInput: S.Schema<UntagResourceInput>;
export interface UntagResourceOutput {
}
export declare const UntagResourceOutput: S.Schema<UntagResourceOutput>;
export interface UpdateCapacityReservationInput {
    TargetDpus: number;
    Name: string;
}
export declare const UpdateCapacityReservationInput: S.Schema<UpdateCapacityReservationInput>;
export interface UpdateCapacityReservationOutput {
}
export declare const UpdateCapacityReservationOutput: S.Schema<UpdateCapacityReservationOutput>;
export interface UpdateDataCatalogInput {
    Name: string;
    Type: DataCatalogType;
    Description?: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateDataCatalogInput: S.Schema<UpdateDataCatalogInput>;
export interface UpdateDataCatalogOutput {
}
export declare const UpdateDataCatalogOutput: S.Schema<UpdateDataCatalogOutput>;
export type NamedQueryDescriptionString = string;
export interface UpdateNamedQueryInput {
    NamedQueryId: string;
    Name: string;
    Description?: string;
    QueryString: string;
}
export declare const UpdateNamedQueryInput: S.Schema<UpdateNamedQueryInput>;
export interface UpdateNamedQueryOutput {
}
export declare const UpdateNamedQueryOutput: S.Schema<UpdateNamedQueryOutput>;
export interface UpdateNotebookInput {
    NotebookId: string;
    Payload: string;
    Type: NotebookType;
    SessionId?: string;
    ClientRequestToken?: string;
}
export declare const UpdateNotebookInput: S.Schema<UpdateNotebookInput>;
export interface UpdateNotebookOutput {
}
export declare const UpdateNotebookOutput: S.Schema<UpdateNotebookOutput>;
export interface UpdateNotebookMetadataInput {
    NotebookId: string;
    ClientRequestToken?: string;
    Name: string;
}
export declare const UpdateNotebookMetadataInput: S.Schema<UpdateNotebookMetadataInput>;
export interface UpdateNotebookMetadataOutput {
}
export declare const UpdateNotebookMetadataOutput: S.Schema<UpdateNotebookMetadataOutput>;
export interface UpdatePreparedStatementInput {
    StatementName: string;
    WorkGroup: string;
    QueryStatement: string;
    Description?: string;
}
export declare const UpdatePreparedStatementInput: S.Schema<UpdatePreparedStatementInput>;
export interface UpdatePreparedStatementOutput {
}
export declare const UpdatePreparedStatementOutput: S.Schema<UpdatePreparedStatementOutput>;
export interface ResultConfigurationUpdates {
    OutputLocation?: string;
    RemoveOutputLocation?: boolean;
    EncryptionConfiguration?: EncryptionConfiguration;
    RemoveEncryptionConfiguration?: boolean;
    ExpectedBucketOwner?: string;
    RemoveExpectedBucketOwner?: boolean;
    AclConfiguration?: AclConfiguration;
    RemoveAclConfiguration?: boolean;
}
export declare const ResultConfigurationUpdates: S.Schema<ResultConfigurationUpdates>;
export interface ManagedQueryResultsConfigurationUpdates {
    Enabled?: boolean;
    EncryptionConfiguration?: ManagedQueryResultsEncryptionConfiguration;
    RemoveEncryptionConfiguration?: boolean;
}
export declare const ManagedQueryResultsConfigurationUpdates: S.Schema<ManagedQueryResultsConfigurationUpdates>;
export interface WorkGroupConfigurationUpdates {
    EnforceWorkGroupConfiguration?: boolean;
    ResultConfigurationUpdates?: ResultConfigurationUpdates;
    ManagedQueryResultsConfigurationUpdates?: ManagedQueryResultsConfigurationUpdates;
    PublishCloudWatchMetricsEnabled?: boolean;
    BytesScannedCutoffPerQuery?: number;
    RemoveBytesScannedCutoffPerQuery?: boolean;
    RequesterPaysEnabled?: boolean;
    EngineVersion?: EngineVersion;
    RemoveCustomerContentEncryptionConfiguration?: boolean;
    AdditionalConfiguration?: string;
    ExecutionRole?: string;
    CustomerContentEncryptionConfiguration?: CustomerContentEncryptionConfiguration;
    EnableMinimumEncryptionConfiguration?: boolean;
    QueryResultsS3AccessGrantsConfiguration?: QueryResultsS3AccessGrantsConfiguration;
    MonitoringConfiguration?: MonitoringConfiguration;
    EngineConfiguration?: EngineConfiguration;
}
export declare const WorkGroupConfigurationUpdates: S.Schema<WorkGroupConfigurationUpdates>;
export interface UpdateWorkGroupInput {
    WorkGroup: string;
    Description?: string;
    ConfigurationUpdates?: WorkGroupConfigurationUpdates;
    State?: WorkGroupState;
}
export declare const UpdateWorkGroupInput: S.Schema<UpdateWorkGroupInput>;
export interface UpdateWorkGroupOutput {
}
export declare const UpdateWorkGroupOutput: S.Schema<UpdateWorkGroupOutput>;
export type ThrottleReason = "CONCURRENT_QUERY_LIMIT_EXCEEDED" | (string & {});
export declare const ThrottleReason: any;
export type BatchGetNamedQueryError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns the details of a single named query or a list of up to 50 queries, which you
 * provide as an array of query ID strings. Requires you to have access to the workgroup in
 * which the queries were saved. Use ListNamedQueriesInput to get the
 * list of named query IDs in the specified workgroup. If information could not be
 * retrieved for a submitted query ID, information about the query ID submitted is listed
 * under UnprocessedNamedQueryId. Named queries differ from executed
 * queries. Use BatchGetQueryExecutionInput to get details about each
 * unique query execution, and ListQueryExecutionsInput to get a list of
 * query execution IDs.
 */
export declare const batchGetNamedQuery: API.OperationMethod<BatchGetNamedQueryInput, BatchGetNamedQueryOutput, BatchGetNamedQueryError, Credentials | HttpClient.HttpClient>;
export type BatchGetPreparedStatementError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns the details of a single prepared statement or a list of up to 256 prepared
 * statements for the array of prepared statement names that you provide. Requires you to
 * have access to the workgroup to which the prepared statements belong. If a prepared
 * statement cannot be retrieved for the name specified, the statement is listed in
 * `UnprocessedPreparedStatementNames`.
 */
export declare const batchGetPreparedStatement: API.OperationMethod<BatchGetPreparedStatementInput, BatchGetPreparedStatementOutput, BatchGetPreparedStatementError, Credentials | HttpClient.HttpClient>;
export type BatchGetQueryExecutionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns the details of a single query execution or a list of up to 50 query
 * executions, which you provide as an array of query execution ID strings. Requires you to
 * have access to the workgroup in which the queries ran. To get a list of query execution
 * IDs, use ListQueryExecutionsInput$WorkGroup. Query executions differ
 * from named (saved) queries. Use BatchGetNamedQueryInput to get details
 * about named queries.
 */
export declare const batchGetQueryExecution: API.OperationMethod<BatchGetQueryExecutionInput, BatchGetQueryExecutionOutput, BatchGetQueryExecutionError, Credentials | HttpClient.HttpClient>;
export type CancelCapacityReservationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Cancels the capacity reservation with the specified name. Cancelled reservations
 * remain in your account and will be deleted 45 days after cancellation. During the 45
 * days, you cannot re-purpose or reuse a reservation that has been cancelled, but you can
 * refer to its tags and view it for historical reference.
 */
export declare const cancelCapacityReservation: API.OperationMethod<CancelCapacityReservationInput, CancelCapacityReservationOutput, CancelCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type CreateCapacityReservationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates a capacity reservation with the specified name and number of requested data
 * processing units.
 */
export declare const createCapacityReservation: API.OperationMethod<CreateCapacityReservationInput, CreateCapacityReservationOutput, CreateCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type CreateDataCatalogError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates (registers) a data catalog with the specified name and properties. Catalogs
 * created are visible to all users of the same Amazon Web Services account.
 *
 * For a `FEDERATED` catalog, this API operation creates the following
 * resources.
 *
 * - CFN Stack Name with a maximum length of 128 characters and prefix
 * `athenafederatedcatalog-CATALOG_NAME_SANITIZED` with length 23
 * characters.
 *
 * - Lambda Function Name with a maximum length of 64 characters and prefix
 * `athenafederatedcatalog_CATALOG_NAME_SANITIZED` with length 23
 * characters.
 *
 * - Glue Connection Name with a maximum length of 255 characters and a prefix
 * `athenafederatedcatalog_CATALOG_NAME_SANITIZED` with length 23
 * characters.
 */
export declare const createDataCatalog: API.OperationMethod<CreateDataCatalogInput, CreateDataCatalogOutput, CreateDataCatalogError, Credentials | HttpClient.HttpClient>;
export type CreateNamedQueryError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates a named query in the specified workgroup. Requires that you have access to the
 * workgroup.
 */
export declare const createNamedQuery: API.OperationMethod<CreateNamedQueryInput, CreateNamedQueryOutput, CreateNamedQueryError, Credentials | HttpClient.HttpClient>;
export type CreateNotebookError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Creates an empty `ipynb` file in the specified Apache Spark enabled
 * workgroup. Throws an error if a file in the workgroup with the same name already
 * exists.
 */
export declare const createNotebook: API.OperationMethod<CreateNotebookInput, CreateNotebookOutput, CreateNotebookError, Credentials | HttpClient.HttpClient>;
export type CreatePreparedStatementError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates a prepared statement for use with SQL queries in Athena.
 */
export declare const createPreparedStatement: API.OperationMethod<CreatePreparedStatementInput, CreatePreparedStatementOutput, CreatePreparedStatementError, Credentials | HttpClient.HttpClient>;
export type CreatePresignedNotebookUrlError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets an authentication token and the URL at which the notebook can be accessed. During
 * programmatic access, `CreatePresignedNotebookUrl` must be called every 10
 * minutes to refresh the authentication token. For information about granting programmatic
 * access, see Grant
 * programmatic access.
 */
export declare const createPresignedNotebookUrl: API.OperationMethod<CreatePresignedNotebookUrlRequest, CreatePresignedNotebookUrlResponse, CreatePresignedNotebookUrlError, Credentials | HttpClient.HttpClient>;
export type CreateWorkGroupError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates a workgroup with the specified name. A workgroup can be an Apache Spark
 * enabled workgroup or an Athena SQL workgroup.
 */
export declare const createWorkGroup: API.OperationMethod<CreateWorkGroupInput, CreateWorkGroupOutput, CreateWorkGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCapacityReservationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Deletes a cancelled capacity reservation. A reservation must be cancelled before it
 * can be deleted. A deleted reservation is immediately removed from your account and can
 * no longer be referenced, including by its ARN. A deleted reservation cannot be called by
 * `GetCapacityReservation`, and deleted reservations do not appear in the
 * output of `ListCapacityReservations`.
 */
export declare const deleteCapacityReservation: API.OperationMethod<DeleteCapacityReservationInput, DeleteCapacityReservationOutput, DeleteCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type DeleteDataCatalogError = InternalServerException | InvalidRequestException | DataCatalogNotFound | CommonErrors;
/**
 * Deletes a data catalog.
 */
export declare const deleteDataCatalog: API.OperationMethod<DeleteDataCatalogInput, DeleteDataCatalogOutput, DeleteDataCatalogError, Credentials | HttpClient.HttpClient>;
export type DeleteNamedQueryError = InternalServerException | InvalidRequestException | NamedQueryNotFound | CommonErrors;
/**
 * Deletes the named query if you have access to the workgroup in which the query was
 * saved.
 */
export declare const deleteNamedQuery: API.OperationMethod<DeleteNamedQueryInput, DeleteNamedQueryOutput, DeleteNamedQueryError, Credentials | HttpClient.HttpClient>;
export type DeleteNotebookError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the specified notebook.
 */
export declare const deleteNotebook: API.OperationMethod<DeleteNotebookInput, DeleteNotebookOutput, DeleteNotebookError, Credentials | HttpClient.HttpClient>;
export type DeletePreparedStatementError = InternalServerException | InvalidRequestException | ResourceNotFoundException | WorkGroupNotFound | CommonErrors;
/**
 * Deletes the prepared statement with the specified name from the specified
 * workgroup.
 */
export declare const deletePreparedStatement: API.OperationMethod<DeletePreparedStatementInput, DeletePreparedStatementOutput, DeletePreparedStatementError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkGroupError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Deletes the workgroup with the specified name. The primary workgroup cannot be
 * deleted.
 */
export declare const deleteWorkGroup: API.OperationMethod<DeleteWorkGroupInput, DeleteWorkGroupOutput, DeleteWorkGroupError, Credentials | HttpClient.HttpClient>;
export type ExportNotebookError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Exports the specified notebook and its metadata.
 */
export declare const exportNotebook: API.OperationMethod<ExportNotebookInput, ExportNotebookOutput, ExportNotebookError, Credentials | HttpClient.HttpClient>;
export type GetCalculationExecutionError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a previously submitted calculation execution.
 */
export declare const getCalculationExecution: API.OperationMethod<GetCalculationExecutionRequest, GetCalculationExecutionResponse, GetCalculationExecutionError, Credentials | HttpClient.HttpClient>;
export type GetCalculationExecutionCodeError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the unencrypted code that was executed for the calculation.
 */
export declare const getCalculationExecutionCode: API.OperationMethod<GetCalculationExecutionCodeRequest, GetCalculationExecutionCodeResponse, GetCalculationExecutionCodeError, Credentials | HttpClient.HttpClient>;
export type GetCalculationExecutionStatusError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the status of a current calculation.
 */
export declare const getCalculationExecutionStatus: API.OperationMethod<GetCalculationExecutionStatusRequest, GetCalculationExecutionStatusResponse, GetCalculationExecutionStatusError, Credentials | HttpClient.HttpClient>;
export type GetCapacityAssignmentConfigurationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Gets the capacity assignment configuration for a capacity reservation, if one
 * exists.
 */
export declare const getCapacityAssignmentConfiguration: API.OperationMethod<GetCapacityAssignmentConfigurationInput, GetCapacityAssignmentConfigurationOutput, GetCapacityAssignmentConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetCapacityReservationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns information about the capacity reservation with the specified name.
 */
export declare const getCapacityReservation: API.OperationMethod<GetCapacityReservationInput, GetCapacityReservationOutput, GetCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type GetDatabaseError = InternalServerException | InvalidRequestException | MetadataException | CommonErrors;
/**
 * Returns a database object for the specified database and data catalog.
 */
export declare const getDatabase: API.OperationMethod<GetDatabaseInput, GetDatabaseOutput, GetDatabaseError, Credentials | HttpClient.HttpClient>;
export type GetDataCatalogError = InternalServerException | InvalidRequestException | DataCatalogNotFound | CommonErrors;
/**
 * Returns the specified data catalog.
 */
export declare const getDataCatalog: API.OperationMethod<GetDataCatalogInput, GetDataCatalogOutput, GetDataCatalogError, Credentials | HttpClient.HttpClient>;
export type GetNamedQueryError = InternalServerException | InvalidRequestException | NamedQueryNotFound | CommonErrors;
/**
 * Returns information about a single query. Requires that you have access to the
 * workgroup in which the query was saved.
 */
export declare const getNamedQuery: API.OperationMethod<GetNamedQueryInput, GetNamedQueryOutput, GetNamedQueryError, Credentials | HttpClient.HttpClient>;
export type GetNotebookMetadataError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves notebook metadata for the specified notebook ID.
 */
export declare const getNotebookMetadata: API.OperationMethod<GetNotebookMetadataInput, GetNotebookMetadataOutput, GetNotebookMetadataError, Credentials | HttpClient.HttpClient>;
export type GetPreparedStatementError = InternalServerException | InvalidRequestException | ResourceNotFoundException | WorkGroupNotFound | CommonErrors;
/**
 * Retrieves the prepared statement with the specified name from the specified
 * workgroup.
 */
export declare const getPreparedStatement: API.OperationMethod<GetPreparedStatementInput, GetPreparedStatementOutput, GetPreparedStatementError, Credentials | HttpClient.HttpClient>;
export type GetQueryExecutionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns information about a single execution of a query if you have access to the
 * workgroup in which the query ran. Each time a query executes, information about the
 * query execution is saved with a unique ID.
 */
export declare const getQueryExecution: API.OperationMethod<GetQueryExecutionInput, GetQueryExecutionOutput, GetQueryExecutionError, Credentials | HttpClient.HttpClient>;
export type GetQueryResultsError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Streams the results of a single query execution specified by
 * `QueryExecutionId` from the Athena query results location in
 * Amazon S3. For more information, see Working with query results, recent queries, and
 * output files in the *Amazon Athena User Guide*.
 * This request does not execute the query but returns results. Use StartQueryExecution to run a query.
 *
 * To stream query results successfully, the IAM principal with permission to call
 * `GetQueryResults` also must have permissions to the Amazon S3
 * `GetObject` action for the Athena query results location.
 *
 * IAM principals with permission to the Amazon S3
 * `GetObject` action for the query results location are able to retrieve
 * query results from Amazon S3 even if permission to the
 * `GetQueryResults` action is denied. To restrict user or role access,
 * ensure that Amazon S3 permissions to the Athena query location
 * are denied.
 */
export declare const getQueryResults: API.PaginatedOperationMethod<GetQueryResultsInput, GetQueryResultsOutput, GetQueryResultsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetQueryRuntimeStatisticsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns query execution runtime statistics related to a single execution of a query if
 * you have access to the workgroup in which the query ran. Statistics from the
 * `Timeline` section of the response object are available as soon as QueryExecutionStatus$State is in a SUCCEEDED or FAILED state. The
 * remaining non-timeline statistics in the response (like stage-level input and output row
 * count and data size) are updated asynchronously and may not be available immediately
 * after a query completes or, in some cases, may not be returned. The non-timeline
 * statistics are also not included when a query has row-level filters defined in Lake Formation.
 */
export declare const getQueryRuntimeStatistics: API.OperationMethod<GetQueryRuntimeStatisticsInput, GetQueryRuntimeStatisticsOutput, GetQueryRuntimeStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetResourceDashboardError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the Live UI/Persistence UI for a session.
 */
export declare const getResourceDashboard: API.OperationMethod<GetResourceDashboardRequest, GetResourceDashboardResponse, GetResourceDashboardError, Credentials | HttpClient.HttpClient>;
export type GetSessionError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the full details of a previously created session, including the session status
 * and configuration.
 */
export declare const getSession: API.OperationMethod<GetSessionRequest, GetSessionResponse, GetSessionError, Credentials | HttpClient.HttpClient>;
export type GetSessionEndpointError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a connection endpoint and authentication token for a given session Id.
 */
export declare const getSessionEndpoint: API.OperationMethod<GetSessionEndpointRequest, GetSessionEndpointResponse, GetSessionEndpointError, Credentials | HttpClient.HttpClient>;
export type GetSessionStatusError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the current status of a session.
 */
export declare const getSessionStatus: API.OperationMethod<GetSessionStatusRequest, GetSessionStatusResponse, GetSessionStatusError, Credentials | HttpClient.HttpClient>;
export type GetTableMetadataError = InternalServerException | InvalidRequestException | MetadataException | CommonErrors;
/**
 * Returns table metadata for the specified catalog, database, and table.
 */
export declare const getTableMetadata: API.OperationMethod<GetTableMetadataInput, GetTableMetadataOutput, GetTableMetadataError, Credentials | HttpClient.HttpClient>;
export type GetWorkGroupError = InternalServerException | InvalidRequestException | WorkGroupNotFound | CommonErrors;
/**
 * Returns information about the workgroup with the specified name.
 */
export declare const getWorkGroup: API.OperationMethod<GetWorkGroupInput, GetWorkGroupOutput, GetWorkGroupError, Credentials | HttpClient.HttpClient>;
export type ImportNotebookError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Imports a single `ipynb` file to a Spark enabled workgroup. To import the
 * notebook, the request must specify a value for either `Payload` or
 * `NoteBookS3LocationUri`. If neither is specified or both are specified,
 * an `InvalidRequestException` occurs. The maximum file size that can be
 * imported is 10 megabytes. If an `ipynb` file with the same name already
 * exists in the workgroup, throws an error.
 */
export declare const importNotebook: API.OperationMethod<ImportNotebookInput, ImportNotebookOutput, ImportNotebookError, Credentials | HttpClient.HttpClient>;
export type ListApplicationDPUSizesError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Returns the supported DPU sizes for the supported application runtimes (for example,
 * `Athena notebook version 1`).
 */
export declare const listApplicationDPUSizes: API.PaginatedOperationMethod<ListApplicationDPUSizesInput, ListApplicationDPUSizesOutput, ListApplicationDPUSizesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCalculationExecutionsError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the calculations that have been submitted to a session in descending order.
 * Newer calculations are listed first; older calculations are listed later.
 */
export declare const listCalculationExecutions: API.PaginatedOperationMethod<ListCalculationExecutionsRequest, ListCalculationExecutionsResponse, ListCalculationExecutionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCapacityReservationsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists the capacity reservations for the current account.
 */
export declare const listCapacityReservations: API.PaginatedOperationMethod<ListCapacityReservationsInput, ListCapacityReservationsOutput, ListCapacityReservationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDatabasesError = InternalServerException | InvalidRequestException | MetadataException | CommonErrors;
/**
 * Lists the databases in the specified data catalog.
 */
export declare const listDatabases: API.PaginatedOperationMethod<ListDatabasesInput, ListDatabasesOutput, ListDatabasesError, Credentials | HttpClient.HttpClient, Database>;
export type ListDataCatalogsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists the data catalogs in the current Amazon Web Services account.
 *
 * In the Athena console, data catalogs are listed as "data sources" on
 * the **Data sources** page under the **Data source name** column.
 */
export declare const listDataCatalogs: API.PaginatedOperationMethod<ListDataCatalogsInput, ListDataCatalogsOutput, ListDataCatalogsError, Credentials | HttpClient.HttpClient, DataCatalogSummary>;
export type ListEngineVersionsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of engine versions that are available to choose from, including the
 * Auto option.
 */
export declare const listEngineVersions: API.PaginatedOperationMethod<ListEngineVersionsInput, ListEngineVersionsOutput, ListEngineVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListExecutorsError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists, in descending order, the executors that joined a session. Newer executors are
 * listed first; older executors are listed later. The result can be optionally filtered by
 * state.
 */
export declare const listExecutors: API.PaginatedOperationMethod<ListExecutorsRequest, ListExecutorsResponse, ListExecutorsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNamedQueriesError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides a list of available query IDs only for queries saved in the specified
 * workgroup. Requires that you have access to the specified workgroup. If a workgroup is
 * not specified, lists the saved queries for the primary workgroup.
 */
export declare const listNamedQueries: API.PaginatedOperationMethod<ListNamedQueriesInput, ListNamedQueriesOutput, ListNamedQueriesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNotebookMetadataError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Displays the notebook files for the specified workgroup in paginated format.
 */
export declare const listNotebookMetadata: API.OperationMethod<ListNotebookMetadataInput, ListNotebookMetadataOutput, ListNotebookMetadataError, Credentials | HttpClient.HttpClient>;
export type ListNotebookSessionsError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists, in descending order, the sessions that have been created in a notebook that are
 * in an active state like `CREATING`, `CREATED`, `IDLE`
 * or `BUSY`. Newer sessions are listed first; older sessions are listed
 * later.
 */
export declare const listNotebookSessions: API.OperationMethod<ListNotebookSessionsRequest, ListNotebookSessionsResponse, ListNotebookSessionsError, Credentials | HttpClient.HttpClient>;
export type ListPreparedStatementsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists the prepared statements in the specified workgroup.
 */
export declare const listPreparedStatements: API.PaginatedOperationMethod<ListPreparedStatementsInput, ListPreparedStatementsOutput, ListPreparedStatementsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListQueryExecutionsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides a list of available query execution IDs for the queries in the specified
 * workgroup. Athena keeps a query history for 45 days. If a workgroup is not
 * specified, returns a list of query execution IDs for the primary workgroup. Requires you
 * to have access to the workgroup in which the queries ran.
 */
export declare const listQueryExecutions: API.PaginatedOperationMethod<ListQueryExecutionsInput, ListQueryExecutionsOutput, ListQueryExecutionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSessionsError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the sessions in a workgroup that are in an active state like
 * `CREATING`, `CREATED`, `IDLE`, or
 * `BUSY`. Newer sessions are listed first; older sessions are listed
 * later.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsRequest, ListSessionsResponse, ListSessionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTableMetadataError = InternalServerException | InvalidRequestException | MetadataException | CommonErrors;
/**
 * Lists the metadata for the tables in the specified data catalog database.
 */
export declare const listTableMetadata: API.PaginatedOperationMethod<ListTableMetadataInput, ListTableMetadataOutput, ListTableMetadataError, Credentials | HttpClient.HttpClient, TableMetadata>;
export type ListTagsForResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags associated with an Athena resource.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type ListWorkGroupsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists available workgroups for the account.
 */
export declare const listWorkGroups: API.PaginatedOperationMethod<ListWorkGroupsInput, ListWorkGroupsOutput, ListWorkGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type PutCapacityAssignmentConfigurationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Puts a new capacity assignment configuration for a specified capacity reservation. If
 * a capacity assignment configuration already exists for the capacity reservation,
 * replaces the existing capacity assignment configuration.
 */
export declare const putCapacityAssignmentConfiguration: API.OperationMethod<PutCapacityAssignmentConfigurationInput, PutCapacityAssignmentConfigurationOutput, PutCapacityAssignmentConfigurationError, Credentials | HttpClient.HttpClient>;
export type StartCalculationExecutionError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Submits calculations for execution within a session. You can supply the code to run as
 * an inline code block within the request.
 *
 * The request syntax requires the StartCalculationExecutionRequest$CodeBlock parameter or the CalculationConfiguration$CodeBlock parameter, but not both. Because
 * CalculationConfiguration$CodeBlock is deprecated, use the
 * StartCalculationExecutionRequest$CodeBlock parameter
 * instead.
 */
export declare const startCalculationExecution: API.OperationMethod<StartCalculationExecutionRequest, StartCalculationExecutionResponse, StartCalculationExecutionError, Credentials | HttpClient.HttpClient>;
export type StartQueryExecutionError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Runs the SQL query statements contained in the `Query`. Requires you to
 * have access to the workgroup in which the query ran. Running queries against an external
 * catalog requires GetDataCatalog permission to the catalog. For code
 * samples using the Amazon Web Services SDK for Java, see Examples and
 * Code Samples in the Amazon Athena User
 * Guide.
 */
export declare const startQueryExecution: API.OperationMethod<StartQueryExecutionInput, StartQueryExecutionOutput, StartQueryExecutionError, Credentials | HttpClient.HttpClient>;
export type StartSessionError = InternalServerException | InvalidRequestException | ResourceNotFoundException | SessionAlreadyExistsException | TooManyRequestsException | CommonErrors;
/**
 * Creates a session for running calculations within a workgroup. The session is ready
 * when it reaches an `IDLE` state.
 */
export declare const startSession: API.OperationMethod<StartSessionRequest, StartSessionResponse, StartSessionError, Credentials | HttpClient.HttpClient>;
export type StopCalculationExecutionError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Requests the cancellation of a calculation. A `StopCalculationExecution`
 * call on a calculation that is already in a terminal state (for example,
 * `STOPPED`, `FAILED`, or `COMPLETED`) succeeds but
 * has no effect.
 *
 * Cancelling a calculation is done on a best effort basis. If a calculation cannot
 * be cancelled, you can be charged for its completion. If you are concerned about
 * being charged for a calculation that cannot be cancelled, consider terminating the
 * session in which the calculation is running.
 */
export declare const stopCalculationExecution: API.OperationMethod<StopCalculationExecutionRequest, StopCalculationExecutionResponse, StopCalculationExecutionError, Credentials | HttpClient.HttpClient>;
export type StopQueryExecutionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Stops a query execution. Requires you to have access to the workgroup in which the
 * query ran.
 */
export declare const stopQueryExecution: API.OperationMethod<StopQueryExecutionInput, StopQueryExecutionOutput, StopQueryExecutionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Adds one or more tags to an Athena resource. A tag is a label that you
 * assign to a resource. Each tag consists of a key and an optional value, both of which
 * you define. For example, you can use tags to categorize Athena workgroups,
 * data catalogs, or capacity reservations by purpose, owner, or environment. Use a
 * consistent set of tag keys to make it easier to search and filter the resources in your
 * account. For best practices, see Tagging
 * Best Practices. Tag keys can be from 1 to 128 UTF-8 Unicode characters, and
 * tag values can be from 0 to 256 UTF-8 Unicode characters. Tags can use letters and
 * numbers representable in UTF-8, and the following characters: + - = . _ : / @. Tag keys
 * and values are case-sensitive. Tag keys must be unique per resource. If you specify more
 * than one tag, separate them by commas.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateSessionError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Terminates an active session. A `TerminateSession` call on a session that
 * is already inactive (for example, in a `FAILED`, `TERMINATED` or
 * `TERMINATING` state) succeeds but has no effect. Calculations running in
 * the session when `TerminateSession` is called are forcefully stopped, but may
 * display as `FAILED` instead of `STOPPED`.
 */
export declare const terminateSession: API.OperationMethod<TerminateSessionRequest, TerminateSessionResponse, TerminateSessionError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from an Athena resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCapacityReservationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Updates the number of requested data processing units for the capacity reservation
 * with the specified name.
 */
export declare const updateCapacityReservation: API.OperationMethod<UpdateCapacityReservationInput, UpdateCapacityReservationOutput, UpdateCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type UpdateDataCatalogError = InternalServerException | InvalidRequestException | DataCatalogNotFound | CommonErrors;
/**
 * Updates the data catalog that has the specified name.
 */
export declare const updateDataCatalog: API.OperationMethod<UpdateDataCatalogInput, UpdateDataCatalogOutput, UpdateDataCatalogError, Credentials | HttpClient.HttpClient>;
export type UpdateNamedQueryError = InternalServerException | InvalidRequestException | NamedQueryNotFound | CommonErrors;
/**
 * Updates a NamedQuery object. The database or workgroup cannot be
 * updated.
 */
export declare const updateNamedQuery: API.OperationMethod<UpdateNamedQueryInput, UpdateNamedQueryOutput, UpdateNamedQueryError, Credentials | HttpClient.HttpClient>;
export type UpdateNotebookError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Updates the contents of a Spark notebook.
 */
export declare const updateNotebook: API.OperationMethod<UpdateNotebookInput, UpdateNotebookOutput, UpdateNotebookError, Credentials | HttpClient.HttpClient>;
export type UpdateNotebookMetadataError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Updates the metadata for a notebook.
 */
export declare const updateNotebookMetadata: API.OperationMethod<UpdateNotebookMetadataInput, UpdateNotebookMetadataOutput, UpdateNotebookMetadataError, Credentials | HttpClient.HttpClient>;
export type UpdatePreparedStatementError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a prepared statement.
 */
export declare const updatePreparedStatement: API.OperationMethod<UpdatePreparedStatementInput, UpdatePreparedStatementOutput, UpdatePreparedStatementError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkGroupError = InternalServerException | InvalidRequestException | WorkGroupNotFound | CommonErrors;
/**
 * Updates the workgroup with the specified name. The workgroup's name cannot be changed.
 * Only `ConfigurationUpdates` can be specified.
 */
export declare const updateWorkGroup: API.OperationMethod<UpdateWorkGroupInput, UpdateWorkGroupOutput, UpdateWorkGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=athena.d.ts.map