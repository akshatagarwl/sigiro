import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterValueException_base: S.Class<InvalidParameterValueException, S.TaggedStruct<"InvalidParameterValueException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MissingAuthenticationToken_base: S.Class<MissingAuthenticationToken, S.TaggedStruct<"MissingAuthenticationToken", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class MissingAuthenticationToken extends /*@__PURE__*/ MissingAuthenticationToken_base {
}
declare const OptInRequiredException_base: S.Class<OptInRequiredException, S.TaggedStruct<"OptInRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class OptInRequiredException extends /*@__PURE__*/ OptInRequiredException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type ResourceType = "Ec2Instance" | "AutoScalingGroup" | "EbsVolume" | "LambdaFunction" | "NotApplicable" | "EcsService" | "License" | "RdsDBInstance" | "AuroraDBClusterStorage" | "Idle" | (string & {});
export declare const ResourceType: any;
export type ScopeName = "Organization" | "AccountId" | "ResourceArn" | (string & {});
export declare const ScopeName: any;
export type ScopeValue = string;
export interface Scope {
    name?: ScopeName;
    value?: string;
}
export declare const Scope: S.Schema<Scope>;
export type RecommendationPreferenceName = "EnhancedInfrastructureMetrics" | "InferredWorkloadTypes" | "ExternalMetricsPreference" | "LookBackPeriodPreference" | "PreferredResources" | "UtilizationPreferences" | (string & {});
export declare const RecommendationPreferenceName: any;
export type RecommendationPreferenceNames = RecommendationPreferenceName[];
export declare const RecommendationPreferenceNames: any;
export interface DeleteRecommendationPreferencesRequest {
    resourceType: ResourceType;
    scope?: Scope;
    recommendationPreferenceNames: RecommendationPreferenceName[];
}
export declare const DeleteRecommendationPreferencesRequest: S.Schema<DeleteRecommendationPreferencesRequest>;
export interface DeleteRecommendationPreferencesResponse {
}
export declare const DeleteRecommendationPreferencesResponse: S.Schema<DeleteRecommendationPreferencesResponse>;
export type JobId = string;
export type JobIds = string[];
export declare const JobIds: any;
export type JobFilterName = "ResourceType" | "JobStatus" | (string & {});
export declare const JobFilterName: any;
export type FilterValue = string;
export type FilterValues = string[];
export declare const FilterValues: any;
export interface JobFilter {
    name?: JobFilterName;
    values?: string[];
}
export declare const JobFilter: S.Schema<JobFilter>;
export type JobFilters = JobFilter[];
export declare const JobFilters: any;
export type NextToken = string;
export type MaxResults = number;
export interface DescribeRecommendationExportJobsRequest {
    jobIds?: string[];
    filters?: JobFilter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const DescribeRecommendationExportJobsRequest: S.Schema<DescribeRecommendationExportJobsRequest>;
export type DestinationBucket = string;
export type DestinationKey = string;
export type MetadataKey = string;
export interface S3Destination {
    bucket?: string;
    key?: string;
    metadataKey?: string;
}
export declare const S3Destination: S.Schema<S3Destination>;
export interface ExportDestination {
    s3?: S3Destination;
}
export declare const ExportDestination: S.Schema<ExportDestination>;
export type JobStatus = "Queued" | "InProgress" | "Complete" | "Failed" | (string & {});
export declare const JobStatus: any;
export type CreationTimestamp = Date;
export type LastUpdatedTimestamp = Date;
export type FailureReason = string;
export interface RecommendationExportJob {
    jobId?: string;
    destination?: ExportDestination;
    resourceType?: ResourceType;
    status?: JobStatus;
    creationTimestamp?: Date;
    lastUpdatedTimestamp?: Date;
    failureReason?: string;
}
export declare const RecommendationExportJob: S.Schema<RecommendationExportJob>;
export type RecommendationExportJobs = RecommendationExportJob[];
export declare const RecommendationExportJobs: any;
export interface DescribeRecommendationExportJobsResponse {
    recommendationExportJobs?: RecommendationExportJob[];
    nextToken?: string;
}
export declare const DescribeRecommendationExportJobsResponse: S.Schema<DescribeRecommendationExportJobsResponse>;
export type AccountId = string;
export type AccountIds = string[];
export declare const AccountIds: any;
export type FilterName = "Finding" | "FindingReasonCodes" | "RecommendationSourceType" | "InferredWorkloadTypes" | (string & {});
export declare const FilterName: any;
export interface Filter {
    name?: FilterName;
    values?: string[];
}
export declare const Filter: S.Schema<Filter>;
export type Filters = Filter[];
export declare const Filters: any;
export type ExportableAutoScalingGroupField = "AccountId" | "AutoScalingGroupArn" | "AutoScalingGroupName" | "Finding" | "UtilizationMetricsCpuMaximum" | "UtilizationMetricsMemoryMaximum" | "UtilizationMetricsEbsReadOpsPerSecondMaximum" | "UtilizationMetricsEbsWriteOpsPerSecondMaximum" | "UtilizationMetricsEbsReadBytesPerSecondMaximum" | "UtilizationMetricsEbsWriteBytesPerSecondMaximum" | "UtilizationMetricsDiskReadOpsPerSecondMaximum" | "UtilizationMetricsDiskWriteOpsPerSecondMaximum" | "UtilizationMetricsDiskReadBytesPerSecondMaximum" | "UtilizationMetricsDiskWriteBytesPerSecondMaximum" | "UtilizationMetricsNetworkInBytesPerSecondMaximum" | "UtilizationMetricsNetworkOutBytesPerSecondMaximum" | "UtilizationMetricsNetworkPacketsInPerSecondMaximum" | "UtilizationMetricsNetworkPacketsOutPerSecondMaximum" | "LookbackPeriodInDays" | "CurrentConfigurationInstanceType" | "CurrentConfigurationDesiredCapacity" | "CurrentConfigurationMinSize" | "CurrentConfigurationMaxSize" | "CurrentConfigurationAllocationStrategy" | "CurrentConfigurationMixedInstanceTypes" | "CurrentConfigurationType" | "CurrentOnDemandPrice" | "CurrentStandardOneYearNoUpfrontReservedPrice" | "CurrentStandardThreeYearNoUpfrontReservedPrice" | "CurrentVCpus" | "CurrentMemory" | "CurrentStorage" | "CurrentNetwork" | "RecommendationOptionsConfigurationInstanceType" | "RecommendationOptionsConfigurationDesiredCapacity" | "RecommendationOptionsConfigurationMinSize" | "RecommendationOptionsConfigurationMaxSize" | "RecommendationOptionsConfigurationEstimatedInstanceHourReductionPercentage" | "RecommendationOptionsConfigurationAllocationStrategy" | "RecommendationOptionsConfigurationMixedInstanceTypes" | "RecommendationOptionsConfigurationType" | "RecommendationOptionsProjectedUtilizationMetricsCpuMaximum" | "RecommendationOptionsProjectedUtilizationMetricsMemoryMaximum" | "RecommendationOptionsPerformanceRisk" | "RecommendationOptionsOnDemandPrice" | "RecommendationOptionsStandardOneYearNoUpfrontReservedPrice" | "RecommendationOptionsStandardThreeYearNoUpfrontReservedPrice" | "RecommendationOptionsVcpus" | "RecommendationOptionsMemory" | "RecommendationOptionsStorage" | "RecommendationOptionsNetwork" | "LastRefreshTimestamp" | "CurrentPerformanceRisk" | "RecommendationOptionsSavingsOpportunityPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrency" | "RecommendationOptionsEstimatedMonthlySavingsValue" | "EffectiveRecommendationPreferencesCpuVendorArchitectures" | "EffectiveRecommendationPreferencesEnhancedInfrastructureMetrics" | "EffectiveRecommendationPreferencesInferredWorkloadTypes" | "EffectiveRecommendationPreferencesPreferredResources" | "EffectiveRecommendationPreferencesLookBackPeriod" | "InferredWorkloadTypes" | "RecommendationOptionsMigrationEffort" | "CurrentInstanceGpuInfo" | "RecommendationOptionsInstanceGpuInfo" | "UtilizationMetricsGpuPercentageMaximum" | "UtilizationMetricsGpuMemoryPercentageMaximum" | "RecommendationOptionsProjectedUtilizationMetricsGpuPercentageMaximum" | "RecommendationOptionsProjectedUtilizationMetricsGpuMemoryPercentageMaximum" | "EffectiveRecommendationPreferencesSavingsEstimationMode" | "RecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "RecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | (string & {});
export declare const ExportableAutoScalingGroupField: any;
export type ExportableAutoScalingGroupFields = ExportableAutoScalingGroupField[];
export declare const ExportableAutoScalingGroupFields: any;
export type DestinationKeyPrefix = string;
export interface S3DestinationConfig {
    bucket?: string;
    keyPrefix?: string;
}
export declare const S3DestinationConfig: S.Schema<S3DestinationConfig>;
export type FileFormat = "Csv" | (string & {});
export declare const FileFormat: any;
export type IncludeMemberAccounts = boolean;
export type CpuVendorArchitecture = "AWS_ARM64" | "CURRENT" | (string & {});
export declare const CpuVendorArchitecture: any;
export type CpuVendorArchitectures = CpuVendorArchitecture[];
export declare const CpuVendorArchitectures: any;
export interface RecommendationPreferences {
    cpuVendorArchitectures?: CpuVendorArchitecture[];
}
export declare const RecommendationPreferences: S.Schema<RecommendationPreferences>;
export interface ExportAutoScalingGroupRecommendationsRequest {
    accountIds?: string[];
    filters?: Filter[];
    fieldsToExport?: ExportableAutoScalingGroupField[];
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat;
    includeMemberAccounts?: boolean;
    recommendationPreferences?: RecommendationPreferences;
}
export declare const ExportAutoScalingGroupRecommendationsRequest: S.Schema<ExportAutoScalingGroupRecommendationsRequest>;
export interface ExportAutoScalingGroupRecommendationsResponse {
    jobId?: string;
    s3Destination?: S3Destination;
}
export declare const ExportAutoScalingGroupRecommendationsResponse: S.Schema<ExportAutoScalingGroupRecommendationsResponse>;
export type EBSFilterName = "Finding" | (string & {});
export declare const EBSFilterName: any;
export interface EBSFilter {
    name?: EBSFilterName;
    values?: string[];
}
export declare const EBSFilter: S.Schema<EBSFilter>;
export type EBSFilters = EBSFilter[];
export declare const EBSFilters: any;
export type ExportableVolumeField = "AccountId" | "VolumeArn" | "Finding" | "UtilizationMetricsVolumeReadOpsPerSecondMaximum" | "UtilizationMetricsVolumeWriteOpsPerSecondMaximum" | "UtilizationMetricsVolumeReadBytesPerSecondMaximum" | "UtilizationMetricsVolumeWriteBytesPerSecondMaximum" | "UtilizationMetricsVolumeIOPSExceededMaximum" | "UtilizationMetricsVolumeThroughputExceededMaximum" | "LookbackPeriodInDays" | "CurrentConfigurationVolumeType" | "CurrentConfigurationVolumeBaselineIOPS" | "CurrentConfigurationVolumeBaselineThroughput" | "CurrentConfigurationVolumeBurstIOPS" | "CurrentConfigurationVolumeBurstThroughput" | "CurrentConfigurationVolumeSize" | "CurrentMonthlyPrice" | "RecommendationOptionsConfigurationVolumeType" | "RecommendationOptionsConfigurationVolumeBaselineIOPS" | "RecommendationOptionsConfigurationVolumeBaselineThroughput" | "RecommendationOptionsConfigurationVolumeBurstIOPS" | "RecommendationOptionsConfigurationVolumeBurstThroughput" | "RecommendationOptionsConfigurationVolumeSize" | "RecommendationOptionsMonthlyPrice" | "RecommendationOptionsPerformanceRisk" | "LastRefreshTimestamp" | "CurrentPerformanceRisk" | "RecommendationOptionsSavingsOpportunityPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrency" | "RecommendationOptionsEstimatedMonthlySavingsValue" | "Tags" | "RootVolume" | "CurrentConfigurationRootVolume" | "EffectiveRecommendationPreferencesSavingsEstimationMode" | "RecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "RecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | "EffectiveRecommendationPreferencesLookBackPeriod" | (string & {});
export declare const ExportableVolumeField: any;
export type ExportableVolumeFields = ExportableVolumeField[];
export declare const ExportableVolumeFields: any;
export interface ExportEBSVolumeRecommendationsRequest {
    accountIds?: string[];
    filters?: EBSFilter[];
    fieldsToExport?: ExportableVolumeField[];
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat;
    includeMemberAccounts?: boolean;
}
export declare const ExportEBSVolumeRecommendationsRequest: S.Schema<ExportEBSVolumeRecommendationsRequest>;
export interface ExportEBSVolumeRecommendationsResponse {
    jobId?: string;
    s3Destination?: S3Destination;
}
export declare const ExportEBSVolumeRecommendationsResponse: S.Schema<ExportEBSVolumeRecommendationsResponse>;
export type ExportableInstanceField = "AccountId" | "InstanceArn" | "InstanceName" | "Finding" | "FindingReasonCodes" | "LookbackPeriodInDays" | "CurrentInstanceType" | "UtilizationMetricsCpuMaximum" | "UtilizationMetricsMemoryMaximum" | "UtilizationMetricsEbsReadOpsPerSecondMaximum" | "UtilizationMetricsEbsWriteOpsPerSecondMaximum" | "UtilizationMetricsEbsReadBytesPerSecondMaximum" | "UtilizationMetricsEbsWriteBytesPerSecondMaximum" | "UtilizationMetricsDiskReadOpsPerSecondMaximum" | "UtilizationMetricsDiskWriteOpsPerSecondMaximum" | "UtilizationMetricsDiskReadBytesPerSecondMaximum" | "UtilizationMetricsDiskWriteBytesPerSecondMaximum" | "UtilizationMetricsNetworkInBytesPerSecondMaximum" | "UtilizationMetricsNetworkOutBytesPerSecondMaximum" | "UtilizationMetricsNetworkPacketsInPerSecondMaximum" | "UtilizationMetricsNetworkPacketsOutPerSecondMaximum" | "CurrentOnDemandPrice" | "CurrentStandardOneYearNoUpfrontReservedPrice" | "CurrentStandardThreeYearNoUpfrontReservedPrice" | "CurrentVCpus" | "CurrentMemory" | "CurrentStorage" | "CurrentNetwork" | "RecommendationOptionsInstanceType" | "RecommendationOptionsProjectedUtilizationMetricsCpuMaximum" | "RecommendationOptionsProjectedUtilizationMetricsMemoryMaximum" | "RecommendationOptionsPlatformDifferences" | "RecommendationOptionsPerformanceRisk" | "RecommendationOptionsVcpus" | "RecommendationOptionsMemory" | "RecommendationOptionsStorage" | "RecommendationOptionsNetwork" | "RecommendationOptionsOnDemandPrice" | "RecommendationOptionsStandardOneYearNoUpfrontReservedPrice" | "RecommendationOptionsStandardThreeYearNoUpfrontReservedPrice" | "RecommendationsSourcesRecommendationSourceArn" | "RecommendationsSourcesRecommendationSourceType" | "LastRefreshTimestamp" | "CurrentPerformanceRisk" | "RecommendationOptionsSavingsOpportunityPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrency" | "RecommendationOptionsEstimatedMonthlySavingsValue" | "EffectiveRecommendationPreferencesCpuVendorArchitectures" | "EffectiveRecommendationPreferencesEnhancedInfrastructureMetrics" | "EffectiveRecommendationPreferencesInferredWorkloadTypes" | "InferredWorkloadTypes" | "RecommendationOptionsMigrationEffort" | "EffectiveRecommendationPreferencesExternalMetricsSource" | "Tags" | "InstanceState" | "ExternalMetricStatusCode" | "ExternalMetricStatusReason" | "CurrentInstanceGpuInfo" | "RecommendationOptionsInstanceGpuInfo" | "UtilizationMetricsGpuPercentageMaximum" | "UtilizationMetricsGpuMemoryPercentageMaximum" | "RecommendationOptionsProjectedUtilizationMetricsGpuPercentageMaximum" | "RecommendationOptionsProjectedUtilizationMetricsGpuMemoryPercentageMaximum" | "Idle" | "EffectiveRecommendationPreferencesPreferredResources" | "EffectiveRecommendationPreferencesLookBackPeriod" | "EffectiveRecommendationPreferencesUtilizationPreferences" | "EffectiveRecommendationPreferencesSavingsEstimationMode" | "RecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "RecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | (string & {});
export declare const ExportableInstanceField: any;
export type ExportableInstanceFields = ExportableInstanceField[];
export declare const ExportableInstanceFields: any;
export interface ExportEC2InstanceRecommendationsRequest {
    accountIds?: string[];
    filters?: Filter[];
    fieldsToExport?: ExportableInstanceField[];
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat;
    includeMemberAccounts?: boolean;
    recommendationPreferences?: RecommendationPreferences;
}
export declare const ExportEC2InstanceRecommendationsRequest: S.Schema<ExportEC2InstanceRecommendationsRequest>;
export interface ExportEC2InstanceRecommendationsResponse {
    jobId?: string;
    s3Destination?: S3Destination;
}
export declare const ExportEC2InstanceRecommendationsResponse: S.Schema<ExportEC2InstanceRecommendationsResponse>;
export type ECSServiceRecommendationFilterName = "Finding" | "FindingReasonCode" | (string & {});
export declare const ECSServiceRecommendationFilterName: any;
export interface ECSServiceRecommendationFilter {
    name?: ECSServiceRecommendationFilterName;
    values?: string[];
}
export declare const ECSServiceRecommendationFilter: S.Schema<ECSServiceRecommendationFilter>;
export type ECSServiceRecommendationFilters = ECSServiceRecommendationFilter[];
export declare const ECSServiceRecommendationFilters: any;
export type ExportableECSServiceField = "AccountId" | "ServiceArn" | "LookbackPeriodInDays" | "LastRefreshTimestamp" | "LaunchType" | "CurrentPerformanceRisk" | "CurrentServiceConfigurationMemory" | "CurrentServiceConfigurationCpu" | "CurrentServiceConfigurationTaskDefinitionArn" | "CurrentServiceConfigurationAutoScalingConfiguration" | "CurrentServiceContainerConfigurations" | "UtilizationMetricsCpuMaximum" | "UtilizationMetricsMemoryMaximum" | "Finding" | "FindingReasonCodes" | "RecommendationOptionsMemory" | "RecommendationOptionsCpu" | "RecommendationOptionsSavingsOpportunityPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrency" | "RecommendationOptionsEstimatedMonthlySavingsValue" | "RecommendationOptionsContainerRecommendations" | "RecommendationOptionsProjectedUtilizationMetricsCpuMaximum" | "RecommendationOptionsProjectedUtilizationMetricsMemoryMaximum" | "Tags" | "EffectiveRecommendationPreferencesSavingsEstimationMode" | "RecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "RecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | "EffectiveRecommendationPreferencesLookBackPeriod" | (string & {});
export declare const ExportableECSServiceField: any;
export type ExportableECSServiceFields = ExportableECSServiceField[];
export declare const ExportableECSServiceFields: any;
export interface ExportECSServiceRecommendationsRequest {
    accountIds?: string[];
    filters?: ECSServiceRecommendationFilter[];
    fieldsToExport?: ExportableECSServiceField[];
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat;
    includeMemberAccounts?: boolean;
}
export declare const ExportECSServiceRecommendationsRequest: S.Schema<ExportECSServiceRecommendationsRequest>;
export interface ExportECSServiceRecommendationsResponse {
    jobId?: string;
    s3Destination?: S3Destination;
}
export declare const ExportECSServiceRecommendationsResponse: S.Schema<ExportECSServiceRecommendationsResponse>;
export type IdleRecommendationFilterName = "Finding" | "ResourceType" | (string & {});
export declare const IdleRecommendationFilterName: any;
export interface IdleRecommendationFilter {
    name?: IdleRecommendationFilterName;
    values?: string[];
}
export declare const IdleRecommendationFilter: S.Schema<IdleRecommendationFilter>;
export type IdleRecommendationFilters = IdleRecommendationFilter[];
export declare const IdleRecommendationFilters: any;
export type ExportableIdleField = "AccountId" | "ResourceArn" | "ResourceId" | "ResourceType" | "LastRefreshTimestamp" | "LookbackPeriodInDays" | "SavingsOpportunity" | "SavingsOpportunityAfterDiscount" | "UtilizationMetricsCpuMaximum" | "UtilizationMetricsMemoryMaximum" | "UtilizationMetricsNetworkOutBytesPerSecondMaximum" | "UtilizationMetricsNetworkInBytesPerSecondMaximum" | "UtilizationMetricsDatabaseConnectionsMaximum" | "UtilizationMetricsEBSVolumeReadIOPSMaximum" | "UtilizationMetricsEBSVolumeWriteIOPSMaximum" | "UtilizationMetricsVolumeReadOpsPerSecondMaximum" | "UtilizationMetricsVolumeWriteOpsPerSecondMaximum" | "UtilizationMetricsActiveConnectionCountMaximum" | "UtilizationMetricsPacketsInFromSourceMaximum" | "UtilizationMetricsPacketsInFromDestinationMaximum" | "UtilizationMetricsConsumedReadCapacityUnitsSum" | "UtilizationMetricsConsumedWriteCapacityUnitsSum" | "UtilizationMetricsNewConnectionsSum" | "UtilizationMetricsEngineCPUUtilizationMaximum" | "UtilizationMetricsCacheHitsSum" | "UtilizationMetricsCacheMissesSum" | "UtilizationMetricsKeyspaceHitsSum" | "UtilizationMetricsKeyspaceMissesSum" | "UtilizationMetricsIsIdleMinimum" | "UtilizationMetricsUserConnectedSum" | "UtilizationMetricsInvocationsSum" | "UtilizationMetricsGetTypeCmdsSum" | "UtilizationMetricsSetTypeCmdsSum" | "UtilizationMetricsElastiCacheProcessingUnitsSum" | "UtilizationMetricsCurrConnectionsSum" | "UtilizationMetricsDatabaseConnectionsSum" | "Finding" | "FindingDescription" | "Tags" | (string & {});
export declare const ExportableIdleField: any;
export type ExportableIdleFields = ExportableIdleField[];
export declare const ExportableIdleFields: any;
export interface ExportIdleRecommendationsRequest {
    accountIds?: string[];
    filters?: IdleRecommendationFilter[];
    fieldsToExport?: ExportableIdleField[];
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat;
    includeMemberAccounts?: boolean;
}
export declare const ExportIdleRecommendationsRequest: S.Schema<ExportIdleRecommendationsRequest>;
export interface ExportIdleRecommendationsResponse {
    jobId?: string;
    s3Destination?: S3Destination;
}
export declare const ExportIdleRecommendationsResponse: S.Schema<ExportIdleRecommendationsResponse>;
export type LambdaFunctionRecommendationFilterName = "Finding" | "FindingReasonCode" | (string & {});
export declare const LambdaFunctionRecommendationFilterName: any;
export interface LambdaFunctionRecommendationFilter {
    name?: LambdaFunctionRecommendationFilterName;
    values?: string[];
}
export declare const LambdaFunctionRecommendationFilter: S.Schema<LambdaFunctionRecommendationFilter>;
export type LambdaFunctionRecommendationFilters = LambdaFunctionRecommendationFilter[];
export declare const LambdaFunctionRecommendationFilters: any;
export type ExportableLambdaFunctionField = "AccountId" | "FunctionArn" | "FunctionVersion" | "Finding" | "FindingReasonCodes" | "NumberOfInvocations" | "UtilizationMetricsDurationMaximum" | "UtilizationMetricsDurationAverage" | "UtilizationMetricsMemoryMaximum" | "UtilizationMetricsMemoryAverage" | "LookbackPeriodInDays" | "CurrentConfigurationMemorySize" | "CurrentConfigurationTimeout" | "CurrentCostTotal" | "CurrentCostAverage" | "RecommendationOptionsConfigurationMemorySize" | "RecommendationOptionsCostLow" | "RecommendationOptionsCostHigh" | "RecommendationOptionsProjectedUtilizationMetricsDurationLowerBound" | "RecommendationOptionsProjectedUtilizationMetricsDurationUpperBound" | "RecommendationOptionsProjectedUtilizationMetricsDurationExpected" | "LastRefreshTimestamp" | "CurrentPerformanceRisk" | "RecommendationOptionsSavingsOpportunityPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrency" | "RecommendationOptionsEstimatedMonthlySavingsValue" | "Tags" | "EffectiveRecommendationPreferencesSavingsEstimationMode" | "RecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "RecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | (string & {});
export declare const ExportableLambdaFunctionField: any;
export type ExportableLambdaFunctionFields = ExportableLambdaFunctionField[];
export declare const ExportableLambdaFunctionFields: any;
export interface ExportLambdaFunctionRecommendationsRequest {
    accountIds?: string[];
    filters?: LambdaFunctionRecommendationFilter[];
    fieldsToExport?: ExportableLambdaFunctionField[];
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat;
    includeMemberAccounts?: boolean;
}
export declare const ExportLambdaFunctionRecommendationsRequest: S.Schema<ExportLambdaFunctionRecommendationsRequest>;
export interface ExportLambdaFunctionRecommendationsResponse {
    jobId?: string;
    s3Destination?: S3Destination;
}
export declare const ExportLambdaFunctionRecommendationsResponse: S.Schema<ExportLambdaFunctionRecommendationsResponse>;
export type LicenseRecommendationFilterName = "Finding" | "FindingReasonCode" | "LicenseName" | (string & {});
export declare const LicenseRecommendationFilterName: any;
export interface LicenseRecommendationFilter {
    name?: LicenseRecommendationFilterName;
    values?: string[];
}
export declare const LicenseRecommendationFilter: S.Schema<LicenseRecommendationFilter>;
export type LicenseRecommendationFilters = LicenseRecommendationFilter[];
export declare const LicenseRecommendationFilters: any;
export type ExportableLicenseField = "AccountId" | "ResourceArn" | "LookbackPeriodInDays" | "LastRefreshTimestamp" | "Finding" | "FindingReasonCodes" | "CurrentLicenseConfigurationNumberOfCores" | "CurrentLicenseConfigurationInstanceType" | "CurrentLicenseConfigurationOperatingSystem" | "CurrentLicenseConfigurationLicenseName" | "CurrentLicenseConfigurationLicenseEdition" | "CurrentLicenseConfigurationLicenseModel" | "CurrentLicenseConfigurationLicenseVersion" | "CurrentLicenseConfigurationMetricsSource" | "RecommendationOptionsOperatingSystem" | "RecommendationOptionsLicenseEdition" | "RecommendationOptionsLicenseModel" | "RecommendationOptionsSavingsOpportunityPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrency" | "RecommendationOptionsEstimatedMonthlySavingsValue" | "Tags" | (string & {});
export declare const ExportableLicenseField: any;
export type ExportableLicenseFields = ExportableLicenseField[];
export declare const ExportableLicenseFields: any;
export interface ExportLicenseRecommendationsRequest {
    accountIds?: string[];
    filters?: LicenseRecommendationFilter[];
    fieldsToExport?: ExportableLicenseField[];
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat;
    includeMemberAccounts?: boolean;
}
export declare const ExportLicenseRecommendationsRequest: S.Schema<ExportLicenseRecommendationsRequest>;
export interface ExportLicenseRecommendationsResponse {
    jobId?: string;
    s3Destination?: S3Destination;
}
export declare const ExportLicenseRecommendationsResponse: S.Schema<ExportLicenseRecommendationsResponse>;
export type RDSDBRecommendationFilterName = "InstanceFinding" | "InstanceFindingReasonCode" | "StorageFinding" | "StorageFindingReasonCode" | "Idle" | (string & {});
export declare const RDSDBRecommendationFilterName: any;
export interface RDSDBRecommendationFilter {
    name?: RDSDBRecommendationFilterName;
    values?: string[];
}
export declare const RDSDBRecommendationFilter: S.Schema<RDSDBRecommendationFilter>;
export type RDSDBRecommendationFilters = RDSDBRecommendationFilter[];
export declare const RDSDBRecommendationFilters: any;
export type ExportableRDSDBField = "ResourceArn" | "AccountId" | "Engine" | "EngineVersion" | "Idle" | "MultiAZDBInstance" | "ClusterWriter" | "CurrentDBInstanceClass" | "CurrentStorageConfigurationStorageType" | "CurrentStorageConfigurationAllocatedStorage" | "CurrentStorageConfigurationMaxAllocatedStorage" | "CurrentStorageConfigurationIOPS" | "CurrentStorageConfigurationStorageThroughput" | "CurrentStorageEstimatedMonthlyVolumeIOPsCostVariation" | "CurrentInstanceOnDemandHourlyPrice" | "CurrentStorageOnDemandMonthlyPrice" | "LookbackPeriodInDays" | "CurrentStorageEstimatedClusterInstanceOnDemandMonthlyCost" | "CurrentStorageEstimatedClusterStorageOnDemandMonthlyCost" | "CurrentStorageEstimatedClusterStorageIOOnDemandMonthlyCost" | "CurrentInstancePerformanceRisk" | "UtilizationMetricsCpuMaximum" | "UtilizationMetricsMemoryMaximum" | "UtilizationMetricsEBSVolumeStorageSpaceUtilizationMaximum" | "UtilizationMetricsNetworkReceiveThroughputMaximum" | "UtilizationMetricsNetworkTransmitThroughputMaximum" | "UtilizationMetricsEBSVolumeReadIOPSMaximum" | "UtilizationMetricsEBSVolumeWriteIOPSMaximum" | "UtilizationMetricsEBSVolumeReadThroughputMaximum" | "UtilizationMetricsEBSVolumeWriteThroughputMaximum" | "UtilizationMetricsDatabaseConnectionsMaximum" | "UtilizationMetricsStorageNetworkReceiveThroughputMaximum" | "UtilizationMetricsStorageNetworkTransmitThroughputMaximum" | "UtilizationMetricsAuroraMemoryHealthStateMaximum" | "UtilizationMetricsAuroraMemoryNumDeclinedSqlTotalMaximum" | "UtilizationMetricsAuroraMemoryNumKillConnTotalMaximum" | "UtilizationMetricsAuroraMemoryNumKillQueryTotalMaximum" | "UtilizationMetricsReadIOPSEphemeralStorageMaximum" | "UtilizationMetricsWriteIOPSEphemeralStorageMaximum" | "UtilizationMetricsVolumeBytesUsedAverage" | "UtilizationMetricsVolumeReadIOPsAverage" | "UtilizationMetricsVolumeWriteIOPsAverage" | "InstanceFinding" | "InstanceFindingReasonCodes" | "StorageFinding" | "StorageFindingReasonCodes" | "InstanceRecommendationOptionsDBInstanceClass" | "InstanceRecommendationOptionsRank" | "InstanceRecommendationOptionsPerformanceRisk" | "InstanceRecommendationOptionsProjectedUtilizationMetricsCpuMaximum" | "StorageRecommendationOptionsStorageType" | "StorageRecommendationOptionsAllocatedStorage" | "StorageRecommendationOptionsMaxAllocatedStorage" | "StorageRecommendationOptionsIOPS" | "StorageRecommendationOptionsStorageThroughput" | "StorageRecommendationOptionsRank" | "StorageRecommendationOptionsEstimatedMonthlyVolumeIOPsCostVariation" | "InstanceRecommendationOptionsInstanceOnDemandHourlyPrice" | "InstanceRecommendationOptionsSavingsOpportunityPercentage" | "InstanceRecommendationOptionsEstimatedMonthlySavingsCurrency" | "InstanceRecommendationOptionsEstimatedMonthlySavingsValue" | "InstanceRecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "InstanceRecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "InstanceRecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | "StorageRecommendationOptionsOnDemandMonthlyPrice" | "StorageRecommendationOptionsEstimatedClusterInstanceOnDemandMonthlyCost" | "StorageRecommendationOptionsEstimatedClusterStorageOnDemandMonthlyCost" | "StorageRecommendationOptionsEstimatedClusterStorageIOOnDemandMonthlyCost" | "StorageRecommendationOptionsSavingsOpportunityPercentage" | "StorageRecommendationOptionsEstimatedMonthlySavingsCurrency" | "StorageRecommendationOptionsEstimatedMonthlySavingsValue" | "StorageRecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "StorageRecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "StorageRecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | "EffectiveRecommendationPreferencesCpuVendorArchitectures" | "EffectiveRecommendationPreferencesEnhancedInfrastructureMetrics" | "EffectiveRecommendationPreferencesLookBackPeriod" | "EffectiveRecommendationPreferencesSavingsEstimationMode" | "LastRefreshTimestamp" | "Tags" | "DBClusterIdentifier" | "PromotionTier" | (string & {});
export declare const ExportableRDSDBField: any;
export type ExportableRDSDBFields = ExportableRDSDBField[];
export declare const ExportableRDSDBFields: any;
export interface ExportRDSDatabaseRecommendationsRequest {
    accountIds?: string[];
    filters?: RDSDBRecommendationFilter[];
    fieldsToExport?: ExportableRDSDBField[];
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat;
    includeMemberAccounts?: boolean;
    recommendationPreferences?: RecommendationPreferences;
}
export declare const ExportRDSDatabaseRecommendationsRequest: S.Schema<ExportRDSDatabaseRecommendationsRequest>;
export interface ExportRDSDatabaseRecommendationsResponse {
    jobId?: string;
    s3Destination?: S3Destination;
}
export declare const ExportRDSDatabaseRecommendationsResponse: S.Schema<ExportRDSDatabaseRecommendationsResponse>;
export type AutoScalingGroupArn = string;
export type AutoScalingGroupArns = string[];
export declare const AutoScalingGroupArns: any;
export interface GetAutoScalingGroupRecommendationsRequest {
    accountIds?: string[];
    autoScalingGroupArns?: string[];
    nextToken?: string;
    maxResults?: number;
    filters?: Filter[];
    recommendationPreferences?: RecommendationPreferences;
}
export declare const GetAutoScalingGroupRecommendationsRequest: S.Schema<GetAutoScalingGroupRecommendationsRequest>;
export type AutoScalingGroupName = string;
export type Finding = "Underprovisioned" | "Overprovisioned" | "Optimized" | "NotOptimized" | (string & {});
export declare const Finding: any;
export type MetricName = "Cpu" | "Memory" | "EBS_READ_OPS_PER_SECOND" | "EBS_WRITE_OPS_PER_SECOND" | "EBS_READ_BYTES_PER_SECOND" | "EBS_WRITE_BYTES_PER_SECOND" | "DISK_READ_OPS_PER_SECOND" | "DISK_WRITE_OPS_PER_SECOND" | "DISK_READ_BYTES_PER_SECOND" | "DISK_WRITE_BYTES_PER_SECOND" | "NETWORK_IN_BYTES_PER_SECOND" | "NETWORK_OUT_BYTES_PER_SECOND" | "NETWORK_PACKETS_IN_PER_SECOND" | "NETWORK_PACKETS_OUT_PER_SECOND" | "GPU_PERCENTAGE" | "GPU_MEMORY_PERCENTAGE" | (string & {});
export declare const MetricName: any;
export type MetricStatistic = "Maximum" | "Average" | (string & {});
export declare const MetricStatistic: any;
export type MetricValue = number;
export interface UtilizationMetric {
    name?: MetricName;
    statistic?: MetricStatistic;
    value?: number;
}
export declare const UtilizationMetric: S.Schema<UtilizationMetric>;
export type UtilizationMetrics = UtilizationMetric[];
export declare const UtilizationMetrics: any;
export type LookBackPeriodInDays = number;
export type DesiredCapacity = number;
export type MinSize = number;
export type MaxSize = number;
export type NullableInstanceType = string;
export type AllocationStrategy = "Prioritized" | "LowestPrice" | (string & {});
export declare const AllocationStrategy: any;
export type NullableEstimatedInstanceHourReductionPercentage = number;
export type AsgType = "SingleInstanceType" | "MixedInstanceTypes" | (string & {});
export declare const AsgType: any;
export type MixedInstanceType = string;
export type MixedInstanceTypes = string[];
export declare const MixedInstanceTypes: any;
export interface AutoScalingGroupConfiguration {
    desiredCapacity?: number;
    minSize?: number;
    maxSize?: number;
    instanceType?: string;
    allocationStrategy?: AllocationStrategy;
    estimatedInstanceHourReductionPercentage?: number;
    type?: AsgType;
    mixedInstanceTypes?: string[];
}
export declare const AutoScalingGroupConfiguration: S.Schema<AutoScalingGroupConfiguration>;
export type GpuCount = number;
export type GpuMemorySizeInMiB = number;
export interface Gpu {
    gpuCount?: number;
    gpuMemorySizeInMiB?: number;
}
export declare const Gpu: S.Schema<Gpu>;
export type Gpus = Gpu[];
export declare const Gpus: any;
export interface GpuInfo {
    gpus?: Gpu[];
}
export declare const GpuInfo: S.Schema<GpuInfo>;
export type ProjectedUtilizationMetrics = UtilizationMetric[];
export declare const ProjectedUtilizationMetrics: any;
export type PerformanceRisk = number;
export type Rank = number;
export type SavingsOpportunityPercentage = number;
export type Currency = "USD" | "CNY" | (string & {});
export declare const Currency: any;
export type Value = number;
export interface EstimatedMonthlySavings {
    currency?: Currency;
    value?: number;
}
export declare const EstimatedMonthlySavings: S.Schema<EstimatedMonthlySavings>;
export interface SavingsOpportunity {
    savingsOpportunityPercentage?: number;
    estimatedMonthlySavings?: EstimatedMonthlySavings;
}
export declare const SavingsOpportunity: S.Schema<SavingsOpportunity>;
export interface AutoScalingGroupEstimatedMonthlySavings {
    currency?: Currency;
    value?: number;
}
export declare const AutoScalingGroupEstimatedMonthlySavings: S.Schema<AutoScalingGroupEstimatedMonthlySavings>;
export interface AutoScalingGroupSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number;
    estimatedMonthlySavings?: AutoScalingGroupEstimatedMonthlySavings;
}
export declare const AutoScalingGroupSavingsOpportunityAfterDiscounts: S.Schema<AutoScalingGroupSavingsOpportunityAfterDiscounts>;
export type MigrationEffort = "VeryLow" | "Low" | "Medium" | "High" | (string & {});
export declare const MigrationEffort: any;
export interface AutoScalingGroupRecommendationOption {
    configuration?: AutoScalingGroupConfiguration;
    instanceGpuInfo?: GpuInfo;
    projectedUtilizationMetrics?: UtilizationMetric[];
    performanceRisk?: number;
    rank?: number;
    savingsOpportunity?: SavingsOpportunity;
    savingsOpportunityAfterDiscounts?: AutoScalingGroupSavingsOpportunityAfterDiscounts;
    migrationEffort?: MigrationEffort;
}
export declare const AutoScalingGroupRecommendationOption: S.Schema<AutoScalingGroupRecommendationOption>;
export type AutoScalingGroupRecommendationOptions = AutoScalingGroupRecommendationOption[];
export declare const AutoScalingGroupRecommendationOptions: any;
export type LastRefreshTimestamp = Date;
export type CurrentPerformanceRisk = "VeryLow" | "Low" | "Medium" | "High" | (string & {});
export declare const CurrentPerformanceRisk: any;
export type EnhancedInfrastructureMetrics = "Active" | "Inactive" | (string & {});
export declare const EnhancedInfrastructureMetrics: any;
export type InferredWorkloadTypesPreference = "Active" | "Inactive" | (string & {});
export declare const InferredWorkloadTypesPreference: any;
export type ExternalMetricsSource = "Datadog" | "Dynatrace" | "NewRelic" | "Instana" | (string & {});
export declare const ExternalMetricsSource: any;
export interface ExternalMetricsPreference {
    source?: ExternalMetricsSource;
}
export declare const ExternalMetricsPreference: S.Schema<ExternalMetricsPreference>;
export type LookBackPeriodPreference = "DAYS_14" | "DAYS_32" | "DAYS_93" | (string & {});
export declare const LookBackPeriodPreference: any;
export type CustomizableMetricName = "CpuUtilization" | "MemoryUtilization" | (string & {});
export declare const CustomizableMetricName: any;
export type CustomizableMetricThreshold = "P90" | "P95" | "P99_5" | (string & {});
export declare const CustomizableMetricThreshold: any;
export type CustomizableMetricHeadroom = "PERCENT_30" | "PERCENT_20" | "PERCENT_10" | "PERCENT_0" | (string & {});
export declare const CustomizableMetricHeadroom: any;
export interface CustomizableMetricParameters {
    threshold?: CustomizableMetricThreshold;
    headroom?: CustomizableMetricHeadroom;
}
export declare const CustomizableMetricParameters: S.Schema<CustomizableMetricParameters>;
export interface UtilizationPreference {
    metricName?: CustomizableMetricName;
    metricParameters?: CustomizableMetricParameters;
}
export declare const UtilizationPreference: S.Schema<UtilizationPreference>;
export type UtilizationPreferences = UtilizationPreference[];
export declare const UtilizationPreferences: any;
export type PreferredResourceName = "Ec2InstanceTypes" | (string & {});
export declare const PreferredResourceName: any;
export type PreferredResourceValue = string;
export type PreferredResourceValues = string[];
export declare const PreferredResourceValues: any;
export interface EffectivePreferredResource {
    name?: PreferredResourceName;
    includeList?: string[];
    effectiveIncludeList?: string[];
    excludeList?: string[];
}
export declare const EffectivePreferredResource: S.Schema<EffectivePreferredResource>;
export type EffectivePreferredResources = EffectivePreferredResource[];
export declare const EffectivePreferredResources: any;
export type InstanceSavingsEstimationModeSource = "PublicPricing" | "CostExplorerRightsizing" | "CostOptimizationHub" | (string & {});
export declare const InstanceSavingsEstimationModeSource: any;
export interface InstanceSavingsEstimationMode {
    source?: InstanceSavingsEstimationModeSource;
}
export declare const InstanceSavingsEstimationMode: S.Schema<InstanceSavingsEstimationMode>;
export interface EffectiveRecommendationPreferences {
    cpuVendorArchitectures?: CpuVendorArchitecture[];
    enhancedInfrastructureMetrics?: EnhancedInfrastructureMetrics;
    inferredWorkloadTypes?: InferredWorkloadTypesPreference;
    externalMetricsPreference?: ExternalMetricsPreference;
    lookBackPeriod?: LookBackPeriodPreference;
    utilizationPreferences?: UtilizationPreference[];
    preferredResources?: EffectivePreferredResource[];
    savingsEstimationMode?: InstanceSavingsEstimationMode;
}
export declare const EffectiveRecommendationPreferences: S.Schema<EffectiveRecommendationPreferences>;
export type InferredWorkloadType = "AmazonEmr" | "ApacheCassandra" | "ApacheHadoop" | "Memcached" | "Nginx" | "PostgreSql" | "Redis" | "Kafka" | "SQLServer" | (string & {});
export declare const InferredWorkloadType: any;
export type InferredWorkloadTypes = InferredWorkloadType[];
export declare const InferredWorkloadTypes: any;
export interface AutoScalingGroupRecommendation {
    accountId?: string;
    autoScalingGroupArn?: string;
    autoScalingGroupName?: string;
    finding?: Finding;
    utilizationMetrics?: UtilizationMetric[];
    lookBackPeriodInDays?: number;
    currentConfiguration?: AutoScalingGroupConfiguration;
    currentInstanceGpuInfo?: GpuInfo;
    recommendationOptions?: AutoScalingGroupRecommendationOption[];
    lastRefreshTimestamp?: Date;
    currentPerformanceRisk?: CurrentPerformanceRisk;
    effectiveRecommendationPreferences?: EffectiveRecommendationPreferences;
    inferredWorkloadTypes?: InferredWorkloadType[];
}
export declare const AutoScalingGroupRecommendation: S.Schema<AutoScalingGroupRecommendation>;
export type AutoScalingGroupRecommendations = AutoScalingGroupRecommendation[];
export declare const AutoScalingGroupRecommendations: any;
export type Identifier = string;
export type Code = string;
export type Message = string;
export interface GetRecommendationError {
    identifier?: string;
    code?: string;
    message?: string;
}
export declare const GetRecommendationError: S.Schema<GetRecommendationError>;
export type GetRecommendationErrors = GetRecommendationError[];
export declare const GetRecommendationErrors: any;
export interface GetAutoScalingGroupRecommendationsResponse {
    nextToken?: string;
    autoScalingGroupRecommendations?: AutoScalingGroupRecommendation[];
    errors?: GetRecommendationError[];
}
export declare const GetAutoScalingGroupRecommendationsResponse: S.Schema<GetAutoScalingGroupRecommendationsResponse>;
export type VolumeArn = string;
export type VolumeArns = string[];
export declare const VolumeArns: any;
export interface GetEBSVolumeRecommendationsRequest {
    volumeArns?: string[];
    nextToken?: string;
    maxResults?: number;
    filters?: EBSFilter[];
    accountIds?: string[];
}
export declare const GetEBSVolumeRecommendationsRequest: S.Schema<GetEBSVolumeRecommendationsRequest>;
export type VolumeType = string;
export type VolumeSize = number;
export type VolumeBaselineIOPS = number;
export type VolumeBurstIOPS = number;
export type VolumeBaselineThroughput = number;
export type VolumeBurstThroughput = number;
export type RootVolume = boolean;
export interface VolumeConfiguration {
    volumeType?: string;
    volumeSize?: number;
    volumeBaselineIOPS?: number;
    volumeBurstIOPS?: number;
    volumeBaselineThroughput?: number;
    volumeBurstThroughput?: number;
    rootVolume?: boolean;
}
export declare const VolumeConfiguration: S.Schema<VolumeConfiguration>;
export type EBSFinding = "Optimized" | "NotOptimized" | (string & {});
export declare const EBSFinding: any;
export type EBSMetricName = "VolumeReadOpsPerSecond" | "VolumeWriteOpsPerSecond" | "VolumeReadBytesPerSecond" | "VolumeWriteBytesPerSecond" | "VolumeIOPSExceeded" | "VolumeThroughputExceeded" | (string & {});
export declare const EBSMetricName: any;
export interface EBSUtilizationMetric {
    name?: EBSMetricName;
    statistic?: MetricStatistic;
    value?: number;
}
export declare const EBSUtilizationMetric: S.Schema<EBSUtilizationMetric>;
export type EBSUtilizationMetrics = EBSUtilizationMetric[];
export declare const EBSUtilizationMetrics: any;
export interface EBSEstimatedMonthlySavings {
    currency?: Currency;
    value?: number;
}
export declare const EBSEstimatedMonthlySavings: S.Schema<EBSEstimatedMonthlySavings>;
export interface EBSSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number;
    estimatedMonthlySavings?: EBSEstimatedMonthlySavings;
}
export declare const EBSSavingsOpportunityAfterDiscounts: S.Schema<EBSSavingsOpportunityAfterDiscounts>;
export interface VolumeRecommendationOption {
    configuration?: VolumeConfiguration;
    performanceRisk?: number;
    rank?: number;
    savingsOpportunity?: SavingsOpportunity;
    savingsOpportunityAfterDiscounts?: EBSSavingsOpportunityAfterDiscounts;
}
export declare const VolumeRecommendationOption: S.Schema<VolumeRecommendationOption>;
export type VolumeRecommendationOptions = VolumeRecommendationOption[];
export declare const VolumeRecommendationOptions: any;
export type EBSSavingsEstimationModeSource = "PublicPricing" | "CostExplorerRightsizing" | "CostOptimizationHub" | (string & {});
export declare const EBSSavingsEstimationModeSource: any;
export interface EBSSavingsEstimationMode {
    source?: EBSSavingsEstimationModeSource;
}
export declare const EBSSavingsEstimationMode: S.Schema<EBSSavingsEstimationMode>;
export interface EBSEffectiveRecommendationPreferences {
    savingsEstimationMode?: EBSSavingsEstimationMode;
    lookBackPeriod?: LookBackPeriodPreference;
}
export declare const EBSEffectiveRecommendationPreferences: S.Schema<EBSEffectiveRecommendationPreferences>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key?: string;
    value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export interface VolumeRecommendation {
    volumeArn?: string;
    accountId?: string;
    currentConfiguration?: VolumeConfiguration;
    finding?: EBSFinding;
    utilizationMetrics?: EBSUtilizationMetric[];
    lookBackPeriodInDays?: number;
    volumeRecommendationOptions?: VolumeRecommendationOption[];
    lastRefreshTimestamp?: Date;
    currentPerformanceRisk?: CurrentPerformanceRisk;
    effectiveRecommendationPreferences?: EBSEffectiveRecommendationPreferences;
    tags?: Tag[];
}
export declare const VolumeRecommendation: S.Schema<VolumeRecommendation>;
export type VolumeRecommendations = VolumeRecommendation[];
export declare const VolumeRecommendations: any;
export interface GetEBSVolumeRecommendationsResponse {
    nextToken?: string;
    volumeRecommendations?: VolumeRecommendation[];
    errors?: GetRecommendationError[];
}
export declare const GetEBSVolumeRecommendationsResponse: S.Schema<GetEBSVolumeRecommendationsResponse>;
export type InstanceArn = string;
export type InstanceArns = string[];
export declare const InstanceArns: any;
export interface GetEC2InstanceRecommendationsRequest {
    instanceArns?: string[];
    nextToken?: string;
    maxResults?: number;
    filters?: Filter[];
    accountIds?: string[];
    recommendationPreferences?: RecommendationPreferences;
}
export declare const GetEC2InstanceRecommendationsRequest: S.Schema<GetEC2InstanceRecommendationsRequest>;
export type InstanceName = string;
export type CurrentInstanceType = string;
export type InstanceRecommendationFindingReasonCode = "CPUOverprovisioned" | "CPUUnderprovisioned" | "MemoryOverprovisioned" | "MemoryUnderprovisioned" | "EBSThroughputOverprovisioned" | "EBSThroughputUnderprovisioned" | "EBSIOPSOverprovisioned" | "EBSIOPSUnderprovisioned" | "NetworkBandwidthOverprovisioned" | "NetworkBandwidthUnderprovisioned" | "NetworkPPSOverprovisioned" | "NetworkPPSUnderprovisioned" | "DiskIOPSOverprovisioned" | "DiskIOPSUnderprovisioned" | "DiskThroughputOverprovisioned" | "DiskThroughputUnderprovisioned" | "GPUUnderprovisioned" | "GPUOverprovisioned" | "GPUMemoryUnderprovisioned" | "GPUMemoryOverprovisioned" | (string & {});
export declare const InstanceRecommendationFindingReasonCode: any;
export type InstanceRecommendationFindingReasonCodes = InstanceRecommendationFindingReasonCode[];
export declare const InstanceRecommendationFindingReasonCodes: any;
export type InstanceType = string;
export type PlatformDifference = "Hypervisor" | "NetworkInterface" | "StorageInterface" | "InstanceStoreAvailability" | "VirtualizationType" | "Architecture" | (string & {});
export declare const PlatformDifference: any;
export type PlatformDifferences = PlatformDifference[];
export declare const PlatformDifferences: any;
export interface InstanceEstimatedMonthlySavings {
    currency?: Currency;
    value?: number;
}
export declare const InstanceEstimatedMonthlySavings: S.Schema<InstanceEstimatedMonthlySavings>;
export interface InstanceSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number;
    estimatedMonthlySavings?: InstanceEstimatedMonthlySavings;
}
export declare const InstanceSavingsOpportunityAfterDiscounts: S.Schema<InstanceSavingsOpportunityAfterDiscounts>;
export interface InstanceRecommendationOption {
    instanceType?: string;
    instanceGpuInfo?: GpuInfo;
    projectedUtilizationMetrics?: UtilizationMetric[];
    platformDifferences?: PlatformDifference[];
    performanceRisk?: number;
    rank?: number;
    savingsOpportunity?: SavingsOpportunity;
    savingsOpportunityAfterDiscounts?: InstanceSavingsOpportunityAfterDiscounts;
    migrationEffort?: MigrationEffort;
}
export declare const InstanceRecommendationOption: S.Schema<InstanceRecommendationOption>;
export type RecommendationOptions = InstanceRecommendationOption[];
export declare const RecommendationOptions: any;
export type RecommendationSourceArn = string;
export type RecommendationSourceType = "Ec2Instance" | "AutoScalingGroup" | "EbsVolume" | "LambdaFunction" | "EcsService" | "License" | "RdsDBInstance" | "RdsDBInstanceStorage" | "AuroraDBClusterStorage" | "NatGateway" | "DynamoDBTable" | "ElastiCacheCluster" | "MemoryDBCluster" | "DocumentDBCluster" | "WorkSpaces" | "SageMakerEndpoint" | (string & {});
export declare const RecommendationSourceType: any;
export interface RecommendationSource {
    recommendationSourceArn?: string;
    recommendationSourceType?: RecommendationSourceType;
}
export declare const RecommendationSource: S.Schema<RecommendationSource>;
export type RecommendationSources = RecommendationSource[];
export declare const RecommendationSources: any;
export type InstanceState = "pending" | "running" | "shutting-down" | "terminated" | "stopping" | "stopped" | (string & {});
export declare const InstanceState: any;
export type ExternalMetricStatusCode = "NO_EXTERNAL_METRIC_SET" | "INTEGRATION_SUCCESS" | "DATADOG_INTEGRATION_ERROR" | "DYNATRACE_INTEGRATION_ERROR" | "NEWRELIC_INTEGRATION_ERROR" | "INSTANA_INTEGRATION_ERROR" | "INSUFFICIENT_DATADOG_METRICS" | "INSUFFICIENT_DYNATRACE_METRICS" | "INSUFFICIENT_NEWRELIC_METRICS" | "INSUFFICIENT_INSTANA_METRICS" | (string & {});
export declare const ExternalMetricStatusCode: any;
export type ExternalMetricStatusReason = string;
export interface ExternalMetricStatus {
    statusCode?: ExternalMetricStatusCode;
    statusReason?: string;
}
export declare const ExternalMetricStatus: S.Schema<ExternalMetricStatus>;
export type InstanceIdle = "True" | "False" | (string & {});
export declare const InstanceIdle: any;
export interface InstanceRecommendation {
    instanceArn?: string;
    accountId?: string;
    instanceName?: string;
    currentInstanceType?: string;
    finding?: Finding;
    findingReasonCodes?: InstanceRecommendationFindingReasonCode[];
    utilizationMetrics?: UtilizationMetric[];
    lookBackPeriodInDays?: number;
    recommendationOptions?: InstanceRecommendationOption[];
    recommendationSources?: RecommendationSource[];
    lastRefreshTimestamp?: Date;
    currentPerformanceRisk?: CurrentPerformanceRisk;
    effectiveRecommendationPreferences?: EffectiveRecommendationPreferences;
    inferredWorkloadTypes?: InferredWorkloadType[];
    instanceState?: InstanceState;
    tags?: Tag[];
    externalMetricStatus?: ExternalMetricStatus;
    currentInstanceGpuInfo?: GpuInfo;
    idle?: InstanceIdle;
}
export declare const InstanceRecommendation: S.Schema<InstanceRecommendation>;
export type InstanceRecommendations = InstanceRecommendation[];
export declare const InstanceRecommendations: any;
export interface GetEC2InstanceRecommendationsResponse {
    nextToken?: string;
    instanceRecommendations?: InstanceRecommendation[];
    errors?: GetRecommendationError[];
}
export declare const GetEC2InstanceRecommendationsResponse: S.Schema<GetEC2InstanceRecommendationsResponse>;
export type Period = number;
export interface GetEC2RecommendationProjectedMetricsRequest {
    instanceArn: string;
    stat: MetricStatistic;
    period: number;
    startTime: Date;
    endTime: Date;
    recommendationPreferences?: RecommendationPreferences;
}
export declare const GetEC2RecommendationProjectedMetricsRequest: S.Schema<GetEC2RecommendationProjectedMetricsRequest>;
export type RecommendedInstanceType = string;
export type Timestamps = Date[];
export declare const Timestamps: any;
export type MetricValues = number[];
export declare const MetricValues: any;
export interface ProjectedMetric {
    name?: MetricName;
    timestamps?: Date[];
    values?: number[];
}
export declare const ProjectedMetric: S.Schema<ProjectedMetric>;
export type ProjectedMetrics = ProjectedMetric[];
export declare const ProjectedMetrics: any;
export interface RecommendedOptionProjectedMetric {
    recommendedInstanceType?: string;
    rank?: number;
    projectedMetrics?: ProjectedMetric[];
}
export declare const RecommendedOptionProjectedMetric: S.Schema<RecommendedOptionProjectedMetric>;
export type RecommendedOptionProjectedMetrics = RecommendedOptionProjectedMetric[];
export declare const RecommendedOptionProjectedMetrics: any;
export interface GetEC2RecommendationProjectedMetricsResponse {
    recommendedOptionProjectedMetrics?: RecommendedOptionProjectedMetric[];
}
export declare const GetEC2RecommendationProjectedMetricsResponse: S.Schema<GetEC2RecommendationProjectedMetricsResponse>;
export type ServiceArn = string;
export interface GetECSServiceRecommendationProjectedMetricsRequest {
    serviceArn: string;
    stat: MetricStatistic;
    period: number;
    startTime: Date;
    endTime: Date;
}
export declare const GetECSServiceRecommendationProjectedMetricsRequest: S.Schema<GetECSServiceRecommendationProjectedMetricsRequest>;
export type CpuSize = number;
export type MemorySize = number;
export type ECSServiceMetricName = "Cpu" | "Memory" | (string & {});
export declare const ECSServiceMetricName: any;
export interface ECSServiceProjectedMetric {
    name?: ECSServiceMetricName;
    timestamps?: Date[];
    upperBoundValues?: number[];
    lowerBoundValues?: number[];
}
export declare const ECSServiceProjectedMetric: S.Schema<ECSServiceProjectedMetric>;
export type ECSServiceProjectedMetrics = ECSServiceProjectedMetric[];
export declare const ECSServiceProjectedMetrics: any;
export interface ECSServiceRecommendedOptionProjectedMetric {
    recommendedCpuUnits?: number;
    recommendedMemorySize?: number;
    projectedMetrics?: ECSServiceProjectedMetric[];
}
export declare const ECSServiceRecommendedOptionProjectedMetric: S.Schema<ECSServiceRecommendedOptionProjectedMetric>;
export type ECSServiceRecommendedOptionProjectedMetrics = ECSServiceRecommendedOptionProjectedMetric[];
export declare const ECSServiceRecommendedOptionProjectedMetrics: any;
export interface GetECSServiceRecommendationProjectedMetricsResponse {
    recommendedOptionProjectedMetrics?: ECSServiceRecommendedOptionProjectedMetric[];
}
export declare const GetECSServiceRecommendationProjectedMetricsResponse: S.Schema<GetECSServiceRecommendationProjectedMetricsResponse>;
export type ServiceArns = string[];
export declare const ServiceArns: any;
export interface GetECSServiceRecommendationsRequest {
    serviceArns?: string[];
    nextToken?: string;
    maxResults?: number;
    filters?: ECSServiceRecommendationFilter[];
    accountIds?: string[];
}
export declare const GetECSServiceRecommendationsRequest: S.Schema<GetECSServiceRecommendationsRequest>;
export type NullableMemory = number;
export type NullableCpu = number;
export type ContainerName = string;
export type NullableMemoryReservation = number;
export interface MemorySizeConfiguration {
    memory?: number;
    memoryReservation?: number;
}
export declare const MemorySizeConfiguration: S.Schema<MemorySizeConfiguration>;
export interface ContainerConfiguration {
    containerName?: string;
    memorySizeConfiguration?: MemorySizeConfiguration;
    cpu?: number;
}
export declare const ContainerConfiguration: S.Schema<ContainerConfiguration>;
export type ContainerConfigurations = ContainerConfiguration[];
export declare const ContainerConfigurations: any;
export type AutoScalingConfiguration = "TargetTrackingScalingCpu" | "TargetTrackingScalingMemory" | (string & {});
export declare const AutoScalingConfiguration: any;
export type TaskDefinitionArn = string;
export interface ServiceConfiguration {
    memory?: number;
    cpu?: number;
    containerConfigurations?: ContainerConfiguration[];
    autoScalingConfiguration?: AutoScalingConfiguration;
    taskDefinitionArn?: string;
}
export declare const ServiceConfiguration: S.Schema<ServiceConfiguration>;
export type ECSServiceMetricStatistic = "Maximum" | "Average" | (string & {});
export declare const ECSServiceMetricStatistic: any;
export interface ECSServiceUtilizationMetric {
    name?: ECSServiceMetricName;
    statistic?: ECSServiceMetricStatistic;
    value?: number;
}
export declare const ECSServiceUtilizationMetric: S.Schema<ECSServiceUtilizationMetric>;
export type ECSServiceUtilizationMetrics = ECSServiceUtilizationMetric[];
export declare const ECSServiceUtilizationMetrics: any;
export type ECSServiceLaunchType = "EC2" | "Fargate" | (string & {});
export declare const ECSServiceLaunchType: any;
export type ECSServiceRecommendationFinding = "Optimized" | "Underprovisioned" | "Overprovisioned" | (string & {});
export declare const ECSServiceRecommendationFinding: any;
export type ECSServiceRecommendationFindingReasonCode = "MemoryOverprovisioned" | "MemoryUnderprovisioned" | "CPUOverprovisioned" | "CPUUnderprovisioned" | (string & {});
export declare const ECSServiceRecommendationFindingReasonCode: any;
export type ECSServiceRecommendationFindingReasonCodes = ECSServiceRecommendationFindingReasonCode[];
export declare const ECSServiceRecommendationFindingReasonCodes: any;
export interface ECSEstimatedMonthlySavings {
    currency?: Currency;
    value?: number;
}
export declare const ECSEstimatedMonthlySavings: S.Schema<ECSEstimatedMonthlySavings>;
export interface ECSSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number;
    estimatedMonthlySavings?: ECSEstimatedMonthlySavings;
}
export declare const ECSSavingsOpportunityAfterDiscounts: S.Schema<ECSSavingsOpportunityAfterDiscounts>;
export type LowerBoundValue = number;
export type UpperBoundValue = number;
export interface ECSServiceProjectedUtilizationMetric {
    name?: ECSServiceMetricName;
    statistic?: ECSServiceMetricStatistic;
    lowerBoundValue?: number;
    upperBoundValue?: number;
}
export declare const ECSServiceProjectedUtilizationMetric: S.Schema<ECSServiceProjectedUtilizationMetric>;
export type ECSServiceProjectedUtilizationMetrics = ECSServiceProjectedUtilizationMetric[];
export declare const ECSServiceProjectedUtilizationMetrics: any;
export interface ContainerRecommendation {
    containerName?: string;
    memorySizeConfiguration?: MemorySizeConfiguration;
    cpu?: number;
}
export declare const ContainerRecommendation: S.Schema<ContainerRecommendation>;
export type ContainerRecommendations = ContainerRecommendation[];
export declare const ContainerRecommendations: any;
export interface ECSServiceRecommendationOption {
    memory?: number;
    cpu?: number;
    savingsOpportunity?: SavingsOpportunity;
    savingsOpportunityAfterDiscounts?: ECSSavingsOpportunityAfterDiscounts;
    projectedUtilizationMetrics?: ECSServiceProjectedUtilizationMetric[];
    containerRecommendations?: ContainerRecommendation[];
}
export declare const ECSServiceRecommendationOption: S.Schema<ECSServiceRecommendationOption>;
export type ECSServiceRecommendationOptions = ECSServiceRecommendationOption[];
export declare const ECSServiceRecommendationOptions: any;
export type ECSSavingsEstimationModeSource = "PublicPricing" | "CostExplorerRightsizing" | "CostOptimizationHub" | (string & {});
export declare const ECSSavingsEstimationModeSource: any;
export interface ECSSavingsEstimationMode {
    source?: ECSSavingsEstimationModeSource;
}
export declare const ECSSavingsEstimationMode: S.Schema<ECSSavingsEstimationMode>;
export interface ECSEffectiveRecommendationPreferences {
    savingsEstimationMode?: ECSSavingsEstimationMode;
    lookBackPeriod?: LookBackPeriodPreference;
}
export declare const ECSEffectiveRecommendationPreferences: S.Schema<ECSEffectiveRecommendationPreferences>;
export interface ECSServiceRecommendation {
    serviceArn?: string;
    accountId?: string;
    currentServiceConfiguration?: ServiceConfiguration;
    utilizationMetrics?: ECSServiceUtilizationMetric[];
    lookbackPeriodInDays?: number;
    launchType?: ECSServiceLaunchType;
    lastRefreshTimestamp?: Date;
    finding?: ECSServiceRecommendationFinding;
    findingReasonCodes?: ECSServiceRecommendationFindingReasonCode[];
    serviceRecommendationOptions?: ECSServiceRecommendationOption[];
    currentPerformanceRisk?: CurrentPerformanceRisk;
    effectiveRecommendationPreferences?: ECSEffectiveRecommendationPreferences;
    tags?: Tag[];
}
export declare const ECSServiceRecommendation: S.Schema<ECSServiceRecommendation>;
export type ECSServiceRecommendations = ECSServiceRecommendation[];
export declare const ECSServiceRecommendations: any;
export interface GetECSServiceRecommendationsResponse {
    nextToken?: string;
    ecsServiceRecommendations?: ECSServiceRecommendation[];
    errors?: GetRecommendationError[];
}
export declare const GetECSServiceRecommendationsResponse: S.Schema<GetECSServiceRecommendationsResponse>;
export type ResourceArn = string;
export interface GetEffectiveRecommendationPreferencesRequest {
    resourceArn: string;
}
export declare const GetEffectiveRecommendationPreferencesRequest: S.Schema<GetEffectiveRecommendationPreferencesRequest>;
export interface GetEffectiveRecommendationPreferencesResponse {
    enhancedInfrastructureMetrics?: EnhancedInfrastructureMetrics;
    externalMetricsPreference?: ExternalMetricsPreference;
    lookBackPeriod?: LookBackPeriodPreference;
    utilizationPreferences?: UtilizationPreference[];
    preferredResources?: EffectivePreferredResource[];
}
export declare const GetEffectiveRecommendationPreferencesResponse: S.Schema<GetEffectiveRecommendationPreferencesResponse>;
export interface GetEnrollmentStatusRequest {
}
export declare const GetEnrollmentStatusRequest: S.Schema<GetEnrollmentStatusRequest>;
export type Status = "Active" | "Inactive" | "Pending" | "Failed" | (string & {});
export declare const Status: any;
export type StatusReason = string;
export type MemberAccountsEnrolled = boolean;
export type NumberOfMemberAccountsOptedIn = number;
export interface GetEnrollmentStatusResponse {
    status?: Status;
    statusReason?: string;
    memberAccountsEnrolled?: boolean;
    lastUpdatedTimestamp?: Date;
    numberOfMemberAccountsOptedIn?: number;
}
export declare const GetEnrollmentStatusResponse: S.Schema<GetEnrollmentStatusResponse>;
export type EnrollmentFilterName = "Status" | (string & {});
export declare const EnrollmentFilterName: any;
export interface EnrollmentFilter {
    name?: EnrollmentFilterName;
    values?: string[];
}
export declare const EnrollmentFilter: S.Schema<EnrollmentFilter>;
export type EnrollmentFilters = EnrollmentFilter[];
export declare const EnrollmentFilters: any;
export interface GetEnrollmentStatusesForOrganizationRequest {
    filters?: EnrollmentFilter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const GetEnrollmentStatusesForOrganizationRequest: S.Schema<GetEnrollmentStatusesForOrganizationRequest>;
export interface AccountEnrollmentStatus {
    accountId?: string;
    status?: Status;
    statusReason?: string;
    lastUpdatedTimestamp?: Date;
}
export declare const AccountEnrollmentStatus: S.Schema<AccountEnrollmentStatus>;
export type AccountEnrollmentStatuses = AccountEnrollmentStatus[];
export declare const AccountEnrollmentStatuses: any;
export interface GetEnrollmentStatusesForOrganizationResponse {
    accountEnrollmentStatuses?: AccountEnrollmentStatus[];
    nextToken?: string;
}
export declare const GetEnrollmentStatusesForOrganizationResponse: S.Schema<GetEnrollmentStatusesForOrganizationResponse>;
export type ResourceArns = string[];
export declare const ResourceArns: any;
export type IdleMaxResults = number;
export type Dimension = "SavingsValue" | "SavingsValueAfterDiscount" | (string & {});
export declare const Dimension: any;
export type Order = "Asc" | "Desc" | (string & {});
export declare const Order: any;
export interface OrderBy {
    dimension?: Dimension;
    order?: Order;
}
export declare const OrderBy: S.Schema<OrderBy>;
export interface GetIdleRecommendationsRequest {
    resourceArns?: string[];
    nextToken?: string;
    maxResults?: number;
    filters?: IdleRecommendationFilter[];
    accountIds?: string[];
    orderBy?: OrderBy;
}
export declare const GetIdleRecommendationsRequest: S.Schema<GetIdleRecommendationsRequest>;
export type ResourceId = string;
export type IdleRecommendationResourceType = "EC2Instance" | "AutoScalingGroup" | "EBSVolume" | "ECSService" | "RDSDBInstance" | "NatGateway" | "DynamoDBTable" | "ElastiCacheCluster" | "MemoryDBCluster" | "DocumentDBCluster" | "WorkSpaces" | "SageMakerEndpoint" | (string & {});
export declare const IdleRecommendationResourceType: any;
export type IdleFinding = "Idle" | "Unattached" | "Unused" | (string & {});
export declare const IdleFinding: any;
export type IdleFindingDescription = string;
export interface IdleEstimatedMonthlySavings {
    currency?: Currency;
    value?: number;
}
export declare const IdleEstimatedMonthlySavings: S.Schema<IdleEstimatedMonthlySavings>;
export interface IdleSavingsOpportunity {
    savingsOpportunityPercentage?: number;
    estimatedMonthlySavings?: IdleEstimatedMonthlySavings;
}
export declare const IdleSavingsOpportunity: S.Schema<IdleSavingsOpportunity>;
export interface IdleSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number;
    estimatedMonthlySavings?: IdleEstimatedMonthlySavings;
}
export declare const IdleSavingsOpportunityAfterDiscounts: S.Schema<IdleSavingsOpportunityAfterDiscounts>;
export type IdleMetricName = "CPU" | "Memory" | "NetworkOutBytesPerSecond" | "NetworkInBytesPerSecond" | "DatabaseConnections" | "EBSVolumeReadIOPS" | "EBSVolumeWriteIOPS" | "VolumeReadOpsPerSecond" | "VolumeWriteOpsPerSecond" | "ActiveConnectionCount" | "PacketsInFromSource" | "PacketsInFromDestination" | "ConsumedReadCapacityUnits" | "ConsumedWriteCapacityUnits" | "ConsumedChangeDataCaptureUnits" | "NewConnections" | "EngineCPUUtilization" | "CacheHits" | "CacheMisses" | "KeyspaceHits" | "KeyspaceMisses" | "IsIdle" | "UserConnected" | "Invocations" | "GetTypeCmds" | "SetTypeCmds" | "ElastiCacheProcessingUnits" | "CurrConnections" | (string & {});
export declare const IdleMetricName: any;
export type IdleDimensionKey = string;
export type IdleDimensionValue = string;
export type IdleDimensionValues = string[];
export declare const IdleDimensionValues: any;
export interface IdleDimension {
    key?: string;
    values?: string[];
}
export declare const IdleDimension: S.Schema<IdleDimension>;
export type IdleDimensions = IdleDimension[];
export declare const IdleDimensions: any;
export interface IdleUtilizationMetric {
    name?: IdleMetricName;
    statistic?: MetricStatistic;
    value?: number;
    dimensions?: IdleDimension[];
}
export declare const IdleUtilizationMetric: S.Schema<IdleUtilizationMetric>;
export type IdleUtilizationMetrics = IdleUtilizationMetric[];
export declare const IdleUtilizationMetrics: any;
export interface IdleRecommendation {
    resourceArn?: string;
    resourceId?: string;
    resourceType?: IdleRecommendationResourceType;
    accountId?: string;
    finding?: IdleFinding;
    findingDescription?: string;
    savingsOpportunity?: IdleSavingsOpportunity;
    savingsOpportunityAfterDiscounts?: IdleSavingsOpportunityAfterDiscounts;
    utilizationMetrics?: IdleUtilizationMetric[];
    lookBackPeriodInDays?: number;
    lastRefreshTimestamp?: Date;
    tags?: Tag[];
}
export declare const IdleRecommendation: S.Schema<IdleRecommendation>;
export type IdleRecommendations = IdleRecommendation[];
export declare const IdleRecommendations: any;
export interface IdleRecommendationError {
    identifier?: string;
    code?: string;
    message?: string;
    resourceType?: IdleRecommendationResourceType;
}
export declare const IdleRecommendationError: S.Schema<IdleRecommendationError>;
export type IdleRecommendationErrors = IdleRecommendationError[];
export declare const IdleRecommendationErrors: any;
export interface GetIdleRecommendationsResponse {
    nextToken?: string;
    idleRecommendations?: IdleRecommendation[];
    errors?: IdleRecommendationError[];
}
export declare const GetIdleRecommendationsResponse: S.Schema<GetIdleRecommendationsResponse>;
export type FunctionArn = string;
export type FunctionArns = string[];
export declare const FunctionArns: any;
export interface GetLambdaFunctionRecommendationsRequest {
    functionArns?: string[];
    accountIds?: string[];
    filters?: LambdaFunctionRecommendationFilter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const GetLambdaFunctionRecommendationsRequest: S.Schema<GetLambdaFunctionRecommendationsRequest>;
export type FunctionVersion = string;
export type NumberOfInvocations = number;
export type LambdaFunctionMetricName = "Duration" | "Memory" | (string & {});
export declare const LambdaFunctionMetricName: any;
export type LambdaFunctionMetricStatistic = "Maximum" | "Average" | (string & {});
export declare const LambdaFunctionMetricStatistic: any;
export interface LambdaFunctionUtilizationMetric {
    name?: LambdaFunctionMetricName;
    statistic?: LambdaFunctionMetricStatistic;
    value?: number;
}
export declare const LambdaFunctionUtilizationMetric: S.Schema<LambdaFunctionUtilizationMetric>;
export type LambdaFunctionUtilizationMetrics = LambdaFunctionUtilizationMetric[];
export declare const LambdaFunctionUtilizationMetrics: any;
export type LambdaFunctionRecommendationFinding = "Optimized" | "NotOptimized" | "Unavailable" | (string & {});
export declare const LambdaFunctionRecommendationFinding: any;
export type LambdaFunctionRecommendationFindingReasonCode = "MemoryOverprovisioned" | "MemoryUnderprovisioned" | "InsufficientData" | "Inconclusive" | (string & {});
export declare const LambdaFunctionRecommendationFindingReasonCode: any;
export type LambdaFunctionRecommendationFindingReasonCodes = LambdaFunctionRecommendationFindingReasonCode[];
export declare const LambdaFunctionRecommendationFindingReasonCodes: any;
export type LambdaFunctionMemoryMetricName = "Duration" | (string & {});
export declare const LambdaFunctionMemoryMetricName: any;
export type LambdaFunctionMemoryMetricStatistic = "LowerBound" | "UpperBound" | "Expected" | (string & {});
export declare const LambdaFunctionMemoryMetricStatistic: any;
export interface LambdaFunctionMemoryProjectedMetric {
    name?: LambdaFunctionMemoryMetricName;
    statistic?: LambdaFunctionMemoryMetricStatistic;
    value?: number;
}
export declare const LambdaFunctionMemoryProjectedMetric: S.Schema<LambdaFunctionMemoryProjectedMetric>;
export type LambdaFunctionMemoryProjectedMetrics = LambdaFunctionMemoryProjectedMetric[];
export declare const LambdaFunctionMemoryProjectedMetrics: any;
export interface LambdaEstimatedMonthlySavings {
    currency?: Currency;
    value?: number;
}
export declare const LambdaEstimatedMonthlySavings: S.Schema<LambdaEstimatedMonthlySavings>;
export interface LambdaSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number;
    estimatedMonthlySavings?: LambdaEstimatedMonthlySavings;
}
export declare const LambdaSavingsOpportunityAfterDiscounts: S.Schema<LambdaSavingsOpportunityAfterDiscounts>;
export interface LambdaFunctionMemoryRecommendationOption {
    rank?: number;
    memorySize?: number;
    projectedUtilizationMetrics?: LambdaFunctionMemoryProjectedMetric[];
    savingsOpportunity?: SavingsOpportunity;
    savingsOpportunityAfterDiscounts?: LambdaSavingsOpportunityAfterDiscounts;
}
export declare const LambdaFunctionMemoryRecommendationOption: S.Schema<LambdaFunctionMemoryRecommendationOption>;
export type LambdaFunctionMemoryRecommendationOptions = LambdaFunctionMemoryRecommendationOption[];
export declare const LambdaFunctionMemoryRecommendationOptions: any;
export type LambdaSavingsEstimationModeSource = "PublicPricing" | "CostExplorerRightsizing" | "CostOptimizationHub" | (string & {});
export declare const LambdaSavingsEstimationModeSource: any;
export interface LambdaSavingsEstimationMode {
    source?: LambdaSavingsEstimationModeSource;
}
export declare const LambdaSavingsEstimationMode: S.Schema<LambdaSavingsEstimationMode>;
export interface LambdaEffectiveRecommendationPreferences {
    savingsEstimationMode?: LambdaSavingsEstimationMode;
}
export declare const LambdaEffectiveRecommendationPreferences: S.Schema<LambdaEffectiveRecommendationPreferences>;
export interface LambdaFunctionRecommendation {
    functionArn?: string;
    functionVersion?: string;
    accountId?: string;
    currentMemorySize?: number;
    numberOfInvocations?: number;
    utilizationMetrics?: LambdaFunctionUtilizationMetric[];
    lookbackPeriodInDays?: number;
    lastRefreshTimestamp?: Date;
    finding?: LambdaFunctionRecommendationFinding;
    findingReasonCodes?: LambdaFunctionRecommendationFindingReasonCode[];
    memorySizeRecommendationOptions?: LambdaFunctionMemoryRecommendationOption[];
    currentPerformanceRisk?: CurrentPerformanceRisk;
    effectiveRecommendationPreferences?: LambdaEffectiveRecommendationPreferences;
    tags?: Tag[];
}
export declare const LambdaFunctionRecommendation: S.Schema<LambdaFunctionRecommendation>;
export type LambdaFunctionRecommendations = LambdaFunctionRecommendation[];
export declare const LambdaFunctionRecommendations: any;
export interface GetLambdaFunctionRecommendationsResponse {
    nextToken?: string;
    lambdaFunctionRecommendations?: LambdaFunctionRecommendation[];
}
export declare const GetLambdaFunctionRecommendationsResponse: S.Schema<GetLambdaFunctionRecommendationsResponse>;
export interface GetLicenseRecommendationsRequest {
    resourceArns?: string[];
    nextToken?: string;
    maxResults?: number;
    filters?: LicenseRecommendationFilter[];
    accountIds?: string[];
}
export declare const GetLicenseRecommendationsRequest: S.Schema<GetLicenseRecommendationsRequest>;
export type NumberOfCores = number;
export type OperatingSystem = string;
export type LicenseEdition = "Enterprise" | "Standard" | "Free" | "NoLicenseEditionFound" | (string & {});
export declare const LicenseEdition: any;
export type LicenseName = "SQLServer" | (string & {});
export declare const LicenseName: any;
export type LicenseModel = "LicenseIncluded" | "BringYourOwnLicense" | (string & {});
export declare const LicenseModel: any;
export type LicenseVersion = string;
export type MetricSourceProvider = "CloudWatchApplicationInsights" | (string & {});
export declare const MetricSourceProvider: any;
export type MetricProviderArn = string;
export interface MetricSource {
    provider?: MetricSourceProvider;
    providerArn?: string;
}
export declare const MetricSource: S.Schema<MetricSource>;
export type MetricsSource = MetricSource[];
export declare const MetricsSource: any;
export interface LicenseConfiguration {
    numberOfCores?: number;
    instanceType?: string;
    operatingSystem?: string;
    licenseEdition?: LicenseEdition;
    licenseName?: LicenseName;
    licenseModel?: LicenseModel;
    licenseVersion?: string;
    metricsSource?: MetricSource[];
}
export declare const LicenseConfiguration: S.Schema<LicenseConfiguration>;
export type LicenseFinding = "InsufficientMetrics" | "Optimized" | "NotOptimized" | (string & {});
export declare const LicenseFinding: any;
export type LicenseFindingReasonCode = "InvalidCloudWatchApplicationInsightsSetup" | "CloudWatchApplicationInsightsError" | "LicenseOverprovisioned" | "Optimized" | (string & {});
export declare const LicenseFindingReasonCode: any;
export type LicenseFindingReasonCodes = LicenseFindingReasonCode[];
export declare const LicenseFindingReasonCodes: any;
export interface LicenseRecommendationOption {
    rank?: number;
    operatingSystem?: string;
    licenseEdition?: LicenseEdition;
    licenseModel?: LicenseModel;
    savingsOpportunity?: SavingsOpportunity;
}
export declare const LicenseRecommendationOption: S.Schema<LicenseRecommendationOption>;
export type LicenseRecommendationOptions = LicenseRecommendationOption[];
export declare const LicenseRecommendationOptions: any;
export interface LicenseRecommendation {
    resourceArn?: string;
    accountId?: string;
    currentLicenseConfiguration?: LicenseConfiguration;
    lookbackPeriodInDays?: number;
    lastRefreshTimestamp?: Date;
    finding?: LicenseFinding;
    findingReasonCodes?: LicenseFindingReasonCode[];
    licenseRecommendationOptions?: LicenseRecommendationOption[];
    tags?: Tag[];
}
export declare const LicenseRecommendation: S.Schema<LicenseRecommendation>;
export type LicenseRecommendations = LicenseRecommendation[];
export declare const LicenseRecommendations: any;
export interface GetLicenseRecommendationsResponse {
    nextToken?: string;
    licenseRecommendations?: LicenseRecommendation[];
    errors?: GetRecommendationError[];
}
export declare const GetLicenseRecommendationsResponse: S.Schema<GetLicenseRecommendationsResponse>;
export interface GetRDSDatabaseRecommendationProjectedMetricsRequest {
    resourceArn: string;
    stat: MetricStatistic;
    period: number;
    startTime: Date;
    endTime: Date;
    recommendationPreferences?: RecommendationPreferences;
}
export declare const GetRDSDatabaseRecommendationProjectedMetricsRequest: S.Schema<GetRDSDatabaseRecommendationProjectedMetricsRequest>;
export type RecommendedDBInstanceClass = string;
export type RDSDBMetricName = "CPU" | "Memory" | "EBSVolumeStorageSpaceUtilization" | "NetworkReceiveThroughput" | "NetworkTransmitThroughput" | "EBSVolumeReadIOPS" | "EBSVolumeWriteIOPS" | "EBSVolumeReadThroughput" | "EBSVolumeWriteThroughput" | "DatabaseConnections" | "StorageNetworkReceiveThroughput" | "StorageNetworkTransmitThroughput" | "AuroraMemoryHealthState" | "AuroraMemoryNumDeclinedSql" | "AuroraMemoryNumKillConnTotal" | "AuroraMemoryNumKillQueryTotal" | "ReadIOPSEphemeralStorage" | "WriteIOPSEphemeralStorage" | "VolumeReadIOPs" | "VolumeBytesUsed" | "VolumeWriteIOPs" | (string & {});
export declare const RDSDBMetricName: any;
export interface RDSDatabaseProjectedMetric {
    name?: RDSDBMetricName;
    timestamps?: Date[];
    values?: number[];
}
export declare const RDSDatabaseProjectedMetric: S.Schema<RDSDatabaseProjectedMetric>;
export type RDSDatabaseProjectedMetrics = RDSDatabaseProjectedMetric[];
export declare const RDSDatabaseProjectedMetrics: any;
export interface RDSDatabaseRecommendedOptionProjectedMetric {
    recommendedDBInstanceClass?: string;
    rank?: number;
    projectedMetrics?: RDSDatabaseProjectedMetric[];
}
export declare const RDSDatabaseRecommendedOptionProjectedMetric: S.Schema<RDSDatabaseRecommendedOptionProjectedMetric>;
export type RDSDatabaseRecommendedOptionProjectedMetrics = RDSDatabaseRecommendedOptionProjectedMetric[];
export declare const RDSDatabaseRecommendedOptionProjectedMetrics: any;
export interface GetRDSDatabaseRecommendationProjectedMetricsResponse {
    recommendedOptionProjectedMetrics?: RDSDatabaseRecommendedOptionProjectedMetric[];
}
export declare const GetRDSDatabaseRecommendationProjectedMetricsResponse: S.Schema<GetRDSDatabaseRecommendationProjectedMetricsResponse>;
export interface GetRDSDatabaseRecommendationsRequest {
    resourceArns?: string[];
    nextToken?: string;
    maxResults?: number;
    filters?: RDSDBRecommendationFilter[];
    accountIds?: string[];
    recommendationPreferences?: RecommendationPreferences;
}
export declare const GetRDSDatabaseRecommendationsRequest: S.Schema<GetRDSDatabaseRecommendationsRequest>;
export type Engine = string;
export type EngineVersion = string;
export type PromotionTier = number;
export type CurrentDBInstanceClass = string;
export type StorageType = string;
export type AllocatedStorage = number;
export type NullableIOPS = number;
export type NullableMaxAllocatedStorage = number;
export type NullableStorageThroughput = number;
export interface DBStorageConfiguration {
    storageType?: string;
    allocatedStorage?: number;
    iops?: number;
    maxAllocatedStorage?: number;
    storageThroughput?: number;
}
export declare const DBStorageConfiguration: S.Schema<DBStorageConfiguration>;
export type DBClusterIdentifier = string;
export type Idle = "True" | "False" | (string & {});
export declare const Idle: any;
export type RDSInstanceFinding = "Optimized" | "Underprovisioned" | "Overprovisioned" | (string & {});
export declare const RDSInstanceFinding: any;
export type RDSStorageFinding = "Optimized" | "Underprovisioned" | "Overprovisioned" | "NotOptimized" | (string & {});
export declare const RDSStorageFinding: any;
export type RDSInstanceFindingReasonCode = "CPUOverprovisioned" | "NetworkBandwidthOverprovisioned" | "EBSIOPSOverprovisioned" | "EBSIOPSUnderprovisioned" | "EBSThroughputOverprovisioned" | "CPUUnderprovisioned" | "NetworkBandwidthUnderprovisioned" | "EBSThroughputUnderprovisioned" | "NewGenerationDBInstanceClassAvailable" | "NewEngineVersionAvailable" | "DBClusterWriterUnderprovisioned" | "MemoryUnderprovisioned" | "InstanceStorageReadIOPSUnderprovisioned" | "InstanceStorageWriteIOPSUnderprovisioned" | (string & {});
export declare const RDSInstanceFindingReasonCode: any;
export type RDSInstanceFindingReasonCodes = RDSInstanceFindingReasonCode[];
export declare const RDSInstanceFindingReasonCodes: any;
export type RDSCurrentInstancePerformanceRisk = "VeryLow" | "Low" | "Medium" | "High" | (string & {});
export declare const RDSCurrentInstancePerformanceRisk: any;
export type RDSEstimatedMonthlyVolumeIOPsCostVariation = "None" | "Low" | "Medium" | "High" | (string & {});
export declare const RDSEstimatedMonthlyVolumeIOPsCostVariation: any;
export type RDSStorageFindingReasonCode = "EBSVolumeAllocatedStorageUnderprovisioned" | "EBSVolumeThroughputUnderprovisioned" | "EBSVolumeIOPSOverprovisioned" | "EBSVolumeThroughputOverprovisioned" | "NewGenerationStorageTypeAvailable" | "DBClusterStorageOptionAvailable" | "DBClusterStorageSavingsAvailable" | (string & {});
export declare const RDSStorageFindingReasonCode: any;
export type RDSStorageFindingReasonCodes = RDSStorageFindingReasonCode[];
export declare const RDSStorageFindingReasonCodes: any;
export type DBInstanceClass = string;
export type RDSDBMetricStatistic = "Maximum" | "Minimum" | "Average" | (string & {});
export declare const RDSDBMetricStatistic: any;
export interface RDSDBUtilizationMetric {
    name?: RDSDBMetricName;
    statistic?: RDSDBMetricStatistic;
    value?: number;
}
export declare const RDSDBUtilizationMetric: S.Schema<RDSDBUtilizationMetric>;
export type RDSDBProjectedUtilizationMetrics = RDSDBUtilizationMetric[];
export declare const RDSDBProjectedUtilizationMetrics: any;
export interface RDSInstanceEstimatedMonthlySavings {
    currency?: Currency;
    value?: number;
}
export declare const RDSInstanceEstimatedMonthlySavings: S.Schema<RDSInstanceEstimatedMonthlySavings>;
export interface RDSInstanceSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number;
    estimatedMonthlySavings?: RDSInstanceEstimatedMonthlySavings;
}
export declare const RDSInstanceSavingsOpportunityAfterDiscounts: S.Schema<RDSInstanceSavingsOpportunityAfterDiscounts>;
export interface RDSDBInstanceRecommendationOption {
    dbInstanceClass?: string;
    projectedUtilizationMetrics?: RDSDBUtilizationMetric[];
    performanceRisk?: number;
    rank?: number;
    savingsOpportunity?: SavingsOpportunity;
    savingsOpportunityAfterDiscounts?: RDSInstanceSavingsOpportunityAfterDiscounts;
}
export declare const RDSDBInstanceRecommendationOption: S.Schema<RDSDBInstanceRecommendationOption>;
export type RDSDBInstanceRecommendationOptions = RDSDBInstanceRecommendationOption[];
export declare const RDSDBInstanceRecommendationOptions: any;
export interface RDSStorageEstimatedMonthlySavings {
    currency?: Currency;
    value?: number;
}
export declare const RDSStorageEstimatedMonthlySavings: S.Schema<RDSStorageEstimatedMonthlySavings>;
export interface RDSStorageSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number;
    estimatedMonthlySavings?: RDSStorageEstimatedMonthlySavings;
}
export declare const RDSStorageSavingsOpportunityAfterDiscounts: S.Schema<RDSStorageSavingsOpportunityAfterDiscounts>;
export interface RDSDBStorageRecommendationOption {
    storageConfiguration?: DBStorageConfiguration;
    rank?: number;
    savingsOpportunity?: SavingsOpportunity;
    savingsOpportunityAfterDiscounts?: RDSStorageSavingsOpportunityAfterDiscounts;
    estimatedMonthlyVolumeIOPsCostVariation?: RDSEstimatedMonthlyVolumeIOPsCostVariation;
}
export declare const RDSDBStorageRecommendationOption: S.Schema<RDSDBStorageRecommendationOption>;
export type RDSDBStorageRecommendationOptions = RDSDBStorageRecommendationOption[];
export declare const RDSDBStorageRecommendationOptions: any;
export type RDSDBUtilizationMetrics = RDSDBUtilizationMetric[];
export declare const RDSDBUtilizationMetrics: any;
export type RDSSavingsEstimationModeSource = "PublicPricing" | "CostExplorerRightsizing" | "CostOptimizationHub" | (string & {});
export declare const RDSSavingsEstimationModeSource: any;
export interface RDSSavingsEstimationMode {
    source?: RDSSavingsEstimationModeSource;
}
export declare const RDSSavingsEstimationMode: S.Schema<RDSSavingsEstimationMode>;
export interface RDSEffectiveRecommendationPreferences {
    cpuVendorArchitectures?: CpuVendorArchitecture[];
    enhancedInfrastructureMetrics?: EnhancedInfrastructureMetrics;
    lookBackPeriod?: LookBackPeriodPreference;
    savingsEstimationMode?: RDSSavingsEstimationMode;
}
export declare const RDSEffectiveRecommendationPreferences: S.Schema<RDSEffectiveRecommendationPreferences>;
export interface RDSDBRecommendation {
    resourceArn?: string;
    accountId?: string;
    engine?: string;
    engineVersion?: string;
    promotionTier?: number;
    currentDBInstanceClass?: string;
    currentStorageConfiguration?: DBStorageConfiguration;
    dbClusterIdentifier?: string;
    idle?: Idle;
    instanceFinding?: RDSInstanceFinding;
    storageFinding?: RDSStorageFinding;
    instanceFindingReasonCodes?: RDSInstanceFindingReasonCode[];
    currentInstancePerformanceRisk?: RDSCurrentInstancePerformanceRisk;
    currentStorageEstimatedMonthlyVolumeIOPsCostVariation?: RDSEstimatedMonthlyVolumeIOPsCostVariation;
    storageFindingReasonCodes?: RDSStorageFindingReasonCode[];
    instanceRecommendationOptions?: RDSDBInstanceRecommendationOption[];
    storageRecommendationOptions?: RDSDBStorageRecommendationOption[];
    utilizationMetrics?: RDSDBUtilizationMetric[];
    effectiveRecommendationPreferences?: RDSEffectiveRecommendationPreferences;
    lookbackPeriodInDays?: number;
    lastRefreshTimestamp?: Date;
    tags?: Tag[];
}
export declare const RDSDBRecommendation: S.Schema<RDSDBRecommendation>;
export type RDSDBRecommendations = RDSDBRecommendation[];
export declare const RDSDBRecommendations: any;
export interface GetRDSDatabaseRecommendationsResponse {
    nextToken?: string;
    rdsDBRecommendations?: RDSDBRecommendation[];
    errors?: GetRecommendationError[];
}
export declare const GetRDSDatabaseRecommendationsResponse: S.Schema<GetRDSDatabaseRecommendationsResponse>;
export interface GetRecommendationPreferencesRequest {
    resourceType: ResourceType;
    scope?: Scope;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetRecommendationPreferencesRequest: S.Schema<GetRecommendationPreferencesRequest>;
export type SavingsEstimationMode = "AfterDiscounts" | "BeforeDiscounts" | (string & {});
export declare const SavingsEstimationMode: any;
export interface RecommendationPreferencesDetail {
    scope?: Scope;
    resourceType?: ResourceType;
    enhancedInfrastructureMetrics?: EnhancedInfrastructureMetrics;
    inferredWorkloadTypes?: InferredWorkloadTypesPreference;
    externalMetricsPreference?: ExternalMetricsPreference;
    lookBackPeriod?: LookBackPeriodPreference;
    utilizationPreferences?: UtilizationPreference[];
    preferredResources?: EffectivePreferredResource[];
    savingsEstimationMode?: SavingsEstimationMode;
}
export declare const RecommendationPreferencesDetail: S.Schema<RecommendationPreferencesDetail>;
export type RecommendationPreferencesDetails = RecommendationPreferencesDetail[];
export declare const RecommendationPreferencesDetails: any;
export interface GetRecommendationPreferencesResponse {
    nextToken?: string;
    recommendationPreferencesDetails?: RecommendationPreferencesDetail[];
}
export declare const GetRecommendationPreferencesResponse: S.Schema<GetRecommendationPreferencesResponse>;
export interface GetRecommendationSummariesRequest {
    accountIds?: string[];
    nextToken?: string;
    maxResults?: number;
}
export declare const GetRecommendationSummariesRequest: S.Schema<GetRecommendationSummariesRequest>;
export type SummaryValue = number;
export type FindingReasonCode = "MemoryOverprovisioned" | "MemoryUnderprovisioned" | (string & {});
export declare const FindingReasonCode: any;
export interface ReasonCodeSummary {
    name?: FindingReasonCode;
    value?: number;
}
export declare const ReasonCodeSummary: S.Schema<ReasonCodeSummary>;
export type ReasonCodeSummaries = ReasonCodeSummary[];
export declare const ReasonCodeSummaries: any;
export interface Summary {
    name?: Finding;
    value?: number;
    reasonCodeSummaries?: ReasonCodeSummary[];
}
export declare const Summary: S.Schema<Summary>;
export type Summaries = Summary[];
export declare const Summaries: any;
export interface IdleSummary {
    name?: IdleFinding;
    value?: number;
}
export declare const IdleSummary: S.Schema<IdleSummary>;
export type IdleSummaries = IdleSummary[];
export declare const IdleSummaries: any;
export type High = number;
export type Medium = number;
export type Low = number;
export type VeryLow = number;
export interface CurrentPerformanceRiskRatings {
    high?: number;
    medium?: number;
    low?: number;
    veryLow?: number;
}
export declare const CurrentPerformanceRiskRatings: S.Schema<CurrentPerformanceRiskRatings>;
export interface InferredWorkloadSaving {
    inferredWorkloadTypes?: InferredWorkloadType[];
    estimatedMonthlySavings?: EstimatedMonthlySavings;
}
export declare const InferredWorkloadSaving: S.Schema<InferredWorkloadSaving>;
export type InferredWorkloadSavings = InferredWorkloadSaving[];
export declare const InferredWorkloadSavings: any;
export interface RecommendationSummary {
    summaries?: Summary[];
    idleSummaries?: IdleSummary[];
    recommendationResourceType?: RecommendationSourceType;
    accountId?: string;
    savingsOpportunity?: SavingsOpportunity;
    idleSavingsOpportunity?: SavingsOpportunity;
    aggregatedSavingsOpportunity?: SavingsOpportunity;
    currentPerformanceRiskRatings?: CurrentPerformanceRiskRatings;
    inferredWorkloadSavings?: InferredWorkloadSaving[];
}
export declare const RecommendationSummary: S.Schema<RecommendationSummary>;
export type RecommendationSummaries = RecommendationSummary[];
export declare const RecommendationSummaries: any;
export interface GetRecommendationSummariesResponse {
    nextToken?: string;
    recommendationSummaries?: RecommendationSummary[];
}
export declare const GetRecommendationSummariesResponse: S.Schema<GetRecommendationSummariesResponse>;
export interface PreferredResource {
    name?: PreferredResourceName;
    includeList?: string[];
    excludeList?: string[];
}
export declare const PreferredResource: S.Schema<PreferredResource>;
export type PreferredResources = PreferredResource[];
export declare const PreferredResources: any;
export interface PutRecommendationPreferencesRequest {
    resourceType: ResourceType;
    scope?: Scope;
    enhancedInfrastructureMetrics?: EnhancedInfrastructureMetrics;
    inferredWorkloadTypes?: InferredWorkloadTypesPreference;
    externalMetricsPreference?: ExternalMetricsPreference;
    lookBackPeriod?: LookBackPeriodPreference;
    utilizationPreferences?: UtilizationPreference[];
    preferredResources?: PreferredResource[];
    savingsEstimationMode?: SavingsEstimationMode;
}
export declare const PutRecommendationPreferencesRequest: S.Schema<PutRecommendationPreferencesRequest>;
export interface PutRecommendationPreferencesResponse {
}
export declare const PutRecommendationPreferencesResponse: S.Schema<PutRecommendationPreferencesResponse>;
export interface UpdateEnrollmentStatusRequest {
    status: Status;
    includeMemberAccounts?: boolean;
}
export declare const UpdateEnrollmentStatusRequest: S.Schema<UpdateEnrollmentStatusRequest>;
export interface UpdateEnrollmentStatusResponse {
    status?: Status;
    statusReason?: string;
}
export declare const UpdateEnrollmentStatusResponse: S.Schema<UpdateEnrollmentStatusResponse>;
export type ErrorMessage = string;
export type DeleteRecommendationPreferencesError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes a recommendation preference, such as enhanced infrastructure metrics.
 *
 * For more information, see Activating
 * enhanced infrastructure metrics in the Compute Optimizer User
 * Guide.
 */
export declare const deleteRecommendationPreferences: API.OperationMethod<DeleteRecommendationPreferencesRequest, DeleteRecommendationPreferencesResponse, DeleteRecommendationPreferencesError, Credentials | HttpClient.HttpClient>;
export type DescribeRecommendationExportJobsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Describes recommendation export jobs created in the last seven days.
 *
 * Use the ExportAutoScalingGroupRecommendations or ExportEC2InstanceRecommendations actions to request an export of your
 * recommendations. Then use the DescribeRecommendationExportJobs action
 * to view your export jobs.
 */
export declare const describeRecommendationExportJobs: API.PaginatedOperationMethod<DescribeRecommendationExportJobsRequest, DescribeRecommendationExportJobsResponse, DescribeRecommendationExportJobsError, Credentials | HttpClient.HttpClient, RecommendationExportJob>;
export type ExportAutoScalingGroupRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Exports optimization recommendations for Auto Scaling groups.
 *
 * Recommendations are exported in a comma-separated values (.csv) file, and its metadata
 * in a JavaScript Object Notation (JSON) (.json) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one Auto Scaling group export job in progress per Amazon Web Services Region.
 */
export declare const exportAutoScalingGroupRecommendations: API.OperationMethod<ExportAutoScalingGroupRecommendationsRequest, ExportAutoScalingGroupRecommendationsResponse, ExportAutoScalingGroupRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportEBSVolumeRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Exports optimization recommendations for Amazon EBS volumes.
 *
 * Recommendations are exported in a comma-separated values (.csv) file, and its metadata
 * in a JavaScript Object Notation (JSON) (.json) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one Amazon EBS volume export job in progress per Amazon Web Services Region.
 */
export declare const exportEBSVolumeRecommendations: API.OperationMethod<ExportEBSVolumeRecommendationsRequest, ExportEBSVolumeRecommendationsResponse, ExportEBSVolumeRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportEC2InstanceRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Exports optimization recommendations for Amazon EC2 instances.
 *
 * Recommendations are exported in a comma-separated values (.csv) file, and its metadata
 * in a JavaScript Object Notation (JSON) (.json) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one Amazon EC2 instance export job in progress per Amazon Web Services Region.
 */
export declare const exportEC2InstanceRecommendations: API.OperationMethod<ExportEC2InstanceRecommendationsRequest, ExportEC2InstanceRecommendationsResponse, ExportEC2InstanceRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportECSServiceRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Exports optimization recommendations for Amazon ECS services on Fargate.
 *
 * Recommendations are exported in a CSV file, and its metadata
 * in a JSON file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can only have one Amazon ECS service export job in progress per Amazon Web Services Region.
 */
export declare const exportECSServiceRecommendations: API.OperationMethod<ExportECSServiceRecommendationsRequest, ExportECSServiceRecommendationsResponse, ExportECSServiceRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportIdleRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Export optimization recommendations for your idle resources.
 *
 * Recommendations are exported in a comma-separated values (CSV) file, and its metadata
 * in a JavaScript Object Notation (JSON) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one idle resource export job in progress per Amazon Web Services Region.
 */
export declare const exportIdleRecommendations: API.OperationMethod<ExportIdleRecommendationsRequest, ExportIdleRecommendationsResponse, ExportIdleRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportLambdaFunctionRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Exports optimization recommendations for Lambda functions.
 *
 * Recommendations are exported in a comma-separated values (.csv) file, and its metadata
 * in a JavaScript Object Notation (JSON) (.json) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one Lambda function export job in progress per Amazon Web Services Region.
 */
export declare const exportLambdaFunctionRecommendations: API.OperationMethod<ExportLambdaFunctionRecommendationsRequest, ExportLambdaFunctionRecommendationsResponse, ExportLambdaFunctionRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportLicenseRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Export optimization recommendations for your licenses.
 *
 * Recommendations are exported in a comma-separated values (CSV) file, and its metadata
 * in a JavaScript Object Notation (JSON) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one license export job in progress per Amazon Web Services Region.
 */
export declare const exportLicenseRecommendations: API.OperationMethod<ExportLicenseRecommendationsRequest, ExportLicenseRecommendationsResponse, ExportLicenseRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportRDSDatabaseRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Export optimization recommendations for your Amazon Aurora and Amazon Relational Database Service (Amazon RDS) databases.
 *
 * Recommendations are exported in a comma-separated values (CSV) file, and its metadata
 * in a JavaScript Object Notation (JSON) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one Amazon Aurora or RDS export job in progress per Amazon Web Services Region.
 */
export declare const exportRDSDatabaseRecommendations: API.OperationMethod<ExportRDSDatabaseRecommendationsRequest, ExportRDSDatabaseRecommendationsResponse, ExportRDSDatabaseRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetAutoScalingGroupRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns Auto Scaling group recommendations.
 *
 * Compute Optimizer generates recommendations for Amazon EC2 Auto Scaling groups that
 * meet a specific set of requirements. For more information, see the Supported
 * resources and requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getAutoScalingGroupRecommendations: API.OperationMethod<GetAutoScalingGroupRecommendationsRequest, GetAutoScalingGroupRecommendationsResponse, GetAutoScalingGroupRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetEBSVolumeRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns Amazon Elastic Block Store (Amazon EBS) volume recommendations.
 *
 * Compute Optimizer generates recommendations for Amazon EBS volumes that
 * meet a specific set of requirements. For more information, see the Supported
 * resources and requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getEBSVolumeRecommendations: API.OperationMethod<GetEBSVolumeRecommendationsRequest, GetEBSVolumeRecommendationsResponse, GetEBSVolumeRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetEC2InstanceRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns Amazon EC2 instance recommendations.
 *
 * Compute Optimizer generates recommendations for Amazon Elastic Compute Cloud (Amazon EC2) instances that meet a specific set of requirements. For more
 * information, see the Supported resources and
 * requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getEC2InstanceRecommendations: API.OperationMethod<GetEC2InstanceRecommendationsRequest, GetEC2InstanceRecommendationsResponse, GetEC2InstanceRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetEC2RecommendationProjectedMetricsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the projected utilization metrics of Amazon EC2 instance
 * recommendations.
 *
 * The `Cpu` and `Memory` metrics are the only projected
 * utilization metrics returned when you run this action. Additionally, the
 * `Memory` metric is returned only for resources that have the unified
 * CloudWatch agent installed on them. For more information, see Enabling Memory Utilization with the CloudWatch Agent.
 */
export declare const getEC2RecommendationProjectedMetrics: API.OperationMethod<GetEC2RecommendationProjectedMetricsRequest, GetEC2RecommendationProjectedMetricsResponse, GetEC2RecommendationProjectedMetricsError, Credentials | HttpClient.HttpClient>;
export type GetECSServiceRecommendationProjectedMetricsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the projected metrics of Amazon ECS service recommendations.
 */
export declare const getECSServiceRecommendationProjectedMetrics: API.OperationMethod<GetECSServiceRecommendationProjectedMetricsRequest, GetECSServiceRecommendationProjectedMetricsResponse, GetECSServiceRecommendationProjectedMetricsError, Credentials | HttpClient.HttpClient>;
export type GetECSServiceRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns Amazon ECS service recommendations.
 *
 * Compute Optimizer generates recommendations for Amazon ECS services on
 * Fargate that meet a specific set of requirements. For more
 * information, see the Supported resources and
 * requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getECSServiceRecommendations: API.OperationMethod<GetECSServiceRecommendationsRequest, GetECSServiceRecommendationsResponse, GetECSServiceRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetEffectiveRecommendationPreferencesError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the recommendation preferences that are in effect for a given resource, such
 * as enhanced infrastructure metrics. Considers all applicable preferences that you might
 * have set at the resource, account, and organization level.
 *
 * When you create a recommendation preference, you can set its status to
 * `Active` or `Inactive`. Use this action to view the
 * recommendation preferences that are in effect, or `Active`.
 */
export declare const getEffectiveRecommendationPreferences: API.OperationMethod<GetEffectiveRecommendationPreferencesRequest, GetEffectiveRecommendationPreferencesResponse, GetEffectiveRecommendationPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetEnrollmentStatusError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the enrollment (opt in) status of an account to the Compute Optimizer
 * service.
 *
 * If the account is the management account of an organization, this action also confirms
 * the enrollment status of member accounts of the organization. Use the GetEnrollmentStatusesForOrganization action to get detailed information
 * about the enrollment status of member accounts of an organization.
 */
export declare const getEnrollmentStatus: API.OperationMethod<GetEnrollmentStatusRequest, GetEnrollmentStatusResponse, GetEnrollmentStatusError, Credentials | HttpClient.HttpClient>;
export type GetEnrollmentStatusesForOrganizationError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the Compute Optimizer enrollment (opt-in) status of organization member
 * accounts, if your account is an organization management account.
 *
 * To get the enrollment status of standalone accounts, use the GetEnrollmentStatus action.
 */
export declare const getEnrollmentStatusesForOrganization: API.PaginatedOperationMethod<GetEnrollmentStatusesForOrganizationRequest, GetEnrollmentStatusesForOrganizationResponse, GetEnrollmentStatusesForOrganizationError, Credentials | HttpClient.HttpClient, AccountEnrollmentStatus>;
export type GetIdleRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns idle resource recommendations. Compute Optimizer generates recommendations for
 * idle resources that meet a specific set of requirements. For more information, see
 * Resource requirements in the
 * *Compute Optimizer User Guide*
 */
export declare const getIdleRecommendations: API.OperationMethod<GetIdleRecommendationsRequest, GetIdleRecommendationsResponse, GetIdleRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetLambdaFunctionRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns Lambda function recommendations.
 *
 * Compute Optimizer generates recommendations for functions that meet a specific set
 * of requirements. For more information, see the Supported resources and
 * requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getLambdaFunctionRecommendations: API.PaginatedOperationMethod<GetLambdaFunctionRecommendationsRequest, GetLambdaFunctionRecommendationsResponse, GetLambdaFunctionRecommendationsError, Credentials | HttpClient.HttpClient, LambdaFunctionRecommendation>;
export type GetLicenseRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns license recommendations for Amazon EC2 instances that run on a specific license.
 *
 * Compute Optimizer generates recommendations for licenses that meet a specific set of requirements. For more
 * information, see the Supported resources and
 * requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getLicenseRecommendations: API.OperationMethod<GetLicenseRecommendationsRequest, GetLicenseRecommendationsResponse, GetLicenseRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetRDSDatabaseRecommendationProjectedMetricsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the projected metrics of Aurora and RDS database recommendations.
 */
export declare const getRDSDatabaseRecommendationProjectedMetrics: API.OperationMethod<GetRDSDatabaseRecommendationProjectedMetricsRequest, GetRDSDatabaseRecommendationProjectedMetricsResponse, GetRDSDatabaseRecommendationProjectedMetricsError, Credentials | HttpClient.HttpClient>;
export type GetRDSDatabaseRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns Amazon Aurora and RDS database recommendations.
 *
 * Compute Optimizer generates recommendations for Amazon Aurora and RDS databases that
 * meet a specific set of requirements. For more
 * information, see the Supported resources and
 * requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getRDSDatabaseRecommendations: API.OperationMethod<GetRDSDatabaseRecommendationsRequest, GetRDSDatabaseRecommendationsResponse, GetRDSDatabaseRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationPreferencesError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns existing recommendation preferences, such as enhanced infrastructure
 * metrics.
 *
 * Use the `scope` parameter to specify which preferences to return. You can
 * specify to return preferences for an organization, a specific account ID, or a specific
 * EC2 instance or Auto Scaling group Amazon Resource Name (ARN).
 *
 * For more information, see Activating
 * enhanced infrastructure metrics in the Compute Optimizer User
 * Guide.
 */
export declare const getRecommendationPreferences: API.PaginatedOperationMethod<GetRecommendationPreferencesRequest, GetRecommendationPreferencesResponse, GetRecommendationPreferencesError, Credentials | HttpClient.HttpClient, RecommendationPreferencesDetail>;
export type GetRecommendationSummariesError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the optimization findings for an account.
 *
 * It returns the number of:
 *
 * - Amazon EC2 instances in an account that are
 * `Underprovisioned`, `Overprovisioned`, or
 * `Optimized`.
 *
 * - EC2Auto Scaling groups in an account that are `NotOptimized`, or
 * `Optimized`.
 *
 * - Amazon EBS volumes in an account that are `NotOptimized`,
 * or `Optimized`.
 *
 * - Lambda functions in an account that are `NotOptimized`,
 * or `Optimized`.
 *
 * - Amazon ECS services in an account that are `Underprovisioned`,
 * `Overprovisioned`, or `Optimized`.
 *
 * - Commercial software licenses in an account that are `InsufficientMetrics`,
 * `NotOptimized` or `Optimized`.
 *
 * - Amazon Aurora and Amazon RDS databases in an account that are `Underprovisioned`,
 * `Overprovisioned`, `Optimized`, or `NotOptimized`.
 */
export declare const getRecommendationSummaries: API.PaginatedOperationMethod<GetRecommendationSummariesRequest, GetRecommendationSummariesResponse, GetRecommendationSummariesError, Credentials | HttpClient.HttpClient, RecommendationSummary>;
export type PutRecommendationPreferencesError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates a new recommendation preference or updates an existing recommendation
 * preference, such as enhanced infrastructure metrics.
 *
 * For more information, see Activating
 * enhanced infrastructure metrics in the Compute Optimizer User
 * Guide.
 */
export declare const putRecommendationPreferences: API.OperationMethod<PutRecommendationPreferencesRequest, PutRecommendationPreferencesResponse, PutRecommendationPreferencesError, Credentials | HttpClient.HttpClient>;
export type UpdateEnrollmentStatusError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates the enrollment (opt in and opt out) status of an account to the Compute Optimizer service.
 *
 * If the account is a management account of an organization, this action can also be
 * used to enroll member accounts of the organization.
 *
 * You must have the appropriate permissions to opt in to Compute Optimizer, to view its
 * recommendations, and to opt out. For more information, see Controlling access with Amazon Web Services Identity and Access Management in the *Compute Optimizer User Guide*.
 *
 * When you opt in, Compute Optimizer automatically creates a service-linked role in your
 * account to access its data. For more information, see Using
 * Service-Linked Roles for Compute Optimizer in the *Compute Optimizer User Guide*.
 */
export declare const updateEnrollmentStatus: API.OperationMethod<UpdateEnrollmentStatusRequest, UpdateEnrollmentStatusResponse, UpdateEnrollmentStatusError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=compute-optimizer.d.ts.map