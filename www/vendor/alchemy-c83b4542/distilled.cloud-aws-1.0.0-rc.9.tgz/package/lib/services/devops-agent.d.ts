import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as stream from "effect/Stream";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ContentSizeExceededException_base: S.Class<ContentSizeExceededException, S.TaggedStruct<"ContentSizeExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ContentSizeExceededException extends /*@__PURE__*/ ContentSizeExceededException_base {
}
declare const IdentityCenterServiceException_base: S.Class<IdentityCenterServiceException, S.TaggedStruct<"IdentityCenterServiceException", {
    readonly message: any;
    readonly underlyingErrorCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IdentityCenterServiceException extends /*@__PURE__*/ IdentityCenterServiceException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AgentSpaceId = string;
export type ServiceId = string;
export type SourceAccountType = "source" | (string & {});
export declare const SourceAccountType: any;
export type RoleArn = string;
export type ValidationStatus = "valid" | "invalid" | "pending-confirmation" | (string & {});
export declare const ValidationStatus: any;
export interface SourceAwsConfiguration {
    accountId: string;
    accountType: SourceAccountType;
    assumableRoleArn: string;
    externalId?: string;
    agentElevatedRoleArn?: string;
    agentElevatedRoleArnStatus?: ValidationStatus;
}
export declare const SourceAwsConfiguration: S.Schema<SourceAwsConfiguration>;
export type MonitorAccountType = "monitor" | (string & {});
export declare const MonitorAccountType: any;
export interface AWSConfiguration {
    assumableRoleArn: string;
    accountId: string;
    accountType: MonitorAccountType;
    agentElevatedRoleArn?: string;
    agentElevatedRoleArnStatus?: ValidationStatus;
}
export declare const AWSConfiguration: S.Schema<AWSConfiguration>;
export type GithubRepoOwnerType = "organization" | "user" | (string & {});
export declare const GithubRepoOwnerType: any;
export interface GitHubConfiguration {
    repoName: string;
    repoId: string;
    owner: string;
    ownerType: GithubRepoOwnerType;
    instanceIdentifier?: string;
    runtimeRoleArn?: string;
}
export declare const GitHubConfiguration: S.Schema<GitHubConfiguration>;
export interface SlackChannel {
    channelName?: string;
    channelId: string;
}
export declare const SlackChannel: S.Schema<SlackChannel>;
export interface SlackTransmissionTarget {
    opsOncallTarget: SlackChannel;
    opsSRETarget?: SlackChannel;
}
export declare const SlackTransmissionTarget: S.Schema<SlackTransmissionTarget>;
export interface SlackConfiguration {
    workspaceId: string;
    workspaceName: string;
    transmissionTarget: SlackTransmissionTarget;
}
export declare const SlackConfiguration: S.Schema<SlackConfiguration>;
export type DynatraceResourceList = string[];
export declare const DynatraceResourceList: any;
export interface DynatraceConfiguration {
    envId: string;
    resources?: string[];
}
export declare const DynatraceConfiguration: S.Schema<DynatraceConfiguration>;
export type ServiceNowAuthenticationScopeList = string[];
export declare const ServiceNowAuthenticationScopeList: any;
export interface ServiceNowConfiguration {
    instanceId?: string;
    authScopes?: string[];
}
export declare const ServiceNowConfiguration: S.Schema<ServiceNowConfiguration>;
export interface MCPServerNewRelicConfiguration {
    accountId: string;
    endpoint: string;
}
export declare const MCPServerNewRelicConfiguration: S.Schema<MCPServerNewRelicConfiguration>;
export type ToolClassification = "READ_ONLY" | "MUTATIVE" | "DESTRUCTIVE" | (string & {});
export declare const ToolClassification: any;
export interface MCPToolDetail {
    name: string;
    toolClassification?: ToolClassification;
}
export declare const MCPToolDetail: S.Schema<MCPToolDetail>;
export type MCPToolDetailsList = MCPToolDetail[];
export declare const MCPToolDetailsList: any;
export interface MCPServerDatadogConfiguration {
    enabledElevatedTools?: MCPToolDetail[];
}
export declare const MCPServerDatadogConfiguration: S.Schema<MCPServerDatadogConfiguration>;
export type MCPToolsList = string[];
export declare const MCPToolsList: any;
export interface MCPServerConfiguration {
    tools: string[];
    toolDetails?: MCPToolDetail[];
}
export declare const MCPServerConfiguration: S.Schema<MCPServerConfiguration>;
export interface GitLabConfiguration {
    projectId: string;
    projectPath: string;
    instanceIdentifier?: string;
    runtimeRoleArn?: string;
}
export declare const GitLabConfiguration: S.Schema<GitLabConfiguration>;
export interface MCPServerSplunkConfiguration {
}
export declare const MCPServerSplunkConfiguration: S.Schema<MCPServerSplunkConfiguration>;
export interface EventChannelConfiguration {
}
export declare const EventChannelConfiguration: S.Schema<EventChannelConfiguration>;
export interface AzureConfiguration {
    subscriptionId: string;
}
export declare const AzureConfiguration: S.Schema<AzureConfiguration>;
export interface AzureDevOpsConfiguration {
    organizationName: string;
    projectId: string;
    projectName: string;
}
export declare const AzureDevOpsConfiguration: S.Schema<AzureDevOpsConfiguration>;
export interface MCPServerGrafanaConfiguration {
    endpoint: string;
    organizationId?: string;
    tools?: string[];
    enabledElevatedTools?: MCPToolDetail[];
}
export declare const MCPServerGrafanaConfiguration: S.Schema<MCPServerGrafanaConfiguration>;
export type PagerDutyServicesList = string[];
export declare const PagerDutyServicesList: any;
export type EmailAddress = string | redacted.Redacted<string>;
export interface PagerDutyConfiguration {
    services: string[];
    customerEmail: string | redacted.Redacted<string>;
}
export declare const PagerDutyConfiguration: S.Schema<PagerDutyConfiguration>;
export interface MCPServerSigV4Configuration {
    tools: string[];
    toolDetails?: MCPToolDetail[];
}
export declare const MCPServerSigV4Configuration: S.Schema<MCPServerSigV4Configuration>;
export interface RemoteAgentConfiguration {
}
export declare const RemoteAgentConfiguration: S.Schema<RemoteAgentConfiguration>;
export interface RemoteAgentSigV4Configuration {
}
export declare const RemoteAgentSigV4Configuration: S.Schema<RemoteAgentSigV4Configuration>;
export type ServiceConfiguration = {
    sourceAws: SourceAwsConfiguration;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws: AWSConfiguration;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github: GitHubConfiguration;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack: SlackConfiguration;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace: DynatraceConfiguration;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow: ServiceNowConfiguration;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic: MCPServerNewRelicConfiguration;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog: MCPServerDatadogConfiguration;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver: MCPServerConfiguration;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab: GitLabConfiguration;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk: MCPServerSplunkConfiguration;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel: EventChannelConfiguration;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure: AzureConfiguration;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops: AzureDevOpsConfiguration;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana: MCPServerGrafanaConfiguration;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty: PagerDutyConfiguration;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4: MCPServerSigV4Configuration;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent: RemoteAgentConfiguration;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4: RemoteAgentSigV4Configuration;
};
export declare const ServiceConfiguration: any;
export type CapabilityType = "RELEASE_READINESS_REVIEW" | "RELEASE_READINESS_REVIEW_AUTOMATED_TESTING" | (string & {});
export declare const CapabilityType: any;
export type TriggerEvent = "PULL_REQUEST_READY_FOR_REVIEW" | "PULL_REQUEST_DRAFT" | (string & {});
export declare const TriggerEvent: any;
export type TriggerEventList = TriggerEvent[];
export declare const TriggerEventList: any;
export type TriggerRegexPattern = string;
export type TriggerRegexPatternList = string[];
export declare const TriggerRegexPatternList: any;
export interface PatternFilter {
    patterns: string[];
}
export declare const PatternFilter: S.Schema<PatternFilter>;
export interface TriggerFilterGroup {
    events?: TriggerEvent[];
    targetBranches?: PatternFilter;
}
export declare const TriggerFilterGroup: S.Schema<TriggerFilterGroup>;
export type TriggerFilterGroups = TriggerFilterGroup[];
export declare const TriggerFilterGroups: any;
export interface CapabilityConfiguration {
    enabled?: boolean;
    triggerFilterGroups?: TriggerFilterGroup[];
}
export declare const CapabilityConfiguration: S.Schema<CapabilityConfiguration>;
export type AssociationCapabilities = {
    [key in CapabilityType]?: CapabilityConfiguration;
};
export declare const AssociationCapabilities: any;
export interface AssociateServiceInput {
    agentSpaceId: string;
    serviceId: string;
    configuration: ServiceConfiguration;
    capabilities?: {
        [key: string]: CapabilityConfiguration | undefined;
    };
}
export declare const AssociateServiceInput: S.Schema<AssociateServiceInput>;
export type AssociationId = string;
export interface Association {
    agentSpaceId: string;
    createdAt: Date;
    updatedAt: Date;
    status?: ValidationStatus;
    associationId: string;
    serviceId: string;
    configuration: ServiceConfiguration;
    capabilities?: {
        [key: string]: CapabilityConfiguration | undefined;
    };
}
export declare const Association: S.Schema<Association>;
export type WebhookType = "hmac" | "apikey" | "gitlab" | "pagerduty" | (string & {});
export declare const WebhookType: any;
export type WebhookSecret = string | redacted.Redacted<string>;
export type ApiKeyValue = string | redacted.Redacted<string>;
export interface GenericWebhook {
    webhookUrl?: string;
    webhookId?: string;
    webhookType?: WebhookType;
    webhookSecret?: string | redacted.Redacted<string>;
    apiKey?: string | redacted.Redacted<string>;
}
export declare const GenericWebhook: S.Schema<GenericWebhook>;
export interface AssociateServiceOutput {
    association: Association;
    webhook?: GenericWebhook;
}
export declare const AssociateServiceOutput: S.Schema<AssociateServiceOutput>;
export type AgentSpaceName = string;
export type Description = string | redacted.Redacted<string>;
export type Locale = string;
export type KmsKeyArn = string;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export type AgentSpacePreferenceKey = "elevatedActionsEnabled" | (string & {});
export declare const AgentSpacePreferenceKey: any;
export type AgentSpacePreferences = {
    [key in AgentSpacePreferenceKey]?: boolean;
};
export declare const AgentSpacePreferences: any;
export interface CreateAgentSpaceInput {
    name: string;
    description?: string | redacted.Redacted<string>;
    locale?: string;
    kmsKeyArn?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    preferences?: {
        [key: string]: boolean | undefined;
    };
}
export declare const CreateAgentSpaceInput: S.Schema<CreateAgentSpaceInput>;
export interface AgentSpace {
    name: string;
    description?: string | redacted.Redacted<string>;
    locale?: string;
    createdAt: Date;
    updatedAt: Date;
    kmsKeyArn?: string;
    agentSpaceId: string;
    preferences?: {
        [key: string]: boolean | undefined;
    };
}
export declare const AgentSpace: S.Schema<AgentSpace>;
export interface CreateAgentSpaceOutput {
    agentSpace: AgentSpace;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateAgentSpaceOutput: S.Schema<CreateAgentSpaceOutput>;
export type AgentSpaceIdentifier = string;
export type AssetType = string;
export type AssetFilePath = string;
export type AssetFileBytes = Uint8Array;
export type AssetFileText = string;
export type AssetFileBody = {
    bytes: Uint8Array;
    text?: never;
} | {
    bytes?: never;
    text: string;
};
export declare const AssetFileBody: any;
export interface AssetFileContent {
    path: string;
    body: AssetFileBody;
    metadata?: any;
}
export declare const AssetFileContent: S.Schema<AssetFileContent>;
export type AssetZipBytes = Uint8Array;
export interface AssetZipContent {
    zipFile: Uint8Array;
}
export declare const AssetZipContent: S.Schema<AssetZipContent>;
export type AssetContentUrl = string;
export interface AssetSourceUrlContent {
    url: string;
}
export declare const AssetSourceUrlContent: S.Schema<AssetSourceUrlContent>;
export type AssetContent = {
    file: AssetFileContent;
    zip?: never;
    sourceUrl?: never;
} | {
    file?: never;
    zip: AssetZipContent;
    sourceUrl?: never;
} | {
    file?: never;
    zip?: never;
    sourceUrl: AssetSourceUrlContent;
};
export declare const AssetContent: any;
export interface CreateAssetRequest {
    agentSpaceId: string;
    assetType: string;
    metadata?: any;
    content: AssetContent;
    clientToken?: string;
}
export declare const CreateAssetRequest: S.Schema<CreateAssetRequest>;
export type ResourceId = string;
export interface Asset {
    assetId: string;
    assetType: string;
    metadata: any;
    version: number;
    createdAt: Date;
    updatedAt: Date;
}
export declare const Asset: S.Schema<Asset>;
export interface CreateAssetResponse {
    asset: Asset;
}
export declare const CreateAssetResponse: S.Schema<CreateAssetResponse>;
export interface CreateAssetFileRequest {
    agentSpaceId: string;
    assetId: string;
    path: string;
    content: AssetFileBody;
    metadata?: any;
    clientToken?: string;
}
export declare const CreateAssetFileRequest: S.Schema<CreateAssetFileRequest>;
export interface AssetFile {
    path: string;
    content: AssetFileBody;
    metadata?: any;
    version: number;
    createdAt: Date;
    updatedAt: Date;
}
export declare const AssetFile: S.Schema<AssetFile>;
export interface CreateAssetFileResponse {
    file: AssetFile;
}
export declare const CreateAssetFileResponse: S.Schema<CreateAssetFileResponse>;
export interface ReferenceInput {
    system: string;
    title?: string;
    referenceId: string;
    referenceUrl: string;
    associationId: string;
}
export declare const ReferenceInput: S.Schema<ReferenceInput>;
export type TaskType = "INVESTIGATION" | "EVALUATION" | "RELEASE_READINESS_REVIEW" | "RELEASE_TESTING" | (string & {});
export declare const TaskType: any;
export type BacklogTaskTitle = string;
export type BacklogTaskDescription = string;
export type Priority = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "MINIMAL" | (string & {});
export declare const Priority: any;
export interface CreateBacklogTaskRequest {
    agentSpaceId: string;
    reference?: ReferenceInput;
    taskType: TaskType;
    title: string;
    description?: string;
    priority: Priority;
    clientToken?: string;
}
export declare const CreateBacklogTaskRequest: S.Schema<CreateBacklogTaskRequest>;
export interface ReferenceOutput {
    system: string;
    title?: string;
    referenceId: string;
    referenceUrl: string;
    associationId: string;
}
export declare const ReferenceOutput: S.Schema<ReferenceOutput>;
export type TaskStatus = "PENDING_TRIAGE" | "LINKED" | "PENDING_START" | "IN_PROGRESS" | "PENDING_CUSTOMER_APPROVAL" | "COMPLETED" | "FAILED" | "TIMED_OUT" | "CANCELED" | "SKIPPED" | "WAITING" | (string & {});
export declare const TaskStatus: any;
export type BackLogTimestamp = Date;
export interface Task {
    agentSpaceId: string;
    taskId: string;
    executionId?: string;
    title: string;
    description?: string;
    reference?: ReferenceOutput;
    taskType: TaskType;
    priority: Priority;
    status: TaskStatus;
    createdAt: Date;
    updatedAt: Date;
    version: number;
    supportMetadata?: any;
    metadata?: any;
    primaryTaskId?: string;
    statusReason?: string;
    hasLinkedTasks?: boolean;
}
export declare const Task: S.Schema<Task>;
export interface CreateBacklogTaskResponse {
    task: Task;
}
export declare const CreateBacklogTaskResponse: S.Schema<CreateBacklogTaskResponse>;
export type UserType = "IAM" | "IDC" | "IDP" | (string & {});
export declare const UserType: any;
export interface CreateChatRequest {
    agentSpaceId: string;
    userId?: string;
    userType?: UserType;
}
export declare const CreateChatRequest: S.Schema<CreateChatRequest>;
export interface CreateChatResponse {
    executionId: string;
    createdAt: Date;
}
export declare const CreateChatResponse: S.Schema<CreateChatResponse>;
export type PrivateConnectionName = string;
export type IpAddressOrDnsName = string;
export type VpcId = string;
export type SubnetId = string;
export type ListOfSubnetIds = string[];
export declare const ListOfSubnetIds: any;
export type SecurityGroupId = string;
export type ListOfSecurityGroupIds = string[];
export declare const ListOfSecurityGroupIds: any;
export type IpAddressType = "IPV4" | "IPV6" | "DUAL_STACK" | (string & {});
export declare const IpAddressType: any;
export type MaxIpv4AddressesPerEni = number;
export type PortRange = string;
export type PortRanges = string[];
export declare const PortRanges: any;
export type CertificateString = string;
export type ResourceConfigDnsResolution = "PUBLIC" | "IN_VPC" | (string & {});
export declare const ResourceConfigDnsResolution: any;
export interface ServiceManagedInput {
    hostAddress: string;
    vpcId: string;
    subnetIds: string[];
    securityGroupIds?: string[];
    ipAddressType?: IpAddressType;
    ipv4AddressesPerEni?: number;
    portRanges?: string[];
    certificate?: string;
    dnsResolution?: ResourceConfigDnsResolution;
}
export declare const ServiceManagedInput: S.Schema<ServiceManagedInput>;
export type ResourceConfigurationArn = string;
export interface SelfManagedInput {
    resourceConfigurationId: string;
    certificate?: string;
}
export declare const SelfManagedInput: S.Schema<SelfManagedInput>;
export type PrivateConnectionMode = {
    serviceManaged: ServiceManagedInput;
    selfManaged?: never;
} | {
    serviceManaged?: never;
    selfManaged: SelfManagedInput;
};
export declare const PrivateConnectionMode: any;
export interface CreatePrivateConnectionInput {
    name: string;
    mode: PrivateConnectionMode;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePrivateConnectionInput: S.Schema<CreatePrivateConnectionInput>;
export type PrivateConnectionType = "SELF_MANAGED" | "SERVICE_MANAGED" | (string & {});
export declare const PrivateConnectionType: any;
export type ResourceGatewayArn = string;
export type PrivateConnectionStatus = "ACTIVE" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export declare const PrivateConnectionStatus: any;
export type FailureMessage = string;
export interface CreatePrivateConnectionOutput {
    name: string;
    type: PrivateConnectionType;
    resourceGatewayId?: string;
    hostAddress?: string;
    vpcId?: string;
    resourceConfigurationId?: string;
    status: PrivateConnectionStatus;
    certificateExpiryTime?: Date;
    dnsResolution?: ResourceConfigDnsResolution;
    failureMessage?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePrivateConnectionOutput: S.Schema<CreatePrivateConnectionOutput>;
export type TriggerType = string;
export type ScheduleExpression = string;
export interface ScheduleCondition {
    expression: string;
}
export declare const ScheduleCondition: S.Schema<ScheduleCondition>;
export type TriggerCondition = {
    schedule: ScheduleCondition;
};
export declare const TriggerCondition: any;
export type TriggerAction = unknown;
export type TriggerStatus = string;
export interface CreateTriggerRequest {
    agentSpaceId: string;
    type: string;
    condition: TriggerCondition;
    action: any;
    status?: string;
    clientToken?: string;
}
export declare const CreateTriggerRequest: S.Schema<CreateTriggerRequest>;
export interface Trigger {
    triggerId: string;
    agentSpaceId: string;
    type: string;
    condition: TriggerCondition;
    action: any;
    status: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const Trigger: S.Schema<Trigger>;
export interface CreateTriggerResponse {
    trigger: Trigger;
}
export declare const CreateTriggerResponse: S.Schema<CreateTriggerResponse>;
export interface DeleteAgentSpaceInput {
    agentSpaceId: string;
}
export declare const DeleteAgentSpaceInput: S.Schema<DeleteAgentSpaceInput>;
export interface DeleteAgentSpaceOutput {
}
export declare const DeleteAgentSpaceOutput: S.Schema<DeleteAgentSpaceOutput>;
export interface DeleteAssetRequest {
    agentSpaceId: string;
    assetId: string;
}
export declare const DeleteAssetRequest: S.Schema<DeleteAssetRequest>;
export interface DeleteAssetResponse {
}
export declare const DeleteAssetResponse: S.Schema<DeleteAssetResponse>;
export interface DeleteAssetFileRequest {
    agentSpaceId: string;
    assetId: string;
    path: string;
}
export declare const DeleteAssetFileRequest: S.Schema<DeleteAssetFileRequest>;
export interface DeleteAssetFileResponse {
}
export declare const DeleteAssetFileResponse: S.Schema<DeleteAssetFileResponse>;
export interface DeletePrivateConnectionInput {
    name: string;
}
export declare const DeletePrivateConnectionInput: S.Schema<DeletePrivateConnectionInput>;
export interface DeletePrivateConnectionOutput {
    name: string;
    status: PrivateConnectionStatus;
}
export declare const DeletePrivateConnectionOutput: S.Schema<DeletePrivateConnectionOutput>;
export interface DeleteTriggerRequest {
    agentSpaceId: string;
    triggerId: string;
}
export declare const DeleteTriggerRequest: S.Schema<DeleteTriggerRequest>;
export interface DeleteTriggerResponse {
}
export declare const DeleteTriggerResponse: S.Schema<DeleteTriggerResponse>;
export interface DeregisterServiceInput {
    serviceId: string;
}
export declare const DeregisterServiceInput: S.Schema<DeregisterServiceInput>;
export interface DeregisterServiceOutput {
}
export declare const DeregisterServiceOutput: S.Schema<DeregisterServiceOutput>;
export interface DescribePrivateConnectionInput {
    name: string;
}
export declare const DescribePrivateConnectionInput: S.Schema<DescribePrivateConnectionInput>;
export interface DescribePrivateConnectionOutput {
    name: string;
    type: PrivateConnectionType;
    resourceGatewayId?: string;
    hostAddress?: string;
    vpcId?: string;
    resourceConfigurationId?: string;
    status: PrivateConnectionStatus;
    certificateExpiryTime?: Date;
    dnsResolution?: ResourceConfigDnsResolution;
    failureMessage?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DescribePrivateConnectionOutput: S.Schema<DescribePrivateConnectionOutput>;
export type AuthFlow = "iam" | "idc" | "idp" | (string & {});
export declare const AuthFlow: any;
export interface DisableOperatorAppInput {
    agentSpaceId: string;
    authFlow?: AuthFlow;
}
export declare const DisableOperatorAppInput: S.Schema<DisableOperatorAppInput>;
export interface DisableOperatorAppResponse {
}
export declare const DisableOperatorAppResponse: S.Schema<DisableOperatorAppResponse>;
export interface DisassociateServiceInput {
    agentSpaceId: string;
    associationId: string;
}
export declare const DisassociateServiceInput: S.Schema<DisassociateServiceInput>;
export interface DisassociateServiceOutput {
}
export declare const DisassociateServiceOutput: S.Schema<DisassociateServiceOutput>;
export type IdpClientId = string;
export type IdpClientSecret = string | redacted.Redacted<string>;
export interface EnableOperatorAppInput {
    agentSpaceId: string;
    authFlow: AuthFlow;
    operatorAppRoleArn: string;
    idcInstanceArn?: string;
    issuerUrl?: string;
    idpClientId?: string;
    idpClientSecret?: string | redacted.Redacted<string>;
    provider?: string;
}
export declare const EnableOperatorAppInput: S.Schema<EnableOperatorAppInput>;
export type OperatorAppUrl = string;
export interface IamAuthConfiguration {
    operatorAppRoleArn: string;
    createdAt: Date;
    updatedAt?: Date;
}
export declare const IamAuthConfiguration: S.Schema<IamAuthConfiguration>;
export interface IdcAuthConfiguration {
    operatorAppRoleArn: string;
    idcInstanceArn: string;
    idcApplicationArn?: string;
    createdAt: Date;
    updatedAt?: Date;
}
export declare const IdcAuthConfiguration: S.Schema<IdcAuthConfiguration>;
export interface IdpAuthConfiguration {
    issuerUrl: string;
    clientId: string;
    operatorAppRoleArn: string;
    provider: string;
    createdAt: Date;
    updatedAt?: Date;
}
export declare const IdpAuthConfiguration: S.Schema<IdpAuthConfiguration>;
export interface EnableOperatorAppOutput {
    agentSpaceId: string;
    operatorAppUrl?: string;
    iam?: IamAuthConfiguration;
    idc?: IdcAuthConfiguration;
    idp?: IdpAuthConfiguration;
}
export declare const EnableOperatorAppOutput: S.Schema<EnableOperatorAppOutput>;
export interface GetAccountUsageInput {
}
export declare const GetAccountUsageInput: S.Schema<GetAccountUsageInput>;
export interface UsageMetric {
    limit: number;
    usage: number;
}
export declare const UsageMetric: S.Schema<UsageMetric>;
export interface GetAccountUsageOutput {
    monthlyAccountInvestigationHours?: UsageMetric;
    monthlyAccountEvaluationHours?: UsageMetric;
    monthlyAccountSystemLearningHours?: UsageMetric;
    monthlyAccountOnDemandHours?: UsageMetric;
    usagePeriodStartTime: Date;
    usagePeriodEndTime: Date;
}
export declare const GetAccountUsageOutput: S.Schema<GetAccountUsageOutput>;
export interface GetAgentSpaceInput {
    agentSpaceId: string;
}
export declare const GetAgentSpaceInput: S.Schema<GetAgentSpaceInput>;
export interface GetAgentSpaceOutput {
    agentSpace: AgentSpace;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetAgentSpaceOutput: S.Schema<GetAgentSpaceOutput>;
export interface GetAssetRequest {
    agentSpaceId: string;
    assetId: string;
    assetVersion?: number;
}
export declare const GetAssetRequest: S.Schema<GetAssetRequest>;
export interface GetAssetResponse {
    asset: Asset;
}
export declare const GetAssetResponse: S.Schema<GetAssetResponse>;
export interface GetAssetContentRequest {
    agentSpaceId: string;
    assetId: string;
    assetVersion?: number;
}
export declare const GetAssetContentRequest: S.Schema<GetAssetContentRequest>;
export interface GetAssetContentResponse {
    content: AssetZipContent;
    version: number;
}
export declare const GetAssetContentResponse: S.Schema<GetAssetContentResponse>;
export interface GetAssetFileRequest {
    agentSpaceId: string;
    assetId: string;
    path: string;
    assetVersion?: number;
}
export declare const GetAssetFileRequest: S.Schema<GetAssetFileRequest>;
export interface GetAssetFileResponse {
    file: AssetFile;
}
export declare const GetAssetFileResponse: S.Schema<GetAssetFileResponse>;
export interface GetAssociationInput {
    agentSpaceId: string;
    associationId: string;
}
export declare const GetAssociationInput: S.Schema<GetAssociationInput>;
export interface GetAssociationOutput {
    association: Association;
}
export declare const GetAssociationOutput: S.Schema<GetAssociationOutput>;
export interface GetBacklogTaskRequest {
    agentSpaceId: string;
    taskId: string;
}
export declare const GetBacklogTaskRequest: S.Schema<GetBacklogTaskRequest>;
export interface GetBacklogTaskResponse {
    task: Task;
}
export declare const GetBacklogTaskResponse: S.Schema<GetBacklogTaskResponse>;
export interface GetOperatorAppInput {
    agentSpaceId: string;
}
export declare const GetOperatorAppInput: S.Schema<GetOperatorAppInput>;
export interface GetOperatorAppOutput {
    operatorAppUrl?: string;
    iam?: IamAuthConfiguration;
    idc?: IdcAuthConfiguration;
    idp?: IdpAuthConfiguration;
}
export declare const GetOperatorAppOutput: S.Schema<GetOperatorAppOutput>;
export interface GetRecommendationRequest {
    agentSpaceId: string;
    recommendationId: string;
    recommendationVersion?: number;
}
export declare const GetRecommendationRequest: S.Schema<GetRecommendationRequest>;
export interface RecommendationContent {
    summary: string;
    spec?: string;
}
export declare const RecommendationContent: S.Schema<RecommendationContent>;
export type RecommendationStatus = "PROPOSED" | "ACCEPTED" | "REJECTED" | "CLOSED" | "COMPLETED" | "UPDATE_IN_PROGRESS" | (string & {});
export declare const RecommendationStatus: any;
export type RecommendationPriority = "HIGH" | "MEDIUM" | "LOW" | (string & {});
export declare const RecommendationPriority: any;
export interface Recommendation {
    agentSpaceArn: string;
    recommendationId: string;
    taskId: string;
    goalId?: string;
    title: string;
    content: RecommendationContent;
    status: RecommendationStatus;
    priority: RecommendationPriority;
    goalVersion?: number;
    additionalContext?: string;
    rankPosition?: number;
    rankedAt?: Date;
    createdAt: Date;
    updatedAt: Date;
    version: number;
}
export declare const Recommendation: S.Schema<Recommendation>;
export interface GetRecommendationResponse {
    recommendation: Recommendation;
}
export declare const GetRecommendationResponse: S.Schema<GetRecommendationResponse>;
export interface GetServiceInput {
    serviceId: string;
}
export declare const GetServiceInput: S.Schema<GetServiceInput>;
export type Service = "github" | "slack" | "azure" | "azuredevops" | "dynatrace" | "servicenow" | "pagerduty" | "gitlab" | "eventChannel" | "mcpservernewrelic" | "mcpservergrafana" | "mcpserverdatadog" | "mcpserver" | "mcpserversplunk" | "azureidentity" | "mcpserversigv4" | "remoteagent" | "remoteagentsigv4" | (string & {});
export declare const Service: any;
export type ServiceName = string;
export type DocumentList = any[];
export declare const DocumentList: any;
export interface RegisteredGithubServiceDetails {
    owner: string;
    ownerType: GithubRepoOwnerType;
    targetUrl?: string;
}
export declare const RegisteredGithubServiceDetails: S.Schema<RegisteredGithubServiceDetails>;
export interface RegisteredSlackServiceDetails {
    teamId: string;
    teamName: string;
}
export declare const RegisteredSlackServiceDetails: S.Schema<RegisteredSlackServiceDetails>;
export type MCPServerAuthorizationMethod = "oauth-client-credentials" | "oauth-3lo" | "api-key" | "bearer-token" | (string & {});
export declare const MCPServerAuthorizationMethod: any;
export interface RegisteredMCPServerDetails {
    name: string;
    endpoint: string;
    authorizationMethod: MCPServerAuthorizationMethod;
    description?: string | redacted.Redacted<string>;
    apiKeyHeader?: string;
}
export declare const RegisteredMCPServerDetails: S.Schema<RegisteredMCPServerDetails>;
export type ServiceNowInstanceUrl = string;
export interface RegisteredServiceNowDetails {
    instanceUrl?: string;
}
export declare const RegisteredServiceNowDetails: S.Schema<RegisteredServiceNowDetails>;
export type GitLabTokenType = "personal" | "group" | (string & {});
export declare const GitLabTokenType: any;
export interface RegisteredGitLabServiceDetails {
    targetUrl: string;
    tokenType: GitLabTokenType;
    groupId?: string;
}
export declare const RegisteredGitLabServiceDetails: S.Schema<RegisteredGitLabServiceDetails>;
export type NewRelicRegion = "US" | "EU" | "JP" | (string & {});
export declare const NewRelicRegion: any;
export interface RegisteredNewRelicDetails {
    accountId: string;
    region: NewRelicRegion;
    description?: string | redacted.Redacted<string>;
}
export declare const RegisteredNewRelicDetails: S.Schema<RegisteredNewRelicDetails>;
export interface RegisteredAzureDevOpsServiceDetails {
    organizationName: string;
}
export declare const RegisteredAzureDevOpsServiceDetails: S.Schema<RegisteredAzureDevOpsServiceDetails>;
export type Guid = string;
export type WebIdentityTokenAudienceList = string[];
export declare const WebIdentityTokenAudienceList: any;
export interface RegisteredAzureIdentityDetails {
    tenantId: string;
    clientId: string;
    webIdentityRoleArn: string;
    webIdentityTokenAudiences: string[];
}
export declare const RegisteredAzureIdentityDetails: S.Schema<RegisteredAzureIdentityDetails>;
export type MCPServerEndpoint = string;
export interface RegisteredGrafanaServerDetails {
    endpoint: string;
    authorizationMethod: MCPServerAuthorizationMethod;
}
export declare const RegisteredGrafanaServerDetails: S.Schema<RegisteredGrafanaServerDetails>;
export type PagerDutyScopesList = string[];
export declare const PagerDutyScopesList: any;
export interface RegisteredPagerDutyDetails {
    scopes: string[];
}
export declare const RegisteredPagerDutyDetails: S.Schema<RegisteredPagerDutyDetails>;
export type MCPServerName = string;
export type SigV4Region = string;
export type CustomHeaderName = string;
export type CustomHeaderValue = string | redacted.Redacted<string>;
export type CustomHeaders = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const CustomHeaders: any;
export interface RegisteredMCPServerSigV4Details {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    region: string;
    service: string;
    roleArn: string;
    mcpRoleArn?: string;
    customHeaders?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export declare const RegisteredMCPServerSigV4Details: S.Schema<RegisteredMCPServerSigV4Details>;
export type RemoteAgentName = string;
export type RemoteAgentEndpoint = string;
export type RemoteAgentAuthorizationMethod = "oauth-client-credentials" | "api-key" | "bearer-token" | (string & {});
export declare const RemoteAgentAuthorizationMethod: any;
export interface RegisteredRemoteAgentDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationMethod: RemoteAgentAuthorizationMethod;
    apiKeyHeader?: string;
}
export declare const RegisteredRemoteAgentDetails: S.Schema<RegisteredRemoteAgentDetails>;
export interface RegisteredRemoteAgentSigV4Details {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    region: string;
    service: string;
    roleArn?: string;
}
export declare const RegisteredRemoteAgentSigV4Details: S.Schema<RegisteredRemoteAgentSigV4Details>;
export type AdditionalServiceDetails = {
    github: RegisteredGithubServiceDetails;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack: RegisteredSlackServiceDetails;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog: RegisteredMCPServerDetails;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver: RegisteredMCPServerDetails;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow: RegisteredServiceNowDetails;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab: RegisteredGitLabServiceDetails;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk: RegisteredMCPServerDetails;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic: RegisteredNewRelicDetails;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops: RegisteredAzureDevOpsServiceDetails;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity: RegisteredAzureIdentityDetails;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana: RegisteredGrafanaServerDetails;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty: RegisteredPagerDutyDetails;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4: RegisteredMCPServerSigV4Details;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent: RegisteredRemoteAgentDetails;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4: RegisteredRemoteAgentSigV4Details;
};
export declare const AdditionalServiceDetails: any;
export interface RegisteredService {
    serviceId: string;
    serviceType: Service;
    name?: string;
    accessibleResources?: any[];
    additionalServiceDetails?: AdditionalServiceDetails;
    kmsKeyArn?: string;
    privateConnectionName?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const RegisteredService: S.Schema<RegisteredService>;
export interface GetServiceOutput {
    service: RegisteredService & {
        createdAt: Date;
        updatedAt: Date;
    };
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetServiceOutput: S.Schema<GetServiceOutput>;
export interface GetTriggerRequest {
    agentSpaceId: string;
    triggerId: string;
}
export declare const GetTriggerRequest: S.Schema<GetTriggerRequest>;
export interface GetTriggerResponse {
    trigger: Trigger;
}
export declare const GetTriggerResponse: S.Schema<GetTriggerResponse>;
export type NextToken = string;
export interface ListAgentSpacesInput {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAgentSpacesInput: S.Schema<ListAgentSpacesInput>;
export type AgentSpaceList = AgentSpace[];
export declare const AgentSpaceList: any;
export interface ListAgentSpacesOutput {
    nextToken?: string;
    agentSpaces: AgentSpace[];
}
export declare const ListAgentSpacesOutput: S.Schema<ListAgentSpacesOutput>;
export interface ListAssetFilesRequest {
    agentSpaceId: string;
    assetId: string;
    assetVersion?: number;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAssetFilesRequest: S.Schema<ListAssetFilesRequest>;
export interface AssetFileSummary {
    path: string;
    metadata?: any;
    version: number;
    createdAt: Date;
    updatedAt: Date;
}
export declare const AssetFileSummary: S.Schema<AssetFileSummary>;
export type AssetFileSummaryList = AssetFileSummary[];
export declare const AssetFileSummaryList: any;
export interface ListAssetFilesResponse {
    items: AssetFileSummary[];
    nextToken?: string;
}
export declare const ListAssetFilesResponse: S.Schema<ListAssetFilesResponse>;
export interface ListAssetsRequest {
    agentSpaceId: string;
    assetType?: string;
    updatedAfter?: Date;
    updatedBefore?: Date;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAssetsRequest: S.Schema<ListAssetsRequest>;
export type AssetList = Asset[];
export declare const AssetList: any;
export interface ListAssetsResponse {
    items: Asset[];
    nextToken?: string;
}
export declare const ListAssetsResponse: S.Schema<ListAssetsResponse>;
export interface ListAssetTypesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAssetTypesRequest: S.Schema<ListAssetTypesRequest>;
export interface AssetTypeSummary {
    assetType: string;
    description: string;
}
export declare const AssetTypeSummary: S.Schema<AssetTypeSummary>;
export type AssetTypeList = AssetTypeSummary[];
export declare const AssetTypeList: any;
export interface ListAssetTypesResponse {
    items: AssetTypeSummary[];
    nextToken?: string;
}
export declare const ListAssetTypesResponse: S.Schema<ListAssetTypesResponse>;
export interface ListAssetVersionsRequest {
    agentSpaceId: string;
    assetId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAssetVersionsRequest: S.Schema<ListAssetVersionsRequest>;
export interface AssetVersionMetadata {
    version: number;
    createdAt: Date;
    updatedAt: Date;
}
export declare const AssetVersionMetadata: S.Schema<AssetVersionMetadata>;
export type AssetVersionMetadataList = AssetVersionMetadata[];
export declare const AssetVersionMetadataList: any;
export interface ListAssetVersionsResponse {
    items: AssetVersionMetadata[];
    nextToken?: string;
}
export declare const ListAssetVersionsResponse: S.Schema<ListAssetVersionsResponse>;
export interface ListAssociationsInput {
    agentSpaceId: string;
    maxResults?: number;
    nextToken?: string;
    filterServiceTypes?: string;
}
export declare const ListAssociationsInput: S.Schema<ListAssociationsInput>;
export type AssociationsList = Association[];
export declare const AssociationsList: any;
export interface ListAssociationsOutput {
    nextToken?: string;
    associations: Association[];
}
export declare const ListAssociationsOutput: S.Schema<ListAssociationsOutput>;
export type PriorityList = Priority[];
export declare const PriorityList: any;
export type TaskStatusList = TaskStatus[];
export declare const TaskStatusList: any;
export type TaskTypeList = TaskType[];
export declare const TaskTypeList: any;
export interface TaskFilter {
    createdAfter?: Date;
    createdBefore?: Date;
    priority?: Priority[];
    status?: TaskStatus[];
    taskType?: TaskType[];
    primaryTaskId?: string;
}
export declare const TaskFilter: S.Schema<TaskFilter>;
export type TaskSortField = "CREATED_AT" | "PRIORITY" | (string & {});
export declare const TaskSortField: any;
export type TaskSortOrder = "ASC" | "DESC" | (string & {});
export declare const TaskSortOrder: any;
export interface ListBacklogTasksRequest {
    agentSpaceId: string;
    filter?: TaskFilter;
    limit?: number;
    nextToken?: string;
    sortField?: TaskSortField;
    order?: TaskSortOrder;
}
export declare const ListBacklogTasksRequest: S.Schema<ListBacklogTasksRequest>;
export type TaskList = Task[];
export declare const TaskList: any;
export interface ListBacklogTasksResponse {
    tasks: Task[];
    nextToken?: string;
}
export declare const ListBacklogTasksResponse: S.Schema<ListBacklogTasksResponse>;
export interface ListChatsRequest {
    agentSpaceId: string;
    userId?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListChatsRequest: S.Schema<ListChatsRequest>;
export interface ChatExecution {
    executionId: string;
    createdAt: Date;
    updatedAt?: Date;
    summary?: string;
}
export declare const ChatExecution: S.Schema<ChatExecution>;
export type ChatExecutionList = ChatExecution[];
export declare const ChatExecutionList: any;
export interface ListChatsResponse {
    executions: ChatExecution[];
    nextToken?: string;
}
export declare const ListChatsResponse: S.Schema<ListChatsResponse>;
export interface ListExecutionsRequest {
    agentSpaceId: string;
    taskId: string;
    limit?: number;
    nextToken?: string;
}
export declare const ListExecutionsRequest: S.Schema<ListExecutionsRequest>;
export type JournalTimestamp = Date;
export type ExecutionStatus = "FAILED" | "RUNNING" | "STOPPED" | "CANCELED" | "TIMED_OUT" | "WAITING" | (string & {});
export declare const ExecutionStatus: any;
export interface Execution {
    agentSpaceId: string;
    executionId: string;
    parentExecutionId?: string;
    agentSubTask: string;
    createdAt: Date;
    updatedAt: Date;
    executionStatus: ExecutionStatus;
    agentType?: string;
    uid?: string;
}
export declare const Execution: S.Schema<Execution>;
export type ExecutionList = Execution[];
export declare const ExecutionList: any;
export interface ListExecutionsResponse {
    executions: Execution[];
    nextToken?: string;
}
export declare const ListExecutionsResponse: S.Schema<ListExecutionsResponse>;
export type GoalStatus = "ACTIVE" | "PAUSED" | "COMPLETE" | (string & {});
export declare const GoalStatus: any;
export type GoalType = "CUSTOMER_DEFINED" | "ONCALL_REPORT" | (string & {});
export declare const GoalType: any;
export interface ListGoalsRequest {
    agentSpaceId: string;
    status?: GoalStatus;
    goalType?: GoalType;
    limit?: number;
    nextToken?: string;
}
export declare const ListGoalsRequest: S.Schema<ListGoalsRequest>;
export interface GoalContent {
    description: string;
    objectives: string;
}
export declare const GoalContent: S.Schema<GoalContent>;
export type SchedulerState = "ENABLED" | "DISABLED" | (string & {});
export declare const SchedulerState: any;
export interface GoalSchedule {
    state: SchedulerState;
    expression?: string;
}
export declare const GoalSchedule: S.Schema<GoalSchedule>;
export interface Goal {
    agentSpaceArn: string;
    goalId: string;
    title: string;
    content: GoalContent;
    status: GoalStatus;
    goalType: GoalType;
    createdAt: Date;
    updatedAt: Date;
    lastEvaluatedAt?: Date;
    lastTaskId?: string;
    lastSuccessfulTaskId?: string;
    version: number;
    evaluationSchedule?: GoalSchedule;
}
export declare const Goal: S.Schema<Goal>;
export type GoalList = Goal[];
export declare const GoalList: any;
export interface ListGoalsResponse {
    goals: Goal[];
    nextToken?: string;
}
export declare const ListGoalsResponse: S.Schema<ListGoalsResponse>;
export type OrderType = "ASC" | "DESC" | (string & {});
export declare const OrderType: any;
export interface ListJournalRecordsRequest {
    agentSpaceId: string;
    executionId: string;
    limit?: number;
    nextToken?: string;
    recordType?: string;
    order?: OrderType;
}
export declare const ListJournalRecordsRequest: S.Schema<ListJournalRecordsRequest>;
export interface UserReference {
    userId: string;
    userType: UserType;
}
export declare const UserReference: S.Schema<UserReference>;
export interface JournalRecord {
    agentSpaceId: string;
    executionId: string;
    recordId: string;
    content: any;
    createdAt: Date;
    recordType: string;
    userReference?: UserReference;
}
export declare const JournalRecord: S.Schema<JournalRecord>;
export type JournalRecordList = JournalRecord[];
export declare const JournalRecordList: any;
export interface ListJournalRecordsResponse {
    records: JournalRecord[];
    nextToken?: string;
}
export declare const ListJournalRecordsResponse: S.Schema<ListJournalRecordsResponse>;
export interface ListPendingMessagesRequest {
    agentSpaceId: string;
    executionId: string;
}
export declare const ListPendingMessagesRequest: S.Schema<ListPendingMessagesRequest>;
export type UserMessageBlock = {
    text: string;
    toolResult?: never;
} | {
    text?: never;
    toolResult: any;
};
export declare const UserMessageBlock: any;
export type UserMessage = UserMessageBlock[];
export declare const UserMessage: any;
export type AssistantMessageBlock = {
    text: string;
    toolUse?: never;
} | {
    text?: never;
    toolUse: any;
};
export declare const AssistantMessageBlock: any;
export type AssistantMessage = AssistantMessageBlock[];
export declare const AssistantMessage: any;
export type Message = {
    userMessage: UserMessageBlock[];
    assistantMessage?: never;
} | {
    userMessage?: never;
    assistantMessage: AssistantMessageBlock[];
};
export declare const Message: any;
export interface PendingMessage {
    messageId: string;
    message: Message;
}
export declare const PendingMessage: S.Schema<PendingMessage>;
export type PendingMessages = PendingMessage[];
export declare const PendingMessages: any;
export interface ListPendingMessagesResponse {
    agentSpaceId: string;
    executionId: string;
    messages: PendingMessage[];
    createdAt: Date;
}
export declare const ListPendingMessagesResponse: S.Schema<ListPendingMessagesResponse>;
export interface ListPrivateConnectionsInput {
}
export declare const ListPrivateConnectionsInput: S.Schema<ListPrivateConnectionsInput>;
export interface PrivateConnectionSummary {
    name: string;
    type: PrivateConnectionType;
    resourceGatewayId?: string;
    hostAddress?: string;
    vpcId?: string;
    resourceConfigurationId?: string;
    status: PrivateConnectionStatus;
    certificateExpiryTime?: Date;
    dnsResolution?: ResourceConfigDnsResolution;
    failureMessage?: string;
}
export declare const PrivateConnectionSummary: S.Schema<PrivateConnectionSummary>;
export type PrivateConnectionSummaryList = PrivateConnectionSummary[];
export declare const PrivateConnectionSummaryList: any;
export interface ListPrivateConnectionsOutput {
    privateConnections: PrivateConnectionSummary[];
}
export declare const ListPrivateConnectionsOutput: S.Schema<ListPrivateConnectionsOutput>;
export interface ListRecommendationsRequest {
    agentSpaceId: string;
    taskId?: string;
    goalId?: string;
    status?: RecommendationStatus;
    priority?: RecommendationPriority;
    limit?: number;
    nextToken?: string;
}
export declare const ListRecommendationsRequest: S.Schema<ListRecommendationsRequest>;
export type RecommendationList = Recommendation[];
export declare const RecommendationList: any;
export interface ListRecommendationsResponse {
    recommendations: Recommendation[];
    nextToken?: string;
}
export declare const ListRecommendationsResponse: S.Schema<ListRecommendationsResponse>;
export interface ListServicesInput {
    maxResults?: number;
    nextToken?: string;
    filterServiceType?: Service;
}
export declare const ListServicesInput: S.Schema<ListServicesInput>;
export type RegisteredServicesList = RegisteredService[];
export declare const RegisteredServicesList: any;
export interface ListServicesOutput {
    nextToken?: string;
    services: (RegisteredService & {
        createdAt: Date;
        updatedAt: Date;
    })[];
}
export declare const ListServicesOutput: S.Schema<ListServicesOutput>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListTriggersRequest {
    agentSpaceId: string;
    status?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListTriggersRequest: S.Schema<ListTriggersRequest>;
export type TriggerList = Trigger[];
export declare const TriggerList: any;
export interface ListTriggersResponse {
    items: Trigger[];
    nextToken?: string;
}
export declare const ListTriggersResponse: S.Schema<ListTriggersResponse>;
export interface ListWebhooksInput {
    agentSpaceId: string;
    associationId: string;
}
export declare const ListWebhooksInput: S.Schema<ListWebhooksInput>;
export interface Webhook {
    webhookUrl: string;
    webhookType?: WebhookType;
    webhookId: string;
}
export declare const Webhook: S.Schema<Webhook>;
export type WebhooksList = Webhook[];
export declare const WebhooksList: any;
export interface ListWebhooksOutput {
    webhooks: Webhook[];
}
export declare const ListWebhooksOutput: S.Schema<ListWebhooksOutput>;
export type PostRegisterServiceSupportedService = "dynatrace" | "servicenow" | "pagerduty" | "gitlab" | "eventChannel" | "mcpservernewrelic" | "mcpservergrafana" | "mcpserverdatadog" | "mcpserver" | "mcpserversplunk" | "azureidentity" | "mcpserversigv4" | "remoteagent" | "remoteagentsigv4" | (string & {});
export declare const PostRegisterServiceSupportedService: any;
export type ClientId = string | redacted.Redacted<string>;
export type ExchangeParameterValue = string | redacted.Redacted<string>;
export type ExchangeParameters = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const ExchangeParameters: any;
export type ClientSecret = string | redacted.Redacted<string>;
export interface DynatraceOAuthClientCredentialsConfig {
    clientName?: string;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    clientSecret: string | redacted.Redacted<string>;
}
export declare const DynatraceOAuthClientCredentialsConfig: S.Schema<DynatraceOAuthClientCredentialsConfig>;
export type DynatraceServiceAuthorizationConfig = {
    oAuthClientCredentials: DynatraceOAuthClientCredentialsConfig;
};
export declare const DynatraceServiceAuthorizationConfig: any;
export interface DynatraceServiceDetails {
    accountUrn: string;
    authorizationConfig?: DynatraceServiceAuthorizationConfig;
}
export declare const DynatraceServiceDetails: S.Schema<DynatraceServiceDetails>;
export interface ServiceNowOAuthClientCredentialsConfig {
    clientName?: string;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    clientSecret: string | redacted.Redacted<string>;
}
export declare const ServiceNowOAuthClientCredentialsConfig: S.Schema<ServiceNowOAuthClientCredentialsConfig>;
export type ServiceNowServiceAuthorizationConfig = {
    oAuthClientCredentials: ServiceNowOAuthClientCredentialsConfig;
};
export declare const ServiceNowServiceAuthorizationConfig: any;
export interface ServiceNowServiceDetails {
    instanceUrl: string;
    authorizationConfig?: ServiceNowServiceAuthorizationConfig;
}
export declare const ServiceNowServiceDetails: S.Schema<ServiceNowServiceDetails>;
export interface MCPServerAuthorizationDiscoveryConfig {
    returnToEndpoint: string;
}
export declare const MCPServerAuthorizationDiscoveryConfig: S.Schema<MCPServerAuthorizationDiscoveryConfig>;
export type DatadogAuthorizationConfig = {
    authorizationDiscovery: MCPServerAuthorizationDiscoveryConfig;
};
export declare const DatadogAuthorizationConfig: any;
export interface DatadogServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationConfig: DatadogAuthorizationConfig;
}
export declare const DatadogServiceDetails: S.Schema<DatadogServiceDetails>;
export type OAuthScope = string;
export type Scopes = string[];
export declare const Scopes: any;
export interface MCPServerOAuthClientCredentialsConfig {
    clientName?: string;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    clientSecret: string | redacted.Redacted<string>;
    exchangeUrl: string;
    scopes?: string[];
}
export declare const MCPServerOAuthClientCredentialsConfig: S.Schema<MCPServerOAuthClientCredentialsConfig>;
export interface MCPServerOAuth3LOConfig {
    clientName?: string;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    returnToEndpoint: string;
    authorizationUrl: string;
    exchangeUrl: string;
    clientSecret?: string | redacted.Redacted<string>;
    supportCodeChallenge?: boolean;
    scopes?: string[];
}
export declare const MCPServerOAuth3LOConfig: S.Schema<MCPServerOAuth3LOConfig>;
export interface MCPServerAPIKeyConfig {
    apiKeyName: string;
    apiKeyValue: string | redacted.Redacted<string>;
    apiKeyHeader: string;
}
export declare const MCPServerAPIKeyConfig: S.Schema<MCPServerAPIKeyConfig>;
export type TokenValue = string | redacted.Redacted<string>;
export interface MCPServerBearerTokenConfig {
    tokenName: string;
    tokenValue: string | redacted.Redacted<string>;
    authorizationHeader?: string;
}
export declare const MCPServerBearerTokenConfig: S.Schema<MCPServerBearerTokenConfig>;
export type MCPServerAuthorizationConfig = {
    oAuthClientCredentials: MCPServerOAuthClientCredentialsConfig;
    oAuth3LO?: never;
    apiKey?: never;
    bearerToken?: never;
    authorizationDiscovery?: never;
} | {
    oAuthClientCredentials?: never;
    oAuth3LO: MCPServerOAuth3LOConfig;
    apiKey?: never;
    bearerToken?: never;
    authorizationDiscovery?: never;
} | {
    oAuthClientCredentials?: never;
    oAuth3LO?: never;
    apiKey: MCPServerAPIKeyConfig;
    bearerToken?: never;
    authorizationDiscovery?: never;
} | {
    oAuthClientCredentials?: never;
    oAuth3LO?: never;
    apiKey?: never;
    bearerToken: MCPServerBearerTokenConfig;
    authorizationDiscovery?: never;
} | {
    oAuthClientCredentials?: never;
    oAuth3LO?: never;
    apiKey?: never;
    bearerToken?: never;
    authorizationDiscovery: MCPServerAuthorizationDiscoveryConfig;
};
export declare const MCPServerAuthorizationConfig: any;
export interface MCPServerDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationConfig: MCPServerAuthorizationConfig;
}
export declare const MCPServerDetails: S.Schema<MCPServerDetails>;
export type GitLabTokenValue = string | redacted.Redacted<string>;
export interface GitLabDetails {
    targetUrl: string;
    tokenType: GitLabTokenType;
    tokenValue: string | redacted.Redacted<string>;
    groupId?: string;
}
export declare const GitLabDetails: S.Schema<GitLabDetails>;
export type NewRelicApiKey = string | redacted.Redacted<string>;
export type NewRelicApplicationIds = string[];
export declare const NewRelicApplicationIds: any;
export type NewRelicEntityGuids = string[];
export declare const NewRelicEntityGuids: any;
export type NewRelicAlertPolicyIds = string[];
export declare const NewRelicAlertPolicyIds: any;
export interface NewRelicApiKeyConfig {
    apiKey: string | redacted.Redacted<string>;
    accountId: string;
    region: NewRelicRegion;
    applicationIds?: string[];
    entityGuids?: string[];
    alertPolicyIds?: string[];
}
export declare const NewRelicApiKeyConfig: S.Schema<NewRelicApiKeyConfig>;
export type NewRelicServiceAuthorizationConfig = {
    apiKey: NewRelicApiKeyConfig;
};
export declare const NewRelicServiceAuthorizationConfig: any;
export interface NewRelicServiceDetails {
    authorizationConfig: NewRelicServiceAuthorizationConfig;
}
export declare const NewRelicServiceDetails: S.Schema<NewRelicServiceDetails>;
export type EventChannelType = "webhook" | (string & {});
export declare const EventChannelType: any;
export interface EventChannelDetails {
    type?: EventChannelType;
}
export declare const EventChannelDetails: S.Schema<EventChannelDetails>;
export interface GrafanaServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationConfig: MCPServerAuthorizationConfig;
}
export declare const GrafanaServiceDetails: S.Schema<GrafanaServiceDetails>;
export type PagerDutyScopes = string[];
export declare const PagerDutyScopes: any;
export interface PagerDutyOAuthClientCredentialsConfig {
    clientName?: string;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    clientSecret: string | redacted.Redacted<string>;
}
export declare const PagerDutyOAuthClientCredentialsConfig: S.Schema<PagerDutyOAuthClientCredentialsConfig>;
export type PagerDutyAuthorizationConfig = {
    oAuthClientCredentials: PagerDutyOAuthClientCredentialsConfig;
};
export declare const PagerDutyAuthorizationConfig: any;
export interface PagerDutyDetails {
    scopes: string[];
    authorizationConfig: PagerDutyAuthorizationConfig;
}
export declare const PagerDutyDetails: S.Schema<PagerDutyDetails>;
export interface MCPServerSigV4AuthorizationConfig {
    region: string;
    service: string;
    roleArn?: string;
    mcpRoleArn?: string;
    customHeaders?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export declare const MCPServerSigV4AuthorizationConfig: S.Schema<MCPServerSigV4AuthorizationConfig>;
export interface MCPServerSigV4ServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationConfig: MCPServerSigV4AuthorizationConfig;
}
export declare const MCPServerSigV4ServiceDetails: S.Schema<MCPServerSigV4ServiceDetails>;
export interface RemoteAgentAPIKeyConfig {
    apiKeyName: string;
    apiKeyValue: string | redacted.Redacted<string>;
    apiKeyHeader: string;
}
export declare const RemoteAgentAPIKeyConfig: S.Schema<RemoteAgentAPIKeyConfig>;
export interface RemoteAgentOAuthClientCredentialsConfig {
    clientName?: string;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    clientSecret: string | redacted.Redacted<string>;
    exchangeUrl: string;
    scopes?: string[];
}
export declare const RemoteAgentOAuthClientCredentialsConfig: S.Schema<RemoteAgentOAuthClientCredentialsConfig>;
export interface RemoteAgentBearerTokenConfig {
    tokenName: string;
    tokenValue: string | redacted.Redacted<string>;
    authorizationHeader?: string;
}
export declare const RemoteAgentBearerTokenConfig: S.Schema<RemoteAgentBearerTokenConfig>;
export type RemoteAgentAuthorizationConfig = {
    apiKey: RemoteAgentAPIKeyConfig;
    oAuthClientCredentials?: never;
    bearerToken?: never;
} | {
    apiKey?: never;
    oAuthClientCredentials: RemoteAgentOAuthClientCredentialsConfig;
    bearerToken?: never;
} | {
    apiKey?: never;
    oAuthClientCredentials?: never;
    bearerToken: RemoteAgentBearerTokenConfig;
};
export declare const RemoteAgentAuthorizationConfig: any;
export interface RemoteAgentServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationConfig: RemoteAgentAuthorizationConfig;
}
export declare const RemoteAgentServiceDetails: S.Schema<RemoteAgentServiceDetails>;
export interface RemoteAgentSigV4AuthorizationConfig {
    region: string;
    service: string;
    roleArn?: string;
}
export declare const RemoteAgentSigV4AuthorizationConfig: S.Schema<RemoteAgentSigV4AuthorizationConfig>;
export interface RemoteAgentSigV4ServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationConfig: RemoteAgentSigV4AuthorizationConfig;
}
export declare const RemoteAgentSigV4ServiceDetails: S.Schema<RemoteAgentSigV4ServiceDetails>;
export type ServiceDetails = {
    dynatrace: DynatraceServiceDetails;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow: ServiceNowServiceDetails;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog: DatadogServiceDetails;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver: MCPServerDetails;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab: GitLabDetails;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk: MCPServerDetails;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic: NewRelicServiceDetails;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel: EventChannelDetails;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana: GrafanaServiceDetails;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty: PagerDutyDetails;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity: RegisteredAzureIdentityDetails;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4: MCPServerSigV4ServiceDetails;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent: RemoteAgentServiceDetails;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4: RemoteAgentSigV4ServiceDetails;
};
export declare const ServiceDetails: any;
export interface RegisterServiceInput {
    service: PostRegisterServiceSupportedService;
    serviceDetails: ServiceDetails;
    kmsKeyArn?: string;
    privateConnectionName?: string;
    targetUrlPrivateConnectionName?: string;
    exchangeUrlPrivateConnectionName?: string;
    name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const RegisterServiceInput: S.Schema<RegisterServiceInput>;
export interface OAuthAdditionalStepDetails {
    authorizationUrl: string;
}
export declare const OAuthAdditionalStepDetails: S.Schema<OAuthAdditionalStepDetails>;
export type AdditionalServiceRegistrationStep = {
    oauth: OAuthAdditionalStepDetails;
};
export declare const AdditionalServiceRegistrationStep: any;
export interface RegisterServiceOutput {
    serviceId?: string;
    additionalStep?: AdditionalServiceRegistrationStep;
    kmsKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const RegisterServiceOutput: S.Schema<RegisterServiceOutput>;
export type ChatExecutionId = string;
export type MessageContent = string;
export type ToolUseId = string;
export type InterruptId = string;
export type ApprovalId = string;
export type ButtonText = string;
export type ApprovalActionType = "APPROVED" | "REJECTED" | (string & {});
export declare const ApprovalActionType: any;
export interface ApprovalAction {
    toolUseId?: string;
    interruptId?: string;
    approvalId?: string;
    buttonText?: string;
    action?: ApprovalActionType;
}
export declare const ApprovalAction: S.Schema<ApprovalAction>;
export interface SendMessageContext {
    currentPage?: string;
    lastMessage?: string;
    userActionResponse?: string;
    approvalAction?: ApprovalAction;
}
export declare const SendMessageContext: S.Schema<SendMessageContext>;
export type AssetIdList = string[];
export declare const AssetIdList: any;
export interface SendMessageRequest {
    agentSpaceId: string;
    executionId: string;
    content: string;
    context?: SendMessageContext;
    userId?: string;
    assetIds?: string[];
    modelTier?: string;
}
export declare const SendMessageRequest: S.Schema<SendMessageRequest>;
export interface SendMessageResponseCreatedEvent {
    responseId?: string;
    sequenceNumber?: number;
}
export declare const SendMessageResponseCreatedEvent: S.Schema<SendMessageResponseCreatedEvent>;
export interface SendMessageResponseInProgressEvent {
    responseId?: string;
    sequenceNumber?: number;
}
export declare const SendMessageResponseInProgressEvent: S.Schema<SendMessageResponseInProgressEvent>;
export interface SendMessageUsageInfo {
    inputTokens?: number;
    outputTokens?: number;
    totalTokens?: number;
}
export declare const SendMessageUsageInfo: S.Schema<SendMessageUsageInfo>;
export interface SendMessageResponseCompletedEvent {
    responseId?: string;
    usage?: SendMessageUsageInfo;
    sequenceNumber?: number;
}
export declare const SendMessageResponseCompletedEvent: S.Schema<SendMessageResponseCompletedEvent>;
export interface SendMessageResponseFailedEvent {
    responseId?: string;
    errorCode?: string;
    errorMessage?: string;
    sequenceNumber?: number;
}
export declare const SendMessageResponseFailedEvent: S.Schema<SendMessageResponseFailedEvent>;
export interface SendMessageSummaryEvent {
    content?: string;
    sequenceNumber?: number;
}
export declare const SendMessageSummaryEvent: S.Schema<SendMessageSummaryEvent>;
export interface SendMessageHeartbeatEvent {
}
export declare const SendMessageHeartbeatEvent: S.Schema<SendMessageHeartbeatEvent>;
export interface SendMessageContentBlockStartEvent {
    index?: number;
    type?: string;
    id?: string;
    parentId?: string;
    sequenceNumber?: number;
}
export declare const SendMessageContentBlockStartEvent: S.Schema<SendMessageContentBlockStartEvent>;
export interface SendMessageTextDelta {
    text?: string;
}
export declare const SendMessageTextDelta: S.Schema<SendMessageTextDelta>;
export interface SendMessageJsonDelta {
    partialJson?: string;
}
export declare const SendMessageJsonDelta: S.Schema<SendMessageJsonDelta>;
export type SendMessageContentBlockDelta = {
    textDelta: SendMessageTextDelta;
    jsonDelta?: never;
} | {
    textDelta?: never;
    jsonDelta: SendMessageJsonDelta;
};
export declare const SendMessageContentBlockDelta: any;
export interface SendMessageContentBlockDeltaEvent {
    index?: number;
    delta?: SendMessageContentBlockDelta;
    sequenceNumber?: number;
}
export declare const SendMessageContentBlockDeltaEvent: S.Schema<SendMessageContentBlockDeltaEvent>;
export interface SendMessageContentBlockStopEvent {
    index?: number;
    type?: string;
    text?: string;
    last?: boolean;
    sequenceNumber?: number;
}
export declare const SendMessageContentBlockStopEvent: S.Schema<SendMessageContentBlockStopEvent>;
export type SendMessageEvents = {
    responseCreated: SendMessageResponseCreatedEvent;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed?: never;
    summary?: never;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress: SendMessageResponseInProgressEvent;
    responseCompleted?: never;
    responseFailed?: never;
    summary?: never;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted: SendMessageResponseCompletedEvent;
    responseFailed?: never;
    summary?: never;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed: SendMessageResponseFailedEvent;
    summary?: never;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed?: never;
    summary: SendMessageSummaryEvent;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed?: never;
    summary?: never;
    heartbeat: SendMessageHeartbeatEvent;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed?: never;
    summary?: never;
    heartbeat?: never;
    contentBlockStart: SendMessageContentBlockStartEvent;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed?: never;
    summary?: never;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta: SendMessageContentBlockDeltaEvent;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed?: never;
    summary?: never;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop: SendMessageContentBlockStopEvent;
};
export declare const SendMessageEvents: S.Schema<stream.Stream<SendMessageEvents, Error, never>>;
export interface SendMessageResponse {
    events: stream.Stream<SendMessageEvents, Error, never>;
}
export declare const SendMessageResponse: S.Schema<SendMessageResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAgentSpaceInput {
    agentSpaceId: string;
    name?: string;
    description?: string | redacted.Redacted<string>;
    locale?: string;
    preferences?: {
        [key: string]: boolean | undefined;
    };
}
export declare const UpdateAgentSpaceInput: S.Schema<UpdateAgentSpaceInput>;
export interface UpdateAgentSpaceOutput {
    agentSpace: AgentSpace;
}
export declare const UpdateAgentSpaceOutput: S.Schema<UpdateAgentSpaceOutput>;
export type ToolIdentifier = string;
export type ApprovalPinKey = string;
export type ApprovalPinValue = string;
export type ApprovalArgumentPins = {
    [key: string]: string | undefined;
};
export declare const ApprovalArgumentPins: any;
export interface ApprovalPattern {
    tool: string;
    argumentPins: {
        [key: string]: string | undefined;
    };
}
export declare const ApprovalPattern: S.Schema<ApprovalPattern>;
export type ApprovalReason = string;
export interface UpdateApprovalActionRequest {
    agentSpaceId: string;
    approvalId: string;
    action: ApprovalActionType;
    finalPattern?: ApprovalPattern;
    reason?: string;
    ttlSeconds?: number;
    singleUse?: boolean;
}
export declare const UpdateApprovalActionRequest: S.Schema<UpdateApprovalActionRequest>;
export type ApprovalStatus = "PENDING" | "APPROVED" | "REJECTED" | "REVOKED" | "REDEEMED" | (string & {});
export declare const ApprovalStatus: any;
export interface UpdateApprovalActionResponse {
    approvalId: string;
    status: ApprovalStatus;
    expiresAt?: Date;
}
export declare const UpdateApprovalActionResponse: S.Schema<UpdateApprovalActionResponse>;
export interface UpdateAssetRequest {
    agentSpaceId: string;
    assetId: string;
    metadata?: any;
    content?: AssetContent;
    clientToken?: string;
}
export declare const UpdateAssetRequest: S.Schema<UpdateAssetRequest>;
export interface UpdateAssetResponse {
    asset: Asset;
}
export declare const UpdateAssetResponse: S.Schema<UpdateAssetResponse>;
export interface UpdateAssetFileRequest {
    agentSpaceId: string;
    assetId: string;
    path: string;
    content?: AssetFileBody;
    metadata?: any;
    clientToken?: string;
}
export declare const UpdateAssetFileRequest: S.Schema<UpdateAssetFileRequest>;
export interface UpdateAssetFileResponse {
    file: AssetFile;
}
export declare const UpdateAssetFileResponse: S.Schema<UpdateAssetFileResponse>;
export interface UpdateAssociationInput {
    agentSpaceId: string;
    associationId: string;
    configuration: ServiceConfiguration;
    capabilities?: {
        [key: string]: CapabilityConfiguration | undefined;
    };
}
export declare const UpdateAssociationInput: S.Schema<UpdateAssociationInput>;
export interface UpdateAssociationOutput {
    association: Association;
    webhook?: GenericWebhook;
}
export declare const UpdateAssociationOutput: S.Schema<UpdateAssociationOutput>;
export interface UpdateBacklogTaskRequest {
    agentSpaceId: string;
    taskId: string;
    taskStatus?: TaskStatus;
    clientToken?: string;
}
export declare const UpdateBacklogTaskRequest: S.Schema<UpdateBacklogTaskRequest>;
export interface UpdateBacklogTaskResponse {
    task: Task;
}
export declare const UpdateBacklogTaskResponse: S.Schema<UpdateBacklogTaskResponse>;
export interface GoalScheduleInput {
    state: SchedulerState;
}
export declare const GoalScheduleInput: S.Schema<GoalScheduleInput>;
export interface UpdateGoalRequest {
    agentSpaceId: string;
    goalId: string;
    evaluationSchedule?: GoalScheduleInput;
    clientToken?: string;
}
export declare const UpdateGoalRequest: S.Schema<UpdateGoalRequest>;
export interface UpdateGoalResponse {
    goal: Goal;
}
export declare const UpdateGoalResponse: S.Schema<UpdateGoalResponse>;
export interface UpdateOperatorAppIdpConfigInput {
    agentSpaceId: string;
    idpClientSecret?: string | redacted.Redacted<string>;
}
export declare const UpdateOperatorAppIdpConfigInput: S.Schema<UpdateOperatorAppIdpConfigInput>;
export interface UpdateOperatorAppIdpConfigOutput {
    agentSpaceId: string;
    idp: IdpAuthConfiguration;
}
export declare const UpdateOperatorAppIdpConfigOutput: S.Schema<UpdateOperatorAppIdpConfigOutput>;
export interface UpdatePrivateConnectionCertificateInput {
    name: string;
    certificate: string;
}
export declare const UpdatePrivateConnectionCertificateInput: S.Schema<UpdatePrivateConnectionCertificateInput>;
export interface UpdatePrivateConnectionCertificateOutput {
    name: string;
    type: PrivateConnectionType;
    resourceGatewayId?: string;
    hostAddress?: string;
    vpcId?: string;
    resourceConfigurationId?: string;
    status: PrivateConnectionStatus;
    certificateExpiryTime?: Date;
    dnsResolution?: ResourceConfigDnsResolution;
    failureMessage?: string;
}
export declare const UpdatePrivateConnectionCertificateOutput: S.Schema<UpdatePrivateConnectionCertificateOutput>;
export interface UpdateRecommendationRequest {
    agentSpaceId: string;
    recommendationId: string;
    status?: RecommendationStatus;
    additionalContext?: string;
    clientToken?: string;
}
export declare const UpdateRecommendationRequest: S.Schema<UpdateRecommendationRequest>;
export interface UpdateRecommendationResponse {
    recommendation: Recommendation;
}
export declare const UpdateRecommendationResponse: S.Schema<UpdateRecommendationResponse>;
export interface UpdateTriggerRequest {
    agentSpaceId: string;
    triggerId: string;
    status?: string;
    clientToken?: string;
}
export declare const UpdateTriggerRequest: S.Schema<UpdateTriggerRequest>;
export interface UpdateTriggerResponse {
    trigger: Trigger;
}
export declare const UpdateTriggerResponse: S.Schema<UpdateTriggerResponse>;
export interface ValidateAwsAssociationsInput {
    agentSpaceId: string;
}
export declare const ValidateAwsAssociationsInput: S.Schema<ValidateAwsAssociationsInput>;
export interface ValidateAwsAssociationsOutput {
}
export declare const ValidateAwsAssociationsOutput: S.Schema<ValidateAwsAssociationsOutput>;
export interface ValidationExceptionField {
    path: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type AssociateServiceError = ConflictException | InternalServerException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a specific service association to an AgentSpace. It overwrites the existing association of the same service. Returns 201 Created on success.
 */
export declare const associateService: API.OperationMethod<AssociateServiceInput, AssociateServiceOutput, AssociateServiceError, Credentials | HttpClient.HttpClient>;
export type CreateAgentSpaceError = ConflictException | InternalServerException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new AgentSpace with the specified name and description. Duplicate space names are allowed.
 */
export declare const createAgentSpace: API.OperationMethod<CreateAgentSpaceInput, CreateAgentSpaceOutput, CreateAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type CreateAssetError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new asset in the specified agent space
 */
export declare const createAsset: API.OperationMethod<CreateAssetRequest, CreateAssetResponse, CreateAssetError, Credentials | HttpClient.HttpClient>;
export type CreateAssetFileError = AccessDeniedException | ConflictException | ContentSizeExceededException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a file in an asset
 */
export declare const createAssetFile: API.OperationMethod<CreateAssetFileRequest, CreateAssetFileResponse, CreateAssetFileError, Credentials | HttpClient.HttpClient>;
export type CreateBacklogTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new backlog task in the specified agent space
 */
export declare const createBacklogTask: API.OperationMethod<CreateBacklogTaskRequest, CreateBacklogTaskResponse, CreateBacklogTaskError, Credentials | HttpClient.HttpClient>;
export type CreateChatError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new chat execution in the specified agent space
 */
export declare const createChat: API.OperationMethod<CreateChatRequest, CreateChatResponse, CreateChatError, Credentials | HttpClient.HttpClient>;
export type CreatePrivateConnectionError = AccessDeniedException | InternalServerException | InvalidParameterException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Private Connection to a target resource.
 */
export declare const createPrivateConnection: API.OperationMethod<CreatePrivateConnectionInput, CreatePrivateConnectionOutput, CreatePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateTriggerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Trigger in the specified agent space
 */
export declare const createTrigger: API.OperationMethod<CreateTriggerRequest, CreateTriggerResponse, CreateTriggerError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentSpaceError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an AgentSpace. This operation is idempotent and returns a 204 No Content response on success.
 */
export declare const deleteAgentSpace: API.OperationMethod<DeleteAgentSpaceInput, DeleteAgentSpaceOutput, DeleteAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an asset and all its files from the specified agent space
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetRequest, DeleteAssetResponse, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetFileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a file from an asset
 */
export declare const deleteAssetFile: API.OperationMethod<DeleteAssetFileRequest, DeleteAssetFileResponse, DeleteAssetFileError, Credentials | HttpClient.HttpClient>;
export type DeletePrivateConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Private Connection. The deletion is asynchronous and returns DELETE_IN_PROGRESS status.
 */
export declare const deletePrivateConnection: API.OperationMethod<DeletePrivateConnectionInput, DeletePrivateConnectionOutput, DeletePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteTriggerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Trigger from the specified agent space
 */
export declare const deleteTrigger: API.OperationMethod<DeleteTriggerRequest, DeleteTriggerResponse, DeleteTriggerError, Credentials | HttpClient.HttpClient>;
export type DeregisterServiceError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deregister a service
 */
export declare const deregisterService: API.OperationMethod<DeregisterServiceInput, DeregisterServiceOutput, DeregisterServiceError, Credentials | HttpClient.HttpClient>;
export type DescribePrivateConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details of an existing Private Connection.
 */
export declare const describePrivateConnection: API.OperationMethod<DescribePrivateConnectionInput, DescribePrivateConnectionOutput, DescribePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type DisableOperatorAppError = IdentityCenterServiceException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disable the Operator App for the specified AgentSpace
 */
export declare const disableOperatorApp: API.OperationMethod<DisableOperatorAppInput, DisableOperatorAppResponse, DisableOperatorAppError, Credentials | HttpClient.HttpClient>;
export type DisassociateServiceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specific service association from an AgentSpace. This operation is idempotent and returns a 204 No Content response on success.
 */
export declare const disassociateService: API.OperationMethod<DisassociateServiceInput, DisassociateServiceOutput, DisassociateServiceError, Credentials | HttpClient.HttpClient>;
export type EnableOperatorAppError = IdentityCenterServiceException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enable the Operator App to access the given AgentSpace
 */
export declare const enableOperatorApp: API.OperationMethod<EnableOperatorAppInput, EnableOperatorAppOutput, EnableOperatorAppError, Credentials | HttpClient.HttpClient>;
export type GetAccountUsageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves monthly account usage metrics and limits for the AWS account.
 */
export declare const getAccountUsage: API.OperationMethod<GetAccountUsageInput, GetAccountUsageOutput, GetAccountUsageError, Credentials | HttpClient.HttpClient>;
export type GetAgentSpaceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific AgentSpace.
 */
export declare const getAgentSpace: API.OperationMethod<GetAgentSpaceInput, GetAgentSpaceOutput, GetAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type GetAssetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an asset from the specified agent space
 */
export declare const getAsset: API.OperationMethod<GetAssetRequest, GetAssetResponse, GetAssetError, Credentials | HttpClient.HttpClient>;
export type GetAssetContentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an asset's content as a zip bundle
 */
export declare const getAssetContent: API.OperationMethod<GetAssetContentRequest, GetAssetContentResponse, GetAssetContentError, Credentials | HttpClient.HttpClient>;
export type GetAssetFileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a file from an asset
 */
export declare const getAssetFile: API.OperationMethod<GetAssetFileRequest, GetAssetFileResponse, GetAssetFileError, Credentials | HttpClient.HttpClient>;
export type GetAssociationError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves given associations configured for a specific AgentSpace.
 */
export declare const getAssociation: API.OperationMethod<GetAssociationInput, GetAssociationOutput, GetAssociationError, Credentials | HttpClient.HttpClient>;
export type GetBacklogTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a backlog task for the specified agent space and task id
 */
export declare const getBacklogTask: API.OperationMethod<GetBacklogTaskRequest, GetBacklogTaskResponse, GetBacklogTaskError, Credentials | HttpClient.HttpClient>;
export type GetOperatorAppError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the full auth configuration of operator including any enabled auth flow
 */
export declare const getOperatorApp: API.OperationMethod<GetOperatorAppInput, GetOperatorAppOutput, GetOperatorAppError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a specific recommendation by its ID
 */
export declare const getRecommendation: API.OperationMethod<GetRecommendationRequest, GetRecommendationResponse, GetRecommendationError, Credentials | HttpClient.HttpClient>;
export type GetServiceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves given service by it's unique identifier
 */
export declare const getService: API.OperationMethod<GetServiceInput, GetServiceOutput, GetServiceError, Credentials | HttpClient.HttpClient>;
export type GetTriggerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a Trigger from the specified agent space
 */
export declare const getTrigger: API.OperationMethod<GetTriggerRequest, GetTriggerResponse, GetTriggerError, Credentials | HttpClient.HttpClient>;
export type ListAgentSpacesError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all AgentSpaces with optional pagination.
 */
export declare const listAgentSpaces: API.PaginatedOperationMethod<ListAgentSpacesInput, ListAgentSpacesOutput, ListAgentSpacesError, Credentials | HttpClient.HttpClient, AgentSpace>;
export type ListAssetFilesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists files in an asset
 */
export declare const listAssetFiles: API.PaginatedOperationMethod<ListAssetFilesRequest, ListAssetFilesResponse, ListAssetFilesError, Credentials | HttpClient.HttpClient, AssetFileSummary>;
export type ListAssetsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists assets in the specified agent space
 */
export declare const listAssets: API.PaginatedOperationMethod<ListAssetsRequest, ListAssetsResponse, ListAssetsError, Credentials | HttpClient.HttpClient, Asset>;
export type ListAssetTypesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the supported asset types
 */
export declare const listAssetTypes: API.PaginatedOperationMethod<ListAssetTypesRequest, ListAssetTypesResponse, ListAssetTypesError, Credentials | HttpClient.HttpClient, AssetTypeSummary>;
export type ListAssetVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists versions of an asset in the specified agent space
 */
export declare const listAssetVersions: API.PaginatedOperationMethod<ListAssetVersionsRequest, ListAssetVersionsResponse, ListAssetVersionsError, Credentials | HttpClient.HttpClient, AssetVersionMetadata>;
export type ListAssociationsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all associations for given AgentSpace
 */
export declare const listAssociations: API.PaginatedOperationMethod<ListAssociationsInput, ListAssociationsOutput, ListAssociationsError, Credentials | HttpClient.HttpClient, Association>;
export type ListBacklogTasksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists backlog tasks in the specified agent space with optional filtering and sorting
 */
export declare const listBacklogTasks: API.PaginatedOperationMethod<ListBacklogTasksRequest, ListBacklogTasksResponse, ListBacklogTasksError, Credentials | HttpClient.HttpClient, Task>;
export type ListChatsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of the user's recent chat executions
 */
export declare const listChats: API.OperationMethod<ListChatsRequest, ListChatsResponse, ListChatsError, Credentials | HttpClient.HttpClient>;
export type ListExecutionsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List executions
 */
export declare const listExecutions: API.PaginatedOperationMethod<ListExecutionsRequest, ListExecutionsResponse, ListExecutionsError, Credentials | HttpClient.HttpClient, Execution>;
export type ListGoalsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists goals in the specified agent space with optional filtering
 */
export declare const listGoals: API.PaginatedOperationMethod<ListGoalsRequest, ListGoalsResponse, ListGoalsError, Credentials | HttpClient.HttpClient, Goal>;
export type ListJournalRecordsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List journal records for a specific execution
 */
export declare const listJournalRecords: API.PaginatedOperationMethod<ListJournalRecordsRequest, ListJournalRecordsResponse, ListJournalRecordsError, Credentials | HttpClient.HttpClient, JournalRecord>;
export type ListPendingMessagesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List pending messages for a specific execution.
 */
export declare const listPendingMessages: API.OperationMethod<ListPendingMessagesRequest, ListPendingMessagesResponse, ListPendingMessagesError, Credentials | HttpClient.HttpClient>;
export type ListPrivateConnectionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all Private Connections in the caller's account.
 */
export declare const listPrivateConnections: API.OperationMethod<ListPrivateConnectionsInput, ListPrivateConnectionsOutput, ListPrivateConnectionsError, Credentials | HttpClient.HttpClient>;
export type ListRecommendationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists recommendations for the specified agent space
 */
export declare const listRecommendations: API.OperationMethod<ListRecommendationsRequest, ListRecommendationsResponse, ListRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ListServicesError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List a list of registered service on the account level.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesInput, ListServicesOutput, ListServicesError, Credentials | HttpClient.HttpClient, RegisteredService>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists tags for the specified AWS DevOps Agent resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTriggersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists Triggers in the specified agent space
 */
export declare const listTriggers: API.PaginatedOperationMethod<ListTriggersRequest, ListTriggersResponse, ListTriggersError, Credentials | HttpClient.HttpClient, Trigger>;
export type ListWebhooksError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all webhooks for given Association
 */
export declare const listWebhooks: API.OperationMethod<ListWebhooksInput, ListWebhooksOutput, ListWebhooksError, Credentials | HttpClient.HttpClient>;
export type RegisterServiceError = InternalServerException | InvalidParameterException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This operation registers the specified service
 */
export declare const registerService: API.OperationMethod<RegisterServiceInput, RegisterServiceOutput, RegisterServiceError, Credentials | HttpClient.HttpClient>;
export type SendMessageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends a chat message and streams the response for the specified agent space execution
 */
export declare const sendMessage: API.OperationMethod<SendMessageRequest, SendMessageResponse, SendMessageError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds or overwrites tags for the specified AWS DevOps Agent resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from the specified AWS DevOps Agent resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentSpaceError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the information of an existing AgentSpace.
 */
export declare const updateAgentSpace: API.OperationMethod<UpdateAgentSpaceInput, UpdateAgentSpaceOutput, UpdateAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type UpdateApprovalActionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an approval request with the terminal decision (APPROVED or REJECTED). A single operation handles both verbs via the action enum.
 */
export declare const updateApprovalAction: API.OperationMethod<UpdateApprovalActionRequest, UpdateApprovalActionResponse, UpdateApprovalActionError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an asset in the specified agent space
 */
export declare const updateAsset: API.OperationMethod<UpdateAssetRequest, UpdateAssetResponse, UpdateAssetError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetFileError = AccessDeniedException | ConflictException | ContentSizeExceededException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a file in an asset
 */
export declare const updateAssetFile: API.OperationMethod<UpdateAssetFileRequest, UpdateAssetFileResponse, UpdateAssetFileError, Credentials | HttpClient.HttpClient>;
export type UpdateAssociationError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Partially updates the configuration of an existing service association for an AgentSpace. Present fields are fully replaced; absent fields are left unchanged. Returns 200 OK on success.
 */
export declare const updateAssociation: API.OperationMethod<UpdateAssociationInput, UpdateAssociationOutput, UpdateAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateBacklogTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an existing backlog task.
 */
export declare const updateBacklogTask: API.OperationMethod<UpdateBacklogTaskRequest, UpdateBacklogTaskResponse, UpdateBacklogTaskError, Credentials | HttpClient.HttpClient>;
export type UpdateGoalError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an existing goal
 */
export declare const updateGoal: API.OperationMethod<UpdateGoalRequest, UpdateGoalResponse, UpdateGoalError, Credentials | HttpClient.HttpClient>;
export type UpdateOperatorAppIdpConfigError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the external Identity Provider configuration for the Operator App
 */
export declare const updateOperatorAppIdpConfig: API.OperationMethod<UpdateOperatorAppIdpConfigInput, UpdateOperatorAppIdpConfigOutput, UpdateOperatorAppIdpConfigError, Credentials | HttpClient.HttpClient>;
export type UpdatePrivateConnectionCertificateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the certificate associated with a Private Connection.
 */
export declare const updatePrivateConnectionCertificate: API.OperationMethod<UpdatePrivateConnectionCertificateInput, UpdatePrivateConnectionCertificateOutput, UpdatePrivateConnectionCertificateError, Credentials | HttpClient.HttpClient>;
export type UpdateRecommendationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing recommendation with new content, status, or metadata
 */
export declare const updateRecommendation: API.OperationMethod<UpdateRecommendationRequest, UpdateRecommendationResponse, UpdateRecommendationError, Credentials | HttpClient.HttpClient>;
export type UpdateTriggerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status of an existing Trigger
 */
export declare const updateTrigger: API.OperationMethod<UpdateTriggerRequest, UpdateTriggerResponse, UpdateTriggerError, Credentials | HttpClient.HttpClient>;
export type ValidateAwsAssociationsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Validates an aws association and set status and returns a 204 No Content response on success.
 */
export declare const validateAwsAssociations: API.OperationMethod<ValidateAwsAssociationsInput, ValidateAwsAssociationsOutput, ValidateAwsAssociationsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=devops-agent.d.ts.map