import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const DuplicateReportNameException_base: S.Class<DuplicateReportNameException, S.TaggedStruct<"DuplicateReportNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DuplicateReportNameException extends /*@__PURE__*/ DuplicateReportNameException_base {
}
declare const InternalErrorException_base: S.Class<InternalErrorException, S.TaggedStruct<"InternalErrorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalErrorException extends /*@__PURE__*/ InternalErrorException_base {
}
declare const ReportBucketNotVerified_base: S.Class<ReportBucketNotVerified, S.TaggedStruct<"ReportBucketNotVerified", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ReportBucketNotVerified extends /*@__PURE__*/ ReportBucketNotVerified_base {
}
declare const ReportLimitReachedException_base: S.Class<ReportLimitReachedException, S.TaggedStruct<"ReportLimitReachedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ReportLimitReachedException extends /*@__PURE__*/ ReportLimitReachedException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ReportName = string;
export interface DeleteReportDefinitionRequest {
    ReportName: string;
}
export declare const DeleteReportDefinitionRequest: S.Schema<DeleteReportDefinitionRequest>;
export type DeleteResponseMessage = string;
export interface DeleteReportDefinitionResponse {
    ResponseMessage?: string;
}
export declare const DeleteReportDefinitionResponse: S.Schema<DeleteReportDefinitionResponse>;
export type MaxResults = number;
export interface DescribeReportDefinitionsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeReportDefinitionsRequest: S.Schema<DescribeReportDefinitionsRequest>;
export type TimeUnit = "HOURLY" | "DAILY" | "MONTHLY" | (string & {});
export declare const TimeUnit: any;
export type ReportFormat = "textORcsv" | "Parquet" | (string & {});
export declare const ReportFormat: any;
export type CompressionFormat = "ZIP" | "GZIP" | "Parquet" | (string & {});
export declare const CompressionFormat: any;
export type SchemaElement = "RESOURCES" | "SPLIT_COST_ALLOCATION_DATA" | "MANUAL_DISCOUNT_COMPATIBILITY" | (string & {});
export declare const SchemaElement: any;
export type SchemaElementList = SchemaElement[];
export declare const SchemaElementList: any;
export type S3Bucket = string;
export type S3Prefix = string;
export type AWSRegion = "af-south-1" | "ap-east-1" | "ap-south-1" | "ap-south-2" | "ap-southeast-1" | "ap-southeast-2" | "ap-southeast-3" | "ap-northeast-1" | "ap-northeast-2" | "ap-northeast-3" | "ca-central-1" | "eu-central-1" | "eu-central-2" | "eu-west-1" | "eu-west-2" | "eu-west-3" | "eu-north-1" | "eu-south-1" | "eu-south-2" | "me-central-1" | "me-south-1" | "sa-east-1" | "us-east-1" | "us-east-2" | "us-west-1" | "us-west-2" | "cn-north-1" | "cn-northwest-1" | (string & {});
export declare const AWSRegion: any;
export type AdditionalArtifact = "REDSHIFT" | "QUICKSIGHT" | "ATHENA" | (string & {});
export declare const AdditionalArtifact: any;
export type AdditionalArtifactList = AdditionalArtifact[];
export declare const AdditionalArtifactList: any;
export type RefreshClosedReports = boolean;
export type ReportVersioning = "CREATE_NEW_REPORT" | "OVERWRITE_REPORT" | (string & {});
export declare const ReportVersioning: any;
export type BillingViewArn = string;
export type LastDelivery = string;
export type LastStatus = "SUCCESS" | "ERROR_PERMISSIONS" | "ERROR_NO_BUCKET" | (string & {});
export declare const LastStatus: any;
export interface ReportStatus {
    lastDelivery?: string;
    lastStatus?: LastStatus;
}
export declare const ReportStatus: S.Schema<ReportStatus>;
export interface ReportDefinition {
    ReportName: string;
    TimeUnit: TimeUnit;
    Format: ReportFormat;
    Compression: CompressionFormat;
    AdditionalSchemaElements: SchemaElement[];
    S3Bucket: string;
    S3Prefix: string;
    S3Region: AWSRegion;
    AdditionalArtifacts?: AdditionalArtifact[];
    RefreshClosedReports?: boolean;
    ReportVersioning?: ReportVersioning;
    BillingViewArn?: string;
    ReportStatus?: ReportStatus;
}
export declare const ReportDefinition: S.Schema<ReportDefinition>;
export type ReportDefinitionList = ReportDefinition[];
export declare const ReportDefinitionList: any;
export interface DescribeReportDefinitionsResponse {
    ReportDefinitions?: ReportDefinition[];
    NextToken?: string;
}
export declare const DescribeReportDefinitionsResponse: S.Schema<DescribeReportDefinitionsResponse>;
export interface ListTagsForResourceRequest {
    ReportName: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ModifyReportDefinitionRequest {
    ReportName: string;
    ReportDefinition: ReportDefinition;
}
export declare const ModifyReportDefinitionRequest: S.Schema<ModifyReportDefinitionRequest>;
export interface ModifyReportDefinitionResponse {
}
export declare const ModifyReportDefinitionResponse: S.Schema<ModifyReportDefinitionResponse>;
export interface PutReportDefinitionRequest {
    ReportDefinition: ReportDefinition;
    Tags?: Tag[];
}
export declare const PutReportDefinitionRequest: S.Schema<PutReportDefinitionRequest>;
export interface PutReportDefinitionResponse {
}
export declare const PutReportDefinitionResponse: S.Schema<PutReportDefinitionResponse>;
export interface TagResourceRequest {
    ReportName: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ReportName: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type ErrorMessage = string;
export type DeleteReportDefinitionError = InternalErrorException | ValidationException | CommonErrors;
/**
 * Deletes the specified report. Any tags associated with the report are also
 * deleted.
 */
export declare const deleteReportDefinition: API.OperationMethod<DeleteReportDefinitionRequest, DeleteReportDefinitionResponse, DeleteReportDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeReportDefinitionsError = InternalErrorException | CommonErrors;
/**
 * Lists the Amazon Web Services Cost and Usage Report available to this account.
 */
export declare const describeReportDefinitions: API.PaginatedOperationMethod<DescribeReportDefinitionsRequest, DescribeReportDefinitionsResponse, DescribeReportDefinitionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalErrorException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags associated with the specified report definition.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ModifyReportDefinitionError = InternalErrorException | ValidationException | ReportBucketNotVerified | CommonErrors;
/**
 * Allows you to programmatically update your report preferences.
 */
export declare const modifyReportDefinition: API.OperationMethod<ModifyReportDefinitionRequest, ModifyReportDefinitionResponse, ModifyReportDefinitionError, Credentials | HttpClient.HttpClient>;
export type PutReportDefinitionError = DuplicateReportNameException | InternalErrorException | ReportLimitReachedException | ResourceNotFoundException | ValidationException | ReportBucketNotVerified | CommonErrors;
/**
 * Creates a new report using the description that you provide.
 */
export declare const putReportDefinition: API.OperationMethod<PutReportDefinitionRequest, PutReportDefinitionResponse, PutReportDefinitionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalErrorException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Associates a set of tags with a report definition.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalErrorException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Disassociates a set of tags from a report definition.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cost-and-usage-report-service.d.ts.map