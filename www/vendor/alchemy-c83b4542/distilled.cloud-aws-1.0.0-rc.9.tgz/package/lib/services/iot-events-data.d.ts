import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalFailureException_base: S.Class<InternalFailureException, S.TaggedStruct<"InternalFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type RequestId = string;
export type AlarmModelName = string;
export type KeyValue = string;
export type Note = string;
export interface AcknowledgeAlarmActionRequest {
    requestId: string;
    alarmModelName: string;
    keyValue?: string;
    note?: string;
}
export declare const AcknowledgeAlarmActionRequest: S.Schema<AcknowledgeAlarmActionRequest>;
export type AcknowledgeAlarmActionRequests = AcknowledgeAlarmActionRequest[];
export declare const AcknowledgeAlarmActionRequests: any;
export interface BatchAcknowledgeAlarmRequest {
    acknowledgeActionRequests: AcknowledgeAlarmActionRequest[];
}
export declare const BatchAcknowledgeAlarmRequest: S.Schema<BatchAcknowledgeAlarmRequest>;
export type ErrorCode = "ResourceNotFoundException" | "InvalidRequestException" | "InternalFailureException" | "ServiceUnavailableException" | "ThrottlingException" | (string & {});
export declare const ErrorCode: any;
export type ErrorMessage = string;
export interface BatchAlarmActionErrorEntry {
    requestId?: string;
    errorCode?: ErrorCode;
    errorMessage?: string;
}
export declare const BatchAlarmActionErrorEntry: S.Schema<BatchAlarmActionErrorEntry>;
export type BatchAlarmActionErrorEntries = BatchAlarmActionErrorEntry[];
export declare const BatchAlarmActionErrorEntries: any;
export interface BatchAcknowledgeAlarmResponse {
    errorEntries?: BatchAlarmActionErrorEntry[];
}
export declare const BatchAcknowledgeAlarmResponse: S.Schema<BatchAcknowledgeAlarmResponse>;
export type MessageId = string;
export type DetectorModelName = string;
export interface DeleteDetectorRequest {
    messageId: string;
    detectorModelName: string;
    keyValue?: string;
}
export declare const DeleteDetectorRequest: S.Schema<DeleteDetectorRequest>;
export type DeleteDetectorRequests = DeleteDetectorRequest[];
export declare const DeleteDetectorRequests: any;
export interface BatchDeleteDetectorRequest {
    detectors: DeleteDetectorRequest[];
}
export declare const BatchDeleteDetectorRequest: S.Schema<BatchDeleteDetectorRequest>;
export interface BatchDeleteDetectorErrorEntry {
    messageId?: string;
    errorCode?: ErrorCode;
    errorMessage?: string;
}
export declare const BatchDeleteDetectorErrorEntry: S.Schema<BatchDeleteDetectorErrorEntry>;
export type BatchDeleteDetectorErrorEntries = BatchDeleteDetectorErrorEntry[];
export declare const BatchDeleteDetectorErrorEntries: any;
export interface BatchDeleteDetectorResponse {
    batchDeleteDetectorErrorEntries?: BatchDeleteDetectorErrorEntry[];
}
export declare const BatchDeleteDetectorResponse: S.Schema<BatchDeleteDetectorResponse>;
export interface DisableAlarmActionRequest {
    requestId: string;
    alarmModelName: string;
    keyValue?: string;
    note?: string;
}
export declare const DisableAlarmActionRequest: S.Schema<DisableAlarmActionRequest>;
export type DisableAlarmActionRequests = DisableAlarmActionRequest[];
export declare const DisableAlarmActionRequests: any;
export interface BatchDisableAlarmRequest {
    disableActionRequests: DisableAlarmActionRequest[];
}
export declare const BatchDisableAlarmRequest: S.Schema<BatchDisableAlarmRequest>;
export interface BatchDisableAlarmResponse {
    errorEntries?: BatchAlarmActionErrorEntry[];
}
export declare const BatchDisableAlarmResponse: S.Schema<BatchDisableAlarmResponse>;
export interface EnableAlarmActionRequest {
    requestId: string;
    alarmModelName: string;
    keyValue?: string;
    note?: string;
}
export declare const EnableAlarmActionRequest: S.Schema<EnableAlarmActionRequest>;
export type EnableAlarmActionRequests = EnableAlarmActionRequest[];
export declare const EnableAlarmActionRequests: any;
export interface BatchEnableAlarmRequest {
    enableActionRequests: EnableAlarmActionRequest[];
}
export declare const BatchEnableAlarmRequest: S.Schema<BatchEnableAlarmRequest>;
export interface BatchEnableAlarmResponse {
    errorEntries?: BatchAlarmActionErrorEntry[];
}
export declare const BatchEnableAlarmResponse: S.Schema<BatchEnableAlarmResponse>;
export type EphemeralInputName = string;
export type Payload = Uint8Array;
export type EpochMilliTimestamp = number;
export interface TimestampValue {
    timeInMillis?: number;
}
export declare const TimestampValue: S.Schema<TimestampValue>;
export interface Message {
    messageId: string;
    inputName: string;
    payload: Uint8Array;
    timestamp?: TimestampValue;
}
export declare const Message: S.Schema<Message>;
export type Messages = Message[];
export declare const Messages: any;
export interface BatchPutMessageRequest {
    messages: Message[];
}
export declare const BatchPutMessageRequest: S.Schema<BatchPutMessageRequest>;
export interface BatchPutMessageErrorEntry {
    messageId?: string;
    errorCode?: ErrorCode;
    errorMessage?: string;
}
export declare const BatchPutMessageErrorEntry: S.Schema<BatchPutMessageErrorEntry>;
export type BatchPutMessageErrorEntries = BatchPutMessageErrorEntry[];
export declare const BatchPutMessageErrorEntries: any;
export interface BatchPutMessageResponse {
    BatchPutMessageErrorEntries?: BatchPutMessageErrorEntry[];
}
export declare const BatchPutMessageResponse: S.Schema<BatchPutMessageResponse>;
export interface ResetAlarmActionRequest {
    requestId: string;
    alarmModelName: string;
    keyValue?: string;
    note?: string;
}
export declare const ResetAlarmActionRequest: S.Schema<ResetAlarmActionRequest>;
export type ResetAlarmActionRequests = ResetAlarmActionRequest[];
export declare const ResetAlarmActionRequests: any;
export interface BatchResetAlarmRequest {
    resetActionRequests: ResetAlarmActionRequest[];
}
export declare const BatchResetAlarmRequest: S.Schema<BatchResetAlarmRequest>;
export interface BatchResetAlarmResponse {
    errorEntries?: BatchAlarmActionErrorEntry[];
}
export declare const BatchResetAlarmResponse: S.Schema<BatchResetAlarmResponse>;
export type SnoozeDuration = number;
export interface SnoozeAlarmActionRequest {
    requestId: string;
    alarmModelName: string;
    keyValue?: string;
    note?: string;
    snoozeDuration: number;
}
export declare const SnoozeAlarmActionRequest: S.Schema<SnoozeAlarmActionRequest>;
export type SnoozeAlarmActionRequests = SnoozeAlarmActionRequest[];
export declare const SnoozeAlarmActionRequests: any;
export interface BatchSnoozeAlarmRequest {
    snoozeActionRequests: SnoozeAlarmActionRequest[];
}
export declare const BatchSnoozeAlarmRequest: S.Schema<BatchSnoozeAlarmRequest>;
export interface BatchSnoozeAlarmResponse {
    errorEntries?: BatchAlarmActionErrorEntry[];
}
export declare const BatchSnoozeAlarmResponse: S.Schema<BatchSnoozeAlarmResponse>;
export type StateName = string;
export type VariableName = string;
export type VariableValue = string;
export interface VariableDefinition {
    name: string;
    value: string;
}
export declare const VariableDefinition: S.Schema<VariableDefinition>;
export type VariableDefinitions = VariableDefinition[];
export declare const VariableDefinitions: any;
export type TimerName = string;
export type Seconds = number;
export interface TimerDefinition {
    name: string;
    seconds: number;
}
export declare const TimerDefinition: S.Schema<TimerDefinition>;
export type TimerDefinitions = TimerDefinition[];
export declare const TimerDefinitions: any;
export interface DetectorStateDefinition {
    stateName: string;
    variables: VariableDefinition[];
    timers: TimerDefinition[];
}
export declare const DetectorStateDefinition: S.Schema<DetectorStateDefinition>;
export interface UpdateDetectorRequest {
    messageId: string;
    detectorModelName: string;
    keyValue?: string;
    state: DetectorStateDefinition;
}
export declare const UpdateDetectorRequest: S.Schema<UpdateDetectorRequest>;
export type UpdateDetectorRequests = UpdateDetectorRequest[];
export declare const UpdateDetectorRequests: any;
export interface BatchUpdateDetectorRequest {
    detectors: UpdateDetectorRequest[];
}
export declare const BatchUpdateDetectorRequest: S.Schema<BatchUpdateDetectorRequest>;
export interface BatchUpdateDetectorErrorEntry {
    messageId?: string;
    errorCode?: ErrorCode;
    errorMessage?: string;
}
export declare const BatchUpdateDetectorErrorEntry: S.Schema<BatchUpdateDetectorErrorEntry>;
export type BatchUpdateDetectorErrorEntries = BatchUpdateDetectorErrorEntry[];
export declare const BatchUpdateDetectorErrorEntries: any;
export interface BatchUpdateDetectorResponse {
    batchUpdateDetectorErrorEntries?: BatchUpdateDetectorErrorEntry[];
}
export declare const BatchUpdateDetectorResponse: S.Schema<BatchUpdateDetectorResponse>;
export interface DescribeAlarmRequest {
    alarmModelName: string;
    keyValue?: string;
}
export declare const DescribeAlarmRequest: S.Schema<DescribeAlarmRequest>;
export type AlarmModelVersion = string;
export type AlarmStateName = "DISABLED" | "NORMAL" | "ACTIVE" | "ACKNOWLEDGED" | "SNOOZE_DISABLED" | "LATCHED" | (string & {});
export declare const AlarmStateName: any;
export type InputPropertyValue = string;
export type ComparisonOperator = "GREATER" | "GREATER_OR_EQUAL" | "LESS" | "LESS_OR_EQUAL" | "EQUAL" | "NOT_EQUAL" | (string & {});
export declare const ComparisonOperator: any;
export type ThresholdValue = string;
export interface SimpleRuleEvaluation {
    inputPropertyValue?: string;
    operator?: ComparisonOperator;
    thresholdValue?: string;
}
export declare const SimpleRuleEvaluation: S.Schema<SimpleRuleEvaluation>;
export interface RuleEvaluation {
    simpleRuleEvaluation?: SimpleRuleEvaluation;
}
export declare const RuleEvaluation: S.Schema<RuleEvaluation>;
export type CustomerActionName = "SNOOZE" | "ENABLE" | "DISABLE" | "ACKNOWLEDGE" | "RESET" | (string & {});
export declare const CustomerActionName: any;
export interface SnoozeActionConfiguration {
    snoozeDuration?: number;
    note?: string;
}
export declare const SnoozeActionConfiguration: S.Schema<SnoozeActionConfiguration>;
export interface EnableActionConfiguration {
    note?: string;
}
export declare const EnableActionConfiguration: S.Schema<EnableActionConfiguration>;
export interface DisableActionConfiguration {
    note?: string;
}
export declare const DisableActionConfiguration: S.Schema<DisableActionConfiguration>;
export interface AcknowledgeActionConfiguration {
    note?: string;
}
export declare const AcknowledgeActionConfiguration: S.Schema<AcknowledgeActionConfiguration>;
export interface ResetActionConfiguration {
    note?: string;
}
export declare const ResetActionConfiguration: S.Schema<ResetActionConfiguration>;
export interface CustomerAction {
    actionName?: CustomerActionName;
    snoozeActionConfiguration?: SnoozeActionConfiguration;
    enableActionConfiguration?: EnableActionConfiguration;
    disableActionConfiguration?: DisableActionConfiguration;
    acknowledgeActionConfiguration?: AcknowledgeActionConfiguration;
    resetActionConfiguration?: ResetActionConfiguration;
}
export declare const CustomerAction: S.Schema<CustomerAction>;
export type EventType = "STATE_CHANGE" | (string & {});
export declare const EventType: any;
export type TriggerType = "SNOOZE_TIMEOUT" | (string & {});
export declare const TriggerType: any;
export interface StateChangeConfiguration {
    triggerType?: TriggerType;
}
export declare const StateChangeConfiguration: S.Schema<StateChangeConfiguration>;
export interface SystemEvent {
    eventType?: EventType;
    stateChangeConfiguration?: StateChangeConfiguration;
}
export declare const SystemEvent: S.Schema<SystemEvent>;
export interface AlarmState {
    stateName?: AlarmStateName;
    ruleEvaluation?: RuleEvaluation;
    customerAction?: CustomerAction;
    systemEvent?: SystemEvent;
}
export declare const AlarmState: S.Schema<AlarmState>;
export type Severity = number;
export interface Alarm {
    alarmModelName?: string;
    alarmModelVersion?: string;
    keyValue?: string;
    alarmState?: AlarmState;
    severity?: number;
    creationTime?: Date;
    lastUpdateTime?: Date;
}
export declare const Alarm: S.Schema<Alarm>;
export interface DescribeAlarmResponse {
    alarm?: Alarm;
}
export declare const DescribeAlarmResponse: S.Schema<DescribeAlarmResponse>;
export interface DescribeDetectorRequest {
    detectorModelName: string;
    keyValue?: string;
}
export declare const DescribeDetectorRequest: S.Schema<DescribeDetectorRequest>;
export type DetectorModelVersion = string;
export interface Variable {
    name: string;
    value: string;
}
export declare const Variable: S.Schema<Variable>;
export type Variables = Variable[];
export declare const Variables: any;
export interface Timer {
    name: string;
    timestamp: Date;
}
export declare const Timer: S.Schema<Timer>;
export type Timers = Timer[];
export declare const Timers: any;
export interface DetectorState {
    stateName: string;
    variables: Variable[];
    timers: Timer[];
}
export declare const DetectorState: S.Schema<DetectorState>;
export interface Detector {
    detectorModelName?: string;
    keyValue?: string;
    detectorModelVersion?: string;
    state?: DetectorState;
    creationTime?: Date;
    lastUpdateTime?: Date;
}
export declare const Detector: S.Schema<Detector>;
export interface DescribeDetectorResponse {
    detector?: Detector;
}
export declare const DescribeDetectorResponse: S.Schema<DescribeDetectorResponse>;
export type NextToken = string;
export type MaxResults = number;
export interface ListAlarmsRequest {
    alarmModelName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAlarmsRequest: S.Schema<ListAlarmsRequest>;
export interface AlarmSummary {
    alarmModelName?: string;
    alarmModelVersion?: string;
    keyValue?: string;
    stateName?: AlarmStateName;
    creationTime?: Date;
    lastUpdateTime?: Date;
}
export declare const AlarmSummary: S.Schema<AlarmSummary>;
export type AlarmSummaries = AlarmSummary[];
export declare const AlarmSummaries: any;
export interface ListAlarmsResponse {
    alarmSummaries?: AlarmSummary[];
    nextToken?: string;
}
export declare const ListAlarmsResponse: S.Schema<ListAlarmsResponse>;
export interface ListDetectorsRequest {
    detectorModelName: string;
    stateName?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDetectorsRequest: S.Schema<ListDetectorsRequest>;
export interface DetectorStateSummary {
    stateName?: string;
}
export declare const DetectorStateSummary: S.Schema<DetectorStateSummary>;
export interface DetectorSummary {
    detectorModelName?: string;
    keyValue?: string;
    detectorModelVersion?: string;
    state?: DetectorStateSummary;
    creationTime?: Date;
    lastUpdateTime?: Date;
}
export declare const DetectorSummary: S.Schema<DetectorSummary>;
export type DetectorSummaries = DetectorSummary[];
export declare const DetectorSummaries: any;
export interface ListDetectorsResponse {
    detectorSummaries?: DetectorSummary[];
    nextToken?: string;
}
export declare const ListDetectorsResponse: S.Schema<ListDetectorsResponse>;
export type BatchAcknowledgeAlarmError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Acknowledges one or more alarms. The alarms change to the `ACKNOWLEDGED` state
 * after you acknowledge them.
 */
export declare const batchAcknowledgeAlarm: API.OperationMethod<BatchAcknowledgeAlarmRequest, BatchAcknowledgeAlarmResponse, BatchAcknowledgeAlarmError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteDetectorError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes one or more detectors that were created. When a detector is deleted, its state will be cleared and the detector will be removed from the list of detectors. The deleted detector will no longer appear if referenced in the ListDetectors API call.
 */
export declare const batchDeleteDetector: API.OperationMethod<BatchDeleteDetectorRequest, BatchDeleteDetectorResponse, BatchDeleteDetectorError, Credentials | HttpClient.HttpClient>;
export type BatchDisableAlarmError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Disables one or more alarms. The alarms change to the `DISABLED` state after
 * you disable them.
 */
export declare const batchDisableAlarm: API.OperationMethod<BatchDisableAlarmRequest, BatchDisableAlarmResponse, BatchDisableAlarmError, Credentials | HttpClient.HttpClient>;
export type BatchEnableAlarmError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Enables one or more alarms. The alarms change to the `NORMAL` state after you
 * enable them.
 */
export declare const batchEnableAlarm: API.OperationMethod<BatchEnableAlarmRequest, BatchEnableAlarmResponse, BatchEnableAlarmError, Credentials | HttpClient.HttpClient>;
export type BatchPutMessageError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Sends a set of messages to the IoT Events system. Each message payload is transformed into
 * the input you specify (`"inputName"`) and ingested into any detectors that monitor
 * that input. If multiple messages are sent, the order in which the messages are processed isn't
 * guaranteed. To guarantee ordering, you must send messages one at a time and wait for a
 * successful response.
 */
export declare const batchPutMessage: API.OperationMethod<BatchPutMessageRequest, BatchPutMessageResponse, BatchPutMessageError, Credentials | HttpClient.HttpClient>;
export type BatchResetAlarmError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Resets one or more alarms. The alarms return to the `NORMAL` state after you
 * reset them.
 */
export declare const batchResetAlarm: API.OperationMethod<BatchResetAlarmRequest, BatchResetAlarmResponse, BatchResetAlarmError, Credentials | HttpClient.HttpClient>;
export type BatchSnoozeAlarmError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Changes one or more alarms to the snooze mode. The alarms change to the
 * `SNOOZE_DISABLED` state after you set them to the snooze mode.
 */
export declare const batchSnoozeAlarm: API.OperationMethod<BatchSnoozeAlarmRequest, BatchSnoozeAlarmResponse, BatchSnoozeAlarmError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateDetectorError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates the state, variable values, and timer settings of one or more detectors
 * (instances) of a specified detector model.
 */
export declare const batchUpdateDetector: API.OperationMethod<BatchUpdateDetectorRequest, BatchUpdateDetectorResponse, BatchUpdateDetectorError, Credentials | HttpClient.HttpClient>;
export type DescribeAlarmError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an alarm.
 */
export declare const describeAlarm: API.OperationMethod<DescribeAlarmRequest, DescribeAlarmResponse, DescribeAlarmError, Credentials | HttpClient.HttpClient>;
export type DescribeDetectorError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns information about the specified detector (instance).
 */
export declare const describeDetector: API.OperationMethod<DescribeDetectorRequest, DescribeDetectorResponse, DescribeDetectorError, Credentials | HttpClient.HttpClient>;
export type ListAlarmsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists one or more alarms. The operation returns only the metadata associated with each
 * alarm.
 */
export declare const listAlarms: API.OperationMethod<ListAlarmsRequest, ListAlarmsResponse, ListAlarmsError, Credentials | HttpClient.HttpClient>;
export type ListDetectorsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists detectors (the instances of a detector model).
 */
export declare const listDetectors: API.OperationMethod<ListDetectorsRequest, ListDetectorsResponse, ListDetectorsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iot-events-data.d.ts.map