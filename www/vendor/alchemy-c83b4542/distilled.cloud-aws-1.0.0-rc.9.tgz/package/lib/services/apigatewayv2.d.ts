import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly message: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly LimitType: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type SelectionExpression = string;
export type CorsHeaderList = string[];
export declare const CorsHeaderList: any;
export type StringWithLengthBetween1And64 = string;
export type CorsMethodList = string[];
export declare const CorsMethodList: any;
export type CorsOriginList = string[];
export declare const CorsOriginList: any;
export type IntegerWithLengthBetweenMinus1And86400 = number;
export interface Cors {
    AllowCredentials?: boolean;
    AllowHeaders?: string[];
    AllowMethods?: string[];
    AllowOrigins?: string[];
    ExposeHeaders?: string[];
    MaxAge?: number;
}
export declare const Cors: S.Schema<Cors>;
export type Arn = string;
export type StringWithLengthBetween0And1024 = string;
export type IpAddressType = "ipv4" | "dualstack" | (string & {});
export declare const IpAddressType: any;
export type StringWithLengthBetween1And128 = string;
export type ProtocolType = "WEBSOCKET" | "HTTP" | (string & {});
export declare const ProtocolType: any;
export type SelectionKey = string;
export type StringWithLengthBetween1And1600 = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export type UriWithLengthBetween1And2048 = string;
export interface CreateApiRequest {
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CredentialsArn?: string;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteKey?: string;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Target?: string;
    Version?: string;
}
export declare const CreateApiRequest: S.Schema<CreateApiRequest>;
export type Id = string;
export type __timestampIso8601 = Date;
export type __listOf__string = string[];
export declare const __listOf__string: any;
export interface CreateApiResponse {
    ApiEndpoint?: string;
    ApiGatewayManaged?: boolean;
    ApiId?: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CreatedDate?: Date;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    ImportInfo?: string[];
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Version?: string;
    Warnings?: string[];
}
export declare const CreateApiResponse: S.Schema<CreateApiResponse>;
export interface CreateApiMappingRequest {
    ApiId?: string;
    ApiMappingKey?: string;
    DomainName: string;
    Stage?: string;
}
export declare const CreateApiMappingRequest: S.Schema<CreateApiMappingRequest>;
export interface CreateApiMappingResponse {
    ApiId?: string;
    ApiMappingId?: string;
    ApiMappingKey?: string;
    Stage?: string;
}
export declare const CreateApiMappingResponse: S.Schema<CreateApiMappingResponse>;
export type IntegerWithLengthBetween0And3600 = number;
export type AuthorizerType = "REQUEST" | "JWT" | (string & {});
export declare const AuthorizerType: any;
export type IdentitySourceList = string[];
export declare const IdentitySourceList: any;
export interface JWTConfiguration {
    Audience?: string[];
    Issuer?: string;
}
export declare const JWTConfiguration: S.Schema<JWTConfiguration>;
export interface CreateAuthorizerRequest {
    ApiId: string;
    AuthorizerCredentialsArn?: string;
    AuthorizerPayloadFormatVersion?: string;
    AuthorizerResultTtlInSeconds?: number;
    AuthorizerType?: AuthorizerType;
    AuthorizerUri?: string;
    EnableSimpleResponses?: boolean;
    IdentitySource?: string[];
    IdentityValidationExpression?: string;
    JwtConfiguration?: JWTConfiguration;
    Name?: string;
}
export declare const CreateAuthorizerRequest: S.Schema<CreateAuthorizerRequest>;
export interface CreateAuthorizerResponse {
    AuthorizerCredentialsArn?: string;
    AuthorizerId?: string;
    AuthorizerPayloadFormatVersion?: string;
    AuthorizerResultTtlInSeconds?: number;
    AuthorizerType?: AuthorizerType;
    AuthorizerUri?: string;
    EnableSimpleResponses?: boolean;
    IdentitySource?: string[];
    IdentityValidationExpression?: string;
    JwtConfiguration?: JWTConfiguration;
    Name?: string;
}
export declare const CreateAuthorizerResponse: S.Schema<CreateAuthorizerResponse>;
export interface CreateDeploymentRequest {
    ApiId: string;
    Description?: string;
    StageName?: string;
}
export declare const CreateDeploymentRequest: S.Schema<CreateDeploymentRequest>;
export type DeploymentStatus = "PENDING" | "FAILED" | "DEPLOYED" | (string & {});
export declare const DeploymentStatus: any;
export interface CreateDeploymentResponse {
    AutoDeployed?: boolean;
    CreatedDate?: Date;
    DeploymentId?: string;
    DeploymentStatus?: DeploymentStatus;
    DeploymentStatusMessage?: string;
    Description?: string;
}
export declare const CreateDeploymentResponse: S.Schema<CreateDeploymentResponse>;
export type StringWithLengthBetween1And512 = string;
export type DomainNameStatus = "AVAILABLE" | "UPDATING" | "PENDING_CERTIFICATE_REIMPORT" | "PENDING_OWNERSHIP_VERIFICATION" | (string & {});
export declare const DomainNameStatus: any;
export type EndpointType = "REGIONAL" | "EDGE" | (string & {});
export declare const EndpointType: any;
export type SecurityPolicy = "TLS_1_0" | "TLS_1_2" | (string & {});
export declare const SecurityPolicy: any;
export interface DomainNameConfiguration {
    ApiGatewayDomainName?: string;
    CertificateArn?: string;
    CertificateName?: string;
    CertificateUploadDate?: Date;
    DomainNameStatus?: DomainNameStatus;
    DomainNameStatusMessage?: string;
    EndpointType?: EndpointType;
    HostedZoneId?: string;
    IpAddressType?: IpAddressType;
    SecurityPolicy?: SecurityPolicy;
    OwnershipVerificationCertificateArn?: string;
}
export declare const DomainNameConfiguration: S.Schema<DomainNameConfiguration>;
export type DomainNameConfigurations = DomainNameConfiguration[];
export declare const DomainNameConfigurations: any;
export interface MutualTlsAuthenticationInput {
    TruststoreUri?: string;
    TruststoreVersion?: string;
}
export declare const MutualTlsAuthenticationInput: S.Schema<MutualTlsAuthenticationInput>;
export type RoutingMode = "API_MAPPING_ONLY" | "ROUTING_RULE_ONLY" | "ROUTING_RULE_THEN_API_MAPPING" | (string & {});
export declare const RoutingMode: any;
export interface CreateDomainNameRequest {
    DomainName?: string;
    DomainNameConfigurations?: DomainNameConfiguration[];
    MutualTlsAuthentication?: MutualTlsAuthenticationInput;
    RoutingMode?: RoutingMode;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDomainNameRequest: S.Schema<CreateDomainNameRequest>;
export interface MutualTlsAuthentication {
    TruststoreUri?: string;
    TruststoreVersion?: string;
    TruststoreWarnings?: string[];
}
export declare const MutualTlsAuthentication: S.Schema<MutualTlsAuthentication>;
export interface CreateDomainNameResponse {
    ApiMappingSelectionExpression?: string;
    DomainName?: string;
    DomainNameArn?: string;
    DomainNameConfigurations?: DomainNameConfiguration[];
    MutualTlsAuthentication?: MutualTlsAuthentication;
    RoutingMode?: RoutingMode;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDomainNameResponse: S.Schema<CreateDomainNameResponse>;
export type StringWithLengthBetween1And1024 = string;
export type ConnectionType = "INTERNET" | "VPC_LINK" | (string & {});
export declare const ConnectionType: any;
export type ContentHandlingStrategy = "CONVERT_TO_BINARY" | "CONVERT_TO_TEXT" | (string & {});
export declare const ContentHandlingStrategy: any;
export type IntegrationType = "AWS" | "HTTP" | "MOCK" | "HTTP_PROXY" | "AWS_PROXY" | (string & {});
export declare const IntegrationType: any;
export type PassthroughBehavior = "WHEN_NO_MATCH" | "NEVER" | "WHEN_NO_TEMPLATES" | (string & {});
export declare const PassthroughBehavior: any;
export type IntegrationParameters = {
    [key: string]: string | undefined;
};
export declare const IntegrationParameters: any;
export type StringWithLengthBetween0And32K = string;
export type TemplateMap = {
    [key: string]: string | undefined;
};
export declare const TemplateMap: any;
export type ResponseParameters = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export declare const ResponseParameters: any;
export type IntegerWithLengthBetween50And30000 = number;
export interface TlsConfigInput {
    ServerNameToVerify?: string;
}
export declare const TlsConfigInput: S.Schema<TlsConfigInput>;
export interface CreateIntegrationRequest {
    ApiId: string;
    ConnectionId?: string;
    ConnectionType?: ConnectionType;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    CredentialsArn?: string;
    Description?: string;
    IntegrationMethod?: string;
    IntegrationSubtype?: string;
    IntegrationType?: IntegrationType;
    IntegrationUri?: string;
    PassthroughBehavior?: PassthroughBehavior;
    PayloadFormatVersion?: string;
    RequestParameters?: {
        [key: string]: string | undefined;
    };
    RequestTemplates?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    TemplateSelectionExpression?: string;
    TimeoutInMillis?: number;
    TlsConfig?: TlsConfigInput;
}
export declare const CreateIntegrationRequest: S.Schema<CreateIntegrationRequest>;
export interface TlsConfig {
    ServerNameToVerify?: string;
}
export declare const TlsConfig: S.Schema<TlsConfig>;
export interface CreateIntegrationResult {
    ApiGatewayManaged?: boolean;
    ConnectionId?: string;
    ConnectionType?: ConnectionType;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    CredentialsArn?: string;
    Description?: string;
    IntegrationId?: string;
    IntegrationMethod?: string;
    IntegrationResponseSelectionExpression?: string;
    IntegrationSubtype?: string;
    IntegrationType?: IntegrationType;
    IntegrationUri?: string;
    PassthroughBehavior?: PassthroughBehavior;
    PayloadFormatVersion?: string;
    RequestParameters?: {
        [key: string]: string | undefined;
    };
    RequestTemplates?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    TemplateSelectionExpression?: string;
    TimeoutInMillis?: number;
    TlsConfig?: TlsConfig;
}
export declare const CreateIntegrationResult: S.Schema<CreateIntegrationResult>;
export interface CreateIntegrationResponseRequest {
    ApiId: string;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    IntegrationId: string;
    IntegrationResponseKey?: string;
    ResponseParameters?: {
        [key: string]: string | undefined;
    };
    ResponseTemplates?: {
        [key: string]: string | undefined;
    };
    TemplateSelectionExpression?: string;
}
export declare const CreateIntegrationResponseRequest: S.Schema<CreateIntegrationResponseRequest>;
export interface CreateIntegrationResponseResponse {
    ContentHandlingStrategy?: ContentHandlingStrategy;
    IntegrationResponseId?: string;
    IntegrationResponseKey?: string;
    ResponseParameters?: {
        [key: string]: string | undefined;
    };
    ResponseTemplates?: {
        [key: string]: string | undefined;
    };
    TemplateSelectionExpression?: string;
}
export declare const CreateIntegrationResponseResponse: S.Schema<CreateIntegrationResponseResponse>;
export type StringWithLengthBetween1And256 = string;
export interface CreateModelRequest {
    ApiId: string;
    ContentType?: string;
    Description?: string;
    Name?: string;
    Schema?: string;
}
export declare const CreateModelRequest: S.Schema<CreateModelRequest>;
export interface CreateModelResponse {
    ContentType?: string;
    Description?: string;
    ModelId?: string;
    Name?: string;
    Schema?: string;
}
export declare const CreateModelResponse: S.Schema<CreateModelResponse>;
export type __stringMin1Max256 = string;
export type __stringMin20Max2048 = string;
export interface CognitoConfig {
    AppClientId?: string;
    UserPoolArn?: string;
    UserPoolDomain?: string;
}
export declare const CognitoConfig: S.Schema<CognitoConfig>;
export interface None {
}
export declare const None: S.Schema<None>;
export interface Authorization {
    CognitoConfig?: CognitoConfig;
    None?: None;
}
export declare const Authorization: S.Schema<Authorization>;
export type __stringMin10Max2048 = string;
export type __stringMin3Max256 = string;
export interface ACMManaged {
    CertificateArn?: string;
    DomainName?: string;
}
export declare const ACMManaged: S.Schema<ACMManaged>;
export interface EndpointConfigurationRequest {
    AcmManaged?: ACMManaged;
    None?: None;
}
export declare const EndpointConfigurationRequest: S.Schema<EndpointConfigurationRequest>;
export type __listOf__stringMin20Max2048 = string[];
export declare const __listOf__stringMin20Max2048: any;
export type __stringMin0Max1092 = string;
export type __stringMin0Max1024 = string;
export type __stringMin3Max255 = string;
export type __stringMin1Max16 = string;
export interface CustomColors {
    AccentColor?: string;
    BackgroundColor?: string;
    ErrorValidationColor?: string;
    HeaderColor?: string;
    NavigationColor?: string;
    TextColor?: string;
}
export declare const CustomColors: S.Schema<CustomColors>;
export interface PortalTheme {
    CustomColors?: CustomColors;
    LogoLastUploaded?: Date;
}
export declare const PortalTheme: S.Schema<PortalTheme>;
export interface PortalContent {
    Description?: string;
    DisplayName?: string;
    Theme?: PortalTheme;
}
export declare const PortalContent: S.Schema<PortalContent>;
export type __stringMin0Max255 = string;
export interface CreatePortalRequest {
    Authorization?: Authorization;
    EndpointConfiguration?: EndpointConfigurationRequest;
    IncludedPortalProductArns?: string[];
    LogoUri?: string;
    PortalContent?: PortalContent;
    RumAppMonitorName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePortalRequest: S.Schema<CreatePortalRequest>;
export type __stringMin1Max64 = string;
export interface EndpointConfigurationResponse {
    CertificateArn?: string;
    DomainName?: string;
    PortalDefaultDomainName?: string;
    PortalDomainHostedZoneId?: string;
}
export declare const EndpointConfigurationResponse: S.Schema<EndpointConfigurationResponse>;
export type __stringMin10Max30PatternAZ09 = string;
export type PublishStatus = "PUBLISHED" | "PUBLISH_IN_PROGRESS" | "PUBLISH_FAILED" | "DISABLE_IN_PROGRESS" | "DISABLE_FAILED" | "DISABLED" | (string & {});
export declare const PublishStatus: any;
export type __stringMin1Max2048 = string;
export interface StatusException {
    Exception?: string;
    Message?: string;
}
export declare const StatusException: S.Schema<StatusException>;
export interface CreatePortalResponse {
    Authorization?: Authorization & {
        CognitoConfig: CognitoConfig & {
            AppClientId: __stringMin1Max256;
            UserPoolArn: __stringMin20Max2048;
            UserPoolDomain: __stringMin20Max2048;
        };
    };
    EndpointConfiguration?: EndpointConfigurationResponse & {
        PortalDefaultDomainName: __stringMin3Max256;
        PortalDomainHostedZoneId: __stringMin1Max64;
    };
    IncludedPortalProductArns?: string[];
    LastModified?: Date;
    LastPublished?: Date;
    LastPublishedDescription?: string;
    PortalArn?: string;
    PortalContent?: PortalContent & {
        DisplayName: __stringMin3Max255;
        Theme: PortalTheme & {
            CustomColors: CustomColors & {
                AccentColor: __stringMin1Max16;
                BackgroundColor: __stringMin1Max16;
                ErrorValidationColor: __stringMin1Max16;
                HeaderColor: __stringMin1Max16;
                NavigationColor: __stringMin1Max16;
                TextColor: __stringMin1Max16;
            };
        };
    };
    PortalId?: string;
    PublishStatus?: PublishStatus;
    RumAppMonitorName?: string;
    StatusException?: StatusException;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePortalResponse: S.Schema<CreatePortalResponse>;
export type __stringMin1Max255 = string;
export interface CreatePortalProductRequest {
    Description?: string;
    DisplayName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePortalProductRequest: S.Schema<CreatePortalProductRequest>;
export interface Section {
    ProductRestEndpointPageArns?: string[];
    SectionName?: string;
}
export declare const Section: S.Schema<Section>;
export type __listOfSection = Section[];
export declare const __listOfSection: any;
export interface DisplayOrder {
    Contents?: Section[];
    OverviewPageArn?: string;
    ProductPageArns?: string[];
}
export declare const DisplayOrder: S.Schema<DisplayOrder>;
export interface CreatePortalProductResponse {
    Description?: string;
    DisplayName?: string;
    DisplayOrder?: DisplayOrder & {
        Contents: (Section & {
            ProductRestEndpointPageArns: __listOf__stringMin20Max2048;
            SectionName: string;
        })[];
    };
    LastModified?: Date;
    PortalProductArn?: string;
    PortalProductId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePortalProductResponse: S.Schema<CreatePortalProductResponse>;
export type __stringMin1Max32768 = string;
export interface DisplayContent {
    Body?: string;
    Title?: string;
}
export declare const DisplayContent: S.Schema<DisplayContent>;
export interface CreateProductPageRequest {
    DisplayContent?: DisplayContent;
    PortalProductId: string;
}
export declare const CreateProductPageRequest: S.Schema<CreateProductPageRequest>;
export interface CreateProductPageResponse {
    DisplayContent?: DisplayContent & {
        Body: __stringMin1Max32768;
        Title: __stringMin1Max255;
    };
    LastModified?: Date;
    ProductPageArn?: string;
    ProductPageId?: string;
}
export declare const CreateProductPageResponse: S.Schema<CreateProductPageResponse>;
export type __stringMin1Max1024 = string;
export interface DisplayContentOverrides {
    Body?: string;
    Endpoint?: string;
    OperationName?: string;
}
export declare const DisplayContentOverrides: S.Schema<DisplayContentOverrides>;
export interface EndpointDisplayContent {
    None?: None;
    Overrides?: DisplayContentOverrides;
}
export declare const EndpointDisplayContent: S.Schema<EndpointDisplayContent>;
export type __stringMin1Max20 = string;
export type __stringMin1Max4096 = string;
export type __stringMin1Max50 = string;
export type __stringMin1Max128 = string;
export interface IdentifierParts {
    Method?: string;
    Path?: string;
    RestApiId?: string;
    Stage?: string;
}
export declare const IdentifierParts: S.Schema<IdentifierParts>;
export interface RestEndpointIdentifier {
    IdentifierParts?: IdentifierParts;
}
export declare const RestEndpointIdentifier: S.Schema<RestEndpointIdentifier>;
export type TryItState = "ENABLED" | "DISABLED" | (string & {});
export declare const TryItState: any;
export interface CreateProductRestEndpointPageRequest {
    DisplayContent?: EndpointDisplayContent;
    PortalProductId: string;
    RestEndpointIdentifier?: RestEndpointIdentifier;
    TryItState?: TryItState;
}
export declare const CreateProductRestEndpointPageRequest: S.Schema<CreateProductRestEndpointPageRequest>;
export interface EndpointDisplayContentResponse {
    Body?: string;
    Endpoint?: string;
    OperationName?: string;
}
export declare const EndpointDisplayContentResponse: S.Schema<EndpointDisplayContentResponse>;
export type Status = "AVAILABLE" | "IN_PROGRESS" | "FAILED" | (string & {});
export declare const Status: any;
export interface CreateProductRestEndpointPageResponse {
    DisplayContent?: EndpointDisplayContentResponse & {
        Endpoint: __stringMin1Max1024;
    };
    LastModified?: Date;
    ProductRestEndpointPageArn?: string;
    ProductRestEndpointPageId?: string;
    RestEndpointIdentifier?: RestEndpointIdentifier & {
        IdentifierParts: IdentifierParts & {
            Method: __stringMin1Max20;
            Path: __stringMin1Max4096;
            RestApiId: __stringMin1Max50;
            Stage: __stringMin1Max128;
        };
    };
    Status?: Status;
    StatusException?: StatusException;
    TryItState?: TryItState;
}
export declare const CreateProductRestEndpointPageResponse: S.Schema<CreateProductRestEndpointPageResponse>;
export type AuthorizationScopes = string[];
export declare const AuthorizationScopes: any;
export type AuthorizationType = "NONE" | "AWS_IAM" | "CUSTOM" | "JWT" | (string & {});
export declare const AuthorizationType: any;
export type RouteModels = {
    [key: string]: string | undefined;
};
export declare const RouteModels: any;
export interface ParameterConstraints {
    Required?: boolean;
}
export declare const ParameterConstraints: S.Schema<ParameterConstraints>;
export type RouteParameters = {
    [key: string]: ParameterConstraints | undefined;
};
export declare const RouteParameters: any;
export interface CreateRouteRequest {
    ApiId: string;
    ApiKeyRequired?: boolean;
    AuthorizationScopes?: string[];
    AuthorizationType?: AuthorizationType;
    AuthorizerId?: string;
    ModelSelectionExpression?: string;
    OperationName?: string;
    RequestModels?: {
        [key: string]: string | undefined;
    };
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteKey?: string;
    RouteResponseSelectionExpression?: string;
    Target?: string;
}
export declare const CreateRouteRequest: S.Schema<CreateRouteRequest>;
export interface CreateRouteResult {
    ApiGatewayManaged?: boolean;
    ApiKeyRequired?: boolean;
    AuthorizationScopes?: string[];
    AuthorizationType?: AuthorizationType;
    AuthorizerId?: string;
    ModelSelectionExpression?: string;
    OperationName?: string;
    RequestModels?: {
        [key: string]: string | undefined;
    };
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId?: string;
    RouteKey?: string;
    RouteResponseSelectionExpression?: string;
    Target?: string;
}
export declare const CreateRouteResult: S.Schema<CreateRouteResult>;
export interface CreateRouteResponseRequest {
    ApiId: string;
    ModelSelectionExpression?: string;
    ResponseModels?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId: string;
    RouteResponseKey?: string;
}
export declare const CreateRouteResponseRequest: S.Schema<CreateRouteResponseRequest>;
export interface CreateRouteResponseResponse {
    ModelSelectionExpression?: string;
    ResponseModels?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteResponseId?: string;
    RouteResponseKey?: string;
}
export declare const CreateRouteResponseResponse: S.Schema<CreateRouteResponseResponse>;
export interface RoutingRuleActionInvokeApi {
    ApiId?: string;
    Stage?: string;
    StripBasePath?: boolean;
}
export declare const RoutingRuleActionInvokeApi: S.Schema<RoutingRuleActionInvokeApi>;
export interface RoutingRuleAction {
    InvokeApi?: RoutingRuleActionInvokeApi;
}
export declare const RoutingRuleAction: S.Schema<RoutingRuleAction>;
export type __listOfRoutingRuleAction = RoutingRuleAction[];
export declare const __listOfRoutingRuleAction: any;
export type __listOfSelectionKey = string[];
export declare const __listOfSelectionKey: any;
export interface RoutingRuleMatchBasePaths {
    AnyOf?: string[];
}
export declare const RoutingRuleMatchBasePaths: S.Schema<RoutingRuleMatchBasePaths>;
export interface RoutingRuleMatchHeaderValue {
    Header?: string;
    ValueGlob?: string;
}
export declare const RoutingRuleMatchHeaderValue: S.Schema<RoutingRuleMatchHeaderValue>;
export type __listOfRoutingRuleMatchHeaderValue = RoutingRuleMatchHeaderValue[];
export declare const __listOfRoutingRuleMatchHeaderValue: any;
export interface RoutingRuleMatchHeaders {
    AnyOf?: RoutingRuleMatchHeaderValue[];
}
export declare const RoutingRuleMatchHeaders: S.Schema<RoutingRuleMatchHeaders>;
export interface RoutingRuleCondition {
    MatchBasePaths?: RoutingRuleMatchBasePaths;
    MatchHeaders?: RoutingRuleMatchHeaders;
}
export declare const RoutingRuleCondition: S.Schema<RoutingRuleCondition>;
export type __listOfRoutingRuleCondition = RoutingRuleCondition[];
export declare const __listOfRoutingRuleCondition: any;
export type RoutingRulePriority = number;
export interface CreateRoutingRuleRequest {
    Actions?: RoutingRuleAction[];
    Conditions?: RoutingRuleCondition[];
    DomainName: string;
    DomainNameId?: string;
    Priority?: number;
}
export declare const CreateRoutingRuleRequest: S.Schema<CreateRoutingRuleRequest>;
export interface CreateRoutingRuleResponse {
    Actions?: (RoutingRuleAction & {
        InvokeApi: RoutingRuleActionInvokeApi & {
            ApiId: Id;
            Stage: StringWithLengthBetween1And128;
        };
    })[];
    Conditions?: (RoutingRuleCondition & {
        MatchBasePaths: RoutingRuleMatchBasePaths & {
            AnyOf: __listOfSelectionKey;
        };
        MatchHeaders: RoutingRuleMatchHeaders & {
            AnyOf: (RoutingRuleMatchHeaderValue & {
                Header: SelectionKey;
                ValueGlob: SelectionExpression;
            })[];
        };
    })[];
    Priority?: number;
    RoutingRuleArn?: string;
    RoutingRuleId?: string;
}
export declare const CreateRoutingRuleResponse: S.Schema<CreateRoutingRuleResponse>;
export interface AccessLogSettings {
    DestinationArn?: string;
    Format?: string;
}
export declare const AccessLogSettings: S.Schema<AccessLogSettings>;
export type LoggingLevel = "ERROR" | "INFO" | "OFF" | (string & {});
export declare const LoggingLevel: any;
export interface RouteSettings {
    DataTraceEnabled?: boolean;
    DetailedMetricsEnabled?: boolean;
    LoggingLevel?: LoggingLevel;
    ThrottlingBurstLimit?: number;
    ThrottlingRateLimit?: number;
}
export declare const RouteSettings: S.Schema<RouteSettings>;
export type RouteSettingsMap = {
    [key: string]: RouteSettings | undefined;
};
export declare const RouteSettingsMap: any;
export type StringWithLengthBetween0And2048 = string;
export type StageVariablesMap = {
    [key: string]: string | undefined;
};
export declare const StageVariablesMap: any;
export interface CreateStageRequest {
    AccessLogSettings?: AccessLogSettings;
    ApiId: string;
    AutoDeploy?: boolean;
    ClientCertificateId?: string;
    DefaultRouteSettings?: RouteSettings;
    DeploymentId?: string;
    Description?: string;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    };
    StageName?: string;
    StageVariables?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateStageRequest: S.Schema<CreateStageRequest>;
export interface CreateStageResponse {
    AccessLogSettings?: AccessLogSettings;
    ApiGatewayManaged?: boolean;
    AutoDeploy?: boolean;
    ClientCertificateId?: string;
    CreatedDate?: Date;
    DefaultRouteSettings?: RouteSettings;
    DeploymentId?: string;
    Description?: string;
    LastDeploymentStatusMessage?: string;
    LastUpdatedDate?: Date;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    };
    StageName?: string;
    StageVariables?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateStageResponse: S.Schema<CreateStageResponse>;
export type SecurityGroupIdList = string[];
export declare const SecurityGroupIdList: any;
export type SubnetIdList = string[];
export declare const SubnetIdList: any;
export interface CreateVpcLinkRequest {
    Name?: string;
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateVpcLinkRequest: S.Schema<CreateVpcLinkRequest>;
export type VpcLinkStatus = "PENDING" | "AVAILABLE" | "DELETING" | "FAILED" | "INACTIVE" | (string & {});
export declare const VpcLinkStatus: any;
export type VpcLinkVersion = "V2" | (string & {});
export declare const VpcLinkVersion: any;
export interface CreateVpcLinkResponse {
    CreatedDate?: Date;
    Name?: string;
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
    VpcLinkId?: string;
    VpcLinkStatus?: VpcLinkStatus;
    VpcLinkStatusMessage?: string;
    VpcLinkVersion?: VpcLinkVersion;
}
export declare const CreateVpcLinkResponse: S.Schema<CreateVpcLinkResponse>;
export interface DeleteAccessLogSettingsRequest {
    ApiId: string;
    StageName: string;
}
export declare const DeleteAccessLogSettingsRequest: S.Schema<DeleteAccessLogSettingsRequest>;
export interface DeleteAccessLogSettingsResponse {
}
export declare const DeleteAccessLogSettingsResponse: S.Schema<DeleteAccessLogSettingsResponse>;
export interface DeleteApiRequest {
    ApiId: string;
}
export declare const DeleteApiRequest: S.Schema<DeleteApiRequest>;
export interface DeleteApiResponse {
}
export declare const DeleteApiResponse: S.Schema<DeleteApiResponse>;
export interface DeleteApiMappingRequest {
    ApiMappingId: string;
    DomainName: string;
}
export declare const DeleteApiMappingRequest: S.Schema<DeleteApiMappingRequest>;
export interface DeleteApiMappingResponse {
}
export declare const DeleteApiMappingResponse: S.Schema<DeleteApiMappingResponse>;
export interface DeleteAuthorizerRequest {
    ApiId: string;
    AuthorizerId: string;
}
export declare const DeleteAuthorizerRequest: S.Schema<DeleteAuthorizerRequest>;
export interface DeleteAuthorizerResponse {
}
export declare const DeleteAuthorizerResponse: S.Schema<DeleteAuthorizerResponse>;
export interface DeleteCorsConfigurationRequest {
    ApiId: string;
}
export declare const DeleteCorsConfigurationRequest: S.Schema<DeleteCorsConfigurationRequest>;
export interface DeleteCorsConfigurationResponse {
}
export declare const DeleteCorsConfigurationResponse: S.Schema<DeleteCorsConfigurationResponse>;
export interface DeleteDeploymentRequest {
    ApiId: string;
    DeploymentId: string;
}
export declare const DeleteDeploymentRequest: S.Schema<DeleteDeploymentRequest>;
export interface DeleteDeploymentResponse {
}
export declare const DeleteDeploymentResponse: S.Schema<DeleteDeploymentResponse>;
export interface DeleteDomainNameRequest {
    DomainName: string;
}
export declare const DeleteDomainNameRequest: S.Schema<DeleteDomainNameRequest>;
export interface DeleteDomainNameResponse {
}
export declare const DeleteDomainNameResponse: S.Schema<DeleteDomainNameResponse>;
export interface DeleteIntegrationRequest {
    ApiId: string;
    IntegrationId: string;
}
export declare const DeleteIntegrationRequest: S.Schema<DeleteIntegrationRequest>;
export interface DeleteIntegrationResponse {
}
export declare const DeleteIntegrationResponse: S.Schema<DeleteIntegrationResponse>;
export interface DeleteIntegrationResponseRequest {
    ApiId: string;
    IntegrationId: string;
    IntegrationResponseId: string;
}
export declare const DeleteIntegrationResponseRequest: S.Schema<DeleteIntegrationResponseRequest>;
export interface DeleteIntegrationResponseResponse {
}
export declare const DeleteIntegrationResponseResponse: S.Schema<DeleteIntegrationResponseResponse>;
export interface DeleteModelRequest {
    ApiId: string;
    ModelId: string;
}
export declare const DeleteModelRequest: S.Schema<DeleteModelRequest>;
export interface DeleteModelResponse {
}
export declare const DeleteModelResponse: S.Schema<DeleteModelResponse>;
export interface DeletePortalRequest {
    PortalId: string;
}
export declare const DeletePortalRequest: S.Schema<DeletePortalRequest>;
export interface DeletePortalResponse {
}
export declare const DeletePortalResponse: S.Schema<DeletePortalResponse>;
export interface DeletePortalProductRequest {
    PortalProductId: string;
}
export declare const DeletePortalProductRequest: S.Schema<DeletePortalProductRequest>;
export interface DeletePortalProductResponse {
}
export declare const DeletePortalProductResponse: S.Schema<DeletePortalProductResponse>;
export interface DeletePortalProductSharingPolicyRequest {
    PortalProductId: string;
}
export declare const DeletePortalProductSharingPolicyRequest: S.Schema<DeletePortalProductSharingPolicyRequest>;
export interface DeletePortalProductSharingPolicyResponse {
}
export declare const DeletePortalProductSharingPolicyResponse: S.Schema<DeletePortalProductSharingPolicyResponse>;
export interface DeleteProductPageRequest {
    PortalProductId: string;
    ProductPageId: string;
}
export declare const DeleteProductPageRequest: S.Schema<DeleteProductPageRequest>;
export interface DeleteProductPageResponse {
}
export declare const DeleteProductPageResponse: S.Schema<DeleteProductPageResponse>;
export interface DeleteProductRestEndpointPageRequest {
    PortalProductId: string;
    ProductRestEndpointPageId: string;
}
export declare const DeleteProductRestEndpointPageRequest: S.Schema<DeleteProductRestEndpointPageRequest>;
export interface DeleteProductRestEndpointPageResponse {
}
export declare const DeleteProductRestEndpointPageResponse: S.Schema<DeleteProductRestEndpointPageResponse>;
export interface DeleteRouteRequest {
    ApiId: string;
    RouteId: string;
}
export declare const DeleteRouteRequest: S.Schema<DeleteRouteRequest>;
export interface DeleteRouteResponse {
}
export declare const DeleteRouteResponse: S.Schema<DeleteRouteResponse>;
export interface DeleteRouteRequestParameterRequest {
    ApiId: string;
    RequestParameterKey: string;
    RouteId: string;
}
export declare const DeleteRouteRequestParameterRequest: S.Schema<DeleteRouteRequestParameterRequest>;
export interface DeleteRouteRequestParameterResponse {
}
export declare const DeleteRouteRequestParameterResponse: S.Schema<DeleteRouteRequestParameterResponse>;
export interface DeleteRouteResponseRequest {
    ApiId: string;
    RouteId: string;
    RouteResponseId: string;
}
export declare const DeleteRouteResponseRequest: S.Schema<DeleteRouteResponseRequest>;
export interface DeleteRouteResponseResponse {
}
export declare const DeleteRouteResponseResponse: S.Schema<DeleteRouteResponseResponse>;
export interface DeleteRouteSettingsRequest {
    ApiId: string;
    RouteKey: string;
    StageName: string;
}
export declare const DeleteRouteSettingsRequest: S.Schema<DeleteRouteSettingsRequest>;
export interface DeleteRouteSettingsResponse {
}
export declare const DeleteRouteSettingsResponse: S.Schema<DeleteRouteSettingsResponse>;
export interface DeleteRoutingRuleRequest {
    DomainName: string;
    DomainNameId?: string;
    RoutingRuleId: string;
}
export declare const DeleteRoutingRuleRequest: S.Schema<DeleteRoutingRuleRequest>;
export interface DeleteRoutingRuleResponse {
}
export declare const DeleteRoutingRuleResponse: S.Schema<DeleteRoutingRuleResponse>;
export interface DeleteStageRequest {
    ApiId: string;
    StageName: string;
}
export declare const DeleteStageRequest: S.Schema<DeleteStageRequest>;
export interface DeleteStageResponse {
}
export declare const DeleteStageResponse: S.Schema<DeleteStageResponse>;
export interface DeleteVpcLinkRequest {
    VpcLinkId: string;
}
export declare const DeleteVpcLinkRequest: S.Schema<DeleteVpcLinkRequest>;
export interface DeleteVpcLinkResponse {
}
export declare const DeleteVpcLinkResponse: S.Schema<DeleteVpcLinkResponse>;
export interface DisablePortalRequest {
    PortalId: string;
}
export declare const DisablePortalRequest: S.Schema<DisablePortalRequest>;
export interface DisablePortalResponse {
}
export declare const DisablePortalResponse: S.Schema<DisablePortalResponse>;
export interface ExportApiRequest {
    ApiId: string;
    ExportVersion?: string;
    IncludeExtensions?: boolean;
    OutputType?: string;
    Specification: string;
    StageName?: string;
}
export declare const ExportApiRequest: S.Schema<ExportApiRequest>;
export interface ExportApiResponse {
    body?: T.StreamingOutputBody;
}
export declare const ExportApiResponse: S.Schema<ExportApiResponse>;
export interface GetApiRequest {
    ApiId: string;
}
export declare const GetApiRequest: S.Schema<GetApiRequest>;
export interface GetApiResponse {
    ApiEndpoint?: string;
    ApiGatewayManaged?: boolean;
    ApiId?: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CreatedDate?: Date;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    ImportInfo?: string[];
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Version?: string;
    Warnings?: string[];
}
export declare const GetApiResponse: S.Schema<GetApiResponse>;
export interface GetApiMappingRequest {
    ApiMappingId: string;
    DomainName: string;
}
export declare const GetApiMappingRequest: S.Schema<GetApiMappingRequest>;
export interface GetApiMappingResponse {
    ApiId?: string;
    ApiMappingId?: string;
    ApiMappingKey?: string;
    Stage?: string;
}
export declare const GetApiMappingResponse: S.Schema<GetApiMappingResponse>;
export interface GetApiMappingsRequest {
    DomainName: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const GetApiMappingsRequest: S.Schema<GetApiMappingsRequest>;
export interface ApiMapping {
    ApiId?: string;
    ApiMappingId?: string;
    ApiMappingKey?: string;
    Stage?: string;
}
export declare const ApiMapping: S.Schema<ApiMapping>;
export type __listOfApiMapping = ApiMapping[];
export declare const __listOfApiMapping: any;
export type NextToken = string;
export interface GetApiMappingsResponse {
    Items?: (ApiMapping & {
        ApiId: Id;
        Stage: StringWithLengthBetween1And128;
    })[];
    NextToken?: string;
}
export declare const GetApiMappingsResponse: S.Schema<GetApiMappingsResponse>;
export interface GetApisRequest {
    MaxResults?: string;
    NextToken?: string;
}
export declare const GetApisRequest: S.Schema<GetApisRequest>;
export interface Api {
    ApiEndpoint?: string;
    ApiGatewayManaged?: boolean;
    ApiId?: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CreatedDate?: Date;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    ImportInfo?: string[];
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Version?: string;
    Warnings?: string[];
}
export declare const Api: S.Schema<Api>;
export type __listOfApi = Api[];
export declare const __listOfApi: any;
export interface GetApisResponse {
    Items?: (Api & {
        Name: StringWithLengthBetween1And128;
        ProtocolType: ProtocolType;
        RouteSelectionExpression: SelectionExpression;
    })[];
    NextToken?: string;
}
export declare const GetApisResponse: S.Schema<GetApisResponse>;
export interface GetAuthorizerRequest {
    ApiId: string;
    AuthorizerId: string;
}
export declare const GetAuthorizerRequest: S.Schema<GetAuthorizerRequest>;
export interface GetAuthorizerResponse {
    AuthorizerCredentialsArn?: string;
    AuthorizerId?: string;
    AuthorizerPayloadFormatVersion?: string;
    AuthorizerResultTtlInSeconds?: number;
    AuthorizerType?: AuthorizerType;
    AuthorizerUri?: string;
    EnableSimpleResponses?: boolean;
    IdentitySource?: string[];
    IdentityValidationExpression?: string;
    JwtConfiguration?: JWTConfiguration;
    Name?: string;
}
export declare const GetAuthorizerResponse: S.Schema<GetAuthorizerResponse>;
export interface GetAuthorizersRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const GetAuthorizersRequest: S.Schema<GetAuthorizersRequest>;
export interface Authorizer {
    AuthorizerCredentialsArn?: string;
    AuthorizerId?: string;
    AuthorizerPayloadFormatVersion?: string;
    AuthorizerResultTtlInSeconds?: number;
    AuthorizerType?: AuthorizerType;
    AuthorizerUri?: string;
    EnableSimpleResponses?: boolean;
    IdentitySource?: string[];
    IdentityValidationExpression?: string;
    JwtConfiguration?: JWTConfiguration;
    Name?: string;
}
export declare const Authorizer: S.Schema<Authorizer>;
export type __listOfAuthorizer = Authorizer[];
export declare const __listOfAuthorizer: any;
export interface GetAuthorizersResponse {
    Items?: (Authorizer & {
        Name: StringWithLengthBetween1And128;
    })[];
    NextToken?: string;
}
export declare const GetAuthorizersResponse: S.Schema<GetAuthorizersResponse>;
export interface GetDeploymentRequest {
    ApiId: string;
    DeploymentId: string;
}
export declare const GetDeploymentRequest: S.Schema<GetDeploymentRequest>;
export interface GetDeploymentResponse {
    AutoDeployed?: boolean;
    CreatedDate?: Date;
    DeploymentId?: string;
    DeploymentStatus?: DeploymentStatus;
    DeploymentStatusMessage?: string;
    Description?: string;
}
export declare const GetDeploymentResponse: S.Schema<GetDeploymentResponse>;
export interface GetDeploymentsRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const GetDeploymentsRequest: S.Schema<GetDeploymentsRequest>;
export interface Deployment {
    AutoDeployed?: boolean;
    CreatedDate?: Date;
    DeploymentId?: string;
    DeploymentStatus?: DeploymentStatus;
    DeploymentStatusMessage?: string;
    Description?: string;
}
export declare const Deployment: S.Schema<Deployment>;
export type __listOfDeployment = Deployment[];
export declare const __listOfDeployment: any;
export interface GetDeploymentsResponse {
    Items?: Deployment[];
    NextToken?: string;
}
export declare const GetDeploymentsResponse: S.Schema<GetDeploymentsResponse>;
export interface GetDomainNameRequest {
    DomainName: string;
}
export declare const GetDomainNameRequest: S.Schema<GetDomainNameRequest>;
export interface GetDomainNameResponse {
    ApiMappingSelectionExpression?: string;
    DomainName?: string;
    DomainNameArn?: string;
    DomainNameConfigurations?: DomainNameConfiguration[];
    MutualTlsAuthentication?: MutualTlsAuthentication;
    RoutingMode?: RoutingMode;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetDomainNameResponse: S.Schema<GetDomainNameResponse>;
export interface GetDomainNamesRequest {
    MaxResults?: string;
    NextToken?: string;
}
export declare const GetDomainNamesRequest: S.Schema<GetDomainNamesRequest>;
export interface DomainName {
    ApiMappingSelectionExpression?: string;
    DomainName?: string;
    DomainNameArn?: string;
    DomainNameConfigurations?: DomainNameConfiguration[];
    MutualTlsAuthentication?: MutualTlsAuthentication;
    RoutingMode?: RoutingMode;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DomainName: S.Schema<DomainName>;
export type __listOfDomainName = DomainName[];
export declare const __listOfDomainName: any;
export interface GetDomainNamesResponse {
    Items?: (DomainName & {
        DomainName: StringWithLengthBetween1And512;
    })[];
    NextToken?: string;
}
export declare const GetDomainNamesResponse: S.Schema<GetDomainNamesResponse>;
export interface GetIntegrationRequest {
    ApiId: string;
    IntegrationId: string;
}
export declare const GetIntegrationRequest: S.Schema<GetIntegrationRequest>;
export interface GetIntegrationResult {
    ApiGatewayManaged?: boolean;
    ConnectionId?: string;
    ConnectionType?: ConnectionType;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    CredentialsArn?: string;
    Description?: string;
    IntegrationId?: string;
    IntegrationMethod?: string;
    IntegrationResponseSelectionExpression?: string;
    IntegrationSubtype?: string;
    IntegrationType?: IntegrationType;
    IntegrationUri?: string;
    PassthroughBehavior?: PassthroughBehavior;
    PayloadFormatVersion?: string;
    RequestParameters?: {
        [key: string]: string | undefined;
    };
    RequestTemplates?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    TemplateSelectionExpression?: string;
    TimeoutInMillis?: number;
    TlsConfig?: TlsConfig;
}
export declare const GetIntegrationResult: S.Schema<GetIntegrationResult>;
export interface GetIntegrationResponseRequest {
    ApiId: string;
    IntegrationId: string;
    IntegrationResponseId: string;
}
export declare const GetIntegrationResponseRequest: S.Schema<GetIntegrationResponseRequest>;
export interface GetIntegrationResponseResponse {
    ContentHandlingStrategy?: ContentHandlingStrategy;
    IntegrationResponseId?: string;
    IntegrationResponseKey?: string;
    ResponseParameters?: {
        [key: string]: string | undefined;
    };
    ResponseTemplates?: {
        [key: string]: string | undefined;
    };
    TemplateSelectionExpression?: string;
}
export declare const GetIntegrationResponseResponse: S.Schema<GetIntegrationResponseResponse>;
export interface GetIntegrationResponsesRequest {
    ApiId: string;
    IntegrationId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const GetIntegrationResponsesRequest: S.Schema<GetIntegrationResponsesRequest>;
export interface IntegrationResponse {
    ContentHandlingStrategy?: ContentHandlingStrategy;
    IntegrationResponseId?: string;
    IntegrationResponseKey?: string;
    ResponseParameters?: {
        [key: string]: string | undefined;
    };
    ResponseTemplates?: {
        [key: string]: string | undefined;
    };
    TemplateSelectionExpression?: string;
}
export declare const IntegrationResponse: S.Schema<IntegrationResponse>;
export type __listOfIntegrationResponse = IntegrationResponse[];
export declare const __listOfIntegrationResponse: any;
export interface GetIntegrationResponsesResponse {
    Items?: (IntegrationResponse & {
        IntegrationResponseKey: SelectionKey;
    })[];
    NextToken?: string;
}
export declare const GetIntegrationResponsesResponse: S.Schema<GetIntegrationResponsesResponse>;
export interface GetIntegrationsRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const GetIntegrationsRequest: S.Schema<GetIntegrationsRequest>;
export interface Integration {
    ApiGatewayManaged?: boolean;
    ConnectionId?: string;
    ConnectionType?: ConnectionType;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    CredentialsArn?: string;
    Description?: string;
    IntegrationId?: string;
    IntegrationMethod?: string;
    IntegrationResponseSelectionExpression?: string;
    IntegrationSubtype?: string;
    IntegrationType?: IntegrationType;
    IntegrationUri?: string;
    PassthroughBehavior?: PassthroughBehavior;
    PayloadFormatVersion?: string;
    RequestParameters?: {
        [key: string]: string | undefined;
    };
    RequestTemplates?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    TemplateSelectionExpression?: string;
    TimeoutInMillis?: number;
    TlsConfig?: TlsConfig;
}
export declare const Integration: S.Schema<Integration>;
export type __listOfIntegration = Integration[];
export declare const __listOfIntegration: any;
export interface GetIntegrationsResponse {
    Items?: Integration[];
    NextToken?: string;
}
export declare const GetIntegrationsResponse: S.Schema<GetIntegrationsResponse>;
export interface GetModelRequest {
    ApiId: string;
    ModelId: string;
}
export declare const GetModelRequest: S.Schema<GetModelRequest>;
export interface GetModelResponse {
    ContentType?: string;
    Description?: string;
    ModelId?: string;
    Name?: string;
    Schema?: string;
}
export declare const GetModelResponse: S.Schema<GetModelResponse>;
export interface GetModelsRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const GetModelsRequest: S.Schema<GetModelsRequest>;
export interface Model {
    ContentType?: string;
    Description?: string;
    ModelId?: string;
    Name?: string;
    Schema?: string;
}
export declare const Model: S.Schema<Model>;
export type __listOfModel = Model[];
export declare const __listOfModel: any;
export interface GetModelsResponse {
    Items?: (Model & {
        Name: StringWithLengthBetween1And128;
    })[];
    NextToken?: string;
}
export declare const GetModelsResponse: S.Schema<GetModelsResponse>;
export interface GetModelTemplateRequest {
    ApiId: string;
    ModelId: string;
}
export declare const GetModelTemplateRequest: S.Schema<GetModelTemplateRequest>;
export interface GetModelTemplateResponse {
    Value?: string;
}
export declare const GetModelTemplateResponse: S.Schema<GetModelTemplateResponse>;
export interface GetPortalRequest {
    PortalId: string;
}
export declare const GetPortalRequest: S.Schema<GetPortalRequest>;
export type PreviewStatus = "PREVIEW_IN_PROGRESS" | "PREVIEW_FAILED" | "PREVIEW_READY" | (string & {});
export declare const PreviewStatus: any;
export interface Preview {
    PreviewStatus?: PreviewStatus;
    PreviewUrl?: string;
    StatusException?: StatusException;
}
export declare const Preview: S.Schema<Preview>;
export interface GetPortalResponse {
    Authorization?: Authorization & {
        CognitoConfig: CognitoConfig & {
            AppClientId: __stringMin1Max256;
            UserPoolArn: __stringMin20Max2048;
            UserPoolDomain: __stringMin20Max2048;
        };
    };
    EndpointConfiguration?: EndpointConfigurationResponse & {
        PortalDefaultDomainName: __stringMin3Max256;
        PortalDomainHostedZoneId: __stringMin1Max64;
    };
    IncludedPortalProductArns?: string[];
    LastModified?: Date;
    LastPublished?: Date;
    LastPublishedDescription?: string;
    PortalArn?: string;
    PortalContent?: PortalContent & {
        DisplayName: __stringMin3Max255;
        Theme: PortalTheme & {
            CustomColors: CustomColors & {
                AccentColor: __stringMin1Max16;
                BackgroundColor: __stringMin1Max16;
                ErrorValidationColor: __stringMin1Max16;
                HeaderColor: __stringMin1Max16;
                NavigationColor: __stringMin1Max16;
                TextColor: __stringMin1Max16;
            };
        };
    };
    PortalId?: string;
    Preview?: Preview & {
        PreviewStatus: PreviewStatus;
    };
    PublishStatus?: PublishStatus;
    RumAppMonitorName?: string;
    StatusException?: StatusException;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetPortalResponse: S.Schema<GetPortalResponse>;
export interface GetPortalProductRequest {
    PortalProductId: string;
    ResourceOwnerAccountId?: string;
}
export declare const GetPortalProductRequest: S.Schema<GetPortalProductRequest>;
export interface GetPortalProductResponse {
    Description?: string;
    DisplayName?: string;
    DisplayOrder?: DisplayOrder & {
        Contents: (Section & {
            ProductRestEndpointPageArns: __listOf__stringMin20Max2048;
            SectionName: string;
        })[];
    };
    LastModified?: Date;
    PortalProductArn?: string;
    PortalProductId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetPortalProductResponse: S.Schema<GetPortalProductResponse>;
export interface GetPortalProductSharingPolicyRequest {
    PortalProductId: string;
}
export declare const GetPortalProductSharingPolicyRequest: S.Schema<GetPortalProductSharingPolicyRequest>;
export type __stringMin1Max307200 = string;
export interface GetPortalProductSharingPolicyResponse {
    PolicyDocument?: string;
    PortalProductId?: string;
}
export declare const GetPortalProductSharingPolicyResponse: S.Schema<GetPortalProductSharingPolicyResponse>;
export interface GetProductPageRequest {
    PortalProductId: string;
    ProductPageId: string;
    ResourceOwnerAccountId?: string;
}
export declare const GetProductPageRequest: S.Schema<GetProductPageRequest>;
export interface GetProductPageResponse {
    DisplayContent?: DisplayContent & {
        Body: __stringMin1Max32768;
        Title: __stringMin1Max255;
    };
    LastModified?: Date;
    ProductPageArn?: string;
    ProductPageId?: string;
}
export declare const GetProductPageResponse: S.Schema<GetProductPageResponse>;
export interface GetProductRestEndpointPageRequest {
    IncludeRawDisplayContent?: string;
    PortalProductId: string;
    ProductRestEndpointPageId: string;
    ResourceOwnerAccountId?: string;
}
export declare const GetProductRestEndpointPageRequest: S.Schema<GetProductRestEndpointPageRequest>;
export interface GetProductRestEndpointPageResponse {
    DisplayContent?: EndpointDisplayContentResponse & {
        Endpoint: __stringMin1Max1024;
    };
    LastModified?: Date;
    ProductRestEndpointPageArn?: string;
    ProductRestEndpointPageId?: string;
    RawDisplayContent?: string;
    RestEndpointIdentifier?: RestEndpointIdentifier & {
        IdentifierParts: IdentifierParts & {
            Method: __stringMin1Max20;
            Path: __stringMin1Max4096;
            RestApiId: __stringMin1Max50;
            Stage: __stringMin1Max128;
        };
    };
    Status?: Status;
    StatusException?: StatusException;
    TryItState?: TryItState;
}
export declare const GetProductRestEndpointPageResponse: S.Schema<GetProductRestEndpointPageResponse>;
export interface GetRouteRequest {
    ApiId: string;
    RouteId: string;
}
export declare const GetRouteRequest: S.Schema<GetRouteRequest>;
export interface GetRouteResult {
    ApiGatewayManaged?: boolean;
    ApiKeyRequired?: boolean;
    AuthorizationScopes?: string[];
    AuthorizationType?: AuthorizationType;
    AuthorizerId?: string;
    ModelSelectionExpression?: string;
    OperationName?: string;
    RequestModels?: {
        [key: string]: string | undefined;
    };
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId?: string;
    RouteKey?: string;
    RouteResponseSelectionExpression?: string;
    Target?: string;
}
export declare const GetRouteResult: S.Schema<GetRouteResult>;
export interface GetRouteResponseRequest {
    ApiId: string;
    RouteId: string;
    RouteResponseId: string;
}
export declare const GetRouteResponseRequest: S.Schema<GetRouteResponseRequest>;
export interface GetRouteResponseResponse {
    ModelSelectionExpression?: string;
    ResponseModels?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteResponseId?: string;
    RouteResponseKey?: string;
}
export declare const GetRouteResponseResponse: S.Schema<GetRouteResponseResponse>;
export interface GetRouteResponsesRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
    RouteId: string;
}
export declare const GetRouteResponsesRequest: S.Schema<GetRouteResponsesRequest>;
export interface RouteResponse {
    ModelSelectionExpression?: string;
    ResponseModels?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteResponseId?: string;
    RouteResponseKey?: string;
}
export declare const RouteResponse: S.Schema<RouteResponse>;
export type __listOfRouteResponse = RouteResponse[];
export declare const __listOfRouteResponse: any;
export interface GetRouteResponsesResponse {
    Items?: (RouteResponse & {
        RouteResponseKey: SelectionKey;
    })[];
    NextToken?: string;
}
export declare const GetRouteResponsesResponse: S.Schema<GetRouteResponsesResponse>;
export interface GetRoutesRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const GetRoutesRequest: S.Schema<GetRoutesRequest>;
export interface Route {
    ApiGatewayManaged?: boolean;
    ApiKeyRequired?: boolean;
    AuthorizationScopes?: string[];
    AuthorizationType?: AuthorizationType;
    AuthorizerId?: string;
    ModelSelectionExpression?: string;
    OperationName?: string;
    RequestModels?: {
        [key: string]: string | undefined;
    };
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId?: string;
    RouteKey?: string;
    RouteResponseSelectionExpression?: string;
    Target?: string;
}
export declare const Route: S.Schema<Route>;
export type __listOfRoute = Route[];
export declare const __listOfRoute: any;
export interface GetRoutesResponse {
    Items?: (Route & {
        RouteKey: SelectionKey;
    })[];
    NextToken?: string;
}
export declare const GetRoutesResponse: S.Schema<GetRoutesResponse>;
export interface GetRoutingRuleRequest {
    DomainName: string;
    DomainNameId?: string;
    RoutingRuleId: string;
}
export declare const GetRoutingRuleRequest: S.Schema<GetRoutingRuleRequest>;
export interface GetRoutingRuleResponse {
    Actions?: (RoutingRuleAction & {
        InvokeApi: RoutingRuleActionInvokeApi & {
            ApiId: Id;
            Stage: StringWithLengthBetween1And128;
        };
    })[];
    Conditions?: (RoutingRuleCondition & {
        MatchBasePaths: RoutingRuleMatchBasePaths & {
            AnyOf: __listOfSelectionKey;
        };
        MatchHeaders: RoutingRuleMatchHeaders & {
            AnyOf: (RoutingRuleMatchHeaderValue & {
                Header: SelectionKey;
                ValueGlob: SelectionExpression;
            })[];
        };
    })[];
    Priority?: number;
    RoutingRuleArn?: string;
    RoutingRuleId?: string;
}
export declare const GetRoutingRuleResponse: S.Schema<GetRoutingRuleResponse>;
export interface GetStageRequest {
    ApiId: string;
    StageName: string;
}
export declare const GetStageRequest: S.Schema<GetStageRequest>;
export interface GetStageResponse {
    AccessLogSettings?: AccessLogSettings;
    ApiGatewayManaged?: boolean;
    AutoDeploy?: boolean;
    ClientCertificateId?: string;
    CreatedDate?: Date;
    DefaultRouteSettings?: RouteSettings;
    DeploymentId?: string;
    Description?: string;
    LastDeploymentStatusMessage?: string;
    LastUpdatedDate?: Date;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    };
    StageName?: string;
    StageVariables?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetStageResponse: S.Schema<GetStageResponse>;
export interface GetStagesRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const GetStagesRequest: S.Schema<GetStagesRequest>;
export interface Stage {
    AccessLogSettings?: AccessLogSettings;
    ApiGatewayManaged?: boolean;
    AutoDeploy?: boolean;
    ClientCertificateId?: string;
    CreatedDate?: Date;
    DefaultRouteSettings?: RouteSettings;
    DeploymentId?: string;
    Description?: string;
    LastDeploymentStatusMessage?: string;
    LastUpdatedDate?: Date;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    };
    StageName?: string;
    StageVariables?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Stage: S.Schema<Stage>;
export type __listOfStage = Stage[];
export declare const __listOfStage: any;
export interface GetStagesResponse {
    Items?: (Stage & {
        StageName: StringWithLengthBetween1And128;
    })[];
    NextToken?: string;
}
export declare const GetStagesResponse: S.Schema<GetStagesResponse>;
export interface GetTagsRequest {
    ResourceArn: string;
}
export declare const GetTagsRequest: S.Schema<GetTagsRequest>;
export interface GetTagsResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetTagsResponse: S.Schema<GetTagsResponse>;
export interface GetVpcLinkRequest {
    VpcLinkId: string;
}
export declare const GetVpcLinkRequest: S.Schema<GetVpcLinkRequest>;
export interface GetVpcLinkResponse {
    CreatedDate?: Date;
    Name?: string;
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
    VpcLinkId?: string;
    VpcLinkStatus?: VpcLinkStatus;
    VpcLinkStatusMessage?: string;
    VpcLinkVersion?: VpcLinkVersion;
}
export declare const GetVpcLinkResponse: S.Schema<GetVpcLinkResponse>;
export interface GetVpcLinksRequest {
    MaxResults?: string;
    NextToken?: string;
}
export declare const GetVpcLinksRequest: S.Schema<GetVpcLinksRequest>;
export interface VpcLink {
    CreatedDate?: Date;
    Name?: string;
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
    VpcLinkId?: string;
    VpcLinkStatus?: VpcLinkStatus;
    VpcLinkStatusMessage?: string;
    VpcLinkVersion?: VpcLinkVersion;
}
export declare const VpcLink: S.Schema<VpcLink>;
export type __listOfVpcLink = VpcLink[];
export declare const __listOfVpcLink: any;
export interface GetVpcLinksResponse {
    Items?: (VpcLink & {
        Name: StringWithLengthBetween1And128;
        SecurityGroupIds: SecurityGroupIdList;
        SubnetIds: SubnetIdList;
        VpcLinkId: Id;
    })[];
    NextToken?: string;
}
export declare const GetVpcLinksResponse: S.Schema<GetVpcLinksResponse>;
export interface ImportApiRequest {
    Basepath?: string;
    Body?: string;
    FailOnWarnings?: boolean;
}
export declare const ImportApiRequest: S.Schema<ImportApiRequest>;
export interface ImportApiResponse {
    ApiEndpoint?: string;
    ApiGatewayManaged?: boolean;
    ApiId?: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CreatedDate?: Date;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    ImportInfo?: string[];
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Version?: string;
    Warnings?: string[];
}
export declare const ImportApiResponse: S.Schema<ImportApiResponse>;
export interface ListPortalProductsRequest {
    MaxResults?: string;
    NextToken?: string;
    ResourceOwner?: string;
}
export declare const ListPortalProductsRequest: S.Schema<ListPortalProductsRequest>;
export interface PortalProductSummary {
    Description?: string;
    DisplayName?: string;
    LastModified?: Date;
    PortalProductArn?: string;
    PortalProductId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const PortalProductSummary: S.Schema<PortalProductSummary>;
export type __listOfPortalProductSummary = PortalProductSummary[];
export declare const __listOfPortalProductSummary: any;
export interface ListPortalProductsResponse {
    Items?: (PortalProductSummary & {
        Description: __stringMin0Max1024;
        DisplayName: __stringMin1Max255;
        LastModified: __timestampIso8601;
        PortalProductArn: __stringMin20Max2048;
        PortalProductId: __stringMin10Max30PatternAZ09;
    })[];
    NextToken?: string;
}
export declare const ListPortalProductsResponse: S.Schema<ListPortalProductsResponse>;
export interface ListPortalsRequest {
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListPortalsRequest: S.Schema<ListPortalsRequest>;
export interface PortalSummary {
    Authorization?: Authorization;
    EndpointConfiguration?: EndpointConfigurationResponse;
    IncludedPortalProductArns?: string[];
    LastModified?: Date;
    LastPublished?: Date;
    LastPublishedDescription?: string;
    PortalArn?: string;
    PortalContent?: PortalContent;
    PortalId?: string;
    Preview?: Preview;
    PublishStatus?: PublishStatus;
    RumAppMonitorName?: string;
    StatusException?: StatusException;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const PortalSummary: S.Schema<PortalSummary>;
export type __listOfPortalSummary = PortalSummary[];
export declare const __listOfPortalSummary: any;
export interface ListPortalsResponse {
    Items?: (PortalSummary & {
        Authorization: Authorization & {
            CognitoConfig: CognitoConfig & {
                AppClientId: __stringMin1Max256;
                UserPoolArn: __stringMin20Max2048;
                UserPoolDomain: __stringMin20Max2048;
            };
        };
        EndpointConfiguration: EndpointConfigurationResponse & {
            PortalDefaultDomainName: __stringMin3Max256;
            PortalDomainHostedZoneId: __stringMin1Max64;
        };
        IncludedPortalProductArns: __listOf__stringMin20Max2048;
        LastModified: __timestampIso8601;
        PortalArn: __stringMin20Max2048;
        PortalContent: PortalContent & {
            DisplayName: __stringMin3Max255;
            Theme: PortalTheme & {
                CustomColors: CustomColors & {
                    AccentColor: __stringMin1Max16;
                    BackgroundColor: __stringMin1Max16;
                    ErrorValidationColor: __stringMin1Max16;
                    HeaderColor: __stringMin1Max16;
                    NavigationColor: __stringMin1Max16;
                    TextColor: __stringMin1Max16;
                };
            };
        };
        PortalId: __stringMin10Max30PatternAZ09;
        Preview: Preview & {
            PreviewStatus: PreviewStatus;
        };
    })[];
    NextToken?: string;
}
export declare const ListPortalsResponse: S.Schema<ListPortalsResponse>;
export interface ListProductPagesRequest {
    MaxResults?: string;
    NextToken?: string;
    PortalProductId: string;
    ResourceOwnerAccountId?: string;
}
export declare const ListProductPagesRequest: S.Schema<ListProductPagesRequest>;
export interface ProductPageSummaryNoBody {
    LastModified?: Date;
    PageTitle?: string;
    ProductPageArn?: string;
    ProductPageId?: string;
}
export declare const ProductPageSummaryNoBody: S.Schema<ProductPageSummaryNoBody>;
export type __listOfProductPageSummaryNoBody = ProductPageSummaryNoBody[];
export declare const __listOfProductPageSummaryNoBody: any;
export interface ListProductPagesResponse {
    Items?: (ProductPageSummaryNoBody & {
        LastModified: __timestampIso8601;
        PageTitle: __stringMin1Max255;
        ProductPageArn: __stringMin20Max2048;
        ProductPageId: __stringMin10Max30PatternAZ09;
    })[];
    NextToken?: string;
}
export declare const ListProductPagesResponse: S.Schema<ListProductPagesResponse>;
export interface ListProductRestEndpointPagesRequest {
    MaxResults?: string;
    NextToken?: string;
    PortalProductId: string;
    ResourceOwnerAccountId?: string;
}
export declare const ListProductRestEndpointPagesRequest: S.Schema<ListProductRestEndpointPagesRequest>;
export interface ProductRestEndpointPageSummaryNoBody {
    Endpoint?: string;
    LastModified?: Date;
    OperationName?: string;
    ProductRestEndpointPageArn?: string;
    ProductRestEndpointPageId?: string;
    RestEndpointIdentifier?: RestEndpointIdentifier;
    Status?: Status;
    StatusException?: StatusException;
    TryItState?: TryItState;
}
export declare const ProductRestEndpointPageSummaryNoBody: S.Schema<ProductRestEndpointPageSummaryNoBody>;
export type __listOfProductRestEndpointPageSummaryNoBody = ProductRestEndpointPageSummaryNoBody[];
export declare const __listOfProductRestEndpointPageSummaryNoBody: any;
export interface ListProductRestEndpointPagesResponse {
    Items?: (ProductRestEndpointPageSummaryNoBody & {
        Endpoint: __stringMin1Max1024;
        LastModified: __timestampIso8601;
        ProductRestEndpointPageArn: __stringMin20Max2048;
        ProductRestEndpointPageId: __stringMin10Max30PatternAZ09;
        RestEndpointIdentifier: RestEndpointIdentifier & {
            IdentifierParts: IdentifierParts & {
                Method: __stringMin1Max20;
                Path: __stringMin1Max4096;
                RestApiId: __stringMin1Max50;
                Stage: __stringMin1Max128;
            };
        };
        Status: Status;
        TryItState: TryItState;
    })[];
    NextToken?: string;
}
export declare const ListProductRestEndpointPagesResponse: S.Schema<ListProductRestEndpointPagesResponse>;
export type MaxResults = number;
export interface ListRoutingRulesRequest {
    DomainName: string;
    DomainNameId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListRoutingRulesRequest: S.Schema<ListRoutingRulesRequest>;
export interface RoutingRule {
    Actions?: RoutingRuleAction[];
    Conditions?: RoutingRuleCondition[];
    Priority?: number;
    RoutingRuleArn?: string;
    RoutingRuleId?: string;
}
export declare const RoutingRule: S.Schema<RoutingRule>;
export type __listOfRoutingRule = RoutingRule[];
export declare const __listOfRoutingRule: any;
export interface ListRoutingRulesResponse {
    NextToken?: string;
    RoutingRules?: (RoutingRule & {
        Actions: (RoutingRuleAction & {
            InvokeApi: RoutingRuleActionInvokeApi & {
                ApiId: Id;
                Stage: StringWithLengthBetween1And128;
            };
        })[];
        Conditions: (RoutingRuleCondition & {
            MatchBasePaths: RoutingRuleMatchBasePaths & {
                AnyOf: __listOfSelectionKey;
            };
            MatchHeaders: RoutingRuleMatchHeaders & {
                AnyOf: (RoutingRuleMatchHeaderValue & {
                    Header: SelectionKey;
                    ValueGlob: SelectionExpression;
                })[];
            };
        })[];
    })[];
}
export declare const ListRoutingRulesResponse: S.Schema<ListRoutingRulesResponse>;
export interface PreviewPortalRequest {
    PortalId: string;
}
export declare const PreviewPortalRequest: S.Schema<PreviewPortalRequest>;
export interface PreviewPortalResponse {
}
export declare const PreviewPortalResponse: S.Schema<PreviewPortalResponse>;
export interface PublishPortalRequest {
    Description?: string;
    PortalId: string;
}
export declare const PublishPortalRequest: S.Schema<PublishPortalRequest>;
export interface PublishPortalResponse {
}
export declare const PublishPortalResponse: S.Schema<PublishPortalResponse>;
export interface PutPortalProductSharingPolicyRequest {
    PolicyDocument?: string;
    PortalProductId: string;
}
export declare const PutPortalProductSharingPolicyRequest: S.Schema<PutPortalProductSharingPolicyRequest>;
export interface PutPortalProductSharingPolicyResponse {
}
export declare const PutPortalProductSharingPolicyResponse: S.Schema<PutPortalProductSharingPolicyResponse>;
export interface PutRoutingRuleRequest {
    Actions?: RoutingRuleAction[];
    Conditions?: RoutingRuleCondition[];
    DomainName: string;
    DomainNameId?: string;
    Priority?: number;
    RoutingRuleId: string;
}
export declare const PutRoutingRuleRequest: S.Schema<PutRoutingRuleRequest>;
export interface PutRoutingRuleResponse {
    Actions?: (RoutingRuleAction & {
        InvokeApi: RoutingRuleActionInvokeApi & {
            ApiId: Id;
            Stage: StringWithLengthBetween1And128;
        };
    })[];
    Conditions?: (RoutingRuleCondition & {
        MatchBasePaths: RoutingRuleMatchBasePaths & {
            AnyOf: __listOfSelectionKey;
        };
        MatchHeaders: RoutingRuleMatchHeaders & {
            AnyOf: (RoutingRuleMatchHeaderValue & {
                Header: SelectionKey;
                ValueGlob: SelectionExpression;
            })[];
        };
    })[];
    Priority?: number;
    RoutingRuleArn?: string;
    RoutingRuleId?: string;
}
export declare const PutRoutingRuleResponse: S.Schema<PutRoutingRuleResponse>;
export interface ReimportApiRequest {
    ApiId: string;
    Basepath?: string;
    Body?: string;
    FailOnWarnings?: boolean;
}
export declare const ReimportApiRequest: S.Schema<ReimportApiRequest>;
export interface ReimportApiResponse {
    ApiEndpoint?: string;
    ApiGatewayManaged?: boolean;
    ApiId?: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CreatedDate?: Date;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    ImportInfo?: string[];
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Version?: string;
    Warnings?: string[];
}
export declare const ReimportApiResponse: S.Schema<ReimportApiResponse>;
export interface ResetAuthorizersCacheRequest {
    ApiId: string;
    StageName: string;
}
export declare const ResetAuthorizersCacheRequest: S.Schema<ResetAuthorizersCacheRequest>;
export interface ResetAuthorizersCacheResponse {
}
export declare const ResetAuthorizersCacheResponse: S.Schema<ResetAuthorizersCacheResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateApiRequest {
    ApiId: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CredentialsArn?: string;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    IpAddressType?: IpAddressType;
    Name?: string;
    RouteKey?: string;
    RouteSelectionExpression?: string;
    Target?: string;
    Version?: string;
}
export declare const UpdateApiRequest: S.Schema<UpdateApiRequest>;
export interface UpdateApiResponse {
    ApiEndpoint?: string;
    ApiGatewayManaged?: boolean;
    ApiId?: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CreatedDate?: Date;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    ImportInfo?: string[];
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Version?: string;
    Warnings?: string[];
}
export declare const UpdateApiResponse: S.Schema<UpdateApiResponse>;
export interface UpdateApiMappingRequest {
    ApiId?: string;
    ApiMappingId: string;
    ApiMappingKey?: string;
    DomainName: string;
    Stage?: string;
}
export declare const UpdateApiMappingRequest: S.Schema<UpdateApiMappingRequest>;
export interface UpdateApiMappingResponse {
    ApiId?: string;
    ApiMappingId?: string;
    ApiMappingKey?: string;
    Stage?: string;
}
export declare const UpdateApiMappingResponse: S.Schema<UpdateApiMappingResponse>;
export interface UpdateAuthorizerRequest {
    ApiId: string;
    AuthorizerCredentialsArn?: string;
    AuthorizerId: string;
    AuthorizerPayloadFormatVersion?: string;
    AuthorizerResultTtlInSeconds?: number;
    AuthorizerType?: AuthorizerType;
    AuthorizerUri?: string;
    EnableSimpleResponses?: boolean;
    IdentitySource?: string[];
    IdentityValidationExpression?: string;
    JwtConfiguration?: JWTConfiguration;
    Name?: string;
}
export declare const UpdateAuthorizerRequest: S.Schema<UpdateAuthorizerRequest>;
export interface UpdateAuthorizerResponse {
    AuthorizerCredentialsArn?: string;
    AuthorizerId?: string;
    AuthorizerPayloadFormatVersion?: string;
    AuthorizerResultTtlInSeconds?: number;
    AuthorizerType?: AuthorizerType;
    AuthorizerUri?: string;
    EnableSimpleResponses?: boolean;
    IdentitySource?: string[];
    IdentityValidationExpression?: string;
    JwtConfiguration?: JWTConfiguration;
    Name?: string;
}
export declare const UpdateAuthorizerResponse: S.Schema<UpdateAuthorizerResponse>;
export interface UpdateDeploymentRequest {
    ApiId: string;
    DeploymentId: string;
    Description?: string;
}
export declare const UpdateDeploymentRequest: S.Schema<UpdateDeploymentRequest>;
export interface UpdateDeploymentResponse {
    AutoDeployed?: boolean;
    CreatedDate?: Date;
    DeploymentId?: string;
    DeploymentStatus?: DeploymentStatus;
    DeploymentStatusMessage?: string;
    Description?: string;
}
export declare const UpdateDeploymentResponse: S.Schema<UpdateDeploymentResponse>;
export interface UpdateDomainNameRequest {
    DomainName: string;
    DomainNameConfigurations?: DomainNameConfiguration[];
    MutualTlsAuthentication?: MutualTlsAuthenticationInput;
    RoutingMode?: RoutingMode;
}
export declare const UpdateDomainNameRequest: S.Schema<UpdateDomainNameRequest>;
export interface UpdateDomainNameResponse {
    ApiMappingSelectionExpression?: string;
    DomainName?: string;
    DomainNameArn?: string;
    DomainNameConfigurations?: DomainNameConfiguration[];
    MutualTlsAuthentication?: MutualTlsAuthentication;
    RoutingMode?: RoutingMode;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateDomainNameResponse: S.Schema<UpdateDomainNameResponse>;
export interface UpdateIntegrationRequest {
    ApiId: string;
    ConnectionId?: string;
    ConnectionType?: ConnectionType;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    CredentialsArn?: string;
    Description?: string;
    IntegrationId: string;
    IntegrationMethod?: string;
    IntegrationSubtype?: string;
    IntegrationType?: IntegrationType;
    IntegrationUri?: string;
    PassthroughBehavior?: PassthroughBehavior;
    PayloadFormatVersion?: string;
    RequestParameters?: {
        [key: string]: string | undefined;
    };
    RequestTemplates?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    TemplateSelectionExpression?: string;
    TimeoutInMillis?: number;
    TlsConfig?: TlsConfigInput;
}
export declare const UpdateIntegrationRequest: S.Schema<UpdateIntegrationRequest>;
export interface UpdateIntegrationResult {
    ApiGatewayManaged?: boolean;
    ConnectionId?: string;
    ConnectionType?: ConnectionType;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    CredentialsArn?: string;
    Description?: string;
    IntegrationId?: string;
    IntegrationMethod?: string;
    IntegrationResponseSelectionExpression?: string;
    IntegrationSubtype?: string;
    IntegrationType?: IntegrationType;
    IntegrationUri?: string;
    PassthroughBehavior?: PassthroughBehavior;
    PayloadFormatVersion?: string;
    RequestParameters?: {
        [key: string]: string | undefined;
    };
    RequestTemplates?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    TemplateSelectionExpression?: string;
    TimeoutInMillis?: number;
    TlsConfig?: TlsConfig;
}
export declare const UpdateIntegrationResult: S.Schema<UpdateIntegrationResult>;
export interface UpdateIntegrationResponseRequest {
    ApiId: string;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    IntegrationId: string;
    IntegrationResponseId: string;
    IntegrationResponseKey?: string;
    ResponseParameters?: {
        [key: string]: string | undefined;
    };
    ResponseTemplates?: {
        [key: string]: string | undefined;
    };
    TemplateSelectionExpression?: string;
}
export declare const UpdateIntegrationResponseRequest: S.Schema<UpdateIntegrationResponseRequest>;
export interface UpdateIntegrationResponseResponse {
    ContentHandlingStrategy?: ContentHandlingStrategy;
    IntegrationResponseId?: string;
    IntegrationResponseKey?: string;
    ResponseParameters?: {
        [key: string]: string | undefined;
    };
    ResponseTemplates?: {
        [key: string]: string | undefined;
    };
    TemplateSelectionExpression?: string;
}
export declare const UpdateIntegrationResponseResponse: S.Schema<UpdateIntegrationResponseResponse>;
export interface UpdateModelRequest {
    ApiId: string;
    ContentType?: string;
    Description?: string;
    ModelId: string;
    Name?: string;
    Schema?: string;
}
export declare const UpdateModelRequest: S.Schema<UpdateModelRequest>;
export interface UpdateModelResponse {
    ContentType?: string;
    Description?: string;
    ModelId?: string;
    Name?: string;
    Schema?: string;
}
export declare const UpdateModelResponse: S.Schema<UpdateModelResponse>;
export interface UpdatePortalRequest {
    Authorization?: Authorization;
    EndpointConfiguration?: EndpointConfigurationRequest;
    IncludedPortalProductArns?: string[];
    LogoUri?: string;
    PortalContent?: PortalContent;
    PortalId: string;
    RumAppMonitorName?: string;
}
export declare const UpdatePortalRequest: S.Schema<UpdatePortalRequest>;
export interface UpdatePortalResponse {
    Authorization?: Authorization & {
        CognitoConfig: CognitoConfig & {
            AppClientId: __stringMin1Max256;
            UserPoolArn: __stringMin20Max2048;
            UserPoolDomain: __stringMin20Max2048;
        };
    };
    EndpointConfiguration?: EndpointConfigurationResponse & {
        PortalDefaultDomainName: __stringMin3Max256;
        PortalDomainHostedZoneId: __stringMin1Max64;
    };
    IncludedPortalProductArns?: string[];
    LastModified?: Date;
    LastPublished?: Date;
    LastPublishedDescription?: string;
    PortalArn?: string;
    PortalContent?: PortalContent & {
        DisplayName: __stringMin3Max255;
        Theme: PortalTheme & {
            CustomColors: CustomColors & {
                AccentColor: __stringMin1Max16;
                BackgroundColor: __stringMin1Max16;
                ErrorValidationColor: __stringMin1Max16;
                HeaderColor: __stringMin1Max16;
                NavigationColor: __stringMin1Max16;
                TextColor: __stringMin1Max16;
            };
        };
    };
    PortalId?: string;
    Preview?: Preview & {
        PreviewStatus: PreviewStatus;
    };
    PublishStatus?: PublishStatus;
    RumAppMonitorName?: string;
    StatusException?: StatusException;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdatePortalResponse: S.Schema<UpdatePortalResponse>;
export interface UpdatePortalProductRequest {
    Description?: string;
    DisplayName?: string;
    DisplayOrder?: DisplayOrder;
    PortalProductId: string;
}
export declare const UpdatePortalProductRequest: S.Schema<UpdatePortalProductRequest>;
export interface UpdatePortalProductResponse {
    Description?: string;
    DisplayName?: string;
    DisplayOrder?: DisplayOrder & {
        Contents: (Section & {
            ProductRestEndpointPageArns: __listOf__stringMin20Max2048;
            SectionName: string;
        })[];
    };
    LastModified?: Date;
    PortalProductArn?: string;
    PortalProductId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdatePortalProductResponse: S.Schema<UpdatePortalProductResponse>;
export interface UpdateProductPageRequest {
    DisplayContent?: DisplayContent;
    PortalProductId: string;
    ProductPageId: string;
}
export declare const UpdateProductPageRequest: S.Schema<UpdateProductPageRequest>;
export interface UpdateProductPageResponse {
    DisplayContent?: DisplayContent & {
        Body: __stringMin1Max32768;
        Title: __stringMin1Max255;
    };
    LastModified?: Date;
    ProductPageArn?: string;
    ProductPageId?: string;
}
export declare const UpdateProductPageResponse: S.Schema<UpdateProductPageResponse>;
export interface UpdateProductRestEndpointPageRequest {
    DisplayContent?: EndpointDisplayContent;
    PortalProductId: string;
    ProductRestEndpointPageId: string;
    TryItState?: TryItState;
}
export declare const UpdateProductRestEndpointPageRequest: S.Schema<UpdateProductRestEndpointPageRequest>;
export interface UpdateProductRestEndpointPageResponse {
    DisplayContent?: EndpointDisplayContentResponse & {
        Endpoint: __stringMin1Max1024;
    };
    LastModified?: Date;
    ProductRestEndpointPageArn?: string;
    ProductRestEndpointPageId?: string;
    RestEndpointIdentifier?: RestEndpointIdentifier & {
        IdentifierParts: IdentifierParts & {
            Method: __stringMin1Max20;
            Path: __stringMin1Max4096;
            RestApiId: __stringMin1Max50;
            Stage: __stringMin1Max128;
        };
    };
    Status?: Status;
    StatusException?: StatusException;
    TryItState?: TryItState;
}
export declare const UpdateProductRestEndpointPageResponse: S.Schema<UpdateProductRestEndpointPageResponse>;
export interface UpdateRouteRequest {
    ApiId: string;
    ApiKeyRequired?: boolean;
    AuthorizationScopes?: string[];
    AuthorizationType?: AuthorizationType;
    AuthorizerId?: string;
    ModelSelectionExpression?: string;
    OperationName?: string;
    RequestModels?: {
        [key: string]: string | undefined;
    };
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId: string;
    RouteKey?: string;
    RouteResponseSelectionExpression?: string;
    Target?: string;
}
export declare const UpdateRouteRequest: S.Schema<UpdateRouteRequest>;
export interface UpdateRouteResult {
    ApiGatewayManaged?: boolean;
    ApiKeyRequired?: boolean;
    AuthorizationScopes?: string[];
    AuthorizationType?: AuthorizationType;
    AuthorizerId?: string;
    ModelSelectionExpression?: string;
    OperationName?: string;
    RequestModels?: {
        [key: string]: string | undefined;
    };
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId?: string;
    RouteKey?: string;
    RouteResponseSelectionExpression?: string;
    Target?: string;
}
export declare const UpdateRouteResult: S.Schema<UpdateRouteResult>;
export interface UpdateRouteResponseRequest {
    ApiId: string;
    ModelSelectionExpression?: string;
    ResponseModels?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId: string;
    RouteResponseId: string;
    RouteResponseKey?: string;
}
export declare const UpdateRouteResponseRequest: S.Schema<UpdateRouteResponseRequest>;
export interface UpdateRouteResponseResponse {
    ModelSelectionExpression?: string;
    ResponseModels?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteResponseId?: string;
    RouteResponseKey?: string;
}
export declare const UpdateRouteResponseResponse: S.Schema<UpdateRouteResponseResponse>;
export interface UpdateStageRequest {
    AccessLogSettings?: AccessLogSettings;
    ApiId: string;
    AutoDeploy?: boolean;
    ClientCertificateId?: string;
    DefaultRouteSettings?: RouteSettings;
    DeploymentId?: string;
    Description?: string;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    };
    StageName: string;
    StageVariables?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateStageRequest: S.Schema<UpdateStageRequest>;
export interface UpdateStageResponse {
    AccessLogSettings?: AccessLogSettings;
    ApiGatewayManaged?: boolean;
    AutoDeploy?: boolean;
    ClientCertificateId?: string;
    CreatedDate?: Date;
    DefaultRouteSettings?: RouteSettings;
    DeploymentId?: string;
    Description?: string;
    LastDeploymentStatusMessage?: string;
    LastUpdatedDate?: Date;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    };
    StageName?: string;
    StageVariables?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateStageResponse: S.Schema<UpdateStageResponse>;
export interface UpdateVpcLinkRequest {
    Name?: string;
    VpcLinkId: string;
}
export declare const UpdateVpcLinkRequest: S.Schema<UpdateVpcLinkRequest>;
export interface UpdateVpcLinkResponse {
    CreatedDate?: Date;
    Name?: string;
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
    VpcLinkId?: string;
    VpcLinkStatus?: VpcLinkStatus;
    VpcLinkStatusMessage?: string;
    VpcLinkVersion?: VpcLinkVersion;
}
export declare const UpdateVpcLinkResponse: S.Schema<UpdateVpcLinkResponse>;
export type CreateApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an Api resource.
 */
export declare const createApi: API.OperationMethod<CreateApiRequest, CreateApiResponse, CreateApiError, Credentials | HttpClient.HttpClient>;
export type CreateApiMappingError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an API mapping.
 */
export declare const createApiMapping: API.OperationMethod<CreateApiMappingRequest, CreateApiMappingResponse, CreateApiMappingError, Credentials | HttpClient.HttpClient>;
export type CreateAuthorizerError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an Authorizer for an API.
 */
export declare const createAuthorizer: API.OperationMethod<CreateAuthorizerRequest, CreateAuthorizerResponse, CreateAuthorizerError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Deployment for an API.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest, CreateDeploymentResponse, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateDomainNameError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a domain name.
 */
export declare const createDomainName: API.OperationMethod<CreateDomainNameRequest, CreateDomainNameResponse, CreateDomainNameError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an Integration.
 */
export declare const createIntegration: API.OperationMethod<CreateIntegrationRequest, CreateIntegrationResult, CreateIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an IntegrationResponses.
 */
export declare const createIntegrationResponse: API.OperationMethod<CreateIntegrationResponseRequest, CreateIntegrationResponseResponse, CreateIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type CreateModelError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Model for an API.
 */
export declare const createModel: API.OperationMethod<CreateModelRequest, CreateModelResponse, CreateModelError, Credentials | HttpClient.HttpClient>;
export type CreatePortalError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Creates a portal.
 */
export declare const createPortal: API.OperationMethod<CreatePortalRequest, CreatePortalResponse, CreatePortalError, Credentials | HttpClient.HttpClient>;
export type CreatePortalProductError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new portal product.
 */
export declare const createPortalProduct: API.OperationMethod<CreatePortalProductRequest, CreatePortalProductResponse, CreatePortalProductError, Credentials | HttpClient.HttpClient>;
export type CreateProductPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new product page for a portal product.
 */
export declare const createProductPage: API.OperationMethod<CreateProductPageRequest, CreateProductPageResponse, CreateProductPageError, Credentials | HttpClient.HttpClient>;
export type CreateProductRestEndpointPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a product REST endpoint page for a portal product.
 */
export declare const createProductRestEndpointPage: API.OperationMethod<CreateProductRestEndpointPageRequest, CreateProductRestEndpointPageResponse, CreateProductRestEndpointPageError, Credentials | HttpClient.HttpClient>;
export type CreateRouteError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Route for an API.
 */
export declare const createRoute: API.OperationMethod<CreateRouteRequest, CreateRouteResult, CreateRouteError, Credentials | HttpClient.HttpClient>;
export type CreateRouteResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a RouteResponse for a Route.
 */
export declare const createRouteResponse: API.OperationMethod<CreateRouteResponseRequest, CreateRouteResponseResponse, CreateRouteResponseError, Credentials | HttpClient.HttpClient>;
export type CreateRoutingRuleError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a RoutingRule.
 */
export declare const createRoutingRule: API.OperationMethod<CreateRoutingRuleRequest, CreateRoutingRuleResponse, CreateRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type CreateStageError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Stage for an API.
 */
export declare const createStage: API.OperationMethod<CreateStageRequest, CreateStageResponse, CreateStageError, Credentials | HttpClient.HttpClient>;
export type CreateVpcLinkError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Creates a VPC link.
 */
export declare const createVpcLink: API.OperationMethod<CreateVpcLinkRequest, CreateVpcLinkResponse, CreateVpcLinkError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessLogSettingsError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the AccessLogSettings for a Stage. To disable access logging for a Stage, delete its AccessLogSettings.
 */
export declare const deleteAccessLogSettings: API.OperationMethod<DeleteAccessLogSettingsRequest, DeleteAccessLogSettingsResponse, DeleteAccessLogSettingsError, Credentials | HttpClient.HttpClient>;
export type DeleteApiError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Api resource.
 */
export declare const deleteApi: API.OperationMethod<DeleteApiRequest, DeleteApiResponse, DeleteApiError, Credentials | HttpClient.HttpClient>;
export type DeleteApiMappingError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an API mapping.
 */
export declare const deleteApiMapping: API.OperationMethod<DeleteApiMappingRequest, DeleteApiMappingResponse, DeleteApiMappingError, Credentials | HttpClient.HttpClient>;
export type DeleteAuthorizerError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Authorizer.
 */
export declare const deleteAuthorizer: API.OperationMethod<DeleteAuthorizerRequest, DeleteAuthorizerResponse, DeleteAuthorizerError, Credentials | HttpClient.HttpClient>;
export type DeleteCorsConfigurationError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a CORS configuration.
 */
export declare const deleteCorsConfiguration: API.OperationMethod<DeleteCorsConfigurationRequest, DeleteCorsConfigurationResponse, DeleteCorsConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Deployment.
 */
export declare const deleteDeployment: API.OperationMethod<DeleteDeploymentRequest, DeleteDeploymentResponse, DeleteDeploymentError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainNameError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a domain name.
 */
export declare const deleteDomainName: API.OperationMethod<DeleteDomainNameRequest, DeleteDomainNameResponse, DeleteDomainNameError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Integration.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationRequest, DeleteIntegrationResponse, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationResponseError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an IntegrationResponses.
 */
export declare const deleteIntegrationResponse: API.OperationMethod<DeleteIntegrationResponseRequest, DeleteIntegrationResponseResponse, DeleteIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type DeleteModelError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Model.
 */
export declare const deleteModel: API.OperationMethod<DeleteModelRequest, DeleteModelResponse, DeleteModelError, Credentials | HttpClient.HttpClient>;
export type DeletePortalError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a portal.
 */
export declare const deletePortal: API.OperationMethod<DeletePortalRequest, DeletePortalResponse, DeletePortalError, Credentials | HttpClient.HttpClient>;
export type DeletePortalProductError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a portal product.
 */
export declare const deletePortalProduct: API.OperationMethod<DeletePortalProductRequest, DeletePortalProductResponse, DeletePortalProductError, Credentials | HttpClient.HttpClient>;
export type DeletePortalProductSharingPolicyError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the sharing policy for a portal product.
 */
export declare const deletePortalProductSharingPolicy: API.OperationMethod<DeletePortalProductSharingPolicyRequest, DeletePortalProductSharingPolicyResponse, DeletePortalProductSharingPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteProductPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a product page of a portal product.
 */
export declare const deleteProductPage: API.OperationMethod<DeleteProductPageRequest, DeleteProductPageResponse, DeleteProductPageError, Credentials | HttpClient.HttpClient>;
export type DeleteProductRestEndpointPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a product REST endpoint page.
 */
export declare const deleteProductRestEndpointPage: API.OperationMethod<DeleteProductRestEndpointPageRequest, DeleteProductRestEndpointPageResponse, DeleteProductRestEndpointPageError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Route.
 */
export declare const deleteRoute: API.OperationMethod<DeleteRouteRequest, DeleteRouteResponse, DeleteRouteError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteRequestParameterError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a route request parameter. Supported only for WebSocket APIs.
 */
export declare const deleteRouteRequestParameter: API.OperationMethod<DeleteRouteRequestParameterRequest, DeleteRouteRequestParameterResponse, DeleteRouteRequestParameterError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteResponseError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a RouteResponse.
 */
export declare const deleteRouteResponse: API.OperationMethod<DeleteRouteResponseRequest, DeleteRouteResponseResponse, DeleteRouteResponseError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteSettingsError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the RouteSettings for a stage.
 */
export declare const deleteRouteSettings: API.OperationMethod<DeleteRouteSettingsRequest, DeleteRouteSettingsResponse, DeleteRouteSettingsError, Credentials | HttpClient.HttpClient>;
export type DeleteRoutingRuleError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a routing rule.
 */
export declare const deleteRoutingRule: API.OperationMethod<DeleteRoutingRuleRequest, DeleteRoutingRuleResponse, DeleteRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteStageError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Stage.
 */
export declare const deleteStage: API.OperationMethod<DeleteStageRequest, DeleteStageResponse, DeleteStageError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcLinkError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a VPC link.
 */
export declare const deleteVpcLink: API.OperationMethod<DeleteVpcLinkRequest, DeleteVpcLinkResponse, DeleteVpcLinkError, Credentials | HttpClient.HttpClient>;
export type DisablePortalError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the publication of a portal portal.
 */
export declare const disablePortal: API.OperationMethod<DisablePortalRequest, DisablePortalResponse, DisablePortalError, Credentials | HttpClient.HttpClient>;
export type ExportApiError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 *
 */
export declare const exportApi: API.OperationMethod<ExportApiRequest, ExportApiResponse, ExportApiError, Credentials | HttpClient.HttpClient>;
export type GetApiError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an Api resource.
 */
export declare const getApi: API.OperationMethod<GetApiRequest, GetApiResponse, GetApiError, Credentials | HttpClient.HttpClient>;
export type GetApiMappingError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an API mapping.
 */
export declare const getApiMapping: API.OperationMethod<GetApiMappingRequest, GetApiMappingResponse, GetApiMappingError, Credentials | HttpClient.HttpClient>;
export type GetApiMappingsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets API mappings.
 */
export declare const getApiMappings: API.OperationMethod<GetApiMappingsRequest, GetApiMappingsResponse, GetApiMappingsError, Credentials | HttpClient.HttpClient>;
export type GetApisError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a collection of Api resources.
 */
export declare const getApis: API.OperationMethod<GetApisRequest, GetApisResponse, GetApisError, Credentials | HttpClient.HttpClient>;
export type GetAuthorizerError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an Authorizer.
 */
export declare const getAuthorizer: API.OperationMethod<GetAuthorizerRequest, GetAuthorizerResponse, GetAuthorizerError, Credentials | HttpClient.HttpClient>;
export type GetAuthorizersError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Authorizers for an API.
 */
export declare const getAuthorizers: API.OperationMethod<GetAuthorizersRequest, GetAuthorizersResponse, GetAuthorizersError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a Deployment.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentRequest, GetDeploymentResponse, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Deployments for an API.
 */
export declare const getDeployments: API.OperationMethod<GetDeploymentsRequest, GetDeploymentsResponse, GetDeploymentsError, Credentials | HttpClient.HttpClient>;
export type GetDomainNameError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a domain name.
 */
export declare const getDomainName: API.OperationMethod<GetDomainNameRequest, GetDomainNameResponse, GetDomainNameError, Credentials | HttpClient.HttpClient>;
export type GetDomainNamesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the domain names for an AWS account.
 */
export declare const getDomainNames: API.OperationMethod<GetDomainNamesRequest, GetDomainNamesResponse, GetDomainNamesError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an Integration.
 */
export declare const getIntegration: API.OperationMethod<GetIntegrationRequest, GetIntegrationResult, GetIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationResponseError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an IntegrationResponses.
 */
export declare const getIntegrationResponse: API.OperationMethod<GetIntegrationResponseRequest, GetIntegrationResponseResponse, GetIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationResponsesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the IntegrationResponses for an Integration.
 */
export declare const getIntegrationResponses: API.OperationMethod<GetIntegrationResponsesRequest, GetIntegrationResponsesResponse, GetIntegrationResponsesError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Integrations for an API.
 */
export declare const getIntegrations: API.OperationMethod<GetIntegrationsRequest, GetIntegrationsResponse, GetIntegrationsError, Credentials | HttpClient.HttpClient>;
export type GetModelError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a Model.
 */
export declare const getModel: API.OperationMethod<GetModelRequest, GetModelResponse, GetModelError, Credentials | HttpClient.HttpClient>;
export type GetModelsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Models for an API.
 */
export declare const getModels: API.OperationMethod<GetModelsRequest, GetModelsResponse, GetModelsError, Credentials | HttpClient.HttpClient>;
export type GetModelTemplateError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a model template.
 */
export declare const getModelTemplate: API.OperationMethod<GetModelTemplateRequest, GetModelTemplateResponse, GetModelTemplateError, Credentials | HttpClient.HttpClient>;
export type GetPortalError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a portal.
 */
export declare const getPortal: API.OperationMethod<GetPortalRequest, GetPortalResponse, GetPortalError, Credentials | HttpClient.HttpClient>;
export type GetPortalProductError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a portal product.
 */
export declare const getPortalProduct: API.OperationMethod<GetPortalProductRequest, GetPortalProductResponse, GetPortalProductError, Credentials | HttpClient.HttpClient>;
export type GetPortalProductSharingPolicyError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the sharing policy for a portal product.
 */
export declare const getPortalProductSharingPolicy: API.OperationMethod<GetPortalProductSharingPolicyRequest, GetPortalProductSharingPolicyResponse, GetPortalProductSharingPolicyError, Credentials | HttpClient.HttpClient>;
export type GetProductPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a product page of a portal product.
 */
export declare const getProductPage: API.OperationMethod<GetProductPageRequest, GetProductPageResponse, GetProductPageError, Credentials | HttpClient.HttpClient>;
export type GetProductRestEndpointPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a product REST endpoint page.
 */
export declare const getProductRestEndpointPage: API.OperationMethod<GetProductRestEndpointPageRequest, GetProductRestEndpointPageResponse, GetProductRestEndpointPageError, Credentials | HttpClient.HttpClient>;
export type GetRouteError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a Route.
 */
export declare const getRoute: API.OperationMethod<GetRouteRequest, GetRouteResult, GetRouteError, Credentials | HttpClient.HttpClient>;
export type GetRouteResponseError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a RouteResponse.
 */
export declare const getRouteResponse: API.OperationMethod<GetRouteResponseRequest, GetRouteResponseResponse, GetRouteResponseError, Credentials | HttpClient.HttpClient>;
export type GetRouteResponsesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the RouteResponses for a Route.
 */
export declare const getRouteResponses: API.OperationMethod<GetRouteResponsesRequest, GetRouteResponsesResponse, GetRouteResponsesError, Credentials | HttpClient.HttpClient>;
export type GetRoutesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Routes for an API.
 */
export declare const getRoutes: API.OperationMethod<GetRoutesRequest, GetRoutesResponse, GetRoutesError, Credentials | HttpClient.HttpClient>;
export type GetRoutingRuleError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a routing rule.
 */
export declare const getRoutingRule: API.OperationMethod<GetRoutingRuleRequest, GetRoutingRuleResponse, GetRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type GetStageError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a Stage.
 */
export declare const getStage: API.OperationMethod<GetStageRequest, GetStageResponse, GetStageError, Credentials | HttpClient.HttpClient>;
export type GetStagesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Stages for an API.
 */
export declare const getStages: API.OperationMethod<GetStagesRequest, GetStagesResponse, GetStagesError, Credentials | HttpClient.HttpClient>;
export type GetTagsError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a collection of Tag resources.
 */
export declare const getTags: API.OperationMethod<GetTagsRequest, GetTagsResponse, GetTagsError, Credentials | HttpClient.HttpClient>;
export type GetVpcLinkError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a VPC link.
 */
export declare const getVpcLink: API.OperationMethod<GetVpcLinkRequest, GetVpcLinkResponse, GetVpcLinkError, Credentials | HttpClient.HttpClient>;
export type GetVpcLinksError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a collection of VPC links.
 */
export declare const getVpcLinks: API.OperationMethod<GetVpcLinksRequest, GetVpcLinksResponse, GetVpcLinksError, Credentials | HttpClient.HttpClient>;
export type ImportApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Imports an API.
 */
export declare const importApi: API.OperationMethod<ImportApiRequest, ImportApiResponse, ImportApiError, Credentials | HttpClient.HttpClient>;
export type ListPortalProductsError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Lists portal products.
 */
export declare const listPortalProducts: API.OperationMethod<ListPortalProductsRequest, ListPortalProductsResponse, ListPortalProductsError, Credentials | HttpClient.HttpClient>;
export type ListPortalsError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Lists portals.
 */
export declare const listPortals: API.OperationMethod<ListPortalsRequest, ListPortalsResponse, ListPortalsError, Credentials | HttpClient.HttpClient>;
export type ListProductPagesError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the product pages for a portal product.
 */
export declare const listProductPages: API.OperationMethod<ListProductPagesRequest, ListProductPagesResponse, ListProductPagesError, Credentials | HttpClient.HttpClient>;
export type ListProductRestEndpointPagesError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the product REST endpoint pages of a portal product.
 */
export declare const listProductRestEndpointPages: API.OperationMethod<ListProductRestEndpointPagesRequest, ListProductRestEndpointPagesResponse, ListProductRestEndpointPagesError, Credentials | HttpClient.HttpClient>;
export type ListRoutingRulesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists routing rules.
 */
export declare const listRoutingRules: API.PaginatedOperationMethod<ListRoutingRulesRequest, ListRoutingRulesResponse, ListRoutingRulesError, Credentials | HttpClient.HttpClient, RoutingRule>;
export type PreviewPortalError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a portal preview.
 */
export declare const previewPortal: API.OperationMethod<PreviewPortalRequest, PreviewPortalResponse, PreviewPortalError, Credentials | HttpClient.HttpClient>;
export type PublishPortalError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Publishes a portal.
 */
export declare const publishPortal: API.OperationMethod<PublishPortalRequest, PublishPortalResponse, PublishPortalError, Credentials | HttpClient.HttpClient>;
export type PutPortalProductSharingPolicyError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the sharing policy for a portal product.
 */
export declare const putPortalProductSharingPolicy: API.OperationMethod<PutPortalProductSharingPolicyRequest, PutPortalProductSharingPolicyResponse, PutPortalProductSharingPolicyError, Credentials | HttpClient.HttpClient>;
export type PutRoutingRuleError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a routing rule.
 */
export declare const putRoutingRule: API.OperationMethod<PutRoutingRuleRequest, PutRoutingRuleResponse, PutRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type ReimportApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Puts an Api resource.
 */
export declare const reimportApi: API.OperationMethod<ReimportApiRequest, ReimportApiResponse, ReimportApiError, Credentials | HttpClient.HttpClient>;
export type ResetAuthorizersCacheError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Resets all authorizer cache entries on a stage. Supported only for HTTP APIs.
 */
export declare const resetAuthorizersCache: API.OperationMethod<ResetAuthorizersCacheRequest, ResetAuthorizersCacheResponse, ResetAuthorizersCacheError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new Tag resource to represent a tag.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Tag.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an Api resource.
 */
export declare const updateApi: API.OperationMethod<UpdateApiRequest, UpdateApiResponse, UpdateApiError, Credentials | HttpClient.HttpClient>;
export type UpdateApiMappingError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * The API mapping.
 */
export declare const updateApiMapping: API.OperationMethod<UpdateApiMappingRequest, UpdateApiMappingResponse, UpdateApiMappingError, Credentials | HttpClient.HttpClient>;
export type UpdateAuthorizerError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an Authorizer.
 */
export declare const updateAuthorizer: API.OperationMethod<UpdateAuthorizerRequest, UpdateAuthorizerResponse, UpdateAuthorizerError, Credentials | HttpClient.HttpClient>;
export type UpdateDeploymentError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a Deployment.
 */
export declare const updateDeployment: API.OperationMethod<UpdateDeploymentRequest, UpdateDeploymentResponse, UpdateDeploymentError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainNameError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a domain name.
 */
export declare const updateDomainName: API.OperationMethod<UpdateDomainNameRequest, UpdateDomainNameResponse, UpdateDomainNameError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an Integration.
 */
export declare const updateIntegration: API.OperationMethod<UpdateIntegrationRequest, UpdateIntegrationResult, UpdateIntegrationError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an IntegrationResponses.
 */
export declare const updateIntegrationResponse: API.OperationMethod<UpdateIntegrationResponseRequest, UpdateIntegrationResponseResponse, UpdateIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type UpdateModelError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a Model.
 */
export declare const updateModel: API.OperationMethod<UpdateModelRequest, UpdateModelResponse, UpdateModelError, Credentials | HttpClient.HttpClient>;
export type UpdatePortalError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a portal.
 */
export declare const updatePortal: API.OperationMethod<UpdatePortalRequest, UpdatePortalResponse, UpdatePortalError, Credentials | HttpClient.HttpClient>;
export type UpdatePortalProductError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the portal product.
 */
export declare const updatePortalProduct: API.OperationMethod<UpdatePortalProductRequest, UpdatePortalProductResponse, UpdatePortalProductError, Credentials | HttpClient.HttpClient>;
export type UpdateProductPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a product page of a portal product.
 */
export declare const updateProductPage: API.OperationMethod<UpdateProductPageRequest, UpdateProductPageResponse, UpdateProductPageError, Credentials | HttpClient.HttpClient>;
export type UpdateProductRestEndpointPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a product REST endpoint page.
 */
export declare const updateProductRestEndpointPage: API.OperationMethod<UpdateProductRestEndpointPageRequest, UpdateProductRestEndpointPageResponse, UpdateProductRestEndpointPageError, Credentials | HttpClient.HttpClient>;
export type UpdateRouteError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a Route.
 */
export declare const updateRoute: API.OperationMethod<UpdateRouteRequest, UpdateRouteResult, UpdateRouteError, Credentials | HttpClient.HttpClient>;
export type UpdateRouteResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a RouteResponse.
 */
export declare const updateRouteResponse: API.OperationMethod<UpdateRouteResponseRequest, UpdateRouteResponseResponse, UpdateRouteResponseError, Credentials | HttpClient.HttpClient>;
export type UpdateStageError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a Stage.
 */
export declare const updateStage: API.OperationMethod<UpdateStageRequest, UpdateStageResponse, UpdateStageError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcLinkError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a VPC link.
 */
export declare const updateVpcLink: API.OperationMethod<UpdateVpcLinkRequest, UpdateVpcLinkResponse, UpdateVpcLinkError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=apigatewayv2.d.ts.map