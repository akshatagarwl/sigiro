import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalFailureException_base: S.Class<InternalFailureException, S.TaggedStruct<"InternalFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ClientToken = string;
export type ConnectorDestinationId = string;
export type AccountAssociationName = string;
export type AccountAssociationDescription = string;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export type AuthMaterialName = string;
export interface GeneralAuthorizationName {
    AuthMaterialName?: string;
}
export declare const GeneralAuthorizationName: S.Schema<GeneralAuthorizationName>;
export interface CreateAccountAssociationRequest {
    ClientToken?: string;
    ConnectorDestinationId: string;
    Name?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    GeneralAuthorization?: GeneralAuthorizationName;
}
export declare const CreateAccountAssociationRequest: S.Schema<CreateAccountAssociationRequest>;
export type OAuthAuthorizationUrlOutput = string | redacted.Redacted<string>;
export type AccountAssociationId = string;
export type AssociationState = "ASSOCIATION_IN_PROGRESS" | "ASSOCIATION_FAILED" | "ASSOCIATION_SUCCEEDED" | "ASSOCIATION_DELETING" | "REFRESH_TOKEN_EXPIRED" | (string & {});
export declare const AssociationState: any;
export type AccountAssociationArn = string;
export interface CreateAccountAssociationResponse {
    OAuthAuthorizationUrl: string | redacted.Redacted<string>;
    AccountAssociationId: string;
    AssociationState: AssociationState;
    Arn?: string;
}
export declare const CreateAccountAssociationResponse: S.Schema<CreateAccountAssociationResponse>;
export type DisplayName = string;
export type LambdaArn = string;
export interface LambdaConfig {
    arn: string;
}
export declare const LambdaConfig: S.Schema<LambdaConfig>;
export interface EndpointConfig {
    lambda?: LambdaConfig;
}
export declare const EndpointConfig: S.Schema<EndpointConfig>;
export type CloudConnectorDescription = string;
export type EndpointType = "LAMBDA" | (string & {});
export declare const EndpointType: any;
export interface CreateCloudConnectorRequest {
    Name: string;
    EndpointConfig: EndpointConfig;
    Description?: string;
    EndpointType?: EndpointType;
    ClientToken?: string;
}
export declare const CreateCloudConnectorRequest: S.Schema<CreateCloudConnectorRequest>;
export type CloudConnectorId = string;
export interface CreateCloudConnectorResponse {
    Id?: string;
}
export declare const CreateCloudConnectorResponse: S.Schema<CreateCloudConnectorResponse>;
export type ConnectorDestinationName = string;
export type ConnectorDestinationDescription = string;
export type AuthType = "OAUTH" | (string & {});
export declare const AuthType: any;
export type AuthUrl = string;
export type TokenUrl = string;
export type TokenEndpointAuthenticationScheme = "HTTP_BASIC" | "REQUEST_BODY_CREDENTIALS" | (string & {});
export declare const TokenEndpointAuthenticationScheme: any;
export interface ProactiveRefreshTokenRenewal {
    enabled?: boolean;
    DaysBeforeRenewal?: number;
}
export declare const ProactiveRefreshTokenRenewal: S.Schema<ProactiveRefreshTokenRenewal>;
export interface OAuthConfig {
    authUrl: string;
    tokenUrl: string;
    scope?: string;
    tokenEndpointAuthenticationScheme: TokenEndpointAuthenticationScheme;
    oAuthCompleteRedirectUrl?: string;
    proactiveRefreshTokenRenewal?: ProactiveRefreshTokenRenewal;
}
export declare const OAuthConfig: S.Schema<OAuthConfig>;
export type SecretsManagerArn = string;
export type SecretsManagerVersionId = string;
export interface SecretsManager {
    arn: string;
    versionId: string;
}
export declare const SecretsManager: S.Schema<SecretsManager>;
export interface AuthMaterial {
    SecretsManager: SecretsManager;
    AuthMaterialName: string;
}
export declare const AuthMaterial: S.Schema<AuthMaterial>;
export type AuthMaterials = AuthMaterial[];
export declare const AuthMaterials: any;
export interface AuthConfig {
    oAuth?: OAuthConfig;
    GeneralAuthorization?: AuthMaterial[];
}
export declare const AuthConfig: S.Schema<AuthConfig>;
export interface CreateConnectorDestinationRequest {
    Name?: string;
    Description?: string;
    CloudConnectorId: string;
    AuthType?: AuthType;
    AuthConfig: AuthConfig;
    SecretsManager?: SecretsManager;
    ClientToken?: string;
}
export declare const CreateConnectorDestinationRequest: S.Schema<CreateConnectorDestinationRequest>;
export interface CreateConnectorDestinationResponse {
    Id?: string;
}
export declare const CreateConnectorDestinationResponse: S.Schema<CreateConnectorDestinationResponse>;
export type CredentialLockerName = string | redacted.Redacted<string>;
export interface CreateCredentialLockerRequest {
    Name?: string | redacted.Redacted<string>;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateCredentialLockerRequest: S.Schema<CreateCredentialLockerRequest>;
export type CredentialLockerId = string;
export type CredentialLockerArn = string;
export type CredentialLockerCreatedAt = Date;
export interface CreateCredentialLockerResponse {
    Id?: string;
    Arn?: string;
    CreatedAt?: Date;
}
export declare const CreateCredentialLockerResponse: S.Schema<CreateCredentialLockerResponse>;
export type DeliveryDestinationArn = string;
export type DeliveryDestinationType = "KINESIS" | (string & {});
export declare const DeliveryDestinationType: any;
export type DestinationName = string;
export type DeliveryDestinationRoleArn = string;
export type DestinationDescription = string;
export interface CreateDestinationRequest {
    DeliveryDestinationArn: string;
    DeliveryDestinationType: DeliveryDestinationType;
    Name: string;
    RoleArn: string;
    ClientToken?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDestinationRequest: S.Schema<CreateDestinationRequest>;
export interface CreateDestinationResponse {
    Name?: string;
}
export declare const CreateDestinationResponse: S.Schema<CreateDestinationResponse>;
export type SmartHomeResourceType = string;
export type SmartHomeResourceId = string;
export type LogLevel = "DEBUG" | "ERROR" | "INFO" | "WARN" | (string & {});
export declare const LogLevel: any;
export interface CreateEventLogConfigurationRequest {
    ResourceType: string;
    ResourceId?: string;
    EventLogLevel: LogLevel;
    ClientToken?: string;
}
export declare const CreateEventLogConfigurationRequest: S.Schema<CreateEventLogConfigurationRequest>;
export type LogConfigurationId = string;
export interface CreateEventLogConfigurationResponse {
    Id?: string;
}
export declare const CreateEventLogConfigurationResponse: S.Schema<CreateEventLogConfigurationResponse>;
export type Role = "CONTROLLER" | "DEVICE" | (string & {});
export declare const Role: any;
export type Owner = string | redacted.Redacted<string>;
export type AuthMaterialString = string | redacted.Redacted<string>;
export type AuthMaterialType = "CUSTOM_PROTOCOL_QR_BAR_CODE" | "WIFI_SETUP_QR_BAR_CODE" | "ZWAVE_QR_BAR_CODE" | "ZIGBEE_QR_BAR_CODE" | "DISCOVERED_DEVICE" | "PRE_ONBOARDED_CLOUD" | (string & {});
export declare const AuthMaterialType: any;
export type EnableAsProvisioner = boolean;
export type EnableAsProvisionee = boolean;
export type TimeoutInMinutes = number;
export interface WiFiSimpleSetupConfiguration {
    EnableAsProvisioner?: boolean;
    EnableAsProvisionee?: boolean;
    TimeoutInMinutes?: number;
}
export declare const WiFiSimpleSetupConfiguration: S.Schema<WiFiSimpleSetupConfiguration>;
export type SerialNumber = string | redacted.Redacted<string>;
export type Brand = string | redacted.Redacted<string>;
export type Model = string | redacted.Redacted<string>;
export type Name = string;
export type CapabilityReportVersion = string;
export type NodeId = string;
export type EndpointId = string;
export type DeviceType = string;
export type DeviceTypes = string[];
export declare const DeviceTypes: any;
export type SchemaVersionedId = string;
export type CapabilityName = string;
export type CapabilityVersion = string;
export type PropertyName = string;
export type CapabilityReportProperties = string[];
export declare const CapabilityReportProperties: any;
export type ActionName = string;
export type CapabilityReportActions = string[];
export declare const CapabilityReportActions: any;
export type EventName = string;
export type CapabilityReportEvents = string[];
export declare const CapabilityReportEvents: any;
export interface CapabilityReportCapability {
    id: string;
    name: string;
    version: string;
    properties: string[];
    actions: string[];
    events: string[];
}
export declare const CapabilityReportCapability: S.Schema<CapabilityReportCapability>;
export type CapabilityReportCapabilities = CapabilityReportCapability[];
export declare const CapabilityReportCapabilities: any;
export interface CapabilityReportEndpoint {
    id: string;
    deviceTypes: string[];
    capabilities: CapabilityReportCapability[];
}
export declare const CapabilityReportEndpoint: S.Schema<CapabilityReportEndpoint>;
export type CapabilityReportEndpoints = CapabilityReportEndpoint[];
export declare const CapabilityReportEndpoints: any;
export interface CapabilityReport {
    version: string;
    nodeId?: string;
    endpoints: CapabilityReportEndpoint[];
}
export declare const CapabilityReport: S.Schema<CapabilityReport>;
export type SchemaVersionFormat = "AWS" | "ZCL" | "CONNECTOR" | (string & {});
export declare const SchemaVersionFormat: any;
export type ExtrinsicSchemaId = string;
export type MatterCapabilityReportClusterRevisionId = number;
export type ValidationSchema = unknown;
export interface CapabilitySchemaItem {
    Format: SchemaVersionFormat;
    CapabilityId: string;
    ExtrinsicId: string;
    ExtrinsicVersion: number;
    Schema: any;
}
export declare const CapabilitySchemaItem: S.Schema<CapabilitySchemaItem>;
export type CapabilitySchemas = CapabilitySchemaItem[];
export declare const CapabilitySchemas: any;
export type Capabilities = string;
export type Classification = string | redacted.Redacted<string>;
export type AttributeName = string;
export type AttributeValue = string;
export type MetaData = {
    [key: string]: string | undefined;
};
export declare const MetaData: any;
export interface CreateManagedThingRequest {
    Role: Role;
    Owner?: string | redacted.Redacted<string>;
    CredentialLockerId?: string;
    AuthenticationMaterial: string | redacted.Redacted<string>;
    AuthenticationMaterialType: AuthMaterialType;
    WiFiSimpleSetupConfiguration?: WiFiSimpleSetupConfiguration;
    SerialNumber?: string | redacted.Redacted<string>;
    Brand?: string | redacted.Redacted<string>;
    Model?: string | redacted.Redacted<string>;
    Name?: string;
    CapabilityReport?: CapabilityReport;
    CapabilitySchemas?: CapabilitySchemaItem[];
    Capabilities?: string;
    ClientToken?: string;
    Classification?: string | redacted.Redacted<string>;
    Tags?: {
        [key: string]: string | undefined;
    };
    MetaData?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateManagedThingRequest: S.Schema<CreateManagedThingRequest>;
export type ManagedThingId = string;
export type ManagedThingArn = string;
export type CreatedAt = Date;
export interface CreateManagedThingResponse {
    Id?: string;
    Arn?: string;
    CreatedAt?: Date;
}
export declare const CreateManagedThingResponse: S.Schema<CreateManagedThingResponse>;
export type EventType = "DEVICE_COMMAND" | "DEVICE_COMMAND_REQUEST" | "DEVICE_DISCOVERY_STATUS" | "DEVICE_EVENT" | "DEVICE_LIFE_CYCLE" | "DEVICE_STATE" | "DEVICE_OTA" | "DEVICE_WSS" | "CONNECTOR_ASSOCIATION" | "ACCOUNT_ASSOCIATION" | "CONNECTOR_ERROR_REPORT" | (string & {});
export declare const EventType: any;
export interface CreateNotificationConfigurationRequest {
    EventType: EventType;
    DestinationName: string;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateNotificationConfigurationRequest: S.Schema<CreateNotificationConfigurationRequest>;
export interface CreateNotificationConfigurationResponse {
    EventType?: EventType;
}
export declare const CreateNotificationConfigurationResponse: S.Schema<CreateNotificationConfigurationResponse>;
export type OtaDescription = string;
export type S3Url = string;
export type OtaProtocol = "HTTP" | (string & {});
export declare const OtaProtocol: any;
export type Target = string[];
export declare const Target: any;
export type OtaTaskConfigurationId = string;
export type OtaMechanism = "PUSH" | (string & {});
export declare const OtaMechanism: any;
export type OtaType = "ONE_TIME" | "CONTINUOUS" | (string & {});
export declare const OtaType: any;
export type OtaTargetQueryString = string;
export type SchedulingConfigEndBehavior = "STOP_ROLLOUT" | "CANCEL" | "FORCE_CANCEL" | (string & {});
export declare const SchedulingConfigEndBehavior: any;
export type EndTime = string;
export type DurationInMinutes = number;
export type StartTime = string;
export interface ScheduleMaintenanceWindow {
    DurationInMinutes?: number;
    StartTime?: string;
}
export declare const ScheduleMaintenanceWindow: S.Schema<ScheduleMaintenanceWindow>;
export type ScheduleMaintenanceWindowList = ScheduleMaintenanceWindow[];
export declare const ScheduleMaintenanceWindowList: any;
export type ScheduleStartTime = string;
export interface OtaTaskSchedulingConfig {
    EndBehavior?: SchedulingConfigEndBehavior;
    EndTime?: string;
    MaintenanceWindows?: ScheduleMaintenanceWindow[];
    StartTime?: string;
}
export declare const OtaTaskSchedulingConfig: S.Schema<OtaTaskSchedulingConfig>;
export type RetryCriteriaFailureType = "FAILED" | "TIMED_OUT" | "ALL" | (string & {});
export declare const RetryCriteriaFailureType: any;
export type MinNumberOfRetries = number;
export interface RetryConfigCriteria {
    FailureType?: RetryCriteriaFailureType;
    MinNumberOfRetries?: number;
}
export declare const RetryConfigCriteria: S.Schema<RetryConfigCriteria>;
export type RetryConfigCriteriaList = RetryConfigCriteria[];
export declare const RetryConfigCriteriaList: any;
export interface OtaTaskExecutionRetryConfig {
    RetryConfigCriteria?: RetryConfigCriteria[];
}
export declare const OtaTaskExecutionRetryConfig: S.Schema<OtaTaskExecutionRetryConfig>;
export interface CreateOtaTaskRequest {
    Description?: string;
    S3Url: string;
    Protocol?: OtaProtocol;
    Target?: string[];
    TaskConfigurationId?: string;
    OtaMechanism?: OtaMechanism;
    OtaType: OtaType;
    OtaTargetQueryString?: string;
    ClientToken?: string;
    OtaSchedulingConfig?: OtaTaskSchedulingConfig;
    OtaTaskExecutionRetryConfig?: OtaTaskExecutionRetryConfig;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateOtaTaskRequest: S.Schema<CreateOtaTaskRequest>;
export type OtaTaskId = string;
export type OtaTaskArn = string;
export interface CreateOtaTaskResponse {
    TaskId?: string;
    TaskArn?: string;
    Description?: string;
}
export declare const CreateOtaTaskResponse: S.Schema<CreateOtaTaskResponse>;
export type OtaTaskConfigurationName = string | redacted.Redacted<string>;
export type AbortCriteriaAction = "CANCEL" | (string & {});
export declare const AbortCriteriaAction: any;
export type AbortCriteriaFailureType = "FAILED" | "REJECTED" | "TIMED_OUT" | "ALL" | (string & {});
export declare const AbortCriteriaFailureType: any;
export type MinNumberOfExecutedThings = number;
export type ThresholdPercentage = number;
export interface AbortConfigCriteria {
    Action?: AbortCriteriaAction;
    FailureType?: AbortCriteriaFailureType;
    MinNumberOfExecutedThings?: number;
    ThresholdPercentage?: number;
}
export declare const AbortConfigCriteria: S.Schema<AbortConfigCriteria>;
export type AbortConfigCriteriaList = AbortConfigCriteria[];
export declare const AbortConfigCriteriaList: any;
export interface OtaTaskAbortConfig {
    AbortConfigCriteriaList?: AbortConfigCriteria[];
}
export declare const OtaTaskAbortConfig: S.Schema<OtaTaskAbortConfig>;
export type BaseRatePerMinute = number;
export type IncrementFactor = number;
export type NumberOfNotifiedThings = number;
export type NumberOfSucceededThings = number;
export interface RolloutRateIncreaseCriteria {
    numberOfNotifiedThings?: number;
    numberOfSucceededThings?: number;
}
export declare const RolloutRateIncreaseCriteria: S.Schema<RolloutRateIncreaseCriteria>;
export interface ExponentialRolloutRate {
    BaseRatePerMinute?: number;
    IncrementFactor?: number;
    RateIncreaseCriteria?: RolloutRateIncreaseCriteria;
}
export declare const ExponentialRolloutRate: S.Schema<ExponentialRolloutRate>;
export type MaximumPerMinute = number;
export interface OtaTaskExecutionRolloutConfig {
    ExponentialRolloutRate?: ExponentialRolloutRate;
    MaximumPerMinute?: number;
}
export declare const OtaTaskExecutionRolloutConfig: S.Schema<OtaTaskExecutionRolloutConfig>;
export type InProgressTimeoutInMinutes = number;
export interface OtaTaskTimeoutConfig {
    InProgressTimeoutInMinutes?: number;
}
export declare const OtaTaskTimeoutConfig: S.Schema<OtaTaskTimeoutConfig>;
export interface PushConfig {
    AbortConfig?: OtaTaskAbortConfig;
    RolloutConfig?: OtaTaskExecutionRolloutConfig;
    TimeoutConfig?: OtaTaskTimeoutConfig;
}
export declare const PushConfig: S.Schema<PushConfig>;
export interface CreateOtaTaskConfigurationRequest {
    Description?: string;
    Name?: string | redacted.Redacted<string>;
    PushConfig?: PushConfig;
    ClientToken?: string;
}
export declare const CreateOtaTaskConfigurationRequest: S.Schema<CreateOtaTaskConfigurationRequest>;
export interface CreateOtaTaskConfigurationResponse {
    TaskConfigurationId?: string;
}
export declare const CreateOtaTaskConfigurationResponse: S.Schema<CreateOtaTaskConfigurationResponse>;
export type ProvisioningType = "FLEET_PROVISIONING" | "JITR" | (string & {});
export declare const ProvisioningType: any;
export type CaCertificate = string | redacted.Redacted<string>;
export type ClaimCertificate = string | redacted.Redacted<string>;
export type ProvisioningProfileName = string;
export interface CreateProvisioningProfileRequest {
    ProvisioningType: ProvisioningType;
    CaCertificate?: string | redacted.Redacted<string>;
    ClaimCertificate?: string | redacted.Redacted<string>;
    Name?: string;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateProvisioningProfileRequest: S.Schema<CreateProvisioningProfileRequest>;
export type ProvisioningProfileArn = string;
export type ProvisioningProfileId = string;
export type ProvisioningProfileStatus = "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "CREATED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export declare const ProvisioningProfileStatus: any;
export type ClaimCertificatePrivateKey = string | redacted.Redacted<string>;
export interface CreateProvisioningProfileResponse {
    Arn?: string;
    Name?: string;
    ProvisioningType?: ProvisioningType;
    Id?: string;
    Status?: ProvisioningProfileStatus;
    ClaimCertificate?: string | redacted.Redacted<string>;
    ClaimCertificatePrivateKey?: string | redacted.Redacted<string>;
}
export declare const CreateProvisioningProfileResponse: S.Schema<CreateProvisioningProfileResponse>;
export interface DeleteAccountAssociationRequest {
    AccountAssociationId: string;
}
export declare const DeleteAccountAssociationRequest: S.Schema<DeleteAccountAssociationRequest>;
export interface DeleteAccountAssociationResponse {
}
export declare const DeleteAccountAssociationResponse: S.Schema<DeleteAccountAssociationResponse>;
export interface DeleteCloudConnectorRequest {
    Identifier: string;
}
export declare const DeleteCloudConnectorRequest: S.Schema<DeleteCloudConnectorRequest>;
export interface DeleteCloudConnectorResponse {
}
export declare const DeleteCloudConnectorResponse: S.Schema<DeleteCloudConnectorResponse>;
export interface DeleteConnectorDestinationRequest {
    Identifier: string;
}
export declare const DeleteConnectorDestinationRequest: S.Schema<DeleteConnectorDestinationRequest>;
export interface DeleteConnectorDestinationResponse {
}
export declare const DeleteConnectorDestinationResponse: S.Schema<DeleteConnectorDestinationResponse>;
export interface DeleteCredentialLockerRequest {
    Identifier: string;
}
export declare const DeleteCredentialLockerRequest: S.Schema<DeleteCredentialLockerRequest>;
export interface DeleteCredentialLockerResponse {
}
export declare const DeleteCredentialLockerResponse: S.Schema<DeleteCredentialLockerResponse>;
export interface DeleteDestinationRequest {
    Name: string;
}
export declare const DeleteDestinationRequest: S.Schema<DeleteDestinationRequest>;
export interface DeleteDestinationResponse {
}
export declare const DeleteDestinationResponse: S.Schema<DeleteDestinationResponse>;
export interface DeleteEventLogConfigurationRequest {
    Id: string;
}
export declare const DeleteEventLogConfigurationRequest: S.Schema<DeleteEventLogConfigurationRequest>;
export interface DeleteEventLogConfigurationResponse {
}
export declare const DeleteEventLogConfigurationResponse: S.Schema<DeleteEventLogConfigurationResponse>;
export interface DeleteManagedThingRequest {
    Identifier: string;
    Force?: boolean;
}
export declare const DeleteManagedThingRequest: S.Schema<DeleteManagedThingRequest>;
export interface DeleteManagedThingResponse {
}
export declare const DeleteManagedThingResponse: S.Schema<DeleteManagedThingResponse>;
export interface DeleteNotificationConfigurationRequest {
    EventType: EventType;
}
export declare const DeleteNotificationConfigurationRequest: S.Schema<DeleteNotificationConfigurationRequest>;
export interface DeleteNotificationConfigurationResponse {
}
export declare const DeleteNotificationConfigurationResponse: S.Schema<DeleteNotificationConfigurationResponse>;
export interface DeleteOtaTaskRequest {
    Identifier: string;
}
export declare const DeleteOtaTaskRequest: S.Schema<DeleteOtaTaskRequest>;
export interface DeleteOtaTaskResponse {
}
export declare const DeleteOtaTaskResponse: S.Schema<DeleteOtaTaskResponse>;
export interface DeleteOtaTaskConfigurationRequest {
    Identifier: string;
}
export declare const DeleteOtaTaskConfigurationRequest: S.Schema<DeleteOtaTaskConfigurationRequest>;
export interface DeleteOtaTaskConfigurationResponse {
}
export declare const DeleteOtaTaskConfigurationResponse: S.Schema<DeleteOtaTaskConfigurationResponse>;
export interface DeleteProvisioningProfileRequest {
    Identifier: string;
}
export declare const DeleteProvisioningProfileRequest: S.Schema<DeleteProvisioningProfileRequest>;
export interface DeleteProvisioningProfileResponse {
}
export declare const DeleteProvisioningProfileResponse: S.Schema<DeleteProvisioningProfileResponse>;
export interface DeregisterAccountAssociationRequest {
    ManagedThingId: string;
    AccountAssociationId: string;
}
export declare const DeregisterAccountAssociationRequest: S.Schema<DeregisterAccountAssociationRequest>;
export interface DeregisterAccountAssociationResponse {
}
export declare const DeregisterAccountAssociationResponse: S.Schema<DeregisterAccountAssociationResponse>;
export interface GetAccountAssociationRequest {
    AccountAssociationId: string;
}
export declare const GetAccountAssociationRequest: S.Schema<GetAccountAssociationRequest>;
export type AccountAssociationErrorMessage = string;
export interface GetAccountAssociationResponse {
    AccountAssociationId: string;
    AssociationState: AssociationState;
    ErrorMessage?: string;
    ConnectorDestinationId?: string;
    Name?: string;
    Description?: string;
    Arn?: string;
    OAuthAuthorizationUrl: string | redacted.Redacted<string>;
    Tags?: {
        [key: string]: string | undefined;
    };
    GeneralAuthorization?: GeneralAuthorizationName;
}
export declare const GetAccountAssociationResponse: S.Schema<GetAccountAssociationResponse>;
export interface GetCloudConnectorRequest {
    Identifier: string;
}
export declare const GetCloudConnectorRequest: S.Schema<GetCloudConnectorRequest>;
export type CloudConnectorType = "LISTED" | "UNLISTED" | (string & {});
export declare const CloudConnectorType: any;
export interface GetCloudConnectorResponse {
    Name: string;
    EndpointConfig: EndpointConfig;
    Description?: string;
    EndpointType?: EndpointType;
    Id?: string;
    Type?: CloudConnectorType;
}
export declare const GetCloudConnectorResponse: S.Schema<GetCloudConnectorResponse>;
export interface GetConnectorDestinationRequest {
    Identifier: string;
}
export declare const GetConnectorDestinationRequest: S.Schema<GetConnectorDestinationRequest>;
export type OAuthCompleteRedirectUrl = string;
export interface GetConnectorDestinationResponse {
    Name?: string;
    Description?: string;
    CloudConnectorId?: string;
    Id?: string;
    AuthType?: AuthType;
    AuthConfig?: AuthConfig;
    SecretsManager?: SecretsManager;
    OAuthCompleteRedirectUrl?: string;
}
export declare const GetConnectorDestinationResponse: S.Schema<GetConnectorDestinationResponse>;
export interface GetCredentialLockerRequest {
    Identifier: string;
}
export declare const GetCredentialLockerRequest: S.Schema<GetCredentialLockerRequest>;
export interface GetCredentialLockerResponse {
    Id?: string;
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetCredentialLockerResponse: S.Schema<GetCredentialLockerResponse>;
export interface GetCustomEndpointRequest {
}
export declare const GetCustomEndpointRequest: S.Schema<GetCustomEndpointRequest>;
export type EndpointAddress = string;
export interface GetCustomEndpointResponse {
    EndpointAddress: string;
}
export declare const GetCustomEndpointResponse: S.Schema<GetCustomEndpointResponse>;
export interface GetDefaultEncryptionConfigurationRequest {
}
export declare const GetDefaultEncryptionConfigurationRequest: S.Schema<GetDefaultEncryptionConfigurationRequest>;
export type ConfigurationErrorCode = string;
export type ConfigurationErrorMessage = string;
export interface ConfigurationError {
    code?: string;
    message?: string;
}
export declare const ConfigurationError: S.Schema<ConfigurationError>;
export type ConfigurationState = "ENABLED" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | (string & {});
export declare const ConfigurationState: any;
export interface ConfigurationStatus {
    error?: ConfigurationError;
    state: ConfigurationState;
}
export declare const ConfigurationStatus: S.Schema<ConfigurationStatus>;
export type EncryptionType = "MANAGED_INTEGRATIONS_DEFAULT_ENCRYPTION" | "CUSTOMER_KEY_ENCRYPTION" | (string & {});
export declare const EncryptionType: any;
export type KmsKeyArn = string;
export interface GetDefaultEncryptionConfigurationResponse {
    configurationStatus: ConfigurationStatus;
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
}
export declare const GetDefaultEncryptionConfigurationResponse: S.Schema<GetDefaultEncryptionConfigurationResponse>;
export interface GetDestinationRequest {
    Name: string;
}
export declare const GetDestinationRequest: S.Schema<GetDestinationRequest>;
export type DestinationCreatedAt = Date;
export type DestinationUpdatedAt = Date;
export interface GetDestinationResponse {
    Description?: string;
    DeliveryDestinationArn?: string;
    DeliveryDestinationType?: DeliveryDestinationType;
    Name?: string;
    RoleArn?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetDestinationResponse: S.Schema<GetDestinationResponse>;
export type DeviceDiscoveryId = string;
export interface GetDeviceDiscoveryRequest {
    Identifier: string;
}
export declare const GetDeviceDiscoveryRequest: S.Schema<GetDeviceDiscoveryRequest>;
export type DeviceDiscoveryArn = string;
export type DiscoveryType = "ZWAVE" | "ZIGBEE" | "CLOUD" | "CUSTOM" | "CONTROLLER_CAPABILITY_REDISCOVERY" | (string & {});
export declare const DiscoveryType: any;
export type DeviceDiscoveryStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | "TIMED_OUT" | (string & {});
export declare const DeviceDiscoveryStatus: any;
export type DiscoveryStartedAt = Date;
export type ConnectorAssociationId = string;
export type DiscoveryFinishedAt = Date;
export interface GetDeviceDiscoveryResponse {
    Id: string;
    Arn: string;
    DiscoveryType: DiscoveryType;
    Status: DeviceDiscoveryStatus;
    StartedAt: Date;
    ControllerId?: string;
    ConnectorAssociationId?: string;
    AccountAssociationId?: string;
    FinishedAt?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetDeviceDiscoveryResponse: S.Schema<GetDeviceDiscoveryResponse>;
export interface GetEventLogConfigurationRequest {
    Id: string;
}
export declare const GetEventLogConfigurationRequest: S.Schema<GetEventLogConfigurationRequest>;
export interface GetEventLogConfigurationResponse {
    Id?: string;
    ResourceType?: string;
    ResourceId?: string;
    EventLogLevel?: LogLevel;
}
export declare const GetEventLogConfigurationResponse: S.Schema<GetEventLogConfigurationResponse>;
export interface GetHubConfigurationRequest {
}
export declare const GetHubConfigurationRequest: S.Schema<GetHubConfigurationRequest>;
export type HubTokenTimerExpirySettingInSeconds = number;
export type HubConfigurationUpdatedAt = Date;
export interface GetHubConfigurationResponse {
    HubTokenTimerExpirySettingInSeconds?: number;
    UpdatedAt?: Date;
}
export declare const GetHubConfigurationResponse: S.Schema<GetHubConfigurationResponse>;
export interface GetManagedThingRequest {
    Identifier: string;
}
export declare const GetManagedThingRequest: S.Schema<GetManagedThingRequest>;
export type AdvertisedProductId = string;
export type ProvisioningStatus = "UNASSOCIATED" | "PRE_ASSOCIATED" | "DISCOVERED" | "ACTIVATED" | "DELETION_FAILED" | "DELETE_IN_PROGRESS" | "ISOLATED" | "DELETED" | (string & {});
export declare const ProvisioningStatus: any;
export type UniversalProductCode = string | redacted.Redacted<string>;
export type InternationalArticleNumber = string | redacted.Redacted<string>;
export type ConnectorPolicyId = string;
export type ConnectorDeviceId = string | redacted.Redacted<string>;
export type DeviceSpecificKey = string | redacted.Redacted<string>;
export type MacAddress = string | redacted.Redacted<string>;
export type ParentControllerId = string;
export type UpdatedAt = Date;
export type SetupAt = Date;
export type HubNetworkMode = "STANDARD" | "NETWORK_WIDE_EXCLUSION" | (string & {});
export declare const HubNetworkMode: any;
export interface GetManagedThingResponse {
    Id?: string;
    Arn?: string;
    Owner?: string | redacted.Redacted<string>;
    CredentialLockerId?: string;
    AdvertisedProductId?: string;
    Role?: Role;
    ProvisioningStatus?: ProvisioningStatus;
    Name?: string;
    Model?: string | redacted.Redacted<string>;
    Brand?: string | redacted.Redacted<string>;
    SerialNumber?: string | redacted.Redacted<string>;
    UniversalProductCode?: string | redacted.Redacted<string>;
    InternationalArticleNumber?: string | redacted.Redacted<string>;
    ConnectorPolicyId?: string;
    ConnectorDestinationId?: string;
    ConnectorDeviceId?: string | redacted.Redacted<string>;
    DeviceSpecificKey?: string | redacted.Redacted<string>;
    MacAddress?: string | redacted.Redacted<string>;
    ParentControllerId?: string;
    Classification?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ActivatedAt?: Date;
    HubNetworkMode?: HubNetworkMode;
    MetaData?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
    WiFiSimpleSetupConfiguration?: WiFiSimpleSetupConfiguration;
}
export declare const GetManagedThingResponse: S.Schema<GetManagedThingResponse>;
export interface GetManagedThingCapabilitiesRequest {
    Identifier: string;
}
export declare const GetManagedThingCapabilitiesRequest: S.Schema<GetManagedThingCapabilitiesRequest>;
export interface GetManagedThingCapabilitiesResponse {
    ManagedThingId?: string;
    Capabilities?: string;
    CapabilityReport?: CapabilityReport;
}
export declare const GetManagedThingCapabilitiesResponse: S.Schema<GetManagedThingCapabilitiesResponse>;
export interface GetManagedThingCertificateRequest {
    Identifier: string;
}
export declare const GetManagedThingCertificateRequest: S.Schema<GetManagedThingCertificateRequest>;
export type CertificatePem = string;
export interface GetManagedThingCertificateResponse {
    ManagedThingId?: string;
    CertificatePem?: string;
}
export declare const GetManagedThingCertificateResponse: S.Schema<GetManagedThingCertificateResponse>;
export interface GetManagedThingConnectivityDataRequest {
    Identifier: string;
}
export declare const GetManagedThingConnectivityDataRequest: S.Schema<GetManagedThingConnectivityDataRequest>;
export type ConnectivityStatus = boolean;
export type ConnectivityTimestamp = Date;
export type DisconnectReasonValue = "AUTH_ERROR" | "CLIENT_INITIATED_DISCONNECT" | "CLIENT_ERROR" | "CONNECTION_LOST" | "DUPLICATE_CLIENTID" | "FORBIDDEN_ACCESS" | "MQTT_KEEP_ALIVE_TIMEOUT" | "SERVER_ERROR" | "SERVER_INITIATED_DISCONNECT" | "THROTTLED" | "WEBSOCKET_TTL_EXPIRATION" | "CUSTOMAUTH_TTL_EXPIRATION" | "UNKNOWN" | "NONE" | (string & {});
export declare const DisconnectReasonValue: any;
export interface GetManagedThingConnectivityDataResponse {
    ManagedThingId?: string;
    Connected?: boolean;
    Timestamp?: Date;
    DisconnectReason?: DisconnectReasonValue;
}
export declare const GetManagedThingConnectivityDataResponse: S.Schema<GetManagedThingConnectivityDataResponse>;
export interface GetManagedThingMetaDataRequest {
    Identifier: string;
}
export declare const GetManagedThingMetaDataRequest: S.Schema<GetManagedThingMetaDataRequest>;
export interface GetManagedThingMetaDataResponse {
    ManagedThingId?: string;
    MetaData?: {
        [key: string]: string | undefined;
    };
}
export declare const GetManagedThingMetaDataResponse: S.Schema<GetManagedThingMetaDataResponse>;
export interface GetManagedThingStateRequest {
    ManagedThingId: string;
}
export declare const GetManagedThingStateRequest: S.Schema<GetManagedThingStateRequest>;
export type CapabilityProperties = unknown;
export interface StateCapability {
    id: string;
    name: string;
    version: string;
    properties?: any;
}
export declare const StateCapability: S.Schema<StateCapability>;
export type StateCapabilities = StateCapability[];
export declare const StateCapabilities: any;
export interface StateEndpoint {
    endpointId: string;
    capabilities: StateCapability[];
}
export declare const StateEndpoint: S.Schema<StateEndpoint>;
export type StateEndpoints = StateEndpoint[];
export declare const StateEndpoints: any;
export interface GetManagedThingStateResponse {
    Endpoints: StateEndpoint[];
}
export declare const GetManagedThingStateResponse: S.Schema<GetManagedThingStateResponse>;
export interface GetNotificationConfigurationRequest {
    EventType: EventType;
}
export declare const GetNotificationConfigurationRequest: S.Schema<GetNotificationConfigurationRequest>;
export type NotificationConfigurationCreatedAt = Date;
export type NotificationConfigurationUpdatedAt = Date;
export interface GetNotificationConfigurationResponse {
    EventType?: EventType;
    DestinationName?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetNotificationConfigurationResponse: S.Schema<GetNotificationConfigurationResponse>;
export interface GetOtaTaskRequest {
    Identifier: string;
}
export declare const GetOtaTaskRequest: S.Schema<GetOtaTaskRequest>;
export type LastUpdatedAt = Date;
export interface TaskProcessingDetails {
    NumberOfCanceledThings?: number;
    NumberOfFailedThings?: number;
    NumberOfInProgressThings?: number;
    numberOfQueuedThings?: number;
    numberOfRejectedThings?: number;
    numberOfRemovedThings?: number;
    numberOfSucceededThings?: number;
    numberOfTimedOutThings?: number;
    processingTargets?: string[];
}
export declare const TaskProcessingDetails: S.Schema<TaskProcessingDetails>;
export type OtaStatus = "IN_PROGRESS" | "CANCELED" | "COMPLETED" | "DELETION_IN_PROGRESS" | "SCHEDULED" | (string & {});
export declare const OtaStatus: any;
export interface GetOtaTaskResponse {
    TaskId?: string;
    TaskArn?: string;
    Description?: string;
    S3Url?: string;
    Protocol?: OtaProtocol;
    OtaType?: OtaType;
    OtaTargetQueryString?: string;
    OtaMechanism?: OtaMechanism;
    Target?: string[];
    CreatedAt?: Date;
    LastUpdatedAt?: Date;
    TaskConfigurationId?: string;
    TaskProcessingDetails?: TaskProcessingDetails;
    OtaSchedulingConfig?: OtaTaskSchedulingConfig;
    OtaTaskExecutionRetryConfig?: OtaTaskExecutionRetryConfig;
    Status?: OtaStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetOtaTaskResponse: S.Schema<GetOtaTaskResponse>;
export interface GetOtaTaskConfigurationRequest {
    Identifier: string;
}
export declare const GetOtaTaskConfigurationRequest: S.Schema<GetOtaTaskConfigurationRequest>;
export interface GetOtaTaskConfigurationResponse {
    TaskConfigurationId?: string;
    Name?: string | redacted.Redacted<string>;
    PushConfig?: PushConfig;
    Description?: string;
    CreatedAt?: Date;
}
export declare const GetOtaTaskConfigurationResponse: S.Schema<GetOtaTaskConfigurationResponse>;
export interface GetProvisioningProfileRequest {
    Identifier: string;
}
export declare const GetProvisioningProfileRequest: S.Schema<GetProvisioningProfileRequest>;
export interface GetProvisioningProfileResponse {
    Arn?: string;
    Name?: string;
    ProvisioningType?: ProvisioningType;
    Id?: string;
    Status?: ProvisioningProfileStatus;
    ClaimCertificate?: string | redacted.Redacted<string>;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetProvisioningProfileResponse: S.Schema<GetProvisioningProfileResponse>;
export interface GetRuntimeLogConfigurationRequest {
    ManagedThingId: string;
}
export declare const GetRuntimeLogConfigurationRequest: S.Schema<GetRuntimeLogConfigurationRequest>;
export type LocalStoreLocation = string;
export type LocalStoreFileRotationMaxFiles = number;
export type LocalStoreFileRotationMaxBytes = number;
export type UploadLog = boolean;
export type UploadPeriodMinutes = number;
export type DeleteLocalStoreAfterUpload = boolean;
export interface RuntimeLogConfigurations {
    LogLevel?: LogLevel;
    LogFlushLevel?: LogLevel;
    LocalStoreLocation?: string;
    LocalStoreFileRotationMaxFiles?: number;
    LocalStoreFileRotationMaxBytes?: number;
    UploadLog?: boolean;
    UploadPeriodMinutes?: number;
    DeleteLocalStoreAfterUpload?: boolean;
}
export declare const RuntimeLogConfigurations: S.Schema<RuntimeLogConfigurations>;
export interface GetRuntimeLogConfigurationResponse {
    ManagedThingId?: string;
    RuntimeLogConfigurations?: RuntimeLogConfigurations;
}
export declare const GetRuntimeLogConfigurationResponse: S.Schema<GetRuntimeLogConfigurationResponse>;
export type SchemaVersionType = "capability" | "definition" | (string & {});
export declare const SchemaVersionType: any;
export interface GetSchemaVersionRequest {
    Type: SchemaVersionType;
    SchemaVersionedId: string;
    Format?: SchemaVersionFormat;
}
export declare const GetSchemaVersionRequest: S.Schema<GetSchemaVersionRequest>;
export type SchemaId = string;
export type SchemaVersionDescription = string;
export type SchemaVersionNamespaceName = string;
export type SchemaVersionVersion = string;
export type SchemaVersionVisibility = "PUBLIC" | "PRIVATE" | (string & {});
export declare const SchemaVersionVisibility: any;
export type SchemaVersionSchema = unknown;
export interface GetSchemaVersionResponse {
    SchemaId?: string;
    Type?: SchemaVersionType;
    Description?: string;
    Namespace?: string;
    SemanticVersion?: string;
    Visibility?: SchemaVersionVisibility;
    Schema?: any;
}
export declare const GetSchemaVersionResponse: S.Schema<GetSchemaVersionResponse>;
export type MaxResults = number;
export type NextToken = string;
export interface ListAccountAssociationsRequest {
    ConnectorDestinationId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListAccountAssociationsRequest: S.Schema<ListAccountAssociationsRequest>;
export interface AccountAssociationItem {
    AccountAssociationId: string;
    AssociationState: AssociationState;
    ErrorMessage?: string;
    ConnectorDestinationId?: string;
    Name?: string;
    Description?: string;
    Arn?: string;
}
export declare const AccountAssociationItem: S.Schema<AccountAssociationItem>;
export type AccountAssociationListDefinition = AccountAssociationItem[];
export declare const AccountAssociationListDefinition: any;
export interface ListAccountAssociationsResponse {
    Items?: AccountAssociationItem[];
    NextToken?: string;
}
export declare const ListAccountAssociationsResponse: S.Schema<ListAccountAssociationsResponse>;
export interface ListCloudConnectorsRequest {
    Type?: CloudConnectorType;
    LambdaArn?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListCloudConnectorsRequest: S.Schema<ListCloudConnectorsRequest>;
export interface ConnectorItem {
    Name: string;
    EndpointConfig: EndpointConfig;
    Description?: string;
    EndpointType?: EndpointType;
    Id?: string;
    Type?: CloudConnectorType;
}
export declare const ConnectorItem: S.Schema<ConnectorItem>;
export type ConnectorList = ConnectorItem[];
export declare const ConnectorList: any;
export interface ListCloudConnectorsResponse {
    Items?: ConnectorItem[];
    NextToken?: string;
}
export declare const ListCloudConnectorsResponse: S.Schema<ListCloudConnectorsResponse>;
export interface ListConnectorDestinationsRequest {
    CloudConnectorId?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListConnectorDestinationsRequest: S.Schema<ListConnectorDestinationsRequest>;
export interface ConnectorDestinationSummary {
    Name?: string;
    Description?: string;
    CloudConnectorId?: string;
    Id?: string;
}
export declare const ConnectorDestinationSummary: S.Schema<ConnectorDestinationSummary>;
export type ConnectorDestinationListDefinition = ConnectorDestinationSummary[];
export declare const ConnectorDestinationListDefinition: any;
export interface ListConnectorDestinationsResponse {
    ConnectorDestinationList?: ConnectorDestinationSummary[];
    NextToken?: string;
}
export declare const ListConnectorDestinationsResponse: S.Schema<ListConnectorDestinationsResponse>;
export interface ListCredentialLockersRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListCredentialLockersRequest: S.Schema<ListCredentialLockersRequest>;
export interface CredentialLockerSummary {
    Id?: string;
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
}
export declare const CredentialLockerSummary: S.Schema<CredentialLockerSummary>;
export type CredentialLockerListDefinition = CredentialLockerSummary[];
export declare const CredentialLockerListDefinition: any;
export interface ListCredentialLockersResponse {
    Items?: CredentialLockerSummary[];
    NextToken?: string;
}
export declare const ListCredentialLockersResponse: S.Schema<ListCredentialLockersResponse>;
export interface ListDestinationsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDestinationsRequest: S.Schema<ListDestinationsRequest>;
export interface DestinationSummary {
    Description?: string;
    DeliveryDestinationArn?: string;
    DeliveryDestinationType?: DeliveryDestinationType;
    Name?: string;
    RoleArn?: string;
}
export declare const DestinationSummary: S.Schema<DestinationSummary>;
export type DestinationListDefinition = DestinationSummary[];
export declare const DestinationListDefinition: any;
export interface ListDestinationsResponse {
    DestinationList?: DestinationSummary[];
    NextToken?: string;
}
export declare const ListDestinationsResponse: S.Schema<ListDestinationsResponse>;
export interface ListDeviceDiscoveriesRequest {
    NextToken?: string;
    MaxResults?: number;
    TypeFilter?: DiscoveryType;
    StatusFilter?: DeviceDiscoveryStatus;
}
export declare const ListDeviceDiscoveriesRequest: S.Schema<ListDeviceDiscoveriesRequest>;
export interface DeviceDiscoverySummary {
    Id?: string;
    DiscoveryType?: DiscoveryType;
    Status?: DeviceDiscoveryStatus;
}
export declare const DeviceDiscoverySummary: S.Schema<DeviceDiscoverySummary>;
export type DeviceDiscoveryListDefinition = DeviceDiscoverySummary[];
export declare const DeviceDiscoveryListDefinition: any;
export interface ListDeviceDiscoveriesResponse {
    Items?: DeviceDiscoverySummary[];
    NextToken?: string;
}
export declare const ListDeviceDiscoveriesResponse: S.Schema<ListDeviceDiscoveriesResponse>;
export interface ListDiscoveredDevicesRequest {
    Identifier: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDiscoveredDevicesRequest: S.Schema<ListDiscoveredDevicesRequest>;
export type ConnectorDeviceName = string;
export type DeviceTypeList = string[];
export declare const DeviceTypeList: any;
export type DiscoveryModification = "DISCOVERED" | "UPDATED" | "NO_CHANGE" | (string & {});
export declare const DiscoveryModification: any;
export type DiscoveredAt = Date;
export interface DiscoveredDeviceSummary {
    ConnectorDeviceId?: string | redacted.Redacted<string>;
    ConnectorDeviceName?: string;
    DeviceTypes?: string[];
    ManagedThingId?: string;
    Modification?: DiscoveryModification;
    DiscoveredAt?: Date;
    Brand?: string | redacted.Redacted<string>;
    Model?: string | redacted.Redacted<string>;
    AuthenticationMaterial?: string | redacted.Redacted<string>;
}
export declare const DiscoveredDeviceSummary: S.Schema<DiscoveredDeviceSummary>;
export type DiscoveredDeviceListDefinition = DiscoveredDeviceSummary[];
export declare const DiscoveredDeviceListDefinition: any;
export interface ListDiscoveredDevicesResponse {
    Items?: DiscoveredDeviceSummary[];
    NextToken?: string;
}
export declare const ListDiscoveredDevicesResponse: S.Schema<ListDiscoveredDevicesResponse>;
export interface ListEventLogConfigurationsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEventLogConfigurationsRequest: S.Schema<ListEventLogConfigurationsRequest>;
export interface EventLogConfigurationSummary {
    Id?: string;
    ResourceType?: string;
    ResourceId?: string;
    EventLogLevel?: LogLevel;
}
export declare const EventLogConfigurationSummary: S.Schema<EventLogConfigurationSummary>;
export type EventLogConfigurationListDefinition = EventLogConfigurationSummary[];
export declare const EventLogConfigurationListDefinition: any;
export interface ListEventLogConfigurationsResponse {
    EventLogConfigurationList?: EventLogConfigurationSummary[];
    NextToken?: string;
}
export declare const ListEventLogConfigurationsResponse: S.Schema<ListEventLogConfigurationsResponse>;
export interface ListManagedThingAccountAssociationsRequest {
    ManagedThingId?: string;
    AccountAssociationId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListManagedThingAccountAssociationsRequest: S.Schema<ListManagedThingAccountAssociationsRequest>;
export type ManagedThingAssociationStatus = "PRE_ASSOCIATED" | "ASSOCIATED" | (string & {});
export declare const ManagedThingAssociationStatus: any;
export interface ManagedThingAssociation {
    ManagedThingId?: string;
    AccountAssociationId?: string;
    ManagedThingAssociationStatus?: ManagedThingAssociationStatus;
}
export declare const ManagedThingAssociation: S.Schema<ManagedThingAssociation>;
export type ManagedThingAssociationList = ManagedThingAssociation[];
export declare const ManagedThingAssociationList: any;
export interface ListManagedThingAccountAssociationsResponse {
    Items?: ManagedThingAssociation[];
    NextToken?: string;
}
export declare const ListManagedThingAccountAssociationsResponse: S.Schema<ListManagedThingAccountAssociationsResponse>;
export interface ListManagedThingsRequest {
    OwnerFilter?: string | redacted.Redacted<string>;
    CredentialLockerFilter?: string;
    RoleFilter?: Role;
    ParentControllerIdentifierFilter?: string;
    ConnectorPolicyIdFilter?: string;
    ConnectorDestinationIdFilter?: string;
    ConnectorDeviceIdFilter?: string | redacted.Redacted<string>;
    SerialNumberFilter?: string | redacted.Redacted<string>;
    ProvisioningStatusFilter?: ProvisioningStatus;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListManagedThingsRequest: S.Schema<ListManagedThingsRequest>;
export interface ManagedThingSummary {
    Id?: string;
    Arn?: string;
    AdvertisedProductId?: string;
    Brand?: string | redacted.Redacted<string>;
    Classification?: string | redacted.Redacted<string>;
    ConnectorDeviceId?: string | redacted.Redacted<string>;
    ConnectorPolicyId?: string;
    ConnectorDestinationId?: string;
    Model?: string | redacted.Redacted<string>;
    Name?: string;
    Owner?: string | redacted.Redacted<string>;
    CredentialLockerId?: string;
    ParentControllerId?: string;
    ProvisioningStatus?: ProvisioningStatus;
    Role?: Role;
    SerialNumber?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ActivatedAt?: Date;
}
export declare const ManagedThingSummary: S.Schema<ManagedThingSummary>;
export type ManagedThingListDefinition = ManagedThingSummary[];
export declare const ManagedThingListDefinition: any;
export interface ListManagedThingsResponse {
    Items?: ManagedThingSummary[];
    NextToken?: string;
}
export declare const ListManagedThingsResponse: S.Schema<ListManagedThingsResponse>;
export type CapabilityId = string;
export interface ListManagedThingSchemasRequest {
    Identifier: string;
    EndpointIdFilter?: string;
    CapabilityIdFilter?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListManagedThingSchemasRequest: S.Schema<ListManagedThingSchemasRequest>;
export interface ManagedThingSchemaListItem {
    EndpointId?: string;
    CapabilityId?: string;
    Schema?: any;
}
export declare const ManagedThingSchemaListItem: S.Schema<ManagedThingSchemaListItem>;
export type ManagedThingSchemaListDefinition = ManagedThingSchemaListItem[];
export declare const ManagedThingSchemaListDefinition: any;
export interface ListManagedThingSchemasResponse {
    Items?: ManagedThingSchemaListItem[];
    NextToken?: string;
}
export declare const ListManagedThingSchemasResponse: S.Schema<ListManagedThingSchemasResponse>;
export interface ListNotificationConfigurationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListNotificationConfigurationsRequest: S.Schema<ListNotificationConfigurationsRequest>;
export interface NotificationConfigurationSummary {
    EventType?: EventType;
    DestinationName?: string;
}
export declare const NotificationConfigurationSummary: S.Schema<NotificationConfigurationSummary>;
export type NotificationConfigurationListDefinition = NotificationConfigurationSummary[];
export declare const NotificationConfigurationListDefinition: any;
export interface ListNotificationConfigurationsResponse {
    NotificationConfigurationList?: NotificationConfigurationSummary[];
    NextToken?: string;
}
export declare const ListNotificationConfigurationsResponse: S.Schema<ListNotificationConfigurationsResponse>;
export interface ListOtaTaskConfigurationsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListOtaTaskConfigurationsRequest: S.Schema<ListOtaTaskConfigurationsRequest>;
export interface OtaTaskConfigurationSummary {
    TaskConfigurationId?: string;
    Name?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
}
export declare const OtaTaskConfigurationSummary: S.Schema<OtaTaskConfigurationSummary>;
export type OtaTaskConfigurationListDefinition = OtaTaskConfigurationSummary[];
export declare const OtaTaskConfigurationListDefinition: any;
export interface ListOtaTaskConfigurationsResponse {
    Items?: OtaTaskConfigurationSummary[];
    NextToken?: string;
}
export declare const ListOtaTaskConfigurationsResponse: S.Schema<ListOtaTaskConfigurationsResponse>;
export type OtaNextToken = string;
export interface ListOtaTaskExecutionsRequest {
    Identifier: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListOtaTaskExecutionsRequest: S.Schema<ListOtaTaskExecutionsRequest>;
export type ExecutionNumber = number;
export type QueuedAt = Date;
export type RetryAttempt = number;
export type StartedAt = Date;
export type OtaTaskExecutionStatus = "QUEUED" | "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | "TIMED_OUT" | "REJECTED" | "REMOVED" | "CANCELED" | (string & {});
export declare const OtaTaskExecutionStatus: any;
export interface OtaTaskExecutionSummary {
    ExecutionNumber?: number;
    LastUpdatedAt?: Date;
    QueuedAt?: Date;
    RetryAttempt?: number;
    StartedAt?: Date;
    Status?: OtaTaskExecutionStatus;
}
export declare const OtaTaskExecutionSummary: S.Schema<OtaTaskExecutionSummary>;
export interface OtaTaskExecutionSummaries {
    TaskExecutionSummary?: OtaTaskExecutionSummary;
    ManagedThingId?: string;
}
export declare const OtaTaskExecutionSummaries: S.Schema<OtaTaskExecutionSummaries>;
export type OtaTaskExecutionSummariesListDefinition = OtaTaskExecutionSummaries[];
export declare const OtaTaskExecutionSummariesListDefinition: any;
export interface ListOtaTaskExecutionsResponse {
    ExecutionSummaries?: OtaTaskExecutionSummaries[];
    NextToken?: string;
}
export declare const ListOtaTaskExecutionsResponse: S.Schema<ListOtaTaskExecutionsResponse>;
export interface ListOtaTasksRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListOtaTasksRequest: S.Schema<ListOtaTasksRequest>;
export interface OtaTaskSummary {
    TaskId?: string;
    TaskArn?: string;
    CreatedAt?: Date;
    LastUpdatedAt?: Date;
    TaskConfigurationId?: string;
    Status?: OtaStatus;
}
export declare const OtaTaskSummary: S.Schema<OtaTaskSummary>;
export type OtaTaskListDefinition = OtaTaskSummary[];
export declare const OtaTaskListDefinition: any;
export interface ListOtaTasksResponse {
    Tasks?: OtaTaskSummary[];
    NextToken?: string;
}
export declare const ListOtaTasksResponse: S.Schema<ListOtaTasksResponse>;
export interface ListProvisioningProfilesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListProvisioningProfilesRequest: S.Schema<ListProvisioningProfilesRequest>;
export interface ProvisioningProfileSummary {
    Name?: string;
    Id?: string;
    Arn?: string;
    ProvisioningType?: ProvisioningType;
    Status?: ProvisioningProfileStatus;
}
export declare const ProvisioningProfileSummary: S.Schema<ProvisioningProfileSummary>;
export type ProvisioningProfileListDefinition = ProvisioningProfileSummary[];
export declare const ProvisioningProfileListDefinition: any;
export interface ListProvisioningProfilesResponse {
    Items?: ProvisioningProfileSummary[];
    NextToken?: string;
}
export declare const ListProvisioningProfilesResponse: S.Schema<ListProvisioningProfilesResponse>;
export interface ListSchemaVersionsRequest {
    Type: SchemaVersionType;
    MaxResults?: number;
    NextToken?: string;
    SchemaId?: string;
    Namespace?: string;
    Visibility?: SchemaVersionVisibility;
    SemanticVersion?: string;
}
export declare const ListSchemaVersionsRequest: S.Schema<ListSchemaVersionsRequest>;
export interface SchemaVersionListItem {
    SchemaId?: string;
    Type?: SchemaVersionType;
    Description?: string;
    Namespace?: string;
    SemanticVersion?: string;
    Visibility?: SchemaVersionVisibility;
}
export declare const SchemaVersionListItem: S.Schema<SchemaVersionListItem>;
export type SchemaVersionList = SchemaVersionListItem[];
export declare const SchemaVersionList: any;
export interface ListSchemaVersionsResponse {
    Items?: SchemaVersionListItem[];
    NextToken?: string;
}
export declare const ListSchemaVersionsResponse: S.Schema<ListSchemaVersionsResponse>;
export type IoTManagedIntegrationsResourceARN = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PutDefaultEncryptionConfigurationRequest {
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
}
export declare const PutDefaultEncryptionConfigurationRequest: S.Schema<PutDefaultEncryptionConfigurationRequest>;
export interface PutDefaultEncryptionConfigurationResponse {
    configurationStatus: ConfigurationStatus;
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
}
export declare const PutDefaultEncryptionConfigurationResponse: S.Schema<PutDefaultEncryptionConfigurationResponse>;
export interface PutHubConfigurationRequest {
    HubTokenTimerExpirySettingInSeconds: number;
}
export declare const PutHubConfigurationRequest: S.Schema<PutHubConfigurationRequest>;
export interface PutHubConfigurationResponse {
    HubTokenTimerExpirySettingInSeconds?: number;
}
export declare const PutHubConfigurationResponse: S.Schema<PutHubConfigurationResponse>;
export interface PutRuntimeLogConfigurationRequest {
    ManagedThingId: string;
    RuntimeLogConfigurations: RuntimeLogConfigurations;
}
export declare const PutRuntimeLogConfigurationRequest: S.Schema<PutRuntimeLogConfigurationRequest>;
export interface PutRuntimeLogConfigurationResponse {
}
export declare const PutRuntimeLogConfigurationResponse: S.Schema<PutRuntimeLogConfigurationResponse>;
export interface RegisterAccountAssociationRequest {
    ManagedThingId: string;
    AccountAssociationId: string;
    DeviceDiscoveryId: string;
}
export declare const RegisterAccountAssociationRequest: S.Schema<RegisterAccountAssociationRequest>;
export interface RegisterAccountAssociationResponse {
    AccountAssociationId?: string;
    DeviceDiscoveryId?: string;
    ManagedThingId?: string;
}
export declare const RegisterAccountAssociationResponse: S.Schema<RegisterAccountAssociationResponse>;
export interface RegisterCustomEndpointRequest {
}
export declare const RegisterCustomEndpointRequest: S.Schema<RegisterCustomEndpointRequest>;
export interface RegisterCustomEndpointResponse {
    EndpointAddress: string;
}
export declare const RegisterCustomEndpointResponse: S.Schema<RegisterCustomEndpointResponse>;
export interface ResetRuntimeLogConfigurationRequest {
    ManagedThingId: string;
}
export declare const ResetRuntimeLogConfigurationRequest: S.Schema<ResetRuntimeLogConfigurationRequest>;
export interface ResetRuntimeLogConfigurationResponse {
}
export declare const ResetRuntimeLogConfigurationResponse: S.Schema<ResetRuntimeLogConfigurationResponse>;
export type ConnectorId = string;
export type ThirdPartyUserId = string | redacted.Redacted<string>;
export type ConnectorEventOperation = "DEVICE_COMMAND_RESPONSE" | "DEVICE_DISCOVERY" | "DEVICE_EVENT" | "DEVICE_COMMAND_REQUEST" | (string & {});
export declare const ConnectorEventOperation: any;
export type ConnectorEventOperationVersion = string;
export type ConnectorEventStatusCode = number;
export type ConnectorEventMessage = string | redacted.Redacted<string>;
export type TraceId = string;
export type ClusterId = string;
export type SpecVersion = string;
export type MatterAttributeId = string;
export type MatterCapabilityReportAttributeValue = unknown;
export interface MatterCapabilityReportAttribute {
    id?: string;
    name?: string;
    value?: any;
}
export declare const MatterCapabilityReportAttribute: S.Schema<MatterCapabilityReportAttribute>;
export type MatterCapabilityReportAttributes = MatterCapabilityReportAttribute[];
export declare const MatterCapabilityReportAttributes: any;
export type MatterCommandId = string;
export type MatterCapabilityReportCommands = string[];
export declare const MatterCapabilityReportCommands: any;
export type MatterEventId = string;
export type MatterCapabilityReportEvents = string[];
export declare const MatterCapabilityReportEvents: any;
export type MatterCapabilityReportFeatureMap = number;
export type MatterCapabilityReportGeneratedCommands = string[];
export declare const MatterCapabilityReportGeneratedCommands: any;
export type MatterCapabilityReportFabricIndex = number;
export interface MatterCapabilityReportCluster {
    id: string;
    revision: number;
    publicId?: string;
    name?: string;
    specVersion?: string;
    attributes?: MatterCapabilityReportAttribute[];
    commands?: string[];
    events?: string[];
    featureMap?: number;
    generatedCommands?: string[];
    fabricIndex?: number;
}
export declare const MatterCapabilityReportCluster: S.Schema<MatterCapabilityReportCluster>;
export type MatterCapabilityReportClusters = MatterCapabilityReportCluster[];
export declare const MatterCapabilityReportClusters: any;
export type MatterCapabilityReportEndpointParts = string[];
export declare const MatterCapabilityReportEndpointParts: any;
export type EndpointSemanticTag = string;
export type MatterCapabilityReportEndpointSemanticTags = string[];
export declare const MatterCapabilityReportEndpointSemanticTags: any;
export type MatterCapabilityReportEndpointClientClusters = string[];
export declare const MatterCapabilityReportEndpointClientClusters: any;
export interface MatterCapabilityReportEndpoint {
    id: string;
    deviceTypes: string[];
    clusters: MatterCapabilityReportCluster[];
    parts?: string[];
    semanticTags?: string[];
    clientClusters?: string[];
}
export declare const MatterCapabilityReportEndpoint: S.Schema<MatterCapabilityReportEndpoint>;
export type MatterCapabilityReportEndpoints = MatterCapabilityReportEndpoint[];
export declare const MatterCapabilityReportEndpoints: any;
export interface MatterCapabilityReport {
    version: string;
    nodeId?: string;
    endpoints: MatterCapabilityReportEndpoint[];
}
export declare const MatterCapabilityReport: S.Schema<MatterCapabilityReport>;
export type DeviceMetadata = unknown;
export interface Device {
    ConnectorDeviceId: string | redacted.Redacted<string>;
    ConnectorDeviceName?: string;
    CapabilityReport: MatterCapabilityReport;
    CapabilitySchemas?: CapabilitySchemaItem[];
    DeviceMetadata?: any;
}
export declare const Device: S.Schema<Device>;
export type Devices = Device[];
export declare const Devices: any;
export type MatterAttributes = unknown;
export type MatterFields = unknown;
export type MatterCommands = {
    [key: string]: any | undefined;
};
export declare const MatterCommands: any;
export type MatterEvents = {
    [key: string]: any | undefined;
};
export declare const MatterEvents: any;
export interface MatterCluster {
    id?: string;
    attributes?: any;
    commands?: {
        [key: string]: any | undefined;
    };
    events?: {
        [key: string]: any | undefined;
    };
}
export declare const MatterCluster: S.Schema<MatterCluster>;
export type MatterClusters = MatterCluster[];
export declare const MatterClusters: any;
export interface MatterEndpoint {
    id?: string;
    clusters?: MatterCluster[];
}
export declare const MatterEndpoint: S.Schema<MatterEndpoint>;
export interface SendConnectorEventRequest {
    ConnectorId: string;
    UserId?: string | redacted.Redacted<string>;
    Operation: ConnectorEventOperation;
    OperationVersion?: string;
    StatusCode?: number;
    Message?: string | redacted.Redacted<string>;
    DeviceDiscoveryId?: string;
    ConnectorDeviceId?: string | redacted.Redacted<string>;
    TraceId?: string;
    Devices?: Device[];
    MatterEndpoint?: MatterEndpoint;
}
export declare const SendConnectorEventRequest: S.Schema<SendConnectorEventRequest>;
export interface SendConnectorEventResponse {
    ConnectorId: string;
}
export declare const SendConnectorEventResponse: S.Schema<SendConnectorEventResponse>;
export type CapabilityActionName = string;
export type ActionReference = string;
export type ActionTraceId = string;
export interface CapabilityAction {
    name: string;
    ref?: string;
    actionTraceId?: string;
    parameters?: any;
}
export declare const CapabilityAction: S.Schema<CapabilityAction>;
export type CapabilityActions = CapabilityAction[];
export declare const CapabilityActions: any;
export interface CommandCapability {
    id: string;
    name: string;
    version: string;
    actions: CapabilityAction[];
}
export declare const CommandCapability: S.Schema<CommandCapability>;
export type CommandCapabilities = CommandCapability[];
export declare const CommandCapabilities: any;
export interface CommandEndpoint {
    endpointId: string;
    capabilities: CommandCapability[];
}
export declare const CommandEndpoint: S.Schema<CommandEndpoint>;
export type CommandEndpoints = CommandEndpoint[];
export declare const CommandEndpoints: any;
export interface SendManagedThingCommandRequest {
    ManagedThingId: string;
    Endpoints: CommandEndpoint[];
    ConnectorAssociationId?: string;
    AccountAssociationId?: string;
}
export declare const SendManagedThingCommandRequest: S.Schema<SendManagedThingCommandRequest>;
export interface SendManagedThingCommandResponse {
    TraceId?: string;
}
export declare const SendManagedThingCommandResponse: S.Schema<SendManagedThingCommandResponse>;
export interface StartAccountAssociationRefreshRequest {
    AccountAssociationId: string;
}
export declare const StartAccountAssociationRefreshRequest: S.Schema<StartAccountAssociationRefreshRequest>;
export interface StartAccountAssociationRefreshResponse {
    OAuthAuthorizationUrl: string | redacted.Redacted<string>;
}
export declare const StartAccountAssociationRefreshResponse: S.Schema<StartAccountAssociationRefreshResponse>;
export type CustomProtocolDetailKey = string;
export type CustomProtocolDetailValue = string;
export type CustomProtocolDetail = {
    [key: string]: string | undefined;
};
export declare const CustomProtocolDetail: any;
export type DiscoveryAuthMaterialString = string | redacted.Redacted<string>;
export type DiscoveryAuthMaterialType = "ZWAVE_INSTALL_CODE" | (string & {});
export declare const DiscoveryAuthMaterialType: any;
export type ConnectorDeviceIdList = (string | redacted.Redacted<string>)[];
export declare const ConnectorDeviceIdList: any;
export type ProtocolType = "ZWAVE" | "ZIGBEE" | "CUSTOM" | (string & {});
export declare const ProtocolType: any;
export interface StartDeviceDiscoveryRequest {
    DiscoveryType: DiscoveryType;
    CustomProtocolDetail?: {
        [key: string]: string | undefined;
    };
    ControllerIdentifier?: string;
    ConnectorAssociationIdentifier?: string;
    AccountAssociationId?: string;
    AuthenticationMaterial?: string | redacted.Redacted<string>;
    AuthenticationMaterialType?: DiscoveryAuthMaterialType;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ConnectorDeviceIdList?: (string | redacted.Redacted<string>)[];
    Protocol?: ProtocolType;
    EndDeviceIdentifier?: string;
}
export declare const StartDeviceDiscoveryRequest: S.Schema<StartDeviceDiscoveryRequest>;
export interface StartDeviceDiscoveryResponse {
    Id?: string;
    StartedAt?: Date;
}
export declare const StartDeviceDiscoveryResponse: S.Schema<StartDeviceDiscoveryResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAccountAssociationRequest {
    AccountAssociationId: string;
    Name?: string;
    Description?: string;
}
export declare const UpdateAccountAssociationRequest: S.Schema<UpdateAccountAssociationRequest>;
export interface UpdateAccountAssociationResponse {
}
export declare const UpdateAccountAssociationResponse: S.Schema<UpdateAccountAssociationResponse>;
export interface UpdateCloudConnectorRequest {
    Identifier: string;
    Name?: string;
    Description?: string;
}
export declare const UpdateCloudConnectorRequest: S.Schema<UpdateCloudConnectorRequest>;
export interface UpdateCloudConnectorResponse {
}
export declare const UpdateCloudConnectorResponse: S.Schema<UpdateCloudConnectorResponse>;
export interface OAuthUpdate {
    oAuthCompleteRedirectUrl?: string;
    proactiveRefreshTokenRenewal?: ProactiveRefreshTokenRenewal;
}
export declare const OAuthUpdate: S.Schema<OAuthUpdate>;
export interface GeneralAuthorizationUpdate {
    AuthMaterialsToAdd?: AuthMaterial[];
    AuthMaterialsToUpdate?: AuthMaterial[];
}
export declare const GeneralAuthorizationUpdate: S.Schema<GeneralAuthorizationUpdate>;
export interface AuthConfigUpdate {
    oAuthUpdate?: OAuthUpdate;
    GeneralAuthorizationUpdate?: GeneralAuthorizationUpdate;
}
export declare const AuthConfigUpdate: S.Schema<AuthConfigUpdate>;
export interface UpdateConnectorDestinationRequest {
    Identifier: string;
    Description?: string;
    Name?: string;
    AuthType?: AuthType;
    AuthConfig?: AuthConfigUpdate;
    SecretsManager?: SecretsManager;
}
export declare const UpdateConnectorDestinationRequest: S.Schema<UpdateConnectorDestinationRequest>;
export interface UpdateConnectorDestinationResponse {
}
export declare const UpdateConnectorDestinationResponse: S.Schema<UpdateConnectorDestinationResponse>;
export interface UpdateDestinationRequest {
    Name: string;
    DeliveryDestinationArn?: string;
    DeliveryDestinationType?: DeliveryDestinationType;
    RoleArn?: string;
    Description?: string;
}
export declare const UpdateDestinationRequest: S.Schema<UpdateDestinationRequest>;
export interface UpdateDestinationResponse {
}
export declare const UpdateDestinationResponse: S.Schema<UpdateDestinationResponse>;
export interface UpdateEventLogConfigurationRequest {
    Id: string;
    EventLogLevel: LogLevel;
}
export declare const UpdateEventLogConfigurationRequest: S.Schema<UpdateEventLogConfigurationRequest>;
export interface UpdateEventLogConfigurationResponse {
}
export declare const UpdateEventLogConfigurationResponse: S.Schema<UpdateEventLogConfigurationResponse>;
export interface UpdateManagedThingRequest {
    Identifier: string;
    Owner?: string | redacted.Redacted<string>;
    CredentialLockerId?: string;
    SerialNumber?: string | redacted.Redacted<string>;
    WiFiSimpleSetupConfiguration?: WiFiSimpleSetupConfiguration;
    Brand?: string | redacted.Redacted<string>;
    Model?: string | redacted.Redacted<string>;
    Name?: string;
    CapabilityReport?: CapabilityReport;
    CapabilitySchemas?: CapabilitySchemaItem[];
    Capabilities?: string;
    Classification?: string | redacted.Redacted<string>;
    HubNetworkMode?: HubNetworkMode;
    MetaData?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateManagedThingRequest: S.Schema<UpdateManagedThingRequest>;
export interface UpdateManagedThingResponse {
}
export declare const UpdateManagedThingResponse: S.Schema<UpdateManagedThingResponse>;
export interface UpdateNotificationConfigurationRequest {
    EventType: EventType;
    DestinationName: string;
}
export declare const UpdateNotificationConfigurationRequest: S.Schema<UpdateNotificationConfigurationRequest>;
export interface UpdateNotificationConfigurationResponse {
}
export declare const UpdateNotificationConfigurationResponse: S.Schema<UpdateNotificationConfigurationResponse>;
export interface UpdateOtaTaskRequest {
    Identifier: string;
    Description?: string;
    TaskConfigurationId?: string;
}
export declare const UpdateOtaTaskRequest: S.Schema<UpdateOtaTaskRequest>;
export interface UpdateOtaTaskResponse {
}
export declare const UpdateOtaTaskResponse: S.Schema<UpdateOtaTaskResponse>;
export type ErrorMessage = string;
export type ErrorResourceId = string;
export type ErrorResourceType = string;
export type CreateAccountAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates a new account association via the destination id.
 */
export declare const createAccountAssociation: API.OperationMethod<CreateAccountAssociationRequest, CreateAccountAssociationResponse, CreateAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateCloudConnectorError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a C2C (cloud-to-cloud) connector.
 */
export declare const createCloudConnector: API.OperationMethod<CreateCloudConnectorRequest, CreateCloudConnectorResponse, CreateCloudConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorDestinationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Create a connector destination for connecting a cloud-to-cloud (C2C) connector to the customer's Amazon Web Services account.
 */
export declare const createConnectorDestination: API.OperationMethod<CreateConnectorDestinationRequest, CreateConnectorDestinationResponse, CreateConnectorDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateCredentialLockerError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a credential locker.
 *
 * This operation will not trigger the creation of all the manufacturing resources.
 */
export declare const createCredentialLocker: API.OperationMethod<CreateCredentialLockerRequest, CreateCredentialLockerResponse, CreateCredentialLockerError, Credentials | HttpClient.HttpClient>;
export type CreateDestinationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a notification destination such as Kinesis Data Streams that receive events and notifications from Managed integrations. Managed integrations uses the destination to determine where to deliver notifications.
 */
export declare const createDestination: API.OperationMethod<CreateDestinationRequest, CreateDestinationResponse, CreateDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateEventLogConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Set the event log configuration for the account, resource type, or specific resource.
 */
export declare const createEventLogConfiguration: API.OperationMethod<CreateEventLogConfigurationRequest, CreateEventLogConfigurationResponse, CreateEventLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateManagedThingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates a managed thing. A managed thing contains the device identifier, protocol supported, and capabilities of the device in a data model format defined by Managed integrations.
 */
export declare const createManagedThing: API.OperationMethod<CreateManagedThingRequest, CreateManagedThingResponse, CreateManagedThingError, Credentials | HttpClient.HttpClient>;
export type CreateNotificationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a notification configuration. A configuration is a connection between an event type and a destination that you have already created.
 */
export declare const createNotificationConfiguration: API.OperationMethod<CreateNotificationConfigurationRequest, CreateNotificationConfigurationResponse, CreateNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateOtaTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Create an over-the-air (OTA) task to target a device.
 */
export declare const createOtaTask: API.OperationMethod<CreateOtaTaskRequest, CreateOtaTaskResponse, CreateOtaTaskError, Credentials | HttpClient.HttpClient>;
export type CreateOtaTaskConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a configuraiton for the over-the-air (OTA) task.
 */
export declare const createOtaTaskConfiguration: API.OperationMethod<CreateOtaTaskConfigurationRequest, CreateOtaTaskConfigurationResponse, CreateOtaTaskConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateProvisioningProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Create a provisioning profile for executing device provisioning flows. The provisioning profile is a document that defines the set of resources and policies applied to a device during the provisioning process.
 */
export declare const createProvisioningProfile: API.OperationMethod<CreateProvisioningProfileRequest, CreateProvisioningProfileResponse, CreateProvisioningProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove a third-party account association for an end user.
 *
 * You must first call the `DeregisterAccountAssociation` to remove the connection between the managed thing and the third-party account before calling the `DeleteAccountAssociation` API.
 */
export declare const deleteAccountAssociation: API.OperationMethod<DeleteAccountAssociationRequest, DeleteAccountAssociationResponse, DeleteAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudConnectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Delete a cloud connector.
 */
export declare const deleteCloudConnector: API.OperationMethod<DeleteCloudConnectorRequest, DeleteCloudConnectorResponse, DeleteCloudConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a connector destination linked to a cloud-to-cloud (C2C) connector.
 *
 * Deletion can't be done if the account association has used this connector destination.
 */
export declare const deleteConnectorDestination: API.OperationMethod<DeleteConnectorDestinationRequest, DeleteConnectorDestinationResponse, DeleteConnectorDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteCredentialLockerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a credential locker.
 *
 * This operation can't be undone and any existing device won't be able to use IoT managed integrations.
 */
export declare const deleteCredentialLocker: API.OperationMethod<DeleteCredentialLockerRequest, DeleteCredentialLockerResponse, DeleteCredentialLockerError, Credentials | HttpClient.HttpClient>;
export type DeleteDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a notification destination specified by name.
 */
export declare const deleteDestination: API.OperationMethod<DeleteDestinationRequest, DeleteDestinationResponse, DeleteDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteEventLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an event log configuration.
 */
export declare const deleteEventLogConfiguration: API.OperationMethod<DeleteEventLogConfigurationRequest, DeleteEventLogConfigurationResponse, DeleteEventLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteManagedThingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Delete a managed thing. For direct-connected and hub-connected devices connecting with Managed integrations via a controller, all of the devices connected to it will have their status changed to `PENDING`. It is not possible to remove a cloud-to-cloud device.
 */
export declare const deleteManagedThing: API.OperationMethod<DeleteManagedThingRequest, DeleteManagedThingResponse, DeleteManagedThingError, Credentials | HttpClient.HttpClient>;
export type DeleteNotificationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a notification configuration.
 */
export declare const deleteNotificationConfiguration: API.OperationMethod<DeleteNotificationConfigurationRequest, DeleteNotificationConfigurationResponse, DeleteNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteOtaTaskError = AccessDeniedException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete the over-the-air (OTA) task.
 */
export declare const deleteOtaTask: API.OperationMethod<DeleteOtaTaskRequest, DeleteOtaTaskResponse, DeleteOtaTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteOtaTaskConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete the over-the-air (OTA) task configuration.
 */
export declare const deleteOtaTaskConfiguration: API.OperationMethod<DeleteOtaTaskConfigurationRequest, DeleteOtaTaskConfigurationResponse, DeleteOtaTaskConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteProvisioningProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Delete a provisioning profile.
 */
export declare const deleteProvisioningProfile: API.OperationMethod<DeleteProvisioningProfileRequest, DeleteProvisioningProfileResponse, DeleteProvisioningProfileError, Credentials | HttpClient.HttpClient>;
export type DeregisterAccountAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deregister an account association from a managed thing.
 */
export declare const deregisterAccountAssociation: API.OperationMethod<DeregisterAccountAssociationRequest, DeregisterAccountAssociationResponse, DeregisterAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type GetAccountAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get an account association for an Amazon Web Services account linked to a customer-managed destination.
 */
export declare const getAccountAssociation: API.OperationMethod<GetAccountAssociationRequest, GetAccountAssociationResponse, GetAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type GetCloudConnectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get configuration details for a cloud connector.
 */
export declare const getCloudConnector: API.OperationMethod<GetCloudConnectorRequest, GetCloudConnectorResponse, GetCloudConnectorError, Credentials | HttpClient.HttpClient>;
export type GetConnectorDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get connector destination details linked to a cloud-to-cloud (C2C) connector.
 */
export declare const getConnectorDestination: API.OperationMethod<GetConnectorDestinationRequest, GetConnectorDestinationResponse, GetConnectorDestinationError, Credentials | HttpClient.HttpClient>;
export type GetCredentialLockerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get information on an existing credential locker
 */
export declare const getCredentialLocker: API.OperationMethod<GetCredentialLockerRequest, GetCredentialLockerResponse, GetCredentialLockerError, Credentials | HttpClient.HttpClient>;
export type GetCustomEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Returns the IoT managed integrations custom endpoint.
 */
export declare const getCustomEndpoint: API.OperationMethod<GetCustomEndpointRequest, GetCustomEndpointResponse, GetCustomEndpointError, Credentials | HttpClient.HttpClient>;
export type GetDefaultEncryptionConfigurationError = AccessDeniedException | InternalFailureException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves information about the default encryption configuration for the Amazon Web Services account in the default or specified region. For more information, see Key management in the *AWS IoT SiteWise User Guide*.
 */
export declare const getDefaultEncryptionConfiguration: API.OperationMethod<GetDefaultEncryptionConfigurationRequest, GetDefaultEncryptionConfigurationResponse, GetDefaultEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a destination by name.
 */
export declare const getDestination: API.OperationMethod<GetDestinationRequest, GetDestinationResponse, GetDestinationError, Credentials | HttpClient.HttpClient>;
export type GetDeviceDiscoveryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get the current state of a device discovery.
 */
export declare const getDeviceDiscovery: API.OperationMethod<GetDeviceDiscoveryRequest, GetDeviceDiscoveryResponse, GetDeviceDiscoveryError, Credentials | HttpClient.HttpClient>;
export type GetEventLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get an event log configuration.
 */
export declare const getEventLogConfiguration: API.OperationMethod<GetEventLogConfigurationRequest, GetEventLogConfigurationResponse, GetEventLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetHubConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a hub configuration.
 */
export declare const getHubConfiguration: API.OperationMethod<GetHubConfigurationRequest, GetHubConfigurationResponse, GetHubConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get details of a managed thing including its attributes and capabilities.
 */
export declare const getManagedThing: API.OperationMethod<GetManagedThingRequest, GetManagedThingResponse, GetManagedThingError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingCapabilitiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get the capabilities for a managed thing using the device ID.
 */
export declare const getManagedThingCapabilities: API.OperationMethod<GetManagedThingCapabilitiesRequest, GetManagedThingCapabilitiesResponse, GetManagedThingCapabilitiesError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingCertificateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves the certificate PEM for a managed IoT thing.
 */
export declare const getManagedThingCertificate: API.OperationMethod<GetManagedThingCertificateRequest, GetManagedThingCertificateResponse, GetManagedThingCertificateError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingConnectivityDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get the connectivity status of a managed thing.
 */
export declare const getManagedThingConnectivityData: API.OperationMethod<GetManagedThingConnectivityDataRequest, GetManagedThingConnectivityDataResponse, GetManagedThingConnectivityDataError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingMetaDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get the metadata information for a managed thing.
 *
 * The `managedThing` `metadata` parameter is used for associating attributes with a `managedThing` that can be used for grouping over-the-air (OTA) tasks. Name value pairs in `metadata` can be used in the `OtaTargetQueryString` parameter for the `CreateOtaTask` API operation.
 */
export declare const getManagedThingMetaData: API.OperationMethod<GetManagedThingMetaDataRequest, GetManagedThingMetaDataResponse, GetManagedThingMetaDataError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingStateError = AccessDeniedException | InternalFailureException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Returns the managed thing state for the given device Id.
 */
export declare const getManagedThingState: API.OperationMethod<GetManagedThingStateRequest, GetManagedThingStateResponse, GetManagedThingStateError, Credentials | HttpClient.HttpClient>;
export type GetNotificationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a notification configuration for a specified event type.
 */
export declare const getNotificationConfiguration: API.OperationMethod<GetNotificationConfigurationRequest, GetNotificationConfigurationResponse, GetNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetOtaTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get details of the over-the-air (OTA) task by its task id.
 */
export declare const getOtaTask: API.OperationMethod<GetOtaTaskRequest, GetOtaTaskResponse, GetOtaTaskError, Credentials | HttpClient.HttpClient>;
export type GetOtaTaskConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a configuraiton for the over-the-air (OTA) task.
 */
export declare const getOtaTaskConfiguration: API.OperationMethod<GetOtaTaskConfigurationRequest, GetOtaTaskConfigurationResponse, GetOtaTaskConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetProvisioningProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get details of a provisioning profile.
 */
export declare const getProvisioningProfile: API.OperationMethod<GetProvisioningProfileRequest, GetProvisioningProfileResponse, GetProvisioningProfileError, Credentials | HttpClient.HttpClient>;
export type GetRuntimeLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the runtime log configuration for a specific managed thing.
 */
export declare const getRuntimeLogConfiguration: API.OperationMethod<GetRuntimeLogConfigurationRequest, GetRuntimeLogConfigurationResponse, GetRuntimeLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetSchemaVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a schema version with the provided information.
 */
export declare const getSchemaVersion: API.OperationMethod<GetSchemaVersionRequest, GetSchemaVersionResponse, GetSchemaVersionError, Credentials | HttpClient.HttpClient>;
export type ListAccountAssociationsError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all account associations, with optional filtering by connector destination ID.
 */
export declare const listAccountAssociations: API.PaginatedOperationMethod<ListAccountAssociationsRequest, ListAccountAssociationsResponse, ListAccountAssociationsError, Credentials | HttpClient.HttpClient, AccountAssociationItem>;
export type ListCloudConnectorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of connectors filtered by its Lambda Amazon Resource Name (ARN) and `type`.
 */
export declare const listCloudConnectors: API.PaginatedOperationMethod<ListCloudConnectorsRequest, ListCloudConnectorsResponse, ListCloudConnectorsError, Credentials | HttpClient.HttpClient, ConnectorItem>;
export type ListConnectorDestinationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all connector destinations, with optional filtering by cloud connector ID.
 */
export declare const listConnectorDestinations: API.PaginatedOperationMethod<ListConnectorDestinationsRequest, ListConnectorDestinationsResponse, ListConnectorDestinationsError, Credentials | HttpClient.HttpClient, ConnectorDestinationSummary>;
export type ListCredentialLockersError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List information on an existing credential locker.
 */
export declare const listCredentialLockers: API.PaginatedOperationMethod<ListCredentialLockersRequest, ListCredentialLockersResponse, ListCredentialLockersError, Credentials | HttpClient.HttpClient, CredentialLockerSummary>;
export type ListDestinationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all notification destinations.
 */
export declare const listDestinations: API.PaginatedOperationMethod<ListDestinationsRequest, ListDestinationsResponse, ListDestinationsError, Credentials | HttpClient.HttpClient, DestinationSummary>;
export type ListDeviceDiscoveriesError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all device discovery tasks, with optional filtering by type and status.
 */
export declare const listDeviceDiscoveries: API.PaginatedOperationMethod<ListDeviceDiscoveriesRequest, ListDeviceDiscoveriesResponse, ListDeviceDiscoveriesError, Credentials | HttpClient.HttpClient, DeviceDiscoverySummary>;
export type ListDiscoveredDevicesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all devices discovered during a specific device discovery task.
 */
export declare const listDiscoveredDevices: API.PaginatedOperationMethod<ListDiscoveredDevicesRequest, ListDiscoveredDevicesResponse, ListDiscoveredDevicesError, Credentials | HttpClient.HttpClient, DiscoveredDeviceSummary>;
export type ListEventLogConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all event log configurations for an account.
 */
export declare const listEventLogConfigurations: API.PaginatedOperationMethod<ListEventLogConfigurationsRequest, ListEventLogConfigurationsResponse, ListEventLogConfigurationsError, Credentials | HttpClient.HttpClient, EventLogConfigurationSummary>;
export type ListManagedThingAccountAssociationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all account associations for a specific managed thing.
 */
export declare const listManagedThingAccountAssociations: API.PaginatedOperationMethod<ListManagedThingAccountAssociationsRequest, ListManagedThingAccountAssociationsResponse, ListManagedThingAccountAssociationsError, Credentials | HttpClient.HttpClient, ManagedThingAssociation>;
export type ListManagedThingsError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Listing all managed things with provision for filters.
 */
export declare const listManagedThings: API.PaginatedOperationMethod<ListManagedThingsRequest, ListManagedThingsResponse, ListManagedThingsError, Credentials | HttpClient.HttpClient, ManagedThingSummary>;
export type ListManagedThingSchemasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * List schemas associated with a managed thing.
 */
export declare const listManagedThingSchemas: API.PaginatedOperationMethod<ListManagedThingSchemasRequest, ListManagedThingSchemasResponse, ListManagedThingSchemasError, Credentials | HttpClient.HttpClient, ManagedThingSchemaListItem>;
export type ListNotificationConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all notification configurations.
 */
export declare const listNotificationConfigurations: API.PaginatedOperationMethod<ListNotificationConfigurationsRequest, ListNotificationConfigurationsResponse, ListNotificationConfigurationsError, Credentials | HttpClient.HttpClient, NotificationConfigurationSummary>;
export type ListOtaTaskConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all of the over-the-air (OTA) task configurations.
 */
export declare const listOtaTaskConfigurations: API.PaginatedOperationMethod<ListOtaTaskConfigurationsRequest, ListOtaTaskConfigurationsResponse, ListOtaTaskConfigurationsError, Credentials | HttpClient.HttpClient, OtaTaskConfigurationSummary>;
export type ListOtaTaskExecutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all of the over-the-air (OTA) task executions.
 */
export declare const listOtaTaskExecutions: API.PaginatedOperationMethod<ListOtaTaskExecutionsRequest, ListOtaTaskExecutionsResponse, ListOtaTaskExecutionsError, Credentials | HttpClient.HttpClient, OtaTaskExecutionSummaries>;
export type ListOtaTasksError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all of the over-the-air (OTA) tasks.
 */
export declare const listOtaTasks: API.PaginatedOperationMethod<ListOtaTasksRequest, ListOtaTasksResponse, ListOtaTasksError, Credentials | HttpClient.HttpClient, OtaTaskSummary>;
export type ListProvisioningProfilesError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * List the provisioning profiles within the Amazon Web Services account.
 */
export declare const listProvisioningProfiles: API.PaginatedOperationMethod<ListProvisioningProfilesRequest, ListProvisioningProfilesResponse, ListProvisioningProfilesError, Credentials | HttpClient.HttpClient, ProvisioningProfileSummary>;
export type ListSchemaVersionsError = AccessDeniedException | ConflictException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists schema versions with the provided information.
 */
export declare const listSchemaVersions: API.PaginatedOperationMethod<ListSchemaVersionsRequest, ListSchemaVersionsResponse, ListSchemaVersionsError, Credentials | HttpClient.HttpClient, SchemaVersionListItem>;
export type ListTagsForResourceError = InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Lists the tags for a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutDefaultEncryptionConfigurationError = AccessDeniedException | InternalFailureException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Sets the default encryption configuration for the Amazon Web Services account. For more information, see Key management in the AWS IoT SiteWise User Guide.
 */
export declare const putDefaultEncryptionConfiguration: API.OperationMethod<PutDefaultEncryptionConfigurationRequest, PutDefaultEncryptionConfigurationResponse, PutDefaultEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutHubConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a hub configuration.
 */
export declare const putHubConfiguration: API.OperationMethod<PutHubConfigurationRequest, PutHubConfigurationResponse, PutHubConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutRuntimeLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Set the runtime log configuration for a specific managed thing.
 */
export declare const putRuntimeLogConfiguration: API.OperationMethod<PutRuntimeLogConfigurationRequest, PutRuntimeLogConfigurationResponse, PutRuntimeLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type RegisterAccountAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers an account association with a managed thing, establishing a connection between a device and a third-party account.
 */
export declare const registerAccountAssociation: API.OperationMethod<RegisterAccountAssociationRequest, RegisterAccountAssociationResponse, RegisterAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type RegisterCustomEndpointError = AccessDeniedException | ConflictException | InternalServerException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Customers can request IoT managed integrations to manage the server trust for them or bring their own external server trusts for the custom domain. Returns an IoT managed integrations endpoint.
 */
export declare const registerCustomEndpoint: API.OperationMethod<RegisterCustomEndpointRequest, RegisterCustomEndpointResponse, RegisterCustomEndpointError, Credentials | HttpClient.HttpClient>;
export type ResetRuntimeLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Reset a runtime log configuration for a specific managed thing.
 */
export declare const resetRuntimeLogConfiguration: API.OperationMethod<ResetRuntimeLogConfigurationRequest, ResetRuntimeLogConfigurationResponse, ResetRuntimeLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type SendConnectorEventError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Relays third-party device events for a connector such as a new device or a device state change event.
 */
export declare const sendConnectorEvent: API.OperationMethod<SendConnectorEventRequest, SendConnectorEventResponse, SendConnectorEventError, Credentials | HttpClient.HttpClient>;
export type SendManagedThingCommandError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Send the command to the device represented by the managed thing.
 */
export declare const sendManagedThingCommand: API.OperationMethod<SendManagedThingCommandRequest, SendManagedThingCommandResponse, SendManagedThingCommandError, Credentials | HttpClient.HttpClient>;
export type StartAccountAssociationRefreshError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates a refresh of an existing account association to update its authorization and connection status.
 */
export declare const startAccountAssociationRefresh: API.OperationMethod<StartAccountAssociationRefreshRequest, StartAccountAssociationRefreshResponse, StartAccountAssociationRefreshError, Credentials | HttpClient.HttpClient>;
export type StartDeviceDiscoveryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * This API is used to start device discovery for hub-connected and third-party-connected devices. The authentication material (install code) is delivered as a message to the controller instructing it to start the discovery.
 */
export declare const startDeviceDiscovery: API.OperationMethod<StartDeviceDiscoveryRequest, StartDeviceDiscoveryResponse, StartDeviceDiscoveryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConflictException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Adds tags to a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConflictException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Removes tags from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an existing account association.
 */
export declare const updateAccountAssociation: API.OperationMethod<UpdateAccountAssociationRequest, UpdateAccountAssociationResponse, UpdateAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudConnectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Update an existing cloud connector.
 */
export declare const updateCloudConnector: API.OperationMethod<UpdateCloudConnectorRequest, UpdateCloudConnectorResponse, UpdateCloudConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an existing connector destination.
 */
export declare const updateConnectorDestination: API.OperationMethod<UpdateConnectorDestinationRequest, UpdateConnectorDestinationResponse, UpdateConnectorDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a destination specified by name.
 */
export declare const updateDestination: API.OperationMethod<UpdateDestinationRequest, UpdateDestinationResponse, UpdateDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateEventLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an event log configuration by log configuration ID.
 */
export declare const updateEventLogConfiguration: API.OperationMethod<UpdateEventLogConfigurationRequest, UpdateEventLogConfigurationResponse, UpdateEventLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateManagedThingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Update the attributes and capabilities associated with a managed thing.
 */
export declare const updateManagedThing: API.OperationMethod<UpdateManagedThingRequest, UpdateManagedThingResponse, UpdateManagedThingError, Credentials | HttpClient.HttpClient>;
export type UpdateNotificationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a notification configuration.
 */
export declare const updateNotificationConfiguration: API.OperationMethod<UpdateNotificationConfigurationRequest, UpdateNotificationConfigurationResponse, UpdateNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateOtaTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an over-the-air (OTA) task.
 */
export declare const updateOtaTask: API.OperationMethod<UpdateOtaTaskRequest, UpdateOtaTaskResponse, UpdateOtaTaskError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iot-managed-integrations.d.ts.map