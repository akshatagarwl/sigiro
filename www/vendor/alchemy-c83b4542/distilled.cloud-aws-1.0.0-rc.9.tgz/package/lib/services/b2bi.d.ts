import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CapabilityName = string;
export type CapabilityType = "edi" | (string & {});
export declare const CapabilityType: any;
export type CapabilityDirection = "INBOUND" | "OUTBOUND" | (string & {});
export declare const CapabilityDirection: any;
export type X12TransactionSet = "X12_100" | "X12_101" | "X12_102" | "X12_103" | "X12_104" | "X12_105" | "X12_106" | "X12_107" | "X12_108" | "X12_109" | "X12_110" | "X12_111" | "X12_112" | "X12_113" | "X12_120" | "X12_121" | "X12_124" | "X12_125" | "X12_126" | "X12_127" | "X12_128" | "X12_129" | "X12_130" | "X12_131" | "X12_132" | "X12_133" | "X12_135" | "X12_138" | "X12_139" | "X12_140" | "X12_141" | "X12_142" | "X12_143" | "X12_144" | "X12_146" | "X12_147" | "X12_148" | "X12_149" | "X12_150" | "X12_151" | "X12_152" | "X12_153" | "X12_154" | "X12_155" | "X12_157" | "X12_158" | "X12_159" | "X12_160" | "X12_161" | "X12_163" | "X12_170" | "X12_175" | "X12_176" | "X12_179" | "X12_180" | "X12_185" | "X12_186" | "X12_187" | "X12_188" | "X12_189" | "X12_190" | "X12_191" | "X12_194" | "X12_195" | "X12_196" | "X12_197" | "X12_198" | "X12_199" | "X12_200" | "X12_201" | "X12_202" | "X12_203" | "X12_204" | "X12_205" | "X12_206" | "X12_210" | "X12_211" | "X12_212" | "X12_213" | "X12_214" | "X12_215" | "X12_216" | "X12_217" | "X12_218" | "X12_219" | "X12_220" | "X12_222" | "X12_223" | "X12_224" | "X12_225" | "X12_227" | "X12_228" | "X12_240" | "X12_242" | "X12_244" | "X12_245" | "X12_248" | "X12_249" | "X12_250" | "X12_251" | "X12_252" | "X12_255" | "X12_256" | "X12_259" | "X12_260" | "X12_261" | "X12_262" | "X12_263" | "X12_264" | "X12_265" | "X12_266" | "X12_267" | "X12_268" | "X12_269" | "X12_270" | "X12_271" | "X12_272" | "X12_273" | "X12_274" | "X12_275" | "X12_276" | "X12_277" | "X12_278" | "X12_280" | "X12_283" | "X12_284" | "X12_285" | "X12_286" | "X12_288" | "X12_290" | "X12_300" | "X12_301" | "X12_303" | "X12_304" | "X12_309" | "X12_310" | "X12_311" | "X12_312" | "X12_313" | "X12_315" | "X12_317" | "X12_319" | "X12_322" | "X12_323" | "X12_324" | "X12_325" | "X12_326" | "X12_350" | "X12_352" | "X12_353" | "X12_354" | "X12_355" | "X12_356" | "X12_357" | "X12_358" | "X12_361" | "X12_362" | "X12_404" | "X12_410" | "X12_412" | "X12_414" | "X12_417" | "X12_418" | "X12_419" | "X12_420" | "X12_421" | "X12_422" | "X12_423" | "X12_424" | "X12_425" | "X12_426" | "X12_429" | "X12_431" | "X12_432" | "X12_433" | "X12_434" | "X12_435" | "X12_436" | "X12_437" | "X12_440" | "X12_451" | "X12_452" | "X12_453" | "X12_455" | "X12_456" | "X12_460" | "X12_463" | "X12_466" | "X12_468" | "X12_470" | "X12_475" | "X12_485" | "X12_486" | "X12_490" | "X12_492" | "X12_494" | "X12_500" | "X12_501" | "X12_503" | "X12_504" | "X12_511" | "X12_517" | "X12_521" | "X12_527" | "X12_536" | "X12_540" | "X12_561" | "X12_567" | "X12_568" | "X12_601" | "X12_602" | "X12_620" | "X12_625" | "X12_650" | "X12_715" | "X12_753" | "X12_754" | "X12_805" | "X12_806" | "X12_810" | "X12_811" | "X12_812" | "X12_813" | "X12_814" | "X12_815" | "X12_816" | "X12_818" | "X12_819" | "X12_820" | "X12_821" | "X12_822" | "X12_823" | "X12_824" | "X12_826" | "X12_827" | "X12_828" | "X12_829" | "X12_830" | "X12_831" | "X12_832" | "X12_833" | "X12_834" | "X12_835" | "X12_836" | "X12_837" | "X12_838" | "X12_839" | "X12_840" | "X12_841" | "X12_842" | "X12_843" | "X12_844" | "X12_845" | "X12_846" | "X12_847" | "X12_848" | "X12_849" | "X12_850" | "X12_851" | "X12_852" | "X12_853" | "X12_854" | "X12_855" | "X12_856" | "X12_857" | "X12_858" | "X12_859" | "X12_860" | "X12_861" | "X12_862" | "X12_863" | "X12_864" | "X12_865" | "X12_866" | "X12_867" | "X12_868" | "X12_869" | "X12_870" | "X12_871" | "X12_872" | "X12_873" | "X12_874" | "X12_875" | "X12_876" | "X12_877" | "X12_878" | "X12_879" | "X12_880" | "X12_881" | "X12_882" | "X12_883" | "X12_884" | "X12_885" | "X12_886" | "X12_887" | "X12_888" | "X12_889" | "X12_891" | "X12_893" | "X12_894" | "X12_895" | "X12_896" | "X12_920" | "X12_924" | "X12_925" | "X12_926" | "X12_928" | "X12_940" | "X12_943" | "X12_944" | "X12_945" | "X12_947" | "X12_980" | "X12_990" | "X12_993" | "X12_996" | "X12_997" | "X12_998" | "X12_999" | "X12_270_X279" | "X12_271_X279" | "X12_275_X210" | "X12_275_X211" | "X12_276_X212" | "X12_277_X212" | "X12_277_X214" | "X12_277_X364" | "X12_278_X217" | "X12_820_X218" | "X12_820_X306" | "X12_824_X186" | "X12_834_X220" | "X12_834_X307" | "X12_834_X318" | "X12_835_X221" | "X12_837_X222" | "X12_837_X223" | "X12_837_X224" | "X12_837_X291" | "X12_837_X292" | "X12_837_X298" | "X12_999_X231" | (string & {});
export declare const X12TransactionSet: any;
export type X12Version = "VERSION_4010" | "VERSION_4030" | "VERSION_4050" | "VERSION_4060" | "VERSION_5010" | "VERSION_5010_HIPAA" | (string & {});
export declare const X12Version: any;
export interface X12Details {
    transactionSet?: X12TransactionSet;
    version?: X12Version;
}
export declare const X12Details: S.Schema<X12Details>;
export type EdiType = {
    x12Details: X12Details;
};
export declare const EdiType: any;
export type BucketName = string;
export type S3Key = string;
export interface S3Location {
    bucketName?: string;
    key?: string;
}
export declare const S3Location: S.Schema<S3Location>;
export type TransformerId = string;
export interface EdiConfiguration {
    capabilityDirection?: CapabilityDirection;
    type: EdiType;
    inputLocation: S3Location;
    outputLocation: S3Location;
    transformerId: string;
}
export declare const EdiConfiguration: S.Schema<EdiConfiguration>;
export type CapabilityConfiguration = {
    edi: EdiConfiguration;
};
export declare const CapabilityConfiguration: any;
export type InstructionsDocuments = S3Location[];
export declare const InstructionsDocuments: any;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateCapabilityRequest {
    name: string;
    type: CapabilityType;
    configuration: CapabilityConfiguration;
    instructionsDocuments?: S3Location[];
    clientToken?: string;
    tags?: Tag[];
}
export declare const CreateCapabilityRequest: S.Schema<CreateCapabilityRequest>;
export type CapabilityId = string;
export type ResourceArn = string;
export type CreatedDate = Date;
export interface CreateCapabilityResponse {
    capabilityId: string;
    capabilityArn: string;
    name: string;
    type: CapabilityType;
    configuration: CapabilityConfiguration;
    instructionsDocuments?: S3Location[];
    createdAt: Date;
}
export declare const CreateCapabilityResponse: S.Schema<CreateCapabilityResponse>;
export type ProfileId = string;
export type PartnerName = string;
export type Email = string | redacted.Redacted<string>;
export type Phone = string | redacted.Redacted<string>;
export type PartnershipCapabilities = string[];
export declare const PartnershipCapabilities: any;
export type X12IdQualifier = string;
export type X12SenderId = string;
export type X12ReceiverId = string;
export type X12RepetitionSeparator = string;
export type X12AcknowledgmentRequestedCode = string;
export type X12UsageIndicatorCode = string;
export interface X12InterchangeControlHeaders {
    senderIdQualifier?: string;
    senderId?: string;
    receiverIdQualifier?: string;
    receiverId?: string;
    repetitionSeparator?: string;
    acknowledgmentRequestedCode?: string;
    usageIndicatorCode?: string;
}
export declare const X12InterchangeControlHeaders: S.Schema<X12InterchangeControlHeaders>;
export type X12ApplicationSenderCode = string;
export type X12ApplicationReceiverCode = string;
export type X12ResponsibleAgencyCode = string;
export interface X12FunctionalGroupHeaders {
    applicationSenderCode?: string;
    applicationReceiverCode?: string;
    responsibleAgencyCode?: string;
}
export declare const X12FunctionalGroupHeaders: S.Schema<X12FunctionalGroupHeaders>;
export type X12ComponentSeparator = string;
export type X12DataElementSeparator = string;
export type X12SegmentTerminator = string;
export interface X12Delimiters {
    componentSeparator?: string;
    dataElementSeparator?: string;
    segmentTerminator?: string;
}
export declare const X12Delimiters: S.Schema<X12Delimiters>;
export type X12ValidateEdi = boolean;
export type StartingInterchangeControlNumber = number;
export type StartingFunctionalGroupControlNumber = number;
export type StartingTransactionSetControlNumber = number;
export interface X12ControlNumbers {
    startingInterchangeControlNumber?: number;
    startingFunctionalGroupControlNumber?: number;
    startingTransactionSetControlNumber?: number;
}
export declare const X12ControlNumbers: S.Schema<X12ControlNumbers>;
export type X12GS05TimeFormat = "HHMM" | "HHMMSS" | "HHMMSSDD" | (string & {});
export declare const X12GS05TimeFormat: any;
export interface X12OutboundEdiHeaders {
    interchangeControlHeaders?: X12InterchangeControlHeaders;
    functionalGroupHeaders?: X12FunctionalGroupHeaders;
    delimiters?: X12Delimiters;
    validateEdi?: boolean;
    controlNumbers?: X12ControlNumbers;
    gs05TimeFormat?: X12GS05TimeFormat;
}
export declare const X12OutboundEdiHeaders: S.Schema<X12OutboundEdiHeaders>;
export type WrapFormat = "SEGMENT" | "ONE_LINE" | "LINE_LENGTH" | (string & {});
export declare const WrapFormat: any;
export type LineTerminator = "CRLF" | "LF" | "CR" | (string & {});
export declare const LineTerminator: any;
export type LineLength = number;
export interface WrapOptions {
    wrapBy: WrapFormat;
    lineTerminator?: LineTerminator;
    lineLength?: number;
}
export declare const WrapOptions: S.Schema<WrapOptions>;
export interface X12Envelope {
    common?: X12OutboundEdiHeaders;
    wrapOptions?: WrapOptions;
}
export declare const X12Envelope: S.Schema<X12Envelope>;
export type OutboundEdiOptions = {
    x12: X12Envelope;
};
export declare const OutboundEdiOptions: any;
export type X12FunctionalAcknowledgment = "DO_NOT_GENERATE" | "GENERATE_ALL_SEGMENTS" | "GENERATE_WITHOUT_TRANSACTION_SET_RESPONSE_LOOP" | (string & {});
export declare const X12FunctionalAcknowledgment: any;
export type X12TechnicalAcknowledgment = "DO_NOT_GENERATE" | "GENERATE_ALL_SEGMENTS" | (string & {});
export declare const X12TechnicalAcknowledgment: any;
export interface X12AcknowledgmentOptions {
    functionalAcknowledgment: X12FunctionalAcknowledgment;
    technicalAcknowledgment: X12TechnicalAcknowledgment;
}
export declare const X12AcknowledgmentOptions: S.Schema<X12AcknowledgmentOptions>;
export interface X12InboundEdiOptions {
    acknowledgmentOptions?: X12AcknowledgmentOptions;
}
export declare const X12InboundEdiOptions: S.Schema<X12InboundEdiOptions>;
export interface InboundEdiOptions {
    x12?: X12InboundEdiOptions;
}
export declare const InboundEdiOptions: S.Schema<InboundEdiOptions>;
export interface CapabilityOptions {
    outboundEdi?: OutboundEdiOptions;
    inboundEdi?: InboundEdiOptions;
}
export declare const CapabilityOptions: S.Schema<CapabilityOptions>;
export interface CreatePartnershipRequest {
    profileId: string;
    name: string;
    email: string | redacted.Redacted<string>;
    phone?: string | redacted.Redacted<string>;
    capabilities: string[];
    capabilityOptions?: CapabilityOptions;
    clientToken?: string;
    tags?: Tag[];
}
export declare const CreatePartnershipRequest: S.Schema<CreatePartnershipRequest>;
export type PartnershipId = string;
export type TradingPartnerId = string;
export interface CreatePartnershipResponse {
    profileId: string;
    partnershipId: string;
    partnershipArn: string;
    name?: string;
    email?: string | redacted.Redacted<string>;
    phone?: string | redacted.Redacted<string>;
    capabilities?: string[];
    capabilityOptions?: CapabilityOptions;
    tradingPartnerId?: string;
    createdAt: Date;
}
export declare const CreatePartnershipResponse: S.Schema<CreatePartnershipResponse>;
export type ProfileName = string;
export type BusinessName = string;
export type Logging = "ENABLED" | "DISABLED" | (string & {});
export declare const Logging: any;
export interface CreateProfileRequest {
    name: string;
    email?: string | redacted.Redacted<string>;
    phone: string | redacted.Redacted<string>;
    businessName: string;
    logging: Logging;
    clientToken?: string;
    tags?: Tag[];
}
export declare const CreateProfileRequest: S.Schema<CreateProfileRequest>;
export type LogGroupName = string;
export interface CreateProfileResponse {
    profileId: string;
    profileArn: string;
    name: string;
    businessName: string;
    phone: string | redacted.Redacted<string>;
    email?: string | redacted.Redacted<string>;
    logging?: Logging;
    logGroupName?: string;
    createdAt: Date;
}
export declare const CreateProfileResponse: S.Schema<CreateProfileResponse>;
export type MappingType = "JSONATA" | "XSLT" | (string & {});
export declare const MappingType: any;
export type TemplateDetails = {
    x12: X12Details;
};
export declare const TemplateDetails: any;
export interface CreateStarterMappingTemplateRequest {
    outputSampleLocation?: S3Location;
    mappingType: MappingType;
    templateDetails: TemplateDetails;
}
export declare const CreateStarterMappingTemplateRequest: S.Schema<CreateStarterMappingTemplateRequest>;
export interface CreateStarterMappingTemplateResponse {
    mappingTemplate: string;
}
export declare const CreateStarterMappingTemplateResponse: S.Schema<CreateStarterMappingTemplateResponse>;
export type TransformerName = string;
export type FileFormat = "XML" | "JSON" | "NOT_USED" | (string & {});
export declare const FileFormat: any;
export type MappingTemplate = string;
export type FileLocation = string;
export type FromFormat = "X12" | (string & {});
export declare const FromFormat: any;
export type FormatOptions = {
    x12: X12Details;
};
export declare const FormatOptions: any;
export type X12SplitBy = "NONE" | "TRANSACTION" | (string & {});
export declare const X12SplitBy: any;
export interface X12SplitOptions {
    splitBy: X12SplitBy;
}
export declare const X12SplitOptions: S.Schema<X12SplitOptions>;
export type ElementId = string;
export type CodeList = string[];
export declare const CodeList: any;
export interface X12CodeListValidationRule {
    elementId: string;
    codesToAdd?: string[];
    codesToRemove?: string[];
}
export declare const X12CodeListValidationRule: S.Schema<X12CodeListValidationRule>;
export interface X12ElementLengthValidationRule {
    elementId: string;
    maxLength: number;
    minLength: number;
}
export declare const X12ElementLengthValidationRule: S.Schema<X12ElementLengthValidationRule>;
export type ElementPosition = string;
export type ElementRequirement = "OPTIONAL" | "MANDATORY" | (string & {});
export declare const ElementRequirement: any;
export interface X12ElementRequirementValidationRule {
    elementPosition: string;
    requirement: ElementRequirement;
}
export declare const X12ElementRequirementValidationRule: S.Schema<X12ElementRequirementValidationRule>;
export type X12ValidationRule = {
    codeListValidationRule: X12CodeListValidationRule;
    elementLengthValidationRule?: never;
    elementRequirementValidationRule?: never;
} | {
    codeListValidationRule?: never;
    elementLengthValidationRule: X12ElementLengthValidationRule;
    elementRequirementValidationRule?: never;
} | {
    codeListValidationRule?: never;
    elementLengthValidationRule?: never;
    elementRequirementValidationRule: X12ElementRequirementValidationRule;
};
export declare const X12ValidationRule: any;
export type X12ValidationRules = X12ValidationRule[];
export declare const X12ValidationRules: any;
export interface X12ValidationOptions {
    validationRules?: X12ValidationRule[];
}
export declare const X12ValidationOptions: S.Schema<X12ValidationOptions>;
export interface X12AdvancedOptions {
    splitOptions?: X12SplitOptions;
    validationOptions?: X12ValidationOptions;
}
export declare const X12AdvancedOptions: S.Schema<X12AdvancedOptions>;
export interface AdvancedOptions {
    x12?: X12AdvancedOptions;
}
export declare const AdvancedOptions: S.Schema<AdvancedOptions>;
export interface InputConversion {
    fromFormat: FromFormat;
    formatOptions?: FormatOptions;
    advancedOptions?: AdvancedOptions;
}
export declare const InputConversion: S.Schema<InputConversion>;
export type MappingTemplateLanguage = "XSLT" | "JSONATA" | (string & {});
export declare const MappingTemplateLanguage: any;
export interface Mapping {
    templateLanguage: MappingTemplateLanguage;
    template?: string;
}
export declare const Mapping: S.Schema<Mapping>;
export type ToFormat = "X12" | (string & {});
export declare const ToFormat: any;
export interface OutputConversion {
    toFormat: ToFormat;
    formatOptions?: FormatOptions;
    advancedOptions?: AdvancedOptions;
}
export declare const OutputConversion: S.Schema<OutputConversion>;
export interface SampleDocumentKeys {
    input?: string;
    output?: string;
}
export declare const SampleDocumentKeys: S.Schema<SampleDocumentKeys>;
export type KeyList = SampleDocumentKeys[];
export declare const KeyList: any;
export interface SampleDocuments {
    bucketName: string;
    keys: SampleDocumentKeys[];
}
export declare const SampleDocuments: S.Schema<SampleDocuments>;
export interface CreateTransformerRequest {
    name: string;
    clientToken?: string;
    tags?: Tag[];
    fileFormat?: FileFormat;
    mappingTemplate?: string;
    ediType?: EdiType;
    sampleDocument?: string;
    inputConversion?: InputConversion;
    mapping?: Mapping;
    outputConversion?: OutputConversion;
    sampleDocuments?: SampleDocuments;
}
export declare const CreateTransformerRequest: S.Schema<CreateTransformerRequest>;
export type TransformerStatus = "active" | "inactive" | (string & {});
export declare const TransformerStatus: any;
export interface CreateTransformerResponse {
    transformerId: string;
    transformerArn: string;
    name: string;
    status: TransformerStatus;
    createdAt: Date;
    fileFormat?: FileFormat;
    mappingTemplate?: string;
    ediType?: EdiType;
    sampleDocument?: string;
    inputConversion?: InputConversion;
    mapping?: Mapping;
    outputConversion?: OutputConversion;
    sampleDocuments?: SampleDocuments;
}
export declare const CreateTransformerResponse: S.Schema<CreateTransformerResponse>;
export interface DeleteCapabilityRequest {
    capabilityId: string;
}
export declare const DeleteCapabilityRequest: S.Schema<DeleteCapabilityRequest>;
export interface DeleteCapabilityResponse {
}
export declare const DeleteCapabilityResponse: S.Schema<DeleteCapabilityResponse>;
export interface DeletePartnershipRequest {
    partnershipId: string;
}
export declare const DeletePartnershipRequest: S.Schema<DeletePartnershipRequest>;
export interface DeletePartnershipResponse {
}
export declare const DeletePartnershipResponse: S.Schema<DeletePartnershipResponse>;
export interface DeleteProfileRequest {
    profileId: string;
}
export declare const DeleteProfileRequest: S.Schema<DeleteProfileRequest>;
export interface DeleteProfileResponse {
}
export declare const DeleteProfileResponse: S.Schema<DeleteProfileResponse>;
export interface DeleteTransformerRequest {
    transformerId: string;
}
export declare const DeleteTransformerRequest: S.Schema<DeleteTransformerRequest>;
export interface DeleteTransformerResponse {
}
export declare const DeleteTransformerResponse: S.Schema<DeleteTransformerResponse>;
export type GenerateMappingInputFileContent = string;
export type GenerateMappingOutputFileContent = string;
export interface GenerateMappingRequest {
    inputFileContent: string;
    outputFileContent: string;
    mappingType: MappingType;
}
export declare const GenerateMappingRequest: S.Schema<GenerateMappingRequest>;
export interface GenerateMappingResponse {
    mappingTemplate: string;
    mappingAccuracy?: number;
}
export declare const GenerateMappingResponse: S.Schema<GenerateMappingResponse>;
export interface GetCapabilityRequest {
    capabilityId: string;
}
export declare const GetCapabilityRequest: S.Schema<GetCapabilityRequest>;
export type ModifiedDate = Date;
export interface GetCapabilityResponse {
    capabilityId: string;
    capabilityArn: string;
    name: string;
    type: CapabilityType;
    configuration: CapabilityConfiguration;
    instructionsDocuments?: S3Location[];
    createdAt: Date;
    modifiedAt?: Date;
}
export declare const GetCapabilityResponse: S.Schema<GetCapabilityResponse>;
export interface GetPartnershipRequest {
    partnershipId: string;
}
export declare const GetPartnershipRequest: S.Schema<GetPartnershipRequest>;
export interface GetPartnershipResponse {
    profileId: string;
    partnershipId: string;
    partnershipArn: string;
    name?: string;
    email?: string | redacted.Redacted<string>;
    phone?: string | redacted.Redacted<string>;
    capabilities?: string[];
    capabilityOptions?: CapabilityOptions;
    tradingPartnerId?: string;
    createdAt: Date;
    modifiedAt?: Date;
}
export declare const GetPartnershipResponse: S.Schema<GetPartnershipResponse>;
export interface GetProfileRequest {
    profileId: string;
}
export declare const GetProfileRequest: S.Schema<GetProfileRequest>;
export interface GetProfileResponse {
    profileId: string;
    profileArn: string;
    name: string;
    email?: string | redacted.Redacted<string>;
    phone: string | redacted.Redacted<string>;
    businessName: string;
    logging?: Logging;
    logGroupName?: string;
    createdAt: Date;
    modifiedAt?: Date;
}
export declare const GetProfileResponse: S.Schema<GetProfileResponse>;
export interface GetTransformerRequest {
    transformerId: string;
}
export declare const GetTransformerRequest: S.Schema<GetTransformerRequest>;
export interface GetTransformerResponse {
    transformerId: string;
    transformerArn: string;
    name: string;
    status: TransformerStatus;
    createdAt: Date;
    modifiedAt?: Date;
    fileFormat?: FileFormat;
    mappingTemplate?: string;
    ediType?: EdiType;
    sampleDocument?: string;
    inputConversion?: InputConversion;
    mapping?: Mapping;
    outputConversion?: OutputConversion;
    sampleDocuments?: SampleDocuments;
}
export declare const GetTransformerResponse: S.Schema<GetTransformerResponse>;
export type TransformerJobId = string;
export interface GetTransformerJobRequest {
    transformerJobId: string;
    transformerId: string;
}
export declare const GetTransformerJobRequest: S.Schema<GetTransformerJobRequest>;
export type TransformerJobStatus = "running" | "succeeded" | "failed" | (string & {});
export declare const TransformerJobStatus: any;
export type S3LocationList = S3Location[];
export declare const S3LocationList: any;
export interface GetTransformerJobResponse {
    status: TransformerJobStatus;
    outputFiles?: S3Location[];
    message?: string;
}
export declare const GetTransformerJobResponse: S.Schema<GetTransformerJobResponse>;
export type PageToken = string;
export type MaxResults = number;
export interface ListCapabilitiesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListCapabilitiesRequest: S.Schema<ListCapabilitiesRequest>;
export interface CapabilitySummary {
    capabilityId: string;
    name: string;
    type: CapabilityType;
    createdAt: Date;
    modifiedAt?: Date;
}
export declare const CapabilitySummary: S.Schema<CapabilitySummary>;
export type CapabilityList = CapabilitySummary[];
export declare const CapabilityList: any;
export interface ListCapabilitiesResponse {
    capabilities: CapabilitySummary[];
    nextToken?: string;
}
export declare const ListCapabilitiesResponse: S.Schema<ListCapabilitiesResponse>;
export interface ListPartnershipsRequest {
    profileId?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPartnershipsRequest: S.Schema<ListPartnershipsRequest>;
export interface PartnershipSummary {
    profileId: string;
    partnershipId: string;
    name?: string;
    capabilities?: string[];
    capabilityOptions?: CapabilityOptions;
    tradingPartnerId?: string;
    createdAt: Date;
    modifiedAt?: Date;
}
export declare const PartnershipSummary: S.Schema<PartnershipSummary>;
export type PartnershipList = PartnershipSummary[];
export declare const PartnershipList: any;
export interface ListPartnershipsResponse {
    partnerships: PartnershipSummary[];
    nextToken?: string;
}
export declare const ListPartnershipsResponse: S.Schema<ListPartnershipsResponse>;
export interface ListProfilesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListProfilesRequest: S.Schema<ListProfilesRequest>;
export interface ProfileSummary {
    profileId: string;
    name: string;
    businessName: string;
    logging?: Logging;
    logGroupName?: string;
    createdAt: Date;
    modifiedAt?: Date;
}
export declare const ProfileSummary: S.Schema<ProfileSummary>;
export type ProfileList = ProfileSummary[];
export declare const ProfileList: any;
export interface ListProfilesResponse {
    profiles: ProfileSummary[];
    nextToken?: string;
}
export declare const ListProfilesResponse: S.Schema<ListProfilesResponse>;
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListTransformersRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListTransformersRequest: S.Schema<ListTransformersRequest>;
export interface TransformerSummary {
    transformerId: string;
    name: string;
    status: TransformerStatus;
    createdAt: Date;
    modifiedAt?: Date;
    fileFormat?: FileFormat;
    mappingTemplate?: string;
    ediType?: EdiType;
    sampleDocument?: string;
    inputConversion?: InputConversion;
    mapping?: Mapping;
    outputConversion?: OutputConversion;
    sampleDocuments?: SampleDocuments;
}
export declare const TransformerSummary: S.Schema<TransformerSummary>;
export type TransformerList = TransformerSummary[];
export declare const TransformerList: any;
export interface ListTransformersResponse {
    transformers: TransformerSummary[];
    nextToken?: string;
}
export declare const ListTransformersResponse: S.Schema<ListTransformersResponse>;
export interface StartTransformerJobRequest {
    inputFile: S3Location;
    outputLocation: S3Location;
    transformerId: string;
    clientToken?: string;
}
export declare const StartTransformerJobRequest: S.Schema<StartTransformerJobRequest>;
export interface StartTransformerJobResponse {
    transformerJobId: string;
}
export declare const StartTransformerJobResponse: S.Schema<StartTransformerJobResponse>;
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type ConversionSourceFormat = "JSON" | "XML" | (string & {});
export declare const ConversionSourceFormat: any;
export type InputFileSource = {
    fileContent: string;
};
export declare const InputFileSource: any;
export interface ConversionSource {
    fileFormat: ConversionSourceFormat;
    inputFile: InputFileSource;
}
export declare const ConversionSource: S.Schema<ConversionSource>;
export type ConversionTargetFormat = "X12" | (string & {});
export declare const ConversionTargetFormat: any;
export type ConversionTargetFormatDetails = {
    x12: X12Details;
};
export declare const ConversionTargetFormatDetails: any;
export type OutputSampleFileSource = {
    fileLocation: S3Location;
};
export declare const OutputSampleFileSource: any;
export interface ConversionTarget {
    fileFormat: ConversionTargetFormat;
    formatDetails?: ConversionTargetFormatDetails;
    outputSampleFile?: OutputSampleFileSource;
    advancedOptions?: AdvancedOptions;
}
export declare const ConversionTarget: S.Schema<ConversionTarget>;
export interface TestConversionRequest {
    source: ConversionSource;
    target: ConversionTarget;
}
export declare const TestConversionRequest: S.Schema<TestConversionRequest>;
export type ValidationMessages = string[];
export declare const ValidationMessages: any;
export interface TestConversionResponse {
    convertedFileContent: string;
    validationMessages?: string[];
}
export declare const TestConversionResponse: S.Schema<TestConversionResponse>;
export type TestMappingInputFileContent = string;
export interface TestMappingRequest {
    inputFileContent: string;
    mappingTemplate: string;
    fileFormat: FileFormat;
}
export declare const TestMappingRequest: S.Schema<TestMappingRequest>;
export interface TestMappingResponse {
    mappedFileContent: string;
}
export declare const TestMappingResponse: S.Schema<TestMappingResponse>;
export interface TestParsingRequest {
    inputFile: S3Location;
    fileFormat: FileFormat;
    ediType: EdiType;
    advancedOptions?: AdvancedOptions;
}
export declare const TestParsingRequest: S.Schema<TestParsingRequest>;
export type ParsedSplitFileContentsList = string[];
export declare const ParsedSplitFileContentsList: any;
export interface TestParsingResponse {
    parsedFileContent: string;
    parsedSplitFileContents?: string[];
    validationMessages?: string[];
}
export declare const TestParsingResponse: S.Schema<TestParsingResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateCapabilityRequest {
    capabilityId: string;
    name?: string;
    configuration?: CapabilityConfiguration;
    instructionsDocuments?: S3Location[];
}
export declare const UpdateCapabilityRequest: S.Schema<UpdateCapabilityRequest>;
export interface UpdateCapabilityResponse {
    capabilityId: string;
    capabilityArn: string;
    name: string;
    type: CapabilityType;
    configuration: CapabilityConfiguration;
    instructionsDocuments?: S3Location[];
    createdAt: Date;
    modifiedAt?: Date;
}
export declare const UpdateCapabilityResponse: S.Schema<UpdateCapabilityResponse>;
export interface UpdatePartnershipRequest {
    partnershipId: string;
    name?: string;
    capabilities?: string[];
    capabilityOptions?: CapabilityOptions;
}
export declare const UpdatePartnershipRequest: S.Schema<UpdatePartnershipRequest>;
export interface UpdatePartnershipResponse {
    profileId: string;
    partnershipId: string;
    partnershipArn: string;
    name?: string;
    email?: string | redacted.Redacted<string>;
    phone?: string | redacted.Redacted<string>;
    capabilities?: string[];
    capabilityOptions?: CapabilityOptions;
    tradingPartnerId?: string;
    createdAt: Date;
    modifiedAt?: Date;
}
export declare const UpdatePartnershipResponse: S.Schema<UpdatePartnershipResponse>;
export interface UpdateProfileRequest {
    profileId: string;
    name?: string;
    email?: string | redacted.Redacted<string>;
    phone?: string | redacted.Redacted<string>;
    businessName?: string;
}
export declare const UpdateProfileRequest: S.Schema<UpdateProfileRequest>;
export interface UpdateProfileResponse {
    profileId: string;
    profileArn: string;
    name: string;
    email?: string | redacted.Redacted<string>;
    phone: string | redacted.Redacted<string>;
    businessName: string;
    logging?: Logging;
    logGroupName?: string;
    createdAt: Date;
    modifiedAt?: Date;
}
export declare const UpdateProfileResponse: S.Schema<UpdateProfileResponse>;
export interface UpdateTransformerRequest {
    transformerId: string;
    name?: string;
    status?: TransformerStatus;
    fileFormat?: FileFormat;
    mappingTemplate?: string;
    ediType?: EdiType;
    sampleDocument?: string;
    inputConversion?: InputConversion;
    mapping?: Mapping;
    outputConversion?: OutputConversion;
    sampleDocuments?: SampleDocuments;
}
export declare const UpdateTransformerRequest: S.Schema<UpdateTransformerRequest>;
export interface UpdateTransformerResponse {
    transformerId: string;
    transformerArn: string;
    name: string;
    status: TransformerStatus;
    createdAt: Date;
    modifiedAt: Date;
    fileFormat?: FileFormat;
    mappingTemplate?: string;
    ediType?: EdiType;
    sampleDocument?: string;
    inputConversion?: InputConversion;
    mapping?: Mapping;
    outputConversion?: OutputConversion;
    sampleDocuments?: SampleDocuments;
}
export declare const UpdateTransformerResponse: S.Schema<UpdateTransformerResponse>;
export type ErrorMessage = string;
export type CreateCapabilityError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Instantiates a capability based on the specified parameters. A trading capability contains the information required to transform incoming EDI documents into JSON or XML outputs.
 */
export declare const createCapability: API.OperationMethod<CreateCapabilityRequest, CreateCapabilityResponse, CreateCapabilityError, Credentials | HttpClient.HttpClient>;
export type CreatePartnershipError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a partnership between a customer and a trading partner, based on the supplied parameters. A partnership represents the connection between you and your trading partner. It ties together a profile and one or more trading capabilities.
 */
export declare const createPartnership: API.OperationMethod<CreatePartnershipRequest, CreatePartnershipResponse, CreatePartnershipError, Credentials | HttpClient.HttpClient>;
export type CreateProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a customer profile. You can have up to five customer profiles, each representing a distinct private network. A profile is the mechanism used to create the concept of a private network.
 */
export declare const createProfile: API.OperationMethod<CreateProfileRequest, CreateProfileResponse, CreateProfileError, Credentials | HttpClient.HttpClient>;
export type CreateStarterMappingTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Amazon Web Services B2B Data Interchange uses a mapping template in JSONata or XSLT format to transform a customer input file into a JSON or XML file that can be converted to EDI.
 *
 * If you provide a sample EDI file with the same structure as the EDI files that you wish to generate, then the service can generate a mapping template. The starter template contains placeholder values which you can replace with JSONata or XSLT expressions to take data from your input file and insert it into the JSON or XML file that is used to generate the EDI.
 *
 * If you do not provide a sample EDI file, then the service can generate a mapping template based on the EDI settings in the `templateDetails` parameter.
 *
 * Currently, we only support generating a template that can generate the input to produce an Outbound X12 EDI file.
 */
export declare const createStarterMappingTemplate: API.OperationMethod<CreateStarterMappingTemplateRequest, CreateStarterMappingTemplateResponse, CreateStarterMappingTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateTransformerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a transformer. Amazon Web Services B2B Data Interchange currently supports two scenarios:
 *
 * - *Inbound EDI*: the Amazon Web Services customer receives an EDI file from their trading partner. Amazon Web Services B2B Data Interchange converts this EDI file into a JSON or XML file with a service-defined structure. A mapping template provided by the customer, in JSONata or XSLT format, is optionally applied to this file to produce a JSON or XML file with the structure the customer requires.
 *
 * - *Outbound EDI*: the Amazon Web Services customer has a JSON or XML file containing data that they wish to use in an EDI file. A mapping template, provided by the customer (in either JSONata or XSLT format) is applied to this file to generate a JSON or XML file in the service-defined structure. This file is then converted to an EDI file.
 *
 * The following fields are provided for backwards compatibility only: `fileFormat`, `mappingTemplate`, `ediType`, and `sampleDocument`.
 *
 * - Use the `mapping` data type in place of `mappingTemplate` and `fileFormat`
 *
 * - Use the `sampleDocuments` data type in place of `sampleDocument`
 *
 * - Use either the `inputConversion` or `outputConversion` in place of `ediType`
 */
export declare const createTransformer: API.OperationMethod<CreateTransformerRequest, CreateTransformerResponse, CreateTransformerError, Credentials | HttpClient.HttpClient>;
export type DeleteCapabilityError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified capability. A trading capability contains the information required to transform incoming EDI documents into JSON or XML outputs.
 */
export declare const deleteCapability: API.OperationMethod<DeleteCapabilityRequest, DeleteCapabilityResponse, DeleteCapabilityError, Credentials | HttpClient.HttpClient>;
export type DeletePartnershipError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified partnership. A partnership represents the connection between you and your trading partner. It ties together a profile and one or more trading capabilities.
 */
export declare const deletePartnership: API.OperationMethod<DeletePartnershipRequest, DeletePartnershipResponse, DeletePartnershipError, Credentials | HttpClient.HttpClient>;
export type DeleteProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified profile. A profile is the mechanism used to create the concept of a private network.
 */
export declare const deleteProfile: API.OperationMethod<DeleteProfileRequest, DeleteProfileResponse, DeleteProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteTransformerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified transformer. A transformer can take an EDI file as input and transform it into a JSON-or XML-formatted document. Alternatively, a transformer can take a JSON-or XML-formatted document as input and transform it into an EDI file.
 */
export declare const deleteTransformer: API.OperationMethod<DeleteTransformerRequest, DeleteTransformerResponse, DeleteTransformerError, Credentials | HttpClient.HttpClient>;
export type GenerateMappingError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Takes sample input and output documents and uses Amazon Bedrock to generate a mapping automatically. Depending on the accuracy and other factors, you can then edit the mapping for your needs.
 *
 * Before you can use the AI-assisted feature for Amazon Web Services B2B Data Interchange you must enable models in Amazon Bedrock. For details, see AI-assisted template mapping prerequisites in the *Amazon Web Services B2B Data Interchange User guide*.
 *
 * To generate a mapping, perform the following steps:
 *
 * - Start with an X12 EDI document to use as the input.
 *
 * - Call `TestMapping` using your EDI document.
 *
 * - Use the output from the `TestMapping` operation as either input or output for your GenerateMapping call, along with your sample file.
 */
export declare const generateMapping: API.OperationMethod<GenerateMappingRequest, GenerateMappingResponse, GenerateMappingError, Credentials | HttpClient.HttpClient>;
export type GetCapabilityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details for the specified capability. A trading capability contains the information required to transform incoming EDI documents into JSON or XML outputs.
 */
export declare const getCapability: API.OperationMethod<GetCapabilityRequest, GetCapabilityResponse, GetCapabilityError, Credentials | HttpClient.HttpClient>;
export type GetPartnershipError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details for a partnership, based on the partner and profile IDs specified. A partnership represents the connection between you and your trading partner. It ties together a profile and one or more trading capabilities.
 */
export declare const getPartnership: API.OperationMethod<GetPartnershipRequest, GetPartnershipResponse, GetPartnershipError, Credentials | HttpClient.HttpClient>;
export type GetProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details for the profile specified by the profile ID. A profile is the mechanism used to create the concept of a private network.
 */
export declare const getProfile: API.OperationMethod<GetProfileRequest, GetProfileResponse, GetProfileError, Credentials | HttpClient.HttpClient>;
export type GetTransformerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details for the transformer specified by the transformer ID. A transformer can take an EDI file as input and transform it into a JSON-or XML-formatted document. Alternatively, a transformer can take a JSON-or XML-formatted document as input and transform it into an EDI file.
 */
export declare const getTransformer: API.OperationMethod<GetTransformerRequest, GetTransformerResponse, GetTransformerError, Credentials | HttpClient.HttpClient>;
export type GetTransformerJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the details of the transformer run, based on the Transformer job ID.
 *
 * If 30 days have elapsed since your transformer job was started, the system deletes it. So, if you run `GetTransformerJob` and supply a `transformerId` and `transformerJobId` for a job that was started more than 30 days previously, you receive a 404 response.
 */
export declare const getTransformerJob: API.OperationMethod<GetTransformerJobRequest, GetTransformerJobResponse, GetTransformerJobError, Credentials | HttpClient.HttpClient>;
export type ListCapabilitiesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the capabilities associated with your Amazon Web Services account for your current or specified region. A trading capability contains the information required to transform incoming EDI documents into JSON or XML outputs.
 */
export declare const listCapabilities: API.PaginatedOperationMethod<ListCapabilitiesRequest, ListCapabilitiesResponse, ListCapabilitiesError, Credentials | HttpClient.HttpClient, CapabilitySummary>;
export type ListPartnershipsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the partnerships associated with your Amazon Web Services account for your current or specified region. A partnership represents the connection between you and your trading partner. It ties together a profile and one or more trading capabilities.
 */
export declare const listPartnerships: API.PaginatedOperationMethod<ListPartnershipsRequest, ListPartnershipsResponse, ListPartnershipsError, Credentials | HttpClient.HttpClient, PartnershipSummary>;
export type ListProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the profiles associated with your Amazon Web Services account for your current or specified region. A profile is the mechanism used to create the concept of a private network.
 */
export declare const listProfiles: API.PaginatedOperationMethod<ListProfilesRequest, ListProfilesResponse, ListProfilesError, Credentials | HttpClient.HttpClient, ProfileSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all of the tags associated with the Amazon Resource Name (ARN) that you specify. The resource can be a capability, partnership, profile, or transformer.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTransformersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the available transformers. A transformer can take an EDI file as input and transform it into a JSON-or XML-formatted document. Alternatively, a transformer can take a JSON-or XML-formatted document as input and transform it into an EDI file.
 */
export declare const listTransformers: API.PaginatedOperationMethod<ListTransformersRequest, ListTransformersResponse, ListTransformersError, Credentials | HttpClient.HttpClient, TransformerSummary>;
export type StartTransformerJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Runs a job, using a transformer, to parse input EDI (electronic data interchange) file into the output structures used by Amazon Web Services B2B Data Interchange.
 *
 * If you only want to transform EDI (electronic data interchange) documents, you don't need to create profiles, partnerships or capabilities. Just create and configure a transformer, and then run the `StartTransformerJob` API to process your files.
 *
 * The system stores transformer jobs for 30 days. During that period, you can run GetTransformerJob and supply its `transformerId` and `transformerJobId` to return details of the job.
 */
export declare const startTransformerJob: API.OperationMethod<StartTransformerJobRequest, StartTransformerJobResponse, StartTransformerJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Attaches a key-value pair to a resource, as identified by its Amazon Resource Name (ARN). Resources are capability, partnership, profile, transformers and other entities.
 *
 * There is no response returned from this call.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestConversionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation mimics the latter half of a typical Outbound EDI request. It takes an input JSON/XML in the B2Bi shape as input, converts it to an X12 EDI string, and return that string.
 */
export declare const testConversion: API.OperationMethod<TestConversionRequest, TestConversionResponse, TestConversionError, Credentials | HttpClient.HttpClient>;
export type TestMappingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Maps the input file according to the provided template file. The API call downloads the file contents from the Amazon S3 location, and passes the contents in as a string, to the `inputFileContent` parameter.
 */
export declare const testMapping: API.OperationMethod<TestMappingRequest, TestMappingResponse, TestMappingError, Credentials | HttpClient.HttpClient>;
export type TestParsingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Parses the input EDI (electronic data interchange) file. The input file has a file size limit of 250 KB.
 */
export declare const testParsing: API.OperationMethod<TestParsingRequest, TestParsingResponse, TestParsingError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Detaches a key-value pair from the specified resource, as identified by its Amazon Resource Name (ARN). Resources are capability, partnership, profile, transformers and other entities.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCapabilityError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates some of the parameters for a capability, based on the specified parameters. A trading capability contains the information required to transform incoming EDI documents into JSON or XML outputs.
 */
export declare const updateCapability: API.OperationMethod<UpdateCapabilityRequest, UpdateCapabilityResponse, UpdateCapabilityError, Credentials | HttpClient.HttpClient>;
export type UpdatePartnershipError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates some of the parameters for a partnership between a customer and trading partner. A partnership represents the connection between you and your trading partner. It ties together a profile and one or more trading capabilities.
 */
export declare const updatePartnership: API.OperationMethod<UpdatePartnershipRequest, UpdatePartnershipResponse, UpdatePartnershipError, Credentials | HttpClient.HttpClient>;
export type UpdateProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified parameters for a profile. A profile is the mechanism used to create the concept of a private network.
 */
export declare const updateProfile: API.OperationMethod<UpdateProfileRequest, UpdateProfileResponse, UpdateProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateTransformerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified parameters for a transformer. A transformer can take an EDI file as input and transform it into a JSON-or XML-formatted document. Alternatively, a transformer can take a JSON-or XML-formatted document as input and transform it into an EDI file.
 */
export declare const updateTransformer: API.OperationMethod<UpdateTransformerRequest, UpdateTransformerResponse, UpdateTransformerError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=b2bi.d.ts.map