import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DeletionProtectionEnabled = boolean;
export type KmsEncryptionKey = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type ClientToken = string;
export type Region = string;
export type ClusterArn = string;
export type ClusterArnList = string[];
export declare const ClusterArnList: any;
export interface MultiRegionProperties {
    witnessRegion?: string;
    clusters?: string[];
}
export declare const MultiRegionProperties: S.Schema<MultiRegionProperties>;
export type PolicyDocument = string;
export type BypassPolicyLockoutSafetyCheck = boolean;
export interface CreateClusterInput {
    deletionProtectionEnabled?: boolean;
    kmsEncryptionKey?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
    multiRegionProperties?: MultiRegionProperties;
    policy?: string;
    bypassPolicyLockoutSafetyCheck?: boolean;
}
export declare const CreateClusterInput: S.Schema<CreateClusterInput>;
export type ClusterId = string;
export type ClusterStatus = "CREATING" | "ACTIVE" | "IDLE" | "INACTIVE" | "UPDATING" | "DELETING" | "DELETED" | "FAILED" | "PENDING_SETUP" | "PENDING_DELETE" | (string & {});
export declare const ClusterStatus: any;
export type ClusterCreationTime = Date;
export type EncryptionType = "AWS_OWNED_KMS_KEY" | "CUSTOMER_MANAGED_KMS_KEY" | (string & {});
export declare const EncryptionType: any;
export type KmsKeyArn = string;
export type EncryptionStatus = "ENABLED" | "UPDATING" | "KMS_KEY_INACCESSIBLE" | "ENABLING" | (string & {});
export declare const EncryptionStatus: any;
export interface EncryptionDetails {
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
    encryptionStatus: EncryptionStatus;
}
export declare const EncryptionDetails: S.Schema<EncryptionDetails>;
export type Endpoint = string;
export interface CreateClusterOutput {
    identifier: string;
    arn: string;
    status: ClusterStatus;
    creationTime: Date;
    multiRegionProperties?: MultiRegionProperties;
    encryptionDetails?: EncryptionDetails;
    deletionProtectionEnabled: boolean;
    endpoint?: string;
}
export declare const CreateClusterOutput: S.Schema<CreateClusterOutput>;
export type KinesisStreamArn = string;
export type RoleArn = string;
export interface KinesisTargetDefinition {
    streamArn: string;
    roleArn: string;
}
export declare const KinesisTargetDefinition: S.Schema<KinesisTargetDefinition>;
export type TargetDefinition = {
    kinesis: KinesisTargetDefinition;
};
export declare const TargetDefinition: any;
export type StreamOrdering = "UNORDERED" | (string & {});
export declare const StreamOrdering: any;
export type StreamFormat = "JSON" | (string & {});
export declare const StreamFormat: any;
export interface CreateStreamInput {
    clusterIdentifier: string;
    targetDefinition: TargetDefinition;
    ordering: StreamOrdering;
    format: StreamFormat;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const CreateStreamInput: S.Schema<CreateStreamInput>;
export type StreamId = string;
export type StreamArn = string;
export type StreamStatus = "CREATING" | "ACTIVE" | "DELETING" | "DELETED" | "FAILED" | "IMPAIRED" | (string & {});
export declare const StreamStatus: any;
export type StreamCreationTime = Date;
export interface CreateStreamOutput {
    clusterIdentifier: string;
    streamIdentifier: string;
    arn: string;
    status: StreamStatus;
    creationTime: Date;
    ordering: StreamOrdering;
    format: StreamFormat;
}
export declare const CreateStreamOutput: S.Schema<CreateStreamOutput>;
export interface DeleteClusterInput {
    identifier: string;
    clientToken?: string;
}
export declare const DeleteClusterInput: S.Schema<DeleteClusterInput>;
export interface DeleteClusterOutput {
    identifier: string;
    arn: string;
    status: ClusterStatus;
    creationTime: Date;
}
export declare const DeleteClusterOutput: S.Schema<DeleteClusterOutput>;
export type PolicyVersion = string;
export interface DeleteClusterPolicyInput {
    identifier: string;
    expectedPolicyVersion?: string;
    clientToken?: string;
}
export declare const DeleteClusterPolicyInput: S.Schema<DeleteClusterPolicyInput>;
export interface DeleteClusterPolicyOutput {
    policyVersion: string;
}
export declare const DeleteClusterPolicyOutput: S.Schema<DeleteClusterPolicyOutput>;
export interface DeleteStreamInput {
    clusterIdentifier: string;
    streamIdentifier: string;
    clientToken?: string;
}
export declare const DeleteStreamInput: S.Schema<DeleteStreamInput>;
export interface DeleteStreamOutput {
    clusterIdentifier: string;
    streamIdentifier: string;
    arn: string;
    status: StreamStatus;
    creationTime: Date;
}
export declare const DeleteStreamOutput: S.Schema<DeleteStreamOutput>;
export interface GetClusterInput {
    identifier: string;
}
export declare const GetClusterInput: S.Schema<GetClusterInput>;
export interface GetClusterOutput {
    identifier: string;
    arn: string;
    status: ClusterStatus;
    creationTime: Date;
    deletionProtectionEnabled: boolean;
    multiRegionProperties?: MultiRegionProperties;
    tags?: {
        [key: string]: string | undefined;
    };
    encryptionDetails?: EncryptionDetails;
    endpoint?: string;
}
export declare const GetClusterOutput: S.Schema<GetClusterOutput>;
export interface GetClusterPolicyInput {
    identifier: string;
}
export declare const GetClusterPolicyInput: S.Schema<GetClusterPolicyInput>;
export interface GetClusterPolicyOutput {
    policy: string;
    policyVersion: string;
}
export declare const GetClusterPolicyOutput: S.Schema<GetClusterPolicyOutput>;
export interface GetStreamInput {
    clusterIdentifier: string;
    streamIdentifier: string;
}
export declare const GetStreamInput: S.Schema<GetStreamInput>;
export type StreamFailureErrorCode = "KINESIS_THROUGHPUT_EXCEEDED" | "KINESIS_STREAM_NOT_FOUND" | "ROLE_ACCESS_DENIED" | "KINESIS_ACCESS_DENIED" | "KINESIS_KMS_ACCESS_DENIED" | "KINESIS_OVERSIZE_RECORD" | "CLUSTER_CMK_INACCESSIBLE" | "INTERNAL_ERROR" | (string & {});
export declare const StreamFailureErrorCode: any;
export interface StatusReason {
    error: StreamFailureErrorCode;
    updatedAt: Date;
}
export declare const StatusReason: S.Schema<StatusReason>;
export interface GetStreamOutput {
    clusterIdentifier: string;
    streamIdentifier: string;
    arn: string;
    status: StreamStatus;
    creationTime: Date;
    ordering: StreamOrdering;
    format: StreamFormat;
    targetDefinition?: TargetDefinition;
    statusReason?: StatusReason;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetStreamOutput: S.Schema<GetStreamOutput>;
export interface GetVpcEndpointServiceNameInput {
    identifier: string;
}
export declare const GetVpcEndpointServiceNameInput: S.Schema<GetVpcEndpointServiceNameInput>;
export type ServiceName = string;
export type ClusterVpcEndpoint = string;
export interface GetVpcEndpointServiceNameOutput {
    serviceName: string;
    clusterVpcEndpoint?: string;
}
export declare const GetVpcEndpointServiceNameOutput: S.Schema<GetVpcEndpointServiceNameOutput>;
export type MaxResults = number;
export type NextToken = string;
export interface ListClustersInput {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListClustersInput: S.Schema<ListClustersInput>;
export interface ClusterSummary {
    identifier: string;
    arn: string;
}
export declare const ClusterSummary: S.Schema<ClusterSummary>;
export type ClusterList = ClusterSummary[];
export declare const ClusterList: any;
export interface ListClustersOutput {
    nextToken?: string;
    clusters: ClusterSummary[];
}
export declare const ListClustersOutput: S.Schema<ListClustersOutput>;
export interface ListStreamsInput {
    clusterIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListStreamsInput: S.Schema<ListStreamsInput>;
export interface StreamSummary {
    clusterIdentifier: string;
    streamIdentifier: string;
    arn: string;
    creationTime: Date;
    status: StreamStatus;
}
export declare const StreamSummary: S.Schema<StreamSummary>;
export type StreamList = StreamSummary[];
export declare const StreamList: any;
export interface ListStreamsOutput {
    nextToken?: string;
    streams: StreamSummary[];
}
export declare const ListStreamsOutput: S.Schema<ListStreamsOutput>;
export type Arn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export declare const ListTagsForResourceInput: S.Schema<ListTagsForResourceInput>;
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceOutput: S.Schema<ListTagsForResourceOutput>;
export interface PutClusterPolicyInput {
    identifier: string;
    policy: string;
    bypassPolicyLockoutSafetyCheck?: boolean;
    expectedPolicyVersion?: string;
    clientToken?: string;
}
export declare const PutClusterPolicyInput: S.Schema<PutClusterPolicyInput>;
export interface PutClusterPolicyOutput {
    policyVersion: string;
}
export declare const PutClusterPolicyOutput: S.Schema<PutClusterPolicyOutput>;
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceInput: S.Schema<TagResourceInput>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceInput: S.Schema<UntagResourceInput>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateClusterInput {
    identifier: string;
    deletionProtectionEnabled?: boolean;
    kmsEncryptionKey?: string;
    clientToken?: string;
    multiRegionProperties?: MultiRegionProperties;
}
export declare const UpdateClusterInput: S.Schema<UpdateClusterInput>;
export interface UpdateClusterOutput {
    identifier: string;
    arn: string;
    status: ClusterStatus;
    creationTime: Date;
}
export declare const UpdateClusterOutput: S.Schema<UpdateClusterOutput>;
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "deletionProtectionEnabled" | "other" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type CreateClusterError = ConflictException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * The CreateCluster API allows you to create both single-Region clusters and multi-Region clusters. With the addition of the *multiRegionProperties* parameter, you can create a cluster with witness Region support and establish peer relationships with clusters in other Regions during creation.
 *
 * Creating multi-Region clusters requires additional IAM permissions beyond those needed for single-Region clusters, as detailed in the **Required permissions** section below.
 *
 * **Required permissions**
 *
 * ### dsql:CreateCluster
 *
 * Required to create a cluster.
 *
 * Resources: `arn:aws:dsql:region:account-id:cluster/*`
 *
 * ### dsql:TagResource
 *
 * Permission to add tags to a resource.
 *
 * Resources: `arn:aws:dsql:region:account-id:cluster/*`
 *
 * ### dsql:PutMultiRegionProperties
 *
 * Permission to configure multi-Region properties for a cluster.
 *
 * Resources: `arn:aws:dsql:region:account-id:cluster/*`
 *
 * ### dsql:AddPeerCluster
 *
 * When specifying `multiRegionProperties.clusters`, permission to add peer clusters.
 *
 * Resources:
 *
 * - Local cluster: `arn:aws:dsql:region:account-id:cluster/*`
 *
 * - Each peer cluster: exact ARN of each specified peer cluster
 *
 * ### dsql:PutWitnessRegion
 *
 * When specifying `multiRegionProperties.witnessRegion`, permission to set a witness Region. This permission is checked both in the cluster Region and in the witness Region.
 *
 * Resources: `arn:aws:dsql:region:account-id:cluster/*`
 *
 * Condition Keys: `dsql:WitnessRegion` (matching the specified witness region)
 *
 * - The witness Region specified in `multiRegionProperties.witnessRegion` cannot be the same as the cluster's Region.
 */
export declare const createCluster: API.OperationMethod<CreateClusterInput, CreateClusterOutput, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateStreamError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a new change data capture (CDC) stream for a cluster. The stream captures database changes and delivers them to the specified target destination.
 *
 * **Required permissions**
 *
 * ### dsql:CreateStream
 *
 * Permission to create a new stream.
 *
 * Resources: `arn:aws:dsql:region:account-id:cluster/cluster-id`
 *
 * ### iam:PassRole
 *
 * Permission to pass the IAM role specified in the target definition to the service.
 *
 * Resources: ARN of the IAM role specified in `targetDefinition.kinesis.roleArn`
 *
 * ### kms:Decrypt
 *
 * Required when the cluster uses a customer managed KMS key (CMK). Permission to decrypt data using the cluster's CMK.
 *
 * Resources: ARN of the KMS key used by the cluster
 */
export declare const createStream: API.OperationMethod<CreateStreamInput, CreateStreamOutput, CreateStreamError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a cluster in Amazon Aurora DSQL.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterInput, DeleteClusterOutput, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterPolicyError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the resource-based policy attached to a cluster. This removes all access permissions defined by the policy, reverting to default access controls.
 */
export declare const deleteClusterPolicy: API.OperationMethod<DeleteClusterPolicyInput, DeleteClusterPolicyOutput, DeleteClusterPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteStreamError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a stream from a cluster.
 */
export declare const deleteStream: API.OperationMethod<DeleteStreamInput, DeleteStreamOutput, DeleteStreamError, Credentials | HttpClient.HttpClient>;
export type GetClusterError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a cluster.
 */
export declare const getCluster: API.OperationMethod<GetClusterInput, GetClusterOutput, GetClusterError, Credentials | HttpClient.HttpClient>;
export type GetClusterPolicyError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the resource-based policy document attached to a cluster. This policy defines the access permissions and conditions for the cluster.
 */
export declare const getClusterPolicy: API.OperationMethod<GetClusterPolicyInput, GetClusterPolicyOutput, GetClusterPolicyError, Credentials | HttpClient.HttpClient>;
export type GetStreamError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a stream.
 */
export declare const getStream: API.OperationMethod<GetStreamInput, GetStreamOutput, GetStreamError, Credentials | HttpClient.HttpClient>;
export type GetVpcEndpointServiceNameError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the VPC endpoint service name.
 */
export declare const getVpcEndpointServiceName: API.OperationMethod<GetVpcEndpointServiceNameInput, GetVpcEndpointServiceNameOutput, GetVpcEndpointServiceNameError, Credentials | HttpClient.HttpClient>;
export type ListClustersError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a list of clusters.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersInput, ListClustersOutput, ListClustersError, Credentials | HttpClient.HttpClient, ClusterSummary>;
export type ListStreamsError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a list of streams for a cluster.
 */
export declare const listStreams: API.PaginatedOperationMethod<ListStreamsInput, ListStreamsOutput, ListStreamsError, Credentials | HttpClient.HttpClient, StreamSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Lists all of the tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutClusterPolicyError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Attaches a resource-based policy to a cluster. This policy defines access permissions and conditions for the cluster, allowing you to control which principals can perform actions on the cluster.
 */
export declare const putClusterPolicy: API.OperationMethod<PutClusterPolicyInput, PutClusterPolicyOutput, PutClusterPolicyError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Tags a resource with a map of key and value pairs.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * The *UpdateCluster* API allows you to modify both single-Region and multi-Region cluster configurations. With the *multiRegionProperties* parameter, you can add or modify witness Region support and manage peer relationships with clusters in other Regions.
 *
 * Note that updating multi-Region clusters requires additional IAM permissions beyond those needed for standard cluster updates, as detailed in the Permissions section.
 *
 * **Required permissions**
 *
 * ### dsql:UpdateCluster
 *
 * Permission to update a DSQL cluster.
 *
 * Resources: `arn:aws:dsql:*region*:*account-id*:cluster/*cluster-id* `
 *
 * ### dsql:PutMultiRegionProperties
 *
 * Permission to configure multi-Region properties for a cluster.
 *
 * Resources: `arn:aws:dsql:*region*:*account-id*:cluster/*cluster-id* `
 *
 * ### dsql:GetCluster
 *
 * Permission to retrieve cluster information.
 *
 * Resources: `arn:aws:dsql:*region*:*account-id*:cluster/*cluster-id* `
 *
 * ### dsql:AddPeerCluster
 *
 * Permission to add peer clusters.
 *
 * Resources:
 *
 * - Local cluster: `arn:aws:dsql:*region*:*account-id*:cluster/*cluster-id* `
 *
 * - Each peer cluster: exact ARN of each specified peer cluster
 *
 * ### dsql:RemovePeerCluster
 *
 * Permission to remove peer clusters. When you list peer clusters in `multiRegionProperties.clusters`, you need this permission for each current peer cluster that your list omits.
 *
 * Resources:
 *
 * - Each removed peer cluster: exact ARN of each removed peer cluster, in its own Region
 *
 * ### dsql:PutWitnessRegion
 *
 * Permission to set a witness Region.
 *
 * Resources: `arn:aws:dsql:*region*:*account-id*:cluster/*cluster-id* `
 *
 * Condition Keys: dsql:WitnessRegion (matching the specified witness Region)
 *
 * **This permission is checked both in the cluster Region and in the witness Region.**
 *
 * - The witness Region specified in `multiRegionProperties.witnessRegion` cannot be the same as the cluster's Region.
 *
 * - When you list peer clusters in `multiRegionProperties.clusters`, you need `dsql:AddPeerCluster` for every peer cluster in your request. You need `dsql:RemovePeerCluster` only for the peer clusters that the update removes.
 */
export declare const updateCluster: API.OperationMethod<UpdateClusterInput, UpdateClusterOutput, UpdateClusterError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=dsql.d.ts.map