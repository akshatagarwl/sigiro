import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as stream from "effect/Stream";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DomainId = string;
export type SubscriptionId = string;
export interface ActivateSubscriptionInput {
    domainId: string;
    subscriptionId: string;
}
export declare const ActivateSubscriptionInput: S.Schema<ActivateSubscriptionInput>;
export type SubscriptionArn = string;
export type SubscriptionStatus = "ACTIVE" | "INACTIVE" | "DELETED" | (string & {});
export declare const SubscriptionStatus: any;
export interface SubscriptionDescription {
    domainId: string;
    subscriptionId: string;
    arn: string;
    status: SubscriptionStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
    activatedAt?: Date;
    deactivatedAt?: Date;
}
export declare const SubscriptionDescription: S.Schema<SubscriptionDescription>;
export interface ActivateSubscriptionOutput {
    subscription?: SubscriptionDescription;
}
export declare const ActivateSubscriptionOutput: S.Schema<ActivateSubscriptionOutput>;
export type DomainName = string;
export type KmsKeyArn = string;
export interface CreateWebAppConfiguration {
    ehrRole: string;
    idcInstanceId: string;
    idcRegion: string;
}
export declare const CreateWebAppConfiguration: S.Schema<CreateWebAppConfiguration>;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateDomainInput {
    name: string;
    kmsKeyArn?: string;
    webAppSetupConfiguration?: CreateWebAppConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDomainInput: S.Schema<CreateDomainInput>;
export type DomainArn = string;
export type EncryptionType = "AWS_OWNED_KEY" | "CUSTOMER_MANAGED_KEY" | (string & {});
export declare const EncryptionType: any;
export interface EncryptionContext {
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
}
export declare const EncryptionContext: S.Schema<EncryptionContext>;
export type DomainStatus = "ACTIVE" | "DELETING" | "DELETED" | (string & {});
export declare const DomainStatus: any;
export type WebAppUrl = string;
export interface WebAppConfiguration {
    ehrRole: string;
    idcApplicationId: string;
    idcRegion: string;
}
export declare const WebAppConfiguration: S.Schema<WebAppConfiguration>;
export interface CreateDomainOutput {
    domainId: string;
    arn: string;
    name: string;
    kmsKeyArn?: string;
    encryptionContext?: EncryptionContext;
    status: DomainStatus;
    webAppUrl?: string;
    webAppConfiguration?: WebAppConfiguration;
    createdAt: Date;
}
export declare const CreateDomainOutput: S.Schema<CreateDomainOutput>;
export interface CreateSubscriptionInput {
    domainId: string;
}
export declare const CreateSubscriptionInput: S.Schema<CreateSubscriptionInput>;
export interface CreateSubscriptionOutput {
    domainId: string;
    subscriptionId: string;
    arn: string;
    status: SubscriptionStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
    activatedAt?: Date;
    deactivatedAt?: Date;
}
export declare const CreateSubscriptionOutput: S.Schema<CreateSubscriptionOutput>;
export interface DeactivateSubscriptionInput {
    domainId: string;
    subscriptionId: string;
}
export declare const DeactivateSubscriptionInput: S.Schema<DeactivateSubscriptionInput>;
export interface DeactivateSubscriptionOutput {
    subscription?: SubscriptionDescription;
}
export declare const DeactivateSubscriptionOutput: S.Schema<DeactivateSubscriptionOutput>;
export interface DeleteDomainInput {
    domainId: string;
}
export declare const DeleteDomainInput: S.Schema<DeleteDomainInput>;
export interface DeleteDomainOutput {
    domainId: string;
    arn: string;
    status: DomainStatus;
}
export declare const DeleteDomainOutput: S.Schema<DeleteDomainOutput>;
export interface GetDomainInput {
    domainId: string;
}
export declare const GetDomainInput: S.Schema<GetDomainInput>;
export interface GetDomainOutput {
    domainId: string;
    arn: string;
    name: string;
    kmsKeyArn?: string;
    encryptionContext?: EncryptionContext;
    status: DomainStatus;
    webAppUrl?: string;
    webAppConfiguration?: WebAppConfiguration;
    createdAt: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetDomainOutput: S.Schema<GetDomainOutput>;
export type ScribeSessionId = string;
export interface GetMedicalScribeListeningSessionInput {
    sessionId: string;
    domainId: string;
    subscriptionId: string;
}
export declare const GetMedicalScribeListeningSessionInput: S.Schema<GetMedicalScribeListeningSessionInput>;
export type MedicalScribeLanguageCode = "en-US" | (string & {});
export declare const MedicalScribeLanguageCode: any;
export type MedicalScribeMediaSampleRateHertz = number;
export type MedicalScribeMediaEncoding = "pcm" | "flac" | (string & {});
export declare const MedicalScribeMediaEncoding: any;
export type MedicalScribeChannelId = number;
export type MedicalScribeParticipantRole = "PATIENT" | "CLINICIAN" | (string & {});
export declare const MedicalScribeParticipantRole: any;
export interface MedicalScribeChannelDefinition {
    channelId: number;
    participantRole: MedicalScribeParticipantRole;
}
export declare const MedicalScribeChannelDefinition: S.Schema<MedicalScribeChannelDefinition>;
export type MedicalScribeChannelDefinitions = MedicalScribeChannelDefinition[];
export declare const MedicalScribeChannelDefinitions: any;
export type S3Uri = string;
export type ManagedNoteTemplate = "HISTORY_AND_PHYSICAL" | "GIRPP" | "DAP" | "SIRP" | "BIRP" | "BEHAVIORAL_SOAP" | "PHYSICAL_SOAP" | (string & {});
export declare const ManagedNoteTemplate: any;
export interface ManagedTemplateResponse {
    templateType?: ManagedNoteTemplate;
}
export declare const ManagedTemplateResponse: S.Schema<ManagedTemplateResponse>;
export type CustomTemplateBase = "HISTORY_AND_PHYSICAL" | "GIRPP" | "DAP" | "SIRP" | "BIRP" | "BEHAVIORAL_SOAP" | (string & {});
export declare const CustomTemplateBase: any;
export interface CustomTemplateResponse {
    templateType?: CustomTemplateBase;
}
export declare const CustomTemplateResponse: S.Schema<CustomTemplateResponse>;
export type NoteTemplateSettingsResponse = {
    managedTemplate: ManagedTemplateResponse;
    customTemplate?: never;
} | {
    managedTemplate?: never;
    customTemplate: CustomTemplateResponse;
};
export declare const NoteTemplateSettingsResponse: any;
export interface ClinicalNoteGenerationSettingsResponse {
    noteTemplateSettings?: NoteTemplateSettingsResponse;
}
export declare const ClinicalNoteGenerationSettingsResponse: S.Schema<ClinicalNoteGenerationSettingsResponse>;
export interface MedicalScribePostStreamActionSettingsResponse {
    outputS3Uri: string;
    clinicalNoteGenerationSettings: ClinicalNoteGenerationSettingsResponse;
}
export declare const MedicalScribePostStreamActionSettingsResponse: S.Schema<MedicalScribePostStreamActionSettingsResponse>;
export type Uri = string;
export type PostStreamArtifactGenerationStatus = "IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export declare const PostStreamArtifactGenerationStatus: any;
export type ErrorMessage = string;
export interface ArtifactDetails {
    outputLocation?: string;
    status?: PostStreamArtifactGenerationStatus;
    failureReason?: string;
}
export declare const ArtifactDetails: S.Schema<ArtifactDetails>;
export interface ClinicalNoteGenerationResult {
    noteResult?: ArtifactDetails;
    transcriptResult?: ArtifactDetails;
    afterVisitSummaryResult?: ArtifactDetails;
}
export declare const ClinicalNoteGenerationResult: S.Schema<ClinicalNoteGenerationResult>;
export interface MedicalScribePostStreamActionsResult {
    clinicalNoteGenerationResult?: ClinicalNoteGenerationResult;
}
export declare const MedicalScribePostStreamActionsResult: S.Schema<MedicalScribePostStreamActionsResult>;
export type NonNullBoolean = boolean;
export type MedicalScribeStreamStatus = "IN_PROGRESS" | "PAUSED" | "FAILED" | "COMPLETED" | (string & {});
export declare const MedicalScribeStreamStatus: any;
export interface MedicalScribeListeningSessionDetails {
    sessionId?: string;
    domainId?: string;
    subscriptionId?: string;
    languageCode?: MedicalScribeLanguageCode;
    mediaSampleRateHertz?: number;
    mediaEncoding?: MedicalScribeMediaEncoding;
    channelDefinitions?: MedicalScribeChannelDefinition[];
    postStreamActionSettings?: MedicalScribePostStreamActionSettingsResponse;
    postStreamActionResult?: MedicalScribePostStreamActionsResult;
    encounterContextProvided?: boolean;
    streamStatus?: MedicalScribeStreamStatus;
    streamCreationTime?: Date;
    streamEndTime?: Date;
}
export declare const MedicalScribeListeningSessionDetails: S.Schema<MedicalScribeListeningSessionDetails>;
export interface GetMedicalScribeListeningSessionOutput {
    medicalScribeListeningSessionDetails?: MedicalScribeListeningSessionDetails;
}
export declare const GetMedicalScribeListeningSessionOutput: S.Schema<GetMedicalScribeListeningSessionOutput>;
export type JobId = string;
export interface GetPatientInsightsJobRequest {
    domainId: string;
    jobId: string;
}
export declare const GetPatientInsightsJobRequest: S.Schema<GetPatientInsightsJobRequest>;
export type JobArn = string;
export type JobStatus = "SUBMITTED" | "IN_PROGRESS" | "FAILED" | "SUCCEEDED" | (string & {});
export declare const JobStatus: any;
export interface InsightsOutput {
    uri: string;
}
export declare const InsightsOutput: S.Schema<InsightsOutput>;
export type NonEmptyString = string;
export type SensitiveNonEmptyString = string | redacted.Redacted<string>;
export type SensitiveIsoDateString = string | redacted.Redacted<string>;
export type Pronouns = "HE_HIM" | "SHE_HER" | "THEY_THEM" | (string & {});
export declare const Pronouns: any;
export interface PatientInsightsPatientContext {
    patientId: string | redacted.Redacted<string>;
    dateOfBirth?: string | redacted.Redacted<string>;
    pronouns?: Pronouns;
}
export declare const PatientInsightsPatientContext: S.Schema<PatientInsightsPatientContext>;
export type InsightsType = "PRE_VISIT" | (string & {});
export declare const InsightsType: any;
export interface InsightsContext {
    insightsType: InsightsType;
}
export declare const InsightsContext: S.Schema<InsightsContext>;
export interface PatientInsightsEncounterContext {
    encounterReason: string | redacted.Redacted<string>;
}
export declare const PatientInsightsEncounterContext: S.Schema<PatientInsightsEncounterContext>;
export type ProviderRole = "CLINICIAN" | (string & {});
export declare const ProviderRole: any;
export type Specialty = "PRIMARY_CARE" | (string & {});
export declare const Specialty: any;
export interface UserContext {
    role: ProviderRole;
    userId: string | redacted.Redacted<string>;
    specialty?: Specialty;
}
export declare const UserContext: S.Schema<UserContext>;
export interface FHIRServer {
    fhirEndpoint: string;
    oauthToken?: string | redacted.Redacted<string>;
}
export declare const FHIRServer: S.Schema<FHIRServer>;
export interface S3Source {
    uri: string;
}
export declare const S3Source: S.Schema<S3Source>;
export type S3Sources = S3Source[];
export declare const S3Sources: any;
export interface InputDataConfig {
    fhirServer?: FHIRServer;
    s3Sources?: S3Source[];
}
export declare const InputDataConfig: S.Schema<InputDataConfig>;
export interface OutputDataConfig {
    s3OutputPath: string;
}
export declare const OutputDataConfig: S.Schema<OutputDataConfig>;
export interface GetPatientInsightsJobResponse {
    jobId: string;
    jobArn: string;
    jobStatus: JobStatus;
    creationTime?: Date;
    updatedTime?: Date;
    insightsOutput?: InsightsOutput;
    statusDetails?: string;
    patientContext: PatientInsightsPatientContext;
    insightsContext: InsightsContext;
    encounterContext: PatientInsightsEncounterContext;
    userContext: UserContext;
    inputDataConfig: InputDataConfig;
    outputDataConfig: OutputDataConfig;
}
export declare const GetPatientInsightsJobResponse: S.Schema<GetPatientInsightsJobResponse>;
export interface GetSubscriptionInput {
    domainId: string;
    subscriptionId: string;
}
export declare const GetSubscriptionInput: S.Schema<GetSubscriptionInput>;
export interface GetSubscriptionOutput {
    subscription?: SubscriptionDescription;
}
export declare const GetSubscriptionOutput: S.Schema<GetSubscriptionOutput>;
export interface ListDomainsInput {
    status?: DomainStatus;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDomainsInput: S.Schema<ListDomainsInput>;
export interface DomainSummary {
    domainId: string;
    arn: string;
    name: string;
    status: DomainStatus;
    createdAt: Date;
}
export declare const DomainSummary: S.Schema<DomainSummary>;
export type DomainSummaryList = DomainSummary[];
export declare const DomainSummaryList: any;
export interface ListDomainsOutput {
    domains: DomainSummary[];
    nextToken?: string;
}
export declare const ListDomainsOutput: S.Schema<ListDomainsOutput>;
export interface ListSubscriptionsInput {
    domainId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSubscriptionsInput: S.Schema<ListSubscriptionsInput>;
export type SubscriptionList = SubscriptionDescription[];
export declare const SubscriptionList: any;
export interface ListSubscriptionsOutput {
    subscriptions: SubscriptionDescription[];
    nextToken?: string;
}
export declare const ListSubscriptionsOutput: S.Schema<ListSubscriptionsOutput>;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export declare const ListTagsForResourceInput: S.Schema<ListTagsForResourceInput>;
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceOutput: S.Schema<ListTagsForResourceOutput>;
export type AudioChunk = Uint8Array;
export interface MedicalScribeAudioEvent {
    audioChunk: Uint8Array;
}
export declare const MedicalScribeAudioEvent: S.Schema<MedicalScribeAudioEvent>;
export interface MedicalScribeBinaryAudioEvent {
    audioChunk: Uint8Array;
}
export declare const MedicalScribeBinaryAudioEvent: S.Schema<MedicalScribeBinaryAudioEvent>;
export type MedicalScribeSessionControlEventType = "END_OF_SESSION" | (string & {});
export declare const MedicalScribeSessionControlEventType: any;
export interface MedicalScribeSessionControlEvent {
    type?: MedicalScribeSessionControlEventType;
}
export declare const MedicalScribeSessionControlEvent: S.Schema<MedicalScribeSessionControlEvent>;
export interface ManagedTemplate {
    templateType: ManagedNoteTemplate;
}
export declare const ManagedTemplate: S.Schema<ManagedTemplate>;
export type SensitiveAlphanumericString = string | redacted.Redacted<string>;
export type SensitiveMarkdownString = string | redacted.Redacted<string>;
export interface TemplateSectionInstruction {
    sectionHeader: string | redacted.Redacted<string>;
    sectionInstruction: string | redacted.Redacted<string>;
}
export declare const TemplateSectionInstruction: S.Schema<TemplateSectionInstruction>;
export type TemplateInstructions = TemplateSectionInstruction[];
export declare const TemplateInstructions: any;
export interface CustomTemplate {
    templateType: CustomTemplateBase;
    templateInstructions: TemplateSectionInstruction[];
}
export declare const CustomTemplate: S.Schema<CustomTemplate>;
export type NoteTemplateSettings = {
    managedTemplate: ManagedTemplate;
    customTemplate?: never;
} | {
    managedTemplate?: never;
    customTemplate: CustomTemplate;
};
export declare const NoteTemplateSettings: any;
export interface ClinicalNoteGenerationSettings {
    noteTemplateSettings: NoteTemplateSettings;
}
export declare const ClinicalNoteGenerationSettings: S.Schema<ClinicalNoteGenerationSettings>;
export interface MedicalScribePostStreamActionSettings {
    outputS3Uri: string;
    clinicalNoteGenerationSettings: ClinicalNoteGenerationSettings;
}
export declare const MedicalScribePostStreamActionSettings: S.Schema<MedicalScribePostStreamActionSettings>;
export interface EncounterContext {
    unstructuredContext?: string | redacted.Redacted<string>;
}
export declare const EncounterContext: S.Schema<EncounterContext>;
export interface MedicalScribeConfigurationEvent {
    postStreamActionSettings: MedicalScribePostStreamActionSettings;
    channelDefinitions?: MedicalScribeChannelDefinition[];
    encounterContext?: EncounterContext;
}
export declare const MedicalScribeConfigurationEvent: S.Schema<MedicalScribeConfigurationEvent>;
export type MedicalScribeInputStream = {
    audioEvent: MedicalScribeAudioEvent;
    binaryAudioEvent?: never;
    sessionControlEvent?: never;
    configurationEvent?: never;
} | {
    audioEvent?: never;
    binaryAudioEvent: MedicalScribeBinaryAudioEvent;
    sessionControlEvent?: never;
    configurationEvent?: never;
} | {
    audioEvent?: never;
    binaryAudioEvent?: never;
    sessionControlEvent: MedicalScribeSessionControlEvent;
    configurationEvent?: never;
} | {
    audioEvent?: never;
    binaryAudioEvent?: never;
    sessionControlEvent?: never;
    configurationEvent: MedicalScribeConfigurationEvent;
};
export declare const MedicalScribeInputStream: S.Schema<stream.Stream<MedicalScribeInputStream, Error, never>>;
export interface StartMedicalScribeListeningSessionInput {
    sessionId: string;
    domainId: string;
    subscriptionId: string;
    languageCode: MedicalScribeLanguageCode;
    mediaSampleRateHertz: number;
    mediaEncoding: MedicalScribeMediaEncoding;
    inputStream?: stream.Stream<MedicalScribeInputStream, Error, never>;
}
export declare const StartMedicalScribeListeningSessionInput: S.Schema<StartMedicalScribeListeningSessionInput>;
export type RequestId = string;
export type AudioOffset = number;
export interface MedicalScribeTranscriptSegment {
    segmentId?: string;
    audioBeginOffset?: number;
    audioEndOffset?: number;
    isPartial?: boolean;
    channelId?: string;
    content?: string;
}
export declare const MedicalScribeTranscriptSegment: S.Schema<MedicalScribeTranscriptSegment>;
export interface MedicalScribeTranscriptEvent {
    transcriptSegment?: MedicalScribeTranscriptSegment;
}
export declare const MedicalScribeTranscriptEvent: S.Schema<MedicalScribeTranscriptEvent>;
export type MedicalScribeOutputStream = {
    transcriptEvent: MedicalScribeTranscriptEvent;
    internalFailureException?: never;
    validationException?: never;
} | {
    transcriptEvent?: never;
    internalFailureException: InternalServerException;
    validationException?: never;
} | {
    transcriptEvent?: never;
    internalFailureException?: never;
    validationException: ValidationException;
};
export declare const MedicalScribeOutputStream: S.Schema<stream.Stream<MedicalScribeOutputStream, Error, never>>;
export interface StartMedicalScribeListeningSessionOutput {
    sessionId?: string;
    domainId?: string;
    subscriptionId?: string;
    requestId?: string;
    languageCode?: MedicalScribeLanguageCode;
    mediaSampleRateHertz?: number;
    mediaEncoding?: MedicalScribeMediaEncoding;
    responseStream?: stream.Stream<MedicalScribeOutputStream, Error, never>;
}
export declare const StartMedicalScribeListeningSessionOutput: S.Schema<StartMedicalScribeListeningSessionOutput>;
export interface StartPatientInsightsJobRequest {
    domainId: string;
    patientContext: PatientInsightsPatientContext;
    insightsContext: InsightsContext;
    encounterContext: PatientInsightsEncounterContext;
    userContext: UserContext;
    inputDataConfig: InputDataConfig;
    outputDataConfig: OutputDataConfig;
    clientToken?: string;
}
export declare const StartPatientInsightsJobRequest: S.Schema<StartPatientInsightsJobRequest>;
export interface StartPatientInsightsJobResponse {
    jobArn: string;
    jobId: string;
    creationTime?: Date;
}
export declare const StartPatientInsightsJobResponse: S.Schema<StartPatientInsightsJobResponse>;
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceInput: S.Schema<TagResourceInput>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceInput: S.Schema<UntagResourceInput>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type ActivateSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Activates a Subscription to enable billing for a user.
 */
export declare const activateSubscription: API.OperationMethod<ActivateSubscriptionInput, ActivateSubscriptionOutput, ActivateSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new Domain for managing HealthAgent resources.
 */
export declare const createDomain: API.OperationMethod<CreateDomainInput, CreateDomainOutput, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a new Subscription within a Domain for billing and user management.
 */
export declare const createSubscription: API.OperationMethod<CreateSubscriptionInput, CreateSubscriptionOutput, CreateSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeactivateSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deactivates a Subscription to stop billing for a user.
 */
export declare const deactivateSubscription: API.OperationMethod<DeactivateSubscriptionInput, DeactivateSubscriptionOutput, DeactivateSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = ResourceNotFoundException | CommonErrors;
/**
 * Deletes a Domain and all associated resources.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainInput, DeleteDomainOutput, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type GetDomainError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a Domain.
 */
export declare const getDomain: API.OperationMethod<GetDomainInput, GetDomainOutput, GetDomainError, Credentials | HttpClient.HttpClient>;
export type GetMedicalScribeListeningSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Retrieves details about an existing Medical Scribe listening session
 */
export declare const getMedicalScribeListeningSession: API.OperationMethod<GetMedicalScribeListeningSessionInput, GetMedicalScribeListeningSessionOutput, GetMedicalScribeListeningSessionError, Credentials | HttpClient.HttpClient>;
export type GetPatientInsightsJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get details of a started patient insights job.
 */
export declare const getPatientInsightsJob: API.OperationMethod<GetPatientInsightsJobRequest, GetPatientInsightsJobResponse, GetPatientInsightsJobError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information about a Subscription.
 */
export declare const getSubscription: API.OperationMethod<GetSubscriptionInput, GetSubscriptionOutput, GetSubscriptionError, Credentials | HttpClient.HttpClient>;
export type ListDomainsError = CommonErrors;
/**
 * Lists Domains for a given account.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsInput, ListDomainsOutput, ListDomainsError, Credentials | HttpClient.HttpClient, DomainSummary>;
export type ListSubscriptionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all Subscriptions within a Domain.
 */
export declare const listSubscriptions: API.PaginatedOperationMethod<ListSubscriptionsInput, ListSubscriptionsOutput, ListSubscriptionsError, Credentials | HttpClient.HttpClient, SubscriptionDescription>;
export type ListTagsForResourceError = CommonErrors;
/**
 * Lists the tags associated with the specified resource
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartMedicalScribeListeningSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a new Medical Scribe listening session for real-time audio transcription
 */
export declare const startMedicalScribeListeningSession: API.OperationMethod<StartMedicalScribeListeningSessionInput, StartMedicalScribeListeningSessionOutput, StartMedicalScribeListeningSessionError, Credentials | HttpClient.HttpClient>;
export type StartPatientInsightsJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a new patient insights job.
 */
export declare const startPatientInsightsJob: API.OperationMethod<StartPatientInsightsJobRequest, StartPatientInsightsJobResponse, StartPatientInsightsJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * Associates the specified tags with the specified resource
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * Removes the specified tags from the specified resource
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=connecthealth.d.ts.map