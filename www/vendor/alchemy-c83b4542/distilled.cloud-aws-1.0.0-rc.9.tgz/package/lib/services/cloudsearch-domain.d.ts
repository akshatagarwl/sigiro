import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const DocumentServiceException_base: S.Class<DocumentServiceException, S.TaggedStruct<"DocumentServiceException", {
    readonly status: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DocumentServiceException extends /*@__PURE__*/ DocumentServiceException_base {
}
declare const SearchException_base: S.Class<SearchException, S.TaggedStruct<"SearchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SearchException extends /*@__PURE__*/ SearchException_base {
}
export type Cursor = string;
export type Expr = string;
export type Facet = string;
export type FilterQuery = string;
export type Highlight = string;
export type Partial = boolean;
export type Query = string;
export type QueryOptions = string;
export type QueryParser = "simple" | "structured" | "lucene" | "dismax" | (string & {});
export declare const QueryParser: any;
export type Return = string;
export type Size = number;
export type Sort = string;
export type Start = number;
export type Stat = string;
export interface SearchRequest {
    cursor?: string;
    expr?: string;
    facet?: string;
    filterQuery?: string;
    highlight?: string;
    partial?: boolean;
    query: string;
    queryOptions?: string;
    queryParser?: QueryParser;
    return?: string;
    size?: number;
    sort?: string;
    start?: number;
    stats?: string;
}
export declare const SearchRequest: S.Schema<SearchRequest>;
export interface SearchStatus {
    timems?: number;
    rid?: string;
}
export declare const SearchStatus: S.Schema<SearchStatus>;
export type FieldValue = string[];
export declare const FieldValue: any;
export type Fields = {
    [key: string]: string[] | undefined;
};
export declare const Fields: any;
export type Exprs = {
    [key: string]: string | undefined;
};
export declare const Exprs: any;
export type Highlights = {
    [key: string]: string | undefined;
};
export declare const Highlights: any;
export interface Hit {
    id?: string;
    fields?: {
        [key: string]: string[] | undefined;
    };
    exprs?: {
        [key: string]: string | undefined;
    };
    highlights?: {
        [key: string]: string | undefined;
    };
}
export declare const Hit: S.Schema<Hit>;
export type HitList = Hit[];
export declare const HitList: any;
export interface Hits {
    found?: number;
    start?: number;
    cursor?: string;
    hit?: Hit[];
}
export declare const Hits: S.Schema<Hits>;
export interface Bucket {
    value?: string;
    count?: number;
}
export declare const Bucket: S.Schema<Bucket>;
export type BucketList = Bucket[];
export declare const BucketList: any;
export interface BucketInfo {
    buckets?: Bucket[];
}
export declare const BucketInfo: S.Schema<BucketInfo>;
export type Facets = {
    [key: string]: BucketInfo | undefined;
};
export declare const Facets: any;
export interface FieldStats {
    min?: string;
    max?: string;
    count?: number;
    missing?: number;
    sum?: number;
    sumOfSquares?: number;
    mean?: string;
    stddev?: number;
}
export declare const FieldStats: S.Schema<FieldStats>;
export type Stats = {
    [key: string]: FieldStats | undefined;
};
export declare const Stats: any;
export interface SearchResponse {
    status?: SearchStatus;
    hits?: Hits;
    facets?: {
        [key: string]: BucketInfo | undefined;
    };
    stats?: {
        [key: string]: FieldStats | undefined;
    };
}
export declare const SearchResponse: S.Schema<SearchResponse>;
export type Suggester = string;
export type SuggestionsSize = number;
export interface SuggestRequest {
    query: string;
    suggester: string;
    size?: number;
}
export declare const SuggestRequest: S.Schema<SuggestRequest>;
export interface SuggestStatus {
    timems?: number;
    rid?: string;
}
export declare const SuggestStatus: S.Schema<SuggestStatus>;
export interface SuggestionMatch {
    suggestion?: string;
    score?: number;
    id?: string;
}
export declare const SuggestionMatch: S.Schema<SuggestionMatch>;
export type Suggestions = SuggestionMatch[];
export declare const Suggestions: any;
export interface SuggestModel {
    query?: string;
    found?: number;
    suggestions?: SuggestionMatch[];
}
export declare const SuggestModel: S.Schema<SuggestModel>;
export interface SuggestResponse {
    status?: SuggestStatus;
    suggest?: SuggestModel;
}
export declare const SuggestResponse: S.Schema<SuggestResponse>;
export type ContentType = "application/json" | "application/xml" | (string & {});
export declare const ContentType: any;
export interface UploadDocumentsRequest {
    documents: T.StreamingInputBody;
    contentType: ContentType;
}
export declare const UploadDocumentsRequest: S.Schema<UploadDocumentsRequest>;
export type Adds = number;
export type Deletes = number;
export interface DocumentServiceWarning {
    message?: string;
}
export declare const DocumentServiceWarning: S.Schema<DocumentServiceWarning>;
export type DocumentServiceWarnings = DocumentServiceWarning[];
export declare const DocumentServiceWarnings: any;
export interface UploadDocumentsResponse {
    status?: string;
    adds?: number;
    deletes?: number;
    warnings?: DocumentServiceWarning[];
}
export declare const UploadDocumentsResponse: S.Schema<UploadDocumentsResponse>;
export type SearchError = SearchException | CommonErrors;
/**
 * Retrieves a list of documents that match the specified search criteria. How you specify the search criteria depends on which query parser you use. Amazon CloudSearch supports four query parsers:
 *
 * - `simple`: search all `text` and `text-array` fields for the specified string. Search for phrases, individual terms, and prefixes.
 *
 * - `structured`: search specific fields, construct compound queries using Boolean operators, and use advanced features such as term boosting and proximity searching.
 *
 * - `lucene`: specify search criteria using the Apache Lucene query parser syntax.
 *
 * - `dismax`: specify search criteria using the simplified subset of the Apache Lucene query parser syntax defined by the DisMax query parser.
 *
 * For more information, see Searching Your Data in the *Amazon CloudSearch Developer Guide*.
 *
 * The endpoint for submitting `Search` requests is domain-specific. You submit search requests to a domain's search endpoint. To get the search endpoint for your domain, use the Amazon CloudSearch configuration service `DescribeDomains` action. A domain's endpoints are also displayed on the domain dashboard in the Amazon CloudSearch console.
 */
export declare const search: API.OperationMethod<SearchRequest, SearchResponse, SearchError, Credentials | HttpClient.HttpClient>;
export type SuggestError = SearchException | CommonErrors;
/**
 * Retrieves autocomplete suggestions for a partial query string. You can use suggestions enable you to display likely matches before users finish typing. In Amazon CloudSearch, suggestions are based on the contents of a particular text field. When you request suggestions, Amazon CloudSearch finds all of the documents whose values in the suggester field start with the specified query string. The beginning of the field must match the query string to be considered a match.
 *
 * For more information about configuring suggesters and retrieving suggestions, see Getting Suggestions in the *Amazon CloudSearch Developer Guide*.
 *
 * The endpoint for submitting `Suggest` requests is domain-specific. You submit suggest requests to a domain's search endpoint. To get the search endpoint for your domain, use the Amazon CloudSearch configuration service `DescribeDomains` action. A domain's endpoints are also displayed on the domain dashboard in the Amazon CloudSearch console.
 */
export declare const suggest: API.OperationMethod<SuggestRequest, SuggestResponse, SuggestError, Credentials | HttpClient.HttpClient>;
export type UploadDocumentsError = DocumentServiceException | CommonErrors;
/**
 * Posts a batch of documents to a search domain for indexing. A document batch is a collection of add and delete operations that represent the documents you want to add, update, or delete from your domain. Batches can be described in either JSON or XML. Each item that you want Amazon CloudSearch to return as a search result (such as a product) is represented as a document. Every document has a unique ID and one or more fields that contain the data that you want to search and return in results. Individual documents cannot contain more than 1 MB of data. The entire batch cannot exceed 5 MB. To get the best possible upload performance, group add and delete operations in batches that are close the 5 MB limit. Submitting a large volume of single-document batches can overload a domain's document service.
 *
 * The endpoint for submitting `UploadDocuments` requests is domain-specific. To get the document endpoint for your domain, use the Amazon CloudSearch configuration service `DescribeDomains` action. A domain's endpoints are also displayed on the domain dashboard in the Amazon CloudSearch console.
 *
 * For more information about formatting your data for Amazon CloudSearch, see Preparing Your Data in the *Amazon CloudSearch Developer Guide*.
 * For more information about uploading data for indexing, see Uploading Data in the *Amazon CloudSearch Developer Guide*.
 */
export declare const uploadDocuments: API.OperationMethod<UploadDocumentsRequest, UploadDocumentsResponse, UploadDocumentsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudsearch-domain.d.ts.map