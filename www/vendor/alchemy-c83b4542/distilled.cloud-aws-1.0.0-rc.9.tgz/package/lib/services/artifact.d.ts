import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type InquiryName = string | redacted.Redacted<string>;
export type LongStringAttribute = string;
export type ShortStringAttribute = string;
export type FileSectionList = string[];
export declare const FileSectionList: any;
export interface InquiryFileContent {
    fileSections?: string[];
    content: Uint8Array;
}
export declare const InquiryFileContent: S.Schema<InquiryFileContent>;
export type InquiryContent = {
    query: string;
    fileContent?: never;
} | {
    query?: never;
    fileContent: InquiryFileContent;
};
export declare const InquiryContent: any;
export type IdempotentClientToken = string;
export type InquirySupportMode = "AI_ONLY" | "FULL_SUPPORT" | (string & {});
export declare const InquirySupportMode: any;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export interface CreateComplianceInquiryRequest {
    name: string | redacted.Redacted<string>;
    inquiryContent: InquiryContent;
    clientToken?: string;
    supportMode?: InquirySupportMode;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateComplianceInquiryRequest: S.Schema<CreateComplianceInquiryRequest>;
export type InquiryId = string;
export type InquiryStatus = "PROCESSING" | "HUMAN_REVIEW" | "COMPLETED" | "FAILED" | (string & {});
export declare const InquiryStatus: any;
export type InquiryStatusMessage = "Compliance inquiry processing is complete." | "Malware was detected on the file. Provide a new file and try again." | "Compliance inquiry processing is in-progress." | "An internal error occurred while processing the inquiry. Try again at a later time." | "Human review is in progress." | "Compliance inquiry processing is complete. One or more queries encountered errors during processing." | (string & {});
export declare const InquiryStatusMessage: any;
export type InputSource = "TEXT" | "FILE" | (string & {});
export declare const InputSource: any;
export type TimestampAttribute = Date;
export interface InquirySummary {
    arn: string;
    name: string;
    id: string;
    status: InquiryStatus;
    statusMessage: InquiryStatusMessage;
    inputSource: InputSource;
    createdAt: Date;
}
export declare const InquirySummary: S.Schema<InquirySummary>;
export interface CreateComplianceInquiryResponse {
    complianceInquirySummary?: InquirySummary;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateComplianceInquiryResponse: S.Schema<CreateComplianceInquiryResponse>;
export type QueryIdentifiersList = number[];
export declare const QueryIdentifiersList: any;
export interface ExportComplianceInquiryRequest {
    complianceInquiryId: string;
    queryIdentifiers?: number[];
    includeCitations?: boolean;
}
export declare const ExportComplianceInquiryRequest: S.Schema<ExportComplianceInquiryRequest>;
export type PresignedUrl = string | redacted.Redacted<string>;
export interface ExportComplianceInquiryResponse {
    documentPresignedUrl?: string | redacted.Redacted<string>;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ExportComplianceInquiryResponse: S.Schema<ExportComplianceInquiryResponse>;
export interface GetAccountSettingsRequest {
}
export declare const GetAccountSettingsRequest: S.Schema<GetAccountSettingsRequest>;
export type NotificationSubscriptionStatus = "SUBSCRIBED" | "NOT_SUBSCRIBED" | (string & {});
export declare const NotificationSubscriptionStatus: any;
export interface AccountSettings {
    notificationSubscriptionStatus?: NotificationSubscriptionStatus;
}
export declare const AccountSettings: S.Schema<AccountSettings>;
export interface GetAccountSettingsResponse {
    accountSettings?: AccountSettings;
}
export declare const GetAccountSettingsResponse: S.Schema<GetAccountSettingsResponse>;
export interface GetComplianceInquiryMetadataRequest {
    complianceInquiryId: string;
}
export declare const GetComplianceInquiryMetadataRequest: S.Schema<GetComplianceInquiryMetadataRequest>;
export interface InquiryDetail {
    arn: string;
    name: string;
    id: string;
    status: InquiryStatus;
    statusMessage: InquiryStatusMessage;
    inputSource: InputSource;
    createdAt: Date;
    updatedAt?: Date;
    supportMode?: InquirySupportMode;
}
export declare const InquiryDetail: S.Schema<InquiryDetail>;
export interface GetComplianceInquiryMetadataResponse {
    complianceInquiryDetail?: InquiryDetail;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetComplianceInquiryMetadataResponse: S.Schema<GetComplianceInquiryMetadataResponse>;
export type ReportId = string;
export type VersionAttribute = number;
export interface GetReportRequest {
    reportId: string;
    reportVersion?: number;
    termToken: string;
}
export declare const GetReportRequest: S.Schema<GetReportRequest>;
export interface GetReportResponse {
    documentPresignedUrl?: string;
}
export declare const GetReportResponse: S.Schema<GetReportResponse>;
export interface GetReportMetadataRequest {
    reportId: string;
    reportVersion?: number;
}
export declare const GetReportMetadataRequest: S.Schema<GetReportMetadataRequest>;
export type PublishedState = "PUBLISHED" | "UNPUBLISHED" | (string & {});
export declare const PublishedState: any;
export type AcceptanceType = "PASSTHROUGH" | "EXPLICIT" | (string & {});
export declare const AcceptanceType: any;
export type SequenceNumberAttribute = number;
export type UploadState = "PROCESSING" | "COMPLETE" | "FAILED" | "FAULT" | (string & {});
export declare const UploadState: any;
export type StatusMessage = string;
export interface ReportDetail {
    id?: string;
    name?: string;
    description?: string;
    periodStart?: Date;
    periodEnd?: Date;
    createdAt?: Date;
    lastModifiedAt?: Date;
    deletedAt?: Date;
    state?: PublishedState;
    arn?: string;
    series?: string;
    category?: string;
    companyName?: string;
    productName?: string;
    termArn?: string;
    version?: number;
    acceptanceType?: AcceptanceType;
    sequenceNumber?: number;
    uploadState?: UploadState;
    statusMessage?: string;
}
export declare const ReportDetail: S.Schema<ReportDetail>;
export interface GetReportMetadataResponse {
    reportDetails?: ReportDetail;
}
export declare const GetReportMetadataResponse: S.Schema<GetReportMetadataResponse>;
export interface GetTermForReportRequest {
    reportId: string;
    reportVersion?: number;
}
export declare const GetTermForReportRequest: S.Schema<GetTermForReportRequest>;
export interface GetTermForReportResponse {
    documentPresignedUrl?: string;
    termToken?: string;
}
export declare const GetTermForReportResponse: S.Schema<GetTermForReportResponse>;
export type MaxResultsAttribute = number;
export type NextTokenAttribute = string;
export interface ListComplianceInquiriesRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListComplianceInquiriesRequest: S.Schema<ListComplianceInquiriesRequest>;
export type InquiriesList = InquirySummary[];
export declare const InquiriesList: any;
export interface ListComplianceInquiriesResponse {
    complianceInquiries?: InquirySummary[];
    nextToken?: string;
}
export declare const ListComplianceInquiriesResponse: S.Schema<ListComplianceInquiriesResponse>;
export interface ListComplianceInquiryQueriesRequest {
    complianceInquiryId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListComplianceInquiryQueriesRequest: S.Schema<ListComplianceInquiryQueriesRequest>;
export type ReviewType = "HUMAN" | "AI" | (string & {});
export declare const ReviewType: any;
export interface Citation {
    sourceLabel?: string;
    sourceContent?: string;
    sourceLink?: string;
}
export declare const Citation: S.Schema<Citation>;
export type CitationList = Citation[];
export declare const CitationList: any;
export type QueryStatus = "PROCESSING" | "COMPLETED" | "FAILED" | (string & {});
export declare const QueryStatus: any;
export type QueryStatusMessage = "Query processing is complete." | "Query processing is in-progress." | "An internal error occurred while processing the query. Try again at a later time." | "Query is pending human review." | "Query contains restricted or unsupported content." | (string & {});
export declare const QueryStatusMessage: any;
export interface ResponseVersion {
    responseText: string;
    timestamp: Date;
}
export declare const ResponseVersion: S.Schema<ResponseVersion>;
export type ResponseVersionList = ResponseVersion[];
export declare const ResponseVersionList: any;
export interface QuerySummary {
    queryIdentifier: number;
    query: string;
    response?: string;
    reviewType?: ReviewType;
    citations?: Citation[];
    status: QueryStatus;
    statusMessage: QueryStatusMessage;
    createdAt: Date;
    updatedResponseVersions?: ResponseVersion[];
}
export declare const QuerySummary: S.Schema<QuerySummary>;
export type QueriesList = QuerySummary[];
export declare const QueriesList: any;
export interface ListComplianceInquiryQueriesResponse {
    queries?: QuerySummary[];
    nextToken?: string;
}
export declare const ListComplianceInquiryQueriesResponse: S.Schema<ListComplianceInquiryQueriesResponse>;
export interface ListCustomerAgreementsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListCustomerAgreementsRequest: S.Schema<ListCustomerAgreementsRequest>;
export type CustomerAgreementIdAttribute = string;
export type CustomerAgreementState = "ACTIVE" | "CUSTOMER_TERMINATED" | "AWS_TERMINATED" | (string & {});
export declare const CustomerAgreementState: any;
export type AgreementTerms = string[];
export declare const AgreementTerms: any;
export type AgreementType = "CUSTOM" | "DEFAULT" | "MODIFIED" | (string & {});
export declare const AgreementType: any;
export interface CustomerAgreementSummary {
    name?: string;
    arn?: string;
    id?: string;
    agreementArn?: string;
    awsAccountId?: string;
    organizationArn?: string;
    effectiveStart?: Date;
    effectiveEnd?: Date;
    state?: CustomerAgreementState;
    description?: string;
    acceptanceTerms?: string[];
    terminateTerms?: string[];
    type?: AgreementType;
}
export declare const CustomerAgreementSummary: S.Schema<CustomerAgreementSummary>;
export type CustomerAgreementList = CustomerAgreementSummary[];
export declare const CustomerAgreementList: any;
export interface ListCustomerAgreementsResponse {
    customerAgreements: CustomerAgreementSummary[];
    nextToken?: string;
}
export declare const ListCustomerAgreementsResponse: S.Schema<ListCustomerAgreementsResponse>;
export interface ListReportsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListReportsRequest: S.Schema<ListReportsRequest>;
export interface ReportSummary {
    id?: string;
    name?: string;
    state?: PublishedState;
    arn?: string;
    version?: number;
    uploadState?: UploadState;
    description?: string;
    periodStart?: Date;
    periodEnd?: Date;
    series?: string;
    category?: string;
    companyName?: string;
    productName?: string;
    statusMessage?: string;
    acceptanceType?: AcceptanceType;
}
export declare const ReportSummary: S.Schema<ReportSummary>;
export type ReportsList = ReportSummary[];
export declare const ReportsList: any;
export interface ListReportsResponse {
    reports?: ReportSummary[];
    nextToken?: string;
}
export declare const ListReportsResponse: S.Schema<ListReportsResponse>;
export interface ListReportVersionsRequest {
    reportId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListReportVersionsRequest: S.Schema<ListReportVersionsRequest>;
export interface ListReportVersionsResponse {
    reports: ReportSummary[];
    nextToken?: string;
}
export declare const ListReportVersionsResponse: S.Schema<ListReportVersionsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PutAccountSettingsRequest {
    notificationSubscriptionStatus?: NotificationSubscriptionStatus;
}
export declare const PutAccountSettingsRequest: S.Schema<PutAccountSettingsRequest>;
export interface PutAccountSettingsResponse {
    accountSettings?: AccountSettings;
}
export declare const PutAccountSettingsResponse: S.Schema<PutAccountSettingsResponse>;
export type FeedbackRating = "THUMBS_UP" | "THUMBS_DOWN" | (string & {});
export declare const FeedbackRating: any;
export type FeedbackReasonCode = "OTHER" | "PARTIAL_RESPONSE" | "IRRELEVANT_RESPONSE" | (string & {});
export declare const FeedbackReasonCode: any;
export type FeedbackReasonCodeList = FeedbackReasonCode[];
export declare const FeedbackReasonCodeList: any;
export type FeedbackCommentAttribute = string | redacted.Redacted<string>;
export interface PutComplianceInquiryFeedbackRequest {
    complianceInquiryId: string;
    queryIdentifier?: number;
    rating: FeedbackRating;
    responseRevisionId?: number;
    reasonCodes?: FeedbackReasonCode[];
    comment?: string | redacted.Redacted<string>;
    clientToken?: string;
}
export declare const PutComplianceInquiryFeedbackRequest: S.Schema<PutComplianceInquiryFeedbackRequest>;
export interface PutComplianceInquiryFeedbackResponse {
    submittedAt: Date;
}
export declare const PutComplianceInquiryFeedbackResponse: S.Schema<PutComplianceInquiryFeedbackResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type CreateComplianceInquiryError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a new compliance inquiry.
 */
export declare const createComplianceInquiry: API.OperationMethod<CreateComplianceInquiryRequest, CreateComplianceInquiryResponse, CreateComplianceInquiryError, Credentials | HttpClient.HttpClient>;
export type ExportComplianceInquiryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Export a compliance inquiry report.
 */
export declare const exportComplianceInquiry: API.OperationMethod<ExportComplianceInquiryRequest, ExportComplianceInquiryResponse, ExportComplianceInquiryError, Credentials | HttpClient.HttpClient>;
export type GetAccountSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the account settings for Artifact.
 */
export declare const getAccountSettings: API.OperationMethod<GetAccountSettingsRequest, GetAccountSettingsResponse, GetAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type GetComplianceInquiryMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the metadata for a single compliance inquiry.
 */
export declare const getComplianceInquiryMetadata: API.OperationMethod<GetComplianceInquiryMetadataRequest, GetComplianceInquiryMetadataResponse, GetComplianceInquiryMetadataError, Credentials | HttpClient.HttpClient>;
export type GetReportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the content for a single report.
 */
export declare const getReport: API.OperationMethod<GetReportRequest, GetReportResponse, GetReportError, Credentials | HttpClient.HttpClient>;
export type GetReportMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the metadata for a single report.
 */
export declare const getReportMetadata: API.OperationMethod<GetReportMetadataRequest, GetReportMetadataResponse, GetReportMetadataError, Credentials | HttpClient.HttpClient>;
export type GetTermForReportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the Term content associated with a single report.
 */
export declare const getTermForReport: API.OperationMethod<GetTermForReportRequest, GetTermForReportResponse, GetTermForReportError, Credentials | HttpClient.HttpClient>;
export type ListComplianceInquiriesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List available compliance inquiries.
 */
export declare const listComplianceInquiries: API.PaginatedOperationMethod<ListComplianceInquiriesRequest, ListComplianceInquiriesResponse, ListComplianceInquiriesError, Credentials | HttpClient.HttpClient, InquirySummary>;
export type ListComplianceInquiryQueriesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List queries within a compliance inquiry.
 */
export declare const listComplianceInquiryQueries: API.PaginatedOperationMethod<ListComplianceInquiryQueriesRequest, ListComplianceInquiryQueriesResponse, ListComplianceInquiryQueriesError, Credentials | HttpClient.HttpClient, QuerySummary>;
export type ListCustomerAgreementsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List active customer-agreements applicable to calling identity.
 */
export declare const listCustomerAgreements: API.PaginatedOperationMethod<ListCustomerAgreementsRequest, ListCustomerAgreementsResponse, ListCustomerAgreementsError, Credentials | HttpClient.HttpClient, CustomerAgreementSummary>;
export type ListReportsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List available reports.
 */
export declare const listReports: API.PaginatedOperationMethod<ListReportsRequest, ListReportsResponse, ListReportsError, Credentials | HttpClient.HttpClient, ReportSummary>;
export type ListReportVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List available report versions for a given report.
 */
export declare const listReportVersions: API.PaginatedOperationMethod<ListReportVersionsRequest, ListReportVersionsResponse, ListReportVersionsError, Credentials | HttpClient.HttpClient, ReportSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutAccountSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Put the account settings for Artifact.
 */
export declare const putAccountSettings: API.OperationMethod<PutAccountSettingsRequest, PutAccountSettingsResponse, PutAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type PutComplianceInquiryFeedbackError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Submits feedback on a compliance inquiry response.
 */
export declare const putComplianceInquiryFeedback: API.OperationMethod<PutComplianceInquiryFeedbackRequest, PutComplianceInquiryFeedbackResponse, PutComplianceInquiryFeedbackError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Add tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=artifact.d.ts.map