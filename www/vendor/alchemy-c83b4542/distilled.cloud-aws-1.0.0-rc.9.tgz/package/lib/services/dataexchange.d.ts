import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceLimitExceededException_base: S.Class<ServiceLimitExceededException, S.TaggedStruct<"ServiceLimitExceededException", {
    readonly LimitName: any;
    readonly LimitValue: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceLimitExceededException extends /*@__PURE__*/ ServiceLimitExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly ExceptionCause: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DataGrantArn = string;
export interface AcceptDataGrantRequest {
    DataGrantArn: string;
}
export declare const AcceptDataGrantRequest: S.Schema<AcceptDataGrantRequest>;
export type DataGrantName = string;
export type SenderPrincipal = string;
export type ReceiverPrincipal = string;
export type DataGrantDescription = string;
export type DataGrantAcceptanceState = string;
export type GrantDistributionScope = string;
export type Id = string;
export type Arn = string;
export interface AcceptDataGrantResponse {
    Name: string;
    SenderPrincipal?: string;
    ReceiverPrincipal: string;
    Description?: string;
    AcceptanceState: string;
    AcceptedAt?: Date;
    EndsAt?: Date;
    GrantDistributionScope: string;
    DataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export declare const AcceptDataGrantResponse: S.Schema<AcceptDataGrantResponse>;
export interface CancelJobRequest {
    JobId: string;
}
export declare const CancelJobRequest: S.Schema<CancelJobRequest>;
export interface CancelJobResponse {
}
export declare const CancelJobResponse: S.Schema<CancelJobResponse>;
export type Description = string;
export type MapOf__string = {
    [key: string]: string | undefined;
};
export declare const MapOf__string: any;
export interface CreateDataGrantRequest {
    Name: string;
    GrantDistributionScope: string;
    ReceiverPrincipal: string;
    SourceDataSetId: string;
    EndsAt?: Date;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDataGrantRequest: S.Schema<CreateDataGrantRequest>;
export interface CreateDataGrantResponse {
    Name: string;
    SenderPrincipal: string;
    ReceiverPrincipal: string;
    Description?: string;
    AcceptanceState: string;
    AcceptedAt?: Date;
    EndsAt?: Date;
    GrantDistributionScope: string;
    DataSetId: string;
    SourceDataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDataGrantResponse: S.Schema<CreateDataGrantResponse>;
export type AssetType = string;
export type Name = string;
export interface CreateDataSetRequest {
    AssetType: string;
    Description: string;
    Name: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDataSetRequest: S.Schema<CreateDataSetRequest>;
export type Origin = string;
export interface OriginDetails {
    ProductId?: string;
    DataGrantId?: string;
}
export declare const OriginDetails: S.Schema<OriginDetails>;
export interface CreateDataSetResponse {
    Arn?: string;
    AssetType?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    Name?: string;
    Origin?: string;
    OriginDetails?: OriginDetails;
    SourceId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
}
export declare const CreateDataSetResponse: S.Schema<CreateDataSetResponse>;
export type ServerSideEncryptionTypes = string;
export interface ExportServerSideEncryption {
    KmsKeyArn?: string;
    Type: string;
}
export declare const ExportServerSideEncryption: S.Schema<ExportServerSideEncryption>;
export interface AutoExportRevisionDestinationEntry {
    Bucket: string;
    KeyPattern?: string;
}
export declare const AutoExportRevisionDestinationEntry: S.Schema<AutoExportRevisionDestinationEntry>;
export interface AutoExportRevisionToS3RequestDetails {
    Encryption?: ExportServerSideEncryption;
    RevisionDestination: AutoExportRevisionDestinationEntry;
}
export declare const AutoExportRevisionToS3RequestDetails: S.Schema<AutoExportRevisionToS3RequestDetails>;
export interface Action {
    ExportRevisionToS3?: AutoExportRevisionToS3RequestDetails;
}
export declare const Action: S.Schema<Action>;
export interface RevisionPublished {
    DataSetId: string;
}
export declare const RevisionPublished: S.Schema<RevisionPublished>;
export interface Event {
    RevisionPublished?: RevisionPublished;
}
export declare const Event: S.Schema<Event>;
export interface CreateEventActionRequest {
    Action: Action;
    Event: Event;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateEventActionRequest: S.Schema<CreateEventActionRequest>;
export interface CreateEventActionResponse {
    Action?: Action;
    Arn?: string;
    CreatedAt?: Date;
    Event?: Event;
    Id?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
}
export declare const CreateEventActionResponse: S.Schema<CreateEventActionResponse>;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type ListOfTag = Tag[];
export declare const ListOfTag: any;
export interface AssetConfiguration {
    Tags?: Tag[];
}
export declare const AssetConfiguration: S.Schema<AssetConfiguration>;
export interface ExportAssetToSignedUrlRequestDetails {
    AssetId: string;
    DataSetId: string;
    RevisionId: string;
}
export declare const ExportAssetToSignedUrlRequestDetails: S.Schema<ExportAssetToSignedUrlRequestDetails>;
export interface AssetDestinationEntry {
    AssetId: string;
    Bucket: string;
    Key?: string;
}
export declare const AssetDestinationEntry: S.Schema<AssetDestinationEntry>;
export type ListOfAssetDestinationEntry = AssetDestinationEntry[];
export declare const ListOfAssetDestinationEntry: any;
export interface ExportAssetsToS3RequestDetails {
    AssetDestinations: AssetDestinationEntry[];
    DataSetId: string;
    Encryption?: ExportServerSideEncryption;
    RevisionId: string;
}
export declare const ExportAssetsToS3RequestDetails: S.Schema<ExportAssetsToS3RequestDetails>;
export interface RevisionDestinationEntry {
    Bucket: string;
    KeyPattern?: string;
    RevisionId: string;
}
export declare const RevisionDestinationEntry: S.Schema<RevisionDestinationEntry>;
export type ListOfRevisionDestinationEntry = RevisionDestinationEntry[];
export declare const ListOfRevisionDestinationEntry: any;
export interface ExportRevisionsToS3RequestDetails {
    DataSetId: string;
    Encryption?: ExportServerSideEncryption;
    RevisionDestinations: RevisionDestinationEntry[];
}
export declare const ExportRevisionsToS3RequestDetails: S.Schema<ExportRevisionsToS3RequestDetails>;
export type AssetName = string;
export type __stringMin24Max24PatternAZaZ094AZaZ092AZaZ093 = string;
export interface ImportAssetFromSignedUrlRequestDetails {
    AssetName: string;
    DataSetId: string;
    Md5Hash: string;
    RevisionId: string;
}
export declare const ImportAssetFromSignedUrlRequestDetails: S.Schema<ImportAssetFromSignedUrlRequestDetails>;
export interface AssetSourceEntry {
    Bucket: string;
    Key: string;
}
export declare const AssetSourceEntry: S.Schema<AssetSourceEntry>;
export type ListOfAssetSourceEntry = AssetSourceEntry[];
export declare const ListOfAssetSourceEntry: any;
export interface ImportAssetsFromS3RequestDetails {
    AssetSources: AssetSourceEntry[];
    DataSetId: string;
    RevisionId: string;
}
export declare const ImportAssetsFromS3RequestDetails: S.Schema<ImportAssetsFromS3RequestDetails>;
export interface RedshiftDataShareAssetSourceEntry {
    DataShareArn: string;
}
export declare const RedshiftDataShareAssetSourceEntry: S.Schema<RedshiftDataShareAssetSourceEntry>;
export type ListOfRedshiftDataShareAssetSourceEntry = RedshiftDataShareAssetSourceEntry[];
export declare const ListOfRedshiftDataShareAssetSourceEntry: any;
export interface ImportAssetsFromRedshiftDataSharesRequestDetails {
    AssetSources: RedshiftDataShareAssetSourceEntry[];
    DataSetId: string;
    RevisionId: string;
}
export declare const ImportAssetsFromRedshiftDataSharesRequestDetails: S.Schema<ImportAssetsFromRedshiftDataSharesRequestDetails>;
export type ApiDescription = string;
export type ProtocolType = string;
export interface ImportAssetFromApiGatewayApiRequestDetails {
    ApiDescription?: string;
    ApiId: string;
    ApiKey?: string | redacted.Redacted<string>;
    ApiName: string;
    ApiSpecificationMd5Hash: string;
    DataSetId: string;
    ProtocolType: string;
    RevisionId: string;
    Stage: string;
}
export declare const ImportAssetFromApiGatewayApiRequestDetails: S.Schema<ImportAssetFromApiGatewayApiRequestDetails>;
export type ListOf__string = string[];
export declare const ListOf__string: any;
export type KmsKeyArn = string;
export interface KmsKeyToGrant {
    KmsKeyArn: string;
}
export declare const KmsKeyToGrant: S.Schema<KmsKeyToGrant>;
export type ListOfKmsKeysToGrant = KmsKeyToGrant[];
export declare const ListOfKmsKeysToGrant: any;
export interface S3DataAccessAssetSourceEntry {
    Bucket: string;
    KeyPrefixes?: string[];
    Keys?: string[];
    KmsKeysToGrant?: KmsKeyToGrant[];
}
export declare const S3DataAccessAssetSourceEntry: S.Schema<S3DataAccessAssetSourceEntry>;
export interface CreateS3DataAccessFromS3BucketRequestDetails {
    AssetSource: S3DataAccessAssetSourceEntry;
    DataSetId: string;
    RevisionId: string;
}
export declare const CreateS3DataAccessFromS3BucketRequestDetails: S.Schema<CreateS3DataAccessFromS3BucketRequestDetails>;
export type AwsAccountId = string;
export type ListOfLFTagValues = string[];
export declare const ListOfLFTagValues: any;
export interface LFTag {
    TagKey: string;
    TagValues: string[];
}
export declare const LFTag: S.Schema<LFTag>;
export type ListOfLFTags = LFTag[];
export declare const ListOfLFTags: any;
export type DatabaseLFTagPolicyPermission = string;
export type ListOfDatabaseLFTagPolicyPermissions = string[];
export declare const ListOfDatabaseLFTagPolicyPermissions: any;
export interface DatabaseLFTagPolicyAndPermissions {
    Expression: LFTag[];
    Permissions: string[];
}
export declare const DatabaseLFTagPolicyAndPermissions: S.Schema<DatabaseLFTagPolicyAndPermissions>;
export type TableTagPolicyLFPermission = string;
export type ListOfTableTagPolicyLFPermissions = string[];
export declare const ListOfTableTagPolicyLFPermissions: any;
export interface TableLFTagPolicyAndPermissions {
    Expression: LFTag[];
    Permissions: string[];
}
export declare const TableLFTagPolicyAndPermissions: S.Schema<TableLFTagPolicyAndPermissions>;
export type RoleArn = string;
export interface ImportAssetsFromLakeFormationTagPolicyRequestDetails {
    CatalogId: string;
    Database?: DatabaseLFTagPolicyAndPermissions;
    Table?: TableLFTagPolicyAndPermissions;
    RoleArn: string;
    DataSetId: string;
    RevisionId: string;
}
export declare const ImportAssetsFromLakeFormationTagPolicyRequestDetails: S.Schema<ImportAssetsFromLakeFormationTagPolicyRequestDetails>;
export interface RequestDetails {
    ExportAssetToSignedUrl?: ExportAssetToSignedUrlRequestDetails;
    ExportAssetsToS3?: ExportAssetsToS3RequestDetails;
    ExportRevisionsToS3?: ExportRevisionsToS3RequestDetails;
    ImportAssetFromSignedUrl?: ImportAssetFromSignedUrlRequestDetails;
    ImportAssetsFromS3?: ImportAssetsFromS3RequestDetails;
    ImportAssetsFromRedshiftDataShares?: ImportAssetsFromRedshiftDataSharesRequestDetails;
    ImportAssetFromApiGatewayApi?: ImportAssetFromApiGatewayApiRequestDetails;
    CreateS3DataAccessFromS3Bucket?: CreateS3DataAccessFromS3BucketRequestDetails;
    ImportAssetsFromLakeFormationTagPolicy?: ImportAssetsFromLakeFormationTagPolicyRequestDetails;
}
export declare const RequestDetails: S.Schema<RequestDetails>;
export type Type = string;
export interface CreateJobRequest {
    AssetConfiguration?: AssetConfiguration;
    Details: RequestDetails;
    Type: string;
}
export declare const CreateJobRequest: S.Schema<CreateJobRequest>;
export interface ExportAssetToSignedUrlResponseDetails {
    AssetId: string;
    DataSetId: string;
    RevisionId: string;
    SignedUrl?: string;
    SignedUrlExpiresAt?: Date;
}
export declare const ExportAssetToSignedUrlResponseDetails: S.Schema<ExportAssetToSignedUrlResponseDetails>;
export interface ExportAssetsToS3ResponseDetails {
    AssetDestinations: AssetDestinationEntry[];
    DataSetId: string;
    Encryption?: ExportServerSideEncryption;
    RevisionId: string;
}
export declare const ExportAssetsToS3ResponseDetails: S.Schema<ExportAssetsToS3ResponseDetails>;
export interface ExportRevisionsToS3ResponseDetails {
    DataSetId: string;
    Encryption?: ExportServerSideEncryption;
    RevisionDestinations: RevisionDestinationEntry[];
    EventActionArn?: string;
}
export declare const ExportRevisionsToS3ResponseDetails: S.Schema<ExportRevisionsToS3ResponseDetails>;
export interface ImportAssetFromSignedUrlResponseDetails {
    AssetName: string;
    DataSetId: string;
    Md5Hash?: string;
    RevisionId: string;
    SignedUrl?: string;
    SignedUrlExpiresAt?: Date;
}
export declare const ImportAssetFromSignedUrlResponseDetails: S.Schema<ImportAssetFromSignedUrlResponseDetails>;
export interface ImportAssetsFromS3ResponseDetails {
    AssetSources: AssetSourceEntry[];
    DataSetId: string;
    RevisionId: string;
}
export declare const ImportAssetsFromS3ResponseDetails: S.Schema<ImportAssetsFromS3ResponseDetails>;
export interface ImportAssetsFromRedshiftDataSharesResponseDetails {
    AssetSources: RedshiftDataShareAssetSourceEntry[];
    DataSetId: string;
    RevisionId: string;
}
export declare const ImportAssetsFromRedshiftDataSharesResponseDetails: S.Schema<ImportAssetsFromRedshiftDataSharesResponseDetails>;
export interface ImportAssetFromApiGatewayApiResponseDetails {
    ApiDescription?: string;
    ApiId: string;
    ApiKey?: string | redacted.Redacted<string>;
    ApiName: string;
    ApiSpecificationMd5Hash: string;
    ApiSpecificationUploadUrl: string;
    ApiSpecificationUploadUrlExpiresAt: Date;
    DataSetId: string;
    ProtocolType: string;
    RevisionId: string;
    Stage: string;
}
export declare const ImportAssetFromApiGatewayApiResponseDetails: S.Schema<ImportAssetFromApiGatewayApiResponseDetails>;
export interface CreateS3DataAccessFromS3BucketResponseDetails {
    AssetSource: S3DataAccessAssetSourceEntry;
    DataSetId: string;
    RevisionId: string;
}
export declare const CreateS3DataAccessFromS3BucketResponseDetails: S.Schema<CreateS3DataAccessFromS3BucketResponseDetails>;
export interface ImportAssetsFromLakeFormationTagPolicyResponseDetails {
    CatalogId: string;
    Database?: DatabaseLFTagPolicyAndPermissions;
    Table?: TableLFTagPolicyAndPermissions;
    RoleArn: string;
    DataSetId: string;
    RevisionId: string;
}
export declare const ImportAssetsFromLakeFormationTagPolicyResponseDetails: S.Schema<ImportAssetsFromLakeFormationTagPolicyResponseDetails>;
export interface ResponseDetails {
    ExportAssetToSignedUrl?: ExportAssetToSignedUrlResponseDetails;
    ExportAssetsToS3?: ExportAssetsToS3ResponseDetails;
    ExportRevisionsToS3?: ExportRevisionsToS3ResponseDetails;
    ImportAssetFromSignedUrl?: ImportAssetFromSignedUrlResponseDetails;
    ImportAssetsFromS3?: ImportAssetsFromS3ResponseDetails;
    ImportAssetsFromRedshiftDataShares?: ImportAssetsFromRedshiftDataSharesResponseDetails;
    ImportAssetFromApiGatewayApi?: ImportAssetFromApiGatewayApiResponseDetails;
    CreateS3DataAccessFromS3Bucket?: CreateS3DataAccessFromS3BucketResponseDetails;
    ImportAssetsFromLakeFormationTagPolicy?: ImportAssetsFromLakeFormationTagPolicyResponseDetails;
}
export declare const ResponseDetails: S.Schema<ResponseDetails>;
export type Code = string;
export interface ImportAssetFromSignedUrlJobErrorDetails {
    AssetName: string;
}
export declare const ImportAssetFromSignedUrlJobErrorDetails: S.Schema<ImportAssetFromSignedUrlJobErrorDetails>;
export interface Details {
    ImportAssetFromSignedUrlJobErrorDetails?: ImportAssetFromSignedUrlJobErrorDetails;
    ImportAssetsFromS3JobErrorDetails?: AssetSourceEntry[];
}
export declare const Details: S.Schema<Details>;
export type JobErrorLimitName = string;
export type JobErrorResourceTypes = string;
export interface JobError {
    Code: string;
    Details?: Details;
    LimitName?: string;
    LimitValue?: number;
    Message: string;
    ResourceId?: string;
    ResourceType?: string;
}
export declare const JobError: S.Schema<JobError>;
export type ListOfJobError = JobError[];
export declare const ListOfJobError: any;
export type State = string;
export interface CreateJobResponse {
    Arn?: string;
    AssetConfiguration?: AssetConfiguration;
    CreatedAt?: Date;
    Details?: ResponseDetails;
    Errors?: JobError[];
    Id?: string;
    State?: string;
    Type?: string;
    UpdatedAt?: Date;
}
export declare const CreateJobResponse: S.Schema<CreateJobResponse>;
export type __stringMin0Max16384 = string;
export interface CreateRevisionRequest {
    Comment?: string;
    DataSetId: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateRevisionRequest: S.Schema<CreateRevisionRequest>;
export type __stringMin10Max512 = string;
export interface CreateRevisionResponse {
    Arn?: string;
    Comment?: string;
    CreatedAt?: Date;
    DataSetId?: string;
    Finalized?: boolean;
    Id?: string;
    SourceId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
    RevocationComment?: string;
    Revoked?: boolean;
    RevokedAt?: Date;
}
export declare const CreateRevisionResponse: S.Schema<CreateRevisionResponse>;
export interface DeleteAssetRequest {
    AssetId: string;
    DataSetId: string;
    RevisionId: string;
}
export declare const DeleteAssetRequest: S.Schema<DeleteAssetRequest>;
export interface DeleteAssetResponse {
}
export declare const DeleteAssetResponse: S.Schema<DeleteAssetResponse>;
export type DataGrantId = string;
export interface DeleteDataGrantRequest {
    DataGrantId: string;
}
export declare const DeleteDataGrantRequest: S.Schema<DeleteDataGrantRequest>;
export interface DeleteDataGrantResponse {
}
export declare const DeleteDataGrantResponse: S.Schema<DeleteDataGrantResponse>;
export interface DeleteDataSetRequest {
    DataSetId: string;
}
export declare const DeleteDataSetRequest: S.Schema<DeleteDataSetRequest>;
export interface DeleteDataSetResponse {
}
export declare const DeleteDataSetResponse: S.Schema<DeleteDataSetResponse>;
export interface DeleteEventActionRequest {
    EventActionId: string;
}
export declare const DeleteEventActionRequest: S.Schema<DeleteEventActionRequest>;
export interface DeleteEventActionResponse {
}
export declare const DeleteEventActionResponse: S.Schema<DeleteEventActionResponse>;
export interface DeleteRevisionRequest {
    DataSetId: string;
    RevisionId: string;
}
export declare const DeleteRevisionRequest: S.Schema<DeleteRevisionRequest>;
export interface DeleteRevisionResponse {
}
export declare const DeleteRevisionResponse: S.Schema<DeleteRevisionResponse>;
export interface GetAssetRequest {
    AssetId: string;
    DataSetId: string;
    RevisionId: string;
}
export declare const GetAssetRequest: S.Schema<GetAssetRequest>;
export type __doubleMin0 = number;
export interface S3SnapshotAsset {
    Size: number;
}
export declare const S3SnapshotAsset: S.Schema<S3SnapshotAsset>;
export interface RedshiftDataShareAsset {
    Arn: string;
}
export declare const RedshiftDataShareAsset: S.Schema<RedshiftDataShareAsset>;
export interface ApiGatewayApiAsset {
    ApiDescription?: string;
    ApiEndpoint?: string;
    ApiId?: string;
    ApiKey?: string | redacted.Redacted<string>;
    ApiName?: string;
    ApiSpecificationDownloadUrl?: string;
    ApiSpecificationDownloadUrlExpiresAt?: Date;
    ProtocolType?: string;
    Stage?: string;
}
export declare const ApiGatewayApiAsset: S.Schema<ApiGatewayApiAsset>;
export interface S3DataAccessAsset {
    Bucket: string;
    KeyPrefixes?: string[];
    Keys?: string[];
    S3AccessPointAlias?: string;
    S3AccessPointArn?: string;
    KmsKeysToGrant?: KmsKeyToGrant[];
}
export declare const S3DataAccessAsset: S.Schema<S3DataAccessAsset>;
export type LFResourceType = string;
export interface DatabaseLFTagPolicy {
    Expression: LFTag[];
}
export declare const DatabaseLFTagPolicy: S.Schema<DatabaseLFTagPolicy>;
export interface TableLFTagPolicy {
    Expression: LFTag[];
}
export declare const TableLFTagPolicy: S.Schema<TableLFTagPolicy>;
export interface LFResourceDetails {
    Database?: DatabaseLFTagPolicy;
    Table?: TableLFTagPolicy;
}
export declare const LFResourceDetails: S.Schema<LFResourceDetails>;
export interface LFTagPolicyDetails {
    CatalogId: string;
    ResourceType: string;
    ResourceDetails: LFResourceDetails;
}
export declare const LFTagPolicyDetails: S.Schema<LFTagPolicyDetails>;
export interface LakeFormationDataPermissionDetails {
    LFTagPolicy?: LFTagPolicyDetails;
}
export declare const LakeFormationDataPermissionDetails: S.Schema<LakeFormationDataPermissionDetails>;
export type LakeFormationDataPermissionType = string;
export type LFPermission = string;
export type ListOfLFPermissions = string[];
export declare const ListOfLFPermissions: any;
export interface LakeFormationDataPermissionAsset {
    LakeFormationDataPermissionDetails: LakeFormationDataPermissionDetails;
    LakeFormationDataPermissionType: string;
    Permissions: string[];
    RoleArn?: string;
}
export declare const LakeFormationDataPermissionAsset: S.Schema<LakeFormationDataPermissionAsset>;
export interface AssetDetails {
    S3SnapshotAsset?: S3SnapshotAsset;
    RedshiftDataShareAsset?: RedshiftDataShareAsset;
    ApiGatewayApiAsset?: ApiGatewayApiAsset;
    S3DataAccessAsset?: S3DataAccessAsset;
    LakeFormationDataPermissionAsset?: LakeFormationDataPermissionAsset;
}
export declare const AssetDetails: S.Schema<AssetDetails>;
export interface GetAssetResponse {
    Arn?: string;
    AssetDetails?: AssetDetails;
    AssetType?: string;
    CreatedAt?: Date;
    DataSetId?: string;
    Id?: string;
    Name?: string;
    RevisionId?: string;
    SourceId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
}
export declare const GetAssetResponse: S.Schema<GetAssetResponse>;
export interface GetDataGrantRequest {
    DataGrantId: string;
}
export declare const GetDataGrantRequest: S.Schema<GetDataGrantRequest>;
export interface GetDataGrantResponse {
    Name: string;
    SenderPrincipal: string;
    ReceiverPrincipal: string;
    Description?: string;
    AcceptanceState: string;
    AcceptedAt?: Date;
    EndsAt?: Date;
    GrantDistributionScope: string;
    DataSetId: string;
    SourceDataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetDataGrantResponse: S.Schema<GetDataGrantResponse>;
export interface GetDataSetRequest {
    DataSetId: string;
}
export declare const GetDataSetRequest: S.Schema<GetDataSetRequest>;
export interface GetDataSetResponse {
    Arn?: string;
    AssetType?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    Name?: string;
    Origin?: string;
    OriginDetails?: OriginDetails;
    SourceId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
}
export declare const GetDataSetResponse: S.Schema<GetDataSetResponse>;
export interface GetEventActionRequest {
    EventActionId: string;
}
export declare const GetEventActionRequest: S.Schema<GetEventActionRequest>;
export interface GetEventActionResponse {
    Action?: Action;
    Arn?: string;
    CreatedAt?: Date;
    Event?: Event;
    Id?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
}
export declare const GetEventActionResponse: S.Schema<GetEventActionResponse>;
export interface GetJobRequest {
    JobId: string;
}
export declare const GetJobRequest: S.Schema<GetJobRequest>;
export interface GetJobResponse {
    Arn?: string;
    AssetConfiguration?: AssetConfiguration;
    CreatedAt?: Date;
    Details?: ResponseDetails;
    Errors?: JobError[];
    Id?: string;
    State?: string;
    Type?: string;
    UpdatedAt?: Date;
}
export declare const GetJobResponse: S.Schema<GetJobResponse>;
export interface GetReceivedDataGrantRequest {
    DataGrantArn: string;
}
export declare const GetReceivedDataGrantRequest: S.Schema<GetReceivedDataGrantRequest>;
export interface GetReceivedDataGrantResponse {
    Name: string;
    SenderPrincipal?: string;
    ReceiverPrincipal: string;
    Description?: string;
    AcceptanceState: string;
    AcceptedAt?: Date;
    EndsAt?: Date;
    GrantDistributionScope: string;
    DataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export declare const GetReceivedDataGrantResponse: S.Schema<GetReceivedDataGrantResponse>;
export interface GetRevisionRequest {
    DataSetId: string;
    RevisionId: string;
}
export declare const GetRevisionRequest: S.Schema<GetRevisionRequest>;
export interface GetRevisionResponse {
    Arn?: string;
    Comment?: string;
    CreatedAt?: Date;
    DataSetId?: string;
    Finalized?: boolean;
    Id?: string;
    SourceId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
    RevocationComment?: string;
    Revoked?: boolean;
    RevokedAt?: Date;
}
export declare const GetRevisionResponse: S.Schema<GetRevisionResponse>;
export type MaxResults = number;
export interface ListDataGrantsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDataGrantsRequest: S.Schema<ListDataGrantsRequest>;
export interface DataGrantSummaryEntry {
    Name: string;
    SenderPrincipal: string;
    ReceiverPrincipal: string;
    AcceptanceState: string;
    AcceptedAt?: Date;
    EndsAt?: Date;
    DataSetId: string;
    SourceDataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export declare const DataGrantSummaryEntry: S.Schema<DataGrantSummaryEntry>;
export type ListOfDataGrantSummaryEntry = DataGrantSummaryEntry[];
export declare const ListOfDataGrantSummaryEntry: any;
export type NextToken = string;
export interface ListDataGrantsResponse {
    DataGrantSummaries?: DataGrantSummaryEntry[];
    NextToken?: string;
}
export declare const ListDataGrantsResponse: S.Schema<ListDataGrantsResponse>;
export interface ListDataSetRevisionsRequest {
    DataSetId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDataSetRevisionsRequest: S.Schema<ListDataSetRevisionsRequest>;
export interface RevisionEntry {
    Arn: string;
    Comment?: string;
    CreatedAt: Date;
    DataSetId: string;
    Finalized?: boolean;
    Id: string;
    SourceId?: string;
    UpdatedAt: Date;
    RevocationComment?: string;
    Revoked?: boolean;
    RevokedAt?: Date;
}
export declare const RevisionEntry: S.Schema<RevisionEntry>;
export type ListOfRevisionEntry = RevisionEntry[];
export declare const ListOfRevisionEntry: any;
export interface ListDataSetRevisionsResponse {
    NextToken?: string;
    Revisions?: RevisionEntry[];
}
export declare const ListDataSetRevisionsResponse: S.Schema<ListDataSetRevisionsResponse>;
export interface ListDataSetsRequest {
    MaxResults?: number;
    NextToken?: string;
    Origin?: string;
}
export declare const ListDataSetsRequest: S.Schema<ListDataSetsRequest>;
export interface DataSetEntry {
    Arn: string;
    AssetType: string;
    CreatedAt: Date;
    Description: string;
    Id: string;
    Name: string;
    Origin: string;
    OriginDetails?: OriginDetails;
    SourceId?: string;
    UpdatedAt: Date;
}
export declare const DataSetEntry: S.Schema<DataSetEntry>;
export type ListOfDataSetEntry = DataSetEntry[];
export declare const ListOfDataSetEntry: any;
export interface ListDataSetsResponse {
    DataSets?: DataSetEntry[];
    NextToken?: string;
}
export declare const ListDataSetsResponse: S.Schema<ListDataSetsResponse>;
export interface ListEventActionsRequest {
    EventSourceId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListEventActionsRequest: S.Schema<ListEventActionsRequest>;
export interface EventActionEntry {
    Action: Action;
    Arn: string;
    CreatedAt: Date;
    Event: Event;
    Id: string;
    UpdatedAt: Date;
}
export declare const EventActionEntry: S.Schema<EventActionEntry>;
export type ListOfEventActionEntry = EventActionEntry[];
export declare const ListOfEventActionEntry: any;
export interface ListEventActionsResponse {
    EventActions?: EventActionEntry[];
    NextToken?: string;
}
export declare const ListEventActionsResponse: S.Schema<ListEventActionsResponse>;
export interface ListJobsRequest {
    DataSetId?: string;
    MaxResults?: number;
    NextToken?: string;
    RevisionId?: string;
}
export declare const ListJobsRequest: S.Schema<ListJobsRequest>;
export interface JobEntry {
    Arn: string;
    AssetConfiguration?: AssetConfiguration;
    CreatedAt: Date;
    Details: ResponseDetails;
    Errors?: JobError[];
    Id: string;
    State: string;
    Type: string;
    UpdatedAt: Date;
}
export declare const JobEntry: S.Schema<JobEntry>;
export type ListOfJobEntry = JobEntry[];
export declare const ListOfJobEntry: any;
export interface ListJobsResponse {
    Jobs?: JobEntry[];
    NextToken?: string;
}
export declare const ListJobsResponse: S.Schema<ListJobsResponse>;
export type AcceptanceStateFilterValue = string;
export type AcceptanceStateFilterValues = string[];
export declare const AcceptanceStateFilterValues: any;
export interface ListReceivedDataGrantsRequest {
    MaxResults?: number;
    NextToken?: string;
    AcceptanceState?: string[];
}
export declare const ListReceivedDataGrantsRequest: S.Schema<ListReceivedDataGrantsRequest>;
export interface ReceivedDataGrantSummariesEntry {
    Name: string;
    SenderPrincipal: string;
    ReceiverPrincipal: string;
    AcceptanceState: string;
    AcceptedAt?: Date;
    EndsAt?: Date;
    DataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export declare const ReceivedDataGrantSummariesEntry: S.Schema<ReceivedDataGrantSummariesEntry>;
export type ListOfReceivedDataGrantSummariesEntry = ReceivedDataGrantSummariesEntry[];
export declare const ListOfReceivedDataGrantSummariesEntry: any;
export interface ListReceivedDataGrantsResponse {
    DataGrantSummaries?: ReceivedDataGrantSummariesEntry[];
    NextToken?: string;
}
export declare const ListReceivedDataGrantsResponse: S.Schema<ListReceivedDataGrantsResponse>;
export interface ListRevisionAssetsRequest {
    DataSetId: string;
    MaxResults?: number;
    NextToken?: string;
    RevisionId: string;
}
export declare const ListRevisionAssetsRequest: S.Schema<ListRevisionAssetsRequest>;
export interface AssetEntry {
    Arn: string;
    AssetDetails: AssetDetails;
    AssetType: string;
    CreatedAt: Date;
    DataSetId: string;
    Id: string;
    Name: string;
    RevisionId: string;
    SourceId?: string;
    UpdatedAt: Date;
}
export declare const AssetEntry: S.Schema<AssetEntry>;
export type ListOfAssetEntry = AssetEntry[];
export declare const ListOfAssetEntry: any;
export interface ListRevisionAssetsResponse {
    Assets?: AssetEntry[];
    NextToken?: string;
}
export declare const ListRevisionAssetsResponse: S.Schema<ListRevisionAssetsResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface RevokeRevisionRequest {
    DataSetId: string;
    RevisionId: string;
    RevocationComment: string;
}
export declare const RevokeRevisionRequest: S.Schema<RevokeRevisionRequest>;
export interface RevokeRevisionResponse {
    Arn?: string;
    Comment?: string;
    CreatedAt?: Date;
    DataSetId?: string;
    Finalized?: boolean;
    Id?: string;
    SourceId?: string;
    UpdatedAt?: Date;
    RevocationComment?: string;
    Revoked?: boolean;
    RevokedAt?: Date;
}
export declare const RevokeRevisionResponse: S.Schema<RevokeRevisionResponse>;
export interface SendApiAssetRequest {
    Body?: string;
    QueryStringParameters?: {
        [key: string]: string | undefined;
    };
    AssetId: string;
    DataSetId: string;
    RequestHeaders?: {
        [key: string]: string | undefined;
    };
    Method?: string;
    Path?: string;
    RevisionId: string;
}
export declare const SendApiAssetRequest: S.Schema<SendApiAssetRequest>;
export interface SendApiAssetResponse {
    Body?: string;
    ResponseHeaders?: {
        [key: string]: string | undefined;
    };
}
export declare const SendApiAssetResponse: S.Schema<SendApiAssetResponse>;
export interface LakeFormationTagPolicyDetails {
    Database?: string;
    Table?: string;
}
export declare const LakeFormationTagPolicyDetails: S.Schema<LakeFormationTagPolicyDetails>;
export type ListOfLakeFormationTagPolicies = LakeFormationTagPolicyDetails[];
export declare const ListOfLakeFormationTagPolicies: any;
export interface RedshiftDataShareDetails {
    Arn: string;
    Database: string;
    Function?: string;
    Table?: string;
    Schema?: string;
    View?: string;
}
export declare const RedshiftDataShareDetails: S.Schema<RedshiftDataShareDetails>;
export type ListOfRedshiftDataShares = RedshiftDataShareDetails[];
export declare const ListOfRedshiftDataShares: any;
export interface S3DataAccessDetails {
    KeyPrefixes?: string[];
    Keys?: string[];
}
export declare const S3DataAccessDetails: S.Schema<S3DataAccessDetails>;
export type ListOfS3DataAccesses = S3DataAccessDetails[];
export declare const ListOfS3DataAccesses: any;
export interface ScopeDetails {
    LakeFormationTagPolicies?: LakeFormationTagPolicyDetails[];
    RedshiftDataShares?: RedshiftDataShareDetails[];
    S3DataAccesses?: S3DataAccessDetails[];
}
export declare const ScopeDetails: S.Schema<ScopeDetails>;
export type ClientToken = string;
export type __stringMin0Max4096 = string;
export interface DataUpdateRequestDetails {
    DataUpdatedAt?: Date;
}
export declare const DataUpdateRequestDetails: S.Schema<DataUpdateRequestDetails>;
export interface DeprecationRequestDetails {
    DeprecationAt: Date;
}
export declare const DeprecationRequestDetails: S.Schema<DeprecationRequestDetails>;
export type SchemaChangeType = string;
export interface SchemaChangeDetails {
    Name: string;
    Type: string;
    Description?: string;
}
export declare const SchemaChangeDetails: S.Schema<SchemaChangeDetails>;
export type ListOfSchemaChangeDetails = SchemaChangeDetails[];
export declare const ListOfSchemaChangeDetails: any;
export interface SchemaChangeRequestDetails {
    Changes?: SchemaChangeDetails[];
    SchemaChangeAt: Date;
}
export declare const SchemaChangeRequestDetails: S.Schema<SchemaChangeRequestDetails>;
export interface NotificationDetails {
    DataUpdate?: DataUpdateRequestDetails;
    Deprecation?: DeprecationRequestDetails;
    SchemaChange?: SchemaChangeRequestDetails;
}
export declare const NotificationDetails: S.Schema<NotificationDetails>;
export type NotificationType = string;
export interface SendDataSetNotificationRequest {
    Scope?: ScopeDetails;
    ClientToken?: string;
    Comment?: string;
    DataSetId: string;
    Details?: NotificationDetails;
    Type: string;
}
export declare const SendDataSetNotificationRequest: S.Schema<SendDataSetNotificationRequest>;
export interface SendDataSetNotificationResponse {
}
export declare const SendDataSetNotificationResponse: S.Schema<SendDataSetNotificationResponse>;
export interface StartJobRequest {
    JobId: string;
}
export declare const StartJobRequest: S.Schema<StartJobRequest>;
export interface StartJobResponse {
}
export declare const StartJobResponse: S.Schema<StartJobResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAssetRequest {
    AssetId: string;
    DataSetId: string;
    Name: string;
    RevisionId: string;
}
export declare const UpdateAssetRequest: S.Schema<UpdateAssetRequest>;
export interface UpdateAssetResponse {
    Arn?: string;
    AssetDetails?: AssetDetails;
    AssetType?: string;
    CreatedAt?: Date;
    DataSetId?: string;
    Id?: string;
    Name?: string;
    RevisionId?: string;
    SourceId?: string;
    UpdatedAt?: Date;
}
export declare const UpdateAssetResponse: S.Schema<UpdateAssetResponse>;
export interface UpdateDataSetRequest {
    DataSetId: string;
    Description?: string;
    Name?: string;
}
export declare const UpdateDataSetRequest: S.Schema<UpdateDataSetRequest>;
export interface UpdateDataSetResponse {
    Arn?: string;
    AssetType?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    Name?: string;
    Origin?: string;
    OriginDetails?: OriginDetails;
    SourceId?: string;
    UpdatedAt?: Date;
}
export declare const UpdateDataSetResponse: S.Schema<UpdateDataSetResponse>;
export interface UpdateEventActionRequest {
    Action?: Action;
    EventActionId: string;
}
export declare const UpdateEventActionRequest: S.Schema<UpdateEventActionRequest>;
export interface UpdateEventActionResponse {
    Action?: Action;
    Arn?: string;
    CreatedAt?: Date;
    Event?: Event;
    Id?: string;
    UpdatedAt?: Date;
}
export declare const UpdateEventActionResponse: S.Schema<UpdateEventActionResponse>;
export interface UpdateRevisionRequest {
    Comment?: string;
    DataSetId: string;
    Finalized?: boolean;
    RevisionId: string;
}
export declare const UpdateRevisionRequest: S.Schema<UpdateRevisionRequest>;
export interface UpdateRevisionResponse {
    Arn?: string;
    Comment?: string;
    CreatedAt?: Date;
    DataSetId?: string;
    Finalized?: boolean;
    Id?: string;
    SourceId?: string;
    UpdatedAt?: Date;
    RevocationComment?: string;
    Revoked?: boolean;
    RevokedAt?: Date;
}
export declare const UpdateRevisionResponse: S.Schema<UpdateRevisionResponse>;
export type ResourceType = string;
export type ExceptionCause = string;
export type LimitName = string;
export type AcceptDataGrantError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation accepts a data grant.
 */
export declare const acceptDataGrant: API.OperationMethod<AcceptDataGrantRequest, AcceptDataGrantResponse, AcceptDataGrantError, Credentials | HttpClient.HttpClient>;
export type CancelJobError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation cancels a job. Jobs can be cancelled only when they are in the WAITING state.
 */
export declare const cancelJob: API.OperationMethod<CancelJobRequest, CancelJobResponse, CancelJobError, Credentials | HttpClient.HttpClient>;
export type CreateDataGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates a data grant.
 */
export declare const createDataGrant: API.OperationMethod<CreateDataGrantRequest, CreateDataGrantResponse, CreateDataGrantError, Credentials | HttpClient.HttpClient>;
export type CreateDataSetError = AccessDeniedException | InternalServerException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates a data set.
 */
export declare const createDataSet: API.OperationMethod<CreateDataSetRequest, CreateDataSetResponse, CreateDataSetError, Credentials | HttpClient.HttpClient>;
export type CreateEventActionError = AccessDeniedException | InternalServerException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates an event action.
 */
export declare const createEventAction: API.OperationMethod<CreateEventActionRequest, CreateEventActionResponse, CreateEventActionError, Credentials | HttpClient.HttpClient>;
export type CreateJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates a job.
 */
export declare const createJob: API.OperationMethod<CreateJobRequest, CreateJobResponse, CreateJobError, Credentials | HttpClient.HttpClient>;
export type CreateRevisionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates a revision for a data set.
 */
export declare const createRevision: API.OperationMethod<CreateRevisionRequest, CreateRevisionResponse, CreateRevisionError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes an asset.
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetRequest, DeleteAssetResponse, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeleteDataGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes a data grant.
 */
export declare const deleteDataGrant: API.OperationMethod<DeleteDataGrantRequest, DeleteDataGrantResponse, DeleteDataGrantError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes a data set.
 */
export declare const deleteDataSet: API.OperationMethod<DeleteDataSetRequest, DeleteDataSetResponse, DeleteDataSetError, Credentials | HttpClient.HttpClient>;
export type DeleteEventActionError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes the event action.
 */
export declare const deleteEventAction: API.OperationMethod<DeleteEventActionRequest, DeleteEventActionResponse, DeleteEventActionError, Credentials | HttpClient.HttpClient>;
export type DeleteRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes a revision.
 */
export declare const deleteRevision: API.OperationMethod<DeleteRevisionRequest, DeleteRevisionResponse, DeleteRevisionError, Credentials | HttpClient.HttpClient>;
export type GetAssetError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about an asset.
 */
export declare const getAsset: API.OperationMethod<GetAssetRequest, GetAssetResponse, GetAssetError, Credentials | HttpClient.HttpClient>;
export type GetDataGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a data grant.
 */
export declare const getDataGrant: API.OperationMethod<GetDataGrantRequest, GetDataGrantResponse, GetDataGrantError, Credentials | HttpClient.HttpClient>;
export type GetDataSetError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a data set.
 */
export declare const getDataSet: API.OperationMethod<GetDataSetRequest, GetDataSetResponse, GetDataSetError, Credentials | HttpClient.HttpClient>;
export type GetEventActionError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation retrieves information about an event action.
 */
export declare const getEventAction: API.OperationMethod<GetEventActionRequest, GetEventActionResponse, GetEventActionError, Credentials | HttpClient.HttpClient>;
export type GetJobError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a job.
 */
export declare const getJob: API.OperationMethod<GetJobRequest, GetJobResponse, GetJobError, Credentials | HttpClient.HttpClient>;
export type GetReceivedDataGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a received data grant.
 */
export declare const getReceivedDataGrant: API.OperationMethod<GetReceivedDataGrantRequest, GetReceivedDataGrantResponse, GetReceivedDataGrantError, Credentials | HttpClient.HttpClient>;
export type GetRevisionError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a revision.
 */
export declare const getRevision: API.OperationMethod<GetRevisionRequest, GetRevisionResponse, GetRevisionError, Credentials | HttpClient.HttpClient>;
export type ListDataGrantsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about all data grants.
 */
export declare const listDataGrants: API.PaginatedOperationMethod<ListDataGrantsRequest, ListDataGrantsResponse, ListDataGrantsError, Credentials | HttpClient.HttpClient, DataGrantSummaryEntry>;
export type ListDataSetRevisionsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists a data set's revisions sorted by CreatedAt in descending order.
 */
export declare const listDataSetRevisions: API.PaginatedOperationMethod<ListDataSetRevisionsRequest, ListDataSetRevisionsResponse, ListDataSetRevisionsError, Credentials | HttpClient.HttpClient, RevisionEntry>;
export type ListDataSetsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists your data sets. When listing by origin OWNED, results are sorted by CreatedAt in descending order. When listing by origin ENTITLED, there is no order.
 */
export declare const listDataSets: API.PaginatedOperationMethod<ListDataSetsRequest, ListDataSetsResponse, ListDataSetsError, Credentials | HttpClient.HttpClient, DataSetEntry>;
export type ListEventActionsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists your event actions.
 */
export declare const listEventActions: API.PaginatedOperationMethod<ListEventActionsRequest, ListEventActionsResponse, ListEventActionsError, Credentials | HttpClient.HttpClient, EventActionEntry>;
export type ListJobsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists your jobs sorted by CreatedAt in descending order.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest, ListJobsResponse, ListJobsError, Credentials | HttpClient.HttpClient, JobEntry>;
export type ListReceivedDataGrantsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about all received data grants.
 */
export declare const listReceivedDataGrants: API.PaginatedOperationMethod<ListReceivedDataGrantsRequest, ListReceivedDataGrantsResponse, ListReceivedDataGrantsError, Credentials | HttpClient.HttpClient, ReceivedDataGrantSummariesEntry>;
export type ListRevisionAssetsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists a revision's assets sorted alphabetically in descending order.
 */
export declare const listRevisionAssets: API.PaginatedOperationMethod<ListRevisionAssetsRequest, ListRevisionAssetsResponse, ListRevisionAssetsError, Credentials | HttpClient.HttpClient, AssetEntry>;
export type ListTagsForResourceError = CommonErrors;
/**
 * This operation lists the tags on the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RevokeRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation revokes subscribers' access to a revision.
 */
export declare const revokeRevision: API.OperationMethod<RevokeRevisionRequest, RevokeRevisionResponse, RevokeRevisionError, Credentials | HttpClient.HttpClient>;
export type SendApiAssetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation invokes an API Gateway API asset. The request is proxied to the provider’s API Gateway API.
 */
export declare const sendApiAsset: API.OperationMethod<SendApiAssetRequest, SendApiAssetResponse, SendApiAssetError, Credentials | HttpClient.HttpClient>;
export type SendDataSetNotificationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The type of event associated with the data set.
 */
export declare const sendDataSetNotification: API.OperationMethod<SendDataSetNotificationRequest, SendDataSetNotificationResponse, SendDataSetNotificationError, Credentials | HttpClient.HttpClient>;
export type StartJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation starts a job.
 */
export declare const startJob: API.OperationMethod<StartJobRequest, StartJobResponse, StartJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * This operation tags a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * This operation removes one or more tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation updates an asset.
 */
export declare const updateAsset: API.OperationMethod<UpdateAssetRequest, UpdateAssetResponse, UpdateAssetError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation updates a data set.
 */
export declare const updateDataSet: API.OperationMethod<UpdateDataSetRequest, UpdateDataSetResponse, UpdateDataSetError, Credentials | HttpClient.HttpClient>;
export type UpdateEventActionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation updates the event action.
 */
export declare const updateEventAction: API.OperationMethod<UpdateEventActionRequest, UpdateEventActionResponse, UpdateEventActionError, Credentials | HttpClient.HttpClient>;
export type UpdateRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation updates a revision.
 */
export declare const updateRevision: API.OperationMethod<UpdateRevisionRequest, UpdateRevisionResponse, UpdateRevisionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=dataexchange.d.ts.map