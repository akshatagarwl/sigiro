import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const FeaturedResultsConflictException_base: S.Class<FeaturedResultsConflictException, S.TaggedStruct<"FeaturedResultsConflictException", {
    readonly message: any;
    readonly ConflictingItems: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class FeaturedResultsConflictException extends /*@__PURE__*/ FeaturedResultsConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ResourceAlreadyExistException_base: S.Class<ResourceAlreadyExistException, S.TaggedStruct<"ResourceAlreadyExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceAlreadyExistException extends /*@__PURE__*/ ResourceAlreadyExistException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceUnavailableException_base: S.Class<ResourceUnavailableException, S.TaggedStruct<"ResourceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceUnavailableException extends /*@__PURE__*/ ResourceUnavailableException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ExperienceId = string;
export type IndexId = string;
export type EntityId = string;
export type EntityType = "USER" | "GROUP" | (string & {});
export declare const EntityType: any;
export interface EntityConfiguration {
    EntityId: string;
    EntityType: EntityType;
}
export declare const EntityConfiguration: S.Schema<EntityConfiguration>;
export type AssociateEntityList = EntityConfiguration[];
export declare const AssociateEntityList: any;
export interface AssociateEntitiesToExperienceRequest {
    Id: string;
    IndexId: string;
    EntityList: EntityConfiguration[];
}
export declare const AssociateEntitiesToExperienceRequest: S.Schema<AssociateEntitiesToExperienceRequest>;
export type ErrorMessage = string;
export interface FailedEntity {
    EntityId?: string;
    ErrorMessage?: string;
}
export declare const FailedEntity: S.Schema<FailedEntity>;
export type AssociateEntitiesToExperienceFailedEntityList = FailedEntity[];
export declare const AssociateEntitiesToExperienceFailedEntityList: any;
export interface AssociateEntitiesToExperienceResponse {
    FailedEntityList?: FailedEntity[];
}
export declare const AssociateEntitiesToExperienceResponse: S.Schema<AssociateEntitiesToExperienceResponse>;
export type Persona = "OWNER" | "VIEWER" | (string & {});
export declare const Persona: any;
export interface EntityPersonaConfiguration {
    EntityId: string;
    Persona: Persona;
}
export declare const EntityPersonaConfiguration: S.Schema<EntityPersonaConfiguration>;
export type EntityPersonaConfigurationList = EntityPersonaConfiguration[];
export declare const EntityPersonaConfigurationList: any;
export interface AssociatePersonasToEntitiesRequest {
    Id: string;
    IndexId: string;
    Personas: EntityPersonaConfiguration[];
}
export declare const AssociatePersonasToEntitiesRequest: S.Schema<AssociatePersonasToEntitiesRequest>;
export type FailedEntityList = FailedEntity[];
export declare const FailedEntityList: any;
export interface AssociatePersonasToEntitiesResponse {
    FailedEntityList?: FailedEntity[];
}
export declare const AssociatePersonasToEntitiesResponse: S.Schema<AssociatePersonasToEntitiesResponse>;
export type DocumentId = string;
export type DocumentIdList = string[];
export declare const DocumentIdList: any;
export type DataSourceId = string;
export type DataSourceSyncJobId = string;
export interface DataSourceSyncJobMetricTarget {
    DataSourceId: string;
    DataSourceSyncJobId?: string;
}
export declare const DataSourceSyncJobMetricTarget: S.Schema<DataSourceSyncJobMetricTarget>;
export interface BatchDeleteDocumentRequest {
    IndexId: string;
    DocumentIdList: string[];
    DataSourceSyncJobMetricTarget?: DataSourceSyncJobMetricTarget;
}
export declare const BatchDeleteDocumentRequest: S.Schema<BatchDeleteDocumentRequest>;
export type ErrorCode = "InternalError" | "InvalidRequest" | (string & {});
export declare const ErrorCode: any;
export interface BatchDeleteDocumentResponseFailedDocument {
    Id?: string;
    DataSourceId?: string;
    ErrorCode?: ErrorCode;
    ErrorMessage?: string;
}
export declare const BatchDeleteDocumentResponseFailedDocument: S.Schema<BatchDeleteDocumentResponseFailedDocument>;
export type BatchDeleteDocumentResponseFailedDocuments = BatchDeleteDocumentResponseFailedDocument[];
export declare const BatchDeleteDocumentResponseFailedDocuments: any;
export interface BatchDeleteDocumentResponse {
    FailedDocuments?: BatchDeleteDocumentResponseFailedDocument[];
}
export declare const BatchDeleteDocumentResponse: S.Schema<BatchDeleteDocumentResponse>;
export type FeaturedResultsSetId = string;
export type FeaturedResultsSetIdList = string[];
export declare const FeaturedResultsSetIdList: any;
export interface BatchDeleteFeaturedResultsSetRequest {
    IndexId: string;
    FeaturedResultsSetIds: string[];
}
export declare const BatchDeleteFeaturedResultsSetRequest: S.Schema<BatchDeleteFeaturedResultsSetRequest>;
export interface BatchDeleteFeaturedResultsSetError_ {
    Id: string;
    ErrorCode: ErrorCode;
    ErrorMessage: string;
}
export declare const BatchDeleteFeaturedResultsSetError_: S.Schema<BatchDeleteFeaturedResultsSetError_>;
export type BatchDeleteFeaturedResultsSetErrors = BatchDeleteFeaturedResultsSetError_[];
export declare const BatchDeleteFeaturedResultsSetErrors: any;
export interface BatchDeleteFeaturedResultsSetResponse {
    Errors: BatchDeleteFeaturedResultsSetError_[];
}
export declare const BatchDeleteFeaturedResultsSetResponse: S.Schema<BatchDeleteFeaturedResultsSetResponse>;
export type DocumentAttributeKey = string;
export type DocumentAttributeStringValue = string;
export type DocumentAttributeStringListValue = string[];
export declare const DocumentAttributeStringListValue: any;
export interface DocumentAttributeValue {
    StringValue?: string;
    StringListValue?: string[];
    LongValue?: number;
    DateValue?: Date;
}
export declare const DocumentAttributeValue: S.Schema<DocumentAttributeValue>;
export interface DocumentAttribute {
    Key: string;
    Value: DocumentAttributeValue;
}
export declare const DocumentAttribute: S.Schema<DocumentAttribute>;
export type DocumentAttributeList = DocumentAttribute[];
export declare const DocumentAttributeList: any;
export interface DocumentInfo {
    DocumentId: string;
    Attributes?: DocumentAttribute[];
}
export declare const DocumentInfo: S.Schema<DocumentInfo>;
export type DocumentInfoList = DocumentInfo[];
export declare const DocumentInfoList: any;
export interface BatchGetDocumentStatusRequest {
    IndexId: string;
    DocumentInfoList: DocumentInfo[];
}
export declare const BatchGetDocumentStatusRequest: S.Schema<BatchGetDocumentStatusRequest>;
export interface BatchGetDocumentStatusResponseError {
    DocumentId?: string;
    DataSourceId?: string;
    ErrorCode?: ErrorCode;
    ErrorMessage?: string;
}
export declare const BatchGetDocumentStatusResponseError: S.Schema<BatchGetDocumentStatusResponseError>;
export type BatchGetDocumentStatusResponseErrors = BatchGetDocumentStatusResponseError[];
export declare const BatchGetDocumentStatusResponseErrors: any;
export type DocumentStatus = "NOT_FOUND" | "PROCESSING" | "INDEXED" | "UPDATED" | "FAILED" | "UPDATE_FAILED" | (string & {});
export declare const DocumentStatus: any;
export interface Status {
    DocumentId?: string;
    DocumentStatus?: DocumentStatus;
    FailureCode?: string;
    FailureReason?: string;
}
export declare const Status: S.Schema<Status>;
export type DocumentStatusList = Status[];
export declare const DocumentStatusList: any;
export interface BatchGetDocumentStatusResponse {
    Errors?: BatchGetDocumentStatusResponseError[];
    DocumentStatusList?: Status[];
}
export declare const BatchGetDocumentStatusResponse: S.Schema<BatchGetDocumentStatusResponse>;
export type RoleArn = string;
export type Title = string;
export type S3BucketName = string;
export type S3ObjectKey = string;
export interface S3Path {
    Bucket: string;
    Key: string;
}
export declare const S3Path: S.Schema<S3Path>;
export type PrincipalName = string;
export type PrincipalType = "USER" | "GROUP" | (string & {});
export declare const PrincipalType: any;
export type ReadAccessType = "ALLOW" | "DENY" | (string & {});
export declare const ReadAccessType: any;
export interface Principal {
    Name: string;
    Type: PrincipalType;
    Access: ReadAccessType;
    DataSourceId?: string;
}
export declare const Principal: S.Schema<Principal>;
export type PrincipalList = Principal[];
export declare const PrincipalList: any;
export interface HierarchicalPrincipal {
    PrincipalList: Principal[];
}
export declare const HierarchicalPrincipal: S.Schema<HierarchicalPrincipal>;
export type HierarchicalPrincipalList = HierarchicalPrincipal[];
export declare const HierarchicalPrincipalList: any;
export type ContentType = "PDF" | "HTML" | "MS_WORD" | "PLAIN_TEXT" | "PPT" | "RTF" | "XML" | "XSLT" | "MS_EXCEL" | "CSV" | "JSON" | "MD" | (string & {});
export declare const ContentType: any;
export type AccessControlConfigurationId = string;
export interface Document {
    Id: string;
    Title?: string;
    Blob?: Uint8Array;
    S3Path?: S3Path;
    Attributes?: DocumentAttribute[];
    AccessControlList?: Principal[];
    HierarchicalAccessControlList?: HierarchicalPrincipal[];
    ContentType?: ContentType;
    AccessControlConfigurationId?: string;
}
export declare const Document: S.Schema<Document>;
export type DocumentList = Document[];
export declare const DocumentList: any;
export type ConditionOperator = "GreaterThan" | "GreaterThanOrEquals" | "LessThan" | "LessThanOrEquals" | "Equals" | "NotEquals" | "Contains" | "NotContains" | "Exists" | "NotExists" | "BeginsWith" | (string & {});
export declare const ConditionOperator: any;
export interface DocumentAttributeCondition {
    ConditionDocumentAttributeKey: string;
    Operator: ConditionOperator;
    ConditionOnValue?: DocumentAttributeValue;
}
export declare const DocumentAttributeCondition: S.Schema<DocumentAttributeCondition>;
export interface DocumentAttributeTarget {
    TargetDocumentAttributeKey?: string;
    TargetDocumentAttributeValueDeletion?: boolean;
    TargetDocumentAttributeValue?: DocumentAttributeValue;
}
export declare const DocumentAttributeTarget: S.Schema<DocumentAttributeTarget>;
export interface InlineCustomDocumentEnrichmentConfiguration {
    Condition?: DocumentAttributeCondition;
    Target?: DocumentAttributeTarget;
    DocumentContentDeletion?: boolean;
}
export declare const InlineCustomDocumentEnrichmentConfiguration: S.Schema<InlineCustomDocumentEnrichmentConfiguration>;
export type InlineCustomDocumentEnrichmentConfigurationList = InlineCustomDocumentEnrichmentConfiguration[];
export declare const InlineCustomDocumentEnrichmentConfigurationList: any;
export type LambdaArn = string;
export interface HookConfiguration {
    InvocationCondition?: DocumentAttributeCondition;
    LambdaArn: string;
    S3Bucket: string;
}
export declare const HookConfiguration: S.Schema<HookConfiguration>;
export interface CustomDocumentEnrichmentConfiguration {
    InlineConfigurations?: InlineCustomDocumentEnrichmentConfiguration[];
    PreExtractionHookConfiguration?: HookConfiguration;
    PostExtractionHookConfiguration?: HookConfiguration;
    RoleArn?: string;
}
export declare const CustomDocumentEnrichmentConfiguration: S.Schema<CustomDocumentEnrichmentConfiguration>;
export interface BatchPutDocumentRequest {
    IndexId: string;
    RoleArn?: string;
    Documents: Document[];
    CustomDocumentEnrichmentConfiguration?: CustomDocumentEnrichmentConfiguration;
}
export declare const BatchPutDocumentRequest: S.Schema<BatchPutDocumentRequest>;
export interface BatchPutDocumentResponseFailedDocument {
    Id?: string;
    DataSourceId?: string;
    ErrorCode?: ErrorCode;
    ErrorMessage?: string;
}
export declare const BatchPutDocumentResponseFailedDocument: S.Schema<BatchPutDocumentResponseFailedDocument>;
export type BatchPutDocumentResponseFailedDocuments = BatchPutDocumentResponseFailedDocument[];
export declare const BatchPutDocumentResponseFailedDocuments: any;
export interface BatchPutDocumentResponse {
    FailedDocuments?: BatchPutDocumentResponseFailedDocument[];
}
export declare const BatchPutDocumentResponse: S.Schema<BatchPutDocumentResponse>;
export interface ClearQuerySuggestionsRequest {
    IndexId: string;
}
export declare const ClearQuerySuggestionsRequest: S.Schema<ClearQuerySuggestionsRequest>;
export interface ClearQuerySuggestionsResponse {
}
export declare const ClearQuerySuggestionsResponse: S.Schema<ClearQuerySuggestionsResponse>;
export type AccessControlConfigurationName = string;
export type Description = string;
export type ClientTokenName = string;
export interface CreateAccessControlConfigurationRequest {
    IndexId: string;
    Name: string;
    Description?: string;
    AccessControlList?: Principal[];
    HierarchicalAccessControlList?: HierarchicalPrincipal[];
    ClientToken?: string;
}
export declare const CreateAccessControlConfigurationRequest: S.Schema<CreateAccessControlConfigurationRequest>;
export interface CreateAccessControlConfigurationResponse {
    Id: string;
}
export declare const CreateAccessControlConfigurationResponse: S.Schema<CreateAccessControlConfigurationResponse>;
export type DataSourceName = string;
export type DataSourceType = "S3" | "SHAREPOINT" | "DATABASE" | "SALESFORCE" | "ONEDRIVE" | "SERVICENOW" | "CUSTOM" | "CONFLUENCE" | "GOOGLEDRIVE" | "WEBCRAWLER" | "WORKDOCS" | "FSX" | "SLACK" | "BOX" | "QUIP" | "JIRA" | "GITHUB" | "ALFRESCO" | "TEMPLATE" | (string & {});
export declare const DataSourceType: any;
export type DataSourceInclusionsExclusionsStringsMember = string;
export type DataSourceInclusionsExclusionsStrings = string[];
export declare const DataSourceInclusionsExclusionsStrings: any;
export interface DocumentsMetadataConfiguration {
    S3Prefix?: string;
}
export declare const DocumentsMetadataConfiguration: S.Schema<DocumentsMetadataConfiguration>;
export interface AccessControlListConfiguration {
    KeyPath?: string;
}
export declare const AccessControlListConfiguration: S.Schema<AccessControlListConfiguration>;
export interface S3DataSourceConfiguration {
    BucketName: string;
    InclusionPrefixes?: string[];
    InclusionPatterns?: string[];
    ExclusionPatterns?: string[];
    DocumentsMetadataConfiguration?: DocumentsMetadataConfiguration;
    AccessControlListConfiguration?: AccessControlListConfiguration;
}
export declare const S3DataSourceConfiguration: S.Schema<S3DataSourceConfiguration>;
export type SharePointVersion = "SHAREPOINT_2013" | "SHAREPOINT_2016" | "SHAREPOINT_ONLINE" | "SHAREPOINT_2019" | (string & {});
export declare const SharePointVersion: any;
export type Url = string;
export type SharePointUrlList = string[];
export declare const SharePointUrlList: any;
export type SecretArn = string;
export type SubnetId = string;
export type SubnetIdList = string[];
export declare const SubnetIdList: any;
export type VpcSecurityGroupId = string;
export type SecurityGroupIdList = string[];
export declare const SecurityGroupIdList: any;
export interface DataSourceVpcConfiguration {
    SubnetIds: string[];
    SecurityGroupIds: string[];
}
export declare const DataSourceVpcConfiguration: S.Schema<DataSourceVpcConfiguration>;
export type DataSourceFieldName = string;
export type DataSourceDateFieldFormat = string;
export type IndexFieldName = string;
export interface DataSourceToIndexFieldMapping {
    DataSourceFieldName: string;
    DateFieldFormat?: string;
    IndexFieldName: string;
}
export declare const DataSourceToIndexFieldMapping: S.Schema<DataSourceToIndexFieldMapping>;
export type DataSourceToIndexFieldMappingList = DataSourceToIndexFieldMapping[];
export declare const DataSourceToIndexFieldMappingList: any;
export type SharePointOnlineAuthenticationType = "HTTP_BASIC" | "OAUTH2" | (string & {});
export declare const SharePointOnlineAuthenticationType: any;
export type Host = string;
export type Port = number;
export interface ProxyConfiguration {
    Host: string;
    Port: number;
    Credentials?: string;
}
export declare const ProxyConfiguration: S.Schema<ProxyConfiguration>;
export interface SharePointConfiguration {
    SharePointVersion: SharePointVersion;
    Urls: string[];
    SecretArn: string;
    CrawlAttachments?: boolean;
    UseChangeLog?: boolean;
    InclusionPatterns?: string[];
    ExclusionPatterns?: string[];
    VpcConfiguration?: DataSourceVpcConfiguration;
    FieldMappings?: DataSourceToIndexFieldMapping[];
    DocumentTitleFieldName?: string;
    DisableLocalGroups?: boolean;
    SslCertificateS3Path?: S3Path;
    AuthenticationType?: SharePointOnlineAuthenticationType;
    ProxyConfiguration?: ProxyConfiguration;
}
export declare const SharePointConfiguration: S.Schema<SharePointConfiguration>;
export type DatabaseEngineType = "RDS_AURORA_MYSQL" | "RDS_AURORA_POSTGRESQL" | "RDS_MYSQL" | "RDS_POSTGRESQL" | (string & {});
export declare const DatabaseEngineType: any;
export type DatabaseHost = string;
export type DatabasePort = number;
export type DatabaseName = string;
export type TableName = string;
export interface ConnectionConfiguration {
    DatabaseHost: string;
    DatabasePort: number;
    DatabaseName: string;
    TableName: string;
    SecretArn: string;
}
export declare const ConnectionConfiguration: S.Schema<ConnectionConfiguration>;
export type ColumnName = string;
export type ChangeDetectingColumns = string[];
export declare const ChangeDetectingColumns: any;
export interface ColumnConfiguration {
    DocumentIdColumnName: string;
    DocumentDataColumnName: string;
    DocumentTitleColumnName?: string;
    FieldMappings?: DataSourceToIndexFieldMapping[];
    ChangeDetectingColumns: string[];
}
export declare const ColumnConfiguration: S.Schema<ColumnConfiguration>;
export interface AclConfiguration {
    AllowedGroupsColumnName: string;
}
export declare const AclConfiguration: S.Schema<AclConfiguration>;
export type QueryIdentifiersEnclosingOption = "DOUBLE_QUOTES" | "NONE" | (string & {});
export declare const QueryIdentifiersEnclosingOption: any;
export interface SqlConfiguration {
    QueryIdentifiersEnclosingOption?: QueryIdentifiersEnclosingOption;
}
export declare const SqlConfiguration: S.Schema<SqlConfiguration>;
export interface DatabaseConfiguration {
    DatabaseEngineType: DatabaseEngineType;
    ConnectionConfiguration: ConnectionConfiguration;
    VpcConfiguration?: DataSourceVpcConfiguration;
    ColumnConfiguration: ColumnConfiguration;
    AclConfiguration?: AclConfiguration;
    SqlConfiguration?: SqlConfiguration;
}
export declare const DatabaseConfiguration: S.Schema<DatabaseConfiguration>;
export type SalesforceStandardObjectName = "ACCOUNT" | "CAMPAIGN" | "CASE" | "CONTACT" | "CONTRACT" | "DOCUMENT" | "GROUP" | "IDEA" | "LEAD" | "OPPORTUNITY" | "PARTNER" | "PRICEBOOK" | "PRODUCT" | "PROFILE" | "SOLUTION" | "TASK" | "USER" | (string & {});
export declare const SalesforceStandardObjectName: any;
export interface SalesforceStandardObjectConfiguration {
    Name: SalesforceStandardObjectName;
    DocumentDataFieldName: string;
    DocumentTitleFieldName?: string;
    FieldMappings?: DataSourceToIndexFieldMapping[];
}
export declare const SalesforceStandardObjectConfiguration: S.Schema<SalesforceStandardObjectConfiguration>;
export type SalesforceStandardObjectConfigurationList = SalesforceStandardObjectConfiguration[];
export declare const SalesforceStandardObjectConfigurationList: any;
export type SalesforceKnowledgeArticleState = "DRAFT" | "PUBLISHED" | "ARCHIVED" | (string & {});
export declare const SalesforceKnowledgeArticleState: any;
export type SalesforceKnowledgeArticleStateList = SalesforceKnowledgeArticleState[];
export declare const SalesforceKnowledgeArticleStateList: any;
export interface SalesforceStandardKnowledgeArticleTypeConfiguration {
    DocumentDataFieldName: string;
    DocumentTitleFieldName?: string;
    FieldMappings?: DataSourceToIndexFieldMapping[];
}
export declare const SalesforceStandardKnowledgeArticleTypeConfiguration: S.Schema<SalesforceStandardKnowledgeArticleTypeConfiguration>;
export type SalesforceCustomKnowledgeArticleTypeName = string;
export interface SalesforceCustomKnowledgeArticleTypeConfiguration {
    Name: string;
    DocumentDataFieldName: string;
    DocumentTitleFieldName?: string;
    FieldMappings?: DataSourceToIndexFieldMapping[];
}
export declare const SalesforceCustomKnowledgeArticleTypeConfiguration: S.Schema<SalesforceCustomKnowledgeArticleTypeConfiguration>;
export type SalesforceCustomKnowledgeArticleTypeConfigurationList = SalesforceCustomKnowledgeArticleTypeConfiguration[];
export declare const SalesforceCustomKnowledgeArticleTypeConfigurationList: any;
export interface SalesforceKnowledgeArticleConfiguration {
    IncludedStates: SalesforceKnowledgeArticleState[];
    StandardKnowledgeArticleTypeConfiguration?: SalesforceStandardKnowledgeArticleTypeConfiguration;
    CustomKnowledgeArticleTypeConfigurations?: SalesforceCustomKnowledgeArticleTypeConfiguration[];
}
export declare const SalesforceKnowledgeArticleConfiguration: S.Schema<SalesforceKnowledgeArticleConfiguration>;
export type SalesforceChatterFeedIncludeFilterType = "ACTIVE_USER" | "STANDARD_USER" | (string & {});
export declare const SalesforceChatterFeedIncludeFilterType: any;
export type SalesforceChatterFeedIncludeFilterTypes = SalesforceChatterFeedIncludeFilterType[];
export declare const SalesforceChatterFeedIncludeFilterTypes: any;
export interface SalesforceChatterFeedConfiguration {
    DocumentDataFieldName: string;
    DocumentTitleFieldName?: string;
    FieldMappings?: DataSourceToIndexFieldMapping[];
    IncludeFilterTypes?: SalesforceChatterFeedIncludeFilterType[];
}
export declare const SalesforceChatterFeedConfiguration: S.Schema<SalesforceChatterFeedConfiguration>;
export interface SalesforceStandardObjectAttachmentConfiguration {
    DocumentTitleFieldName?: string;
    FieldMappings?: DataSourceToIndexFieldMapping[];
}
export declare const SalesforceStandardObjectAttachmentConfiguration: S.Schema<SalesforceStandardObjectAttachmentConfiguration>;
export interface SalesforceConfiguration {
    ServerUrl: string;
    SecretArn: string;
    StandardObjectConfigurations?: SalesforceStandardObjectConfiguration[];
    KnowledgeArticleConfiguration?: SalesforceKnowledgeArticleConfiguration;
    ChatterFeedConfiguration?: SalesforceChatterFeedConfiguration;
    CrawlAttachments?: boolean;
    StandardObjectAttachmentConfiguration?: SalesforceStandardObjectAttachmentConfiguration;
    IncludeAttachmentFilePatterns?: string[];
    ExcludeAttachmentFilePatterns?: string[];
}
export declare const SalesforceConfiguration: S.Schema<SalesforceConfiguration>;
export type TenantDomain = string;
export type OneDriveUser = string;
export type OneDriveUserList = string[];
export declare const OneDriveUserList: any;
export interface OneDriveUsers {
    OneDriveUserList?: string[];
    OneDriveUserS3Path?: S3Path;
}
export declare const OneDriveUsers: S.Schema<OneDriveUsers>;
export interface OneDriveConfiguration {
    TenantDomain: string;
    SecretArn: string;
    OneDriveUsers: OneDriveUsers;
    InclusionPatterns?: string[];
    ExclusionPatterns?: string[];
    FieldMappings?: DataSourceToIndexFieldMapping[];
    DisableLocalGroups?: boolean;
}
export declare const OneDriveConfiguration: S.Schema<OneDriveConfiguration>;
export type ServiceNowHostUrl = string;
export type ServiceNowBuildVersionType = "LONDON" | "OTHERS" | (string & {});
export declare const ServiceNowBuildVersionType: any;
export type ServiceNowKnowledgeArticleFilterQuery = string;
export interface ServiceNowKnowledgeArticleConfiguration {
    CrawlAttachments?: boolean;
    IncludeAttachmentFilePatterns?: string[];
    ExcludeAttachmentFilePatterns?: string[];
    DocumentDataFieldName: string;
    DocumentTitleFieldName?: string;
    FieldMappings?: DataSourceToIndexFieldMapping[];
    FilterQuery?: string;
}
export declare const ServiceNowKnowledgeArticleConfiguration: S.Schema<ServiceNowKnowledgeArticleConfiguration>;
export interface ServiceNowServiceCatalogConfiguration {
    CrawlAttachments?: boolean;
    IncludeAttachmentFilePatterns?: string[];
    ExcludeAttachmentFilePatterns?: string[];
    DocumentDataFieldName: string;
    DocumentTitleFieldName?: string;
    FieldMappings?: DataSourceToIndexFieldMapping[];
}
export declare const ServiceNowServiceCatalogConfiguration: S.Schema<ServiceNowServiceCatalogConfiguration>;
export type ServiceNowAuthenticationType = "HTTP_BASIC" | "OAUTH2" | (string & {});
export declare const ServiceNowAuthenticationType: any;
export interface ServiceNowConfiguration {
    HostUrl: string;
    SecretArn: string;
    ServiceNowBuildVersion: ServiceNowBuildVersionType;
    KnowledgeArticleConfiguration?: ServiceNowKnowledgeArticleConfiguration;
    ServiceCatalogConfiguration?: ServiceNowServiceCatalogConfiguration;
    AuthenticationType?: ServiceNowAuthenticationType;
}
export declare const ServiceNowConfiguration: S.Schema<ServiceNowConfiguration>;
export type ConfluenceVersion = "CLOUD" | "SERVER" | (string & {});
export declare const ConfluenceVersion: any;
export type ConfluenceSpaceIdentifier = string;
export type ConfluenceSpaceList = string[];
export declare const ConfluenceSpaceList: any;
export type ConfluenceSpaceFieldName = "DISPLAY_URL" | "ITEM_TYPE" | "SPACE_KEY" | "URL" | (string & {});
export declare const ConfluenceSpaceFieldName: any;
export interface ConfluenceSpaceToIndexFieldMapping {
    DataSourceFieldName?: ConfluenceSpaceFieldName;
    DateFieldFormat?: string;
    IndexFieldName?: string;
}
export declare const ConfluenceSpaceToIndexFieldMapping: S.Schema<ConfluenceSpaceToIndexFieldMapping>;
export type ConfluenceSpaceFieldMappingsList = ConfluenceSpaceToIndexFieldMapping[];
export declare const ConfluenceSpaceFieldMappingsList: any;
export interface ConfluenceSpaceConfiguration {
    CrawlPersonalSpaces?: boolean;
    CrawlArchivedSpaces?: boolean;
    IncludeSpaces?: string[];
    ExcludeSpaces?: string[];
    SpaceFieldMappings?: ConfluenceSpaceToIndexFieldMapping[];
}
export declare const ConfluenceSpaceConfiguration: S.Schema<ConfluenceSpaceConfiguration>;
export type ConfluencePageFieldName = "AUTHOR" | "CONTENT_STATUS" | "CREATED_DATE" | "DISPLAY_URL" | "ITEM_TYPE" | "LABELS" | "MODIFIED_DATE" | "PARENT_ID" | "SPACE_KEY" | "SPACE_NAME" | "URL" | "VERSION" | (string & {});
export declare const ConfluencePageFieldName: any;
export interface ConfluencePageToIndexFieldMapping {
    DataSourceFieldName?: ConfluencePageFieldName;
    DateFieldFormat?: string;
    IndexFieldName?: string;
}
export declare const ConfluencePageToIndexFieldMapping: S.Schema<ConfluencePageToIndexFieldMapping>;
export type ConfluencePageFieldMappingsList = ConfluencePageToIndexFieldMapping[];
export declare const ConfluencePageFieldMappingsList: any;
export interface ConfluencePageConfiguration {
    PageFieldMappings?: ConfluencePageToIndexFieldMapping[];
}
export declare const ConfluencePageConfiguration: S.Schema<ConfluencePageConfiguration>;
export type ConfluenceBlogFieldName = "AUTHOR" | "DISPLAY_URL" | "ITEM_TYPE" | "LABELS" | "PUBLISH_DATE" | "SPACE_KEY" | "SPACE_NAME" | "URL" | "VERSION" | (string & {});
export declare const ConfluenceBlogFieldName: any;
export interface ConfluenceBlogToIndexFieldMapping {
    DataSourceFieldName?: ConfluenceBlogFieldName;
    DateFieldFormat?: string;
    IndexFieldName?: string;
}
export declare const ConfluenceBlogToIndexFieldMapping: S.Schema<ConfluenceBlogToIndexFieldMapping>;
export type ConfluenceBlogFieldMappingsList = ConfluenceBlogToIndexFieldMapping[];
export declare const ConfluenceBlogFieldMappingsList: any;
export interface ConfluenceBlogConfiguration {
    BlogFieldMappings?: ConfluenceBlogToIndexFieldMapping[];
}
export declare const ConfluenceBlogConfiguration: S.Schema<ConfluenceBlogConfiguration>;
export type ConfluenceAttachmentFieldName = "AUTHOR" | "CONTENT_TYPE" | "CREATED_DATE" | "DISPLAY_URL" | "FILE_SIZE" | "ITEM_TYPE" | "PARENT_ID" | "SPACE_KEY" | "SPACE_NAME" | "URL" | "VERSION" | (string & {});
export declare const ConfluenceAttachmentFieldName: any;
export interface ConfluenceAttachmentToIndexFieldMapping {
    DataSourceFieldName?: ConfluenceAttachmentFieldName;
    DateFieldFormat?: string;
    IndexFieldName?: string;
}
export declare const ConfluenceAttachmentToIndexFieldMapping: S.Schema<ConfluenceAttachmentToIndexFieldMapping>;
export type ConfluenceAttachmentFieldMappingsList = ConfluenceAttachmentToIndexFieldMapping[];
export declare const ConfluenceAttachmentFieldMappingsList: any;
export interface ConfluenceAttachmentConfiguration {
    CrawlAttachments?: boolean;
    AttachmentFieldMappings?: ConfluenceAttachmentToIndexFieldMapping[];
}
export declare const ConfluenceAttachmentConfiguration: S.Schema<ConfluenceAttachmentConfiguration>;
export type ConfluenceAuthenticationType = "HTTP_BASIC" | "PAT" | (string & {});
export declare const ConfluenceAuthenticationType: any;
export interface ConfluenceConfiguration {
    ServerUrl: string;
    SecretArn: string;
    Version: ConfluenceVersion;
    SpaceConfiguration?: ConfluenceSpaceConfiguration;
    PageConfiguration?: ConfluencePageConfiguration;
    BlogConfiguration?: ConfluenceBlogConfiguration;
    AttachmentConfiguration?: ConfluenceAttachmentConfiguration;
    VpcConfiguration?: DataSourceVpcConfiguration;
    InclusionPatterns?: string[];
    ExclusionPatterns?: string[];
    ProxyConfiguration?: ProxyConfiguration;
    AuthenticationType?: ConfluenceAuthenticationType;
}
export declare const ConfluenceConfiguration: S.Schema<ConfluenceConfiguration>;
export type MimeType = string;
export type ExcludeMimeTypesList = string[];
export declare const ExcludeMimeTypesList: any;
export type UserAccount = string;
export type ExcludeUserAccountsList = string[];
export declare const ExcludeUserAccountsList: any;
export type SharedDriveId = string;
export type ExcludeSharedDrivesList = string[];
export declare const ExcludeSharedDrivesList: any;
export interface GoogleDriveConfiguration {
    SecretArn: string;
    InclusionPatterns?: string[];
    ExclusionPatterns?: string[];
    FieldMappings?: DataSourceToIndexFieldMapping[];
    ExcludeMimeTypes?: string[];
    ExcludeUserAccounts?: string[];
    ExcludeSharedDrives?: string[];
}
export declare const GoogleDriveConfiguration: S.Schema<GoogleDriveConfiguration>;
export type SeedUrl = string;
export type SeedUrlList = string[];
export declare const SeedUrlList: any;
export type WebCrawlerMode = "HOST_ONLY" | "SUBDOMAINS" | "EVERYTHING" | (string & {});
export declare const WebCrawlerMode: any;
export interface SeedUrlConfiguration {
    SeedUrls: string[];
    WebCrawlerMode?: WebCrawlerMode;
}
export declare const SeedUrlConfiguration: S.Schema<SeedUrlConfiguration>;
export type SiteMap = string;
export type SiteMapsList = string[];
export declare const SiteMapsList: any;
export interface SiteMapsConfiguration {
    SiteMaps: string[];
}
export declare const SiteMapsConfiguration: S.Schema<SiteMapsConfiguration>;
export interface Urls {
    SeedUrlConfiguration?: SeedUrlConfiguration;
    SiteMapsConfiguration?: SiteMapsConfiguration;
}
export declare const Urls: S.Schema<Urls>;
export type CrawlDepth = number;
export type MaxLinksPerPage = number;
export type MaxContentSizePerPageInMegaBytes = number;
export type MaxUrlsPerMinuteCrawlRate = number;
export interface BasicAuthenticationConfiguration {
    Host: string;
    Port: number;
    Credentials: string;
}
export declare const BasicAuthenticationConfiguration: S.Schema<BasicAuthenticationConfiguration>;
export type BasicAuthenticationConfigurationList = BasicAuthenticationConfiguration[];
export declare const BasicAuthenticationConfigurationList: any;
export interface AuthenticationConfiguration {
    BasicAuthentication?: BasicAuthenticationConfiguration[];
}
export declare const AuthenticationConfiguration: S.Schema<AuthenticationConfiguration>;
export interface WebCrawlerConfiguration {
    Urls: Urls;
    CrawlDepth?: number;
    MaxLinksPerPage?: number;
    MaxContentSizePerPageInMegaBytes?: number;
    MaxUrlsPerMinuteCrawlRate?: number;
    UrlInclusionPatterns?: string[];
    UrlExclusionPatterns?: string[];
    ProxyConfiguration?: ProxyConfiguration;
    AuthenticationConfiguration?: AuthenticationConfiguration;
}
export declare const WebCrawlerConfiguration: S.Schema<WebCrawlerConfiguration>;
export type OrganizationId = string;
export interface WorkDocsConfiguration {
    OrganizationId: string;
    CrawlComments?: boolean;
    UseChangeLog?: boolean;
    InclusionPatterns?: string[];
    ExclusionPatterns?: string[];
    FieldMappings?: DataSourceToIndexFieldMapping[];
}
export declare const WorkDocsConfiguration: S.Schema<WorkDocsConfiguration>;
export type FileSystemId = string;
export type FsxFileSystemType = "WINDOWS" | (string & {});
export declare const FsxFileSystemType: any;
export interface FsxConfiguration {
    FileSystemId: string;
    FileSystemType: FsxFileSystemType;
    VpcConfiguration: DataSourceVpcConfiguration;
    SecretArn?: string;
    InclusionPatterns?: string[];
    ExclusionPatterns?: string[];
    FieldMappings?: DataSourceToIndexFieldMapping[];
}
export declare const FsxConfiguration: S.Schema<FsxConfiguration>;
export type TeamId = string;
export type SlackEntity = "PUBLIC_CHANNEL" | "PRIVATE_CHANNEL" | "GROUP_MESSAGE" | "DIRECT_MESSAGE" | (string & {});
export declare const SlackEntity: any;
export type SlackEntityList = SlackEntity[];
export declare const SlackEntityList: any;
export type SinceCrawlDate = string;
export type LookBackPeriod = number;
export type PrivateChannelFilter = string[];
export declare const PrivateChannelFilter: any;
export type PublicChannelFilter = string[];
export declare const PublicChannelFilter: any;
export interface SlackConfiguration {
    TeamId: string;
    SecretArn: string;
    VpcConfiguration?: DataSourceVpcConfiguration;
    SlackEntityList: SlackEntity[];
    UseChangeLog?: boolean;
    CrawlBotMessage?: boolean;
    ExcludeArchived?: boolean;
    SinceCrawlDate: string;
    LookBackPeriod?: number;
    PrivateChannelFilter?: string[];
    PublicChannelFilter?: string[];
    InclusionPatterns?: string[];
    ExclusionPatterns?: string[];
    FieldMappings?: DataSourceToIndexFieldMapping[];
}
export declare const SlackConfiguration: S.Schema<SlackConfiguration>;
export type EnterpriseId = string;
export interface BoxConfiguration {
    EnterpriseId: string;
    SecretArn: string;
    UseChangeLog?: boolean;
    CrawlComments?: boolean;
    CrawlTasks?: boolean;
    CrawlWebLinks?: boolean;
    FileFieldMappings?: DataSourceToIndexFieldMapping[];
    TaskFieldMappings?: DataSourceToIndexFieldMapping[];
    CommentFieldMappings?: DataSourceToIndexFieldMapping[];
    WebLinkFieldMappings?: DataSourceToIndexFieldMapping[];
    InclusionPatterns?: string[];
    ExclusionPatterns?: string[];
    VpcConfiguration?: DataSourceVpcConfiguration;
}
export declare const BoxConfiguration: S.Schema<BoxConfiguration>;
export type Domain = string;
export type FolderId = string;
export type FolderIdList = string[];
export declare const FolderIdList: any;
export interface QuipConfiguration {
    Domain: string;
    SecretArn: string;
    CrawlFileComments?: boolean;
    CrawlChatRooms?: boolean;
    CrawlAttachments?: boolean;
    FolderIds?: string[];
    ThreadFieldMappings?: DataSourceToIndexFieldMapping[];
    MessageFieldMappings?: DataSourceToIndexFieldMapping[];
    AttachmentFieldMappings?: DataSourceToIndexFieldMapping[];
    InclusionPatterns?: string[];
    ExclusionPatterns?: string[];
    VpcConfiguration?: DataSourceVpcConfiguration;
}
export declare const QuipConfiguration: S.Schema<QuipConfiguration>;
export type JiraAccountUrl = string;
export type Project = string[];
export declare const Project: any;
export type IssueType = string[];
export declare const IssueType: any;
export type JiraStatus = string[];
export declare const JiraStatus: any;
export type IssueSubEntity = "COMMENTS" | "ATTACHMENTS" | "WORKLOGS" | (string & {});
export declare const IssueSubEntity: any;
export type IssueSubEntityFilter = IssueSubEntity[];
export declare const IssueSubEntityFilter: any;
export interface JiraConfiguration {
    JiraAccountUrl: string;
    SecretArn: string;
    UseChangeLog?: boolean;
    Project?: string[];
    IssueType?: string[];
    Status?: string[];
    IssueSubEntityFilter?: IssueSubEntity[];
    AttachmentFieldMappings?: DataSourceToIndexFieldMapping[];
    CommentFieldMappings?: DataSourceToIndexFieldMapping[];
    IssueFieldMappings?: DataSourceToIndexFieldMapping[];
    ProjectFieldMappings?: DataSourceToIndexFieldMapping[];
    WorkLogFieldMappings?: DataSourceToIndexFieldMapping[];
    InclusionPatterns?: string[];
    ExclusionPatterns?: string[];
    VpcConfiguration?: DataSourceVpcConfiguration;
}
export declare const JiraConfiguration: S.Schema<JiraConfiguration>;
export type OrganizationName = string;
export interface SaaSConfiguration {
    OrganizationName: string;
    HostUrl: string;
}
export declare const SaaSConfiguration: S.Schema<SaaSConfiguration>;
export interface OnPremiseConfiguration {
    HostUrl: string;
    OrganizationName: string;
    SslCertificateS3Path: S3Path;
}
export declare const OnPremiseConfiguration: S.Schema<OnPremiseConfiguration>;
export type Type = "SAAS" | "ON_PREMISE" | (string & {});
export declare const Type: any;
export interface GitHubDocumentCrawlProperties {
    CrawlRepositoryDocuments?: boolean;
    CrawlIssue?: boolean;
    CrawlIssueComment?: boolean;
    CrawlIssueCommentAttachment?: boolean;
    CrawlPullRequest?: boolean;
    CrawlPullRequestComment?: boolean;
    CrawlPullRequestCommentAttachment?: boolean;
}
export declare const GitHubDocumentCrawlProperties: S.Schema<GitHubDocumentCrawlProperties>;
export type RepositoryName = string;
export type RepositoryNames = string[];
export declare const RepositoryNames: any;
export type StringList = string[];
export declare const StringList: any;
export interface GitHubConfiguration {
    SaaSConfiguration?: SaaSConfiguration;
    OnPremiseConfiguration?: OnPremiseConfiguration;
    Type?: Type;
    SecretArn: string;
    UseChangeLog?: boolean;
    GitHubDocumentCrawlProperties?: GitHubDocumentCrawlProperties;
    RepositoryFilter?: string[];
    InclusionFolderNamePatterns?: string[];
    InclusionFileTypePatterns?: string[];
    InclusionFileNamePatterns?: string[];
    ExclusionFolderNamePatterns?: string[];
    ExclusionFileTypePatterns?: string[];
    ExclusionFileNamePatterns?: string[];
    VpcConfiguration?: DataSourceVpcConfiguration;
    GitHubRepositoryConfigurationFieldMappings?: DataSourceToIndexFieldMapping[];
    GitHubCommitConfigurationFieldMappings?: DataSourceToIndexFieldMapping[];
    GitHubIssueDocumentConfigurationFieldMappings?: DataSourceToIndexFieldMapping[];
    GitHubIssueCommentConfigurationFieldMappings?: DataSourceToIndexFieldMapping[];
    GitHubIssueAttachmentConfigurationFieldMappings?: DataSourceToIndexFieldMapping[];
    GitHubPullRequestCommentConfigurationFieldMappings?: DataSourceToIndexFieldMapping[];
    GitHubPullRequestDocumentConfigurationFieldMappings?: DataSourceToIndexFieldMapping[];
    GitHubPullRequestDocumentAttachmentConfigurationFieldMappings?: DataSourceToIndexFieldMapping[];
}
export declare const GitHubConfiguration: S.Schema<GitHubConfiguration>;
export type SiteUrl = string;
export type SiteId = string;
export type AlfrescoEntity = "wiki" | "blog" | "documentLibrary" | (string & {});
export declare const AlfrescoEntity: any;
export type EntityFilter = AlfrescoEntity[];
export declare const EntityFilter: any;
export interface AlfrescoConfiguration {
    SiteUrl: string;
    SiteId: string;
    SecretArn: string;
    SslCertificateS3Path: S3Path;
    CrawlSystemFolders?: boolean;
    CrawlComments?: boolean;
    EntityFilter?: AlfrescoEntity[];
    DocumentLibraryFieldMappings?: DataSourceToIndexFieldMapping[];
    BlogFieldMappings?: DataSourceToIndexFieldMapping[];
    WikiFieldMappings?: DataSourceToIndexFieldMapping[];
    InclusionPatterns?: string[];
    ExclusionPatterns?: string[];
    VpcConfiguration?: DataSourceVpcConfiguration;
}
export declare const AlfrescoConfiguration: S.Schema<AlfrescoConfiguration>;
export type Template = unknown;
export interface TemplateConfiguration {
    Template?: any;
}
export declare const TemplateConfiguration: S.Schema<TemplateConfiguration>;
export interface DataSourceConfiguration {
    S3Configuration?: S3DataSourceConfiguration;
    SharePointConfiguration?: SharePointConfiguration;
    DatabaseConfiguration?: DatabaseConfiguration;
    SalesforceConfiguration?: SalesforceConfiguration;
    OneDriveConfiguration?: OneDriveConfiguration;
    ServiceNowConfiguration?: ServiceNowConfiguration;
    ConfluenceConfiguration?: ConfluenceConfiguration;
    GoogleDriveConfiguration?: GoogleDriveConfiguration;
    WebCrawlerConfiguration?: WebCrawlerConfiguration;
    WorkDocsConfiguration?: WorkDocsConfiguration;
    FsxConfiguration?: FsxConfiguration;
    SlackConfiguration?: SlackConfiguration;
    BoxConfiguration?: BoxConfiguration;
    QuipConfiguration?: QuipConfiguration;
    JiraConfiguration?: JiraConfiguration;
    GitHubConfiguration?: GitHubConfiguration;
    AlfrescoConfiguration?: AlfrescoConfiguration;
    TemplateConfiguration?: TemplateConfiguration;
}
export declare const DataSourceConfiguration: S.Schema<DataSourceConfiguration>;
export type ScanSchedule = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type LanguageCode = string;
export interface CreateDataSourceRequest {
    Name: string;
    IndexId: string;
    Type: DataSourceType;
    Configuration?: DataSourceConfiguration;
    VpcConfiguration?: DataSourceVpcConfiguration;
    Description?: string;
    Schedule?: string;
    RoleArn?: string;
    Tags?: Tag[];
    ClientToken?: string;
    LanguageCode?: string;
    CustomDocumentEnrichmentConfiguration?: CustomDocumentEnrichmentConfiguration;
}
export declare const CreateDataSourceRequest: S.Schema<CreateDataSourceRequest>;
export interface CreateDataSourceResponse {
    Id: string;
}
export declare const CreateDataSourceResponse: S.Schema<CreateDataSourceResponse>;
export type ExperienceName = string;
export type DataSourceIdList = string[];
export declare const DataSourceIdList: any;
export type FaqId = string;
export type FaqIdsList = string[];
export declare const FaqIdsList: any;
export interface ContentSourceConfiguration {
    DataSourceIds?: string[];
    FaqIds?: string[];
    DirectPutContent?: boolean;
}
export declare const ContentSourceConfiguration: S.Schema<ContentSourceConfiguration>;
export type IdentityAttributeName = string;
export interface UserIdentityConfiguration {
    IdentityAttributeName?: string;
}
export declare const UserIdentityConfiguration: S.Schema<UserIdentityConfiguration>;
export interface ExperienceConfiguration {
    ContentSourceConfiguration?: ContentSourceConfiguration;
    UserIdentityConfiguration?: UserIdentityConfiguration;
}
export declare const ExperienceConfiguration: S.Schema<ExperienceConfiguration>;
export interface CreateExperienceRequest {
    Name: string;
    IndexId: string;
    RoleArn?: string;
    Configuration?: ExperienceConfiguration;
    Description?: string;
    ClientToken?: string;
}
export declare const CreateExperienceRequest: S.Schema<CreateExperienceRequest>;
export interface CreateExperienceResponse {
    Id: string;
}
export declare const CreateExperienceResponse: S.Schema<CreateExperienceResponse>;
export type FaqName = string;
export type FaqFileFormat = "CSV" | "CSV_WITH_HEADER" | "JSON" | (string & {});
export declare const FaqFileFormat: any;
export interface CreateFaqRequest {
    IndexId: string;
    Name: string;
    Description?: string;
    S3Path: S3Path;
    RoleArn: string;
    Tags?: Tag[];
    FileFormat?: FaqFileFormat;
    ClientToken?: string;
    LanguageCode?: string;
}
export declare const CreateFaqRequest: S.Schema<CreateFaqRequest>;
export interface CreateFaqResponse {
    Id?: string;
}
export declare const CreateFaqResponse: S.Schema<CreateFaqResponse>;
export type FeaturedResultsSetName = string;
export type FeaturedResultsSetDescription = string;
export type FeaturedResultsSetStatus = "ACTIVE" | "INACTIVE" | (string & {});
export declare const FeaturedResultsSetStatus: any;
export type QueryText = string;
export type QueryTextList = string[];
export declare const QueryTextList: any;
export interface FeaturedDocument {
    Id?: string;
}
export declare const FeaturedDocument: S.Schema<FeaturedDocument>;
export type FeaturedDocumentList = FeaturedDocument[];
export declare const FeaturedDocumentList: any;
export interface CreateFeaturedResultsSetRequest {
    IndexId: string;
    FeaturedResultsSetName: string;
    Description?: string;
    ClientToken?: string;
    Status?: FeaturedResultsSetStatus;
    QueryTexts?: string[];
    FeaturedDocuments?: FeaturedDocument[];
    Tags?: Tag[];
}
export declare const CreateFeaturedResultsSetRequest: S.Schema<CreateFeaturedResultsSetRequest>;
export interface FeaturedResultsSet {
    FeaturedResultsSetId?: string;
    FeaturedResultsSetName?: string;
    Description?: string;
    Status?: FeaturedResultsSetStatus;
    QueryTexts?: string[];
    FeaturedDocuments?: FeaturedDocument[];
    LastUpdatedTimestamp?: number;
    CreationTimestamp?: number;
}
export declare const FeaturedResultsSet: S.Schema<FeaturedResultsSet>;
export interface CreateFeaturedResultsSetResponse {
    FeaturedResultsSet?: FeaturedResultsSet;
}
export declare const CreateFeaturedResultsSetResponse: S.Schema<CreateFeaturedResultsSetResponse>;
export type IndexName = string;
export type IndexEdition = "DEVELOPER_EDITION" | "ENTERPRISE_EDITION" | "GEN_AI_ENTERPRISE_EDITION" | (string & {});
export declare const IndexEdition: any;
export type KmsKeyId = string | redacted.Redacted<string>;
export interface ServerSideEncryptionConfiguration {
    KmsKeyId?: string | redacted.Redacted<string>;
}
export declare const ServerSideEncryptionConfiguration: S.Schema<ServerSideEncryptionConfiguration>;
export type KeyLocation = "URL" | "SECRET_MANAGER" | (string & {});
export declare const KeyLocation: any;
export type UserNameAttributeField = string;
export type GroupAttributeField = string;
export type Issuer = string;
export type ClaimRegex = string;
export interface JwtTokenTypeConfiguration {
    KeyLocation: KeyLocation;
    URL?: string;
    SecretManagerArn?: string;
    UserNameAttributeField?: string;
    GroupAttributeField?: string;
    Issuer?: string;
    ClaimRegex?: string;
}
export declare const JwtTokenTypeConfiguration: S.Schema<JwtTokenTypeConfiguration>;
export interface JsonTokenTypeConfiguration {
    UserNameAttributeField: string;
    GroupAttributeField: string;
}
export declare const JsonTokenTypeConfiguration: S.Schema<JsonTokenTypeConfiguration>;
export interface UserTokenConfiguration {
    JwtTokenTypeConfiguration?: JwtTokenTypeConfiguration;
    JsonTokenTypeConfiguration?: JsonTokenTypeConfiguration;
}
export declare const UserTokenConfiguration: S.Schema<UserTokenConfiguration>;
export type UserTokenConfigurationList = UserTokenConfiguration[];
export declare const UserTokenConfigurationList: any;
export type UserContextPolicy = "ATTRIBUTE_FILTER" | "USER_TOKEN" | (string & {});
export declare const UserContextPolicy: any;
export type UserGroupResolutionMode = "AWS_SSO" | "NONE" | (string & {});
export declare const UserGroupResolutionMode: any;
export interface UserGroupResolutionConfiguration {
    UserGroupResolutionMode: UserGroupResolutionMode;
}
export declare const UserGroupResolutionConfiguration: S.Schema<UserGroupResolutionConfiguration>;
export interface CreateIndexRequest {
    Name: string;
    Edition?: IndexEdition;
    RoleArn: string;
    ServerSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    Description?: string;
    ClientToken?: string;
    Tags?: Tag[];
    UserTokenConfigurations?: UserTokenConfiguration[];
    UserContextPolicy?: UserContextPolicy;
    UserGroupResolutionConfiguration?: UserGroupResolutionConfiguration;
}
export declare const CreateIndexRequest: S.Schema<CreateIndexRequest>;
export interface CreateIndexResponse {
    Id?: string;
}
export declare const CreateIndexResponse: S.Schema<CreateIndexResponse>;
export type QuerySuggestionsBlockListName = string;
export interface CreateQuerySuggestionsBlockListRequest {
    IndexId: string;
    Name: string;
    Description?: string;
    SourceS3Path: S3Path;
    ClientToken?: string;
    RoleArn: string;
    Tags?: Tag[];
}
export declare const CreateQuerySuggestionsBlockListRequest: S.Schema<CreateQuerySuggestionsBlockListRequest>;
export type QuerySuggestionsBlockListId = string;
export interface CreateQuerySuggestionsBlockListResponse {
    Id?: string;
}
export declare const CreateQuerySuggestionsBlockListResponse: S.Schema<CreateQuerySuggestionsBlockListResponse>;
export type ThesaurusName = string;
export interface CreateThesaurusRequest {
    IndexId: string;
    Name: string;
    Description?: string;
    RoleArn: string;
    Tags?: Tag[];
    SourceS3Path: S3Path;
    ClientToken?: string;
}
export declare const CreateThesaurusRequest: S.Schema<CreateThesaurusRequest>;
export type ThesaurusId = string;
export interface CreateThesaurusResponse {
    Id?: string;
}
export declare const CreateThesaurusResponse: S.Schema<CreateThesaurusResponse>;
export interface DeleteAccessControlConfigurationRequest {
    IndexId: string;
    Id: string;
}
export declare const DeleteAccessControlConfigurationRequest: S.Schema<DeleteAccessControlConfigurationRequest>;
export interface DeleteAccessControlConfigurationResponse {
}
export declare const DeleteAccessControlConfigurationResponse: S.Schema<DeleteAccessControlConfigurationResponse>;
export interface DeleteDataSourceRequest {
    Id: string;
    IndexId: string;
}
export declare const DeleteDataSourceRequest: S.Schema<DeleteDataSourceRequest>;
export interface DeleteDataSourceResponse {
}
export declare const DeleteDataSourceResponse: S.Schema<DeleteDataSourceResponse>;
export interface DeleteExperienceRequest {
    Id: string;
    IndexId: string;
}
export declare const DeleteExperienceRequest: S.Schema<DeleteExperienceRequest>;
export interface DeleteExperienceResponse {
}
export declare const DeleteExperienceResponse: S.Schema<DeleteExperienceResponse>;
export interface DeleteFaqRequest {
    Id: string;
    IndexId: string;
}
export declare const DeleteFaqRequest: S.Schema<DeleteFaqRequest>;
export interface DeleteFaqResponse {
}
export declare const DeleteFaqResponse: S.Schema<DeleteFaqResponse>;
export interface DeleteIndexRequest {
    Id: string;
}
export declare const DeleteIndexRequest: S.Schema<DeleteIndexRequest>;
export interface DeleteIndexResponse {
}
export declare const DeleteIndexResponse: S.Schema<DeleteIndexResponse>;
export type GroupId = string;
export type PrincipalOrderingId = number;
export interface DeletePrincipalMappingRequest {
    IndexId: string;
    DataSourceId?: string;
    GroupId: string;
    OrderingId?: number;
}
export declare const DeletePrincipalMappingRequest: S.Schema<DeletePrincipalMappingRequest>;
export interface DeletePrincipalMappingResponse {
}
export declare const DeletePrincipalMappingResponse: S.Schema<DeletePrincipalMappingResponse>;
export interface DeleteQuerySuggestionsBlockListRequest {
    IndexId: string;
    Id: string;
}
export declare const DeleteQuerySuggestionsBlockListRequest: S.Schema<DeleteQuerySuggestionsBlockListRequest>;
export interface DeleteQuerySuggestionsBlockListResponse {
}
export declare const DeleteQuerySuggestionsBlockListResponse: S.Schema<DeleteQuerySuggestionsBlockListResponse>;
export interface DeleteThesaurusRequest {
    Id: string;
    IndexId: string;
}
export declare const DeleteThesaurusRequest: S.Schema<DeleteThesaurusRequest>;
export interface DeleteThesaurusResponse {
}
export declare const DeleteThesaurusResponse: S.Schema<DeleteThesaurusResponse>;
export interface DescribeAccessControlConfigurationRequest {
    IndexId: string;
    Id: string;
}
export declare const DescribeAccessControlConfigurationRequest: S.Schema<DescribeAccessControlConfigurationRequest>;
export interface DescribeAccessControlConfigurationResponse {
    Name: string;
    Description?: string;
    ErrorMessage?: string;
    AccessControlList?: Principal[];
    HierarchicalAccessControlList?: HierarchicalPrincipal[];
}
export declare const DescribeAccessControlConfigurationResponse: S.Schema<DescribeAccessControlConfigurationResponse>;
export interface DescribeDataSourceRequest {
    Id: string;
    IndexId: string;
}
export declare const DescribeDataSourceRequest: S.Schema<DescribeDataSourceRequest>;
export type DataSourceStatus = "CREATING" | "DELETING" | "FAILED" | "UPDATING" | "ACTIVE" | (string & {});
export declare const DataSourceStatus: any;
export interface DescribeDataSourceResponse {
    Id?: string;
    IndexId?: string;
    Name?: string;
    Type?: DataSourceType;
    Configuration?: DataSourceConfiguration;
    VpcConfiguration?: DataSourceVpcConfiguration;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Description?: string;
    Status?: DataSourceStatus;
    Schedule?: string;
    RoleArn?: string;
    ErrorMessage?: string;
    LanguageCode?: string;
    CustomDocumentEnrichmentConfiguration?: CustomDocumentEnrichmentConfiguration;
}
export declare const DescribeDataSourceResponse: S.Schema<DescribeDataSourceResponse>;
export interface DescribeExperienceRequest {
    Id: string;
    IndexId: string;
}
export declare const DescribeExperienceRequest: S.Schema<DescribeExperienceRequest>;
export type EndpointType = "HOME" | (string & {});
export declare const EndpointType: any;
export type Endpoint = string;
export interface ExperienceEndpoint {
    EndpointType?: EndpointType;
    Endpoint?: string;
}
export declare const ExperienceEndpoint: S.Schema<ExperienceEndpoint>;
export type ExperienceEndpoints = ExperienceEndpoint[];
export declare const ExperienceEndpoints: any;
export type ExperienceStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export declare const ExperienceStatus: any;
export interface DescribeExperienceResponse {
    Id?: string;
    IndexId?: string;
    Name?: string;
    Endpoints?: ExperienceEndpoint[];
    Configuration?: ExperienceConfiguration;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Description?: string;
    Status?: ExperienceStatus;
    RoleArn?: string;
    ErrorMessage?: string;
}
export declare const DescribeExperienceResponse: S.Schema<DescribeExperienceResponse>;
export interface DescribeFaqRequest {
    Id: string;
    IndexId: string;
}
export declare const DescribeFaqRequest: S.Schema<DescribeFaqRequest>;
export type FaqStatus = "CREATING" | "UPDATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export declare const FaqStatus: any;
export interface DescribeFaqResponse {
    Id?: string;
    IndexId?: string;
    Name?: string;
    Description?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    S3Path?: S3Path;
    Status?: FaqStatus;
    RoleArn?: string;
    ErrorMessage?: string;
    FileFormat?: FaqFileFormat;
    LanguageCode?: string;
}
export declare const DescribeFaqResponse: S.Schema<DescribeFaqResponse>;
export interface DescribeFeaturedResultsSetRequest {
    IndexId: string;
    FeaturedResultsSetId: string;
}
export declare const DescribeFeaturedResultsSetRequest: S.Schema<DescribeFeaturedResultsSetRequest>;
export interface FeaturedDocumentWithMetadata {
    Id?: string;
    Title?: string;
    URI?: string;
}
export declare const FeaturedDocumentWithMetadata: S.Schema<FeaturedDocumentWithMetadata>;
export type FeaturedDocumentWithMetadataList = FeaturedDocumentWithMetadata[];
export declare const FeaturedDocumentWithMetadataList: any;
export interface FeaturedDocumentMissing {
    Id?: string;
}
export declare const FeaturedDocumentMissing: S.Schema<FeaturedDocumentMissing>;
export type FeaturedDocumentMissingList = FeaturedDocumentMissing[];
export declare const FeaturedDocumentMissingList: any;
export interface DescribeFeaturedResultsSetResponse {
    FeaturedResultsSetId?: string;
    FeaturedResultsSetName?: string;
    Description?: string;
    Status?: FeaturedResultsSetStatus;
    QueryTexts?: string[];
    FeaturedDocumentsWithMetadata?: FeaturedDocumentWithMetadata[];
    FeaturedDocumentsMissing?: FeaturedDocumentMissing[];
    LastUpdatedTimestamp?: number;
    CreationTimestamp?: number;
}
export declare const DescribeFeaturedResultsSetResponse: S.Schema<DescribeFeaturedResultsSetResponse>;
export interface DescribeIndexRequest {
    Id: string;
}
export declare const DescribeIndexRequest: S.Schema<DescribeIndexRequest>;
export type IndexStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | "UPDATING" | "SYSTEM_UPDATING" | (string & {});
export declare const IndexStatus: any;
export type DocumentMetadataConfigurationName = string;
export type DocumentAttributeValueType = "STRING_VALUE" | "STRING_LIST_VALUE" | "LONG_VALUE" | "DATE_VALUE" | (string & {});
export declare const DocumentAttributeValueType: any;
export type DocumentMetadataBoolean = boolean;
export type Importance = number;
export type Duration = string;
export type Order = "ASCENDING" | "DESCENDING" | (string & {});
export declare const Order: any;
export type ValueImportanceMapKey = string;
export type ValueImportanceMap = {
    [key: string]: number | undefined;
};
export declare const ValueImportanceMap: any;
export interface Relevance {
    Freshness?: boolean;
    Importance?: number;
    Duration?: string;
    RankOrder?: Order;
    ValueImportanceMap?: {
        [key: string]: number | undefined;
    };
}
export declare const Relevance: S.Schema<Relevance>;
export interface Search {
    Facetable?: boolean;
    Searchable?: boolean;
    Displayable?: boolean;
    Sortable?: boolean;
}
export declare const Search: S.Schema<Search>;
export interface DocumentMetadataConfiguration {
    Name: string;
    Type: DocumentAttributeValueType;
    Relevance?: Relevance;
    Search?: Search;
}
export declare const DocumentMetadataConfiguration: S.Schema<DocumentMetadataConfiguration>;
export type DocumentMetadataConfigurationList = DocumentMetadataConfiguration[];
export declare const DocumentMetadataConfigurationList: any;
export type IndexedQuestionAnswersCount = number;
export interface FaqStatistics {
    IndexedQuestionAnswersCount: number;
}
export declare const FaqStatistics: S.Schema<FaqStatistics>;
export type IndexedTextDocumentsCount = number;
export type IndexedTextBytes = number;
export interface TextDocumentStatistics {
    IndexedTextDocumentsCount: number;
    IndexedTextBytes: number;
}
export declare const TextDocumentStatistics: S.Schema<TextDocumentStatistics>;
export interface IndexStatistics {
    FaqStatistics: FaqStatistics;
    TextDocumentStatistics: TextDocumentStatistics;
}
export declare const IndexStatistics: S.Schema<IndexStatistics>;
export type StorageCapacityUnit = number;
export type QueryCapacityUnit = number;
export interface CapacityUnitsConfiguration {
    StorageCapacityUnits: number;
    QueryCapacityUnits: number;
}
export declare const CapacityUnitsConfiguration: S.Schema<CapacityUnitsConfiguration>;
export interface DescribeIndexResponse {
    Name?: string;
    Id?: string;
    Edition?: IndexEdition;
    RoleArn?: string;
    ServerSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    Status?: IndexStatus;
    Description?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    DocumentMetadataConfigurations?: DocumentMetadataConfiguration[];
    IndexStatistics?: IndexStatistics;
    ErrorMessage?: string;
    CapacityUnits?: CapacityUnitsConfiguration;
    UserTokenConfigurations?: UserTokenConfiguration[];
    UserContextPolicy?: UserContextPolicy;
    UserGroupResolutionConfiguration?: UserGroupResolutionConfiguration;
}
export declare const DescribeIndexResponse: S.Schema<DescribeIndexResponse>;
export interface DescribePrincipalMappingRequest {
    IndexId: string;
    DataSourceId?: string;
    GroupId: string;
}
export declare const DescribePrincipalMappingRequest: S.Schema<DescribePrincipalMappingRequest>;
export type PrincipalMappingStatus = "FAILED" | "SUCCEEDED" | "PROCESSING" | "DELETING" | "DELETED" | (string & {});
export declare const PrincipalMappingStatus: any;
export type FailureReason = string;
export interface GroupOrderingIdSummary {
    Status?: PrincipalMappingStatus;
    LastUpdatedAt?: Date;
    ReceivedAt?: Date;
    OrderingId?: number;
    FailureReason?: string;
}
export declare const GroupOrderingIdSummary: S.Schema<GroupOrderingIdSummary>;
export type GroupOrderingIdSummaries = GroupOrderingIdSummary[];
export declare const GroupOrderingIdSummaries: any;
export interface DescribePrincipalMappingResponse {
    IndexId?: string;
    DataSourceId?: string;
    GroupId?: string;
    GroupOrderingIdSummaries?: GroupOrderingIdSummary[];
}
export declare const DescribePrincipalMappingResponse: S.Schema<DescribePrincipalMappingResponse>;
export interface DescribeQuerySuggestionsBlockListRequest {
    IndexId: string;
    Id: string;
}
export declare const DescribeQuerySuggestionsBlockListRequest: S.Schema<DescribeQuerySuggestionsBlockListRequest>;
export type QuerySuggestionsBlockListStatus = "ACTIVE" | "CREATING" | "DELETING" | "UPDATING" | "ACTIVE_BUT_UPDATE_FAILED" | "FAILED" | (string & {});
export declare const QuerySuggestionsBlockListStatus: any;
export interface DescribeQuerySuggestionsBlockListResponse {
    IndexId?: string;
    Id?: string;
    Name?: string;
    Description?: string;
    Status?: QuerySuggestionsBlockListStatus;
    ErrorMessage?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    SourceS3Path?: S3Path;
    ItemCount?: number;
    FileSizeBytes?: number;
    RoleArn?: string;
}
export declare const DescribeQuerySuggestionsBlockListResponse: S.Schema<DescribeQuerySuggestionsBlockListResponse>;
export interface DescribeQuerySuggestionsConfigRequest {
    IndexId: string;
}
export declare const DescribeQuerySuggestionsConfigRequest: S.Schema<DescribeQuerySuggestionsConfigRequest>;
export type Mode = "ENABLED" | "LEARN_ONLY" | (string & {});
export declare const Mode: any;
export type QuerySuggestionsStatus = "ACTIVE" | "UPDATING" | (string & {});
export declare const QuerySuggestionsStatus: any;
export type ObjectBoolean = boolean;
export type MinimumNumberOfQueryingUsers = number;
export type MinimumQueryCount = number;
export interface SuggestableConfig {
    AttributeName?: string;
    Suggestable?: boolean;
}
export declare const SuggestableConfig: S.Schema<SuggestableConfig>;
export type SuggestableConfigList = SuggestableConfig[];
export declare const SuggestableConfigList: any;
export type AttributeSuggestionsMode = "ACTIVE" | "INACTIVE" | (string & {});
export declare const AttributeSuggestionsMode: any;
export interface AttributeSuggestionsDescribeConfig {
    SuggestableConfigList?: SuggestableConfig[];
    AttributeSuggestionsMode?: AttributeSuggestionsMode;
}
export declare const AttributeSuggestionsDescribeConfig: S.Schema<AttributeSuggestionsDescribeConfig>;
export interface DescribeQuerySuggestionsConfigResponse {
    Mode?: Mode;
    Status?: QuerySuggestionsStatus;
    QueryLogLookBackWindowInDays?: number;
    IncludeQueriesWithoutUserInformation?: boolean;
    MinimumNumberOfQueryingUsers?: number;
    MinimumQueryCount?: number;
    LastSuggestionsBuildTime?: Date;
    LastClearTime?: Date;
    TotalSuggestionsCount?: number;
    AttributeSuggestionsConfig?: AttributeSuggestionsDescribeConfig;
}
export declare const DescribeQuerySuggestionsConfigResponse: S.Schema<DescribeQuerySuggestionsConfigResponse>;
export interface DescribeThesaurusRequest {
    Id: string;
    IndexId: string;
}
export declare const DescribeThesaurusRequest: S.Schema<DescribeThesaurusRequest>;
export type ThesaurusStatus = "CREATING" | "ACTIVE" | "DELETING" | "UPDATING" | "ACTIVE_BUT_UPDATE_FAILED" | "FAILED" | (string & {});
export declare const ThesaurusStatus: any;
export interface DescribeThesaurusResponse {
    Id?: string;
    IndexId?: string;
    Name?: string;
    Description?: string;
    Status?: ThesaurusStatus;
    ErrorMessage?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    RoleArn?: string;
    SourceS3Path?: S3Path;
    FileSizeBytes?: number;
    TermCount?: number;
    SynonymRuleCount?: number;
}
export declare const DescribeThesaurusResponse: S.Schema<DescribeThesaurusResponse>;
export type DisassociateEntityList = EntityConfiguration[];
export declare const DisassociateEntityList: any;
export interface DisassociateEntitiesFromExperienceRequest {
    Id: string;
    IndexId: string;
    EntityList: EntityConfiguration[];
}
export declare const DisassociateEntitiesFromExperienceRequest: S.Schema<DisassociateEntitiesFromExperienceRequest>;
export interface DisassociateEntitiesFromExperienceResponse {
    FailedEntityList?: FailedEntity[];
}
export declare const DisassociateEntitiesFromExperienceResponse: S.Schema<DisassociateEntitiesFromExperienceResponse>;
export type EntityIdsList = string[];
export declare const EntityIdsList: any;
export interface DisassociatePersonasFromEntitiesRequest {
    Id: string;
    IndexId: string;
    EntityIds: string[];
}
export declare const DisassociatePersonasFromEntitiesRequest: S.Schema<DisassociatePersonasFromEntitiesRequest>;
export interface DisassociatePersonasFromEntitiesResponse {
    FailedEntityList?: FailedEntity[];
}
export declare const DisassociatePersonasFromEntitiesResponse: S.Schema<DisassociatePersonasFromEntitiesResponse>;
export type SuggestionQueryText = string;
export type SuggestionType = "QUERY" | "DOCUMENT_ATTRIBUTES" | (string & {});
export declare const SuggestionType: any;
export type SuggestionTypes = SuggestionType[];
export declare const SuggestionTypes: any;
export type DocumentAttributeKeyList = string[];
export declare const DocumentAttributeKeyList: any;
export type AttributeFilterList = AttributeFilter[];
export declare const AttributeFilterList: S.Schema<AttributeFilterList>;
export interface AttributeFilter {
    AndAllFilters?: AttributeFilter[];
    OrAllFilters?: AttributeFilter[];
    NotFilter?: AttributeFilter;
    EqualsTo?: DocumentAttribute;
    ContainsAll?: DocumentAttribute;
    ContainsAny?: DocumentAttribute;
    GreaterThan?: DocumentAttribute;
    GreaterThanOrEquals?: DocumentAttribute;
    LessThan?: DocumentAttribute;
    LessThanOrEquals?: DocumentAttribute;
}
export declare const AttributeFilter: S.Schema<AttributeFilter>;
export type Token = string;
export type Groups = string[];
export declare const Groups: any;
export interface DataSourceGroup {
    GroupId: string;
    DataSourceId: string;
}
export declare const DataSourceGroup: S.Schema<DataSourceGroup>;
export type DataSourceGroups = DataSourceGroup[];
export declare const DataSourceGroups: any;
export interface UserContext {
    Token?: string | redacted.Redacted<string>;
    UserId?: string;
    Groups?: string[];
    DataSourceGroups?: DataSourceGroup[];
}
export declare const UserContext: S.Schema<UserContext>;
export interface AttributeSuggestionsGetConfig {
    SuggestionAttributes?: string[];
    AdditionalResponseAttributes?: string[];
    AttributeFilter?: AttributeFilter;
    UserContext?: UserContext;
}
export declare const AttributeSuggestionsGetConfig: S.Schema<AttributeSuggestionsGetConfig>;
export interface GetQuerySuggestionsRequest {
    IndexId: string;
    QueryText: string;
    MaxSuggestionsCount?: number;
    SuggestionTypes?: SuggestionType[];
    AttributeSuggestionsConfig?: AttributeSuggestionsGetConfig;
}
export declare const GetQuerySuggestionsRequest: S.Schema<GetQuerySuggestionsRequest>;
export type QuerySuggestionsId = string;
export type ResultId = string;
export interface SuggestionHighlight {
    BeginOffset?: number;
    EndOffset?: number;
}
export declare const SuggestionHighlight: S.Schema<SuggestionHighlight>;
export type SuggestionHighlightList = SuggestionHighlight[];
export declare const SuggestionHighlightList: any;
export interface SuggestionTextWithHighlights {
    Text?: string;
    Highlights?: SuggestionHighlight[];
}
export declare const SuggestionTextWithHighlights: S.Schema<SuggestionTextWithHighlights>;
export interface SuggestionValue {
    Text?: SuggestionTextWithHighlights;
}
export declare const SuggestionValue: S.Schema<SuggestionValue>;
export interface SourceDocument {
    DocumentId?: string;
    SuggestionAttributes?: string[];
    AdditionalAttributes?: DocumentAttribute[];
}
export declare const SourceDocument: S.Schema<SourceDocument>;
export type SourceDocuments = SourceDocument[];
export declare const SourceDocuments: any;
export interface Suggestion {
    Id?: string;
    Value?: SuggestionValue;
    SourceDocuments?: SourceDocument[];
}
export declare const Suggestion: S.Schema<Suggestion>;
export type SuggestionList = Suggestion[];
export declare const SuggestionList: any;
export interface GetQuerySuggestionsResponse {
    QuerySuggestionsId?: string;
    Suggestions?: Suggestion[];
}
export declare const GetQuerySuggestionsResponse: S.Schema<GetQuerySuggestionsResponse>;
export type Interval = "THIS_MONTH" | "THIS_WEEK" | "ONE_WEEK_AGO" | "TWO_WEEKS_AGO" | "ONE_MONTH_AGO" | "TWO_MONTHS_AGO" | (string & {});
export declare const Interval: any;
export type MetricType = "QUERIES_BY_COUNT" | "QUERIES_BY_ZERO_CLICK_RATE" | "QUERIES_BY_ZERO_RESULT_RATE" | "DOCS_BY_CLICK_COUNT" | "AGG_QUERY_DOC_METRICS" | "TREND_QUERY_DOC_METRICS" | (string & {});
export declare const MetricType: any;
export type NextToken = string;
export interface GetSnapshotsRequest {
    IndexId: string;
    Interval: Interval;
    MetricType: MetricType;
    NextToken?: string;
    MaxResults?: number;
}
export declare const GetSnapshotsRequest: S.Schema<GetSnapshotsRequest>;
export interface TimeRange {
    StartTime?: Date;
    EndTime?: Date;
}
export declare const TimeRange: S.Schema<TimeRange>;
export type SnapshotsDataHeaderFields = string[];
export declare const SnapshotsDataHeaderFields: any;
export type SnapshotsDataRecord = string[];
export declare const SnapshotsDataRecord: any;
export type SnapshotsDataRecords = string[][];
export declare const SnapshotsDataRecords: any;
export interface GetSnapshotsResponse {
    SnapShotTimeFilter?: TimeRange;
    SnapshotsDataHeader?: string[];
    SnapshotsData?: string[][];
    NextToken?: string;
}
export declare const GetSnapshotsResponse: S.Schema<GetSnapshotsResponse>;
export type MaxResultsIntegerForListAccessControlConfigurationsRequest = number;
export interface ListAccessControlConfigurationsRequest {
    IndexId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListAccessControlConfigurationsRequest: S.Schema<ListAccessControlConfigurationsRequest>;
export interface AccessControlConfigurationSummary {
    Id: string;
}
export declare const AccessControlConfigurationSummary: S.Schema<AccessControlConfigurationSummary>;
export type AccessControlConfigurationSummaryList = AccessControlConfigurationSummary[];
export declare const AccessControlConfigurationSummaryList: any;
export interface ListAccessControlConfigurationsResponse {
    NextToken?: string;
    AccessControlConfigurations: AccessControlConfigurationSummary[];
}
export declare const ListAccessControlConfigurationsResponse: S.Schema<ListAccessControlConfigurationsResponse>;
export type MaxResultsIntegerForListDataSourcesRequest = number;
export interface ListDataSourcesRequest {
    IndexId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDataSourcesRequest: S.Schema<ListDataSourcesRequest>;
export interface DataSourceSummary {
    Name?: string;
    Id?: string;
    Type?: DataSourceType;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Status?: DataSourceStatus;
    LanguageCode?: string;
}
export declare const DataSourceSummary: S.Schema<DataSourceSummary>;
export type DataSourceSummaryList = DataSourceSummary[];
export declare const DataSourceSummaryList: any;
export interface ListDataSourcesResponse {
    SummaryItems?: DataSourceSummary[];
    NextToken?: string;
}
export declare const ListDataSourcesResponse: S.Schema<ListDataSourcesResponse>;
export type MaxResultsIntegerForListDataSourceSyncJobsRequest = number;
export type DataSourceSyncJobStatus = "FAILED" | "SUCCEEDED" | "SYNCING" | "INCOMPLETE" | "STOPPING" | "ABORTED" | "SYNCING_INDEXING" | (string & {});
export declare const DataSourceSyncJobStatus: any;
export interface ListDataSourceSyncJobsRequest {
    Id: string;
    IndexId: string;
    NextToken?: string;
    MaxResults?: number;
    StartTimeFilter?: TimeRange;
    StatusFilter?: DataSourceSyncJobStatus;
}
export declare const ListDataSourceSyncJobsRequest: S.Schema<ListDataSourceSyncJobsRequest>;
export type MetricValue = string;
export interface DataSourceSyncJobMetrics {
    DocumentsAdded?: string;
    DocumentsModified?: string;
    DocumentsDeleted?: string;
    DocumentsFailed?: string;
    DocumentsScanned?: string;
}
export declare const DataSourceSyncJobMetrics: S.Schema<DataSourceSyncJobMetrics>;
export interface DataSourceSyncJob {
    ExecutionId?: string;
    StartTime?: Date;
    EndTime?: Date;
    Status?: DataSourceSyncJobStatus;
    ErrorMessage?: string;
    ErrorCode?: ErrorCode;
    DataSourceErrorCode?: string;
    Metrics?: DataSourceSyncJobMetrics;
}
export declare const DataSourceSyncJob: S.Schema<DataSourceSyncJob>;
export type DataSourceSyncJobHistoryList = DataSourceSyncJob[];
export declare const DataSourceSyncJobHistoryList: any;
export interface ListDataSourceSyncJobsResponse {
    History?: DataSourceSyncJob[];
    NextToken?: string;
}
export declare const ListDataSourceSyncJobsResponse: S.Schema<ListDataSourceSyncJobsResponse>;
export type MaxResultsIntegerForListEntityPersonasRequest = number;
export interface ListEntityPersonasRequest {
    Id: string;
    IndexId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEntityPersonasRequest: S.Schema<ListEntityPersonasRequest>;
export interface PersonasSummary {
    EntityId?: string;
    Persona?: Persona;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export declare const PersonasSummary: S.Schema<PersonasSummary>;
export type PersonasSummaryList = PersonasSummary[];
export declare const PersonasSummaryList: any;
export interface ListEntityPersonasResponse {
    SummaryItems?: PersonasSummary[];
    NextToken?: string;
}
export declare const ListEntityPersonasResponse: S.Schema<ListEntityPersonasResponse>;
export interface ListExperienceEntitiesRequest {
    Id: string;
    IndexId: string;
    NextToken?: string;
}
export declare const ListExperienceEntitiesRequest: S.Schema<ListExperienceEntitiesRequest>;
export type NameType = string | redacted.Redacted<string>;
export interface EntityDisplayData {
    UserName?: string | redacted.Redacted<string>;
    GroupName?: string | redacted.Redacted<string>;
    IdentifiedUserName?: string | redacted.Redacted<string>;
    FirstName?: string | redacted.Redacted<string>;
    LastName?: string | redacted.Redacted<string>;
}
export declare const EntityDisplayData: S.Schema<EntityDisplayData>;
export interface ExperienceEntitiesSummary {
    EntityId?: string;
    EntityType?: EntityType;
    DisplayData?: EntityDisplayData;
}
export declare const ExperienceEntitiesSummary: S.Schema<ExperienceEntitiesSummary>;
export type ExperienceEntitiesSummaryList = ExperienceEntitiesSummary[];
export declare const ExperienceEntitiesSummaryList: any;
export interface ListExperienceEntitiesResponse {
    SummaryItems?: ExperienceEntitiesSummary[];
    NextToken?: string;
}
export declare const ListExperienceEntitiesResponse: S.Schema<ListExperienceEntitiesResponse>;
export type MaxResultsIntegerForListExperiencesRequest = number;
export interface ListExperiencesRequest {
    IndexId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListExperiencesRequest: S.Schema<ListExperiencesRequest>;
export interface ExperiencesSummary {
    Name?: string;
    Id?: string;
    CreatedAt?: Date;
    Status?: ExperienceStatus;
    Endpoints?: ExperienceEndpoint[];
}
export declare const ExperiencesSummary: S.Schema<ExperiencesSummary>;
export type ExperiencesSummaryList = ExperiencesSummary[];
export declare const ExperiencesSummaryList: any;
export interface ListExperiencesResponse {
    SummaryItems?: ExperiencesSummary[];
    NextToken?: string;
}
export declare const ListExperiencesResponse: S.Schema<ListExperiencesResponse>;
export type MaxResultsIntegerForListFaqsRequest = number;
export interface ListFaqsRequest {
    IndexId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListFaqsRequest: S.Schema<ListFaqsRequest>;
export interface FaqSummary {
    Id?: string;
    Name?: string;
    Status?: FaqStatus;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    FileFormat?: FaqFileFormat;
    LanguageCode?: string;
}
export declare const FaqSummary: S.Schema<FaqSummary>;
export type FaqSummaryItems = FaqSummary[];
export declare const FaqSummaryItems: any;
export interface ListFaqsResponse {
    NextToken?: string;
    FaqSummaryItems?: FaqSummary[];
}
export declare const ListFaqsResponse: S.Schema<ListFaqsResponse>;
export type MaxResultsIntegerForListFeaturedResultsSetsRequest = number;
export interface ListFeaturedResultsSetsRequest {
    IndexId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListFeaturedResultsSetsRequest: S.Schema<ListFeaturedResultsSetsRequest>;
export interface FeaturedResultsSetSummary {
    FeaturedResultsSetId?: string;
    FeaturedResultsSetName?: string;
    Status?: FeaturedResultsSetStatus;
    LastUpdatedTimestamp?: number;
    CreationTimestamp?: number;
}
export declare const FeaturedResultsSetSummary: S.Schema<FeaturedResultsSetSummary>;
export type FeaturedResultsSetSummaryItems = FeaturedResultsSetSummary[];
export declare const FeaturedResultsSetSummaryItems: any;
export interface ListFeaturedResultsSetsResponse {
    FeaturedResultsSetSummaryItems?: FeaturedResultsSetSummary[];
    NextToken?: string;
}
export declare const ListFeaturedResultsSetsResponse: S.Schema<ListFeaturedResultsSetsResponse>;
export type MaxResultsIntegerForListPrincipalsRequest = number;
export interface ListGroupsOlderThanOrderingIdRequest {
    IndexId: string;
    DataSourceId?: string;
    OrderingId: number;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListGroupsOlderThanOrderingIdRequest: S.Schema<ListGroupsOlderThanOrderingIdRequest>;
export interface GroupSummary {
    GroupId?: string;
    OrderingId?: number;
}
export declare const GroupSummary: S.Schema<GroupSummary>;
export type ListOfGroupSummaries = GroupSummary[];
export declare const ListOfGroupSummaries: any;
export interface ListGroupsOlderThanOrderingIdResponse {
    GroupsSummaries?: GroupSummary[];
    NextToken?: string;
}
export declare const ListGroupsOlderThanOrderingIdResponse: S.Schema<ListGroupsOlderThanOrderingIdResponse>;
export type MaxResultsIntegerForListIndicesRequest = number;
export interface ListIndicesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListIndicesRequest: S.Schema<ListIndicesRequest>;
export interface IndexConfigurationSummary {
    Name?: string;
    Id?: string;
    Edition?: IndexEdition;
    CreatedAt: Date;
    UpdatedAt: Date;
    Status: IndexStatus;
}
export declare const IndexConfigurationSummary: S.Schema<IndexConfigurationSummary>;
export type IndexConfigurationSummaryList = IndexConfigurationSummary[];
export declare const IndexConfigurationSummaryList: any;
export interface ListIndicesResponse {
    IndexConfigurationSummaryItems?: IndexConfigurationSummary[];
    NextToken?: string;
}
export declare const ListIndicesResponse: S.Schema<ListIndicesResponse>;
export type MaxResultsIntegerForListQuerySuggestionsBlockLists = number;
export interface ListQuerySuggestionsBlockListsRequest {
    IndexId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListQuerySuggestionsBlockListsRequest: S.Schema<ListQuerySuggestionsBlockListsRequest>;
export interface QuerySuggestionsBlockListSummary {
    Id?: string;
    Name?: string;
    Status?: QuerySuggestionsBlockListStatus;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ItemCount?: number;
}
export declare const QuerySuggestionsBlockListSummary: S.Schema<QuerySuggestionsBlockListSummary>;
export type QuerySuggestionsBlockListSummaryItems = QuerySuggestionsBlockListSummary[];
export declare const QuerySuggestionsBlockListSummaryItems: any;
export interface ListQuerySuggestionsBlockListsResponse {
    BlockListSummaryItems?: QuerySuggestionsBlockListSummary[];
    NextToken?: string;
}
export declare const ListQuerySuggestionsBlockListsResponse: S.Schema<ListQuerySuggestionsBlockListsResponse>;
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type MaxResultsIntegerForListThesauriRequest = number;
export interface ListThesauriRequest {
    IndexId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListThesauriRequest: S.Schema<ListThesauriRequest>;
export interface ThesaurusSummary {
    Id?: string;
    Name?: string;
    Status?: ThesaurusStatus;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export declare const ThesaurusSummary: S.Schema<ThesaurusSummary>;
export type ThesaurusSummaryItems = ThesaurusSummary[];
export declare const ThesaurusSummaryItems: any;
export interface ListThesauriResponse {
    NextToken?: string;
    ThesaurusSummaryItems?: ThesaurusSummary[];
}
export declare const ListThesauriResponse: S.Schema<ListThesauriResponse>;
export interface MemberGroup {
    GroupId: string;
    DataSourceId?: string;
}
export declare const MemberGroup: S.Schema<MemberGroup>;
export type MemberGroups = MemberGroup[];
export declare const MemberGroups: any;
export type UserId = string;
export interface MemberUser {
    UserId: string;
}
export declare const MemberUser: S.Schema<MemberUser>;
export type MemberUsers = MemberUser[];
export declare const MemberUsers: any;
export interface GroupMembers {
    MemberGroups?: MemberGroup[];
    MemberUsers?: MemberUser[];
    S3PathforGroupMembers?: S3Path;
}
export declare const GroupMembers: S.Schema<GroupMembers>;
export interface PutPrincipalMappingRequest {
    IndexId: string;
    DataSourceId?: string;
    GroupId: string;
    GroupMembers: GroupMembers;
    OrderingId?: number;
    RoleArn?: string;
}
export declare const PutPrincipalMappingRequest: S.Schema<PutPrincipalMappingRequest>;
export interface PutPrincipalMappingResponse {
}
export declare const PutPrincipalMappingResponse: S.Schema<PutPrincipalMappingResponse>;
export type TopDocumentAttributeValueCountPairsSize = number;
export interface Facet {
    DocumentAttributeKey?: string;
    Facets?: Facet[];
    MaxResults?: number;
}
export declare const Facet: S.Schema<Facet>;
export type FacetList = Facet[];
export declare const FacetList: S.Schema<FacetList>;
export type QueryResultType = "DOCUMENT" | "QUESTION_ANSWER" | "ANSWER" | (string & {});
export declare const QueryResultType: any;
export interface DocumentRelevanceConfiguration {
    Name: string;
    Relevance: Relevance;
}
export declare const DocumentRelevanceConfiguration: S.Schema<DocumentRelevanceConfiguration>;
export type DocumentRelevanceOverrideConfigurationList = DocumentRelevanceConfiguration[];
export declare const DocumentRelevanceOverrideConfigurationList: any;
export type SortOrder = "DESC" | "ASC" | (string & {});
export declare const SortOrder: any;
export interface SortingConfiguration {
    DocumentAttributeKey: string;
    SortOrder: SortOrder;
}
export declare const SortingConfiguration: S.Schema<SortingConfiguration>;
export type SortingConfigurationList = SortingConfiguration[];
export declare const SortingConfigurationList: any;
export type VisitorId = string;
export interface SpellCorrectionConfiguration {
    IncludeQuerySpellCheckSuggestions: boolean;
}
export declare const SpellCorrectionConfiguration: S.Schema<SpellCorrectionConfiguration>;
export type MissingAttributeKeyStrategy = "IGNORE" | "COLLAPSE" | "EXPAND" | (string & {});
export declare const MissingAttributeKeyStrategy: any;
export interface ExpandConfiguration {
    MaxResultItemsToExpand?: number;
    MaxExpandedResultsPerItem?: number;
}
export declare const ExpandConfiguration: S.Schema<ExpandConfiguration>;
export interface CollapseConfiguration {
    DocumentAttributeKey: string;
    SortingConfigurations?: SortingConfiguration[];
    MissingAttributeKeyStrategy?: MissingAttributeKeyStrategy;
    Expand?: boolean;
    ExpandConfiguration?: ExpandConfiguration;
}
export declare const CollapseConfiguration: S.Schema<CollapseConfiguration>;
export interface QueryRequest {
    IndexId: string;
    QueryText?: string;
    AttributeFilter?: AttributeFilter;
    Facets?: Facet[];
    RequestedDocumentAttributes?: string[];
    QueryResultTypeFilter?: QueryResultType;
    DocumentRelevanceOverrideConfigurations?: DocumentRelevanceConfiguration[];
    PageNumber?: number;
    PageSize?: number;
    SortingConfiguration?: SortingConfiguration;
    SortingConfigurations?: SortingConfiguration[];
    UserContext?: UserContext;
    VisitorId?: string;
    SpellCorrectionConfiguration?: SpellCorrectionConfiguration;
    CollapseConfiguration?: CollapseConfiguration;
}
export declare const QueryRequest: S.Schema<QueryRequest>;
export type QueryId = string;
export type QueryResultFormat = "TABLE" | "TEXT" | (string & {});
export declare const QueryResultFormat: any;
export type AdditionalResultAttributeValueType = "TEXT_WITH_HIGHLIGHTS_VALUE" | (string & {});
export declare const AdditionalResultAttributeValueType: any;
export type HighlightType = "STANDARD" | "THESAURUS_SYNONYM" | (string & {});
export declare const HighlightType: any;
export interface Highlight {
    BeginOffset: number;
    EndOffset: number;
    TopAnswer?: boolean;
    Type?: HighlightType;
}
export declare const Highlight: S.Schema<Highlight>;
export type HighlightList = Highlight[];
export declare const HighlightList: any;
export interface TextWithHighlights {
    Text?: string;
    Highlights?: Highlight[];
}
export declare const TextWithHighlights: S.Schema<TextWithHighlights>;
export interface AdditionalResultAttributeValue {
    TextWithHighlightsValue?: TextWithHighlights;
}
export declare const AdditionalResultAttributeValue: S.Schema<AdditionalResultAttributeValue>;
export interface AdditionalResultAttribute {
    Key: string;
    ValueType: AdditionalResultAttributeValueType;
    Value: AdditionalResultAttributeValue;
}
export declare const AdditionalResultAttribute: S.Schema<AdditionalResultAttribute>;
export type AdditionalResultAttributeList = AdditionalResultAttribute[];
export declare const AdditionalResultAttributeList: any;
export type ScoreConfidence = "VERY_HIGH" | "HIGH" | "MEDIUM" | "LOW" | "NOT_AVAILABLE" | (string & {});
export declare const ScoreConfidence: any;
export interface ScoreAttributes {
    ScoreConfidence?: ScoreConfidence;
}
export declare const ScoreAttributes: S.Schema<ScoreAttributes>;
export type FeedbackToken = string;
export interface TableCell {
    Value?: string;
    TopAnswer?: boolean;
    Highlighted?: boolean;
    Header?: boolean;
}
export declare const TableCell: S.Schema<TableCell>;
export type TableCellList = TableCell[];
export declare const TableCellList: any;
export interface TableRow {
    Cells?: TableCell[];
}
export declare const TableRow: S.Schema<TableRow>;
export type TableRowList = TableRow[];
export declare const TableRowList: any;
export interface TableExcerpt {
    Rows?: TableRow[];
    TotalNumberOfRows?: number;
}
export declare const TableExcerpt: S.Schema<TableExcerpt>;
export interface ExpandedResultItem {
    Id?: string;
    DocumentId?: string;
    DocumentTitle?: TextWithHighlights;
    DocumentExcerpt?: TextWithHighlights;
    DocumentURI?: string;
    DocumentAttributes?: DocumentAttribute[];
}
export declare const ExpandedResultItem: S.Schema<ExpandedResultItem>;
export type ExpandedResultList = ExpandedResultItem[];
export declare const ExpandedResultList: any;
export interface CollapsedResultDetail {
    DocumentAttribute: DocumentAttribute;
    ExpandedResults?: ExpandedResultItem[];
}
export declare const CollapsedResultDetail: S.Schema<CollapsedResultDetail>;
export interface QueryResultItem {
    Id?: string;
    Type?: QueryResultType;
    Format?: QueryResultFormat;
    AdditionalAttributes?: AdditionalResultAttribute[];
    DocumentId?: string;
    DocumentTitle?: TextWithHighlights;
    DocumentExcerpt?: TextWithHighlights;
    DocumentURI?: string;
    DocumentAttributes?: DocumentAttribute[];
    ScoreAttributes?: ScoreAttributes;
    FeedbackToken?: string;
    TableExcerpt?: TableExcerpt;
    CollapsedResultDetail?: CollapsedResultDetail;
}
export declare const QueryResultItem: S.Schema<QueryResultItem>;
export type QueryResultItemList = QueryResultItem[];
export declare const QueryResultItemList: any;
export interface DocumentAttributeValueCountPair {
    DocumentAttributeValue?: DocumentAttributeValue;
    Count?: number;
    FacetResults?: FacetResult[];
}
export declare const DocumentAttributeValueCountPair: S.Schema<DocumentAttributeValueCountPair>;
export type DocumentAttributeValueCountPairList = DocumentAttributeValueCountPair[];
export declare const DocumentAttributeValueCountPairList: S.Schema<DocumentAttributeValueCountPairList>;
export interface FacetResult {
    DocumentAttributeKey?: string;
    DocumentAttributeValueType?: DocumentAttributeValueType;
    DocumentAttributeValueCountPairs?: DocumentAttributeValueCountPair[];
}
export declare const FacetResult: S.Schema<FacetResult>;
export type FacetResultList = FacetResult[];
export declare const FacetResultList: S.Schema<FacetResultList>;
export type WarningMessage = string;
export type WarningCode = "QUERY_LANGUAGE_INVALID_SYNTAX" | (string & {});
export declare const WarningCode: any;
export interface Warning {
    Message?: string;
    Code?: WarningCode;
}
export declare const Warning: S.Schema<Warning>;
export type WarningList = Warning[];
export declare const WarningList: any;
export type SuggestedQueryText = string;
export interface Correction {
    BeginOffset?: number;
    EndOffset?: number;
    Term?: string;
    CorrectedTerm?: string;
}
export declare const Correction: S.Schema<Correction>;
export type CorrectionList = Correction[];
export declare const CorrectionList: any;
export interface SpellCorrectedQuery {
    SuggestedQueryText?: string;
    Corrections?: Correction[];
}
export declare const SpellCorrectedQuery: S.Schema<SpellCorrectedQuery>;
export type SpellCorrectedQueryList = SpellCorrectedQuery[];
export declare const SpellCorrectedQueryList: any;
export interface FeaturedResultsItem {
    Id?: string;
    Type?: QueryResultType;
    AdditionalAttributes?: AdditionalResultAttribute[];
    DocumentId?: string;
    DocumentTitle?: TextWithHighlights;
    DocumentExcerpt?: TextWithHighlights;
    DocumentURI?: string;
    DocumentAttributes?: DocumentAttribute[];
    FeedbackToken?: string;
}
export declare const FeaturedResultsItem: S.Schema<FeaturedResultsItem>;
export type FeaturedResultsItemList = FeaturedResultsItem[];
export declare const FeaturedResultsItemList: any;
export interface QueryResult {
    QueryId?: string;
    ResultItems?: QueryResultItem[];
    FacetResults?: FacetResult[];
    TotalNumberOfResults?: number;
    Warnings?: Warning[];
    SpellCorrectedQueries?: SpellCorrectedQuery[];
    FeaturedResultsItems?: FeaturedResultsItem[];
}
export declare const QueryResult: S.Schema<QueryResult>;
export interface RetrieveRequest {
    IndexId: string;
    QueryText: string;
    AttributeFilter?: AttributeFilter;
    RequestedDocumentAttributes?: string[];
    DocumentRelevanceOverrideConfigurations?: DocumentRelevanceConfiguration[];
    PageNumber?: number;
    PageSize?: number;
    UserContext?: UserContext;
}
export declare const RetrieveRequest: S.Schema<RetrieveRequest>;
export type DocumentTitle = string;
export type Content = string;
export interface RetrieveResultItem {
    Id?: string;
    DocumentId?: string;
    DocumentTitle?: string;
    Content?: string;
    DocumentURI?: string;
    DocumentAttributes?: DocumentAttribute[];
    ScoreAttributes?: ScoreAttributes;
}
export declare const RetrieveResultItem: S.Schema<RetrieveResultItem>;
export type RetrieveResultItemList = RetrieveResultItem[];
export declare const RetrieveResultItemList: any;
export interface RetrieveResult {
    QueryId?: string;
    ResultItems?: RetrieveResultItem[];
}
export declare const RetrieveResult: S.Schema<RetrieveResult>;
export interface StartDataSourceSyncJobRequest {
    Id: string;
    IndexId: string;
}
export declare const StartDataSourceSyncJobRequest: S.Schema<StartDataSourceSyncJobRequest>;
export interface StartDataSourceSyncJobResponse {
    ExecutionId?: string;
}
export declare const StartDataSourceSyncJobResponse: S.Schema<StartDataSourceSyncJobResponse>;
export interface StopDataSourceSyncJobRequest {
    Id: string;
    IndexId: string;
}
export declare const StopDataSourceSyncJobRequest: S.Schema<StopDataSourceSyncJobRequest>;
export interface StopDataSourceSyncJobResponse {
}
export declare const StopDataSourceSyncJobResponse: S.Schema<StopDataSourceSyncJobResponse>;
export interface ClickFeedback {
    ResultId: string;
    ClickTime: Date;
}
export declare const ClickFeedback: S.Schema<ClickFeedback>;
export type ClickFeedbackList = ClickFeedback[];
export declare const ClickFeedbackList: any;
export type RelevanceType = "RELEVANT" | "NOT_RELEVANT" | (string & {});
export declare const RelevanceType: any;
export interface RelevanceFeedback {
    ResultId: string;
    RelevanceValue: RelevanceType;
}
export declare const RelevanceFeedback: S.Schema<RelevanceFeedback>;
export type RelevanceFeedbackList = RelevanceFeedback[];
export declare const RelevanceFeedbackList: any;
export interface SubmitFeedbackRequest {
    IndexId: string;
    QueryId: string;
    ClickFeedbackItems?: ClickFeedback[];
    RelevanceFeedbackItems?: RelevanceFeedback[];
}
export declare const SubmitFeedbackRequest: S.Schema<SubmitFeedbackRequest>;
export interface SubmitFeedbackResponse {
}
export declare const SubmitFeedbackResponse: S.Schema<SubmitFeedbackResponse>;
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAccessControlConfigurationRequest {
    IndexId: string;
    Id: string;
    Name?: string;
    Description?: string;
    AccessControlList?: Principal[];
    HierarchicalAccessControlList?: HierarchicalPrincipal[];
}
export declare const UpdateAccessControlConfigurationRequest: S.Schema<UpdateAccessControlConfigurationRequest>;
export interface UpdateAccessControlConfigurationResponse {
}
export declare const UpdateAccessControlConfigurationResponse: S.Schema<UpdateAccessControlConfigurationResponse>;
export interface UpdateDataSourceRequest {
    Id: string;
    Name?: string;
    IndexId: string;
    Configuration?: DataSourceConfiguration;
    VpcConfiguration?: DataSourceVpcConfiguration;
    Description?: string;
    Schedule?: string;
    RoleArn?: string;
    LanguageCode?: string;
    CustomDocumentEnrichmentConfiguration?: CustomDocumentEnrichmentConfiguration;
}
export declare const UpdateDataSourceRequest: S.Schema<UpdateDataSourceRequest>;
export interface UpdateDataSourceResponse {
}
export declare const UpdateDataSourceResponse: S.Schema<UpdateDataSourceResponse>;
export interface UpdateExperienceRequest {
    Id: string;
    Name?: string;
    IndexId: string;
    RoleArn?: string;
    Configuration?: ExperienceConfiguration;
    Description?: string;
}
export declare const UpdateExperienceRequest: S.Schema<UpdateExperienceRequest>;
export interface UpdateExperienceResponse {
}
export declare const UpdateExperienceResponse: S.Schema<UpdateExperienceResponse>;
export interface UpdateFeaturedResultsSetRequest {
    IndexId: string;
    FeaturedResultsSetId: string;
    FeaturedResultsSetName?: string;
    Description?: string;
    Status?: FeaturedResultsSetStatus;
    QueryTexts?: string[];
    FeaturedDocuments?: FeaturedDocument[];
}
export declare const UpdateFeaturedResultsSetRequest: S.Schema<UpdateFeaturedResultsSetRequest>;
export interface UpdateFeaturedResultsSetResponse {
    FeaturedResultsSet?: FeaturedResultsSet;
}
export declare const UpdateFeaturedResultsSetResponse: S.Schema<UpdateFeaturedResultsSetResponse>;
export interface UpdateIndexRequest {
    Id: string;
    Name?: string;
    RoleArn?: string;
    Description?: string;
    DocumentMetadataConfigurationUpdates?: DocumentMetadataConfiguration[];
    CapacityUnits?: CapacityUnitsConfiguration;
    UserTokenConfigurations?: UserTokenConfiguration[];
    UserContextPolicy?: UserContextPolicy;
    UserGroupResolutionConfiguration?: UserGroupResolutionConfiguration;
}
export declare const UpdateIndexRequest: S.Schema<UpdateIndexRequest>;
export interface UpdateIndexResponse {
}
export declare const UpdateIndexResponse: S.Schema<UpdateIndexResponse>;
export interface UpdateQuerySuggestionsBlockListRequest {
    IndexId: string;
    Id: string;
    Name?: string;
    Description?: string;
    SourceS3Path?: S3Path;
    RoleArn?: string;
}
export declare const UpdateQuerySuggestionsBlockListRequest: S.Schema<UpdateQuerySuggestionsBlockListRequest>;
export interface UpdateQuerySuggestionsBlockListResponse {
}
export declare const UpdateQuerySuggestionsBlockListResponse: S.Schema<UpdateQuerySuggestionsBlockListResponse>;
export interface AttributeSuggestionsUpdateConfig {
    SuggestableConfigList?: SuggestableConfig[];
    AttributeSuggestionsMode?: AttributeSuggestionsMode;
}
export declare const AttributeSuggestionsUpdateConfig: S.Schema<AttributeSuggestionsUpdateConfig>;
export interface UpdateQuerySuggestionsConfigRequest {
    IndexId: string;
    Mode?: Mode;
    QueryLogLookBackWindowInDays?: number;
    IncludeQueriesWithoutUserInformation?: boolean;
    MinimumNumberOfQueryingUsers?: number;
    MinimumQueryCount?: number;
    AttributeSuggestionsConfig?: AttributeSuggestionsUpdateConfig;
}
export declare const UpdateQuerySuggestionsConfigRequest: S.Schema<UpdateQuerySuggestionsConfigRequest>;
export interface UpdateQuerySuggestionsConfigResponse {
}
export declare const UpdateQuerySuggestionsConfigResponse: S.Schema<UpdateQuerySuggestionsConfigResponse>;
export interface UpdateThesaurusRequest {
    Id: string;
    Name?: string;
    IndexId: string;
    Description?: string;
    RoleArn?: string;
    SourceS3Path?: S3Path;
}
export declare const UpdateThesaurusRequest: S.Schema<UpdateThesaurusRequest>;
export interface UpdateThesaurusResponse {
}
export declare const UpdateThesaurusResponse: S.Schema<UpdateThesaurusResponse>;
export interface ConflictingItem {
    QueryText?: string;
    SetName?: string;
    SetId?: string;
}
export declare const ConflictingItem: S.Schema<ConflictingItem>;
export type ConflictingItems = ConflictingItem[];
export declare const ConflictingItems: any;
export type AssociateEntitiesToExperienceError = AccessDeniedException | InternalServerException | ResourceAlreadyExistException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants users or groups in your IAM Identity Center identity source access
 * to your Amazon Kendra experience. You can create an Amazon Kendra experience such as a
 * search application. For more information on creating a search application
 * experience, see Building
 * a search experience with no code.
 */
export declare const associateEntitiesToExperience: API.OperationMethod<AssociateEntitiesToExperienceRequest, AssociateEntitiesToExperienceResponse, AssociateEntitiesToExperienceError, Credentials | HttpClient.HttpClient>;
export type AssociatePersonasToEntitiesError = AccessDeniedException | InternalServerException | ResourceAlreadyExistException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Defines the specific permissions of users or groups in your IAM Identity Center
 * identity source with access to your Amazon Kendra experience. You can create an Amazon Kendra
 * experience such as a search application. For more information on creating a
 * search application experience, see Building
 * a search experience with no code.
 */
export declare const associatePersonasToEntities: API.OperationMethod<AssociatePersonasToEntitiesRequest, AssociatePersonasToEntitiesResponse, AssociatePersonasToEntitiesError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteDocumentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more documents from an index. The documents must have been added with
 * the `BatchPutDocument` API.
 *
 * The documents are deleted asynchronously. You can see the progress of the deletion by
 * using Amazon Web Services
 * CloudWatch. Any error messages related to the processing of the batch are sent to
 * your Amazon Web Services
 * CloudWatch log. You can also use the `BatchGetDocumentStatus` API to
 * monitor the progress of deleting your documents.
 *
 * Deleting documents from an index using `BatchDeleteDocument` could take up
 * to an hour or more, depending on the number of documents you want to delete.
 */
export declare const batchDeleteDocument: API.OperationMethod<BatchDeleteDocumentRequest, BatchDeleteDocumentResponse, BatchDeleteDocumentError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteFeaturedResultsSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more sets of featured results. Features results are placed
 * above all other results for certain queries. If there's an exact match of a
 * query, then one or more specific documents are featured in the search results.
 */
export declare const batchDeleteFeaturedResultsSet: API.OperationMethod<BatchDeleteFeaturedResultsSetRequest, BatchDeleteFeaturedResultsSetResponse, BatchDeleteFeaturedResultsSetError, Credentials | HttpClient.HttpClient>;
export type BatchGetDocumentStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the indexing status for one or more documents submitted with the
 * BatchPutDocument API.
 *
 * When you use the `BatchPutDocument` API, documents are indexed
 * asynchronously. You can use the `BatchGetDocumentStatus` API to get the
 * current status of a list of documents so that you can determine if they have been
 * successfully indexed.
 *
 * You can also use the `BatchGetDocumentStatus` API to check the status of
 * the
 * BatchDeleteDocument API. When a document is deleted from the index, Amazon Kendra returns `NOT_FOUND` as the status.
 */
export declare const batchGetDocumentStatus: API.OperationMethod<BatchGetDocumentStatusRequest, BatchGetDocumentStatusResponse, BatchGetDocumentStatusError, Credentials | HttpClient.HttpClient>;
export type BatchPutDocumentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds one or more documents to an index.
 *
 * The `BatchPutDocument` API enables you to ingest inline documents or a set
 * of documents stored in an Amazon S3 bucket. Use this API to ingest your text and
 * unstructured text into an index, add custom attributes to the documents, and to attach
 * an access control list to the documents added to the index.
 *
 * The documents are indexed asynchronously. You can see the progress of the batch using
 * Amazon Web Services
 * CloudWatch. Any error messages related to processing the batch are sent to your
 * Amazon Web Services
 * CloudWatch log. You can also use the `BatchGetDocumentStatus` API to
 * monitor the progress of indexing your documents.
 *
 * For an example of ingesting inline documents using Python and Java SDKs, see Adding files
 * directly to an index.
 */
export declare const batchPutDocument: API.OperationMethod<BatchPutDocumentRequest, BatchPutDocumentResponse, BatchPutDocumentError, Credentials | HttpClient.HttpClient>;
export type ClearQuerySuggestionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Clears existing query suggestions from an index.
 *
 * This deletes existing suggestions only, not the queries
 * in the query log. After you clear suggestions, Amazon Kendra learns
 * new suggestions based on new queries added to the query log
 * from the time you cleared suggestions. If you do not see any
 * new suggestions, then please allow Amazon Kendra to collect
 * enough queries to learn new suggestions.
 *
 * `ClearQuerySuggestions` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const clearQuerySuggestions: API.OperationMethod<ClearQuerySuggestionsRequest, ClearQuerySuggestionsResponse, ClearQuerySuggestionsError, Credentials | HttpClient.HttpClient>;
export type CreateAccessControlConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an access configuration for your documents. This includes user and group
 * access information for your documents. This is useful for user context filtering, where
 * search results are filtered based on the user or their group access to documents.
 *
 * You can use this to re-configure your existing document level access control without
 * indexing all of your documents again. For example, your index contains top-secret
 * company documents that only certain employees or users should access. One of these users
 * leaves the company or switches to a team that should be blocked from accessing
 * top-secret documents. The user still has access to top-secret documents because the user
 * had access when your documents were previously indexed. You can create a specific access
 * control configuration for the user with deny access. You can later update the access
 * control configuration to allow access if the user returns to the company and re-joins
 * the 'top-secret' team. You can re-configure access control for your documents as
 * circumstances change.
 *
 * To apply your access control configuration to certain documents, you call the BatchPutDocument API with the `AccessControlConfigurationId`
 * included in the Document object. If you use an S3 bucket as a data source, you update the
 * `.metadata.json` with the `AccessControlConfigurationId` and
 * synchronize your data source. Amazon Kendra currently only supports access control
 * configuration for S3 data sources and documents indexed using the
 * `BatchPutDocument` API.
 *
 * You can't configure access control using
 * `CreateAccessControlConfiguration` for an Amazon Kendra Gen AI Enterprise
 * Edition index. Amazon Kendra will return a `ValidationException` error for a
 * `Gen_AI_ENTERPRISE_EDITION` index.
 */
export declare const createAccessControlConfiguration: API.OperationMethod<CreateAccessControlConfigurationRequest, CreateAccessControlConfigurationResponse, CreateAccessControlConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceAlreadyExistException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a data source connector that you want to use with an Amazon Kendra
 * index.
 *
 * You specify a name, data source connector type and description for your data source. You
 * also specify configuration information for the data source connector.
 *
 * `CreateDataSource` is a synchronous operation. The operation returns 200 if the
 * data source was successfully created. Otherwise, an exception is raised.
 *
 * For an example of creating an index and data source using the Python SDK, see Getting started with Python
 * SDK. For an example of creating an index and data source using the Java SDK, see
 * Getting started with Java
 * SDK.
 */
export declare const createDataSource: API.OperationMethod<CreateDataSourceRequest, CreateDataSourceResponse, CreateDataSourceError, Credentials | HttpClient.HttpClient>;
export type CreateExperienceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Kendra experience such as a search application. For more information
 * on creating a search application experience, including using the Python and Java SDKs,
 * see Building a
 * search experience with no code.
 */
export declare const createExperience: API.OperationMethod<CreateExperienceRequest, CreateExperienceResponse, CreateExperienceError, Credentials | HttpClient.HttpClient>;
export type CreateFaqError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a set of frequently ask questions (FAQs) using a specified FAQ file stored
 * in an Amazon S3 bucket.
 *
 * Adding FAQs to an index is an asynchronous operation.
 *
 * For an example of adding an FAQ to an index using Python and Java SDKs, see Using your FAQ file.
 */
export declare const createFaq: API.OperationMethod<CreateFaqRequest, CreateFaqResponse, CreateFaqError, Credentials | HttpClient.HttpClient>;
export type CreateFeaturedResultsSetError = AccessDeniedException | ConflictException | FeaturedResultsConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a set of featured results to display at the top of the search results page.
 * Featured results are placed above all other results for certain queries. You map
 * specific queries to specific documents for featuring in the results. If a query
 * contains an exact match, then one or more specific documents are featured in the
 * search results.
 *
 * You can create up to 50 sets of featured results per index. You can request to
 * increase this limit by contacting Support.
 */
export declare const createFeaturedResultsSet: API.OperationMethod<CreateFeaturedResultsSetRequest, CreateFeaturedResultsSetResponse, CreateFeaturedResultsSetError, Credentials | HttpClient.HttpClient>;
export type CreateIndexError = AccessDeniedException | ConflictException | InternalServerException | ResourceAlreadyExistException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Kendra index. Index creation is an asynchronous API. To determine
 * if index creation has completed, check the `Status` field returned from a call to
 * `DescribeIndex`. The `Status` field is set to `ACTIVE` when
 * the index is ready to use.
 *
 * Once the index is active, you can index your documents using the
 * `BatchPutDocument` API or using one of the supported data sources.
 *
 * For an example of creating an index and data source using the Python SDK, see Getting started with Python
 * SDK. For an example of creating an index and data source using the Java SDK, see
 * Getting started with Java
 * SDK.
 */
export declare const createIndex: API.OperationMethod<CreateIndexRequest, CreateIndexResponse, CreateIndexError, Credentials | HttpClient.HttpClient>;
export type CreateQuerySuggestionsBlockListError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a block list to exlcude certain queries from suggestions.
 *
 * Any query that contains words or phrases specified in the block
 * list is blocked or filtered out from being shown as a suggestion.
 *
 * You need to provide the file location of your block list text file
 * in your S3 bucket. In your text file, enter each block word or phrase
 * on a separate line.
 *
 * For information on the current quota limits for block lists, see
 * Quotas
 * for Amazon Kendra.
 *
 * `CreateQuerySuggestionsBlockList` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 *
 * For an example of creating a block list for query suggestions using the
 * Python SDK, see Query
 * suggestions block list.
 */
export declare const createQuerySuggestionsBlockList: API.OperationMethod<CreateQuerySuggestionsBlockListRequest, CreateQuerySuggestionsBlockListResponse, CreateQuerySuggestionsBlockListError, Credentials | HttpClient.HttpClient>;
export type CreateThesaurusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a thesaurus for an index. The thesaurus
 * contains a list of synonyms in Solr format.
 *
 * For an example of adding a thesaurus file to an index, see
 * Adding
 * custom synonyms to an index.
 */
export declare const createThesaurus: API.OperationMethod<CreateThesaurusRequest, CreateThesaurusResponse, CreateThesaurusError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessControlConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an access control configuration that you created for your documents in an
 * index. This includes user and group access information for your documents. This is
 * useful for user context filtering, where search results are filtered based on the user
 * or their group access to documents.
 */
export declare const deleteAccessControlConfiguration: API.OperationMethod<DeleteAccessControlConfigurationRequest, DeleteAccessControlConfigurationResponse, DeleteAccessControlConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Kendra data source connector. An exception is not thrown if the
 * data source is already being deleted. While the data source is being deleted, the
 * `Status` field returned by a call to the `DescribeDataSource` API is
 * set to `DELETING`. For more information, see Deleting Data Sources.
 *
 * Deleting an entire data source or re-syncing your index after deleting specific documents
 * from a data source could take up to an hour or more, depending on the number of documents you
 * want to delete.
 */
export declare const deleteDataSource: API.OperationMethod<DeleteDataSourceRequest, DeleteDataSourceResponse, DeleteDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteExperienceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes your Amazon Kendra experience such as a search application. For more information on
 * creating a search application experience, see Building a search
 * experience with no code.
 */
export declare const deleteExperience: API.OperationMethod<DeleteExperienceRequest, DeleteExperienceResponse, DeleteExperienceError, Credentials | HttpClient.HttpClient>;
export type DeleteFaqError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a FAQ from an index.
 */
export declare const deleteFaq: API.OperationMethod<DeleteFaqRequest, DeleteFaqResponse, DeleteFaqError, Credentials | HttpClient.HttpClient>;
export type DeleteIndexError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Kendra index. An exception is not thrown if the index is already
 * being deleted. While the index is being deleted, the `Status` field returned by a
 * call to the `DescribeIndex` API is set to `DELETING`.
 */
export declare const deleteIndex: API.OperationMethod<DeleteIndexRequest, DeleteIndexResponse, DeleteIndexError, Credentials | HttpClient.HttpClient>;
export type DeletePrincipalMappingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a group so that all users that belong to the group can no
 * longer access documents only available to that group.
 *
 * For example, after deleting the group "Summer Interns", all interns who belonged to
 * that group no longer see intern-only documents in their search results.
 *
 * If you want to delete or replace users or sub groups of a group, you need to use the
 * `PutPrincipalMapping` operation. For example, if a user in the group
 * "Engineering" leaves the engineering team and another user takes their place, you
 * provide an updated list of users or sub groups that belong to the "Engineering" group
 * when calling `PutPrincipalMapping`. You can update your internal list of
 * users or sub groups and input this list when calling
 * `PutPrincipalMapping`.
 *
 * `DeletePrincipalMapping` is currently not supported in the Amazon Web Services GovCloud (US-West) region.
 */
export declare const deletePrincipalMapping: API.OperationMethod<DeletePrincipalMappingRequest, DeletePrincipalMappingResponse, DeletePrincipalMappingError, Credentials | HttpClient.HttpClient>;
export type DeleteQuerySuggestionsBlockListError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a block list used for query suggestions for an index.
 *
 * A deleted block list might not take effect right away. Amazon Kendra
 * needs to refresh the entire suggestions list to add back the
 * queries that were previously blocked.
 *
 * `DeleteQuerySuggestionsBlockList` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const deleteQuerySuggestionsBlockList: API.OperationMethod<DeleteQuerySuggestionsBlockListRequest, DeleteQuerySuggestionsBlockListResponse, DeleteQuerySuggestionsBlockListError, Credentials | HttpClient.HttpClient>;
export type DeleteThesaurusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Kendra thesaurus.
 */
export declare const deleteThesaurus: API.OperationMethod<DeleteThesaurusRequest, DeleteThesaurusResponse, DeleteThesaurusError, Credentials | HttpClient.HttpClient>;
export type DescribeAccessControlConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an access control configuration that you created for your
 * documents in an index. This includes user and group access information for your
 * documents. This is useful for user context filtering, where search results are filtered
 * based on the user or their group access to documents.
 */
export declare const describeAccessControlConfiguration: API.OperationMethod<DescribeAccessControlConfigurationRequest, DescribeAccessControlConfigurationResponse, DescribeAccessControlConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeDataSourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an Amazon Kendra data source connector.
 */
export declare const describeDataSource: API.OperationMethod<DescribeDataSourceRequest, DescribeDataSourceResponse, DescribeDataSourceError, Credentials | HttpClient.HttpClient>;
export type DescribeExperienceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about your Amazon Kendra experience such as a search application.
 * For more information on creating a search application experience,
 * see Building
 * a search experience with no code.
 */
export declare const describeExperience: API.OperationMethod<DescribeExperienceRequest, DescribeExperienceResponse, DescribeExperienceError, Credentials | HttpClient.HttpClient>;
export type DescribeFaqError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a FAQ.
 */
export declare const describeFaq: API.OperationMethod<DescribeFaqRequest, DescribeFaqResponse, DescribeFaqError, Credentials | HttpClient.HttpClient>;
export type DescribeFeaturedResultsSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a set of featured results. Features results are placed
 * above all other results for certain queries. If there's an exact match of a query,
 * then one or more specific documents are featured in the search results.
 */
export declare const describeFeaturedResultsSet: API.OperationMethod<DescribeFeaturedResultsSetRequest, DescribeFeaturedResultsSetResponse, DescribeFeaturedResultsSetError, Credentials | HttpClient.HttpClient>;
export type DescribeIndexError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an Amazon Kendra index.
 */
export declare const describeIndex: API.OperationMethod<DescribeIndexRequest, DescribeIndexResponse, DescribeIndexError, Credentials | HttpClient.HttpClient>;
export type DescribePrincipalMappingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the processing of `PUT` and `DELETE` actions for
 * mapping users to their groups. This includes information on the status of actions
 * currently processing or yet to be processed, when actions were last updated, when
 * actions were received by Amazon Kendra, the latest action that should process and
 * apply after other actions, and useful error messages if an action could not be
 * processed.
 *
 * `DescribePrincipalMapping` is currently not supported in the Amazon Web Services GovCloud (US-West) region.
 */
export declare const describePrincipalMapping: API.OperationMethod<DescribePrincipalMappingRequest, DescribePrincipalMappingResponse, DescribePrincipalMappingError, Credentials | HttpClient.HttpClient>;
export type DescribeQuerySuggestionsBlockListError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a block list used for query suggestions for
 * an index.
 *
 * This is used to check the current settings that are applied to a
 * block list.
 *
 * `DescribeQuerySuggestionsBlockList` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const describeQuerySuggestionsBlockList: API.OperationMethod<DescribeQuerySuggestionsBlockListRequest, DescribeQuerySuggestionsBlockListResponse, DescribeQuerySuggestionsBlockListError, Credentials | HttpClient.HttpClient>;
export type DescribeQuerySuggestionsConfigError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information on the settings of query suggestions for an index.
 *
 * This is used to check the current settings applied
 * to query suggestions.
 *
 * `DescribeQuerySuggestionsConfig` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const describeQuerySuggestionsConfig: API.OperationMethod<DescribeQuerySuggestionsConfigRequest, DescribeQuerySuggestionsConfigResponse, DescribeQuerySuggestionsConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeThesaurusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an Amazon Kendra thesaurus.
 */
export declare const describeThesaurus: API.OperationMethod<DescribeThesaurusRequest, DescribeThesaurusResponse, DescribeThesaurusError, Credentials | HttpClient.HttpClient>;
export type DisassociateEntitiesFromExperienceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Prevents users or groups in your IAM Identity Center identity source
 * from accessing your Amazon Kendra experience. You can create an Amazon Kendra experience
 * such as a search application. For more information on creating a search
 * application experience, see Building
 * a search experience with no code.
 */
export declare const disassociateEntitiesFromExperience: API.OperationMethod<DisassociateEntitiesFromExperienceRequest, DisassociateEntitiesFromExperienceResponse, DisassociateEntitiesFromExperienceError, Credentials | HttpClient.HttpClient>;
export type DisassociatePersonasFromEntitiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the specific permissions of users or groups in your IAM Identity Center
 * identity source with access to your Amazon Kendra experience. You can create an Amazon Kendra
 * experience such as a search application. For more information on creating a
 * search application experience, see Building a
 * search experience with no code.
 */
export declare const disassociatePersonasFromEntities: API.OperationMethod<DisassociatePersonasFromEntitiesRequest, DisassociatePersonasFromEntitiesResponse, DisassociatePersonasFromEntitiesError, Credentials | HttpClient.HttpClient>;
export type GetQuerySuggestionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Fetches the queries that are suggested to your users.
 *
 * `GetQuerySuggestions` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const getQuerySuggestions: API.OperationMethod<GetQuerySuggestionsRequest, GetQuerySuggestionsResponse, GetQuerySuggestionsError, Credentials | HttpClient.HttpClient>;
export type GetSnapshotsError = AccessDeniedException | InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves search metrics data. The data provides a snapshot of how your users interact
 * with your search application and how effective the application is.
 */
export declare const getSnapshots: API.PaginatedOperationMethod<GetSnapshotsRequest, GetSnapshotsResponse, GetSnapshotsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAccessControlConfigurationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists one or more access control configurations for an index. This includes user and
 * group access information for your documents. This is useful for user context filtering,
 * where search results are filtered based on the user or their group access to
 * documents.
 */
export declare const listAccessControlConfigurations: API.PaginatedOperationMethod<ListAccessControlConfigurationsRequest, ListAccessControlConfigurationsResponse, ListAccessControlConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataSourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the data source connectors that you have created.
 */
export declare const listDataSources: API.PaginatedOperationMethod<ListDataSourcesRequest, ListDataSourcesResponse, ListDataSourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataSourceSyncJobsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets statistics about synchronizing a data source connector.
 */
export declare const listDataSourceSyncJobs: API.PaginatedOperationMethod<ListDataSourceSyncJobsRequest, ListDataSourceSyncJobsResponse, ListDataSourceSyncJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEntityPersonasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists specific permissions of users and groups with access to your
 * Amazon Kendra experience.
 */
export declare const listEntityPersonas: API.PaginatedOperationMethod<ListEntityPersonasRequest, ListEntityPersonasResponse, ListEntityPersonasError, Credentials | HttpClient.HttpClient, unknown>;
export type ListExperienceEntitiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists users or groups in your IAM Identity Center identity source that are
 * granted access to your Amazon Kendra experience. You can create an Amazon Kendra experience
 * such as a search application. For more information on creating a search
 * application experience, see Building
 * a search experience with no code.
 */
export declare const listExperienceEntities: API.PaginatedOperationMethod<ListExperienceEntitiesRequest, ListExperienceEntitiesResponse, ListExperienceEntitiesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListExperiencesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists one or more Amazon Kendra experiences. You can create an Amazon Kendra experience such
 * as a search application. For more information on creating a search application
 * experience, see Building a
 * search experience with no code.
 */
export declare const listExperiences: API.PaginatedOperationMethod<ListExperiencesRequest, ListExperiencesResponse, ListExperiencesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFaqsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of FAQs associated with an index.
 */
export declare const listFaqs: API.PaginatedOperationMethod<ListFaqsRequest, ListFaqsResponse, ListFaqsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFeaturedResultsSetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all your sets of featured results for a given index. Features results
 * are placed above all other results for certain queries. If there's an exact match
 * of a query, then one or more specific documents are featured in the search results.
 */
export declare const listFeaturedResultsSets: API.OperationMethod<ListFeaturedResultsSetsRequest, ListFeaturedResultsSetsResponse, ListFeaturedResultsSetsError, Credentials | HttpClient.HttpClient>;
export type ListGroupsOlderThanOrderingIdError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides a list of groups that are mapped to users before a given ordering or
 * timestamp identifier.
 *
 * `ListGroupsOlderThanOrderingId` is currently not supported in the Amazon Web Services GovCloud (US-West) region.
 */
export declare const listGroupsOlderThanOrderingId: API.PaginatedOperationMethod<ListGroupsOlderThanOrderingIdRequest, ListGroupsOlderThanOrderingIdResponse, ListGroupsOlderThanOrderingIdError, Credentials | HttpClient.HttpClient, unknown>;
export type ListIndicesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Amazon Kendra indexes that you created.
 */
export declare const listIndices: API.PaginatedOperationMethod<ListIndicesRequest, ListIndicesResponse, ListIndicesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListQuerySuggestionsBlockListsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the block lists used for query suggestions for an index.
 *
 * For information on the current quota limits for block lists, see
 * Quotas
 * for Amazon Kendra.
 *
 * `ListQuerySuggestionsBlockLists` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const listQuerySuggestionsBlockLists: API.PaginatedOperationMethod<ListQuerySuggestionsBlockListsRequest, ListQuerySuggestionsBlockListsResponse, ListQuerySuggestionsBlockListsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceUnavailableException | ThrottlingException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a list of tags associated with a resource. Indexes, FAQs, data sources, and
 * other resources can have tags associated with them.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListThesauriError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the thesauri for an index.
 */
export declare const listThesauri: API.PaginatedOperationMethod<ListThesauriRequest, ListThesauriResponse, ListThesauriError, Credentials | HttpClient.HttpClient, unknown>;
export type PutPrincipalMappingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Maps users to their groups so that you only need to provide the user ID when you issue
 * the query.
 *
 * You can also map sub groups to groups. For example, the group "Company Intellectual
 * Property Teams" includes sub groups "Research" and "Engineering". These sub groups
 * include their own list of users or people who work in these teams. Only users who work
 * in research and engineering, and therefore belong in the intellectual property group,
 * can see top-secret company documents in their search results.
 *
 * This is useful for user context filtering, where search results are filtered based on
 * the user or their group access to documents. For more information, see Filtering on
 * user context.
 *
 * If more than five `PUT` actions for a group are currently processing, a
 * validation exception is thrown.
 */
export declare const putPrincipalMapping: API.OperationMethod<PutPrincipalMappingRequest, PutPrincipalMappingResponse, PutPrincipalMappingError, Credentials | HttpClient.HttpClient>;
export type QueryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches an index given an input query.
 *
 * If you are working with large language models (LLMs) or implementing retrieval
 * augmented generation (RAG) systems, you can use Amazon Kendra's Retrieve API, which can return longer semantically relevant passages. We
 * recommend using the `Retrieve` API instead of filing a service limit increase
 * to increase the `Query` API document excerpt length.
 *
 * You can configure boosting or relevance tuning at the query level to override boosting
 * at the index level, filter based on document fields/attributes and faceted search, and
 * filter based on the user or their group access to documents. You can also include certain
 * fields in the response that might provide useful additional information.
 *
 * A query response contains three types of results.
 *
 * - Relevant suggested answers. The answers can be either a text excerpt or table
 * excerpt. The answer can be highlighted in the excerpt.
 *
 * - Matching FAQs or questions-answer from your FAQ file.
 *
 * - Relevant documents. This result type includes an excerpt of the document with the
 * document title. The searched terms can be highlighted in the excerpt.
 *
 * You can specify that the query return only one type of result using the
 * `QueryResultTypeFilter` parameter. Each query returns the 100 most relevant
 * results. If you filter result type to only question-answers, a maximum of four results are
 * returned. If you filter result type to only answers, a maximum of three results are
 * returned.
 *
 * If you're using an Amazon Kendra Gen AI Enterprise Edition index, you can only use
 * `ATTRIBUTE_FILTER` to filter search results by user context. If you're
 * using an Amazon Kendra Gen AI Enterprise Edition index and you try to use
 * `USER_TOKEN` to configure user context policy, Amazon Kendra returns a
 * `ValidationException` error.
 */
export declare const query: API.OperationMethod<QueryRequest, QueryResult, QueryError, Credentials | HttpClient.HttpClient>;
export type RetrieveError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves relevant passages or text excerpts given an input query.
 *
 * This API is similar to the Query API. However, by
 * default, the `Query` API only returns excerpt passages of up to 100 token
 * words. With the `Retrieve` API, you can retrieve longer passages of up to 200
 * token words and up to 100 semantically relevant passages. This doesn't include
 * question-answer or FAQ type responses from your index. The passages are text excerpts
 * that can be semantically extracted from multiple documents and multiple parts of the
 * same document. If in extreme cases your documents produce zero passages using the
 * `Retrieve` API, you can alternatively use the `Query` API and
 * its types of responses.
 *
 * You can also do the following:
 *
 * - Override boosting at the index level
 *
 * - Filter based on document fields or attributes
 *
 * - Filter based on the user or their group access to documents
 *
 * - View the confidence score bucket for a retrieved passage result. The
 * confidence bucket provides a relative ranking that indicates how confident
 * Amazon Kendra is that the response is relevant to the query.
 *
 * Confidence score buckets are currently available only for English.
 *
 * You can also include certain fields in the response that might provide useful
 * additional information.
 *
 * The `Retrieve` API shares the number of query capacity
 * units that you set for your index. For more information on what's included
 * in a single capacity unit and the default base capacity for an index, see Adjusting
 * capacity.
 *
 * If you're using an Amazon Kendra Gen AI Enterprise Edition index, you can only use
 * `ATTRIBUTE_FILTER` to filter search results by user context. If
 * you're using an Amazon Kendra Gen AI Enterprise Edition index and you try to use
 * `USER_TOKEN` to configure user context policy, Amazon Kendra returns a
 * `ValidationException` error.
 */
export declare const retrieve: API.OperationMethod<RetrieveRequest, RetrieveResult, RetrieveError, Credentials | HttpClient.HttpClient>;
export type StartDataSourceSyncJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a synchronization job for a data source connector. If a synchronization job is
 * already in progress, Amazon Kendra returns a `ResourceInUseException`
 * exception.
 *
 * Re-syncing your data source with your index after modifying, adding, or deleting
 * documents from your data source respository could take up to an hour or more, depending on
 * the number of documents to sync.
 */
export declare const startDataSourceSyncJob: API.OperationMethod<StartDataSourceSyncJobRequest, StartDataSourceSyncJobResponse, StartDataSourceSyncJobError, Credentials | HttpClient.HttpClient>;
export type StopDataSourceSyncJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a synchronization job that is currently running. You can't stop a scheduled
 * synchronization job.
 */
export declare const stopDataSourceSyncJob: API.OperationMethod<StopDataSourceSyncJobRequest, StopDataSourceSyncJobResponse, StopDataSourceSyncJobError, Credentials | HttpClient.HttpClient>;
export type SubmitFeedbackError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables you to provide feedback to Amazon Kendra to improve the
 * performance of your index.
 *
 * `SubmitFeedback` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const submitFeedback: API.OperationMethod<SubmitFeedbackRequest, SubmitFeedbackResponse, SubmitFeedbackError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds the specified tag to the specified index, FAQ, data source, or other resource. If
 * the tag already exists, the existing value is replaced with the new value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag from an index, FAQ, data source, or other resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccessControlConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an access control configuration for your documents in an index. This includes
 * user and group access information for your documents. This is useful for user context
 * filtering, where search results are filtered based on the user or their group access to
 * documents.
 *
 * You can update an access control configuration you created without indexing all of
 * your documents again. For example, your index contains top-secret company documents that
 * only certain employees or users should access. You created an 'allow' access control
 * configuration for one user who recently joined the 'top-secret' team, switching from a
 * team with 'deny' access to top-secret documents. However, the user suddenly returns to
 * their previous team and should no longer have access to top secret documents. You can
 * update the access control configuration to re-configure access control for your
 * documents as circumstances change.
 *
 * You call the BatchPutDocument API to
 * apply the updated access control configuration, with the
 * `AccessControlConfigurationId` included in the Document
 * object. If you use an S3 bucket as a data source, you synchronize your data source to
 * apply the `AccessControlConfigurationId` in the `.metadata.json`
 * file. Amazon Kendra currently only supports access control configuration for S3
 * data sources and documents indexed using the `BatchPutDocument` API.
 *
 * You can't configure access control using
 * `CreateAccessControlConfiguration` for an Amazon Kendra Gen AI Enterprise
 * Edition index. Amazon Kendra will return a `ValidationException` error for a
 * `Gen_AI_ENTERPRISE_EDITION` index.
 */
export declare const updateAccessControlConfiguration: API.OperationMethod<UpdateAccessControlConfigurationRequest, UpdateAccessControlConfigurationResponse, UpdateAccessControlConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Kendra data source connector.
 */
export declare const updateDataSource: API.OperationMethod<UpdateDataSourceRequest, UpdateDataSourceResponse, UpdateDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateExperienceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates your Amazon Kendra experience such as a search application. For more information on
 * creating a search application experience, see Building a
 * search experience with no code.
 */
export declare const updateExperience: API.OperationMethod<UpdateExperienceRequest, UpdateExperienceResponse, UpdateExperienceError, Credentials | HttpClient.HttpClient>;
export type UpdateFeaturedResultsSetError = AccessDeniedException | FeaturedResultsConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a set of featured results. Features results are placed
 * above
 * all other results for certain queries. You map specific queries to specific documents
 * for featuring in the results. If a query contains an exact match of a query, then one
 * or more specific documents are featured in the search results.
 */
export declare const updateFeaturedResultsSet: API.OperationMethod<UpdateFeaturedResultsSetRequest, UpdateFeaturedResultsSetResponse, UpdateFeaturedResultsSetError, Credentials | HttpClient.HttpClient>;
export type UpdateIndexError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Kendra index.
 */
export declare const updateIndex: API.OperationMethod<UpdateIndexRequest, UpdateIndexResponse, UpdateIndexError, Credentials | HttpClient.HttpClient>;
export type UpdateQuerySuggestionsBlockListError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a block list used for query suggestions for an index.
 *
 * Updates to a block list might not take effect right away. Amazon Kendra
 * needs to refresh the entire suggestions list to apply any updates to the
 * block list. Other changes not related to the block list apply immediately.
 *
 * If a block list is updating, then you need to wait for the first update to
 * finish before submitting another update.
 *
 * Amazon Kendra supports partial updates, so you only need to provide the fields
 * you want to update.
 *
 * `UpdateQuerySuggestionsBlockList` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const updateQuerySuggestionsBlockList: API.OperationMethod<UpdateQuerySuggestionsBlockListRequest, UpdateQuerySuggestionsBlockListResponse, UpdateQuerySuggestionsBlockListError, Credentials | HttpClient.HttpClient>;
export type UpdateQuerySuggestionsConfigError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the settings of query suggestions for an index.
 *
 * Amazon Kendra supports partial updates, so you only need to provide
 * the fields you want to update.
 *
 * If an update is currently processing, you
 * need to wait for the update to finish before making another update.
 *
 * Updates to query suggestions settings might not take effect right away.
 * The time for your updated settings to take effect depends on the updates
 * made and the number of search queries in your index.
 *
 * You can still enable/disable query suggestions at any time.
 *
 * `UpdateQuerySuggestionsConfig` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const updateQuerySuggestionsConfig: API.OperationMethod<UpdateQuerySuggestionsConfigRequest, UpdateQuerySuggestionsConfigResponse, UpdateQuerySuggestionsConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateThesaurusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a thesaurus for an index.
 */
export declare const updateThesaurus: API.OperationMethod<UpdateThesaurusRequest, UpdateThesaurusResponse, UpdateThesaurusError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=kendra.d.ts.map