import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AgentMessageOutOfContextException_base: S.Class<AgentMessageOutOfContextException, S.TaggedStruct<"AgentMessageOutOfContextException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AgentMessageOutOfContextException extends /*@__PURE__*/ AgentMessageOutOfContextException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ConversationNotFoundException_base: S.Class<ConversationNotFoundException, S.TaggedStruct<"ConversationNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConversationNotFoundException extends /*@__PURE__*/ ConversationNotFoundException_base {
}
declare const FailedDependencyException_base: S.Class<FailedDependencyException, S.TaggedStruct<"FailedDependencyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FailedDependencyException extends /*@__PURE__*/ FailedDependencyException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const NotImplementedOperationException_base: S.Class<NotImplementedOperationException, S.TaggedStruct<"NotImplementedOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class NotImplementedOperationException extends /*@__PURE__*/ NotImplementedOperationException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const UnsupportedMIMETypeException_base: S.Class<UnsupportedMIMETypeException, S.TaggedStruct<"UnsupportedMIMETypeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedMIMETypeException extends /*@__PURE__*/ UnsupportedMIMETypeException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SourceFormat = "CCDA" | "CSV" | (string & {});
export declare const SourceFormat: any;
export interface StarterProfileSource {
    StarterProfileName: string;
}
export declare const StarterProfileSource: S.Schema<StarterProfileSource>;
export interface ExistingVersionedProfileSource {
    ProfileId: string;
    Version: number;
}
export declare const ExistingVersionedProfileSource: S.Schema<ExistingVersionedProfileSource>;
export type StringMap = {
    [key: string]: string | undefined;
};
export declare const StringMap: any;
export interface ProfileMappingSource {
    ProfileMapping: {
        [key: string]: string | undefined;
    };
}
export declare const ProfileMappingSource: S.Schema<ProfileMappingSource>;
export type SampleDataS3Uri = string;
export interface SampleDataSource {
    S3Uri: string;
}
export declare const SampleDataSource: S.Schema<SampleDataSource>;
export type CreateDataTransformationProfileSource = {
    StarterProfile: StarterProfileSource;
    ExistingVersionedProfileId?: never;
    ProfileMapping?: never;
    SampleData?: never;
} | {
    StarterProfile?: never;
    ExistingVersionedProfileId: ExistingVersionedProfileSource;
    ProfileMapping?: never;
    SampleData?: never;
} | {
    StarterProfile?: never;
    ExistingVersionedProfileId?: never;
    ProfileMapping: ProfileMappingSource;
    SampleData?: never;
} | {
    StarterProfile?: never;
    ExistingVersionedProfileId?: never;
    ProfileMapping?: never;
    SampleData: SampleDataSource;
};
export declare const CreateDataTransformationProfileSource: any;
export type KmsKeyId = string;
export type ProfileDescription = string;
export type ProfileNameString = string;
export type DataTransformationTagKey = string;
export type DataTransformationTagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type ClientToken = string;
export interface CreateDataTransformationProfileRequest {
    SourceFormat: SourceFormat;
    Source: CreateDataTransformationProfileSource;
    KmsKeyId?: string;
    ProfileDescription?: string;
    ProfileName: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export declare const CreateDataTransformationProfileRequest: S.Schema<CreateDataTransformationProfileRequest>;
export type ProfileIdString = string;
export type ProfileVersion = number;
export type TargetFormat = "FHIR_R4" | (string & {});
export declare const TargetFormat: any;
export interface CreateDataTransformationProfileResponse {
    ProfileId: string;
    Version: number;
    SourceFormat: SourceFormat;
    TargetFormat: TargetFormat;
    ProfileName: string;
    LastUpdatedAt: Date;
}
export declare const CreateDataTransformationProfileResponse: S.Schema<CreateDataTransformationProfileResponse>;
export type DatastoreName = string;
export type FHIRVersion = "R4" | (string & {});
export declare const FHIRVersion: any;
export type CmkType = "CUSTOMER_MANAGED_KMS_KEY" | "AWS_OWNED_KMS_KEY" | (string & {});
export declare const CmkType: any;
export type EncryptionKeyID = string;
export interface KmsEncryptionConfig {
    CmkType: CmkType;
    KmsKeyId?: string;
}
export declare const KmsEncryptionConfig: S.Schema<KmsEncryptionConfig>;
export interface SseConfiguration {
    KmsEncryptionConfig: KmsEncryptionConfig;
}
export declare const SseConfiguration: S.Schema<SseConfiguration>;
export type PreloadDataType = "SYNTHEA" | (string & {});
export declare const PreloadDataType: any;
export interface PreloadDataConfig {
    PreloadDataType: PreloadDataType;
}
export declare const PreloadDataConfig: S.Schema<PreloadDataConfig>;
export type ClientTokenString = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type AuthorizationStrategy = "SMART_ON_FHIR_V1" | "SMART_ON_FHIR" | "AWS_AUTH" | (string & {});
export declare const AuthorizationStrategy: any;
export type HealthLakeBoolean = boolean;
export type ConfigurationMetadata = string;
export type LambdaArn = string;
export interface IdentityProviderConfiguration {
    AuthorizationStrategy: AuthorizationStrategy;
    FineGrainedAuthorizationEnabled?: boolean;
    Metadata?: string;
    IdpLambdaArn?: string;
}
export declare const IdentityProviderConfiguration: S.Schema<IdentityProviderConfiguration>;
export type AnalyticsStatus = "ENABLED" | "ENABLING" | "DISABLED" | "DISABLING" | "PAUSING" | "PAUSED" | (string & {});
export declare const AnalyticsStatus: any;
export interface AnalyticsConfiguration {
    Status?: AnalyticsStatus;
}
export declare const AnalyticsConfiguration: S.Schema<AnalyticsConfiguration>;
export type NlpStatus = "ENABLED" | "ENABLING" | "DISABLED" | "DISABLING" | (string & {});
export declare const NlpStatus: any;
export interface NlpConfiguration {
    Status?: NlpStatus;
}
export declare const NlpConfiguration: S.Schema<NlpConfiguration>;
export type HealthLakeString = string;
export type DefaultProfiles = string[];
export declare const DefaultProfiles: any;
export interface ProfileConfiguration {
    DefaultProfiles?: string[];
}
export declare const ProfileConfiguration: S.Schema<ProfileConfiguration>;
export type BackupStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const BackupStatus: any;
export type BackupType = "CONTINUOUS" | (string & {});
export declare const BackupType: any;
export type BackupRetentionPeriodInDays = number;
export interface BackupConfiguration {
    Status?: BackupStatus;
    BackupType?: BackupType;
    RetentionPeriodInDays?: number;
    BackupTagsEnabled?: boolean;
}
export declare const BackupConfiguration: S.Schema<BackupConfiguration>;
export interface CreateFHIRDatastoreRequest {
    DatastoreName?: string;
    DatastoreTypeVersion: FHIRVersion;
    SseConfiguration?: SseConfiguration;
    PreloadDataConfig?: PreloadDataConfig;
    ClientToken?: string;
    Tags?: Tag[];
    IdentityProviderConfiguration?: IdentityProviderConfiguration;
    AnalyticsConfiguration?: AnalyticsConfiguration;
    NlpConfiguration?: NlpConfiguration;
    ProfileConfiguration?: ProfileConfiguration;
    BackupConfiguration?: BackupConfiguration;
}
export declare const CreateFHIRDatastoreRequest: S.Schema<CreateFHIRDatastoreRequest>;
export type DatastoreId = string;
export type DatastoreArn = string;
export type DatastoreStatus = "CREATING" | "ACTIVE" | "DELETING" | "DELETED" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | (string & {});
export declare const DatastoreStatus: any;
export type BoundedLengthString = string;
export interface CreateFHIRDatastoreResponse {
    DatastoreId: string;
    DatastoreArn: string;
    DatastoreStatus: DatastoreStatus;
    DatastoreEndpoint: string;
}
export declare const CreateFHIRDatastoreResponse: S.Schema<CreateFHIRDatastoreResponse>;
export interface DeleteDataTransformationProfileRequest {
    ProfileId: string;
}
export declare const DeleteDataTransformationProfileRequest: S.Schema<DeleteDataTransformationProfileRequest>;
export interface DeleteDataTransformationProfileResponse {
    ProfileId: string;
    ProfileName?: string;
    DeletionTime: Date;
}
export declare const DeleteDataTransformationProfileResponse: S.Schema<DeleteDataTransformationProfileResponse>;
export interface DeleteFHIRDatastoreRequest {
    DatastoreId: string;
}
export declare const DeleteFHIRDatastoreRequest: S.Schema<DeleteFHIRDatastoreRequest>;
export interface DeleteFHIRDatastoreResponse {
    DatastoreId: string;
    DatastoreArn: string;
    DatastoreStatus: DatastoreStatus;
    DatastoreEndpoint: string;
}
export declare const DeleteFHIRDatastoreResponse: S.Schema<DeleteFHIRDatastoreResponse>;
export type DataTransformationJobId = string;
export interface DescribeDataTransformationJobRequest {
    JobId: string;
}
export declare const DescribeDataTransformationJobRequest: S.Schema<DescribeDataTransformationJobRequest>;
export type TransformationJobStatus = "SUBMITTED" | "QUEUED" | "IN_PROGRESS" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "FAILED" | (string & {});
export declare const TransformationJobStatus: any;
export type DataTransformationS3Uri = string;
export interface TransformationInputDataConfig {
    S3Uri: string;
    SourceFormat?: SourceFormat;
}
export declare const TransformationInputDataConfig: S.Schema<TransformationInputDataConfig>;
export interface DataTransformationS3Configuration {
    S3Uri: string;
    KmsKeyId: string;
}
export declare const DataTransformationS3Configuration: S.Schema<DataTransformationS3Configuration>;
export interface TransformationOutputDataConfig {
    S3Configuration: DataTransformationS3Configuration;
}
export declare const TransformationOutputDataConfig: S.Schema<TransformationOutputDataConfig>;
export type DataTransformationIamRoleArn = string;
export type DataTransformationJobName = string;
export type BoundedString = string;
export interface TransformationJobProgressReport {
    TotalFilesScanned: number;
    TotalFilesConverted: number;
    TotalFilesFailed: number;
    TotalResourcesGenerated: number;
}
export declare const TransformationJobProgressReport: S.Schema<TransformationJobProgressReport>;
export interface TransformationJobProperties {
    JobId: string;
    JobStatus: TransformationJobStatus;
    InputDataConfig: TransformationInputDataConfig;
    OutputDataConfig: TransformationOutputDataConfig;
    DataAccessRoleArn: string;
    SubmitTime: Date;
    JobName?: string;
    ProfileId?: string;
    ProfileName?: string;
    ProfileVersion?: number;
    EndTime?: Date;
    DriftDetectionEnabled?: boolean;
    ProvenanceEnabled?: boolean;
    Message?: string;
    JobProgressReport?: TransformationJobProgressReport;
}
export declare const TransformationJobProperties: S.Schema<TransformationJobProperties>;
export interface DescribeDataTransformationJobResponse {
    TransformationJobProperties: TransformationJobProperties;
}
export declare const DescribeDataTransformationJobResponse: S.Schema<DescribeDataTransformationJobResponse>;
export interface DescribeFHIRDatastoreRequest {
    DatastoreId: string;
}
export declare const DescribeFHIRDatastoreRequest: S.Schema<DescribeFHIRDatastoreRequest>;
export type HealthLakeTimestamp = Date;
export type ErrorMessage = string;
export type ErrorCategory = "RETRYABLE_ERROR" | "NON_RETRYABLE_ERROR" | (string & {});
export declare const ErrorCategory: any;
export interface ErrorCause {
    ErrorMessage?: string;
    ErrorCategory?: ErrorCategory;
}
export declare const ErrorCause: S.Schema<ErrorCause>;
export interface DatastoreBackupStatus {
    Configuration?: BackupConfiguration;
    BackupEnabledAt?: Date;
    EarliestRestorePoint?: Date;
    LatestRestorePoint?: Date;
    ScheduledPermanentDeletionTime?: Date;
}
export declare const DatastoreBackupStatus: S.Schema<DatastoreBackupStatus>;
export interface DatastoreProperties {
    DatastoreId: string;
    DatastoreArn: string;
    DatastoreName?: string;
    DatastoreStatus: DatastoreStatus;
    CreatedAt?: Date;
    DatastoreTypeVersion: FHIRVersion;
    DatastoreEndpoint: string;
    SseConfiguration?: SseConfiguration;
    PreloadDataConfig?: PreloadDataConfig;
    IdentityProviderConfiguration?: IdentityProviderConfiguration;
    ErrorCause?: ErrorCause;
    NlpConfiguration?: NlpConfiguration;
    AnalyticsConfiguration?: AnalyticsConfiguration;
    ProfileConfiguration?: ProfileConfiguration;
    BackupStatusInfo?: DatastoreBackupStatus;
}
export declare const DatastoreProperties: S.Schema<DatastoreProperties>;
export interface DescribeFHIRDatastoreResponse {
    DatastoreProperties: DatastoreProperties;
}
export declare const DescribeFHIRDatastoreResponse: S.Schema<DescribeFHIRDatastoreResponse>;
export type JobId = string;
export interface DescribeFHIRExportJobRequest {
    DatastoreId: string;
    JobId: string;
}
export declare const DescribeFHIRExportJobRequest: S.Schema<DescribeFHIRExportJobRequest>;
export type JobName = string;
export type JobStatus = "SUBMITTED" | "QUEUED" | "IN_PROGRESS" | "COMPLETED_WITH_ERRORS" | "COMPLETED" | "FAILED" | "CANCEL_SUBMITTED" | "CANCEL_IN_PROGRESS" | "CANCEL_COMPLETED" | "CANCEL_FAILED" | (string & {});
export declare const JobStatus: any;
export type S3Uri = string;
export interface S3Configuration {
    S3Uri: string;
    KmsKeyId: string;
}
export declare const S3Configuration: S.Schema<S3Configuration>;
export type OutputDataConfig = {
    S3Configuration: S3Configuration;
};
export declare const OutputDataConfig: any;
export type IamRoleArn = string;
export type Message = string;
export interface ExportJobProperties {
    JobId: string;
    JobName?: string;
    JobStatus: JobStatus;
    SubmitTime: Date;
    EndTime?: Date;
    DatastoreId: string;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn?: string;
    Message?: string;
}
export declare const ExportJobProperties: S.Schema<ExportJobProperties>;
export interface DescribeFHIRExportJobResponse {
    ExportJobProperties: ExportJobProperties;
}
export declare const DescribeFHIRExportJobResponse: S.Schema<DescribeFHIRExportJobResponse>;
export interface DescribeFHIRImportJobRequest {
    DatastoreId: string;
    JobId: string;
}
export declare const DescribeFHIRImportJobRequest: S.Schema<DescribeFHIRImportJobRequest>;
export type InputDataConfig = {
    S3Uri: string;
};
export declare const InputDataConfig: any;
export interface JobProgressReport {
    TotalNumberOfScannedFiles?: number;
    TotalSizeOfScannedFilesInMB?: number;
    TotalNumberOfImportedFiles?: number;
    TotalNumberOfResourcesScanned?: number;
    TotalNumberOfResourcesImported?: number;
    TotalNumberOfResourcesWithCustomerError?: number;
    TotalNumberOfFilesReadWithCustomerError?: number;
    TotalNumberOfScannedNonFhirFiles?: number;
    TotalSizeOfScannedNonFhirFilesInMB?: number;
    TotalNumberOfImportedNonFhirFiles?: number;
    TotalNumberOfNonFhirResourcesScanned?: number;
    TotalNumberOfNonFhirResourcesImported?: number;
    TotalNumberOfNonFhirResourcesWithCustomerError?: number;
    TotalNumberOfNonFhirFilesReadWithCustomerError?: number;
    Throughput?: number;
    TotalFilesConverted?: number;
    TotalResourcesGenerated?: number;
}
export declare const JobProgressReport: S.Schema<JobProgressReport>;
export type ValidationLevel = "strict" | "structure-only" | "minimal" | (string & {});
export declare const ValidationLevel: any;
export interface ImportJobProperties {
    JobId: string;
    JobName?: string;
    JobStatus: JobStatus;
    SubmitTime: Date;
    EndTime?: Date;
    DatastoreId: string;
    InputDataConfig: InputDataConfig;
    JobOutputDataConfig?: OutputDataConfig;
    JobProgressReport?: JobProgressReport;
    DataAccessRoleArn?: string;
    Message?: string;
    ValidationLevel?: ValidationLevel;
}
export declare const ImportJobProperties: S.Schema<ImportJobProperties>;
export interface DescribeFHIRImportJobResponse {
    ImportJobProperties: ImportJobProperties;
}
export declare const DescribeFHIRImportJobResponse: S.Schema<DescribeFHIRImportJobResponse>;
export interface GetDataTransformationProfileRequest {
    ProfileId: string;
    ProfileVersion?: number;
}
export declare const GetDataTransformationProfileRequest: S.Schema<GetDataTransformationProfileRequest>;
export type ProfileMappingKey = string;
export type ProfileMappingValue = string;
export type ProfileMapping = {
    [key: string]: string | undefined;
};
export declare const ProfileMapping: any;
export type ChangeDescription = string;
export interface GetDataTransformationProfileResponse {
    ProfileId: string;
    Version: number;
    SourceFormat: SourceFormat;
    TargetFormat: TargetFormat;
    ProfileMapping: {
        [key: string]: string | undefined;
    };
    ProfileName?: string;
    ProfileDescription?: string;
    ChangeDescription?: string;
    LastUpdatedAt: Date;
}
export declare const GetDataTransformationProfileResponse: S.Schema<GetDataTransformationProfileResponse>;
export type MaxResults = number;
export type DataTransformationNextToken = string;
export interface ListDataTransformationJobsRequest {
    MaxResults?: number;
    NextToken?: string;
    JobStatus?: TransformationJobStatus;
    JobName?: string;
    SubmittedAfter?: Date;
    SubmittedBefore?: Date;
}
export declare const ListDataTransformationJobsRequest: S.Schema<ListDataTransformationJobsRequest>;
export interface TransformationJobSummary {
    JobId: string;
    JobStatus: TransformationJobStatus;
    SubmitTime: Date;
    JobName?: string;
    EndTime?: Date;
    SourceFormat?: SourceFormat;
}
export declare const TransformationJobSummary: S.Schema<TransformationJobSummary>;
export type TransformationJobSummaryList = TransformationJobSummary[];
export declare const TransformationJobSummaryList: any;
export interface ListDataTransformationJobsResponse {
    Items: TransformationJobSummary[];
    NextToken?: string;
}
export declare const ListDataTransformationJobsResponse: S.Schema<ListDataTransformationJobsResponse>;
export interface ListDataTransformationProfilesRequest {
    SourceFormat: SourceFormat;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDataTransformationProfilesRequest: S.Schema<ListDataTransformationProfilesRequest>;
export interface DataTransformationProfileSummary {
    ProfileId: string;
    Version: number;
    SourceFormat: SourceFormat;
    TargetFormat: TargetFormat;
    ProfileName?: string;
    ProfileDescription?: string;
    LastUpdatedAt?: Date;
}
export declare const DataTransformationProfileSummary: S.Schema<DataTransformationProfileSummary>;
export type DataTransformationProfileSummaryList = DataTransformationProfileSummary[];
export declare const DataTransformationProfileSummaryList: any;
export interface ListDataTransformationProfilesResponse {
    Items: DataTransformationProfileSummary[];
    NextToken?: string;
}
export declare const ListDataTransformationProfilesResponse: S.Schema<ListDataTransformationProfilesResponse>;
export interface ListDataTransformationProfileVersionsRequest {
    ProfileId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDataTransformationProfileVersionsRequest: S.Schema<ListDataTransformationProfileVersionsRequest>;
export interface DataTransformationProfileVersionSummary {
    ProfileId: string;
    Version: number;
    SourceFormat: SourceFormat;
    TargetFormat: TargetFormat;
    ProfileName?: string;
    ChangeDescription?: string;
    LastUpdatedAt?: Date;
}
export declare const DataTransformationProfileVersionSummary: S.Schema<DataTransformationProfileVersionSummary>;
export type DataTransformationProfileVersionSummaryList = DataTransformationProfileVersionSummary[];
export declare const DataTransformationProfileVersionSummaryList: any;
export interface ListDataTransformationProfileVersionsResponse {
    Items: DataTransformationProfileVersionSummary[];
    NextToken?: string;
}
export declare const ListDataTransformationProfileVersionsResponse: S.Schema<ListDataTransformationProfileVersionsResponse>;
export interface DatastoreFilter {
    DatastoreName?: string;
    DatastoreStatus?: DatastoreStatus;
    CreatedBefore?: Date;
    CreatedAfter?: Date;
}
export declare const DatastoreFilter: S.Schema<DatastoreFilter>;
export type NextToken = string;
export type MaxResultsInteger = number;
export interface ListFHIRDatastoresRequest {
    Filter?: DatastoreFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListFHIRDatastoresRequest: S.Schema<ListFHIRDatastoresRequest>;
export type DatastorePropertiesList = DatastoreProperties[];
export declare const DatastorePropertiesList: any;
export interface ListFHIRDatastoresResponse {
    DatastorePropertiesList: DatastoreProperties[];
    NextToken?: string;
}
export declare const ListFHIRDatastoresResponse: S.Schema<ListFHIRDatastoresResponse>;
export interface ListFHIRExportJobsRequest {
    DatastoreId: string;
    NextToken?: string;
    MaxResults?: number;
    JobName?: string;
    JobStatus?: JobStatus;
    SubmittedBefore?: Date;
    SubmittedAfter?: Date;
}
export declare const ListFHIRExportJobsRequest: S.Schema<ListFHIRExportJobsRequest>;
export type ExportJobPropertiesList = ExportJobProperties[];
export declare const ExportJobPropertiesList: any;
export interface ListFHIRExportJobsResponse {
    ExportJobPropertiesList: ExportJobProperties[];
    NextToken?: string;
}
export declare const ListFHIRExportJobsResponse: S.Schema<ListFHIRExportJobsResponse>;
export interface ListFHIRImportJobsRequest {
    DatastoreId: string;
    NextToken?: string;
    MaxResults?: number;
    JobName?: string;
    JobStatus?: JobStatus;
    SubmittedBefore?: Date;
    SubmittedAfter?: Date;
}
export declare const ListFHIRImportJobsRequest: S.Schema<ListFHIRImportJobsRequest>;
export type ImportJobPropertiesList = ImportJobProperties[];
export declare const ImportJobPropertiesList: any;
export interface ListFHIRImportJobsResponse {
    ImportJobPropertiesList: ImportJobProperties[];
    NextToken?: string;
}
export declare const ListFHIRImportJobsResponse: S.Schema<ListFHIRImportJobsResponse>;
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PublishDataTransformationProfileRequest {
    ProfileId: string;
    SourceFormat: SourceFormat;
    FromExistingVersion?: number;
    ChangeDescription?: string;
}
export declare const PublishDataTransformationProfileRequest: S.Schema<PublishDataTransformationProfileRequest>;
export interface PublishDataTransformationProfileResponse {
    ProfileId: string;
    Version: number;
    SourceFormat: SourceFormat;
    TargetFormat: TargetFormat;
    ProfileName?: string;
    LastUpdatedAt: Date;
}
export declare const PublishDataTransformationProfileResponse: S.Schema<PublishDataTransformationProfileResponse>;
export interface ContinuousBackupRestoreConfiguration {
    RestorePointTime?: Date;
}
export declare const ContinuousBackupRestoreConfiguration: S.Schema<ContinuousBackupRestoreConfiguration>;
export type RestoreConfiguration = {
    ContinuousBackupRestoreConfiguration: ContinuousBackupRestoreConfiguration;
};
export declare const RestoreConfiguration: any;
export interface RestoreFHIRDatastoreRequest {
    SourceDatastoreId: string;
    RestoreConfiguration: RestoreConfiguration;
    DatastoreName?: string;
    SseConfiguration?: SseConfiguration;
    ClientToken?: string;
    Tags?: Tag[];
    IdentityProviderConfiguration?: IdentityProviderConfiguration;
    AnalyticsConfiguration?: AnalyticsConfiguration;
    NlpConfiguration?: NlpConfiguration;
    ProfileConfiguration?: ProfileConfiguration;
}
export declare const RestoreFHIRDatastoreRequest: S.Schema<RestoreFHIRDatastoreRequest>;
export interface RestoreFHIRDatastoreResponse {
    DatastoreId: string;
    DatastoreArn: string;
    DatastoreStatus: DatastoreStatus;
    DatastoreEndpoint: string;
}
export declare const RestoreFHIRDatastoreResponse: S.Schema<RestoreFHIRDatastoreResponse>;
export interface StartDataTransformationJobRequest {
    InputDataConfig: TransformationInputDataConfig;
    OutputDataConfig: TransformationOutputDataConfig;
    DataAccessRoleArn: string;
    ClientToken: string;
    JobName?: string;
    ProfileId: string;
    DriftDetectionEnabled?: boolean;
    ProvenanceEnabled?: boolean;
}
export declare const StartDataTransformationJobRequest: S.Schema<StartDataTransformationJobRequest>;
export interface StartDataTransformationJobResponse {
    JobId: string;
    JobStatus: TransformationJobStatus;
}
export declare const StartDataTransformationJobResponse: S.Schema<StartDataTransformationJobResponse>;
export interface StartFHIRExportJobRequest {
    JobName?: string;
    OutputDataConfig: OutputDataConfig;
    DatastoreId: string;
    DataAccessRoleArn: string;
    ClientToken?: string;
}
export declare const StartFHIRExportJobRequest: S.Schema<StartFHIRExportJobRequest>;
export interface StartFHIRExportJobResponse {
    JobId: string;
    JobStatus: JobStatus;
    DatastoreId?: string;
}
export declare const StartFHIRExportJobResponse: S.Schema<StartFHIRExportJobResponse>;
export type DefaultEnabledBoolean = boolean;
export interface StartFHIRImportJobRequest {
    JobName?: string;
    InputDataConfig: InputDataConfig;
    JobOutputDataConfig: OutputDataConfig;
    DatastoreId: string;
    DataAccessRoleArn: string;
    ClientToken?: string;
    ValidationLevel?: ValidationLevel;
    ProfileId?: string;
    InputFormat?: string;
    DriftDetectionEnabled?: boolean;
    ProvenanceEnabled?: boolean;
}
export declare const StartFHIRImportJobRequest: S.Schema<StartFHIRImportJobRequest>;
export interface StartFHIRImportJobResponse {
    JobId: string;
    JobStatus: JobStatus;
    DatastoreId?: string;
}
export declare const StartFHIRImportJobResponse: S.Schema<StartFHIRImportJobResponse>;
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateDataTransformationProfileRequest {
    ProfileId: string;
    ProfileMapping: {
        [key: string]: string | undefined;
    };
    ChangeDescription?: string;
}
export declare const UpdateDataTransformationProfileRequest: S.Schema<UpdateDataTransformationProfileRequest>;
export interface UpdateDataTransformationProfileResponse {
    ProfileId: string;
    SourceFormat: SourceFormat;
    TargetFormat: TargetFormat;
    ProfileName?: string;
    LastUpdatedAt: Date;
}
export declare const UpdateDataTransformationProfileResponse: S.Schema<UpdateDataTransformationProfileResponse>;
export interface UpdateFHIRDatastoreRequest {
    DatastoreId: string;
    DatastoreName?: string;
    AnalyticsConfiguration?: AnalyticsConfiguration;
    NlpConfiguration?: NlpConfiguration;
    ProfileConfiguration?: ProfileConfiguration;
    IdentityProviderConfiguration?: IdentityProviderConfiguration;
    BackupConfiguration?: BackupConfiguration;
}
export declare const UpdateFHIRDatastoreRequest: S.Schema<UpdateFHIRDatastoreRequest>;
export interface UpdateFHIRDatastoreResponse {
    DatastoreProperties: DatastoreProperties;
}
export declare const UpdateFHIRDatastoreResponse: S.Schema<UpdateFHIRDatastoreResponse>;
export type AgentMessageString = string | redacted.Redacted<string>;
export type AgentInputMessageType = "normal" | "confirmation_response" | (string & {});
export declare const AgentInputMessageType: any;
export interface AgentInputMessage {
    Body: string | redacted.Redacted<string>;
    Type: AgentInputMessageType;
}
export declare const AgentInputMessage: S.Schema<AgentInputMessage>;
export type ConversationIdString = string;
export interface UpdateProfileWithAgentRequest {
    ProfileId: string;
    SourceFormat: SourceFormat;
    InputMessage: AgentInputMessage;
    ConversationId?: string;
}
export declare const UpdateProfileWithAgentRequest: S.Schema<UpdateProfileWithAgentRequest>;
export type AgentOutputMessageType = "INITIAL_GREETING" | "normal" | "confirmation" | "complete" | "error" | "options" | "choices" | (string & {});
export declare const AgentOutputMessageType: any;
export type DataTransformationChatOptionString = string | redacted.Redacted<string>;
export type DataTransformationChatOptionsList = (string | redacted.Redacted<string>)[];
export declare const DataTransformationChatOptionsList: any;
export interface AgentOutputMessage {
    Body: string | redacted.Redacted<string>;
    Type: AgentOutputMessageType;
    OptionsList?: (string | redacted.Redacted<string>)[];
}
export declare const AgentOutputMessage: S.Schema<AgentOutputMessage>;
export interface UpdateProfileWithAgentResponse {
    AgentResponse: AgentOutputMessage;
    ConversationId: string;
}
export declare const UpdateProfileWithAgentResponse: S.Schema<UpdateProfileWithAgentResponse>;
export type CreateDataTransformationProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a data transformation profile in DRAFT state. Specify a built-in starter profile, an existing profile version, raw profile content, or a sample data file as the source.
 */
export declare const createDataTransformationProfile: API.OperationMethod<CreateDataTransformationProfileRequest, CreateDataTransformationProfileResponse, CreateDataTransformationProfileError, Credentials | HttpClient.HttpClient>;
export type CreateFHIRDatastoreError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a FHIR-enabled data store.
 */
export declare const createFHIRDatastore: API.OperationMethod<CreateFHIRDatastoreRequest, CreateFHIRDatastoreResponse, CreateFHIRDatastoreError, Credentials | HttpClient.HttpClient>;
export type DeleteDataTransformationProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a data transformation profile and all its versions, including the DRAFT and all published versions.
 */
export declare const deleteDataTransformationProfile: API.OperationMethod<DeleteDataTransformationProfileRequest, DeleteDataTransformationProfileResponse, DeleteDataTransformationProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteFHIRDatastoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a FHIR-enabled data store.
 */
export declare const deleteFHIRDatastore: API.OperationMethod<DeleteFHIRDatastoreRequest, DeleteFHIRDatastoreResponse, DeleteFHIRDatastoreError, Credentials | HttpClient.HttpClient>;
export type DescribeDataTransformationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes a data transformation job, including its current status, configuration, and progress information.
 */
export declare const describeDataTransformationJob: API.OperationMethod<DescribeDataTransformationJobRequest, DescribeDataTransformationJobResponse, DescribeDataTransformationJobError, Credentials | HttpClient.HttpClient>;
export type DescribeFHIRDatastoreError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get properties for a FHIR-enabled data store.
 */
export declare const describeFHIRDatastore: API.OperationMethod<DescribeFHIRDatastoreRequest, DescribeFHIRDatastoreResponse, DescribeFHIRDatastoreError, Credentials | HttpClient.HttpClient>;
export type DescribeFHIRExportJobError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get FHIR export job properties.
 */
export declare const describeFHIRExportJob: API.OperationMethod<DescribeFHIRExportJobRequest, DescribeFHIRExportJobResponse, DescribeFHIRExportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeFHIRImportJobError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the import job properties to learn more about the job or job progress.
 */
export declare const describeFHIRImportJob: API.OperationMethod<DescribeFHIRImportJobRequest, DescribeFHIRImportJobResponse, DescribeFHIRImportJobError, Credentials | HttpClient.HttpClient>;
export type GetDataTransformationProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a data transformation profile's metadata and profile content at a specific version. Specify version 0 to retrieve the DRAFT, a version number between 1 and 99 to retrieve a specific published version, or omit the version to retrieve the latest published version.
 */
export declare const getDataTransformationProfile: API.OperationMethod<GetDataTransformationProfileRequest, GetDataTransformationProfileResponse, GetDataTransformationProfileError, Credentials | HttpClient.HttpClient>;
export type ListDataTransformationJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists data transformation jobs for your Amazon Web Services account. Results can be filtered by status, job name, and submit time window. Results are paginated. Use the `NextToken` parameter to retrieve additional results.
 */
export declare const listDataTransformationJobs: API.PaginatedOperationMethod<ListDataTransformationJobsRequest, ListDataTransformationJobsResponse, ListDataTransformationJobsError, Credentials | HttpClient.HttpClient, TransformationJobSummary>;
export type ListDataTransformationProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all data transformation profiles in your account, returning the latest version summary for each. Use `GetDataTransformationProfile` to retrieve profile content. Results are paginated. Use the `NextToken` parameter to retrieve additional results.
 */
export declare const listDataTransformationProfiles: API.PaginatedOperationMethod<ListDataTransformationProfilesRequest, ListDataTransformationProfilesResponse, ListDataTransformationProfilesError, Credentials | HttpClient.HttpClient, DataTransformationProfileSummary>;
export type ListDataTransformationProfileVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all versions of a specific data transformation profile (DRAFT and published), in reverse chronological order (newest first). Use `GetDataTransformationProfile` to retrieve profile content. Results are paginated. Use the `NextToken` parameter to retrieve additional results.
 */
export declare const listDataTransformationProfileVersions: API.PaginatedOperationMethod<ListDataTransformationProfileVersionsRequest, ListDataTransformationProfileVersionsResponse, ListDataTransformationProfileVersionsError, Credentials | HttpClient.HttpClient, DataTransformationProfileVersionSummary>;
export type ListFHIRDatastoresError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all FHIR-enabled data stores in a user’s account, regardless of data store status.
 */
export declare const listFHIRDatastores: API.PaginatedOperationMethod<ListFHIRDatastoresRequest, ListFHIRDatastoresResponse, ListFHIRDatastoresError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFHIRExportJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all FHIR export jobs associated with an account and their statuses.
 */
export declare const listFHIRExportJobs: API.PaginatedOperationMethod<ListFHIRExportJobsRequest, ListFHIRExportJobsResponse, ListFHIRExportJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFHIRImportJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all FHIR import jobs associated with an account and their statuses.
 */
export declare const listFHIRImportJobs: API.PaginatedOperationMethod<ListFHIRImportJobsRequest, ListFHIRImportJobsResponse, ListFHIRImportJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of all existing tags associated with a data store.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PublishDataTransformationProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Promotes the current DRAFT version of a data transformation profile to a new immutable published version. Also supports rollback by publishing from a previously published version.
 */
export declare const publishDataTransformationProfile: API.OperationMethod<PublishDataTransformationProfileRequest, PublishDataTransformationProfileResponse, PublishDataTransformationProfileError, Credentials | HttpClient.HttpClient>;
export type RestoreFHIRDatastoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Restore a backup-enabled data store to a point in time. Creates a new data store from the backup.
 */
export declare const restoreFHIRDatastore: API.OperationMethod<RestoreFHIRDatastoreRequest, RestoreFHIRDatastoreResponse, RestoreFHIRDatastoreError, Credentials | HttpClient.HttpClient>;
export type StartDataTransformationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an asynchronous data transformation job that converts source files from Amazon Simple Storage Service (Amazon S3) and writes the output to Amazon S3 or HealthLake.
 */
export declare const startDataTransformationJob: API.OperationMethod<StartDataTransformationJobRequest, StartDataTransformationJobResponse, StartDataTransformationJobError, Credentials | HttpClient.HttpClient>;
export type StartFHIRExportJobError = AccessDeniedException | FailedDependencyException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Start a FHIR export job.
 */
export declare const startFHIRExportJob: API.OperationMethod<StartFHIRExportJobRequest, StartFHIRExportJobResponse, StartFHIRExportJobError, Credentials | HttpClient.HttpClient>;
export type StartFHIRImportJobError = AccessDeniedException | FailedDependencyException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Start importing bulk FHIR data into an ACTIVE data store. The import job imports FHIR data found in the `InputDataConfig` object and stores processing results in the `JobOutputDataConfig` object.
 */
export declare const startFHIRImportJob: API.OperationMethod<StartFHIRImportJobRequest, StartFHIRImportJobResponse, StartFHIRImportJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Add a user-specifed key and value tag to a data store.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Remove a user-specifed key and value tag from a data store.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDataTransformationProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the DRAFT version (version 0) of a data transformation profile with new profile content. The update replaces all existing DRAFT content.
 */
export declare const updateDataTransformationProfile: API.OperationMethod<UpdateDataTransformationProfileRequest, UpdateDataTransformationProfileResponse, UpdateDataTransformationProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateFHIRDatastoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the properties of a FHIR-enabled data store.
 */
export declare const updateFHIRDatastore: API.OperationMethod<UpdateFHIRDatastoreRequest, UpdateFHIRDatastoreResponse, UpdateFHIRDatastoreError, Credentials | HttpClient.HttpClient>;
export type UpdateProfileWithAgentError = AccessDeniedException | AgentMessageOutOfContextException | ConversationNotFoundException | InternalServerException | NotImplementedOperationException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | UnsupportedMIMETypeException | ValidationException | CommonErrors;
/**
 * Updates a data transformation profile using chat-based interaction with an agent. Supports multi-turn conversations for iteratively customizing profiles.
 */
export declare const updateProfileWithAgent: API.OperationMethod<UpdateProfileWithAgentRequest, UpdateProfileWithAgentResponse, UpdateProfileWithAgentError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=healthlake.d.ts.map