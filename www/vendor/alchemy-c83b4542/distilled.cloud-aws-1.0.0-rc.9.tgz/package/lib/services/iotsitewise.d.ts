import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as stream from "effect/Stream";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictingOperationException_base: S.Class<ConflictingOperationException, S.TaggedStruct<"ConflictingOperationException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceArn: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictingOperationException extends /*@__PURE__*/ ConflictingOperationException_base {
}
declare const InternalFailureException_base: S.Class<InternalFailureException, S.TaggedStruct<"InternalFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const PreconditionFailedException_base: S.Class<PreconditionFailedException, S.TaggedStruct<"PreconditionFailedException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceArn: any;
}>, import("effect/Cause").YieldableError>;
export declare class PreconditionFailedException extends /*@__PURE__*/ PreconditionFailedException_base {
}
declare const QueryTimeoutException_base: S.Class<QueryTimeoutException, S.TaggedStruct<"QueryTimeoutException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class QueryTimeoutException extends /*@__PURE__*/ QueryTimeoutException_base {
}
declare const ResourceAlreadyExistsException_base: S.Class<ResourceAlreadyExistsException, S.TaggedStruct<"ResourceAlreadyExistsException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceArn: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
    readonly resourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CustomID = string;
export type ClientToken = string;
export interface AssociateAssetsRequest {
    assetId: string;
    hierarchyId: string;
    childAssetId: string;
    clientToken?: string;
}
export declare const AssociateAssetsRequest: S.Schema<AssociateAssetsRequest>;
export interface AssociateAssetsResponse {
}
export declare const AssociateAssetsResponse: S.Schema<AssociateAssetsResponse>;
export type PropertyAlias = string;
export interface AssociateTimeSeriesToAssetPropertyRequest {
    alias: string;
    assetId: string;
    propertyId: string;
    clientToken?: string;
}
export declare const AssociateTimeSeriesToAssetPropertyRequest: S.Schema<AssociateTimeSeriesToAssetPropertyRequest>;
export interface AssociateTimeSeriesToAssetPropertyResponse {
}
export declare const AssociateTimeSeriesToAssetPropertyResponse: S.Schema<AssociateTimeSeriesToAssetPropertyResponse>;
export type ID = string;
export type WorkspaceName = string;
export type TimeSeriesId = string;
export type TimeInSeconds = number;
export type OffsetInNanos = number;
export interface TimeInNanos {
    timeInSeconds: number;
    offsetInNanos?: number;
}
export declare const TimeInNanos: S.Schema<TimeInNanos>;
export interface AssociateDataSegmentEntry {
    sourceDatasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
}
export declare const AssociateDataSegmentEntry: S.Schema<AssociateDataSegmentEntry>;
export type AssociateDataSegmentEntries = AssociateDataSegmentEntry[];
export declare const AssociateDataSegmentEntries: any;
export interface BatchAssociateDataSegmentsToDatasetRequest {
    datasetId: string;
    workspaceName: string;
    associateDataSegmentEntries: AssociateDataSegmentEntry[];
    clientToken?: string;
}
export declare const BatchAssociateDataSegmentsToDatasetRequest: S.Schema<BatchAssociateDataSegmentsToDatasetRequest>;
export type Version = string;
export type DataSegmentErrorCode = "INTERNAL_FAILURE" | "VALIDATION_ERROR" | "RESOURCE_NOT_FOUND" | "LIMIT_EXCEEDED" | "CONFLICTING_OPERATION" | (string & {});
export declare const DataSegmentErrorCode: any;
export type DataSegmentErrorMessage = string;
export interface FailedDataSegmentAssociation {
    sourceDatasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
    errorCode: DataSegmentErrorCode;
    errorMessage: string;
}
export declare const FailedDataSegmentAssociation: S.Schema<FailedDataSegmentAssociation>;
export type FailedDataSegmentAssociations = FailedDataSegmentAssociation[];
export declare const FailedDataSegmentAssociations: any;
export interface BatchAssociateDataSegmentsToDatasetResponse {
    datasetId: string;
    datasetVersion: string;
    failedAssociations: FailedDataSegmentAssociation[];
}
export declare const BatchAssociateDataSegmentsToDatasetResponse: S.Schema<BatchAssociateDataSegmentsToDatasetResponse>;
export type IDs = string[];
export declare const IDs: any;
export interface BatchAssociateProjectAssetsRequest {
    projectId: string;
    assetIds: string[];
    clientToken?: string;
}
export declare const BatchAssociateProjectAssetsRequest: S.Schema<BatchAssociateProjectAssetsRequest>;
export type AssetErrorCode = "INTERNAL_FAILURE" | (string & {});
export declare const AssetErrorCode: any;
export type AssetErrorMessage = string;
export interface AssetErrorDetails {
    assetId: string;
    code: AssetErrorCode;
    message: string;
}
export declare const AssetErrorDetails: S.Schema<AssetErrorDetails>;
export type BatchAssociateProjectAssetsErrors = AssetErrorDetails[];
export declare const BatchAssociateProjectAssetsErrors: any;
export interface BatchAssociateProjectAssetsResponse {
    errors?: AssetErrorDetails[];
}
export declare const BatchAssociateProjectAssetsResponse: S.Schema<BatchAssociateProjectAssetsResponse>;
export interface DeleteDataSegmentEntry {
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
}
export declare const DeleteDataSegmentEntry: S.Schema<DeleteDataSegmentEntry>;
export type DeleteDataSegmentEntries = DeleteDataSegmentEntry[];
export declare const DeleteDataSegmentEntries: any;
export interface BatchDeleteDatasetDataSegmentsRequest {
    datasetId: string;
    workspaceName: string;
    deleteDataSegmentEntries: DeleteDataSegmentEntry[];
    clientToken?: string;
}
export declare const BatchDeleteDatasetDataSegmentsRequest: S.Schema<BatchDeleteDatasetDataSegmentsRequest>;
export interface FailedDataSegmentDeletion {
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
    errorCode: DataSegmentErrorCode;
    errorMessage: string;
}
export declare const FailedDataSegmentDeletion: S.Schema<FailedDataSegmentDeletion>;
export type FailedDataSegmentDeletions = FailedDataSegmentDeletion[];
export declare const FailedDataSegmentDeletions: any;
export interface BatchDeleteDatasetDataSegmentsResponse {
    datasetId: string;
    datasetVersion: string;
    errors: FailedDataSegmentDeletion[];
}
export declare const BatchDeleteDatasetDataSegmentsResponse: S.Schema<BatchDeleteDatasetDataSegmentsResponse>;
export interface DisassociateDataSegmentEntry {
    sourceDatasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
}
export declare const DisassociateDataSegmentEntry: S.Schema<DisassociateDataSegmentEntry>;
export type DisassociateDataSegmentEntries = DisassociateDataSegmentEntry[];
export declare const DisassociateDataSegmentEntries: any;
export interface BatchDisassociateDataSegmentsFromDatasetRequest {
    datasetId: string;
    workspaceName: string;
    disassociateDataSegmentEntries: DisassociateDataSegmentEntry[];
    clientToken?: string;
}
export declare const BatchDisassociateDataSegmentsFromDatasetRequest: S.Schema<BatchDisassociateDataSegmentsFromDatasetRequest>;
export interface FailedDataSegmentDisassociation {
    sourceDatasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
    errorCode: DataSegmentErrorCode;
    errorMessage: string;
}
export declare const FailedDataSegmentDisassociation: S.Schema<FailedDataSegmentDisassociation>;
export type FailedDataSegmentDisassociations = FailedDataSegmentDisassociation[];
export declare const FailedDataSegmentDisassociations: any;
export interface BatchDisassociateDataSegmentsFromDatasetResponse {
    datasetId: string;
    datasetVersion: string;
    failedDisassociations: FailedDataSegmentDisassociation[];
}
export declare const BatchDisassociateDataSegmentsFromDatasetResponse: S.Schema<BatchDisassociateDataSegmentsFromDatasetResponse>;
export interface BatchDisassociateProjectAssetsRequest {
    projectId: string;
    assetIds: string[];
    clientToken?: string;
}
export declare const BatchDisassociateProjectAssetsRequest: S.Schema<BatchDisassociateProjectAssetsRequest>;
export type BatchDisassociateProjectAssetsErrors = AssetErrorDetails[];
export declare const BatchDisassociateProjectAssetsErrors: any;
export interface BatchDisassociateProjectAssetsResponse {
    errors?: AssetErrorDetails[];
}
export declare const BatchDisassociateProjectAssetsResponse: S.Schema<BatchDisassociateProjectAssetsResponse>;
export type EntryId = string;
export type AssetPropertyAlias = string;
export type AggregateType = "AVERAGE" | "COUNT" | "MAXIMUM" | "MINIMUM" | "SUM" | "STANDARD_DEVIATION" | (string & {});
export declare const AggregateType: any;
export type AggregateTypes = AggregateType[];
export declare const AggregateTypes: any;
export type Resolution = string;
export type Quality = "GOOD" | "BAD" | "UNCERTAIN" | (string & {});
export declare const Quality: any;
export type Qualities = Quality[];
export declare const Qualities: any;
export type TimeOrdering = "ASCENDING" | "DESCENDING" | (string & {});
export declare const TimeOrdering: any;
export interface BatchGetAssetPropertyAggregatesEntry {
    entryId: string;
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    aggregateTypes: AggregateType[];
    resolution: string;
    startDate: Date;
    endDate: Date;
    qualities?: Quality[];
    timeOrdering?: TimeOrdering;
}
export declare const BatchGetAssetPropertyAggregatesEntry: S.Schema<BatchGetAssetPropertyAggregatesEntry>;
export type BatchGetAssetPropertyAggregatesEntries = BatchGetAssetPropertyAggregatesEntry[];
export declare const BatchGetAssetPropertyAggregatesEntries: any;
export type NextToken = string;
export type BatchGetAssetPropertyAggregatesMaxResults = number;
export interface BatchGetAssetPropertyAggregatesRequest {
    entries: BatchGetAssetPropertyAggregatesEntry[];
    nextToken?: string;
    maxResults?: number;
}
export declare const BatchGetAssetPropertyAggregatesRequest: S.Schema<BatchGetAssetPropertyAggregatesRequest>;
export type BatchGetAssetPropertyAggregatesErrorCode = "ResourceNotFoundException" | "InvalidRequestException" | "AccessDeniedException" | (string & {});
export declare const BatchGetAssetPropertyAggregatesErrorCode: any;
export type ErrorMessage = string;
export interface BatchGetAssetPropertyAggregatesErrorEntry {
    errorCode: BatchGetAssetPropertyAggregatesErrorCode;
    errorMessage: string;
    entryId: string;
}
export declare const BatchGetAssetPropertyAggregatesErrorEntry: S.Schema<BatchGetAssetPropertyAggregatesErrorEntry>;
export type BatchGetAssetPropertyAggregatesErrorEntries = BatchGetAssetPropertyAggregatesErrorEntry[];
export declare const BatchGetAssetPropertyAggregatesErrorEntries: any;
export type AggregatedDoubleValue = number;
export interface Aggregates {
    average?: number;
    count?: number;
    maximum?: number;
    minimum?: number;
    sum?: number;
    standardDeviation?: number;
}
export declare const Aggregates: S.Schema<Aggregates>;
export interface AggregatedValue {
    timestamp: Date;
    quality?: Quality;
    value: Aggregates;
}
export declare const AggregatedValue: S.Schema<AggregatedValue>;
export type AggregatedValues = AggregatedValue[];
export declare const AggregatedValues: any;
export interface BatchGetAssetPropertyAggregatesSuccessEntry {
    entryId: string;
    aggregatedValues: AggregatedValue[];
}
export declare const BatchGetAssetPropertyAggregatesSuccessEntry: S.Schema<BatchGetAssetPropertyAggregatesSuccessEntry>;
export type BatchGetAssetPropertyAggregatesSuccessEntries = BatchGetAssetPropertyAggregatesSuccessEntry[];
export declare const BatchGetAssetPropertyAggregatesSuccessEntries: any;
export type BatchEntryCompletionStatus = "SUCCESS" | "ERROR" | (string & {});
export declare const BatchEntryCompletionStatus: any;
export interface BatchGetAssetPropertyAggregatesErrorInfo {
    errorCode: BatchGetAssetPropertyAggregatesErrorCode;
    errorTimestamp: Date;
}
export declare const BatchGetAssetPropertyAggregatesErrorInfo: S.Schema<BatchGetAssetPropertyAggregatesErrorInfo>;
export interface BatchGetAssetPropertyAggregatesSkippedEntry {
    entryId: string;
    completionStatus: BatchEntryCompletionStatus;
    errorInfo?: BatchGetAssetPropertyAggregatesErrorInfo;
}
export declare const BatchGetAssetPropertyAggregatesSkippedEntry: S.Schema<BatchGetAssetPropertyAggregatesSkippedEntry>;
export type BatchGetAssetPropertyAggregatesSkippedEntries = BatchGetAssetPropertyAggregatesSkippedEntry[];
export declare const BatchGetAssetPropertyAggregatesSkippedEntries: any;
export interface BatchGetAssetPropertyAggregatesResponse {
    errorEntries: BatchGetAssetPropertyAggregatesErrorEntry[];
    successEntries: BatchGetAssetPropertyAggregatesSuccessEntry[];
    skippedEntries: BatchGetAssetPropertyAggregatesSkippedEntry[];
    nextToken?: string;
}
export declare const BatchGetAssetPropertyAggregatesResponse: S.Schema<BatchGetAssetPropertyAggregatesResponse>;
export interface BatchGetAssetPropertyValueEntry {
    entryId: string;
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
}
export declare const BatchGetAssetPropertyValueEntry: S.Schema<BatchGetAssetPropertyValueEntry>;
export type BatchGetAssetPropertyValueEntries = BatchGetAssetPropertyValueEntry[];
export declare const BatchGetAssetPropertyValueEntries: any;
export interface BatchGetAssetPropertyValueRequest {
    entries: BatchGetAssetPropertyValueEntry[];
    nextToken?: string;
}
export declare const BatchGetAssetPropertyValueRequest: S.Schema<BatchGetAssetPropertyValueRequest>;
export type BatchGetAssetPropertyValueErrorCode = "ResourceNotFoundException" | "InvalidRequestException" | "AccessDeniedException" | (string & {});
export declare const BatchGetAssetPropertyValueErrorCode: any;
export interface BatchGetAssetPropertyValueErrorEntry {
    errorCode: BatchGetAssetPropertyValueErrorCode;
    errorMessage: string;
    entryId: string;
}
export declare const BatchGetAssetPropertyValueErrorEntry: S.Schema<BatchGetAssetPropertyValueErrorEntry>;
export type BatchGetAssetPropertyValueErrorEntries = BatchGetAssetPropertyValueErrorEntry[];
export declare const BatchGetAssetPropertyValueErrorEntries: any;
export type PropertyValueStringValue = string;
export type PropertyValueIntegerValue = number;
export type PropertyValueDoubleValue = number;
export type PropertyValueBooleanValue = boolean;
export type RawValueType = "D" | "B" | "S" | "I" | "U" | (string & {});
export declare const RawValueType: any;
export interface PropertyValueNullValue {
    valueType: RawValueType;
}
export declare const PropertyValueNullValue: S.Schema<PropertyValueNullValue>;
export interface Variant {
    stringValue?: string;
    integerValue?: number;
    doubleValue?: number;
    booleanValue?: boolean;
    nullValue?: PropertyValueNullValue;
}
export declare const Variant: S.Schema<Variant>;
export interface AssetPropertyValue {
    value: Variant;
    timestamp: TimeInNanos;
    quality?: Quality;
}
export declare const AssetPropertyValue: S.Schema<AssetPropertyValue>;
export interface BatchGetAssetPropertyValueSuccessEntry {
    entryId: string;
    assetPropertyValue?: AssetPropertyValue;
}
export declare const BatchGetAssetPropertyValueSuccessEntry: S.Schema<BatchGetAssetPropertyValueSuccessEntry>;
export type BatchGetAssetPropertyValueSuccessEntries = BatchGetAssetPropertyValueSuccessEntry[];
export declare const BatchGetAssetPropertyValueSuccessEntries: any;
export interface BatchGetAssetPropertyValueErrorInfo {
    errorCode: BatchGetAssetPropertyValueErrorCode;
    errorTimestamp: Date;
}
export declare const BatchGetAssetPropertyValueErrorInfo: S.Schema<BatchGetAssetPropertyValueErrorInfo>;
export interface BatchGetAssetPropertyValueSkippedEntry {
    entryId: string;
    completionStatus: BatchEntryCompletionStatus;
    errorInfo?: BatchGetAssetPropertyValueErrorInfo;
}
export declare const BatchGetAssetPropertyValueSkippedEntry: S.Schema<BatchGetAssetPropertyValueSkippedEntry>;
export type BatchGetAssetPropertyValueSkippedEntries = BatchGetAssetPropertyValueSkippedEntry[];
export declare const BatchGetAssetPropertyValueSkippedEntries: any;
export interface BatchGetAssetPropertyValueResponse {
    errorEntries: BatchGetAssetPropertyValueErrorEntry[];
    successEntries: BatchGetAssetPropertyValueSuccessEntry[];
    skippedEntries: BatchGetAssetPropertyValueSkippedEntry[];
    nextToken?: string;
}
export declare const BatchGetAssetPropertyValueResponse: S.Schema<BatchGetAssetPropertyValueResponse>;
export interface BatchGetAssetPropertyValueHistoryEntry {
    entryId: string;
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    startDate?: Date;
    endDate?: Date;
    qualities?: Quality[];
    timeOrdering?: TimeOrdering;
}
export declare const BatchGetAssetPropertyValueHistoryEntry: S.Schema<BatchGetAssetPropertyValueHistoryEntry>;
export type BatchGetAssetPropertyValueHistoryEntries = BatchGetAssetPropertyValueHistoryEntry[];
export declare const BatchGetAssetPropertyValueHistoryEntries: any;
export type BatchGetAssetPropertyValueHistoryMaxResults = number;
export interface BatchGetAssetPropertyValueHistoryRequest {
    entries: BatchGetAssetPropertyValueHistoryEntry[];
    nextToken?: string;
    maxResults?: number;
}
export declare const BatchGetAssetPropertyValueHistoryRequest: S.Schema<BatchGetAssetPropertyValueHistoryRequest>;
export type BatchGetAssetPropertyValueHistoryErrorCode = "ResourceNotFoundException" | "InvalidRequestException" | "AccessDeniedException" | (string & {});
export declare const BatchGetAssetPropertyValueHistoryErrorCode: any;
export interface BatchGetAssetPropertyValueHistoryErrorEntry {
    errorCode: BatchGetAssetPropertyValueHistoryErrorCode;
    errorMessage: string;
    entryId: string;
}
export declare const BatchGetAssetPropertyValueHistoryErrorEntry: S.Schema<BatchGetAssetPropertyValueHistoryErrorEntry>;
export type BatchGetAssetPropertyValueHistoryErrorEntries = BatchGetAssetPropertyValueHistoryErrorEntry[];
export declare const BatchGetAssetPropertyValueHistoryErrorEntries: any;
export type AssetPropertyValueHistory = AssetPropertyValue[];
export declare const AssetPropertyValueHistory: any;
export interface BatchGetAssetPropertyValueHistorySuccessEntry {
    entryId: string;
    assetPropertyValueHistory: AssetPropertyValue[];
}
export declare const BatchGetAssetPropertyValueHistorySuccessEntry: S.Schema<BatchGetAssetPropertyValueHistorySuccessEntry>;
export type BatchGetAssetPropertyValueHistorySuccessEntries = BatchGetAssetPropertyValueHistorySuccessEntry[];
export declare const BatchGetAssetPropertyValueHistorySuccessEntries: any;
export interface BatchGetAssetPropertyValueHistoryErrorInfo {
    errorCode: BatchGetAssetPropertyValueHistoryErrorCode;
    errorTimestamp: Date;
}
export declare const BatchGetAssetPropertyValueHistoryErrorInfo: S.Schema<BatchGetAssetPropertyValueHistoryErrorInfo>;
export interface BatchGetAssetPropertyValueHistorySkippedEntry {
    entryId: string;
    completionStatus: BatchEntryCompletionStatus;
    errorInfo?: BatchGetAssetPropertyValueHistoryErrorInfo;
}
export declare const BatchGetAssetPropertyValueHistorySkippedEntry: S.Schema<BatchGetAssetPropertyValueHistorySkippedEntry>;
export type BatchGetAssetPropertyValueHistorySkippedEntries = BatchGetAssetPropertyValueHistorySkippedEntry[];
export declare const BatchGetAssetPropertyValueHistorySkippedEntries: any;
export interface BatchGetAssetPropertyValueHistoryResponse {
    errorEntries: BatchGetAssetPropertyValueHistoryErrorEntry[];
    successEntries: BatchGetAssetPropertyValueHistorySuccessEntry[];
    skippedEntries: BatchGetAssetPropertyValueHistorySkippedEntry[];
    nextToken?: string;
}
export declare const BatchGetAssetPropertyValueHistoryResponse: S.Schema<BatchGetAssetPropertyValueHistoryResponse>;
export type AssetPropertyValues = AssetPropertyValue[];
export declare const AssetPropertyValues: any;
export interface PutAssetPropertyValueEntry {
    entryId: string;
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    propertyValues: AssetPropertyValue[];
}
export declare const PutAssetPropertyValueEntry: S.Schema<PutAssetPropertyValueEntry>;
export type PutAssetPropertyValueEntries = PutAssetPropertyValueEntry[];
export declare const PutAssetPropertyValueEntries: any;
export interface BatchPutAssetPropertyValueRequest {
    enablePartialEntryProcessing?: boolean;
    entries: PutAssetPropertyValueEntry[];
}
export declare const BatchPutAssetPropertyValueRequest: S.Schema<BatchPutAssetPropertyValueRequest>;
export type BatchPutAssetPropertyValueErrorCode = "ResourceNotFoundException" | "InvalidRequestException" | "InternalFailureException" | "ServiceUnavailableException" | "ThrottlingException" | "LimitExceededException" | "ConflictingOperationException" | "TimestampOutOfRangeException" | "AccessDeniedException" | (string & {});
export declare const BatchPutAssetPropertyValueErrorCode: any;
export type Timestamps = TimeInNanos[];
export declare const Timestamps: any;
export interface BatchPutAssetPropertyError {
    errorCode: BatchPutAssetPropertyValueErrorCode;
    errorMessage: string;
    timestamps: TimeInNanos[];
}
export declare const BatchPutAssetPropertyError: S.Schema<BatchPutAssetPropertyError>;
export type BatchPutAssetPropertyErrors = BatchPutAssetPropertyError[];
export declare const BatchPutAssetPropertyErrors: any;
export interface BatchPutAssetPropertyErrorEntry {
    entryId: string;
    errors: BatchPutAssetPropertyError[];
}
export declare const BatchPutAssetPropertyErrorEntry: S.Schema<BatchPutAssetPropertyErrorEntry>;
export type BatchPutAssetPropertyErrorEntries = BatchPutAssetPropertyErrorEntry[];
export declare const BatchPutAssetPropertyErrorEntries: any;
export interface BatchPutAssetPropertyValueResponse {
    errorEntries: BatchPutAssetPropertyErrorEntry[];
}
export declare const BatchPutAssetPropertyValueResponse: S.Schema<BatchPutAssetPropertyValueResponse>;
export interface CancelEnrichmentJobRequest {
    workspaceName: string;
    jobId: string;
}
export declare const CancelEnrichmentJobRequest: S.Schema<CancelEnrichmentJobRequest>;
export type EnrichmentJobStatus = "PENDING" | "RUNNING" | "COMPLETED" | "FAILED" | "TIMED_OUT" | "CANCELLED" | (string & {});
export declare const EnrichmentJobStatus: any;
export interface CancelEnrichmentJobResponse {
    jobId: string;
    status: EnrichmentJobStatus;
}
export declare const CancelEnrichmentJobResponse: S.Schema<CancelEnrichmentJobResponse>;
export type ResourceName = string;
export type CancelPipelineExecutionRequestReasonString = string;
export interface CancelPipelineExecutionRequest {
    workspaceName: string;
    pipelineName: string;
    pipelineExecutionId: string;
    reason?: string;
}
export declare const CancelPipelineExecutionRequest: S.Schema<CancelPipelineExecutionRequest>;
export type PipelineExecutionState = "NOT_STARTED" | "RUNNING" | "SUCCEEDED" | "FAILED" | "CANCELLING" | "CANCELLED" | (string & {});
export declare const PipelineExecutionState: any;
export interface CancelPipelineExecutionResponse {
    state: PipelineExecutionState;
}
export declare const CancelPipelineExecutionResponse: S.Schema<CancelPipelineExecutionResponse>;
export type QueryId = string;
export interface CancelQueryRequest {
    workspaceName: string;
    queryId: string;
}
export declare const CancelQueryRequest: S.Schema<CancelQueryRequest>;
export type QueryStatus = "SUBMITTED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELED" | "CANCELING" | (string & {});
export declare const QueryStatus: any;
export interface CancelQueryResponse {
    queryId: string;
    status: QueryStatus;
}
export declare const CancelQueryResponse: S.Schema<CancelQueryResponse>;
export type IdentityId = string;
export interface UserIdentity {
    id: string;
}
export declare const UserIdentity: S.Schema<UserIdentity>;
export interface GroupIdentity {
    id: string;
}
export declare const GroupIdentity: S.Schema<GroupIdentity>;
export type IamArn = string;
export interface IAMUserIdentity {
    arn: string;
}
export declare const IAMUserIdentity: S.Schema<IAMUserIdentity>;
export interface IAMRoleIdentity {
    arn: string;
}
export declare const IAMRoleIdentity: S.Schema<IAMRoleIdentity>;
export interface Identity {
    user?: UserIdentity;
    group?: GroupIdentity;
    iamUser?: IAMUserIdentity;
    iamRole?: IAMRoleIdentity;
}
export declare const Identity: S.Schema<Identity>;
export interface PortalResource {
    id: string;
}
export declare const PortalResource: S.Schema<PortalResource>;
export interface ProjectResource {
    id: string;
}
export declare const ProjectResource: S.Schema<ProjectResource>;
export interface Resource {
    portal?: PortalResource;
    project?: ProjectResource;
}
export declare const Resource: S.Schema<Resource>;
export type Permission = "ADMINISTRATOR" | "VIEWER" | (string & {});
export declare const Permission: any;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateAccessPolicyRequest {
    accessPolicyIdentity: Identity;
    accessPolicyResource: Resource;
    accessPolicyPermission: Permission;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateAccessPolicyRequest: S.Schema<CreateAccessPolicyRequest>;
export type ARN = string;
export interface CreateAccessPolicyResponse {
    accessPolicyId: string;
    accessPolicyArn: string;
}
export declare const CreateAccessPolicyResponse: S.Schema<CreateAccessPolicyResponse>;
export type ApplicationName = string;
export type Description = string;
export interface CreateApplicationRequest {
    clientToken?: string;
    idcInstanceArn: string;
    workspaceName: string;
    name: string;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateApplicationRequest: S.Schema<CreateApplicationRequest>;
export type ApplicationId = string;
export type DnsSubdomain = string;
export type ApplicationStatus = "CREATING" | "ACTIVE" | "DELETING" | (string & {});
export declare const ApplicationStatus: any;
export interface CreateApplicationResponse {
    arn: string;
    id: string;
    dnsSubdomain: string;
    name: string;
    status: ApplicationStatus;
}
export declare const CreateApplicationResponse: S.Schema<CreateApplicationResponse>;
export type Name = string;
export type ExternalId = string;
export interface CreateAssetRequest {
    assetName: string;
    assetModelId: string;
    assetId?: string;
    assetExternalId?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    assetDescription?: string;
}
export declare const CreateAssetRequest: S.Schema<CreateAssetRequest>;
export type AssetState = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export declare const AssetState: any;
export type ErrorCode = "VALIDATION_ERROR" | "INTERNAL_FAILURE" | (string & {});
export declare const ErrorCode: any;
export type DetailedErrorCode = "INCOMPATIBLE_COMPUTE_LOCATION" | "INCOMPATIBLE_FORWARDING_CONFIGURATION" | (string & {});
export declare const DetailedErrorCode: any;
export type DetailedErrorMessage = string;
export interface DetailedError {
    code: DetailedErrorCode;
    message: string;
}
export declare const DetailedError: S.Schema<DetailedError>;
export type DetailedErrors = DetailedError[];
export declare const DetailedErrors: any;
export interface ErrorDetails {
    code: ErrorCode;
    message: string;
    details?: DetailedError[];
}
export declare const ErrorDetails: S.Schema<ErrorDetails>;
export interface AssetStatus {
    state: AssetState;
    error?: ErrorDetails;
}
export declare const AssetStatus: S.Schema<AssetStatus>;
export interface CreateAssetResponse {
    assetId: string;
    assetArn: string;
    assetStatus: AssetStatus;
}
export declare const CreateAssetResponse: S.Schema<CreateAssetResponse>;
export type AssetModelType = "ASSET_MODEL" | "COMPONENT_MODEL" | "INTERFACE" | (string & {});
export declare const AssetModelType: any;
export type PropertyDataType = "STRING" | "INTEGER" | "DOUBLE" | "BOOLEAN" | "STRUCT" | "VIDEO" | "ANNOTATION" | "JSON" | (string & {});
export declare const PropertyDataType: any;
export type PropertyUnit = string;
export type DefaultValue = string;
export interface Attribute {
    defaultValue?: string;
}
export declare const Attribute: S.Schema<Attribute>;
export type ForwardingConfigState = "DISABLED" | "ENABLED" | (string & {});
export declare const ForwardingConfigState: any;
export interface ForwardingConfig {
    state: ForwardingConfigState;
}
export declare const ForwardingConfig: S.Schema<ForwardingConfig>;
export interface MeasurementProcessingConfig {
    forwardingConfig: ForwardingConfig;
}
export declare const MeasurementProcessingConfig: S.Schema<MeasurementProcessingConfig>;
export interface Measurement {
    processingConfig?: MeasurementProcessingConfig;
}
export declare const Measurement: S.Schema<Measurement>;
export type Expression = string;
export type VariableName = string;
export type Macro = string;
export interface AssetModelPropertyPathSegment {
    id?: string;
    name?: string;
}
export declare const AssetModelPropertyPathSegment: S.Schema<AssetModelPropertyPathSegment>;
export type AssetModelPropertyPath = AssetModelPropertyPathSegment[];
export declare const AssetModelPropertyPath: any;
export interface VariableValue {
    propertyId?: string;
    hierarchyId?: string;
    propertyPath?: AssetModelPropertyPathSegment[];
}
export declare const VariableValue: S.Schema<VariableValue>;
export interface ExpressionVariable {
    name: string;
    value: VariableValue;
}
export declare const ExpressionVariable: S.Schema<ExpressionVariable>;
export type ExpressionVariables = ExpressionVariable[];
export declare const ExpressionVariables: any;
export type ComputeLocation = "EDGE" | "CLOUD" | (string & {});
export declare const ComputeLocation: any;
export interface TransformProcessingConfig {
    computeLocation: ComputeLocation;
    forwardingConfig?: ForwardingConfig;
}
export declare const TransformProcessingConfig: S.Schema<TransformProcessingConfig>;
export interface Transform {
    expression: string;
    variables: ExpressionVariable[];
    processingConfig?: TransformProcessingConfig;
}
export declare const Transform: S.Schema<Transform>;
export type Interval = string;
export type Offset = string;
export interface TumblingWindow {
    interval: string;
    offset?: string;
}
export declare const TumblingWindow: S.Schema<TumblingWindow>;
export interface MetricWindow {
    tumbling?: TumblingWindow;
}
export declare const MetricWindow: S.Schema<MetricWindow>;
export interface MetricProcessingConfig {
    computeLocation: ComputeLocation;
}
export declare const MetricProcessingConfig: S.Schema<MetricProcessingConfig>;
export interface Metric {
    expression?: string;
    variables?: ExpressionVariable[];
    window: MetricWindow;
    processingConfig?: MetricProcessingConfig;
}
export declare const Metric: S.Schema<Metric>;
export interface PropertyType {
    attribute?: Attribute;
    measurement?: Measurement;
    transform?: Transform;
    metric?: Metric;
}
export declare const PropertyType: S.Schema<PropertyType>;
export interface AssetModelPropertyDefinition {
    id?: string;
    externalId?: string;
    name: string;
    dataType: PropertyDataType;
    dataTypeSpec?: string;
    unit?: string;
    type: PropertyType;
}
export declare const AssetModelPropertyDefinition: S.Schema<AssetModelPropertyDefinition>;
export type AssetModelPropertyDefinitions = AssetModelPropertyDefinition[];
export declare const AssetModelPropertyDefinitions: any;
export interface AssetModelHierarchyDefinition {
    id?: string;
    externalId?: string;
    name: string;
    childAssetModelId: string;
}
export declare const AssetModelHierarchyDefinition: S.Schema<AssetModelHierarchyDefinition>;
export type AssetModelHierarchyDefinitions = AssetModelHierarchyDefinition[];
export declare const AssetModelHierarchyDefinitions: any;
export interface AssetModelCompositeModelDefinition {
    id?: string;
    externalId?: string;
    name: string;
    description?: string;
    type: string;
    properties?: AssetModelPropertyDefinition[];
}
export declare const AssetModelCompositeModelDefinition: S.Schema<AssetModelCompositeModelDefinition>;
export type AssetModelCompositeModelDefinitions = AssetModelCompositeModelDefinition[];
export declare const AssetModelCompositeModelDefinitions: any;
export interface CreateAssetModelRequest {
    assetModelName: string;
    assetModelType?: AssetModelType;
    assetModelId?: string;
    assetModelExternalId?: string;
    assetModelDescription?: string;
    assetModelProperties?: AssetModelPropertyDefinition[];
    assetModelHierarchies?: AssetModelHierarchyDefinition[];
    assetModelCompositeModels?: AssetModelCompositeModelDefinition[];
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateAssetModelRequest: S.Schema<CreateAssetModelRequest>;
export type AssetModelState = "CREATING" | "ACTIVE" | "UPDATING" | "PROPAGATING" | "DELETING" | "FAILED" | (string & {});
export declare const AssetModelState: any;
export interface AssetModelStatus {
    state: AssetModelState;
    error?: ErrorDetails;
}
export declare const AssetModelStatus: S.Schema<AssetModelStatus>;
export interface CreateAssetModelResponse {
    assetModelId: string;
    assetModelArn: string;
    assetModelStatus: AssetModelStatus;
}
export declare const CreateAssetModelResponse: S.Schema<CreateAssetModelResponse>;
export type ETag = string;
export type SelectAll = string;
export type AssetModelVersionType = "LATEST" | "ACTIVE" | (string & {});
export declare const AssetModelVersionType: any;
export interface CreateAssetModelCompositeModelRequest {
    assetModelId: string;
    assetModelCompositeModelExternalId?: string;
    parentAssetModelCompositeModelId?: string;
    assetModelCompositeModelId?: string;
    assetModelCompositeModelDescription?: string;
    assetModelCompositeModelName: string;
    assetModelCompositeModelType: string;
    clientToken?: string;
    composedAssetModelId?: string;
    assetModelCompositeModelProperties?: AssetModelPropertyDefinition[];
    ifMatch?: string;
    ifNoneMatch?: string;
    matchForVersionType?: AssetModelVersionType;
}
export declare const CreateAssetModelCompositeModelRequest: S.Schema<CreateAssetModelCompositeModelRequest>;
export interface AssetModelCompositeModelPathSegment {
    id?: string;
    name?: string;
}
export declare const AssetModelCompositeModelPathSegment: S.Schema<AssetModelCompositeModelPathSegment>;
export type AssetModelCompositeModelPath = AssetModelCompositeModelPathSegment[];
export declare const AssetModelCompositeModelPath: any;
export interface CreateAssetModelCompositeModelResponse {
    assetModelCompositeModelId: string;
    assetModelCompositeModelPath: AssetModelCompositeModelPathSegment[];
    assetModelStatus: AssetModelStatus;
    assetModelId?: string;
}
export declare const CreateAssetModelCompositeModelResponse: S.Schema<CreateAssetModelCompositeModelResponse>;
export type BulkImportJobName = string;
export type Bucket = string;
export type ColumnName = "ALIAS" | "ASSET_ID" | "PROPERTY_ID" | "DATA_TYPE" | "TIMESTAMP_SECONDS" | "TIMESTAMP_NANO_OFFSET" | "QUALITY" | "VALUE" | (string & {});
export declare const ColumnName: any;
export type ColumnNames = ColumnName[];
export declare const ColumnNames: any;
export interface Csv {
    columnNames: ColumnName[];
}
export declare const Csv: S.Schema<Csv>;
export interface Parquet {
}
export declare const Parquet: S.Schema<Parquet>;
export interface Mp4 {
}
export declare const Mp4: S.Schema<Mp4>;
export interface Annotation {
}
export declare const Annotation: S.Schema<Annotation>;
export interface FileFormat {
    csv?: Csv;
    parquet?: Parquet;
    mp4?: Mp4;
    annotation?: Annotation;
}
export declare const FileFormat: S.Schema<FileFormat>;
export interface File {
    bucket: string;
    key: string;
    versionId?: string;
    alias?: string;
    startTime?: TimeInNanos;
    fileFormat?: FileFormat;
}
export declare const File: S.Schema<File>;
export type Files = File[];
export declare const Files: any;
export interface ErrorReportLocation {
    bucket: string;
    prefix: string;
}
export declare const ErrorReportLocation: S.Schema<ErrorReportLocation>;
export interface JobConfiguration {
    fileFormat?: FileFormat;
}
export declare const JobConfiguration: S.Schema<JobConfiguration>;
export type AdaptiveIngestion = boolean;
export type DeleteFilesAfterImport = boolean;
export interface CreateBulkImportJobRequest {
    jobName: string;
    jobRoleArn: string;
    files: File[];
    errorReportLocation: ErrorReportLocation;
    jobConfiguration?: JobConfiguration;
    adaptiveIngestion?: boolean;
    deleteFilesAfterImport?: boolean;
    datasetId?: string;
    workspaceName?: string;
}
export declare const CreateBulkImportJobRequest: S.Schema<CreateBulkImportJobRequest>;
export type JobStatus = "PENDING" | "CANCELLED" | "RUNNING" | "COMPLETED" | "FAILED" | "COMPLETED_WITH_FAILURES" | (string & {});
export declare const JobStatus: any;
export interface CreateBulkImportJobResponse {
    jobId: string;
    jobName: string;
    jobStatus: JobStatus;
}
export declare const CreateBulkImportJobResponse: S.Schema<CreateBulkImportJobResponse>;
export type RestrictedName = string;
export type RestrictedDescription = string;
export type InputProperties = string;
export type ResultProperty = string;
export interface ComputationModelAnomalyDetectionConfiguration {
    inputProperties: string;
    resultProperty: string;
}
export declare const ComputationModelAnomalyDetectionConfiguration: S.Schema<ComputationModelAnomalyDetectionConfiguration>;
export interface ComputationModelConfiguration {
    anomalyDetection?: ComputationModelAnomalyDetectionConfiguration;
}
export declare const ComputationModelConfiguration: S.Schema<ComputationModelConfiguration>;
export type ComputationModelDataBindingVariable = string;
export interface AssetModelPropertyBindingValue {
    assetModelId: string;
    propertyId: string;
}
export declare const AssetModelPropertyBindingValue: S.Schema<AssetModelPropertyBindingValue>;
export interface AssetPropertyBindingValue {
    assetId: string;
    propertyId: string;
}
export declare const AssetPropertyBindingValue: S.Schema<AssetPropertyBindingValue>;
export type BindingValueList = ComputationModelDataBindingValue[];
export declare const BindingValueList: S.Schema<BindingValueList>;
export interface ComputationModelDataBindingValue {
    assetModelProperty?: AssetModelPropertyBindingValue;
    assetProperty?: AssetPropertyBindingValue;
    list?: ComputationModelDataBindingValue[];
}
export declare const ComputationModelDataBindingValue: S.Schema<ComputationModelDataBindingValue>;
export type ComputationModelDataBinding = {
    [key: string]: ComputationModelDataBindingValue | undefined;
};
export declare const ComputationModelDataBinding: any;
export interface CreateComputationModelRequest {
    computationModelName: string;
    computationModelDescription?: string;
    computationModelConfiguration: ComputationModelConfiguration;
    computationModelDataBinding: {
        [key: string]: ComputationModelDataBindingValue | undefined;
    };
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateComputationModelRequest: S.Schema<CreateComputationModelRequest>;
export type ComputationModelState = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export declare const ComputationModelState: any;
export interface ComputationModelStatus {
    state: ComputationModelState;
    error?: ErrorDetails;
}
export declare const ComputationModelStatus: S.Schema<ComputationModelStatus>;
export interface CreateComputationModelResponse {
    computationModelId: string;
    computationModelArn: string;
    computationModelStatus: ComputationModelStatus;
}
export declare const CreateComputationModelResponse: S.Schema<CreateComputationModelResponse>;
export type DashboardDefinition = string;
export interface CreateDashboardRequest {
    projectId: string;
    dashboardName: string;
    dashboardDescription?: string;
    dashboardDefinition: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDashboardRequest: S.Schema<CreateDashboardRequest>;
export interface CreateDashboardResponse {
    dashboardId: string;
    dashboardArn: string;
}
export declare const CreateDashboardResponse: S.Schema<CreateDashboardResponse>;
export type DatasetTypeEnum = "SESSION" | "CURATED" | "EXTERNAL" | (string & {});
export declare const DatasetTypeEnum: any;
export interface SessionConfig {
    sessionStartTimestamp: TimeInNanos;
    sessionEndTimestamp: TimeInNanos;
}
export declare const SessionConfig: S.Schema<SessionConfig>;
export interface DatasetConfig {
    session?: SessionConfig;
}
export declare const DatasetConfig: S.Schema<DatasetConfig>;
export type MetadataKey = string;
export type MetadataValue = string;
export type Metadata = {
    [key: string]: string | undefined;
};
export declare const Metadata: any;
export type DatasetSourceType = "KENDRA" | "SITEWISE" | (string & {});
export declare const DatasetSourceType: any;
export type DatasetSourceFormat = "KNOWLEDGE_BASE" | "TIMESERIES" | (string & {});
export declare const DatasetSourceFormat: any;
export interface KendraSourceDetail {
    knowledgeBaseArn: string;
    roleArn: string;
}
export declare const KendraSourceDetail: S.Schema<KendraSourceDetail>;
export interface SourceDetail {
    kendra?: KendraSourceDetail;
}
export declare const SourceDetail: S.Schema<SourceDetail>;
export interface DatasetSource {
    sourceType: DatasetSourceType;
    sourceFormat: DatasetSourceFormat;
    sourceDetail?: SourceDetail;
}
export declare const DatasetSource: S.Schema<DatasetSource>;
export interface CreateDatasetRequest {
    datasetId?: string;
    datasetName: string;
    datasetDescription?: string;
    datasetType?: DatasetTypeEnum;
    datasetConfig?: DatasetConfig;
    workspaceName?: string;
    metadata?: {
        [key: string]: string | undefined;
    };
    datasetSource: DatasetSource;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDatasetRequest: S.Schema<CreateDatasetRequest>;
export type DatasetState = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export declare const DatasetState: any;
export interface DatasetStatus {
    state: DatasetState;
    error?: ErrorDetails;
}
export declare const DatasetStatus: S.Schema<DatasetStatus>;
export interface CreateDatasetResponse {
    datasetId: string;
    datasetArn: string;
    datasetStatus: DatasetStatus;
}
export declare const CreateDatasetResponse: S.Schema<CreateDatasetResponse>;
export type S3Uri = string;
export interface TrimSettings {
    startTime: TimeInNanos;
    endTime: TimeInNanos;
}
export declare const TrimSettings: S.Schema<TrimSettings>;
export type PositiveInteger = number;
export interface FormatSettings {
    framesPerSecond?: number;
    widthInPixels?: number;
    heightInPixels?: number;
}
export declare const FormatSettings: S.Schema<FormatSettings>;
export interface TimeseriesItem {
    timeSeriesId?: string;
    propertyAlias?: string;
    trimSettings?: TrimSettings;
    formatSettings?: FormatSettings;
}
export declare const TimeseriesItem: S.Schema<TimeseriesItem>;
export type TimeseriesList = TimeseriesItem[];
export declare const TimeseriesList: any;
export type DatasetId = string;
export type ExportDataType = "VIDEO" | "TELEMETRY" | "ANNOTATION" | (string & {});
export declare const ExportDataType: any;
export type ExportDataTypeList = ExportDataType[];
export declare const ExportDataTypeList: any;
export interface DatasetItem {
    datasetId: string;
    trimSettings?: TrimSettings;
    exportDataTypes?: ExportDataType[];
}
export declare const DatasetItem: S.Schema<DatasetItem>;
export type ProcessingInput = {
    timeseries: TimeseriesItem[];
    dataset?: never;
} | {
    timeseries?: never;
    dataset: DatasetItem;
};
export declare const ProcessingInput: any;
export interface ExportErrorReportLocation {
    s3Uri: string;
}
export declare const ExportErrorReportLocation: S.Schema<ExportErrorReportLocation>;
export interface CreateDatasetExportJobRequest {
    workspaceName: string;
    clientToken?: string;
    destinationS3Uri: string;
    input: ProcessingInput;
    errorReportLocation: ExportErrorReportLocation;
}
export declare const CreateDatasetExportJobRequest: S.Schema<CreateDatasetExportJobRequest>;
export type DatasetExportJobId = string;
export interface CreateDatasetExportJobResponse {
    jobId: string;
    workspaceName: string;
}
export declare const CreateDatasetExportJobResponse: S.Schema<CreateDatasetExportJobResponse>;
export interface EnrichmentTrimSettings {
    startTime: TimeInNanos;
    endTime: TimeInNanos;
}
export declare const EnrichmentTrimSettings: S.Schema<EnrichmentTrimSettings>;
export interface EventDetection {
    datasetId: string;
    timeSeriesId?: string;
    propertyAlias?: string;
    trimSettings: EnrichmentTrimSettings;
}
export declare const EventDetection: S.Schema<EventDetection>;
export type EnrichmentJobConfiguration = {
    eventDetection: EventDetection;
};
export declare const EnrichmentJobConfiguration: any;
export interface CreateEnrichmentJobRequest {
    workspaceName: string;
    jobConfiguration: EnrichmentJobConfiguration;
    clientToken?: string;
}
export declare const CreateEnrichmentJobRequest: S.Schema<CreateEnrichmentJobRequest>;
export interface CreateEnrichmentJobResponse {
    jobId: string;
    status: EnrichmentJobStatus;
    createdAt: Date;
}
export declare const CreateEnrichmentJobResponse: S.Schema<CreateEnrichmentJobResponse>;
export type GatewayName = string;
export interface Greengrass {
    groupArn: string;
}
export declare const Greengrass: S.Schema<Greengrass>;
export type CoreDeviceThingName = string;
export type CoreDeviceOperatingSystem = "LINUX_AARCH64" | "LINUX_AMD64" | "WINDOWS_AMD64" | (string & {});
export declare const CoreDeviceOperatingSystem: any;
export interface GreengrassV2 {
    coreDeviceThingName: string;
    coreDeviceOperatingSystem?: CoreDeviceOperatingSystem;
}
export declare const GreengrassV2: S.Schema<GreengrassV2>;
export type IotCoreThingName = string;
export interface SiemensIE {
    iotCoreThingName: string;
}
export declare const SiemensIE: S.Schema<SiemensIE>;
export interface GatewayPlatform {
    greengrass?: Greengrass;
    greengrassV2?: GreengrassV2;
    siemensIE?: SiemensIE;
}
export declare const GatewayPlatform: S.Schema<GatewayPlatform>;
export type GatewayVersion = string;
export interface CreateGatewayRequest {
    gatewayName: string;
    gatewayPlatform: GatewayPlatform;
    gatewayVersion?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateGatewayRequest: S.Schema<CreateGatewayRequest>;
export interface CreateGatewayResponse {
    gatewayId: string;
    gatewayArn: string;
}
export declare const CreateGatewayResponse: S.Schema<CreateGatewayResponse>;
export type EnvironmentVariableName = string;
export type EnvironmentVariableValue = string;
export type EnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export declare const EnvironmentVariablesMap: any;
export type ComputeNodeNameList = string[];
export declare const ComputeNodeNameList: any;
export interface ComputeNode {
    computeNodeName: string;
    taskName: string;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    dependsOn?: string[];
}
export declare const ComputeNode: S.Schema<ComputeNode>;
export type ComputeNodeList = ComputeNode[];
export declare const ComputeNodeList: any;
export interface CreatePipelineRequest {
    workspaceName: string;
    pipelineName: string;
    description?: string;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    computations: ComputeNode[];
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const CreatePipelineRequest: S.Schema<CreatePipelineRequest>;
export type ResourceErrorCode = "VALIDATION_ERROR" | "INTERNAL_FAILURE" | (string & {});
export declare const ResourceErrorCode: any;
export interface ResourceError {
    code?: ResourceErrorCode;
    message?: string;
}
export declare const ResourceError: S.Schema<ResourceError>;
export type ResourceState = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export declare const ResourceState: any;
export interface ResourceStatus {
    error?: ResourceError;
    state?: ResourceState;
}
export declare const ResourceStatus: S.Schema<ResourceStatus>;
export interface CreatePipelineResponse {
    pipelineName: string;
    pipelineArn: string;
    version: string;
    status: ResourceStatus;
}
export declare const CreatePipelineResponse: S.Schema<CreatePipelineResponse>;
export type Email = string | redacted.Redacted<string>;
export type ImageFileData = Uint8Array;
export type ImageFileType = "PNG" | (string & {});
export declare const ImageFileType: any;
export interface ImageFile {
    data: Uint8Array;
    type: ImageFileType;
}
export declare const ImageFile: S.Schema<ImageFile>;
export type AuthMode = "IAM" | "SSO" | (string & {});
export declare const AuthMode: any;
export interface Alarms {
    alarmRoleArn: string;
    notificationLambdaArn?: string;
}
export declare const Alarms: S.Schema<Alarms>;
export type PortalType = "SITEWISE_PORTAL_V1" | "SITEWISE_PORTAL_V2" | (string & {});
export declare const PortalType: any;
export type PortalTypeKey = string;
export type PortalTools = string[];
export declare const PortalTools: any;
export interface PortalTypeEntry {
    portalTools?: string[];
}
export declare const PortalTypeEntry: S.Schema<PortalTypeEntry>;
export type PortalTypeConfiguration = {
    [key: string]: PortalTypeEntry | undefined;
};
export declare const PortalTypeConfiguration: any;
export interface CreatePortalRequest {
    portalName: string;
    portalDescription?: string;
    portalContactEmail: string | redacted.Redacted<string>;
    clientToken?: string;
    portalLogoImageFile?: ImageFile;
    roleArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
    portalAuthMode?: AuthMode;
    notificationSenderEmail?: string | redacted.Redacted<string>;
    alarms?: Alarms;
    portalType?: PortalType;
    portalTypeConfiguration?: {
        [key: string]: PortalTypeEntry | undefined;
    };
}
export declare const CreatePortalRequest: S.Schema<CreatePortalRequest>;
export type Url = string;
export type PortalState = "CREATING" | "PENDING" | "UPDATING" | "DELETING" | "ACTIVE" | "FAILED" | (string & {});
export declare const PortalState: any;
export type MonitorErrorCode = "INTERNAL_FAILURE" | "VALIDATION_ERROR" | "LIMIT_EXCEEDED" | (string & {});
export declare const MonitorErrorCode: any;
export type MonitorErrorMessage = string;
export interface MonitorErrorDetails {
    code?: MonitorErrorCode;
    message?: string;
}
export declare const MonitorErrorDetails: S.Schema<MonitorErrorDetails>;
export interface PortalStatus {
    state: PortalState;
    error?: MonitorErrorDetails;
}
export declare const PortalStatus: S.Schema<PortalStatus>;
export type SSOApplicationId = string;
export interface CreatePortalResponse {
    portalId: string;
    portalArn: string;
    portalStartUrl: string;
    portalStatus: PortalStatus;
    ssoApplicationId: string;
}
export declare const CreatePortalResponse: S.Schema<CreatePortalResponse>;
export interface CreateProjectRequest {
    portalId: string;
    projectName: string;
    projectDescription?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateProjectRequest: S.Schema<CreateProjectRequest>;
export interface CreateProjectResponse {
    projectId: string;
    projectArn: string;
}
export declare const CreateProjectResponse: S.Schema<CreateProjectResponse>;
export type EcrUri = string | redacted.Redacted<string>;
export type IamRoleArn = string | redacted.Redacted<string>;
export type ProcessingType = "GENERIC_COMPUTE_PROCESSING" | "HARDWARE_ACCELERATED_PROCESSING" | (string & {});
export declare const ProcessingType: any;
export type ProcessingUnit = "UNITS_2" | "UNITS_4" | "UNITS_8" | "UNITS_12" | "UNITS_16" | "UNITS_24" | "UNITS_32" | "UNITS_36" | "UNITS_48" | "UNITS_60" | "UNITS_64" | "UNITS_72" | "UNITS_84" | "UNITS_96" | (string & {});
export declare const ProcessingUnit: any;
export type CommandList = string[];
export declare const CommandList: any;
export type TimeoutSeconds = number;
export interface ContainerTaskConfiguration {
    ecrUri: string | redacted.Redacted<string>;
    taskExecutionRole: string | redacted.Redacted<string>;
    processingType: ProcessingType;
    processingUnit: ProcessingUnit;
    command?: string[];
    timeoutSeconds?: number;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
}
export declare const ContainerTaskConfiguration: S.Schema<ContainerTaskConfiguration>;
export type TaskConfiguration = {
    containerTaskConfiguration: ContainerTaskConfiguration;
};
export declare const TaskConfiguration: any;
export interface CreateTaskRequest {
    workspaceName: string;
    taskName: string;
    description?: string;
    taskConfiguration: TaskConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const CreateTaskRequest: S.Schema<CreateTaskRequest>;
export interface CreateTaskResponse {
    taskName: string;
    taskArn: string;
    version: string;
    status: ResourceStatus;
}
export declare const CreateTaskResponse: S.Schema<CreateTaskResponse>;
export type EncryptionType = "SITEWISE_DEFAULT_ENCRYPTION" | "KMS_BASED_ENCRYPTION" | (string & {});
export declare const EncryptionType: any;
export type KmsKeyId = string;
export interface WorkspaceEncryptionConfiguration {
    encryptionType: EncryptionType;
    kmsKeyId?: string;
}
export declare const WorkspaceEncryptionConfiguration: S.Schema<WorkspaceEncryptionConfiguration>;
export interface CreateWorkspaceRequest {
    workspaceName: string;
    workspaceDescription?: string;
    encryptionConfiguration: WorkspaceEncryptionConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const CreateWorkspaceRequest: S.Schema<CreateWorkspaceRequest>;
export type WorkspaceState = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export declare const WorkspaceState: any;
export interface WorkspaceErrorDetails {
    code: ErrorCode;
    message: string;
}
export declare const WorkspaceErrorDetails: S.Schema<WorkspaceErrorDetails>;
export interface WorkspaceStatus {
    state: WorkspaceState;
    error?: WorkspaceErrorDetails;
}
export declare const WorkspaceStatus: S.Schema<WorkspaceStatus>;
export interface CreateWorkspaceResponse {
    workspaceName: string;
    workspaceArn: string;
    workspaceStatus: WorkspaceStatus;
}
export declare const CreateWorkspaceResponse: S.Schema<CreateWorkspaceResponse>;
export interface DeleteAccessPolicyRequest {
    accessPolicyId: string;
    clientToken?: string;
}
export declare const DeleteAccessPolicyRequest: S.Schema<DeleteAccessPolicyRequest>;
export interface DeleteAccessPolicyResponse {
}
export declare const DeleteAccessPolicyResponse: S.Schema<DeleteAccessPolicyResponse>;
export interface DeleteApplicationRequest {
    workspaceName: string;
    id: string;
}
export declare const DeleteApplicationRequest: S.Schema<DeleteApplicationRequest>;
export interface DeleteApplicationResponse {
}
export declare const DeleteApplicationResponse: S.Schema<DeleteApplicationResponse>;
export interface DeleteAssetRequest {
    assetId: string;
    clientToken?: string;
}
export declare const DeleteAssetRequest: S.Schema<DeleteAssetRequest>;
export interface DeleteAssetResponse {
    assetId?: string;
    assetStatus: AssetStatus;
}
export declare const DeleteAssetResponse: S.Schema<DeleteAssetResponse>;
export interface DeleteAssetModelRequest {
    assetModelId: string;
    clientToken?: string;
    ifMatch?: string;
    ifNoneMatch?: string;
    matchForVersionType?: AssetModelVersionType;
}
export declare const DeleteAssetModelRequest: S.Schema<DeleteAssetModelRequest>;
export interface DeleteAssetModelResponse {
    assetModelId?: string;
    assetModelStatus: AssetModelStatus;
}
export declare const DeleteAssetModelResponse: S.Schema<DeleteAssetModelResponse>;
export interface DeleteAssetModelCompositeModelRequest {
    assetModelId: string;
    assetModelCompositeModelId: string;
    clientToken?: string;
    ifMatch?: string;
    ifNoneMatch?: string;
    matchForVersionType?: AssetModelVersionType;
}
export declare const DeleteAssetModelCompositeModelRequest: S.Schema<DeleteAssetModelCompositeModelRequest>;
export interface DeleteAssetModelCompositeModelResponse {
    assetModelStatus: AssetModelStatus;
    assetModelId?: string;
}
export declare const DeleteAssetModelCompositeModelResponse: S.Schema<DeleteAssetModelCompositeModelResponse>;
export interface DeleteAssetModelInterfaceRelationshipRequest {
    assetModelId: string;
    interfaceAssetModelId: string;
    clientToken?: string;
}
export declare const DeleteAssetModelInterfaceRelationshipRequest: S.Schema<DeleteAssetModelInterfaceRelationshipRequest>;
export interface DeleteAssetModelInterfaceRelationshipResponse {
    assetModelId: string;
    interfaceAssetModelId: string;
    assetModelArn: string;
    assetModelStatus: AssetModelStatus;
}
export declare const DeleteAssetModelInterfaceRelationshipResponse: S.Schema<DeleteAssetModelInterfaceRelationshipResponse>;
export interface DeleteComputationModelRequest {
    computationModelId: string;
    clientToken?: string;
}
export declare const DeleteComputationModelRequest: S.Schema<DeleteComputationModelRequest>;
export interface DeleteComputationModelResponse {
    computationModelStatus: ComputationModelStatus;
}
export declare const DeleteComputationModelResponse: S.Schema<DeleteComputationModelResponse>;
export interface DeleteDashboardRequest {
    dashboardId: string;
    clientToken?: string;
}
export declare const DeleteDashboardRequest: S.Schema<DeleteDashboardRequest>;
export interface DeleteDashboardResponse {
}
export declare const DeleteDashboardResponse: S.Schema<DeleteDashboardResponse>;
export interface DeleteDatasetRequest {
    datasetId: string;
    workspaceName?: string;
    clientToken?: string;
}
export declare const DeleteDatasetRequest: S.Schema<DeleteDatasetRequest>;
export interface DeleteDatasetResponse {
    datasetStatus: DatasetStatus;
}
export declare const DeleteDatasetResponse: S.Schema<DeleteDatasetResponse>;
export interface DeleteGatewayRequest {
    gatewayId: string;
}
export declare const DeleteGatewayRequest: S.Schema<DeleteGatewayRequest>;
export interface DeleteGatewayResponse {
}
export declare const DeleteGatewayResponse: S.Schema<DeleteGatewayResponse>;
export interface DeletePipelineRequest {
    workspaceName: string;
    pipelineName: string;
}
export declare const DeletePipelineRequest: S.Schema<DeletePipelineRequest>;
export interface DeletePipelineResponse {
    status: ResourceStatus;
}
export declare const DeletePipelineResponse: S.Schema<DeletePipelineResponse>;
export interface DeletePortalRequest {
    portalId: string;
    clientToken?: string;
}
export declare const DeletePortalRequest: S.Schema<DeletePortalRequest>;
export interface DeletePortalResponse {
    portalStatus: PortalStatus;
}
export declare const DeletePortalResponse: S.Schema<DeletePortalResponse>;
export interface DeleteProjectRequest {
    projectId: string;
    clientToken?: string;
}
export declare const DeleteProjectRequest: S.Schema<DeleteProjectRequest>;
export interface DeleteProjectResponse {
}
export declare const DeleteProjectResponse: S.Schema<DeleteProjectResponse>;
export interface DeleteTaskRequest {
    workspaceName: string;
    taskName: string;
}
export declare const DeleteTaskRequest: S.Schema<DeleteTaskRequest>;
export interface DeleteTaskResponse {
    status: ResourceStatus;
}
export declare const DeleteTaskResponse: S.Schema<DeleteTaskResponse>;
export interface DeleteTimeSeriesRequest {
    alias?: string;
    assetId?: string;
    propertyId?: string;
    clientToken?: string;
    workspaceName?: string;
}
export declare const DeleteTimeSeriesRequest: S.Schema<DeleteTimeSeriesRequest>;
export interface DeleteTimeSeriesResponse {
}
export declare const DeleteTimeSeriesResponse: S.Schema<DeleteTimeSeriesResponse>;
export interface DeleteWorkspaceRequest {
    workspaceName: string;
    clientToken?: string;
}
export declare const DeleteWorkspaceRequest: S.Schema<DeleteWorkspaceRequest>;
export interface DeleteWorkspaceResponse {
    workspaceStatus: WorkspaceStatus;
}
export declare const DeleteWorkspaceResponse: S.Schema<DeleteWorkspaceResponse>;
export interface DescribeAccessPolicyRequest {
    accessPolicyId: string;
}
export declare const DescribeAccessPolicyRequest: S.Schema<DescribeAccessPolicyRequest>;
export interface DescribeAccessPolicyResponse {
    accessPolicyId: string;
    accessPolicyArn: string;
    accessPolicyIdentity: Identity;
    accessPolicyResource: Resource;
    accessPolicyPermission: Permission;
    accessPolicyCreationDate: Date;
    accessPolicyLastUpdateDate: Date;
}
export declare const DescribeAccessPolicyResponse: S.Schema<DescribeAccessPolicyResponse>;
export interface DescribeActionRequest {
    actionId: string;
}
export declare const DescribeActionRequest: S.Schema<DescribeActionRequest>;
export interface TargetResource {
    assetId?: string;
    computationModelId?: string;
}
export declare const TargetResource: S.Schema<TargetResource>;
export type ActionPayloadString = string;
export interface ActionPayload {
    stringValue: string;
}
export declare const ActionPayload: S.Schema<ActionPayload>;
export interface ResolveTo {
    assetId: string;
}
export declare const ResolveTo: S.Schema<ResolveTo>;
export interface DescribeActionResponse {
    actionId: string;
    targetResource: TargetResource;
    actionDefinitionId: string;
    actionPayload: ActionPayload;
    executionTime: Date;
    resolveTo?: ResolveTo;
}
export declare const DescribeActionResponse: S.Schema<DescribeActionResponse>;
export interface DescribeApplicationRequest {
    workspaceName: string;
    id: string;
}
export declare const DescribeApplicationRequest: S.Schema<DescribeApplicationRequest>;
export type ApplicationDescription = string;
export interface DescribeApplicationResponse {
    arn: string;
    createdAt: Date;
    dnsSubdomain: string;
    description?: string;
    id: string;
    idcApplicationArn: string;
    name: string;
    status: ApplicationStatus;
    updatedAt: Date;
    workspaceName: string;
}
export declare const DescribeApplicationResponse: S.Schema<DescribeApplicationResponse>;
export type ExcludeProperties = boolean;
export interface DescribeAssetRequest {
    assetId: string;
    excludeProperties?: boolean;
}
export declare const DescribeAssetRequest: S.Schema<DescribeAssetRequest>;
export type PropertyNotificationTopic = string;
export type PropertyNotificationState = "ENABLED" | "DISABLED" | (string & {});
export declare const PropertyNotificationState: any;
export interface PropertyNotification {
    topic: string;
    state: PropertyNotificationState;
}
export declare const PropertyNotification: S.Schema<PropertyNotification>;
export interface AssetPropertyPathSegment {
    id?: string;
    name?: string;
}
export declare const AssetPropertyPathSegment: S.Schema<AssetPropertyPathSegment>;
export type AssetPropertyPath = AssetPropertyPathSegment[];
export declare const AssetPropertyPath: any;
export interface AssetProperty {
    id: string;
    externalId?: string;
    name: string;
    alias?: string;
    notification?: PropertyNotification;
    dataType: PropertyDataType;
    dataTypeSpec?: string;
    unit?: string;
    path?: AssetPropertyPathSegment[];
}
export declare const AssetProperty: S.Schema<AssetProperty>;
export type AssetProperties = AssetProperty[];
export declare const AssetProperties: any;
export interface AssetHierarchy {
    id?: string;
    externalId?: string;
    name: string;
}
export declare const AssetHierarchy: S.Schema<AssetHierarchy>;
export type AssetHierarchies = AssetHierarchy[];
export declare const AssetHierarchies: any;
export interface AssetCompositeModel {
    name: string;
    description?: string;
    type: string;
    properties: AssetProperty[];
    id?: string;
    externalId?: string;
}
export declare const AssetCompositeModel: S.Schema<AssetCompositeModel>;
export type AssetCompositeModels = AssetCompositeModel[];
export declare const AssetCompositeModels: any;
export interface AssetCompositeModelPathSegment {
    id?: string;
    name?: string;
}
export declare const AssetCompositeModelPathSegment: S.Schema<AssetCompositeModelPathSegment>;
export type AssetCompositeModelPath = AssetCompositeModelPathSegment[];
export declare const AssetCompositeModelPath: any;
export interface AssetCompositeModelSummary {
    id: string;
    externalId?: string;
    name: string;
    type: string;
    description: string;
    path: AssetCompositeModelPathSegment[];
}
export declare const AssetCompositeModelSummary: S.Schema<AssetCompositeModelSummary>;
export type AssetCompositeModelSummaries = AssetCompositeModelSummary[];
export declare const AssetCompositeModelSummaries: any;
export interface DescribeAssetResponse {
    assetId: string;
    assetExternalId?: string;
    assetArn: string;
    assetName: string;
    assetModelId: string;
    assetProperties: AssetProperty[];
    assetHierarchies: AssetHierarchy[];
    assetCompositeModels?: AssetCompositeModel[];
    assetCreationDate: Date;
    assetLastUpdateDate: Date;
    assetStatus: AssetStatus;
    assetDescription?: string;
    assetCompositeModelSummaries?: AssetCompositeModelSummary[];
}
export declare const DescribeAssetResponse: S.Schema<DescribeAssetResponse>;
export interface DescribeAssetCompositeModelRequest {
    assetId: string;
    assetCompositeModelId: string;
}
export declare const DescribeAssetCompositeModelRequest: S.Schema<DescribeAssetCompositeModelRequest>;
export interface ActionDefinition {
    actionDefinitionId: string;
    actionName: string;
    actionType: string;
}
export declare const ActionDefinition: S.Schema<ActionDefinition>;
export type ActionDefinitions = ActionDefinition[];
export declare const ActionDefinitions: any;
export interface DescribeAssetCompositeModelResponse {
    assetId: string;
    assetCompositeModelId: string;
    assetCompositeModelExternalId?: string;
    assetCompositeModelPath: AssetCompositeModelPathSegment[];
    assetCompositeModelName: string;
    assetCompositeModelDescription: string;
    assetCompositeModelType: string;
    assetCompositeModelProperties: AssetProperty[];
    assetCompositeModelSummaries: AssetCompositeModelSummary[];
    actionDefinitions?: ActionDefinition[];
}
export declare const DescribeAssetCompositeModelResponse: S.Schema<DescribeAssetCompositeModelResponse>;
export type AssetModelVersionFilter = string;
export interface DescribeAssetModelRequest {
    assetModelId: string;
    excludeProperties?: boolean;
    assetModelVersion?: string;
}
export declare const DescribeAssetModelRequest: S.Schema<DescribeAssetModelRequest>;
export interface AssetModelProperty {
    id?: string;
    externalId?: string;
    name: string;
    dataType: PropertyDataType;
    dataTypeSpec?: string;
    unit?: string;
    type: PropertyType;
    path?: AssetModelPropertyPathSegment[];
}
export declare const AssetModelProperty: S.Schema<AssetModelProperty>;
export type AssetModelProperties = AssetModelProperty[];
export declare const AssetModelProperties: any;
export interface AssetModelHierarchy {
    id?: string;
    externalId?: string;
    name: string;
    childAssetModelId: string;
}
export declare const AssetModelHierarchy: S.Schema<AssetModelHierarchy>;
export type AssetModelHierarchies = AssetModelHierarchy[];
export declare const AssetModelHierarchies: any;
export interface AssetModelCompositeModel {
    name: string;
    description?: string;
    type: string;
    properties?: AssetModelProperty[];
    id?: string;
    externalId?: string;
}
export declare const AssetModelCompositeModel: S.Schema<AssetModelCompositeModel>;
export type AssetModelCompositeModels = AssetModelCompositeModel[];
export declare const AssetModelCompositeModels: any;
export interface AssetModelCompositeModelSummary {
    id: string;
    externalId?: string;
    name: string;
    type: string;
    description?: string;
    path?: AssetModelCompositeModelPathSegment[];
}
export declare const AssetModelCompositeModelSummary: S.Schema<AssetModelCompositeModelSummary>;
export type AssetModelCompositeModelSummaries = AssetModelCompositeModelSummary[];
export declare const AssetModelCompositeModelSummaries: any;
export interface InterfaceRelationship {
    id: string;
}
export declare const InterfaceRelationship: S.Schema<InterfaceRelationship>;
export type InterfaceDetails = InterfaceRelationship[];
export declare const InterfaceDetails: any;
export interface DescribeAssetModelResponse {
    assetModelId: string;
    assetModelExternalId?: string;
    assetModelArn: string;
    assetModelName: string;
    assetModelType?: AssetModelType;
    assetModelDescription: string;
    assetModelProperties: AssetModelProperty[];
    assetModelHierarchies: AssetModelHierarchy[];
    assetModelCompositeModels?: AssetModelCompositeModel[];
    assetModelCompositeModelSummaries?: AssetModelCompositeModelSummary[];
    assetModelCreationDate: Date;
    assetModelLastUpdateDate: Date;
    assetModelStatus: AssetModelStatus;
    assetModelVersion?: string;
    interfaceDetails?: InterfaceRelationship[];
    eTag?: string;
}
export declare const DescribeAssetModelResponse: S.Schema<DescribeAssetModelResponse>;
export interface DescribeAssetModelCompositeModelRequest {
    assetModelId: string;
    assetModelCompositeModelId: string;
    assetModelVersion?: string;
}
export declare const DescribeAssetModelCompositeModelRequest: S.Schema<DescribeAssetModelCompositeModelRequest>;
export interface CompositionRelationshipItem {
    id?: string;
}
export declare const CompositionRelationshipItem: S.Schema<CompositionRelationshipItem>;
export type CompositionRelationship = CompositionRelationshipItem[];
export declare const CompositionRelationship: any;
export interface CompositionDetails {
    compositionRelationship?: CompositionRelationshipItem[];
}
export declare const CompositionDetails: S.Schema<CompositionDetails>;
export interface DescribeAssetModelCompositeModelResponse {
    assetModelId: string;
    assetModelCompositeModelId: string;
    assetModelCompositeModelExternalId?: string;
    assetModelCompositeModelPath: AssetModelCompositeModelPathSegment[];
    assetModelCompositeModelName: string;
    assetModelCompositeModelDescription: string;
    assetModelCompositeModelType: string;
    assetModelCompositeModelProperties: AssetModelProperty[];
    compositionDetails?: CompositionDetails;
    assetModelCompositeModelSummaries: AssetModelCompositeModelSummary[];
    actionDefinitions?: ActionDefinition[];
}
export declare const DescribeAssetModelCompositeModelResponse: S.Schema<DescribeAssetModelCompositeModelResponse>;
export interface DescribeAssetModelInterfaceRelationshipRequest {
    assetModelId: string;
    interfaceAssetModelId: string;
}
export declare const DescribeAssetModelInterfaceRelationshipRequest: S.Schema<DescribeAssetModelInterfaceRelationshipRequest>;
export interface PropertyMapping {
    assetModelPropertyId: string;
    interfaceAssetModelPropertyId: string;
}
export declare const PropertyMapping: S.Schema<PropertyMapping>;
export type PropertyMappings = PropertyMapping[];
export declare const PropertyMappings: any;
export interface HierarchyMapping {
    assetModelHierarchyId: string;
    interfaceAssetModelHierarchyId: string;
}
export declare const HierarchyMapping: S.Schema<HierarchyMapping>;
export type HierarchyMappings = HierarchyMapping[];
export declare const HierarchyMappings: any;
export interface DescribeAssetModelInterfaceRelationshipResponse {
    assetModelId: string;
    interfaceAssetModelId: string;
    propertyMappings: PropertyMapping[];
    hierarchyMappings: HierarchyMapping[];
}
export declare const DescribeAssetModelInterfaceRelationshipResponse: S.Schema<DescribeAssetModelInterfaceRelationshipResponse>;
export interface DescribeAssetPropertyRequest {
    assetId: string;
    propertyId: string;
}
export declare const DescribeAssetPropertyRequest: S.Schema<DescribeAssetPropertyRequest>;
export interface Property {
    id: string;
    externalId?: string;
    name: string;
    alias?: string;
    notification?: PropertyNotification;
    dataType: PropertyDataType;
    unit?: string;
    type?: PropertyType;
    path?: AssetPropertyPathSegment[];
}
export declare const Property: S.Schema<Property>;
export interface CompositeModelProperty {
    name: string;
    type: string;
    assetProperty: Property;
    id?: string;
    externalId?: string;
}
export declare const CompositeModelProperty: S.Schema<CompositeModelProperty>;
export interface DescribeAssetPropertyResponse {
    assetId: string;
    assetExternalId?: string;
    assetName: string;
    assetModelId: string;
    assetProperty?: Property;
    compositeModel?: CompositeModelProperty;
}
export declare const DescribeAssetPropertyResponse: S.Schema<DescribeAssetPropertyResponse>;
export interface DescribeBulkImportJobRequest {
    jobId: string;
    workspaceName?: string;
}
export declare const DescribeBulkImportJobRequest: S.Schema<DescribeBulkImportJobRequest>;
export interface DescribeBulkImportJobResponse {
    jobId: string;
    jobName: string;
    jobStatus: JobStatus;
    jobRoleArn: string;
    files: File[];
    errorReportLocation: ErrorReportLocation;
    jobConfiguration?: JobConfiguration;
    jobCreationDate: Date;
    jobLastUpdateDate: Date;
    adaptiveIngestion?: boolean;
    deleteFilesAfterImport?: boolean;
    datasetId?: string;
    workspaceName?: string;
}
export declare const DescribeBulkImportJobResponse: S.Schema<DescribeBulkImportJobResponse>;
export type ComputationModelVersionFilter = string;
export interface DescribeComputationModelRequest {
    computationModelId: string;
    computationModelVersion?: string;
}
export declare const DescribeComputationModelRequest: S.Schema<DescribeComputationModelRequest>;
export interface DescribeComputationModelResponse {
    computationModelId: string;
    computationModelArn: string;
    computationModelName: string;
    computationModelDescription?: string;
    computationModelConfiguration: ComputationModelConfiguration;
    computationModelDataBinding: {
        [key: string]: ComputationModelDataBindingValue | undefined;
    };
    computationModelCreationDate: Date;
    computationModelLastUpdateDate: Date;
    computationModelStatus: ComputationModelStatus;
    computationModelVersion: string;
    actionDefinitions: ActionDefinition[];
}
export declare const DescribeComputationModelResponse: S.Schema<DescribeComputationModelResponse>;
export type ResolveToResourceType = "ASSET" | (string & {});
export declare const ResolveToResourceType: any;
export interface DescribeComputationModelExecutionSummaryRequest {
    computationModelId: string;
    resolveToResourceType?: ResolveToResourceType;
    resolveToResourceId?: string;
}
export declare const DescribeComputationModelExecutionSummaryRequest: S.Schema<DescribeComputationModelExecutionSummaryRequest>;
export type ComputationModelExecutionSummaryKey = string;
export type ComputationModelExecutionSummaryValue = string;
export type ComputationModelExecutionSummary = {
    [key: string]: string | undefined;
};
export declare const ComputationModelExecutionSummary: any;
export interface DescribeComputationModelExecutionSummaryResponse {
    computationModelId: string;
    resolveTo?: ResolveTo;
    computationModelExecutionSummary: {
        [key: string]: string | undefined;
    };
}
export declare const DescribeComputationModelExecutionSummaryResponse: S.Schema<DescribeComputationModelExecutionSummaryResponse>;
export interface DescribeDashboardRequest {
    dashboardId: string;
}
export declare const DescribeDashboardRequest: S.Schema<DescribeDashboardRequest>;
export interface DescribeDashboardResponse {
    dashboardId: string;
    dashboardArn: string;
    dashboardName: string;
    projectId: string;
    dashboardDescription?: string;
    dashboardDefinition: string;
    dashboardCreationDate: Date;
    dashboardLastUpdateDate: Date;
}
export declare const DescribeDashboardResponse: S.Schema<DescribeDashboardResponse>;
export interface DescribeDatasetRequest {
    datasetId: string;
    workspaceName?: string;
    datasetVersion?: string;
}
export declare const DescribeDatasetRequest: S.Schema<DescribeDatasetRequest>;
export type DatasetEnrichmentStatus = "FULLY_ENRICHED" | "PARTIALLY_ENRICHED" | "NOT_ENRICHED" | (string & {});
export declare const DatasetEnrichmentStatus: any;
export interface DatasetEnrichmentEntry {
    status: DatasetEnrichmentStatus;
    lastEnrichedAt?: Date;
}
export declare const DatasetEnrichmentEntry: S.Schema<DatasetEnrichmentEntry>;
export interface DatasetEnrichment {
    video?: DatasetEnrichmentEntry;
}
export declare const DatasetEnrichment: S.Schema<DatasetEnrichment>;
export interface DescribeDatasetResponse {
    datasetId: string;
    datasetArn: string;
    datasetName: string;
    datasetDescription: string;
    datasetType?: DatasetTypeEnum;
    datasetConfig?: DatasetConfig;
    workspaceName?: string;
    metadata?: {
        [key: string]: string | undefined;
    };
    datasetSource: DatasetSource;
    datasetStatus: DatasetStatus;
    datasetCreationDate: Date;
    datasetLastUpdateDate: Date;
    datasetVersion?: string;
    enrichmentStatus?: DatasetEnrichment;
}
export declare const DescribeDatasetResponse: S.Schema<DescribeDatasetResponse>;
export interface DescribeDatasetExportJobRequest {
    workspaceName: string;
    jobId: string;
}
export declare const DescribeDatasetExportJobRequest: S.Schema<DescribeDatasetExportJobRequest>;
export type DatasetExportJobStatus = "SUBMITTED" | "RUNNING" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "FAILED" | (string & {});
export declare const DatasetExportJobStatus: any;
export interface DescribeDatasetExportJobResponse {
    jobId: string;
    workspaceName: string;
    status: DatasetExportJobStatus;
    startedAt: Date;
    completedAt?: Date;
    destinationS3Uri: string;
    errorReportLocation: ExportErrorReportLocation;
    input: ProcessingInput;
}
export declare const DescribeDatasetExportJobResponse: S.Schema<DescribeDatasetExportJobResponse>;
export interface DescribeDefaultEncryptionConfigurationRequest {
}
export declare const DescribeDefaultEncryptionConfigurationRequest: S.Schema<DescribeDefaultEncryptionConfigurationRequest>;
export type ConfigurationState = "ACTIVE" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | (string & {});
export declare const ConfigurationState: any;
export interface ConfigurationErrorDetails {
    code: ErrorCode;
    message: string;
}
export declare const ConfigurationErrorDetails: S.Schema<ConfigurationErrorDetails>;
export interface ConfigurationStatus {
    state: ConfigurationState;
    error?: ConfigurationErrorDetails;
}
export declare const ConfigurationStatus: S.Schema<ConfigurationStatus>;
export interface DescribeDefaultEncryptionConfigurationResponse {
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
    configurationStatus: ConfigurationStatus;
}
export declare const DescribeDefaultEncryptionConfigurationResponse: S.Schema<DescribeDefaultEncryptionConfigurationResponse>;
export interface DescribeEnrichmentJobRequest {
    workspaceName: string;
    jobId: string;
}
export declare const DescribeEnrichmentJobRequest: S.Schema<DescribeEnrichmentJobRequest>;
export type JobType = "EVENT_DETECTION" | (string & {});
export declare const JobType: any;
export interface DescribeEnrichmentJobResponse {
    jobId: string;
    status: EnrichmentJobStatus;
    workspaceName: string;
    jobType: JobType;
    jobConfiguration: EnrichmentJobConfiguration;
    createdAt: Date;
    updatedAt?: Date;
    completedAt?: Date;
    cancelledAt?: Date;
    failureMessage?: string;
}
export declare const DescribeEnrichmentJobResponse: S.Schema<DescribeEnrichmentJobResponse>;
export interface DescribeExecutionRequest {
    executionId: string;
}
export declare const DescribeExecutionRequest: S.Schema<DescribeExecutionRequest>;
export type ExecutionState = "RUNNING" | "COMPLETED" | "FAILED" | (string & {});
export declare const ExecutionState: any;
export interface ExecutionStatus {
    state: ExecutionState;
}
export declare const ExecutionStatus: S.Schema<ExecutionStatus>;
export type ExecutionResultKey = string;
export type ExecutionResultValue = string;
export type ExecutionResult = {
    [key: string]: string | undefined;
};
export declare const ExecutionResult: any;
export type ExecutionDetailsKey = string;
export type ExecutionDetailsValue = string;
export type ExecutionDetails = {
    [key: string]: string | undefined;
};
export declare const ExecutionDetails: any;
export interface DescribeExecutionResponse {
    executionId: string;
    actionType?: string;
    targetResource: TargetResource;
    targetResourceVersion: string;
    resolveTo?: ResolveTo;
    executionStartTime: Date;
    executionEndTime?: Date;
    executionStatus: ExecutionStatus;
    executionResult?: {
        [key: string]: string | undefined;
    };
    executionDetails?: {
        [key: string]: string | undefined;
    };
    executionEntityVersion?: string;
}
export declare const DescribeExecutionResponse: S.Schema<DescribeExecutionResponse>;
export interface DescribeGatewayRequest {
    gatewayId: string;
}
export declare const DescribeGatewayRequest: S.Schema<DescribeGatewayRequest>;
export type CapabilityNamespace = string;
export type CapabilitySyncStatus = "IN_SYNC" | "OUT_OF_SYNC" | "SYNC_FAILED" | "UNKNOWN" | "NOT_APPLICABLE" | (string & {});
export declare const CapabilitySyncStatus: any;
export interface GatewayCapabilitySummary {
    capabilityNamespace: string;
    capabilitySyncStatus: CapabilitySyncStatus;
}
export declare const GatewayCapabilitySummary: S.Schema<GatewayCapabilitySummary>;
export type GatewayCapabilitySummaries = GatewayCapabilitySummary[];
export declare const GatewayCapabilitySummaries: any;
export interface DescribeGatewayResponse {
    gatewayId: string;
    gatewayName: string;
    gatewayArn: string;
    gatewayPlatform?: GatewayPlatform;
    gatewayVersion?: string;
    gatewayCapabilitySummaries: GatewayCapabilitySummary[];
    creationDate: Date;
    lastUpdateDate: Date;
}
export declare const DescribeGatewayResponse: S.Schema<DescribeGatewayResponse>;
export interface DescribeGatewayCapabilityConfigurationRequest {
    gatewayId: string;
    capabilityNamespace: string;
}
export declare const DescribeGatewayCapabilityConfigurationRequest: S.Schema<DescribeGatewayCapabilityConfigurationRequest>;
export type CapabilityConfiguration = string;
export interface DescribeGatewayCapabilityConfigurationResponse {
    gatewayId: string;
    capabilityNamespace: string;
    capabilityConfiguration: string;
    capabilitySyncStatus: CapabilitySyncStatus;
}
export declare const DescribeGatewayCapabilityConfigurationResponse: S.Schema<DescribeGatewayCapabilityConfigurationResponse>;
export interface DescribeLoggingOptionsRequest {
    workspaceName?: string;
}
export declare const DescribeLoggingOptionsRequest: S.Schema<DescribeLoggingOptionsRequest>;
export type LoggingLevel = "ERROR" | "INFO" | "OFF" | (string & {});
export declare const LoggingLevel: any;
export interface LoggingOptions {
    level: LoggingLevel;
}
export declare const LoggingOptions: S.Schema<LoggingOptions>;
export interface DescribeLoggingOptionsResponse {
    loggingOptions: LoggingOptions;
}
export declare const DescribeLoggingOptionsResponse: S.Schema<DescribeLoggingOptionsResponse>;
export interface DescribePipelineRequest {
    workspaceName: string;
    pipelineName: string;
    pipelineVersion?: string;
}
export declare const DescribePipelineRequest: S.Schema<DescribePipelineRequest>;
export interface DescribePipelineResponse {
    pipelineName: string;
    workspaceName: string;
    description?: string;
    pipelineArn: string;
    version: string;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    computations: ComputeNode[];
    status: ResourceStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const DescribePipelineResponse: S.Schema<DescribePipelineResponse>;
export type PaginationToken = string;
export type DescribePipelineExecutionRequestMaxResultsInteger = number;
export interface DescribePipelineExecutionRequest {
    workspaceName: string;
    pipelineName: string;
    pipelineExecutionId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const DescribePipelineExecutionRequest: S.Schema<DescribePipelineExecutionRequest>;
export type PipelineErrorCode = "VALIDATION_ERROR" | "INTERNAL_FAILURE" | "EXECUTION_ERROR" | "TIMED_OUT" | (string & {});
export declare const PipelineErrorCode: any;
export type DetailedPipelineErrorCode = "VALIDATION_ERROR" | "INTERNAL_FAILURE" | "EXECUTION_ERROR" | "TIMED_OUT" | (string & {});
export declare const DetailedPipelineErrorCode: any;
export interface DetailedPipelineError {
    code: DetailedPipelineErrorCode;
    message: string;
}
export declare const DetailedPipelineError: S.Schema<DetailedPipelineError>;
export type DetailedErrorList = DetailedPipelineError[];
export declare const DetailedErrorList: any;
export interface PipelineExecutionStateDetails {
    code?: PipelineErrorCode;
    message: string;
    details?: DetailedPipelineError[];
}
export declare const PipelineExecutionStateDetails: S.Schema<PipelineExecutionStateDetails>;
export interface PipelineExecutionStatus {
    state: PipelineExecutionState;
    stateDetails?: PipelineExecutionStateDetails;
}
export declare const PipelineExecutionStatus: S.Schema<PipelineExecutionStatus>;
export type ComputeNodeEnvironmentVariablesMap = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export declare const ComputeNodeEnvironmentVariablesMap: any;
export interface ExecutionEnvironmentVariables {
    global?: {
        [key: string]: string | undefined;
    };
    computeNodes?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
}
export declare const ExecutionEnvironmentVariables: S.Schema<ExecutionEnvironmentVariables>;
export type ExecutionPriority = number;
export type ComputeNodeExecutionState = "NOT_STARTED" | "QUEUED" | "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const ComputeNodeExecutionState: any;
export type ComputeNodeErrorCode = "VALIDATION_ERROR" | "INTERNAL_FAILURE" | "EXECUTION_ERROR" | "TIMED_OUT" | (string & {});
export declare const ComputeNodeErrorCode: any;
export interface ComputeNodeExecutionStateDetails {
    code: ComputeNodeErrorCode;
    message: string;
    details?: DetailedPipelineError[];
}
export declare const ComputeNodeExecutionStateDetails: S.Schema<ComputeNodeExecutionStateDetails>;
export interface ComputeNodeExecutionStatus {
    state: ComputeNodeExecutionState;
    stateDetails?: ComputeNodeExecutionStateDetails;
}
export declare const ComputeNodeExecutionStatus: S.Schema<ComputeNodeExecutionStatus>;
export type ExecutionEnvironmentVariablesMapKeyString = string;
export type ExecutionEnvironmentVariablesMapValueString = string;
export type ExecutionEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export declare const ExecutionEnvironmentVariablesMap: any;
export interface ComputeNodeExecutionDetails {
    computeNodeName: string;
    taskName: string;
    taskArn: string;
    taskVersion: string;
    dependsOn: string[];
    status: ComputeNodeExecutionStatus;
    startTime?: Date;
    endTime?: Date;
    executionEnvironmentVariables?: {
        [key: string]: string | undefined;
    };
}
export declare const ComputeNodeExecutionDetails: S.Schema<ComputeNodeExecutionDetails>;
export type ComputeNodeExecutionDetailsList = ComputeNodeExecutionDetails[];
export declare const ComputeNodeExecutionDetailsList: any;
export interface DescribePipelineExecutionResponse {
    pipelineExecutionId: string;
    pipelineName: string;
    workspaceName: string;
    pipelineVersion: string;
    status: PipelineExecutionStatus;
    startTime?: Date;
    endTime?: Date;
    requestEnvironmentVariables: ExecutionEnvironmentVariables;
    executionPriority?: number;
    computeNodeExecutionDetails: ComputeNodeExecutionDetails[];
    nextToken?: string;
}
export declare const DescribePipelineExecutionResponse: S.Schema<DescribePipelineExecutionResponse>;
export interface DescribePortalRequest {
    portalId: string;
}
export declare const DescribePortalRequest: S.Schema<DescribePortalRequest>;
export type PortalClientId = string;
export interface ImageLocation {
    id: string;
    url: string;
}
export declare const ImageLocation: S.Schema<ImageLocation>;
export interface DescribePortalResponse {
    portalId: string;
    portalArn: string;
    portalName: string;
    portalDescription?: string;
    portalClientId: string;
    portalStartUrl: string;
    portalContactEmail: string | redacted.Redacted<string>;
    portalStatus: PortalStatus;
    portalCreationDate: Date;
    portalLastUpdateDate: Date;
    portalLogoImageLocation?: ImageLocation;
    roleArn?: string;
    portalAuthMode?: AuthMode;
    notificationSenderEmail?: string | redacted.Redacted<string>;
    alarms?: Alarms;
    portalType?: PortalType;
    portalTypeConfiguration?: {
        [key: string]: PortalTypeEntry | undefined;
    };
}
export declare const DescribePortalResponse: S.Schema<DescribePortalResponse>;
export interface DescribeProjectRequest {
    projectId: string;
}
export declare const DescribeProjectRequest: S.Schema<DescribeProjectRequest>;
export interface DescribeProjectResponse {
    projectId: string;
    projectArn: string;
    projectName: string;
    portalId: string;
    projectDescription?: string;
    projectCreationDate: Date;
    projectLastUpdateDate: Date;
}
export declare const DescribeProjectResponse: S.Schema<DescribeProjectResponse>;
export interface DescribeQueryRequest {
    workspaceName: string;
    queryId: string;
}
export declare const DescribeQueryRequest: S.Schema<DescribeQueryRequest>;
export interface QueryStatistics {
    rowCount: number;
    bytesScanned: number;
    executionTimeInMillis: number;
}
export declare const QueryStatistics: S.Schema<QueryStatistics>;
export type QueryErrorMessage = string;
export interface DescribeQueryResponse {
    queryId: string;
    status: QueryStatus;
    submittedAt: Date;
    completedAt?: Date;
    statistics?: QueryStatistics;
    errorMessage?: string;
}
export declare const DescribeQueryResponse: S.Schema<DescribeQueryResponse>;
export type SearchId = string;
export interface DescribeSearchRequest {
    workspaceName: string;
    searchId: string;
}
export declare const DescribeSearchRequest: S.Schema<DescribeSearchRequest>;
export type SearchStatus = "QUEUED" | "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const SearchStatus: any;
export type SearchQueryStatement = string | redacted.Redacted<string>;
export type SearchType = "DEEP" | "QUICK" | (string & {});
export declare const SearchType: any;
export type GroupId = string;
export interface DescribeSearchResponse {
    searchId: string;
    workspaceName: string;
    status: SearchStatus;
    queryStatement: string | redacted.Redacted<string>;
    searchType: SearchType;
    statusReason?: string;
    startedAt?: Date;
    groupId?: string;
}
export declare const DescribeSearchResponse: S.Schema<DescribeSearchResponse>;
export interface DescribeStorageConfigurationRequest {
}
export declare const DescribeStorageConfigurationRequest: S.Schema<DescribeStorageConfigurationRequest>;
export type StorageType = "SITEWISE_DEFAULT_STORAGE" | "MULTI_LAYER_STORAGE" | (string & {});
export declare const StorageType: any;
export interface CustomerManagedS3Storage {
    s3ResourceArn: string;
    roleArn: string;
}
export declare const CustomerManagedS3Storage: S.Schema<CustomerManagedS3Storage>;
export interface MultiLayerStorage {
    customerManagedS3Storage: CustomerManagedS3Storage;
}
export declare const MultiLayerStorage: S.Schema<MultiLayerStorage>;
export type DisassociatedDataStorageState = "ENABLED" | "DISABLED" | (string & {});
export declare const DisassociatedDataStorageState: any;
export type NumberOfDays = number;
export type Unlimited = boolean;
export interface RetentionPeriod {
    numberOfDays?: number;
    unlimited?: boolean;
}
export declare const RetentionPeriod: S.Schema<RetentionPeriod>;
export type WarmTierState = "ENABLED" | "DISABLED" | (string & {});
export declare const WarmTierState: any;
export interface WarmTierRetentionPeriod {
    numberOfDays?: number;
    unlimited?: boolean;
}
export declare const WarmTierRetentionPeriod: S.Schema<WarmTierRetentionPeriod>;
export type DisallowIngestNullNaN = boolean;
export interface DescribeStorageConfigurationResponse {
    storageType: StorageType;
    multiLayerStorage?: MultiLayerStorage;
    disassociatedDataStorage?: DisassociatedDataStorageState;
    retentionPeriod?: RetentionPeriod;
    configurationStatus: ConfigurationStatus;
    lastUpdateDate?: Date;
    warmTier?: WarmTierState;
    warmTierRetentionPeriod?: WarmTierRetentionPeriod;
    disallowIngestNullNaN?: boolean;
}
export declare const DescribeStorageConfigurationResponse: S.Schema<DescribeStorageConfigurationResponse>;
export interface DescribeTaskRequest {
    workspaceName: string;
    taskName: string;
    taskVersion?: string;
}
export declare const DescribeTaskRequest: S.Schema<DescribeTaskRequest>;
export interface DescribeTaskResponse {
    workspaceName: string;
    taskName: string;
    description?: string;
    taskArn: string;
    version: string;
    taskConfiguration: TaskConfiguration;
    status: ResourceStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const DescribeTaskResponse: S.Schema<DescribeTaskResponse>;
export interface DescribeTimeSeriesRequest {
    alias?: string;
    assetId?: string;
    propertyId?: string;
    workspaceName?: string;
}
export declare const DescribeTimeSeriesRequest: S.Schema<DescribeTimeSeriesRequest>;
export interface DescribeTimeSeriesResponse {
    assetId?: string;
    propertyId?: string;
    alias?: string;
    timeSeriesId: string;
    dataType: PropertyDataType;
    dataTypeSpec?: string;
    timeSeriesCreationDate: Date;
    timeSeriesLastUpdateDate: Date;
    timeSeriesArn: string;
    workspaceName?: string;
}
export declare const DescribeTimeSeriesResponse: S.Schema<DescribeTimeSeriesResponse>;
export interface DescribeWorkspaceRequest {
    workspaceName: string;
}
export declare const DescribeWorkspaceRequest: S.Schema<DescribeWorkspaceRequest>;
export interface WorkspaceEncryptionConfigurationInfo {
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
}
export declare const WorkspaceEncryptionConfigurationInfo: S.Schema<WorkspaceEncryptionConfigurationInfo>;
export interface DescribeWorkspaceResponse {
    workspaceArn: string;
    workspaceName: string;
    workspaceDescription?: string;
    workspaceStatus: WorkspaceStatus;
    encryptionConfiguration?: WorkspaceEncryptionConfigurationInfo;
    createdAt: Date;
    updatedAt: Date;
}
export declare const DescribeWorkspaceResponse: S.Schema<DescribeWorkspaceResponse>;
export interface DisassociateAssetsRequest {
    assetId: string;
    hierarchyId: string;
    childAssetId: string;
    clientToken?: string;
}
export declare const DisassociateAssetsRequest: S.Schema<DisassociateAssetsRequest>;
export interface DisassociateAssetsResponse {
}
export declare const DisassociateAssetsResponse: S.Schema<DisassociateAssetsResponse>;
export interface DisassociateTimeSeriesFromAssetPropertyRequest {
    alias: string;
    assetId: string;
    propertyId: string;
    clientToken?: string;
}
export declare const DisassociateTimeSeriesFromAssetPropertyRequest: S.Schema<DisassociateTimeSeriesFromAssetPropertyRequest>;
export interface DisassociateTimeSeriesFromAssetPropertyResponse {
}
export declare const DisassociateTimeSeriesFromAssetPropertyResponse: S.Schema<DisassociateTimeSeriesFromAssetPropertyResponse>;
export interface ExecuteActionRequest {
    targetResource: TargetResource;
    actionDefinitionId: string;
    actionPayload: ActionPayload;
    clientToken?: string;
    resolveTo?: ResolveTo;
}
export declare const ExecuteActionRequest: S.Schema<ExecuteActionRequest>;
export interface ExecuteActionResponse {
    actionId: string;
}
export declare const ExecuteActionResponse: S.Schema<ExecuteActionResponse>;
export type QueryStatement = string | redacted.Redacted<string>;
export type ExecuteQueryNextToken = string;
export type ExecuteQueryMaxResults = number;
export interface ExecuteQueryRequest {
    queryStatement: string | redacted.Redacted<string>;
    nextToken?: string;
    maxResults?: number;
    clientToken?: string;
}
export declare const ExecuteQueryRequest: S.Schema<ExecuteQueryRequest>;
export type ScalarType = "BOOLEAN" | "INT" | "DOUBLE" | "TIMESTAMP" | "STRING" | (string & {});
export declare const ScalarType: any;
export interface ColumnType {
    scalarType?: ScalarType;
}
export declare const ColumnType: S.Schema<ColumnType>;
export interface ColumnInfo {
    name?: string;
    type?: ColumnType;
}
export declare const ColumnInfo: S.Schema<ColumnInfo>;
export type ColumnsList = ColumnInfo[];
export declare const ColumnsList: any;
export type ScalarValue = string;
export interface Datum {
    scalarValue?: string;
    arrayValue?: Datum[];
    rowValue?: Row;
    nullValue?: boolean;
}
export declare const Datum: S.Schema<Datum>;
export type DatumList = Datum[];
export declare const DatumList: S.Schema<DatumList>;
export interface Row {
    data: Datum[];
}
export declare const Row: S.Schema<Row>;
export type Rows = Row[];
export declare const Rows: any;
export interface ExecuteQueryResponse {
    columns?: ColumnInfo[];
    rows?: Row[];
    nextToken?: string;
}
export declare const ExecuteQueryResponse: S.Schema<ExecuteQueryResponse>;
export type GetAssetPropertyValueAggregatesMaxResults = number;
export interface GetAssetPropertyAggregatesRequest {
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    aggregateTypes: AggregateType[];
    resolution: string;
    qualities?: Quality[];
    startDate: Date;
    endDate: Date;
    timeOrdering?: TimeOrdering;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetAssetPropertyAggregatesRequest: S.Schema<GetAssetPropertyAggregatesRequest>;
export interface GetAssetPropertyAggregatesResponse {
    aggregatedValues: AggregatedValue[];
    nextToken?: string;
}
export declare const GetAssetPropertyAggregatesResponse: S.Schema<GetAssetPropertyAggregatesResponse>;
export interface GetAssetPropertyValueRequest {
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
}
export declare const GetAssetPropertyValueRequest: S.Schema<GetAssetPropertyValueRequest>;
export interface GetAssetPropertyValueResponse {
    propertyValue?: AssetPropertyValue;
}
export declare const GetAssetPropertyValueResponse: S.Schema<GetAssetPropertyValueResponse>;
export type GetAssetPropertyValueHistoryMaxResults = number;
export interface GetAssetPropertyValueHistoryRequest {
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    startDate?: Date;
    endDate?: Date;
    qualities?: Quality[];
    timeOrdering?: TimeOrdering;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetAssetPropertyValueHistoryRequest: S.Schema<GetAssetPropertyValueHistoryRequest>;
export interface GetAssetPropertyValueHistoryResponse {
    assetPropertyValueHistory: AssetPropertyValue[];
    nextToken?: string;
}
export declare const GetAssetPropertyValueHistoryResponse: S.Schema<GetAssetPropertyValueHistoryResponse>;
export type GetCaptureDataNextToken = string;
export interface GetCaptureDataRequest {
    workspaceName: string;
    startTime: TimeInNanos;
    endTime: TimeInNanos;
    timeSeriesId?: string;
    propertyAlias?: string;
    formatSettings?: FormatSettings;
    nextToken?: string;
}
export declare const GetCaptureDataRequest: S.Schema<GetCaptureDataRequest>;
export type CaptureBlob = Uint8Array;
export type VideoDataType = "VIDEO-MP4" | (string & {});
export declare const VideoDataType: any;
export interface GetCaptureDataResponse {
    data: Uint8Array;
    startTime: TimeInNanos;
    endTime: TimeInNanos;
    dataType: VideoDataType;
    nextToken?: string;
}
export declare const GetCaptureDataResponse: S.Schema<GetCaptureDataResponse>;
export type IntervalInSeconds = number;
export type MaxInterpolatedResults = number;
export type InterpolationType = string;
export type IntervalWindowInSeconds = number;
export interface GetInterpolatedAssetPropertyValuesRequest {
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    startTimeInSeconds: number;
    startTimeOffsetInNanos?: number;
    endTimeInSeconds: number;
    endTimeOffsetInNanos?: number;
    quality: Quality;
    intervalInSeconds: number;
    nextToken?: string;
    maxResults?: number;
    type: string;
    intervalWindowInSeconds?: number;
}
export declare const GetInterpolatedAssetPropertyValuesRequest: S.Schema<GetInterpolatedAssetPropertyValuesRequest>;
export interface InterpolatedAssetPropertyValue {
    timestamp: TimeInNanos;
    value: Variant;
}
export declare const InterpolatedAssetPropertyValue: S.Schema<InterpolatedAssetPropertyValue>;
export type InterpolatedAssetPropertyValues = InterpolatedAssetPropertyValue[];
export declare const InterpolatedAssetPropertyValues: any;
export interface GetInterpolatedAssetPropertyValuesResponse {
    interpolatedAssetPropertyValues: InterpolatedAssetPropertyValue[];
    nextToken?: string;
}
export declare const GetInterpolatedAssetPropertyValuesResponse: S.Schema<GetInterpolatedAssetPropertyValuesResponse>;
export type QueryMaxResults = number;
export type QueryNextToken = string;
export interface GetQueryResultsRequest {
    workspaceName: string;
    queryId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const GetQueryResultsRequest: S.Schema<GetQueryResultsRequest>;
export type ColumnLabel = string;
export type ColumnDataType = string;
export interface ColumnInformation {
    name: string;
    type: string;
}
export declare const ColumnInformation: S.Schema<ColumnInformation>;
export type ColumnInformationList = ColumnInformation[];
export declare const ColumnInformationList: any;
export type ColumnValue = string;
export type Result = string[];
export declare const Result: any;
export type RowList = string[][];
export declare const RowList: any;
export interface GetQueryResultsResponse {
    columnInfo?: ColumnInformation[];
    rows?: string[][];
    nextToken?: string;
}
export declare const GetQueryResultsResponse: S.Schema<GetQueryResultsResponse>;
export type GetSearchResultsRequestMaxResultsInteger = number;
export interface GetSearchResultsRequest {
    searchId: string;
    workspaceName: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const GetSearchResultsRequest: S.Schema<GetSearchResultsRequest>;
export interface SearchResult {
    searchId: string;
    workspaceName: string;
    datasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
    topTimestamp: TimeInNanos;
    score: number;
}
export declare const SearchResult: S.Schema<SearchResult>;
export type SearchResultList = SearchResult[];
export declare const SearchResultList: any;
export interface GetSearchResultsResponse {
    searchResults: SearchResult[];
    nextToken?: string;
}
export declare const GetSearchResultsResponse: S.Schema<GetSearchResultsResponse>;
export type ConversationId = string;
export type MessageInput = string | redacted.Redacted<string>;
export interface InvokeAssistantRequest {
    conversationId?: string;
    message: string | redacted.Redacted<string>;
    enableTrace?: boolean;
}
export declare const InvokeAssistantRequest: S.Schema<InvokeAssistantRequest>;
export interface Trace {
    text?: string;
}
export declare const Trace: S.Schema<Trace>;
export interface Location {
    uri?: string;
}
export declare const Location: S.Schema<Location>;
export interface Source {
    arn?: string;
    location?: Location;
}
export declare const Source: S.Schema<Source>;
export interface DataSetReference {
    datasetArn?: string;
    source?: Source;
}
export declare const DataSetReference: S.Schema<DataSetReference>;
export interface Reference {
    dataset?: DataSetReference;
}
export declare const Reference: S.Schema<Reference>;
export interface Content {
    text?: string;
}
export declare const Content: S.Schema<Content>;
export interface Citation {
    reference?: Reference;
    content?: Content;
}
export declare const Citation: S.Schema<Citation>;
export type Citations = Citation[];
export declare const Citations: any;
export interface InvocationOutput {
    message?: string;
    citations?: Citation[];
}
export declare const InvocationOutput: S.Schema<InvocationOutput>;
export type ResourceId = string;
export type ResourceArn = string;
export type ResponseStream = {
    trace: Trace;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output: InvocationOutput;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException: AccessDeniedException;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException: ConflictingOperationException;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException: InternalFailureException;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException: InvalidRequestException;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException: LimitExceededException;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException: ResourceNotFoundException;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException: ThrottlingException;
};
export declare const ResponseStream: S.Schema<stream.Stream<ResponseStream, Error, never>>;
export interface InvokeAssistantResponse {
    body: stream.Stream<ResponseStream, Error, never>;
    conversationId: string;
}
export declare const InvokeAssistantResponse: S.Schema<InvokeAssistantResponse>;
export type IdentityType = "USER" | "GROUP" | "IAM" | (string & {});
export declare const IdentityType: any;
export type ResourceType = "PORTAL" | "PROJECT" | (string & {});
export declare const ResourceType: any;
export type MaxResults = number;
export interface ListAccessPoliciesRequest {
    identityType?: IdentityType;
    identityId?: string;
    resourceType?: ResourceType;
    resourceId?: string;
    iamArn?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAccessPoliciesRequest: S.Schema<ListAccessPoliciesRequest>;
export interface AccessPolicySummary {
    id: string;
    identity: Identity;
    resource: Resource;
    permission: Permission;
    creationDate?: Date;
    lastUpdateDate?: Date;
}
export declare const AccessPolicySummary: S.Schema<AccessPolicySummary>;
export type AccessPolicySummaries = AccessPolicySummary[];
export declare const AccessPolicySummaries: any;
export interface ListAccessPoliciesResponse {
    accessPolicySummaries: AccessPolicySummary[];
    nextToken?: string;
}
export declare const ListAccessPoliciesResponse: S.Schema<ListAccessPoliciesResponse>;
export type TargetResourceType = "ASSET" | "COMPUTATION_MODEL" | (string & {});
export declare const TargetResourceType: any;
export interface ListActionsRequest {
    targetResourceType: TargetResourceType;
    targetResourceId: string;
    nextToken?: string;
    maxResults?: number;
    resolveToResourceType?: ResolveToResourceType;
    resolveToResourceId?: string;
}
export declare const ListActionsRequest: S.Schema<ListActionsRequest>;
export interface ActionSummary {
    actionId?: string;
    actionDefinitionId?: string;
    targetResource?: TargetResource;
    resolveTo?: ResolveTo;
}
export declare const ActionSummary: S.Schema<ActionSummary>;
export type ActionSummaries = ActionSummary[];
export declare const ActionSummaries: any;
export interface ListActionsResponse {
    actionSummaries: ActionSummary[];
    nextToken: string;
}
export declare const ListActionsResponse: S.Schema<ListActionsResponse>;
export interface ListApplicationsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListApplicationsRequest: S.Schema<ListApplicationsRequest>;
export interface ApplicationSummary {
    arn: string;
    id: string;
    name: string;
    status: ApplicationStatus;
    createdAt: Date;
    workspaceName: string;
}
export declare const ApplicationSummary: S.Schema<ApplicationSummary>;
export type ApplicationList = ApplicationSummary[];
export declare const ApplicationList: any;
export interface ListApplicationsResponse {
    nextToken?: string;
    applications: ApplicationSummary[];
}
export declare const ListApplicationsResponse: S.Schema<ListApplicationsResponse>;
export interface ListAssetModelCompositeModelsRequest {
    assetModelId: string;
    nextToken?: string;
    maxResults?: number;
    assetModelVersion?: string;
}
export declare const ListAssetModelCompositeModelsRequest: S.Schema<ListAssetModelCompositeModelsRequest>;
export interface ListAssetModelCompositeModelsResponse {
    assetModelCompositeModelSummaries: AssetModelCompositeModelSummary[];
    nextToken?: string;
}
export declare const ListAssetModelCompositeModelsResponse: S.Schema<ListAssetModelCompositeModelsResponse>;
export type ListAssetModelPropertiesFilter = "ALL" | "BASE" | (string & {});
export declare const ListAssetModelPropertiesFilter: any;
export interface ListAssetModelPropertiesRequest {
    assetModelId: string;
    nextToken?: string;
    maxResults?: number;
    filter?: ListAssetModelPropertiesFilter;
    assetModelVersion?: string;
}
export declare const ListAssetModelPropertiesRequest: S.Schema<ListAssetModelPropertiesRequest>;
export interface InterfaceSummary {
    interfaceAssetModelId: string;
    interfaceAssetModelPropertyId: string;
}
export declare const InterfaceSummary: S.Schema<InterfaceSummary>;
export type InterfaceSummaries = InterfaceSummary[];
export declare const InterfaceSummaries: any;
export interface AssetModelPropertySummary {
    id?: string;
    externalId?: string;
    name: string;
    dataType: PropertyDataType;
    dataTypeSpec?: string;
    unit?: string;
    type: PropertyType;
    assetModelCompositeModelId?: string;
    path?: AssetModelPropertyPathSegment[];
    interfaceSummaries?: InterfaceSummary[];
}
export declare const AssetModelPropertySummary: S.Schema<AssetModelPropertySummary>;
export type AssetModelPropertySummaries = AssetModelPropertySummary[];
export declare const AssetModelPropertySummaries: any;
export interface ListAssetModelPropertiesResponse {
    assetModelPropertySummaries: AssetModelPropertySummary[];
    nextToken?: string;
}
export declare const ListAssetModelPropertiesResponse: S.Schema<ListAssetModelPropertiesResponse>;
export type ListAssetModelsTypeFilter = AssetModelType[];
export declare const ListAssetModelsTypeFilter: any;
export interface ListAssetModelsRequest {
    assetModelTypes?: AssetModelType[];
    nextToken?: string;
    maxResults?: number;
    assetModelVersion?: string;
}
export declare const ListAssetModelsRequest: S.Schema<ListAssetModelsRequest>;
export interface AssetModelSummary {
    id: string;
    externalId?: string;
    arn: string;
    name: string;
    assetModelType?: AssetModelType;
    description?: string;
    creationDate: Date;
    lastUpdateDate: Date;
    status: AssetModelStatus;
    version?: string;
}
export declare const AssetModelSummary: S.Schema<AssetModelSummary>;
export type AssetModelSummaries = AssetModelSummary[];
export declare const AssetModelSummaries: any;
export interface ListAssetModelsResponse {
    assetModelSummaries: AssetModelSummary[];
    nextToken?: string;
}
export declare const ListAssetModelsResponse: S.Schema<ListAssetModelsResponse>;
export type ListAssetPropertiesFilter = "ALL" | "BASE" | (string & {});
export declare const ListAssetPropertiesFilter: any;
export interface ListAssetPropertiesRequest {
    assetId: string;
    nextToken?: string;
    maxResults?: number;
    filter?: ListAssetPropertiesFilter;
}
export declare const ListAssetPropertiesRequest: S.Schema<ListAssetPropertiesRequest>;
export interface AssetPropertySummary {
    id: string;
    externalId?: string;
    alias?: string;
    unit?: string;
    notification?: PropertyNotification;
    assetCompositeModelId?: string;
    path?: AssetPropertyPathSegment[];
}
export declare const AssetPropertySummary: S.Schema<AssetPropertySummary>;
export type AssetPropertySummaries = AssetPropertySummary[];
export declare const AssetPropertySummaries: any;
export interface ListAssetPropertiesResponse {
    assetPropertySummaries: AssetPropertySummary[];
    nextToken?: string;
}
export declare const ListAssetPropertiesResponse: S.Schema<ListAssetPropertiesResponse>;
export type TraversalType = "PATH_TO_ROOT" | (string & {});
export declare const TraversalType: any;
export interface ListAssetRelationshipsRequest {
    assetId: string;
    traversalType: TraversalType;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAssetRelationshipsRequest: S.Schema<ListAssetRelationshipsRequest>;
export interface AssetHierarchyInfo {
    parentAssetId?: string;
    childAssetId?: string;
}
export declare const AssetHierarchyInfo: S.Schema<AssetHierarchyInfo>;
export type AssetRelationshipType = "HIERARCHY" | (string & {});
export declare const AssetRelationshipType: any;
export interface AssetRelationshipSummary {
    hierarchyInfo?: AssetHierarchyInfo;
    relationshipType: AssetRelationshipType;
}
export declare const AssetRelationshipSummary: S.Schema<AssetRelationshipSummary>;
export type AssetRelationshipSummaries = AssetRelationshipSummary[];
export declare const AssetRelationshipSummaries: any;
export interface ListAssetRelationshipsResponse {
    assetRelationshipSummaries: AssetRelationshipSummary[];
    nextToken?: string;
}
export declare const ListAssetRelationshipsResponse: S.Schema<ListAssetRelationshipsResponse>;
export type ListAssetsFilter = "ALL" | "TOP_LEVEL" | (string & {});
export declare const ListAssetsFilter: any;
export interface ListAssetsRequest {
    nextToken?: string;
    maxResults?: number;
    assetModelId?: string;
    filter?: ListAssetsFilter;
}
export declare const ListAssetsRequest: S.Schema<ListAssetsRequest>;
export interface AssetSummary {
    id: string;
    externalId?: string;
    arn: string;
    name: string;
    assetModelId: string;
    creationDate: Date;
    lastUpdateDate: Date;
    status: AssetStatus;
    hierarchies: AssetHierarchy[];
    description?: string;
}
export declare const AssetSummary: S.Schema<AssetSummary>;
export type AssetSummaries = AssetSummary[];
export declare const AssetSummaries: any;
export interface ListAssetsResponse {
    assetSummaries: AssetSummary[];
    nextToken?: string;
}
export declare const ListAssetsResponse: S.Schema<ListAssetsResponse>;
export type TraversalDirection = "PARENT" | "CHILD" | (string & {});
export declare const TraversalDirection: any;
export interface ListAssociatedAssetsRequest {
    assetId: string;
    hierarchyId?: string;
    traversalDirection?: TraversalDirection;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAssociatedAssetsRequest: S.Schema<ListAssociatedAssetsRequest>;
export interface AssociatedAssetsSummary {
    id: string;
    externalId?: string;
    arn: string;
    name: string;
    assetModelId: string;
    creationDate: Date;
    lastUpdateDate: Date;
    status: AssetStatus;
    hierarchies: AssetHierarchy[];
    description?: string;
}
export declare const AssociatedAssetsSummary: S.Schema<AssociatedAssetsSummary>;
export type AssociatedAssetsSummaries = AssociatedAssetsSummary[];
export declare const AssociatedAssetsSummaries: any;
export interface ListAssociatedAssetsResponse {
    assetSummaries: AssociatedAssetsSummary[];
    nextToken?: string;
}
export declare const ListAssociatedAssetsResponse: S.Schema<ListAssociatedAssetsResponse>;
export type ListBulkImportJobsFilter = "ALL" | "PENDING" | "RUNNING" | "CANCELLED" | "FAILED" | "COMPLETED_WITH_FAILURES" | "COMPLETED" | (string & {});
export declare const ListBulkImportJobsFilter: any;
export interface ListBulkImportJobsRequest {
    nextToken?: string;
    maxResults?: number;
    filter?: ListBulkImportJobsFilter;
    workspaceName?: string;
}
export declare const ListBulkImportJobsRequest: S.Schema<ListBulkImportJobsRequest>;
export interface JobSummary {
    id: string;
    name: string;
    status: JobStatus;
}
export declare const JobSummary: S.Schema<JobSummary>;
export type JobSummaries = JobSummary[];
export declare const JobSummaries: any;
export interface ListBulkImportJobsResponse {
    jobSummaries: JobSummary[];
    nextToken?: string;
}
export declare const ListBulkImportJobsResponse: S.Schema<ListBulkImportJobsResponse>;
export interface ListCompositionRelationshipsRequest {
    assetModelId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListCompositionRelationshipsRequest: S.Schema<ListCompositionRelationshipsRequest>;
export interface CompositionRelationshipSummary {
    assetModelId: string;
    assetModelCompositeModelId: string;
    assetModelCompositeModelType: string;
}
export declare const CompositionRelationshipSummary: S.Schema<CompositionRelationshipSummary>;
export type CompositionRelationshipSummaries = CompositionRelationshipSummary[];
export declare const CompositionRelationshipSummaries: any;
export interface ListCompositionRelationshipsResponse {
    compositionRelationshipSummaries: CompositionRelationshipSummary[];
    nextToken?: string;
}
export declare const ListCompositionRelationshipsResponse: S.Schema<ListCompositionRelationshipsResponse>;
export interface AssetBindingValueFilter {
    assetId: string;
}
export declare const AssetBindingValueFilter: S.Schema<AssetBindingValueFilter>;
export interface AssetModelBindingValueFilter {
    assetModelId: string;
}
export declare const AssetModelBindingValueFilter: S.Schema<AssetModelBindingValueFilter>;
export interface AssetPropertyBindingValueFilter {
    assetId: string;
    propertyId: string;
}
export declare const AssetPropertyBindingValueFilter: S.Schema<AssetPropertyBindingValueFilter>;
export interface AssetModelPropertyBindingValueFilter {
    assetModelId: string;
    propertyId: string;
}
export declare const AssetModelPropertyBindingValueFilter: S.Schema<AssetModelPropertyBindingValueFilter>;
export interface DataBindingValueFilter {
    asset?: AssetBindingValueFilter;
    assetModel?: AssetModelBindingValueFilter;
    assetProperty?: AssetPropertyBindingValueFilter;
    assetModelProperty?: AssetModelPropertyBindingValueFilter;
}
export declare const DataBindingValueFilter: S.Schema<DataBindingValueFilter>;
export interface ListComputationModelDataBindingUsagesRequest {
    dataBindingValueFilter: DataBindingValueFilter;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListComputationModelDataBindingUsagesRequest: S.Schema<ListComputationModelDataBindingUsagesRequest>;
export type ComputationModelIdList = string[];
export declare const ComputationModelIdList: any;
export interface DataBindingValue {
    assetModelProperty?: AssetModelPropertyBindingValue;
    assetProperty?: AssetPropertyBindingValue;
}
export declare const DataBindingValue: S.Schema<DataBindingValue>;
export interface MatchedDataBinding {
    value: DataBindingValue;
}
export declare const MatchedDataBinding: S.Schema<MatchedDataBinding>;
export interface ComputationModelDataBindingUsageSummary {
    computationModelIds: string[];
    matchedDataBinding: MatchedDataBinding;
}
export declare const ComputationModelDataBindingUsageSummary: S.Schema<ComputationModelDataBindingUsageSummary>;
export type ComputationModelDataBindingUsageSummaries = ComputationModelDataBindingUsageSummary[];
export declare const ComputationModelDataBindingUsageSummaries: any;
export interface ListComputationModelDataBindingUsagesResponse {
    dataBindingUsageSummaries: ComputationModelDataBindingUsageSummary[];
    nextToken?: string;
}
export declare const ListComputationModelDataBindingUsagesResponse: S.Schema<ListComputationModelDataBindingUsagesResponse>;
export interface ListComputationModelResolveToResourcesRequest {
    computationModelId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListComputationModelResolveToResourcesRequest: S.Schema<ListComputationModelResolveToResourcesRequest>;
export interface ComputationModelResolveToResourceSummary {
    resolveTo?: ResolveTo;
}
export declare const ComputationModelResolveToResourceSummary: S.Schema<ComputationModelResolveToResourceSummary>;
export type ComputationModelResolveToResourceSummaries = ComputationModelResolveToResourceSummary[];
export declare const ComputationModelResolveToResourceSummaries: any;
export interface ListComputationModelResolveToResourcesResponse {
    computationModelResolveToResourceSummaries: ComputationModelResolveToResourceSummary[];
    nextToken?: string;
}
export declare const ListComputationModelResolveToResourcesResponse: S.Schema<ListComputationModelResolveToResourcesResponse>;
export type ComputationModelType = "ANOMALY_DETECTION" | (string & {});
export declare const ComputationModelType: any;
export interface ListComputationModelsRequest {
    computationModelType?: ComputationModelType;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListComputationModelsRequest: S.Schema<ListComputationModelsRequest>;
export interface ComputationModelSummary {
    id: string;
    arn: string;
    name: string;
    description?: string;
    type: ComputationModelType;
    creationDate: Date;
    lastUpdateDate: Date;
    status: ComputationModelStatus;
    version: string;
}
export declare const ComputationModelSummary: S.Schema<ComputationModelSummary>;
export type ComputationModelSummaries = ComputationModelSummary[];
export declare const ComputationModelSummaries: any;
export interface ListComputationModelsResponse {
    computationModelSummaries: ComputationModelSummary[];
    nextToken?: string;
}
export declare const ListComputationModelsResponse: S.Schema<ListComputationModelsResponse>;
export interface ListDashboardsRequest {
    projectId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDashboardsRequest: S.Schema<ListDashboardsRequest>;
export interface DashboardSummary {
    id: string;
    name: string;
    description?: string;
    creationDate?: Date;
    lastUpdateDate?: Date;
}
export declare const DashboardSummary: S.Schema<DashboardSummary>;
export type DashboardSummaries = DashboardSummary[];
export declare const DashboardSummaries: any;
export interface ListDashboardsResponse {
    dashboardSummaries: DashboardSummary[];
    nextToken?: string;
}
export declare const ListDashboardsResponse: S.Schema<ListDashboardsResponse>;
export interface ListDatasetDataSegmentRelationshipsRequest {
    datasetId: string;
    workspaceName: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDatasetDataSegmentRelationshipsRequest: S.Schema<ListDatasetDataSegmentRelationshipsRequest>;
export interface DataSegmentRelationshipSummary {
    targetDatasetId: string;
    sourceDatasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
}
export declare const DataSegmentRelationshipSummary: S.Schema<DataSegmentRelationshipSummary>;
export type DataSegmentRelationshipSummaries = DataSegmentRelationshipSummary[];
export declare const DataSegmentRelationshipSummaries: any;
export interface ListDatasetDataSegmentRelationshipsResponse {
    dataSegmentRelationshipSummaries: DataSegmentRelationshipSummary[];
    nextToken?: string;
}
export declare const ListDatasetDataSegmentRelationshipsResponse: S.Schema<ListDatasetDataSegmentRelationshipsResponse>;
export interface ListDatasetDataSegmentsRequest {
    datasetId: string;
    workspaceName: string;
    datasetVersion?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDatasetDataSegmentsRequest: S.Schema<ListDatasetDataSegmentsRequest>;
export type EnrichmentStatus = "ENRICHED" | "NOT_ENRICHED" | (string & {});
export declare const EnrichmentStatus: any;
export interface DataSegmentEnrichment {
    status: EnrichmentStatus;
    lastEnrichedAt?: Date;
}
export declare const DataSegmentEnrichment: S.Schema<DataSegmentEnrichment>;
export interface DataSegmentSummary {
    sourceDatasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
    alias: string;
    dataType: PropertyDataType;
    enrichment?: DataSegmentEnrichment;
}
export declare const DataSegmentSummary: S.Schema<DataSegmentSummary>;
export type DataSegmentSummaries = DataSegmentSummary[];
export declare const DataSegmentSummaries: any;
export interface ListDatasetDataSegmentsResponse {
    dataSegments: DataSegmentSummary[];
    nextToken?: string;
}
export declare const ListDatasetDataSegmentsResponse: S.Schema<ListDatasetDataSegmentsResponse>;
export type DatasetExportJobFilter = "ALL" | "SUBMITTED" | "RUNNING" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "FAILED" | (string & {});
export declare const DatasetExportJobFilter: any;
export type ListExportJobsMaxResults = number;
export type ListExportJobsNextToken = string;
export interface ListDatasetExportJobsRequest {
    workspaceName: string;
    filter?: DatasetExportJobFilter;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDatasetExportJobsRequest: S.Schema<ListDatasetExportJobsRequest>;
export interface ExportJobSummary {
    jobId: string;
    status: DatasetExportJobStatus;
    startedAt: Date;
    completedAt?: Date;
    destinationS3Uri: string;
}
export declare const ExportJobSummary: S.Schema<ExportJobSummary>;
export type ExportJobSummaryList = ExportJobSummary[];
export declare const ExportJobSummaryList: any;
export interface ListDatasetExportJobsResponse {
    jobs: ExportJobSummary[];
    nextToken?: string;
}
export declare const ListDatasetExportJobsResponse: S.Schema<ListDatasetExportJobsResponse>;
export interface ListDatasetsRequest {
    sourceType: DatasetSourceType;
    workspaceName?: string;
    datasetType?: DatasetTypeEnum;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDatasetsRequest: S.Schema<ListDatasetsRequest>;
export interface DatasetSummary {
    id: string;
    arn: string;
    name: string;
    description: string;
    sourceType?: DatasetSourceType;
    datasetType?: DatasetTypeEnum;
    creationDate: Date;
    lastUpdateDate: Date;
    status: DatasetStatus;
    enrichmentStatus?: DatasetEnrichment;
}
export declare const DatasetSummary: S.Schema<DatasetSummary>;
export type DatasetSummaries = DatasetSummary[];
export declare const DatasetSummaries: any;
export interface ListDatasetsResponse {
    datasetSummaries: DatasetSummary[];
    nextToken?: string;
    workspaceName?: string;
}
export declare const ListDatasetsResponse: S.Schema<ListDatasetsResponse>;
export interface ListEnrichmentJobsRequest {
    workspaceName: string;
    datasetId?: string;
    propertyAlias?: string;
    timeSeriesId?: string;
    status?: EnrichmentJobStatus;
    jobType?: JobType;
    startDate?: Date;
    endDate?: Date;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListEnrichmentJobsRequest: S.Schema<ListEnrichmentJobsRequest>;
export interface EnrichmentJobSummary {
    jobId: string;
    status: EnrichmentJobStatus;
    workspaceName: string;
    jobType: JobType;
    datasetId: string;
    propertyAlias?: string;
    timeSeriesId?: string;
    createdAt: Date;
    updatedAt?: Date;
}
export declare const EnrichmentJobSummary: S.Schema<EnrichmentJobSummary>;
export type EnrichmentJobSummaries = EnrichmentJobSummary[];
export declare const EnrichmentJobSummaries: any;
export interface ListEnrichmentJobsResponse {
    jobs: EnrichmentJobSummary[];
    nextToken?: string;
}
export declare const ListEnrichmentJobsResponse: S.Schema<ListEnrichmentJobsResponse>;
export interface ListExecutionsRequest {
    targetResourceType: TargetResourceType;
    targetResourceId: string;
    resolveToResourceType?: ResolveToResourceType;
    resolveToResourceId?: string;
    nextToken?: string;
    maxResults?: number;
    actionType?: string;
}
export declare const ListExecutionsRequest: S.Schema<ListExecutionsRequest>;
export interface ExecutionSummary {
    executionId: string;
    actionType?: string;
    targetResource: TargetResource;
    targetResourceVersion: string;
    resolveTo?: ResolveTo;
    executionStartTime: Date;
    executionEndTime?: Date;
    executionStatus: ExecutionStatus;
    executionEntityVersion?: string;
}
export declare const ExecutionSummary: S.Schema<ExecutionSummary>;
export type ExecutionSummaries = ExecutionSummary[];
export declare const ExecutionSummaries: any;
export interface ListExecutionsResponse {
    executionSummaries: ExecutionSummary[];
    nextToken?: string;
}
export declare const ListExecutionsResponse: S.Schema<ListExecutionsResponse>;
export interface ListGatewaysRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListGatewaysRequest: S.Schema<ListGatewaysRequest>;
export interface GatewaySummary {
    gatewayId: string;
    gatewayName: string;
    gatewayPlatform?: GatewayPlatform;
    gatewayVersion?: string;
    gatewayCapabilitySummaries?: GatewayCapabilitySummary[];
    creationDate: Date;
    lastUpdateDate: Date;
}
export declare const GatewaySummary: S.Schema<GatewaySummary>;
export type GatewaySummaries = GatewaySummary[];
export declare const GatewaySummaries: any;
export interface ListGatewaysResponse {
    gatewaySummaries: GatewaySummary[];
    nextToken?: string;
}
export declare const ListGatewaysResponse: S.Schema<ListGatewaysResponse>;
export interface ListInterfaceRelationshipsRequest {
    interfaceAssetModelId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListInterfaceRelationshipsRequest: S.Schema<ListInterfaceRelationshipsRequest>;
export interface InterfaceRelationshipSummary {
    id: string;
}
export declare const InterfaceRelationshipSummary: S.Schema<InterfaceRelationshipSummary>;
export type InterfaceRelationshipSummaries = InterfaceRelationshipSummary[];
export declare const InterfaceRelationshipSummaries: any;
export interface ListInterfaceRelationshipsResponse {
    interfaceRelationshipSummaries: InterfaceRelationshipSummary[];
    nextToken?: string;
}
export declare const ListInterfaceRelationshipsResponse: S.Schema<ListInterfaceRelationshipsResponse>;
export type ListPipelineExecutionsRequestMaxResultsInteger = number;
export interface ListPipelineExecutionsRequest {
    workspaceName: string;
    pipelineName: string;
    nextToken?: string;
    maxResults?: number;
    state?: PipelineExecutionState;
    startTimeAfter?: Date;
    startTimeBefore?: Date;
    endTimeAfter?: Date;
    endTimeBefore?: Date;
}
export declare const ListPipelineExecutionsRequest: S.Schema<ListPipelineExecutionsRequest>;
export interface PipelineExecutionSummary {
    pipelineExecutionId: string;
    pipelineVersion: string;
    status: PipelineExecutionStatus;
    executionPriority?: number;
    startTime?: Date;
    endTime?: Date;
}
export declare const PipelineExecutionSummary: S.Schema<PipelineExecutionSummary>;
export type PipelineExecutionSummaryList = PipelineExecutionSummary[];
export declare const PipelineExecutionSummaryList: any;
export interface ListPipelineExecutionsResponse {
    pipelineExecutionSummaries: PipelineExecutionSummary[];
    nextToken?: string;
}
export declare const ListPipelineExecutionsResponse: S.Schema<ListPipelineExecutionsResponse>;
export type ListPipelinesRequestMaxResultsInteger = number;
export interface ListPipelinesRequest {
    workspaceName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPipelinesRequest: S.Schema<ListPipelinesRequest>;
export interface PipelineSummary {
    pipelineName: string;
    description?: string;
    pipelineArn: string;
    version: string;
    status: ResourceStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const PipelineSummary: S.Schema<PipelineSummary>;
export type PipelineSummaries = PipelineSummary[];
export declare const PipelineSummaries: any;
export interface ListPipelinesResponse {
    pipelineSummaries: PipelineSummary[];
    nextToken?: string;
}
export declare const ListPipelinesResponse: S.Schema<ListPipelinesResponse>;
export interface ListPortalsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPortalsRequest: S.Schema<ListPortalsRequest>;
export interface PortalSummary {
    id: string;
    name: string;
    description?: string;
    startUrl: string;
    creationDate?: Date;
    lastUpdateDate?: Date;
    roleArn?: string;
    status: PortalStatus;
    portalType?: PortalType;
}
export declare const PortalSummary: S.Schema<PortalSummary>;
export type PortalSummaries = PortalSummary[];
export declare const PortalSummaries: any;
export interface ListPortalsResponse {
    portalSummaries?: PortalSummary[];
    nextToken?: string;
}
export declare const ListPortalsResponse: S.Schema<ListPortalsResponse>;
export interface ListProjectAssetsRequest {
    projectId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListProjectAssetsRequest: S.Schema<ListProjectAssetsRequest>;
export type AssetIDs = string[];
export declare const AssetIDs: any;
export interface ListProjectAssetsResponse {
    assetIds: string[];
    nextToken?: string;
}
export declare const ListProjectAssetsResponse: S.Schema<ListProjectAssetsResponse>;
export interface ListProjectsRequest {
    portalId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListProjectsRequest: S.Schema<ListProjectsRequest>;
export interface ProjectSummary {
    id: string;
    name: string;
    description?: string;
    creationDate?: Date;
    lastUpdateDate?: Date;
}
export declare const ProjectSummary: S.Schema<ProjectSummary>;
export type ProjectSummaries = ProjectSummary[];
export declare const ProjectSummaries: any;
export interface ListProjectsResponse {
    projectSummaries: ProjectSummary[];
    nextToken?: string;
}
export declare const ListProjectsResponse: S.Schema<ListProjectsResponse>;
export type QueryFilter = string;
export type QueryListNextToken = string;
export interface ListQueriesRequest {
    workspaceName: string;
    filter?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListQueriesRequest: S.Schema<ListQueriesRequest>;
export interface QuerySummary {
    queryId: string;
    status: QueryStatus;
    submittedAt: Date;
    completedAt?: Date;
}
export declare const QuerySummary: S.Schema<QuerySummary>;
export type QuerySummaryList = QuerySummary[];
export declare const QuerySummaryList: any;
export interface ListQueriesResponse {
    queries: QuerySummary[];
    nextToken?: string;
}
export declare const ListQueriesResponse: S.Schema<ListQueriesResponse>;
export type ListSearchesRequestMaxResultsInteger = number;
export type SearchStatusFilterList = SearchStatus[];
export declare const SearchStatusFilterList: any;
export type GroupIdFilterList = string[];
export declare const GroupIdFilterList: any;
export type SearchTypeFilterList = SearchType[];
export declare const SearchTypeFilterList: any;
export interface ListSearchesFilters {
    statusFilter?: SearchStatus[];
    startedAfter?: Date;
    startedBefore?: Date;
    groupIdFilter?: string[];
    searchTypeFilter?: SearchType[];
}
export declare const ListSearchesFilters: S.Schema<ListSearchesFilters>;
export interface ListSearchesRequest {
    workspaceName: string;
    maxResults?: number;
    nextToken?: string;
    listSearchesFilters?: ListSearchesFilters;
}
export declare const ListSearchesRequest: S.Schema<ListSearchesRequest>;
export interface SearchSummary {
    searchId: string;
    workspaceName: string;
    status: SearchStatus;
    queryStatement: string | redacted.Redacted<string>;
    searchType: SearchType;
    statusReason?: string;
    startedAt?: Date;
    groupId?: string;
}
export declare const SearchSummary: S.Schema<SearchSummary>;
export type SearchSummaries = SearchSummary[];
export declare const SearchSummaries: any;
export interface ListSearchesResponse {
    searchSummaries: SearchSummary[];
    nextToken?: string;
}
export declare const ListSearchesResponse: S.Schema<ListSearchesResponse>;
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type ListTasksRequestMaxResultsInteger = number;
export interface ListTasksRequest {
    workspaceName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListTasksRequest: S.Schema<ListTasksRequest>;
export interface TaskSummary {
    taskName: string;
    description?: string;
    taskArn: string;
    version: string;
    status: ResourceStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const TaskSummary: S.Schema<TaskSummary>;
export type TaskSummaries = TaskSummary[];
export declare const TaskSummaries: any;
export interface ListTasksResponse {
    taskSummaries: TaskSummary[];
    nextToken?: string;
}
export declare const ListTasksResponse: S.Schema<ListTasksResponse>;
export type ListTimeSeriesType = "ASSOCIATED" | "DISASSOCIATED" | (string & {});
export declare const ListTimeSeriesType: any;
export interface ListTimeSeriesRequest {
    nextToken?: string;
    maxResults?: number;
    assetId?: string;
    aliasPrefix?: string;
    timeSeriesType?: ListTimeSeriesType;
    workspaceName?: string;
}
export declare const ListTimeSeriesRequest: S.Schema<ListTimeSeriesRequest>;
export interface TimeSeriesSummary {
    assetId?: string;
    propertyId?: string;
    alias?: string;
    timeSeriesId: string;
    dataType: PropertyDataType;
    dataTypeSpec?: string;
    timeSeriesCreationDate: Date;
    timeSeriesLastUpdateDate: Date;
    timeSeriesArn: string;
}
export declare const TimeSeriesSummary: S.Schema<TimeSeriesSummary>;
export type TimeSeriesSummaries = TimeSeriesSummary[];
export declare const TimeSeriesSummaries: any;
export interface ListTimeSeriesResponse {
    TimeSeriesSummaries: TimeSeriesSummary[];
    nextToken?: string;
    workspaceName?: string;
}
export declare const ListTimeSeriesResponse: S.Schema<ListTimeSeriesResponse>;
export interface ListWorkspacesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListWorkspacesRequest: S.Schema<ListWorkspacesRequest>;
export interface WorkspaceSummary {
    name: string;
    arn: string;
    status: WorkspaceStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const WorkspaceSummary: S.Schema<WorkspaceSummary>;
export type WorkspaceSummaries = WorkspaceSummary[];
export declare const WorkspaceSummaries: any;
export interface ListWorkspacesResponse {
    workspaceSummaries: WorkspaceSummary[];
    nextToken?: string;
}
export declare const ListWorkspacesResponse: S.Schema<ListWorkspacesResponse>;
export type MatchByPropertyName = boolean;
export type CreateMissingProperty = boolean;
export interface PropertyMappingConfiguration {
    matchByPropertyName?: boolean;
    createMissingProperty?: boolean;
    overrides?: PropertyMapping[];
}
export declare const PropertyMappingConfiguration: S.Schema<PropertyMappingConfiguration>;
export interface PutAssetModelInterfaceRelationshipRequest {
    assetModelId: string;
    interfaceAssetModelId: string;
    propertyMappingConfiguration: PropertyMappingConfiguration;
    clientToken?: string;
}
export declare const PutAssetModelInterfaceRelationshipRequest: S.Schema<PutAssetModelInterfaceRelationshipRequest>;
export interface PutAssetModelInterfaceRelationshipResponse {
    assetModelId: string;
    interfaceAssetModelId: string;
    assetModelArn: string;
    assetModelStatus: AssetModelStatus;
}
export declare const PutAssetModelInterfaceRelationshipResponse: S.Schema<PutAssetModelInterfaceRelationshipResponse>;
export interface PutDefaultEncryptionConfigurationRequest {
    encryptionType: EncryptionType;
    kmsKeyId?: string;
}
export declare const PutDefaultEncryptionConfigurationRequest: S.Schema<PutDefaultEncryptionConfigurationRequest>;
export interface PutDefaultEncryptionConfigurationResponse {
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
    configurationStatus: ConfigurationStatus;
}
export declare const PutDefaultEncryptionConfigurationResponse: S.Schema<PutDefaultEncryptionConfigurationResponse>;
export interface PutLoggingOptionsRequest {
    loggingOptions: LoggingOptions;
    workspaceName?: string;
}
export declare const PutLoggingOptionsRequest: S.Schema<PutLoggingOptionsRequest>;
export interface PutLoggingOptionsResponse {
}
export declare const PutLoggingOptionsResponse: S.Schema<PutLoggingOptionsResponse>;
export interface PutStorageConfigurationRequest {
    storageType: StorageType;
    multiLayerStorage?: MultiLayerStorage;
    disassociatedDataStorage?: DisassociatedDataStorageState;
    retentionPeriod?: RetentionPeriod;
    warmTier?: WarmTierState;
    warmTierRetentionPeriod?: WarmTierRetentionPeriod;
    disallowIngestNullNaN?: boolean;
}
export declare const PutStorageConfigurationRequest: S.Schema<PutStorageConfigurationRequest>;
export interface PutStorageConfigurationResponse {
    storageType: StorageType;
    multiLayerStorage?: MultiLayerStorage;
    disassociatedDataStorage?: DisassociatedDataStorageState;
    retentionPeriod?: RetentionPeriod;
    configurationStatus: ConfigurationStatus;
    warmTier?: WarmTierState;
    warmTierRetentionPeriod?: WarmTierRetentionPeriod;
    disallowIngestNullNaN?: boolean;
}
export declare const PutStorageConfigurationResponse: S.Schema<PutStorageConfigurationResponse>;
export interface StartPipelineExecutionRequest {
    workspaceName: string;
    pipelineName: string;
    executionEnvironmentVariableOverrides?: ExecutionEnvironmentVariables;
    executionPriority?: number;
    clientToken?: string;
}
export declare const StartPipelineExecutionRequest: S.Schema<StartPipelineExecutionRequest>;
export interface StartPipelineExecutionResponse {
    pipelineExecutionId: string;
}
export declare const StartPipelineExecutionResponse: S.Schema<StartPipelineExecutionResponse>;
export type QueryString = string | redacted.Redacted<string>;
export interface StartQueryRequest {
    clientToken?: string;
    workspaceName: string;
    queryStatement: string | redacted.Redacted<string>;
}
export declare const StartQueryRequest: S.Schema<StartQueryRequest>;
export interface StartQueryResponse {
    queryId: string;
    status: QueryStatus;
}
export declare const StartQueryResponse: S.Schema<StartQueryResponse>;
export type TimeSeriesIdList = string[];
export declare const TimeSeriesIdList: any;
export type DataSetIdList = string[];
export declare const DataSetIdList: any;
export interface TimeInterval {
    startTime: TimeInNanos;
    endTime: TimeInNanos;
}
export declare const TimeInterval: S.Schema<TimeInterval>;
export type TimeIntervalList = TimeInterval[];
export declare const TimeIntervalList: any;
export interface SearchFilters {
    timeSeriesIds?: string[];
    datasetIds?: string[];
    timeIntervals?: TimeInterval[];
}
export declare const SearchFilters: S.Schema<SearchFilters>;
export interface StartSearchRequest {
    workspaceName: string;
    queryStatement: string | redacted.Redacted<string>;
    clientToken?: string;
    searchType?: SearchType;
    searchFilters?: SearchFilters;
    groupId?: string;
}
export declare const StartSearchRequest: S.Schema<StartSearchRequest>;
export interface StartSearchResponse {
    searchId: string;
    workspaceName: string;
    status: SearchStatus;
    groupId?: string;
}
export declare const StartSearchResponse: S.Schema<StartSearchResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAccessPolicyRequest {
    accessPolicyId: string;
    accessPolicyIdentity: Identity;
    accessPolicyResource: Resource;
    accessPolicyPermission: Permission;
    clientToken?: string;
}
export declare const UpdateAccessPolicyRequest: S.Schema<UpdateAccessPolicyRequest>;
export interface UpdateAccessPolicyResponse {
}
export declare const UpdateAccessPolicyResponse: S.Schema<UpdateAccessPolicyResponse>;
export interface UpdateAssetRequest {
    assetId: string;
    assetExternalId?: string;
    assetName: string;
    clientToken?: string;
    assetDescription?: string;
}
export declare const UpdateAssetRequest: S.Schema<UpdateAssetRequest>;
export interface UpdateAssetResponse {
    assetId?: string;
    assetStatus: AssetStatus;
}
export declare const UpdateAssetResponse: S.Schema<UpdateAssetResponse>;
export interface UpdateAssetModelRequest {
    assetModelId: string;
    assetModelExternalId?: string;
    assetModelName: string;
    assetModelDescription?: string;
    assetModelProperties?: AssetModelProperty[];
    assetModelHierarchies?: AssetModelHierarchy[];
    assetModelCompositeModels?: AssetModelCompositeModel[];
    clientToken?: string;
    ifMatch?: string;
    ifNoneMatch?: string;
    matchForVersionType?: AssetModelVersionType;
}
export declare const UpdateAssetModelRequest: S.Schema<UpdateAssetModelRequest>;
export interface UpdateAssetModelResponse {
    assetModelId?: string;
    assetModelStatus: AssetModelStatus;
}
export declare const UpdateAssetModelResponse: S.Schema<UpdateAssetModelResponse>;
export interface UpdateAssetModelCompositeModelRequest {
    assetModelId: string;
    assetModelCompositeModelId: string;
    assetModelCompositeModelExternalId?: string;
    assetModelCompositeModelDescription?: string;
    assetModelCompositeModelName: string;
    clientToken?: string;
    assetModelCompositeModelProperties?: AssetModelProperty[];
    ifMatch?: string;
    ifNoneMatch?: string;
    matchForVersionType?: AssetModelVersionType;
}
export declare const UpdateAssetModelCompositeModelRequest: S.Schema<UpdateAssetModelCompositeModelRequest>;
export interface UpdateAssetModelCompositeModelResponse {
    assetModelCompositeModelPath: AssetModelCompositeModelPathSegment[];
    assetModelStatus: AssetModelStatus;
    assetModelId?: string;
}
export declare const UpdateAssetModelCompositeModelResponse: S.Schema<UpdateAssetModelCompositeModelResponse>;
export interface UpdateAssetPropertyRequest {
    assetId: string;
    propertyId: string;
    propertyAlias?: string;
    propertyNotificationState?: PropertyNotificationState;
    clientToken?: string;
    propertyUnit?: string;
}
export declare const UpdateAssetPropertyRequest: S.Schema<UpdateAssetPropertyRequest>;
export interface UpdateAssetPropertyResponse {
}
export declare const UpdateAssetPropertyResponse: S.Schema<UpdateAssetPropertyResponse>;
export interface UpdateComputationModelRequest {
    computationModelId: string;
    computationModelName: string;
    computationModelDescription?: string;
    computationModelConfiguration: ComputationModelConfiguration;
    computationModelDataBinding: {
        [key: string]: ComputationModelDataBindingValue | undefined;
    };
    clientToken?: string;
}
export declare const UpdateComputationModelRequest: S.Schema<UpdateComputationModelRequest>;
export interface UpdateComputationModelResponse {
    computationModelStatus: ComputationModelStatus;
}
export declare const UpdateComputationModelResponse: S.Schema<UpdateComputationModelResponse>;
export interface UpdateDashboardRequest {
    dashboardId: string;
    dashboardName: string;
    dashboardDescription?: string;
    dashboardDefinition: string;
    clientToken?: string;
}
export declare const UpdateDashboardRequest: S.Schema<UpdateDashboardRequest>;
export interface UpdateDashboardResponse {
}
export declare const UpdateDashboardResponse: S.Schema<UpdateDashboardResponse>;
export interface UpdateDatasetRequest {
    datasetId: string;
    workspaceName?: string;
    datasetName: string;
    datasetDescription?: string;
    datasetConfig?: DatasetConfig;
    metadata?: {
        [key: string]: string | undefined;
    };
    datasetSource: DatasetSource;
    clientToken?: string;
}
export declare const UpdateDatasetRequest: S.Schema<UpdateDatasetRequest>;
export interface UpdateDatasetResponse {
    datasetId?: string;
    datasetArn?: string;
    datasetStatus?: DatasetStatus;
}
export declare const UpdateDatasetResponse: S.Schema<UpdateDatasetResponse>;
export interface UpdateGatewayRequest {
    gatewayId: string;
    gatewayName: string;
}
export declare const UpdateGatewayRequest: S.Schema<UpdateGatewayRequest>;
export interface UpdateGatewayResponse {
}
export declare const UpdateGatewayResponse: S.Schema<UpdateGatewayResponse>;
export interface UpdateGatewayCapabilityConfigurationRequest {
    gatewayId: string;
    capabilityNamespace: string;
    capabilityConfiguration: string;
}
export declare const UpdateGatewayCapabilityConfigurationRequest: S.Schema<UpdateGatewayCapabilityConfigurationRequest>;
export interface UpdateGatewayCapabilityConfigurationResponse {
    capabilityNamespace: string;
    capabilitySyncStatus: CapabilitySyncStatus;
}
export declare const UpdateGatewayCapabilityConfigurationResponse: S.Schema<UpdateGatewayCapabilityConfigurationResponse>;
export interface UpdatePipelineRequest {
    workspaceName: string;
    pipelineName: string;
    description?: string;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    computations?: ComputeNode[];
}
export declare const UpdatePipelineRequest: S.Schema<UpdatePipelineRequest>;
export interface UpdatePipelineResponse {
    version: string;
    status: ResourceStatus;
}
export declare const UpdatePipelineResponse: S.Schema<UpdatePipelineResponse>;
export interface Image {
    id?: string;
    file?: ImageFile;
}
export declare const Image: S.Schema<Image>;
export interface UpdatePortalRequest {
    portalId: string;
    portalName: string;
    portalDescription?: string;
    portalContactEmail: string | redacted.Redacted<string>;
    portalLogoImage?: Image;
    roleArn: string;
    clientToken?: string;
    notificationSenderEmail?: string | redacted.Redacted<string>;
    alarms?: Alarms;
    portalType?: PortalType;
    portalTypeConfiguration?: {
        [key: string]: PortalTypeEntry | undefined;
    };
}
export declare const UpdatePortalRequest: S.Schema<UpdatePortalRequest>;
export interface UpdatePortalResponse {
    portalStatus: PortalStatus;
}
export declare const UpdatePortalResponse: S.Schema<UpdatePortalResponse>;
export interface UpdateProjectRequest {
    projectId: string;
    projectName: string;
    projectDescription?: string;
    clientToken?: string;
}
export declare const UpdateProjectRequest: S.Schema<UpdateProjectRequest>;
export interface UpdateProjectResponse {
}
export declare const UpdateProjectResponse: S.Schema<UpdateProjectResponse>;
export interface UpdateTaskRequest {
    workspaceName: string;
    taskName: string;
    description?: string;
    taskConfiguration?: TaskConfiguration;
}
export declare const UpdateTaskRequest: S.Schema<UpdateTaskRequest>;
export interface UpdateTaskResponse {
    version: string;
    status: ResourceStatus;
}
export declare const UpdateTaskResponse: S.Schema<UpdateTaskResponse>;
export interface UpdateWorkspaceRequest {
    workspaceName: string;
    workspaceDescription?: string;
    encryptionConfiguration?: WorkspaceEncryptionConfiguration;
    clientToken?: string;
}
export declare const UpdateWorkspaceRequest: S.Schema<UpdateWorkspaceRequest>;
export interface UpdateWorkspaceResponse {
    workspaceStatus: WorkspaceStatus;
}
export declare const UpdateWorkspaceResponse: S.Schema<UpdateWorkspaceResponse>;
export type ExceptionMessage = string;
export type AssociateAssetsError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a child asset with the given parent asset through a hierarchy defined in the
 * parent asset's model. For more information, see Associating assets in the
 * *IoT SiteWise User Guide*.
 */
export declare const associateAssets: API.OperationMethod<AssociateAssetsRequest, AssociateAssetsResponse, AssociateAssetsError, Credentials | HttpClient.HttpClient>;
export type AssociateTimeSeriesToAssetPropertyError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a time series (data stream) with an asset property.
 */
export declare const associateTimeSeriesToAssetProperty: API.OperationMethod<AssociateTimeSeriesToAssetPropertyRequest, AssociateTimeSeriesToAssetPropertyResponse, AssociateTimeSeriesToAssetPropertyError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateDataSegmentsToDatasetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a batch of data segments with a curated dataset. Data segments are
 * time-bounded slices of time series data selected from source session datasets. Data segments
 * that belong to the same time series can't overlap in time, regardless of which dataset they
 * belong to.
 */
export declare const batchAssociateDataSegmentsToDataset: API.OperationMethod<BatchAssociateDataSegmentsToDatasetRequest, BatchAssociateDataSegmentsToDatasetResponse, BatchAssociateDataSegmentsToDatasetError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateProjectAssetsError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Associates a group (batch) of assets with an IoT SiteWise Monitor project.
 */
export declare const batchAssociateProjectAssets: API.OperationMethod<BatchAssociateProjectAssetsRequest, BatchAssociateProjectAssetsResponse, BatchAssociateProjectAssetsError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteDatasetDataSegmentsError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a batch of data segments from a session dataset. Deleting a data segment deletes
 * the underlying time series data for the segment's time range.
 */
export declare const batchDeleteDatasetDataSegments: API.OperationMethod<BatchDeleteDatasetDataSegmentsRequest, BatchDeleteDatasetDataSegmentsResponse, BatchDeleteDatasetDataSegmentsError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateDataSegmentsFromDatasetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a batch of data segments from a curated dataset. Disassociating a data
 * segment doesn't delete the underlying data in the source session dataset.
 */
export declare const batchDisassociateDataSegmentsFromDataset: API.OperationMethod<BatchDisassociateDataSegmentsFromDatasetRequest, BatchDisassociateDataSegmentsFromDatasetResponse, BatchDisassociateDataSegmentsFromDatasetError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateProjectAssetsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a group (batch) of assets from an IoT SiteWise Monitor project.
 */
export declare const batchDisassociateProjectAssets: API.OperationMethod<BatchDisassociateProjectAssetsRequest, BatchDisassociateProjectAssetsResponse, BatchDisassociateProjectAssetsError, Credentials | HttpClient.HttpClient>;
export type BatchGetAssetPropertyAggregatesError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets aggregated values (for example, average, minimum, and maximum) for one or more asset
 * properties. For more information, see Querying aggregates in the
 * *IoT SiteWise User Guide*.
 */
export declare const batchGetAssetPropertyAggregates: API.PaginatedOperationMethod<BatchGetAssetPropertyAggregatesRequest, BatchGetAssetPropertyAggregatesResponse, BatchGetAssetPropertyAggregatesError, Credentials | HttpClient.HttpClient, unknown>;
export type BatchGetAssetPropertyValueError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets the current value for one or more asset properties. For more information, see Querying
 * current values in the *IoT SiteWise User Guide*.
 */
export declare const batchGetAssetPropertyValue: API.PaginatedOperationMethod<BatchGetAssetPropertyValueRequest, BatchGetAssetPropertyValueResponse, BatchGetAssetPropertyValueError, Credentials | HttpClient.HttpClient, unknown>;
export type BatchGetAssetPropertyValueHistoryError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets the historical values for one or more asset properties. For more information, see
 * Querying historical values in the *IoT SiteWise User Guide*.
 */
export declare const batchGetAssetPropertyValueHistory: API.PaginatedOperationMethod<BatchGetAssetPropertyValueHistoryRequest, BatchGetAssetPropertyValueHistoryResponse, BatchGetAssetPropertyValueHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type BatchPutAssetPropertyValueError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Sends a list of asset property values to IoT SiteWise. Each value is a timestamp-quality-value
 * (TQV) data point. For more information, see Ingesting data using the API in the
 * *IoT SiteWise User Guide*.
 *
 * To identify an asset property, you must specify one of the following:
 *
 * - The `assetId` and `propertyId` of an asset property.
 *
 * - A `propertyAlias`, which is a data stream alias (for example,
 * `/company/windfarm/3/turbine/7/temperature`). To define an asset property's alias, see UpdateAssetProperty.
 *
 * With respect to Unix epoch time, IoT SiteWise accepts only TQVs that have a timestamp of no more
 * than 7 days in the past and no more than 10 minutes in the future. IoT SiteWise rejects timestamps
 * outside of the inclusive range of [-7 days, +10 minutes] and returns a
 * `TimestampOutOfRangeException` error.
 *
 * For each asset property, IoT SiteWise overwrites TQVs with duplicate timestamps unless the newer
 * TQV has a different quality. For example, if you store a TQV `{T1, GOOD, V1}`,
 * then storing `{T1, GOOD, V2}` replaces the existing TQV.
 *
 * IoT SiteWise authorizes access to each `BatchPutAssetPropertyValue` entry individually.
 * For more information, see BatchPutAssetPropertyValue authorization in the
 * *IoT SiteWise User Guide*.
 */
export declare const batchPutAssetPropertyValue: API.OperationMethod<BatchPutAssetPropertyValueRequest, BatchPutAssetPropertyValueResponse, BatchPutAssetPropertyValueError, Credentials | HttpClient.HttpClient>;
export type CancelEnrichmentJobError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Cancels a running or pending enrichment job. This is an idempotent operation—calling it multiple
 * times with the same jobId is safe and returns the current status.
 *
 * Behavior
 *
 * - Jobs in PENDING or RUNNING status transition to CANCELLED
 *
 * - Jobs in RUNNING state may not be cancellable once they have progressed to certain processing stages
 *
 * - Jobs already in terminal states (COMPLETED, FAILED, TIMED_OUT) cannot be cancelled;
 * the operation returns a ConflictingOperationException
 *
 * - Cancelling an already-CANCELLED job is a no-op and returns the current status (idempotent behavior)
 *
 * - The API responds immediately after recording the cancellation
 *
 * - Cleanup of job resources happens asynchronously in the background
 *
 * When to Cancel
 *
 * Cancel a job when:
 *
 * - The job is taking longer than expected
 *
 * - The job was created with incorrect parameters
 *
 * - You no longer need the results
 *
 * Idempotency
 *
 * You can safely retry cancellation requests. Calling CancelEnrichmentJob multiple times for the same
 * job returns the current status without error as long as the job is not in a terminal state other
 * than CANCELLED.
 */
export declare const cancelEnrichmentJob: API.OperationMethod<CancelEnrichmentJobRequest, CancelEnrichmentJobResponse, CancelEnrichmentJobError, Credentials | HttpClient.HttpClient>;
export type CancelPipelineExecutionError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Cancels a pipeline execution in the specified workspace. If the execution
 * is not in a terminal state (such as NOT_STARTED or RUNNING), it transitions to
 * CANCELLING and asynchronously to CANCELLED. This operation is idempotent: calling
 * it on an execution that is already CANCELLING or CANCELLED returns success with
 * the current state. Calling it on a terminal execution (SUCCEEDED or FAILED)
 * returns a conflict error. You can optionally provide a reason; it is returned in
 * the stateDetails field when you describe the execution.
 */
export declare const cancelPipelineExecution: API.OperationMethod<CancelPipelineExecutionRequest, CancelPipelineExecutionResponse, CancelPipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type CancelQueryError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Cancels a running query.
 */
export declare const cancelQuery: API.OperationMethod<CancelQueryRequest, CancelQueryResponse, CancelQueryError, Credentials | HttpClient.HttpClient>;
export type CreateAccessPolicyError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Creates an access policy that grants the specified identity (IAM Identity Center user, IAM Identity Center group, or
 * IAM user) access to the specified IoT SiteWise Monitor portal or project resource.
 *
 * Support for access policies that use an SSO Group as the identity is not supported at this time.
 */
export declare const createAccessPolicy: API.OperationMethod<CreateAccessPolicyRequest, CreateAccessPolicyResponse, CreateAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new application for the workspace and IdC application provided
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateAssetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an asset from an existing asset model. For more information, see Creating assets in the
 * *IoT SiteWise User Guide*.
 */
export declare const createAsset: API.OperationMethod<CreateAssetRequest, CreateAssetResponse, CreateAssetError, Credentials | HttpClient.HttpClient>;
export type CreateAssetModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an asset model from specified property and hierarchy definitions. You create
 * assets from asset models. With asset models, you can easily create assets of the same type
 * that have standardized definitions. Each asset created from a model inherits the asset model's
 * property and hierarchy definitions. For more information, see Defining asset models in the
 * *IoT SiteWise User Guide*.
 *
 * You can create three types of asset models, `ASSET_MODEL`,
 * `COMPONENT_MODEL`, or an `INTERFACE`.
 *
 * - **ASSET_MODEL** – (default) An asset model that
 * you can use to create assets. Can't be included as a component in another asset
 * model.
 *
 * - **COMPONENT_MODEL** – A reusable component that
 * you can include in the composite models of other asset models. You can't create
 * assets directly from this type of asset model.
 *
 * - **INTERFACE** – An interface is a type of model
 * that defines a standard structure that can be applied to different asset models.
 */
export declare const createAssetModel: API.OperationMethod<CreateAssetModelRequest, CreateAssetModelResponse, CreateAssetModelError, Credentials | HttpClient.HttpClient>;
export type CreateAssetModelCompositeModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | PreconditionFailedException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a custom composite model from specified property and hierarchy definitions. There
 * are two types of custom composite models, `inline` and
 * `component-model-based`.
 *
 * Use component-model-based custom composite models to define standard, reusable components.
 * A component-model-based custom composite model consists of a name, a description, and the ID
 * of the component model it references. A component-model-based custom composite model has no
 * properties of its own; its referenced component model provides its associated properties to
 * any created assets. For more information, see Custom composite models (Components)
 * in the *IoT SiteWise User Guide*.
 *
 * Use inline custom composite models to organize the properties of an asset model. The
 * properties of inline custom composite models are local to the asset model where they are
 * included and can't be used to create multiple assets.
 *
 * To create a component-model-based model, specify the `composedAssetModelId` of
 * an existing asset model with `assetModelType` of
 * `COMPONENT_MODEL`.
 *
 * To create an inline model, specify the `assetModelCompositeModelProperties` and
 * don't include an `composedAssetModelId`.
 */
export declare const createAssetModelCompositeModel: API.OperationMethod<CreateAssetModelCompositeModelRequest, CreateAssetModelCompositeModelResponse, CreateAssetModelCompositeModelError, Credentials | HttpClient.HttpClient>;
export type CreateBulkImportJobError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Defines a job to ingest data to IoT SiteWise from Amazon S3. For more information, see Create a
 * bulk import job (CLI) in the *Amazon Simple Storage Service User Guide*.
 *
 * Before you create a bulk import job that ingests data into time series outside of a
 * workspace, you must enable IoT SiteWise warm tier or IoT SiteWise cold tier. For more information about how
 * to configure storage settings, see PutStorageConfiguration. This requirement doesn't apply to bulk import jobs that
 * ingest data into a session dataset in a workspace (jobs that specify a
 * `workspaceName` and `datasetId`). Those jobs don't use IoT SiteWise warm or
 * cold tier storage.
 *
 * Bulk import is designed to store historical data to IoT SiteWise.
 *
 * - Newly ingested data in the hot tier triggers notifications and computations.
 *
 * - After data moves from the hot tier to the warm or cold tier based on retention
 * settings, it does not trigger computations or notifications.
 *
 * - Data older than 7 days does not trigger computations or notifications.
 */
export declare const createBulkImportJob: API.OperationMethod<CreateBulkImportJobRequest, CreateBulkImportJobResponse, CreateBulkImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateComputationModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Create a computation model with a configuration and data binding.
 */
export declare const createComputationModel: API.OperationMethod<CreateComputationModelRequest, CreateComputationModelResponse, CreateComputationModelError, Credentials | HttpClient.HttpClient>;
export type CreateDashboardError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Creates a dashboard in an IoT SiteWise Monitor project.
 */
export declare const createDashboard: API.OperationMethod<CreateDashboardRequest, CreateDashboardResponse, CreateDashboardError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a dataset. Session and curated datasets are created in a workspace. A session dataset contains data segments of time series data, and a curated dataset curates data segments selected from source session datasets. A dataset that connects to an external datasource is created outside of a workspace.
 */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest, CreateDatasetResponse, CreateDatasetError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetExportJobError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts an asynchronous job that exports dataset and time-series data from a workspace to Amazon
 * S3. The operation returns a jobId immediately; poll DescribeDatasetExportJob to track progress and
 * ListDatasetExportJobs to enumerate a workspace's jobs.
 */
export declare const createDatasetExportJob: API.OperationMethod<CreateDatasetExportJobRequest, CreateDatasetExportJobResponse, CreateDatasetExportJobError, Credentials | HttpClient.HttpClient>;
export type CreateEnrichmentJobError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an asynchronous enrichment job to analyze time-series sensor data. The operation returns
 * immediately with job details while processing continues in the background.
 *
 * Idempotency
 *
 * Include a clientToken to make the operation idempotent. If you submit the same request with the same
 * token within the idempotency window, you receive the original job details without creating a duplicate.
 *
 * Prerequisites
 *
 * Before creating a job, ensure:
 *
 * - The workspace is in ACTIVE state (not being deleted)
 *
 * - You have IAM permissions for the workspace, dataset, and time-series resources
 *
 * - You have KMS Decrypt permission on the workspace's customer-managed encryption key
 *
 * - No duplicate job (same workspace, dataset, property, and job type) is currently running
 *
 * Workflow
 *
 * - Submit the job with configuration specifying which video data to analyze and the time range
 *
 * - Capture the jobId from the response
 *
 * - Use DescribeEnrichmentJob to monitor progress and check job status
 *
 * - When status reaches a terminal state (COMPLETED, FAILED, TIMED_OUT, CANCELLED), check results
 *
 * - For COMPLETED jobs, query IoT SiteWise for semantic search on video events
 *
 * Error Handling
 *
 * - ConflictingOperationException: A duplicate job is already running for the same configuration
 *
 * - InvalidRequestException: Invalid parameters (e.g., both timeSeriesId and propertyAlias specified)
 *
 * - AccessDeniedException: Insufficient IAM or KMS permissions
 *
 * - LimitExceededException: Too many concurrent jobs or requests
 */
export declare const createEnrichmentJob: API.OperationMethod<CreateEnrichmentJobRequest, CreateEnrichmentJobResponse, CreateEnrichmentJobError, Credentials | HttpClient.HttpClient>;
export type CreateGatewayError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a gateway, which is a virtual or edge device that delivers industrial data streams
 * from local servers to IoT SiteWise. For more information, see Ingesting data using a gateway in the
 * *IoT SiteWise User Guide*.
 */
export declare const createGateway: API.OperationMethod<CreateGatewayRequest, CreateGatewayResponse, CreateGatewayError, Credentials | HttpClient.HttpClient>;
export type CreatePipelineError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new pipeline in the specified workspace. A pipeline defines a
 * directed acyclic graph (DAG) of compute nodes, where each node references a task
 * and can declare dependencies on other nodes. Cyclic dependencies are not
 * allowed. Nodes without dependencies run in parallel, while nodes with dependencies
 * wait for all upstream nodes to complete successfully before starting.
 *
 * You can set environment variables at the pipeline level that are shared across all
 * compute nodes, and override them at the individual compute node level.
 */
export declare const createPipeline: API.OperationMethod<CreatePipelineRequest, CreatePipelineResponse, CreatePipelineError, Credentials | HttpClient.HttpClient>;
export type CreatePortalError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Creates a portal, which can contain projects and dashboards. IoT SiteWise Monitor uses IAM Identity Center or IAM
 * to authenticate portal users and manage user permissions.
 *
 * Before you can sign in to a new portal, you must add at least one identity to that
 * portal. For more information, see Adding or removing portal
 * administrators in the *IoT SiteWise User Guide*.
 */
export declare const createPortal: API.OperationMethod<CreatePortalRequest, CreatePortalResponse, CreatePortalError, Credentials | HttpClient.HttpClient>;
export type CreateProjectError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Creates a project in the specified portal.
 *
 * Make sure that the project name and description don't contain confidential
 * information.
 */
export declare const createProject: API.OperationMethod<CreateProjectRequest, CreateProjectResponse, CreateProjectError, Credentials | HttpClient.HttpClient>;
export type CreateTaskError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new task in the specified workspace. A task defines a reusable
 * containerized compute workload that can be referenced by one or more pipeline compute nodes.
 *
 * Specify a `containerTaskConfiguration` for custom container workloads with
 * configurable ECR image, processing type, processing unit, and environment variables.
 */
export declare const createTask: API.OperationMethod<CreateTaskRequest, CreateTaskResponse, CreateTaskError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspaceError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a workspace in IoT SiteWise. A workspace isolates its resources, such as datasets, time
 * series, pipelines, and tasks, and their data from other workspaces, and has its own quotas
 * and throttling limits. You must specify an encryption configuration when you create
 * a workspace. The operation returns immediately with the workspace in the
 * `CREATING` state. Provisioning completes asynchronously, after which the workspace
 * state is `ACTIVE`, or `FAILED` if provisioning doesn't complete.
 */
export declare const createWorkspace: API.OperationMethod<CreateWorkspaceRequest, CreateWorkspaceResponse, CreateWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessPolicyError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an access policy that grants the specified identity access to the specified
 * IoT SiteWise Monitor resource. You can use this operation to revoke access to an IoT SiteWise Monitor
 * resource.
 */
export declare const deleteAccessPolicy: API.OperationMethod<DeleteAccessPolicyRequest, DeleteAccessPolicyResponse, DeleteAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an application by ID
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an asset. This action can't be undone. For more information, see Deleting assets and
 * models in the *IoT SiteWise User Guide*.
 *
 * You can't delete an asset that's associated to another asset. For more information, see
 * DisassociateAssets.
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetRequest, DeleteAssetResponse, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | PreconditionFailedException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an asset model. This action can't be undone. You must delete all assets created
 * from an asset model before you can delete the model. Also, you can't delete an asset model if
 * a parent asset model exists that contains a property formula expression that depends on the
 * asset model that you want to delete. For more information, see Deleting assets and models in the
 * *IoT SiteWise User Guide*.
 */
export declare const deleteAssetModel: API.OperationMethod<DeleteAssetModelRequest, DeleteAssetModelResponse, DeleteAssetModelError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetModelCompositeModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | PreconditionFailedException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a composite model. This action can't be undone. You must delete all assets created
 * from a composite model before you can delete the model. Also, you can't delete a composite
 * model if a parent asset model exists that contains a property formula expression that depends
 * on the asset model that you want to delete. For more information, see Deleting assets and
 * models in the *IoT SiteWise User Guide*.
 */
export declare const deleteAssetModelCompositeModel: API.OperationMethod<DeleteAssetModelCompositeModelRequest, DeleteAssetModelCompositeModelResponse, DeleteAssetModelCompositeModelError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetModelInterfaceRelationshipError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an interface relationship between an asset model and an interface asset
 * model.
 */
export declare const deleteAssetModelInterfaceRelationship: API.OperationMethod<DeleteAssetModelInterfaceRelationshipRequest, DeleteAssetModelInterfaceRelationshipResponse, DeleteAssetModelInterfaceRelationshipError, Credentials | HttpClient.HttpClient>;
export type DeleteComputationModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a computation model. This action can't be undone.
 */
export declare const deleteComputationModel: API.OperationMethod<DeleteComputationModelRequest, DeleteComputationModelResponse, DeleteComputationModelError, Credentials | HttpClient.HttpClient>;
export type DeleteDashboardError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a dashboard from IoT SiteWise Monitor.
 */
export declare const deleteDashboard: API.OperationMethod<DeleteDashboardRequest, DeleteDashboardResponse, DeleteDashboardError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a dataset. This can't be undone. Deleting a session dataset also deletes the underlying time series data in the session. You can't delete a session dataset while a curated dataset references its data segments. First delete the curated dataset or disassociate the data segments. Deleting a curated dataset doesn't delete the underlying data in the source session datasets.
 */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest, DeleteDatasetResponse, DeleteDatasetError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a gateway from IoT SiteWise. When you delete a gateway, some of the gateway's files remain
 * in your gateway's file system.
 */
export declare const deleteGateway: API.OperationMethod<DeleteGatewayRequest, DeleteGatewayResponse, DeleteGatewayError, Credentials | HttpClient.HttpClient>;
export type DeletePipelineError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a pipeline from the specified workspace. A pipeline cannot be
 * deleted if it has any active executions. Wait for all executions to complete before
 * attempting to delete the pipeline, or use CancelPipelineExecution to stop a running
 * execution.
 */
export declare const deletePipeline: API.OperationMethod<DeletePipelineRequest, DeletePipelineResponse, DeletePipelineError, Credentials | HttpClient.HttpClient>;
export type DeletePortalError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a portal from IoT SiteWise Monitor.
 */
export declare const deletePortal: API.OperationMethod<DeletePortalRequest, DeletePortalResponse, DeletePortalError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a project from IoT SiteWise Monitor.
 */
export declare const deleteProject: API.OperationMethod<DeleteProjectRequest, DeleteProjectResponse, DeleteProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteTaskError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a task from the specified workspace. A task cannot be deleted
 * if it is currently referenced by any existing pipeline. Remove the task from all
 * pipelines before attempting to delete it.
 */
export declare const deleteTask: API.OperationMethod<DeleteTaskRequest, DeleteTaskResponse, DeleteTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteTimeSeriesError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a time series (data stream). If you delete a time series that's associated with an
 * asset property, the asset property still exists, but the time series will no longer be
 * associated with this asset property. You can't delete a time series until all of its data
 * segments have been deleted from session datasets.
 *
 * To identify a time series, do one of the following:
 *
 * - If the time series isn't associated with an asset property,
 * specify the `alias` of the time series.
 *
 * - If the time series is associated with an asset property,
 * specify one of the following:
 *
 * - The `alias` of the time series.
 *
 * - The `assetId` and `propertyId` that identifies the asset property.
 */
export declare const deleteTimeSeries: API.OperationMethod<DeleteTimeSeriesRequest, DeleteTimeSeriesResponse, DeleteTimeSeriesError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkspaceError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a workspace. Before you delete a workspace, you must delete all resources
 * contained in or associated with the workspace, such as datasets, time series, pipelines,
 * and tasks.
 */
export declare const deleteWorkspace: API.OperationMethod<DeleteWorkspaceRequest, DeleteWorkspaceResponse, DeleteWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DescribeAccessPolicyError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an access policy, which specifies an identity's access to an IoT SiteWise Monitor portal or
 * project.
 */
export declare const describeAccessPolicy: API.OperationMethod<DescribeAccessPolicyRequest, DescribeAccessPolicyResponse, DescribeAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeActionError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an action.
 */
export declare const describeAction: API.OperationMethod<DescribeActionRequest, DescribeActionResponse, DescribeActionError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves Application details based on the ID
 */
export declare const describeApplication: API.OperationMethod<DescribeApplicationRequest, DescribeApplicationResponse, DescribeApplicationError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an asset.
 */
export declare const describeAsset: API.OperationMethod<DescribeAssetRequest, DescribeAssetResponse, DescribeAssetError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetCompositeModelError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an asset composite model (also known as an asset component).
 * An `AssetCompositeModel` is an instance of an
 * `AssetModelCompositeModel`. If you want to see information about the model this is
 * based on, call DescribeAssetModelCompositeModel.
 */
export declare const describeAssetCompositeModel: API.OperationMethod<DescribeAssetCompositeModelRequest, DescribeAssetCompositeModelResponse, DescribeAssetCompositeModelError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetModelError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an asset model. This includes details about the asset model's
 * properties, hierarchies, composite models, and any interface relationships if the asset model
 * implements interfaces.
 */
export declare const describeAssetModel: API.OperationMethod<DescribeAssetModelRequest, DescribeAssetModelResponse, DescribeAssetModelError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetModelCompositeModelError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an asset model composite model (also known as an asset model
 * component). For more information, see Custom composite models
 * (Components) in the *IoT SiteWise User Guide*.
 */
export declare const describeAssetModelCompositeModel: API.OperationMethod<DescribeAssetModelCompositeModelRequest, DescribeAssetModelCompositeModelResponse, DescribeAssetModelCompositeModelError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetModelInterfaceRelationshipError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an interface relationship between an asset model and an
 * interface asset model.
 */
export declare const describeAssetModelInterfaceRelationship: API.OperationMethod<DescribeAssetModelInterfaceRelationshipRequest, DescribeAssetModelInterfaceRelationshipResponse, DescribeAssetModelInterfaceRelationshipError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetPropertyError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an asset property.
 *
 * When you call this operation for an attribute property, this response includes the
 * default attribute value that you define in the asset model. If you update the default value
 * in the model, this operation's response includes the new default value.
 *
 * This operation doesn't return the value of the asset property. To get the value of an
 * asset property, use GetAssetPropertyValue.
 */
export declare const describeAssetProperty: API.OperationMethod<DescribeAssetPropertyRequest, DescribeAssetPropertyResponse, DescribeAssetPropertyError, Credentials | HttpClient.HttpClient>;
export type DescribeBulkImportJobError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a bulk import job request. For more information, see Describe
 * a bulk import job (CLI) in the *Amazon Simple Storage Service User Guide*.
 */
export declare const describeBulkImportJob: API.OperationMethod<DescribeBulkImportJobRequest, DescribeBulkImportJobResponse, DescribeBulkImportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeComputationModelError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a computation model.
 */
export declare const describeComputationModel: API.OperationMethod<DescribeComputationModelRequest, DescribeComputationModelResponse, DescribeComputationModelError, Credentials | HttpClient.HttpClient>;
export type DescribeComputationModelExecutionSummaryError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about the execution summary of a computation model.
 */
export declare const describeComputationModelExecutionSummary: API.OperationMethod<DescribeComputationModelExecutionSummaryRequest, DescribeComputationModelExecutionSummaryResponse, DescribeComputationModelExecutionSummaryError, Credentials | HttpClient.HttpClient>;
export type DescribeDashboardError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a dashboard.
 */
export declare const describeDashboard: API.OperationMethod<DescribeDashboardRequest, DescribeDashboardResponse, DescribeDashboardError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a dataset.
 */
export declare const describeDataset: API.OperationMethod<DescribeDatasetRequest, DescribeDatasetResponse, DescribeDatasetError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetExportJobError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a dataset export job.
 */
export declare const describeDatasetExportJob: API.OperationMethod<DescribeDatasetExportJobRequest, DescribeDatasetExportJobResponse, DescribeDatasetExportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeDefaultEncryptionConfigurationError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about the default encryption configuration for the Amazon Web Services account in
 * the default or specified Region. For more information, see Key management in the
 * *IoT SiteWise User Guide*.
 */
export declare const describeDefaultEncryptionConfiguration: API.OperationMethod<DescribeDefaultEncryptionConfigurationRequest, DescribeDefaultEncryptionConfigurationResponse, DescribeDefaultEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeEnrichmentJobError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about a specific enrichment job, including its current status,
 * configuration, and timestamps.
 *
 * Use Cases
 *
 * - Monitor job progress by checking status updates with DescribeEnrichmentJob
 *
 * - Retrieve the complete job configuration submitted during creation
 *
 * - Debug failed jobs by examining the failureMessage field
 *
 * - Track job lifecycle with creation, update, completion, and cancellation timestamps
 *
 * Status Monitoring
 *
 * Jobs progress through statuses: PENDING → RUNNING → terminal state
 *
 * Terminal states:
 *
 * - COMPLETED: Job finished successfully; query IoT SiteWise for semantic search results
 *
 * - FAILED: Job encountered an error; check failureMessage for details
 *
 * - TIMED_OUT: Job exceeded maximum processing time
 *
 * - CANCELLED: Job was cancelled via CancelEnrichmentJob
 *
 * Response Fields
 *
 * The response includes:
 *
 * - Current job status and type
 *
 * - Full job configuration as originally submitted
 *
 * - Lifecycle timestamps (created, updated, completed, cancelled)
 *
 * - Failure details if status is FAILED
 */
export declare const describeEnrichmentJob: API.OperationMethod<DescribeEnrichmentJobRequest, DescribeEnrichmentJobResponse, DescribeEnrichmentJobError, Credentials | HttpClient.HttpClient>;
export type DescribeExecutionError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about the execution.
 */
export declare const describeExecution: API.OperationMethod<DescribeExecutionRequest, DescribeExecutionResponse, DescribeExecutionError, Credentials | HttpClient.HttpClient>;
export type DescribeGatewayError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a gateway.
 */
export declare const describeGateway: API.OperationMethod<DescribeGatewayRequest, DescribeGatewayResponse, DescribeGatewayError, Credentials | HttpClient.HttpClient>;
export type DescribeGatewayCapabilityConfigurationError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Each gateway capability defines data sources for a gateway. This is the namespace of the gateway capability.
 *
 * . The namespace follows the format `service:capability:version`, where:
 *
 * - `service` - The service providing the capability, or `iotsitewise`.
 *
 * - `capability` - The specific capability type. Options include: `opcuacollector` for the OPC UA data source collector, or `publisher` for data publisher capability.
 *
 * - `version` - The version number of the capability. Option include `2` for Classic streams, V2 gateways, and `3` for MQTT-enabled, V3 gateways.
 *
 * After updating a capability configuration, the sync status becomes `OUT_OF_SYNC` until the gateway processes the configuration.Use `DescribeGatewayCapabilityConfiguration` to check the sync status and verify the configuration was applied.
 *
 * A gateway can have multiple capability configurations with different namespaces.
 */
export declare const describeGatewayCapabilityConfiguration: API.OperationMethod<DescribeGatewayCapabilityConfigurationRequest, DescribeGatewayCapabilityConfigurationResponse, DescribeGatewayCapabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeLoggingOptionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the current IoT SiteWise logging options.
 */
export declare const describeLoggingOptions: API.OperationMethod<DescribeLoggingOptionsRequest, DescribeLoggingOptionsResponse, DescribeLoggingOptionsError, Credentials | HttpClient.HttpClient>;
export type DescribePipelineError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about a specific pipeline in a workspace.
 */
export declare const describePipeline: API.OperationMethod<DescribePipelineRequest, DescribePipelineResponse, DescribePipelineError, Credentials | HttpClient.HttpClient>;
export type DescribePipelineExecutionError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about a specific pipeline execution, including the
 * overall execution status and the status of each individual compute node. Use this
 * operation to monitor execution progress and inspect per-node results, environment
 * variables, and error details.
 */
export declare const describePipelineExecution: API.PaginatedOperationMethod<DescribePipelineExecutionRequest, DescribePipelineExecutionResponse, DescribePipelineExecutionError, Credentials | HttpClient.HttpClient, ComputeNodeExecutionDetails>;
export type DescribePortalError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a portal.
 */
export declare const describePortal: API.OperationMethod<DescribePortalRequest, DescribePortalResponse, DescribePortalError, Credentials | HttpClient.HttpClient>;
export type DescribeProjectError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a project.
 */
export declare const describeProject: API.OperationMethod<DescribeProjectRequest, DescribeProjectResponse, DescribeProjectError, Credentials | HttpClient.HttpClient>;
export type DescribeQueryError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a query, including its status.
 */
export declare const describeQuery: API.OperationMethod<DescribeQueryRequest, DescribeQueryResponse, DescribeQueryError, Credentials | HttpClient.HttpClient>;
export type DescribeSearchError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the current status and metadata of a single search, including the query that was
 * submitted, the search type, and — when the search has failed — the reason. Use this to poll a
 * search started with `StartSearch` until it reaches a terminal status (`SUCCEEDED` or
 * `FAILED`).
 */
export declare const describeSearch: API.OperationMethod<DescribeSearchRequest, DescribeSearchResponse, DescribeSearchError, Credentials | HttpClient.HttpClient>;
export type DescribeStorageConfigurationError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about the storage configuration for IoT SiteWise.
 */
export declare const describeStorageConfiguration: API.OperationMethod<DescribeStorageConfigurationRequest, DescribeStorageConfigurationResponse, DescribeStorageConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeTaskError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about a specific task in a workspace.
 */
export declare const describeTask: API.OperationMethod<DescribeTaskRequest, DescribeTaskResponse, DescribeTaskError, Credentials | HttpClient.HttpClient>;
export type DescribeTimeSeriesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a time series (data stream).
 *
 * To identify a time series, do one of the following:
 *
 * - If the time series isn't associated with an asset property,
 * specify the `alias` of the time series.
 *
 * - If the time series is associated with an asset property,
 * specify one of the following:
 *
 * - The `alias` of the time series.
 *
 * - The `assetId` and `propertyId` that identifies the asset property.
 */
export declare const describeTimeSeries: API.OperationMethod<DescribeTimeSeriesRequest, DescribeTimeSeriesResponse, DescribeTimeSeriesError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspaceError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a workspace.
 */
export declare const describeWorkspace: API.OperationMethod<DescribeWorkspaceRequest, DescribeWorkspaceResponse, DescribeWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DisassociateAssetsError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a child asset from the given parent asset through a hierarchy defined in the
 * parent asset's model.
 */
export declare const disassociateAssets: API.OperationMethod<DisassociateAssetsRequest, DisassociateAssetsResponse, DisassociateAssetsError, Credentials | HttpClient.HttpClient>;
export type DisassociateTimeSeriesFromAssetPropertyError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a time series (data stream) from an asset property.
 */
export declare const disassociateTimeSeriesFromAssetProperty: API.OperationMethod<DisassociateTimeSeriesFromAssetPropertyRequest, DisassociateTimeSeriesFromAssetPropertyResponse, DisassociateTimeSeriesFromAssetPropertyError, Credentials | HttpClient.HttpClient>;
export type ExecuteActionError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Executes an action on a target resource.
 */
export declare const executeAction: API.OperationMethod<ExecuteActionRequest, ExecuteActionResponse, ExecuteActionError, Credentials | HttpClient.HttpClient>;
export type ExecuteQueryError = AccessDeniedException | InternalFailureException | InvalidRequestException | QueryTimeoutException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Run SQL queries to retrieve metadata and time-series data from asset models, assets,
 * measurements, metrics, transforms, and aggregates.
 */
export declare const executeQuery: API.PaginatedOperationMethod<ExecuteQueryRequest, ExecuteQueryResponse, ExecuteQueryError, Credentials | HttpClient.HttpClient, Row>;
export type GetAssetPropertyAggregatesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets aggregated values for an asset property. For more information, see Querying
 * aggregates in the *IoT SiteWise User Guide*.
 *
 * To identify an asset property, you must specify one of the following:
 *
 * - The `assetId` and `propertyId` of an asset property.
 *
 * - A `propertyAlias`, which is a data stream alias (for example,
 * `/company/windfarm/3/turbine/7/temperature`). To define an asset property's alias, see UpdateAssetProperty.
 */
export declare const getAssetPropertyAggregates: API.PaginatedOperationMethod<GetAssetPropertyAggregatesRequest, GetAssetPropertyAggregatesResponse, GetAssetPropertyAggregatesError, Credentials | HttpClient.HttpClient, AggregatedValue>;
export type GetAssetPropertyValueError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets an asset property's current value. For more information, see Querying
 * current values in the *IoT SiteWise User Guide*.
 *
 * To identify an asset property, you must specify one of the following:
 *
 * - The `assetId` and `propertyId` of an asset property.
 *
 * - A `propertyAlias`, which is a data stream alias (for example,
 * `/company/windfarm/3/turbine/7/temperature`). To define an asset property's alias, see UpdateAssetProperty.
 */
export declare const getAssetPropertyValue: API.OperationMethod<GetAssetPropertyValueRequest, GetAssetPropertyValueResponse, GetAssetPropertyValueError, Credentials | HttpClient.HttpClient>;
export type GetAssetPropertyValueHistoryError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets the history of an asset property's values. For more information, see Querying
 * historical values in the *IoT SiteWise User Guide*.
 *
 * To identify an asset property, you must specify one of the following:
 *
 * - The `assetId` and `propertyId` of an asset property.
 *
 * - A `propertyAlias`, which is a data stream alias (for example,
 * `/company/windfarm/3/turbine/7/temperature`). To define an asset property's alias, see UpdateAssetProperty.
 */
export declare const getAssetPropertyValueHistory: API.PaginatedOperationMethod<GetAssetPropertyValueHistoryRequest, GetAssetPropertyValueHistoryResponse, GetAssetPropertyValueHistoryError, Credentials | HttpClient.HttpClient, AssetPropertyValue>;
export type GetCaptureDataError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves video data for a specific time range.
 */
export declare const getCaptureData: API.OperationMethod<GetCaptureDataRequest, GetCaptureDataResponse, GetCaptureDataError, Credentials | HttpClient.HttpClient>;
export type GetInterpolatedAssetPropertyValuesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Get interpolated values for an asset property for a specified time interval, during a
 * period of time. If your time series is missing data points during the specified time interval,
 * you can use interpolation to estimate the missing data.
 *
 * For example, you can use this operation to return the interpolated temperature values for
 * a wind turbine every 24 hours over a duration of 7 days.
 *
 * To identify an asset property, you must specify one of the following:
 *
 * - The `assetId` and `propertyId` of an asset property.
 *
 * - A `propertyAlias`, which is a data stream alias (for example,
 * `/company/windfarm/3/turbine/7/temperature`). To define an asset property's alias, see UpdateAssetProperty.
 */
export declare const getInterpolatedAssetPropertyValues: API.PaginatedOperationMethod<GetInterpolatedAssetPropertyValuesRequest, GetInterpolatedAssetPropertyValuesResponse, GetInterpolatedAssetPropertyValuesError, Credentials | HttpClient.HttpClient, InterpolatedAssetPropertyValue>;
export type GetQueryResultsError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the paginated results of a query. Returns empty rows if the query is not yet complete.
 */
export declare const getQueryResults: API.PaginatedOperationMethod<GetQueryResultsRequest, GetQueryResultsResponse, GetQueryResultsError, Credentials | HttpClient.HttpClient, ColumnValue[]>;
export type GetSearchResultsError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the ranked results of a search, ordered by descending relevance score. Results are
 * available only after the search has reached the `SUCCEEDED` status. Calling this on a search
 * that exists but has not yet completed returns `InvalidRequestException`, while calling it on a
 * search that does not exist returns `ResourceNotFoundException`. The response is paginated: when
 * `nextToken` is present, pass it on a subsequent call to retrieve the next page.
 */
export declare const getSearchResults: API.PaginatedOperationMethod<GetSearchResultsRequest, GetSearchResultsResponse, GetSearchResultsError, Credentials | HttpClient.HttpClient, SearchResult>;
export type InvokeAssistantError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Invokes SiteWise Assistant to start or continue a conversation.
 */
export declare const invokeAssistant: API.OperationMethod<InvokeAssistantRequest, InvokeAssistantResponse, InvokeAssistantError, Credentials | HttpClient.HttpClient>;
export type ListAccessPoliciesError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of access policies for an identity (an IAM Identity Center user, an IAM Identity Center
 * group, or an IAM user) or an IoT SiteWise Monitor resource (a portal or project).
 */
export declare const listAccessPolicies: API.PaginatedOperationMethod<ListAccessPoliciesRequest, ListAccessPoliciesResponse, ListAccessPoliciesError, Credentials | HttpClient.HttpClient, AccessPolicySummary>;
export type ListActionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of actions for a specific target resource.
 */
export declare const listActions: API.PaginatedOperationMethod<ListActionsRequest, ListActionsResponse, ListActionsError, Credentials | HttpClient.HttpClient, ActionSummary>;
export type ListApplicationsError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of existing applications
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListAssetModelCompositeModelsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of composite models associated with the asset model
 */
export declare const listAssetModelCompositeModels: API.PaginatedOperationMethod<ListAssetModelCompositeModelsRequest, ListAssetModelCompositeModelsResponse, ListAssetModelCompositeModelsError, Credentials | HttpClient.HttpClient, AssetModelCompositeModelSummary>;
export type ListAssetModelPropertiesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of properties associated with an asset model.
 * If you update properties associated with the model before you finish listing all the properties,
 * you need to start all over again.
 */
export declare const listAssetModelProperties: API.PaginatedOperationMethod<ListAssetModelPropertiesRequest, ListAssetModelPropertiesResponse, ListAssetModelPropertiesError, Credentials | HttpClient.HttpClient, AssetModelPropertySummary>;
export type ListAssetModelsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of summaries of all asset models.
 */
export declare const listAssetModels: API.PaginatedOperationMethod<ListAssetModelsRequest, ListAssetModelsResponse, ListAssetModelsError, Credentials | HttpClient.HttpClient, AssetModelSummary>;
export type ListAssetPropertiesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of properties associated with an asset.
 * If you update properties associated with the model before you finish listing all the properties,
 * you need to start all over again.
 */
export declare const listAssetProperties: API.PaginatedOperationMethod<ListAssetPropertiesRequest, ListAssetPropertiesResponse, ListAssetPropertiesError, Credentials | HttpClient.HttpClient, AssetPropertySummary>;
export type ListAssetRelationshipsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of asset relationships for an asset. You can use this operation
 * to identify an asset's root asset and all associated assets between that asset and its
 * root.
 */
export declare const listAssetRelationships: API.PaginatedOperationMethod<ListAssetRelationshipsRequest, ListAssetRelationshipsResponse, ListAssetRelationshipsError, Credentials | HttpClient.HttpClient, AssetRelationshipSummary>;
export type ListAssetsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of asset summaries.
 *
 * You can use this operation to do the following:
 *
 * - List assets based on a specific asset model.
 *
 * - List top-level assets.
 *
 * You can't use this operation to list all assets. To retrieve summaries for all of your
 * assets, use ListAssetModels to get all of your asset model IDs. Then, use ListAssets to get all
 * assets for each asset model.
 */
export declare const listAssets: API.PaginatedOperationMethod<ListAssetsRequest, ListAssetsResponse, ListAssetsError, Credentials | HttpClient.HttpClient, AssetSummary>;
export type ListAssociatedAssetsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of associated assets.
 *
 * You can use this operation to do the following:
 *
 * - `CHILD` - List all child assets associated to the asset.
 *
 * - `PARENT` - List the asset's parent asset.
 */
export declare const listAssociatedAssets: API.PaginatedOperationMethod<ListAssociatedAssetsRequest, ListAssociatedAssetsResponse, ListAssociatedAssetsError, Credentials | HttpClient.HttpClient, AssociatedAssetsSummary>;
export type ListBulkImportJobsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of bulk import job requests. For more information, see List bulk
 * import jobs (CLI) in the *IoT SiteWise User Guide*.
 */
export declare const listBulkImportJobs: API.PaginatedOperationMethod<ListBulkImportJobsRequest, ListBulkImportJobsResponse, ListBulkImportJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListCompositionRelationshipsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of composition relationships for an asset model of type
 * `COMPONENT_MODEL`.
 */
export declare const listCompositionRelationships: API.PaginatedOperationMethod<ListCompositionRelationshipsRequest, ListCompositionRelationshipsResponse, ListCompositionRelationshipsError, Credentials | HttpClient.HttpClient, CompositionRelationshipSummary>;
export type ListComputationModelDataBindingUsagesError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists all data binding usages for computation models. This allows to identify where
 * specific data bindings are being utilized across the computation models. This track
 * dependencies between data sources and computation models.
 */
export declare const listComputationModelDataBindingUsages: API.PaginatedOperationMethod<ListComputationModelDataBindingUsagesRequest, ListComputationModelDataBindingUsagesResponse, ListComputationModelDataBindingUsagesError, Credentials | HttpClient.HttpClient, ComputationModelDataBindingUsageSummary>;
export type ListComputationModelResolveToResourcesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all distinct resources that are resolved from the executed actions of the
 * computation model.
 */
export declare const listComputationModelResolveToResources: API.PaginatedOperationMethod<ListComputationModelResolveToResourcesRequest, ListComputationModelResolveToResourcesResponse, ListComputationModelResolveToResourcesError, Credentials | HttpClient.HttpClient, ComputationModelResolveToResourceSummary>;
export type ListComputationModelsError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of summaries of all computation models.
 */
export declare const listComputationModels: API.PaginatedOperationMethod<ListComputationModelsRequest, ListComputationModelsResponse, ListComputationModelsError, Credentials | HttpClient.HttpClient, ComputationModelSummary>;
export type ListDashboardsError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of dashboards for an IoT SiteWise Monitor project.
 */
export declare const listDashboards: API.PaginatedOperationMethod<ListDashboardsRequest, ListDashboardsResponse, ListDashboardsError, Credentials | HttpClient.HttpClient, DashboardSummary>;
export type ListDatasetDataSegmentRelationshipsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of data segment relationships for a session dataset. Use this
 * operation to find the curated datasets that reference data segments of the specified session
 * dataset. Use the `nextToken` parameter to retrieve additional results.
 */
export declare const listDatasetDataSegmentRelationships: API.PaginatedOperationMethod<ListDatasetDataSegmentRelationshipsRequest, ListDatasetDataSegmentRelationshipsResponse, ListDatasetDataSegmentRelationshipsError, Credentials | HttpClient.HttpClient, DataSegmentRelationshipSummary>;
export type ListDatasetDataSegmentsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of data segments associated with a dataset. Use the `nextToken` parameter to retrieve additional results.
 */
export declare const listDatasetDataSegments: API.PaginatedOperationMethod<ListDatasetDataSegmentsRequest, ListDatasetDataSegmentsResponse, ListDatasetDataSegmentsError, Credentials | HttpClient.HttpClient, DataSegmentSummary>;
export type ListDatasetExportJobsError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of dataset export jobs for a workspace.
 */
export declare const listDatasetExportJobs: API.PaginatedOperationMethod<ListDatasetExportJobsRequest, ListDatasetExportJobsResponse, ListDatasetExportJobsError, Credentials | HttpClient.HttpClient, ExportJobSummary>;
export type ListDatasetsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of datasets for a specific target resource.
 */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest, ListDatasetsResponse, ListDatasetsError, Credentials | HttpClient.HttpClient, DatasetSummary>;
export type ListEnrichmentJobsError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists enrichment jobs within a workspace with optional filtering and pagination. Results are ordered
 * by createdAt timestamp descending (newest first).
 *
 * Filtering
 *
 * Combine filters to narrow results:
 *
 * - datasetId: Filter by dataset
 *
 * - propertyAlias OR timeSeriesId: Filter by time series (specify one, not both)
 *
 * - status: Filter by job status (e.g., RUNNING to find active jobs)
 *
 * - jobType: Filter by enrichment type (currently only EVENT_DETECTION)
 *
 * - startDate and endDate: Filter by job creation time range
 *
 * Important Constraints
 *
 * - You must specify either propertyAlias OR timeSeriesId, but not both
 *
 * - Attempting to specify both results in an InvalidRequestException
 *
 * - Date filters use ISO 8601 format
 *
 * - startDate is exclusive, endDate is inclusive
 *
 * Pagination
 *
 * The operation returns up to maxResults jobs per page (default 50). If more results exist, the
 * response includes a nextToken. Submit this token in a subsequent request to retrieve the next page.
 *
 * Common Use Cases
 *
 * - Find all running jobs: Filter by status=RUNNING
 *
 * - List recent jobs for a dataset: Filter by datasetId with optional date range
 *
 * - Monitor jobs for a specific sensor: Filter by propertyAlias or timeSeriesId
 *
 * - Track all event detection jobs: Filter by jobType=EVENT_DETECTION
 *
 * Performance
 *
 * Performance is optimal when filtering by supported fields (datasetId, propertyAlias, timeSeriesId, status, jobType).
 */
export declare const listEnrichmentJobs: API.PaginatedOperationMethod<ListEnrichmentJobsRequest, ListEnrichmentJobsResponse, ListEnrichmentJobsError, Credentials | HttpClient.HttpClient, EnrichmentJobSummary>;
export type ListExecutionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of summaries of all executions.
 */
export declare const listExecutions: API.PaginatedOperationMethod<ListExecutionsRequest, ListExecutionsResponse, ListExecutionsError, Credentials | HttpClient.HttpClient, ExecutionSummary>;
export type ListGatewaysError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of gateways.
 */
export declare const listGateways: API.PaginatedOperationMethod<ListGatewaysRequest, ListGatewaysResponse, ListGatewaysError, Credentials | HttpClient.HttpClient, GatewaySummary>;
export type ListInterfaceRelationshipsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of asset models that have a specific interface asset model
 * applied to them.
 */
export declare const listInterfaceRelationships: API.PaginatedOperationMethod<ListInterfaceRelationshipsRequest, ListInterfaceRelationshipsResponse, ListInterfaceRelationshipsError, Credentials | HttpClient.HttpClient, InterfaceRelationshipSummary>;
export type ListPipelineExecutionsError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists pipeline executions for a specific pipeline in a workspace.
 * Supports filtering by state and time range. State can be combined with either
 * startTime or endTime filters. Time range filters are grouped: use startTime filters
 * (startTimeAfter, startTimeBefore) or endTime filters (endTimeAfter, endTimeBefore),
 * but not both. Combining startTime and endTime filters returns an InvalidRequestException.
 * Note: endTime filters only return executions in terminal states, as in-progress
 * executions have no endTime.
 */
export declare const listPipelineExecutions: API.PaginatedOperationMethod<ListPipelineExecutionsRequest, ListPipelineExecutionsResponse, ListPipelineExecutionsError, Credentials | HttpClient.HttpClient, PipelineExecutionSummary>;
export type ListPipelinesError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists pipelines in a workspace. To get complete details about a pipeline, use DescribePipeline.
 */
export declare const listPipelines: API.PaginatedOperationMethod<ListPipelinesRequest, ListPipelinesResponse, ListPipelinesError, Credentials | HttpClient.HttpClient, PipelineSummary>;
export type ListPortalsError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of IoT SiteWise Monitor portals.
 */
export declare const listPortals: API.PaginatedOperationMethod<ListPortalsRequest, ListPortalsResponse, ListPortalsError, Credentials | HttpClient.HttpClient, PortalSummary>;
export type ListProjectAssetsError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of assets associated with an IoT SiteWise Monitor project.
 */
export declare const listProjectAssets: API.PaginatedOperationMethod<ListProjectAssetsRequest, ListProjectAssetsResponse, ListProjectAssetsError, Credentials | HttpClient.HttpClient, ID>;
export type ListProjectsError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of projects for an IoT SiteWise Monitor portal.
 */
export declare const listProjects: API.PaginatedOperationMethod<ListProjectsRequest, ListProjectsResponse, ListProjectsError, Credentials | HttpClient.HttpClient, ProjectSummary>;
export type ListQueriesError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of queries for a workspace.
 */
export declare const listQueries: API.PaginatedOperationMethod<ListQueriesRequest, ListQueriesResponse, ListQueriesError, Credentials | HttpClient.HttpClient, QuerySummary>;
export type ListSearchesError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the searches in a workspace, most recently started first. Results can be narrowed with
 * optional filters (status, search type, group, and started-at time range) and are paginated: when
 * `nextToken` is present, pass it on a subsequent call to retrieve the next page.
 */
export declare const listSearches: API.PaginatedOperationMethod<ListSearchesRequest, ListSearchesResponse, ListSearchesError, Credentials | HttpClient.HttpClient, SearchSummary>;
export type ListTagsForResourceError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the list of tags for an IoT SiteWise resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTasksError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists tasks in a workspace. To get complete details about a task, use DescribeTask.
 */
export declare const listTasks: API.PaginatedOperationMethod<ListTasksRequest, ListTasksResponse, ListTasksError, Credentials | HttpClient.HttpClient, TaskSummary>;
export type ListTimeSeriesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of time series (data streams).
 */
export declare const listTimeSeries: API.PaginatedOperationMethod<ListTimeSeriesRequest, ListTimeSeriesResponse, ListTimeSeriesError, Credentials | HttpClient.HttpClient, TimeSeriesSummary>;
export type ListWorkspacesError = AccessDeniedException | InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of workspaces. Use the `nextToken` parameter to retrieve additional results.
 */
export declare const listWorkspaces: API.PaginatedOperationMethod<ListWorkspacesRequest, ListWorkspacesResponse, ListWorkspacesError, Credentials | HttpClient.HttpClient, WorkspaceSummary>;
export type PutAssetModelInterfaceRelationshipError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates or updates an interface relationship between an asset model and an interface asset
 * model. This operation applies an interface to an asset model.
 */
export declare const putAssetModelInterfaceRelationship: API.OperationMethod<PutAssetModelInterfaceRelationshipRequest, PutAssetModelInterfaceRelationshipResponse, PutAssetModelInterfaceRelationshipError, Credentials | HttpClient.HttpClient>;
export type PutDefaultEncryptionConfigurationError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Sets the default encryption configuration for the Amazon Web Services account. For more information, see
 * Key management in
 * the *IoT SiteWise User Guide*.
 */
export declare const putDefaultEncryptionConfiguration: API.OperationMethod<PutDefaultEncryptionConfigurationRequest, PutDefaultEncryptionConfigurationResponse, PutDefaultEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutLoggingOptionsError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Sets logging options for IoT SiteWise.
 */
export declare const putLoggingOptions: API.OperationMethod<PutLoggingOptionsRequest, PutLoggingOptionsResponse, PutLoggingOptionsError, Credentials | HttpClient.HttpClient>;
export type PutStorageConfigurationError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Configures storage settings for IoT SiteWise.
 */
export declare const putStorageConfiguration: API.OperationMethod<PutStorageConfigurationRequest, PutStorageConfigurationResponse, PutStorageConfigurationError, Credentials | HttpClient.HttpClient>;
export type StartPipelineExecutionError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts execution of a pipeline in the specified workspace. Each compute node runs
 * according to the DAG dependency order defined in the pipeline. Nodes without
 * dependencies start immediately, while dependent nodes wait for all upstream nodes
 * to complete successfully.
 *
 * You can provide runtime environment variable overrides that take the highest priority
 * in the environment variable hierarchy, without modifying the pipeline definition.
 */
export declare const startPipelineExecution: API.OperationMethod<StartPipelineExecutionRequest, StartPipelineExecutionResponse, StartPipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type StartQueryError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts an asynchronous SQL query against workspace telemetry, annotations, data segment, and dataset data.
 */
export declare const startQuery: API.OperationMethod<StartQueryRequest, StartQueryResponse, StartQueryError, Credentials | HttpClient.HttpClient>;
export type StartSearchError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts an asynchronous search over the data in a workspace. The search runs in the background;
 * the response returns immediately with a `searchId` and an initial status of `QUEUED`. Use
 * `DescribeSearch` to poll for completion and `GetSearchResults` to retrieve the results once the
 * search reaches `SUCCEEDED`. The request is idempotent on `clientToken`: repeating a call with the
 * same token returns the original search instead of starting a new one.
 */
export declare const startSearch: API.OperationMethod<StartSearchRequest, StartSearchResponse, StartSearchError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | TooManyTagsException | UnauthorizedException | CommonErrors;
/**
 * Adds tags to an IoT SiteWise resource. If a tag already exists for the resource, this operation
 * updates the tag's value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Removes a tag from an IoT SiteWise resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccessPolicyError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Updates an existing access policy that specifies an identity's access to an IoT SiteWise Monitor
 * portal or project resource.
 */
export declare const updateAccessPolicy: API.OperationMethod<UpdateAccessPolicyRequest, UpdateAccessPolicyResponse, UpdateAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an asset's name. For more information, see Updating assets and models in the
 * *IoT SiteWise User Guide*.
 */
export declare const updateAsset: API.OperationMethod<UpdateAssetRequest, UpdateAssetResponse, UpdateAssetError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | PreconditionFailedException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an asset model and all of the assets that were created from the model. Each asset
 * created from the model inherits the updated asset model's property and hierarchy definitions.
 * For more information, see Updating assets and models in the
 * *IoT SiteWise User Guide*.
 *
 * If you remove a property from an asset model, IoT SiteWise deletes all previous data for that
 * property. You can’t change the type or data type of an existing property.
 *
 * To replace an existing asset model property with a new one with the same
 * `name`, do the following:
 *
 * - Submit an `UpdateAssetModel` request with the entire existing property
 * removed.
 *
 * - Submit a second `UpdateAssetModel` request that includes the new
 * property. The new asset property will have the same `name` as the previous
 * one and IoT SiteWise will generate a new unique `id`.
 */
export declare const updateAssetModel: API.OperationMethod<UpdateAssetModelRequest, UpdateAssetModelResponse, UpdateAssetModelError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetModelCompositeModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | PreconditionFailedException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a composite model and all of the assets that were created from the model. Each
 * asset created from the model inherits the updated asset model's property and hierarchy
 * definitions. For more information, see Updating assets and models in the
 * *IoT SiteWise User Guide*.
 *
 * If you remove a property from a composite asset model, IoT SiteWise deletes all previous data
 * for that property. You can’t change the type or data type of an existing property.
 *
 * To replace an existing composite asset model property with a new one with the same
 * `name`, do the following:
 *
 * - Submit an `UpdateAssetModelCompositeModel` request with the entire
 * existing property removed.
 *
 * - Submit a second `UpdateAssetModelCompositeModel` request that includes
 * the new property. The new asset property will have the same `name` as the
 * previous one and IoT SiteWise will generate a new unique `id`.
 */
export declare const updateAssetModelCompositeModel: API.OperationMethod<UpdateAssetModelCompositeModelRequest, UpdateAssetModelCompositeModelResponse, UpdateAssetModelCompositeModelError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetPropertyError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an asset property's alias and notification state.
 *
 * This operation overwrites the property's existing alias and notification state. To keep
 * your existing property's alias or notification state, you must include the existing values
 * in the UpdateAssetProperty request. For more information, see DescribeAssetProperty.
 */
export declare const updateAssetProperty: API.OperationMethod<UpdateAssetPropertyRequest, UpdateAssetPropertyResponse, UpdateAssetPropertyError, Credentials | HttpClient.HttpClient>;
export type UpdateComputationModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the computation model.
 */
export declare const updateComputationModel: API.OperationMethod<UpdateComputationModelRequest, UpdateComputationModelResponse, UpdateComputationModelError, Credentials | HttpClient.HttpClient>;
export type UpdateDashboardError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Updates an IoT SiteWise Monitor dashboard.
 */
export declare const updateDashboard: API.OperationMethod<UpdateDashboardRequest, UpdateDashboardResponse, UpdateDashboardError, Credentials | HttpClient.HttpClient>;
export type UpdateDatasetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a dataset.
 */
export declare const updateDataset: API.OperationMethod<UpdateDatasetRequest, UpdateDatasetResponse, UpdateDatasetError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a gateway's name.
 */
export declare const updateGateway: API.OperationMethod<UpdateGatewayRequest, UpdateGatewayResponse, UpdateGatewayError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayCapabilityConfigurationError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a gateway capability configuration or defines a new capability configuration. Each gateway capability defines data sources for a gateway.
 *
 * Important workflow notes:
 *
 * Each gateway capability defines data sources for a gateway. This is the namespace of the gateway capability.
 *
 * . The namespace follows the format `service:capability:version`, where:
 *
 * - `service` - The service providing the capability, or `iotsitewise`.
 *
 * - `capability` - The specific capability type. Options include: `opcuacollector` for the OPC UA data source collector, or `publisher` for data publisher capability.
 *
 * - `version` - The version number of the capability. Option include `2` for Classic streams, V2 gateways, and `3` for MQTT-enabled, V3 gateways.
 *
 * After updating a capability configuration, the sync status becomes `OUT_OF_SYNC` until the gateway processes the configuration.Use `DescribeGatewayCapabilityConfiguration` to check the sync status and verify the configuration was applied.
 *
 * A gateway can have multiple capability configurations with different namespaces.
 */
export declare const updateGatewayCapabilityConfiguration: API.OperationMethod<UpdateGatewayCapabilityConfigurationRequest, UpdateGatewayCapabilityConfigurationResponse, UpdateGatewayCapabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdatePipelineError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an existing pipeline in the specified workspace. Only the fields
 * provided in the request are updated; fields not included in the request are preserved
 * unchanged. You can update the pipeline description, environment variables, and the
 * list of compute nodes independently.
 */
export declare const updatePipeline: API.OperationMethod<UpdatePipelineRequest, UpdatePipelineResponse, UpdatePipelineError, Credentials | HttpClient.HttpClient>;
export type UpdatePortalError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Updates an IoT SiteWise Monitor portal.
 */
export declare const updatePortal: API.OperationMethod<UpdatePortalRequest, UpdatePortalResponse, UpdatePortalError, Credentials | HttpClient.HttpClient>;
export type UpdateProjectError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Updates an IoT SiteWise Monitor project.
 */
export declare const updateProject: API.OperationMethod<UpdateProjectRequest, UpdateProjectResponse, UpdateProjectError, Credentials | HttpClient.HttpClient>;
export type UpdateTaskError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an existing task in the specified workspace. Only the fields
 * provided in the request are updated; fields not included in the request are preserved
 * unchanged.
 */
export declare const updateTask: API.OperationMethod<UpdateTaskRequest, UpdateTaskResponse, UpdateTaskError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkspaceError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a workspace. You can update only workspaces in the `ACTIVE` or
 * `FAILED` state. Fields that you omit from the request are left unchanged. To
 * recover a workspace in the `FAILED` state, call this operation and supply its
 * encryption configuration again.
 */
export declare const updateWorkspace: API.OperationMethod<UpdateWorkspaceRequest, UpdateWorkspaceResponse, UpdateWorkspaceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iotsitewise.d.ts.map