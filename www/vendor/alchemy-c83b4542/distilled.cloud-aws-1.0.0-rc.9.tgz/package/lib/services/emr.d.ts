import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials as Creds } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ClusterNotFound_base: S.Class<ClusterNotFound, S.TaggedStruct<"ClusterNotFound", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ClusterNotFound extends /*@__PURE__*/ ClusterNotFound_base {
}
declare const InternalServerError_base: S.Class<InternalServerError, S.TaggedStruct<"InternalServerError", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const JobFlowNotFound_base: S.Class<JobFlowNotFound, S.TaggedStruct<"JobFlowNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class JobFlowNotFound extends /*@__PURE__*/ JobFlowNotFound_base {
}
declare const SecurityConfigurationAlreadyExists_base: S.Class<SecurityConfigurationAlreadyExists, S.TaggedStruct<"SecurityConfigurationAlreadyExists", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class SecurityConfigurationAlreadyExists extends /*@__PURE__*/ SecurityConfigurationAlreadyExists_base {
}
declare const SecurityConfigurationNotFound_base: S.Class<SecurityConfigurationNotFound, S.TaggedStruct<"SecurityConfigurationNotFound", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class SecurityConfigurationNotFound extends /*@__PURE__*/ SecurityConfigurationNotFound_base {
}
declare const StudioNotFound_base: S.Class<StudioNotFound, S.TaggedStruct<"StudioNotFound", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class StudioNotFound extends /*@__PURE__*/ StudioNotFound_base {
}
declare const StudioServiceRoleMissingS3Access_base: S.Class<StudioServiceRoleMissingS3Access, S.TaggedStruct<"StudioServiceRoleMissingS3Access", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class StudioServiceRoleMissingS3Access extends /*@__PURE__*/ StudioServiceRoleMissingS3Access_base {
}
declare const StudioServiceRoleNotAssumable_base: S.Class<StudioServiceRoleNotAssumable, S.TaggedStruct<"StudioServiceRoleNotAssumable", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class StudioServiceRoleNotAssumable extends /*@__PURE__*/ StudioServiceRoleNotAssumable_base {
}
export type XmlStringMaxLen256 = string;
export type InstanceFleetType = "MASTER" | "CORE" | "TASK" | (string & {});
export declare const InstanceFleetType: any;
export type WholeNumber = number;
export type InstanceType = string;
export type NonNegativeDouble = number;
export type ThroughputVal = number;
export interface VolumeSpecification {
    VolumeType?: string;
    Iops?: number;
    SizeInGB?: number;
    Throughput?: number;
}
export declare const VolumeSpecification: S.Schema<VolumeSpecification>;
export interface EbsBlockDeviceConfig {
    VolumeSpecification?: VolumeSpecification;
    VolumesPerInstance?: number;
}
export declare const EbsBlockDeviceConfig: S.Schema<EbsBlockDeviceConfig>;
export type EbsBlockDeviceConfigList = EbsBlockDeviceConfig[];
export declare const EbsBlockDeviceConfigList: any;
export interface EbsConfiguration {
    EbsBlockDeviceConfigs?: EbsBlockDeviceConfig[];
    EbsOptimized?: boolean;
}
export declare const EbsConfiguration: S.Schema<EbsConfiguration>;
export type StringMap = {
    [key: string]: string | undefined;
};
export declare const StringMap: any;
export interface Configuration {
    Classification?: string;
    Configurations?: Configuration[];
    Properties?: {
        [key: string]: string | undefined;
    };
}
export declare const Configuration: S.Schema<Configuration>;
export type ConfigurationList = Configuration[];
export declare const ConfigurationList: S.Schema<ConfigurationList>;
export interface InstanceTypeConfig {
    InstanceType?: string;
    WeightedCapacity?: number;
    BidPrice?: string;
    BidPriceAsPercentageOfOnDemandPrice?: number;
    EbsConfiguration?: EbsConfiguration;
    Configurations?: Configuration[];
    CustomAmiId?: string;
    Priority?: number;
}
export declare const InstanceTypeConfig: S.Schema<InstanceTypeConfig>;
export type InstanceTypeConfigList = InstanceTypeConfig[];
export declare const InstanceTypeConfigList: any;
export type SpotProvisioningTimeoutAction = "SWITCH_TO_ON_DEMAND" | "TERMINATE_CLUSTER" | (string & {});
export declare const SpotProvisioningTimeoutAction: any;
export type SpotProvisioningAllocationStrategy = "capacity-optimized" | "price-capacity-optimized" | "lowest-price" | "diversified" | "capacity-optimized-prioritized" | (string & {});
export declare const SpotProvisioningAllocationStrategy: any;
export interface SpotProvisioningSpecification {
    TimeoutDurationMinutes?: number;
    TimeoutAction?: SpotProvisioningTimeoutAction;
    BlockDurationMinutes?: number;
    AllocationStrategy?: SpotProvisioningAllocationStrategy;
}
export declare const SpotProvisioningSpecification: S.Schema<SpotProvisioningSpecification>;
export type OnDemandProvisioningAllocationStrategy = "lowest-price" | "prioritized" | (string & {});
export declare const OnDemandProvisioningAllocationStrategy: any;
export type OnDemandCapacityReservationUsageStrategy = "use-capacity-reservations-first" | (string & {});
export declare const OnDemandCapacityReservationUsageStrategy: any;
export type OnDemandCapacityReservationPreference = "open" | "none" | (string & {});
export declare const OnDemandCapacityReservationPreference: any;
export interface OnDemandCapacityReservationOptions {
    UsageStrategy?: OnDemandCapacityReservationUsageStrategy;
    CapacityReservationPreference?: OnDemandCapacityReservationPreference;
    CapacityReservationResourceGroupArn?: string;
}
export declare const OnDemandCapacityReservationOptions: S.Schema<OnDemandCapacityReservationOptions>;
export interface OnDemandProvisioningSpecification {
    AllocationStrategy?: OnDemandProvisioningAllocationStrategy;
    CapacityReservationOptions?: OnDemandCapacityReservationOptions;
}
export declare const OnDemandProvisioningSpecification: S.Schema<OnDemandProvisioningSpecification>;
export interface InstanceFleetProvisioningSpecifications {
    SpotSpecification?: SpotProvisioningSpecification;
    OnDemandSpecification?: OnDemandProvisioningSpecification;
}
export declare const InstanceFleetProvisioningSpecifications: S.Schema<InstanceFleetProvisioningSpecifications>;
export interface SpotResizingSpecification {
    TimeoutDurationMinutes?: number;
    AllocationStrategy?: SpotProvisioningAllocationStrategy;
}
export declare const SpotResizingSpecification: S.Schema<SpotResizingSpecification>;
export interface OnDemandResizingSpecification {
    TimeoutDurationMinutes?: number;
    AllocationStrategy?: OnDemandProvisioningAllocationStrategy;
    CapacityReservationOptions?: OnDemandCapacityReservationOptions;
}
export declare const OnDemandResizingSpecification: S.Schema<OnDemandResizingSpecification>;
export interface InstanceFleetResizingSpecifications {
    SpotResizeSpecification?: SpotResizingSpecification;
    OnDemandResizeSpecification?: OnDemandResizingSpecification;
}
export declare const InstanceFleetResizingSpecifications: S.Schema<InstanceFleetResizingSpecifications>;
export interface InstanceFleetConfig {
    Name?: string;
    InstanceFleetType?: InstanceFleetType;
    TargetOnDemandCapacity?: number;
    TargetSpotCapacity?: number;
    InstanceTypeConfigs?: InstanceTypeConfig[];
    LaunchSpecifications?: InstanceFleetProvisioningSpecifications;
    ResizeSpecifications?: InstanceFleetResizingSpecifications;
    Context?: string;
}
export declare const InstanceFleetConfig: S.Schema<InstanceFleetConfig>;
export interface AddInstanceFleetInput {
    ClusterId?: string;
    InstanceFleet?: InstanceFleetConfig;
}
export declare const AddInstanceFleetInput: S.Schema<AddInstanceFleetInput>;
export type InstanceFleetId = string;
export type ArnType = string;
export interface AddInstanceFleetOutput {
    ClusterId?: string;
    InstanceFleetId?: string;
    ClusterArn?: string;
}
export declare const AddInstanceFleetOutput: S.Schema<AddInstanceFleetOutput>;
export type MarketType = "ON_DEMAND" | "SPOT" | (string & {});
export declare const MarketType: any;
export type InstanceRoleType = "MASTER" | "CORE" | "TASK" | (string & {});
export declare const InstanceRoleType: any;
export interface ScalingConstraints {
    MinCapacity?: number;
    MaxCapacity?: number;
}
export declare const ScalingConstraints: S.Schema<ScalingConstraints>;
export type AdjustmentType = "CHANGE_IN_CAPACITY" | "PERCENT_CHANGE_IN_CAPACITY" | "EXACT_CAPACITY" | (string & {});
export declare const AdjustmentType: any;
export interface SimpleScalingPolicyConfiguration {
    AdjustmentType?: AdjustmentType;
    ScalingAdjustment?: number;
    CoolDown?: number;
}
export declare const SimpleScalingPolicyConfiguration: S.Schema<SimpleScalingPolicyConfiguration>;
export interface ScalingAction {
    Market?: MarketType;
    SimpleScalingPolicyConfiguration?: SimpleScalingPolicyConfiguration;
}
export declare const ScalingAction: S.Schema<ScalingAction>;
export type ComparisonOperator = "GREATER_THAN_OR_EQUAL" | "GREATER_THAN" | "LESS_THAN" | "LESS_THAN_OR_EQUAL" | (string & {});
export declare const ComparisonOperator: any;
export type Statistic = "SAMPLE_COUNT" | "AVERAGE" | "SUM" | "MINIMUM" | "MAXIMUM" | (string & {});
export declare const Statistic: any;
export type Unit = "NONE" | "SECONDS" | "MICRO_SECONDS" | "MILLI_SECONDS" | "BYTES" | "KILO_BYTES" | "MEGA_BYTES" | "GIGA_BYTES" | "TERA_BYTES" | "BITS" | "KILO_BITS" | "MEGA_BITS" | "GIGA_BITS" | "TERA_BITS" | "PERCENT" | "COUNT" | "BYTES_PER_SECOND" | "KILO_BYTES_PER_SECOND" | "MEGA_BYTES_PER_SECOND" | "GIGA_BYTES_PER_SECOND" | "TERA_BYTES_PER_SECOND" | "BITS_PER_SECOND" | "KILO_BITS_PER_SECOND" | "MEGA_BITS_PER_SECOND" | "GIGA_BITS_PER_SECOND" | "TERA_BITS_PER_SECOND" | "COUNT_PER_SECOND" | (string & {});
export declare const Unit: any;
export interface MetricDimension {
    Key?: string;
    Value?: string;
}
export declare const MetricDimension: S.Schema<MetricDimension>;
export type MetricDimensionList = MetricDimension[];
export declare const MetricDimensionList: any;
export interface CloudWatchAlarmDefinition {
    ComparisonOperator?: ComparisonOperator;
    EvaluationPeriods?: number;
    MetricName?: string;
    Namespace?: string;
    Period?: number;
    Statistic?: Statistic;
    Threshold?: number;
    Unit?: Unit;
    Dimensions?: MetricDimension[];
}
export declare const CloudWatchAlarmDefinition: S.Schema<CloudWatchAlarmDefinition>;
export interface ScalingTrigger {
    CloudWatchAlarmDefinition?: CloudWatchAlarmDefinition;
}
export declare const ScalingTrigger: S.Schema<ScalingTrigger>;
export interface ScalingRule {
    Name?: string;
    Description?: string;
    Action?: ScalingAction;
    Trigger?: ScalingTrigger;
}
export declare const ScalingRule: S.Schema<ScalingRule>;
export type ScalingRuleList = ScalingRule[];
export declare const ScalingRuleList: any;
export interface AutoScalingPolicy {
    Constraints?: ScalingConstraints;
    Rules?: ScalingRule[];
}
export declare const AutoScalingPolicy: S.Schema<AutoScalingPolicy>;
export interface InstanceGroupConfig {
    Name?: string;
    Market?: MarketType;
    InstanceRole?: InstanceRoleType;
    BidPrice?: string;
    InstanceType?: string;
    InstanceCount?: number;
    Configurations?: Configuration[];
    EbsConfiguration?: EbsConfiguration;
    AutoScalingPolicy?: AutoScalingPolicy;
    CustomAmiId?: string;
}
export declare const InstanceGroupConfig: S.Schema<InstanceGroupConfig>;
export type InstanceGroupConfigList = InstanceGroupConfig[];
export declare const InstanceGroupConfigList: any;
export interface AddInstanceGroupsInput {
    InstanceGroups?: InstanceGroupConfig[];
    JobFlowId?: string;
}
export declare const AddInstanceGroupsInput: S.Schema<AddInstanceGroupsInput>;
export type InstanceGroupIdsList = string[];
export declare const InstanceGroupIdsList: any;
export interface AddInstanceGroupsOutput {
    JobFlowId?: string;
    InstanceGroupIds?: string[];
    ClusterArn?: string;
}
export declare const AddInstanceGroupsOutput: S.Schema<AddInstanceGroupsOutput>;
export type ActionOnFailure = "TERMINATE_JOB_FLOW" | "TERMINATE_CLUSTER" | "CANCEL_AND_WAIT" | "CONTINUE" | (string & {});
export declare const ActionOnFailure: any;
export type XmlString = string;
export interface KeyValue {
    Key?: string;
    Value?: string;
}
export declare const KeyValue: S.Schema<KeyValue>;
export type KeyValueList = KeyValue[];
export declare const KeyValueList: any;
export type XmlStringList = string[];
export declare const XmlStringList: any;
export interface HadoopJarStepConfig {
    Properties?: KeyValue[];
    Jar?: string;
    MainClass?: string;
    Args?: string[];
}
export declare const HadoopJarStepConfig: S.Schema<HadoopJarStepConfig>;
export interface S3MonitoringConfiguration {
    LogUri?: string;
    EncryptionKeyArn?: string;
}
export declare const S3MonitoringConfiguration: S.Schema<S3MonitoringConfiguration>;
export interface StepMonitoringConfiguration {
    S3MonitoringConfiguration?: S3MonitoringConfiguration;
}
export declare const StepMonitoringConfiguration: S.Schema<StepMonitoringConfiguration>;
export interface StepConfig {
    Name?: string;
    ActionOnFailure?: ActionOnFailure;
    HadoopJarStep?: HadoopJarStepConfig;
    StepMonitoringConfiguration?: StepMonitoringConfiguration;
}
export declare const StepConfig: S.Schema<StepConfig>;
export type StepConfigList = StepConfig[];
export declare const StepConfigList: any;
export interface AddJobFlowStepsInput {
    JobFlowId?: string;
    Steps?: StepConfig[];
    ExecutionRoleArn?: string;
}
export declare const AddJobFlowStepsInput: S.Schema<AddJobFlowStepsInput>;
export type StepIdsList = string[];
export declare const StepIdsList: any;
export interface AddJobFlowStepsOutput {
    StepIds?: string[];
}
export declare const AddJobFlowStepsOutput: S.Schema<AddJobFlowStepsOutput>;
export type ResourceId = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type ClusterId = string;
export interface AddTagsInput {
    ResourceId?: string;
    Tags?: Tag[];
    ClusterId?: string;
}
export declare const AddTagsInput: S.Schema<AddTagsInput>;
export interface AddTagsOutput {
}
export declare const AddTagsOutput: S.Schema<AddTagsOutput>;
export type StepCancellationOption = "SEND_INTERRUPT" | "TERMINATE_PROCESS" | (string & {});
export declare const StepCancellationOption: any;
export interface CancelStepsInput {
    ClusterId?: string;
    StepIds?: string[];
    StepCancellationOption?: StepCancellationOption;
}
export declare const CancelStepsInput: S.Schema<CancelStepsInput>;
export type StepId = string;
export type CancelStepsRequestStatus = "SUBMITTED" | "FAILED" | (string & {});
export declare const CancelStepsRequestStatus: any;
export interface CancelStepsInfo {
    StepId?: string;
    Status?: CancelStepsRequestStatus;
    Reason?: string;
}
export declare const CancelStepsInfo: S.Schema<CancelStepsInfo>;
export type CancelStepsInfoList = CancelStepsInfo[];
export declare const CancelStepsInfoList: any;
export interface CancelStepsOutput {
    CancelStepsInfoList?: CancelStepsInfo[];
}
export declare const CancelStepsOutput: S.Schema<CancelStepsOutput>;
export interface EMRContainersConfig {
    JobRunId?: string;
}
export declare const EMRContainersConfig: S.Schema<EMRContainersConfig>;
export type ProfilerType = "SHS" | "TEZUI" | "YTS" | (string & {});
export declare const ProfilerType: any;
export interface CreatePersistentAppUIInput {
    TargetResourceArn?: string;
    EMRContainersConfig?: EMRContainersConfig;
    Tags?: Tag[];
    XReferer?: string;
    ProfilerType?: ProfilerType;
}
export declare const CreatePersistentAppUIInput: S.Schema<CreatePersistentAppUIInput>;
export interface CreatePersistentAppUIOutput {
    PersistentAppUIId?: string;
    RuntimeRoleEnabledCluster?: boolean;
}
export declare const CreatePersistentAppUIOutput: S.Schema<CreatePersistentAppUIOutput>;
export interface CreateSecurityConfigurationInput {
    Name?: string;
    SecurityConfiguration?: string;
}
export declare const CreateSecurityConfigurationInput: S.Schema<CreateSecurityConfigurationInput>;
export interface CreateSecurityConfigurationOutput {
    Name: string;
    CreationDateTime: Date;
}
export declare const CreateSecurityConfigurationOutput: S.Schema<CreateSecurityConfigurationOutput>;
export type AuthMode = "SSO" | "IAM" | (string & {});
export declare const AuthMode: any;
export type SubnetIdList = string[];
export declare const SubnetIdList: any;
export type IdcUserAssignment = "REQUIRED" | "OPTIONAL" | (string & {});
export declare const IdcUserAssignment: any;
export interface CreateStudioInput {
    Name?: string;
    Description?: string;
    AuthMode?: AuthMode;
    VpcId?: string;
    SubnetIds?: string[];
    ServiceRole?: string;
    UserRole?: string;
    WorkspaceSecurityGroupId?: string;
    EngineSecurityGroupId?: string;
    DefaultS3Location?: string;
    IdpAuthUrl?: string;
    IdpRelayStateParameterName?: string;
    Tags?: Tag[];
    TrustedIdentityPropagationEnabled?: boolean;
    IdcUserAssignment?: IdcUserAssignment;
    IdcInstanceArn?: string;
    EncryptionKeyArn?: string;
}
export declare const CreateStudioInput: S.Schema<CreateStudioInput>;
export interface CreateStudioOutput {
    StudioId?: string;
    Url?: string;
}
export declare const CreateStudioOutput: S.Schema<CreateStudioOutput>;
export type IdentityType = "USER" | "GROUP" | (string & {});
export declare const IdentityType: any;
export interface CreateStudioSessionMappingInput {
    StudioId?: string;
    IdentityId?: string;
    IdentityName?: string;
    IdentityType?: IdentityType;
    SessionPolicyArn?: string;
}
export declare const CreateStudioSessionMappingInput: S.Schema<CreateStudioSessionMappingInput>;
export interface CreateStudioSessionMappingResponse {
}
export declare const CreateStudioSessionMappingResponse: S.Schema<CreateStudioSessionMappingResponse>;
export interface DeleteSecurityConfigurationInput {
    Name?: string;
}
export declare const DeleteSecurityConfigurationInput: S.Schema<DeleteSecurityConfigurationInput>;
export interface DeleteSecurityConfigurationOutput {
}
export declare const DeleteSecurityConfigurationOutput: S.Schema<DeleteSecurityConfigurationOutput>;
export interface DeleteStudioInput {
    StudioId?: string;
}
export declare const DeleteStudioInput: S.Schema<DeleteStudioInput>;
export interface DeleteStudioResponse {
}
export declare const DeleteStudioResponse: S.Schema<DeleteStudioResponse>;
export interface DeleteStudioSessionMappingInput {
    StudioId?: string;
    IdentityId?: string;
    IdentityName?: string;
    IdentityType?: IdentityType;
}
export declare const DeleteStudioSessionMappingInput: S.Schema<DeleteStudioSessionMappingInput>;
export interface DeleteStudioSessionMappingResponse {
}
export declare const DeleteStudioSessionMappingResponse: S.Schema<DeleteStudioSessionMappingResponse>;
export interface DescribeClusterInput {
    ClusterId?: string;
}
export declare const DescribeClusterInput: S.Schema<DescribeClusterInput>;
export type ClusterState = "STARTING" | "BOOTSTRAPPING" | "RUNNING" | "WAITING" | "TERMINATING" | "TERMINATED" | "TERMINATED_WITH_ERRORS" | (string & {});
export declare const ClusterState: any;
export type ClusterStateChangeReasonCode = "INTERNAL_ERROR" | "VALIDATION_ERROR" | "INSTANCE_FAILURE" | "INSTANCE_FLEET_TIMEOUT" | "BOOTSTRAP_FAILURE" | "USER_REQUEST" | "STEP_FAILURE" | "ALL_STEPS_COMPLETED" | (string & {});
export declare const ClusterStateChangeReasonCode: any;
export interface ClusterStateChangeReason {
    Code?: ClusterStateChangeReasonCode;
    Message?: string;
}
export declare const ClusterStateChangeReason: S.Schema<ClusterStateChangeReason>;
export interface ClusterTimeline {
    CreationDateTime?: Date;
    ReadyDateTime?: Date;
    EndDateTime?: Date;
}
export declare const ClusterTimeline: S.Schema<ClusterTimeline>;
export type ErrorData = {
    [key: string]: string | undefined;
}[];
export declare const ErrorData: any;
export interface ErrorDetail {
    ErrorCode?: string;
    ErrorData?: {
        [key: string]: string | undefined;
    }[];
    ErrorMessage?: string;
}
export declare const ErrorDetail: S.Schema<ErrorDetail>;
export type ErrorDetailList = ErrorDetail[];
export declare const ErrorDetailList: any;
export interface ClusterStatus {
    State?: ClusterState;
    StateChangeReason?: ClusterStateChangeReason;
    Timeline?: ClusterTimeline;
    ErrorDetails?: ErrorDetail[];
}
export declare const ClusterStatus: S.Schema<ClusterStatus>;
export type XmlStringMaxLen256List = string[];
export declare const XmlStringMaxLen256List: any;
export type StringList = string[];
export declare const StringList: any;
export interface Ec2InstanceAttributes {
    Ec2KeyName?: string;
    Ec2SubnetId?: string;
    RequestedEc2SubnetIds?: string[];
    Ec2AvailabilityZone?: string;
    RequestedEc2AvailabilityZones?: string[];
    IamInstanceProfile?: string;
    EmrManagedMasterSecurityGroup?: string;
    EmrManagedSlaveSecurityGroup?: string;
    ServiceAccessSecurityGroup?: string;
    AdditionalMasterSecurityGroups?: string[];
    AdditionalSlaveSecurityGroups?: string[];
}
export declare const Ec2InstanceAttributes: S.Schema<Ec2InstanceAttributes>;
export type InstanceCollectionType = "INSTANCE_FLEET" | "INSTANCE_GROUP" | (string & {});
export declare const InstanceCollectionType: any;
export interface Application {
    Name?: string;
    Version?: string;
    Args?: string[];
    AdditionalInfo?: {
        [key: string]: string | undefined;
    };
}
export declare const Application: S.Schema<Application>;
export type ApplicationList = Application[];
export declare const ApplicationList: any;
export type ScaleDownBehavior = "TERMINATE_AT_INSTANCE_HOUR" | "TERMINATE_AT_TASK_COMPLETION" | (string & {});
export declare const ScaleDownBehavior: any;
export type RepoUpgradeOnBoot = "SECURITY" | "NONE" | (string & {});
export declare const RepoUpgradeOnBoot: any;
export interface KerberosAttributes {
    Realm?: string;
    KdcAdminPassword?: string | redacted.Redacted<string>;
    CrossRealmTrustPrincipalPassword?: string | redacted.Redacted<string>;
    ADDomainJoinUser?: string;
    ADDomainJoinPassword?: string | redacted.Redacted<string>;
}
export declare const KerberosAttributes: S.Schema<KerberosAttributes>;
export type OptionalArnType = string;
export type PlacementGroupStrategy = "SPREAD" | "PARTITION" | "CLUSTER" | "NONE" | (string & {});
export declare const PlacementGroupStrategy: any;
export interface PlacementGroupConfig {
    InstanceRole?: InstanceRoleType;
    PlacementStrategy?: PlacementGroupStrategy;
}
export declare const PlacementGroupConfig: S.Schema<PlacementGroupConfig>;
export type PlacementGroupConfigList = PlacementGroupConfig[];
export declare const PlacementGroupConfigList: any;
export type LogTypesMap = {
    [key: string]: string[] | undefined;
};
export declare const LogTypesMap: any;
export interface CloudWatchLogConfiguration {
    Enabled?: boolean;
    LogGroupName?: string;
    LogStreamNamePrefix?: string;
    EncryptionKeyArn?: string;
    LogTypes?: {
        [key: string]: string[] | undefined;
    };
}
export declare const CloudWatchLogConfiguration: S.Schema<CloudWatchLogConfiguration>;
export type LogType = "system-logs" | "application-logs" | "persistent-ui-logs" | (string & {});
export declare const LogType: any;
export type LogUploadPolicyValue = "emr-managed" | "on-customer-s3only" | "disabled" | (string & {});
export declare const LogUploadPolicyValue: any;
export type LogTypeMap = {
    [key in LogType]?: LogUploadPolicyValue;
};
export declare const LogTypeMap: any;
export interface S3LoggingConfiguration {
    LogTypeUploadPolicy?: {
        [key: string]: LogUploadPolicyValue | undefined;
    };
}
export declare const S3LoggingConfiguration: S.Schema<S3LoggingConfiguration>;
export interface MonitoringConfiguration {
    CloudWatchLogConfiguration?: CloudWatchLogConfiguration;
    S3LoggingConfiguration?: S3LoggingConfiguration;
}
export declare const MonitoringConfiguration: S.Schema<MonitoringConfiguration>;
export interface Cluster {
    Id?: string;
    Name?: string;
    Status?: ClusterStatus;
    Ec2InstanceAttributes?: Ec2InstanceAttributes;
    InstanceCollectionType?: InstanceCollectionType;
    LogUri?: string;
    LogEncryptionKmsKeyId?: string;
    RequestedAmiVersion?: string;
    RunningAmiVersion?: string;
    ReleaseLabel?: string;
    AutoTerminate?: boolean;
    TerminationProtected?: boolean;
    UnhealthyNodeReplacement?: boolean;
    VisibleToAllUsers?: boolean;
    Applications?: Application[];
    Tags?: Tag[];
    ServiceRole?: string;
    NormalizedInstanceHours?: number;
    MasterPublicDnsName?: string;
    Configurations?: Configuration[];
    SecurityConfiguration?: string;
    AutoScalingRole?: string;
    ScaleDownBehavior?: ScaleDownBehavior;
    CustomAmiId?: string;
    EbsRootVolumeSize?: number;
    RepoUpgradeOnBoot?: RepoUpgradeOnBoot;
    KerberosAttributes?: KerberosAttributes;
    ClusterArn?: string;
    OutpostArn?: string;
    StepConcurrencyLevel?: number;
    PlacementGroups?: PlacementGroupConfig[];
    OSReleaseLabel?: string;
    EbsRootVolumeIops?: number;
    EbsRootVolumeThroughput?: number;
    ExtendedSupport?: boolean;
    MonitoringConfiguration?: MonitoringConfiguration;
    SessionEnabled?: boolean;
}
export declare const Cluster: S.Schema<Cluster>;
export interface DescribeClusterOutput {
    Cluster?: Cluster & {
        KerberosAttributes: KerberosAttributes & {
            Realm: XmlStringMaxLen256;
            KdcAdminPassword: XmlStringMaxLen256;
        };
        PlacementGroups: (PlacementGroupConfig & {
            InstanceRole: InstanceRoleType;
        })[];
        MonitoringConfiguration: MonitoringConfiguration & {
            CloudWatchLogConfiguration: CloudWatchLogConfiguration & {
                Enabled: boolean;
            };
        };
    };
}
export declare const DescribeClusterOutput: S.Schema<DescribeClusterOutput>;
export type JobFlowExecutionState = "STARTING" | "BOOTSTRAPPING" | "RUNNING" | "WAITING" | "SHUTTING_DOWN" | "TERMINATED" | "COMPLETED" | "FAILED" | (string & {});
export declare const JobFlowExecutionState: any;
export type JobFlowExecutionStateList = JobFlowExecutionState[];
export declare const JobFlowExecutionStateList: any;
export interface DescribeJobFlowsInput {
    CreatedAfter?: Date;
    CreatedBefore?: Date;
    JobFlowIds?: string[];
    JobFlowStates?: JobFlowExecutionState[];
}
export declare const DescribeJobFlowsInput: S.Schema<DescribeJobFlowsInput>;
export interface JobFlowExecutionStatusDetail {
    State?: JobFlowExecutionState;
    CreationDateTime?: Date;
    StartDateTime?: Date;
    ReadyDateTime?: Date;
    EndDateTime?: Date;
    LastStateChangeReason?: string;
}
export declare const JobFlowExecutionStatusDetail: S.Schema<JobFlowExecutionStatusDetail>;
export type InstanceGroupState = "PROVISIONING" | "BOOTSTRAPPING" | "RUNNING" | "RECONFIGURING" | "RESIZING" | "SUSPENDED" | "TERMINATING" | "TERMINATED" | "ARRESTED" | "SHUTTING_DOWN" | "ENDED" | (string & {});
export declare const InstanceGroupState: any;
export interface InstanceGroupDetail {
    InstanceGroupId?: string;
    Name?: string;
    Market?: MarketType;
    InstanceRole?: InstanceRoleType;
    BidPrice?: string;
    InstanceType?: string;
    InstanceRequestCount?: number;
    InstanceRunningCount?: number;
    State?: InstanceGroupState;
    LastStateChangeReason?: string;
    CreationDateTime?: Date;
    StartDateTime?: Date;
    ReadyDateTime?: Date;
    EndDateTime?: Date;
    CustomAmiId?: string;
}
export declare const InstanceGroupDetail: S.Schema<InstanceGroupDetail>;
export type InstanceGroupDetailList = InstanceGroupDetail[];
export declare const InstanceGroupDetailList: any;
export interface PlacementType {
    AvailabilityZone?: string;
    AvailabilityZones?: string[];
}
export declare const PlacementType: S.Schema<PlacementType>;
export interface JobFlowInstancesDetail {
    MasterInstanceType?: string;
    MasterPublicDnsName?: string;
    MasterInstanceId?: string;
    SlaveInstanceType?: string;
    InstanceCount?: number;
    InstanceGroups?: InstanceGroupDetail[];
    NormalizedInstanceHours?: number;
    Ec2KeyName?: string;
    Ec2SubnetId?: string;
    Placement?: PlacementType;
    KeepJobFlowAliveWhenNoSteps?: boolean;
    TerminationProtected?: boolean;
    UnhealthyNodeReplacement?: boolean;
    HadoopVersion?: string;
}
export declare const JobFlowInstancesDetail: S.Schema<JobFlowInstancesDetail>;
export type StepExecutionState = "PENDING" | "RUNNING" | "CONTINUE" | "COMPLETED" | "CANCELLED" | "FAILED" | "INTERRUPTED" | (string & {});
export declare const StepExecutionState: any;
export interface StepExecutionStatusDetail {
    State?: StepExecutionState;
    CreationDateTime?: Date;
    StartDateTime?: Date;
    EndDateTime?: Date;
    LastStateChangeReason?: string;
}
export declare const StepExecutionStatusDetail: S.Schema<StepExecutionStatusDetail>;
export interface StepDetail {
    StepConfig?: StepConfig;
    ExecutionStatusDetail?: StepExecutionStatusDetail;
}
export declare const StepDetail: S.Schema<StepDetail>;
export type StepDetailList = StepDetail[];
export declare const StepDetailList: any;
export interface ScriptBootstrapActionConfig {
    Path?: string;
    Args?: string[];
}
export declare const ScriptBootstrapActionConfig: S.Schema<ScriptBootstrapActionConfig>;
export interface BootstrapActionConfig {
    Name?: string;
    ScriptBootstrapAction?: ScriptBootstrapActionConfig;
}
export declare const BootstrapActionConfig: S.Schema<BootstrapActionConfig>;
export interface BootstrapActionDetail {
    BootstrapActionConfig?: BootstrapActionConfig;
}
export declare const BootstrapActionDetail: S.Schema<BootstrapActionDetail>;
export type BootstrapActionDetailList = BootstrapActionDetail[];
export declare const BootstrapActionDetailList: any;
export type SupportedProductsList = string[];
export declare const SupportedProductsList: any;
export interface JobFlowDetail {
    JobFlowId?: string;
    Name?: string;
    LogUri?: string;
    LogEncryptionKmsKeyId?: string;
    AmiVersion?: string;
    ExecutionStatusDetail?: JobFlowExecutionStatusDetail;
    Instances?: JobFlowInstancesDetail;
    Steps?: StepDetail[];
    BootstrapActions?: BootstrapActionDetail[];
    SupportedProducts?: string[];
    VisibleToAllUsers?: boolean;
    JobFlowRole?: string;
    ServiceRole?: string;
    AutoScalingRole?: string;
    ScaleDownBehavior?: ScaleDownBehavior;
}
export declare const JobFlowDetail: S.Schema<JobFlowDetail>;
export type JobFlowDetailList = JobFlowDetail[];
export declare const JobFlowDetailList: any;
export interface DescribeJobFlowsOutput {
    JobFlows?: (JobFlowDetail & {
        JobFlowId: XmlStringMaxLen256;
        Name: XmlStringMaxLen256;
        ExecutionStatusDetail: JobFlowExecutionStatusDetail & {
            State: JobFlowExecutionState;
            CreationDateTime: Date;
        };
        Instances: JobFlowInstancesDetail & {
            MasterInstanceType: InstanceType;
            SlaveInstanceType: InstanceType;
            InstanceCount: number;
            InstanceGroups: (InstanceGroupDetail & {
                Market: MarketType;
                InstanceRole: InstanceRoleType;
                InstanceType: InstanceType;
                InstanceRequestCount: number;
                InstanceRunningCount: number;
                State: InstanceGroupState;
                CreationDateTime: Date;
            })[];
        };
        Steps: (StepDetail & {
            StepConfig: StepConfig & {
                Name: XmlStringMaxLen256;
                HadoopJarStep: HadoopJarStepConfig & {
                    Jar: XmlString;
                };
            };
            ExecutionStatusDetail: StepExecutionStatusDetail & {
                State: StepExecutionState;
                CreationDateTime: Date;
            };
        })[];
        BootstrapActions: (BootstrapActionDetail & {
            BootstrapActionConfig: BootstrapActionConfig & {
                Name: XmlStringMaxLen256;
                ScriptBootstrapAction: ScriptBootstrapActionConfig & {
                    Path: XmlString;
                };
            };
        })[];
    })[];
}
export declare const DescribeJobFlowsOutput: S.Schema<DescribeJobFlowsOutput>;
export interface DescribeNotebookExecutionInput {
    NotebookExecutionId?: string;
}
export declare const DescribeNotebookExecutionInput: S.Schema<DescribeNotebookExecutionInput>;
export type ExecutionEngineType = "EMR" | (string & {});
export declare const ExecutionEngineType: any;
export type IAMRoleArn = string;
export interface ExecutionEngineConfig {
    Id?: string;
    Type?: ExecutionEngineType;
    MasterInstanceSecurityGroupId?: string;
    ExecutionRoleArn?: string;
}
export declare const ExecutionEngineConfig: S.Schema<ExecutionEngineConfig>;
export type NotebookExecutionStatus = "START_PENDING" | "STARTING" | "RUNNING" | "FINISHING" | "FINISHED" | "FAILING" | "FAILED" | "STOP_PENDING" | "STOPPING" | "STOPPED" | (string & {});
export declare const NotebookExecutionStatus: any;
export type UriString = string;
export interface NotebookS3LocationForOutput {
    Bucket?: string;
    Key?: string;
}
export declare const NotebookS3LocationForOutput: S.Schema<NotebookS3LocationForOutput>;
export interface OutputNotebookS3LocationForOutput {
    Bucket?: string;
    Key?: string;
}
export declare const OutputNotebookS3LocationForOutput: S.Schema<OutputNotebookS3LocationForOutput>;
export type OutputNotebookFormat = "HTML" | (string & {});
export declare const OutputNotebookFormat: any;
export type EnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export declare const EnvironmentVariablesMap: any;
export interface NotebookExecution {
    NotebookExecutionId?: string;
    EditorId?: string;
    ExecutionEngine?: ExecutionEngineConfig;
    NotebookExecutionName?: string;
    NotebookParams?: string;
    Status?: NotebookExecutionStatus;
    StartTime?: Date;
    EndTime?: Date;
    Arn?: string;
    OutputNotebookURI?: string;
    LastStateChangeReason?: string;
    NotebookInstanceSecurityGroupId?: string;
    Tags?: Tag[];
    NotebookS3Location?: NotebookS3LocationForOutput;
    OutputNotebookS3Location?: OutputNotebookS3LocationForOutput;
    OutputNotebookFormat?: OutputNotebookFormat;
    EnvironmentVariables?: {
        [key: string]: string | undefined;
    };
}
export declare const NotebookExecution: S.Schema<NotebookExecution>;
export interface DescribeNotebookExecutionOutput {
    NotebookExecution?: NotebookExecution & {
        ExecutionEngine: ExecutionEngineConfig & {
            Id: XmlStringMaxLen256;
        };
    };
}
export declare const DescribeNotebookExecutionOutput: S.Schema<DescribeNotebookExecutionOutput>;
export interface DescribePersistentAppUIInput {
    PersistentAppUIId?: string;
}
export declare const DescribePersistentAppUIInput: S.Schema<DescribePersistentAppUIInput>;
export type PersistentAppUIType = "SHS" | "TEZ" | "YTS" | (string & {});
export declare const PersistentAppUIType: any;
export type PersistentAppUITypeList = PersistentAppUIType[];
export declare const PersistentAppUITypeList: any;
export interface PersistentAppUI {
    PersistentAppUIId?: string;
    PersistentAppUITypeList?: PersistentAppUIType[];
    PersistentAppUIStatus?: string;
    AuthorId?: string;
    CreationTime?: Date;
    LastModifiedTime?: Date;
    LastStateChangeReason?: string;
    Tags?: Tag[];
}
export declare const PersistentAppUI: S.Schema<PersistentAppUI>;
export interface DescribePersistentAppUIOutput {
    PersistentAppUI?: PersistentAppUI;
}
export declare const DescribePersistentAppUIOutput: S.Schema<DescribePersistentAppUIOutput>;
export type MaxResultsNumber = number;
export interface DescribeReleaseLabelInput {
    ReleaseLabel?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const DescribeReleaseLabelInput: S.Schema<DescribeReleaseLabelInput>;
export interface SimplifiedApplication {
    Name?: string;
    Version?: string;
}
export declare const SimplifiedApplication: S.Schema<SimplifiedApplication>;
export type SimplifiedApplicationList = SimplifiedApplication[];
export declare const SimplifiedApplicationList: any;
export interface OSRelease {
    Label?: string;
}
export declare const OSRelease: S.Schema<OSRelease>;
export type OSReleaseList = OSRelease[];
export declare const OSReleaseList: any;
export interface DescribeReleaseLabelOutput {
    ReleaseLabel?: string;
    Applications?: SimplifiedApplication[];
    NextToken?: string;
    AvailableOSReleases?: OSRelease[];
}
export declare const DescribeReleaseLabelOutput: S.Schema<DescribeReleaseLabelOutput>;
export interface DescribeSecurityConfigurationInput {
    Name?: string;
}
export declare const DescribeSecurityConfigurationInput: S.Schema<DescribeSecurityConfigurationInput>;
export interface DescribeSecurityConfigurationOutput {
    Name?: string;
    SecurityConfiguration?: string;
    CreationDateTime?: Date;
}
export declare const DescribeSecurityConfigurationOutput: S.Schema<DescribeSecurityConfigurationOutput>;
export interface DescribeStepInput {
    ClusterId?: string;
    StepId?: string;
}
export declare const DescribeStepInput: S.Schema<DescribeStepInput>;
export interface HadoopStepConfig {
    Jar?: string;
    Properties?: {
        [key: string]: string | undefined;
    };
    MainClass?: string;
    Args?: string[];
}
export declare const HadoopStepConfig: S.Schema<HadoopStepConfig>;
export type StepState = "PENDING" | "CANCEL_PENDING" | "RUNNING" | "COMPLETED" | "CANCELLED" | "FAILED" | "INTERRUPTED" | (string & {});
export declare const StepState: any;
export type StepStateChangeReasonCode = "NONE" | (string & {});
export declare const StepStateChangeReasonCode: any;
export interface StepStateChangeReason {
    Code?: StepStateChangeReasonCode;
    Message?: string;
}
export declare const StepStateChangeReason: S.Schema<StepStateChangeReason>;
export interface FailureDetails {
    Reason?: string;
    Message?: string;
    LogFile?: string;
}
export declare const FailureDetails: S.Schema<FailureDetails>;
export interface StepTimeline {
    CreationDateTime?: Date;
    StartDateTime?: Date;
    EndDateTime?: Date;
}
export declare const StepTimeline: S.Schema<StepTimeline>;
export interface StepStatus {
    State?: StepState;
    StateChangeReason?: StepStateChangeReason;
    FailureDetails?: FailureDetails;
    Timeline?: StepTimeline;
}
export declare const StepStatus: S.Schema<StepStatus>;
export interface Step {
    Id?: string;
    Name?: string;
    Config?: HadoopStepConfig;
    ActionOnFailure?: ActionOnFailure;
    Status?: StepStatus;
    ExecutionRoleArn?: string;
    LogUri?: string;
    EncryptionKeyArn?: string;
}
export declare const Step: S.Schema<Step>;
export interface DescribeStepOutput {
    Step?: Step;
}
export declare const DescribeStepOutput: S.Schema<DescribeStepOutput>;
export interface DescribeStudioInput {
    StudioId?: string;
}
export declare const DescribeStudioInput: S.Schema<DescribeStudioInput>;
export interface Studio {
    StudioId?: string;
    StudioArn?: string;
    Name?: string;
    Description?: string;
    AuthMode?: AuthMode;
    VpcId?: string;
    SubnetIds?: string[];
    ServiceRole?: string;
    UserRole?: string;
    WorkspaceSecurityGroupId?: string;
    EngineSecurityGroupId?: string;
    Url?: string;
    CreationTime?: Date;
    DefaultS3Location?: string;
    IdpAuthUrl?: string;
    IdpRelayStateParameterName?: string;
    Tags?: Tag[];
    IdcInstanceArn?: string;
    TrustedIdentityPropagationEnabled?: boolean;
    IdcUserAssignment?: IdcUserAssignment;
    EncryptionKeyArn?: string;
}
export declare const Studio: S.Schema<Studio>;
export interface DescribeStudioOutput {
    Studio?: Studio;
}
export declare const DescribeStudioOutput: S.Schema<DescribeStudioOutput>;
export interface GetAutoTerminationPolicyInput {
    ClusterId?: string;
}
export declare const GetAutoTerminationPolicyInput: S.Schema<GetAutoTerminationPolicyInput>;
export interface AutoTerminationPolicy {
    IdleTimeout?: number;
}
export declare const AutoTerminationPolicy: S.Schema<AutoTerminationPolicy>;
export interface GetAutoTerminationPolicyOutput {
    AutoTerminationPolicy?: AutoTerminationPolicy;
}
export declare const GetAutoTerminationPolicyOutput: S.Schema<GetAutoTerminationPolicyOutput>;
export interface GetBlockPublicAccessConfigurationInput {
}
export declare const GetBlockPublicAccessConfigurationInput: S.Schema<GetBlockPublicAccessConfigurationInput>;
export type Port = number;
export interface PortRange {
    MinRange?: number;
    MaxRange?: number;
}
export declare const PortRange: S.Schema<PortRange>;
export type PortRanges = PortRange[];
export declare const PortRanges: any;
export interface BlockPublicAccessConfiguration {
    BlockPublicSecurityGroupRules?: boolean;
    PermittedPublicSecurityGroupRuleRanges?: PortRange[];
    Classification?: string;
    Configurations?: Configuration[];
    Properties?: {
        [key: string]: string | undefined;
    };
}
export declare const BlockPublicAccessConfiguration: S.Schema<BlockPublicAccessConfiguration>;
export interface BlockPublicAccessConfigurationMetadata {
    CreationDateTime?: Date;
    CreatedByArn?: string;
}
export declare const BlockPublicAccessConfigurationMetadata: S.Schema<BlockPublicAccessConfigurationMetadata>;
export interface GetBlockPublicAccessConfigurationOutput {
    BlockPublicAccessConfiguration: BlockPublicAccessConfiguration & {
        BlockPublicSecurityGroupRules: boolean;
        PermittedPublicSecurityGroupRuleRanges: (PortRange & {
            MinRange: Port;
        })[];
    };
    BlockPublicAccessConfigurationMetadata: BlockPublicAccessConfigurationMetadata & {
        CreationDateTime: Date;
        CreatedByArn: ArnType;
    };
}
export declare const GetBlockPublicAccessConfigurationOutput: S.Schema<GetBlockPublicAccessConfigurationOutput>;
export interface GetClusterSessionCredentialsInput {
    ClusterId?: string;
    ExecutionRoleArn?: string;
}
export declare const GetClusterSessionCredentialsInput: S.Schema<GetClusterSessionCredentialsInput>;
export interface UsernamePassword {
    Username?: string;
    Password?: string | redacted.Redacted<string>;
}
export declare const UsernamePassword: S.Schema<UsernamePassword>;
export type Credentials = {
    UsernamePassword: UsernamePassword;
};
export declare const Credentials: any;
export interface GetClusterSessionCredentialsOutput {
    Credentials?: Credentials;
    ExpiresAt?: Date;
}
export declare const GetClusterSessionCredentialsOutput: S.Schema<GetClusterSessionCredentialsOutput>;
export interface GetManagedScalingPolicyInput {
    ClusterId?: string;
}
export declare const GetManagedScalingPolicyInput: S.Schema<GetManagedScalingPolicyInput>;
export type ComputeLimitsUnitType = "InstanceFleetUnits" | "Instances" | "VCPU" | (string & {});
export declare const ComputeLimitsUnitType: any;
export interface ComputeLimits {
    UnitType?: ComputeLimitsUnitType;
    MinimumCapacityUnits?: number;
    MaximumCapacityUnits?: number;
    MaximumOnDemandCapacityUnits?: number;
    MaximumCoreCapacityUnits?: number;
}
export declare const ComputeLimits: S.Schema<ComputeLimits>;
export type UtilizationPerformanceIndexInteger = number;
export type ScalingStrategy = "DEFAULT" | "ADVANCED" | (string & {});
export declare const ScalingStrategy: any;
export interface ManagedScalingPolicy {
    ComputeLimits?: ComputeLimits;
    UtilizationPerformanceIndex?: number;
    ScalingStrategy?: ScalingStrategy;
}
export declare const ManagedScalingPolicy: S.Schema<ManagedScalingPolicy>;
export interface GetManagedScalingPolicyOutput {
    ManagedScalingPolicy?: ManagedScalingPolicy & {
        ComputeLimits: ComputeLimits & {
            UnitType: ComputeLimitsUnitType;
            MinimumCapacityUnits: number;
            MaximumCapacityUnits: number;
        };
    };
}
export declare const GetManagedScalingPolicyOutput: S.Schema<GetManagedScalingPolicyOutput>;
export type OnClusterAppUIType = "SparkHistoryServer" | "YarnTimelineService" | "TezUI" | "ApplicationMaster" | "JobHistoryServer" | "ResourceManager" | (string & {});
export declare const OnClusterAppUIType: any;
export interface GetOnClusterAppUIPresignedURLInput {
    ClusterId?: string;
    OnClusterAppUIType?: OnClusterAppUIType;
    ApplicationId?: string;
    DryRun?: boolean;
    ExecutionRoleArn?: string;
}
export declare const GetOnClusterAppUIPresignedURLInput: S.Schema<GetOnClusterAppUIPresignedURLInput>;
export interface GetOnClusterAppUIPresignedURLOutput {
    PresignedURLReady?: boolean;
    PresignedURL?: string;
}
export declare const GetOnClusterAppUIPresignedURLOutput: S.Schema<GetOnClusterAppUIPresignedURLOutput>;
export interface GetPersistentAppUIPresignedURLInput {
    PersistentAppUIId?: string;
    PersistentAppUIType?: PersistentAppUIType;
    ApplicationId?: string;
    AuthProxyCall?: boolean;
    ExecutionRoleArn?: string;
}
export declare const GetPersistentAppUIPresignedURLInput: S.Schema<GetPersistentAppUIPresignedURLInput>;
export interface GetPersistentAppUIPresignedURLOutput {
    PresignedURLReady?: boolean;
    PresignedURL?: string;
}
export declare const GetPersistentAppUIPresignedURLOutput: S.Schema<GetPersistentAppUIPresignedURLOutput>;
export type SessionId = string;
export interface GetSessionInput {
    ClusterId?: string;
    SessionId?: string;
}
export declare const GetSessionInput: S.Schema<GetSessionInput>;
export type SessionState = "SUBMITTED" | "STARTING" | "STARTED" | "IDLE" | "BUSY" | "TERMINATING" | "TERMINATED" | "FAILED" | (string & {});
export declare const SessionState: any;
export interface SessionCloudWatchLoggingConfiguration {
    Enabled?: boolean;
    LogGroup?: string;
    LogStreamNamePrefix?: string;
    EncryptionKeyArn?: string;
    LogTypes?: {
        [key: string]: string[] | undefined;
    };
}
export declare const SessionCloudWatchLoggingConfiguration: S.Schema<SessionCloudWatchLoggingConfiguration>;
export interface SessionManagedLoggingConfiguration {
    Enabled?: boolean;
    EncryptionKeyArn?: string;
}
export declare const SessionManagedLoggingConfiguration: S.Schema<SessionManagedLoggingConfiguration>;
export interface SessionS3LoggingConfiguration {
    Enabled?: boolean;
    LogUri?: string;
    EncryptionKeyArn?: string;
    LogTypes?: {
        [key: string]: string[] | undefined;
    };
}
export declare const SessionS3LoggingConfiguration: S.Schema<SessionS3LoggingConfiguration>;
export interface SessionMonitoringConfiguration {
    CloudWatchLoggingConfiguration?: SessionCloudWatchLoggingConfiguration;
    ManagedLoggingConfiguration?: SessionManagedLoggingConfiguration;
    S3LoggingConfiguration?: SessionS3LoggingConfiguration;
}
export declare const SessionMonitoringConfiguration: S.Schema<SessionMonitoringConfiguration>;
export interface Session {
    Id?: string;
    ClusterId?: string;
    Name?: string;
    Arn?: string;
    State?: SessionState;
    StateChangeReason?: string;
    ReleaseLabel?: string;
    ExecutionRoleArn?: string;
    AccountId?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    StartedAt?: Date;
    EndedAt?: Date;
    IdleSince?: Date;
    EngineConfigurations?: Configuration[];
    MonitoringConfiguration?: SessionMonitoringConfiguration;
    SessionIdleTimeoutInMinutes?: number;
    ServerUrl?: string;
    Tags?: Tag[];
}
export declare const Session: S.Schema<Session>;
export interface GetSessionOutput {
    Session: Session & {
        Id: SessionId;
        ClusterId: ClusterId;
        Arn: ArnType;
        State: SessionState;
    };
}
export declare const GetSessionOutput: S.Schema<GetSessionOutput>;
export interface GetSessionEndpointInput {
    ClusterId?: string;
    SessionId?: string;
}
export declare const GetSessionEndpointInput: S.Schema<GetSessionEndpointInput>;
export type SensitiveString = string | redacted.Redacted<string>;
export interface GetSessionEndpointOutput {
    Endpoint: string;
    AuthToken?: string | redacted.Redacted<string>;
    AuthTokenExpirationTime?: Date;
    Credentials?: Credentials;
}
export declare const GetSessionEndpointOutput: S.Schema<GetSessionEndpointOutput>;
export interface GetStudioSessionMappingInput {
    StudioId?: string;
    IdentityId?: string;
    IdentityName?: string;
    IdentityType?: IdentityType;
}
export declare const GetStudioSessionMappingInput: S.Schema<GetStudioSessionMappingInput>;
export interface SessionMappingDetail {
    StudioId?: string;
    IdentityId?: string;
    IdentityName?: string;
    IdentityType?: IdentityType;
    SessionPolicyArn?: string;
    CreationTime?: Date;
    LastModifiedTime?: Date;
}
export declare const SessionMappingDetail: S.Schema<SessionMappingDetail>;
export interface GetStudioSessionMappingOutput {
    SessionMapping?: SessionMappingDetail;
}
export declare const GetStudioSessionMappingOutput: S.Schema<GetStudioSessionMappingOutput>;
export type Marker = string;
export interface ListBootstrapActionsInput {
    ClusterId?: string;
    Marker?: string;
}
export declare const ListBootstrapActionsInput: S.Schema<ListBootstrapActionsInput>;
export interface Command {
    Name?: string;
    ScriptPath?: string;
    Args?: string[];
}
export declare const Command: S.Schema<Command>;
export type CommandList = Command[];
export declare const CommandList: any;
export interface ListBootstrapActionsOutput {
    BootstrapActions?: Command[];
    Marker?: string;
}
export declare const ListBootstrapActionsOutput: S.Schema<ListBootstrapActionsOutput>;
export type ClusterStateList = ClusterState[];
export declare const ClusterStateList: any;
export interface ListClustersInput {
    CreatedAfter?: Date;
    CreatedBefore?: Date;
    ClusterStates?: ClusterState[];
    Marker?: string;
}
export declare const ListClustersInput: S.Schema<ListClustersInput>;
export interface ClusterSummary {
    Id?: string;
    Name?: string;
    Status?: ClusterStatus;
    NormalizedInstanceHours?: number;
    ClusterArn?: string;
    OutpostArn?: string;
}
export declare const ClusterSummary: S.Schema<ClusterSummary>;
export type ClusterSummaryList = ClusterSummary[];
export declare const ClusterSummaryList: any;
export interface ListClustersOutput {
    Clusters?: ClusterSummary[];
    Marker?: string;
}
export declare const ListClustersOutput: S.Schema<ListClustersOutput>;
export interface ListInstanceFleetsInput {
    ClusterId?: string;
    Marker?: string;
}
export declare const ListInstanceFleetsInput: S.Schema<ListInstanceFleetsInput>;
export type InstanceFleetState = "PROVISIONING" | "BOOTSTRAPPING" | "RUNNING" | "RESIZING" | "RECONFIGURING" | "SUSPENDED" | "TERMINATING" | "TERMINATED" | (string & {});
export declare const InstanceFleetState: any;
export type InstanceFleetStateChangeReasonCode = "INTERNAL_ERROR" | "VALIDATION_ERROR" | "INSTANCE_FAILURE" | "CLUSTER_TERMINATED" | (string & {});
export declare const InstanceFleetStateChangeReasonCode: any;
export interface InstanceFleetStateChangeReason {
    Code?: InstanceFleetStateChangeReasonCode;
    Message?: string;
}
export declare const InstanceFleetStateChangeReason: S.Schema<InstanceFleetStateChangeReason>;
export interface InstanceFleetTimeline {
    CreationDateTime?: Date;
    ReadyDateTime?: Date;
    EndDateTime?: Date;
}
export declare const InstanceFleetTimeline: S.Schema<InstanceFleetTimeline>;
export interface InstanceFleetStatus {
    State?: InstanceFleetState;
    StateChangeReason?: InstanceFleetStateChangeReason;
    Timeline?: InstanceFleetTimeline;
}
export declare const InstanceFleetStatus: S.Schema<InstanceFleetStatus>;
export interface EbsBlockDevice {
    VolumeSpecification?: VolumeSpecification;
    Device?: string;
}
export declare const EbsBlockDevice: S.Schema<EbsBlockDevice>;
export type EbsBlockDeviceList = EbsBlockDevice[];
export declare const EbsBlockDeviceList: any;
export interface InstanceTypeSpecification {
    InstanceType?: string;
    WeightedCapacity?: number;
    BidPrice?: string;
    BidPriceAsPercentageOfOnDemandPrice?: number;
    Configurations?: Configuration[];
    EbsBlockDevices?: EbsBlockDevice[];
    EbsOptimized?: boolean;
    CustomAmiId?: string;
    Priority?: number;
}
export declare const InstanceTypeSpecification: S.Schema<InstanceTypeSpecification>;
export type InstanceTypeSpecificationList = InstanceTypeSpecification[];
export declare const InstanceTypeSpecificationList: any;
export interface InstanceFleet {
    Id?: string;
    Name?: string;
    Status?: InstanceFleetStatus;
    InstanceFleetType?: InstanceFleetType;
    TargetOnDemandCapacity?: number;
    TargetSpotCapacity?: number;
    ProvisionedOnDemandCapacity?: number;
    ProvisionedSpotCapacity?: number;
    InstanceTypeSpecifications?: InstanceTypeSpecification[];
    LaunchSpecifications?: InstanceFleetProvisioningSpecifications;
    ResizeSpecifications?: InstanceFleetResizingSpecifications;
    Context?: string;
}
export declare const InstanceFleet: S.Schema<InstanceFleet>;
export type InstanceFleetList = InstanceFleet[];
export declare const InstanceFleetList: any;
export interface ListInstanceFleetsOutput {
    InstanceFleets?: (InstanceFleet & {
        InstanceTypeSpecifications: (InstanceTypeSpecification & {
            EbsBlockDevices: (EbsBlockDevice & {
                VolumeSpecification: VolumeSpecification & {
                    VolumeType: string;
                    SizeInGB: number;
                };
            })[];
        })[];
        LaunchSpecifications: InstanceFleetProvisioningSpecifications & {
            SpotSpecification: SpotProvisioningSpecification & {
                TimeoutDurationMinutes: WholeNumber;
                TimeoutAction: SpotProvisioningTimeoutAction;
            };
            OnDemandSpecification: OnDemandProvisioningSpecification & {
                AllocationStrategy: OnDemandProvisioningAllocationStrategy;
            };
        };
    })[];
    Marker?: string;
}
export declare const ListInstanceFleetsOutput: S.Schema<ListInstanceFleetsOutput>;
export interface ListInstanceGroupsInput {
    ClusterId?: string;
    Marker?: string;
}
export declare const ListInstanceGroupsInput: S.Schema<ListInstanceGroupsInput>;
export type InstanceGroupId = string;
export type InstanceGroupType = "MASTER" | "CORE" | "TASK" | (string & {});
export declare const InstanceGroupType: any;
export type InstanceGroupStateChangeReasonCode = "INTERNAL_ERROR" | "VALIDATION_ERROR" | "INSTANCE_FAILURE" | "CLUSTER_TERMINATED" | (string & {});
export declare const InstanceGroupStateChangeReasonCode: any;
export interface InstanceGroupStateChangeReason {
    Code?: InstanceGroupStateChangeReasonCode;
    Message?: string;
}
export declare const InstanceGroupStateChangeReason: S.Schema<InstanceGroupStateChangeReason>;
export interface InstanceGroupTimeline {
    CreationDateTime?: Date;
    ReadyDateTime?: Date;
    EndDateTime?: Date;
}
export declare const InstanceGroupTimeline: S.Schema<InstanceGroupTimeline>;
export interface InstanceGroupStatus {
    State?: InstanceGroupState;
    StateChangeReason?: InstanceGroupStateChangeReason;
    Timeline?: InstanceGroupTimeline;
}
export declare const InstanceGroupStatus: S.Schema<InstanceGroupStatus>;
export type InstanceId = string;
export type EC2InstanceIdsList = string[];
export declare const EC2InstanceIdsList: any;
export interface InstanceResizePolicy {
    InstancesToTerminate?: string[];
    InstancesToProtect?: string[];
    InstanceTerminationTimeout?: number;
}
export declare const InstanceResizePolicy: S.Schema<InstanceResizePolicy>;
export interface ShrinkPolicy {
    DecommissionTimeout?: number;
    InstanceResizePolicy?: InstanceResizePolicy;
}
export declare const ShrinkPolicy: S.Schema<ShrinkPolicy>;
export type AutoScalingPolicyState = "PENDING" | "ATTACHING" | "ATTACHED" | "DETACHING" | "DETACHED" | "FAILED" | (string & {});
export declare const AutoScalingPolicyState: any;
export type AutoScalingPolicyStateChangeReasonCode = "USER_REQUEST" | "PROVISION_FAILURE" | "CLEANUP_FAILURE" | (string & {});
export declare const AutoScalingPolicyStateChangeReasonCode: any;
export interface AutoScalingPolicyStateChangeReason {
    Code?: AutoScalingPolicyStateChangeReasonCode;
    Message?: string;
}
export declare const AutoScalingPolicyStateChangeReason: S.Schema<AutoScalingPolicyStateChangeReason>;
export interface AutoScalingPolicyStatus {
    State?: AutoScalingPolicyState;
    StateChangeReason?: AutoScalingPolicyStateChangeReason;
}
export declare const AutoScalingPolicyStatus: S.Schema<AutoScalingPolicyStatus>;
export interface AutoScalingPolicyDescription {
    Status?: AutoScalingPolicyStatus;
    Constraints?: ScalingConstraints;
    Rules?: ScalingRule[];
}
export declare const AutoScalingPolicyDescription: S.Schema<AutoScalingPolicyDescription>;
export interface InstanceGroup {
    Id?: string;
    Name?: string;
    Market?: MarketType;
    InstanceGroupType?: InstanceGroupType;
    BidPrice?: string;
    InstanceType?: string;
    RequestedInstanceCount?: number;
    RunningInstanceCount?: number;
    Status?: InstanceGroupStatus;
    Configurations?: Configuration[];
    ConfigurationsVersion?: number;
    LastSuccessfullyAppliedConfigurations?: Configuration[];
    LastSuccessfullyAppliedConfigurationsVersion?: number;
    EbsBlockDevices?: EbsBlockDevice[];
    EbsOptimized?: boolean;
    ShrinkPolicy?: ShrinkPolicy;
    AutoScalingPolicy?: AutoScalingPolicyDescription;
    CustomAmiId?: string;
}
export declare const InstanceGroup: S.Schema<InstanceGroup>;
export type InstanceGroupList = InstanceGroup[];
export declare const InstanceGroupList: any;
export interface ListInstanceGroupsOutput {
    InstanceGroups?: (InstanceGroup & {
        EbsBlockDevices: (EbsBlockDevice & {
            VolumeSpecification: VolumeSpecification & {
                VolumeType: string;
                SizeInGB: number;
            };
        })[];
        AutoScalingPolicy: AutoScalingPolicyDescription & {
            Constraints: ScalingConstraints & {
                MinCapacity: number;
                MaxCapacity: number;
            };
            Rules: (ScalingRule & {
                Name: string;
                Action: ScalingAction & {
                    SimpleScalingPolicyConfiguration: SimpleScalingPolicyConfiguration & {
                        ScalingAdjustment: number;
                    };
                };
                Trigger: ScalingTrigger & {
                    CloudWatchAlarmDefinition: CloudWatchAlarmDefinition & {
                        ComparisonOperator: ComparisonOperator;
                        MetricName: string;
                        Period: number;
                        Threshold: NonNegativeDouble;
                    };
                };
            })[];
        };
    })[];
    Marker?: string;
}
export declare const ListInstanceGroupsOutput: S.Schema<ListInstanceGroupsOutput>;
export type InstanceGroupTypeList = InstanceGroupType[];
export declare const InstanceGroupTypeList: any;
export type InstanceState = "AWAITING_FULFILLMENT" | "PROVISIONING" | "BOOTSTRAPPING" | "RUNNING" | "TERMINATED" | (string & {});
export declare const InstanceState: any;
export type InstanceStateList = InstanceState[];
export declare const InstanceStateList: any;
export interface ListInstancesInput {
    ClusterId?: string;
    InstanceGroupId?: string;
    InstanceGroupTypes?: InstanceGroupType[];
    InstanceFleetId?: string;
    InstanceFleetType?: InstanceFleetType;
    InstanceStates?: InstanceState[];
    Marker?: string;
}
export declare const ListInstancesInput: S.Schema<ListInstancesInput>;
export type InstanceStateChangeReasonCode = "INTERNAL_ERROR" | "VALIDATION_ERROR" | "INSTANCE_FAILURE" | "BOOTSTRAP_FAILURE" | "CLUSTER_TERMINATED" | (string & {});
export declare const InstanceStateChangeReasonCode: any;
export interface InstanceStateChangeReason {
    Code?: InstanceStateChangeReasonCode;
    Message?: string;
}
export declare const InstanceStateChangeReason: S.Schema<InstanceStateChangeReason>;
export interface InstanceTimeline {
    CreationDateTime?: Date;
    ReadyDateTime?: Date;
    EndDateTime?: Date;
}
export declare const InstanceTimeline: S.Schema<InstanceTimeline>;
export interface InstanceStatus {
    State?: InstanceState;
    StateChangeReason?: InstanceStateChangeReason;
    Timeline?: InstanceTimeline;
}
export declare const InstanceStatus: S.Schema<InstanceStatus>;
export interface EbsVolume {
    Device?: string;
    VolumeId?: string;
}
export declare const EbsVolume: S.Schema<EbsVolume>;
export type EbsVolumeList = EbsVolume[];
export declare const EbsVolumeList: any;
export interface Instance {
    Id?: string;
    Ec2InstanceId?: string;
    PublicDnsName?: string;
    PublicIpAddress?: string;
    PrivateDnsName?: string;
    PrivateIpAddress?: string;
    Status?: InstanceStatus;
    InstanceGroupId?: string;
    InstanceFleetId?: string;
    Market?: MarketType;
    InstanceType?: string;
    EbsVolumes?: EbsVolume[];
}
export declare const Instance: S.Schema<Instance>;
export type InstanceList = Instance[];
export declare const InstanceList: any;
export interface ListInstancesOutput {
    Instances?: Instance[];
    Marker?: string;
}
export declare const ListInstancesOutput: S.Schema<ListInstancesOutput>;
export interface ListNotebookExecutionsInput {
    EditorId?: string;
    Status?: NotebookExecutionStatus;
    From?: Date;
    To?: Date;
    Marker?: string;
    ExecutionEngineId?: string;
}
export declare const ListNotebookExecutionsInput: S.Schema<ListNotebookExecutionsInput>;
export interface NotebookExecutionSummary {
    NotebookExecutionId?: string;
    EditorId?: string;
    NotebookExecutionName?: string;
    Status?: NotebookExecutionStatus;
    StartTime?: Date;
    EndTime?: Date;
    NotebookS3Location?: NotebookS3LocationForOutput;
    ExecutionEngineId?: string;
}
export declare const NotebookExecutionSummary: S.Schema<NotebookExecutionSummary>;
export type NotebookExecutionSummaryList = NotebookExecutionSummary[];
export declare const NotebookExecutionSummaryList: any;
export interface ListNotebookExecutionsOutput {
    NotebookExecutions?: NotebookExecutionSummary[];
    Marker?: string;
}
export declare const ListNotebookExecutionsOutput: S.Schema<ListNotebookExecutionsOutput>;
export interface ReleaseLabelFilter {
    Prefix?: string;
    Application?: string;
}
export declare const ReleaseLabelFilter: S.Schema<ReleaseLabelFilter>;
export interface ListReleaseLabelsInput {
    Filters?: ReleaseLabelFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListReleaseLabelsInput: S.Schema<ListReleaseLabelsInput>;
export interface ListReleaseLabelsOutput {
    ReleaseLabels?: string[];
    NextToken?: string;
}
export declare const ListReleaseLabelsOutput: S.Schema<ListReleaseLabelsOutput>;
export interface ListSecurityConfigurationsInput {
    Marker?: string;
}
export declare const ListSecurityConfigurationsInput: S.Schema<ListSecurityConfigurationsInput>;
export interface SecurityConfigurationSummary {
    Name?: string;
    CreationDateTime?: Date;
}
export declare const SecurityConfigurationSummary: S.Schema<SecurityConfigurationSummary>;
export type SecurityConfigurationList = SecurityConfigurationSummary[];
export declare const SecurityConfigurationList: any;
export interface ListSecurityConfigurationsOutput {
    SecurityConfigurations?: SecurityConfigurationSummary[];
    Marker?: string;
}
export declare const ListSecurityConfigurationsOutput: S.Schema<ListSecurityConfigurationsOutput>;
export type SessionStateList = SessionState[];
export declare const SessionStateList: any;
export interface ListSessionsInput {
    ClusterId?: string;
    SessionStates?: SessionState[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListSessionsInput: S.Schema<ListSessionsInput>;
export type SessionList = Session[];
export declare const SessionList: any;
export interface ListSessionsOutput {
    Sessions?: (Session & {
        Id: SessionId;
        ClusterId: ClusterId;
        Arn: ArnType;
        State: SessionState;
    })[];
    NextToken?: string;
}
export declare const ListSessionsOutput: S.Schema<ListSessionsOutput>;
export type StepStateList = StepState[];
export declare const StepStateList: any;
export interface ListStepsInput {
    ClusterId?: string;
    StepStates?: StepState[];
    StepIds?: string[];
    Marker?: string;
}
export declare const ListStepsInput: S.Schema<ListStepsInput>;
export interface StepSummary {
    Id?: string;
    Name?: string;
    Config?: HadoopStepConfig;
    ActionOnFailure?: ActionOnFailure;
    Status?: StepStatus;
    LogUri?: string;
    EncryptionKeyArn?: string;
}
export declare const StepSummary: S.Schema<StepSummary>;
export type StepSummaryList = StepSummary[];
export declare const StepSummaryList: any;
export interface ListStepsOutput {
    Steps?: StepSummary[];
    Marker?: string;
}
export declare const ListStepsOutput: S.Schema<ListStepsOutput>;
export interface ListStudiosInput {
    Marker?: string;
}
export declare const ListStudiosInput: S.Schema<ListStudiosInput>;
export interface StudioSummary {
    StudioId?: string;
    Name?: string;
    VpcId?: string;
    Description?: string;
    Url?: string;
    AuthMode?: AuthMode;
    CreationTime?: Date;
}
export declare const StudioSummary: S.Schema<StudioSummary>;
export type StudioSummaryList = StudioSummary[];
export declare const StudioSummaryList: any;
export interface ListStudiosOutput {
    Studios?: StudioSummary[];
    Marker?: string;
}
export declare const ListStudiosOutput: S.Schema<ListStudiosOutput>;
export interface ListStudioSessionMappingsInput {
    StudioId?: string;
    IdentityType?: IdentityType;
    Marker?: string;
}
export declare const ListStudioSessionMappingsInput: S.Schema<ListStudioSessionMappingsInput>;
export interface SessionMappingSummary {
    StudioId?: string;
    IdentityId?: string;
    IdentityName?: string;
    IdentityType?: IdentityType;
    SessionPolicyArn?: string;
    CreationTime?: Date;
}
export declare const SessionMappingSummary: S.Schema<SessionMappingSummary>;
export type SessionMappingSummaryList = SessionMappingSummary[];
export declare const SessionMappingSummaryList: any;
export interface ListStudioSessionMappingsOutput {
    SessionMappings?: SessionMappingSummary[];
    Marker?: string;
}
export declare const ListStudioSessionMappingsOutput: S.Schema<ListStudioSessionMappingsOutput>;
export interface ListSupportedInstanceTypesInput {
    ReleaseLabel?: string;
    Marker?: string;
}
export declare const ListSupportedInstanceTypesInput: S.Schema<ListSupportedInstanceTypesInput>;
export interface SupportedInstanceType {
    Type?: string;
    MemoryGB?: number;
    StorageGB?: number;
    VCPU?: number;
    Is64BitsOnly?: boolean;
    InstanceFamilyId?: string;
    EbsOptimizedAvailable?: boolean;
    EbsOptimizedByDefault?: boolean;
    NumberOfDisks?: number;
    EbsStorageOnly?: boolean;
    Architecture?: string;
}
export declare const SupportedInstanceType: S.Schema<SupportedInstanceType>;
export type SupportedInstanceTypesList = SupportedInstanceType[];
export declare const SupportedInstanceTypesList: any;
export interface ListSupportedInstanceTypesOutput {
    SupportedInstanceTypes?: SupportedInstanceType[];
    Marker?: string;
}
export declare const ListSupportedInstanceTypesOutput: S.Schema<ListSupportedInstanceTypesOutput>;
export interface ModifyClusterInput {
    ClusterId?: string;
    StepConcurrencyLevel?: number;
    ExtendedSupport?: boolean;
}
export declare const ModifyClusterInput: S.Schema<ModifyClusterInput>;
export interface ModifyClusterOutput {
    StepConcurrencyLevel?: number;
    ExtendedSupport?: boolean;
}
export declare const ModifyClusterOutput: S.Schema<ModifyClusterOutput>;
export interface InstanceFleetModifyConfig {
    InstanceFleetId?: string;
    TargetOnDemandCapacity?: number;
    TargetSpotCapacity?: number;
    ResizeSpecifications?: InstanceFleetResizingSpecifications;
    InstanceTypeConfigs?: InstanceTypeConfig[];
    Context?: string;
}
export declare const InstanceFleetModifyConfig: S.Schema<InstanceFleetModifyConfig>;
export interface ModifyInstanceFleetInput {
    ClusterId?: string;
    InstanceFleet?: InstanceFleetModifyConfig;
}
export declare const ModifyInstanceFleetInput: S.Schema<ModifyInstanceFleetInput>;
export interface ModifyInstanceFleetResponse {
}
export declare const ModifyInstanceFleetResponse: S.Schema<ModifyInstanceFleetResponse>;
export type EC2InstanceIdsToTerminateList = string[];
export declare const EC2InstanceIdsToTerminateList: any;
export type ReconfigurationType = "OVERWRITE" | "MERGE" | (string & {});
export declare const ReconfigurationType: any;
export interface InstanceGroupModifyConfig {
    InstanceGroupId?: string;
    InstanceCount?: number;
    EC2InstanceIdsToTerminate?: string[];
    ShrinkPolicy?: ShrinkPolicy;
    ReconfigurationType?: ReconfigurationType;
    Configurations?: Configuration[];
}
export declare const InstanceGroupModifyConfig: S.Schema<InstanceGroupModifyConfig>;
export type InstanceGroupModifyConfigList = InstanceGroupModifyConfig[];
export declare const InstanceGroupModifyConfigList: any;
export interface ModifyInstanceGroupsInput {
    ClusterId?: string;
    InstanceGroups?: InstanceGroupModifyConfig[];
}
export declare const ModifyInstanceGroupsInput: S.Schema<ModifyInstanceGroupsInput>;
export interface ModifyInstanceGroupsResponse {
}
export declare const ModifyInstanceGroupsResponse: S.Schema<ModifyInstanceGroupsResponse>;
export interface PutAutoScalingPolicyInput {
    ClusterId?: string;
    InstanceGroupId?: string;
    AutoScalingPolicy?: AutoScalingPolicy;
}
export declare const PutAutoScalingPolicyInput: S.Schema<PutAutoScalingPolicyInput>;
export interface PutAutoScalingPolicyOutput {
    ClusterId?: string;
    InstanceGroupId?: string;
    AutoScalingPolicy?: AutoScalingPolicyDescription & {
        Constraints: ScalingConstraints & {
            MinCapacity: number;
            MaxCapacity: number;
        };
        Rules: (ScalingRule & {
            Name: string;
            Action: ScalingAction & {
                SimpleScalingPolicyConfiguration: SimpleScalingPolicyConfiguration & {
                    ScalingAdjustment: number;
                };
            };
            Trigger: ScalingTrigger & {
                CloudWatchAlarmDefinition: CloudWatchAlarmDefinition & {
                    ComparisonOperator: ComparisonOperator;
                    MetricName: string;
                    Period: number;
                    Threshold: NonNegativeDouble;
                };
            };
        })[];
    };
    ClusterArn?: string;
}
export declare const PutAutoScalingPolicyOutput: S.Schema<PutAutoScalingPolicyOutput>;
export interface PutAutoTerminationPolicyInput {
    ClusterId?: string;
    AutoTerminationPolicy?: AutoTerminationPolicy;
}
export declare const PutAutoTerminationPolicyInput: S.Schema<PutAutoTerminationPolicyInput>;
export interface PutAutoTerminationPolicyOutput {
}
export declare const PutAutoTerminationPolicyOutput: S.Schema<PutAutoTerminationPolicyOutput>;
export interface PutBlockPublicAccessConfigurationInput {
    BlockPublicAccessConfiguration?: BlockPublicAccessConfiguration;
}
export declare const PutBlockPublicAccessConfigurationInput: S.Schema<PutBlockPublicAccessConfigurationInput>;
export interface PutBlockPublicAccessConfigurationOutput {
}
export declare const PutBlockPublicAccessConfigurationOutput: S.Schema<PutBlockPublicAccessConfigurationOutput>;
export interface PutManagedScalingPolicyInput {
    ClusterId?: string;
    ManagedScalingPolicy?: ManagedScalingPolicy;
}
export declare const PutManagedScalingPolicyInput: S.Schema<PutManagedScalingPolicyInput>;
export interface PutManagedScalingPolicyOutput {
}
export declare const PutManagedScalingPolicyOutput: S.Schema<PutManagedScalingPolicyOutput>;
export interface RemoveAutoScalingPolicyInput {
    ClusterId?: string;
    InstanceGroupId?: string;
}
export declare const RemoveAutoScalingPolicyInput: S.Schema<RemoveAutoScalingPolicyInput>;
export interface RemoveAutoScalingPolicyOutput {
}
export declare const RemoveAutoScalingPolicyOutput: S.Schema<RemoveAutoScalingPolicyOutput>;
export interface RemoveAutoTerminationPolicyInput {
    ClusterId?: string;
}
export declare const RemoveAutoTerminationPolicyInput: S.Schema<RemoveAutoTerminationPolicyInput>;
export interface RemoveAutoTerminationPolicyOutput {
}
export declare const RemoveAutoTerminationPolicyOutput: S.Schema<RemoveAutoTerminationPolicyOutput>;
export interface RemoveManagedScalingPolicyInput {
    ClusterId?: string;
}
export declare const RemoveManagedScalingPolicyInput: S.Schema<RemoveManagedScalingPolicyInput>;
export interface RemoveManagedScalingPolicyOutput {
}
export declare const RemoveManagedScalingPolicyOutput: S.Schema<RemoveManagedScalingPolicyOutput>;
export interface RemoveTagsInput {
    ResourceId?: string;
    TagKeys?: string[];
    ClusterId?: string;
}
export declare const RemoveTagsInput: S.Schema<RemoveTagsInput>;
export interface RemoveTagsOutput {
}
export declare const RemoveTagsOutput: S.Schema<RemoveTagsOutput>;
export type InstanceFleetConfigList = InstanceFleetConfig[];
export declare const InstanceFleetConfigList: any;
export type SecurityGroupsList = string[];
export declare const SecurityGroupsList: any;
export interface JobFlowInstancesConfig {
    MasterInstanceType?: string;
    SlaveInstanceType?: string;
    InstanceCount?: number;
    InstanceGroups?: InstanceGroupConfig[];
    InstanceFleets?: InstanceFleetConfig[];
    Ec2KeyName?: string;
    Placement?: PlacementType;
    KeepJobFlowAliveWhenNoSteps?: boolean;
    TerminationProtected?: boolean;
    UnhealthyNodeReplacement?: boolean;
    HadoopVersion?: string;
    Ec2SubnetId?: string;
    Ec2SubnetIds?: string[];
    EmrManagedMasterSecurityGroup?: string;
    EmrManagedSlaveSecurityGroup?: string;
    ServiceAccessSecurityGroup?: string;
    AdditionalMasterSecurityGroups?: string[];
    AdditionalSlaveSecurityGroups?: string[];
}
export declare const JobFlowInstancesConfig: S.Schema<JobFlowInstancesConfig>;
export type BootstrapActionConfigList = BootstrapActionConfig[];
export declare const BootstrapActionConfigList: any;
export interface SupportedProductConfig {
    Name?: string;
    Args?: string[];
}
export declare const SupportedProductConfig: S.Schema<SupportedProductConfig>;
export type NewSupportedProductsList = SupportedProductConfig[];
export declare const NewSupportedProductsList: any;
export interface RunJobFlowInput {
    Name?: string;
    LogUri?: string;
    LogEncryptionKmsKeyId?: string;
    AdditionalInfo?: string;
    AmiVersion?: string;
    ReleaseLabel?: string;
    Instances?: JobFlowInstancesConfig;
    Steps?: StepConfig[];
    StepExecutionRoleArn?: string;
    BootstrapActions?: BootstrapActionConfig[];
    SupportedProducts?: string[];
    NewSupportedProducts?: SupportedProductConfig[];
    Applications?: Application[];
    Configurations?: Configuration[];
    VisibleToAllUsers?: boolean;
    JobFlowRole?: string;
    ServiceRole?: string;
    Tags?: Tag[];
    SecurityConfiguration?: string;
    AutoScalingRole?: string;
    ScaleDownBehavior?: ScaleDownBehavior;
    CustomAmiId?: string;
    EbsRootVolumeSize?: number;
    RepoUpgradeOnBoot?: RepoUpgradeOnBoot;
    KerberosAttributes?: KerberosAttributes;
    StepConcurrencyLevel?: number;
    ManagedScalingPolicy?: ManagedScalingPolicy;
    PlacementGroupConfigs?: PlacementGroupConfig[];
    AutoTerminationPolicy?: AutoTerminationPolicy;
    OSReleaseLabel?: string;
    EbsRootVolumeIops?: number;
    EbsRootVolumeThroughput?: number;
    ExtendedSupport?: boolean;
    MonitoringConfiguration?: MonitoringConfiguration;
    SessionEnabled?: boolean;
}
export declare const RunJobFlowInput: S.Schema<RunJobFlowInput>;
export interface RunJobFlowOutput {
    JobFlowId?: string;
    ClusterArn?: string;
}
export declare const RunJobFlowOutput: S.Schema<RunJobFlowOutput>;
export interface SetKeepJobFlowAliveWhenNoStepsInput {
    JobFlowIds?: string[];
    KeepJobFlowAliveWhenNoSteps?: boolean;
}
export declare const SetKeepJobFlowAliveWhenNoStepsInput: S.Schema<SetKeepJobFlowAliveWhenNoStepsInput>;
export interface SetKeepJobFlowAliveWhenNoStepsResponse {
}
export declare const SetKeepJobFlowAliveWhenNoStepsResponse: S.Schema<SetKeepJobFlowAliveWhenNoStepsResponse>;
export interface SetTerminationProtectionInput {
    JobFlowIds?: string[];
    TerminationProtected?: boolean;
}
export declare const SetTerminationProtectionInput: S.Schema<SetTerminationProtectionInput>;
export interface SetTerminationProtectionResponse {
}
export declare const SetTerminationProtectionResponse: S.Schema<SetTerminationProtectionResponse>;
export interface SetUnhealthyNodeReplacementInput {
    JobFlowIds?: string[];
    UnhealthyNodeReplacement?: boolean;
}
export declare const SetUnhealthyNodeReplacementInput: S.Schema<SetUnhealthyNodeReplacementInput>;
export interface SetUnhealthyNodeReplacementResponse {
}
export declare const SetUnhealthyNodeReplacementResponse: S.Schema<SetUnhealthyNodeReplacementResponse>;
export interface SetVisibleToAllUsersInput {
    JobFlowIds?: string[];
    VisibleToAllUsers?: boolean;
}
export declare const SetVisibleToAllUsersInput: S.Schema<SetVisibleToAllUsersInput>;
export interface SetVisibleToAllUsersResponse {
}
export declare const SetVisibleToAllUsersResponse: S.Schema<SetVisibleToAllUsersResponse>;
export interface NotebookS3LocationFromInput {
    Bucket?: string;
    Key?: string;
}
export declare const NotebookS3LocationFromInput: S.Schema<NotebookS3LocationFromInput>;
export interface OutputNotebookS3LocationFromInput {
    Bucket?: string;
    Key?: string;
}
export declare const OutputNotebookS3LocationFromInput: S.Schema<OutputNotebookS3LocationFromInput>;
export interface StartNotebookExecutionInput {
    EditorId?: string;
    RelativePath?: string;
    NotebookExecutionName?: string;
    NotebookParams?: string;
    ExecutionEngine?: ExecutionEngineConfig;
    ServiceRole?: string;
    NotebookInstanceSecurityGroupId?: string;
    Tags?: Tag[];
    NotebookS3Location?: NotebookS3LocationFromInput;
    OutputNotebookS3Location?: OutputNotebookS3LocationFromInput;
    OutputNotebookFormat?: OutputNotebookFormat;
    EnvironmentVariables?: {
        [key: string]: string | undefined;
    };
}
export declare const StartNotebookExecutionInput: S.Schema<StartNotebookExecutionInput>;
export interface StartNotebookExecutionOutput {
    NotebookExecutionId?: string;
}
export declare const StartNotebookExecutionOutput: S.Schema<StartNotebookExecutionOutput>;
export type ClientRequestToken = string;
export interface StartSessionInput {
    Name?: string;
    ClusterId?: string;
    ExecutionRoleArn?: string;
    EngineConfigurations?: Configuration[];
    MonitoringConfiguration?: SessionMonitoringConfiguration;
    SessionIdleTimeoutInMinutes?: number;
    ClientRequestToken?: string;
    Tags?: Tag[];
}
export declare const StartSessionInput: S.Schema<StartSessionInput>;
export interface StartSessionOutput {
    Id: string;
    ClusterId?: string;
    Arn?: string;
    AccountId?: string;
    State?: SessionState;
}
export declare const StartSessionOutput: S.Schema<StartSessionOutput>;
export interface StopNotebookExecutionInput {
    NotebookExecutionId?: string;
}
export declare const StopNotebookExecutionInput: S.Schema<StopNotebookExecutionInput>;
export interface StopNotebookExecutionResponse {
}
export declare const StopNotebookExecutionResponse: S.Schema<StopNotebookExecutionResponse>;
export interface TerminateJobFlowsInput {
    JobFlowIds?: string[];
}
export declare const TerminateJobFlowsInput: S.Schema<TerminateJobFlowsInput>;
export interface TerminateJobFlowsResponse {
}
export declare const TerminateJobFlowsResponse: S.Schema<TerminateJobFlowsResponse>;
export interface TerminateSessionInput {
    ClusterId?: string;
    SessionId?: string;
}
export declare const TerminateSessionInput: S.Schema<TerminateSessionInput>;
export interface TerminateSessionOutput {
    ClusterId: string;
    SessionId: string;
    State: SessionState;
}
export declare const TerminateSessionOutput: S.Schema<TerminateSessionOutput>;
export interface UpdateStudioInput {
    StudioId?: string;
    Name?: string;
    Description?: string;
    SubnetIds?: string[];
    DefaultS3Location?: string;
    EncryptionKeyArn?: string;
}
export declare const UpdateStudioInput: S.Schema<UpdateStudioInput>;
export interface UpdateStudioResponse {
}
export declare const UpdateStudioResponse: S.Schema<UpdateStudioResponse>;
export interface UpdateStudioSessionMappingInput {
    StudioId?: string;
    IdentityId?: string;
    IdentityName?: string;
    IdentityType?: IdentityType;
    SessionPolicyArn?: string;
}
export declare const UpdateStudioSessionMappingInput: S.Schema<UpdateStudioSessionMappingInput>;
export interface UpdateStudioSessionMappingResponse {
}
export declare const UpdateStudioSessionMappingResponse: S.Schema<UpdateStudioSessionMappingResponse>;
export type ErrorMessage = string;
export type ErrorCode = string;
export type AddInstanceFleetError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Adds an instance fleet to a running cluster.
 *
 * The instance fleet configuration is available only in Amazon EMR releases
 * 4.8.0 and later, excluding 5.0.x.
 */
export declare const addInstanceFleet: API.OperationMethod<AddInstanceFleetInput, AddInstanceFleetOutput, AddInstanceFleetError, Creds | HttpClient.HttpClient>;
export type AddInstanceGroupsError = InternalServerError | CommonErrors;
/**
 * Adds one or more instance groups to a running cluster.
 */
export declare const addInstanceGroups: API.OperationMethod<AddInstanceGroupsInput, AddInstanceGroupsOutput, AddInstanceGroupsError, Creds | HttpClient.HttpClient>;
export type AddJobFlowStepsError = InternalServerError | CommonErrors;
/**
 * AddJobFlowSteps adds new steps to a running cluster. A maximum of 256 steps are allowed
 * in each job flow.
 *
 * If your cluster is long-running (such as a Hive data warehouse) or complex, you may
 * require more than 256 steps to process your data. You can bypass the 256-step limitation in
 * various ways, including using SSH to connect to the master node and submitting queries
 * directly to the software running on the master node, such as Hive and Hadoop.
 *
 * A step specifies the location of a JAR file stored either on the master node of the
 * cluster or in Amazon S3. Each step is performed by the main function of the main
 * class of the JAR file. The main class can be specified either in the manifest of the JAR or
 * by using the MainFunction parameter of the step.
 *
 * Amazon EMR executes each step in the order listed. For a step to be considered
 * complete, the main function must exit with a zero exit code and all Hadoop jobs started
 * while the step was running must have completed and run successfully.
 *
 * You can only add steps to a cluster that is in one of the following states: STARTING,
 * BOOTSTRAPPING, RUNNING, or WAITING.
 *
 * The string values passed into `HadoopJarStep` object cannot exceed a total
 * of 10240 characters.
 */
export declare const addJobFlowSteps: API.OperationMethod<AddJobFlowStepsInput, AddJobFlowStepsOutput, AddJobFlowStepsError, Creds | HttpClient.HttpClient>;
export type AddTagsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Adds tags to an Amazon EMR resource, such as a cluster or an Amazon EMR
 * Studio. Tags make it easier to associate resources in various ways, such as grouping
 * clusters to track your Amazon EMR resource allocation costs. For more information,
 * see Tag
 * Clusters.
 */
export declare const addTags: API.OperationMethod<AddTagsInput, AddTagsOutput, AddTagsError, Creds | HttpClient.HttpClient>;
export type CancelStepsError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Cancels a pending step or steps in a running cluster. Available only in Amazon EMR versions 4.8.0 and later, excluding version 5.0.0. A maximum of 256 steps are allowed in
 * each CancelSteps request. CancelSteps is idempotent but asynchronous; it does not guarantee
 * that a step will be canceled, even if the request is successfully submitted. When you use
 * Amazon EMR releases 5.28.0 and later, you can cancel steps that are in a
 * `PENDING` or `RUNNING` state. In earlier versions of Amazon EMR, you can only cancel steps that are in a `PENDING` state.
 */
export declare const cancelSteps: API.OperationMethod<CancelStepsInput, CancelStepsOutput, CancelStepsError, Creds | HttpClient.HttpClient>;
export type CreatePersistentAppUIError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates a persistent application user interface.
 */
export declare const createPersistentAppUI: API.OperationMethod<CreatePersistentAppUIInput, CreatePersistentAppUIOutput, CreatePersistentAppUIError, Creds | HttpClient.HttpClient>;
export type CreateSecurityConfigurationError = InternalServerException | InvalidRequestException | SecurityConfigurationAlreadyExists | CommonErrors;
/**
 * Creates a security configuration, which is stored in the service and can be specified
 * when a cluster is created.
 */
export declare const createSecurityConfiguration: API.OperationMethod<CreateSecurityConfigurationInput, CreateSecurityConfigurationOutput, CreateSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type CreateStudioError = InternalServerException | InvalidRequestException | StudioServiceRoleNotAssumable | StudioServiceRoleMissingS3Access | CommonErrors;
/**
 * Creates a new Amazon EMR Studio.
 */
export declare const createStudio: API.OperationMethod<CreateStudioInput, CreateStudioOutput, CreateStudioError, Creds | HttpClient.HttpClient>;
export type CreateStudioSessionMappingError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Maps a user or group to the Amazon EMR Studio specified by
 * `StudioId`, and applies a session policy to refine Studio permissions for that
 * user or group. Use `CreateStudioSessionMapping` to assign users to a Studio when
 * you use IAM Identity Center authentication. For instructions on how to assign users to a
 * Studio when you use IAM authentication, see Assign a user or group to your EMR Studio.
 */
export declare const createStudioSessionMapping: API.OperationMethod<CreateStudioSessionMappingInput, CreateStudioSessionMappingResponse, CreateStudioSessionMappingError, Creds | HttpClient.HttpClient>;
export type DeleteSecurityConfigurationError = InternalServerException | InvalidRequestException | SecurityConfigurationNotFound | CommonErrors;
/**
 * Deletes a security configuration.
 */
export declare const deleteSecurityConfiguration: API.OperationMethod<DeleteSecurityConfigurationInput, DeleteSecurityConfigurationOutput, DeleteSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type DeleteStudioError = InternalServerException | InvalidRequestException | StudioNotFound | CommonErrors;
/**
 * Removes an Amazon EMR Studio from the Studio metadata store.
 */
export declare const deleteStudio: API.OperationMethod<DeleteStudioInput, DeleteStudioResponse, DeleteStudioError, Creds | HttpClient.HttpClient>;
export type DeleteStudioSessionMappingError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Removes a user or group from an Amazon EMR Studio.
 */
export declare const deleteStudioSessionMapping: API.OperationMethod<DeleteStudioSessionMappingInput, DeleteStudioSessionMappingResponse, DeleteStudioSessionMappingError, Creds | HttpClient.HttpClient>;
export type DescribeClusterError = InternalServerException | InvalidRequestException | ClusterNotFound | CommonErrors;
/**
 * Provides cluster-level details including status, hardware and software configuration,
 * VPC settings, and so on.
 */
export declare const describeCluster: API.OperationMethod<DescribeClusterInput, DescribeClusterOutput, DescribeClusterError, Creds | HttpClient.HttpClient>;
export type DescribeJobFlowsError = InternalServerError | CommonErrors;
/**
 * This API is no longer supported and will eventually be removed. We recommend you use
 * ListClusters, DescribeCluster, ListSteps, ListInstanceGroups and ListBootstrapActions instead.
 *
 * DescribeJobFlows returns a list of job flows that match all of the supplied parameters.
 * The parameters can include a list of job flow IDs, job flow states, and restrictions on job
 * flow creation date and time.
 *
 * Regardless of supplied parameters, only job flows created within the last two months are
 * returned.
 *
 * If no parameters are supplied, then job flows matching either of the following criteria
 * are returned:
 *
 * - Job flows created and completed in the last two weeks
 *
 * - Job flows created within the last two months that are in one of the following
 * states: `RUNNING`, `WAITING`, `SHUTTING_DOWN`,
 * `STARTING`
 *
 * Amazon EMR can return a maximum of 512 job flow descriptions.
 */
export declare const describeJobFlows: API.OperationMethod<DescribeJobFlowsInput, DescribeJobFlowsOutput, DescribeJobFlowsError, Creds | HttpClient.HttpClient>;
export type DescribeNotebookExecutionError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Provides details of a notebook execution.
 */
export declare const describeNotebookExecution: API.OperationMethod<DescribeNotebookExecutionInput, DescribeNotebookExecutionOutput, DescribeNotebookExecutionError, Creds | HttpClient.HttpClient>;
export type DescribePersistentAppUIError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Describes a persistent application user interface.
 */
export declare const describePersistentAppUI: API.OperationMethod<DescribePersistentAppUIInput, DescribePersistentAppUIOutput, DescribePersistentAppUIError, Creds | HttpClient.HttpClient>;
export type DescribeReleaseLabelError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides Amazon EMR release label details, such as the releases available the
 * Region where the API request is run, and the available applications for a specific Amazon EMR release label. Can also list Amazon EMR releases that support a
 * specified version of Spark.
 */
export declare const describeReleaseLabel: API.OperationMethod<DescribeReleaseLabelInput, DescribeReleaseLabelOutput, DescribeReleaseLabelError, Creds | HttpClient.HttpClient>;
export type DescribeSecurityConfigurationError = InternalServerException | InvalidRequestException | SecurityConfigurationNotFound | CommonErrors;
/**
 * Provides the details of a security configuration by returning the configuration
 * JSON.
 */
export declare const describeSecurityConfiguration: API.OperationMethod<DescribeSecurityConfigurationInput, DescribeSecurityConfigurationOutput, DescribeSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type DescribeStepError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides more detail about the cluster step.
 */
export declare const describeStep: API.OperationMethod<DescribeStepInput, DescribeStepOutput, DescribeStepError, Creds | HttpClient.HttpClient>;
export type DescribeStudioError = InternalServerException | InvalidRequestException | StudioNotFound | CommonErrors;
/**
 * Returns details for the specified Amazon EMR Studio including ID, Name, VPC,
 * Studio access URL, and so on.
 */
export declare const describeStudio: API.OperationMethod<DescribeStudioInput, DescribeStudioOutput, DescribeStudioError, Creds | HttpClient.HttpClient>;
export type GetAutoTerminationPolicyError = CommonErrors;
/**
 * Returns the auto-termination policy for an Amazon EMR cluster.
 */
export declare const getAutoTerminationPolicy: API.OperationMethod<GetAutoTerminationPolicyInput, GetAutoTerminationPolicyOutput, GetAutoTerminationPolicyError, Creds | HttpClient.HttpClient>;
export type GetBlockPublicAccessConfigurationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns the Amazon EMR block public access configuration for your Amazon Web Services account in the current Region. For more information see Configure Block
 * Public Access for Amazon EMR in the Amazon EMR
 * Management Guide.
 */
export declare const getBlockPublicAccessConfiguration: API.OperationMethod<GetBlockPublicAccessConfigurationInput, GetBlockPublicAccessConfigurationOutput, GetBlockPublicAccessConfigurationError, Creds | HttpClient.HttpClient>;
export type GetClusterSessionCredentialsError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Provides temporary, HTTP basic credentials that are associated with a given runtime
 * IAM role and used by a cluster with fine-grained access control
 * activated. You can use these credentials to connect to cluster endpoints that support
 * username and password authentication.
 */
export declare const getClusterSessionCredentials: API.OperationMethod<GetClusterSessionCredentialsInput, GetClusterSessionCredentialsOutput, GetClusterSessionCredentialsError, Creds | HttpClient.HttpClient>;
export type GetManagedScalingPolicyError = CommonErrors;
/**
 * Fetches the attached managed scaling policy for an Amazon EMR cluster.
 */
export declare const getManagedScalingPolicy: API.OperationMethod<GetManagedScalingPolicyInput, GetManagedScalingPolicyOutput, GetManagedScalingPolicyError, Creds | HttpClient.HttpClient>;
export type GetOnClusterAppUIPresignedURLError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * The presigned URL properties for the cluster's application user interface.
 */
export declare const getOnClusterAppUIPresignedURL: API.OperationMethod<GetOnClusterAppUIPresignedURLInput, GetOnClusterAppUIPresignedURLOutput, GetOnClusterAppUIPresignedURLError, Creds | HttpClient.HttpClient>;
export type GetPersistentAppUIPresignedURLError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * The presigned URL properties for the cluster's application user interface.
 */
export declare const getPersistentAppUIPresignedURL: API.OperationMethod<GetPersistentAppUIPresignedURLInput, GetPersistentAppUIPresignedURLOutput, GetPersistentAppUIPresignedURLError, Creds | HttpClient.HttpClient>;
export type GetSessionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns detailed information about a session.
 */
export declare const getSession: API.OperationMethod<GetSessionInput, GetSessionOutput, GetSessionError, Creds | HttpClient.HttpClient>;
export type GetSessionEndpointError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns the Spark Connect endpoint URL and a time-limited authentication token for the specified session. Use the endpoint and token to connect a PySpark client to the session. Call this operation again when the token expires to obtain a new one.
 */
export declare const getSessionEndpoint: API.OperationMethod<GetSessionEndpointInput, GetSessionEndpointOutput, GetSessionEndpointError, Creds | HttpClient.HttpClient>;
export type GetStudioSessionMappingError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Fetches mapping details for the specified Amazon EMR Studio and identity (user
 * or group).
 */
export declare const getStudioSessionMapping: API.OperationMethod<GetStudioSessionMappingInput, GetStudioSessionMappingOutput, GetStudioSessionMappingError, Creds | HttpClient.HttpClient>;
export type ListBootstrapActionsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides information about the bootstrap actions associated with a cluster.
 */
export declare const listBootstrapActions: API.PaginatedOperationMethod<ListBootstrapActionsInput, ListBootstrapActionsOutput, ListBootstrapActionsError, Creds | HttpClient.HttpClient, Command>;
export type ListClustersError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides the status of all clusters visible to this Amazon Web Services account. Allows
 * you to filter the list of clusters based on certain criteria; for example, filtering by
 * cluster creation date and time or by status. This call returns a maximum of 50 clusters in
 * unsorted order per call, but returns a marker to track the paging of the cluster list
 * across multiple ListClusters calls.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersInput, ListClustersOutput, ListClustersError, Creds | HttpClient.HttpClient, ClusterSummary>;
export type ListInstanceFleetsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists all available details about the instance fleets in a cluster.
 *
 * The instance fleet configuration is available only in Amazon EMR releases
 * 4.8.0 and later, excluding 5.0.x versions.
 */
export declare const listInstanceFleets: API.PaginatedOperationMethod<ListInstanceFleetsInput, ListInstanceFleetsOutput, ListInstanceFleetsError, Creds | HttpClient.HttpClient, InstanceFleet>;
export type ListInstanceGroupsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides all available details about the instance groups in a cluster.
 */
export declare const listInstanceGroups: API.PaginatedOperationMethod<ListInstanceGroupsInput, ListInstanceGroupsOutput, ListInstanceGroupsError, Creds | HttpClient.HttpClient, InstanceGroup>;
export type ListInstancesError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides information for all active Amazon EC2 instances and Amazon EC2
 * instances terminated in the last 30 days, up to a maximum of 2,000. Amazon EC2
 * instances in any of the following states are considered active: AWAITING_FULFILLMENT,
 * PROVISIONING, BOOTSTRAPPING, RUNNING.
 */
export declare const listInstances: API.PaginatedOperationMethod<ListInstancesInput, ListInstancesOutput, ListInstancesError, Creds | HttpClient.HttpClient, Instance>;
export type ListNotebookExecutionsError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Provides summaries of all notebook executions. You can filter the list based on multiple
 * criteria such as status, time range, and editor id. Returns a maximum of 50 notebook
 * executions and a marker to track the paging of a longer notebook execution list across
 * multiple `ListNotebookExecutions` calls.
 */
export declare const listNotebookExecutions: API.PaginatedOperationMethod<ListNotebookExecutionsInput, ListNotebookExecutionsOutput, ListNotebookExecutionsError, Creds | HttpClient.HttpClient, NotebookExecutionSummary>;
export type ListReleaseLabelsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Retrieves release labels of Amazon EMR services in the Region where the API is
 * called.
 */
export declare const listReleaseLabels: API.PaginatedOperationMethod<ListReleaseLabelsInput, ListReleaseLabelsOutput, ListReleaseLabelsError, Creds | HttpClient.HttpClient, unknown>;
export type ListSecurityConfigurationsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists all the security configurations visible to this account, providing their creation
 * dates and times, and their names. This call returns a maximum of 50 clusters per call, but
 * returns a marker to track the paging of the cluster list across multiple
 * ListSecurityConfigurations calls.
 */
export declare const listSecurityConfigurations: API.PaginatedOperationMethod<ListSecurityConfigurationsInput, ListSecurityConfigurationsOutput, ListSecurityConfigurationsError, Creds | HttpClient.HttpClient, SecurityConfigurationSummary>;
export type ListSessionsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists the sessions on a cluster. You can filter the results by session state. Newer sessions are returned first.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsInput, ListSessionsOutput, ListSessionsError, Creds | HttpClient.HttpClient, Session>;
export type ListStepsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides a list of steps for the cluster in reverse order unless you specify
 * `stepIds` with the request or filter by `StepStates`. You can
 * specify a maximum of 10 `stepIDs`. The CLI automatically
 * paginates results to return a list greater than 50 steps. To return more than 50 steps
 * using the CLI, specify a `Marker`, which is a pagination token
 * that indicates the next set of steps to retrieve.
 */
export declare const listSteps: API.PaginatedOperationMethod<ListStepsInput, ListStepsOutput, ListStepsError, Creds | HttpClient.HttpClient, StepSummary>;
export type ListStudiosError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of all Amazon EMR Studios associated with the Amazon Web Services account. The list includes details such as ID, Studio Access URL, and
 * creation time for each Studio.
 */
export declare const listStudios: API.PaginatedOperationMethod<ListStudiosInput, ListStudiosOutput, ListStudiosError, Creds | HttpClient.HttpClient, StudioSummary>;
export type ListStudioSessionMappingsError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Returns a list of all user or group session mappings for the Amazon EMR Studio
 * specified by `StudioId`.
 */
export declare const listStudioSessionMappings: API.PaginatedOperationMethod<ListStudioSessionMappingsInput, ListStudioSessionMappingsOutput, ListStudioSessionMappingsError, Creds | HttpClient.HttpClient, SessionMappingSummary>;
export type ListSupportedInstanceTypesError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * A list of the instance types that Amazon EMR supports. You can filter the
 * list by Amazon Web Services Region and Amazon EMR release.
 */
export declare const listSupportedInstanceTypes: API.PaginatedOperationMethod<ListSupportedInstanceTypesInput, ListSupportedInstanceTypesOutput, ListSupportedInstanceTypesError, Creds | HttpClient.HttpClient, unknown>;
export type ModifyClusterError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Modifies the number of steps that can be executed concurrently for the cluster specified
 * using ClusterID.
 */
export declare const modifyCluster: API.OperationMethod<ModifyClusterInput, ModifyClusterOutput, ModifyClusterError, Creds | HttpClient.HttpClient>;
export type ModifyInstanceFleetError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Modifies the target On-Demand and target Spot capacities for the instance fleet with the
 * specified InstanceFleetID within the cluster specified using ClusterID. The call either
 * succeeds or fails atomically.
 *
 * The instance fleet configuration is available only in Amazon EMR releases
 * 4.8.0 and later, excluding 5.0.x versions.
 */
export declare const modifyInstanceFleet: API.OperationMethod<ModifyInstanceFleetInput, ModifyInstanceFleetResponse, ModifyInstanceFleetError, Creds | HttpClient.HttpClient>;
export type ModifyInstanceGroupsError = InternalServerError | CommonErrors;
/**
 * ModifyInstanceGroups modifies the number of nodes and configuration settings of an
 * instance group. The input parameters include the new target instance count for the group
 * and the instance group ID. The call will either succeed or fail atomically.
 */
export declare const modifyInstanceGroups: API.OperationMethod<ModifyInstanceGroupsInput, ModifyInstanceGroupsResponse, ModifyInstanceGroupsError, Creds | HttpClient.HttpClient>;
export type PutAutoScalingPolicyError = CommonErrors;
/**
 * Creates or updates an automatic scaling policy for a core instance group or task
 * instance group in an Amazon EMR cluster. The automatic scaling policy defines how
 * an instance group dynamically adds and terminates Amazon EC2 instances in response
 * to the value of a CloudWatch metric.
 */
export declare const putAutoScalingPolicy: API.OperationMethod<PutAutoScalingPolicyInput, PutAutoScalingPolicyOutput, PutAutoScalingPolicyError, Creds | HttpClient.HttpClient>;
export type PutAutoTerminationPolicyError = CommonErrors;
/**
 * Auto-termination is supported in Amazon EMR releases 5.30.0 and 6.1.0 and
 * later. For more information, see Using an
 * auto-termination policy.
 *
 * Creates or updates an auto-termination policy for an Amazon EMR cluster. An
 * auto-termination policy defines the amount of idle time in seconds after which a cluster
 * automatically terminates. For alternative cluster termination options, see Control
 * cluster termination.
 */
export declare const putAutoTerminationPolicy: API.OperationMethod<PutAutoTerminationPolicyInput, PutAutoTerminationPolicyOutput, PutAutoTerminationPolicyError, Creds | HttpClient.HttpClient>;
export type PutBlockPublicAccessConfigurationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates or updates an Amazon EMR block public access configuration for your
 * Amazon Web Services account in the current Region. For more information see Configure Block
 * Public Access for Amazon EMR in the Amazon EMR
 * Management Guide.
 */
export declare const putBlockPublicAccessConfiguration: API.OperationMethod<PutBlockPublicAccessConfigurationInput, PutBlockPublicAccessConfigurationOutput, PutBlockPublicAccessConfigurationError, Creds | HttpClient.HttpClient>;
export type PutManagedScalingPolicyError = CommonErrors;
/**
 * Creates or updates a managed scaling policy for an Amazon EMR cluster. The
 * managed scaling policy defines the limits for resources, such as Amazon EC2
 * instances that can be added or terminated from a cluster. The policy only applies to the
 * core and task nodes. The master node cannot be scaled after initial configuration.
 */
export declare const putManagedScalingPolicy: API.OperationMethod<PutManagedScalingPolicyInput, PutManagedScalingPolicyOutput, PutManagedScalingPolicyError, Creds | HttpClient.HttpClient>;
export type RemoveAutoScalingPolicyError = CommonErrors;
/**
 * Removes an automatic scaling policy from a specified instance group within an Amazon EMR cluster.
 */
export declare const removeAutoScalingPolicy: API.OperationMethod<RemoveAutoScalingPolicyInput, RemoveAutoScalingPolicyOutput, RemoveAutoScalingPolicyError, Creds | HttpClient.HttpClient>;
export type RemoveAutoTerminationPolicyError = CommonErrors;
/**
 * Removes an auto-termination policy from an Amazon EMR cluster.
 */
export declare const removeAutoTerminationPolicy: API.OperationMethod<RemoveAutoTerminationPolicyInput, RemoveAutoTerminationPolicyOutput, RemoveAutoTerminationPolicyError, Creds | HttpClient.HttpClient>;
export type RemoveManagedScalingPolicyError = CommonErrors;
/**
 * Removes a managed scaling policy from a specified Amazon EMR cluster.
 */
export declare const removeManagedScalingPolicy: API.OperationMethod<RemoveManagedScalingPolicyInput, RemoveManagedScalingPolicyOutput, RemoveManagedScalingPolicyError, Creds | HttpClient.HttpClient>;
export type RemoveTagsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Removes tags from an Amazon EMR resource, such as a cluster or Amazon EMR Studio. Tags make it easier to associate resources in various ways, such as grouping
 * clusters to track your Amazon EMR resource allocation costs. For more information,
 * see Tag
 * Clusters.
 *
 * The following example removes the stack tag with value Prod from a cluster:
 */
export declare const removeTags: API.OperationMethod<RemoveTagsInput, RemoveTagsOutput, RemoveTagsError, Creds | HttpClient.HttpClient>;
export type RunJobFlowError = InternalServerError | CommonErrors;
/**
 * RunJobFlow creates and starts running a new cluster (job flow). The cluster runs the
 * steps specified. After the steps complete, the cluster stops and the HDFS partition is
 * lost. To prevent loss of data, configure the last step of the job flow to store results in
 * Amazon S3. If the JobFlowInstancesConfig
 * `KeepJobFlowAliveWhenNoSteps` parameter is set to `TRUE`, the cluster
 * transitions to the WAITING state rather than shutting down after the steps have completed.
 *
 * For additional protection, you can set the JobFlowInstancesConfig
 * `TerminationProtected` parameter to `TRUE` to lock the cluster and
 * prevent it from being terminated by API call, user intervention, or in the event of a job
 * flow error.
 *
 * A maximum of 256 steps are allowed in each job flow.
 *
 * If your cluster is long-running (such as a Hive data warehouse) or complex, you may
 * require more than 256 steps to process your data. You can bypass the 256-step limitation in
 * various ways, including using the SSH shell to connect to the master node and submitting
 * queries directly to the software running on the master node, such as Hive and
 * Hadoop.
 *
 * For long-running clusters, we recommend that you periodically store your results.
 *
 * The instance fleets configuration is available only in Amazon EMR releases
 * 4.8.0 and later, excluding 5.0.x versions. The RunJobFlow request can contain
 * InstanceFleets parameters or InstanceGroups parameters, but not both.
 */
export declare const runJobFlow: API.OperationMethod<RunJobFlowInput, RunJobFlowOutput, RunJobFlowError, Creds | HttpClient.HttpClient>;
export type SetKeepJobFlowAliveWhenNoStepsError = InternalServerError | CommonErrors;
/**
 * You can use the `SetKeepJobFlowAliveWhenNoSteps` to configure a cluster (job flow) to terminate after the step execution, i.e., all your
 * steps are executed. If you want a transient cluster that shuts down after the last of the current executing steps are completed,
 * you can configure `SetKeepJobFlowAliveWhenNoSteps` to false. If you want a long running cluster, configure `SetKeepJobFlowAliveWhenNoSteps` to true.
 *
 * For more information, see Managing Cluster Termination in the *Amazon EMR Management Guide*.
 */
export declare const setKeepJobFlowAliveWhenNoSteps: API.OperationMethod<SetKeepJobFlowAliveWhenNoStepsInput, SetKeepJobFlowAliveWhenNoStepsResponse, SetKeepJobFlowAliveWhenNoStepsError, Creds | HttpClient.HttpClient>;
export type SetTerminationProtectionError = InternalServerError | JobFlowNotFound | CommonErrors;
/**
 * SetTerminationProtection locks a cluster (job flow) so the Amazon EC2 instances
 * in the cluster cannot be terminated by user intervention, an API call, or in the event of a
 * job-flow error. The cluster still terminates upon successful completion of the job flow.
 * Calling `SetTerminationProtection` on a cluster is similar to calling the
 * Amazon EC2
 * `DisableAPITermination` API on all Amazon EC2 instances in a
 * cluster.
 *
 * `SetTerminationProtection` is used to prevent accidental termination of a
 * cluster and to ensure that in the event of an error, the instances persist so that you can
 * recover any data stored in their ephemeral instance storage.
 *
 * To terminate a cluster that has been locked by setting
 * `SetTerminationProtection` to `true`, you must first unlock the
 * job flow by a subsequent call to `SetTerminationProtection` in which you set the
 * value to `false`.
 *
 * For more information, see Managing Cluster
 * Termination in the *Amazon EMR Management Guide*.
 */
export declare const setTerminationProtection: API.OperationMethod<SetTerminationProtectionInput, SetTerminationProtectionResponse, SetTerminationProtectionError, Creds | HttpClient.HttpClient>;
export type SetUnhealthyNodeReplacementError = InternalServerError | CommonErrors;
/**
 * Specify whether to enable unhealthy node replacement, which lets Amazon EMR gracefully
 * replace core nodes on a cluster if any nodes become unhealthy. For example, a node becomes
 * unhealthy if disk usage is above 90%. If unhealthy node replacement is on and `TerminationProtected` are off,
 * Amazon EMR immediately terminates the unhealthy core nodes. To use unhealthy node replacement
 * and retain unhealthy core nodes, use to turn on
 * termination protection. In such cases, Amazon EMR adds
 * the unhealthy nodes to a denylist, reducing job interruptions and failures.
 *
 * If unhealthy node replacement is on, Amazon EMR
 * notifies YARN and other applications on the cluster to stop scheduling tasks
 * with these nodes, moves the data, and then terminates the nodes.
 *
 * For more information, see graceful
 * node replacement in the *Amazon EMR Management Guide*.
 */
export declare const setUnhealthyNodeReplacement: API.OperationMethod<SetUnhealthyNodeReplacementInput, SetUnhealthyNodeReplacementResponse, SetUnhealthyNodeReplacementError, Creds | HttpClient.HttpClient>;
export type SetVisibleToAllUsersError = InternalServerError | CommonErrors;
/**
 * The SetVisibleToAllUsers parameter is no longer supported. Your cluster may be
 * visible to all users in your account. To restrict cluster access using an IAM policy, see Identity and Access
 * Management for Amazon EMR.
 *
 * Sets the Cluster$VisibleToAllUsers value for an Amazon EMR
 * cluster. When `true`, IAM principals in the Amazon Web Services account can perform Amazon EMR cluster actions that their IAM policies allow. When `false`, only the IAM
 * principal that created the cluster and the Amazon Web Services account root user can perform
 * Amazon EMR actions on the cluster, regardless of IAM permissions
 * policies attached to other IAM principals.
 *
 * This action works on running clusters. When you create a cluster, use the RunJobFlowInput$VisibleToAllUsers parameter.
 *
 * For more information, see Understanding the Amazon EMR Cluster VisibleToAllUsers Setting in the
 * *Amazon EMR Management Guide*.
 */
export declare const setVisibleToAllUsers: API.OperationMethod<SetVisibleToAllUsersInput, SetVisibleToAllUsersResponse, SetVisibleToAllUsersError, Creds | HttpClient.HttpClient>;
export type StartNotebookExecutionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Starts a notebook execution.
 */
export declare const startNotebookExecution: API.OperationMethod<StartNotebookExecutionInput, StartNotebookExecutionOutput, StartNotebookExecutionError, Creds | HttpClient.HttpClient>;
export type StartSessionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates and starts a new Spark Connect session on the specified cluster. The cluster must be in the `RUNNING` or `WAITING` state and have sessions enabled. This operation is supported in Amazon EMR Spark 8.0.0 and later.
 */
export declare const startSession: API.OperationMethod<StartSessionInput, StartSessionOutput, StartSessionError, Creds | HttpClient.HttpClient>;
export type StopNotebookExecutionError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Stops a notebook execution.
 */
export declare const stopNotebookExecution: API.OperationMethod<StopNotebookExecutionInput, StopNotebookExecutionResponse, StopNotebookExecutionError, Creds | HttpClient.HttpClient>;
export type TerminateJobFlowsError = InternalServerError | JobFlowNotFound | CommonErrors;
/**
 * TerminateJobFlows shuts a list of clusters (job flows) down. When a job flow is shut
 * down, any step not yet completed is canceled and the Amazon EC2 instances on which
 * the cluster is running are stopped. Any log files not already saved are uploaded to Amazon S3 if a LogUri was specified when the cluster was created.
 *
 * The maximum number of clusters allowed is 10. The call to `TerminateJobFlows`
 * is asynchronous. Depending on the configuration of the cluster, it may take up to 1-5
 * minutes for the cluster to completely terminate and release allocated resources, such as
 * Amazon EC2 instances.
 */
export declare const terminateJobFlows: API.OperationMethod<TerminateJobFlowsInput, TerminateJobFlowsResponse, TerminateJobFlowsError, Creds | HttpClient.HttpClient>;
export type TerminateSessionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Terminates an active session. After you call this operation, the session enters the `TERMINATING` state and then transitions to `TERMINATED`.
 */
export declare const terminateSession: API.OperationMethod<TerminateSessionInput, TerminateSessionOutput, TerminateSessionError, Creds | HttpClient.HttpClient>;
export type UpdateStudioError = InternalServerException | InvalidRequestException | StudioNotFound | CommonErrors;
/**
 * Updates an Amazon EMR Studio configuration, including attributes such as name,
 * description, and subnets.
 */
export declare const updateStudio: API.OperationMethod<UpdateStudioInput, UpdateStudioResponse, UpdateStudioError, Creds | HttpClient.HttpClient>;
export type UpdateStudioSessionMappingError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Updates the session policy attached to the user or group for the specified Amazon EMR Studio.
 */
export declare const updateStudioSessionMapping: API.OperationMethod<UpdateStudioSessionMappingInput, UpdateStudioSessionMappingResponse, UpdateStudioSessionMappingError, Creds | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=emr.d.ts.map