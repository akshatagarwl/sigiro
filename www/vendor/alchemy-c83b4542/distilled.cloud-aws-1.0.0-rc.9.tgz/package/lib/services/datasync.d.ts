import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalException_base: S.Class<InternalException, S.TaggedStruct<"InternalException", {
    readonly message: any;
    readonly errorCode: any;
}>, import("effect/Cause").YieldableError>;
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
    readonly errorCode: any;
    readonly datasyncErrorCode: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LocationAccessTestFailed_base: S.Class<LocationAccessTestFailed, S.TaggedStruct<"LocationAccessTestFailed", {
    readonly message: any;
    readonly errorCode: any;
    readonly datasyncErrorCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LocationAccessTestFailed extends /*@__PURE__*/ LocationAccessTestFailed_base {
}
declare const LocationNotFound_base: S.Class<LocationNotFound, S.TaggedStruct<"LocationNotFound", {
    readonly message: any;
    readonly errorCode: any;
    readonly datasyncErrorCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class LocationNotFound extends /*@__PURE__*/ LocationNotFound_base {
}
declare const LocationRoleNotAssumable_base: S.Class<LocationRoleNotAssumable, S.TaggedStruct<"LocationRoleNotAssumable", {
    readonly message: any;
    readonly errorCode: any;
    readonly datasyncErrorCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LocationRoleNotAssumable extends /*@__PURE__*/ LocationRoleNotAssumable_base {
}
declare const TaskNotFound_base: S.Class<TaskNotFound, S.TaggedStruct<"TaskNotFound", {
    readonly message: any;
    readonly errorCode: any;
    readonly datasyncErrorCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class TaskNotFound extends /*@__PURE__*/ TaskNotFound_base {
}
export type TaskExecutionArn = string;
export interface CancelTaskExecutionRequest {
    TaskExecutionArn: string;
}
export declare const CancelTaskExecutionRequest: S.Schema<CancelTaskExecutionRequest>;
export interface CancelTaskExecutionResponse {
}
export declare const CancelTaskExecutionResponse: S.Schema<CancelTaskExecutionResponse>;
export type ActivationKey = string;
export type TagValue = string;
export type TagKey = string;
export interface TagListEntry {
    Key: string;
    Value?: string;
}
export declare const TagListEntry: S.Schema<TagListEntry>;
export type InputTagList = TagListEntry[];
export declare const InputTagList: any;
export type VpcEndpointId = string;
export type Ec2SubnetArn = string;
export type PLSubnetArnList = string[];
export declare const PLSubnetArnList: any;
export type Ec2SecurityGroupArn = string;
export type PLSecurityGroupArnList = string[];
export declare const PLSecurityGroupArnList: any;
export interface CreateAgentRequest {
    ActivationKey: string;
    AgentName?: string;
    Tags?: TagListEntry[];
    VpcEndpointId?: string;
    SubnetArns?: string[];
    SecurityGroupArns?: string[];
}
export declare const CreateAgentRequest: S.Schema<CreateAgentRequest>;
export type AgentArn = string;
export interface CreateAgentResponse {
    AgentArn?: string;
}
export declare const CreateAgentResponse: S.Schema<CreateAgentResponse>;
export type AzureBlobContainerUrl = string;
export type AzureBlobAuthenticationType = "SAS" | "NONE" | (string & {});
export declare const AzureBlobAuthenticationType: any;
export type AzureBlobSasToken = string | redacted.Redacted<string>;
export interface AzureBlobSasConfiguration {
    Token: string | redacted.Redacted<string>;
}
export declare const AzureBlobSasConfiguration: S.Schema<AzureBlobSasConfiguration>;
export type AzureBlobType = "BLOCK" | (string & {});
export declare const AzureBlobType: any;
export type AzureAccessTier = "HOT" | "COOL" | "ARCHIVE" | (string & {});
export declare const AzureAccessTier: any;
export type AzureBlobSubdirectory = string;
export type AgentArnList = string[];
export declare const AgentArnList: any;
export type SecretArn = string;
export type KmsKeyArn = string;
export interface CmkSecretConfig {
    SecretArn?: string;
    KmsKeyArn?: string;
}
export declare const CmkSecretConfig: S.Schema<CmkSecretConfig>;
export type IamRoleArnOrEmptyString = string;
export interface CustomSecretConfig {
    SecretArn?: string;
    SecretAccessRoleArn?: string;
}
export declare const CustomSecretConfig: S.Schema<CustomSecretConfig>;
export interface CreateLocationAzureBlobRequest {
    ContainerUrl: string;
    AuthenticationType: AzureBlobAuthenticationType;
    SasConfiguration?: AzureBlobSasConfiguration;
    BlobType?: AzureBlobType;
    AccessTier?: AzureAccessTier;
    Subdirectory?: string;
    AgentArns?: string[];
    Tags?: TagListEntry[];
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const CreateLocationAzureBlobRequest: S.Schema<CreateLocationAzureBlobRequest>;
export type LocationArn = string;
export interface CreateLocationAzureBlobResponse {
    LocationArn?: string;
}
export declare const CreateLocationAzureBlobResponse: S.Schema<CreateLocationAzureBlobResponse>;
export type EfsSubdirectory = string;
export type EfsFilesystemArn = string;
export type Ec2SecurityGroupArnList = string[];
export declare const Ec2SecurityGroupArnList: any;
export interface Ec2Config {
    SubnetArn: string;
    SecurityGroupArns: string[];
}
export declare const Ec2Config: S.Schema<Ec2Config>;
export type EfsAccessPointArn = string;
export type IamRoleArn = string;
export type EfsInTransitEncryption = "NONE" | "TLS1_2" | (string & {});
export declare const EfsInTransitEncryption: any;
export interface CreateLocationEfsRequest {
    Subdirectory?: string;
    EfsFilesystemArn: string;
    Ec2Config: Ec2Config;
    Tags?: TagListEntry[];
    AccessPointArn?: string;
    FileSystemAccessRoleArn?: string;
    InTransitEncryption?: EfsInTransitEncryption;
}
export declare const CreateLocationEfsRequest: S.Schema<CreateLocationEfsRequest>;
export interface CreateLocationEfsResponse {
    LocationArn?: string;
}
export declare const CreateLocationEfsResponse: S.Schema<CreateLocationEfsResponse>;
export type FsxFilesystemArn = string;
export type FsxLustreSubdirectory = string;
export interface CreateLocationFsxLustreRequest {
    FsxFilesystemArn: string;
    SecurityGroupArns: string[];
    Subdirectory?: string;
    Tags?: TagListEntry[];
}
export declare const CreateLocationFsxLustreRequest: S.Schema<CreateLocationFsxLustreRequest>;
export interface CreateLocationFsxLustreResponse {
    LocationArn?: string;
}
export declare const CreateLocationFsxLustreResponse: S.Schema<CreateLocationFsxLustreResponse>;
export type NfsVersion = "AUTOMATIC" | "NFS3" | "NFS4_0" | "NFS4_1" | (string & {});
export declare const NfsVersion: any;
export interface NfsMountOptions {
    Version?: NfsVersion;
}
export declare const NfsMountOptions: S.Schema<NfsMountOptions>;
export interface FsxProtocolNfs {
    MountOptions?: NfsMountOptions;
}
export declare const FsxProtocolNfs: S.Schema<FsxProtocolNfs>;
export type SmbDomain = string;
export type SmbVersion = "AUTOMATIC" | "SMB2" | "SMB3" | "SMB1" | "SMB2_0" | (string & {});
export declare const SmbVersion: any;
export interface SmbMountOptions {
    Version?: SmbVersion;
}
export declare const SmbMountOptions: S.Schema<SmbMountOptions>;
export type SmbPassword = string | redacted.Redacted<string>;
export type SmbUser = string;
export interface ManagedSecretConfig {
    SecretArn?: string;
}
export declare const ManagedSecretConfig: S.Schema<ManagedSecretConfig>;
export interface FsxProtocolSmb {
    Domain?: string;
    MountOptions?: SmbMountOptions;
    Password?: string | redacted.Redacted<string>;
    User: string;
    ManagedSecretConfig?: ManagedSecretConfig;
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const FsxProtocolSmb: S.Schema<FsxProtocolSmb>;
export interface FsxProtocol {
    NFS?: FsxProtocolNfs;
    SMB?: FsxProtocolSmb;
}
export declare const FsxProtocol: S.Schema<FsxProtocol>;
export type StorageVirtualMachineArn = string;
export type FsxOntapSubdirectory = string;
export interface CreateLocationFsxOntapRequest {
    Protocol: FsxProtocol;
    SecurityGroupArns: string[];
    StorageVirtualMachineArn: string;
    Subdirectory?: string;
    Tags?: TagListEntry[];
}
export declare const CreateLocationFsxOntapRequest: S.Schema<CreateLocationFsxOntapRequest>;
export interface CreateLocationFsxOntapResponse {
    LocationArn?: string;
}
export declare const CreateLocationFsxOntapResponse: S.Schema<CreateLocationFsxOntapResponse>;
export type FsxOpenZfsSubdirectory = string;
export interface CreateLocationFsxOpenZfsRequest {
    FsxFilesystemArn: string;
    Protocol: FsxProtocol;
    SecurityGroupArns: string[];
    Subdirectory?: string;
    Tags?: TagListEntry[];
}
export declare const CreateLocationFsxOpenZfsRequest: S.Schema<CreateLocationFsxOpenZfsRequest>;
export interface CreateLocationFsxOpenZfsResponse {
    LocationArn?: string;
}
export declare const CreateLocationFsxOpenZfsResponse: S.Schema<CreateLocationFsxOpenZfsResponse>;
export type FsxWindowsSubdirectory = string;
export interface CreateLocationFsxWindowsRequest {
    Subdirectory?: string;
    FsxFilesystemArn: string;
    SecurityGroupArns: string[];
    Tags?: TagListEntry[];
    User: string;
    Domain?: string;
    Password?: string | redacted.Redacted<string>;
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const CreateLocationFsxWindowsRequest: S.Schema<CreateLocationFsxWindowsRequest>;
export interface CreateLocationFsxWindowsResponse {
    LocationArn?: string;
}
export declare const CreateLocationFsxWindowsResponse: S.Schema<CreateLocationFsxWindowsResponse>;
export type HdfsSubdirectory = string;
export type HdfsServerHostname = string;
export type HdfsServerPort = number;
export interface HdfsNameNode {
    Hostname: string;
    Port: number;
}
export declare const HdfsNameNode: S.Schema<HdfsNameNode>;
export type HdfsNameNodeList = HdfsNameNode[];
export declare const HdfsNameNodeList: any;
export type HdfsBlockSize = number;
export type HdfsReplicationFactor = number;
export type KmsKeyProviderUri = string;
export type HdfsRpcProtection = "DISABLED" | "AUTHENTICATION" | "INTEGRITY" | "PRIVACY" | (string & {});
export declare const HdfsRpcProtection: any;
export type HdfsDataTransferProtection = "DISABLED" | "AUTHENTICATION" | "INTEGRITY" | "PRIVACY" | (string & {});
export declare const HdfsDataTransferProtection: any;
export interface QopConfiguration {
    RpcProtection?: HdfsRpcProtection;
    DataTransferProtection?: HdfsDataTransferProtection;
}
export declare const QopConfiguration: S.Schema<QopConfiguration>;
export type HdfsAuthenticationType = "SIMPLE" | "KERBEROS" | (string & {});
export declare const HdfsAuthenticationType: any;
export type HdfsUser = string;
export type KerberosPrincipal = string;
export type KerberosKeytabFile = Uint8Array;
export type KerberosKrb5ConfFile = Uint8Array;
export interface CreateLocationHdfsRequest {
    Subdirectory?: string;
    NameNodes: HdfsNameNode[];
    BlockSize?: number;
    ReplicationFactor?: number;
    KmsKeyProviderUri?: string;
    QopConfiguration?: QopConfiguration;
    AuthenticationType: HdfsAuthenticationType;
    SimpleUser?: string;
    KerberosPrincipal?: string;
    KerberosKeytab?: Uint8Array;
    KerberosKrb5Conf?: Uint8Array;
    AgentArns: string[];
    Tags?: TagListEntry[];
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const CreateLocationHdfsRequest: S.Schema<CreateLocationHdfsRequest>;
export interface CreateLocationHdfsResponse {
    LocationArn?: string;
}
export declare const CreateLocationHdfsResponse: S.Schema<CreateLocationHdfsResponse>;
export type NfsSubdirectory = string;
export type ServerHostname = string;
export interface OnPremConfig {
    AgentArns: string[];
}
export declare const OnPremConfig: S.Schema<OnPremConfig>;
export interface CreateLocationNfsRequest {
    Subdirectory: string;
    ServerHostname: string;
    OnPremConfig: OnPremConfig;
    MountOptions?: NfsMountOptions;
    Tags?: TagListEntry[];
}
export declare const CreateLocationNfsRequest: S.Schema<CreateLocationNfsRequest>;
export interface CreateLocationNfsResponse {
    LocationArn?: string;
}
export declare const CreateLocationNfsResponse: S.Schema<CreateLocationNfsResponse>;
export type ObjectStorageServerPort = number;
export type ObjectStorageServerProtocol = "HTTPS" | "HTTP" | (string & {});
export declare const ObjectStorageServerProtocol: any;
export type S3Subdirectory = string;
export type ObjectStorageBucketName = string;
export type ObjectStorageAccessKey = string;
export type ObjectStorageSecretKey = string | redacted.Redacted<string>;
export type ObjectStorageCertificate = Uint8Array;
export interface CreateLocationObjectStorageRequest {
    ServerHostname: string;
    ServerPort?: number;
    ServerProtocol?: ObjectStorageServerProtocol;
    Subdirectory?: string;
    BucketName: string;
    AccessKey?: string;
    SecretKey?: string | redacted.Redacted<string>;
    AgentArns?: string[];
    Tags?: TagListEntry[];
    ServerCertificate?: Uint8Array;
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const CreateLocationObjectStorageRequest: S.Schema<CreateLocationObjectStorageRequest>;
export interface CreateLocationObjectStorageResponse {
    LocationArn?: string;
}
export declare const CreateLocationObjectStorageResponse: S.Schema<CreateLocationObjectStorageResponse>;
export type S3BucketArn = string;
export type S3StorageClass = "STANDARD" | "STANDARD_IA" | "ONEZONE_IA" | "INTELLIGENT_TIERING" | "GLACIER" | "DEEP_ARCHIVE" | "OUTPOSTS" | "GLACIER_INSTANT_RETRIEVAL" | (string & {});
export declare const S3StorageClass: any;
export interface S3Config {
    BucketAccessRoleArn: string;
}
export declare const S3Config: S.Schema<S3Config>;
export interface CreateLocationS3Request {
    Subdirectory?: string;
    S3BucketArn: string;
    S3StorageClass?: S3StorageClass;
    S3Config: S3Config;
    AgentArns?: string[];
    Tags?: TagListEntry[];
}
export declare const CreateLocationS3Request: S.Schema<CreateLocationS3Request>;
export interface CreateLocationS3Response {
    LocationArn?: string;
}
export declare const CreateLocationS3Response: S.Schema<CreateLocationS3Response>;
export type SmbSubdirectory = string;
export type SmbAuthenticationType = "NTLM" | "KERBEROS" | (string & {});
export declare const SmbAuthenticationType: any;
export type ServerIpAddress = string;
export type DnsIpList = string[];
export declare const DnsIpList: any;
export interface CreateLocationSmbRequest {
    Subdirectory: string;
    ServerHostname: string;
    User?: string;
    Domain?: string;
    Password?: string | redacted.Redacted<string>;
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
    AgentArns: string[];
    MountOptions?: SmbMountOptions;
    Tags?: TagListEntry[];
    AuthenticationType?: SmbAuthenticationType;
    DnsIpAddresses?: string[];
    KerberosPrincipal?: string;
    KerberosKeytab?: Uint8Array;
    KerberosKrb5Conf?: Uint8Array;
}
export declare const CreateLocationSmbRequest: S.Schema<CreateLocationSmbRequest>;
export interface CreateLocationSmbResponse {
    LocationArn?: string;
}
export declare const CreateLocationSmbResponse: S.Schema<CreateLocationSmbResponse>;
export type LogGroupArn = string;
export type VerifyMode = "POINT_IN_TIME_CONSISTENT" | "ONLY_FILES_TRANSFERRED" | "NONE" | (string & {});
export declare const VerifyMode: any;
export type OverwriteMode = "ALWAYS" | "NEVER" | (string & {});
export declare const OverwriteMode: any;
export type Atime = "NONE" | "BEST_EFFORT" | (string & {});
export declare const Atime: any;
export type Mtime = "NONE" | "PRESERVE" | (string & {});
export declare const Mtime: any;
export type Uid = "NONE" | "INT_VALUE" | "NAME" | "BOTH" | (string & {});
export declare const Uid: any;
export type Gid = "NONE" | "INT_VALUE" | "NAME" | "BOTH" | (string & {});
export declare const Gid: any;
export type PreserveDeletedFiles = "PRESERVE" | "REMOVE" | (string & {});
export declare const PreserveDeletedFiles: any;
export type PreserveDevices = "NONE" | "PRESERVE" | (string & {});
export declare const PreserveDevices: any;
export type PosixPermissions = "NONE" | "PRESERVE" | (string & {});
export declare const PosixPermissions: any;
export type BytesPerSecond = number;
export type TaskQueueing = "ENABLED" | "DISABLED" | (string & {});
export declare const TaskQueueing: any;
export type LogLevel = "OFF" | "BASIC" | "TRANSFER" | (string & {});
export declare const LogLevel: any;
export type TransferMode = "CHANGED" | "ALL" | (string & {});
export declare const TransferMode: any;
export type SmbSecurityDescriptorCopyFlags = "NONE" | "OWNER_DACL" | "OWNER_DACL_SACL" | (string & {});
export declare const SmbSecurityDescriptorCopyFlags: any;
export type ObjectTags = "PRESERVE" | "NONE" | (string & {});
export declare const ObjectTags: any;
export interface Options {
    VerifyMode?: VerifyMode;
    OverwriteMode?: OverwriteMode;
    Atime?: Atime;
    Mtime?: Mtime;
    Uid?: Uid;
    Gid?: Gid;
    PreserveDeletedFiles?: PreserveDeletedFiles;
    PreserveDevices?: PreserveDevices;
    PosixPermissions?: PosixPermissions;
    BytesPerSecond?: number;
    TaskQueueing?: TaskQueueing;
    LogLevel?: LogLevel;
    TransferMode?: TransferMode;
    SecurityDescriptorCopyFlags?: SmbSecurityDescriptorCopyFlags;
    ObjectTags?: ObjectTags;
}
export declare const Options: S.Schema<Options>;
export type FilterType = "SIMPLE_PATTERN" | (string & {});
export declare const FilterType: any;
export type FilterValue = string;
export interface FilterRule {
    FilterType?: FilterType;
    Value?: string;
}
export declare const FilterRule: S.Schema<FilterRule>;
export type FilterList = FilterRule[];
export declare const FilterList: any;
export type ScheduleExpressionCron = string;
export type ScheduleStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const ScheduleStatus: any;
export interface TaskSchedule {
    ScheduleExpression: string;
    Status?: ScheduleStatus;
}
export declare const TaskSchedule: S.Schema<TaskSchedule>;
export type ManifestAction = "TRANSFER" | (string & {});
export declare const ManifestAction: any;
export type ManifestFormat = "CSV" | (string & {});
export declare const ManifestFormat: any;
export type S3ObjectVersionId = string;
export interface S3ManifestConfig {
    ManifestObjectPath: string;
    BucketAccessRoleArn: string;
    S3BucketArn: string;
    ManifestObjectVersionId?: string;
}
export declare const S3ManifestConfig: S.Schema<S3ManifestConfig>;
export interface SourceManifestConfig {
    S3: S3ManifestConfig;
}
export declare const SourceManifestConfig: S.Schema<SourceManifestConfig>;
export interface ManifestConfig {
    Action?: ManifestAction;
    Format?: ManifestFormat;
    Source?: SourceManifestConfig;
}
export declare const ManifestConfig: S.Schema<ManifestConfig>;
export interface ReportDestinationS3 {
    Subdirectory?: string;
    S3BucketArn: string;
    BucketAccessRoleArn: string;
}
export declare const ReportDestinationS3: S.Schema<ReportDestinationS3>;
export interface ReportDestination {
    S3?: ReportDestinationS3;
}
export declare const ReportDestination: S.Schema<ReportDestination>;
export type ReportOutputType = "SUMMARY_ONLY" | "STANDARD" | (string & {});
export declare const ReportOutputType: any;
export type ReportLevel = "ERRORS_ONLY" | "SUCCESSES_AND_ERRORS" | (string & {});
export declare const ReportLevel: any;
export type ObjectVersionIds = "INCLUDE" | "NONE" | (string & {});
export declare const ObjectVersionIds: any;
export interface ReportOverride {
    ReportLevel?: ReportLevel;
}
export declare const ReportOverride: S.Schema<ReportOverride>;
export interface ReportOverrides {
    Transferred?: ReportOverride;
    Verified?: ReportOverride;
    Deleted?: ReportOverride;
    Skipped?: ReportOverride;
}
export declare const ReportOverrides: S.Schema<ReportOverrides>;
export interface TaskReportConfig {
    Destination?: ReportDestination;
    OutputType?: ReportOutputType;
    ReportLevel?: ReportLevel;
    ObjectVersionIds?: ObjectVersionIds;
    Overrides?: ReportOverrides;
}
export declare const TaskReportConfig: S.Schema<TaskReportConfig>;
export type TaskMode = "BASIC" | "ENHANCED" | (string & {});
export declare const TaskMode: any;
export interface CreateTaskRequest {
    SourceLocationArn: string;
    DestinationLocationArn: string;
    CloudWatchLogGroupArn?: string;
    Name?: string;
    Options?: Options;
    Excludes?: FilterRule[];
    Schedule?: TaskSchedule;
    Tags?: TagListEntry[];
    Includes?: FilterRule[];
    ManifestConfig?: ManifestConfig;
    TaskReportConfig?: TaskReportConfig;
    TaskMode?: TaskMode;
}
export declare const CreateTaskRequest: S.Schema<CreateTaskRequest>;
export type TaskArn = string;
export interface CreateTaskResponse {
    TaskArn?: string;
}
export declare const CreateTaskResponse: S.Schema<CreateTaskResponse>;
export interface DeleteAgentRequest {
    AgentArn: string;
}
export declare const DeleteAgentRequest: S.Schema<DeleteAgentRequest>;
export interface DeleteAgentResponse {
}
export declare const DeleteAgentResponse: S.Schema<DeleteAgentResponse>;
export interface DeleteLocationRequest {
    LocationArn: string;
}
export declare const DeleteLocationRequest: S.Schema<DeleteLocationRequest>;
export interface DeleteLocationResponse {
}
export declare const DeleteLocationResponse: S.Schema<DeleteLocationResponse>;
export interface DeleteTaskRequest {
    TaskArn: string;
}
export declare const DeleteTaskRequest: S.Schema<DeleteTaskRequest>;
export interface DeleteTaskResponse {
}
export declare const DeleteTaskResponse: S.Schema<DeleteTaskResponse>;
export interface DescribeAgentRequest {
    AgentArn: string;
}
export declare const DescribeAgentRequest: S.Schema<DescribeAgentRequest>;
export type AgentStatus = "ONLINE" | "OFFLINE" | (string & {});
export declare const AgentStatus: any;
export type EndpointType = "PUBLIC" | "PRIVATE_LINK" | "FIPS" | "FIPS_PRIVATE_LINK" | (string & {});
export declare const EndpointType: any;
export type Endpoint = string;
export interface PrivateLinkConfig {
    VpcEndpointId?: string;
    PrivateLinkEndpoint?: string;
    SubnetArns?: string[];
    SecurityGroupArns?: string[];
}
export declare const PrivateLinkConfig: S.Schema<PrivateLinkConfig>;
export type AgentVersion = string;
export interface Platform {
    Version?: string;
}
export declare const Platform: S.Schema<Platform>;
export interface DescribeAgentResponse {
    AgentArn?: string;
    Name?: string;
    Status?: AgentStatus;
    LastConnectionTime?: Date;
    CreationTime?: Date;
    EndpointType?: EndpointType;
    PrivateLinkConfig?: PrivateLinkConfig;
    Platform?: Platform;
}
export declare const DescribeAgentResponse: S.Schema<DescribeAgentResponse>;
export interface DescribeLocationAzureBlobRequest {
    LocationArn: string;
}
export declare const DescribeLocationAzureBlobRequest: S.Schema<DescribeLocationAzureBlobRequest>;
export type LocationUri = string;
export interface DescribeLocationAzureBlobResponse {
    LocationArn?: string;
    LocationUri?: string;
    AuthenticationType?: AzureBlobAuthenticationType;
    BlobType?: AzureBlobType;
    AccessTier?: AzureAccessTier;
    AgentArns?: string[];
    CreationTime?: Date;
    ManagedSecretConfig?: ManagedSecretConfig;
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const DescribeLocationAzureBlobResponse: S.Schema<DescribeLocationAzureBlobResponse>;
export interface DescribeLocationEfsRequest {
    LocationArn: string;
}
export declare const DescribeLocationEfsRequest: S.Schema<DescribeLocationEfsRequest>;
export interface DescribeLocationEfsResponse {
    LocationArn?: string;
    LocationUri?: string;
    Ec2Config?: Ec2Config;
    CreationTime?: Date;
    AccessPointArn?: string;
    FileSystemAccessRoleArn?: string;
    InTransitEncryption?: EfsInTransitEncryption;
}
export declare const DescribeLocationEfsResponse: S.Schema<DescribeLocationEfsResponse>;
export interface DescribeLocationFsxLustreRequest {
    LocationArn: string;
}
export declare const DescribeLocationFsxLustreRequest: S.Schema<DescribeLocationFsxLustreRequest>;
export interface DescribeLocationFsxLustreResponse {
    LocationArn?: string;
    LocationUri?: string;
    SecurityGroupArns?: string[];
    CreationTime?: Date;
}
export declare const DescribeLocationFsxLustreResponse: S.Schema<DescribeLocationFsxLustreResponse>;
export interface DescribeLocationFsxOntapRequest {
    LocationArn: string;
}
export declare const DescribeLocationFsxOntapRequest: S.Schema<DescribeLocationFsxOntapRequest>;
export interface DescribeLocationFsxOntapResponse {
    CreationTime?: Date;
    LocationArn?: string;
    LocationUri?: string;
    Protocol?: FsxProtocol;
    SecurityGroupArns?: string[];
    StorageVirtualMachineArn?: string;
    FsxFilesystemArn?: string;
}
export declare const DescribeLocationFsxOntapResponse: S.Schema<DescribeLocationFsxOntapResponse>;
export interface DescribeLocationFsxOpenZfsRequest {
    LocationArn: string;
}
export declare const DescribeLocationFsxOpenZfsRequest: S.Schema<DescribeLocationFsxOpenZfsRequest>;
export interface DescribeLocationFsxOpenZfsResponse {
    LocationArn?: string;
    LocationUri?: string;
    SecurityGroupArns?: string[];
    Protocol?: FsxProtocol;
    CreationTime?: Date;
}
export declare const DescribeLocationFsxOpenZfsResponse: S.Schema<DescribeLocationFsxOpenZfsResponse>;
export interface DescribeLocationFsxWindowsRequest {
    LocationArn: string;
}
export declare const DescribeLocationFsxWindowsRequest: S.Schema<DescribeLocationFsxWindowsRequest>;
export interface DescribeLocationFsxWindowsResponse {
    LocationArn?: string;
    LocationUri?: string;
    SecurityGroupArns?: string[];
    CreationTime?: Date;
    User?: string;
    Domain?: string;
    ManagedSecretConfig?: ManagedSecretConfig;
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const DescribeLocationFsxWindowsResponse: S.Schema<DescribeLocationFsxWindowsResponse>;
export interface DescribeLocationHdfsRequest {
    LocationArn: string;
}
export declare const DescribeLocationHdfsRequest: S.Schema<DescribeLocationHdfsRequest>;
export interface DescribeLocationHdfsResponse {
    LocationArn?: string;
    LocationUri?: string;
    NameNodes?: HdfsNameNode[];
    BlockSize?: number;
    ReplicationFactor?: number;
    KmsKeyProviderUri?: string;
    QopConfiguration?: QopConfiguration;
    AuthenticationType?: HdfsAuthenticationType;
    SimpleUser?: string;
    KerberosPrincipal?: string;
    AgentArns?: string[];
    CreationTime?: Date;
    ManagedSecretConfig?: ManagedSecretConfig;
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const DescribeLocationHdfsResponse: S.Schema<DescribeLocationHdfsResponse>;
export interface DescribeLocationNfsRequest {
    LocationArn: string;
}
export declare const DescribeLocationNfsRequest: S.Schema<DescribeLocationNfsRequest>;
export interface DescribeLocationNfsResponse {
    LocationArn?: string;
    LocationUri?: string;
    OnPremConfig?: OnPremConfig;
    MountOptions?: NfsMountOptions;
    CreationTime?: Date;
}
export declare const DescribeLocationNfsResponse: S.Schema<DescribeLocationNfsResponse>;
export interface DescribeLocationObjectStorageRequest {
    LocationArn: string;
}
export declare const DescribeLocationObjectStorageRequest: S.Schema<DescribeLocationObjectStorageRequest>;
export interface DescribeLocationObjectStorageResponse {
    LocationArn?: string;
    LocationUri?: string;
    AccessKey?: string;
    ServerPort?: number;
    ServerProtocol?: ObjectStorageServerProtocol;
    AgentArns?: string[];
    CreationTime?: Date;
    ServerCertificate?: Uint8Array;
    ManagedSecretConfig?: ManagedSecretConfig;
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const DescribeLocationObjectStorageResponse: S.Schema<DescribeLocationObjectStorageResponse>;
export interface DescribeLocationS3Request {
    LocationArn: string;
}
export declare const DescribeLocationS3Request: S.Schema<DescribeLocationS3Request>;
export interface DescribeLocationS3Response {
    LocationArn?: string;
    LocationUri?: string;
    S3StorageClass?: S3StorageClass;
    S3Config?: S3Config;
    AgentArns?: string[];
    CreationTime?: Date;
}
export declare const DescribeLocationS3Response: S.Schema<DescribeLocationS3Response>;
export interface DescribeLocationSmbRequest {
    LocationArn: string;
}
export declare const DescribeLocationSmbRequest: S.Schema<DescribeLocationSmbRequest>;
export interface DescribeLocationSmbResponse {
    LocationArn?: string;
    LocationUri?: string;
    AgentArns?: string[];
    User?: string;
    Domain?: string;
    MountOptions?: SmbMountOptions;
    CreationTime?: Date;
    DnsIpAddresses?: string[];
    KerberosPrincipal?: string;
    AuthenticationType?: SmbAuthenticationType;
    ManagedSecretConfig?: ManagedSecretConfig;
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const DescribeLocationSmbResponse: S.Schema<DescribeLocationSmbResponse>;
export interface DescribeTaskRequest {
    TaskArn: string;
}
export declare const DescribeTaskRequest: S.Schema<DescribeTaskRequest>;
export type TaskStatus = "AVAILABLE" | "CREATING" | "QUEUED" | "RUNNING" | "UNAVAILABLE" | (string & {});
export declare const TaskStatus: any;
export type NetworkInterfaceArn = string;
export type SourceNetworkInterfaceArns = string[];
export declare const SourceNetworkInterfaceArns: any;
export type DestinationNetworkInterfaceArns = string[];
export declare const DestinationNetworkInterfaceArns: any;
export type ScheduleDisabledReason = string;
export type ScheduleDisabledBy = "USER" | "SERVICE" | (string & {});
export declare const ScheduleDisabledBy: any;
export interface TaskScheduleDetails {
    StatusUpdateTime?: Date;
    DisabledReason?: string;
    DisabledBy?: ScheduleDisabledBy;
}
export declare const TaskScheduleDetails: S.Schema<TaskScheduleDetails>;
export interface DescribeTaskResponse {
    TaskArn?: string;
    Status?: TaskStatus;
    Name?: string;
    CurrentTaskExecutionArn?: string;
    SourceLocationArn?: string;
    DestinationLocationArn?: string;
    CloudWatchLogGroupArn?: string;
    SourceNetworkInterfaceArns?: string[];
    DestinationNetworkInterfaceArns?: string[];
    Options?: Options;
    Excludes?: FilterRule[];
    Schedule?: TaskSchedule;
    ErrorCode?: string;
    ErrorDetail?: string;
    CreationTime?: Date;
    Includes?: FilterRule[];
    ManifestConfig?: ManifestConfig;
    TaskReportConfig?: TaskReportConfig;
    ScheduleDetails?: TaskScheduleDetails;
    TaskMode?: TaskMode;
}
export declare const DescribeTaskResponse: S.Schema<DescribeTaskResponse>;
export interface DescribeTaskExecutionRequest {
    TaskExecutionArn: string;
}
export declare const DescribeTaskExecutionRequest: S.Schema<DescribeTaskExecutionRequest>;
export type TaskExecutionStatus = "QUEUED" | "CANCELLING" | "LAUNCHING" | "PREPARING" | "TRANSFERRING" | "VERIFYING" | "SUCCESS" | "ERROR" | (string & {});
export declare const TaskExecutionStatus: any;
export type Duration = number;
export type PhaseStatus = "PENDING" | "SUCCESS" | "ERROR" | (string & {});
export declare const PhaseStatus: any;
export interface TaskExecutionResultDetail {
    PrepareDuration?: number;
    PrepareStatus?: PhaseStatus;
    TotalDuration?: number;
    TransferDuration?: number;
    TransferStatus?: PhaseStatus;
    VerifyDuration?: number;
    VerifyStatus?: PhaseStatus;
    ErrorCode?: string;
    ErrorDetail?: string;
}
export declare const TaskExecutionResultDetail: S.Schema<TaskExecutionResultDetail>;
export interface ReportResult {
    Status?: PhaseStatus;
    ErrorCode?: string;
    ErrorDetail?: string;
}
export declare const ReportResult: S.Schema<ReportResult>;
export interface TaskExecutionFilesListedDetail {
    AtSource?: number;
    AtDestinationForDelete?: number;
}
export declare const TaskExecutionFilesListedDetail: S.Schema<TaskExecutionFilesListedDetail>;
export interface TaskExecutionFilesFailedDetail {
    Prepare?: number;
    Transfer?: number;
    Verify?: number;
    Delete?: number;
}
export declare const TaskExecutionFilesFailedDetail: S.Schema<TaskExecutionFilesFailedDetail>;
export type ItemCount = number;
export interface TaskExecutionFoldersListedDetail {
    AtSource?: number;
    AtDestinationForDelete?: number;
}
export declare const TaskExecutionFoldersListedDetail: S.Schema<TaskExecutionFoldersListedDetail>;
export interface TaskExecutionFoldersFailedDetail {
    List?: number;
    Prepare?: number;
    Transfer?: number;
    Verify?: number;
    Delete?: number;
}
export declare const TaskExecutionFoldersFailedDetail: S.Schema<TaskExecutionFoldersFailedDetail>;
export interface DescribeTaskExecutionResponse {
    TaskExecutionArn?: string;
    Status?: TaskExecutionStatus;
    Options?: Options;
    Excludes?: FilterRule[];
    Includes?: FilterRule[];
    ManifestConfig?: ManifestConfig;
    StartTime?: Date;
    EstimatedFilesToTransfer?: number;
    EstimatedBytesToTransfer?: number;
    FilesTransferred?: number;
    BytesWritten?: number;
    BytesTransferred?: number;
    BytesCompressed?: number;
    Result?: TaskExecutionResultDetail;
    TaskReportConfig?: TaskReportConfig;
    FilesDeleted?: number;
    FilesSkipped?: number;
    FilesVerified?: number;
    ReportResult?: ReportResult;
    EstimatedFilesToDelete?: number;
    TaskMode?: TaskMode;
    FilesPrepared?: number;
    FilesListed?: TaskExecutionFilesListedDetail;
    FilesFailed?: TaskExecutionFilesFailedDetail;
    EstimatedFoldersToDelete?: number;
    EstimatedFoldersToTransfer?: number;
    FoldersSkipped?: number;
    FoldersPrepared?: number;
    FoldersTransferred?: number;
    FoldersVerified?: number;
    FoldersDeleted?: number;
    FoldersListed?: TaskExecutionFoldersListedDetail;
    FoldersFailed?: TaskExecutionFoldersFailedDetail;
    LaunchTime?: Date;
    EndTime?: Date;
}
export declare const DescribeTaskExecutionResponse: S.Schema<DescribeTaskExecutionResponse>;
export type MaxResults = number;
export type NextToken = string;
export interface ListAgentsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListAgentsRequest: S.Schema<ListAgentsRequest>;
export interface AgentListEntry {
    AgentArn?: string;
    Name?: string;
    Status?: AgentStatus;
    Platform?: Platform;
}
export declare const AgentListEntry: S.Schema<AgentListEntry>;
export type AgentList = AgentListEntry[];
export declare const AgentList: any;
export interface ListAgentsResponse {
    Agents?: AgentListEntry[];
    NextToken?: string;
}
export declare const ListAgentsResponse: S.Schema<ListAgentsResponse>;
export type LocationFilterName = "LocationUri" | "LocationType" | "CreationTime" | (string & {});
export declare const LocationFilterName: any;
export type FilterAttributeValue = string;
export type FilterValues = string[];
export declare const FilterValues: any;
export type Operator = "Equals" | "NotEquals" | "In" | "LessThanOrEqual" | "LessThan" | "GreaterThanOrEqual" | "GreaterThan" | "Contains" | "NotContains" | "BeginsWith" | (string & {});
export declare const Operator: any;
export interface LocationFilter {
    Name: LocationFilterName;
    Values: string[];
    Operator: Operator;
}
export declare const LocationFilter: S.Schema<LocationFilter>;
export type LocationFilters = LocationFilter[];
export declare const LocationFilters: any;
export interface ListLocationsRequest {
    MaxResults?: number;
    NextToken?: string;
    Filters?: LocationFilter[];
}
export declare const ListLocationsRequest: S.Schema<ListLocationsRequest>;
export interface LocationListEntry {
    LocationArn?: string;
    LocationUri?: string;
}
export declare const LocationListEntry: S.Schema<LocationListEntry>;
export type LocationList = LocationListEntry[];
export declare const LocationList: any;
export interface ListLocationsResponse {
    Locations?: LocationListEntry[];
    NextToken?: string;
}
export declare const ListLocationsResponse: S.Schema<ListLocationsResponse>;
export type TaggableResourceArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export type OutputTagList = TagListEntry[];
export declare const OutputTagList: any;
export interface ListTagsForResourceResponse {
    Tags?: TagListEntry[];
    NextToken?: string;
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListTaskExecutionsRequest {
    TaskArn?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListTaskExecutionsRequest: S.Schema<ListTaskExecutionsRequest>;
export interface TaskExecutionListEntry {
    TaskExecutionArn?: string;
    Status?: TaskExecutionStatus;
    TaskMode?: TaskMode;
}
export declare const TaskExecutionListEntry: S.Schema<TaskExecutionListEntry>;
export type TaskExecutionList = TaskExecutionListEntry[];
export declare const TaskExecutionList: any;
export interface ListTaskExecutionsResponse {
    TaskExecutions?: TaskExecutionListEntry[];
    NextToken?: string;
}
export declare const ListTaskExecutionsResponse: S.Schema<ListTaskExecutionsResponse>;
export type TaskFilterName = "LocationId" | "CreationTime" | (string & {});
export declare const TaskFilterName: any;
export interface TaskFilter {
    Name: TaskFilterName;
    Values: string[];
    Operator: Operator;
}
export declare const TaskFilter: S.Schema<TaskFilter>;
export type TaskFilters = TaskFilter[];
export declare const TaskFilters: any;
export interface ListTasksRequest {
    MaxResults?: number;
    NextToken?: string;
    Filters?: TaskFilter[];
}
export declare const ListTasksRequest: S.Schema<ListTasksRequest>;
export interface TaskListEntry {
    TaskArn?: string;
    Status?: TaskStatus;
    Name?: string;
    TaskMode?: TaskMode;
}
export declare const TaskListEntry: S.Schema<TaskListEntry>;
export type TaskList = TaskListEntry[];
export declare const TaskList: any;
export interface ListTasksResponse {
    Tasks?: TaskListEntry[];
    NextToken?: string;
}
export declare const ListTasksResponse: S.Schema<ListTasksResponse>;
export interface StartTaskExecutionRequest {
    TaskArn: string;
    OverrideOptions?: Options;
    Includes?: FilterRule[];
    Excludes?: FilterRule[];
    ManifestConfig?: ManifestConfig;
    TaskReportConfig?: TaskReportConfig;
    Tags?: TagListEntry[];
}
export declare const StartTaskExecutionRequest: S.Schema<StartTaskExecutionRequest>;
export interface StartTaskExecutionResponse {
    TaskExecutionArn?: string;
}
export declare const StartTaskExecutionResponse: S.Schema<StartTaskExecutionResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: TagListEntry[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    Keys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAgentRequest {
    AgentArn: string;
    Name?: string;
}
export declare const UpdateAgentRequest: S.Schema<UpdateAgentRequest>;
export interface UpdateAgentResponse {
}
export declare const UpdateAgentResponse: S.Schema<UpdateAgentResponse>;
export interface UpdateLocationAzureBlobRequest {
    LocationArn: string;
    Subdirectory?: string;
    AuthenticationType?: AzureBlobAuthenticationType;
    SasConfiguration?: AzureBlobSasConfiguration;
    BlobType?: AzureBlobType;
    AccessTier?: AzureAccessTier;
    AgentArns?: string[];
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const UpdateLocationAzureBlobRequest: S.Schema<UpdateLocationAzureBlobRequest>;
export interface UpdateLocationAzureBlobResponse {
}
export declare const UpdateLocationAzureBlobResponse: S.Schema<UpdateLocationAzureBlobResponse>;
export type UpdatedEfsAccessPointArn = string;
export type UpdatedEfsIamRoleArn = string;
export interface UpdateLocationEfsRequest {
    LocationArn: string;
    Subdirectory?: string;
    AccessPointArn?: string;
    FileSystemAccessRoleArn?: string;
    InTransitEncryption?: EfsInTransitEncryption;
}
export declare const UpdateLocationEfsRequest: S.Schema<UpdateLocationEfsRequest>;
export interface UpdateLocationEfsResponse {
}
export declare const UpdateLocationEfsResponse: S.Schema<UpdateLocationEfsResponse>;
export interface UpdateLocationFsxLustreRequest {
    LocationArn: string;
    Subdirectory?: string;
}
export declare const UpdateLocationFsxLustreRequest: S.Schema<UpdateLocationFsxLustreRequest>;
export interface UpdateLocationFsxLustreResponse {
}
export declare const UpdateLocationFsxLustreResponse: S.Schema<UpdateLocationFsxLustreResponse>;
export type UpdateSmbDomain = string;
export interface FsxUpdateProtocolSmb {
    Domain?: string;
    MountOptions?: SmbMountOptions;
    Password?: string | redacted.Redacted<string>;
    User?: string;
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const FsxUpdateProtocolSmb: S.Schema<FsxUpdateProtocolSmb>;
export interface FsxUpdateProtocol {
    NFS?: FsxProtocolNfs;
    SMB?: FsxUpdateProtocolSmb;
}
export declare const FsxUpdateProtocol: S.Schema<FsxUpdateProtocol>;
export interface UpdateLocationFsxOntapRequest {
    LocationArn: string;
    Protocol?: FsxUpdateProtocol;
    Subdirectory?: string;
}
export declare const UpdateLocationFsxOntapRequest: S.Schema<UpdateLocationFsxOntapRequest>;
export interface UpdateLocationFsxOntapResponse {
}
export declare const UpdateLocationFsxOntapResponse: S.Schema<UpdateLocationFsxOntapResponse>;
export interface UpdateLocationFsxOpenZfsRequest {
    LocationArn: string;
    Protocol?: FsxProtocol;
    Subdirectory?: string;
}
export declare const UpdateLocationFsxOpenZfsRequest: S.Schema<UpdateLocationFsxOpenZfsRequest>;
export interface UpdateLocationFsxOpenZfsResponse {
}
export declare const UpdateLocationFsxOpenZfsResponse: S.Schema<UpdateLocationFsxOpenZfsResponse>;
export interface UpdateLocationFsxWindowsRequest {
    LocationArn: string;
    Subdirectory?: string;
    Domain?: string;
    User?: string;
    Password?: string | redacted.Redacted<string>;
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const UpdateLocationFsxWindowsRequest: S.Schema<UpdateLocationFsxWindowsRequest>;
export interface UpdateLocationFsxWindowsResponse {
}
export declare const UpdateLocationFsxWindowsResponse: S.Schema<UpdateLocationFsxWindowsResponse>;
export interface UpdateLocationHdfsRequest {
    LocationArn: string;
    Subdirectory?: string;
    NameNodes?: HdfsNameNode[];
    BlockSize?: number;
    ReplicationFactor?: number;
    KmsKeyProviderUri?: string;
    QopConfiguration?: QopConfiguration;
    AuthenticationType?: HdfsAuthenticationType;
    SimpleUser?: string;
    KerberosPrincipal?: string;
    KerberosKeytab?: Uint8Array;
    KerberosKrb5Conf?: Uint8Array;
    AgentArns?: string[];
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const UpdateLocationHdfsRequest: S.Schema<UpdateLocationHdfsRequest>;
export interface UpdateLocationHdfsResponse {
}
export declare const UpdateLocationHdfsResponse: S.Schema<UpdateLocationHdfsResponse>;
export interface UpdateLocationNfsRequest {
    LocationArn: string;
    Subdirectory?: string;
    ServerHostname?: string;
    OnPremConfig?: OnPremConfig;
    MountOptions?: NfsMountOptions;
}
export declare const UpdateLocationNfsRequest: S.Schema<UpdateLocationNfsRequest>;
export interface UpdateLocationNfsResponse {
}
export declare const UpdateLocationNfsResponse: S.Schema<UpdateLocationNfsResponse>;
export interface UpdateLocationObjectStorageRequest {
    LocationArn: string;
    ServerPort?: number;
    ServerProtocol?: ObjectStorageServerProtocol;
    Subdirectory?: string;
    ServerHostname?: string;
    AccessKey?: string;
    SecretKey?: string | redacted.Redacted<string>;
    AgentArns?: string[];
    ServerCertificate?: Uint8Array;
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
}
export declare const UpdateLocationObjectStorageRequest: S.Schema<UpdateLocationObjectStorageRequest>;
export interface UpdateLocationObjectStorageResponse {
}
export declare const UpdateLocationObjectStorageResponse: S.Schema<UpdateLocationObjectStorageResponse>;
export interface UpdateLocationS3Request {
    LocationArn: string;
    Subdirectory?: string;
    S3StorageClass?: S3StorageClass;
    S3Config?: S3Config;
}
export declare const UpdateLocationS3Request: S.Schema<UpdateLocationS3Request>;
export interface UpdateLocationS3Response {
}
export declare const UpdateLocationS3Response: S.Schema<UpdateLocationS3Response>;
export interface UpdateLocationSmbRequest {
    LocationArn: string;
    Subdirectory?: string;
    ServerHostname?: string;
    User?: string;
    Domain?: string;
    Password?: string | redacted.Redacted<string>;
    CmkSecretConfig?: CmkSecretConfig;
    CustomSecretConfig?: CustomSecretConfig;
    AgentArns?: string[];
    MountOptions?: SmbMountOptions;
    AuthenticationType?: SmbAuthenticationType;
    DnsIpAddresses?: string[];
    KerberosPrincipal?: string;
    KerberosKeytab?: Uint8Array;
    KerberosKrb5Conf?: Uint8Array;
}
export declare const UpdateLocationSmbRequest: S.Schema<UpdateLocationSmbRequest>;
export interface UpdateLocationSmbResponse {
}
export declare const UpdateLocationSmbResponse: S.Schema<UpdateLocationSmbResponse>;
export interface UpdateTaskRequest {
    TaskArn: string;
    Options?: Options;
    Excludes?: FilterRule[];
    Schedule?: TaskSchedule;
    Name?: string;
    CloudWatchLogGroupArn?: string;
    Includes?: FilterRule[];
    ManifestConfig?: ManifestConfig;
    TaskReportConfig?: TaskReportConfig;
}
export declare const UpdateTaskRequest: S.Schema<UpdateTaskRequest>;
export interface UpdateTaskResponse {
}
export declare const UpdateTaskResponse: S.Schema<UpdateTaskResponse>;
export interface UpdateTaskExecutionRequest {
    TaskExecutionArn: string;
    Options: Options;
}
export declare const UpdateTaskExecutionRequest: S.Schema<UpdateTaskExecutionRequest>;
export interface UpdateTaskExecutionResponse {
}
export declare const UpdateTaskExecutionResponse: S.Schema<UpdateTaskExecutionResponse>;
export type CancelTaskExecutionError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Stops an DataSync task execution that's in progress. The transfer of some
 * files are abruptly interrupted. File contents that're transferred to the destination might be
 * incomplete or inconsistent with the source files.
 *
 * However, if you start a new task execution using the same task and allow it to finish,
 * file content on the destination will be complete and consistent. This applies to other
 * unexpected failures that interrupt a task execution. In all of these cases, DataSync
 * successfully completes the transfer when you start the next task execution.
 */
export declare const cancelTaskExecution: API.OperationMethod<CancelTaskExecutionRequest, CancelTaskExecutionResponse, CancelTaskExecutionError, Credentials | HttpClient.HttpClient>;
export type CreateAgentError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Activates an DataSync agent that you deploy in your storage environment.
 * The activation process associates the agent with your Amazon Web Services account.
 *
 * If you haven't deployed an agent yet, see Do I need a DataSync
 * agent?
 */
export declare const createAgent: API.OperationMethod<CreateAgentRequest, CreateAgentResponse, CreateAgentError, Credentials | HttpClient.HttpClient>;
export type CreateLocationAzureBlobError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for a Microsoft Azure Blob Storage
 * container. DataSync can use this location as a transfer source or destination.
 * You can make transfers with or without a DataSync agent that connects to your
 * container.
 *
 * Before you begin, make sure you know how DataSync accesses Azure Blob Storage and works with access tiers and blob types.
 */
export declare const createLocationAzureBlob: API.OperationMethod<CreateLocationAzureBlobRequest, CreateLocationAzureBlobResponse, CreateLocationAzureBlobError, Credentials | HttpClient.HttpClient>;
export type CreateLocationEfsError = InternalException | InvalidRequestException | LocationRoleNotAssumable | LocationAccessTestFailed | CommonErrors;
/**
 * Creates a transfer *location* for an Amazon EFS file system.
 * DataSync can use this location as a source or destination for transferring
 * data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses
 * Amazon EFS file systems.
 */
export declare const createLocationEfs: API.OperationMethod<CreateLocationEfsRequest, CreateLocationEfsResponse, CreateLocationEfsError, Credentials | HttpClient.HttpClient>;
export type CreateLocationFsxLustreError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for an Amazon FSx for Lustre file
 * system. DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses FSx for Lustre file systems.
 */
export declare const createLocationFsxLustre: API.OperationMethod<CreateLocationFsxLustreRequest, CreateLocationFsxLustreResponse, CreateLocationFsxLustreError, Credentials | HttpClient.HttpClient>;
export type CreateLocationFsxOntapError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for an Amazon FSx for NetApp ONTAP file
 * system. DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses FSx for ONTAP file systems.
 */
export declare const createLocationFsxOntap: API.OperationMethod<CreateLocationFsxOntapRequest, CreateLocationFsxOntapResponse, CreateLocationFsxOntapError, Credentials | HttpClient.HttpClient>;
export type CreateLocationFsxOpenZfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for an Amazon FSx for OpenZFS file
 * system. DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses
 * FSx for OpenZFS file systems.
 *
 * Request parameters related to `SMB` aren't supported with the
 * `CreateLocationFsxOpenZfs` operation.
 */
export declare const createLocationFsxOpenZfs: API.OperationMethod<CreateLocationFsxOpenZfsRequest, CreateLocationFsxOpenZfsResponse, CreateLocationFsxOpenZfsError, Credentials | HttpClient.HttpClient>;
export type CreateLocationFsxWindowsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for an Amazon FSx for Windows File Server file
 * system. DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses
 * FSx for Windows File Server file systems.
 */
export declare const createLocationFsxWindows: API.OperationMethod<CreateLocationFsxWindowsRequest, CreateLocationFsxWindowsResponse, CreateLocationFsxWindowsError, Credentials | HttpClient.HttpClient>;
export type CreateLocationHdfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for a Hadoop Distributed File System
 * (HDFS). DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses HDFS
 * clusters.
 */
export declare const createLocationHdfs: API.OperationMethod<CreateLocationHdfsRequest, CreateLocationHdfsResponse, CreateLocationHdfsError, Credentials | HttpClient.HttpClient>;
export type CreateLocationNfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for a Network File System (NFS) file
 * server. DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses NFS file
 * servers.
 */
export declare const createLocationNfs: API.OperationMethod<CreateLocationNfsRequest, CreateLocationNfsResponse, CreateLocationNfsError, Credentials | HttpClient.HttpClient>;
export type CreateLocationObjectStorageError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for an object storage system. DataSync can use this location as a source or destination for transferring data. You
 * can make transfers with or without a DataSync
 * agent.
 *
 * Before you begin, make sure that you understand the prerequisites for DataSync to work with object storage systems.
 */
export declare const createLocationObjectStorage: API.OperationMethod<CreateLocationObjectStorageRequest, CreateLocationObjectStorageResponse, CreateLocationObjectStorageError, Credentials | HttpClient.HttpClient>;
export type CreateLocationS3Error = InternalException | InvalidRequestException | LocationRoleNotAssumable | LocationAccessTestFailed | CommonErrors;
/**
 * Creates a transfer *location* for an Amazon S3 bucket.
 * DataSync can use this location as a source or destination for transferring
 * data.
 *
 * Before you begin, make sure that you read the following topics:
 *
 * - Storage
 * class considerations with Amazon S3 locations
 *
 * - Evaluating S3 request costs when using DataSync
 *
 * For more information, see Configuring
 * transfers with Amazon S3.
 */
export declare const createLocationS3: API.OperationMethod<CreateLocationS3Request, CreateLocationS3Response, CreateLocationS3Error, Credentials | HttpClient.HttpClient>;
export type CreateLocationSmbError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for a Server Message Block (SMB) file
 * server. DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync accesses SMB
 * file servers. For more information, see Providing DataSync access to SMB file servers.
 */
export declare const createLocationSmb: API.OperationMethod<CreateLocationSmbRequest, CreateLocationSmbResponse, CreateLocationSmbError, Credentials | HttpClient.HttpClient>;
export type CreateTaskError = InternalException | InvalidRequestException | LocationAccessTestFailed | CommonErrors;
/**
 * Configures a *task*, which defines where and how DataSync
 * transfers your data.
 *
 * A task includes a source location, destination location, and transfer options (such as
 * bandwidth limits, scheduling, and more).
 *
 * If you're planning to transfer data to or from an Amazon S3 location, review
 * how
 * DataSync can affect your S3 request charges and the DataSync pricing page before
 * you begin.
 */
export declare const createTask: API.OperationMethod<CreateTaskRequest, CreateTaskResponse, CreateTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Removes an DataSync agent resource from your Amazon Web Services account.
 *
 * Keep in mind that this operation (which can't be undone) doesn't remove the agent's
 * virtual machine (VM) or Amazon EC2 instance from your storage environment. For next
 * steps, you can delete the VM or instance from your storage environment or reuse it to activate a new
 * agent.
 */
export declare const deleteAgent: API.OperationMethod<DeleteAgentRequest, DeleteAgentResponse, DeleteAgentError, Credentials | HttpClient.HttpClient>;
export type DeleteLocationError = InternalException | InvalidRequestException | LocationNotFound | CommonErrors;
/**
 * Deletes a transfer location resource from DataSync.
 */
export declare const deleteLocation: API.OperationMethod<DeleteLocationRequest, DeleteLocationResponse, DeleteLocationError, Credentials | HttpClient.HttpClient>;
export type DeleteTaskError = InternalException | InvalidRequestException | TaskNotFound | CommonErrors;
/**
 * Deletes a transfer task resource from DataSync.
 */
export declare const deleteTask: API.OperationMethod<DeleteTaskRequest, DeleteTaskResponse, DeleteTaskError, Credentials | HttpClient.HttpClient>;
export type DescribeAgentError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Returns information about an DataSync agent, such as its name, service
 * endpoint type, and status.
 */
export declare const describeAgent: API.OperationMethod<DescribeAgentRequest, DescribeAgentResponse, DescribeAgentError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationAzureBlobError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for Microsoft Azure
 * Blob Storage is configured.
 */
export declare const describeLocationAzureBlob: API.OperationMethod<DescribeLocationAzureBlobRequest, DescribeLocationAzureBlobResponse, DescribeLocationAzureBlobError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationEfsError = InternalException | InvalidRequestException | LocationNotFound | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an Amazon EFS file system is configured.
 */
export declare const describeLocationEfs: API.OperationMethod<DescribeLocationEfsRequest, DescribeLocationEfsResponse, DescribeLocationEfsError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationFsxLustreError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an Amazon FSx for Lustre file system is configured.
 */
export declare const describeLocationFsxLustre: API.OperationMethod<DescribeLocationFsxLustreRequest, DescribeLocationFsxLustreResponse, DescribeLocationFsxLustreError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationFsxOntapError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an Amazon FSx for NetApp ONTAP file system is configured.
 *
 * If your location uses SMB, the `DescribeLocationFsxOntap` operation doesn't
 * actually return a `Password`.
 */
export declare const describeLocationFsxOntap: API.OperationMethod<DescribeLocationFsxOntapRequest, DescribeLocationFsxOntapResponse, DescribeLocationFsxOntapError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationFsxOpenZfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an Amazon FSx for OpenZFS file system is configured.
 *
 * Response elements related to `SMB` aren't supported with the
 * `DescribeLocationFsxOpenZfs` operation.
 */
export declare const describeLocationFsxOpenZfs: API.OperationMethod<DescribeLocationFsxOpenZfsRequest, DescribeLocationFsxOpenZfsResponse, DescribeLocationFsxOpenZfsError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationFsxWindowsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an Amazon FSx for Windows File Server file system is configured.
 */
export declare const describeLocationFsxWindows: API.OperationMethod<DescribeLocationFsxWindowsRequest, DescribeLocationFsxWindowsResponse, DescribeLocationFsxWindowsError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationHdfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for a Hadoop
 * Distributed File System (HDFS) is configured.
 */
export declare const describeLocationHdfs: API.OperationMethod<DescribeLocationHdfsRequest, DescribeLocationHdfsResponse, DescribeLocationHdfsError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationNfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for a Network
 * File System (NFS) file server is configured.
 */
export declare const describeLocationNfs: API.OperationMethod<DescribeLocationNfsRequest, DescribeLocationNfsResponse, DescribeLocationNfsError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationObjectStorageError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an object
 * storage system is configured.
 */
export declare const describeLocationObjectStorage: API.OperationMethod<DescribeLocationObjectStorageRequest, DescribeLocationObjectStorageResponse, DescribeLocationObjectStorageError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationS3Error = InternalException | InvalidRequestException | LocationNotFound | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an S3 bucket
 * is configured.
 */
export declare const describeLocationS3: API.OperationMethod<DescribeLocationS3Request, DescribeLocationS3Response, DescribeLocationS3Error, Credentials | HttpClient.HttpClient>;
export type DescribeLocationSmbError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for a Server
 * Message Block (SMB) file server is configured.
 */
export declare const describeLocationSmb: API.OperationMethod<DescribeLocationSmbRequest, DescribeLocationSmbResponse, DescribeLocationSmbError, Credentials | HttpClient.HttpClient>;
export type DescribeTaskError = InternalException | InvalidRequestException | TaskNotFound | CommonErrors;
/**
 * Provides information about a *task*, which defines where and how
 * DataSync transfers your data.
 */
export declare const describeTask: API.OperationMethod<DescribeTaskRequest, DescribeTaskResponse, DescribeTaskError, Credentials | HttpClient.HttpClient>;
export type DescribeTaskExecutionError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides information about an execution of your DataSync task. You can
 * use this operation to help monitor the progress of an ongoing data transfer or check the
 * results of the transfer.
 *
 * Some `DescribeTaskExecution` response elements are only relevant to a
 * specific task mode. For information, see Understanding task mode differences and Understanding data
 * transfer performance counters.
 */
export declare const describeTaskExecution: API.OperationMethod<DescribeTaskExecutionRequest, DescribeTaskExecutionResponse, DescribeTaskExecutionError, Credentials | HttpClient.HttpClient>;
export type ListAgentsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of DataSync agents that belong to an Amazon Web Services account in the Amazon Web Services Region specified in the request.
 *
 * With pagination, you can reduce the number of agents returned in a response. If you get
 * a truncated list of agents in a response, the response contains a marker that you can specify
 * in your next request to fetch the next page of agents.
 *
 * `ListAgents` is eventually consistent. This means the result of running the
 * operation might not reflect that you just created or deleted an agent. For example, if you
 * create an agent with CreateAgent and then
 * immediately run `ListAgents`, that agent might not show up in the list right away.
 * In situations like this, you can always confirm whether an agent has been created (or deleted)
 * by using DescribeAgent.
 */
export declare const listAgents: API.PaginatedOperationMethod<ListAgentsRequest, ListAgentsResponse, ListAgentsError, Credentials | HttpClient.HttpClient, AgentListEntry>;
export type ListLocationsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of source and destination locations.
 *
 * If you have more locations than are returned in a response (that is, the response
 * returns only a truncated list of your agents), the response contains a token that you can
 * specify in your next request to fetch the next page of locations.
 */
export declare const listLocations: API.PaginatedOperationMethod<ListLocationsRequest, ListLocationsResponse, ListLocationsError, Credentials | HttpClient.HttpClient, LocationListEntry>;
export type ListTagsForResourceError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Returns all the tags associated with an Amazon Web Services resource.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, TagListEntry>;
export type ListTaskExecutionsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of executions for an DataSync transfer task.
 */
export declare const listTaskExecutions: API.PaginatedOperationMethod<ListTaskExecutionsRequest, ListTaskExecutionsResponse, ListTaskExecutionsError, Credentials | HttpClient.HttpClient, TaskExecutionListEntry>;
export type ListTasksError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of the DataSync tasks you created.
 */
export declare const listTasks: API.PaginatedOperationMethod<ListTasksRequest, ListTasksResponse, ListTasksError, Credentials | HttpClient.HttpClient, TaskListEntry>;
export type StartTaskExecutionError = InternalException | InvalidRequestException | LocationAccessTestFailed | CommonErrors;
/**
 * Starts an DataSync transfer task. For each task, you can only run one task
 * execution at a time.
 *
 * There are several steps to a task execution. For more information, see Task execution statuses.
 *
 * If you're planning to transfer data to or from an Amazon S3 location, review
 * how
 * DataSync can affect your S3 request charges and the DataSync pricing page before
 * you begin.
 */
export declare const startTaskExecution: API.OperationMethod<StartTaskExecutionRequest, StartTaskExecutionResponse, StartTaskExecutionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Applies a *tag* to an Amazon Web Services resource. Tags are
 * key-value pairs that can help you manage, filter, and search for your resources.
 *
 * These include DataSync resources, such as locations, tasks, and task
 * executions.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Removes tags from an Amazon Web Services resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Updates the name of an DataSync agent.
 */
export declare const updateAgent: API.OperationMethod<UpdateAgentRequest, UpdateAgentResponse, UpdateAgentError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationAzureBlobError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configurations of the Microsoft Azure Blob Storage transfer
 * location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync transfers with Azure Blob Storage.
 */
export declare const updateLocationAzureBlob: API.OperationMethod<UpdateLocationAzureBlobRequest, UpdateLocationAzureBlobResponse, UpdateLocationAzureBlobError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationEfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Amazon EFS transfer
 * location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with Amazon EFS.
 */
export declare const updateLocationEfs: API.OperationMethod<UpdateLocationEfsRequest, UpdateLocationEfsResponse, UpdateLocationEfsError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationFsxLustreError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Amazon FSx for Lustre
 * transfer location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with FSx for Lustre.
 */
export declare const updateLocationFsxLustre: API.OperationMethod<UpdateLocationFsxLustreRequest, UpdateLocationFsxLustreResponse, UpdateLocationFsxLustreError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationFsxOntapError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Amazon FSx for NetApp ONTAP
 * transfer location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with FSx for ONTAP.
 */
export declare const updateLocationFsxOntap: API.OperationMethod<UpdateLocationFsxOntapRequest, UpdateLocationFsxOntapResponse, UpdateLocationFsxOntapError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationFsxOpenZfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Amazon FSx for OpenZFS
 * transfer location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with FSx for OpenZFS.
 *
 * Request parameters related to `SMB` aren't supported with the
 * `UpdateLocationFsxOpenZfs` operation.
 */
export declare const updateLocationFsxOpenZfs: API.OperationMethod<UpdateLocationFsxOpenZfsRequest, UpdateLocationFsxOpenZfsResponse, UpdateLocationFsxOpenZfsError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationFsxWindowsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Amazon FSx for Windows File Server
 * transfer location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with FSx for Windows File Server.
 */
export declare const updateLocationFsxWindows: API.OperationMethod<UpdateLocationFsxWindowsRequest, UpdateLocationFsxWindowsResponse, UpdateLocationFsxWindowsError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationHdfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Hadoop Distributed File System
 * (HDFS) transfer location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with an HDFS cluster.
 */
export declare const updateLocationHdfs: API.OperationMethod<UpdateLocationHdfsRequest, UpdateLocationHdfsResponse, UpdateLocationHdfsError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationNfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Network File System (NFS) transfer
 * location that you're using with DataSync.
 *
 * For more information, see Configuring transfers with an NFS
 * file server.
 */
export declare const updateLocationNfs: API.OperationMethod<UpdateLocationNfsRequest, UpdateLocationNfsResponse, UpdateLocationNfsError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationObjectStorageError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the object storage transfer location
 * that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with an object storage system.
 */
export declare const updateLocationObjectStorage: API.OperationMethod<UpdateLocationObjectStorageRequest, UpdateLocationObjectStorageResponse, UpdateLocationObjectStorageError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationS3Error = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Amazon S3 transfer location
 * that you're using with DataSync.
 *
 * Before you begin, make sure that you read the following topics:
 *
 * - Storage
 * class considerations with Amazon S3 locations
 *
 * - Evaluating S3 request costs when using DataSync
 */
export declare const updateLocationS3: API.OperationMethod<UpdateLocationS3Request, UpdateLocationS3Response, UpdateLocationS3Error, Credentials | HttpClient.HttpClient>;
export type UpdateLocationSmbError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Server Message Block (SMB) transfer
 * location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with an SMB file server.
 */
export declare const updateLocationSmb: API.OperationMethod<UpdateLocationSmbRequest, UpdateLocationSmbResponse, UpdateLocationSmbError, Credentials | HttpClient.HttpClient>;
export type UpdateTaskError = InternalException | InvalidRequestException | TaskNotFound | CommonErrors;
/**
 * Updates the configuration of a *task*, which defines where and how
 * DataSync transfers your data.
 */
export declare const updateTask: API.OperationMethod<UpdateTaskRequest, UpdateTaskResponse, UpdateTaskError, Credentials | HttpClient.HttpClient>;
export type UpdateTaskExecutionError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Updates the configuration of a running DataSync task execution.
 *
 * Currently, the only `Option` that you can modify with
 * `UpdateTaskExecution` is
 * BytesPerSecond
 * , which throttles bandwidth for a running or queued task
 * execution.
 */
export declare const updateTaskExecution: API.OperationMethod<UpdateTaskExecutionRequest, UpdateTaskExecutionResponse, UpdateTaskExecutionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=datasync.d.ts.map