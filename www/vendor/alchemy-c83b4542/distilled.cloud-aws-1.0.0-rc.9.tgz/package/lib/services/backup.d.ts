import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AlreadyExistsException_base: S.Class<AlreadyExistsException, S.TaggedStruct<"AlreadyExistsException", {
    readonly Code: any;
    readonly message: any;
    readonly CreatorRequestId: any;
    readonly Arn: any;
    readonly Type: any;
    readonly Context: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly Code: any;
    readonly message: any;
    readonly Type: any;
    readonly Context: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DependencyFailureException_base: S.Class<DependencyFailureException, S.TaggedStruct<"DependencyFailureException", {
    readonly Code: any;
    readonly message: any;
    readonly Type: any;
    readonly Context: any;
}>, import("effect/Cause").YieldableError>;
export declare class DependencyFailureException extends /*@__PURE__*/ DependencyFailureException_base {
}
declare const InvalidParameterValueException_base: S.Class<InvalidParameterValueException, S.TaggedStruct<"InvalidParameterValueException", {
    readonly Code: any;
    readonly message: any;
    readonly Type: any;
    readonly Context: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly Code: any;
    readonly message: any;
    readonly Type: any;
    readonly Context: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidResourceStateException_base: S.Class<InvalidResourceStateException, S.TaggedStruct<"InvalidResourceStateException", {
    readonly Code: any;
    readonly message: any;
    readonly Type: any;
    readonly Context: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidResourceStateException extends /*@__PURE__*/ InvalidResourceStateException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly Code: any;
    readonly message: any;
    readonly Type: any;
    readonly Context: any;
}>, import("effect/Cause").YieldableError>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MissingParameterValueException_base: S.Class<MissingParameterValueException, S.TaggedStruct<"MissingParameterValueException", {
    readonly Code: any;
    readonly message: any;
    readonly Type: any;
    readonly Context: any;
}>, import("effect/Cause").YieldableError>;
export declare class MissingParameterValueException extends /*@__PURE__*/ MissingParameterValueException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly Code: any;
    readonly message: any;
    readonly Type: any;
    readonly Context: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly Code: any;
    readonly message: any;
    readonly Type: any;
    readonly Context: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
export type BackupVaultName = string;
export type ARN = string;
export type RequesterComment = string | redacted.Redacted<string>;
export interface AssociateBackupVaultMpaApprovalTeamInput {
    BackupVaultName: string;
    MpaApprovalTeamArn: string;
    RequesterComment?: string | redacted.Redacted<string>;
}
export declare const AssociateBackupVaultMpaApprovalTeamInput: S.Schema<AssociateBackupVaultMpaApprovalTeamInput>;
export interface AssociateBackupVaultMpaApprovalTeamResponse {
}
export declare const AssociateBackupVaultMpaApprovalTeamResponse: S.Schema<AssociateBackupVaultMpaApprovalTeamResponse>;
export interface CancelLegalHoldInput {
    LegalHoldId: string;
    CancelDescription: string;
    RetainRecordInDays?: number;
}
export declare const CancelLegalHoldInput: S.Schema<CancelLegalHoldInput>;
export interface CancelLegalHoldOutput {
}
export declare const CancelLegalHoldOutput: S.Schema<CancelLegalHoldOutput>;
export type AccessPointMetadataMapKeyString = string;
export type AccessPointMetadataMapValueString = string;
export type AccessPointMetadataMap = {
    [key: string]: string | undefined;
};
export declare const AccessPointMetadataMap: any;
export type AccessPointPolicy = string;
export type AccessPointName = string;
export type RecoveryPointArn = string;
export type TagMapKeyString = string;
export type TagMapValueString = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateBackupAccessPointRequest {
    AccessPointMetadata?: {
        [key: string]: string | undefined;
    };
    AccessPointPolicy?: string;
    Name: string;
    RecoveryPointArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateBackupAccessPointRequest: S.Schema<CreateBackupAccessPointRequest>;
export type AccessPointArn = string;
export type AccessPointStatus = "AVAILABLE" | "CREATING" | "DELETING" | "DISASSOCIATED" | "DISASSOCIATING" | "EXPIRED" | "FAILED" | (string & {});
export declare const AccessPointStatus: any;
export interface CreateBackupAccessPointResponse {
    AccessPointArn: string;
    Status: AccessPointStatus;
}
export declare const CreateBackupAccessPointResponse: S.Schema<CreateBackupAccessPointResponse>;
export type BackupPlanName = string;
export type BackupRuleName = string;
export type CronExpression = string;
export type WindowMinutes = number;
export type LifecycleDeleteAfterEvent = "DELETE_AFTER_COPY" | (string & {});
export declare const LifecycleDeleteAfterEvent: any;
export interface Lifecycle {
    MoveToColdStorageAfterDays?: number;
    DeleteAfterDays?: number;
    OptInToArchiveForSupportedResources?: boolean;
    DeleteAfterEvent?: LifecycleDeleteAfterEvent;
}
export declare const Lifecycle: S.Schema<Lifecycle>;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export interface CopyAction {
    Lifecycle?: Lifecycle;
    DestinationBackupVaultArn: string;
}
export declare const CopyAction: S.Schema<CopyAction>;
export type CopyActions = CopyAction[];
export declare const CopyActions: any;
export type Timezone = string;
export type ResourceType = string;
export type ResourceTypes = string[];
export declare const ResourceTypes: any;
export interface IndexAction {
    ResourceTypes?: string[];
}
export declare const IndexAction: S.Schema<IndexAction>;
export type IndexActions = IndexAction[];
export declare const IndexActions: any;
export type MalwareScanner = "GUARDDUTY" | (string & {});
export declare const MalwareScanner: any;
export type ScanMode = "FULL_SCAN" | "INCREMENTAL_SCAN" | (string & {});
export declare const ScanMode: any;
export interface ScanAction {
    MalwareScanner?: MalwareScanner;
    ScanMode?: ScanMode;
}
export declare const ScanAction: S.Schema<ScanAction>;
export type ScanActions = ScanAction[];
export declare const ScanActions: any;
export interface BackupRuleInput {
    RuleName: string;
    TargetBackupVaultName: string;
    TargetLogicallyAirGappedBackupVaultArn?: string;
    ScheduleExpression?: string;
    StartWindowMinutes?: number;
    CompletionWindowMinutes?: number;
    Lifecycle?: Lifecycle;
    RecoveryPointTags?: {
        [key: string]: string | undefined;
    };
    CopyActions?: CopyAction[];
    EnableContinuousBackup?: boolean;
    ScheduleExpressionTimezone?: string;
    IndexActions?: IndexAction[];
    ScanActions?: ScanAction[];
}
export declare const BackupRuleInput: S.Schema<BackupRuleInput>;
export type BackupRulesInput = BackupRuleInput[];
export declare const BackupRulesInput: any;
export type BackupOptionKey = string;
export type BackupOptionValue = string;
export type BackupOptions = {
    [key: string]: string | undefined;
};
export declare const BackupOptions: any;
export interface AdvancedBackupSetting {
    ResourceType?: string;
    BackupOptions?: {
        [key: string]: string | undefined;
    };
}
export declare const AdvancedBackupSetting: S.Schema<AdvancedBackupSetting>;
export type AdvancedBackupSettings = AdvancedBackupSetting[];
export declare const AdvancedBackupSettings: any;
export type IAMRoleArn = string;
export interface ScanSetting {
    MalwareScanner?: MalwareScanner;
    ResourceTypes?: string[];
    ScannerRoleArn?: string;
}
export declare const ScanSetting: S.Schema<ScanSetting>;
export type ScanSettings = ScanSetting[];
export declare const ScanSettings: any;
export interface BackupPlanInput {
    BackupPlanName: string;
    Rules: BackupRuleInput[];
    AdvancedBackupSettings?: AdvancedBackupSetting[];
    ScanSettings?: ScanSetting[];
}
export declare const BackupPlanInput: S.Schema<BackupPlanInput>;
export interface CreateBackupPlanInput {
    BackupPlan: BackupPlanInput;
    BackupPlanTags?: {
        [key: string]: string | undefined;
    };
    CreatorRequestId?: string;
}
export declare const CreateBackupPlanInput: S.Schema<CreateBackupPlanInput>;
export interface CreateBackupPlanOutput {
    BackupPlanId?: string;
    BackupPlanArn?: string;
    CreationDate?: Date;
    VersionId?: string;
    AdvancedBackupSettings?: AdvancedBackupSetting[];
}
export declare const CreateBackupPlanOutput: S.Schema<CreateBackupPlanOutput>;
export type BackupSelectionName = string;
export type ResourceArns = string[];
export declare const ResourceArns: any;
export type ConditionType = "STRINGEQUALS" | (string & {});
export declare const ConditionType: any;
export type ConditionKey = string;
export type ConditionValue = string;
export interface Condition {
    ConditionType: ConditionType;
    ConditionKey: string;
    ConditionValue: string;
}
export declare const Condition: S.Schema<Condition>;
export type ListOfTags = Condition[];
export declare const ListOfTags: any;
export interface ConditionParameter {
    ConditionKey?: string;
    ConditionValue?: string;
}
export declare const ConditionParameter: S.Schema<ConditionParameter>;
export type ConditionParameters = ConditionParameter[];
export declare const ConditionParameters: any;
export interface Conditions {
    StringEquals?: ConditionParameter[];
    StringNotEquals?: ConditionParameter[];
    StringLike?: ConditionParameter[];
    StringNotLike?: ConditionParameter[];
}
export declare const Conditions: S.Schema<Conditions>;
export interface BackupSelection {
    SelectionName: string;
    IamRoleArn: string;
    Resources?: string[];
    ListOfTags?: Condition[];
    NotResources?: string[];
    Conditions?: Conditions;
}
export declare const BackupSelection: S.Schema<BackupSelection>;
export interface CreateBackupSelectionInput {
    BackupPlanId: string;
    BackupSelection: BackupSelection;
    CreatorRequestId?: string;
}
export declare const CreateBackupSelectionInput: S.Schema<CreateBackupSelectionInput>;
export interface CreateBackupSelectionOutput {
    SelectionId?: string;
    BackupPlanId?: string;
    CreationDate?: Date;
}
export declare const CreateBackupSelectionOutput: S.Schema<CreateBackupSelectionOutput>;
export interface CreateBackupVaultInput {
    BackupVaultName: string;
    BackupVaultTags?: {
        [key: string]: string | undefined;
    };
    EncryptionKeyArn?: string;
    CreatorRequestId?: string;
}
export declare const CreateBackupVaultInput: S.Schema<CreateBackupVaultInput>;
export interface CreateBackupVaultOutput {
    BackupVaultName?: string;
    BackupVaultArn?: string;
    CreationDate?: Date;
}
export declare const CreateBackupVaultOutput: S.Schema<CreateBackupVaultOutput>;
export type FrameworkName = string;
export type FrameworkDescription = string;
export type ControlName = string;
export type ParameterName = string;
export type ParameterValue = string;
export interface ControlInputParameter {
    ParameterName?: string;
    ParameterValue?: string;
}
export declare const ControlInputParameter: S.Schema<ControlInputParameter>;
export type ControlInputParameters = ControlInputParameter[];
export declare const ControlInputParameters: any;
export type ComplianceResourceIdList = string[];
export declare const ComplianceResourceIdList: any;
export type ResourceTypeList = string[];
export declare const ResourceTypeList: any;
export type StringMap = {
    [key: string]: string | undefined;
};
export declare const StringMap: any;
export interface ControlScope {
    ComplianceResourceIds?: string[];
    ComplianceResourceTypes?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ControlScope: S.Schema<ControlScope>;
export interface FrameworkControl {
    ControlName: string;
    ControlInputParameters?: ControlInputParameter[];
    ControlScope?: ControlScope;
}
export declare const FrameworkControl: S.Schema<FrameworkControl>;
export type FrameworkControls = FrameworkControl[];
export declare const FrameworkControls: any;
export interface CreateFrameworkInput {
    FrameworkName: string;
    FrameworkDescription?: string;
    FrameworkControls: FrameworkControl[];
    IdempotencyToken?: string;
    FrameworkTags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateFrameworkInput: S.Schema<CreateFrameworkInput>;
export interface CreateFrameworkOutput {
    FrameworkName?: string;
    FrameworkArn?: string;
}
export declare const CreateFrameworkOutput: S.Schema<CreateFrameworkOutput>;
export type VaultNames = string[];
export declare const VaultNames: any;
export type ResourceIdentifiers = string[];
export declare const ResourceIdentifiers: any;
export interface DateRange {
    FromDate: Date;
    ToDate: Date;
}
export declare const DateRange: S.Schema<DateRange>;
export interface RecoveryPointSelection {
    VaultNames?: string[];
    ResourceIdentifiers?: string[];
    DateRange?: DateRange;
}
export declare const RecoveryPointSelection: S.Schema<RecoveryPointSelection>;
export interface CreateLegalHoldInput {
    Title: string;
    Description: string;
    IdempotencyToken?: string;
    RecoveryPointSelection?: RecoveryPointSelection;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateLegalHoldInput: S.Schema<CreateLegalHoldInput>;
export type LegalHoldStatus = "CREATING" | "ACTIVE" | "CANCELING" | "CANCELED" | (string & {});
export declare const LegalHoldStatus: any;
export interface CreateLegalHoldOutput {
    Title?: string;
    Status?: LegalHoldStatus;
    Description?: string;
    LegalHoldId?: string;
    LegalHoldArn?: string;
    CreationDate?: Date;
    RecoveryPointSelection?: RecoveryPointSelection;
}
export declare const CreateLegalHoldOutput: S.Schema<CreateLegalHoldOutput>;
export interface CreateLogicallyAirGappedBackupVaultInput {
    BackupVaultName: string;
    BackupVaultTags?: {
        [key: string]: string | undefined;
    };
    CreatorRequestId?: string;
    MinRetentionDays: number;
    MaxRetentionDays: number;
    EncryptionKeyArn?: string;
}
export declare const CreateLogicallyAirGappedBackupVaultInput: S.Schema<CreateLogicallyAirGappedBackupVaultInput>;
export type VaultState = "CREATING" | "AVAILABLE" | "FAILED" | (string & {});
export declare const VaultState: any;
export interface CreateLogicallyAirGappedBackupVaultOutput {
    BackupVaultName?: string;
    BackupVaultArn?: string;
    CreationDate?: Date;
    VaultState?: VaultState;
}
export declare const CreateLogicallyAirGappedBackupVaultOutput: S.Schema<CreateLogicallyAirGappedBackupVaultOutput>;
export type ReportPlanName = string;
export type ReportPlanDescription = string;
export type FormatList = string[];
export declare const FormatList: any;
export interface ReportDeliveryChannel {
    S3BucketName: string;
    S3KeyPrefix?: string;
    Formats?: string[];
}
export declare const ReportDeliveryChannel: S.Schema<ReportDeliveryChannel>;
export type StringList = string[];
export declare const StringList: any;
export interface ReportSetting {
    ReportTemplate: string;
    FrameworkArns?: string[];
    NumberOfFrameworks?: number;
    Accounts?: string[];
    OrganizationUnits?: string[];
    Regions?: string[];
}
export declare const ReportSetting: S.Schema<ReportSetting>;
export interface CreateReportPlanInput {
    ReportPlanName: string;
    ReportPlanDescription?: string;
    ReportDeliveryChannel: ReportDeliveryChannel;
    ReportSetting: ReportSetting;
    ReportPlanTags?: {
        [key: string]: string | undefined;
    };
    IdempotencyToken?: string;
}
export declare const CreateReportPlanInput: S.Schema<CreateReportPlanInput>;
export interface CreateReportPlanOutput {
    ReportPlanName?: string;
    ReportPlanArn?: string;
    CreationTime?: Date;
}
export declare const CreateReportPlanOutput: S.Schema<CreateReportPlanOutput>;
export interface CreateRestoreAccessBackupVaultInput {
    SourceBackupVaultArn: string;
    BackupVaultName?: string;
    BackupVaultTags?: {
        [key: string]: string | undefined;
    };
    CreatorRequestId?: string;
    RequesterComment?: string | redacted.Redacted<string>;
}
export declare const CreateRestoreAccessBackupVaultInput: S.Schema<CreateRestoreAccessBackupVaultInput>;
export interface CreateRestoreAccessBackupVaultOutput {
    RestoreAccessBackupVaultArn?: string;
    VaultState?: VaultState;
    RestoreAccessBackupVaultName?: string;
    CreationDate?: Date;
}
export declare const CreateRestoreAccessBackupVaultOutput: S.Schema<CreateRestoreAccessBackupVaultOutput>;
export type RestoreTestingRecoveryPointSelectionAlgorithm = "LATEST_WITHIN_WINDOW" | "RANDOM_WITHIN_WINDOW" | (string & {});
export declare const RestoreTestingRecoveryPointSelectionAlgorithm: any;
export type RestoreTestingRecoveryPointType = "CONTINUOUS" | "SNAPSHOT" | (string & {});
export declare const RestoreTestingRecoveryPointType: any;
export type RestoreTestingRecoveryPointTypeList = RestoreTestingRecoveryPointType[];
export declare const RestoreTestingRecoveryPointTypeList: any;
export interface RestoreTestingRecoveryPointSelection {
    Algorithm?: RestoreTestingRecoveryPointSelectionAlgorithm;
    ExcludeVaults?: string[];
    IncludeVaults?: string[];
    RecoveryPointTypes?: RestoreTestingRecoveryPointType[];
    SelectionWindowDays?: number;
}
export declare const RestoreTestingRecoveryPointSelection: S.Schema<RestoreTestingRecoveryPointSelection>;
export interface RestoreTestingPlanForCreate {
    RecoveryPointSelection: RestoreTestingRecoveryPointSelection;
    RestoreTestingPlanName: string;
    ScheduleExpression: string;
    ScheduleExpressionTimezone?: string;
    StartWindowHours?: number;
}
export declare const RestoreTestingPlanForCreate: S.Schema<RestoreTestingPlanForCreate>;
export type SensitiveStringMap = {
    [key: string]: string | undefined;
};
export declare const SensitiveStringMap: any;
export interface CreateRestoreTestingPlanInput {
    CreatorRequestId?: string;
    RestoreTestingPlan: RestoreTestingPlanForCreate;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateRestoreTestingPlanInput: S.Schema<CreateRestoreTestingPlanInput>;
export interface CreateRestoreTestingPlanOutput {
    CreationTime: Date;
    RestoreTestingPlanArn: string;
    RestoreTestingPlanName: string;
}
export declare const CreateRestoreTestingPlanOutput: S.Schema<CreateRestoreTestingPlanOutput>;
export interface KeyValue {
    Key: string;
    Value: string;
}
export declare const KeyValue: S.Schema<KeyValue>;
export type KeyValueList = KeyValue[];
export declare const KeyValueList: any;
export interface ProtectedResourceConditions {
    StringEquals?: KeyValue[];
    StringNotEquals?: KeyValue[];
}
export declare const ProtectedResourceConditions: S.Schema<ProtectedResourceConditions>;
export interface RestoreTestingSelectionForCreate {
    IamRoleArn: string;
    ProtectedResourceArns?: string[];
    ProtectedResourceConditions?: ProtectedResourceConditions;
    ProtectedResourceType: string;
    RestoreMetadataOverrides?: {
        [key: string]: string | undefined;
    };
    RestoreTestingSelectionName: string;
    ValidationWindowHours?: number;
}
export declare const RestoreTestingSelectionForCreate: S.Schema<RestoreTestingSelectionForCreate>;
export interface CreateRestoreTestingSelectionInput {
    CreatorRequestId?: string;
    RestoreTestingPlanName: string;
    RestoreTestingSelection: RestoreTestingSelectionForCreate;
}
export declare const CreateRestoreTestingSelectionInput: S.Schema<CreateRestoreTestingSelectionInput>;
export interface CreateRestoreTestingSelectionOutput {
    CreationTime: Date;
    RestoreTestingPlanArn: string;
    RestoreTestingPlanName: string;
    RestoreTestingSelectionName: string;
}
export declare const CreateRestoreTestingSelectionOutput: S.Schema<CreateRestoreTestingSelectionOutput>;
export type TieringConfigurationName = string;
export type BackupVaultNameOrWildcard = string;
export type TieringDownSettingsInDays = number;
export interface ResourceSelection {
    Resources: string[];
    TieringDownSettingsInDays: number;
    ResourceType: string;
}
export declare const ResourceSelection: S.Schema<ResourceSelection>;
export type ResourceSelections = ResourceSelection[];
export declare const ResourceSelections: any;
export interface TieringConfigurationInputForCreate {
    TieringConfigurationName: string;
    BackupVaultName: string;
    ResourceSelection: ResourceSelection[];
}
export declare const TieringConfigurationInputForCreate: S.Schema<TieringConfigurationInputForCreate>;
export type CreatorRequestId = string;
export interface CreateTieringConfigurationInput {
    TieringConfiguration: TieringConfigurationInputForCreate;
    TieringConfigurationTags?: {
        [key: string]: string | undefined;
    };
    CreatorRequestId?: string;
}
export declare const CreateTieringConfigurationInput: S.Schema<CreateTieringConfigurationInput>;
export interface CreateTieringConfigurationOutput {
    TieringConfigurationArn?: string;
    TieringConfigurationName?: string;
    CreationTime?: Date;
}
export declare const CreateTieringConfigurationOutput: S.Schema<CreateTieringConfigurationOutput>;
export interface DeleteBackupAccessPointInput {
    AccessPointArn: string;
}
export declare const DeleteBackupAccessPointInput: S.Schema<DeleteBackupAccessPointInput>;
export interface DeleteBackupAccessPointResponse {
}
export declare const DeleteBackupAccessPointResponse: S.Schema<DeleteBackupAccessPointResponse>;
export interface DeleteBackupPlanInput {
    BackupPlanId: string;
}
export declare const DeleteBackupPlanInput: S.Schema<DeleteBackupPlanInput>;
export interface DeleteBackupPlanOutput {
    BackupPlanId?: string;
    BackupPlanArn?: string;
    DeletionDate?: Date;
    VersionId?: string;
}
export declare const DeleteBackupPlanOutput: S.Schema<DeleteBackupPlanOutput>;
export interface DeleteBackupSelectionInput {
    BackupPlanId: string;
    SelectionId: string;
}
export declare const DeleteBackupSelectionInput: S.Schema<DeleteBackupSelectionInput>;
export interface DeleteBackupSelectionResponse {
}
export declare const DeleteBackupSelectionResponse: S.Schema<DeleteBackupSelectionResponse>;
export interface DeleteBackupVaultInput {
    BackupVaultName: string;
}
export declare const DeleteBackupVaultInput: S.Schema<DeleteBackupVaultInput>;
export interface DeleteBackupVaultResponse {
}
export declare const DeleteBackupVaultResponse: S.Schema<DeleteBackupVaultResponse>;
export interface DeleteBackupVaultAccessPolicyInput {
    BackupVaultName: string;
}
export declare const DeleteBackupVaultAccessPolicyInput: S.Schema<DeleteBackupVaultAccessPolicyInput>;
export interface DeleteBackupVaultAccessPolicyResponse {
}
export declare const DeleteBackupVaultAccessPolicyResponse: S.Schema<DeleteBackupVaultAccessPolicyResponse>;
export interface DeleteBackupVaultLockConfigurationInput {
    BackupVaultName: string;
}
export declare const DeleteBackupVaultLockConfigurationInput: S.Schema<DeleteBackupVaultLockConfigurationInput>;
export interface DeleteBackupVaultLockConfigurationResponse {
}
export declare const DeleteBackupVaultLockConfigurationResponse: S.Schema<DeleteBackupVaultLockConfigurationResponse>;
export interface DeleteBackupVaultNotificationsInput {
    BackupVaultName: string;
}
export declare const DeleteBackupVaultNotificationsInput: S.Schema<DeleteBackupVaultNotificationsInput>;
export interface DeleteBackupVaultNotificationsResponse {
}
export declare const DeleteBackupVaultNotificationsResponse: S.Schema<DeleteBackupVaultNotificationsResponse>;
export interface DeleteFrameworkInput {
    FrameworkName: string;
}
export declare const DeleteFrameworkInput: S.Schema<DeleteFrameworkInput>;
export interface DeleteFrameworkResponse {
}
export declare const DeleteFrameworkResponse: S.Schema<DeleteFrameworkResponse>;
export interface DeleteRecoveryPointInput {
    BackupVaultName: string;
    RecoveryPointArn: string;
}
export declare const DeleteRecoveryPointInput: S.Schema<DeleteRecoveryPointInput>;
export interface DeleteRecoveryPointResponse {
}
export declare const DeleteRecoveryPointResponse: S.Schema<DeleteRecoveryPointResponse>;
export interface DeleteReportPlanInput {
    ReportPlanName: string;
}
export declare const DeleteReportPlanInput: S.Schema<DeleteReportPlanInput>;
export interface DeleteReportPlanResponse {
}
export declare const DeleteReportPlanResponse: S.Schema<DeleteReportPlanResponse>;
export interface DeleteRestoreTestingPlanInput {
    RestoreTestingPlanName: string;
}
export declare const DeleteRestoreTestingPlanInput: S.Schema<DeleteRestoreTestingPlanInput>;
export interface DeleteRestoreTestingPlanResponse {
}
export declare const DeleteRestoreTestingPlanResponse: S.Schema<DeleteRestoreTestingPlanResponse>;
export interface DeleteRestoreTestingSelectionInput {
    RestoreTestingPlanName: string;
    RestoreTestingSelectionName: string;
}
export declare const DeleteRestoreTestingSelectionInput: S.Schema<DeleteRestoreTestingSelectionInput>;
export interface DeleteRestoreTestingSelectionResponse {
}
export declare const DeleteRestoreTestingSelectionResponse: S.Schema<DeleteRestoreTestingSelectionResponse>;
export interface DeleteTieringConfigurationInput {
    TieringConfigurationName: string;
}
export declare const DeleteTieringConfigurationInput: S.Schema<DeleteTieringConfigurationInput>;
export interface DeleteTieringConfigurationOutput {
}
export declare const DeleteTieringConfigurationOutput: S.Schema<DeleteTieringConfigurationOutput>;
export interface DescribeBackupAccessPointInput {
    AccessPointArn: string;
}
export declare const DescribeBackupAccessPointInput: S.Schema<DescribeBackupAccessPointInput>;
export type BackupVaultArn = string;
export type ResourceArn = string;
export interface DescribeBackupAccessPointResponse {
    AccessPointArn: string;
    AccessPointMetadata?: {
        [key: string]: string | undefined;
    };
    BackupVaultArn?: string;
    BackupVaultName: string;
    CreationTime: Date;
    Name: string;
    RecoveryPointArn: string;
    ResourceArn: string;
    ResourceType: string;
    Status: AccessPointStatus;
    StatusMessage?: string;
}
export declare const DescribeBackupAccessPointResponse: S.Schema<DescribeBackupAccessPointResponse>;
export interface DescribeBackupJobInput {
    BackupJobId: string;
}
export declare const DescribeBackupJobInput: S.Schema<DescribeBackupJobInput>;
export type AccountId = string;
export type BackupJobState = "CREATED" | "PENDING" | "RUNNING" | "ABORTING" | "ABORTED" | "COMPLETED" | "FAILED" | "EXPIRED" | "PARTIAL" | (string & {});
export declare const BackupJobState: any;
export interface RecoveryPointCreator {
    BackupPlanId?: string;
    BackupPlanArn?: string;
    BackupPlanName?: string;
    BackupPlanVersion?: string;
    BackupRuleId?: string;
    BackupRuleName?: string;
    BackupRuleCron?: string;
    BackupRuleTimezone?: string;
}
export declare const RecoveryPointCreator: S.Schema<RecoveryPointCreator>;
export type BackupJobChildJobsInState = {
    [key in BackupJobState]?: number;
};
export declare const BackupJobChildJobsInState: any;
export interface DescribeBackupJobOutput {
    AccountId?: string;
    BackupJobId?: string;
    BackupVaultName?: string;
    RecoveryPointLifecycle?: Lifecycle;
    BackupVaultArn?: string;
    VaultType?: string;
    VaultLockState?: string;
    RecoveryPointArn?: string;
    EncryptionKeyArn?: string;
    IsEncrypted?: boolean;
    ResourceArn?: string;
    CreationDate?: Date;
    CompletionDate?: Date;
    State?: BackupJobState;
    StatusMessage?: string;
    PercentDone?: string;
    BackupSizeInBytes?: number;
    IamRoleArn?: string;
    CreatedBy?: RecoveryPointCreator;
    ResourceType?: string;
    BytesTransferred?: number;
    ExpectedCompletionDate?: Date;
    StartBy?: Date;
    BackupOptions?: {
        [key: string]: string | undefined;
    };
    BackupType?: string;
    ParentJobId?: string;
    IsParent?: boolean;
    NumberOfChildJobs?: number;
    ChildJobsInState?: {
        [key: string]: number | undefined;
    };
    ResourceName?: string;
    InitiationDate?: Date;
    MessageCategory?: string;
}
export declare const DescribeBackupJobOutput: S.Schema<DescribeBackupJobOutput>;
export interface DescribeBackupVaultInput {
    BackupVaultName: string;
    BackupVaultAccountId?: string;
}
export declare const DescribeBackupVaultInput: S.Schema<DescribeBackupVaultInput>;
export type VaultType = "BACKUP_VAULT" | "LOGICALLY_AIR_GAPPED_BACKUP_VAULT" | "RESTORE_ACCESS_BACKUP_VAULT" | (string & {});
export declare const VaultType: any;
export type Long2 = number;
export type MpaSessionStatus = "PENDING" | "APPROVED" | "FAILED" | (string & {});
export declare const MpaSessionStatus: any;
export interface LatestMpaApprovalTeamUpdate {
    MpaSessionArn?: string;
    Status?: MpaSessionStatus;
    StatusMessage?: string;
    InitiationDate?: Date;
    ExpiryDate?: Date;
}
export declare const LatestMpaApprovalTeamUpdate: S.Schema<LatestMpaApprovalTeamUpdate>;
export type EncryptionKeyType = "AWS_OWNED_KMS_KEY" | "CUSTOMER_MANAGED_KMS_KEY" | (string & {});
export declare const EncryptionKeyType: any;
export interface DescribeBackupVaultOutput {
    BackupVaultName?: string;
    BackupVaultArn?: string;
    VaultType?: VaultType;
    VaultState?: VaultState;
    EncryptionKeyArn?: string;
    CreationDate?: Date;
    CreatorRequestId?: string;
    NumberOfRecoveryPoints?: number;
    Locked?: boolean;
    MinRetentionDays?: number;
    MaxRetentionDays?: number;
    LockDate?: Date;
    SourceBackupVaultArn?: string;
    MpaApprovalTeamArn?: string;
    MpaSessionArn?: string;
    LatestMpaApprovalTeamUpdate?: LatestMpaApprovalTeamUpdate;
    EncryptionKeyType?: EncryptionKeyType;
}
export declare const DescribeBackupVaultOutput: S.Schema<DescribeBackupVaultOutput>;
export interface DescribeCopyJobInput {
    CopyJobId: string;
}
export declare const DescribeCopyJobInput: S.Schema<DescribeCopyJobInput>;
export type CopyJobState = "CREATED" | "RUNNING" | "COMPLETED" | "FAILED" | "PARTIAL" | (string & {});
export declare const CopyJobState: any;
export type CopyJobChildJobsInState = {
    [key in CopyJobState]?: number;
};
export declare const CopyJobChildJobsInState: any;
export interface CopyJob {
    AccountId?: string;
    CopyJobId?: string;
    SourceBackupVaultArn?: string;
    SourceRecoveryPointArn?: string;
    DestinationBackupVaultArn?: string;
    DestinationVaultType?: string;
    DestinationVaultLockState?: string;
    DestinationRecoveryPointArn?: string;
    DestinationEncryptionKeyArn?: string;
    DestinationRecoveryPointLifecycle?: Lifecycle;
    ResourceArn?: string;
    CreationDate?: Date;
    CompletionDate?: Date;
    State?: CopyJobState;
    StatusMessage?: string;
    BackupSizeInBytes?: number;
    IamRoleArn?: string;
    CreatedBy?: RecoveryPointCreator;
    CreatedByBackupJobId?: string;
    ResourceType?: string;
    ParentJobId?: string;
    IsParent?: boolean;
    CompositeMemberIdentifier?: string;
    NumberOfChildJobs?: number;
    ChildJobsInState?: {
        [key: string]: number | undefined;
    };
    ResourceName?: string;
    MessageCategory?: string;
}
export declare const CopyJob: S.Schema<CopyJob>;
export interface DescribeCopyJobOutput {
    CopyJob?: CopyJob;
}
export declare const DescribeCopyJobOutput: S.Schema<DescribeCopyJobOutput>;
export interface DescribeFrameworkInput {
    FrameworkName: string;
}
export declare const DescribeFrameworkInput: S.Schema<DescribeFrameworkInput>;
export interface DescribeFrameworkOutput {
    FrameworkName?: string;
    FrameworkArn?: string;
    FrameworkDescription?: string;
    FrameworkControls?: FrameworkControl[];
    CreationTime?: Date;
    DeploymentStatus?: string;
    FrameworkStatus?: string;
    IdempotencyToken?: string;
}
export declare const DescribeFrameworkOutput: S.Schema<DescribeFrameworkOutput>;
export interface DescribeGlobalSettingsInput {
}
export declare const DescribeGlobalSettingsInput: S.Schema<DescribeGlobalSettingsInput>;
export type GlobalSettingsName = string;
export type GlobalSettingsValue = string;
export type GlobalSettings = {
    [key: string]: string | undefined;
};
export declare const GlobalSettings: any;
export interface DescribeGlobalSettingsOutput {
    GlobalSettings?: {
        [key: string]: string | undefined;
    };
    LastUpdateTime?: Date;
}
export declare const DescribeGlobalSettingsOutput: S.Schema<DescribeGlobalSettingsOutput>;
export interface DescribeProtectedResourceInput {
    ResourceArn: string;
}
export declare const DescribeProtectedResourceInput: S.Schema<DescribeProtectedResourceInput>;
export interface DescribeProtectedResourceOutput {
    ResourceArn?: string;
    ResourceType?: string;
    LastBackupTime?: Date;
    ResourceName?: string;
    LastBackupVaultArn?: string;
    LastRecoveryPointArn?: string;
    LatestRestoreExecutionTimeMinutes?: number;
    LatestRestoreJobCreationDate?: Date;
    LatestRestoreRecoveryPointCreationDate?: Date;
}
export declare const DescribeProtectedResourceOutput: S.Schema<DescribeProtectedResourceOutput>;
export interface DescribeRecoveryPointInput {
    BackupVaultName: string;
    RecoveryPointArn: string;
    BackupVaultAccountId?: string;
}
export declare const DescribeRecoveryPointInput: S.Schema<DescribeRecoveryPointInput>;
export type RecoveryPointStatus = "COMPLETED" | "PARTIAL" | "DELETING" | "EXPIRED" | "AVAILABLE" | "STOPPED" | "CREATING" | (string & {});
export declare const RecoveryPointStatus: any;
export interface CalculatedLifecycle {
    MoveToColdStorageAt?: Date;
    DeleteAt?: Date;
}
export declare const CalculatedLifecycle: S.Schema<CalculatedLifecycle>;
export type StorageClass = "WARM" | "COLD" | "DELETED" | (string & {});
export declare const StorageClass: any;
export type IndexStatus = "PENDING" | "ACTIVE" | "FAILED" | "DELETING" | (string & {});
export declare const IndexStatus: any;
export type ScanJobState = "COMPLETED" | "COMPLETED_WITH_ISSUES" | "FAILED" | "CANCELED" | (string & {});
export declare const ScanJobState: any;
export type ScanFinding = "MALWARE" | (string & {});
export declare const ScanFinding: any;
export type ScanFindings = ScanFinding[];
export declare const ScanFindings: any;
export interface ScanResult {
    MalwareScanner?: MalwareScanner;
    ScanJobState?: ScanJobState;
    LastScanTimestamp?: Date;
    Findings?: ScanFinding[];
}
export declare const ScanResult: S.Schema<ScanResult>;
export type ScanResults = ScanResult[];
export declare const ScanResults: any;
export interface DescribeRecoveryPointOutput {
    RecoveryPointArn?: string;
    BackupVaultName?: string;
    BackupVaultArn?: string;
    SourceBackupVaultArn?: string;
    ResourceArn?: string;
    ResourceType?: string;
    CreatedBy?: RecoveryPointCreator;
    IamRoleArn?: string;
    Status?: RecoveryPointStatus;
    StatusMessage?: string;
    CreationDate?: Date;
    InitiationDate?: Date;
    CompletionDate?: Date;
    BackupSizeInBytes?: number;
    CalculatedLifecycle?: CalculatedLifecycle;
    Lifecycle?: Lifecycle;
    EncryptionKeyArn?: string;
    IsEncrypted?: boolean;
    StorageClass?: StorageClass;
    LastRestoreTime?: Date;
    ParentRecoveryPointArn?: string;
    CompositeMemberIdentifier?: string;
    IsParent?: boolean;
    ResourceName?: string;
    VaultType?: VaultType;
    IndexStatus?: IndexStatus;
    IndexStatusMessage?: string;
    EncryptionKeyType?: EncryptionKeyType;
    ScanResults?: ScanResult[];
}
export declare const DescribeRecoveryPointOutput: S.Schema<DescribeRecoveryPointOutput>;
export interface DescribeRegionSettingsInput {
}
export declare const DescribeRegionSettingsInput: S.Schema<DescribeRegionSettingsInput>;
export type IsEnabled = boolean;
export type ResourceTypeOptInPreference = {
    [key: string]: boolean | undefined;
};
export declare const ResourceTypeOptInPreference: any;
export type ResourceTypeManagementPreference = {
    [key: string]: boolean | undefined;
};
export declare const ResourceTypeManagementPreference: any;
export interface DescribeRegionSettingsOutput {
    ResourceTypeOptInPreference?: {
        [key: string]: boolean | undefined;
    };
    ResourceTypeManagementPreference?: {
        [key: string]: boolean | undefined;
    };
}
export declare const DescribeRegionSettingsOutput: S.Schema<DescribeRegionSettingsOutput>;
export type ReportJobId = string;
export interface DescribeReportJobInput {
    ReportJobId: string;
}
export declare const DescribeReportJobInput: S.Schema<DescribeReportJobInput>;
export interface ReportDestination {
    S3BucketName?: string;
    S3Keys?: string[];
}
export declare const ReportDestination: S.Schema<ReportDestination>;
export interface ReportJob {
    ReportJobId?: string;
    ReportPlanArn?: string;
    ReportTemplate?: string;
    CreationTime?: Date;
    CompletionTime?: Date;
    Status?: string;
    StatusMessage?: string;
    ReportDestination?: ReportDestination;
}
export declare const ReportJob: S.Schema<ReportJob>;
export interface DescribeReportJobOutput {
    ReportJob?: ReportJob;
}
export declare const DescribeReportJobOutput: S.Schema<DescribeReportJobOutput>;
export interface DescribeReportPlanInput {
    ReportPlanName: string;
}
export declare const DescribeReportPlanInput: S.Schema<DescribeReportPlanInput>;
export interface ReportPlan {
    ReportPlanArn?: string;
    ReportPlanName?: string;
    ReportPlanDescription?: string;
    ReportSetting?: ReportSetting;
    ReportDeliveryChannel?: ReportDeliveryChannel;
    DeploymentStatus?: string;
    CreationTime?: Date;
    LastAttemptedExecutionTime?: Date;
    LastSuccessfulExecutionTime?: Date;
}
export declare const ReportPlan: S.Schema<ReportPlan>;
export interface DescribeReportPlanOutput {
    ReportPlan?: ReportPlan;
}
export declare const DescribeReportPlanOutput: S.Schema<DescribeReportPlanOutput>;
export type RestoreJobId = string;
export interface DescribeRestoreJobInput {
    RestoreJobId: string;
}
export declare const DescribeRestoreJobInput: S.Schema<DescribeRestoreJobInput>;
export type RestoreJobStatus = "PENDING" | "RUNNING" | "COMPLETED" | "ABORTED" | "FAILED" | (string & {});
export declare const RestoreJobStatus: any;
export interface RestoreJobCreator {
    RestoreTestingPlanArn?: string;
}
export declare const RestoreJobCreator: S.Schema<RestoreJobCreator>;
export type RestoreValidationStatus = "FAILED" | "SUCCESSFUL" | "TIMED_OUT" | "VALIDATING" | (string & {});
export declare const RestoreValidationStatus: any;
export type RestoreDeletionStatus = "DELETING" | "FAILED" | "SUCCESSFUL" | (string & {});
export declare const RestoreDeletionStatus: any;
export interface DescribeRestoreJobOutput {
    AccountId?: string;
    RestoreJobId?: string;
    RecoveryPointArn?: string;
    SourceResourceArn?: string;
    BackupVaultArn?: string;
    CreationDate?: Date;
    CompletionDate?: Date;
    Status?: RestoreJobStatus;
    StatusMessage?: string;
    PercentDone?: string;
    BackupSizeInBytes?: number;
    IamRoleArn?: string;
    ExpectedCompletionTimeMinutes?: number;
    CreatedResourceArn?: string;
    ResourceType?: string;
    RecoveryPointCreationDate?: Date;
    CreatedBy?: RestoreJobCreator;
    ValidationStatus?: RestoreValidationStatus;
    ValidationStatusMessage?: string;
    DeletionStatus?: RestoreDeletionStatus;
    DeletionStatusMessage?: string;
    IsParent?: boolean;
    ParentJobId?: string;
}
export declare const DescribeRestoreJobOutput: S.Schema<DescribeRestoreJobOutput>;
export interface DescribeScanJobInput {
    ScanJobId: string;
}
export declare const DescribeScanJobInput: S.Schema<DescribeScanJobInput>;
export interface ScanJobCreator {
    BackupPlanArn: string;
    BackupPlanId: string;
    BackupPlanVersion: string;
    BackupRuleId: string;
}
export declare const ScanJobCreator: S.Schema<ScanJobCreator>;
export type ScanResourceType = "EBS" | "EC2" | "S3" | (string & {});
export declare const ScanResourceType: any;
export type ScanResultStatus = "NO_THREATS_FOUND" | "THREATS_FOUND" | "UNKNOWN" | (string & {});
export declare const ScanResultStatus: any;
export interface ScanResultInfo {
    ScanResultStatus: ScanResultStatus;
}
export declare const ScanResultInfo: S.Schema<ScanResultInfo>;
export type ScanState = "CANCELED" | "COMPLETED" | "COMPLETED_WITH_ISSUES" | "CREATED" | "FAILED" | "RUNNING" | (string & {});
export declare const ScanState: any;
export interface DescribeScanJobOutput {
    AccountId: string;
    BackupVaultArn: string;
    BackupVaultName: string;
    CompletionDate?: Date;
    ContinuousScanEndTime?: Date;
    ContinuousScanStartTime?: Date;
    CreatedBy: ScanJobCreator;
    CreationDate: Date;
    IamRoleArn: string;
    MalwareScanner: MalwareScanner;
    RecoveryPointArn: string;
    ResourceArn: string;
    ResourceName: string;
    ResourceType: ScanResourceType;
    ScanBaseRecoveryPointArn?: string;
    ScanId?: string;
    ScanJobId: string;
    ScanMode: ScanMode;
    ScanResult?: ScanResultInfo;
    ScannerRoleArn: string;
    State: ScanState;
    StatusMessage?: string;
}
export declare const DescribeScanJobOutput: S.Schema<DescribeScanJobOutput>;
export interface DisassociateBackupVaultMpaApprovalTeamInput {
    BackupVaultName: string;
    RequesterComment?: string | redacted.Redacted<string>;
}
export declare const DisassociateBackupVaultMpaApprovalTeamInput: S.Schema<DisassociateBackupVaultMpaApprovalTeamInput>;
export interface DisassociateBackupVaultMpaApprovalTeamResponse {
}
export declare const DisassociateBackupVaultMpaApprovalTeamResponse: S.Schema<DisassociateBackupVaultMpaApprovalTeamResponse>;
export interface DisassociateRecoveryPointInput {
    BackupVaultName: string;
    RecoveryPointArn: string;
}
export declare const DisassociateRecoveryPointInput: S.Schema<DisassociateRecoveryPointInput>;
export interface DisassociateRecoveryPointResponse {
}
export declare const DisassociateRecoveryPointResponse: S.Schema<DisassociateRecoveryPointResponse>;
export interface DisassociateRecoveryPointFromParentInput {
    BackupVaultName: string;
    RecoveryPointArn: string;
}
export declare const DisassociateRecoveryPointFromParentInput: S.Schema<DisassociateRecoveryPointFromParentInput>;
export interface DisassociateRecoveryPointFromParentResponse {
}
export declare const DisassociateRecoveryPointFromParentResponse: S.Schema<DisassociateRecoveryPointFromParentResponse>;
export interface ExportBackupPlanTemplateInput {
    BackupPlanId: string;
}
export declare const ExportBackupPlanTemplateInput: S.Schema<ExportBackupPlanTemplateInput>;
export interface ExportBackupPlanTemplateOutput {
    BackupPlanTemplateJson?: string;
}
export declare const ExportBackupPlanTemplateOutput: S.Schema<ExportBackupPlanTemplateOutput>;
export type MaxScheduledRunsPreview = number;
export interface GetBackupPlanInput {
    BackupPlanId: string;
    VersionId?: string;
    MaxScheduledRunsPreview?: number;
}
export declare const GetBackupPlanInput: S.Schema<GetBackupPlanInput>;
export interface BackupRule {
    RuleName: string;
    TargetBackupVaultName: string;
    TargetLogicallyAirGappedBackupVaultArn?: string;
    ScheduleExpression?: string;
    StartWindowMinutes?: number;
    CompletionWindowMinutes?: number;
    Lifecycle?: Lifecycle;
    RecoveryPointTags?: {
        [key: string]: string | undefined;
    };
    RuleId?: string;
    CopyActions?: CopyAction[];
    EnableContinuousBackup?: boolean;
    ScheduleExpressionTimezone?: string;
    IndexActions?: IndexAction[];
    ScanActions?: ScanAction[];
}
export declare const BackupRule: S.Schema<BackupRule>;
export type BackupRules = BackupRule[];
export declare const BackupRules: any;
export interface BackupPlan {
    BackupPlanName: string;
    Rules: BackupRule[];
    AdvancedBackupSettings?: AdvancedBackupSetting[];
    ScanSettings?: ScanSetting[];
}
export declare const BackupPlan: S.Schema<BackupPlan>;
export type RuleExecutionType = "CONTINUOUS" | "SNAPSHOTS" | "CONTINUOUS_AND_SNAPSHOTS" | (string & {});
export declare const RuleExecutionType: any;
export interface ScheduledPlanExecutionMember {
    ExecutionTime?: Date;
    RuleId?: string;
    RuleExecutionType?: RuleExecutionType;
}
export declare const ScheduledPlanExecutionMember: S.Schema<ScheduledPlanExecutionMember>;
export type ScheduledRunsPreview = ScheduledPlanExecutionMember[];
export declare const ScheduledRunsPreview: any;
export interface GetBackupPlanOutput {
    BackupPlan?: BackupPlan;
    BackupPlanId?: string;
    BackupPlanArn?: string;
    VersionId?: string;
    CreatorRequestId?: string;
    CreationDate?: Date;
    DeletionDate?: Date;
    LastExecutionDate?: Date;
    AdvancedBackupSettings?: AdvancedBackupSetting[];
    ScheduledRunsPreview?: ScheduledPlanExecutionMember[];
}
export declare const GetBackupPlanOutput: S.Schema<GetBackupPlanOutput>;
export interface GetBackupPlanFromJSONInput {
    BackupPlanTemplateJson: string;
}
export declare const GetBackupPlanFromJSONInput: S.Schema<GetBackupPlanFromJSONInput>;
export interface GetBackupPlanFromJSONOutput {
    BackupPlan?: BackupPlan;
}
export declare const GetBackupPlanFromJSONOutput: S.Schema<GetBackupPlanFromJSONOutput>;
export interface GetBackupPlanFromTemplateInput {
    BackupPlanTemplateId: string;
}
export declare const GetBackupPlanFromTemplateInput: S.Schema<GetBackupPlanFromTemplateInput>;
export interface GetBackupPlanFromTemplateOutput {
    BackupPlanDocument?: BackupPlan;
}
export declare const GetBackupPlanFromTemplateOutput: S.Schema<GetBackupPlanFromTemplateOutput>;
export interface GetBackupSelectionInput {
    BackupPlanId: string;
    SelectionId: string;
}
export declare const GetBackupSelectionInput: S.Schema<GetBackupSelectionInput>;
export interface GetBackupSelectionOutput {
    BackupSelection?: BackupSelection;
    SelectionId?: string;
    BackupPlanId?: string;
    CreationDate?: Date;
    CreatorRequestId?: string;
}
export declare const GetBackupSelectionOutput: S.Schema<GetBackupSelectionOutput>;
export interface GetBackupVaultAccessPolicyInput {
    BackupVaultName: string;
}
export declare const GetBackupVaultAccessPolicyInput: S.Schema<GetBackupVaultAccessPolicyInput>;
export type IAMPolicy = string;
export interface GetBackupVaultAccessPolicyOutput {
    BackupVaultName?: string;
    BackupVaultArn?: string;
    Policy?: string;
}
export declare const GetBackupVaultAccessPolicyOutput: S.Schema<GetBackupVaultAccessPolicyOutput>;
export interface GetBackupVaultNotificationsInput {
    BackupVaultName: string;
}
export declare const GetBackupVaultNotificationsInput: S.Schema<GetBackupVaultNotificationsInput>;
export type BackupVaultEvent = "BACKUP_JOB_STARTED" | "BACKUP_JOB_COMPLETED" | "BACKUP_JOB_SUCCESSFUL" | "BACKUP_JOB_FAILED" | "BACKUP_JOB_EXPIRED" | "RESTORE_JOB_STARTED" | "RESTORE_JOB_COMPLETED" | "RESTORE_JOB_SUCCESSFUL" | "RESTORE_JOB_FAILED" | "COPY_JOB_STARTED" | "COPY_JOB_SUCCESSFUL" | "COPY_JOB_FAILED" | "RECOVERY_POINT_MODIFIED" | "BACKUP_PLAN_CREATED" | "BACKUP_PLAN_MODIFIED" | "S3_BACKUP_OBJECT_FAILED" | "S3_RESTORE_OBJECT_FAILED" | "CONTINUOUS_BACKUP_INTERRUPTED" | "RECOVERY_POINT_INDEX_COMPLETED" | "RECOVERY_POINT_INDEX_DELETED" | "RECOVERY_POINT_INDEXING_FAILED" | "EKS_RESTORE_OBJECT_FAILED" | "EKS_RESTORE_OBJECT_SKIPPED" | "EKS_BACKUP_OBJECT_FAILED" | "ACCESS_POINT_AVAILABLE" | "ACCESS_POINT_CREATION_FAILED" | "ACCESS_POINT_DELETED" | "ACCESS_POINT_DELETION_FAILED" | "ACCESS_POINT_EXPIRED" | "ACCESS_POINT_DISASSOCIATED" | (string & {});
export declare const BackupVaultEvent: any;
export type BackupVaultEvents = BackupVaultEvent[];
export declare const BackupVaultEvents: any;
export interface GetBackupVaultNotificationsOutput {
    BackupVaultName?: string;
    BackupVaultArn?: string;
    SNSTopicArn?: string;
    BackupVaultEvents?: BackupVaultEvent[];
}
export declare const GetBackupVaultNotificationsOutput: S.Schema<GetBackupVaultNotificationsOutput>;
export interface GetLegalHoldInput {
    LegalHoldId: string;
}
export declare const GetLegalHoldInput: S.Schema<GetLegalHoldInput>;
export interface GetLegalHoldOutput {
    Title?: string;
    Status?: LegalHoldStatus;
    Description?: string;
    CancelDescription?: string;
    LegalHoldId?: string;
    LegalHoldArn?: string;
    CreationDate?: Date;
    CancellationDate?: Date;
    RetainRecordUntil?: Date;
    RecoveryPointSelection?: RecoveryPointSelection;
}
export declare const GetLegalHoldOutput: S.Schema<GetLegalHoldOutput>;
export interface GetPITRMalwareScanResultsInput {
    RecoveryPointArn: string;
    BackupVaultName: string;
    ScanEndTime: Date;
    MalwareScanner: MalwareScanner;
}
export declare const GetPITRMalwareScanResultsInput: S.Schema<GetPITRMalwareScanResultsInput>;
export interface GetPITRMalwareScanResultsOutput {
    ScanEndTime: Date;
    ScanResult: ScanResultInfo;
    LastScanJobTime?: Date;
    ScanId?: string;
    ScanMode?: ScanMode;
}
export declare const GetPITRMalwareScanResultsOutput: S.Schema<GetPITRMalwareScanResultsOutput>;
export interface GetRecoveryPointIndexDetailsInput {
    BackupVaultName: string;
    RecoveryPointArn: string;
}
export declare const GetRecoveryPointIndexDetailsInput: S.Schema<GetRecoveryPointIndexDetailsInput>;
export interface GetRecoveryPointIndexDetailsOutput {
    RecoveryPointArn?: string;
    BackupVaultArn?: string;
    SourceResourceArn?: string;
    IndexCreationDate?: Date;
    IndexDeletionDate?: Date;
    IndexCompletionDate?: Date;
    IndexStatus?: IndexStatus;
    IndexStatusMessage?: string;
    TotalItemsIndexed?: number;
}
export declare const GetRecoveryPointIndexDetailsOutput: S.Schema<GetRecoveryPointIndexDetailsOutput>;
export interface GetRecoveryPointRestoreMetadataInput {
    BackupVaultName: string;
    RecoveryPointArn: string;
    BackupVaultAccountId?: string;
}
export declare const GetRecoveryPointRestoreMetadataInput: S.Schema<GetRecoveryPointRestoreMetadataInput>;
export type MetadataKey = string;
export type MetadataValue = string;
export type Metadata = {
    [key: string]: string | undefined;
};
export declare const Metadata: any;
export interface GetRecoveryPointRestoreMetadataOutput {
    BackupVaultArn?: string;
    RecoveryPointArn?: string;
    RestoreMetadata?: {
        [key: string]: string | undefined;
    };
    ResourceType?: string;
}
export declare const GetRecoveryPointRestoreMetadataOutput: S.Schema<GetRecoveryPointRestoreMetadataOutput>;
export interface GetRestoreJobMetadataInput {
    RestoreJobId: string;
}
export declare const GetRestoreJobMetadataInput: S.Schema<GetRestoreJobMetadataInput>;
export interface GetRestoreJobMetadataOutput {
    RestoreJobId?: string;
    Metadata?: {
        [key: string]: string | undefined;
    };
}
export declare const GetRestoreJobMetadataOutput: S.Schema<GetRestoreJobMetadataOutput>;
export interface GetRestoreTestingInferredMetadataInput {
    BackupVaultAccountId?: string;
    BackupVaultName: string;
    RecoveryPointArn: string;
}
export declare const GetRestoreTestingInferredMetadataInput: S.Schema<GetRestoreTestingInferredMetadataInput>;
export interface GetRestoreTestingInferredMetadataOutput {
    InferredMetadata: {
        [key: string]: string | undefined;
    };
}
export declare const GetRestoreTestingInferredMetadataOutput: S.Schema<GetRestoreTestingInferredMetadataOutput>;
export interface GetRestoreTestingPlanInput {
    RestoreTestingPlanName: string;
}
export declare const GetRestoreTestingPlanInput: S.Schema<GetRestoreTestingPlanInput>;
export interface RestoreTestingPlanForGet {
    CreationTime: Date;
    CreatorRequestId?: string;
    LastExecutionTime?: Date;
    LastUpdateTime?: Date;
    RecoveryPointSelection: RestoreTestingRecoveryPointSelection;
    RestoreTestingPlanArn: string;
    RestoreTestingPlanName: string;
    ScheduleExpression: string;
    ScheduleExpressionTimezone?: string;
    StartWindowHours?: number;
}
export declare const RestoreTestingPlanForGet: S.Schema<RestoreTestingPlanForGet>;
export interface GetRestoreTestingPlanOutput {
    RestoreTestingPlan: RestoreTestingPlanForGet;
}
export declare const GetRestoreTestingPlanOutput: S.Schema<GetRestoreTestingPlanOutput>;
export interface GetRestoreTestingSelectionInput {
    RestoreTestingPlanName: string;
    RestoreTestingSelectionName: string;
}
export declare const GetRestoreTestingSelectionInput: S.Schema<GetRestoreTestingSelectionInput>;
export interface RestoreTestingSelectionForGet {
    CreationTime: Date;
    CreatorRequestId?: string;
    IamRoleArn: string;
    ProtectedResourceArns?: string[];
    ProtectedResourceConditions?: ProtectedResourceConditions;
    ProtectedResourceType: string;
    RestoreMetadataOverrides?: {
        [key: string]: string | undefined;
    };
    RestoreTestingPlanName: string;
    RestoreTestingSelectionName: string;
    ValidationWindowHours?: number;
}
export declare const RestoreTestingSelectionForGet: S.Schema<RestoreTestingSelectionForGet>;
export interface GetRestoreTestingSelectionOutput {
    RestoreTestingSelection: RestoreTestingSelectionForGet;
}
export declare const GetRestoreTestingSelectionOutput: S.Schema<GetRestoreTestingSelectionOutput>;
export interface GetSupportedResourceTypesRequest {
}
export declare const GetSupportedResourceTypesRequest: S.Schema<GetSupportedResourceTypesRequest>;
export interface GetSupportedResourceTypesOutput {
    ResourceTypes?: string[];
}
export declare const GetSupportedResourceTypesOutput: S.Schema<GetSupportedResourceTypesOutput>;
export interface GetTieringConfigurationInput {
    TieringConfigurationName: string;
}
export declare const GetTieringConfigurationInput: S.Schema<GetTieringConfigurationInput>;
export interface TieringConfiguration {
    TieringConfigurationName: string;
    TieringConfigurationArn?: string;
    BackupVaultName: string;
    ResourceSelection: ResourceSelection[];
    CreatorRequestId?: string;
    CreationTime?: Date;
    LastUpdatedTime?: Date;
}
export declare const TieringConfiguration: S.Schema<TieringConfiguration>;
export interface GetTieringConfigurationOutput {
    TieringConfiguration?: TieringConfiguration;
}
export declare const GetTieringConfigurationOutput: S.Schema<GetTieringConfigurationOutput>;
export type ListBackupAccessPointsRequestMaxResultsInteger = number;
export interface ListBackupAccessPointsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListBackupAccessPointsRequest: S.Schema<ListBackupAccessPointsRequest>;
export interface ListAccessPointsMember {
    AccessPointArn: string;
    AccessPointMetadata: {
        [key: string]: string | undefined;
    };
    BackupVaultArn?: string;
    BackupVaultName: string;
    CreationTime: Date;
    Name: string;
    RecoveryPointArn: string;
    ResourceArn: string;
    ResourceType: string;
    Status: AccessPointStatus;
    StatusMessage?: string;
}
export declare const ListAccessPointsMember: S.Schema<ListAccessPointsMember>;
export type BackupAccessPoints = ListAccessPointsMember[];
export declare const BackupAccessPoints: any;
export interface ListBackupAccessPointsResponse {
    BackupAccessPoints: ListAccessPointsMember[];
    NextToken?: string;
}
export declare const ListBackupAccessPointsResponse: S.Schema<ListBackupAccessPointsResponse>;
export type ListBackupAccessPointsByRecoveryPointRequestMaxResultsInteger = number;
export interface ListBackupAccessPointsByRecoveryPointRequest {
    MaxResults?: number;
    NextToken?: string;
    RecoveryPointArn: string;
}
export declare const ListBackupAccessPointsByRecoveryPointRequest: S.Schema<ListBackupAccessPointsByRecoveryPointRequest>;
export interface ListBackupAccessPointsByRecoveryPointResponse {
    BackupAccessPoints: ListAccessPointsMember[];
    NextToken?: string;
}
export declare const ListBackupAccessPointsByRecoveryPointResponse: S.Schema<ListBackupAccessPointsByRecoveryPointResponse>;
export type ListBackupAccessPointsByResourceRequestMaxResultsInteger = number;
export interface ListBackupAccessPointsByResourceRequest {
    MaxResults?: number;
    NextToken?: string;
    ResourceArn: string;
}
export declare const ListBackupAccessPointsByResourceRequest: S.Schema<ListBackupAccessPointsByResourceRequest>;
export interface ListBackupAccessPointsByResourceResponse {
    BackupAccessPoints: ListAccessPointsMember[];
    NextToken?: string;
}
export declare const ListBackupAccessPointsByResourceResponse: S.Schema<ListBackupAccessPointsByResourceResponse>;
export type MaxResults = number;
export interface ListBackupJobsInput {
    NextToken?: string;
    MaxResults?: number;
    ByResourceArn?: string;
    ByState?: BackupJobState;
    ByBackupVaultName?: string;
    ByCreatedBefore?: Date;
    ByCreatedAfter?: Date;
    ByResourceType?: string;
    ByAccountId?: string;
    ByCompleteAfter?: Date;
    ByCompleteBefore?: Date;
    ByParentJobId?: string;
    ByMessageCategory?: string;
}
export declare const ListBackupJobsInput: S.Schema<ListBackupJobsInput>;
export interface BackupJob {
    AccountId?: string;
    BackupJobId?: string;
    BackupVaultName?: string;
    BackupVaultArn?: string;
    VaultType?: string;
    VaultLockState?: string;
    RecoveryPointArn?: string;
    RecoveryPointLifecycle?: Lifecycle;
    EncryptionKeyArn?: string;
    IsEncrypted?: boolean;
    ResourceArn?: string;
    CreationDate?: Date;
    CompletionDate?: Date;
    State?: BackupJobState;
    StatusMessage?: string;
    PercentDone?: string;
    BackupSizeInBytes?: number;
    IamRoleArn?: string;
    CreatedBy?: RecoveryPointCreator;
    ExpectedCompletionDate?: Date;
    StartBy?: Date;
    ResourceType?: string;
    BytesTransferred?: number;
    BackupOptions?: {
        [key: string]: string | undefined;
    };
    BackupType?: string;
    ParentJobId?: string;
    IsParent?: boolean;
    ResourceName?: string;
    InitiationDate?: Date;
    MessageCategory?: string;
}
export declare const BackupJob: S.Schema<BackupJob>;
export type BackupJobsList = BackupJob[];
export declare const BackupJobsList: any;
export interface ListBackupJobsOutput {
    BackupJobs?: BackupJob[];
    NextToken?: string;
}
export declare const ListBackupJobsOutput: S.Schema<ListBackupJobsOutput>;
export type BackupJobStatus = "CREATED" | "PENDING" | "RUNNING" | "ABORTING" | "ABORTED" | "COMPLETED" | "FAILED" | "EXPIRED" | "PARTIAL" | "AGGREGATE_ALL" | "ANY" | (string & {});
export declare const BackupJobStatus: any;
export type MessageCategory = string;
export type AggregationPeriod = "ONE_DAY" | "SEVEN_DAYS" | "FOURTEEN_DAYS" | (string & {});
export declare const AggregationPeriod: any;
export interface ListBackupJobSummariesInput {
    AccountId?: string;
    State?: BackupJobStatus;
    ResourceType?: string;
    MessageCategory?: string;
    AggregationPeriod?: AggregationPeriod;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListBackupJobSummariesInput: S.Schema<ListBackupJobSummariesInput>;
export type Region = string;
export interface BackupJobSummary {
    Region?: string;
    AccountId?: string;
    State?: BackupJobStatus;
    ResourceType?: string;
    MessageCategory?: string;
    Count?: number;
    StartTime?: Date;
    EndTime?: Date;
}
export declare const BackupJobSummary: S.Schema<BackupJobSummary>;
export type BackupJobSummaryList = BackupJobSummary[];
export declare const BackupJobSummaryList: any;
export interface ListBackupJobSummariesOutput {
    BackupJobSummaries?: BackupJobSummary[];
    AggregationPeriod?: string;
    NextToken?: string;
}
export declare const ListBackupJobSummariesOutput: S.Schema<ListBackupJobSummariesOutput>;
export interface ListBackupPlansInput {
    NextToken?: string;
    MaxResults?: number;
    IncludeDeleted?: boolean;
}
export declare const ListBackupPlansInput: S.Schema<ListBackupPlansInput>;
export interface BackupPlansListMember {
    BackupPlanArn?: string;
    BackupPlanId?: string;
    CreationDate?: Date;
    DeletionDate?: Date;
    VersionId?: string;
    BackupPlanName?: string;
    CreatorRequestId?: string;
    LastExecutionDate?: Date;
    AdvancedBackupSettings?: AdvancedBackupSetting[];
}
export declare const BackupPlansListMember: S.Schema<BackupPlansListMember>;
export type BackupPlansList = BackupPlansListMember[];
export declare const BackupPlansList: any;
export interface ListBackupPlansOutput {
    NextToken?: string;
    BackupPlansList?: BackupPlansListMember[];
}
export declare const ListBackupPlansOutput: S.Schema<ListBackupPlansOutput>;
export interface ListBackupPlanTemplatesInput {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListBackupPlanTemplatesInput: S.Schema<ListBackupPlanTemplatesInput>;
export interface BackupPlanTemplatesListMember {
    BackupPlanTemplateId?: string;
    BackupPlanTemplateName?: string;
}
export declare const BackupPlanTemplatesListMember: S.Schema<BackupPlanTemplatesListMember>;
export type BackupPlanTemplatesList = BackupPlanTemplatesListMember[];
export declare const BackupPlanTemplatesList: any;
export interface ListBackupPlanTemplatesOutput {
    NextToken?: string;
    BackupPlanTemplatesList?: BackupPlanTemplatesListMember[];
}
export declare const ListBackupPlanTemplatesOutput: S.Schema<ListBackupPlanTemplatesOutput>;
export interface ListBackupPlanVersionsInput {
    BackupPlanId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListBackupPlanVersionsInput: S.Schema<ListBackupPlanVersionsInput>;
export type BackupPlanVersionsList = BackupPlansListMember[];
export declare const BackupPlanVersionsList: any;
export interface ListBackupPlanVersionsOutput {
    NextToken?: string;
    BackupPlanVersionsList?: BackupPlansListMember[];
}
export declare const ListBackupPlanVersionsOutput: S.Schema<ListBackupPlanVersionsOutput>;
export interface ListBackupSelectionsInput {
    BackupPlanId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListBackupSelectionsInput: S.Schema<ListBackupSelectionsInput>;
export interface BackupSelectionsListMember {
    SelectionId?: string;
    SelectionName?: string;
    BackupPlanId?: string;
    CreationDate?: Date;
    CreatorRequestId?: string;
    IamRoleArn?: string;
}
export declare const BackupSelectionsListMember: S.Schema<BackupSelectionsListMember>;
export type BackupSelectionsList = BackupSelectionsListMember[];
export declare const BackupSelectionsList: any;
export interface ListBackupSelectionsOutput {
    NextToken?: string;
    BackupSelectionsList?: BackupSelectionsListMember[];
}
export declare const ListBackupSelectionsOutput: S.Schema<ListBackupSelectionsOutput>;
export interface ListBackupVaultsInput {
    ByVaultType?: VaultType;
    ByShared?: boolean;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListBackupVaultsInput: S.Schema<ListBackupVaultsInput>;
export interface BackupVaultListMember {
    BackupVaultName?: string;
    BackupVaultArn?: string;
    VaultType?: VaultType;
    VaultState?: VaultState;
    CreationDate?: Date;
    EncryptionKeyArn?: string;
    CreatorRequestId?: string;
    NumberOfRecoveryPoints?: number;
    Locked?: boolean;
    MinRetentionDays?: number;
    MaxRetentionDays?: number;
    LockDate?: Date;
    EncryptionKeyType?: EncryptionKeyType;
}
export declare const BackupVaultListMember: S.Schema<BackupVaultListMember>;
export type BackupVaultList = BackupVaultListMember[];
export declare const BackupVaultList: any;
export interface ListBackupVaultsOutput {
    BackupVaultList?: BackupVaultListMember[];
    NextToken?: string;
}
export declare const ListBackupVaultsOutput: S.Schema<ListBackupVaultsOutput>;
export interface ListCopyJobsInput {
    NextToken?: string;
    MaxResults?: number;
    ByResourceArn?: string;
    ByState?: CopyJobState;
    ByCreatedBefore?: Date;
    ByCreatedAfter?: Date;
    ByResourceType?: string;
    ByDestinationVaultArn?: string;
    ByAccountId?: string;
    ByCompleteBefore?: Date;
    ByCompleteAfter?: Date;
    ByParentJobId?: string;
    ByMessageCategory?: string;
    BySourceRecoveryPointArn?: string;
}
export declare const ListCopyJobsInput: S.Schema<ListCopyJobsInput>;
export type CopyJobsList = CopyJob[];
export declare const CopyJobsList: any;
export interface ListCopyJobsOutput {
    CopyJobs?: CopyJob[];
    NextToken?: string;
}
export declare const ListCopyJobsOutput: S.Schema<ListCopyJobsOutput>;
export type CopyJobStatus = "CREATED" | "RUNNING" | "ABORTING" | "ABORTED" | "COMPLETING" | "COMPLETED" | "FAILING" | "FAILED" | "PARTIAL" | "AGGREGATE_ALL" | "ANY" | (string & {});
export declare const CopyJobStatus: any;
export interface ListCopyJobSummariesInput {
    AccountId?: string;
    State?: CopyJobStatus;
    ResourceType?: string;
    MessageCategory?: string;
    AggregationPeriod?: AggregationPeriod;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListCopyJobSummariesInput: S.Schema<ListCopyJobSummariesInput>;
export interface CopyJobSummary {
    Region?: string;
    AccountId?: string;
    State?: CopyJobStatus;
    ResourceType?: string;
    MessageCategory?: string;
    Count?: number;
    StartTime?: Date;
    EndTime?: Date;
}
export declare const CopyJobSummary: S.Schema<CopyJobSummary>;
export type CopyJobSummaryList = CopyJobSummary[];
export declare const CopyJobSummaryList: any;
export interface ListCopyJobSummariesOutput {
    CopyJobSummaries?: CopyJobSummary[];
    AggregationPeriod?: string;
    NextToken?: string;
}
export declare const ListCopyJobSummariesOutput: S.Schema<ListCopyJobSummariesOutput>;
export type MaxFrameworkInputs = number;
export interface ListFrameworksInput {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListFrameworksInput: S.Schema<ListFrameworksInput>;
export interface Framework {
    FrameworkName?: string;
    FrameworkArn?: string;
    FrameworkDescription?: string;
    NumberOfControls?: number;
    CreationTime?: Date;
    DeploymentStatus?: string;
}
export declare const Framework: S.Schema<Framework>;
export type FrameworkList = Framework[];
export declare const FrameworkList: any;
export interface ListFrameworksOutput {
    Frameworks?: Framework[];
    NextToken?: string;
}
export declare const ListFrameworksOutput: S.Schema<ListFrameworksOutput>;
export interface ListIndexedRecoveryPointsInput {
    NextToken?: string;
    MaxResults?: number;
    SourceResourceArn?: string;
    CreatedBefore?: Date;
    CreatedAfter?: Date;
    ResourceType?: string;
    IndexStatus?: IndexStatus;
}
export declare const ListIndexedRecoveryPointsInput: S.Schema<ListIndexedRecoveryPointsInput>;
export interface IndexedRecoveryPoint {
    RecoveryPointArn?: string;
    SourceResourceArn?: string;
    IamRoleArn?: string;
    BackupCreationDate?: Date;
    ResourceType?: string;
    IndexCreationDate?: Date;
    IndexStatus?: IndexStatus;
    IndexStatusMessage?: string;
    BackupVaultArn?: string;
}
export declare const IndexedRecoveryPoint: S.Schema<IndexedRecoveryPoint>;
export type IndexedRecoveryPointList = IndexedRecoveryPoint[];
export declare const IndexedRecoveryPointList: any;
export interface ListIndexedRecoveryPointsOutput {
    IndexedRecoveryPoints?: IndexedRecoveryPoint[];
    NextToken?: string;
}
export declare const ListIndexedRecoveryPointsOutput: S.Schema<ListIndexedRecoveryPointsOutput>;
export interface ListLegalHoldsInput {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListLegalHoldsInput: S.Schema<ListLegalHoldsInput>;
export interface LegalHold {
    Title?: string;
    Status?: LegalHoldStatus;
    Description?: string;
    LegalHoldId?: string;
    LegalHoldArn?: string;
    CreationDate?: Date;
    CancellationDate?: Date;
}
export declare const LegalHold: S.Schema<LegalHold>;
export type LegalHoldsList = LegalHold[];
export declare const LegalHoldsList: any;
export interface ListLegalHoldsOutput {
    NextToken?: string;
    LegalHolds?: LegalHold[];
}
export declare const ListLegalHoldsOutput: S.Schema<ListLegalHoldsOutput>;
export interface ListProtectedResourcesInput {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListProtectedResourcesInput: S.Schema<ListProtectedResourcesInput>;
export interface ProtectedResource {
    ResourceArn?: string;
    ResourceType?: string;
    LastBackupTime?: Date;
    ResourceName?: string;
    LastBackupVaultArn?: string;
    LastRecoveryPointArn?: string;
}
export declare const ProtectedResource: S.Schema<ProtectedResource>;
export type ProtectedResourcesList = ProtectedResource[];
export declare const ProtectedResourcesList: any;
export interface ListProtectedResourcesOutput {
    Results?: ProtectedResource[];
    NextToken?: string;
}
export declare const ListProtectedResourcesOutput: S.Schema<ListProtectedResourcesOutput>;
export interface ListProtectedResourcesByBackupVaultInput {
    BackupVaultName: string;
    BackupVaultAccountId?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListProtectedResourcesByBackupVaultInput: S.Schema<ListProtectedResourcesByBackupVaultInput>;
export interface ListProtectedResourcesByBackupVaultOutput {
    Results?: ProtectedResource[];
    NextToken?: string;
}
export declare const ListProtectedResourcesByBackupVaultOutput: S.Schema<ListProtectedResourcesByBackupVaultOutput>;
export interface ListRecoveryPointsByBackupVaultInput {
    BackupVaultName: string;
    BackupVaultAccountId?: string;
    NextToken?: string;
    MaxResults?: number;
    ByResourceArn?: string;
    ByResourceType?: string;
    ByBackupPlanId?: string;
    ByCreatedBefore?: Date;
    ByCreatedAfter?: Date;
    ByParentRecoveryPointArn?: string;
}
export declare const ListRecoveryPointsByBackupVaultInput: S.Schema<ListRecoveryPointsByBackupVaultInput>;
export interface AggregatedScanResult {
    FailedScan?: boolean;
    Findings?: ScanFinding[];
    LastComputed?: Date;
}
export declare const AggregatedScanResult: S.Schema<AggregatedScanResult>;
export interface RecoveryPointByBackupVault {
    RecoveryPointArn?: string;
    BackupVaultName?: string;
    BackupVaultArn?: string;
    SourceBackupVaultArn?: string;
    ResourceArn?: string;
    ResourceType?: string;
    CreatedBy?: RecoveryPointCreator;
    IamRoleArn?: string;
    Status?: RecoveryPointStatus;
    StatusMessage?: string;
    CreationDate?: Date;
    InitiationDate?: Date;
    CompletionDate?: Date;
    BackupSizeInBytes?: number;
    CalculatedLifecycle?: CalculatedLifecycle;
    Lifecycle?: Lifecycle;
    EncryptionKeyArn?: string;
    IsEncrypted?: boolean;
    LastRestoreTime?: Date;
    ParentRecoveryPointArn?: string;
    CompositeMemberIdentifier?: string;
    IsParent?: boolean;
    ResourceName?: string;
    VaultType?: VaultType;
    IndexStatus?: IndexStatus;
    IndexStatusMessage?: string;
    EncryptionKeyType?: EncryptionKeyType;
    AggregatedScanResult?: AggregatedScanResult;
}
export declare const RecoveryPointByBackupVault: S.Schema<RecoveryPointByBackupVault>;
export type RecoveryPointByBackupVaultList = RecoveryPointByBackupVault[];
export declare const RecoveryPointByBackupVaultList: any;
export interface ListRecoveryPointsByBackupVaultOutput {
    NextToken?: string;
    RecoveryPoints?: RecoveryPointByBackupVault[];
}
export declare const ListRecoveryPointsByBackupVaultOutput: S.Schema<ListRecoveryPointsByBackupVaultOutput>;
export interface ListRecoveryPointsByLegalHoldInput {
    LegalHoldId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListRecoveryPointsByLegalHoldInput: S.Schema<ListRecoveryPointsByLegalHoldInput>;
export interface RecoveryPointMember {
    RecoveryPointArn?: string;
    ResourceArn?: string;
    ResourceType?: string;
    BackupVaultName?: string;
}
export declare const RecoveryPointMember: S.Schema<RecoveryPointMember>;
export type RecoveryPointsList = RecoveryPointMember[];
export declare const RecoveryPointsList: any;
export interface ListRecoveryPointsByLegalHoldOutput {
    RecoveryPoints?: RecoveryPointMember[];
    NextToken?: string;
}
export declare const ListRecoveryPointsByLegalHoldOutput: S.Schema<ListRecoveryPointsByLegalHoldOutput>;
export interface ListRecoveryPointsByResourceInput {
    ResourceArn: string;
    NextToken?: string;
    MaxResults?: number;
    ManagedByAWSBackupOnly?: boolean;
}
export declare const ListRecoveryPointsByResourceInput: S.Schema<ListRecoveryPointsByResourceInput>;
export interface RecoveryPointByResource {
    RecoveryPointArn?: string;
    CreationDate?: Date;
    Status?: RecoveryPointStatus;
    StatusMessage?: string;
    EncryptionKeyArn?: string;
    BackupSizeBytes?: number;
    BackupVaultName?: string;
    IsParent?: boolean;
    ParentRecoveryPointArn?: string;
    ResourceName?: string;
    VaultType?: VaultType;
    IndexStatus?: IndexStatus;
    IndexStatusMessage?: string;
    EncryptionKeyType?: EncryptionKeyType;
    AggregatedScanResult?: AggregatedScanResult;
}
export declare const RecoveryPointByResource: S.Schema<RecoveryPointByResource>;
export type RecoveryPointByResourceList = RecoveryPointByResource[];
export declare const RecoveryPointByResourceList: any;
export interface ListRecoveryPointsByResourceOutput {
    NextToken?: string;
    RecoveryPoints?: RecoveryPointByResource[];
}
export declare const ListRecoveryPointsByResourceOutput: S.Schema<ListRecoveryPointsByResourceOutput>;
export interface ListReportJobsInput {
    ByReportPlanName?: string;
    ByCreationBefore?: Date;
    ByCreationAfter?: Date;
    ByStatus?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListReportJobsInput: S.Schema<ListReportJobsInput>;
export type ReportJobList = ReportJob[];
export declare const ReportJobList: any;
export interface ListReportJobsOutput {
    ReportJobs?: ReportJob[];
    NextToken?: string;
}
export declare const ListReportJobsOutput: S.Schema<ListReportJobsOutput>;
export interface ListReportPlansInput {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListReportPlansInput: S.Schema<ListReportPlansInput>;
export type ReportPlanList = ReportPlan[];
export declare const ReportPlanList: any;
export interface ListReportPlansOutput {
    ReportPlans?: ReportPlan[];
    NextToken?: string;
}
export declare const ListReportPlansOutput: S.Schema<ListReportPlansOutput>;
export interface ListRestoreAccessBackupVaultsInput {
    BackupVaultName: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListRestoreAccessBackupVaultsInput: S.Schema<ListRestoreAccessBackupVaultsInput>;
export type MpaRevokeSessionStatus = "PENDING" | "FAILED" | (string & {});
export declare const MpaRevokeSessionStatus: any;
export interface LatestRevokeRequest {
    MpaSessionArn?: string;
    Status?: MpaRevokeSessionStatus;
    StatusMessage?: string;
    InitiationDate?: Date;
    ExpiryDate?: Date;
}
export declare const LatestRevokeRequest: S.Schema<LatestRevokeRequest>;
export interface RestoreAccessBackupVaultListMember {
    RestoreAccessBackupVaultArn?: string;
    CreationDate?: Date;
    ApprovalDate?: Date;
    VaultState?: VaultState;
    LatestRevokeRequest?: LatestRevokeRequest;
}
export declare const RestoreAccessBackupVaultListMember: S.Schema<RestoreAccessBackupVaultListMember>;
export type RestoreAccessBackupVaultList = RestoreAccessBackupVaultListMember[];
export declare const RestoreAccessBackupVaultList: any;
export interface ListRestoreAccessBackupVaultsOutput {
    NextToken?: string;
    RestoreAccessBackupVaults?: RestoreAccessBackupVaultListMember[];
}
export declare const ListRestoreAccessBackupVaultsOutput: S.Schema<ListRestoreAccessBackupVaultsOutput>;
export interface ListRestoreJobsInput {
    NextToken?: string;
    MaxResults?: number;
    ByAccountId?: string;
    ByResourceType?: string;
    ByCreatedBefore?: Date;
    ByCreatedAfter?: Date;
    ByStatus?: RestoreJobStatus;
    ByCompleteBefore?: Date;
    ByCompleteAfter?: Date;
    ByRestoreTestingPlanArn?: string;
    ByParentJobId?: string;
}
export declare const ListRestoreJobsInput: S.Schema<ListRestoreJobsInput>;
export interface RestoreJobsListMember {
    AccountId?: string;
    RestoreJobId?: string;
    RecoveryPointArn?: string;
    SourceResourceArn?: string;
    BackupVaultArn?: string;
    CreationDate?: Date;
    CompletionDate?: Date;
    Status?: RestoreJobStatus;
    StatusMessage?: string;
    PercentDone?: string;
    BackupSizeInBytes?: number;
    IamRoleArn?: string;
    ExpectedCompletionTimeMinutes?: number;
    CreatedResourceArn?: string;
    ResourceType?: string;
    RecoveryPointCreationDate?: Date;
    IsParent?: boolean;
    ParentJobId?: string;
    CreatedBy?: RestoreJobCreator;
    ValidationStatus?: RestoreValidationStatus;
    ValidationStatusMessage?: string;
    DeletionStatus?: RestoreDeletionStatus;
    DeletionStatusMessage?: string;
}
export declare const RestoreJobsListMember: S.Schema<RestoreJobsListMember>;
export type RestoreJobsList = RestoreJobsListMember[];
export declare const RestoreJobsList: any;
export interface ListRestoreJobsOutput {
    RestoreJobs?: RestoreJobsListMember[];
    NextToken?: string;
}
export declare const ListRestoreJobsOutput: S.Schema<ListRestoreJobsOutput>;
export interface ListRestoreJobsByProtectedResourceInput {
    ResourceArn: string;
    ByStatus?: RestoreJobStatus;
    ByRecoveryPointCreationDateAfter?: Date;
    ByRecoveryPointCreationDateBefore?: Date;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListRestoreJobsByProtectedResourceInput: S.Schema<ListRestoreJobsByProtectedResourceInput>;
export interface ListRestoreJobsByProtectedResourceOutput {
    RestoreJobs?: RestoreJobsListMember[];
    NextToken?: string;
}
export declare const ListRestoreJobsByProtectedResourceOutput: S.Schema<ListRestoreJobsByProtectedResourceOutput>;
export type RestoreJobState = "CREATED" | "PENDING" | "RUNNING" | "ABORTED" | "COMPLETED" | "FAILED" | "AGGREGATE_ALL" | "ANY" | (string & {});
export declare const RestoreJobState: any;
export interface ListRestoreJobSummariesInput {
    AccountId?: string;
    State?: RestoreJobState;
    ResourceType?: string;
    AggregationPeriod?: AggregationPeriod;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListRestoreJobSummariesInput: S.Schema<ListRestoreJobSummariesInput>;
export interface RestoreJobSummary {
    Region?: string;
    AccountId?: string;
    State?: RestoreJobState;
    ResourceType?: string;
    Count?: number;
    StartTime?: Date;
    EndTime?: Date;
}
export declare const RestoreJobSummary: S.Schema<RestoreJobSummary>;
export type RestoreJobSummaryList = RestoreJobSummary[];
export declare const RestoreJobSummaryList: any;
export interface ListRestoreJobSummariesOutput {
    RestoreJobSummaries?: RestoreJobSummary[];
    AggregationPeriod?: string;
    NextToken?: string;
}
export declare const ListRestoreJobSummariesOutput: S.Schema<ListRestoreJobSummariesOutput>;
export type ListRestoreTestingPlansInputMaxResultsInteger = number;
export interface ListRestoreTestingPlansInput {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListRestoreTestingPlansInput: S.Schema<ListRestoreTestingPlansInput>;
export interface RestoreTestingPlanForList {
    CreationTime: Date;
    LastExecutionTime?: Date;
    LastUpdateTime?: Date;
    RestoreTestingPlanArn: string;
    RestoreTestingPlanName: string;
    ScheduleExpression: string;
    ScheduleExpressionTimezone?: string;
    StartWindowHours?: number;
}
export declare const RestoreTestingPlanForList: S.Schema<RestoreTestingPlanForList>;
export type RestoreTestingPlans = RestoreTestingPlanForList[];
export declare const RestoreTestingPlans: any;
export interface ListRestoreTestingPlansOutput {
    NextToken?: string;
    RestoreTestingPlans: RestoreTestingPlanForList[];
}
export declare const ListRestoreTestingPlansOutput: S.Schema<ListRestoreTestingPlansOutput>;
export type ListRestoreTestingSelectionsInputMaxResultsInteger = number;
export interface ListRestoreTestingSelectionsInput {
    MaxResults?: number;
    NextToken?: string;
    RestoreTestingPlanName: string;
}
export declare const ListRestoreTestingSelectionsInput: S.Schema<ListRestoreTestingSelectionsInput>;
export interface RestoreTestingSelectionForList {
    CreationTime: Date;
    IamRoleArn: string;
    ProtectedResourceType: string;
    RestoreTestingPlanName: string;
    RestoreTestingSelectionName: string;
    ValidationWindowHours?: number;
}
export declare const RestoreTestingSelectionForList: S.Schema<RestoreTestingSelectionForList>;
export type RestoreTestingSelections = RestoreTestingSelectionForList[];
export declare const RestoreTestingSelections: any;
export interface ListRestoreTestingSelectionsOutput {
    NextToken?: string;
    RestoreTestingSelections: RestoreTestingSelectionForList[];
}
export declare const ListRestoreTestingSelectionsOutput: S.Schema<ListRestoreTestingSelectionsOutput>;
export type ListScanJobsInputMaxResultsInteger = number;
export interface ListScanJobsInput {
    ByAccountId?: string;
    ByBackupVaultName?: string;
    ByCompleteAfter?: Date;
    ByCompleteBefore?: Date;
    ByMalwareScanner?: MalwareScanner;
    ByRecoveryPointArn?: string;
    ByResourceArn?: string;
    ByResourceType?: ScanResourceType;
    ByScanResultStatus?: ScanResultStatus;
    ByState?: ScanState;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListScanJobsInput: S.Schema<ListScanJobsInput>;
export interface ScanJob {
    AccountId: string;
    BackupVaultArn: string;
    BackupVaultName: string;
    CompletionDate?: Date;
    ContinuousScanEndTime?: Date;
    ContinuousScanStartTime?: Date;
    CreatedBy: ScanJobCreator;
    CreationDate: Date;
    IamRoleArn: string;
    MalwareScanner: MalwareScanner;
    RecoveryPointArn: string;
    ResourceArn: string;
    ResourceName: string;
    ResourceType: ScanResourceType;
    ScanBaseRecoveryPointArn?: string;
    ScanId?: string;
    ScanJobId: string;
    ScanMode: ScanMode;
    ScanResult?: ScanResultInfo;
    ScannerRoleArn: string;
    State?: ScanState;
    StatusMessage?: string;
}
export declare const ScanJob: S.Schema<ScanJob>;
export type ScanJobs = ScanJob[];
export declare const ScanJobs: any;
export interface ListScanJobsOutput {
    NextToken?: string;
    ScanJobs: ScanJob[];
}
export declare const ListScanJobsOutput: S.Schema<ListScanJobsOutput>;
export type ScanJobStatus = "CREATED" | "COMPLETED" | "COMPLETED_WITH_ISSUES" | "RUNNING" | "FAILED" | "CANCELED" | "AGGREGATE_ALL" | "ANY" | (string & {});
export declare const ScanJobStatus: any;
export interface ListScanJobSummariesInput {
    AccountId?: string;
    ResourceType?: string;
    MalwareScanner?: MalwareScanner;
    ScanResultStatus?: ScanResultStatus;
    State?: ScanJobStatus;
    AggregationPeriod?: AggregationPeriod;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListScanJobSummariesInput: S.Schema<ListScanJobSummariesInput>;
export interface ScanJobSummary {
    Region?: string;
    AccountId?: string;
    State?: ScanJobStatus;
    ResourceType?: string;
    Count?: number;
    StartTime?: Date;
    EndTime?: Date;
    MalwareScanner?: MalwareScanner;
    ScanResultStatus?: ScanResultStatus;
}
export declare const ScanJobSummary: S.Schema<ScanJobSummary>;
export type ScanJobSummaryList = ScanJobSummary[];
export declare const ScanJobSummaryList: any;
export interface ListScanJobSummariesOutput {
    ScanJobSummaries?: ScanJobSummary[];
    AggregationPeriod?: string;
    NextToken?: string;
}
export declare const ListScanJobSummariesOutput: S.Schema<ListScanJobSummariesOutput>;
export interface ListTagsInput {
    ResourceArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListTagsInput: S.Schema<ListTagsInput>;
export interface ListTagsOutput {
    NextToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsOutput: S.Schema<ListTagsOutput>;
export interface ListTieringConfigurationsInput {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListTieringConfigurationsInput: S.Schema<ListTieringConfigurationsInput>;
export interface TieringConfigurationsListMember {
    TieringConfigurationArn?: string;
    TieringConfigurationName?: string;
    BackupVaultName?: string;
    CreationTime?: Date;
    LastUpdatedTime?: Date;
}
export declare const TieringConfigurationsListMember: S.Schema<TieringConfigurationsListMember>;
export type TieringConfigurationsList = TieringConfigurationsListMember[];
export declare const TieringConfigurationsList: any;
export interface ListTieringConfigurationsOutput {
    TieringConfigurations?: TieringConfigurationsListMember[];
    NextToken?: string;
}
export declare const ListTieringConfigurationsOutput: S.Schema<ListTieringConfigurationsOutput>;
export interface PutBackupVaultAccessPolicyInput {
    BackupVaultName: string;
    Policy?: string;
}
export declare const PutBackupVaultAccessPolicyInput: S.Schema<PutBackupVaultAccessPolicyInput>;
export interface PutBackupVaultAccessPolicyResponse {
}
export declare const PutBackupVaultAccessPolicyResponse: S.Schema<PutBackupVaultAccessPolicyResponse>;
export interface PutBackupVaultLockConfigurationInput {
    BackupVaultName: string;
    MinRetentionDays?: number;
    MaxRetentionDays?: number;
    ChangeableForDays?: number;
}
export declare const PutBackupVaultLockConfigurationInput: S.Schema<PutBackupVaultLockConfigurationInput>;
export interface PutBackupVaultLockConfigurationResponse {
}
export declare const PutBackupVaultLockConfigurationResponse: S.Schema<PutBackupVaultLockConfigurationResponse>;
export interface PutBackupVaultNotificationsInput {
    BackupVaultName: string;
    SNSTopicArn: string;
    BackupVaultEvents: BackupVaultEvent[];
}
export declare const PutBackupVaultNotificationsInput: S.Schema<PutBackupVaultNotificationsInput>;
export interface PutBackupVaultNotificationsResponse {
}
export declare const PutBackupVaultNotificationsResponse: S.Schema<PutBackupVaultNotificationsResponse>;
export interface PutRestoreValidationResultInput {
    RestoreJobId: string;
    ValidationStatus: RestoreValidationStatus;
    ValidationStatusMessage?: string;
}
export declare const PutRestoreValidationResultInput: S.Schema<PutRestoreValidationResultInput>;
export interface PutRestoreValidationResultResponse {
}
export declare const PutRestoreValidationResultResponse: S.Schema<PutRestoreValidationResultResponse>;
export interface RevokeRestoreAccessBackupVaultInput {
    BackupVaultName: string;
    RestoreAccessBackupVaultArn: string;
    RequesterComment?: string | redacted.Redacted<string>;
}
export declare const RevokeRestoreAccessBackupVaultInput: S.Schema<RevokeRestoreAccessBackupVaultInput>;
export interface RevokeRestoreAccessBackupVaultResponse {
}
export declare const RevokeRestoreAccessBackupVaultResponse: S.Schema<RevokeRestoreAccessBackupVaultResponse>;
export type Index = "ENABLED" | "DISABLED" | (string & {});
export declare const Index: any;
export interface StartBackupJobInput {
    BackupVaultName: string;
    LogicallyAirGappedBackupVaultArn?: string;
    ResourceArn: string;
    IamRoleArn: string;
    IdempotencyToken?: string;
    StartWindowMinutes?: number;
    CompleteWindowMinutes?: number;
    Lifecycle?: Lifecycle;
    RecoveryPointTags?: {
        [key: string]: string | undefined;
    };
    BackupOptions?: {
        [key: string]: string | undefined;
    };
    Index?: Index;
}
export declare const StartBackupJobInput: S.Schema<StartBackupJobInput>;
export interface StartBackupJobOutput {
    BackupJobId?: string;
    RecoveryPointArn?: string;
    CreationDate?: Date;
    IsParent?: boolean;
}
export declare const StartBackupJobOutput: S.Schema<StartBackupJobOutput>;
export interface StartCopyJobInput {
    RecoveryPointArn: string;
    SourceBackupVaultName: string;
    DestinationBackupVaultArn: string;
    IamRoleArn: string;
    IdempotencyToken?: string;
    Lifecycle?: Lifecycle;
}
export declare const StartCopyJobInput: S.Schema<StartCopyJobInput>;
export interface StartCopyJobOutput {
    CopyJobId?: string;
    CreationDate?: Date;
    IsParent?: boolean;
}
export declare const StartCopyJobOutput: S.Schema<StartCopyJobOutput>;
export interface StartReportJobInput {
    ReportPlanName: string;
    IdempotencyToken?: string;
}
export declare const StartReportJobInput: S.Schema<StartReportJobInput>;
export interface StartReportJobOutput {
    ReportJobId?: string;
}
export declare const StartReportJobOutput: S.Schema<StartReportJobOutput>;
export interface StartRestoreJobInput {
    RecoveryPointArn: string;
    Metadata: {
        [key: string]: string | undefined;
    };
    IamRoleArn?: string;
    IdempotencyToken?: string;
    ResourceType?: string;
    CopySourceTagsToRestoredResource?: boolean;
}
export declare const StartRestoreJobInput: S.Schema<StartRestoreJobInput>;
export interface StartRestoreJobOutput {
    RestoreJobId?: string;
}
export declare const StartRestoreJobOutput: S.Schema<StartRestoreJobOutput>;
export interface StartScanJobInput {
    BackupVaultName: string;
    ContinuousScanEndTime?: Date;
    IamRoleArn: string;
    IdempotencyToken?: string;
    MalwareScanner: MalwareScanner;
    RecoveryPointArn: string;
    ScanBaseRecoveryPointArn?: string;
    ScanMode: ScanMode;
    ScannerRoleArn: string;
}
export declare const StartScanJobInput: S.Schema<StartScanJobInput>;
export interface StartScanJobOutput {
    CreationDate: Date;
    ScanJobId: string;
}
export declare const StartScanJobOutput: S.Schema<StartScanJobOutput>;
export interface StopBackupJobInput {
    BackupJobId: string;
}
export declare const StopBackupJobInput: S.Schema<StopBackupJobInput>;
export interface StopBackupJobResponse {
}
export declare const StopBackupJobResponse: S.Schema<StopBackupJobResponse>;
export interface TagResourceInput {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceInput: S.Schema<TagResourceInput>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceInput {
    ResourceArn: string;
    TagKeyList: string[];
}
export declare const UntagResourceInput: S.Schema<UntagResourceInput>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateBackupPlanInput {
    BackupPlanId: string;
    BackupPlan: BackupPlanInput;
}
export declare const UpdateBackupPlanInput: S.Schema<UpdateBackupPlanInput>;
export interface UpdateBackupPlanOutput {
    BackupPlanId?: string;
    BackupPlanArn?: string;
    CreationDate?: Date;
    VersionId?: string;
    AdvancedBackupSettings?: AdvancedBackupSetting[];
    ScanSettings?: ScanSetting[];
}
export declare const UpdateBackupPlanOutput: S.Schema<UpdateBackupPlanOutput>;
export interface UpdateFrameworkInput {
    FrameworkName: string;
    FrameworkDescription?: string;
    FrameworkControls?: FrameworkControl[];
    IdempotencyToken?: string;
}
export declare const UpdateFrameworkInput: S.Schema<UpdateFrameworkInput>;
export interface UpdateFrameworkOutput {
    FrameworkName?: string;
    FrameworkArn?: string;
    CreationTime?: Date;
}
export declare const UpdateFrameworkOutput: S.Schema<UpdateFrameworkOutput>;
export interface UpdateGlobalSettingsInput {
    GlobalSettings?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateGlobalSettingsInput: S.Schema<UpdateGlobalSettingsInput>;
export interface UpdateGlobalSettingsResponse {
}
export declare const UpdateGlobalSettingsResponse: S.Schema<UpdateGlobalSettingsResponse>;
export interface UpdateRecoveryPointIndexSettingsInput {
    BackupVaultName: string;
    RecoveryPointArn: string;
    IamRoleArn?: string;
    Index: Index;
}
export declare const UpdateRecoveryPointIndexSettingsInput: S.Schema<UpdateRecoveryPointIndexSettingsInput>;
export interface UpdateRecoveryPointIndexSettingsOutput {
    BackupVaultName?: string;
    RecoveryPointArn?: string;
    IndexStatus?: IndexStatus;
    Index?: Index;
}
export declare const UpdateRecoveryPointIndexSettingsOutput: S.Schema<UpdateRecoveryPointIndexSettingsOutput>;
export interface UpdateRecoveryPointLifecycleInput {
    BackupVaultName: string;
    RecoveryPointArn: string;
    Lifecycle?: Lifecycle;
}
export declare const UpdateRecoveryPointLifecycleInput: S.Schema<UpdateRecoveryPointLifecycleInput>;
export interface UpdateRecoveryPointLifecycleOutput {
    BackupVaultArn?: string;
    RecoveryPointArn?: string;
    Lifecycle?: Lifecycle;
    CalculatedLifecycle?: CalculatedLifecycle;
}
export declare const UpdateRecoveryPointLifecycleOutput: S.Schema<UpdateRecoveryPointLifecycleOutput>;
export interface UpdateRegionSettingsInput {
    ResourceTypeOptInPreference?: {
        [key: string]: boolean | undefined;
    };
    ResourceTypeManagementPreference?: {
        [key: string]: boolean | undefined;
    };
}
export declare const UpdateRegionSettingsInput: S.Schema<UpdateRegionSettingsInput>;
export interface UpdateRegionSettingsResponse {
}
export declare const UpdateRegionSettingsResponse: S.Schema<UpdateRegionSettingsResponse>;
export interface UpdateReportPlanInput {
    ReportPlanName: string;
    ReportPlanDescription?: string;
    ReportDeliveryChannel?: ReportDeliveryChannel;
    ReportSetting?: ReportSetting;
    IdempotencyToken?: string;
}
export declare const UpdateReportPlanInput: S.Schema<UpdateReportPlanInput>;
export interface UpdateReportPlanOutput {
    ReportPlanName?: string;
    ReportPlanArn?: string;
    CreationTime?: Date;
}
export declare const UpdateReportPlanOutput: S.Schema<UpdateReportPlanOutput>;
export interface RestoreTestingPlanForUpdate {
    RecoveryPointSelection?: RestoreTestingRecoveryPointSelection;
    ScheduleExpression?: string;
    ScheduleExpressionTimezone?: string;
    StartWindowHours?: number;
}
export declare const RestoreTestingPlanForUpdate: S.Schema<RestoreTestingPlanForUpdate>;
export interface UpdateRestoreTestingPlanInput {
    RestoreTestingPlan: RestoreTestingPlanForUpdate;
    RestoreTestingPlanName: string;
}
export declare const UpdateRestoreTestingPlanInput: S.Schema<UpdateRestoreTestingPlanInput>;
export interface UpdateRestoreTestingPlanOutput {
    CreationTime: Date;
    RestoreTestingPlanArn: string;
    RestoreTestingPlanName: string;
    UpdateTime: Date;
}
export declare const UpdateRestoreTestingPlanOutput: S.Schema<UpdateRestoreTestingPlanOutput>;
export interface RestoreTestingSelectionForUpdate {
    IamRoleArn?: string;
    ProtectedResourceArns?: string[];
    ProtectedResourceConditions?: ProtectedResourceConditions;
    RestoreMetadataOverrides?: {
        [key: string]: string | undefined;
    };
    ValidationWindowHours?: number;
}
export declare const RestoreTestingSelectionForUpdate: S.Schema<RestoreTestingSelectionForUpdate>;
export interface UpdateRestoreTestingSelectionInput {
    RestoreTestingPlanName: string;
    RestoreTestingSelection: RestoreTestingSelectionForUpdate;
    RestoreTestingSelectionName: string;
}
export declare const UpdateRestoreTestingSelectionInput: S.Schema<UpdateRestoreTestingSelectionInput>;
export interface UpdateRestoreTestingSelectionOutput {
    CreationTime: Date;
    RestoreTestingPlanArn: string;
    RestoreTestingPlanName: string;
    RestoreTestingSelectionName: string;
    UpdateTime: Date;
}
export declare const UpdateRestoreTestingSelectionOutput: S.Schema<UpdateRestoreTestingSelectionOutput>;
export interface TieringConfigurationInputForUpdate {
    ResourceSelection: ResourceSelection[];
    BackupVaultName: string;
}
export declare const TieringConfigurationInputForUpdate: S.Schema<TieringConfigurationInputForUpdate>;
export interface UpdateTieringConfigurationInput {
    TieringConfigurationName: string;
    TieringConfiguration: TieringConfigurationInputForUpdate;
}
export declare const UpdateTieringConfigurationInput: S.Schema<UpdateTieringConfigurationInput>;
export interface UpdateTieringConfigurationOutput {
    TieringConfigurationArn?: string;
    TieringConfigurationName?: string;
    CreationTime?: Date;
    LastUpdatedTime?: Date;
}
export declare const UpdateTieringConfigurationOutput: S.Schema<UpdateTieringConfigurationOutput>;
export type AssociateBackupVaultMpaApprovalTeamError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Associates an MPA approval team with a backup vault.
 */
export declare const associateBackupVaultMpaApprovalTeam: API.OperationMethod<AssociateBackupVaultMpaApprovalTeamInput, AssociateBackupVaultMpaApprovalTeamResponse, AssociateBackupVaultMpaApprovalTeamError, Credentials | HttpClient.HttpClient>;
export type CancelLegalHoldError = InvalidParameterValueException | InvalidResourceStateException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Removes the specified legal hold on a recovery point. This action can only be performed
 * by a user with sufficient permissions.
 */
export declare const cancelLegalHold: API.OperationMethod<CancelLegalHoldInput, CancelLegalHoldOutput, CancelLegalHoldError, Credentials | HttpClient.HttpClient>;
export type CreateBackupAccessPointError = AlreadyExistsException | ConflictException | InvalidParameterValueException | InvalidRequestException | LimitExceededException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a backup access point for an Amazon S3 recovery point. A backup access point provides
 * on-demand, read-only access to the backup data in a recovery point through an Amazon S3 access point,
 * without initiating a restore.
 *
 * While a backup access point is active for a recovery point, Backup pauses lifecycle transitions
 * and blocks deletion of that recovery point.
 */
export declare const createBackupAccessPoint: API.OperationMethod<CreateBackupAccessPointRequest, CreateBackupAccessPointResponse, CreateBackupAccessPointError, Credentials | HttpClient.HttpClient>;
export type CreateBackupPlanError = AlreadyExistsException | InvalidParameterValueException | LimitExceededException | MissingParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a backup plan using a backup plan name and backup rules. A backup plan is a
 * document that contains information that Backup uses to schedule tasks that
 * create recovery points for resources.
 *
 * If you call `CreateBackupPlan` with a plan that already exists, you receive
 * an `AlreadyExistsException` exception.
 */
export declare const createBackupPlan: API.OperationMethod<CreateBackupPlanInput, CreateBackupPlanOutput, CreateBackupPlanError, Credentials | HttpClient.HttpClient>;
export type CreateBackupSelectionError = AlreadyExistsException | InvalidParameterValueException | LimitExceededException | MissingParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a JSON document that specifies a set of resources to assign to a backup plan.
 * For examples, see Assigning resources programmatically.
 */
export declare const createBackupSelection: API.OperationMethod<CreateBackupSelectionInput, CreateBackupSelectionOutput, CreateBackupSelectionError, Credentials | HttpClient.HttpClient>;
export type CreateBackupVaultError = AlreadyExistsException | InvalidParameterValueException | LimitExceededException | MissingParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a logical container where backups are stored. A `CreateBackupVault`
 * request includes a name, optionally one or more resource tags, an encryption key, and a
 * request ID.
 *
 * Do not include sensitive data, such as passport numbers, in the name of a backup
 * vault.
 */
export declare const createBackupVault: API.OperationMethod<CreateBackupVaultInput, CreateBackupVaultOutput, CreateBackupVaultError, Credentials | HttpClient.HttpClient>;
export type CreateFrameworkError = AlreadyExistsException | InvalidParameterValueException | LimitExceededException | MissingParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a framework with one or more controls. A framework is a collection of controls
 * that you can use to evaluate your backup practices. By using pre-built customizable
 * controls to define your policies, you can evaluate whether your backup practices comply
 * with your policies and which resources are not yet in compliance.
 */
export declare const createFramework: API.OperationMethod<CreateFrameworkInput, CreateFrameworkOutput, CreateFrameworkError, Credentials | HttpClient.HttpClient>;
export type CreateLegalHoldError = InvalidParameterValueException | LimitExceededException | MissingParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a legal hold on a recovery point (backup). A legal hold is a restraint on
 * altering or deleting a backup until an authorized user cancels the legal hold. Any actions
 * to delete or disassociate a recovery point will fail with an error if one or more active
 * legal holds are on the recovery point.
 */
export declare const createLegalHold: API.OperationMethod<CreateLegalHoldInput, CreateLegalHoldOutput, CreateLegalHoldError, Credentials | HttpClient.HttpClient>;
export type CreateLogicallyAirGappedBackupVaultError = AlreadyExistsException | InvalidParameterValueException | InvalidRequestException | LimitExceededException | MissingParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a logical container to where backups may be copied.
 *
 * This request includes a name, the Region, the maximum number of retention days, the
 * minimum number of retention days, and optionally can include tags and a creator request
 * ID.
 *
 * Do not include sensitive data, such as passport numbers, in the name of a backup
 * vault.
 */
export declare const createLogicallyAirGappedBackupVault: API.OperationMethod<CreateLogicallyAirGappedBackupVaultInput, CreateLogicallyAirGappedBackupVaultOutput, CreateLogicallyAirGappedBackupVaultError, Credentials | HttpClient.HttpClient>;
export type CreateReportPlanError = AlreadyExistsException | InvalidParameterValueException | LimitExceededException | MissingParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a report plan. A report plan is a document that contains information about the
 * contents of the report and where Backup will deliver it.
 *
 * If you call `CreateReportPlan` with a plan that already exists, you receive
 * an `AlreadyExistsException` exception.
 */
export declare const createReportPlan: API.OperationMethod<CreateReportPlanInput, CreateReportPlanOutput, CreateReportPlanError, Credentials | HttpClient.HttpClient>;
export type CreateRestoreAccessBackupVaultError = AlreadyExistsException | InvalidParameterValueException | InvalidRequestException | LimitExceededException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a restore access backup vault that provides temporary access to recovery points in a logically air-gapped backup vault, subject to MPA approval.
 */
export declare const createRestoreAccessBackupVault: API.OperationMethod<CreateRestoreAccessBackupVaultInput, CreateRestoreAccessBackupVaultOutput, CreateRestoreAccessBackupVaultError, Credentials | HttpClient.HttpClient>;
export type CreateRestoreTestingPlanError = AlreadyExistsException | ConflictException | InvalidParameterValueException | LimitExceededException | MissingParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a restore testing plan.
 *
 * The first of two steps to create a restore testing
 * plan. After this request is successful, finish the procedure using
 * CreateRestoreTestingSelection.
 */
export declare const createRestoreTestingPlan: API.OperationMethod<CreateRestoreTestingPlanInput, CreateRestoreTestingPlanOutput, CreateRestoreTestingPlanError, Credentials | HttpClient.HttpClient>;
export type CreateRestoreTestingSelectionError = AlreadyExistsException | InvalidParameterValueException | LimitExceededException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * This request can be sent after CreateRestoreTestingPlan request
 * returns successfully. This is the second part of creating a resource testing
 * plan, and it must be completed sequentially.
 *
 * This consists of `RestoreTestingSelectionName`,
 * `ProtectedResourceType`, and one of the following:
 *
 * - `ProtectedResourceArns`
 *
 * - `ProtectedResourceConditions`
 *
 * Each protected resource type can have one single value.
 *
 * A restore testing selection can include a wildcard value ("*") for
 * `ProtectedResourceArns` along with `ProtectedResourceConditions`.
 * Alternatively, you can include up to 30 specific protected resource ARNs in
 * `ProtectedResourceArns`.
 *
 * Cannot select by both protected resource types AND specific ARNs.
 * Request will fail if both are included.
 */
export declare const createRestoreTestingSelection: API.OperationMethod<CreateRestoreTestingSelectionInput, CreateRestoreTestingSelectionOutput, CreateRestoreTestingSelectionError, Credentials | HttpClient.HttpClient>;
export type CreateTieringConfigurationError = AlreadyExistsException | ConflictException | InvalidParameterValueException | LimitExceededException | MissingParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a tiering configuration.
 *
 * A tiering configuration enables automatic movement of backup data to a lower-cost storage tier based on the age of backed-up objects in the backup vault.
 *
 * Each vault can only have one vault-specific tiering configuration, in addition to any global configuration that applies to all vaults.
 */
export declare const createTieringConfiguration: API.OperationMethod<CreateTieringConfigurationInput, CreateTieringConfigurationOutput, CreateTieringConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteBackupAccessPointError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a backup access point. This deletes the underlying Amazon S3 access point and, if no other
 * backup access points remain for the recovery point, resumes lifecycle transitions for that recovery point.
 *
 * Always delete backup access points using this operation rather than deleting the underlying Amazon S3
 * access point directly.
 */
export declare const deleteBackupAccessPoint: API.OperationMethod<DeleteBackupAccessPointInput, DeleteBackupAccessPointResponse, DeleteBackupAccessPointError, Credentials | HttpClient.HttpClient>;
export type DeleteBackupPlanError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a backup plan. A backup plan can only be deleted after all associated selections
 * of resources have been deleted. Deleting a backup plan deletes the current version of a
 * backup plan. Previous versions, if any, will still exist.
 */
export declare const deleteBackupPlan: API.OperationMethod<DeleteBackupPlanInput, DeleteBackupPlanOutput, DeleteBackupPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteBackupSelectionError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the resource selection associated with a backup plan that is specified by the
 * `SelectionId`.
 */
export declare const deleteBackupSelection: API.OperationMethod<DeleteBackupSelectionInput, DeleteBackupSelectionResponse, DeleteBackupSelectionError, Credentials | HttpClient.HttpClient>;
export type DeleteBackupVaultError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the backup vault identified by its name. A vault can be deleted only if it is
 * empty.
 */
export declare const deleteBackupVault: API.OperationMethod<DeleteBackupVaultInput, DeleteBackupVaultResponse, DeleteBackupVaultError, Credentials | HttpClient.HttpClient>;
export type DeleteBackupVaultAccessPolicyError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the policy document that manages permissions on a backup vault.
 */
export declare const deleteBackupVaultAccessPolicy: API.OperationMethod<DeleteBackupVaultAccessPolicyInput, DeleteBackupVaultAccessPolicyResponse, DeleteBackupVaultAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteBackupVaultLockConfigurationError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes Backup Vault Lock from a backup vault specified by a backup vault
 * name.
 *
 * If the Vault Lock configuration is immutable, then you cannot delete Vault Lock using
 * API operations, and you will receive an `InvalidRequestException` if you attempt
 * to do so. For more information, see Vault Lock in the
 * *Backup Developer Guide*.
 */
export declare const deleteBackupVaultLockConfiguration: API.OperationMethod<DeleteBackupVaultLockConfigurationInput, DeleteBackupVaultLockConfigurationResponse, DeleteBackupVaultLockConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteBackupVaultNotificationsError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes event notifications for the specified backup vault.
 */
export declare const deleteBackupVaultNotifications: API.OperationMethod<DeleteBackupVaultNotificationsInput, DeleteBackupVaultNotificationsResponse, DeleteBackupVaultNotificationsError, Credentials | HttpClient.HttpClient>;
export type DeleteFrameworkError = ConflictException | InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the framework specified by a framework name.
 */
export declare const deleteFramework: API.OperationMethod<DeleteFrameworkInput, DeleteFrameworkResponse, DeleteFrameworkError, Credentials | HttpClient.HttpClient>;
export type DeleteRecoveryPointError = InvalidParameterValueException | InvalidRequestException | InvalidResourceStateException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the recovery point specified by a recovery point ID.
 *
 * If the recovery point ID belongs to a continuous backup, calling this endpoint deletes
 * the existing continuous backup and stops future continuous backup.
 *
 * When an IAM role's permissions are insufficient to call this API, the service sends back
 * an HTTP 200 response with an empty HTTP body, but the recovery point is not deleted.
 * Instead, it enters an `EXPIRED` state.
 *
 * `EXPIRED` recovery points can be deleted with this API once the IAM role
 * has the `iam:CreateServiceLinkedRole` action. To learn more about adding this role, see
 *
 * Troubleshooting manual deletions.
 *
 * If the user or role is deleted or the permission within the role is removed,
 * the deletion will not be successful and will enter an `EXPIRED` state.
 */
export declare const deleteRecoveryPoint: API.OperationMethod<DeleteRecoveryPointInput, DeleteRecoveryPointResponse, DeleteRecoveryPointError, Credentials | HttpClient.HttpClient>;
export type DeleteReportPlanError = ConflictException | InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the report plan specified by a report plan name.
 */
export declare const deleteReportPlan: API.OperationMethod<DeleteReportPlanInput, DeleteReportPlanResponse, DeleteReportPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteRestoreTestingPlanError = InvalidRequestException | ServiceUnavailableException | CommonErrors;
/**
 * This request deletes the specified restore testing plan.
 *
 * Deletion can only successfully occur if all associated
 * restore testing selections are deleted first.
 */
export declare const deleteRestoreTestingPlan: API.OperationMethod<DeleteRestoreTestingPlanInput, DeleteRestoreTestingPlanResponse, DeleteRestoreTestingPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteRestoreTestingSelectionError = ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Input the Restore Testing Plan name and Restore Testing Selection
 * name.
 *
 * All testing selections associated with a restore testing plan must
 * be deleted before the restore testing plan can be deleted.
 */
export declare const deleteRestoreTestingSelection: API.OperationMethod<DeleteRestoreTestingSelectionInput, DeleteRestoreTestingSelectionResponse, DeleteRestoreTestingSelectionError, Credentials | HttpClient.HttpClient>;
export type DeleteTieringConfigurationError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the tiering configuration specified by a tiering configuration name.
 */
export declare const deleteTieringConfiguration: API.OperationMethod<DeleteTieringConfigurationInput, DeleteTieringConfigurationOutput, DeleteTieringConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeBackupAccessPointError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns metadata about a backup access point, including its status and the details of the underlying
 * Amazon S3 access point.
 *
 * After a backup access point reaches the `AVAILABLE` status, use this operation to retrieve the
 * Amazon S3 access point ARN and alias that you need to read the backup data.
 */
export declare const describeBackupAccessPoint: API.OperationMethod<DescribeBackupAccessPointInput, DescribeBackupAccessPointResponse, DescribeBackupAccessPointError, Credentials | HttpClient.HttpClient>;
export type DescribeBackupJobError = DependencyFailureException | InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns backup job details for the specified `BackupJobId`.
 */
export declare const describeBackupJob: API.OperationMethod<DescribeBackupJobInput, DescribeBackupJobOutput, DescribeBackupJobError, Credentials | HttpClient.HttpClient>;
export type DescribeBackupVaultError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns metadata about a backup vault specified by its name.
 */
export declare const describeBackupVault: API.OperationMethod<DescribeBackupVaultInput, DescribeBackupVaultOutput, DescribeBackupVaultError, Credentials | HttpClient.HttpClient>;
export type DescribeCopyJobError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns metadata associated with creating a copy of a resource.
 */
export declare const describeCopyJob: API.OperationMethod<DescribeCopyJobInput, DescribeCopyJobOutput, DescribeCopyJobError, Credentials | HttpClient.HttpClient>;
export type DescribeFrameworkError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the framework details for the specified `FrameworkName`.
 */
export declare const describeFramework: API.OperationMethod<DescribeFrameworkInput, DescribeFrameworkOutput, DescribeFrameworkError, Credentials | HttpClient.HttpClient>;
export type DescribeGlobalSettingsError = InvalidRequestException | ServiceUnavailableException | CommonErrors;
/**
 * Describes whether the Amazon Web Services account has enabled different cross-account management options, including cross-account backup, multi-party approval, and delegated administrator. Returns an error if the account is not a member of an Organizations organization. Example: `describe-global-settings --region us-west-2`
 */
export declare const describeGlobalSettings: API.OperationMethod<DescribeGlobalSettingsInput, DescribeGlobalSettingsOutput, DescribeGlobalSettingsError, Credentials | HttpClient.HttpClient>;
export type DescribeProtectedResourceError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns information about a saved resource, including the last time it was backed up,
 * its Amazon Resource Name (ARN), and the Amazon Web Services service type of the saved
 * resource.
 */
export declare const describeProtectedResource: API.OperationMethod<DescribeProtectedResourceInput, DescribeProtectedResourceOutput, DescribeProtectedResourceError, Credentials | HttpClient.HttpClient>;
export type DescribeRecoveryPointError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns metadata associated with a recovery point, including ID, status, encryption, and
 * lifecycle.
 */
export declare const describeRecoveryPoint: API.OperationMethod<DescribeRecoveryPointInput, DescribeRecoveryPointOutput, DescribeRecoveryPointError, Credentials | HttpClient.HttpClient>;
export type DescribeRegionSettingsError = ServiceUnavailableException | CommonErrors;
/**
 * Returns the current service opt-in settings for the Region. If service opt-in is enabled
 * for a service, Backup tries to protect that service's resources in this Region,
 * when the resource is included in an on-demand backup or scheduled backup plan. Otherwise,
 * Backup does not try to protect that service's resources in this
 * Region.
 */
export declare const describeRegionSettings: API.OperationMethod<DescribeRegionSettingsInput, DescribeRegionSettingsOutput, DescribeRegionSettingsError, Credentials | HttpClient.HttpClient>;
export type DescribeReportJobError = MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the details associated with creating a report as specified by its
 * `ReportJobId`.
 */
export declare const describeReportJob: API.OperationMethod<DescribeReportJobInput, DescribeReportJobOutput, DescribeReportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeReportPlanError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of all report plans for an Amazon Web Services account and Amazon Web Services Region.
 */
export declare const describeReportPlan: API.OperationMethod<DescribeReportPlanInput, DescribeReportPlanOutput, DescribeReportPlanError, Credentials | HttpClient.HttpClient>;
export type DescribeRestoreJobError = DependencyFailureException | InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns metadata associated with a restore job that is specified by a job ID.
 */
export declare const describeRestoreJob: API.OperationMethod<DescribeRestoreJobInput, DescribeRestoreJobOutput, DescribeRestoreJobError, Credentials | HttpClient.HttpClient>;
export type DescribeScanJobError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns scan job details for the specified ScanJobID.
 */
export declare const describeScanJob: API.OperationMethod<DescribeScanJobInput, DescribeScanJobOutput, DescribeScanJobError, Credentials | HttpClient.HttpClient>;
export type DisassociateBackupVaultMpaApprovalTeamError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Removes the association between an MPA approval team and a backup vault, disabling the MPA approval workflow for restore operations.
 */
export declare const disassociateBackupVaultMpaApprovalTeam: API.OperationMethod<DisassociateBackupVaultMpaApprovalTeamInput, DisassociateBackupVaultMpaApprovalTeamResponse, DisassociateBackupVaultMpaApprovalTeamError, Credentials | HttpClient.HttpClient>;
export type DisassociateRecoveryPointError = InvalidParameterValueException | InvalidRequestException | InvalidResourceStateException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the specified continuous backup recovery point from Backup and
 * releases control of that continuous backup to the source service, such as Amazon RDS. The source service will continue to create and retain continuous backups using the
 * lifecycle that you specified in your original backup plan.
 *
 * Does not support snapshot backup recovery points.
 */
export declare const disassociateRecoveryPoint: API.OperationMethod<DisassociateRecoveryPointInput, DisassociateRecoveryPointResponse, DisassociateRecoveryPointError, Credentials | HttpClient.HttpClient>;
export type DisassociateRecoveryPointFromParentError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * This action to a specific child (nested) recovery point removes the relationship
 * between the specified recovery point and its parent (composite) recovery point.
 */
export declare const disassociateRecoveryPointFromParent: API.OperationMethod<DisassociateRecoveryPointFromParentInput, DisassociateRecoveryPointFromParentResponse, DisassociateRecoveryPointFromParentError, Credentials | HttpClient.HttpClient>;
export type ExportBackupPlanTemplateError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the backup plan that is specified by the plan ID as a backup template.
 */
export declare const exportBackupPlanTemplate: API.OperationMethod<ExportBackupPlanTemplateInput, ExportBackupPlanTemplateOutput, ExportBackupPlanTemplateError, Credentials | HttpClient.HttpClient>;
export type GetBackupPlanError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns `BackupPlan` details for the specified `BackupPlanId`. The
 * details are the body of a backup plan in JSON format, in addition to plan metadata.
 */
export declare const getBackupPlan: API.OperationMethod<GetBackupPlanInput, GetBackupPlanOutput, GetBackupPlanError, Credentials | HttpClient.HttpClient>;
export type GetBackupPlanFromJSONError = InvalidParameterValueException | InvalidRequestException | LimitExceededException | MissingParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a valid JSON document specifying a backup plan or an error.
 */
export declare const getBackupPlanFromJSON: API.OperationMethod<GetBackupPlanFromJSONInput, GetBackupPlanFromJSONOutput, GetBackupPlanFromJSONError, Credentials | HttpClient.HttpClient>;
export type GetBackupPlanFromTemplateError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the template specified by its `templateId` as a backup plan.
 */
export declare const getBackupPlanFromTemplate: API.OperationMethod<GetBackupPlanFromTemplateInput, GetBackupPlanFromTemplateOutput, GetBackupPlanFromTemplateError, Credentials | HttpClient.HttpClient>;
export type GetBackupSelectionError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns selection metadata and a document in JSON format that specifies a list of
 * resources that are associated with a backup plan.
 */
export declare const getBackupSelection: API.OperationMethod<GetBackupSelectionInput, GetBackupSelectionOutput, GetBackupSelectionError, Credentials | HttpClient.HttpClient>;
export type GetBackupVaultAccessPolicyError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the access policy document that is associated with the named backup
 * vault.
 */
export declare const getBackupVaultAccessPolicy: API.OperationMethod<GetBackupVaultAccessPolicyInput, GetBackupVaultAccessPolicyOutput, GetBackupVaultAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type GetBackupVaultNotificationsError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns event notifications for the specified backup vault.
 */
export declare const getBackupVaultNotifications: API.OperationMethod<GetBackupVaultNotificationsInput, GetBackupVaultNotificationsOutput, GetBackupVaultNotificationsError, Credentials | HttpClient.HttpClient>;
export type GetLegalHoldError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * This action returns details for a specified legal hold. The details are the
 * body of a legal hold in JSON format, in addition to metadata.
 */
export declare const getLegalHold: API.OperationMethod<GetLegalHoldInput, GetLegalHoldOutput, GetLegalHoldError, Credentials | HttpClient.HttpClient>;
export type GetPITRMalwareScanResultsError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the malware scan results for a specified point in time within a continuous (point-in-time recovery) backup.
 */
export declare const getPITRMalwareScanResults: API.OperationMethod<GetPITRMalwareScanResultsInput, GetPITRMalwareScanResultsOutput, GetPITRMalwareScanResultsError, Credentials | HttpClient.HttpClient>;
export type GetRecoveryPointIndexDetailsError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * This operation returns the metadata and details specific to
 * the backup index associated with the specified recovery point.
 */
export declare const getRecoveryPointIndexDetails: API.OperationMethod<GetRecoveryPointIndexDetailsInput, GetRecoveryPointIndexDetailsOutput, GetRecoveryPointIndexDetailsError, Credentials | HttpClient.HttpClient>;
export type GetRecoveryPointRestoreMetadataError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a set of metadata key-value pairs that were used to create the backup.
 */
export declare const getRecoveryPointRestoreMetadata: API.OperationMethod<GetRecoveryPointRestoreMetadataInput, GetRecoveryPointRestoreMetadataOutput, GetRecoveryPointRestoreMetadataError, Credentials | HttpClient.HttpClient>;
export type GetRestoreJobMetadataError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * This request returns the metadata for the specified restore job.
 */
export declare const getRestoreJobMetadata: API.OperationMethod<GetRestoreJobMetadataInput, GetRestoreJobMetadataOutput, GetRestoreJobMetadataError, Credentials | HttpClient.HttpClient>;
export type GetRestoreTestingInferredMetadataError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * This request returns the minimal required set of metadata needed to
 * start a restore job with secure default settings. `BackupVaultName`
 * and `RecoveryPointArn` are required parameters.
 * `BackupVaultAccountId` is an optional parameter.
 */
export declare const getRestoreTestingInferredMetadata: API.OperationMethod<GetRestoreTestingInferredMetadataInput, GetRestoreTestingInferredMetadataOutput, GetRestoreTestingInferredMetadataError, Credentials | HttpClient.HttpClient>;
export type GetRestoreTestingPlanError = ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns `RestoreTestingPlan` details for the specified
 * `RestoreTestingPlanName`. The details are the body of a restore testing plan
 * in JSON format, in addition to plan metadata.
 */
export declare const getRestoreTestingPlan: API.OperationMethod<GetRestoreTestingPlanInput, GetRestoreTestingPlanOutput, GetRestoreTestingPlanError, Credentials | HttpClient.HttpClient>;
export type GetRestoreTestingSelectionError = ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns RestoreTestingSelection, which displays resources
 * and elements of the restore testing plan.
 */
export declare const getRestoreTestingSelection: API.OperationMethod<GetRestoreTestingSelectionInput, GetRestoreTestingSelectionOutput, GetRestoreTestingSelectionError, Credentials | HttpClient.HttpClient>;
export type GetSupportedResourceTypesError = ServiceUnavailableException | CommonErrors;
/**
 * Returns the Amazon Web Services resource types supported by Backup.
 */
export declare const getSupportedResourceTypes: API.OperationMethod<GetSupportedResourceTypesRequest, GetSupportedResourceTypesOutput, GetSupportedResourceTypesError, Credentials | HttpClient.HttpClient>;
export type GetTieringConfigurationError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns `TieringConfiguration` details for the specified
 * `TieringConfigurationName`. The details are the body of a tiering configuration
 * in JSON format, in addition to configuration metadata.
 */
export declare const getTieringConfiguration: API.OperationMethod<GetTieringConfigurationInput, GetTieringConfigurationOutput, GetTieringConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListBackupAccessPointsError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of the backup access points in your account and Region.
 */
export declare const listBackupAccessPoints: API.PaginatedOperationMethod<ListBackupAccessPointsRequest, ListBackupAccessPointsResponse, ListBackupAccessPointsError, Credentials | HttpClient.HttpClient, ListAccessPointsMember>;
export type ListBackupAccessPointsByRecoveryPointError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the backup access points associated with the specified recovery point.
 *
 * If you own the recovery point and have shared it with other accounts, the response includes backup access
 * points created by those accounts.
 */
export declare const listBackupAccessPointsByRecoveryPoint: API.PaginatedOperationMethod<ListBackupAccessPointsByRecoveryPointRequest, ListBackupAccessPointsByRecoveryPointResponse, ListBackupAccessPointsByRecoveryPointError, Credentials | HttpClient.HttpClient, ListAccessPointsMember>;
export type ListBackupAccessPointsByResourceError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the backup access points associated with the specified resource, such as an Amazon S3
 * bucket.
 */
export declare const listBackupAccessPointsByResource: API.PaginatedOperationMethod<ListBackupAccessPointsByResourceRequest, ListBackupAccessPointsByResourceResponse, ListBackupAccessPointsByResourceError, Credentials | HttpClient.HttpClient, ListAccessPointsMember>;
export type ListBackupJobsError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of existing backup jobs for an authenticated account for the last 30
 * days. For a longer period of time, consider using these monitoring tools.
 */
export declare const listBackupJobs: API.PaginatedOperationMethod<ListBackupJobsInput, ListBackupJobsOutput, ListBackupJobsError, Credentials | HttpClient.HttpClient, BackupJob>;
export type ListBackupJobSummariesError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * This is a request for a summary of backup jobs created
 * or running within the most recent 14 days. You can
 * include parameters AccountID, State, ResourceType, MessageCategory,
 * AggregationPeriod, MaxResults, or NextToken to filter
 * results.
 *
 * This request returns a summary that contains
 * Region, Account, State, ResourceType, MessageCategory,
 * StartTime, EndTime, and Count of included jobs.
 */
export declare const listBackupJobSummaries: API.PaginatedOperationMethod<ListBackupJobSummariesInput, ListBackupJobSummariesOutput, ListBackupJobSummariesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBackupPlansError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the active backup plans for the account.
 */
export declare const listBackupPlans: API.PaginatedOperationMethod<ListBackupPlansInput, ListBackupPlansOutput, ListBackupPlansError, Credentials | HttpClient.HttpClient, BackupPlansListMember>;
export type ListBackupPlanTemplatesError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the backup plan templates.
 */
export declare const listBackupPlanTemplates: API.PaginatedOperationMethod<ListBackupPlanTemplatesInput, ListBackupPlanTemplatesOutput, ListBackupPlanTemplatesError, Credentials | HttpClient.HttpClient, BackupPlanTemplatesListMember>;
export type ListBackupPlanVersionsError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns version metadata of your backup plans, including Amazon Resource Names (ARNs),
 * backup plan IDs, creation and deletion dates, plan names, and version IDs.
 */
export declare const listBackupPlanVersions: API.PaginatedOperationMethod<ListBackupPlanVersionsInput, ListBackupPlanVersionsOutput, ListBackupPlanVersionsError, Credentials | HttpClient.HttpClient, BackupPlansListMember>;
export type ListBackupSelectionsError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns an array containing metadata of the resources associated with the target backup
 * plan.
 */
export declare const listBackupSelections: API.PaginatedOperationMethod<ListBackupSelectionsInput, ListBackupSelectionsOutput, ListBackupSelectionsError, Credentials | HttpClient.HttpClient, BackupSelectionsListMember>;
export type ListBackupVaultsError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of recovery point storage containers along with information about
 * them.
 */
export declare const listBackupVaults: API.PaginatedOperationMethod<ListBackupVaultsInput, ListBackupVaultsOutput, ListBackupVaultsError, Credentials | HttpClient.HttpClient, BackupVaultListMember>;
export type ListCopyJobsError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Returns metadata about your copy jobs.
 */
export declare const listCopyJobs: API.PaginatedOperationMethod<ListCopyJobsInput, ListCopyJobsOutput, ListCopyJobsError, Credentials | HttpClient.HttpClient, CopyJob>;
export type ListCopyJobSummariesError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * This request obtains a list of copy jobs created
 * or running within the the most recent 14 days. You can
 * include parameters AccountID, State, ResourceType, MessageCategory,
 * AggregationPeriod, MaxResults, or NextToken to filter
 * results.
 *
 * This request returns a summary that contains
 * Region, Account, State, RestourceType, MessageCategory,
 * StartTime, EndTime, and Count of included jobs.
 */
export declare const listCopyJobSummaries: API.PaginatedOperationMethod<ListCopyJobSummariesInput, ListCopyJobSummariesOutput, ListCopyJobSummariesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFrameworksError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of all frameworks for an Amazon Web Services account and Amazon Web Services Region.
 */
export declare const listFrameworks: API.PaginatedOperationMethod<ListFrameworksInput, ListFrameworksOutput, ListFrameworksError, Credentials | HttpClient.HttpClient, unknown>;
export type ListIndexedRecoveryPointsError = InvalidParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * This operation returns a list of recovery points that have an
 * associated index, belonging to the specified account.
 *
 * Optional parameters you can include are: MaxResults;
 * NextToken; SourceResourceArns; CreatedBefore; CreatedAfter;
 * and ResourceType.
 */
export declare const listIndexedRecoveryPoints: API.PaginatedOperationMethod<ListIndexedRecoveryPointsInput, ListIndexedRecoveryPointsOutput, ListIndexedRecoveryPointsError, Credentials | HttpClient.HttpClient, IndexedRecoveryPoint>;
export type ListLegalHoldsError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * This action returns metadata about active and previous legal holds.
 */
export declare const listLegalHolds: API.PaginatedOperationMethod<ListLegalHoldsInput, ListLegalHoldsOutput, ListLegalHoldsError, Credentials | HttpClient.HttpClient, LegalHold>;
export type ListProtectedResourcesError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Returns an array of resources with recovery points created by Backup
 * (regardless of the recovery point's status),
 * including the time the resource was saved, an Amazon Resource Name (ARN) of the resource,
 * and a resource type.
 */
export declare const listProtectedResources: API.PaginatedOperationMethod<ListProtectedResourcesInput, ListProtectedResourcesOutput, ListProtectedResourcesError, Credentials | HttpClient.HttpClient, ProtectedResource>;
export type ListProtectedResourcesByBackupVaultError = InvalidParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * This request lists the protected resources corresponding to each backup vault.
 */
export declare const listProtectedResourcesByBackupVault: API.PaginatedOperationMethod<ListProtectedResourcesByBackupVaultInput, ListProtectedResourcesByBackupVaultOutput, ListProtectedResourcesByBackupVaultError, Credentials | HttpClient.HttpClient, ProtectedResource>;
export type ListRecoveryPointsByBackupVaultError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns detailed information about the recovery points stored in a backup vault.
 */
export declare const listRecoveryPointsByBackupVault: API.PaginatedOperationMethod<ListRecoveryPointsByBackupVaultInput, ListRecoveryPointsByBackupVaultOutput, ListRecoveryPointsByBackupVaultError, Credentials | HttpClient.HttpClient, RecoveryPointByBackupVault>;
export type ListRecoveryPointsByLegalHoldError = InvalidParameterValueException | MissingParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * This action returns recovery point ARNs (Amazon Resource Names) of the
 * specified legal hold.
 */
export declare const listRecoveryPointsByLegalHold: API.PaginatedOperationMethod<ListRecoveryPointsByLegalHoldInput, ListRecoveryPointsByLegalHoldOutput, ListRecoveryPointsByLegalHoldError, Credentials | HttpClient.HttpClient, RecoveryPointMember>;
export type ListRecoveryPointsByResourceError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * The information about the recovery points of the type specified by a
 * resource Amazon Resource Name (ARN).
 *
 * For Amazon EFS and Amazon EC2, this action only lists recovery points
 * created by Backup.
 */
export declare const listRecoveryPointsByResource: API.PaginatedOperationMethod<ListRecoveryPointsByResourceInput, ListRecoveryPointsByResourceOutput, ListRecoveryPointsByResourceError, Credentials | HttpClient.HttpClient, RecoveryPointByResource>;
export type ListReportJobsError = InvalidParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns details about your report jobs.
 */
export declare const listReportJobs: API.PaginatedOperationMethod<ListReportJobsInput, ListReportJobsOutput, ListReportJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListReportPlansError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of your report plans. For detailed information about a single report
 * plan, use `DescribeReportPlan`.
 */
export declare const listReportPlans: API.PaginatedOperationMethod<ListReportPlansInput, ListReportPlansOutput, ListReportPlansError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRestoreAccessBackupVaultsError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of restore access backup vaults associated with a specified backup vault.
 */
export declare const listRestoreAccessBackupVaults: API.PaginatedOperationMethod<ListRestoreAccessBackupVaultsInput, ListRestoreAccessBackupVaultsOutput, ListRestoreAccessBackupVaultsError, Credentials | HttpClient.HttpClient, RestoreAccessBackupVaultListMember>;
export type ListRestoreJobsError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of jobs that Backup initiated to restore a saved resource,
 * including details about the recovery process.
 */
export declare const listRestoreJobs: API.PaginatedOperationMethod<ListRestoreJobsInput, ListRestoreJobsOutput, ListRestoreJobsError, Credentials | HttpClient.HttpClient, RestoreJobsListMember>;
export type ListRestoreJobsByProtectedResourceError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * This returns restore jobs that contain the specified protected resource.
 *
 * You must include `ResourceArn`. You can optionally include
 * `NextToken`, `ByStatus`, `MaxResults`,
 * `ByRecoveryPointCreationDateAfter` , and
 * `ByRecoveryPointCreationDateBefore`.
 */
export declare const listRestoreJobsByProtectedResource: API.PaginatedOperationMethod<ListRestoreJobsByProtectedResourceInput, ListRestoreJobsByProtectedResourceOutput, ListRestoreJobsByProtectedResourceError, Credentials | HttpClient.HttpClient, RestoreJobsListMember>;
export type ListRestoreJobSummariesError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * This request obtains a summary of restore jobs created
 * or running within the the most recent 14 days. You can
 * include parameters AccountID, State, ResourceType,
 * AggregationPeriod, MaxResults, or NextToken to filter
 * results.
 *
 * This request returns a summary that contains
 * Region, Account, State, RestourceType, MessageCategory,
 * StartTime, EndTime, and Count of included jobs.
 */
export declare const listRestoreJobSummaries: API.PaginatedOperationMethod<ListRestoreJobSummariesInput, ListRestoreJobSummariesOutput, ListRestoreJobSummariesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRestoreTestingPlansError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of restore testing plans.
 */
export declare const listRestoreTestingPlans: API.PaginatedOperationMethod<ListRestoreTestingPlansInput, ListRestoreTestingPlansOutput, ListRestoreTestingPlansError, Credentials | HttpClient.HttpClient, RestoreTestingPlanForList>;
export type ListRestoreTestingSelectionsError = InvalidParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of restore testing selections. Can be filtered
 * by `MaxResults` and `RestoreTestingPlanName`.
 */
export declare const listRestoreTestingSelections: API.PaginatedOperationMethod<ListRestoreTestingSelectionsInput, ListRestoreTestingSelectionsOutput, ListRestoreTestingSelectionsError, Credentials | HttpClient.HttpClient, RestoreTestingSelectionForList>;
export type ListScanJobsError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of existing scan jobs for an authenticated account for the last 30 days.
 */
export declare const listScanJobs: API.PaginatedOperationMethod<ListScanJobsInput, ListScanJobsOutput, ListScanJobsError, Credentials | HttpClient.HttpClient, ScanJob>;
export type ListScanJobSummariesError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * This is a request for a summary of scan jobs created or running within the most recent 14 days.
 */
export declare const listScanJobSummaries: API.PaginatedOperationMethod<ListScanJobSummariesInput, ListScanJobSummariesOutput, ListScanJobSummariesError, Credentials | HttpClient.HttpClient, ScanJobSummary>;
export type ListTagsError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the tags assigned to the resource, such as a target recovery point, backup plan,
 * or backup vault.
 *
 * This operation returns results depending on the resource type used in the value for
 * `resourceArn`. For example, recovery points of Amazon DynamoDB with
 * Advanced Settings have an ARN (Amazon Resource Name) that begins with
 * `arn:aws:backup`. Recovery points (backups) of DynamoDB without
 * Advanced Settings enabled have an ARN that begins with
 * `arn:aws:dynamodb`.
 *
 * When this operation is called and when you include values of `resourceArn`
 * that have an ARN other than `arn:aws:backup`, it may return one of the
 * exceptions listed below. To prevent this exception, include only values representing
 * resource types that are fully managed by Backup. These have an ARN that begins
 * `arn:aws:backup` and they are noted in the Feature availability by resource table.
 */
export declare const listTags: API.PaginatedOperationMethod<ListTagsInput, ListTagsOutput, ListTagsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTieringConfigurationsError = InvalidParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of tiering configurations.
 */
export declare const listTieringConfigurations: API.PaginatedOperationMethod<ListTieringConfigurationsInput, ListTieringConfigurationsOutput, ListTieringConfigurationsError, Credentials | HttpClient.HttpClient, TieringConfigurationsListMember>;
export type PutBackupVaultAccessPolicyError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Sets a resource-based policy that is used to manage access permissions on the target
 * backup vault. Requires a backup vault name and an access policy document in JSON
 * format.
 */
export declare const putBackupVaultAccessPolicy: API.OperationMethod<PutBackupVaultAccessPolicyInput, PutBackupVaultAccessPolicyResponse, PutBackupVaultAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type PutBackupVaultLockConfigurationError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Applies Backup Vault Lock to a backup vault, preventing attempts to delete
 * any recovery point stored in or created in a backup vault. Vault Lock also prevents
 * attempts to update the lifecycle policy that controls the retention period of any recovery
 * point currently stored in a backup vault. If specified, Vault Lock enforces a minimum and
 * maximum retention period for future backup and copy jobs that target a backup vault.
 *
 * Backup Vault Lock has been assessed by Cohasset Associates for use in environments
 * that are subject to SEC 17a-4, CFTC, and FINRA regulations. For more information about
 * how Backup Vault Lock relates to these regulations, see the
 * Cohasset Associates
 * Compliance Assessment.
 *
 * For more information, see Backup Vault Lock.
 */
export declare const putBackupVaultLockConfiguration: API.OperationMethod<PutBackupVaultLockConfigurationInput, PutBackupVaultLockConfigurationResponse, PutBackupVaultLockConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutBackupVaultNotificationsError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Turns on notifications on a backup vault for the specified topic and events.
 */
export declare const putBackupVaultNotifications: API.OperationMethod<PutBackupVaultNotificationsInput, PutBackupVaultNotificationsResponse, PutBackupVaultNotificationsError, Credentials | HttpClient.HttpClient>;
export type PutRestoreValidationResultError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * This request allows you to send your independent self-run
 * restore test validation results.
 * `RestoreJobId` and `ValidationStatus`
 * are required. Optionally, you can input a
 * `ValidationStatusMessage`.
 */
export declare const putRestoreValidationResult: API.OperationMethod<PutRestoreValidationResultInput, PutRestoreValidationResultResponse, PutRestoreValidationResultError, Credentials | HttpClient.HttpClient>;
export type RevokeRestoreAccessBackupVaultError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Revokes access to a restore access backup vault, removing the ability to restore from its recovery points and permanently deleting the vault.
 */
export declare const revokeRestoreAccessBackupVault: API.OperationMethod<RevokeRestoreAccessBackupVaultInput, RevokeRestoreAccessBackupVaultResponse, RevokeRestoreAccessBackupVaultError, Credentials | HttpClient.HttpClient>;
export type StartBackupJobError = InvalidParameterValueException | InvalidRequestException | LimitExceededException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Starts an on-demand backup job for the specified resource.
 */
export declare const startBackupJob: API.OperationMethod<StartBackupJobInput, StartBackupJobOutput, StartBackupJobError, Credentials | HttpClient.HttpClient>;
export type StartCopyJobError = InvalidParameterValueException | InvalidRequestException | LimitExceededException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Starts a job to create a one-time copy of the specified resource.
 *
 * Does not support continuous backups.
 *
 * See Copy
 * job retry for information on how Backup retries copy job
 * operations.
 */
export declare const startCopyJob: API.OperationMethod<StartCopyJobInput, StartCopyJobOutput, StartCopyJobError, Credentials | HttpClient.HttpClient>;
export type StartReportJobError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Starts an on-demand report job for the specified report plan.
 */
export declare const startReportJob: API.OperationMethod<StartReportJobInput, StartReportJobOutput, StartReportJobError, Credentials | HttpClient.HttpClient>;
export type StartRestoreJobError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Recovers the saved resource identified by an Amazon Resource Name (ARN).
 */
export declare const startRestoreJob: API.OperationMethod<StartRestoreJobInput, StartRestoreJobOutput, StartRestoreJobError, Credentials | HttpClient.HttpClient>;
export type StartScanJobError = InvalidParameterValueException | InvalidRequestException | LimitExceededException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Starts scanning jobs for specific resources.
 */
export declare const startScanJob: API.OperationMethod<StartScanJobInput, StartScanJobOutput, StartScanJobError, Credentials | HttpClient.HttpClient>;
export type StopBackupJobError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Attempts to cancel a job to create a one-time backup of a resource.
 *
 * This action is not supported for the following services:
 *
 * - Amazon Aurora
 *
 * - Amazon DocumentDB (with MongoDB compatibility)
 *
 * - Amazon FSx for Lustre
 *
 * - Amazon FSx for NetApp ONTAP
 *
 * - Amazon FSx for OpenZFS
 *
 * - Amazon FSx for Windows File Server
 *
 * - Amazon Neptune
 *
 * - SAP HANA databases on Amazon EC2 instances
 *
 * - Amazon RDS
 */
export declare const stopBackupJob: API.OperationMethod<StopBackupJobInput, StopBackupJobResponse, StopBackupJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidParameterValueException | LimitExceededException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Assigns a set of key-value pairs to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Removes a set of key-value pairs from a recovery point, backup plan, or backup vault
 * identified by an Amazon Resource Name (ARN)
 *
 * This API is not supported for recovery points for resource types
 * including Aurora, Amazon DocumentDB. Amazon EBS,
 * Amazon FSx, Neptune, and Amazon RDS.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBackupPlanError = InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Updates the specified backup plan. The new version is uniquely identified by its ID.
 */
export declare const updateBackupPlan: API.OperationMethod<UpdateBackupPlanInput, UpdateBackupPlanOutput, UpdateBackupPlanError, Credentials | HttpClient.HttpClient>;
export type UpdateFrameworkError = AlreadyExistsException | ConflictException | InvalidParameterValueException | LimitExceededException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Updates the specified framework.
 */
export declare const updateFramework: API.OperationMethod<UpdateFrameworkInput, UpdateFrameworkOutput, UpdateFrameworkError, Credentials | HttpClient.HttpClient>;
export type UpdateGlobalSettingsError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Updates whether the Amazon Web Services account has enabled different cross-account management options, including cross-account backup, multi-party approval, and delegated administrator. Returns an error if the account is not an Organizations management account. Use the `DescribeGlobalSettings` API to determine the current settings.
 */
export declare const updateGlobalSettings: API.OperationMethod<UpdateGlobalSettingsInput, UpdateGlobalSettingsResponse, UpdateGlobalSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateRecoveryPointIndexSettingsError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * This operation updates the settings of a recovery point index.
 *
 * Required: BackupVaultName, RecoveryPointArn, and IAMRoleArn
 */
export declare const updateRecoveryPointIndexSettings: API.OperationMethod<UpdateRecoveryPointIndexSettingsInput, UpdateRecoveryPointIndexSettingsOutput, UpdateRecoveryPointIndexSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateRecoveryPointLifecycleError = InvalidParameterValueException | InvalidRequestException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Sets the transition lifecycle of a recovery point.
 *
 * The lifecycle defines when a protected resource is transitioned to cold storage and when
 * it expires. Backup transitions and expires backups automatically according to
 * the lifecycle that you define.
 *
 * Resource types that can transition to cold storage are listed in the Feature availability by resource table. Backup ignores this expression for
 * other resource types.
 *
 * Backups transitioned to cold storage must be stored in cold storage for a minimum of 90
 * days. Therefore, the “retention” setting must be 90 days greater than the “transition to
 * cold after days” setting. The “transition to cold after days” setting cannot be changed
 * after a backup has been transitioned to cold.
 *
 * If your lifecycle currently uses the parameters `DeleteAfterDays` and
 * `MoveToColdStorageAfterDays`, include these parameters and their values when you call
 * this operation. Not including them may result in your plan updating with null values.
 *
 * This operation does not support continuous backups.
 */
export declare const updateRecoveryPointLifecycle: API.OperationMethod<UpdateRecoveryPointLifecycleInput, UpdateRecoveryPointLifecycleOutput, UpdateRecoveryPointLifecycleError, Credentials | HttpClient.HttpClient>;
export type UpdateRegionSettingsError = InvalidParameterValueException | MissingParameterValueException | ServiceUnavailableException | CommonErrors;
/**
 * Updates the current service opt-in settings for the Region.
 *
 * Use
 * the `DescribeRegionSettings` API to determine the resource types that are
 * supported.
 */
export declare const updateRegionSettings: API.OperationMethod<UpdateRegionSettingsInput, UpdateRegionSettingsResponse, UpdateRegionSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateReportPlanError = ConflictException | InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Updates the specified report plan.
 */
export declare const updateReportPlan: API.OperationMethod<UpdateReportPlanInput, UpdateReportPlanOutput, UpdateReportPlanError, Credentials | HttpClient.HttpClient>;
export type UpdateRestoreTestingPlanError = ConflictException | InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * This request will send changes to your specified restore testing
 * plan. `RestoreTestingPlanName`
 * cannot be updated after it is created.
 *
 * `RecoveryPointSelection` can contain:
 *
 * - `Algorithm`
 *
 * - `ExcludeVaults`
 *
 * - `IncludeVaults`
 *
 * - `RecoveryPointTypes`
 *
 * - `SelectionWindowDays`
 */
export declare const updateRestoreTestingPlan: API.OperationMethod<UpdateRestoreTestingPlanInput, UpdateRestoreTestingPlanOutput, UpdateRestoreTestingPlanError, Credentials | HttpClient.HttpClient>;
export type UpdateRestoreTestingSelectionError = ConflictException | InvalidParameterValueException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Updates the specified restore testing selection.
 *
 * Most elements except the `RestoreTestingSelectionName`
 * can be updated with this request.
 *
 * You can use either protected resource ARNs or conditions, but not both.
 */
export declare const updateRestoreTestingSelection: API.OperationMethod<UpdateRestoreTestingSelectionInput, UpdateRestoreTestingSelectionOutput, UpdateRestoreTestingSelectionError, Credentials | HttpClient.HttpClient>;
export type UpdateTieringConfigurationError = AlreadyExistsException | ConflictException | InvalidParameterValueException | LimitExceededException | MissingParameterValueException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * This request will send changes to your specified tiering
 * configuration. `TieringConfigurationName`
 * cannot be updated after it is created.
 *
 * `ResourceSelection` can contain:
 *
 * - `Resources`
 *
 * - `TieringDownSettingsInDays`
 *
 * - `ResourceType`
 */
export declare const updateTieringConfiguration: API.OperationMethod<UpdateTieringConfigurationInput, UpdateTieringConfigurationOutput, UpdateTieringConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=backup.d.ts.map