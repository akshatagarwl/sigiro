import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ActionExecutionNotFoundException_base: S.Class<ActionExecutionNotFoundException, S.TaggedStruct<"ActionExecutionNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ActionExecutionNotFoundException extends /*@__PURE__*/ ActionExecutionNotFoundException_base {
}
declare const ActionNotFoundException_base: S.Class<ActionNotFoundException, S.TaggedStruct<"ActionNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ActionNotFoundException extends /*@__PURE__*/ ActionNotFoundException_base {
}
declare const ActionTypeNotFoundException_base: S.Class<ActionTypeNotFoundException, S.TaggedStruct<"ActionTypeNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ActionTypeNotFoundException extends /*@__PURE__*/ ActionTypeNotFoundException_base {
}
declare const ApprovalAlreadyCompletedException_base: S.Class<ApprovalAlreadyCompletedException, S.TaggedStruct<"ApprovalAlreadyCompletedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ApprovalAlreadyCompletedException extends /*@__PURE__*/ ApprovalAlreadyCompletedException_base {
}
declare const ConcurrentModificationException_base: S.Class<ConcurrentModificationException, S.TaggedStruct<"ConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConcurrentPipelineExecutionsLimitExceededException_base: S.Class<ConcurrentPipelineExecutionsLimitExceededException, S.TaggedStruct<"ConcurrentPipelineExecutionsLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConcurrentPipelineExecutionsLimitExceededException extends /*@__PURE__*/ ConcurrentPipelineExecutionsLimitExceededException_base {
}
declare const ConditionNotOverridableException_base: S.Class<ConditionNotOverridableException, S.TaggedStruct<"ConditionNotOverridableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConditionNotOverridableException extends /*@__PURE__*/ ConditionNotOverridableException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DuplicatedStopRequestException_base: S.Class<DuplicatedStopRequestException, S.TaggedStruct<"DuplicatedStopRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DuplicatedStopRequestException extends /*@__PURE__*/ DuplicatedStopRequestException_base {
}
declare const InvalidActionDeclarationException_base: S.Class<InvalidActionDeclarationException, S.TaggedStruct<"InvalidActionDeclarationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidActionDeclarationException extends /*@__PURE__*/ InvalidActionDeclarationException_base {
}
declare const InvalidApprovalTokenException_base: S.Class<InvalidApprovalTokenException, S.TaggedStruct<"InvalidApprovalTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidApprovalTokenException extends /*@__PURE__*/ InvalidApprovalTokenException_base {
}
declare const InvalidArnException_base: S.Class<InvalidArnException, S.TaggedStruct<"InvalidArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidArnException extends /*@__PURE__*/ InvalidArnException_base {
}
declare const InvalidBlockerDeclarationException_base: S.Class<InvalidBlockerDeclarationException, S.TaggedStruct<"InvalidBlockerDeclarationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidBlockerDeclarationException extends /*@__PURE__*/ InvalidBlockerDeclarationException_base {
}
declare const InvalidClientTokenException_base: S.Class<InvalidClientTokenException, S.TaggedStruct<"InvalidClientTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidClientTokenException extends /*@__PURE__*/ InvalidClientTokenException_base {
}
declare const InvalidJobException_base: S.Class<InvalidJobException, S.TaggedStruct<"InvalidJobException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidJobException extends /*@__PURE__*/ InvalidJobException_base {
}
declare const InvalidJobStateException_base: S.Class<InvalidJobStateException, S.TaggedStruct<"InvalidJobStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidJobStateException extends /*@__PURE__*/ InvalidJobStateException_base {
}
declare const InvalidNextTokenException_base: S.Class<InvalidNextTokenException, S.TaggedStruct<"InvalidNextTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidNonceException_base: S.Class<InvalidNonceException, S.TaggedStruct<"InvalidNonceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidNonceException extends /*@__PURE__*/ InvalidNonceException_base {
}
declare const InvalidStageDeclarationException_base: S.Class<InvalidStageDeclarationException, S.TaggedStruct<"InvalidStageDeclarationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidStageDeclarationException extends /*@__PURE__*/ InvalidStageDeclarationException_base {
}
declare const InvalidStructureException_base: S.Class<InvalidStructureException, S.TaggedStruct<"InvalidStructureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidStructureException extends /*@__PURE__*/ InvalidStructureException_base {
}
declare const InvalidTagsException_base: S.Class<InvalidTagsException, S.TaggedStruct<"InvalidTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTagsException extends /*@__PURE__*/ InvalidTagsException_base {
}
declare const InvalidWebhookAuthenticationParametersException_base: S.Class<InvalidWebhookAuthenticationParametersException, S.TaggedStruct<"InvalidWebhookAuthenticationParametersException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidWebhookAuthenticationParametersException extends /*@__PURE__*/ InvalidWebhookAuthenticationParametersException_base {
}
declare const InvalidWebhookFilterPatternException_base: S.Class<InvalidWebhookFilterPatternException, S.TaggedStruct<"InvalidWebhookFilterPatternException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidWebhookFilterPatternException extends /*@__PURE__*/ InvalidWebhookFilterPatternException_base {
}
declare const JobNotFoundException_base: S.Class<JobNotFoundException, S.TaggedStruct<"JobNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class JobNotFoundException extends /*@__PURE__*/ JobNotFoundException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotLatestPipelineExecutionException_base: S.Class<NotLatestPipelineExecutionException, S.TaggedStruct<"NotLatestPipelineExecutionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NotLatestPipelineExecutionException extends /*@__PURE__*/ NotLatestPipelineExecutionException_base {
}
declare const OutputVariablesSizeExceededException_base: S.Class<OutputVariablesSizeExceededException, S.TaggedStruct<"OutputVariablesSizeExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OutputVariablesSizeExceededException extends /*@__PURE__*/ OutputVariablesSizeExceededException_base {
}
declare const PipelineExecutionNotFoundException_base: S.Class<PipelineExecutionNotFoundException, S.TaggedStruct<"PipelineExecutionNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PipelineExecutionNotFoundException extends /*@__PURE__*/ PipelineExecutionNotFoundException_base {
}
declare const PipelineExecutionNotStoppableException_base: S.Class<PipelineExecutionNotStoppableException, S.TaggedStruct<"PipelineExecutionNotStoppableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PipelineExecutionNotStoppableException extends /*@__PURE__*/ PipelineExecutionNotStoppableException_base {
}
declare const PipelineExecutionOutdatedException_base: S.Class<PipelineExecutionOutdatedException, S.TaggedStruct<"PipelineExecutionOutdatedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PipelineExecutionOutdatedException extends /*@__PURE__*/ PipelineExecutionOutdatedException_base {
}
declare const PipelineNameInUseException_base: S.Class<PipelineNameInUseException, S.TaggedStruct<"PipelineNameInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PipelineNameInUseException extends /*@__PURE__*/ PipelineNameInUseException_base {
}
declare const PipelineNotFoundException_base: S.Class<PipelineNotFoundException, S.TaggedStruct<"PipelineNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PipelineNotFoundException extends /*@__PURE__*/ PipelineNotFoundException_base {
}
declare const PipelineVersionNotFoundException_base: S.Class<PipelineVersionNotFoundException, S.TaggedStruct<"PipelineVersionNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PipelineVersionNotFoundException extends /*@__PURE__*/ PipelineVersionNotFoundException_base {
}
declare const RequestFailedException_base: S.Class<RequestFailedException, S.TaggedStruct<"RequestFailedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RequestFailedException extends /*@__PURE__*/ RequestFailedException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const StageNotFoundException_base: S.Class<StageNotFoundException, S.TaggedStruct<"StageNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class StageNotFoundException extends /*@__PURE__*/ StageNotFoundException_base {
}
declare const StageNotRetryableException_base: S.Class<StageNotRetryableException, S.TaggedStruct<"StageNotRetryableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class StageNotRetryableException extends /*@__PURE__*/ StageNotRetryableException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnableToRollbackStageException_base: S.Class<UnableToRollbackStageException, S.TaggedStruct<"UnableToRollbackStageException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnableToRollbackStageException extends /*@__PURE__*/ UnableToRollbackStageException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
declare const WebhookNotFoundException_base: S.Class<WebhookNotFoundException, S.TaggedStruct<"WebhookNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WebhookNotFoundException extends /*@__PURE__*/ WebhookNotFoundException_base {
}
export type JobId = string;
export type Nonce = string;
export interface AcknowledgeJobInput {
    jobId: string;
    nonce: string;
}
export declare const AcknowledgeJobInput: S.Schema<AcknowledgeJobInput>;
export type JobStatus = "Created" | "Queued" | "Dispatched" | "InProgress" | "TimedOut" | "Succeeded" | "Failed" | (string & {});
export declare const JobStatus: any;
export interface AcknowledgeJobOutput {
    status?: JobStatus;
}
export declare const AcknowledgeJobOutput: S.Schema<AcknowledgeJobOutput>;
export type ThirdPartyJobId = string;
export type ClientToken = string;
export interface AcknowledgeThirdPartyJobInput {
    jobId: string;
    nonce: string;
    clientToken: string;
}
export declare const AcknowledgeThirdPartyJobInput: S.Schema<AcknowledgeThirdPartyJobInput>;
export interface AcknowledgeThirdPartyJobOutput {
    status?: JobStatus;
}
export declare const AcknowledgeThirdPartyJobOutput: S.Schema<AcknowledgeThirdPartyJobOutput>;
export type ActionCategory = "Source" | "Build" | "Deploy" | "Test" | "Invoke" | "Approval" | "Compute" | (string & {});
export declare const ActionCategory: any;
export type ActionProvider = string;
export type Version = string;
export type Url = string;
export type UrlTemplate = string;
export interface ActionTypeSettings {
    thirdPartyConfigurationUrl?: string;
    entityUrlTemplate?: string;
    executionUrlTemplate?: string;
    revisionUrlTemplate?: string;
}
export declare const ActionTypeSettings: S.Schema<ActionTypeSettings>;
export type ActionConfigurationKey = string;
export type Description = string;
export type ActionConfigurationPropertyType = "String" | "Number" | "Boolean" | (string & {});
export declare const ActionConfigurationPropertyType: any;
export interface ActionConfigurationProperty {
    name: string;
    required: boolean;
    key: boolean;
    secret: boolean;
    queryable?: boolean;
    description?: string;
    type?: ActionConfigurationPropertyType;
}
export declare const ActionConfigurationProperty: S.Schema<ActionConfigurationProperty>;
export type ActionConfigurationPropertyList = ActionConfigurationProperty[];
export declare const ActionConfigurationPropertyList: any;
export type MinimumArtifactCount = number;
export type MaximumArtifactCount = number;
export interface ArtifactDetails {
    minimumCount: number;
    maximumCount: number;
}
export declare const ArtifactDetails: S.Schema<ArtifactDetails>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateCustomActionTypeInput {
    category: ActionCategory;
    provider: string;
    version: string;
    settings?: ActionTypeSettings;
    configurationProperties?: ActionConfigurationProperty[];
    inputArtifactDetails: ArtifactDetails;
    outputArtifactDetails: ArtifactDetails;
    tags?: Tag[];
}
export declare const CreateCustomActionTypeInput: S.Schema<CreateCustomActionTypeInput>;
export type ActionOwner = "AWS" | "ThirdParty" | "Custom" | (string & {});
export declare const ActionOwner: any;
export interface ActionTypeId {
    category: ActionCategory;
    owner: ActionOwner;
    provider: string;
    version: string;
}
export declare const ActionTypeId: S.Schema<ActionTypeId>;
export interface ActionType {
    id: ActionTypeId;
    settings?: ActionTypeSettings;
    actionConfigurationProperties?: ActionConfigurationProperty[];
    inputArtifactDetails: ArtifactDetails;
    outputArtifactDetails: ArtifactDetails;
}
export declare const ActionType: S.Schema<ActionType>;
export interface CreateCustomActionTypeOutput {
    actionType: ActionType;
    tags?: Tag[];
}
export declare const CreateCustomActionTypeOutput: S.Schema<CreateCustomActionTypeOutput>;
export type PipelineName = string;
export type RoleArn = string;
export type ArtifactStoreType = "S3" | (string & {});
export declare const ArtifactStoreType: any;
export type ArtifactStoreLocation = string;
export type EncryptionKeyId = string;
export type EncryptionKeyType = "KMS" | (string & {});
export declare const EncryptionKeyType: any;
export interface EncryptionKey {
    id: string;
    type: EncryptionKeyType;
}
export declare const EncryptionKey: S.Schema<EncryptionKey>;
export interface ArtifactStore {
    type: ArtifactStoreType;
    location: string;
    encryptionKey?: EncryptionKey;
}
export declare const ArtifactStore: S.Schema<ArtifactStore>;
export type AWSRegionName = string;
export type ArtifactStoreMap = {
    [key: string]: ArtifactStore | undefined;
};
export declare const ArtifactStoreMap: any;
export type StageName = string;
export type BlockerName = string;
export type BlockerType = "Schedule" | (string & {});
export declare const BlockerType: any;
export interface BlockerDeclaration {
    name: string;
    type: BlockerType;
}
export declare const BlockerDeclaration: S.Schema<BlockerDeclaration>;
export type StageBlockerDeclarationList = BlockerDeclaration[];
export declare const StageBlockerDeclarationList: any;
export type ActionName = string;
export type ActionRunOrder = number;
export type ActionConfigurationValue = string;
export type ActionConfigurationMap = {
    [key: string]: string | undefined;
};
export declare const ActionConfigurationMap: any;
export type Command = string;
export type CommandList = string[];
export declare const CommandList: any;
export type ArtifactName = string;
export type FilePath = string;
export type FilePathList = string[];
export declare const FilePathList: any;
export interface OutputArtifact {
    name: string;
    files?: string[];
}
export declare const OutputArtifact: S.Schema<OutputArtifact>;
export type OutputArtifactList = OutputArtifact[];
export declare const OutputArtifactList: any;
export interface InputArtifact {
    name: string;
}
export declare const InputArtifact: S.Schema<InputArtifact>;
export type InputArtifactList = InputArtifact[];
export declare const InputArtifactList: any;
export type OutputVariable = string;
export type OutputVariableList = string[];
export declare const OutputVariableList: any;
export type ActionNamespace = string;
export type ActionTimeout = number;
export type EnvironmentVariableName = string;
export type EnvironmentVariableValue = string;
export type EnvironmentVariableType = "PLAINTEXT" | "SECRETS_MANAGER" | (string & {});
export declare const EnvironmentVariableType: any;
export interface EnvironmentVariable {
    name: string;
    value: string;
    type?: EnvironmentVariableType;
}
export declare const EnvironmentVariable: S.Schema<EnvironmentVariable>;
export type EnvironmentVariableList = EnvironmentVariable[];
export declare const EnvironmentVariableList: any;
export interface ActionDeclaration {
    name: string;
    actionTypeId: ActionTypeId;
    runOrder?: number;
    configuration?: {
        [key: string]: string | undefined;
    };
    commands?: string[];
    outputArtifacts?: OutputArtifact[];
    inputArtifacts?: InputArtifact[];
    outputVariables?: string[];
    roleArn?: string;
    region?: string;
    namespace?: string;
    timeoutInMinutes?: number;
    environmentVariables?: EnvironmentVariable[];
}
export declare const ActionDeclaration: S.Schema<ActionDeclaration>;
export type StageActionDeclarationList = ActionDeclaration[];
export declare const StageActionDeclarationList: any;
export type Result = "ROLLBACK" | "FAIL" | "RETRY" | "SKIP" | (string & {});
export declare const Result: any;
export type StageRetryMode = "FAILED_ACTIONS" | "ALL_ACTIONS" | (string & {});
export declare const StageRetryMode: any;
export interface RetryConfiguration {
    retryMode?: StageRetryMode;
}
export declare const RetryConfiguration: S.Schema<RetryConfiguration>;
export type RuleName = string;
export type RuleCategory = "Rule" | (string & {});
export declare const RuleCategory: any;
export type RuleOwner = "AWS" | (string & {});
export declare const RuleOwner: any;
export type RuleProvider = string;
export interface RuleTypeId {
    category: RuleCategory;
    owner?: RuleOwner;
    provider: string;
    version?: string;
}
export declare const RuleTypeId: S.Schema<RuleTypeId>;
export type RuleConfigurationKey = string;
export type RuleConfigurationValue = string;
export type RuleConfigurationMap = {
    [key: string]: string | undefined;
};
export declare const RuleConfigurationMap: any;
export type RuleTimeout = number;
export interface RuleDeclaration {
    name: string;
    ruleTypeId: RuleTypeId;
    configuration?: {
        [key: string]: string | undefined;
    };
    commands?: string[];
    inputArtifacts?: InputArtifact[];
    roleArn?: string;
    region?: string;
    timeoutInMinutes?: number;
}
export declare const RuleDeclaration: S.Schema<RuleDeclaration>;
export type RuleDeclarationList = RuleDeclaration[];
export declare const RuleDeclarationList: any;
export interface Condition {
    result?: Result;
    rules?: RuleDeclaration[];
}
export declare const Condition: S.Schema<Condition>;
export type ConditionList = Condition[];
export declare const ConditionList: any;
export interface FailureConditions {
    result?: Result;
    retryConfiguration?: RetryConfiguration;
    conditions?: Condition[];
}
export declare const FailureConditions: S.Schema<FailureConditions>;
export interface SuccessConditions {
    conditions: Condition[];
}
export declare const SuccessConditions: S.Schema<SuccessConditions>;
export interface BeforeEntryConditions {
    conditions: Condition[];
}
export declare const BeforeEntryConditions: S.Schema<BeforeEntryConditions>;
export interface StageDeclaration {
    name: string;
    blockers?: BlockerDeclaration[];
    actions: ActionDeclaration[];
    onFailure?: FailureConditions;
    onSuccess?: SuccessConditions;
    beforeEntry?: BeforeEntryConditions;
}
export declare const StageDeclaration: S.Schema<StageDeclaration>;
export type PipelineStageDeclarationList = StageDeclaration[];
export declare const PipelineStageDeclarationList: any;
export type PipelineVersion = number;
export type ExecutionMode = "QUEUED" | "SUPERSEDED" | "PARALLEL" | (string & {});
export declare const ExecutionMode: any;
export type PipelineType = "V1" | "V2" | (string & {});
export declare const PipelineType: any;
export type PipelineVariableName = string;
export type PipelineVariableValue = string;
export type PipelineVariableDescription = string;
export interface PipelineVariableDeclaration {
    name: string;
    defaultValue?: string;
    description?: string;
}
export declare const PipelineVariableDeclaration: S.Schema<PipelineVariableDeclaration>;
export type PipelineVariableDeclarationList = PipelineVariableDeclaration[];
export declare const PipelineVariableDeclarationList: any;
export type PipelineTriggerProviderType = "CodeStarSourceConnection" | (string & {});
export declare const PipelineTriggerProviderType: any;
export type GitTagNamePattern = string;
export type GitTagPatternList = string[];
export declare const GitTagPatternList: any;
export interface GitTagFilterCriteria {
    includes?: string[];
    excludes?: string[];
}
export declare const GitTagFilterCriteria: S.Schema<GitTagFilterCriteria>;
export type GitBranchNamePattern = string;
export type GitBranchPatternList = string[];
export declare const GitBranchPatternList: any;
export interface GitBranchFilterCriteria {
    includes?: string[];
    excludes?: string[];
}
export declare const GitBranchFilterCriteria: S.Schema<GitBranchFilterCriteria>;
export type GitFilePathPattern = string;
export type GitFilePathPatternList = string[];
export declare const GitFilePathPatternList: any;
export interface GitFilePathFilterCriteria {
    includes?: string[];
    excludes?: string[];
}
export declare const GitFilePathFilterCriteria: S.Schema<GitFilePathFilterCriteria>;
export interface GitPushFilter {
    tags?: GitTagFilterCriteria;
    branches?: GitBranchFilterCriteria;
    filePaths?: GitFilePathFilterCriteria;
}
export declare const GitPushFilter: S.Schema<GitPushFilter>;
export type GitPushFilterList = GitPushFilter[];
export declare const GitPushFilterList: any;
export type GitPullRequestEventType = "OPEN" | "UPDATED" | "CLOSED" | (string & {});
export declare const GitPullRequestEventType: any;
export type GitPullRequestEventTypeList = GitPullRequestEventType[];
export declare const GitPullRequestEventTypeList: any;
export interface GitPullRequestFilter {
    events?: GitPullRequestEventType[];
    branches?: GitBranchFilterCriteria;
    filePaths?: GitFilePathFilterCriteria;
}
export declare const GitPullRequestFilter: S.Schema<GitPullRequestFilter>;
export type GitPullRequestFilterList = GitPullRequestFilter[];
export declare const GitPullRequestFilterList: any;
export interface GitConfiguration {
    sourceActionName: string;
    push?: GitPushFilter[];
    pullRequest?: GitPullRequestFilter[];
}
export declare const GitConfiguration: S.Schema<GitConfiguration>;
export interface PipelineTriggerDeclaration {
    providerType: PipelineTriggerProviderType;
    gitConfiguration: GitConfiguration;
}
export declare const PipelineTriggerDeclaration: S.Schema<PipelineTriggerDeclaration>;
export type PipelineTriggerDeclarationList = PipelineTriggerDeclaration[];
export declare const PipelineTriggerDeclarationList: any;
export interface PipelineDeclaration {
    name: string;
    roleArn: string;
    artifactStore?: ArtifactStore;
    artifactStores?: {
        [key: string]: ArtifactStore | undefined;
    };
    stages: StageDeclaration[];
    version?: number;
    executionMode?: ExecutionMode;
    pipelineType?: PipelineType;
    variables?: PipelineVariableDeclaration[];
    triggers?: PipelineTriggerDeclaration[];
}
export declare const PipelineDeclaration: S.Schema<PipelineDeclaration>;
export interface CreatePipelineInput {
    pipeline: PipelineDeclaration;
    tags?: Tag[];
}
export declare const CreatePipelineInput: S.Schema<CreatePipelineInput>;
export interface CreatePipelineOutput {
    pipeline?: PipelineDeclaration;
    tags?: Tag[];
}
export declare const CreatePipelineOutput: S.Schema<CreatePipelineOutput>;
export interface DeleteCustomActionTypeInput {
    category: ActionCategory;
    provider: string;
    version: string;
}
export declare const DeleteCustomActionTypeInput: S.Schema<DeleteCustomActionTypeInput>;
export interface DeleteCustomActionTypeResponse {
}
export declare const DeleteCustomActionTypeResponse: S.Schema<DeleteCustomActionTypeResponse>;
export interface DeletePipelineInput {
    name: string;
}
export declare const DeletePipelineInput: S.Schema<DeletePipelineInput>;
export interface DeletePipelineResponse {
}
export declare const DeletePipelineResponse: S.Schema<DeletePipelineResponse>;
export type WebhookName = string;
export interface DeleteWebhookInput {
    name: string;
}
export declare const DeleteWebhookInput: S.Schema<DeleteWebhookInput>;
export interface DeleteWebhookOutput {
}
export declare const DeleteWebhookOutput: S.Schema<DeleteWebhookOutput>;
export interface DeregisterWebhookWithThirdPartyInput {
    webhookName?: string;
}
export declare const DeregisterWebhookWithThirdPartyInput: S.Schema<DeregisterWebhookWithThirdPartyInput>;
export interface DeregisterWebhookWithThirdPartyOutput {
}
export declare const DeregisterWebhookWithThirdPartyOutput: S.Schema<DeregisterWebhookWithThirdPartyOutput>;
export type StageTransitionType = "Inbound" | "Outbound" | (string & {});
export declare const StageTransitionType: any;
export type DisabledReason = string;
export interface DisableStageTransitionInput {
    pipelineName: string;
    stageName: string;
    transitionType: StageTransitionType;
    reason: string;
}
export declare const DisableStageTransitionInput: S.Schema<DisableStageTransitionInput>;
export interface DisableStageTransitionResponse {
}
export declare const DisableStageTransitionResponse: S.Schema<DisableStageTransitionResponse>;
export interface EnableStageTransitionInput {
    pipelineName: string;
    stageName: string;
    transitionType: StageTransitionType;
}
export declare const EnableStageTransitionInput: S.Schema<EnableStageTransitionInput>;
export interface EnableStageTransitionResponse {
}
export declare const EnableStageTransitionResponse: S.Schema<EnableStageTransitionResponse>;
export type ActionTypeOwner = string;
export interface GetActionTypeInput {
    category: ActionCategory;
    owner: string;
    provider: string;
    version: string;
}
export declare const GetActionTypeInput: S.Schema<GetActionTypeInput>;
export type ActionTypeDescription = string;
export type LambdaFunctionArn = string;
export interface LambdaExecutorConfiguration {
    lambdaFunctionArn: string;
}
export declare const LambdaExecutorConfiguration: S.Schema<LambdaExecutorConfiguration>;
export type AccountId = string;
export type PollingAccountList = string[];
export declare const PollingAccountList: any;
export type ServicePrincipal = string;
export type PollingServicePrincipalList = string[];
export declare const PollingServicePrincipalList: any;
export interface JobWorkerExecutorConfiguration {
    pollingAccounts?: string[];
    pollingServicePrincipals?: string[];
}
export declare const JobWorkerExecutorConfiguration: S.Schema<JobWorkerExecutorConfiguration>;
export interface ExecutorConfiguration {
    lambdaExecutorConfiguration?: LambdaExecutorConfiguration;
    jobWorkerExecutorConfiguration?: JobWorkerExecutorConfiguration;
}
export declare const ExecutorConfiguration: S.Schema<ExecutorConfiguration>;
export type ExecutorType = "JobWorker" | "Lambda" | (string & {});
export declare const ExecutorType: any;
export type PolicyStatementsTemplate = string;
export type JobTimeout = number;
export interface ActionTypeExecutor {
    configuration: ExecutorConfiguration;
    type: ExecutorType;
    policyStatementsTemplate?: string;
    jobTimeout?: number;
}
export declare const ActionTypeExecutor: S.Schema<ActionTypeExecutor>;
export interface ActionTypeIdentifier {
    category: ActionCategory;
    owner: string;
    provider: string;
    version: string;
}
export declare const ActionTypeIdentifier: S.Schema<ActionTypeIdentifier>;
export type MinimumActionTypeArtifactCount = number;
export type MaximumActionTypeArtifactCount = number;
export interface ActionTypeArtifactDetails {
    minimumCount: number;
    maximumCount: number;
}
export declare const ActionTypeArtifactDetails: S.Schema<ActionTypeArtifactDetails>;
export type AllowedAccount = string;
export type AllowedAccounts = string[];
export declare const AllowedAccounts: any;
export interface ActionTypePermissions {
    allowedAccounts: string[];
}
export declare const ActionTypePermissions: S.Schema<ActionTypePermissions>;
export type PropertyDescription = string;
export interface ActionTypeProperty {
    name: string;
    optional: boolean;
    key: boolean;
    noEcho: boolean;
    queryable?: boolean;
    description?: string;
}
export declare const ActionTypeProperty: S.Schema<ActionTypeProperty>;
export type ActionTypeProperties = ActionTypeProperty[];
export declare const ActionTypeProperties: any;
export interface ActionTypeUrls {
    configurationUrl?: string;
    entityUrlTemplate?: string;
    executionUrlTemplate?: string;
    revisionUrlTemplate?: string;
}
export declare const ActionTypeUrls: S.Schema<ActionTypeUrls>;
export interface ActionTypeDeclaration {
    description?: string;
    executor: ActionTypeExecutor;
    id: ActionTypeIdentifier;
    inputArtifactDetails: ActionTypeArtifactDetails;
    outputArtifactDetails: ActionTypeArtifactDetails;
    permissions?: ActionTypePermissions;
    properties?: ActionTypeProperty[];
    urls?: ActionTypeUrls;
}
export declare const ActionTypeDeclaration: S.Schema<ActionTypeDeclaration>;
export interface GetActionTypeOutput {
    actionType?: ActionTypeDeclaration;
}
export declare const GetActionTypeOutput: S.Schema<GetActionTypeOutput>;
export interface GetJobDetailsInput {
    jobId: string;
}
export declare const GetJobDetailsInput: S.Schema<GetJobDetailsInput>;
export interface ActionConfiguration {
    configuration?: {
        [key: string]: string | undefined;
    };
}
export declare const ActionConfiguration: S.Schema<ActionConfiguration>;
export interface StageContext {
    name?: string;
}
export declare const StageContext: S.Schema<StageContext>;
export type ActionExecutionId = string;
export interface ActionContext {
    name?: string;
    actionExecutionId?: string;
}
export declare const ActionContext: S.Schema<ActionContext>;
export type PipelineArn = string;
export type PipelineExecutionId = string;
export interface PipelineContext {
    pipelineName?: string;
    stage?: StageContext;
    action?: ActionContext;
    pipelineArn?: string;
    pipelineExecutionId?: string;
}
export declare const PipelineContext: S.Schema<PipelineContext>;
export type Revision = string;
export type ArtifactLocationType = "S3" | (string & {});
export declare const ArtifactLocationType: any;
export type S3BucketName = string;
export type S3ObjectKey = string;
export interface S3ArtifactLocation {
    bucketName: string;
    objectKey: string;
}
export declare const S3ArtifactLocation: S.Schema<S3ArtifactLocation>;
export interface ArtifactLocation {
    type?: ArtifactLocationType;
    s3Location?: S3ArtifactLocation;
}
export declare const ArtifactLocation: S.Schema<ArtifactLocation>;
export interface Artifact {
    name?: string;
    revision?: string;
    location?: ArtifactLocation;
}
export declare const Artifact: S.Schema<Artifact>;
export type ArtifactList = Artifact[];
export declare const ArtifactList: any;
export type AccessKeyId = string | redacted.Redacted<string>;
export type SecretAccessKey = string | redacted.Redacted<string>;
export type SessionToken = string | redacted.Redacted<string>;
export interface AWSSessionCredentials {
    accessKeyId: string | redacted.Redacted<string>;
    secretAccessKey: string | redacted.Redacted<string>;
    sessionToken: string | redacted.Redacted<string>;
}
export declare const AWSSessionCredentials: S.Schema<AWSSessionCredentials>;
export type ContinuationToken = string;
export interface JobData {
    actionTypeId?: ActionTypeId;
    actionConfiguration?: ActionConfiguration;
    pipelineContext?: PipelineContext;
    inputArtifacts?: Artifact[];
    outputArtifacts?: Artifact[];
    artifactCredentials?: AWSSessionCredentials;
    continuationToken?: string;
    encryptionKey?: EncryptionKey;
}
export declare const JobData: S.Schema<JobData>;
export interface JobDetails {
    id?: string;
    data?: JobData;
    accountId?: string;
}
export declare const JobDetails: S.Schema<JobDetails>;
export interface GetJobDetailsOutput {
    jobDetails?: JobDetails;
}
export declare const GetJobDetailsOutput: S.Schema<GetJobDetailsOutput>;
export interface GetPipelineInput {
    name: string;
    version?: number;
}
export declare const GetPipelineInput: S.Schema<GetPipelineInput>;
export interface PipelineMetadata {
    pipelineArn?: string;
    created?: Date;
    updated?: Date;
    pollingDisabledAt?: Date;
}
export declare const PipelineMetadata: S.Schema<PipelineMetadata>;
export interface GetPipelineOutput {
    pipeline?: PipelineDeclaration;
    metadata?: PipelineMetadata;
}
export declare const GetPipelineOutput: S.Schema<GetPipelineOutput>;
export interface GetPipelineExecutionInput {
    pipelineName: string;
    pipelineExecutionId: string;
}
export declare const GetPipelineExecutionInput: S.Schema<GetPipelineExecutionInput>;
export type PipelineExecutionStatus = "Cancelled" | "InProgress" | "Stopped" | "Stopping" | "Succeeded" | "Superseded" | "Failed" | (string & {});
export declare const PipelineExecutionStatus: any;
export type PipelineExecutionStatusSummary = string;
export type RevisionChangeIdentifier = string;
export type RevisionSummary = string;
export interface ArtifactRevision {
    name?: string;
    revisionId?: string;
    revisionChangeIdentifier?: string;
    revisionSummary?: string;
    created?: Date;
    revisionUrl?: string;
}
export declare const ArtifactRevision: S.Schema<ArtifactRevision>;
export type ArtifactRevisionList = ArtifactRevision[];
export declare const ArtifactRevisionList: any;
export interface ResolvedPipelineVariable {
    name?: string;
    resolvedValue?: string;
}
export declare const ResolvedPipelineVariable: S.Schema<ResolvedPipelineVariable>;
export type ResolvedPipelineVariableList = ResolvedPipelineVariable[];
export declare const ResolvedPipelineVariableList: any;
export type TriggerType = "CreatePipeline" | "StartPipelineExecution" | "PollForSourceChanges" | "Webhook" | "CloudWatchEvent" | "PutActionRevision" | "WebhookV2" | "ManualRollback" | "AutomatedRollback" | (string & {});
export declare const TriggerType: any;
export type TriggerDetail = string;
export interface ExecutionTrigger {
    triggerType?: TriggerType;
    triggerDetail?: string;
}
export declare const ExecutionTrigger: S.Schema<ExecutionTrigger>;
export type ExecutionType = "STANDARD" | "ROLLBACK" | (string & {});
export declare const ExecutionType: any;
export interface PipelineRollbackMetadata {
    rollbackTargetPipelineExecutionId?: string;
}
export declare const PipelineRollbackMetadata: S.Schema<PipelineRollbackMetadata>;
export interface PipelineExecution {
    pipelineName?: string;
    pipelineVersion?: number;
    pipelineExecutionId?: string;
    status?: PipelineExecutionStatus;
    statusSummary?: string;
    artifactRevisions?: ArtifactRevision[];
    variables?: ResolvedPipelineVariable[];
    trigger?: ExecutionTrigger;
    executionMode?: ExecutionMode;
    executionType?: ExecutionType;
    rollbackMetadata?: PipelineRollbackMetadata;
}
export declare const PipelineExecution: S.Schema<PipelineExecution>;
export interface GetPipelineExecutionOutput {
    pipelineExecution?: PipelineExecution;
}
export declare const GetPipelineExecutionOutput: S.Schema<GetPipelineExecutionOutput>;
export interface GetPipelineStateInput {
    name: string;
}
export declare const GetPipelineStateInput: S.Schema<GetPipelineStateInput>;
export type StageExecutionStatus = "Cancelled" | "InProgress" | "Failed" | "Stopped" | "Stopping" | "Succeeded" | "Skipped" | (string & {});
export declare const StageExecutionStatus: any;
export interface StageExecution {
    pipelineExecutionId: string;
    status: StageExecutionStatus;
    type?: ExecutionType;
}
export declare const StageExecution: S.Schema<StageExecution>;
export type StageExecutionList = StageExecution[];
export declare const StageExecutionList: any;
export type Enabled = boolean;
export type LastChangedBy = string;
export type LastChangedAt = Date;
export interface TransitionState {
    enabled?: boolean;
    lastChangedBy?: string;
    lastChangedAt?: Date;
    disabledReason?: string;
}
export declare const TransitionState: S.Schema<TransitionState>;
export interface ActionRevision {
    revisionId: string;
    revisionChangeId?: string;
    created?: Date;
}
export declare const ActionRevision: S.Schema<ActionRevision>;
export type ActionExecutionStatus = "InProgress" | "Abandoned" | "Succeeded" | "Failed" | (string & {});
export declare const ActionExecutionStatus: any;
export type ExecutionSummary = string;
export type ActionExecutionToken = string;
export type LastUpdatedBy = string;
export type ExecutionId = string;
export type Percentage = number;
export type Code = string;
export type Message = string;
export interface ErrorDetails {
    code?: string;
    message?: string;
}
export declare const ErrorDetails: S.Schema<ErrorDetails>;
export type LogStreamARN = string;
export interface ActionExecution {
    actionExecutionId?: string;
    status?: ActionExecutionStatus;
    summary?: string;
    lastStatusChange?: Date;
    token?: string;
    lastUpdatedBy?: string;
    externalExecutionId?: string;
    externalExecutionUrl?: string;
    percentComplete?: number;
    errorDetails?: ErrorDetails;
    logStreamARN?: string;
}
export declare const ActionExecution: S.Schema<ActionExecution>;
export interface ActionState {
    actionName?: string;
    currentRevision?: ActionRevision;
    latestExecution?: ActionExecution;
    entityUrl?: string;
    revisionUrl?: string;
}
export declare const ActionState: S.Schema<ActionState>;
export type ActionStateList = ActionState[];
export declare const ActionStateList: any;
export type ConditionExecutionStatus = "InProgress" | "Failed" | "Errored" | "Succeeded" | "Cancelled" | "Abandoned" | "Overridden" | (string & {});
export declare const ConditionExecutionStatus: any;
export interface StageConditionsExecution {
    status?: ConditionExecutionStatus;
    summary?: string;
}
export declare const StageConditionsExecution: S.Schema<StageConditionsExecution>;
export interface ConditionExecution {
    status?: ConditionExecutionStatus;
    summary?: string;
    lastStatusChange?: Date;
}
export declare const ConditionExecution: S.Schema<ConditionExecution>;
export interface RuleRevision {
    revisionId: string;
    revisionChangeId?: string;
    created?: Date;
}
export declare const RuleRevision: S.Schema<RuleRevision>;
export type RuleExecutionId = string;
export type RuleExecutionStatus = "InProgress" | "Abandoned" | "Succeeded" | "Failed" | (string & {});
export declare const RuleExecutionStatus: any;
export type RuleExecutionToken = string;
export interface RuleExecution {
    ruleExecutionId?: string;
    status?: RuleExecutionStatus;
    summary?: string;
    lastStatusChange?: Date;
    token?: string;
    lastUpdatedBy?: string;
    externalExecutionId?: string;
    externalExecutionUrl?: string;
    errorDetails?: ErrorDetails;
}
export declare const RuleExecution: S.Schema<RuleExecution>;
export interface RuleState {
    ruleName?: string;
    currentRevision?: RuleRevision;
    latestExecution?: RuleExecution;
    entityUrl?: string;
    revisionUrl?: string;
}
export declare const RuleState: S.Schema<RuleState>;
export type RuleStateList = RuleState[];
export declare const RuleStateList: any;
export interface ConditionState {
    latestExecution?: ConditionExecution;
    ruleStates?: RuleState[];
}
export declare const ConditionState: S.Schema<ConditionState>;
export type ConditionStateList = ConditionState[];
export declare const ConditionStateList: any;
export interface StageConditionState {
    latestExecution?: StageConditionsExecution;
    conditionStates?: ConditionState[];
}
export declare const StageConditionState: S.Schema<StageConditionState>;
export type RetryAttempt = number;
export type RetryTrigger = "AutomatedStageRetry" | "ManualStageRetry" | (string & {});
export declare const RetryTrigger: any;
export interface RetryStageMetadata {
    autoStageRetryAttempt?: number;
    manualStageRetryAttempt?: number;
    latestRetryTrigger?: RetryTrigger;
}
export declare const RetryStageMetadata: S.Schema<RetryStageMetadata>;
export interface StageState {
    stageName?: string;
    inboundExecution?: StageExecution;
    inboundExecutions?: StageExecution[];
    inboundTransitionState?: TransitionState;
    actionStates?: ActionState[];
    latestExecution?: StageExecution;
    beforeEntryConditionState?: StageConditionState;
    onSuccessConditionState?: StageConditionState;
    onFailureConditionState?: StageConditionState;
    retryStageMetadata?: RetryStageMetadata;
}
export declare const StageState: S.Schema<StageState>;
export type StageStateList = StageState[];
export declare const StageStateList: any;
export interface GetPipelineStateOutput {
    pipelineName?: string;
    pipelineVersion?: number;
    stageStates?: StageState[];
    created?: Date;
    updated?: Date;
}
export declare const GetPipelineStateOutput: S.Schema<GetPipelineStateOutput>;
export interface GetThirdPartyJobDetailsInput {
    jobId: string;
    clientToken: string;
}
export declare const GetThirdPartyJobDetailsInput: S.Schema<GetThirdPartyJobDetailsInput>;
export interface ThirdPartyJobData {
    actionTypeId?: ActionTypeId;
    actionConfiguration?: ActionConfiguration;
    pipelineContext?: PipelineContext;
    inputArtifacts?: Artifact[];
    outputArtifacts?: Artifact[];
    artifactCredentials?: AWSSessionCredentials;
    continuationToken?: string;
    encryptionKey?: EncryptionKey;
}
export declare const ThirdPartyJobData: S.Schema<ThirdPartyJobData>;
export interface ThirdPartyJobDetails {
    id?: string;
    data?: ThirdPartyJobData;
    nonce?: string;
}
export declare const ThirdPartyJobDetails: S.Schema<ThirdPartyJobDetails>;
export interface GetThirdPartyJobDetailsOutput {
    jobDetails?: ThirdPartyJobDetails;
}
export declare const GetThirdPartyJobDetailsOutput: S.Schema<GetThirdPartyJobDetailsOutput>;
export type StartTimeRange = "Latest" | "All" | (string & {});
export declare const StartTimeRange: any;
export interface LatestInPipelineExecutionFilter {
    pipelineExecutionId: string;
    startTimeRange: StartTimeRange;
}
export declare const LatestInPipelineExecutionFilter: S.Schema<LatestInPipelineExecutionFilter>;
export interface ActionExecutionFilter {
    pipelineExecutionId?: string;
    latestInPipelineExecution?: LatestInPipelineExecutionFilter;
}
export declare const ActionExecutionFilter: S.Schema<ActionExecutionFilter>;
export type MaxResults = number;
export type NextToken = string;
export interface ListActionExecutionsInput {
    pipelineName: string;
    filter?: ActionExecutionFilter;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListActionExecutionsInput: S.Schema<ListActionExecutionsInput>;
export type ResolvedActionConfigurationMap = {
    [key: string]: string | undefined;
};
export declare const ResolvedActionConfigurationMap: any;
export type S3Bucket = string;
export type S3Key = string;
export interface S3Location {
    bucket?: string;
    key?: string;
}
export declare const S3Location: S.Schema<S3Location>;
export interface ArtifactDetail {
    name?: string;
    s3location?: S3Location;
}
export declare const ArtifactDetail: S.Schema<ArtifactDetail>;
export type ArtifactDetailList = ArtifactDetail[];
export declare const ArtifactDetailList: any;
export interface ActionExecutionInput {
    actionTypeId?: ActionTypeId;
    configuration?: {
        [key: string]: string | undefined;
    };
    resolvedConfiguration?: {
        [key: string]: string | undefined;
    };
    roleArn?: string;
    region?: string;
    inputArtifacts?: ArtifactDetail[];
    namespace?: string;
}
export declare const ActionExecutionInput: S.Schema<ActionExecutionInput>;
export type ExternalExecutionId = string;
export type ExternalExecutionSummary = string;
export interface ActionExecutionResult {
    externalExecutionId?: string;
    externalExecutionSummary?: string;
    externalExecutionUrl?: string;
    errorDetails?: ErrorDetails;
    logStreamARN?: string;
}
export declare const ActionExecutionResult: S.Schema<ActionExecutionResult>;
export type OutputVariablesKey = string;
export type OutputVariablesValue = string;
export type OutputVariablesMap = {
    [key: string]: string | undefined;
};
export declare const OutputVariablesMap: any;
export interface ActionExecutionOutput {
    outputArtifacts?: ArtifactDetail[];
    executionResult?: ActionExecutionResult;
    outputVariables?: {
        [key: string]: string | undefined;
    };
}
export declare const ActionExecutionOutput: S.Schema<ActionExecutionOutput>;
export interface ActionExecutionDetail {
    pipelineExecutionId?: string;
    actionExecutionId?: string;
    pipelineVersion?: number;
    stageName?: string;
    actionName?: string;
    startTime?: Date;
    lastUpdateTime?: Date;
    updatedBy?: string;
    status?: ActionExecutionStatus;
    input?: ActionExecutionInput;
    output?: ActionExecutionOutput;
}
export declare const ActionExecutionDetail: S.Schema<ActionExecutionDetail>;
export type ActionExecutionDetailList = ActionExecutionDetail[];
export declare const ActionExecutionDetailList: any;
export interface ListActionExecutionsOutput {
    actionExecutionDetails?: ActionExecutionDetail[];
    nextToken?: string;
}
export declare const ListActionExecutionsOutput: S.Schema<ListActionExecutionsOutput>;
export interface ListActionTypesInput {
    actionOwnerFilter?: ActionOwner;
    nextToken?: string;
    regionFilter?: string;
}
export declare const ListActionTypesInput: S.Schema<ListActionTypesInput>;
export type ActionTypeList = ActionType[];
export declare const ActionTypeList: any;
export interface ListActionTypesOutput {
    actionTypes: ActionType[];
    nextToken?: string;
}
export declare const ListActionTypesOutput: S.Schema<ListActionTypesOutput>;
export type TargetFilterName = "TARGET_STATUS" | (string & {});
export declare const TargetFilterName: any;
export type TargetFilterValue = string;
export type TargetFilterValueList = string[];
export declare const TargetFilterValueList: any;
export interface TargetFilter {
    name?: TargetFilterName;
    values?: string[];
}
export declare const TargetFilter: S.Schema<TargetFilter>;
export type TargetFilterList = TargetFilter[];
export declare const TargetFilterList: any;
export interface ListDeployActionExecutionTargetsInput {
    pipelineName?: string;
    actionExecutionId: string;
    filters?: TargetFilter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDeployActionExecutionTargetsInput: S.Schema<ListDeployActionExecutionTargetsInput>;
export interface DeployTargetEventContext {
    ssmCommandId?: string;
    message?: string;
}
export declare const DeployTargetEventContext: S.Schema<DeployTargetEventContext>;
export interface DeployTargetEvent {
    name?: string;
    status?: string;
    startTime?: Date;
    endTime?: Date;
    context?: DeployTargetEventContext;
}
export declare const DeployTargetEvent: S.Schema<DeployTargetEvent>;
export type DeployTargetEventList = DeployTargetEvent[];
export declare const DeployTargetEventList: any;
export interface DeployActionExecutionTarget {
    targetId?: string;
    targetType?: string;
    status?: string;
    startTime?: Date;
    endTime?: Date;
    events?: DeployTargetEvent[];
}
export declare const DeployActionExecutionTarget: S.Schema<DeployActionExecutionTarget>;
export type DeployActionExecutionTargetList = DeployActionExecutionTarget[];
export declare const DeployActionExecutionTargetList: any;
export interface ListDeployActionExecutionTargetsOutput {
    targets?: DeployActionExecutionTarget[];
    nextToken?: string;
}
export declare const ListDeployActionExecutionTargetsOutput: S.Schema<ListDeployActionExecutionTargetsOutput>;
export interface SucceededInStageFilter {
    stageName?: string;
}
export declare const SucceededInStageFilter: S.Schema<SucceededInStageFilter>;
export interface PipelineExecutionFilter {
    succeededInStage?: SucceededInStageFilter;
}
export declare const PipelineExecutionFilter: S.Schema<PipelineExecutionFilter>;
export interface ListPipelineExecutionsInput {
    pipelineName: string;
    maxResults?: number;
    filter?: PipelineExecutionFilter;
    nextToken?: string;
}
export declare const ListPipelineExecutionsInput: S.Schema<ListPipelineExecutionsInput>;
export interface SourceRevision {
    actionName: string;
    revisionId?: string;
    revisionSummary?: string;
    revisionUrl?: string;
}
export declare const SourceRevision: S.Schema<SourceRevision>;
export type SourceRevisionList = SourceRevision[];
export declare const SourceRevisionList: any;
export type StopPipelineExecutionReason = string;
export interface StopExecutionTrigger {
    reason?: string;
}
export declare const StopExecutionTrigger: S.Schema<StopExecutionTrigger>;
export interface PipelineExecutionSummary {
    pipelineExecutionId?: string;
    status?: PipelineExecutionStatus;
    statusSummary?: string;
    startTime?: Date;
    lastUpdateTime?: Date;
    sourceRevisions?: SourceRevision[];
    trigger?: ExecutionTrigger;
    stopTrigger?: StopExecutionTrigger;
    executionMode?: ExecutionMode;
    executionType?: ExecutionType;
    rollbackMetadata?: PipelineRollbackMetadata;
}
export declare const PipelineExecutionSummary: S.Schema<PipelineExecutionSummary>;
export type PipelineExecutionSummaryList = PipelineExecutionSummary[];
export declare const PipelineExecutionSummaryList: any;
export interface ListPipelineExecutionsOutput {
    pipelineExecutionSummaries?: PipelineExecutionSummary[];
    nextToken?: string;
}
export declare const ListPipelineExecutionsOutput: S.Schema<ListPipelineExecutionsOutput>;
export type MaxPipelines = number;
export interface ListPipelinesInput {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPipelinesInput: S.Schema<ListPipelinesInput>;
export interface PipelineSummary {
    name?: string;
    version?: number;
    pipelineType?: PipelineType;
    executionMode?: ExecutionMode;
    created?: Date;
    updated?: Date;
}
export declare const PipelineSummary: S.Schema<PipelineSummary>;
export type PipelineList = PipelineSummary[];
export declare const PipelineList: any;
export interface ListPipelinesOutput {
    pipelines?: PipelineSummary[];
    nextToken?: string;
}
export declare const ListPipelinesOutput: S.Schema<ListPipelinesOutput>;
export interface RuleExecutionFilter {
    pipelineExecutionId?: string;
    latestInPipelineExecution?: LatestInPipelineExecutionFilter;
}
export declare const RuleExecutionFilter: S.Schema<RuleExecutionFilter>;
export interface ListRuleExecutionsInput {
    pipelineName: string;
    filter?: RuleExecutionFilter;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRuleExecutionsInput: S.Schema<ListRuleExecutionsInput>;
export type ResolvedRuleConfigurationMap = {
    [key: string]: string | undefined;
};
export declare const ResolvedRuleConfigurationMap: any;
export interface RuleExecutionInput {
    ruleTypeId?: RuleTypeId;
    configuration?: {
        [key: string]: string | undefined;
    };
    resolvedConfiguration?: {
        [key: string]: string | undefined;
    };
    roleArn?: string;
    region?: string;
    inputArtifacts?: ArtifactDetail[];
}
export declare const RuleExecutionInput: S.Schema<RuleExecutionInput>;
export interface RuleExecutionResult {
    externalExecutionId?: string;
    externalExecutionSummary?: string;
    externalExecutionUrl?: string;
    errorDetails?: ErrorDetails;
}
export declare const RuleExecutionResult: S.Schema<RuleExecutionResult>;
export interface RuleExecutionOutput {
    executionResult?: RuleExecutionResult;
}
export declare const RuleExecutionOutput: S.Schema<RuleExecutionOutput>;
export interface RuleExecutionDetail {
    pipelineExecutionId?: string;
    ruleExecutionId?: string;
    pipelineVersion?: number;
    stageName?: string;
    ruleName?: string;
    startTime?: Date;
    lastUpdateTime?: Date;
    updatedBy?: string;
    status?: RuleExecutionStatus;
    input?: RuleExecutionInput;
    output?: RuleExecutionOutput;
}
export declare const RuleExecutionDetail: S.Schema<RuleExecutionDetail>;
export type RuleExecutionDetailList = RuleExecutionDetail[];
export declare const RuleExecutionDetailList: any;
export interface ListRuleExecutionsOutput {
    ruleExecutionDetails?: RuleExecutionDetail[];
    nextToken?: string;
}
export declare const ListRuleExecutionsOutput: S.Schema<ListRuleExecutionsOutput>;
export interface ListRuleTypesInput {
    ruleOwnerFilter?: RuleOwner;
    regionFilter?: string;
}
export declare const ListRuleTypesInput: S.Schema<ListRuleTypesInput>;
export interface RuleTypeSettings {
    thirdPartyConfigurationUrl?: string;
    entityUrlTemplate?: string;
    executionUrlTemplate?: string;
    revisionUrlTemplate?: string;
}
export declare const RuleTypeSettings: S.Schema<RuleTypeSettings>;
export type RuleConfigurationPropertyType = "String" | "Number" | "Boolean" | (string & {});
export declare const RuleConfigurationPropertyType: any;
export interface RuleConfigurationProperty {
    name: string;
    required: boolean;
    key: boolean;
    secret: boolean;
    queryable?: boolean;
    description?: string;
    type?: RuleConfigurationPropertyType;
}
export declare const RuleConfigurationProperty: S.Schema<RuleConfigurationProperty>;
export type RuleConfigurationPropertyList = RuleConfigurationProperty[];
export declare const RuleConfigurationPropertyList: any;
export interface RuleType {
    id: RuleTypeId;
    settings?: RuleTypeSettings;
    ruleConfigurationProperties?: RuleConfigurationProperty[];
    inputArtifactDetails: ArtifactDetails;
}
export declare const RuleType: S.Schema<RuleType>;
export type RuleTypeList = RuleType[];
export declare const RuleTypeList: any;
export interface ListRuleTypesOutput {
    ruleTypes: RuleType[];
}
export declare const ListRuleTypesOutput: S.Schema<ListRuleTypesOutput>;
export type ResourceArn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListTagsForResourceInput: S.Schema<ListTagsForResourceInput>;
export interface ListTagsForResourceOutput {
    tags?: Tag[];
    nextToken?: string;
}
export declare const ListTagsForResourceOutput: S.Schema<ListTagsForResourceOutput>;
export interface ListWebhooksInput {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListWebhooksInput: S.Schema<ListWebhooksInput>;
export type JsonPath = string;
export type MatchEquals = string;
export interface WebhookFilterRule {
    jsonPath: string;
    matchEquals?: string;
}
export declare const WebhookFilterRule: S.Schema<WebhookFilterRule>;
export type WebhookFilters = WebhookFilterRule[];
export declare const WebhookFilters: any;
export type WebhookAuthenticationType = "GITHUB_HMAC" | "IP" | "UNAUTHENTICATED" | (string & {});
export declare const WebhookAuthenticationType: any;
export type WebhookAuthConfigurationAllowedIPRange = string;
export type WebhookAuthConfigurationSecretToken = string;
export interface WebhookAuthConfiguration {
    AllowedIPRange?: string;
    SecretToken?: string | redacted.Redacted<string>;
}
export declare const WebhookAuthConfiguration: S.Schema<WebhookAuthConfiguration>;
export interface WebhookDefinition {
    name: string;
    targetPipeline: string;
    targetAction: string;
    filters: WebhookFilterRule[];
    authentication: WebhookAuthenticationType;
    authenticationConfiguration: WebhookAuthConfiguration;
}
export declare const WebhookDefinition: S.Schema<WebhookDefinition>;
export type WebhookUrl = string;
export type WebhookErrorMessage = string;
export type WebhookErrorCode = string;
export type WebhookLastTriggered = Date;
export type WebhookArn = string;
export interface ListWebhookItem {
    definition: WebhookDefinition;
    url: string;
    errorMessage?: string;
    errorCode?: string;
    lastTriggered?: Date;
    arn?: string;
    tags?: Tag[];
}
export declare const ListWebhookItem: S.Schema<ListWebhookItem>;
export type WebhookList = ListWebhookItem[];
export declare const WebhookList: any;
export interface ListWebhooksOutput {
    webhooks?: ListWebhookItem[];
    NextToken?: string;
}
export declare const ListWebhooksOutput: S.Schema<ListWebhooksOutput>;
export type ConditionType = "BEFORE_ENTRY" | "ON_SUCCESS" | (string & {});
export declare const ConditionType: any;
export interface OverrideStageConditionInput {
    pipelineName: string;
    stageName: string;
    pipelineExecutionId: string;
    conditionType: ConditionType;
}
export declare const OverrideStageConditionInput: S.Schema<OverrideStageConditionInput>;
export interface OverrideStageConditionResponse {
}
export declare const OverrideStageConditionResponse: S.Schema<OverrideStageConditionResponse>;
export type MaxBatchSize = number;
export type ActionConfigurationQueryableValue = string;
export type QueryParamMap = {
    [key: string]: string | undefined;
};
export declare const QueryParamMap: any;
export interface PollForJobsInput {
    actionTypeId: ActionTypeId;
    maxBatchSize?: number;
    queryParam?: {
        [key: string]: string | undefined;
    };
}
export declare const PollForJobsInput: S.Schema<PollForJobsInput>;
export interface Job {
    id?: string;
    data?: JobData;
    nonce?: string;
    accountId?: string;
}
export declare const Job: S.Schema<Job>;
export type JobList = Job[];
export declare const JobList: any;
export interface PollForJobsOutput {
    jobs?: Job[];
}
export declare const PollForJobsOutput: S.Schema<PollForJobsOutput>;
export interface PollForThirdPartyJobsInput {
    actionTypeId: ActionTypeId;
    maxBatchSize?: number;
}
export declare const PollForThirdPartyJobsInput: S.Schema<PollForThirdPartyJobsInput>;
export type ClientId = string;
export interface ThirdPartyJob {
    clientId?: string;
    jobId?: string;
}
export declare const ThirdPartyJob: S.Schema<ThirdPartyJob>;
export type ThirdPartyJobList = ThirdPartyJob[];
export declare const ThirdPartyJobList: any;
export interface PollForThirdPartyJobsOutput {
    jobs?: ThirdPartyJob[];
}
export declare const PollForThirdPartyJobsOutput: S.Schema<PollForThirdPartyJobsOutput>;
export interface PutActionRevisionInput {
    pipelineName: string;
    stageName: string;
    actionName: string;
    actionRevision: ActionRevision;
}
export declare const PutActionRevisionInput: S.Schema<PutActionRevisionInput>;
export interface PutActionRevisionOutput {
    newRevision?: boolean;
    pipelineExecutionId?: string;
}
export declare const PutActionRevisionOutput: S.Schema<PutActionRevisionOutput>;
export type ApprovalSummary = string;
export type ApprovalStatus = "Approved" | "Rejected" | (string & {});
export declare const ApprovalStatus: any;
export interface ApprovalResult {
    summary: string;
    status: ApprovalStatus;
}
export declare const ApprovalResult: S.Schema<ApprovalResult>;
export type ApprovalToken = string;
export interface PutApprovalResultInput {
    pipelineName: string;
    stageName: string;
    actionName: string;
    result: ApprovalResult;
    token: string;
}
export declare const PutApprovalResultInput: S.Schema<PutApprovalResultInput>;
export interface PutApprovalResultOutput {
    approvedAt?: Date;
}
export declare const PutApprovalResultOutput: S.Schema<PutApprovalResultOutput>;
export type FailureType = "JobFailed" | "ConfigurationError" | "PermissionError" | "RevisionOutOfSync" | "RevisionUnavailable" | "SystemUnavailable" | (string & {});
export declare const FailureType: any;
export interface FailureDetails {
    type: FailureType;
    message: string;
    externalExecutionId?: string;
}
export declare const FailureDetails: S.Schema<FailureDetails>;
export interface PutJobFailureResultInput {
    jobId: string;
    failureDetails: FailureDetails;
}
export declare const PutJobFailureResultInput: S.Schema<PutJobFailureResultInput>;
export interface PutJobFailureResultResponse {
}
export declare const PutJobFailureResultResponse: S.Schema<PutJobFailureResultResponse>;
export interface CurrentRevision {
    revision: string;
    changeIdentifier: string;
    created?: Date;
    revisionSummary?: string;
}
export declare const CurrentRevision: S.Schema<CurrentRevision>;
export interface ExecutionDetails {
    summary?: string;
    externalExecutionId?: string;
    percentComplete?: number;
}
export declare const ExecutionDetails: S.Schema<ExecutionDetails>;
export interface PutJobSuccessResultInput {
    jobId: string;
    currentRevision?: CurrentRevision;
    continuationToken?: string;
    executionDetails?: ExecutionDetails;
    outputVariables?: {
        [key: string]: string | undefined;
    };
}
export declare const PutJobSuccessResultInput: S.Schema<PutJobSuccessResultInput>;
export interface PutJobSuccessResultResponse {
}
export declare const PutJobSuccessResultResponse: S.Schema<PutJobSuccessResultResponse>;
export interface PutThirdPartyJobFailureResultInput {
    jobId: string;
    clientToken: string;
    failureDetails: FailureDetails;
}
export declare const PutThirdPartyJobFailureResultInput: S.Schema<PutThirdPartyJobFailureResultInput>;
export interface PutThirdPartyJobFailureResultResponse {
}
export declare const PutThirdPartyJobFailureResultResponse: S.Schema<PutThirdPartyJobFailureResultResponse>;
export interface PutThirdPartyJobSuccessResultInput {
    jobId: string;
    clientToken: string;
    currentRevision?: CurrentRevision;
    continuationToken?: string;
    executionDetails?: ExecutionDetails;
}
export declare const PutThirdPartyJobSuccessResultInput: S.Schema<PutThirdPartyJobSuccessResultInput>;
export interface PutThirdPartyJobSuccessResultResponse {
}
export declare const PutThirdPartyJobSuccessResultResponse: S.Schema<PutThirdPartyJobSuccessResultResponse>;
export interface PutWebhookInput {
    webhook: WebhookDefinition;
    tags?: Tag[];
}
export declare const PutWebhookInput: S.Schema<PutWebhookInput>;
export interface PutWebhookOutput {
    webhook?: ListWebhookItem;
}
export declare const PutWebhookOutput: S.Schema<PutWebhookOutput>;
export interface RegisterWebhookWithThirdPartyInput {
    webhookName?: string;
}
export declare const RegisterWebhookWithThirdPartyInput: S.Schema<RegisterWebhookWithThirdPartyInput>;
export interface RegisterWebhookWithThirdPartyOutput {
}
export declare const RegisterWebhookWithThirdPartyOutput: S.Schema<RegisterWebhookWithThirdPartyOutput>;
export interface RetryStageExecutionInput {
    pipelineName: string;
    stageName: string;
    pipelineExecutionId: string;
    retryMode: StageRetryMode;
}
export declare const RetryStageExecutionInput: S.Schema<RetryStageExecutionInput>;
export interface RetryStageExecutionOutput {
    pipelineExecutionId?: string;
}
export declare const RetryStageExecutionOutput: S.Schema<RetryStageExecutionOutput>;
export interface RollbackStageInput {
    pipelineName: string;
    stageName: string;
    targetPipelineExecutionId: string;
}
export declare const RollbackStageInput: S.Schema<RollbackStageInput>;
export interface RollbackStageOutput {
    pipelineExecutionId: string;
}
export declare const RollbackStageOutput: S.Schema<RollbackStageOutput>;
export interface PipelineVariable {
    name: string;
    value: string;
}
export declare const PipelineVariable: S.Schema<PipelineVariable>;
export type PipelineVariableList = PipelineVariable[];
export declare const PipelineVariableList: any;
export type ClientRequestToken = string;
export type SourceRevisionType = "COMMIT_ID" | "IMAGE_DIGEST" | "S3_OBJECT_VERSION_ID" | "S3_OBJECT_KEY" | (string & {});
export declare const SourceRevisionType: any;
export interface SourceRevisionOverride {
    actionName: string;
    revisionType: SourceRevisionType;
    revisionValue: string;
}
export declare const SourceRevisionOverride: S.Schema<SourceRevisionOverride>;
export type SourceRevisionOverrideList = SourceRevisionOverride[];
export declare const SourceRevisionOverrideList: any;
export interface StartPipelineExecutionInput {
    name: string;
    variables?: PipelineVariable[];
    clientRequestToken?: string;
    sourceRevisions?: SourceRevisionOverride[];
}
export declare const StartPipelineExecutionInput: S.Schema<StartPipelineExecutionInput>;
export interface StartPipelineExecutionOutput {
    pipelineExecutionId?: string;
}
export declare const StartPipelineExecutionOutput: S.Schema<StartPipelineExecutionOutput>;
export interface StopPipelineExecutionInput {
    pipelineName: string;
    pipelineExecutionId: string;
    abandon?: boolean;
    reason?: string;
}
export declare const StopPipelineExecutionInput: S.Schema<StopPipelineExecutionInput>;
export interface StopPipelineExecutionOutput {
    pipelineExecutionId?: string;
}
export declare const StopPipelineExecutionOutput: S.Schema<StopPipelineExecutionOutput>;
export interface TagResourceInput {
    resourceArn: string;
    tags: Tag[];
}
export declare const TagResourceInput: S.Schema<TagResourceInput>;
export interface TagResourceOutput {
}
export declare const TagResourceOutput: S.Schema<TagResourceOutput>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceInput: S.Schema<UntagResourceInput>;
export interface UntagResourceOutput {
}
export declare const UntagResourceOutput: S.Schema<UntagResourceOutput>;
export interface UpdateActionTypeInput {
    actionType: ActionTypeDeclaration;
}
export declare const UpdateActionTypeInput: S.Schema<UpdateActionTypeInput>;
export interface UpdateActionTypeResponse {
}
export declare const UpdateActionTypeResponse: S.Schema<UpdateActionTypeResponse>;
export interface UpdatePipelineInput {
    pipeline: PipelineDeclaration;
}
export declare const UpdatePipelineInput: S.Schema<UpdatePipelineInput>;
export interface UpdatePipelineOutput {
    pipeline?: PipelineDeclaration;
}
export declare const UpdatePipelineOutput: S.Schema<UpdatePipelineOutput>;
export type AcknowledgeJobError = InvalidNonceException | JobNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a specified job and whether that job has been received by
 * the job worker. Used for custom actions only.
 */
export declare const acknowledgeJob: API.OperationMethod<AcknowledgeJobInput, AcknowledgeJobOutput, AcknowledgeJobError, Credentials | HttpClient.HttpClient>;
export type AcknowledgeThirdPartyJobError = InvalidClientTokenException | InvalidNonceException | JobNotFoundException | ValidationException | CommonErrors;
/**
 * Confirms a job worker has received the specified job. Used for partner actions
 * only.
 */
export declare const acknowledgeThirdPartyJob: API.OperationMethod<AcknowledgeThirdPartyJobInput, AcknowledgeThirdPartyJobOutput, AcknowledgeThirdPartyJobError, Credentials | HttpClient.HttpClient>;
export type CreateCustomActionTypeError = ConcurrentModificationException | InvalidTagsException | LimitExceededException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a new custom action that can be used in all pipelines associated with the
 * Amazon Web Services account. Only used for custom actions.
 */
export declare const createCustomActionType: API.OperationMethod<CreateCustomActionTypeInput, CreateCustomActionTypeOutput, CreateCustomActionTypeError, Credentials | HttpClient.HttpClient>;
export type CreatePipelineError = ConcurrentModificationException | InvalidActionDeclarationException | InvalidBlockerDeclarationException | InvalidStageDeclarationException | InvalidStructureException | InvalidTagsException | LimitExceededException | PipelineNameInUseException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a pipeline.
 *
 * In the pipeline structure, you must include either `artifactStore`
 * or `artifactStores` in your pipeline, but you cannot use both. If you
 * create a cross-region action in your pipeline, you must use
 * `artifactStores`.
 */
export declare const createPipeline: API.OperationMethod<CreatePipelineInput, CreatePipelineOutput, CreatePipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomActionTypeError = ConcurrentModificationException | ValidationException | CommonErrors;
/**
 * Marks a custom action as deleted. `PollForJobs` for the custom action
 * fails after the action is marked for deletion. Used for custom actions only.
 *
 * To re-create a custom action after it has been deleted you must use a string in
 * the version field that has never been used before. This string can be an incremented
 * version number, for example. To restore a deleted custom action, use a JSON file
 * that is identical to the deleted action, including the original string in the
 * version field.
 */
export declare const deleteCustomActionType: API.OperationMethod<DeleteCustomActionTypeInput, DeleteCustomActionTypeResponse, DeleteCustomActionTypeError, Credentials | HttpClient.HttpClient>;
export type DeletePipelineError = ConcurrentModificationException | ValidationException | CommonErrors;
/**
 * Deletes the specified pipeline.
 */
export declare const deletePipeline: API.OperationMethod<DeletePipelineInput, DeletePipelineResponse, DeletePipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteWebhookError = ConcurrentModificationException | ValidationException | CommonErrors;
/**
 * Deletes a previously created webhook by name. Deleting the webhook stops CodePipeline from starting a pipeline every time an external event occurs. The API
 * returns successfully when trying to delete a webhook that is already deleted. If a
 * deleted webhook is re-created by calling PutWebhook with the same name, it will have a
 * different URL.
 */
export declare const deleteWebhook: API.OperationMethod<DeleteWebhookInput, DeleteWebhookOutput, DeleteWebhookError, Credentials | HttpClient.HttpClient>;
export type DeregisterWebhookWithThirdPartyError = ValidationException | WebhookNotFoundException | CommonErrors;
/**
 * Removes the connection between the webhook that was created by CodePipeline
 * and the external tool with events to be detected. Currently supported only for webhooks
 * that target an action type of GitHub.
 */
export declare const deregisterWebhookWithThirdParty: API.OperationMethod<DeregisterWebhookWithThirdPartyInput, DeregisterWebhookWithThirdPartyOutput, DeregisterWebhookWithThirdPartyError, Credentials | HttpClient.HttpClient>;
export type DisableStageTransitionError = PipelineNotFoundException | StageNotFoundException | ValidationException | CommonErrors;
/**
 * Prevents artifacts in a pipeline from transitioning to the next stage in the
 * pipeline.
 */
export declare const disableStageTransition: API.OperationMethod<DisableStageTransitionInput, DisableStageTransitionResponse, DisableStageTransitionError, Credentials | HttpClient.HttpClient>;
export type EnableStageTransitionError = PipelineNotFoundException | StageNotFoundException | ValidationException | CommonErrors;
/**
 * Enables artifacts in a pipeline to transition to a stage in a pipeline.
 */
export declare const enableStageTransition: API.OperationMethod<EnableStageTransitionInput, EnableStageTransitionResponse, EnableStageTransitionError, Credentials | HttpClient.HttpClient>;
export type GetActionTypeError = ActionTypeNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about an action type created for an external provider, where the
 * action is to be used by customers of the external provider. The action can be created
 * with any supported integration model.
 */
export declare const getActionType: API.OperationMethod<GetActionTypeInput, GetActionTypeOutput, GetActionTypeError, Credentials | HttpClient.HttpClient>;
export type GetJobDetailsError = JobNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a job. Used for custom actions only.
 *
 * When this API is called, CodePipeline returns temporary credentials for
 * the S3 bucket used to store artifacts for the pipeline, if the action requires
 * access to that S3 bucket for input or output artifacts. This API also returns any
 * secret values defined for the action.
 */
export declare const getJobDetails: API.OperationMethod<GetJobDetailsInput, GetJobDetailsOutput, GetJobDetailsError, Credentials | HttpClient.HttpClient>;
export type GetPipelineError = PipelineNotFoundException | PipelineVersionNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the metadata, structure, stages, and actions of a pipeline. Can be used to
 * return the entire structure of a pipeline in JSON format, which can then be modified and
 * used to update the pipeline structure with UpdatePipeline.
 */
export declare const getPipeline: API.OperationMethod<GetPipelineInput, GetPipelineOutput, GetPipelineError, Credentials | HttpClient.HttpClient>;
export type GetPipelineExecutionError = PipelineExecutionNotFoundException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about an execution of a pipeline, including details about
 * artifacts, the pipeline execution ID, and the name, version, and status of the
 * pipeline.
 */
export declare const getPipelineExecution: API.OperationMethod<GetPipelineExecutionInput, GetPipelineExecutionOutput, GetPipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type GetPipelineStateError = PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about the state of a pipeline, including the stages and
 * actions.
 *
 * Values returned in the `revisionId` and `revisionUrl`
 * fields indicate the source revision information, such as the commit ID, for the
 * current state.
 */
export declare const getPipelineState: API.OperationMethod<GetPipelineStateInput, GetPipelineStateOutput, GetPipelineStateError, Credentials | HttpClient.HttpClient>;
export type GetThirdPartyJobDetailsError = InvalidClientTokenException | InvalidJobException | JobNotFoundException | ValidationException | CommonErrors;
/**
 * Requests the details of a job for a third party action. Used for partner actions
 * only.
 *
 * When this API is called, CodePipeline returns temporary credentials for
 * the S3 bucket used to store artifacts for the pipeline, if the action requires
 * access to that S3 bucket for input or output artifacts. This API also returns any
 * secret values defined for the action.
 */
export declare const getThirdPartyJobDetails: API.OperationMethod<GetThirdPartyJobDetailsInput, GetThirdPartyJobDetailsOutput, GetThirdPartyJobDetailsError, Credentials | HttpClient.HttpClient>;
export type ListActionExecutionsError = InvalidNextTokenException | PipelineExecutionNotFoundException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the action executions that have occurred in a pipeline.
 */
export declare const listActionExecutions: API.PaginatedOperationMethod<ListActionExecutionsInput, ListActionExecutionsOutput, ListActionExecutionsError, Credentials | HttpClient.HttpClient, ActionExecutionDetail>;
export type ListActionTypesError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Gets a summary of all CodePipeline action types associated with your
 * account.
 */
export declare const listActionTypes: API.PaginatedOperationMethod<ListActionTypesInput, ListActionTypesOutput, ListActionTypesError, Credentials | HttpClient.HttpClient, ActionType>;
export type ListDeployActionExecutionTargetsError = ActionExecutionNotFoundException | InvalidNextTokenException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the targets for the deploy action.
 */
export declare const listDeployActionExecutionTargets: API.PaginatedOperationMethod<ListDeployActionExecutionTargetsInput, ListDeployActionExecutionTargetsOutput, ListDeployActionExecutionTargetsError, Credentials | HttpClient.HttpClient, DeployActionExecutionTarget>;
export type ListPipelineExecutionsError = InvalidNextTokenException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Gets a summary of the most recent executions for a pipeline.
 *
 * When applying the filter for pipeline executions that have succeeded in the stage,
 * the operation returns all executions in the current pipeline version beginning on
 * February 1, 2024.
 */
export declare const listPipelineExecutions: API.PaginatedOperationMethod<ListPipelineExecutionsInput, ListPipelineExecutionsOutput, ListPipelineExecutionsError, Credentials | HttpClient.HttpClient, PipelineExecutionSummary>;
export type ListPipelinesError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Gets a summary of all of the pipelines associated with your account.
 */
export declare const listPipelines: API.PaginatedOperationMethod<ListPipelinesInput, ListPipelinesOutput, ListPipelinesError, Credentials | HttpClient.HttpClient, PipelineSummary>;
export type ListRuleExecutionsError = InvalidNextTokenException | PipelineExecutionNotFoundException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the rule executions that have occurred in a pipeline configured for conditions
 * with rules.
 */
export declare const listRuleExecutions: API.PaginatedOperationMethod<ListRuleExecutionsInput, ListRuleExecutionsOutput, ListRuleExecutionsError, Credentials | HttpClient.HttpClient, RuleExecutionDetail>;
export type ListRuleTypesError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Lists the rules for the condition. For more information about conditions, see Stage
 * conditions and How do
 * stage conditions work?.For more information about rules, see the CodePipeline rule reference.
 */
export declare const listRuleTypes: API.OperationMethod<ListRuleTypesInput, ListRuleTypesOutput, ListRuleTypesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InvalidArnException | InvalidNextTokenException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets the set of key-value pairs (metadata) that are used to manage the
 * resource.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type ListWebhooksError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Gets a listing of all the webhooks in this Amazon Web Services Region for this
 * account. The output lists all webhooks and includes the webhook URL and ARN and the
 * configuration for each webhook.
 *
 * If a secret token was provided, it will be redacted in the response.
 */
export declare const listWebhooks: API.PaginatedOperationMethod<ListWebhooksInput, ListWebhooksOutput, ListWebhooksError, Credentials | HttpClient.HttpClient, ListWebhookItem>;
export type OverrideStageConditionError = ConcurrentPipelineExecutionsLimitExceededException | ConditionNotOverridableException | ConflictException | NotLatestPipelineExecutionException | PipelineNotFoundException | StageNotFoundException | ValidationException | CommonErrors;
/**
 * Used to override a stage condition. For more information about conditions, see Stage
 * conditions and How do
 * stage conditions work?.
 */
export declare const overrideStageCondition: API.OperationMethod<OverrideStageConditionInput, OverrideStageConditionResponse, OverrideStageConditionError, Credentials | HttpClient.HttpClient>;
export type PollForJobsError = ActionTypeNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about any jobs for CodePipeline to act on.
 * `PollForJobs` is valid only for action types with "Custom" in the owner
 * field. If the action type contains `AWS` or `ThirdParty` in the
 * owner field, the `PollForJobs` action returns an error.
 *
 * When this API is called, CodePipeline returns temporary credentials for
 * the S3 bucket used to store artifacts for the pipeline, if the action requires
 * access to that S3 bucket for input or output artifacts. This API also returns any
 * secret values defined for the action.
 */
export declare const pollForJobs: API.OperationMethod<PollForJobsInput, PollForJobsOutput, PollForJobsError, Credentials | HttpClient.HttpClient>;
export type PollForThirdPartyJobsError = ActionTypeNotFoundException | ValidationException | CommonErrors;
/**
 * Determines whether there are any third party jobs for a job worker to act on. Used
 * for partner actions only.
 *
 * When this API is called, CodePipeline returns temporary credentials for
 * the S3 bucket used to store artifacts for the pipeline, if the action requires
 * access to that S3 bucket for input or output artifacts.
 */
export declare const pollForThirdPartyJobs: API.OperationMethod<PollForThirdPartyJobsInput, PollForThirdPartyJobsOutput, PollForThirdPartyJobsError, Credentials | HttpClient.HttpClient>;
export type PutActionRevisionError = ActionNotFoundException | ConcurrentPipelineExecutionsLimitExceededException | PipelineNotFoundException | StageNotFoundException | ValidationException | CommonErrors;
/**
 * Provides information to CodePipeline about new revisions to a
 * source.
 */
export declare const putActionRevision: API.OperationMethod<PutActionRevisionInput, PutActionRevisionOutput, PutActionRevisionError, Credentials | HttpClient.HttpClient>;
export type PutApprovalResultError = ActionNotFoundException | ApprovalAlreadyCompletedException | InvalidApprovalTokenException | PipelineNotFoundException | StageNotFoundException | ValidationException | CommonErrors;
/**
 * Provides the response to a manual approval request to CodePipeline. Valid
 * responses include Approved and Rejected.
 */
export declare const putApprovalResult: API.OperationMethod<PutApprovalResultInput, PutApprovalResultOutput, PutApprovalResultError, Credentials | HttpClient.HttpClient>;
export type PutJobFailureResultError = InvalidJobStateException | JobNotFoundException | ValidationException | CommonErrors;
/**
 * Represents the failure of a job as returned to the pipeline by a job worker. Used
 * for custom actions only.
 */
export declare const putJobFailureResult: API.OperationMethod<PutJobFailureResultInput, PutJobFailureResultResponse, PutJobFailureResultError, Credentials | HttpClient.HttpClient>;
export type PutJobSuccessResultError = InvalidJobStateException | JobNotFoundException | OutputVariablesSizeExceededException | ValidationException | CommonErrors;
/**
 * Represents the success of a job as returned to the pipeline by a job worker. Used
 * for custom actions only.
 */
export declare const putJobSuccessResult: API.OperationMethod<PutJobSuccessResultInput, PutJobSuccessResultResponse, PutJobSuccessResultError, Credentials | HttpClient.HttpClient>;
export type PutThirdPartyJobFailureResultError = InvalidClientTokenException | InvalidJobStateException | JobNotFoundException | ValidationException | CommonErrors;
/**
 * Represents the failure of a third party job as returned to the pipeline by a job
 * worker. Used for partner actions only.
 */
export declare const putThirdPartyJobFailureResult: API.OperationMethod<PutThirdPartyJobFailureResultInput, PutThirdPartyJobFailureResultResponse, PutThirdPartyJobFailureResultError, Credentials | HttpClient.HttpClient>;
export type PutThirdPartyJobSuccessResultError = InvalidClientTokenException | InvalidJobStateException | JobNotFoundException | ValidationException | CommonErrors;
/**
 * Represents the success of a third party job as returned to the pipeline by a job
 * worker. Used for partner actions only.
 */
export declare const putThirdPartyJobSuccessResult: API.OperationMethod<PutThirdPartyJobSuccessResultInput, PutThirdPartyJobSuccessResultResponse, PutThirdPartyJobSuccessResultError, Credentials | HttpClient.HttpClient>;
export type PutWebhookError = ConcurrentModificationException | InvalidTagsException | InvalidWebhookAuthenticationParametersException | InvalidWebhookFilterPatternException | LimitExceededException | PipelineNotFoundException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Defines a webhook and returns a unique webhook URL generated by CodePipeline.
 * This URL can be supplied to third party source hosting providers to call every time
 * there's a code change. When CodePipeline receives a POST request on this URL, the
 * pipeline defined in the webhook is started as long as the POST request satisfied the
 * authentication and filtering requirements supplied when defining the webhook.
 * RegisterWebhookWithThirdParty and DeregisterWebhookWithThirdParty APIs can be used to
 * automatically configure supported third parties to call the generated webhook
 * URL.
 *
 * When creating CodePipeline webhooks, do not use your own credentials or
 * reuse the same secret token across multiple webhooks. For optimal security, generate
 * a unique secret token for each webhook you create. The secret token is an arbitrary
 * string that you provide, which GitHub uses to compute and sign the webhook payloads
 * sent to CodePipeline, for protecting the integrity and authenticity of the
 * webhook payloads. Using your own credentials or reusing the same token across
 * multiple webhooks can lead to security vulnerabilities.
 *
 * If a secret token was provided, it will be redacted in the response.
 */
export declare const putWebhook: API.OperationMethod<PutWebhookInput, PutWebhookOutput, PutWebhookError, Credentials | HttpClient.HttpClient>;
export type RegisterWebhookWithThirdPartyError = ValidationException | WebhookNotFoundException | CommonErrors;
/**
 * Configures a connection between the webhook that was created and the external tool
 * with events to be detected.
 */
export declare const registerWebhookWithThirdParty: API.OperationMethod<RegisterWebhookWithThirdPartyInput, RegisterWebhookWithThirdPartyOutput, RegisterWebhookWithThirdPartyError, Credentials | HttpClient.HttpClient>;
export type RetryStageExecutionError = ConcurrentPipelineExecutionsLimitExceededException | ConflictException | NotLatestPipelineExecutionException | PipelineNotFoundException | StageNotFoundException | StageNotRetryableException | ValidationException | CommonErrors;
/**
 * You can retry a stage that has failed without having to run a pipeline again from
 * the beginning. You do this by either retrying the failed actions in a stage or by
 * retrying all actions in the stage starting from the first action in the stage. When you
 * retry the failed actions in a stage, all actions that are still in progress continue
 * working, and failed actions are triggered again. When you retry a failed stage from the
 * first action in the stage, the stage cannot have any actions in progress. Before a stage
 * can be retried, it must either have all actions failed or some actions failed and some
 * succeeded.
 */
export declare const retryStageExecution: API.OperationMethod<RetryStageExecutionInput, RetryStageExecutionOutput, RetryStageExecutionError, Credentials | HttpClient.HttpClient>;
export type RollbackStageError = ConflictException | PipelineExecutionNotFoundException | PipelineExecutionOutdatedException | PipelineNotFoundException | StageNotFoundException | UnableToRollbackStageException | ValidationException | CommonErrors;
/**
 * Rolls back a stage execution.
 */
export declare const rollbackStage: API.OperationMethod<RollbackStageInput, RollbackStageOutput, RollbackStageError, Credentials | HttpClient.HttpClient>;
export type StartPipelineExecutionError = ConcurrentPipelineExecutionsLimitExceededException | ConflictException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Starts the specified pipeline. Specifically, it begins processing the latest commit
 * to the source location specified as part of the pipeline.
 */
export declare const startPipelineExecution: API.OperationMethod<StartPipelineExecutionInput, StartPipelineExecutionOutput, StartPipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type StopPipelineExecutionError = ConflictException | DuplicatedStopRequestException | PipelineExecutionNotStoppableException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Stops the specified pipeline execution. You choose to either stop the pipeline
 * execution by completing in-progress actions without starting subsequent actions, or by
 * abandoning in-progress actions. While completing or abandoning in-progress actions, the
 * pipeline execution is in a `Stopping` state. After all in-progress actions
 * are completed or abandoned, the pipeline execution is in a `Stopped`
 * state.
 */
export declare const stopPipelineExecution: API.OperationMethod<StopPipelineExecutionInput, StopPipelineExecutionOutput, StopPipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConcurrentModificationException | InvalidArnException | InvalidTagsException | ResourceNotFoundException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Adds to or modifies the tags of the given resource. Tags are metadata that can be used
 * to manage a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConcurrentModificationException | InvalidArnException | InvalidTagsException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from an Amazon Web Services resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateActionTypeError = ActionTypeNotFoundException | RequestFailedException | ValidationException | CommonErrors;
/**
 * Updates an action type that was created with any supported integration model, where
 * the action type is to be used by customers of the action type provider. Use a JSON file
 * with the action definition and `UpdateActionType` to provide the full
 * structure.
 */
export declare const updateActionType: API.OperationMethod<UpdateActionTypeInput, UpdateActionTypeResponse, UpdateActionTypeError, Credentials | HttpClient.HttpClient>;
export type UpdatePipelineError = InvalidActionDeclarationException | InvalidBlockerDeclarationException | InvalidStageDeclarationException | InvalidStructureException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Updates a specified pipeline with edits or changes to its structure. Use a JSON
 * file with the pipeline structure and `UpdatePipeline` to provide the full
 * structure of the pipeline. Updating the pipeline increases the version number of the
 * pipeline by 1.
 */
export declare const updatePipeline: API.OperationMethod<UpdatePipelineInput, UpdatePipelineOutput, UpdatePipelineError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codepipeline.d.ts.map