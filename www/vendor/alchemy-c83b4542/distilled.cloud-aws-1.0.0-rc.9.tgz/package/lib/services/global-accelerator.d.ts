import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AcceleratorNotDisabledException_base: S.Class<AcceleratorNotDisabledException, S.TaggedStruct<"AcceleratorNotDisabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AcceleratorNotDisabledException extends /*@__PURE__*/ AcceleratorNotDisabledException_base {
}
declare const AcceleratorNotFoundException_base: S.Class<AcceleratorNotFoundException, S.TaggedStruct<"AcceleratorNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AcceleratorNotFoundException extends /*@__PURE__*/ AcceleratorNotFoundException_base {
}
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AssociatedEndpointGroupFoundException_base: S.Class<AssociatedEndpointGroupFoundException, S.TaggedStruct<"AssociatedEndpointGroupFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AssociatedEndpointGroupFoundException extends /*@__PURE__*/ AssociatedEndpointGroupFoundException_base {
}
declare const AssociatedListenerFoundException_base: S.Class<AssociatedListenerFoundException, S.TaggedStruct<"AssociatedListenerFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AssociatedListenerFoundException extends /*@__PURE__*/ AssociatedListenerFoundException_base {
}
declare const AttachmentNotFoundException_base: S.Class<AttachmentNotFoundException, S.TaggedStruct<"AttachmentNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AttachmentNotFoundException extends /*@__PURE__*/ AttachmentNotFoundException_base {
}
declare const ByoipCidrNotFoundException_base: S.Class<ByoipCidrNotFoundException, S.TaggedStruct<"ByoipCidrNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ByoipCidrNotFoundException extends /*@__PURE__*/ ByoipCidrNotFoundException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const EndpointAlreadyExistsException_base: S.Class<EndpointAlreadyExistsException, S.TaggedStruct<"EndpointAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EndpointAlreadyExistsException extends /*@__PURE__*/ EndpointAlreadyExistsException_base {
}
declare const EndpointGroupAlreadyExistsException_base: S.Class<EndpointGroupAlreadyExistsException, S.TaggedStruct<"EndpointGroupAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EndpointGroupAlreadyExistsException extends /*@__PURE__*/ EndpointGroupAlreadyExistsException_base {
}
declare const EndpointGroupNotFoundException_base: S.Class<EndpointGroupNotFoundException, S.TaggedStruct<"EndpointGroupNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EndpointGroupNotFoundException extends /*@__PURE__*/ EndpointGroupNotFoundException_base {
}
declare const EndpointNotFoundException_base: S.Class<EndpointNotFoundException, S.TaggedStruct<"EndpointNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EndpointNotFoundException extends /*@__PURE__*/ EndpointNotFoundException_base {
}
declare const IncorrectCidrStateException_base: S.Class<IncorrectCidrStateException, S.TaggedStruct<"IncorrectCidrStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IncorrectCidrStateException extends /*@__PURE__*/ IncorrectCidrStateException_base {
}
declare const InternalServiceErrorException_base: S.Class<InternalServiceErrorException, S.TaggedStruct<"InternalServiceErrorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const InvalidArgumentException_base: S.Class<InvalidArgumentException, S.TaggedStruct<"InvalidArgumentException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidArgumentException extends /*@__PURE__*/ InvalidArgumentException_base {
}
declare const InvalidNextTokenException_base: S.Class<InvalidNextTokenException, S.TaggedStruct<"InvalidNextTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidPortRangeException_base: S.Class<InvalidPortRangeException, S.TaggedStruct<"InvalidPortRangeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPortRangeException extends /*@__PURE__*/ InvalidPortRangeException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ListenerNotFoundException_base: S.Class<ListenerNotFoundException, S.TaggedStruct<"ListenerNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ListenerNotFoundException extends /*@__PURE__*/ ListenerNotFoundException_base {
}
declare const TransactionInProgressException_base: S.Class<TransactionInProgressException, S.TaggedStruct<"TransactionInProgressException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class TransactionInProgressException extends /*@__PURE__*/ TransactionInProgressException_base {
}
export interface CustomRoutingEndpointConfiguration {
    EndpointId?: string;
    AttachmentArn?: string;
}
export declare const CustomRoutingEndpointConfiguration: S.Schema<CustomRoutingEndpointConfiguration>;
export type CustomRoutingEndpointConfigurations = CustomRoutingEndpointConfiguration[];
export declare const CustomRoutingEndpointConfigurations: any;
export interface AddCustomRoutingEndpointsRequest {
    EndpointConfigurations: CustomRoutingEndpointConfiguration[];
    EndpointGroupArn: string;
}
export declare const AddCustomRoutingEndpointsRequest: S.Schema<AddCustomRoutingEndpointsRequest>;
export interface CustomRoutingEndpointDescription {
    EndpointId?: string;
}
export declare const CustomRoutingEndpointDescription: S.Schema<CustomRoutingEndpointDescription>;
export type CustomRoutingEndpointDescriptions = CustomRoutingEndpointDescription[];
export declare const CustomRoutingEndpointDescriptions: any;
export interface AddCustomRoutingEndpointsResponse {
    EndpointDescriptions?: CustomRoutingEndpointDescription[];
    EndpointGroupArn?: string;
}
export declare const AddCustomRoutingEndpointsResponse: S.Schema<AddCustomRoutingEndpointsResponse>;
export type EndpointWeight = number;
export interface EndpointConfiguration {
    EndpointId?: string;
    Weight?: number;
    ClientIPPreservationEnabled?: boolean;
    AttachmentArn?: string;
}
export declare const EndpointConfiguration: S.Schema<EndpointConfiguration>;
export type EndpointConfigurations = EndpointConfiguration[];
export declare const EndpointConfigurations: any;
export interface AddEndpointsRequest {
    EndpointConfigurations: EndpointConfiguration[];
    EndpointGroupArn: string;
}
export declare const AddEndpointsRequest: S.Schema<AddEndpointsRequest>;
export type HealthState = "INITIAL" | "HEALTHY" | "UNHEALTHY" | (string & {});
export declare const HealthState: any;
export interface EndpointDescription {
    EndpointId?: string;
    Weight?: number;
    HealthState?: HealthState;
    HealthReason?: string;
    ClientIPPreservationEnabled?: boolean;
}
export declare const EndpointDescription: S.Schema<EndpointDescription>;
export type EndpointDescriptions = EndpointDescription[];
export declare const EndpointDescriptions: any;
export interface AddEndpointsResponse {
    EndpointDescriptions?: EndpointDescription[];
    EndpointGroupArn?: string;
}
export declare const AddEndpointsResponse: S.Schema<AddEndpointsResponse>;
export interface AdvertiseByoipCidrRequest {
    Cidr: string;
}
export declare const AdvertiseByoipCidrRequest: S.Schema<AdvertiseByoipCidrRequest>;
export type ByoipCidrState = "PENDING_PROVISIONING" | "READY" | "PENDING_ADVERTISING" | "ADVERTISING" | "PENDING_WITHDRAWING" | "PENDING_DEPROVISIONING" | "DEPROVISIONED" | "FAILED_PROVISION" | "FAILED_ADVERTISING" | "FAILED_WITHDRAW" | "FAILED_DEPROVISION" | (string & {});
export declare const ByoipCidrState: any;
export interface ByoipCidrEvent {
    Message?: string;
    Timestamp?: Date;
}
export declare const ByoipCidrEvent: S.Schema<ByoipCidrEvent>;
export type ByoipCidrEvents = ByoipCidrEvent[];
export declare const ByoipCidrEvents: any;
export interface ByoipCidr {
    Cidr?: string;
    State?: ByoipCidrState;
    Events?: ByoipCidrEvent[];
}
export declare const ByoipCidr: S.Schema<ByoipCidr>;
export interface AdvertiseByoipCidrResponse {
    ByoipCidr?: ByoipCidr;
}
export declare const AdvertiseByoipCidrResponse: S.Schema<AdvertiseByoipCidrResponse>;
export type IpAddress = string;
export type DestinationAddresses = string[];
export declare const DestinationAddresses: any;
export type PortNumber = number;
export type DestinationPorts = number[];
export declare const DestinationPorts: any;
export interface AllowCustomRoutingTrafficRequest {
    EndpointGroupArn: string;
    EndpointId: string;
    DestinationAddresses?: string[];
    DestinationPorts?: number[];
    AllowAllTrafficToEndpoint?: boolean;
}
export declare const AllowCustomRoutingTrafficRequest: S.Schema<AllowCustomRoutingTrafficRequest>;
export interface AllowCustomRoutingTrafficResponse {
}
export declare const AllowCustomRoutingTrafficResponse: S.Schema<AllowCustomRoutingTrafficResponse>;
export type IpAddressType = "IPV4" | "DUAL_STACK" | (string & {});
export declare const IpAddressType: any;
export type IpAddresses = string[];
export declare const IpAddresses: any;
export type IdempotencyToken = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export interface CreateAcceleratorRequest {
    Name: string;
    IpAddressType?: IpAddressType;
    IpAddresses?: string[];
    Enabled?: boolean;
    IdempotencyToken: string;
    Tags?: Tag[];
}
export declare const CreateAcceleratorRequest: S.Schema<CreateAcceleratorRequest>;
export type IpAddressFamily = "IPv4" | "IPv6" | (string & {});
export declare const IpAddressFamily: any;
export interface IpSet {
    IpFamily?: string;
    IpAddresses?: string[];
    IpAddressFamily?: IpAddressFamily;
}
export declare const IpSet: S.Schema<IpSet>;
export type IpSets = IpSet[];
export declare const IpSets: any;
export type AcceleratorStatus = "DEPLOYED" | "IN_PROGRESS" | (string & {});
export declare const AcceleratorStatus: any;
export interface AcceleratorEvent {
    Message?: string;
    Timestamp?: Date;
}
export declare const AcceleratorEvent: S.Schema<AcceleratorEvent>;
export type AcceleratorEvents = AcceleratorEvent[];
export declare const AcceleratorEvents: any;
export interface Accelerator {
    AcceleratorArn?: string;
    Name?: string;
    IpAddressType?: IpAddressType;
    Enabled?: boolean;
    IpSets?: IpSet[];
    DnsName?: string;
    Status?: AcceleratorStatus;
    CreatedTime?: Date;
    LastModifiedTime?: Date;
    DualStackDnsName?: string;
    Events?: AcceleratorEvent[];
}
export declare const Accelerator: S.Schema<Accelerator>;
export interface CreateAcceleratorResponse {
    Accelerator?: Accelerator;
}
export declare const CreateAcceleratorResponse: S.Schema<CreateAcceleratorResponse>;
export type AttachmentName = string;
export type Principal = string;
export type Principals = string[];
export declare const Principals: any;
export interface Resource {
    EndpointId?: string;
    Cidr?: string;
    Region?: string;
}
export declare const Resource: S.Schema<Resource>;
export type Resources = Resource[];
export declare const Resources: any;
export interface CreateCrossAccountAttachmentRequest {
    Name: string;
    Principals?: string[];
    Resources?: Resource[];
    IdempotencyToken: string;
    Tags?: Tag[];
}
export declare const CreateCrossAccountAttachmentRequest: S.Schema<CreateCrossAccountAttachmentRequest>;
export interface Attachment {
    AttachmentArn?: string;
    Name?: string;
    Principals?: string[];
    Resources?: Resource[];
    LastModifiedTime?: Date;
    CreatedTime?: Date;
}
export declare const Attachment: S.Schema<Attachment>;
export interface CreateCrossAccountAttachmentResponse {
    CrossAccountAttachment?: Attachment;
}
export declare const CreateCrossAccountAttachmentResponse: S.Schema<CreateCrossAccountAttachmentResponse>;
export interface CreateCustomRoutingAcceleratorRequest {
    Name: string;
    IpAddressType?: IpAddressType;
    IpAddresses?: string[];
    Enabled?: boolean;
    IdempotencyToken: string;
    Tags?: Tag[];
}
export declare const CreateCustomRoutingAcceleratorRequest: S.Schema<CreateCustomRoutingAcceleratorRequest>;
export type CustomRoutingAcceleratorStatus = "DEPLOYED" | "IN_PROGRESS" | (string & {});
export declare const CustomRoutingAcceleratorStatus: any;
export interface CustomRoutingAccelerator {
    AcceleratorArn?: string;
    Name?: string;
    IpAddressType?: IpAddressType;
    Enabled?: boolean;
    IpSets?: IpSet[];
    DnsName?: string;
    Status?: CustomRoutingAcceleratorStatus;
    CreatedTime?: Date;
    LastModifiedTime?: Date;
}
export declare const CustomRoutingAccelerator: S.Schema<CustomRoutingAccelerator>;
export interface CreateCustomRoutingAcceleratorResponse {
    Accelerator?: CustomRoutingAccelerator;
}
export declare const CreateCustomRoutingAcceleratorResponse: S.Schema<CreateCustomRoutingAcceleratorResponse>;
export type CustomRoutingProtocol = "TCP" | "UDP" | (string & {});
export declare const CustomRoutingProtocol: any;
export type CustomRoutingProtocols = CustomRoutingProtocol[];
export declare const CustomRoutingProtocols: any;
export interface CustomRoutingDestinationConfiguration {
    FromPort: number;
    ToPort: number;
    Protocols: CustomRoutingProtocol[];
}
export declare const CustomRoutingDestinationConfiguration: S.Schema<CustomRoutingDestinationConfiguration>;
export type CustomRoutingDestinationConfigurations = CustomRoutingDestinationConfiguration[];
export declare const CustomRoutingDestinationConfigurations: any;
export interface CreateCustomRoutingEndpointGroupRequest {
    ListenerArn: string;
    EndpointGroupRegion: string;
    DestinationConfigurations: CustomRoutingDestinationConfiguration[];
    IdempotencyToken: string;
}
export declare const CreateCustomRoutingEndpointGroupRequest: S.Schema<CreateCustomRoutingEndpointGroupRequest>;
export type Protocol = "TCP" | "UDP" | (string & {});
export declare const Protocol: any;
export type Protocols = Protocol[];
export declare const Protocols: any;
export interface CustomRoutingDestinationDescription {
    FromPort?: number;
    ToPort?: number;
    Protocols?: Protocol[];
}
export declare const CustomRoutingDestinationDescription: S.Schema<CustomRoutingDestinationDescription>;
export type CustomRoutingDestinationDescriptions = CustomRoutingDestinationDescription[];
export declare const CustomRoutingDestinationDescriptions: any;
export interface CustomRoutingEndpointGroup {
    EndpointGroupArn?: string;
    EndpointGroupRegion?: string;
    DestinationDescriptions?: CustomRoutingDestinationDescription[];
    EndpointDescriptions?: CustomRoutingEndpointDescription[];
}
export declare const CustomRoutingEndpointGroup: S.Schema<CustomRoutingEndpointGroup>;
export interface CreateCustomRoutingEndpointGroupResponse {
    EndpointGroup?: CustomRoutingEndpointGroup;
}
export declare const CreateCustomRoutingEndpointGroupResponse: S.Schema<CreateCustomRoutingEndpointGroupResponse>;
export interface PortRange {
    FromPort?: number;
    ToPort?: number;
}
export declare const PortRange: S.Schema<PortRange>;
export type PortRanges = PortRange[];
export declare const PortRanges: any;
export interface CreateCustomRoutingListenerRequest {
    AcceleratorArn: string;
    PortRanges: PortRange[];
    IdempotencyToken: string;
}
export declare const CreateCustomRoutingListenerRequest: S.Schema<CreateCustomRoutingListenerRequest>;
export interface CustomRoutingListener {
    ListenerArn?: string;
    PortRanges?: PortRange[];
}
export declare const CustomRoutingListener: S.Schema<CustomRoutingListener>;
export interface CreateCustomRoutingListenerResponse {
    Listener?: CustomRoutingListener;
}
export declare const CreateCustomRoutingListenerResponse: S.Schema<CreateCustomRoutingListenerResponse>;
export type TrafficDialPercentage = number;
export type HealthCheckPort = number;
export type HealthCheckProtocol = "TCP" | "HTTP" | "HTTPS" | (string & {});
export declare const HealthCheckProtocol: any;
export type HealthCheckPath = string;
export type HealthCheckIntervalSeconds = number;
export type ThresholdCount = number;
export interface PortOverride {
    ListenerPort?: number;
    EndpointPort?: number;
}
export declare const PortOverride: S.Schema<PortOverride>;
export type PortOverrides = PortOverride[];
export declare const PortOverrides: any;
export interface CreateEndpointGroupRequest {
    ListenerArn: string;
    EndpointGroupRegion: string;
    EndpointConfigurations?: EndpointConfiguration[];
    TrafficDialPercentage?: number;
    HealthCheckPort?: number;
    HealthCheckProtocol?: HealthCheckProtocol;
    HealthCheckPath?: string;
    HealthCheckIntervalSeconds?: number;
    ThresholdCount?: number;
    IdempotencyToken: string;
    PortOverrides?: PortOverride[];
}
export declare const CreateEndpointGroupRequest: S.Schema<CreateEndpointGroupRequest>;
export interface EndpointGroup {
    EndpointGroupArn?: string;
    EndpointGroupRegion?: string;
    EndpointDescriptions?: EndpointDescription[];
    TrafficDialPercentage?: number;
    HealthCheckPort?: number;
    HealthCheckProtocol?: HealthCheckProtocol;
    HealthCheckPath?: string;
    HealthCheckIntervalSeconds?: number;
    ThresholdCount?: number;
    PortOverrides?: PortOverride[];
}
export declare const EndpointGroup: S.Schema<EndpointGroup>;
export interface CreateEndpointGroupResponse {
    EndpointGroup?: EndpointGroup;
}
export declare const CreateEndpointGroupResponse: S.Schema<CreateEndpointGroupResponse>;
export type ClientAffinity = "NONE" | "SOURCE_IP" | (string & {});
export declare const ClientAffinity: any;
export interface CreateListenerRequest {
    AcceleratorArn: string;
    PortRanges: PortRange[];
    Protocol: Protocol;
    ClientAffinity?: ClientAffinity;
    IdempotencyToken: string;
}
export declare const CreateListenerRequest: S.Schema<CreateListenerRequest>;
export interface Listener {
    ListenerArn?: string;
    PortRanges?: PortRange[];
    Protocol?: Protocol;
    ClientAffinity?: ClientAffinity;
}
export declare const Listener: S.Schema<Listener>;
export interface CreateListenerResponse {
    Listener?: Listener;
}
export declare const CreateListenerResponse: S.Schema<CreateListenerResponse>;
export interface DeleteAcceleratorRequest {
    AcceleratorArn: string;
}
export declare const DeleteAcceleratorRequest: S.Schema<DeleteAcceleratorRequest>;
export interface DeleteAcceleratorResponse {
}
export declare const DeleteAcceleratorResponse: S.Schema<DeleteAcceleratorResponse>;
export interface DeleteCrossAccountAttachmentRequest {
    AttachmentArn: string;
}
export declare const DeleteCrossAccountAttachmentRequest: S.Schema<DeleteCrossAccountAttachmentRequest>;
export interface DeleteCrossAccountAttachmentResponse {
}
export declare const DeleteCrossAccountAttachmentResponse: S.Schema<DeleteCrossAccountAttachmentResponse>;
export interface DeleteCustomRoutingAcceleratorRequest {
    AcceleratorArn: string;
}
export declare const DeleteCustomRoutingAcceleratorRequest: S.Schema<DeleteCustomRoutingAcceleratorRequest>;
export interface DeleteCustomRoutingAcceleratorResponse {
}
export declare const DeleteCustomRoutingAcceleratorResponse: S.Schema<DeleteCustomRoutingAcceleratorResponse>;
export interface DeleteCustomRoutingEndpointGroupRequest {
    EndpointGroupArn: string;
}
export declare const DeleteCustomRoutingEndpointGroupRequest: S.Schema<DeleteCustomRoutingEndpointGroupRequest>;
export interface DeleteCustomRoutingEndpointGroupResponse {
}
export declare const DeleteCustomRoutingEndpointGroupResponse: S.Schema<DeleteCustomRoutingEndpointGroupResponse>;
export interface DeleteCustomRoutingListenerRequest {
    ListenerArn: string;
}
export declare const DeleteCustomRoutingListenerRequest: S.Schema<DeleteCustomRoutingListenerRequest>;
export interface DeleteCustomRoutingListenerResponse {
}
export declare const DeleteCustomRoutingListenerResponse: S.Schema<DeleteCustomRoutingListenerResponse>;
export interface DeleteEndpointGroupRequest {
    EndpointGroupArn: string;
}
export declare const DeleteEndpointGroupRequest: S.Schema<DeleteEndpointGroupRequest>;
export interface DeleteEndpointGroupResponse {
}
export declare const DeleteEndpointGroupResponse: S.Schema<DeleteEndpointGroupResponse>;
export interface DeleteListenerRequest {
    ListenerArn: string;
}
export declare const DeleteListenerRequest: S.Schema<DeleteListenerRequest>;
export interface DeleteListenerResponse {
}
export declare const DeleteListenerResponse: S.Schema<DeleteListenerResponse>;
export interface DenyCustomRoutingTrafficRequest {
    EndpointGroupArn: string;
    EndpointId: string;
    DestinationAddresses?: string[];
    DestinationPorts?: number[];
    DenyAllTrafficToEndpoint?: boolean;
}
export declare const DenyCustomRoutingTrafficRequest: S.Schema<DenyCustomRoutingTrafficRequest>;
export interface DenyCustomRoutingTrafficResponse {
}
export declare const DenyCustomRoutingTrafficResponse: S.Schema<DenyCustomRoutingTrafficResponse>;
export interface DeprovisionByoipCidrRequest {
    Cidr: string;
}
export declare const DeprovisionByoipCidrRequest: S.Schema<DeprovisionByoipCidrRequest>;
export interface DeprovisionByoipCidrResponse {
    ByoipCidr?: ByoipCidr;
}
export declare const DeprovisionByoipCidrResponse: S.Schema<DeprovisionByoipCidrResponse>;
export interface DescribeAcceleratorRequest {
    AcceleratorArn: string;
}
export declare const DescribeAcceleratorRequest: S.Schema<DescribeAcceleratorRequest>;
export interface DescribeAcceleratorResponse {
    Accelerator?: Accelerator;
}
export declare const DescribeAcceleratorResponse: S.Schema<DescribeAcceleratorResponse>;
export interface DescribeAcceleratorAttributesRequest {
    AcceleratorArn: string;
}
export declare const DescribeAcceleratorAttributesRequest: S.Schema<DescribeAcceleratorAttributesRequest>;
export interface AcceleratorAttributes {
    FlowLogsEnabled?: boolean;
    FlowLogsS3Bucket?: string;
    FlowLogsS3Prefix?: string;
}
export declare const AcceleratorAttributes: S.Schema<AcceleratorAttributes>;
export interface DescribeAcceleratorAttributesResponse {
    AcceleratorAttributes?: AcceleratorAttributes;
}
export declare const DescribeAcceleratorAttributesResponse: S.Schema<DescribeAcceleratorAttributesResponse>;
export interface DescribeCrossAccountAttachmentRequest {
    AttachmentArn: string;
}
export declare const DescribeCrossAccountAttachmentRequest: S.Schema<DescribeCrossAccountAttachmentRequest>;
export interface DescribeCrossAccountAttachmentResponse {
    CrossAccountAttachment?: Attachment;
}
export declare const DescribeCrossAccountAttachmentResponse: S.Schema<DescribeCrossAccountAttachmentResponse>;
export interface DescribeCustomRoutingAcceleratorRequest {
    AcceleratorArn: string;
}
export declare const DescribeCustomRoutingAcceleratorRequest: S.Schema<DescribeCustomRoutingAcceleratorRequest>;
export interface DescribeCustomRoutingAcceleratorResponse {
    Accelerator?: CustomRoutingAccelerator;
}
export declare const DescribeCustomRoutingAcceleratorResponse: S.Schema<DescribeCustomRoutingAcceleratorResponse>;
export interface DescribeCustomRoutingAcceleratorAttributesRequest {
    AcceleratorArn: string;
}
export declare const DescribeCustomRoutingAcceleratorAttributesRequest: S.Schema<DescribeCustomRoutingAcceleratorAttributesRequest>;
export interface CustomRoutingAcceleratorAttributes {
    FlowLogsEnabled?: boolean;
    FlowLogsS3Bucket?: string;
    FlowLogsS3Prefix?: string;
}
export declare const CustomRoutingAcceleratorAttributes: S.Schema<CustomRoutingAcceleratorAttributes>;
export interface DescribeCustomRoutingAcceleratorAttributesResponse {
    AcceleratorAttributes?: CustomRoutingAcceleratorAttributes;
}
export declare const DescribeCustomRoutingAcceleratorAttributesResponse: S.Schema<DescribeCustomRoutingAcceleratorAttributesResponse>;
export interface DescribeCustomRoutingEndpointGroupRequest {
    EndpointGroupArn: string;
}
export declare const DescribeCustomRoutingEndpointGroupRequest: S.Schema<DescribeCustomRoutingEndpointGroupRequest>;
export interface DescribeCustomRoutingEndpointGroupResponse {
    EndpointGroup?: CustomRoutingEndpointGroup;
}
export declare const DescribeCustomRoutingEndpointGroupResponse: S.Schema<DescribeCustomRoutingEndpointGroupResponse>;
export interface DescribeCustomRoutingListenerRequest {
    ListenerArn: string;
}
export declare const DescribeCustomRoutingListenerRequest: S.Schema<DescribeCustomRoutingListenerRequest>;
export interface DescribeCustomRoutingListenerResponse {
    Listener?: CustomRoutingListener;
}
export declare const DescribeCustomRoutingListenerResponse: S.Schema<DescribeCustomRoutingListenerResponse>;
export interface DescribeEndpointGroupRequest {
    EndpointGroupArn: string;
}
export declare const DescribeEndpointGroupRequest: S.Schema<DescribeEndpointGroupRequest>;
export interface DescribeEndpointGroupResponse {
    EndpointGroup?: EndpointGroup;
}
export declare const DescribeEndpointGroupResponse: S.Schema<DescribeEndpointGroupResponse>;
export interface DescribeListenerRequest {
    ListenerArn: string;
}
export declare const DescribeListenerRequest: S.Schema<DescribeListenerRequest>;
export interface DescribeListenerResponse {
    Listener?: Listener;
}
export declare const DescribeListenerResponse: S.Schema<DescribeListenerResponse>;
export type MaxResults = number;
export interface ListAcceleratorsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListAcceleratorsRequest: S.Schema<ListAcceleratorsRequest>;
export type Accelerators = Accelerator[];
export declare const Accelerators: any;
export interface ListAcceleratorsResponse {
    Accelerators?: Accelerator[];
    NextToken?: string;
}
export declare const ListAcceleratorsResponse: S.Schema<ListAcceleratorsResponse>;
export interface ListByoipCidrsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListByoipCidrsRequest: S.Schema<ListByoipCidrsRequest>;
export type ByoipCidrs = ByoipCidr[];
export declare const ByoipCidrs: any;
export interface ListByoipCidrsResponse {
    ByoipCidrs?: ByoipCidr[];
    NextToken?: string;
}
export declare const ListByoipCidrsResponse: S.Schema<ListByoipCidrsResponse>;
export interface ListCrossAccountAttachmentsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListCrossAccountAttachmentsRequest: S.Schema<ListCrossAccountAttachmentsRequest>;
export type Attachments = Attachment[];
export declare const Attachments: any;
export interface ListCrossAccountAttachmentsResponse {
    CrossAccountAttachments?: Attachment[];
    NextToken?: string;
}
export declare const ListCrossAccountAttachmentsResponse: S.Schema<ListCrossAccountAttachmentsResponse>;
export interface ListCrossAccountResourceAccountsRequest {
}
export declare const ListCrossAccountResourceAccountsRequest: S.Schema<ListCrossAccountResourceAccountsRequest>;
export type AwsAccountId = string;
export type AwsAccountIds = string[];
export declare const AwsAccountIds: any;
export interface ListCrossAccountResourceAccountsResponse {
    ResourceOwnerAwsAccountIds?: string[];
}
export declare const ListCrossAccountResourceAccountsResponse: S.Schema<ListCrossAccountResourceAccountsResponse>;
export interface ListCrossAccountResourcesRequest {
    AcceleratorArn?: string;
    ResourceOwnerAwsAccountId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListCrossAccountResourcesRequest: S.Schema<ListCrossAccountResourcesRequest>;
export interface CrossAccountResource {
    EndpointId?: string;
    Cidr?: string;
    AttachmentArn?: string;
}
export declare const CrossAccountResource: S.Schema<CrossAccountResource>;
export type CrossAccountResources = CrossAccountResource[];
export declare const CrossAccountResources: any;
export interface ListCrossAccountResourcesResponse {
    CrossAccountResources?: CrossAccountResource[];
    NextToken?: string;
}
export declare const ListCrossAccountResourcesResponse: S.Schema<ListCrossAccountResourcesResponse>;
export interface ListCustomRoutingAcceleratorsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListCustomRoutingAcceleratorsRequest: S.Schema<ListCustomRoutingAcceleratorsRequest>;
export type CustomRoutingAccelerators = CustomRoutingAccelerator[];
export declare const CustomRoutingAccelerators: any;
export interface ListCustomRoutingAcceleratorsResponse {
    Accelerators?: CustomRoutingAccelerator[];
    NextToken?: string;
}
export declare const ListCustomRoutingAcceleratorsResponse: S.Schema<ListCustomRoutingAcceleratorsResponse>;
export interface ListCustomRoutingEndpointGroupsRequest {
    ListenerArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListCustomRoutingEndpointGroupsRequest: S.Schema<ListCustomRoutingEndpointGroupsRequest>;
export type CustomRoutingEndpointGroups = CustomRoutingEndpointGroup[];
export declare const CustomRoutingEndpointGroups: any;
export interface ListCustomRoutingEndpointGroupsResponse {
    EndpointGroups?: CustomRoutingEndpointGroup[];
    NextToken?: string;
}
export declare const ListCustomRoutingEndpointGroupsResponse: S.Schema<ListCustomRoutingEndpointGroupsResponse>;
export interface ListCustomRoutingListenersRequest {
    AcceleratorArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListCustomRoutingListenersRequest: S.Schema<ListCustomRoutingListenersRequest>;
export type CustomRoutingListeners = CustomRoutingListener[];
export declare const CustomRoutingListeners: any;
export interface ListCustomRoutingListenersResponse {
    Listeners?: CustomRoutingListener[];
    NextToken?: string;
}
export declare const ListCustomRoutingListenersResponse: S.Schema<ListCustomRoutingListenersResponse>;
export type PortMappingsMaxResults = number;
export interface ListCustomRoutingPortMappingsRequest {
    AcceleratorArn: string;
    EndpointGroupArn?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListCustomRoutingPortMappingsRequest: S.Schema<ListCustomRoutingPortMappingsRequest>;
export interface SocketAddress {
    IpAddress?: string;
    Port?: number;
}
export declare const SocketAddress: S.Schema<SocketAddress>;
export type CustomRoutingDestinationTrafficState = "ALLOW" | "DENY" | (string & {});
export declare const CustomRoutingDestinationTrafficState: any;
export interface PortMapping {
    AcceleratorPort?: number;
    EndpointGroupArn?: string;
    EndpointId?: string;
    DestinationSocketAddress?: SocketAddress;
    Protocols?: CustomRoutingProtocol[];
    DestinationTrafficState?: CustomRoutingDestinationTrafficState;
}
export declare const PortMapping: S.Schema<PortMapping>;
export type PortMappings = PortMapping[];
export declare const PortMappings: any;
export interface ListCustomRoutingPortMappingsResponse {
    PortMappings?: PortMapping[];
    NextToken?: string;
}
export declare const ListCustomRoutingPortMappingsResponse: S.Schema<ListCustomRoutingPortMappingsResponse>;
export interface ListCustomRoutingPortMappingsByDestinationRequest {
    EndpointId: string;
    DestinationAddress: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListCustomRoutingPortMappingsByDestinationRequest: S.Schema<ListCustomRoutingPortMappingsByDestinationRequest>;
export type SocketAddresses = SocketAddress[];
export declare const SocketAddresses: any;
export interface DestinationPortMapping {
    AcceleratorArn?: string;
    AcceleratorSocketAddresses?: SocketAddress[];
    EndpointGroupArn?: string;
    EndpointId?: string;
    EndpointGroupRegion?: string;
    DestinationSocketAddress?: SocketAddress;
    IpAddressType?: IpAddressType;
    DestinationTrafficState?: CustomRoutingDestinationTrafficState;
}
export declare const DestinationPortMapping: S.Schema<DestinationPortMapping>;
export type DestinationPortMappings = DestinationPortMapping[];
export declare const DestinationPortMappings: any;
export interface ListCustomRoutingPortMappingsByDestinationResponse {
    DestinationPortMappings?: DestinationPortMapping[];
    NextToken?: string;
}
export declare const ListCustomRoutingPortMappingsByDestinationResponse: S.Schema<ListCustomRoutingPortMappingsByDestinationResponse>;
export interface ListEndpointGroupsRequest {
    ListenerArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListEndpointGroupsRequest: S.Schema<ListEndpointGroupsRequest>;
export type EndpointGroups = EndpointGroup[];
export declare const EndpointGroups: any;
export interface ListEndpointGroupsResponse {
    EndpointGroups?: EndpointGroup[];
    NextToken?: string;
}
export declare const ListEndpointGroupsResponse: S.Schema<ListEndpointGroupsResponse>;
export interface ListListenersRequest {
    AcceleratorArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListListenersRequest: S.Schema<ListListenersRequest>;
export type Listeners = Listener[];
export declare const Listeners: any;
export interface ListListenersResponse {
    Listeners?: Listener[];
    NextToken?: string;
}
export declare const ListListenersResponse: S.Schema<ListListenersResponse>;
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface CidrAuthorizationContext {
    Message: string;
    Signature: string;
}
export declare const CidrAuthorizationContext: S.Schema<CidrAuthorizationContext>;
export interface ProvisionByoipCidrRequest {
    Cidr: string;
    CidrAuthorizationContext: CidrAuthorizationContext;
}
export declare const ProvisionByoipCidrRequest: S.Schema<ProvisionByoipCidrRequest>;
export interface ProvisionByoipCidrResponse {
    ByoipCidr?: ByoipCidr;
}
export declare const ProvisionByoipCidrResponse: S.Schema<ProvisionByoipCidrResponse>;
export type EndpointIds = string[];
export declare const EndpointIds: any;
export interface RemoveCustomRoutingEndpointsRequest {
    EndpointIds: string[];
    EndpointGroupArn: string;
}
export declare const RemoveCustomRoutingEndpointsRequest: S.Schema<RemoveCustomRoutingEndpointsRequest>;
export interface RemoveCustomRoutingEndpointsResponse {
}
export declare const RemoveCustomRoutingEndpointsResponse: S.Schema<RemoveCustomRoutingEndpointsResponse>;
export interface EndpointIdentifier {
    EndpointId: string;
    ClientIPPreservationEnabled?: boolean;
}
export declare const EndpointIdentifier: S.Schema<EndpointIdentifier>;
export type EndpointIdentifiers = EndpointIdentifier[];
export declare const EndpointIdentifiers: any;
export interface RemoveEndpointsRequest {
    EndpointIdentifiers: EndpointIdentifier[];
    EndpointGroupArn: string;
}
export declare const RemoveEndpointsRequest: S.Schema<RemoveEndpointsRequest>;
export interface RemoveEndpointsResponse {
}
export declare const RemoveEndpointsResponse: S.Schema<RemoveEndpointsResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAcceleratorRequest {
    AcceleratorArn: string;
    Name?: string;
    IpAddressType?: IpAddressType;
    IpAddresses?: string[];
    Enabled?: boolean;
}
export declare const UpdateAcceleratorRequest: S.Schema<UpdateAcceleratorRequest>;
export interface UpdateAcceleratorResponse {
    Accelerator?: Accelerator;
}
export declare const UpdateAcceleratorResponse: S.Schema<UpdateAcceleratorResponse>;
export interface UpdateAcceleratorAttributesRequest {
    AcceleratorArn: string;
    FlowLogsEnabled?: boolean;
    FlowLogsS3Bucket?: string;
    FlowLogsS3Prefix?: string;
}
export declare const UpdateAcceleratorAttributesRequest: S.Schema<UpdateAcceleratorAttributesRequest>;
export interface UpdateAcceleratorAttributesResponse {
    AcceleratorAttributes?: AcceleratorAttributes;
}
export declare const UpdateAcceleratorAttributesResponse: S.Schema<UpdateAcceleratorAttributesResponse>;
export interface UpdateCrossAccountAttachmentRequest {
    AttachmentArn: string;
    Name?: string;
    AddPrincipals?: string[];
    RemovePrincipals?: string[];
    AddResources?: Resource[];
    RemoveResources?: Resource[];
}
export declare const UpdateCrossAccountAttachmentRequest: S.Schema<UpdateCrossAccountAttachmentRequest>;
export interface UpdateCrossAccountAttachmentResponse {
    CrossAccountAttachment?: Attachment;
}
export declare const UpdateCrossAccountAttachmentResponse: S.Schema<UpdateCrossAccountAttachmentResponse>;
export interface UpdateCustomRoutingAcceleratorRequest {
    AcceleratorArn: string;
    Name?: string;
    IpAddressType?: IpAddressType;
    IpAddresses?: string[];
    Enabled?: boolean;
}
export declare const UpdateCustomRoutingAcceleratorRequest: S.Schema<UpdateCustomRoutingAcceleratorRequest>;
export interface UpdateCustomRoutingAcceleratorResponse {
    Accelerator?: CustomRoutingAccelerator;
}
export declare const UpdateCustomRoutingAcceleratorResponse: S.Schema<UpdateCustomRoutingAcceleratorResponse>;
export interface UpdateCustomRoutingAcceleratorAttributesRequest {
    AcceleratorArn: string;
    FlowLogsEnabled?: boolean;
    FlowLogsS3Bucket?: string;
    FlowLogsS3Prefix?: string;
}
export declare const UpdateCustomRoutingAcceleratorAttributesRequest: S.Schema<UpdateCustomRoutingAcceleratorAttributesRequest>;
export interface UpdateCustomRoutingAcceleratorAttributesResponse {
    AcceleratorAttributes?: CustomRoutingAcceleratorAttributes;
}
export declare const UpdateCustomRoutingAcceleratorAttributesResponse: S.Schema<UpdateCustomRoutingAcceleratorAttributesResponse>;
export interface UpdateCustomRoutingListenerRequest {
    ListenerArn: string;
    PortRanges: PortRange[];
}
export declare const UpdateCustomRoutingListenerRequest: S.Schema<UpdateCustomRoutingListenerRequest>;
export interface UpdateCustomRoutingListenerResponse {
    Listener?: CustomRoutingListener;
}
export declare const UpdateCustomRoutingListenerResponse: S.Schema<UpdateCustomRoutingListenerResponse>;
export interface UpdateEndpointGroupRequest {
    EndpointGroupArn: string;
    EndpointConfigurations?: EndpointConfiguration[];
    TrafficDialPercentage?: number;
    HealthCheckPort?: number;
    HealthCheckProtocol?: HealthCheckProtocol;
    HealthCheckPath?: string;
    HealthCheckIntervalSeconds?: number;
    ThresholdCount?: number;
    PortOverrides?: PortOverride[];
}
export declare const UpdateEndpointGroupRequest: S.Schema<UpdateEndpointGroupRequest>;
export interface UpdateEndpointGroupResponse {
    EndpointGroup?: EndpointGroup;
}
export declare const UpdateEndpointGroupResponse: S.Schema<UpdateEndpointGroupResponse>;
export interface UpdateListenerRequest {
    ListenerArn: string;
    PortRanges?: PortRange[];
    Protocol?: Protocol;
    ClientAffinity?: ClientAffinity;
}
export declare const UpdateListenerRequest: S.Schema<UpdateListenerRequest>;
export interface UpdateListenerResponse {
    Listener?: Listener;
}
export declare const UpdateListenerResponse: S.Schema<UpdateListenerResponse>;
export interface WithdrawByoipCidrRequest {
    Cidr: string;
}
export declare const WithdrawByoipCidrRequest: S.Schema<WithdrawByoipCidrRequest>;
export interface WithdrawByoipCidrResponse {
    ByoipCidr?: ByoipCidr;
}
export declare const WithdrawByoipCidrResponse: S.Schema<WithdrawByoipCidrResponse>;
export type ErrorMessage = string;
export type AddCustomRoutingEndpointsError = AccessDeniedException | ConflictException | EndpointAlreadyExistsException | EndpointGroupNotFoundException | InternalServiceErrorException | InvalidArgumentException | LimitExceededException | CommonErrors;
/**
 * Associate a virtual private cloud (VPC) subnet endpoint with your custom routing accelerator.
 *
 * The listener port range must be large enough to support the number of IP addresses that can be
 * specified in your subnet. The number of ports required is: subnet size times the number
 * of ports per destination EC2 instances. For example, a subnet defined as /24 requires a listener
 * port range of at least 255 ports.
 *
 * Note: You must have enough remaining listener ports available to
 * map to the subnet ports, or the call will fail with a LimitExceededException.
 *
 * By default, all destinations in a subnet in a custom routing accelerator cannot receive traffic. To enable all
 * destinations to receive traffic, or to specify individual port mappings that can receive
 * traffic, see the
 * AllowCustomRoutingTraffic operation.
 */
export declare const addCustomRoutingEndpoints: API.OperationMethod<AddCustomRoutingEndpointsRequest, AddCustomRoutingEndpointsResponse, AddCustomRoutingEndpointsError, Credentials | HttpClient.HttpClient>;
export type AddEndpointsError = AccessDeniedException | EndpointGroupNotFoundException | InternalServiceErrorException | InvalidArgumentException | LimitExceededException | TransactionInProgressException | CommonErrors;
/**
 * Add endpoints to an endpoint group. The `AddEndpoints` API operation is the recommended option for adding endpoints. The
 * alternative options are to add endpoints when you create an endpoint group (with the
 * CreateEndpointGroup API)
 * or when you update an endpoint group (with the
 * UpdateEndpointGroup API).
 *
 * There are two advantages to using `AddEndpoints` to add endpoints in Global Accelerator:
 *
 * - It's faster, because Global Accelerator only has to resolve the new endpoints that
 * you're adding, rather than resolving new and existing endpoints.
 *
 * - It's more convenient, because you don't need to specify the current
 * endpoints that are already in the endpoint group, in addition to the new endpoints that
 * you want to add.
 *
 * For information about endpoint types and requirements for endpoints that you can add
 * to Global Accelerator, see
 * Endpoints for standard accelerators in the *Global Accelerator Developer Guide*.
 */
export declare const addEndpoints: API.OperationMethod<AddEndpointsRequest, AddEndpointsResponse, AddEndpointsError, Credentials | HttpClient.HttpClient>;
export type AdvertiseByoipCidrError = AccessDeniedException | ByoipCidrNotFoundException | IncorrectCidrStateException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Advertises an IPv4 address range that is provisioned for use with your Amazon Web Services resources
 * through bring your own IP addresses (BYOIP). It can take a few minutes before traffic to
 * the specified addresses starts routing to Amazon Web Services because of propagation delays.
 *
 * To stop advertising the BYOIP address range, use
 * WithdrawByoipCidr.
 *
 * For more information, see Bring your own
 * IP addresses (BYOIP) in the *Global Accelerator Developer Guide*.
 */
export declare const advertiseByoipCidr: API.OperationMethod<AdvertiseByoipCidrRequest, AdvertiseByoipCidrResponse, AdvertiseByoipCidrError, Credentials | HttpClient.HttpClient>;
export type AllowCustomRoutingTrafficError = EndpointGroupNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Specify the Amazon EC2 instance (destination) IP addresses and ports for a VPC subnet endpoint that can receive traffic
 * for a custom routing accelerator. You can allow traffic to all destinations in the subnet endpoint, or allow traffic to a
 * specified list of destination IP addresses and ports in the subnet. Note that you cannot specify IP addresses or ports
 * outside of the range that you configured for the endpoint group.
 *
 * After you make changes, you can verify that the updates are complete by checking the status of your
 * accelerator: the status changes from IN_PROGRESS to DEPLOYED.
 */
export declare const allowCustomRoutingTraffic: API.OperationMethod<AllowCustomRoutingTrafficRequest, AllowCustomRoutingTrafficResponse, AllowCustomRoutingTrafficError, Credentials | HttpClient.HttpClient>;
export type CreateAcceleratorError = AccessDeniedException | InternalServiceErrorException | InvalidArgumentException | LimitExceededException | TransactionInProgressException | CommonErrors;
/**
 * Create an accelerator. An accelerator includes one or more listeners that process inbound connections and direct traffic
 * to one or more endpoint groups, each of which includes endpoints, such as Network Load Balancers.
 *
 * Global Accelerator is a global service that supports endpoints in multiple Amazon Web Services Regions but you must specify the
 * US West (Oregon) Region to create, update, or otherwise work with accelerators. That is, for example, specify `--region us-west-2`
 * on Amazon Web Services CLI commands.
 */
export declare const createAccelerator: API.OperationMethod<CreateAcceleratorRequest, CreateAcceleratorResponse, CreateAcceleratorError, Credentials | HttpClient.HttpClient>;
export type CreateCrossAccountAttachmentError = AccessDeniedException | InternalServiceErrorException | InvalidArgumentException | LimitExceededException | TransactionInProgressException | CommonErrors;
/**
 * Create a cross-account attachment in Global Accelerator. You create a cross-account attachment to
 * specify the *principals* who have permission to work with *resources*
 * in accelerators in their own account. You specify, in the same attachment, the resources that are shared.
 *
 * A principal can be an Amazon Web Services account number or the Amazon Resource Name (ARN) for an
 * accelerator. For account numbers that are listed as principals, to work with a resource listed in the attachment,
 * you must sign in to an account specified as a principal. Then, you can work with resources that are listed,
 * with any of your accelerators. If an accelerator ARN is listed in the cross-account attachment as a principal,
 * anyone with permission to make updates to the accelerator can work with resources that are listed in the
 * attachment.
 *
 * Specify each principal and resource separately. To specify two CIDR address pools, list
 * them individually under `Resources`, and so on. For a command line operation, for example,
 * you might use a statement like the following:
 *
 * ` "Resources": [{"Cidr": "169.254.60.0/24"},{"Cidr": "169.254.59.0/24"}]`
 *
 * For more information, see
 * Working with cross-account attachments and resources in Global Accelerator in the
 * Global Accelerator Developer Guide.
 */
export declare const createCrossAccountAttachment: API.OperationMethod<CreateCrossAccountAttachmentRequest, CreateCrossAccountAttachmentResponse, CreateCrossAccountAttachmentError, Credentials | HttpClient.HttpClient>;
export type CreateCustomRoutingAcceleratorError = AccessDeniedException | InternalServiceErrorException | InvalidArgumentException | LimitExceededException | TransactionInProgressException | CommonErrors;
/**
 * Create a custom routing accelerator. A custom routing accelerator directs traffic to one of possibly thousands
 * of Amazon EC2 instance destinations running in a single or multiple virtual private clouds (VPC) subnet endpoints.
 *
 * Be aware that, by default, all destination EC2 instances in a VPC subnet endpoint cannot receive
 * traffic. To enable all destinations to receive traffic, or to specify individual port
 * mappings that can receive traffic, see the
 * AllowCustomRoutingTraffic operation.
 *
 * Global Accelerator is a global service that supports endpoints in multiple Amazon Web Services Regions but you must specify the
 * US West (Oregon) Region to create, update, or otherwise work with accelerators. That is, for example, specify `--region us-west-2`
 * on Amazon Web Services CLI commands.
 */
export declare const createCustomRoutingAccelerator: API.OperationMethod<CreateCustomRoutingAcceleratorRequest, CreateCustomRoutingAcceleratorResponse, CreateCustomRoutingAcceleratorError, Credentials | HttpClient.HttpClient>;
export type CreateCustomRoutingEndpointGroupError = AcceleratorNotFoundException | AccessDeniedException | EndpointGroupAlreadyExistsException | InternalServiceErrorException | InvalidArgumentException | InvalidPortRangeException | LimitExceededException | ListenerNotFoundException | CommonErrors;
/**
 * Create an endpoint group for the specified listener for a custom routing accelerator.
 * An endpoint group is a collection of endpoints in one Amazon Web Services
 * Region.
 */
export declare const createCustomRoutingEndpointGroup: API.OperationMethod<CreateCustomRoutingEndpointGroupRequest, CreateCustomRoutingEndpointGroupResponse, CreateCustomRoutingEndpointGroupError, Credentials | HttpClient.HttpClient>;
export type CreateCustomRoutingListenerError = AcceleratorNotFoundException | InternalServiceErrorException | InvalidArgumentException | InvalidPortRangeException | LimitExceededException | CommonErrors;
/**
 * Create a listener to process inbound connections from clients to a custom routing accelerator.
 * Connections arrive to assigned static IP addresses on the port range that you specify.
 */
export declare const createCustomRoutingListener: API.OperationMethod<CreateCustomRoutingListenerRequest, CreateCustomRoutingListenerResponse, CreateCustomRoutingListenerError, Credentials | HttpClient.HttpClient>;
export type CreateEndpointGroupError = AcceleratorNotFoundException | AccessDeniedException | EndpointGroupAlreadyExistsException | InternalServiceErrorException | InvalidArgumentException | LimitExceededException | ListenerNotFoundException | CommonErrors;
/**
 * Create an endpoint group for the specified listener. An endpoint group is a collection of endpoints in one Amazon Web Services
 * Region. A resource must be valid and active when you add it as an endpoint.
 *
 * For more information about endpoint types and requirements for endpoints that you can add
 * to Global Accelerator, see
 * Endpoints for standard accelerators in the *Global Accelerator Developer Guide*.
 */
export declare const createEndpointGroup: API.OperationMethod<CreateEndpointGroupRequest, CreateEndpointGroupResponse, CreateEndpointGroupError, Credentials | HttpClient.HttpClient>;
export type CreateListenerError = AcceleratorNotFoundException | InternalServiceErrorException | InvalidArgumentException | InvalidPortRangeException | LimitExceededException | CommonErrors;
/**
 * Create a listener to process inbound connections from clients to an accelerator. Connections arrive to assigned static
 * IP addresses on a port, port range, or list of port ranges that you specify.
 */
export declare const createListener: API.OperationMethod<CreateListenerRequest, CreateListenerResponse, CreateListenerError, Credentials | HttpClient.HttpClient>;
export type DeleteAcceleratorError = AcceleratorNotDisabledException | AcceleratorNotFoundException | AssociatedListenerFoundException | InternalServiceErrorException | InvalidArgumentException | TransactionInProgressException | CommonErrors;
/**
 * Delete an accelerator. Before you can delete an accelerator, you must disable it and remove all dependent resources
 * (listeners and endpoint groups). To disable the accelerator, update the accelerator to set `Enabled` to false.
 *
 * When you create an accelerator, by default, Global Accelerator provides you with a set of two static IP addresses.
 * Alternatively, you can bring your own IP address ranges to Global Accelerator and assign IP addresses from those ranges.
 *
 * The IP addresses are assigned to your accelerator for as long as it exists, even if you disable the accelerator and
 * it no longer accepts or routes traffic. However, when you *delete* an accelerator, you lose the
 * static IP addresses that are assigned to the accelerator, so you can no longer route traffic by using them.
 * As a best practice, ensure that you have permissions in place to avoid inadvertently deleting accelerators. You
 * can use IAM policies with Global Accelerator to limit the users who have permissions to delete an accelerator. For more information,
 * see Identity and access management in
 * the *Global Accelerator Developer Guide*.
 */
export declare const deleteAccelerator: API.OperationMethod<DeleteAcceleratorRequest, DeleteAcceleratorResponse, DeleteAcceleratorError, Credentials | HttpClient.HttpClient>;
export type DeleteCrossAccountAttachmentError = AccessDeniedException | AttachmentNotFoundException | InternalServiceErrorException | InvalidArgumentException | TransactionInProgressException | CommonErrors;
/**
 * Delete a cross-account attachment. When you delete an attachment, Global Accelerator revokes the permission
 * to use the resources in the attachment from all principals in the list of principals. Global Accelerator
 * revokes the permission for specific resources.
 *
 * For more information, see
 * Working with cross-account attachments and resources in Global Accelerator in the
 * Global Accelerator Developer Guide.
 */
export declare const deleteCrossAccountAttachment: API.OperationMethod<DeleteCrossAccountAttachmentRequest, DeleteCrossAccountAttachmentResponse, DeleteCrossAccountAttachmentError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomRoutingAcceleratorError = AcceleratorNotDisabledException | AcceleratorNotFoundException | AssociatedListenerFoundException | InternalServiceErrorException | InvalidArgumentException | TransactionInProgressException | CommonErrors;
/**
 * Delete a custom routing accelerator. Before you can delete an accelerator, you must disable it and remove all dependent resources
 * (listeners and endpoint groups). To disable the accelerator, update the accelerator to set `Enabled` to false.
 *
 * When you create a custom routing accelerator, by default, Global Accelerator provides you with a set of two static IP addresses.
 *
 * The IP
 * addresses are assigned to your accelerator for as long as it exists, even if you disable the accelerator and
 * it no longer accepts or routes traffic. However, when you *delete* an accelerator, you lose the
 * static IP addresses that are assigned to the accelerator, so you can no longer route traffic by using them.
 * As a best practice, ensure that you have permissions in place to avoid inadvertently deleting accelerators. You
 * can use IAM policies with Global Accelerator to limit the users who have permissions to delete an accelerator. For more information,
 * see Identity and access management in
 * the *Global Accelerator Developer Guide*.
 */
export declare const deleteCustomRoutingAccelerator: API.OperationMethod<DeleteCustomRoutingAcceleratorRequest, DeleteCustomRoutingAcceleratorResponse, DeleteCustomRoutingAcceleratorError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomRoutingEndpointGroupError = EndpointGroupNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Delete an endpoint group from a listener for a custom routing accelerator.
 */
export declare const deleteCustomRoutingEndpointGroup: API.OperationMethod<DeleteCustomRoutingEndpointGroupRequest, DeleteCustomRoutingEndpointGroupResponse, DeleteCustomRoutingEndpointGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomRoutingListenerError = AssociatedEndpointGroupFoundException | InternalServiceErrorException | InvalidArgumentException | ListenerNotFoundException | CommonErrors;
/**
 * Delete a listener for a custom routing accelerator.
 */
export declare const deleteCustomRoutingListener: API.OperationMethod<DeleteCustomRoutingListenerRequest, DeleteCustomRoutingListenerResponse, DeleteCustomRoutingListenerError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointGroupError = EndpointGroupNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Delete an endpoint group from a listener.
 */
export declare const deleteEndpointGroup: API.OperationMethod<DeleteEndpointGroupRequest, DeleteEndpointGroupResponse, DeleteEndpointGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteListenerError = AssociatedEndpointGroupFoundException | InternalServiceErrorException | InvalidArgumentException | ListenerNotFoundException | CommonErrors;
/**
 * Delete a listener from an accelerator.
 */
export declare const deleteListener: API.OperationMethod<DeleteListenerRequest, DeleteListenerResponse, DeleteListenerError, Credentials | HttpClient.HttpClient>;
export type DenyCustomRoutingTrafficError = EndpointGroupNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Specify the Amazon EC2 instance (destination) IP addresses and ports for a VPC subnet endpoint that cannot receive traffic
 * for a custom routing accelerator. You can deny traffic to all destinations in the VPC endpoint, or deny traffic to a
 * specified list of destination IP addresses and ports. Note that you cannot specify IP addresses
 * or ports outside of the range that you configured for the endpoint group.
 *
 * After you make changes, you can verify that the updates are complete by checking the status of your
 * accelerator: the status changes from IN_PROGRESS to DEPLOYED.
 */
export declare const denyCustomRoutingTraffic: API.OperationMethod<DenyCustomRoutingTrafficRequest, DenyCustomRoutingTrafficResponse, DenyCustomRoutingTrafficError, Credentials | HttpClient.HttpClient>;
export type DeprovisionByoipCidrError = AccessDeniedException | ByoipCidrNotFoundException | IncorrectCidrStateException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Releases the specified address range that you provisioned to use with your Amazon Web Services resources
 * through bring your own IP addresses (BYOIP) and deletes the corresponding address pool.
 *
 * Before you can release an address range, you must stop advertising it by using WithdrawByoipCidr and you must not have
 * any accelerators that are using static IP addresses allocated from its address range.
 *
 * For more information, see Bring
 * your own IP addresses (BYOIP) in the *Global Accelerator Developer Guide*.
 */
export declare const deprovisionByoipCidr: API.OperationMethod<DeprovisionByoipCidrRequest, DeprovisionByoipCidrResponse, DeprovisionByoipCidrError, Credentials | HttpClient.HttpClient>;
export type DescribeAcceleratorError = AcceleratorNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Describe an accelerator.
 */
export declare const describeAccelerator: API.OperationMethod<DescribeAcceleratorRequest, DescribeAcceleratorResponse, DescribeAcceleratorError, Credentials | HttpClient.HttpClient>;
export type DescribeAcceleratorAttributesError = AcceleratorNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Describe the attributes of an accelerator.
 */
export declare const describeAcceleratorAttributes: API.OperationMethod<DescribeAcceleratorAttributesRequest, DescribeAcceleratorAttributesResponse, DescribeAcceleratorAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeCrossAccountAttachmentError = AccessDeniedException | AttachmentNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Gets configuration information about a cross-account attachment.
 */
export declare const describeCrossAccountAttachment: API.OperationMethod<DescribeCrossAccountAttachmentRequest, DescribeCrossAccountAttachmentResponse, DescribeCrossAccountAttachmentError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomRoutingAcceleratorError = AcceleratorNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Describe a custom routing accelerator.
 */
export declare const describeCustomRoutingAccelerator: API.OperationMethod<DescribeCustomRoutingAcceleratorRequest, DescribeCustomRoutingAcceleratorResponse, DescribeCustomRoutingAcceleratorError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomRoutingAcceleratorAttributesError = AcceleratorNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Describe the attributes of a custom routing accelerator.
 */
export declare const describeCustomRoutingAcceleratorAttributes: API.OperationMethod<DescribeCustomRoutingAcceleratorAttributesRequest, DescribeCustomRoutingAcceleratorAttributesResponse, DescribeCustomRoutingAcceleratorAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomRoutingEndpointGroupError = EndpointGroupNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Describe an endpoint group for a custom routing accelerator.
 */
export declare const describeCustomRoutingEndpointGroup: API.OperationMethod<DescribeCustomRoutingEndpointGroupRequest, DescribeCustomRoutingEndpointGroupResponse, DescribeCustomRoutingEndpointGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomRoutingListenerError = InternalServiceErrorException | InvalidArgumentException | ListenerNotFoundException | CommonErrors;
/**
 * The description of a listener for a custom routing accelerator.
 */
export declare const describeCustomRoutingListener: API.OperationMethod<DescribeCustomRoutingListenerRequest, DescribeCustomRoutingListenerResponse, DescribeCustomRoutingListenerError, Credentials | HttpClient.HttpClient>;
export type DescribeEndpointGroupError = EndpointGroupNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Describe an endpoint group.
 */
export declare const describeEndpointGroup: API.OperationMethod<DescribeEndpointGroupRequest, DescribeEndpointGroupResponse, DescribeEndpointGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeListenerError = InternalServiceErrorException | InvalidArgumentException | ListenerNotFoundException | CommonErrors;
/**
 * Describe a listener.
 */
export declare const describeListener: API.OperationMethod<DescribeListenerRequest, DescribeListenerResponse, DescribeListenerError, Credentials | HttpClient.HttpClient>;
export type ListAcceleratorsError = InternalServiceErrorException | InvalidArgumentException | InvalidNextTokenException | CommonErrors;
/**
 * List the accelerators for an Amazon Web Services account.
 */
export declare const listAccelerators: API.PaginatedOperationMethod<ListAcceleratorsRequest, ListAcceleratorsResponse, ListAcceleratorsError, Credentials | HttpClient.HttpClient, Accelerator>;
export type ListByoipCidrsError = AccessDeniedException | InternalServiceErrorException | InvalidArgumentException | InvalidNextTokenException | CommonErrors;
/**
 * Lists the IP address ranges that were specified in calls to ProvisionByoipCidr, including
 * the current state and a history of state changes.
 */
export declare const listByoipCidrs: API.PaginatedOperationMethod<ListByoipCidrsRequest, ListByoipCidrsResponse, ListByoipCidrsError, Credentials | HttpClient.HttpClient, ByoipCidr>;
export type ListCrossAccountAttachmentsError = AccessDeniedException | InternalServiceErrorException | InvalidArgumentException | InvalidNextTokenException | CommonErrors;
/**
 * List the cross-account attachments that have been created in Global Accelerator.
 */
export declare const listCrossAccountAttachments: API.PaginatedOperationMethod<ListCrossAccountAttachmentsRequest, ListCrossAccountAttachmentsResponse, ListCrossAccountAttachmentsError, Credentials | HttpClient.HttpClient, Attachment>;
export type ListCrossAccountResourceAccountsError = AccessDeniedException | InternalServiceErrorException | CommonErrors;
/**
 * List the accounts that have cross-account resources.
 *
 * For more information, see
 * Working with cross-account attachments and resources in Global Accelerator in the
 * Global Accelerator Developer Guide.
 */
export declare const listCrossAccountResourceAccounts: API.OperationMethod<ListCrossAccountResourceAccountsRequest, ListCrossAccountResourceAccountsResponse, ListCrossAccountResourceAccountsError, Credentials | HttpClient.HttpClient>;
export type ListCrossAccountResourcesError = AcceleratorNotFoundException | AccessDeniedException | InternalServiceErrorException | InvalidArgumentException | InvalidNextTokenException | CommonErrors;
/**
 * List the cross-account resources available to work with.
 */
export declare const listCrossAccountResources: API.PaginatedOperationMethod<ListCrossAccountResourcesRequest, ListCrossAccountResourcesResponse, ListCrossAccountResourcesError, Credentials | HttpClient.HttpClient, CrossAccountResource>;
export type ListCustomRoutingAcceleratorsError = InternalServiceErrorException | InvalidArgumentException | InvalidNextTokenException | CommonErrors;
/**
 * List the custom routing accelerators for an Amazon Web Services account.
 */
export declare const listCustomRoutingAccelerators: API.PaginatedOperationMethod<ListCustomRoutingAcceleratorsRequest, ListCustomRoutingAcceleratorsResponse, ListCustomRoutingAcceleratorsError, Credentials | HttpClient.HttpClient, CustomRoutingAccelerator>;
export type ListCustomRoutingEndpointGroupsError = InternalServiceErrorException | InvalidArgumentException | InvalidNextTokenException | ListenerNotFoundException | CommonErrors;
/**
 * List the endpoint groups that are associated with a listener for a custom routing accelerator.
 */
export declare const listCustomRoutingEndpointGroups: API.PaginatedOperationMethod<ListCustomRoutingEndpointGroupsRequest, ListCustomRoutingEndpointGroupsResponse, ListCustomRoutingEndpointGroupsError, Credentials | HttpClient.HttpClient, CustomRoutingEndpointGroup>;
export type ListCustomRoutingListenersError = AcceleratorNotFoundException | InternalServiceErrorException | InvalidArgumentException | InvalidNextTokenException | CommonErrors;
/**
 * List the listeners for a custom routing accelerator.
 */
export declare const listCustomRoutingListeners: API.PaginatedOperationMethod<ListCustomRoutingListenersRequest, ListCustomRoutingListenersResponse, ListCustomRoutingListenersError, Credentials | HttpClient.HttpClient, CustomRoutingListener>;
export type ListCustomRoutingPortMappingsError = AcceleratorNotFoundException | EndpointGroupNotFoundException | InternalServiceErrorException | InvalidArgumentException | InvalidNextTokenException | CommonErrors;
/**
 * Provides a complete mapping from the public accelerator IP address and port to destination EC2 instance
 * IP addresses and ports in the virtual public cloud (VPC) subnet endpoint for a custom routing accelerator.
 * For each subnet endpoint that you add, Global Accelerator creates a new static port mapping for the accelerator. The port
 * mappings don't change after Global Accelerator generates them, so you can retrieve and cache the full mapping on your servers.
 *
 * If you remove a subnet from your accelerator, Global Accelerator removes (reclaims) the port mappings. If you add a subnet to
 * your accelerator, Global Accelerator creates new port mappings (the existing ones don't change). If you add or remove EC2 instances
 * in your subnet, the port mappings don't change, because the mappings are created when you add the subnet to Global Accelerator.
 *
 * The mappings also include a flag for each destination denoting which destination IP addresses and
 * ports are allowed or denied traffic.
 */
export declare const listCustomRoutingPortMappings: API.PaginatedOperationMethod<ListCustomRoutingPortMappingsRequest, ListCustomRoutingPortMappingsResponse, ListCustomRoutingPortMappingsError, Credentials | HttpClient.HttpClient, PortMapping>;
export type ListCustomRoutingPortMappingsByDestinationError = EndpointNotFoundException | InternalServiceErrorException | InvalidArgumentException | InvalidNextTokenException | CommonErrors;
/**
 * List the port mappings for a specific EC2 instance (destination) in a VPC subnet endpoint. The
 * response is the mappings for one destination IP address. This is useful when your subnet endpoint has mappings that
 * span multiple custom routing accelerators in your account, or for scenarios where you only want to
 * list the port mappings for a specific destination instance.
 */
export declare const listCustomRoutingPortMappingsByDestination: API.PaginatedOperationMethod<ListCustomRoutingPortMappingsByDestinationRequest, ListCustomRoutingPortMappingsByDestinationResponse, ListCustomRoutingPortMappingsByDestinationError, Credentials | HttpClient.HttpClient, DestinationPortMapping>;
export type ListEndpointGroupsError = InternalServiceErrorException | InvalidArgumentException | InvalidNextTokenException | ListenerNotFoundException | CommonErrors;
/**
 * List the endpoint groups that are associated with a listener.
 */
export declare const listEndpointGroups: API.PaginatedOperationMethod<ListEndpointGroupsRequest, ListEndpointGroupsResponse, ListEndpointGroupsError, Credentials | HttpClient.HttpClient, EndpointGroup>;
export type ListListenersError = AcceleratorNotFoundException | InternalServiceErrorException | InvalidArgumentException | InvalidNextTokenException | CommonErrors;
/**
 * List the listeners for an accelerator.
 */
export declare const listListeners: API.PaginatedOperationMethod<ListListenersRequest, ListListenersResponse, ListListenersError, Credentials | HttpClient.HttpClient, Listener>;
export type ListTagsForResourceError = AcceleratorNotFoundException | AttachmentNotFoundException | EndpointGroupNotFoundException | InternalServiceErrorException | InvalidArgumentException | ListenerNotFoundException | CommonErrors;
/**
 * List all tags for an accelerator.
 *
 * For more information, see Tagging
 * in Global Accelerator in the *Global Accelerator Developer Guide*.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ProvisionByoipCidrError = AccessDeniedException | IncorrectCidrStateException | InternalServiceErrorException | InvalidArgumentException | LimitExceededException | CommonErrors;
/**
 * Provisions an IP address range to use with your Amazon Web Services resources through bring your own IP
 * addresses (BYOIP) and creates a corresponding address pool. After the address range is provisioned,
 * it is ready to be advertised using
 * AdvertiseByoipCidr.
 *
 * For more information, see Bring your own
 * IP addresses (BYOIP) in the *Global Accelerator Developer Guide*.
 */
export declare const provisionByoipCidr: API.OperationMethod<ProvisionByoipCidrRequest, ProvisionByoipCidrResponse, ProvisionByoipCidrError, Credentials | HttpClient.HttpClient>;
export type RemoveCustomRoutingEndpointsError = AccessDeniedException | ConflictException | EndpointGroupNotFoundException | EndpointNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Remove endpoints from a custom routing accelerator.
 */
export declare const removeCustomRoutingEndpoints: API.OperationMethod<RemoveCustomRoutingEndpointsRequest, RemoveCustomRoutingEndpointsResponse, RemoveCustomRoutingEndpointsError, Credentials | HttpClient.HttpClient>;
export type RemoveEndpointsError = AccessDeniedException | EndpointGroupNotFoundException | InternalServiceErrorException | InvalidArgumentException | TransactionInProgressException | CommonErrors;
/**
 * Remove endpoints from an endpoint group.
 *
 * The `RemoveEndpoints` API operation is the recommended option for removing endpoints. The alternative is to remove
 * endpoints by updating an endpoint group by using the
 * UpdateEndpointGroup
 * API operation. There are two advantages to using `AddEndpoints` to remove endpoints instead:
 *
 * - It's more convenient, because you only need to specify the endpoints that you want to remove. With the
 * `UpdateEndpointGroup` API operation, you must specify all of the endpoints in the
 * endpoint group except the ones that you want to remove from the group.
 *
 * - It's faster, because Global Accelerator doesn't need to resolve any endpoints. With the
 * `UpdateEndpointGroup` API operation, Global Accelerator must resolve all of the endpoints that
 * remain in the group.
 */
export declare const removeEndpoints: API.OperationMethod<RemoveEndpointsRequest, RemoveEndpointsResponse, RemoveEndpointsError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AcceleratorNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Add tags to an accelerator resource.
 *
 * For more information, see Tagging
 * in Global Accelerator in the *Global Accelerator Developer Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AcceleratorNotFoundException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Remove tags from a Global Accelerator resource. When you specify a tag key, the action removes both that key and its associated value.
 * The operation succeeds even if you attempt to remove tags from an accelerator that was already removed.
 *
 * For more information, see Tagging
 * in Global Accelerator in the *Global Accelerator Developer Guide*.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAcceleratorError = AcceleratorNotFoundException | AccessDeniedException | ConflictException | InternalServiceErrorException | InvalidArgumentException | TransactionInProgressException | CommonErrors;
/**
 * Update an accelerator to make changes, such as the following:
 *
 * - Change the name of the accelerator.
 *
 * - Disable the accelerator so that it no longer accepts or routes traffic, or so that you can delete it.
 *
 * - Enable the accelerator, if it is disabled.
 *
 * - Change the IP address type to dual-stack if it is IPv4, or change the IP address type to IPv4 if it's dual-stack.
 *
 * Be aware that static IP addresses remain assigned to your accelerator for as long as it exists, even if you disable the accelerator and it no
 * longer accepts or routes traffic. However, when you delete the accelerator, you lose the static IP addresses that are assigned to it, so you
 * can no longer route traffic by using them.
 *
 * Global Accelerator is a global service that supports endpoints in multiple Amazon Web Services Regions but you must specify the
 * US West (Oregon) Region to create, update, or otherwise work with accelerators. That is, for example, specify `--region us-west-2`
 * on Amazon Web Services CLI commands.
 */
export declare const updateAccelerator: API.OperationMethod<UpdateAcceleratorRequest, UpdateAcceleratorResponse, UpdateAcceleratorError, Credentials | HttpClient.HttpClient>;
export type UpdateAcceleratorAttributesError = AcceleratorNotFoundException | AccessDeniedException | InternalServiceErrorException | InvalidArgumentException | TransactionInProgressException | CommonErrors;
/**
 * Update the attributes for an accelerator.
 */
export declare const updateAcceleratorAttributes: API.OperationMethod<UpdateAcceleratorAttributesRequest, UpdateAcceleratorAttributesResponse, UpdateAcceleratorAttributesError, Credentials | HttpClient.HttpClient>;
export type UpdateCrossAccountAttachmentError = AccessDeniedException | AttachmentNotFoundException | InternalServiceErrorException | InvalidArgumentException | LimitExceededException | TransactionInProgressException | CommonErrors;
/**
 * Update a cross-account attachment to add or remove principals or resources. When you update
 * an attachment to remove a principal (account ID or accelerator) or a resource, Global Accelerator
 * revokes the permission for specific resources.
 *
 * For more information, see
 * Working with cross-account attachments and resources in Global Accelerator in the
 * Global Accelerator Developer Guide.
 */
export declare const updateCrossAccountAttachment: API.OperationMethod<UpdateCrossAccountAttachmentRequest, UpdateCrossAccountAttachmentResponse, UpdateCrossAccountAttachmentError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomRoutingAcceleratorError = AcceleratorNotFoundException | ConflictException | InternalServiceErrorException | InvalidArgumentException | TransactionInProgressException | CommonErrors;
/**
 * Update a custom routing accelerator.
 */
export declare const updateCustomRoutingAccelerator: API.OperationMethod<UpdateCustomRoutingAcceleratorRequest, UpdateCustomRoutingAcceleratorResponse, UpdateCustomRoutingAcceleratorError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomRoutingAcceleratorAttributesError = AcceleratorNotFoundException | AccessDeniedException | InternalServiceErrorException | InvalidArgumentException | TransactionInProgressException | CommonErrors;
/**
 * Update the attributes for a custom routing accelerator.
 */
export declare const updateCustomRoutingAcceleratorAttributes: API.OperationMethod<UpdateCustomRoutingAcceleratorAttributesRequest, UpdateCustomRoutingAcceleratorAttributesResponse, UpdateCustomRoutingAcceleratorAttributesError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomRoutingListenerError = InternalServiceErrorException | InvalidArgumentException | InvalidPortRangeException | LimitExceededException | ListenerNotFoundException | CommonErrors;
/**
 * Update a listener for a custom routing accelerator.
 */
export declare const updateCustomRoutingListener: API.OperationMethod<UpdateCustomRoutingListenerRequest, UpdateCustomRoutingListenerResponse, UpdateCustomRoutingListenerError, Credentials | HttpClient.HttpClient>;
export type UpdateEndpointGroupError = AccessDeniedException | EndpointGroupNotFoundException | InternalServiceErrorException | InvalidArgumentException | LimitExceededException | CommonErrors;
/**
 * Update an endpoint group. A resource must be valid and active when you add it as an endpoint.
 */
export declare const updateEndpointGroup: API.OperationMethod<UpdateEndpointGroupRequest, UpdateEndpointGroupResponse, UpdateEndpointGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateListenerError = InternalServiceErrorException | InvalidArgumentException | InvalidPortRangeException | LimitExceededException | ListenerNotFoundException | CommonErrors;
/**
 * Update a listener.
 */
export declare const updateListener: API.OperationMethod<UpdateListenerRequest, UpdateListenerResponse, UpdateListenerError, Credentials | HttpClient.HttpClient>;
export type WithdrawByoipCidrError = AccessDeniedException | ByoipCidrNotFoundException | IncorrectCidrStateException | InternalServiceErrorException | InvalidArgumentException | CommonErrors;
/**
 * Stops advertising an address range that is provisioned as an address pool.
 * You can perform this operation at most once every 10 seconds, even if you specify different address
 * ranges each time.
 *
 * It can take a few minutes before traffic to the specified addresses stops routing to Amazon Web Services because of
 * propagation delays.
 *
 * For more information, see Bring your own
 * IP addresses (BYOIP) in the *Global Accelerator Developer Guide*.
 */
export declare const withdrawByoipCidr: API.OperationMethod<WithdrawByoipCidrRequest, WithdrawByoipCidrResponse, WithdrawByoipCidrError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=global-accelerator.d.ts.map