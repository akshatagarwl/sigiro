import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
    readonly resourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AdvancedPromptOptimizationJobIdentifier = string;
export type AdvancedPromptOptimizationJobIdentifiers = string[];
export declare const AdvancedPromptOptimizationJobIdentifiers: any;
export interface BatchDeleteAdvancedPromptOptimizationJobRequest {
    jobIdentifiers: string[];
}
export declare const BatchDeleteAdvancedPromptOptimizationJobRequest: S.Schema<BatchDeleteAdvancedPromptOptimizationJobRequest>;
export interface BatchDeleteAdvancedPromptOptimizationJobError_ {
    jobIdentifier: string;
    code: string;
    message?: string;
}
export declare const BatchDeleteAdvancedPromptOptimizationJobError_: S.Schema<BatchDeleteAdvancedPromptOptimizationJobError_>;
export type BatchDeleteAdvancedPromptOptimizationJobErrors = BatchDeleteAdvancedPromptOptimizationJobError_[];
export declare const BatchDeleteAdvancedPromptOptimizationJobErrors: any;
export type AdvancedPromptOptimizationJobStatus = "InProgress" | "Completed" | "Failed" | "PartiallyCompleted" | "Stopping" | "Stopped" | "Deleting" | (string & {});
export declare const AdvancedPromptOptimizationJobStatus: any;
export interface BatchDeleteAdvancedPromptOptimizationJobItem {
    jobIdentifier: string;
    jobStatus: AdvancedPromptOptimizationJobStatus;
}
export declare const BatchDeleteAdvancedPromptOptimizationJobItem: S.Schema<BatchDeleteAdvancedPromptOptimizationJobItem>;
export type BatchDeleteAdvancedPromptOptimizationJobItems = BatchDeleteAdvancedPromptOptimizationJobItem[];
export declare const BatchDeleteAdvancedPromptOptimizationJobItems: any;
export interface BatchDeleteAdvancedPromptOptimizationJobResponse {
    errors: BatchDeleteAdvancedPromptOptimizationJobError_[];
    advancedPromptOptimizationJobs: BatchDeleteAdvancedPromptOptimizationJobItem[];
}
export declare const BatchDeleteAdvancedPromptOptimizationJobResponse: S.Schema<BatchDeleteAdvancedPromptOptimizationJobResponse>;
export type EvaluationJobIdentifier = string | redacted.Redacted<string>;
export type EvaluationJobIdentifiers = (string | redacted.Redacted<string>)[];
export declare const EvaluationJobIdentifiers: any;
export interface BatchDeleteEvaluationJobRequest {
    jobIdentifiers: (string | redacted.Redacted<string>)[];
}
export declare const BatchDeleteEvaluationJobRequest: S.Schema<BatchDeleteEvaluationJobRequest>;
export interface BatchDeleteEvaluationJobError_ {
    jobIdentifier: string | redacted.Redacted<string>;
    code: string;
    message?: string;
}
export declare const BatchDeleteEvaluationJobError_: S.Schema<BatchDeleteEvaluationJobError_>;
export type BatchDeleteEvaluationJobErrors = BatchDeleteEvaluationJobError_[];
export declare const BatchDeleteEvaluationJobErrors: any;
export type EvaluationJobStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | "Deleting" | (string & {});
export declare const EvaluationJobStatus: any;
export interface BatchDeleteEvaluationJobItem {
    jobIdentifier: string | redacted.Redacted<string>;
    jobStatus: EvaluationJobStatus;
}
export declare const BatchDeleteEvaluationJobItem: S.Schema<BatchDeleteEvaluationJobItem>;
export type BatchDeleteEvaluationJobItems = BatchDeleteEvaluationJobItem[];
export declare const BatchDeleteEvaluationJobItems: any;
export interface BatchDeleteEvaluationJobResponse {
    errors: BatchDeleteEvaluationJobError_[];
    evaluationJobs: BatchDeleteEvaluationJobItem[];
}
export declare const BatchDeleteEvaluationJobResponse: S.Schema<BatchDeleteEvaluationJobResponse>;
export type AutomatedReasoningPolicyArn = string;
export type AutomatedReasoningPolicyBuildWorkflowId = string;
export interface CancelAutomatedReasoningPolicyBuildWorkflowRequest {
    policyArn: string;
    buildWorkflowId: string;
}
export declare const CancelAutomatedReasoningPolicyBuildWorkflowRequest: S.Schema<CancelAutomatedReasoningPolicyBuildWorkflowRequest>;
export interface CancelAutomatedReasoningPolicyBuildWorkflowResponse {
}
export declare const CancelAutomatedReasoningPolicyBuildWorkflowResponse: S.Schema<CancelAutomatedReasoningPolicyBuildWorkflowResponse>;
export type AdvancedPromptOptimizationJobName = string;
export type AdvancedPromptOptimizationJobDescription = string;
export type IdempotencyToken = string;
export type S3Uri = string;
export interface AdvancedPromptOptimizationInputConfig {
    s3Uri: string;
}
export declare const AdvancedPromptOptimizationInputConfig: S.Schema<AdvancedPromptOptimizationInputConfig>;
export type S3UriFolder = string;
export interface AdvancedPromptOptimizationOutputConfig {
    s3Uri: string;
}
export declare const AdvancedPromptOptimizationOutputConfig: S.Schema<AdvancedPromptOptimizationOutputConfig>;
export type KmsKeyArn = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type AdvancedPromptOptimizationModelIdentifier = string;
export type NonEmptyStringList = string[];
export declare const NonEmptyStringList: any;
export interface InferenceConfiguration {
    maxTokens?: number;
    temperature?: number;
    topP?: number;
    stopSequences?: string[];
}
export declare const InferenceConfiguration: S.Schema<InferenceConfiguration>;
export type AdditionalModelRequestFieldsKey = string;
export type AdditionalModelRequestFieldsValue = unknown;
export type AdditionalModelRequestFields = {
    [key: string]: any | undefined;
};
export declare const AdditionalModelRequestFields: any;
export interface ModelConfiguration {
    modelId: string;
    inferenceConfig?: InferenceConfiguration;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    };
}
export declare const ModelConfiguration: S.Schema<ModelConfiguration>;
export type ModelConfigurations = ModelConfiguration[];
export declare const ModelConfigurations: any;
export interface CreateAdvancedPromptOptimizationJobRequest {
    jobName: string;
    jobDescription?: string;
    clientToken?: string;
    inputConfig: AdvancedPromptOptimizationInputConfig;
    outputConfig: AdvancedPromptOptimizationOutputConfig;
    encryptionKeyArn?: string;
    tags?: Tag[];
    modelConfigurations: ModelConfiguration[];
}
export declare const CreateAdvancedPromptOptimizationJobRequest: S.Schema<CreateAdvancedPromptOptimizationJobRequest>;
export type AdvancedPromptOptimizationJobArn = string;
export interface CreateAdvancedPromptOptimizationJobResponse {
    jobArn: string;
}
export declare const CreateAdvancedPromptOptimizationJobResponse: S.Schema<CreateAdvancedPromptOptimizationJobResponse>;
export type AutomatedReasoningPolicyName = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyDescription = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyFormatVersion = string;
export type AutomatedReasoningPolicyDefinitionTypeName = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyDefinitionTypeDescription = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyDefinitionTypeValueName = string;
export type AutomatedReasoningPolicyDefinitionTypeValueDescription = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyDefinitionTypeValue {
    value: string;
    description?: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyDefinitionTypeValue: S.Schema<AutomatedReasoningPolicyDefinitionTypeValue>;
export type AutomatedReasoningPolicyDefinitionTypeValueList = AutomatedReasoningPolicyDefinitionTypeValue[];
export declare const AutomatedReasoningPolicyDefinitionTypeValueList: any;
export interface AutomatedReasoningPolicyDefinitionType {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    values: AutomatedReasoningPolicyDefinitionTypeValue[];
}
export declare const AutomatedReasoningPolicyDefinitionType: S.Schema<AutomatedReasoningPolicyDefinitionType>;
export type AutomatedReasoningPolicyDefinitionTypeList = AutomatedReasoningPolicyDefinitionType[];
export declare const AutomatedReasoningPolicyDefinitionTypeList: any;
export type AutomatedReasoningPolicyDefinitionRuleId = string;
export type AutomatedReasoningPolicyDefinitionRuleExpression = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyDefinitionRuleAlternateExpression = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyDefinitionRule {
    id: string;
    expression: string | redacted.Redacted<string>;
    alternateExpression?: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyDefinitionRule: S.Schema<AutomatedReasoningPolicyDefinitionRule>;
export type AutomatedReasoningPolicyDefinitionRuleList = AutomatedReasoningPolicyDefinitionRule[];
export declare const AutomatedReasoningPolicyDefinitionRuleList: any;
export type AutomatedReasoningPolicyDefinitionVariableName = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyDefinitionVariableDescription = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyDefinitionVariable {
    name: string | redacted.Redacted<string>;
    type: string | redacted.Redacted<string>;
    description: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyDefinitionVariable: S.Schema<AutomatedReasoningPolicyDefinitionVariable>;
export type AutomatedReasoningPolicyDefinitionVariableList = AutomatedReasoningPolicyDefinitionVariable[];
export declare const AutomatedReasoningPolicyDefinitionVariableList: any;
export interface AutomatedReasoningPolicyDefinition {
    version?: string;
    types?: AutomatedReasoningPolicyDefinitionType[];
    rules?: AutomatedReasoningPolicyDefinitionRule[];
    variables?: AutomatedReasoningPolicyDefinitionVariable[];
}
export declare const AutomatedReasoningPolicyDefinition: S.Schema<AutomatedReasoningPolicyDefinition>;
export type KmsKeyId = string;
export interface CreateAutomatedReasoningPolicyRequest {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    clientRequestToken?: string;
    policyDefinition?: AutomatedReasoningPolicyDefinition;
    kmsKeyId?: string;
    tags?: Tag[];
}
export declare const CreateAutomatedReasoningPolicyRequest: S.Schema<CreateAutomatedReasoningPolicyRequest>;
export type AutomatedReasoningPolicyVersion = string;
export type AutomatedReasoningPolicyHash = string;
export interface CreateAutomatedReasoningPolicyResponse {
    policyArn: string;
    version: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    definitionHash?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const CreateAutomatedReasoningPolicyResponse: S.Schema<CreateAutomatedReasoningPolicyResponse>;
export type AutomatedReasoningPolicyTestGuardContent = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyTestQueryContent = string | redacted.Redacted<string>;
export type AutomatedReasoningCheckResult = "VALID" | "INVALID" | "SATISFIABLE" | "IMPOSSIBLE" | "TRANSLATION_AMBIGUOUS" | "TOO_COMPLEX" | "NO_TRANSLATION" | (string & {});
export declare const AutomatedReasoningCheckResult: any;
export type AutomatedReasoningCheckTranslationConfidence = number;
export interface CreateAutomatedReasoningPolicyTestCaseRequest {
    policyArn: string;
    guardContent: string | redacted.Redacted<string>;
    queryContent?: string | redacted.Redacted<string>;
    expectedAggregatedFindingsResult: AutomatedReasoningCheckResult;
    clientRequestToken?: string;
    confidenceThreshold?: number;
}
export declare const CreateAutomatedReasoningPolicyTestCaseRequest: S.Schema<CreateAutomatedReasoningPolicyTestCaseRequest>;
export type AutomatedReasoningPolicyTestCaseId = string;
export interface CreateAutomatedReasoningPolicyTestCaseResponse {
    policyArn: string;
    testCaseId: string;
}
export declare const CreateAutomatedReasoningPolicyTestCaseResponse: S.Schema<CreateAutomatedReasoningPolicyTestCaseResponse>;
export interface CreateAutomatedReasoningPolicyVersionRequest {
    policyArn: string;
    clientRequestToken?: string;
    lastUpdatedDefinitionHash: string;
    tags?: Tag[];
}
export declare const CreateAutomatedReasoningPolicyVersionRequest: S.Schema<CreateAutomatedReasoningPolicyVersionRequest>;
export interface CreateAutomatedReasoningPolicyVersionResponse {
    policyArn: string;
    version: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    definitionHash: string;
    createdAt: Date;
}
export declare const CreateAutomatedReasoningPolicyVersionResponse: S.Schema<CreateAutomatedReasoningPolicyVersionResponse>;
export type CustomModelName = string;
export interface S3DataSource {
    s3Uri: string;
}
export declare const S3DataSource: S.Schema<S3DataSource>;
export type ModelDataSource = {
    s3DataSource: S3DataSource;
};
export declare const ModelDataSource: any;
export type ModelPackageArn = string;
export interface ModelPackageArnDataSource {
    modelPackageArn: string;
}
export declare const ModelPackageArnDataSource: S.Schema<ModelPackageArnDataSource>;
export type CustomModelDataSource = {
    modelPackageArnDataSource: ModelPackageArnDataSource;
};
export declare const CustomModelDataSource: any;
export type RoleArn = string;
export interface CreateCustomModelRequest {
    modelName: string;
    modelSourceConfig?: ModelDataSource;
    customModelDataSource?: CustomModelDataSource;
    modelKmsKeyArn?: string;
    roleArn?: string;
    modelTags?: Tag[];
    clientRequestToken?: string;
}
export declare const CreateCustomModelRequest: S.Schema<CreateCustomModelRequest>;
export type ModelArn = string;
export interface CreateCustomModelResponse {
    modelArn: string;
}
export declare const CreateCustomModelResponse: S.Schema<CreateCustomModelResponse>;
export type ModelDeploymentName = string;
export type CustomModelArn = string;
export type CustomModelDeploymentDescription = string;
export interface CreateCustomModelDeploymentRequest {
    modelDeploymentName: string;
    modelArn: string;
    description?: string;
    tags?: Tag[];
    clientRequestToken?: string;
}
export declare const CreateCustomModelDeploymentRequest: S.Schema<CreateCustomModelDeploymentRequest>;
export type CustomModelDeploymentArn = string;
export interface CreateCustomModelDeploymentResponse {
    customModelDeploymentArn: string;
}
export declare const CreateCustomModelDeploymentResponse: S.Schema<CreateCustomModelDeploymentResponse>;
export type EvaluationJobName = string;
export type EvaluationJobDescription = string | redacted.Redacted<string>;
export type ApplicationType = "ModelEvaluation" | "RagEvaluation" | (string & {});
export declare const ApplicationType: any;
export type EvaluationTaskType = "Summarization" | "Classification" | "QuestionAndAnswer" | "Generation" | "Custom" | (string & {});
export declare const EvaluationTaskType: any;
export type EvaluationDatasetName = string | redacted.Redacted<string>;
export type EvaluationDatasetLocation = {
    s3Uri: string;
};
export declare const EvaluationDatasetLocation: any;
export interface EvaluationDataset {
    name: string | redacted.Redacted<string>;
    datasetLocation?: EvaluationDatasetLocation;
}
export declare const EvaluationDataset: S.Schema<EvaluationDataset>;
export type EvaluationMetricName = string | redacted.Redacted<string>;
export type EvaluationMetricNames = (string | redacted.Redacted<string>)[];
export declare const EvaluationMetricNames: any;
export interface EvaluationDatasetMetricConfig {
    taskType: EvaluationTaskType;
    dataset: EvaluationDataset;
    metricNames: (string | redacted.Redacted<string>)[];
}
export declare const EvaluationDatasetMetricConfig: S.Schema<EvaluationDatasetMetricConfig>;
export type EvaluationDatasetMetricConfigs = EvaluationDatasetMetricConfig[];
export declare const EvaluationDatasetMetricConfigs: any;
export type EvaluatorModelIdentifier = string;
export interface BedrockEvaluatorModel {
    modelIdentifier: string;
}
export declare const BedrockEvaluatorModel: S.Schema<BedrockEvaluatorModel>;
export type BedrockEvaluatorModels = BedrockEvaluatorModel[];
export declare const BedrockEvaluatorModels: any;
export type EvaluatorModelConfig = {
    bedrockEvaluatorModels: BedrockEvaluatorModel[];
};
export declare const EvaluatorModelConfig: any;
export type MetricName = string | redacted.Redacted<string>;
export type CustomMetricInstructions = string;
export type RatingScaleItemDefinition = string;
export type RatingScaleItemValue = {
    stringValue: string;
    floatValue?: never;
} | {
    stringValue?: never;
    floatValue: number;
};
export declare const RatingScaleItemValue: any;
export interface RatingScaleItem {
    definition: string;
    value: RatingScaleItemValue;
}
export declare const RatingScaleItem: S.Schema<RatingScaleItem>;
export type RatingScale = RatingScaleItem[];
export declare const RatingScale: any;
export interface CustomMetricDefinition {
    name: string | redacted.Redacted<string>;
    instructions: string;
    ratingScale?: RatingScaleItem[];
}
export declare const CustomMetricDefinition: S.Schema<CustomMetricDefinition>;
export type AutomatedEvaluationCustomMetricSource = {
    customMetricDefinition: CustomMetricDefinition;
};
export declare const AutomatedEvaluationCustomMetricSource: any;
export type AutomatedEvaluationCustomMetrics = AutomatedEvaluationCustomMetricSource[];
export declare const AutomatedEvaluationCustomMetrics: any;
export interface CustomMetricBedrockEvaluatorModel {
    modelIdentifier: string;
}
export declare const CustomMetricBedrockEvaluatorModel: S.Schema<CustomMetricBedrockEvaluatorModel>;
export type CustomMetricBedrockEvaluatorModels = CustomMetricBedrockEvaluatorModel[];
export declare const CustomMetricBedrockEvaluatorModels: any;
export interface CustomMetricEvaluatorModelConfig {
    bedrockEvaluatorModels: CustomMetricBedrockEvaluatorModel[];
}
export declare const CustomMetricEvaluatorModelConfig: S.Schema<CustomMetricEvaluatorModelConfig>;
export interface AutomatedEvaluationCustomMetricConfig {
    customMetrics: AutomatedEvaluationCustomMetricSource[];
    evaluatorModelConfig: CustomMetricEvaluatorModelConfig;
}
export declare const AutomatedEvaluationCustomMetricConfig: S.Schema<AutomatedEvaluationCustomMetricConfig>;
export interface AutomatedEvaluationConfig {
    datasetMetricConfigs: EvaluationDatasetMetricConfig[];
    evaluatorModelConfig?: EvaluatorModelConfig;
    customMetricConfig?: AutomatedEvaluationCustomMetricConfig;
}
export declare const AutomatedEvaluationConfig: S.Schema<AutomatedEvaluationConfig>;
export type SageMakerFlowDefinitionArn = string;
export type HumanTaskInstructions = string | redacted.Redacted<string>;
export interface HumanWorkflowConfig {
    flowDefinitionArn: string;
    instructions?: string | redacted.Redacted<string>;
}
export declare const HumanWorkflowConfig: S.Schema<HumanWorkflowConfig>;
export type EvaluationMetricDescription = string | redacted.Redacted<string>;
export type EvaluationRatingMethod = string;
export interface HumanEvaluationCustomMetric {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    ratingMethod: string;
}
export declare const HumanEvaluationCustomMetric: S.Schema<HumanEvaluationCustomMetric>;
export type HumanEvaluationCustomMetrics = HumanEvaluationCustomMetric[];
export declare const HumanEvaluationCustomMetrics: any;
export interface HumanEvaluationConfig {
    humanWorkflowConfig?: HumanWorkflowConfig;
    customMetrics?: HumanEvaluationCustomMetric[];
    datasetMetricConfigs: EvaluationDatasetMetricConfig[];
}
export declare const HumanEvaluationConfig: S.Schema<HumanEvaluationConfig>;
export type EvaluationConfig = {
    automated: AutomatedEvaluationConfig;
    human?: never;
} | {
    automated?: never;
    human: HumanEvaluationConfig;
};
export declare const EvaluationConfig: any;
export type EvaluationBedrockModelIdentifier = string;
export type EvaluationModelInferenceParams = string | redacted.Redacted<string>;
export type PerformanceConfigLatency = "standard" | "optimized" | (string & {});
export declare const PerformanceConfigLatency: any;
export interface PerformanceConfiguration {
    latency?: PerformanceConfigLatency;
}
export declare const PerformanceConfiguration: S.Schema<PerformanceConfiguration>;
export interface EvaluationBedrockModel {
    modelIdentifier: string;
    inferenceParams?: string | redacted.Redacted<string>;
    performanceConfig?: PerformanceConfiguration;
}
export declare const EvaluationBedrockModel: S.Schema<EvaluationBedrockModel>;
export type EvaluationPrecomputedInferenceSourceIdentifier = string;
export interface EvaluationPrecomputedInferenceSource {
    inferenceSourceIdentifier: string;
}
export declare const EvaluationPrecomputedInferenceSource: S.Schema<EvaluationPrecomputedInferenceSource>;
export type EvaluationModelConfig = {
    bedrockModel: EvaluationBedrockModel;
    precomputedInferenceSource?: never;
} | {
    bedrockModel?: never;
    precomputedInferenceSource: EvaluationPrecomputedInferenceSource;
};
export declare const EvaluationModelConfig: any;
export type EvaluationModelConfigs = EvaluationModelConfig[];
export declare const EvaluationModelConfigs: any;
export type KnowledgeBaseId = string;
export type SearchType = "HYBRID" | "SEMANTIC" | (string & {});
export declare const SearchType: any;
export type FilterKey = string;
export type FilterValue = unknown;
export interface FilterAttribute {
    key: string;
    value: any;
}
export declare const FilterAttribute: S.Schema<FilterAttribute>;
export type RetrievalFilterList = RetrievalFilter[];
export declare const RetrievalFilterList: S.Schema<RetrievalFilterList>;
export type RetrievalFilter = {
    equals: FilterAttribute;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals: FilterAttribute;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan: FilterAttribute;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals: FilterAttribute;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan: FilterAttribute;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals: FilterAttribute;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in: FilterAttribute;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn: FilterAttribute;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith: FilterAttribute;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains: FilterAttribute;
    stringContains?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains: FilterAttribute;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll: RetrievalFilter[];
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    in?: never;
    notIn?: never;
    startsWith?: never;
    listContains?: never;
    stringContains?: never;
    andAll?: never;
    orAll: RetrievalFilter[];
};
export declare const RetrievalFilter: S.Schema<RetrievalFilter>;
export type AttributeType = "STRING" | "NUMBER" | "BOOLEAN" | "STRING_LIST" | (string & {});
export declare const AttributeType: any;
export interface MetadataAttributeSchema {
    key: string;
    type: AttributeType;
    description: string;
}
export declare const MetadataAttributeSchema: S.Schema<MetadataAttributeSchema>;
export type MetadataAttributeSchemaList = MetadataAttributeSchema[];
export declare const MetadataAttributeSchemaList: any;
export type BedrockModelArn = string;
export interface ImplicitFilterConfiguration {
    metadataAttributes: MetadataAttributeSchema[];
    modelArn: string;
}
export declare const ImplicitFilterConfiguration: S.Schema<ImplicitFilterConfiguration>;
export type VectorSearchRerankingConfigurationType = "BEDROCK_RERANKING_MODEL" | (string & {});
export declare const VectorSearchRerankingConfigurationType: any;
export type BedrockRerankingModelArn = string;
export interface VectorSearchBedrockRerankingModelConfiguration {
    modelArn: string;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    };
}
export declare const VectorSearchBedrockRerankingModelConfiguration: S.Schema<VectorSearchBedrockRerankingModelConfiguration>;
export type RerankingMetadataSelectionMode = "SELECTIVE" | "ALL" | (string & {});
export declare const RerankingMetadataSelectionMode: any;
export interface FieldForReranking {
    fieldName: string;
}
export declare const FieldForReranking: S.Schema<FieldForReranking>;
export type FieldsForReranking = FieldForReranking[];
export declare const FieldsForReranking: any;
export type RerankingMetadataSelectiveModeConfiguration = {
    fieldsToInclude: FieldForReranking[];
    fieldsToExclude?: never;
} | {
    fieldsToInclude?: never;
    fieldsToExclude: FieldForReranking[];
};
export declare const RerankingMetadataSelectiveModeConfiguration: any;
export interface MetadataConfigurationForReranking {
    selectionMode: RerankingMetadataSelectionMode;
    selectiveModeConfiguration?: RerankingMetadataSelectiveModeConfiguration;
}
export declare const MetadataConfigurationForReranking: S.Schema<MetadataConfigurationForReranking>;
export interface VectorSearchBedrockRerankingConfiguration {
    modelConfiguration: VectorSearchBedrockRerankingModelConfiguration;
    numberOfRerankedResults?: number;
    metadataConfiguration?: MetadataConfigurationForReranking;
}
export declare const VectorSearchBedrockRerankingConfiguration: S.Schema<VectorSearchBedrockRerankingConfiguration>;
export interface VectorSearchRerankingConfiguration {
    type: VectorSearchRerankingConfigurationType;
    bedrockRerankingConfiguration?: VectorSearchBedrockRerankingConfiguration;
}
export declare const VectorSearchRerankingConfiguration: S.Schema<VectorSearchRerankingConfiguration>;
export interface KnowledgeBaseVectorSearchConfiguration {
    numberOfResults?: number;
    overrideSearchType?: SearchType;
    filter?: RetrievalFilter;
    implicitFilterConfiguration?: ImplicitFilterConfiguration;
    rerankingConfiguration?: VectorSearchRerankingConfiguration;
}
export declare const KnowledgeBaseVectorSearchConfiguration: S.Schema<KnowledgeBaseVectorSearchConfiguration>;
export interface KnowledgeBaseRetrievalConfiguration {
    vectorSearchConfiguration: KnowledgeBaseVectorSearchConfiguration;
}
export declare const KnowledgeBaseRetrievalConfiguration: S.Schema<KnowledgeBaseRetrievalConfiguration>;
export interface RetrieveConfig {
    knowledgeBaseId: string;
    knowledgeBaseRetrievalConfiguration: KnowledgeBaseRetrievalConfiguration;
}
export declare const RetrieveConfig: S.Schema<RetrieveConfig>;
export type RetrieveAndGenerateType = "KNOWLEDGE_BASE" | "EXTERNAL_SOURCES" | (string & {});
export declare const RetrieveAndGenerateType: any;
export type TextPromptTemplate = string | redacted.Redacted<string>;
export interface PromptTemplate {
    textPromptTemplate?: string | redacted.Redacted<string>;
}
export declare const PromptTemplate: S.Schema<PromptTemplate>;
export interface GuardrailConfiguration {
    guardrailId: string;
    guardrailVersion: string;
}
export declare const GuardrailConfiguration: S.Schema<GuardrailConfiguration>;
export type Temperature = number;
export type TopP = number;
export type MaxTokens = number;
export type RAGStopSequences = string[];
export declare const RAGStopSequences: any;
export interface TextInferenceConfig {
    temperature?: number;
    topP?: number;
    maxTokens?: number;
    stopSequences?: string[];
}
export declare const TextInferenceConfig: S.Schema<TextInferenceConfig>;
export interface KbInferenceConfig {
    textInferenceConfig?: TextInferenceConfig;
}
export declare const KbInferenceConfig: S.Schema<KbInferenceConfig>;
export interface GenerationConfiguration {
    promptTemplate?: PromptTemplate;
    guardrailConfiguration?: GuardrailConfiguration;
    kbInferenceConfig?: KbInferenceConfig;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    };
}
export declare const GenerationConfiguration: S.Schema<GenerationConfiguration>;
export type QueryTransformationType = "QUERY_DECOMPOSITION" | (string & {});
export declare const QueryTransformationType: any;
export interface QueryTransformationConfiguration {
    type: QueryTransformationType;
}
export declare const QueryTransformationConfiguration: S.Schema<QueryTransformationConfiguration>;
export interface OrchestrationConfiguration {
    queryTransformationConfiguration: QueryTransformationConfiguration;
}
export declare const OrchestrationConfiguration: S.Schema<OrchestrationConfiguration>;
export interface KnowledgeBaseRetrieveAndGenerateConfiguration {
    knowledgeBaseId: string;
    modelArn: string;
    retrievalConfiguration?: KnowledgeBaseRetrievalConfiguration;
    generationConfiguration?: GenerationConfiguration;
    orchestrationConfiguration?: OrchestrationConfiguration;
}
export declare const KnowledgeBaseRetrieveAndGenerateConfiguration: S.Schema<KnowledgeBaseRetrieveAndGenerateConfiguration>;
export type ExternalSourceType = "S3" | "BYTE_CONTENT" | (string & {});
export declare const ExternalSourceType: any;
export type KBS3Uri = string;
export interface S3ObjectDoc {
    uri: string;
}
export declare const S3ObjectDoc: S.Schema<S3ObjectDoc>;
export type Identifier = string | redacted.Redacted<string>;
export type ContentType = string;
export type ByteContentBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface ByteContentDoc {
    identifier: string | redacted.Redacted<string>;
    contentType: string;
    data: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const ByteContentDoc: S.Schema<ByteContentDoc>;
export interface ExternalSource {
    sourceType: ExternalSourceType;
    s3Location?: S3ObjectDoc;
    byteContent?: ByteContentDoc;
}
export declare const ExternalSource: S.Schema<ExternalSource>;
export type ExternalSources = ExternalSource[];
export declare const ExternalSources: any;
export interface ExternalSourcesGenerationConfiguration {
    promptTemplate?: PromptTemplate;
    guardrailConfiguration?: GuardrailConfiguration;
    kbInferenceConfig?: KbInferenceConfig;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    };
}
export declare const ExternalSourcesGenerationConfiguration: S.Schema<ExternalSourcesGenerationConfiguration>;
export interface ExternalSourcesRetrieveAndGenerateConfiguration {
    modelArn: string;
    sources: ExternalSource[];
    generationConfiguration?: ExternalSourcesGenerationConfiguration;
}
export declare const ExternalSourcesRetrieveAndGenerateConfiguration: S.Schema<ExternalSourcesRetrieveAndGenerateConfiguration>;
export interface RetrieveAndGenerateConfiguration {
    type: RetrieveAndGenerateType;
    knowledgeBaseConfiguration?: KnowledgeBaseRetrieveAndGenerateConfiguration;
    externalSourcesConfiguration?: ExternalSourcesRetrieveAndGenerateConfiguration;
}
export declare const RetrieveAndGenerateConfiguration: S.Schema<RetrieveAndGenerateConfiguration>;
export type KnowledgeBaseConfig = {
    retrieveConfig: RetrieveConfig;
    retrieveAndGenerateConfig?: never;
} | {
    retrieveConfig?: never;
    retrieveAndGenerateConfig: RetrieveAndGenerateConfiguration;
};
export declare const KnowledgeBaseConfig: any;
export type EvaluationPrecomputedRagSourceIdentifier = string;
export interface EvaluationPrecomputedRetrieveSourceConfig {
    ragSourceIdentifier: string;
}
export declare const EvaluationPrecomputedRetrieveSourceConfig: S.Schema<EvaluationPrecomputedRetrieveSourceConfig>;
export interface EvaluationPrecomputedRetrieveAndGenerateSourceConfig {
    ragSourceIdentifier: string;
}
export declare const EvaluationPrecomputedRetrieveAndGenerateSourceConfig: S.Schema<EvaluationPrecomputedRetrieveAndGenerateSourceConfig>;
export type EvaluationPrecomputedRagSourceConfig = {
    retrieveSourceConfig: EvaluationPrecomputedRetrieveSourceConfig;
    retrieveAndGenerateSourceConfig?: never;
} | {
    retrieveSourceConfig?: never;
    retrieveAndGenerateSourceConfig: EvaluationPrecomputedRetrieveAndGenerateSourceConfig;
};
export declare const EvaluationPrecomputedRagSourceConfig: any;
export type RAGConfig = {
    knowledgeBaseConfig: KnowledgeBaseConfig;
    precomputedRagSourceConfig?: never;
} | {
    knowledgeBaseConfig?: never;
    precomputedRagSourceConfig: EvaluationPrecomputedRagSourceConfig;
};
export declare const RAGConfig: any;
export type RagConfigs = RAGConfig[];
export declare const RagConfigs: any;
export type EvaluationInferenceConfig = {
    models: EvaluationModelConfig[];
    ragConfigs?: never;
} | {
    models?: never;
    ragConfigs: RAGConfig[];
};
export declare const EvaluationInferenceConfig: any;
export interface EvaluationOutputDataConfig {
    s3Uri: string;
}
export declare const EvaluationOutputDataConfig: S.Schema<EvaluationOutputDataConfig>;
export interface CreateEvaluationJobRequest {
    jobName: string;
    jobDescription?: string | redacted.Redacted<string>;
    clientRequestToken?: string;
    roleArn: string;
    customerEncryptionKeyId?: string;
    jobTags?: Tag[];
    applicationType?: ApplicationType;
    evaluationConfig: EvaluationConfig;
    inferenceConfig: EvaluationInferenceConfig;
    outputDataConfig: EvaluationOutputDataConfig;
}
export declare const CreateEvaluationJobRequest: S.Schema<CreateEvaluationJobRequest>;
export type EvaluationJobArn = string;
export interface CreateEvaluationJobResponse {
    jobArn: string;
}
export declare const CreateEvaluationJobResponse: S.Schema<CreateEvaluationJobResponse>;
export type OfferToken = string;
export type BedrockModelId = string;
export interface CreateFoundationModelAgreementRequest {
    offerToken: string;
    modelId: string;
}
export declare const CreateFoundationModelAgreementRequest: S.Schema<CreateFoundationModelAgreementRequest>;
export interface CreateFoundationModelAgreementResponse {
    modelId: string;
}
export declare const CreateFoundationModelAgreementResponse: S.Schema<CreateFoundationModelAgreementResponse>;
export type GuardrailName = string | redacted.Redacted<string>;
export type GuardrailDescription = string | redacted.Redacted<string>;
export type GuardrailTopicName = string | redacted.Redacted<string>;
export type GuardrailTopicDefinition = string | redacted.Redacted<string>;
export type GuardrailTopicExample = string | redacted.Redacted<string>;
export type GuardrailTopicExamples = (string | redacted.Redacted<string>)[];
export declare const GuardrailTopicExamples: any;
export type GuardrailTopicType = "DENY" | (string & {});
export declare const GuardrailTopicType: any;
export type GuardrailTopicAction = "BLOCK" | "NONE" | (string & {});
export declare const GuardrailTopicAction: any;
export interface GuardrailTopicConfig {
    name: string | redacted.Redacted<string>;
    definition: string | redacted.Redacted<string>;
    examples?: (string | redacted.Redacted<string>)[];
    type: GuardrailTopicType;
    inputAction?: GuardrailTopicAction;
    outputAction?: GuardrailTopicAction;
    inputEnabled?: boolean;
    outputEnabled?: boolean;
}
export declare const GuardrailTopicConfig: S.Schema<GuardrailTopicConfig>;
export type GuardrailTopicsConfig = GuardrailTopicConfig[];
export declare const GuardrailTopicsConfig: any;
export type GuardrailTopicsTierName = "CLASSIC" | "STANDARD" | (string & {});
export declare const GuardrailTopicsTierName: any;
export interface GuardrailTopicsTierConfig {
    tierName: GuardrailTopicsTierName;
}
export declare const GuardrailTopicsTierConfig: S.Schema<GuardrailTopicsTierConfig>;
export interface GuardrailTopicPolicyConfig {
    topicsConfig: GuardrailTopicConfig[];
    tierConfig?: GuardrailTopicsTierConfig;
}
export declare const GuardrailTopicPolicyConfig: S.Schema<GuardrailTopicPolicyConfig>;
export type GuardrailContentFilterType = "SEXUAL" | "VIOLENCE" | "HATE" | "INSULTS" | "MISCONDUCT" | "PROMPT_ATTACK" | (string & {});
export declare const GuardrailContentFilterType: any;
export type GuardrailFilterStrength = "NONE" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export declare const GuardrailFilterStrength: any;
export type GuardrailModality = "TEXT" | "IMAGE" | (string & {});
export declare const GuardrailModality: any;
export type GuardrailModalities = GuardrailModality[];
export declare const GuardrailModalities: any;
export type GuardrailContentFilterAction = "BLOCK" | "NONE" | (string & {});
export declare const GuardrailContentFilterAction: any;
export interface GuardrailContentFilterConfig {
    type: GuardrailContentFilterType;
    inputStrength: GuardrailFilterStrength;
    outputStrength: GuardrailFilterStrength;
    inputModalities?: GuardrailModality[];
    outputModalities?: GuardrailModality[];
    inputAction?: GuardrailContentFilterAction;
    outputAction?: GuardrailContentFilterAction;
    inputEnabled?: boolean;
    outputEnabled?: boolean;
}
export declare const GuardrailContentFilterConfig: S.Schema<GuardrailContentFilterConfig>;
export type GuardrailContentFiltersConfig = GuardrailContentFilterConfig[];
export declare const GuardrailContentFiltersConfig: any;
export type GuardrailContentFiltersTierName = "CLASSIC" | "STANDARD" | (string & {});
export declare const GuardrailContentFiltersTierName: any;
export interface GuardrailContentFiltersTierConfig {
    tierName: GuardrailContentFiltersTierName;
}
export declare const GuardrailContentFiltersTierConfig: S.Schema<GuardrailContentFiltersTierConfig>;
export interface GuardrailContentPolicyConfig {
    filtersConfig: GuardrailContentFilterConfig[];
    tierConfig?: GuardrailContentFiltersTierConfig;
}
export declare const GuardrailContentPolicyConfig: S.Schema<GuardrailContentPolicyConfig>;
export type GuardrailWordAction = "BLOCK" | "NONE" | (string & {});
export declare const GuardrailWordAction: any;
export interface GuardrailWordConfig {
    text: string;
    inputAction?: GuardrailWordAction;
    outputAction?: GuardrailWordAction;
    inputEnabled?: boolean;
    outputEnabled?: boolean;
}
export declare const GuardrailWordConfig: S.Schema<GuardrailWordConfig>;
export type GuardrailWordsConfig = GuardrailWordConfig[];
export declare const GuardrailWordsConfig: any;
export type GuardrailManagedWordsType = "PROFANITY" | (string & {});
export declare const GuardrailManagedWordsType: any;
export interface GuardrailManagedWordsConfig {
    type: GuardrailManagedWordsType;
    inputAction?: GuardrailWordAction;
    outputAction?: GuardrailWordAction;
    inputEnabled?: boolean;
    outputEnabled?: boolean;
}
export declare const GuardrailManagedWordsConfig: S.Schema<GuardrailManagedWordsConfig>;
export type GuardrailManagedWordListsConfig = GuardrailManagedWordsConfig[];
export declare const GuardrailManagedWordListsConfig: any;
export interface GuardrailWordPolicyConfig {
    wordsConfig?: GuardrailWordConfig[];
    managedWordListsConfig?: GuardrailManagedWordsConfig[];
}
export declare const GuardrailWordPolicyConfig: S.Schema<GuardrailWordPolicyConfig>;
export type GuardrailPiiEntityType = "ADDRESS" | "AGE" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "CREDIT_DEBIT_CARD_CVV" | "CREDIT_DEBIT_CARD_EXPIRY" | "CREDIT_DEBIT_CARD_NUMBER" | "DRIVER_ID" | "EMAIL" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "IP_ADDRESS" | "LICENSE_PLATE" | "MAC_ADDRESS" | "NAME" | "PASSWORD" | "PHONE" | "PIN" | "SWIFT_CODE" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | "URL" | "USERNAME" | "US_BANK_ACCOUNT_NUMBER" | "US_BANK_ROUTING_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "US_PASSPORT_NUMBER" | "US_SOCIAL_SECURITY_NUMBER" | "VEHICLE_IDENTIFICATION_NUMBER" | (string & {});
export declare const GuardrailPiiEntityType: any;
export type GuardrailSensitiveInformationAction = "BLOCK" | "ANONYMIZE" | "NONE" | (string & {});
export declare const GuardrailSensitiveInformationAction: any;
export interface GuardrailPiiEntityConfig {
    type: GuardrailPiiEntityType;
    action: GuardrailSensitiveInformationAction;
    inputAction?: GuardrailSensitiveInformationAction;
    outputAction?: GuardrailSensitiveInformationAction;
    inputEnabled?: boolean;
    outputEnabled?: boolean;
}
export declare const GuardrailPiiEntityConfig: S.Schema<GuardrailPiiEntityConfig>;
export type GuardrailPiiEntitiesConfig = GuardrailPiiEntityConfig[];
export declare const GuardrailPiiEntitiesConfig: any;
export interface GuardrailRegexConfig {
    name: string;
    description?: string;
    pattern: string;
    action: GuardrailSensitiveInformationAction;
    inputAction?: GuardrailSensitiveInformationAction;
    outputAction?: GuardrailSensitiveInformationAction;
    inputEnabled?: boolean;
    outputEnabled?: boolean;
}
export declare const GuardrailRegexConfig: S.Schema<GuardrailRegexConfig>;
export type GuardrailRegexesConfig = GuardrailRegexConfig[];
export declare const GuardrailRegexesConfig: any;
export interface GuardrailSensitiveInformationPolicyConfig {
    piiEntitiesConfig?: GuardrailPiiEntityConfig[];
    regexesConfig?: GuardrailRegexConfig[];
}
export declare const GuardrailSensitiveInformationPolicyConfig: S.Schema<GuardrailSensitiveInformationPolicyConfig>;
export type GuardrailContextualGroundingFilterType = "GROUNDING" | "RELEVANCE" | (string & {});
export declare const GuardrailContextualGroundingFilterType: any;
export type GuardrailContextualGroundingAction = "BLOCK" | "NONE" | (string & {});
export declare const GuardrailContextualGroundingAction: any;
export interface GuardrailContextualGroundingFilterConfig {
    type: GuardrailContextualGroundingFilterType;
    threshold: number;
    action?: GuardrailContextualGroundingAction;
    enabled?: boolean;
}
export declare const GuardrailContextualGroundingFilterConfig: S.Schema<GuardrailContextualGroundingFilterConfig>;
export type GuardrailContextualGroundingFiltersConfig = GuardrailContextualGroundingFilterConfig[];
export declare const GuardrailContextualGroundingFiltersConfig: any;
export interface GuardrailContextualGroundingPolicyConfig {
    filtersConfig: GuardrailContextualGroundingFilterConfig[];
}
export declare const GuardrailContextualGroundingPolicyConfig: S.Schema<GuardrailContextualGroundingPolicyConfig>;
export type AutomatedReasoningPolicyArnList = string[];
export declare const AutomatedReasoningPolicyArnList: any;
export type AutomatedReasoningConfidenceFilterThreshold = number;
export interface GuardrailAutomatedReasoningPolicyConfig {
    policies: string[];
    confidenceThreshold?: number;
}
export declare const GuardrailAutomatedReasoningPolicyConfig: S.Schema<GuardrailAutomatedReasoningPolicyConfig>;
export type GuardrailCrossRegionGuardrailProfileIdentifier = string;
export interface GuardrailCrossRegionConfig {
    guardrailProfileIdentifier: string;
}
export declare const GuardrailCrossRegionConfig: S.Schema<GuardrailCrossRegionConfig>;
export type GuardrailBlockedMessaging = string | redacted.Redacted<string>;
export interface CreateGuardrailRequest {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    topicPolicyConfig?: GuardrailTopicPolicyConfig;
    contentPolicyConfig?: GuardrailContentPolicyConfig;
    wordPolicyConfig?: GuardrailWordPolicyConfig;
    sensitiveInformationPolicyConfig?: GuardrailSensitiveInformationPolicyConfig;
    contextualGroundingPolicyConfig?: GuardrailContextualGroundingPolicyConfig;
    automatedReasoningPolicyConfig?: GuardrailAutomatedReasoningPolicyConfig;
    crossRegionConfig?: GuardrailCrossRegionConfig;
    blockedInputMessaging: string | redacted.Redacted<string>;
    blockedOutputsMessaging: string | redacted.Redacted<string>;
    kmsKeyId?: string;
    tags?: Tag[];
    clientRequestToken?: string;
}
export declare const CreateGuardrailRequest: S.Schema<CreateGuardrailRequest>;
export type GuardrailId = string;
export type GuardrailArn = string;
export type GuardrailDraftVersion = string;
export interface CreateGuardrailResponse {
    guardrailId: string;
    guardrailArn: string;
    version: string;
    createdAt: Date;
}
export declare const CreateGuardrailResponse: S.Schema<CreateGuardrailResponse>;
export type GuardrailIdentifier = string;
export interface CreateGuardrailVersionRequest {
    guardrailIdentifier: string;
    description?: string | redacted.Redacted<string>;
    clientRequestToken?: string;
}
export declare const CreateGuardrailVersionRequest: S.Schema<CreateGuardrailVersionRequest>;
export type GuardrailNumericalVersion = string;
export interface CreateGuardrailVersionResponse {
    guardrailId: string;
    version: string;
}
export declare const CreateGuardrailVersionResponse: S.Schema<CreateGuardrailVersionResponse>;
export type InferenceProfileName = string;
export type InferenceProfileDescription = string | redacted.Redacted<string>;
export type InferenceProfileModelSourceArn = string;
export type InferenceProfileModelSource = {
    copyFrom: string;
};
export declare const InferenceProfileModelSource: any;
export interface CreateInferenceProfileRequest {
    inferenceProfileName: string;
    description?: string | redacted.Redacted<string>;
    clientRequestToken?: string;
    modelSource: InferenceProfileModelSource;
    tags?: Tag[];
}
export declare const CreateInferenceProfileRequest: S.Schema<CreateInferenceProfileRequest>;
export type InferenceProfileArn = string;
export type InferenceProfileStatus = "ACTIVE" | (string & {});
export declare const InferenceProfileStatus: any;
export interface CreateInferenceProfileResponse {
    inferenceProfileArn: string;
    status?: InferenceProfileStatus;
}
export declare const CreateInferenceProfileResponse: S.Schema<CreateInferenceProfileResponse>;
export type ModelSourceIdentifier = string;
export type InstanceCount = number;
export type InstanceType = string;
export type SubnetId = string;
export type SubnetIds = string[];
export declare const SubnetIds: any;
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export declare const SecurityGroupIds: any;
export interface VpcConfig {
    subnetIds: string[];
    securityGroupIds: string[];
}
export declare const VpcConfig: S.Schema<VpcConfig>;
export interface SageMakerEndpoint {
    initialInstanceCount: number;
    instanceType: string;
    executionRole: string;
    kmsEncryptionKey?: string;
    vpc?: VpcConfig;
}
export declare const SageMakerEndpoint: S.Schema<SageMakerEndpoint>;
export type EndpointConfig = {
    sageMaker: SageMakerEndpoint;
};
export declare const EndpointConfig: any;
export type AcceptEula = boolean;
export type EndpointName = string;
export interface CreateMarketplaceModelEndpointRequest {
    modelSourceIdentifier: string;
    endpointConfig: EndpointConfig;
    acceptEula?: boolean;
    endpointName: string;
    clientRequestToken?: string;
    tags?: Tag[];
}
export declare const CreateMarketplaceModelEndpointRequest: S.Schema<CreateMarketplaceModelEndpointRequest>;
export type Arn = string;
export type Status = "REGISTERED" | "INCOMPATIBLE_ENDPOINT" | (string & {});
export declare const Status: any;
export interface MarketplaceModelEndpoint {
    endpointArn: string;
    modelSourceIdentifier: string;
    status?: Status;
    statusMessage?: string;
    createdAt: Date;
    updatedAt: Date;
    endpointConfig: EndpointConfig;
    endpointStatus: string;
    endpointStatusMessage?: string;
}
export declare const MarketplaceModelEndpoint: S.Schema<MarketplaceModelEndpoint>;
export interface CreateMarketplaceModelEndpointResponse {
    marketplaceModelEndpoint: MarketplaceModelEndpoint;
}
export declare const CreateMarketplaceModelEndpointResponse: S.Schema<CreateMarketplaceModelEndpointResponse>;
export interface CreateModelCopyJobRequest {
    sourceModelArn: string;
    targetModelName: string;
    modelKmsKeyId?: string;
    targetModelTags?: Tag[];
    clientRequestToken?: string;
}
export declare const CreateModelCopyJobRequest: S.Schema<CreateModelCopyJobRequest>;
export type ModelCopyJobArn = string;
export interface CreateModelCopyJobResponse {
    jobArn: string;
}
export declare const CreateModelCopyJobResponse: S.Schema<CreateModelCopyJobResponse>;
export type JobName = string;
export type BaseModelIdentifier = string;
export type CustomizationType = "FINE_TUNING" | "CONTINUED_PRE_TRAINING" | "DISTILLATION" | "REINFORCEMENT_FINE_TUNING" | "IMPORTED" | (string & {});
export declare const CustomizationType: any;
export type UsePromptResponse = boolean;
export type InvocationLogSource = {
    s3Uri: string;
};
export declare const InvocationLogSource: any;
export type RequestMetadataMap = {
    [key: string]: string | undefined;
};
export declare const RequestMetadataMap: any;
export interface RequestMetadataBaseFilters {
    equals?: {
        [key: string]: string | undefined;
    };
    notEquals?: {
        [key: string]: string | undefined;
    };
}
export declare const RequestMetadataBaseFilters: S.Schema<RequestMetadataBaseFilters>;
export type RequestMetadataFiltersList = RequestMetadataBaseFilters[];
export declare const RequestMetadataFiltersList: any;
export type RequestMetadataFilters = {
    equals: {
        [key: string]: string | undefined;
    };
    notEquals?: never;
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals: {
        [key: string]: string | undefined;
    };
    andAll?: never;
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    andAll: RequestMetadataBaseFilters[];
    orAll?: never;
} | {
    equals?: never;
    notEquals?: never;
    andAll?: never;
    orAll: RequestMetadataBaseFilters[];
};
export declare const RequestMetadataFilters: any;
export interface InvocationLogsConfig {
    usePromptResponse?: boolean;
    invocationLogSource: InvocationLogSource;
    requestMetadataFilters?: RequestMetadataFilters;
}
export declare const InvocationLogsConfig: S.Schema<InvocationLogsConfig>;
export interface TrainingDataConfig {
    s3Uri?: string;
    invocationLogsConfig?: InvocationLogsConfig;
}
export declare const TrainingDataConfig: S.Schema<TrainingDataConfig>;
export interface Validator {
    s3Uri: string;
}
export declare const Validator: S.Schema<Validator>;
export type Validators = Validator[];
export declare const Validators: any;
export interface ValidationDataConfig {
    validators: Validator[];
}
export declare const ValidationDataConfig: S.Schema<ValidationDataConfig>;
export interface OutputDataConfig {
    s3Uri: string;
}
export declare const OutputDataConfig: S.Schema<OutputDataConfig>;
export type ModelCustomizationHyperParameters = {
    [key: string]: string | undefined;
};
export declare const ModelCustomizationHyperParameters: any;
export type TeacherModelIdentifier = string;
export interface TeacherModelConfig {
    teacherModelIdentifier: string;
    maxResponseLengthForInference?: number;
}
export declare const TeacherModelConfig: S.Schema<TeacherModelConfig>;
export interface DistillationConfig {
    teacherModelConfig: TeacherModelConfig;
}
export declare const DistillationConfig: S.Schema<DistillationConfig>;
export type LambdaArn = string;
export interface LambdaGraderConfig {
    lambdaArn: string;
}
export declare const LambdaGraderConfig: S.Schema<LambdaGraderConfig>;
export type GraderConfig = {
    lambdaGrader: LambdaGraderConfig;
};
export declare const GraderConfig: any;
export type EpochCount = number;
export type RFTBatchSize = number;
export type RFTLearningRate = number;
export type RFTMaxPromptLength = number;
export type RFTTrainingSamplePerPrompt = number;
export type RFTInferenceMaxTokens = number;
export type ReasoningEffort = "low" | "medium" | "high" | (string & {});
export declare const ReasoningEffort: any;
export type RFTEvalInterval = number;
export interface RFTHyperParameters {
    epochCount?: number;
    batchSize?: number;
    learningRate?: number;
    maxPromptLength?: number;
    trainingSamplePerPrompt?: number;
    inferenceMaxTokens?: number;
    reasoningEffort?: ReasoningEffort;
    evalInterval?: number;
}
export declare const RFTHyperParameters: S.Schema<RFTHyperParameters>;
export interface RFTConfig {
    graderConfig?: GraderConfig;
    hyperParameters?: RFTHyperParameters;
}
export declare const RFTConfig: S.Schema<RFTConfig>;
export type CustomizationConfig = {
    distillationConfig: DistillationConfig;
    rftConfig?: never;
} | {
    distillationConfig?: never;
    rftConfig: RFTConfig;
};
export declare const CustomizationConfig: any;
export interface CreateModelCustomizationJobRequest {
    jobName: string;
    customModelName: string;
    roleArn: string;
    clientRequestToken?: string;
    baseModelIdentifier: string;
    customizationType?: CustomizationType;
    customModelKmsKeyId?: string;
    jobTags?: Tag[];
    customModelTags?: Tag[];
    trainingDataConfig: TrainingDataConfig;
    validationDataConfig?: ValidationDataConfig;
    outputDataConfig: OutputDataConfig;
    hyperParameters?: {
        [key: string]: string | undefined;
    };
    vpcConfig?: VpcConfig;
    customizationConfig?: CustomizationConfig;
}
export declare const CreateModelCustomizationJobRequest: S.Schema<CreateModelCustomizationJobRequest>;
export type ModelCustomizationJobArn = string;
export interface CreateModelCustomizationJobResponse {
    jobArn: string;
}
export declare const CreateModelCustomizationJobResponse: S.Schema<CreateModelCustomizationJobResponse>;
export type ImportedModelName = string;
export interface CreateModelImportJobRequest {
    jobName: string;
    importedModelName: string;
    roleArn: string;
    modelDataSource: ModelDataSource;
    jobTags?: Tag[];
    importedModelTags?: Tag[];
    clientRequestToken?: string;
    vpcConfig?: VpcConfig;
    importedModelKmsKeyId?: string;
}
export declare const CreateModelImportJobRequest: S.Schema<CreateModelImportJobRequest>;
export type ModelImportJobArn = string;
export interface CreateModelImportJobResponse {
    jobArn: string;
}
export declare const CreateModelImportJobResponse: S.Schema<CreateModelImportJobResponse>;
export type ModelInvocationJobName = string;
export type ModelInvocationIdempotencyToken = string;
export type ModelId = string;
export type S3InputFormat = "JSONL" | (string & {});
export declare const S3InputFormat: any;
export type AccountId = string;
export interface ModelInvocationJobS3InputDataConfig {
    s3InputFormat?: S3InputFormat;
    s3Uri: string;
    s3BucketOwner?: string;
}
export declare const ModelInvocationJobS3InputDataConfig: S.Schema<ModelInvocationJobS3InputDataConfig>;
export type ModelInvocationJobInputDataConfig = {
    s3InputDataConfig: ModelInvocationJobS3InputDataConfig;
};
export declare const ModelInvocationJobInputDataConfig: any;
export interface ModelInvocationJobS3OutputDataConfig {
    s3Uri: string;
    s3EncryptionKeyId?: string;
    s3BucketOwner?: string;
}
export declare const ModelInvocationJobS3OutputDataConfig: S.Schema<ModelInvocationJobS3OutputDataConfig>;
export type ModelInvocationJobOutputDataConfig = {
    s3OutputDataConfig: ModelInvocationJobS3OutputDataConfig;
};
export declare const ModelInvocationJobOutputDataConfig: any;
export type ModelInvocationJobTimeoutDurationInHours = number;
export type ModelInvocationType = "InvokeModel" | "Converse" | (string & {});
export declare const ModelInvocationType: any;
export interface CreateModelInvocationJobRequest {
    jobName: string;
    roleArn: string;
    clientRequestToken?: string;
    modelId: string;
    inputDataConfig: ModelInvocationJobInputDataConfig;
    outputDataConfig: ModelInvocationJobOutputDataConfig;
    vpcConfig?: VpcConfig;
    timeoutDurationInHours?: number;
    tags?: Tag[];
    modelInvocationType?: ModelInvocationType;
}
export declare const CreateModelInvocationJobRequest: S.Schema<CreateModelInvocationJobRequest>;
export type ModelInvocationJobArn = string;
export interface CreateModelInvocationJobResponse {
    jobArn: string;
}
export declare const CreateModelInvocationJobResponse: S.Schema<CreateModelInvocationJobResponse>;
export type PromptRouterName = string;
export type PromptRouterTargetModelArn = string;
export interface PromptRouterTargetModel {
    modelArn?: string;
}
export declare const PromptRouterTargetModel: S.Schema<PromptRouterTargetModel>;
export type PromptRouterTargetModels = PromptRouterTargetModel[];
export declare const PromptRouterTargetModels: any;
export type PromptRouterDescription = string | redacted.Redacted<string>;
export interface RoutingCriteria {
    responseQualityDifference: number;
}
export declare const RoutingCriteria: S.Schema<RoutingCriteria>;
export interface CreatePromptRouterRequest {
    clientRequestToken?: string;
    promptRouterName: string;
    models: PromptRouterTargetModel[];
    description?: string | redacted.Redacted<string>;
    routingCriteria: RoutingCriteria;
    fallbackModel: PromptRouterTargetModel;
    tags?: Tag[];
}
export declare const CreatePromptRouterRequest: S.Schema<CreatePromptRouterRequest>;
export type PromptRouterArn = string;
export interface CreatePromptRouterResponse {
    promptRouterArn?: string;
}
export declare const CreatePromptRouterResponse: S.Schema<CreatePromptRouterResponse>;
export type PositiveInteger = number;
export type ProvisionedModelName = string;
export type ModelIdentifier = string;
export type CommitmentDuration = "OneMonth" | "SixMonths" | (string & {});
export declare const CommitmentDuration: any;
export interface CreateProvisionedModelThroughputRequest {
    clientRequestToken?: string;
    modelUnits: number;
    provisionedModelName: string;
    modelId: string;
    commitmentDuration?: CommitmentDuration;
    tags?: Tag[];
}
export declare const CreateProvisionedModelThroughputRequest: S.Schema<CreateProvisionedModelThroughputRequest>;
export type ProvisionedModelArn = string;
export interface CreateProvisionedModelThroughputResponse {
    provisionedModelArn: string;
}
export declare const CreateProvisionedModelThroughputResponse: S.Schema<CreateProvisionedModelThroughputResponse>;
export interface DeleteAutomatedReasoningPolicyRequest {
    policyArn: string;
    force?: boolean;
}
export declare const DeleteAutomatedReasoningPolicyRequest: S.Schema<DeleteAutomatedReasoningPolicyRequest>;
export interface DeleteAutomatedReasoningPolicyResponse {
}
export declare const DeleteAutomatedReasoningPolicyResponse: S.Schema<DeleteAutomatedReasoningPolicyResponse>;
export interface DeleteAutomatedReasoningPolicyBuildWorkflowRequest {
    policyArn: string;
    buildWorkflowId: string;
    lastUpdatedAt: Date;
}
export declare const DeleteAutomatedReasoningPolicyBuildWorkflowRequest: S.Schema<DeleteAutomatedReasoningPolicyBuildWorkflowRequest>;
export interface DeleteAutomatedReasoningPolicyBuildWorkflowResponse {
}
export declare const DeleteAutomatedReasoningPolicyBuildWorkflowResponse: S.Schema<DeleteAutomatedReasoningPolicyBuildWorkflowResponse>;
export interface DeleteAutomatedReasoningPolicyTestCaseRequest {
    policyArn: string;
    testCaseId: string;
    lastUpdatedAt: Date;
}
export declare const DeleteAutomatedReasoningPolicyTestCaseRequest: S.Schema<DeleteAutomatedReasoningPolicyTestCaseRequest>;
export interface DeleteAutomatedReasoningPolicyTestCaseResponse {
}
export declare const DeleteAutomatedReasoningPolicyTestCaseResponse: S.Schema<DeleteAutomatedReasoningPolicyTestCaseResponse>;
export interface DeleteCustomModelRequest {
    modelIdentifier: string;
}
export declare const DeleteCustomModelRequest: S.Schema<DeleteCustomModelRequest>;
export interface DeleteCustomModelResponse {
}
export declare const DeleteCustomModelResponse: S.Schema<DeleteCustomModelResponse>;
export type CustomModelDeploymentIdentifier = string;
export interface DeleteCustomModelDeploymentRequest {
    customModelDeploymentIdentifier: string;
}
export declare const DeleteCustomModelDeploymentRequest: S.Schema<DeleteCustomModelDeploymentRequest>;
export interface DeleteCustomModelDeploymentResponse {
}
export declare const DeleteCustomModelDeploymentResponse: S.Schema<DeleteCustomModelDeploymentResponse>;
export type AccountEnforcedGuardrailConfigurationId = string;
export interface DeleteEnforcedGuardrailConfigurationRequest {
    configId: string;
}
export declare const DeleteEnforcedGuardrailConfigurationRequest: S.Schema<DeleteEnforcedGuardrailConfigurationRequest>;
export interface DeleteEnforcedGuardrailConfigurationResponse {
}
export declare const DeleteEnforcedGuardrailConfigurationResponse: S.Schema<DeleteEnforcedGuardrailConfigurationResponse>;
export interface DeleteFoundationModelAgreementRequest {
    modelId: string;
}
export declare const DeleteFoundationModelAgreementRequest: S.Schema<DeleteFoundationModelAgreementRequest>;
export interface DeleteFoundationModelAgreementResponse {
}
export declare const DeleteFoundationModelAgreementResponse: S.Schema<DeleteFoundationModelAgreementResponse>;
export interface DeleteGuardrailRequest {
    guardrailIdentifier: string;
    guardrailVersion?: string;
}
export declare const DeleteGuardrailRequest: S.Schema<DeleteGuardrailRequest>;
export interface DeleteGuardrailResponse {
}
export declare const DeleteGuardrailResponse: S.Schema<DeleteGuardrailResponse>;
export type ImportedModelIdentifier = string;
export interface DeleteImportedModelRequest {
    modelIdentifier: string;
}
export declare const DeleteImportedModelRequest: S.Schema<DeleteImportedModelRequest>;
export interface DeleteImportedModelResponse {
}
export declare const DeleteImportedModelResponse: S.Schema<DeleteImportedModelResponse>;
export type InferenceProfileIdentifier = string;
export interface DeleteInferenceProfileRequest {
    inferenceProfileIdentifier: string;
}
export declare const DeleteInferenceProfileRequest: S.Schema<DeleteInferenceProfileRequest>;
export interface DeleteInferenceProfileResponse {
}
export declare const DeleteInferenceProfileResponse: S.Schema<DeleteInferenceProfileResponse>;
export interface DeleteMarketplaceModelEndpointRequest {
    endpointArn: string;
}
export declare const DeleteMarketplaceModelEndpointRequest: S.Schema<DeleteMarketplaceModelEndpointRequest>;
export interface DeleteMarketplaceModelEndpointResponse {
}
export declare const DeleteMarketplaceModelEndpointResponse: S.Schema<DeleteMarketplaceModelEndpointResponse>;
export interface DeleteModelInvocationLoggingConfigurationRequest {
}
export declare const DeleteModelInvocationLoggingConfigurationRequest: S.Schema<DeleteModelInvocationLoggingConfigurationRequest>;
export interface DeleteModelInvocationLoggingConfigurationResponse {
}
export declare const DeleteModelInvocationLoggingConfigurationResponse: S.Schema<DeleteModelInvocationLoggingConfigurationResponse>;
export interface DeletePromptRouterRequest {
    promptRouterArn: string;
}
export declare const DeletePromptRouterRequest: S.Schema<DeletePromptRouterRequest>;
export interface DeletePromptRouterResponse {
}
export declare const DeletePromptRouterResponse: S.Schema<DeletePromptRouterResponse>;
export type ProvisionedModelId = string;
export interface DeleteProvisionedModelThroughputRequest {
    provisionedModelId: string;
}
export declare const DeleteProvisionedModelThroughputRequest: S.Schema<DeleteProvisionedModelThroughputRequest>;
export interface DeleteProvisionedModelThroughputResponse {
}
export declare const DeleteProvisionedModelThroughputResponse: S.Schema<DeleteProvisionedModelThroughputResponse>;
export type ResourcePolicyResourceArn = string;
export interface DeleteResourcePolicyRequest {
    resourceArn: string;
}
export declare const DeleteResourcePolicyRequest: S.Schema<DeleteResourcePolicyRequest>;
export interface DeleteResourcePolicyResponse {
}
export declare const DeleteResourcePolicyResponse: S.Schema<DeleteResourcePolicyResponse>;
export interface DeregisterMarketplaceModelEndpointRequest {
    endpointArn: string;
}
export declare const DeregisterMarketplaceModelEndpointRequest: S.Schema<DeregisterMarketplaceModelEndpointRequest>;
export interface DeregisterMarketplaceModelEndpointResponse {
}
export declare const DeregisterMarketplaceModelEndpointResponse: S.Schema<DeregisterMarketplaceModelEndpointResponse>;
export interface ExportAutomatedReasoningPolicyVersionRequest {
    policyArn: string;
}
export declare const ExportAutomatedReasoningPolicyVersionRequest: S.Schema<ExportAutomatedReasoningPolicyVersionRequest>;
export interface ExportAutomatedReasoningPolicyVersionResponse {
    policyDefinition: AutomatedReasoningPolicyDefinition;
}
export declare const ExportAutomatedReasoningPolicyVersionResponse: S.Schema<ExportAutomatedReasoningPolicyVersionResponse>;
export interface GetAccountDataRetentionRequest {
}
export declare const GetAccountDataRetentionRequest: S.Schema<GetAccountDataRetentionRequest>;
export type DataRetentionMode = "default" | "none" | "provider_data_share" | "inherit" | (string & {});
export declare const DataRetentionMode: any;
export interface GetAccountDataRetentionResponse {
    mode: DataRetentionMode;
    updatedAt?: Date;
}
export declare const GetAccountDataRetentionResponse: S.Schema<GetAccountDataRetentionResponse>;
export interface GetAdvancedPromptOptimizationJobRequest {
    jobIdentifier: string;
}
export declare const GetAdvancedPromptOptimizationJobRequest: S.Schema<GetAdvancedPromptOptimizationJobRequest>;
export type ErrorMessage = string;
export interface GetAdvancedPromptOptimizationJobResponse {
    jobArn: string;
    jobName: string;
    jobDescription?: string;
    jobStatus: AdvancedPromptOptimizationJobStatus;
    inputConfig: AdvancedPromptOptimizationInputConfig;
    outputConfig: AdvancedPromptOptimizationOutputConfig;
    encryptionKeyArn?: string;
    creationTime: Date;
    lastModifiedTime?: Date;
    failureMessage?: string;
    modelConfigurations: ModelConfiguration[];
}
export declare const GetAdvancedPromptOptimizationJobResponse: S.Schema<GetAdvancedPromptOptimizationJobResponse>;
export interface GetAutomatedReasoningPolicyRequest {
    policyArn: string;
}
export declare const GetAutomatedReasoningPolicyRequest: S.Schema<GetAutomatedReasoningPolicyRequest>;
export type AutomatedReasoningPolicyId = string;
export interface GetAutomatedReasoningPolicyResponse {
    policyArn: string;
    name: string | redacted.Redacted<string>;
    version: string;
    policyId: string;
    description?: string | redacted.Redacted<string>;
    definitionHash: string;
    kmsKeyArn?: string;
    createdAt?: Date;
    updatedAt: Date;
}
export declare const GetAutomatedReasoningPolicyResponse: S.Schema<GetAutomatedReasoningPolicyResponse>;
export interface GetAutomatedReasoningPolicyAnnotationsRequest {
    policyArn: string;
    buildWorkflowId: string;
}
export declare const GetAutomatedReasoningPolicyAnnotationsRequest: S.Schema<GetAutomatedReasoningPolicyAnnotationsRequest>;
export interface AutomatedReasoningPolicyAddTypeAnnotation {
    name: string | redacted.Redacted<string>;
    description: string | redacted.Redacted<string>;
    values: AutomatedReasoningPolicyDefinitionTypeValue[];
}
export declare const AutomatedReasoningPolicyAddTypeAnnotation: S.Schema<AutomatedReasoningPolicyAddTypeAnnotation>;
export interface AutomatedReasoningPolicyAddTypeValue {
    value: string;
    description?: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyAddTypeValue: S.Schema<AutomatedReasoningPolicyAddTypeValue>;
export interface AutomatedReasoningPolicyUpdateTypeValue {
    value: string;
    newValue?: string;
    description?: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyUpdateTypeValue: S.Schema<AutomatedReasoningPolicyUpdateTypeValue>;
export interface AutomatedReasoningPolicyDeleteTypeValue {
    value: string;
}
export declare const AutomatedReasoningPolicyDeleteTypeValue: S.Schema<AutomatedReasoningPolicyDeleteTypeValue>;
export type AutomatedReasoningPolicyTypeValueAnnotation = {
    addTypeValue: AutomatedReasoningPolicyAddTypeValue;
    updateTypeValue?: never;
    deleteTypeValue?: never;
} | {
    addTypeValue?: never;
    updateTypeValue: AutomatedReasoningPolicyUpdateTypeValue;
    deleteTypeValue?: never;
} | {
    addTypeValue?: never;
    updateTypeValue?: never;
    deleteTypeValue: AutomatedReasoningPolicyDeleteTypeValue;
};
export declare const AutomatedReasoningPolicyTypeValueAnnotation: any;
export type AutomatedReasoningPolicyTypeValueAnnotationList = AutomatedReasoningPolicyTypeValueAnnotation[];
export declare const AutomatedReasoningPolicyTypeValueAnnotationList: any;
export interface AutomatedReasoningPolicyUpdateTypeAnnotation {
    name: string | redacted.Redacted<string>;
    newName?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    values: AutomatedReasoningPolicyTypeValueAnnotation[];
}
export declare const AutomatedReasoningPolicyUpdateTypeAnnotation: S.Schema<AutomatedReasoningPolicyUpdateTypeAnnotation>;
export interface AutomatedReasoningPolicyDeleteTypeAnnotation {
    name: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyDeleteTypeAnnotation: S.Schema<AutomatedReasoningPolicyDeleteTypeAnnotation>;
export interface AutomatedReasoningPolicyAddVariableAnnotation {
    name: string | redacted.Redacted<string>;
    type: string | redacted.Redacted<string>;
    description: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyAddVariableAnnotation: S.Schema<AutomatedReasoningPolicyAddVariableAnnotation>;
export interface AutomatedReasoningPolicyUpdateVariableAnnotation {
    name: string | redacted.Redacted<string>;
    newName?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyUpdateVariableAnnotation: S.Schema<AutomatedReasoningPolicyUpdateVariableAnnotation>;
export interface AutomatedReasoningPolicyDeleteVariableAnnotation {
    name: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyDeleteVariableAnnotation: S.Schema<AutomatedReasoningPolicyDeleteVariableAnnotation>;
export interface AutomatedReasoningPolicyAddRuleAnnotation {
    expression: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyAddRuleAnnotation: S.Schema<AutomatedReasoningPolicyAddRuleAnnotation>;
export interface AutomatedReasoningPolicyUpdateRuleAnnotation {
    ruleId: string;
    expression: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyUpdateRuleAnnotation: S.Schema<AutomatedReasoningPolicyUpdateRuleAnnotation>;
export interface AutomatedReasoningPolicyDeleteRuleAnnotation {
    ruleId: string;
}
export declare const AutomatedReasoningPolicyDeleteRuleAnnotation: S.Schema<AutomatedReasoningPolicyDeleteRuleAnnotation>;
export type AutomatedReasoningPolicyAnnotationRuleNaturalLanguage = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyAddRuleFromNaturalLanguageAnnotation {
    naturalLanguage: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyAddRuleFromNaturalLanguageAnnotation: S.Schema<AutomatedReasoningPolicyAddRuleFromNaturalLanguageAnnotation>;
export type AutomatedReasoningPolicyDefinitionRuleIdList = string[];
export declare const AutomatedReasoningPolicyDefinitionRuleIdList: any;
export type AutomatedReasoningPolicyAnnotationFeedbackNaturalLanguage = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyUpdateFromRuleFeedbackAnnotation {
    ruleIds?: string[];
    feedback: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyUpdateFromRuleFeedbackAnnotation: S.Schema<AutomatedReasoningPolicyUpdateFromRuleFeedbackAnnotation>;
export type AutomatedReasoningPolicyScenarioExpression = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyUpdateFromScenarioFeedbackAnnotation {
    ruleIds?: string[];
    scenarioExpression: string | redacted.Redacted<string>;
    feedback?: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyUpdateFromScenarioFeedbackAnnotation: S.Schema<AutomatedReasoningPolicyUpdateFromScenarioFeedbackAnnotation>;
export type AutomatedReasoningPolicyAnnotationIngestContent = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyIngestContentAnnotation {
    content: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyIngestContentAnnotation: S.Schema<AutomatedReasoningPolicyIngestContentAnnotation>;
export type AutomatedReasoningPolicyAnnotation = {
    addType: AutomatedReasoningPolicyAddTypeAnnotation;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
    addRuleFromNaturalLanguage?: never;
    updateFromRulesFeedback?: never;
    updateFromScenarioFeedback?: never;
    ingestContent?: never;
} | {
    addType?: never;
    updateType: AutomatedReasoningPolicyUpdateTypeAnnotation;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
    addRuleFromNaturalLanguage?: never;
    updateFromRulesFeedback?: never;
    updateFromScenarioFeedback?: never;
    ingestContent?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType: AutomatedReasoningPolicyDeleteTypeAnnotation;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
    addRuleFromNaturalLanguage?: never;
    updateFromRulesFeedback?: never;
    updateFromScenarioFeedback?: never;
    ingestContent?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable: AutomatedReasoningPolicyAddVariableAnnotation;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
    addRuleFromNaturalLanguage?: never;
    updateFromRulesFeedback?: never;
    updateFromScenarioFeedback?: never;
    ingestContent?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable: AutomatedReasoningPolicyUpdateVariableAnnotation;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
    addRuleFromNaturalLanguage?: never;
    updateFromRulesFeedback?: never;
    updateFromScenarioFeedback?: never;
    ingestContent?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable: AutomatedReasoningPolicyDeleteVariableAnnotation;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
    addRuleFromNaturalLanguage?: never;
    updateFromRulesFeedback?: never;
    updateFromScenarioFeedback?: never;
    ingestContent?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule: AutomatedReasoningPolicyAddRuleAnnotation;
    updateRule?: never;
    deleteRule?: never;
    addRuleFromNaturalLanguage?: never;
    updateFromRulesFeedback?: never;
    updateFromScenarioFeedback?: never;
    ingestContent?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule: AutomatedReasoningPolicyUpdateRuleAnnotation;
    deleteRule?: never;
    addRuleFromNaturalLanguage?: never;
    updateFromRulesFeedback?: never;
    updateFromScenarioFeedback?: never;
    ingestContent?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule: AutomatedReasoningPolicyDeleteRuleAnnotation;
    addRuleFromNaturalLanguage?: never;
    updateFromRulesFeedback?: never;
    updateFromScenarioFeedback?: never;
    ingestContent?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
    addRuleFromNaturalLanguage: AutomatedReasoningPolicyAddRuleFromNaturalLanguageAnnotation;
    updateFromRulesFeedback?: never;
    updateFromScenarioFeedback?: never;
    ingestContent?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
    addRuleFromNaturalLanguage?: never;
    updateFromRulesFeedback: AutomatedReasoningPolicyUpdateFromRuleFeedbackAnnotation;
    updateFromScenarioFeedback?: never;
    ingestContent?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
    addRuleFromNaturalLanguage?: never;
    updateFromRulesFeedback?: never;
    updateFromScenarioFeedback: AutomatedReasoningPolicyUpdateFromScenarioFeedbackAnnotation;
    ingestContent?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
    addRuleFromNaturalLanguage?: never;
    updateFromRulesFeedback?: never;
    updateFromScenarioFeedback?: never;
    ingestContent: AutomatedReasoningPolicyIngestContentAnnotation;
};
export declare const AutomatedReasoningPolicyAnnotation: any;
export type AutomatedReasoningPolicyAnnotationList = AutomatedReasoningPolicyAnnotation[];
export declare const AutomatedReasoningPolicyAnnotationList: any;
export interface GetAutomatedReasoningPolicyAnnotationsResponse {
    policyArn: string;
    name: string | redacted.Redacted<string>;
    buildWorkflowId: string;
    annotations: AutomatedReasoningPolicyAnnotation[];
    annotationSetHash: string;
    updatedAt: Date;
}
export declare const GetAutomatedReasoningPolicyAnnotationsResponse: S.Schema<GetAutomatedReasoningPolicyAnnotationsResponse>;
export interface GetAutomatedReasoningPolicyBuildWorkflowRequest {
    policyArn: string;
    buildWorkflowId: string;
}
export declare const GetAutomatedReasoningPolicyBuildWorkflowRequest: S.Schema<GetAutomatedReasoningPolicyBuildWorkflowRequest>;
export type AutomatedReasoningPolicyBuildWorkflowStatus = "SCHEDULED" | "CANCEL_REQUESTED" | "PREPROCESSING" | "BUILDING" | "TESTING" | "COMPLETED" | "FAILED" | "CANCELLED" | (string & {});
export declare const AutomatedReasoningPolicyBuildWorkflowStatus: any;
export type AutomatedReasoningPolicyBuildWorkflowType = "INGEST_CONTENT" | "REFINE_POLICY" | "IMPORT_POLICY" | "GENERATE_FIDELITY_REPORT" | "GENERATE_POLICY_SCENARIOS" | "RESOLVE_POLICY_AMBIGUITIES" | "ITERATIVELY_REFINE_POLICY" | (string & {});
export declare const AutomatedReasoningPolicyBuildWorkflowType: any;
export type AutomatedReasoningPolicyBuildDocumentName = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyBuildDocumentContentType = "pdf" | "txt" | (string & {});
export declare const AutomatedReasoningPolicyBuildDocumentContentType: any;
export type AutomatedReasoningPolicyBuildDocumentDescription = string | redacted.Redacted<string>;
export interface GetAutomatedReasoningPolicyBuildWorkflowResponse {
    policyArn: string;
    buildWorkflowId: string;
    status: AutomatedReasoningPolicyBuildWorkflowStatus;
    buildWorkflowType: AutomatedReasoningPolicyBuildWorkflowType;
    documentName?: string | redacted.Redacted<string>;
    documentContentType?: AutomatedReasoningPolicyBuildDocumentContentType;
    documentDescription?: string | redacted.Redacted<string>;
    createdAt: Date;
    updatedAt: Date;
}
export declare const GetAutomatedReasoningPolicyBuildWorkflowResponse: S.Schema<GetAutomatedReasoningPolicyBuildWorkflowResponse>;
export type AutomatedReasoningPolicyBuildResultAssetType = "BUILD_LOG" | "QUALITY_REPORT" | "POLICY_DEFINITION" | "GENERATED_TEST_CASES" | "POLICY_SCENARIOS" | "FIDELITY_REPORT" | "ASSET_MANIFEST" | "SOURCE_DOCUMENT" | (string & {});
export declare const AutomatedReasoningPolicyBuildResultAssetType: any;
export type AutomatedReasoningPolicyBuildResultAssetId = string;
export interface GetAutomatedReasoningPolicyBuildWorkflowResultAssetsRequest {
    policyArn: string;
    buildWorkflowId: string;
    assetType: AutomatedReasoningPolicyBuildResultAssetType;
    assetId?: string;
}
export declare const GetAutomatedReasoningPolicyBuildWorkflowResultAssetsRequest: S.Schema<GetAutomatedReasoningPolicyBuildWorkflowResultAssetsRequest>;
export type AutomatedReasoningPolicyDefinitionTypeNameList = (string | redacted.Redacted<string>)[];
export declare const AutomatedReasoningPolicyDefinitionTypeNameList: any;
export interface AutomatedReasoningPolicyDefinitionTypeValuePair {
    typeName: string | redacted.Redacted<string>;
    valueName: string;
}
export declare const AutomatedReasoningPolicyDefinitionTypeValuePair: S.Schema<AutomatedReasoningPolicyDefinitionTypeValuePair>;
export type AutomatedReasoningPolicyDefinitionTypeValuePairList = AutomatedReasoningPolicyDefinitionTypeValuePair[];
export declare const AutomatedReasoningPolicyDefinitionTypeValuePairList: any;
export type AutomatedReasoningPolicyDefinitionVariableNameList = (string | redacted.Redacted<string>)[];
export declare const AutomatedReasoningPolicyDefinitionVariableNameList: any;
export type AutomatedReasoningPolicyConflictedRuleIdList = string[];
export declare const AutomatedReasoningPolicyConflictedRuleIdList: any;
export type AutomatedReasoningPolicyDisjointedRuleIdList = string[];
export declare const AutomatedReasoningPolicyDisjointedRuleIdList: any;
export interface AutomatedReasoningPolicyDisjointRuleSet {
    variables: (string | redacted.Redacted<string>)[];
    rules: string[];
}
export declare const AutomatedReasoningPolicyDisjointRuleSet: S.Schema<AutomatedReasoningPolicyDisjointRuleSet>;
export type AutomatedReasoningPolicyDisjointRuleSetList = AutomatedReasoningPolicyDisjointRuleSet[];
export declare const AutomatedReasoningPolicyDisjointRuleSetList: any;
export interface AutomatedReasoningPolicyDefinitionQualityReport {
    typeCount: number;
    variableCount: number;
    ruleCount: number;
    unusedTypes: (string | redacted.Redacted<string>)[];
    unusedTypeValues: AutomatedReasoningPolicyDefinitionTypeValuePair[];
    unusedVariables: (string | redacted.Redacted<string>)[];
    conflictingRules: string[];
    disjointRuleSets: AutomatedReasoningPolicyDisjointRuleSet[];
}
export declare const AutomatedReasoningPolicyDefinitionQualityReport: S.Schema<AutomatedReasoningPolicyDefinitionQualityReport>;
export type AutomatedReasoningPolicyAnnotationStatus = "APPLIED" | "FAILED" | (string & {});
export declare const AutomatedReasoningPolicyAnnotationStatus: any;
export interface AutomatedReasoningPolicyPlanning {
}
export declare const AutomatedReasoningPolicyPlanning: S.Schema<AutomatedReasoningPolicyPlanning>;
export interface AutomatedReasoningPolicyAddTypeMutation {
    type: AutomatedReasoningPolicyDefinitionType;
}
export declare const AutomatedReasoningPolicyAddTypeMutation: S.Schema<AutomatedReasoningPolicyAddTypeMutation>;
export interface AutomatedReasoningPolicyUpdateTypeMutation {
    type: AutomatedReasoningPolicyDefinitionType;
}
export declare const AutomatedReasoningPolicyUpdateTypeMutation: S.Schema<AutomatedReasoningPolicyUpdateTypeMutation>;
export interface AutomatedReasoningPolicyDeleteTypeMutation {
    name: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyDeleteTypeMutation: S.Schema<AutomatedReasoningPolicyDeleteTypeMutation>;
export interface AutomatedReasoningPolicyAddVariableMutation {
    variable: AutomatedReasoningPolicyDefinitionVariable;
}
export declare const AutomatedReasoningPolicyAddVariableMutation: S.Schema<AutomatedReasoningPolicyAddVariableMutation>;
export interface AutomatedReasoningPolicyUpdateVariableMutation {
    variable: AutomatedReasoningPolicyDefinitionVariable;
}
export declare const AutomatedReasoningPolicyUpdateVariableMutation: S.Schema<AutomatedReasoningPolicyUpdateVariableMutation>;
export interface AutomatedReasoningPolicyDeleteVariableMutation {
    name: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyDeleteVariableMutation: S.Schema<AutomatedReasoningPolicyDeleteVariableMutation>;
export interface AutomatedReasoningPolicyAddRuleMutation {
    rule: AutomatedReasoningPolicyDefinitionRule;
}
export declare const AutomatedReasoningPolicyAddRuleMutation: S.Schema<AutomatedReasoningPolicyAddRuleMutation>;
export interface AutomatedReasoningPolicyUpdateRuleMutation {
    rule: AutomatedReasoningPolicyDefinitionRule;
}
export declare const AutomatedReasoningPolicyUpdateRuleMutation: S.Schema<AutomatedReasoningPolicyUpdateRuleMutation>;
export interface AutomatedReasoningPolicyDeleteRuleMutation {
    id: string;
}
export declare const AutomatedReasoningPolicyDeleteRuleMutation: S.Schema<AutomatedReasoningPolicyDeleteRuleMutation>;
export type AutomatedReasoningPolicyMutation = {
    addType: AutomatedReasoningPolicyAddTypeMutation;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
} | {
    addType?: never;
    updateType: AutomatedReasoningPolicyUpdateTypeMutation;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType: AutomatedReasoningPolicyDeleteTypeMutation;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable: AutomatedReasoningPolicyAddVariableMutation;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable: AutomatedReasoningPolicyUpdateVariableMutation;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable: AutomatedReasoningPolicyDeleteVariableMutation;
    addRule?: never;
    updateRule?: never;
    deleteRule?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule: AutomatedReasoningPolicyAddRuleMutation;
    updateRule?: never;
    deleteRule?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule: AutomatedReasoningPolicyUpdateRuleMutation;
    deleteRule?: never;
} | {
    addType?: never;
    updateType?: never;
    deleteType?: never;
    addVariable?: never;
    updateVariable?: never;
    deleteVariable?: never;
    addRule?: never;
    updateRule?: never;
    deleteRule: AutomatedReasoningPolicyDeleteRuleMutation;
};
export declare const AutomatedReasoningPolicyMutation: any;
export type AutomatedReasoningPolicyBuildStepContext = {
    planning: AutomatedReasoningPolicyPlanning;
    mutation?: never;
} | {
    planning?: never;
    mutation: AutomatedReasoningPolicyMutation;
};
export declare const AutomatedReasoningPolicyBuildStepContext: any;
export type AutomatedReasoningPolicyDefinitionElement = {
    policyDefinitionVariable: AutomatedReasoningPolicyDefinitionVariable;
    policyDefinitionType?: never;
    policyDefinitionRule?: never;
} | {
    policyDefinitionVariable?: never;
    policyDefinitionType: AutomatedReasoningPolicyDefinitionType;
    policyDefinitionRule?: never;
} | {
    policyDefinitionVariable?: never;
    policyDefinitionType?: never;
    policyDefinitionRule: AutomatedReasoningPolicyDefinitionRule;
};
export declare const AutomatedReasoningPolicyDefinitionElement: any;
export type AutomatedReasoningPolicyBuildMessageType = "INFO" | "WARNING" | "ERROR" | (string & {});
export declare const AutomatedReasoningPolicyBuildMessageType: any;
export interface AutomatedReasoningPolicyBuildStepMessage {
    message: string;
    messageType: AutomatedReasoningPolicyBuildMessageType;
}
export declare const AutomatedReasoningPolicyBuildStepMessage: S.Schema<AutomatedReasoningPolicyBuildStepMessage>;
export type AutomatedReasoningPolicyBuildStepMessageList = AutomatedReasoningPolicyBuildStepMessage[];
export declare const AutomatedReasoningPolicyBuildStepMessageList: any;
export interface AutomatedReasoningPolicyBuildStep {
    context: AutomatedReasoningPolicyBuildStepContext;
    priorElement?: AutomatedReasoningPolicyDefinitionElement;
    messages: AutomatedReasoningPolicyBuildStepMessage[];
}
export declare const AutomatedReasoningPolicyBuildStep: S.Schema<AutomatedReasoningPolicyBuildStep>;
export type AutomatedReasoningPolicyBuildStepList = AutomatedReasoningPolicyBuildStep[];
export declare const AutomatedReasoningPolicyBuildStepList: any;
export interface AutomatedReasoningPolicyBuildLogEntry {
    annotation: AutomatedReasoningPolicyAnnotation;
    status: AutomatedReasoningPolicyAnnotationStatus;
    buildSteps: AutomatedReasoningPolicyBuildStep[];
}
export declare const AutomatedReasoningPolicyBuildLogEntry: S.Schema<AutomatedReasoningPolicyBuildLogEntry>;
export type AutomatedReasoningPolicyBuildLogEntryList = AutomatedReasoningPolicyBuildLogEntry[];
export declare const AutomatedReasoningPolicyBuildLogEntryList: any;
export interface AutomatedReasoningPolicyBuildLog {
    entries: AutomatedReasoningPolicyBuildLogEntry[];
}
export declare const AutomatedReasoningPolicyBuildLog: S.Schema<AutomatedReasoningPolicyBuildLog>;
export interface AutomatedReasoningPolicyGeneratedTestCase {
    queryContent: string | redacted.Redacted<string>;
    guardContent: string | redacted.Redacted<string>;
    expectedAggregatedFindingsResult: AutomatedReasoningCheckResult;
}
export declare const AutomatedReasoningPolicyGeneratedTestCase: S.Schema<AutomatedReasoningPolicyGeneratedTestCase>;
export type AutomatedReasoningPolicyGeneratedTestCaseList = AutomatedReasoningPolicyGeneratedTestCase[];
export declare const AutomatedReasoningPolicyGeneratedTestCaseList: any;
export interface AutomatedReasoningPolicyGeneratedTestCases {
    generatedTestCases: AutomatedReasoningPolicyGeneratedTestCase[];
}
export declare const AutomatedReasoningPolicyGeneratedTestCases: S.Schema<AutomatedReasoningPolicyGeneratedTestCases>;
export type AutomatedReasoningPolicyScenarioAlternateExpression = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyScenario {
    expression: string | redacted.Redacted<string>;
    alternateExpression: string | redacted.Redacted<string>;
    expectedResult: AutomatedReasoningCheckResult;
    ruleIds: string[];
}
export declare const AutomatedReasoningPolicyScenario: S.Schema<AutomatedReasoningPolicyScenario>;
export type AutomatedReasoningPolicyScenarioList = AutomatedReasoningPolicyScenario[];
export declare const AutomatedReasoningPolicyScenarioList: any;
export interface AutomatedReasoningPolicyScenarios {
    policyScenarios: AutomatedReasoningPolicyScenario[];
}
export declare const AutomatedReasoningPolicyScenarios: S.Schema<AutomatedReasoningPolicyScenarios>;
export type AutomatedReasoningPolicyBuildResultAssetName = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyBuildResultAssetManifestEntry {
    assetType: AutomatedReasoningPolicyBuildResultAssetType;
    assetName?: string | redacted.Redacted<string>;
    assetId?: string;
}
export declare const AutomatedReasoningPolicyBuildResultAssetManifestEntry: S.Schema<AutomatedReasoningPolicyBuildResultAssetManifestEntry>;
export type AutomatedReasoningPolicyBuildResultAssetManifestList = AutomatedReasoningPolicyBuildResultAssetManifestEntry[];
export declare const AutomatedReasoningPolicyBuildResultAssetManifestList: any;
export interface AutomatedReasoningPolicyBuildResultAssetManifest {
    entries: AutomatedReasoningPolicyBuildResultAssetManifestEntry[];
}
export declare const AutomatedReasoningPolicyBuildResultAssetManifest: S.Schema<AutomatedReasoningPolicyBuildResultAssetManifest>;
export type AutomatedReasoningPolicyBuildDocumentBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export type AutomatedReasoningPolicyDocumentSha256 = string;
export interface AutomatedReasoningPolicySourceDocument {
    document: Uint8Array | redacted.Redacted<Uint8Array>;
    documentContentType: AutomatedReasoningPolicyBuildDocumentContentType;
    documentName: string | redacted.Redacted<string>;
    documentDescription?: string | redacted.Redacted<string>;
    documentHash: string;
}
export declare const AutomatedReasoningPolicySourceDocument: S.Schema<AutomatedReasoningPolicySourceDocument>;
export type AutomatedReasoningPolicyCoverageScore = number;
export type AutomatedReasoningPolicyAccuracyScore = number;
export type AutomatedReasoningPolicyDocumentId = string;
export type AutomatedReasoningPolicyStatementId = string;
export interface AutomatedReasoningPolicyStatementReference {
    documentId: string;
    statementId: string;
}
export declare const AutomatedReasoningPolicyStatementReference: S.Schema<AutomatedReasoningPolicyStatementReference>;
export type AutomatedReasoningPolicyStatementReferenceList = AutomatedReasoningPolicyStatementReference[];
export declare const AutomatedReasoningPolicyStatementReferenceList: any;
export type AutomatedReasoningPolicyJustificationText = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyJustificationList = (string | redacted.Redacted<string>)[];
export declare const AutomatedReasoningPolicyJustificationList: any;
export interface AutomatedReasoningPolicyRuleReport {
    rule: string;
    groundingStatements?: AutomatedReasoningPolicyStatementReference[];
    groundingJustifications?: (string | redacted.Redacted<string>)[];
    accuracyScore?: number;
    accuracyJustification?: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyRuleReport: S.Schema<AutomatedReasoningPolicyRuleReport>;
export type AutomatedReasoningPolicyRuleReportMap = {
    [key: string]: AutomatedReasoningPolicyRuleReport | undefined;
};
export declare const AutomatedReasoningPolicyRuleReportMap: any;
export interface AutomatedReasoningPolicyVariableReport {
    policyVariable: string | redacted.Redacted<string>;
    groundingStatements?: AutomatedReasoningPolicyStatementReference[];
    groundingJustifications?: (string | redacted.Redacted<string>)[];
    accuracyScore?: number;
    accuracyJustification?: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyVariableReport: S.Schema<AutomatedReasoningPolicyVariableReport>;
export type AutomatedReasoningPolicyVariableReportMap = {
    [key: string]: AutomatedReasoningPolicyVariableReport | undefined;
};
export declare const AutomatedReasoningPolicyVariableReportMap: any;
export type AutomatedReasoningPolicyStatementText = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyLineNumberList = number[];
export declare const AutomatedReasoningPolicyLineNumberList: any;
export interface AutomatedReasoningPolicyStatementLocation {
    lines: number[];
}
export declare const AutomatedReasoningPolicyStatementLocation: S.Schema<AutomatedReasoningPolicyStatementLocation>;
export interface AutomatedReasoningPolicyAtomicStatement {
    id: string;
    text: string | redacted.Redacted<string>;
    location: AutomatedReasoningPolicyStatementLocation;
}
export declare const AutomatedReasoningPolicyAtomicStatement: S.Schema<AutomatedReasoningPolicyAtomicStatement>;
export type AutomatedReasoningPolicyAtomicStatementList = AutomatedReasoningPolicyAtomicStatement[];
export declare const AutomatedReasoningPolicyAtomicStatementList: any;
export type AutomatedReasoningPolicyLineText = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyAnnotatedLine {
    lineNumber?: number;
    lineText?: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyAnnotatedLine: S.Schema<AutomatedReasoningPolicyAnnotatedLine>;
export type AutomatedReasoningPolicyAnnotatedContent = {
    line: AutomatedReasoningPolicyAnnotatedLine;
};
export declare const AutomatedReasoningPolicyAnnotatedContent: any;
export type AutomatedReasoningPolicyAnnotatedContentList = AutomatedReasoningPolicyAnnotatedContent[];
export declare const AutomatedReasoningPolicyAnnotatedContentList: any;
export interface AutomatedReasoningPolicyAnnotatedChunk {
    pageNumber?: number;
    content: AutomatedReasoningPolicyAnnotatedContent[];
}
export declare const AutomatedReasoningPolicyAnnotatedChunk: S.Schema<AutomatedReasoningPolicyAnnotatedChunk>;
export type AutomatedReasoningPolicyAnnotatedChunkList = AutomatedReasoningPolicyAnnotatedChunk[];
export declare const AutomatedReasoningPolicyAnnotatedChunkList: any;
export interface AutomatedReasoningPolicyReportSourceDocument {
    documentName: string | redacted.Redacted<string>;
    documentHash: string;
    documentId: string;
    atomicStatements: AutomatedReasoningPolicyAtomicStatement[];
    documentContent: AutomatedReasoningPolicyAnnotatedChunk[];
}
export declare const AutomatedReasoningPolicyReportSourceDocument: S.Schema<AutomatedReasoningPolicyReportSourceDocument>;
export type AutomatedReasoningPolicyReportSourceDocumentList = AutomatedReasoningPolicyReportSourceDocument[];
export declare const AutomatedReasoningPolicyReportSourceDocumentList: any;
export interface AutomatedReasoningPolicyFidelityReport {
    coverageScore: number;
    accuracyScore: number;
    ruleReports: {
        [key: string]: AutomatedReasoningPolicyRuleReport | undefined;
    };
    variableReports: {
        [key: string]: AutomatedReasoningPolicyVariableReport | undefined;
    };
    documentSources: AutomatedReasoningPolicyReportSourceDocument[];
}
export declare const AutomatedReasoningPolicyFidelityReport: S.Schema<AutomatedReasoningPolicyFidelityReport>;
export type AutomatedReasoningPolicyBuildResultAssets = {
    policyDefinition: AutomatedReasoningPolicyDefinition;
    qualityReport?: never;
    buildLog?: never;
    generatedTestCases?: never;
    policyScenarios?: never;
    assetManifest?: never;
    document?: never;
    fidelityReport?: never;
} | {
    policyDefinition?: never;
    qualityReport: AutomatedReasoningPolicyDefinitionQualityReport;
    buildLog?: never;
    generatedTestCases?: never;
    policyScenarios?: never;
    assetManifest?: never;
    document?: never;
    fidelityReport?: never;
} | {
    policyDefinition?: never;
    qualityReport?: never;
    buildLog: AutomatedReasoningPolicyBuildLog;
    generatedTestCases?: never;
    policyScenarios?: never;
    assetManifest?: never;
    document?: never;
    fidelityReport?: never;
} | {
    policyDefinition?: never;
    qualityReport?: never;
    buildLog?: never;
    generatedTestCases: AutomatedReasoningPolicyGeneratedTestCases;
    policyScenarios?: never;
    assetManifest?: never;
    document?: never;
    fidelityReport?: never;
} | {
    policyDefinition?: never;
    qualityReport?: never;
    buildLog?: never;
    generatedTestCases?: never;
    policyScenarios: AutomatedReasoningPolicyScenarios;
    assetManifest?: never;
    document?: never;
    fidelityReport?: never;
} | {
    policyDefinition?: never;
    qualityReport?: never;
    buildLog?: never;
    generatedTestCases?: never;
    policyScenarios?: never;
    assetManifest: AutomatedReasoningPolicyBuildResultAssetManifest;
    document?: never;
    fidelityReport?: never;
} | {
    policyDefinition?: never;
    qualityReport?: never;
    buildLog?: never;
    generatedTestCases?: never;
    policyScenarios?: never;
    assetManifest?: never;
    document: AutomatedReasoningPolicySourceDocument;
    fidelityReport?: never;
} | {
    policyDefinition?: never;
    qualityReport?: never;
    buildLog?: never;
    generatedTestCases?: never;
    policyScenarios?: never;
    assetManifest?: never;
    document?: never;
    fidelityReport: AutomatedReasoningPolicyFidelityReport;
};
export declare const AutomatedReasoningPolicyBuildResultAssets: any;
export interface GetAutomatedReasoningPolicyBuildWorkflowResultAssetsResponse {
    policyArn: string;
    buildWorkflowId: string;
    buildWorkflowAssets?: AutomatedReasoningPolicyBuildResultAssets;
}
export declare const GetAutomatedReasoningPolicyBuildWorkflowResultAssetsResponse: S.Schema<GetAutomatedReasoningPolicyBuildWorkflowResultAssetsResponse>;
export interface GetAutomatedReasoningPolicyNextScenarioRequest {
    policyArn: string;
    buildWorkflowId: string;
}
export declare const GetAutomatedReasoningPolicyNextScenarioRequest: S.Schema<GetAutomatedReasoningPolicyNextScenarioRequest>;
export interface GetAutomatedReasoningPolicyNextScenarioResponse {
    policyArn: string;
    scenario?: AutomatedReasoningPolicyScenario;
}
export declare const GetAutomatedReasoningPolicyNextScenarioResponse: S.Schema<GetAutomatedReasoningPolicyNextScenarioResponse>;
export interface GetAutomatedReasoningPolicyTestCaseRequest {
    policyArn: string;
    testCaseId: string;
}
export declare const GetAutomatedReasoningPolicyTestCaseRequest: S.Schema<GetAutomatedReasoningPolicyTestCaseRequest>;
export interface AutomatedReasoningPolicyTestCase {
    testCaseId: string;
    guardContent: string | redacted.Redacted<string>;
    queryContent?: string | redacted.Redacted<string>;
    expectedAggregatedFindingsResult?: AutomatedReasoningCheckResult;
    createdAt: Date;
    updatedAt: Date;
    confidenceThreshold?: number;
}
export declare const AutomatedReasoningPolicyTestCase: S.Schema<AutomatedReasoningPolicyTestCase>;
export interface GetAutomatedReasoningPolicyTestCaseResponse {
    policyArn: string;
    testCase: AutomatedReasoningPolicyTestCase;
}
export declare const GetAutomatedReasoningPolicyTestCaseResponse: S.Schema<GetAutomatedReasoningPolicyTestCaseResponse>;
export interface GetAutomatedReasoningPolicyTestResultRequest {
    policyArn: string;
    buildWorkflowId: string;
    testCaseId: string;
}
export declare const GetAutomatedReasoningPolicyTestResultRequest: S.Schema<GetAutomatedReasoningPolicyTestResultRequest>;
export type AutomatedReasoningPolicyTestRunStatus = "NOT_STARTED" | "SCHEDULED" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export declare const AutomatedReasoningPolicyTestRunStatus: any;
export type AutomatedReasoningLogicStatementContent = string | redacted.Redacted<string>;
export type AutomatedReasoningNaturalLanguageStatementContent = string | redacted.Redacted<string>;
export interface AutomatedReasoningLogicStatement {
    logic: string | redacted.Redacted<string>;
    naturalLanguage?: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningLogicStatement: S.Schema<AutomatedReasoningLogicStatement>;
export type AutomatedReasoningLogicStatementList = AutomatedReasoningLogicStatement[];
export declare const AutomatedReasoningLogicStatementList: any;
export interface AutomatedReasoningCheckInputTextReference {
    text?: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningCheckInputTextReference: S.Schema<AutomatedReasoningCheckInputTextReference>;
export type AutomatedReasoningCheckInputTextReferenceList = AutomatedReasoningCheckInputTextReference[];
export declare const AutomatedReasoningCheckInputTextReferenceList: any;
export interface AutomatedReasoningCheckTranslation {
    premises?: AutomatedReasoningLogicStatement[];
    claims: AutomatedReasoningLogicStatement[];
    untranslatedPremises?: AutomatedReasoningCheckInputTextReference[];
    untranslatedClaims?: AutomatedReasoningCheckInputTextReference[];
    confidence: number;
}
export declare const AutomatedReasoningCheckTranslation: S.Schema<AutomatedReasoningCheckTranslation>;
export interface AutomatedReasoningCheckScenario {
    statements?: AutomatedReasoningLogicStatement[];
}
export declare const AutomatedReasoningCheckScenario: S.Schema<AutomatedReasoningCheckScenario>;
export interface AutomatedReasoningCheckRule {
    id?: string;
    policyVersionArn?: string;
}
export declare const AutomatedReasoningCheckRule: S.Schema<AutomatedReasoningCheckRule>;
export type AutomatedReasoningCheckRuleList = AutomatedReasoningCheckRule[];
export declare const AutomatedReasoningCheckRuleList: any;
export type AutomatedReasoningCheckLogicWarningType = "ALWAYS_TRUE" | "ALWAYS_FALSE" | (string & {});
export declare const AutomatedReasoningCheckLogicWarningType: any;
export interface AutomatedReasoningCheckLogicWarning {
    type?: AutomatedReasoningCheckLogicWarningType;
    premises?: AutomatedReasoningLogicStatement[];
    claims?: AutomatedReasoningLogicStatement[];
}
export declare const AutomatedReasoningCheckLogicWarning: S.Schema<AutomatedReasoningCheckLogicWarning>;
export interface AutomatedReasoningCheckValidFinding {
    translation?: AutomatedReasoningCheckTranslation;
    claimsTrueScenario?: AutomatedReasoningCheckScenario;
    supportingRules?: AutomatedReasoningCheckRule[];
    logicWarning?: AutomatedReasoningCheckLogicWarning;
}
export declare const AutomatedReasoningCheckValidFinding: S.Schema<AutomatedReasoningCheckValidFinding>;
export interface AutomatedReasoningCheckInvalidFinding {
    translation?: AutomatedReasoningCheckTranslation;
    contradictingRules?: AutomatedReasoningCheckRule[];
    logicWarning?: AutomatedReasoningCheckLogicWarning;
}
export declare const AutomatedReasoningCheckInvalidFinding: S.Schema<AutomatedReasoningCheckInvalidFinding>;
export interface AutomatedReasoningCheckSatisfiableFinding {
    translation?: AutomatedReasoningCheckTranslation;
    claimsTrueScenario?: AutomatedReasoningCheckScenario;
    claimsFalseScenario?: AutomatedReasoningCheckScenario;
    logicWarning?: AutomatedReasoningCheckLogicWarning;
}
export declare const AutomatedReasoningCheckSatisfiableFinding: S.Schema<AutomatedReasoningCheckSatisfiableFinding>;
export interface AutomatedReasoningCheckImpossibleFinding {
    translation?: AutomatedReasoningCheckTranslation;
    contradictingRules?: AutomatedReasoningCheckRule[];
    logicWarning?: AutomatedReasoningCheckLogicWarning;
}
export declare const AutomatedReasoningCheckImpossibleFinding: S.Schema<AutomatedReasoningCheckImpossibleFinding>;
export type AutomatedReasoningCheckTranslationList = AutomatedReasoningCheckTranslation[];
export declare const AutomatedReasoningCheckTranslationList: any;
export interface AutomatedReasoningCheckTranslationOption {
    translations?: AutomatedReasoningCheckTranslation[];
}
export declare const AutomatedReasoningCheckTranslationOption: S.Schema<AutomatedReasoningCheckTranslationOption>;
export type AutomatedReasoningCheckTranslationOptionList = AutomatedReasoningCheckTranslationOption[];
export declare const AutomatedReasoningCheckTranslationOptionList: any;
export type AutomatedReasoningCheckDifferenceScenarioList = AutomatedReasoningCheckScenario[];
export declare const AutomatedReasoningCheckDifferenceScenarioList: any;
export interface AutomatedReasoningCheckTranslationAmbiguousFinding {
    options?: AutomatedReasoningCheckTranslationOption[];
    differenceScenarios?: AutomatedReasoningCheckScenario[];
}
export declare const AutomatedReasoningCheckTranslationAmbiguousFinding: S.Schema<AutomatedReasoningCheckTranslationAmbiguousFinding>;
export interface AutomatedReasoningCheckTooComplexFinding {
}
export declare const AutomatedReasoningCheckTooComplexFinding: S.Schema<AutomatedReasoningCheckTooComplexFinding>;
export interface AutomatedReasoningCheckNoTranslationsFinding {
}
export declare const AutomatedReasoningCheckNoTranslationsFinding: S.Schema<AutomatedReasoningCheckNoTranslationsFinding>;
export type AutomatedReasoningCheckFinding = {
    valid: AutomatedReasoningCheckValidFinding;
    invalid?: never;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid: AutomatedReasoningCheckInvalidFinding;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable: AutomatedReasoningCheckSatisfiableFinding;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable?: never;
    impossible: AutomatedReasoningCheckImpossibleFinding;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous: AutomatedReasoningCheckTranslationAmbiguousFinding;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex: AutomatedReasoningCheckTooComplexFinding;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations: AutomatedReasoningCheckNoTranslationsFinding;
};
export declare const AutomatedReasoningCheckFinding: any;
export type AutomatedReasoningCheckFindingList = AutomatedReasoningCheckFinding[];
export declare const AutomatedReasoningCheckFindingList: any;
export type AutomatedReasoningPolicyTestRunResult = "PASSED" | "FAILED" | (string & {});
export declare const AutomatedReasoningPolicyTestRunResult: any;
export interface AutomatedReasoningPolicyTestResult {
    testCase: AutomatedReasoningPolicyTestCase;
    policyArn: string;
    testRunStatus: AutomatedReasoningPolicyTestRunStatus;
    testFindings?: AutomatedReasoningCheckFinding[];
    testRunResult?: AutomatedReasoningPolicyTestRunResult;
    aggregatedTestFindingsResult?: AutomatedReasoningCheckResult;
    updatedAt: Date;
}
export declare const AutomatedReasoningPolicyTestResult: S.Schema<AutomatedReasoningPolicyTestResult>;
export interface GetAutomatedReasoningPolicyTestResultResponse {
    testResult: AutomatedReasoningPolicyTestResult;
}
export declare const GetAutomatedReasoningPolicyTestResultResponse: S.Schema<GetAutomatedReasoningPolicyTestResultResponse>;
export interface GetCustomModelRequest {
    modelIdentifier: string;
}
export declare const GetCustomModelRequest: S.Schema<GetCustomModelRequest>;
export type MetricFloat = number;
export interface TrainingMetrics {
    trainingLoss?: number;
}
export declare const TrainingMetrics: S.Schema<TrainingMetrics>;
export interface ValidatorMetric {
    validationLoss?: number;
}
export declare const ValidatorMetric: S.Schema<ValidatorMetric>;
export type ValidationMetrics = ValidatorMetric[];
export declare const ValidationMetrics: any;
export type ModelStatus = "Active" | "Creating" | "Failed" | (string & {});
export declare const ModelStatus: any;
export interface GetCustomModelResponse {
    modelArn: string;
    modelName: string;
    jobName?: string;
    jobArn?: string;
    baseModelArn?: string;
    customizationType?: CustomizationType;
    modelKmsKeyArn?: string;
    hyperParameters?: {
        [key: string]: string | undefined;
    };
    trainingDataConfig?: TrainingDataConfig;
    validationDataConfig?: ValidationDataConfig;
    outputDataConfig?: OutputDataConfig;
    trainingMetrics?: TrainingMetrics;
    validationMetrics?: ValidatorMetric[];
    creationTime: Date;
    customizationConfig?: CustomizationConfig;
    modelStatus?: ModelStatus;
    failureMessage?: string;
}
export declare const GetCustomModelResponse: S.Schema<GetCustomModelResponse>;
export interface GetCustomModelDeploymentRequest {
    customModelDeploymentIdentifier: string;
}
export declare const GetCustomModelDeploymentRequest: S.Schema<GetCustomModelDeploymentRequest>;
export type CustomModelDeploymentStatus = "Creating" | "Active" | "Failed" | (string & {});
export declare const CustomModelDeploymentStatus: any;
export type CustomModelDeploymentUpdateStatus = "Updating" | "UpdateCompleted" | "UpdateFailed" | (string & {});
export declare const CustomModelDeploymentUpdateStatus: any;
export interface CustomModelDeploymentUpdateDetails {
    modelArn: string;
    updateStatus: CustomModelDeploymentUpdateStatus;
}
export declare const CustomModelDeploymentUpdateDetails: S.Schema<CustomModelDeploymentUpdateDetails>;
export interface GetCustomModelDeploymentResponse {
    customModelDeploymentArn: string;
    modelDeploymentName: string;
    modelArn: string;
    createdAt: Date;
    status: CustomModelDeploymentStatus;
    description?: string;
    updateDetails?: CustomModelDeploymentUpdateDetails;
    failureMessage?: string;
    lastUpdatedAt?: Date;
}
export declare const GetCustomModelDeploymentResponse: S.Schema<GetCustomModelDeploymentResponse>;
export interface GetEvaluationJobRequest {
    jobIdentifier: string | redacted.Redacted<string>;
}
export declare const GetEvaluationJobRequest: S.Schema<GetEvaluationJobRequest>;
export type EvaluationJobType = "Human" | "Automated" | (string & {});
export declare const EvaluationJobType: any;
export type ErrorMessages = string[];
export declare const ErrorMessages: any;
export interface GetEvaluationJobResponse {
    jobName: string;
    status: EvaluationJobStatus;
    jobArn: string;
    jobDescription?: string | redacted.Redacted<string>;
    roleArn: string;
    customerEncryptionKeyId?: string;
    jobType: EvaluationJobType;
    applicationType?: ApplicationType;
    evaluationConfig: EvaluationConfig;
    inferenceConfig: EvaluationInferenceConfig;
    outputDataConfig: EvaluationOutputDataConfig;
    creationTime: Date;
    lastModifiedTime?: Date;
    failureMessages?: string[];
}
export declare const GetEvaluationJobResponse: S.Schema<GetEvaluationJobResponse>;
export type GetFoundationModelIdentifier = string;
export interface GetFoundationModelRequest {
    modelIdentifier: string;
}
export declare const GetFoundationModelRequest: S.Schema<GetFoundationModelRequest>;
export type FoundationModelArn = string;
export type BrandedName = string;
export type ModelModality = "TEXT" | "IMAGE" | "EMBEDDING" | (string & {});
export declare const ModelModality: any;
export type ModelModalityList = ModelModality[];
export declare const ModelModalityList: any;
export type ModelCustomization = "FINE_TUNING" | "CONTINUED_PRE_TRAINING" | "DISTILLATION" | (string & {});
export declare const ModelCustomization: any;
export type ModelCustomizationList = ModelCustomization[];
export declare const ModelCustomizationList: any;
export type InferenceType = "ON_DEMAND" | "PROVISIONED" | (string & {});
export declare const InferenceType: any;
export type InferenceTypeList = InferenceType[];
export declare const InferenceTypeList: any;
export type FoundationModelLifecycleStatus = "ACTIVE" | "LEGACY" | (string & {});
export declare const FoundationModelLifecycleStatus: any;
export interface FoundationModelLifecycle {
    status: FoundationModelLifecycleStatus;
    startOfLifeTime?: Date;
    endOfLifeTime?: Date;
    legacyTime?: Date;
    publicExtendedAccessTime?: Date;
}
export declare const FoundationModelLifecycle: S.Schema<FoundationModelLifecycle>;
export interface FoundationModelDetails {
    modelArn: string;
    modelId: string;
    modelName?: string;
    providerName?: string;
    inputModalities?: ModelModality[];
    outputModalities?: ModelModality[];
    responseStreamingSupported?: boolean;
    customizationsSupported?: ModelCustomization[];
    inferenceTypesSupported?: InferenceType[];
    modelLifecycle?: FoundationModelLifecycle;
}
export declare const FoundationModelDetails: S.Schema<FoundationModelDetails>;
export interface GetFoundationModelResponse {
    modelDetails?: FoundationModelDetails;
}
export declare const GetFoundationModelResponse: S.Schema<GetFoundationModelResponse>;
export interface GetFoundationModelAvailabilityRequest {
    modelId: string;
}
export declare const GetFoundationModelAvailabilityRequest: S.Schema<GetFoundationModelAvailabilityRequest>;
export type AgreementStatus = "AVAILABLE" | "PENDING" | "NOT_AVAILABLE" | "ERROR" | (string & {});
export declare const AgreementStatus: any;
export interface AgreementAvailability {
    status: AgreementStatus;
    errorMessage?: string;
}
export declare const AgreementAvailability: S.Schema<AgreementAvailability>;
export type AuthorizationStatus = "AUTHORIZED" | "NOT_AUTHORIZED" | (string & {});
export declare const AuthorizationStatus: any;
export type EntitlementAvailability = "AVAILABLE" | "NOT_AVAILABLE" | (string & {});
export declare const EntitlementAvailability: any;
export type RegionAvailability = "AVAILABLE" | "NOT_AVAILABLE" | (string & {});
export declare const RegionAvailability: any;
export interface GetFoundationModelAvailabilityResponse {
    modelId: string;
    agreementAvailability: AgreementAvailability;
    authorizationStatus: AuthorizationStatus;
    entitlementAvailability: EntitlementAvailability;
    regionAvailability: RegionAvailability;
}
export declare const GetFoundationModelAvailabilityResponse: S.Schema<GetFoundationModelAvailabilityResponse>;
export type GuardrailVersion = string;
export interface GetGuardrailRequest {
    guardrailIdentifier: string;
    guardrailVersion?: string;
}
export declare const GetGuardrailRequest: S.Schema<GetGuardrailRequest>;
export type GuardrailStatus = "CREATING" | "UPDATING" | "VERSIONING" | "READY" | "FAILED" | "DELETING" | (string & {});
export declare const GuardrailStatus: any;
export interface GuardrailTopic {
    name: string | redacted.Redacted<string>;
    definition: string | redacted.Redacted<string>;
    examples?: (string | redacted.Redacted<string>)[];
    type?: GuardrailTopicType;
    inputAction?: GuardrailTopicAction;
    outputAction?: GuardrailTopicAction;
    inputEnabled?: boolean;
    outputEnabled?: boolean;
}
export declare const GuardrailTopic: S.Schema<GuardrailTopic>;
export type GuardrailTopics = GuardrailTopic[];
export declare const GuardrailTopics: any;
export interface GuardrailTopicsTier {
    tierName: GuardrailTopicsTierName;
}
export declare const GuardrailTopicsTier: S.Schema<GuardrailTopicsTier>;
export interface GuardrailTopicPolicy {
    topics: GuardrailTopic[];
    tier?: GuardrailTopicsTier;
}
export declare const GuardrailTopicPolicy: S.Schema<GuardrailTopicPolicy>;
export interface GuardrailContentFilter {
    type: GuardrailContentFilterType;
    inputStrength: GuardrailFilterStrength;
    outputStrength: GuardrailFilterStrength;
    inputModalities?: GuardrailModality[];
    outputModalities?: GuardrailModality[];
    inputAction?: GuardrailContentFilterAction;
    outputAction?: GuardrailContentFilterAction;
    inputEnabled?: boolean;
    outputEnabled?: boolean;
}
export declare const GuardrailContentFilter: S.Schema<GuardrailContentFilter>;
export type GuardrailContentFilters = GuardrailContentFilter[];
export declare const GuardrailContentFilters: any;
export interface GuardrailContentFiltersTier {
    tierName: GuardrailContentFiltersTierName;
}
export declare const GuardrailContentFiltersTier: S.Schema<GuardrailContentFiltersTier>;
export interface GuardrailContentPolicy {
    filters?: GuardrailContentFilter[];
    tier?: GuardrailContentFiltersTier;
}
export declare const GuardrailContentPolicy: S.Schema<GuardrailContentPolicy>;
export interface GuardrailWord {
    text: string;
    inputAction?: GuardrailWordAction;
    outputAction?: GuardrailWordAction;
    inputEnabled?: boolean;
    outputEnabled?: boolean;
}
export declare const GuardrailWord: S.Schema<GuardrailWord>;
export type GuardrailWords = GuardrailWord[];
export declare const GuardrailWords: any;
export interface GuardrailManagedWords {
    type: GuardrailManagedWordsType;
    inputAction?: GuardrailWordAction;
    outputAction?: GuardrailWordAction;
    inputEnabled?: boolean;
    outputEnabled?: boolean;
}
export declare const GuardrailManagedWords: S.Schema<GuardrailManagedWords>;
export type GuardrailManagedWordLists = GuardrailManagedWords[];
export declare const GuardrailManagedWordLists: any;
export interface GuardrailWordPolicy {
    words?: GuardrailWord[];
    managedWordLists?: GuardrailManagedWords[];
}
export declare const GuardrailWordPolicy: S.Schema<GuardrailWordPolicy>;
export interface GuardrailPiiEntity {
    type: GuardrailPiiEntityType;
    action: GuardrailSensitiveInformationAction;
    inputAction?: GuardrailSensitiveInformationAction;
    outputAction?: GuardrailSensitiveInformationAction;
    inputEnabled?: boolean;
    outputEnabled?: boolean;
}
export declare const GuardrailPiiEntity: S.Schema<GuardrailPiiEntity>;
export type GuardrailPiiEntities = GuardrailPiiEntity[];
export declare const GuardrailPiiEntities: any;
export interface GuardrailRegex {
    name: string;
    description?: string;
    pattern: string;
    action: GuardrailSensitiveInformationAction;
    inputAction?: GuardrailSensitiveInformationAction;
    outputAction?: GuardrailSensitiveInformationAction;
    inputEnabled?: boolean;
    outputEnabled?: boolean;
}
export declare const GuardrailRegex: S.Schema<GuardrailRegex>;
export type GuardrailRegexes = GuardrailRegex[];
export declare const GuardrailRegexes: any;
export interface GuardrailSensitiveInformationPolicy {
    piiEntities?: GuardrailPiiEntity[];
    regexes?: GuardrailRegex[];
}
export declare const GuardrailSensitiveInformationPolicy: S.Schema<GuardrailSensitiveInformationPolicy>;
export interface GuardrailContextualGroundingFilter {
    type: GuardrailContextualGroundingFilterType;
    threshold: number;
    action?: GuardrailContextualGroundingAction;
    enabled?: boolean;
}
export declare const GuardrailContextualGroundingFilter: S.Schema<GuardrailContextualGroundingFilter>;
export type GuardrailContextualGroundingFilters = GuardrailContextualGroundingFilter[];
export declare const GuardrailContextualGroundingFilters: any;
export interface GuardrailContextualGroundingPolicy {
    filters: GuardrailContextualGroundingFilter[];
}
export declare const GuardrailContextualGroundingPolicy: S.Schema<GuardrailContextualGroundingPolicy>;
export interface GuardrailAutomatedReasoningPolicy {
    policies: string[];
    confidenceThreshold?: number;
}
export declare const GuardrailAutomatedReasoningPolicy: S.Schema<GuardrailAutomatedReasoningPolicy>;
export type GuardrailCrossRegionGuardrailProfileId = string;
export type GuardrailCrossRegionGuardrailProfileArn = string;
export interface GuardrailCrossRegionDetails {
    guardrailProfileId?: string;
    guardrailProfileArn?: string;
}
export declare const GuardrailCrossRegionDetails: S.Schema<GuardrailCrossRegionDetails>;
export type GuardrailStatusReason = string | redacted.Redacted<string>;
export type GuardrailStatusReasons = (string | redacted.Redacted<string>)[];
export declare const GuardrailStatusReasons: any;
export type GuardrailFailureRecommendation = string | redacted.Redacted<string>;
export type GuardrailFailureRecommendations = (string | redacted.Redacted<string>)[];
export declare const GuardrailFailureRecommendations: any;
export interface GetGuardrailResponse {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    guardrailId: string;
    guardrailArn: string;
    version: string;
    status: GuardrailStatus;
    topicPolicy?: GuardrailTopicPolicy;
    contentPolicy?: GuardrailContentPolicy;
    wordPolicy?: GuardrailWordPolicy;
    sensitiveInformationPolicy?: GuardrailSensitiveInformationPolicy;
    contextualGroundingPolicy?: GuardrailContextualGroundingPolicy;
    automatedReasoningPolicy?: GuardrailAutomatedReasoningPolicy;
    crossRegionDetails?: GuardrailCrossRegionDetails;
    createdAt: Date;
    updatedAt: Date;
    statusReasons?: (string | redacted.Redacted<string>)[];
    failureRecommendations?: (string | redacted.Redacted<string>)[];
    blockedInputMessaging: string | redacted.Redacted<string>;
    blockedOutputsMessaging: string | redacted.Redacted<string>;
    kmsKeyArn?: string;
}
export declare const GetGuardrailResponse: S.Schema<GetGuardrailResponse>;
export interface GetImportedModelRequest {
    modelIdentifier: string;
}
export declare const GetImportedModelRequest: S.Schema<GetImportedModelRequest>;
export type ImportedModelArn = string;
export type InstructSupported = boolean;
export type CustomModelUnitsVersion = string;
export interface CustomModelUnits {
    customModelUnitsPerModelCopy?: number;
    customModelUnitsVersion?: string;
}
export declare const CustomModelUnits: S.Schema<CustomModelUnits>;
export interface GetImportedModelResponse {
    modelArn?: string;
    modelName?: string;
    jobName?: string;
    jobArn?: string;
    modelDataSource?: ModelDataSource;
    creationTime?: Date;
    modelArchitecture?: string;
    modelKmsKeyArn?: string;
    instructSupported?: boolean;
    customModelUnits?: CustomModelUnits;
}
export declare const GetImportedModelResponse: S.Schema<GetImportedModelResponse>;
export interface GetInferenceProfileRequest {
    inferenceProfileIdentifier: string;
}
export declare const GetInferenceProfileRequest: S.Schema<GetInferenceProfileRequest>;
export interface InferenceProfileModel {
    modelArn?: string;
}
export declare const InferenceProfileModel: S.Schema<InferenceProfileModel>;
export type InferenceProfileModels = InferenceProfileModel[];
export declare const InferenceProfileModels: any;
export type InferenceProfileId = string;
export type InferenceProfileType = "SYSTEM_DEFINED" | "APPLICATION" | (string & {});
export declare const InferenceProfileType: any;
export interface GetInferenceProfileResponse {
    inferenceProfileName: string;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    updatedAt?: Date;
    inferenceProfileArn: string;
    models: InferenceProfileModel[];
    inferenceProfileId: string;
    status: InferenceProfileStatus;
    type: InferenceProfileType;
}
export declare const GetInferenceProfileResponse: S.Schema<GetInferenceProfileResponse>;
export interface GetMarketplaceModelEndpointRequest {
    endpointArn: string;
}
export declare const GetMarketplaceModelEndpointRequest: S.Schema<GetMarketplaceModelEndpointRequest>;
export interface GetMarketplaceModelEndpointResponse {
    marketplaceModelEndpoint?: MarketplaceModelEndpoint;
}
export declare const GetMarketplaceModelEndpointResponse: S.Schema<GetMarketplaceModelEndpointResponse>;
export interface GetModelCopyJobRequest {
    jobArn: string;
}
export declare const GetModelCopyJobRequest: S.Schema<GetModelCopyJobRequest>;
export type ModelCopyJobStatus = "InProgress" | "Completed" | "Failed" | (string & {});
export declare const ModelCopyJobStatus: any;
export interface GetModelCopyJobResponse {
    jobArn: string;
    status: ModelCopyJobStatus;
    creationTime: Date;
    targetModelArn: string;
    targetModelName?: string;
    sourceAccountId: string;
    sourceModelArn: string;
    targetModelKmsKeyArn?: string;
    targetModelTags?: Tag[];
    failureMessage?: string;
    sourceModelName?: string;
}
export declare const GetModelCopyJobResponse: S.Schema<GetModelCopyJobResponse>;
export type ModelCustomizationJobIdentifier = string;
export interface GetModelCustomizationJobRequest {
    jobIdentifier: string;
}
export declare const GetModelCustomizationJobRequest: S.Schema<GetModelCustomizationJobRequest>;
export type ModelCustomizationJobStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | (string & {});
export declare const ModelCustomizationJobStatus: any;
export type JobStatusDetails = "InProgress" | "Completed" | "Stopping" | "Stopped" | "Failed" | "NotStarted" | (string & {});
export declare const JobStatusDetails: any;
export interface ValidationDetails {
    status?: JobStatusDetails;
    creationTime?: Date;
    lastModifiedTime?: Date;
}
export declare const ValidationDetails: S.Schema<ValidationDetails>;
export interface DataProcessingDetails {
    status?: JobStatusDetails;
    creationTime?: Date;
    lastModifiedTime?: Date;
}
export declare const DataProcessingDetails: S.Schema<DataProcessingDetails>;
export interface TrainingDetails {
    status?: JobStatusDetails;
    creationTime?: Date;
    lastModifiedTime?: Date;
}
export declare const TrainingDetails: S.Schema<TrainingDetails>;
export interface StatusDetails {
    validationDetails?: ValidationDetails;
    dataProcessingDetails?: DataProcessingDetails;
    trainingDetails?: TrainingDetails;
}
export declare const StatusDetails: S.Schema<StatusDetails>;
export interface GetModelCustomizationJobResponse {
    jobArn: string;
    jobName: string;
    outputModelName: string;
    outputModelArn?: string;
    clientRequestToken?: string;
    roleArn: string;
    status?: ModelCustomizationJobStatus;
    statusDetails?: StatusDetails;
    failureMessage?: string;
    creationTime: Date;
    lastModifiedTime?: Date;
    endTime?: Date;
    baseModelArn: string;
    hyperParameters?: {
        [key: string]: string | undefined;
    };
    trainingDataConfig: TrainingDataConfig;
    validationDataConfig: ValidationDataConfig;
    outputDataConfig: OutputDataConfig;
    customizationType?: CustomizationType;
    outputModelKmsKeyArn?: string;
    trainingMetrics?: TrainingMetrics;
    validationMetrics?: ValidatorMetric[];
    vpcConfig?: VpcConfig;
    customizationConfig?: CustomizationConfig;
}
export declare const GetModelCustomizationJobResponse: S.Schema<GetModelCustomizationJobResponse>;
export type ModelImportJobIdentifier = string;
export interface GetModelImportJobRequest {
    jobIdentifier: string;
}
export declare const GetModelImportJobRequest: S.Schema<GetModelImportJobRequest>;
export type ModelImportJobStatus = "InProgress" | "Completed" | "Failed" | (string & {});
export declare const ModelImportJobStatus: any;
export interface GetModelImportJobResponse {
    jobArn?: string;
    jobName?: string;
    importedModelName?: string;
    importedModelArn?: string;
    roleArn?: string;
    modelDataSource?: ModelDataSource;
    status?: ModelImportJobStatus;
    failureMessage?: string;
    creationTime?: Date;
    lastModifiedTime?: Date;
    endTime?: Date;
    vpcConfig?: VpcConfig;
    importedModelKmsKeyArn?: string;
}
export declare const GetModelImportJobResponse: S.Schema<GetModelImportJobResponse>;
export type ModelInvocationJobIdentifier = string;
export interface GetModelInvocationJobRequest {
    jobIdentifier: string;
}
export declare const GetModelInvocationJobRequest: S.Schema<GetModelInvocationJobRequest>;
export type ModelInvocationJobStatus = "Submitted" | "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | "PartiallyCompleted" | "Expired" | "Validating" | "Scheduled" | (string & {});
export declare const ModelInvocationJobStatus: any;
export type Message = string | redacted.Redacted<string>;
export type NonNegativeLong = number;
export interface GetModelInvocationJobResponse {
    jobArn: string;
    jobName?: string;
    modelId: string;
    clientRequestToken?: string;
    roleArn: string;
    status?: ModelInvocationJobStatus;
    message?: string | redacted.Redacted<string>;
    submitTime: Date;
    lastModifiedTime?: Date;
    endTime?: Date;
    inputDataConfig: ModelInvocationJobInputDataConfig;
    outputDataConfig: ModelInvocationJobOutputDataConfig;
    vpcConfig?: VpcConfig;
    timeoutDurationInHours?: number;
    jobExpirationTime?: Date;
    modelInvocationType?: ModelInvocationType;
    totalRecordCount?: number;
    processedRecordCount?: number;
    successRecordCount?: number;
    errorRecordCount?: number;
}
export declare const GetModelInvocationJobResponse: S.Schema<GetModelInvocationJobResponse>;
export interface GetModelInvocationLoggingConfigurationRequest {
}
export declare const GetModelInvocationLoggingConfigurationRequest: S.Schema<GetModelInvocationLoggingConfigurationRequest>;
export type LogGroupName = string;
export type BucketName = string;
export type KeyPrefix = string;
export interface S3Config {
    bucketName: string;
    keyPrefix?: string;
}
export declare const S3Config: S.Schema<S3Config>;
export interface CloudWatchConfig {
    logGroupName: string;
    roleArn: string;
    largeDataDeliveryS3Config?: S3Config;
}
export declare const CloudWatchConfig: S.Schema<CloudWatchConfig>;
export interface LoggingConfig {
    cloudWatchConfig?: CloudWatchConfig;
    s3Config?: S3Config;
    textDataDeliveryEnabled?: boolean;
    imageDataDeliveryEnabled?: boolean;
    embeddingDataDeliveryEnabled?: boolean;
    videoDataDeliveryEnabled?: boolean;
    audioDataDeliveryEnabled?: boolean;
}
export declare const LoggingConfig: S.Schema<LoggingConfig>;
export interface GetModelInvocationLoggingConfigurationResponse {
    loggingConfig?: LoggingConfig;
}
export declare const GetModelInvocationLoggingConfigurationResponse: S.Schema<GetModelInvocationLoggingConfigurationResponse>;
export interface GetPromptRouterRequest {
    promptRouterArn: string;
}
export declare const GetPromptRouterRequest: S.Schema<GetPromptRouterRequest>;
export type PromptRouterStatus = "AVAILABLE" | (string & {});
export declare const PromptRouterStatus: any;
export type PromptRouterType = "custom" | "default" | (string & {});
export declare const PromptRouterType: any;
export interface GetPromptRouterResponse {
    promptRouterName: string;
    routingCriteria: RoutingCriteria;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    updatedAt?: Date;
    promptRouterArn: string;
    models: (PromptRouterTargetModel & {
        modelArn: PromptRouterTargetModelArn;
    })[];
    fallbackModel: PromptRouterTargetModel & {
        modelArn: PromptRouterTargetModelArn;
    };
    status: PromptRouterStatus;
    type: PromptRouterType;
}
export declare const GetPromptRouterResponse: S.Schema<GetPromptRouterResponse>;
export interface GetProvisionedModelThroughputRequest {
    provisionedModelId: string;
}
export declare const GetProvisionedModelThroughputRequest: S.Schema<GetProvisionedModelThroughputRequest>;
export type ProvisionedModelStatus = "Creating" | "InService" | "Updating" | "Failed" | (string & {});
export declare const ProvisionedModelStatus: any;
export interface GetProvisionedModelThroughputResponse {
    modelUnits: number;
    desiredModelUnits: number;
    provisionedModelName: string;
    provisionedModelArn: string;
    modelArn: string;
    desiredModelArn: string;
    foundationModelArn: string;
    status: ProvisionedModelStatus;
    creationTime: Date;
    lastModifiedTime: Date;
    failureMessage?: string;
    commitmentDuration?: CommitmentDuration;
    commitmentExpirationTime?: Date;
}
export declare const GetProvisionedModelThroughputResponse: S.Schema<GetProvisionedModelThroughputResponse>;
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export declare const GetResourcePolicyRequest: S.Schema<GetResourcePolicyRequest>;
export type ResourcePolicyDocument = string;
export interface GetResourcePolicyResponse {
    resourcePolicy?: string;
}
export declare const GetResourcePolicyResponse: S.Schema<GetResourcePolicyResponse>;
export interface GetUseCaseForModelAccessRequest {
}
export declare const GetUseCaseForModelAccessRequest: S.Schema<GetUseCaseForModelAccessRequest>;
export type AcknowledgementFormDataBody = Uint8Array;
export interface GetUseCaseForModelAccessResponse {
    formData: Uint8Array;
}
export declare const GetUseCaseForModelAccessResponse: S.Schema<GetUseCaseForModelAccessResponse>;
export type MaxResults = number;
export type PaginationToken = string;
export type SortJobsBy = "CreationTime" | (string & {});
export declare const SortJobsBy: any;
export type SortOrder = "Ascending" | "Descending" | (string & {});
export declare const SortOrder: any;
export interface ListAdvancedPromptOptimizationJobsRequest {
    maxResults?: number;
    nextToken?: string;
    sortBy?: SortJobsBy;
    sortOrder?: SortOrder;
}
export declare const ListAdvancedPromptOptimizationJobsRequest: S.Schema<ListAdvancedPromptOptimizationJobsRequest>;
export interface AdvancedPromptOptimizationJobSummary {
    jobArn: string;
    jobName: string;
    jobStatus: AdvancedPromptOptimizationJobStatus;
    creationTime: Date;
    lastModifiedTime?: Date;
}
export declare const AdvancedPromptOptimizationJobSummary: S.Schema<AdvancedPromptOptimizationJobSummary>;
export type AdvancedPromptOptimizationJobSummaries = AdvancedPromptOptimizationJobSummary[];
export declare const AdvancedPromptOptimizationJobSummaries: any;
export interface ListAdvancedPromptOptimizationJobsResponse {
    jobSummaries?: AdvancedPromptOptimizationJobSummary[];
    nextToken?: string;
}
export declare const ListAdvancedPromptOptimizationJobsResponse: S.Schema<ListAdvancedPromptOptimizationJobsResponse>;
export interface ListAutomatedReasoningPoliciesRequest {
    policyArn?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAutomatedReasoningPoliciesRequest: S.Schema<ListAutomatedReasoningPoliciesRequest>;
export interface AutomatedReasoningPolicySummary {
    policyArn: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    version: string;
    policyId: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const AutomatedReasoningPolicySummary: S.Schema<AutomatedReasoningPolicySummary>;
export type AutomatedReasoningPolicySummaries = AutomatedReasoningPolicySummary[];
export declare const AutomatedReasoningPolicySummaries: any;
export interface ListAutomatedReasoningPoliciesResponse {
    automatedReasoningPolicySummaries: AutomatedReasoningPolicySummary[];
    nextToken?: string;
}
export declare const ListAutomatedReasoningPoliciesResponse: S.Schema<ListAutomatedReasoningPoliciesResponse>;
export interface ListAutomatedReasoningPolicyBuildWorkflowsRequest {
    policyArn: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAutomatedReasoningPolicyBuildWorkflowsRequest: S.Schema<ListAutomatedReasoningPolicyBuildWorkflowsRequest>;
export interface AutomatedReasoningPolicyBuildWorkflowSummary {
    policyArn: string;
    buildWorkflowId: string;
    status: AutomatedReasoningPolicyBuildWorkflowStatus;
    buildWorkflowType: AutomatedReasoningPolicyBuildWorkflowType;
    createdAt: Date;
    updatedAt: Date;
}
export declare const AutomatedReasoningPolicyBuildWorkflowSummary: S.Schema<AutomatedReasoningPolicyBuildWorkflowSummary>;
export type AutomatedReasoningPolicyBuildWorkflowSummaries = AutomatedReasoningPolicyBuildWorkflowSummary[];
export declare const AutomatedReasoningPolicyBuildWorkflowSummaries: any;
export interface ListAutomatedReasoningPolicyBuildWorkflowsResponse {
    automatedReasoningPolicyBuildWorkflowSummaries: AutomatedReasoningPolicyBuildWorkflowSummary[];
    nextToken?: string;
}
export declare const ListAutomatedReasoningPolicyBuildWorkflowsResponse: S.Schema<ListAutomatedReasoningPolicyBuildWorkflowsResponse>;
export interface ListAutomatedReasoningPolicyTestCasesRequest {
    policyArn: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAutomatedReasoningPolicyTestCasesRequest: S.Schema<ListAutomatedReasoningPolicyTestCasesRequest>;
export type AutomatedReasoningPolicyTestCaseList = AutomatedReasoningPolicyTestCase[];
export declare const AutomatedReasoningPolicyTestCaseList: any;
export interface ListAutomatedReasoningPolicyTestCasesResponse {
    testCases: AutomatedReasoningPolicyTestCase[];
    nextToken?: string;
}
export declare const ListAutomatedReasoningPolicyTestCasesResponse: S.Schema<ListAutomatedReasoningPolicyTestCasesResponse>;
export interface ListAutomatedReasoningPolicyTestResultsRequest {
    policyArn: string;
    buildWorkflowId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAutomatedReasoningPolicyTestResultsRequest: S.Schema<ListAutomatedReasoningPolicyTestResultsRequest>;
export type AutomatedReasoningPolicyTestList = AutomatedReasoningPolicyTestResult[];
export declare const AutomatedReasoningPolicyTestList: any;
export interface ListAutomatedReasoningPolicyTestResultsResponse {
    testResults: AutomatedReasoningPolicyTestResult[];
    nextToken?: string;
}
export declare const ListAutomatedReasoningPolicyTestResultsResponse: S.Schema<ListAutomatedReasoningPolicyTestResultsResponse>;
export type SortModelsBy = "CreationTime" | (string & {});
export declare const SortModelsBy: any;
export interface ListCustomModelDeploymentsRequest {
    createdBefore?: Date;
    createdAfter?: Date;
    nameContains?: string;
    maxResults?: number;
    nextToken?: string;
    sortBy?: SortModelsBy;
    sortOrder?: SortOrder;
    statusEquals?: CustomModelDeploymentStatus;
    modelArnEquals?: string;
}
export declare const ListCustomModelDeploymentsRequest: S.Schema<ListCustomModelDeploymentsRequest>;
export interface CustomModelDeploymentSummary {
    customModelDeploymentArn: string;
    customModelDeploymentName: string;
    modelArn: string;
    createdAt: Date;
    status: CustomModelDeploymentStatus;
    lastUpdatedAt?: Date;
    failureMessage?: string;
}
export declare const CustomModelDeploymentSummary: S.Schema<CustomModelDeploymentSummary>;
export type CustomModelDeploymentSummaryList = CustomModelDeploymentSummary[];
export declare const CustomModelDeploymentSummaryList: any;
export interface ListCustomModelDeploymentsResponse {
    nextToken?: string;
    modelDeploymentSummaries?: CustomModelDeploymentSummary[];
}
export declare const ListCustomModelDeploymentsResponse: S.Schema<ListCustomModelDeploymentsResponse>;
export interface ListCustomModelsRequest {
    creationTimeBefore?: Date;
    creationTimeAfter?: Date;
    nameContains?: string;
    baseModelArnEquals?: string;
    foundationModelArnEquals?: string;
    maxResults?: number;
    nextToken?: string;
    sortBy?: SortModelsBy;
    sortOrder?: SortOrder;
    isOwned?: boolean;
    modelStatus?: ModelStatus;
}
export declare const ListCustomModelsRequest: S.Schema<ListCustomModelsRequest>;
export type ModelName = string;
export interface CustomModelSummary {
    modelArn: string;
    modelName: string;
    creationTime: Date;
    baseModelArn: string;
    baseModelName: string;
    customizationType?: CustomizationType;
    ownerAccountId?: string;
    modelStatus?: ModelStatus;
}
export declare const CustomModelSummary: S.Schema<CustomModelSummary>;
export type CustomModelSummaryList = CustomModelSummary[];
export declare const CustomModelSummaryList: any;
export interface ListCustomModelsResponse {
    nextToken?: string;
    modelSummaries?: CustomModelSummary[];
}
export declare const ListCustomModelsResponse: S.Schema<ListCustomModelsResponse>;
export interface ListEnforcedGuardrailsConfigurationRequest {
    nextToken?: string;
}
export declare const ListEnforcedGuardrailsConfigurationRequest: S.Schema<ListEnforcedGuardrailsConfigurationRequest>;
export type InputTags = "HONOR" | "IGNORE" | (string & {});
export declare const InputTags: any;
export type SelectiveGuardingMode = "SELECTIVE" | "COMPREHENSIVE" | (string & {});
export declare const SelectiveGuardingMode: any;
export interface SelectiveContentGuarding {
    system?: SelectiveGuardingMode;
    messages?: SelectiveGuardingMode;
}
export declare const SelectiveContentGuarding: S.Schema<SelectiveContentGuarding>;
export type ConfigurationOwner = string;
export type IncludedModelId = string;
export type IncludedModelsList = string[];
export declare const IncludedModelsList: any;
export type ExcludedModelId = string;
export type ExcludedModelsList = string[];
export declare const ExcludedModelsList: any;
export interface ModelEnforcement {
    includedModels: string[];
    excludedModels: string[];
}
export declare const ModelEnforcement: S.Schema<ModelEnforcement>;
export interface AccountEnforcedGuardrailOutputConfiguration {
    configId?: string;
    guardrailArn?: string;
    guardrailId?: string;
    inputTags?: InputTags;
    selectiveContentGuarding?: SelectiveContentGuarding;
    guardrailVersion?: string;
    createdAt?: Date;
    createdBy?: string;
    updatedAt?: Date;
    updatedBy?: string;
    owner?: string;
    modelEnforcement?: ModelEnforcement;
}
export declare const AccountEnforcedGuardrailOutputConfiguration: S.Schema<AccountEnforcedGuardrailOutputConfiguration>;
export type AccountEnforcedGuardrailsOutputConfiguration = AccountEnforcedGuardrailOutputConfiguration[];
export declare const AccountEnforcedGuardrailsOutputConfiguration: any;
export interface ListEnforcedGuardrailsConfigurationResponse {
    guardrailsConfig: AccountEnforcedGuardrailOutputConfiguration[];
    nextToken?: string;
}
export declare const ListEnforcedGuardrailsConfigurationResponse: S.Schema<ListEnforcedGuardrailsConfigurationResponse>;
export interface ListEvaluationJobsRequest {
    creationTimeAfter?: Date;
    creationTimeBefore?: Date;
    statusEquals?: EvaluationJobStatus;
    applicationTypeEquals?: ApplicationType;
    nameContains?: string;
    maxResults?: number;
    nextToken?: string;
    sortBy?: SortJobsBy;
    sortOrder?: SortOrder;
}
export declare const ListEvaluationJobsRequest: S.Schema<ListEvaluationJobsRequest>;
export type EvaluationTaskTypes = EvaluationTaskType[];
export declare const EvaluationTaskTypes: any;
export type EvaluationBedrockModelIdentifiers = string[];
export declare const EvaluationBedrockModelIdentifiers: any;
export type EvaluationBedrockKnowledgeBaseIdentifiers = string[];
export declare const EvaluationBedrockKnowledgeBaseIdentifiers: any;
export type EvaluatorModelIdentifiers = string[];
export declare const EvaluatorModelIdentifiers: any;
export type EvaluationPrecomputedInferenceSourceIdentifiers = string[];
export declare const EvaluationPrecomputedInferenceSourceIdentifiers: any;
export interface EvaluationModelConfigSummary {
    bedrockModelIdentifiers?: string[];
    precomputedInferenceSourceIdentifiers?: string[];
}
export declare const EvaluationModelConfigSummary: S.Schema<EvaluationModelConfigSummary>;
export type EvaluationPrecomputedRagSourceIdentifiers = string[];
export declare const EvaluationPrecomputedRagSourceIdentifiers: any;
export interface EvaluationRagConfigSummary {
    bedrockKnowledgeBaseIdentifiers?: string[];
    precomputedRagSourceIdentifiers?: string[];
}
export declare const EvaluationRagConfigSummary: S.Schema<EvaluationRagConfigSummary>;
export interface EvaluationInferenceConfigSummary {
    modelConfigSummary?: EvaluationModelConfigSummary;
    ragConfigSummary?: EvaluationRagConfigSummary;
}
export declare const EvaluationInferenceConfigSummary: S.Schema<EvaluationInferenceConfigSummary>;
export interface EvaluationSummary {
    jobArn: string;
    jobName: string;
    status: EvaluationJobStatus;
    creationTime: Date;
    jobType: EvaluationJobType;
    evaluationTaskTypes: EvaluationTaskType[];
    modelIdentifiers?: string[];
    ragIdentifiers?: string[];
    evaluatorModelIdentifiers?: string[];
    customMetricsEvaluatorModelIdentifiers?: string[];
    inferenceConfigSummary?: EvaluationInferenceConfigSummary;
    applicationType?: ApplicationType;
}
export declare const EvaluationSummary: S.Schema<EvaluationSummary>;
export type EvaluationSummaries = EvaluationSummary[];
export declare const EvaluationSummaries: any;
export interface ListEvaluationJobsResponse {
    nextToken?: string;
    jobSummaries?: EvaluationSummary[];
}
export declare const ListEvaluationJobsResponse: S.Schema<ListEvaluationJobsResponse>;
export type OfferType = "ALL" | "PUBLIC" | (string & {});
export declare const OfferType: any;
export interface ListFoundationModelAgreementOffersRequest {
    modelId: string;
    offerType?: OfferType;
}
export declare const ListFoundationModelAgreementOffersRequest: S.Schema<ListFoundationModelAgreementOffersRequest>;
export type OfferId = string;
export interface DimensionalPriceRate {
    dimension?: string;
    price?: string;
    description?: string;
    unit?: string;
}
export declare const DimensionalPriceRate: S.Schema<DimensionalPriceRate>;
export type RateCard = DimensionalPriceRate[];
export declare const RateCard: any;
export interface PricingTerm {
    rateCard: DimensionalPriceRate[];
}
export declare const PricingTerm: S.Schema<PricingTerm>;
export interface LegalTerm {
    url?: string;
}
export declare const LegalTerm: S.Schema<LegalTerm>;
export interface SupportTerm {
    refundPolicyDescription?: string;
}
export declare const SupportTerm: S.Schema<SupportTerm>;
export interface ValidityTerm {
    agreementDuration?: string;
}
export declare const ValidityTerm: S.Schema<ValidityTerm>;
export interface TermDetails {
    usageBasedPricingTerm: PricingTerm;
    legalTerm: LegalTerm;
    supportTerm: SupportTerm;
    validityTerm?: ValidityTerm;
}
export declare const TermDetails: S.Schema<TermDetails>;
export interface Offer {
    offerId?: string;
    offerToken: string;
    termDetails: TermDetails;
}
export declare const Offer: S.Schema<Offer>;
export type Offers = Offer[];
export declare const Offers: any;
export interface ListFoundationModelAgreementOffersResponse {
    modelId: string;
    offers: Offer[];
}
export declare const ListFoundationModelAgreementOffersResponse: S.Schema<ListFoundationModelAgreementOffersResponse>;
export type Provider = string;
export interface ListFoundationModelsRequest {
    byProvider?: string;
    byCustomizationType?: ModelCustomization;
    byOutputModality?: ModelModality;
    byInferenceType?: InferenceType;
}
export declare const ListFoundationModelsRequest: S.Schema<ListFoundationModelsRequest>;
export interface FoundationModelSummary {
    modelArn: string;
    modelId: string;
    modelName?: string;
    providerName?: string;
    inputModalities?: ModelModality[];
    outputModalities?: ModelModality[];
    responseStreamingSupported?: boolean;
    customizationsSupported?: ModelCustomization[];
    inferenceTypesSupported?: InferenceType[];
    modelLifecycle?: FoundationModelLifecycle;
}
export declare const FoundationModelSummary: S.Schema<FoundationModelSummary>;
export type FoundationModelSummaryList = FoundationModelSummary[];
export declare const FoundationModelSummaryList: any;
export interface ListFoundationModelsResponse {
    modelSummaries?: FoundationModelSummary[];
}
export declare const ListFoundationModelsResponse: S.Schema<ListFoundationModelsResponse>;
export interface ListGuardrailsRequest {
    guardrailIdentifier?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListGuardrailsRequest: S.Schema<ListGuardrailsRequest>;
export interface GuardrailSummary {
    id: string;
    arn: string;
    status: GuardrailStatus;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    version: string;
    createdAt: Date;
    updatedAt: Date;
    crossRegionDetails?: GuardrailCrossRegionDetails;
}
export declare const GuardrailSummary: S.Schema<GuardrailSummary>;
export type GuardrailSummaries = GuardrailSummary[];
export declare const GuardrailSummaries: any;
export interface ListGuardrailsResponse {
    guardrails: GuardrailSummary[];
    nextToken?: string;
}
export declare const ListGuardrailsResponse: S.Schema<ListGuardrailsResponse>;
export interface ListImportedModelsRequest {
    creationTimeBefore?: Date;
    creationTimeAfter?: Date;
    nameContains?: string;
    maxResults?: number;
    nextToken?: string;
    sortBy?: SortModelsBy;
    sortOrder?: SortOrder;
}
export declare const ListImportedModelsRequest: S.Schema<ListImportedModelsRequest>;
export type ModelArchitecture = string;
export interface ImportedModelSummary {
    modelArn: string;
    modelName: string;
    creationTime: Date;
    instructSupported?: boolean;
    modelArchitecture?: string;
}
export declare const ImportedModelSummary: S.Schema<ImportedModelSummary>;
export type ImportedModelSummaryList = ImportedModelSummary[];
export declare const ImportedModelSummaryList: any;
export interface ListImportedModelsResponse {
    nextToken?: string;
    modelSummaries?: ImportedModelSummary[];
}
export declare const ListImportedModelsResponse: S.Schema<ListImportedModelsResponse>;
export interface ListInferenceProfilesRequest {
    maxResults?: number;
    nextToken?: string;
    typeEquals?: InferenceProfileType;
}
export declare const ListInferenceProfilesRequest: S.Schema<ListInferenceProfilesRequest>;
export interface InferenceProfileSummary {
    inferenceProfileName: string;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    updatedAt?: Date;
    inferenceProfileArn: string;
    models: InferenceProfileModel[];
    inferenceProfileId: string;
    status: InferenceProfileStatus;
    type: InferenceProfileType;
}
export declare const InferenceProfileSummary: S.Schema<InferenceProfileSummary>;
export type InferenceProfileSummaries = InferenceProfileSummary[];
export declare const InferenceProfileSummaries: any;
export interface ListInferenceProfilesResponse {
    inferenceProfileSummaries?: InferenceProfileSummary[];
    nextToken?: string;
}
export declare const ListInferenceProfilesResponse: S.Schema<ListInferenceProfilesResponse>;
export interface ListMarketplaceModelEndpointsRequest {
    maxResults?: number;
    nextToken?: string;
    modelSourceEquals?: string;
}
export declare const ListMarketplaceModelEndpointsRequest: S.Schema<ListMarketplaceModelEndpointsRequest>;
export interface MarketplaceModelEndpointSummary {
    endpointArn: string;
    modelSourceIdentifier: string;
    status?: Status;
    statusMessage?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const MarketplaceModelEndpointSummary: S.Schema<MarketplaceModelEndpointSummary>;
export type MarketplaceModelEndpointSummaries = MarketplaceModelEndpointSummary[];
export declare const MarketplaceModelEndpointSummaries: any;
export interface ListMarketplaceModelEndpointsResponse {
    marketplaceModelEndpoints?: MarketplaceModelEndpointSummary[];
    nextToken?: string;
}
export declare const ListMarketplaceModelEndpointsResponse: S.Schema<ListMarketplaceModelEndpointsResponse>;
export interface ListModelCopyJobsRequest {
    creationTimeAfter?: Date;
    creationTimeBefore?: Date;
    statusEquals?: ModelCopyJobStatus;
    sourceAccountEquals?: string;
    sourceModelArnEquals?: string;
    targetModelNameContains?: string;
    maxResults?: number;
    nextToken?: string;
    sortBy?: SortJobsBy;
    sortOrder?: SortOrder;
}
export declare const ListModelCopyJobsRequest: S.Schema<ListModelCopyJobsRequest>;
export interface ModelCopyJobSummary {
    jobArn: string;
    status: ModelCopyJobStatus;
    creationTime: Date;
    targetModelArn: string;
    targetModelName?: string;
    sourceAccountId: string;
    sourceModelArn: string;
    targetModelKmsKeyArn?: string;
    targetModelTags?: Tag[];
    failureMessage?: string;
    sourceModelName?: string;
}
export declare const ModelCopyJobSummary: S.Schema<ModelCopyJobSummary>;
export type ModelCopyJobSummaries = ModelCopyJobSummary[];
export declare const ModelCopyJobSummaries: any;
export interface ListModelCopyJobsResponse {
    nextToken?: string;
    modelCopyJobSummaries?: ModelCopyJobSummary[];
}
export declare const ListModelCopyJobsResponse: S.Schema<ListModelCopyJobsResponse>;
export type FineTuningJobStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | (string & {});
export declare const FineTuningJobStatus: any;
export interface ListModelCustomizationJobsRequest {
    creationTimeAfter?: Date;
    creationTimeBefore?: Date;
    statusEquals?: FineTuningJobStatus;
    nameContains?: string;
    maxResults?: number;
    nextToken?: string;
    sortBy?: SortJobsBy;
    sortOrder?: SortOrder;
}
export declare const ListModelCustomizationJobsRequest: S.Schema<ListModelCustomizationJobsRequest>;
export interface ModelCustomizationJobSummary {
    jobArn: string;
    baseModelArn: string;
    jobName: string;
    status: ModelCustomizationJobStatus;
    statusDetails?: StatusDetails;
    lastModifiedTime?: Date;
    creationTime: Date;
    endTime?: Date;
    customModelArn?: string;
    customModelName?: string;
    customizationType?: CustomizationType;
}
export declare const ModelCustomizationJobSummary: S.Schema<ModelCustomizationJobSummary>;
export type ModelCustomizationJobSummaries = ModelCustomizationJobSummary[];
export declare const ModelCustomizationJobSummaries: any;
export interface ListModelCustomizationJobsResponse {
    nextToken?: string;
    modelCustomizationJobSummaries?: ModelCustomizationJobSummary[];
}
export declare const ListModelCustomizationJobsResponse: S.Schema<ListModelCustomizationJobsResponse>;
export interface ListModelImportJobsRequest {
    creationTimeAfter?: Date;
    creationTimeBefore?: Date;
    statusEquals?: ModelImportJobStatus;
    nameContains?: string;
    maxResults?: number;
    nextToken?: string;
    sortBy?: SortJobsBy;
    sortOrder?: SortOrder;
}
export declare const ListModelImportJobsRequest: S.Schema<ListModelImportJobsRequest>;
export interface ModelImportJobSummary {
    jobArn: string;
    jobName: string;
    status: ModelImportJobStatus;
    lastModifiedTime?: Date;
    creationTime: Date;
    endTime?: Date;
    importedModelArn?: string;
    importedModelName?: string;
}
export declare const ModelImportJobSummary: S.Schema<ModelImportJobSummary>;
export type ModelImportJobSummaries = ModelImportJobSummary[];
export declare const ModelImportJobSummaries: any;
export interface ListModelImportJobsResponse {
    nextToken?: string;
    modelImportJobSummaries?: ModelImportJobSummary[];
}
export declare const ListModelImportJobsResponse: S.Schema<ListModelImportJobsResponse>;
export interface ListModelInvocationJobsRequest {
    submitTimeAfter?: Date;
    submitTimeBefore?: Date;
    statusEquals?: ModelInvocationJobStatus;
    nameContains?: string;
    maxResults?: number;
    nextToken?: string;
    sortBy?: SortJobsBy;
    sortOrder?: SortOrder;
}
export declare const ListModelInvocationJobsRequest: S.Schema<ListModelInvocationJobsRequest>;
export interface ModelInvocationJobSummary {
    jobArn: string;
    jobName: string;
    modelId: string;
    clientRequestToken?: string;
    roleArn: string;
    status?: ModelInvocationJobStatus;
    message?: string | redacted.Redacted<string>;
    submitTime: Date;
    lastModifiedTime?: Date;
    endTime?: Date;
    inputDataConfig: ModelInvocationJobInputDataConfig;
    outputDataConfig: ModelInvocationJobOutputDataConfig;
    vpcConfig?: VpcConfig;
    timeoutDurationInHours?: number;
    jobExpirationTime?: Date;
    modelInvocationType?: ModelInvocationType;
    totalRecordCount?: number;
    processedRecordCount?: number;
    successRecordCount?: number;
    errorRecordCount?: number;
}
export declare const ModelInvocationJobSummary: S.Schema<ModelInvocationJobSummary>;
export type ModelInvocationJobSummaries = ModelInvocationJobSummary[];
export declare const ModelInvocationJobSummaries: any;
export interface ListModelInvocationJobsResponse {
    nextToken?: string;
    invocationJobSummaries?: ModelInvocationJobSummary[];
}
export declare const ListModelInvocationJobsResponse: S.Schema<ListModelInvocationJobsResponse>;
export interface ListPromptRoutersRequest {
    maxResults?: number;
    nextToken?: string;
    type?: PromptRouterType;
}
export declare const ListPromptRoutersRequest: S.Schema<ListPromptRoutersRequest>;
export interface PromptRouterSummary {
    promptRouterName: string;
    routingCriteria: RoutingCriteria;
    description?: string | redacted.Redacted<string>;
    createdAt?: Date;
    updatedAt?: Date;
    promptRouterArn: string;
    models: PromptRouterTargetModel[];
    fallbackModel: PromptRouterTargetModel;
    status: PromptRouterStatus;
    type: PromptRouterType;
}
export declare const PromptRouterSummary: S.Schema<PromptRouterSummary>;
export type PromptRouterSummaries = PromptRouterSummary[];
export declare const PromptRouterSummaries: any;
export interface ListPromptRoutersResponse {
    promptRouterSummaries?: (PromptRouterSummary & {
        models: (PromptRouterTargetModel & {
            modelArn: PromptRouterTargetModelArn;
        })[];
        fallbackModel: PromptRouterTargetModel & {
            modelArn: PromptRouterTargetModelArn;
        };
    })[];
    nextToken?: string;
}
export declare const ListPromptRoutersResponse: S.Schema<ListPromptRoutersResponse>;
export type SortByProvisionedModels = "CreationTime" | (string & {});
export declare const SortByProvisionedModels: any;
export interface ListProvisionedModelThroughputsRequest {
    creationTimeAfter?: Date;
    creationTimeBefore?: Date;
    statusEquals?: ProvisionedModelStatus;
    modelArnEquals?: string;
    nameContains?: string;
    maxResults?: number;
    nextToken?: string;
    sortBy?: SortByProvisionedModels;
    sortOrder?: SortOrder;
}
export declare const ListProvisionedModelThroughputsRequest: S.Schema<ListProvisionedModelThroughputsRequest>;
export interface ProvisionedModelSummary {
    provisionedModelName: string;
    provisionedModelArn: string;
    modelArn: string;
    desiredModelArn: string;
    foundationModelArn: string;
    modelUnits: number;
    desiredModelUnits: number;
    status: ProvisionedModelStatus;
    commitmentDuration?: CommitmentDuration;
    commitmentExpirationTime?: Date;
    creationTime: Date;
    lastModifiedTime: Date;
}
export declare const ProvisionedModelSummary: S.Schema<ProvisionedModelSummary>;
export type ProvisionedModelSummaries = ProvisionedModelSummary[];
export declare const ProvisionedModelSummaries: any;
export interface ListProvisionedModelThroughputsResponse {
    nextToken?: string;
    provisionedModelSummaries?: ProvisionedModelSummary[];
}
export declare const ListProvisionedModelThroughputsResponse: S.Schema<ListProvisionedModelThroughputsResponse>;
export type TaggableResourcesArn = string;
export interface ListTagsForResourceRequest {
    resourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PutAccountDataRetentionRequest {
    mode: DataRetentionMode;
}
export declare const PutAccountDataRetentionRequest: S.Schema<PutAccountDataRetentionRequest>;
export interface PutAccountDataRetentionResponse {
    mode: DataRetentionMode;
    updatedAt?: Date;
}
export declare const PutAccountDataRetentionResponse: S.Schema<PutAccountDataRetentionResponse>;
export interface AccountEnforcedGuardrailInferenceInputConfiguration {
    guardrailIdentifier: string;
    guardrailVersion: string;
    selectiveContentGuarding?: SelectiveContentGuarding;
    modelEnforcement?: ModelEnforcement;
}
export declare const AccountEnforcedGuardrailInferenceInputConfiguration: S.Schema<AccountEnforcedGuardrailInferenceInputConfiguration>;
export interface PutEnforcedGuardrailConfigurationRequest {
    configId?: string;
    guardrailInferenceConfig: AccountEnforcedGuardrailInferenceInputConfiguration;
}
export declare const PutEnforcedGuardrailConfigurationRequest: S.Schema<PutEnforcedGuardrailConfigurationRequest>;
export interface PutEnforcedGuardrailConfigurationResponse {
    configId?: string;
    updatedAt?: Date;
    updatedBy?: string;
}
export declare const PutEnforcedGuardrailConfigurationResponse: S.Schema<PutEnforcedGuardrailConfigurationResponse>;
export interface PutModelInvocationLoggingConfigurationRequest {
    loggingConfig: LoggingConfig;
}
export declare const PutModelInvocationLoggingConfigurationRequest: S.Schema<PutModelInvocationLoggingConfigurationRequest>;
export interface PutModelInvocationLoggingConfigurationResponse {
}
export declare const PutModelInvocationLoggingConfigurationResponse: S.Schema<PutModelInvocationLoggingConfigurationResponse>;
export interface PutResourcePolicyRequest {
    resourceArn: string;
    resourcePolicy: string;
}
export declare const PutResourcePolicyRequest: S.Schema<PutResourcePolicyRequest>;
export interface PutResourcePolicyResponse {
    resourceArn?: string;
}
export declare const PutResourcePolicyResponse: S.Schema<PutResourcePolicyResponse>;
export interface PutUseCaseForModelAccessRequest {
    formData: Uint8Array;
}
export declare const PutUseCaseForModelAccessRequest: S.Schema<PutUseCaseForModelAccessRequest>;
export interface PutUseCaseForModelAccessResponse {
}
export declare const PutUseCaseForModelAccessResponse: S.Schema<PutUseCaseForModelAccessResponse>;
export interface RegisterMarketplaceModelEndpointRequest {
    endpointIdentifier: string;
    modelSourceIdentifier: string;
}
export declare const RegisterMarketplaceModelEndpointRequest: S.Schema<RegisterMarketplaceModelEndpointRequest>;
export interface RegisterMarketplaceModelEndpointResponse {
    marketplaceModelEndpoint: MarketplaceModelEndpoint;
}
export declare const RegisterMarketplaceModelEndpointResponse: S.Schema<RegisterMarketplaceModelEndpointResponse>;
export interface AutomatedReasoningPolicyBuildWorkflowDocument {
    document: Uint8Array | redacted.Redacted<Uint8Array>;
    documentContentType: AutomatedReasoningPolicyBuildDocumentContentType;
    documentName: string | redacted.Redacted<string>;
    documentDescription?: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyBuildWorkflowDocument: S.Schema<AutomatedReasoningPolicyBuildWorkflowDocument>;
export type AutomatedReasoningPolicyBuildWorkflowDocumentList = AutomatedReasoningPolicyBuildWorkflowDocument[];
export declare const AutomatedReasoningPolicyBuildWorkflowDocumentList: any;
export interface AutomatedReasoningPolicyBuildWorkflowRepairContent {
    annotations: AutomatedReasoningPolicyAnnotation[];
}
export declare const AutomatedReasoningPolicyBuildWorkflowRepairContent: S.Schema<AutomatedReasoningPolicyBuildWorkflowRepairContent>;
export type AutomatedReasoningPolicyGenerateFidelityReportDocumentList = AutomatedReasoningPolicyBuildWorkflowDocument[];
export declare const AutomatedReasoningPolicyGenerateFidelityReportDocumentList: any;
export type AutomatedReasoningPolicyGenerateFidelityReportContent = {
    documents: AutomatedReasoningPolicyBuildWorkflowDocument[];
};
export declare const AutomatedReasoningPolicyGenerateFidelityReportContent: any;
export type AutomatedReasoningPolicyIterativeRefinementDocumentList = AutomatedReasoningPolicyBuildWorkflowDocument[];
export declare const AutomatedReasoningPolicyIterativeRefinementDocumentList: any;
export type AutomatedReasoningPolicyBuildFeedback = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyIterativeRefinementContent {
    documents: AutomatedReasoningPolicyBuildWorkflowDocument[];
    feedback?: string | redacted.Redacted<string>;
}
export declare const AutomatedReasoningPolicyIterativeRefinementContent: S.Schema<AutomatedReasoningPolicyIterativeRefinementContent>;
export type AutomatedReasoningPolicyWorkflowTypeContent = {
    documents: AutomatedReasoningPolicyBuildWorkflowDocument[];
    policyRepairAssets?: never;
    generateFidelityReportContent?: never;
    iterativeRefinementContent?: never;
} | {
    documents?: never;
    policyRepairAssets: AutomatedReasoningPolicyBuildWorkflowRepairContent;
    generateFidelityReportContent?: never;
    iterativeRefinementContent?: never;
} | {
    documents?: never;
    policyRepairAssets?: never;
    generateFidelityReportContent: AutomatedReasoningPolicyGenerateFidelityReportContent;
    iterativeRefinementContent?: never;
} | {
    documents?: never;
    policyRepairAssets?: never;
    generateFidelityReportContent?: never;
    iterativeRefinementContent: AutomatedReasoningPolicyIterativeRefinementContent;
};
export declare const AutomatedReasoningPolicyWorkflowTypeContent: any;
export interface AutomatedReasoningPolicyBuildWorkflowSource {
    policyDefinition?: AutomatedReasoningPolicyDefinition;
    workflowContent?: AutomatedReasoningPolicyWorkflowTypeContent;
}
export declare const AutomatedReasoningPolicyBuildWorkflowSource: S.Schema<AutomatedReasoningPolicyBuildWorkflowSource>;
export interface StartAutomatedReasoningPolicyBuildWorkflowRequest {
    policyArn: string;
    buildWorkflowType: AutomatedReasoningPolicyBuildWorkflowType;
    clientRequestToken?: string;
    sourceContent: AutomatedReasoningPolicyBuildWorkflowSource;
}
export declare const StartAutomatedReasoningPolicyBuildWorkflowRequest: S.Schema<StartAutomatedReasoningPolicyBuildWorkflowRequest>;
export interface StartAutomatedReasoningPolicyBuildWorkflowResponse {
    policyArn: string;
    buildWorkflowId: string;
}
export declare const StartAutomatedReasoningPolicyBuildWorkflowResponse: S.Schema<StartAutomatedReasoningPolicyBuildWorkflowResponse>;
export type AutomatedReasoningPolicyTestCaseIdList = string[];
export declare const AutomatedReasoningPolicyTestCaseIdList: any;
export interface StartAutomatedReasoningPolicyTestWorkflowRequest {
    policyArn: string;
    buildWorkflowId: string;
    testCaseIds?: string[];
    clientRequestToken?: string;
}
export declare const StartAutomatedReasoningPolicyTestWorkflowRequest: S.Schema<StartAutomatedReasoningPolicyTestWorkflowRequest>;
export interface StartAutomatedReasoningPolicyTestWorkflowResponse {
    policyArn: string;
}
export declare const StartAutomatedReasoningPolicyTestWorkflowResponse: S.Schema<StartAutomatedReasoningPolicyTestWorkflowResponse>;
export interface StopAdvancedPromptOptimizationJobRequest {
    jobIdentifier: string;
}
export declare const StopAdvancedPromptOptimizationJobRequest: S.Schema<StopAdvancedPromptOptimizationJobRequest>;
export interface StopAdvancedPromptOptimizationJobResponse {
}
export declare const StopAdvancedPromptOptimizationJobResponse: S.Schema<StopAdvancedPromptOptimizationJobResponse>;
export interface StopEvaluationJobRequest {
    jobIdentifier: string | redacted.Redacted<string>;
}
export declare const StopEvaluationJobRequest: S.Schema<StopEvaluationJobRequest>;
export interface StopEvaluationJobResponse {
}
export declare const StopEvaluationJobResponse: S.Schema<StopEvaluationJobResponse>;
export interface StopModelCustomizationJobRequest {
    jobIdentifier: string;
}
export declare const StopModelCustomizationJobRequest: S.Schema<StopModelCustomizationJobRequest>;
export interface StopModelCustomizationJobResponse {
}
export declare const StopModelCustomizationJobResponse: S.Schema<StopModelCustomizationJobResponse>;
export interface StopModelInvocationJobRequest {
    jobIdentifier: string;
}
export declare const StopModelInvocationJobRequest: S.Schema<StopModelInvocationJobRequest>;
export interface StopModelInvocationJobResponse {
}
export declare const StopModelInvocationJobResponse: S.Schema<StopModelInvocationJobResponse>;
export interface TagResourceRequest {
    resourceARN: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAutomatedReasoningPolicyRequest {
    policyArn: string;
    policyDefinition: AutomatedReasoningPolicyDefinition;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
}
export declare const UpdateAutomatedReasoningPolicyRequest: S.Schema<UpdateAutomatedReasoningPolicyRequest>;
export interface UpdateAutomatedReasoningPolicyResponse {
    policyArn: string;
    name: string | redacted.Redacted<string>;
    definitionHash: string;
    updatedAt: Date;
}
export declare const UpdateAutomatedReasoningPolicyResponse: S.Schema<UpdateAutomatedReasoningPolicyResponse>;
export interface UpdateAutomatedReasoningPolicyAnnotationsRequest {
    policyArn: string;
    buildWorkflowId: string;
    annotations: AutomatedReasoningPolicyAnnotation[];
    lastUpdatedAnnotationSetHash: string;
}
export declare const UpdateAutomatedReasoningPolicyAnnotationsRequest: S.Schema<UpdateAutomatedReasoningPolicyAnnotationsRequest>;
export interface UpdateAutomatedReasoningPolicyAnnotationsResponse {
    policyArn: string;
    buildWorkflowId: string;
    annotationSetHash: string;
    updatedAt: Date;
}
export declare const UpdateAutomatedReasoningPolicyAnnotationsResponse: S.Schema<UpdateAutomatedReasoningPolicyAnnotationsResponse>;
export interface UpdateAutomatedReasoningPolicyTestCaseRequest {
    policyArn: string;
    testCaseId: string;
    guardContent: string | redacted.Redacted<string>;
    queryContent?: string | redacted.Redacted<string>;
    lastUpdatedAt: Date;
    expectedAggregatedFindingsResult: AutomatedReasoningCheckResult;
    confidenceThreshold?: number;
    clientRequestToken?: string;
}
export declare const UpdateAutomatedReasoningPolicyTestCaseRequest: S.Schema<UpdateAutomatedReasoningPolicyTestCaseRequest>;
export interface UpdateAutomatedReasoningPolicyTestCaseResponse {
    policyArn: string;
    testCaseId: string;
}
export declare const UpdateAutomatedReasoningPolicyTestCaseResponse: S.Schema<UpdateAutomatedReasoningPolicyTestCaseResponse>;
export interface UpdateCustomModelDeploymentRequest {
    modelArn: string;
    customModelDeploymentIdentifier: string;
}
export declare const UpdateCustomModelDeploymentRequest: S.Schema<UpdateCustomModelDeploymentRequest>;
export interface UpdateCustomModelDeploymentResponse {
    customModelDeploymentArn: string;
}
export declare const UpdateCustomModelDeploymentResponse: S.Schema<UpdateCustomModelDeploymentResponse>;
export interface UpdateGuardrailRequest {
    guardrailIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    topicPolicyConfig?: GuardrailTopicPolicyConfig;
    contentPolicyConfig?: GuardrailContentPolicyConfig;
    wordPolicyConfig?: GuardrailWordPolicyConfig;
    sensitiveInformationPolicyConfig?: GuardrailSensitiveInformationPolicyConfig;
    contextualGroundingPolicyConfig?: GuardrailContextualGroundingPolicyConfig;
    automatedReasoningPolicyConfig?: GuardrailAutomatedReasoningPolicyConfig;
    crossRegionConfig?: GuardrailCrossRegionConfig;
    blockedInputMessaging: string | redacted.Redacted<string>;
    blockedOutputsMessaging: string | redacted.Redacted<string>;
    kmsKeyId?: string;
}
export declare const UpdateGuardrailRequest: S.Schema<UpdateGuardrailRequest>;
export interface UpdateGuardrailResponse {
    guardrailId: string;
    guardrailArn: string;
    version: string;
    updatedAt: Date;
}
export declare const UpdateGuardrailResponse: S.Schema<UpdateGuardrailResponse>;
export interface UpdateMarketplaceModelEndpointRequest {
    endpointArn: string;
    endpointConfig: EndpointConfig;
    clientRequestToken?: string;
}
export declare const UpdateMarketplaceModelEndpointRequest: S.Schema<UpdateMarketplaceModelEndpointRequest>;
export interface UpdateMarketplaceModelEndpointResponse {
    marketplaceModelEndpoint: MarketplaceModelEndpoint;
}
export declare const UpdateMarketplaceModelEndpointResponse: S.Schema<UpdateMarketplaceModelEndpointResponse>;
export interface UpdateProvisionedModelThroughputRequest {
    provisionedModelId: string;
    desiredProvisionedModelName?: string;
    desiredModelId?: string;
}
export declare const UpdateProvisionedModelThroughputRequest: S.Schema<UpdateProvisionedModelThroughputRequest>;
export interface UpdateProvisionedModelThroughputResponse {
}
export declare const UpdateProvisionedModelThroughputResponse: S.Schema<UpdateProvisionedModelThroughputResponse>;
export type NonBlankString = string;
export type BatchDeleteAdvancedPromptOptimizationJobError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes one or more advanced prompt optimization jobs.
 */
export declare const batchDeleteAdvancedPromptOptimizationJob: API.OperationMethod<BatchDeleteAdvancedPromptOptimizationJobRequest, BatchDeleteAdvancedPromptOptimizationJobResponse, BatchDeleteAdvancedPromptOptimizationJobError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteEvaluationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a batch of evaluation jobs. An evaluation job can only be deleted if it has following status `FAILED`, `COMPLETED`, and `STOPPED`. You can request up to 25 model evaluation jobs be deleted in a single request.
 */
export declare const batchDeleteEvaluationJob: API.OperationMethod<BatchDeleteEvaluationJobRequest, BatchDeleteEvaluationJobResponse, BatchDeleteEvaluationJobError, Credentials | HttpClient.HttpClient>;
export type CancelAutomatedReasoningPolicyBuildWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a running Automated Reasoning policy build workflow. This stops the policy generation process and prevents further processing of the source documents.
 */
export declare const cancelAutomatedReasoningPolicyBuildWorkflow: API.OperationMethod<CancelAutomatedReasoningPolicyBuildWorkflowRequest, CancelAutomatedReasoningPolicyBuildWorkflowResponse, CancelAutomatedReasoningPolicyBuildWorkflowError, Credentials | HttpClient.HttpClient>;
export type CreateAdvancedPromptOptimizationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates an advanced prompt optimization job. The job optimizes your prompt templates for specific models using your evaluation dataset and criteria.
 */
export declare const createAdvancedPromptOptimizationJob: API.OperationMethod<CreateAdvancedPromptOptimizationJobRequest, CreateAdvancedPromptOptimizationJobResponse, CreateAdvancedPromptOptimizationJobError, Credentials | HttpClient.HttpClient>;
export type CreateAutomatedReasoningPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates an Automated Reasoning policy for Amazon Bedrock Guardrails. Automated Reasoning policies use mathematical techniques to detect hallucinations, suggest corrections, and highlight unstated assumptions in the responses of your GenAI application.
 *
 * To create a policy, you upload a source document that describes the rules that you're encoding. Automated Reasoning extracts important concepts from the source document that will become variables in the policy and infers policy rules.
 */
export declare const createAutomatedReasoningPolicy: API.OperationMethod<CreateAutomatedReasoningPolicyRequest, CreateAutomatedReasoningPolicyResponse, CreateAutomatedReasoningPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateAutomatedReasoningPolicyTestCaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a test for an Automated Reasoning policy. Tests validate that your policy works as expected by providing sample inputs and expected outcomes. Use tests to verify policy behavior before deploying to production.
 */
export declare const createAutomatedReasoningPolicyTestCase: API.OperationMethod<CreateAutomatedReasoningPolicyTestCaseRequest, CreateAutomatedReasoningPolicyTestCaseResponse, CreateAutomatedReasoningPolicyTestCaseError, Credentials | HttpClient.HttpClient>;
export type CreateAutomatedReasoningPolicyVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a new version of an existing Automated Reasoning policy. This allows you to iterate on your policy rules while maintaining previous versions for rollback or comparison purposes.
 */
export declare const createAutomatedReasoningPolicyVersion: API.OperationMethod<CreateAutomatedReasoningPolicyVersionRequest, CreateAutomatedReasoningPolicyVersionResponse, CreateAutomatedReasoningPolicyVersionError, Credentials | HttpClient.HttpClient>;
export type CreateCustomModelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a new custom model in Amazon Bedrock. After the model is active, you can use it for inference.
 *
 * You can provide the model data source in one of the following ways:
 *
 * - `customModelDataSource` — Specify a SageMaker AI model package ARN. Amazon Bedrock resolves the model package to retrieve the model artifacts. This is the preferred method for new SageMaker AI training outputs.
 *
 * - `modelSourceConfig` — Specify an Amazon S3 URI pointing to the Amazon-managed Amazon S3 bucket containing your model artifacts.
 *
 * To use the model for inference, you must purchase Provisioned Throughput for it. You can't use On-demand inference with these custom models. For more information about Provisioned Throughput, see Provisioned Throughput.
 *
 * The model appears in `ListCustomModels` with a `customizationType` of `imported`. To track the status of the new model, you use the `GetCustomModel` API operation. The model can be in the following states:
 *
 * - `Creating` - Initial state during validation and registration
 *
 * - `Active` - Model is ready for use in inference
 *
 * - `Failed` - Creation process encountered an error
 *
 * **Related APIs**
 *
 * - GetCustomModel
 *
 * - ListCustomModels
 *
 * - DeleteCustomModel
 */
export declare const createCustomModel: API.OperationMethod<CreateCustomModelRequest, CreateCustomModelResponse, CreateCustomModelError, Credentials | HttpClient.HttpClient>;
export type CreateCustomModelDeploymentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Deploys a custom model for on-demand inference in Amazon Bedrock. After you deploy your custom model, you use the deployment's Amazon Resource Name (ARN) as the `modelId` parameter when you submit prompts and generate responses with model inference.
 *
 * For more information about setting up on-demand inference for custom models, see Set up inference for a custom model.
 *
 * The following actions are related to the `CreateCustomModelDeployment` operation:
 *
 * - GetCustomModelDeployment
 *
 * - ListCustomModelDeployments
 *
 * - DeleteCustomModelDeployment
 */
export declare const createCustomModelDeployment: API.OperationMethod<CreateCustomModelDeploymentRequest, CreateCustomModelDeploymentResponse, CreateCustomModelDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateEvaluationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an evaluation job.
 */
export declare const createEvaluationJob: API.OperationMethod<CreateEvaluationJobRequest, CreateEvaluationJobResponse, CreateEvaluationJobError, Credentials | HttpClient.HttpClient>;
export type CreateFoundationModelAgreementError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Request a model access agreement for the specified model.
 */
export declare const createFoundationModelAgreement: API.OperationMethod<CreateFoundationModelAgreementRequest, CreateFoundationModelAgreementResponse, CreateFoundationModelAgreementError, Credentials | HttpClient.HttpClient>;
export type CreateGuardrailError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a guardrail to block topics and to implement safeguards for your generative AI applications.
 *
 * You can configure the following policies in a guardrail to avoid undesirable and harmful content, filter out denied topics and words, and remove sensitive information for privacy protection.
 *
 * - **Content filters** - Adjust filter strengths to block input prompts or model responses containing harmful content.
 *
 * - **Denied topics** - Define a set of topics that are undesirable in the context of your application. These topics will be blocked if detected in user queries or model responses.
 *
 * - **Word filters** - Configure filters to block undesirable words, phrases, and profanity. Such words can include offensive terms, competitor names etc.
 *
 * - **Sensitive information filters** - Block or mask sensitive information such as personally identifiable information (PII) or custom regex in user inputs and model responses.
 *
 * In addition to the above policies, you can also configure the messages to be returned to the user if a user input or model response is in violation of the policies defined in the guardrail.
 *
 * For more information, see Amazon Bedrock Guardrails in the *Amazon Bedrock User Guide*.
 */
export declare const createGuardrail: API.OperationMethod<CreateGuardrailRequest, CreateGuardrailResponse, CreateGuardrailError, Credentials | HttpClient.HttpClient>;
export type CreateGuardrailVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a version of the guardrail. Use this API to create a snapshot of the guardrail when you are satisfied with a configuration, or to compare the configuration with another version.
 */
export declare const createGuardrailVersion: API.OperationMethod<CreateGuardrailVersionRequest, CreateGuardrailVersionResponse, CreateGuardrailVersionError, Credentials | HttpClient.HttpClient>;
export type CreateInferenceProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates an application inference profile to track metrics and costs when invoking a model. To create an application inference profile for a foundation model in one region, specify the ARN of the model in that region. To create an application inference profile for a foundation model across multiple regions, specify the ARN of the system-defined inference profile that contains the regions that you want to route requests to. For more information, see Increase throughput and resilience with cross-region inference in Amazon Bedrock. in the Amazon Bedrock User Guide.
 */
export declare const createInferenceProfile: API.OperationMethod<CreateInferenceProfileRequest, CreateInferenceProfileResponse, CreateInferenceProfileError, Credentials | HttpClient.HttpClient>;
export type CreateMarketplaceModelEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an endpoint for a model from Amazon Bedrock Marketplace. The endpoint is hosted by Amazon SageMaker.
 */
export declare const createMarketplaceModelEndpoint: API.OperationMethod<CreateMarketplaceModelEndpointRequest, CreateMarketplaceModelEndpointResponse, CreateMarketplaceModelEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateModelCopyJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Copies a model to another region so that it can be used there. For more information, see Copy models to be used in other regions in the Amazon Bedrock User Guide.
 */
export declare const createModelCopyJob: API.OperationMethod<CreateModelCopyJobRequest, CreateModelCopyJobResponse, CreateModelCopyJobError, Credentials | HttpClient.HttpClient>;
export type CreateModelCustomizationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a fine-tuning job to customize a base model.
 *
 * You specify the base foundation model and the location of the training data. After the model-customization job completes successfully, your custom model resource will be ready to use. Amazon Bedrock returns validation loss metrics and output generations after the job completes.
 *
 * For information on the format of training and validation data, see Prepare the datasets.
 *
 * Model-customization jobs are asynchronous and the completion time depends on the base model and the training/validation data size. To monitor a job, use the `GetModelCustomizationJob` operation to retrieve the job status.
 *
 * For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const createModelCustomizationJob: API.OperationMethod<CreateModelCustomizationJobRequest, CreateModelCustomizationJobResponse, CreateModelCustomizationJobError, Credentials | HttpClient.HttpClient>;
export type CreateModelImportJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a model import job to import model that you have customized in other environments, such as Amazon SageMaker. For more information, see Import a customized model
 */
export declare const createModelImportJob: API.OperationMethod<CreateModelImportJobRequest, CreateModelImportJobResponse, CreateModelImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateModelInvocationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a batch inference job to invoke a model on multiple prompts. Format your data according to Format your inference data and upload it to an Amazon S3 bucket. For more information, see Process multiple prompts with batch inference.
 *
 * The response returns a `jobArn` that you can use to stop or get details about the job.
 */
export declare const createModelInvocationJob: API.OperationMethod<CreateModelInvocationJobRequest, CreateModelInvocationJobResponse, CreateModelInvocationJobError, Credentials | HttpClient.HttpClient>;
export type CreatePromptRouterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a prompt router that manages the routing of requests between multiple foundation models based on the routing criteria.
 */
export declare const createPromptRouter: API.OperationMethod<CreatePromptRouterRequest, CreatePromptRouterResponse, CreatePromptRouterError, Credentials | HttpClient.HttpClient>;
export type CreateProvisionedModelThroughputError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates dedicated throughput for a base or custom model with the model units and for the duration that you specify. For pricing details, see Amazon Bedrock Pricing. For more information, see Provisioned Throughput in the Amazon Bedrock User Guide.
 */
export declare const createProvisionedModelThroughput: API.OperationMethod<CreateProvisionedModelThroughputRequest, CreateProvisionedModelThroughputResponse, CreateProvisionedModelThroughputError, Credentials | HttpClient.HttpClient>;
export type DeleteAutomatedReasoningPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Automated Reasoning policy or policy version. This operation is idempotent. If you delete a policy more than once, each call succeeds. Deleting a policy removes it permanently and cannot be undone.
 */
export declare const deleteAutomatedReasoningPolicy: API.OperationMethod<DeleteAutomatedReasoningPolicyRequest, DeleteAutomatedReasoningPolicyResponse, DeleteAutomatedReasoningPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteAutomatedReasoningPolicyBuildWorkflowError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Automated Reasoning policy build workflow and its associated artifacts. This permanently removes the workflow history and any generated assets.
 */
export declare const deleteAutomatedReasoningPolicyBuildWorkflow: API.OperationMethod<DeleteAutomatedReasoningPolicyBuildWorkflowRequest, DeleteAutomatedReasoningPolicyBuildWorkflowResponse, DeleteAutomatedReasoningPolicyBuildWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeleteAutomatedReasoningPolicyTestCaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Automated Reasoning policy test. This operation is idempotent; if you delete a test more than once, each call succeeds.
 */
export declare const deleteAutomatedReasoningPolicyTestCase: API.OperationMethod<DeleteAutomatedReasoningPolicyTestCaseRequest, DeleteAutomatedReasoningPolicyTestCaseResponse, DeleteAutomatedReasoningPolicyTestCaseError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomModelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a custom model that you created earlier. For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const deleteCustomModel: API.OperationMethod<DeleteCustomModelRequest, DeleteCustomModelResponse, DeleteCustomModelError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomModelDeploymentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a custom model deployment. This operation stops the deployment and removes it from your account. After deletion, the deployment ARN can no longer be used for inference requests.
 *
 * The following actions are related to the `DeleteCustomModelDeployment` operation:
 *
 * - CreateCustomModelDeployment
 *
 * - GetCustomModelDeployment
 *
 * - ListCustomModelDeployments
 */
export declare const deleteCustomModelDeployment: API.OperationMethod<DeleteCustomModelDeploymentRequest, DeleteCustomModelDeploymentResponse, DeleteCustomModelDeploymentError, Credentials | HttpClient.HttpClient>;
export type DeleteEnforcedGuardrailConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the account-level enforced guardrail configuration.
 */
export declare const deleteEnforcedGuardrailConfiguration: API.OperationMethod<DeleteEnforcedGuardrailConfigurationRequest, DeleteEnforcedGuardrailConfigurationResponse, DeleteEnforcedGuardrailConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteFoundationModelAgreementError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete the model access agreement for the specified model.
 */
export declare const deleteFoundationModelAgreement: API.OperationMethod<DeleteFoundationModelAgreementRequest, DeleteFoundationModelAgreementResponse, DeleteFoundationModelAgreementError, Credentials | HttpClient.HttpClient>;
export type DeleteGuardrailError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a guardrail.
 *
 * - To delete a guardrail, only specify the ARN of the guardrail in the `guardrailIdentifier` field. If you delete a guardrail, all of its versions will be deleted.
 *
 * - To delete a version of a guardrail, specify the ARN of the guardrail in the `guardrailIdentifier` field and the version in the `guardrailVersion` field.
 */
export declare const deleteGuardrail: API.OperationMethod<DeleteGuardrailRequest, DeleteGuardrailResponse, DeleteGuardrailError, Credentials | HttpClient.HttpClient>;
export type DeleteImportedModelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a custom model that you imported earlier. For more information, see Import a customized model in the Amazon Bedrock User Guide.
 */
export declare const deleteImportedModel: API.OperationMethod<DeleteImportedModelRequest, DeleteImportedModelResponse, DeleteImportedModelError, Credentials | HttpClient.HttpClient>;
export type DeleteInferenceProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an application inference profile. For more information, see Increase throughput and resilience with cross-region inference in Amazon Bedrock. in the Amazon Bedrock User Guide.
 */
export declare const deleteInferenceProfile: API.OperationMethod<DeleteInferenceProfileRequest, DeleteInferenceProfileResponse, DeleteInferenceProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteMarketplaceModelEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an endpoint for a model from Amazon Bedrock Marketplace.
 */
export declare const deleteMarketplaceModelEndpoint: API.OperationMethod<DeleteMarketplaceModelEndpointRequest, DeleteMarketplaceModelEndpointResponse, DeleteMarketplaceModelEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteModelInvocationLoggingConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Delete the invocation logging.
 */
export declare const deleteModelInvocationLoggingConfiguration: API.OperationMethod<DeleteModelInvocationLoggingConfigurationRequest, DeleteModelInvocationLoggingConfigurationResponse, DeleteModelInvocationLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePromptRouterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specified prompt router. This action cannot be undone.
 */
export declare const deletePromptRouter: API.OperationMethod<DeletePromptRouterRequest, DeletePromptRouterResponse, DeletePromptRouterError, Credentials | HttpClient.HttpClient>;
export type DeleteProvisionedModelThroughputError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Provisioned Throughput. You can't delete a Provisioned Throughput before the commitment term is over. For more information, see Provisioned Throughput in the Amazon Bedrock User Guide.
 */
export declare const deleteProvisionedModelThroughput: API.OperationMethod<DeleteProvisionedModelThroughputRequest, DeleteProvisionedModelThroughputResponse, DeleteProvisionedModelThroughputError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a previously created Bedrock resource policy.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeregisterMarketplaceModelEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deregisters an endpoint for a model from Amazon Bedrock Marketplace. This operation removes the endpoint's association with Amazon Bedrock but does not delete the underlying Amazon SageMaker endpoint.
 */
export declare const deregisterMarketplaceModelEndpoint: API.OperationMethod<DeregisterMarketplaceModelEndpointRequest, DeregisterMarketplaceModelEndpointResponse, DeregisterMarketplaceModelEndpointError, Credentials | HttpClient.HttpClient>;
export type ExportAutomatedReasoningPolicyVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Exports the policy definition for an Automated Reasoning policy version. Returns the complete policy definition including rules, variables, and custom variable types in a structured format.
 */
export declare const exportAutomatedReasoningPolicyVersion: API.OperationMethod<ExportAutomatedReasoningPolicyVersionRequest, ExportAutomatedReasoningPolicyVersionResponse, ExportAutomatedReasoningPolicyVersionError, Credentials | HttpClient.HttpClient>;
export type GetAccountDataRetentionError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the account-wide data retention mode for Amazon Bedrock.
 */
export declare const getAccountDataRetention: API.OperationMethod<GetAccountDataRetentionRequest, GetAccountDataRetentionResponse, GetAccountDataRetentionError, Credentials | HttpClient.HttpClient>;
export type GetAdvancedPromptOptimizationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an advanced prompt optimization job.
 */
export declare const getAdvancedPromptOptimizationJob: API.OperationMethod<GetAdvancedPromptOptimizationJobRequest, GetAdvancedPromptOptimizationJobResponse, GetAdvancedPromptOptimizationJobError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about an Automated Reasoning policy or policy version. Returns information including the policy definition, metadata, and timestamps.
 */
export declare const getAutomatedReasoningPolicy: API.OperationMethod<GetAutomatedReasoningPolicyRequest, GetAutomatedReasoningPolicyResponse, GetAutomatedReasoningPolicyError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyAnnotationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the current annotations for an Automated Reasoning policy build workflow. Annotations contain corrections to the rules, variables and types to be applied to the policy.
 */
export declare const getAutomatedReasoningPolicyAnnotations: API.OperationMethod<GetAutomatedReasoningPolicyAnnotationsRequest, GetAutomatedReasoningPolicyAnnotationsResponse, GetAutomatedReasoningPolicyAnnotationsError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyBuildWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about an Automated Reasoning policy build workflow, including its status, configuration, and metadata.
 */
export declare const getAutomatedReasoningPolicyBuildWorkflow: API.OperationMethod<GetAutomatedReasoningPolicyBuildWorkflowRequest, GetAutomatedReasoningPolicyBuildWorkflowResponse, GetAutomatedReasoningPolicyBuildWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyBuildWorkflowResultAssetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the resulting assets from a completed Automated Reasoning policy build workflow, including build logs, quality reports, and generated policy artifacts.
 */
export declare const getAutomatedReasoningPolicyBuildWorkflowResultAssets: API.OperationMethod<GetAutomatedReasoningPolicyBuildWorkflowResultAssetsRequest, GetAutomatedReasoningPolicyBuildWorkflowResultAssetsResponse, GetAutomatedReasoningPolicyBuildWorkflowResultAssetsError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyNextScenarioError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the next test scenario for validating an Automated Reasoning policy. This is used during the interactive policy refinement process to test policy behavior.
 */
export declare const getAutomatedReasoningPolicyNextScenario: API.OperationMethod<GetAutomatedReasoningPolicyNextScenarioRequest, GetAutomatedReasoningPolicyNextScenarioResponse, GetAutomatedReasoningPolicyNextScenarioError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyTestCaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a specific Automated Reasoning policy test.
 */
export declare const getAutomatedReasoningPolicyTestCase: API.OperationMethod<GetAutomatedReasoningPolicyTestCaseRequest, GetAutomatedReasoningPolicyTestCaseResponse, GetAutomatedReasoningPolicyTestCaseError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyTestResultError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the test result for a specific Automated Reasoning policy test. Returns detailed validation findings and execution status.
 */
export declare const getAutomatedReasoningPolicyTestResult: API.OperationMethod<GetAutomatedReasoningPolicyTestResultRequest, GetAutomatedReasoningPolicyTestResultResponse, GetAutomatedReasoningPolicyTestResultError, Credentials | HttpClient.HttpClient>;
export type GetCustomModelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the properties associated with a Amazon Bedrock custom model that you have created. For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const getCustomModel: API.OperationMethod<GetCustomModelRequest, GetCustomModelResponse, GetCustomModelError, Credentials | HttpClient.HttpClient>;
export type GetCustomModelDeploymentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a custom model deployment, including its status, configuration, and metadata. Use this operation to monitor the deployment status and retrieve details needed for inference requests.
 *
 * The following actions are related to the `GetCustomModelDeployment` operation:
 *
 * - CreateCustomModelDeployment
 *
 * - ListCustomModelDeployments
 *
 * - DeleteCustomModelDeployment
 */
export declare const getCustomModelDeployment: API.OperationMethod<GetCustomModelDeploymentRequest, GetCustomModelDeploymentResponse, GetCustomModelDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetEvaluationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an evaluation job, such as the status of the job.
 */
export declare const getEvaluationJob: API.OperationMethod<GetEvaluationJobRequest, GetEvaluationJobResponse, GetEvaluationJobError, Credentials | HttpClient.HttpClient>;
export type GetFoundationModelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get details about a Amazon Bedrock foundation model.
 */
export declare const getFoundationModel: API.OperationMethod<GetFoundationModelRequest, GetFoundationModelResponse, GetFoundationModelError, Credentials | HttpClient.HttpClient>;
export type GetFoundationModelAvailabilityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get information about the Foundation model availability.
 */
export declare const getFoundationModelAvailability: API.OperationMethod<GetFoundationModelAvailabilityRequest, GetFoundationModelAvailabilityResponse, GetFoundationModelAvailabilityError, Credentials | HttpClient.HttpClient>;
export type GetGuardrailError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details about a guardrail. If you don't specify a version, the response returns details for the `DRAFT` version.
 */
export declare const getGuardrail: API.OperationMethod<GetGuardrailRequest, GetGuardrailResponse, GetGuardrailError, Credentials | HttpClient.HttpClient>;
export type GetImportedModelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets properties associated with a customized model you imported.
 */
export declare const getImportedModel: API.OperationMethod<GetImportedModelRequest, GetImportedModelResponse, GetImportedModelError, Credentials | HttpClient.HttpClient>;
export type GetInferenceProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an inference profile. For more information, see Increase throughput and resilience with cross-region inference in Amazon Bedrock. in the Amazon Bedrock User Guide.
 */
export declare const getInferenceProfile: API.OperationMethod<GetInferenceProfileRequest, GetInferenceProfileResponse, GetInferenceProfileError, Credentials | HttpClient.HttpClient>;
export type GetMarketplaceModelEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a specific endpoint for a model from Amazon Bedrock Marketplace.
 */
export declare const getMarketplaceModelEndpoint: API.OperationMethod<GetMarketplaceModelEndpointRequest, GetMarketplaceModelEndpointResponse, GetMarketplaceModelEndpointError, Credentials | HttpClient.HttpClient>;
export type GetModelCopyJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a model copy job. For more information, see Copy models to be used in other regions in the Amazon Bedrock User Guide.
 */
export declare const getModelCopyJob: API.OperationMethod<GetModelCopyJobRequest, GetModelCopyJobResponse, GetModelCopyJobError, Credentials | HttpClient.HttpClient>;
export type GetModelCustomizationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the properties associated with a model-customization job, including the status of the job. For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const getModelCustomizationJob: API.OperationMethod<GetModelCustomizationJobRequest, GetModelCustomizationJobResponse, GetModelCustomizationJobError, Credentials | HttpClient.HttpClient>;
export type GetModelImportJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the properties associated with import model job, including the status of the job. For more information, see Import a customized model in the Amazon Bedrock User Guide.
 */
export declare const getModelImportJob: API.OperationMethod<GetModelImportJobRequest, GetModelImportJobResponse, GetModelImportJobError, Credentials | HttpClient.HttpClient>;
export type GetModelInvocationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details about a batch inference job. For more information, see Monitor batch inference jobs
 */
export declare const getModelInvocationJob: API.OperationMethod<GetModelInvocationJobRequest, GetModelInvocationJobResponse, GetModelInvocationJobError, Credentials | HttpClient.HttpClient>;
export type GetModelInvocationLoggingConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Get the current configuration values for model invocation logging.
 */
export declare const getModelInvocationLoggingConfiguration: API.OperationMethod<GetModelInvocationLoggingConfigurationRequest, GetModelInvocationLoggingConfigurationResponse, GetModelInvocationLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetPromptRouterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a prompt router.
 */
export declare const getPromptRouter: API.OperationMethod<GetPromptRouterRequest, GetPromptRouterResponse, GetPromptRouterError, Credentials | HttpClient.HttpClient>;
export type GetProvisionedModelThroughputError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details for a Provisioned Throughput. For more information, see Provisioned Throughput in the Amazon Bedrock User Guide.
 */
export declare const getProvisionedModelThroughput: API.OperationMethod<GetProvisionedModelThroughputRequest, GetProvisionedModelThroughputResponse, GetProvisionedModelThroughputError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the resource policy document for a Bedrock resource
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetUseCaseForModelAccessError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get usecase for model access.
 */
export declare const getUseCaseForModelAccess: API.OperationMethod<GetUseCaseForModelAccessRequest, GetUseCaseForModelAccessResponse, GetUseCaseForModelAccessError, Credentials | HttpClient.HttpClient>;
export type ListAdvancedPromptOptimizationJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the advanced prompt optimization jobs in your account.
 */
export declare const listAdvancedPromptOptimizationJobs: API.PaginatedOperationMethod<ListAdvancedPromptOptimizationJobsRequest, ListAdvancedPromptOptimizationJobsResponse, ListAdvancedPromptOptimizationJobsError, Credentials | HttpClient.HttpClient, AdvancedPromptOptimizationJobSummary>;
export type ListAutomatedReasoningPoliciesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all Automated Reasoning policies in your account, with optional filtering by policy ARN. This helps you manage and discover existing policies.
 */
export declare const listAutomatedReasoningPolicies: API.PaginatedOperationMethod<ListAutomatedReasoningPoliciesRequest, ListAutomatedReasoningPoliciesResponse, ListAutomatedReasoningPoliciesError, Credentials | HttpClient.HttpClient, AutomatedReasoningPolicySummary>;
export type ListAutomatedReasoningPolicyBuildWorkflowsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all build workflows for an Automated Reasoning policy, showing the history of policy creation and modification attempts.
 */
export declare const listAutomatedReasoningPolicyBuildWorkflows: API.PaginatedOperationMethod<ListAutomatedReasoningPolicyBuildWorkflowsRequest, ListAutomatedReasoningPolicyBuildWorkflowsResponse, ListAutomatedReasoningPolicyBuildWorkflowsError, Credentials | HttpClient.HttpClient, AutomatedReasoningPolicyBuildWorkflowSummary>;
export type ListAutomatedReasoningPolicyTestCasesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists tests for an Automated Reasoning policy. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listAutomatedReasoningPolicyTestCases: API.PaginatedOperationMethod<ListAutomatedReasoningPolicyTestCasesRequest, ListAutomatedReasoningPolicyTestCasesResponse, ListAutomatedReasoningPolicyTestCasesError, Credentials | HttpClient.HttpClient, AutomatedReasoningPolicyTestCase>;
export type ListAutomatedReasoningPolicyTestResultsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists test results for an Automated Reasoning policy, showing how the policy performed against various test scenarios and validation checks.
 */
export declare const listAutomatedReasoningPolicyTestResults: API.PaginatedOperationMethod<ListAutomatedReasoningPolicyTestResultsRequest, ListAutomatedReasoningPolicyTestResultsResponse, ListAutomatedReasoningPolicyTestResultsError, Credentials | HttpClient.HttpClient, AutomatedReasoningPolicyTestResult>;
export type ListCustomModelDeploymentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists custom model deployments in your account. You can filter the results by creation time, name, status, and associated model. Use this operation to manage and monitor your custom model deployments.
 *
 * We recommend using pagination to ensure that the operation returns quickly and successfully.
 *
 * The following actions are related to the `ListCustomModelDeployments` operation:
 *
 * - CreateCustomModelDeployment
 *
 * - GetCustomModelDeployment
 *
 * - DeleteCustomModelDeployment
 */
export declare const listCustomModelDeployments: API.PaginatedOperationMethod<ListCustomModelDeploymentsRequest, ListCustomModelDeploymentsResponse, ListCustomModelDeploymentsError, Credentials | HttpClient.HttpClient, CustomModelDeploymentSummary>;
export type ListCustomModelsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the custom models that you have created with the `CreateModelCustomizationJob` operation.
 *
 * For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const listCustomModels: API.PaginatedOperationMethod<ListCustomModelsRequest, ListCustomModelsResponse, ListCustomModelsError, Credentials | HttpClient.HttpClient, CustomModelSummary>;
export type ListEnforcedGuardrailsConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the account-level enforced guardrail configurations.
 */
export declare const listEnforcedGuardrailsConfiguration: API.PaginatedOperationMethod<ListEnforcedGuardrailsConfigurationRequest, ListEnforcedGuardrailsConfigurationResponse, ListEnforcedGuardrailsConfigurationError, Credentials | HttpClient.HttpClient, AccountEnforcedGuardrailOutputConfiguration>;
export type ListEvaluationJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all existing evaluation jobs.
 */
export declare const listEvaluationJobs: API.PaginatedOperationMethod<ListEvaluationJobsRequest, ListEvaluationJobsResponse, ListEvaluationJobsError, Credentials | HttpClient.HttpClient, EvaluationSummary>;
export type ListFoundationModelAgreementOffersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the offers associated with the specified model.
 */
export declare const listFoundationModelAgreementOffers: API.OperationMethod<ListFoundationModelAgreementOffersRequest, ListFoundationModelAgreementOffersResponse, ListFoundationModelAgreementOffersError, Credentials | HttpClient.HttpClient>;
export type ListFoundationModelsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists Amazon Bedrock foundation models that you can use. You can filter the results with the request parameters. For more information, see Foundation models in the Amazon Bedrock User Guide.
 */
export declare const listFoundationModels: API.OperationMethod<ListFoundationModelsRequest, ListFoundationModelsResponse, ListFoundationModelsError, Credentials | HttpClient.HttpClient>;
export type ListGuardrailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists details about all the guardrails in an account. To list the `DRAFT` version of all your guardrails, don't specify the `guardrailIdentifier` field. To list all versions of a guardrail, specify the ARN of the guardrail in the `guardrailIdentifier` field.
 *
 * You can set the maximum number of results to return in a response in the `maxResults` field. If there are more results than the number you set, the response returns a `nextToken` that you can send in another `ListGuardrails` request to see the next batch of results.
 */
export declare const listGuardrails: API.PaginatedOperationMethod<ListGuardrailsRequest, ListGuardrailsResponse, ListGuardrailsError, Credentials | HttpClient.HttpClient, GuardrailSummary>;
export type ListImportedModelsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of models you've imported. You can filter the results to return based on one or more criteria. For more information, see Import a customized model in the Amazon Bedrock User Guide.
 */
export declare const listImportedModels: API.PaginatedOperationMethod<ListImportedModelsRequest, ListImportedModelsResponse, ListImportedModelsError, Credentials | HttpClient.HttpClient, ImportedModelSummary>;
export type ListInferenceProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of inference profiles that you can use. For more information, see Increase throughput and resilience with cross-region inference in Amazon Bedrock. in the Amazon Bedrock User Guide.
 */
export declare const listInferenceProfiles: API.PaginatedOperationMethod<ListInferenceProfilesRequest, ListInferenceProfilesResponse, ListInferenceProfilesError, Credentials | HttpClient.HttpClient, InferenceProfileSummary>;
export type ListMarketplaceModelEndpointsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the endpoints for models from Amazon Bedrock Marketplace in your Amazon Web Services account.
 */
export declare const listMarketplaceModelEndpoints: API.PaginatedOperationMethod<ListMarketplaceModelEndpointsRequest, ListMarketplaceModelEndpointsResponse, ListMarketplaceModelEndpointsError, Credentials | HttpClient.HttpClient, MarketplaceModelEndpointSummary>;
export type ListModelCopyJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of model copy jobs that you have submitted. You can filter the jobs to return based on one or more criteria. For more information, see Copy models to be used in other regions in the Amazon Bedrock User Guide.
 */
export declare const listModelCopyJobs: API.PaginatedOperationMethod<ListModelCopyJobsRequest, ListModelCopyJobsResponse, ListModelCopyJobsError, Credentials | HttpClient.HttpClient, ModelCopyJobSummary>;
export type ListModelCustomizationJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of model customization jobs that you have submitted. You can filter the jobs to return based on one or more criteria.
 *
 * For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const listModelCustomizationJobs: API.PaginatedOperationMethod<ListModelCustomizationJobsRequest, ListModelCustomizationJobsResponse, ListModelCustomizationJobsError, Credentials | HttpClient.HttpClient, ModelCustomizationJobSummary>;
export type ListModelImportJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of import jobs you've submitted. You can filter the results to return based on one or more criteria. For more information, see Import a customized model in the Amazon Bedrock User Guide.
 */
export declare const listModelImportJobs: API.PaginatedOperationMethod<ListModelImportJobsRequest, ListModelImportJobsResponse, ListModelImportJobsError, Credentials | HttpClient.HttpClient, ModelImportJobSummary>;
export type ListModelInvocationJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all batch inference jobs in the account. For more information, see View details about a batch inference job.
 */
export declare const listModelInvocationJobs: API.PaginatedOperationMethod<ListModelInvocationJobsRequest, ListModelInvocationJobsResponse, ListModelInvocationJobsError, Credentials | HttpClient.HttpClient, ModelInvocationJobSummary>;
export type ListPromptRoutersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of prompt routers.
 */
export declare const listPromptRouters: API.PaginatedOperationMethod<ListPromptRoutersRequest, ListPromptRoutersResponse, ListPromptRoutersError, Credentials | HttpClient.HttpClient, PromptRouterSummary>;
export type ListProvisionedModelThroughputsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Provisioned Throughputs in the account. For more information, see Provisioned Throughput in the Amazon Bedrock User Guide.
 */
export declare const listProvisionedModelThroughputs: API.PaginatedOperationMethod<ListProvisionedModelThroughputsRequest, ListProvisionedModelThroughputsResponse, ListProvisionedModelThroughputsError, Credentials | HttpClient.HttpClient, ProvisionedModelSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the tags associated with the specified resource.
 *
 * For more information, see Tagging resources in the Amazon Bedrock User Guide.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutAccountDataRetentionError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets the account-wide data retention mode for Amazon Bedrock.
 */
export declare const putAccountDataRetention: API.OperationMethod<PutAccountDataRetentionRequest, PutAccountDataRetentionResponse, PutAccountDataRetentionError, Credentials | HttpClient.HttpClient>;
export type PutEnforcedGuardrailConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets the account-level enforced guardrail configuration.
 */
export declare const putEnforcedGuardrailConfiguration: API.OperationMethod<PutEnforcedGuardrailConfigurationRequest, PutEnforcedGuardrailConfigurationResponse, PutEnforcedGuardrailConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutModelInvocationLoggingConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Set the configuration values for model invocation logging.
 */
export declare const putModelInvocationLoggingConfiguration: API.OperationMethod<PutModelInvocationLoggingConfigurationRequest, PutModelInvocationLoggingConfigurationResponse, PutModelInvocationLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a resource policy for a Bedrock resource.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type PutUseCaseForModelAccessError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Put usecase for model access.
 */
export declare const putUseCaseForModelAccess: API.OperationMethod<PutUseCaseForModelAccessRequest, PutUseCaseForModelAccessResponse, PutUseCaseForModelAccessError, Credentials | HttpClient.HttpClient>;
export type RegisterMarketplaceModelEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers an existing Amazon SageMaker endpoint with Amazon Bedrock Marketplace, allowing it to be used with Amazon Bedrock APIs.
 */
export declare const registerMarketplaceModelEndpoint: API.OperationMethod<RegisterMarketplaceModelEndpointRequest, RegisterMarketplaceModelEndpointResponse, RegisterMarketplaceModelEndpointError, Credentials | HttpClient.HttpClient>;
export type StartAutomatedReasoningPolicyBuildWorkflowError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a new build workflow for an Automated Reasoning policy. This initiates the process of analyzing source documents and generating policy rules, variables, and types.
 */
export declare const startAutomatedReasoningPolicyBuildWorkflow: API.OperationMethod<StartAutomatedReasoningPolicyBuildWorkflowRequest, StartAutomatedReasoningPolicyBuildWorkflowResponse, StartAutomatedReasoningPolicyBuildWorkflowError, Credentials | HttpClient.HttpClient>;
export type StartAutomatedReasoningPolicyTestWorkflowError = AccessDeniedException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates a test workflow to validate Automated Reasoning policy tests. The workflow executes the specified tests against the policy and generates validation results.
 */
export declare const startAutomatedReasoningPolicyTestWorkflow: API.OperationMethod<StartAutomatedReasoningPolicyTestWorkflowRequest, StartAutomatedReasoningPolicyTestWorkflowResponse, StartAutomatedReasoningPolicyTestWorkflowError, Credentials | HttpClient.HttpClient>;
export type StopAdvancedPromptOptimizationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops an advanced prompt optimization job that is in progress.
 */
export declare const stopAdvancedPromptOptimizationJob: API.OperationMethod<StopAdvancedPromptOptimizationJobRequest, StopAdvancedPromptOptimizationJobResponse, StopAdvancedPromptOptimizationJobError, Credentials | HttpClient.HttpClient>;
export type StopEvaluationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops an evaluation job that is current being created or running.
 */
export declare const stopEvaluationJob: API.OperationMethod<StopEvaluationJobRequest, StopEvaluationJobResponse, StopEvaluationJobError, Credentials | HttpClient.HttpClient>;
export type StopModelCustomizationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops an active model customization job. For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const stopModelCustomizationJob: API.OperationMethod<StopModelCustomizationJobRequest, StopModelCustomizationJobResponse, StopModelCustomizationJobError, Credentials | HttpClient.HttpClient>;
export type StopModelInvocationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a batch inference job. You're only charged for tokens that were already processed. For more information, see Stop a batch inference job.
 */
export declare const stopModelInvocationJob: API.OperationMethod<StopModelInvocationJobRequest, StopModelInvocationJobResponse, StopModelInvocationJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Associate tags with a resource. For more information, see Tagging resources in the Amazon Bedrock User Guide.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove one or more tags from a resource. For more information, see Tagging resources in the Amazon Bedrock User Guide.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAutomatedReasoningPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Updates an existing Automated Reasoning policy with new rules, variables, or configuration. This creates a new version of the policy while preserving the previous version.
 */
export declare const updateAutomatedReasoningPolicy: API.OperationMethod<UpdateAutomatedReasoningPolicyRequest, UpdateAutomatedReasoningPolicyResponse, UpdateAutomatedReasoningPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateAutomatedReasoningPolicyAnnotationsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the annotations for an Automated Reasoning policy build workflow. This allows you to modify extracted rules, variables, and types before finalizing the policy.
 */
export declare const updateAutomatedReasoningPolicyAnnotations: API.OperationMethod<UpdateAutomatedReasoningPolicyAnnotationsRequest, UpdateAutomatedReasoningPolicyAnnotationsResponse, UpdateAutomatedReasoningPolicyAnnotationsError, Credentials | HttpClient.HttpClient>;
export type UpdateAutomatedReasoningPolicyTestCaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Automated Reasoning policy test. You can modify the content, query, expected result, and confidence threshold.
 */
export declare const updateAutomatedReasoningPolicyTestCase: API.OperationMethod<UpdateAutomatedReasoningPolicyTestCaseRequest, UpdateAutomatedReasoningPolicyTestCaseResponse, UpdateAutomatedReasoningPolicyTestCaseError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomModelDeploymentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a custom model deployment with a new custom model. This allows you to deploy updated models without creating new deployment endpoints.
 */
export declare const updateCustomModelDeployment: API.OperationMethod<UpdateCustomModelDeploymentRequest, UpdateCustomModelDeploymentResponse, UpdateCustomModelDeploymentError, Credentials | HttpClient.HttpClient>;
export type UpdateGuardrailError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a guardrail with the values you specify.
 *
 * - Specify a `name` and optional `description`.
 *
 * - Specify messages for when the guardrail successfully blocks a prompt or a model response in the `blockedInputMessaging` and `blockedOutputsMessaging` fields.
 *
 * - Specify topics for the guardrail to deny in the `topicPolicyConfig` object. Each GuardrailTopicConfig object in the `topicsConfig` list pertains to one topic.
 *
 * - Give a `name` and `description` so that the guardrail can properly identify the topic.
 *
 * - Specify `DENY` in the `type` field.
 *
 * - (Optional) Provide up to five prompts that you would categorize as belonging to the topic in the `examples` list.
 *
 * - Specify filter strengths for the harmful categories defined in Amazon Bedrock in the `contentPolicyConfig` object. Each GuardrailContentFilterConfig object in the `filtersConfig` list pertains to a harmful category. For more information, see Content filters. For more information about the fields in a content filter, see GuardrailContentFilterConfig.
 *
 * - Specify the category in the `type` field.
 *
 * - Specify the strength of the filter for prompts in the `inputStrength` field and for model responses in the `strength` field of the GuardrailContentFilterConfig.
 *
 * - (Optional) For security, include the ARN of a KMS key in the `kmsKeyId` field.
 */
export declare const updateGuardrail: API.OperationMethod<UpdateGuardrailRequest, UpdateGuardrailResponse, UpdateGuardrailError, Credentials | HttpClient.HttpClient>;
export type UpdateMarketplaceModelEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an existing endpoint for a model from Amazon Bedrock Marketplace.
 */
export declare const updateMarketplaceModelEndpoint: API.OperationMethod<UpdateMarketplaceModelEndpointRequest, UpdateMarketplaceModelEndpointResponse, UpdateMarketplaceModelEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateProvisionedModelThroughputError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the name or associated model for a Provisioned Throughput. For more information, see Provisioned Throughput in the Amazon Bedrock User Guide.
 */
export declare const updateProvisionedModelThroughput: API.OperationMethod<UpdateProvisionedModelThroughputRequest, UpdateProvisionedModelThroughputResponse, UpdateProvisionedModelThroughputError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock.d.ts.map