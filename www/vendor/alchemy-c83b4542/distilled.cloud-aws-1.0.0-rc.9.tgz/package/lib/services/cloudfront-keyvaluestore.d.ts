import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type KvsARN = string;
export type Key = string;
export type Etag = string;
export interface DeleteKeyRequest {
    KvsARN: string;
    Key: string;
    IfMatch: string;
}
export declare const DeleteKeyRequest: S.Schema<DeleteKeyRequest>;
export interface DeleteKeyResponse {
    ItemCount: number;
    TotalSizeInBytes: number;
    ETag: string;
}
export declare const DeleteKeyResponse: S.Schema<DeleteKeyResponse>;
export interface DescribeKeyValueStoreRequest {
    KvsARN: string;
}
export declare const DescribeKeyValueStoreRequest: S.Schema<DescribeKeyValueStoreRequest>;
export interface DescribeKeyValueStoreResponse {
    ItemCount: number;
    TotalSizeInBytes: number;
    KvsARN: string;
    Created: Date;
    ETag: string;
    LastModified?: Date;
    Status?: string;
    FailureReason?: string;
}
export declare const DescribeKeyValueStoreResponse: S.Schema<DescribeKeyValueStoreResponse>;
export interface GetKeyRequest {
    KvsARN: string;
    Key: string;
}
export declare const GetKeyRequest: S.Schema<GetKeyRequest>;
export type Value = string | redacted.Redacted<string>;
export interface GetKeyResponse {
    Key: string;
    Value: string | redacted.Redacted<string>;
    ItemCount: number;
    TotalSizeInBytes: number;
}
export declare const GetKeyResponse: S.Schema<GetKeyResponse>;
export interface ListKeysRequest {
    KvsARN: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListKeysRequest: S.Schema<ListKeysRequest>;
export interface ListKeysResponseListItem {
    Key: string;
    Value: string | redacted.Redacted<string>;
}
export declare const ListKeysResponseListItem: S.Schema<ListKeysResponseListItem>;
export type ListKeysResponseList = ListKeysResponseListItem[];
export declare const ListKeysResponseList: any;
export interface ListKeysResponse {
    NextToken?: string;
    Items?: ListKeysResponseListItem[];
}
export declare const ListKeysResponse: S.Schema<ListKeysResponse>;
export interface PutKeyRequest {
    Key: string;
    Value: string | redacted.Redacted<string>;
    KvsARN: string;
    IfMatch: string;
}
export declare const PutKeyRequest: S.Schema<PutKeyRequest>;
export interface PutKeyResponse {
    ItemCount: number;
    TotalSizeInBytes: number;
    ETag: string;
}
export declare const PutKeyResponse: S.Schema<PutKeyResponse>;
export interface PutKeyRequestListItem {
    Key: string;
    Value: string | redacted.Redacted<string>;
}
export declare const PutKeyRequestListItem: S.Schema<PutKeyRequestListItem>;
export type PutKeyRequestsList = PutKeyRequestListItem[];
export declare const PutKeyRequestsList: any;
export interface DeleteKeyRequestListItem {
    Key: string;
}
export declare const DeleteKeyRequestListItem: S.Schema<DeleteKeyRequestListItem>;
export type DeleteKeyRequestsList = DeleteKeyRequestListItem[];
export declare const DeleteKeyRequestsList: any;
export interface UpdateKeysRequest {
    KvsARN: string;
    IfMatch: string;
    Puts?: PutKeyRequestListItem[];
    Deletes?: DeleteKeyRequestListItem[];
}
export declare const UpdateKeysRequest: S.Schema<UpdateKeysRequest>;
export interface UpdateKeysResponse {
    ItemCount: number;
    TotalSizeInBytes: number;
    ETag: string;
}
export declare const UpdateKeysResponse: S.Schema<UpdateKeysResponse>;
export type DeleteKeyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Deletes the key value pair specified by the key.
 */
export declare const deleteKey: API.OperationMethod<DeleteKeyRequest, DeleteKeyResponse, DeleteKeyError, Credentials | HttpClient.HttpClient>;
export type DescribeKeyValueStoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Returns metadata information about Key Value Store.
 */
export declare const describeKeyValueStore: API.OperationMethod<DescribeKeyValueStoreRequest, DescribeKeyValueStoreResponse, DescribeKeyValueStoreError, Credentials | HttpClient.HttpClient>;
export type GetKeyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a key value pair.
 */
export declare const getKey: API.OperationMethod<GetKeyRequest, GetKeyResponse, GetKeyError, Credentials | HttpClient.HttpClient>;
export type ListKeysError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of key value pairs.
 */
export declare const listKeys: API.PaginatedOperationMethod<ListKeysRequest, ListKeysResponse, ListKeysError, Credentials | HttpClient.HttpClient, ListKeysResponseListItem>;
export type PutKeyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a new key value pair or replaces the value of an existing key.
 */
export declare const putKey: API.OperationMethod<PutKeyRequest, PutKeyResponse, PutKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateKeysError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Puts or Deletes multiple key value pairs in a single, all-or-nothing operation.
 */
export declare const updateKeys: API.OperationMethod<UpdateKeysRequest, UpdateKeysResponse, UpdateKeysError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudfront-keyvaluestore.d.ts.map