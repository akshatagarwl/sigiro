import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ActorDoesNotExistException_base: S.Class<ActorDoesNotExistException, S.TaggedStruct<"ActorDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ActorDoesNotExistException extends /*@__PURE__*/ ActorDoesNotExistException_base {
}
declare const ApprovalRuleContentRequiredException_base: S.Class<ApprovalRuleContentRequiredException, S.TaggedStruct<"ApprovalRuleContentRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ApprovalRuleContentRequiredException extends /*@__PURE__*/ ApprovalRuleContentRequiredException_base {
}
declare const ApprovalRuleDoesNotExistException_base: S.Class<ApprovalRuleDoesNotExistException, S.TaggedStruct<"ApprovalRuleDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ApprovalRuleDoesNotExistException extends /*@__PURE__*/ ApprovalRuleDoesNotExistException_base {
}
declare const ApprovalRuleNameAlreadyExistsException_base: S.Class<ApprovalRuleNameAlreadyExistsException, S.TaggedStruct<"ApprovalRuleNameAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ApprovalRuleNameAlreadyExistsException extends /*@__PURE__*/ ApprovalRuleNameAlreadyExistsException_base {
}
declare const ApprovalRuleNameRequiredException_base: S.Class<ApprovalRuleNameRequiredException, S.TaggedStruct<"ApprovalRuleNameRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ApprovalRuleNameRequiredException extends /*@__PURE__*/ ApprovalRuleNameRequiredException_base {
}
declare const ApprovalRuleTemplateContentRequiredException_base: S.Class<ApprovalRuleTemplateContentRequiredException, S.TaggedStruct<"ApprovalRuleTemplateContentRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ApprovalRuleTemplateContentRequiredException extends /*@__PURE__*/ ApprovalRuleTemplateContentRequiredException_base {
}
declare const ApprovalRuleTemplateDoesNotExistException_base: S.Class<ApprovalRuleTemplateDoesNotExistException, S.TaggedStruct<"ApprovalRuleTemplateDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ApprovalRuleTemplateDoesNotExistException extends /*@__PURE__*/ ApprovalRuleTemplateDoesNotExistException_base {
}
declare const ApprovalRuleTemplateInUseException_base: S.Class<ApprovalRuleTemplateInUseException, S.TaggedStruct<"ApprovalRuleTemplateInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ApprovalRuleTemplateInUseException extends /*@__PURE__*/ ApprovalRuleTemplateInUseException_base {
}
declare const ApprovalRuleTemplateNameAlreadyExistsException_base: S.Class<ApprovalRuleTemplateNameAlreadyExistsException, S.TaggedStruct<"ApprovalRuleTemplateNameAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ApprovalRuleTemplateNameAlreadyExistsException extends /*@__PURE__*/ ApprovalRuleTemplateNameAlreadyExistsException_base {
}
declare const ApprovalRuleTemplateNameRequiredException_base: S.Class<ApprovalRuleTemplateNameRequiredException, S.TaggedStruct<"ApprovalRuleTemplateNameRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ApprovalRuleTemplateNameRequiredException extends /*@__PURE__*/ ApprovalRuleTemplateNameRequiredException_base {
}
declare const ApprovalStateRequiredException_base: S.Class<ApprovalStateRequiredException, S.TaggedStruct<"ApprovalStateRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ApprovalStateRequiredException extends /*@__PURE__*/ ApprovalStateRequiredException_base {
}
declare const AuthorDoesNotExistException_base: S.Class<AuthorDoesNotExistException, S.TaggedStruct<"AuthorDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AuthorDoesNotExistException extends /*@__PURE__*/ AuthorDoesNotExistException_base {
}
declare const BeforeCommitIdAndAfterCommitIdAreSameException_base: S.Class<BeforeCommitIdAndAfterCommitIdAreSameException, S.TaggedStruct<"BeforeCommitIdAndAfterCommitIdAreSameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BeforeCommitIdAndAfterCommitIdAreSameException extends /*@__PURE__*/ BeforeCommitIdAndAfterCommitIdAreSameException_base {
}
declare const BlobIdDoesNotExistException_base: S.Class<BlobIdDoesNotExistException, S.TaggedStruct<"BlobIdDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BlobIdDoesNotExistException extends /*@__PURE__*/ BlobIdDoesNotExistException_base {
}
declare const BlobIdRequiredException_base: S.Class<BlobIdRequiredException, S.TaggedStruct<"BlobIdRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BlobIdRequiredException extends /*@__PURE__*/ BlobIdRequiredException_base {
}
declare const BranchDoesNotExistException_base: S.Class<BranchDoesNotExistException, S.TaggedStruct<"BranchDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BranchDoesNotExistException extends /*@__PURE__*/ BranchDoesNotExistException_base {
}
declare const BranchNameExistsException_base: S.Class<BranchNameExistsException, S.TaggedStruct<"BranchNameExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BranchNameExistsException extends /*@__PURE__*/ BranchNameExistsException_base {
}
declare const BranchNameIsTagNameException_base: S.Class<BranchNameIsTagNameException, S.TaggedStruct<"BranchNameIsTagNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BranchNameIsTagNameException extends /*@__PURE__*/ BranchNameIsTagNameException_base {
}
declare const BranchNameRequiredException_base: S.Class<BranchNameRequiredException, S.TaggedStruct<"BranchNameRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BranchNameRequiredException extends /*@__PURE__*/ BranchNameRequiredException_base {
}
declare const CannotDeleteApprovalRuleFromTemplateException_base: S.Class<CannotDeleteApprovalRuleFromTemplateException, S.TaggedStruct<"CannotDeleteApprovalRuleFromTemplateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CannotDeleteApprovalRuleFromTemplateException extends /*@__PURE__*/ CannotDeleteApprovalRuleFromTemplateException_base {
}
declare const CannotModifyApprovalRuleFromTemplateException_base: S.Class<CannotModifyApprovalRuleFromTemplateException, S.TaggedStruct<"CannotModifyApprovalRuleFromTemplateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CannotModifyApprovalRuleFromTemplateException extends /*@__PURE__*/ CannotModifyApprovalRuleFromTemplateException_base {
}
declare const ClientRequestTokenRequiredException_base: S.Class<ClientRequestTokenRequiredException, S.TaggedStruct<"ClientRequestTokenRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ClientRequestTokenRequiredException extends /*@__PURE__*/ ClientRequestTokenRequiredException_base {
}
declare const CommentContentRequiredException_base: S.Class<CommentContentRequiredException, S.TaggedStruct<"CommentContentRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CommentContentRequiredException extends /*@__PURE__*/ CommentContentRequiredException_base {
}
declare const CommentContentSizeLimitExceededException_base: S.Class<CommentContentSizeLimitExceededException, S.TaggedStruct<"CommentContentSizeLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CommentContentSizeLimitExceededException extends /*@__PURE__*/ CommentContentSizeLimitExceededException_base {
}
declare const CommentDeletedException_base: S.Class<CommentDeletedException, S.TaggedStruct<"CommentDeletedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CommentDeletedException extends /*@__PURE__*/ CommentDeletedException_base {
}
declare const CommentDoesNotExistException_base: S.Class<CommentDoesNotExistException, S.TaggedStruct<"CommentDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CommentDoesNotExistException extends /*@__PURE__*/ CommentDoesNotExistException_base {
}
declare const CommentIdRequiredException_base: S.Class<CommentIdRequiredException, S.TaggedStruct<"CommentIdRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CommentIdRequiredException extends /*@__PURE__*/ CommentIdRequiredException_base {
}
declare const CommentNotCreatedByCallerException_base: S.Class<CommentNotCreatedByCallerException, S.TaggedStruct<"CommentNotCreatedByCallerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CommentNotCreatedByCallerException extends /*@__PURE__*/ CommentNotCreatedByCallerException_base {
}
declare const CommitDoesNotExistException_base: S.Class<CommitDoesNotExistException, S.TaggedStruct<"CommitDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CommitDoesNotExistException extends /*@__PURE__*/ CommitDoesNotExistException_base {
}
declare const CommitIdDoesNotExistException_base: S.Class<CommitIdDoesNotExistException, S.TaggedStruct<"CommitIdDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CommitIdDoesNotExistException extends /*@__PURE__*/ CommitIdDoesNotExistException_base {
}
declare const CommitIdRequiredException_base: S.Class<CommitIdRequiredException, S.TaggedStruct<"CommitIdRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CommitIdRequiredException extends /*@__PURE__*/ CommitIdRequiredException_base {
}
declare const CommitIdsLimitExceededException_base: S.Class<CommitIdsLimitExceededException, S.TaggedStruct<"CommitIdsLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CommitIdsLimitExceededException extends /*@__PURE__*/ CommitIdsLimitExceededException_base {
}
declare const CommitIdsListRequiredException_base: S.Class<CommitIdsListRequiredException, S.TaggedStruct<"CommitIdsListRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CommitIdsListRequiredException extends /*@__PURE__*/ CommitIdsListRequiredException_base {
}
declare const CommitMessageLengthExceededException_base: S.Class<CommitMessageLengthExceededException, S.TaggedStruct<"CommitMessageLengthExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CommitMessageLengthExceededException extends /*@__PURE__*/ CommitMessageLengthExceededException_base {
}
declare const CommitRequiredException_base: S.Class<CommitRequiredException, S.TaggedStruct<"CommitRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CommitRequiredException extends /*@__PURE__*/ CommitRequiredException_base {
}
declare const ConcurrentReferenceUpdateException_base: S.Class<ConcurrentReferenceUpdateException, S.TaggedStruct<"ConcurrentReferenceUpdateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConcurrentReferenceUpdateException extends /*@__PURE__*/ ConcurrentReferenceUpdateException_base {
}
declare const DefaultBranchCannotBeDeletedException_base: S.Class<DefaultBranchCannotBeDeletedException, S.TaggedStruct<"DefaultBranchCannotBeDeletedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DefaultBranchCannotBeDeletedException extends /*@__PURE__*/ DefaultBranchCannotBeDeletedException_base {
}
declare const DirectoryNameConflictsWithFileNameException_base: S.Class<DirectoryNameConflictsWithFileNameException, S.TaggedStruct<"DirectoryNameConflictsWithFileNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DirectoryNameConflictsWithFileNameException extends /*@__PURE__*/ DirectoryNameConflictsWithFileNameException_base {
}
declare const EncryptionIntegrityChecksFailedException_base: S.Class<EncryptionIntegrityChecksFailedException, S.TaggedStruct<"EncryptionIntegrityChecksFailedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EncryptionIntegrityChecksFailedException extends /*@__PURE__*/ EncryptionIntegrityChecksFailedException_base {
}
declare const EncryptionKeyAccessDeniedException_base: S.Class<EncryptionKeyAccessDeniedException, S.TaggedStruct<"EncryptionKeyAccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class EncryptionKeyAccessDeniedException extends /*@__PURE__*/ EncryptionKeyAccessDeniedException_base {
}
declare const EncryptionKeyDisabledException_base: S.Class<EncryptionKeyDisabledException, S.TaggedStruct<"EncryptionKeyDisabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EncryptionKeyDisabledException extends /*@__PURE__*/ EncryptionKeyDisabledException_base {
}
declare const EncryptionKeyInvalidIdException_base: S.Class<EncryptionKeyInvalidIdException, S.TaggedStruct<"EncryptionKeyInvalidIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EncryptionKeyInvalidIdException extends /*@__PURE__*/ EncryptionKeyInvalidIdException_base {
}
declare const EncryptionKeyInvalidUsageException_base: S.Class<EncryptionKeyInvalidUsageException, S.TaggedStruct<"EncryptionKeyInvalidUsageException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EncryptionKeyInvalidUsageException extends /*@__PURE__*/ EncryptionKeyInvalidUsageException_base {
}
declare const EncryptionKeyNotFoundException_base: S.Class<EncryptionKeyNotFoundException, S.TaggedStruct<"EncryptionKeyNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EncryptionKeyNotFoundException extends /*@__PURE__*/ EncryptionKeyNotFoundException_base {
}
declare const EncryptionKeyRequiredException_base: S.Class<EncryptionKeyRequiredException, S.TaggedStruct<"EncryptionKeyRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EncryptionKeyRequiredException extends /*@__PURE__*/ EncryptionKeyRequiredException_base {
}
declare const EncryptionKeyUnavailableException_base: S.Class<EncryptionKeyUnavailableException, S.TaggedStruct<"EncryptionKeyUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EncryptionKeyUnavailableException extends /*@__PURE__*/ EncryptionKeyUnavailableException_base {
}
declare const FileContentAndSourceFileSpecifiedException_base: S.Class<FileContentAndSourceFileSpecifiedException, S.TaggedStruct<"FileContentAndSourceFileSpecifiedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FileContentAndSourceFileSpecifiedException extends /*@__PURE__*/ FileContentAndSourceFileSpecifiedException_base {
}
declare const FileContentRequiredException_base: S.Class<FileContentRequiredException, S.TaggedStruct<"FileContentRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FileContentRequiredException extends /*@__PURE__*/ FileContentRequiredException_base {
}
declare const FileContentSizeLimitExceededException_base: S.Class<FileContentSizeLimitExceededException, S.TaggedStruct<"FileContentSizeLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FileContentSizeLimitExceededException extends /*@__PURE__*/ FileContentSizeLimitExceededException_base {
}
declare const FileDoesNotExistException_base: S.Class<FileDoesNotExistException, S.TaggedStruct<"FileDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FileDoesNotExistException extends /*@__PURE__*/ FileDoesNotExistException_base {
}
declare const FileEntryRequiredException_base: S.Class<FileEntryRequiredException, S.TaggedStruct<"FileEntryRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FileEntryRequiredException extends /*@__PURE__*/ FileEntryRequiredException_base {
}
declare const FileModeRequiredException_base: S.Class<FileModeRequiredException, S.TaggedStruct<"FileModeRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FileModeRequiredException extends /*@__PURE__*/ FileModeRequiredException_base {
}
declare const FileNameConflictsWithDirectoryNameException_base: S.Class<FileNameConflictsWithDirectoryNameException, S.TaggedStruct<"FileNameConflictsWithDirectoryNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FileNameConflictsWithDirectoryNameException extends /*@__PURE__*/ FileNameConflictsWithDirectoryNameException_base {
}
declare const FilePathConflictsWithSubmodulePathException_base: S.Class<FilePathConflictsWithSubmodulePathException, S.TaggedStruct<"FilePathConflictsWithSubmodulePathException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FilePathConflictsWithSubmodulePathException extends /*@__PURE__*/ FilePathConflictsWithSubmodulePathException_base {
}
declare const FileTooLargeException_base: S.Class<FileTooLargeException, S.TaggedStruct<"FileTooLargeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FileTooLargeException extends /*@__PURE__*/ FileTooLargeException_base {
}
declare const FolderContentSizeLimitExceededException_base: S.Class<FolderContentSizeLimitExceededException, S.TaggedStruct<"FolderContentSizeLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FolderContentSizeLimitExceededException extends /*@__PURE__*/ FolderContentSizeLimitExceededException_base {
}
declare const FolderDoesNotExistException_base: S.Class<FolderDoesNotExistException, S.TaggedStruct<"FolderDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FolderDoesNotExistException extends /*@__PURE__*/ FolderDoesNotExistException_base {
}
declare const IdempotencyParameterMismatchException_base: S.Class<IdempotencyParameterMismatchException, S.TaggedStruct<"IdempotencyParameterMismatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IdempotencyParameterMismatchException extends /*@__PURE__*/ IdempotencyParameterMismatchException_base {
}
declare const InvalidActorArnException_base: S.Class<InvalidActorArnException, S.TaggedStruct<"InvalidActorArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidActorArnException extends /*@__PURE__*/ InvalidActorArnException_base {
}
declare const InvalidApprovalRuleContentException_base: S.Class<InvalidApprovalRuleContentException, S.TaggedStruct<"InvalidApprovalRuleContentException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidApprovalRuleContentException extends /*@__PURE__*/ InvalidApprovalRuleContentException_base {
}
declare const InvalidApprovalRuleNameException_base: S.Class<InvalidApprovalRuleNameException, S.TaggedStruct<"InvalidApprovalRuleNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidApprovalRuleNameException extends /*@__PURE__*/ InvalidApprovalRuleNameException_base {
}
declare const InvalidApprovalRuleTemplateContentException_base: S.Class<InvalidApprovalRuleTemplateContentException, S.TaggedStruct<"InvalidApprovalRuleTemplateContentException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidApprovalRuleTemplateContentException extends /*@__PURE__*/ InvalidApprovalRuleTemplateContentException_base {
}
declare const InvalidApprovalRuleTemplateDescriptionException_base: S.Class<InvalidApprovalRuleTemplateDescriptionException, S.TaggedStruct<"InvalidApprovalRuleTemplateDescriptionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidApprovalRuleTemplateDescriptionException extends /*@__PURE__*/ InvalidApprovalRuleTemplateDescriptionException_base {
}
declare const InvalidApprovalRuleTemplateNameException_base: S.Class<InvalidApprovalRuleTemplateNameException, S.TaggedStruct<"InvalidApprovalRuleTemplateNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidApprovalRuleTemplateNameException extends /*@__PURE__*/ InvalidApprovalRuleTemplateNameException_base {
}
declare const InvalidApprovalStateException_base: S.Class<InvalidApprovalStateException, S.TaggedStruct<"InvalidApprovalStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidApprovalStateException extends /*@__PURE__*/ InvalidApprovalStateException_base {
}
declare const InvalidAuthorArnException_base: S.Class<InvalidAuthorArnException, S.TaggedStruct<"InvalidAuthorArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidAuthorArnException extends /*@__PURE__*/ InvalidAuthorArnException_base {
}
declare const InvalidBlobIdException_base: S.Class<InvalidBlobIdException, S.TaggedStruct<"InvalidBlobIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidBlobIdException extends /*@__PURE__*/ InvalidBlobIdException_base {
}
declare const InvalidBranchNameException_base: S.Class<InvalidBranchNameException, S.TaggedStruct<"InvalidBranchNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidBranchNameException extends /*@__PURE__*/ InvalidBranchNameException_base {
}
declare const InvalidClientRequestTokenException_base: S.Class<InvalidClientRequestTokenException, S.TaggedStruct<"InvalidClientRequestTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidClientRequestTokenException extends /*@__PURE__*/ InvalidClientRequestTokenException_base {
}
declare const InvalidCommentIdException_base: S.Class<InvalidCommentIdException, S.TaggedStruct<"InvalidCommentIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidCommentIdException extends /*@__PURE__*/ InvalidCommentIdException_base {
}
declare const InvalidCommitException_base: S.Class<InvalidCommitException, S.TaggedStruct<"InvalidCommitException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidCommitException extends /*@__PURE__*/ InvalidCommitException_base {
}
declare const InvalidCommitIdException_base: S.Class<InvalidCommitIdException, S.TaggedStruct<"InvalidCommitIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidCommitIdException extends /*@__PURE__*/ InvalidCommitIdException_base {
}
declare const InvalidConflictDetailLevelException_base: S.Class<InvalidConflictDetailLevelException, S.TaggedStruct<"InvalidConflictDetailLevelException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidConflictDetailLevelException extends /*@__PURE__*/ InvalidConflictDetailLevelException_base {
}
declare const InvalidConflictResolutionException_base: S.Class<InvalidConflictResolutionException, S.TaggedStruct<"InvalidConflictResolutionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidConflictResolutionException extends /*@__PURE__*/ InvalidConflictResolutionException_base {
}
declare const InvalidConflictResolutionStrategyException_base: S.Class<InvalidConflictResolutionStrategyException, S.TaggedStruct<"InvalidConflictResolutionStrategyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidConflictResolutionStrategyException extends /*@__PURE__*/ InvalidConflictResolutionStrategyException_base {
}
declare const InvalidContinuationTokenException_base: S.Class<InvalidContinuationTokenException, S.TaggedStruct<"InvalidContinuationTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidContinuationTokenException extends /*@__PURE__*/ InvalidContinuationTokenException_base {
}
declare const InvalidDeletionParameterException_base: S.Class<InvalidDeletionParameterException, S.TaggedStruct<"InvalidDeletionParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDeletionParameterException extends /*@__PURE__*/ InvalidDeletionParameterException_base {
}
declare const InvalidDescriptionException_base: S.Class<InvalidDescriptionException, S.TaggedStruct<"InvalidDescriptionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDescriptionException extends /*@__PURE__*/ InvalidDescriptionException_base {
}
declare const InvalidDestinationCommitSpecifierException_base: S.Class<InvalidDestinationCommitSpecifierException, S.TaggedStruct<"InvalidDestinationCommitSpecifierException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDestinationCommitSpecifierException extends /*@__PURE__*/ InvalidDestinationCommitSpecifierException_base {
}
declare const InvalidEmailException_base: S.Class<InvalidEmailException, S.TaggedStruct<"InvalidEmailException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidEmailException extends /*@__PURE__*/ InvalidEmailException_base {
}
declare const InvalidFileLocationException_base: S.Class<InvalidFileLocationException, S.TaggedStruct<"InvalidFileLocationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidFileLocationException extends /*@__PURE__*/ InvalidFileLocationException_base {
}
declare const InvalidFileModeException_base: S.Class<InvalidFileModeException, S.TaggedStruct<"InvalidFileModeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidFileModeException extends /*@__PURE__*/ InvalidFileModeException_base {
}
declare const InvalidFilePositionException_base: S.Class<InvalidFilePositionException, S.TaggedStruct<"InvalidFilePositionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidFilePositionException extends /*@__PURE__*/ InvalidFilePositionException_base {
}
declare const InvalidMaxConflictFilesException_base: S.Class<InvalidMaxConflictFilesException, S.TaggedStruct<"InvalidMaxConflictFilesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidMaxConflictFilesException extends /*@__PURE__*/ InvalidMaxConflictFilesException_base {
}
declare const InvalidMaxMergeHunksException_base: S.Class<InvalidMaxMergeHunksException, S.TaggedStruct<"InvalidMaxMergeHunksException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidMaxMergeHunksException extends /*@__PURE__*/ InvalidMaxMergeHunksException_base {
}
declare const InvalidMaxResultsException_base: S.Class<InvalidMaxResultsException, S.TaggedStruct<"InvalidMaxResultsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidMaxResultsException extends /*@__PURE__*/ InvalidMaxResultsException_base {
}
declare const InvalidMergeOptionException_base: S.Class<InvalidMergeOptionException, S.TaggedStruct<"InvalidMergeOptionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidMergeOptionException extends /*@__PURE__*/ InvalidMergeOptionException_base {
}
declare const InvalidOrderException_base: S.Class<InvalidOrderException, S.TaggedStruct<"InvalidOrderException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidOrderException extends /*@__PURE__*/ InvalidOrderException_base {
}
declare const InvalidOverrideStatusException_base: S.Class<InvalidOverrideStatusException, S.TaggedStruct<"InvalidOverrideStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidOverrideStatusException extends /*@__PURE__*/ InvalidOverrideStatusException_base {
}
declare const InvalidParentCommitIdException_base: S.Class<InvalidParentCommitIdException, S.TaggedStruct<"InvalidParentCommitIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidParentCommitIdException extends /*@__PURE__*/ InvalidParentCommitIdException_base {
}
declare const InvalidPathException_base: S.Class<InvalidPathException, S.TaggedStruct<"InvalidPathException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidPathException extends /*@__PURE__*/ InvalidPathException_base {
}
declare const InvalidPullRequestEventTypeException_base: S.Class<InvalidPullRequestEventTypeException, S.TaggedStruct<"InvalidPullRequestEventTypeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidPullRequestEventTypeException extends /*@__PURE__*/ InvalidPullRequestEventTypeException_base {
}
declare const InvalidPullRequestIdException_base: S.Class<InvalidPullRequestIdException, S.TaggedStruct<"InvalidPullRequestIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidPullRequestIdException extends /*@__PURE__*/ InvalidPullRequestIdException_base {
}
declare const InvalidPullRequestStatusException_base: S.Class<InvalidPullRequestStatusException, S.TaggedStruct<"InvalidPullRequestStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidPullRequestStatusException extends /*@__PURE__*/ InvalidPullRequestStatusException_base {
}
declare const InvalidPullRequestStatusUpdateException_base: S.Class<InvalidPullRequestStatusUpdateException, S.TaggedStruct<"InvalidPullRequestStatusUpdateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidPullRequestStatusUpdateException extends /*@__PURE__*/ InvalidPullRequestStatusUpdateException_base {
}
declare const InvalidReactionUserArnException_base: S.Class<InvalidReactionUserArnException, S.TaggedStruct<"InvalidReactionUserArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidReactionUserArnException extends /*@__PURE__*/ InvalidReactionUserArnException_base {
}
declare const InvalidReactionValueException_base: S.Class<InvalidReactionValueException, S.TaggedStruct<"InvalidReactionValueException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidReactionValueException extends /*@__PURE__*/ InvalidReactionValueException_base {
}
declare const InvalidReferenceNameException_base: S.Class<InvalidReferenceNameException, S.TaggedStruct<"InvalidReferenceNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidReferenceNameException extends /*@__PURE__*/ InvalidReferenceNameException_base {
}
declare const InvalidRelativeFileVersionEnumException_base: S.Class<InvalidRelativeFileVersionEnumException, S.TaggedStruct<"InvalidRelativeFileVersionEnumException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRelativeFileVersionEnumException extends /*@__PURE__*/ InvalidRelativeFileVersionEnumException_base {
}
declare const InvalidReplacementContentException_base: S.Class<InvalidReplacementContentException, S.TaggedStruct<"InvalidReplacementContentException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidReplacementContentException extends /*@__PURE__*/ InvalidReplacementContentException_base {
}
declare const InvalidReplacementTypeException_base: S.Class<InvalidReplacementTypeException, S.TaggedStruct<"InvalidReplacementTypeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidReplacementTypeException extends /*@__PURE__*/ InvalidReplacementTypeException_base {
}
declare const InvalidRepositoryDescriptionException_base: S.Class<InvalidRepositoryDescriptionException, S.TaggedStruct<"InvalidRepositoryDescriptionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRepositoryDescriptionException extends /*@__PURE__*/ InvalidRepositoryDescriptionException_base {
}
declare const InvalidRepositoryNameException_base: S.Class<InvalidRepositoryNameException, S.TaggedStruct<"InvalidRepositoryNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRepositoryNameException extends /*@__PURE__*/ InvalidRepositoryNameException_base {
}
declare const InvalidRepositoryTriggerBranchNameException_base: S.Class<InvalidRepositoryTriggerBranchNameException, S.TaggedStruct<"InvalidRepositoryTriggerBranchNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRepositoryTriggerBranchNameException extends /*@__PURE__*/ InvalidRepositoryTriggerBranchNameException_base {
}
declare const InvalidRepositoryTriggerCustomDataException_base: S.Class<InvalidRepositoryTriggerCustomDataException, S.TaggedStruct<"InvalidRepositoryTriggerCustomDataException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRepositoryTriggerCustomDataException extends /*@__PURE__*/ InvalidRepositoryTriggerCustomDataException_base {
}
declare const InvalidRepositoryTriggerDestinationArnException_base: S.Class<InvalidRepositoryTriggerDestinationArnException, S.TaggedStruct<"InvalidRepositoryTriggerDestinationArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRepositoryTriggerDestinationArnException extends /*@__PURE__*/ InvalidRepositoryTriggerDestinationArnException_base {
}
declare const InvalidRepositoryTriggerEventsException_base: S.Class<InvalidRepositoryTriggerEventsException, S.TaggedStruct<"InvalidRepositoryTriggerEventsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRepositoryTriggerEventsException extends /*@__PURE__*/ InvalidRepositoryTriggerEventsException_base {
}
declare const InvalidRepositoryTriggerNameException_base: S.Class<InvalidRepositoryTriggerNameException, S.TaggedStruct<"InvalidRepositoryTriggerNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRepositoryTriggerNameException extends /*@__PURE__*/ InvalidRepositoryTriggerNameException_base {
}
declare const InvalidRepositoryTriggerRegionException_base: S.Class<InvalidRepositoryTriggerRegionException, S.TaggedStruct<"InvalidRepositoryTriggerRegionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRepositoryTriggerRegionException extends /*@__PURE__*/ InvalidRepositoryTriggerRegionException_base {
}
declare const InvalidResourceArnException_base: S.Class<InvalidResourceArnException, S.TaggedStruct<"InvalidResourceArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidResourceArnException extends /*@__PURE__*/ InvalidResourceArnException_base {
}
declare const InvalidRevisionIdException_base: S.Class<InvalidRevisionIdException, S.TaggedStruct<"InvalidRevisionIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRevisionIdException extends /*@__PURE__*/ InvalidRevisionIdException_base {
}
declare const InvalidRuleContentSha256Exception_base: S.Class<InvalidRuleContentSha256Exception, S.TaggedStruct<"InvalidRuleContentSha256Exception", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRuleContentSha256Exception extends /*@__PURE__*/ InvalidRuleContentSha256Exception_base {
}
declare const InvalidSortByException_base: S.Class<InvalidSortByException, S.TaggedStruct<"InvalidSortByException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSortByException extends /*@__PURE__*/ InvalidSortByException_base {
}
declare const InvalidSourceCommitSpecifierException_base: S.Class<InvalidSourceCommitSpecifierException, S.TaggedStruct<"InvalidSourceCommitSpecifierException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSourceCommitSpecifierException extends /*@__PURE__*/ InvalidSourceCommitSpecifierException_base {
}
declare const InvalidSystemTagUsageException_base: S.Class<InvalidSystemTagUsageException, S.TaggedStruct<"InvalidSystemTagUsageException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSystemTagUsageException extends /*@__PURE__*/ InvalidSystemTagUsageException_base {
}
declare const InvalidTagKeysListException_base: S.Class<InvalidTagKeysListException, S.TaggedStruct<"InvalidTagKeysListException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTagKeysListException extends /*@__PURE__*/ InvalidTagKeysListException_base {
}
declare const InvalidTagsMapException_base: S.Class<InvalidTagsMapException, S.TaggedStruct<"InvalidTagsMapException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTagsMapException extends /*@__PURE__*/ InvalidTagsMapException_base {
}
declare const InvalidTargetBranchException_base: S.Class<InvalidTargetBranchException, S.TaggedStruct<"InvalidTargetBranchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTargetBranchException extends /*@__PURE__*/ InvalidTargetBranchException_base {
}
declare const InvalidTargetException_base: S.Class<InvalidTargetException, S.TaggedStruct<"InvalidTargetException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTargetException extends /*@__PURE__*/ InvalidTargetException_base {
}
declare const InvalidTargetsException_base: S.Class<InvalidTargetsException, S.TaggedStruct<"InvalidTargetsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTargetsException extends /*@__PURE__*/ InvalidTargetsException_base {
}
declare const InvalidTitleException_base: S.Class<InvalidTitleException, S.TaggedStruct<"InvalidTitleException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTitleException extends /*@__PURE__*/ InvalidTitleException_base {
}
declare const ManualMergeRequiredException_base: S.Class<ManualMergeRequiredException, S.TaggedStruct<"ManualMergeRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ManualMergeRequiredException extends /*@__PURE__*/ ManualMergeRequiredException_base {
}
declare const MaximumBranchesExceededException_base: S.Class<MaximumBranchesExceededException, S.TaggedStruct<"MaximumBranchesExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaximumBranchesExceededException extends /*@__PURE__*/ MaximumBranchesExceededException_base {
}
declare const MaximumConflictResolutionEntriesExceededException_base: S.Class<MaximumConflictResolutionEntriesExceededException, S.TaggedStruct<"MaximumConflictResolutionEntriesExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaximumConflictResolutionEntriesExceededException extends /*@__PURE__*/ MaximumConflictResolutionEntriesExceededException_base {
}
declare const MaximumFileContentToLoadExceededException_base: S.Class<MaximumFileContentToLoadExceededException, S.TaggedStruct<"MaximumFileContentToLoadExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaximumFileContentToLoadExceededException extends /*@__PURE__*/ MaximumFileContentToLoadExceededException_base {
}
declare const MaximumFileEntriesExceededException_base: S.Class<MaximumFileEntriesExceededException, S.TaggedStruct<"MaximumFileEntriesExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaximumFileEntriesExceededException extends /*@__PURE__*/ MaximumFileEntriesExceededException_base {
}
declare const MaximumItemsToCompareExceededException_base: S.Class<MaximumItemsToCompareExceededException, S.TaggedStruct<"MaximumItemsToCompareExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaximumItemsToCompareExceededException extends /*@__PURE__*/ MaximumItemsToCompareExceededException_base {
}
declare const MaximumNumberOfApprovalsExceededException_base: S.Class<MaximumNumberOfApprovalsExceededException, S.TaggedStruct<"MaximumNumberOfApprovalsExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaximumNumberOfApprovalsExceededException extends /*@__PURE__*/ MaximumNumberOfApprovalsExceededException_base {
}
declare const MaximumOpenPullRequestsExceededException_base: S.Class<MaximumOpenPullRequestsExceededException, S.TaggedStruct<"MaximumOpenPullRequestsExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaximumOpenPullRequestsExceededException extends /*@__PURE__*/ MaximumOpenPullRequestsExceededException_base {
}
declare const MaximumRepositoryNamesExceededException_base: S.Class<MaximumRepositoryNamesExceededException, S.TaggedStruct<"MaximumRepositoryNamesExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaximumRepositoryNamesExceededException extends /*@__PURE__*/ MaximumRepositoryNamesExceededException_base {
}
declare const MaximumRepositoryTriggersExceededException_base: S.Class<MaximumRepositoryTriggersExceededException, S.TaggedStruct<"MaximumRepositoryTriggersExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaximumRepositoryTriggersExceededException extends /*@__PURE__*/ MaximumRepositoryTriggersExceededException_base {
}
declare const MaximumRuleTemplatesAssociatedWithRepositoryException_base: S.Class<MaximumRuleTemplatesAssociatedWithRepositoryException, S.TaggedStruct<"MaximumRuleTemplatesAssociatedWithRepositoryException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaximumRuleTemplatesAssociatedWithRepositoryException extends /*@__PURE__*/ MaximumRuleTemplatesAssociatedWithRepositoryException_base {
}
declare const MergeOptionRequiredException_base: S.Class<MergeOptionRequiredException, S.TaggedStruct<"MergeOptionRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MergeOptionRequiredException extends /*@__PURE__*/ MergeOptionRequiredException_base {
}
declare const MultipleConflictResolutionEntriesException_base: S.Class<MultipleConflictResolutionEntriesException, S.TaggedStruct<"MultipleConflictResolutionEntriesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MultipleConflictResolutionEntriesException extends /*@__PURE__*/ MultipleConflictResolutionEntriesException_base {
}
declare const MultipleRepositoriesInPullRequestException_base: S.Class<MultipleRepositoriesInPullRequestException, S.TaggedStruct<"MultipleRepositoriesInPullRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MultipleRepositoriesInPullRequestException extends /*@__PURE__*/ MultipleRepositoriesInPullRequestException_base {
}
declare const NameLengthExceededException_base: S.Class<NameLengthExceededException, S.TaggedStruct<"NameLengthExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NameLengthExceededException extends /*@__PURE__*/ NameLengthExceededException_base {
}
declare const NoChangeException_base: S.Class<NoChangeException, S.TaggedStruct<"NoChangeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoChangeException extends /*@__PURE__*/ NoChangeException_base {
}
declare const NumberOfRulesExceededException_base: S.Class<NumberOfRulesExceededException, S.TaggedStruct<"NumberOfRulesExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NumberOfRulesExceededException extends /*@__PURE__*/ NumberOfRulesExceededException_base {
}
declare const NumberOfRuleTemplatesExceededException_base: S.Class<NumberOfRuleTemplatesExceededException, S.TaggedStruct<"NumberOfRuleTemplatesExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NumberOfRuleTemplatesExceededException extends /*@__PURE__*/ NumberOfRuleTemplatesExceededException_base {
}
declare const OperationNotAllowedException_base: S.Class<OperationNotAllowedException, S.TaggedStruct<"OperationNotAllowedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OperationNotAllowedException extends /*@__PURE__*/ OperationNotAllowedException_base {
}
declare const OverrideAlreadySetException_base: S.Class<OverrideAlreadySetException, S.TaggedStruct<"OverrideAlreadySetException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OverrideAlreadySetException extends /*@__PURE__*/ OverrideAlreadySetException_base {
}
declare const OverrideStatusRequiredException_base: S.Class<OverrideStatusRequiredException, S.TaggedStruct<"OverrideStatusRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OverrideStatusRequiredException extends /*@__PURE__*/ OverrideStatusRequiredException_base {
}
declare const ParentCommitDoesNotExistException_base: S.Class<ParentCommitDoesNotExistException, S.TaggedStruct<"ParentCommitDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ParentCommitDoesNotExistException extends /*@__PURE__*/ ParentCommitDoesNotExistException_base {
}
declare const ParentCommitIdOutdatedException_base: S.Class<ParentCommitIdOutdatedException, S.TaggedStruct<"ParentCommitIdOutdatedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ParentCommitIdOutdatedException extends /*@__PURE__*/ ParentCommitIdOutdatedException_base {
}
declare const ParentCommitIdRequiredException_base: S.Class<ParentCommitIdRequiredException, S.TaggedStruct<"ParentCommitIdRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ParentCommitIdRequiredException extends /*@__PURE__*/ ParentCommitIdRequiredException_base {
}
declare const PathDoesNotExistException_base: S.Class<PathDoesNotExistException, S.TaggedStruct<"PathDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PathDoesNotExistException extends /*@__PURE__*/ PathDoesNotExistException_base {
}
declare const PathRequiredException_base: S.Class<PathRequiredException, S.TaggedStruct<"PathRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PathRequiredException extends /*@__PURE__*/ PathRequiredException_base {
}
declare const PullRequestAlreadyClosedException_base: S.Class<PullRequestAlreadyClosedException, S.TaggedStruct<"PullRequestAlreadyClosedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PullRequestAlreadyClosedException extends /*@__PURE__*/ PullRequestAlreadyClosedException_base {
}
declare const PullRequestApprovalRulesNotSatisfiedException_base: S.Class<PullRequestApprovalRulesNotSatisfiedException, S.TaggedStruct<"PullRequestApprovalRulesNotSatisfiedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PullRequestApprovalRulesNotSatisfiedException extends /*@__PURE__*/ PullRequestApprovalRulesNotSatisfiedException_base {
}
declare const PullRequestCannotBeApprovedByAuthorException_base: S.Class<PullRequestCannotBeApprovedByAuthorException, S.TaggedStruct<"PullRequestCannotBeApprovedByAuthorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PullRequestCannotBeApprovedByAuthorException extends /*@__PURE__*/ PullRequestCannotBeApprovedByAuthorException_base {
}
declare const PullRequestDoesNotExistException_base: S.Class<PullRequestDoesNotExistException, S.TaggedStruct<"PullRequestDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PullRequestDoesNotExistException extends /*@__PURE__*/ PullRequestDoesNotExistException_base {
}
declare const PullRequestIdRequiredException_base: S.Class<PullRequestIdRequiredException, S.TaggedStruct<"PullRequestIdRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PullRequestIdRequiredException extends /*@__PURE__*/ PullRequestIdRequiredException_base {
}
declare const PullRequestStatusRequiredException_base: S.Class<PullRequestStatusRequiredException, S.TaggedStruct<"PullRequestStatusRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PullRequestStatusRequiredException extends /*@__PURE__*/ PullRequestStatusRequiredException_base {
}
declare const PutFileEntryConflictException_base: S.Class<PutFileEntryConflictException, S.TaggedStruct<"PutFileEntryConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PutFileEntryConflictException extends /*@__PURE__*/ PutFileEntryConflictException_base {
}
declare const ReactionLimitExceededException_base: S.Class<ReactionLimitExceededException, S.TaggedStruct<"ReactionLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ReactionLimitExceededException extends /*@__PURE__*/ ReactionLimitExceededException_base {
}
declare const ReactionValueRequiredException_base: S.Class<ReactionValueRequiredException, S.TaggedStruct<"ReactionValueRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ReactionValueRequiredException extends /*@__PURE__*/ ReactionValueRequiredException_base {
}
declare const ReferenceDoesNotExistException_base: S.Class<ReferenceDoesNotExistException, S.TaggedStruct<"ReferenceDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ReferenceDoesNotExistException extends /*@__PURE__*/ ReferenceDoesNotExistException_base {
}
declare const ReferenceNameRequiredException_base: S.Class<ReferenceNameRequiredException, S.TaggedStruct<"ReferenceNameRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ReferenceNameRequiredException extends /*@__PURE__*/ ReferenceNameRequiredException_base {
}
declare const ReferenceTypeNotSupportedException_base: S.Class<ReferenceTypeNotSupportedException, S.TaggedStruct<"ReferenceTypeNotSupportedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ReferenceTypeNotSupportedException extends /*@__PURE__*/ ReferenceTypeNotSupportedException_base {
}
declare const ReplacementContentRequiredException_base: S.Class<ReplacementContentRequiredException, S.TaggedStruct<"ReplacementContentRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ReplacementContentRequiredException extends /*@__PURE__*/ ReplacementContentRequiredException_base {
}
declare const ReplacementTypeRequiredException_base: S.Class<ReplacementTypeRequiredException, S.TaggedStruct<"ReplacementTypeRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ReplacementTypeRequiredException extends /*@__PURE__*/ ReplacementTypeRequiredException_base {
}
declare const RepositoryDoesNotExistException_base: S.Class<RepositoryDoesNotExistException, S.TaggedStruct<"RepositoryDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryDoesNotExistException extends /*@__PURE__*/ RepositoryDoesNotExistException_base {
}
declare const RepositoryLimitExceededException_base: S.Class<RepositoryLimitExceededException, S.TaggedStruct<"RepositoryLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryLimitExceededException extends /*@__PURE__*/ RepositoryLimitExceededException_base {
}
declare const RepositoryNameExistsException_base: S.Class<RepositoryNameExistsException, S.TaggedStruct<"RepositoryNameExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryNameExistsException extends /*@__PURE__*/ RepositoryNameExistsException_base {
}
declare const RepositoryNameRequiredException_base: S.Class<RepositoryNameRequiredException, S.TaggedStruct<"RepositoryNameRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryNameRequiredException extends /*@__PURE__*/ RepositoryNameRequiredException_base {
}
declare const RepositoryNamesRequiredException_base: S.Class<RepositoryNamesRequiredException, S.TaggedStruct<"RepositoryNamesRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryNamesRequiredException extends /*@__PURE__*/ RepositoryNamesRequiredException_base {
}
declare const RepositoryNotAssociatedWithPullRequestException_base: S.Class<RepositoryNotAssociatedWithPullRequestException, S.TaggedStruct<"RepositoryNotAssociatedWithPullRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryNotAssociatedWithPullRequestException extends /*@__PURE__*/ RepositoryNotAssociatedWithPullRequestException_base {
}
declare const RepositoryTriggerBranchNameListRequiredException_base: S.Class<RepositoryTriggerBranchNameListRequiredException, S.TaggedStruct<"RepositoryTriggerBranchNameListRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryTriggerBranchNameListRequiredException extends /*@__PURE__*/ RepositoryTriggerBranchNameListRequiredException_base {
}
declare const RepositoryTriggerDestinationArnRequiredException_base: S.Class<RepositoryTriggerDestinationArnRequiredException, S.TaggedStruct<"RepositoryTriggerDestinationArnRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryTriggerDestinationArnRequiredException extends /*@__PURE__*/ RepositoryTriggerDestinationArnRequiredException_base {
}
declare const RepositoryTriggerEventsListRequiredException_base: S.Class<RepositoryTriggerEventsListRequiredException, S.TaggedStruct<"RepositoryTriggerEventsListRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryTriggerEventsListRequiredException extends /*@__PURE__*/ RepositoryTriggerEventsListRequiredException_base {
}
declare const RepositoryTriggerNameRequiredException_base: S.Class<RepositoryTriggerNameRequiredException, S.TaggedStruct<"RepositoryTriggerNameRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryTriggerNameRequiredException extends /*@__PURE__*/ RepositoryTriggerNameRequiredException_base {
}
declare const RepositoryTriggersListRequiredException_base: S.Class<RepositoryTriggersListRequiredException, S.TaggedStruct<"RepositoryTriggersListRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryTriggersListRequiredException extends /*@__PURE__*/ RepositoryTriggersListRequiredException_base {
}
declare const ResourceArnRequiredException_base: S.Class<ResourceArnRequiredException, S.TaggedStruct<"ResourceArnRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceArnRequiredException extends /*@__PURE__*/ ResourceArnRequiredException_base {
}
declare const RestrictedSourceFileException_base: S.Class<RestrictedSourceFileException, S.TaggedStruct<"RestrictedSourceFileException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RestrictedSourceFileException extends /*@__PURE__*/ RestrictedSourceFileException_base {
}
declare const RevisionIdRequiredException_base: S.Class<RevisionIdRequiredException, S.TaggedStruct<"RevisionIdRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RevisionIdRequiredException extends /*@__PURE__*/ RevisionIdRequiredException_base {
}
declare const RevisionNotCurrentException_base: S.Class<RevisionNotCurrentException, S.TaggedStruct<"RevisionNotCurrentException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RevisionNotCurrentException extends /*@__PURE__*/ RevisionNotCurrentException_base {
}
declare const SameFileContentException_base: S.Class<SameFileContentException, S.TaggedStruct<"SameFileContentException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SameFileContentException extends /*@__PURE__*/ SameFileContentException_base {
}
declare const SamePathRequestException_base: S.Class<SamePathRequestException, S.TaggedStruct<"SamePathRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SamePathRequestException extends /*@__PURE__*/ SamePathRequestException_base {
}
declare const SourceAndDestinationAreSameException_base: S.Class<SourceAndDestinationAreSameException, S.TaggedStruct<"SourceAndDestinationAreSameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SourceAndDestinationAreSameException extends /*@__PURE__*/ SourceAndDestinationAreSameException_base {
}
declare const SourceFileOrContentRequiredException_base: S.Class<SourceFileOrContentRequiredException, S.TaggedStruct<"SourceFileOrContentRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SourceFileOrContentRequiredException extends /*@__PURE__*/ SourceFileOrContentRequiredException_base {
}
declare const TagKeysListRequiredException_base: S.Class<TagKeysListRequiredException, S.TaggedStruct<"TagKeysListRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TagKeysListRequiredException extends /*@__PURE__*/ TagKeysListRequiredException_base {
}
declare const TagPolicyException_base: S.Class<TagPolicyException, S.TaggedStruct<"TagPolicyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TagPolicyException extends /*@__PURE__*/ TagPolicyException_base {
}
declare const TagsMapRequiredException_base: S.Class<TagsMapRequiredException, S.TaggedStruct<"TagsMapRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TagsMapRequiredException extends /*@__PURE__*/ TagsMapRequiredException_base {
}
declare const TargetRequiredException_base: S.Class<TargetRequiredException, S.TaggedStruct<"TargetRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TargetRequiredException extends /*@__PURE__*/ TargetRequiredException_base {
}
declare const TargetsRequiredException_base: S.Class<TargetsRequiredException, S.TaggedStruct<"TargetsRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TargetsRequiredException extends /*@__PURE__*/ TargetsRequiredException_base {
}
declare const TipOfSourceReferenceIsDifferentException_base: S.Class<TipOfSourceReferenceIsDifferentException, S.TaggedStruct<"TipOfSourceReferenceIsDifferentException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TipOfSourceReferenceIsDifferentException extends /*@__PURE__*/ TipOfSourceReferenceIsDifferentException_base {
}
declare const TipsDivergenceExceededException_base: S.Class<TipsDivergenceExceededException, S.TaggedStruct<"TipsDivergenceExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TipsDivergenceExceededException extends /*@__PURE__*/ TipsDivergenceExceededException_base {
}
declare const TitleRequiredException_base: S.Class<TitleRequiredException, S.TaggedStruct<"TitleRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TitleRequiredException extends /*@__PURE__*/ TitleRequiredException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ApprovalRuleTemplateName = string;
export type RepositoryName = string;
export interface AssociateApprovalRuleTemplateWithRepositoryInput {
    approvalRuleTemplateName: string;
    repositoryName: string;
}
export declare const AssociateApprovalRuleTemplateWithRepositoryInput: S.Schema<AssociateApprovalRuleTemplateWithRepositoryInput>;
export interface AssociateApprovalRuleTemplateWithRepositoryResponse {
}
export declare const AssociateApprovalRuleTemplateWithRepositoryResponse: S.Schema<AssociateApprovalRuleTemplateWithRepositoryResponse>;
export type RepositoryNameList = string[];
export declare const RepositoryNameList: any;
export interface BatchAssociateApprovalRuleTemplateWithRepositoriesInput {
    approvalRuleTemplateName: string;
    repositoryNames: string[];
}
export declare const BatchAssociateApprovalRuleTemplateWithRepositoriesInput: S.Schema<BatchAssociateApprovalRuleTemplateWithRepositoriesInput>;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface BatchAssociateApprovalRuleTemplateWithRepositoriesError_ {
    repositoryName?: string;
    errorCode?: string;
    errorMessage?: string;
}
export declare const BatchAssociateApprovalRuleTemplateWithRepositoriesError_: S.Schema<BatchAssociateApprovalRuleTemplateWithRepositoriesError_>;
export type BatchAssociateApprovalRuleTemplateWithRepositoriesErrorsList = BatchAssociateApprovalRuleTemplateWithRepositoriesError_[];
export declare const BatchAssociateApprovalRuleTemplateWithRepositoriesErrorsList: any;
export interface BatchAssociateApprovalRuleTemplateWithRepositoriesOutput {
    associatedRepositoryNames: string[];
    errors: BatchAssociateApprovalRuleTemplateWithRepositoriesError_[];
}
export declare const BatchAssociateApprovalRuleTemplateWithRepositoriesOutput: S.Schema<BatchAssociateApprovalRuleTemplateWithRepositoriesOutput>;
export type CommitName = string;
export type MergeOptionTypeEnum = "FAST_FORWARD_MERGE" | "SQUASH_MERGE" | "THREE_WAY_MERGE" | (string & {});
export declare const MergeOptionTypeEnum: any;
export type MaxResults = number;
export type Path = string;
export type FilePaths = string[];
export declare const FilePaths: any;
export type ConflictDetailLevelTypeEnum = "FILE_LEVEL" | "LINE_LEVEL" | (string & {});
export declare const ConflictDetailLevelTypeEnum: any;
export type ConflictResolutionStrategyTypeEnum = "NONE" | "ACCEPT_SOURCE" | "ACCEPT_DESTINATION" | "AUTOMERGE" | (string & {});
export declare const ConflictResolutionStrategyTypeEnum: any;
export type NextToken = string;
export interface BatchDescribeMergeConflictsInput {
    repositoryName: string;
    destinationCommitSpecifier: string;
    sourceCommitSpecifier: string;
    mergeOption: MergeOptionTypeEnum;
    maxMergeHunks?: number;
    maxConflictFiles?: number;
    filePaths?: string[];
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    nextToken?: string;
}
export declare const BatchDescribeMergeConflictsInput: S.Schema<BatchDescribeMergeConflictsInput>;
export type FileSize = number;
export interface FileSizes {
    source?: number;
    destination?: number;
    base?: number;
}
export declare const FileSizes: S.Schema<FileSizes>;
export type FileModeTypeEnum = "EXECUTABLE" | "NORMAL" | "SYMLINK" | (string & {});
export declare const FileModeTypeEnum: any;
export interface FileModes {
    source?: FileModeTypeEnum;
    destination?: FileModeTypeEnum;
    base?: FileModeTypeEnum;
}
export declare const FileModes: S.Schema<FileModes>;
export type ObjectTypeEnum = "FILE" | "DIRECTORY" | "GIT_LINK" | "SYMBOLIC_LINK" | (string & {});
export declare const ObjectTypeEnum: any;
export interface ObjectTypes {
    source?: ObjectTypeEnum;
    destination?: ObjectTypeEnum;
    base?: ObjectTypeEnum;
}
export declare const ObjectTypes: S.Schema<ObjectTypes>;
export type NumberOfConflicts = number;
export type CapitalBoolean = boolean;
export interface IsBinaryFile {
    source?: boolean;
    destination?: boolean;
    base?: boolean;
}
export declare const IsBinaryFile: S.Schema<IsBinaryFile>;
export type IsContentConflict = boolean;
export type IsFileModeConflict = boolean;
export type IsObjectTypeConflict = boolean;
export type ChangeTypeEnum = "A" | "M" | "D" | (string & {});
export declare const ChangeTypeEnum: any;
export interface MergeOperations {
    source?: ChangeTypeEnum;
    destination?: ChangeTypeEnum;
}
export declare const MergeOperations: S.Schema<MergeOperations>;
export interface ConflictMetadata {
    filePath?: string;
    fileSizes?: FileSizes;
    fileModes?: FileModes;
    objectTypes?: ObjectTypes;
    numberOfConflicts?: number;
    isBinaryFile?: IsBinaryFile;
    contentConflict?: boolean;
    fileModeConflict?: boolean;
    objectTypeConflict?: boolean;
    mergeOperations?: MergeOperations;
}
export declare const ConflictMetadata: S.Schema<ConflictMetadata>;
export type IsHunkConflict = boolean;
export type LineNumber = number;
export type HunkContent = string;
export interface MergeHunkDetail {
    startLine?: number;
    endLine?: number;
    hunkContent?: string;
}
export declare const MergeHunkDetail: S.Schema<MergeHunkDetail>;
export interface MergeHunk {
    isConflict?: boolean;
    source?: MergeHunkDetail;
    destination?: MergeHunkDetail;
    base?: MergeHunkDetail;
}
export declare const MergeHunk: S.Schema<MergeHunk>;
export type MergeHunks = MergeHunk[];
export declare const MergeHunks: any;
export interface Conflict {
    conflictMetadata?: ConflictMetadata;
    mergeHunks?: MergeHunk[];
}
export declare const Conflict: S.Schema<Conflict>;
export type Conflicts = Conflict[];
export declare const Conflicts: any;
export type ExceptionName = string;
export type Message = string;
export interface BatchDescribeMergeConflictsError_ {
    filePath: string;
    exceptionName: string;
    message: string;
}
export declare const BatchDescribeMergeConflictsError_: S.Schema<BatchDescribeMergeConflictsError_>;
export type BatchDescribeMergeConflictsErrors = BatchDescribeMergeConflictsError_[];
export declare const BatchDescribeMergeConflictsErrors: any;
export type ObjectId = string;
export interface BatchDescribeMergeConflictsOutput {
    conflicts: Conflict[];
    nextToken?: string;
    errors?: BatchDescribeMergeConflictsError_[];
    destinationCommitId: string;
    sourceCommitId: string;
    baseCommitId?: string;
}
export declare const BatchDescribeMergeConflictsOutput: S.Schema<BatchDescribeMergeConflictsOutput>;
export interface BatchDisassociateApprovalRuleTemplateFromRepositoriesInput {
    approvalRuleTemplateName: string;
    repositoryNames: string[];
}
export declare const BatchDisassociateApprovalRuleTemplateFromRepositoriesInput: S.Schema<BatchDisassociateApprovalRuleTemplateFromRepositoriesInput>;
export interface BatchDisassociateApprovalRuleTemplateFromRepositoriesError_ {
    repositoryName?: string;
    errorCode?: string;
    errorMessage?: string;
}
export declare const BatchDisassociateApprovalRuleTemplateFromRepositoriesError_: S.Schema<BatchDisassociateApprovalRuleTemplateFromRepositoriesError_>;
export type BatchDisassociateApprovalRuleTemplateFromRepositoriesErrorsList = BatchDisassociateApprovalRuleTemplateFromRepositoriesError_[];
export declare const BatchDisassociateApprovalRuleTemplateFromRepositoriesErrorsList: any;
export interface BatchDisassociateApprovalRuleTemplateFromRepositoriesOutput {
    disassociatedRepositoryNames: string[];
    errors: BatchDisassociateApprovalRuleTemplateFromRepositoriesError_[];
}
export declare const BatchDisassociateApprovalRuleTemplateFromRepositoriesOutput: S.Schema<BatchDisassociateApprovalRuleTemplateFromRepositoriesOutput>;
export type CommitIdsInputList = string[];
export declare const CommitIdsInputList: any;
export interface BatchGetCommitsInput {
    commitIds: string[];
    repositoryName: string;
}
export declare const BatchGetCommitsInput: S.Schema<BatchGetCommitsInput>;
export type ParentList = string[];
export declare const ParentList: any;
export type Name = string;
export type Email = string;
export interface UserInfo {
    name?: string;
    email?: string;
    date?: string;
}
export declare const UserInfo: S.Schema<UserInfo>;
export type AdditionalData = string;
export interface Commit {
    commitId?: string;
    treeId?: string;
    parents?: string[];
    message?: string;
    author?: UserInfo;
    committer?: UserInfo;
    additionalData?: string;
}
export declare const Commit: S.Schema<Commit>;
export type CommitObjectsList = Commit[];
export declare const CommitObjectsList: any;
export interface BatchGetCommitsError_ {
    commitId?: string;
    errorCode?: string;
    errorMessage?: string;
}
export declare const BatchGetCommitsError_: S.Schema<BatchGetCommitsError_>;
export type BatchGetCommitsErrorsList = BatchGetCommitsError_[];
export declare const BatchGetCommitsErrorsList: any;
export interface BatchGetCommitsOutput {
    commits?: Commit[];
    errors?: BatchGetCommitsError_[];
}
export declare const BatchGetCommitsOutput: S.Schema<BatchGetCommitsOutput>;
export interface BatchGetRepositoriesInput {
    repositoryNames: string[];
}
export declare const BatchGetRepositoriesInput: S.Schema<BatchGetRepositoriesInput>;
export type AccountId = string;
export type RepositoryId = string;
export type RepositoryDescription = string;
export type BranchName = string;
export type LastModifiedDate = Date;
export type CreationDate = Date;
export type CloneUrlHttp = string;
export type CloneUrlSsh = string;
export type Arn = string;
export type KmsKeyId = string;
export interface RepositoryMetadata {
    accountId?: string;
    repositoryId?: string;
    repositoryName?: string;
    repositoryDescription?: string;
    defaultBranch?: string;
    lastModifiedDate?: Date;
    creationDate?: Date;
    cloneUrlHttp?: string;
    cloneUrlSsh?: string;
    Arn?: string;
    kmsKeyId?: string;
}
export declare const RepositoryMetadata: S.Schema<RepositoryMetadata>;
export type RepositoryMetadataList = RepositoryMetadata[];
export declare const RepositoryMetadataList: any;
export type RepositoryNotFoundList = string[];
export declare const RepositoryNotFoundList: any;
export type BatchGetRepositoriesErrorCodeEnum = "EncryptionIntegrityChecksFailedException" | "EncryptionKeyAccessDeniedException" | "EncryptionKeyDisabledException" | "EncryptionKeyNotFoundException" | "EncryptionKeyUnavailableException" | "RepositoryDoesNotExistException" | (string & {});
export declare const BatchGetRepositoriesErrorCodeEnum: any;
export interface BatchGetRepositoriesError_ {
    repositoryId?: string;
    repositoryName?: string;
    errorCode?: BatchGetRepositoriesErrorCodeEnum;
    errorMessage?: string;
}
export declare const BatchGetRepositoriesError_: S.Schema<BatchGetRepositoriesError_>;
export type BatchGetRepositoriesErrorsList = BatchGetRepositoriesError_[];
export declare const BatchGetRepositoriesErrorsList: any;
export interface BatchGetRepositoriesOutput {
    repositories?: RepositoryMetadata[];
    repositoriesNotFound?: string[];
    errors?: BatchGetRepositoriesError_[];
}
export declare const BatchGetRepositoriesOutput: S.Schema<BatchGetRepositoriesOutput>;
export type ApprovalRuleTemplateContent = string;
export type ApprovalRuleTemplateDescription = string;
export interface CreateApprovalRuleTemplateInput {
    approvalRuleTemplateName: string;
    approvalRuleTemplateContent: string;
    approvalRuleTemplateDescription?: string;
}
export declare const CreateApprovalRuleTemplateInput: S.Schema<CreateApprovalRuleTemplateInput>;
export type ApprovalRuleTemplateId = string;
export type RuleContentSha256 = string;
export interface ApprovalRuleTemplate {
    approvalRuleTemplateId?: string;
    approvalRuleTemplateName?: string;
    approvalRuleTemplateDescription?: string;
    approvalRuleTemplateContent?: string;
    ruleContentSha256?: string;
    lastModifiedDate?: Date;
    creationDate?: Date;
    lastModifiedUser?: string;
}
export declare const ApprovalRuleTemplate: S.Schema<ApprovalRuleTemplate>;
export interface CreateApprovalRuleTemplateOutput {
    approvalRuleTemplate: ApprovalRuleTemplate;
}
export declare const CreateApprovalRuleTemplateOutput: S.Schema<CreateApprovalRuleTemplateOutput>;
export type CommitId = string;
export interface CreateBranchInput {
    repositoryName: string;
    branchName: string;
    commitId: string;
}
export declare const CreateBranchInput: S.Schema<CreateBranchInput>;
export interface CreateBranchResponse {
}
export declare const CreateBranchResponse: S.Schema<CreateBranchResponse>;
export type KeepEmptyFolders = boolean;
export type FileContent = Uint8Array;
export type IsMove = boolean;
export interface SourceFileSpecifier {
    filePath: string;
    isMove?: boolean;
}
export declare const SourceFileSpecifier: S.Schema<SourceFileSpecifier>;
export interface PutFileEntry {
    filePath: string;
    fileMode?: FileModeTypeEnum;
    fileContent?: Uint8Array;
    sourceFile?: SourceFileSpecifier;
}
export declare const PutFileEntry: S.Schema<PutFileEntry>;
export type PutFileEntries = PutFileEntry[];
export declare const PutFileEntries: any;
export interface DeleteFileEntry {
    filePath: string;
}
export declare const DeleteFileEntry: S.Schema<DeleteFileEntry>;
export type DeleteFileEntries = DeleteFileEntry[];
export declare const DeleteFileEntries: any;
export interface SetFileModeEntry {
    filePath: string;
    fileMode: FileModeTypeEnum;
}
export declare const SetFileModeEntry: S.Schema<SetFileModeEntry>;
export type SetFileModeEntries = SetFileModeEntry[];
export declare const SetFileModeEntries: any;
export interface CreateCommitInput {
    repositoryName: string;
    branchName: string;
    parentCommitId?: string;
    authorName?: string;
    email?: string;
    commitMessage?: string;
    keepEmptyFolders?: boolean;
    putFiles?: PutFileEntry[];
    deleteFiles?: DeleteFileEntry[];
    setFileModes?: SetFileModeEntry[];
}
export declare const CreateCommitInput: S.Schema<CreateCommitInput>;
export interface FileMetadata {
    absolutePath?: string;
    blobId?: string;
    fileMode?: FileModeTypeEnum;
}
export declare const FileMetadata: S.Schema<FileMetadata>;
export type FilesMetadata = FileMetadata[];
export declare const FilesMetadata: any;
export interface CreateCommitOutput {
    commitId?: string;
    treeId?: string;
    filesAdded?: FileMetadata[];
    filesUpdated?: FileMetadata[];
    filesDeleted?: FileMetadata[];
}
export declare const CreateCommitOutput: S.Schema<CreateCommitOutput>;
export type Title = string;
export type Description = string;
export type ReferenceName = string;
export interface Target {
    repositoryName: string;
    sourceReference: string;
    destinationReference?: string;
}
export declare const Target: S.Schema<Target>;
export type TargetList = Target[];
export declare const TargetList: any;
export type ClientRequestToken = string;
export interface CreatePullRequestInput {
    title: string;
    description?: string;
    targets: Target[];
    clientRequestToken?: string;
}
export declare const CreatePullRequestInput: S.Schema<CreatePullRequestInput>;
export type PullRequestId = string;
export type PullRequestStatusEnum = "OPEN" | "CLOSED" | (string & {});
export declare const PullRequestStatusEnum: any;
export type IsMerged = boolean;
export interface MergeMetadata {
    isMerged?: boolean;
    mergedBy?: string;
    mergeCommitId?: string;
    mergeOption?: MergeOptionTypeEnum;
}
export declare const MergeMetadata: S.Schema<MergeMetadata>;
export interface PullRequestTarget {
    repositoryName?: string;
    sourceReference?: string;
    destinationReference?: string;
    destinationCommit?: string;
    sourceCommit?: string;
    mergeBase?: string;
    mergeMetadata?: MergeMetadata;
}
export declare const PullRequestTarget: S.Schema<PullRequestTarget>;
export type PullRequestTargetList = PullRequestTarget[];
export declare const PullRequestTargetList: any;
export type RevisionId = string;
export type ApprovalRuleId = string;
export type ApprovalRuleName = string;
export type ApprovalRuleContent = string;
export interface OriginApprovalRuleTemplate {
    approvalRuleTemplateId?: string;
    approvalRuleTemplateName?: string;
}
export declare const OriginApprovalRuleTemplate: S.Schema<OriginApprovalRuleTemplate>;
export interface ApprovalRule {
    approvalRuleId?: string;
    approvalRuleName?: string;
    approvalRuleContent?: string;
    ruleContentSha256?: string;
    lastModifiedDate?: Date;
    creationDate?: Date;
    lastModifiedUser?: string;
    originApprovalRuleTemplate?: OriginApprovalRuleTemplate;
}
export declare const ApprovalRule: S.Schema<ApprovalRule>;
export type ApprovalRulesList = ApprovalRule[];
export declare const ApprovalRulesList: any;
export interface PullRequest {
    pullRequestId?: string;
    title?: string;
    description?: string;
    lastActivityDate?: Date;
    creationDate?: Date;
    pullRequestStatus?: PullRequestStatusEnum;
    authorArn?: string;
    pullRequestTargets?: PullRequestTarget[];
    clientRequestToken?: string;
    revisionId?: string;
    approvalRules?: ApprovalRule[];
}
export declare const PullRequest: S.Schema<PullRequest>;
export interface CreatePullRequestOutput {
    pullRequest: PullRequest;
}
export declare const CreatePullRequestOutput: S.Schema<CreatePullRequestOutput>;
export interface CreatePullRequestApprovalRuleInput {
    pullRequestId: string;
    approvalRuleName: string;
    approvalRuleContent: string;
}
export declare const CreatePullRequestApprovalRuleInput: S.Schema<CreatePullRequestApprovalRuleInput>;
export interface CreatePullRequestApprovalRuleOutput {
    approvalRule: ApprovalRule;
}
export declare const CreatePullRequestApprovalRuleOutput: S.Schema<CreatePullRequestApprovalRuleOutput>;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export interface CreateRepositoryInput {
    repositoryName: string;
    repositoryDescription?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    kmsKeyId?: string;
}
export declare const CreateRepositoryInput: S.Schema<CreateRepositoryInput>;
export interface CreateRepositoryOutput {
    repositoryMetadata?: RepositoryMetadata;
}
export declare const CreateRepositoryOutput: S.Schema<CreateRepositoryOutput>;
export type ReplacementTypeEnum = "KEEP_BASE" | "KEEP_SOURCE" | "KEEP_DESTINATION" | "USE_NEW_CONTENT" | (string & {});
export declare const ReplacementTypeEnum: any;
export interface ReplaceContentEntry {
    filePath: string;
    replacementType: ReplacementTypeEnum;
    content?: Uint8Array;
    fileMode?: FileModeTypeEnum;
}
export declare const ReplaceContentEntry: S.Schema<ReplaceContentEntry>;
export type ReplaceContentEntries = ReplaceContentEntry[];
export declare const ReplaceContentEntries: any;
export interface ConflictResolution {
    replaceContents?: ReplaceContentEntry[];
    deleteFiles?: DeleteFileEntry[];
    setFileModes?: SetFileModeEntry[];
}
export declare const ConflictResolution: S.Schema<ConflictResolution>;
export interface CreateUnreferencedMergeCommitInput {
    repositoryName: string;
    sourceCommitSpecifier: string;
    destinationCommitSpecifier: string;
    mergeOption: MergeOptionTypeEnum;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    authorName?: string;
    email?: string;
    commitMessage?: string;
    keepEmptyFolders?: boolean;
    conflictResolution?: ConflictResolution;
}
export declare const CreateUnreferencedMergeCommitInput: S.Schema<CreateUnreferencedMergeCommitInput>;
export interface CreateUnreferencedMergeCommitOutput {
    commitId?: string;
    treeId?: string;
}
export declare const CreateUnreferencedMergeCommitOutput: S.Schema<CreateUnreferencedMergeCommitOutput>;
export interface DeleteApprovalRuleTemplateInput {
    approvalRuleTemplateName: string;
}
export declare const DeleteApprovalRuleTemplateInput: S.Schema<DeleteApprovalRuleTemplateInput>;
export interface DeleteApprovalRuleTemplateOutput {
    approvalRuleTemplateId: string;
}
export declare const DeleteApprovalRuleTemplateOutput: S.Schema<DeleteApprovalRuleTemplateOutput>;
export interface DeleteBranchInput {
    repositoryName: string;
    branchName: string;
}
export declare const DeleteBranchInput: S.Schema<DeleteBranchInput>;
export interface BranchInfo {
    branchName?: string;
    commitId?: string;
}
export declare const BranchInfo: S.Schema<BranchInfo>;
export interface DeleteBranchOutput {
    deletedBranch?: BranchInfo;
}
export declare const DeleteBranchOutput: S.Schema<DeleteBranchOutput>;
export type CommentId = string;
export interface DeleteCommentContentInput {
    commentId: string;
}
export declare const DeleteCommentContentInput: S.Schema<DeleteCommentContentInput>;
export type Content = string;
export type IsCommentDeleted = boolean;
export type ReactionValue = string;
export type CallerReactions = string[];
export declare const CallerReactions: any;
export type Count = number;
export type ReactionCountsMap = {
    [key: string]: number | undefined;
};
export declare const ReactionCountsMap: any;
export interface Comment {
    commentId?: string;
    content?: string;
    inReplyTo?: string;
    creationDate?: Date;
    lastModifiedDate?: Date;
    authorArn?: string;
    deleted?: boolean;
    clientRequestToken?: string;
    callerReactions?: string[];
    reactionCounts?: {
        [key: string]: number | undefined;
    };
}
export declare const Comment: S.Schema<Comment>;
export interface DeleteCommentContentOutput {
    comment?: Comment;
}
export declare const DeleteCommentContentOutput: S.Schema<DeleteCommentContentOutput>;
export interface DeleteFileInput {
    repositoryName: string;
    branchName: string;
    filePath: string;
    parentCommitId: string;
    keepEmptyFolders?: boolean;
    commitMessage?: string;
    name?: string;
    email?: string;
}
export declare const DeleteFileInput: S.Schema<DeleteFileInput>;
export interface DeleteFileOutput {
    commitId: string;
    blobId: string;
    treeId: string;
    filePath: string;
}
export declare const DeleteFileOutput: S.Schema<DeleteFileOutput>;
export interface DeletePullRequestApprovalRuleInput {
    pullRequestId: string;
    approvalRuleName: string;
}
export declare const DeletePullRequestApprovalRuleInput: S.Schema<DeletePullRequestApprovalRuleInput>;
export interface DeletePullRequestApprovalRuleOutput {
    approvalRuleId: string;
}
export declare const DeletePullRequestApprovalRuleOutput: S.Schema<DeletePullRequestApprovalRuleOutput>;
export interface DeleteRepositoryInput {
    repositoryName: string;
}
export declare const DeleteRepositoryInput: S.Schema<DeleteRepositoryInput>;
export interface DeleteRepositoryOutput {
    repositoryId?: string;
}
export declare const DeleteRepositoryOutput: S.Schema<DeleteRepositoryOutput>;
export interface DescribeMergeConflictsInput {
    repositoryName: string;
    destinationCommitSpecifier: string;
    sourceCommitSpecifier: string;
    mergeOption: MergeOptionTypeEnum;
    maxMergeHunks?: number;
    filePath: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    nextToken?: string;
}
export declare const DescribeMergeConflictsInput: S.Schema<DescribeMergeConflictsInput>;
export interface DescribeMergeConflictsOutput {
    conflictMetadata: ConflictMetadata;
    mergeHunks: MergeHunk[];
    nextToken?: string;
    destinationCommitId: string;
    sourceCommitId: string;
    baseCommitId?: string;
}
export declare const DescribeMergeConflictsOutput: S.Schema<DescribeMergeConflictsOutput>;
export type PullRequestEventType = "PULL_REQUEST_CREATED" | "PULL_REQUEST_STATUS_CHANGED" | "PULL_REQUEST_SOURCE_REFERENCE_UPDATED" | "PULL_REQUEST_MERGE_STATE_CHANGED" | "PULL_REQUEST_APPROVAL_RULE_CREATED" | "PULL_REQUEST_APPROVAL_RULE_UPDATED" | "PULL_REQUEST_APPROVAL_RULE_DELETED" | "PULL_REQUEST_APPROVAL_RULE_OVERRIDDEN" | "PULL_REQUEST_APPROVAL_STATE_CHANGED" | (string & {});
export declare const PullRequestEventType: any;
export interface DescribePullRequestEventsInput {
    pullRequestId: string;
    pullRequestEventType?: PullRequestEventType;
    actorArn?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const DescribePullRequestEventsInput: S.Schema<DescribePullRequestEventsInput>;
export type EventDate = Date;
export interface PullRequestCreatedEventMetadata {
    repositoryName?: string;
    sourceCommitId?: string;
    destinationCommitId?: string;
    mergeBase?: string;
}
export declare const PullRequestCreatedEventMetadata: S.Schema<PullRequestCreatedEventMetadata>;
export interface PullRequestStatusChangedEventMetadata {
    pullRequestStatus?: PullRequestStatusEnum;
}
export declare const PullRequestStatusChangedEventMetadata: S.Schema<PullRequestStatusChangedEventMetadata>;
export interface PullRequestSourceReferenceUpdatedEventMetadata {
    repositoryName?: string;
    beforeCommitId?: string;
    afterCommitId?: string;
    mergeBase?: string;
}
export declare const PullRequestSourceReferenceUpdatedEventMetadata: S.Schema<PullRequestSourceReferenceUpdatedEventMetadata>;
export interface PullRequestMergedStateChangedEventMetadata {
    repositoryName?: string;
    destinationReference?: string;
    mergeMetadata?: MergeMetadata;
}
export declare const PullRequestMergedStateChangedEventMetadata: S.Schema<PullRequestMergedStateChangedEventMetadata>;
export interface ApprovalRuleEventMetadata {
    approvalRuleName?: string;
    approvalRuleId?: string;
    approvalRuleContent?: string;
}
export declare const ApprovalRuleEventMetadata: S.Schema<ApprovalRuleEventMetadata>;
export type ApprovalState = "APPROVE" | "REVOKE" | (string & {});
export declare const ApprovalState: any;
export interface ApprovalStateChangedEventMetadata {
    revisionId?: string;
    approvalStatus?: ApprovalState;
}
export declare const ApprovalStateChangedEventMetadata: S.Schema<ApprovalStateChangedEventMetadata>;
export type OverrideStatus = "OVERRIDE" | "REVOKE" | (string & {});
export declare const OverrideStatus: any;
export interface ApprovalRuleOverriddenEventMetadata {
    revisionId?: string;
    overrideStatus?: OverrideStatus;
}
export declare const ApprovalRuleOverriddenEventMetadata: S.Schema<ApprovalRuleOverriddenEventMetadata>;
export interface PullRequestEvent {
    pullRequestId?: string;
    eventDate?: Date;
    pullRequestEventType?: PullRequestEventType;
    actorArn?: string;
    pullRequestCreatedEventMetadata?: PullRequestCreatedEventMetadata;
    pullRequestStatusChangedEventMetadata?: PullRequestStatusChangedEventMetadata;
    pullRequestSourceReferenceUpdatedEventMetadata?: PullRequestSourceReferenceUpdatedEventMetadata;
    pullRequestMergedStateChangedEventMetadata?: PullRequestMergedStateChangedEventMetadata;
    approvalRuleEventMetadata?: ApprovalRuleEventMetadata;
    approvalStateChangedEventMetadata?: ApprovalStateChangedEventMetadata;
    approvalRuleOverriddenEventMetadata?: ApprovalRuleOverriddenEventMetadata;
}
export declare const PullRequestEvent: S.Schema<PullRequestEvent>;
export type PullRequestEventList = PullRequestEvent[];
export declare const PullRequestEventList: any;
export interface DescribePullRequestEventsOutput {
    pullRequestEvents: PullRequestEvent[];
    nextToken?: string;
}
export declare const DescribePullRequestEventsOutput: S.Schema<DescribePullRequestEventsOutput>;
export interface DisassociateApprovalRuleTemplateFromRepositoryInput {
    approvalRuleTemplateName: string;
    repositoryName: string;
}
export declare const DisassociateApprovalRuleTemplateFromRepositoryInput: S.Schema<DisassociateApprovalRuleTemplateFromRepositoryInput>;
export interface DisassociateApprovalRuleTemplateFromRepositoryResponse {
}
export declare const DisassociateApprovalRuleTemplateFromRepositoryResponse: S.Schema<DisassociateApprovalRuleTemplateFromRepositoryResponse>;
export interface EvaluatePullRequestApprovalRulesInput {
    pullRequestId: string;
    revisionId: string;
}
export declare const EvaluatePullRequestApprovalRulesInput: S.Schema<EvaluatePullRequestApprovalRulesInput>;
export type Approved = boolean;
export type Overridden = boolean;
export type ApprovalRulesSatisfiedList = string[];
export declare const ApprovalRulesSatisfiedList: any;
export type ApprovalRulesNotSatisfiedList = string[];
export declare const ApprovalRulesNotSatisfiedList: any;
export interface Evaluation {
    approved?: boolean;
    overridden?: boolean;
    approvalRulesSatisfied?: string[];
    approvalRulesNotSatisfied?: string[];
}
export declare const Evaluation: S.Schema<Evaluation>;
export interface EvaluatePullRequestApprovalRulesOutput {
    evaluation: Evaluation;
}
export declare const EvaluatePullRequestApprovalRulesOutput: S.Schema<EvaluatePullRequestApprovalRulesOutput>;
export interface GetApprovalRuleTemplateInput {
    approvalRuleTemplateName: string;
}
export declare const GetApprovalRuleTemplateInput: S.Schema<GetApprovalRuleTemplateInput>;
export interface GetApprovalRuleTemplateOutput {
    approvalRuleTemplate: ApprovalRuleTemplate;
}
export declare const GetApprovalRuleTemplateOutput: S.Schema<GetApprovalRuleTemplateOutput>;
export interface GetBlobInput {
    repositoryName: string;
    blobId: string;
}
export declare const GetBlobInput: S.Schema<GetBlobInput>;
export interface GetBlobOutput {
    content: Uint8Array;
}
export declare const GetBlobOutput: S.Schema<GetBlobOutput>;
export type DiffContext = number;
export type IgnoreWhiteSpaces = boolean;
export type Limit = number;
export interface GetBlobDifferencesInput {
    repositoryName: string;
    afterBlobId: string;
    beforeBlobId?: string;
    contextLines?: number;
    ignoreWhitespace?: boolean;
    MaxResults?: number;
    NextToken?: string;
}
export declare const GetBlobDifferencesInput: S.Schema<GetBlobDifferencesInput>;
export type DiffChangeType = "CONTEXT" | "ADD" | "DELETE" | (string & {});
export declare const DiffChangeType: any;
export type LineContent = string;
export interface DiffChange {
    type?: DiffChangeType;
    beforeLineNumber?: number;
    afterLineNumber?: number;
    content?: string;
}
export declare const DiffChange: S.Schema<DiffChange>;
export type DiffChangeList = DiffChange[];
export declare const DiffChangeList: any;
export interface DiffHunk {
    beforeStartLine?: number;
    beforeLineCount?: number;
    afterStartLine?: number;
    afterLineCount?: number;
    changes?: DiffChange[];
}
export declare const DiffHunk: S.Schema<DiffHunk>;
export type DiffHunkList = DiffHunk[];
export declare const DiffHunkList: any;
export type ObjectSize = number;
export interface GetBlobDifferencesOutput {
    hunks: DiffHunk[];
    isBinary: boolean;
    beforeBlobSize?: number;
    afterBlobSize: number;
    NextToken?: string;
}
export declare const GetBlobDifferencesOutput: S.Schema<GetBlobDifferencesOutput>;
export interface GetBranchInput {
    repositoryName?: string;
    branchName?: string;
}
export declare const GetBranchInput: S.Schema<GetBranchInput>;
export interface GetBranchOutput {
    branch?: BranchInfo;
}
export declare const GetBranchOutput: S.Schema<GetBranchOutput>;
export interface GetCommentInput {
    commentId: string;
}
export declare const GetCommentInput: S.Schema<GetCommentInput>;
export interface GetCommentOutput {
    comment?: Comment;
}
export declare const GetCommentOutput: S.Schema<GetCommentOutput>;
export interface GetCommentReactionsInput {
    commentId: string;
    reactionUserArn?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetCommentReactionsInput: S.Schema<GetCommentReactionsInput>;
export type ReactionEmoji = string;
export type ReactionShortCode = string;
export type ReactionUnicode = string;
export interface ReactionValueFormats {
    emoji?: string;
    shortCode?: string;
    unicode?: string;
}
export declare const ReactionValueFormats: S.Schema<ReactionValueFormats>;
export type ReactionUsersList = string[];
export declare const ReactionUsersList: any;
export interface ReactionForComment {
    reaction?: ReactionValueFormats;
    reactionUsers?: string[];
    reactionsFromDeletedUsersCount?: number;
}
export declare const ReactionForComment: S.Schema<ReactionForComment>;
export type ReactionsForCommentList = ReactionForComment[];
export declare const ReactionsForCommentList: any;
export interface GetCommentReactionsOutput {
    reactionsForComment: ReactionForComment[];
    nextToken?: string;
}
export declare const GetCommentReactionsOutput: S.Schema<GetCommentReactionsOutput>;
export interface GetCommentsForComparedCommitInput {
    repositoryName: string;
    beforeCommitId?: string;
    afterCommitId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetCommentsForComparedCommitInput: S.Schema<GetCommentsForComparedCommitInput>;
export type Position = number;
export type RelativeFileVersionEnum = "BEFORE" | "AFTER" | (string & {});
export declare const RelativeFileVersionEnum: any;
export interface Location {
    filePath?: string;
    filePosition?: number;
    relativeFileVersion?: RelativeFileVersionEnum;
}
export declare const Location: S.Schema<Location>;
export type Comments = Comment[];
export declare const Comments: any;
export interface CommentsForComparedCommit {
    repositoryName?: string;
    beforeCommitId?: string;
    afterCommitId?: string;
    beforeBlobId?: string;
    afterBlobId?: string;
    location?: Location;
    comments?: Comment[];
}
export declare const CommentsForComparedCommit: S.Schema<CommentsForComparedCommit>;
export type CommentsForComparedCommitData = CommentsForComparedCommit[];
export declare const CommentsForComparedCommitData: any;
export interface GetCommentsForComparedCommitOutput {
    commentsForComparedCommitData?: CommentsForComparedCommit[];
    nextToken?: string;
}
export declare const GetCommentsForComparedCommitOutput: S.Schema<GetCommentsForComparedCommitOutput>;
export interface GetCommentsForPullRequestInput {
    pullRequestId: string;
    repositoryName?: string;
    beforeCommitId?: string;
    afterCommitId?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetCommentsForPullRequestInput: S.Schema<GetCommentsForPullRequestInput>;
export interface CommentsForPullRequest {
    pullRequestId?: string;
    repositoryName?: string;
    beforeCommitId?: string;
    afterCommitId?: string;
    beforeBlobId?: string;
    afterBlobId?: string;
    location?: Location;
    comments?: Comment[];
}
export declare const CommentsForPullRequest: S.Schema<CommentsForPullRequest>;
export type CommentsForPullRequestData = CommentsForPullRequest[];
export declare const CommentsForPullRequestData: any;
export interface GetCommentsForPullRequestOutput {
    commentsForPullRequestData?: CommentsForPullRequest[];
    nextToken?: string;
}
export declare const GetCommentsForPullRequestOutput: S.Schema<GetCommentsForPullRequestOutput>;
export interface GetCommitInput {
    repositoryName: string;
    commitId: string;
}
export declare const GetCommitInput: S.Schema<GetCommitInput>;
export interface GetCommitOutput {
    commit: Commit;
}
export declare const GetCommitOutput: S.Schema<GetCommitOutput>;
export interface GetDifferencesInput {
    repositoryName: string;
    beforeCommitSpecifier?: string;
    afterCommitSpecifier: string;
    beforePath?: string;
    afterPath?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const GetDifferencesInput: S.Schema<GetDifferencesInput>;
export type Mode = string;
export interface BlobMetadata {
    blobId?: string;
    path?: string;
    mode?: string;
}
export declare const BlobMetadata: S.Schema<BlobMetadata>;
export interface Difference {
    beforeBlob?: BlobMetadata;
    afterBlob?: BlobMetadata;
    changeType?: ChangeTypeEnum;
}
export declare const Difference: S.Schema<Difference>;
export type DifferenceList = Difference[];
export declare const DifferenceList: any;
export interface GetDifferencesOutput {
    differences?: Difference[];
    NextToken?: string;
}
export declare const GetDifferencesOutput: S.Schema<GetDifferencesOutput>;
export interface GetFileInput {
    repositoryName: string;
    commitSpecifier?: string;
    filePath: string;
}
export declare const GetFileInput: S.Schema<GetFileInput>;
export interface GetFileOutput {
    commitId: string;
    blobId: string;
    filePath: string;
    fileMode: FileModeTypeEnum;
    fileSize: number;
    fileContent: Uint8Array;
}
export declare const GetFileOutput: S.Schema<GetFileOutput>;
export interface GetFolderInput {
    repositoryName: string;
    commitSpecifier?: string;
    folderPath: string;
}
export declare const GetFolderInput: S.Schema<GetFolderInput>;
export interface Folder {
    treeId?: string;
    absolutePath?: string;
    relativePath?: string;
}
export declare const Folder: S.Schema<Folder>;
export type FolderList = Folder[];
export declare const FolderList: any;
export interface File {
    blobId?: string;
    absolutePath?: string;
    relativePath?: string;
    fileMode?: FileModeTypeEnum;
}
export declare const File: S.Schema<File>;
export type FileList = File[];
export declare const FileList: any;
export interface SymbolicLink {
    blobId?: string;
    absolutePath?: string;
    relativePath?: string;
    fileMode?: FileModeTypeEnum;
}
export declare const SymbolicLink: S.Schema<SymbolicLink>;
export type SymbolicLinkList = SymbolicLink[];
export declare const SymbolicLinkList: any;
export interface SubModule {
    commitId?: string;
    absolutePath?: string;
    relativePath?: string;
}
export declare const SubModule: S.Schema<SubModule>;
export type SubModuleList = SubModule[];
export declare const SubModuleList: any;
export interface GetFolderOutput {
    commitId: string;
    folderPath: string;
    treeId?: string;
    subFolders?: Folder[];
    files?: File[];
    symbolicLinks?: SymbolicLink[];
    subModules?: SubModule[];
}
export declare const GetFolderOutput: S.Schema<GetFolderOutput>;
export interface GetMergeCommitInput {
    repositoryName: string;
    sourceCommitSpecifier: string;
    destinationCommitSpecifier: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
}
export declare const GetMergeCommitInput: S.Schema<GetMergeCommitInput>;
export interface GetMergeCommitOutput {
    sourceCommitId?: string;
    destinationCommitId?: string;
    baseCommitId?: string;
    mergedCommitId?: string;
}
export declare const GetMergeCommitOutput: S.Schema<GetMergeCommitOutput>;
export interface GetMergeConflictsInput {
    repositoryName: string;
    destinationCommitSpecifier: string;
    sourceCommitSpecifier: string;
    mergeOption: MergeOptionTypeEnum;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    maxConflictFiles?: number;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    nextToken?: string;
}
export declare const GetMergeConflictsInput: S.Schema<GetMergeConflictsInput>;
export type IsMergeable = boolean;
export type ConflictMetadataList = ConflictMetadata[];
export declare const ConflictMetadataList: any;
export interface GetMergeConflictsOutput {
    mergeable: boolean;
    destinationCommitId: string;
    sourceCommitId: string;
    baseCommitId?: string;
    conflictMetadataList: ConflictMetadata[];
    nextToken?: string;
}
export declare const GetMergeConflictsOutput: S.Schema<GetMergeConflictsOutput>;
export interface GetMergeOptionsInput {
    repositoryName: string;
    sourceCommitSpecifier: string;
    destinationCommitSpecifier: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
}
export declare const GetMergeOptionsInput: S.Schema<GetMergeOptionsInput>;
export type MergeOptions = MergeOptionTypeEnum[];
export declare const MergeOptions: any;
export interface GetMergeOptionsOutput {
    mergeOptions: MergeOptionTypeEnum[];
    sourceCommitId: string;
    destinationCommitId: string;
    baseCommitId: string;
}
export declare const GetMergeOptionsOutput: S.Schema<GetMergeOptionsOutput>;
export interface GetPullRequestInput {
    pullRequestId: string;
}
export declare const GetPullRequestInput: S.Schema<GetPullRequestInput>;
export interface GetPullRequestOutput {
    pullRequest: PullRequest;
}
export declare const GetPullRequestOutput: S.Schema<GetPullRequestOutput>;
export interface GetPullRequestApprovalStatesInput {
    pullRequestId: string;
    revisionId: string;
}
export declare const GetPullRequestApprovalStatesInput: S.Schema<GetPullRequestApprovalStatesInput>;
export interface Approval {
    userArn?: string;
    approvalState?: ApprovalState;
}
export declare const Approval: S.Schema<Approval>;
export type ApprovalList = Approval[];
export declare const ApprovalList: any;
export interface GetPullRequestApprovalStatesOutput {
    approvals?: Approval[];
}
export declare const GetPullRequestApprovalStatesOutput: S.Schema<GetPullRequestApprovalStatesOutput>;
export interface GetPullRequestOverrideStateInput {
    pullRequestId: string;
    revisionId: string;
}
export declare const GetPullRequestOverrideStateInput: S.Schema<GetPullRequestOverrideStateInput>;
export interface GetPullRequestOverrideStateOutput {
    overridden?: boolean;
    overrider?: string;
}
export declare const GetPullRequestOverrideStateOutput: S.Schema<GetPullRequestOverrideStateOutput>;
export interface GetRepositoryInput {
    repositoryName: string;
}
export declare const GetRepositoryInput: S.Schema<GetRepositoryInput>;
export interface GetRepositoryOutput {
    repositoryMetadata?: RepositoryMetadata;
}
export declare const GetRepositoryOutput: S.Schema<GetRepositoryOutput>;
export interface GetRepositoryTriggersInput {
    repositoryName: string;
}
export declare const GetRepositoryTriggersInput: S.Schema<GetRepositoryTriggersInput>;
export type RepositoryTriggersConfigurationId = string;
export type RepositoryTriggerName = string;
export type RepositoryTriggerCustomData = string;
export type BranchNameList = string[];
export declare const BranchNameList: any;
export type RepositoryTriggerEventEnum = "all" | "updateReference" | "createReference" | "deleteReference" | (string & {});
export declare const RepositoryTriggerEventEnum: any;
export type RepositoryTriggerEventList = RepositoryTriggerEventEnum[];
export declare const RepositoryTriggerEventList: any;
export interface RepositoryTrigger {
    name: string;
    destinationArn: string;
    customData?: string;
    branches?: string[];
    events: RepositoryTriggerEventEnum[];
}
export declare const RepositoryTrigger: S.Schema<RepositoryTrigger>;
export type RepositoryTriggersList = RepositoryTrigger[];
export declare const RepositoryTriggersList: any;
export interface GetRepositoryTriggersOutput {
    configurationId?: string;
    triggers?: RepositoryTrigger[];
}
export declare const GetRepositoryTriggersOutput: S.Schema<GetRepositoryTriggersOutput>;
export interface ListApprovalRuleTemplatesInput {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListApprovalRuleTemplatesInput: S.Schema<ListApprovalRuleTemplatesInput>;
export type ApprovalRuleTemplateNameList = string[];
export declare const ApprovalRuleTemplateNameList: any;
export interface ListApprovalRuleTemplatesOutput {
    approvalRuleTemplateNames?: string[];
    nextToken?: string;
}
export declare const ListApprovalRuleTemplatesOutput: S.Schema<ListApprovalRuleTemplatesOutput>;
export interface ListAssociatedApprovalRuleTemplatesForRepositoryInput {
    repositoryName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAssociatedApprovalRuleTemplatesForRepositoryInput: S.Schema<ListAssociatedApprovalRuleTemplatesForRepositoryInput>;
export interface ListAssociatedApprovalRuleTemplatesForRepositoryOutput {
    approvalRuleTemplateNames?: string[];
    nextToken?: string;
}
export declare const ListAssociatedApprovalRuleTemplatesForRepositoryOutput: S.Schema<ListAssociatedApprovalRuleTemplatesForRepositoryOutput>;
export interface ListBranchesInput {
    repositoryName: string;
    nextToken?: string;
}
export declare const ListBranchesInput: S.Schema<ListBranchesInput>;
export interface ListBranchesOutput {
    branches?: string[];
    nextToken?: string;
}
export declare const ListBranchesOutput: S.Schema<ListBranchesOutput>;
export interface ListFileCommitHistoryRequest {
    repositoryName: string;
    commitSpecifier?: string;
    filePath: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListFileCommitHistoryRequest: S.Schema<ListFileCommitHistoryRequest>;
export type RevisionChildren = string[];
export declare const RevisionChildren: any;
export interface FileVersion {
    commit?: Commit;
    blobId?: string;
    path?: string;
    revisionChildren?: string[];
}
export declare const FileVersion: S.Schema<FileVersion>;
export type RevisionDag = FileVersion[];
export declare const RevisionDag: any;
export interface ListFileCommitHistoryResponse {
    revisionDag: FileVersion[];
    nextToken?: string;
}
export declare const ListFileCommitHistoryResponse: S.Schema<ListFileCommitHistoryResponse>;
export interface ListPullRequestsInput {
    repositoryName: string;
    authorArn?: string;
    pullRequestStatus?: PullRequestStatusEnum;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPullRequestsInput: S.Schema<ListPullRequestsInput>;
export type PullRequestIdList = string[];
export declare const PullRequestIdList: any;
export interface ListPullRequestsOutput {
    pullRequestIds: string[];
    nextToken?: string;
}
export declare const ListPullRequestsOutput: S.Schema<ListPullRequestsOutput>;
export type SortByEnum = "repositoryName" | "lastModifiedDate" | (string & {});
export declare const SortByEnum: any;
export type OrderEnum = "ascending" | "descending" | (string & {});
export declare const OrderEnum: any;
export interface ListRepositoriesInput {
    nextToken?: string;
    sortBy?: SortByEnum;
    order?: OrderEnum;
}
export declare const ListRepositoriesInput: S.Schema<ListRepositoriesInput>;
export interface RepositoryNameIdPair {
    repositoryName?: string;
    repositoryId?: string;
}
export declare const RepositoryNameIdPair: S.Schema<RepositoryNameIdPair>;
export type RepositoryNameIdPairList = RepositoryNameIdPair[];
export declare const RepositoryNameIdPairList: any;
export interface ListRepositoriesOutput {
    repositories?: RepositoryNameIdPair[];
    nextToken?: string;
}
export declare const ListRepositoriesOutput: S.Schema<ListRepositoriesOutput>;
export interface ListRepositoriesForApprovalRuleTemplateInput {
    approvalRuleTemplateName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListRepositoriesForApprovalRuleTemplateInput: S.Schema<ListRepositoriesForApprovalRuleTemplateInput>;
export interface ListRepositoriesForApprovalRuleTemplateOutput {
    repositoryNames?: string[];
    nextToken?: string;
}
export declare const ListRepositoriesForApprovalRuleTemplateOutput: S.Schema<ListRepositoriesForApprovalRuleTemplateOutput>;
export type ResourceArn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
    nextToken?: string;
}
export declare const ListTagsForResourceInput: S.Schema<ListTagsForResourceInput>;
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    };
    nextToken?: string;
}
export declare const ListTagsForResourceOutput: S.Schema<ListTagsForResourceOutput>;
export interface MergeBranchesByFastForwardInput {
    repositoryName: string;
    sourceCommitSpecifier: string;
    destinationCommitSpecifier: string;
    targetBranch?: string;
}
export declare const MergeBranchesByFastForwardInput: S.Schema<MergeBranchesByFastForwardInput>;
export interface MergeBranchesByFastForwardOutput {
    commitId?: string;
    treeId?: string;
}
export declare const MergeBranchesByFastForwardOutput: S.Schema<MergeBranchesByFastForwardOutput>;
export interface MergeBranchesBySquashInput {
    repositoryName: string;
    sourceCommitSpecifier: string;
    destinationCommitSpecifier: string;
    targetBranch?: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    authorName?: string;
    email?: string;
    commitMessage?: string;
    keepEmptyFolders?: boolean;
    conflictResolution?: ConflictResolution;
}
export declare const MergeBranchesBySquashInput: S.Schema<MergeBranchesBySquashInput>;
export interface MergeBranchesBySquashOutput {
    commitId?: string;
    treeId?: string;
}
export declare const MergeBranchesBySquashOutput: S.Schema<MergeBranchesBySquashOutput>;
export interface MergeBranchesByThreeWayInput {
    repositoryName: string;
    sourceCommitSpecifier: string;
    destinationCommitSpecifier: string;
    targetBranch?: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    authorName?: string;
    email?: string;
    commitMessage?: string;
    keepEmptyFolders?: boolean;
    conflictResolution?: ConflictResolution;
}
export declare const MergeBranchesByThreeWayInput: S.Schema<MergeBranchesByThreeWayInput>;
export interface MergeBranchesByThreeWayOutput {
    commitId?: string;
    treeId?: string;
}
export declare const MergeBranchesByThreeWayOutput: S.Schema<MergeBranchesByThreeWayOutput>;
export interface MergePullRequestByFastForwardInput {
    pullRequestId: string;
    repositoryName: string;
    sourceCommitId?: string;
}
export declare const MergePullRequestByFastForwardInput: S.Schema<MergePullRequestByFastForwardInput>;
export interface MergePullRequestByFastForwardOutput {
    pullRequest?: PullRequest;
}
export declare const MergePullRequestByFastForwardOutput: S.Schema<MergePullRequestByFastForwardOutput>;
export interface MergePullRequestBySquashInput {
    pullRequestId: string;
    repositoryName: string;
    sourceCommitId?: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    commitMessage?: string;
    authorName?: string;
    email?: string;
    keepEmptyFolders?: boolean;
    conflictResolution?: ConflictResolution;
}
export declare const MergePullRequestBySquashInput: S.Schema<MergePullRequestBySquashInput>;
export interface MergePullRequestBySquashOutput {
    pullRequest?: PullRequest;
}
export declare const MergePullRequestBySquashOutput: S.Schema<MergePullRequestBySquashOutput>;
export interface MergePullRequestByThreeWayInput {
    pullRequestId: string;
    repositoryName: string;
    sourceCommitId?: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    commitMessage?: string;
    authorName?: string;
    email?: string;
    keepEmptyFolders?: boolean;
    conflictResolution?: ConflictResolution;
}
export declare const MergePullRequestByThreeWayInput: S.Schema<MergePullRequestByThreeWayInput>;
export interface MergePullRequestByThreeWayOutput {
    pullRequest?: PullRequest;
}
export declare const MergePullRequestByThreeWayOutput: S.Schema<MergePullRequestByThreeWayOutput>;
export interface OverridePullRequestApprovalRulesInput {
    pullRequestId: string;
    revisionId: string;
    overrideStatus: OverrideStatus;
}
export declare const OverridePullRequestApprovalRulesInput: S.Schema<OverridePullRequestApprovalRulesInput>;
export interface OverridePullRequestApprovalRulesResponse {
}
export declare const OverridePullRequestApprovalRulesResponse: S.Schema<OverridePullRequestApprovalRulesResponse>;
export interface PostCommentForComparedCommitInput {
    repositoryName: string;
    beforeCommitId?: string;
    afterCommitId: string;
    location?: Location;
    content: string;
    clientRequestToken?: string;
}
export declare const PostCommentForComparedCommitInput: S.Schema<PostCommentForComparedCommitInput>;
export interface PostCommentForComparedCommitOutput {
    repositoryName?: string;
    beforeCommitId?: string;
    afterCommitId?: string;
    beforeBlobId?: string;
    afterBlobId?: string;
    location?: Location;
    comment?: Comment;
}
export declare const PostCommentForComparedCommitOutput: S.Schema<PostCommentForComparedCommitOutput>;
export interface PostCommentForPullRequestInput {
    pullRequestId: string;
    repositoryName: string;
    beforeCommitId: string;
    afterCommitId: string;
    location?: Location;
    content: string;
    clientRequestToken?: string;
}
export declare const PostCommentForPullRequestInput: S.Schema<PostCommentForPullRequestInput>;
export interface PostCommentForPullRequestOutput {
    repositoryName?: string;
    pullRequestId?: string;
    beforeCommitId?: string;
    afterCommitId?: string;
    beforeBlobId?: string;
    afterBlobId?: string;
    location?: Location;
    comment?: Comment;
}
export declare const PostCommentForPullRequestOutput: S.Schema<PostCommentForPullRequestOutput>;
export interface PostCommentReplyInput {
    inReplyTo: string;
    clientRequestToken?: string;
    content: string;
}
export declare const PostCommentReplyInput: S.Schema<PostCommentReplyInput>;
export interface PostCommentReplyOutput {
    comment?: Comment;
}
export declare const PostCommentReplyOutput: S.Schema<PostCommentReplyOutput>;
export interface PutCommentReactionInput {
    commentId: string;
    reactionValue: string;
}
export declare const PutCommentReactionInput: S.Schema<PutCommentReactionInput>;
export interface PutCommentReactionResponse {
}
export declare const PutCommentReactionResponse: S.Schema<PutCommentReactionResponse>;
export interface PutFileInput {
    repositoryName: string;
    branchName: string;
    fileContent: Uint8Array;
    filePath: string;
    fileMode?: FileModeTypeEnum;
    parentCommitId?: string;
    commitMessage?: string;
    name?: string;
    email?: string;
}
export declare const PutFileInput: S.Schema<PutFileInput>;
export interface PutFileOutput {
    commitId: string;
    blobId: string;
    treeId: string;
}
export declare const PutFileOutput: S.Schema<PutFileOutput>;
export interface PutRepositoryTriggersInput {
    repositoryName: string;
    triggers: RepositoryTrigger[];
}
export declare const PutRepositoryTriggersInput: S.Schema<PutRepositoryTriggersInput>;
export interface PutRepositoryTriggersOutput {
    configurationId?: string;
}
export declare const PutRepositoryTriggersOutput: S.Schema<PutRepositoryTriggersOutput>;
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceInput: S.Schema<TagResourceInput>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface TestRepositoryTriggersInput {
    repositoryName: string;
    triggers: RepositoryTrigger[];
}
export declare const TestRepositoryTriggersInput: S.Schema<TestRepositoryTriggersInput>;
export type RepositoryTriggerNameList = string[];
export declare const RepositoryTriggerNameList: any;
export type RepositoryTriggerExecutionFailureMessage = string;
export interface RepositoryTriggerExecutionFailure {
    trigger?: string;
    failureMessage?: string;
}
export declare const RepositoryTriggerExecutionFailure: S.Schema<RepositoryTriggerExecutionFailure>;
export type RepositoryTriggerExecutionFailureList = RepositoryTriggerExecutionFailure[];
export declare const RepositoryTriggerExecutionFailureList: any;
export interface TestRepositoryTriggersOutput {
    successfulExecutions?: string[];
    failedExecutions?: RepositoryTriggerExecutionFailure[];
}
export declare const TestRepositoryTriggersOutput: S.Schema<TestRepositoryTriggersOutput>;
export type TagKeysList = string[];
export declare const TagKeysList: any;
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceInput: S.Schema<UntagResourceInput>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateApprovalRuleTemplateContentInput {
    approvalRuleTemplateName: string;
    newRuleContent: string;
    existingRuleContentSha256?: string;
}
export declare const UpdateApprovalRuleTemplateContentInput: S.Schema<UpdateApprovalRuleTemplateContentInput>;
export interface UpdateApprovalRuleTemplateContentOutput {
    approvalRuleTemplate: ApprovalRuleTemplate;
}
export declare const UpdateApprovalRuleTemplateContentOutput: S.Schema<UpdateApprovalRuleTemplateContentOutput>;
export interface UpdateApprovalRuleTemplateDescriptionInput {
    approvalRuleTemplateName: string;
    approvalRuleTemplateDescription: string;
}
export declare const UpdateApprovalRuleTemplateDescriptionInput: S.Schema<UpdateApprovalRuleTemplateDescriptionInput>;
export interface UpdateApprovalRuleTemplateDescriptionOutput {
    approvalRuleTemplate: ApprovalRuleTemplate;
}
export declare const UpdateApprovalRuleTemplateDescriptionOutput: S.Schema<UpdateApprovalRuleTemplateDescriptionOutput>;
export interface UpdateApprovalRuleTemplateNameInput {
    oldApprovalRuleTemplateName: string;
    newApprovalRuleTemplateName: string;
}
export declare const UpdateApprovalRuleTemplateNameInput: S.Schema<UpdateApprovalRuleTemplateNameInput>;
export interface UpdateApprovalRuleTemplateNameOutput {
    approvalRuleTemplate: ApprovalRuleTemplate;
}
export declare const UpdateApprovalRuleTemplateNameOutput: S.Schema<UpdateApprovalRuleTemplateNameOutput>;
export interface UpdateCommentInput {
    commentId: string;
    content: string;
}
export declare const UpdateCommentInput: S.Schema<UpdateCommentInput>;
export interface UpdateCommentOutput {
    comment?: Comment;
}
export declare const UpdateCommentOutput: S.Schema<UpdateCommentOutput>;
export interface UpdateDefaultBranchInput {
    repositoryName: string;
    defaultBranchName: string;
}
export declare const UpdateDefaultBranchInput: S.Schema<UpdateDefaultBranchInput>;
export interface UpdateDefaultBranchResponse {
}
export declare const UpdateDefaultBranchResponse: S.Schema<UpdateDefaultBranchResponse>;
export interface UpdatePullRequestApprovalRuleContentInput {
    pullRequestId: string;
    approvalRuleName: string;
    existingRuleContentSha256?: string;
    newRuleContent: string;
}
export declare const UpdatePullRequestApprovalRuleContentInput: S.Schema<UpdatePullRequestApprovalRuleContentInput>;
export interface UpdatePullRequestApprovalRuleContentOutput {
    approvalRule: ApprovalRule;
}
export declare const UpdatePullRequestApprovalRuleContentOutput: S.Schema<UpdatePullRequestApprovalRuleContentOutput>;
export interface UpdatePullRequestApprovalStateInput {
    pullRequestId: string;
    revisionId: string;
    approvalState: ApprovalState;
}
export declare const UpdatePullRequestApprovalStateInput: S.Schema<UpdatePullRequestApprovalStateInput>;
export interface UpdatePullRequestApprovalStateResponse {
}
export declare const UpdatePullRequestApprovalStateResponse: S.Schema<UpdatePullRequestApprovalStateResponse>;
export interface UpdatePullRequestDescriptionInput {
    pullRequestId: string;
    description: string;
}
export declare const UpdatePullRequestDescriptionInput: S.Schema<UpdatePullRequestDescriptionInput>;
export interface UpdatePullRequestDescriptionOutput {
    pullRequest: PullRequest;
}
export declare const UpdatePullRequestDescriptionOutput: S.Schema<UpdatePullRequestDescriptionOutput>;
export interface UpdatePullRequestStatusInput {
    pullRequestId: string;
    pullRequestStatus: PullRequestStatusEnum;
}
export declare const UpdatePullRequestStatusInput: S.Schema<UpdatePullRequestStatusInput>;
export interface UpdatePullRequestStatusOutput {
    pullRequest: PullRequest;
}
export declare const UpdatePullRequestStatusOutput: S.Schema<UpdatePullRequestStatusOutput>;
export interface UpdatePullRequestTitleInput {
    pullRequestId: string;
    title: string;
}
export declare const UpdatePullRequestTitleInput: S.Schema<UpdatePullRequestTitleInput>;
export interface UpdatePullRequestTitleOutput {
    pullRequest: PullRequest;
}
export declare const UpdatePullRequestTitleOutput: S.Schema<UpdatePullRequestTitleOutput>;
export interface UpdateRepositoryDescriptionInput {
    repositoryName: string;
    repositoryDescription?: string;
}
export declare const UpdateRepositoryDescriptionInput: S.Schema<UpdateRepositoryDescriptionInput>;
export interface UpdateRepositoryDescriptionResponse {
}
export declare const UpdateRepositoryDescriptionResponse: S.Schema<UpdateRepositoryDescriptionResponse>;
export interface UpdateRepositoryEncryptionKeyInput {
    repositoryName: string;
    kmsKeyId: string;
}
export declare const UpdateRepositoryEncryptionKeyInput: S.Schema<UpdateRepositoryEncryptionKeyInput>;
export interface UpdateRepositoryEncryptionKeyOutput {
    repositoryId?: string;
    kmsKeyId?: string;
    originalKmsKeyId?: string;
}
export declare const UpdateRepositoryEncryptionKeyOutput: S.Schema<UpdateRepositoryEncryptionKeyOutput>;
export interface UpdateRepositoryNameInput {
    oldName: string;
    newName: string;
}
export declare const UpdateRepositoryNameInput: S.Schema<UpdateRepositoryNameInput>;
export interface UpdateRepositoryNameResponse {
}
export declare const UpdateRepositoryNameResponse: S.Schema<UpdateRepositoryNameResponse>;
export type AssociateApprovalRuleTemplateWithRepositoryError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleTemplateNameException | InvalidRepositoryNameException | MaximumRuleTemplatesAssociatedWithRepositoryException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Creates an association between an approval rule template and a specified repository.
 * Then, the next time a pull request is created in the repository where the destination
 * reference (if specified) matches the destination reference (branch) for the pull
 * request, an approval rule that matches the template conditions is automatically created
 * for that pull request. If no destination references are specified in the template, an
 * approval rule that matches the template contents is created for all pull requests in
 * that repository.
 */
export declare const associateApprovalRuleTemplateWithRepository: API.OperationMethod<AssociateApprovalRuleTemplateWithRepositoryInput, AssociateApprovalRuleTemplateWithRepositoryResponse, AssociateApprovalRuleTemplateWithRepositoryError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateApprovalRuleTemplateWithRepositoriesError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleTemplateNameException | MaximumRepositoryNamesExceededException | RepositoryNamesRequiredException | CommonErrors;
/**
 * Creates an association between an approval rule template and one or more specified repositories.
 */
export declare const batchAssociateApprovalRuleTemplateWithRepositories: API.OperationMethod<BatchAssociateApprovalRuleTemplateWithRepositoriesInput, BatchAssociateApprovalRuleTemplateWithRepositoriesOutput, BatchAssociateApprovalRuleTemplateWithRepositoriesError, Credentials | HttpClient.HttpClient>;
export type BatchDescribeMergeConflictsError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionStrategyException | InvalidContinuationTokenException | InvalidMaxConflictFilesException | InvalidMaxMergeHunksException | InvalidMergeOptionException | InvalidRepositoryNameException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MergeOptionRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Returns information about one or more merge conflicts in the attempted merge of two commit specifiers using the squash or three-way merge strategy.
 */
export declare const batchDescribeMergeConflicts: API.OperationMethod<BatchDescribeMergeConflictsInput, BatchDescribeMergeConflictsOutput, BatchDescribeMergeConflictsError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateApprovalRuleTemplateFromRepositoriesError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleTemplateNameException | MaximumRepositoryNamesExceededException | RepositoryNamesRequiredException | CommonErrors;
/**
 * Removes the association between an approval rule template and one or more specified repositories.
 */
export declare const batchDisassociateApprovalRuleTemplateFromRepositories: API.OperationMethod<BatchDisassociateApprovalRuleTemplateFromRepositoriesInput, BatchDisassociateApprovalRuleTemplateFromRepositoriesOutput, BatchDisassociateApprovalRuleTemplateFromRepositoriesError, Credentials | HttpClient.HttpClient>;
export type BatchGetCommitsError = CommitIdsLimitExceededException | CommitIdsListRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about the contents of one or more commits in a repository.
 */
export declare const batchGetCommits: API.OperationMethod<BatchGetCommitsInput, BatchGetCommitsOutput, BatchGetCommitsError, Credentials | HttpClient.HttpClient>;
export type BatchGetRepositoriesError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | MaximumRepositoryNamesExceededException | RepositoryNamesRequiredException | CommonErrors;
/**
 * Returns information about one or more repositories.
 *
 * The description field for a repository accepts all HTML characters and all valid
 * Unicode characters. Applications that do not HTML-encode the description and display
 * it in a webpage can expose users to potentially malicious code. Make sure that you
 * HTML-encode the description field in any application that uses this API to display
 * the repository description on a webpage.
 */
export declare const batchGetRepositories: API.OperationMethod<BatchGetRepositoriesInput, BatchGetRepositoriesOutput, BatchGetRepositoriesError, Credentials | HttpClient.HttpClient>;
export type CreateApprovalRuleTemplateError = ApprovalRuleTemplateContentRequiredException | ApprovalRuleTemplateNameAlreadyExistsException | ApprovalRuleTemplateNameRequiredException | InvalidApprovalRuleTemplateContentException | InvalidApprovalRuleTemplateDescriptionException | InvalidApprovalRuleTemplateNameException | NumberOfRuleTemplatesExceededException | CommonErrors;
/**
 * Creates a template for approval rules that can then be associated with one or more
 * repositories in your Amazon Web Services account. When you associate a template with a repository,
 * CodeCommit creates an approval rule that matches the conditions of the template for all
 * pull requests that meet the conditions of the template. For more information, see
 * AssociateApprovalRuleTemplateWithRepository.
 */
export declare const createApprovalRuleTemplate: API.OperationMethod<CreateApprovalRuleTemplateInput, CreateApprovalRuleTemplateOutput, CreateApprovalRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateBranchError = BranchNameExistsException | BranchNameRequiredException | CommitDoesNotExistException | CommitIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidBranchNameException | InvalidCommitIdException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Creates a branch in a repository and points the branch to a commit.
 *
 * Calling the create branch operation does not set a repository's default branch. To do this, call the update default branch operation.
 */
export declare const createBranch: API.OperationMethod<CreateBranchInput, CreateBranchResponse, CreateBranchError, Credentials | HttpClient.HttpClient>;
export type CreateCommitError = BranchDoesNotExistException | BranchNameIsTagNameException | BranchNameRequiredException | CommitMessageLengthExceededException | DirectoryNameConflictsWithFileNameException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentAndSourceFileSpecifiedException | FileContentSizeLimitExceededException | FileDoesNotExistException | FileEntryRequiredException | FileModeRequiredException | FileNameConflictsWithDirectoryNameException | FilePathConflictsWithSubmodulePathException | FolderContentSizeLimitExceededException | InvalidBranchNameException | InvalidDeletionParameterException | InvalidEmailException | InvalidFileModeException | InvalidParentCommitIdException | InvalidPathException | InvalidRepositoryNameException | MaximumFileEntriesExceededException | NameLengthExceededException | NoChangeException | ParentCommitDoesNotExistException | ParentCommitIdOutdatedException | ParentCommitIdRequiredException | PathRequiredException | PutFileEntryConflictException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RestrictedSourceFileException | SamePathRequestException | SourceFileOrContentRequiredException | CommonErrors;
/**
 * Creates a commit for a repository on the tip of a specified branch.
 */
export declare const createCommit: API.OperationMethod<CreateCommitInput, CreateCommitOutput, CreateCommitError, Credentials | HttpClient.HttpClient>;
export type CreatePullRequestError = ClientRequestTokenRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | IdempotencyParameterMismatchException | InvalidClientRequestTokenException | InvalidDescriptionException | InvalidReferenceNameException | InvalidRepositoryNameException | InvalidTargetException | InvalidTargetsException | InvalidTitleException | MaximumOpenPullRequestsExceededException | MultipleRepositoriesInPullRequestException | ReferenceDoesNotExistException | ReferenceNameRequiredException | ReferenceTypeNotSupportedException | RepositoryDoesNotExistException | RepositoryNameRequiredException | SourceAndDestinationAreSameException | TargetRequiredException | TargetsRequiredException | TitleRequiredException | CommonErrors;
/**
 * Creates a pull request in the specified repository.
 */
export declare const createPullRequest: API.OperationMethod<CreatePullRequestInput, CreatePullRequestOutput, CreatePullRequestError, Credentials | HttpClient.HttpClient>;
export type CreatePullRequestApprovalRuleError = ApprovalRuleContentRequiredException | ApprovalRuleNameAlreadyExistsException | ApprovalRuleNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleContentException | InvalidApprovalRuleNameException | InvalidPullRequestIdException | NumberOfRulesExceededException | PullRequestAlreadyClosedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | CommonErrors;
/**
 * Creates an approval rule for a pull request.
 */
export declare const createPullRequestApprovalRule: API.OperationMethod<CreatePullRequestApprovalRuleInput, CreatePullRequestApprovalRuleOutput, CreatePullRequestApprovalRuleError, Credentials | HttpClient.HttpClient>;
export type CreateRepositoryError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyInvalidIdException | EncryptionKeyInvalidUsageException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryDescriptionException | InvalidRepositoryNameException | InvalidSystemTagUsageException | InvalidTagsMapException | OperationNotAllowedException | RepositoryLimitExceededException | RepositoryNameExistsException | RepositoryNameRequiredException | TagPolicyException | TooManyTagsException | CommonErrors;
/**
 * Creates a new, empty repository.
 */
export declare const createRepository: API.OperationMethod<CreateRepositoryInput, CreateRepositoryOutput, CreateRepositoryError, Credentials | HttpClient.HttpClient>;
export type CreateUnreferencedMergeCommitError = CommitDoesNotExistException | CommitMessageLengthExceededException | CommitRequiredException | ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentSizeLimitExceededException | FileModeRequiredException | FolderContentSizeLimitExceededException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionException | InvalidConflictResolutionStrategyException | InvalidEmailException | InvalidFileModeException | InvalidMergeOptionException | InvalidPathException | InvalidReplacementContentException | InvalidReplacementTypeException | InvalidRepositoryNameException | ManualMergeRequiredException | MaximumConflictResolutionEntriesExceededException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MergeOptionRequiredException | MultipleConflictResolutionEntriesException | NameLengthExceededException | PathRequiredException | ReplacementContentRequiredException | ReplacementTypeRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Creates an unreferenced commit that represents the result of merging two branches
 * using a specified merge strategy. This can help you determine the outcome of a potential
 * merge. This API cannot be used with the fast-forward merge strategy because that
 * strategy does not create a merge commit.
 *
 * This unreferenced merge commit
 * can only be accessed using the GetCommit API or through git commands such as git fetch. To retrieve this commit, you must specify its commit ID or otherwise reference it.
 */
export declare const createUnreferencedMergeCommit: API.OperationMethod<CreateUnreferencedMergeCommitInput, CreateUnreferencedMergeCommitOutput, CreateUnreferencedMergeCommitError, Credentials | HttpClient.HttpClient>;
export type DeleteApprovalRuleTemplateError = ApprovalRuleTemplateInUseException | ApprovalRuleTemplateNameRequiredException | InvalidApprovalRuleTemplateNameException | CommonErrors;
/**
 * Deletes a specified approval rule template. Deleting a template does not remove approval rules on pull requests already created with the template.
 */
export declare const deleteApprovalRuleTemplate: API.OperationMethod<DeleteApprovalRuleTemplateInput, DeleteApprovalRuleTemplateOutput, DeleteApprovalRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteBranchError = BranchNameRequiredException | DefaultBranchCannotBeDeletedException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidBranchNameException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Deletes a branch from a repository, unless that branch is the default branch for the repository.
 */
export declare const deleteBranch: API.OperationMethod<DeleteBranchInput, DeleteBranchOutput, DeleteBranchError, Credentials | HttpClient.HttpClient>;
export type DeleteCommentContentError = CommentDeletedException | CommentDoesNotExistException | CommentIdRequiredException | InvalidCommentIdException | CommonErrors;
/**
 * Deletes the content of a comment made on a change, file, or commit in a repository.
 */
export declare const deleteCommentContent: API.OperationMethod<DeleteCommentContentInput, DeleteCommentContentOutput, DeleteCommentContentError, Credentials | HttpClient.HttpClient>;
export type DeleteFileError = BranchDoesNotExistException | BranchNameIsTagNameException | BranchNameRequiredException | CommitMessageLengthExceededException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileDoesNotExistException | InvalidBranchNameException | InvalidEmailException | InvalidParentCommitIdException | InvalidPathException | InvalidRepositoryNameException | NameLengthExceededException | ParentCommitDoesNotExistException | ParentCommitIdOutdatedException | ParentCommitIdRequiredException | PathRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Deletes a specified file from a specified branch. A commit is created on the branch
 * that contains the revision. The file still exists in the commits earlier to the commit
 * that contains the deletion.
 */
export declare const deleteFile: API.OperationMethod<DeleteFileInput, DeleteFileOutput, DeleteFileError, Credentials | HttpClient.HttpClient>;
export type DeletePullRequestApprovalRuleError = ApprovalRuleNameRequiredException | CannotDeleteApprovalRuleFromTemplateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleNameException | InvalidPullRequestIdException | PullRequestAlreadyClosedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | CommonErrors;
/**
 * Deletes an approval rule from a specified pull request. Approval rules can be deleted from a pull request only if the pull request is open, and if the
 * approval rule was created specifically for a pull request and not generated from an approval rule template associated with the repository where the
 * pull request was created. You cannot delete an approval rule from a merged or closed pull request.
 */
export declare const deletePullRequestApprovalRule: API.OperationMethod<DeletePullRequestApprovalRuleInput, DeletePullRequestApprovalRuleOutput, DeletePullRequestApprovalRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | RepositoryNameRequiredException | CommonErrors;
/**
 * Deletes a repository. If a specified repository was already deleted, a null repository
 * ID is returned.
 *
 * Deleting a repository also deletes all associated objects and metadata. After a repository is
 * deleted, all future push calls to the deleted repository fail.
 */
export declare const deleteRepository: API.OperationMethod<DeleteRepositoryInput, DeleteRepositoryOutput, DeleteRepositoryError, Credentials | HttpClient.HttpClient>;
export type DescribeMergeConflictsError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileDoesNotExistException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionStrategyException | InvalidContinuationTokenException | InvalidMaxMergeHunksException | InvalidMergeOptionException | InvalidPathException | InvalidRepositoryNameException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MergeOptionRequiredException | PathRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Returns information about one or more merge conflicts in the attempted merge of two
 * commit specifiers using the squash or three-way merge strategy. If the merge option for
 * the attempted merge is specified as FAST_FORWARD_MERGE, an exception is thrown.
 */
export declare const describeMergeConflicts: API.PaginatedOperationMethod<DescribeMergeConflictsInput, DescribeMergeConflictsOutput, DescribeMergeConflictsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribePullRequestEventsError = ActorDoesNotExistException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidActorArnException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidPullRequestEventTypeException | InvalidPullRequestIdException | PullRequestDoesNotExistException | PullRequestIdRequiredException | CommonErrors;
/**
 * Returns information about one or more pull request events.
 */
export declare const describePullRequestEvents: API.PaginatedOperationMethod<DescribePullRequestEventsInput, DescribePullRequestEventsOutput, DescribePullRequestEventsError, Credentials | HttpClient.HttpClient, unknown>;
export type DisassociateApprovalRuleTemplateFromRepositoryError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleTemplateNameException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Removes the association between a template and a repository so that approval rules
 * based on the template are not automatically created when pull requests are created in
 * the specified repository. This does not delete any approval rules previously created for
 * pull requests through the template association.
 */
export declare const disassociateApprovalRuleTemplateFromRepository: API.OperationMethod<DisassociateApprovalRuleTemplateFromRepositoryInput, DisassociateApprovalRuleTemplateFromRepositoryResponse, DisassociateApprovalRuleTemplateFromRepositoryError, Credentials | HttpClient.HttpClient>;
export type EvaluatePullRequestApprovalRulesError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidPullRequestIdException | InvalidRevisionIdException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RevisionIdRequiredException | RevisionNotCurrentException | CommonErrors;
/**
 * Evaluates whether a pull request has met all the conditions specified in its associated approval rules.
 */
export declare const evaluatePullRequestApprovalRules: API.OperationMethod<EvaluatePullRequestApprovalRulesInput, EvaluatePullRequestApprovalRulesOutput, EvaluatePullRequestApprovalRulesError, Credentials | HttpClient.HttpClient>;
export type GetApprovalRuleTemplateError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | InvalidApprovalRuleTemplateNameException | CommonErrors;
/**
 * Returns information about a specified approval rule template.
 */
export declare const getApprovalRuleTemplate: API.OperationMethod<GetApprovalRuleTemplateInput, GetApprovalRuleTemplateOutput, GetApprovalRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type GetBlobError = BlobIdDoesNotExistException | BlobIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileTooLargeException | InvalidBlobIdException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns the base-64 encoded content of an individual blob in a repository.
 */
export declare const getBlob: API.OperationMethod<GetBlobInput, GetBlobOutput, GetBlobError, Credentials | HttpClient.HttpClient>;
export type GetBlobDifferencesError = BlobIdDoesNotExistException | BlobIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileTooLargeException | InvalidBlobIdException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | ValidationException | CommonErrors;
/**
 * Returns a structured, line-level diff between two blob versions in a repository. The
 * diff is returned as an ordered list of hunks, where each hunk represents a contiguous
 * run of changed lines together with any surrounding unchanged context lines.
 *
 * Results are paginated. Use `MaxResults` and `NextToken` to
 * retrieve additional pages.
 *
 * For the typical usage workflow, see GetDifferences.
 */
export declare const getBlobDifferences: API.PaginatedOperationMethod<GetBlobDifferencesInput, GetBlobDifferencesOutput, GetBlobDifferencesError, Credentials | HttpClient.HttpClient, DiffHunk>;
export type GetBranchError = BranchDoesNotExistException | BranchNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidBranchNameException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about a repository branch, including its name and the last commit ID.
 */
export declare const getBranch: API.OperationMethod<GetBranchInput, GetBranchOutput, GetBranchError, Credentials | HttpClient.HttpClient>;
export type GetCommentError = CommentDeletedException | CommentDoesNotExistException | CommentIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommentIdException | CommonErrors;
/**
 * Returns the content of a comment made on a change, file, or commit in a repository.
 *
 * Reaction counts might include numbers from user identities who were deleted after the reaction was made. For a count of
 * reactions from active identities, use GetCommentReactions.
 */
export declare const getComment: API.OperationMethod<GetCommentInput, GetCommentOutput, GetCommentError, Credentials | HttpClient.HttpClient>;
export type GetCommentReactionsError = CommentDeletedException | CommentDoesNotExistException | CommentIdRequiredException | InvalidCommentIdException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidReactionUserArnException | CommonErrors;
/**
 * Returns information about reactions to a specified comment ID. Reactions from users who have been deleted will not be included in the count.
 */
export declare const getCommentReactions: API.PaginatedOperationMethod<GetCommentReactionsInput, GetCommentReactionsOutput, GetCommentReactionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCommentsForComparedCommitError = CommitDoesNotExistException | CommitIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitIdException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about comments made on the comparison between two commits.
 *
 * Reaction counts might include numbers from user identities who were deleted after the reaction was made. For a count of
 * reactions from active identities, use GetCommentReactions.
 */
export declare const getCommentsForComparedCommit: API.PaginatedOperationMethod<GetCommentsForComparedCommitInput, GetCommentsForComparedCommitOutput, GetCommentsForComparedCommitError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCommentsForPullRequestError = CommitDoesNotExistException | CommitIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitIdException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidPullRequestIdException | InvalidRepositoryNameException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryNotAssociatedWithPullRequestException | CommonErrors;
/**
 * Returns comments made on a pull request.
 *
 * Reaction counts might include numbers from user identities who were deleted after the reaction was made. For a count of
 * reactions from active identities, use GetCommentReactions.
 */
export declare const getCommentsForPullRequest: API.PaginatedOperationMethod<GetCommentsForPullRequestInput, GetCommentsForPullRequestOutput, GetCommentsForPullRequestError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCommitError = CommitIdDoesNotExistException | CommitIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitIdException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about a commit, including commit message and committer information.
 */
export declare const getCommit: API.OperationMethod<GetCommitInput, GetCommitOutput, GetCommitError, Credentials | HttpClient.HttpClient>;
export type GetDifferencesError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitException | InvalidCommitIdException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidPathException | InvalidRepositoryNameException | PathDoesNotExistException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about the differences in a valid commit specifier (such as a
 * branch, tag, HEAD, commit ID, or other fully qualified reference). Results can be
 * limited to a specified path.
 *
 * For line-level diff details, pass the `beforeBlob.blobId` and
 * `afterBlob.blobId` values from a `Difference` object to GetBlobDifferences.
 */
export declare const getDifferences: API.PaginatedOperationMethod<GetDifferencesInput, GetDifferencesOutput, GetDifferencesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetFileError = CommitDoesNotExistException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileDoesNotExistException | FileTooLargeException | InvalidCommitException | InvalidPathException | InvalidRepositoryNameException | PathRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns the base-64 encoded contents of a specified file and its metadata.
 */
export declare const getFile: API.OperationMethod<GetFileInput, GetFileOutput, GetFileError, Credentials | HttpClient.HttpClient>;
export type GetFolderError = CommitDoesNotExistException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FolderDoesNotExistException | InvalidCommitException | InvalidPathException | InvalidRepositoryNameException | PathRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns the contents of a specified folder in a repository.
 */
export declare const getFolder: API.OperationMethod<GetFolderInput, GetFolderOutput, GetFolderError, Credentials | HttpClient.HttpClient>;
export type GetMergeCommitError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionStrategyException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about a specified merge commit.
 */
export declare const getMergeCommit: API.OperationMethod<GetMergeCommitInput, GetMergeCommitOutput, GetMergeCommitError, Credentials | HttpClient.HttpClient>;
export type GetMergeConflictsError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionStrategyException | InvalidContinuationTokenException | InvalidDestinationCommitSpecifierException | InvalidMaxConflictFilesException | InvalidMergeOptionException | InvalidRepositoryNameException | InvalidSourceCommitSpecifierException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MergeOptionRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Returns information about merge conflicts between the before and after commit IDs for a pull request in a repository.
 */
export declare const getMergeConflicts: API.PaginatedOperationMethod<GetMergeConflictsInput, GetMergeConflictsOutput, GetMergeConflictsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetMergeOptionsError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionStrategyException | InvalidRepositoryNameException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Returns information about the merge options available for merging two specified
 * branches. For details about why a merge option is not available, use GetMergeConflicts
 * or DescribeMergeConflicts.
 */
export declare const getMergeOptions: API.OperationMethod<GetMergeOptionsInput, GetMergeOptionsOutput, GetMergeOptionsError, Credentials | HttpClient.HttpClient>;
export type GetPullRequestError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidPullRequestIdException | PullRequestDoesNotExistException | PullRequestIdRequiredException | CommonErrors;
/**
 * Gets information about a pull request in a specified repository.
 */
export declare const getPullRequest: API.OperationMethod<GetPullRequestInput, GetPullRequestOutput, GetPullRequestError, Credentials | HttpClient.HttpClient>;
export type GetPullRequestApprovalStatesError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidPullRequestIdException | InvalidRevisionIdException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RevisionIdRequiredException | CommonErrors;
/**
 * Gets information about the approval states for a specified pull request. Approval states only apply to pull requests that have one or more
 * approval rules applied to them.
 */
export declare const getPullRequestApprovalStates: API.OperationMethod<GetPullRequestApprovalStatesInput, GetPullRequestApprovalStatesOutput, GetPullRequestApprovalStatesError, Credentials | HttpClient.HttpClient>;
export type GetPullRequestOverrideStateError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidPullRequestIdException | InvalidRevisionIdException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RevisionIdRequiredException | CommonErrors;
/**
 * Returns information about whether approval rules have been set aside (overridden) for a
 * pull request, and if so, the Amazon Resource Name (ARN) of the user or identity that overrode the rules and their requirements for the pull request.
 */
export declare const getPullRequestOverrideState: API.OperationMethod<GetPullRequestOverrideStateInput, GetPullRequestOverrideStateOutput, GetPullRequestOverrideStateError, Credentials | HttpClient.HttpClient>;
export type GetRepositoryError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about a repository.
 *
 * The description field for a repository accepts all HTML characters and all valid
 * Unicode characters. Applications that do not HTML-encode the description and display
 * it in a webpage can expose users to potentially malicious code. Make sure that you
 * HTML-encode the description field in any application that uses this API to display
 * the repository description on a webpage.
 */
export declare const getRepository: API.OperationMethod<GetRepositoryInput, GetRepositoryOutput, GetRepositoryError, Credentials | HttpClient.HttpClient>;
export type GetRepositoryTriggersError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Gets information about triggers configured for a repository.
 */
export declare const getRepositoryTriggers: API.OperationMethod<GetRepositoryTriggersInput, GetRepositoryTriggersOutput, GetRepositoryTriggersError, Credentials | HttpClient.HttpClient>;
export type ListApprovalRuleTemplatesError = InvalidContinuationTokenException | InvalidMaxResultsException | CommonErrors;
/**
 * Lists all approval rule templates in the specified Amazon Web Services Region in your Amazon Web Services account. If
 * an Amazon Web Services Region is not specified, the Amazon Web Services Region where you are signed in is used.
 */
export declare const listApprovalRuleTemplates: API.PaginatedOperationMethod<ListApprovalRuleTemplatesInput, ListApprovalRuleTemplatesOutput, ListApprovalRuleTemplatesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAssociatedApprovalRuleTemplatesForRepositoryError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Lists all approval rule templates that are associated with a specified repository.
 */
export declare const listAssociatedApprovalRuleTemplatesForRepository: API.PaginatedOperationMethod<ListAssociatedApprovalRuleTemplatesForRepositoryInput, ListAssociatedApprovalRuleTemplatesForRepositoryOutput, ListAssociatedApprovalRuleTemplatesForRepositoryError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBranchesError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidContinuationTokenException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Gets information about one or more branches in a repository.
 */
export declare const listBranches: API.PaginatedOperationMethod<ListBranchesInput, ListBranchesOutput, ListBranchesError, Credentials | HttpClient.HttpClient, BranchName>;
export type ListFileCommitHistoryError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Retrieves a list of commits and changes to a specified file.
 */
export declare const listFileCommitHistory: API.PaginatedOperationMethod<ListFileCommitHistoryRequest, ListFileCommitHistoryResponse, ListFileCommitHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPullRequestsError = AuthorDoesNotExistException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidAuthorArnException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidPullRequestStatusException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns a list of pull requests for a specified repository. The return list can be refined by pull request
 * status or pull request author ARN.
 */
export declare const listPullRequests: API.PaginatedOperationMethod<ListPullRequestsInput, ListPullRequestsOutput, ListPullRequestsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRepositoriesError = InvalidContinuationTokenException | InvalidOrderException | InvalidSortByException | CommonErrors;
/**
 * Gets information about one or more repositories.
 */
export declare const listRepositories: API.PaginatedOperationMethod<ListRepositoriesInput, ListRepositoriesOutput, ListRepositoriesError, Credentials | HttpClient.HttpClient, RepositoryNameIdPair>;
export type ListRepositoriesForApprovalRuleTemplateError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleTemplateNameException | InvalidContinuationTokenException | InvalidMaxResultsException | CommonErrors;
/**
 * Lists all repositories associated with the specified approval rule template.
 */
export declare const listRepositoriesForApprovalRuleTemplate: API.PaginatedOperationMethod<ListRepositoriesForApprovalRuleTemplateInput, ListRepositoriesForApprovalRuleTemplateOutput, ListRepositoriesForApprovalRuleTemplateError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InvalidRepositoryNameException | InvalidResourceArnException | RepositoryDoesNotExistException | ResourceArnRequiredException | CommonErrors;
/**
 * Gets information about Amazon Web Servicestags for a specified Amazon Resource Name (ARN) in CodeCommit. For a list of valid resources in CodeCommit, see CodeCommit Resources and Operations in the CodeCommit User
 * Guide.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type MergeBranchesByFastForwardError = BranchDoesNotExistException | BranchNameIsTagNameException | BranchNameRequiredException | CommitDoesNotExistException | CommitRequiredException | ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidBranchNameException | InvalidCommitException | InvalidRepositoryNameException | InvalidTargetBranchException | ManualMergeRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Merges two branches using the fast-forward merge strategy.
 */
export declare const mergeBranchesByFastForward: API.OperationMethod<MergeBranchesByFastForwardInput, MergeBranchesByFastForwardOutput, MergeBranchesByFastForwardError, Credentials | HttpClient.HttpClient>;
export type MergeBranchesBySquashError = BranchDoesNotExistException | BranchNameIsTagNameException | BranchNameRequiredException | CommitDoesNotExistException | CommitMessageLengthExceededException | CommitRequiredException | ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentSizeLimitExceededException | FileModeRequiredException | FolderContentSizeLimitExceededException | InvalidBranchNameException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionException | InvalidConflictResolutionStrategyException | InvalidEmailException | InvalidFileModeException | InvalidPathException | InvalidReplacementContentException | InvalidReplacementTypeException | InvalidRepositoryNameException | InvalidTargetBranchException | ManualMergeRequiredException | MaximumConflictResolutionEntriesExceededException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MultipleConflictResolutionEntriesException | NameLengthExceededException | PathRequiredException | ReplacementContentRequiredException | ReplacementTypeRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Merges two branches using the squash merge strategy.
 */
export declare const mergeBranchesBySquash: API.OperationMethod<MergeBranchesBySquashInput, MergeBranchesBySquashOutput, MergeBranchesBySquashError, Credentials | HttpClient.HttpClient>;
export type MergeBranchesByThreeWayError = BranchDoesNotExistException | BranchNameIsTagNameException | BranchNameRequiredException | CommitDoesNotExistException | CommitMessageLengthExceededException | CommitRequiredException | ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentSizeLimitExceededException | FileModeRequiredException | FolderContentSizeLimitExceededException | InvalidBranchNameException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionException | InvalidConflictResolutionStrategyException | InvalidEmailException | InvalidFileModeException | InvalidPathException | InvalidReplacementContentException | InvalidReplacementTypeException | InvalidRepositoryNameException | InvalidTargetBranchException | ManualMergeRequiredException | MaximumConflictResolutionEntriesExceededException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MultipleConflictResolutionEntriesException | NameLengthExceededException | PathRequiredException | ReplacementContentRequiredException | ReplacementTypeRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Merges two specified branches using the three-way merge strategy.
 */
export declare const mergeBranchesByThreeWay: API.OperationMethod<MergeBranchesByThreeWayInput, MergeBranchesByThreeWayOutput, MergeBranchesByThreeWayError, Credentials | HttpClient.HttpClient>;
export type MergePullRequestByFastForwardError = ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitIdException | InvalidPullRequestIdException | InvalidRepositoryNameException | ManualMergeRequiredException | PullRequestAlreadyClosedException | PullRequestApprovalRulesNotSatisfiedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | ReferenceDoesNotExistException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryNotAssociatedWithPullRequestException | TipOfSourceReferenceIsDifferentException | CommonErrors;
/**
 * Attempts to merge the source commit of a pull request into the specified destination
 * branch for that pull request at the specified commit using the fast-forward merge strategy. If the merge is successful, it closes the pull request.
 */
export declare const mergePullRequestByFastForward: API.OperationMethod<MergePullRequestByFastForwardInput, MergePullRequestByFastForwardOutput, MergePullRequestByFastForwardError, Credentials | HttpClient.HttpClient>;
export type MergePullRequestBySquashError = CommitMessageLengthExceededException | ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentSizeLimitExceededException | FolderContentSizeLimitExceededException | InvalidCommitIdException | InvalidConflictDetailLevelException | InvalidConflictResolutionException | InvalidConflictResolutionStrategyException | InvalidEmailException | InvalidFileModeException | InvalidPathException | InvalidPullRequestIdException | InvalidReplacementContentException | InvalidReplacementTypeException | InvalidRepositoryNameException | ManualMergeRequiredException | MaximumConflictResolutionEntriesExceededException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MultipleConflictResolutionEntriesException | NameLengthExceededException | PathRequiredException | PullRequestAlreadyClosedException | PullRequestApprovalRulesNotSatisfiedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | ReplacementContentRequiredException | ReplacementTypeRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryNotAssociatedWithPullRequestException | TipOfSourceReferenceIsDifferentException | TipsDivergenceExceededException | CommonErrors;
/**
 * Attempts to merge the source commit of a pull request into the specified destination
 * branch for that pull request at the specified commit using the squash merge strategy. If the merge is successful, it closes the pull request.
 */
export declare const mergePullRequestBySquash: API.OperationMethod<MergePullRequestBySquashInput, MergePullRequestBySquashOutput, MergePullRequestBySquashError, Credentials | HttpClient.HttpClient>;
export type MergePullRequestByThreeWayError = CommitMessageLengthExceededException | ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentSizeLimitExceededException | FolderContentSizeLimitExceededException | InvalidCommitIdException | InvalidConflictDetailLevelException | InvalidConflictResolutionException | InvalidConflictResolutionStrategyException | InvalidEmailException | InvalidFileModeException | InvalidPathException | InvalidPullRequestIdException | InvalidReplacementContentException | InvalidReplacementTypeException | InvalidRepositoryNameException | ManualMergeRequiredException | MaximumConflictResolutionEntriesExceededException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MultipleConflictResolutionEntriesException | NameLengthExceededException | PathRequiredException | PullRequestAlreadyClosedException | PullRequestApprovalRulesNotSatisfiedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | ReplacementContentRequiredException | ReplacementTypeRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryNotAssociatedWithPullRequestException | TipOfSourceReferenceIsDifferentException | TipsDivergenceExceededException | CommonErrors;
/**
 * Attempts to merge the source commit of a pull request into the specified destination
 * branch for that pull request at the specified commit using the three-way merge strategy. If the merge is successful, it closes the pull request.
 */
export declare const mergePullRequestByThreeWay: API.OperationMethod<MergePullRequestByThreeWayInput, MergePullRequestByThreeWayOutput, MergePullRequestByThreeWayError, Credentials | HttpClient.HttpClient>;
export type OverridePullRequestApprovalRulesError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidOverrideStatusException | InvalidPullRequestIdException | InvalidRevisionIdException | OverrideAlreadySetException | OverrideStatusRequiredException | PullRequestAlreadyClosedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RevisionIdRequiredException | RevisionNotCurrentException | CommonErrors;
/**
 * Sets aside (overrides) all approval rule requirements for a specified pull request.
 */
export declare const overridePullRequestApprovalRules: API.OperationMethod<OverridePullRequestApprovalRulesInput, OverridePullRequestApprovalRulesResponse, OverridePullRequestApprovalRulesError, Credentials | HttpClient.HttpClient>;
export type PostCommentForComparedCommitError = BeforeCommitIdAndAfterCommitIdAreSameException | ClientRequestTokenRequiredException | CommentContentRequiredException | CommentContentSizeLimitExceededException | CommitDoesNotExistException | CommitIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | IdempotencyParameterMismatchException | InvalidClientRequestTokenException | InvalidCommitIdException | InvalidFileLocationException | InvalidFilePositionException | InvalidPathException | InvalidRelativeFileVersionEnumException | InvalidRepositoryNameException | PathDoesNotExistException | PathRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Posts a comment on the comparison between two commits.
 */
export declare const postCommentForComparedCommit: API.OperationMethod<PostCommentForComparedCommitInput, PostCommentForComparedCommitOutput, PostCommentForComparedCommitError, Credentials | HttpClient.HttpClient>;
export type PostCommentForPullRequestError = BeforeCommitIdAndAfterCommitIdAreSameException | ClientRequestTokenRequiredException | CommentContentRequiredException | CommentContentSizeLimitExceededException | CommitDoesNotExistException | CommitIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | IdempotencyParameterMismatchException | InvalidClientRequestTokenException | InvalidCommitIdException | InvalidFileLocationException | InvalidFilePositionException | InvalidPathException | InvalidPullRequestIdException | InvalidRelativeFileVersionEnumException | InvalidRepositoryNameException | PathDoesNotExistException | PathRequiredException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryNotAssociatedWithPullRequestException | CommonErrors;
/**
 * Posts a comment on a pull request.
 */
export declare const postCommentForPullRequest: API.OperationMethod<PostCommentForPullRequestInput, PostCommentForPullRequestOutput, PostCommentForPullRequestError, Credentials | HttpClient.HttpClient>;
export type PostCommentReplyError = ClientRequestTokenRequiredException | CommentContentRequiredException | CommentContentSizeLimitExceededException | CommentDoesNotExistException | CommentIdRequiredException | IdempotencyParameterMismatchException | InvalidClientRequestTokenException | InvalidCommentIdException | CommonErrors;
/**
 * Posts a comment in reply to an existing comment on a comparison between commits or a pull request.
 */
export declare const postCommentReply: API.OperationMethod<PostCommentReplyInput, PostCommentReplyOutput, PostCommentReplyError, Credentials | HttpClient.HttpClient>;
export type PutCommentReactionError = CommentDeletedException | CommentDoesNotExistException | CommentIdRequiredException | InvalidCommentIdException | InvalidReactionValueException | ReactionLimitExceededException | ReactionValueRequiredException | CommonErrors;
/**
 * Adds or updates a reaction to a specified comment for the user whose identity is used to make the request. You can only add or
 * update a reaction for yourself. You cannot add, modify, or delete a reaction for another user.
 */
export declare const putCommentReaction: API.OperationMethod<PutCommentReactionInput, PutCommentReactionResponse, PutCommentReactionError, Credentials | HttpClient.HttpClient>;
export type PutFileError = BranchDoesNotExistException | BranchNameIsTagNameException | BranchNameRequiredException | CommitMessageLengthExceededException | DirectoryNameConflictsWithFileNameException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentRequiredException | FileContentSizeLimitExceededException | FileNameConflictsWithDirectoryNameException | FilePathConflictsWithSubmodulePathException | FolderContentSizeLimitExceededException | InvalidBranchNameException | InvalidDeletionParameterException | InvalidEmailException | InvalidFileModeException | InvalidParentCommitIdException | InvalidPathException | InvalidRepositoryNameException | NameLengthExceededException | ParentCommitDoesNotExistException | ParentCommitIdOutdatedException | ParentCommitIdRequiredException | PathRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | SameFileContentException | CommonErrors;
/**
 * Adds or updates a file in a branch in an CodeCommit repository, and generates a commit for the addition in the specified branch.
 */
export declare const putFile: API.OperationMethod<PutFileInput, PutFileOutput, PutFileError, Credentials | HttpClient.HttpClient>;
export type PutRepositoryTriggersError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | InvalidRepositoryTriggerBranchNameException | InvalidRepositoryTriggerCustomDataException | InvalidRepositoryTriggerDestinationArnException | InvalidRepositoryTriggerEventsException | InvalidRepositoryTriggerNameException | InvalidRepositoryTriggerRegionException | MaximumBranchesExceededException | MaximumRepositoryTriggersExceededException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryTriggerBranchNameListRequiredException | RepositoryTriggerDestinationArnRequiredException | RepositoryTriggerEventsListRequiredException | RepositoryTriggerNameRequiredException | RepositoryTriggersListRequiredException | CommonErrors;
/**
 * Replaces all triggers for a repository. Used to create or delete triggers.
 */
export declare const putRepositoryTriggers: API.OperationMethod<PutRepositoryTriggersInput, PutRepositoryTriggersOutput, PutRepositoryTriggersError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidRepositoryNameException | InvalidResourceArnException | InvalidSystemTagUsageException | InvalidTagsMapException | RepositoryDoesNotExistException | ResourceArnRequiredException | TagPolicyException | TagsMapRequiredException | TooManyTagsException | CommonErrors;
/**
 * Adds or updates tags for a resource in CodeCommit. For a list of valid resources
 * in CodeCommit, see CodeCommit Resources and Operations in the CodeCommit User
 * Guide.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestRepositoryTriggersError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | InvalidRepositoryTriggerBranchNameException | InvalidRepositoryTriggerCustomDataException | InvalidRepositoryTriggerDestinationArnException | InvalidRepositoryTriggerEventsException | InvalidRepositoryTriggerNameException | InvalidRepositoryTriggerRegionException | MaximumBranchesExceededException | MaximumRepositoryTriggersExceededException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryTriggerBranchNameListRequiredException | RepositoryTriggerDestinationArnRequiredException | RepositoryTriggerEventsListRequiredException | RepositoryTriggerNameRequiredException | RepositoryTriggersListRequiredException | CommonErrors;
/**
 * Tests the functionality of repository triggers by sending information to the trigger
 * target. If real data is available in the repository, the test sends data from the last
 * commit. If no data is available, sample data is generated.
 */
export declare const testRepositoryTriggers: API.OperationMethod<TestRepositoryTriggersInput, TestRepositoryTriggersOutput, TestRepositoryTriggersError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidRepositoryNameException | InvalidResourceArnException | InvalidSystemTagUsageException | InvalidTagKeysListException | RepositoryDoesNotExistException | ResourceArnRequiredException | TagKeysListRequiredException | TagPolicyException | TooManyTagsException | CommonErrors;
/**
 * Removes tags for a resource in CodeCommit. For a list of valid resources in CodeCommit, see CodeCommit Resources and Operations in the CodeCommit User
 * Guide.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApprovalRuleTemplateContentError = ApprovalRuleTemplateContentRequiredException | ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | InvalidApprovalRuleTemplateContentException | InvalidApprovalRuleTemplateNameException | InvalidRuleContentSha256Exception | CommonErrors;
/**
 * Updates the content of an approval rule template. You can change the number of
 * required approvals, the membership of the approval rule, and whether an approval pool is
 * defined.
 */
export declare const updateApprovalRuleTemplateContent: API.OperationMethod<UpdateApprovalRuleTemplateContentInput, UpdateApprovalRuleTemplateContentOutput, UpdateApprovalRuleTemplateContentError, Credentials | HttpClient.HttpClient>;
export type UpdateApprovalRuleTemplateDescriptionError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | InvalidApprovalRuleTemplateDescriptionException | InvalidApprovalRuleTemplateNameException | CommonErrors;
/**
 * Updates the description for a specified approval rule template.
 */
export declare const updateApprovalRuleTemplateDescription: API.OperationMethod<UpdateApprovalRuleTemplateDescriptionInput, UpdateApprovalRuleTemplateDescriptionOutput, UpdateApprovalRuleTemplateDescriptionError, Credentials | HttpClient.HttpClient>;
export type UpdateApprovalRuleTemplateNameError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameAlreadyExistsException | ApprovalRuleTemplateNameRequiredException | InvalidApprovalRuleTemplateNameException | CommonErrors;
/**
 * Updates the name of a specified approval rule template.
 */
export declare const updateApprovalRuleTemplateName: API.OperationMethod<UpdateApprovalRuleTemplateNameInput, UpdateApprovalRuleTemplateNameOutput, UpdateApprovalRuleTemplateNameError, Credentials | HttpClient.HttpClient>;
export type UpdateCommentError = CommentContentRequiredException | CommentContentSizeLimitExceededException | CommentDeletedException | CommentDoesNotExistException | CommentIdRequiredException | CommentNotCreatedByCallerException | InvalidCommentIdException | CommonErrors;
/**
 * Replaces the contents of a comment.
 */
export declare const updateComment: API.OperationMethod<UpdateCommentInput, UpdateCommentOutput, UpdateCommentError, Credentials | HttpClient.HttpClient>;
export type UpdateDefaultBranchError = BranchDoesNotExistException | BranchNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidBranchNameException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Sets or changes the default branch name for the specified repository.
 *
 * If you use this operation to change the default branch name to the current default branch name, a success message is returned even though the default branch did not change.
 */
export declare const updateDefaultBranch: API.OperationMethod<UpdateDefaultBranchInput, UpdateDefaultBranchResponse, UpdateDefaultBranchError, Credentials | HttpClient.HttpClient>;
export type UpdatePullRequestApprovalRuleContentError = ApprovalRuleContentRequiredException | ApprovalRuleDoesNotExistException | ApprovalRuleNameRequiredException | CannotModifyApprovalRuleFromTemplateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleContentException | InvalidApprovalRuleNameException | InvalidPullRequestIdException | InvalidRuleContentSha256Exception | PullRequestAlreadyClosedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | CommonErrors;
/**
 * Updates the structure of an approval rule created specifically for a pull request. For example, you can change the number of required approvers and
 * the approval pool for approvers.
 */
export declare const updatePullRequestApprovalRuleContent: API.OperationMethod<UpdatePullRequestApprovalRuleContentInput, UpdatePullRequestApprovalRuleContentOutput, UpdatePullRequestApprovalRuleContentError, Credentials | HttpClient.HttpClient>;
export type UpdatePullRequestApprovalStateError = ApprovalStateRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalStateException | InvalidPullRequestIdException | InvalidRevisionIdException | MaximumNumberOfApprovalsExceededException | PullRequestAlreadyClosedException | PullRequestCannotBeApprovedByAuthorException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RevisionIdRequiredException | RevisionNotCurrentException | CommonErrors;
/**
 * Updates the state of a user's approval on a pull request. The user is derived from the signed-in account when the request is made.
 */
export declare const updatePullRequestApprovalState: API.OperationMethod<UpdatePullRequestApprovalStateInput, UpdatePullRequestApprovalStateResponse, UpdatePullRequestApprovalStateError, Credentials | HttpClient.HttpClient>;
export type UpdatePullRequestDescriptionError = InvalidDescriptionException | InvalidPullRequestIdException | PullRequestAlreadyClosedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | CommonErrors;
/**
 * Replaces the contents of the description of a pull request.
 */
export declare const updatePullRequestDescription: API.OperationMethod<UpdatePullRequestDescriptionInput, UpdatePullRequestDescriptionOutput, UpdatePullRequestDescriptionError, Credentials | HttpClient.HttpClient>;
export type UpdatePullRequestStatusError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidPullRequestIdException | InvalidPullRequestStatusException | InvalidPullRequestStatusUpdateException | PullRequestDoesNotExistException | PullRequestIdRequiredException | PullRequestStatusRequiredException | CommonErrors;
/**
 * Updates the status of a pull request.
 */
export declare const updatePullRequestStatus: API.OperationMethod<UpdatePullRequestStatusInput, UpdatePullRequestStatusOutput, UpdatePullRequestStatusError, Credentials | HttpClient.HttpClient>;
export type UpdatePullRequestTitleError = InvalidPullRequestIdException | InvalidTitleException | PullRequestAlreadyClosedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | TitleRequiredException | CommonErrors;
/**
 * Replaces the title of a pull request.
 */
export declare const updatePullRequestTitle: API.OperationMethod<UpdatePullRequestTitleInput, UpdatePullRequestTitleOutput, UpdatePullRequestTitleError, Credentials | HttpClient.HttpClient>;
export type UpdateRepositoryDescriptionError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryDescriptionException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Sets or changes the comment or description for a repository.
 *
 * The description field for a repository accepts all HTML characters and all valid
 * Unicode characters. Applications that do not HTML-encode the description and display
 * it in a webpage can expose users to potentially malicious code. Make sure that you
 * HTML-encode the description field in any application that uses this API to display
 * the repository description on a webpage.
 */
export declare const updateRepositoryDescription: API.OperationMethod<UpdateRepositoryDescriptionInput, UpdateRepositoryDescriptionResponse, UpdateRepositoryDescriptionError, Credentials | HttpClient.HttpClient>;
export type UpdateRepositoryEncryptionKeyError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyInvalidIdException | EncryptionKeyInvalidUsageException | EncryptionKeyNotFoundException | EncryptionKeyRequiredException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Updates the Key Management Service encryption key used to encrypt and decrypt a CodeCommit repository.
 */
export declare const updateRepositoryEncryptionKey: API.OperationMethod<UpdateRepositoryEncryptionKeyInput, UpdateRepositoryEncryptionKeyOutput, UpdateRepositoryEncryptionKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateRepositoryNameError = InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameExistsException | RepositoryNameRequiredException | CommonErrors;
/**
 * Renames a repository. The repository name must be unique across the calling Amazon Web Services account.
 * Repository names are limited to 100 alphanumeric, dash, and underscore
 * characters, and cannot include certain characters. The suffix .git is prohibited. For
 * more information about the limits on repository names, see Quotas in the CodeCommit
 * User Guide.
 */
export declare const updateRepositoryName: API.OperationMethod<UpdateRepositoryNameInput, UpdateRepositoryNameResponse, UpdateRepositoryNameError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codecommit.d.ts.map