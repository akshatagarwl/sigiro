import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BaseException_base: S.Class<BaseException, S.TaggedStruct<"BaseException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BaseException extends /*@__PURE__*/ BaseException_base {
}
declare const DisabledOperationException_base: S.Class<DisabledOperationException, S.TaggedStruct<"DisabledOperationException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DisabledOperationException extends /*@__PURE__*/ DisabledOperationException_base {
}
declare const InternalException_base: S.Class<InternalException, S.TaggedStruct<"InternalException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InvalidTypeException_base: S.Class<InvalidTypeException, S.TaggedStruct<"InvalidTypeException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidTypeException extends /*@__PURE__*/ InvalidTypeException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.Class<ResourceAlreadyExistsException, S.TaggedStruct<"ResourceAlreadyExistsException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly Code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DomainName = string;
export interface BuildSuggestersRequest {
    DomainName: string;
}
export declare const BuildSuggestersRequest: S.Schema<BuildSuggestersRequest>;
export type FieldName = string;
export type FieldNameList = string[];
export declare const FieldNameList: any;
export interface BuildSuggestersResponse {
    FieldNames?: string[];
}
export declare const BuildSuggestersResponse: S.Schema<BuildSuggestersResponse>;
export interface CreateDomainRequest {
    DomainName: string;
}
export declare const CreateDomainRequest: S.Schema<CreateDomainRequest>;
export type DomainId = string;
export type ARN = string;
export type ServiceUrl = string;
export interface ServiceEndpoint {
    Endpoint?: string;
}
export declare const ServiceEndpoint: S.Schema<ServiceEndpoint>;
export type SearchInstanceType = string;
export type PartitionCount = number;
export type InstanceCount = number;
export type MaximumReplicationCount = number;
export type MaximumPartitionCount = number;
export interface Limits {
    MaximumReplicationCount: number;
    MaximumPartitionCount: number;
}
export declare const Limits: S.Schema<Limits>;
export interface DomainStatus {
    DomainId: string;
    DomainName: string;
    ARN?: string;
    Created?: boolean;
    Deleted?: boolean;
    DocService?: ServiceEndpoint;
    SearchService?: ServiceEndpoint;
    RequiresIndexDocuments: boolean;
    Processing?: boolean;
    SearchInstanceType?: string;
    SearchPartitionCount?: number;
    SearchInstanceCount?: number;
    Limits?: Limits;
}
export declare const DomainStatus: S.Schema<DomainStatus>;
export interface CreateDomainResponse {
    DomainStatus?: DomainStatus;
}
export declare const CreateDomainResponse: S.Schema<CreateDomainResponse>;
export type StandardName = string;
export type AnalysisSchemeLanguage = "ar" | "bg" | "ca" | "cs" | "da" | "de" | "el" | "en" | "es" | "eu" | "fa" | "fi" | "fr" | "ga" | "gl" | "he" | "hi" | "hu" | "hy" | "id" | "it" | "ja" | "ko" | "lv" | "mul" | "nl" | "no" | "pt" | "ro" | "ru" | "sv" | "th" | "tr" | "zh-Hans" | "zh-Hant" | (string & {});
export declare const AnalysisSchemeLanguage: any;
export type AlgorithmicStemming = "none" | "minimal" | "light" | "full" | (string & {});
export declare const AlgorithmicStemming: any;
export interface AnalysisOptions {
    Synonyms?: string;
    Stopwords?: string;
    StemmingDictionary?: string;
    JapaneseTokenizationDictionary?: string;
    AlgorithmicStemming?: AlgorithmicStemming;
}
export declare const AnalysisOptions: S.Schema<AnalysisOptions>;
export interface AnalysisScheme {
    AnalysisSchemeName: string;
    AnalysisSchemeLanguage: AnalysisSchemeLanguage;
    AnalysisOptions?: AnalysisOptions;
}
export declare const AnalysisScheme: S.Schema<AnalysisScheme>;
export interface DefineAnalysisSchemeRequest {
    DomainName: string;
    AnalysisScheme: AnalysisScheme;
}
export declare const DefineAnalysisSchemeRequest: S.Schema<DefineAnalysisSchemeRequest>;
export type UpdateTimestamp = Date;
export type UIntValue = number;
export type OptionState = "RequiresIndexDocuments" | "Processing" | "Active" | "FailedToValidate" | (string & {});
export declare const OptionState: any;
export interface OptionStatus {
    CreationDate: Date;
    UpdateDate: Date;
    UpdateVersion?: number;
    State: OptionState;
    PendingDeletion?: boolean;
}
export declare const OptionStatus: S.Schema<OptionStatus>;
export interface AnalysisSchemeStatus {
    Options: AnalysisScheme;
    Status: OptionStatus;
}
export declare const AnalysisSchemeStatus: S.Schema<AnalysisSchemeStatus>;
export interface DefineAnalysisSchemeResponse {
    AnalysisScheme: AnalysisSchemeStatus;
}
export declare const DefineAnalysisSchemeResponse: S.Schema<DefineAnalysisSchemeResponse>;
export type ExpressionValue = string;
export interface Expression {
    ExpressionName: string;
    ExpressionValue: string;
}
export declare const Expression: S.Schema<Expression>;
export interface DefineExpressionRequest {
    DomainName: string;
    Expression: Expression;
}
export declare const DefineExpressionRequest: S.Schema<DefineExpressionRequest>;
export interface ExpressionStatus {
    Options: Expression;
    Status: OptionStatus;
}
export declare const ExpressionStatus: S.Schema<ExpressionStatus>;
export interface DefineExpressionResponse {
    Expression: ExpressionStatus;
}
export declare const DefineExpressionResponse: S.Schema<DefineExpressionResponse>;
export type DynamicFieldName = string;
export type IndexFieldType = "int" | "double" | "literal" | "text" | "date" | "latlon" | "int-array" | "double-array" | "literal-array" | "text-array" | "date-array" | (string & {});
export declare const IndexFieldType: any;
export interface IntOptions {
    DefaultValue?: number;
    SourceField?: string;
    FacetEnabled?: boolean;
    SearchEnabled?: boolean;
    ReturnEnabled?: boolean;
    SortEnabled?: boolean;
}
export declare const IntOptions: S.Schema<IntOptions>;
export interface DoubleOptions {
    DefaultValue?: number;
    SourceField?: string;
    FacetEnabled?: boolean;
    SearchEnabled?: boolean;
    ReturnEnabled?: boolean;
    SortEnabled?: boolean;
}
export declare const DoubleOptions: S.Schema<DoubleOptions>;
export type FieldValue = string;
export interface LiteralOptions {
    DefaultValue?: string;
    SourceField?: string;
    FacetEnabled?: boolean;
    SearchEnabled?: boolean;
    ReturnEnabled?: boolean;
    SortEnabled?: boolean;
}
export declare const LiteralOptions: S.Schema<LiteralOptions>;
export type Word = string;
export interface TextOptions {
    DefaultValue?: string;
    SourceField?: string;
    ReturnEnabled?: boolean;
    SortEnabled?: boolean;
    HighlightEnabled?: boolean;
    AnalysisScheme?: string;
}
export declare const TextOptions: S.Schema<TextOptions>;
export interface DateOptions {
    DefaultValue?: string;
    SourceField?: string;
    FacetEnabled?: boolean;
    SearchEnabled?: boolean;
    ReturnEnabled?: boolean;
    SortEnabled?: boolean;
}
export declare const DateOptions: S.Schema<DateOptions>;
export interface LatLonOptions {
    DefaultValue?: string;
    SourceField?: string;
    FacetEnabled?: boolean;
    SearchEnabled?: boolean;
    ReturnEnabled?: boolean;
    SortEnabled?: boolean;
}
export declare const LatLonOptions: S.Schema<LatLonOptions>;
export type FieldNameCommaList = string;
export interface IntArrayOptions {
    DefaultValue?: number;
    SourceFields?: string;
    FacetEnabled?: boolean;
    SearchEnabled?: boolean;
    ReturnEnabled?: boolean;
}
export declare const IntArrayOptions: S.Schema<IntArrayOptions>;
export interface DoubleArrayOptions {
    DefaultValue?: number;
    SourceFields?: string;
    FacetEnabled?: boolean;
    SearchEnabled?: boolean;
    ReturnEnabled?: boolean;
}
export declare const DoubleArrayOptions: S.Schema<DoubleArrayOptions>;
export interface LiteralArrayOptions {
    DefaultValue?: string;
    SourceFields?: string;
    FacetEnabled?: boolean;
    SearchEnabled?: boolean;
    ReturnEnabled?: boolean;
}
export declare const LiteralArrayOptions: S.Schema<LiteralArrayOptions>;
export interface TextArrayOptions {
    DefaultValue?: string;
    SourceFields?: string;
    ReturnEnabled?: boolean;
    HighlightEnabled?: boolean;
    AnalysisScheme?: string;
}
export declare const TextArrayOptions: S.Schema<TextArrayOptions>;
export interface DateArrayOptions {
    DefaultValue?: string;
    SourceFields?: string;
    FacetEnabled?: boolean;
    SearchEnabled?: boolean;
    ReturnEnabled?: boolean;
}
export declare const DateArrayOptions: S.Schema<DateArrayOptions>;
export interface IndexField {
    IndexFieldName: string;
    IndexFieldType: IndexFieldType;
    IntOptions?: IntOptions;
    DoubleOptions?: DoubleOptions;
    LiteralOptions?: LiteralOptions;
    TextOptions?: TextOptions;
    DateOptions?: DateOptions;
    LatLonOptions?: LatLonOptions;
    IntArrayOptions?: IntArrayOptions;
    DoubleArrayOptions?: DoubleArrayOptions;
    LiteralArrayOptions?: LiteralArrayOptions;
    TextArrayOptions?: TextArrayOptions;
    DateArrayOptions?: DateArrayOptions;
}
export declare const IndexField: S.Schema<IndexField>;
export interface DefineIndexFieldRequest {
    DomainName: string;
    IndexField: IndexField;
}
export declare const DefineIndexFieldRequest: S.Schema<DefineIndexFieldRequest>;
export interface IndexFieldStatus {
    Options: IndexField;
    Status: OptionStatus;
}
export declare const IndexFieldStatus: S.Schema<IndexFieldStatus>;
export interface DefineIndexFieldResponse {
    IndexField: IndexFieldStatus;
}
export declare const DefineIndexFieldResponse: S.Schema<DefineIndexFieldResponse>;
export type SuggesterFuzzyMatching = "none" | "low" | "high" | (string & {});
export declare const SuggesterFuzzyMatching: any;
export interface DocumentSuggesterOptions {
    SourceField: string;
    FuzzyMatching?: SuggesterFuzzyMatching;
    SortExpression?: string;
}
export declare const DocumentSuggesterOptions: S.Schema<DocumentSuggesterOptions>;
export interface Suggester {
    SuggesterName: string;
    DocumentSuggesterOptions: DocumentSuggesterOptions;
}
export declare const Suggester: S.Schema<Suggester>;
export interface DefineSuggesterRequest {
    DomainName: string;
    Suggester: Suggester;
}
export declare const DefineSuggesterRequest: S.Schema<DefineSuggesterRequest>;
export interface SuggesterStatus {
    Options: Suggester;
    Status: OptionStatus;
}
export declare const SuggesterStatus: S.Schema<SuggesterStatus>;
export interface DefineSuggesterResponse {
    Suggester: SuggesterStatus;
}
export declare const DefineSuggesterResponse: S.Schema<DefineSuggesterResponse>;
export interface DeleteAnalysisSchemeRequest {
    DomainName: string;
    AnalysisSchemeName: string;
}
export declare const DeleteAnalysisSchemeRequest: S.Schema<DeleteAnalysisSchemeRequest>;
export interface DeleteAnalysisSchemeResponse {
    AnalysisScheme: AnalysisSchemeStatus;
}
export declare const DeleteAnalysisSchemeResponse: S.Schema<DeleteAnalysisSchemeResponse>;
export interface DeleteDomainRequest {
    DomainName: string;
}
export declare const DeleteDomainRequest: S.Schema<DeleteDomainRequest>;
export interface DeleteDomainResponse {
    DomainStatus?: DomainStatus;
}
export declare const DeleteDomainResponse: S.Schema<DeleteDomainResponse>;
export interface DeleteExpressionRequest {
    DomainName: string;
    ExpressionName: string;
}
export declare const DeleteExpressionRequest: S.Schema<DeleteExpressionRequest>;
export interface DeleteExpressionResponse {
    Expression: ExpressionStatus;
}
export declare const DeleteExpressionResponse: S.Schema<DeleteExpressionResponse>;
export interface DeleteIndexFieldRequest {
    DomainName: string;
    IndexFieldName: string;
}
export declare const DeleteIndexFieldRequest: S.Schema<DeleteIndexFieldRequest>;
export interface DeleteIndexFieldResponse {
    IndexField: IndexFieldStatus;
}
export declare const DeleteIndexFieldResponse: S.Schema<DeleteIndexFieldResponse>;
export interface DeleteSuggesterRequest {
    DomainName: string;
    SuggesterName: string;
}
export declare const DeleteSuggesterRequest: S.Schema<DeleteSuggesterRequest>;
export interface DeleteSuggesterResponse {
    Suggester: SuggesterStatus;
}
export declare const DeleteSuggesterResponse: S.Schema<DeleteSuggesterResponse>;
export type StandardNameList = string[];
export declare const StandardNameList: any;
export interface DescribeAnalysisSchemesRequest {
    DomainName: string;
    AnalysisSchemeNames?: string[];
    Deployed?: boolean;
}
export declare const DescribeAnalysisSchemesRequest: S.Schema<DescribeAnalysisSchemesRequest>;
export type AnalysisSchemeStatusList = AnalysisSchemeStatus[];
export declare const AnalysisSchemeStatusList: any;
export interface DescribeAnalysisSchemesResponse {
    AnalysisSchemes: AnalysisSchemeStatus[];
}
export declare const DescribeAnalysisSchemesResponse: S.Schema<DescribeAnalysisSchemesResponse>;
export interface DescribeAvailabilityOptionsRequest {
    DomainName: string;
    Deployed?: boolean;
}
export declare const DescribeAvailabilityOptionsRequest: S.Schema<DescribeAvailabilityOptionsRequest>;
export type MultiAZ = boolean;
export interface AvailabilityOptionsStatus {
    Options: boolean;
    Status: OptionStatus;
}
export declare const AvailabilityOptionsStatus: S.Schema<AvailabilityOptionsStatus>;
export interface DescribeAvailabilityOptionsResponse {
    AvailabilityOptions?: AvailabilityOptionsStatus;
}
export declare const DescribeAvailabilityOptionsResponse: S.Schema<DescribeAvailabilityOptionsResponse>;
export interface DescribeDomainEndpointOptionsRequest {
    DomainName: string;
    Deployed?: boolean;
}
export declare const DescribeDomainEndpointOptionsRequest: S.Schema<DescribeDomainEndpointOptionsRequest>;
export type TLSSecurityPolicy = "Policy-Min-TLS-1-0-2019-07" | "Policy-Min-TLS-1-2-2019-07" | (string & {});
export declare const TLSSecurityPolicy: any;
export interface DomainEndpointOptions {
    EnforceHTTPS?: boolean;
    TLSSecurityPolicy?: TLSSecurityPolicy;
}
export declare const DomainEndpointOptions: S.Schema<DomainEndpointOptions>;
export interface DomainEndpointOptionsStatus {
    Options: DomainEndpointOptions;
    Status: OptionStatus;
}
export declare const DomainEndpointOptionsStatus: S.Schema<DomainEndpointOptionsStatus>;
export interface DescribeDomainEndpointOptionsResponse {
    DomainEndpointOptions?: DomainEndpointOptionsStatus;
}
export declare const DescribeDomainEndpointOptionsResponse: S.Schema<DescribeDomainEndpointOptionsResponse>;
export type DomainNameList = string[];
export declare const DomainNameList: any;
export interface DescribeDomainsRequest {
    DomainNames?: string[];
}
export declare const DescribeDomainsRequest: S.Schema<DescribeDomainsRequest>;
export type DomainStatusList = DomainStatus[];
export declare const DomainStatusList: any;
export interface DescribeDomainsResponse {
    DomainStatusList: DomainStatus[];
}
export declare const DescribeDomainsResponse: S.Schema<DescribeDomainsResponse>;
export interface DescribeExpressionsRequest {
    DomainName: string;
    ExpressionNames?: string[];
    Deployed?: boolean;
}
export declare const DescribeExpressionsRequest: S.Schema<DescribeExpressionsRequest>;
export type ExpressionStatusList = ExpressionStatus[];
export declare const ExpressionStatusList: any;
export interface DescribeExpressionsResponse {
    Expressions: ExpressionStatus[];
}
export declare const DescribeExpressionsResponse: S.Schema<DescribeExpressionsResponse>;
export type DynamicFieldNameList = string[];
export declare const DynamicFieldNameList: any;
export interface DescribeIndexFieldsRequest {
    DomainName: string;
    FieldNames?: string[];
    Deployed?: boolean;
}
export declare const DescribeIndexFieldsRequest: S.Schema<DescribeIndexFieldsRequest>;
export type IndexFieldStatusList = IndexFieldStatus[];
export declare const IndexFieldStatusList: any;
export interface DescribeIndexFieldsResponse {
    IndexFields: IndexFieldStatus[];
}
export declare const DescribeIndexFieldsResponse: S.Schema<DescribeIndexFieldsResponse>;
export interface DescribeScalingParametersRequest {
    DomainName: string;
}
export declare const DescribeScalingParametersRequest: S.Schema<DescribeScalingParametersRequest>;
export type PartitionInstanceType = "search.m1.small" | "search.m1.large" | "search.m2.xlarge" | "search.m2.2xlarge" | "search.m3.medium" | "search.m3.large" | "search.m3.xlarge" | "search.m3.2xlarge" | "search.small" | "search.medium" | "search.large" | "search.xlarge" | "search.2xlarge" | "search.previousgeneration.small" | "search.previousgeneration.large" | "search.previousgeneration.xlarge" | "search.previousgeneration.2xlarge" | (string & {});
export declare const PartitionInstanceType: any;
export interface ScalingParameters {
    DesiredInstanceType?: PartitionInstanceType;
    DesiredReplicationCount?: number;
    DesiredPartitionCount?: number;
}
export declare const ScalingParameters: S.Schema<ScalingParameters>;
export interface ScalingParametersStatus {
    Options: ScalingParameters;
    Status: OptionStatus;
}
export declare const ScalingParametersStatus: S.Schema<ScalingParametersStatus>;
export interface DescribeScalingParametersResponse {
    ScalingParameters: ScalingParametersStatus;
}
export declare const DescribeScalingParametersResponse: S.Schema<DescribeScalingParametersResponse>;
export interface DescribeServiceAccessPoliciesRequest {
    DomainName: string;
    Deployed?: boolean;
}
export declare const DescribeServiceAccessPoliciesRequest: S.Schema<DescribeServiceAccessPoliciesRequest>;
export type PolicyDocument = string;
export interface AccessPoliciesStatus {
    Options: string;
    Status: OptionStatus;
}
export declare const AccessPoliciesStatus: S.Schema<AccessPoliciesStatus>;
export interface DescribeServiceAccessPoliciesResponse {
    AccessPolicies: AccessPoliciesStatus;
}
export declare const DescribeServiceAccessPoliciesResponse: S.Schema<DescribeServiceAccessPoliciesResponse>;
export interface DescribeSuggestersRequest {
    DomainName: string;
    SuggesterNames?: string[];
    Deployed?: boolean;
}
export declare const DescribeSuggestersRequest: S.Schema<DescribeSuggestersRequest>;
export type SuggesterStatusList = SuggesterStatus[];
export declare const SuggesterStatusList: any;
export interface DescribeSuggestersResponse {
    Suggesters: SuggesterStatus[];
}
export declare const DescribeSuggestersResponse: S.Schema<DescribeSuggestersResponse>;
export interface IndexDocumentsRequest {
    DomainName: string;
}
export declare const IndexDocumentsRequest: S.Schema<IndexDocumentsRequest>;
export interface IndexDocumentsResponse {
    FieldNames?: string[];
}
export declare const IndexDocumentsResponse: S.Schema<IndexDocumentsResponse>;
export interface ListDomainNamesRequest {
}
export declare const ListDomainNamesRequest: S.Schema<ListDomainNamesRequest>;
export type APIVersion = string;
export type DomainNameMap = {
    [key: string]: string | undefined;
};
export declare const DomainNameMap: any;
export interface ListDomainNamesResponse {
    DomainNames?: {
        [key: string]: string | undefined;
    };
}
export declare const ListDomainNamesResponse: S.Schema<ListDomainNamesResponse>;
export interface UpdateAvailabilityOptionsRequest {
    DomainName: string;
    MultiAZ: boolean;
}
export declare const UpdateAvailabilityOptionsRequest: S.Schema<UpdateAvailabilityOptionsRequest>;
export interface UpdateAvailabilityOptionsResponse {
    AvailabilityOptions?: AvailabilityOptionsStatus;
}
export declare const UpdateAvailabilityOptionsResponse: S.Schema<UpdateAvailabilityOptionsResponse>;
export interface UpdateDomainEndpointOptionsRequest {
    DomainName: string;
    DomainEndpointOptions: DomainEndpointOptions;
}
export declare const UpdateDomainEndpointOptionsRequest: S.Schema<UpdateDomainEndpointOptionsRequest>;
export interface UpdateDomainEndpointOptionsResponse {
    DomainEndpointOptions?: DomainEndpointOptionsStatus;
}
export declare const UpdateDomainEndpointOptionsResponse: S.Schema<UpdateDomainEndpointOptionsResponse>;
export interface UpdateScalingParametersRequest {
    DomainName: string;
    ScalingParameters: ScalingParameters;
}
export declare const UpdateScalingParametersRequest: S.Schema<UpdateScalingParametersRequest>;
export interface UpdateScalingParametersResponse {
    ScalingParameters: ScalingParametersStatus;
}
export declare const UpdateScalingParametersResponse: S.Schema<UpdateScalingParametersResponse>;
export interface UpdateServiceAccessPoliciesRequest {
    DomainName: string;
    AccessPolicies: string;
}
export declare const UpdateServiceAccessPoliciesRequest: S.Schema<UpdateServiceAccessPoliciesRequest>;
export interface UpdateServiceAccessPoliciesResponse {
    AccessPolicies: AccessPoliciesStatus;
}
export declare const UpdateServiceAccessPoliciesResponse: S.Schema<UpdateServiceAccessPoliciesResponse>;
export type ErrorCode = string;
export type ErrorMessage = string;
export type BuildSuggestersError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Indexes the search suggestions. For more information, see Configuring Suggesters in the *Amazon CloudSearch Developer Guide*.
 */
export declare const buildSuggesters: API.OperationMethod<BuildSuggestersRequest, BuildSuggestersResponse, BuildSuggestersError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = BaseException | InternalException | LimitExceededException | ResourceAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates a new search domain. For more information,
 * see Creating a Search Domain in the *Amazon CloudSearch Developer Guide*.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest, CreateDomainResponse, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type DefineAnalysisSchemeError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures an analysis scheme that can be applied to a `text` or `text-array` field to define language-specific text processing options. For more information, see Configuring Analysis Schemes in the *Amazon CloudSearch Developer Guide*.
 */
export declare const defineAnalysisScheme: API.OperationMethod<DefineAnalysisSchemeRequest, DefineAnalysisSchemeResponse, DefineAnalysisSchemeError, Credentials | HttpClient.HttpClient>;
export type DefineExpressionError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures an `Expression` for the search domain. Used to create new expressions and modify existing ones. If the expression exists, the new configuration replaces the old one. For more information, see Configuring Expressions in the *Amazon CloudSearch Developer Guide*.
 */
export declare const defineExpression: API.OperationMethod<DefineExpressionRequest, DefineExpressionResponse, DefineExpressionError, Credentials | HttpClient.HttpClient>;
export type DefineIndexFieldError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures an `IndexField` for the search domain. Used to create new fields and modify existing ones. You must specify the name of the domain you are configuring and an index field configuration. The index field configuration specifies a unique name, the index field type, and the options you want to configure for the field. The options you can specify depend on the `IndexFieldType`. If the field exists, the new configuration replaces the old one. For more information, see Configuring Index Fields in the *Amazon CloudSearch Developer Guide*.
 */
export declare const defineIndexField: API.OperationMethod<DefineIndexFieldRequest, DefineIndexFieldResponse, DefineIndexFieldError, Credentials | HttpClient.HttpClient>;
export type DefineSuggesterError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures a suggester for a domain. A suggester enables you to display possible matches before users finish typing their queries. When you configure a suggester, you must specify the name of the text field you want to search for possible matches and a unique name for the suggester. For more information, see Getting Search Suggestions in the *Amazon CloudSearch Developer Guide*.
 */
export declare const defineSuggester: API.OperationMethod<DefineSuggesterRequest, DefineSuggesterResponse, DefineSuggesterError, Credentials | HttpClient.HttpClient>;
export type DeleteAnalysisSchemeError = BaseException | InternalException | InvalidTypeException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an analysis scheme. For more information, see Configuring Analysis Schemes in the *Amazon CloudSearch Developer Guide*.
 */
export declare const deleteAnalysisScheme: API.OperationMethod<DeleteAnalysisSchemeRequest, DeleteAnalysisSchemeResponse, DeleteAnalysisSchemeError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = BaseException | InternalException | CommonErrors;
/**
 * Permanently deletes a search domain and all of its data. Once a domain has been deleted, it cannot be recovered. For more information,
 * see Deleting a Search Domain in the *Amazon CloudSearch Developer Guide*.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest, DeleteDomainResponse, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteExpressionError = BaseException | InternalException | InvalidTypeException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes an `Expression` from the search domain. For more information, see Configuring Expressions in the *Amazon CloudSearch Developer Guide*.
 */
export declare const deleteExpression: API.OperationMethod<DeleteExpressionRequest, DeleteExpressionResponse, DeleteExpressionError, Credentials | HttpClient.HttpClient>;
export type DeleteIndexFieldError = BaseException | InternalException | InvalidTypeException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes an `IndexField` from the search domain. For more information, see Configuring Index Fields in the *Amazon CloudSearch Developer Guide*.
 */
export declare const deleteIndexField: API.OperationMethod<DeleteIndexFieldRequest, DeleteIndexFieldResponse, DeleteIndexFieldError, Credentials | HttpClient.HttpClient>;
export type DeleteSuggesterError = BaseException | InternalException | InvalidTypeException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a suggester. For more information, see Getting Search Suggestions in the *Amazon CloudSearch Developer Guide*.
 */
export declare const deleteSuggester: API.OperationMethod<DeleteSuggesterRequest, DeleteSuggesterResponse, DeleteSuggesterError, Credentials | HttpClient.HttpClient>;
export type DescribeAnalysisSchemesError = BaseException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the analysis schemes configured for a domain. An analysis scheme defines language-specific text processing options for a `text` field. Can be limited to specific analysis schemes by name. By default, shows all analysis schemes and includes any pending changes to the configuration. Set the `Deployed` option to `true` to show the active configuration and exclude pending changes. For more information, see Configuring Analysis Schemes in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeAnalysisSchemes: API.OperationMethod<DescribeAnalysisSchemesRequest, DescribeAnalysisSchemesResponse, DescribeAnalysisSchemesError, Credentials | HttpClient.HttpClient>;
export type DescribeAvailabilityOptionsError = BaseException | DisabledOperationException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the availability options configured for a domain. By default, shows the configuration with any pending changes. Set the `Deployed` option to `true` to show the active configuration and exclude pending changes. For more information, see Configuring Availability Options in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeAvailabilityOptions: API.OperationMethod<DescribeAvailabilityOptionsRequest, DescribeAvailabilityOptionsResponse, DescribeAvailabilityOptionsError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainEndpointOptionsError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the domain's endpoint options, specifically whether all requests to the domain must arrive over HTTPS. For more information, see Configuring Domain Endpoint Options in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeDomainEndpointOptions: API.OperationMethod<DescribeDomainEndpointOptionsRequest, DescribeDomainEndpointOptionsResponse, DescribeDomainEndpointOptionsError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainsError = BaseException | InternalException | CommonErrors;
/**
 * Gets information about the search domains owned by this account. Can be limited to specific domains. Shows
 * all domains by default. To get the number of searchable documents in a domain, use the console or submit a `matchall` request to your domain's search endpoint: `q=matchall&q.parser=structured&size=0`. For more information,
 * see Getting Information about a Search Domain in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeDomains: API.OperationMethod<DescribeDomainsRequest, DescribeDomainsResponse, DescribeDomainsError, Credentials | HttpClient.HttpClient>;
export type DescribeExpressionsError = BaseException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the expressions configured for the search domain. Can be limited to specific expressions by name. By default, shows all expressions and includes any pending changes to the configuration. Set the `Deployed` option to `true` to show the active configuration and exclude pending changes. For more information, see Configuring Expressions in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeExpressions: API.OperationMethod<DescribeExpressionsRequest, DescribeExpressionsResponse, DescribeExpressionsError, Credentials | HttpClient.HttpClient>;
export type DescribeIndexFieldsError = BaseException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the index fields configured for the search domain.
 * Can be limited to specific fields by name. By default, shows all fields and includes any pending changes to the configuration. Set the `Deployed` option to `true` to show the active configuration and exclude pending changes. For more information,
 * see Getting Domain Information in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeIndexFields: API.OperationMethod<DescribeIndexFieldsRequest, DescribeIndexFieldsResponse, DescribeIndexFieldsError, Credentials | HttpClient.HttpClient>;
export type DescribeScalingParametersError = BaseException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the scaling parameters configured for a domain. A domain's scaling parameters specify the desired search instance type and replication count. For more information, see Configuring Scaling Options in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeScalingParameters: API.OperationMethod<DescribeScalingParametersRequest, DescribeScalingParametersResponse, DescribeScalingParametersError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceAccessPoliciesError = BaseException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the access policies that control access to the domain's document and search endpoints. By default, shows the configuration with any pending changes. Set the `Deployed` option to `true` to show the active configuration and exclude pending changes. For more information,
 * see Configuring Access for a Search Domain in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeServiceAccessPolicies: API.OperationMethod<DescribeServiceAccessPoliciesRequest, DescribeServiceAccessPoliciesResponse, DescribeServiceAccessPoliciesError, Credentials | HttpClient.HttpClient>;
export type DescribeSuggestersError = BaseException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the suggesters configured for a domain. A suggester enables you to display possible matches before users finish typing their queries. Can be limited to specific suggesters by name. By default, shows all suggesters and includes any pending changes to the configuration. Set the `Deployed` option to `true` to show the active configuration and exclude pending changes. For more information, see Getting Search Suggestions in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeSuggesters: API.OperationMethod<DescribeSuggestersRequest, DescribeSuggestersResponse, DescribeSuggestersError, Credentials | HttpClient.HttpClient>;
export type IndexDocumentsError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Tells the search domain to start indexing its documents using the latest indexing options. This operation must be invoked to activate options whose OptionStatus is `RequiresIndexDocuments`.
 */
export declare const indexDocuments: API.OperationMethod<IndexDocumentsRequest, IndexDocumentsResponse, IndexDocumentsError, Credentials | HttpClient.HttpClient>;
export type ListDomainNamesError = BaseException | CommonErrors;
/**
 * Lists all search domains owned by an account.
 */
export declare const listDomainNames: API.OperationMethod<ListDomainNamesRequest, ListDomainNamesResponse, ListDomainNamesError, Credentials | HttpClient.HttpClient>;
export type UpdateAvailabilityOptionsError = BaseException | DisabledOperationException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures the availability options for a domain. Enabling the Multi-AZ option expands an Amazon CloudSearch domain to an additional Availability Zone in the same Region to increase fault tolerance in the event of a service disruption. Changes to the Multi-AZ option can take about half an hour to become active. For more information, see Configuring Availability Options in the *Amazon CloudSearch Developer Guide*.
 */
export declare const updateAvailabilityOptions: API.OperationMethod<UpdateAvailabilityOptionsRequest, UpdateAvailabilityOptionsResponse, UpdateAvailabilityOptionsError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainEndpointOptionsError = BaseException | DisabledOperationException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the domain's endpoint options, specifically whether all requests to the domain must arrive over HTTPS. For more information, see Configuring Domain Endpoint Options in the *Amazon CloudSearch Developer Guide*.
 */
export declare const updateDomainEndpointOptions: API.OperationMethod<UpdateDomainEndpointOptionsRequest, UpdateDomainEndpointOptionsResponse, UpdateDomainEndpointOptionsError, Credentials | HttpClient.HttpClient>;
export type UpdateScalingParametersError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures scaling parameters for a domain. A domain's scaling parameters specify the desired search instance type and replication count. Amazon CloudSearch will still automatically scale your domain based on the volume of data and traffic, but not below the desired instance type and replication count. If the Multi-AZ option is enabled, these values control the resources used per Availability Zone. For more information, see Configuring Scaling Options in the *Amazon CloudSearch Developer Guide*.
 */
export declare const updateScalingParameters: API.OperationMethod<UpdateScalingParametersRequest, UpdateScalingParametersResponse, UpdateScalingParametersError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceAccessPoliciesError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures the access rules that control access to the domain's document and search endpoints.
 * For more information, see
 * Configuring Access for an Amazon CloudSearch Domain.
 */
export declare const updateServiceAccessPolicies: API.OperationMethod<UpdateServiceAccessPoliciesRequest, UpdateServiceAccessPoliciesResponse, UpdateServiceAccessPoliciesError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudsearch.d.ts.map