import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const ResourceConflictException_base: S.Class<ResourceConflictException, S.TaggedStruct<"ResourceConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflictException extends /*@__PURE__*/ ResourceConflictException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type ComponentName = string;
export type ComponentType = string;
export interface ComponentPropertyBindingProperties {
    property: string;
    field?: string;
}
export declare const ComponentPropertyBindingProperties: S.Schema<ComponentPropertyBindingProperties>;
export interface FormBindingElement {
    element: string;
    property: string;
}
export declare const FormBindingElement: S.Schema<FormBindingElement>;
export type FormBindings = {
    [key: string]: FormBindingElement | undefined;
};
export declare const FormBindings: any;
export type ComponentPropertyList = ComponentProperty[];
export declare const ComponentPropertyList: S.Schema<ComponentPropertyList>;
export interface ComponentConditionProperty {
    property?: string;
    field?: string;
    operator?: string;
    operand?: string;
    then?: ComponentProperty;
    else?: ComponentProperty;
    operandType?: string;
}
export declare const ComponentConditionProperty: S.Schema<ComponentConditionProperty>;
export interface ComponentProperty {
    value?: string;
    bindingProperties?: ComponentPropertyBindingProperties;
    collectionBindingProperties?: ComponentPropertyBindingProperties;
    defaultValue?: string;
    model?: string;
    bindings?: {
        [key: string]: FormBindingElement | undefined;
    };
    event?: string;
    userAttribute?: string;
    concat?: ComponentProperty[];
    condition?: ComponentConditionProperty;
    configured?: boolean;
    type?: string;
    importedValue?: string;
    componentName?: string;
    property?: string;
}
export declare const ComponentProperty: S.Schema<ComponentProperty>;
export type ComponentProperties = {
    [key: string]: ComponentProperty | undefined;
};
export declare const ComponentProperties: any;
export interface MutationActionSetStateParameter {
    componentName: string;
    property: string;
    set: ComponentProperty;
}
export declare const MutationActionSetStateParameter: S.Schema<MutationActionSetStateParameter>;
export interface ActionParameters {
    type?: ComponentProperty;
    url?: ComponentProperty;
    anchor?: ComponentProperty;
    target?: ComponentProperty;
    global?: ComponentProperty;
    model?: string;
    id?: ComponentProperty;
    fields?: {
        [key: string]: ComponentProperty | undefined;
    };
    state?: MutationActionSetStateParameter;
}
export declare const ActionParameters: S.Schema<ActionParameters>;
export interface ComponentEvent {
    action?: string;
    parameters?: ActionParameters;
    bindingEvent?: string;
}
export declare const ComponentEvent: S.Schema<ComponentEvent>;
export type ComponentEvents = {
    [key: string]: ComponentEvent | undefined;
};
export declare const ComponentEvents: any;
export interface ComponentChild {
    componentType: string;
    name: string;
    properties: {
        [key: string]: ComponentProperty | undefined;
    };
    children?: ComponentChild[];
    events?: {
        [key: string]: ComponentEvent | undefined;
    };
    sourceId?: string;
}
export declare const ComponentChild: S.Schema<ComponentChild>;
export type ComponentChildList = ComponentChild[];
export declare const ComponentChildList: S.Schema<ComponentChildList>;
export type ComponentVariantValues = {
    [key: string]: string | undefined;
};
export declare const ComponentVariantValues: any;
export type ComponentOverridesValue = {
    [key: string]: string | undefined;
};
export declare const ComponentOverridesValue: any;
export type ComponentOverrides = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export declare const ComponentOverrides: any;
export interface ComponentVariant {
    variantValues?: {
        [key: string]: string | undefined;
    };
    overrides?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
}
export declare const ComponentVariant: S.Schema<ComponentVariant>;
export type ComponentVariants = ComponentVariant[];
export declare const ComponentVariants: any;
export type OperandType = string;
export interface Predicate {
    or?: Predicate[];
    and?: Predicate[];
    field?: string;
    operator?: string;
    operand?: string;
    operandType?: string;
}
export declare const Predicate: S.Schema<Predicate>;
export type PredicateList = Predicate[];
export declare const PredicateList: S.Schema<PredicateList>;
export interface ComponentBindingPropertiesValueProperties {
    model?: string;
    field?: string;
    predicates?: Predicate[];
    userAttribute?: string;
    bucket?: string;
    key?: string;
    defaultValue?: string;
    slotName?: string;
}
export declare const ComponentBindingPropertiesValueProperties: S.Schema<ComponentBindingPropertiesValueProperties>;
export interface ComponentBindingPropertiesValue {
    type?: string;
    bindingProperties?: ComponentBindingPropertiesValueProperties;
    defaultValue?: string;
}
export declare const ComponentBindingPropertiesValue: S.Schema<ComponentBindingPropertiesValue>;
export type ComponentBindingProperties = {
    [key: string]: ComponentBindingPropertiesValue | undefined;
};
export declare const ComponentBindingProperties: any;
export type SortDirection = "ASC" | "DESC" | (string & {});
export declare const SortDirection: any;
export interface SortProperty {
    field: string;
    direction: SortDirection;
}
export declare const SortProperty: S.Schema<SortProperty>;
export type SortPropertyList = SortProperty[];
export declare const SortPropertyList: any;
export type IdentifierList = string[];
export declare const IdentifierList: any;
export interface ComponentDataConfiguration {
    model: string;
    sort?: SortProperty[];
    predicate?: Predicate;
    identifiers?: string[];
}
export declare const ComponentDataConfiguration: S.Schema<ComponentDataConfiguration>;
export type ComponentCollectionProperties = {
    [key: string]: ComponentDataConfiguration | undefined;
};
export declare const ComponentCollectionProperties: any;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export interface CreateComponentData {
    name: string;
    sourceId?: string;
    componentType: string;
    properties: {
        [key: string]: ComponentProperty | undefined;
    };
    children?: ComponentChild[];
    variants: ComponentVariant[];
    overrides: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    bindingProperties: {
        [key: string]: ComponentBindingPropertiesValue | undefined;
    };
    collectionProperties?: {
        [key: string]: ComponentDataConfiguration | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
    events?: {
        [key: string]: ComponentEvent | undefined;
    };
    schemaVersion?: string;
}
export declare const CreateComponentData: S.Schema<CreateComponentData>;
export interface CreateComponentRequest {
    appId: string;
    environmentName: string;
    clientToken?: string;
    componentToCreate: CreateComponentData;
}
export declare const CreateComponentRequest: S.Schema<CreateComponentRequest>;
export type Uuid = string;
export interface Component {
    appId: string;
    environmentName: string;
    sourceId?: string;
    id: string;
    name: string;
    componentType: string;
    properties: {
        [key: string]: ComponentProperty | undefined;
    };
    children?: ComponentChild[];
    variants: ComponentVariant[];
    overrides: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    bindingProperties: {
        [key: string]: ComponentBindingPropertiesValue | undefined;
    };
    collectionProperties?: {
        [key: string]: ComponentDataConfiguration | undefined;
    };
    createdAt: Date;
    modifiedAt?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    events?: {
        [key: string]: ComponentEvent | undefined;
    };
    schemaVersion?: string;
}
export declare const Component: S.Schema<Component>;
export interface CreateComponentResponse {
    entity?: Component;
}
export declare const CreateComponentResponse: S.Schema<CreateComponentResponse>;
export type FormName = string;
export type FormDataSourceType = string;
export interface FormDataTypeConfig {
    dataSourceType: string;
    dataTypeName: string;
}
export declare const FormDataTypeConfig: S.Schema<FormDataTypeConfig>;
export type FormActionType = "create" | "update" | (string & {});
export declare const FormActionType: any;
export type FixedPosition = "first" | (string & {});
export declare const FixedPosition: any;
export type FieldPosition = {
    fixed: FixedPosition;
    rightOf?: never;
    below?: never;
} | {
    fixed?: never;
    rightOf: string;
    below?: never;
} | {
    fixed?: never;
    rightOf?: never;
    below: string;
};
export declare const FieldPosition: any;
export interface FormInputValuePropertyBindingProperties {
    property: string;
    field?: string;
}
export declare const FormInputValuePropertyBindingProperties: S.Schema<FormInputValuePropertyBindingProperties>;
export type FormInputValuePropertyList = FormInputValueProperty[];
export declare const FormInputValuePropertyList: S.Schema<FormInputValuePropertyList>;
export interface FormInputValueProperty {
    value?: string;
    bindingProperties?: FormInputValuePropertyBindingProperties;
    concat?: FormInputValueProperty[];
}
export declare const FormInputValueProperty: S.Schema<FormInputValueProperty>;
export interface ValueMapping {
    displayValue?: FormInputValueProperty;
    value: FormInputValueProperty;
}
export declare const ValueMapping: S.Schema<ValueMapping>;
export type ValueMappingList = ValueMapping[];
export declare const ValueMappingList: any;
export interface FormInputBindingPropertiesValueProperties {
    model?: string;
}
export declare const FormInputBindingPropertiesValueProperties: S.Schema<FormInputBindingPropertiesValueProperties>;
export interface FormInputBindingPropertiesValue {
    type?: string;
    bindingProperties?: FormInputBindingPropertiesValueProperties;
}
export declare const FormInputBindingPropertiesValue: S.Schema<FormInputBindingPropertiesValue>;
export type FormInputBindingProperties = {
    [key: string]: FormInputBindingPropertiesValue | undefined;
};
export declare const FormInputBindingProperties: any;
export interface ValueMappings {
    values: ValueMapping[];
    bindingProperties?: {
        [key: string]: FormInputBindingPropertiesValue | undefined;
    };
}
export declare const ValueMappings: S.Schema<ValueMappings>;
export type StorageAccessLevel = "public" | "protected" | "private" | (string & {});
export declare const StorageAccessLevel: any;
export type StrValues = string[];
export declare const StrValues: any;
export interface FileUploaderFieldConfig {
    accessLevel: StorageAccessLevel;
    acceptedFileTypes: string[];
    showThumbnails?: boolean;
    isResumable?: boolean;
    maxFileCount?: number;
    maxSize?: number;
}
export declare const FileUploaderFieldConfig: S.Schema<FileUploaderFieldConfig>;
export interface FieldInputConfig {
    type: string;
    required?: boolean;
    readOnly?: boolean;
    placeholder?: string;
    defaultValue?: string;
    descriptiveText?: string;
    defaultChecked?: boolean;
    defaultCountryCode?: string;
    valueMappings?: ValueMappings;
    name?: string;
    minValue?: number;
    maxValue?: number;
    step?: number;
    value?: string;
    isArray?: boolean;
    fileUploaderConfig?: FileUploaderFieldConfig;
}
export declare const FieldInputConfig: S.Schema<FieldInputConfig>;
export type NumValues = number[];
export declare const NumValues: any;
export interface FieldValidationConfiguration {
    type: string;
    strValues?: string[];
    numValues?: number[];
    validationMessage?: string;
}
export declare const FieldValidationConfiguration: S.Schema<FieldValidationConfiguration>;
export type ValidationsList = FieldValidationConfiguration[];
export declare const ValidationsList: any;
export interface FieldConfig {
    label?: string;
    position?: FieldPosition;
    excluded?: boolean;
    inputType?: FieldInputConfig;
    validations?: FieldValidationConfiguration[];
}
export declare const FieldConfig: S.Schema<FieldConfig>;
export type FieldsMap = {
    [key: string]: FieldConfig | undefined;
};
export declare const FieldsMap: any;
export type FormStyleConfig = {
    tokenReference: string;
    value?: never;
} | {
    tokenReference?: never;
    value: string;
};
export declare const FormStyleConfig: any;
export interface FormStyle {
    horizontalGap?: FormStyleConfig;
    verticalGap?: FormStyleConfig;
    outerPadding?: FormStyleConfig;
}
export declare const FormStyle: S.Schema<FormStyle>;
export interface SectionalElement {
    type: string;
    position?: FieldPosition;
    text?: string;
    level?: number;
    orientation?: string;
    excluded?: boolean;
}
export declare const SectionalElement: S.Schema<SectionalElement>;
export type SectionalElementMap = {
    [key: string]: SectionalElement | undefined;
};
export declare const SectionalElementMap: any;
export type FormButtonsPosition = "top" | "bottom" | "top_and_bottom" | (string & {});
export declare const FormButtonsPosition: any;
export interface FormButton {
    excluded?: boolean;
    children?: string;
    position?: FieldPosition;
}
export declare const FormButton: S.Schema<FormButton>;
export interface FormCTA {
    position?: FormButtonsPosition;
    clear?: FormButton;
    cancel?: FormButton;
    submit?: FormButton;
}
export declare const FormCTA: S.Schema<FormCTA>;
export type LabelDecorator = string;
export interface CreateFormData {
    name: string;
    dataType: FormDataTypeConfig;
    formActionType: FormActionType;
    fields: {
        [key: string]: FieldConfig | undefined;
    };
    style: FormStyle;
    sectionalElements: {
        [key: string]: SectionalElement | undefined;
    };
    schemaVersion: string;
    cta?: FormCTA;
    tags?: {
        [key: string]: string | undefined;
    };
    labelDecorator?: string;
}
export declare const CreateFormData: S.Schema<CreateFormData>;
export interface CreateFormRequest {
    appId: string;
    environmentName: string;
    clientToken?: string;
    formToCreate: CreateFormData;
}
export declare const CreateFormRequest: S.Schema<CreateFormRequest>;
export interface Form {
    appId: string;
    environmentName: string;
    id: string;
    name: string;
    formActionType: FormActionType;
    style: FormStyle;
    dataType: FormDataTypeConfig;
    fields: {
        [key: string]: FieldConfig | undefined;
    };
    sectionalElements: {
        [key: string]: SectionalElement | undefined;
    };
    schemaVersion: string;
    tags?: {
        [key: string]: string | undefined;
    };
    cta?: FormCTA;
    labelDecorator?: string;
}
export declare const Form: S.Schema<Form>;
export interface CreateFormResponse {
    entity?: Form;
}
export declare const CreateFormResponse: S.Schema<CreateFormResponse>;
export type ThemeName = string;
export interface ThemeValue {
    value?: string;
    children?: ThemeValues[];
}
export declare const ThemeValue: S.Schema<ThemeValue>;
export interface ThemeValues {
    key?: string;
    value?: ThemeValue;
}
export declare const ThemeValues: S.Schema<ThemeValues>;
export type ThemeValuesList = ThemeValues[];
export declare const ThemeValuesList: S.Schema<ThemeValuesList>;
export interface CreateThemeData {
    name: string;
    values: ThemeValues[];
    overrides?: ThemeValues[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateThemeData: S.Schema<CreateThemeData>;
export interface CreateThemeRequest {
    appId: string;
    environmentName: string;
    clientToken?: string;
    themeToCreate: CreateThemeData;
}
export declare const CreateThemeRequest: S.Schema<CreateThemeRequest>;
export interface Theme {
    appId: string;
    environmentName: string;
    id: string;
    name: string;
    createdAt: Date;
    modifiedAt?: Date;
    values: ThemeValues[];
    overrides?: ThemeValues[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Theme: S.Schema<Theme>;
export interface CreateThemeResponse {
    entity?: Theme;
}
export declare const CreateThemeResponse: S.Schema<CreateThemeResponse>;
export interface DeleteComponentRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export declare const DeleteComponentRequest: S.Schema<DeleteComponentRequest>;
export interface DeleteComponentResponse {
}
export declare const DeleteComponentResponse: S.Schema<DeleteComponentResponse>;
export interface DeleteFormRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export declare const DeleteFormRequest: S.Schema<DeleteFormRequest>;
export interface DeleteFormResponse {
}
export declare const DeleteFormResponse: S.Schema<DeleteFormResponse>;
export interface DeleteThemeRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export declare const DeleteThemeRequest: S.Schema<DeleteThemeRequest>;
export interface DeleteThemeResponse {
}
export declare const DeleteThemeResponse: S.Schema<DeleteThemeResponse>;
export type TokenProviders = string;
export type SensitiveString = string | redacted.Redacted<string>;
export interface ExchangeCodeForTokenRequestBody {
    code: string | redacted.Redacted<string>;
    redirectUri: string;
    clientId?: string | redacted.Redacted<string>;
}
export declare const ExchangeCodeForTokenRequestBody: S.Schema<ExchangeCodeForTokenRequestBody>;
export interface ExchangeCodeForTokenRequest {
    provider: string;
    request: ExchangeCodeForTokenRequestBody;
}
export declare const ExchangeCodeForTokenRequest: S.Schema<ExchangeCodeForTokenRequest>;
export interface ExchangeCodeForTokenResponse {
    accessToken: string | redacted.Redacted<string>;
    expiresIn: number;
    refreshToken: string | redacted.Redacted<string>;
}
export declare const ExchangeCodeForTokenResponse: S.Schema<ExchangeCodeForTokenResponse>;
export interface ExportComponentsRequest {
    appId: string;
    environmentName: string;
    nextToken?: string;
}
export declare const ExportComponentsRequest: S.Schema<ExportComponentsRequest>;
export type ComponentList = Component[];
export declare const ComponentList: any;
export interface ExportComponentsResponse {
    entities: Component[];
    nextToken?: string;
}
export declare const ExportComponentsResponse: S.Schema<ExportComponentsResponse>;
export interface ExportFormsRequest {
    appId: string;
    environmentName: string;
    nextToken?: string;
}
export declare const ExportFormsRequest: S.Schema<ExportFormsRequest>;
export type FormList = Form[];
export declare const FormList: any;
export interface ExportFormsResponse {
    entities: Form[];
    nextToken?: string;
}
export declare const ExportFormsResponse: S.Schema<ExportFormsResponse>;
export interface ExportThemesRequest {
    appId: string;
    environmentName: string;
    nextToken?: string;
}
export declare const ExportThemesRequest: S.Schema<ExportThemesRequest>;
export type ThemeList = Theme[];
export declare const ThemeList: any;
export interface ExportThemesResponse {
    entities: Theme[];
    nextToken?: string;
}
export declare const ExportThemesResponse: S.Schema<ExportThemesResponse>;
export type AppId = string;
export interface GetCodegenJobRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export declare const GetCodegenJobRequest: S.Schema<GetCodegenJobRequest>;
export type JSModule = "es2020" | "esnext" | (string & {});
export declare const JSModule: any;
export type JSTarget = "es2015" | "es2020" | (string & {});
export declare const JSTarget: any;
export type JSScript = "jsx" | "tsx" | "js" | (string & {});
export declare const JSScript: any;
export interface GraphQLRenderConfig {
    typesFilePath: string;
    queriesFilePath: string;
    mutationsFilePath: string;
    subscriptionsFilePath: string;
    fragmentsFilePath: string;
}
export declare const GraphQLRenderConfig: S.Schema<GraphQLRenderConfig>;
export interface DataStoreRenderConfig {
}
export declare const DataStoreRenderConfig: S.Schema<DataStoreRenderConfig>;
export interface NoApiRenderConfig {
}
export declare const NoApiRenderConfig: S.Schema<NoApiRenderConfig>;
export type ApiConfiguration = {
    graphQLConfig: GraphQLRenderConfig;
    dataStoreConfig?: never;
    noApiConfig?: never;
} | {
    graphQLConfig?: never;
    dataStoreConfig: DataStoreRenderConfig;
    noApiConfig?: never;
} | {
    graphQLConfig?: never;
    dataStoreConfig?: never;
    noApiConfig: NoApiRenderConfig;
};
export declare const ApiConfiguration: any;
export type ReactCodegenDependencies = {
    [key: string]: string | undefined;
};
export declare const ReactCodegenDependencies: any;
export interface ReactStartCodegenJobData {
    module?: JSModule;
    target?: JSTarget;
    script?: JSScript;
    renderTypeDeclarations?: boolean;
    inlineSourceMap?: boolean;
    apiConfiguration?: ApiConfiguration;
    dependencies?: {
        [key: string]: string | undefined;
    };
}
export declare const ReactStartCodegenJobData: S.Schema<ReactStartCodegenJobData>;
export type CodegenJobRenderConfig = {
    react: ReactStartCodegenJobData;
};
export declare const CodegenJobRenderConfig: any;
export type CodegenJobGenericDataSourceType = "DataStore" | (string & {});
export declare const CodegenJobGenericDataSourceType: any;
export type CodegenGenericDataFieldDataType = "ID" | "String" | "Int" | "Float" | "AWSDate" | "AWSTime" | "AWSDateTime" | "AWSTimestamp" | "AWSEmail" | "AWSURL" | "AWSIPAddress" | "Boolean" | "AWSJSON" | "AWSPhone" | "Enum" | "Model" | "NonModel" | (string & {});
export declare const CodegenGenericDataFieldDataType: any;
export type GenericDataRelationshipType = "HAS_MANY" | "HAS_ONE" | "BELONGS_TO" | (string & {});
export declare const GenericDataRelationshipType: any;
export type RelatedModelFieldsList = string[];
export declare const RelatedModelFieldsList: any;
export type AssociatedFieldsList = string[];
export declare const AssociatedFieldsList: any;
export interface CodegenGenericDataRelationshipType {
    type: GenericDataRelationshipType;
    relatedModelName: string;
    relatedModelFields?: string[];
    canUnlinkAssociatedModel?: boolean;
    relatedJoinFieldName?: string;
    relatedJoinTableName?: string;
    belongsToFieldOnRelatedModel?: string;
    associatedFields?: string[];
    isHasManyIndex?: boolean;
}
export declare const CodegenGenericDataRelationshipType: S.Schema<CodegenGenericDataRelationshipType>;
export interface CodegenGenericDataField {
    dataType: CodegenGenericDataFieldDataType;
    dataTypeValue: string;
    required: boolean;
    readOnly: boolean;
    isArray: boolean;
    relationship?: CodegenGenericDataRelationshipType;
}
export declare const CodegenGenericDataField: S.Schema<CodegenGenericDataField>;
export type CodegenGenericDataFields = {
    [key: string]: CodegenGenericDataField | undefined;
};
export declare const CodegenGenericDataFields: any;
export type CodegenPrimaryKeysList = string[];
export declare const CodegenPrimaryKeysList: any;
export interface CodegenGenericDataModel {
    fields: {
        [key: string]: CodegenGenericDataField | undefined;
    };
    isJoinTable?: boolean;
    primaryKeys: string[];
}
export declare const CodegenGenericDataModel: S.Schema<CodegenGenericDataModel>;
export type CodegenGenericDataModels = {
    [key: string]: CodegenGenericDataModel | undefined;
};
export declare const CodegenGenericDataModels: any;
export type CodegenGenericDataEnumValuesList = string[];
export declare const CodegenGenericDataEnumValuesList: any;
export interface CodegenGenericDataEnum {
    values: string[];
}
export declare const CodegenGenericDataEnum: S.Schema<CodegenGenericDataEnum>;
export type CodegenGenericDataEnums = {
    [key: string]: CodegenGenericDataEnum | undefined;
};
export declare const CodegenGenericDataEnums: any;
export type CodegenGenericDataNonModelFields = {
    [key: string]: CodegenGenericDataField | undefined;
};
export declare const CodegenGenericDataNonModelFields: any;
export interface CodegenGenericDataNonModel {
    fields: {
        [key: string]: CodegenGenericDataField | undefined;
    };
}
export declare const CodegenGenericDataNonModel: S.Schema<CodegenGenericDataNonModel>;
export type CodegenGenericDataNonModels = {
    [key: string]: CodegenGenericDataNonModel | undefined;
};
export declare const CodegenGenericDataNonModels: any;
export interface CodegenJobGenericDataSchema {
    dataSourceType: CodegenJobGenericDataSourceType;
    models: {
        [key: string]: CodegenGenericDataModel | undefined;
    };
    enums: {
        [key: string]: CodegenGenericDataEnum | undefined;
    };
    nonModels: {
        [key: string]: CodegenGenericDataNonModel | undefined;
    };
}
export declare const CodegenJobGenericDataSchema: S.Schema<CodegenJobGenericDataSchema>;
export interface CodegenFeatureFlags {
    isRelationshipSupported?: boolean;
    isNonModelSupported?: boolean;
}
export declare const CodegenFeatureFlags: S.Schema<CodegenFeatureFlags>;
export type CodegenJobStatus = "in_progress" | "failed" | "succeeded" | (string & {});
export declare const CodegenJobStatus: any;
export interface CodegenJobAsset {
    downloadUrl?: string;
}
export declare const CodegenJobAsset: S.Schema<CodegenJobAsset>;
export interface CodegenDependency {
    name?: string;
    supportedVersion?: string;
    isSemVer?: boolean;
    reason?: string;
}
export declare const CodegenDependency: S.Schema<CodegenDependency>;
export type CodegenDependencies = CodegenDependency[];
export declare const CodegenDependencies: any;
export interface CodegenJob {
    id: string;
    appId: string;
    environmentName: string;
    renderConfig?: CodegenJobRenderConfig;
    genericDataSchema?: CodegenJobGenericDataSchema;
    autoGenerateForms?: boolean;
    features?: CodegenFeatureFlags;
    status?: CodegenJobStatus;
    statusMessage?: string;
    asset?: CodegenJobAsset;
    tags?: {
        [key: string]: string | undefined;
    };
    createdAt?: Date;
    modifiedAt?: Date;
    dependencies?: CodegenDependency[];
}
export declare const CodegenJob: S.Schema<CodegenJob>;
export interface GetCodegenJobResponse {
    job?: CodegenJob;
}
export declare const GetCodegenJobResponse: S.Schema<GetCodegenJobResponse>;
export interface GetComponentRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export declare const GetComponentRequest: S.Schema<GetComponentRequest>;
export interface GetComponentResponse {
    component?: Component;
}
export declare const GetComponentResponse: S.Schema<GetComponentResponse>;
export interface GetFormRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export declare const GetFormRequest: S.Schema<GetFormRequest>;
export interface GetFormResponse {
    form?: Form;
}
export declare const GetFormResponse: S.Schema<GetFormResponse>;
export interface GetMetadataRequest {
    appId: string;
    environmentName: string;
}
export declare const GetMetadataRequest: S.Schema<GetMetadataRequest>;
export type FeaturesMap = {
    [key: string]: string | undefined;
};
export declare const FeaturesMap: any;
export interface GetMetadataResponse {
    features: {
        [key: string]: string | undefined;
    };
}
export declare const GetMetadataResponse: S.Schema<GetMetadataResponse>;
export interface GetThemeRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export declare const GetThemeRequest: S.Schema<GetThemeRequest>;
export interface GetThemeResponse {
    theme?: Theme;
}
export declare const GetThemeResponse: S.Schema<GetThemeResponse>;
export type ListCodegenJobsLimit = number;
export interface ListCodegenJobsRequest {
    appId: string;
    environmentName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListCodegenJobsRequest: S.Schema<ListCodegenJobsRequest>;
export interface CodegenJobSummary {
    appId: string;
    environmentName: string;
    id: string;
    createdAt?: Date;
    modifiedAt?: Date;
}
export declare const CodegenJobSummary: S.Schema<CodegenJobSummary>;
export type CodegenJobSummaryList = CodegenJobSummary[];
export declare const CodegenJobSummaryList: any;
export interface ListCodegenJobsResponse {
    entities: CodegenJobSummary[];
    nextToken?: string;
}
export declare const ListCodegenJobsResponse: S.Schema<ListCodegenJobsResponse>;
export type ListEntityLimit = number;
export interface ListComponentsRequest {
    appId: string;
    environmentName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListComponentsRequest: S.Schema<ListComponentsRequest>;
export interface ComponentSummary {
    appId: string;
    environmentName: string;
    id: string;
    name: string;
    componentType: string;
}
export declare const ComponentSummary: S.Schema<ComponentSummary>;
export type ComponentSummaryList = ComponentSummary[];
export declare const ComponentSummaryList: any;
export interface ListComponentsResponse {
    entities: ComponentSummary[];
    nextToken?: string;
}
export declare const ListComponentsResponse: S.Schema<ListComponentsResponse>;
export interface ListFormsRequest {
    appId: string;
    environmentName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListFormsRequest: S.Schema<ListFormsRequest>;
export interface FormSummary {
    appId: string;
    dataType: FormDataTypeConfig;
    environmentName: string;
    formActionType: FormActionType;
    id: string;
    name: string;
}
export declare const FormSummary: S.Schema<FormSummary>;
export type FormSummaryList = FormSummary[];
export declare const FormSummaryList: any;
export interface ListFormsResponse {
    entities: FormSummary[];
    nextToken?: string;
}
export declare const ListFormsResponse: S.Schema<ListFormsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListThemesRequest {
    appId: string;
    environmentName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListThemesRequest: S.Schema<ListThemesRequest>;
export interface ThemeSummary {
    appId: string;
    environmentName: string;
    id: string;
    name: string;
}
export declare const ThemeSummary: S.Schema<ThemeSummary>;
export type ThemeSummaryList = ThemeSummary[];
export declare const ThemeSummaryList: any;
export interface ListThemesResponse {
    entities: ThemeSummary[];
    nextToken?: string;
}
export declare const ListThemesResponse: S.Schema<ListThemesResponse>;
export interface PutMetadataFlagBody {
    newValue: string;
}
export declare const PutMetadataFlagBody: S.Schema<PutMetadataFlagBody>;
export interface PutMetadataFlagRequest {
    appId: string;
    environmentName: string;
    featureName: string;
    body: PutMetadataFlagBody;
}
export declare const PutMetadataFlagRequest: S.Schema<PutMetadataFlagRequest>;
export interface PutMetadataFlagResponse {
}
export declare const PutMetadataFlagResponse: S.Schema<PutMetadataFlagResponse>;
export interface RefreshTokenRequestBody {
    token: string | redacted.Redacted<string>;
    clientId?: string | redacted.Redacted<string>;
}
export declare const RefreshTokenRequestBody: S.Schema<RefreshTokenRequestBody>;
export interface RefreshTokenRequest {
    provider: string;
    refreshTokenBody: RefreshTokenRequestBody;
}
export declare const RefreshTokenRequest: S.Schema<RefreshTokenRequest>;
export interface RefreshTokenResponse {
    accessToken: string | redacted.Redacted<string>;
    expiresIn: number;
}
export declare const RefreshTokenResponse: S.Schema<RefreshTokenResponse>;
export interface StartCodegenJobData {
    renderConfig: CodegenJobRenderConfig;
    genericDataSchema?: CodegenJobGenericDataSchema;
    autoGenerateForms?: boolean;
    features?: CodegenFeatureFlags;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StartCodegenJobData: S.Schema<StartCodegenJobData>;
export interface StartCodegenJobRequest {
    appId: string;
    environmentName: string;
    clientToken?: string;
    codegenJobToCreate: StartCodegenJobData;
}
export declare const StartCodegenJobRequest: S.Schema<StartCodegenJobRequest>;
export interface StartCodegenJobResponse {
    entity?: CodegenJob;
}
export declare const StartCodegenJobResponse: S.Schema<StartCodegenJobResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateComponentData {
    id?: string;
    name?: string;
    sourceId?: string;
    componentType?: string;
    properties?: {
        [key: string]: ComponentProperty | undefined;
    };
    children?: ComponentChild[];
    variants?: ComponentVariant[];
    overrides?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    bindingProperties?: {
        [key: string]: ComponentBindingPropertiesValue | undefined;
    };
    collectionProperties?: {
        [key: string]: ComponentDataConfiguration | undefined;
    };
    events?: {
        [key: string]: ComponentEvent | undefined;
    };
    schemaVersion?: string;
}
export declare const UpdateComponentData: S.Schema<UpdateComponentData>;
export interface UpdateComponentRequest {
    appId: string;
    environmentName: string;
    id: string;
    clientToken?: string;
    updatedComponent: UpdateComponentData;
}
export declare const UpdateComponentRequest: S.Schema<UpdateComponentRequest>;
export interface UpdateComponentResponse {
    entity?: Component;
}
export declare const UpdateComponentResponse: S.Schema<UpdateComponentResponse>;
export interface UpdateFormData {
    name?: string;
    dataType?: FormDataTypeConfig;
    formActionType?: FormActionType;
    fields?: {
        [key: string]: FieldConfig | undefined;
    };
    style?: FormStyle;
    sectionalElements?: {
        [key: string]: SectionalElement | undefined;
    };
    schemaVersion?: string;
    cta?: FormCTA;
    labelDecorator?: string;
}
export declare const UpdateFormData: S.Schema<UpdateFormData>;
export interface UpdateFormRequest {
    appId: string;
    environmentName: string;
    id: string;
    clientToken?: string;
    updatedForm: UpdateFormData;
}
export declare const UpdateFormRequest: S.Schema<UpdateFormRequest>;
export interface UpdateFormResponse {
    entity?: Form;
}
export declare const UpdateFormResponse: S.Schema<UpdateFormResponse>;
export interface UpdateThemeData {
    id?: string;
    name?: string;
    values: ThemeValues[];
    overrides?: ThemeValues[];
}
export declare const UpdateThemeData: S.Schema<UpdateThemeData>;
export interface UpdateThemeRequest {
    appId: string;
    environmentName: string;
    id: string;
    clientToken?: string;
    updatedTheme: UpdateThemeData;
}
export declare const UpdateThemeRequest: S.Schema<UpdateThemeRequest>;
export interface UpdateThemeResponse {
    entity?: Theme;
}
export declare const UpdateThemeResponse: S.Schema<UpdateThemeResponse>;
export type CreateComponentError = InternalServerException | InvalidParameterException | ResourceConflictException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new component for an Amplify app.
 */
export declare const createComponent: API.OperationMethod<CreateComponentRequest, CreateComponentResponse, CreateComponentError, Credentials | HttpClient.HttpClient>;
export type CreateFormError = InternalServerException | InvalidParameterException | ResourceConflictException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new form for an Amplify app.
 */
export declare const createForm: API.OperationMethod<CreateFormRequest, CreateFormResponse, CreateFormError, Credentials | HttpClient.HttpClient>;
export type CreateThemeError = InternalServerException | InvalidParameterException | ResourceConflictException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a theme to apply to the components in an Amplify app.
 */
export declare const createTheme: API.OperationMethod<CreateThemeRequest, CreateThemeResponse, CreateThemeError, Credentials | HttpClient.HttpClient>;
export type DeleteComponentError = InternalServerException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a component from an Amplify app.
 */
export declare const deleteComponent: API.OperationMethod<DeleteComponentRequest, DeleteComponentResponse, DeleteComponentError, Credentials | HttpClient.HttpClient>;
export type DeleteFormError = InternalServerException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a form from an Amplify app.
 */
export declare const deleteForm: API.OperationMethod<DeleteFormRequest, DeleteFormResponse, DeleteFormError, Credentials | HttpClient.HttpClient>;
export type DeleteThemeError = InternalServerException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a theme from an Amplify app.
 */
export declare const deleteTheme: API.OperationMethod<DeleteThemeRequest, DeleteThemeResponse, DeleteThemeError, Credentials | HttpClient.HttpClient>;
export type ExchangeCodeForTokenError = InvalidParameterException | CommonErrors;
/**
 * This is for internal use.
 *
 * Amplify uses this action to exchange an access code for a token.
 */
export declare const exchangeCodeForToken: API.OperationMethod<ExchangeCodeForTokenRequest, ExchangeCodeForTokenResponse, ExchangeCodeForTokenError, Credentials | HttpClient.HttpClient>;
export type ExportComponentsError = InternalServerException | InvalidParameterException | CommonErrors;
/**
 * Exports component configurations to code that is ready to integrate into an Amplify app.
 */
export declare const exportComponents: API.PaginatedOperationMethod<ExportComponentsRequest, ExportComponentsResponse, ExportComponentsError, Credentials | HttpClient.HttpClient, Component>;
export type ExportFormsError = InternalServerException | InvalidParameterException | CommonErrors;
/**
 * Exports form configurations to code that is ready to integrate into an Amplify app.
 */
export declare const exportForms: API.PaginatedOperationMethod<ExportFormsRequest, ExportFormsResponse, ExportFormsError, Credentials | HttpClient.HttpClient, Form>;
export type ExportThemesError = InternalServerException | InvalidParameterException | CommonErrors;
/**
 * Exports theme configurations to code that is ready to integrate into an Amplify app.
 */
export declare const exportThemes: API.PaginatedOperationMethod<ExportThemesRequest, ExportThemesResponse, ExportThemesError, Credentials | HttpClient.HttpClient, Theme>;
export type GetCodegenJobError = InternalServerException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns an existing code generation job.
 */
export declare const getCodegenJob: API.OperationMethod<GetCodegenJobRequest, GetCodegenJobResponse, GetCodegenJobError, Credentials | HttpClient.HttpClient>;
export type GetComponentError = InternalServerException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an existing component for an Amplify app.
 */
export declare const getComponent: API.OperationMethod<GetComponentRequest, GetComponentResponse, GetComponentError, Credentials | HttpClient.HttpClient>;
export type GetFormError = InternalServerException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an existing form for an Amplify app.
 */
export declare const getForm: API.OperationMethod<GetFormRequest, GetFormResponse, GetFormError, Credentials | HttpClient.HttpClient>;
export type GetMetadataError = InvalidParameterException | UnauthorizedException | CommonErrors;
/**
 * Returns existing metadata for an Amplify app.
 */
export declare const getMetadata: API.OperationMethod<GetMetadataRequest, GetMetadataResponse, GetMetadataError, Credentials | HttpClient.HttpClient>;
export type GetThemeError = InternalServerException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an existing theme for an Amplify app.
 */
export declare const getTheme: API.OperationMethod<GetThemeRequest, GetThemeResponse, GetThemeError, Credentials | HttpClient.HttpClient>;
export type ListCodegenJobsError = InternalServerException | InvalidParameterException | ThrottlingException | CommonErrors;
/**
 * Retrieves a list of code generation jobs for a specified Amplify app and backend environment.
 */
export declare const listCodegenJobs: API.PaginatedOperationMethod<ListCodegenJobsRequest, ListCodegenJobsResponse, ListCodegenJobsError, Credentials | HttpClient.HttpClient, CodegenJobSummary>;
export type ListComponentsError = InternalServerException | InvalidParameterException | CommonErrors;
/**
 * Retrieves a list of components for a specified Amplify app and backend
 * environment.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsRequest, ListComponentsResponse, ListComponentsError, Credentials | HttpClient.HttpClient, ComponentSummary>;
export type ListFormsError = InternalServerException | InvalidParameterException | CommonErrors;
/**
 * Retrieves a list of forms for a specified Amplify app and backend environment.
 */
export declare const listForms: API.PaginatedOperationMethod<ListFormsRequest, ListFormsResponse, ListFormsError, Credentials | HttpClient.HttpClient, FormSummary>;
export type ListTagsForResourceError = InternalServerException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of tags for a specified Amazon Resource Name (ARN).
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListThemesError = InternalServerException | InvalidParameterException | CommonErrors;
/**
 * Retrieves a list of themes for a specified Amplify app and backend
 * environment.
 */
export declare const listThemes: API.PaginatedOperationMethod<ListThemesRequest, ListThemesResponse, ListThemesError, Credentials | HttpClient.HttpClient, ThemeSummary>;
export type PutMetadataFlagError = InvalidParameterException | UnauthorizedException | CommonErrors;
/**
 * Stores the metadata information about a feature on a form.
 */
export declare const putMetadataFlag: API.OperationMethod<PutMetadataFlagRequest, PutMetadataFlagResponse, PutMetadataFlagError, Credentials | HttpClient.HttpClient>;
export type RefreshTokenError = InvalidParameterException | CommonErrors;
/**
 * This is for internal use.
 *
 * Amplify uses this action to refresh a previously issued access token that might have expired.
 */
export declare const refreshToken: API.OperationMethod<RefreshTokenRequest, RefreshTokenResponse, RefreshTokenError, Credentials | HttpClient.HttpClient>;
export type StartCodegenJobError = InternalServerException | InvalidParameterException | ThrottlingException | CommonErrors;
/**
 * Starts a code generation job for a specified Amplify app and backend environment.
 */
export declare const startCodegenJob: API.OperationMethod<StartCodegenJobRequest, StartCodegenJobResponse, StartCodegenJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Tags the resource with a tag key and value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Untags a resource with a specified Amazon Resource Name (ARN).
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateComponentError = InternalServerException | InvalidParameterException | ResourceConflictException | CommonErrors;
/**
 * Updates an existing component.
 */
export declare const updateComponent: API.OperationMethod<UpdateComponentRequest, UpdateComponentResponse, UpdateComponentError, Credentials | HttpClient.HttpClient>;
export type UpdateFormError = InternalServerException | InvalidParameterException | ResourceConflictException | CommonErrors;
/**
 * Updates an existing form.
 */
export declare const updateForm: API.OperationMethod<UpdateFormRequest, UpdateFormResponse, UpdateFormError, Credentials | HttpClient.HttpClient>;
export type UpdateThemeError = InternalServerException | InvalidParameterException | ResourceConflictException | CommonErrors;
/**
 * Updates an existing theme.
 */
export declare const updateTheme: API.OperationMethod<UpdateThemeRequest, UpdateThemeResponse, UpdateThemeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=amplifyuibuilder.d.ts.map