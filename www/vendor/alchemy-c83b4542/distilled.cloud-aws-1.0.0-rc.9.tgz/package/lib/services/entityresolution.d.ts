import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ExceedsLimitException_base: S.Class<ExceedsLimitException, S.TaggedStruct<"ExceedsLimitException", {
    readonly message: any;
    readonly quotaName: any;
    readonly quotaValue: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ExceedsLimitException extends /*@__PURE__*/ ExceedsLimitException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type VeniceGlobalArn = string;
export type StatementId = string;
export type StatementEffect = "Allow" | "Deny" | (string & {});
export declare const StatementEffect: any;
export type StatementAction = string;
export type StatementActionList = string[];
export declare const StatementActionList: any;
export type StatementPrincipal = string;
export type StatementPrincipalList = string[];
export declare const StatementPrincipalList: any;
export type StatementCondition = string;
export interface AddPolicyStatementInput {
    arn: string;
    statementId: string;
    effect: StatementEffect;
    action: string[];
    principal: string[];
    condition?: string;
}
export declare const AddPolicyStatementInput: S.Schema<AddPolicyStatementInput>;
export type PolicyToken = string;
export type PolicyDocument = string;
export interface AddPolicyStatementOutput {
    arn: string;
    token: string;
    policy?: string;
}
export declare const AddPolicyStatementOutput: S.Schema<AddPolicyStatementOutput>;
export type EntityName = string;
export type HeaderSafeUniqueId = string;
export type UniqueIdList = string[];
export declare const UniqueIdList: any;
export interface BatchDeleteUniqueIdInput {
    workflowName: string;
    inputSource?: string;
    uniqueIds: string[];
}
export declare const BatchDeleteUniqueIdInput: S.Schema<BatchDeleteUniqueIdInput>;
export type DeleteUniqueIdStatus = "COMPLETED" | "ACCEPTED" | (string & {});
export declare const DeleteUniqueIdStatus: any;
export type DeleteUniqueIdErrorType = "SERVICE_ERROR" | "VALIDATION_ERROR" | (string & {});
export declare const DeleteUniqueIdErrorType: any;
export interface DeleteUniqueIdError {
    uniqueId: string;
    errorType: DeleteUniqueIdErrorType;
}
export declare const DeleteUniqueIdError: S.Schema<DeleteUniqueIdError>;
export type DeleteUniqueIdErrorsList = DeleteUniqueIdError[];
export declare const DeleteUniqueIdErrorsList: any;
export interface DeletedUniqueId {
    uniqueId: string;
}
export declare const DeletedUniqueId: S.Schema<DeletedUniqueId>;
export type DeletedUniqueIdList = DeletedUniqueId[];
export declare const DeletedUniqueIdList: any;
export type DisconnectedUniqueIdsList = string[];
export declare const DisconnectedUniqueIdsList: any;
export interface BatchDeleteUniqueIdOutput {
    status: DeleteUniqueIdStatus;
    errors?: DeleteUniqueIdError[];
    deleted?: DeletedUniqueId[];
    disconnectedUniqueIds?: string[];
}
export declare const BatchDeleteUniqueIdOutput: S.Schema<BatchDeleteUniqueIdOutput>;
export type Description = string;
export type InputSourceARN = string;
export type IdNamespaceType = "SOURCE" | "TARGET" | (string & {});
export declare const IdNamespaceType: any;
export interface IdMappingWorkflowInputSource {
    inputSourceARN: string;
    schemaName?: string;
    type?: IdNamespaceType;
}
export declare const IdMappingWorkflowInputSource: S.Schema<IdMappingWorkflowInputSource>;
export type IdMappingWorkflowInputSourceConfig = IdMappingWorkflowInputSource[];
export declare const IdMappingWorkflowInputSourceConfig: any;
export type KMSArn = string;
export type S3Path = string;
export interface IdMappingWorkflowOutputSource {
    KMSArn?: string;
    outputS3Path: string;
}
export declare const IdMappingWorkflowOutputSource: S.Schema<IdMappingWorkflowOutputSource>;
export type IdMappingWorkflowOutputSourceConfig = IdMappingWorkflowOutputSource[];
export declare const IdMappingWorkflowOutputSourceConfig: any;
export type IdMappingType = "PROVIDER" | "RULE_BASED" | (string & {});
export declare const IdMappingType: any;
export type AttributeName = string;
export type MatchingKeys = string[];
export declare const MatchingKeys: any;
export interface Rule {
    ruleName: string;
    matchingKeys: string[];
}
export declare const Rule: S.Schema<Rule>;
export type RuleList = Rule[];
export declare const RuleList: any;
export type IdMappingWorkflowRuleDefinitionType = "SOURCE" | "TARGET" | (string & {});
export declare const IdMappingWorkflowRuleDefinitionType: any;
export type AttributeMatchingModel = "ONE_TO_ONE" | "MANY_TO_MANY" | (string & {});
export declare const AttributeMatchingModel: any;
export type RecordMatchingModel = "ONE_SOURCE_TO_ONE_TARGET" | "MANY_SOURCE_TO_ONE_TARGET" | (string & {});
export declare const RecordMatchingModel: any;
export interface IdMappingRuleBasedProperties {
    rules?: Rule[];
    ruleDefinitionType: IdMappingWorkflowRuleDefinitionType;
    attributeMatchingModel: AttributeMatchingModel;
    recordMatchingModel: RecordMatchingModel;
}
export declare const IdMappingRuleBasedProperties: S.Schema<IdMappingRuleBasedProperties>;
export type ProviderServiceArn = string;
export interface IntermediateSourceConfiguration {
    intermediateS3Path: string;
}
export declare const IntermediateSourceConfiguration: S.Schema<IntermediateSourceConfiguration>;
export interface ProviderProperties {
    providerServiceArn: string;
    providerConfiguration?: any;
    intermediateSourceConfiguration?: IntermediateSourceConfiguration;
}
export declare const ProviderProperties: S.Schema<ProviderProperties>;
export interface IdMappingTechniques {
    idMappingType: IdMappingType;
    ruleBasedProperties?: IdMappingRuleBasedProperties;
    providerProperties?: ProviderProperties;
}
export declare const IdMappingTechniques: S.Schema<IdMappingTechniques>;
export type IdMappingIncrementalRunType = "ON_DEMAND" | (string & {});
export declare const IdMappingIncrementalRunType: any;
export interface IdMappingIncrementalRunConfig {
    incrementalRunType?: IdMappingIncrementalRunType;
}
export declare const IdMappingIncrementalRunConfig: S.Schema<IdMappingIncrementalRunConfig>;
export type IdMappingRoleArn = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateIdMappingWorkflowInput {
    workflowName: string;
    description?: string;
    inputSourceConfig: IdMappingWorkflowInputSource[];
    outputSourceConfig?: IdMappingWorkflowOutputSource[];
    idMappingTechniques: IdMappingTechniques;
    incrementalRunConfig?: IdMappingIncrementalRunConfig;
    roleArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateIdMappingWorkflowInput: S.Schema<CreateIdMappingWorkflowInput>;
export type IdMappingWorkflowArn = string;
export interface CreateIdMappingWorkflowOutput {
    workflowName: string;
    workflowArn: string;
    description?: string;
    inputSourceConfig: IdMappingWorkflowInputSource[];
    outputSourceConfig?: IdMappingWorkflowOutputSource[];
    idMappingTechniques: IdMappingTechniques;
    incrementalRunConfig?: IdMappingIncrementalRunConfig;
    roleArn?: string;
}
export declare const CreateIdMappingWorkflowOutput: S.Schema<CreateIdMappingWorkflowOutput>;
export interface IdNamespaceInputSource {
    inputSourceARN: string;
    schemaName?: string;
}
export declare const IdNamespaceInputSource: S.Schema<IdNamespaceInputSource>;
export type IdNamespaceInputSourceConfig = IdNamespaceInputSource[];
export declare const IdNamespaceInputSourceConfig: any;
export type IdMappingWorkflowRuleDefinitionTypeList = IdMappingWorkflowRuleDefinitionType[];
export declare const IdMappingWorkflowRuleDefinitionTypeList: any;
export type RecordMatchingModelList = RecordMatchingModel[];
export declare const RecordMatchingModelList: any;
export interface NamespaceRuleBasedProperties {
    rules?: Rule[];
    ruleDefinitionTypes?: IdMappingWorkflowRuleDefinitionType[];
    attributeMatchingModel?: AttributeMatchingModel;
    recordMatchingModels?: RecordMatchingModel[];
}
export declare const NamespaceRuleBasedProperties: S.Schema<NamespaceRuleBasedProperties>;
export interface NamespaceProviderProperties {
    providerServiceArn: string;
    providerConfiguration?: any;
}
export declare const NamespaceProviderProperties: S.Schema<NamespaceProviderProperties>;
export interface IdNamespaceIdMappingWorkflowProperties {
    idMappingType: IdMappingType;
    ruleBasedProperties?: NamespaceRuleBasedProperties;
    providerProperties?: NamespaceProviderProperties;
}
export declare const IdNamespaceIdMappingWorkflowProperties: S.Schema<IdNamespaceIdMappingWorkflowProperties>;
export type IdNamespaceIdMappingWorkflowPropertiesList = IdNamespaceIdMappingWorkflowProperties[];
export declare const IdNamespaceIdMappingWorkflowPropertiesList: any;
export type RoleArn = string;
export interface CreateIdNamespaceInput {
    idNamespaceName: string;
    description?: string;
    inputSourceConfig?: IdNamespaceInputSource[];
    idMappingWorkflowProperties?: IdNamespaceIdMappingWorkflowProperties[];
    type: IdNamespaceType;
    roleArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateIdNamespaceInput: S.Schema<CreateIdNamespaceInput>;
export type IdNamespaceArn = string;
export interface CreateIdNamespaceOutput {
    idNamespaceName: string;
    idNamespaceArn: string;
    description?: string;
    inputSourceConfig?: IdNamespaceInputSource[];
    idMappingWorkflowProperties?: IdNamespaceIdMappingWorkflowProperties[];
    type: IdNamespaceType;
    roleArn?: string;
    createdAt: Date;
    updatedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateIdNamespaceOutput: S.Schema<CreateIdNamespaceOutput>;
export interface InputSource {
    inputSourceARN: string;
    schemaName: string;
    applyNormalization?: boolean;
}
export declare const InputSource: S.Schema<InputSource>;
export type InputSourceConfig = InputSource[];
export declare const InputSourceConfig: any;
export type OptionalS3Path = string;
export interface OutputAttribute {
    name: string;
    hashed?: boolean;
}
export declare const OutputAttribute: S.Schema<OutputAttribute>;
export type OutputAttributes = OutputAttribute[];
export declare const OutputAttributes: any;
export type CustomerProfilesDomainArn = string;
export type CustomerProfilesObjectTypeArn = string;
export interface CustomerProfilesIntegrationConfig {
    domainArn: string;
    objectTypeArn: string;
}
export declare const CustomerProfilesIntegrationConfig: S.Schema<CustomerProfilesIntegrationConfig>;
export interface OutputSource {
    KMSArn?: string;
    outputS3Path?: string;
    output: OutputAttribute[];
    applyNormalization?: boolean;
    customerProfilesIntegrationConfig?: CustomerProfilesIntegrationConfig;
}
export declare const OutputSource: S.Schema<OutputSource>;
export type OutputSourceConfig = OutputSource[];
export declare const OutputSourceConfig: any;
export type ResolutionType = "RULE_MATCHING" | "ML_MATCHING" | "PROVIDER" | (string & {});
export declare const ResolutionType: any;
export type MatchPurpose = "IDENTIFIER_GENERATION" | "INDEXING" | (string & {});
export declare const MatchPurpose: any;
export interface RuleBasedProperties {
    rules: Rule[];
    attributeMatchingModel: AttributeMatchingModel;
    matchPurpose?: MatchPurpose;
}
export declare const RuleBasedProperties: S.Schema<RuleBasedProperties>;
export interface RuleCondition {
    ruleName: string;
    condition: string;
}
export declare const RuleCondition: S.Schema<RuleCondition>;
export type RuleConditionList = RuleCondition[];
export declare const RuleConditionList: any;
export interface MatchingConfig {
    enableTransitiveMatching?: boolean;
}
export declare const MatchingConfig: S.Schema<MatchingConfig>;
export interface RuleConditionProperties {
    rules: RuleCondition[];
    matchingConfig?: MatchingConfig;
}
export declare const RuleConditionProperties: S.Schema<RuleConditionProperties>;
export interface ResolutionTechniques {
    resolutionType: ResolutionType;
    ruleBasedProperties?: RuleBasedProperties;
    ruleConditionProperties?: RuleConditionProperties;
    enableRealTimeMatching?: boolean;
    providerProperties?: ProviderProperties;
}
export declare const ResolutionTechniques: S.Schema<ResolutionTechniques>;
export type IncrementalRunType = "IMMEDIATE" | (string & {});
export declare const IncrementalRunType: any;
export interface IncrementalRunConfig {
    incrementalRunType?: IncrementalRunType;
}
export declare const IncrementalRunConfig: S.Schema<IncrementalRunConfig>;
export interface CreateMatchingWorkflowInput {
    workflowName: string;
    description?: string;
    inputSourceConfig: InputSource[];
    outputSourceConfig: OutputSource[];
    resolutionTechniques: ResolutionTechniques;
    incrementalRunConfig?: IncrementalRunConfig;
    roleArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateMatchingWorkflowInput: S.Schema<CreateMatchingWorkflowInput>;
export type MatchingWorkflowArn = string;
export interface CreateMatchingWorkflowOutput {
    workflowName: string;
    workflowArn: string;
    description?: string;
    inputSourceConfig: InputSource[];
    outputSourceConfig: OutputSource[];
    resolutionTechniques: ResolutionTechniques;
    incrementalRunConfig?: IncrementalRunConfig;
    roleArn: string;
}
export declare const CreateMatchingWorkflowOutput: S.Schema<CreateMatchingWorkflowOutput>;
export type SchemaAttributeType = "NAME" | "NAME_FIRST" | "NAME_MIDDLE" | "NAME_LAST" | "ADDRESS" | "ADDRESS_STREET1" | "ADDRESS_STREET2" | "ADDRESS_STREET3" | "ADDRESS_CITY" | "ADDRESS_STATE" | "ADDRESS_COUNTRY" | "ADDRESS_POSTALCODE" | "PHONE" | "PHONE_NUMBER" | "PHONE_COUNTRYCODE" | "EMAIL_ADDRESS" | "UNIQUE_ID" | "DATE" | "STRING" | "PROVIDER_ID" | "IPV4" | "IPV6" | "MAID" | (string & {});
export declare const SchemaAttributeType: any;
export interface SchemaInputAttribute {
    fieldName: string;
    type: SchemaAttributeType;
    groupName?: string;
    matchKey?: string;
    subType?: string;
    hashed?: boolean;
}
export declare const SchemaInputAttribute: S.Schema<SchemaInputAttribute>;
export type SchemaInputAttributes = SchemaInputAttribute[];
export declare const SchemaInputAttributes: any;
export interface CreateSchemaMappingInput {
    schemaName: string;
    description?: string;
    mappedInputFields: SchemaInputAttribute[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateSchemaMappingInput: S.Schema<CreateSchemaMappingInput>;
export type SchemaMappingArn = string;
export interface CreateSchemaMappingOutput {
    schemaName: string;
    schemaArn: string;
    description?: string;
    mappedInputFields: SchemaInputAttribute[];
}
export declare const CreateSchemaMappingOutput: S.Schema<CreateSchemaMappingOutput>;
export interface DeleteIdMappingWorkflowInput {
    workflowName: string;
}
export declare const DeleteIdMappingWorkflowInput: S.Schema<DeleteIdMappingWorkflowInput>;
export interface DeleteIdMappingWorkflowOutput {
    message: string;
}
export declare const DeleteIdMappingWorkflowOutput: S.Schema<DeleteIdMappingWorkflowOutput>;
export interface DeleteIdNamespaceInput {
    idNamespaceName: string;
}
export declare const DeleteIdNamespaceInput: S.Schema<DeleteIdNamespaceInput>;
export interface DeleteIdNamespaceOutput {
    message: string;
}
export declare const DeleteIdNamespaceOutput: S.Schema<DeleteIdNamespaceOutput>;
export interface DeleteMatchingWorkflowInput {
    workflowName: string;
}
export declare const DeleteMatchingWorkflowInput: S.Schema<DeleteMatchingWorkflowInput>;
export interface DeleteMatchingWorkflowOutput {
    message: string;
}
export declare const DeleteMatchingWorkflowOutput: S.Schema<DeleteMatchingWorkflowOutput>;
export interface DeletePolicyStatementInput {
    arn: string;
    statementId: string;
}
export declare const DeletePolicyStatementInput: S.Schema<DeletePolicyStatementInput>;
export interface DeletePolicyStatementOutput {
    arn: string;
    token: string;
    policy?: string;
}
export declare const DeletePolicyStatementOutput: S.Schema<DeletePolicyStatementOutput>;
export interface DeleteSchemaMappingInput {
    schemaName: string;
}
export declare const DeleteSchemaMappingInput: S.Schema<DeleteSchemaMappingInput>;
export interface DeleteSchemaMappingOutput {
    message: string;
}
export declare const DeleteSchemaMappingOutput: S.Schema<DeleteSchemaMappingOutput>;
export type UniqueId = string;
export type RecordAttributeMapString255 = {
    [key: string]: string | undefined;
};
export declare const RecordAttributeMapString255: any;
export interface Record {
    inputSourceARN: string;
    uniqueId: string;
    recordAttributeMap: {
        [key: string]: string | undefined;
    };
}
export declare const Record: S.Schema<Record>;
export type RecordList = Record[];
export declare const RecordList: any;
export type ProcessingType = "CONSISTENT" | "EVENTUAL" | "EVENTUAL_NO_LOOKUP" | (string & {});
export declare const ProcessingType: any;
export interface GenerateMatchIdInput {
    workflowName: string;
    records: Record[];
    processingType?: ProcessingType;
}
export declare const GenerateMatchIdInput: S.Schema<GenerateMatchIdInput>;
export interface MatchedRecord {
    inputSourceARN: string;
    recordId: string;
}
export declare const MatchedRecord: S.Schema<MatchedRecord>;
export type MatchedRecordsList = MatchedRecord[];
export declare const MatchedRecordsList: any;
export interface MatchGroup {
    records: MatchedRecord[];
    matchId: string;
    matchRule: string;
}
export declare const MatchGroup: S.Schema<MatchGroup>;
export type MatchGroupsList = MatchGroup[];
export declare const MatchGroupsList: any;
export type ErrorMessage = string;
export interface FailedRecord {
    inputSourceARN: string;
    uniqueId: string;
    errorMessage: string;
}
export declare const FailedRecord: S.Schema<FailedRecord>;
export type FailedRecordsList = FailedRecord[];
export declare const FailedRecordsList: any;
export interface GenerateMatchIdOutput {
    matchGroups: MatchGroup[];
    failedRecords: FailedRecord[];
}
export declare const GenerateMatchIdOutput: S.Schema<GenerateMatchIdOutput>;
export type EntityNameOrIdMappingWorkflowArn = string;
export type JobId = string;
export interface GetIdMappingJobInput {
    workflowName: string;
    jobId: string;
}
export declare const GetIdMappingJobInput: S.Schema<GetIdMappingJobInput>;
export type JobStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | "QUEUED" | (string & {});
export declare const JobStatus: any;
export interface IdMappingJobMetrics {
    inputRecords?: number;
    totalRecordsProcessed?: number;
    recordsNotProcessed?: number;
    deleteRecordsProcessed?: number;
    totalMappedRecords?: number;
    totalMappedSourceRecords?: number;
    totalMappedTargetRecords?: number;
    uniqueRecordsLoaded?: number;
    newMappedRecords?: number;
    newMappedSourceRecords?: number;
    newMappedTargetRecords?: number;
    newUniqueRecordsLoaded?: number;
    mappedRecordsRemoved?: number;
    mappedSourceRecordsRemoved?: number;
    mappedTargetRecordsRemoved?: number;
}
export declare const IdMappingJobMetrics: S.Schema<IdMappingJobMetrics>;
export interface ErrorDetails {
    errorMessage?: string;
}
export declare const ErrorDetails: S.Schema<ErrorDetails>;
export interface IdMappingJobOutputSource {
    roleArn: string;
    outputS3Path: string;
    KMSArn?: string;
}
export declare const IdMappingJobOutputSource: S.Schema<IdMappingJobOutputSource>;
export type IdMappingJobOutputSourceConfig = IdMappingJobOutputSource[];
export declare const IdMappingJobOutputSourceConfig: any;
export type JobType = "BATCH" | "INCREMENTAL" | "DELETE_ONLY" | (string & {});
export declare const JobType: any;
export interface GetIdMappingJobOutput {
    jobId: string;
    status: JobStatus;
    startTime: Date;
    endTime?: Date;
    metrics?: IdMappingJobMetrics;
    errorDetails?: ErrorDetails;
    outputSourceConfig?: IdMappingJobOutputSource[];
    jobType?: JobType;
}
export declare const GetIdMappingJobOutput: S.Schema<GetIdMappingJobOutput>;
export interface GetIdMappingWorkflowInput {
    workflowName: string;
}
export declare const GetIdMappingWorkflowInput: S.Schema<GetIdMappingWorkflowInput>;
export interface GetIdMappingWorkflowOutput {
    workflowName: string;
    workflowArn: string;
    description?: string;
    inputSourceConfig: IdMappingWorkflowInputSource[];
    outputSourceConfig?: IdMappingWorkflowOutputSource[];
    idMappingTechniques: IdMappingTechniques;
    createdAt: Date;
    updatedAt: Date;
    incrementalRunConfig?: IdMappingIncrementalRunConfig;
    roleArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetIdMappingWorkflowOutput: S.Schema<GetIdMappingWorkflowOutput>;
export type EntityNameOrIdNamespaceArn = string;
export interface GetIdNamespaceInput {
    idNamespaceName: string;
}
export declare const GetIdNamespaceInput: S.Schema<GetIdNamespaceInput>;
export interface GetIdNamespaceOutput {
    idNamespaceName: string;
    idNamespaceArn: string;
    description?: string;
    inputSourceConfig?: IdNamespaceInputSource[];
    idMappingWorkflowProperties?: IdNamespaceIdMappingWorkflowProperties[];
    type: IdNamespaceType;
    roleArn?: string;
    createdAt: Date;
    updatedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetIdNamespaceOutput: S.Schema<GetIdNamespaceOutput>;
export type RecordAttributeMap = {
    [key: string]: string | undefined;
};
export declare const RecordAttributeMap: any;
export interface GetMatchIdInput {
    workflowName: string;
    record: {
        [key: string]: string | undefined;
    };
    applyNormalization?: boolean;
}
export declare const GetMatchIdInput: S.Schema<GetMatchIdInput>;
export interface GetMatchIdOutput {
    matchId?: string;
    matchRule?: string;
}
export declare const GetMatchIdOutput: S.Schema<GetMatchIdOutput>;
export interface GetMatchingJobInput {
    workflowName: string;
    jobId: string;
}
export declare const GetMatchingJobInput: S.Schema<GetMatchingJobInput>;
export interface JobMetrics {
    inputRecords?: number;
    totalRecordsProcessed?: number;
    recordsNotProcessed?: number;
    deleteRecordsProcessed?: number;
    matchIDs?: number;
}
export declare const JobMetrics: S.Schema<JobMetrics>;
export interface JobOutputSource {
    roleArn: string;
    outputS3Path: string;
    KMSArn?: string;
}
export declare const JobOutputSource: S.Schema<JobOutputSource>;
export type JobOutputSourceConfig = JobOutputSource[];
export declare const JobOutputSourceConfig: any;
export interface GetMatchingJobOutput {
    jobId: string;
    status: JobStatus;
    startTime: Date;
    endTime?: Date;
    metrics?: JobMetrics;
    errorDetails?: ErrorDetails;
    outputSourceConfig?: JobOutputSource[];
}
export declare const GetMatchingJobOutput: S.Schema<GetMatchingJobOutput>;
export interface GetMatchingWorkflowInput {
    workflowName: string;
}
export declare const GetMatchingWorkflowInput: S.Schema<GetMatchingWorkflowInput>;
export interface GetMatchingWorkflowOutput {
    workflowName: string;
    workflowArn: string;
    description?: string;
    inputSourceConfig: InputSource[];
    outputSourceConfig: OutputSource[];
    resolutionTechniques: ResolutionTechniques;
    createdAt: Date;
    updatedAt: Date;
    incrementalRunConfig?: IncrementalRunConfig;
    roleArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetMatchingWorkflowOutput: S.Schema<GetMatchingWorkflowOutput>;
export interface GetPolicyInput {
    arn: string;
}
export declare const GetPolicyInput: S.Schema<GetPolicyInput>;
export interface GetPolicyOutput {
    arn: string;
    token: string;
    policy?: string;
}
export declare const GetPolicyOutput: S.Schema<GetPolicyOutput>;
export interface GetProviderServiceInput {
    providerName: string;
    providerServiceName: string;
}
export declare const GetProviderServiceInput: S.Schema<GetProviderServiceInput>;
export type ProviderServiceDisplayName = string;
export type ServiceType = "ASSIGNMENT" | "ID_MAPPING" | (string & {});
export declare const ServiceType: any;
export interface ProviderIdNameSpaceConfiguration {
    description?: string;
    providerTargetConfigurationDefinition?: any;
    providerSourceConfigurationDefinition?: any;
}
export declare const ProviderIdNameSpaceConfiguration: S.Schema<ProviderIdNameSpaceConfiguration>;
export interface ProviderMarketplaceConfiguration {
    dataSetId: string;
    revisionId: string;
    assetId: string;
    listingId: string;
}
export declare const ProviderMarketplaceConfiguration: S.Schema<ProviderMarketplaceConfiguration>;
export type ProviderEndpointConfiguration = {
    marketplaceConfiguration: ProviderMarketplaceConfiguration;
};
export declare const ProviderEndpointConfiguration: any;
export type AwsAccountId = string;
export type AwsAccountIdList = string[];
export declare const AwsAccountIdList: any;
export type RequiredBucketActionsList = string[];
export declare const RequiredBucketActionsList: any;
export interface ProviderIntermediateDataAccessConfiguration {
    awsAccountIds?: string[];
    requiredBucketActions?: string[];
}
export declare const ProviderIntermediateDataAccessConfiguration: S.Schema<ProviderIntermediateDataAccessConfiguration>;
export type SchemaList = string[];
export declare const SchemaList: any;
export type Schemas = string[][];
export declare const Schemas: any;
export interface ProviderSchemaAttribute {
    fieldName: string;
    type: SchemaAttributeType;
    subType?: string;
    hashing?: boolean;
}
export declare const ProviderSchemaAttribute: S.Schema<ProviderSchemaAttribute>;
export type ProviderSchemaAttributes = ProviderSchemaAttribute[];
export declare const ProviderSchemaAttributes: any;
export interface ProviderComponentSchema {
    schemas?: string[][];
    providerSchemaAttributes?: ProviderSchemaAttribute[];
}
export declare const ProviderComponentSchema: S.Schema<ProviderComponentSchema>;
export interface GetProviderServiceOutput {
    providerName: string;
    providerServiceName: string;
    providerServiceDisplayName: string;
    providerServiceType: ServiceType;
    providerServiceArn: string;
    providerConfigurationDefinition?: any;
    providerIdNameSpaceConfiguration?: ProviderIdNameSpaceConfiguration;
    providerJobConfiguration?: any;
    providerEndpointConfiguration: ProviderEndpointConfiguration;
    anonymizedOutput: boolean;
    providerEntityOutputDefinition: any;
    providerIntermediateDataAccessConfiguration?: ProviderIntermediateDataAccessConfiguration;
    providerComponentSchema?: ProviderComponentSchema;
}
export declare const GetProviderServiceOutput: S.Schema<GetProviderServiceOutput>;
export interface GetSchemaMappingInput {
    schemaName: string;
}
export declare const GetSchemaMappingInput: S.Schema<GetSchemaMappingInput>;
export interface GetSchemaMappingOutput {
    schemaName: string;
    schemaArn: string;
    description?: string;
    mappedInputFields: SchemaInputAttribute[];
    createdAt: Date;
    updatedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    hasWorkflows: boolean;
}
export declare const GetSchemaMappingOutput: S.Schema<GetSchemaMappingOutput>;
export type NextToken = string;
export interface ListIdMappingJobsInput {
    workflowName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListIdMappingJobsInput: S.Schema<ListIdMappingJobsInput>;
export interface JobSummary {
    jobId: string;
    status: JobStatus;
    startTime: Date;
    endTime?: Date;
}
export declare const JobSummary: S.Schema<JobSummary>;
export type JobList = JobSummary[];
export declare const JobList: any;
export interface ListIdMappingJobsOutput {
    jobs?: JobSummary[];
    nextToken?: string;
}
export declare const ListIdMappingJobsOutput: S.Schema<ListIdMappingJobsOutput>;
export interface ListIdMappingWorkflowsInput {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListIdMappingWorkflowsInput: S.Schema<ListIdMappingWorkflowsInput>;
export interface IdMappingWorkflowSummary {
    workflowName: string;
    workflowArn: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const IdMappingWorkflowSummary: S.Schema<IdMappingWorkflowSummary>;
export type IdMappingWorkflowList = IdMappingWorkflowSummary[];
export declare const IdMappingWorkflowList: any;
export interface ListIdMappingWorkflowsOutput {
    workflowSummaries?: IdMappingWorkflowSummary[];
    nextToken?: string;
}
export declare const ListIdMappingWorkflowsOutput: S.Schema<ListIdMappingWorkflowsOutput>;
export interface ListIdNamespacesInput {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListIdNamespacesInput: S.Schema<ListIdNamespacesInput>;
export interface IdNamespaceIdMappingWorkflowMetadata {
    idMappingType: IdMappingType;
}
export declare const IdNamespaceIdMappingWorkflowMetadata: S.Schema<IdNamespaceIdMappingWorkflowMetadata>;
export type IdNamespaceIdMappingWorkflowMetadataList = IdNamespaceIdMappingWorkflowMetadata[];
export declare const IdNamespaceIdMappingWorkflowMetadataList: any;
export interface IdNamespaceSummary {
    idNamespaceName: string;
    idNamespaceArn: string;
    description?: string;
    idMappingWorkflowProperties?: IdNamespaceIdMappingWorkflowMetadata[];
    type: IdNamespaceType;
    createdAt: Date;
    updatedAt: Date;
}
export declare const IdNamespaceSummary: S.Schema<IdNamespaceSummary>;
export type IdNamespaceList = IdNamespaceSummary[];
export declare const IdNamespaceList: any;
export interface ListIdNamespacesOutput {
    idNamespaceSummaries?: IdNamespaceSummary[];
    nextToken?: string;
}
export declare const ListIdNamespacesOutput: S.Schema<ListIdNamespacesOutput>;
export interface ListMatchingJobsInput {
    workflowName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListMatchingJobsInput: S.Schema<ListMatchingJobsInput>;
export interface ListMatchingJobsOutput {
    jobs?: JobSummary[];
    nextToken?: string;
}
export declare const ListMatchingJobsOutput: S.Schema<ListMatchingJobsOutput>;
export interface ListMatchingWorkflowsInput {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListMatchingWorkflowsInput: S.Schema<ListMatchingWorkflowsInput>;
export interface MatchingWorkflowSummary {
    workflowName: string;
    workflowArn: string;
    createdAt: Date;
    updatedAt: Date;
    resolutionType: ResolutionType;
}
export declare const MatchingWorkflowSummary: S.Schema<MatchingWorkflowSummary>;
export type MatchingWorkflowList = MatchingWorkflowSummary[];
export declare const MatchingWorkflowList: any;
export interface ListMatchingWorkflowsOutput {
    workflowSummaries?: MatchingWorkflowSummary[];
    nextToken?: string;
}
export declare const ListMatchingWorkflowsOutput: S.Schema<ListMatchingWorkflowsOutput>;
export interface ListProviderServicesInput {
    nextToken?: string;
    maxResults?: number;
    providerName?: string;
}
export declare const ListProviderServicesInput: S.Schema<ListProviderServicesInput>;
export interface ProviderServiceSummary {
    providerServiceArn: string;
    providerName: string;
    providerServiceDisplayName: string;
    providerServiceName: string;
    providerServiceType: ServiceType;
}
export declare const ProviderServiceSummary: S.Schema<ProviderServiceSummary>;
export type ProviderServiceList = ProviderServiceSummary[];
export declare const ProviderServiceList: any;
export interface ListProviderServicesOutput {
    providerServiceSummaries?: ProviderServiceSummary[];
    nextToken?: string;
}
export declare const ListProviderServicesOutput: S.Schema<ListProviderServicesOutput>;
export interface ListSchemaMappingsInput {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListSchemaMappingsInput: S.Schema<ListSchemaMappingsInput>;
export interface SchemaMappingSummary {
    schemaName: string;
    schemaArn: string;
    createdAt: Date;
    updatedAt: Date;
    hasWorkflows: boolean;
}
export declare const SchemaMappingSummary: S.Schema<SchemaMappingSummary>;
export type SchemaMappingList = SchemaMappingSummary[];
export declare const SchemaMappingList: any;
export interface ListSchemaMappingsOutput {
    schemaList?: SchemaMappingSummary[];
    nextToken?: string;
}
export declare const ListSchemaMappingsOutput: S.Schema<ListSchemaMappingsOutput>;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export declare const ListTagsForResourceInput: S.Schema<ListTagsForResourceInput>;
export interface ListTagsForResourceOutput {
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceOutput: S.Schema<ListTagsForResourceOutput>;
export interface PutPolicyInput {
    arn: string;
    token?: string;
    policy: string;
}
export declare const PutPolicyInput: S.Schema<PutPolicyInput>;
export interface PutPolicyOutput {
    arn: string;
    token: string;
    policy?: string;
}
export declare const PutPolicyOutput: S.Schema<PutPolicyOutput>;
export interface StartIdMappingJobInput {
    workflowName: string;
    outputSourceConfig?: IdMappingJobOutputSource[];
    jobType?: JobType;
}
export declare const StartIdMappingJobInput: S.Schema<StartIdMappingJobInput>;
export interface StartIdMappingJobOutput {
    jobId: string;
    outputSourceConfig?: IdMappingJobOutputSource[];
    jobType?: JobType;
}
export declare const StartIdMappingJobOutput: S.Schema<StartIdMappingJobOutput>;
export interface StartMatchingJobInput {
    workflowName: string;
}
export declare const StartMatchingJobInput: S.Schema<StartMatchingJobInput>;
export interface StartMatchingJobOutput {
    jobId: string;
}
export declare const StartMatchingJobOutput: S.Schema<StartMatchingJobOutput>;
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceInput: S.Schema<TagResourceInput>;
export interface TagResourceOutput {
}
export declare const TagResourceOutput: S.Schema<TagResourceOutput>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceInput: S.Schema<UntagResourceInput>;
export interface UntagResourceOutput {
}
export declare const UntagResourceOutput: S.Schema<UntagResourceOutput>;
export interface UpdateIdMappingWorkflowInput {
    workflowName: string;
    description?: string;
    inputSourceConfig: IdMappingWorkflowInputSource[];
    outputSourceConfig?: IdMappingWorkflowOutputSource[];
    idMappingTechniques: IdMappingTechniques;
    incrementalRunConfig?: IdMappingIncrementalRunConfig;
    roleArn?: string;
}
export declare const UpdateIdMappingWorkflowInput: S.Schema<UpdateIdMappingWorkflowInput>;
export interface UpdateIdMappingWorkflowOutput {
    workflowName: string;
    workflowArn: string;
    description?: string;
    inputSourceConfig: IdMappingWorkflowInputSource[];
    outputSourceConfig?: IdMappingWorkflowOutputSource[];
    idMappingTechniques: IdMappingTechniques;
    incrementalRunConfig?: IdMappingIncrementalRunConfig;
    roleArn?: string;
}
export declare const UpdateIdMappingWorkflowOutput: S.Schema<UpdateIdMappingWorkflowOutput>;
export interface UpdateIdNamespaceInput {
    idNamespaceName: string;
    description?: string;
    inputSourceConfig?: IdNamespaceInputSource[];
    idMappingWorkflowProperties?: IdNamespaceIdMappingWorkflowProperties[];
    roleArn?: string;
}
export declare const UpdateIdNamespaceInput: S.Schema<UpdateIdNamespaceInput>;
export interface UpdateIdNamespaceOutput {
    idNamespaceName: string;
    idNamespaceArn: string;
    description?: string;
    inputSourceConfig?: IdNamespaceInputSource[];
    idMappingWorkflowProperties?: IdNamespaceIdMappingWorkflowProperties[];
    type: IdNamespaceType;
    roleArn?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const UpdateIdNamespaceOutput: S.Schema<UpdateIdNamespaceOutput>;
export interface UpdateMatchingWorkflowInput {
    workflowName: string;
    description?: string;
    inputSourceConfig: InputSource[];
    outputSourceConfig: OutputSource[];
    resolutionTechniques: ResolutionTechniques;
    incrementalRunConfig?: IncrementalRunConfig;
    roleArn: string;
}
export declare const UpdateMatchingWorkflowInput: S.Schema<UpdateMatchingWorkflowInput>;
export interface UpdateMatchingWorkflowOutput {
    workflowName: string;
    description?: string;
    inputSourceConfig: InputSource[];
    outputSourceConfig: OutputSource[];
    resolutionTechniques: ResolutionTechniques;
    incrementalRunConfig?: IncrementalRunConfig;
    roleArn: string;
}
export declare const UpdateMatchingWorkflowOutput: S.Schema<UpdateMatchingWorkflowOutput>;
export interface UpdateSchemaMappingInput {
    schemaName: string;
    description?: string;
    mappedInputFields: SchemaInputAttribute[];
}
export declare const UpdateSchemaMappingInput: S.Schema<UpdateSchemaMappingInput>;
export interface UpdateSchemaMappingOutput {
    schemaName: string;
    schemaArn: string;
    description?: string;
    mappedInputFields: SchemaInputAttribute[];
}
export declare const UpdateSchemaMappingOutput: S.Schema<UpdateSchemaMappingOutput>;
export type AddPolicyStatementError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a policy statement object. To retrieve a list of existing policy statements, use the `GetPolicy` API.
 */
export declare const addPolicyStatement: API.OperationMethod<AddPolicyStatementInput, AddPolicyStatementOutput, AddPolicyStatementError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteUniqueIdError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes multiple unique IDs in a matching workflow.
 */
export declare const batchDeleteUniqueId: API.OperationMethod<BatchDeleteUniqueIdInput, BatchDeleteUniqueIdOutput, BatchDeleteUniqueIdError, Credentials | HttpClient.HttpClient>;
export type CreateIdMappingWorkflowError = AccessDeniedException | ConflictException | ExceedsLimitException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an `IdMappingWorkflow` object which stores the configuration of the data processing job to be run. Each `IdMappingWorkflow` must have a unique workflow name. To modify an existing workflow, use the UpdateIdMappingWorkflow API.
 *
 * Incremental processing is not supported for ID mapping workflows.
 */
export declare const createIdMappingWorkflow: API.OperationMethod<CreateIdMappingWorkflowInput, CreateIdMappingWorkflowOutput, CreateIdMappingWorkflowError, Credentials | HttpClient.HttpClient>;
export type CreateIdNamespaceError = AccessDeniedException | ConflictException | ExceedsLimitException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ID namespace object which will help customers provide metadata explaining their dataset and how to use it. Each ID namespace must have a unique name. To modify an existing ID namespace, use the UpdateIdNamespace API.
 */
export declare const createIdNamespace: API.OperationMethod<CreateIdNamespaceInput, CreateIdNamespaceOutput, CreateIdNamespaceError, Credentials | HttpClient.HttpClient>;
export type CreateMatchingWorkflowError = AccessDeniedException | ConflictException | ExceedsLimitException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a matching workflow that defines the configuration for a data processing job. The workflow name must be unique. To modify an existing workflow, use `UpdateMatchingWorkflow`.
 *
 * For workflows where `resolutionType` is `PROVIDER`, incremental processing is not supported.
 */
export declare const createMatchingWorkflow: API.OperationMethod<CreateMatchingWorkflowInput, CreateMatchingWorkflowOutput, CreateMatchingWorkflowError, Credentials | HttpClient.HttpClient>;
export type CreateSchemaMappingError = AccessDeniedException | ConflictException | ExceedsLimitException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a schema mapping, which defines the schema of the input customer records table. The `SchemaMapping` also provides Entity Resolution with some metadata about the table, such as the attribute types of the columns and which columns to match on.
 */
export declare const createSchemaMapping: API.OperationMethod<CreateSchemaMappingInput, CreateSchemaMappingOutput, CreateSchemaMappingError, Credentials | HttpClient.HttpClient>;
export type DeleteIdMappingWorkflowError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the `IdMappingWorkflow` with a given name. This operation returns a `ResourceNotFoundException` if a workflow with the given name does not exist.
 */
export declare const deleteIdMappingWorkflow: API.OperationMethod<DeleteIdMappingWorkflowInput, DeleteIdMappingWorkflowOutput, DeleteIdMappingWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeleteIdNamespaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | CommonErrors;
/**
 * Deletes the `IdNamespace` with a given name. This operation returns a `ResourceNotFoundException` if an ID namespace with the given name does not exist.
 */
export declare const deleteIdNamespace: API.OperationMethod<DeleteIdNamespaceInput, DeleteIdNamespaceOutput, DeleteIdNamespaceError, Credentials | HttpClient.HttpClient>;
export type DeleteMatchingWorkflowError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the `MatchingWorkflow` with a given name. This operation returns a `ResourceNotFoundException` if a workflow with the given name does not exist.
 */
export declare const deleteMatchingWorkflow: API.OperationMethod<DeleteMatchingWorkflowInput, DeleteMatchingWorkflowOutput, DeleteMatchingWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyStatementError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the policy statement.
 */
export declare const deletePolicyStatement: API.OperationMethod<DeletePolicyStatementInput, DeletePolicyStatementOutput, DeletePolicyStatementError, Credentials | HttpClient.HttpClient>;
export type DeleteSchemaMappingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the `SchemaMapping` with a given name. This operation returns a `ResourceNotFoundException` if a schema with the given name does not exist. This operation will fail if there is a `MatchingWorkflow` object that references the `SchemaMapping` in the workflow's `InputSourceConfig`.
 */
export declare const deleteSchemaMapping: API.OperationMethod<DeleteSchemaMappingInput, DeleteSchemaMappingOutput, DeleteSchemaMappingError, Credentials | HttpClient.HttpClient>;
export type GenerateMatchIdError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates or retrieves Match IDs for records using a rule-based matching workflow. When you call this operation, it processes your records against the workflow's matching rules to identify potential matches. For existing records, it retrieves their Match IDs and associated rules. For records without matches, it generates new Match IDs. The operation saves results to Amazon S3.
 *
 * The processing type (`processingType`) you choose affects both the accuracy and response time of the operation. Additional charges apply for each API call, whether made through the Entity Resolution console or directly via the API. The rule-based matching workflow must exist and be active before calling this operation.
 */
export declare const generateMatchId: API.OperationMethod<GenerateMatchIdInput, GenerateMatchIdOutput, GenerateMatchIdError, Credentials | HttpClient.HttpClient>;
export type GetIdMappingJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the status, metrics, and errors (if there are any) that are associated with a job.
 */
export declare const getIdMappingJob: API.OperationMethod<GetIdMappingJobInput, GetIdMappingJobOutput, GetIdMappingJobError, Credentials | HttpClient.HttpClient>;
export type GetIdMappingWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the `IdMappingWorkflow` with a given name, if it exists.
 */
export declare const getIdMappingWorkflow: API.OperationMethod<GetIdMappingWorkflowInput, GetIdMappingWorkflowOutput, GetIdMappingWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetIdNamespaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the `IdNamespace` with a given name, if it exists.
 */
export declare const getIdNamespace: API.OperationMethod<GetIdNamespaceInput, GetIdNamespaceOutput, GetIdNamespaceError, Credentials | HttpClient.HttpClient>;
export type GetMatchIdError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the corresponding Match ID of a customer record if the record has been processed in a rule-based matching workflow.
 *
 * You can call this API as a dry run of an incremental load on the rule-based matching workflow.
 */
export declare const getMatchId: API.OperationMethod<GetMatchIdInput, GetMatchIdOutput, GetMatchIdError, Credentials | HttpClient.HttpClient>;
export type GetMatchingJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the status, metrics, and errors (if there are any) that are associated with a job.
 */
export declare const getMatchingJob: API.OperationMethod<GetMatchingJobInput, GetMatchingJobOutput, GetMatchingJobError, Credentials | HttpClient.HttpClient>;
export type GetMatchingWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the `MatchingWorkflow` with a given name, if it exists.
 */
export declare const getMatchingWorkflow: API.OperationMethod<GetMatchingWorkflowInput, GetMatchingWorkflowOutput, GetMatchingWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the resource-based policy.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyInput, GetPolicyOutput, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetProviderServiceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the `ProviderService` of a given name.
 */
export declare const getProviderService: API.OperationMethod<GetProviderServiceInput, GetProviderServiceOutput, GetProviderServiceError, Credentials | HttpClient.HttpClient>;
export type GetSchemaMappingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the SchemaMapping of a given name.
 */
export declare const getSchemaMapping: API.OperationMethod<GetSchemaMappingInput, GetSchemaMappingOutput, GetSchemaMappingError, Credentials | HttpClient.HttpClient>;
export type ListIdMappingJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all ID mapping jobs for a given workflow.
 */
export declare const listIdMappingJobs: API.PaginatedOperationMethod<ListIdMappingJobsInput, ListIdMappingJobsOutput, ListIdMappingJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListIdMappingWorkflowsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the `IdMappingWorkflows` that have been created for an Amazon Web Services account.
 */
export declare const listIdMappingWorkflows: API.PaginatedOperationMethod<ListIdMappingWorkflowsInput, ListIdMappingWorkflowsOutput, ListIdMappingWorkflowsError, Credentials | HttpClient.HttpClient, IdMappingWorkflowSummary>;
export type ListIdNamespacesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all ID namespaces.
 */
export declare const listIdNamespaces: API.PaginatedOperationMethod<ListIdNamespacesInput, ListIdNamespacesOutput, ListIdNamespacesError, Credentials | HttpClient.HttpClient, IdNamespaceSummary>;
export type ListMatchingJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all jobs for a given workflow.
 */
export declare const listMatchingJobs: API.PaginatedOperationMethod<ListMatchingJobsInput, ListMatchingJobsOutput, ListMatchingJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListMatchingWorkflowsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the `MatchingWorkflows` that have been created for an Amazon Web Services account.
 */
export declare const listMatchingWorkflows: API.PaginatedOperationMethod<ListMatchingWorkflowsInput, ListMatchingWorkflowsOutput, ListMatchingWorkflowsError, Credentials | HttpClient.HttpClient, MatchingWorkflowSummary>;
export type ListProviderServicesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the `ProviderServices` that are available in this Amazon Web Services Region.
 */
export declare const listProviderServices: API.PaginatedOperationMethod<ListProviderServicesInput, ListProviderServicesOutput, ListProviderServicesError, Credentials | HttpClient.HttpClient, ProviderServiceSummary>;
export type ListSchemaMappingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the `SchemaMappings` that have been created for an Amazon Web Services account.
 */
export declare const listSchemaMappings: API.PaginatedOperationMethod<ListSchemaMappingsInput, ListSchemaMappingsOutput, ListSchemaMappingsError, Credentials | HttpClient.HttpClient, SchemaMappingSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Displays the tags associated with an Entity Resolution resource. In Entity Resolution, `SchemaMapping`, and `MatchingWorkflow` can be tagged.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the resource-based policy.
 */
export declare const putPolicy: API.OperationMethod<PutPolicyInput, PutPolicyOutput, PutPolicyError, Credentials | HttpClient.HttpClient>;
export type StartIdMappingJobError = AccessDeniedException | ConflictException | ExceedsLimitException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the `IdMappingJob` of a workflow. The workflow must have previously been created using the `CreateIdMappingWorkflow` endpoint.
 */
export declare const startIdMappingJob: API.OperationMethod<StartIdMappingJobInput, StartIdMappingJobOutput, StartIdMappingJobError, Credentials | HttpClient.HttpClient>;
export type StartMatchingJobError = AccessDeniedException | ConflictException | ExceedsLimitException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the `MatchingJob` of a workflow. The workflow must have previously been created using the `CreateMatchingWorkflow` endpoint.
 */
export declare const startMatchingJob: API.OperationMethod<StartMatchingJobInput, StartMatchingJobOutput, StartMatchingJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified Entity Resolution resource. Tags can help you organize and categorize your resources. You can also use them to scope user permissions by granting a user permission to access or change only resources with certain tag values. In Entity Resolution, `SchemaMapping` and `MatchingWorkflow` can be tagged. Tags don't have any semantic meaning to Amazon Web Services and are interpreted strictly as strings of characters. You can use the `TagResource` action with a resource that already has tags. If you specify a new tag key, this tag is appended to the list of tags associated with the resource. If you specify a tag key that is already associated with the resource, the new tag value that you specify replaces the previous value for that tag.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from the specified Entity Resolution resource. In Entity Resolution, `SchemaMapping`, and `MatchingWorkflow` can be tagged.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateIdMappingWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing `IdMappingWorkflow`. This method is identical to CreateIdMappingWorkflow, except it uses an HTTP `PUT` request instead of a `POST` request, and the `IdMappingWorkflow` must already exist for the method to succeed.
 *
 * Incremental processing is not supported for ID mapping workflows.
 */
export declare const updateIdMappingWorkflow: API.OperationMethod<UpdateIdMappingWorkflowInput, UpdateIdMappingWorkflowOutput, UpdateIdMappingWorkflowError, Credentials | HttpClient.HttpClient>;
export type UpdateIdNamespaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing ID namespace.
 */
export declare const updateIdNamespace: API.OperationMethod<UpdateIdNamespaceInput, UpdateIdNamespaceOutput, UpdateIdNamespaceError, Credentials | HttpClient.HttpClient>;
export type UpdateMatchingWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing matching workflow. The workflow must already exist for this operation to succeed.
 *
 * For workflows where `resolutionType` is `PROVIDER`, incremental processing is not supported.
 */
export declare const updateMatchingWorkflow: API.OperationMethod<UpdateMatchingWorkflowInput, UpdateMatchingWorkflowOutput, UpdateMatchingWorkflowError, Credentials | HttpClient.HttpClient>;
export type UpdateSchemaMappingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a schema mapping.
 *
 * A schema is immutable if it is being used by a workflow. Therefore, you can't update a schema mapping if it's associated with a workflow.
 */
export declare const updateSchemaMapping: API.OperationMethod<UpdateSchemaMappingInput, UpdateSchemaMappingOutput, UpdateSchemaMappingError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=entityresolution.d.ts.map