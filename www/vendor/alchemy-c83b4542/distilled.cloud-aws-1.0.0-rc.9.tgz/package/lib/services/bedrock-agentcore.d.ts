import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as stream from "effect/Stream";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DuplicateIdException_base: S.Class<DuplicateIdException, S.TaggedStruct<"DuplicateIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateIdException extends /*@__PURE__*/ DuplicateIdException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidInputException_base: S.Class<InvalidInputException, S.TaggedStruct<"InvalidInputException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const RetryableConflictException_base: S.Class<RetryableConflictException, S.TaggedStruct<"RetryableConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RetryableConflictException extends /*@__PURE__*/ RetryableConflictException_base {
}
declare const RuntimeClientError_base: S.Class<RuntimeClientError, S.TaggedStruct<"RuntimeClientError", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RuntimeClientError extends /*@__PURE__*/ RuntimeClientError_base {
}
declare const ServiceException_base: S.Class<ServiceException, S.TaggedStruct<"ServiceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const SubscriptionRequiredException_base: S.Class<SubscriptionRequiredException, S.TaggedStruct<"SubscriptionRequiredException", {
    readonly message: any;
    readonly subscriptionUrl: any;
    readonly productName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class SubscriptionRequiredException extends /*@__PURE__*/ SubscriptionRequiredException_base {
}
declare const ThrottledException_base: S.Class<ThrottledException, S.TaggedStruct<"ThrottledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottledException extends /*@__PURE__*/ ThrottledException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type MemoryId = string;
export type RequestIdentifier = string;
export type Namespace = string;
export type NamespacesList = string[];
export declare const NamespacesList: any;
export type SensitiveString = string | redacted.Redacted<string>;
export type MemoryContent = {
    text: string | redacted.Redacted<string>;
};
export declare const MemoryContent: any;
export type MemoryStrategyId = string;
export type MetadataKey = string;
export type StringValue = string;
export type StringListMemberValue = string;
export type StringValueList = string[];
export declare const StringValueList: any;
export type MemoryRecordMetadataValue = {
    stringValue: string;
    stringListValue?: never;
    numberValue?: never;
    dateTimeValue?: never;
} | {
    stringValue?: never;
    stringListValue: string[];
    numberValue?: never;
    dateTimeValue?: never;
} | {
    stringValue?: never;
    stringListValue?: never;
    numberValue: number;
    dateTimeValue?: never;
} | {
    stringValue?: never;
    stringListValue?: never;
    numberValue?: never;
    dateTimeValue: Date;
};
export declare const MemoryRecordMetadataValue: any;
export type MemoryRecordMetadataMap = {
    [key: string]: MemoryRecordMetadataValue | undefined;
};
export declare const MemoryRecordMetadataMap: any;
export interface MemoryRecordCreateInput {
    requestIdentifier: string;
    namespaces: string[];
    content: MemoryContent;
    timestamp: Date;
    memoryStrategyId?: string;
    metadata?: {
        [key: string]: MemoryRecordMetadataValue | undefined;
    };
}
export declare const MemoryRecordCreateInput: S.Schema<MemoryRecordCreateInput>;
export type MemoryRecordsCreateInputList = MemoryRecordCreateInput[];
export declare const MemoryRecordsCreateInputList: any;
export interface BatchCreateMemoryRecordsInput {
    memoryId: string;
    records: MemoryRecordCreateInput[];
    clientToken?: string;
}
export declare const BatchCreateMemoryRecordsInput: S.Schema<BatchCreateMemoryRecordsInput>;
export type MemoryRecordId = string;
export type MemoryRecordStatus = "SUCCEEDED" | "FAILED" | (string & {});
export declare const MemoryRecordStatus: any;
export interface MemoryRecordOutput {
    memoryRecordId: string;
    status: MemoryRecordStatus;
    requestIdentifier?: string;
    errorCode?: number;
    errorMessage?: string;
}
export declare const MemoryRecordOutput: S.Schema<MemoryRecordOutput>;
export type MemoryRecordsOutputList = MemoryRecordOutput[];
export declare const MemoryRecordsOutputList: any;
export interface BatchCreateMemoryRecordsOutput {
    successfulRecords: MemoryRecordOutput[];
    failedRecords: MemoryRecordOutput[];
}
export declare const BatchCreateMemoryRecordsOutput: S.Schema<BatchCreateMemoryRecordsOutput>;
export interface MemoryRecordDeleteInput {
    memoryRecordId: string;
    namespace?: string;
}
export declare const MemoryRecordDeleteInput: S.Schema<MemoryRecordDeleteInput>;
export type MemoryRecordsDeleteInputList = MemoryRecordDeleteInput[];
export declare const MemoryRecordsDeleteInputList: any;
export interface BatchDeleteMemoryRecordsInput {
    memoryId: string;
    records: MemoryRecordDeleteInput[];
}
export declare const BatchDeleteMemoryRecordsInput: S.Schema<BatchDeleteMemoryRecordsInput>;
export interface BatchDeleteMemoryRecordsOutput {
    successfulRecords: MemoryRecordOutput[];
    failedRecords: MemoryRecordOutput[];
}
export declare const BatchDeleteMemoryRecordsOutput: S.Schema<BatchDeleteMemoryRecordsOutput>;
export interface MemoryRecordUpdateInput {
    memoryRecordId: string;
    timestamp: Date;
    content?: MemoryContent;
    namespaces?: string[];
    sourceNamespaces?: string[];
    memoryStrategyId?: string;
    metadata?: {
        [key: string]: MemoryRecordMetadataValue | undefined;
    };
}
export declare const MemoryRecordUpdateInput: S.Schema<MemoryRecordUpdateInput>;
export type MemoryRecordsUpdateInputList = MemoryRecordUpdateInput[];
export declare const MemoryRecordsUpdateInputList: any;
export interface BatchUpdateMemoryRecordsInput {
    memoryId: string;
    records: MemoryRecordUpdateInput[];
}
export declare const BatchUpdateMemoryRecordsInput: S.Schema<BatchUpdateMemoryRecordsInput>;
export interface BatchUpdateMemoryRecordsOutput {
    successfulRecords: MemoryRecordOutput[];
    failedRecords: MemoryRecordOutput[];
}
export declare const BatchUpdateMemoryRecordsOutput: S.Schema<BatchUpdateMemoryRecordsOutput>;
export type UserTokenType = string | redacted.Redacted<string>;
export type UserIdType = string;
export type UserIdentifier = {
    userToken: string | redacted.Redacted<string>;
    userId?: never;
} | {
    userToken?: never;
    userId: string;
};
export declare const UserIdentifier: any;
export type RequestUri = string;
export interface CompleteResourceTokenAuthRequest {
    userIdentifier: UserIdentifier;
    sessionUri: string;
}
export declare const CompleteResourceTokenAuthRequest: S.Schema<CompleteResourceTokenAuthRequest>;
export interface CompleteResourceTokenAuthResponse {
}
export declare const CompleteResourceTokenAuthResponse: S.Schema<CompleteResourceTokenAuthResponse>;
export type ABTestName = string;
export type ABTestDescription = string;
export type GatewayArn = string;
export type VariantName = string;
export type ConfigurationBundleArn = string;
export type ConfigurationBundleVersion = string;
export interface ConfigurationBundleRef {
    bundleArn: string;
    bundleVersion: string;
}
export declare const ConfigurationBundleRef: S.Schema<ConfigurationBundleRef>;
export type TargetName = string;
export interface TargetRef {
    name: string;
}
export declare const TargetRef: S.Schema<TargetRef>;
export interface VariantConfiguration {
    configurationBundle?: ConfigurationBundleRef;
    target?: TargetRef;
}
export declare const VariantConfiguration: S.Schema<VariantConfiguration>;
export interface Variant {
    name: string;
    weight: number;
    variantConfiguration: VariantConfiguration;
}
export declare const Variant: S.Schema<Variant>;
export type VariantList = Variant[];
export declare const VariantList: any;
export type PathPattern = string;
export type TargetPathList = string[];
export declare const TargetPathList: any;
export interface GatewayFilter {
    targetPaths?: string[];
}
export declare const GatewayFilter: S.Schema<GatewayFilter>;
export type OnlineEvaluationConfigArn = string;
export interface PerVariantOnlineEvaluationConfig {
    name: string;
    onlineEvaluationConfigArn: string;
}
export declare const PerVariantOnlineEvaluationConfig: S.Schema<PerVariantOnlineEvaluationConfig>;
export type PerVariantOnlineEvaluationConfigList = PerVariantOnlineEvaluationConfig[];
export declare const PerVariantOnlineEvaluationConfigList: any;
export type ABTestEvaluationConfig = {
    onlineEvaluationConfigArn: string;
    perVariantOnlineEvaluationConfig?: never;
} | {
    onlineEvaluationConfigArn?: never;
    perVariantOnlineEvaluationConfig: PerVariantOnlineEvaluationConfig[];
};
export declare const ABTestEvaluationConfig: any;
export type RoleArn = string;
export type ClientToken = string;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export interface CreateABTestRequest {
    name: string;
    description?: string;
    gatewayArn: string;
    variants: Variant[];
    gatewayFilter?: GatewayFilter;
    evaluationConfig: ABTestEvaluationConfig;
    roleArn: string;
    enableOnCreate?: boolean;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateABTestRequest: S.Schema<CreateABTestRequest>;
export type ABTestId = string;
export type ABTestArn = string;
export type ABTestStatus = "CREATING" | "ACTIVE" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "DELETING" | "DELETE_FAILED" | "FAILED" | (string & {});
export declare const ABTestStatus: any;
export type ABTestExecutionStatus = "PAUSED" | "RUNNING" | "STOPPED" | "NOT_STARTED" | (string & {});
export declare const ABTestExecutionStatus: any;
export interface CreateABTestResponse {
    abTestId: string;
    abTestArn: string;
    name?: string;
    status: ABTestStatus;
    executionStatus: ABTestExecutionStatus;
    createdAt: Date;
}
export declare const CreateABTestResponse: S.Schema<CreateABTestResponse>;
export type ActorId = string;
export type SessionId = string;
export type Content = {
    text: string | redacted.Redacted<string>;
};
export declare const Content: any;
export type Role = "ASSISTANT" | "USER" | "TOOL" | "OTHER" | (string & {});
export declare const Role: any;
export interface Conversational {
    content: Content;
    role: Role;
}
export declare const Conversational: S.Schema<Conversational>;
export type MemoryDocument = unknown;
export type MemoryJsonDataContent = unknown;
export interface MemoryJsonData {
    content: any;
}
export declare const MemoryJsonData: S.Schema<MemoryJsonData>;
export type PayloadType = {
    conversational: Conversational;
    blob?: never;
    json?: never;
} | {
    conversational?: never;
    blob: any;
    json?: never;
} | {
    conversational?: never;
    blob?: never;
    json: MemoryJsonData;
};
export declare const PayloadType: any;
export type PayloadTypeList = PayloadType[];
export declare const PayloadTypeList: any;
export type EventId = string;
export type BranchName = string;
export interface Branch {
    rootEventId?: string;
    name: string;
}
export declare const Branch: S.Schema<Branch>;
export type MetadataValue = {
    stringValue: string;
};
export declare const MetadataValue: any;
export type MetadataMap = {
    [key: string]: MetadataValue | undefined;
};
export declare const MetadataMap: any;
export type ExtractionMode = "SKIP" | (string & {});
export declare const ExtractionMode: any;
export type NamespaceVariableName = string;
export type NamespaceVariableValue = string;
export type NamespaceVariablesMap = {
    [key: string]: string | undefined;
};
export declare const NamespaceVariablesMap: any;
export interface ExtractionConfig {
    namespaceVariables?: {
        [key: string]: string | undefined;
    };
}
export declare const ExtractionConfig: S.Schema<ExtractionConfig>;
export interface CreateEventInput {
    memoryId: string;
    actorId: string;
    sessionId?: string;
    eventTimestamp: Date;
    payload: PayloadType[];
    branch?: Branch;
    clientToken?: string;
    metadata?: {
        [key: string]: MetadataValue | undefined;
    };
    extractionMode?: ExtractionMode;
    extractionConfig?: ExtractionConfig;
}
export declare const CreateEventInput: S.Schema<CreateEventInput>;
export interface Event {
    memoryId: string;
    actorId: string;
    sessionId: string;
    eventId: string;
    eventTimestamp: Date;
    payload?: PayloadType[];
    branch?: Branch;
    metadata?: {
        [key: string]: MetadataValue | undefined;
    };
}
export declare const Event: S.Schema<Event>;
export interface CreateEventOutput {
    event: Event;
}
export declare const CreateEventOutput: S.Schema<CreateEventOutput>;
export type UserId = string;
export type PaymentAgentName = string;
export type PaymentManagerArn = string;
export type PaymentConnectorId = string;
export type PaymentInstrumentType = "EMBEDDED_CRYPTO_WALLET" | (string & {});
export declare const PaymentInstrumentType: any;
export type CryptoWalletNetwork = "ETHEREUM" | "SOLANA" | (string & {});
export declare const CryptoWalletNetwork: any;
export type Email = string | redacted.Redacted<string>;
export interface LinkedAccountEmail {
    emailAddress: string | redacted.Redacted<string>;
}
export declare const LinkedAccountEmail: S.Schema<LinkedAccountEmail>;
export type PhoneNumber = string | redacted.Redacted<string>;
export interface LinkedAccountSms {
    phoneNumber: string | redacted.Redacted<string>;
}
export declare const LinkedAccountSms: S.Schema<LinkedAccountSms>;
export type JwtKeyId = string;
export interface LinkedAccountDeveloperJwt {
    kid: string;
    sub: string;
}
export declare const LinkedAccountDeveloperJwt: S.Schema<LinkedAccountDeveloperJwt>;
export interface OAuth2Authentication {
    sub: string;
    emailAddress?: string | redacted.Redacted<string>;
    name?: string;
    username?: string;
}
export declare const OAuth2Authentication: S.Schema<OAuth2Authentication>;
export type LinkedAccountOAuth2 = {
    google: OAuth2Authentication;
    apple?: never;
    x?: never;
    telegram?: never;
    github?: never;
} | {
    google?: never;
    apple: OAuth2Authentication;
    x?: never;
    telegram?: never;
    github?: never;
} | {
    google?: never;
    apple?: never;
    x: OAuth2Authentication;
    telegram?: never;
    github?: never;
} | {
    google?: never;
    apple?: never;
    x?: never;
    telegram: OAuth2Authentication;
    github?: never;
} | {
    google?: never;
    apple?: never;
    x?: never;
    telegram?: never;
    github: OAuth2Authentication;
};
export declare const LinkedAccountOAuth2: any;
export type LinkedAccount = {
    email: LinkedAccountEmail;
    sms?: never;
    developerJwt?: never;
    oAuth2?: never;
} | {
    email?: never;
    sms: LinkedAccountSms;
    developerJwt?: never;
    oAuth2?: never;
} | {
    email?: never;
    sms?: never;
    developerJwt: LinkedAccountDeveloperJwt;
    oAuth2?: never;
} | {
    email?: never;
    sms?: never;
    developerJwt?: never;
    oAuth2: LinkedAccountOAuth2;
};
export declare const LinkedAccount: any;
export type LinkedAccountList = LinkedAccount[];
export declare const LinkedAccountList: any;
export interface EmbeddedCryptoWallet {
    network: CryptoWalletNetwork;
    linkedAccounts: LinkedAccount[];
    walletAddress?: string;
    redirectUrl?: string;
}
export declare const EmbeddedCryptoWallet: S.Schema<EmbeddedCryptoWallet>;
export type PaymentInstrumentDetails = {
    embeddedCryptoWallet: EmbeddedCryptoWallet;
};
export declare const PaymentInstrumentDetails: any;
export interface CreatePaymentInstrumentRequest {
    userId?: string;
    agentName?: string;
    paymentManagerArn: string;
    paymentConnectorId: string;
    paymentInstrumentType: PaymentInstrumentType;
    paymentInstrumentDetails: PaymentInstrumentDetails;
    clientToken?: string;
}
export declare const CreatePaymentInstrumentRequest: S.Schema<CreatePaymentInstrumentRequest>;
export type PaymentInstrumentId = string;
export type PaymentInstrumentStatus = "INITIATED" | "ACTIVE" | "FAILED" | "DELETED" | "BLOCKED" | (string & {});
export declare const PaymentInstrumentStatus: any;
export interface PaymentInstrument {
    paymentInstrumentId: string;
    paymentManagerArn: string;
    paymentConnectorId: string;
    userId: string;
    paymentInstrumentType: PaymentInstrumentType;
    paymentInstrumentDetails: PaymentInstrumentDetails;
    createdAt: Date;
    status: PaymentInstrumentStatus;
    updatedAt: Date;
}
export declare const PaymentInstrument: S.Schema<PaymentInstrument>;
export interface CreatePaymentInstrumentResponse {
    paymentInstrument: PaymentInstrument;
}
export declare const CreatePaymentInstrumentResponse: S.Schema<CreatePaymentInstrumentResponse>;
export type Currency = "USD" | (string & {});
export declare const Currency: any;
export interface Amount {
    value: string;
    currency: Currency;
}
export declare const Amount: S.Schema<Amount>;
export interface SessionLimits {
    maxSpendAmount: Amount;
}
export declare const SessionLimits: S.Schema<SessionLimits>;
export interface CreatePaymentSessionRequest {
    userId?: string;
    agentName?: string;
    paymentManagerArn: string;
    limits?: SessionLimits;
    expiryTimeInMinutes: number;
    clientToken?: string;
}
export declare const CreatePaymentSessionRequest: S.Schema<CreatePaymentSessionRequest>;
export type PaymentSessionId = string;
export interface AvailableLimits {
    availableSpendAmount?: Amount;
    updatedAt?: Date;
}
export declare const AvailableLimits: S.Schema<AvailableLimits>;
export interface PaymentSession {
    paymentSessionId: string;
    paymentManagerArn: string;
    limits?: SessionLimits;
    userId: string;
    expiryTimeInMinutes: number;
    createdAt: Date;
    availableLimits?: AvailableLimits;
    updatedAt: Date;
}
export declare const PaymentSession: S.Schema<PaymentSession>;
export interface CreatePaymentSessionResponse {
    paymentSession: PaymentSession;
}
export declare const CreatePaymentSessionResponse: S.Schema<CreatePaymentSessionResponse>;
export interface DeleteABTestRequest {
    abTestId: string;
}
export declare const DeleteABTestRequest: S.Schema<DeleteABTestRequest>;
export interface DeleteABTestResponse {
    abTestId: string;
    abTestArn: string;
    status: ABTestStatus;
}
export declare const DeleteABTestResponse: S.Schema<DeleteABTestResponse>;
export type BatchEvaluationId = string;
export interface DeleteBatchEvaluationRequest {
    batchEvaluationId: string;
}
export declare const DeleteBatchEvaluationRequest: S.Schema<DeleteBatchEvaluationRequest>;
export type BatchEvaluationArn = string;
export type BatchEvaluationStatus = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "FAILED" | "STOPPING" | "STOPPED" | "DELETING" | (string & {});
export declare const BatchEvaluationStatus: any;
export interface DeleteBatchEvaluationResponse {
    batchEvaluationId: string;
    batchEvaluationArn: string;
    status: BatchEvaluationStatus;
}
export declare const DeleteBatchEvaluationResponse: S.Schema<DeleteBatchEvaluationResponse>;
export type CapacityProviderId = string;
export interface DeleteCapacityProviderSessionRequest {
    capacityProviderId: string;
    sessionId: string;
}
export declare const DeleteCapacityProviderSessionRequest: S.Schema<DeleteCapacityProviderSessionRequest>;
export type CapacityProviderArn = string;
export type CapacityProviderSessionStatus = "Provisioning" | "Deprovisioning" | "Active" | "Deleting" | "Deleted" | "Stopped" | (string & {});
export declare const CapacityProviderSessionStatus: any;
export interface DeleteCapacityProviderSessionResponse {
    capacityProviderArn: string;
    sessionId: string;
    status: CapacityProviderSessionStatus;
}
export declare const DeleteCapacityProviderSessionResponse: S.Schema<DeleteCapacityProviderSessionResponse>;
export interface DeleteEventInput {
    memoryId: string;
    sessionId: string;
    eventId: string;
    actorId: string;
}
export declare const DeleteEventInput: S.Schema<DeleteEventInput>;
export interface DeleteEventOutput {
    eventId: string;
}
export declare const DeleteEventOutput: S.Schema<DeleteEventOutput>;
export interface DeleteMemoryRecordInput {
    memoryId: string;
    memoryRecordId: string;
    namespace?: string;
}
export declare const DeleteMemoryRecordInput: S.Schema<DeleteMemoryRecordInput>;
export interface DeleteMemoryRecordOutput {
    memoryRecordId: string;
}
export declare const DeleteMemoryRecordOutput: S.Schema<DeleteMemoryRecordOutput>;
export interface DeletePaymentInstrumentRequest {
    userId?: string;
    paymentManagerArn: string;
    paymentConnectorId: string;
    paymentInstrumentId: string;
}
export declare const DeletePaymentInstrumentRequest: S.Schema<DeletePaymentInstrumentRequest>;
export interface DeletePaymentInstrumentResponse {
    status: PaymentInstrumentStatus;
}
export declare const DeletePaymentInstrumentResponse: S.Schema<DeletePaymentInstrumentResponse>;
export interface DeletePaymentSessionRequest {
    userId?: string;
    paymentManagerArn: string;
    paymentSessionId: string;
}
export declare const DeletePaymentSessionRequest: S.Schema<DeletePaymentSessionRequest>;
export type PaymentSessionStatus = "ACTIVE" | "EXPIRED" | "DELETED" | (string & {});
export declare const PaymentSessionStatus: any;
export interface DeletePaymentSessionResponse {
    status: PaymentSessionStatus;
}
export declare const DeletePaymentSessionResponse: S.Schema<DeletePaymentSessionResponse>;
export type RecommendationId = string;
export interface DeleteRecommendationRequest {
    recommendationId: string;
}
export declare const DeleteRecommendationRequest: S.Schema<DeleteRecommendationRequest>;
export type RecommendationStatus = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | "DELETING" | (string & {});
export declare const RecommendationStatus: any;
export interface DeleteRecommendationResponse {
    recommendationId: string;
    status: RecommendationStatus;
}
export declare const DeleteRecommendationResponse: S.Schema<DeleteRecommendationResponse>;
export type EvaluatorId = string;
export type Span = unknown;
export type Spans = any[];
export declare const Spans: any;
export type EvaluationInput = {
    sessionSpans: any[];
};
export declare const EvaluationInput: any;
export type SpanId = string;
export type SpanIds = string[];
export declare const SpanIds: any;
export type TraceId = string;
export type TraceIds = string[];
export declare const TraceIds: any;
export type EvaluationTarget = {
    spanIds: string[];
    traceIds?: never;
} | {
    spanIds?: never;
    traceIds: string[];
};
export declare const EvaluationTarget: any;
export interface SpanContext {
    sessionId: string;
    traceId?: string;
    spanId?: string;
}
export declare const SpanContext: S.Schema<SpanContext>;
export type Context = {
    spanContext: SpanContext;
};
export declare const Context: any;
export type EvaluationContent = {
    text: string;
};
export declare const EvaluationContent: any;
export type EvaluationContentList = EvaluationContent[];
export declare const EvaluationContentList: any;
export type EvaluationToolName = string;
export type EvaluationToolNames = string[];
export declare const EvaluationToolNames: any;
export interface EvaluationExpectedTrajectory {
    toolNames?: string[];
}
export declare const EvaluationExpectedTrajectory: S.Schema<EvaluationExpectedTrajectory>;
export interface EvaluationReferenceInput {
    context: Context;
    expectedResponse?: EvaluationContent;
    assertions?: EvaluationContent[];
    expectedTrajectory?: EvaluationExpectedTrajectory;
}
export declare const EvaluationReferenceInput: S.Schema<EvaluationReferenceInput>;
export type EvaluationReferenceInputs = EvaluationReferenceInput[];
export declare const EvaluationReferenceInputs: any;
export interface EvaluateRequest {
    evaluatorId: string;
    evaluationInput: EvaluationInput;
    evaluationTarget?: EvaluationTarget;
    evaluationReferenceInputs?: EvaluationReferenceInput[];
}
export declare const EvaluateRequest: S.Schema<EvaluateRequest>;
export type EvaluatorArn = string;
export type EvaluatorName = string;
export type EvaluationExplanation = string | redacted.Redacted<string>;
export interface TokenUsage {
    inputTokens?: number;
    outputTokens?: number;
    totalTokens?: number;
}
export declare const TokenUsage: S.Schema<TokenUsage>;
export type EvaluationErrorMessage = string;
export type EvaluationErrorCode = string;
export type IgnoredReferenceInputField = string;
export type IgnoredReferenceInputFields = string[];
export declare const IgnoredReferenceInputFields: any;
export interface EvaluationResultContent {
    evaluatorArn: string;
    evaluatorId: string;
    evaluatorName: string;
    explanation?: string | redacted.Redacted<string>;
    context: Context;
    value?: number;
    label?: string;
    tokenUsage?: TokenUsage;
    errorMessage?: string;
    errorCode?: string;
    ignoredReferenceInputFields?: string[];
}
export declare const EvaluationResultContent: S.Schema<EvaluationResultContent>;
export type EvaluationResults = EvaluationResultContent[];
export declare const EvaluationResults: any;
export interface EvaluateResponse {
    evaluationResults: EvaluationResultContent[];
}
export declare const EvaluateResponse: S.Schema<EvaluateResponse>;
export interface GetABTestRequest {
    abTestId: string;
}
export declare const GetABTestRequest: S.Schema<GetABTestRequest>;
export type ErrorDetailsList = string[];
export declare const ErrorDetailsList: any;
export interface ControlStats {
    variantName: string;
    sampleSize: number;
    mean: number;
}
export declare const ControlStats: S.Schema<ControlStats>;
export interface ConfidenceInterval {
    lower?: number;
    upper?: number;
}
export declare const ConfidenceInterval: S.Schema<ConfidenceInterval>;
export interface VariantResult {
    variantName: string;
    sampleSize: number;
    mean: number;
    absoluteChange?: number;
    percentChange?: number;
    pValue?: number;
    confidenceInterval?: ConfidenceInterval;
    isSignificant: boolean;
}
export declare const VariantResult: S.Schema<VariantResult>;
export type VariantResultList = VariantResult[];
export declare const VariantResultList: any;
export interface EvaluatorMetric {
    evaluatorArn: string;
    controlStats: ControlStats;
    variantResults: VariantResult[];
}
export declare const EvaluatorMetric: S.Schema<EvaluatorMetric>;
export type EvaluatorMetricList = EvaluatorMetric[];
export declare const EvaluatorMetricList: any;
export interface ABTestResults {
    analysisTimestamp?: Date;
    evaluatorMetrics: EvaluatorMetric[];
}
export declare const ABTestResults: S.Schema<ABTestResults>;
export interface GetABTestResponse {
    abTestId: string;
    abTestArn: string;
    name: string;
    description?: string;
    status: ABTestStatus;
    executionStatus: ABTestExecutionStatus;
    gatewayArn: string;
    variants: Variant[];
    gatewayFilter?: GatewayFilter;
    evaluationConfig: ABTestEvaluationConfig;
    roleArn?: string;
    currentRunId?: string;
    errorDetails?: string[];
    startedAt?: Date;
    stoppedAt?: Date;
    maxDurationExpiresAt?: Date;
    createdAt: Date;
    updatedAt: Date;
    results?: ABTestResults;
}
export declare const GetABTestResponse: S.Schema<GetABTestResponse>;
export type SessionType = string;
export interface GetAgentCardRequest {
    runtimeSessionId?: string;
    agentRuntimeArn: string;
    qualifier?: string;
}
export declare const GetAgentCardRequest: S.Schema<GetAgentCardRequest>;
export type AgentCard = unknown;
export type HttpResponseCode = number;
export interface GetAgentCardResponse {
    runtimeSessionId?: string;
    agentCard: any;
    statusCode?: number;
}
export declare const GetAgentCardResponse: S.Schema<GetAgentCardResponse>;
export interface GetBatchEvaluationRequest {
    batchEvaluationId: string;
}
export declare const GetBatchEvaluationRequest: S.Schema<GetBatchEvaluationRequest>;
export type BatchEvaluationName = string;
export interface Evaluator {
    evaluatorId: string;
}
export declare const Evaluator: S.Schema<Evaluator>;
export type EvaluatorList = Evaluator[];
export declare const EvaluatorList: any;
export type InsightId = string;
export interface Insight {
    insightId: string;
}
export declare const Insight: S.Schema<Insight>;
export type InsightList = Insight[];
export declare const InsightList: any;
export type EvaluationStringList = string[];
export declare const EvaluationStringList: any;
export interface SessionFilterConfig {
    startTime?: Date;
    endTime?: Date;
}
export declare const SessionFilterConfig: S.Schema<SessionFilterConfig>;
export interface CloudWatchFilterConfig {
    sessionIds?: string[];
    timeRange?: SessionFilterConfig;
}
export declare const CloudWatchFilterConfig: S.Schema<CloudWatchFilterConfig>;
export interface CloudWatchLogsSource {
    serviceNames: string[];
    logGroupNames: string[];
    filterConfig?: CloudWatchFilterConfig;
}
export declare const CloudWatchLogsSource: S.Schema<CloudWatchLogsSource>;
export interface OnlineEvaluationConfigSource {
    onlineEvaluationConfigArn: string;
    timeRange?: SessionFilterConfig;
}
export declare const OnlineEvaluationConfigSource: S.Schema<OnlineEvaluationConfigSource>;
export type DataSourceConfig = {
    cloudWatchLogs: CloudWatchLogsSource;
    onlineEvaluationConfigSource?: never;
} | {
    cloudWatchLogs?: never;
    onlineEvaluationConfigSource: OnlineEvaluationConfigSource;
};
export declare const DataSourceConfig: any;
export interface CloudWatchOutputConfig {
    logGroupName: string;
    logStreamName: string;
}
export declare const CloudWatchOutputConfig: S.Schema<CloudWatchOutputConfig>;
export type OutputConfig = {
    cloudWatchConfig: CloudWatchOutputConfig;
};
export declare const OutputConfig: any;
export interface EvaluatorStatistics {
    averageScore?: number;
}
export declare const EvaluatorStatistics: S.Schema<EvaluatorStatistics>;
export interface EvaluatorSummary {
    evaluatorId?: string;
    statistics?: EvaluatorStatistics;
    totalEvaluated?: number;
    totalFailed?: number;
}
export declare const EvaluatorSummary: S.Schema<EvaluatorSummary>;
export type EvaluatorSummaryList = EvaluatorSummary[];
export declare const EvaluatorSummaryList: any;
export interface EvaluationJobResults {
    numberOfSessionsCompleted?: number;
    numberOfSessionsInProgress?: number;
    numberOfSessionsFailed?: number;
    totalNumberOfSessions?: number;
    numberOfSessionsIgnored?: number;
    evaluatorSummaries?: EvaluatorSummary[];
}
export declare const EvaluationJobResults: S.Schema<EvaluationJobResults>;
export type InsightsFailureCategory = "execution-error-category-authentication" | "execution-error-category-resource-not-found" | "execution-error-category-service-errors" | "execution-error-category-rate-limiting" | "execution-error-category-formatting" | "execution-error-category-timeout" | "execution-error-category-resource-exhaustion" | "execution-error-category-environment" | "execution-error-category-tool-schema" | "task-instruction-category-non-compliance" | "task-instruction-category-problem-id" | "incorrect-actions-category-tool-selection" | "incorrect-actions-category-poor-information-retrieval" | "incorrect-actions-category-clarification" | "incorrect-actions-category-inappropriate-info-request" | "context-handling-error-category-context-handling-failures" | "hallucination-category-hall-capabilities" | "hallucination-category-hall-misunderstand" | "hallucination-category-hall-usage" | "hallucination-category-hall-history" | "hallucination-category-hall-params" | "hallucination-category-fabricate-tool-outputs" | "repetitive-behavior-category-repetition-tool" | "repetitive-behavior-category-repetition-info" | "repetitive-behavior-category-step-repetition" | "orchestration-related-errors-category-reasoning-mismatch" | "orchestration-related-errors-category-goal-deviation" | "orchestration-related-errors-category-premature-termination" | "orchestration-related-errors-category-unaware-termination" | "llm-output-category-nonsensical" | "configuration-mismatch-category-tool-definition" | "coding-use-case-specific-failure-types-category-edge-case-oversights" | "coding-use-case-specific-failure-types-category-dependency-issues" | "other" | (string & {});
export declare const InsightsFailureCategory: any;
export interface InsightsFailureSignal {
    category: InsightsFailureCategory;
    evidence: string;
    confidence: number;
}
export declare const InsightsFailureSignal: S.Schema<InsightsFailureSignal>;
export type InsightsFailureSignalList = InsightsFailureSignal[];
export declare const InsightsFailureSignalList: any;
export interface FailureSpanDetail {
    spanId: string;
    traceId: string;
    signals: InsightsFailureSignal[];
}
export declare const FailureSpanDetail: S.Schema<FailureSpanDetail>;
export type FailureSpanDetailList = FailureSpanDetail[];
export declare const FailureSpanDetailList: any;
export interface AffectedSession {
    sessionId: string;
    explanation: string;
    fixType: string;
    recommendation: string;
    failureSpans: FailureSpanDetail[];
}
export declare const AffectedSession: S.Schema<AffectedSession>;
export type AffectedSessionList = AffectedSession[];
export declare const AffectedSessionList: any;
export interface RootCauseCluster {
    clusterId: number;
    name: string;
    rootCause: string;
    recommendation: string;
    affectedSessionCount: number;
    affectedSessions: AffectedSession[];
}
export declare const RootCauseCluster: S.Schema<RootCauseCluster>;
export type RootCauseClusterList = RootCauseCluster[];
export declare const RootCauseClusterList: any;
export interface FailureSubCategoryCluster {
    clusterId: number;
    name: string;
    description: string;
    affectedSessionCount: number;
    rootCauses: RootCauseCluster[];
}
export declare const FailureSubCategoryCluster: S.Schema<FailureSubCategoryCluster>;
export type FailureSubCategoryClusterList = FailureSubCategoryCluster[];
export declare const FailureSubCategoryClusterList: any;
export interface FailureCategoryCluster {
    clusterId: number;
    name: string;
    description: string;
    affectedSessionCount: number;
    subCategories: FailureSubCategoryCluster[];
}
export declare const FailureCategoryCluster: S.Schema<FailureCategoryCluster>;
export type FailureCategoryClusterList = FailureCategoryCluster[];
export declare const FailureCategoryClusterList: any;
export interface FailureAnalysisResultContent {
    failures: FailureCategoryCluster[];
}
export declare const FailureAnalysisResultContent: S.Schema<FailureAnalysisResultContent>;
export type UserIntentList = string[];
export declare const UserIntentList: any;
export interface UserIntentAffectedSession {
    sessionId: string;
    userMessages: string[];
}
export declare const UserIntentAffectedSession: S.Schema<UserIntentAffectedSession>;
export type UserIntentAffectedSessionList = UserIntentAffectedSession[];
export declare const UserIntentAffectedSessionList: any;
export interface UserIntentCluster {
    clusterId: number;
    name: string;
    description: string;
    affectedSessionCount: number;
    affectedSessions: UserIntentAffectedSession[];
}
export declare const UserIntentCluster: S.Schema<UserIntentCluster>;
export type UserIntentClusterList = UserIntentCluster[];
export declare const UserIntentClusterList: any;
export interface UserIntentClusteringResultContent {
    userIntents: UserIntentCluster[];
}
export declare const UserIntentClusteringResultContent: S.Schema<UserIntentClusteringResultContent>;
export interface ExecutionSummaryAffectedSession {
    sessionId: string;
    approachTaken: string;
    finalOutcome: string;
}
export declare const ExecutionSummaryAffectedSession: S.Schema<ExecutionSummaryAffectedSession>;
export type ExecutionSummaryAffectedSessionList = ExecutionSummaryAffectedSession[];
export declare const ExecutionSummaryAffectedSessionList: any;
export interface ExecutionSummaryCluster {
    clusterId: number;
    name: string;
    description: string;
    affectedSessionCount: number;
    affectedSessions: ExecutionSummaryAffectedSession[];
}
export declare const ExecutionSummaryCluster: S.Schema<ExecutionSummaryCluster>;
export type ExecutionSummaryClusterList = ExecutionSummaryCluster[];
export declare const ExecutionSummaryClusterList: any;
export interface ExecutionSummaryClusteringResultContent {
    executionSummaries: ExecutionSummaryCluster[];
}
export declare const ExecutionSummaryClusteringResultContent: S.Schema<ExecutionSummaryClusteringResultContent>;
export type BatchEvaluationDescription = string;
export type KmsKeyArn = string;
export interface GetBatchEvaluationResponse {
    batchEvaluationId: string;
    batchEvaluationArn: string;
    batchEvaluationName: string;
    status: BatchEvaluationStatus;
    createdAt: Date;
    evaluators?: Evaluator[];
    insights?: Insight[];
    dataSourceConfig?: DataSourceConfig;
    outputConfig?: OutputConfig;
    evaluationResults?: EvaluationJobResults;
    failureAnalysisResult?: FailureAnalysisResultContent;
    userIntentResult?: UserIntentClusteringResultContent;
    executionSummaryResult?: ExecutionSummaryClusteringResultContent;
    errorDetails?: string[];
    description?: string;
    updatedAt?: Date;
    kmsKeyArn?: string;
}
export declare const GetBatchEvaluationResponse: S.Schema<GetBatchEvaluationResponse>;
export type BrowserSessionId = string;
export interface GetBrowserSessionRequest {
    browserIdentifier: string;
    sessionId: string;
}
export declare const GetBrowserSessionRequest: S.Schema<GetBrowserSessionRequest>;
export type Name = string;
export type ViewPortWidth = number;
export type ViewPortHeight = number;
export interface ViewPort {
    width: number;
    height: number;
}
export declare const ViewPort: S.Schema<ViewPort>;
export interface S3Location {
    bucket: string;
    prefix: string;
    versionId?: string;
}
export declare const S3Location: S.Schema<S3Location>;
export type ResourceLocation = {
    s3: S3Location;
};
export declare const ResourceLocation: any;
export interface BrowserExtension {
    location: ResourceLocation;
}
export declare const BrowserExtension: S.Schema<BrowserExtension>;
export type BrowserExtensions = BrowserExtension[];
export declare const BrowserExtensions: any;
export type BrowserEnterprisePolicyType = "MANAGED" | "RECOMMENDED" | (string & {});
export declare const BrowserEnterprisePolicyType: any;
export interface BrowserEnterprisePolicy {
    location: ResourceLocation;
    type?: BrowserEnterprisePolicyType;
}
export declare const BrowserEnterprisePolicy: S.Schema<BrowserEnterprisePolicy>;
export type BrowserEnterprisePolicies = BrowserEnterprisePolicy[];
export declare const BrowserEnterprisePolicies: any;
export type BrowserProfileId = string;
export interface BrowserProfileConfiguration {
    profileIdentifier: string;
}
export declare const BrowserProfileConfiguration: S.Schema<BrowserProfileConfiguration>;
export type BrowserSessionTimeout = number;
export type BrowserSessionStatus = "READY" | "TERMINATED" | (string & {});
export declare const BrowserSessionStatus: any;
export type BrowserStreamEndpoint = string;
export type AutomationStreamStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const AutomationStreamStatus: any;
export interface AutomationStream {
    streamEndpoint: string;
    streamStatus: AutomationStreamStatus;
}
export declare const AutomationStream: S.Schema<AutomationStream>;
export interface LiveViewStream {
    streamEndpoint?: string;
}
export declare const LiveViewStream: S.Schema<LiveViewStream>;
export interface BrowserSessionStream {
    automationStream: AutomationStream;
    liveViewStream?: LiveViewStream;
}
export declare const BrowserSessionStream: S.Schema<BrowserSessionStream>;
export type HostName = string;
export type DomainPattern = string;
export type DomainPatterns = string[];
export declare const DomainPatterns: any;
export type SecretArn = string;
export interface BasicAuth {
    secretArn: string;
}
export declare const BasicAuth: S.Schema<BasicAuth>;
export type ProxyCredentials = {
    basicAuth: BasicAuth;
};
export declare const ProxyCredentials: any;
export interface ExternalProxy {
    server: string;
    port: number;
    domainPatterns?: string[];
    credentials?: ProxyCredentials;
}
export declare const ExternalProxy: S.Schema<ExternalProxy>;
export type Proxy = {
    externalProxy: ExternalProxy;
};
export declare const Proxy: any;
export type Proxies = Proxy[];
export declare const Proxies: any;
export interface ProxyBypass {
    domainPatterns?: string[];
}
export declare const ProxyBypass: S.Schema<ProxyBypass>;
export interface ProxyConfiguration {
    proxies: Proxy[];
    bypass?: ProxyBypass;
}
export declare const ProxyConfiguration: S.Schema<ProxyConfiguration>;
export interface SecretsManagerLocation {
    secretArn: string;
}
export declare const SecretsManagerLocation: S.Schema<SecretsManagerLocation>;
export type CertificateLocation = {
    secretsManager: SecretsManagerLocation;
};
export declare const CertificateLocation: any;
export interface Certificate {
    location: CertificateLocation;
}
export declare const Certificate: S.Schema<Certificate>;
export type Certificates = Certificate[];
export declare const Certificates: any;
export type S3FilesAccessPointArn = string;
export type MountPath = string;
export type S3FilesFileSystemArn = string;
export interface S3FilesConfiguration {
    accessPointArn: string;
    mountPath: string;
    fileSystemArn: string;
}
export declare const S3FilesConfiguration: S.Schema<S3FilesConfiguration>;
export type EfsAccessPointArn = string;
export type EfsFileSystemArn = string;
export interface EfsConfiguration {
    accessPointArn: string;
    mountPath: string;
    fileSystemArn: string;
}
export declare const EfsConfiguration: S.Schema<EfsConfiguration>;
export type ToolsFileSystemConfiguration = {
    s3FilesConfiguration: S3FilesConfiguration;
    efsConfiguration?: never;
} | {
    s3FilesConfiguration?: never;
    efsConfiguration: EfsConfiguration;
};
export declare const ToolsFileSystemConfiguration: any;
export type ToolsFileSystemConfigurations = ToolsFileSystemConfiguration[];
export declare const ToolsFileSystemConfigurations: any;
export interface GetBrowserSessionResponse {
    browserIdentifier: string;
    sessionId: string;
    name?: string;
    createdAt: Date;
    viewPort?: ViewPort;
    extensions?: BrowserExtension[];
    enterprisePolicies?: BrowserEnterprisePolicy[];
    profileConfiguration?: BrowserProfileConfiguration;
    sessionTimeoutSeconds?: number;
    status?: BrowserSessionStatus;
    streams?: BrowserSessionStream;
    proxyConfiguration?: ProxyConfiguration;
    certificates?: Certificate[];
    filesystemConfigurations?: ToolsFileSystemConfiguration[];
    sessionReplayArtifact?: string;
    lastUpdatedAt?: Date;
}
export declare const GetBrowserSessionResponse: S.Schema<GetBrowserSessionResponse>;
export type CodeInterpreterSessionId = string;
export interface GetCodeInterpreterSessionRequest {
    codeInterpreterIdentifier: string;
    sessionId: string;
}
export declare const GetCodeInterpreterSessionRequest: S.Schema<GetCodeInterpreterSessionRequest>;
export type CodeInterpreterSessionTimeout = number;
export type CodeInterpreterSessionStatus = "READY" | "TERMINATED" | (string & {});
export declare const CodeInterpreterSessionStatus: any;
export interface GetCodeInterpreterSessionResponse {
    codeInterpreterIdentifier: string;
    sessionId: string;
    name?: string;
    createdAt: Date;
    sessionTimeoutSeconds?: number;
    status?: CodeInterpreterSessionStatus;
    certificates?: Certificate[];
    filesystemConfigurations?: ToolsFileSystemConfiguration[];
}
export declare const GetCodeInterpreterSessionResponse: S.Schema<GetCodeInterpreterSessionResponse>;
export interface GetEventInput {
    memoryId: string;
    sessionId: string;
    actorId: string;
    eventId: string;
}
export declare const GetEventInput: S.Schema<GetEventInput>;
export interface GetEventOutput {
    event: Event;
}
export declare const GetEventOutput: S.Schema<GetEventOutput>;
export interface GetMemoryRecordInput {
    memoryId: string;
    memoryRecordId: string;
    namespace?: string;
}
export declare const GetMemoryRecordInput: S.Schema<GetMemoryRecordInput>;
export interface MemoryRecord {
    memoryRecordId: string;
    content: MemoryContent;
    memoryStrategyId?: string;
    namespaces: string[];
    createdAt: Date;
    metadata?: {
        [key: string]: MemoryRecordMetadataValue | undefined;
    };
}
export declare const MemoryRecord: S.Schema<MemoryRecord>;
export interface GetMemoryRecordOutput {
    memoryRecord: MemoryRecord;
}
export declare const GetMemoryRecordOutput: S.Schema<GetMemoryRecordOutput>;
export interface GetPaymentInstrumentRequest {
    userId?: string;
    agentName?: string;
    paymentManagerArn: string;
    paymentConnectorId?: string;
    paymentInstrumentId: string;
}
export declare const GetPaymentInstrumentRequest: S.Schema<GetPaymentInstrumentRequest>;
export interface GetPaymentInstrumentResponse {
    paymentInstrument: PaymentInstrument;
}
export declare const GetPaymentInstrumentResponse: S.Schema<GetPaymentInstrumentResponse>;
export type BlockchainChainId = "BASE" | "BASE_SEPOLIA" | "ETHEREUM" | "SOLANA" | "SOLANA_DEVNET" | (string & {});
export declare const BlockchainChainId: any;
export type InstrumentBalanceToken = "USDC" | (string & {});
export declare const InstrumentBalanceToken: any;
export interface GetPaymentInstrumentBalanceRequest {
    userId?: string;
    agentName?: string;
    paymentManagerArn: string;
    paymentConnectorId: string;
    paymentInstrumentId: string;
    chain: BlockchainChainId;
    token: InstrumentBalanceToken;
}
export declare const GetPaymentInstrumentBalanceRequest: S.Schema<GetPaymentInstrumentBalanceRequest>;
export interface TokenBalance {
    amount: string;
    decimals: number;
    token: InstrumentBalanceToken;
    network: CryptoWalletNetwork;
    chain: BlockchainChainId;
}
export declare const TokenBalance: S.Schema<TokenBalance>;
export interface GetPaymentInstrumentBalanceResponse {
    paymentInstrumentId: string;
    tokenBalance: TokenBalance;
}
export declare const GetPaymentInstrumentBalanceResponse: S.Schema<GetPaymentInstrumentBalanceResponse>;
export interface GetPaymentSessionRequest {
    userId?: string;
    agentName?: string;
    paymentManagerArn: string;
    paymentSessionId: string;
}
export declare const GetPaymentSessionRequest: S.Schema<GetPaymentSessionRequest>;
export interface GetPaymentSessionResponse {
    paymentSession: PaymentSession;
}
export declare const GetPaymentSessionResponse: S.Schema<GetPaymentSessionResponse>;
export interface GetRecommendationRequest {
    recommendationId: string;
}
export declare const GetRecommendationRequest: S.Schema<GetRecommendationRequest>;
export type RecommendationArn = string;
export type RecommendationName = string;
export type RecommendationDescription = string;
export type RecommendationType = "SYSTEM_PROMPT_RECOMMENDATION" | "TOOL_DESCRIPTION_RECOMMENDATION" | (string & {});
export declare const RecommendationType: any;
export type SystemPromptText = string | redacted.Redacted<string>;
export type ConfigurationBundleVersionId = string;
export interface SystemPromptConfigurationBundle {
    bundleArn: string;
    versionId: string;
    systemPromptJsonPath: string;
}
export declare const SystemPromptConfigurationBundle: S.Schema<SystemPromptConfigurationBundle>;
export type SystemPromptConfig = {
    text: string | redacted.Redacted<string>;
    configurationBundle?: never;
} | {
    text?: never;
    configurationBundle: SystemPromptConfigurationBundle;
};
export declare const SystemPromptConfig: any;
export type LogGroupArnList = string[];
export declare const LogGroupArnList: any;
export type ServiceName = string;
export type ServiceNameList = string[];
export declare const ServiceNameList: any;
export type CloudWatchLogsFilterOperator = "Equals" | "NotEquals" | "GreaterThan" | "LessThan" | "GreaterThanOrEqual" | "LessThanOrEqual" | "Contains" | "NotContains" | (string & {});
export declare const CloudWatchLogsFilterOperator: any;
export type FilterStringValue = string;
export type FilterValue = {
    stringValue: string;
    doubleValue?: never;
    booleanValue?: never;
} | {
    stringValue?: never;
    doubleValue: number;
    booleanValue?: never;
} | {
    stringValue?: never;
    doubleValue?: never;
    booleanValue: boolean;
};
export declare const FilterValue: any;
export interface CloudWatchLogsFilter {
    key: string;
    operator: CloudWatchLogsFilterOperator;
    value: FilterValue;
}
export declare const CloudWatchLogsFilter: S.Schema<CloudWatchLogsFilter>;
export type CloudWatchLogsFilterList = CloudWatchLogsFilter[];
export declare const CloudWatchLogsFilterList: any;
export interface CloudWatchLogsRule {
    filters?: CloudWatchLogsFilter[];
}
export declare const CloudWatchLogsRule: S.Schema<CloudWatchLogsRule>;
export interface CloudWatchLogsTraceConfig {
    logGroupArns: string[];
    serviceNames: string[];
    startTime: Date;
    endTime: Date;
    rule?: CloudWatchLogsRule;
}
export declare const CloudWatchLogsTraceConfig: S.Schema<CloudWatchLogsTraceConfig>;
export interface BatchEvaluationTraceConfig {
    batchEvaluationArn: string;
}
export declare const BatchEvaluationTraceConfig: S.Schema<BatchEvaluationTraceConfig>;
export interface OnlineEvaluationTraceConfig {
    onlineEvaluationConfigArn: string;
    startTime: Date;
    endTime: Date;
}
export declare const OnlineEvaluationTraceConfig: S.Schema<OnlineEvaluationTraceConfig>;
export type AgentTracesConfig = {
    sessionSpans: any[];
    cloudwatchLogs?: never;
    batchEvaluation?: never;
    onlineEvaluation?: never;
} | {
    sessionSpans?: never;
    cloudwatchLogs: CloudWatchLogsTraceConfig;
    batchEvaluation?: never;
    onlineEvaluation?: never;
} | {
    sessionSpans?: never;
    cloudwatchLogs?: never;
    batchEvaluation: BatchEvaluationTraceConfig;
    onlineEvaluation?: never;
} | {
    sessionSpans?: never;
    cloudwatchLogs?: never;
    batchEvaluation?: never;
    onlineEvaluation: OnlineEvaluationTraceConfig;
};
export declare const AgentTracesConfig: any;
export interface RecommendationEvaluatorReference {
    evaluatorArn: string;
}
export declare const RecommendationEvaluatorReference: S.Schema<RecommendationEvaluatorReference>;
export type RecommendationEvaluatorList = RecommendationEvaluatorReference[];
export declare const RecommendationEvaluatorList: any;
export interface RecommendationEvaluationConfig {
    evaluators: RecommendationEvaluatorReference[];
}
export declare const RecommendationEvaluationConfig: S.Schema<RecommendationEvaluationConfig>;
export interface SystemPromptRecommendationConfig {
    systemPrompt: SystemPromptConfig;
    agentTraces: AgentTracesConfig;
    evaluationConfig?: RecommendationEvaluationConfig;
}
export declare const SystemPromptRecommendationConfig: S.Schema<SystemPromptRecommendationConfig>;
export type RecommendationToolName = string;
export type ToolDescriptionText = string | redacted.Redacted<string>;
export type ToolDescriptionConfig = {
    text: string | redacted.Redacted<string>;
};
export declare const ToolDescriptionConfig: any;
export interface ToolDescriptionInput {
    toolName: string;
    toolDescription: ToolDescriptionConfig;
}
export declare const ToolDescriptionInput: S.Schema<ToolDescriptionInput>;
export type ToolDescriptionList = ToolDescriptionInput[];
export declare const ToolDescriptionList: any;
export interface ToolDescriptionTextInput {
    tools: ToolDescriptionInput[];
}
export declare const ToolDescriptionTextInput: S.Schema<ToolDescriptionTextInput>;
export interface ConfigurationBundleToolEntry {
    toolName: string;
    toolDescriptionJsonPath: string;
}
export declare const ConfigurationBundleToolEntry: S.Schema<ConfigurationBundleToolEntry>;
export type ConfigurationBundleToolEntryList = ConfigurationBundleToolEntry[];
export declare const ConfigurationBundleToolEntryList: any;
export interface ToolDescriptionConfigurationBundle {
    bundleArn: string;
    versionId: string;
    tools: ConfigurationBundleToolEntry[];
}
export declare const ToolDescriptionConfigurationBundle: S.Schema<ToolDescriptionConfigurationBundle>;
export type ToolDescriptionSource = {
    toolDescriptionText: ToolDescriptionTextInput;
    configurationBundle?: never;
} | {
    toolDescriptionText?: never;
    configurationBundle: ToolDescriptionConfigurationBundle;
};
export declare const ToolDescriptionSource: any;
export interface ToolDescriptionRecommendationConfig {
    toolDescription: ToolDescriptionSource;
    agentTraces: AgentTracesConfig;
}
export declare const ToolDescriptionRecommendationConfig: S.Schema<ToolDescriptionRecommendationConfig>;
export type RecommendationConfig = {
    systemPromptRecommendationConfig: SystemPromptRecommendationConfig;
    toolDescriptionRecommendationConfig?: never;
} | {
    systemPromptRecommendationConfig?: never;
    toolDescriptionRecommendationConfig: ToolDescriptionRecommendationConfig;
};
export declare const RecommendationConfig: any;
export interface RecommendationResultConfigurationBundle {
    bundleArn: string;
    versionId: string;
}
export declare const RecommendationResultConfigurationBundle: S.Schema<RecommendationResultConfigurationBundle>;
export type RecommendationExplanation = string;
export type RecommendationErrorCode = string;
export type RecommendationErrorMessage = string;
export interface SystemPromptRecommendationResult {
    recommendedSystemPrompt?: string | redacted.Redacted<string>;
    configurationBundle?: RecommendationResultConfigurationBundle;
    explanation?: string;
    errorCode?: string;
    errorMessage?: string;
}
export declare const SystemPromptRecommendationResult: S.Schema<SystemPromptRecommendationResult>;
export interface ToolDescriptionOutput {
    toolName: string;
    recommendedToolDescription?: string | redacted.Redacted<string>;
    explanation?: string;
}
export declare const ToolDescriptionOutput: S.Schema<ToolDescriptionOutput>;
export type ToolDescriptionResultList = ToolDescriptionOutput[];
export declare const ToolDescriptionResultList: any;
export interface ToolDescriptionRecommendationResult {
    tools?: ToolDescriptionOutput[];
    configurationBundle?: RecommendationResultConfigurationBundle;
    errorCode?: string;
    errorMessage?: string;
}
export declare const ToolDescriptionRecommendationResult: S.Schema<ToolDescriptionRecommendationResult>;
export type RecommendationResult = {
    systemPromptRecommendationResult: SystemPromptRecommendationResult;
    toolDescriptionRecommendationResult?: never;
} | {
    systemPromptRecommendationResult?: never;
    toolDescriptionRecommendationResult: ToolDescriptionRecommendationResult;
};
export declare const RecommendationResult: any;
export interface GetRecommendationResponse {
    recommendationId: string;
    recommendationArn: string;
    name: string;
    description?: string;
    type: RecommendationType;
    recommendationConfig: RecommendationConfig;
    status: RecommendationStatus;
    createdAt: Date;
    updatedAt: Date;
    recommendationResult?: RecommendationResult;
    kmsKeyArn?: string;
}
export declare const GetRecommendationResponse: S.Schema<GetRecommendationResponse>;
export type WorkloadIdentityTokenType = string | redacted.Redacted<string>;
export type CredentialProviderName = string;
export interface GetResourceApiKeyRequest {
    workloadIdentityToken: string | redacted.Redacted<string>;
    resourceCredentialProviderName: string;
}
export declare const GetResourceApiKeyRequest: S.Schema<GetResourceApiKeyRequest>;
export type ApiKeyType = string | redacted.Redacted<string>;
export interface GetResourceApiKeyResponse {
    apiKey: string | redacted.Redacted<string>;
}
export declare const GetResourceApiKeyResponse: S.Schema<GetResourceApiKeyResponse>;
export type ScopeType = string;
export type ScopesListType = string[];
export declare const ScopesListType: any;
export type Oauth2FlowType = "USER_FEDERATION" | "M2M" | "ON_BEHALF_OF_TOKEN_EXCHANGE" | (string & {});
export declare const Oauth2FlowType: any;
export type ResourceOauth2ReturnUrlType = string;
export type CustomRequestKeyType = string;
export type CustomRequestValueType = string | redacted.Redacted<string>;
export type CustomRequestParametersType = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const CustomRequestParametersType: any;
export type State = string | redacted.Redacted<string>;
export type ResourceType = string;
export type ResourcesListType = string[];
export declare const ResourcesListType: any;
export type AudienceType = string;
export type AudiencesListType = string[];
export declare const AudiencesListType: any;
export interface GetResourceOauth2TokenRequest {
    workloadIdentityToken: string | redacted.Redacted<string>;
    resourceCredentialProviderName: string;
    scopes: string[];
    oauth2Flow: Oauth2FlowType;
    sessionUri?: string;
    resourceOauth2ReturnUrl?: string;
    forceAuthentication?: boolean;
    customParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    customState?: string | redacted.Redacted<string>;
    resources?: string[];
    audiences?: string[];
}
export declare const GetResourceOauth2TokenRequest: S.Schema<GetResourceOauth2TokenRequest>;
export type AuthorizationUrlType = string | redacted.Redacted<string>;
export type AccessTokenType = string | redacted.Redacted<string>;
export type SessionStatus = "IN_PROGRESS" | "FAILED" | (string & {});
export declare const SessionStatus: any;
export interface GetResourceOauth2TokenResponse {
    authorizationUrl?: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    sessionUri?: string;
    sessionStatus?: SessionStatus;
}
export declare const GetResourceOauth2TokenResponse: S.Schema<GetResourceOauth2TokenResponse>;
export type PaymentHttpMethodType = "GET" | "POST" | "PUT" | "DELETE" | "PATCH" | (string & {});
export declare const PaymentHttpMethodType: any;
export type PaymentRequestHostType = string;
export type PaymentRequestPathType = string;
export type CoinbaseCdpPaymentRequestBodyType = string;
export interface CoinbaseCdpTokenRequestInput {
    requestMethod: PaymentHttpMethodType;
    requestHost?: string;
    requestPath: string;
    includeWalletAuthToken?: boolean;
    requestBody?: string;
}
export declare const CoinbaseCdpTokenRequestInput: S.Schema<CoinbaseCdpTokenRequestInput>;
export type StripePrivyRequestHostType = string;
export type StripePrivyRequestPathType = string;
export type StripePrivyRequestBodyType = string | redacted.Redacted<string>;
export interface StripePrivyTokenRequestInput {
    requestHost?: string;
    requestPath: string;
    requestBody: string | redacted.Redacted<string>;
    includeAuthorizationSignature?: boolean;
}
export declare const StripePrivyTokenRequestInput: S.Schema<StripePrivyTokenRequestInput>;
export type PaymentTokenRequestInput = {
    coinbaseCdpTokenRequest: CoinbaseCdpTokenRequestInput;
    stripePrivyTokenRequest?: never;
} | {
    coinbaseCdpTokenRequest?: never;
    stripePrivyTokenRequest: StripePrivyTokenRequestInput;
};
export declare const PaymentTokenRequestInput: any;
export interface GetResourcePaymentTokenRequest {
    workloadIdentityToken: string | redacted.Redacted<string>;
    resourceCredentialProviderName: string;
    paymentTokenRequest: PaymentTokenRequestInput;
}
export declare const GetResourcePaymentTokenRequest: S.Schema<GetResourcePaymentTokenRequest>;
export type CoinbaseCdpPaymentJwtTokenType = string | redacted.Redacted<string>;
export interface CoinbaseCdpTokenResponseOutput {
    bearerToken: string | redacted.Redacted<string>;
    walletAuthToken?: string | redacted.Redacted<string>;
}
export declare const CoinbaseCdpTokenResponseOutput: S.Schema<CoinbaseCdpTokenResponseOutput>;
export type StripePrivyAuthorizationSignatureType = string | redacted.Redacted<string>;
export type StripePrivyAppIdType = string;
export type StripePrivyBasicAuthTokenType = string | redacted.Redacted<string>;
export interface StripePrivyTokenResponseOutput {
    authorizationSignature?: string | redacted.Redacted<string>;
    requestExpiry?: number;
    appId: string;
    basicAuthToken: string | redacted.Redacted<string>;
}
export declare const StripePrivyTokenResponseOutput: S.Schema<StripePrivyTokenResponseOutput>;
export type PaymentTokenResponseOutput = {
    coinbaseCdpTokenResponse: CoinbaseCdpTokenResponseOutput;
    stripePrivyTokenResponse?: never;
} | {
    coinbaseCdpTokenResponse?: never;
    stripePrivyTokenResponse: StripePrivyTokenResponseOutput;
};
export declare const PaymentTokenResponseOutput: any;
export interface GetResourcePaymentTokenResponse {
    paymentTokenResponse: PaymentTokenResponseOutput;
}
export declare const GetResourcePaymentTokenResponse: S.Schema<GetResourcePaymentTokenResponse>;
export type WorkloadIdentityNameType = string;
export interface GetWorkloadAccessTokenRequest {
    workloadName: string;
}
export declare const GetWorkloadAccessTokenRequest: S.Schema<GetWorkloadAccessTokenRequest>;
export interface GetWorkloadAccessTokenResponse {
    workloadAccessToken: string | redacted.Redacted<string>;
}
export declare const GetWorkloadAccessTokenResponse: S.Schema<GetWorkloadAccessTokenResponse>;
export interface GetWorkloadAccessTokenForJWTRequest {
    workloadName: string;
    userToken: string | redacted.Redacted<string>;
}
export declare const GetWorkloadAccessTokenForJWTRequest: S.Schema<GetWorkloadAccessTokenForJWTRequest>;
export interface GetWorkloadAccessTokenForJWTResponse {
    workloadAccessToken: string | redacted.Redacted<string>;
}
export declare const GetWorkloadAccessTokenForJWTResponse: S.Schema<GetWorkloadAccessTokenForJWTResponse>;
export interface GetWorkloadAccessTokenForUserIdRequest {
    workloadName: string;
    userId: string;
}
export declare const GetWorkloadAccessTokenForUserIdRequest: S.Schema<GetWorkloadAccessTokenForUserIdRequest>;
export interface GetWorkloadAccessTokenForUserIdResponse {
    workloadAccessToken: string | redacted.Redacted<string>;
}
export declare const GetWorkloadAccessTokenForUserIdResponse: S.Schema<GetWorkloadAccessTokenForUserIdResponse>;
export type IngestPayloadType = {
    conversational: Conversational;
    json?: never;
} | {
    conversational?: never;
    json: MemoryJsonData;
};
export declare const IngestPayloadType: any;
export type IngestPayloadList = IngestPayloadType[];
export declare const IngestPayloadList: any;
export interface InlineMemoryContent {
    payload: IngestPayloadType[];
}
export declare const InlineMemoryContent: S.Schema<InlineMemoryContent>;
export type ContentSource = {
    inline: InlineMemoryContent;
};
export declare const ContentSource: any;
export interface IngestDataInput {
    memoryId: string;
    source: ContentSource;
    contentTimestamp: Date;
    actorId: string;
    sessionId?: string;
    extractionConfig?: ExtractionConfig;
    metadata?: {
        [key: string]: MetadataValue | undefined;
    };
    clientToken?: string;
}
export declare const IngestDataInput: S.Schema<IngestDataInput>;
export interface IngestDataOutput {
    sessionId: string;
}
export declare const IngestDataOutput: S.Schema<IngestDataOutput>;
export type MimeType = string;
export type StringType = string;
export type Body = Uint8Array | redacted.Redacted<Uint8Array>;
export interface InvokeAgentRuntimeRequest {
    contentType?: string;
    accept?: string;
    mcpSessionId?: string;
    runtimeSessionId?: string;
    mcpProtocolVersion?: string;
    mcpMethod?: string;
    mcpName?: string;
    runtimeUserId?: string;
    traceId?: string;
    traceParent?: string;
    traceState?: string;
    baggage?: string;
    agentRuntimeArn: string;
    qualifier?: string;
    accountId?: string;
    payload: T.StreamingInputBody;
}
export declare const InvokeAgentRuntimeRequest: S.Schema<InvokeAgentRuntimeRequest>;
export interface InvokeAgentRuntimeResponse {
    runtimeSessionId?: string;
    mcpSessionId?: string;
    mcpProtocolVersion?: string;
    traceId?: string;
    traceParent?: string;
    traceState?: string;
    baggage?: string;
    contentType: string;
    response?: T.StreamingOutputBody;
    statusCode?: number;
}
export declare const InvokeAgentRuntimeResponse: S.Schema<InvokeAgentRuntimeResponse>;
export interface InvokeAgentRuntimeCommandRequestBody {
    command: string;
    timeout?: number;
}
export declare const InvokeAgentRuntimeCommandRequestBody: S.Schema<InvokeAgentRuntimeCommandRequestBody>;
export interface InvokeAgentRuntimeCommandRequest {
    contentType?: string;
    accept?: string;
    runtimeSessionId?: string;
    traceId?: string;
    traceParent?: string;
    traceState?: string;
    baggage?: string;
    agentRuntimeArn: string;
    qualifier?: string;
    accountId?: string;
    body: InvokeAgentRuntimeCommandRequestBody;
}
export declare const InvokeAgentRuntimeCommandRequest: S.Schema<InvokeAgentRuntimeCommandRequest>;
export interface ContentStartEvent {
}
export declare const ContentStartEvent: S.Schema<ContentStartEvent>;
export interface ContentDeltaEvent {
    stdout?: string;
    stderr?: string;
}
export declare const ContentDeltaEvent: S.Schema<ContentDeltaEvent>;
export type CommandExecutionStatus = "COMPLETED" | "TIMED_OUT" | (string & {});
export declare const CommandExecutionStatus: any;
export interface ContentStopEvent {
    exitCode: number;
    status: CommandExecutionStatus;
}
export declare const ContentStopEvent: S.Schema<ContentStopEvent>;
export interface ResponseChunk {
    contentStart?: ContentStartEvent;
    contentDelta?: ContentDeltaEvent;
    contentStop?: ContentStopEvent;
}
export declare const ResponseChunk: S.Schema<ResponseChunk>;
export type NonBlankString = string;
export type ValidationExceptionReason = "CannotParse" | "FieldValidationFailed" | "IdempotentParameterMismatchException" | "EventInOtherSession" | "ResourceConflict" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type InvokeAgentRuntimeCommandStreamOutput = {
    chunk: ResponseChunk;
    accessDeniedException?: never;
    internalServerException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    validationException?: never;
    runtimeClientError?: never;
} | {
    chunk?: never;
    accessDeniedException: AccessDeniedException;
    internalServerException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    validationException?: never;
    runtimeClientError?: never;
} | {
    chunk?: never;
    accessDeniedException?: never;
    internalServerException: InternalServerException;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    validationException?: never;
    runtimeClientError?: never;
} | {
    chunk?: never;
    accessDeniedException?: never;
    internalServerException?: never;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    validationException?: never;
    runtimeClientError?: never;
} | {
    chunk?: never;
    accessDeniedException?: never;
    internalServerException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: never;
    validationException?: never;
    runtimeClientError?: never;
} | {
    chunk?: never;
    accessDeniedException?: never;
    internalServerException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException: ThrottlingException;
    validationException?: never;
    runtimeClientError?: never;
} | {
    chunk?: never;
    accessDeniedException?: never;
    internalServerException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    validationException: ValidationException;
    runtimeClientError?: never;
} | {
    chunk?: never;
    accessDeniedException?: never;
    internalServerException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    validationException?: never;
    runtimeClientError: RuntimeClientError;
};
export declare const InvokeAgentRuntimeCommandStreamOutput: S.Schema<stream.Stream<InvokeAgentRuntimeCommandStreamOutput, Error, never>>;
export interface InvokeAgentRuntimeCommandResponse {
    runtimeSessionId?: string;
    traceId?: string;
    traceParent?: string;
    traceState?: string;
    baggage?: string;
    contentType: string;
    statusCode?: number;
    stream: stream.Stream<InvokeAgentRuntimeCommandStreamOutput, Error, never>;
}
export declare const InvokeAgentRuntimeCommandResponse: S.Schema<InvokeAgentRuntimeCommandResponse>;
export type MouseButton = "LEFT" | "RIGHT" | "MIDDLE" | (string & {});
export declare const MouseButton: any;
export interface MouseClickArguments {
    x: number;
    y: number;
    button?: MouseButton;
    clickCount?: number;
}
export declare const MouseClickArguments: S.Schema<MouseClickArguments>;
export interface MouseMoveArguments {
    x: number;
    y: number;
}
export declare const MouseMoveArguments: S.Schema<MouseMoveArguments>;
export interface MouseDragArguments {
    endX: number;
    endY: number;
    startX: number;
    startY: number;
    button?: MouseButton;
}
export declare const MouseDragArguments: S.Schema<MouseDragArguments>;
export interface MouseScrollArguments {
    x: number;
    y: number;
    deltaX?: number;
    deltaY?: number;
}
export declare const MouseScrollArguments: S.Schema<MouseScrollArguments>;
export interface KeyTypeArguments {
    text: string;
}
export declare const KeyTypeArguments: S.Schema<KeyTypeArguments>;
export interface KeyPressArguments {
    key: string;
    presses?: number;
}
export declare const KeyPressArguments: S.Schema<KeyPressArguments>;
export type KeyList = string[];
export declare const KeyList: any;
export interface KeyShortcutArguments {
    keys: string[];
}
export declare const KeyShortcutArguments: S.Schema<KeyShortcutArguments>;
export type ScreenshotFormat = "PNG" | (string & {});
export declare const ScreenshotFormat: any;
export interface ScreenshotArguments {
    format?: ScreenshotFormat;
}
export declare const ScreenshotArguments: S.Schema<ScreenshotArguments>;
export type BrowserAction = {
    mouseClick: MouseClickArguments;
    mouseMove?: never;
    mouseDrag?: never;
    mouseScroll?: never;
    keyType?: never;
    keyPress?: never;
    keyShortcut?: never;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove: MouseMoveArguments;
    mouseDrag?: never;
    mouseScroll?: never;
    keyType?: never;
    keyPress?: never;
    keyShortcut?: never;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove?: never;
    mouseDrag: MouseDragArguments;
    mouseScroll?: never;
    keyType?: never;
    keyPress?: never;
    keyShortcut?: never;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove?: never;
    mouseDrag?: never;
    mouseScroll: MouseScrollArguments;
    keyType?: never;
    keyPress?: never;
    keyShortcut?: never;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove?: never;
    mouseDrag?: never;
    mouseScroll?: never;
    keyType: KeyTypeArguments;
    keyPress?: never;
    keyShortcut?: never;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove?: never;
    mouseDrag?: never;
    mouseScroll?: never;
    keyType?: never;
    keyPress: KeyPressArguments;
    keyShortcut?: never;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove?: never;
    mouseDrag?: never;
    mouseScroll?: never;
    keyType?: never;
    keyPress?: never;
    keyShortcut: KeyShortcutArguments;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove?: never;
    mouseDrag?: never;
    mouseScroll?: never;
    keyType?: never;
    keyPress?: never;
    keyShortcut?: never;
    screenshot: ScreenshotArguments;
};
export declare const BrowserAction: any;
export interface InvokeBrowserRequest {
    browserIdentifier: string;
    sessionId: string;
    action: BrowserAction;
}
export declare const InvokeBrowserRequest: S.Schema<InvokeBrowserRequest>;
export type BrowserActionStatus = "SUCCESS" | "FAILED" | (string & {});
export declare const BrowserActionStatus: any;
export interface MouseClickResult {
    status: BrowserActionStatus;
    error?: string;
}
export declare const MouseClickResult: S.Schema<MouseClickResult>;
export interface MouseMoveResult {
    status: BrowserActionStatus;
    error?: string;
}
export declare const MouseMoveResult: S.Schema<MouseMoveResult>;
export interface MouseDragResult {
    status: BrowserActionStatus;
    error?: string;
}
export declare const MouseDragResult: S.Schema<MouseDragResult>;
export interface MouseScrollResult {
    status: BrowserActionStatus;
    error?: string;
}
export declare const MouseScrollResult: S.Schema<MouseScrollResult>;
export interface KeyTypeResult {
    status: BrowserActionStatus;
    error?: string;
}
export declare const KeyTypeResult: S.Schema<KeyTypeResult>;
export interface KeyPressResult {
    status: BrowserActionStatus;
    error?: string;
}
export declare const KeyPressResult: S.Schema<KeyPressResult>;
export interface KeyShortcutResult {
    status: BrowserActionStatus;
    error?: string;
}
export declare const KeyShortcutResult: S.Schema<KeyShortcutResult>;
export interface ScreenshotResult {
    status: BrowserActionStatus;
    error?: string;
    data?: Uint8Array;
}
export declare const ScreenshotResult: S.Schema<ScreenshotResult>;
export type BrowserActionResult = {
    mouseClick: MouseClickResult;
    mouseMove?: never;
    mouseDrag?: never;
    mouseScroll?: never;
    keyType?: never;
    keyPress?: never;
    keyShortcut?: never;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove: MouseMoveResult;
    mouseDrag?: never;
    mouseScroll?: never;
    keyType?: never;
    keyPress?: never;
    keyShortcut?: never;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove?: never;
    mouseDrag: MouseDragResult;
    mouseScroll?: never;
    keyType?: never;
    keyPress?: never;
    keyShortcut?: never;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove?: never;
    mouseDrag?: never;
    mouseScroll: MouseScrollResult;
    keyType?: never;
    keyPress?: never;
    keyShortcut?: never;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove?: never;
    mouseDrag?: never;
    mouseScroll?: never;
    keyType: KeyTypeResult;
    keyPress?: never;
    keyShortcut?: never;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove?: never;
    mouseDrag?: never;
    mouseScroll?: never;
    keyType?: never;
    keyPress: KeyPressResult;
    keyShortcut?: never;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove?: never;
    mouseDrag?: never;
    mouseScroll?: never;
    keyType?: never;
    keyPress?: never;
    keyShortcut: KeyShortcutResult;
    screenshot?: never;
} | {
    mouseClick?: never;
    mouseMove?: never;
    mouseDrag?: never;
    mouseScroll?: never;
    keyType?: never;
    keyPress?: never;
    keyShortcut?: never;
    screenshot: ScreenshotResult;
};
export declare const BrowserActionResult: any;
export interface InvokeBrowserResponse {
    result: BrowserActionResult;
    sessionId: string;
}
export declare const InvokeBrowserResponse: S.Schema<InvokeBrowserResponse>;
export type ToolName = "executeCode" | "executeCommand" | "readFiles" | "listFiles" | "removeFiles" | "writeFiles" | "startCommandExecution" | "getTask" | "stopTask" | (string & {});
export declare const ToolName: any;
export type MaxLenString = string;
export type ProgrammingLanguage = "python" | "javascript" | "typescript" | (string & {});
export declare const ProgrammingLanguage: any;
export type StringList = string[];
export declare const StringList: any;
export interface InputContentBlock {
    path: string;
    text?: string;
    blob?: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const InputContentBlock: S.Schema<InputContentBlock>;
export type InputContentBlockList = InputContentBlock[];
export declare const InputContentBlockList: any;
export type LanguageRuntime = "nodejs" | "deno" | "python" | (string & {});
export declare const LanguageRuntime: any;
export interface ToolArguments {
    code?: string;
    language?: ProgrammingLanguage;
    clearContext?: boolean;
    command?: string;
    path?: string;
    paths?: string[];
    content?: InputContentBlock[];
    directoryPath?: string;
    taskId?: string;
    runtime?: LanguageRuntime;
}
export declare const ToolArguments: S.Schema<ToolArguments>;
export interface InvokeCodeInterpreterRequest {
    codeInterpreterIdentifier: string;
    sessionId?: string;
    traceId?: string;
    traceParent?: string;
    name: ToolName;
    arguments?: ToolArguments;
}
export declare const InvokeCodeInterpreterRequest: S.Schema<InvokeCodeInterpreterRequest>;
export type ContentBlockType = "text" | "image" | "resource" | "resource_link" | (string & {});
export declare const ContentBlockType: any;
export type ResourceContentType = "text" | "blob" | (string & {});
export declare const ResourceContentType: any;
export interface ResourceContent {
    type: ResourceContentType;
    uri?: string;
    mimeType?: string;
    text?: string;
    blob?: Uint8Array;
}
export declare const ResourceContent: S.Schema<ResourceContent>;
export interface ContentBlock {
    type: ContentBlockType;
    text?: string;
    data?: Uint8Array;
    mimeType?: string;
    uri?: string;
    name?: string;
    description?: string;
    size?: number;
    resource?: ResourceContent;
}
export declare const ContentBlock: S.Schema<ContentBlock>;
export type ContentBlockList = ContentBlock[];
export declare const ContentBlockList: any;
export type TaskStatus = "submitted" | "working" | "completed" | "canceled" | "failed" | (string & {});
export declare const TaskStatus: any;
export interface ToolResultStructuredContent {
    taskId?: string;
    taskStatus?: TaskStatus;
    stdout?: string;
    stderr?: string;
    exitCode?: number;
    executionTime?: number;
}
export declare const ToolResultStructuredContent: S.Schema<ToolResultStructuredContent>;
export interface CodeInterpreterResult {
    content: ContentBlock[];
    structuredContent?: ToolResultStructuredContent;
    isError?: boolean;
}
export declare const CodeInterpreterResult: S.Schema<CodeInterpreterResult>;
export type CodeInterpreterStreamOutput = {
    result: CodeInterpreterResult;
    accessDeniedException?: never;
    conflictException?: never;
    internalServerException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    validationException?: never;
} | {
    result?: never;
    accessDeniedException: AccessDeniedException;
    conflictException?: never;
    internalServerException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    validationException?: never;
} | {
    result?: never;
    accessDeniedException?: never;
    conflictException: ConflictException;
    internalServerException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    validationException?: never;
} | {
    result?: never;
    accessDeniedException?: never;
    conflictException?: never;
    internalServerException: InternalServerException;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    validationException?: never;
} | {
    result?: never;
    accessDeniedException?: never;
    conflictException?: never;
    internalServerException?: never;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    validationException?: never;
} | {
    result?: never;
    accessDeniedException?: never;
    conflictException?: never;
    internalServerException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: never;
    validationException?: never;
} | {
    result?: never;
    accessDeniedException?: never;
    conflictException?: never;
    internalServerException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException: ThrottlingException;
    validationException?: never;
} | {
    result?: never;
    accessDeniedException?: never;
    conflictException?: never;
    internalServerException?: never;
    resourceNotFoundException?: never;
    serviceQuotaExceededException?: never;
    throttlingException?: never;
    validationException: ValidationException;
};
export declare const CodeInterpreterStreamOutput: S.Schema<stream.Stream<CodeInterpreterStreamOutput, Error, never>>;
export interface InvokeCodeInterpreterResponse {
    sessionId?: string;
    stream: stream.Stream<CodeInterpreterStreamOutput, Error, never>;
}
export declare const InvokeCodeInterpreterResponse: S.Schema<InvokeCodeInterpreterResponse>;
export type HarnessArn = string;
export type HarnessEndpointName = string;
export type HarnessConversationRole = "user" | "assistant" | (string & {});
export declare const HarnessConversationRole: any;
export type SensitiveText = string | redacted.Redacted<string>;
export type HarnessToolName = string;
export type HarnessToolUseId = string;
export type SensitiveJson = unknown;
export type HarnessToolUseType = "tool_use" | "server_tool_use" | "mcp_tool_use" | (string & {});
export declare const HarnessToolUseType: any;
export interface HarnessToolUseBlock {
    name: string;
    toolUseId: string;
    input: any;
    type?: HarnessToolUseType;
    serverName?: string;
}
export declare const HarnessToolUseBlock: S.Schema<HarnessToolUseBlock>;
export type HarnessToolResultContentBlock = {
    text: string | redacted.Redacted<string>;
    json?: never;
} | {
    text?: never;
    json: any;
};
export declare const HarnessToolResultContentBlock: any;
export type HarnessToolResultContentBlocks = HarnessToolResultContentBlock[];
export declare const HarnessToolResultContentBlocks: any;
export type HarnessToolUseStatus = "success" | "error" | (string & {});
export declare const HarnessToolUseStatus: any;
export interface HarnessToolResultBlock {
    toolUseId: string;
    content: HarnessToolResultContentBlock[];
    status?: HarnessToolUseStatus;
    type?: HarnessToolUseType;
}
export declare const HarnessToolResultBlock: S.Schema<HarnessToolResultBlock>;
export interface HarnessReasoningTextBlock {
    text: string;
    signature?: string;
}
export declare const HarnessReasoningTextBlock: S.Schema<HarnessReasoningTextBlock>;
export type HarnessReasoningContentBlock = {
    reasoningText: HarnessReasoningTextBlock;
    redactedContent?: never;
} | {
    reasoningText?: never;
    redactedContent: Uint8Array;
};
export declare const HarnessReasoningContentBlock: any;
export type HarnessContentBlock = {
    text: string | redacted.Redacted<string>;
    toolUse?: never;
    toolResult?: never;
    reasoningContent?: never;
} | {
    text?: never;
    toolUse: HarnessToolUseBlock;
    toolResult?: never;
    reasoningContent?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult: HarnessToolResultBlock;
    reasoningContent?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult?: never;
    reasoningContent: HarnessReasoningContentBlock;
};
export declare const HarnessContentBlock: any;
export type HarnessContentBlocks = HarnessContentBlock[];
export declare const HarnessContentBlocks: any;
export interface HarnessMessage {
    role: HarnessConversationRole;
    content: HarnessContentBlock[];
}
export declare const HarnessMessage: S.Schema<HarnessMessage>;
export type HarnessMessages = HarnessMessage[];
export declare const HarnessMessages: any;
export type ModelId = string;
export type MaxTokens = number;
export type Temperature = number;
export type TopP = number;
export type HarnessBedrockApiFormat = "converse_stream" | "responses" | "chat_completions" | (string & {});
export declare const HarnessBedrockApiFormat: any;
export interface HarnessBedrockModelConfig {
    modelId: string;
    maxTokens?: number;
    temperature?: number;
    topP?: number;
    apiFormat?: HarnessBedrockApiFormat;
    additionalParams?: any;
}
export declare const HarnessBedrockModelConfig: S.Schema<HarnessBedrockModelConfig>;
export type ApiKeyArn = string;
export type HarnessOpenAiApiFormat = "chat_completions" | "responses" | (string & {});
export declare const HarnessOpenAiApiFormat: any;
export interface HarnessOpenAiModelConfig {
    modelId: string;
    apiKeyArn: string;
    maxTokens?: number;
    temperature?: number;
    topP?: number;
    apiFormat?: HarnessOpenAiApiFormat;
    additionalParams?: any;
}
export declare const HarnessOpenAiModelConfig: S.Schema<HarnessOpenAiModelConfig>;
export type TopK = number;
export interface HarnessGeminiModelConfig {
    modelId: string;
    apiKeyArn: string;
    maxTokens?: number;
    temperature?: number;
    topP?: number;
    topK?: number;
    additionalParams?: any;
}
export declare const HarnessGeminiModelConfig: S.Schema<HarnessGeminiModelConfig>;
export type HarnessLiteLlmApiBase = string | redacted.Redacted<string>;
export interface HarnessLiteLlmModelConfig {
    modelId: string;
    apiKeyArn?: string;
    apiBase?: string | redacted.Redacted<string>;
    maxTokens?: number;
    temperature?: number;
    topP?: number;
    additionalParams?: any;
}
export declare const HarnessLiteLlmModelConfig: S.Schema<HarnessLiteLlmModelConfig>;
export type HarnessModelConfiguration = {
    bedrockModelConfig: HarnessBedrockModelConfig;
    openAiModelConfig?: never;
    geminiModelConfig?: never;
    liteLlmModelConfig?: never;
} | {
    bedrockModelConfig?: never;
    openAiModelConfig: HarnessOpenAiModelConfig;
    geminiModelConfig?: never;
    liteLlmModelConfig?: never;
} | {
    bedrockModelConfig?: never;
    openAiModelConfig?: never;
    geminiModelConfig: HarnessGeminiModelConfig;
    liteLlmModelConfig?: never;
} | {
    bedrockModelConfig?: never;
    openAiModelConfig?: never;
    geminiModelConfig?: never;
    liteLlmModelConfig: HarnessLiteLlmModelConfig;
};
export declare const HarnessModelConfiguration: any;
export type HarnessSystemContentBlock = {
    text: string | redacted.Redacted<string>;
};
export declare const HarnessSystemContentBlock: any;
export type HarnessSystemPrompt = HarnessSystemContentBlock[];
export declare const HarnessSystemPrompt: any;
export type HarnessToolType = "remote_mcp" | "agentcore_browser" | "agentcore_gateway" | "inline_function" | "agentcore_code_interpreter" | (string & {});
export declare const HarnessToolType: any;
export type HarnessRemoteMcpUrl = string | redacted.Redacted<string>;
export type HttpHeaderKey = string;
export type HttpHeaderValue = string;
export type HttpHeadersMap = {
    [key: string]: string | undefined;
};
export declare const HttpHeadersMap: any;
export interface HarnessRemoteMcpConfig {
    url: string | redacted.Redacted<string>;
    headers?: {
        [key: string]: string | undefined;
    };
}
export declare const HarnessRemoteMcpConfig: S.Schema<HarnessRemoteMcpConfig>;
export type HarnessBrowserArn = string;
export interface HarnessAgentCoreBrowserConfig {
    browserArn?: string;
}
export declare const HarnessAgentCoreBrowserConfig: S.Schema<HarnessAgentCoreBrowserConfig>;
export type OAuthCredentialProviderArn = string;
export type OAuthScope = string;
export type OAuthScopes = string[];
export declare const OAuthScopes: any;
export type OAuthCustomParametersKey = string;
export type OAuthCustomParametersValue = string | redacted.Redacted<string>;
export type OAuthCustomParameters = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const OAuthCustomParameters: any;
export type OAuthGrantType = "CLIENT_CREDENTIALS" | "AUTHORIZATION_CODE" | "TOKEN_EXCHANGE" | (string & {});
export declare const OAuthGrantType: any;
export type OAuthDefaultReturnUrl = string;
export interface OAuthCredentialProvider {
    providerArn: string;
    scopes: string[];
    customParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    grantType?: OAuthGrantType;
    defaultReturnUrl?: string;
}
export declare const OAuthCredentialProvider: S.Schema<OAuthCredentialProvider>;
export type HarnessGatewayOutboundAuth = {
    awsIam: Record<string, never>;
    none?: never;
    oauth?: never;
} | {
    awsIam?: never;
    none: Record<string, never>;
    oauth?: never;
} | {
    awsIam?: never;
    none?: never;
    oauth: OAuthCredentialProvider;
};
export declare const HarnessGatewayOutboundAuth: any;
export interface HarnessAgentCoreGatewayConfig {
    gatewayArn: string;
    outboundAuth?: HarnessGatewayOutboundAuth;
}
export declare const HarnessAgentCoreGatewayConfig: S.Schema<HarnessAgentCoreGatewayConfig>;
export type HarnessInlineFunctionDescription = string | redacted.Redacted<string>;
export interface HarnessInlineFunctionConfig {
    description: string | redacted.Redacted<string>;
    inputSchema: any;
}
export declare const HarnessInlineFunctionConfig: S.Schema<HarnessInlineFunctionConfig>;
export type HarnessCodeInterpreterArn = string;
export interface HarnessAgentCoreCodeInterpreterConfig {
    codeInterpreterArn?: string;
}
export declare const HarnessAgentCoreCodeInterpreterConfig: S.Schema<HarnessAgentCoreCodeInterpreterConfig>;
export type HarnessToolConfiguration = {
    remoteMcp: HarnessRemoteMcpConfig;
    agentCoreBrowser?: never;
    agentCoreGateway?: never;
    inlineFunction?: never;
    agentCoreCodeInterpreter?: never;
} | {
    remoteMcp?: never;
    agentCoreBrowser: HarnessAgentCoreBrowserConfig;
    agentCoreGateway?: never;
    inlineFunction?: never;
    agentCoreCodeInterpreter?: never;
} | {
    remoteMcp?: never;
    agentCoreBrowser?: never;
    agentCoreGateway: HarnessAgentCoreGatewayConfig;
    inlineFunction?: never;
    agentCoreCodeInterpreter?: never;
} | {
    remoteMcp?: never;
    agentCoreBrowser?: never;
    agentCoreGateway?: never;
    inlineFunction: HarnessInlineFunctionConfig;
    agentCoreCodeInterpreter?: never;
} | {
    remoteMcp?: never;
    agentCoreBrowser?: never;
    agentCoreGateway?: never;
    inlineFunction?: never;
    agentCoreCodeInterpreter: HarnessAgentCoreCodeInterpreterConfig;
};
export declare const HarnessToolConfiguration: any;
export interface HarnessTool {
    type: HarnessToolType;
    name?: string;
    config?: HarnessToolConfiguration;
}
export declare const HarnessTool: S.Schema<HarnessTool>;
export type HarnessTools = HarnessTool[];
export declare const HarnessTools: any;
export type HarnessSkillPath = string;
export type HarnessSkillS3Uri = string;
export interface HarnessSkillS3Source {
    uri: string;
}
export declare const HarnessSkillS3Source: S.Schema<HarnessSkillS3Source>;
export type HarnessSkillGitUrl = string;
export interface HarnessSkillGitAuth {
    credentialArn: string;
    username?: string;
}
export declare const HarnessSkillGitAuth: S.Schema<HarnessSkillGitAuth>;
export interface HarnessSkillGitSource {
    url: string;
    path?: string;
    auth?: HarnessSkillGitAuth;
}
export declare const HarnessSkillGitSource: S.Schema<HarnessSkillGitSource>;
export type HarnessAwsSkillPath = string;
export type HarnessAwsSkillPaths = string[];
export declare const HarnessAwsSkillPaths: any;
export interface HarnessSkillAwsSkillsSource {
    paths?: string[];
}
export declare const HarnessSkillAwsSkillsSource: S.Schema<HarnessSkillAwsSkillsSource>;
export type HarnessSkill = {
    path: string;
    s3?: never;
    git?: never;
    awsSkills?: never;
} | {
    path?: never;
    s3: HarnessSkillS3Source;
    git?: never;
    awsSkills?: never;
} | {
    path?: never;
    s3?: never;
    git: HarnessSkillGitSource;
    awsSkills?: never;
} | {
    path?: never;
    s3?: never;
    git?: never;
    awsSkills: HarnessSkillAwsSkillsSource;
};
export declare const HarnessSkill: any;
export type HarnessSkills = HarnessSkill[];
export declare const HarnessSkills: any;
export type HarnessAllowedTool = string;
export type HarnessAllowedTools = string[];
export declare const HarnessAllowedTools: any;
export interface InvokeHarnessRequest {
    harnessArn: string;
    qualifier?: string;
    runtimeSessionId: string;
    runtimeUserId?: string;
    traceParent?: string;
    traceState?: string;
    traceId?: string;
    baggage?: string;
    messages: HarnessMessage[];
    model?: HarnessModelConfiguration;
    systemPrompt?: HarnessSystemContentBlock[];
    tools?: HarnessTool[];
    skills?: HarnessSkill[];
    allowedTools?: string[];
    maxIterations?: number;
    maxTokens?: number;
    timeoutSeconds?: number;
    actorId?: string;
}
export declare const InvokeHarnessRequest: S.Schema<InvokeHarnessRequest>;
export interface HarnessMessageStartEvent {
    role: HarnessConversationRole;
}
export declare const HarnessMessageStartEvent: S.Schema<HarnessMessageStartEvent>;
export interface HarnessToolUseBlockStart {
    toolUseId: string;
    name: string;
    type?: HarnessToolUseType;
    serverName?: string;
}
export declare const HarnessToolUseBlockStart: S.Schema<HarnessToolUseBlockStart>;
export interface HarnessToolResultBlockStart {
    toolUseId: string;
    status?: HarnessToolUseStatus;
}
export declare const HarnessToolResultBlockStart: S.Schema<HarnessToolResultBlockStart>;
export type HarnessContentBlockStart = {
    toolUse: HarnessToolUseBlockStart;
    toolResult?: never;
} | {
    toolUse?: never;
    toolResult: HarnessToolResultBlockStart;
};
export declare const HarnessContentBlockStart: any;
export interface HarnessContentBlockStartEvent {
    contentBlockIndex: number;
    start: HarnessContentBlockStart;
}
export declare const HarnessContentBlockStartEvent: S.Schema<HarnessContentBlockStartEvent>;
export interface HarnessToolUseBlockDelta {
    input: string | redacted.Redacted<string>;
}
export declare const HarnessToolUseBlockDelta: S.Schema<HarnessToolUseBlockDelta>;
export type HarnessToolResultBlockDelta = {
    text: string | redacted.Redacted<string>;
    json?: never;
} | {
    text?: never;
    json: any;
};
export declare const HarnessToolResultBlockDelta: any;
export type HarnessToolResultBlocksDelta = HarnessToolResultBlockDelta[];
export declare const HarnessToolResultBlocksDelta: any;
export type HarnessReasoningContentBlockDelta = {
    text: string;
    redactedContent?: never;
    signature?: never;
} | {
    text?: never;
    redactedContent: Uint8Array | redacted.Redacted<Uint8Array>;
    signature?: never;
} | {
    text?: never;
    redactedContent?: never;
    signature: string;
};
export declare const HarnessReasoningContentBlockDelta: any;
export interface HarnessToolResultMetadataBlockDelta {
    metadata: string | redacted.Redacted<string>;
}
export declare const HarnessToolResultMetadataBlockDelta: S.Schema<HarnessToolResultMetadataBlockDelta>;
export type HarnessContentBlockDelta = {
    text: string | redacted.Redacted<string>;
    toolUse?: never;
    toolResult?: never;
    reasoningContent?: never;
    toolResultMetadata?: never;
} | {
    text?: never;
    toolUse: HarnessToolUseBlockDelta;
    toolResult?: never;
    reasoningContent?: never;
    toolResultMetadata?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult: HarnessToolResultBlockDelta[];
    reasoningContent?: never;
    toolResultMetadata?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult?: never;
    reasoningContent: HarnessReasoningContentBlockDelta;
    toolResultMetadata?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult?: never;
    reasoningContent?: never;
    toolResultMetadata: HarnessToolResultMetadataBlockDelta;
};
export declare const HarnessContentBlockDelta: any;
export interface HarnessContentBlockDeltaEvent {
    contentBlockIndex: number;
    delta: HarnessContentBlockDelta;
}
export declare const HarnessContentBlockDeltaEvent: S.Schema<HarnessContentBlockDeltaEvent>;
export interface HarnessContentBlockStopEvent {
    contentBlockIndex: number;
}
export declare const HarnessContentBlockStopEvent: S.Schema<HarnessContentBlockStopEvent>;
export type HarnessStopReason = "end_turn" | "tool_use" | "tool_result" | "max_tokens" | "stop_sequence" | "content_filtered" | "malformed_model_output" | "malformed_tool_use" | "interrupted" | "partial_turn" | "model_context_window_exceeded" | "max_iterations_exceeded" | "max_output_tokens_exceeded" | "timeout_exceeded" | (string & {});
export declare const HarnessStopReason: any;
export interface HarnessMessageStopEvent {
    stopReason: HarnessStopReason;
}
export declare const HarnessMessageStopEvent: S.Schema<HarnessMessageStopEvent>;
export interface HarnessTokenUsage {
    inputTokens: number;
    outputTokens: number;
    totalTokens: number;
    cacheReadInputTokens?: number;
    cacheWriteInputTokens?: number;
}
export declare const HarnessTokenUsage: S.Schema<HarnessTokenUsage>;
export interface HarnessStreamMetrics {
    latencyMs: number;
}
export declare const HarnessStreamMetrics: S.Schema<HarnessStreamMetrics>;
export interface HarnessMetadataEvent {
    usage: HarnessTokenUsage;
    metrics: HarnessStreamMetrics;
}
export declare const HarnessMetadataEvent: S.Schema<HarnessMetadataEvent>;
export type InvokeHarnessStreamOutput = {
    messageStart: HarnessMessageStartEvent;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    validationException?: never;
    runtimeClientError?: never;
} | {
    messageStart?: never;
    contentBlockStart: HarnessContentBlockStartEvent;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    validationException?: never;
    runtimeClientError?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta: HarnessContentBlockDeltaEvent;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    validationException?: never;
    runtimeClientError?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop: HarnessContentBlockStopEvent;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    validationException?: never;
    runtimeClientError?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop: HarnessMessageStopEvent;
    metadata?: never;
    internalServerException?: never;
    validationException?: never;
    runtimeClientError?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata: HarnessMetadataEvent;
    internalServerException?: never;
    validationException?: never;
    runtimeClientError?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException: InternalServerException;
    validationException?: never;
    runtimeClientError?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    validationException: ValidationException;
    runtimeClientError?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    validationException?: never;
    runtimeClientError: RuntimeClientError;
};
export declare const InvokeHarnessStreamOutput: S.Schema<stream.Stream<InvokeHarnessStreamOutput, Error, never>>;
export interface InvokeHarnessResponse {
    stream: stream.Stream<InvokeHarnessStreamOutput, Error, never>;
}
export declare const InvokeHarnessResponse: S.Schema<InvokeHarnessResponse>;
export interface ListABTestsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListABTestsRequest: S.Schema<ListABTestsRequest>;
export interface ABTestSummary {
    abTestId: string;
    abTestArn: string;
    name: string;
    status: ABTestStatus;
    executionStatus: ABTestExecutionStatus;
    description?: string;
    gatewayArn?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const ABTestSummary: S.Schema<ABTestSummary>;
export type ABTestSummaryList = ABTestSummary[];
export declare const ABTestSummaryList: any;
export interface ListABTestsResponse {
    abTests: ABTestSummary[];
    nextToken?: string;
}
export declare const ListABTestsResponse: S.Schema<ListABTestsResponse>;
export type MaxResults = number;
export type PaginationToken = string;
export interface ListActorsInput {
    memoryId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListActorsInput: S.Schema<ListActorsInput>;
export interface ActorSummary {
    actorId: string;
}
export declare const ActorSummary: S.Schema<ActorSummary>;
export type ActorSummaryList = ActorSummary[];
export declare const ActorSummaryList: any;
export interface ListActorsOutput {
    actorSummaries: ActorSummary[];
    nextToken?: string;
}
export declare const ListActorsOutput: S.Schema<ListActorsOutput>;
export interface ListBatchEvaluationsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListBatchEvaluationsRequest: S.Schema<ListBatchEvaluationsRequest>;
export interface BatchEvaluationSummary {
    batchEvaluationId: string;
    batchEvaluationArn: string;
    batchEvaluationName: string;
    status: BatchEvaluationStatus;
    createdAt: Date;
    description?: string;
    evaluators?: Evaluator[];
    insights?: Insight[];
    evaluationResults?: EvaluationJobResults;
    errorDetails?: string[];
    kmsKeyArn?: string;
    updatedAt?: Date;
}
export declare const BatchEvaluationSummary: S.Schema<BatchEvaluationSummary>;
export type BatchEvaluationSummaryList = BatchEvaluationSummary[];
export declare const BatchEvaluationSummaryList: any;
export interface ListBatchEvaluationsResponse {
    batchEvaluations: BatchEvaluationSummary[];
    nextToken?: string;
}
export declare const ListBatchEvaluationsResponse: S.Schema<ListBatchEvaluationsResponse>;
export type NextToken = string;
export interface ListBrowserSessionsRequest {
    browserIdentifier: string;
    maxResults?: number;
    nextToken?: string;
    status?: BrowserSessionStatus;
}
export declare const ListBrowserSessionsRequest: S.Schema<ListBrowserSessionsRequest>;
export interface BrowserSessionSummary {
    browserIdentifier: string;
    sessionId: string;
    name?: string;
    status: BrowserSessionStatus;
    createdAt: Date;
    lastUpdatedAt?: Date;
}
export declare const BrowserSessionSummary: S.Schema<BrowserSessionSummary>;
export type BrowserSessionSummaries = BrowserSessionSummary[];
export declare const BrowserSessionSummaries: any;
export interface ListBrowserSessionsResponse {
    items: BrowserSessionSummary[];
    nextToken?: string;
}
export declare const ListBrowserSessionsResponse: S.Schema<ListBrowserSessionsResponse>;
export interface ListCodeInterpreterSessionsRequest {
    codeInterpreterIdentifier: string;
    maxResults?: number;
    nextToken?: string;
    status?: CodeInterpreterSessionStatus;
}
export declare const ListCodeInterpreterSessionsRequest: S.Schema<ListCodeInterpreterSessionsRequest>;
export interface CodeInterpreterSessionSummary {
    codeInterpreterIdentifier: string;
    sessionId: string;
    name?: string;
    status: CodeInterpreterSessionStatus;
    createdAt: Date;
    lastUpdatedAt?: Date;
}
export declare const CodeInterpreterSessionSummary: S.Schema<CodeInterpreterSessionSummary>;
export type CodeInterpreterSessionSummaries = CodeInterpreterSessionSummary[];
export declare const CodeInterpreterSessionSummaries: any;
export interface ListCodeInterpreterSessionsResponse {
    items: CodeInterpreterSessionSummary[];
    nextToken?: string;
}
export declare const ListCodeInterpreterSessionsResponse: S.Schema<ListCodeInterpreterSessionsResponse>;
export interface BranchFilter {
    name: string;
    includeParentBranches?: boolean;
}
export declare const BranchFilter: S.Schema<BranchFilter>;
export type LeftExpression = {
    metadataKey: string;
};
export declare const LeftExpression: any;
export type OperatorType = "EQUALS_TO" | "EXISTS" | "NOT_EXISTS" | (string & {});
export declare const OperatorType: any;
export type RightExpression = {
    metadataValue: MetadataValue;
};
export declare const RightExpression: any;
export interface EventMetadataFilterExpression {
    left: LeftExpression;
    operator: OperatorType;
    right?: RightExpression;
}
export declare const EventMetadataFilterExpression: S.Schema<EventMetadataFilterExpression>;
export type EventMetadataFilterList = EventMetadataFilterExpression[];
export declare const EventMetadataFilterList: any;
export interface FilterInput {
    branch?: BranchFilter;
    eventMetadata?: EventMetadataFilterExpression[];
}
export declare const FilterInput: S.Schema<FilterInput>;
export interface ListEventsInput {
    memoryId: string;
    sessionId: string;
    actorId: string;
    includePayloads?: boolean;
    filter?: FilterInput;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListEventsInput: S.Schema<ListEventsInput>;
export type EventList = Event[];
export declare const EventList: any;
export interface ListEventsOutput {
    events: Event[];
    nextToken?: string;
}
export declare const ListEventsOutput: S.Schema<ListEventsOutput>;
export type ExtractionJobStatus = "FAILED" | (string & {});
export declare const ExtractionJobStatus: any;
export interface ExtractionJobFilterInput {
    strategyId?: string;
    sessionId?: string;
    actorId?: string;
    status?: ExtractionJobStatus;
}
export declare const ExtractionJobFilterInput: S.Schema<ExtractionJobFilterInput>;
export interface ListMemoryExtractionJobsInput {
    memoryId: string;
    maxResults?: number;
    filter?: ExtractionJobFilterInput;
    nextToken?: string;
}
export declare const ListMemoryExtractionJobsInput: S.Schema<ListMemoryExtractionJobsInput>;
export interface MessageMetadata {
    eventId: string;
    messageIndex: number;
}
export declare const MessageMetadata: S.Schema<MessageMetadata>;
export type MessagesList = MessageMetadata[];
export declare const MessagesList: any;
export type ExtractionJobMessages = {
    messagesList: MessageMetadata[];
};
export declare const ExtractionJobMessages: any;
export interface ExtractionJobMetadata {
    jobID: string;
    messages: ExtractionJobMessages;
    status?: ExtractionJobStatus;
    failureReason?: string;
    strategyId?: string;
    sessionId?: string;
    actorId?: string;
}
export declare const ExtractionJobMetadata: S.Schema<ExtractionJobMetadata>;
export type ExtractionJobMetadataList = ExtractionJobMetadata[];
export declare const ExtractionJobMetadataList: any;
export interface ListMemoryExtractionJobsOutput {
    jobs: ExtractionJobMetadata[];
    nextToken?: string;
}
export declare const ListMemoryExtractionJobsOutput: S.Schema<ListMemoryExtractionJobsOutput>;
export type MemoryRecordLeftExpression = {
    metadataKey: string;
};
export declare const MemoryRecordLeftExpression: any;
export type MemoryRecordOperatorType = "EQUALS_TO" | "EXISTS" | "NOT_EXISTS" | "BEFORE" | "AFTER" | "CONTAINS" | "GREATER_THAN" | "GREATER_THAN_OR_EQUALS" | "LESS_THAN" | "LESS_THAN_OR_EQUALS" | (string & {});
export declare const MemoryRecordOperatorType: any;
export type MemoryRecordRightExpression = {
    metadataValue: MemoryRecordMetadataValue;
};
export declare const MemoryRecordRightExpression: any;
export interface MemoryMetadataFilterExpression {
    left: MemoryRecordLeftExpression;
    operator: MemoryRecordOperatorType;
    right?: MemoryRecordRightExpression;
}
export declare const MemoryMetadataFilterExpression: S.Schema<MemoryMetadataFilterExpression>;
export type MemoryMetadataFilterList = MemoryMetadataFilterExpression[];
export declare const MemoryMetadataFilterList: any;
export interface ListMemoryRecordsInput {
    memoryId: string;
    namespace?: string;
    namespacePath?: string;
    memoryStrategyId?: string;
    maxResults?: number;
    nextToken?: string;
    metadataFilters?: MemoryMetadataFilterExpression[];
}
export declare const ListMemoryRecordsInput: S.Schema<ListMemoryRecordsInput>;
export interface MemoryRecordSummary {
    memoryRecordId: string;
    content: MemoryContent;
    memoryStrategyId?: string;
    namespaces: string[];
    createdAt: Date;
    score?: number;
    metadata?: {
        [key: string]: MemoryRecordMetadataValue | undefined;
    };
}
export declare const MemoryRecordSummary: S.Schema<MemoryRecordSummary>;
export type MemoryRecordSummaryList = MemoryRecordSummary[];
export declare const MemoryRecordSummaryList: any;
export interface ListMemoryRecordsOutput {
    memoryRecordSummaries: MemoryRecordSummary[];
    nextToken?: string;
}
export declare const ListMemoryRecordsOutput: S.Schema<ListMemoryRecordsOutput>;
export interface ListPaymentInstrumentsRequest {
    userId?: string;
    agentName?: string;
    paymentManagerArn: string;
    paymentConnectorId?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPaymentInstrumentsRequest: S.Schema<ListPaymentInstrumentsRequest>;
export interface PaymentInstrumentSummary {
    paymentInstrumentId: string;
    paymentManagerArn: string;
    paymentConnectorId: string;
    userId: string;
    paymentInstrumentType: PaymentInstrumentType;
    status: PaymentInstrumentStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const PaymentInstrumentSummary: S.Schema<PaymentInstrumentSummary>;
export type PaymentInstrumentSummaryList = PaymentInstrumentSummary[];
export declare const PaymentInstrumentSummaryList: any;
export interface ListPaymentInstrumentsResponse {
    paymentInstruments: PaymentInstrumentSummary[];
    nextToken?: string;
}
export declare const ListPaymentInstrumentsResponse: S.Schema<ListPaymentInstrumentsResponse>;
export interface ListPaymentSessionsRequest {
    userId?: string;
    agentName?: string;
    paymentManagerArn: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPaymentSessionsRequest: S.Schema<ListPaymentSessionsRequest>;
export interface PaymentSessionSummary {
    paymentSessionId: string;
    paymentManagerArn: string;
    userId: string;
    expiryTimeInMinutes: number;
    createdAt: Date;
    updatedAt: Date;
}
export declare const PaymentSessionSummary: S.Schema<PaymentSessionSummary>;
export type PaymentSessionSummaryList = PaymentSessionSummary[];
export declare const PaymentSessionSummaryList: any;
export interface ListPaymentSessionsResponse {
    paymentSessions: PaymentSessionSummary[];
    nextToken?: string;
}
export declare const ListPaymentSessionsResponse: S.Schema<ListPaymentSessionsResponse>;
export interface ListRecommendationsRequest {
    maxResults?: number;
    nextToken?: string;
    statusFilter?: RecommendationStatus;
}
export declare const ListRecommendationsRequest: S.Schema<ListRecommendationsRequest>;
export interface RecommendationSummary {
    recommendationId: string;
    recommendationArn: string;
    name: string;
    description?: string;
    type: RecommendationType;
    status: RecommendationStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const RecommendationSummary: S.Schema<RecommendationSummary>;
export type RecommendationSummaryList = RecommendationSummary[];
export declare const RecommendationSummaryList: any;
export interface ListRecommendationsResponse {
    recommendationSummaries: RecommendationSummary[];
    nextToken?: string;
}
export declare const ListRecommendationsResponse: S.Schema<ListRecommendationsResponse>;
export type EventFilterCondition = "HAS_EVENTS" | (string & {});
export declare const EventFilterCondition: any;
export interface SessionFilter {
    eventFilter?: EventFilterCondition;
}
export declare const SessionFilter: S.Schema<SessionFilter>;
export interface ListSessionsInput {
    memoryId: string;
    actorId: string;
    maxResults?: number;
    nextToken?: string;
    filter?: SessionFilter;
}
export declare const ListSessionsInput: S.Schema<ListSessionsInput>;
export interface SessionSummary {
    sessionId: string;
    actorId: string;
    createdAt: Date;
}
export declare const SessionSummary: S.Schema<SessionSummary>;
export type SessionSummaryList = SessionSummary[];
export declare const SessionSummaryList: any;
export interface ListSessionsOutput {
    sessionSummaries: SessionSummary[];
    nextToken?: string;
}
export declare const ListSessionsOutput: S.Schema<ListSessionsOutput>;
export type PaymentType = "CRYPTO_X402" | "MPP" | (string & {});
export declare const PaymentType: any;
export type PaymentDocument = unknown;
export type Permit2AllowanceLimit = string;
export interface CryptoX402PaymentInput {
    version: string;
    payload: any;
    permit2AllowanceLimit?: string;
}
export declare const CryptoX402PaymentInput: S.Schema<CryptoX402PaymentInput>;
export type Version = string;
export type WwwAuthenticateHeader = string;
export type WwwAuthenticateHeaderList = string[];
export declare const WwwAuthenticateHeaderList: any;
export interface MppPaymentInput {
    version: string;
    wwwAuthenticateHeaders: string[];
    buyerPaysGasFees?: boolean;
}
export declare const MppPaymentInput: S.Schema<MppPaymentInput>;
export type PaymentInput = {
    cryptoX402: CryptoX402PaymentInput;
    mpp?: never;
} | {
    cryptoX402?: never;
    mpp: MppPaymentInput;
};
export declare const PaymentInput: any;
export interface ProcessPaymentRequest {
    userId?: string;
    agentName?: string;
    paymentManagerArn: string;
    paymentSessionId: string;
    paymentInstrumentId: string;
    paymentType: PaymentType;
    paymentInput: PaymentInput;
    clientToken?: string;
}
export declare const ProcessPaymentRequest: S.Schema<ProcessPaymentRequest>;
export type ProcessPaymentId = string;
export type PaymentStatus = "PROOF_GENERATED" | (string & {});
export declare const PaymentStatus: any;
export interface CryptoX402PaymentOutput {
    version: string;
    payload: any;
}
export declare const CryptoX402PaymentOutput: S.Schema<CryptoX402PaymentOutput>;
export type MppPaymentCredential = string | redacted.Redacted<string>;
export interface MppPaymentOutput {
    version: string;
    selectedPaymentId: string;
    paymentCredential: string | redacted.Redacted<string>;
}
export declare const MppPaymentOutput: S.Schema<MppPaymentOutput>;
export type PaymentOutput = {
    cryptoX402: CryptoX402PaymentOutput;
    mpp?: never;
} | {
    cryptoX402?: never;
    mpp: MppPaymentOutput;
};
export declare const PaymentOutput: any;
export interface ProcessPaymentResponse {
    processPaymentId: string;
    paymentManagerArn: string;
    paymentSessionId: string;
    paymentInstrumentId: string;
    paymentType: PaymentType;
    status: PaymentStatus;
    paymentOutput: PaymentOutput;
    createdAt: Date;
    updatedAt: Date;
}
export declare const ProcessPaymentResponse: S.Schema<ProcessPaymentResponse>;
export interface SearchCriteria {
    searchQuery: string | redacted.Redacted<string>;
    memoryStrategyId?: string;
    topK?: number;
    metadataFilters?: MemoryMetadataFilterExpression[];
}
export declare const SearchCriteria: S.Schema<SearchCriteria>;
export interface RetrieveMemoryRecordsInput {
    memoryId: string;
    namespace?: string;
    namespacePath?: string;
    searchCriteria: SearchCriteria;
    nextToken?: string;
    maxResults?: number;
}
export declare const RetrieveMemoryRecordsInput: S.Schema<RetrieveMemoryRecordsInput>;
export interface RetrieveMemoryRecordsOutput {
    memoryRecordSummaries: MemoryRecordSummary[];
    nextToken?: string;
}
export declare const RetrieveMemoryRecordsOutput: S.Schema<RetrieveMemoryRecordsOutput>;
export interface SaveBrowserSessionProfileRequest {
    traceId?: string;
    traceParent?: string;
    profileIdentifier: string;
    browserIdentifier: string;
    sessionId: string;
    clientToken?: string;
}
export declare const SaveBrowserSessionProfileRequest: S.Schema<SaveBrowserSessionProfileRequest>;
export interface SaveBrowserSessionProfileResponse {
    profileIdentifier: string;
    browserIdentifier: string;
    sessionId: string;
    lastUpdatedAt: Date;
}
export declare const SaveBrowserSessionProfileResponse: S.Schema<SaveBrowserSessionProfileResponse>;
export type RegistryIdentifier = string;
export type RegistryIdList = string[];
export declare const RegistryIdList: any;
export type MetadataFilterExpression = unknown;
export interface SearchRegistryRecordsRequest {
    searchQuery: string;
    registryIds: string[];
    maxResults?: number;
    filters?: any;
}
export declare const SearchRegistryRecordsRequest: S.Schema<SearchRegistryRecordsRequest>;
export type RegistryArn = string;
export type RegistryRecordArn = string;
export type RegistryRecordId = string;
export type RegistryRecordName = string;
export type Description = string | redacted.Redacted<string>;
export type DescriptorType = "MCP" | "A2A" | "CUSTOM" | "AGENT_SKILLS" | (string & {});
export declare const DescriptorType: any;
export type SchemaVersion = string;
export type InlineContent = string;
export interface ServerDefinition {
    schemaVersion?: string;
    inlineContent?: string;
}
export declare const ServerDefinition: S.Schema<ServerDefinition>;
export interface ToolsDefinition {
    protocolVersion?: string;
    inlineContent?: string;
}
export declare const ToolsDefinition: S.Schema<ToolsDefinition>;
export interface McpDescriptor {
    server: ServerDefinition;
    tools: ToolsDefinition;
}
export declare const McpDescriptor: S.Schema<McpDescriptor>;
export interface AgentCardDefinition {
    schemaVersion?: string;
    inlineContent?: string;
}
export declare const AgentCardDefinition: S.Schema<AgentCardDefinition>;
export interface A2aDescriptor {
    agentCard: AgentCardDefinition;
}
export declare const A2aDescriptor: S.Schema<A2aDescriptor>;
export interface CustomDescriptor {
    inlineContent?: string;
}
export declare const CustomDescriptor: S.Schema<CustomDescriptor>;
export interface SkillMdDefinition {
    inlineContent?: string;
}
export declare const SkillMdDefinition: S.Schema<SkillMdDefinition>;
export interface SkillDefinition {
    schemaVersion?: string;
    inlineContent?: string;
}
export declare const SkillDefinition: S.Schema<SkillDefinition>;
export interface AgentSkillsDescriptor {
    skillMd: SkillMdDefinition;
    skillDefinition?: SkillDefinition;
}
export declare const AgentSkillsDescriptor: S.Schema<AgentSkillsDescriptor>;
export interface Descriptors {
    mcp?: McpDescriptor;
    a2a?: A2aDescriptor;
    custom?: CustomDescriptor;
    agentSkills?: AgentSkillsDescriptor;
}
export declare const Descriptors: S.Schema<Descriptors>;
export type RegistryRecordVersion = string;
export type RegistryRecordStatus = "DRAFT" | "PENDING_APPROVAL" | "APPROVED" | "REJECTED" | "DEPRECATED" | (string & {});
export declare const RegistryRecordStatus: any;
export interface RegistryRecordSummary {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    descriptorType: DescriptorType;
    descriptors: Descriptors;
    version: string;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const RegistryRecordSummary: S.Schema<RegistryRecordSummary>;
export type RegistryRecordSummaryList = RegistryRecordSummary[];
export declare const RegistryRecordSummaryList: any;
export interface SearchRegistryRecordsResponse {
    registryRecords: RegistryRecordSummary[];
}
export declare const SearchRegistryRecordsResponse: S.Schema<SearchRegistryRecordsResponse>;
export type GroundTruthTurnInput = {
    prompt: string;
};
export declare const GroundTruthTurnInput: any;
export interface GroundTruthTurn {
    input?: GroundTruthTurnInput;
    expectedResponse?: EvaluationContent;
}
export declare const GroundTruthTurn: S.Schema<GroundTruthTurn>;
export type GroundTruthTurnList = GroundTruthTurn[];
export declare const GroundTruthTurnList: any;
export interface InlineGroundTruth {
    assertions?: EvaluationContent[];
    expectedTrajectory?: EvaluationExpectedTrajectory;
    turns?: GroundTruthTurn[];
}
export declare const InlineGroundTruth: S.Schema<InlineGroundTruth>;
export type GroundTruthSource = {
    inline: InlineGroundTruth;
};
export declare const GroundTruthSource: any;
export type StringMap = {
    [key: string]: string | undefined;
};
export declare const StringMap: any;
export interface SessionMetadataShape {
    sessionId: string;
    testScenarioId?: string;
    groundTruth?: GroundTruthSource;
    metadata?: {
        [key: string]: string | undefined;
    };
}
export declare const SessionMetadataShape: S.Schema<SessionMetadataShape>;
export type SessionMetadataList = SessionMetadataShape[];
export declare const SessionMetadataList: any;
export type EvaluationMetadata = {
    sessionMetadata: SessionMetadataShape[];
};
export declare const EvaluationMetadata: any;
export interface StartBatchEvaluationRequest {
    batchEvaluationName: string;
    evaluators?: Evaluator[];
    insights?: Insight[];
    dataSourceConfig: DataSourceConfig;
    clientToken?: string;
    evaluationMetadata?: EvaluationMetadata;
    tags?: {
        [key: string]: string | undefined;
    };
    kmsKeyArn?: string;
    description?: string;
}
export declare const StartBatchEvaluationRequest: S.Schema<StartBatchEvaluationRequest>;
export interface StartBatchEvaluationResponse {
    batchEvaluationId: string;
    batchEvaluationArn: string;
    batchEvaluationName: string;
    evaluators?: Evaluator[];
    insights?: Insight[];
    status: BatchEvaluationStatus;
    createdAt: Date;
    outputConfig?: OutputConfig;
    tags?: {
        [key: string]: string | undefined;
    };
    kmsKeyArn?: string;
    description?: string;
}
export declare const StartBatchEvaluationResponse: S.Schema<StartBatchEvaluationResponse>;
export interface StartBrowserSessionRequest {
    traceId?: string;
    traceParent?: string;
    browserIdentifier: string;
    name?: string;
    sessionTimeoutSeconds?: number;
    viewPort?: ViewPort;
    extensions?: BrowserExtension[];
    profileConfiguration?: BrowserProfileConfiguration;
    proxyConfiguration?: ProxyConfiguration;
    enterprisePolicies?: BrowserEnterprisePolicy[];
    certificates?: Certificate[];
    filesystemConfigurations?: ToolsFileSystemConfiguration[];
    clientToken?: string;
}
export declare const StartBrowserSessionRequest: S.Schema<StartBrowserSessionRequest>;
export interface StartBrowserSessionResponse {
    browserIdentifier: string;
    sessionId: string;
    createdAt: Date;
    streams?: BrowserSessionStream;
}
export declare const StartBrowserSessionResponse: S.Schema<StartBrowserSessionResponse>;
export interface StartCodeInterpreterSessionRequest {
    traceId?: string;
    traceParent?: string;
    codeInterpreterIdentifier: string;
    name?: string;
    sessionTimeoutSeconds?: number;
    certificates?: Certificate[];
    filesystemConfigurations?: ToolsFileSystemConfiguration[];
    clientToken?: string;
}
export declare const StartCodeInterpreterSessionRequest: S.Schema<StartCodeInterpreterSessionRequest>;
export interface StartCodeInterpreterSessionResponse {
    codeInterpreterIdentifier: string;
    sessionId: string;
    createdAt: Date;
}
export declare const StartCodeInterpreterSessionResponse: S.Schema<StartCodeInterpreterSessionResponse>;
export interface ExtractionJob {
    jobId: string;
}
export declare const ExtractionJob: S.Schema<ExtractionJob>;
export interface StartMemoryExtractionJobInput {
    memoryId: string;
    extractionJob: ExtractionJob;
    clientToken?: string;
}
export declare const StartMemoryExtractionJobInput: S.Schema<StartMemoryExtractionJobInput>;
export interface StartMemoryExtractionJobOutput {
    jobId: string;
}
export declare const StartMemoryExtractionJobOutput: S.Schema<StartMemoryExtractionJobOutput>;
export interface StartRecommendationRequest {
    name: string;
    description?: string;
    type: RecommendationType;
    recommendationConfig: RecommendationConfig;
    kmsKeyArn?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StartRecommendationRequest: S.Schema<StartRecommendationRequest>;
export interface StartRecommendationResponse {
    recommendationId: string;
    recommendationArn: string;
    name: string;
    description?: string;
    type: RecommendationType;
    recommendationConfig: RecommendationConfig;
    status: RecommendationStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const StartRecommendationResponse: S.Schema<StartRecommendationResponse>;
export interface StopBatchEvaluationRequest {
    batchEvaluationId: string;
}
export declare const StopBatchEvaluationRequest: S.Schema<StopBatchEvaluationRequest>;
export interface StopBatchEvaluationResponse {
    batchEvaluationId: string;
    batchEvaluationArn: string;
    status: BatchEvaluationStatus;
    description?: string;
}
export declare const StopBatchEvaluationResponse: S.Schema<StopBatchEvaluationResponse>;
export interface StopBrowserSessionRequest {
    traceId?: string;
    traceParent?: string;
    browserIdentifier: string;
    sessionId: string;
    clientToken?: string;
}
export declare const StopBrowserSessionRequest: S.Schema<StopBrowserSessionRequest>;
export interface StopBrowserSessionResponse {
    browserIdentifier: string;
    sessionId: string;
    lastUpdatedAt: Date;
}
export declare const StopBrowserSessionResponse: S.Schema<StopBrowserSessionResponse>;
export interface StopCodeInterpreterSessionRequest {
    traceId?: string;
    traceParent?: string;
    codeInterpreterIdentifier: string;
    sessionId: string;
    clientToken?: string;
}
export declare const StopCodeInterpreterSessionRequest: S.Schema<StopCodeInterpreterSessionRequest>;
export interface StopCodeInterpreterSessionResponse {
    codeInterpreterIdentifier: string;
    sessionId: string;
    lastUpdatedAt: Date;
}
export declare const StopCodeInterpreterSessionResponse: S.Schema<StopCodeInterpreterSessionResponse>;
export interface StopRuntimeSessionRequest {
    runtimeSessionId: string;
    agentRuntimeArn: string;
    qualifier?: string;
    clientToken?: string;
}
export declare const StopRuntimeSessionRequest: S.Schema<StopRuntimeSessionRequest>;
export interface StopRuntimeSessionResponse {
    runtimeSessionId?: string;
    statusCode?: number;
}
export declare const StopRuntimeSessionResponse: S.Schema<StopRuntimeSessionResponse>;
export interface UpdateABTestRequest {
    abTestId: string;
    clientToken?: string;
    name?: string;
    description?: string;
    variants?: Variant[];
    gatewayFilter?: GatewayFilter;
    evaluationConfig?: ABTestEvaluationConfig;
    roleArn?: string;
    executionStatus?: ABTestExecutionStatus;
}
export declare const UpdateABTestRequest: S.Schema<UpdateABTestRequest>;
export interface UpdateABTestResponse {
    abTestId: string;
    abTestArn: string;
    status: ABTestStatus;
    executionStatus: ABTestExecutionStatus;
    updatedAt: Date;
}
export declare const UpdateABTestResponse: S.Schema<UpdateABTestResponse>;
export interface AutomationStreamUpdate {
    streamStatus?: AutomationStreamStatus;
}
export declare const AutomationStreamUpdate: S.Schema<AutomationStreamUpdate>;
export type StreamUpdate = {
    automationStreamUpdate: AutomationStreamUpdate;
};
export declare const StreamUpdate: any;
export interface UpdateBrowserStreamRequest {
    browserIdentifier: string;
    sessionId: string;
    streamUpdate: StreamUpdate;
    clientToken?: string;
}
export declare const UpdateBrowserStreamRequest: S.Schema<UpdateBrowserStreamRequest>;
export interface UpdateBrowserStreamResponse {
    browserIdentifier: string;
    sessionId: string;
    streams: BrowserSessionStream;
    updatedAt: Date;
}
export declare const UpdateBrowserStreamResponse: S.Schema<UpdateBrowserStreamResponse>;
export type BatchCreateMemoryRecordsError = AccessDeniedException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Creates multiple memory records in a single batch operation for the specified memory with custom content.
 */
export declare const batchCreateMemoryRecords: API.OperationMethod<BatchCreateMemoryRecordsInput, BatchCreateMemoryRecordsOutput, BatchCreateMemoryRecordsError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteMemoryRecordsError = AccessDeniedException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Deletes multiple memory records in a single batch operation from the specified memory.
 */
export declare const batchDeleteMemoryRecords: API.OperationMethod<BatchDeleteMemoryRecordsInput, BatchDeleteMemoryRecordsOutput, BatchDeleteMemoryRecordsError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateMemoryRecordsError = AccessDeniedException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Updates multiple memory records with custom content in a single batch operation within the specified memory.
 */
export declare const batchUpdateMemoryRecords: API.OperationMethod<BatchUpdateMemoryRecordsInput, BatchUpdateMemoryRecordsOutput, BatchUpdateMemoryRecordsError, Credentials | HttpClient.HttpClient>;
export type CompleteResourceTokenAuthError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Confirms the user authentication session for obtaining OAuth2.0 tokens for a resource.
 */
export declare const completeResourceTokenAuth: API.OperationMethod<CompleteResourceTokenAuthRequest, CompleteResourceTokenAuthResponse, CompleteResourceTokenAuthError, Credentials | HttpClient.HttpClient>;
export type CreateABTestError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates an A/B test for comparing agent configurations. A/B tests split traffic between a control variant and a treatment variant through a gateway, then evaluate performance using online evaluation configurations to determine which variant performs better.
 */
export declare const createABTest: API.OperationMethod<CreateABTestRequest, CreateABTestResponse, CreateABTestError, Credentials | HttpClient.HttpClient>;
export type CreateEventError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | RetryableConflictException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Creates an event in an AgentCore Memory resource. Events represent interactions or activities that occur within a session and are associated with specific actors.
 *
 * To use this operation, you must have the `bedrock-agentcore:CreateEvent` permission.
 *
 * This operation is subject to request rate limiting.
 */
export declare const createEvent: API.OperationMethod<CreateEventInput, CreateEventOutput, CreateEventError, Credentials | HttpClient.HttpClient>;
export type CreatePaymentInstrumentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | SubscriptionRequiredException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a new payment instrument for a connector.
 */
export declare const createPaymentInstrument: API.OperationMethod<CreatePaymentInstrumentRequest, CreatePaymentInstrumentResponse, CreatePaymentInstrumentError, Credentials | HttpClient.HttpClient>;
export type CreatePaymentSessionError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | SubscriptionRequiredException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a new payment session.
 */
export declare const createPaymentSession: API.OperationMethod<CreatePaymentSessionRequest, CreatePaymentSessionResponse, CreatePaymentSessionError, Credentials | HttpClient.HttpClient>;
export type DeleteABTestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes an A/B test and its associated gateway rules.
 */
export declare const deleteABTest: API.OperationMethod<DeleteABTestRequest, DeleteABTestResponse, DeleteABTestError, Credentials | HttpClient.HttpClient>;
export type DeleteBatchEvaluationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes a batch evaluation and its associated results.
 */
export declare const deleteBatchEvaluation: API.OperationMethod<DeleteBatchEvaluationRequest, DeleteBatchEvaluationResponse, DeleteBatchEvaluationError, Credentials | HttpClient.HttpClient>;
export type DeleteCapacityProviderSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a session associated with a capacity provider in Amazon Bedrock AgentCore and makes the session unavailable for further use. To delete a capacity provider session, specify both the capacity provider identifier and the session ID. After you delete a session, you cannot restart it.
 */
export declare const deleteCapacityProviderSession: API.OperationMethod<DeleteCapacityProviderSessionRequest, DeleteCapacityProviderSessionResponse, DeleteCapacityProviderSessionError, Credentials | HttpClient.HttpClient>;
export type DeleteEventError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Deletes an event from an AgentCore Memory resource. When you delete an event, it is permanently removed.
 *
 * To use this operation, you must have the `bedrock-agentcore:DeleteEvent` permission.
 */
export declare const deleteEvent: API.OperationMethod<DeleteEventInput, DeleteEventOutput, DeleteEventError, Credentials | HttpClient.HttpClient>;
export type DeleteMemoryRecordError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Deletes a memory record from an AgentCore Memory resource. When you delete a memory record, it is permanently removed.
 *
 * To use this operation, you must have the `bedrock-agentcore:DeleteMemoryRecord` permission.
 */
export declare const deleteMemoryRecord: API.OperationMethod<DeleteMemoryRecordInput, DeleteMemoryRecordOutput, DeleteMemoryRecordError, Credentials | HttpClient.HttpClient>;
export type DeletePaymentInstrumentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a payment instrument. This is a soft delete operation that preserves the record for audit and compliance purposes.
 */
export declare const deletePaymentInstrument: API.OperationMethod<DeletePaymentInstrumentRequest, DeletePaymentInstrumentResponse, DeletePaymentInstrumentError, Credentials | HttpClient.HttpClient>;
export type DeletePaymentSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a payment session. This permanently removes the payment session record.
 */
export declare const deletePaymentSession: API.OperationMethod<DeletePaymentSessionRequest, DeletePaymentSessionResponse, DeletePaymentSessionError, Credentials | HttpClient.HttpClient>;
export type DeleteRecommendationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a recommendation and its associated results.
 */
export declare const deleteRecommendation: API.OperationMethod<DeleteRecommendationRequest, DeleteRecommendationResponse, DeleteRecommendationError, Credentials | HttpClient.HttpClient>;
export type EvaluateError = AccessDeniedException | ConflictException | DuplicateIdException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Performs on-demand evaluation of agent traces using a specified evaluator. This synchronous API accepts traces in OpenTelemetry format and returns immediate scoring results with detailed explanations.
 */
export declare const evaluate: API.OperationMethod<EvaluateRequest, EvaluateResponse, EvaluateError, Credentials | HttpClient.HttpClient>;
export type GetABTestError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about an A/B test, including its configuration, status, and statistical results.
 */
export declare const getABTest: API.OperationMethod<GetABTestRequest, GetABTestResponse, GetABTestError, Credentials | HttpClient.HttpClient>;
export type GetAgentCardError = AccessDeniedException | InternalServerException | ResourceNotFoundException | RetryableConflictException | RuntimeClientError | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the A2A agent card associated with an AgentCore Runtime agent.
 */
export declare const getAgentCard: API.OperationMethod<GetAgentCardRequest, GetAgentCardResponse, GetAgentCardError, Credentials | HttpClient.HttpClient>;
export type GetBatchEvaluationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a batch evaluation, including its status, configuration, results, and any error details.
 */
export declare const getBatchEvaluation: API.OperationMethod<GetBatchEvaluationRequest, GetBatchEvaluationResponse, GetBatchEvaluationError, Credentials | HttpClient.HttpClient>;
export type GetBrowserSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific browser session in Amazon Bedrock AgentCore. This operation returns the session's configuration, current status, associated streams, and metadata.
 *
 * To get a browser session, you must specify both the browser identifier and the session ID. The response includes information about the session's viewport configuration, timeout settings, and stream endpoints.
 *
 * The following operations are related to `GetBrowserSession`:
 *
 * - StartBrowserSession
 *
 * - ListBrowserSessions
 *
 * - StopBrowserSession
 */
export declare const getBrowserSession: API.OperationMethod<GetBrowserSessionRequest, GetBrowserSessionResponse, GetBrowserSessionError, Credentials | HttpClient.HttpClient>;
export type GetCodeInterpreterSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific code interpreter session in Amazon Bedrock AgentCore. This operation returns the session's configuration, current status, and metadata.
 *
 * To get a code interpreter session, you must specify both the code interpreter identifier and the session ID. The response includes information about the session's timeout settings and current status.
 *
 * The following operations are related to `GetCodeInterpreterSession`:
 *
 * - StartCodeInterpreterSession
 *
 * - ListCodeInterpreterSessions
 *
 * - StopCodeInterpreterSession
 */
export declare const getCodeInterpreterSession: API.OperationMethod<GetCodeInterpreterSessionRequest, GetCodeInterpreterSessionResponse, GetCodeInterpreterSessionError, Credentials | HttpClient.HttpClient>;
export type GetEventError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific event in an AgentCore Memory resource.
 *
 * To use this operation, you must have the `bedrock-agentcore:GetEvent` permission.
 */
export declare const getEvent: API.OperationMethod<GetEventInput, GetEventOutput, GetEventError, Credentials | HttpClient.HttpClient>;
export type GetMemoryRecordError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Retrieves a specific memory record from an AgentCore Memory resource.
 *
 * To use this operation, you must have the `bedrock-agentcore:GetMemoryRecord` permission.
 */
export declare const getMemoryRecord: API.OperationMethod<GetMemoryRecordInput, GetMemoryRecordOutput, GetMemoryRecordError, Credentials | HttpClient.HttpClient>;
export type GetPaymentInstrumentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a payment instrument by ID.
 */
export declare const getPaymentInstrument: API.OperationMethod<GetPaymentInstrumentRequest, GetPaymentInstrumentResponse, GetPaymentInstrumentError, Credentials | HttpClient.HttpClient>;
export type GetPaymentInstrumentBalanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the balance of a payment instrument.
 */
export declare const getPaymentInstrumentBalance: API.OperationMethod<GetPaymentInstrumentBalanceRequest, GetPaymentInstrumentBalanceResponse, GetPaymentInstrumentBalanceError, Credentials | HttpClient.HttpClient>;
export type GetPaymentSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a payment session.
 */
export declare const getPaymentSession: API.OperationMethod<GetPaymentSessionRequest, GetPaymentSessionResponse, GetPaymentSessionError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a recommendation, including its configuration, status, and results.
 */
export declare const getRecommendation: API.OperationMethod<GetRecommendationRequest, GetRecommendationResponse, GetRecommendationError, Credentials | HttpClient.HttpClient>;
export type GetResourceApiKeyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves the API key associated with an API key credential provider.
 */
export declare const getResourceApiKey: API.OperationMethod<GetResourceApiKeyRequest, GetResourceApiKeyResponse, GetResourceApiKeyError, Credentials | HttpClient.HttpClient>;
export type GetResourceOauth2TokenError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Returns the OAuth 2.0 token of the provided resource.
 */
export declare const getResourceOauth2Token: API.OperationMethod<GetResourceOauth2TokenRequest, GetResourceOauth2TokenResponse, GetResourceOauth2TokenError, Credentials | HttpClient.HttpClient>;
export type GetResourcePaymentTokenError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Generates authentication tokens for payment providers that use vendor-specific authentication mechanisms.
 */
export declare const getResourcePaymentToken: API.OperationMethod<GetResourcePaymentTokenRequest, GetResourcePaymentTokenResponse, GetResourcePaymentTokenError, Credentials | HttpClient.HttpClient>;
export type GetWorkloadAccessTokenError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Obtains a workload access token for agentic workloads not acting on behalf of a user.
 */
export declare const getWorkloadAccessToken: API.OperationMethod<GetWorkloadAccessTokenRequest, GetWorkloadAccessTokenResponse, GetWorkloadAccessTokenError, Credentials | HttpClient.HttpClient>;
export type GetWorkloadAccessTokenForJWTError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Obtains a workload access token for agentic workloads acting on behalf of a user, using a JWT token.
 */
export declare const getWorkloadAccessTokenForJWT: API.OperationMethod<GetWorkloadAccessTokenForJWTRequest, GetWorkloadAccessTokenForJWTResponse, GetWorkloadAccessTokenForJWTError, Credentials | HttpClient.HttpClient>;
export type GetWorkloadAccessTokenForUserIdError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Obtains a workload access token for agentic workloads acting on behalf of a user, using the user's ID.
 */
export declare const getWorkloadAccessTokenForUserId: API.OperationMethod<GetWorkloadAccessTokenForUserIdRequest, GetWorkloadAccessTokenForUserIdResponse, GetWorkloadAccessTokenForUserIdError, Credentials | HttpClient.HttpClient>;
export type IngestDataError = AccessDeniedException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Submits content directly for ingestion to generate long-term memory records in a AgentCore Memory resource.
 *
 * To use this operation, you must have the `bedrock-agentcore:IngestData` permission.
 */
export declare const ingestData: API.OperationMethod<IngestDataInput, IngestDataOutput, IngestDataError, Credentials | HttpClient.HttpClient>;
export type InvokeAgentRuntimeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | RetryableConflictException | RuntimeClientError | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends a request to an agent or tool hosted in an Amazon Bedrock AgentCore Runtime and receives responses in real-time.
 *
 * To invoke an agent, you can specify either the AgentCore Runtime ARN or the agent ID with an account ID, and provide a payload containing your request. When you use the agent ID instead of the full ARN, you don't need to URL-encode the identifier. You can optionally specify a qualifier to target a specific endpoint of the agent.
 *
 * This operation supports streaming responses, allowing you to receive partial responses as they become available. We recommend using pagination to ensure that the operation returns quickly and successfully when processing large responses.
 *
 * For example code, see Invoke an AgentCore Runtime agent.
 *
 * If you're integrating your agent with OAuth, you can't use the Amazon Web Services SDK to call `InvokeAgentRuntime`. Instead, make a HTTPS request to `InvokeAgentRuntime`. For an example, see Authenticate and authorize with Inbound Auth and Outbound Auth.
 *
 * To use this operation, you must have the `bedrock-agentcore:InvokeAgentRuntime` permission. If you are making a call to `InvokeAgentRuntime` on behalf of a user ID with the `X-Amzn-Bedrock-AgentCore-Runtime-User-Id` header, You require permissions to both actions (`bedrock-agentcore:InvokeAgentRuntime` and `bedrock-agentcore:InvokeAgentRuntimeForUser`).
 */
export declare const invokeAgentRuntime: API.OperationMethod<InvokeAgentRuntimeRequest, InvokeAgentRuntimeResponse, InvokeAgentRuntimeError, Credentials | HttpClient.HttpClient>;
export type InvokeAgentRuntimeCommandError = AccessDeniedException | InternalServerException | ResourceNotFoundException | RetryableConflictException | RuntimeClientError | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Executes a command in a runtime session container and streams the output back to the caller. This operation allows you to run shell commands within the agent runtime environment and receive real-time streaming responses including standard output and standard error.
 *
 * To invoke a command, you must specify the agent runtime ARN and a runtime session ID. The command execution supports streaming responses, allowing you to receive output as it becomes available through `contentStart`, `contentDelta`, and `contentStop` events.
 *
 * To use this operation, you must have the `bedrock-agentcore:InvokeAgentRuntimeCommand` permission.
 */
export declare const invokeAgentRuntimeCommand: API.OperationMethod<InvokeAgentRuntimeCommandRequest, InvokeAgentRuntimeCommandResponse, InvokeAgentRuntimeCommandError, Credentials | HttpClient.HttpClient>;
export type InvokeBrowserError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invokes an operating system-level action on a browser session in Amazon Bedrock AgentCore. This operation provides direct OS-level control over browser sessions, enabling mouse actions, keyboard input, and screenshots that the WebSocket-based Chrome DevTools Protocol (CDP) cannot handle — such as interacting with print dialogs, context menus, and JavaScript alerts.
 *
 * You send a request with exactly one action in the `BrowserAction` union, and receive a corresponding result in the `BrowserActionResult` union.
 *
 * The following operations are related to `InvokeBrowser`:
 *
 * - StartBrowserSession
 *
 * - GetBrowserSession
 *
 * - StopBrowserSession
 */
export declare const invokeBrowser: API.OperationMethod<InvokeBrowserRequest, InvokeBrowserResponse, InvokeBrowserError, Credentials | HttpClient.HttpClient>;
export type InvokeCodeInterpreterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Executes code within an active code interpreter session in Amazon Bedrock AgentCore. This operation processes the provided code, runs it in a secure environment, and returns the execution results including output, errors, and generated visualizations.
 *
 * To execute code, you must specify the code interpreter identifier, session ID, and the code to run in the arguments parameter. The operation returns a stream containing the execution results, which can include text output, error messages, and data visualizations.
 *
 * This operation is subject to request rate limiting based on your account's service quotas.
 *
 * The following operations are related to `InvokeCodeInterpreter`:
 *
 * - StartCodeInterpreterSession
 *
 * - GetCodeInterpreterSession
 */
export declare const invokeCodeInterpreter: API.OperationMethod<InvokeCodeInterpreterRequest, InvokeCodeInterpreterResponse, InvokeCodeInterpreterError, Credentials | HttpClient.HttpClient>;
export type InvokeHarnessError = AccessDeniedException | InternalServerException | ResourceNotFoundException | RuntimeClientError | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Operation to invoke a Harness.
 */
export declare const invokeHarness: API.OperationMethod<InvokeHarnessRequest, InvokeHarnessResponse, InvokeHarnessError, Credentials | HttpClient.HttpClient>;
export type ListABTestsError = AccessDeniedException | InternalServerException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all A/B tests in the account.
 */
export declare const listABTests: API.PaginatedOperationMethod<ListABTestsRequest, ListABTestsResponse, ListABTestsError, Credentials | HttpClient.HttpClient, ABTestSummary>;
export type ListActorsError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Lists all actors in an AgentCore Memory resource. We recommend using pagination to ensure that the operation returns quickly and successfully.
 *
 * To use this operation, you must have the `bedrock-agentcore:ListActors` permission.
 */
export declare const listActors: API.PaginatedOperationMethod<ListActorsInput, ListActorsOutput, ListActorsError, Credentials | HttpClient.HttpClient, ActorSummary>;
export type ListBatchEvaluationsError = AccessDeniedException | InternalServerException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all batch evaluations in the account, providing summary information about each evaluation's status and configuration.
 */
export declare const listBatchEvaluations: API.PaginatedOperationMethod<ListBatchEvaluationsRequest, ListBatchEvaluationsResponse, ListBatchEvaluationsError, Credentials | HttpClient.HttpClient, BatchEvaluationSummary>;
export type ListBrowserSessionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of browser sessions in Amazon Bedrock AgentCore that match the specified criteria. This operation returns summary information about each session, including identifiers, status, and timestamps.
 *
 * You can filter the results by browser identifier and session status. The operation supports pagination to handle large result sets efficiently.
 *
 * We recommend using pagination to ensure that the operation returns quickly and successfully when retrieving large numbers of sessions.
 *
 * The following operations are related to `ListBrowserSessions`:
 *
 * - StartBrowserSession
 *
 * - GetBrowserSession
 */
export declare const listBrowserSessions: API.OperationMethod<ListBrowserSessionsRequest, ListBrowserSessionsResponse, ListBrowserSessionsError, Credentials | HttpClient.HttpClient>;
export type ListCodeInterpreterSessionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of code interpreter sessions in Amazon Bedrock AgentCore that match the specified criteria. This operation returns summary information about each session, including identifiers, status, and timestamps.
 *
 * You can filter the results by code interpreter identifier and session status. The operation supports pagination to handle large result sets efficiently.
 *
 * We recommend using pagination to ensure that the operation returns quickly and successfully when retrieving large numbers of sessions.
 *
 * The following operations are related to `ListCodeInterpreterSessions`:
 *
 * - StartCodeInterpreterSession
 *
 * - GetCodeInterpreterSession
 */
export declare const listCodeInterpreterSessions: API.OperationMethod<ListCodeInterpreterSessionsRequest, ListCodeInterpreterSessionsResponse, ListCodeInterpreterSessionsError, Credentials | HttpClient.HttpClient>;
export type ListEventsError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Lists events in an AgentCore Memory resource based on specified criteria. We recommend using pagination to ensure that the operation returns quickly and successfully.
 *
 * To use this operation, you must have the `bedrock-agentcore:ListEvents` permission.
 */
export declare const listEvents: API.PaginatedOperationMethod<ListEventsInput, ListEventsOutput, ListEventsError, Credentials | HttpClient.HttpClient, Event>;
export type ListMemoryExtractionJobsError = AccessDeniedException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Lists all long-term memory extraction jobs that are eligible to be started with optional filtering.
 *
 * To use this operation, you must have the `bedrock-agentcore:ListMemoryExtractionJobs` permission.
 */
export declare const listMemoryExtractionJobs: API.PaginatedOperationMethod<ListMemoryExtractionJobsInput, ListMemoryExtractionJobsOutput, ListMemoryExtractionJobsError, Credentials | HttpClient.HttpClient, ExtractionJobMetadata>;
export type ListMemoryRecordsError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Lists memory records in an AgentCore Memory resource based on specified criteria. We recommend using pagination to ensure that the operation returns quickly and successfully.
 *
 * To use this operation, you must have the `bedrock-agentcore:ListMemoryRecords` permission.
 */
export declare const listMemoryRecords: API.PaginatedOperationMethod<ListMemoryRecordsInput, ListMemoryRecordsOutput, ListMemoryRecordsError, Credentials | HttpClient.HttpClient, MemoryRecordSummary>;
export type ListPaymentInstrumentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List payment instruments for a manager.
 */
export declare const listPaymentInstruments: API.PaginatedOperationMethod<ListPaymentInstrumentsRequest, ListPaymentInstrumentsResponse, ListPaymentInstrumentsError, Credentials | HttpClient.HttpClient, PaymentInstrumentSummary>;
export type ListPaymentSessionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List payment sessions.
 */
export declare const listPaymentSessions: API.PaginatedOperationMethod<ListPaymentSessionsRequest, ListPaymentSessionsResponse, ListPaymentSessionsError, Credentials | HttpClient.HttpClient, PaymentSessionSummary>;
export type ListRecommendationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all recommendations in the account, with optional filtering by status.
 */
export declare const listRecommendations: API.PaginatedOperationMethod<ListRecommendationsRequest, ListRecommendationsResponse, ListRecommendationsError, Credentials | HttpClient.HttpClient, RecommendationSummary>;
export type ListSessionsError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Lists sessions in an AgentCore Memory resource based on specified criteria. We recommend using pagination to ensure that the operation returns quickly and successfully.
 *
 * Empty sessions are automatically deleted after one day.
 *
 * To use this operation, you must have the `bedrock-agentcore:ListSessions` permission.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsInput, ListSessionsOutput, ListSessionsError, Credentials | HttpClient.HttpClient, SessionSummary>;
export type ProcessPaymentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | SubscriptionRequiredException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Processes a payment using a payment instrument within a payment session.
 */
export declare const processPayment: API.OperationMethod<ProcessPaymentRequest, ProcessPaymentResponse, ProcessPaymentError, Credentials | HttpClient.HttpClient>;
export type RetrieveMemoryRecordsError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Searches for and retrieves memory records from an AgentCore Memory resource based on specified search criteria. We recommend using pagination to ensure that the operation returns quickly and successfully.
 *
 * To use this operation, you must have the `bedrock-agentcore:RetrieveMemoryRecords` permission.
 */
export declare const retrieveMemoryRecords: API.PaginatedOperationMethod<RetrieveMemoryRecordsInput, RetrieveMemoryRecordsOutput, RetrieveMemoryRecordsError, Credentials | HttpClient.HttpClient, MemoryRecordSummary>;
export type SaveBrowserSessionProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Saves the current state of a browser session as a reusable profile in Amazon Bedrock AgentCore. A browser profile captures persistent browser data such as cookies and local storage from an active session, enabling you to reuse this data in future browser sessions.
 *
 * To save a browser session profile, you must specify the profile identifier, browser identifier, and session ID. The session must be active when saving the profile. Once saved, the profile can be used with the `StartBrowserSession` operation to initialize new sessions with the stored browser state.
 *
 * Browser profiles are useful for scenarios that require persistent authentication, maintaining user preferences across sessions, or continuing tasks that depend on previously stored browser data.
 *
 * The following operations are related to `SaveBrowserSessionProfile`:
 *
 * - StartBrowserSession
 *
 * - GetBrowserSession
 */
export declare const saveBrowserSessionProfile: API.OperationMethod<SaveBrowserSessionProfileRequest, SaveBrowserSessionProfileResponse, SaveBrowserSessionProfileError, Credentials | HttpClient.HttpClient>;
export type SearchRegistryRecordsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Searches for registry records using semantic, lexical, or hybrid queries. Returns metadata for matching records ordered by relevance within the specified registry.
 */
export declare const searchRegistryRecords: API.OperationMethod<SearchRegistryRecordsRequest, SearchRegistryRecordsResponse, SearchRegistryRecordsError, Credentials | HttpClient.HttpClient>;
export type StartBatchEvaluationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Starts a batch evaluation job that evaluates agent performance across multiple sessions. Batch evaluations pull agent traces from CloudWatch Logs or an existing online evaluation configuration and run specified evaluators and insights against them.
 */
export declare const startBatchEvaluation: API.OperationMethod<StartBatchEvaluationRequest, StartBatchEvaluationResponse, StartBatchEvaluationError, Credentials | HttpClient.HttpClient>;
export type StartBrowserSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates and initializes a browser session in Amazon Bedrock AgentCore. The session enables agents to navigate and interact with web content, extract information from websites, and perform web-based tasks as part of their response generation.
 *
 * To create a session, you must specify a browser identifier and a name. You can also configure the viewport dimensions to control the visible area of web content. The session remains active until it times out or you explicitly stop it using the `StopBrowserSession` operation.
 *
 * The following operations are related to `StartBrowserSession`:
 *
 * - GetBrowserSession
 *
 * - UpdateBrowserStream
 *
 * - SaveBrowserSessionProfile
 *
 * - StopBrowserSession
 *
 * - InvokeBrowser
 */
export declare const startBrowserSession: API.OperationMethod<StartBrowserSessionRequest, StartBrowserSessionResponse, StartBrowserSessionError, Credentials | HttpClient.HttpClient>;
export type StartCodeInterpreterSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates and initializes a code interpreter session in Amazon Bedrock AgentCore. The session enables agents to execute code as part of their response generation, supporting programming languages such as Python for data analysis, visualization, and computation tasks.
 *
 * To create a session, you must specify a code interpreter identifier and a name. The session remains active until it times out or you explicitly stop it using the `StopCodeInterpreterSession` operation.
 *
 * The following operations are related to `StartCodeInterpreterSession`:
 *
 * - InvokeCodeInterpreter
 *
 * - GetCodeInterpreterSession
 *
 * - StopCodeInterpreterSession
 */
export declare const startCodeInterpreterSession: API.OperationMethod<StartCodeInterpreterSessionRequest, StartCodeInterpreterSessionResponse, StartCodeInterpreterSessionError, Credentials | HttpClient.HttpClient>;
export type StartMemoryExtractionJobError = AccessDeniedException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Starts a memory extraction job that processes events that failed extraction previously in an AgentCore Memory resource and produces structured memory records. When earlier extraction attempts have left events unprocessed, this job will pick up and extract those as well.
 *
 * To use this operation, you must have the `bedrock-agentcore:StartMemoryExtractionJob` permission.
 */
export declare const startMemoryExtractionJob: API.OperationMethod<StartMemoryExtractionJobInput, StartMemoryExtractionJobOutput, StartMemoryExtractionJobError, Credentials | HttpClient.HttpClient>;
export type StartRecommendationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a recommendation job that analyzes agent traces and generates optimization suggestions for system prompts or tool descriptions to improve agent performance.
 */
export declare const startRecommendation: API.OperationMethod<StartRecommendationRequest, StartRecommendationResponse, StartRecommendationError, Credentials | HttpClient.HttpClient>;
export type StopBatchEvaluationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Stops a running batch evaluation. Sessions that have already been evaluated retain their results.
 */
export declare const stopBatchEvaluation: API.OperationMethod<StopBatchEvaluationRequest, StopBatchEvaluationResponse, StopBatchEvaluationError, Credentials | HttpClient.HttpClient>;
export type StopBrowserSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Terminates an active browser session in Amazon Bedrock AgentCore. This operation stops the session, releases associated resources, and makes the session unavailable for further use.
 *
 * To stop a browser session, you must specify both the browser identifier and the session ID. Once stopped, a session cannot be restarted; you must create a new session using `StartBrowserSession`.
 *
 * The following operations are related to `StopBrowserSession`:
 *
 * - StartBrowserSession
 *
 * - GetBrowserSession
 */
export declare const stopBrowserSession: API.OperationMethod<StopBrowserSessionRequest, StopBrowserSessionResponse, StopBrowserSessionError, Credentials | HttpClient.HttpClient>;
export type StopCodeInterpreterSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Terminates an active code interpreter session in Amazon Bedrock AgentCore. This operation stops the session, releases associated resources, and makes the session unavailable for further use.
 *
 * To stop a code interpreter session, you must specify both the code interpreter identifier and the session ID. Once stopped, a session cannot be restarted; you must create a new session using `StartCodeInterpreterSession`.
 *
 * The following operations are related to `StopCodeInterpreterSession`:
 *
 * - StartCodeInterpreterSession
 *
 * - GetCodeInterpreterSession
 */
export declare const stopCodeInterpreterSession: API.OperationMethod<StopCodeInterpreterSessionRequest, StopCodeInterpreterSessionResponse, StopCodeInterpreterSessionError, Credentials | HttpClient.HttpClient>;
export type StopRuntimeSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | RetryableConflictException | RuntimeClientError | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Stops a session that is running in an running AgentCore Runtime agent.
 */
export declare const stopRuntimeSession: API.OperationMethod<StopRuntimeSessionRequest, StopRuntimeSessionResponse, StopRuntimeSessionError, Credentials | HttpClient.HttpClient>;
export type UpdateABTestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates an A/B test's configuration, including variants, traffic allocation, evaluation settings, or execution status.
 */
export declare const updateABTest: API.OperationMethod<UpdateABTestRequest, UpdateABTestResponse, UpdateABTestError, Credentials | HttpClient.HttpClient>;
export type UpdateBrowserStreamError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a browser stream. To use this operation, you must have permissions to perform the bedrock:UpdateBrowserStream action.
 */
export declare const updateBrowserStream: API.OperationMethod<UpdateBrowserStreamRequest, UpdateBrowserStreamResponse, UpdateBrowserStreamError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-agentcore.d.ts.map