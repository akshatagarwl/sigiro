import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessPointAlreadyOwnedByYou_base: S.Class<AccessPointAlreadyOwnedByYou, S.TaggedStruct<"AccessPointAlreadyOwnedByYou", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class AccessPointAlreadyOwnedByYou extends /*@__PURE__*/ AccessPointAlreadyOwnedByYou_base {
}
declare const ActiveDirectoryError_base: S.Class<ActiveDirectoryError, S.TaggedStruct<"ActiveDirectoryError", {
    readonly ActiveDirectoryId: any;
    readonly Type: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ActiveDirectoryError extends /*@__PURE__*/ ActiveDirectoryError_base {
}
declare const BackupBeingCopied_base: S.Class<BackupBeingCopied, S.TaggedStruct<"BackupBeingCopied", {
    readonly message: any;
    readonly BackupId: any;
}>, import("effect/Cause").YieldableError>;
export declare class BackupBeingCopied extends /*@__PURE__*/ BackupBeingCopied_base {
}
declare const BackupInProgress_base: S.Class<BackupInProgress, S.TaggedStruct<"BackupInProgress", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BackupInProgress extends /*@__PURE__*/ BackupInProgress_base {
}
declare const BackupNotFound_base: S.Class<BackupNotFound, S.TaggedStruct<"BackupNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BackupNotFound extends /*@__PURE__*/ BackupNotFound_base {
}
declare const BackupRestoring_base: S.Class<BackupRestoring, S.TaggedStruct<"BackupRestoring", {
    readonly message: any;
    readonly FileSystemId: any;
}>, import("effect/Cause").YieldableError>;
export declare class BackupRestoring extends /*@__PURE__*/ BackupRestoring_base {
}
declare const BadRequest_base: S.Class<BadRequest, S.TaggedStruct<"BadRequest", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BadRequest extends /*@__PURE__*/ BadRequest_base {
}
declare const DataRepositoryAssociationNotFound_base: S.Class<DataRepositoryAssociationNotFound, S.TaggedStruct<"DataRepositoryAssociationNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DataRepositoryAssociationNotFound extends /*@__PURE__*/ DataRepositoryAssociationNotFound_base {
}
declare const DataRepositoryTaskEnded_base: S.Class<DataRepositoryTaskEnded, S.TaggedStruct<"DataRepositoryTaskEnded", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DataRepositoryTaskEnded extends /*@__PURE__*/ DataRepositoryTaskEnded_base {
}
declare const DataRepositoryTaskExecuting_base: S.Class<DataRepositoryTaskExecuting, S.TaggedStruct<"DataRepositoryTaskExecuting", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DataRepositoryTaskExecuting extends /*@__PURE__*/ DataRepositoryTaskExecuting_base {
}
declare const DataRepositoryTaskNotFound_base: S.Class<DataRepositoryTaskNotFound, S.TaggedStruct<"DataRepositoryTaskNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DataRepositoryTaskNotFound extends /*@__PURE__*/ DataRepositoryTaskNotFound_base {
}
declare const FileCacheNotFound_base: S.Class<FileCacheNotFound, S.TaggedStruct<"FileCacheNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FileCacheNotFound extends /*@__PURE__*/ FileCacheNotFound_base {
}
declare const FileSystemNotFound_base: S.Class<FileSystemNotFound, S.TaggedStruct<"FileSystemNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FileSystemNotFound extends /*@__PURE__*/ FileSystemNotFound_base {
}
declare const IncompatibleParameterError_base: S.Class<IncompatibleParameterError, S.TaggedStruct<"IncompatibleParameterError", {
    readonly Parameter: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IncompatibleParameterError extends /*@__PURE__*/ IncompatibleParameterError_base {
}
declare const IncompatibleRegionForMultiAZ_base: S.Class<IncompatibleRegionForMultiAZ, S.TaggedStruct<"IncompatibleRegionForMultiAZ", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IncompatibleRegionForMultiAZ extends /*@__PURE__*/ IncompatibleRegionForMultiAZ_base {
}
declare const InternalServerError_base: S.Class<InternalServerError, S.TaggedStruct<"InternalServerError", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const InvalidAccessPoint_base: S.Class<InvalidAccessPoint, S.TaggedStruct<"InvalidAccessPoint", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidAccessPoint extends /*@__PURE__*/ InvalidAccessPoint_base {
}
declare const InvalidDataRepositoryType_base: S.Class<InvalidDataRepositoryType, S.TaggedStruct<"InvalidDataRepositoryType", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDataRepositoryType extends /*@__PURE__*/ InvalidDataRepositoryType_base {
}
declare const InvalidDestinationKmsKey_base: S.Class<InvalidDestinationKmsKey, S.TaggedStruct<"InvalidDestinationKmsKey", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDestinationKmsKey extends /*@__PURE__*/ InvalidDestinationKmsKey_base {
}
declare const InvalidExportPath_base: S.Class<InvalidExportPath, S.TaggedStruct<"InvalidExportPath", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidExportPath extends /*@__PURE__*/ InvalidExportPath_base {
}
declare const InvalidImportPath_base: S.Class<InvalidImportPath, S.TaggedStruct<"InvalidImportPath", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidImportPath extends /*@__PURE__*/ InvalidImportPath_base {
}
declare const InvalidNetworkSettings_base: S.Class<InvalidNetworkSettings, S.TaggedStruct<"InvalidNetworkSettings", {
    readonly message: any;
    readonly InvalidSubnetId: any;
    readonly InvalidSecurityGroupId: any;
    readonly InvalidRouteTableId: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidNetworkSettings extends /*@__PURE__*/ InvalidNetworkSettings_base {
}
declare const InvalidPerUnitStorageThroughput_base: S.Class<InvalidPerUnitStorageThroughput, S.TaggedStruct<"InvalidPerUnitStorageThroughput", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidPerUnitStorageThroughput extends /*@__PURE__*/ InvalidPerUnitStorageThroughput_base {
}
declare const InvalidRegion_base: S.Class<InvalidRegion, S.TaggedStruct<"InvalidRegion", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRegion extends /*@__PURE__*/ InvalidRegion_base {
}
declare const InvalidRequest_base: S.Class<InvalidRequest, S.TaggedStruct<"InvalidRequest", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequest extends /*@__PURE__*/ InvalidRequest_base {
}
declare const InvalidSourceKmsKey_base: S.Class<InvalidSourceKmsKey, S.TaggedStruct<"InvalidSourceKmsKey", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSourceKmsKey extends /*@__PURE__*/ InvalidSourceKmsKey_base {
}
declare const MissingFileCacheConfiguration_base: S.Class<MissingFileCacheConfiguration, S.TaggedStruct<"MissingFileCacheConfiguration", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MissingFileCacheConfiguration extends /*@__PURE__*/ MissingFileCacheConfiguration_base {
}
declare const MissingFileSystemConfiguration_base: S.Class<MissingFileSystemConfiguration, S.TaggedStruct<"MissingFileSystemConfiguration", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MissingFileSystemConfiguration extends /*@__PURE__*/ MissingFileSystemConfiguration_base {
}
declare const MissingVolumeConfiguration_base: S.Class<MissingVolumeConfiguration, S.TaggedStruct<"MissingVolumeConfiguration", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MissingVolumeConfiguration extends /*@__PURE__*/ MissingVolumeConfiguration_base {
}
declare const NotServiceResourceError_base: S.Class<NotServiceResourceError, S.TaggedStruct<"NotServiceResourceError", {
    readonly ResourceARN: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NotServiceResourceError extends /*@__PURE__*/ NotServiceResourceError_base {
}
declare const ResourceDoesNotSupportTagging_base: S.Class<ResourceDoesNotSupportTagging, S.TaggedStruct<"ResourceDoesNotSupportTagging", {
    readonly ResourceARN: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceDoesNotSupportTagging extends /*@__PURE__*/ ResourceDoesNotSupportTagging_base {
}
declare const ResourceNotFound_base: S.Class<ResourceNotFound, S.TaggedStruct<"ResourceNotFound", {
    readonly ResourceARN: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotFound extends /*@__PURE__*/ ResourceNotFound_base {
}
declare const RestoreSnapshotNotFound_base: S.Class<RestoreSnapshotNotFound, S.TaggedStruct<"RestoreSnapshotNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class RestoreSnapshotNotFound extends /*@__PURE__*/ RestoreSnapshotNotFound_base {
}
declare const S3AccessPointAttachmentNotFound_base: S.Class<S3AccessPointAttachmentNotFound, S.TaggedStruct<"S3AccessPointAttachmentNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class S3AccessPointAttachmentNotFound extends /*@__PURE__*/ S3AccessPointAttachmentNotFound_base {
}
declare const ServiceLimitExceeded_base: S.Class<ServiceLimitExceeded, S.TaggedStruct<"ServiceLimitExceeded", {
    readonly Limit: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ServiceLimitExceeded extends /*@__PURE__*/ ServiceLimitExceeded_base {
}
declare const SnapshotNotFound_base: S.Class<SnapshotNotFound, S.TaggedStruct<"SnapshotNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SnapshotNotFound extends /*@__PURE__*/ SnapshotNotFound_base {
}
declare const SnapshotVolumeNotFound_base: S.Class<SnapshotVolumeNotFound, S.TaggedStruct<"SnapshotVolumeNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class SnapshotVolumeNotFound extends /*@__PURE__*/ SnapshotVolumeNotFound_base {
}
declare const SourceBackupUnavailable_base: S.Class<SourceBackupUnavailable, S.TaggedStruct<"SourceBackupUnavailable", {
    readonly message: any;
    readonly BackupId: any;
}>, import("effect/Cause").YieldableError>;
export declare class SourceBackupUnavailable extends /*@__PURE__*/ SourceBackupUnavailable_base {
}
declare const SourceSnapshotNotFound_base: S.Class<SourceSnapshotNotFound, S.TaggedStruct<"SourceSnapshotNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class SourceSnapshotNotFound extends /*@__PURE__*/ SourceSnapshotNotFound_base {
}
declare const StorageVirtualMachineNotFound_base: S.Class<StorageVirtualMachineNotFound, S.TaggedStruct<"StorageVirtualMachineNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class StorageVirtualMachineNotFound extends /*@__PURE__*/ StorageVirtualMachineNotFound_base {
}
declare const TooManyAccessPoints_base: S.Class<TooManyAccessPoints, S.TaggedStruct<"TooManyAccessPoints", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyAccessPoints extends /*@__PURE__*/ TooManyAccessPoints_base {
}
declare const UnsupportedOperation_base: S.Class<UnsupportedOperation, S.TaggedStruct<"UnsupportedOperation", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnsupportedOperation extends /*@__PURE__*/ UnsupportedOperation_base {
}
declare const UpdateSnapshotNotFound_base: S.Class<UpdateSnapshotNotFound, S.TaggedStruct<"UpdateSnapshotNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class UpdateSnapshotNotFound extends /*@__PURE__*/ UpdateSnapshotNotFound_base {
}
declare const VolumeNotFound_base: S.Class<VolumeNotFound, S.TaggedStruct<"VolumeNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class VolumeNotFound extends /*@__PURE__*/ VolumeNotFound_base {
}
export type ClientRequestToken = string;
export type FileSystemId = string;
export type AlternateDNSName = string;
export type AlternateDNSNames = string[];
export declare const AlternateDNSNames: any;
export interface AssociateFileSystemAliasesRequest {
    ClientRequestToken?: string;
    FileSystemId?: string;
    Aliases?: string[];
}
export declare const AssociateFileSystemAliasesRequest: S.Schema<AssociateFileSystemAliasesRequest>;
export type AliasLifecycle = "AVAILABLE" | "CREATING" | "DELETING" | "CREATE_FAILED" | "DELETE_FAILED" | (string & {});
export declare const AliasLifecycle: any;
export interface Alias {
    Name?: string;
    Lifecycle?: AliasLifecycle;
}
export declare const Alias: S.Schema<Alias>;
export type Aliases = Alias[];
export declare const Aliases: any;
export interface AssociateFileSystemAliasesResponse {
    Aliases?: Alias[];
}
export declare const AssociateFileSystemAliasesResponse: S.Schema<AssociateFileSystemAliasesResponse>;
export type TaskId = string;
export interface CancelDataRepositoryTaskRequest {
    TaskId?: string;
}
export declare const CancelDataRepositoryTaskRequest: S.Schema<CancelDataRepositoryTaskRequest>;
export type DataRepositoryTaskLifecycle = "PENDING" | "EXECUTING" | "FAILED" | "SUCCEEDED" | "CANCELED" | "CANCELING" | (string & {});
export declare const DataRepositoryTaskLifecycle: any;
export interface CancelDataRepositoryTaskResponse {
    Lifecycle?: DataRepositoryTaskLifecycle;
    TaskId?: string;
}
export declare const CancelDataRepositoryTaskResponse: S.Schema<CancelDataRepositoryTaskResponse>;
export type SourceBackupId = string;
export type Region = string;
export type KmsKeyId = string;
export type Flag = boolean;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export interface CopyBackupRequest {
    ClientRequestToken?: string;
    SourceBackupId?: string;
    SourceRegion?: string;
    KmsKeyId?: string;
    CopyTags?: boolean;
    Tags?: Tag[];
}
export declare const CopyBackupRequest: S.Schema<CopyBackupRequest>;
export type BackupId = string;
export type BackupLifecycle = "AVAILABLE" | "CREATING" | "TRANSFERRING" | "DELETED" | "FAILED" | "PENDING" | "COPYING" | (string & {});
export declare const BackupLifecycle: any;
export type ErrorMessage = string;
export interface BackupFailureDetails {
    Message?: string;
}
export declare const BackupFailureDetails: S.Schema<BackupFailureDetails>;
export type BackupType = "AUTOMATIC" | "USER_INITIATED" | "AWS_BACKUP" | (string & {});
export declare const BackupType: any;
export type ProgressPercent = number;
export type CreationTime = Date;
export type ResourceARN = string;
export type AWSAccountId = string;
export type FileSystemType = "WINDOWS" | "LUSTRE" | "ONTAP" | "OPENZFS" | (string & {});
export declare const FileSystemType: any;
export type FileSystemLifecycle = "AVAILABLE" | "CREATING" | "FAILED" | "DELETING" | "MISCONFIGURED" | "UPDATING" | "MISCONFIGURED_UNAVAILABLE" | (string & {});
export declare const FileSystemLifecycle: any;
export interface FileSystemFailureDetails {
    Message?: string;
}
export declare const FileSystemFailureDetails: S.Schema<FileSystemFailureDetails>;
export type StorageCapacity = number;
export type StorageType = "SSD" | "HDD" | "INTELLIGENT_TIERING" | (string & {});
export declare const StorageType: any;
export type VpcId = string;
export type SubnetId = string;
export type SubnetIds = string[];
export declare const SubnetIds: any;
export type NetworkInterfaceId = string;
export type NetworkInterfaceIds = string[];
export declare const NetworkInterfaceIds: any;
export type DNSName = string;
export type DirectoryId = string;
export type ActiveDirectoryFullyQualifiedName = string;
export type OrganizationalUnitDistinguishedName = string;
export type FileSystemAdministratorsGroupName = string;
export type DirectoryUserName = string;
export type IpAddress = string;
export type DnsIps = string[];
export declare const DnsIps: any;
export type CustomerSecretsManagerARN = string;
export interface SelfManagedActiveDirectoryAttributes {
    DomainName?: string;
    OrganizationalUnitDistinguishedName?: string;
    FileSystemAdministratorsGroup?: string;
    UserName?: string;
    DnsIps?: string[];
    DomainJoinServiceAccountSecret?: string;
}
export declare const SelfManagedActiveDirectoryAttributes: S.Schema<SelfManagedActiveDirectoryAttributes>;
export type WindowsDeploymentType = "MULTI_AZ_1" | "SINGLE_AZ_1" | "SINGLE_AZ_2" | (string & {});
export declare const WindowsDeploymentType: any;
export type MegabytesPerSecond = number;
export type FileSystemMaintenanceOperation = "PATCHING" | "BACKING_UP" | (string & {});
export declare const FileSystemMaintenanceOperation: any;
export type FileSystemMaintenanceOperations = FileSystemMaintenanceOperation[];
export declare const FileSystemMaintenanceOperations: any;
export type WeeklyTime = string;
export type DailyTime = string;
export type AutomaticBackupRetentionDays = number;
export type WindowsAccessAuditLogLevel = "DISABLED" | "SUCCESS_ONLY" | "FAILURE_ONLY" | "SUCCESS_AND_FAILURE" | (string & {});
export declare const WindowsAccessAuditLogLevel: any;
export type GeneralARN = string;
export interface WindowsAuditLogConfiguration {
    FileAccessAuditLogLevel?: WindowsAccessAuditLogLevel;
    FileShareAccessAuditLogLevel?: WindowsAccessAuditLogLevel;
    AuditLogDestination?: string;
}
export declare const WindowsAuditLogConfiguration: S.Schema<WindowsAuditLogConfiguration>;
export type DiskIopsConfigurationMode = "AUTOMATIC" | "USER_PROVISIONED" | (string & {});
export declare const DiskIopsConfigurationMode: any;
export type Iops = number;
export interface DiskIopsConfiguration {
    Mode?: DiskIopsConfigurationMode;
    Iops?: number;
}
export declare const DiskIopsConfiguration: S.Schema<DiskIopsConfiguration>;
export interface WindowsFsrmConfiguration {
    FsrmServiceEnabled?: boolean;
    EventLogDestination?: string;
}
export declare const WindowsFsrmConfiguration: S.Schema<WindowsFsrmConfiguration>;
export interface WindowsFileSystemConfiguration {
    ActiveDirectoryId?: string;
    SelfManagedActiveDirectoryConfiguration?: SelfManagedActiveDirectoryAttributes;
    DeploymentType?: WindowsDeploymentType;
    RemoteAdministrationEndpoint?: string;
    PreferredSubnetId?: string;
    PreferredFileServerIp?: string;
    ThroughputCapacity?: number;
    MaintenanceOperationsInProgress?: FileSystemMaintenanceOperation[];
    WeeklyMaintenanceStartTime?: string;
    DailyAutomaticBackupStartTime?: string;
    AutomaticBackupRetentionDays?: number;
    CopyTagsToBackups?: boolean;
    Aliases?: Alias[];
    AuditLogConfiguration?: WindowsAuditLogConfiguration;
    DiskIopsConfiguration?: DiskIopsConfiguration;
    PreferredFileServerIpv6?: string;
    FsrmConfiguration?: WindowsFsrmConfiguration;
}
export declare const WindowsFileSystemConfiguration: S.Schema<WindowsFileSystemConfiguration>;
export type DataRepositoryLifecycle = "CREATING" | "AVAILABLE" | "MISCONFIGURED" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export declare const DataRepositoryLifecycle: any;
export type ArchivePath = string;
export type Megabytes = number;
export type AutoImportPolicyType = "NONE" | "NEW" | "NEW_CHANGED" | "NEW_CHANGED_DELETED" | (string & {});
export declare const AutoImportPolicyType: any;
export interface DataRepositoryFailureDetails {
    Message?: string;
}
export declare const DataRepositoryFailureDetails: S.Schema<DataRepositoryFailureDetails>;
export interface DataRepositoryConfiguration {
    Lifecycle?: DataRepositoryLifecycle;
    ImportPath?: string;
    ExportPath?: string;
    ImportedFileChunkSize?: number;
    AutoImportPolicy?: AutoImportPolicyType;
    FailureDetails?: DataRepositoryFailureDetails;
}
export declare const DataRepositoryConfiguration: S.Schema<DataRepositoryConfiguration>;
export type LustreDeploymentType = "SCRATCH_1" | "SCRATCH_2" | "PERSISTENT_1" | "PERSISTENT_2" | (string & {});
export declare const LustreDeploymentType: any;
export type PerUnitStorageThroughput = number;
export type LustreFileSystemMountName = string;
export type DriveCacheType = "NONE" | "READ" | (string & {});
export declare const DriveCacheType: any;
export type DataCompressionType = "NONE" | "LZ4" | (string & {});
export declare const DataCompressionType: any;
export type LustreAccessAuditLogLevel = "DISABLED" | "WARN_ONLY" | "ERROR_ONLY" | "WARN_ERROR" | (string & {});
export declare const LustreAccessAuditLogLevel: any;
export interface LustreLogConfiguration {
    Level?: LustreAccessAuditLogLevel;
    Destination?: string;
}
export declare const LustreLogConfiguration: S.Schema<LustreLogConfiguration>;
export type LustreRootSquash = string;
export type LustreNoSquashNid = string;
export type LustreNoSquashNids = string[];
export declare const LustreNoSquashNids: any;
export interface LustreRootSquashConfiguration {
    RootSquash?: string;
    NoSquashNids?: string[];
}
export declare const LustreRootSquashConfiguration: S.Schema<LustreRootSquashConfiguration>;
export type MetadataIops = number;
export type MetadataConfigurationMode = "AUTOMATIC" | "USER_PROVISIONED" | (string & {});
export declare const MetadataConfigurationMode: any;
export interface FileSystemLustreMetadataConfiguration {
    Iops?: number;
    Mode?: MetadataConfigurationMode;
}
export declare const FileSystemLustreMetadataConfiguration: S.Schema<FileSystemLustreMetadataConfiguration>;
export type ThroughputCapacityMbps = number;
export type LustreReadCacheSizingMode = "NO_CACHE" | "USER_PROVISIONED" | "PROPORTIONAL_TO_THROUGHPUT_CAPACITY" | (string & {});
export declare const LustreReadCacheSizingMode: any;
export interface LustreReadCacheConfiguration {
    SizingMode?: LustreReadCacheSizingMode;
    SizeGiB?: number;
}
export declare const LustreReadCacheConfiguration: S.Schema<LustreReadCacheConfiguration>;
export interface LustreFileSystemConfiguration {
    WeeklyMaintenanceStartTime?: string;
    DataRepositoryConfiguration?: DataRepositoryConfiguration;
    DeploymentType?: LustreDeploymentType;
    PerUnitStorageThroughput?: number;
    MountName?: string;
    DailyAutomaticBackupStartTime?: string;
    AutomaticBackupRetentionDays?: number;
    CopyTagsToBackups?: boolean;
    DriveCacheType?: DriveCacheType;
    DataCompressionType?: DataCompressionType;
    LogConfiguration?: LustreLogConfiguration;
    RootSquashConfiguration?: LustreRootSquashConfiguration;
    MetadataConfiguration?: FileSystemLustreMetadataConfiguration;
    EfaEnabled?: boolean;
    ThroughputCapacity?: number;
    DataReadCacheConfiguration?: LustreReadCacheConfiguration;
}
export declare const LustreFileSystemConfiguration: S.Schema<LustreFileSystemConfiguration>;
export type AdministrativeActionType = "FILE_SYSTEM_UPDATE" | "STORAGE_OPTIMIZATION" | "FILE_SYSTEM_ALIAS_ASSOCIATION" | "FILE_SYSTEM_ALIAS_DISASSOCIATION" | "VOLUME_UPDATE" | "SNAPSHOT_UPDATE" | "RELEASE_NFS_V3_LOCKS" | "VOLUME_RESTORE" | "THROUGHPUT_OPTIMIZATION" | "IOPS_OPTIMIZATION" | "STORAGE_TYPE_OPTIMIZATION" | "MISCONFIGURED_STATE_RECOVERY" | "VOLUME_UPDATE_WITH_SNAPSHOT" | "VOLUME_INITIALIZE_WITH_SNAPSHOT" | "DOWNLOAD_DATA_FROM_BACKUP" | (string & {});
export declare const AdministrativeActionType: any;
export type RequestTime = Date;
export type Status = "FAILED" | "IN_PROGRESS" | "PENDING" | "COMPLETED" | "UPDATED_OPTIMIZING" | "OPTIMIZING" | "PAUSED" | "CANCELLED" | (string & {});
export declare const Status: any;
export interface AdministrativeActionFailureDetails {
    Message?: string;
}
export declare const AdministrativeActionFailureDetails: S.Schema<AdministrativeActionFailureDetails>;
export type VolumeLifecycle = "CREATING" | "CREATED" | "DELETING" | "FAILED" | "MISCONFIGURED" | "PENDING" | "AVAILABLE" | (string & {});
export declare const VolumeLifecycle: any;
export type VolumeName = string;
export type FlexCacheEndpointType = "NONE" | "ORIGIN" | "CACHE" | (string & {});
export declare const FlexCacheEndpointType: any;
export type JunctionPath = string;
export type SecurityStyle = "UNIX" | "NTFS" | "MIXED" | (string & {});
export declare const SecurityStyle: any;
export type VolumeCapacity = number;
export type StorageVirtualMachineId = string;
export type CoolingPeriod = number;
export type TieringPolicyName = "SNAPSHOT_ONLY" | "AUTO" | "ALL" | "NONE" | (string & {});
export declare const TieringPolicyName: any;
export interface TieringPolicy {
    CoolingPeriod?: number;
    Name?: TieringPolicyName;
}
export declare const TieringPolicy: S.Schema<TieringPolicy>;
export type UUID = string;
export type OntapVolumeType = "RW" | "DP" | "LS" | (string & {});
export declare const OntapVolumeType: any;
export type SnapshotPolicy = string;
export type AutocommitPeriodType = "MINUTES" | "HOURS" | "DAYS" | "MONTHS" | "YEARS" | "NONE" | (string & {});
export declare const AutocommitPeriodType: any;
export type AutocommitPeriodValue = number;
export interface AutocommitPeriod {
    Type?: AutocommitPeriodType;
    Value?: number;
}
export declare const AutocommitPeriod: S.Schema<AutocommitPeriod>;
export type PrivilegedDelete = "DISABLED" | "ENABLED" | "PERMANENTLY_DISABLED" | (string & {});
export declare const PrivilegedDelete: any;
export type RetentionPeriodType = "SECONDS" | "MINUTES" | "HOURS" | "DAYS" | "MONTHS" | "YEARS" | "INFINITE" | "UNSPECIFIED" | (string & {});
export declare const RetentionPeriodType: any;
export type RetentionPeriodValue = number;
export interface RetentionPeriod {
    Type?: RetentionPeriodType;
    Value?: number;
}
export declare const RetentionPeriod: S.Schema<RetentionPeriod>;
export interface SnaplockRetentionPeriod {
    DefaultRetention?: RetentionPeriod;
    MinimumRetention?: RetentionPeriod;
    MaximumRetention?: RetentionPeriod;
}
export declare const SnaplockRetentionPeriod: S.Schema<SnaplockRetentionPeriod>;
export type SnaplockType = "COMPLIANCE" | "ENTERPRISE" | (string & {});
export declare const SnaplockType: any;
export interface SnaplockConfiguration {
    AuditLogVolume?: boolean;
    AutocommitPeriod?: AutocommitPeriod;
    PrivilegedDelete?: PrivilegedDelete;
    RetentionPeriod?: SnaplockRetentionPeriod;
    SnaplockType?: SnaplockType;
    VolumeAppendModeEnabled?: boolean;
}
export declare const SnaplockConfiguration: S.Schema<SnaplockConfiguration>;
export type VolumeStyle = "FLEXVOL" | "FLEXGROUP" | (string & {});
export declare const VolumeStyle: any;
export type Aggregate = string;
export type Aggregates = string[];
export declare const Aggregates: any;
export type TotalConstituents = number;
export interface AggregateConfiguration {
    Aggregates?: string[];
    TotalConstituents?: number;
}
export declare const AggregateConfiguration: S.Schema<AggregateConfiguration>;
export type VolumeCapacityBytes = number;
export interface OntapVolumeConfiguration {
    FlexCacheEndpointType?: FlexCacheEndpointType;
    JunctionPath?: string;
    SecurityStyle?: SecurityStyle;
    SizeInMegabytes?: number;
    StorageEfficiencyEnabled?: boolean;
    StorageVirtualMachineId?: string;
    StorageVirtualMachineRoot?: boolean;
    TieringPolicy?: TieringPolicy;
    UUID?: string;
    OntapVolumeType?: OntapVolumeType;
    SnapshotPolicy?: string;
    CopyTagsToBackups?: boolean;
    SnaplockConfiguration?: SnaplockConfiguration;
    VolumeStyle?: VolumeStyle;
    AggregateConfiguration?: AggregateConfiguration;
    SizeInBytes?: number;
}
export declare const OntapVolumeConfiguration: S.Schema<OntapVolumeConfiguration>;
export type VolumeId = string;
export type VolumeType = "ONTAP" | "OPENZFS" | (string & {});
export declare const VolumeType: any;
export interface LifecycleTransitionReason {
    Message?: string;
}
export declare const LifecycleTransitionReason: S.Schema<LifecycleTransitionReason>;
export type VolumePath = string;
export type IntegerNoMax = number;
export type IntegerRecordSizeKiB = number;
export type OpenZFSDataCompressionType = "NONE" | "ZSTD" | "LZ4" | (string & {});
export declare const OpenZFSDataCompressionType: any;
export type OpenZFSCopyStrategy = "CLONE" | "FULL_COPY" | "INCREMENTAL_COPY" | (string & {});
export declare const OpenZFSCopyStrategy: any;
export interface OpenZFSOriginSnapshotConfiguration {
    SnapshotARN?: string;
    CopyStrategy?: OpenZFSCopyStrategy;
}
export declare const OpenZFSOriginSnapshotConfiguration: S.Schema<OpenZFSOriginSnapshotConfiguration>;
export type ReadOnly = boolean;
export type OpenZFSClients = string;
export type OpenZFSNfsExportOption = string;
export type OpenZFSNfsExportOptions = string[];
export declare const OpenZFSNfsExportOptions: any;
export interface OpenZFSClientConfiguration {
    Clients?: string;
    Options?: string[];
}
export declare const OpenZFSClientConfiguration: S.Schema<OpenZFSClientConfiguration>;
export type OpenZFSClientConfigurations = OpenZFSClientConfiguration[];
export declare const OpenZFSClientConfigurations: any;
export interface OpenZFSNfsExport {
    ClientConfigurations?: OpenZFSClientConfiguration[];
}
export declare const OpenZFSNfsExport: S.Schema<OpenZFSNfsExport>;
export type OpenZFSNfsExports = OpenZFSNfsExport[];
export declare const OpenZFSNfsExports: any;
export type OpenZFSQuotaType = "USER" | "GROUP" | (string & {});
export declare const OpenZFSQuotaType: any;
export interface OpenZFSUserOrGroupQuota {
    Type?: OpenZFSQuotaType;
    Id?: number;
    StorageCapacityQuotaGiB?: number;
}
export declare const OpenZFSUserOrGroupQuota: S.Schema<OpenZFSUserOrGroupQuota>;
export type OpenZFSUserAndGroupQuotas = OpenZFSUserOrGroupQuota[];
export declare const OpenZFSUserAndGroupQuotas: any;
export type SnapshotId = string;
export interface OpenZFSVolumeConfiguration {
    ParentVolumeId?: string;
    VolumePath?: string;
    StorageCapacityReservationGiB?: number;
    StorageCapacityQuotaGiB?: number;
    RecordSizeKiB?: number;
    DataCompressionType?: OpenZFSDataCompressionType;
    CopyTagsToSnapshots?: boolean;
    OriginSnapshot?: OpenZFSOriginSnapshotConfiguration;
    ReadOnly?: boolean;
    NfsExports?: OpenZFSNfsExport[];
    UserAndGroupQuotas?: OpenZFSUserOrGroupQuota[];
    RestoreToSnapshot?: string;
    DeleteIntermediateSnaphots?: boolean;
    DeleteClonedVolumes?: boolean;
    DeleteIntermediateData?: boolean;
    SourceSnapshotARN?: string;
    DestinationSnapshot?: string;
    CopyStrategy?: OpenZFSCopyStrategy;
}
export declare const OpenZFSVolumeConfiguration: S.Schema<OpenZFSVolumeConfiguration>;
export interface Volume {
    CreationTime?: Date;
    FileSystemId?: string;
    Lifecycle?: VolumeLifecycle;
    Name?: string;
    OntapConfiguration?: OntapVolumeConfiguration;
    ResourceARN?: string;
    Tags?: Tag[];
    VolumeId?: string;
    VolumeType?: VolumeType;
    LifecycleTransitionReason?: LifecycleTransitionReason;
    AdministrativeActions?: AdministrativeAction[];
    OpenZFSConfiguration?: OpenZFSVolumeConfiguration;
}
export declare const Volume: S.Schema<Volume>;
export type SnapshotName = string;
export type SnapshotLifecycle = "PENDING" | "CREATING" | "DELETING" | "AVAILABLE" | (string & {});
export declare const SnapshotLifecycle: any;
export interface Snapshot {
    ResourceARN?: string;
    SnapshotId?: string;
    Name?: string;
    VolumeId?: string;
    CreationTime?: Date;
    Lifecycle?: SnapshotLifecycle;
    LifecycleTransitionReason?: LifecycleTransitionReason;
    Tags?: Tag[];
    AdministrativeActions?: AdministrativeAction[];
}
export declare const Snapshot: S.Schema<Snapshot>;
export type TotalTransferBytes = number;
export type RemainingTransferBytes = number;
export interface AdministrativeAction {
    AdministrativeActionType?: AdministrativeActionType;
    ProgressPercent?: number;
    RequestTime?: Date;
    Status?: Status;
    TargetFileSystemValues?: FileSystem;
    FailureDetails?: AdministrativeActionFailureDetails;
    TargetVolumeValues?: Volume;
    TargetSnapshotValues?: Snapshot;
    TotalTransferBytes?: number;
    RemainingTransferBytes?: number;
    Message?: string;
}
export declare const AdministrativeAction: S.Schema<AdministrativeAction>;
export type AdministrativeActions = AdministrativeAction[];
export declare const AdministrativeActions: S.Schema<AdministrativeActions>;
export type OntapDeploymentType = "MULTI_AZ_1" | "SINGLE_AZ_1" | "SINGLE_AZ_2" | "MULTI_AZ_2" | (string & {});
export declare const OntapDeploymentType: any;
export type IpAddressRange = string;
export type OntapEndpointIpAddresses = string[];
export declare const OntapEndpointIpAddresses: any;
export interface FileSystemEndpoint {
    DNSName?: string;
    IpAddresses?: string[];
    Ipv6Addresses?: string[];
}
export declare const FileSystemEndpoint: S.Schema<FileSystemEndpoint>;
export interface FileSystemEndpoints {
    Intercluster?: FileSystemEndpoint;
    Management?: FileSystemEndpoint;
}
export declare const FileSystemEndpoints: S.Schema<FileSystemEndpoints>;
export type RouteTableId = string;
export type RouteTableIds = string[];
export declare const RouteTableIds: any;
export type AdminPassword = string | redacted.Redacted<string>;
export type HAPairs = number;
export type ThroughputCapacityPerHAPair = number;
export type Ipv6AddressRange = string;
export interface OntapFileSystemConfiguration {
    AutomaticBackupRetentionDays?: number;
    DailyAutomaticBackupStartTime?: string;
    DeploymentType?: OntapDeploymentType;
    EndpointIpAddressRange?: string;
    Endpoints?: FileSystemEndpoints;
    DiskIopsConfiguration?: DiskIopsConfiguration;
    PreferredSubnetId?: string;
    RouteTableIds?: string[];
    ThroughputCapacity?: number;
    WeeklyMaintenanceStartTime?: string;
    FsxAdminPassword?: string | redacted.Redacted<string>;
    HAPairs?: number;
    ThroughputCapacityPerHAPair?: number;
    EndpointIpv6AddressRange?: string;
}
export declare const OntapFileSystemConfiguration: S.Schema<OntapFileSystemConfiguration>;
export type FileSystemTypeVersion = string;
export type OpenZFSDeploymentType = "SINGLE_AZ_1" | "SINGLE_AZ_2" | "SINGLE_AZ_HA_1" | "SINGLE_AZ_HA_2" | "MULTI_AZ_1" | (string & {});
export declare const OpenZFSDeploymentType: any;
export type OpenZFSReadCacheSizingMode = "NO_CACHE" | "USER_PROVISIONED" | "PROPORTIONAL_TO_THROUGHPUT_CAPACITY" | (string & {});
export declare const OpenZFSReadCacheSizingMode: any;
export interface OpenZFSReadCacheConfiguration {
    SizingMode?: OpenZFSReadCacheSizingMode;
    SizeGiB?: number;
}
export declare const OpenZFSReadCacheConfiguration: S.Schema<OpenZFSReadCacheConfiguration>;
export interface OpenZFSFileSystemConfiguration {
    AutomaticBackupRetentionDays?: number;
    CopyTagsToBackups?: boolean;
    CopyTagsToVolumes?: boolean;
    DailyAutomaticBackupStartTime?: string;
    DeploymentType?: OpenZFSDeploymentType;
    ThroughputCapacity?: number;
    WeeklyMaintenanceStartTime?: string;
    DiskIopsConfiguration?: DiskIopsConfiguration;
    RootVolumeId?: string;
    PreferredSubnetId?: string;
    EndpointIpAddressRange?: string;
    EndpointIpv6AddressRange?: string;
    RouteTableIds?: string[];
    EndpointIpAddress?: string;
    EndpointIpv6Address?: string;
    ReadCacheConfiguration?: OpenZFSReadCacheConfiguration;
}
export declare const OpenZFSFileSystemConfiguration: S.Schema<OpenZFSFileSystemConfiguration>;
export type NetworkType = "IPV4" | "DUAL" | (string & {});
export declare const NetworkType: any;
export interface FileSystem {
    OwnerId?: string;
    CreationTime?: Date;
    FileSystemId?: string;
    FileSystemType?: FileSystemType;
    Lifecycle?: FileSystemLifecycle;
    FailureDetails?: FileSystemFailureDetails;
    StorageCapacity?: number;
    StorageType?: StorageType;
    VpcId?: string;
    SubnetIds?: string[];
    NetworkInterfaceIds?: string[];
    DNSName?: string;
    KmsKeyId?: string;
    ResourceARN?: string;
    Tags?: Tag[];
    WindowsConfiguration?: WindowsFileSystemConfiguration;
    LustreConfiguration?: LustreFileSystemConfiguration;
    AdministrativeActions?: AdministrativeAction[];
    OntapConfiguration?: OntapFileSystemConfiguration;
    FileSystemTypeVersion?: string;
    OpenZFSConfiguration?: OpenZFSFileSystemConfiguration;
    NetworkType?: NetworkType;
}
export declare const FileSystem: S.Schema<FileSystem>;
export interface ActiveDirectoryBackupAttributes {
    DomainName?: string;
    ActiveDirectoryId?: string;
    ResourceARN?: string;
}
export declare const ActiveDirectoryBackupAttributes: S.Schema<ActiveDirectoryBackupAttributes>;
export type ResourceType = "FILE_SYSTEM" | "VOLUME" | (string & {});
export declare const ResourceType: any;
export type SizeInBytes = number;
export interface Backup {
    BackupId?: string;
    Lifecycle?: BackupLifecycle;
    FailureDetails?: BackupFailureDetails;
    Type?: BackupType;
    ProgressPercent?: number;
    CreationTime?: Date;
    KmsKeyId?: string;
    ResourceARN?: string;
    Tags?: Tag[];
    FileSystem?: FileSystem;
    DirectoryInformation?: ActiveDirectoryBackupAttributes;
    OwnerId?: string;
    SourceBackupId?: string;
    SourceBackupRegion?: string;
    ResourceType?: ResourceType;
    Volume?: Volume;
    SizeInBytes?: number;
}
export declare const Backup: S.Schema<Backup>;
export interface CopyBackupResponse {
    Backup?: Backup & {
        BackupId: BackupId;
        Lifecycle: BackupLifecycle;
        Type: BackupType;
        CreationTime: CreationTime;
        FileSystem: FileSystem & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            WindowsConfiguration: WindowsFileSystemConfiguration & {
                AuditLogConfiguration: WindowsAuditLogConfiguration & {
                    FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                };
                FsrmConfiguration: WindowsFsrmConfiguration & {
                    FsrmServiceEnabled: Flag;
                };
            };
            LustreConfiguration: LustreFileSystemConfiguration & {
                LogConfiguration: LustreLogConfiguration & {
                    Level: LustreAccessAuditLogLevel;
                };
                MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                    Mode: MetadataConfigurationMode;
                };
            };
            AdministrativeActions: (AdministrativeAction & {
                TargetVolumeValues: Volume & {
                    OntapConfiguration: OntapVolumeConfiguration & {
                        SnaplockConfiguration: SnaplockConfiguration & {
                            AutocommitPeriod: AutocommitPeriod & {
                                Type: AutocommitPeriodType;
                            };
                            RetentionPeriod: SnaplockRetentionPeriod & {
                                DefaultRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                                MinimumRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                                MaximumRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                            };
                        };
                    };
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                    OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                        NfsExports: (OpenZFSNfsExport & {
                            ClientConfigurations: (OpenZFSClientConfiguration & {
                                Clients: OpenZFSClients;
                                Options: OpenZFSNfsExportOptions;
                            })[];
                        })[];
                        UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                            Type: OpenZFSQuotaType;
                            Id: IntegerNoMax;
                            StorageCapacityQuotaGiB: IntegerNoMax;
                        })[];
                    };
                };
                TargetSnapshotValues: Snapshot & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
            })[];
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        Volume: Volume & {
            OntapConfiguration: OntapVolumeConfiguration & {
                SnaplockConfiguration: SnaplockConfiguration & {
                    AutocommitPeriod: AutocommitPeriod & {
                        Type: AutocommitPeriodType;
                    };
                    RetentionPeriod: SnaplockRetentionPeriod & {
                        DefaultRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MinimumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MaximumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                    };
                };
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            AdministrativeActions: (AdministrativeAction & {
                TargetFileSystemValues: FileSystem & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                    WindowsConfiguration: WindowsFileSystemConfiguration & {
                        AuditLogConfiguration: WindowsAuditLogConfiguration & {
                            FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                            FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        };
                        FsrmConfiguration: WindowsFsrmConfiguration & {
                            FsrmServiceEnabled: Flag;
                        };
                    };
                    LustreConfiguration: LustreFileSystemConfiguration & {
                        LogConfiguration: LustreLogConfiguration & {
                            Level: LustreAccessAuditLogLevel;
                        };
                        MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                            Mode: MetadataConfigurationMode;
                        };
                    };
                };
                TargetSnapshotValues: Snapshot & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
            })[];
            OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                NfsExports: (OpenZFSNfsExport & {
                    ClientConfigurations: (OpenZFSClientConfiguration & {
                        Clients: OpenZFSClients;
                        Options: OpenZFSNfsExportOptions;
                    })[];
                })[];
                UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                    Type: OpenZFSQuotaType;
                    Id: IntegerNoMax;
                    StorageCapacityQuotaGiB: IntegerNoMax;
                })[];
            };
        };
    };
}
export declare const CopyBackupResponse: S.Schema<CopyBackupResponse>;
export type UpdateOpenZFSVolumeOption = "DELETE_INTERMEDIATE_SNAPSHOTS" | "DELETE_CLONED_VOLUMES" | "DELETE_INTERMEDIATE_DATA" | (string & {});
export declare const UpdateOpenZFSVolumeOption: any;
export type UpdateOpenZFSVolumeOptions = UpdateOpenZFSVolumeOption[];
export declare const UpdateOpenZFSVolumeOptions: any;
export interface CopySnapshotAndUpdateVolumeRequest {
    ClientRequestToken?: string;
    VolumeId?: string;
    SourceSnapshotARN?: string;
    CopyStrategy?: OpenZFSCopyStrategy;
    Options?: UpdateOpenZFSVolumeOption[];
}
export declare const CopySnapshotAndUpdateVolumeRequest: S.Schema<CopySnapshotAndUpdateVolumeRequest>;
export interface CopySnapshotAndUpdateVolumeResponse {
    VolumeId?: string;
    Lifecycle?: VolumeLifecycle;
    AdministrativeActions?: (AdministrativeAction & {
        TargetFileSystemValues: FileSystem & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            WindowsConfiguration: WindowsFileSystemConfiguration & {
                AuditLogConfiguration: WindowsAuditLogConfiguration & {
                    FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                };
                FsrmConfiguration: WindowsFsrmConfiguration & {
                    FsrmServiceEnabled: Flag;
                };
            };
            LustreConfiguration: LustreFileSystemConfiguration & {
                LogConfiguration: LustreLogConfiguration & {
                    Level: LustreAccessAuditLogLevel;
                };
                MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                    Mode: MetadataConfigurationMode;
                };
            };
        };
        TargetVolumeValues: Volume & {
            OntapConfiguration: OntapVolumeConfiguration & {
                SnaplockConfiguration: SnaplockConfiguration & {
                    AutocommitPeriod: AutocommitPeriod & {
                        Type: AutocommitPeriodType;
                    };
                    RetentionPeriod: SnaplockRetentionPeriod & {
                        DefaultRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MinimumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MaximumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                    };
                };
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                NfsExports: (OpenZFSNfsExport & {
                    ClientConfigurations: (OpenZFSClientConfiguration & {
                        Clients: OpenZFSClients;
                        Options: OpenZFSNfsExportOptions;
                    })[];
                })[];
                UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                    Type: OpenZFSQuotaType;
                    Id: IntegerNoMax;
                    StorageCapacityQuotaGiB: IntegerNoMax;
                })[];
            };
        };
        TargetSnapshotValues: Snapshot & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
    })[];
}
export declare const CopySnapshotAndUpdateVolumeResponse: S.Schema<CopySnapshotAndUpdateVolumeResponse>;
export type S3AccessPointAttachmentName = string;
export type S3AccessPointAttachmentType = "OPENZFS" | "ONTAP" | (string & {});
export declare const S3AccessPointAttachmentType: any;
export type OpenZFSFileSystemUserType = "POSIX" | (string & {});
export declare const OpenZFSFileSystemUserType: any;
export type FileSystemUID = number;
export type FileSystemGID = number;
export type FileSystemSecondaryGIDs = number[];
export declare const FileSystemSecondaryGIDs: any;
export interface OpenZFSPosixFileSystemUser {
    Uid?: number;
    Gid?: number;
    SecondaryGids?: number[];
}
export declare const OpenZFSPosixFileSystemUser: S.Schema<OpenZFSPosixFileSystemUser>;
export interface OpenZFSFileSystemIdentity {
    Type?: OpenZFSFileSystemUserType;
    PosixUser?: OpenZFSPosixFileSystemUser;
}
export declare const OpenZFSFileSystemIdentity: S.Schema<OpenZFSFileSystemIdentity>;
export interface CreateAndAttachS3AccessPointOpenZFSConfiguration {
    VolumeId?: string;
    FileSystemIdentity?: OpenZFSFileSystemIdentity;
}
export declare const CreateAndAttachS3AccessPointOpenZFSConfiguration: S.Schema<CreateAndAttachS3AccessPointOpenZFSConfiguration>;
export type OntapFileSystemUserType = "UNIX" | "WINDOWS" | (string & {});
export declare const OntapFileSystemUserType: any;
export type OntapFileSystemUserName = string;
export interface OntapUnixFileSystemUser {
    Name?: string;
}
export declare const OntapUnixFileSystemUser: S.Schema<OntapUnixFileSystemUser>;
export interface OntapWindowsFileSystemUser {
    Name?: string;
}
export declare const OntapWindowsFileSystemUser: S.Schema<OntapWindowsFileSystemUser>;
export interface OntapFileSystemIdentity {
    Type?: OntapFileSystemUserType;
    UnixUser?: OntapUnixFileSystemUser;
    WindowsUser?: OntapWindowsFileSystemUser;
}
export declare const OntapFileSystemIdentity: S.Schema<OntapFileSystemIdentity>;
export interface CreateAndAttachS3AccessPointOntapConfiguration {
    VolumeId?: string;
    FileSystemIdentity?: OntapFileSystemIdentity;
}
export declare const CreateAndAttachS3AccessPointOntapConfiguration: S.Schema<CreateAndAttachS3AccessPointOntapConfiguration>;
export interface S3AccessPointVpcConfiguration {
    VpcId?: string;
}
export declare const S3AccessPointVpcConfiguration: S.Schema<S3AccessPointVpcConfiguration>;
export type AccessPointPolicy = string;
export interface CreateAndAttachS3AccessPointS3Configuration {
    VpcConfiguration?: S3AccessPointVpcConfiguration;
    Policy?: string;
}
export declare const CreateAndAttachS3AccessPointS3Configuration: S.Schema<CreateAndAttachS3AccessPointS3Configuration>;
export interface CreateAndAttachS3AccessPointRequest {
    ClientRequestToken?: string;
    Name?: string;
    Type?: S3AccessPointAttachmentType;
    OpenZFSConfiguration?: CreateAndAttachS3AccessPointOpenZFSConfiguration;
    OntapConfiguration?: CreateAndAttachS3AccessPointOntapConfiguration;
    S3AccessPoint?: CreateAndAttachS3AccessPointS3Configuration;
}
export declare const CreateAndAttachS3AccessPointRequest: S.Schema<CreateAndAttachS3AccessPointRequest>;
export type S3AccessPointAttachmentLifecycle = "AVAILABLE" | "CREATING" | "DELETING" | "UPDATING" | "FAILED" | "MISCONFIGURED" | (string & {});
export declare const S3AccessPointAttachmentLifecycle: any;
export interface S3AccessPointOpenZFSConfiguration {
    VolumeId?: string;
    FileSystemIdentity?: OpenZFSFileSystemIdentity;
}
export declare const S3AccessPointOpenZFSConfiguration: S.Schema<S3AccessPointOpenZFSConfiguration>;
export interface S3AccessPointOntapConfiguration {
    VolumeId?: string;
    FileSystemIdentity?: OntapFileSystemIdentity;
}
export declare const S3AccessPointOntapConfiguration: S.Schema<S3AccessPointOntapConfiguration>;
export type S3AccessPointAlias = string;
export interface S3AccessPoint {
    ResourceARN?: string;
    Alias?: string;
    VpcConfiguration?: S3AccessPointVpcConfiguration;
}
export declare const S3AccessPoint: S.Schema<S3AccessPoint>;
export interface S3AccessPointAttachment {
    Lifecycle?: S3AccessPointAttachmentLifecycle;
    LifecycleTransitionReason?: LifecycleTransitionReason;
    CreationTime?: Date;
    Name?: string;
    Type?: S3AccessPointAttachmentType;
    OpenZFSConfiguration?: S3AccessPointOpenZFSConfiguration;
    OntapConfiguration?: S3AccessPointOntapConfiguration;
    S3AccessPoint?: S3AccessPoint;
}
export declare const S3AccessPointAttachment: S.Schema<S3AccessPointAttachment>;
export interface CreateAndAttachS3AccessPointResponse {
    S3AccessPointAttachment?: S3AccessPointAttachment & {
        OpenZFSConfiguration: S3AccessPointOpenZFSConfiguration & {
            FileSystemIdentity: OpenZFSFileSystemIdentity & {
                Type: OpenZFSFileSystemUserType;
                PosixUser: OpenZFSPosixFileSystemUser & {
                    Uid: FileSystemUID;
                    Gid: FileSystemGID;
                };
            };
        };
        OntapConfiguration: S3AccessPointOntapConfiguration & {
            FileSystemIdentity: OntapFileSystemIdentity & {
                Type: OntapFileSystemUserType;
                UnixUser: OntapUnixFileSystemUser & {
                    Name: OntapFileSystemUserName;
                };
                WindowsUser: OntapWindowsFileSystemUser & {
                    Name: OntapFileSystemUserName;
                };
            };
        };
    };
}
export declare const CreateAndAttachS3AccessPointResponse: S.Schema<CreateAndAttachS3AccessPointResponse>;
export interface CreateBackupRequest {
    FileSystemId?: string;
    ClientRequestToken?: string;
    Tags?: Tag[];
    VolumeId?: string;
}
export declare const CreateBackupRequest: S.Schema<CreateBackupRequest>;
export interface CreateBackupResponse {
    Backup?: Backup & {
        BackupId: BackupId;
        Lifecycle: BackupLifecycle;
        Type: BackupType;
        CreationTime: CreationTime;
        FileSystem: FileSystem & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            WindowsConfiguration: WindowsFileSystemConfiguration & {
                AuditLogConfiguration: WindowsAuditLogConfiguration & {
                    FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                };
                FsrmConfiguration: WindowsFsrmConfiguration & {
                    FsrmServiceEnabled: Flag;
                };
            };
            LustreConfiguration: LustreFileSystemConfiguration & {
                LogConfiguration: LustreLogConfiguration & {
                    Level: LustreAccessAuditLogLevel;
                };
                MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                    Mode: MetadataConfigurationMode;
                };
            };
            AdministrativeActions: (AdministrativeAction & {
                TargetVolumeValues: Volume & {
                    OntapConfiguration: OntapVolumeConfiguration & {
                        SnaplockConfiguration: SnaplockConfiguration & {
                            AutocommitPeriod: AutocommitPeriod & {
                                Type: AutocommitPeriodType;
                            };
                            RetentionPeriod: SnaplockRetentionPeriod & {
                                DefaultRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                                MinimumRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                                MaximumRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                            };
                        };
                    };
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                    OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                        NfsExports: (OpenZFSNfsExport & {
                            ClientConfigurations: (OpenZFSClientConfiguration & {
                                Clients: OpenZFSClients;
                                Options: OpenZFSNfsExportOptions;
                            })[];
                        })[];
                        UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                            Type: OpenZFSQuotaType;
                            Id: IntegerNoMax;
                            StorageCapacityQuotaGiB: IntegerNoMax;
                        })[];
                    };
                };
                TargetSnapshotValues: Snapshot & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
            })[];
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        Volume: Volume & {
            OntapConfiguration: OntapVolumeConfiguration & {
                SnaplockConfiguration: SnaplockConfiguration & {
                    AutocommitPeriod: AutocommitPeriod & {
                        Type: AutocommitPeriodType;
                    };
                    RetentionPeriod: SnaplockRetentionPeriod & {
                        DefaultRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MinimumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MaximumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                    };
                };
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            AdministrativeActions: (AdministrativeAction & {
                TargetFileSystemValues: FileSystem & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                    WindowsConfiguration: WindowsFileSystemConfiguration & {
                        AuditLogConfiguration: WindowsAuditLogConfiguration & {
                            FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                            FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        };
                        FsrmConfiguration: WindowsFsrmConfiguration & {
                            FsrmServiceEnabled: Flag;
                        };
                    };
                    LustreConfiguration: LustreFileSystemConfiguration & {
                        LogConfiguration: LustreLogConfiguration & {
                            Level: LustreAccessAuditLogLevel;
                        };
                        MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                            Mode: MetadataConfigurationMode;
                        };
                    };
                };
                TargetSnapshotValues: Snapshot & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
            })[];
            OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                NfsExports: (OpenZFSNfsExport & {
                    ClientConfigurations: (OpenZFSClientConfiguration & {
                        Clients: OpenZFSClients;
                        Options: OpenZFSNfsExportOptions;
                    })[];
                })[];
                UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                    Type: OpenZFSQuotaType;
                    Id: IntegerNoMax;
                    StorageCapacityQuotaGiB: IntegerNoMax;
                })[];
            };
        };
    };
}
export declare const CreateBackupResponse: S.Schema<CreateBackupResponse>;
export type Namespace = string;
export type BatchImportMetaDataOnCreate = boolean;
export type EventType = "NEW" | "CHANGED" | "DELETED" | (string & {});
export declare const EventType: any;
export type EventTypes = EventType[];
export declare const EventTypes: any;
export interface AutoImportPolicy {
    Events?: EventType[];
}
export declare const AutoImportPolicy: S.Schema<AutoImportPolicy>;
export interface AutoExportPolicy {
    Events?: EventType[];
}
export declare const AutoExportPolicy: S.Schema<AutoExportPolicy>;
export interface S3DataRepositoryConfiguration {
    AutoImportPolicy?: AutoImportPolicy;
    AutoExportPolicy?: AutoExportPolicy;
}
export declare const S3DataRepositoryConfiguration: S.Schema<S3DataRepositoryConfiguration>;
export interface CreateDataRepositoryAssociationRequest {
    FileSystemId?: string;
    FileSystemPath?: string;
    DataRepositoryPath?: string;
    BatchImportMetaDataOnCreate?: boolean;
    ImportedFileChunkSize?: number;
    S3?: S3DataRepositoryConfiguration;
    ClientRequestToken?: string;
    Tags?: Tag[];
}
export declare const CreateDataRepositoryAssociationRequest: S.Schema<CreateDataRepositoryAssociationRequest>;
export type DataRepositoryAssociationId = string;
export type FileCacheId = string;
export type SubDirectoriesPaths = string[];
export declare const SubDirectoriesPaths: any;
export type NfsVersion = "NFS3" | (string & {});
export declare const NfsVersion: any;
export type RepositoryDnsIps = string[];
export declare const RepositoryDnsIps: any;
export interface NFSDataRepositoryConfiguration {
    Version?: NfsVersion;
    DnsIps?: string[];
    AutoExportPolicy?: AutoExportPolicy;
}
export declare const NFSDataRepositoryConfiguration: S.Schema<NFSDataRepositoryConfiguration>;
export interface DataRepositoryAssociation {
    AssociationId?: string;
    ResourceARN?: string;
    FileSystemId?: string;
    Lifecycle?: DataRepositoryLifecycle;
    FailureDetails?: DataRepositoryFailureDetails;
    FileSystemPath?: string;
    DataRepositoryPath?: string;
    BatchImportMetaDataOnCreate?: boolean;
    ImportedFileChunkSize?: number;
    S3?: S3DataRepositoryConfiguration;
    Tags?: Tag[];
    CreationTime?: Date;
    FileCacheId?: string;
    FileCachePath?: string;
    DataRepositorySubdirectories?: string[];
    NFS?: NFSDataRepositoryConfiguration;
}
export declare const DataRepositoryAssociation: S.Schema<DataRepositoryAssociation>;
export interface CreateDataRepositoryAssociationResponse {
    Association?: DataRepositoryAssociation & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        NFS: NFSDataRepositoryConfiguration & {
            Version: NfsVersion;
        };
    };
}
export declare const CreateDataRepositoryAssociationResponse: S.Schema<CreateDataRepositoryAssociationResponse>;
export type DataRepositoryTaskType = "EXPORT_TO_REPOSITORY" | "IMPORT_METADATA_FROM_REPOSITORY" | "RELEASE_DATA_FROM_FILESYSTEM" | "AUTO_RELEASE_DATA" | (string & {});
export declare const DataRepositoryTaskType: any;
export type DataRepositoryTaskPath = string;
export type DataRepositoryTaskPaths = string[];
export declare const DataRepositoryTaskPaths: any;
export type ReportFormat = "REPORT_CSV_20191124" | (string & {});
export declare const ReportFormat: any;
export type ReportScope = "FAILED_FILES_ONLY" | (string & {});
export declare const ReportScope: any;
export interface CompletionReport {
    Enabled?: boolean;
    Path?: string;
    Format?: ReportFormat;
    Scope?: ReportScope;
}
export declare const CompletionReport: S.Schema<CompletionReport>;
export type CapacityToRelease = number;
export type Unit = "DAYS" | (string & {});
export declare const Unit: any;
export type Value = number;
export interface DurationSinceLastAccess {
    Unit?: Unit;
    Value?: number;
}
export declare const DurationSinceLastAccess: S.Schema<DurationSinceLastAccess>;
export interface ReleaseConfiguration {
    DurationSinceLastAccess?: DurationSinceLastAccess;
}
export declare const ReleaseConfiguration: S.Schema<ReleaseConfiguration>;
export interface CreateDataRepositoryTaskRequest {
    Type?: DataRepositoryTaskType;
    Paths?: string[];
    FileSystemId?: string;
    Report?: CompletionReport;
    ClientRequestToken?: string;
    Tags?: Tag[];
    CapacityToRelease?: number;
    ReleaseConfiguration?: ReleaseConfiguration;
}
export declare const CreateDataRepositoryTaskRequest: S.Schema<CreateDataRepositoryTaskRequest>;
export type StartTime = Date;
export type EndTime = Date;
export interface DataRepositoryTaskFailureDetails {
    Message?: string;
}
export declare const DataRepositoryTaskFailureDetails: S.Schema<DataRepositoryTaskFailureDetails>;
export type TotalCount = number;
export type SucceededCount = number;
export type FailedCount = number;
export type LastUpdatedTime = Date;
export type ReleasedCapacity = number;
export interface DataRepositoryTaskStatus {
    TotalCount?: number;
    SucceededCount?: number;
    FailedCount?: number;
    LastUpdatedTime?: Date;
    ReleasedCapacity?: number;
}
export declare const DataRepositoryTaskStatus: S.Schema<DataRepositoryTaskStatus>;
export interface DataRepositoryTask {
    TaskId?: string;
    Lifecycle?: DataRepositoryTaskLifecycle;
    Type?: DataRepositoryTaskType;
    CreationTime?: Date;
    StartTime?: Date;
    EndTime?: Date;
    ResourceARN?: string;
    Tags?: Tag[];
    FileSystemId?: string;
    Paths?: string[];
    FailureDetails?: DataRepositoryTaskFailureDetails;
    Status?: DataRepositoryTaskStatus;
    Report?: CompletionReport;
    CapacityToRelease?: number;
    FileCacheId?: string;
    ReleaseConfiguration?: ReleaseConfiguration;
}
export declare const DataRepositoryTask: S.Schema<DataRepositoryTask>;
export interface CreateDataRepositoryTaskResponse {
    DataRepositoryTask?: DataRepositoryTask & {
        TaskId: TaskId;
        Lifecycle: DataRepositoryTaskLifecycle;
        Type: DataRepositoryTaskType;
        CreationTime: CreationTime;
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        Report: CompletionReport & {
            Enabled: Flag;
        };
    };
}
export declare const CreateDataRepositoryTaskResponse: S.Schema<CreateDataRepositoryTaskResponse>;
export type FileCacheType = "LUSTRE" | (string & {});
export declare const FileCacheType: any;
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export declare const SecurityGroupIds: any;
export type CopyTagsToDataRepositoryAssociations = boolean;
export type FileCacheLustreDeploymentType = "CACHE_1" | (string & {});
export declare const FileCacheLustreDeploymentType: any;
export type MetadataStorageCapacity = number;
export interface FileCacheLustreMetadataConfiguration {
    StorageCapacity?: number;
}
export declare const FileCacheLustreMetadataConfiguration: S.Schema<FileCacheLustreMetadataConfiguration>;
export interface CreateFileCacheLustreConfiguration {
    PerUnitStorageThroughput?: number;
    DeploymentType?: FileCacheLustreDeploymentType;
    WeeklyMaintenanceStartTime?: string;
    MetadataConfiguration?: FileCacheLustreMetadataConfiguration;
}
export declare const CreateFileCacheLustreConfiguration: S.Schema<CreateFileCacheLustreConfiguration>;
export interface FileCacheNFSConfiguration {
    Version?: NfsVersion;
    DnsIps?: string[];
}
export declare const FileCacheNFSConfiguration: S.Schema<FileCacheNFSConfiguration>;
export interface FileCacheDataRepositoryAssociation {
    FileCachePath?: string;
    DataRepositoryPath?: string;
    DataRepositorySubdirectories?: string[];
    NFS?: FileCacheNFSConfiguration;
}
export declare const FileCacheDataRepositoryAssociation: S.Schema<FileCacheDataRepositoryAssociation>;
export type CreateFileCacheDataRepositoryAssociations = FileCacheDataRepositoryAssociation[];
export declare const CreateFileCacheDataRepositoryAssociations: any;
export interface CreateFileCacheRequest {
    ClientRequestToken?: string;
    FileCacheType?: FileCacheType;
    FileCacheTypeVersion?: string;
    StorageCapacity?: number;
    SubnetIds?: string[];
    SecurityGroupIds?: string[];
    Tags?: Tag[];
    CopyTagsToDataRepositoryAssociations?: boolean;
    KmsKeyId?: string;
    LustreConfiguration?: CreateFileCacheLustreConfiguration;
    DataRepositoryAssociations?: FileCacheDataRepositoryAssociation[];
}
export declare const CreateFileCacheRequest: S.Schema<CreateFileCacheRequest>;
export type FileCacheLifecycle = "AVAILABLE" | "CREATING" | "DELETING" | "UPDATING" | "FAILED" | (string & {});
export declare const FileCacheLifecycle: any;
export interface FileCacheFailureDetails {
    Message?: string;
}
export declare const FileCacheFailureDetails: S.Schema<FileCacheFailureDetails>;
export interface FileCacheLustreConfiguration {
    PerUnitStorageThroughput?: number;
    DeploymentType?: FileCacheLustreDeploymentType;
    MountName?: string;
    WeeklyMaintenanceStartTime?: string;
    MetadataConfiguration?: FileCacheLustreMetadataConfiguration;
    LogConfiguration?: LustreLogConfiguration;
}
export declare const FileCacheLustreConfiguration: S.Schema<FileCacheLustreConfiguration>;
export type DataRepositoryAssociationIds = string[];
export declare const DataRepositoryAssociationIds: any;
export interface FileCacheCreating {
    OwnerId?: string;
    CreationTime?: Date;
    FileCacheId?: string;
    FileCacheType?: FileCacheType;
    FileCacheTypeVersion?: string;
    Lifecycle?: FileCacheLifecycle;
    FailureDetails?: FileCacheFailureDetails;
    StorageCapacity?: number;
    VpcId?: string;
    SubnetIds?: string[];
    NetworkInterfaceIds?: string[];
    DNSName?: string;
    KmsKeyId?: string;
    ResourceARN?: string;
    Tags?: Tag[];
    CopyTagsToDataRepositoryAssociations?: boolean;
    LustreConfiguration?: FileCacheLustreConfiguration;
    DataRepositoryAssociationIds?: string[];
}
export declare const FileCacheCreating: S.Schema<FileCacheCreating>;
export interface CreateFileCacheResponse {
    FileCache?: FileCacheCreating & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        LustreConfiguration: FileCacheLustreConfiguration & {
            MetadataConfiguration: FileCacheLustreMetadataConfiguration & {
                StorageCapacity: MetadataStorageCapacity;
            };
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
        };
    };
}
export declare const CreateFileCacheResponse: S.Schema<CreateFileCacheResponse>;
export type DirectoryPassword = string | redacted.Redacted<string>;
export interface SelfManagedActiveDirectoryConfiguration {
    DomainName?: string;
    OrganizationalUnitDistinguishedName?: string;
    FileSystemAdministratorsGroup?: string;
    UserName?: string;
    Password?: string | redacted.Redacted<string>;
    DnsIps?: string[];
    DomainJoinServiceAccountSecret?: string;
}
export declare const SelfManagedActiveDirectoryConfiguration: S.Schema<SelfManagedActiveDirectoryConfiguration>;
export interface WindowsAuditLogCreateConfiguration {
    FileAccessAuditLogLevel?: WindowsAccessAuditLogLevel;
    FileShareAccessAuditLogLevel?: WindowsAccessAuditLogLevel;
    AuditLogDestination?: string;
}
export declare const WindowsAuditLogCreateConfiguration: S.Schema<WindowsAuditLogCreateConfiguration>;
export interface CreateFileSystemWindowsConfiguration {
    ActiveDirectoryId?: string;
    SelfManagedActiveDirectoryConfiguration?: SelfManagedActiveDirectoryConfiguration;
    DeploymentType?: WindowsDeploymentType;
    PreferredSubnetId?: string;
    ThroughputCapacity?: number;
    WeeklyMaintenanceStartTime?: string;
    DailyAutomaticBackupStartTime?: string;
    AutomaticBackupRetentionDays?: number;
    CopyTagsToBackups?: boolean;
    Aliases?: string[];
    AuditLogConfiguration?: WindowsAuditLogCreateConfiguration;
    DiskIopsConfiguration?: DiskIopsConfiguration;
    FsrmConfiguration?: WindowsFsrmConfiguration;
}
export declare const CreateFileSystemWindowsConfiguration: S.Schema<CreateFileSystemWindowsConfiguration>;
export interface LustreLogCreateConfiguration {
    Level?: LustreAccessAuditLogLevel;
    Destination?: string;
}
export declare const LustreLogCreateConfiguration: S.Schema<LustreLogCreateConfiguration>;
export interface CreateFileSystemLustreMetadataConfiguration {
    Iops?: number;
    Mode?: MetadataConfigurationMode;
}
export declare const CreateFileSystemLustreMetadataConfiguration: S.Schema<CreateFileSystemLustreMetadataConfiguration>;
export interface CreateFileSystemLustreConfiguration {
    WeeklyMaintenanceStartTime?: string;
    ImportPath?: string;
    ExportPath?: string;
    ImportedFileChunkSize?: number;
    DeploymentType?: LustreDeploymentType;
    AutoImportPolicy?: AutoImportPolicyType;
    PerUnitStorageThroughput?: number;
    DailyAutomaticBackupStartTime?: string;
    AutomaticBackupRetentionDays?: number;
    CopyTagsToBackups?: boolean;
    DriveCacheType?: DriveCacheType;
    DataCompressionType?: DataCompressionType;
    EfaEnabled?: boolean;
    LogConfiguration?: LustreLogCreateConfiguration;
    RootSquashConfiguration?: LustreRootSquashConfiguration;
    MetadataConfiguration?: CreateFileSystemLustreMetadataConfiguration;
    ThroughputCapacity?: number;
    DataReadCacheConfiguration?: LustreReadCacheConfiguration;
}
export declare const CreateFileSystemLustreConfiguration: S.Schema<CreateFileSystemLustreConfiguration>;
export interface CreateFileSystemOntapConfiguration {
    AutomaticBackupRetentionDays?: number;
    DailyAutomaticBackupStartTime?: string;
    DeploymentType?: OntapDeploymentType;
    EndpointIpAddressRange?: string;
    FsxAdminPassword?: string | redacted.Redacted<string>;
    DiskIopsConfiguration?: DiskIopsConfiguration;
    PreferredSubnetId?: string;
    RouteTableIds?: string[];
    ThroughputCapacity?: number;
    WeeklyMaintenanceStartTime?: string;
    HAPairs?: number;
    ThroughputCapacityPerHAPair?: number;
    EndpointIpv6AddressRange?: string;
}
export declare const CreateFileSystemOntapConfiguration: S.Schema<CreateFileSystemOntapConfiguration>;
export interface OpenZFSCreateRootVolumeConfiguration {
    RecordSizeKiB?: number;
    DataCompressionType?: OpenZFSDataCompressionType;
    NfsExports?: OpenZFSNfsExport[];
    UserAndGroupQuotas?: OpenZFSUserOrGroupQuota[];
    CopyTagsToSnapshots?: boolean;
    ReadOnly?: boolean;
}
export declare const OpenZFSCreateRootVolumeConfiguration: S.Schema<OpenZFSCreateRootVolumeConfiguration>;
export interface CreateFileSystemOpenZFSConfiguration {
    AutomaticBackupRetentionDays?: number;
    CopyTagsToBackups?: boolean;
    CopyTagsToVolumes?: boolean;
    DailyAutomaticBackupStartTime?: string;
    DeploymentType?: OpenZFSDeploymentType;
    ThroughputCapacity?: number;
    WeeklyMaintenanceStartTime?: string;
    DiskIopsConfiguration?: DiskIopsConfiguration;
    RootVolumeConfiguration?: OpenZFSCreateRootVolumeConfiguration;
    PreferredSubnetId?: string;
    EndpointIpAddressRange?: string;
    EndpointIpv6AddressRange?: string;
    RouteTableIds?: string[];
    ReadCacheConfiguration?: OpenZFSReadCacheConfiguration;
}
export declare const CreateFileSystemOpenZFSConfiguration: S.Schema<CreateFileSystemOpenZFSConfiguration>;
export interface CreateFileSystemRequest {
    ClientRequestToken?: string;
    FileSystemType?: FileSystemType;
    StorageCapacity?: number;
    StorageType?: StorageType;
    SubnetIds?: string[];
    SecurityGroupIds?: string[];
    Tags?: Tag[];
    KmsKeyId?: string;
    WindowsConfiguration?: CreateFileSystemWindowsConfiguration;
    LustreConfiguration?: CreateFileSystemLustreConfiguration;
    OntapConfiguration?: CreateFileSystemOntapConfiguration;
    FileSystemTypeVersion?: string;
    OpenZFSConfiguration?: CreateFileSystemOpenZFSConfiguration;
    NetworkType?: NetworkType;
}
export declare const CreateFileSystemRequest: S.Schema<CreateFileSystemRequest>;
export interface CreateFileSystemResponse {
    FileSystem?: FileSystem & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        WindowsConfiguration: WindowsFileSystemConfiguration & {
            AuditLogConfiguration: WindowsAuditLogConfiguration & {
                FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
            };
            FsrmConfiguration: WindowsFsrmConfiguration & {
                FsrmServiceEnabled: Flag;
            };
        };
        LustreConfiguration: LustreFileSystemConfiguration & {
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
            MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                Mode: MetadataConfigurationMode;
            };
        };
        AdministrativeActions: (AdministrativeAction & {
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
    };
}
export declare const CreateFileSystemResponse: S.Schema<CreateFileSystemResponse>;
export interface CreateFileSystemFromBackupRequest {
    BackupId?: string;
    ClientRequestToken?: string;
    SubnetIds?: string[];
    SecurityGroupIds?: string[];
    Tags?: Tag[];
    WindowsConfiguration?: CreateFileSystemWindowsConfiguration;
    LustreConfiguration?: CreateFileSystemLustreConfiguration;
    StorageType?: StorageType;
    KmsKeyId?: string;
    FileSystemTypeVersion?: string;
    OpenZFSConfiguration?: CreateFileSystemOpenZFSConfiguration;
    StorageCapacity?: number;
    NetworkType?: NetworkType;
}
export declare const CreateFileSystemFromBackupRequest: S.Schema<CreateFileSystemFromBackupRequest>;
export interface CreateFileSystemFromBackupResponse {
    FileSystem?: FileSystem & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        WindowsConfiguration: WindowsFileSystemConfiguration & {
            AuditLogConfiguration: WindowsAuditLogConfiguration & {
                FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
            };
            FsrmConfiguration: WindowsFsrmConfiguration & {
                FsrmServiceEnabled: Flag;
            };
        };
        LustreConfiguration: LustreFileSystemConfiguration & {
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
            MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                Mode: MetadataConfigurationMode;
            };
        };
        AdministrativeActions: (AdministrativeAction & {
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
    };
}
export declare const CreateFileSystemFromBackupResponse: S.Schema<CreateFileSystemFromBackupResponse>;
export interface CreateSnapshotRequest {
    ClientRequestToken?: string;
    Name?: string;
    VolumeId?: string;
    Tags?: Tag[];
}
export declare const CreateSnapshotRequest: S.Schema<CreateSnapshotRequest>;
export interface CreateSnapshotResponse {
    Snapshot?: Snapshot & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
        })[];
    };
}
export declare const CreateSnapshotResponse: S.Schema<CreateSnapshotResponse>;
export type NetBiosAlias = string;
export interface CreateSvmActiveDirectoryConfiguration {
    NetBiosName?: string;
    SelfManagedActiveDirectoryConfiguration?: SelfManagedActiveDirectoryConfiguration;
}
export declare const CreateSvmActiveDirectoryConfiguration: S.Schema<CreateSvmActiveDirectoryConfiguration>;
export type StorageVirtualMachineName = string;
export type StorageVirtualMachineRootVolumeSecurityStyle = "UNIX" | "NTFS" | "MIXED" | (string & {});
export declare const StorageVirtualMachineRootVolumeSecurityStyle: any;
export interface CreateStorageVirtualMachineRequest {
    ActiveDirectoryConfiguration?: CreateSvmActiveDirectoryConfiguration;
    ClientRequestToken?: string;
    FileSystemId?: string;
    Name?: string;
    SvmAdminPassword?: string | redacted.Redacted<string>;
    Tags?: Tag[];
    RootVolumeSecurityStyle?: StorageVirtualMachineRootVolumeSecurityStyle;
}
export declare const CreateStorageVirtualMachineRequest: S.Schema<CreateStorageVirtualMachineRequest>;
export interface SvmActiveDirectoryConfiguration {
    NetBiosName?: string;
    SelfManagedActiveDirectoryConfiguration?: SelfManagedActiveDirectoryAttributes;
}
export declare const SvmActiveDirectoryConfiguration: S.Schema<SvmActiveDirectoryConfiguration>;
export interface SvmEndpoint {
    DNSName?: string;
    IpAddresses?: string[];
    Ipv6Addresses?: string[];
}
export declare const SvmEndpoint: S.Schema<SvmEndpoint>;
export interface SvmEndpoints {
    Iscsi?: SvmEndpoint;
    Management?: SvmEndpoint;
    Nfs?: SvmEndpoint;
    Smb?: SvmEndpoint;
}
export declare const SvmEndpoints: S.Schema<SvmEndpoints>;
export type StorageVirtualMachineLifecycle = "CREATED" | "CREATING" | "DELETING" | "FAILED" | "MISCONFIGURED" | "PENDING" | (string & {});
export declare const StorageVirtualMachineLifecycle: any;
export type StorageVirtualMachineSubtype = "DEFAULT" | "DP_DESTINATION" | "SYNC_DESTINATION" | "SYNC_SOURCE" | (string & {});
export declare const StorageVirtualMachineSubtype: any;
export interface StorageVirtualMachine {
    ActiveDirectoryConfiguration?: SvmActiveDirectoryConfiguration;
    CreationTime?: Date;
    Endpoints?: SvmEndpoints;
    FileSystemId?: string;
    Lifecycle?: StorageVirtualMachineLifecycle;
    Name?: string;
    ResourceARN?: string;
    StorageVirtualMachineId?: string;
    Subtype?: StorageVirtualMachineSubtype;
    UUID?: string;
    Tags?: Tag[];
    LifecycleTransitionReason?: LifecycleTransitionReason;
    RootVolumeSecurityStyle?: StorageVirtualMachineRootVolumeSecurityStyle;
}
export declare const StorageVirtualMachine: S.Schema<StorageVirtualMachine>;
export interface CreateStorageVirtualMachineResponse {
    StorageVirtualMachine?: StorageVirtualMachine & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    };
}
export declare const CreateStorageVirtualMachineResponse: S.Schema<CreateStorageVirtualMachineResponse>;
export type InputOntapVolumeType = "RW" | "DP" | (string & {});
export declare const InputOntapVolumeType: any;
export interface CreateSnaplockConfiguration {
    AuditLogVolume?: boolean;
    AutocommitPeriod?: AutocommitPeriod;
    PrivilegedDelete?: PrivilegedDelete;
    RetentionPeriod?: SnaplockRetentionPeriod;
    SnaplockType?: SnaplockType;
    VolumeAppendModeEnabled?: boolean;
}
export declare const CreateSnaplockConfiguration: S.Schema<CreateSnaplockConfiguration>;
export type AggregateListMultiplier = number;
export interface CreateAggregateConfiguration {
    Aggregates?: string[];
    ConstituentsPerAggregate?: number;
}
export declare const CreateAggregateConfiguration: S.Schema<CreateAggregateConfiguration>;
export interface CreateOntapVolumeConfiguration {
    JunctionPath?: string;
    SecurityStyle?: SecurityStyle;
    SizeInMegabytes?: number;
    StorageEfficiencyEnabled?: boolean;
    StorageVirtualMachineId?: string;
    TieringPolicy?: TieringPolicy;
    OntapVolumeType?: InputOntapVolumeType;
    SnapshotPolicy?: string;
    CopyTagsToBackups?: boolean;
    SnaplockConfiguration?: CreateSnaplockConfiguration;
    VolumeStyle?: VolumeStyle;
    AggregateConfiguration?: CreateAggregateConfiguration;
    SizeInBytes?: number;
}
export declare const CreateOntapVolumeConfiguration: S.Schema<CreateOntapVolumeConfiguration>;
export type IntegerNoMaxFromNegativeOne = number;
export interface CreateOpenZFSOriginSnapshotConfiguration {
    SnapshotARN?: string;
    CopyStrategy?: OpenZFSCopyStrategy;
}
export declare const CreateOpenZFSOriginSnapshotConfiguration: S.Schema<CreateOpenZFSOriginSnapshotConfiguration>;
export interface CreateOpenZFSVolumeConfiguration {
    ParentVolumeId?: string;
    StorageCapacityReservationGiB?: number;
    StorageCapacityQuotaGiB?: number;
    RecordSizeKiB?: number;
    DataCompressionType?: OpenZFSDataCompressionType;
    CopyTagsToSnapshots?: boolean;
    OriginSnapshot?: CreateOpenZFSOriginSnapshotConfiguration;
    ReadOnly?: boolean;
    NfsExports?: OpenZFSNfsExport[];
    UserAndGroupQuotas?: OpenZFSUserOrGroupQuota[];
}
export declare const CreateOpenZFSVolumeConfiguration: S.Schema<CreateOpenZFSVolumeConfiguration>;
export interface CreateVolumeRequest {
    ClientRequestToken?: string;
    VolumeType?: VolumeType;
    Name?: string;
    OntapConfiguration?: CreateOntapVolumeConfiguration;
    Tags?: Tag[];
    OpenZFSConfiguration?: CreateOpenZFSVolumeConfiguration;
}
export declare const CreateVolumeRequest: S.Schema<CreateVolumeRequest>;
export interface CreateVolumeResponse {
    Volume?: Volume & {
        OntapConfiguration: OntapVolumeConfiguration & {
            SnaplockConfiguration: SnaplockConfiguration & {
                AutocommitPeriod: AutocommitPeriod & {
                    Type: AutocommitPeriodType;
                };
                RetentionPeriod: SnaplockRetentionPeriod & {
                    DefaultRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MinimumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MaximumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                };
            };
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
        OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
            NfsExports: (OpenZFSNfsExport & {
                ClientConfigurations: (OpenZFSClientConfiguration & {
                    Clients: OpenZFSClients;
                    Options: OpenZFSNfsExportOptions;
                })[];
            })[];
            UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                Type: OpenZFSQuotaType;
                Id: IntegerNoMax;
                StorageCapacityQuotaGiB: IntegerNoMax;
            })[];
        };
    };
}
export declare const CreateVolumeResponse: S.Schema<CreateVolumeResponse>;
export interface CreateVolumeFromBackupRequest {
    BackupId?: string;
    ClientRequestToken?: string;
    Name?: string;
    OntapConfiguration?: CreateOntapVolumeConfiguration;
    Tags?: Tag[];
}
export declare const CreateVolumeFromBackupRequest: S.Schema<CreateVolumeFromBackupRequest>;
export interface CreateVolumeFromBackupResponse {
    Volume?: Volume & {
        OntapConfiguration: OntapVolumeConfiguration & {
            SnaplockConfiguration: SnaplockConfiguration & {
                AutocommitPeriod: AutocommitPeriod & {
                    Type: AutocommitPeriodType;
                };
                RetentionPeriod: SnaplockRetentionPeriod & {
                    DefaultRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MinimumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MaximumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                };
            };
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
        OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
            NfsExports: (OpenZFSNfsExport & {
                ClientConfigurations: (OpenZFSClientConfiguration & {
                    Clients: OpenZFSClients;
                    Options: OpenZFSNfsExportOptions;
                })[];
            })[];
            UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                Type: OpenZFSQuotaType;
                Id: IntegerNoMax;
                StorageCapacityQuotaGiB: IntegerNoMax;
            })[];
        };
    };
}
export declare const CreateVolumeFromBackupResponse: S.Schema<CreateVolumeFromBackupResponse>;
export interface DeleteBackupRequest {
    BackupId?: string;
    ClientRequestToken?: string;
}
export declare const DeleteBackupRequest: S.Schema<DeleteBackupRequest>;
export interface DeleteBackupResponse {
    BackupId?: string;
    Lifecycle?: BackupLifecycle;
}
export declare const DeleteBackupResponse: S.Schema<DeleteBackupResponse>;
export type DeleteDataInFileSystem = boolean;
export interface DeleteDataRepositoryAssociationRequest {
    AssociationId?: string;
    ClientRequestToken?: string;
    DeleteDataInFileSystem?: boolean;
}
export declare const DeleteDataRepositoryAssociationRequest: S.Schema<DeleteDataRepositoryAssociationRequest>;
export interface DeleteDataRepositoryAssociationResponse {
    AssociationId?: string;
    Lifecycle?: DataRepositoryLifecycle;
    DeleteDataInFileSystem?: boolean;
}
export declare const DeleteDataRepositoryAssociationResponse: S.Schema<DeleteDataRepositoryAssociationResponse>;
export interface DeleteFileCacheRequest {
    FileCacheId?: string;
    ClientRequestToken?: string;
}
export declare const DeleteFileCacheRequest: S.Schema<DeleteFileCacheRequest>;
export interface DeleteFileCacheResponse {
    FileCacheId?: string;
    Lifecycle?: FileCacheLifecycle;
}
export declare const DeleteFileCacheResponse: S.Schema<DeleteFileCacheResponse>;
export interface DeleteFileSystemWindowsConfiguration {
    SkipFinalBackup?: boolean;
    FinalBackupTags?: Tag[];
}
export declare const DeleteFileSystemWindowsConfiguration: S.Schema<DeleteFileSystemWindowsConfiguration>;
export interface DeleteFileSystemLustreConfiguration {
    SkipFinalBackup?: boolean;
    FinalBackupTags?: Tag[];
}
export declare const DeleteFileSystemLustreConfiguration: S.Schema<DeleteFileSystemLustreConfiguration>;
export type DeleteFileSystemOpenZFSOption = "DELETE_CHILD_VOLUMES_AND_SNAPSHOTS" | (string & {});
export declare const DeleteFileSystemOpenZFSOption: any;
export type DeleteFileSystemOpenZFSOptions = DeleteFileSystemOpenZFSOption[];
export declare const DeleteFileSystemOpenZFSOptions: any;
export interface DeleteFileSystemOpenZFSConfiguration {
    SkipFinalBackup?: boolean;
    FinalBackupTags?: Tag[];
    Options?: DeleteFileSystemOpenZFSOption[];
}
export declare const DeleteFileSystemOpenZFSConfiguration: S.Schema<DeleteFileSystemOpenZFSConfiguration>;
export interface DeleteFileSystemRequest {
    FileSystemId?: string;
    ClientRequestToken?: string;
    WindowsConfiguration?: DeleteFileSystemWindowsConfiguration;
    LustreConfiguration?: DeleteFileSystemLustreConfiguration;
    OpenZFSConfiguration?: DeleteFileSystemOpenZFSConfiguration;
}
export declare const DeleteFileSystemRequest: S.Schema<DeleteFileSystemRequest>;
export interface DeleteFileSystemWindowsResponse {
    FinalBackupId?: string;
    FinalBackupTags?: Tag[];
}
export declare const DeleteFileSystemWindowsResponse: S.Schema<DeleteFileSystemWindowsResponse>;
export interface DeleteFileSystemLustreResponse {
    FinalBackupId?: string;
    FinalBackupTags?: Tag[];
}
export declare const DeleteFileSystemLustreResponse: S.Schema<DeleteFileSystemLustreResponse>;
export interface DeleteFileSystemOpenZFSResponse {
    FinalBackupId?: string;
    FinalBackupTags?: Tag[];
}
export declare const DeleteFileSystemOpenZFSResponse: S.Schema<DeleteFileSystemOpenZFSResponse>;
export interface DeleteFileSystemResponse {
    FileSystemId?: string;
    Lifecycle?: FileSystemLifecycle;
    WindowsResponse?: DeleteFileSystemWindowsResponse & {
        FinalBackupTags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    };
    LustreResponse?: DeleteFileSystemLustreResponse & {
        FinalBackupTags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    };
    OpenZFSResponse?: DeleteFileSystemOpenZFSResponse & {
        FinalBackupTags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    };
}
export declare const DeleteFileSystemResponse: S.Schema<DeleteFileSystemResponse>;
export interface DeleteSnapshotRequest {
    ClientRequestToken?: string;
    SnapshotId?: string;
}
export declare const DeleteSnapshotRequest: S.Schema<DeleteSnapshotRequest>;
export interface DeleteSnapshotResponse {
    SnapshotId?: string;
    Lifecycle?: SnapshotLifecycle;
}
export declare const DeleteSnapshotResponse: S.Schema<DeleteSnapshotResponse>;
export interface DeleteStorageVirtualMachineRequest {
    ClientRequestToken?: string;
    StorageVirtualMachineId?: string;
}
export declare const DeleteStorageVirtualMachineRequest: S.Schema<DeleteStorageVirtualMachineRequest>;
export interface DeleteStorageVirtualMachineResponse {
    StorageVirtualMachineId?: string;
    Lifecycle?: StorageVirtualMachineLifecycle;
}
export declare const DeleteStorageVirtualMachineResponse: S.Schema<DeleteStorageVirtualMachineResponse>;
export interface DeleteVolumeOntapConfiguration {
    SkipFinalBackup?: boolean;
    FinalBackupTags?: Tag[];
    BypassSnaplockEnterpriseRetention?: boolean;
}
export declare const DeleteVolumeOntapConfiguration: S.Schema<DeleteVolumeOntapConfiguration>;
export type DeleteOpenZFSVolumeOption = "DELETE_CHILD_VOLUMES_AND_SNAPSHOTS" | (string & {});
export declare const DeleteOpenZFSVolumeOption: any;
export type DeleteOpenZFSVolumeOptions = DeleteOpenZFSVolumeOption[];
export declare const DeleteOpenZFSVolumeOptions: any;
export interface DeleteVolumeOpenZFSConfiguration {
    Options?: DeleteOpenZFSVolumeOption[];
}
export declare const DeleteVolumeOpenZFSConfiguration: S.Schema<DeleteVolumeOpenZFSConfiguration>;
export interface DeleteVolumeRequest {
    ClientRequestToken?: string;
    VolumeId?: string;
    OntapConfiguration?: DeleteVolumeOntapConfiguration;
    OpenZFSConfiguration?: DeleteVolumeOpenZFSConfiguration;
}
export declare const DeleteVolumeRequest: S.Schema<DeleteVolumeRequest>;
export interface DeleteVolumeOntapResponse {
    FinalBackupId?: string;
    FinalBackupTags?: Tag[];
}
export declare const DeleteVolumeOntapResponse: S.Schema<DeleteVolumeOntapResponse>;
export interface DeleteVolumeResponse {
    VolumeId?: string;
    Lifecycle?: VolumeLifecycle;
    OntapResponse?: DeleteVolumeOntapResponse & {
        FinalBackupTags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    };
}
export declare const DeleteVolumeResponse: S.Schema<DeleteVolumeResponse>;
export type BackupIds = string[];
export declare const BackupIds: any;
export type FilterName = "file-system-id" | "backup-type" | "file-system-type" | "volume-id" | "data-repository-type" | "file-cache-id" | "file-cache-type" | (string & {});
export declare const FilterName: any;
export type FilterValue = string;
export type FilterValues = string[];
export declare const FilterValues: any;
export interface Filter {
    Name?: FilterName;
    Values?: string[];
}
export declare const Filter: S.Schema<Filter>;
export type Filters = Filter[];
export declare const Filters: any;
export type MaxResults = number;
export type NextToken = string;
export interface DescribeBackupsRequest {
    BackupIds?: string[];
    Filters?: Filter[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeBackupsRequest: S.Schema<DescribeBackupsRequest>;
export type Backups = Backup[];
export declare const Backups: any;
export interface DescribeBackupsResponse {
    Backups?: (Backup & {
        BackupId: BackupId;
        Lifecycle: BackupLifecycle;
        Type: BackupType;
        CreationTime: CreationTime;
        FileSystem: FileSystem & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            WindowsConfiguration: WindowsFileSystemConfiguration & {
                AuditLogConfiguration: WindowsAuditLogConfiguration & {
                    FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                };
                FsrmConfiguration: WindowsFsrmConfiguration & {
                    FsrmServiceEnabled: Flag;
                };
            };
            LustreConfiguration: LustreFileSystemConfiguration & {
                LogConfiguration: LustreLogConfiguration & {
                    Level: LustreAccessAuditLogLevel;
                };
                MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                    Mode: MetadataConfigurationMode;
                };
            };
            AdministrativeActions: (AdministrativeAction & {
                TargetVolumeValues: Volume & {
                    OntapConfiguration: OntapVolumeConfiguration & {
                        SnaplockConfiguration: SnaplockConfiguration & {
                            AutocommitPeriod: AutocommitPeriod & {
                                Type: AutocommitPeriodType;
                            };
                            RetentionPeriod: SnaplockRetentionPeriod & {
                                DefaultRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                                MinimumRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                                MaximumRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                            };
                        };
                    };
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                    OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                        NfsExports: (OpenZFSNfsExport & {
                            ClientConfigurations: (OpenZFSClientConfiguration & {
                                Clients: OpenZFSClients;
                                Options: OpenZFSNfsExportOptions;
                            })[];
                        })[];
                        UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                            Type: OpenZFSQuotaType;
                            Id: IntegerNoMax;
                            StorageCapacityQuotaGiB: IntegerNoMax;
                        })[];
                    };
                };
                TargetSnapshotValues: Snapshot & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
            })[];
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        Volume: Volume & {
            OntapConfiguration: OntapVolumeConfiguration & {
                SnaplockConfiguration: SnaplockConfiguration & {
                    AutocommitPeriod: AutocommitPeriod & {
                        Type: AutocommitPeriodType;
                    };
                    RetentionPeriod: SnaplockRetentionPeriod & {
                        DefaultRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MinimumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MaximumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                    };
                };
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            AdministrativeActions: (AdministrativeAction & {
                TargetFileSystemValues: FileSystem & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                    WindowsConfiguration: WindowsFileSystemConfiguration & {
                        AuditLogConfiguration: WindowsAuditLogConfiguration & {
                            FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                            FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        };
                        FsrmConfiguration: WindowsFsrmConfiguration & {
                            FsrmServiceEnabled: Flag;
                        };
                    };
                    LustreConfiguration: LustreFileSystemConfiguration & {
                        LogConfiguration: LustreLogConfiguration & {
                            Level: LustreAccessAuditLogLevel;
                        };
                        MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                            Mode: MetadataConfigurationMode;
                        };
                    };
                };
                TargetSnapshotValues: Snapshot & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
            })[];
            OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                NfsExports: (OpenZFSNfsExport & {
                    ClientConfigurations: (OpenZFSClientConfiguration & {
                        Clients: OpenZFSClients;
                        Options: OpenZFSNfsExportOptions;
                    })[];
                })[];
                UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                    Type: OpenZFSQuotaType;
                    Id: IntegerNoMax;
                    StorageCapacityQuotaGiB: IntegerNoMax;
                })[];
            };
        };
    })[];
    NextToken?: string;
}
export declare const DescribeBackupsResponse: S.Schema<DescribeBackupsResponse>;
export type LimitedMaxResults = number;
export interface DescribeDataRepositoryAssociationsRequest {
    AssociationIds?: string[];
    Filters?: Filter[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeDataRepositoryAssociationsRequest: S.Schema<DescribeDataRepositoryAssociationsRequest>;
export type DataRepositoryAssociations = DataRepositoryAssociation[];
export declare const DataRepositoryAssociations: any;
export interface DescribeDataRepositoryAssociationsResponse {
    Associations?: (DataRepositoryAssociation & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        NFS: NFSDataRepositoryConfiguration & {
            Version: NfsVersion;
        };
    })[];
    NextToken?: string;
}
export declare const DescribeDataRepositoryAssociationsResponse: S.Schema<DescribeDataRepositoryAssociationsResponse>;
export type TaskIds = string[];
export declare const TaskIds: any;
export type DataRepositoryTaskFilterName = "file-system-id" | "task-lifecycle" | "data-repository-association-id" | "file-cache-id" | (string & {});
export declare const DataRepositoryTaskFilterName: any;
export type DataRepositoryTaskFilterValue = string;
export type DataRepositoryTaskFilterValues = string[];
export declare const DataRepositoryTaskFilterValues: any;
export interface DataRepositoryTaskFilter {
    Name?: DataRepositoryTaskFilterName;
    Values?: string[];
}
export declare const DataRepositoryTaskFilter: S.Schema<DataRepositoryTaskFilter>;
export type DataRepositoryTaskFilters = DataRepositoryTaskFilter[];
export declare const DataRepositoryTaskFilters: any;
export interface DescribeDataRepositoryTasksRequest {
    TaskIds?: string[];
    Filters?: DataRepositoryTaskFilter[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeDataRepositoryTasksRequest: S.Schema<DescribeDataRepositoryTasksRequest>;
export type DataRepositoryTasks = DataRepositoryTask[];
export declare const DataRepositoryTasks: any;
export interface DescribeDataRepositoryTasksResponse {
    DataRepositoryTasks?: (DataRepositoryTask & {
        TaskId: TaskId;
        Lifecycle: DataRepositoryTaskLifecycle;
        Type: DataRepositoryTaskType;
        CreationTime: CreationTime;
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        Report: CompletionReport & {
            Enabled: Flag;
        };
    })[];
    NextToken?: string;
}
export declare const DescribeDataRepositoryTasksResponse: S.Schema<DescribeDataRepositoryTasksResponse>;
export type FileCacheIds = string[];
export declare const FileCacheIds: any;
export interface DescribeFileCachesRequest {
    FileCacheIds?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeFileCachesRequest: S.Schema<DescribeFileCachesRequest>;
export interface FileCache {
    OwnerId?: string;
    CreationTime?: Date;
    FileCacheId?: string;
    FileCacheType?: FileCacheType;
    FileCacheTypeVersion?: string;
    Lifecycle?: FileCacheLifecycle;
    FailureDetails?: FileCacheFailureDetails;
    StorageCapacity?: number;
    VpcId?: string;
    SubnetIds?: string[];
    NetworkInterfaceIds?: string[];
    DNSName?: string;
    KmsKeyId?: string;
    ResourceARN?: string;
    LustreConfiguration?: FileCacheLustreConfiguration;
    DataRepositoryAssociationIds?: string[];
}
export declare const FileCache: S.Schema<FileCache>;
export type FileCaches = FileCache[];
export declare const FileCaches: any;
export interface DescribeFileCachesResponse {
    FileCaches?: (FileCache & {
        LustreConfiguration: FileCacheLustreConfiguration & {
            MetadataConfiguration: FileCacheLustreMetadataConfiguration & {
                StorageCapacity: MetadataStorageCapacity;
            };
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
        };
    })[];
    NextToken?: string;
}
export declare const DescribeFileCachesResponse: S.Schema<DescribeFileCachesResponse>;
export interface DescribeFileSystemAliasesRequest {
    ClientRequestToken?: string;
    FileSystemId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeFileSystemAliasesRequest: S.Schema<DescribeFileSystemAliasesRequest>;
export interface DescribeFileSystemAliasesResponse {
    Aliases?: Alias[];
    NextToken?: string;
}
export declare const DescribeFileSystemAliasesResponse: S.Schema<DescribeFileSystemAliasesResponse>;
export type FileSystemIds = string[];
export declare const FileSystemIds: any;
export interface DescribeFileSystemsRequest {
    FileSystemIds?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeFileSystemsRequest: S.Schema<DescribeFileSystemsRequest>;
export type FileSystems = FileSystem[];
export declare const FileSystems: any;
export interface DescribeFileSystemsResponse {
    FileSystems?: (FileSystem & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        WindowsConfiguration: WindowsFileSystemConfiguration & {
            AuditLogConfiguration: WindowsAuditLogConfiguration & {
                FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
            };
            FsrmConfiguration: WindowsFsrmConfiguration & {
                FsrmServiceEnabled: Flag;
            };
        };
        LustreConfiguration: LustreFileSystemConfiguration & {
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
            MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                Mode: MetadataConfigurationMode;
            };
        };
        AdministrativeActions: (AdministrativeAction & {
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
    })[];
    NextToken?: string;
}
export declare const DescribeFileSystemsResponse: S.Schema<DescribeFileSystemsResponse>;
export type S3AccessPointAttachmentNames = string[];
export declare const S3AccessPointAttachmentNames: any;
export type S3AccessPointAttachmentsFilterName = "file-system-id" | "volume-id" | "type" | (string & {});
export declare const S3AccessPointAttachmentsFilterName: any;
export type S3AccessPointAttachmentsFilterValue = string;
export type S3AccessPointAttachmentsFilterValues = string[];
export declare const S3AccessPointAttachmentsFilterValues: any;
export interface S3AccessPointAttachmentsFilter {
    Name?: S3AccessPointAttachmentsFilterName;
    Values?: string[];
}
export declare const S3AccessPointAttachmentsFilter: S.Schema<S3AccessPointAttachmentsFilter>;
export type S3AccessPointAttachmentsFilters = S3AccessPointAttachmentsFilter[];
export declare const S3AccessPointAttachmentsFilters: any;
export interface DescribeS3AccessPointAttachmentsRequest {
    Names?: string[];
    Filters?: S3AccessPointAttachmentsFilter[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeS3AccessPointAttachmentsRequest: S.Schema<DescribeS3AccessPointAttachmentsRequest>;
export type S3AccessPointAttachments = S3AccessPointAttachment[];
export declare const S3AccessPointAttachments: any;
export interface DescribeS3AccessPointAttachmentsResponse {
    S3AccessPointAttachments?: (S3AccessPointAttachment & {
        OpenZFSConfiguration: S3AccessPointOpenZFSConfiguration & {
            FileSystemIdentity: OpenZFSFileSystemIdentity & {
                Type: OpenZFSFileSystemUserType;
                PosixUser: OpenZFSPosixFileSystemUser & {
                    Uid: FileSystemUID;
                    Gid: FileSystemGID;
                };
            };
        };
        OntapConfiguration: S3AccessPointOntapConfiguration & {
            FileSystemIdentity: OntapFileSystemIdentity & {
                Type: OntapFileSystemUserType;
                UnixUser: OntapUnixFileSystemUser & {
                    Name: OntapFileSystemUserName;
                };
                WindowsUser: OntapWindowsFileSystemUser & {
                    Name: OntapFileSystemUserName;
                };
            };
        };
    })[];
    NextToken?: string;
}
export declare const DescribeS3AccessPointAttachmentsResponse: S.Schema<DescribeS3AccessPointAttachmentsResponse>;
export interface DescribeSharedVpcConfigurationRequest {
}
export declare const DescribeSharedVpcConfigurationRequest: S.Schema<DescribeSharedVpcConfigurationRequest>;
export type VerboseFlag = string;
export interface DescribeSharedVpcConfigurationResponse {
    EnableFsxRouteTableUpdatesFromParticipantAccounts?: string;
}
export declare const DescribeSharedVpcConfigurationResponse: S.Schema<DescribeSharedVpcConfigurationResponse>;
export type SnapshotIds = string[];
export declare const SnapshotIds: any;
export type SnapshotFilterName = "file-system-id" | "volume-id" | (string & {});
export declare const SnapshotFilterName: any;
export type SnapshotFilterValue = string;
export type SnapshotFilterValues = string[];
export declare const SnapshotFilterValues: any;
export interface SnapshotFilter {
    Name?: SnapshotFilterName;
    Values?: string[];
}
export declare const SnapshotFilter: S.Schema<SnapshotFilter>;
export type SnapshotFilters = SnapshotFilter[];
export declare const SnapshotFilters: any;
export type IncludeShared = boolean;
export interface DescribeSnapshotsRequest {
    SnapshotIds?: string[];
    Filters?: SnapshotFilter[];
    MaxResults?: number;
    NextToken?: string;
    IncludeShared?: boolean;
}
export declare const DescribeSnapshotsRequest: S.Schema<DescribeSnapshotsRequest>;
export type Snapshots = Snapshot[];
export declare const Snapshots: any;
export interface DescribeSnapshotsResponse {
    Snapshots?: (Snapshot & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
        })[];
    })[];
    NextToken?: string;
}
export declare const DescribeSnapshotsResponse: S.Schema<DescribeSnapshotsResponse>;
export type StorageVirtualMachineIds = string[];
export declare const StorageVirtualMachineIds: any;
export type StorageVirtualMachineFilterName = "file-system-id" | (string & {});
export declare const StorageVirtualMachineFilterName: any;
export type StorageVirtualMachineFilterValue = string;
export type StorageVirtualMachineFilterValues = string[];
export declare const StorageVirtualMachineFilterValues: any;
export interface StorageVirtualMachineFilter {
    Name?: StorageVirtualMachineFilterName;
    Values?: string[];
}
export declare const StorageVirtualMachineFilter: S.Schema<StorageVirtualMachineFilter>;
export type StorageVirtualMachineFilters = StorageVirtualMachineFilter[];
export declare const StorageVirtualMachineFilters: any;
export interface DescribeStorageVirtualMachinesRequest {
    StorageVirtualMachineIds?: string[];
    Filters?: StorageVirtualMachineFilter[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeStorageVirtualMachinesRequest: S.Schema<DescribeStorageVirtualMachinesRequest>;
export type StorageVirtualMachines = StorageVirtualMachine[];
export declare const StorageVirtualMachines: any;
export interface DescribeStorageVirtualMachinesResponse {
    StorageVirtualMachines?: (StorageVirtualMachine & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    })[];
    NextToken?: string;
}
export declare const DescribeStorageVirtualMachinesResponse: S.Schema<DescribeStorageVirtualMachinesResponse>;
export type VolumeIds = string[];
export declare const VolumeIds: any;
export type VolumeFilterName = "file-system-id" | "storage-virtual-machine-id" | (string & {});
export declare const VolumeFilterName: any;
export type VolumeFilterValue = string;
export type VolumeFilterValues = string[];
export declare const VolumeFilterValues: any;
export interface VolumeFilter {
    Name?: VolumeFilterName;
    Values?: string[];
}
export declare const VolumeFilter: S.Schema<VolumeFilter>;
export type VolumeFilters = VolumeFilter[];
export declare const VolumeFilters: any;
export interface DescribeVolumesRequest {
    VolumeIds?: string[];
    Filters?: VolumeFilter[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeVolumesRequest: S.Schema<DescribeVolumesRequest>;
export type Volumes = Volume[];
export declare const Volumes: any;
export interface DescribeVolumesResponse {
    Volumes?: (Volume & {
        OntapConfiguration: OntapVolumeConfiguration & {
            SnaplockConfiguration: SnaplockConfiguration & {
                AutocommitPeriod: AutocommitPeriod & {
                    Type: AutocommitPeriodType;
                };
                RetentionPeriod: SnaplockRetentionPeriod & {
                    DefaultRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MinimumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MaximumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                };
            };
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
        OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
            NfsExports: (OpenZFSNfsExport & {
                ClientConfigurations: (OpenZFSClientConfiguration & {
                    Clients: OpenZFSClients;
                    Options: OpenZFSNfsExportOptions;
                })[];
            })[];
            UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                Type: OpenZFSQuotaType;
                Id: IntegerNoMax;
                StorageCapacityQuotaGiB: IntegerNoMax;
            })[];
        };
    })[];
    NextToken?: string;
}
export declare const DescribeVolumesResponse: S.Schema<DescribeVolumesResponse>;
export interface DetachAndDeleteS3AccessPointRequest {
    ClientRequestToken?: string;
    Name?: string;
}
export declare const DetachAndDeleteS3AccessPointRequest: S.Schema<DetachAndDeleteS3AccessPointRequest>;
export interface DetachAndDeleteS3AccessPointResponse {
    Lifecycle?: S3AccessPointAttachmentLifecycle;
    Name?: string;
}
export declare const DetachAndDeleteS3AccessPointResponse: S.Schema<DetachAndDeleteS3AccessPointResponse>;
export interface DisassociateFileSystemAliasesRequest {
    ClientRequestToken?: string;
    FileSystemId?: string;
    Aliases?: string[];
}
export declare const DisassociateFileSystemAliasesRequest: S.Schema<DisassociateFileSystemAliasesRequest>;
export interface DisassociateFileSystemAliasesResponse {
    Aliases?: Alias[];
}
export declare const DisassociateFileSystemAliasesResponse: S.Schema<DisassociateFileSystemAliasesResponse>;
export interface ListTagsForResourceRequest {
    ResourceARN?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: (Tag & {
        Key: TagKey;
        Value: TagValue;
    })[];
    NextToken?: string;
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ReleaseFileSystemNfsV3LocksRequest {
    FileSystemId?: string;
    ClientRequestToken?: string;
}
export declare const ReleaseFileSystemNfsV3LocksRequest: S.Schema<ReleaseFileSystemNfsV3LocksRequest>;
export interface ReleaseFileSystemNfsV3LocksResponse {
    FileSystem?: FileSystem & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        WindowsConfiguration: WindowsFileSystemConfiguration & {
            AuditLogConfiguration: WindowsAuditLogConfiguration & {
                FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
            };
            FsrmConfiguration: WindowsFsrmConfiguration & {
                FsrmServiceEnabled: Flag;
            };
        };
        LustreConfiguration: LustreFileSystemConfiguration & {
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
            MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                Mode: MetadataConfigurationMode;
            };
        };
        AdministrativeActions: (AdministrativeAction & {
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
    };
}
export declare const ReleaseFileSystemNfsV3LocksResponse: S.Schema<ReleaseFileSystemNfsV3LocksResponse>;
export type RestoreOpenZFSVolumeOption = "DELETE_INTERMEDIATE_SNAPSHOTS" | "DELETE_CLONED_VOLUMES" | (string & {});
export declare const RestoreOpenZFSVolumeOption: any;
export type RestoreOpenZFSVolumeOptions = RestoreOpenZFSVolumeOption[];
export declare const RestoreOpenZFSVolumeOptions: any;
export interface RestoreVolumeFromSnapshotRequest {
    ClientRequestToken?: string;
    VolumeId?: string;
    SnapshotId?: string;
    Options?: RestoreOpenZFSVolumeOption[];
}
export declare const RestoreVolumeFromSnapshotRequest: S.Schema<RestoreVolumeFromSnapshotRequest>;
export interface RestoreVolumeFromSnapshotResponse {
    VolumeId?: string;
    Lifecycle?: VolumeLifecycle;
    AdministrativeActions?: (AdministrativeAction & {
        TargetFileSystemValues: FileSystem & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            WindowsConfiguration: WindowsFileSystemConfiguration & {
                AuditLogConfiguration: WindowsAuditLogConfiguration & {
                    FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                };
                FsrmConfiguration: WindowsFsrmConfiguration & {
                    FsrmServiceEnabled: Flag;
                };
            };
            LustreConfiguration: LustreFileSystemConfiguration & {
                LogConfiguration: LustreLogConfiguration & {
                    Level: LustreAccessAuditLogLevel;
                };
                MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                    Mode: MetadataConfigurationMode;
                };
            };
        };
        TargetVolumeValues: Volume & {
            OntapConfiguration: OntapVolumeConfiguration & {
                SnaplockConfiguration: SnaplockConfiguration & {
                    AutocommitPeriod: AutocommitPeriod & {
                        Type: AutocommitPeriodType;
                    };
                    RetentionPeriod: SnaplockRetentionPeriod & {
                        DefaultRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MinimumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MaximumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                    };
                };
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                NfsExports: (OpenZFSNfsExport & {
                    ClientConfigurations: (OpenZFSClientConfiguration & {
                        Clients: OpenZFSClients;
                        Options: OpenZFSNfsExportOptions;
                    })[];
                })[];
                UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                    Type: OpenZFSQuotaType;
                    Id: IntegerNoMax;
                    StorageCapacityQuotaGiB: IntegerNoMax;
                })[];
            };
        };
        TargetSnapshotValues: Snapshot & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
    })[];
}
export declare const RestoreVolumeFromSnapshotResponse: S.Schema<RestoreVolumeFromSnapshotResponse>;
export interface StartMisconfiguredStateRecoveryRequest {
    ClientRequestToken?: string;
    FileSystemId?: string;
}
export declare const StartMisconfiguredStateRecoveryRequest: S.Schema<StartMisconfiguredStateRecoveryRequest>;
export interface StartMisconfiguredStateRecoveryResponse {
    FileSystem?: FileSystem & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        WindowsConfiguration: WindowsFileSystemConfiguration & {
            AuditLogConfiguration: WindowsAuditLogConfiguration & {
                FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
            };
            FsrmConfiguration: WindowsFsrmConfiguration & {
                FsrmServiceEnabled: Flag;
            };
        };
        LustreConfiguration: LustreFileSystemConfiguration & {
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
            MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                Mode: MetadataConfigurationMode;
            };
        };
        AdministrativeActions: (AdministrativeAction & {
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
    };
}
export declare const StartMisconfiguredStateRecoveryResponse: S.Schema<StartMisconfiguredStateRecoveryResponse>;
export interface TagResourceRequest {
    ResourceARN?: string;
    Tags?: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    ResourceARN?: string;
    TagKeys?: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateDataRepositoryAssociationRequest {
    AssociationId?: string;
    ClientRequestToken?: string;
    ImportedFileChunkSize?: number;
    S3?: S3DataRepositoryConfiguration;
}
export declare const UpdateDataRepositoryAssociationRequest: S.Schema<UpdateDataRepositoryAssociationRequest>;
export interface UpdateDataRepositoryAssociationResponse {
    Association?: DataRepositoryAssociation & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        NFS: NFSDataRepositoryConfiguration & {
            Version: NfsVersion;
        };
    };
}
export declare const UpdateDataRepositoryAssociationResponse: S.Schema<UpdateDataRepositoryAssociationResponse>;
export interface UpdateFileCacheLustreConfiguration {
    WeeklyMaintenanceStartTime?: string;
}
export declare const UpdateFileCacheLustreConfiguration: S.Schema<UpdateFileCacheLustreConfiguration>;
export interface UpdateFileCacheRequest {
    FileCacheId?: string;
    ClientRequestToken?: string;
    LustreConfiguration?: UpdateFileCacheLustreConfiguration;
}
export declare const UpdateFileCacheRequest: S.Schema<UpdateFileCacheRequest>;
export interface UpdateFileCacheResponse {
    FileCache?: FileCache & {
        LustreConfiguration: FileCacheLustreConfiguration & {
            MetadataConfiguration: FileCacheLustreMetadataConfiguration & {
                StorageCapacity: MetadataStorageCapacity;
            };
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
        };
    };
}
export declare const UpdateFileCacheResponse: S.Schema<UpdateFileCacheResponse>;
export interface SelfManagedActiveDirectoryConfigurationUpdates {
    UserName?: string;
    Password?: string | redacted.Redacted<string>;
    DnsIps?: string[];
    DomainName?: string;
    OrganizationalUnitDistinguishedName?: string;
    FileSystemAdministratorsGroup?: string;
    DomainJoinServiceAccountSecret?: string;
}
export declare const SelfManagedActiveDirectoryConfigurationUpdates: S.Schema<SelfManagedActiveDirectoryConfigurationUpdates>;
export interface UpdateFileSystemWindowsConfiguration {
    WeeklyMaintenanceStartTime?: string;
    DailyAutomaticBackupStartTime?: string;
    AutomaticBackupRetentionDays?: number;
    ThroughputCapacity?: number;
    SelfManagedActiveDirectoryConfiguration?: SelfManagedActiveDirectoryConfigurationUpdates;
    AuditLogConfiguration?: WindowsAuditLogCreateConfiguration;
    DiskIopsConfiguration?: DiskIopsConfiguration;
    FsrmConfiguration?: WindowsFsrmConfiguration;
}
export declare const UpdateFileSystemWindowsConfiguration: S.Schema<UpdateFileSystemWindowsConfiguration>;
export interface UpdateFileSystemLustreMetadataConfiguration {
    Iops?: number;
    Mode?: MetadataConfigurationMode;
}
export declare const UpdateFileSystemLustreMetadataConfiguration: S.Schema<UpdateFileSystemLustreMetadataConfiguration>;
export interface UpdateFileSystemLustreConfiguration {
    WeeklyMaintenanceStartTime?: string;
    DailyAutomaticBackupStartTime?: string;
    AutomaticBackupRetentionDays?: number;
    AutoImportPolicy?: AutoImportPolicyType;
    DataCompressionType?: DataCompressionType;
    LogConfiguration?: LustreLogCreateConfiguration;
    RootSquashConfiguration?: LustreRootSquashConfiguration;
    PerUnitStorageThroughput?: number;
    MetadataConfiguration?: UpdateFileSystemLustreMetadataConfiguration;
    ThroughputCapacity?: number;
    DataReadCacheConfiguration?: LustreReadCacheConfiguration;
}
export declare const UpdateFileSystemLustreConfiguration: S.Schema<UpdateFileSystemLustreConfiguration>;
export interface UpdateFileSystemOntapConfiguration {
    AutomaticBackupRetentionDays?: number;
    DailyAutomaticBackupStartTime?: string;
    FsxAdminPassword?: string | redacted.Redacted<string>;
    WeeklyMaintenanceStartTime?: string;
    DiskIopsConfiguration?: DiskIopsConfiguration;
    ThroughputCapacity?: number;
    AddRouteTableIds?: string[];
    RemoveRouteTableIds?: string[];
    ThroughputCapacityPerHAPair?: number;
    HAPairs?: number;
    EndpointIpv6AddressRange?: string;
}
export declare const UpdateFileSystemOntapConfiguration: S.Schema<UpdateFileSystemOntapConfiguration>;
export interface UpdateFileSystemOpenZFSConfiguration {
    AutomaticBackupRetentionDays?: number;
    CopyTagsToBackups?: boolean;
    CopyTagsToVolumes?: boolean;
    DailyAutomaticBackupStartTime?: string;
    ThroughputCapacity?: number;
    WeeklyMaintenanceStartTime?: string;
    DiskIopsConfiguration?: DiskIopsConfiguration;
    AddRouteTableIds?: string[];
    RemoveRouteTableIds?: string[];
    ReadCacheConfiguration?: OpenZFSReadCacheConfiguration;
    EndpointIpv6AddressRange?: string;
}
export declare const UpdateFileSystemOpenZFSConfiguration: S.Schema<UpdateFileSystemOpenZFSConfiguration>;
export interface UpdateFileSystemRequest {
    FileSystemId?: string;
    ClientRequestToken?: string;
    StorageCapacity?: number;
    WindowsConfiguration?: UpdateFileSystemWindowsConfiguration;
    LustreConfiguration?: UpdateFileSystemLustreConfiguration;
    OntapConfiguration?: UpdateFileSystemOntapConfiguration;
    OpenZFSConfiguration?: UpdateFileSystemOpenZFSConfiguration;
    StorageType?: StorageType;
    FileSystemTypeVersion?: string;
    NetworkType?: NetworkType;
}
export declare const UpdateFileSystemRequest: S.Schema<UpdateFileSystemRequest>;
export interface UpdateFileSystemResponse {
    FileSystem?: FileSystem & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        WindowsConfiguration: WindowsFileSystemConfiguration & {
            AuditLogConfiguration: WindowsAuditLogConfiguration & {
                FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
            };
            FsrmConfiguration: WindowsFsrmConfiguration & {
                FsrmServiceEnabled: Flag;
            };
        };
        LustreConfiguration: LustreFileSystemConfiguration & {
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
            MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                Mode: MetadataConfigurationMode;
            };
        };
        AdministrativeActions: (AdministrativeAction & {
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
    };
}
export declare const UpdateFileSystemResponse: S.Schema<UpdateFileSystemResponse>;
export interface UpdateSharedVpcConfigurationRequest {
    EnableFsxRouteTableUpdatesFromParticipantAccounts?: string;
    ClientRequestToken?: string;
}
export declare const UpdateSharedVpcConfigurationRequest: S.Schema<UpdateSharedVpcConfigurationRequest>;
export interface UpdateSharedVpcConfigurationResponse {
    EnableFsxRouteTableUpdatesFromParticipantAccounts?: string;
}
export declare const UpdateSharedVpcConfigurationResponse: S.Schema<UpdateSharedVpcConfigurationResponse>;
export interface UpdateSnapshotRequest {
    ClientRequestToken?: string;
    Name?: string;
    SnapshotId?: string;
}
export declare const UpdateSnapshotRequest: S.Schema<UpdateSnapshotRequest>;
export interface UpdateSnapshotResponse {
    Snapshot?: Snapshot & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
        })[];
    };
}
export declare const UpdateSnapshotResponse: S.Schema<UpdateSnapshotResponse>;
export interface UpdateSvmActiveDirectoryConfiguration {
    SelfManagedActiveDirectoryConfiguration?: SelfManagedActiveDirectoryConfigurationUpdates;
    NetBiosName?: string;
}
export declare const UpdateSvmActiveDirectoryConfiguration: S.Schema<UpdateSvmActiveDirectoryConfiguration>;
export interface UpdateStorageVirtualMachineRequest {
    ActiveDirectoryConfiguration?: UpdateSvmActiveDirectoryConfiguration;
    ClientRequestToken?: string;
    StorageVirtualMachineId?: string;
    SvmAdminPassword?: string | redacted.Redacted<string>;
}
export declare const UpdateStorageVirtualMachineRequest: S.Schema<UpdateStorageVirtualMachineRequest>;
export interface UpdateStorageVirtualMachineResponse {
    StorageVirtualMachine?: StorageVirtualMachine & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    };
}
export declare const UpdateStorageVirtualMachineResponse: S.Schema<UpdateStorageVirtualMachineResponse>;
export interface UpdateSnaplockConfiguration {
    AuditLogVolume?: boolean;
    AutocommitPeriod?: AutocommitPeriod;
    PrivilegedDelete?: PrivilegedDelete;
    RetentionPeriod?: SnaplockRetentionPeriod;
    VolumeAppendModeEnabled?: boolean;
}
export declare const UpdateSnaplockConfiguration: S.Schema<UpdateSnaplockConfiguration>;
export interface UpdateOntapVolumeConfiguration {
    JunctionPath?: string;
    SecurityStyle?: SecurityStyle;
    SizeInMegabytes?: number;
    StorageEfficiencyEnabled?: boolean;
    TieringPolicy?: TieringPolicy;
    SnapshotPolicy?: string;
    CopyTagsToBackups?: boolean;
    SnaplockConfiguration?: UpdateSnaplockConfiguration;
    SizeInBytes?: number;
}
export declare const UpdateOntapVolumeConfiguration: S.Schema<UpdateOntapVolumeConfiguration>;
export interface UpdateOpenZFSVolumeConfiguration {
    StorageCapacityReservationGiB?: number;
    StorageCapacityQuotaGiB?: number;
    RecordSizeKiB?: number;
    DataCompressionType?: OpenZFSDataCompressionType;
    NfsExports?: OpenZFSNfsExport[];
    UserAndGroupQuotas?: OpenZFSUserOrGroupQuota[];
    ReadOnly?: boolean;
}
export declare const UpdateOpenZFSVolumeConfiguration: S.Schema<UpdateOpenZFSVolumeConfiguration>;
export interface UpdateVolumeRequest {
    ClientRequestToken?: string;
    VolumeId?: string;
    OntapConfiguration?: UpdateOntapVolumeConfiguration;
    Name?: string;
    OpenZFSConfiguration?: UpdateOpenZFSVolumeConfiguration;
}
export declare const UpdateVolumeRequest: S.Schema<UpdateVolumeRequest>;
export interface UpdateVolumeResponse {
    Volume?: Volume & {
        OntapConfiguration: OntapVolumeConfiguration & {
            SnaplockConfiguration: SnaplockConfiguration & {
                AutocommitPeriod: AutocommitPeriod & {
                    Type: AutocommitPeriodType;
                };
                RetentionPeriod: SnaplockRetentionPeriod & {
                    DefaultRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MinimumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MaximumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                };
            };
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
        OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
            NfsExports: (OpenZFSNfsExport & {
                ClientConfigurations: (OpenZFSClientConfiguration & {
                    Clients: OpenZFSClients;
                    Options: OpenZFSNfsExportOptions;
                })[];
            })[];
            UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                Type: OpenZFSQuotaType;
                Id: IntegerNoMax;
                StorageCapacityQuotaGiB: IntegerNoMax;
            })[];
        };
    };
}
export declare const UpdateVolumeResponse: S.Schema<UpdateVolumeResponse>;
export type Parameter = string;
export type ServiceLimit = "FILE_SYSTEM_COUNT" | "TOTAL_THROUGHPUT_CAPACITY" | "TOTAL_STORAGE" | "TOTAL_USER_INITIATED_BACKUPS" | "TOTAL_USER_TAGS" | "TOTAL_IN_PROGRESS_COPY_BACKUPS" | "STORAGE_VIRTUAL_MACHINES_PER_FILE_SYSTEM" | "VOLUMES_PER_FILE_SYSTEM" | "TOTAL_SSD_IOPS" | "FILE_CACHE_COUNT" | (string & {});
export declare const ServiceLimit: any;
export type ErrorCode = string;
export type ActiveDirectoryErrorType = "DOMAIN_NOT_FOUND" | "INCOMPATIBLE_DOMAIN_MODE" | "WRONG_VPC" | "INVALID_NETWORK_TYPE" | "INVALID_DOMAIN_STAGE" | (string & {});
export declare const ActiveDirectoryErrorType: any;
export type AssociateFileSystemAliasesError = BadRequest | FileSystemNotFound | InternalServerError | CommonErrors;
/**
 * Use this action to associate one or more Domain Name Server (DNS) aliases with an existing Amazon FSx for Windows File Server file system.
 * A file system can have a maximum of 50 DNS aliases associated with it at any one time. If you try to
 * associate a DNS alias that is already associated with the file system, FSx takes no action on that alias in the request.
 * For more information, see Working with DNS Aliases and
 * Walkthrough 5: Using DNS aliases to access your file system, including
 * additional steps you must take to be able to access your file system using a DNS alias.
 *
 * The system response shows the DNS aliases that
 * Amazon FSx is attempting to associate with the file system.
 * Use the API
 * operation to monitor the status of the aliases Amazon FSx is
 * associating with the file system.
 */
export declare const associateFileSystemAliases: API.OperationMethod<AssociateFileSystemAliasesRequest, AssociateFileSystemAliasesResponse, AssociateFileSystemAliasesError, Credentials | HttpClient.HttpClient>;
export type CancelDataRepositoryTaskError = BadRequest | DataRepositoryTaskEnded | DataRepositoryTaskNotFound | InternalServerError | UnsupportedOperation | CommonErrors;
/**
 * Cancels an existing Amazon FSx for Lustre data repository task if that task is in either the
 * `PENDING` or `EXECUTING` state. When you cancel an export task, Amazon FSx
 * does the following.
 *
 * - Any files that FSx has already exported are not reverted.
 *
 * - FSx continues to export any files that are in-flight when the cancel operation is received.
 *
 * - FSx does not export any files that have not yet been exported.
 *
 * For a release task, Amazon FSx will stop releasing files upon cancellation. Any files that
 * have already been released will remain in the released state.
 */
export declare const cancelDataRepositoryTask: API.OperationMethod<CancelDataRepositoryTaskRequest, CancelDataRepositoryTaskResponse, CancelDataRepositoryTaskError, Credentials | HttpClient.HttpClient>;
export type CopyBackupError = BackupNotFound | BadRequest | IncompatibleParameterError | IncompatibleRegionForMultiAZ | InternalServerError | InvalidDestinationKmsKey | InvalidRegion | InvalidSourceKmsKey | ServiceLimitExceeded | SourceBackupUnavailable | UnsupportedOperation | CommonErrors;
/**
 * Copies an existing backup within the same Amazon Web Services account to another Amazon Web Services Region
 * (cross-Region copy) or within the same Amazon Web Services Region (in-Region copy). You can have up to five
 * backup copy requests in progress to a single destination Region per account.
 *
 * You can use cross-Region backup copies for cross-Region disaster recovery. You can
 * periodically take backups and copy them to another Region so that in the event of a
 * disaster in the primary Region, you can restore from backup and recover availability
 * quickly in the other Region. You can make cross-Region copies only within your Amazon Web Services partition. A partition is a grouping of Regions. Amazon Web Services currently
 * has three partitions: `aws` (Standard Regions), `aws-cn` (China
 * Regions), and `aws-us-gov` (Amazon Web Services GovCloud [US] Regions).
 *
 * You can also use backup copies to clone your file dataset to another Region or within
 * the same Region.
 *
 * You can use the `SourceRegion` parameter to specify the Amazon Web Services Region
 * from which the backup will be copied. For example, if you make the call from the
 * `us-west-1` Region and want to copy a backup from the `us-east-2`
 * Region, you specify `us-east-2` in the `SourceRegion` parameter
 * to make a cross-Region copy. If you don't specify a Region, the backup copy is
 * created in the same Region where the request is sent from (in-Region copy).
 *
 * For more information about creating backup copies, see Copying backups
 * in the *Amazon FSx for Windows User Guide*, Copying backups in the Amazon FSx for Lustre User
 * Guide, and Copying backups in the Amazon FSx for OpenZFS User
 * Guide.
 */
export declare const copyBackup: API.OperationMethod<CopyBackupRequest, CopyBackupResponse, CopyBackupError, Credentials | HttpClient.HttpClient>;
export type CopySnapshotAndUpdateVolumeError = BadRequest | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | SourceSnapshotNotFound | CommonErrors;
/**
 * Updates an existing volume by using a snapshot from another Amazon FSx for OpenZFS file system. For more information, see on-demand data replication in the Amazon FSx for OpenZFS User
 * Guide.
 */
export declare const copySnapshotAndUpdateVolume: API.OperationMethod<CopySnapshotAndUpdateVolumeRequest, CopySnapshotAndUpdateVolumeResponse, CopySnapshotAndUpdateVolumeError, Credentials | HttpClient.HttpClient>;
export type CreateAndAttachS3AccessPointError = AccessPointAlreadyOwnedByYou | BadRequest | IncompatibleParameterError | InternalServerError | InvalidAccessPoint | InvalidRequest | TooManyAccessPoints | UnsupportedOperation | VolumeNotFound | CommonErrors;
/**
 * Creates an S3 access point and attaches it to an Amazon FSx volume. For FSx for OpenZFS file systems, the
 * volume must be hosted on a high-availability file system, either Single-AZ or Multi-AZ. For more information,
 * see Accessing your data using Amazon S3 access points.
 * in the Amazon FSx for OpenZFS User Guide.
 *
 * The requester requires the following permissions to perform these actions:
 *
 * - `fsx:CreateAndAttachS3AccessPoint`
 *
 * - `s3:CreateAccessPoint`
 *
 * - `s3:GetAccessPoint`
 *
 * - `s3:PutAccessPointPolicy`
 *
 * - `s3:DeleteAccessPoint`
 *
 * The following actions are related to `CreateAndAttachS3AccessPoint`:
 *
 * - DescribeS3AccessPointAttachments
 *
 * - DetachAndDeleteS3AccessPoint
 */
export declare const createAndAttachS3AccessPoint: API.OperationMethod<CreateAndAttachS3AccessPointRequest, CreateAndAttachS3AccessPointResponse, CreateAndAttachS3AccessPointError, Credentials | HttpClient.HttpClient>;
export type CreateBackupError = BackupInProgress | BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | UnsupportedOperation | VolumeNotFound | CommonErrors;
/**
 * Creates a backup of an existing Amazon FSx for Windows File Server file
 * system, Amazon FSx for Lustre file system, Amazon FSx for NetApp ONTAP
 * volume, or Amazon FSx for OpenZFS file system. We recommend creating regular
 * backups so that you can restore a file system or volume from a backup if an issue arises
 * with the original file system or volume.
 *
 * For Amazon FSx for Lustre file systems, you can create a backup only for file
 * systems that have the following configuration:
 *
 * - A Persistent deployment type
 *
 * - Are *not* linked to a data repository
 *
 * For more information about backups, see the following:
 *
 * - For Amazon FSx for Lustre, see Working with FSx for
 * Lustre backups.
 *
 * - For Amazon FSx for Windows, see Working with FSx for
 * Windows backups.
 *
 * - For Amazon FSx for NetApp ONTAP, see Working with FSx for NetApp
 * ONTAP backups.
 *
 * - For Amazon FSx for OpenZFS, see Working with FSx for OpenZFS backups.
 *
 * If a backup with the specified client request token exists and the parameters match,
 * this operation returns the description of the existing backup. If a backup with the
 * specified client request token exists and the parameters don't match, this operation
 * returns `IncompatibleParameterError`. If a backup with the specified client
 * request token doesn't exist, `CreateBackup` does the following:
 *
 * - Creates a new Amazon FSx backup with an assigned ID, and an initial
 * lifecycle state of `CREATING`.
 *
 * - Returns the description of the backup.
 *
 * By using the idempotent operation, you can retry a `CreateBackup`
 * operation without the risk of creating an extra backup. This approach can be useful when
 * an initial call fails in a way that makes it unclear whether a backup was created. If
 * you use the same client request token and the initial call created a backup, the
 * operation returns a successful result because all the parameters are the same.
 *
 * The `CreateBackup` operation returns while the backup's lifecycle state is
 * still `CREATING`. You can check the backup creation status by calling the
 * DescribeBackups operation, which returns the backup state along with other
 * information.
 */
export declare const createBackup: API.OperationMethod<CreateBackupRequest, CreateBackupResponse, CreateBackupError, Credentials | HttpClient.HttpClient>;
export type CreateDataRepositoryAssociationError = BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | UnsupportedOperation | CommonErrors;
/**
 * Creates an Amazon FSx for Lustre data repository association (DRA). A data
 * repository association is a link between a directory on the file system and
 * an Amazon S3 bucket or prefix. You can have a maximum of 8 data repository
 * associations on a file system. Data repository associations are supported
 * on all FSx for Lustre 2.12 and 2.15 file systems, excluding
 * `scratch_1` deployment type.
 *
 * Each data repository association must have a unique Amazon FSx file
 * system directory and a unique S3 bucket or prefix associated with it. You
 * can configure a data repository association for automatic import only,
 * for automatic export only, or for both. To learn more about linking a
 * data repository to your file system, see
 * Linking your file system to an S3 bucket.
 *
 * `CreateDataRepositoryAssociation` isn't supported
 * on Amazon File Cache resources. To create a DRA on Amazon File Cache,
 * use the `CreateFileCache` operation.
 */
export declare const createDataRepositoryAssociation: API.OperationMethod<CreateDataRepositoryAssociationRequest, CreateDataRepositoryAssociationResponse, CreateDataRepositoryAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateDataRepositoryTaskError = BadRequest | DataRepositoryTaskExecuting | FileSystemNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | UnsupportedOperation | CommonErrors;
/**
 * Creates an Amazon FSx for Lustre data repository task.
 * A `CreateDataRepositoryTask` operation will fail if a data
 * repository is not linked to the FSx file system.
 *
 * You use import and export data repository tasks to perform bulk operations between your
 * FSx for Lustre file system and its linked data repositories. An example of a data repository
 * task is exporting any data and metadata changes, including POSIX metadata, to files, directories,
 * and symbolic links (symlinks) from your FSx file system to a linked data repository.
 *
 * You use release data repository tasks to release data from your file system for files that
 * are exported to S3. The metadata of released files remains on the file system so users or applications
 * can still access released files by reading the files again, which will restore data from
 * Amazon S3 to the FSx for Lustre file system.
 *
 * To learn more about data repository tasks, see
 * Data Repository Tasks.
 * To learn more about linking a data repository to your file system, see
 * Linking your file system to an S3 bucket.
 */
export declare const createDataRepositoryTask: API.OperationMethod<CreateDataRepositoryTaskRequest, CreateDataRepositoryTaskResponse, CreateDataRepositoryTaskError, Credentials | HttpClient.HttpClient>;
export type CreateFileCacheError = BadRequest | IncompatibleParameterError | InternalServerError | InvalidNetworkSettings | InvalidPerUnitStorageThroughput | MissingFileCacheConfiguration | ServiceLimitExceeded | CommonErrors;
/**
 * Creates a new Amazon File Cache resource.
 *
 * You can use this operation with a client request token in the request that
 * Amazon File Cache uses to ensure idempotent creation.
 * If a cache with the specified client request token exists and the parameters
 * match, `CreateFileCache` returns the description of the existing
 * cache. If a cache with the specified client request token exists and the
 * parameters don't match, this call returns `IncompatibleParameterError`.
 * If a file cache with the specified client request token doesn't exist,
 * `CreateFileCache` does the following:
 *
 * - Creates a new, empty Amazon File Cache resource with an assigned ID, and
 * an initial lifecycle state of `CREATING`.
 *
 * - Returns the description of the cache in JSON format.
 *
 * The `CreateFileCache` call returns while the cache's lifecycle
 * state is still `CREATING`. You can check the cache creation status
 * by calling the DescribeFileCaches operation, which returns the cache state
 * along with other information.
 */
export declare const createFileCache: API.OperationMethod<CreateFileCacheRequest, CreateFileCacheResponse, CreateFileCacheError, Credentials | HttpClient.HttpClient>;
export type CreateFileSystemError = ActiveDirectoryError | BadRequest | IncompatibleParameterError | InternalServerError | InvalidExportPath | InvalidImportPath | InvalidNetworkSettings | InvalidPerUnitStorageThroughput | MissingFileSystemConfiguration | ServiceLimitExceeded | CommonErrors;
/**
 * Creates a new, empty Amazon FSx file system. You can create the following supported
 * Amazon FSx file systems using the `CreateFileSystem` API operation:
 *
 * - Amazon FSx for Lustre
 *
 * - Amazon FSx for NetApp ONTAP
 *
 * - Amazon FSx for OpenZFS
 *
 * - Amazon FSx for Windows File Server
 *
 * This operation requires a client request token in the request that Amazon FSx uses
 * to ensure idempotent creation. This means that calling the operation multiple times with
 * the same client request token has no effect. By using the idempotent operation, you can
 * retry a `CreateFileSystem` operation without the risk of creating an extra
 * file system. This approach can be useful when an initial call fails in a way that makes
 * it unclear whether a file system was created. Examples are if a transport level timeout
 * occurred, or your connection was reset. If you use the same client request token and the
 * initial call created a file system, the client receives success as long as the
 * parameters are the same.
 *
 * If a file system with the specified client request token exists and the parameters
 * match, `CreateFileSystem` returns the description of the existing file
 * system. If a file system with the specified client request token exists and the
 * parameters don't match, this call returns `IncompatibleParameterError`. If a
 * file system with the specified client request token doesn't exist,
 * `CreateFileSystem` does the following:
 *
 * - Creates a new, empty Amazon FSx file system with an assigned ID, and
 * an initial lifecycle state of `CREATING`.
 *
 * - Returns the description of the file system in JSON format.
 *
 * The `CreateFileSystem` call returns while the file system's lifecycle
 * state is still `CREATING`. You can check the file-system creation status
 * by calling the DescribeFileSystems operation, which returns the file system state
 * along with other information.
 */
export declare const createFileSystem: API.OperationMethod<CreateFileSystemRequest, CreateFileSystemResponse, CreateFileSystemError, Credentials | HttpClient.HttpClient>;
export type CreateFileSystemFromBackupError = ActiveDirectoryError | BackupNotFound | BadRequest | IncompatibleParameterError | InternalServerError | InvalidNetworkSettings | InvalidPerUnitStorageThroughput | MissingFileSystemConfiguration | ServiceLimitExceeded | CommonErrors;
/**
 * Creates a new Amazon FSx for Lustre, Amazon FSx for Windows File
 * Server, or Amazon FSx for OpenZFS file system from an existing Amazon FSx backup.
 *
 * If a file system with the specified client request token exists and the parameters
 * match, this operation returns the description of the file system. If a file system
 * with the specified client request token exists but the parameters don't match, this
 * call returns `IncompatibleParameterError`. If a file system with the
 * specified client request token doesn't exist, this operation does the following:
 *
 * - Creates a new Amazon FSx file system from backup with an assigned ID,
 * and an initial lifecycle state of `CREATING`.
 *
 * - Returns the description of the file system.
 *
 * Parameters like the Active Directory, default share name, automatic backup, and backup
 * settings default to the parameters of the file system that was backed up, unless
 * overridden. You can explicitly supply other settings.
 *
 * By using the idempotent operation, you can retry a
 * `CreateFileSystemFromBackup` call without the risk of creating an extra
 * file system. This approach can be useful when an initial call fails in a way that makes
 * it unclear whether a file system was created. Examples are if a transport level timeout
 * occurred, or your connection was reset. If you use the same client request token and the
 * initial call created a file system, the client receives a success message as long as the
 * parameters are the same.
 *
 * The `CreateFileSystemFromBackup` call returns while the file system's
 * lifecycle state is still `CREATING`. You can check the file-system
 * creation status by calling the
 * DescribeFileSystems operation, which returns the file system state along
 * with other information.
 */
export declare const createFileSystemFromBackup: API.OperationMethod<CreateFileSystemFromBackupRequest, CreateFileSystemFromBackupResponse, CreateFileSystemFromBackupError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotError = BadRequest | InternalServerError | ServiceLimitExceeded | VolumeNotFound | SnapshotVolumeNotFound | CommonErrors;
/**
 * Creates a snapshot of an existing Amazon FSx for OpenZFS volume. With
 * snapshots, you can easily undo file changes and compare file versions by restoring the
 * volume to a previous version.
 *
 * If a snapshot with the specified client request token exists, and the parameters
 * match, this operation returns the description of the existing snapshot. If a snapshot
 * with the specified client request token exists, and the parameters don't match, this
 * operation returns `IncompatibleParameterError`. If a snapshot with the
 * specified client request token doesn't exist, `CreateSnapshot` does the
 * following:
 *
 * - Creates a new OpenZFS snapshot with an assigned ID, and an initial lifecycle
 * state of `CREATING`.
 *
 * - Returns the description of the snapshot.
 *
 * By using the idempotent operation, you can retry a `CreateSnapshot`
 * operation without the risk of creating an extra snapshot. This approach can be useful
 * when an initial call fails in a way that makes it unclear whether a snapshot was
 * created. If you use the same client request token and the initial call created a
 * snapshot, the operation returns a successful result because all the parameters are the
 * same.
 *
 * The `CreateSnapshot` operation returns while the snapshot's lifecycle state
 * is still `CREATING`. You can check the snapshot creation status by calling
 * the DescribeSnapshots operation, which returns the snapshot state along with
 * other information.
 */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotRequest, CreateSnapshotResponse, CreateSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateStorageVirtualMachineError = ActiveDirectoryError | BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | UnsupportedOperation | CommonErrors;
/**
 * Creates a storage virtual machine (SVM) for an Amazon FSx for ONTAP file system.
 */
export declare const createStorageVirtualMachine: API.OperationMethod<CreateStorageVirtualMachineRequest, CreateStorageVirtualMachineResponse, CreateStorageVirtualMachineError, Credentials | HttpClient.HttpClient>;
export type CreateVolumeError = BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | MissingVolumeConfiguration | ServiceLimitExceeded | StorageVirtualMachineNotFound | UnsupportedOperation | CommonErrors;
/**
 * Creates an FSx for ONTAP or Amazon FSx for OpenZFS storage volume.
 */
export declare const createVolume: API.OperationMethod<CreateVolumeRequest, CreateVolumeResponse, CreateVolumeError, Credentials | HttpClient.HttpClient>;
export type CreateVolumeFromBackupError = BackupNotFound | BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | MissingVolumeConfiguration | ServiceLimitExceeded | StorageVirtualMachineNotFound | CommonErrors;
/**
 * Creates a new Amazon FSx for NetApp ONTAP volume from an
 * existing Amazon FSx volume backup.
 */
export declare const createVolumeFromBackup: API.OperationMethod<CreateVolumeFromBackupRequest, CreateVolumeFromBackupResponse, CreateVolumeFromBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteBackupError = BackupBeingCopied | BackupInProgress | BackupNotFound | BackupRestoring | BadRequest | IncompatibleParameterError | InternalServerError | CommonErrors;
/**
 * Deletes an Amazon FSx backup. After deletion, the backup no longer exists, and
 * its data is gone.
 *
 * The `DeleteBackup` call returns instantly. The backup won't show up in
 * later `DescribeBackups` calls.
 *
 * The data in a deleted backup is also deleted and can't be recovered by any
 * means.
 */
export declare const deleteBackup: API.OperationMethod<DeleteBackupRequest, DeleteBackupResponse, DeleteBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteDataRepositoryAssociationError = BadRequest | DataRepositoryAssociationNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | CommonErrors;
/**
 * Deletes a data repository association on an Amazon FSx for Lustre
 * file system. Deleting the data repository association unlinks the
 * file system from the Amazon S3 bucket. When deleting a data repository
 * association, you have the option of deleting the data in the file system
 * that corresponds to the data repository association. Data repository
 * associations are supported on all FSx for Lustre 2.12 and 2.15 file
 * systems, excluding `scratch_1` deployment type.
 */
export declare const deleteDataRepositoryAssociation: API.OperationMethod<DeleteDataRepositoryAssociationRequest, DeleteDataRepositoryAssociationResponse, DeleteDataRepositoryAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteFileCacheError = BadRequest | FileCacheNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | CommonErrors;
/**
 * Deletes an Amazon File Cache resource. After deletion, the cache no longer exists, and its data
 * is gone.
 *
 * The `DeleteFileCache` operation returns while the cache has the
 * `DELETING` status. You can check the cache deletion status by
 * calling the DescribeFileCaches operation, which returns a list of caches in your
 * account. If you pass the cache ID for a deleted cache, the
 * `DescribeFileCaches` operation returns a `FileCacheNotFound`
 * error.
 *
 * The data in a deleted cache is also deleted and can't be recovered by
 * any means.
 */
export declare const deleteFileCache: API.OperationMethod<DeleteFileCacheRequest, DeleteFileCacheResponse, DeleteFileCacheError, Credentials | HttpClient.HttpClient>;
export type DeleteFileSystemError = BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | CommonErrors;
/**
 * Deletes a file system. After deletion, the file system no longer exists, and its data
 * is gone. Any existing automatic backups and snapshots are also deleted.
 *
 * To delete an Amazon FSx for NetApp ONTAP file system, first delete all the
 * volumes and storage virtual machines (SVMs) on the file system. Then provide a
 * `FileSystemId` value to the `DeleteFileSystem` operation.
 *
 * Before deleting an Amazon FSx for OpenZFS file system, make sure that there aren't
 * any Amazon S3 access points attached to any volume. For more information on how to list S3
 * access points that are attached to volumes, see
 * Listing S3 access point attachments.
 * For more information on how to delete S3 access points, see
 * Deleting an S3 access point attachment.
 *
 * By default, when you delete an Amazon FSx for Windows File Server file system,
 * a final backup is created upon deletion. This final backup isn't subject to the file
 * system's retention policy, and must be manually deleted.
 *
 * To delete an Amazon FSx for Lustre file system, first
 * unmount
 * it from every connected Amazon EC2 instance, then provide a `FileSystemId`
 * value to the `DeleteFileSystem` operation. By default, Amazon FSx will not
 * take a final backup when the `DeleteFileSystem` operation is invoked. On file systems
 * not linked to an Amazon S3 bucket, set `SkipFinalBackup` to `false`
 * to take a final backup of the file system you are deleting. Backups cannot be enabled on S3-linked
 * file systems. To ensure all of your data is written back to S3 before deleting your file system,
 * you can either monitor for the
 * AgeOfOldestQueuedMessage
 * metric to be zero (if using automatic export) or you can run an
 * export data repository task.
 * If you have automatic export enabled and want to use an export data repository task, you have
 * to disable automatic export before executing the export data repository task.
 *
 * The `DeleteFileSystem` operation returns while the file system has the
 * `DELETING` status. You can check the file system deletion status by
 * calling the DescribeFileSystems operation, which returns a list of file systems in your
 * account. If you pass the file system ID for a deleted file system, the
 * `DescribeFileSystems` operation returns a `FileSystemNotFound`
 * error.
 *
 * If a data repository task is in a `PENDING` or `EXECUTING` state,
 * deleting an Amazon FSx for Lustre file system will fail with an HTTP status
 * code 400 (Bad Request).
 *
 * The data in a deleted file system is also deleted and can't be recovered by
 * any means.
 */
export declare const deleteFileSystem: API.OperationMethod<DeleteFileSystemRequest, DeleteFileSystemResponse, DeleteFileSystemError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotError = BadRequest | InternalServerError | SnapshotNotFound | CommonErrors;
/**
 * Deletes an Amazon FSx for OpenZFS snapshot. After deletion, the snapshot no longer
 * exists, and its data is gone. Deleting a snapshot doesn't affect snapshots stored in a
 * file system backup.
 *
 * The `DeleteSnapshot` operation returns instantly. The snapshot appears with
 * the lifecycle status of `DELETING` until the deletion is complete.
 */
export declare const deleteSnapshot: API.OperationMethod<DeleteSnapshotRequest, DeleteSnapshotResponse, DeleteSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteStorageVirtualMachineError = BadRequest | IncompatibleParameterError | InternalServerError | StorageVirtualMachineNotFound | CommonErrors;
/**
 * Deletes an existing Amazon FSx for ONTAP storage virtual machine (SVM). Prior
 * to deleting an SVM, you must delete all non-root volumes in the SVM, otherwise the operation will fail.
 */
export declare const deleteStorageVirtualMachine: API.OperationMethod<DeleteStorageVirtualMachineRequest, DeleteStorageVirtualMachineResponse, DeleteStorageVirtualMachineError, Credentials | HttpClient.HttpClient>;
export type DeleteVolumeError = BadRequest | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | VolumeNotFound | CommonErrors;
/**
 * Deletes an Amazon FSx for NetApp ONTAP or Amazon FSx for OpenZFS
 * volume.
 */
export declare const deleteVolume: API.OperationMethod<DeleteVolumeRequest, DeleteVolumeResponse, DeleteVolumeError, Credentials | HttpClient.HttpClient>;
export type DescribeBackupsError = BackupNotFound | BadRequest | FileSystemNotFound | InternalServerError | VolumeNotFound | CommonErrors;
/**
 * Returns the description of a specific Amazon FSx backup, if a
 * `BackupIds` value is provided for that backup. Otherwise, it returns all
 * backups owned by your Amazon Web Services account in the Amazon Web Services Region of the
 * endpoint that you're calling.
 *
 * When retrieving all backups, you can optionally specify the `MaxResults`
 * parameter to limit the number of backups in a response. If more backups remain, Amazon FSx returns a `NextToken` value in the response. In this case,
 * send a later request with the `NextToken` request parameter set to the value
 * of the `NextToken` value from the last response.
 *
 * This operation is used in an iterative process to retrieve a list of your backups.
 * `DescribeBackups` is called first without a `NextToken` value.
 * Then the operation continues to be called with the `NextToken` parameter set
 * to the value of the last `NextToken` value until a response has no
 * `NextToken` value.
 *
 * When using this operation, keep the following in mind:
 *
 * - The operation might return fewer than the `MaxResults` value of
 * backup descriptions while still including a `NextToken`
 * value.
 *
 * - The order of the backups returned in the response of one
 * `DescribeBackups` call and the order of the backups returned
 * across the responses of a multi-call iteration is unspecified.
 */
export declare const describeBackups: API.PaginatedOperationMethod<DescribeBackupsRequest, DescribeBackupsResponse, DescribeBackupsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeDataRepositoryAssociationsError = BadRequest | DataRepositoryAssociationNotFound | FileSystemNotFound | InternalServerError | InvalidDataRepositoryType | CommonErrors;
/**
 * Returns the description of specific Amazon FSx for Lustre or Amazon File Cache
 * data repository associations, if one or more `AssociationIds` values
 * are provided in the request, or if filters are used in the request. Data repository
 * associations are supported on Amazon File Cache resources and all FSx for Lustre
 * 2.12 and 2,15 file systems, excluding `scratch_1` deployment type.
 *
 * You can use filters to narrow the response to include just data repository
 * associations for specific file systems (use the `file-system-id` filter with
 * the ID of the file system) or caches (use the `file-cache-id` filter with
 * the ID of the cache), or data repository associations for a specific repository type
 * (use the `data-repository-type` filter with a value of `S3`
 * or `NFS`). If you don't use filters, the response returns all data
 * repository associations owned by your Amazon Web Services account in the Amazon Web Services Region
 * of the endpoint that you're calling.
 *
 * When retrieving all data repository associations, you can paginate the response by using
 * the optional `MaxResults` parameter to limit the number of data repository associations
 * returned in a response. If more data repository associations remain, a
 * `NextToken` value is returned in the response. In this case, send a later
 * request with the `NextToken` request parameter set to the value of
 * `NextToken` from the last response.
 */
export declare const describeDataRepositoryAssociations: API.PaginatedOperationMethod<DescribeDataRepositoryAssociationsRequest, DescribeDataRepositoryAssociationsResponse, DescribeDataRepositoryAssociationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeDataRepositoryTasksError = BadRequest | DataRepositoryTaskNotFound | FileSystemNotFound | InternalServerError | CommonErrors;
/**
 * Returns the description of specific Amazon FSx for Lustre or Amazon File Cache data repository tasks, if
 * one or more `TaskIds` values are provided in the request, or if filters are used in the request.
 * You can use filters to narrow the response to include just tasks for specific file systems or caches,
 * or tasks in a specific lifecycle state. Otherwise, it returns all data repository tasks owned
 * by your Amazon Web Services account in the Amazon Web Services Region of the endpoint that you're calling.
 *
 * When retrieving all tasks, you can paginate the response by using the optional `MaxResults`
 * parameter to limit the number of tasks returned in a response. If more tasks remain,
 * a `NextToken` value is returned in the response. In this case, send a later
 * request with the `NextToken` request parameter set to the value of
 * `NextToken` from the last response.
 */
export declare const describeDataRepositoryTasks: API.PaginatedOperationMethod<DescribeDataRepositoryTasksRequest, DescribeDataRepositoryTasksResponse, DescribeDataRepositoryTasksError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFileCachesError = BadRequest | FileCacheNotFound | InternalServerError | CommonErrors;
/**
 * Returns the description of a specific Amazon File Cache resource, if a
 * `FileCacheIds` value is provided for that cache. Otherwise, it
 * returns descriptions of all caches owned by your Amazon Web Services account in the
 * Amazon Web Services Region of the endpoint that you're calling.
 *
 * When retrieving all cache descriptions, you can optionally specify the
 * `MaxResults` parameter to limit the number of descriptions in a response.
 * If more cache descriptions remain, the operation returns a
 * `NextToken` value in the response. In this case, send a later request
 * with the `NextToken` request parameter set to the value of
 * `NextToken` from the last response.
 *
 * This operation is used in an iterative process to retrieve a list of your cache
 * descriptions. `DescribeFileCaches` is called first without a
 * `NextToken`value. Then the operation continues to be called with the
 * `NextToken` parameter set to the value of the last `NextToken`
 * value until a response has no `NextToken`.
 *
 * When using this operation, keep the following in mind:
 *
 * - The implementation might return fewer than `MaxResults`
 * cache descriptions while still including a `NextToken`
 * value.
 *
 * - The order of caches returned in the response of one
 * `DescribeFileCaches` call and the order of caches returned
 * across the responses of a multicall iteration is unspecified.
 */
export declare const describeFileCaches: API.PaginatedOperationMethod<DescribeFileCachesRequest, DescribeFileCachesResponse, DescribeFileCachesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFileSystemAliasesError = BadRequest | FileSystemNotFound | InternalServerError | CommonErrors;
/**
 * Returns the DNS aliases that are associated with the specified Amazon FSx for Windows File Server file system. A history of
 * all DNS aliases that have been associated with and disassociated from the file system is available in the list of AdministrativeAction
 * provided in the DescribeFileSystems operation response.
 */
export declare const describeFileSystemAliases: API.PaginatedOperationMethod<DescribeFileSystemAliasesRequest, DescribeFileSystemAliasesResponse, DescribeFileSystemAliasesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFileSystemsError = BadRequest | FileSystemNotFound | InternalServerError | CommonErrors;
/**
 * Returns the description of specific Amazon FSx file systems, if a
 * `FileSystemIds` value is provided for that file system. Otherwise, it
 * returns descriptions of all file systems owned by your Amazon Web Services account in the
 * Amazon Web Services Region of the endpoint that you're calling.
 *
 * When retrieving all file system descriptions, you can optionally specify the
 * `MaxResults` parameter to limit the number of descriptions in a response.
 * If more file system descriptions remain, Amazon FSx returns a
 * `NextToken` value in the response. In this case, send a later request
 * with the `NextToken` request parameter set to the value of
 * `NextToken` from the last response.
 *
 * This operation is used in an iterative process to retrieve a list of your file system
 * descriptions. `DescribeFileSystems` is called first without a
 * `NextToken`value. Then the operation continues to be called with the
 * `NextToken` parameter set to the value of the last `NextToken`
 * value until a response has no `NextToken`.
 *
 * When using this operation, keep the following in mind:
 *
 * - The implementation might return fewer than `MaxResults` file
 * system descriptions while still including a `NextToken`
 * value.
 *
 * - The order of file systems returned in the response of one
 * `DescribeFileSystems` call and the order of file systems returned
 * across the responses of a multicall iteration is unspecified.
 */
export declare const describeFileSystems: API.PaginatedOperationMethod<DescribeFileSystemsRequest, DescribeFileSystemsResponse, DescribeFileSystemsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeS3AccessPointAttachmentsError = BadRequest | InternalServerError | S3AccessPointAttachmentNotFound | UnsupportedOperation | CommonErrors;
/**
 * Describes one or more S3 access points attached to Amazon FSx volumes.
 *
 * The requester requires the following permission to perform this action:
 *
 * - `fsx:DescribeS3AccessPointAttachments`
 */
export declare const describeS3AccessPointAttachments: API.PaginatedOperationMethod<DescribeS3AccessPointAttachmentsRequest, DescribeS3AccessPointAttachmentsResponse, DescribeS3AccessPointAttachmentsError, Credentials | HttpClient.HttpClient, S3AccessPointAttachment>;
export type DescribeSharedVpcConfigurationError = BadRequest | InternalServerError | CommonErrors;
/**
 * Indicates whether participant accounts in your organization can create Amazon FSx for NetApp ONTAP Multi-AZ file systems in subnets that are shared by a virtual
 * private cloud (VPC) owner. For more information, see Creating FSx for ONTAP file systems in shared subnets.
 */
export declare const describeSharedVpcConfiguration: API.OperationMethod<DescribeSharedVpcConfigurationRequest, DescribeSharedVpcConfigurationResponse, DescribeSharedVpcConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeSnapshotsError = BadRequest | InternalServerError | SnapshotNotFound | CommonErrors;
/**
 * Returns the description of specific Amazon FSx for OpenZFS snapshots, if a
 * `SnapshotIds` value is provided. Otherwise, this operation returns all
 * snapshots owned by your Amazon Web Services account in the Amazon Web Services Region of
 * the endpoint that you're calling.
 *
 * When retrieving all snapshots, you can optionally specify the `MaxResults`
 * parameter to limit the number of snapshots in a response. If more backups remain,
 * Amazon FSx returns a `NextToken` value in the response. In this
 * case, send a later request with the `NextToken` request parameter set to the
 * value of `NextToken` from the last response.
 *
 * Use this operation in an iterative process to retrieve a list of your snapshots.
 * `DescribeSnapshots` is called first without a `NextToken`
 * value. Then the operation continues to be called with the `NextToken`
 * parameter set to the value of the last `NextToken` value until a response has
 * no `NextToken` value.
 *
 * When using this operation, keep the following in mind:
 *
 * - The operation might return fewer than the `MaxResults` value of
 * snapshot descriptions while still including a `NextToken`
 * value.
 *
 * - The order of snapshots returned in the response of one
 * `DescribeSnapshots` call and the order of backups returned across
 * the responses of a multi-call iteration is unspecified.
 */
export declare const describeSnapshots: API.PaginatedOperationMethod<DescribeSnapshotsRequest, DescribeSnapshotsResponse, DescribeSnapshotsError, Credentials | HttpClient.HttpClient, Snapshot>;
export type DescribeStorageVirtualMachinesError = BadRequest | InternalServerError | StorageVirtualMachineNotFound | CommonErrors;
/**
 * Describes one or more Amazon FSx for NetApp ONTAP storage virtual machines (SVMs).
 */
export declare const describeStorageVirtualMachines: API.PaginatedOperationMethod<DescribeStorageVirtualMachinesRequest, DescribeStorageVirtualMachinesResponse, DescribeStorageVirtualMachinesError, Credentials | HttpClient.HttpClient, StorageVirtualMachine>;
export type DescribeVolumesError = BadRequest | InternalServerError | VolumeNotFound | CommonErrors;
/**
 * Describes one or more Amazon FSx for NetApp ONTAP or Amazon FSx for
 * OpenZFS volumes.
 */
export declare const describeVolumes: API.PaginatedOperationMethod<DescribeVolumesRequest, DescribeVolumesResponse, DescribeVolumesError, Credentials | HttpClient.HttpClient, Volume>;
export type DetachAndDeleteS3AccessPointError = BadRequest | IncompatibleParameterError | InternalServerError | S3AccessPointAttachmentNotFound | UnsupportedOperation | CommonErrors;
/**
 * Detaches an S3 access point from an Amazon FSx volume and deletes the S3 access point.
 *
 * The requester requires the following permission to perform this action:
 *
 * - `fsx:DetachAndDeleteS3AccessPoint`
 *
 * - `s3:DeleteAccessPoint`
 */
export declare const detachAndDeleteS3AccessPoint: API.OperationMethod<DetachAndDeleteS3AccessPointRequest, DetachAndDeleteS3AccessPointResponse, DetachAndDeleteS3AccessPointError, Credentials | HttpClient.HttpClient>;
export type DisassociateFileSystemAliasesError = BadRequest | FileSystemNotFound | InternalServerError | CommonErrors;
/**
 * Use this action to disassociate, or remove, one or more Domain Name Service (DNS) aliases
 * from an Amazon FSx for Windows File Server file system. If you attempt to disassociate a DNS alias that is not
 * associated with the file system, Amazon FSx responds with an HTTP status code 400 (Bad Request). For more information, see
 * Working with DNS Aliases.
 *
 * The system generated response showing the DNS aliases that
 * Amazon FSx is attempting to disassociate from the file system.
 * Use the API
 * operation to monitor the status of the aliases Amazon FSx is
 * disassociating with the file system.
 */
export declare const disassociateFileSystemAliases: API.OperationMethod<DisassociateFileSystemAliasesRequest, DisassociateFileSystemAliasesResponse, DisassociateFileSystemAliasesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = BadRequest | InternalServerError | NotServiceResourceError | ResourceDoesNotSupportTagging | ResourceNotFound | CommonErrors;
/**
 * Lists tags for Amazon FSx resources.
 *
 * When retrieving all tags, you can optionally specify the `MaxResults`
 * parameter to limit the number of tags in a response. If more tags remain, Amazon FSx
 * returns a `NextToken` value in the response. In this case, send a later
 * request with the `NextToken` request parameter set to the value of
 * `NextToken` from the last response.
 *
 * This action is used in an iterative process to retrieve a list of your tags.
 * `ListTagsForResource` is called first without a
 * `NextToken`value. Then the action continues to be called with the
 * `NextToken` parameter set to the value of the last `NextToken`
 * value until a response has no `NextToken`.
 *
 * When using this action, keep the following in mind:
 *
 * - The implementation might return fewer than `MaxResults` file
 * system descriptions while still including a `NextToken`
 * value.
 *
 * - The order of tags returned in the response of one
 * `ListTagsForResource` call and the order of tags returned across
 * the responses of a multi-call iteration is unspecified.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, unknown>;
export type ReleaseFileSystemNfsV3LocksError = BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | CommonErrors;
/**
 * Releases the file system lock from an Amazon FSx for OpenZFS file
 * system.
 */
export declare const releaseFileSystemNfsV3Locks: API.OperationMethod<ReleaseFileSystemNfsV3LocksRequest, ReleaseFileSystemNfsV3LocksResponse, ReleaseFileSystemNfsV3LocksError, Credentials | HttpClient.HttpClient>;
export type RestoreVolumeFromSnapshotError = BadRequest | InternalServerError | VolumeNotFound | RestoreSnapshotNotFound | CommonErrors;
/**
 * Returns an Amazon FSx for OpenZFS volume to the state saved by the specified
 * snapshot.
 */
export declare const restoreVolumeFromSnapshot: API.OperationMethod<RestoreVolumeFromSnapshotRequest, RestoreVolumeFromSnapshotResponse, RestoreVolumeFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type StartMisconfiguredStateRecoveryError = BadRequest | FileSystemNotFound | InternalServerError | CommonErrors;
/**
 * After performing steps to repair the Active Directory configuration of an FSx for Windows File Server file system, use this action to
 * initiate the process of Amazon FSx attempting to reconnect to the file system.
 */
export declare const startMisconfiguredStateRecovery: API.OperationMethod<StartMisconfiguredStateRecoveryRequest, StartMisconfiguredStateRecoveryResponse, StartMisconfiguredStateRecoveryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequest | InternalServerError | NotServiceResourceError | ResourceDoesNotSupportTagging | ResourceNotFound | CommonErrors;
/**
 * Tags an Amazon FSx resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequest | InternalServerError | NotServiceResourceError | ResourceDoesNotSupportTagging | ResourceNotFound | CommonErrors;
/**
 * This action removes a tag from an Amazon FSx resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDataRepositoryAssociationError = BadRequest | DataRepositoryAssociationNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | CommonErrors;
/**
 * Updates the configuration of an existing data repository association
 * on an Amazon FSx for Lustre file system. Data repository associations
 * are supported on all FSx for Lustre 2.12 and 2.15 file systems,
 * excluding `scratch_1` deployment type.
 */
export declare const updateDataRepositoryAssociation: API.OperationMethod<UpdateDataRepositoryAssociationRequest, UpdateDataRepositoryAssociationResponse, UpdateDataRepositoryAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateFileCacheError = BadRequest | FileCacheNotFound | IncompatibleParameterError | InternalServerError | MissingFileCacheConfiguration | ServiceLimitExceeded | UnsupportedOperation | CommonErrors;
/**
 * Updates the configuration of an existing Amazon File Cache resource.
 * You can update multiple properties in a single request.
 */
export declare const updateFileCache: API.OperationMethod<UpdateFileCacheRequest, UpdateFileCacheResponse, UpdateFileCacheError, Credentials | HttpClient.HttpClient>;
export type UpdateFileSystemError = BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | InvalidNetworkSettings | MissingFileSystemConfiguration | ServiceLimitExceeded | UnsupportedOperation | CommonErrors;
/**
 * Use this operation to update the configuration of an existing Amazon FSx file
 * system. You can update multiple properties in a single request.
 *
 * For FSx for Windows File Server file systems, you can update the following
 * properties:
 *
 * - `AuditLogConfiguration`
 *
 * - `AutomaticBackupRetentionDays`
 *
 * - `DailyAutomaticBackupStartTime`
 *
 * - `DiskIopsConfiguration`
 *
 * - `SelfManagedActiveDirectoryConfiguration`
 *
 * - `StorageCapacity`
 *
 * - `StorageType`
 *
 * - `ThroughputCapacity`
 *
 * - `WeeklyMaintenanceStartTime`
 *
 * For FSx for Lustre file systems, you can update the following
 * properties:
 *
 * - `AutoImportPolicy`
 *
 * - `AutomaticBackupRetentionDays`
 *
 * - `DailyAutomaticBackupStartTime`
 *
 * - `DataCompressionType`
 *
 * - `FileSystemTypeVersion`
 *
 * - `LogConfiguration`
 *
 * - `LustreReadCacheConfiguration`
 *
 * - `LustreRootSquashConfiguration`
 *
 * - `MetadataConfiguration`
 *
 * - `PerUnitStorageThroughput`
 *
 * - `StorageCapacity`
 *
 * - `ThroughputCapacity`
 *
 * - `WeeklyMaintenanceStartTime`
 *
 * For FSx for ONTAP file systems, you can update the following
 * properties:
 *
 * - `AddRouteTableIds`
 *
 * - `AutomaticBackupRetentionDays`
 *
 * - `DailyAutomaticBackupStartTime`
 *
 * - `DiskIopsConfiguration`
 *
 * - `EndpointIpv6AddressRange`
 *
 * - `FsxAdminPassword`
 *
 * - `HAPairs`
 *
 * - `RemoveRouteTableIds`
 *
 * - `StorageCapacity`
 *
 * - `ThroughputCapacity`
 *
 * - `ThroughputCapacityPerHAPair`
 *
 * - `WeeklyMaintenanceStartTime`
 *
 * For FSx for OpenZFS file systems, you can update the following
 * properties:
 *
 * - `AddRouteTableIds`
 *
 * - `AutomaticBackupRetentionDays`
 *
 * - `CopyTagsToBackups`
 *
 * - `CopyTagsToVolumes`
 *
 * - `DailyAutomaticBackupStartTime`
 *
 * - `DiskIopsConfiguration`
 *
 * - `EndpointIpv6AddressRange`
 *
 * - `ReadCacheConfiguration`
 *
 * - `RemoveRouteTableIds`
 *
 * - `StorageCapacity`
 *
 * - `ThroughputCapacity`
 *
 * - `WeeklyMaintenanceStartTime`
 */
export declare const updateFileSystem: API.OperationMethod<UpdateFileSystemRequest, UpdateFileSystemResponse, UpdateFileSystemError, Credentials | HttpClient.HttpClient>;
export type UpdateSharedVpcConfigurationError = BadRequest | IncompatibleParameterError | InternalServerError | CommonErrors;
/**
 * Configures whether participant accounts in your organization can create Amazon FSx for NetApp ONTAP Multi-AZ file systems in subnets that are shared by a virtual
 * private cloud (VPC) owner. For more information, see the Amazon FSx for NetApp ONTAP User
 * Guide.
 *
 * We strongly recommend that participant-created Multi-AZ file systems in the shared
 * VPC are deleted before you disable this feature. Once the feature is disabled, these
 * file systems will enter a `MISCONFIGURED` state and behave like Single-AZ
 * file systems. For more information, see Important considerations before disabling shared VPC support for Multi-AZ file
 * systems.
 */
export declare const updateSharedVpcConfiguration: API.OperationMethod<UpdateSharedVpcConfigurationRequest, UpdateSharedVpcConfigurationResponse, UpdateSharedVpcConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateSnapshotError = BadRequest | InternalServerError | SnapshotNotFound | UpdateSnapshotNotFound | CommonErrors;
/**
 * Updates the name of an Amazon FSx for OpenZFS snapshot.
 */
export declare const updateSnapshot: API.OperationMethod<UpdateSnapshotRequest, UpdateSnapshotResponse, UpdateSnapshotError, Credentials | HttpClient.HttpClient>;
export type UpdateStorageVirtualMachineError = BadRequest | IncompatibleParameterError | InternalServerError | StorageVirtualMachineNotFound | UnsupportedOperation | CommonErrors;
/**
 * Updates an FSx for ONTAP storage virtual machine (SVM).
 */
export declare const updateStorageVirtualMachine: API.OperationMethod<UpdateStorageVirtualMachineRequest, UpdateStorageVirtualMachineResponse, UpdateStorageVirtualMachineError, Credentials | HttpClient.HttpClient>;
export type UpdateVolumeError = BadRequest | IncompatibleParameterError | InternalServerError | MissingVolumeConfiguration | VolumeNotFound | CommonErrors;
/**
 * Updates the configuration of an Amazon FSx for NetApp ONTAP or Amazon FSx for OpenZFS volume.
 */
export declare const updateVolume: API.OperationMethod<UpdateVolumeRequest, UpdateVolumeResponse, UpdateVolumeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=fsx.d.ts.map