import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const GatewayTimeoutException_base: S.Class<GatewayTimeoutException, S.TaggedStruct<"GatewayTimeoutException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class GatewayTimeoutException extends /*@__PURE__*/ GatewayTimeoutException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly message: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly LimitType: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export interface CloneBackendRequest {
    AppId: string;
    BackendEnvironmentName: string;
    TargetEnvironmentName?: string;
}
export declare const CloneBackendRequest: S.Schema<CloneBackendRequest>;
export interface CloneBackendResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export declare const CloneBackendResponse: S.Schema<CloneBackendResponse>;
export interface ResourceConfig {
}
export declare const ResourceConfig: S.Schema<ResourceConfig>;
export interface CreateBackendRequest {
    AppId?: string;
    AppName?: string;
    BackendEnvironmentName?: string;
    ResourceConfig?: ResourceConfig;
    ResourceName?: string;
}
export declare const CreateBackendRequest: S.Schema<CreateBackendRequest>;
export interface CreateBackendResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export declare const CreateBackendResponse: S.Schema<CreateBackendResponse>;
export type Mode = "API_KEY" | "AWS_IAM" | "AMAZON_COGNITO_USER_POOLS" | "OPENID_CONNECT" | (string & {});
export declare const Mode: any;
export interface BackendAPIAppSyncAuthSettings {
    CognitoUserPoolId?: string;
    Description?: string;
    ExpirationTime?: number;
    OpenIDAuthTTL?: string;
    OpenIDClientId?: string;
    OpenIDIatTTL?: string;
    OpenIDIssueURL?: string;
    OpenIDProviderName?: string;
}
export declare const BackendAPIAppSyncAuthSettings: S.Schema<BackendAPIAppSyncAuthSettings>;
export interface BackendAPIAuthType {
    Mode?: Mode;
    Settings?: BackendAPIAppSyncAuthSettings;
}
export declare const BackendAPIAuthType: S.Schema<BackendAPIAuthType>;
export type ListOfBackendAPIAuthType = BackendAPIAuthType[];
export declare const ListOfBackendAPIAuthType: any;
export type ResolutionStrategy = "OPTIMISTIC_CONCURRENCY" | "LAMBDA" | "AUTOMERGE" | "NONE" | (string & {});
export declare const ResolutionStrategy: any;
export interface BackendAPIConflictResolution {
    ResolutionStrategy?: ResolutionStrategy;
}
export declare const BackendAPIConflictResolution: S.Schema<BackendAPIConflictResolution>;
export interface BackendAPIResourceConfig {
    AdditionalAuthTypes?: BackendAPIAuthType[];
    ApiName?: string;
    ConflictResolution?: BackendAPIConflictResolution;
    DefaultAuthType?: BackendAPIAuthType;
    Service?: string;
    TransformSchema?: string;
}
export declare const BackendAPIResourceConfig: S.Schema<BackendAPIResourceConfig>;
export interface CreateBackendAPIRequest {
    AppId: string;
    BackendEnvironmentName?: string;
    ResourceConfig?: BackendAPIResourceConfig;
    ResourceName?: string;
}
export declare const CreateBackendAPIRequest: S.Schema<CreateBackendAPIRequest>;
export interface CreateBackendAPIResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export declare const CreateBackendAPIResponse: S.Schema<CreateBackendAPIResponse>;
export type AuthResources = "USER_POOL_ONLY" | "IDENTITY_POOL_AND_USER_POOL" | (string & {});
export declare const AuthResources: any;
export interface CreateBackendAuthIdentityPoolConfig {
    IdentityPoolName?: string;
    UnauthenticatedLogin?: boolean;
}
export declare const CreateBackendAuthIdentityPoolConfig: S.Schema<CreateBackendAuthIdentityPoolConfig>;
export type Service = "COGNITO" | (string & {});
export declare const Service: any;
export type DeliveryMethod = "EMAIL" | "SMS" | (string & {});
export declare const DeliveryMethod: any;
export interface EmailSettings {
    EmailMessage?: string;
    EmailSubject?: string;
}
export declare const EmailSettings: S.Schema<EmailSettings>;
export interface SmsSettings {
    SmsMessage?: string;
}
export declare const SmsSettings: S.Schema<SmsSettings>;
export interface CreateBackendAuthForgotPasswordConfig {
    DeliveryMethod?: DeliveryMethod;
    EmailSettings?: EmailSettings;
    SmsSettings?: SmsSettings;
}
export declare const CreateBackendAuthForgotPasswordConfig: S.Schema<CreateBackendAuthForgotPasswordConfig>;
export type MFAMode = "ON" | "OFF" | "OPTIONAL" | (string & {});
export declare const MFAMode: any;
export type MfaTypesElement = "SMS" | "TOTP" | (string & {});
export declare const MfaTypesElement: any;
export type ListOfMfaTypesElement = MfaTypesElement[];
export declare const ListOfMfaTypesElement: any;
export interface Settings {
    MfaTypes?: MfaTypesElement[];
    SmsMessage?: string;
}
export declare const Settings: S.Schema<Settings>;
export interface CreateBackendAuthMFAConfig {
    MFAMode?: MFAMode;
    Settings?: Settings;
}
export declare const CreateBackendAuthMFAConfig: S.Schema<CreateBackendAuthMFAConfig>;
export type OAuthGrantType = "CODE" | "IMPLICIT" | (string & {});
export declare const OAuthGrantType: any;
export type OAuthScopesElement = "PHONE" | "EMAIL" | "OPENID" | "PROFILE" | "AWS_COGNITO_SIGNIN_USER_ADMIN" | (string & {});
export declare const OAuthScopesElement: any;
export type ListOfOAuthScopesElement = OAuthScopesElement[];
export declare const ListOfOAuthScopesElement: any;
export type ListOf__string = string[];
export declare const ListOf__string: any;
export interface BackendAuthSocialProviderConfig {
    ClientId?: string;
    ClientSecret?: string;
}
export declare const BackendAuthSocialProviderConfig: S.Schema<BackendAuthSocialProviderConfig>;
export interface BackendAuthAppleProviderConfig {
    ClientId?: string;
    KeyId?: string;
    PrivateKey?: string;
    TeamId?: string;
}
export declare const BackendAuthAppleProviderConfig: S.Schema<BackendAuthAppleProviderConfig>;
export interface SocialProviderSettings {
    Facebook?: BackendAuthSocialProviderConfig;
    Google?: BackendAuthSocialProviderConfig;
    LoginWithAmazon?: BackendAuthSocialProviderConfig;
    SignInWithApple?: BackendAuthAppleProviderConfig;
}
export declare const SocialProviderSettings: S.Schema<SocialProviderSettings>;
export interface CreateBackendAuthOAuthConfig {
    DomainPrefix?: string;
    OAuthGrantType?: OAuthGrantType;
    OAuthScopes?: OAuthScopesElement[];
    RedirectSignInURIs?: string[];
    RedirectSignOutURIs?: string[];
    SocialProviderSettings?: SocialProviderSettings;
}
export declare const CreateBackendAuthOAuthConfig: S.Schema<CreateBackendAuthOAuthConfig>;
export type AdditionalConstraintsElement = "REQUIRE_DIGIT" | "REQUIRE_LOWERCASE" | "REQUIRE_SYMBOL" | "REQUIRE_UPPERCASE" | (string & {});
export declare const AdditionalConstraintsElement: any;
export type ListOfAdditionalConstraintsElement = AdditionalConstraintsElement[];
export declare const ListOfAdditionalConstraintsElement: any;
export interface CreateBackendAuthPasswordPolicyConfig {
    AdditionalConstraints?: AdditionalConstraintsElement[];
    MinimumLength?: number;
}
export declare const CreateBackendAuthPasswordPolicyConfig: S.Schema<CreateBackendAuthPasswordPolicyConfig>;
export type RequiredSignUpAttributesElement = "ADDRESS" | "BIRTHDATE" | "EMAIL" | "FAMILY_NAME" | "GENDER" | "GIVEN_NAME" | "LOCALE" | "MIDDLE_NAME" | "NAME" | "NICKNAME" | "PHONE_NUMBER" | "PICTURE" | "PREFERRED_USERNAME" | "PROFILE" | "UPDATED_AT" | "WEBSITE" | "ZONE_INFO" | (string & {});
export declare const RequiredSignUpAttributesElement: any;
export type ListOfRequiredSignUpAttributesElement = RequiredSignUpAttributesElement[];
export declare const ListOfRequiredSignUpAttributesElement: any;
export type SignInMethod = "EMAIL" | "EMAIL_AND_PHONE_NUMBER" | "PHONE_NUMBER" | "USERNAME" | (string & {});
export declare const SignInMethod: any;
export interface CreateBackendAuthVerificationMessageConfig {
    DeliveryMethod?: DeliveryMethod;
    EmailSettings?: EmailSettings;
    SmsSettings?: SmsSettings;
}
export declare const CreateBackendAuthVerificationMessageConfig: S.Schema<CreateBackendAuthVerificationMessageConfig>;
export interface CreateBackendAuthUserPoolConfig {
    ForgotPassword?: CreateBackendAuthForgotPasswordConfig;
    Mfa?: CreateBackendAuthMFAConfig;
    OAuth?: CreateBackendAuthOAuthConfig;
    PasswordPolicy?: CreateBackendAuthPasswordPolicyConfig;
    RequiredSignUpAttributes?: RequiredSignUpAttributesElement[];
    SignInMethod?: SignInMethod;
    UserPoolName?: string;
    VerificationMessage?: CreateBackendAuthVerificationMessageConfig;
}
export declare const CreateBackendAuthUserPoolConfig: S.Schema<CreateBackendAuthUserPoolConfig>;
export interface CreateBackendAuthResourceConfig {
    AuthResources?: AuthResources;
    IdentityPoolConfigs?: CreateBackendAuthIdentityPoolConfig;
    Service?: Service;
    UserPoolConfigs?: CreateBackendAuthUserPoolConfig;
}
export declare const CreateBackendAuthResourceConfig: S.Schema<CreateBackendAuthResourceConfig>;
export interface CreateBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName?: string;
    ResourceConfig?: CreateBackendAuthResourceConfig;
    ResourceName?: string;
}
export declare const CreateBackendAuthRequest: S.Schema<CreateBackendAuthRequest>;
export interface CreateBackendAuthResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export declare const CreateBackendAuthResponse: S.Schema<CreateBackendAuthResponse>;
export interface CreateBackendConfigRequest {
    AppId: string;
    BackendManagerAppId?: string;
}
export declare const CreateBackendConfigRequest: S.Schema<CreateBackendConfigRequest>;
export interface CreateBackendConfigResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    JobId?: string;
    Status?: string;
}
export declare const CreateBackendConfigResponse: S.Schema<CreateBackendConfigResponse>;
export type AuthenticatedElement = "READ" | "CREATE_AND_UPDATE" | "DELETE" | (string & {});
export declare const AuthenticatedElement: any;
export type ListOfAuthenticatedElement = AuthenticatedElement[];
export declare const ListOfAuthenticatedElement: any;
export type UnAuthenticatedElement = "READ" | "CREATE_AND_UPDATE" | "DELETE" | (string & {});
export declare const UnAuthenticatedElement: any;
export type ListOfUnAuthenticatedElement = UnAuthenticatedElement[];
export declare const ListOfUnAuthenticatedElement: any;
export interface BackendStoragePermissions {
    Authenticated?: AuthenticatedElement[];
    UnAuthenticated?: UnAuthenticatedElement[];
}
export declare const BackendStoragePermissions: S.Schema<BackendStoragePermissions>;
export type ServiceName = "S3" | (string & {});
export declare const ServiceName: any;
export interface CreateBackendStorageResourceConfig {
    BucketName?: string;
    Permissions?: BackendStoragePermissions;
    ServiceName?: ServiceName;
}
export declare const CreateBackendStorageResourceConfig: S.Schema<CreateBackendStorageResourceConfig>;
export interface CreateBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName?: string;
    ResourceConfig?: CreateBackendStorageResourceConfig;
    ResourceName?: string;
}
export declare const CreateBackendStorageRequest: S.Schema<CreateBackendStorageRequest>;
export interface CreateBackendStorageResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    JobId?: string;
    Status?: string;
}
export declare const CreateBackendStorageResponse: S.Schema<CreateBackendStorageResponse>;
export interface CreateTokenRequest {
    AppId: string;
}
export declare const CreateTokenRequest: S.Schema<CreateTokenRequest>;
export interface CreateTokenResponse {
    AppId?: string;
    ChallengeCode?: string;
    SessionId?: string;
    Ttl?: string;
}
export declare const CreateTokenResponse: S.Schema<CreateTokenResponse>;
export interface DeleteBackendRequest {
    AppId: string;
    BackendEnvironmentName: string;
}
export declare const DeleteBackendRequest: S.Schema<DeleteBackendRequest>;
export interface DeleteBackendResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export declare const DeleteBackendResponse: S.Schema<DeleteBackendResponse>;
export interface DeleteBackendAPIRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: BackendAPIResourceConfig;
    ResourceName?: string;
}
export declare const DeleteBackendAPIRequest: S.Schema<DeleteBackendAPIRequest>;
export interface DeleteBackendAPIResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export declare const DeleteBackendAPIResponse: S.Schema<DeleteBackendAPIResponse>;
export interface DeleteBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string;
}
export declare const DeleteBackendAuthRequest: S.Schema<DeleteBackendAuthRequest>;
export interface DeleteBackendAuthResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export declare const DeleteBackendAuthResponse: S.Schema<DeleteBackendAuthResponse>;
export interface DeleteBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string;
    ServiceName?: ServiceName;
}
export declare const DeleteBackendStorageRequest: S.Schema<DeleteBackendStorageRequest>;
export interface DeleteBackendStorageResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    JobId?: string;
    Status?: string;
}
export declare const DeleteBackendStorageResponse: S.Schema<DeleteBackendStorageResponse>;
export interface DeleteTokenRequest {
    AppId: string;
    SessionId: string;
}
export declare const DeleteTokenRequest: S.Schema<DeleteTokenRequest>;
export interface DeleteTokenResponse {
    IsSuccess?: boolean;
}
export declare const DeleteTokenResponse: S.Schema<DeleteTokenResponse>;
export interface GenerateBackendAPIModelsRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string;
}
export declare const GenerateBackendAPIModelsRequest: S.Schema<GenerateBackendAPIModelsRequest>;
export interface GenerateBackendAPIModelsResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export declare const GenerateBackendAPIModelsResponse: S.Schema<GenerateBackendAPIModelsResponse>;
export interface GetBackendRequest {
    AppId: string;
    BackendEnvironmentName?: string;
}
export declare const GetBackendRequest: S.Schema<GetBackendRequest>;
export interface GetBackendResponse {
    AmplifyFeatureFlags?: string;
    AmplifyMetaConfig?: string;
    AppId?: string;
    AppName?: string;
    BackendEnvironmentList?: string[];
    BackendEnvironmentName?: string;
    Error?: string;
}
export declare const GetBackendResponse: S.Schema<GetBackendResponse>;
export interface GetBackendAPIRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: BackendAPIResourceConfig;
    ResourceName?: string;
}
export declare const GetBackendAPIRequest: S.Schema<GetBackendAPIRequest>;
export interface GetBackendAPIResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    ResourceConfig?: BackendAPIResourceConfig;
    ResourceName?: string;
}
export declare const GetBackendAPIResponse: S.Schema<GetBackendAPIResponse>;
export interface GetBackendAPIModelsRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string;
}
export declare const GetBackendAPIModelsRequest: S.Schema<GetBackendAPIModelsRequest>;
export type Status = "LATEST" | "STALE" | (string & {});
export declare const Status: any;
export interface GetBackendAPIModelsResponse {
    Models?: string;
    Status?: Status;
    ModelIntrospectionSchema?: string;
}
export declare const GetBackendAPIModelsResponse: S.Schema<GetBackendAPIModelsResponse>;
export interface GetBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string;
}
export declare const GetBackendAuthRequest: S.Schema<GetBackendAuthRequest>;
export interface GetBackendAuthResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    ResourceConfig?: CreateBackendAuthResourceConfig & {
        AuthResources: AuthResources;
        Service: Service;
        UserPoolConfigs: CreateBackendAuthUserPoolConfig & {
            RequiredSignUpAttributes: ListOfRequiredSignUpAttributesElement;
            SignInMethod: SignInMethod;
            UserPoolName: string;
            ForgotPassword: CreateBackendAuthForgotPasswordConfig & {
                DeliveryMethod: DeliveryMethod;
            };
            Mfa: CreateBackendAuthMFAConfig & {
                MFAMode: MFAMode;
            };
            OAuth: CreateBackendAuthOAuthConfig & {
                OAuthGrantType: OAuthGrantType;
                OAuthScopes: ListOfOAuthScopesElement;
                RedirectSignInURIs: ListOf__string;
                RedirectSignOutURIs: ListOf__string;
            };
            PasswordPolicy: CreateBackendAuthPasswordPolicyConfig & {
                MinimumLength: number;
            };
            VerificationMessage: CreateBackendAuthVerificationMessageConfig & {
                DeliveryMethod: DeliveryMethod;
            };
        };
        IdentityPoolConfigs: CreateBackendAuthIdentityPoolConfig & {
            IdentityPoolName: string;
            UnauthenticatedLogin: boolean;
        };
    };
    ResourceName?: string;
}
export declare const GetBackendAuthResponse: S.Schema<GetBackendAuthResponse>;
export interface GetBackendJobRequest {
    AppId: string;
    BackendEnvironmentName: string;
    JobId: string;
}
export declare const GetBackendJobRequest: S.Schema<GetBackendJobRequest>;
export interface GetBackendJobResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    CreateTime?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
    UpdateTime?: string;
}
export declare const GetBackendJobResponse: S.Schema<GetBackendJobResponse>;
export interface GetBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string;
}
export declare const GetBackendStorageRequest: S.Schema<GetBackendStorageRequest>;
export interface GetBackendStorageResourceConfig {
    BucketName?: string;
    Imported?: boolean;
    Permissions?: BackendStoragePermissions;
    ServiceName?: ServiceName;
}
export declare const GetBackendStorageResourceConfig: S.Schema<GetBackendStorageResourceConfig>;
export interface GetBackendStorageResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    ResourceConfig?: GetBackendStorageResourceConfig & {
        Imported: boolean;
        ServiceName: ServiceName;
        Permissions: BackendStoragePermissions & {
            Authenticated: ListOfAuthenticatedElement;
        };
    };
    ResourceName?: string;
}
export declare const GetBackendStorageResponse: S.Schema<GetBackendStorageResponse>;
export interface GetTokenRequest {
    AppId: string;
    SessionId: string;
}
export declare const GetTokenRequest: S.Schema<GetTokenRequest>;
export interface GetTokenResponse {
    AppId?: string;
    ChallengeCode?: string;
    SessionId?: string;
    Ttl?: string;
}
export declare const GetTokenResponse: S.Schema<GetTokenResponse>;
export interface ImportBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName: string;
    IdentityPoolId?: string;
    NativeClientId?: string;
    UserPoolId?: string;
    WebClientId?: string;
}
export declare const ImportBackendAuthRequest: S.Schema<ImportBackendAuthRequest>;
export interface ImportBackendAuthResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export declare const ImportBackendAuthResponse: S.Schema<ImportBackendAuthResponse>;
export interface ImportBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName: string;
    BucketName?: string;
    ServiceName?: ServiceName;
}
export declare const ImportBackendStorageRequest: S.Schema<ImportBackendStorageRequest>;
export interface ImportBackendStorageResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    JobId?: string;
    Status?: string;
}
export declare const ImportBackendStorageResponse: S.Schema<ImportBackendStorageResponse>;
export type __integerMin1Max25 = number;
export interface ListBackendJobsRequest {
    AppId: string;
    BackendEnvironmentName: string;
    JobId?: string;
    MaxResults?: number;
    NextToken?: string;
    Operation?: string;
    Status?: string;
}
export declare const ListBackendJobsRequest: S.Schema<ListBackendJobsRequest>;
export interface BackendJobRespObj {
    AppId?: string;
    BackendEnvironmentName?: string;
    CreateTime?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
    UpdateTime?: string;
}
export declare const BackendJobRespObj: S.Schema<BackendJobRespObj>;
export type ListOfBackendJobRespObj = BackendJobRespObj[];
export declare const ListOfBackendJobRespObj: any;
export interface ListBackendJobsResponse {
    Jobs?: (BackendJobRespObj & {
        AppId: string;
        BackendEnvironmentName: string;
    })[];
    NextToken?: string;
}
export declare const ListBackendJobsResponse: S.Schema<ListBackendJobsResponse>;
export interface ListS3BucketsRequest {
    NextToken?: string;
}
export declare const ListS3BucketsRequest: S.Schema<ListS3BucketsRequest>;
export interface S3BucketInfo {
    CreationDate?: string;
    Name?: string;
}
export declare const S3BucketInfo: S.Schema<S3BucketInfo>;
export type ListOfS3BucketInfo = S3BucketInfo[];
export declare const ListOfS3BucketInfo: any;
export interface ListS3BucketsResponse {
    Buckets?: S3BucketInfo[];
    NextToken?: string;
}
export declare const ListS3BucketsResponse: S.Schema<ListS3BucketsResponse>;
export interface RemoveAllBackendsRequest {
    AppId: string;
    CleanAmplifyApp?: boolean;
}
export declare const RemoveAllBackendsRequest: S.Schema<RemoveAllBackendsRequest>;
export interface RemoveAllBackendsResponse {
    AppId?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export declare const RemoveAllBackendsResponse: S.Schema<RemoveAllBackendsResponse>;
export interface RemoveBackendConfigRequest {
    AppId: string;
}
export declare const RemoveBackendConfigRequest: S.Schema<RemoveBackendConfigRequest>;
export interface RemoveBackendConfigResponse {
    Error?: string;
}
export declare const RemoveBackendConfigResponse: S.Schema<RemoveBackendConfigResponse>;
export interface UpdateBackendAPIRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: BackendAPIResourceConfig;
    ResourceName?: string;
}
export declare const UpdateBackendAPIRequest: S.Schema<UpdateBackendAPIRequest>;
export interface UpdateBackendAPIResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export declare const UpdateBackendAPIResponse: S.Schema<UpdateBackendAPIResponse>;
export interface UpdateBackendAuthIdentityPoolConfig {
    UnauthenticatedLogin?: boolean;
}
export declare const UpdateBackendAuthIdentityPoolConfig: S.Schema<UpdateBackendAuthIdentityPoolConfig>;
export interface UpdateBackendAuthForgotPasswordConfig {
    DeliveryMethod?: DeliveryMethod;
    EmailSettings?: EmailSettings;
    SmsSettings?: SmsSettings;
}
export declare const UpdateBackendAuthForgotPasswordConfig: S.Schema<UpdateBackendAuthForgotPasswordConfig>;
export interface UpdateBackendAuthMFAConfig {
    MFAMode?: MFAMode;
    Settings?: Settings;
}
export declare const UpdateBackendAuthMFAConfig: S.Schema<UpdateBackendAuthMFAConfig>;
export interface UpdateBackendAuthOAuthConfig {
    DomainPrefix?: string;
    OAuthGrantType?: OAuthGrantType;
    OAuthScopes?: OAuthScopesElement[];
    RedirectSignInURIs?: string[];
    RedirectSignOutURIs?: string[];
    SocialProviderSettings?: SocialProviderSettings;
}
export declare const UpdateBackendAuthOAuthConfig: S.Schema<UpdateBackendAuthOAuthConfig>;
export interface UpdateBackendAuthPasswordPolicyConfig {
    AdditionalConstraints?: AdditionalConstraintsElement[];
    MinimumLength?: number;
}
export declare const UpdateBackendAuthPasswordPolicyConfig: S.Schema<UpdateBackendAuthPasswordPolicyConfig>;
export interface UpdateBackendAuthVerificationMessageConfig {
    DeliveryMethod?: DeliveryMethod;
    EmailSettings?: EmailSettings;
    SmsSettings?: SmsSettings;
}
export declare const UpdateBackendAuthVerificationMessageConfig: S.Schema<UpdateBackendAuthVerificationMessageConfig>;
export interface UpdateBackendAuthUserPoolConfig {
    ForgotPassword?: UpdateBackendAuthForgotPasswordConfig;
    Mfa?: UpdateBackendAuthMFAConfig;
    OAuth?: UpdateBackendAuthOAuthConfig;
    PasswordPolicy?: UpdateBackendAuthPasswordPolicyConfig;
    VerificationMessage?: UpdateBackendAuthVerificationMessageConfig;
}
export declare const UpdateBackendAuthUserPoolConfig: S.Schema<UpdateBackendAuthUserPoolConfig>;
export interface UpdateBackendAuthResourceConfig {
    AuthResources?: AuthResources;
    IdentityPoolConfigs?: UpdateBackendAuthIdentityPoolConfig;
    Service?: Service;
    UserPoolConfigs?: UpdateBackendAuthUserPoolConfig;
}
export declare const UpdateBackendAuthResourceConfig: S.Schema<UpdateBackendAuthResourceConfig>;
export interface UpdateBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: UpdateBackendAuthResourceConfig;
    ResourceName?: string;
}
export declare const UpdateBackendAuthRequest: S.Schema<UpdateBackendAuthRequest>;
export interface UpdateBackendAuthResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export declare const UpdateBackendAuthResponse: S.Schema<UpdateBackendAuthResponse>;
export interface LoginAuthConfigReqObj {
    AwsCognitoIdentityPoolId?: string;
    AwsCognitoRegion?: string;
    AwsUserPoolsId?: string;
    AwsUserPoolsWebClientId?: string;
}
export declare const LoginAuthConfigReqObj: S.Schema<LoginAuthConfigReqObj>;
export interface UpdateBackendConfigRequest {
    AppId: string;
    LoginAuthConfig?: LoginAuthConfigReqObj;
}
export declare const UpdateBackendConfigRequest: S.Schema<UpdateBackendConfigRequest>;
export interface UpdateBackendConfigResponse {
    AppId?: string;
    BackendManagerAppId?: string;
    Error?: string;
    LoginAuthConfig?: LoginAuthConfigReqObj;
}
export declare const UpdateBackendConfigResponse: S.Schema<UpdateBackendConfigResponse>;
export interface UpdateBackendJobRequest {
    AppId: string;
    BackendEnvironmentName: string;
    JobId: string;
    Operation?: string;
    Status?: string;
}
export declare const UpdateBackendJobRequest: S.Schema<UpdateBackendJobRequest>;
export interface UpdateBackendJobResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    CreateTime?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
    UpdateTime?: string;
}
export declare const UpdateBackendJobResponse: S.Schema<UpdateBackendJobResponse>;
export interface UpdateBackendStorageResourceConfig {
    Permissions?: BackendStoragePermissions;
    ServiceName?: ServiceName;
}
export declare const UpdateBackendStorageResourceConfig: S.Schema<UpdateBackendStorageResourceConfig>;
export interface UpdateBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: UpdateBackendStorageResourceConfig;
    ResourceName?: string;
}
export declare const UpdateBackendStorageRequest: S.Schema<UpdateBackendStorageRequest>;
export interface UpdateBackendStorageResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    JobId?: string;
    Status?: string;
}
export declare const UpdateBackendStorageResponse: S.Schema<UpdateBackendStorageResponse>;
export type CloneBackendError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * This operation clones an existing backend.
 */
export declare const cloneBackend: API.OperationMethod<CloneBackendRequest, CloneBackendResponse, CloneBackendError, Credentials | HttpClient.HttpClient>;
export type CreateBackendError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * This operation creates a backend for an Amplify app. Backends are automatically created at the time of app creation.
 */
export declare const createBackend: API.OperationMethod<CreateBackendRequest, CreateBackendResponse, CreateBackendError, Credentials | HttpClient.HttpClient>;
export type CreateBackendAPIError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new backend API resource.
 */
export declare const createBackendAPI: API.OperationMethod<CreateBackendAPIRequest, CreateBackendAPIResponse, CreateBackendAPIError, Credentials | HttpClient.HttpClient>;
export type CreateBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new backend authentication resource.
 */
export declare const createBackendAuth: API.OperationMethod<CreateBackendAuthRequest, CreateBackendAuthResponse, CreateBackendAuthError, Credentials | HttpClient.HttpClient>;
export type CreateBackendConfigError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a config object for a backend.
 */
export declare const createBackendConfig: API.OperationMethod<CreateBackendConfigRequest, CreateBackendConfigResponse, CreateBackendConfigError, Credentials | HttpClient.HttpClient>;
export type CreateBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a backend storage resource.
 */
export declare const createBackendStorage: API.OperationMethod<CreateBackendStorageRequest, CreateBackendStorageResponse, CreateBackendStorageError, Credentials | HttpClient.HttpClient>;
export type CreateTokenError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Generates a one-time challenge code to authenticate a user into your Amplify Admin UI.
 */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes an existing environment from your Amplify project.
 */
export declare const deleteBackend: API.OperationMethod<DeleteBackendRequest, DeleteBackendResponse, DeleteBackendError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendAPIError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing backend API resource.
 */
export declare const deleteBackendAPI: API.OperationMethod<DeleteBackendAPIRequest, DeleteBackendAPIResponse, DeleteBackendAPIError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing backend authentication resource.
 */
export declare const deleteBackendAuth: API.OperationMethod<DeleteBackendAuthRequest, DeleteBackendAuthResponse, DeleteBackendAuthError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes the specified backend storage resource.
 */
export declare const deleteBackendStorage: API.OperationMethod<DeleteBackendStorageRequest, DeleteBackendStorageResponse, DeleteBackendStorageError, Credentials | HttpClient.HttpClient>;
export type DeleteTokenError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the challenge token based on the given appId and sessionId.
 */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, Credentials | HttpClient.HttpClient>;
export type GenerateBackendAPIModelsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Generates a model schema for an existing backend API resource.
 */
export declare const generateBackendAPIModels: API.OperationMethod<GenerateBackendAPIModelsRequest, GenerateBackendAPIModelsResponse, GenerateBackendAPIModelsError, Credentials | HttpClient.HttpClient>;
export type GetBackendError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Provides project-level details for your Amplify UI project.
 */
export declare const getBackend: API.OperationMethod<GetBackendRequest, GetBackendResponse, GetBackendError, Credentials | HttpClient.HttpClient>;
export type GetBackendAPIError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the details for a backend API.
 */
export declare const getBackendAPI: API.OperationMethod<GetBackendAPIRequest, GetBackendAPIResponse, GetBackendAPIError, Credentials | HttpClient.HttpClient>;
export type GetBackendAPIModelsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a model introspection schema for an existing backend API resource.
 */
export declare const getBackendAPIModels: API.OperationMethod<GetBackendAPIModelsRequest, GetBackendAPIModelsResponse, GetBackendAPIModelsError, Credentials | HttpClient.HttpClient>;
export type GetBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a backend auth details.
 */
export declare const getBackendAuth: API.OperationMethod<GetBackendAuthRequest, GetBackendAuthResponse, GetBackendAuthError, Credentials | HttpClient.HttpClient>;
export type GetBackendJobError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns information about a specific job.
 */
export declare const getBackendJob: API.OperationMethod<GetBackendJobRequest, GetBackendJobResponse, GetBackendJobError, Credentials | HttpClient.HttpClient>;
export type GetBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details for a backend storage resource.
 */
export declare const getBackendStorage: API.OperationMethod<GetBackendStorageRequest, GetBackendStorageResponse, GetBackendStorageError, Credentials | HttpClient.HttpClient>;
export type GetTokenError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the challenge token based on the given appId and sessionId.
 */
export declare const getToken: API.OperationMethod<GetTokenRequest, GetTokenResponse, GetTokenError, Credentials | HttpClient.HttpClient>;
export type ImportBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Imports an existing backend authentication resource.
 */
export declare const importBackendAuth: API.OperationMethod<ImportBackendAuthRequest, ImportBackendAuthResponse, ImportBackendAuthError, Credentials | HttpClient.HttpClient>;
export type ImportBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Imports an existing backend storage resource.
 */
export declare const importBackendStorage: API.OperationMethod<ImportBackendStorageRequest, ImportBackendStorageResponse, ImportBackendStorageError, Credentials | HttpClient.HttpClient>;
export type ListBackendJobsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the jobs for the backend of an Amplify app.
 */
export declare const listBackendJobs: API.OperationMethod<ListBackendJobsRequest, ListBackendJobsResponse, ListBackendJobsError, Credentials | HttpClient.HttpClient>;
export type ListS3BucketsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * The list of S3 buckets in your account.
 */
export declare const listS3Buckets: API.OperationMethod<ListS3BucketsRequest, ListS3BucketsResponse, ListS3BucketsError, Credentials | HttpClient.HttpClient>;
export type RemoveAllBackendsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes all backend environments from your Amplify project.
 */
export declare const removeAllBackends: API.OperationMethod<RemoveAllBackendsRequest, RemoveAllBackendsResponse, RemoveAllBackendsError, Credentials | HttpClient.HttpClient>;
export type RemoveBackendConfigError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes the AWS resources required to access the Amplify Admin UI.
 */
export declare const removeBackendConfig: API.OperationMethod<RemoveBackendConfigRequest, RemoveBackendConfigResponse, RemoveBackendConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendAPIError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing backend API resource.
 */
export declare const updateBackendAPI: API.OperationMethod<UpdateBackendAPIRequest, UpdateBackendAPIResponse, UpdateBackendAPIError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing backend authentication resource.
 */
export declare const updateBackendAuth: API.OperationMethod<UpdateBackendAuthRequest, UpdateBackendAuthResponse, UpdateBackendAuthError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendConfigError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the AWS resources required to access the Amplify Admin UI.
 */
export declare const updateBackendConfig: API.OperationMethod<UpdateBackendConfigRequest, UpdateBackendConfigResponse, UpdateBackendConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendJobError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a specific job.
 */
export declare const updateBackendJob: API.OperationMethod<UpdateBackendJobRequest, UpdateBackendJobResponse, UpdateBackendJobError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing backend storage resource.
 */
export declare const updateBackendStorage: API.OperationMethod<UpdateBackendStorageRequest, UpdateBackendStorageResponse, UpdateBackendStorageError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=amplifybackend.d.ts.map