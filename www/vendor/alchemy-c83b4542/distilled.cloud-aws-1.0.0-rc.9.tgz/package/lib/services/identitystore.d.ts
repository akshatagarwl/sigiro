import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly RequestId: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly ResourceType: any;
    readonly ResourceId: any;
    readonly Reason: any;
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly RequestId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly RequestId: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type IdentityStoreId = string;
export type GroupDisplayName = string | redacted.Redacted<string>;
export type SensitiveStringType = string | redacted.Redacted<string>;
export interface CreateGroupRequest {
    IdentityStoreId: string;
    DisplayName?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
}
export declare const CreateGroupRequest: S.Schema<CreateGroupRequest>;
export type ResourceId = string;
export interface CreateGroupResponse {
    GroupId: string;
    IdentityStoreId: string;
}
export declare const CreateGroupResponse: S.Schema<CreateGroupResponse>;
export type MemberId = {
    UserId: string;
};
export declare const MemberId: any;
export interface CreateGroupMembershipRequest {
    IdentityStoreId: string;
    GroupId: string;
    MemberId: MemberId;
}
export declare const CreateGroupMembershipRequest: S.Schema<CreateGroupMembershipRequest>;
export interface CreateGroupMembershipResponse {
    MembershipId: string;
    IdentityStoreId: string;
}
export declare const CreateGroupMembershipResponse: S.Schema<CreateGroupMembershipResponse>;
export type UserName = string | redacted.Redacted<string>;
export interface Name {
    Formatted?: string | redacted.Redacted<string>;
    FamilyName?: string | redacted.Redacted<string>;
    GivenName?: string | redacted.Redacted<string>;
    MiddleName?: string | redacted.Redacted<string>;
    HonorificPrefix?: string | redacted.Redacted<string>;
    HonorificSuffix?: string | redacted.Redacted<string>;
}
export declare const Name: S.Schema<Name>;
export interface Email {
    Value?: string | redacted.Redacted<string>;
    Type?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export declare const Email: S.Schema<Email>;
export type Emails = Email[];
export declare const Emails: any;
export interface Address {
    StreetAddress?: string | redacted.Redacted<string>;
    Locality?: string | redacted.Redacted<string>;
    Region?: string | redacted.Redacted<string>;
    PostalCode?: string | redacted.Redacted<string>;
    Country?: string | redacted.Redacted<string>;
    Formatted?: string | redacted.Redacted<string>;
    Type?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export declare const Address: S.Schema<Address>;
export type Addresses = Address[];
export declare const Addresses: any;
export interface PhoneNumber {
    Value?: string | redacted.Redacted<string>;
    Type?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export declare const PhoneNumber: S.Schema<PhoneNumber>;
export type PhoneNumbers = PhoneNumber[];
export declare const PhoneNumbers: any;
export interface Photo {
    Value: string | redacted.Redacted<string>;
    Type?: string | redacted.Redacted<string>;
    Display?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export declare const Photo: S.Schema<Photo>;
export type Photos = Photo[];
export declare const Photos: any;
export interface Role {
    Value?: string | redacted.Redacted<string>;
    Type?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export declare const Role: S.Schema<Role>;
export type Roles = Role[];
export declare const Roles: any;
export type ExtensionName = string;
export type AttributeValue = unknown;
export type Extensions = {
    [key: string]: any | undefined;
};
export declare const Extensions: any;
export interface CreateUserRequest {
    IdentityStoreId: string;
    UserName?: string | redacted.Redacted<string>;
    Name?: Name;
    DisplayName?: string | redacted.Redacted<string>;
    NickName?: string | redacted.Redacted<string>;
    ProfileUrl?: string | redacted.Redacted<string>;
    Emails?: Email[];
    Addresses?: Address[];
    PhoneNumbers?: PhoneNumber[];
    UserType?: string | redacted.Redacted<string>;
    Title?: string | redacted.Redacted<string>;
    PreferredLanguage?: string | redacted.Redacted<string>;
    Locale?: string | redacted.Redacted<string>;
    Timezone?: string | redacted.Redacted<string>;
    Photos?: Photo[];
    Website?: string | redacted.Redacted<string>;
    Birthdate?: string | redacted.Redacted<string>;
    Roles?: Role[];
    Extensions?: {
        [key: string]: any | undefined;
    };
}
export declare const CreateUserRequest: S.Schema<CreateUserRequest>;
export interface CreateUserResponse {
    IdentityStoreId: string;
    UserId: string;
}
export declare const CreateUserResponse: S.Schema<CreateUserResponse>;
export interface DeleteGroupRequest {
    IdentityStoreId: string;
    GroupId: string;
}
export declare const DeleteGroupRequest: S.Schema<DeleteGroupRequest>;
export interface DeleteGroupResponse {
}
export declare const DeleteGroupResponse: S.Schema<DeleteGroupResponse>;
export interface DeleteGroupMembershipRequest {
    IdentityStoreId: string;
    MembershipId: string;
}
export declare const DeleteGroupMembershipRequest: S.Schema<DeleteGroupMembershipRequest>;
export interface DeleteGroupMembershipResponse {
}
export declare const DeleteGroupMembershipResponse: S.Schema<DeleteGroupMembershipResponse>;
export interface DeleteUserRequest {
    IdentityStoreId: string;
    UserId: string;
}
export declare const DeleteUserRequest: S.Schema<DeleteUserRequest>;
export interface DeleteUserResponse {
}
export declare const DeleteUserResponse: S.Schema<DeleteUserResponse>;
export interface DescribeGroupRequest {
    IdentityStoreId: string;
    GroupId: string;
}
export declare const DescribeGroupRequest: S.Schema<DescribeGroupRequest>;
export type ExternalIdIssuer = string | redacted.Redacted<string>;
export type ExternalIdIdentifier = string | redacted.Redacted<string>;
export interface ExternalId {
    Issuer: string | redacted.Redacted<string>;
    Id: string | redacted.Redacted<string>;
}
export declare const ExternalId: S.Schema<ExternalId>;
export type ExternalIds = ExternalId[];
export declare const ExternalIds: any;
export type StringType = string;
export interface DescribeGroupResponse {
    GroupId: string;
    DisplayName?: string | redacted.Redacted<string>;
    ExternalIds?: ExternalId[];
    Description?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    CreatedBy?: string;
    UpdatedBy?: string;
    IdentityStoreId: string;
}
export declare const DescribeGroupResponse: S.Schema<DescribeGroupResponse>;
export interface DescribeGroupMembershipRequest {
    IdentityStoreId: string;
    MembershipId: string;
}
export declare const DescribeGroupMembershipRequest: S.Schema<DescribeGroupMembershipRequest>;
export interface DescribeGroupMembershipResponse {
    IdentityStoreId: string;
    MembershipId: string;
    GroupId: string;
    MemberId: MemberId;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    CreatedBy?: string;
    UpdatedBy?: string;
}
export declare const DescribeGroupMembershipResponse: S.Schema<DescribeGroupMembershipResponse>;
export type ExtensionNames = string[];
export declare const ExtensionNames: any;
export interface DescribeUserRequest {
    IdentityStoreId: string;
    UserId: string;
    Extensions?: string[];
}
export declare const DescribeUserRequest: S.Schema<DescribeUserRequest>;
export type UserStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const UserStatus: any;
export interface DescribeUserResponse {
    IdentityStoreId: string;
    UserId: string;
    UserName?: string | redacted.Redacted<string>;
    ExternalIds?: ExternalId[];
    Name?: Name;
    DisplayName?: string | redacted.Redacted<string>;
    NickName?: string | redacted.Redacted<string>;
    ProfileUrl?: string | redacted.Redacted<string>;
    Emails?: Email[];
    Addresses?: Address[];
    PhoneNumbers?: PhoneNumber[];
    UserType?: string | redacted.Redacted<string>;
    Title?: string | redacted.Redacted<string>;
    PreferredLanguage?: string | redacted.Redacted<string>;
    Locale?: string | redacted.Redacted<string>;
    Timezone?: string | redacted.Redacted<string>;
    UserStatus?: UserStatus;
    Photos?: Photo[];
    Website?: string | redacted.Redacted<string>;
    Birthdate?: string | redacted.Redacted<string>;
    Roles?: Role[];
    CreatedAt?: Date;
    CreatedBy?: string;
    UpdatedAt?: Date;
    UpdatedBy?: string;
    Extensions?: {
        [key: string]: any | undefined;
    };
}
export declare const DescribeUserResponse: S.Schema<DescribeUserResponse>;
export type AttributePath = string;
export interface UniqueAttribute {
    AttributePath: string;
    AttributeValue: any;
}
export declare const UniqueAttribute: S.Schema<UniqueAttribute>;
export type AlternateIdentifier = {
    ExternalId: ExternalId;
    UniqueAttribute?: never;
} | {
    ExternalId?: never;
    UniqueAttribute: UniqueAttribute;
};
export declare const AlternateIdentifier: any;
export interface GetGroupIdRequest {
    IdentityStoreId: string;
    AlternateIdentifier: AlternateIdentifier;
}
export declare const GetGroupIdRequest: S.Schema<GetGroupIdRequest>;
export interface GetGroupIdResponse {
    GroupId: string;
    IdentityStoreId: string;
}
export declare const GetGroupIdResponse: S.Schema<GetGroupIdResponse>;
export interface GetGroupMembershipIdRequest {
    IdentityStoreId: string;
    GroupId: string;
    MemberId: MemberId;
}
export declare const GetGroupMembershipIdRequest: S.Schema<GetGroupMembershipIdRequest>;
export interface GetGroupMembershipIdResponse {
    MembershipId: string;
    IdentityStoreId: string;
}
export declare const GetGroupMembershipIdResponse: S.Schema<GetGroupMembershipIdResponse>;
export interface GetUserIdRequest {
    IdentityStoreId: string;
    AlternateIdentifier: AlternateIdentifier;
}
export declare const GetUserIdRequest: S.Schema<GetUserIdRequest>;
export interface GetUserIdResponse {
    IdentityStoreId: string;
    UserId: string;
}
export declare const GetUserIdResponse: S.Schema<GetUserIdResponse>;
export type GroupIds = string[];
export declare const GroupIds: any;
export interface IsMemberInGroupsRequest {
    IdentityStoreId: string;
    MemberId: MemberId;
    GroupIds: string[];
}
export declare const IsMemberInGroupsRequest: S.Schema<IsMemberInGroupsRequest>;
export interface GroupMembershipExistenceResult {
    GroupId?: string;
    MemberId?: MemberId;
    MembershipExists?: boolean;
}
export declare const GroupMembershipExistenceResult: S.Schema<GroupMembershipExistenceResult>;
export type GroupMembershipExistenceResults = GroupMembershipExistenceResult[];
export declare const GroupMembershipExistenceResults: any;
export interface IsMemberInGroupsResponse {
    Results: GroupMembershipExistenceResult[];
}
export declare const IsMemberInGroupsResponse: S.Schema<IsMemberInGroupsResponse>;
export type MaxResults = number;
export type NextToken = string;
export interface ListGroupMembershipsRequest {
    IdentityStoreId: string;
    GroupId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListGroupMembershipsRequest: S.Schema<ListGroupMembershipsRequest>;
export interface GroupMembership {
    IdentityStoreId: string;
    MembershipId?: string;
    GroupId?: string;
    MemberId?: MemberId;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    CreatedBy?: string;
    UpdatedBy?: string;
}
export declare const GroupMembership: S.Schema<GroupMembership>;
export type GroupMemberships = GroupMembership[];
export declare const GroupMemberships: any;
export interface ListGroupMembershipsResponse {
    GroupMemberships: GroupMembership[];
    NextToken?: string;
}
export declare const ListGroupMembershipsResponse: S.Schema<ListGroupMembershipsResponse>;
export interface ListGroupMembershipsForMemberRequest {
    IdentityStoreId: string;
    MemberId: MemberId;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListGroupMembershipsForMemberRequest: S.Schema<ListGroupMembershipsForMemberRequest>;
export interface ListGroupMembershipsForMemberResponse {
    GroupMemberships: GroupMembership[];
    NextToken?: string;
}
export declare const ListGroupMembershipsForMemberResponse: S.Schema<ListGroupMembershipsForMemberResponse>;
export interface Filter {
    AttributePath: string;
    AttributeValue: string | redacted.Redacted<string>;
}
export declare const Filter: S.Schema<Filter>;
export type Filters = Filter[];
export declare const Filters: any;
export interface ListGroupsRequest {
    IdentityStoreId: string;
    MaxResults?: number;
    NextToken?: string;
    Filters?: Filter[];
}
export declare const ListGroupsRequest: S.Schema<ListGroupsRequest>;
export interface Group {
    GroupId: string;
    DisplayName?: string | redacted.Redacted<string>;
    ExternalIds?: ExternalId[];
    Description?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    CreatedBy?: string;
    UpdatedBy?: string;
    IdentityStoreId: string;
}
export declare const Group: S.Schema<Group>;
export type Groups = Group[];
export declare const Groups: any;
export interface ListGroupsResponse {
    Groups: Group[];
    NextToken?: string;
}
export declare const ListGroupsResponse: S.Schema<ListGroupsResponse>;
export interface ListUsersRequest {
    IdentityStoreId: string;
    Extensions?: string[];
    MaxResults?: number;
    NextToken?: string;
    Filters?: Filter[];
}
export declare const ListUsersRequest: S.Schema<ListUsersRequest>;
export interface User {
    IdentityStoreId: string;
    UserId: string;
    UserName?: string | redacted.Redacted<string>;
    ExternalIds?: ExternalId[];
    Name?: Name;
    DisplayName?: string | redacted.Redacted<string>;
    NickName?: string | redacted.Redacted<string>;
    ProfileUrl?: string | redacted.Redacted<string>;
    Emails?: Email[];
    Addresses?: Address[];
    PhoneNumbers?: PhoneNumber[];
    UserType?: string | redacted.Redacted<string>;
    Title?: string | redacted.Redacted<string>;
    PreferredLanguage?: string | redacted.Redacted<string>;
    Locale?: string | redacted.Redacted<string>;
    Timezone?: string | redacted.Redacted<string>;
    UserStatus?: UserStatus;
    Photos?: Photo[];
    Website?: string | redacted.Redacted<string>;
    Birthdate?: string | redacted.Redacted<string>;
    Roles?: Role[];
    CreatedAt?: Date;
    CreatedBy?: string;
    UpdatedAt?: Date;
    UpdatedBy?: string;
    Extensions?: {
        [key: string]: any | undefined;
    };
}
export declare const User: S.Schema<User>;
export type Users = User[];
export declare const Users: any;
export interface ListUsersResponse {
    Users: User[];
    NextToken?: string;
}
export declare const ListUsersResponse: S.Schema<ListUsersResponse>;
export interface AttributeOperation {
    AttributePath: string;
    AttributeValue?: any;
}
export declare const AttributeOperation: S.Schema<AttributeOperation>;
export type AttributeOperations = AttributeOperation[];
export declare const AttributeOperations: any;
export interface UpdateGroupRequest {
    IdentityStoreId: string;
    GroupId: string;
    Operations: AttributeOperation[];
}
export declare const UpdateGroupRequest: S.Schema<UpdateGroupRequest>;
export interface UpdateGroupResponse {
}
export declare const UpdateGroupResponse: S.Schema<UpdateGroupResponse>;
export interface UpdateUserRequest {
    IdentityStoreId: string;
    UserId: string;
    Operations: AttributeOperation[];
}
export declare const UpdateUserRequest: S.Schema<UpdateUserRequest>;
export interface UpdateUserResponse {
}
export declare const UpdateUserResponse: S.Schema<UpdateUserResponse>;
export type ExceptionMessage = string;
export type RequestId = string;
export type ConflictExceptionReason = "UNIQUENESS_CONSTRAINT_VIOLATION" | "CONCURRENT_MODIFICATION" | (string & {});
export declare const ConflictExceptionReason: any;
export type ResourceType = "GROUP" | "USER" | "IDENTITY_STORE" | "GROUP_MEMBERSHIP" | "RESOURCE_POLICY" | (string & {});
export declare const ResourceType: any;
export type ResourceNotFoundExceptionReason = "KMS_KEY_NOT_FOUND" | (string & {});
export declare const ResourceNotFoundExceptionReason: any;
export type ValidationExceptionReason = "KMS_INVALID_ARN" | "KMS_INVALID_KEY_USAGE" | "KMS_INVALID_STATE" | "KMS_DISABLED" | (string & {});
export declare const ValidationExceptionReason: any;
export type CreateGroupError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a group within the specified identity store.
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest, CreateGroupResponse, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateGroupMembershipError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a relationship between a member and a group. The following identifiers must be specified: `GroupId`, `IdentityStoreId`, and `MemberId`.
 */
export declare const createGroupMembership: API.OperationMethod<CreateGroupMembershipRequest, CreateGroupMembershipResponse, CreateGroupMembershipError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a user within the specified identity store.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest, CreateUserResponse, CreateUserError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete a group within an identity store given `GroupId`.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest, DeleteGroupResponse, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupMembershipError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete a membership within a group given `MembershipId`.
 */
export declare const deleteGroupMembership: API.OperationMethod<DeleteGroupMembershipRequest, DeleteGroupMembershipResponse, DeleteGroupMembershipError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a user within an identity store given `UserId`.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DescribeGroupError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the group metadata and attributes from `GroupId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const describeGroup: API.OperationMethod<DescribeGroupRequest, DescribeGroupResponse, DescribeGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeGroupMembershipError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves membership metadata and attributes from `MembershipId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const describeGroupMembership: API.OperationMethod<DescribeGroupMembershipRequest, DescribeGroupMembershipResponse, DescribeGroupMembershipError, Credentials | HttpClient.HttpClient>;
export type DescribeUserError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the user metadata and attributes from the `UserId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const describeUser: API.OperationMethod<DescribeUserRequest, DescribeUserResponse, DescribeUserError, Credentials | HttpClient.HttpClient>;
export type GetGroupIdError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves `GroupId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const getGroupId: API.OperationMethod<GetGroupIdRequest, GetGroupIdResponse, GetGroupIdError, Credentials | HttpClient.HttpClient>;
export type GetGroupMembershipIdError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the `MembershipId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const getGroupMembershipId: API.OperationMethod<GetGroupMembershipIdRequest, GetGroupMembershipIdResponse, GetGroupMembershipIdError, Credentials | HttpClient.HttpClient>;
export type GetUserIdError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the `UserId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const getUserId: API.OperationMethod<GetUserIdRequest, GetUserIdResponse, GetUserIdError, Credentials | HttpClient.HttpClient>;
export type IsMemberInGroupsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Checks the user's membership in all requested groups and returns if the member exists in all queried groups.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const isMemberInGroups: API.OperationMethod<IsMemberInGroupsRequest, IsMemberInGroupsResponse, IsMemberInGroupsError, Credentials | HttpClient.HttpClient>;
export type ListGroupMembershipsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * For the specified group in the specified identity store, returns the list of all ` GroupMembership` objects and returns results in paginated form.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const listGroupMemberships: API.PaginatedOperationMethod<ListGroupMembershipsRequest, ListGroupMembershipsResponse, ListGroupMembershipsError, Credentials | HttpClient.HttpClient, GroupMembership>;
export type ListGroupMembershipsForMemberError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * For the specified member in the specified identity store, returns the list of all ` GroupMembership` objects and returns results in paginated form.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const listGroupMembershipsForMember: API.PaginatedOperationMethod<ListGroupMembershipsForMemberRequest, ListGroupMembershipsForMemberResponse, ListGroupMembershipsForMemberError, Credentials | HttpClient.HttpClient, GroupMembership>;
export type ListGroupsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all groups in the identity store. Returns a paginated list of complete `Group` objects. Filtering for a `Group` by the `DisplayName` attribute is deprecated. Instead, use the `GetGroupId` API action.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsRequest, ListGroupsResponse, ListGroupsError, Credentials | HttpClient.HttpClient, Group>;
export type ListUsersError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all users in the identity store. Returns a paginated list of complete `User` objects. Filtering for a `User` by the `UserName` attribute is deprecated. Instead, use the `GetUserId` API action.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest, ListUsersResponse, ListUsersError, Credentials | HttpClient.HttpClient, User>;
export type UpdateGroupError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates the specified group metadata and attributes in the specified identity store.
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest, UpdateGroupResponse, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates the specified user metadata and attributes in the specified identity store.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=identitystore.d.ts.map