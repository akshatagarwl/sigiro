import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccountNotManagementOrDelegatedAdministratorException_base: S.Class<AccountNotManagementOrDelegatedAdministratorException, S.TaggedStruct<"AccountNotManagementOrDelegatedAdministratorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccountNotManagementOrDelegatedAdministratorException extends /*@__PURE__*/ AccountNotManagementOrDelegatedAdministratorException_base {
}
declare const CallerIsNotManagementAccountException_base: S.Class<CallerIsNotManagementAccountException, S.TaggedStruct<"CallerIsNotManagementAccountException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CallerIsNotManagementAccountException extends /*@__PURE__*/ CallerIsNotManagementAccountException_base {
}
declare const ConcurrentModificationException_base: S.Class<ConcurrentModificationException, S.TaggedStruct<"ConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const CredentialReportExpiredException_base: S.Class<CredentialReportExpiredException, S.TaggedStruct<"CredentialReportExpiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CredentialReportExpiredException extends /*@__PURE__*/ CredentialReportExpiredException_base {
}
declare const CredentialReportNotPresentException_base: S.Class<CredentialReportNotPresentException, S.TaggedStruct<"CredentialReportNotPresentException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CredentialReportNotPresentException extends /*@__PURE__*/ CredentialReportNotPresentException_base {
}
declare const CredentialReportNotReadyException_base: S.Class<CredentialReportNotReadyException, S.TaggedStruct<"CredentialReportNotReadyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CredentialReportNotReadyException extends /*@__PURE__*/ CredentialReportNotReadyException_base {
}
declare const DeleteConflictException_base: S.Class<DeleteConflictException, S.TaggedStruct<"DeleteConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DeleteConflictException extends /*@__PURE__*/ DeleteConflictException_base {
}
declare const DuplicateCertificateException_base: S.Class<DuplicateCertificateException, S.TaggedStruct<"DuplicateCertificateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateCertificateException extends /*@__PURE__*/ DuplicateCertificateException_base {
}
declare const DuplicateSSHPublicKeyException_base: S.Class<DuplicateSSHPublicKeyException, S.TaggedStruct<"DuplicateSSHPublicKeyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateSSHPublicKeyException extends /*@__PURE__*/ DuplicateSSHPublicKeyException_base {
}
declare const EntityAlreadyExistsException_base: S.Class<EntityAlreadyExistsException, S.TaggedStruct<"EntityAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EntityAlreadyExistsException extends /*@__PURE__*/ EntityAlreadyExistsException_base {
}
declare const EntityTemporarilyUnmodifiableException_base: S.Class<EntityTemporarilyUnmodifiableException, S.TaggedStruct<"EntityTemporarilyUnmodifiableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class EntityTemporarilyUnmodifiableException extends /*@__PURE__*/ EntityTemporarilyUnmodifiableException_base {
}
declare const FeatureDisabledException_base: S.Class<FeatureDisabledException, S.TaggedStruct<"FeatureDisabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FeatureDisabledException extends /*@__PURE__*/ FeatureDisabledException_base {
}
declare const FeatureEnabledException_base: S.Class<FeatureEnabledException, S.TaggedStruct<"FeatureEnabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class FeatureEnabledException extends /*@__PURE__*/ FeatureEnabledException_base {
}
declare const InvalidAuthenticationCodeException_base: S.Class<InvalidAuthenticationCodeException, S.TaggedStruct<"InvalidAuthenticationCodeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InvalidAuthenticationCodeException extends /*@__PURE__*/ InvalidAuthenticationCodeException_base {
}
declare const InvalidCertificateException_base: S.Class<InvalidCertificateException, S.TaggedStruct<"InvalidCertificateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCertificateException extends /*@__PURE__*/ InvalidCertificateException_base {
}
declare const InvalidInput_base: S.Class<InvalidInput, S.TaggedStruct<"InvalidInput", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidInput extends /*@__PURE__*/ InvalidInput_base {
}
declare const InvalidInputException_base: S.Class<InvalidInputException, S.TaggedStruct<"InvalidInputException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidPublicKeyException_base: S.Class<InvalidPublicKeyException, S.TaggedStruct<"InvalidPublicKeyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPublicKeyException extends /*@__PURE__*/ InvalidPublicKeyException_base {
}
declare const InvalidUserTypeException_base: S.Class<InvalidUserTypeException, S.TaggedStruct<"InvalidUserTypeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidUserTypeException extends /*@__PURE__*/ InvalidUserTypeException_base {
}
declare const KeyPairMismatchException_base: S.Class<KeyPairMismatchException, S.TaggedStruct<"KeyPairMismatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KeyPairMismatchException extends /*@__PURE__*/ KeyPairMismatchException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MalformedCertificateException_base: S.Class<MalformedCertificateException, S.TaggedStruct<"MalformedCertificateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MalformedCertificateException extends /*@__PURE__*/ MalformedCertificateException_base {
}
declare const MalformedPolicyDocumentException_base: S.Class<MalformedPolicyDocumentException, S.TaggedStruct<"MalformedPolicyDocumentException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MalformedPolicyDocumentException extends /*@__PURE__*/ MalformedPolicyDocumentException_base {
}
declare const NameConflictException_base: S.Class<NameConflictException, S.TaggedStruct<"NameConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class NameConflictException extends /*@__PURE__*/ NameConflictException_base {
}
declare const NoSuchEntityException_base: S.Class<NoSuchEntityException, S.TaggedStruct<"NoSuchEntityException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class NoSuchEntityException extends /*@__PURE__*/ NoSuchEntityException_base {
}
declare const OpenIdIdpCommunicationErrorException_base: S.Class<OpenIdIdpCommunicationErrorException, S.TaggedStruct<"OpenIdIdpCommunicationErrorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OpenIdIdpCommunicationErrorException extends /*@__PURE__*/ OpenIdIdpCommunicationErrorException_base {
}
declare const OrganizationNotFoundException_base: S.Class<OrganizationNotFoundException, S.TaggedStruct<"OrganizationNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OrganizationNotFoundException extends /*@__PURE__*/ OrganizationNotFoundException_base {
}
declare const OrganizationNotInAllFeaturesModeException_base: S.Class<OrganizationNotInAllFeaturesModeException, S.TaggedStruct<"OrganizationNotInAllFeaturesModeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OrganizationNotInAllFeaturesModeException extends /*@__PURE__*/ OrganizationNotInAllFeaturesModeException_base {
}
declare const PasswordPolicyViolationException_base: S.Class<PasswordPolicyViolationException, S.TaggedStruct<"PasswordPolicyViolationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PasswordPolicyViolationException extends /*@__PURE__*/ PasswordPolicyViolationException_base {
}
declare const PolicyEvaluationException_base: S.Class<PolicyEvaluationException, S.TaggedStruct<"PolicyEvaluationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class PolicyEvaluationException extends /*@__PURE__*/ PolicyEvaluationException_base {
}
declare const PolicyNotAttachableException_base: S.Class<PolicyNotAttachableException, S.TaggedStruct<"PolicyNotAttachableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PolicyNotAttachableException extends /*@__PURE__*/ PolicyNotAttachableException_base {
}
declare const ReportGenerationLimitExceededException_base: S.Class<ReportGenerationLimitExceededException, S.TaggedStruct<"ReportGenerationLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ReportGenerationLimitExceededException extends /*@__PURE__*/ ReportGenerationLimitExceededException_base {
}
declare const RequestLimitExceeded_base: S.Class<RequestLimitExceeded, S.TaggedStruct<"RequestLimitExceeded", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RequestLimitExceeded extends /*@__PURE__*/ RequestLimitExceeded_base {
}
declare const RoleModifiedException_base: S.Class<RoleModifiedException, S.TaggedStruct<"RoleModifiedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class RoleModifiedException extends /*@__PURE__*/ RoleModifiedException_base {
}
declare const RoleTemplateDisabledException_base: S.Class<RoleTemplateDisabledException, S.TaggedStruct<"RoleTemplateDisabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RoleTemplateDisabledException extends /*@__PURE__*/ RoleTemplateDisabledException_base {
}
declare const ServiceAccessNotEnabledException_base: S.Class<ServiceAccessNotEnabledException, S.TaggedStruct<"ServiceAccessNotEnabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceAccessNotEnabledException extends /*@__PURE__*/ ServiceAccessNotEnabledException_base {
}
declare const ServiceFailureException_base: S.Class<ServiceFailureException, S.TaggedStruct<"ServiceFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceFailureException extends /*@__PURE__*/ ServiceFailureException_base {
}
declare const ServiceNotSupportedException_base: S.Class<ServiceNotSupportedException, S.TaggedStruct<"ServiceNotSupportedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceNotSupportedException extends /*@__PURE__*/ ServiceNotSupportedException_base {
}
declare const UnmodifiableEntityException_base: S.Class<UnmodifiableEntityException, S.TaggedStruct<"UnmodifiableEntityException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnmodifiableEntityException extends /*@__PURE__*/ UnmodifiableEntityException_base {
}
declare const UnrecognizedPublicKeyEncodingException_base: S.Class<UnrecognizedPublicKeyEncodingException, S.TaggedStruct<"UnrecognizedPublicKeyEncodingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnrecognizedPublicKeyEncodingException extends /*@__PURE__*/ UnrecognizedPublicKeyEncodingException_base {
}
export type DelegationRequestIdType = string;
export interface AcceptDelegationRequestRequest {
    DelegationRequestId: string;
}
export declare const AcceptDelegationRequestRequest: S.Schema<AcceptDelegationRequestRequest>;
export interface AcceptDelegationRequestResponse {
}
export declare const AcceptDelegationRequestResponse: S.Schema<AcceptDelegationRequestResponse>;
export type ArnType = string;
export type IntegerType = number;
export type StringType = string;
export type ReplacementValueListType = string[];
export declare const ReplacementValueListType: any;
export interface ReplacementValueEntry {
    Values: string[];
}
export declare const ReplacementValueEntry: S.Schema<ReplacementValueEntry>;
export type MapStringReplacementValueEntry = {
    [key: string]: ReplacementValueEntry | undefined;
};
export declare const MapStringReplacementValueEntry: any;
export interface AcquireRoleRequest {
    TemplateArn: string;
    TemplateMinorVersion?: number;
    ReplacementValues?: {
        [key: string]: ReplacementValueEntry | undefined;
    };
}
export declare const AcquireRoleRequest: S.Schema<AcquireRoleRequest>;
export type PathType = string;
export type RoleNameType = string;
export type IdType = string;
export type PolicyDocumentType = string;
export type RoleDescriptionType = string;
export type RoleMaxSessionDurationType = number;
export type PermissionsBoundaryAttachmentType = "PermissionsBoundaryPolicy" | (string & {});
export declare const PermissionsBoundaryAttachmentType: any;
export interface AttachedPermissionsBoundary {
    PermissionsBoundaryType?: PermissionsBoundaryAttachmentType;
    PermissionsBoundaryArn?: string;
}
export declare const AttachedPermissionsBoundary: S.Schema<AttachedPermissionsBoundary>;
export type TagKeyType = string;
export type TagValueType = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagListType = Tag[];
export declare const TagListType: any;
export interface RoleLastUsed {
    LastUsedDate?: Date;
    Region?: string;
}
export declare const RoleLastUsed: S.Schema<RoleLastUsed>;
export interface SourceRoleTemplate {
    TemplateArn: string;
    TemplateMinorVersion: number;
}
export declare const SourceRoleTemplate: S.Schema<SourceRoleTemplate>;
export interface Role {
    Path: string;
    RoleName: string;
    RoleId: string;
    Arn: string;
    CreateDate: Date;
    AssumeRolePolicyDocument?: string;
    Description?: string;
    MaxSessionDuration?: number;
    PermissionsBoundary?: AttachedPermissionsBoundary;
    Tags?: Tag[];
    RoleLastUsed?: RoleLastUsed;
    SourceRoleTemplate?: SourceRoleTemplate;
}
export declare const Role: S.Schema<Role>;
export interface AcquireRoleResponse {
    Role: Role;
}
export declare const AcquireRoleResponse: S.Schema<AcquireRoleResponse>;
export type ClientIDType = string;
export interface AddClientIDToOpenIDConnectProviderRequest {
    OpenIDConnectProviderArn: string;
    ClientID: string;
}
export declare const AddClientIDToOpenIDConnectProviderRequest: S.Schema<AddClientIDToOpenIDConnectProviderRequest>;
export interface AddClientIDToOpenIDConnectProviderResponse {
}
export declare const AddClientIDToOpenIDConnectProviderResponse: S.Schema<AddClientIDToOpenIDConnectProviderResponse>;
export type InstanceProfileNameType = string;
export interface AddRoleToInstanceProfileRequest {
    InstanceProfileName: string;
    RoleName: string;
}
export declare const AddRoleToInstanceProfileRequest: S.Schema<AddRoleToInstanceProfileRequest>;
export interface AddRoleToInstanceProfileResponse {
}
export declare const AddRoleToInstanceProfileResponse: S.Schema<AddRoleToInstanceProfileResponse>;
export type GroupNameType = string;
export type ExistingUserNameType = string;
export interface AddUserToGroupRequest {
    GroupName: string;
    UserName: string;
}
export declare const AddUserToGroupRequest: S.Schema<AddUserToGroupRequest>;
export interface AddUserToGroupResponse {
}
export declare const AddUserToGroupResponse: S.Schema<AddUserToGroupResponse>;
export interface AssociateDelegationRequestRequest {
    DelegationRequestId: string;
}
export declare const AssociateDelegationRequestRequest: S.Schema<AssociateDelegationRequestRequest>;
export interface AssociateDelegationRequestResponse {
}
export declare const AssociateDelegationRequestResponse: S.Schema<AssociateDelegationRequestResponse>;
export interface AttachGroupPolicyRequest {
    GroupName: string;
    PolicyArn: string;
}
export declare const AttachGroupPolicyRequest: S.Schema<AttachGroupPolicyRequest>;
export interface AttachGroupPolicyResponse {
}
export declare const AttachGroupPolicyResponse: S.Schema<AttachGroupPolicyResponse>;
export interface AttachRolePolicyRequest {
    RoleName: string;
    PolicyArn: string;
}
export declare const AttachRolePolicyRequest: S.Schema<AttachRolePolicyRequest>;
export interface AttachRolePolicyResponse {
}
export declare const AttachRolePolicyResponse: S.Schema<AttachRolePolicyResponse>;
export type UserNameType = string;
export interface AttachUserPolicyRequest {
    UserName: string;
    PolicyArn: string;
}
export declare const AttachUserPolicyRequest: S.Schema<AttachUserPolicyRequest>;
export interface AttachUserPolicyResponse {
}
export declare const AttachUserPolicyResponse: S.Schema<AttachUserPolicyResponse>;
export type PasswordType = string | redacted.Redacted<string>;
export interface ChangePasswordRequest {
    OldPassword: string | redacted.Redacted<string>;
    NewPassword: string | redacted.Redacted<string>;
}
export declare const ChangePasswordRequest: S.Schema<ChangePasswordRequest>;
export interface ChangePasswordResponse {
}
export declare const ChangePasswordResponse: S.Schema<ChangePasswordResponse>;
export interface CreateAccessKeyRequest {
    UserName?: string;
}
export declare const CreateAccessKeyRequest: S.Schema<CreateAccessKeyRequest>;
export type AccessKeyIdType = string;
export type StatusType = "Active" | "Inactive" | "Expired" | (string & {});
export declare const StatusType: any;
export type AccessKeySecretType = string | redacted.Redacted<string>;
export interface AccessKey {
    UserName: string;
    AccessKeyId: string;
    Status: StatusType;
    SecretAccessKey: string | redacted.Redacted<string>;
    CreateDate?: Date;
}
export declare const AccessKey: S.Schema<AccessKey>;
export interface CreateAccessKeyResponse {
    AccessKey: AccessKey;
}
export declare const CreateAccessKeyResponse: S.Schema<CreateAccessKeyResponse>;
export type AccountAliasType = string;
export interface CreateAccountAliasRequest {
    AccountAlias: string;
}
export declare const CreateAccountAliasRequest: S.Schema<CreateAccountAliasRequest>;
export interface CreateAccountAliasResponse {
}
export declare const CreateAccountAliasResponse: S.Schema<CreateAccountAliasResponse>;
export type AccountIdType = string;
export type DelegationRequestDescriptionType = string;
export type PolicyParameterNameType = string;
export type PolicyParameterValueType = string;
export type PolicyParameterValuesListType = string[];
export declare const PolicyParameterValuesListType: any;
export type PolicyParameterTypeEnum = "string" | "stringList" | (string & {});
export declare const PolicyParameterTypeEnum: any;
export interface PolicyParameter {
    Name?: string;
    Values?: string[];
    Type?: PolicyParameterTypeEnum;
}
export declare const PolicyParameter: S.Schema<PolicyParameter>;
export type PolicyParameterListType = PolicyParameter[];
export declare const PolicyParameterListType: any;
export interface DelegationPermission {
    PolicyTemplateArn?: string;
    Parameters?: PolicyParameter[];
}
export declare const DelegationPermission: S.Schema<DelegationPermission>;
export type RequestMessageType = string;
export type RequestorWorkflowIdType = string;
export type RedirectUrlType = string;
export type NotificationChannelType = string;
export type SessionDurationType = number;
export interface CreateDelegationRequestRequest {
    OwnerAccountId?: string;
    Description: string;
    Permissions: DelegationPermission;
    RequestMessage?: string;
    RequestorWorkflowId: string;
    RedirectUrl?: string;
    NotificationChannel: string;
    SessionDuration: number;
    OnlySendByOwner?: boolean;
}
export declare const CreateDelegationRequestRequest: S.Schema<CreateDelegationRequestRequest>;
export type ConsoleDeepLinkType = string;
export interface CreateDelegationRequestResponse {
    ConsoleDeepLink?: string;
    DelegationRequestId?: string;
}
export declare const CreateDelegationRequestResponse: S.Schema<CreateDelegationRequestResponse>;
export interface CreateGroupRequest {
    Path?: string;
    GroupName: string;
}
export declare const CreateGroupRequest: S.Schema<CreateGroupRequest>;
export interface Group {
    Path: string;
    GroupName: string;
    GroupId: string;
    Arn: string;
    CreateDate: Date;
}
export declare const Group: S.Schema<Group>;
export interface CreateGroupResponse {
    Group: Group;
}
export declare const CreateGroupResponse: S.Schema<CreateGroupResponse>;
export interface CreateInstanceProfileRequest {
    InstanceProfileName: string;
    Path?: string;
    Tags?: Tag[];
}
export declare const CreateInstanceProfileRequest: S.Schema<CreateInstanceProfileRequest>;
export type RoleListType = Role[];
export declare const RoleListType: any;
export interface InstanceProfile {
    Path: string;
    InstanceProfileName: string;
    InstanceProfileId: string;
    Arn: string;
    CreateDate: Date;
    Roles: Role[];
    Tags?: Tag[];
}
export declare const InstanceProfile: S.Schema<InstanceProfile>;
export interface CreateInstanceProfileResponse {
    InstanceProfile: InstanceProfile;
}
export declare const CreateInstanceProfileResponse: S.Schema<CreateInstanceProfileResponse>;
export interface CreateLoginProfileRequest {
    UserName?: string;
    Password?: string | redacted.Redacted<string>;
    PasswordResetRequired?: boolean;
}
export declare const CreateLoginProfileRequest: S.Schema<CreateLoginProfileRequest>;
export interface LoginProfile {
    UserName: string;
    CreateDate: Date;
    PasswordResetRequired?: boolean;
}
export declare const LoginProfile: S.Schema<LoginProfile>;
export interface CreateLoginProfileResponse {
    LoginProfile: LoginProfile;
}
export declare const CreateLoginProfileResponse: S.Schema<CreateLoginProfileResponse>;
export type OpenIDConnectProviderUrlType = string;
export type ClientIDListType = string[];
export declare const ClientIDListType: any;
export type ThumbprintType = string;
export type ThumbprintListType = string[];
export declare const ThumbprintListType: any;
export interface CreateOpenIDConnectProviderRequest {
    Url: string;
    ClientIDList?: string[];
    ThumbprintList?: string[];
    Tags?: Tag[];
}
export declare const CreateOpenIDConnectProviderRequest: S.Schema<CreateOpenIDConnectProviderRequest>;
export interface CreateOpenIDConnectProviderResponse {
    OpenIDConnectProviderArn?: string;
    Tags?: Tag[];
}
export declare const CreateOpenIDConnectProviderResponse: S.Schema<CreateOpenIDConnectProviderResponse>;
export type PolicyNameType = string;
export type PolicyPathType = string;
export type PolicyDescriptionType = string;
export interface CreatePolicyRequest {
    PolicyName: string;
    Path?: string;
    PolicyDocument: string;
    Description?: string;
    Tags?: Tag[];
}
export declare const CreatePolicyRequest: S.Schema<CreatePolicyRequest>;
export type PolicyVersionIdType = string;
export type AttachmentCountType = number;
export interface Policy {
    PolicyName?: string;
    PolicyId?: string;
    Arn?: string;
    Path?: string;
    DefaultVersionId?: string;
    AttachmentCount?: number;
    PermissionsBoundaryUsageCount?: number;
    IsAttachable?: boolean;
    Description?: string;
    CreateDate?: Date;
    UpdateDate?: Date;
    Tags?: Tag[];
}
export declare const Policy: S.Schema<Policy>;
export interface CreatePolicyResponse {
    Policy?: Policy;
}
export declare const CreatePolicyResponse: S.Schema<CreatePolicyResponse>;
export interface CreatePolicyVersionRequest {
    PolicyArn: string;
    PolicyDocument: string;
    SetAsDefault?: boolean;
}
export declare const CreatePolicyVersionRequest: S.Schema<CreatePolicyVersionRequest>;
export interface PolicyVersion {
    Document?: string;
    VersionId?: string;
    IsDefaultVersion?: boolean;
    CreateDate?: Date;
}
export declare const PolicyVersion: S.Schema<PolicyVersion>;
export interface CreatePolicyVersionResponse {
    PolicyVersion?: PolicyVersion;
}
export declare const CreatePolicyVersionResponse: S.Schema<CreatePolicyVersionResponse>;
export interface CreateRoleRequest {
    Path?: string;
    RoleName: string;
    AssumeRolePolicyDocument: string;
    Description?: string;
    MaxSessionDuration?: number;
    PermissionsBoundary?: string;
    Tags?: Tag[];
}
export declare const CreateRoleRequest: S.Schema<CreateRoleRequest>;
export interface CreateRoleResponse {
    Role: Role;
}
export declare const CreateRoleResponse: S.Schema<CreateRoleResponse>;
export type SAMLMetadataDocumentType = string;
export type SAMLProviderNameType = string;
export type AssertionEncryptionModeType = "Required" | "Allowed" | (string & {});
export declare const AssertionEncryptionModeType: any;
export type PrivateKeyType = string | redacted.Redacted<string>;
export interface CreateSAMLProviderRequest {
    SAMLMetadataDocument: string;
    Name: string;
    Tags?: Tag[];
    AssertionEncryptionMode?: AssertionEncryptionModeType;
    AddPrivateKey?: string | redacted.Redacted<string>;
}
export declare const CreateSAMLProviderRequest: S.Schema<CreateSAMLProviderRequest>;
export interface CreateSAMLProviderResponse {
    SAMLProviderArn?: string;
    Tags?: Tag[];
}
export declare const CreateSAMLProviderResponse: S.Schema<CreateSAMLProviderResponse>;
export type CustomSuffixType = string;
export interface CreateServiceLinkedRoleRequest {
    AWSServiceName: string;
    Description?: string;
    CustomSuffix?: string;
}
export declare const CreateServiceLinkedRoleRequest: S.Schema<CreateServiceLinkedRoleRequest>;
export interface CreateServiceLinkedRoleResponse {
    Role?: Role;
}
export declare const CreateServiceLinkedRoleResponse: S.Schema<CreateServiceLinkedRoleResponse>;
export type ServiceName = string;
export type CredentialAgeDays = number;
export interface CreateServiceSpecificCredentialRequest {
    UserName: string;
    ServiceName: string;
    CredentialAgeDays?: number;
}
export declare const CreateServiceSpecificCredentialRequest: S.Schema<CreateServiceSpecificCredentialRequest>;
export type ServiceUserName = string;
export type ServicePassword = string | redacted.Redacted<string>;
export type ServiceCredentialAlias = string;
export type ServiceCredentialSecret = string | redacted.Redacted<string>;
export type ServiceSpecificCredentialId = string;
export interface ServiceSpecificCredential {
    CreateDate: Date;
    ExpirationDate?: Date;
    ServiceName: string;
    ServiceUserName?: string;
    ServicePassword?: string | redacted.Redacted<string>;
    ServiceCredentialAlias?: string;
    ServiceCredentialSecret?: string | redacted.Redacted<string>;
    ServiceSpecificCredentialId: string;
    UserName: string;
    Status: StatusType;
}
export declare const ServiceSpecificCredential: S.Schema<ServiceSpecificCredential>;
export interface CreateServiceSpecificCredentialResponse {
    ServiceSpecificCredential?: ServiceSpecificCredential;
}
export declare const CreateServiceSpecificCredentialResponse: S.Schema<CreateServiceSpecificCredentialResponse>;
export interface CreateUserRequest {
    Path?: string;
    UserName: string;
    PermissionsBoundary?: string;
    Tags?: Tag[];
}
export declare const CreateUserRequest: S.Schema<CreateUserRequest>;
export interface User {
    Path: string;
    UserName: string;
    UserId: string;
    Arn: string;
    CreateDate: Date;
    PasswordLastUsed?: Date;
    PermissionsBoundary?: AttachedPermissionsBoundary;
    Tags?: Tag[];
}
export declare const User: S.Schema<User>;
export interface CreateUserResponse {
    User?: User;
}
export declare const CreateUserResponse: S.Schema<CreateUserResponse>;
export type VirtualMFADeviceName = string;
export interface CreateVirtualMFADeviceRequest {
    Path?: string;
    VirtualMFADeviceName: string;
    Tags?: Tag[];
}
export declare const CreateVirtualMFADeviceRequest: S.Schema<CreateVirtualMFADeviceRequest>;
export type SerialNumberType = string;
export type BootstrapDatum = Uint8Array | redacted.Redacted<Uint8Array>;
export interface VirtualMFADevice {
    SerialNumber: string;
    Base32StringSeed?: Uint8Array | redacted.Redacted<Uint8Array>;
    QRCodePNG?: Uint8Array | redacted.Redacted<Uint8Array>;
    User?: User;
    EnableDate?: Date;
    Tags?: Tag[];
}
export declare const VirtualMFADevice: S.Schema<VirtualMFADevice>;
export interface CreateVirtualMFADeviceResponse {
    VirtualMFADevice: VirtualMFADevice;
}
export declare const CreateVirtualMFADeviceResponse: S.Schema<CreateVirtualMFADeviceResponse>;
export interface DeactivateMFADeviceRequest {
    UserName?: string;
    SerialNumber: string;
}
export declare const DeactivateMFADeviceRequest: S.Schema<DeactivateMFADeviceRequest>;
export interface DeactivateMFADeviceResponse {
}
export declare const DeactivateMFADeviceResponse: S.Schema<DeactivateMFADeviceResponse>;
export interface DeleteAccessKeyRequest {
    UserName?: string;
    AccessKeyId: string;
}
export declare const DeleteAccessKeyRequest: S.Schema<DeleteAccessKeyRequest>;
export interface DeleteAccessKeyResponse {
}
export declare const DeleteAccessKeyResponse: S.Schema<DeleteAccessKeyResponse>;
export interface DeleteAccountAliasRequest {
    AccountAlias: string;
}
export declare const DeleteAccountAliasRequest: S.Schema<DeleteAccountAliasRequest>;
export interface DeleteAccountAliasResponse {
}
export declare const DeleteAccountAliasResponse: S.Schema<DeleteAccountAliasResponse>;
export interface DeleteAccountPasswordPolicyRequest {
}
export declare const DeleteAccountPasswordPolicyRequest: S.Schema<DeleteAccountPasswordPolicyRequest>;
export interface DeleteAccountPasswordPolicyResponse {
}
export declare const DeleteAccountPasswordPolicyResponse: S.Schema<DeleteAccountPasswordPolicyResponse>;
export interface DeleteGroupRequest {
    GroupName: string;
}
export declare const DeleteGroupRequest: S.Schema<DeleteGroupRequest>;
export interface DeleteGroupResponse {
}
export declare const DeleteGroupResponse: S.Schema<DeleteGroupResponse>;
export interface DeleteGroupPolicyRequest {
    GroupName: string;
    PolicyName: string;
}
export declare const DeleteGroupPolicyRequest: S.Schema<DeleteGroupPolicyRequest>;
export interface DeleteGroupPolicyResponse {
}
export declare const DeleteGroupPolicyResponse: S.Schema<DeleteGroupPolicyResponse>;
export interface DeleteInstanceProfileRequest {
    InstanceProfileName: string;
}
export declare const DeleteInstanceProfileRequest: S.Schema<DeleteInstanceProfileRequest>;
export interface DeleteInstanceProfileResponse {
}
export declare const DeleteInstanceProfileResponse: S.Schema<DeleteInstanceProfileResponse>;
export interface DeleteLoginProfileRequest {
    UserName?: string;
}
export declare const DeleteLoginProfileRequest: S.Schema<DeleteLoginProfileRequest>;
export interface DeleteLoginProfileResponse {
}
export declare const DeleteLoginProfileResponse: S.Schema<DeleteLoginProfileResponse>;
export interface DeleteOpenIDConnectProviderRequest {
    OpenIDConnectProviderArn: string;
}
export declare const DeleteOpenIDConnectProviderRequest: S.Schema<DeleteOpenIDConnectProviderRequest>;
export interface DeleteOpenIDConnectProviderResponse {
}
export declare const DeleteOpenIDConnectProviderResponse: S.Schema<DeleteOpenIDConnectProviderResponse>;
export interface DeletePolicyRequest {
    PolicyArn: string;
}
export declare const DeletePolicyRequest: S.Schema<DeletePolicyRequest>;
export interface DeletePolicyResponse {
}
export declare const DeletePolicyResponse: S.Schema<DeletePolicyResponse>;
export interface DeletePolicyVersionRequest {
    PolicyArn: string;
    VersionId: string;
}
export declare const DeletePolicyVersionRequest: S.Schema<DeletePolicyVersionRequest>;
export interface DeletePolicyVersionResponse {
}
export declare const DeletePolicyVersionResponse: S.Schema<DeletePolicyVersionResponse>;
export interface DeleteRoleRequest {
    RoleName: string;
}
export declare const DeleteRoleRequest: S.Schema<DeleteRoleRequest>;
export interface DeleteRoleResponse {
}
export declare const DeleteRoleResponse: S.Schema<DeleteRoleResponse>;
export interface DeleteRolePermissionsBoundaryRequest {
    RoleName: string;
}
export declare const DeleteRolePermissionsBoundaryRequest: S.Schema<DeleteRolePermissionsBoundaryRequest>;
export interface DeleteRolePermissionsBoundaryResponse {
}
export declare const DeleteRolePermissionsBoundaryResponse: S.Schema<DeleteRolePermissionsBoundaryResponse>;
export interface DeleteRolePolicyRequest {
    RoleName: string;
    PolicyName: string;
}
export declare const DeleteRolePolicyRequest: S.Schema<DeleteRolePolicyRequest>;
export interface DeleteRolePolicyResponse {
}
export declare const DeleteRolePolicyResponse: S.Schema<DeleteRolePolicyResponse>;
export interface DeleteSAMLProviderRequest {
    SAMLProviderArn: string;
}
export declare const DeleteSAMLProviderRequest: S.Schema<DeleteSAMLProviderRequest>;
export interface DeleteSAMLProviderResponse {
}
export declare const DeleteSAMLProviderResponse: S.Schema<DeleteSAMLProviderResponse>;
export type ServerCertificateNameType = string;
export interface DeleteServerCertificateRequest {
    ServerCertificateName: string;
}
export declare const DeleteServerCertificateRequest: S.Schema<DeleteServerCertificateRequest>;
export interface DeleteServerCertificateResponse {
}
export declare const DeleteServerCertificateResponse: S.Schema<DeleteServerCertificateResponse>;
export interface DeleteServiceLinkedRoleRequest {
    RoleName: string;
}
export declare const DeleteServiceLinkedRoleRequest: S.Schema<DeleteServiceLinkedRoleRequest>;
export type DeletionTaskIdType = string;
export interface DeleteServiceLinkedRoleResponse {
    DeletionTaskId: string;
}
export declare const DeleteServiceLinkedRoleResponse: S.Schema<DeleteServiceLinkedRoleResponse>;
export interface DeleteServiceSpecificCredentialRequest {
    UserName?: string;
    ServiceSpecificCredentialId: string;
}
export declare const DeleteServiceSpecificCredentialRequest: S.Schema<DeleteServiceSpecificCredentialRequest>;
export interface DeleteServiceSpecificCredentialResponse {
}
export declare const DeleteServiceSpecificCredentialResponse: S.Schema<DeleteServiceSpecificCredentialResponse>;
export type CertificateIdType = string;
export interface DeleteSigningCertificateRequest {
    UserName?: string;
    CertificateId: string;
}
export declare const DeleteSigningCertificateRequest: S.Schema<DeleteSigningCertificateRequest>;
export interface DeleteSigningCertificateResponse {
}
export declare const DeleteSigningCertificateResponse: S.Schema<DeleteSigningCertificateResponse>;
export type PublicKeyIdType = string;
export interface DeleteSSHPublicKeyRequest {
    UserName: string;
    SSHPublicKeyId: string;
}
export declare const DeleteSSHPublicKeyRequest: S.Schema<DeleteSSHPublicKeyRequest>;
export interface DeleteSSHPublicKeyResponse {
}
export declare const DeleteSSHPublicKeyResponse: S.Schema<DeleteSSHPublicKeyResponse>;
export interface DeleteUserRequest {
    UserName: string;
}
export declare const DeleteUserRequest: S.Schema<DeleteUserRequest>;
export interface DeleteUserResponse {
}
export declare const DeleteUserResponse: S.Schema<DeleteUserResponse>;
export interface DeleteUserPermissionsBoundaryRequest {
    UserName: string;
}
export declare const DeleteUserPermissionsBoundaryRequest: S.Schema<DeleteUserPermissionsBoundaryRequest>;
export interface DeleteUserPermissionsBoundaryResponse {
}
export declare const DeleteUserPermissionsBoundaryResponse: S.Schema<DeleteUserPermissionsBoundaryResponse>;
export interface DeleteUserPolicyRequest {
    UserName: string;
    PolicyName: string;
}
export declare const DeleteUserPolicyRequest: S.Schema<DeleteUserPolicyRequest>;
export interface DeleteUserPolicyResponse {
}
export declare const DeleteUserPolicyResponse: S.Schema<DeleteUserPolicyResponse>;
export interface DeleteVirtualMFADeviceRequest {
    SerialNumber: string;
}
export declare const DeleteVirtualMFADeviceRequest: S.Schema<DeleteVirtualMFADeviceRequest>;
export interface DeleteVirtualMFADeviceResponse {
}
export declare const DeleteVirtualMFADeviceResponse: S.Schema<DeleteVirtualMFADeviceResponse>;
export interface DetachGroupPolicyRequest {
    GroupName: string;
    PolicyArn: string;
}
export declare const DetachGroupPolicyRequest: S.Schema<DetachGroupPolicyRequest>;
export interface DetachGroupPolicyResponse {
}
export declare const DetachGroupPolicyResponse: S.Schema<DetachGroupPolicyResponse>;
export interface DetachRolePolicyRequest {
    RoleName: string;
    PolicyArn: string;
}
export declare const DetachRolePolicyRequest: S.Schema<DetachRolePolicyRequest>;
export interface DetachRolePolicyResponse {
}
export declare const DetachRolePolicyResponse: S.Schema<DetachRolePolicyResponse>;
export interface DetachUserPolicyRequest {
    UserName: string;
    PolicyArn: string;
}
export declare const DetachUserPolicyRequest: S.Schema<DetachUserPolicyRequest>;
export interface DetachUserPolicyResponse {
}
export declare const DetachUserPolicyResponse: S.Schema<DetachUserPolicyResponse>;
export interface DisableOrganizationsRootCredentialsManagementRequest {
}
export declare const DisableOrganizationsRootCredentialsManagementRequest: S.Schema<DisableOrganizationsRootCredentialsManagementRequest>;
export type OrganizationIdType = string;
export type FeatureType = "RootCredentialsManagement" | "RootSessions" | (string & {});
export declare const FeatureType: any;
export type FeaturesListType = FeatureType[];
export declare const FeaturesListType: any;
export interface DisableOrganizationsRootCredentialsManagementResponse {
    OrganizationId?: string;
    EnabledFeatures?: FeatureType[];
}
export declare const DisableOrganizationsRootCredentialsManagementResponse: S.Schema<DisableOrganizationsRootCredentialsManagementResponse>;
export interface DisableOrganizationsRootSessionsRequest {
}
export declare const DisableOrganizationsRootSessionsRequest: S.Schema<DisableOrganizationsRootSessionsRequest>;
export interface DisableOrganizationsRootSessionsResponse {
    OrganizationId?: string;
    EnabledFeatures?: FeatureType[];
}
export declare const DisableOrganizationsRootSessionsResponse: S.Schema<DisableOrganizationsRootSessionsResponse>;
export interface DisableOutboundWebIdentityFederationRequest {
}
export declare const DisableOutboundWebIdentityFederationRequest: S.Schema<DisableOutboundWebIdentityFederationRequest>;
export interface DisableOutboundWebIdentityFederationResponse {
}
export declare const DisableOutboundWebIdentityFederationResponse: S.Schema<DisableOutboundWebIdentityFederationResponse>;
export type AuthenticationCodeType = string;
export interface EnableMFADeviceRequest {
    UserName: string;
    SerialNumber: string;
    AuthenticationCode1: string;
    AuthenticationCode2: string;
}
export declare const EnableMFADeviceRequest: S.Schema<EnableMFADeviceRequest>;
export interface EnableMFADeviceResponse {
}
export declare const EnableMFADeviceResponse: S.Schema<EnableMFADeviceResponse>;
export interface EnableOrganizationsRootCredentialsManagementRequest {
}
export declare const EnableOrganizationsRootCredentialsManagementRequest: S.Schema<EnableOrganizationsRootCredentialsManagementRequest>;
export interface EnableOrganizationsRootCredentialsManagementResponse {
    OrganizationId?: string;
    EnabledFeatures?: FeatureType[];
}
export declare const EnableOrganizationsRootCredentialsManagementResponse: S.Schema<EnableOrganizationsRootCredentialsManagementResponse>;
export interface EnableOrganizationsRootSessionsRequest {
}
export declare const EnableOrganizationsRootSessionsRequest: S.Schema<EnableOrganizationsRootSessionsRequest>;
export interface EnableOrganizationsRootSessionsResponse {
    OrganizationId?: string;
    EnabledFeatures?: FeatureType[];
}
export declare const EnableOrganizationsRootSessionsResponse: S.Schema<EnableOrganizationsRootSessionsResponse>;
export interface EnableOutboundWebIdentityFederationRequest {
}
export declare const EnableOutboundWebIdentityFederationRequest: S.Schema<EnableOutboundWebIdentityFederationRequest>;
export interface EnableOutboundWebIdentityFederationResponse {
    IssuerIdentifier?: string;
}
export declare const EnableOutboundWebIdentityFederationResponse: S.Schema<EnableOutboundWebIdentityFederationResponse>;
export interface GenerateCredentialReportRequest {
}
export declare const GenerateCredentialReportRequest: S.Schema<GenerateCredentialReportRequest>;
export type ReportStateType = "STARTED" | "INPROGRESS" | "COMPLETE" | (string & {});
export declare const ReportStateType: any;
export type ReportStateDescriptionType = string;
export interface GenerateCredentialReportResponse {
    State?: ReportStateType;
    Description?: string;
}
export declare const GenerateCredentialReportResponse: S.Schema<GenerateCredentialReportResponse>;
export type OrganizationsEntityPathType = string;
export type OrganizationsPolicyIdType = string;
export interface GenerateOrganizationsAccessReportRequest {
    EntityPath: string;
    OrganizationsPolicyId?: string;
}
export declare const GenerateOrganizationsAccessReportRequest: S.Schema<GenerateOrganizationsAccessReportRequest>;
export type JobIDType = string;
export interface GenerateOrganizationsAccessReportResponse {
    JobId?: string;
}
export declare const GenerateOrganizationsAccessReportResponse: S.Schema<GenerateOrganizationsAccessReportResponse>;
export type AccessAdvisorUsageGranularityType = "SERVICE_LEVEL" | "ACTION_LEVEL" | (string & {});
export declare const AccessAdvisorUsageGranularityType: any;
export interface GenerateServiceLastAccessedDetailsRequest {
    Arn: string;
    Granularity?: AccessAdvisorUsageGranularityType;
}
export declare const GenerateServiceLastAccessedDetailsRequest: S.Schema<GenerateServiceLastAccessedDetailsRequest>;
export interface GenerateServiceLastAccessedDetailsResponse {
    JobId?: string;
}
export declare const GenerateServiceLastAccessedDetailsResponse: S.Schema<GenerateServiceLastAccessedDetailsResponse>;
export interface GetAccessKeyLastUsedRequest {
    AccessKeyId: string;
}
export declare const GetAccessKeyLastUsedRequest: S.Schema<GetAccessKeyLastUsedRequest>;
export interface AccessKeyLastUsed {
    LastUsedDate?: Date;
    ServiceName: string;
    Region: string;
}
export declare const AccessKeyLastUsed: S.Schema<AccessKeyLastUsed>;
export interface GetAccessKeyLastUsedResponse {
    UserName?: string;
    AccessKeyLastUsed?: AccessKeyLastUsed;
}
export declare const GetAccessKeyLastUsedResponse: S.Schema<GetAccessKeyLastUsedResponse>;
export type EntityType = "User" | "Role" | "Group" | "LocalManagedPolicy" | "AWSManagedPolicy" | (string & {});
export declare const EntityType: any;
export type EntityListType = EntityType[];
export declare const EntityListType: any;
export type MaxItemsType = number;
export type MarkerType = string;
export interface GetAccountAuthorizationDetailsRequest {
    Filter?: EntityType[];
    MaxItems?: number;
    Marker?: string;
}
export declare const GetAccountAuthorizationDetailsRequest: S.Schema<GetAccountAuthorizationDetailsRequest>;
export interface PolicyDetail {
    PolicyName?: string;
    PolicyDocument?: string;
}
export declare const PolicyDetail: S.Schema<PolicyDetail>;
export type PolicyDetailListType = PolicyDetail[];
export declare const PolicyDetailListType: any;
export type GroupNameListType = string[];
export declare const GroupNameListType: any;
export interface AttachedPolicy {
    PolicyName?: string;
    PolicyArn?: string;
}
export declare const AttachedPolicy: S.Schema<AttachedPolicy>;
export type AttachedPoliciesListType = AttachedPolicy[];
export declare const AttachedPoliciesListType: any;
export interface UserDetail {
    Path?: string;
    UserName?: string;
    UserId?: string;
    Arn?: string;
    CreateDate?: Date;
    UserPolicyList?: PolicyDetail[];
    GroupList?: string[];
    AttachedManagedPolicies?: AttachedPolicy[];
    PermissionsBoundary?: AttachedPermissionsBoundary;
    Tags?: Tag[];
}
export declare const UserDetail: S.Schema<UserDetail>;
export type UserDetailListType = UserDetail[];
export declare const UserDetailListType: any;
export interface GroupDetail {
    Path?: string;
    GroupName?: string;
    GroupId?: string;
    Arn?: string;
    CreateDate?: Date;
    GroupPolicyList?: PolicyDetail[];
    AttachedManagedPolicies?: AttachedPolicy[];
}
export declare const GroupDetail: S.Schema<GroupDetail>;
export type GroupDetailListType = GroupDetail[];
export declare const GroupDetailListType: any;
export type InstanceProfileListType = InstanceProfile[];
export declare const InstanceProfileListType: any;
export interface RoleDetail {
    Path?: string;
    RoleName?: string;
    RoleId?: string;
    Arn?: string;
    CreateDate?: Date;
    AssumeRolePolicyDocument?: string;
    InstanceProfileList?: InstanceProfile[];
    RolePolicyList?: PolicyDetail[];
    AttachedManagedPolicies?: AttachedPolicy[];
    PermissionsBoundary?: AttachedPermissionsBoundary;
    Tags?: Tag[];
    RoleLastUsed?: RoleLastUsed;
}
export declare const RoleDetail: S.Schema<RoleDetail>;
export type RoleDetailListType = RoleDetail[];
export declare const RoleDetailListType: any;
export type PolicyDocumentVersionListType = PolicyVersion[];
export declare const PolicyDocumentVersionListType: any;
export interface ManagedPolicyDetail {
    PolicyName?: string;
    PolicyId?: string;
    Arn?: string;
    Path?: string;
    DefaultVersionId?: string;
    AttachmentCount?: number;
    PermissionsBoundaryUsageCount?: number;
    IsAttachable?: boolean;
    Description?: string;
    CreateDate?: Date;
    UpdateDate?: Date;
    PolicyVersionList?: PolicyVersion[];
}
export declare const ManagedPolicyDetail: S.Schema<ManagedPolicyDetail>;
export type ManagedPolicyDetailListType = ManagedPolicyDetail[];
export declare const ManagedPolicyDetailListType: any;
export type ResponseMarkerType = string;
export interface GetAccountAuthorizationDetailsResponse {
    UserDetailList?: UserDetail[];
    GroupDetailList?: GroupDetail[];
    RoleDetailList?: RoleDetail[];
    Policies?: ManagedPolicyDetail[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const GetAccountAuthorizationDetailsResponse: S.Schema<GetAccountAuthorizationDetailsResponse>;
export interface GetAccountPasswordPolicyRequest {
}
export declare const GetAccountPasswordPolicyRequest: S.Schema<GetAccountPasswordPolicyRequest>;
export type MinimumPasswordLengthType = number;
export type MaxPasswordAgeType = number;
export type PasswordReusePreventionType = number;
export type BooleanObjectType = boolean;
export interface PasswordPolicy {
    MinimumPasswordLength?: number;
    RequireSymbols?: boolean;
    RequireNumbers?: boolean;
    RequireUppercaseCharacters?: boolean;
    RequireLowercaseCharacters?: boolean;
    AllowUsersToChangePassword?: boolean;
    ExpirePasswords?: boolean;
    MaxPasswordAge?: number;
    PasswordReusePrevention?: number;
    HardExpiry?: boolean;
}
export declare const PasswordPolicy: S.Schema<PasswordPolicy>;
export interface GetAccountPasswordPolicyResponse {
    PasswordPolicy: PasswordPolicy;
}
export declare const GetAccountPasswordPolicyResponse: S.Schema<GetAccountPasswordPolicyResponse>;
export interface GetAccountPropertiesRequest {
}
export declare const GetAccountPropertiesRequest: S.Schema<GetAccountPropertiesRequest>;
export type AccountPropertyKeyType = string;
export type AccountPropertyValueType = string;
export type AccountPropertiesMapType = {
    [key: string]: string | undefined;
};
export declare const AccountPropertiesMapType: any;
export interface GetAccountPropertiesResponse {
    Properties?: {
        [key: string]: string | undefined;
    };
}
export declare const GetAccountPropertiesResponse: S.Schema<GetAccountPropertiesResponse>;
export interface GetAccountSummaryRequest {
}
export declare const GetAccountSummaryRequest: S.Schema<GetAccountSummaryRequest>;
export type SummaryKeyType = "Users" | "UsersQuota" | "Groups" | "GroupsQuota" | "ServerCertificates" | "ServerCertificatesQuota" | "UserPolicySizeQuota" | "GroupPolicySizeQuota" | "GroupsPerUserQuota" | "SigningCertificatesPerUserQuota" | "AccessKeysPerUserQuota" | "MFADevices" | "MFADevicesInUse" | "AccountMFAEnabled" | "AccountAccessKeysPresent" | "AccountPasswordPresent" | "AccountSigningCertificatesPresent" | "AttachedPoliciesPerGroupQuota" | "AttachedPoliciesPerRoleQuota" | "AttachedPoliciesPerUserQuota" | "Policies" | "PoliciesQuota" | "PolicySizeQuota" | "PolicyVersionsInUse" | "PolicyVersionsInUseQuota" | "VersionsPerPolicyQuota" | "GlobalEndpointTokenVersion" | "AssumeRolePolicySizeQuota" | "InstanceProfiles" | "InstanceProfilesQuota" | "Providers" | "RolePolicySizeQuota" | "Roles" | "RolesQuota" | (string & {});
export declare const SummaryKeyType: any;
export type SummaryValueType = number;
export type SummaryMapType = {
    [key in SummaryKeyType]?: number;
};
export declare const SummaryMapType: any;
export interface GetAccountSummaryResponse {
    SummaryMap?: {
        [key: string]: number | undefined;
    };
}
export declare const GetAccountSummaryResponse: S.Schema<GetAccountSummaryResponse>;
export type SimulationPolicyListType = string[];
export declare const SimulationPolicyListType: any;
export interface GetContextKeysForCustomPolicyRequest {
    PolicyInputList: string[];
}
export declare const GetContextKeysForCustomPolicyRequest: S.Schema<GetContextKeysForCustomPolicyRequest>;
export type ContextKeyNameType = string;
export type ContextKeyNamesResultListType = string[];
export declare const ContextKeyNamesResultListType: any;
export interface GetContextKeysForPolicyResponse {
    ContextKeyNames?: string[];
}
export declare const GetContextKeysForPolicyResponse: S.Schema<GetContextKeysForPolicyResponse>;
export interface GetContextKeysForPrincipalPolicyRequest {
    PolicySourceArn: string;
    PolicyInputList?: string[];
}
export declare const GetContextKeysForPrincipalPolicyRequest: S.Schema<GetContextKeysForPrincipalPolicyRequest>;
export interface GetCredentialReportRequest {
}
export declare const GetCredentialReportRequest: S.Schema<GetCredentialReportRequest>;
export type ReportContentType = Uint8Array;
export type ReportFormatType = "text/csv" | (string & {});
export declare const ReportFormatType: any;
export interface GetCredentialReportResponse {
    Content?: Uint8Array;
    ReportFormat?: ReportFormatType;
    GeneratedTime?: Date;
}
export declare const GetCredentialReportResponse: S.Schema<GetCredentialReportResponse>;
export interface GetDelegationRequestRequest {
    DelegationRequestId: string;
    DelegationPermissionCheck?: boolean;
}
export declare const GetDelegationRequestRequest: S.Schema<GetDelegationRequestRequest>;
export type PermissionType = string;
export type RolePermissionRestrictionArnListType = string[];
export declare const RolePermissionRestrictionArnListType: any;
export type OwnerIdType = string;
export type StateType = "UNASSIGNED" | "ASSIGNED" | "PENDING_APPROVAL" | "FINALIZED" | "ACCEPTED" | "REJECTED" | "EXPIRED" | (string & {});
export declare const StateType: any;
export type RequestorNameType = string;
export type NotesType = string;
export interface DelegationRequest {
    DelegationRequestId?: string;
    OwnerAccountId?: string;
    Description?: string;
    RequestMessage?: string;
    Permissions?: DelegationPermission;
    PermissionPolicy?: string;
    RolePermissionRestrictionArns?: string[];
    OwnerId?: string;
    ApproverId?: string;
    State?: StateType;
    ExpirationTime?: Date;
    RequestorId?: string;
    RequestorName?: string;
    CreateDate?: Date;
    SessionDuration?: number;
    RedirectUrl?: string;
    Notes?: string;
    RejectionReason?: string;
    OnlySendByOwner?: boolean;
    UpdatedTime?: Date;
}
export declare const DelegationRequest: S.Schema<DelegationRequest>;
export type PermissionCheckStatusType = "COMPLETE" | "IN_PROGRESS" | "FAILED" | (string & {});
export declare const PermissionCheckStatusType: any;
export type PermissionCheckResultType = "ALLOWED" | "DENIED" | "UNSURE" | (string & {});
export declare const PermissionCheckResultType: any;
export interface GetDelegationRequestResponse {
    DelegationRequest?: DelegationRequest;
    PermissionCheckStatus?: PermissionCheckStatusType;
    PermissionCheckResult?: PermissionCheckResultType;
}
export declare const GetDelegationRequestResponse: S.Schema<GetDelegationRequestResponse>;
export interface GetGroupRequest {
    GroupName: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const GetGroupRequest: S.Schema<GetGroupRequest>;
export type UserListType = User[];
export declare const UserListType: any;
export interface GetGroupResponse {
    Group: Group;
    Users: User[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const GetGroupResponse: S.Schema<GetGroupResponse>;
export interface GetGroupPolicyRequest {
    GroupName: string;
    PolicyName: string;
}
export declare const GetGroupPolicyRequest: S.Schema<GetGroupPolicyRequest>;
export interface GetGroupPolicyResponse {
    GroupName: string;
    PolicyName: string;
    PolicyDocument: string;
}
export declare const GetGroupPolicyResponse: S.Schema<GetGroupPolicyResponse>;
export type LocaleType = string;
export interface GetHumanReadableSummaryRequest {
    EntityArn: string;
    Locale?: string;
}
export declare const GetHumanReadableSummaryRequest: S.Schema<GetHumanReadableSummaryRequest>;
export type SummaryContentType = string;
export type SummaryStateType = "AVAILABLE" | "NOT_AVAILABLE" | "NOT_SUPPORTED" | "FAILED" | (string & {});
export declare const SummaryStateType: any;
export interface GetHumanReadableSummaryResponse {
    SummaryContent?: string;
    Locale?: string;
    SummaryState?: SummaryStateType;
}
export declare const GetHumanReadableSummaryResponse: S.Schema<GetHumanReadableSummaryResponse>;
export interface GetInstanceProfileRequest {
    InstanceProfileName: string;
}
export declare const GetInstanceProfileRequest: S.Schema<GetInstanceProfileRequest>;
export interface GetInstanceProfileResponse {
    InstanceProfile: InstanceProfile;
}
export declare const GetInstanceProfileResponse: S.Schema<GetInstanceProfileResponse>;
export interface GetLoginProfileRequest {
    UserName?: string;
}
export declare const GetLoginProfileRequest: S.Schema<GetLoginProfileRequest>;
export interface GetLoginProfileResponse {
    LoginProfile: LoginProfile;
}
export declare const GetLoginProfileResponse: S.Schema<GetLoginProfileResponse>;
export interface GetMFADeviceRequest {
    SerialNumber: string;
    UserName?: string;
}
export declare const GetMFADeviceRequest: S.Schema<GetMFADeviceRequest>;
export type CertificationKeyType = string;
export type CertificationValueType = string;
export type CertificationMapType = {
    [key: string]: string | undefined;
};
export declare const CertificationMapType: any;
export interface GetMFADeviceResponse {
    UserName?: string;
    SerialNumber: string;
    EnableDate?: Date;
    Certifications?: {
        [key: string]: string | undefined;
    };
}
export declare const GetMFADeviceResponse: S.Schema<GetMFADeviceResponse>;
export interface GetOpenIDConnectProviderRequest {
    OpenIDConnectProviderArn: string;
}
export declare const GetOpenIDConnectProviderRequest: S.Schema<GetOpenIDConnectProviderRequest>;
export interface GetOpenIDConnectProviderResponse {
    Url?: string;
    ClientIDList?: string[];
    ThumbprintList?: string[];
    CreateDate?: Date;
    Tags?: Tag[];
}
export declare const GetOpenIDConnectProviderResponse: S.Schema<GetOpenIDConnectProviderResponse>;
export type SortKeyType = "SERVICE_NAMESPACE_ASCENDING" | "SERVICE_NAMESPACE_DESCENDING" | "LAST_AUTHENTICATED_TIME_ASCENDING" | "LAST_AUTHENTICATED_TIME_DESCENDING" | (string & {});
export declare const SortKeyType: any;
export interface GetOrganizationsAccessReportRequest {
    JobId: string;
    MaxItems?: number;
    Marker?: string;
    SortKey?: SortKeyType;
}
export declare const GetOrganizationsAccessReportRequest: S.Schema<GetOrganizationsAccessReportRequest>;
export type JobStatusType = "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export declare const JobStatusType: any;
export type ServiceNameType = string;
export type ServiceNamespaceType = string;
export interface AccessDetail {
    ServiceName: string;
    ServiceNamespace: string;
    Region?: string;
    EntityPath?: string;
    LastAuthenticatedTime?: Date;
    TotalAuthenticatedEntities?: number;
}
export declare const AccessDetail: S.Schema<AccessDetail>;
export type AccessDetails = AccessDetail[];
export declare const AccessDetails: any;
export interface ErrorDetails {
    Message: string;
    Code: string;
}
export declare const ErrorDetails: S.Schema<ErrorDetails>;
export interface GetOrganizationsAccessReportResponse {
    JobStatus: JobStatusType;
    JobCreationDate: Date;
    JobCompletionDate?: Date;
    NumberOfServicesAccessible?: number;
    NumberOfServicesNotAccessed?: number;
    AccessDetails?: AccessDetail[];
    IsTruncated?: boolean;
    Marker?: string;
    ErrorDetails?: ErrorDetails;
}
export declare const GetOrganizationsAccessReportResponse: S.Schema<GetOrganizationsAccessReportResponse>;
export interface GetOutboundWebIdentityFederationInfoRequest {
}
export declare const GetOutboundWebIdentityFederationInfoRequest: S.Schema<GetOutboundWebIdentityFederationInfoRequest>;
export interface GetOutboundWebIdentityFederationInfoResponse {
    IssuerIdentifier?: string;
    JwtVendingEnabled?: boolean;
}
export declare const GetOutboundWebIdentityFederationInfoResponse: S.Schema<GetOutboundWebIdentityFederationInfoResponse>;
export interface GetPolicyRequest {
    PolicyArn: string;
}
export declare const GetPolicyRequest: S.Schema<GetPolicyRequest>;
export interface GetPolicyResponse {
    Policy?: Policy;
}
export declare const GetPolicyResponse: S.Schema<GetPolicyResponse>;
export interface GetPolicyVersionRequest {
    PolicyArn: string;
    VersionId: string;
}
export declare const GetPolicyVersionRequest: S.Schema<GetPolicyVersionRequest>;
export interface GetPolicyVersionResponse {
    PolicyVersion?: PolicyVersion;
}
export declare const GetPolicyVersionResponse: S.Schema<GetPolicyVersionResponse>;
export interface GetRoleRequest {
    RoleName: string;
}
export declare const GetRoleRequest: S.Schema<GetRoleRequest>;
export interface GetRoleResponse {
    Role: Role;
}
export declare const GetRoleResponse: S.Schema<GetRoleResponse>;
export interface GetRolePolicyRequest {
    RoleName: string;
    PolicyName: string;
}
export declare const GetRolePolicyRequest: S.Schema<GetRolePolicyRequest>;
export interface GetRolePolicyResponse {
    RoleName: string;
    PolicyName: string;
    PolicyDocument: string;
}
export declare const GetRolePolicyResponse: S.Schema<GetRolePolicyResponse>;
export type MinorVersionType = number;
export interface GetRoleTemplateVersionRequest {
    TemplateArn: string;
    MinorVersion?: number;
}
export declare const GetRoleTemplateVersionRequest: S.Schema<GetRoleTemplateVersionRequest>;
export type RoleTemplateNameType = string;
export type RoleTemplateDescriptionType = string;
export type ManagedByTypeType = "Service" | (string & {});
export declare const ManagedByTypeType: any;
export type ManagedByValueType = string;
export type RoleNamePatternType = string;
export type RolePathPatternType = string;
export type RoleDescriptionPatternType = string;
export interface InlinePolicy {
    PolicyName: string;
    PolicyDocument: string;
}
export declare const InlinePolicy: S.Schema<InlinePolicy>;
export type InlinePolicyTemplateListType = InlinePolicy[];
export declare const InlinePolicyTemplateListType: any;
export type ManagedPolicyArnListType = string[];
export declare const ManagedPolicyArnListType: any;
export type ParameterNameType = string;
export type ParameterTypeType = "String" | "StringList" | "Number" | "NumberList" | "Arn" | "ArnList" | (string & {});
export declare const ParameterTypeType: any;
export type ParameterSubTypeType = string;
export type ParameterDescriptionType = string;
export type ParameterDefaultValueType = string;
export interface ParameterDefinition {
    Name: string;
    Type: ParameterTypeType;
    SubType?: string;
    Description?: string;
    IsRequired?: boolean;
    DefaultValue?: string;
    Immutable?: boolean;
}
export declare const ParameterDefinition: S.Schema<ParameterDefinition>;
export type ParametersDefinitionListType = ParameterDefinition[];
export declare const ParametersDefinitionListType: any;
export type TagTemplateKeyType = string;
export type TagTemplateValueType = string;
export interface TagTemplate {
    Key: string;
    Value: string;
}
export declare const TagTemplate: S.Schema<TagTemplate>;
export type TagTemplateListType = TagTemplate[];
export declare const TagTemplateListType: any;
export interface RoleTemplateVersion {
    TemplateArn?: string;
    TemplateName?: string;
    TemplateVersionId?: string;
    Description?: string;
    MajorVersion?: number;
    DefaultMinorVersion?: number;
    ManagedByType?: ManagedByTypeType;
    ManagedByValue?: string;
    Enabled?: boolean;
    MinorVersion?: number;
    RoleNamePattern?: string;
    RolePathPattern?: string;
    RoleDescriptionPattern?: string;
    AssumeRolePolicyDocumentTemplate?: string;
    InlinePolicyTemplates?: InlinePolicy[];
    ManagedPolicyArns?: string[];
    PermissionBoundaryArn?: string;
    ParametersDefinition?: ParameterDefinition[];
    RoleTagsTemplate?: TagTemplate[];
    MaxSessionDuration?: number;
    VersionEnabled?: boolean;
    CreateTimestamp?: Date;
    UpdateTimestamp?: Date;
}
export declare const RoleTemplateVersion: S.Schema<RoleTemplateVersion>;
export interface GetRoleTemplateVersionResponse {
    RoleTemplateVersion: RoleTemplateVersion;
}
export declare const GetRoleTemplateVersionResponse: S.Schema<GetRoleTemplateVersionResponse>;
export interface GetSAMLProviderRequest {
    SAMLProviderArn: string;
}
export declare const GetSAMLProviderRequest: S.Schema<GetSAMLProviderRequest>;
export type PrivateKeyIdType = string;
export interface SAMLPrivateKey {
    KeyId?: string;
    Timestamp?: Date;
}
export declare const SAMLPrivateKey: S.Schema<SAMLPrivateKey>;
export type PrivateKeyList = SAMLPrivateKey[];
export declare const PrivateKeyList: any;
export interface GetSAMLProviderResponse {
    SAMLProviderUUID?: string;
    SAMLMetadataDocument?: string;
    CreateDate?: Date;
    ValidUntil?: Date;
    Tags?: Tag[];
    AssertionEncryptionMode?: AssertionEncryptionModeType;
    PrivateKeyList?: SAMLPrivateKey[];
}
export declare const GetSAMLProviderResponse: S.Schema<GetSAMLProviderResponse>;
export interface GetServerCertificateRequest {
    ServerCertificateName: string;
}
export declare const GetServerCertificateRequest: S.Schema<GetServerCertificateRequest>;
export interface ServerCertificateMetadata {
    Path: string;
    ServerCertificateName: string;
    ServerCertificateId: string;
    Arn: string;
    UploadDate?: Date;
    Expiration?: Date;
}
export declare const ServerCertificateMetadata: S.Schema<ServerCertificateMetadata>;
export type CertificateBodyType = string;
export type CertificateChainType = string;
export interface ServerCertificate {
    ServerCertificateMetadata: ServerCertificateMetadata;
    CertificateBody: string;
    CertificateChain?: string;
    Tags?: Tag[];
}
export declare const ServerCertificate: S.Schema<ServerCertificate>;
export interface GetServerCertificateResponse {
    ServerCertificate: ServerCertificate;
}
export declare const GetServerCertificateResponse: S.Schema<GetServerCertificateResponse>;
export interface GetServiceLastAccessedDetailsRequest {
    JobId: string;
    MaxItems?: number;
    Marker?: string;
}
export declare const GetServiceLastAccessedDetailsRequest: S.Schema<GetServiceLastAccessedDetailsRequest>;
export interface TrackedActionLastAccessed {
    ActionName?: string;
    LastAccessedEntity?: string;
    LastAccessedTime?: Date;
    LastAccessedRegion?: string;
}
export declare const TrackedActionLastAccessed: S.Schema<TrackedActionLastAccessed>;
export type TrackedActionsLastAccessed = TrackedActionLastAccessed[];
export declare const TrackedActionsLastAccessed: any;
export interface ServiceLastAccessed {
    ServiceName: string;
    LastAuthenticated?: Date;
    ServiceNamespace: string;
    LastAuthenticatedEntity?: string;
    LastAuthenticatedRegion?: string;
    TotalAuthenticatedEntities?: number;
    TrackedActionsLastAccessed?: TrackedActionLastAccessed[];
}
export declare const ServiceLastAccessed: S.Schema<ServiceLastAccessed>;
export type ServicesLastAccessed = ServiceLastAccessed[];
export declare const ServicesLastAccessed: any;
export interface GetServiceLastAccessedDetailsResponse {
    JobStatus: JobStatusType;
    JobType?: AccessAdvisorUsageGranularityType;
    JobCreationDate: Date;
    ServicesLastAccessed: ServiceLastAccessed[];
    JobCompletionDate: Date;
    IsTruncated?: boolean;
    Marker?: string;
    Error?: ErrorDetails;
}
export declare const GetServiceLastAccessedDetailsResponse: S.Schema<GetServiceLastAccessedDetailsResponse>;
export interface GetServiceLastAccessedDetailsWithEntitiesRequest {
    JobId: string;
    ServiceNamespace: string;
    MaxItems?: number;
    Marker?: string;
}
export declare const GetServiceLastAccessedDetailsWithEntitiesRequest: S.Schema<GetServiceLastAccessedDetailsWithEntitiesRequest>;
export type PolicyOwnerEntityType = "USER" | "ROLE" | "GROUP" | (string & {});
export declare const PolicyOwnerEntityType: any;
export interface EntityInfo {
    Arn: string;
    Name: string;
    Type: PolicyOwnerEntityType;
    Id: string;
    Path?: string;
}
export declare const EntityInfo: S.Schema<EntityInfo>;
export interface EntityDetails {
    EntityInfo: EntityInfo;
    LastAuthenticated?: Date;
}
export declare const EntityDetails: S.Schema<EntityDetails>;
export type EntityDetailsListType = EntityDetails[];
export declare const EntityDetailsListType: any;
export interface GetServiceLastAccessedDetailsWithEntitiesResponse {
    JobStatus: JobStatusType;
    JobCreationDate: Date;
    JobCompletionDate: Date;
    EntityDetailsList: EntityDetails[];
    IsTruncated?: boolean;
    Marker?: string;
    Error?: ErrorDetails;
}
export declare const GetServiceLastAccessedDetailsWithEntitiesResponse: S.Schema<GetServiceLastAccessedDetailsWithEntitiesResponse>;
export interface GetServiceLinkedRoleDeletionStatusRequest {
    DeletionTaskId: string;
}
export declare const GetServiceLinkedRoleDeletionStatusRequest: S.Schema<GetServiceLinkedRoleDeletionStatusRequest>;
export type DeletionTaskStatusType = "SUCCEEDED" | "IN_PROGRESS" | "FAILED" | "NOT_STARTED" | (string & {});
export declare const DeletionTaskStatusType: any;
export type ReasonType = string;
export type RegionNameType = string;
export type ArnListType = string[];
export declare const ArnListType: any;
export interface RoleUsageType {
    Region?: string;
    Resources?: string[];
}
export declare const RoleUsageType: S.Schema<RoleUsageType>;
export type RoleUsageListType = RoleUsageType[];
export declare const RoleUsageListType: any;
export interface DeletionTaskFailureReasonType {
    Reason?: string;
    RoleUsageList?: RoleUsageType[];
}
export declare const DeletionTaskFailureReasonType: S.Schema<DeletionTaskFailureReasonType>;
export interface GetServiceLinkedRoleDeletionStatusResponse {
    Status: DeletionTaskStatusType;
    Reason?: DeletionTaskFailureReasonType;
}
export declare const GetServiceLinkedRoleDeletionStatusResponse: S.Schema<GetServiceLinkedRoleDeletionStatusResponse>;
export type EncodingType = "SSH" | "PEM" | (string & {});
export declare const EncodingType: any;
export interface GetSSHPublicKeyRequest {
    UserName: string;
    SSHPublicKeyId: string;
    Encoding: EncodingType;
}
export declare const GetSSHPublicKeyRequest: S.Schema<GetSSHPublicKeyRequest>;
export type PublicKeyFingerprintType = string;
export type PublicKeyMaterialType = string;
export interface SSHPublicKey {
    UserName: string;
    SSHPublicKeyId: string;
    Fingerprint: string;
    SSHPublicKeyBody: string;
    Status: StatusType;
    UploadDate?: Date;
}
export declare const SSHPublicKey: S.Schema<SSHPublicKey>;
export interface GetSSHPublicKeyResponse {
    SSHPublicKey?: SSHPublicKey;
}
export declare const GetSSHPublicKeyResponse: S.Schema<GetSSHPublicKeyResponse>;
export interface GetUserRequest {
    UserName?: string;
}
export declare const GetUserRequest: S.Schema<GetUserRequest>;
export interface GetUserResponse {
    User: User;
}
export declare const GetUserResponse: S.Schema<GetUserResponse>;
export interface GetUserPolicyRequest {
    UserName: string;
    PolicyName: string;
}
export declare const GetUserPolicyRequest: S.Schema<GetUserPolicyRequest>;
export interface GetUserPolicyResponse {
    UserName: string;
    PolicyName: string;
    PolicyDocument: string;
}
export declare const GetUserPolicyResponse: S.Schema<GetUserPolicyResponse>;
export interface ListAccessKeysRequest {
    UserName?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListAccessKeysRequest: S.Schema<ListAccessKeysRequest>;
export interface AccessKeyMetadata {
    UserName?: string;
    AccessKeyId?: string;
    Status?: StatusType;
    CreateDate?: Date;
}
export declare const AccessKeyMetadata: S.Schema<AccessKeyMetadata>;
export type AccessKeyMetadataListType = AccessKeyMetadata[];
export declare const AccessKeyMetadataListType: any;
export interface ListAccessKeysResponse {
    AccessKeyMetadata: AccessKeyMetadata[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListAccessKeysResponse: S.Schema<ListAccessKeysResponse>;
export interface ListAccountAliasesRequest {
    Marker?: string;
    MaxItems?: number;
}
export declare const ListAccountAliasesRequest: S.Schema<ListAccountAliasesRequest>;
export type AccountAliasListType = string[];
export declare const AccountAliasListType: any;
export interface ListAccountAliasesResponse {
    AccountAliases: string[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListAccountAliasesResponse: S.Schema<ListAccountAliasesResponse>;
export interface ListAttachedGroupPoliciesRequest {
    GroupName: string;
    PathPrefix?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListAttachedGroupPoliciesRequest: S.Schema<ListAttachedGroupPoliciesRequest>;
export interface ListAttachedGroupPoliciesResponse {
    AttachedPolicies?: AttachedPolicy[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListAttachedGroupPoliciesResponse: S.Schema<ListAttachedGroupPoliciesResponse>;
export interface ListAttachedRolePoliciesRequest {
    RoleName: string;
    PathPrefix?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListAttachedRolePoliciesRequest: S.Schema<ListAttachedRolePoliciesRequest>;
export interface ListAttachedRolePoliciesResponse {
    AttachedPolicies?: AttachedPolicy[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListAttachedRolePoliciesResponse: S.Schema<ListAttachedRolePoliciesResponse>;
export interface ListAttachedUserPoliciesRequest {
    UserName: string;
    PathPrefix?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListAttachedUserPoliciesRequest: S.Schema<ListAttachedUserPoliciesRequest>;
export interface ListAttachedUserPoliciesResponse {
    AttachedPolicies?: AttachedPolicy[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListAttachedUserPoliciesResponse: S.Schema<ListAttachedUserPoliciesResponse>;
export interface ListDelegationRequestsRequest {
    OwnerId?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListDelegationRequestsRequest: S.Schema<ListDelegationRequestsRequest>;
export type DelegationRequestsListType = DelegationRequest[];
export declare const DelegationRequestsListType: any;
export interface ListDelegationRequestsResponse {
    DelegationRequests?: DelegationRequest[];
    Marker?: string;
    isTruncated?: boolean;
}
export declare const ListDelegationRequestsResponse: S.Schema<ListDelegationRequestsResponse>;
export type PolicyUsageType = "PermissionsPolicy" | "PermissionsBoundary" | (string & {});
export declare const PolicyUsageType: any;
export interface ListEntitiesForPolicyRequest {
    PolicyArn: string;
    EntityFilter?: EntityType;
    PathPrefix?: string;
    PolicyUsageFilter?: PolicyUsageType;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListEntitiesForPolicyRequest: S.Schema<ListEntitiesForPolicyRequest>;
export interface PolicyGroup {
    GroupName?: string;
    GroupId?: string;
}
export declare const PolicyGroup: S.Schema<PolicyGroup>;
export type PolicyGroupListType = PolicyGroup[];
export declare const PolicyGroupListType: any;
export interface PolicyUser {
    UserName?: string;
    UserId?: string;
}
export declare const PolicyUser: S.Schema<PolicyUser>;
export type PolicyUserListType = PolicyUser[];
export declare const PolicyUserListType: any;
export interface PolicyRole {
    RoleName?: string;
    RoleId?: string;
}
export declare const PolicyRole: S.Schema<PolicyRole>;
export type PolicyRoleListType = PolicyRole[];
export declare const PolicyRoleListType: any;
export interface ListEntitiesForPolicyResponse {
    PolicyGroups?: PolicyGroup[];
    PolicyUsers?: PolicyUser[];
    PolicyRoles?: PolicyRole[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListEntitiesForPolicyResponse: S.Schema<ListEntitiesForPolicyResponse>;
export interface ListGroupPoliciesRequest {
    GroupName: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListGroupPoliciesRequest: S.Schema<ListGroupPoliciesRequest>;
export type PolicyNameListType = string[];
export declare const PolicyNameListType: any;
export interface ListGroupPoliciesResponse {
    PolicyNames: string[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListGroupPoliciesResponse: S.Schema<ListGroupPoliciesResponse>;
export type PathPrefixType = string;
export interface ListGroupsRequest {
    PathPrefix?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListGroupsRequest: S.Schema<ListGroupsRequest>;
export type GroupListType = Group[];
export declare const GroupListType: any;
export interface ListGroupsResponse {
    Groups: Group[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListGroupsResponse: S.Schema<ListGroupsResponse>;
export interface ListGroupsForUserRequest {
    UserName: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListGroupsForUserRequest: S.Schema<ListGroupsForUserRequest>;
export interface ListGroupsForUserResponse {
    Groups: Group[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListGroupsForUserResponse: S.Schema<ListGroupsForUserResponse>;
export interface ListInstanceProfilesRequest {
    PathPrefix?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListInstanceProfilesRequest: S.Schema<ListInstanceProfilesRequest>;
export interface ListInstanceProfilesResponse {
    InstanceProfiles: InstanceProfile[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListInstanceProfilesResponse: S.Schema<ListInstanceProfilesResponse>;
export interface ListInstanceProfilesForRoleRequest {
    RoleName: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListInstanceProfilesForRoleRequest: S.Schema<ListInstanceProfilesForRoleRequest>;
export interface ListInstanceProfilesForRoleResponse {
    InstanceProfiles: InstanceProfile[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListInstanceProfilesForRoleResponse: S.Schema<ListInstanceProfilesForRoleResponse>;
export interface ListInstanceProfileTagsRequest {
    InstanceProfileName: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListInstanceProfileTagsRequest: S.Schema<ListInstanceProfileTagsRequest>;
export interface ListInstanceProfileTagsResponse {
    Tags: Tag[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListInstanceProfileTagsResponse: S.Schema<ListInstanceProfileTagsResponse>;
export interface ListMFADevicesRequest {
    UserName?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListMFADevicesRequest: S.Schema<ListMFADevicesRequest>;
export interface MFADevice {
    UserName: string;
    SerialNumber: string;
    EnableDate: Date;
}
export declare const MFADevice: S.Schema<MFADevice>;
export type MfaDeviceListType = MFADevice[];
export declare const MfaDeviceListType: any;
export interface ListMFADevicesResponse {
    MFADevices: MFADevice[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListMFADevicesResponse: S.Schema<ListMFADevicesResponse>;
export interface ListMFADeviceTagsRequest {
    SerialNumber: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListMFADeviceTagsRequest: S.Schema<ListMFADeviceTagsRequest>;
export interface ListMFADeviceTagsResponse {
    Tags: Tag[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListMFADeviceTagsResponse: S.Schema<ListMFADeviceTagsResponse>;
export interface ListOpenIDConnectProvidersRequest {
}
export declare const ListOpenIDConnectProvidersRequest: S.Schema<ListOpenIDConnectProvidersRequest>;
export interface OpenIDConnectProviderListEntry {
    Arn?: string;
}
export declare const OpenIDConnectProviderListEntry: S.Schema<OpenIDConnectProviderListEntry>;
export type OpenIDConnectProviderListType = OpenIDConnectProviderListEntry[];
export declare const OpenIDConnectProviderListType: any;
export interface ListOpenIDConnectProvidersResponse {
    OpenIDConnectProviderList?: OpenIDConnectProviderListEntry[];
}
export declare const ListOpenIDConnectProvidersResponse: S.Schema<ListOpenIDConnectProvidersResponse>;
export interface ListOpenIDConnectProviderTagsRequest {
    OpenIDConnectProviderArn: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListOpenIDConnectProviderTagsRequest: S.Schema<ListOpenIDConnectProviderTagsRequest>;
export interface ListOpenIDConnectProviderTagsResponse {
    Tags: Tag[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListOpenIDConnectProviderTagsResponse: S.Schema<ListOpenIDConnectProviderTagsResponse>;
export interface ListOrganizationsFeaturesRequest {
}
export declare const ListOrganizationsFeaturesRequest: S.Schema<ListOrganizationsFeaturesRequest>;
export interface ListOrganizationsFeaturesResponse {
    OrganizationId?: string;
    EnabledFeatures?: FeatureType[];
}
export declare const ListOrganizationsFeaturesResponse: S.Schema<ListOrganizationsFeaturesResponse>;
export type PolicyScopeType = "All" | "AWS" | "Local" | (string & {});
export declare const PolicyScopeType: any;
export interface ListPoliciesRequest {
    Scope?: PolicyScopeType;
    OnlyAttached?: boolean;
    PathPrefix?: string;
    PolicyUsageFilter?: PolicyUsageType;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListPoliciesRequest: S.Schema<ListPoliciesRequest>;
export type PolicyListType = Policy[];
export declare const PolicyListType: any;
export interface ListPoliciesResponse {
    Policies?: Policy[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListPoliciesResponse: S.Schema<ListPoliciesResponse>;
export type ServiceNamespaceListType = string[];
export declare const ServiceNamespaceListType: any;
export interface ListPoliciesGrantingServiceAccessRequest {
    Marker?: string;
    Arn: string;
    ServiceNamespaces: string[];
}
export declare const ListPoliciesGrantingServiceAccessRequest: S.Schema<ListPoliciesGrantingServiceAccessRequest>;
export type PolicyType = "INLINE" | "MANAGED" | (string & {});
export declare const PolicyType: any;
export type EntityNameType = string;
export interface PolicyGrantingServiceAccess {
    PolicyName: string;
    PolicyType: PolicyType;
    PolicyArn?: string;
    EntityType?: PolicyOwnerEntityType;
    EntityName?: string;
}
export declare const PolicyGrantingServiceAccess: S.Schema<PolicyGrantingServiceAccess>;
export type PolicyGrantingServiceAccessListType = PolicyGrantingServiceAccess[];
export declare const PolicyGrantingServiceAccessListType: any;
export interface ListPoliciesGrantingServiceAccessEntry {
    ServiceNamespace?: string;
    Policies?: PolicyGrantingServiceAccess[];
}
export declare const ListPoliciesGrantingServiceAccessEntry: S.Schema<ListPoliciesGrantingServiceAccessEntry>;
export type ListPolicyGrantingServiceAccessResponseListType = ListPoliciesGrantingServiceAccessEntry[];
export declare const ListPolicyGrantingServiceAccessResponseListType: any;
export interface ListPoliciesGrantingServiceAccessResponse {
    PoliciesGrantingServiceAccess: ListPoliciesGrantingServiceAccessEntry[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListPoliciesGrantingServiceAccessResponse: S.Schema<ListPoliciesGrantingServiceAccessResponse>;
export interface ListPolicyTagsRequest {
    PolicyArn: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListPolicyTagsRequest: S.Schema<ListPolicyTagsRequest>;
export interface ListPolicyTagsResponse {
    Tags: Tag[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListPolicyTagsResponse: S.Schema<ListPolicyTagsResponse>;
export interface ListPolicyVersionsRequest {
    PolicyArn: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListPolicyVersionsRequest: S.Schema<ListPolicyVersionsRequest>;
export interface ListPolicyVersionsResponse {
    Versions?: PolicyVersion[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListPolicyVersionsResponse: S.Schema<ListPolicyVersionsResponse>;
export interface ListRolePoliciesRequest {
    RoleName: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListRolePoliciesRequest: S.Schema<ListRolePoliciesRequest>;
export interface ListRolePoliciesResponse {
    PolicyNames: string[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListRolePoliciesResponse: S.Schema<ListRolePoliciesResponse>;
export interface ListRolesRequest {
    PathPrefix?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListRolesRequest: S.Schema<ListRolesRequest>;
export interface ListRolesResponse {
    Roles: Role[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListRolesResponse: S.Schema<ListRolesResponse>;
export interface ListRoleTagsRequest {
    RoleName: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListRoleTagsRequest: S.Schema<ListRoleTagsRequest>;
export interface ListRoleTagsResponse {
    Tags: Tag[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListRoleTagsResponse: S.Schema<ListRoleTagsResponse>;
export interface ListSAMLProvidersRequest {
}
export declare const ListSAMLProvidersRequest: S.Schema<ListSAMLProvidersRequest>;
export interface SAMLProviderListEntry {
    Arn?: string;
    ValidUntil?: Date;
    CreateDate?: Date;
}
export declare const SAMLProviderListEntry: S.Schema<SAMLProviderListEntry>;
export type SAMLProviderListType = SAMLProviderListEntry[];
export declare const SAMLProviderListType: any;
export interface ListSAMLProvidersResponse {
    SAMLProviderList?: SAMLProviderListEntry[];
}
export declare const ListSAMLProvidersResponse: S.Schema<ListSAMLProvidersResponse>;
export interface ListSAMLProviderTagsRequest {
    SAMLProviderArn: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListSAMLProviderTagsRequest: S.Schema<ListSAMLProviderTagsRequest>;
export interface ListSAMLProviderTagsResponse {
    Tags: Tag[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListSAMLProviderTagsResponse: S.Schema<ListSAMLProviderTagsResponse>;
export interface ListServerCertificatesRequest {
    PathPrefix?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListServerCertificatesRequest: S.Schema<ListServerCertificatesRequest>;
export type ServerCertificateMetadataListType = ServerCertificateMetadata[];
export declare const ServerCertificateMetadataListType: any;
export interface ListServerCertificatesResponse {
    ServerCertificateMetadataList: ServerCertificateMetadata[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListServerCertificatesResponse: S.Schema<ListServerCertificatesResponse>;
export interface ListServerCertificateTagsRequest {
    ServerCertificateName: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListServerCertificateTagsRequest: S.Schema<ListServerCertificateTagsRequest>;
export interface ListServerCertificateTagsResponse {
    Tags: Tag[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListServerCertificateTagsResponse: S.Schema<ListServerCertificateTagsResponse>;
export type AllUsers = boolean;
export interface ListServiceSpecificCredentialsRequest {
    UserName?: string;
    ServiceName?: string;
    AllUsers?: boolean;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListServiceSpecificCredentialsRequest: S.Schema<ListServiceSpecificCredentialsRequest>;
export interface ServiceSpecificCredentialMetadata {
    UserName: string;
    Status: StatusType;
    ServiceUserName?: string;
    ServiceCredentialAlias?: string;
    CreateDate: Date;
    ExpirationDate?: Date;
    ServiceSpecificCredentialId: string;
    ServiceName: string;
}
export declare const ServiceSpecificCredentialMetadata: S.Schema<ServiceSpecificCredentialMetadata>;
export type ServiceSpecificCredentialsListType = ServiceSpecificCredentialMetadata[];
export declare const ServiceSpecificCredentialsListType: any;
export interface ListServiceSpecificCredentialsResponse {
    ServiceSpecificCredentials?: ServiceSpecificCredentialMetadata[];
    Marker?: string;
    IsTruncated?: boolean;
}
export declare const ListServiceSpecificCredentialsResponse: S.Schema<ListServiceSpecificCredentialsResponse>;
export interface ListSigningCertificatesRequest {
    UserName?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListSigningCertificatesRequest: S.Schema<ListSigningCertificatesRequest>;
export interface SigningCertificate {
    UserName: string;
    CertificateId: string;
    CertificateBody: string;
    Status: StatusType;
    UploadDate?: Date;
}
export declare const SigningCertificate: S.Schema<SigningCertificate>;
export type CertificateListType = SigningCertificate[];
export declare const CertificateListType: any;
export interface ListSigningCertificatesResponse {
    Certificates: SigningCertificate[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListSigningCertificatesResponse: S.Schema<ListSigningCertificatesResponse>;
export interface ListSSHPublicKeysRequest {
    UserName?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListSSHPublicKeysRequest: S.Schema<ListSSHPublicKeysRequest>;
export interface SSHPublicKeyMetadata {
    UserName: string;
    SSHPublicKeyId: string;
    Status: StatusType;
    UploadDate: Date;
}
export declare const SSHPublicKeyMetadata: S.Schema<SSHPublicKeyMetadata>;
export type SSHPublicKeyListType = SSHPublicKeyMetadata[];
export declare const SSHPublicKeyListType: any;
export interface ListSSHPublicKeysResponse {
    SSHPublicKeys?: SSHPublicKeyMetadata[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListSSHPublicKeysResponse: S.Schema<ListSSHPublicKeysResponse>;
export interface ListUserPoliciesRequest {
    UserName: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListUserPoliciesRequest: S.Schema<ListUserPoliciesRequest>;
export interface ListUserPoliciesResponse {
    PolicyNames: string[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListUserPoliciesResponse: S.Schema<ListUserPoliciesResponse>;
export interface ListUsersRequest {
    PathPrefix?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListUsersRequest: S.Schema<ListUsersRequest>;
export interface ListUsersResponse {
    Users: User[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListUsersResponse: S.Schema<ListUsersResponse>;
export interface ListUserTagsRequest {
    UserName: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListUserTagsRequest: S.Schema<ListUserTagsRequest>;
export interface ListUserTagsResponse {
    Tags: Tag[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListUserTagsResponse: S.Schema<ListUserTagsResponse>;
export type AssignmentStatusType = "Assigned" | "Unassigned" | "Any" | (string & {});
export declare const AssignmentStatusType: any;
export interface ListVirtualMFADevicesRequest {
    AssignmentStatus?: AssignmentStatusType;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListVirtualMFADevicesRequest: S.Schema<ListVirtualMFADevicesRequest>;
export type VirtualMFADeviceListType = VirtualMFADevice[];
export declare const VirtualMFADeviceListType: any;
export interface ListVirtualMFADevicesResponse {
    VirtualMFADevices: VirtualMFADevice[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const ListVirtualMFADevicesResponse: S.Schema<ListVirtualMFADevicesResponse>;
export interface PutAccountPropertiesRequest {
    Properties: {
        [key: string]: string | undefined;
    };
}
export declare const PutAccountPropertiesRequest: S.Schema<PutAccountPropertiesRequest>;
export interface PutAccountPropertiesResponse {
}
export declare const PutAccountPropertiesResponse: S.Schema<PutAccountPropertiesResponse>;
export interface PutGroupPolicyRequest {
    GroupName: string;
    PolicyName: string;
    PolicyDocument: string;
}
export declare const PutGroupPolicyRequest: S.Schema<PutGroupPolicyRequest>;
export interface PutGroupPolicyResponse {
}
export declare const PutGroupPolicyResponse: S.Schema<PutGroupPolicyResponse>;
export interface PutRolePermissionsBoundaryRequest {
    RoleName: string;
    PermissionsBoundary: string;
}
export declare const PutRolePermissionsBoundaryRequest: S.Schema<PutRolePermissionsBoundaryRequest>;
export interface PutRolePermissionsBoundaryResponse {
}
export declare const PutRolePermissionsBoundaryResponse: S.Schema<PutRolePermissionsBoundaryResponse>;
export interface PutRolePolicyRequest {
    RoleName: string;
    PolicyName: string;
    PolicyDocument: string;
}
export declare const PutRolePolicyRequest: S.Schema<PutRolePolicyRequest>;
export interface PutRolePolicyResponse {
}
export declare const PutRolePolicyResponse: S.Schema<PutRolePolicyResponse>;
export interface PutUserPermissionsBoundaryRequest {
    UserName: string;
    PermissionsBoundary: string;
}
export declare const PutUserPermissionsBoundaryRequest: S.Schema<PutUserPermissionsBoundaryRequest>;
export interface PutUserPermissionsBoundaryResponse {
}
export declare const PutUserPermissionsBoundaryResponse: S.Schema<PutUserPermissionsBoundaryResponse>;
export interface PutUserPolicyRequest {
    UserName: string;
    PolicyName: string;
    PolicyDocument: string;
}
export declare const PutUserPolicyRequest: S.Schema<PutUserPolicyRequest>;
export interface PutUserPolicyResponse {
}
export declare const PutUserPolicyResponse: S.Schema<PutUserPolicyResponse>;
export interface RejectDelegationRequestRequest {
    DelegationRequestId: string;
    Notes?: string;
}
export declare const RejectDelegationRequestRequest: S.Schema<RejectDelegationRequestRequest>;
export interface RejectDelegationRequestResponse {
}
export declare const RejectDelegationRequestResponse: S.Schema<RejectDelegationRequestResponse>;
export interface RemoveClientIDFromOpenIDConnectProviderRequest {
    OpenIDConnectProviderArn: string;
    ClientID: string;
}
export declare const RemoveClientIDFromOpenIDConnectProviderRequest: S.Schema<RemoveClientIDFromOpenIDConnectProviderRequest>;
export interface RemoveClientIDFromOpenIDConnectProviderResponse {
}
export declare const RemoveClientIDFromOpenIDConnectProviderResponse: S.Schema<RemoveClientIDFromOpenIDConnectProviderResponse>;
export interface RemoveRoleFromInstanceProfileRequest {
    InstanceProfileName: string;
    RoleName: string;
}
export declare const RemoveRoleFromInstanceProfileRequest: S.Schema<RemoveRoleFromInstanceProfileRequest>;
export interface RemoveRoleFromInstanceProfileResponse {
}
export declare const RemoveRoleFromInstanceProfileResponse: S.Schema<RemoveRoleFromInstanceProfileResponse>;
export interface RemoveUserFromGroupRequest {
    GroupName: string;
    UserName: string;
}
export declare const RemoveUserFromGroupRequest: S.Schema<RemoveUserFromGroupRequest>;
export interface RemoveUserFromGroupResponse {
}
export declare const RemoveUserFromGroupResponse: S.Schema<RemoveUserFromGroupResponse>;
export interface ResetServiceSpecificCredentialRequest {
    UserName?: string;
    ServiceSpecificCredentialId: string;
}
export declare const ResetServiceSpecificCredentialRequest: S.Schema<ResetServiceSpecificCredentialRequest>;
export interface ResetServiceSpecificCredentialResponse {
    ServiceSpecificCredential?: ServiceSpecificCredential;
}
export declare const ResetServiceSpecificCredentialResponse: S.Schema<ResetServiceSpecificCredentialResponse>;
export interface ResyncMFADeviceRequest {
    UserName: string;
    SerialNumber: string;
    AuthenticationCode1: string;
    AuthenticationCode2: string;
}
export declare const ResyncMFADeviceRequest: S.Schema<ResyncMFADeviceRequest>;
export interface ResyncMFADeviceResponse {
}
export declare const ResyncMFADeviceResponse: S.Schema<ResyncMFADeviceResponse>;
export interface SendDelegationTokenRequest {
    DelegationRequestId: string;
}
export declare const SendDelegationTokenRequest: S.Schema<SendDelegationTokenRequest>;
export interface SendDelegationTokenResponse {
}
export declare const SendDelegationTokenResponse: S.Schema<SendDelegationTokenResponse>;
export interface SetDefaultPolicyVersionRequest {
    PolicyArn: string;
    VersionId: string;
}
export declare const SetDefaultPolicyVersionRequest: S.Schema<SetDefaultPolicyVersionRequest>;
export interface SetDefaultPolicyVersionResponse {
}
export declare const SetDefaultPolicyVersionResponse: S.Schema<SetDefaultPolicyVersionResponse>;
export type GlobalEndpointTokenVersion = "v1Token" | "v2Token" | (string & {});
export declare const GlobalEndpointTokenVersion: any;
export interface SetSecurityTokenServicePreferencesRequest {
    GlobalEndpointTokenVersion: GlobalEndpointTokenVersion;
}
export declare const SetSecurityTokenServicePreferencesRequest: S.Schema<SetSecurityTokenServicePreferencesRequest>;
export interface SetSecurityTokenServicePreferencesResponse {
}
export declare const SetSecurityTokenServicePreferencesResponse: S.Schema<SetSecurityTokenServicePreferencesResponse>;
export interface OrderedOrganizationPolicyType {
    ServiceControlPolicyInputList?: string[];
}
export declare const OrderedOrganizationPolicyType: S.Schema<OrderedOrganizationPolicyType>;
export type OrganizationPolicyListType = OrderedOrganizationPolicyType[];
export declare const OrganizationPolicyListType: any;
export type ActionNameType = string;
export type ActionNameListType = string[];
export declare const ActionNameListType: any;
export type ResourceNameType = string;
export type ResourceNameListType = string[];
export declare const ResourceNameListType: any;
export type ContextKeyValueType = string;
export type ContextKeyValueListType = string[];
export declare const ContextKeyValueListType: any;
export type ContextKeyTypeEnum = "string" | "stringList" | "numeric" | "numericList" | "boolean" | "booleanList" | "ip" | "ipList" | "binary" | "binaryList" | "date" | "dateList" | (string & {});
export declare const ContextKeyTypeEnum: any;
export interface ContextEntry {
    ContextKeyName?: string;
    ContextKeyValues?: string[];
    ContextKeyType?: ContextKeyTypeEnum;
}
export declare const ContextEntry: S.Schema<ContextEntry>;
export type ContextEntryListType = ContextEntry[];
export declare const ContextEntryListType: any;
export type ResourceHandlingOptionType = string;
export interface SimulateCustomPolicyRequest {
    PolicyInputList: string[];
    PermissionsBoundaryPolicyInputList?: string[];
    OrderedOrganizationPolicyInputList?: OrderedOrganizationPolicyType[];
    ActionNames: string[];
    ResourceArns?: string[];
    ResourcePolicy?: string;
    ResourceOwner?: string;
    CallerArn?: string;
    ContextEntries?: ContextEntry[];
    ResourceHandlingOption?: string;
    MaxItems?: number;
    Marker?: string;
}
export declare const SimulateCustomPolicyRequest: S.Schema<SimulateCustomPolicyRequest>;
export type PolicyEvaluationDecisionType = "allowed" | "explicitDeny" | "implicitDeny" | (string & {});
export declare const PolicyEvaluationDecisionType: any;
export type PolicyIdentifierType = string;
export type PolicySourceType = "user" | "group" | "role" | "aws-managed" | "user-managed" | "resource" | "none" | (string & {});
export declare const PolicySourceType: any;
export type LineNumber = number;
export type ColumnNumber = number;
export interface Position {
    Line?: number;
    Column?: number;
}
export declare const Position: S.Schema<Position>;
export interface Statement {
    SourcePolicyId?: string;
    SourcePolicyType?: PolicySourceType;
    StartPosition?: Position;
    EndPosition?: Position;
}
export declare const Statement: S.Schema<Statement>;
export type StatementListType = Statement[];
export declare const StatementListType: any;
export interface OrganizationsDecisionDetail {
    AllowedByOrganizations?: boolean;
}
export declare const OrganizationsDecisionDetail: S.Schema<OrganizationsDecisionDetail>;
export interface PermissionsBoundaryDecisionDetail {
    AllowedByPermissionsBoundary?: boolean;
}
export declare const PermissionsBoundaryDecisionDetail: S.Schema<PermissionsBoundaryDecisionDetail>;
export type EvalDecisionSourceType = string;
export type EvalDecisionDetailsType = {
    [key: string]: PolicyEvaluationDecisionType | undefined;
};
export declare const EvalDecisionDetailsType: any;
export interface ResourceSpecificResult {
    EvalResourceName: string;
    EvalResourceDecision: PolicyEvaluationDecisionType;
    MatchedStatements?: Statement[];
    MissingContextValues?: string[];
    EvalDecisionDetails?: {
        [key: string]: PolicyEvaluationDecisionType | undefined;
    };
    PermissionsBoundaryDecisionDetail?: PermissionsBoundaryDecisionDetail;
}
export declare const ResourceSpecificResult: S.Schema<ResourceSpecificResult>;
export type ResourceSpecificResultListType = ResourceSpecificResult[];
export declare const ResourceSpecificResultListType: any;
export interface EvaluationResult {
    EvalActionName: string;
    EvalResourceName?: string;
    EvalDecision: PolicyEvaluationDecisionType;
    MatchedStatements?: Statement[];
    MissingContextValues?: string[];
    OrganizationsDecisionDetail?: OrganizationsDecisionDetail;
    PermissionsBoundaryDecisionDetail?: PermissionsBoundaryDecisionDetail;
    EvalDecisionDetails?: {
        [key: string]: PolicyEvaluationDecisionType | undefined;
    };
    ResourceSpecificResults?: ResourceSpecificResult[];
}
export declare const EvaluationResult: S.Schema<EvaluationResult>;
export type EvaluationResultsListType = EvaluationResult[];
export declare const EvaluationResultsListType: any;
export interface SimulatePolicyResponse {
    EvaluationResults?: EvaluationResult[];
    IsTruncated?: boolean;
    Marker?: string;
}
export declare const SimulatePolicyResponse: S.Schema<SimulatePolicyResponse>;
export type PolicyIdentifierPolicyType = "inline" | "aws-managed" | "user-managed" | "permission-boundary" | "scp" | "rcp" | (string & {});
export declare const PolicyIdentifierPolicyType: any;
export type AttachmentType = "user" | "group" | "role" | (string & {});
export declare const AttachmentType: any;
export type AttachmentName = string;
export interface InlinePolicyIdentifierType {
    PolicyName: string;
    AttachmentType: AttachmentType;
    AttachmentName: string;
}
export declare const InlinePolicyIdentifierType: S.Schema<InlinePolicyIdentifierType>;
export type PolicyIdentifier = {
    PolicyType: PolicyIdentifierPolicyType;
    PolicyArn?: never;
    InlinePolicyIdentifier?: never;
} | {
    PolicyType?: never;
    PolicyArn: string;
    InlinePolicyIdentifier?: never;
} | {
    PolicyType?: never;
    PolicyArn?: never;
    InlinePolicyIdentifier: InlinePolicyIdentifierType;
};
export declare const PolicyIdentifier: any;
export type PolicyExclusionsListType = PolicyIdentifier[];
export declare const PolicyExclusionsListType: any;
export interface SimulatePrincipalPolicyRequest {
    PolicySourceArn: string;
    PolicyInputList?: string[];
    PermissionsBoundaryPolicyInputList?: string[];
    PolicyExclusionList?: PolicyIdentifier[];
    ActionNames: string[];
    ResourceArns?: string[];
    ResourcePolicy?: string;
    ResourceOwner?: string;
    CallerArn?: string;
    ContextEntries?: ContextEntry[];
    ResourceHandlingOption?: string;
    MaxItems?: number;
    Marker?: string;
}
export declare const SimulatePrincipalPolicyRequest: S.Schema<SimulatePrincipalPolicyRequest>;
export interface TagInstanceProfileRequest {
    InstanceProfileName: string;
    Tags: Tag[];
}
export declare const TagInstanceProfileRequest: S.Schema<TagInstanceProfileRequest>;
export interface TagInstanceProfileResponse {
}
export declare const TagInstanceProfileResponse: S.Schema<TagInstanceProfileResponse>;
export interface TagMFADeviceRequest {
    SerialNumber: string;
    Tags: Tag[];
}
export declare const TagMFADeviceRequest: S.Schema<TagMFADeviceRequest>;
export interface TagMFADeviceResponse {
}
export declare const TagMFADeviceResponse: S.Schema<TagMFADeviceResponse>;
export interface TagOpenIDConnectProviderRequest {
    OpenIDConnectProviderArn: string;
    Tags: Tag[];
}
export declare const TagOpenIDConnectProviderRequest: S.Schema<TagOpenIDConnectProviderRequest>;
export interface TagOpenIDConnectProviderResponse {
}
export declare const TagOpenIDConnectProviderResponse: S.Schema<TagOpenIDConnectProviderResponse>;
export interface TagPolicyRequest {
    PolicyArn: string;
    Tags: Tag[];
}
export declare const TagPolicyRequest: S.Schema<TagPolicyRequest>;
export interface TagPolicyResponse {
}
export declare const TagPolicyResponse: S.Schema<TagPolicyResponse>;
export interface TagRoleRequest {
    RoleName: string;
    Tags: Tag[];
}
export declare const TagRoleRequest: S.Schema<TagRoleRequest>;
export interface TagRoleResponse {
}
export declare const TagRoleResponse: S.Schema<TagRoleResponse>;
export interface TagSAMLProviderRequest {
    SAMLProviderArn: string;
    Tags: Tag[];
}
export declare const TagSAMLProviderRequest: S.Schema<TagSAMLProviderRequest>;
export interface TagSAMLProviderResponse {
}
export declare const TagSAMLProviderResponse: S.Schema<TagSAMLProviderResponse>;
export interface TagServerCertificateRequest {
    ServerCertificateName: string;
    Tags: Tag[];
}
export declare const TagServerCertificateRequest: S.Schema<TagServerCertificateRequest>;
export interface TagServerCertificateResponse {
}
export declare const TagServerCertificateResponse: S.Schema<TagServerCertificateResponse>;
export interface TagUserRequest {
    UserName: string;
    Tags: Tag[];
}
export declare const TagUserRequest: S.Schema<TagUserRequest>;
export interface TagUserResponse {
}
export declare const TagUserResponse: S.Schema<TagUserResponse>;
export type TagKeyListType = string[];
export declare const TagKeyListType: any;
export interface UntagInstanceProfileRequest {
    InstanceProfileName: string;
    TagKeys: string[];
}
export declare const UntagInstanceProfileRequest: S.Schema<UntagInstanceProfileRequest>;
export interface UntagInstanceProfileResponse {
}
export declare const UntagInstanceProfileResponse: S.Schema<UntagInstanceProfileResponse>;
export interface UntagMFADeviceRequest {
    SerialNumber: string;
    TagKeys: string[];
}
export declare const UntagMFADeviceRequest: S.Schema<UntagMFADeviceRequest>;
export interface UntagMFADeviceResponse {
}
export declare const UntagMFADeviceResponse: S.Schema<UntagMFADeviceResponse>;
export interface UntagOpenIDConnectProviderRequest {
    OpenIDConnectProviderArn: string;
    TagKeys: string[];
}
export declare const UntagOpenIDConnectProviderRequest: S.Schema<UntagOpenIDConnectProviderRequest>;
export interface UntagOpenIDConnectProviderResponse {
}
export declare const UntagOpenIDConnectProviderResponse: S.Schema<UntagOpenIDConnectProviderResponse>;
export interface UntagPolicyRequest {
    PolicyArn: string;
    TagKeys: string[];
}
export declare const UntagPolicyRequest: S.Schema<UntagPolicyRequest>;
export interface UntagPolicyResponse {
}
export declare const UntagPolicyResponse: S.Schema<UntagPolicyResponse>;
export interface UntagRoleRequest {
    RoleName: string;
    TagKeys: string[];
}
export declare const UntagRoleRequest: S.Schema<UntagRoleRequest>;
export interface UntagRoleResponse {
}
export declare const UntagRoleResponse: S.Schema<UntagRoleResponse>;
export interface UntagSAMLProviderRequest {
    SAMLProviderArn: string;
    TagKeys: string[];
}
export declare const UntagSAMLProviderRequest: S.Schema<UntagSAMLProviderRequest>;
export interface UntagSAMLProviderResponse {
}
export declare const UntagSAMLProviderResponse: S.Schema<UntagSAMLProviderResponse>;
export interface UntagServerCertificateRequest {
    ServerCertificateName: string;
    TagKeys: string[];
}
export declare const UntagServerCertificateRequest: S.Schema<UntagServerCertificateRequest>;
export interface UntagServerCertificateResponse {
}
export declare const UntagServerCertificateResponse: S.Schema<UntagServerCertificateResponse>;
export interface UntagUserRequest {
    UserName: string;
    TagKeys: string[];
}
export declare const UntagUserRequest: S.Schema<UntagUserRequest>;
export interface UntagUserResponse {
}
export declare const UntagUserResponse: S.Schema<UntagUserResponse>;
export interface UpdateAccessKeyRequest {
    UserName?: string;
    AccessKeyId: string;
    Status: StatusType;
}
export declare const UpdateAccessKeyRequest: S.Schema<UpdateAccessKeyRequest>;
export interface UpdateAccessKeyResponse {
}
export declare const UpdateAccessKeyResponse: S.Schema<UpdateAccessKeyResponse>;
export interface UpdateAccountPasswordPolicyRequest {
    MinimumPasswordLength?: number;
    RequireSymbols?: boolean;
    RequireNumbers?: boolean;
    RequireUppercaseCharacters?: boolean;
    RequireLowercaseCharacters?: boolean;
    AllowUsersToChangePassword?: boolean;
    MaxPasswordAge?: number;
    PasswordReusePrevention?: number;
    HardExpiry?: boolean;
}
export declare const UpdateAccountPasswordPolicyRequest: S.Schema<UpdateAccountPasswordPolicyRequest>;
export interface UpdateAccountPasswordPolicyResponse {
}
export declare const UpdateAccountPasswordPolicyResponse: S.Schema<UpdateAccountPasswordPolicyResponse>;
export interface UpdateAssumeRolePolicyRequest {
    RoleName: string;
    PolicyDocument: string;
}
export declare const UpdateAssumeRolePolicyRequest: S.Schema<UpdateAssumeRolePolicyRequest>;
export interface UpdateAssumeRolePolicyResponse {
}
export declare const UpdateAssumeRolePolicyResponse: S.Schema<UpdateAssumeRolePolicyResponse>;
export interface UpdateDelegationRequestRequest {
    DelegationRequestId: string;
    Notes?: string;
}
export declare const UpdateDelegationRequestRequest: S.Schema<UpdateDelegationRequestRequest>;
export interface UpdateDelegationRequestResponse {
}
export declare const UpdateDelegationRequestResponse: S.Schema<UpdateDelegationRequestResponse>;
export interface UpdateGroupRequest {
    GroupName: string;
    NewPath?: string;
    NewGroupName?: string;
}
export declare const UpdateGroupRequest: S.Schema<UpdateGroupRequest>;
export interface UpdateGroupResponse {
}
export declare const UpdateGroupResponse: S.Schema<UpdateGroupResponse>;
export interface UpdateLoginProfileRequest {
    UserName: string;
    Password?: string | redacted.Redacted<string>;
    PasswordResetRequired?: boolean;
}
export declare const UpdateLoginProfileRequest: S.Schema<UpdateLoginProfileRequest>;
export interface UpdateLoginProfileResponse {
}
export declare const UpdateLoginProfileResponse: S.Schema<UpdateLoginProfileResponse>;
export interface UpdateOpenIDConnectProviderThumbprintRequest {
    OpenIDConnectProviderArn: string;
    ThumbprintList: string[];
}
export declare const UpdateOpenIDConnectProviderThumbprintRequest: S.Schema<UpdateOpenIDConnectProviderThumbprintRequest>;
export interface UpdateOpenIDConnectProviderThumbprintResponse {
}
export declare const UpdateOpenIDConnectProviderThumbprintResponse: S.Schema<UpdateOpenIDConnectProviderThumbprintResponse>;
export interface UpdateRoleRequest {
    RoleName: string;
    Description?: string;
    MaxSessionDuration?: number;
}
export declare const UpdateRoleRequest: S.Schema<UpdateRoleRequest>;
export interface UpdateRoleResponse {
}
export declare const UpdateRoleResponse: S.Schema<UpdateRoleResponse>;
export interface UpdateRoleDescriptionRequest {
    RoleName: string;
    Description: string;
}
export declare const UpdateRoleDescriptionRequest: S.Schema<UpdateRoleDescriptionRequest>;
export interface UpdateRoleDescriptionResponse {
    Role?: Role;
}
export declare const UpdateRoleDescriptionResponse: S.Schema<UpdateRoleDescriptionResponse>;
export interface UpdateSAMLProviderRequest {
    SAMLMetadataDocument?: string;
    SAMLProviderArn: string;
    AssertionEncryptionMode?: AssertionEncryptionModeType;
    AddPrivateKey?: string | redacted.Redacted<string>;
    RemovePrivateKey?: string;
}
export declare const UpdateSAMLProviderRequest: S.Schema<UpdateSAMLProviderRequest>;
export interface UpdateSAMLProviderResponse {
    SAMLProviderArn?: string;
}
export declare const UpdateSAMLProviderResponse: S.Schema<UpdateSAMLProviderResponse>;
export interface UpdateServerCertificateRequest {
    ServerCertificateName: string;
    NewPath?: string;
    NewServerCertificateName?: string;
}
export declare const UpdateServerCertificateRequest: S.Schema<UpdateServerCertificateRequest>;
export interface UpdateServerCertificateResponse {
}
export declare const UpdateServerCertificateResponse: S.Schema<UpdateServerCertificateResponse>;
export interface UpdateServiceSpecificCredentialRequest {
    UserName?: string;
    ServiceSpecificCredentialId: string;
    Status: StatusType;
}
export declare const UpdateServiceSpecificCredentialRequest: S.Schema<UpdateServiceSpecificCredentialRequest>;
export interface UpdateServiceSpecificCredentialResponse {
}
export declare const UpdateServiceSpecificCredentialResponse: S.Schema<UpdateServiceSpecificCredentialResponse>;
export interface UpdateSigningCertificateRequest {
    UserName?: string;
    CertificateId: string;
    Status: StatusType;
}
export declare const UpdateSigningCertificateRequest: S.Schema<UpdateSigningCertificateRequest>;
export interface UpdateSigningCertificateResponse {
}
export declare const UpdateSigningCertificateResponse: S.Schema<UpdateSigningCertificateResponse>;
export interface UpdateSSHPublicKeyRequest {
    UserName: string;
    SSHPublicKeyId: string;
    Status: StatusType;
}
export declare const UpdateSSHPublicKeyRequest: S.Schema<UpdateSSHPublicKeyRequest>;
export interface UpdateSSHPublicKeyResponse {
}
export declare const UpdateSSHPublicKeyResponse: S.Schema<UpdateSSHPublicKeyResponse>;
export interface UpdateUserRequest {
    UserName: string;
    NewPath?: string;
    NewUserName?: string;
}
export declare const UpdateUserRequest: S.Schema<UpdateUserRequest>;
export interface UpdateUserResponse {
}
export declare const UpdateUserResponse: S.Schema<UpdateUserResponse>;
export interface UploadServerCertificateRequest {
    Path?: string;
    ServerCertificateName: string;
    CertificateBody: string;
    PrivateKey: string | redacted.Redacted<string>;
    CertificateChain?: string;
    Tags?: Tag[];
}
export declare const UploadServerCertificateRequest: S.Schema<UploadServerCertificateRequest>;
export interface UploadServerCertificateResponse {
    ServerCertificateMetadata?: ServerCertificateMetadata;
    Tags?: Tag[];
}
export declare const UploadServerCertificateResponse: S.Schema<UploadServerCertificateResponse>;
export interface UploadSigningCertificateRequest {
    UserName?: string;
    CertificateBody: string;
}
export declare const UploadSigningCertificateRequest: S.Schema<UploadSigningCertificateRequest>;
export interface UploadSigningCertificateResponse {
    Certificate: SigningCertificate;
}
export declare const UploadSigningCertificateResponse: S.Schema<UploadSigningCertificateResponse>;
export interface UploadSSHPublicKeyRequest {
    UserName: string;
    SSHPublicKeyBody: string;
}
export declare const UploadSSHPublicKeyRequest: S.Schema<UploadSSHPublicKeyRequest>;
export interface UploadSSHPublicKeyResponse {
    SSHPublicKey?: SSHPublicKey;
}
export declare const UploadSSHPublicKeyResponse: S.Schema<UploadSSHPublicKeyResponse>;
export type ConcurrentModificationMessage = string;
export type NoSuchEntityMessage = string;
export type ServiceFailureExceptionMessage = string;
export type EntityAlreadyExistsMessage = string;
export type InvalidInputMessage = string;
export type LimitExceededMessage = string;
export type MalformedPolicyDocumentMessage = string;
export type NameConflictMessage = string;
export type RoleModifiedMessage = string;
export type RoleTemplateDisabledMessage = string;
export type UnmodifiableEntityMessage = string;
export type PolicyNotAttachableMessage = string;
export type EntityTemporarilyUnmodifiableMessage = string;
export type InvalidUserTypeMessage = string;
export type PasswordPolicyViolationMessage = string;
export type OpenIdIdpCommunicationErrorExceptionMessage = string;
export type ServiceNotSupportedMessage = string;
export type DeleteConflictMessage = string;
export type ExceptionMessage = string;
export type FeatureDisabledMessage = string;
export type InvalidAuthenticationCodeMessage = string;
export type FeatureEnabledMessage = string;
export type ReportGenerationLimitExceededMessage = string;
export type CredentialReportExpiredExceptionMessage = string;
export type CredentialReportNotPresentExceptionMessage = string;
export type CredentialReportNotReadyExceptionMessage = string;
export type UnrecognizedPublicKeyEncodingMessage = string;
export type PolicyEvaluationErrorMessage = string;
export type KeyPairMismatchMessage = string;
export type MalformedCertificateMessage = string;
export type DuplicateCertificateMessage = string;
export type InvalidCertificateMessage = string;
export type DuplicateSSHPublicKeyMessage = string;
export type InvalidPublicKeyMessage = string;
export type AcceptDelegationRequestError = ConcurrentModificationException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Accepts a delegation request, granting the requested temporary access.
 *
 * Once the delegation request is accepted, it is eligible to send the exchange token to the partner.
 * The SendDelegationToken
 * API has to be explicitly called to send the delegation token.
 *
 * At the time of acceptance, IAM records the details and the state of the identity that called this API.
 * This is the identity that gets mapped to the delegated credential.
 *
 * An accepted request may be rejected before the exchange token is sent to the partner.
 */
export declare const acceptDelegationRequest: API.OperationMethod<AcceptDelegationRequestRequest, AcceptDelegationRequestResponse, AcceptDelegationRequestError, Credentials | HttpClient.HttpClient>;
export type AcquireRoleError = ConcurrentModificationException | EntityAlreadyExistsException | InvalidInputException | LimitExceededException | MalformedPolicyDocumentException | NameConflictException | NoSuchEntityException | RoleModifiedException | RoleTemplateDisabledException | ServiceFailureException | CommonErrors;
/**
 * Creates an IAM role from the specified role template. The new role takes its
 * configuration—including its name, path, trust policy, inline and managed policies,
 * permissions boundary, tags, and maximum session duration—from the role
 * template version that you specify. For more information about roles, see IAM roles in the
 * *IAM User Guide*.
 *
 * If the template version defines parameters, use the `ReplacementValues`
 * parameter to supply the values that the service substitutes into the role during
 * creation.
 */
export declare const acquireRole: API.OperationMethod<AcquireRoleRequest, AcquireRoleResponse, AcquireRoleError, Credentials | HttpClient.HttpClient>;
export type AddClientIDToOpenIDConnectProviderError = ConcurrentModificationException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Adds a new client ID (also known as audience) to the list of client IDs already
 * registered for the specified IAM OpenID Connect (OIDC) provider resource.
 *
 * This operation is idempotent; it does not fail or return an error if you add an
 * existing client ID to the provider.
 */
export declare const addClientIDToOpenIDConnectProvider: API.OperationMethod<AddClientIDToOpenIDConnectProviderRequest, AddClientIDToOpenIDConnectProviderResponse, AddClientIDToOpenIDConnectProviderError, Credentials | HttpClient.HttpClient>;
export type AddRoleToInstanceProfileError = EntityAlreadyExistsException | LimitExceededException | NoSuchEntityException | ServiceFailureException | UnmodifiableEntityException | CommonErrors;
/**
 * Adds the specified IAM role to the specified instance profile. An instance profile
 * can contain only one role, and this quota cannot be increased. You can remove the
 * existing role and then add a different role to an instance profile. You must then wait
 * for the change to appear across all of Amazon Web Services because of eventual
 * consistency. To force the change, you must disassociate the instance profile and then associate the
 * instance profile, or you can stop your instance and then restart it.
 *
 * The caller of this operation must be granted the `PassRole` permission
 * on the IAM role by a permissions policy.
 *
 * When using the iam:AssociatedResourceArn condition in a policy to restrict the PassRole IAM action, special considerations apply if the policy is
 * intended to define access for the `AddRoleToInstanceProfile` action. In
 * this case, you cannot specify a Region or instance ID in the EC2 instance ARN. The
 * ARN value must be `arn:aws:ec2:*:CallerAccountId:instance/*`. Using any
 * other ARN value may lead to unexpected evaluation results.
 *
 * For more information about roles, see IAM roles in the
 * *IAM User Guide*. For more information about instance profiles,
 * see Using
 * instance profiles in the *IAM User Guide*.
 */
export declare const addRoleToInstanceProfile: API.OperationMethod<AddRoleToInstanceProfileRequest, AddRoleToInstanceProfileResponse, AddRoleToInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type AddUserToGroupError = LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Adds the specified user to the specified group.
 */
export declare const addUserToGroup: API.OperationMethod<AddUserToGroupRequest, AddUserToGroupResponse, AddUserToGroupError, Credentials | HttpClient.HttpClient>;
export type AssociateDelegationRequestError = ConcurrentModificationException | InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Associates a delegation request with the current identity.
 *
 * If the partner that created the delegation request has specified the owner account during creation,
 * only an identity from that owner account can call the `AssociateDelegationRequest` API for
 * the specified delegation request. Once the `AssociateDelegationRequest` API call is successful,
 * the ARN of the current calling identity will be stored as the
 * `ownerId`
 * of the request.
 *
 * If the partner that created the delegation request has not specified the owner account during creation,
 * any caller from any account can call the `AssociateDelegationRequest` API for
 * the delegation request. Once this API call is successful, the ARN of the current calling identity will be stored as the
 * `ownerId`
 * and the Amazon Web Services account ID of the current calling identity will be stored as the
 * `ownerAccount`
 * of the request.
 *
 * For more details, see
 *
 * Managing Permissions for Delegation Requests.
 */
export declare const associateDelegationRequest: API.OperationMethod<AssociateDelegationRequestRequest, AssociateDelegationRequestResponse, AssociateDelegationRequestError, Credentials | HttpClient.HttpClient>;
export type AttachGroupPolicyError = InvalidInputException | LimitExceededException | NoSuchEntityException | PolicyNotAttachableException | ServiceFailureException | CommonErrors;
/**
 * Attaches the specified managed policy to the specified IAM group.
 *
 * You use this operation to attach a managed policy to a group. To embed an inline
 * policy in a group, use
 * `PutGroupPolicy`
 * .
 *
 * As a best practice, you can validate your IAM policies.
 * To learn more, see Validating IAM policies
 * in the *IAM User Guide*.
 *
 * For more information about policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 */
export declare const attachGroupPolicy: API.OperationMethod<AttachGroupPolicyRequest, AttachGroupPolicyResponse, AttachGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type AttachRolePolicyError = InvalidInputException | LimitExceededException | NoSuchEntityException | PolicyNotAttachableException | ServiceFailureException | UnmodifiableEntityException | CommonErrors;
/**
 * Attaches the specified managed policy to the specified IAM role. When you attach a
 * managed policy to a role, the managed policy becomes part of the role's permission
 * (access) policy.
 *
 * You cannot use a managed policy as the role's trust policy. The role's trust
 * policy is created at the same time as the role, using
 * `CreateRole`
 * . You can update a role's trust policy using
 *
 * `UpdateAssumerolePolicy`
 * .
 *
 * Use this operation to attach a *managed* policy to a role. To embed
 * an inline policy in a role, use
 * `PutRolePolicy`
 * . For more information about policies, see Managed
 * policies and inline policies in the
 * *IAM User Guide*.
 *
 * As a best practice, you can validate your IAM policies.
 * To learn more, see Validating IAM policies
 * in the *IAM User Guide*.
 */
export declare const attachRolePolicy: API.OperationMethod<AttachRolePolicyRequest, AttachRolePolicyResponse, AttachRolePolicyError, Credentials | HttpClient.HttpClient>;
export type AttachUserPolicyError = InvalidInputException | LimitExceededException | NoSuchEntityException | PolicyNotAttachableException | ServiceFailureException | CommonErrors;
/**
 * Attaches the specified managed policy to the specified user.
 *
 * You use this operation to attach a *managed* policy to a user. To
 * embed an inline policy in a user, use
 * `PutUserPolicy`
 * .
 *
 * As a best practice, you can validate your IAM policies.
 * To learn more, see Validating IAM policies
 * in the *IAM User Guide*.
 *
 * For more information about policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 */
export declare const attachUserPolicy: API.OperationMethod<AttachUserPolicyRequest, AttachUserPolicyResponse, AttachUserPolicyError, Credentials | HttpClient.HttpClient>;
export type ChangePasswordError = EntityTemporarilyUnmodifiableException | InvalidUserTypeException | LimitExceededException | NoSuchEntityException | PasswordPolicyViolationException | ServiceFailureException | CommonErrors;
/**
 * Changes the password of the IAM user who is calling this operation. This operation
 * can be performed using the CLI, the Amazon Web Services API, or the My
 * Security Credentials page in the Amazon Web Services Management Console. The Amazon Web Services account root user password is
 * not affected by this operation.
 *
 * Use UpdateLoginProfile
 * to use the CLI, the Amazon Web Services API, or the **Users** page in
 * the IAM console to change the password for any IAM user. For more information about
 * modifying passwords, see Managing passwords in the
 * *IAM User Guide*.
 */
export declare const changePassword: API.OperationMethod<ChangePasswordRequest, ChangePasswordResponse, ChangePasswordError, Credentials | HttpClient.HttpClient>;
export type CreateAccessKeyError = LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Creates a new Amazon Web Services secret access key and corresponding Amazon Web Services access key ID for the
 * specified user. The default status for new keys is `Active`.
 *
 * If you do not specify a user name, IAM determines the user name implicitly based on
 * the Amazon Web Services access key ID signing the request. This operation works for access keys under
 * the Amazon Web Services account. Consequently, you can use this operation to manage Amazon Web Services account root
 * user credentials. This is true even if the Amazon Web Services account has no associated users.
 *
 * For information about quotas on the number of keys you can create, see IAM and STS
 * quotas in the *IAM User Guide*.
 *
 * To ensure the security of your Amazon Web Services account, the secret access key is accessible
 * only during key and user creation. You must save the key (for example, in a text
 * file) if you want to be able to access it again. If a secret key is lost, you can
 * delete the access keys for the associated user and then create new keys.
 */
export declare const createAccessKey: API.OperationMethod<CreateAccessKeyRequest, CreateAccessKeyResponse, CreateAccessKeyError, Credentials | HttpClient.HttpClient>;
export type CreateAccountAliasError = ConcurrentModificationException | EntityAlreadyExistsException | LimitExceededException | ServiceFailureException | CommonErrors;
/**
 * Creates an alias for your Amazon Web Services account. For information about using an Amazon Web Services account
 * alias, see Creating, deleting, and
 * listing an Amazon Web Services account alias in the Amazon Web Services Sign-In User
 * Guide.
 */
export declare const createAccountAlias: API.OperationMethod<CreateAccountAliasRequest, CreateAccountAliasResponse, CreateAccountAliasError, Credentials | HttpClient.HttpClient>;
export type CreateDelegationRequestError = ConcurrentModificationException | EntityAlreadyExistsException | InvalidInputException | LimitExceededException | ServiceFailureException | CommonErrors;
/**
 * Creates an IAM delegation request for temporary access delegation.
 *
 * This API is not available for general use. In order to use this API, a caller first need to
 * go through an onboarding process described in the
 * partner onboarding documentation.
 */
export declare const createDelegationRequest: API.OperationMethod<CreateDelegationRequestRequest, CreateDelegationRequestResponse, CreateDelegationRequestError, Credentials | HttpClient.HttpClient>;
export type CreateGroupError = EntityAlreadyExistsException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Creates a new group.
 *
 * For information about the number of groups you can create, see IAM and STS
 * quotas in the *IAM User Guide*.
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest, CreateGroupResponse, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateInstanceProfileError = ConcurrentModificationException | EntityAlreadyExistsException | InvalidInputException | LimitExceededException | ServiceFailureException | CommonErrors;
/**
 * Creates a new instance profile. For information about instance profiles, see Using
 * roles for applications on Amazon EC2 in the
 * *IAM User Guide*, and Instance profiles in the *Amazon EC2 User Guide*.
 *
 * For information about the number of instance profiles you can create, see IAM object
 * quotas in the *IAM User Guide*.
 */
export declare const createInstanceProfile: API.OperationMethod<CreateInstanceProfileRequest, CreateInstanceProfileResponse, CreateInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type CreateLoginProfileError = EntityAlreadyExistsException | LimitExceededException | NoSuchEntityException | PasswordPolicyViolationException | ServiceFailureException | CommonErrors;
/**
 * Creates a password for the specified IAM user. A password allows an IAM user to
 * access Amazon Web Services services through the Amazon Web Services Management Console.
 *
 * You can use the CLI, the Amazon Web Services API, or the **Users**
 * page in the IAM console to create a password for any IAM user. Use ChangePassword to update your own existing password in the **My Security Credentials** page in the Amazon Web Services Management Console.
 *
 * For more information about managing passwords, see Managing passwords in the
 * *IAM User Guide*.
 */
export declare const createLoginProfile: API.OperationMethod<CreateLoginProfileRequest, CreateLoginProfileResponse, CreateLoginProfileError, Credentials | HttpClient.HttpClient>;
export type CreateOpenIDConnectProviderError = ConcurrentModificationException | EntityAlreadyExistsException | InvalidInputException | LimitExceededException | OpenIdIdpCommunicationErrorException | ServiceFailureException | CommonErrors;
/**
 * Creates an IAM entity to describe an identity provider (IdP) that supports OpenID Connect (OIDC).
 *
 * The OIDC provider that you create with this operation can be used as a principal in a
 * role's trust policy. Such a policy establishes a trust relationship between Amazon Web Services and
 * the OIDC provider.
 *
 * If you are using an OIDC identity provider from Google, Facebook, or Amazon Cognito, you don't
 * need to create a separate IAM identity provider. These OIDC identity providers are
 * already built-in to Amazon Web Services and are available for your use. Instead, you can move directly
 * to creating new roles using your identity provider. To learn more, see Creating
 * a role for web identity or OpenID connect federation in the IAM
 * User Guide.
 *
 * When you create the IAM OIDC provider, you specify the following:
 *
 * - The URL of the OIDC identity provider (IdP) to trust
 *
 * - A list of client IDs (also known as audiences) that identify the application
 * or applications allowed to authenticate using the OIDC provider
 *
 * - A list of tags that are attached to the specified IAM OIDC provider
 *
 * - A list of thumbprints of one or more server certificates that the IdP
 * uses
 *
 * You get all of this information from the OIDC IdP you want to use to access
 * Amazon Web Services.
 *
 * Amazon Web Services secures communication with OIDC identity providers (IdPs) using our library of
 * trusted root certificate authorities (CAs) to verify the JSON Web Key Set (JWKS)
 * endpoint's TLS certificate. If your OIDC IdP relies on a certificate that is not signed
 * by one of these trusted CAs, only then we secure communication using the thumbprints set
 * in the IdP's configuration.
 *
 * The trust for the OIDC provider is derived from the IAM provider that this
 * operation creates. Therefore, it is best to limit access to the CreateOpenIDConnectProvider operation to highly privileged
 * users.
 */
export declare const createOpenIDConnectProvider: API.OperationMethod<CreateOpenIDConnectProviderRequest, CreateOpenIDConnectProviderResponse, CreateOpenIDConnectProviderError, Credentials | HttpClient.HttpClient>;
export type CreatePolicyError = ConcurrentModificationException | EntityAlreadyExistsException | InvalidInputException | LimitExceededException | MalformedPolicyDocumentException | ServiceFailureException | CommonErrors;
/**
 * Creates a new managed policy for your Amazon Web Services account.
 *
 * This operation creates a policy version with a version identifier of `v1`
 * and sets v1 as the policy's default version. For more information about policy versions,
 * see Versioning for managed policies in the
 * *IAM User Guide*.
 *
 * As a best practice, you can validate your IAM policies.
 * To learn more, see Validating IAM policies
 * in the *IAM User Guide*.
 *
 * For more information about managed policies in general, see Managed
 * policies and inline policies in the
 * *IAM User Guide*.
 */
export declare const createPolicy: API.OperationMethod<CreatePolicyRequest, CreatePolicyResponse, CreatePolicyError, Credentials | HttpClient.HttpClient>;
export type CreatePolicyVersionError = InvalidInputException | LimitExceededException | MalformedPolicyDocumentException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Creates a new version of the specified managed policy. To update a managed policy, you
 * create a new policy version. A managed policy can have up to five versions. If the
 * policy has five versions, you must delete an existing version using DeletePolicyVersion before you create a new version.
 *
 * Optionally, you can set the new version as the policy's default version. The default
 * version is the version that is in effect for the IAM users, groups, and roles to which
 * the policy is attached.
 *
 * For more information about managed policy versions, see Versioning for managed
 * policies in the *IAM User Guide*.
 */
export declare const createPolicyVersion: API.OperationMethod<CreatePolicyVersionRequest, CreatePolicyVersionResponse, CreatePolicyVersionError, Credentials | HttpClient.HttpClient>;
export type CreateRoleError = ConcurrentModificationException | EntityAlreadyExistsException | InvalidInputException | LimitExceededException | MalformedPolicyDocumentException | ServiceFailureException | CommonErrors;
/**
 * Creates a new role for your Amazon Web Services account.
 *
 * For more information about roles, see IAM roles in the
 * *IAM User Guide*. For information about quotas for role names
 * and the number of roles you can create, see IAM and STS quotas in the
 * *IAM User Guide*.
 */
export declare const createRole: API.OperationMethod<CreateRoleRequest, CreateRoleResponse, CreateRoleError, Credentials | HttpClient.HttpClient>;
export type CreateSAMLProviderError = ConcurrentModificationException | EntityAlreadyExistsException | InvalidInputException | LimitExceededException | ServiceFailureException | CommonErrors;
/**
 * Creates an IAM resource that describes an identity provider (IdP) that supports SAML
 * 2.0.
 *
 * The SAML provider resource that you create with this operation can be used as a
 * principal in an IAM role's trust policy. Such a policy can enable federated users who
 * sign in using the SAML IdP to assume the role. You can create an IAM role that
 * supports Web-based single sign-on (SSO) to the Amazon Web Services Management Console or one that supports API access
 * to Amazon Web Services.
 *
 * When you create the SAML provider resource, you upload a SAML metadata document that
 * you get from your IdP. That document includes the issuer's name, expiration information,
 * and keys that can be used to validate the SAML authentication response (assertions) that
 * the IdP sends. You must generate the metadata document using the identity management
 * software that is used as your organization's IdP.
 *
 * This operation requires Signature Version 4.
 *
 * For more information, see Enabling SAML 2.0
 * federated users to access the Amazon Web Services Management Console and About SAML 2.0-based
 * federation in the *IAM User Guide*.
 */
export declare const createSAMLProvider: API.OperationMethod<CreateSAMLProviderRequest, CreateSAMLProviderResponse, CreateSAMLProviderError, Credentials | HttpClient.HttpClient>;
export type CreateServiceLinkedRoleError = InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Creates an IAM role that is linked to a specific Amazon Web Services service. The service controls
 * the attached policies and when the role can be deleted. This helps ensure that the
 * service is not broken by an unexpectedly changed or deleted role, which could put your
 * Amazon Web Services resources into an unknown state. Allowing the service to control the role helps
 * improve service stability and proper cleanup when a service and its role are no longer
 * needed. For more information, see Using service-linked
 * roles in the *IAM User Guide*.
 *
 * To attach a policy to this service-linked role, you must make the request using the
 * Amazon Web Services service that depends on this role.
 */
export declare const createServiceLinkedRole: API.OperationMethod<CreateServiceLinkedRoleRequest, CreateServiceLinkedRoleResponse, CreateServiceLinkedRoleError, Credentials | HttpClient.HttpClient>;
export type CreateServiceSpecificCredentialError = LimitExceededException | NoSuchEntityException | ServiceNotSupportedException | CommonErrors;
/**
 * Generates a set of credentials consisting of a user name and password that can be used
 * to access the service specified in the request. These credentials are generated by
 * IAM, and can be used only for the specified service.
 *
 * You can have a maximum of two sets of service-specific credentials for each supported
 * service per user.
 *
 * You can reset the password to a new service-generated value by calling ResetServiceSpecificCredential.
 *
 * For more information about using service-specific credentials to authenticate to an
 * Amazon Web Services service, refer to the following docs:
 *
 * - For service-specific credentials with CodeCommit, refer to IAM credentials for CodeCommit: Git credentials, SSH keys, and Amazon Web Services access
 * keys in the *IAM User Guide*.
 *
 * - For service-specific credentials with Amazon Keyspaces (for Apache Cassandra), refer to Use IAM with
 * Amazon Keyspaces (for Apache Cassandra) in the
 * *IAM User Guide*.
 *
 * - For services that support long-term API keys, refer to API
 * keys for Amazon Web Services services in the
 * *IAM User Guide*.
 */
export declare const createServiceSpecificCredential: API.OperationMethod<CreateServiceSpecificCredentialRequest, CreateServiceSpecificCredentialResponse, CreateServiceSpecificCredentialError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = ConcurrentModificationException | EntityAlreadyExistsException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Creates a new IAM user for your Amazon Web Services account.
 *
 * For information about quotas for the number of IAM users you can create, see IAM and STS
 * quotas in the *IAM User Guide*.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest, CreateUserResponse, CreateUserError, Credentials | HttpClient.HttpClient>;
export type CreateVirtualMFADeviceError = ConcurrentModificationException | EntityAlreadyExistsException | InvalidInputException | LimitExceededException | ServiceFailureException | CommonErrors;
/**
 * Creates a new virtual MFA device for the Amazon Web Services account. After creating the virtual
 * MFA, use EnableMFADevice to
 * attach the MFA device to an IAM user. For more information about creating and working
 * with virtual MFA devices, see Using a virtual MFA device in the
 * *IAM User Guide*.
 *
 * For information about the maximum number of MFA devices you can create, see IAM and STS
 * quotas in the *IAM User Guide*.
 *
 * The seed information contained in the QR code and the Base32 string should be
 * treated like any other secret access information. In other words, protect the seed
 * information as you would your Amazon Web Services access keys or your passwords. After you
 * provision your virtual device, you should ensure that the information is destroyed
 * following secure procedures.
 */
export declare const createVirtualMFADevice: API.OperationMethod<CreateVirtualMFADeviceRequest, CreateVirtualMFADeviceResponse, CreateVirtualMFADeviceError, Credentials | HttpClient.HttpClient>;
export type DeactivateMFADeviceError = ConcurrentModificationException | EntityTemporarilyUnmodifiableException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deactivates the specified MFA device and removes it from association with the user
 * name for which it was originally enabled.
 *
 * For more information about creating and working with virtual MFA devices, see Enabling a virtual
 * multi-factor authentication (MFA) device in the
 * *IAM User Guide*.
 */
export declare const deactivateMFADevice: API.OperationMethod<DeactivateMFADeviceRequest, DeactivateMFADeviceResponse, DeactivateMFADeviceError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessKeyError = LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes the access key pair associated with the specified IAM user.
 *
 * If you do not specify a user name, IAM determines the user name implicitly based on
 * the Amazon Web Services access key ID signing the request. This operation works for access keys under
 * the Amazon Web Services account. Consequently, you can use this operation to manage Amazon Web Services account root
 * user credentials even if the Amazon Web Services account has no associated users.
 */
export declare const deleteAccessKey: API.OperationMethod<DeleteAccessKeyRequest, DeleteAccessKeyResponse, DeleteAccessKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountAliasError = ConcurrentModificationException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes the specified Amazon Web Services account alias. For information about using an Amazon Web Services
 * account alias, see Creating, deleting, and
 * listing an Amazon Web Services account alias in the Amazon Web Services Sign-In User
 * Guide.
 */
export declare const deleteAccountAlias: API.OperationMethod<DeleteAccountAliasRequest, DeleteAccountAliasResponse, DeleteAccountAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountPasswordPolicyError = LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes the password policy for the Amazon Web Services account. There are no parameters.
 */
export declare const deleteAccountPasswordPolicy: API.OperationMethod<DeleteAccountPasswordPolicyRequest, DeleteAccountPasswordPolicyResponse, DeleteAccountPasswordPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = DeleteConflictException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes the specified IAM group. The group must not contain any users or have any
 * attached policies.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest, DeleteGroupResponse, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupPolicyError = LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes the specified inline policy that is embedded in the specified IAM
 * group.
 *
 * A group can also have managed policies attached to it. To detach a managed policy from
 * a group, use DetachGroupPolicy.
 * For more information about policies, refer to Managed policies and inline
 * policies in the *IAM User Guide*.
 */
export declare const deleteGroupPolicy: API.OperationMethod<DeleteGroupPolicyRequest, DeleteGroupPolicyResponse, DeleteGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteInstanceProfileError = DeleteConflictException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes the specified instance profile. The instance profile must not have an
 * associated role.
 *
 * Make sure that you do not have any Amazon EC2 instances running with the instance
 * profile you are about to delete. Deleting a role or instance profile that is
 * associated with a running instance will break any applications running on the
 * instance.
 *
 * For more information about instance profiles, see Using
 * instance profiles in the *IAM User Guide*.
 */
export declare const deleteInstanceProfile: API.OperationMethod<DeleteInstanceProfileRequest, DeleteInstanceProfileResponse, DeleteInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteLoginProfileError = EntityTemporarilyUnmodifiableException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes the password for the specified IAM user or root user, For more information, see
 * Managing
 * passwords for IAM users.
 *
 * You can use the CLI, the Amazon Web Services API, or the **Users**
 * page in the IAM console to delete a password for any IAM user. You can use ChangePassword to update, but not delete, your own password in the
 * **My Security Credentials** page in the
 * Amazon Web Services Management Console.
 *
 * Deleting a user's password does not prevent a user from accessing Amazon Web Services through
 * the command line interface or the API. To prevent all user access, you must also
 * either make any access keys inactive or delete them. For more information about
 * making keys inactive or deleting them, see UpdateAccessKey
 * and DeleteAccessKey.
 */
export declare const deleteLoginProfile: API.OperationMethod<DeleteLoginProfileRequest, DeleteLoginProfileResponse, DeleteLoginProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteOpenIDConnectProviderError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes an OpenID Connect identity provider (IdP) resource object in IAM.
 *
 * Deleting an IAM OIDC provider resource does not update any roles that reference the
 * provider as a principal in their trust policies. Any attempt to assume a role that
 * references a deleted provider fails.
 *
 * This operation is idempotent; it does not fail or return an error if you call the
 * operation for a provider that does not exist.
 */
export declare const deleteOpenIDConnectProvider: API.OperationMethod<DeleteOpenIDConnectProviderRequest, DeleteOpenIDConnectProviderResponse, DeleteOpenIDConnectProviderError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = DeleteConflictException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes the specified managed policy.
 *
 * Before you can delete a managed policy, you must first detach the policy from all
 * users, groups, and roles that it is attached to. In addition, you must delete all the
 * policy's versions. The following steps describe the process for deleting a managed
 * policy:
 *
 * - Detach the policy from all users, groups, and roles that the policy is
 * attached to, using DetachUserPolicy, DetachGroupPolicy, or DetachRolePolicy. To list all the users, groups, and roles that a
 * policy is attached to, use ListEntitiesForPolicy.
 *
 * - Delete all versions of the policy using DeletePolicyVersion. To list the policy's versions, use ListPolicyVersions. You cannot use DeletePolicyVersion to delete the version that is marked as the
 * default version. You delete the policy's default version in the next step of the
 * process.
 *
 * - Delete the policy (this automatically deletes the policy's default version)
 * using this operation.
 *
 * For information about managed policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest, DeletePolicyResponse, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyVersionError = DeleteConflictException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes the specified version from the specified managed policy.
 *
 * You cannot delete the default version from a policy using this operation. To delete
 * the default version from a policy, use DeletePolicy. To find
 * out which version of a policy is marked as the default version, use ListPolicyVersions.
 *
 * For information about versions for managed policies, see Versioning for managed
 * policies in the *IAM User Guide*.
 */
export declare const deletePolicyVersion: API.OperationMethod<DeletePolicyVersionRequest, DeletePolicyVersionResponse, DeletePolicyVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteRoleError = ConcurrentModificationException | DeleteConflictException | LimitExceededException | NoSuchEntityException | ServiceFailureException | UnmodifiableEntityException | CommonErrors;
/**
 * Deletes the specified role. Unlike the Amazon Web Services Management Console, when you delete a role
 * programmatically, you must delete the items attached to the role manually, or the
 * deletion fails. For more information, see Deleting an IAM role. Before attempting to delete a role, remove the
 * following attached items:
 *
 * - Inline policies (DeleteRolePolicy)
 *
 * - Attached managed policies (DetachRolePolicy)
 *
 * - Instance profile (RemoveRoleFromInstanceProfile)
 *
 * - Optional – Delete instance profile after detaching from role for
 * resource clean up (DeleteInstanceProfile)
 *
 * Make sure that you do not have any Amazon EC2 instances running with the role you are
 * about to delete. Deleting a role or instance profile that is associated with a
 * running instance will break any applications running on the instance.
 */
export declare const deleteRole: API.OperationMethod<DeleteRoleRequest, DeleteRoleResponse, DeleteRoleError, Credentials | HttpClient.HttpClient>;
export type DeleteRolePermissionsBoundaryError = NoSuchEntityException | ServiceFailureException | UnmodifiableEntityException | CommonErrors;
/**
 * Deletes the permissions boundary for the specified IAM role.
 *
 * You cannot set the boundary for a service-linked role.
 *
 * Deleting the permissions boundary for a role might increase its permissions. For
 * example, it might allow anyone who assumes the role to perform all the actions
 * granted in its permissions policies.
 */
export declare const deleteRolePermissionsBoundary: API.OperationMethod<DeleteRolePermissionsBoundaryRequest, DeleteRolePermissionsBoundaryResponse, DeleteRolePermissionsBoundaryError, Credentials | HttpClient.HttpClient>;
export type DeleteRolePolicyError = LimitExceededException | NoSuchEntityException | ServiceFailureException | UnmodifiableEntityException | CommonErrors;
/**
 * Deletes the specified inline policy that is embedded in the specified IAM
 * role.
 *
 * A role can also have managed policies attached to it. To detach a managed policy from
 * a role, use DetachRolePolicy.
 * For more information about policies, refer to Managed policies and inline
 * policies in the *IAM User Guide*.
 */
export declare const deleteRolePolicy: API.OperationMethod<DeleteRolePolicyRequest, DeleteRolePolicyResponse, DeleteRolePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSAMLProviderError = InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes a SAML provider resource in IAM.
 *
 * Deleting the provider resource from IAM does not update any roles that reference the
 * SAML provider resource's ARN as a principal in their trust policies. Any attempt to
 * assume a role that references a non-existent provider resource ARN fails.
 *
 * This operation requires Signature Version 4.
 */
export declare const deleteSAMLProvider: API.OperationMethod<DeleteSAMLProviderRequest, DeleteSAMLProviderResponse, DeleteSAMLProviderError, Credentials | HttpClient.HttpClient>;
export type DeleteServerCertificateError = DeleteConflictException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes the specified server certificate.
 *
 * For more information about working with server certificates, see Working
 * with server certificates in the *IAM User Guide*. This
 * topic also includes a list of Amazon Web Services services that can use the server certificates that
 * you manage with IAM.
 *
 * If you are using a server certificate with Elastic Load Balancing, deleting the
 * certificate could have implications for your application. If Elastic Load Balancing
 * doesn't detect the deletion of bound certificates, it may continue to use the
 * certificates. This could cause Elastic Load Balancing to stop accepting traffic. We
 * recommend that you remove the reference to the certificate from Elastic Load
 * Balancing before using this command to delete the certificate. For more information,
 * see DeleteLoadBalancerListeners in the Elastic Load Balancing API
 * Reference.
 */
export declare const deleteServerCertificate: API.OperationMethod<DeleteServerCertificateRequest, DeleteServerCertificateResponse, DeleteServerCertificateError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceLinkedRoleError = LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Submits a service-linked role deletion request and returns a
 * `DeletionTaskId`, which you can use to check the status of the deletion.
 * Before you call this operation, confirm that the role has no active sessions and that
 * any resources used by the role in the linked service are deleted. If you call this
 * operation more than once for the same service-linked role and an earlier deletion task
 * is not complete, then the `DeletionTaskId` of the earlier request is
 * returned.
 *
 * If you submit a deletion request for a service-linked role whose linked service is
 * still accessing a resource, then the deletion task fails. If it fails, the GetServiceLinkedRoleDeletionStatus operation returns the reason for the
 * failure, usually including the resources that must be deleted. To delete the
 * service-linked role, you must first remove those resources from the linked service and
 * then submit the deletion request again. Resources are specific to the service that is
 * linked to the role. For more information about removing resources from a service, see
 * the Amazon Web Services documentation for your
 * service.
 *
 * For more information about service-linked roles, see Roles terms and concepts: Amazon Web Services service-linked role in the
 * *IAM User Guide*.
 */
export declare const deleteServiceLinkedRole: API.OperationMethod<DeleteServiceLinkedRoleRequest, DeleteServiceLinkedRoleResponse, DeleteServiceLinkedRoleError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceSpecificCredentialError = NoSuchEntityException | CommonErrors;
/**
 * Deletes the specified service-specific credential.
 */
export declare const deleteServiceSpecificCredential: API.OperationMethod<DeleteServiceSpecificCredentialRequest, DeleteServiceSpecificCredentialResponse, DeleteServiceSpecificCredentialError, Credentials | HttpClient.HttpClient>;
export type DeleteSigningCertificateError = ConcurrentModificationException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes a signing certificate associated with the specified IAM user.
 *
 * If you do not specify a user name, IAM determines the user name implicitly based on
 * the Amazon Web Services access key ID signing the request. This operation works for access keys under
 * the Amazon Web Services account. Consequently, you can use this operation to manage Amazon Web Services account root
 * user credentials even if the Amazon Web Services account has no associated IAM users.
 */
export declare const deleteSigningCertificate: API.OperationMethod<DeleteSigningCertificateRequest, DeleteSigningCertificateResponse, DeleteSigningCertificateError, Credentials | HttpClient.HttpClient>;
export type DeleteSSHPublicKeyError = NoSuchEntityException | CommonErrors;
/**
 * Deletes the specified SSH public key.
 *
 * The SSH public key deleted by this operation is used only for authenticating the
 * associated IAM user to an CodeCommit repository. For more information about using SSH keys
 * to authenticate to an CodeCommit repository, see Set up CodeCommit for
 * SSH connections in the *CodeCommit User Guide*.
 */
export declare const deleteSSHPublicKey: API.OperationMethod<DeleteSSHPublicKeyRequest, DeleteSSHPublicKeyResponse, DeleteSSHPublicKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = ConcurrentModificationException | DeleteConflictException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes the specified IAM user. Unlike the Amazon Web Services Management Console, when you delete a user
 * programmatically, you must delete the items attached to the user manually, or the
 * deletion fails. For more information, see Deleting an IAM
 * user. Before attempting to delete a user, remove the following items:
 *
 * - Password (DeleteLoginProfile)
 *
 * - Access keys (DeleteAccessKey)
 *
 * - Signing certificate (DeleteSigningCertificate)
 *
 * - SSH public key (DeleteSSHPublicKey)
 *
 * - Git credentials (DeleteServiceSpecificCredential)
 *
 * - Multi-factor authentication (MFA) device (DeactivateMFADevice, DeleteVirtualMFADevice)
 *
 * - Inline policies (DeleteUserPolicy)
 *
 * - Attached managed policies (DetachUserPolicy)
 *
 * - Group memberships (RemoveUserFromGroup)
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DeleteUserPermissionsBoundaryError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes the permissions boundary for the specified IAM user.
 *
 * Deleting the permissions boundary for a user might increase its permissions by
 * allowing the user to perform all the actions granted in its permissions policies.
 */
export declare const deleteUserPermissionsBoundary: API.OperationMethod<DeleteUserPermissionsBoundaryRequest, DeleteUserPermissionsBoundaryResponse, DeleteUserPermissionsBoundaryError, Credentials | HttpClient.HttpClient>;
export type DeleteUserPolicyError = LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes the specified inline policy that is embedded in the specified IAM
 * user.
 *
 * A user can also have managed policies attached to it. To detach a managed policy from
 * a user, use DetachUserPolicy.
 * For more information about policies, refer to Managed policies and inline
 * policies in the *IAM User Guide*.
 */
export declare const deleteUserPolicy: API.OperationMethod<DeleteUserPolicyRequest, DeleteUserPolicyResponse, DeleteUserPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteVirtualMFADeviceError = ConcurrentModificationException | DeleteConflictException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Deletes a virtual MFA device.
 *
 * You must deactivate a user's virtual MFA device before you can delete it. For
 * information about deactivating MFA devices, see DeactivateMFADevice.
 */
export declare const deleteVirtualMFADevice: API.OperationMethod<DeleteVirtualMFADeviceRequest, DeleteVirtualMFADeviceResponse, DeleteVirtualMFADeviceError, Credentials | HttpClient.HttpClient>;
export type DetachGroupPolicyError = InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Removes the specified managed policy from the specified IAM group.
 *
 * A group can also have inline policies embedded with it. To delete an inline policy,
 * use DeleteGroupPolicy. For information about policies, see Managed
 * policies and inline policies in the
 * *IAM User Guide*.
 */
export declare const detachGroupPolicy: API.OperationMethod<DetachGroupPolicyRequest, DetachGroupPolicyResponse, DetachGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type DetachRolePolicyError = InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | UnmodifiableEntityException | CommonErrors;
/**
 * Removes the specified managed policy from the specified role.
 *
 * A role can also have inline policies embedded with it. To delete an inline policy, use
 * DeleteRolePolicy. For information about policies, see Managed
 * policies and inline policies in the
 * *IAM User Guide*.
 */
export declare const detachRolePolicy: API.OperationMethod<DetachRolePolicyRequest, DetachRolePolicyResponse, DetachRolePolicyError, Credentials | HttpClient.HttpClient>;
export type DetachUserPolicyError = InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Removes the specified managed policy from the specified user.
 *
 * A user can also have inline policies embedded with it. To delete an inline policy, use
 * DeleteUserPolicy. For information about policies, see Managed
 * policies and inline policies in the
 * *IAM User Guide*.
 */
export declare const detachUserPolicy: API.OperationMethod<DetachUserPolicyRequest, DetachUserPolicyResponse, DetachUserPolicyError, Credentials | HttpClient.HttpClient>;
export type DisableOrganizationsRootCredentialsManagementError = AccountNotManagementOrDelegatedAdministratorException | OrganizationNotFoundException | OrganizationNotInAllFeaturesModeException | ServiceAccessNotEnabledException | CommonErrors;
/**
 * Disables the management of privileged root user credentials across member accounts in
 * your organization. When you disable this feature, the management account and the
 * delegated administrator for IAM can no longer manage root user credentials for member
 * accounts in your organization.
 */
export declare const disableOrganizationsRootCredentialsManagement: API.OperationMethod<DisableOrganizationsRootCredentialsManagementRequest, DisableOrganizationsRootCredentialsManagementResponse, DisableOrganizationsRootCredentialsManagementError, Credentials | HttpClient.HttpClient>;
export type DisableOrganizationsRootSessionsError = AccountNotManagementOrDelegatedAdministratorException | OrganizationNotFoundException | OrganizationNotInAllFeaturesModeException | ServiceAccessNotEnabledException | CommonErrors;
/**
 * Disables root user sessions for privileged tasks across member accounts in your
 * organization. When you disable this feature, the management account and the delegated
 * administrator for IAM can no longer perform privileged tasks on member accounts in
 * your organization.
 */
export declare const disableOrganizationsRootSessions: API.OperationMethod<DisableOrganizationsRootSessionsRequest, DisableOrganizationsRootSessionsResponse, DisableOrganizationsRootSessionsError, Credentials | HttpClient.HttpClient>;
export type DisableOutboundWebIdentityFederationError = FeatureDisabledException | CommonErrors;
/**
 * Disables the outbound identity federation feature for your Amazon Web Services account. When disabled, IAM principals in the account cannot
 * use the `GetWebIdentityToken` API to obtain JSON Web Tokens (JWTs) for authentication with external services. This operation
 * does not affect tokens that were issued before the feature was disabled.
 */
export declare const disableOutboundWebIdentityFederation: API.OperationMethod<DisableOutboundWebIdentityFederationRequest, DisableOutboundWebIdentityFederationResponse, DisableOutboundWebIdentityFederationError, Credentials | HttpClient.HttpClient>;
export type EnableMFADeviceError = ConcurrentModificationException | EntityAlreadyExistsException | EntityTemporarilyUnmodifiableException | InvalidAuthenticationCodeException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Enables the specified MFA device and associates it with the specified IAM user. When
 * enabled, the MFA device is required for every subsequent login by the IAM user
 * associated with the device.
 */
export declare const enableMFADevice: API.OperationMethod<EnableMFADeviceRequest, EnableMFADeviceResponse, EnableMFADeviceError, Credentials | HttpClient.HttpClient>;
export type EnableOrganizationsRootCredentialsManagementError = AccountNotManagementOrDelegatedAdministratorException | CallerIsNotManagementAccountException | OrganizationNotFoundException | OrganizationNotInAllFeaturesModeException | ServiceAccessNotEnabledException | CommonErrors;
/**
 * Enables the management of privileged root user credentials across member accounts in your
 * organization. When you enable root credentials management for centralized root access, the management account and the delegated
 * administrator for IAM can manage root user credentials for member accounts in your
 * organization.
 *
 * Before you enable centralized root access, you must have an account configured with
 * the following settings:
 *
 * - You must manage your Amazon Web Services accounts in Organizations.
 *
 * - Enable trusted access for Identity and Access Management in Organizations. For details, see
 * IAM and Organizations in the Organizations User
 * Guide.
 */
export declare const enableOrganizationsRootCredentialsManagement: API.OperationMethod<EnableOrganizationsRootCredentialsManagementRequest, EnableOrganizationsRootCredentialsManagementResponse, EnableOrganizationsRootCredentialsManagementError, Credentials | HttpClient.HttpClient>;
export type EnableOrganizationsRootSessionsError = AccountNotManagementOrDelegatedAdministratorException | CallerIsNotManagementAccountException | OrganizationNotFoundException | OrganizationNotInAllFeaturesModeException | ServiceAccessNotEnabledException | CommonErrors;
/**
 * Allows the management account or delegated administrator to perform privileged tasks
 * on member accounts in your organization. For more information, see Centrally manage root access for member accounts in the Identity and Access Management
 * User Guide.
 *
 * Before you enable this feature, you must have an account configured with the following
 * settings:
 *
 * - You must manage your Amazon Web Services accounts in Organizations.
 *
 * - Enable trusted access for Identity and Access Management in Organizations. For details, see
 * IAM and Organizations in the Organizations User
 * Guide.
 */
export declare const enableOrganizationsRootSessions: API.OperationMethod<EnableOrganizationsRootSessionsRequest, EnableOrganizationsRootSessionsResponse, EnableOrganizationsRootSessionsError, Credentials | HttpClient.HttpClient>;
export type EnableOutboundWebIdentityFederationError = FeatureEnabledException | CommonErrors;
/**
 * Enables the outbound identity federation feature for your Amazon Web Services account. When enabled, IAM principals in your account
 * can use the `GetWebIdentityToken` API to obtain JSON Web Tokens (JWTs) for secure authentication with external services.
 * This operation also generates a unique issuer URL for your Amazon Web Services account.
 */
export declare const enableOutboundWebIdentityFederation: API.OperationMethod<EnableOutboundWebIdentityFederationRequest, EnableOutboundWebIdentityFederationResponse, EnableOutboundWebIdentityFederationError, Credentials | HttpClient.HttpClient>;
export type GenerateCredentialReportError = LimitExceededException | ServiceFailureException | CommonErrors;
/**
 * Generates a credential report for the Amazon Web Services account. For more information about the
 * credential report, see Getting credential reports in
 * the *IAM User Guide*.
 */
export declare const generateCredentialReport: API.OperationMethod<GenerateCredentialReportRequest, GenerateCredentialReportResponse, GenerateCredentialReportError, Credentials | HttpClient.HttpClient>;
export type GenerateOrganizationsAccessReportError = ReportGenerationLimitExceededException | CommonErrors;
/**
 * Generates a report for service last accessed data for Organizations. You can generate a
 * report for any entities (organization root, organizational unit, or account) or policies
 * in your organization.
 *
 * To call this operation, you must be signed in using your Organizations management account
 * credentials. You can use your long-term IAM user or root user credentials, or temporary
 * credentials from assuming an IAM role. SCPs must be enabled for your organization
 * root. You must have the required IAM and Organizations permissions. For more information, see
 * Refining permissions using service last accessed data in the
 * *IAM User Guide*.
 *
 * You can generate a service last accessed data report for entities by specifying only
 * the entity's path. This data includes a list of services that are allowed by any service
 * control policies (SCPs) that apply to the entity.
 *
 * You can generate a service last accessed data report for a policy by specifying an
 * entity's path and an optional Organizations policy ID. This data includes a list of services that
 * are allowed by the specified SCP.
 *
 * For each service in both report types, the data includes the most recent account
 * activity that the policy allows to account principals in the entity or the entity's
 * children. For important information about the data, reporting period, permissions
 * required, troubleshooting, and supported Regions see Reducing permissions using
 * service last accessed data in the
 * *IAM User Guide*.
 *
 * The data includes all attempts to access Amazon Web Services, not just the successful ones. This
 * includes all attempts that were made using the Amazon Web Services Management Console, the Amazon Web Services API through any
 * of the SDKs, or any of the command line tools. An unexpected entry in the service
 * last accessed data does not mean that an account has been compromised, because the
 * request might have been denied. Refer to your CloudTrail logs as the authoritative
 * source for information about all API calls and whether they were successful or
 * denied access. For more information, see Logging IAM events with
 * CloudTrail in the *IAM User Guide*.
 *
 * This operation returns a `JobId`. Use this parameter in the
 * GetOrganizationsAccessReport
 * operation to check the status of
 * the report generation. To check the status of this request, use the `JobId`
 * parameter in the
 * GetOrganizationsAccessReport
 * operation and test the
 * `JobStatus` response parameter. When the job is complete, you can
 * retrieve the report.
 *
 * To generate a service last accessed data report for entities, specify an entity path
 * without specifying the optional Organizations policy ID. The type of entity that you specify
 * determines the data returned in the report.
 *
 * - **Root** – When you specify the
 * organizations root as the entity, the resulting report lists all of the services
 * allowed by SCPs that are attached to your root. For each service, the report
 * includes data for all accounts in your organization except the
 * management account, because the management account is not limited by SCPs.
 *
 * - **OU** – When you specify an
 * organizational unit (OU) as the entity, the resulting report lists all of the
 * services allowed by SCPs that are attached to the OU and its parents. For each
 * service, the report includes data for all accounts in the OU or its children.
 * This data excludes the management account, because the management account is not
 * limited by SCPs.
 *
 * - **management account** – When you specify the
 * management account, the resulting report lists all Amazon Web Services services, because the
 * management account is not limited by SCPs. For each service, the report includes
 * data for only the management account.
 *
 * - **Account** – When you specify another
 * account as the entity, the resulting report lists all of the services allowed by
 * SCPs that are attached to the account and its parents. For each service, the
 * report includes data for only the specified account.
 *
 * To generate a service last accessed data report for policies, specify an entity path
 * and the optional Organizations policy ID. The type of entity that you specify determines the data
 * returned for each service.
 *
 * - **Root** – When you specify the root
 * entity and a policy ID, the resulting report lists all of the services that are
 * allowed by the specified SCP. For each service, the report includes data for all
 * accounts in your organization to which the SCP applies. This data excludes the
 * management account, because the management account is not limited by SCPs. If the
 * SCP is not attached to any entities in the organization, then the report will
 * return a list of services with no data.
 *
 * - **OU** – When you specify an OU entity and
 * a policy ID, the resulting report lists all of the services that are allowed by
 * the specified SCP. For each service, the report includes data for all accounts
 * in the OU or its children to which the SCP applies. This means that other
 * accounts outside the OU that are affected by the SCP might not be included in
 * the data. This data excludes the management account, because the
 * management account is not limited by SCPs. If the SCP is not attached to the OU
 * or one of its children, the report will return a list of services with no
 * data.
 *
 * - **management account** – When you specify the
 * management account, the resulting report lists all Amazon Web Services services, because the
 * management account is not limited by SCPs. If you specify a policy ID in the CLI
 * or API, the policy is ignored. For each service, the report includes data for
 * only the management account.
 *
 * - **Account** – When you specify another
 * account entity and a policy ID, the resulting report lists all of the services
 * that are allowed by the specified SCP. For each service, the report includes
 * data for only the specified account. This means that other accounts in the
 * organization that are affected by the SCP might not be included in the data. If
 * the SCP is not attached to the account, the report will return a list of
 * services with no data.
 *
 * Service last accessed data does not use other policy types when determining
 * whether a principal could access a service. These other policy types include
 * identity-based policies, resource-based policies, access control lists, IAM
 * permissions boundaries, and STS assume role policies. It only applies SCP logic.
 * For more about the evaluation of policy types, see Evaluating policies in the
 * *IAM User Guide*.
 *
 * For more information about service last accessed data, see Reducing policy scope by
 * viewing user activity in the *IAM User Guide*.
 */
export declare const generateOrganizationsAccessReport: API.OperationMethod<GenerateOrganizationsAccessReportRequest, GenerateOrganizationsAccessReportResponse, GenerateOrganizationsAccessReportError, Credentials | HttpClient.HttpClient>;
export type GenerateServiceLastAccessedDetailsError = InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Generates a report that includes details about when an IAM resource (user, group,
 * role, or policy) was last used in an attempt to access Amazon Web Services services. Recent activity
 * usually appears within four hours. IAM reports activity for at least the last 400
 * days, or less if your Region began supporting this feature within the last year. For
 * more information, see Regions where data is tracked. For more information about services and
 * actions for which action last accessed information is displayed, see IAM
 * action last accessed information services and actions.
 *
 * The service last accessed data includes all attempts to access an Amazon Web Services API, not
 * just the successful ones. This includes all attempts that were made using the
 * Amazon Web Services Management Console, the Amazon Web Services API through any of the SDKs, or any of the command line tools.
 * An unexpected entry in the service last accessed data does not mean that your
 * account has been compromised, because the request might have been denied. Refer to
 * your CloudTrail logs as the authoritative source for information about all API calls
 * and whether they were successful or denied access. For more information, see Logging
 * IAM events with CloudTrail in the
 * *IAM User Guide*.
 *
 * The `GenerateServiceLastAccessedDetails` operation returns a
 * `JobId`. Use this parameter in the following operations to retrieve the
 * following details from your report:
 *
 * - GetServiceLastAccessedDetails – Use this operation for
 * users, groups, roles, or policies to list every Amazon Web Services service that the resource
 * could access using permissions policies. For each service, the response includes
 * information about the most recent access attempt.
 *
 * The `JobId` returned by
 * `GenerateServiceLastAccessedDetail` must be used by the same role
 * within a session, or by the same user when used to call
 * `GetServiceLastAccessedDetail`.
 *
 * - GetServiceLastAccessedDetailsWithEntities – Use this
 * operation for groups and policies to list information about the associated
 * entities (users or roles) that attempted to access a specific Amazon Web Services service.
 *
 * To check the status of the `GenerateServiceLastAccessedDetails` request,
 * use the `JobId` parameter in the same operations and test the
 * `JobStatus` response parameter.
 *
 * For additional information about the permissions policies that allow an identity
 * (user, group, or role) to access specific services, use the ListPoliciesGrantingServiceAccess operation.
 *
 * Service last accessed data does not use other policy types when determining
 * whether a resource could access a service. These other policy types include
 * resource-based policies, access control lists, Organizations policies, IAM permissions
 * boundaries, and STS assume role policies. It only applies permissions policy
 * logic. For more about the evaluation of policy types, see Evaluating policies in the
 * *IAM User Guide*.
 *
 * For more information about service and action last accessed data, see Reducing permissions using service last accessed data in the
 * *IAM User Guide*.
 */
export declare const generateServiceLastAccessedDetails: API.OperationMethod<GenerateServiceLastAccessedDetailsRequest, GenerateServiceLastAccessedDetailsResponse, GenerateServiceLastAccessedDetailsError, Credentials | HttpClient.HttpClient>;
export type GetAccessKeyLastUsedError = CommonErrors;
/**
 * Retrieves information about when the specified access key was last used. The
 * information includes the date and time of last use, along with the Amazon Web Services service and
 * Region that were specified in the last request made with that key.
 */
export declare const getAccessKeyLastUsed: API.OperationMethod<GetAccessKeyLastUsedRequest, GetAccessKeyLastUsedResponse, GetAccessKeyLastUsedError, Credentials | HttpClient.HttpClient>;
export type GetAccountAuthorizationDetailsError = ServiceFailureException | CommonErrors;
/**
 * Retrieves information about all IAM users, groups, roles, and policies in your Amazon Web Services
 * account, including their relationships to one another. Use this operation to obtain a
 * snapshot of the configuration of IAM permissions (users, groups, roles, and policies)
 * in your account.
 *
 * Policies returned by this operation are URL-encoded compliant
 * with RFC 3986. You can use a URL
 * decoding method to convert the policy back to plain JSON text. For example, if you use Java, you
 * can use the `decode` method of the `java.net.URLDecoder` utility class in
 * the Java SDK. Other languages and SDKs provide similar functionality, and some SDKs do this decoding
 * automatically.
 *
 * You can optionally filter the results using the `Filter` parameter. You can
 * paginate the results using the `MaxItems` and `Marker`
 * parameters.
 */
export declare const getAccountAuthorizationDetails: API.PaginatedOperationMethod<GetAccountAuthorizationDetailsRequest, GetAccountAuthorizationDetailsResponse, GetAccountAuthorizationDetailsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetAccountPasswordPolicyError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves the password policy for the Amazon Web Services account. This tells you the complexity
 * requirements and mandatory rotation periods for the IAM user passwords in your account.
 * For more information about using a password policy, see Managing an IAM password
 * policy.
 */
export declare const getAccountPasswordPolicy: API.OperationMethod<GetAccountPasswordPolicyRequest, GetAccountPasswordPolicyResponse, GetAccountPasswordPolicyError, Credentials | HttpClient.HttpClient>;
export type GetAccountPropertiesError = InvalidInputException | ServiceFailureException | CommonErrors;
/**
 * Retrieves the account-level properties for the caller's Amazon Web Services account. Account
 * properties are configuration settings that control account-wide IAM features such as
 * Role Manager.
 *
 * The service returns properties as key-value pairs in
 * `Namespace/PropertyName` format. Each namespace groups related
 * configuration settings. Use PutAccountProperties to modify these properties.
 */
export declare const getAccountProperties: API.OperationMethod<GetAccountPropertiesRequest, GetAccountPropertiesResponse, GetAccountPropertiesError, Credentials | HttpClient.HttpClient>;
export type GetAccountSummaryError = ServiceFailureException | CommonErrors;
/**
 * Retrieves information about IAM entity usage and IAM quotas in the Amazon Web Services
 * account.
 *
 * For information about IAM quotas, see IAM and STS quotas in the
 * *IAM User Guide*.
 */
export declare const getAccountSummary: API.OperationMethod<GetAccountSummaryRequest, GetAccountSummaryResponse, GetAccountSummaryError, Credentials | HttpClient.HttpClient>;
export type GetContextKeysForCustomPolicyError = InvalidInputException | CommonErrors;
/**
 * Gets a list of all of the context keys referenced in the input policies. The policies
 * are supplied as a list of one or more strings. To get the context keys from policies
 * associated with an IAM user, group, or role, use GetContextKeysForPrincipalPolicy.
 *
 * Context keys are variables maintained by Amazon Web Services and its services that provide details
 * about the context of an API query request. Context keys can be evaluated by testing
 * against a value specified in an IAM policy. Use
 * `GetContextKeysForCustomPolicy` to understand what key names and values
 * you must supply when you call SimulateCustomPolicy. Note that all parameters are shown in unencoded form
 * here for clarity but must be URL encoded to be included as a part of a real HTML
 * request.
 */
export declare const getContextKeysForCustomPolicy: API.OperationMethod<GetContextKeysForCustomPolicyRequest, GetContextKeysForPolicyResponse, GetContextKeysForCustomPolicyError, Credentials | HttpClient.HttpClient>;
export type GetContextKeysForPrincipalPolicyError = InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Gets a list of all of the context keys referenced in all the IAM policies that are
 * attached to the specified IAM entity. The entity can be an IAM user, group, or role.
 * If you specify a user, then the request also includes all of the policies attached to
 * groups that the user is a member of.
 *
 * You can optionally include a list of one or more additional policies, specified as
 * strings. If you want to include *only* a list of policies by string,
 * use GetContextKeysForCustomPolicy instead.
 *
 * **Note:** This operation discloses information about the
 * permissions granted to other users. If you do not want users to see other user's
 * permissions, then consider allowing them to use GetContextKeysForCustomPolicy instead.
 *
 * Context keys are variables maintained by Amazon Web Services and its services that provide details
 * about the context of an API query request. Context keys can be evaluated by testing
 * against a value in an IAM policy. Use GetContextKeysForPrincipalPolicy to understand what key names and values
 * you must supply when you call SimulatePrincipalPolicy. This operation doesn't return context keys
 * referenced by service control policies (SCPs). Only context keys referenced by the
 * identity-based policies attached to the specified entity, and any additional policies
 * that you provide, are included.
 */
export declare const getContextKeysForPrincipalPolicy: API.OperationMethod<GetContextKeysForPrincipalPolicyRequest, GetContextKeysForPolicyResponse, GetContextKeysForPrincipalPolicyError, Credentials | HttpClient.HttpClient>;
export type GetCredentialReportError = CredentialReportExpiredException | CredentialReportNotPresentException | CredentialReportNotReadyException | ServiceFailureException | CommonErrors;
/**
 * Retrieves a credential report for the Amazon Web Services account. For more information about the
 * credential report, see Getting credential reports in
 * the *IAM User Guide*.
 */
export declare const getCredentialReport: API.OperationMethod<GetCredentialReportRequest, GetCredentialReportResponse, GetCredentialReportError, Credentials | HttpClient.HttpClient>;
export type GetDelegationRequestError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves information about a specific delegation request.
 *
 * If a delegation request has no owner or owner account, `GetDelegationRequest` for that delegation request can be called by any account.
 * If the owner account is assigned but there is
 * no owner id, only identities within that owner account can call `GetDelegationRequest`
 * for the delegation request. Once the delegation request is fully owned, the owner of the request gets
 * a default permission to get that delegation request. For more details, see
 *
 * Managing Permissions for Delegation Requests.
 */
export declare const getDelegationRequest: API.OperationMethod<GetDelegationRequestRequest, GetDelegationRequestResponse, GetDelegationRequestError, Credentials | HttpClient.HttpClient>;
export type GetGroupError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Returns a list of IAM users that are in the specified IAM group. You can paginate
 * the results using the `MaxItems` and `Marker` parameters.
 */
export declare const getGroup: API.PaginatedOperationMethod<GetGroupRequest, GetGroupResponse, GetGroupError, Credentials | HttpClient.HttpClient, User>;
export type GetGroupPolicyError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves the specified inline policy document that is embedded in the specified IAM
 * group.
 *
 * Policies returned by this operation are URL-encoded compliant
 * with RFC 3986. You can use a URL
 * decoding method to convert the policy back to plain JSON text. For example, if you use Java, you
 * can use the `decode` method of the `java.net.URLDecoder` utility class in
 * the Java SDK. Other languages and SDKs provide similar functionality, and some SDKs do this decoding
 * automatically.
 *
 * An IAM group can also have managed policies attached to it. To retrieve a managed
 * policy document that is attached to a group, use GetPolicy to determine the
 * policy's default version, then use GetPolicyVersion to
 * retrieve the policy document.
 *
 * For more information about policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 */
export declare const getGroupPolicy: API.OperationMethod<GetGroupPolicyRequest, GetGroupPolicyResponse, GetGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type GetHumanReadableSummaryError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves a human readable summary for a given entity. At this time, the only supported
 * entity type is `delegation-request`
 *
 * This method uses a Large Language Model (LLM) to generate the summary.
 *
 * If a delegation request has no owner or owner account, `GetHumanReadableSummary` for that delegation request can be called by any account.
 * If the owner account is assigned but there is
 * no owner id, only identities within that owner account can call `GetHumanReadableSummary`
 * for the delegation request to retrieve a summary of that request.
 * Once the delegation request is fully owned, the owner of the request gets
 * a default permission to get that delegation request. For more details, read
 * default permissions granted to delegation requests. These rules are identical to
 * GetDelegationRequest
 * API behavior, such that a party who has permissions to call
 * GetDelegationRequest
 * for a given delegation request will always be able to retrieve the human readable summary for that request.
 */
export declare const getHumanReadableSummary: API.OperationMethod<GetHumanReadableSummaryRequest, GetHumanReadableSummaryResponse, GetHumanReadableSummaryError, Credentials | HttpClient.HttpClient>;
export type GetInstanceProfileError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves information about the specified instance profile, including the instance
 * profile's path, GUID, ARN, and role. For more information about instance profiles, see
 * Using
 * instance profiles in the *IAM User Guide*.
 */
export declare const getInstanceProfile: API.OperationMethod<GetInstanceProfileRequest, GetInstanceProfileResponse, GetInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type GetLoginProfileError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves the user name for the specified IAM user. A login profile is created when
 * you create a password for the user to access the Amazon Web Services Management Console. If the user does not exist
 * or does not have a password, the operation returns a 404 (`NoSuchEntity`)
 * error.
 *
 * If you create an IAM user with access to the console, the `CreateDate`
 * reflects the date you created the initial password for the user.
 *
 * If you create an IAM user with programmatic access, and then later add a password
 * for the user to access the Amazon Web Services Management Console, the `CreateDate` reflects the initial
 * password creation date. A user with programmatic access does not have a login profile
 * unless you create a password for the user to access the Amazon Web Services Management Console.
 */
export declare const getLoginProfile: API.OperationMethod<GetLoginProfileRequest, GetLoginProfileResponse, GetLoginProfileError, Credentials | HttpClient.HttpClient>;
export type GetMFADeviceError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves information about an MFA device for a specified user.
 */
export declare const getMFADevice: API.OperationMethod<GetMFADeviceRequest, GetMFADeviceResponse, GetMFADeviceError, Credentials | HttpClient.HttpClient>;
export type GetOpenIDConnectProviderError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Returns information about the specified OpenID Connect (OIDC) provider resource object
 * in IAM.
 */
export declare const getOpenIDConnectProvider: API.OperationMethod<GetOpenIDConnectProviderRequest, GetOpenIDConnectProviderResponse, GetOpenIDConnectProviderError, Credentials | HttpClient.HttpClient>;
export type GetOrganizationsAccessReportError = NoSuchEntityException | CommonErrors;
/**
 * Retrieves the service last accessed data report for Organizations that was previously
 * generated using the
 * GenerateOrganizationsAccessReport
 * operation. This operation
 * retrieves the status of your report job and the report contents.
 *
 * Depending on the parameters that you passed when you generated the report, the data
 * returned could include different information. For details, see GenerateOrganizationsAccessReport.
 *
 * To call this operation, you must be signed in to the management account in your
 * organization. SCPs must be enabled for your organization root. You must have permissions
 * to perform this operation. For more information, see Refining permissions using
 * service last accessed data in the
 * *IAM User Guide*.
 *
 * For each service that principals in an account (root user, IAM users, or IAM roles)
 * could access using SCPs, the operation returns details about the most recent access
 * attempt. If there was no attempt, the service is listed without details about the most
 * recent attempt to access the service. If the operation fails, it returns the reason that
 * it failed.
 *
 * By default, the list is sorted by service namespace.
 */
export declare const getOrganizationsAccessReport: API.OperationMethod<GetOrganizationsAccessReportRequest, GetOrganizationsAccessReportResponse, GetOrganizationsAccessReportError, Credentials | HttpClient.HttpClient>;
export type GetOutboundWebIdentityFederationInfoError = FeatureDisabledException | CommonErrors;
/**
 * Retrieves the configuration information for the outbound identity federation feature in your Amazon Web Services account. The response includes the unique issuer URL for your
 * Amazon Web Services account and the current enabled/disabled status of the feature. Use this operation to obtain the issuer URL that you need to configure trust relationships with external services.
 */
export declare const getOutboundWebIdentityFederationInfo: API.OperationMethod<GetOutboundWebIdentityFederationInfoRequest, GetOutboundWebIdentityFederationInfoResponse, GetOutboundWebIdentityFederationInfoError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves information about the specified managed policy, including the policy's
 * default version and the total number of IAM users, groups, and roles to which the
 * policy is attached. To retrieve the list of the specific users, groups, and roles that
 * the policy is attached to, use ListEntitiesForPolicy. This operation returns metadata about the policy. To
 * retrieve the actual policy document for a specific version of the policy, use GetPolicyVersion.
 *
 * This operation retrieves information about managed policies. To retrieve information
 * about an inline policy that is embedded with an IAM user, group, or role, use GetUserPolicy, GetGroupPolicy, or
 * GetRolePolicy.
 *
 * For more information about policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest, GetPolicyResponse, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetPolicyVersionError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves information about the specified version of the specified managed policy,
 * including the policy document.
 *
 * Policies returned by this operation are URL-encoded compliant
 * with RFC 3986. You can use a URL
 * decoding method to convert the policy back to plain JSON text. For example, if you use Java, you
 * can use the `decode` method of the `java.net.URLDecoder` utility class in
 * the Java SDK. Other languages and SDKs provide similar functionality, and some SDKs do this decoding
 * automatically.
 *
 * To list the available versions for a policy, use ListPolicyVersions.
 *
 * This operation retrieves information about managed policies. To retrieve information
 * about an inline policy that is embedded in a user, group, or role, use GetUserPolicy, GetGroupPolicy, or
 * GetRolePolicy.
 *
 * For more information about the types of policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 *
 * For more information about managed policy versions, see Versioning for managed
 * policies in the *IAM User Guide*.
 */
export declare const getPolicyVersion: API.OperationMethod<GetPolicyVersionRequest, GetPolicyVersionResponse, GetPolicyVersionError, Credentials | HttpClient.HttpClient>;
export type GetRoleError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves information about the specified role, including the role's path, GUID, ARN,
 * and the role's trust policy that grants permission to assume the role. For more
 * information about roles, see IAM roles in the
 * *IAM User Guide*.
 *
 * Policies returned by this operation are URL-encoded compliant
 * with RFC 3986. You can use a URL
 * decoding method to convert the policy back to plain JSON text. For example, if you use Java, you
 * can use the `decode` method of the `java.net.URLDecoder` utility class in
 * the Java SDK. Other languages and SDKs provide similar functionality, and some SDKs do this decoding
 * automatically.
 */
export declare const getRole: API.OperationMethod<GetRoleRequest, GetRoleResponse, GetRoleError, Credentials | HttpClient.HttpClient>;
export type GetRolePolicyError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves the specified inline policy document that is embedded with the specified
 * IAM role.
 *
 * Policies returned by this operation are URL-encoded compliant
 * with RFC 3986. You can use a URL
 * decoding method to convert the policy back to plain JSON text. For example, if you use Java, you
 * can use the `decode` method of the `java.net.URLDecoder` utility class in
 * the Java SDK. Other languages and SDKs provide similar functionality, and some SDKs do this decoding
 * automatically.
 *
 * An IAM role can also have managed policies attached to it. To retrieve a managed
 * policy document that is attached to a role, use GetPolicy to determine the
 * policy's default version, then use GetPolicyVersion to
 * retrieve the policy document.
 *
 * For more information about policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 *
 * For more information about roles, see IAM roles in the
 * *IAM User Guide*.
 */
export declare const getRolePolicy: API.OperationMethod<GetRolePolicyRequest, GetRolePolicyResponse, GetRolePolicyError, Credentials | HttpClient.HttpClient>;
export type GetRoleTemplateVersionError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves information about a version of the specified role template. Role templates
 * define a reusable configuration—including role name and path patterns, trust
 * policy, inline and managed policies, permissions boundary, tags, and maximum session
 * duration—that you use to create IAM roles with AcquireRole.
 *
 * If you do not specify a minor version, the service returns the template's default
 * minor version.
 */
export declare const getRoleTemplateVersion: API.OperationMethod<GetRoleTemplateVersionRequest, GetRoleTemplateVersionResponse, GetRoleTemplateVersionError, Credentials | HttpClient.HttpClient>;
export type GetSAMLProviderError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Returns the SAML provider metadocument that was uploaded when the IAM SAML provider
 * resource object was created or updated.
 *
 * This operation requires Signature Version 4.
 */
export declare const getSAMLProvider: API.OperationMethod<GetSAMLProviderRequest, GetSAMLProviderResponse, GetSAMLProviderError, Credentials | HttpClient.HttpClient>;
export type GetServerCertificateError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves information about the specified server certificate stored in IAM.
 *
 * For more information about working with server certificates, see Working
 * with server certificates in the *IAM User Guide*. This
 * topic includes a list of Amazon Web Services services that can use the server certificates that you
 * manage with IAM.
 */
export declare const getServerCertificate: API.OperationMethod<GetServerCertificateRequest, GetServerCertificateResponse, GetServerCertificateError, Credentials | HttpClient.HttpClient>;
export type GetServiceLastAccessedDetailsError = InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Retrieves a service last accessed report that was created using the
 * `GenerateServiceLastAccessedDetails` operation. You can use the
 * `JobId` parameter in `GetServiceLastAccessedDetails` to
 * retrieve the status of your report job. When the report is complete, you can retrieve
 * the generated report. The report includes a list of Amazon Web Services services that the resource
 * (user, group, role, or managed policy) can access.
 *
 * Service last accessed data does not use other policy types when determining
 * whether a resource could access a service. These other policy types include
 * resource-based policies, access control lists, Organizations policies, IAM permissions
 * boundaries, and STS assume role policies. It only applies permissions policy
 * logic. For more about the evaluation of policy types, see Evaluating policies in the
 * *IAM User Guide*.
 *
 * For each service that the resource could access using permissions policies, the
 * operation returns details about the most recent access attempt. If there was no attempt,
 * the service is listed without details about the most recent attempt to access the
 * service. If the operation fails, the `GetServiceLastAccessedDetails`
 * operation returns the reason that it failed.
 *
 * The `GetServiceLastAccessedDetails` operation returns a list of services.
 * This list includes the number of entities that have attempted to access the service and
 * the date and time of the last attempt. It also returns the ARN of the following entity,
 * depending on the resource ARN that you used to generate the report:
 *
 * - **User** – Returns the user ARN that you
 * used to generate the report
 *
 * - **Group** – Returns the ARN of the group
 * member (user) that last attempted to access the service
 *
 * - **Role** – Returns the role ARN that you
 * used to generate the report
 *
 * - **Policy** – Returns the ARN of the user
 * or role that last used the policy to attempt to access the service
 *
 * By default, the list is sorted by service namespace.
 *
 * If you specified `ACTION_LEVEL` granularity when you generated the report,
 * this operation returns service and action last accessed data. This includes the most
 * recent access attempt for each tracked action within a service. Otherwise, this
 * operation returns only service data.
 *
 * For more information about service and action last accessed data, see Reducing permissions using service last accessed data in the
 * *IAM User Guide*.
 */
export declare const getServiceLastAccessedDetails: API.OperationMethod<GetServiceLastAccessedDetailsRequest, GetServiceLastAccessedDetailsResponse, GetServiceLastAccessedDetailsError, Credentials | HttpClient.HttpClient>;
export type GetServiceLastAccessedDetailsWithEntitiesError = InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * After you generate a group or policy report using the
 * `GenerateServiceLastAccessedDetails` operation, you can use the
 * `JobId` parameter in
 * `GetServiceLastAccessedDetailsWithEntities`. This operation retrieves the
 * status of your report job and a list of entities that could have used group or policy
 * permissions to access the specified service.
 *
 * - **Group** – For a group report, this
 * operation returns a list of users in the group that could have used the group’s
 * policies in an attempt to access the service.
 *
 * - **Policy** – For a policy report, this
 * operation returns a list of entities (users or roles) that could have used the
 * policy in an attempt to access the service.
 *
 * You can also use this operation for user or role reports to retrieve details about
 * those entities.
 *
 * If the operation fails, the `GetServiceLastAccessedDetailsWithEntities`
 * operation returns the reason that it failed.
 *
 * By default, the list of associated entities is sorted by date, with the most recent
 * access listed first.
 */
export declare const getServiceLastAccessedDetailsWithEntities: API.OperationMethod<GetServiceLastAccessedDetailsWithEntitiesRequest, GetServiceLastAccessedDetailsWithEntitiesResponse, GetServiceLastAccessedDetailsWithEntitiesError, Credentials | HttpClient.HttpClient>;
export type GetServiceLinkedRoleDeletionStatusError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves the status of your service-linked role deletion. After you use DeleteServiceLinkedRole to submit a service-linked role for deletion, you
 * can use the `DeletionTaskId` parameter in
 * `GetServiceLinkedRoleDeletionStatus` to check the status of the deletion.
 * If the deletion fails, this operation returns the reason that it failed, if that
 * information is returned by the service.
 */
export declare const getServiceLinkedRoleDeletionStatus: API.OperationMethod<GetServiceLinkedRoleDeletionStatusRequest, GetServiceLinkedRoleDeletionStatusResponse, GetServiceLinkedRoleDeletionStatusError, Credentials | HttpClient.HttpClient>;
export type GetSSHPublicKeyError = NoSuchEntityException | UnrecognizedPublicKeyEncodingException | CommonErrors;
/**
 * Retrieves the specified SSH public key, including metadata about the key.
 *
 * The SSH public key retrieved by this operation is used only for authenticating the
 * associated IAM user to an CodeCommit repository. For more information about using SSH keys
 * to authenticate to an CodeCommit repository, see Set up CodeCommit for SSH
 * connections in the *CodeCommit User Guide*.
 */
export declare const getSSHPublicKey: API.OperationMethod<GetSSHPublicKeyRequest, GetSSHPublicKeyResponse, GetSSHPublicKeyError, Credentials | HttpClient.HttpClient>;
export type GetUserError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves information about the specified IAM user, including the user's creation
 * date, path, unique ID, and ARN.
 *
 * If you do not specify a user name, IAM determines the user name implicitly based on
 * the Amazon Web Services access key ID used to sign the request to this operation.
 */
export declare const getUser: API.OperationMethod<GetUserRequest, GetUserResponse, GetUserError, Credentials | HttpClient.HttpClient>;
export type GetUserPolicyError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Retrieves the specified inline policy document that is embedded in the specified IAM
 * user.
 *
 * Policies returned by this operation are URL-encoded compliant
 * with RFC 3986. You can use a URL
 * decoding method to convert the policy back to plain JSON text. For example, if you use Java, you
 * can use the `decode` method of the `java.net.URLDecoder` utility class in
 * the Java SDK. Other languages and SDKs provide similar functionality, and some SDKs do this decoding
 * automatically.
 *
 * An IAM user can also have managed policies attached to it. To retrieve a managed
 * policy document that is attached to a user, use GetPolicy to determine the
 * policy's default version. Then use GetPolicyVersion to
 * retrieve the policy document.
 *
 * For more information about policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 */
export declare const getUserPolicy: API.OperationMethod<GetUserPolicyRequest, GetUserPolicyResponse, GetUserPolicyError, Credentials | HttpClient.HttpClient>;
export type ListAccessKeysError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Returns information about the access key IDs associated with the specified IAM user.
 * If there is none, the operation returns an empty list.
 *
 * Although each user is limited to a small number of keys, you can still paginate the
 * results using the `MaxItems` and `Marker` parameters.
 *
 * If the `UserName` is not specified, the user name is determined implicitly
 * based on the Amazon Web Services access key ID used to sign the request. If a temporary access key is
 * used, then `UserName` is required. If a long-term key is assigned to the
 * user, then `UserName` is not required.
 *
 * This operation works for access keys under the Amazon Web Services account. If the Amazon Web Services account has
 * no associated users, the root user returns it's own access key IDs by running this
 * command.
 *
 * To ensure the security of your Amazon Web Services account, the secret access key is accessible
 * only during key and user creation.
 */
export declare const listAccessKeys: API.PaginatedOperationMethod<ListAccessKeysRequest, ListAccessKeysResponse, ListAccessKeysError, Credentials | HttpClient.HttpClient, AccessKeyMetadata>;
export type ListAccountAliasesError = ServiceFailureException | CommonErrors;
/**
 * Lists the account alias associated with the Amazon Web Services account (Note: you can have only
 * one). For information about using an Amazon Web Services account alias, see Creating,
 * deleting, and listing an Amazon Web Services account alias in the
 * *IAM User Guide*.
 */
export declare const listAccountAliases: API.PaginatedOperationMethod<ListAccountAliasesRequest, ListAccountAliasesResponse, ListAccountAliasesError, Credentials | HttpClient.HttpClient, AccountAliasType>;
export type ListAttachedGroupPoliciesError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists all managed policies that are attached to the specified IAM group.
 *
 * An IAM group can also have inline policies embedded with it. To list the inline
 * policies for a group, use ListGroupPolicies.
 * For information about policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters. You can use the `PathPrefix` parameter to limit the list of
 * policies to only those matching the specified path prefix. If there are no policies
 * attached to the specified group (or none that match the specified path prefix), the
 * operation returns an empty list.
 */
export declare const listAttachedGroupPolicies: API.PaginatedOperationMethod<ListAttachedGroupPoliciesRequest, ListAttachedGroupPoliciesResponse, ListAttachedGroupPoliciesError, Credentials | HttpClient.HttpClient, AttachedPolicy>;
export type ListAttachedRolePoliciesError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists all managed policies that are attached to the specified IAM role.
 *
 * An IAM role can also have inline policies embedded with it. To list the inline
 * policies for a role, use ListRolePolicies.
 * For information about policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters. You can use the `PathPrefix` parameter to limit the list of
 * policies to only those matching the specified path prefix. If there are no policies
 * attached to the specified role (or none that match the specified path prefix), the
 * operation returns an empty list.
 */
export declare const listAttachedRolePolicies: API.PaginatedOperationMethod<ListAttachedRolePoliciesRequest, ListAttachedRolePoliciesResponse, ListAttachedRolePoliciesError, Credentials | HttpClient.HttpClient, AttachedPolicy>;
export type ListAttachedUserPoliciesError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists all managed policies that are attached to the specified IAM user.
 *
 * An IAM user can also have inline policies embedded with it. To list the inline
 * policies for a user, use ListUserPolicies.
 * For information about policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters. You can use the `PathPrefix` parameter to limit the list of
 * policies to only those matching the specified path prefix. If there are no policies
 * attached to the specified group (or none that match the specified path prefix), the
 * operation returns an empty list.
 */
export declare const listAttachedUserPolicies: API.PaginatedOperationMethod<ListAttachedUserPoliciesRequest, ListAttachedUserPoliciesResponse, ListAttachedUserPoliciesError, Credentials | HttpClient.HttpClient, AttachedPolicy>;
export type ListDelegationRequestsError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists delegation requests based on the specified criteria.
 *
 * If a delegation request has no owner, even if it is assigned to a specific account, it will not be part of the
 * `ListDelegationRequests` output for that account.
 *
 * For more details, see
 *
 * Managing Permissions for Delegation Requests.
 */
export declare const listDelegationRequests: API.OperationMethod<ListDelegationRequestsRequest, ListDelegationRequestsResponse, ListDelegationRequestsError, Credentials | HttpClient.HttpClient>;
export type ListEntitiesForPolicyError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists all IAM users, groups, and roles that the specified managed policy is attached
 * to.
 *
 * You can use the optional `EntityFilter` parameter to limit the results to a
 * particular type of entity (users, groups, or roles). For example, to list only the roles
 * that are attached to the specified policy, set `EntityFilter` to
 * `Role`.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters.
 */
export declare const listEntitiesForPolicy: API.PaginatedOperationMethod<ListEntitiesForPolicyRequest, ListEntitiesForPolicyResponse, ListEntitiesForPolicyError, Credentials | HttpClient.HttpClient, unknown>;
export type ListGroupPoliciesError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the names of the inline policies that are embedded in the specified IAM
 * group.
 *
 * An IAM group can also have managed policies attached to it. To list the managed
 * policies that are attached to a group, use ListAttachedGroupPolicies. For more information about policies, see Managed
 * policies and inline policies in the
 * *IAM User Guide*.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters. If there are no inline policies embedded with the specified group, the
 * operation returns an empty list.
 */
export declare const listGroupPolicies: API.PaginatedOperationMethod<ListGroupPoliciesRequest, ListGroupPoliciesResponse, ListGroupPoliciesError, Credentials | HttpClient.HttpClient, PolicyNameType>;
export type ListGroupsError = ServiceFailureException | CommonErrors;
/**
 * Lists the IAM groups that have the specified path prefix.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters.
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsRequest, ListGroupsResponse, ListGroupsError, Credentials | HttpClient.HttpClient, Group>;
export type ListGroupsForUserError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the IAM groups that the specified IAM user belongs to.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters.
 */
export declare const listGroupsForUser: API.PaginatedOperationMethod<ListGroupsForUserRequest, ListGroupsForUserResponse, ListGroupsForUserError, Credentials | HttpClient.HttpClient, Group>;
export type ListInstanceProfilesError = ServiceFailureException | CommonErrors;
/**
 * Lists the instance profiles that have the specified path prefix. If there are none,
 * the operation returns an empty list. For more information about instance profiles, see
 * Using
 * instance profiles in the *IAM User Guide*.
 *
 * IAM resource-listing operations return a subset of the available
 * attributes for the resource. For example, this operation does not return tags, even though they are an attribute of the returned object. To view all of the information for an instance profile, see
 * GetInstanceProfile.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters.
 */
export declare const listInstanceProfiles: API.PaginatedOperationMethod<ListInstanceProfilesRequest, ListInstanceProfilesResponse, ListInstanceProfilesError, Credentials | HttpClient.HttpClient, InstanceProfile>;
export type ListInstanceProfilesForRoleError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the instance profiles that have the specified associated IAM role. If there
 * are none, the operation returns an empty list. For more information about instance
 * profiles, go to Using
 * instance profiles in the *IAM User Guide*.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters.
 */
export declare const listInstanceProfilesForRole: API.PaginatedOperationMethod<ListInstanceProfilesForRoleRequest, ListInstanceProfilesForRoleResponse, ListInstanceProfilesForRoleError, Credentials | HttpClient.HttpClient, InstanceProfile>;
export type ListInstanceProfileTagsError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the tags that are attached to the specified IAM instance profile. The returned list of tags is sorted by tag key.
 * For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const listInstanceProfileTags: API.PaginatedOperationMethod<ListInstanceProfileTagsRequest, ListInstanceProfileTagsResponse, ListInstanceProfileTagsError, Credentials | HttpClient.HttpClient, Tag>;
export type ListMFADevicesError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the MFA devices for an IAM user. If the request includes a IAM user name,
 * then this operation lists all the MFA devices associated with the specified user. If you
 * do not specify a user name, IAM determines the user name implicitly based on the Amazon Web Services
 * access key ID signing the request for this operation.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters.
 */
export declare const listMFADevices: API.PaginatedOperationMethod<ListMFADevicesRequest, ListMFADevicesResponse, ListMFADevicesError, Credentials | HttpClient.HttpClient, MFADevice>;
export type ListMFADeviceTagsError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the tags that are attached to the specified IAM virtual multi-factor authentication (MFA) device. The returned list of tags is
 * sorted by tag key. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const listMFADeviceTags: API.PaginatedOperationMethod<ListMFADeviceTagsRequest, ListMFADeviceTagsResponse, ListMFADeviceTagsError, Credentials | HttpClient.HttpClient, Tag>;
export type ListOpenIDConnectProvidersError = ServiceFailureException | CommonErrors;
/**
 * Lists information about the IAM OpenID Connect (OIDC) provider resource objects
 * defined in the Amazon Web Services account.
 *
 * IAM resource-listing operations return a subset of the available
 * attributes for the resource. For example, this operation does not return tags, even though they are an attribute of the returned object. To view all of the information for an OIDC provider, see GetOpenIDConnectProvider.
 */
export declare const listOpenIDConnectProviders: API.OperationMethod<ListOpenIDConnectProvidersRequest, ListOpenIDConnectProvidersResponse, ListOpenIDConnectProvidersError, Credentials | HttpClient.HttpClient>;
export type ListOpenIDConnectProviderTagsError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the tags that are attached to the specified OpenID Connect (OIDC)-compatible
 * identity provider. The returned list of tags is sorted by tag key. For more information, see About web identity
 * federation.
 *
 * For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const listOpenIDConnectProviderTags: API.PaginatedOperationMethod<ListOpenIDConnectProviderTagsRequest, ListOpenIDConnectProviderTagsResponse, ListOpenIDConnectProviderTagsError, Credentials | HttpClient.HttpClient, Tag>;
export type ListOrganizationsFeaturesError = AccountNotManagementOrDelegatedAdministratorException | OrganizationNotFoundException | OrganizationNotInAllFeaturesModeException | ServiceAccessNotEnabledException | CommonErrors;
/**
 * Lists the centralized root access features enabled for your organization. For more
 * information, see Centrally manage root access for member accounts.
 */
export declare const listOrganizationsFeatures: API.OperationMethod<ListOrganizationsFeaturesRequest, ListOrganizationsFeaturesResponse, ListOrganizationsFeaturesError, Credentials | HttpClient.HttpClient>;
export type ListPoliciesError = ServiceFailureException | CommonErrors;
/**
 * Lists all the managed policies that are available in your Amazon Web Services account, including
 * your own customer-defined managed policies and all Amazon Web Services managed policies.
 *
 * You can filter the list of policies that is returned using the optional
 * `OnlyAttached`, `Scope`, and `PathPrefix`
 * parameters. For example, to list only the customer managed policies in your Amazon Web Services
 * account, set `Scope` to `Local`. To list only Amazon Web Services managed
 * policies, set `Scope` to `AWS`.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters.
 *
 * For more information about managed policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 *
 * IAM resource-listing operations return a subset of the available
 * attributes for the resource. For example, this operation does not return tags, even though they are an attribute of the returned object. To view all of the information for a customer manged policy, see
 * GetPolicy.
 */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesRequest, ListPoliciesResponse, ListPoliciesError, Credentials | HttpClient.HttpClient, Policy>;
export type ListPoliciesGrantingServiceAccessError = InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Retrieves a list of policies that the IAM identity (user, group, or role) can use to
 * access each specified service.
 *
 * This operation does not use other policy types when determining whether a resource
 * could access a service. These other policy types include resource-based policies,
 * access control lists, Organizations policies, IAM permissions boundaries, and STS
 * assume role policies. It only applies permissions policy logic. For more about the
 * evaluation of policy types, see Evaluating policies in the
 * *IAM User Guide*.
 *
 * The list of policies returned by the operation depends on the ARN of the identity that
 * you provide.
 *
 * - **User** – The list of policies includes
 * the managed and inline policies that are attached to the user directly. The list
 * also includes any additional managed and inline policies that are attached to
 * the group to which the user belongs.
 *
 * - **Group** – The list of policies includes
 * only the managed and inline policies that are attached to the group directly.
 * Policies that are attached to the group’s user are not included.
 *
 * - **Role** – The list of policies includes
 * only the managed and inline policies that are attached to the role.
 *
 * For each managed policy, this operation returns the ARN and policy name. For each
 * inline policy, it returns the policy name and the entity to which it is attached. Inline
 * policies do not have an ARN. For more information about these policy types, see Managed policies and inline policies in the
 * *IAM User Guide*.
 *
 * Policies that are attached to users and roles as permissions boundaries are not
 * returned. To view which managed policy is currently used to set the permissions boundary
 * for a user or role, use the GetUser or GetRole
 * operations.
 */
export declare const listPoliciesGrantingServiceAccess: API.OperationMethod<ListPoliciesGrantingServiceAccessRequest, ListPoliciesGrantingServiceAccessResponse, ListPoliciesGrantingServiceAccessError, Credentials | HttpClient.HttpClient>;
export type ListPolicyTagsError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the tags that are attached to the specified IAM customer managed policy.
 * The returned list of tags is sorted by tag key. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const listPolicyTags: API.PaginatedOperationMethod<ListPolicyTagsRequest, ListPolicyTagsResponse, ListPolicyTagsError, Credentials | HttpClient.HttpClient, Tag>;
export type ListPolicyVersionsError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists information about the versions of the specified managed policy, including the
 * version that is currently set as the policy's default version.
 *
 * For more information about managed policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 */
export declare const listPolicyVersions: API.PaginatedOperationMethod<ListPolicyVersionsRequest, ListPolicyVersionsResponse, ListPolicyVersionsError, Credentials | HttpClient.HttpClient, PolicyVersion>;
export type ListRolePoliciesError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the names of the inline policies that are embedded in the specified IAM
 * role.
 *
 * An IAM role can also have managed policies attached to it. To list the managed
 * policies that are attached to a role, use ListAttachedRolePolicies. For more information about policies, see Managed
 * policies and inline policies in the
 * *IAM User Guide*.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters. If there are no inline policies embedded with the specified role, the
 * operation returns an empty list.
 */
export declare const listRolePolicies: API.PaginatedOperationMethod<ListRolePoliciesRequest, ListRolePoliciesResponse, ListRolePoliciesError, Credentials | HttpClient.HttpClient, PolicyNameType>;
export type ListRolesError = ServiceFailureException | CommonErrors;
/**
 * Lists the IAM roles that have the specified path prefix. If there are none, the
 * operation returns an empty list. For more information about roles, see IAM roles in the
 * *IAM User Guide*.
 *
 * IAM resource-listing operations return a subset of the available
 * attributes for the resource. This operation does not return the following attributes, even though they are an attribute of the returned object:
 *
 * - PermissionsBoundary
 *
 * - RoleLastUsed
 *
 * - Tags
 *
 * To view all of the information for a role, see GetRole.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters.
 */
export declare const listRoles: API.PaginatedOperationMethod<ListRolesRequest, ListRolesResponse, ListRolesError, Credentials | HttpClient.HttpClient, Role>;
export type ListRoleTagsError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the tags that are attached to the specified role. The returned list of tags is
 * sorted by tag key. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const listRoleTags: API.PaginatedOperationMethod<ListRoleTagsRequest, ListRoleTagsResponse, ListRoleTagsError, Credentials | HttpClient.HttpClient, Tag>;
export type ListSAMLProvidersError = ServiceFailureException | CommonErrors;
/**
 * Lists the SAML provider resource objects defined in IAM in the account.
 * IAM resource-listing operations return a subset of the available
 * attributes for the resource. For example, this operation does not return tags, even though they are an attribute of the returned object. To view all of the information for a SAML provider, see GetSAMLProvider.
 *
 * This operation requires Signature Version 4.
 */
export declare const listSAMLProviders: API.OperationMethod<ListSAMLProvidersRequest, ListSAMLProvidersResponse, ListSAMLProvidersError, Credentials | HttpClient.HttpClient>;
export type ListSAMLProviderTagsError = InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the tags that are attached to the specified Security Assertion Markup Language
 * (SAML) identity provider. The returned list of tags is sorted by tag key. For more information, see About SAML 2.0-based
 * federation.
 *
 * For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const listSAMLProviderTags: API.PaginatedOperationMethod<ListSAMLProviderTagsRequest, ListSAMLProviderTagsResponse, ListSAMLProviderTagsError, Credentials | HttpClient.HttpClient, Tag>;
export type ListServerCertificatesError = ServiceFailureException | CommonErrors;
/**
 * Lists the server certificates stored in IAM that have the specified path prefix. If
 * none exist, the operation returns an empty list.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters.
 *
 * For more information about working with server certificates, see Working
 * with server certificates in the *IAM User Guide*. This
 * topic also includes a list of Amazon Web Services services that can use the server certificates that
 * you manage with IAM.
 *
 * IAM resource-listing operations return a subset of the available
 * attributes for the resource. For example, this operation does not return tags, even though they are an attribute of the returned object. To view all of the information for a servercertificate, see
 * GetServerCertificate.
 */
export declare const listServerCertificates: API.PaginatedOperationMethod<ListServerCertificatesRequest, ListServerCertificatesResponse, ListServerCertificatesError, Credentials | HttpClient.HttpClient, ServerCertificateMetadata>;
export type ListServerCertificateTagsError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the tags that are attached to the specified IAM server certificate. The
 * returned list of tags is sorted by tag key. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 *
 * For certificates in a Region supported by Certificate Manager (ACM), we
 * recommend that you don't use IAM server certificates. Instead, use ACM to provision,
 * manage, and deploy your server certificates. For more information about IAM server
 * certificates, Working with server
 * certificates in the *IAM User Guide*.
 */
export declare const listServerCertificateTags: API.PaginatedOperationMethod<ListServerCertificateTagsRequest, ListServerCertificateTagsResponse, ListServerCertificateTagsError, Credentials | HttpClient.HttpClient, Tag>;
export type ListServiceSpecificCredentialsError = NoSuchEntityException | ServiceNotSupportedException | RequestLimitExceeded | InvalidInput | CommonErrors;
/**
 * Returns information about the service-specific credentials associated with the
 * specified IAM user. If none exists, the operation returns an empty list. The
 * service-specific credentials returned by this operation are used only for authenticating
 * the IAM user to a specific service. For more information about using service-specific
 * credentials to authenticate to an Amazon Web Services service, refer to the following docs:
 *
 * - For service-specific credentials with CodeCommit, refer to IAM credentials for CodeCommit: Git credentials, SSH keys, and Amazon Web Services access
 * keys in the *IAM User Guide*.
 *
 * - For service-specific credentials with Amazon Keyspaces (for Apache Cassandra), refer to Use IAM with
 * Amazon Keyspaces (for Apache Cassandra) in the
 * *IAM User Guide*.
 *
 * - For services that support long-term API keys, refer to API
 * keys for Amazon Web Services services in the
 * *IAM User Guide*.
 */
export declare const listServiceSpecificCredentials: API.OperationMethod<ListServiceSpecificCredentialsRequest, ListServiceSpecificCredentialsResponse, ListServiceSpecificCredentialsError, Credentials | HttpClient.HttpClient>;
export type ListSigningCertificatesError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Returns information about the signing certificates associated with the specified IAM
 * user. If none exists, the operation returns an empty list.
 *
 * Although each user is limited to a small number of signing certificates, you can still
 * paginate the results using the `MaxItems` and `Marker`
 * parameters.
 *
 * If the `UserName` field is not specified, the user name is determined
 * implicitly based on the Amazon Web Services access key ID used to sign the request for this operation.
 * This operation works for access keys under the Amazon Web Services account. Consequently, you can use
 * this operation to manage Amazon Web Services account root user credentials even if the Amazon Web Services account has no
 * associated users.
 */
export declare const listSigningCertificates: API.PaginatedOperationMethod<ListSigningCertificatesRequest, ListSigningCertificatesResponse, ListSigningCertificatesError, Credentials | HttpClient.HttpClient, SigningCertificate>;
export type ListSSHPublicKeysError = NoSuchEntityException | CommonErrors;
/**
 * Returns information about the SSH public keys associated with the specified IAM
 * user. If none exists, the operation returns an empty list.
 *
 * The SSH public keys returned by this operation are used only for authenticating the
 * IAM user to an CodeCommit repository. For more information about using SSH keys to
 * authenticate to an CodeCommit repository, see Set up CodeCommit for
 * SSH connections in the *CodeCommit User Guide*.
 *
 * Although each user is limited to a small number of keys, you can still paginate the
 * results using the `MaxItems` and `Marker` parameters.
 */
export declare const listSSHPublicKeys: API.PaginatedOperationMethod<ListSSHPublicKeysRequest, ListSSHPublicKeysResponse, ListSSHPublicKeysError, Credentials | HttpClient.HttpClient, SSHPublicKeyMetadata>;
export type ListUserPoliciesError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the names of the inline policies embedded in the specified IAM user.
 *
 * An IAM user can also have managed policies attached to it. To list the managed
 * policies that are attached to a user, use ListAttachedUserPolicies. For more information about policies, see Managed
 * policies and inline policies in the
 * *IAM User Guide*.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters. If there are no inline policies embedded with the specified user, the
 * operation returns an empty list.
 */
export declare const listUserPolicies: API.PaginatedOperationMethod<ListUserPoliciesRequest, ListUserPoliciesResponse, ListUserPoliciesError, Credentials | HttpClient.HttpClient, PolicyNameType>;
export type ListUsersError = ServiceFailureException | CommonErrors;
/**
 * Lists the IAM users that have the specified path prefix. If no path prefix is
 * specified, the operation returns all users in the Amazon Web Services account. If there are none, the
 * operation returns an empty list.
 *
 * IAM resource-listing operations return a subset of the available
 * attributes for the resource. This operation does not return the following attributes, even though they are an attribute of the returned object:
 *
 * - PermissionsBoundary
 *
 * - Tags
 *
 * To view all of the information for a user, see GetUser.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest, ListUsersResponse, ListUsersError, Credentials | HttpClient.HttpClient, User>;
export type ListUserTagsError = NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Lists the tags that are attached to the specified IAM user. The returned list of tags is sorted by tag key. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const listUserTags: API.PaginatedOperationMethod<ListUserTagsRequest, ListUserTagsResponse, ListUserTagsError, Credentials | HttpClient.HttpClient, Tag>;
export type ListVirtualMFADevicesError = CommonErrors;
/**
 * Lists the virtual MFA devices defined in the Amazon Web Services account by assignment status. If
 * you do not specify an assignment status, the operation returns a list of all virtual MFA
 * devices. Assignment status can be `Assigned`, `Unassigned`, or
 * `Any`.
 *
 * IAM resource-listing operations return a subset of the available
 * attributes for the resource. For example, this operation does not return tags, even though they are an attribute of the returned object. To view tag information for a virtual MFA device, see ListMFADeviceTags.
 *
 * You can paginate the results using the `MaxItems` and `Marker`
 * parameters.
 */
export declare const listVirtualMFADevices: API.PaginatedOperationMethod<ListVirtualMFADevicesRequest, ListVirtualMFADevicesResponse, ListVirtualMFADevicesError, Credentials | HttpClient.HttpClient, VirtualMFADevice>;
export type PutAccountPropertiesError = ConcurrentModificationException | InvalidInputException | ServiceFailureException | CommonErrors;
/**
 * Sets account-level properties for the caller's Amazon Web Services account. Account properties are
 * configuration settings that control account-wide IAM features such as Role
 * Manager.
 *
 * Specify properties as key-value pairs in
 * `Namespace/PropertyName` format. All properties in a single request must
 * belong to the same namespace. Use GetAccountProperties to view the current properties.
 */
export declare const putAccountProperties: API.OperationMethod<PutAccountPropertiesRequest, PutAccountPropertiesResponse, PutAccountPropertiesError, Credentials | HttpClient.HttpClient>;
export type PutGroupPolicyError = LimitExceededException | MalformedPolicyDocumentException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Adds or updates an inline policy document that is embedded in the specified IAM
 * group.
 *
 * A user can also have managed policies attached to it. To attach a managed policy to a
 * group, use
 * `AttachGroupPolicy`
 * . To create a new managed policy, use
 *
 * `CreatePolicy`
 * . For information about policies, see Managed
 * policies and inline policies in the
 * *IAM User Guide*.
 *
 * For information about the maximum number of inline policies that you can embed in a
 * group, see IAM and STS quotas in the *IAM User Guide*.
 *
 * Because policy documents can be large, you should use POST rather than GET when
 * calling `PutGroupPolicy`. For general information about using the Query
 * API with IAM, see Making query requests in the
 * *IAM User Guide*.
 */
export declare const putGroupPolicy: API.OperationMethod<PutGroupPolicyRequest, PutGroupPolicyResponse, PutGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type PutRolePermissionsBoundaryError = InvalidInputException | NoSuchEntityException | PolicyNotAttachableException | ServiceFailureException | UnmodifiableEntityException | CommonErrors;
/**
 * Adds or updates the policy that is specified as the IAM role's permissions boundary.
 * You can use an Amazon Web Services managed policy or a customer managed policy to set the boundary for
 * a role. Use the boundary to control the maximum permissions that the role can have.
 * Setting a permissions boundary is an advanced feature that can affect the permissions
 * for the role.
 *
 * You cannot set the boundary for a service-linked role.
 *
 * Policies used as permissions boundaries do not provide permissions. You must also
 * attach a permissions policy to the role. To learn how the effective permissions for
 * a role are evaluated, see IAM JSON policy
 * evaluation logic in the IAM User Guide.
 */
export declare const putRolePermissionsBoundary: API.OperationMethod<PutRolePermissionsBoundaryRequest, PutRolePermissionsBoundaryResponse, PutRolePermissionsBoundaryError, Credentials | HttpClient.HttpClient>;
export type PutRolePolicyError = LimitExceededException | MalformedPolicyDocumentException | NoSuchEntityException | ServiceFailureException | UnmodifiableEntityException | CommonErrors;
/**
 * Adds or updates an inline policy document that is embedded in the specified IAM
 * role.
 *
 * When you embed an inline policy in a role, the inline policy is used as part of the
 * role's access (permissions) policy. The role's trust policy is created at the same time
 * as the role, using
 * `CreateRole`
 * .
 * You can update a role's trust policy using
 * `UpdateAssumeRolePolicy`
 * . For more information about roles,
 * see IAM
 * roles in the *IAM User Guide*.
 *
 * A role can also have a managed policy attached to it. To attach a managed policy to a
 * role, use
 * `AttachRolePolicy`
 * . To create a new managed policy, use
 *
 * `CreatePolicy`
 * . For information about policies, see Managed
 * policies and inline policies in the
 * *IAM User Guide*.
 *
 * For information about the maximum number of inline policies that you can embed with a
 * role, see IAM and STS quotas in the *IAM User Guide*.
 *
 * Because policy documents can be large, you should use POST rather than GET when
 * calling `PutRolePolicy`. For general information about using the Query
 * API with IAM, see Making query requests in the
 * *IAM User Guide*.
 */
export declare const putRolePolicy: API.OperationMethod<PutRolePolicyRequest, PutRolePolicyResponse, PutRolePolicyError, Credentials | HttpClient.HttpClient>;
export type PutUserPermissionsBoundaryError = InvalidInputException | NoSuchEntityException | PolicyNotAttachableException | ServiceFailureException | CommonErrors;
/**
 * Adds or updates the policy that is specified as the IAM user's permissions
 * boundary. You can use an Amazon Web Services managed policy or a customer managed policy to set the
 * boundary for a user. Use the boundary to control the maximum permissions that the user
 * can have. Setting a permissions boundary is an advanced feature that can affect the
 * permissions for the user.
 *
 * Policies that are used as permissions boundaries do not provide permissions. You
 * must also attach a permissions policy to the user. To learn how the effective
 * permissions for a user are evaluated, see IAM JSON policy
 * evaluation logic in the IAM User Guide.
 */
export declare const putUserPermissionsBoundary: API.OperationMethod<PutUserPermissionsBoundaryRequest, PutUserPermissionsBoundaryResponse, PutUserPermissionsBoundaryError, Credentials | HttpClient.HttpClient>;
export type PutUserPolicyError = LimitExceededException | MalformedPolicyDocumentException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Adds or updates an inline policy document that is embedded in the specified IAM
 * user.
 *
 * An IAM user can also have a managed policy attached to it. To attach a managed
 * policy to a user, use
 * `AttachUserPolicy`
 * . To create a new managed policy, use
 *
 * `CreatePolicy`
 * . For information about policies, see Managed
 * policies and inline policies in the
 * *IAM User Guide*.
 *
 * For information about the maximum number of inline policies that you can embed in a
 * user, see IAM and STS quotas in the *IAM User Guide*.
 *
 * Because policy documents can be large, you should use POST rather than GET when
 * calling `PutUserPolicy`. For general information about using the Query
 * API with IAM, see Making query requests in the
 * *IAM User Guide*.
 */
export declare const putUserPolicy: API.OperationMethod<PutUserPolicyRequest, PutUserPolicyResponse, PutUserPolicyError, Credentials | HttpClient.HttpClient>;
export type RejectDelegationRequestError = ConcurrentModificationException | InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Rejects a delegation request, denying the requested temporary access.
 *
 * Once a request is rejected, it cannot be accepted or updated later. Rejected requests expire after 7 days.
 *
 * When rejecting a request, an optional explanation can be added using the `Notes` request parameter.
 *
 * For more details, see
 *
 * Managing Permissions for Delegation Requests.
 */
export declare const rejectDelegationRequest: API.OperationMethod<RejectDelegationRequestRequest, RejectDelegationRequestResponse, RejectDelegationRequestError, Credentials | HttpClient.HttpClient>;
export type RemoveClientIDFromOpenIDConnectProviderError = ConcurrentModificationException | InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Removes the specified client ID (also known as audience) from the list of client IDs
 * registered for the specified IAM OpenID Connect (OIDC) provider resource
 * object.
 *
 * This operation is idempotent; it does not fail or return an error if you try to remove
 * a client ID that does not exist.
 */
export declare const removeClientIDFromOpenIDConnectProvider: API.OperationMethod<RemoveClientIDFromOpenIDConnectProviderRequest, RemoveClientIDFromOpenIDConnectProviderResponse, RemoveClientIDFromOpenIDConnectProviderError, Credentials | HttpClient.HttpClient>;
export type RemoveRoleFromInstanceProfileError = LimitExceededException | NoSuchEntityException | ServiceFailureException | UnmodifiableEntityException | CommonErrors;
/**
 * Removes the specified IAM role from the specified Amazon EC2 instance profile.
 *
 * Make sure that you do not have any Amazon EC2 instances running with the role you are
 * about to remove from the instance profile. Removing a role from an instance profile
 * that is associated with a running instance might break any applications running on
 * the instance.
 *
 * For more information about roles, see IAM roles in the
 * *IAM User Guide*. For more information about instance profiles,
 * see Using
 * instance profiles in the *IAM User Guide*.
 */
export declare const removeRoleFromInstanceProfile: API.OperationMethod<RemoveRoleFromInstanceProfileRequest, RemoveRoleFromInstanceProfileResponse, RemoveRoleFromInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type RemoveUserFromGroupError = LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Removes the specified user from the specified group.
 */
export declare const removeUserFromGroup: API.OperationMethod<RemoveUserFromGroupRequest, RemoveUserFromGroupResponse, RemoveUserFromGroupError, Credentials | HttpClient.HttpClient>;
export type ResetServiceSpecificCredentialError = NoSuchEntityException | CommonErrors;
/**
 * Resets the password for a service-specific credential. The new password is Amazon Web Services
 * generated and cryptographically strong. It cannot be configured by the user. Resetting
 * the password immediately invalidates the previous password associated with this
 * user.
 */
export declare const resetServiceSpecificCredential: API.OperationMethod<ResetServiceSpecificCredentialRequest, ResetServiceSpecificCredentialResponse, ResetServiceSpecificCredentialError, Credentials | HttpClient.HttpClient>;
export type ResyncMFADeviceError = ConcurrentModificationException | InvalidAuthenticationCodeException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Synchronizes the specified MFA device with its IAM resource object on the Amazon Web Services
 * servers.
 *
 * For more information about creating and working with virtual MFA devices, see Using a virtual MFA
 * device in the *IAM User Guide*.
 */
export declare const resyncMFADevice: API.OperationMethod<ResyncMFADeviceRequest, ResyncMFADeviceResponse, ResyncMFADeviceError, Credentials | HttpClient.HttpClient>;
export type SendDelegationTokenError = ConcurrentModificationException | InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Sends the exchange token for an accepted delegation request.
 *
 * The exchange token is sent to the partner via an asynchronous notification channel, established by the partner.
 *
 * The delegation request must be in the `ACCEPTED` state when calling this API. After the
 * `SendDelegationToken` API
 * call is successful, the request transitions to a `FINALIZED` state and cannot be rolled back. However, a user may reject
 * an accepted request before the `SendDelegationToken` API is called.
 *
 * For more details, see
 *
 * Managing Permissions for Delegation Requests.
 */
export declare const sendDelegationToken: API.OperationMethod<SendDelegationTokenRequest, SendDelegationTokenResponse, SendDelegationTokenError, Credentials | HttpClient.HttpClient>;
export type SetDefaultPolicyVersionError = InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Sets the specified version of the specified policy as the policy's default (operative)
 * version.
 *
 * This operation affects all users, groups, and roles that the policy is attached to. To
 * list the users, groups, and roles that the policy is attached to, use ListEntitiesForPolicy.
 *
 * For information about managed policies, see Managed policies and inline
 * policies in the *IAM User Guide*.
 */
export declare const setDefaultPolicyVersion: API.OperationMethod<SetDefaultPolicyVersionRequest, SetDefaultPolicyVersionResponse, SetDefaultPolicyVersionError, Credentials | HttpClient.HttpClient>;
export type SetSecurityTokenServicePreferencesError = ServiceFailureException | CommonErrors;
/**
 * Sets the specified version of the global endpoint token as the token version used for
 * the Amazon Web Services account.
 *
 * By default, Security Token Service (STS) is available as a global service, and all STS requests
 * go to a single endpoint at `https://sts.amazonaws.com`. Amazon Web Services recommends
 * using Regional STS endpoints to reduce latency, build in redundancy, and increase
 * session token availability. For information about Regional endpoints for STS, see
 * Security Token Service
 * endpoints and quotas in the *Amazon Web Services General Reference*.
 *
 * If you make an STS call to the global endpoint, the resulting session tokens might
 * be valid in some Regions but not others. It depends on the version that is set in this
 * operation. Version 1 tokens are valid only in Amazon Web Services Regions that are
 * available by default. These tokens do not work in manually enabled Regions, such as Asia
 * Pacific (Hong Kong). Version 2 tokens are valid in all Regions. However, version 2
 * tokens are longer and might affect systems where you temporarily store tokens. For
 * information, see Activating and
 * deactivating STS in an Amazon Web Services Region in the
 * *IAM User Guide*.
 *
 * To view the current session token version, see the
 * `GlobalEndpointTokenVersion` entry in the response of the GetAccountSummary operation.
 */
export declare const setSecurityTokenServicePreferences: API.OperationMethod<SetSecurityTokenServicePreferencesRequest, SetSecurityTokenServicePreferencesResponse, SetSecurityTokenServicePreferencesError, Credentials | HttpClient.HttpClient>;
export type SimulateCustomPolicyError = InvalidInputException | PolicyEvaluationException | CommonErrors;
/**
 * Simulate how a set of IAM policies and optionally a resource-based policy works with
 * a list of API operations and Amazon Web Services resources to determine the policies' effective
 * permissions. The policies are provided as strings.
 *
 * The simulation does not perform the API operations; it only checks the authorization
 * to determine if the simulated policies allow or deny the operations. You can simulate
 * resources that don't exist in your account.
 *
 * If you want to simulate existing policies that are attached to an IAM user, group,
 * or role, use SimulatePrincipalPolicy instead.
 *
 * Context keys are variables that are maintained by Amazon Web Services and its services and which
 * provide details about the context of an API query request. You can use the
 * `Condition` element of an IAM policy to evaluate context keys. To get
 * the list of context keys that the policies require for correct simulation, use GetContextKeysForCustomPolicy.
 *
 * If the output is long, you can use `MaxItems` and `Marker`
 * parameters to paginate the results.
 *
 * The IAM policy simulator evaluates statements in identity-based policies,
 * service control policies (SCPs) including their condition keys and resource
 * scoping, and the inputs that you provide during simulation. The policy
 * simulator results can differ from your live Amazon Web Services environment. We recommend that you check your policies
 * against your live Amazon Web Services environment after testing using the policy simulator to
 * confirm that you have the desired results. For more information about using the
 * policy simulator, see Testing IAM
 * policies with the IAM policy simulator in the
 * *IAM User Guide*.
 */
export declare const simulateCustomPolicy: API.PaginatedOperationMethod<SimulateCustomPolicyRequest, SimulatePolicyResponse, SimulateCustomPolicyError, Credentials | HttpClient.HttpClient, EvaluationResult>;
export type SimulatePrincipalPolicyError = InvalidInputException | NoSuchEntityException | PolicyEvaluationException | CommonErrors;
/**
 * Simulate how a set of IAM policies attached to an IAM entity works with a list of
 * API operations and Amazon Web Services resources to determine the policies' effective permissions. The
 * entity can be an IAM user, group, or role. If you specify a user, then the simulation
 * also includes all of the policies that are attached to groups that the user belongs to.
 * You can simulate resources that don't exist in your account.
 *
 * You can optionally include a list of one or more additional policies specified as
 * strings to include in the simulation. If you want to simulate only policies specified as
 * strings, use SimulateCustomPolicy instead.
 *
 * You can also optionally include one resource-based policy to be evaluated with each of
 * the resources included in the simulation for IAM users only.
 *
 * The simulation does not perform the API operations; it only checks the authorization
 * to determine if the simulated policies allow or deny the operations.
 *
 * For cross-account simulations, `EvalDecisionDetails` returns the decision
 * for each policy type (identity-based policy, resource-based policy, and permissions
 * boundary). This helps you identify which policy type is responsible for an allow or
 * deny decision when policies span multiple accounts.
 *
 * **Note:** This operation discloses information about the
 * permissions granted to other users. If you do not want users to see other user's
 * permissions, then consider allowing them to use SimulateCustomPolicy instead.
 *
 * Context keys are variables maintained by Amazon Web Services and its services that provide details
 * about the context of an API query request. You can use the `Condition`
 * element of an IAM policy to evaluate context keys. To get the list of context keys
 * that the policies require for correct simulation, use GetContextKeysForPrincipalPolicy.
 *
 * If the output is long, you can use the `MaxItems` and `Marker`
 * parameters to paginate the results.
 *
 * The IAM policy simulator evaluates statements in identity-based policies,
 * service control policies (SCPs) including their condition keys and resource
 * scoping, and the inputs that you provide during simulation. The policy
 * simulator results can differ from your live Amazon Web Services environment. We recommend that you check your policies
 * against your live Amazon Web Services environment after testing using the policy simulator to
 * confirm that you have the desired results. For more information about using the
 * policy simulator, see Testing IAM
 * policies with the IAM policy simulator in the
 * *IAM User Guide*.
 */
export declare const simulatePrincipalPolicy: API.PaginatedOperationMethod<SimulatePrincipalPolicyRequest, SimulatePolicyResponse, SimulatePrincipalPolicyError, Credentials | HttpClient.HttpClient, EvaluationResult>;
export type TagInstanceProfileError = ConcurrentModificationException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Adds one or more tags to an IAM instance profile. If a tag with the same key name
 * already exists, then that tag is overwritten with the new value.
 *
 * Each tag consists of a key name and an associated value. By assigning tags to your resources, you can do the
 * following:
 *
 * - **Administrative grouping and discovery** - Attach
 * tags to resources to aid in organization and search. For example, you could search for all
 * resources with the key name *Project* and the value
 * *MyImportantProject*. Or search for all resources with the key name
 * *Cost Center* and the value *41200*.
 *
 * - **Access control** - Include tags in IAM user-based
 * and resource-based policies. You can use tags to restrict access to only an IAM instance
 * profile that has a specified tag attached. For examples of policies that show how to use
 * tags to control access, see Control access using IAM tags in the
 * *IAM User Guide*.
 *
 * - If any one of the tags is invalid or if you exceed the allowed maximum number of tags, then the entire request
 * fails and the resource is not created. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 *
 * - Amazon Web Services always interprets the tag `Value` as a single string. If you
 * need to store an array, you can store comma-separated values in the string. However, you
 * must interpret the value in your code.
 */
export declare const tagInstanceProfile: API.OperationMethod<TagInstanceProfileRequest, TagInstanceProfileResponse, TagInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type TagMFADeviceError = ConcurrentModificationException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Adds one or more tags to an IAM virtual multi-factor authentication (MFA) device. If
 * a tag with the same key name already exists, then that tag is overwritten with the new
 * value.
 *
 * A tag consists of a key name and an associated value. By assigning tags to your
 * resources, you can do the following:
 *
 * - **Administrative grouping and discovery** - Attach
 * tags to resources to aid in organization and search. For example, you could search for all
 * resources with the key name *Project* and the value
 * *MyImportantProject*. Or search for all resources with the key name
 * *Cost Center* and the value *41200*.
 *
 * - **Access control** - Include tags in IAM user-based
 * and resource-based policies. You can use tags to restrict access to only an IAM virtual
 * MFA device that has a specified tag attached. For examples of policies that show how to
 * use tags to control access, see Control access using IAM tags in the
 * *IAM User Guide*.
 *
 * - If any one of the tags is invalid or if you exceed the allowed maximum number of tags, then the entire request
 * fails and the resource is not created. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 *
 * - Amazon Web Services always interprets the tag `Value` as a single string. If you
 * need to store an array, you can store comma-separated values in the string. However, you
 * must interpret the value in your code.
 */
export declare const tagMFADevice: API.OperationMethod<TagMFADeviceRequest, TagMFADeviceResponse, TagMFADeviceError, Credentials | HttpClient.HttpClient>;
export type TagOpenIDConnectProviderError = ConcurrentModificationException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Adds one or more tags to an OpenID Connect (OIDC)-compatible identity provider. For
 * more information about these providers, see About web identity federation. If
 * a tag with the same key name already exists, then that tag is overwritten with the new
 * value.
 *
 * A tag consists of a key name and an associated value. By assigning tags to your
 * resources, you can do the following:
 *
 * - **Administrative grouping and discovery** - Attach
 * tags to resources to aid in organization and search. For example, you could search for all
 * resources with the key name *Project* and the value
 * *MyImportantProject*. Or search for all resources with the key name
 * *Cost Center* and the value *41200*.
 *
 * - **Access control** - Include tags in IAM identity-based
 * and resource-based policies. You can use tags to restrict access to only an OIDC provider
 * that has a specified tag attached. For examples of policies that show how to use tags to
 * control access, see Control access using IAM tags in the
 * *IAM User Guide*.
 *
 * - If any one of the tags is invalid or if you exceed the allowed maximum number of tags, then the entire request
 * fails and the resource is not created. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 *
 * - Amazon Web Services always interprets the tag `Value` as a single string. If you
 * need to store an array, you can store comma-separated values in the string. However, you
 * must interpret the value in your code.
 */
export declare const tagOpenIDConnectProvider: API.OperationMethod<TagOpenIDConnectProviderRequest, TagOpenIDConnectProviderResponse, TagOpenIDConnectProviderError, Credentials | HttpClient.HttpClient>;
export type TagPolicyError = ConcurrentModificationException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Adds one or more tags to an IAM customer managed policy. If a tag with the same key
 * name already exists, then that tag is overwritten with the new value.
 *
 * A tag consists of a key name and an associated value. By assigning tags to your
 * resources, you can do the following:
 *
 * - **Administrative grouping and discovery** - Attach
 * tags to resources to aid in organization and search. For example, you could search for all
 * resources with the key name *Project* and the value
 * *MyImportantProject*. Or search for all resources with the key name
 * *Cost Center* and the value *41200*.
 *
 * - **Access control** - Include tags in IAM user-based
 * and resource-based policies. You can use tags to restrict access to only an IAM customer
 * managed policy that has a specified tag attached. For examples of policies that show how
 * to use tags to control access, see Control access using IAM tags in the
 * *IAM User Guide*.
 *
 * - If any one of the tags is invalid or if you exceed the allowed maximum number of tags, then the entire request
 * fails and the resource is not created. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 *
 * - Amazon Web Services always interprets the tag `Value` as a single string. If you
 * need to store an array, you can store comma-separated values in the string. However, you
 * must interpret the value in your code.
 */
export declare const tagPolicy: API.OperationMethod<TagPolicyRequest, TagPolicyResponse, TagPolicyError, Credentials | HttpClient.HttpClient>;
export type TagRoleError = ConcurrentModificationException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Adds one or more tags to an IAM role. The role can be a regular role or a
 * service-linked role. If a tag with the same key name already exists, then that tag is
 * overwritten with the new value.
 *
 * A tag consists of a key name and an associated value. By assigning tags to your
 * resources, you can do the following:
 *
 * - **Administrative grouping and discovery** - Attach
 * tags to resources to aid in organization and search. For example, you could search for all
 * resources with the key name *Project* and the value
 * *MyImportantProject*. Or search for all resources with the key name
 * *Cost Center* and the value *41200*.
 *
 * - **Access control** - Include tags in IAM user-based
 * and resource-based policies. You can use tags to restrict access to only an IAM role
 * that has a specified tag attached. You can also restrict access to only those resources
 * that have a certain tag attached. For examples of policies that show how to use tags to
 * control access, see Control access using IAM tags in the
 * *IAM User Guide*.
 *
 * - **Cost allocation** - Use tags to help track which
 * individuals and teams are using which Amazon Web Services resources.
 *
 * - If any one of the tags is invalid or if you exceed the allowed maximum number of tags, then the entire request
 * fails and the resource is not created. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 *
 * - Amazon Web Services always interprets the tag `Value` as a single string. If you
 * need to store an array, you can store comma-separated values in the string. However, you
 * must interpret the value in your code.
 *
 * For more information about tagging, see Tagging IAM identities in the
 * *IAM User Guide*.
 */
export declare const tagRole: API.OperationMethod<TagRoleRequest, TagRoleResponse, TagRoleError, Credentials | HttpClient.HttpClient>;
export type TagSAMLProviderError = ConcurrentModificationException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Adds one or more tags to a Security Assertion Markup Language (SAML) identity provider.
 * For more information about these providers, see About SAML 2.0-based federation .
 * If a tag with the same key name already exists, then that tag is overwritten with the new
 * value.
 *
 * A tag consists of a key name and an associated value. By assigning tags to your
 * resources, you can do the following:
 *
 * - **Administrative grouping and discovery** - Attach
 * tags to resources to aid in organization and search. For example, you could search for all
 * resources with the key name *Project* and the value
 * *MyImportantProject*. Or search for all resources with the key name
 * *Cost Center* and the value *41200*.
 *
 * - **Access control** - Include tags in IAM user-based
 * and resource-based policies. You can use tags to restrict access to only a SAML identity
 * provider that has a specified tag attached. For examples of policies that show how to use
 * tags to control access, see Control access using IAM tags in the
 * *IAM User Guide*.
 *
 * - If any one of the tags is invalid or if you exceed the allowed maximum number of tags, then the entire request
 * fails and the resource is not created. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 *
 * - Amazon Web Services always interprets the tag `Value` as a single string. If you
 * need to store an array, you can store comma-separated values in the string. However, you
 * must interpret the value in your code.
 */
export declare const tagSAMLProvider: API.OperationMethod<TagSAMLProviderRequest, TagSAMLProviderResponse, TagSAMLProviderError, Credentials | HttpClient.HttpClient>;
export type TagServerCertificateError = ConcurrentModificationException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Adds one or more tags to an IAM server certificate. If a tag with the same key name
 * already exists, then that tag is overwritten with the new value.
 *
 * For certificates in a Region supported by Certificate Manager (ACM), we
 * recommend that you don't use IAM server certificates. Instead, use ACM to provision,
 * manage, and deploy your server certificates. For more information about IAM server
 * certificates, Working with server
 * certificates in the *IAM User Guide*.
 *
 * A tag consists of a key name and an associated value. By assigning tags to your
 * resources, you can do the following:
 *
 * - **Administrative grouping and discovery** - Attach
 * tags to resources to aid in organization and search. For example, you could search for all
 * resources with the key name *Project* and the value
 * *MyImportantProject*. Or search for all resources with the key name
 * *Cost Center* and the value *41200*.
 *
 * - **Access control** - Include tags in IAM user-based
 * and resource-based policies. You can use tags to restrict access to only a server
 * certificate that has a specified tag attached. For examples of policies that show how to
 * use tags to control access, see Control access using IAM tags in the
 * *IAM User Guide*.
 *
 * - **Cost allocation** - Use tags to help track which
 * individuals and teams are using which Amazon Web Services resources.
 *
 * - If any one of the tags is invalid or if you exceed the allowed maximum number of tags, then the entire request
 * fails and the resource is not created. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 *
 * - Amazon Web Services always interprets the tag `Value` as a single string. If you
 * need to store an array, you can store comma-separated values in the string. However, you
 * must interpret the value in your code.
 */
export declare const tagServerCertificate: API.OperationMethod<TagServerCertificateRequest, TagServerCertificateResponse, TagServerCertificateError, Credentials | HttpClient.HttpClient>;
export type TagUserError = ConcurrentModificationException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Adds one or more tags to an IAM user. If a tag with the same key name already exists,
 * then that tag is overwritten with the new value.
 *
 * A tag consists of a key name and an associated value. By assigning tags to your
 * resources, you can do the following:
 *
 * - **Administrative grouping and discovery** - Attach
 * tags to resources to aid in organization and search. For example, you could search for all
 * resources with the key name *Project* and the value
 * *MyImportantProject*. Or search for all resources with the key name
 * *Cost Center* and the value *41200*.
 *
 * - **Access control** - Include tags in IAM identity-based
 * and resource-based policies. You can use tags to restrict access to only an IAM
 * requesting user that has a specified tag attached. You can also restrict access to only
 * those resources that have a certain tag attached. For examples of policies that show how
 * to use tags to control access, see Control access using IAM tags in the
 * *IAM User Guide*.
 *
 * - **Cost allocation** - Use tags to help track which
 * individuals and teams are using which Amazon Web Services resources.
 *
 * - If any one of the tags is invalid or if you exceed the allowed maximum number of tags, then the entire request
 * fails and the resource is not created. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 *
 * - Amazon Web Services always interprets the tag `Value` as a single string. If you
 * need to store an array, you can store comma-separated values in the string. However, you
 * must interpret the value in your code.
 *
 * For more information about tagging, see Tagging IAM identities in the
 * *IAM User Guide*.
 */
export declare const tagUser: API.OperationMethod<TagUserRequest, TagUserResponse, TagUserError, Credentials | HttpClient.HttpClient>;
export type UntagInstanceProfileError = ConcurrentModificationException | InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Removes the specified tags from the IAM instance profile. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const untagInstanceProfile: API.OperationMethod<UntagInstanceProfileRequest, UntagInstanceProfileResponse, UntagInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type UntagMFADeviceError = ConcurrentModificationException | InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Removes the specified tags from the IAM virtual multi-factor authentication (MFA)
 * device. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const untagMFADevice: API.OperationMethod<UntagMFADeviceRequest, UntagMFADeviceResponse, UntagMFADeviceError, Credentials | HttpClient.HttpClient>;
export type UntagOpenIDConnectProviderError = ConcurrentModificationException | InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Removes the specified tags from the specified OpenID Connect (OIDC)-compatible identity
 * provider in IAM. For more information about OIDC providers, see About web identity federation.
 * For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const untagOpenIDConnectProvider: API.OperationMethod<UntagOpenIDConnectProviderRequest, UntagOpenIDConnectProviderResponse, UntagOpenIDConnectProviderError, Credentials | HttpClient.HttpClient>;
export type UntagPolicyError = ConcurrentModificationException | InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Removes the specified tags from the customer managed policy. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const untagPolicy: API.OperationMethod<UntagPolicyRequest, UntagPolicyResponse, UntagPolicyError, Credentials | HttpClient.HttpClient>;
export type UntagRoleError = ConcurrentModificationException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Removes the specified tags from the role. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const untagRole: API.OperationMethod<UntagRoleRequest, UntagRoleResponse, UntagRoleError, Credentials | HttpClient.HttpClient>;
export type UntagSAMLProviderError = ConcurrentModificationException | InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Removes the specified tags from the specified Security Assertion Markup Language (SAML)
 * identity provider in IAM. For more information about these providers, see About web identity
 * federation. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const untagSAMLProvider: API.OperationMethod<UntagSAMLProviderRequest, UntagSAMLProviderResponse, UntagSAMLProviderError, Credentials | HttpClient.HttpClient>;
export type UntagServerCertificateError = ConcurrentModificationException | InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Removes the specified tags from the IAM server certificate.
 * For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 *
 * For certificates in a Region supported by Certificate Manager (ACM), we
 * recommend that you don't use IAM server certificates. Instead, use ACM to provision,
 * manage, and deploy your server certificates. For more information about IAM server
 * certificates, Working with server
 * certificates in the *IAM User Guide*.
 */
export declare const untagServerCertificate: API.OperationMethod<UntagServerCertificateRequest, UntagServerCertificateResponse, UntagServerCertificateError, Credentials | HttpClient.HttpClient>;
export type UntagUserError = ConcurrentModificationException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Removes the specified tags from the user. For more information about tagging, see Tagging IAM resources in the
 * *IAM User Guide*.
 */
export declare const untagUser: API.OperationMethod<UntagUserRequest, UntagUserResponse, UntagUserError, Credentials | HttpClient.HttpClient>;
export type UpdateAccessKeyError = InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Changes the status of the specified access key from Active to Inactive, or vice versa.
 * This operation can be used to disable a user's key as part of a key rotation
 * workflow.
 *
 * If the `UserName` is not specified, the user name is determined implicitly
 * based on the Amazon Web Services access key ID used to sign the request. If a temporary access key is
 * used, then `UserName` is required. If a long-term key is assigned to the
 * user, then `UserName` is not required. This operation works for access keys
 * under the Amazon Web Services account. Consequently, you can use this operation to manage Amazon Web Services account root user
 * credentials even if the Amazon Web Services account has no associated users.
 *
 * For information about rotating keys, see Managing keys and certificates
 * in the *IAM User Guide*.
 */
export declare const updateAccessKey: API.OperationMethod<UpdateAccessKeyRequest, UpdateAccessKeyResponse, UpdateAccessKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountPasswordPolicyError = LimitExceededException | MalformedPolicyDocumentException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Updates the password policy settings for the Amazon Web Services account.
 *
 * This operation does not support partial updates. No parameters are required, but
 * if you do not specify a parameter, that parameter's value reverts to its default
 * value. See the **Request Parameters** section for each
 * parameter's default value. Also note that some parameters do not allow the default
 * parameter to be explicitly set. Instead, to invoke the default value, do not include
 * that parameter when you invoke the operation.
 *
 * For more information about using a password policy, see Managing an IAM password
 * policy in the *IAM User Guide*.
 */
export declare const updateAccountPasswordPolicy: API.OperationMethod<UpdateAccountPasswordPolicyRequest, UpdateAccountPasswordPolicyResponse, UpdateAccountPasswordPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateAssumeRolePolicyError = LimitExceededException | MalformedPolicyDocumentException | NoSuchEntityException | ServiceFailureException | UnmodifiableEntityException | CommonErrors;
/**
 * Updates the policy that grants an IAM entity permission to assume a role. This is
 * typically referred to as the "role trust policy". For more information about roles, see
 * Using roles to
 * delegate permissions and federate identities.
 */
export declare const updateAssumeRolePolicy: API.OperationMethod<UpdateAssumeRolePolicyRequest, UpdateAssumeRolePolicyResponse, UpdateAssumeRolePolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateDelegationRequestError = ConcurrentModificationException | InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Updates an existing delegation request with additional information. When the delegation
 * request is updated, it reaches the `PENDING_APPROVAL` state.
 *
 * Once a delegation request has an owner, that owner gets a default permission to update the
 * delegation request. For more details, see
 *
 * Managing Permissions for Delegation Requests.
 */
export declare const updateDelegationRequest: API.OperationMethod<UpdateDelegationRequestRequest, UpdateDelegationRequestResponse, UpdateDelegationRequestError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupError = EntityAlreadyExistsException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Updates the name and/or the path of the specified IAM group.
 *
 * You should understand the implications of changing a group's path or name. For
 * more information, see Renaming users and
 * groups in the *IAM User Guide*.
 *
 * The person making the request (the principal), must have permission to change the
 * role group with the old name and the new name. For example, to change the group
 * named `Managers` to `MGRs`, the principal must have a policy
 * that allows them to update both groups. If the principal has permission to update
 * the `Managers` group, but not the `MGRs` group, then the
 * update fails. For more information about permissions, see Access management.
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest, UpdateGroupResponse, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateLoginProfileError = EntityTemporarilyUnmodifiableException | LimitExceededException | NoSuchEntityException | PasswordPolicyViolationException | ServiceFailureException | CommonErrors;
/**
 * Changes the password for the specified IAM user. You can use the CLI, the Amazon Web Services
 * API, or the **Users** page in the IAM console to change
 * the password for any IAM user. Use ChangePassword to
 * change your own password in the **My Security Credentials**
 * page in the Amazon Web Services Management Console.
 *
 * For more information about modifying passwords, see Managing passwords in the
 * *IAM User Guide*.
 */
export declare const updateLoginProfile: API.OperationMethod<UpdateLoginProfileRequest, UpdateLoginProfileResponse, UpdateLoginProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateOpenIDConnectProviderThumbprintError = ConcurrentModificationException | InvalidInputException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Replaces the existing list of server certificate thumbprints associated with an OpenID
 * Connect (OIDC) provider resource object with a new list of thumbprints.
 *
 * The list that you pass with this operation completely replaces the existing list of
 * thumbprints. (The lists are not merged.)
 *
 * Typically, you need to update a thumbprint only when the identity provider certificate
 * changes, which occurs rarely. However, if the provider's certificate
 * *does* change, any attempt to assume an IAM role that specifies
 * the OIDC provider as a principal fails until the certificate thumbprint is
 * updated.
 *
 * Amazon Web Services secures communication with OIDC identity providers (IdPs) using our library of
 * trusted root certificate authorities (CAs) to verify the JSON Web Key Set (JWKS)
 * endpoint's TLS certificate. If your OIDC IdP relies on a certificate that is not signed
 * by one of these trusted CAs, only then we secure communication using the thumbprints set
 * in the IdP's configuration.
 *
 * Trust for the OIDC provider is derived from the provider certificate and is
 * validated by the thumbprint. Therefore, it is best to limit access to the
 * `UpdateOpenIDConnectProviderThumbprint` operation to highly
 * privileged users.
 */
export declare const updateOpenIDConnectProviderThumbprint: API.OperationMethod<UpdateOpenIDConnectProviderThumbprintRequest, UpdateOpenIDConnectProviderThumbprintResponse, UpdateOpenIDConnectProviderThumbprintError, Credentials | HttpClient.HttpClient>;
export type UpdateRoleError = NoSuchEntityException | ServiceFailureException | UnmodifiableEntityException | CommonErrors;
/**
 * Updates the description or maximum session duration setting of a role.
 */
export declare const updateRole: API.OperationMethod<UpdateRoleRequest, UpdateRoleResponse, UpdateRoleError, Credentials | HttpClient.HttpClient>;
export type UpdateRoleDescriptionError = NoSuchEntityException | ServiceFailureException | UnmodifiableEntityException | CommonErrors;
/**
 * Use UpdateRole instead.
 *
 * Modifies only the description of a role. This operation performs the same function as
 * the `Description` parameter in the `UpdateRole` operation.
 */
export declare const updateRoleDescription: API.OperationMethod<UpdateRoleDescriptionRequest, UpdateRoleDescriptionResponse, UpdateRoleDescriptionError, Credentials | HttpClient.HttpClient>;
export type UpdateSAMLProviderError = ConcurrentModificationException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Updates the metadata document, SAML encryption settings, and private keys for an
 * existing SAML provider. To rotate private keys, add your new private key and then remove
 * the old key in a separate request.
 */
export declare const updateSAMLProvider: API.OperationMethod<UpdateSAMLProviderRequest, UpdateSAMLProviderResponse, UpdateSAMLProviderError, Credentials | HttpClient.HttpClient>;
export type UpdateServerCertificateError = EntityAlreadyExistsException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Updates the name and/or the path of the specified server certificate stored in
 * IAM.
 *
 * For more information about working with server certificates, see Working
 * with server certificates in the *IAM User Guide*. This
 * topic also includes a list of Amazon Web Services services that can use the server certificates that
 * you manage with IAM.
 *
 * You should understand the implications of changing a server certificate's path or
 * name. For more information, see Renaming a server certificate in the
 * *IAM User Guide*.
 *
 * The person making the request (the principal), must have permission to change the
 * server certificate with the old name and the new name. For example, to change the
 * certificate named `ProductionCert` to `ProdCert`, the
 * principal must have a policy that allows them to update both certificates. If the
 * principal has permission to update the `ProductionCert` group, but not
 * the `ProdCert` certificate, then the update fails. For more information
 * about permissions, see Access management in the *IAM User Guide*.
 */
export declare const updateServerCertificate: API.OperationMethod<UpdateServerCertificateRequest, UpdateServerCertificateResponse, UpdateServerCertificateError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceSpecificCredentialError = NoSuchEntityException | CommonErrors;
/**
 * Sets the status of a service-specific credential to `Active` or
 * `Inactive`. Service-specific credentials that are inactive cannot be used
 * for authentication to the service. This operation can be used to disable a user's
 * service-specific credential as part of a credential rotation work flow.
 */
export declare const updateServiceSpecificCredential: API.OperationMethod<UpdateServiceSpecificCredentialRequest, UpdateServiceSpecificCredentialResponse, UpdateServiceSpecificCredentialError, Credentials | HttpClient.HttpClient>;
export type UpdateSigningCertificateError = InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Changes the status of the specified user signing certificate from active to disabled,
 * or vice versa. This operation can be used to disable an IAM user's signing
 * certificate as part of a certificate rotation work flow.
 *
 * If the `UserName` field is not specified, the user name is determined
 * implicitly based on the Amazon Web Services access key ID used to sign the request. This operation
 * works for access keys under the Amazon Web Services account. Consequently, you can use this operation
 * to manage Amazon Web Services account root user credentials even if the Amazon Web Services account has no associated
 * users.
 */
export declare const updateSigningCertificate: API.OperationMethod<UpdateSigningCertificateRequest, UpdateSigningCertificateResponse, UpdateSigningCertificateError, Credentials | HttpClient.HttpClient>;
export type UpdateSSHPublicKeyError = InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Sets the status of an IAM user's SSH public key to active or inactive. SSH public
 * keys that are inactive cannot be used for authentication. This operation can be used to
 * disable a user's SSH public key as part of a key rotation work flow.
 *
 * The SSH public key affected by this operation is used only for authenticating the
 * associated IAM user to an CodeCommit repository. For more information about using SSH keys
 * to authenticate to an CodeCommit repository, see Set up CodeCommit for
 * SSH connections in the *CodeCommit User Guide*.
 */
export declare const updateSSHPublicKey: API.OperationMethod<UpdateSSHPublicKeyRequest, UpdateSSHPublicKeyResponse, UpdateSSHPublicKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = ConcurrentModificationException | EntityAlreadyExistsException | EntityTemporarilyUnmodifiableException | LimitExceededException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Updates the name and/or the path of the specified IAM user.
 *
 * You should understand the implications of changing an IAM user's path or
 * name. For more information, see Renaming an IAM
 * user and Renaming an IAM
 * group in the *IAM User Guide*.
 *
 * To change a user name, the requester must have appropriate permissions on both
 * the source object and the target object. For example, to change Bob to Robert, the
 * entity making the request must have permission on Bob and Robert, or must have
 * permission on all (*). For more information about permissions, see Permissions and policies.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export type UploadServerCertificateError = ConcurrentModificationException | EntityAlreadyExistsException | InvalidInputException | KeyPairMismatchException | LimitExceededException | MalformedCertificateException | ServiceFailureException | CommonErrors;
/**
 * Uploads a server certificate entity for the Amazon Web Services account. The server certificate
 * entity includes a public key certificate, a private key, and an optional certificate
 * chain, which should all be PEM-encoded.
 *
 * We recommend that you use Certificate Manager to
 * provision, manage, and deploy your server certificates. With ACM you can request a
 * certificate, deploy it to Amazon Web Services resources, and let ACM handle certificate renewals for
 * you. Certificates provided by ACM are free. For more information about using ACM,
 * see the Certificate Manager User
 * Guide.
 *
 * For more information about working with server certificates, see Working
 * with server certificates in the *IAM User Guide*. This
 * topic includes a list of Amazon Web Services services that can use the server certificates that you
 * manage with IAM.
 *
 * For information about the number of server certificates you can upload, see IAM and STS
 * quotas in the *IAM User Guide*.
 *
 * Because the body of the public key certificate, private key, and the certificate
 * chain can be large, you should use POST rather than GET when calling
 * `UploadServerCertificate`. For information about setting up
 * signatures and authorization through the API, see Signing Amazon Web Services API
 * requests in the *Amazon Web Services General Reference*. For general
 * information about using the Query API with IAM, see Calling the API by making HTTP query
 * requests in the *IAM User Guide*.
 */
export declare const uploadServerCertificate: API.OperationMethod<UploadServerCertificateRequest, UploadServerCertificateResponse, UploadServerCertificateError, Credentials | HttpClient.HttpClient>;
export type UploadSigningCertificateError = ConcurrentModificationException | DuplicateCertificateException | EntityAlreadyExistsException | InvalidCertificateException | LimitExceededException | MalformedCertificateException | NoSuchEntityException | ServiceFailureException | CommonErrors;
/**
 * Uploads an X.509 signing certificate and associates it with the specified IAM user.
 * Some Amazon Web Services services require you to use certificates to validate requests that are signed
 * with a corresponding private key. When you upload the certificate, its default status is
 * `Active`.
 *
 * For information about when you would use an X.509 signing certificate, see Managing
 * server certificates in IAM in the
 * *IAM User Guide*.
 *
 * If the `UserName` is not specified, the IAM user name is determined
 * implicitly based on the Amazon Web Services access key ID used to sign the request. This operation
 * works for access keys under the Amazon Web Services account. Consequently, you can use this operation
 * to manage Amazon Web Services account root user credentials even if the Amazon Web Services account has no associated
 * users.
 *
 * Because the body of an X.509 certificate can be large, you should use POST rather
 * than GET when calling `UploadSigningCertificate`. For information about
 * setting up signatures and authorization through the API, see Signing
 * Amazon Web Services API requests in the *Amazon Web Services General Reference*. For
 * general information about using the Query API with IAM, see Making query
 * requests in the *IAM User Guide*.
 */
export declare const uploadSigningCertificate: API.OperationMethod<UploadSigningCertificateRequest, UploadSigningCertificateResponse, UploadSigningCertificateError, Credentials | HttpClient.HttpClient>;
export type UploadSSHPublicKeyError = DuplicateSSHPublicKeyException | InvalidPublicKeyException | LimitExceededException | NoSuchEntityException | UnrecognizedPublicKeyEncodingException | CommonErrors;
/**
 * Uploads an SSH public key and associates it with the specified IAM user.
 *
 * The SSH public key uploaded by this operation can be used only for authenticating the
 * associated IAM user to an CodeCommit repository. For more information about using SSH keys
 * to authenticate to an CodeCommit repository, see Set up CodeCommit for
 * SSH connections in the *CodeCommit User Guide*.
 */
export declare const uploadSSHPublicKey: API.OperationMethod<UploadSSHPublicKeyRequest, UploadSSHPublicKeyResponse, UploadSSHPublicKeyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iam.d.ts.map