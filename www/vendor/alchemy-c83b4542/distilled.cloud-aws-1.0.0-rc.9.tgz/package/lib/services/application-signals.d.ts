import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly ResourceType: any;
    readonly ResourceId: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type InstrumentationType = "BREAKPOINT" | "PROBE" | (string & {});
export declare const InstrumentationType: any;
export interface BatchDeleteScope {
    Service: string;
    Environment: string;
    InstrumentationType: InstrumentationType;
}
export declare const BatchDeleteScope: S.Schema<BatchDeleteScope>;
export type BatchDeleteResourceArnList = string[];
export declare const BatchDeleteResourceArnList: any;
export interface BatchDeleteByResourceArns {
    ResourceArns: string[];
    InstrumentationType: InstrumentationType;
}
export declare const BatchDeleteByResourceArns: S.Schema<BatchDeleteByResourceArns>;
export type BatchDeleteDeletionTarget = {
    Scope: BatchDeleteScope;
    ResourceArns?: never;
} | {
    Scope?: never;
    ResourceArns: BatchDeleteByResourceArns;
};
export declare const BatchDeleteDeletionTarget: any;
export interface BatchDeleteInstrumentationConfigurationsRequest {
    DeletionTarget: BatchDeleteDeletionTarget;
}
export declare const BatchDeleteInstrumentationConfigurationsRequest: S.Schema<BatchDeleteInstrumentationConfigurationsRequest>;
export interface BatchDeleteSuccessfulDeletion {
    ResourceArn?: string;
    SignalType?: string;
    LocationHash?: string;
}
export declare const BatchDeleteSuccessfulDeletion: S.Schema<BatchDeleteSuccessfulDeletion>;
export type BatchDeleteSuccessfulDeletionList = BatchDeleteSuccessfulDeletion[];
export declare const BatchDeleteSuccessfulDeletionList: any;
export type BatchDeleteErrorCode = "ResourceNotFoundException" | "AccessDeniedException" | "InternalServiceException" | (string & {});
export declare const BatchDeleteErrorCode: any;
export interface BatchDeleteError {
    ResourceArn: string;
    Code: BatchDeleteErrorCode;
    Message: string;
}
export declare const BatchDeleteError: S.Schema<BatchDeleteError>;
export type BatchDeleteErrorList = BatchDeleteError[];
export declare const BatchDeleteErrorList: any;
export interface BatchDeleteInstrumentationConfigurationsResponse {
    DeletedCount: number;
    SuccessfulDeletions: BatchDeleteSuccessfulDeletion[];
    Errors: BatchDeleteError[];
}
export declare const BatchDeleteInstrumentationConfigurationsResponse: S.Schema<BatchDeleteInstrumentationConfigurationsResponse>;
export type ServiceLevelObjectiveIds = string[];
export declare const ServiceLevelObjectiveIds: any;
export interface BatchGetServiceLevelObjectiveBudgetReportInput {
    Timestamp: Date;
    SloIds: string[];
}
export declare const BatchGetServiceLevelObjectiveBudgetReportInput: S.Schema<BatchGetServiceLevelObjectiveBudgetReportInput>;
export type ServiceLevelObjectiveArn = string;
export type ServiceLevelObjectiveName = string;
export type EvaluationType = "PeriodBased" | "RequestBased" | (string & {});
export declare const EvaluationType: any;
export type ServiceLevelObjectiveBudgetStatus = "OK" | "WARNING" | "BREACHED" | "INSUFFICIENT_DATA" | (string & {});
export declare const ServiceLevelObjectiveBudgetStatus: any;
export type Attainment = number;
export type TotalBudgetSeconds = number;
export type BudgetSecondsRemaining = number;
export type TotalBudgetRequests = number;
export type BudgetRequestsRemaining = number;
export type KeyAttributeName = string;
export type KeyAttributeValue = string;
export type Attributes = {
    [key: string]: string | undefined;
};
export declare const Attributes: any;
export type OperationName = string;
export type ServiceLevelIndicatorMetricType = "LATENCY" | "AVAILABILITY" | (string & {});
export declare const ServiceLevelIndicatorMetricType: any;
export type MetricId = string;
export type Namespace = string;
export type MetricName = string;
export type DimensionName = string;
export type DimensionValue = string;
export interface Dimension {
    Name: string;
    Value: string;
}
export declare const Dimension: S.Schema<Dimension>;
export type Dimensions = Dimension[];
export declare const Dimensions: any;
export interface Metric {
    Namespace?: string;
    MetricName?: string;
    Dimensions?: Dimension[];
}
export declare const Metric: S.Schema<Metric>;
export type Period = number;
export type Stat = string;
export type StandardUnit = "Microseconds" | "Milliseconds" | "Seconds" | "Bytes" | "Kilobytes" | "Megabytes" | "Gigabytes" | "Terabytes" | "Bits" | "Kilobits" | "Megabits" | "Gigabits" | "Terabits" | "Percent" | "Count" | "Bytes/Second" | "Kilobytes/Second" | "Megabytes/Second" | "Gigabytes/Second" | "Terabytes/Second" | "Bits/Second" | "Kilobits/Second" | "Megabits/Second" | "Gigabits/Second" | "Terabits/Second" | "Count/Second" | "None" | (string & {});
export declare const StandardUnit: any;
export interface MetricStat {
    Metric: Metric;
    Period: number;
    Stat: string;
    Unit?: StandardUnit;
}
export declare const MetricStat: S.Schema<MetricStat>;
export type MetricExpression = string;
export type MetricLabel = string;
export type ReturnData = boolean;
export type AccountId = string;
export interface MetricDataQuery {
    Id: string;
    MetricStat?: MetricStat;
    Expression?: string;
    Label?: string;
    ReturnData?: boolean;
    Period?: number;
    AccountId?: string;
}
export declare const MetricDataQuery: S.Schema<MetricDataQuery>;
export type MetricDataQueries = MetricDataQuery[];
export declare const MetricDataQueries: any;
export interface DependencyConfig {
    DependencyKeyAttributes: {
        [key: string]: string | undefined;
    };
    DependencyOperationName: string;
}
export declare const DependencyConfig: S.Schema<DependencyConfig>;
export interface MetricSource {
    MetricSourceKeyAttributes: {
        [key: string]: string | undefined;
    };
    MetricSourceAttributes?: {
        [key: string]: string | undefined;
    };
}
export declare const MetricSource: S.Schema<MetricSource>;
export type SelectionType = "EXPLICIT" | "PREFIX" | "REGEX" | (string & {});
export declare const SelectionType: any;
export type SelectionPattern = string;
export interface SelectionConfig {
    Type: SelectionType;
    Pattern?: string;
}
export declare const SelectionConfig: S.Schema<SelectionConfig>;
export type CompositeSliComponent = {
    OperationName: string;
};
export declare const CompositeSliComponent: any;
export type CompositeSliComponents = CompositeSliComponent[];
export declare const CompositeSliComponents: any;
export interface CompositeSliConfig {
    SelectionConfig: SelectionConfig;
    Components?: CompositeSliComponent[];
}
export declare const CompositeSliConfig: S.Schema<CompositeSliConfig>;
export interface ServiceLevelIndicatorMetric {
    KeyAttributes?: {
        [key: string]: string | undefined;
    };
    OperationName?: string;
    MetricType?: ServiceLevelIndicatorMetricType;
    MetricDataQueries: MetricDataQuery[];
    DependencyConfig?: DependencyConfig;
    MetricSource?: MetricSource;
    CompositeSliConfig?: CompositeSliConfig;
}
export declare const ServiceLevelIndicatorMetric: S.Schema<ServiceLevelIndicatorMetric>;
export type ServiceLevelIndicatorMetricThreshold = number;
export type ServiceLevelIndicatorComparisonOperator = "GreaterThanOrEqualTo" | "GreaterThan" | "LessThan" | "LessThanOrEqualTo" | (string & {});
export declare const ServiceLevelIndicatorComparisonOperator: any;
export interface ServiceLevelIndicator {
    SliMetric: ServiceLevelIndicatorMetric;
    MetricThreshold: number;
    ComparisonOperator: ServiceLevelIndicatorComparisonOperator;
}
export declare const ServiceLevelIndicator: S.Schema<ServiceLevelIndicator>;
export type MonitoredRequestCountMetricDataQueries = {
    GoodCountMetric: MetricDataQuery[];
    BadCountMetric?: never;
} | {
    GoodCountMetric?: never;
    BadCountMetric: MetricDataQuery[];
};
export declare const MonitoredRequestCountMetricDataQueries: any;
export interface RequestBasedServiceLevelIndicatorMetric {
    KeyAttributes?: {
        [key: string]: string | undefined;
    };
    OperationName?: string;
    MetricType?: ServiceLevelIndicatorMetricType;
    TotalRequestCountMetric: MetricDataQuery[];
    MonitoredRequestCountMetric: MonitoredRequestCountMetricDataQueries;
    DependencyConfig?: DependencyConfig;
    MetricSource?: MetricSource;
    CompositeSliConfig?: CompositeSliConfig;
}
export declare const RequestBasedServiceLevelIndicatorMetric: S.Schema<RequestBasedServiceLevelIndicatorMetric>;
export interface RequestBasedServiceLevelIndicator {
    RequestBasedSliMetric: RequestBasedServiceLevelIndicatorMetric;
    MetricThreshold?: number;
    ComparisonOperator?: ServiceLevelIndicatorComparisonOperator;
}
export declare const RequestBasedServiceLevelIndicator: S.Schema<RequestBasedServiceLevelIndicator>;
export type DurationUnit = "MINUTE" | "HOUR" | "DAY" | "MONTH" | (string & {});
export declare const DurationUnit: any;
export type RollingIntervalDuration = number;
export interface RollingInterval {
    DurationUnit: DurationUnit;
    Duration: number;
}
export declare const RollingInterval: S.Schema<RollingInterval>;
export type CalendarIntervalDuration = number;
export interface CalendarInterval {
    StartTime: Date;
    DurationUnit: DurationUnit;
    Duration: number;
}
export declare const CalendarInterval: S.Schema<CalendarInterval>;
export type Interval = {
    RollingInterval: RollingInterval;
    CalendarInterval?: never;
} | {
    RollingInterval?: never;
    CalendarInterval: CalendarInterval;
};
export declare const Interval: any;
export type AttainmentGoal = number;
export type WarningThreshold = number;
export interface Goal {
    Interval?: Interval;
    AttainmentGoal?: number;
    WarningThreshold?: number;
}
export declare const Goal: S.Schema<Goal>;
export interface ServiceLevelObjectiveBudgetReport {
    Arn: string;
    Name: string;
    EvaluationType?: EvaluationType;
    BudgetStatus: ServiceLevelObjectiveBudgetStatus;
    Attainment?: number;
    TotalBudgetSeconds?: number;
    BudgetSecondsRemaining?: number;
    TotalBudgetRequests?: number;
    BudgetRequestsRemaining?: number;
    Sli?: ServiceLevelIndicator;
    RequestBasedSli?: RequestBasedServiceLevelIndicator;
    Goal?: Goal;
}
export declare const ServiceLevelObjectiveBudgetReport: S.Schema<ServiceLevelObjectiveBudgetReport>;
export type ServiceLevelObjectiveBudgetReports = ServiceLevelObjectiveBudgetReport[];
export declare const ServiceLevelObjectiveBudgetReports: any;
export type ServiceLevelObjectiveBudgetReportErrorCode = string;
export type ServiceLevelObjectiveBudgetReportErrorMessage = string;
export interface ServiceLevelObjectiveBudgetReportError {
    Name?: string;
    Arn: string;
    ErrorCode: string;
    ErrorMessage: string;
}
export declare const ServiceLevelObjectiveBudgetReportError: S.Schema<ServiceLevelObjectiveBudgetReportError>;
export type ServiceLevelObjectiveBudgetReportErrors = ServiceLevelObjectiveBudgetReportError[];
export declare const ServiceLevelObjectiveBudgetReportErrors: any;
export interface BatchGetServiceLevelObjectiveBudgetReportOutput {
    Timestamp: Date;
    Reports: ServiceLevelObjectiveBudgetReport[];
    Errors: ServiceLevelObjectiveBudgetReportError[];
}
export declare const BatchGetServiceLevelObjectiveBudgetReportOutput: S.Schema<BatchGetServiceLevelObjectiveBudgetReportOutput>;
export type ExclusionDuration = number;
export interface Window {
    DurationUnit: DurationUnit;
    Duration: number;
}
export declare const Window: S.Schema<Window>;
export type Expression = string;
export interface RecurrenceRule {
    Expression?: string;
}
export declare const RecurrenceRule: S.Schema<RecurrenceRule>;
export type ExclusionReason = string;
export interface ExclusionWindow {
    Window: Window;
    StartTime?: Date;
    RecurrenceRule?: RecurrenceRule;
    Reason?: string;
}
export declare const ExclusionWindow: S.Schema<ExclusionWindow>;
export type ExclusionWindows = ExclusionWindow[];
export declare const ExclusionWindows: any;
export interface BatchUpdateExclusionWindowsInput {
    SloIds: string[];
    AddExclusionWindows?: ExclusionWindow[];
    RemoveExclusionWindows?: ExclusionWindow[];
}
export declare const BatchUpdateExclusionWindowsInput: S.Schema<BatchUpdateExclusionWindowsInput>;
export type ServiceLevelObjectiveId = string;
export type ExclusionWindowErrorCode = string;
export type ExclusionWindowErrorMessage = string;
export interface BatchUpdateExclusionWindowsError_ {
    SloId: string;
    ErrorCode: string;
    ErrorMessage: string;
}
export declare const BatchUpdateExclusionWindowsError_: S.Schema<BatchUpdateExclusionWindowsError_>;
export type BatchUpdateExclusionWindowsErrors = BatchUpdateExclusionWindowsError_[];
export declare const BatchUpdateExclusionWindowsErrors: any;
export interface BatchUpdateExclusionWindowsOutput {
    SloIds: string[];
    Errors: BatchUpdateExclusionWindowsError_[];
}
export declare const BatchUpdateExclusionWindowsOutput: S.Schema<BatchUpdateExclusionWindowsOutput>;
export type DynamicInstrumentationSignalType = "SNAPSHOT" | (string & {});
export declare const DynamicInstrumentationSignalType: any;
export type ProgrammingLanguage = "Java" | "Python" | "Javascript" | (string & {});
export declare const ProgrammingLanguage: any;
export interface CodeLocation {
    Language: ProgrammingLanguage;
    CodeUnit?: string;
    ClassName?: string;
    MethodName?: string;
    FilePath: string;
    LineNumber?: number;
}
export declare const CodeLocation: S.Schema<CodeLocation>;
export type Location = {
    CodeLocation: CodeLocation;
};
export declare const Location: any;
export type DynamicInstrumentationAttributeFilterGroup = {
    [key: string]: string | undefined;
};
export declare const DynamicInstrumentationAttributeFilterGroup: any;
export type DynamicInstrumentationAttributeFilters = {
    [key: string]: string | undefined;
}[];
export declare const DynamicInstrumentationAttributeFilters: any;
export type StringList = string[];
export declare const StringList: any;
export interface CaptureLimitsConfig {
    MaxHits?: number;
    MaxStringLength?: number;
    MaxCollectionWidth?: number;
    MaxCollectionDepth?: number;
    MaxStackFrames?: number;
    MaxStackTraceSize?: number;
    MaxObjectDepth?: number;
    MaxFieldsPerObject?: number;
}
export declare const CaptureLimitsConfig: S.Schema<CaptureLimitsConfig>;
export interface CodeCaptureConfiguration {
    CaptureArguments?: string[];
    CaptureReturn?: boolean;
    CaptureStackTrace?: boolean;
    CaptureLocals?: string[];
    CaptureLimits: CaptureLimitsConfig;
}
export declare const CodeCaptureConfiguration: S.Schema<CodeCaptureConfiguration>;
export type CaptureConfiguration = {
    CodeCapture: CodeCaptureConfiguration;
};
export declare const CaptureConfiguration: any;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateInstrumentationConfigurationRequest {
    InstrumentationType: InstrumentationType;
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    Location: Location;
    Description?: string;
    ExpiresAt?: Date;
    AttributeFilters?: {
        [key: string]: string | undefined;
    }[];
    CaptureConfiguration: CaptureConfiguration;
    Tags?: Tag[];
}
export declare const CreateInstrumentationConfigurationRequest: S.Schema<CreateInstrumentationConfigurationRequest>;
export type InstrumentationConfigurationArn = string;
export interface CreateInstrumentationConfigurationResponse {
    InstrumentationType: InstrumentationType;
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    Location: Location;
    LocationHash: string;
    Description?: string;
    ExpiresAt?: Date;
    AttributeFilters?: {
        [key: string]: string | undefined;
    }[];
    CaptureConfiguration: CaptureConfiguration;
    CreatedAt: Date;
    ARN: string;
}
export declare const CreateInstrumentationConfigurationResponse: S.Schema<CreateInstrumentationConfigurationResponse>;
export type ServiceLevelObjectiveDescription = string;
export type ServiceLevelIndicatorStatistic = string;
export type SLIPeriodSeconds = number;
export interface ServiceLevelIndicatorMetricConfig {
    KeyAttributes?: {
        [key: string]: string | undefined;
    };
    OperationName?: string;
    MetricType?: ServiceLevelIndicatorMetricType;
    MetricName?: string;
    Statistic?: string;
    PeriodSeconds?: number;
    MetricSource?: MetricSource;
    MetricDataQueries?: MetricDataQuery[];
    DependencyConfig?: DependencyConfig;
    CompositeSliConfig?: CompositeSliConfig;
}
export declare const ServiceLevelIndicatorMetricConfig: S.Schema<ServiceLevelIndicatorMetricConfig>;
export interface ServiceLevelIndicatorConfig {
    SliMetricConfig: ServiceLevelIndicatorMetricConfig;
    MetricThreshold?: number;
    ComparisonOperator?: ServiceLevelIndicatorComparisonOperator;
}
export declare const ServiceLevelIndicatorConfig: S.Schema<ServiceLevelIndicatorConfig>;
export interface RequestBasedServiceLevelIndicatorMetricConfig {
    KeyAttributes?: {
        [key: string]: string | undefined;
    };
    OperationName?: string;
    MetricType?: ServiceLevelIndicatorMetricType;
    TotalRequestCountMetric?: MetricDataQuery[];
    MonitoredRequestCountMetric?: MonitoredRequestCountMetricDataQueries;
    DependencyConfig?: DependencyConfig;
    MetricSource?: MetricSource;
    MetricName?: string;
    CompositeSliConfig?: CompositeSliConfig;
}
export declare const RequestBasedServiceLevelIndicatorMetricConfig: S.Schema<RequestBasedServiceLevelIndicatorMetricConfig>;
export interface RequestBasedServiceLevelIndicatorConfig {
    RequestBasedSliMetricConfig: RequestBasedServiceLevelIndicatorMetricConfig;
    MetricThreshold?: number;
    ComparisonOperator?: ServiceLevelIndicatorComparisonOperator;
}
export declare const RequestBasedServiceLevelIndicatorConfig: S.Schema<RequestBasedServiceLevelIndicatorConfig>;
export type BurnRateLookBackWindowMinutes = number;
export interface BurnRateConfiguration {
    LookBackWindowMinutes: number;
}
export declare const BurnRateConfiguration: S.Schema<BurnRateConfiguration>;
export type BurnRateConfigurations = BurnRateConfiguration[];
export declare const BurnRateConfigurations: any;
export interface CreateServiceLevelObjectiveInput {
    Name: string;
    Description?: string;
    SliConfig?: ServiceLevelIndicatorConfig;
    RequestBasedSliConfig?: RequestBasedServiceLevelIndicatorConfig;
    Goal?: Goal;
    Tags?: Tag[];
    BurnRateConfigurations?: BurnRateConfiguration[];
    CreateRecommendedSlo?: boolean;
    AutoInvestigationEnabled?: boolean;
}
export declare const CreateServiceLevelObjectiveInput: S.Schema<CreateServiceLevelObjectiveInput>;
export type MetricSourceType = "ServiceOperation" | "CloudWatchMetric" | "ServiceDependency" | "AppMonitor" | "Canary" | "Service" | (string & {});
export declare const MetricSourceType: any;
export interface ServiceLevelObjective {
    Arn: string;
    Name: string;
    Description?: string;
    CreatedTime: Date;
    LastUpdatedTime: Date;
    Sli?: ServiceLevelIndicator;
    RequestBasedSli?: RequestBasedServiceLevelIndicator;
    EvaluationType?: EvaluationType;
    Goal: Goal;
    BurnRateConfigurations?: BurnRateConfiguration[];
    MetricSourceType?: MetricSourceType;
    AutoInvestigationEnabled?: boolean;
}
export declare const ServiceLevelObjective: S.Schema<ServiceLevelObjective>;
export interface CreateServiceLevelObjectiveOutput {
    Slo: ServiceLevelObjective;
}
export declare const CreateServiceLevelObjectiveOutput: S.Schema<CreateServiceLevelObjectiveOutput>;
export interface DeleteGroupingConfigurationRequest {
}
export declare const DeleteGroupingConfigurationRequest: S.Schema<DeleteGroupingConfigurationRequest>;
export interface DeleteGroupingConfigurationOutput {
}
export declare const DeleteGroupingConfigurationOutput: S.Schema<DeleteGroupingConfigurationOutput>;
export type LocationIdentifier = {
    CodeLocation: CodeLocation;
    LocationHash?: never;
} | {
    CodeLocation?: never;
    LocationHash: string;
};
export declare const LocationIdentifier: any;
export interface DeleteInstrumentationConfigurationRequest {
    InstrumentationType: InstrumentationType;
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    LocationIdentifier: LocationIdentifier;
}
export declare const DeleteInstrumentationConfigurationRequest: S.Schema<DeleteInstrumentationConfigurationRequest>;
export type DynamicInstrumentationDeletionStatus = "DELETED" | (string & {});
export declare const DynamicInstrumentationDeletionStatus: any;
export interface DeleteInstrumentationConfigurationResponse {
    DeletionStatus: DynamicInstrumentationDeletionStatus;
}
export declare const DeleteInstrumentationConfigurationResponse: S.Schema<DeleteInstrumentationConfigurationResponse>;
export interface DeleteServiceLevelObjectiveInput {
    Id: string;
}
export declare const DeleteServiceLevelObjectiveInput: S.Schema<DeleteServiceLevelObjectiveInput>;
export interface DeleteServiceLevelObjectiveOutput {
}
export declare const DeleteServiceLevelObjectiveOutput: S.Schema<DeleteServiceLevelObjectiveOutput>;
export interface GetInstrumentationConfigurationRequest {
    InstrumentationType: InstrumentationType;
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    LocationIdentifier: LocationIdentifier;
}
export declare const GetInstrumentationConfigurationRequest: S.Schema<GetInstrumentationConfigurationRequest>;
export interface InstrumentationConfiguration {
    InstrumentationType: InstrumentationType;
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    Location: Location;
    LocationHash: string;
    Description?: string;
    ExpiresAt?: Date;
    AttributeFilters?: {
        [key: string]: string | undefined;
    }[];
    CaptureConfiguration: CaptureConfiguration;
    CreatedAt: Date;
    ARN: string;
}
export declare const InstrumentationConfiguration: S.Schema<InstrumentationConfiguration>;
export interface GetInstrumentationConfigurationResponse {
    Configuration: InstrumentationConfiguration;
}
export declare const GetInstrumentationConfigurationResponse: S.Schema<GetInstrumentationConfigurationResponse>;
export type InstrumentationConfigurationStatus = "READY" | "ERROR" | "ACTIVE" | "DISABLED" | (string & {});
export declare const InstrumentationConfigurationStatus: any;
export type NextToken = string;
export interface GetInstrumentationConfigurationStatusRequest {
    InstrumentationType: InstrumentationType;
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    LocationIdentifier: LocationIdentifier;
    Status?: InstrumentationConfigurationStatus;
    StartTime?: Date;
    EndTime?: Date;
    MaxResults?: number;
    NextToken?: string;
}
export declare const GetInstrumentationConfigurationStatusRequest: S.Schema<GetInstrumentationConfigurationStatusRequest>;
export type InstrumentationErrorCause = "FILE_NOT_FOUND" | "METHOD_NOT_FOUND" | "LINE_NOT_EXECUTABLE" | "OVERLOADED_METHODS" | "LANGUAGE_MISMATCH" | "RUNTIME_ERROR" | (string & {});
export declare const InstrumentationErrorCause: any;
export interface InstrumentationStatusEvent {
    Time: Date;
    ErrorCause?: InstrumentationErrorCause;
}
export declare const InstrumentationStatusEvent: S.Schema<InstrumentationStatusEvent>;
export type InstrumentationStatusEventList = InstrumentationStatusEvent[];
export declare const InstrumentationStatusEventList: any;
export interface GetInstrumentationConfigurationStatusResponse {
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    Location: Location;
    Status: InstrumentationConfigurationStatus;
    Events: InstrumentationStatusEvent[];
    NextToken?: string;
}
export declare const GetInstrumentationConfigurationStatusResponse: S.Schema<GetInstrumentationConfigurationStatusResponse>;
export interface GetServiceInput {
    StartTime: Date;
    EndTime: Date;
    KeyAttributes: {
        [key: string]: string | undefined;
    };
}
export declare const GetServiceInput: S.Schema<GetServiceInput>;
export type AttributeMap = {
    [key: string]: string | undefined;
};
export declare const AttributeMap: any;
export type AttributeMaps = {
    [key: string]: string | undefined;
}[];
export declare const AttributeMaps: any;
export type GroupName = string;
export type GroupValue = string;
export type GroupSource = string;
export type GroupIdentifier = string;
export interface ServiceGroup {
    GroupName: string;
    GroupValue: string;
    GroupSource: string;
    GroupIdentifier: string;
}
export declare const ServiceGroup: S.Schema<ServiceGroup>;
export type ServiceGroups = ServiceGroup[];
export declare const ServiceGroups: any;
export type MetricType = string;
export type AwsAccountId = string;
export interface MetricReference {
    Namespace: string;
    MetricType: string;
    Dimensions?: Dimension[];
    MetricName: string;
    AccountId?: string;
}
export declare const MetricReference: S.Schema<MetricReference>;
export type MetricReferences = MetricReference[];
export declare const MetricReferences: any;
export type LogGroupReferences = {
    [key: string]: string | undefined;
}[];
export declare const LogGroupReferences: any;
export interface Service {
    KeyAttributes?: {
        [key: string]: string | undefined;
    };
    AttributeMaps?: {
        [key: string]: string | undefined;
    }[];
    ServiceGroups?: ServiceGroup[];
    MetricReferences?: MetricReference[];
    LogGroupReferences?: {
        [key: string]: string | undefined;
    }[];
}
export declare const Service: S.Schema<Service>;
export interface GetServiceOutput {
    Service: Service;
    StartTime: Date;
    EndTime: Date;
    LogGroupReferences?: {
        [key: string]: string | undefined;
    }[];
}
export declare const GetServiceOutput: S.Schema<GetServiceOutput>;
export interface GetServiceLevelObjectiveInput {
    Id: string;
}
export declare const GetServiceLevelObjectiveInput: S.Schema<GetServiceLevelObjectiveInput>;
export interface GetServiceLevelObjectiveOutput {
    Slo: ServiceLevelObjective;
}
export declare const GetServiceLevelObjectiveOutput: S.Schema<GetServiceLevelObjectiveOutput>;
export type Auditors = string[];
export declare const Auditors: any;
export interface ServiceEntity {
    Type?: string;
    Name?: string;
    Environment?: string;
    AwsAccountId?: string;
}
export declare const ServiceEntity: S.Schema<ServiceEntity>;
export interface ServiceLevelObjectiveEntity {
    SloName?: string;
    SloArn?: string;
}
export declare const ServiceLevelObjectiveEntity: S.Schema<ServiceLevelObjectiveEntity>;
export interface ServiceOperationEntity {
    Service?: ServiceEntity;
    Operation?: string;
    MetricType?: string;
}
export declare const ServiceOperationEntity: S.Schema<ServiceOperationEntity>;
export interface CanaryEntity {
    CanaryName: string;
}
export declare const CanaryEntity: S.Schema<CanaryEntity>;
export type AuditTargetEntity = {
    Service: ServiceEntity;
    Slo?: never;
    ServiceOperation?: never;
    Canary?: never;
} | {
    Service?: never;
    Slo: ServiceLevelObjectiveEntity;
    ServiceOperation?: never;
    Canary?: never;
} | {
    Service?: never;
    Slo?: never;
    ServiceOperation: ServiceOperationEntity;
    Canary?: never;
} | {
    Service?: never;
    Slo?: never;
    ServiceOperation?: never;
    Canary: CanaryEntity;
};
export declare const AuditTargetEntity: any;
export interface AuditTarget {
    Type: string;
    Data: AuditTargetEntity;
}
export declare const AuditTarget: S.Schema<AuditTarget>;
export type AuditTargets = AuditTarget[];
export declare const AuditTargets: any;
export type DetailLevel = "BRIEF" | "DETAILED" | (string & {});
export declare const DetailLevel: any;
export type ListAuditFindingMaxResults = number;
export interface ListAuditFindingsInput {
    StartTime: Date;
    EndTime: Date;
    Auditors?: string[];
    AuditTargets: AuditTarget[];
    DetailLevel?: DetailLevel;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListAuditFindingsInput: S.Schema<ListAuditFindingsInput>;
export type DataMap = {
    [key: string]: string | undefined;
};
export declare const DataMap: any;
export type Severity = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "NONE" | (string & {});
export declare const Severity: any;
export interface AuditorResult {
    Auditor?: string;
    Description?: string;
    Data?: {
        [key: string]: string | undefined;
    };
    Severity?: Severity;
}
export declare const AuditorResult: S.Schema<AuditorResult>;
export type AuditorResults = AuditorResult[];
export declare const AuditorResults: any;
export interface MetricGraph {
    MetricDataQueries?: MetricDataQuery[];
    StartTime?: Date;
    EndTime?: Date;
}
export declare const MetricGraph: S.Schema<MetricGraph>;
export interface Node {
    KeyAttributes: {
        [key: string]: string | undefined;
    };
    Name: string;
    NodeId: string;
    Operation?: string;
    Type?: string;
    Duration?: number;
    Status?: string;
}
export declare const Node: S.Schema<Node>;
export type Nodes = Node[];
export declare const Nodes: any;
export type ConnectionType = "INDIRECT" | "DIRECT" | (string & {});
export declare const ConnectionType: any;
export interface Edge {
    SourceNodeId?: string;
    DestinationNodeId?: string;
    Duration?: number;
    ConnectionType?: ConnectionType;
}
export declare const Edge: S.Schema<Edge>;
export type Edges = Edge[];
export declare const Edges: any;
export interface DependencyGraph {
    Nodes?: Node[];
    Edges?: Edge[];
}
export declare const DependencyGraph: S.Schema<DependencyGraph>;
export interface AuditFinding {
    KeyAttributes: {
        [key: string]: string | undefined;
    };
    AuditorResults?: AuditorResult[];
    Operation?: string;
    MetricGraph?: MetricGraph;
    DependencyGraph?: DependencyGraph;
    Type?: string;
}
export declare const AuditFinding: S.Schema<AuditFinding>;
export type AuditFindings = AuditFinding[];
export declare const AuditFindings: any;
export interface ListAuditFindingsOutput {
    StartTime?: Date;
    EndTime?: Date;
    AuditFindings: AuditFinding[];
    NextToken?: string;
}
export declare const ListAuditFindingsOutput: S.Schema<ListAuditFindingsOutput>;
export type ListEntityEventsMaxResults = number;
export interface ListEntityEventsInput {
    Entity: {
        [key: string]: string | undefined;
    };
    StartTime: Date;
    EndTime: Date;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListEntityEventsInput: S.Schema<ListEntityEventsInput>;
export type ChangeEventType = "DEPLOYMENT" | "CONFIGURATION" | (string & {});
export declare const ChangeEventType: any;
export interface ChangeEvent {
    Timestamp: Date;
    AccountId: string;
    Region: string;
    Entity: {
        [key: string]: string | undefined;
    };
    ChangeEventType: ChangeEventType;
    EventId: string;
    UserName?: string;
    EventName?: string;
}
export declare const ChangeEvent: S.Schema<ChangeEvent>;
export type ChangeEvents = ChangeEvent[];
export declare const ChangeEvents: any;
export interface ListEntityEventsOutput {
    StartTime: Date;
    EndTime: Date;
    ChangeEvents: ChangeEvent[];
    NextToken?: string;
}
export declare const ListEntityEventsOutput: S.Schema<ListEntityEventsOutput>;
export interface ListGroupingAttributeDefinitionsInput {
    NextToken?: string;
    AwsAccountId?: string;
    IncludeLinkedAccounts?: boolean;
}
export declare const ListGroupingAttributeDefinitionsInput: S.Schema<ListGroupingAttributeDefinitionsInput>;
export type GroupingString = string;
export type GroupingSourceKeyStringList = string[];
export declare const GroupingSourceKeyStringList: any;
export interface GroupingAttributeDefinition {
    GroupingName: string;
    GroupingSourceKeys?: string[];
    DefaultGroupingValue?: string;
}
export declare const GroupingAttributeDefinition: S.Schema<GroupingAttributeDefinition>;
export type GroupingAttributeDefinitions = GroupingAttributeDefinition[];
export declare const GroupingAttributeDefinitions: any;
export interface ListGroupingAttributeDefinitionsOutput {
    GroupingAttributeDefinitions: GroupingAttributeDefinition[];
    UpdatedAt?: Date;
    NextToken?: string;
}
export declare const ListGroupingAttributeDefinitionsOutput: S.Schema<ListGroupingAttributeDefinitionsOutput>;
export interface ListInstrumentationConfigurationsRequest {
    Service: string;
    Environment: string;
    InstrumentationType: InstrumentationType;
    SyncedAt?: Date;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListInstrumentationConfigurationsRequest: S.Schema<ListInstrumentationConfigurationsRequest>;
export interface InstrumentationConfigurationWithoutServiceEnv {
    InstrumentationType: InstrumentationType;
    SignalType: DynamicInstrumentationSignalType;
    Location: Location;
    LocationHash: string;
    Description?: string;
    ExpiresAt?: Date;
    AttributeFilters?: {
        [key: string]: string | undefined;
    }[];
    CaptureConfiguration: CaptureConfiguration;
    CreatedAt: Date;
    ARN: string;
}
export declare const InstrumentationConfigurationWithoutServiceEnv: S.Schema<InstrumentationConfigurationWithoutServiceEnv>;
export type InstrumentationConfigurationsWithoutServiceEnv = InstrumentationConfigurationWithoutServiceEnv[];
export declare const InstrumentationConfigurationsWithoutServiceEnv: any;
export interface InstrumentationConfigurationsPage {
    Service: string;
    Environment: string;
    Changed: boolean;
    LatestConfigurations?: InstrumentationConfigurationWithoutServiceEnv[];
    SyncedAt: Date;
    SyncInterval: number;
    NextToken?: string;
}
export declare const InstrumentationConfigurationsPage: S.Schema<InstrumentationConfigurationsPage>;
export type ListServiceDependenciesMaxResults = number;
export interface ListServiceDependenciesInput {
    StartTime: Date;
    EndTime: Date;
    KeyAttributes: {
        [key: string]: string | undefined;
    };
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListServiceDependenciesInput: S.Schema<ListServiceDependenciesInput>;
export interface ServiceDependency {
    OperationName: string;
    DependencyKeyAttributes: {
        [key: string]: string | undefined;
    };
    DependencyOperationName: string;
    MetricReferences: MetricReference[];
}
export declare const ServiceDependency: S.Schema<ServiceDependency>;
export type ServiceDependencies = ServiceDependency[];
export declare const ServiceDependencies: any;
export interface ListServiceDependenciesOutput {
    StartTime: Date;
    EndTime: Date;
    ServiceDependencies: ServiceDependency[];
    NextToken?: string;
}
export declare const ListServiceDependenciesOutput: S.Schema<ListServiceDependenciesOutput>;
export type ListServiceDependentsMaxResults = number;
export interface ListServiceDependentsInput {
    StartTime: Date;
    EndTime: Date;
    KeyAttributes: {
        [key: string]: string | undefined;
    };
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListServiceDependentsInput: S.Schema<ListServiceDependentsInput>;
export interface ServiceDependent {
    OperationName?: string;
    DependentKeyAttributes: {
        [key: string]: string | undefined;
    };
    DependentOperationName?: string;
    MetricReferences: MetricReference[];
}
export declare const ServiceDependent: S.Schema<ServiceDependent>;
export type ServiceDependents = ServiceDependent[];
export declare const ServiceDependents: any;
export interface ListServiceDependentsOutput {
    StartTime: Date;
    EndTime: Date;
    ServiceDependents: ServiceDependent[];
    NextToken?: string;
}
export declare const ListServiceDependentsOutput: S.Schema<ListServiceDependentsOutput>;
export type ListServiceLevelObjectiveExclusionWindowsMaxResults = number;
export interface ListServiceLevelObjectiveExclusionWindowsInput {
    Id: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListServiceLevelObjectiveExclusionWindowsInput: S.Schema<ListServiceLevelObjectiveExclusionWindowsInput>;
export interface ListServiceLevelObjectiveExclusionWindowsOutput {
    ExclusionWindows: ExclusionWindow[];
    NextToken?: string;
}
export declare const ListServiceLevelObjectiveExclusionWindowsOutput: S.Schema<ListServiceLevelObjectiveExclusionWindowsOutput>;
export type ListServiceLevelObjectivesMaxResults = number;
export type MetricSourceTypes = MetricSourceType[];
export declare const MetricSourceTypes: any;
export interface ListServiceLevelObjectivesInput {
    KeyAttributes?: {
        [key: string]: string | undefined;
    };
    OperationName?: string;
    DependencyConfig?: DependencyConfig;
    MaxResults?: number;
    NextToken?: string;
    MetricSourceTypes?: MetricSourceType[];
    IncludeLinkedAccounts?: boolean;
    SloOwnerAwsAccountId?: string;
    MetricSource?: MetricSource;
}
export declare const ListServiceLevelObjectivesInput: S.Schema<ListServiceLevelObjectivesInput>;
export interface ServiceLevelObjectiveSummary {
    Arn: string;
    Name: string;
    KeyAttributes?: {
        [key: string]: string | undefined;
    };
    OperationName?: string;
    DependencyConfig?: DependencyConfig;
    CreatedTime?: Date;
    EvaluationType?: EvaluationType;
    MetricSourceType?: MetricSourceType;
    MetricSource?: MetricSource;
    CompositeSliConfig?: CompositeSliConfig;
}
export declare const ServiceLevelObjectiveSummary: S.Schema<ServiceLevelObjectiveSummary>;
export type ServiceLevelObjectiveSummaries = ServiceLevelObjectiveSummary[];
export declare const ServiceLevelObjectiveSummaries: any;
export interface ListServiceLevelObjectivesOutput {
    SloSummaries?: ServiceLevelObjectiveSummary[];
    NextToken?: string;
}
export declare const ListServiceLevelObjectivesOutput: S.Schema<ListServiceLevelObjectivesOutput>;
export type ListServiceOperationMaxResults = number;
export interface ListServiceOperationsInput {
    StartTime: Date;
    EndTime: Date;
    KeyAttributes: {
        [key: string]: string | undefined;
    };
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListServiceOperationsInput: S.Schema<ListServiceOperationsInput>;
export interface ServiceOperation {
    Name: string;
    MetricReferences: MetricReference[];
}
export declare const ServiceOperation: S.Schema<ServiceOperation>;
export type ServiceOperations = ServiceOperation[];
export declare const ServiceOperations: any;
export interface ListServiceOperationsOutput {
    StartTime: Date;
    EndTime: Date;
    ServiceOperations: ServiceOperation[];
    NextToken?: string;
}
export declare const ListServiceOperationsOutput: S.Schema<ListServiceOperationsOutput>;
export type ListServicesMaxResults = number;
export interface ListServicesInput {
    StartTime: Date;
    EndTime: Date;
    MaxResults?: number;
    NextToken?: string;
    IncludeLinkedAccounts?: boolean;
    AwsAccountId?: string;
}
export declare const ListServicesInput: S.Schema<ListServicesInput>;
export interface ServiceSummary {
    KeyAttributes: {
        [key: string]: string | undefined;
    };
    AttributeMaps?: {
        [key: string]: string | undefined;
    }[];
    MetricReferences: MetricReference[];
    ServiceGroups?: ServiceGroup[];
}
export declare const ServiceSummary: S.Schema<ServiceSummary>;
export type ServiceSummaries = ServiceSummary[];
export declare const ServiceSummaries: any;
export interface ListServicesOutput {
    StartTime: Date;
    EndTime: Date;
    ServiceSummaries: ServiceSummary[];
    NextToken?: string;
}
export declare const ListServicesOutput: S.Schema<ListServicesOutput>;
export type ListServiceStatesMaxResults = number;
export type AttributeFilterName = string;
export type AttributeFilterValue = string;
export type AttributeFilterValues = string[];
export declare const AttributeFilterValues: any;
export interface AttributeFilter {
    AttributeFilterName: string;
    AttributeFilterValues: string[];
}
export declare const AttributeFilter: S.Schema<AttributeFilter>;
export type AttributeFilters = AttributeFilter[];
export declare const AttributeFilters: any;
export interface ListServiceStatesInput {
    StartTime: Date;
    EndTime: Date;
    MaxResults?: number;
    NextToken?: string;
    IncludeLinkedAccounts?: boolean;
    AwsAccountId?: string;
    AttributeFilters?: AttributeFilter[];
}
export declare const ListServiceStatesInput: S.Schema<ListServiceStatesInput>;
export type LatestChangeEvents = ChangeEvent[];
export declare const LatestChangeEvents: any;
export interface ServiceState {
    AttributeFilters?: AttributeFilter[];
    Service: {
        [key: string]: string | undefined;
    };
    LatestChangeEvents: ChangeEvent[];
}
export declare const ServiceState: S.Schema<ServiceState>;
export type ServiceStates = ServiceState[];
export declare const ServiceStates: any;
export interface ListServiceStatesOutput {
    StartTime: Date;
    EndTime: Date;
    ServiceStates: ServiceState[];
    NextToken?: string;
}
export declare const ListServiceStatesOutput: S.Schema<ListServiceStatesOutput>;
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PutGroupingConfigurationInput {
    GroupingAttributeDefinitions: GroupingAttributeDefinition[];
}
export declare const PutGroupingConfigurationInput: S.Schema<PutGroupingConfigurationInput>;
export interface GroupingConfiguration {
    GroupingAttributeDefinitions: GroupingAttributeDefinition[];
    UpdatedAt: Date;
}
export declare const GroupingConfiguration: S.Schema<GroupingConfiguration>;
export interface PutGroupingConfigurationOutput {
    GroupingConfiguration: GroupingConfiguration;
}
export declare const PutGroupingConfigurationOutput: S.Schema<PutGroupingConfigurationOutput>;
export interface InstrumentationConfigurationStatusReport {
    InstrumentationType: InstrumentationType;
    SignalType: DynamicInstrumentationSignalType;
    LocationHash: string;
    Status: InstrumentationConfigurationStatus;
    Time: Date;
    ErrorCause?: InstrumentationErrorCause;
}
export declare const InstrumentationConfigurationStatusReport: S.Schema<InstrumentationConfigurationStatusReport>;
export type InstrumentationConfigurationStatusList = InstrumentationConfigurationStatusReport[];
export declare const InstrumentationConfigurationStatusList: any;
export interface ReportInstrumentationConfigurationStatusRequest {
    Service: string;
    Environment: string;
    Configurations: InstrumentationConfigurationStatusReport[];
}
export declare const ReportInstrumentationConfigurationStatusRequest: S.Schema<ReportInstrumentationConfigurationStatusRequest>;
export type UnprocessedStatusEventFailureReason = "THROTTLED" | "INTERNAL_ERROR" | "VALIDATION_ERROR" | (string & {});
export declare const UnprocessedStatusEventFailureReason: any;
export interface UnprocessedStatusEvent {
    InstrumentationType: InstrumentationType;
    SignalType: DynamicInstrumentationSignalType;
    LocationHash: string;
    Status: InstrumentationConfigurationStatus;
    Time: Date;
    FailedReason: UnprocessedStatusEventFailureReason;
}
export declare const UnprocessedStatusEvent: S.Schema<UnprocessedStatusEvent>;
export type UnprocessedStatusEventList = UnprocessedStatusEvent[];
export declare const UnprocessedStatusEventList: any;
export interface ReportInstrumentationConfigurationStatusResponse {
    Service: string;
    Environment: string;
    UnprocessedStatusEvents: UnprocessedStatusEvent[];
}
export declare const ReportInstrumentationConfigurationStatusResponse: S.Schema<ReportInstrumentationConfigurationStatusResponse>;
export interface StartDiscoveryInput {
}
export declare const StartDiscoveryInput: S.Schema<StartDiscoveryInput>;
export interface StartDiscoveryOutput {
}
export declare const StartDiscoveryOutput: S.Schema<StartDiscoveryOutput>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateServiceLevelObjectiveInput {
    Id: string;
    Description?: string;
    SliConfig?: ServiceLevelIndicatorConfig;
    RequestBasedSliConfig?: RequestBasedServiceLevelIndicatorConfig;
    Goal?: Goal;
    BurnRateConfigurations?: BurnRateConfiguration[];
    AutoInvestigationEnabled?: boolean;
}
export declare const UpdateServiceLevelObjectiveInput: S.Schema<UpdateServiceLevelObjectiveInput>;
export interface UpdateServiceLevelObjectiveOutput {
    Slo: ServiceLevelObjective;
}
export declare const UpdateServiceLevelObjectiveOutput: S.Schema<UpdateServiceLevelObjectiveOutput>;
export type ValidationExceptionMessage = string;
export type ResourceType = string;
export type ResourceId = string;
export type FaultDescription = string;
export type ServiceErrorMessage = string;
export type BatchDeleteInstrumentationConfigurationsError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes multiple instrumentation configurations in a single request.
 * Supports two mutually exclusive selection methods:
 * - By scope: Delete all configurations matching a Service + Environment + InstrumentationType
 * - By ARN list: Delete specific configurations by providing a list of resource ARNs
 */
export declare const batchDeleteInstrumentationConfigurations: API.OperationMethod<BatchDeleteInstrumentationConfigurationsRequest, BatchDeleteInstrumentationConfigurationsResponse, BatchDeleteInstrumentationConfigurationsError, Credentials | HttpClient.HttpClient>;
export type BatchGetServiceLevelObjectiveBudgetReportError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to retrieve one or more *service level objective (SLO) budget reports*.
 *
 * An *error budget* is the amount of time or requests in an unhealthy state that your service can accumulate during an interval before your overall SLO budget health is breached and the SLO is considered to be unmet. For example, an SLO with a threshold of 99.95% and a monthly interval translates to an error budget of 21.9 minutes of downtime in a 30-day month.
 *
 * Budget reports include a health indicator, the attainment value, and remaining budget.
 *
 * For more information about SLO error budgets, see SLO concepts.
 */
export declare const batchGetServiceLevelObjectiveBudgetReport: API.OperationMethod<BatchGetServiceLevelObjectiveBudgetReportInput, BatchGetServiceLevelObjectiveBudgetReportOutput, BatchGetServiceLevelObjectiveBudgetReportError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateExclusionWindowsError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Add or remove time window exclusions for one or more Service Level Objectives (SLOs).
 */
export declare const batchUpdateExclusionWindows: API.OperationMethod<BatchUpdateExclusionWindowsInput, BatchUpdateExclusionWindowsOutput, BatchUpdateExclusionWindowsError, Credentials | HttpClient.HttpClient>;
export type CreateInstrumentationConfigurationError = ConflictException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a dynamic instrumentation configuration for a specific code or endpoint location within a service and environment. Configurations are immutable after creation.
 *
 * For `BREAKPOINT` type configurations, they expire after 24 hours unless a shorter expiration is provided. For `PROBE` type configurations, they persist until explicitly deleted; an expiration cannot be set for `PROBE` configurations.
 *
 * If a configuration already exists for the same service, environment, signal type, and location, this operation returns a conflict instead of overwriting it. Use attribute filters and capture settings to control where the instrumentation runs and which data is collected.
 */
export declare const createInstrumentationConfiguration: API.OperationMethod<CreateInstrumentationConfigurationRequest, CreateInstrumentationConfigurationResponse, CreateInstrumentationConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateServiceLevelObjectiveError = AccessDeniedException | ConflictException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a service level objective (SLO), which can help you ensure that your critical business operations are meeting customer expectations. Use SLOs to set and track specific target levels for the reliability and availability of your applications and services. SLOs use service level indicators (SLIs) to calculate whether the application is performing at the level that you want.
 *
 * Create an SLO to set a target for a service or operation’s availability or latency. CloudWatch measures this target frequently you can find whether it has been breached.
 *
 * The target performance quality that is defined for an SLO is the *attainment goal*.
 *
 * You can set SLO targets for your applications that are discovered by Application Signals, using critical metrics such as latency and availability. You can also set SLOs against any CloudWatch metric or math expression that produces a time series.
 *
 * You can't create an SLO for a service operation that was discovered by Application Signals until after that operation has reported standard metrics to Application Signals.
 *
 * When you create an SLO, you specify whether it is a *period-based SLO* or a *request-based SLO*. Each type of SLO has a different way of evaluating your application's performance against its attainment goal.
 *
 * - A *period-based SLO* uses defined *periods* of time within a specified total time interval. For each period of time, Application Signals determines whether the application met its goal. The attainment rate is calculated as the `number of good periods/number of total periods`.
 *
 * For example, for a period-based SLO, meeting an attainment goal of 99.9% means that within your interval, your application must meet its performance goal during at least 99.9% of the time periods.
 *
 * - A *request-based SLO* doesn't use pre-defined periods of time. Instead, the SLO measures `number of good requests/number of total requests` during the interval. At any time, you can find the ratio of good requests to total requests for the interval up to the time stamp that you specify, and measure that ratio against the goal set in your SLO.
 *
 * After you have created an SLO, you can retrieve error budget reports for it. An *error budget* is the amount of time or amount of requests that your application can be non-compliant with the SLO's goal, and still have your application meet the goal.
 *
 * - For a period-based SLO, the error budget starts at a number defined by the highest number of periods that can fail to meet the threshold, while still meeting the overall goal. The *remaining error budget* decreases with every failed period that is recorded. The error budget within one interval can never increase.
 *
 * For example, an SLO with a threshold that 99.95% of requests must be completed under 2000ms every month translates to an error budget of 21.9 minutes of downtime per month.
 *
 * - For a request-based SLO, the remaining error budget is dynamic and can increase or decrease, depending on the ratio of good requests to total requests.
 *
 * For more information about SLOs, see Service level objectives (SLOs).
 *
 * When you perform a `CreateServiceLevelObjective` operation, Application Signals creates the *AWSServiceRoleForCloudWatchApplicationSignals* service-linked role, if it doesn't already exist in your account. This service- linked role has the following permissions:
 *
 * - `xray:GetServiceGraph`
 *
 * - `logs:StartQuery`
 *
 * - `logs:GetQueryResults`
 *
 * - `cloudwatch:GetMetricData`
 *
 * - `cloudwatch:ListMetrics`
 *
 * - `tag:GetResources`
 *
 * - `autoscaling:DescribeAutoScalingGroups`
 */
export declare const createServiceLevelObjective: API.OperationMethod<CreateServiceLevelObjectiveInput, CreateServiceLevelObjectiveOutput, CreateServiceLevelObjectiveError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupingConfigurationError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the grouping configuration for this account. This removes all custom grouping attribute definitions that were previously configured.
 */
export declare const deleteGroupingConfiguration: API.OperationMethod<DeleteGroupingConfigurationRequest, DeleteGroupingConfigurationOutput, DeleteGroupingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteInstrumentationConfigurationError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified instrumentation configuration. SDKs remove the instrumentation during their next sync after the configuration is deleted or expires.
 */
export declare const deleteInstrumentationConfiguration: API.OperationMethod<DeleteInstrumentationConfigurationRequest, DeleteInstrumentationConfigurationResponse, DeleteInstrumentationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceLevelObjectiveError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified service level objective.
 */
export declare const deleteServiceLevelObjective: API.OperationMethod<DeleteServiceLevelObjectiveInput, DeleteServiceLevelObjectiveOutput, DeleteServiceLevelObjectiveError, Credentials | HttpClient.HttpClient>;
export type GetInstrumentationConfigurationError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the details of a single instrumentation configuration identified by service, environment, signal type, and location. Use this to audit or display configuration details.
 */
export declare const getInstrumentationConfiguration: API.OperationMethod<GetInstrumentationConfigurationRequest, GetInstrumentationConfigurationResponse, GetInstrumentationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetInstrumentationConfigurationStatusError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the status history for a single instrumentation configuration during a specified time range. The response lists when the configuration was ACTIVE, READY, ERROR, or DISABLED.
 *
 * If no status or time window is provided, the operation defaults to ACTIVE events from the last hour.
 */
export declare const getInstrumentationConfigurationStatus: API.PaginatedOperationMethod<GetInstrumentationConfigurationStatusRequest, GetInstrumentationConfigurationStatusResponse, GetInstrumentationConfigurationStatusError, Credentials | HttpClient.HttpClient, InstrumentationStatusEvent>;
export type GetServiceError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a service discovered by Application Signals.
 */
export declare const getService: API.OperationMethod<GetServiceInput, GetServiceOutput, GetServiceError, Credentials | HttpClient.HttpClient>;
export type GetServiceLevelObjectiveError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about one SLO created in the account.
 */
export declare const getServiceLevelObjective: API.OperationMethod<GetServiceLevelObjectiveInput, GetServiceLevelObjectiveOutput, GetServiceLevelObjectiveError, Credentials | HttpClient.HttpClient>;
export type ListAuditFindingsError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of audit findings that provide automated analysis of service behavior and root cause analysis. These findings help identify the most significant observations about your services, including performance issues, anomalies, and potential problems. The findings are generated using heuristic algorithms based on established troubleshooting patterns.
 */
export declare const listAuditFindings: API.OperationMethod<ListAuditFindingsInput, ListAuditFindingsOutput, ListAuditFindingsError, Credentials | HttpClient.HttpClient>;
export type ListEntityEventsError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of change events for a specific entity, such as deployments, configuration changes, or other state-changing activities. This operation helps track the history of changes that may have affected service performance.
 */
export declare const listEntityEvents: API.PaginatedOperationMethod<ListEntityEventsInput, ListEntityEventsOutput, ListEntityEventsError, Credentials | HttpClient.HttpClient, ChangeEvent>;
export type ListGroupingAttributeDefinitionsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the current grouping configuration for this account, including all custom grouping attribute definitions that have been configured. These definitions determine how services are logically grouped based on telemetry attributes, Amazon Web Services tags, or predefined mappings.
 */
export declare const listGroupingAttributeDefinitions: API.OperationMethod<ListGroupingAttributeDefinitionsInput, ListGroupingAttributeDefinitionsOutput, ListGroupingAttributeDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListInstrumentationConfigurationsError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns all active instrumentation configurations for a service and environment. SDKs use this operation to sync configurations and apply client-side filters locally.
 *
 * Include the previous `SyncedAt` value to perform incremental syncs. When no changes are detected, the response sets `Changed` to `false` and omits configuration details.
 */
export declare const listInstrumentationConfigurations: API.PaginatedOperationMethod<ListInstrumentationConfigurationsRequest, InstrumentationConfigurationsPage, ListInstrumentationConfigurationsError, Credentials | HttpClient.HttpClient, InstrumentationConfigurationWithoutServiceEnv>;
export type ListServiceDependenciesError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of service dependencies of the service that you specify. A dependency is an infrastructure component that an operation of this service connects with. Dependencies can include Amazon Web Services services, Amazon Web Services resources, and third-party services.
 */
export declare const listServiceDependencies: API.PaginatedOperationMethod<ListServiceDependenciesInput, ListServiceDependenciesOutput, ListServiceDependenciesError, Credentials | HttpClient.HttpClient, ServiceDependency>;
export type ListServiceDependentsError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the list of dependents that invoked the specified service during the provided time range. Dependents include other services, CloudWatch Synthetics canaries, and clients that are instrumented with CloudWatch RUM app monitors.
 */
export declare const listServiceDependents: API.PaginatedOperationMethod<ListServiceDependentsInput, ListServiceDependentsOutput, ListServiceDependentsError, Credentials | HttpClient.HttpClient, ServiceDependent>;
export type ListServiceLevelObjectiveExclusionWindowsError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves all exclusion windows configured for a specific SLO.
 */
export declare const listServiceLevelObjectiveExclusionWindows: API.PaginatedOperationMethod<ListServiceLevelObjectiveExclusionWindowsInput, ListServiceLevelObjectiveExclusionWindowsOutput, ListServiceLevelObjectiveExclusionWindowsError, Credentials | HttpClient.HttpClient, ExclusionWindow>;
export type ListServiceLevelObjectivesError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of SLOs created in this account.
 */
export declare const listServiceLevelObjectives: API.PaginatedOperationMethod<ListServiceLevelObjectivesInput, ListServiceLevelObjectivesOutput, ListServiceLevelObjectivesError, Credentials | HttpClient.HttpClient, ServiceLevelObjectiveSummary>;
export type ListServiceOperationsError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the *operations* of this service that have been discovered by Application Signals. Only the operations that were invoked during the specified time range are returned.
 */
export declare const listServiceOperations: API.PaginatedOperationMethod<ListServiceOperationsInput, ListServiceOperationsOutput, ListServiceOperationsError, Credentials | HttpClient.HttpClient, ServiceOperation>;
export type ListServicesError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of services that have been discovered by Application Signals. A service represents a minimum logical and transactional unit that completes a business function. Services are discovered through Application Signals instrumentation.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesInput, ListServicesOutput, ListServicesError, Credentials | HttpClient.HttpClient, ServiceSummary>;
export type ListServiceStatesError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the last deployment and other change states of services. This API provides visibility into recent changes that may have affected service performance, helping with troubleshooting and change correlation.
 */
export declare const listServiceStates: API.PaginatedOperationMethod<ListServiceStatesInput, ListServiceStatesOutput, ListServiceStatesError, Credentials | HttpClient.HttpClient, ServiceState>;
export type ListTagsForResourceError = ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Displays the tags associated with a CloudWatch resource. Tags can be assigned to service level objectives.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutGroupingConfigurationError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates the grouping configuration for this account. This operation allows you to define custom grouping attributes that determine how services are logically grouped based on telemetry attributes, Amazon Web Services tags, or predefined mappings. These grouping attributes can then be used to organize and filter services in the Application Signals console and APIs.
 */
export declare const putGroupingConfiguration: API.OperationMethod<PutGroupingConfigurationInput, PutGroupingConfigurationOutput, PutGroupingConfigurationError, Credentials | HttpClient.HttpClient>;
export type ReportInstrumentationConfigurationStatusError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Reports the status of one or more instrumentation configurations from SDK instances. Use this to record when configurations become ready, hit errors, become active, or are disabled by limits.
 *
 * Report `READY`, `ERROR`, and `DISABLED` when the status changes. Report `ACTIVE` periodically (for example, every minute) while instrumentation is running.
 */
export declare const reportInstrumentationConfigurationStatus: API.OperationMethod<ReportInstrumentationConfigurationStatusRequest, ReportInstrumentationConfigurationStatusResponse, ReportInstrumentationConfigurationStatusError, Credentials | HttpClient.HttpClient>;
export type StartDiscoveryError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables this Amazon Web Services account to be able to use CloudWatch Application Signals by creating the *AWSServiceRoleForCloudWatchApplicationSignals* service-linked role. This service- linked role has the following permissions:
 *
 * - `xray:GetServiceGraph`
 *
 * - `logs:StartQuery`
 *
 * - `logs:GetQueryResults`
 *
 * - `cloudwatch:GetMetricData`
 *
 * - `cloudwatch:ListMetrics`
 *
 * - `tag:GetResources`
 *
 * - `autoscaling:DescribeAutoScalingGroups`
 *
 * A service-linked CloudTrail event channel is created to process CloudTrail events and return change event information. This includes last deployment time, userName, eventName, and other event metadata.
 *
 * After completing this step, you still need to instrument your Java and Python applications to send data to Application Signals. For more information, see Enabling Application Signals.
 */
export declare const startDiscovery: API.OperationMethod<StartDiscoveryInput, StartDiscoveryOutput, StartDiscoveryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified CloudWatch resource, such as a service level objective.
 *
 * Tags can help you organize and categorize your resources. You can also use them to scope user permissions by granting a user permission to access or change only resources with certain tag values.
 *
 * Tags don't have any semantic meaning to Amazon Web Services and are interpreted strictly as strings of characters.
 *
 * You can use the `TagResource` action with an alarm that already has tags. If you specify a new tag key for the alarm, this tag is appended to the list of tags associated with the alarm. If you specify a tag key that is already associated with the alarm, the new tag value that you specify replaces the previous value for that tag.
 *
 * You can associate as many as 50 tags with a CloudWatch resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes one or more tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceLevelObjectiveError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing service level objective (SLO). If you omit parameters, the previous values of those parameters are retained.
 *
 * You cannot change from a period-based SLO to a request-based SLO, or change from a request-based SLO to a period-based SLO.
 */
export declare const updateServiceLevelObjective: API.OperationMethod<UpdateServiceLevelObjectiveInput, UpdateServiceLevelObjectiveOutput, UpdateServiceLevelObjectiveError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=application-signals.d.ts.map