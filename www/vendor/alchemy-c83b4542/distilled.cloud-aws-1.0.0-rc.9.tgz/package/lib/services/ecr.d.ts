import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BlockedByOrganizationPolicyException_base: S.Class<BlockedByOrganizationPolicyException, S.TaggedStruct<"BlockedByOrganizationPolicyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BlockedByOrganizationPolicyException extends /*@__PURE__*/ BlockedByOrganizationPolicyException_base {
}
declare const EmptyUploadException_base: S.Class<EmptyUploadException, S.TaggedStruct<"EmptyUploadException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EmptyUploadException extends /*@__PURE__*/ EmptyUploadException_base {
}
declare const ExclusionAlreadyExistsException_base: S.Class<ExclusionAlreadyExistsException, S.TaggedStruct<"ExclusionAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ExclusionAlreadyExistsException extends /*@__PURE__*/ ExclusionAlreadyExistsException_base {
}
declare const ExclusionNotFoundException_base: S.Class<ExclusionNotFoundException, S.TaggedStruct<"ExclusionNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ExclusionNotFoundException extends /*@__PURE__*/ ExclusionNotFoundException_base {
}
declare const ImageAlreadyExistsException_base: S.Class<ImageAlreadyExistsException, S.TaggedStruct<"ImageAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ImageAlreadyExistsException extends /*@__PURE__*/ ImageAlreadyExistsException_base {
}
declare const ImageArchivedException_base: S.Class<ImageArchivedException, S.TaggedStruct<"ImageArchivedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ImageArchivedException extends /*@__PURE__*/ ImageArchivedException_base {
}
declare const ImageDigestDoesNotMatchException_base: S.Class<ImageDigestDoesNotMatchException, S.TaggedStruct<"ImageDigestDoesNotMatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ImageDigestDoesNotMatchException extends /*@__PURE__*/ ImageDigestDoesNotMatchException_base {
}
declare const ImageNotFoundException_base: S.Class<ImageNotFoundException, S.TaggedStruct<"ImageNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ImageNotFoundException extends /*@__PURE__*/ ImageNotFoundException_base {
}
declare const ImageStorageClassUpdateNotSupportedException_base: S.Class<ImageStorageClassUpdateNotSupportedException, S.TaggedStruct<"ImageStorageClassUpdateNotSupportedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ImageStorageClassUpdateNotSupportedException extends /*@__PURE__*/ ImageStorageClassUpdateNotSupportedException_base {
}
declare const ImageTagAlreadyExistsException_base: S.Class<ImageTagAlreadyExistsException, S.TaggedStruct<"ImageTagAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ImageTagAlreadyExistsException extends /*@__PURE__*/ ImageTagAlreadyExistsException_base {
}
declare const InvalidLayerException_base: S.Class<InvalidLayerException, S.TaggedStruct<"InvalidLayerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidLayerException extends /*@__PURE__*/ InvalidLayerException_base {
}
declare const InvalidLayerPartException_base: S.Class<InvalidLayerPartException, S.TaggedStruct<"InvalidLayerPartException", {
    readonly registryId: any;
    readonly repositoryName: any;
    readonly uploadId: any;
    readonly lastValidByteReceived: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidLayerPartException extends /*@__PURE__*/ InvalidLayerPartException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidTagParameterException_base: S.Class<InvalidTagParameterException, S.TaggedStruct<"InvalidTagParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTagParameterException extends /*@__PURE__*/ InvalidTagParameterException_base {
}
declare const KmsException_base: S.Class<KmsException, S.TaggedStruct<"KmsException", {
    readonly message: any;
    readonly kmsError: any;
}>, import("effect/Cause").YieldableError>;
export declare class KmsException extends /*@__PURE__*/ KmsException_base {
}
declare const LayerAlreadyExistsException_base: S.Class<LayerAlreadyExistsException, S.TaggedStruct<"LayerAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class LayerAlreadyExistsException extends /*@__PURE__*/ LayerAlreadyExistsException_base {
}
declare const LayerInaccessibleException_base: S.Class<LayerInaccessibleException, S.TaggedStruct<"LayerInaccessibleException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LayerInaccessibleException extends /*@__PURE__*/ LayerInaccessibleException_base {
}
declare const LayerPartTooSmallException_base: S.Class<LayerPartTooSmallException, S.TaggedStruct<"LayerPartTooSmallException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LayerPartTooSmallException extends /*@__PURE__*/ LayerPartTooSmallException_base {
}
declare const LayersNotFoundException_base: S.Class<LayersNotFoundException, S.TaggedStruct<"LayersNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LayersNotFoundException extends /*@__PURE__*/ LayersNotFoundException_base {
}
declare const LifecyclePolicyNotFoundException_base: S.Class<LifecyclePolicyNotFoundException, S.TaggedStruct<"LifecyclePolicyNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class LifecyclePolicyNotFoundException extends /*@__PURE__*/ LifecyclePolicyNotFoundException_base {
}
declare const LifecyclePolicyPreviewInProgressException_base: S.Class<LifecyclePolicyPreviewInProgressException, S.TaggedStruct<"LifecyclePolicyPreviewInProgressException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LifecyclePolicyPreviewInProgressException extends /*@__PURE__*/ LifecyclePolicyPreviewInProgressException_base {
}
declare const LifecyclePolicyPreviewNotFoundException_base: S.Class<LifecyclePolicyPreviewNotFoundException, S.TaggedStruct<"LifecyclePolicyPreviewNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LifecyclePolicyPreviewNotFoundException extends /*@__PURE__*/ LifecyclePolicyPreviewNotFoundException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const PullThroughCacheRuleAlreadyExistsException_base: S.Class<PullThroughCacheRuleAlreadyExistsException, S.TaggedStruct<"PullThroughCacheRuleAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class PullThroughCacheRuleAlreadyExistsException extends /*@__PURE__*/ PullThroughCacheRuleAlreadyExistsException_base {
}
declare const PullThroughCacheRuleNotFoundException_base: S.Class<PullThroughCacheRuleNotFoundException, S.TaggedStruct<"PullThroughCacheRuleNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PullThroughCacheRuleNotFoundException extends /*@__PURE__*/ PullThroughCacheRuleNotFoundException_base {
}
declare const ReferencedImagesNotFoundException_base: S.Class<ReferencedImagesNotFoundException, S.TaggedStruct<"ReferencedImagesNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ReferencedImagesNotFoundException extends /*@__PURE__*/ ReferencedImagesNotFoundException_base {
}
declare const RegistryPolicyNotFoundException_base: S.Class<RegistryPolicyNotFoundException, S.TaggedStruct<"RegistryPolicyNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RegistryPolicyNotFoundException extends /*@__PURE__*/ RegistryPolicyNotFoundException_base {
}
declare const RepositoryAlreadyExistsException_base: S.Class<RepositoryAlreadyExistsException, S.TaggedStruct<"RepositoryAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class RepositoryAlreadyExistsException extends /*@__PURE__*/ RepositoryAlreadyExistsException_base {
}
declare const RepositoryNotEmptyException_base: S.Class<RepositoryNotEmptyException, S.TaggedStruct<"RepositoryNotEmptyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class RepositoryNotEmptyException extends /*@__PURE__*/ RepositoryNotEmptyException_base {
}
declare const RepositoryNotFoundException_base: S.Class<RepositoryNotFoundException, S.TaggedStruct<"RepositoryNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class RepositoryNotFoundException extends /*@__PURE__*/ RepositoryNotFoundException_base {
}
declare const RepositoryPolicyNotFoundException_base: S.Class<RepositoryPolicyNotFoundException, S.TaggedStruct<"RepositoryPolicyNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class RepositoryPolicyNotFoundException extends /*@__PURE__*/ RepositoryPolicyNotFoundException_base {
}
declare const ScanNotFoundException_base: S.Class<ScanNotFoundException, S.TaggedStruct<"ScanNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ScanNotFoundException extends /*@__PURE__*/ ScanNotFoundException_base {
}
declare const SecretNotFoundException_base: S.Class<SecretNotFoundException, S.TaggedStruct<"SecretNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SecretNotFoundException extends /*@__PURE__*/ SecretNotFoundException_base {
}
declare const ServerException_base: S.Class<ServerException, S.TaggedStruct<"ServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServerException extends /*@__PURE__*/ ServerException_base {
}
declare const SigningConfigurationNotFoundException_base: S.Class<SigningConfigurationNotFoundException, S.TaggedStruct<"SigningConfigurationNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SigningConfigurationNotFoundException extends /*@__PURE__*/ SigningConfigurationNotFoundException_base {
}
declare const TemplateAlreadyExistsException_base: S.Class<TemplateAlreadyExistsException, S.TaggedStruct<"TemplateAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TemplateAlreadyExistsException extends /*@__PURE__*/ TemplateAlreadyExistsException_base {
}
declare const TemplateNotFoundException_base: S.Class<TemplateNotFoundException, S.TaggedStruct<"TemplateNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TemplateNotFoundException extends /*@__PURE__*/ TemplateNotFoundException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnableToAccessSecretException_base: S.Class<UnableToAccessSecretException, S.TaggedStruct<"UnableToAccessSecretException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnableToAccessSecretException extends /*@__PURE__*/ UnableToAccessSecretException_base {
}
declare const UnableToDecryptSecretValueException_base: S.Class<UnableToDecryptSecretValueException, S.TaggedStruct<"UnableToDecryptSecretValueException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnableToDecryptSecretValueException extends /*@__PURE__*/ UnableToDecryptSecretValueException_base {
}
declare const UnableToGetUpstreamImageException_base: S.Class<UnableToGetUpstreamImageException, S.TaggedStruct<"UnableToGetUpstreamImageException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnableToGetUpstreamImageException extends /*@__PURE__*/ UnableToGetUpstreamImageException_base {
}
declare const UnableToGetUpstreamLayerException_base: S.Class<UnableToGetUpstreamLayerException, S.TaggedStruct<"UnableToGetUpstreamLayerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnableToGetUpstreamLayerException extends /*@__PURE__*/ UnableToGetUpstreamLayerException_base {
}
declare const UnableToListUpstreamImageReferrersException_base: S.Class<UnableToListUpstreamImageReferrersException, S.TaggedStruct<"UnableToListUpstreamImageReferrersException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnableToListUpstreamImageReferrersException extends /*@__PURE__*/ UnableToListUpstreamImageReferrersException_base {
}
declare const UnsupportedImageTypeException_base: S.Class<UnsupportedImageTypeException, S.TaggedStruct<"UnsupportedImageTypeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnsupportedImageTypeException extends /*@__PURE__*/ UnsupportedImageTypeException_base {
}
declare const UnsupportedUpstreamRegistryException_base: S.Class<UnsupportedUpstreamRegistryException, S.TaggedStruct<"UnsupportedUpstreamRegistryException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnsupportedUpstreamRegistryException extends /*@__PURE__*/ UnsupportedUpstreamRegistryException_base {
}
declare const UploadNotFoundException_base: S.Class<UploadNotFoundException, S.TaggedStruct<"UploadNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UploadNotFoundException extends /*@__PURE__*/ UploadNotFoundException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RegistryId = string;
export type RepositoryName = string;
export type BatchedOperationLayerDigest = string;
export type BatchedOperationLayerDigestList = string[];
export declare const BatchedOperationLayerDigestList: any;
export interface BatchCheckLayerAvailabilityRequest {
    registryId?: string;
    repositoryName: string;
    layerDigests: string[];
}
export declare const BatchCheckLayerAvailabilityRequest: S.Schema<BatchCheckLayerAvailabilityRequest>;
export type LayerDigest = string;
export type LayerAvailability = "AVAILABLE" | "UNAVAILABLE" | "ARCHIVED" | (string & {});
export declare const LayerAvailability: any;
export type LayerSizeInBytes = number;
export type MediaType = string;
export interface Layer {
    layerDigest?: string;
    layerAvailability?: LayerAvailability;
    layerSize?: number;
    mediaType?: string;
}
export declare const Layer: S.Schema<Layer>;
export type LayerList = Layer[];
export declare const LayerList: any;
export type LayerFailureCode = "InvalidLayerDigest" | "MissingLayerDigest" | (string & {});
export declare const LayerFailureCode: any;
export type LayerFailureReason = string;
export interface LayerFailure {
    layerDigest?: string;
    failureCode?: LayerFailureCode;
    failureReason?: string;
}
export declare const LayerFailure: S.Schema<LayerFailure>;
export type LayerFailureList = LayerFailure[];
export declare const LayerFailureList: any;
export interface BatchCheckLayerAvailabilityResponse {
    layers?: Layer[];
    failures?: LayerFailure[];
}
export declare const BatchCheckLayerAvailabilityResponse: S.Schema<BatchCheckLayerAvailabilityResponse>;
export type ImageDigest = string;
export type ImageTag = string;
export interface ImageIdentifier {
    imageDigest?: string;
    imageTag?: string;
}
export declare const ImageIdentifier: S.Schema<ImageIdentifier>;
export type ImageIdentifierList = ImageIdentifier[];
export declare const ImageIdentifierList: any;
export interface BatchDeleteImageRequest {
    registryId?: string;
    repositoryName: string;
    imageIds: ImageIdentifier[];
}
export declare const BatchDeleteImageRequest: S.Schema<BatchDeleteImageRequest>;
export type ImageFailureCode = "InvalidImageDigest" | "InvalidImageTag" | "ImageTagDoesNotMatchDigest" | "ImageNotFound" | "MissingDigestAndTag" | "ImageReferencedByManifestList" | "KmsError" | "UpstreamAccessDenied" | "UpstreamTooManyRequests" | "UpstreamUnavailable" | "ImageInaccessible" | (string & {});
export declare const ImageFailureCode: any;
export type ImageFailureReason = string;
export interface ImageFailure {
    imageId?: ImageIdentifier;
    failureCode?: ImageFailureCode;
    failureReason?: string;
}
export declare const ImageFailure: S.Schema<ImageFailure>;
export type ImageFailureList = ImageFailure[];
export declare const ImageFailureList: any;
export interface BatchDeleteImageResponse {
    imageIds?: ImageIdentifier[];
    failures?: ImageFailure[];
}
export declare const BatchDeleteImageResponse: S.Schema<BatchDeleteImageResponse>;
export type MediaTypeList = string[];
export declare const MediaTypeList: any;
export interface BatchGetImageRequest {
    registryId?: string;
    repositoryName: string;
    imageIds: ImageIdentifier[];
    acceptedMediaTypes?: string[];
}
export declare const BatchGetImageRequest: S.Schema<BatchGetImageRequest>;
export type ImageManifest = string;
export interface Image {
    registryId?: string;
    repositoryName?: string;
    imageId?: ImageIdentifier;
    imageManifest?: string;
    imageManifestMediaType?: string;
}
export declare const Image: S.Schema<Image>;
export type ImageList = Image[];
export declare const ImageList: any;
export interface BatchGetImageResponse {
    images?: Image[];
    failures?: ImageFailure[];
}
export declare const BatchGetImageResponse: S.Schema<BatchGetImageResponse>;
export type ScanningConfigurationRepositoryNameList = string[];
export declare const ScanningConfigurationRepositoryNameList: any;
export interface BatchGetRepositoryScanningConfigurationRequest {
    repositoryNames: string[];
}
export declare const BatchGetRepositoryScanningConfigurationRequest: S.Schema<BatchGetRepositoryScanningConfigurationRequest>;
export type Arn = string;
export type ScanOnPushFlag = boolean;
export type ScanFrequency = "SCAN_ON_PUSH" | "CONTINUOUS_SCAN" | "MANUAL" | (string & {});
export declare const ScanFrequency: any;
export type ScanningRepositoryFilterValue = string;
export type ScanningRepositoryFilterType = "WILDCARD" | (string & {});
export declare const ScanningRepositoryFilterType: any;
export interface ScanningRepositoryFilter {
    filter: string;
    filterType: ScanningRepositoryFilterType;
}
export declare const ScanningRepositoryFilter: S.Schema<ScanningRepositoryFilter>;
export type ScanningRepositoryFilterList = ScanningRepositoryFilter[];
export declare const ScanningRepositoryFilterList: any;
export interface RepositoryScanningConfiguration {
    repositoryArn?: string;
    repositoryName?: string;
    scanOnPush?: boolean;
    scanFrequency?: ScanFrequency;
    appliedScanFilters?: ScanningRepositoryFilter[];
}
export declare const RepositoryScanningConfiguration: S.Schema<RepositoryScanningConfiguration>;
export type RepositoryScanningConfigurationList = RepositoryScanningConfiguration[];
export declare const RepositoryScanningConfigurationList: any;
export type ScanningConfigurationFailureCode = "REPOSITORY_NOT_FOUND" | (string & {});
export declare const ScanningConfigurationFailureCode: any;
export type ScanningConfigurationFailureReason = string;
export interface RepositoryScanningConfigurationFailure {
    repositoryName?: string;
    failureCode?: ScanningConfigurationFailureCode;
    failureReason?: string;
}
export declare const RepositoryScanningConfigurationFailure: S.Schema<RepositoryScanningConfigurationFailure>;
export type RepositoryScanningConfigurationFailureList = RepositoryScanningConfigurationFailure[];
export declare const RepositoryScanningConfigurationFailureList: any;
export interface BatchGetRepositoryScanningConfigurationResponse {
    scanningConfigurations?: RepositoryScanningConfiguration[];
    failures?: RepositoryScanningConfigurationFailure[];
}
export declare const BatchGetRepositoryScanningConfigurationResponse: S.Schema<BatchGetRepositoryScanningConfigurationResponse>;
export type UploadId = string;
export type LayerDigestList = string[];
export declare const LayerDigestList: any;
export interface CompleteLayerUploadRequest {
    registryId?: string;
    repositoryName: string;
    uploadId: string;
    layerDigests: string[];
}
export declare const CompleteLayerUploadRequest: S.Schema<CompleteLayerUploadRequest>;
export interface CompleteLayerUploadResponse {
    registryId?: string;
    repositoryName?: string;
    uploadId?: string;
    layerDigest?: string;
}
export declare const CompleteLayerUploadResponse: S.Schema<CompleteLayerUploadResponse>;
export type PullThroughCacheRuleRepositoryPrefix = string;
export type Url = string;
export type UpstreamRegistry = "ecr" | "ecr-public" | "quay" | "k8s" | "docker-hub" | "github-container-registry" | "azure-container-registry" | "gitlab-container-registry" | "chainguard" | (string & {});
export declare const UpstreamRegistry: any;
export type CredentialArn = string;
export type CustomRoleArn = string;
export interface CreatePullThroughCacheRuleRequest {
    ecrRepositoryPrefix: string;
    upstreamRegistryUrl: string;
    registryId?: string;
    upstreamRegistry?: UpstreamRegistry;
    credentialArn?: string;
    customRoleArn?: string;
    upstreamRepositoryPrefix?: string;
}
export declare const CreatePullThroughCacheRuleRequest: S.Schema<CreatePullThroughCacheRuleRequest>;
export type CreationTimestamp = Date;
export interface CreatePullThroughCacheRuleResponse {
    ecrRepositoryPrefix?: string;
    upstreamRegistryUrl?: string;
    createdAt?: Date;
    registryId?: string;
    upstreamRegistry?: UpstreamRegistry;
    credentialArn?: string;
    customRoleArn?: string;
    upstreamRepositoryPrefix?: string;
}
export declare const CreatePullThroughCacheRuleResponse: S.Schema<CreatePullThroughCacheRuleResponse>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type ImageTagMutability = "MUTABLE" | "IMMUTABLE" | "IMMUTABLE_WITH_EXCLUSION" | "MUTABLE_WITH_EXCLUSION" | (string & {});
export declare const ImageTagMutability: any;
export type ImageTagMutabilityExclusionFilterType = "WILDCARD" | (string & {});
export declare const ImageTagMutabilityExclusionFilterType: any;
export type ImageTagMutabilityExclusionFilterValue = string;
export interface ImageTagMutabilityExclusionFilter {
    filterType: ImageTagMutabilityExclusionFilterType;
    filter: string;
}
export declare const ImageTagMutabilityExclusionFilter: S.Schema<ImageTagMutabilityExclusionFilter>;
export type ImageTagMutabilityExclusionFilters = ImageTagMutabilityExclusionFilter[];
export declare const ImageTagMutabilityExclusionFilters: any;
export interface ImageScanningConfiguration {
    scanOnPush?: boolean;
}
export declare const ImageScanningConfiguration: S.Schema<ImageScanningConfiguration>;
export type EncryptionType = "AES256" | "KMS" | "KMS_DSSE" | (string & {});
export declare const EncryptionType: any;
export type KmsKey = string;
export interface EncryptionConfiguration {
    encryptionType: EncryptionType;
    kmsKey?: string;
}
export declare const EncryptionConfiguration: S.Schema<EncryptionConfiguration>;
export interface CreateRepositoryRequest {
    registryId?: string;
    repositoryName: string;
    tags?: Tag[];
    imageTagMutability?: ImageTagMutability;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[];
    imageScanningConfiguration?: ImageScanningConfiguration;
    encryptionConfiguration?: EncryptionConfiguration;
}
export declare const CreateRepositoryRequest: S.Schema<CreateRepositoryRequest>;
export interface Repository {
    repositoryArn?: string;
    registryId?: string;
    repositoryName?: string;
    repositoryUri?: string;
    createdAt?: Date;
    imageTagMutability?: ImageTagMutability;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[];
    imageScanningConfiguration?: ImageScanningConfiguration;
    encryptionConfiguration?: EncryptionConfiguration;
}
export declare const Repository: S.Schema<Repository>;
export interface CreateRepositoryResponse {
    repository?: Repository;
}
export declare const CreateRepositoryResponse: S.Schema<CreateRepositoryResponse>;
export type Prefix = string;
export type RepositoryTemplateDescription = string;
export type KmsKeyForRepositoryCreationTemplate = string;
export interface EncryptionConfigurationForRepositoryCreationTemplate {
    encryptionType: EncryptionType;
    kmsKey?: string;
}
export declare const EncryptionConfigurationForRepositoryCreationTemplate: S.Schema<EncryptionConfigurationForRepositoryCreationTemplate>;
export type RepositoryPolicyText = string;
export type LifecyclePolicyTextForRepositoryCreationTemplate = string;
export type RCTAppliedFor = "REPLICATION" | "PULL_THROUGH_CACHE" | "CREATE_ON_PUSH" | (string & {});
export declare const RCTAppliedFor: any;
export type RCTAppliedForList = RCTAppliedFor[];
export declare const RCTAppliedForList: any;
export interface CreateRepositoryCreationTemplateRequest {
    prefix: string;
    description?: string;
    encryptionConfiguration?: EncryptionConfigurationForRepositoryCreationTemplate;
    resourceTags?: Tag[];
    imageTagMutability?: ImageTagMutability;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[];
    repositoryPolicy?: string;
    lifecyclePolicy?: string;
    appliedFor: RCTAppliedFor[];
    customRoleArn?: string;
}
export declare const CreateRepositoryCreationTemplateRequest: S.Schema<CreateRepositoryCreationTemplateRequest>;
export interface RepositoryCreationTemplate {
    prefix?: string;
    description?: string;
    encryptionConfiguration?: EncryptionConfigurationForRepositoryCreationTemplate;
    resourceTags?: Tag[];
    imageTagMutability?: ImageTagMutability;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[];
    repositoryPolicy?: string;
    lifecyclePolicy?: string;
    appliedFor?: RCTAppliedFor[];
    customRoleArn?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const RepositoryCreationTemplate: S.Schema<RepositoryCreationTemplate>;
export interface CreateRepositoryCreationTemplateResponse {
    registryId?: string;
    repositoryCreationTemplate?: RepositoryCreationTemplate;
}
export declare const CreateRepositoryCreationTemplateResponse: S.Schema<CreateRepositoryCreationTemplateResponse>;
export interface DeleteLifecyclePolicyRequest {
    registryId?: string;
    repositoryName: string;
}
export declare const DeleteLifecyclePolicyRequest: S.Schema<DeleteLifecyclePolicyRequest>;
export type LifecyclePolicyText = string;
export type EvaluationTimestamp = Date;
export interface DeleteLifecyclePolicyResponse {
    registryId?: string;
    repositoryName?: string;
    lifecyclePolicyText?: string;
    lastEvaluatedAt?: Date;
}
export declare const DeleteLifecyclePolicyResponse: S.Schema<DeleteLifecyclePolicyResponse>;
export interface DeletePullThroughCacheRuleRequest {
    ecrRepositoryPrefix: string;
    registryId?: string;
}
export declare const DeletePullThroughCacheRuleRequest: S.Schema<DeletePullThroughCacheRuleRequest>;
export interface DeletePullThroughCacheRuleResponse {
    ecrRepositoryPrefix?: string;
    upstreamRegistryUrl?: string;
    createdAt?: Date;
    registryId?: string;
    credentialArn?: string;
    customRoleArn?: string;
    upstreamRepositoryPrefix?: string;
}
export declare const DeletePullThroughCacheRuleResponse: S.Schema<DeletePullThroughCacheRuleResponse>;
export interface DeleteRegistryPolicyRequest {
}
export declare const DeleteRegistryPolicyRequest: S.Schema<DeleteRegistryPolicyRequest>;
export type RegistryPolicyText = string;
export interface DeleteRegistryPolicyResponse {
    registryId?: string;
    policyText?: string;
}
export declare const DeleteRegistryPolicyResponse: S.Schema<DeleteRegistryPolicyResponse>;
export type ForceFlag = boolean;
export interface DeleteRepositoryRequest {
    registryId?: string;
    repositoryName: string;
    force?: boolean;
}
export declare const DeleteRepositoryRequest: S.Schema<DeleteRepositoryRequest>;
export interface DeleteRepositoryResponse {
    repository?: Repository;
}
export declare const DeleteRepositoryResponse: S.Schema<DeleteRepositoryResponse>;
export interface DeleteRepositoryCreationTemplateRequest {
    prefix: string;
}
export declare const DeleteRepositoryCreationTemplateRequest: S.Schema<DeleteRepositoryCreationTemplateRequest>;
export interface DeleteRepositoryCreationTemplateResponse {
    registryId?: string;
    repositoryCreationTemplate?: RepositoryCreationTemplate;
}
export declare const DeleteRepositoryCreationTemplateResponse: S.Schema<DeleteRepositoryCreationTemplateResponse>;
export interface DeleteRepositoryPolicyRequest {
    registryId?: string;
    repositoryName: string;
}
export declare const DeleteRepositoryPolicyRequest: S.Schema<DeleteRepositoryPolicyRequest>;
export interface DeleteRepositoryPolicyResponse {
    registryId?: string;
    repositoryName?: string;
    policyText?: string;
}
export declare const DeleteRepositoryPolicyResponse: S.Schema<DeleteRepositoryPolicyResponse>;
export interface DeleteSigningConfigurationRequest {
}
export declare const DeleteSigningConfigurationRequest: S.Schema<DeleteSigningConfigurationRequest>;
export type SigningProfileArn = string;
export type SigningRepositoryFilterValue = string;
export type SigningRepositoryFilterType = "WILDCARD_MATCH" | (string & {});
export declare const SigningRepositoryFilterType: any;
export interface SigningRepositoryFilter {
    filter: string;
    filterType: SigningRepositoryFilterType;
}
export declare const SigningRepositoryFilter: S.Schema<SigningRepositoryFilter>;
export type SigningRepositoryFilterList = SigningRepositoryFilter[];
export declare const SigningRepositoryFilterList: any;
export interface SigningRule {
    signingProfileArn: string;
    repositoryFilters?: SigningRepositoryFilter[];
}
export declare const SigningRule: S.Schema<SigningRule>;
export type SigningRuleList = SigningRule[];
export declare const SigningRuleList: any;
export interface SigningConfiguration {
    rules: SigningRule[];
}
export declare const SigningConfiguration: S.Schema<SigningConfiguration>;
export interface DeleteSigningConfigurationResponse {
    registryId?: string;
    signingConfiguration?: SigningConfiguration;
}
export declare const DeleteSigningConfigurationResponse: S.Schema<DeleteSigningConfigurationResponse>;
export type PrincipalArn = string;
export interface DeregisterPullTimeUpdateExclusionRequest {
    principalArn: string;
}
export declare const DeregisterPullTimeUpdateExclusionRequest: S.Schema<DeregisterPullTimeUpdateExclusionRequest>;
export interface DeregisterPullTimeUpdateExclusionResponse {
    principalArn?: string;
}
export declare const DeregisterPullTimeUpdateExclusionResponse: S.Schema<DeregisterPullTimeUpdateExclusionResponse>;
export interface DescribeImageReplicationStatusRequest {
    repositoryName: string;
    imageId: ImageIdentifier;
    registryId?: string;
}
export declare const DescribeImageReplicationStatusRequest: S.Schema<DescribeImageReplicationStatusRequest>;
export type Region = string;
export type ReplicationStatus = "IN_PROGRESS" | "COMPLETE" | "FAILED" | (string & {});
export declare const ReplicationStatus: any;
export type ReplicationError = string;
export interface ImageReplicationStatus {
    region?: string;
    registryId?: string;
    status?: ReplicationStatus;
    failureCode?: string;
}
export declare const ImageReplicationStatus: S.Schema<ImageReplicationStatus>;
export type ImageReplicationStatusList = ImageReplicationStatus[];
export declare const ImageReplicationStatusList: any;
export interface DescribeImageReplicationStatusResponse {
    repositoryName?: string;
    imageId?: ImageIdentifier;
    replicationStatuses?: ImageReplicationStatus[];
}
export declare const DescribeImageReplicationStatusResponse: S.Schema<DescribeImageReplicationStatusResponse>;
export type NextToken = string;
export type MaxResults = number;
export type TagStatus = "TAGGED" | "UNTAGGED" | "ANY" | (string & {});
export declare const TagStatus: any;
export type ImageStatusFilter = "ACTIVE" | "ARCHIVED" | "ACTIVATING" | "ANY" | (string & {});
export declare const ImageStatusFilter: any;
export interface DescribeImagesFilter {
    tagStatus?: TagStatus;
    imageStatus?: ImageStatusFilter;
}
export declare const DescribeImagesFilter: S.Schema<DescribeImagesFilter>;
export interface DescribeImagesRequest {
    registryId?: string;
    repositoryName: string;
    imageIds?: ImageIdentifier[];
    nextToken?: string;
    maxResults?: number;
    filter?: DescribeImagesFilter;
}
export declare const DescribeImagesRequest: S.Schema<DescribeImagesRequest>;
export type ImageTagList = string[];
export declare const ImageTagList: any;
export type ImageSizeInBytes = number;
export type PushTimestamp = Date;
export type ScanStatus = "IN_PROGRESS" | "COMPLETE" | "FAILED" | "UNSUPPORTED_IMAGE" | "ACTIVE" | "PENDING" | "SCAN_ELIGIBILITY_EXPIRED" | "FINDINGS_UNAVAILABLE" | "LIMIT_EXCEEDED" | "IMAGE_ARCHIVED" | (string & {});
export declare const ScanStatus: any;
export type ScanStatusDescription = string;
export interface ImageScanStatus {
    status?: ScanStatus;
    description?: string;
}
export declare const ImageScanStatus: S.Schema<ImageScanStatus>;
export type ScanTimestamp = Date;
export type VulnerabilitySourceUpdateTimestamp = Date;
export type FindingSeverity = "INFORMATIONAL" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | "UNDEFINED" | (string & {});
export declare const FindingSeverity: any;
export type SeverityCount = number;
export type FindingSeverityCounts = {
    [key in FindingSeverity]?: number;
};
export declare const FindingSeverityCounts: any;
export interface ImageScanFindingsSummary {
    imageScanCompletedAt?: Date;
    vulnerabilitySourceUpdatedAt?: Date;
    findingSeverityCounts?: {
        [key: string]: number | undefined;
    };
}
export declare const ImageScanFindingsSummary: S.Schema<ImageScanFindingsSummary>;
export type RecordedPullTimestamp = Date;
export type ImageStatus = "ACTIVE" | "ARCHIVED" | "ACTIVATING" | (string & {});
export declare const ImageStatus: any;
export type LastArchivedAtTimestamp = Date;
export type LastActivatedAtTimestamp = Date;
export interface ImageDetail {
    registryId?: string;
    repositoryName?: string;
    imageDigest?: string;
    imageTags?: string[];
    imageSizeInBytes?: number;
    imagePushedAt?: Date;
    imageScanStatus?: ImageScanStatus;
    imageScanFindingsSummary?: ImageScanFindingsSummary;
    imageManifestMediaType?: string;
    artifactMediaType?: string;
    lastRecordedPullTime?: Date;
    subjectManifestDigest?: string;
    imageStatus?: ImageStatus;
    lastArchivedAt?: Date;
    lastActivatedAt?: Date;
}
export declare const ImageDetail: S.Schema<ImageDetail>;
export type ImageDetailList = ImageDetail[];
export declare const ImageDetailList: any;
export interface DescribeImagesResponse {
    imageDetails?: ImageDetail[];
    nextToken?: string;
}
export declare const DescribeImagesResponse: S.Schema<DescribeImagesResponse>;
export interface DescribeImageScanFindingsRequest {
    registryId?: string;
    repositoryName: string;
    imageId: ImageIdentifier;
    nextToken?: string;
    maxResults?: number;
}
export declare const DescribeImageScanFindingsRequest: S.Schema<DescribeImageScanFindingsRequest>;
export type FindingName = string;
export type FindingDescription = string;
export type AttributeKey = string;
export type AttributeValue = string;
export interface Attribute {
    key: string;
    value?: string;
}
export declare const Attribute: S.Schema<Attribute>;
export type AttributeList = Attribute[];
export declare const AttributeList: any;
export interface ImageScanFinding {
    name?: string;
    description?: string;
    uri?: string;
    severity?: FindingSeverity;
    attributes?: Attribute[];
}
export declare const ImageScanFinding: S.Schema<ImageScanFinding>;
export type ImageScanFindingList = ImageScanFinding[];
export declare const ImageScanFindingList: any;
export type FindingArn = string;
export type BaseScore = number;
export type ScoringVector = string;
export type Source = string;
export type Version = string;
export interface CvssScore {
    baseScore?: number;
    scoringVector?: string;
    source?: string;
    version?: string;
}
export declare const CvssScore: S.Schema<CvssScore>;
export type CvssScoreList = CvssScore[];
export declare const CvssScoreList: any;
export type ReferenceUrlsList = string[];
export declare const ReferenceUrlsList: any;
export type RelatedVulnerability = string;
export type RelatedVulnerabilitiesList = string[];
export declare const RelatedVulnerabilitiesList: any;
export type Severity = string;
export type VulnerabilityId = string;
export type Arch = string;
export type Epoch = number;
export type FilePath = string;
export type VulnerablePackageName = string;
export type PackageManager = string;
export type Release = string;
export type SourceLayerHash = string;
export type FixedInVersion = string;
export interface VulnerablePackage {
    arch?: string;
    epoch?: number;
    filePath?: string;
    name?: string;
    packageManager?: string;
    release?: string;
    sourceLayerHash?: string;
    version?: string;
    fixedInVersion?: string;
}
export declare const VulnerablePackage: S.Schema<VulnerablePackage>;
export type VulnerablePackagesList = VulnerablePackage[];
export declare const VulnerablePackagesList: any;
export interface PackageVulnerabilityDetails {
    cvss?: CvssScore[];
    referenceUrls?: string[];
    relatedVulnerabilities?: string[];
    source?: string;
    sourceUrl?: string;
    vendorCreatedAt?: Date;
    vendorSeverity?: string;
    vendorUpdatedAt?: Date;
    vulnerabilityId?: string;
    vulnerablePackages?: VulnerablePackage[];
}
export declare const PackageVulnerabilityDetails: S.Schema<PackageVulnerabilityDetails>;
export type RecommendationText = string;
export interface Recommendation {
    url?: string;
    text?: string;
}
export declare const Recommendation: S.Schema<Recommendation>;
export interface Remediation {
    recommendation?: Recommendation;
}
export declare const Remediation: S.Schema<Remediation>;
export type Author = string;
export type ImageTagsList = string[];
export declare const ImageTagsList: any;
export type Platform = string;
export type InUseCount = number;
export interface AwsEcrContainerImageDetails {
    architecture?: string;
    author?: string;
    imageHash?: string;
    imageTags?: string[];
    platform?: string;
    pushedAt?: Date;
    lastInUseAt?: Date;
    inUseCount?: number;
    registry?: string;
    repositoryName?: string;
}
export declare const AwsEcrContainerImageDetails: S.Schema<AwsEcrContainerImageDetails>;
export interface ResourceDetails {
    awsEcrContainerImage?: AwsEcrContainerImageDetails;
}
export declare const ResourceDetails: S.Schema<ResourceDetails>;
export type ResourceId = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export type Type = string;
export interface Resource {
    details?: ResourceDetails;
    id?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    type?: string;
}
export declare const Resource: S.Schema<Resource>;
export type ResourceList = Resource[];
export declare const ResourceList: any;
export type Score = number;
export type Metric = string;
export type Reason = string;
export interface CvssScoreAdjustment {
    metric?: string;
    reason?: string;
}
export declare const CvssScoreAdjustment: S.Schema<CvssScoreAdjustment>;
export type CvssScoreAdjustmentList = CvssScoreAdjustment[];
export declare const CvssScoreAdjustmentList: any;
export interface CvssScoreDetails {
    adjustments?: CvssScoreAdjustment[];
    score?: number;
    scoreSource?: string;
    scoringVector?: string;
    version?: string;
}
export declare const CvssScoreDetails: S.Schema<CvssScoreDetails>;
export interface ScoreDetails {
    cvss?: CvssScoreDetails;
}
export declare const ScoreDetails: S.Schema<ScoreDetails>;
export type Status = string;
export type Title = string;
export type FixAvailable = string;
export type ExploitAvailable = string;
export interface EnhancedImageScanFinding {
    awsAccountId?: string;
    description?: string;
    findingArn?: string;
    firstObservedAt?: Date;
    lastObservedAt?: Date;
    packageVulnerabilityDetails?: PackageVulnerabilityDetails;
    remediation?: Remediation;
    resources?: Resource[];
    score?: number;
    scoreDetails?: ScoreDetails;
    severity?: string;
    status?: string;
    title?: string;
    type?: string;
    updatedAt?: Date;
    fixAvailable?: string;
    exploitAvailable?: string;
}
export declare const EnhancedImageScanFinding: S.Schema<EnhancedImageScanFinding>;
export type EnhancedImageScanFindingList = EnhancedImageScanFinding[];
export declare const EnhancedImageScanFindingList: any;
export interface ImageScanFindings {
    imageScanCompletedAt?: Date;
    vulnerabilitySourceUpdatedAt?: Date;
    findingSeverityCounts?: {
        [key: string]: number | undefined;
    };
    findings?: ImageScanFinding[];
    enhancedFindings?: EnhancedImageScanFinding[];
}
export declare const ImageScanFindings: S.Schema<ImageScanFindings>;
export interface DescribeImageScanFindingsResponse {
    registryId?: string;
    repositoryName?: string;
    imageId?: ImageIdentifier;
    imageScanStatus?: ImageScanStatus;
    imageScanFindings?: ImageScanFindings;
    nextToken?: string;
}
export declare const DescribeImageScanFindingsResponse: S.Schema<DescribeImageScanFindingsResponse>;
export interface DescribeImageSigningStatusRequest {
    repositoryName: string;
    imageId: ImageIdentifier;
    registryId?: string;
}
export declare const DescribeImageSigningStatusRequest: S.Schema<DescribeImageSigningStatusRequest>;
export type SigningStatusFailureCode = string;
export type SigningStatusFailureReason = string;
export type SigningStatus = "IN_PROGRESS" | "COMPLETE" | "FAILED" | (string & {});
export declare const SigningStatus: any;
export interface ImageSigningStatus {
    signingProfileArn?: string;
    failureCode?: string;
    failureReason?: string;
    status?: SigningStatus;
}
export declare const ImageSigningStatus: S.Schema<ImageSigningStatus>;
export type ImageSigningStatusList = ImageSigningStatus[];
export declare const ImageSigningStatusList: any;
export interface DescribeImageSigningStatusResponse {
    repositoryName?: string;
    imageId?: ImageIdentifier;
    registryId?: string;
    signingStatuses?: ImageSigningStatus[];
}
export declare const DescribeImageSigningStatusResponse: S.Schema<DescribeImageSigningStatusResponse>;
export type PullThroughCacheRuleRepositoryPrefixList = string[];
export declare const PullThroughCacheRuleRepositoryPrefixList: any;
export interface DescribePullThroughCacheRulesRequest {
    registryId?: string;
    ecrRepositoryPrefixes?: string[];
    nextToken?: string;
    maxResults?: number;
}
export declare const DescribePullThroughCacheRulesRequest: S.Schema<DescribePullThroughCacheRulesRequest>;
export type UpdatedTimestamp = Date;
export interface PullThroughCacheRule {
    ecrRepositoryPrefix?: string;
    upstreamRegistryUrl?: string;
    createdAt?: Date;
    registryId?: string;
    credentialArn?: string;
    customRoleArn?: string;
    upstreamRepositoryPrefix?: string;
    upstreamRegistry?: UpstreamRegistry;
    updatedAt?: Date;
}
export declare const PullThroughCacheRule: S.Schema<PullThroughCacheRule>;
export type PullThroughCacheRuleList = PullThroughCacheRule[];
export declare const PullThroughCacheRuleList: any;
export interface DescribePullThroughCacheRulesResponse {
    pullThroughCacheRules?: PullThroughCacheRule[];
    nextToken?: string;
}
export declare const DescribePullThroughCacheRulesResponse: S.Schema<DescribePullThroughCacheRulesResponse>;
export interface DescribeRegistryRequest {
}
export declare const DescribeRegistryRequest: S.Schema<DescribeRegistryRequest>;
export interface ReplicationDestination {
    region: string;
    registryId: string;
}
export declare const ReplicationDestination: S.Schema<ReplicationDestination>;
export type ReplicationDestinationList = ReplicationDestination[];
export declare const ReplicationDestinationList: any;
export type RepositoryFilterValue = string;
export type RepositoryFilterType = "PREFIX_MATCH" | (string & {});
export declare const RepositoryFilterType: any;
export interface RepositoryFilter {
    filter: string;
    filterType: RepositoryFilterType;
}
export declare const RepositoryFilter: S.Schema<RepositoryFilter>;
export type RepositoryFilterList = RepositoryFilter[];
export declare const RepositoryFilterList: any;
export interface ReplicationRule {
    destinations: ReplicationDestination[];
    repositoryFilters?: RepositoryFilter[];
}
export declare const ReplicationRule: S.Schema<ReplicationRule>;
export type ReplicationRuleList = ReplicationRule[];
export declare const ReplicationRuleList: any;
export interface ReplicationConfiguration {
    rules: ReplicationRule[];
}
export declare const ReplicationConfiguration: S.Schema<ReplicationConfiguration>;
export interface DescribeRegistryResponse {
    registryId?: string;
    replicationConfiguration?: ReplicationConfiguration;
}
export declare const DescribeRegistryResponse: S.Schema<DescribeRegistryResponse>;
export type RepositoryNameList = string[];
export declare const RepositoryNameList: any;
export interface DescribeRepositoriesRequest {
    registryId?: string;
    repositoryNames?: string[];
    nextToken?: string;
    maxResults?: number;
}
export declare const DescribeRepositoriesRequest: S.Schema<DescribeRepositoriesRequest>;
export type RepositoryList = Repository[];
export declare const RepositoryList: any;
export interface DescribeRepositoriesResponse {
    repositories?: Repository[];
    nextToken?: string;
}
export declare const DescribeRepositoriesResponse: S.Schema<DescribeRepositoriesResponse>;
export type PrefixList = string[];
export declare const PrefixList: any;
export interface DescribeRepositoryCreationTemplatesRequest {
    prefixes?: string[];
    nextToken?: string;
    maxResults?: number;
}
export declare const DescribeRepositoryCreationTemplatesRequest: S.Schema<DescribeRepositoryCreationTemplatesRequest>;
export type RepositoryCreationTemplateList = RepositoryCreationTemplate[];
export declare const RepositoryCreationTemplateList: any;
export interface DescribeRepositoryCreationTemplatesResponse {
    registryId?: string;
    repositoryCreationTemplates?: RepositoryCreationTemplate[];
    nextToken?: string;
}
export declare const DescribeRepositoryCreationTemplatesResponse: S.Schema<DescribeRepositoryCreationTemplatesResponse>;
export type AccountSettingName = string;
export interface GetAccountSettingRequest {
    name: string;
}
export declare const GetAccountSettingRequest: S.Schema<GetAccountSettingRequest>;
export interface GetAccountSettingResponse {
    name?: string;
    value?: string;
}
export declare const GetAccountSettingResponse: S.Schema<GetAccountSettingResponse>;
export type GetAuthorizationTokenRegistryIdList = string[];
export declare const GetAuthorizationTokenRegistryIdList: any;
export interface GetAuthorizationTokenRequest {
    registryIds?: string[];
}
export declare const GetAuthorizationTokenRequest: S.Schema<GetAuthorizationTokenRequest>;
export type Base64 = string;
export type ExpirationTimestamp = Date;
export type ProxyEndpoint = string;
export interface AuthorizationData {
    authorizationToken?: string | redacted.Redacted<string>;
    expiresAt?: Date;
    proxyEndpoint?: string;
}
export declare const AuthorizationData: S.Schema<AuthorizationData>;
export type AuthorizationDataList = AuthorizationData[];
export declare const AuthorizationDataList: any;
export interface GetAuthorizationTokenResponse {
    authorizationData?: AuthorizationData[];
}
export declare const GetAuthorizationTokenResponse: S.Schema<GetAuthorizationTokenResponse>;
export interface GetDownloadUrlForLayerRequest {
    registryId?: string;
    repositoryName: string;
    layerDigest: string;
}
export declare const GetDownloadUrlForLayerRequest: S.Schema<GetDownloadUrlForLayerRequest>;
export interface GetDownloadUrlForLayerResponse {
    downloadUrl?: string;
    layerDigest?: string;
}
export declare const GetDownloadUrlForLayerResponse: S.Schema<GetDownloadUrlForLayerResponse>;
export interface GetLifecyclePolicyRequest {
    registryId?: string;
    repositoryName: string;
}
export declare const GetLifecyclePolicyRequest: S.Schema<GetLifecyclePolicyRequest>;
export interface GetLifecyclePolicyResponse {
    registryId?: string;
    repositoryName?: string;
    lifecyclePolicyText?: string;
    lastEvaluatedAt?: Date;
}
export declare const GetLifecyclePolicyResponse: S.Schema<GetLifecyclePolicyResponse>;
export type LifecyclePreviewMaxResults = number;
export interface LifecyclePolicyPreviewFilter {
    tagStatus?: TagStatus;
}
export declare const LifecyclePolicyPreviewFilter: S.Schema<LifecyclePolicyPreviewFilter>;
export interface GetLifecyclePolicyPreviewRequest {
    registryId?: string;
    repositoryName: string;
    imageIds?: ImageIdentifier[];
    nextToken?: string;
    maxResults?: number;
    filter?: LifecyclePolicyPreviewFilter;
}
export declare const GetLifecyclePolicyPreviewRequest: S.Schema<GetLifecyclePolicyPreviewRequest>;
export type LifecyclePolicyPreviewStatus = "IN_PROGRESS" | "COMPLETE" | "EXPIRED" | "FAILED" | (string & {});
export declare const LifecyclePolicyPreviewStatus: any;
export type ImageActionType = "EXPIRE" | "TRANSITION" | (string & {});
export declare const ImageActionType: any;
export type LifecyclePolicyTargetStorageClass = "ARCHIVE" | (string & {});
export declare const LifecyclePolicyTargetStorageClass: any;
export interface LifecyclePolicyRuleAction {
    type?: ImageActionType;
    targetStorageClass?: LifecyclePolicyTargetStorageClass;
}
export declare const LifecyclePolicyRuleAction: S.Schema<LifecyclePolicyRuleAction>;
export type LifecyclePolicyRulePriority = number;
export type LifecyclePolicyStorageClass = "ARCHIVE" | "STANDARD" | (string & {});
export declare const LifecyclePolicyStorageClass: any;
export interface LifecyclePolicyPreviewResult {
    imageTags?: string[];
    imageDigest?: string;
    imagePushedAt?: Date;
    action?: LifecyclePolicyRuleAction;
    appliedRulePriority?: number;
    storageClass?: LifecyclePolicyStorageClass;
}
export declare const LifecyclePolicyPreviewResult: S.Schema<LifecyclePolicyPreviewResult>;
export type LifecyclePolicyPreviewResultList = LifecyclePolicyPreviewResult[];
export declare const LifecyclePolicyPreviewResultList: any;
export type ImageCount = number;
export interface TransitioningImageTotalCount {
    targetStorageClass?: LifecyclePolicyTargetStorageClass;
    imageTotalCount?: number;
}
export declare const TransitioningImageTotalCount: S.Schema<TransitioningImageTotalCount>;
export type TransitioningImageTotalCounts = TransitioningImageTotalCount[];
export declare const TransitioningImageTotalCounts: any;
export interface LifecyclePolicyPreviewSummary {
    expiringImageTotalCount?: number;
    transitioningImageTotalCounts?: TransitioningImageTotalCount[];
}
export declare const LifecyclePolicyPreviewSummary: S.Schema<LifecyclePolicyPreviewSummary>;
export interface GetLifecyclePolicyPreviewResponse {
    registryId?: string;
    repositoryName?: string;
    lifecyclePolicyText?: string;
    status?: LifecyclePolicyPreviewStatus;
    nextToken?: string;
    previewResults?: LifecyclePolicyPreviewResult[];
    summary?: LifecyclePolicyPreviewSummary;
}
export declare const GetLifecyclePolicyPreviewResponse: S.Schema<GetLifecyclePolicyPreviewResponse>;
export interface GetRegistryPolicyRequest {
}
export declare const GetRegistryPolicyRequest: S.Schema<GetRegistryPolicyRequest>;
export interface GetRegistryPolicyResponse {
    registryId?: string;
    policyText?: string;
}
export declare const GetRegistryPolicyResponse: S.Schema<GetRegistryPolicyResponse>;
export interface GetRegistryScanningConfigurationRequest {
}
export declare const GetRegistryScanningConfigurationRequest: S.Schema<GetRegistryScanningConfigurationRequest>;
export type ScanType = "BASIC" | "ENHANCED" | (string & {});
export declare const ScanType: any;
export interface RegistryScanningRule {
    scanFrequency: ScanFrequency;
    repositoryFilters: ScanningRepositoryFilter[];
}
export declare const RegistryScanningRule: S.Schema<RegistryScanningRule>;
export type RegistryScanningRuleList = RegistryScanningRule[];
export declare const RegistryScanningRuleList: any;
export interface RegistryScanningConfiguration {
    scanType?: ScanType;
    rules?: RegistryScanningRule[];
}
export declare const RegistryScanningConfiguration: S.Schema<RegistryScanningConfiguration>;
export interface GetRegistryScanningConfigurationResponse {
    registryId?: string;
    scanningConfiguration?: RegistryScanningConfiguration;
}
export declare const GetRegistryScanningConfigurationResponse: S.Schema<GetRegistryScanningConfigurationResponse>;
export interface GetRepositoryPolicyRequest {
    registryId?: string;
    repositoryName: string;
}
export declare const GetRepositoryPolicyRequest: S.Schema<GetRepositoryPolicyRequest>;
export interface GetRepositoryPolicyResponse {
    registryId?: string;
    repositoryName?: string;
    policyText?: string;
}
export declare const GetRepositoryPolicyResponse: S.Schema<GetRepositoryPolicyResponse>;
export interface GetSigningConfigurationRequest {
}
export declare const GetSigningConfigurationRequest: S.Schema<GetSigningConfigurationRequest>;
export interface GetSigningConfigurationResponse {
    registryId?: string;
    signingConfiguration?: SigningConfiguration;
}
export declare const GetSigningConfigurationResponse: S.Schema<GetSigningConfigurationResponse>;
export interface InitiateLayerUploadRequest {
    registryId?: string;
    repositoryName: string;
}
export declare const InitiateLayerUploadRequest: S.Schema<InitiateLayerUploadRequest>;
export type PartSize = number;
export interface InitiateLayerUploadResponse {
    uploadId?: string;
    partSize?: number;
}
export declare const InitiateLayerUploadResponse: S.Schema<InitiateLayerUploadResponse>;
export interface SubjectIdentifier {
    imageDigest: string;
}
export declare const SubjectIdentifier: S.Schema<SubjectIdentifier>;
export type ArtifactType = string;
export type ArtifactTypeList = string[];
export declare const ArtifactTypeList: any;
export type ArtifactStatusFilter = "ACTIVE" | "ARCHIVED" | "ACTIVATING" | "ANY" | (string & {});
export declare const ArtifactStatusFilter: any;
export interface ListImageReferrersFilter {
    artifactTypes?: string[];
    artifactStatus?: ArtifactStatusFilter;
}
export declare const ListImageReferrersFilter: S.Schema<ListImageReferrersFilter>;
export type FiftyMaxResults = number;
export interface ListImageReferrersRequest {
    registryId?: string;
    repositoryName: string;
    subjectId: SubjectIdentifier;
    filter?: ListImageReferrersFilter;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListImageReferrersRequest: S.Schema<ListImageReferrersRequest>;
export type Annotations = {
    [key: string]: string | undefined;
};
export declare const Annotations: any;
export type ArtifactStatus = "ACTIVE" | "ARCHIVED" | "ACTIVATING" | (string & {});
export declare const ArtifactStatus: any;
export interface ImageReferrer {
    digest: string;
    mediaType: string;
    artifactType?: string;
    size: number;
    annotations?: {
        [key: string]: string | undefined;
    };
    artifactStatus?: ArtifactStatus;
}
export declare const ImageReferrer: S.Schema<ImageReferrer>;
export type ImageReferrerList = ImageReferrer[];
export declare const ImageReferrerList: any;
export interface ListImageReferrersResponse {
    referrers?: ImageReferrer[];
    nextToken?: string;
}
export declare const ListImageReferrersResponse: S.Schema<ListImageReferrersResponse>;
export interface ListImagesFilter {
    tagStatus?: TagStatus;
    imageStatus?: ImageStatusFilter;
}
export declare const ListImagesFilter: S.Schema<ListImagesFilter>;
export interface ListImagesRequest {
    registryId?: string;
    repositoryName: string;
    nextToken?: string;
    maxResults?: number;
    filter?: ListImagesFilter;
}
export declare const ListImagesRequest: S.Schema<ListImagesRequest>;
export interface ListImagesResponse {
    imageIds?: ImageIdentifier[];
    nextToken?: string;
}
export declare const ListImagesResponse: S.Schema<ListImagesResponse>;
export interface ListPullTimeUpdateExclusionsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListPullTimeUpdateExclusionsRequest: S.Schema<ListPullTimeUpdateExclusionsRequest>;
export type PullTimeUpdateExclusionList = string[];
export declare const PullTimeUpdateExclusionList: any;
export interface ListPullTimeUpdateExclusionsResponse {
    pullTimeUpdateExclusions?: string[];
    nextToken?: string;
}
export declare const ListPullTimeUpdateExclusionsResponse: S.Schema<ListPullTimeUpdateExclusionsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type AccountSettingValue = string;
export interface PutAccountSettingRequest {
    name: string;
    value: string;
}
export declare const PutAccountSettingRequest: S.Schema<PutAccountSettingRequest>;
export interface PutAccountSettingResponse {
    name?: string;
    value?: string;
}
export declare const PutAccountSettingResponse: S.Schema<PutAccountSettingResponse>;
export interface PutImageRequest {
    registryId?: string;
    repositoryName: string;
    imageManifest: string;
    imageManifestMediaType?: string;
    imageTag?: string;
    imageDigest?: string;
}
export declare const PutImageRequest: S.Schema<PutImageRequest>;
export interface PutImageResponse {
    image?: Image;
}
export declare const PutImageResponse: S.Schema<PutImageResponse>;
export interface PutImageScanningConfigurationRequest {
    registryId?: string;
    repositoryName: string;
    imageScanningConfiguration: ImageScanningConfiguration;
}
export declare const PutImageScanningConfigurationRequest: S.Schema<PutImageScanningConfigurationRequest>;
export interface PutImageScanningConfigurationResponse {
    registryId?: string;
    repositoryName?: string;
    imageScanningConfiguration?: ImageScanningConfiguration;
}
export declare const PutImageScanningConfigurationResponse: S.Schema<PutImageScanningConfigurationResponse>;
export interface PutImageTagMutabilityRequest {
    registryId?: string;
    repositoryName: string;
    imageTagMutability: ImageTagMutability;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[];
}
export declare const PutImageTagMutabilityRequest: S.Schema<PutImageTagMutabilityRequest>;
export interface PutImageTagMutabilityResponse {
    registryId?: string;
    repositoryName?: string;
    imageTagMutability?: ImageTagMutability;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[];
}
export declare const PutImageTagMutabilityResponse: S.Schema<PutImageTagMutabilityResponse>;
export interface PutLifecyclePolicyRequest {
    registryId?: string;
    repositoryName: string;
    lifecyclePolicyText: string;
}
export declare const PutLifecyclePolicyRequest: S.Schema<PutLifecyclePolicyRequest>;
export interface PutLifecyclePolicyResponse {
    registryId?: string;
    repositoryName?: string;
    lifecyclePolicyText?: string;
}
export declare const PutLifecyclePolicyResponse: S.Schema<PutLifecyclePolicyResponse>;
export interface PutRegistryPolicyRequest {
    policyText: string;
}
export declare const PutRegistryPolicyRequest: S.Schema<PutRegistryPolicyRequest>;
export interface PutRegistryPolicyResponse {
    registryId?: string;
    policyText?: string;
}
export declare const PutRegistryPolicyResponse: S.Schema<PutRegistryPolicyResponse>;
export interface PutRegistryScanningConfigurationRequest {
    scanType?: ScanType;
    rules?: RegistryScanningRule[];
}
export declare const PutRegistryScanningConfigurationRequest: S.Schema<PutRegistryScanningConfigurationRequest>;
export interface PutRegistryScanningConfigurationResponse {
    registryScanningConfiguration?: RegistryScanningConfiguration;
}
export declare const PutRegistryScanningConfigurationResponse: S.Schema<PutRegistryScanningConfigurationResponse>;
export interface PutReplicationConfigurationRequest {
    replicationConfiguration: ReplicationConfiguration;
}
export declare const PutReplicationConfigurationRequest: S.Schema<PutReplicationConfigurationRequest>;
export interface PutReplicationConfigurationResponse {
    replicationConfiguration?: ReplicationConfiguration;
}
export declare const PutReplicationConfigurationResponse: S.Schema<PutReplicationConfigurationResponse>;
export interface PutSigningConfigurationRequest {
    signingConfiguration: SigningConfiguration;
}
export declare const PutSigningConfigurationRequest: S.Schema<PutSigningConfigurationRequest>;
export interface PutSigningConfigurationResponse {
    signingConfiguration?: SigningConfiguration;
}
export declare const PutSigningConfigurationResponse: S.Schema<PutSigningConfigurationResponse>;
export interface RegisterPullTimeUpdateExclusionRequest {
    principalArn: string;
}
export declare const RegisterPullTimeUpdateExclusionRequest: S.Schema<RegisterPullTimeUpdateExclusionRequest>;
export interface RegisterPullTimeUpdateExclusionResponse {
    principalArn?: string;
    createdAt?: Date;
}
export declare const RegisterPullTimeUpdateExclusionResponse: S.Schema<RegisterPullTimeUpdateExclusionResponse>;
export interface SetRepositoryPolicyRequest {
    registryId?: string;
    repositoryName: string;
    policyText: string;
    force?: boolean;
}
export declare const SetRepositoryPolicyRequest: S.Schema<SetRepositoryPolicyRequest>;
export interface SetRepositoryPolicyResponse {
    registryId?: string;
    repositoryName?: string;
    policyText?: string;
}
export declare const SetRepositoryPolicyResponse: S.Schema<SetRepositoryPolicyResponse>;
export interface StartImageScanRequest {
    registryId?: string;
    repositoryName: string;
    imageId: ImageIdentifier;
}
export declare const StartImageScanRequest: S.Schema<StartImageScanRequest>;
export interface StartImageScanResponse {
    registryId?: string;
    repositoryName?: string;
    imageId?: ImageIdentifier;
    imageScanStatus?: ImageScanStatus;
}
export declare const StartImageScanResponse: S.Schema<StartImageScanResponse>;
export interface StartLifecyclePolicyPreviewRequest {
    registryId?: string;
    repositoryName: string;
    lifecyclePolicyText?: string;
}
export declare const StartLifecyclePolicyPreviewRequest: S.Schema<StartLifecyclePolicyPreviewRequest>;
export interface StartLifecyclePolicyPreviewResponse {
    registryId?: string;
    repositoryName?: string;
    lifecyclePolicyText?: string;
    status?: LifecyclePolicyPreviewStatus;
}
export declare const StartLifecyclePolicyPreviewResponse: S.Schema<StartLifecyclePolicyPreviewResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type TargetStorageClass = "STANDARD" | "ARCHIVE" | (string & {});
export declare const TargetStorageClass: any;
export interface UpdateImageStorageClassRequest {
    registryId?: string;
    repositoryName: string;
    imageId: ImageIdentifier;
    targetStorageClass: TargetStorageClass;
}
export declare const UpdateImageStorageClassRequest: S.Schema<UpdateImageStorageClassRequest>;
export interface UpdateImageStorageClassResponse {
    registryId?: string;
    repositoryName?: string;
    imageId?: ImageIdentifier;
    imageStatus?: ImageStatus;
}
export declare const UpdateImageStorageClassResponse: S.Schema<UpdateImageStorageClassResponse>;
export interface UpdatePullThroughCacheRuleRequest {
    registryId?: string;
    ecrRepositoryPrefix: string;
    credentialArn?: string;
    customRoleArn?: string;
}
export declare const UpdatePullThroughCacheRuleRequest: S.Schema<UpdatePullThroughCacheRuleRequest>;
export interface UpdatePullThroughCacheRuleResponse {
    ecrRepositoryPrefix?: string;
    registryId?: string;
    updatedAt?: Date;
    credentialArn?: string;
    customRoleArn?: string;
    upstreamRepositoryPrefix?: string;
}
export declare const UpdatePullThroughCacheRuleResponse: S.Schema<UpdatePullThroughCacheRuleResponse>;
export interface UpdateRepositoryCreationTemplateRequest {
    prefix: string;
    description?: string;
    encryptionConfiguration?: EncryptionConfigurationForRepositoryCreationTemplate;
    resourceTags?: Tag[];
    imageTagMutability?: ImageTagMutability;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[];
    repositoryPolicy?: string;
    lifecyclePolicy?: string;
    appliedFor?: RCTAppliedFor[];
    customRoleArn?: string;
}
export declare const UpdateRepositoryCreationTemplateRequest: S.Schema<UpdateRepositoryCreationTemplateRequest>;
export interface UpdateRepositoryCreationTemplateResponse {
    registryId?: string;
    repositoryCreationTemplate?: RepositoryCreationTemplate;
}
export declare const UpdateRepositoryCreationTemplateResponse: S.Schema<UpdateRepositoryCreationTemplateResponse>;
export type LayerPartBlob = Uint8Array;
export interface UploadLayerPartRequest {
    registryId?: string;
    repositoryName: string;
    uploadId: string;
    partFirstByte: number;
    partLastByte: number;
    layerPartBlob: Uint8Array;
}
export declare const UploadLayerPartRequest: S.Schema<UploadLayerPartRequest>;
export interface UploadLayerPartResponse {
    registryId?: string;
    repositoryName?: string;
    uploadId?: string;
    lastByteReceived?: number;
}
export declare const UploadLayerPartResponse: S.Schema<UploadLayerPartResponse>;
export interface ValidatePullThroughCacheRuleRequest {
    ecrRepositoryPrefix: string;
    registryId?: string;
}
export declare const ValidatePullThroughCacheRuleRequest: S.Schema<ValidatePullThroughCacheRuleRequest>;
export type IsPTCRuleValid = boolean;
export type PTCValidateFailure = string;
export interface ValidatePullThroughCacheRuleResponse {
    ecrRepositoryPrefix?: string;
    registryId?: string;
    upstreamRegistryUrl?: string;
    credentialArn?: string;
    customRoleArn?: string;
    upstreamRepositoryPrefix?: string;
    isValid?: boolean;
    failure?: string;
}
export declare const ValidatePullThroughCacheRuleResponse: S.Schema<ValidatePullThroughCacheRuleResponse>;
export type ExceptionMessage = string;
export type KmsError = string;
export type BatchCheckLayerAvailabilityError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Checks the availability of one or more image layers in a repository.
 *
 * When an image is pushed to a repository, each image layer is checked to verify if it
 * has been uploaded before. If it has been uploaded, then the image layer is
 * skipped.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by
 * customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const batchCheckLayerAvailability: API.OperationMethod<BatchCheckLayerAvailabilityRequest, BatchCheckLayerAvailabilityResponse, BatchCheckLayerAvailabilityError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteImageError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Deletes a list of specified images within a repository. Images are specified with
 * either an `imageTag` or `imageDigest`.
 *
 * You can remove a tag from an image by specifying the image's tag in your request. When
 * you remove the last tag from an image, the image is deleted from your repository.
 *
 * You can completely delete an image (and all of its tags) by specifying the image's
 * digest in your request.
 */
export declare const batchDeleteImage: API.OperationMethod<BatchDeleteImageRequest, BatchDeleteImageResponse, BatchDeleteImageError, Credentials | HttpClient.HttpClient>;
export type BatchGetImageError = InvalidParameterException | LimitExceededException | RepositoryNotFoundException | ServerException | UnableToGetUpstreamImageException | CommonErrors;
/**
 * Gets detailed information for an image. Images are specified with either an
 * `imageTag` or `imageDigest`.
 *
 * When an image is pulled, the BatchGetImage API is called once to retrieve the image
 * manifest.
 */
export declare const batchGetImage: API.OperationMethod<BatchGetImageRequest, BatchGetImageResponse, BatchGetImageError, Credentials | HttpClient.HttpClient>;
export type BatchGetRepositoryScanningConfigurationError = InvalidParameterException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Gets the scanning configuration for one or more repositories.
 */
export declare const batchGetRepositoryScanningConfiguration: API.OperationMethod<BatchGetRepositoryScanningConfigurationRequest, BatchGetRepositoryScanningConfigurationResponse, BatchGetRepositoryScanningConfigurationError, Credentials | HttpClient.HttpClient>;
export type CompleteLayerUploadError = EmptyUploadException | InvalidLayerException | InvalidParameterException | KmsException | LayerAlreadyExistsException | LayerPartTooSmallException | RepositoryNotFoundException | ServerException | UploadNotFoundException | CommonErrors;
/**
 * Informs Amazon ECR that the image layer upload has completed for a specified registry,
 * repository name, and upload ID. You can optionally provide a `sha256` digest
 * of the image layer for data validation purposes.
 *
 * When an image is pushed, the CompleteLayerUpload API is called once per each new image
 * layer to verify that the upload has completed.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by
 * customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const completeLayerUpload: API.OperationMethod<CompleteLayerUploadRequest, CompleteLayerUploadResponse, CompleteLayerUploadError, Credentials | HttpClient.HttpClient>;
export type CreatePullThroughCacheRuleError = InvalidParameterException | LimitExceededException | PullThroughCacheRuleAlreadyExistsException | SecretNotFoundException | ServerException | UnableToAccessSecretException | UnableToDecryptSecretValueException | UnsupportedUpstreamRegistryException | ValidationException | CommonErrors;
/**
 * Creates a pull through cache rule. A pull through cache rule provides a way to cache
 * images from an upstream registry source in your Amazon ECR private registry. For more
 * information, see Using pull through cache
 * rules in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const createPullThroughCacheRule: API.OperationMethod<CreatePullThroughCacheRuleRequest, CreatePullThroughCacheRuleResponse, CreatePullThroughCacheRuleError, Credentials | HttpClient.HttpClient>;
export type CreateRepositoryError = InvalidParameterException | InvalidTagParameterException | KmsException | LimitExceededException | RepositoryAlreadyExistsException | ServerException | TooManyTagsException | CommonErrors;
/**
 * Creates a repository. For more information, see Amazon ECR repositories in the
 * *Amazon Elastic Container Registry User Guide*.
 */
export declare const createRepository: API.OperationMethod<CreateRepositoryRequest, CreateRepositoryResponse, CreateRepositoryError, Credentials | HttpClient.HttpClient>;
export type CreateRepositoryCreationTemplateError = InvalidParameterException | LimitExceededException | ServerException | TemplateAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates a repository creation template. This template is used to define the settings
 * for repositories created by Amazon ECR on your behalf. For example, repositories created
 * through pull through cache actions. For more information, see Private
 * repository creation templates in the
 * *Amazon Elastic Container Registry User Guide*.
 */
export declare const createRepositoryCreationTemplate: API.OperationMethod<CreateRepositoryCreationTemplateRequest, CreateRepositoryCreationTemplateResponse, CreateRepositoryCreationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteLifecyclePolicyError = InvalidParameterException | LifecyclePolicyNotFoundException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Deletes the lifecycle policy associated with the specified repository.
 */
export declare const deleteLifecyclePolicy: API.OperationMethod<DeleteLifecyclePolicyRequest, DeleteLifecyclePolicyResponse, DeleteLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type DeletePullThroughCacheRuleError = InvalidParameterException | PullThroughCacheRuleNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Deletes a pull through cache rule.
 */
export declare const deletePullThroughCacheRule: API.OperationMethod<DeletePullThroughCacheRuleRequest, DeletePullThroughCacheRuleResponse, DeletePullThroughCacheRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteRegistryPolicyError = InvalidParameterException | RegistryPolicyNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Deletes the registry permissions policy.
 */
export declare const deleteRegistryPolicy: API.OperationMethod<DeleteRegistryPolicyRequest, DeleteRegistryPolicyResponse, DeleteRegistryPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryError = InvalidParameterException | KmsException | RepositoryNotEmptyException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Deletes a repository. If the repository isn't empty, you must either delete the
 * contents of the repository or use the `force` option to delete the repository
 * and have Amazon ECR delete all of its contents on your behalf.
 */
export declare const deleteRepository: API.OperationMethod<DeleteRepositoryRequest, DeleteRepositoryResponse, DeleteRepositoryError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryCreationTemplateError = InvalidParameterException | ServerException | TemplateNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a repository creation template.
 */
export declare const deleteRepositoryCreationTemplate: API.OperationMethod<DeleteRepositoryCreationTemplateRequest, DeleteRepositoryCreationTemplateResponse, DeleteRepositoryCreationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryPolicyError = InvalidParameterException | RepositoryNotFoundException | RepositoryPolicyNotFoundException | ServerException | CommonErrors;
/**
 * Deletes the repository policy associated with the specified repository.
 */
export declare const deleteRepositoryPolicy: API.OperationMethod<DeleteRepositoryPolicyRequest, DeleteRepositoryPolicyResponse, DeleteRepositoryPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSigningConfigurationError = ServerException | SigningConfigurationNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the registry's signing configuration. Images pushed after deletion of the signing
 * configuration will no longer be automatically signed.
 *
 * For more information, see Managed signing in the
 * *Amazon Elastic Container Registry User Guide*.
 *
 * Deleting the signing configuration does not affect existing image signatures.
 */
export declare const deleteSigningConfiguration: API.OperationMethod<DeleteSigningConfigurationRequest, DeleteSigningConfigurationResponse, DeleteSigningConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeregisterPullTimeUpdateExclusionError = ExclusionNotFoundException | InvalidParameterException | LimitExceededException | ServerException | ValidationException | CommonErrors;
/**
 * Removes a principal from the pull time update exclusion list for a registry. Once removed, Amazon ECR will resume updating the pull time if the specified principal pulls an image.
 */
export declare const deregisterPullTimeUpdateExclusion: API.OperationMethod<DeregisterPullTimeUpdateExclusionRequest, DeregisterPullTimeUpdateExclusionResponse, DeregisterPullTimeUpdateExclusionError, Credentials | HttpClient.HttpClient>;
export type DescribeImageReplicationStatusError = ImageNotFoundException | InvalidParameterException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Returns the replication status for a specified image.
 */
export declare const describeImageReplicationStatus: API.OperationMethod<DescribeImageReplicationStatusRequest, DescribeImageReplicationStatusResponse, DescribeImageReplicationStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeImagesError = ImageNotFoundException | InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Returns metadata about the images in a repository.
 *
 * Starting with Docker version 1.9, the Docker client compresses image layers before
 * pushing them to a V2 Docker registry. The output of the `docker images`
 * command shows the uncompressed image size. Therefore, Docker might return a larger
 * image than the image shown in the Amazon Web Services Management Console.
 *
 * The new version of Amazon ECR
 * *Basic Scanning* doesn't use the ImageDetail$imageScanFindingsSummary and ImageDetail$imageScanStatus attributes from the API response to
 * return scan results. Use the DescribeImageScanFindings API
 * instead. For more information about Amazon Web Services native basic scanning, see Scan
 * images for software vulnerabilities in Amazon ECR.
 */
export declare const describeImages: API.PaginatedOperationMethod<DescribeImagesRequest, DescribeImagesResponse, DescribeImagesError, Credentials | HttpClient.HttpClient, ImageDetail>;
export type DescribeImageScanFindingsError = ImageNotFoundException | InvalidParameterException | RepositoryNotFoundException | ScanNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Returns the scan findings for the specified image.
 */
export declare const describeImageScanFindings: API.PaginatedOperationMethod<DescribeImageScanFindingsRequest, DescribeImageScanFindingsResponse, DescribeImageScanFindingsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeImageSigningStatusError = ImageNotFoundException | InvalidParameterException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Returns the signing status for a specified image. If the image matched
 * signing rules that reference different signing profiles, a status is returned
 * for each profile.
 *
 * For more information, see Managed signing in the
 * *Amazon Elastic Container Registry User Guide*.
 */
export declare const describeImageSigningStatus: API.OperationMethod<DescribeImageSigningStatusRequest, DescribeImageSigningStatusResponse, DescribeImageSigningStatusError, Credentials | HttpClient.HttpClient>;
export type DescribePullThroughCacheRulesError = InvalidParameterException | PullThroughCacheRuleNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Returns the pull through cache rules for a registry.
 */
export declare const describePullThroughCacheRules: API.PaginatedOperationMethod<DescribePullThroughCacheRulesRequest, DescribePullThroughCacheRulesResponse, DescribePullThroughCacheRulesError, Credentials | HttpClient.HttpClient, PullThroughCacheRule>;
export type DescribeRegistryError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Describes the settings for a registry. The replication configuration for a repository
 * can be created or updated with the PutReplicationConfiguration API
 * action.
 */
export declare const describeRegistry: API.OperationMethod<DescribeRegistryRequest, DescribeRegistryResponse, DescribeRegistryError, Credentials | HttpClient.HttpClient>;
export type DescribeRepositoriesError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Describes image repositories in a registry.
 */
export declare const describeRepositories: API.PaginatedOperationMethod<DescribeRepositoriesRequest, DescribeRepositoriesResponse, DescribeRepositoriesError, Credentials | HttpClient.HttpClient, Repository>;
export type DescribeRepositoryCreationTemplatesError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Returns details about the repository creation templates in a registry. The
 * `prefixes` request parameter can be used to return the details for a
 * specific repository creation template.
 */
export declare const describeRepositoryCreationTemplates: API.PaginatedOperationMethod<DescribeRepositoryCreationTemplatesRequest, DescribeRepositoryCreationTemplatesResponse, DescribeRepositoryCreationTemplatesError, Credentials | HttpClient.HttpClient, RepositoryCreationTemplate>;
export type GetAccountSettingError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Retrieves the account setting value for the specified setting name.
 */
export declare const getAccountSetting: API.OperationMethod<GetAccountSettingRequest, GetAccountSettingResponse, GetAccountSettingError, Credentials | HttpClient.HttpClient>;
export type GetAuthorizationTokenError = InvalidParameterException | ServerException | CommonErrors;
/**
 * Retrieves an authorization token. An authorization token represents your IAM
 * authentication credentials and can be used to access any Amazon ECR registry that your IAM
 * principal has access to. The authorization token is valid for 12 hours.
 *
 * The `authorizationToken` returned is a base64 encoded string that can be
 * decoded and used in a `docker login` command to authenticate to a registry.
 * The CLI offers an `get-login-password` command that simplifies the login
 * process. For more information, see Registry
 * authentication in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const getAuthorizationToken: API.OperationMethod<GetAuthorizationTokenRequest, GetAuthorizationTokenResponse, GetAuthorizationTokenError, Credentials | HttpClient.HttpClient>;
export type GetDownloadUrlForLayerError = InvalidParameterException | LayerInaccessibleException | LayersNotFoundException | RepositoryNotFoundException | ServerException | UnableToGetUpstreamLayerException | CommonErrors;
/**
 * Retrieves the pre-signed Amazon S3 download URL corresponding to an image layer. You can
 * only get URLs for image layers that are referenced in an image.
 *
 * When an image is pulled, the GetDownloadUrlForLayer API is called once per image layer
 * that is not already cached.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by
 * customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const getDownloadUrlForLayer: API.OperationMethod<GetDownloadUrlForLayerRequest, GetDownloadUrlForLayerResponse, GetDownloadUrlForLayerError, Credentials | HttpClient.HttpClient>;
export type GetLifecyclePolicyError = InvalidParameterException | LifecyclePolicyNotFoundException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Retrieves the lifecycle policy for the specified repository.
 */
export declare const getLifecyclePolicy: API.OperationMethod<GetLifecyclePolicyRequest, GetLifecyclePolicyResponse, GetLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type GetLifecyclePolicyPreviewError = InvalidParameterException | LifecyclePolicyPreviewNotFoundException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Retrieves the results of the lifecycle policy preview request for the specified
 * repository.
 */
export declare const getLifecyclePolicyPreview: API.PaginatedOperationMethod<GetLifecyclePolicyPreviewRequest, GetLifecyclePolicyPreviewResponse, GetLifecyclePolicyPreviewError, Credentials | HttpClient.HttpClient, LifecyclePolicyPreviewResult>;
export type GetRegistryPolicyError = InvalidParameterException | RegistryPolicyNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Retrieves the permissions policy for a registry.
 */
export declare const getRegistryPolicy: API.OperationMethod<GetRegistryPolicyRequest, GetRegistryPolicyResponse, GetRegistryPolicyError, Credentials | HttpClient.HttpClient>;
export type GetRegistryScanningConfigurationError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Retrieves the scanning configuration for a registry.
 */
export declare const getRegistryScanningConfiguration: API.OperationMethod<GetRegistryScanningConfigurationRequest, GetRegistryScanningConfigurationResponse, GetRegistryScanningConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetRepositoryPolicyError = InvalidParameterException | RepositoryNotFoundException | RepositoryPolicyNotFoundException | ServerException | CommonErrors;
/**
 * Retrieves the repository policy for the specified repository.
 */
export declare const getRepositoryPolicy: API.OperationMethod<GetRepositoryPolicyRequest, GetRepositoryPolicyResponse, GetRepositoryPolicyError, Credentials | HttpClient.HttpClient>;
export type GetSigningConfigurationError = InvalidParameterException | ServerException | SigningConfigurationNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the registry's signing configuration, which defines
 * rules for automatically signing images using Amazon Web Services Signer.
 *
 * For more information, see Managed signing in the
 * *Amazon Elastic Container Registry User Guide*.
 */
export declare const getSigningConfiguration: API.OperationMethod<GetSigningConfigurationRequest, GetSigningConfigurationResponse, GetSigningConfigurationError, Credentials | HttpClient.HttpClient>;
export type InitiateLayerUploadError = InvalidParameterException | KmsException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Notifies Amazon ECR that you intend to upload an image layer.
 *
 * When an image is pushed, the InitiateLayerUpload API is called once per image layer
 * that has not already been uploaded. Whether or not an image layer has been uploaded is
 * determined by the BatchCheckLayerAvailability API action.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by
 * customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const initiateLayerUpload: API.OperationMethod<InitiateLayerUploadRequest, InitiateLayerUploadResponse, InitiateLayerUploadError, Credentials | HttpClient.HttpClient>;
export type ListImageReferrersError = InvalidParameterException | RepositoryNotFoundException | ServerException | UnableToListUpstreamImageReferrersException | ValidationException | CommonErrors;
/**
 * Lists the artifacts associated with a specified subject image.
 *
 * The IAM principal invoking this operation must have the `ecr:BatchGetImage` permission.
 */
export declare const listImageReferrers: API.OperationMethod<ListImageReferrersRequest, ListImageReferrersResponse, ListImageReferrersError, Credentials | HttpClient.HttpClient>;
export type ListImagesError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Lists all the image IDs for the specified repository.
 *
 * You can filter images based on whether or not they are tagged by using the
 * `tagStatus` filter and specifying either `TAGGED`,
 * `UNTAGGED` or `ANY`. For example, you can filter your results
 * to return only `UNTAGGED` images and then pipe that result to a BatchDeleteImage operation to delete them. Or, you can filter your
 * results to return only `TAGGED` images to list all of the tags in your
 * repository.
 */
export declare const listImages: API.PaginatedOperationMethod<ListImagesRequest, ListImagesResponse, ListImagesError, Credentials | HttpClient.HttpClient, ImageIdentifier>;
export type ListPullTimeUpdateExclusionsError = InvalidParameterException | LimitExceededException | ServerException | ValidationException | CommonErrors;
/**
 * Lists the IAM principals that are excluded from having their image pull times recorded.
 */
export declare const listPullTimeUpdateExclusions: API.OperationMethod<ListPullTimeUpdateExclusionsRequest, ListPullTimeUpdateExclusionsResponse, ListPullTimeUpdateExclusionsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * List the tags for an Amazon ECR resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutAccountSettingError = InvalidParameterException | LimitExceededException | ServerException | ValidationException | CommonErrors;
/**
 * Allows you to change the basic scan type version or registry policy scope.
 */
export declare const putAccountSetting: API.OperationMethod<PutAccountSettingRequest, PutAccountSettingResponse, PutAccountSettingError, Credentials | HttpClient.HttpClient>;
export type PutImageError = ImageAlreadyExistsException | ImageDigestDoesNotMatchException | ImageTagAlreadyExistsException | InvalidParameterException | KmsException | LayersNotFoundException | LimitExceededException | ReferencedImagesNotFoundException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Creates or updates the image manifest and tags associated with an image.
 *
 * When an image is pushed and all new image layers have been uploaded, the PutImage API
 * is called once to create or update the image manifest and the tags associated with the
 * image.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by
 * customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const putImage: API.OperationMethod<PutImageRequest, PutImageResponse, PutImageError, Credentials | HttpClient.HttpClient>;
export type PutImageScanningConfigurationError = InvalidParameterException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * The `PutImageScanningConfiguration` API is being deprecated, in favor
 * of specifying the image scanning configuration at the registry level. For more
 * information, see PutRegistryScanningConfiguration.
 *
 * Updates the image scanning configuration for the specified repository.
 */
export declare const putImageScanningConfiguration: API.OperationMethod<PutImageScanningConfigurationRequest, PutImageScanningConfigurationResponse, PutImageScanningConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutImageTagMutabilityError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Updates the image tag mutability settings for the specified repository. For more
 * information, see Image tag
 * mutability in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const putImageTagMutability: API.OperationMethod<PutImageTagMutabilityRequest, PutImageTagMutabilityResponse, PutImageTagMutabilityError, Credentials | HttpClient.HttpClient>;
export type PutLifecyclePolicyError = InvalidParameterException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Creates or updates the lifecycle policy for the specified repository. For more
 * information, see Lifecycle policy
 * template.
 */
export declare const putLifecyclePolicy: API.OperationMethod<PutLifecyclePolicyRequest, PutLifecyclePolicyResponse, PutLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type PutRegistryPolicyError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Creates or updates the permissions policy for your registry.
 *
 * A registry policy is used to specify permissions for another Amazon Web Services account and is used
 * when configuring cross-account replication. For more information, see Registry permissions in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const putRegistryPolicy: API.OperationMethod<PutRegistryPolicyRequest, PutRegistryPolicyResponse, PutRegistryPolicyError, Credentials | HttpClient.HttpClient>;
export type PutRegistryScanningConfigurationError = BlockedByOrganizationPolicyException | InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Creates or updates the scanning configuration for your private registry.
 */
export declare const putRegistryScanningConfiguration: API.OperationMethod<PutRegistryScanningConfigurationRequest, PutRegistryScanningConfigurationResponse, PutRegistryScanningConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutReplicationConfigurationError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Creates or updates the replication configuration for a registry. The existing
 * replication configuration for a repository can be retrieved with the DescribeRegistry API action. The first time the
 * PutReplicationConfiguration API is called, a service-linked IAM role is created in
 * your account for the replication process. For more information, see Using
 * service-linked roles for Amazon ECR in the *Amazon Elastic Container Registry User Guide*.
 * For more information on the custom role for replication, see Creating an IAM role for replication.
 *
 * When configuring cross-account replication, the destination account must grant the
 * source account permission to replicate. This permission is controlled using a
 * registry permissions policy. For more information, see PutRegistryPolicy.
 */
export declare const putReplicationConfiguration: API.OperationMethod<PutReplicationConfigurationRequest, PutReplicationConfigurationResponse, PutReplicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutSigningConfigurationError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Creates or updates the registry's signing configuration, which defines
 * rules for automatically signing images with Amazon Web Services Signer.
 *
 * For more information, see Managed signing in the
 * *Amazon Elastic Container Registry User Guide*.
 *
 * To successfully generate a signature, the IAM principal pushing images must have
 * permission to sign payloads with the Amazon Web Services Signer signing profile referenced in the signing
 * configuration.
 */
export declare const putSigningConfiguration: API.OperationMethod<PutSigningConfigurationRequest, PutSigningConfigurationResponse, PutSigningConfigurationError, Credentials | HttpClient.HttpClient>;
export type RegisterPullTimeUpdateExclusionError = ExclusionAlreadyExistsException | InvalidParameterException | LimitExceededException | ServerException | ValidationException | CommonErrors;
/**
 * Adds an IAM principal to the pull time update exclusion list for a registry. Amazon ECR will not record the pull time if an excluded principal pulls an image.
 */
export declare const registerPullTimeUpdateExclusion: API.OperationMethod<RegisterPullTimeUpdateExclusionRequest, RegisterPullTimeUpdateExclusionResponse, RegisterPullTimeUpdateExclusionError, Credentials | HttpClient.HttpClient>;
export type SetRepositoryPolicyError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Applies a repository policy to the specified repository to control access permissions.
 * For more information, see Amazon ECR Repository
 * policies in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const setRepositoryPolicy: API.OperationMethod<SetRepositoryPolicyRequest, SetRepositoryPolicyResponse, SetRepositoryPolicyError, Credentials | HttpClient.HttpClient>;
export type StartImageScanError = ImageArchivedException | ImageNotFoundException | InvalidParameterException | LimitExceededException | RepositoryNotFoundException | ServerException | UnsupportedImageTypeException | ValidationException | CommonErrors;
/**
 * Starts a basic image vulnerability scan.
 *
 * A basic image scan can only be started once per 24 hours on an individual image. This
 * limit includes if an image was scanned on initial push. You can start up to 100,000
 * basic scans per 24 hours. This limit includes both scans on initial push and scans
 * initiated by the StartImageScan API. For more information, see Basic scanning in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const startImageScan: API.OperationMethod<StartImageScanRequest, StartImageScanResponse, StartImageScanError, Credentials | HttpClient.HttpClient>;
export type StartLifecyclePolicyPreviewError = InvalidParameterException | LifecyclePolicyNotFoundException | LifecyclePolicyPreviewInProgressException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Starts a preview of a lifecycle policy for the specified repository. This allows you
 * to see the results before associating the lifecycle policy with the repository.
 */
export declare const startLifecyclePolicyPreview: API.OperationMethod<StartLifecyclePolicyPreviewRequest, StartLifecyclePolicyPreviewResponse, StartLifecyclePolicyPreviewError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidParameterException | InvalidTagParameterException | RepositoryNotFoundException | ServerException | TooManyTagsException | CommonErrors;
/**
 * Adds specified tags to a resource with the specified ARN. Existing tags on a resource
 * are not changed if they are not specified in the request parameters.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidParameterException | InvalidTagParameterException | RepositoryNotFoundException | ServerException | TooManyTagsException | CommonErrors;
/**
 * Deletes specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateImageStorageClassError = ImageNotFoundException | ImageStorageClassUpdateNotSupportedException | InvalidParameterException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Transitions an image between storage classes. You can transition images from Amazon ECR standard storage class to Amazon ECR archival storage class for long-term storage, or restore archived images back to Amazon ECR standard.
 */
export declare const updateImageStorageClass: API.OperationMethod<UpdateImageStorageClassRequest, UpdateImageStorageClassResponse, UpdateImageStorageClassError, Credentials | HttpClient.HttpClient>;
export type UpdatePullThroughCacheRuleError = InvalidParameterException | PullThroughCacheRuleNotFoundException | SecretNotFoundException | ServerException | UnableToAccessSecretException | UnableToDecryptSecretValueException | ValidationException | CommonErrors;
/**
 * Updates an existing pull through cache rule.
 */
export declare const updatePullThroughCacheRule: API.OperationMethod<UpdatePullThroughCacheRuleRequest, UpdatePullThroughCacheRuleResponse, UpdatePullThroughCacheRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateRepositoryCreationTemplateError = InvalidParameterException | ServerException | TemplateNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing repository creation template.
 */
export declare const updateRepositoryCreationTemplate: API.OperationMethod<UpdateRepositoryCreationTemplateRequest, UpdateRepositoryCreationTemplateResponse, UpdateRepositoryCreationTemplateError, Credentials | HttpClient.HttpClient>;
export type UploadLayerPartError = InvalidLayerPartException | InvalidParameterException | KmsException | LimitExceededException | RepositoryNotFoundException | ServerException | UploadNotFoundException | CommonErrors;
/**
 * Uploads an image layer part to Amazon ECR.
 *
 * When an image is pushed, each new image layer is uploaded in parts. The maximum size
 * of each image layer part can be 20971520 bytes (or about 20MB). The UploadLayerPart API
 * is called once per each new image layer part.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by
 * customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const uploadLayerPart: API.OperationMethod<UploadLayerPartRequest, UploadLayerPartResponse, UploadLayerPartError, Credentials | HttpClient.HttpClient>;
export type ValidatePullThroughCacheRuleError = InvalidParameterException | PullThroughCacheRuleNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Validates an existing pull through cache rule for an upstream registry that requires
 * authentication. This will retrieve the contents of the Amazon Web Services Secrets Manager secret, verify the
 * syntax, and then validate that authentication to the upstream registry is
 * successful.
 */
export declare const validatePullThroughCacheRule: API.OperationMethod<ValidatePullThroughCacheRuleRequest, ValidatePullThroughCacheRuleResponse, ValidatePullThroughCacheRuleError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ecr.d.ts.map