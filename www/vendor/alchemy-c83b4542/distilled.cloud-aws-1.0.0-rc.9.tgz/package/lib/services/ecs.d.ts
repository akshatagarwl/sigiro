import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AttributeLimitExceededException_base: S.Class<AttributeLimitExceededException, S.TaggedStruct<"AttributeLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class AttributeLimitExceededException extends /*@__PURE__*/ AttributeLimitExceededException_base {
}
declare const BlockedException_base: S.Class<BlockedException, S.TaggedStruct<"BlockedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BlockedException extends /*@__PURE__*/ BlockedException_base {
}
declare const ClientException_base: S.Class<ClientException, S.TaggedStruct<"ClientException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClientException extends /*@__PURE__*/ ClientException_base {
}
declare const ClusterContainsCapacityProviderException_base: S.Class<ClusterContainsCapacityProviderException, S.TaggedStruct<"ClusterContainsCapacityProviderException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ClusterContainsCapacityProviderException extends /*@__PURE__*/ ClusterContainsCapacityProviderException_base {
}
declare const ClusterContainsContainerInstancesException_base: S.Class<ClusterContainsContainerInstancesException, S.TaggedStruct<"ClusterContainsContainerInstancesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ClusterContainsContainerInstancesException extends /*@__PURE__*/ ClusterContainsContainerInstancesException_base {
}
declare const ClusterContainsServicesException_base: S.Class<ClusterContainsServicesException, S.TaggedStruct<"ClusterContainsServicesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ClusterContainsServicesException extends /*@__PURE__*/ ClusterContainsServicesException_base {
}
declare const ClusterContainsTasksException_base: S.Class<ClusterContainsTasksException, S.TaggedStruct<"ClusterContainsTasksException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ClusterContainsTasksException extends /*@__PURE__*/ ClusterContainsTasksException_base {
}
declare const ClusterNotFoundException_base: S.Class<ClusterNotFoundException, S.TaggedStruct<"ClusterNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ClusterNotFoundException extends /*@__PURE__*/ ClusterNotFoundException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly resourceIds: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DaemonNotActiveException_base: S.Class<DaemonNotActiveException, S.TaggedStruct<"DaemonNotActiveException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DaemonNotActiveException extends /*@__PURE__*/ DaemonNotActiveException_base {
}
declare const DaemonNotFoundException_base: S.Class<DaemonNotFoundException, S.TaggedStruct<"DaemonNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class DaemonNotFoundException extends /*@__PURE__*/ DaemonNotFoundException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MissingVersionException_base: S.Class<MissingVersionException, S.TaggedStruct<"MissingVersionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MissingVersionException extends /*@__PURE__*/ MissingVersionException_base {
}
declare const NamespaceNotFoundException_base: S.Class<NamespaceNotFoundException, S.TaggedStruct<"NamespaceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class NamespaceNotFoundException extends /*@__PURE__*/ NamespaceNotFoundException_base {
}
declare const NoUpdateAvailableException_base: S.Class<NoUpdateAvailableException, S.TaggedStruct<"NoUpdateAvailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoUpdateAvailableException extends /*@__PURE__*/ NoUpdateAvailableException_base {
}
declare const PlatformTaskDefinitionIncompatibilityException_base: S.Class<PlatformTaskDefinitionIncompatibilityException, S.TaggedStruct<"PlatformTaskDefinitionIncompatibilityException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PlatformTaskDefinitionIncompatibilityException extends /*@__PURE__*/ PlatformTaskDefinitionIncompatibilityException_base {
}
declare const PlatformUnknownException_base: S.Class<PlatformUnknownException, S.TaggedStruct<"PlatformUnknownException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PlatformUnknownException extends /*@__PURE__*/ PlatformUnknownException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServerException_base: S.Class<ServerException, S.TaggedStruct<"ServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServerException extends /*@__PURE__*/ ServerException_base {
}
declare const ServiceDeploymentNotFoundException_base: S.Class<ServiceDeploymentNotFoundException, S.TaggedStruct<"ServiceDeploymentNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ServiceDeploymentNotFoundException extends /*@__PURE__*/ ServiceDeploymentNotFoundException_base {
}
declare const ServiceNotActiveException_base: S.Class<ServiceNotActiveException, S.TaggedStruct<"ServiceNotActiveException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ServiceNotActiveException extends /*@__PURE__*/ ServiceNotActiveException_base {
}
declare const ServiceNotFoundException_base: S.Class<ServiceNotFoundException, S.TaggedStruct<"ServiceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ServiceNotFoundException extends /*@__PURE__*/ ServiceNotFoundException_base {
}
declare const TargetNotConnectedException_base: S.Class<TargetNotConnectedException, S.TaggedStruct<"TargetNotConnectedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class TargetNotConnectedException extends /*@__PURE__*/ TargetNotConnectedException_base {
}
declare const TargetNotFoundException_base: S.Class<TargetNotFoundException, S.TaggedStruct<"TargetNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class TargetNotFoundException extends /*@__PURE__*/ TargetNotFoundException_base {
}
declare const TaskSetNotFoundException_base: S.Class<TaskSetNotFoundException, S.TaggedStruct<"TaskSetNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class TaskSetNotFoundException extends /*@__PURE__*/ TaskSetNotFoundException_base {
}
declare const UnsupportedFeatureException_base: S.Class<UnsupportedFeatureException, S.TaggedStruct<"UnsupportedFeatureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedFeatureException extends /*@__PURE__*/ UnsupportedFeatureException_base {
}
declare const UpdateInProgressException_base: S.Class<UpdateInProgressException, S.TaggedStruct<"UpdateInProgressException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class UpdateInProgressException extends /*@__PURE__*/ UpdateInProgressException_base {
}
export type DeploymentLifecycleHookAction = "ROLLBACK" | "CONTINUE" | (string & {});
export declare const DeploymentLifecycleHookAction: any;
export interface ContinueServiceDeploymentRequest {
    serviceDeploymentArn: string;
    hookId: string;
    action?: DeploymentLifecycleHookAction;
}
export declare const ContinueServiceDeploymentRequest: S.Schema<ContinueServiceDeploymentRequest>;
export interface ContinueServiceDeploymentResponse {
    serviceDeploymentArn?: string;
}
export declare const ContinueServiceDeploymentResponse: S.Schema<ContinueServiceDeploymentResponse>;
export type ManagedScalingStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const ManagedScalingStatus: any;
export type ManagedScalingTargetCapacity = number;
export type ManagedScalingStepSize = number;
export type ManagedScalingInstanceWarmupPeriod = number;
export interface ManagedScaling {
    status?: ManagedScalingStatus;
    targetCapacity?: number;
    minimumScalingStepSize?: number;
    maximumScalingStepSize?: number;
    instanceWarmupPeriod?: number;
}
export declare const ManagedScaling: S.Schema<ManagedScaling>;
export type ManagedTerminationProtection = "ENABLED" | "DISABLED" | (string & {});
export declare const ManagedTerminationProtection: any;
export type ManagedDraining = "ENABLED" | "DISABLED" | (string & {});
export declare const ManagedDraining: any;
export interface AutoScalingGroupProvider {
    autoScalingGroupArn: string;
    managedScaling?: ManagedScaling;
    managedTerminationProtection?: ManagedTerminationProtection;
    managedDraining?: ManagedDraining;
}
export declare const AutoScalingGroupProvider: S.Schema<AutoScalingGroupProvider>;
export type StringList = string[];
export declare const StringList: any;
export interface ManagedInstancesNetworkConfiguration {
    subnets?: string[];
    securityGroups?: string[];
}
export declare const ManagedInstancesNetworkConfiguration: S.Schema<ManagedInstancesNetworkConfiguration>;
export type TaskVolumeStorageGiB = number;
export interface ManagedInstancesStorageConfiguration {
    storageSizeGiB?: number;
}
export declare const ManagedInstancesStorageConfiguration: S.Schema<ManagedInstancesStorageConfiguration>;
export interface ManagedInstancesLocalStorageConfiguration {
    useLocalStorage?: boolean;
}
export declare const ManagedInstancesLocalStorageConfiguration: S.Schema<ManagedInstancesLocalStorageConfiguration>;
export type ManagedInstancesMonitoringOptions = "BASIC" | "DETAILED" | (string & {});
export declare const ManagedInstancesMonitoringOptions: any;
export type CapacityOptionType = "ON_DEMAND" | "SPOT" | "RESERVED" | (string & {});
export declare const CapacityOptionType: any;
export type BoxedBoolean = boolean;
export type BoxedInteger = number;
export interface VCpuCountRangeRequest {
    min: number;
    max?: number;
}
export declare const VCpuCountRangeRequest: S.Schema<VCpuCountRangeRequest>;
export interface MemoryMiBRequest {
    min: number;
    max?: number;
}
export declare const MemoryMiBRequest: S.Schema<MemoryMiBRequest>;
export type CpuManufacturer = "intel" | "amd" | "amazon-web-services" | (string & {});
export declare const CpuManufacturer: any;
export type CpuManufacturerSet = CpuManufacturer[];
export declare const CpuManufacturerSet: any;
export type BoxedDouble = number;
export interface MemoryGiBPerVCpuRequest {
    min?: number;
    max?: number;
}
export declare const MemoryGiBPerVCpuRequest: S.Schema<MemoryGiBPerVCpuRequest>;
export type ExcludedInstanceType = string;
export type ExcludedInstanceTypeSet = string[];
export declare const ExcludedInstanceTypeSet: any;
export type InstanceGeneration = "current" | "previous" | (string & {});
export declare const InstanceGeneration: any;
export type InstanceGenerationSet = InstanceGeneration[];
export declare const InstanceGenerationSet: any;
export type BareMetal = "included" | "required" | "excluded" | (string & {});
export declare const BareMetal: any;
export type BurstablePerformance = "included" | "required" | "excluded" | (string & {});
export declare const BurstablePerformance: any;
export interface NetworkInterfaceCountRequest {
    min?: number;
    max?: number;
}
export declare const NetworkInterfaceCountRequest: S.Schema<NetworkInterfaceCountRequest>;
export type LocalStorage = "included" | "required" | "excluded" | (string & {});
export declare const LocalStorage: any;
export type LocalStorageType = "hdd" | "ssd" | (string & {});
export declare const LocalStorageType: any;
export type LocalStorageTypeSet = LocalStorageType[];
export declare const LocalStorageTypeSet: any;
export interface TotalLocalStorageGBRequest {
    min?: number;
    max?: number;
}
export declare const TotalLocalStorageGBRequest: S.Schema<TotalLocalStorageGBRequest>;
export interface BaselineEbsBandwidthMbpsRequest {
    min?: number;
    max?: number;
}
export declare const BaselineEbsBandwidthMbpsRequest: S.Schema<BaselineEbsBandwidthMbpsRequest>;
export type AcceleratorType = "gpu" | "fpga" | "inference" | (string & {});
export declare const AcceleratorType: any;
export type AcceleratorTypeSet = AcceleratorType[];
export declare const AcceleratorTypeSet: any;
export interface AcceleratorCountRequest {
    min?: number;
    max?: number;
}
export declare const AcceleratorCountRequest: S.Schema<AcceleratorCountRequest>;
export type AcceleratorManufacturer = "amazon-web-services" | "amd" | "nvidia" | "xilinx" | "habana" | (string & {});
export declare const AcceleratorManufacturer: any;
export type AcceleratorManufacturerSet = AcceleratorManufacturer[];
export declare const AcceleratorManufacturerSet: any;
export type AcceleratorName = "a100" | "inferentia" | "k520" | "k80" | "m60" | "radeon-pro-v520" | "t4" | "vu9p" | "v100" | "a10g" | "h100" | "t4g" | (string & {});
export declare const AcceleratorName: any;
export type AcceleratorNameSet = AcceleratorName[];
export declare const AcceleratorNameSet: any;
export interface AcceleratorTotalMemoryMiBRequest {
    min?: number;
    max?: number;
}
export declare const AcceleratorTotalMemoryMiBRequest: S.Schema<AcceleratorTotalMemoryMiBRequest>;
export interface NetworkBandwidthGbpsRequest {
    min?: number;
    max?: number;
}
export declare const NetworkBandwidthGbpsRequest: S.Schema<NetworkBandwidthGbpsRequest>;
export type AllowedInstanceType = string;
export type AllowedInstanceTypeSet = string[];
export declare const AllowedInstanceTypeSet: any;
export interface InstanceRequirementsRequest {
    vCpuCount: VCpuCountRangeRequest;
    memoryMiB: MemoryMiBRequest;
    cpuManufacturers?: CpuManufacturer[];
    memoryGiBPerVCpu?: MemoryGiBPerVCpuRequest;
    excludedInstanceTypes?: string[];
    instanceGenerations?: InstanceGeneration[];
    spotMaxPricePercentageOverLowestPrice?: number;
    onDemandMaxPricePercentageOverLowestPrice?: number;
    bareMetal?: BareMetal;
    burstablePerformance?: BurstablePerformance;
    requireHibernateSupport?: boolean;
    networkInterfaceCount?: NetworkInterfaceCountRequest;
    localStorage?: LocalStorage;
    localStorageTypes?: LocalStorageType[];
    totalLocalStorageGB?: TotalLocalStorageGBRequest;
    baselineEbsBandwidthMbps?: BaselineEbsBandwidthMbpsRequest;
    acceleratorTypes?: AcceleratorType[];
    acceleratorCount?: AcceleratorCountRequest;
    acceleratorManufacturers?: AcceleratorManufacturer[];
    acceleratorNames?: AcceleratorName[];
    acceleratorTotalMemoryMiB?: AcceleratorTotalMemoryMiBRequest;
    networkBandwidthGbps?: NetworkBandwidthGbpsRequest;
    allowedInstanceTypes?: string[];
    maxSpotPriceAsPercentageOfOptimalOnDemandPrice?: number;
}
export declare const InstanceRequirementsRequest: S.Schema<InstanceRequirementsRequest>;
export type CapacityReservationPreference = "RESERVATIONS_ONLY" | "RESERVATIONS_FIRST" | "RESERVATIONS_EXCLUDED" | (string & {});
export declare const CapacityReservationPreference: any;
export interface CapacityReservationRequest {
    reservationGroupArn?: string;
    reservationPreference?: CapacityReservationPreference;
}
export declare const CapacityReservationRequest: S.Schema<CapacityReservationRequest>;
export interface InstanceLaunchTemplate {
    ec2InstanceProfileArn: string;
    networkConfiguration: ManagedInstancesNetworkConfiguration;
    storageConfiguration?: ManagedInstancesStorageConfiguration;
    localStorageConfiguration?: ManagedInstancesLocalStorageConfiguration;
    monitoring?: ManagedInstancesMonitoringOptions;
    capacityOptionType?: CapacityOptionType;
    instanceMetadataTagsPropagation?: boolean;
    instanceRequirements?: InstanceRequirementsRequest;
    fipsEnabled?: boolean;
    capacityReservations?: CapacityReservationRequest;
}
export declare const InstanceLaunchTemplate: S.Schema<InstanceLaunchTemplate>;
export type PropagateMITags = "CAPACITY_PROVIDER" | "NONE" | (string & {});
export declare const PropagateMITags: any;
export interface InfrastructureOptimization {
    scaleInAfter?: number;
}
export declare const InfrastructureOptimization: S.Schema<InfrastructureOptimization>;
export type AutoRepairActionsStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const AutoRepairActionsStatus: any;
export interface AutoRepairConfiguration {
    actionsStatus?: AutoRepairActionsStatus;
}
export declare const AutoRepairConfiguration: S.Schema<AutoRepairConfiguration>;
export interface CreateManagedInstancesProviderConfiguration {
    infrastructureRoleArn: string;
    instanceLaunchTemplate: InstanceLaunchTemplate;
    propagateTags?: PropagateMITags;
    infrastructureOptimization?: InfrastructureOptimization;
    autoRepairConfiguration?: AutoRepairConfiguration;
}
export declare const CreateManagedInstancesProviderConfiguration: S.Schema<CreateManagedInstancesProviderConfiguration>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key?: string;
    value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export interface CreateCapacityProviderRequest {
    name: string;
    cluster?: string;
    autoScalingGroupProvider?: AutoScalingGroupProvider;
    managedInstancesProvider?: CreateManagedInstancesProviderConfiguration;
    tags?: Tag[];
}
export declare const CreateCapacityProviderRequest: S.Schema<CreateCapacityProviderRequest>;
export type CapacityProviderStatus = "PROVISIONING" | "ACTIVE" | "DEPROVISIONING" | "INACTIVE" | (string & {});
export declare const CapacityProviderStatus: any;
export interface ManagedInstancesProvider {
    infrastructureRoleArn?: string;
    instanceLaunchTemplate?: InstanceLaunchTemplate;
    propagateTags?: PropagateMITags;
    infrastructureOptimization?: InfrastructureOptimization;
    autoRepairConfiguration?: AutoRepairConfiguration;
}
export declare const ManagedInstancesProvider: S.Schema<ManagedInstancesProvider>;
export type CapacityProviderUpdateStatus = "CREATE_IN_PROGRESS" | "CREATE_COMPLETE" | "CREATE_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_COMPLETE" | "DELETE_FAILED" | "UPDATE_IN_PROGRESS" | "UPDATE_COMPLETE" | "UPDATE_FAILED" | (string & {});
export declare const CapacityProviderUpdateStatus: any;
export type CapacityProviderType = "EC2_AUTOSCALING" | "MANAGED_INSTANCES" | "FARGATE" | "FARGATE_SPOT" | (string & {});
export declare const CapacityProviderType: any;
export interface CapacityProvider {
    capacityProviderArn?: string;
    name?: string;
    cluster?: string;
    status?: CapacityProviderStatus;
    autoScalingGroupProvider?: AutoScalingGroupProvider;
    managedInstancesProvider?: ManagedInstancesProvider;
    updateStatus?: CapacityProviderUpdateStatus;
    updateStatusReason?: string;
    tags?: Tag[];
    type?: CapacityProviderType;
}
export declare const CapacityProvider: S.Schema<CapacityProvider>;
export interface CreateCapacityProviderResponse {
    capacityProvider?: CapacityProvider;
}
export declare const CreateCapacityProviderResponse: S.Schema<CreateCapacityProviderResponse>;
export type ClusterSettingName = "containerInsights" | (string & {});
export declare const ClusterSettingName: any;
export interface ClusterSetting {
    name?: ClusterSettingName;
    value?: string;
}
export declare const ClusterSetting: S.Schema<ClusterSetting>;
export type ClusterSettings = ClusterSetting[];
export declare const ClusterSettings: any;
export type ExecuteCommandLogging = "NONE" | "DEFAULT" | "OVERRIDE" | (string & {});
export declare const ExecuteCommandLogging: any;
export interface ExecuteCommandLogConfiguration {
    cloudWatchLogGroupName?: string;
    cloudWatchEncryptionEnabled?: boolean;
    s3BucketName?: string;
    s3EncryptionEnabled?: boolean;
    s3KeyPrefix?: string;
}
export declare const ExecuteCommandLogConfiguration: S.Schema<ExecuteCommandLogConfiguration>;
export interface ExecuteCommandConfiguration {
    kmsKeyId?: string;
    logging?: ExecuteCommandLogging;
    logConfiguration?: ExecuteCommandLogConfiguration;
}
export declare const ExecuteCommandConfiguration: S.Schema<ExecuteCommandConfiguration>;
export interface ManagedStorageConfiguration {
    kmsKeyId?: string;
    fargateEphemeralStorageKmsKeyId?: string;
}
export declare const ManagedStorageConfiguration: S.Schema<ManagedStorageConfiguration>;
export interface ClusterConfiguration {
    executeCommandConfiguration?: ExecuteCommandConfiguration;
    managedStorageConfiguration?: ManagedStorageConfiguration;
}
export declare const ClusterConfiguration: S.Schema<ClusterConfiguration>;
export type CapacityProviderStrategyItemWeight = number;
export type CapacityProviderStrategyItemBase = number;
export interface CapacityProviderStrategyItem {
    capacityProvider: string;
    weight?: number;
    base?: number;
}
export declare const CapacityProviderStrategyItem: S.Schema<CapacityProviderStrategyItem>;
export type CapacityProviderStrategy = CapacityProviderStrategyItem[];
export declare const CapacityProviderStrategy: any;
export interface ClusterServiceConnectDefaultsRequest {
    namespace: string;
}
export declare const ClusterServiceConnectDefaultsRequest: S.Schema<ClusterServiceConnectDefaultsRequest>;
export interface CreateClusterRequest {
    clusterName?: string;
    tags?: Tag[];
    settings?: ClusterSetting[];
    configuration?: ClusterConfiguration;
    capacityProviders?: string[];
    defaultCapacityProviderStrategy?: CapacityProviderStrategyItem[];
    serviceConnectDefaults?: ClusterServiceConnectDefaultsRequest;
}
export declare const CreateClusterRequest: S.Schema<CreateClusterRequest>;
export interface KeyValuePair {
    name?: string;
    value?: string;
}
export declare const KeyValuePair: S.Schema<KeyValuePair>;
export type Statistics = KeyValuePair[];
export declare const Statistics: any;
export type AttachmentDetails = KeyValuePair[];
export declare const AttachmentDetails: any;
export interface Attachment {
    id?: string;
    type?: string;
    status?: string;
    details?: KeyValuePair[];
}
export declare const Attachment: S.Schema<Attachment>;
export type Attachments = Attachment[];
export declare const Attachments: any;
export interface ClusterServiceConnectDefaults {
    namespace?: string;
}
export declare const ClusterServiceConnectDefaults: S.Schema<ClusterServiceConnectDefaults>;
export interface Cluster {
    clusterArn?: string;
    clusterName?: string;
    configuration?: ClusterConfiguration;
    status?: string;
    registeredContainerInstancesCount?: number;
    runningTasksCount?: number;
    pendingTasksCount?: number;
    activeServicesCount?: number;
    statistics?: KeyValuePair[];
    tags?: Tag[];
    settings?: ClusterSetting[];
    capacityProviders?: string[];
    defaultCapacityProviderStrategy?: CapacityProviderStrategyItem[];
    attachments?: Attachment[];
    attachmentsStatus?: string;
    serviceConnectDefaults?: ClusterServiceConnectDefaults;
}
export declare const Cluster: S.Schema<Cluster>;
export interface CreateClusterResponse {
    cluster?: Cluster;
}
export declare const CreateClusterResponse: S.Schema<CreateClusterResponse>;
export type DaemonDrainPercent = number;
export interface DaemonAlarmConfiguration {
    alarmNames?: string[];
    enable?: boolean;
}
export declare const DaemonAlarmConfiguration: S.Schema<DaemonAlarmConfiguration>;
export interface DaemonDeploymentConfiguration {
    drainPercent?: number;
    alarms?: DaemonAlarmConfiguration;
    bakeTimeInMinutes?: number;
}
export declare const DaemonDeploymentConfiguration: S.Schema<DaemonDeploymentConfiguration>;
export type DaemonPropagateTags = "DAEMON" | "NONE" | (string & {});
export declare const DaemonPropagateTags: any;
export interface CreateDaemonRequest {
    daemonName: string;
    clusterArn?: string;
    daemonTaskDefinitionArn: string;
    capacityProviderArns: string[];
    deploymentConfiguration?: DaemonDeploymentConfiguration;
    tags?: Tag[];
    propagateTags?: DaemonPropagateTags;
    enableECSManagedTags?: boolean;
    enableExecuteCommand?: boolean;
    clientToken?: string;
}
export declare const CreateDaemonRequest: S.Schema<CreateDaemonRequest>;
export type DaemonStatus = "ACTIVE" | "DELETE_IN_PROGRESS" | (string & {});
export declare const DaemonStatus: any;
export interface CreateDaemonResponse {
    daemonArn?: string;
    status?: DaemonStatus;
    createdAt?: Date;
    deploymentArn?: string;
}
export declare const CreateDaemonResponse: S.Schema<CreateDaemonResponse>;
export interface ExpressGatewayServiceAwsLogsConfiguration {
    logGroup: string;
    logStreamPrefix: string;
}
export declare const ExpressGatewayServiceAwsLogsConfiguration: S.Schema<ExpressGatewayServiceAwsLogsConfiguration>;
export interface ExpressGatewayRepositoryCredentials {
    credentialsParameter?: string;
}
export declare const ExpressGatewayRepositoryCredentials: S.Schema<ExpressGatewayRepositoryCredentials>;
export type EnvironmentVariables = KeyValuePair[];
export declare const EnvironmentVariables: any;
export interface Secret {
    name: string;
    valueFrom: string;
}
export declare const Secret: S.Schema<Secret>;
export type SecretList = Secret[];
export declare const SecretList: any;
export interface ExpressGatewayContainer {
    image: string;
    containerPort?: number;
    awsLogsConfiguration?: ExpressGatewayServiceAwsLogsConfiguration;
    repositoryCredentials?: ExpressGatewayRepositoryCredentials;
    command?: string[];
    environment?: KeyValuePair[];
    secrets?: Secret[];
}
export declare const ExpressGatewayContainer: S.Schema<ExpressGatewayContainer>;
export interface ExpressGatewayServiceNetworkConfiguration {
    securityGroups?: string[];
    subnets?: string[];
}
export declare const ExpressGatewayServiceNetworkConfiguration: S.Schema<ExpressGatewayServiceNetworkConfiguration>;
export type ExpressGatewayServiceScalingMetric = "AVERAGE_CPU" | "AVERAGE_MEMORY" | "REQUEST_COUNT_PER_TARGET" | (string & {});
export declare const ExpressGatewayServiceScalingMetric: any;
export interface ExpressGatewayScalingTarget {
    minTaskCount?: number;
    maxTaskCount?: number;
    autoScalingMetric?: ExpressGatewayServiceScalingMetric;
    autoScalingTargetValue?: number;
}
export declare const ExpressGatewayScalingTarget: S.Schema<ExpressGatewayScalingTarget>;
export interface CreateExpressGatewayServiceRequest {
    executionRoleArn?: string;
    infrastructureRoleArn: string;
    serviceName?: string;
    cluster?: string;
    healthCheckPath?: string;
    primaryContainer?: ExpressGatewayContainer;
    taskRoleArn?: string;
    networkConfiguration?: ExpressGatewayServiceNetworkConfiguration;
    cpu?: string;
    memory?: string;
    scalingTarget?: ExpressGatewayScalingTarget;
    tags?: Tag[];
    taskDefinitionArn?: string;
}
export declare const CreateExpressGatewayServiceRequest: S.Schema<CreateExpressGatewayServiceRequest>;
export type ExpressGatewayServiceStatusCode = "ACTIVE" | "DRAINING" | "INACTIVE" | (string & {});
export declare const ExpressGatewayServiceStatusCode: any;
export interface ExpressGatewayServiceStatus {
    statusCode?: ExpressGatewayServiceStatusCode;
    statusReason?: string;
}
export declare const ExpressGatewayServiceStatus: S.Schema<ExpressGatewayServiceStatus>;
export type AccessType = "PUBLIC" | "PRIVATE" | (string & {});
export declare const AccessType: any;
export interface IngressPathSummary {
    accessType: AccessType;
    endpoint: string;
}
export declare const IngressPathSummary: S.Schema<IngressPathSummary>;
export type IngressPathSummaries = IngressPathSummary[];
export declare const IngressPathSummaries: any;
export interface ExpressGatewayServiceConfiguration {
    serviceRevisionArn?: string;
    executionRoleArn?: string;
    taskRoleArn?: string;
    taskDefinitionArn?: string;
    cpu?: string;
    memory?: string;
    networkConfiguration?: ExpressGatewayServiceNetworkConfiguration;
    healthCheckPath?: string;
    primaryContainer?: ExpressGatewayContainer;
    scalingTarget?: ExpressGatewayScalingTarget;
    ingressPaths?: IngressPathSummary[];
    createdAt?: Date;
}
export declare const ExpressGatewayServiceConfiguration: S.Schema<ExpressGatewayServiceConfiguration>;
export type ExpressGatewayServiceConfigurations = ExpressGatewayServiceConfiguration[];
export declare const ExpressGatewayServiceConfigurations: any;
export interface ECSExpressGatewayService {
    cluster?: string;
    serviceName?: string;
    serviceArn?: string;
    infrastructureRoleArn?: string;
    status?: ExpressGatewayServiceStatus;
    currentDeployment?: string;
    activeConfigurations?: ExpressGatewayServiceConfiguration[];
    tags?: Tag[];
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const ECSExpressGatewayService: S.Schema<ECSExpressGatewayService>;
export interface CreateExpressGatewayServiceResponse {
    service?: ECSExpressGatewayService;
}
export declare const CreateExpressGatewayServiceResponse: S.Schema<CreateExpressGatewayServiceResponse>;
export type AvailabilityZoneRebalancing = "ENABLED" | "DISABLED" | (string & {});
export declare const AvailabilityZoneRebalancing: any;
export interface AdvancedConfiguration {
    alternateTargetGroupArn?: string;
    productionListenerRule?: string;
    testListenerRule?: string;
    roleArn?: string;
}
export declare const AdvancedConfiguration: S.Schema<AdvancedConfiguration>;
export interface LoadBalancer {
    targetGroupArn?: string;
    loadBalancerName?: string;
    containerName?: string;
    containerPort?: number;
    advancedConfiguration?: AdvancedConfiguration;
}
export declare const LoadBalancer: S.Schema<LoadBalancer>;
export type LoadBalancers = LoadBalancer[];
export declare const LoadBalancers: any;
export interface ServiceRegistry {
    registryArn?: string;
    port?: number;
    containerName?: string;
    containerPort?: number;
}
export declare const ServiceRegistry: S.Schema<ServiceRegistry>;
export type ServiceRegistries = ServiceRegistry[];
export declare const ServiceRegistries: any;
export type LaunchType = "EC2" | "FARGATE" | "EXTERNAL" | "MANAGED_INSTANCES" | (string & {});
export declare const LaunchType: any;
export type ThresholdType = "COUNT" | "BOUNDED_PERCENT" | "UNBOUNDED_PERCENT" | (string & {});
export declare const ThresholdType: any;
export interface ThresholdConfiguration {
    type: ThresholdType;
    value: number;
}
export declare const ThresholdConfiguration: S.Schema<ThresholdConfiguration>;
export interface DeploymentCircuitBreaker {
    enable: boolean;
    rollback: boolean;
    resetOnHealthyTask?: boolean;
    thresholdConfiguration?: ThresholdConfiguration;
}
export declare const DeploymentCircuitBreaker: S.Schema<DeploymentCircuitBreaker>;
export interface DeploymentAlarms {
    alarmNames: string[];
    rollback: boolean;
    enable: boolean;
}
export declare const DeploymentAlarms: S.Schema<DeploymentAlarms>;
export type DeploymentStrategy = "ROLLING" | "BLUE_GREEN" | "LINEAR" | "CANARY" | (string & {});
export declare const DeploymentStrategy: any;
export type DeploymentLifecycleHookTargetType = "AWS_LAMBDA" | "PAUSE" | (string & {});
export declare const DeploymentLifecycleHookTargetType: any;
export type IAMRoleArn = string;
export type DeploymentLifecycleHookStage = "RECONCILE_SERVICE" | "PRE_SCALE_UP" | "POST_SCALE_UP" | "TEST_TRAFFIC_SHIFT" | "POST_TEST_TRAFFIC_SHIFT" | "PRE_PRODUCTION_TRAFFIC_SHIFT" | "PRODUCTION_TRAFFIC_SHIFT" | "POST_PRODUCTION_TRAFFIC_SHIFT" | (string & {});
export declare const DeploymentLifecycleHookStage: any;
export type DeploymentLifecycleHookStageList = DeploymentLifecycleHookStage[];
export declare const DeploymentLifecycleHookStageList: any;
export type HookDetails = unknown;
export type DeploymentLifecycleHookDuration = number;
export interface DeploymentLifecycleHookTimeoutConfiguration {
    timeoutInMinutes?: number;
    action?: DeploymentLifecycleHookAction;
}
export declare const DeploymentLifecycleHookTimeoutConfiguration: S.Schema<DeploymentLifecycleHookTimeoutConfiguration>;
export interface DeploymentLifecycleHook {
    targetType?: DeploymentLifecycleHookTargetType;
    hookTargetArn?: string;
    roleArn?: string;
    lifecycleStages?: DeploymentLifecycleHookStage[];
    hookDetails?: any;
    timeoutConfiguration?: DeploymentLifecycleHookTimeoutConfiguration;
}
export declare const DeploymentLifecycleHook: S.Schema<DeploymentLifecycleHook>;
export type DeploymentLifecycleHookList = DeploymentLifecycleHook[];
export declare const DeploymentLifecycleHookList: any;
export interface LinearConfiguration {
    stepPercent?: number;
    stepBakeTimeInMinutes?: number;
}
export declare const LinearConfiguration: S.Schema<LinearConfiguration>;
export interface CanaryConfiguration {
    canaryPercent?: number;
    canaryBakeTimeInMinutes?: number;
}
export declare const CanaryConfiguration: S.Schema<CanaryConfiguration>;
export type HealthyPercentInteger = number;
export type ServiceRevisionCleanup = "BLOCKING" | "DEFERRED" | (string & {});
export declare const ServiceRevisionCleanup: any;
export interface DeploymentEarlySuccessCriteria {
    enable: boolean;
    healthyPercent?: number;
    sourceServiceRevisionCleanup?: ServiceRevisionCleanup;
}
export declare const DeploymentEarlySuccessCriteria: S.Schema<DeploymentEarlySuccessCriteria>;
export interface DeploymentConfiguration {
    deploymentCircuitBreaker?: DeploymentCircuitBreaker;
    maximumPercent?: number;
    minimumHealthyPercent?: number;
    alarms?: DeploymentAlarms;
    strategy?: DeploymentStrategy;
    bakeTimeInMinutes?: number;
    lifecycleHooks?: DeploymentLifecycleHook[];
    linearConfiguration?: LinearConfiguration;
    canaryConfiguration?: CanaryConfiguration;
    earlySuccessCriteria?: DeploymentEarlySuccessCriteria;
}
export declare const DeploymentConfiguration: S.Schema<DeploymentConfiguration>;
export type PlacementConstraintType = "distinctInstance" | "memberOf" | (string & {});
export declare const PlacementConstraintType: any;
export interface PlacementConstraint {
    type?: PlacementConstraintType;
    expression?: string;
}
export declare const PlacementConstraint: S.Schema<PlacementConstraint>;
export type PlacementConstraints = PlacementConstraint[];
export declare const PlacementConstraints: any;
export type PlacementStrategyType = "random" | "spread" | "binpack" | (string & {});
export declare const PlacementStrategyType: any;
export interface PlacementStrategy {
    type?: PlacementStrategyType;
    field?: string;
}
export declare const PlacementStrategy: S.Schema<PlacementStrategy>;
export type PlacementStrategies = PlacementStrategy[];
export declare const PlacementStrategies: any;
export type AssignPublicIp = "ENABLED" | "DISABLED" | (string & {});
export declare const AssignPublicIp: any;
export interface AwsVpcConfiguration {
    subnets: string[];
    securityGroups?: string[];
    assignPublicIp?: AssignPublicIp;
}
export declare const AwsVpcConfiguration: S.Schema<AwsVpcConfiguration>;
export interface NetworkConfiguration {
    awsvpcConfiguration?: AwsVpcConfiguration;
}
export declare const NetworkConfiguration: S.Schema<NetworkConfiguration>;
export type SchedulingStrategy = "REPLICA" | "DAEMON" | (string & {});
export declare const SchedulingStrategy: any;
export type DeploymentControllerType = "ECS" | "CODE_DEPLOY" | "EXTERNAL" | (string & {});
export declare const DeploymentControllerType: any;
export interface DeploymentController {
    type: DeploymentControllerType;
}
export declare const DeploymentController: S.Schema<DeploymentController>;
export type PropagateTags = "TASK_DEFINITION" | "SERVICE" | "NONE" | (string & {});
export declare const PropagateTags: any;
export type PortNumber = number;
export interface ServiceConnectTestTrafficHeaderMatchRules {
    exact: string;
}
export declare const ServiceConnectTestTrafficHeaderMatchRules: S.Schema<ServiceConnectTestTrafficHeaderMatchRules>;
export interface ServiceConnectTestTrafficHeaderRules {
    name: string;
    value?: ServiceConnectTestTrafficHeaderMatchRules;
}
export declare const ServiceConnectTestTrafficHeaderRules: S.Schema<ServiceConnectTestTrafficHeaderRules>;
export interface ServiceConnectTestTrafficRules {
    header: ServiceConnectTestTrafficHeaderRules;
}
export declare const ServiceConnectTestTrafficRules: S.Schema<ServiceConnectTestTrafficRules>;
export interface ServiceConnectClientAlias {
    port: number;
    dnsName?: string;
    testTrafficRules?: ServiceConnectTestTrafficRules;
}
export declare const ServiceConnectClientAlias: S.Schema<ServiceConnectClientAlias>;
export type ServiceConnectClientAliasList = ServiceConnectClientAlias[];
export declare const ServiceConnectClientAliasList: any;
export type Duration = number;
export interface TimeoutConfiguration {
    idleTimeoutSeconds?: number;
    perRequestTimeoutSeconds?: number;
}
export declare const TimeoutConfiguration: S.Schema<TimeoutConfiguration>;
export interface ServiceConnectTlsCertificateAuthority {
    awsPcaAuthorityArn?: string;
}
export declare const ServiceConnectTlsCertificateAuthority: S.Schema<ServiceConnectTlsCertificateAuthority>;
export interface ServiceConnectTlsConfiguration {
    issuerCertificateAuthority: ServiceConnectTlsCertificateAuthority;
    kmsKey?: string;
    roleArn?: string;
}
export declare const ServiceConnectTlsConfiguration: S.Schema<ServiceConnectTlsConfiguration>;
export interface ServiceConnectService {
    portName: string;
    discoveryName?: string;
    clientAliases?: ServiceConnectClientAlias[];
    ingressPortOverride?: number;
    timeout?: TimeoutConfiguration;
    tls?: ServiceConnectTlsConfiguration;
}
export declare const ServiceConnectService: S.Schema<ServiceConnectService>;
export type ServiceConnectServiceList = ServiceConnectService[];
export declare const ServiceConnectServiceList: any;
export type LogDriver = "json-file" | "syslog" | "journald" | "gelf" | "fluentd" | "awslogs" | "splunk" | "awsfirelens" | (string & {});
export declare const LogDriver: any;
export type LogConfigurationOptionsMap = {
    [key: string]: string | undefined;
};
export declare const LogConfigurationOptionsMap: any;
export interface LogConfiguration {
    logDriver: LogDriver;
    options?: {
        [key: string]: string | undefined;
    };
    secretOptions?: Secret[];
}
export declare const LogConfiguration: S.Schema<LogConfiguration>;
export type ServiceConnectAccessLoggingFormat = "TEXT" | "JSON" | (string & {});
export declare const ServiceConnectAccessLoggingFormat: any;
export type ServiceConnectIncludeQueryParameters = "DISABLED" | "ENABLED" | (string & {});
export declare const ServiceConnectIncludeQueryParameters: any;
export interface ServiceConnectAccessLogConfiguration {
    format: ServiceConnectAccessLoggingFormat;
    includeQueryParameters?: ServiceConnectIncludeQueryParameters;
}
export declare const ServiceConnectAccessLogConfiguration: S.Schema<ServiceConnectAccessLogConfiguration>;
export interface ServiceConnectConfiguration {
    enabled: boolean;
    namespace?: string;
    services?: ServiceConnectService[];
    logConfiguration?: LogConfiguration;
    accessLogConfiguration?: ServiceConnectAccessLogConfiguration;
}
export declare const ServiceConnectConfiguration: S.Schema<ServiceConnectConfiguration>;
export type ECSVolumeName = string;
export type EBSKMSKeyId = string;
export type EBSVolumeType = string;
export type EBSSnapshotId = string;
export type EBSResourceType = "volume" | (string & {});
export declare const EBSResourceType: any;
export interface EBSTagSpecification {
    resourceType: EBSResourceType;
    tags?: Tag[];
    propagateTags?: PropagateTags;
}
export declare const EBSTagSpecification: S.Schema<EBSTagSpecification>;
export type EBSTagSpecifications = EBSTagSpecification[];
export declare const EBSTagSpecifications: any;
export type TaskFilesystemType = "ext3" | "ext4" | "xfs" | "ntfs" | (string & {});
export declare const TaskFilesystemType: any;
export interface ServiceManagedEBSVolumeConfiguration {
    encrypted?: boolean;
    kmsKeyId?: string;
    volumeType?: string;
    sizeInGiB?: number;
    snapshotId?: string;
    volumeInitializationRate?: number;
    iops?: number;
    throughput?: number;
    tagSpecifications?: EBSTagSpecification[];
    roleArn: string;
    filesystemType?: TaskFilesystemType;
}
export declare const ServiceManagedEBSVolumeConfiguration: S.Schema<ServiceManagedEBSVolumeConfiguration>;
export interface ServiceVolumeConfiguration {
    name: string;
    managedEBSVolume?: ServiceManagedEBSVolumeConfiguration;
}
export declare const ServiceVolumeConfiguration: S.Schema<ServiceVolumeConfiguration>;
export type ServiceVolumeConfigurations = ServiceVolumeConfiguration[];
export declare const ServiceVolumeConfigurations: any;
export interface VpcLatticeConfiguration {
    roleArn: string;
    targetGroupArn: string;
    portName: string;
}
export declare const VpcLatticeConfiguration: S.Schema<VpcLatticeConfiguration>;
export type VpcLatticeConfigurations = VpcLatticeConfiguration[];
export declare const VpcLatticeConfigurations: any;
export type MetricName = string;
export type MetricNamesList = string[];
export declare const MetricNamesList: any;
export type MetricResolutionSeconds = number;
export interface MetricConfiguration {
    metricNames: string[];
    resolutionSeconds: number;
}
export declare const MetricConfiguration: S.Schema<MetricConfiguration>;
export type MetricConfigurationList = MetricConfiguration[];
export declare const MetricConfigurationList: any;
export interface MonitoringConfiguration {
    metricConfigurations?: MetricConfiguration[];
}
export declare const MonitoringConfiguration: S.Schema<MonitoringConfiguration>;
export interface CreateServiceRequest {
    cluster?: string;
    serviceName: string;
    taskDefinition?: string;
    availabilityZoneRebalancing?: AvailabilityZoneRebalancing;
    loadBalancers?: LoadBalancer[];
    serviceRegistries?: ServiceRegistry[];
    desiredCount?: number;
    clientToken?: string;
    launchType?: LaunchType;
    capacityProviderStrategy?: CapacityProviderStrategyItem[];
    platformVersion?: string;
    role?: string;
    deploymentConfiguration?: DeploymentConfiguration;
    placementConstraints?: PlacementConstraint[];
    placementStrategy?: PlacementStrategy[];
    networkConfiguration?: NetworkConfiguration;
    healthCheckGracePeriodSeconds?: number;
    schedulingStrategy?: SchedulingStrategy;
    deploymentController?: DeploymentController;
    tags?: Tag[];
    enableECSManagedTags?: boolean;
    propagateTags?: PropagateTags;
    enableExecuteCommand?: boolean;
    serviceConnectConfiguration?: ServiceConnectConfiguration;
    volumeConfigurations?: ServiceVolumeConfiguration[];
    vpcLatticeConfigurations?: VpcLatticeConfiguration[];
    monitoring?: MonitoringConfiguration;
}
export declare const CreateServiceRequest: S.Schema<CreateServiceRequest>;
export type ScaleUnit = "PERCENT" | (string & {});
export declare const ScaleUnit: any;
export interface Scale {
    value?: number;
    unit?: ScaleUnit;
}
export declare const Scale: S.Schema<Scale>;
export type StabilityStatus = "STEADY_STATE" | "STABILIZING" | (string & {});
export declare const StabilityStatus: any;
export interface DeploymentEphemeralStorage {
    kmsKeyId?: string;
}
export declare const DeploymentEphemeralStorage: S.Schema<DeploymentEphemeralStorage>;
export interface TaskSet {
    id?: string;
    taskSetArn?: string;
    serviceArn?: string;
    clusterArn?: string;
    startedBy?: string;
    externalId?: string;
    status?: string;
    taskDefinition?: string;
    computedDesiredCount?: number;
    pendingCount?: number;
    runningCount?: number;
    createdAt?: Date;
    updatedAt?: Date;
    launchType?: LaunchType;
    capacityProviderStrategy?: CapacityProviderStrategyItem[];
    platformVersion?: string;
    platformFamily?: string;
    networkConfiguration?: NetworkConfiguration;
    loadBalancers?: LoadBalancer[];
    serviceRegistries?: ServiceRegistry[];
    scale?: Scale;
    stabilityStatus?: StabilityStatus;
    stabilityStatusAt?: Date;
    tags?: Tag[];
    fargateEphemeralStorage?: DeploymentEphemeralStorage;
}
export declare const TaskSet: S.Schema<TaskSet>;
export type TaskSets = TaskSet[];
export declare const TaskSets: any;
export type DeploymentRolloutState = "COMPLETED" | "FAILED" | "IN_PROGRESS" | (string & {});
export declare const DeploymentRolloutState: any;
export interface ServiceConnectServiceResource {
    discoveryName?: string;
    discoveryArn?: string;
}
export declare const ServiceConnectServiceResource: S.Schema<ServiceConnectServiceResource>;
export type ServiceConnectServiceResourceList = ServiceConnectServiceResource[];
export declare const ServiceConnectServiceResourceList: any;
export interface Deployment {
    id?: string;
    status?: string;
    taskDefinition?: string;
    desiredCount?: number;
    pendingCount?: number;
    runningCount?: number;
    failedTasks?: number;
    createdAt?: Date;
    updatedAt?: Date;
    capacityProviderStrategy?: CapacityProviderStrategyItem[];
    launchType?: LaunchType;
    platformVersion?: string;
    platformFamily?: string;
    networkConfiguration?: NetworkConfiguration;
    rolloutState?: DeploymentRolloutState;
    rolloutStateReason?: string;
    serviceConnectConfiguration?: ServiceConnectConfiguration;
    serviceConnectResources?: ServiceConnectServiceResource[];
    volumeConfigurations?: ServiceVolumeConfiguration[];
    fargateEphemeralStorage?: DeploymentEphemeralStorage;
    vpcLatticeConfigurations?: VpcLatticeConfiguration[];
}
export declare const Deployment: S.Schema<Deployment>;
export type Deployments = Deployment[];
export declare const Deployments: any;
export interface ServiceEvent {
    id?: string;
    createdAt?: Date;
    message?: string;
}
export declare const ServiceEvent: S.Schema<ServiceEvent>;
export type ServiceEvents = ServiceEvent[];
export declare const ServiceEvents: any;
export interface ServiceCurrentRevisionSummary {
    arn?: string;
    requestedTaskCount?: number;
    runningTaskCount?: number;
    pendingTaskCount?: number;
}
export declare const ServiceCurrentRevisionSummary: S.Schema<ServiceCurrentRevisionSummary>;
export type ServiceCurrentRevisionSummaryList = ServiceCurrentRevisionSummary[];
export declare const ServiceCurrentRevisionSummaryList: any;
export type ResourceManagementType = "CUSTOMER" | "ECS" | (string & {});
export declare const ResourceManagementType: any;
export interface Service {
    serviceArn?: string;
    serviceName?: string;
    clusterArn?: string;
    loadBalancers?: LoadBalancer[];
    serviceRegistries?: ServiceRegistry[];
    status?: string;
    desiredCount?: number;
    runningCount?: number;
    pendingCount?: number;
    launchType?: LaunchType;
    capacityProviderStrategy?: CapacityProviderStrategyItem[];
    platformVersion?: string;
    platformFamily?: string;
    taskDefinition?: string;
    deploymentConfiguration?: DeploymentConfiguration;
    taskSets?: TaskSet[];
    deployments?: Deployment[];
    roleArn?: string;
    events?: ServiceEvent[];
    createdAt?: Date;
    currentServiceDeployment?: string;
    currentServiceRevisions?: ServiceCurrentRevisionSummary[];
    placementConstraints?: PlacementConstraint[];
    placementStrategy?: PlacementStrategy[];
    networkConfiguration?: NetworkConfiguration;
    healthCheckGracePeriodSeconds?: number;
    schedulingStrategy?: SchedulingStrategy;
    deploymentController?: DeploymentController;
    tags?: Tag[];
    createdBy?: string;
    enableECSManagedTags?: boolean;
    propagateTags?: PropagateTags;
    enableExecuteCommand?: boolean;
    availabilityZoneRebalancing?: AvailabilityZoneRebalancing;
    resourceManagementType?: ResourceManagementType;
}
export declare const Service: S.Schema<Service>;
export interface CreateServiceResponse {
    service?: Service;
}
export declare const CreateServiceResponse: S.Schema<CreateServiceResponse>;
export interface CreateTaskSetRequest {
    service: string;
    cluster: string;
    externalId?: string;
    taskDefinition: string;
    networkConfiguration?: NetworkConfiguration;
    loadBalancers?: LoadBalancer[];
    serviceRegistries?: ServiceRegistry[];
    launchType?: LaunchType;
    capacityProviderStrategy?: CapacityProviderStrategyItem[];
    platformVersion?: string;
    scale?: Scale;
    clientToken?: string;
    tags?: Tag[];
}
export declare const CreateTaskSetRequest: S.Schema<CreateTaskSetRequest>;
export interface CreateTaskSetResponse {
    taskSet?: TaskSet;
}
export declare const CreateTaskSetResponse: S.Schema<CreateTaskSetResponse>;
export type SettingName = "serviceLongArnFormat" | "taskLongArnFormat" | "containerInstanceLongArnFormat" | "awsvpcTrunking" | "containerInsights" | "fargateFIPSMode" | "tagResourceAuthorization" | "fargateTaskRetirementWaitPeriod" | "guardDutyActivate" | "defaultLogDriverMode" | "fargateEventWindows" | (string & {});
export declare const SettingName: any;
export interface DeleteAccountSettingRequest {
    name: SettingName;
    principalArn?: string;
}
export declare const DeleteAccountSettingRequest: S.Schema<DeleteAccountSettingRequest>;
export type SettingType = "user" | "aws_managed" | (string & {});
export declare const SettingType: any;
export interface Setting {
    name?: SettingName;
    value?: string;
    principalArn?: string;
    type?: SettingType;
}
export declare const Setting: S.Schema<Setting>;
export interface DeleteAccountSettingResponse {
    setting?: Setting;
}
export declare const DeleteAccountSettingResponse: S.Schema<DeleteAccountSettingResponse>;
export type TargetType = "container-instance" | (string & {});
export declare const TargetType: any;
export interface Attribute {
    name: string;
    value?: string;
    targetType?: TargetType;
    targetId?: string;
}
export declare const Attribute: S.Schema<Attribute>;
export type Attributes = Attribute[];
export declare const Attributes: any;
export interface DeleteAttributesRequest {
    cluster?: string;
    attributes: Attribute[];
}
export declare const DeleteAttributesRequest: S.Schema<DeleteAttributesRequest>;
export interface DeleteAttributesResponse {
    attributes?: Attribute[];
}
export declare const DeleteAttributesResponse: S.Schema<DeleteAttributesResponse>;
export interface DeleteCapacityProviderRequest {
    capacityProvider: string;
    cluster?: string;
}
export declare const DeleteCapacityProviderRequest: S.Schema<DeleteCapacityProviderRequest>;
export interface DeleteCapacityProviderResponse {
    capacityProvider?: CapacityProvider;
}
export declare const DeleteCapacityProviderResponse: S.Schema<DeleteCapacityProviderResponse>;
export interface DeleteClusterRequest {
    cluster: string;
}
export declare const DeleteClusterRequest: S.Schema<DeleteClusterRequest>;
export interface DeleteClusterResponse {
    cluster?: Cluster;
}
export declare const DeleteClusterResponse: S.Schema<DeleteClusterResponse>;
export interface DeleteDaemonRequest {
    daemonArn: string;
}
export declare const DeleteDaemonRequest: S.Schema<DeleteDaemonRequest>;
export interface DeleteDaemonResponse {
    daemonArn?: string;
    status?: DaemonStatus;
    createdAt?: Date;
    updatedAt?: Date;
    deploymentArn?: string;
}
export declare const DeleteDaemonResponse: S.Schema<DeleteDaemonResponse>;
export interface DeleteDaemonTaskDefinitionRequest {
    daemonTaskDefinition: string;
}
export declare const DeleteDaemonTaskDefinitionRequest: S.Schema<DeleteDaemonTaskDefinitionRequest>;
export interface DeleteDaemonTaskDefinitionResponse {
    daemonTaskDefinitionArn?: string;
}
export declare const DeleteDaemonTaskDefinitionResponse: S.Schema<DeleteDaemonTaskDefinitionResponse>;
export interface DeleteExpressGatewayServiceRequest {
    serviceArn: string;
}
export declare const DeleteExpressGatewayServiceRequest: S.Schema<DeleteExpressGatewayServiceRequest>;
export interface DeleteExpressGatewayServiceResponse {
    service?: ECSExpressGatewayService;
}
export declare const DeleteExpressGatewayServiceResponse: S.Schema<DeleteExpressGatewayServiceResponse>;
export interface DeleteServiceRequest {
    cluster?: string;
    service: string;
    force?: boolean;
}
export declare const DeleteServiceRequest: S.Schema<DeleteServiceRequest>;
export interface DeleteServiceResponse {
    service?: Service;
}
export declare const DeleteServiceResponse: S.Schema<DeleteServiceResponse>;
export interface DeleteTaskDefinitionsRequest {
    taskDefinitions: string[];
}
export declare const DeleteTaskDefinitionsRequest: S.Schema<DeleteTaskDefinitionsRequest>;
export interface RepositoryCredentials {
    credentialsParameter: string;
}
export declare const RepositoryCredentials: S.Schema<RepositoryCredentials>;
export type TransportProtocol = "tcp" | "udp" | (string & {});
export declare const TransportProtocol: any;
export type ApplicationProtocol = "http" | "http2" | "grpc" | (string & {});
export declare const ApplicationProtocol: any;
export interface PortMapping {
    containerPort?: number;
    hostPort?: number;
    protocol?: TransportProtocol;
    name?: string;
    appProtocol?: ApplicationProtocol;
    containerPortRange?: string;
}
export declare const PortMapping: S.Schema<PortMapping>;
export type PortMappingList = PortMapping[];
export declare const PortMappingList: any;
export type IntegerList = number[];
export declare const IntegerList: any;
export interface ContainerRestartPolicy {
    enabled: boolean;
    ignoredExitCodes?: number[];
    restartAttemptPeriod?: number;
}
export declare const ContainerRestartPolicy: S.Schema<ContainerRestartPolicy>;
export type EnvironmentFileType = "s3" | (string & {});
export declare const EnvironmentFileType: any;
export interface EnvironmentFile {
    value: string;
    type: EnvironmentFileType;
}
export declare const EnvironmentFile: S.Schema<EnvironmentFile>;
export type EnvironmentFiles = EnvironmentFile[];
export declare const EnvironmentFiles: any;
export interface MountPoint {
    sourceVolume?: string;
    containerPath?: string;
    readOnly?: boolean;
}
export declare const MountPoint: S.Schema<MountPoint>;
export type MountPointList = MountPoint[];
export declare const MountPointList: any;
export interface VolumeFrom {
    sourceContainer?: string;
    readOnly?: boolean;
}
export declare const VolumeFrom: S.Schema<VolumeFrom>;
export type VolumeFromList = VolumeFrom[];
export declare const VolumeFromList: any;
export interface KernelCapabilities {
    add?: string[];
    drop?: string[];
}
export declare const KernelCapabilities: S.Schema<KernelCapabilities>;
export type DeviceCgroupPermission = "read" | "write" | "mknod" | (string & {});
export declare const DeviceCgroupPermission: any;
export type DeviceCgroupPermissions = DeviceCgroupPermission[];
export declare const DeviceCgroupPermissions: any;
export interface Device {
    hostPath: string;
    containerPath?: string;
    permissions?: DeviceCgroupPermission[];
}
export declare const Device: S.Schema<Device>;
export type DevicesList = Device[];
export declare const DevicesList: any;
export interface Tmpfs {
    containerPath: string;
    size: number;
    mountOptions?: string[];
}
export declare const Tmpfs: S.Schema<Tmpfs>;
export type TmpfsList = Tmpfs[];
export declare const TmpfsList: any;
export interface LinuxParameters {
    capabilities?: KernelCapabilities;
    devices?: Device[];
    initProcessEnabled?: boolean;
    sharedMemorySize?: number;
    tmpfs?: Tmpfs[];
    maxSwap?: number;
    swappiness?: number;
}
export declare const LinuxParameters: S.Schema<LinuxParameters>;
export type ContainerCondition = "START" | "COMPLETE" | "SUCCESS" | "HEALTHY" | (string & {});
export declare const ContainerCondition: any;
export interface ContainerDependency {
    containerName: string;
    condition: ContainerCondition;
}
export declare const ContainerDependency: S.Schema<ContainerDependency>;
export type ContainerDependencies = ContainerDependency[];
export declare const ContainerDependencies: any;
export type VersionConsistency = "enabled" | "disabled" | (string & {});
export declare const VersionConsistency: any;
export interface HostEntry {
    hostname: string;
    ipAddress: string;
}
export declare const HostEntry: S.Schema<HostEntry>;
export type HostEntryList = HostEntry[];
export declare const HostEntryList: any;
export type DockerLabelsMap = {
    [key: string]: string | undefined;
};
export declare const DockerLabelsMap: any;
export type UlimitName = "core" | "cpu" | "data" | "fsize" | "locks" | "memlock" | "msgqueue" | "nice" | "nofile" | "nproc" | "rss" | "rtprio" | "rttime" | "sigpending" | "stack" | (string & {});
export declare const UlimitName: any;
export interface Ulimit {
    name: UlimitName;
    softLimit: number;
    hardLimit: number;
}
export declare const Ulimit: S.Schema<Ulimit>;
export type UlimitList = Ulimit[];
export declare const UlimitList: any;
export interface HealthCheck {
    command: string[];
    interval?: number;
    timeout?: number;
    retries?: number;
    startPeriod?: number;
}
export declare const HealthCheck: S.Schema<HealthCheck>;
export interface SystemControl {
    namespace?: string;
    value?: string;
}
export declare const SystemControl: S.Schema<SystemControl>;
export type SystemControls = SystemControl[];
export declare const SystemControls: any;
export type ResourceType = "GPU" | "InferenceAccelerator" | "NeuronDevice" | (string & {});
export declare const ResourceType: any;
export interface ResourceRequirement {
    value: string;
    type: ResourceType;
}
export declare const ResourceRequirement: S.Schema<ResourceRequirement>;
export type ResourceRequirements = ResourceRequirement[];
export declare const ResourceRequirements: any;
export type FirelensConfigurationType = "fluentd" | "fluentbit" | (string & {});
export declare const FirelensConfigurationType: any;
export type FirelensConfigurationOptionsMap = {
    [key: string]: string | undefined;
};
export declare const FirelensConfigurationOptionsMap: any;
export interface FirelensConfiguration {
    type: FirelensConfigurationType;
    options?: {
        [key: string]: string | undefined;
    };
}
export declare const FirelensConfiguration: S.Schema<FirelensConfiguration>;
export interface ContainerDefinition {
    name?: string;
    image?: string;
    repositoryCredentials?: RepositoryCredentials;
    cpu?: number;
    memory?: number;
    memoryReservation?: number;
    links?: string[];
    portMappings?: PortMapping[];
    essential?: boolean;
    restartPolicy?: ContainerRestartPolicy;
    entryPoint?: string[];
    command?: string[];
    environment?: KeyValuePair[];
    environmentFiles?: EnvironmentFile[];
    mountPoints?: MountPoint[];
    volumesFrom?: VolumeFrom[];
    linuxParameters?: LinuxParameters;
    secrets?: Secret[];
    dependsOn?: ContainerDependency[];
    startTimeout?: number;
    stopTimeout?: number;
    versionConsistency?: VersionConsistency;
    hostname?: string;
    user?: string;
    workingDirectory?: string;
    disableNetworking?: boolean;
    privileged?: boolean;
    readonlyRootFilesystem?: boolean;
    dnsServers?: string[];
    dnsSearchDomains?: string[];
    extraHosts?: HostEntry[];
    dockerSecurityOptions?: string[];
    interactive?: boolean;
    pseudoTerminal?: boolean;
    dockerLabels?: {
        [key: string]: string | undefined;
    };
    ulimits?: Ulimit[];
    logConfiguration?: LogConfiguration;
    healthCheck?: HealthCheck;
    systemControls?: SystemControl[];
    resourceRequirements?: ResourceRequirement[];
    firelensConfiguration?: FirelensConfiguration;
    credentialSpecs?: string[];
}
export declare const ContainerDefinition: S.Schema<ContainerDefinition>;
export type ContainerDefinitions = ContainerDefinition[];
export declare const ContainerDefinitions: any;
export type NetworkMode = "bridge" | "host" | "awsvpc" | "none" | (string & {});
export declare const NetworkMode: any;
export interface HostVolumeProperties {
    sourcePath?: string;
}
export declare const HostVolumeProperties: S.Schema<HostVolumeProperties>;
export type Scope = "task" | "shared" | (string & {});
export declare const Scope: any;
export type StringMap = {
    [key: string]: string | undefined;
};
export declare const StringMap: any;
export interface DockerVolumeConfiguration {
    scope?: Scope;
    autoprovision?: boolean;
    driver?: string;
    driverOpts?: {
        [key: string]: string | undefined;
    };
    labels?: {
        [key: string]: string | undefined;
    };
}
export declare const DockerVolumeConfiguration: S.Schema<DockerVolumeConfiguration>;
export type EFSTransitEncryption = "ENABLED" | "DISABLED" | (string & {});
export declare const EFSTransitEncryption: any;
export type EFSAuthorizationConfigIAM = "ENABLED" | "DISABLED" | (string & {});
export declare const EFSAuthorizationConfigIAM: any;
export interface EFSAuthorizationConfig {
    accessPointId?: string;
    iam?: EFSAuthorizationConfigIAM;
}
export declare const EFSAuthorizationConfig: S.Schema<EFSAuthorizationConfig>;
export interface EFSVolumeConfiguration {
    fileSystemId: string;
    rootDirectory?: string;
    transitEncryption?: EFSTransitEncryption;
    transitEncryptionPort?: number;
    authorizationConfig?: EFSAuthorizationConfig;
}
export declare const EFSVolumeConfiguration: S.Schema<EFSVolumeConfiguration>;
export interface S3FilesVolumeConfiguration {
    fileSystemArn: string;
    rootDirectory?: string;
    transitEncryptionPort?: number;
    accessPointArn?: string;
}
export declare const S3FilesVolumeConfiguration: S.Schema<S3FilesVolumeConfiguration>;
export interface FSxWindowsFileServerAuthorizationConfig {
    credentialsParameter: string;
    domain: string;
}
export declare const FSxWindowsFileServerAuthorizationConfig: S.Schema<FSxWindowsFileServerAuthorizationConfig>;
export interface FSxWindowsFileServerVolumeConfiguration {
    fileSystemId: string;
    rootDirectory: string;
    authorizationConfig: FSxWindowsFileServerAuthorizationConfig;
}
export declare const FSxWindowsFileServerVolumeConfiguration: S.Schema<FSxWindowsFileServerVolumeConfiguration>;
export interface Volume {
    name?: string;
    host?: HostVolumeProperties;
    dockerVolumeConfiguration?: DockerVolumeConfiguration;
    efsVolumeConfiguration?: EFSVolumeConfiguration;
    s3filesVolumeConfiguration?: S3FilesVolumeConfiguration;
    fsxWindowsFileServerVolumeConfiguration?: FSxWindowsFileServerVolumeConfiguration;
    configuredAtLaunch?: boolean;
}
export declare const Volume: S.Schema<Volume>;
export type VolumeList = Volume[];
export declare const VolumeList: any;
export type TaskDefinitionStatus = "ACTIVE" | "INACTIVE" | "DELETE_IN_PROGRESS" | (string & {});
export declare const TaskDefinitionStatus: any;
export type RequiresAttributes = Attribute[];
export declare const RequiresAttributes: any;
export type TaskDefinitionPlacementConstraintType = "memberOf" | (string & {});
export declare const TaskDefinitionPlacementConstraintType: any;
export interface TaskDefinitionPlacementConstraint {
    type?: TaskDefinitionPlacementConstraintType;
    expression?: string;
}
export declare const TaskDefinitionPlacementConstraint: S.Schema<TaskDefinitionPlacementConstraint>;
export type TaskDefinitionPlacementConstraints = TaskDefinitionPlacementConstraint[];
export declare const TaskDefinitionPlacementConstraints: any;
export type Compatibility = "EC2" | "FARGATE" | "EXTERNAL" | "MANAGED_INSTANCES" | (string & {});
export declare const Compatibility: any;
export type CompatibilityList = Compatibility[];
export declare const CompatibilityList: any;
export type CPUArchitecture = "X86_64" | "ARM64" | (string & {});
export declare const CPUArchitecture: any;
export type OSFamily = "WINDOWS_SERVER_2019_FULL" | "WINDOWS_SERVER_2019_CORE" | "WINDOWS_SERVER_2016_FULL" | "WINDOWS_SERVER_2004_CORE" | "WINDOWS_SERVER_2022_CORE" | "WINDOWS_SERVER_2022_FULL" | "WINDOWS_SERVER_2025_CORE" | "WINDOWS_SERVER_2025_FULL" | "WINDOWS_SERVER_20H2_CORE" | "LINUX" | (string & {});
export declare const OSFamily: any;
export interface RuntimePlatform {
    cpuArchitecture?: CPUArchitecture;
    operatingSystemFamily?: OSFamily;
}
export declare const RuntimePlatform: S.Schema<RuntimePlatform>;
export interface InferenceAccelerator {
    deviceName: string;
    deviceType: string;
}
export declare const InferenceAccelerator: S.Schema<InferenceAccelerator>;
export type InferenceAccelerators = InferenceAccelerator[];
export declare const InferenceAccelerators: any;
export type PidMode = "host" | "task" | (string & {});
export declare const PidMode: any;
export type IpcMode = "host" | "task" | "none" | (string & {});
export declare const IpcMode: any;
export type ProxyConfigurationType = "APPMESH" | (string & {});
export declare const ProxyConfigurationType: any;
export type ProxyConfigurationProperties = KeyValuePair[];
export declare const ProxyConfigurationProperties: any;
export interface ProxyConfiguration {
    type?: ProxyConfigurationType;
    containerName: string;
    properties?: KeyValuePair[];
}
export declare const ProxyConfiguration: S.Schema<ProxyConfiguration>;
export interface EphemeralStorage {
    sizeInGiB: number;
}
export declare const EphemeralStorage: S.Schema<EphemeralStorage>;
export interface TaskDefinition {
    taskDefinitionArn?: string;
    containerDefinitions?: ContainerDefinition[];
    family?: string;
    taskRoleArn?: string;
    executionRoleArn?: string;
    networkMode?: NetworkMode;
    revision?: number;
    volumes?: Volume[];
    status?: TaskDefinitionStatus;
    requiresAttributes?: Attribute[];
    placementConstraints?: TaskDefinitionPlacementConstraint[];
    compatibilities?: Compatibility[];
    runtimePlatform?: RuntimePlatform;
    requiresCompatibilities?: Compatibility[];
    cpu?: string;
    memory?: string;
    inferenceAccelerators?: InferenceAccelerator[];
    pidMode?: PidMode;
    ipcMode?: IpcMode;
    proxyConfiguration?: ProxyConfiguration;
    registeredAt?: Date;
    deregisteredAt?: Date;
    deleteRequestedAt?: Date;
    registeredBy?: string;
    ephemeralStorage?: EphemeralStorage;
    enableFaultInjection?: boolean;
}
export declare const TaskDefinition: S.Schema<TaskDefinition>;
export type TaskDefinitionList = TaskDefinition[];
export declare const TaskDefinitionList: any;
export interface Failure {
    arn?: string;
    reason?: string;
    detail?: string;
}
export declare const Failure: S.Schema<Failure>;
export type Failures = Failure[];
export declare const Failures: any;
export interface DeleteTaskDefinitionsResponse {
    taskDefinitions?: TaskDefinition[];
    failures?: Failure[];
}
export declare const DeleteTaskDefinitionsResponse: S.Schema<DeleteTaskDefinitionsResponse>;
export interface DeleteTaskSetRequest {
    cluster: string;
    service: string;
    taskSet: string;
    force?: boolean;
}
export declare const DeleteTaskSetRequest: S.Schema<DeleteTaskSetRequest>;
export interface DeleteTaskSetResponse {
    taskSet?: TaskSet;
}
export declare const DeleteTaskSetResponse: S.Schema<DeleteTaskSetResponse>;
export interface DeregisterContainerInstanceRequest {
    cluster?: string;
    containerInstance: string;
    force?: boolean;
}
export declare const DeregisterContainerInstanceRequest: S.Schema<DeregisterContainerInstanceRequest>;
export interface VersionInfo {
    agentVersion?: string;
    agentHash?: string;
    dockerVersion?: string;
}
export declare const VersionInfo: S.Schema<VersionInfo>;
export interface Resource {
    name?: string;
    type?: string;
    doubleValue?: number;
    longValue?: number;
    integerValue?: number;
    stringSetValue?: string[];
}
export declare const Resource: S.Schema<Resource>;
export type Resources = Resource[];
export declare const Resources: any;
export type AgentUpdateStatus = "PENDING" | "STAGING" | "STAGED" | "UPDATING" | "UPDATED" | "FAILED" | (string & {});
export declare const AgentUpdateStatus: any;
export type InstanceHealthCheckState = "OK" | "IMPAIRED" | "INSUFFICIENT_DATA" | "INITIALIZING" | (string & {});
export declare const InstanceHealthCheckState: any;
export type InstanceHealthCheckType = "CONTAINER_RUNTIME" | "ACCELERATED_COMPUTE" | "DAEMON" | "AGENT_CONNECTIVITY" | (string & {});
export declare const InstanceHealthCheckType: any;
export interface InstanceHealthCheckResult {
    type?: InstanceHealthCheckType;
    status?: InstanceHealthCheckState;
    statusReason?: string;
    lastUpdated?: Date;
    lastStatusChange?: Date;
}
export declare const InstanceHealthCheckResult: S.Schema<InstanceHealthCheckResult>;
export type InstanceHealthCheckResultList = InstanceHealthCheckResult[];
export declare const InstanceHealthCheckResultList: any;
export interface ContainerInstanceHealthStatus {
    overallStatus?: InstanceHealthCheckState;
    details?: InstanceHealthCheckResult[];
}
export declare const ContainerInstanceHealthStatus: S.Schema<ContainerInstanceHealthStatus>;
export interface ContainerInstance {
    containerInstanceArn?: string;
    ec2InstanceId?: string;
    capacityProviderName?: string;
    version?: number;
    versionInfo?: VersionInfo;
    remainingResources?: Resource[];
    registeredResources?: Resource[];
    status?: string;
    statusReason?: string;
    agentConnected?: boolean;
    runningTasksCount?: number;
    pendingTasksCount?: number;
    agentUpdateStatus?: AgentUpdateStatus;
    attributes?: Attribute[];
    registeredAt?: Date;
    attachments?: Attachment[];
    tags?: Tag[];
    healthStatus?: ContainerInstanceHealthStatus;
}
export declare const ContainerInstance: S.Schema<ContainerInstance>;
export interface DeregisterContainerInstanceResponse {
    containerInstance?: ContainerInstance;
}
export declare const DeregisterContainerInstanceResponse: S.Schema<DeregisterContainerInstanceResponse>;
export interface DeregisterTaskDefinitionRequest {
    taskDefinition: string;
}
export declare const DeregisterTaskDefinitionRequest: S.Schema<DeregisterTaskDefinitionRequest>;
export interface DeregisterTaskDefinitionResponse {
    taskDefinition?: TaskDefinition;
}
export declare const DeregisterTaskDefinitionResponse: S.Schema<DeregisterTaskDefinitionResponse>;
export type CapacityProviderField = "TAGS" | (string & {});
export declare const CapacityProviderField: any;
export type CapacityProviderFieldList = CapacityProviderField[];
export declare const CapacityProviderFieldList: any;
export interface DescribeCapacityProvidersRequest {
    capacityProviders?: string[];
    cluster?: string;
    include?: CapacityProviderField[];
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeCapacityProvidersRequest: S.Schema<DescribeCapacityProvidersRequest>;
export type CapacityProviders = CapacityProvider[];
export declare const CapacityProviders: any;
export interface DescribeCapacityProvidersResponse {
    capacityProviders?: CapacityProvider[];
    failures?: Failure[];
    nextToken?: string;
}
export declare const DescribeCapacityProvidersResponse: S.Schema<DescribeCapacityProvidersResponse>;
export type ClusterField = "ATTACHMENTS" | "CONFIGURATIONS" | "SETTINGS" | "STATISTICS" | "TAGS" | (string & {});
export declare const ClusterField: any;
export type ClusterFieldList = ClusterField[];
export declare const ClusterFieldList: any;
export interface DescribeClustersRequest {
    clusters?: string[];
    include?: ClusterField[];
}
export declare const DescribeClustersRequest: S.Schema<DescribeClustersRequest>;
export type Clusters = Cluster[];
export declare const Clusters: any;
export interface DescribeClustersResponse {
    clusters?: Cluster[];
    failures?: Failure[];
}
export declare const DescribeClustersResponse: S.Schema<DescribeClustersResponse>;
export type ContainerInstanceField = "TAGS" | "CONTAINER_INSTANCE_HEALTH" | (string & {});
export declare const ContainerInstanceField: any;
export type ContainerInstanceFieldList = ContainerInstanceField[];
export declare const ContainerInstanceFieldList: any;
export interface DescribeContainerInstancesRequest {
    cluster?: string;
    containerInstances: string[];
    include?: ContainerInstanceField[];
}
export declare const DescribeContainerInstancesRequest: S.Schema<DescribeContainerInstancesRequest>;
export type ContainerInstances = ContainerInstance[];
export declare const ContainerInstances: any;
export interface DescribeContainerInstancesResponse {
    containerInstances?: ContainerInstance[];
    failures?: Failure[];
}
export declare const DescribeContainerInstancesResponse: S.Schema<DescribeContainerInstancesResponse>;
export interface DescribeDaemonRequest {
    daemonArn: string;
}
export declare const DescribeDaemonRequest: S.Schema<DescribeDaemonRequest>;
export interface DaemonCapacityProvider {
    arn?: string;
    runningCount?: number;
}
export declare const DaemonCapacityProvider: S.Schema<DaemonCapacityProvider>;
export type DaemonCapacityProviderList = DaemonCapacityProvider[];
export declare const DaemonCapacityProviderList: any;
export interface DaemonRevisionDetail {
    arn?: string;
    capacityProviders?: DaemonCapacityProvider[];
    totalRunningCount?: number;
}
export declare const DaemonRevisionDetail: S.Schema<DaemonRevisionDetail>;
export type DaemonRevisionDetailList = DaemonRevisionDetail[];
export declare const DaemonRevisionDetailList: any;
export interface DaemonDetail {
    daemonArn?: string;
    clusterArn?: string;
    status?: DaemonStatus;
    currentRevisions?: DaemonRevisionDetail[];
    deploymentArn?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const DaemonDetail: S.Schema<DaemonDetail>;
export interface DescribeDaemonResponse {
    daemon?: DaemonDetail;
}
export declare const DescribeDaemonResponse: S.Schema<DescribeDaemonResponse>;
export interface DescribeDaemonDeploymentsRequest {
    daemonDeploymentArns: string[];
}
export declare const DescribeDaemonDeploymentsRequest: S.Schema<DescribeDaemonDeploymentsRequest>;
export type DaemonDeploymentStatus = "PENDING" | "SUCCESSFUL" | "STOPPED" | "STOP_REQUESTED" | "IN_PROGRESS" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_SUCCESSFUL" | "ROLLBACK_FAILED" | (string & {});
export declare const DaemonDeploymentStatus: any;
export interface DaemonDeploymentCapacityProvider {
    arn?: string;
    runningInstanceCount?: number;
    drainingInstanceCount?: number;
}
export declare const DaemonDeploymentCapacityProvider: S.Schema<DaemonDeploymentCapacityProvider>;
export type DaemonDeploymentCapacityProviderList = DaemonDeploymentCapacityProvider[];
export declare const DaemonDeploymentCapacityProviderList: any;
export interface DaemonDeploymentRevisionDetail {
    arn?: string;
    capacityProviders?: DaemonDeploymentCapacityProvider[];
    totalRunningInstanceCount?: number;
    totalDrainingInstanceCount?: number;
}
export declare const DaemonDeploymentRevisionDetail: S.Schema<DaemonDeploymentRevisionDetail>;
export type DaemonDeploymentRevisionDetailList = DaemonDeploymentRevisionDetail[];
export declare const DaemonDeploymentRevisionDetailList: any;
export type DaemonDeploymentRollbackMonitorsStatus = "TRIGGERED" | "MONITORING" | "MONITORING_COMPLETE" | "DISABLED" | (string & {});
export declare const DaemonDeploymentRollbackMonitorsStatus: any;
export interface DaemonCircuitBreaker {
    failureCount?: number;
    status?: DaemonDeploymentRollbackMonitorsStatus;
    threshold?: number;
}
export declare const DaemonCircuitBreaker: S.Schema<DaemonCircuitBreaker>;
export interface DaemonDeploymentAlarms {
    status?: DaemonDeploymentRollbackMonitorsStatus;
    alarmNames?: string[];
    triggeredAlarmNames?: string[];
}
export declare const DaemonDeploymentAlarms: S.Schema<DaemonDeploymentAlarms>;
export interface DaemonRollback {
    reason?: string;
    startedAt?: Date;
    rollbackTargetDaemonRevisionArn?: string;
    rollbackCapacityProviders?: string[];
}
export declare const DaemonRollback: S.Schema<DaemonRollback>;
export interface DaemonDeployment {
    daemonDeploymentArn?: string;
    clusterArn?: string;
    status?: DaemonDeploymentStatus;
    statusReason?: string;
    targetDaemonRevision?: DaemonDeploymentRevisionDetail;
    sourceDaemonRevisions?: DaemonDeploymentRevisionDetail[];
    circuitBreaker?: DaemonCircuitBreaker;
    alarms?: DaemonDeploymentAlarms;
    rollback?: DaemonRollback;
    deploymentConfiguration?: DaemonDeploymentConfiguration;
    createdAt?: Date;
    startedAt?: Date;
    stoppedAt?: Date;
    finishedAt?: Date;
}
export declare const DaemonDeployment: S.Schema<DaemonDeployment>;
export type DaemonDeploymentList = DaemonDeployment[];
export declare const DaemonDeploymentList: any;
export interface DescribeDaemonDeploymentsResponse {
    failures?: Failure[];
    daemonDeployments?: DaemonDeployment[];
}
export declare const DescribeDaemonDeploymentsResponse: S.Schema<DescribeDaemonDeploymentsResponse>;
export interface DescribeDaemonRevisionsRequest {
    daemonRevisionArns: string[];
}
export declare const DescribeDaemonRevisionsRequest: S.Schema<DescribeDaemonRevisionsRequest>;
export interface DaemonContainerImage {
    containerName?: string;
    imageDigest?: string;
    image?: string;
}
export declare const DaemonContainerImage: S.Schema<DaemonContainerImage>;
export type DaemonContainerImages = DaemonContainerImage[];
export declare const DaemonContainerImages: any;
export interface DaemonRevision {
    daemonRevisionArn?: string;
    clusterArn?: string;
    daemonArn?: string;
    daemonTaskDefinitionArn?: string;
    createdAt?: Date;
    containerImages?: DaemonContainerImage[];
    propagateTags?: DaemonPropagateTags;
    enableECSManagedTags?: boolean;
    enableExecuteCommand?: boolean;
}
export declare const DaemonRevision: S.Schema<DaemonRevision>;
export type DaemonRevisions = DaemonRevision[];
export declare const DaemonRevisions: any;
export interface DescribeDaemonRevisionsResponse {
    daemonRevisions?: DaemonRevision[];
    failures?: Failure[];
}
export declare const DescribeDaemonRevisionsResponse: S.Schema<DescribeDaemonRevisionsResponse>;
export interface DescribeDaemonTaskDefinitionRequest {
    daemonTaskDefinition: string;
}
export declare const DescribeDaemonTaskDefinitionRequest: S.Schema<DescribeDaemonTaskDefinitionRequest>;
export interface DaemonLinuxParameters {
    capabilities?: KernelCapabilities;
    devices?: Device[];
    initProcessEnabled?: boolean;
    tmpfs?: Tmpfs[];
}
export declare const DaemonLinuxParameters: S.Schema<DaemonLinuxParameters>;
export interface DaemonContainerDefinition {
    name?: string;
    image: string;
    memory?: number;
    memoryReservation?: number;
    repositoryCredentials?: RepositoryCredentials;
    healthCheck?: HealthCheck;
    cpu?: number;
    essential?: boolean;
    entryPoint?: string[];
    command?: string[];
    workingDirectory?: string;
    environmentFiles?: EnvironmentFile[];
    environment?: KeyValuePair[];
    secrets?: Secret[];
    readonlyRootFilesystem?: boolean;
    mountPoints?: MountPoint[];
    logConfiguration?: LogConfiguration;
    firelensConfiguration?: FirelensConfiguration;
    privileged?: boolean;
    user?: string;
    ulimits?: Ulimit[];
    linuxParameters?: DaemonLinuxParameters;
    dependsOn?: ContainerDependency[];
    startTimeout?: number;
    stopTimeout?: number;
    systemControls?: SystemControl[];
    interactive?: boolean;
    pseudoTerminal?: boolean;
    restartPolicy?: ContainerRestartPolicy;
}
export declare const DaemonContainerDefinition: S.Schema<DaemonContainerDefinition>;
export type DaemonContainerDefinitionList = DaemonContainerDefinition[];
export declare const DaemonContainerDefinitionList: any;
export interface DaemonVolume {
    name?: string;
    host?: HostVolumeProperties;
}
export declare const DaemonVolume: S.Schema<DaemonVolume>;
export type DaemonVolumeList = DaemonVolume[];
export declare const DaemonVolumeList: any;
export type DaemonTaskDefinitionStatus = "ACTIVE" | "DELETE_IN_PROGRESS" | "DELETED" | (string & {});
export declare const DaemonTaskDefinitionStatus: any;
export type DaemonPidMode = "none" | "shared" | (string & {});
export declare const DaemonPidMode: any;
export type DaemonIpcMode = "none" | "shared" | (string & {});
export declare const DaemonIpcMode: any;
export interface DaemonTaskDefinition {
    daemonTaskDefinitionArn?: string;
    family?: string;
    revision?: number;
    taskRoleArn?: string;
    executionRoleArn?: string;
    containerDefinitions?: DaemonContainerDefinition[];
    volumes?: DaemonVolume[];
    cpu?: string;
    memory?: string;
    status?: DaemonTaskDefinitionStatus;
    registeredAt?: Date;
    deleteRequestedAt?: Date;
    registeredBy?: string;
    pidMode?: DaemonPidMode;
    ipcMode?: DaemonIpcMode;
}
export declare const DaemonTaskDefinition: S.Schema<DaemonTaskDefinition>;
export interface DescribeDaemonTaskDefinitionResponse {
    daemonTaskDefinition?: DaemonTaskDefinition;
}
export declare const DescribeDaemonTaskDefinitionResponse: S.Schema<DescribeDaemonTaskDefinitionResponse>;
export type ExpressGatewayServiceInclude = "TAGS" | (string & {});
export declare const ExpressGatewayServiceInclude: any;
export type ExpressGatewayServiceIncludeList = ExpressGatewayServiceInclude[];
export declare const ExpressGatewayServiceIncludeList: any;
export interface DescribeExpressGatewayServiceRequest {
    serviceArn: string;
    include?: ExpressGatewayServiceInclude[];
}
export declare const DescribeExpressGatewayServiceRequest: S.Schema<DescribeExpressGatewayServiceRequest>;
export interface DescribeExpressGatewayServiceResponse {
    service?: ECSExpressGatewayService;
}
export declare const DescribeExpressGatewayServiceResponse: S.Schema<DescribeExpressGatewayServiceResponse>;
export interface DescribeServiceDeploymentsRequest {
    serviceDeploymentArns: string[];
}
export declare const DescribeServiceDeploymentsRequest: S.Schema<DescribeServiceDeploymentsRequest>;
export interface ServiceRevisionSummary {
    arn?: string;
    requestedTaskCount?: number;
    runningTaskCount?: number;
    pendingTaskCount?: number;
    requestedTestTrafficWeight?: number;
    requestedProductionTrafficWeight?: number;
}
export declare const ServiceRevisionSummary: S.Schema<ServiceRevisionSummary>;
export type ServiceRevisionsSummaryList = ServiceRevisionSummary[];
export declare const ServiceRevisionsSummaryList: any;
export type ServiceDeploymentStatus = "PENDING" | "SUCCESSFUL" | "STOPPED" | "STOP_REQUESTED" | "IN_PROGRESS" | "ROLLBACK_REQUESTED" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_SUCCESSFUL" | "ROLLBACK_FAILED" | (string & {});
export declare const ServiceDeploymentStatus: any;
export type ServiceDeploymentLifecycleStage = "RECONCILE_SERVICE" | "PRE_SCALE_UP" | "SCALE_UP" | "POST_SCALE_UP" | "TEST_TRAFFIC_SHIFT" | "POST_TEST_TRAFFIC_SHIFT" | "PRODUCTION_TRAFFIC_SHIFT" | "POST_PRODUCTION_TRAFFIC_SHIFT" | "BAKE_TIME" | "CLEAN_UP" | (string & {});
export declare const ServiceDeploymentLifecycleStage: any;
export type DeploymentLifecycleHookStatus = "AWAITING_ACTION" | "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | "TIMED_OUT" | (string & {});
export declare const DeploymentLifecycleHookStatus: any;
export interface DeploymentLifecycleHookDetail {
    hookId?: string;
    targetType?: DeploymentLifecycleHookTargetType;
    targetArn?: string;
    status?: DeploymentLifecycleHookStatus;
    expiresAt?: Date;
    timeoutAction?: DeploymentLifecycleHookAction;
}
export declare const DeploymentLifecycleHookDetail: S.Schema<DeploymentLifecycleHookDetail>;
export type DeploymentLifecycleHookDetailList = DeploymentLifecycleHookDetail[];
export declare const DeploymentLifecycleHookDetailList: any;
export interface Rollback {
    reason?: string;
    startedAt?: Date;
    serviceRevisionArn?: string;
}
export declare const Rollback: S.Schema<Rollback>;
export type ServiceDeploymentRollbackMonitorsStatus = "TRIGGERED" | "MONITORING" | "MONITORING_COMPLETE" | "DISABLED" | (string & {});
export declare const ServiceDeploymentRollbackMonitorsStatus: any;
export interface ServiceDeploymentCircuitBreaker {
    status?: ServiceDeploymentRollbackMonitorsStatus;
    failureCount?: number;
    threshold?: number;
}
export declare const ServiceDeploymentCircuitBreaker: S.Schema<ServiceDeploymentCircuitBreaker>;
export interface ServiceDeploymentAlarms {
    status?: ServiceDeploymentRollbackMonitorsStatus;
    alarmNames?: string[];
    triggeredAlarmNames?: string[];
}
export declare const ServiceDeploymentAlarms: S.Schema<ServiceDeploymentAlarms>;
export interface ServiceDeployment {
    serviceDeploymentArn?: string;
    serviceArn?: string;
    clusterArn?: string;
    createdAt?: Date;
    startedAt?: Date;
    finishedAt?: Date;
    stoppedAt?: Date;
    updatedAt?: Date;
    sourceServiceRevisions?: ServiceRevisionSummary[];
    targetServiceRevision?: ServiceRevisionSummary;
    status?: ServiceDeploymentStatus;
    statusReason?: string;
    lifecycleStage?: ServiceDeploymentLifecycleStage;
    lifecycleHookDetails?: DeploymentLifecycleHookDetail[];
    deploymentConfiguration?: DeploymentConfiguration;
    rollback?: Rollback;
    deploymentCircuitBreaker?: ServiceDeploymentCircuitBreaker;
    alarms?: ServiceDeploymentAlarms;
}
export declare const ServiceDeployment: S.Schema<ServiceDeployment>;
export type ServiceDeployments = ServiceDeployment[];
export declare const ServiceDeployments: any;
export interface DescribeServiceDeploymentsResponse {
    serviceDeployments?: ServiceDeployment[];
    failures?: Failure[];
}
export declare const DescribeServiceDeploymentsResponse: S.Schema<DescribeServiceDeploymentsResponse>;
export interface DescribeServiceRevisionsRequest {
    serviceRevisionArns: string[];
}
export declare const DescribeServiceRevisionsRequest: S.Schema<DescribeServiceRevisionsRequest>;
export interface ContainerImage {
    containerName?: string;
    imageDigest?: string;
    image?: string;
}
export declare const ContainerImage: S.Schema<ContainerImage>;
export type ContainerImages = ContainerImage[];
export declare const ContainerImages: any;
export interface ServiceRevisionLoadBalancer {
    targetGroupArn?: string;
    productionListenerRule?: string;
}
export declare const ServiceRevisionLoadBalancer: S.Schema<ServiceRevisionLoadBalancer>;
export type ServiceRevisionLoadBalancers = ServiceRevisionLoadBalancer[];
export declare const ServiceRevisionLoadBalancers: any;
export interface ResolvedConfiguration {
    loadBalancers?: ServiceRevisionLoadBalancer[];
}
export declare const ResolvedConfiguration: S.Schema<ResolvedConfiguration>;
export type ManagedResourceStatus = "PROVISIONING" | "ACTIVE" | "DEPROVISIONING" | "DELETED" | "FAILED" | (string & {});
export declare const ManagedResourceStatus: any;
export interface ManagedLoadBalancer {
    arn?: string;
    status: ManagedResourceStatus;
    statusReason?: string;
    updatedAt: Date;
    scheme: string;
    subnetIds?: string[];
    securityGroupIds?: string[];
}
export declare const ManagedLoadBalancer: S.Schema<ManagedLoadBalancer>;
export interface ManagedSecurityGroup {
    arn?: string;
    status: ManagedResourceStatus;
    statusReason?: string;
    updatedAt: Date;
}
export declare const ManagedSecurityGroup: S.Schema<ManagedSecurityGroup>;
export type ManagedSecurityGroups = ManagedSecurityGroup[];
export declare const ManagedSecurityGroups: any;
export interface ManagedCertificate {
    arn?: string;
    status: ManagedResourceStatus;
    statusReason?: string;
    updatedAt: Date;
    domainName: string;
}
export declare const ManagedCertificate: S.Schema<ManagedCertificate>;
export interface ManagedListener {
    arn?: string;
    status: ManagedResourceStatus;
    statusReason?: string;
    updatedAt: Date;
}
export declare const ManagedListener: S.Schema<ManagedListener>;
export interface ManagedListenerRule {
    arn?: string;
    status: ManagedResourceStatus;
    statusReason?: string;
    updatedAt: Date;
}
export declare const ManagedListenerRule: S.Schema<ManagedListenerRule>;
export interface ManagedTargetGroup {
    arn?: string;
    status: ManagedResourceStatus;
    statusReason?: string;
    updatedAt: Date;
    healthCheckPath: string;
    healthCheckPort: number;
    port: number;
}
export declare const ManagedTargetGroup: S.Schema<ManagedTargetGroup>;
export type ManagedTargetGroups = ManagedTargetGroup[];
export declare const ManagedTargetGroups: any;
export interface ManagedIngressPath {
    accessType: AccessType;
    endpoint: string;
    loadBalancer?: ManagedLoadBalancer;
    loadBalancerSecurityGroups?: ManagedSecurityGroup[];
    certificate?: ManagedCertificate;
    listener?: ManagedListener;
    rule?: ManagedListenerRule;
    targetGroups?: ManagedTargetGroup[];
}
export declare const ManagedIngressPath: S.Schema<ManagedIngressPath>;
export type ManagedIngressPaths = ManagedIngressPath[];
export declare const ManagedIngressPaths: any;
export interface ManagedScalableTarget {
    arn?: string;
    status: ManagedResourceStatus;
    statusReason?: string;
    updatedAt: Date;
    minCapacity: number;
    maxCapacity: number;
}
export declare const ManagedScalableTarget: S.Schema<ManagedScalableTarget>;
export interface ManagedApplicationAutoScalingPolicy {
    arn?: string;
    status: ManagedResourceStatus;
    statusReason?: string;
    updatedAt: Date;
    policyType: string;
    targetValue: number;
    metric: string;
}
export declare const ManagedApplicationAutoScalingPolicy: S.Schema<ManagedApplicationAutoScalingPolicy>;
export type ManagedApplicationAutoScalingPolicies = ManagedApplicationAutoScalingPolicy[];
export declare const ManagedApplicationAutoScalingPolicies: any;
export interface ManagedAutoScaling {
    scalableTarget?: ManagedScalableTarget;
    applicationAutoScalingPolicies?: ManagedApplicationAutoScalingPolicy[];
}
export declare const ManagedAutoScaling: S.Schema<ManagedAutoScaling>;
export interface ManagedMetricAlarm {
    arn?: string;
    status: ManagedResourceStatus;
    statusReason?: string;
    updatedAt: Date;
}
export declare const ManagedMetricAlarm: S.Schema<ManagedMetricAlarm>;
export type ManagedMetricAlarms = ManagedMetricAlarm[];
export declare const ManagedMetricAlarms: any;
export interface ManagedLogGroup {
    arn?: string;
    status: ManagedResourceStatus;
    statusReason?: string;
    updatedAt: Date;
    logGroupName: string;
}
export declare const ManagedLogGroup: S.Schema<ManagedLogGroup>;
export type ManagedLogGroups = ManagedLogGroup[];
export declare const ManagedLogGroups: any;
export interface ECSManagedResources {
    ingressPaths?: ManagedIngressPath[];
    autoScaling?: ManagedAutoScaling;
    metricAlarms?: ManagedMetricAlarm[];
    serviceSecurityGroups?: ManagedSecurityGroup[];
    logGroups?: ManagedLogGroup[];
}
export declare const ECSManagedResources: S.Schema<ECSManagedResources>;
export interface RuntimePlatformOverride {
    cpuArchitecture?: string;
}
export declare const RuntimePlatformOverride: S.Schema<RuntimePlatformOverride>;
export interface ServiceRevisionOverrides {
    runtimePlatform?: RuntimePlatformOverride;
}
export declare const ServiceRevisionOverrides: S.Schema<ServiceRevisionOverrides>;
export interface ServiceRevision {
    serviceRevisionArn?: string;
    serviceArn?: string;
    clusterArn?: string;
    taskDefinition?: string;
    capacityProviderStrategy?: CapacityProviderStrategyItem[];
    launchType?: LaunchType;
    platformVersion?: string;
    platformFamily?: string;
    loadBalancers?: LoadBalancer[];
    serviceRegistries?: ServiceRegistry[];
    networkConfiguration?: NetworkConfiguration;
    containerImages?: ContainerImage[];
    guardDutyEnabled?: boolean;
    serviceConnectConfiguration?: ServiceConnectConfiguration;
    volumeConfigurations?: ServiceVolumeConfiguration[];
    fargateEphemeralStorage?: DeploymentEphemeralStorage;
    createdAt?: Date;
    vpcLatticeConfigurations?: VpcLatticeConfiguration[];
    resolvedConfiguration?: ResolvedConfiguration;
    ecsManagedResources?: ECSManagedResources;
    overrides?: ServiceRevisionOverrides;
    monitoring?: MonitoringConfiguration;
}
export declare const ServiceRevision: S.Schema<ServiceRevision>;
export type ServiceRevisions = ServiceRevision[];
export declare const ServiceRevisions: any;
export interface DescribeServiceRevisionsResponse {
    serviceRevisions?: ServiceRevision[];
    failures?: Failure[];
}
export declare const DescribeServiceRevisionsResponse: S.Schema<DescribeServiceRevisionsResponse>;
export type ServiceField = "TAGS" | (string & {});
export declare const ServiceField: any;
export type ServiceFieldList = ServiceField[];
export declare const ServiceFieldList: any;
export interface DescribeServicesRequest {
    cluster?: string;
    services: string[];
    include?: ServiceField[];
}
export declare const DescribeServicesRequest: S.Schema<DescribeServicesRequest>;
export type Services = Service[];
export declare const Services: any;
export interface DescribeServicesResponse {
    services?: Service[];
    failures?: Failure[];
}
export declare const DescribeServicesResponse: S.Schema<DescribeServicesResponse>;
export type TaskDefinitionField = "TAGS" | (string & {});
export declare const TaskDefinitionField: any;
export type TaskDefinitionFieldList = TaskDefinitionField[];
export declare const TaskDefinitionFieldList: any;
export interface DescribeTaskDefinitionRequest {
    taskDefinition: string;
    include?: TaskDefinitionField[];
}
export declare const DescribeTaskDefinitionRequest: S.Schema<DescribeTaskDefinitionRequest>;
export interface DescribeTaskDefinitionResponse {
    taskDefinition?: TaskDefinition;
    tags?: Tag[];
}
export declare const DescribeTaskDefinitionResponse: S.Schema<DescribeTaskDefinitionResponse>;
export type TaskField = "TAGS" | (string & {});
export declare const TaskField: any;
export type TaskFieldList = TaskField[];
export declare const TaskFieldList: any;
export interface DescribeTasksRequest {
    cluster?: string;
    tasks: string[];
    include?: TaskField[];
}
export declare const DescribeTasksRequest: S.Schema<DescribeTasksRequest>;
export type Connectivity = "CONNECTED" | "DISCONNECTED" | (string & {});
export declare const Connectivity: any;
export interface NetworkBinding {
    bindIP?: string;
    containerPort?: number;
    hostPort?: number;
    protocol?: TransportProtocol;
    containerPortRange?: string;
    hostPortRange?: string;
}
export declare const NetworkBinding: S.Schema<NetworkBinding>;
export type NetworkBindings = NetworkBinding[];
export declare const NetworkBindings: any;
export interface NetworkInterface {
    attachmentId?: string;
    privateIpv4Address?: string;
    ipv6Address?: string;
}
export declare const NetworkInterface: S.Schema<NetworkInterface>;
export type NetworkInterfaces = NetworkInterface[];
export declare const NetworkInterfaces: any;
export type HealthStatus = "HEALTHY" | "UNHEALTHY" | "UNKNOWN" | (string & {});
export declare const HealthStatus: any;
export type ManagedAgentName = "ExecuteCommandAgent" | (string & {});
export declare const ManagedAgentName: any;
export interface ManagedAgent {
    lastStartedAt?: Date;
    name?: ManagedAgentName;
    reason?: string;
    lastStatus?: string;
}
export declare const ManagedAgent: S.Schema<ManagedAgent>;
export type ManagedAgents = ManagedAgent[];
export declare const ManagedAgents: any;
export type GpuIds = string[];
export declare const GpuIds: any;
export type NeuronDeviceIds = string[];
export declare const NeuronDeviceIds: any;
export interface Container {
    containerArn?: string;
    taskArn?: string;
    name?: string;
    image?: string;
    imageDigest?: string;
    runtimeId?: string;
    lastStatus?: string;
    exitCode?: number;
    reason?: string;
    networkBindings?: NetworkBinding[];
    networkInterfaces?: NetworkInterface[];
    healthStatus?: HealthStatus;
    managedAgents?: ManagedAgent[];
    cpu?: string;
    memory?: string;
    memoryReservation?: string;
    gpuIds?: string[];
    neuronDeviceIds?: string[];
}
export declare const Container: S.Schema<Container>;
export type Containers = Container[];
export declare const Containers: any;
export interface ContainerOverride {
    name?: string;
    command?: string[];
    environment?: KeyValuePair[];
    environmentFiles?: EnvironmentFile[];
    cpu?: number;
    memory?: number;
    memoryReservation?: number;
    resourceRequirements?: ResourceRequirement[];
}
export declare const ContainerOverride: S.Schema<ContainerOverride>;
export type ContainerOverrides = ContainerOverride[];
export declare const ContainerOverrides: any;
export interface InferenceAcceleratorOverride {
    deviceName?: string;
    deviceType?: string;
}
export declare const InferenceAcceleratorOverride: S.Schema<InferenceAcceleratorOverride>;
export type InferenceAcceleratorOverrides = InferenceAcceleratorOverride[];
export declare const InferenceAcceleratorOverrides: any;
export interface TaskOverride {
    containerOverrides?: ContainerOverride[];
    cpu?: string;
    inferenceAcceleratorOverrides?: InferenceAcceleratorOverride[];
    executionRoleArn?: string;
    memory?: string;
    taskRoleArn?: string;
    ephemeralStorage?: EphemeralStorage;
}
export declare const TaskOverride: S.Schema<TaskOverride>;
export type TaskStopCode = "TaskFailedToStart" | "EssentialContainerExited" | "UserInitiated" | "ServiceSchedulerInitiated" | "SpotInterruption" | "TerminationNotice" | "InfrastructureHealth" | (string & {});
export declare const TaskStopCode: any;
export interface TaskEphemeralStorage {
    sizeInGiB?: number;
    kmsKeyId?: string;
}
export declare const TaskEphemeralStorage: S.Schema<TaskEphemeralStorage>;
export interface Task {
    attachments?: Attachment[];
    attributes?: Attribute[];
    availabilityZone?: string;
    capacityProviderName?: string;
    clusterArn?: string;
    connectivity?: Connectivity;
    connectivityAt?: Date;
    containerInstanceArn?: string;
    containers?: Container[];
    cpu?: string;
    createdAt?: Date;
    desiredStatus?: string;
    enableExecuteCommand?: boolean;
    executionStoppedAt?: Date;
    group?: string;
    healthStatus?: HealthStatus;
    inferenceAccelerators?: InferenceAccelerator[];
    lastStatus?: string;
    launchType?: LaunchType;
    memory?: string;
    overrides?: TaskOverride;
    platformVersion?: string;
    platformFamily?: string;
    pullStartedAt?: Date;
    pullStoppedAt?: Date;
    startedAt?: Date;
    startedBy?: string;
    stopCode?: TaskStopCode;
    stoppedAt?: Date;
    stoppedReason?: string;
    stoppingAt?: Date;
    tags?: Tag[];
    taskArn?: string;
    taskDefinitionArn?: string;
    version?: number;
    ephemeralStorage?: EphemeralStorage;
    fargateEphemeralStorage?: TaskEphemeralStorage;
}
export declare const Task: S.Schema<Task>;
export type Tasks = Task[];
export declare const Tasks: any;
export interface DescribeTasksResponse {
    tasks?: Task[];
    failures?: Failure[];
}
export declare const DescribeTasksResponse: S.Schema<DescribeTasksResponse>;
export type TaskSetField = "TAGS" | (string & {});
export declare const TaskSetField: any;
export type TaskSetFieldList = TaskSetField[];
export declare const TaskSetFieldList: any;
export interface DescribeTaskSetsRequest {
    cluster: string;
    service: string;
    taskSets?: string[];
    include?: TaskSetField[];
}
export declare const DescribeTaskSetsRequest: S.Schema<DescribeTaskSetsRequest>;
export interface DescribeTaskSetsResponse {
    taskSets?: TaskSet[];
    failures?: Failure[];
}
export declare const DescribeTaskSetsResponse: S.Schema<DescribeTaskSetsResponse>;
export interface DiscoverPollEndpointRequest {
    containerInstance?: string;
    cluster?: string;
}
export declare const DiscoverPollEndpointRequest: S.Schema<DiscoverPollEndpointRequest>;
export interface DiscoverPollEndpointResponse {
    endpoint?: string;
    telemetryEndpoint?: string;
    serviceConnectEndpoint?: string;
}
export declare const DiscoverPollEndpointResponse: S.Schema<DiscoverPollEndpointResponse>;
export interface ExecuteCommandRequest {
    cluster?: string;
    container?: string;
    command: string;
    interactive: boolean;
    task: string;
}
export declare const ExecuteCommandRequest: S.Schema<ExecuteCommandRequest>;
export type SensitiveString = string | redacted.Redacted<string>;
export interface Session {
    sessionId?: string;
    streamUrl?: string;
    tokenValue?: string | redacted.Redacted<string>;
}
export declare const Session: S.Schema<Session>;
export interface ExecuteCommandResponse {
    clusterArn?: string;
    containerArn?: string;
    containerName?: string;
    interactive?: boolean;
    session?: Session;
    taskArn?: string;
}
export declare const ExecuteCommandResponse: S.Schema<ExecuteCommandResponse>;
export interface GetTaskProtectionRequest {
    cluster: string;
    tasks?: string[];
}
export declare const GetTaskProtectionRequest: S.Schema<GetTaskProtectionRequest>;
export interface ProtectedTask {
    taskArn?: string;
    protectionEnabled?: boolean;
    expirationDate?: Date;
}
export declare const ProtectedTask: S.Schema<ProtectedTask>;
export type ProtectedTasks = ProtectedTask[];
export declare const ProtectedTasks: any;
export interface GetTaskProtectionResponse {
    protectedTasks?: ProtectedTask[];
    failures?: Failure[];
}
export declare const GetTaskProtectionResponse: S.Schema<GetTaskProtectionResponse>;
export interface ListAccountSettingsRequest {
    name?: SettingName;
    value?: string;
    principalArn?: string;
    effectiveSettings?: boolean;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAccountSettingsRequest: S.Schema<ListAccountSettingsRequest>;
export type Settings = Setting[];
export declare const Settings: any;
export interface ListAccountSettingsResponse {
    settings?: Setting[];
    nextToken?: string;
}
export declare const ListAccountSettingsResponse: S.Schema<ListAccountSettingsResponse>;
export interface ListAttributesRequest {
    cluster?: string;
    targetType: TargetType;
    attributeName?: string;
    attributeValue?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAttributesRequest: S.Schema<ListAttributesRequest>;
export interface ListAttributesResponse {
    attributes?: Attribute[];
    nextToken?: string;
}
export declare const ListAttributesResponse: S.Schema<ListAttributesResponse>;
export interface ListClustersRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListClustersRequest: S.Schema<ListClustersRequest>;
export interface ListClustersResponse {
    clusterArns?: string[];
    nextToken?: string;
}
export declare const ListClustersResponse: S.Schema<ListClustersResponse>;
export type ContainerInstanceStatus = "ACTIVE" | "DRAINING" | "REGISTERING" | "DEREGISTERING" | "REGISTRATION_FAILED" | (string & {});
export declare const ContainerInstanceStatus: any;
export interface ListContainerInstancesRequest {
    cluster?: string;
    filter?: string;
    nextToken?: string;
    maxResults?: number;
    status?: ContainerInstanceStatus;
}
export declare const ListContainerInstancesRequest: S.Schema<ListContainerInstancesRequest>;
export interface ListContainerInstancesResponse {
    containerInstanceArns?: string[];
    nextToken?: string;
}
export declare const ListContainerInstancesResponse: S.Schema<ListContainerInstancesResponse>;
export type DaemonDeploymentStatusList = DaemonDeploymentStatus[];
export declare const DaemonDeploymentStatusList: any;
export interface CreatedAt {
    before?: Date;
    after?: Date;
}
export declare const CreatedAt: S.Schema<CreatedAt>;
export interface ListDaemonDeploymentsRequest {
    daemonArn: string;
    status?: DaemonDeploymentStatus[];
    createdAt?: CreatedAt;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDaemonDeploymentsRequest: S.Schema<ListDaemonDeploymentsRequest>;
export interface DaemonDeploymentSummary {
    daemonDeploymentArn?: string;
    daemonArn?: string;
    clusterArn?: string;
    status?: DaemonDeploymentStatus;
    statusReason?: string;
    targetDaemonRevisionArn?: string;
    createdAt?: Date;
    startedAt?: Date;
    stoppedAt?: Date;
    finishedAt?: Date;
}
export declare const DaemonDeploymentSummary: S.Schema<DaemonDeploymentSummary>;
export type DaemonDeploymentSummaryList = DaemonDeploymentSummary[];
export declare const DaemonDeploymentSummaryList: any;
export interface ListDaemonDeploymentsResponse {
    nextToken?: string;
    daemonDeployments?: DaemonDeploymentSummary[];
}
export declare const ListDaemonDeploymentsResponse: S.Schema<ListDaemonDeploymentsResponse>;
export interface ListDaemonsRequest {
    clusterArn?: string;
    capacityProviderArns?: string[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDaemonsRequest: S.Schema<ListDaemonsRequest>;
export interface DaemonSummary {
    daemonArn?: string;
    status?: DaemonStatus;
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const DaemonSummary: S.Schema<DaemonSummary>;
export type DaemonSummariesList = DaemonSummary[];
export declare const DaemonSummariesList: any;
export interface ListDaemonsResponse {
    daemonSummariesList?: DaemonSummary[];
    nextToken?: string;
}
export declare const ListDaemonsResponse: S.Schema<ListDaemonsResponse>;
export type DaemonTaskDefinitionRevisionFilter = "LAST_REGISTERED" | (string & {});
export declare const DaemonTaskDefinitionRevisionFilter: any;
export type DaemonTaskDefinitionStatusFilter = "ACTIVE" | "DELETE_IN_PROGRESS" | "ALL" | (string & {});
export declare const DaemonTaskDefinitionStatusFilter: any;
export type SortOrder = "ASC" | "DESC" | (string & {});
export declare const SortOrder: any;
export interface ListDaemonTaskDefinitionsRequest {
    familyPrefix?: string;
    family?: string;
    revision?: DaemonTaskDefinitionRevisionFilter;
    status?: DaemonTaskDefinitionStatusFilter;
    sort?: SortOrder;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDaemonTaskDefinitionsRequest: S.Schema<ListDaemonTaskDefinitionsRequest>;
export interface DaemonTaskDefinitionSummary {
    arn?: string;
    registeredAt?: Date;
    registeredBy?: string;
    deleteRequestedAt?: Date;
    status?: DaemonTaskDefinitionStatus;
}
export declare const DaemonTaskDefinitionSummary: S.Schema<DaemonTaskDefinitionSummary>;
export type DaemonTaskDefinitionSummaries = DaemonTaskDefinitionSummary[];
export declare const DaemonTaskDefinitionSummaries: any;
export interface ListDaemonTaskDefinitionsResponse {
    daemonTaskDefinitions?: DaemonTaskDefinitionSummary[];
    nextToken?: string;
}
export declare const ListDaemonTaskDefinitionsResponse: S.Schema<ListDaemonTaskDefinitionsResponse>;
export type ServiceDeploymentStatusList = ServiceDeploymentStatus[];
export declare const ServiceDeploymentStatusList: any;
export interface ListServiceDeploymentsRequest {
    service: string;
    cluster?: string;
    status?: ServiceDeploymentStatus[];
    createdAt?: CreatedAt;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListServiceDeploymentsRequest: S.Schema<ListServiceDeploymentsRequest>;
export interface ServiceDeploymentBrief {
    serviceDeploymentArn?: string;
    serviceArn?: string;
    clusterArn?: string;
    startedAt?: Date;
    createdAt?: Date;
    finishedAt?: Date;
    targetServiceRevisionArn?: string;
    status?: ServiceDeploymentStatus;
    statusReason?: string;
}
export declare const ServiceDeploymentBrief: S.Schema<ServiceDeploymentBrief>;
export type ServiceDeploymentsBrief = ServiceDeploymentBrief[];
export declare const ServiceDeploymentsBrief: any;
export interface ListServiceDeploymentsResponse {
    serviceDeployments?: ServiceDeploymentBrief[];
    nextToken?: string;
}
export declare const ListServiceDeploymentsResponse: S.Schema<ListServiceDeploymentsResponse>;
export interface ListServicesRequest {
    cluster?: string;
    nextToken?: string;
    maxResults?: number;
    launchType?: LaunchType;
    schedulingStrategy?: SchedulingStrategy;
    resourceManagementType?: ResourceManagementType;
}
export declare const ListServicesRequest: S.Schema<ListServicesRequest>;
export interface ListServicesResponse {
    serviceArns?: string[];
    nextToken?: string;
}
export declare const ListServicesResponse: S.Schema<ListServicesResponse>;
export interface ListServicesByNamespaceRequest {
    namespace: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListServicesByNamespaceRequest: S.Schema<ListServicesByNamespaceRequest>;
export interface ListServicesByNamespaceResponse {
    serviceArns?: string[];
    nextToken?: string;
}
export declare const ListServicesByNamespaceResponse: S.Schema<ListServicesByNamespaceResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type TaskDefinitionFamilyStatus = "ACTIVE" | "INACTIVE" | "ALL" | (string & {});
export declare const TaskDefinitionFamilyStatus: any;
export interface ListTaskDefinitionFamiliesRequest {
    familyPrefix?: string;
    status?: TaskDefinitionFamilyStatus;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListTaskDefinitionFamiliesRequest: S.Schema<ListTaskDefinitionFamiliesRequest>;
export interface ListTaskDefinitionFamiliesResponse {
    families?: string[];
    nextToken?: string;
}
export declare const ListTaskDefinitionFamiliesResponse: S.Schema<ListTaskDefinitionFamiliesResponse>;
export interface ListTaskDefinitionsRequest {
    familyPrefix?: string;
    status?: TaskDefinitionStatus;
    sort?: SortOrder;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListTaskDefinitionsRequest: S.Schema<ListTaskDefinitionsRequest>;
export interface ListTaskDefinitionsResponse {
    taskDefinitionArns?: string[];
    nextToken?: string;
}
export declare const ListTaskDefinitionsResponse: S.Schema<ListTaskDefinitionsResponse>;
export type DesiredStatus = "RUNNING" | "PENDING" | "STOPPED" | (string & {});
export declare const DesiredStatus: any;
export interface ListTasksRequest {
    cluster?: string;
    containerInstance?: string;
    family?: string;
    nextToken?: string;
    maxResults?: number;
    startedBy?: string;
    serviceName?: string;
    desiredStatus?: DesiredStatus;
    launchType?: LaunchType;
    daemonName?: string;
}
export declare const ListTasksRequest: S.Schema<ListTasksRequest>;
export interface ListTasksResponse {
    taskArns?: string[];
    nextToken?: string;
}
export declare const ListTasksResponse: S.Schema<ListTasksResponse>;
export interface PutAccountSettingRequest {
    name: SettingName;
    value: string;
    principalArn?: string;
}
export declare const PutAccountSettingRequest: S.Schema<PutAccountSettingRequest>;
export interface PutAccountSettingResponse {
    setting?: Setting;
}
export declare const PutAccountSettingResponse: S.Schema<PutAccountSettingResponse>;
export interface PutAccountSettingDefaultRequest {
    name: SettingName;
    value: string;
}
export declare const PutAccountSettingDefaultRequest: S.Schema<PutAccountSettingDefaultRequest>;
export interface PutAccountSettingDefaultResponse {
    setting?: Setting;
}
export declare const PutAccountSettingDefaultResponse: S.Schema<PutAccountSettingDefaultResponse>;
export interface PutAttributesRequest {
    cluster?: string;
    attributes: Attribute[];
}
export declare const PutAttributesRequest: S.Schema<PutAttributesRequest>;
export interface PutAttributesResponse {
    attributes?: Attribute[];
}
export declare const PutAttributesResponse: S.Schema<PutAttributesResponse>;
export interface PutClusterCapacityProvidersRequest {
    cluster: string;
    capacityProviders: string[];
    defaultCapacityProviderStrategy: CapacityProviderStrategyItem[];
}
export declare const PutClusterCapacityProvidersRequest: S.Schema<PutClusterCapacityProvidersRequest>;
export interface PutClusterCapacityProvidersResponse {
    cluster?: Cluster;
}
export declare const PutClusterCapacityProvidersResponse: S.Schema<PutClusterCapacityProvidersResponse>;
export type PlatformDeviceType = "GPU" | "NEURON_DEVICE" | (string & {});
export declare const PlatformDeviceType: any;
export interface PlatformDevice {
    id: string;
    type: PlatformDeviceType;
}
export declare const PlatformDevice: S.Schema<PlatformDevice>;
export type PlatformDevices = PlatformDevice[];
export declare const PlatformDevices: any;
export interface RegisterContainerInstanceRequest {
    cluster?: string;
    instanceIdentityDocument?: string;
    instanceIdentityDocumentSignature?: string;
    totalResources?: Resource[];
    versionInfo?: VersionInfo;
    containerInstanceArn?: string;
    attributes?: Attribute[];
    platformDevices?: PlatformDevice[];
    tags?: Tag[];
}
export declare const RegisterContainerInstanceRequest: S.Schema<RegisterContainerInstanceRequest>;
export interface RegisterContainerInstanceResponse {
    containerInstance?: ContainerInstance;
}
export declare const RegisterContainerInstanceResponse: S.Schema<RegisterContainerInstanceResponse>;
export interface RegisterDaemonTaskDefinitionRequest {
    family: string;
    taskRoleArn?: string;
    executionRoleArn?: string;
    containerDefinitions: DaemonContainerDefinition[];
    cpu?: string;
    memory?: string;
    volumes?: DaemonVolume[];
    tags?: Tag[];
    pidMode?: DaemonPidMode;
    ipcMode?: DaemonIpcMode;
}
export declare const RegisterDaemonTaskDefinitionRequest: S.Schema<RegisterDaemonTaskDefinitionRequest>;
export interface RegisterDaemonTaskDefinitionResponse {
    daemonTaskDefinitionArn?: string;
}
export declare const RegisterDaemonTaskDefinitionResponse: S.Schema<RegisterDaemonTaskDefinitionResponse>;
export interface RegisterTaskDefinitionRequest {
    family: string;
    taskRoleArn?: string;
    executionRoleArn?: string;
    networkMode?: NetworkMode;
    containerDefinitions: ContainerDefinition[];
    volumes?: Volume[];
    placementConstraints?: TaskDefinitionPlacementConstraint[];
    requiresCompatibilities?: Compatibility[];
    cpu?: string;
    memory?: string;
    tags?: Tag[];
    pidMode?: PidMode;
    ipcMode?: IpcMode;
    proxyConfiguration?: ProxyConfiguration;
    inferenceAccelerators?: InferenceAccelerator[];
    ephemeralStorage?: EphemeralStorage;
    runtimePlatform?: RuntimePlatform;
    enableFaultInjection?: boolean;
}
export declare const RegisterTaskDefinitionRequest: S.Schema<RegisterTaskDefinitionRequest>;
export interface RegisterTaskDefinitionResponse {
    taskDefinition?: TaskDefinition;
    tags?: Tag[];
}
export declare const RegisterTaskDefinitionResponse: S.Schema<RegisterTaskDefinitionResponse>;
export interface TaskManagedEBSVolumeTerminationPolicy {
    deleteOnTermination: boolean;
}
export declare const TaskManagedEBSVolumeTerminationPolicy: S.Schema<TaskManagedEBSVolumeTerminationPolicy>;
export interface TaskManagedEBSVolumeConfiguration {
    encrypted?: boolean;
    kmsKeyId?: string;
    volumeType?: string;
    sizeInGiB?: number;
    snapshotId?: string;
    volumeInitializationRate?: number;
    iops?: number;
    throughput?: number;
    tagSpecifications?: EBSTagSpecification[];
    roleArn: string;
    terminationPolicy?: TaskManagedEBSVolumeTerminationPolicy;
    filesystemType?: TaskFilesystemType;
}
export declare const TaskManagedEBSVolumeConfiguration: S.Schema<TaskManagedEBSVolumeConfiguration>;
export interface TaskVolumeConfiguration {
    name: string;
    managedEBSVolume?: TaskManagedEBSVolumeConfiguration;
}
export declare const TaskVolumeConfiguration: S.Schema<TaskVolumeConfiguration>;
export type TaskVolumeConfigurations = TaskVolumeConfiguration[];
export declare const TaskVolumeConfigurations: any;
export interface RunTaskRequest {
    capacityProviderStrategy?: CapacityProviderStrategyItem[];
    cluster?: string;
    count?: number;
    enableECSManagedTags?: boolean;
    enableExecuteCommand?: boolean;
    group?: string;
    launchType?: LaunchType;
    networkConfiguration?: NetworkConfiguration;
    overrides?: TaskOverride;
    placementConstraints?: PlacementConstraint[];
    placementStrategy?: PlacementStrategy[];
    platformVersion?: string;
    propagateTags?: PropagateTags;
    referenceId?: string;
    startedBy?: string;
    tags?: Tag[];
    taskDefinition: string;
    clientToken?: string;
    volumeConfigurations?: TaskVolumeConfiguration[];
}
export declare const RunTaskRequest: S.Schema<RunTaskRequest>;
export interface RunTaskResponse {
    tasks?: Task[];
    failures?: Failure[];
}
export declare const RunTaskResponse: S.Schema<RunTaskResponse>;
export interface StartTaskRequest {
    cluster?: string;
    containerInstances: string[];
    enableECSManagedTags?: boolean;
    enableExecuteCommand?: boolean;
    group?: string;
    networkConfiguration?: NetworkConfiguration;
    overrides?: TaskOverride;
    propagateTags?: PropagateTags;
    referenceId?: string;
    startedBy?: string;
    tags?: Tag[];
    taskDefinition: string;
    volumeConfigurations?: TaskVolumeConfiguration[];
}
export declare const StartTaskRequest: S.Schema<StartTaskRequest>;
export interface StartTaskResponse {
    tasks?: Task[];
    failures?: Failure[];
}
export declare const StartTaskResponse: S.Schema<StartTaskResponse>;
export type StopServiceDeploymentStopType = "ABORT" | "ROLLBACK" | (string & {});
export declare const StopServiceDeploymentStopType: any;
export interface StopServiceDeploymentRequest {
    serviceDeploymentArn: string;
    stopType?: StopServiceDeploymentStopType;
}
export declare const StopServiceDeploymentRequest: S.Schema<StopServiceDeploymentRequest>;
export interface StopServiceDeploymentResponse {
    serviceDeploymentArn?: string;
}
export declare const StopServiceDeploymentResponse: S.Schema<StopServiceDeploymentResponse>;
export interface StopTaskRequest {
    cluster?: string;
    task: string;
    reason?: string;
}
export declare const StopTaskRequest: S.Schema<StopTaskRequest>;
export interface StopTaskResponse {
    task?: Task;
}
export declare const StopTaskResponse: S.Schema<StopTaskResponse>;
export interface AttachmentStateChange {
    attachmentArn: string;
    status: string;
}
export declare const AttachmentStateChange: S.Schema<AttachmentStateChange>;
export type AttachmentStateChanges = AttachmentStateChange[];
export declare const AttachmentStateChanges: any;
export interface SubmitAttachmentStateChangesRequest {
    cluster?: string;
    attachments: AttachmentStateChange[];
}
export declare const SubmitAttachmentStateChangesRequest: S.Schema<SubmitAttachmentStateChangesRequest>;
export interface SubmitAttachmentStateChangesResponse {
    acknowledgment?: string;
}
export declare const SubmitAttachmentStateChangesResponse: S.Schema<SubmitAttachmentStateChangesResponse>;
export interface SubmitContainerStateChangeRequest {
    cluster?: string;
    task?: string;
    containerName?: string;
    runtimeId?: string;
    status?: string;
    exitCode?: number;
    reason?: string;
    networkBindings?: NetworkBinding[];
}
export declare const SubmitContainerStateChangeRequest: S.Schema<SubmitContainerStateChangeRequest>;
export interface SubmitContainerStateChangeResponse {
    acknowledgment?: string;
}
export declare const SubmitContainerStateChangeResponse: S.Schema<SubmitContainerStateChangeResponse>;
export interface ContainerStateChange {
    containerName?: string;
    imageDigest?: string;
    runtimeId?: string;
    exitCode?: number;
    networkBindings?: NetworkBinding[];
    reason?: string;
    status?: string;
}
export declare const ContainerStateChange: S.Schema<ContainerStateChange>;
export type ContainerStateChanges = ContainerStateChange[];
export declare const ContainerStateChanges: any;
export interface ManagedAgentStateChange {
    containerName: string;
    managedAgentName: ManagedAgentName;
    status: string;
    reason?: string;
}
export declare const ManagedAgentStateChange: S.Schema<ManagedAgentStateChange>;
export type ManagedAgentStateChanges = ManagedAgentStateChange[];
export declare const ManagedAgentStateChanges: any;
export interface SubmitTaskStateChangeRequest {
    cluster?: string;
    task?: string;
    status?: string;
    reason?: string;
    containers?: ContainerStateChange[];
    attachments?: AttachmentStateChange[];
    managedAgents?: ManagedAgentStateChange[];
    pullStartedAt?: Date;
    pullStoppedAt?: Date;
    executionStoppedAt?: Date;
}
export declare const SubmitTaskStateChangeRequest: S.Schema<SubmitTaskStateChangeRequest>;
export interface SubmitTaskStateChangeResponse {
    acknowledgment?: string;
}
export declare const SubmitTaskStateChangeResponse: S.Schema<SubmitTaskStateChangeResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface AutoScalingGroupProviderUpdate {
    managedScaling?: ManagedScaling;
    managedTerminationProtection?: ManagedTerminationProtection;
    managedDraining?: ManagedDraining;
}
export declare const AutoScalingGroupProviderUpdate: S.Schema<AutoScalingGroupProviderUpdate>;
export interface InstanceLaunchTemplateUpdate {
    ec2InstanceProfileArn?: string;
    networkConfiguration?: ManagedInstancesNetworkConfiguration;
    storageConfiguration?: ManagedInstancesStorageConfiguration;
    instanceMetadataTagsPropagation?: boolean;
    localStorageConfiguration?: ManagedInstancesLocalStorageConfiguration;
    monitoring?: ManagedInstancesMonitoringOptions;
    instanceRequirements?: InstanceRequirementsRequest;
    capacityReservations?: CapacityReservationRequest;
}
export declare const InstanceLaunchTemplateUpdate: S.Schema<InstanceLaunchTemplateUpdate>;
export interface UpdateManagedInstancesProviderConfiguration {
    infrastructureRoleArn: string;
    instanceLaunchTemplate: InstanceLaunchTemplateUpdate;
    propagateTags?: PropagateMITags;
    infrastructureOptimization?: InfrastructureOptimization;
    autoRepairConfiguration?: AutoRepairConfiguration;
}
export declare const UpdateManagedInstancesProviderConfiguration: S.Schema<UpdateManagedInstancesProviderConfiguration>;
export interface UpdateCapacityProviderRequest {
    name: string;
    cluster?: string;
    autoScalingGroupProvider?: AutoScalingGroupProviderUpdate;
    managedInstancesProvider?: UpdateManagedInstancesProviderConfiguration;
}
export declare const UpdateCapacityProviderRequest: S.Schema<UpdateCapacityProviderRequest>;
export interface UpdateCapacityProviderResponse {
    capacityProvider?: CapacityProvider;
}
export declare const UpdateCapacityProviderResponse: S.Schema<UpdateCapacityProviderResponse>;
export interface UpdateClusterRequest {
    cluster: string;
    settings?: ClusterSetting[];
    configuration?: ClusterConfiguration;
    serviceConnectDefaults?: ClusterServiceConnectDefaultsRequest;
}
export declare const UpdateClusterRequest: S.Schema<UpdateClusterRequest>;
export interface UpdateClusterResponse {
    cluster?: Cluster;
}
export declare const UpdateClusterResponse: S.Schema<UpdateClusterResponse>;
export interface UpdateClusterSettingsRequest {
    cluster: string;
    settings: ClusterSetting[];
}
export declare const UpdateClusterSettingsRequest: S.Schema<UpdateClusterSettingsRequest>;
export interface UpdateClusterSettingsResponse {
    cluster?: Cluster;
}
export declare const UpdateClusterSettingsResponse: S.Schema<UpdateClusterSettingsResponse>;
export interface UpdateContainerAgentRequest {
    cluster?: string;
    containerInstance: string;
}
export declare const UpdateContainerAgentRequest: S.Schema<UpdateContainerAgentRequest>;
export interface UpdateContainerAgentResponse {
    containerInstance?: ContainerInstance;
}
export declare const UpdateContainerAgentResponse: S.Schema<UpdateContainerAgentResponse>;
export interface UpdateContainerInstancesStateRequest {
    cluster?: string;
    containerInstances: string[];
    status: ContainerInstanceStatus;
}
export declare const UpdateContainerInstancesStateRequest: S.Schema<UpdateContainerInstancesStateRequest>;
export interface UpdateContainerInstancesStateResponse {
    containerInstances?: ContainerInstance[];
    failures?: Failure[];
}
export declare const UpdateContainerInstancesStateResponse: S.Schema<UpdateContainerInstancesStateResponse>;
export interface UpdateDaemonRequest {
    daemonArn: string;
    daemonTaskDefinitionArn: string;
    capacityProviderArns: string[];
    deploymentConfiguration?: DaemonDeploymentConfiguration;
    propagateTags?: DaemonPropagateTags;
    enableECSManagedTags?: boolean;
    enableExecuteCommand?: boolean;
}
export declare const UpdateDaemonRequest: S.Schema<UpdateDaemonRequest>;
export interface UpdateDaemonResponse {
    daemonArn?: string;
    status?: DaemonStatus;
    createdAt?: Date;
    updatedAt?: Date;
    deploymentArn?: string;
}
export declare const UpdateDaemonResponse: S.Schema<UpdateDaemonResponse>;
export interface UpdateExpressGatewayServiceRequest {
    serviceArn: string;
    executionRoleArn?: string;
    healthCheckPath?: string;
    primaryContainer?: ExpressGatewayContainer;
    taskRoleArn?: string;
    networkConfiguration?: ExpressGatewayServiceNetworkConfiguration;
    cpu?: string;
    memory?: string;
    scalingTarget?: ExpressGatewayScalingTarget;
    taskDefinitionArn?: string;
}
export declare const UpdateExpressGatewayServiceRequest: S.Schema<UpdateExpressGatewayServiceRequest>;
export interface UpdatedExpressGatewayService {
    serviceArn?: string;
    cluster?: string;
    serviceName?: string;
    status?: ExpressGatewayServiceStatus;
    targetConfiguration?: ExpressGatewayServiceConfiguration;
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const UpdatedExpressGatewayService: S.Schema<UpdatedExpressGatewayService>;
export interface UpdateExpressGatewayServiceResponse {
    service?: UpdatedExpressGatewayService;
}
export declare const UpdateExpressGatewayServiceResponse: S.Schema<UpdateExpressGatewayServiceResponse>;
export interface UpdateServiceRequest {
    cluster?: string;
    service: string;
    desiredCount?: number;
    taskDefinition?: string;
    capacityProviderStrategy?: CapacityProviderStrategyItem[];
    deploymentConfiguration?: DeploymentConfiguration;
    availabilityZoneRebalancing?: AvailabilityZoneRebalancing;
    networkConfiguration?: NetworkConfiguration;
    placementConstraints?: PlacementConstraint[];
    placementStrategy?: PlacementStrategy[];
    platformVersion?: string;
    forceNewDeployment?: boolean;
    healthCheckGracePeriodSeconds?: number;
    deploymentController?: DeploymentController;
    enableExecuteCommand?: boolean;
    enableECSManagedTags?: boolean;
    loadBalancers?: LoadBalancer[];
    propagateTags?: PropagateTags;
    serviceRegistries?: ServiceRegistry[];
    serviceConnectConfiguration?: ServiceConnectConfiguration;
    volumeConfigurations?: ServiceVolumeConfiguration[];
    vpcLatticeConfigurations?: VpcLatticeConfiguration[];
    monitoring?: MonitoringConfiguration;
}
export declare const UpdateServiceRequest: S.Schema<UpdateServiceRequest>;
export interface UpdateServiceResponse {
    service?: Service;
}
export declare const UpdateServiceResponse: S.Schema<UpdateServiceResponse>;
export interface UpdateServicePrimaryTaskSetRequest {
    cluster: string;
    service: string;
    primaryTaskSet: string;
}
export declare const UpdateServicePrimaryTaskSetRequest: S.Schema<UpdateServicePrimaryTaskSetRequest>;
export interface UpdateServicePrimaryTaskSetResponse {
    taskSet?: TaskSet;
}
export declare const UpdateServicePrimaryTaskSetResponse: S.Schema<UpdateServicePrimaryTaskSetResponse>;
export interface UpdateTaskProtectionRequest {
    cluster: string;
    tasks: string[];
    protectionEnabled: boolean;
    expiresInMinutes?: number;
}
export declare const UpdateTaskProtectionRequest: S.Schema<UpdateTaskProtectionRequest>;
export interface UpdateTaskProtectionResponse {
    protectedTasks?: ProtectedTask[];
    failures?: Failure[];
}
export declare const UpdateTaskProtectionResponse: S.Schema<UpdateTaskProtectionResponse>;
export interface UpdateTaskSetRequest {
    cluster: string;
    service: string;
    taskSet: string;
    scale: Scale;
}
export declare const UpdateTaskSetRequest: S.Schema<UpdateTaskSetRequest>;
export interface UpdateTaskSetResponse {
    taskSet?: TaskSet;
}
export declare const UpdateTaskSetResponse: S.Schema<UpdateTaskSetResponse>;
export type ResourceIds = string[];
export declare const ResourceIds: any;
export type ContinueServiceDeploymentError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | ServiceDeploymentNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Continues or rolls back an Amazon ECS service deployment that is paused at a lifecycle hook.
 *
 * When a service deployment reaches a lifecycle stage that has a `PAUSE` hook configured, the deployment pauses and waits for an explicit action. Use this API to either continue the deployment to the next stage or roll back to the previous service revision.
 *
 * To find the `hookId` of the paused hook, call DescribeServiceDeployments and inspect the `lifecycleHookDetails` field.
 *
 * For more information, see Continuing Amazon ECS service deployments in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const continueServiceDeployment: API.OperationMethod<ContinueServiceDeploymentRequest, ContinueServiceDeploymentResponse, ContinueServiceDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateCapacityProviderError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | LimitExceededException | ServerException | UnsupportedFeatureException | UpdateInProgressException | CommonErrors;
/**
 * Creates a capacity provider. Capacity providers are associated with a cluster and are used in capacity provider strategies to facilitate cluster auto scaling. You can create capacity providers for Amazon ECS Managed Instances and EC2 instances. Fargate has the predefined `FARGATE` and `FARGATE_SPOT` capacity providers.
 */
export declare const createCapacityProvider: API.OperationMethod<CreateCapacityProviderRequest, CreateCapacityProviderResponse, CreateCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type CreateClusterError = AccessDeniedException | ClientException | InvalidParameterException | NamespaceNotFoundException | ServerException | CommonErrors;
/**
 * Creates a new Amazon ECS cluster. By default, your account receives a `default` cluster when you launch your first container instance. However, you can create your own cluster with a unique name.
 *
 * When you call the CreateCluster API operation, Amazon ECS attempts to create the Amazon ECS service-linked role for your account. This is so that it can manage required resources in other Amazon Web Services services on your behalf. However, if the user that makes the call doesn't have permissions to create the service-linked role, it isn't created. For more information, see Using service-linked roles for Amazon ECS in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const createCluster: API.OperationMethod<CreateClusterRequest, CreateClusterResponse, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateDaemonError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | PlatformUnknownException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Creates a new daemon in the specified cluster and capacity providers. A daemon deploys cross-cutting software agents such as security monitoring, telemetry, and logging independently across your Amazon ECS infrastructure.
 *
 * Amazon ECS deploys exactly one daemon task on each container instance of the specified capacity providers. When a container instance registers with the cluster, Amazon ECS automatically starts daemon tasks. Amazon ECS starts a daemon task before scheduling other tasks.
 *
 * Daemons are essential for instance health - if a daemon task stops, Amazon ECS automatically drains and replaces that container instance.
 *
 * ECS Managed Daemons is only supported for Amazon ECS Managed Instances Capacity Providers.
 */
export declare const createDaemon: API.OperationMethod<CreateDaemonRequest, CreateDaemonResponse, CreateDaemonError, Credentials | HttpClient.HttpClient>;
export type CreateExpressGatewayServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | PlatformTaskDefinitionIncompatibilityException | PlatformUnknownException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Creates an Express service that simplifies deploying containerized web applications on Amazon ECS with managed Amazon Web Services infrastructure. This operation provisions and configures Application Load Balancers, target groups, security groups, and auto-scaling policies automatically.
 *
 * Specify a primary container configuration with your application image and basic settings. Amazon ECS creates the necessary Amazon Web Services resources for traffic distribution, health monitoring, network access control, and capacity management.
 *
 * Provide an execution role for task operations and an infrastructure role for managing Amazon Web Services resources on your behalf.
 */
export declare const createExpressGatewayService: API.OperationMethod<CreateExpressGatewayServiceRequest, CreateExpressGatewayServiceResponse, CreateExpressGatewayServiceError, Credentials | HttpClient.HttpClient>;
export type CreateServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | NamespaceNotFoundException | PlatformTaskDefinitionIncompatibilityException | PlatformUnknownException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Runs and maintains your desired number of tasks from a specified task definition. If the number of tasks running in a service drops below the `desiredCount`, Amazon ECS runs another copy of the task in the specified cluster. To update an existing service, use UpdateService.
 *
 * On March 21, 2024, a change was made to resolve the task definition revision before authorization. When a task definition revision is not specified, authorization will occur using the latest revision of a task definition.
 *
 * Amazon Elastic Inference (EI) is no longer available to customers.
 *
 * In addition to maintaining the desired count of tasks in your service, you can optionally run your service behind one or more load balancers. The load balancers distribute traffic across the tasks that are associated with the service. For more information, see Service load balancing in the *Amazon Elastic Container Service Developer Guide*.
 *
 * You can attach Amazon EBS volumes to Amazon ECS tasks by configuring the volume when creating or updating a service. `volumeConfigurations` is only supported for REPLICA service and not DAEMON service. For more information, see Amazon EBS volumes in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Tasks for services that don't use a load balancer are considered healthy if they're in the `RUNNING` state. Tasks for services that use a load balancer are considered healthy if they're in the `RUNNING` state and are reported as healthy by the load balancer.
 *
 * There are two service scheduler strategies available:
 *
 * - `REPLICA` - The replica scheduling strategy places and maintains your desired number of tasks across your cluster. By default, the service scheduler spreads tasks across Availability Zones. You can use task placement strategies and constraints to customize task placement decisions. For more information, see Service scheduler concepts in the *Amazon Elastic Container Service Developer Guide*.
 *
 * - `DAEMON` - The daemon scheduling strategy deploys exactly one task on each active container instance that meets all of the task placement constraints that you specify in your cluster. The service scheduler also evaluates the task placement constraints for running tasks. It also stops tasks that don't meet the placement constraints. When using this strategy, you don't need to specify a desired number of tasks, a task placement strategy, or use Service Auto Scaling policies. For more information, see Amazon ECS services in the *Amazon Elastic Container Service Developer Guide*.
 *
 * The deployment controller is the mechanism that determines how tasks are deployed for your service. The valid options are:
 *
 * - ECS
 *
 * When you create a service which uses the `ECS` deployment controller, you can choose between the following deployment strategies (which you can set in the “`strategy`” field in “`deploymentConfiguration`”): :
 *
 * - `ROLLING`: When you create a service which uses the *rolling update* (`ROLLING`) deployment strategy, the Amazon ECS service scheduler replaces the currently running tasks with new tasks. The number of tasks that Amazon ECS adds or removes from the service during a rolling update is controlled by the service deployment configuration. For more information, see Deploy Amazon ECS services by replacing tasks in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Rolling update deployments are best suited for the following scenarios:
 *
 * - Gradual service updates: You need to update your service incrementally without taking the entire service offline at once.
 *
 * - Limited resource requirements: You want to avoid the additional resource costs of running two complete environments simultaneously (as required by blue/green deployments).
 *
 * - Acceptable deployment time: Your application can tolerate a longer deployment process, as rolling updates replace tasks one by one.
 *
 * - No need for instant roll back: Your service can tolerate a rollback process that takes minutes rather than seconds.
 *
 * - Simple deployment process: You prefer a straightforward deployment approach without the complexity of managing multiple environments, target groups, and listeners.
 *
 * - No load balancer requirement: Your service doesn't use or require a load balancer, Application Load Balancer, Network Load Balancer, or Service Connect (which are required for blue/green deployments).
 *
 * - Stateful applications: Your application maintains state that makes it difficult to run two parallel environments.
 *
 * - Cost sensitivity: You want to minimize deployment costs by not running duplicate environments during deployment.
 *
 * Rolling updates are the default deployment strategy for services and provide a balance between deployment safety and resource efficiency for many common application scenarios.
 *
 * - `BLUE_GREEN`: A *blue/green* deployment strategy (`BLUE_GREEN`) is a release methodology that reduces downtime and risk by running two identical production environments called blue and green. With Amazon ECS blue/green deployments, you can validate new service revisions before directing production traffic to them. This approach provides a safer way to deploy changes with the ability to quickly roll back if needed. For more information, see Amazon ECS blue/green deployments in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Amazon ECS blue/green deployments are best suited for the following scenarios:
 *
 * - Service validation: When you need to validate new service revisions before directing production traffic to them
 *
 * - Zero downtime: When your service requires zero-downtime deployments
 *
 * - Instant roll back: When you need the ability to quickly roll back if issues are detected
 *
 * - Load balancer requirement: When your service uses Application Load Balancer, Network Load Balancer, or Service Connect
 *
 * - `LINEAR`: A *linear* deployment strategy (`LINEAR`) gradually shifts traffic from the current production environment to a new environment in equal percentage increments. With Amazon ECS linear deployments, you can control the pace of traffic shifting and validate new service revisions with increasing amounts of production traffic.
 *
 * Linear deployments are best suited for the following scenarios:
 *
 * - Gradual validation: When you want to gradually validate your new service version with increasing traffic
 *
 * - Performance monitoring: When you need time to monitor metrics and performance during the deployment
 *
 * - Risk minimization: When you want to minimize risk by exposing the new version to production traffic incrementally
 *
 * - Load balancer requirement: When your service uses Application Load Balancer or Service Connect
 *
 * - `CANARY`: A *canary* deployment strategy (`CANARY`) shifts a small percentage of traffic to the new service revision first, then shifts the remaining traffic all at once after a specified time period. This allows you to test the new version with a subset of users before full deployment.
 *
 * Canary deployments are best suited for the following scenarios:
 *
 * - Feature testing: When you want to test new features with a small subset of users before full rollout
 *
 * - Production validation: When you need to validate performance and functionality with real production traffic
 *
 * - Blast radius control: When you want to minimize blast radius if issues are discovered in the new version
 *
 * - Load balancer requirement: When your service uses Application Load Balancer or Service Connect
 *
 * - External
 *
 * Use a third-party deployment controller.
 *
 * - Blue/green deployment (powered by CodeDeploy)
 *
 * CodeDeploy installs an updated version of the application as a new replacement task set and reroutes production traffic from the original application task set to the replacement task set. The original task set is terminated after a successful deployment. Use this deployment controller to verify a new deployment of a service before sending production traffic to it.
 *
 * When creating a service that uses the `EXTERNAL` deployment controller, you can specify only parameters that aren't controlled at the task set level. The only required parameter is the service name. You control your services using the CreateTaskSet. For more information, see Amazon ECS deployment types in the *Amazon Elastic Container Service Developer Guide*.
 *
 * When the service scheduler launches new tasks, it determines task placement. For information about task placement and task placement strategies, see Amazon ECS task placement in the *Amazon Elastic Container Service Developer Guide*
 */
export declare const createService: API.OperationMethod<CreateServiceRequest, CreateServiceResponse, CreateServiceError, Credentials | HttpClient.HttpClient>;
export type CreateTaskSetError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | LimitExceededException | NamespaceNotFoundException | PlatformTaskDefinitionIncompatibilityException | PlatformUnknownException | ServerException | ServiceNotActiveException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Create a task set in the specified cluster and service. This is used when a service uses the `EXTERNAL` deployment controller type. For more information, see Amazon ECS deployment types in the *Amazon Elastic Container Service Developer Guide*.
 *
 * On March 21, 2024, a change was made to resolve the task definition revision before authorization. When a task definition revision is not specified, authorization will occur using the latest revision of a task definition.
 *
 * For information about the maximum number of task sets and other quotas, see Amazon ECS service quotas in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const createTaskSet: API.OperationMethod<CreateTaskSetRequest, CreateTaskSetResponse, CreateTaskSetError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountSettingError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Disables an account setting for a specified user, role, or the root user for an account.
 */
export declare const deleteAccountSetting: API.OperationMethod<DeleteAccountSettingRequest, DeleteAccountSettingResponse, DeleteAccountSettingError, Credentials | HttpClient.HttpClient>;
export type DeleteAttributesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | TargetNotFoundException | CommonErrors;
/**
 * Deletes one or more custom attributes from an Amazon ECS resource.
 */
export declare const deleteAttributes: API.OperationMethod<DeleteAttributesRequest, DeleteAttributesResponse, DeleteAttributesError, Credentials | HttpClient.HttpClient>;
export type DeleteCapacityProviderError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | UpdateInProgressException | CommonErrors;
/**
 * Deletes the specified capacity provider.
 *
 * The `FARGATE` and `FARGATE_SPOT` capacity providers are reserved and can't be deleted. You can disassociate them from a cluster using either PutClusterCapacityProviders or by deleting the cluster.
 *
 * Prior to a capacity provider being deleted, the capacity provider must be removed from the capacity provider strategy from all services. The UpdateService API can be used to remove a capacity provider from a service's capacity provider strategy. When updating a service, the `forceNewDeployment` option can be used to ensure that any tasks using the Amazon EC2 instance capacity provided by the capacity provider are transitioned to use the capacity from the remaining capacity providers. Only capacity providers that aren't associated with a cluster can be deleted. To remove a capacity provider from a cluster, you can either use PutClusterCapacityProviders or delete the cluster.
 */
export declare const deleteCapacityProvider: API.OperationMethod<DeleteCapacityProviderRequest, DeleteCapacityProviderResponse, DeleteCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = AccessDeniedException | ClientException | ClusterContainsCapacityProviderException | ClusterContainsContainerInstancesException | ClusterContainsServicesException | ClusterContainsTasksException | ClusterNotFoundException | InvalidParameterException | ServerException | UpdateInProgressException | CommonErrors;
/**
 * Deletes the specified cluster. The cluster transitions to the `INACTIVE` state. Clusters with an `INACTIVE` status might remain discoverable in your account for a period of time. However, this behavior is subject to change in the future. We don't recommend that you rely on `INACTIVE` clusters persisting.
 *
 * You must deregister all container instances from this cluster before you may delete it. You can list the container instances in a cluster with ListContainerInstances and deregister them with DeregisterContainerInstance.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterRequest, DeleteClusterResponse, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteDaemonError = AccessDeniedException | ClientException | ClusterNotFoundException | DaemonNotActiveException | DaemonNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Deletes the specified daemon. The daemon must be in an `ACTIVE` state to be deleted. Deleting a daemon stops all running daemon tasks on the associated container instances. Amazon ECS drains existing container instances and provisions new instances without the deleted daemon. Amazon ECS automatically launches replacement tasks for your Amazon ECS services.
 *
 * ECS Managed Daemons is only supported for Amazon ECS Managed Instances Capacity Providers.
 */
export declare const deleteDaemon: API.OperationMethod<DeleteDaemonRequest, DeleteDaemonResponse, DeleteDaemonError, Credentials | HttpClient.HttpClient>;
export type DeleteDaemonTaskDefinitionError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Deletes the specified daemon task definition. After a daemon task definition is deleted, no new daemons can be created using this definition. Existing daemons that reference the deleted daemon task definition continue to run.
 *
 * A daemon task definition must be in an `ACTIVE` state to be deleted.
 */
export declare const deleteDaemonTaskDefinition: API.OperationMethod<DeleteDaemonTaskDefinitionRequest, DeleteDaemonTaskDefinitionResponse, DeleteDaemonTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteExpressGatewayServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotActiveException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Deletes an Express service and removes all associated Amazon Web Services resources. This operation stops service tasks, removes the Application Load Balancer, target groups, security groups, auto-scaling policies, and other managed infrastructure components.
 *
 * The service enters a `DRAINING` state where existing tasks complete current requests without starting new tasks. After all tasks stop, the service and infrastructure are permanently removed.
 *
 * This operation cannot be reversed. Back up important data and verify the service is no longer needed before deletion.
 */
export declare const deleteExpressGatewayService: API.OperationMethod<DeleteExpressGatewayServiceRequest, DeleteExpressGatewayServiceResponse, DeleteExpressGatewayServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotFoundException | CommonErrors;
/**
 * Deletes a specified service within a cluster. You can delete a service if you have no running tasks in it and the desired task count is zero. If the service is actively maintaining tasks, you can't delete it, and you must update the service to a desired task count of zero. For more information, see UpdateService.
 *
 * When you delete a service, if there are still running tasks that require cleanup, the service status moves from `ACTIVE` to `DRAINING`, and the service is no longer visible in the console or in the ListServices API operation. After all tasks have transitioned to either `STOPPING` or `STOPPED` status, the service status moves from `DRAINING` to `INACTIVE`. Services in the `DRAINING` or `INACTIVE` status can still be viewed with the DescribeServices API operation. However, in the future, `INACTIVE` services may be cleaned up and purged from Amazon ECS record keeping, and DescribeServices calls on those services return a `ServiceNotFoundException` error.
 *
 * If you attempt to create a new service with the same name as an existing service in either `ACTIVE` or `DRAINING` status, you receive an error.
 */
export declare const deleteService: API.OperationMethod<DeleteServiceRequest, DeleteServiceResponse, DeleteServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteTaskDefinitionsError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Deletes one or more task definitions.
 *
 * You must deregister a task definition revision before you delete it. For more information, see DeregisterTaskDefinition.
 *
 * When you delete a task definition revision, it is immediately transitions from the `INACTIVE` to `DELETE_IN_PROGRESS`. Existing tasks and services that reference a `DELETE_IN_PROGRESS` task definition revision continue to run without disruption. Existing services that reference a `DELETE_IN_PROGRESS` task definition revision can still scale up or down by modifying the service's desired count.
 *
 * You can't use a `DELETE_IN_PROGRESS` task definition revision to run new tasks or create new services. You also can't update an existing service to reference a `DELETE_IN_PROGRESS` task definition revision.
 *
 * A task definition revision will stay in `DELETE_IN_PROGRESS` status until all the associated tasks and services have been terminated.
 *
 * When you delete all `INACTIVE` task definition revisions, the task definition name is not displayed in the console and not returned in the API. If a task definition revisions are in the `DELETE_IN_PROGRESS` state, the task definition name is displayed in the console and returned in the API. The task definition name is retained by Amazon ECS and the revision is incremented the next time you create a task definition with that name.
 */
export declare const deleteTaskDefinitions: API.OperationMethod<DeleteTaskDefinitionsRequest, DeleteTaskDefinitionsResponse, DeleteTaskDefinitionsError, Credentials | HttpClient.HttpClient>;
export type DeleteTaskSetError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | LimitExceededException | ServerException | ServiceNotActiveException | ServiceNotFoundException | TaskSetNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Deletes a specified task set within a service. This is used when a service uses the `EXTERNAL` deployment controller type. For more information, see Amazon ECS deployment types in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const deleteTaskSet: API.OperationMethod<DeleteTaskSetRequest, DeleteTaskSetResponse, DeleteTaskSetError, Credentials | HttpClient.HttpClient>;
export type DeregisterContainerInstanceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Deregisters an Amazon ECS container instance from the specified cluster. This instance is no longer available to run tasks.
 *
 * If you intend to use the container instance for some other purpose after deregistration, we recommend that you stop all of the tasks running on the container instance before deregistration. That prevents any orphaned tasks from consuming resources.
 *
 * Deregistering a container instance removes the instance from a cluster, but it doesn't terminate the EC2 instance. If you are finished using the instance, be sure to terminate it in the Amazon EC2 console to stop billing.
 *
 * If you terminate a running container instance, Amazon ECS automatically deregisters the instance from your cluster (stopped container instances or instances with disconnected agents aren't automatically deregistered when terminated).
 */
export declare const deregisterContainerInstance: API.OperationMethod<DeregisterContainerInstanceRequest, DeregisterContainerInstanceResponse, DeregisterContainerInstanceError, Credentials | HttpClient.HttpClient>;
export type DeregisterTaskDefinitionError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Deregisters the specified task definition by family and revision. Upon deregistration, the task definition is marked as `INACTIVE`. Existing tasks and services that reference an `INACTIVE` task definition continue to run without disruption. Existing services that reference an `INACTIVE` task definition can still scale up or down by modifying the service's desired count. If you want to delete a task definition revision, you must first deregister the task definition revision.
 *
 * You can't use an `INACTIVE` task definition to run new tasks or create new services, and you can't update an existing service to reference an `INACTIVE` task definition. However, there may be up to a 10-minute window following deregistration where these restrictions have not yet taken effect.
 *
 * At this time, `INACTIVE` task definitions remain discoverable in your account indefinitely. However, this behavior is subject to change in the future. We don't recommend that you rely on `INACTIVE` task definitions persisting beyond the lifecycle of any associated tasks and services.
 *
 * You must deregister a task definition revision before you delete it. For more information, see DeleteTaskDefinitions.
 */
export declare const deregisterTaskDefinition: API.OperationMethod<DeregisterTaskDefinitionRequest, DeregisterTaskDefinitionResponse, DeregisterTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeCapacityProvidersError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes one or more of your capacity providers.
 */
export declare const describeCapacityProviders: API.OperationMethod<DescribeCapacityProvidersRequest, DescribeCapacityProvidersResponse, DescribeCapacityProvidersError, Credentials | HttpClient.HttpClient>;
export type DescribeClustersError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Describes one or more of your clusters.
 *
 * For CLI examples, see describe-clusters.rst on GitHub.
 */
export declare const describeClusters: API.OperationMethod<DescribeClustersRequest, DescribeClustersResponse, DescribeClustersError, Credentials | HttpClient.HttpClient>;
export type DescribeContainerInstancesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Describes one or more container instances. Returns metadata about each container instance requested.
 */
export declare const describeContainerInstances: API.OperationMethod<DescribeContainerInstancesRequest, DescribeContainerInstancesResponse, DescribeContainerInstancesError, Credentials | HttpClient.HttpClient>;
export type DescribeDaemonError = AccessDeniedException | ClientException | ClusterNotFoundException | DaemonNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes the specified daemon.
 */
export declare const describeDaemon: API.OperationMethod<DescribeDaemonRequest, DescribeDaemonResponse, DescribeDaemonError, Credentials | HttpClient.HttpClient>;
export type DescribeDaemonDeploymentsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes one or more of your daemon deployments.
 *
 * A daemon deployment orchestrates the progressive rollout of daemon task updates across container instances managed by the daemon's capacity providers. Each deployment includes circuit breaker and alarm-based rollback capabilities.
 */
export declare const describeDaemonDeployments: API.OperationMethod<DescribeDaemonDeploymentsRequest, DescribeDaemonDeploymentsResponse, DescribeDaemonDeploymentsError, Credentials | HttpClient.HttpClient>;
export type DescribeDaemonRevisionsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes one or more of your daemon revisions.
 *
 * A daemon revision is a snapshot of a daemon's configuration at the time a deployment was initiated. It captures the daemon task definition, container images, tag propagation, and execute command settings. Daemon revisions are immutable.
 */
export declare const describeDaemonRevisions: API.OperationMethod<DescribeDaemonRevisionsRequest, DescribeDaemonRevisionsResponse, DescribeDaemonRevisionsError, Credentials | HttpClient.HttpClient>;
export type DescribeDaemonTaskDefinitionError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Describes a daemon task definition. You can specify a `family` and `revision` to find information about a specific daemon task definition, or you can simply specify the family to find the latest `ACTIVE` revision in that family.
 */
export declare const describeDaemonTaskDefinition: API.OperationMethod<DescribeDaemonTaskDefinitionRequest, DescribeDaemonTaskDefinitionResponse, DescribeDaemonTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeExpressGatewayServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ResourceNotFoundException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Retrieves detailed information about an Express service, including current status, configuration, managed infrastructure, and service revisions.
 *
 * Returns comprehensive service details, active service revisions, ingress paths with endpoints, and managed Amazon Web Services resource status including load balancers and auto-scaling policies.
 *
 * Use the `include` parameter to retrieve additional information such as resource tags.
 */
export declare const describeExpressGatewayService: API.OperationMethod<DescribeExpressGatewayServiceRequest, DescribeExpressGatewayServiceResponse, DescribeExpressGatewayServiceError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceDeploymentsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes one or more of your service deployments.
 *
 * A service deployment happens when you release a software update for the service. For more information, see View service history using Amazon ECS service deployments.
 */
export declare const describeServiceDeployments: API.OperationMethod<DescribeServiceDeploymentsRequest, DescribeServiceDeploymentsResponse, DescribeServiceDeploymentsError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceRevisionsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes one or more service revisions.
 *
 * A service revision is a version of the service that includes the values for the Amazon ECS resources (for example, task definition) and the environment resources (for example, load balancers, subnets, and security groups). For more information, see Amazon ECS service revisions.
 *
 * You can't describe a service revision that was created before October 25, 2024.
 */
export declare const describeServiceRevisions: API.OperationMethod<DescribeServiceRevisionsRequest, DescribeServiceRevisionsResponse, DescribeServiceRevisionsError, Credentials | HttpClient.HttpClient>;
export type DescribeServicesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Describes the specified services running in your cluster.
 */
export declare const describeServices: API.OperationMethod<DescribeServicesRequest, DescribeServicesResponse, DescribeServicesError, Credentials | HttpClient.HttpClient>;
export type DescribeTaskDefinitionError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Describes a task definition. You can specify a `family` and `revision` to find information about a specific task definition, or you can simply specify the family to find the latest `ACTIVE` revision in that family.
 *
 * You can only describe `INACTIVE` task definitions while an active task or service references them.
 */
export declare const describeTaskDefinition: API.OperationMethod<DescribeTaskDefinitionRequest, DescribeTaskDefinitionResponse, DescribeTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeTasksError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Describes a specified task or tasks.
 *
 * Currently, stopped tasks appear in the returned results for at least one hour.
 *
 * If you have tasks with tags, and then delete the cluster, the tagged tasks are returned in the response. If you create a new cluster with the same name as the deleted cluster, the tagged tasks are not included in the response.
 */
export declare const describeTasks: API.OperationMethod<DescribeTasksRequest, DescribeTasksResponse, DescribeTasksError, Credentials | HttpClient.HttpClient>;
export type DescribeTaskSetsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotActiveException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes the task sets in the specified cluster and service. This is used when a service uses the `EXTERNAL` deployment controller type. For more information, see Amazon ECS Deployment Types in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const describeTaskSets: API.OperationMethod<DescribeTaskSetsRequest, DescribeTaskSetsResponse, DescribeTaskSetsError, Credentials | HttpClient.HttpClient>;
export type DiscoverPollEndpointError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * This action is only used by the Amazon ECS agent, and it is not intended for use outside of the agent.
 *
 * Returns an endpoint for the Amazon ECS agent to poll for updates.
 */
export declare const discoverPollEndpoint: API.OperationMethod<DiscoverPollEndpointRequest, DiscoverPollEndpointResponse, DiscoverPollEndpointError, Credentials | HttpClient.HttpClient>;
export type ExecuteCommandError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | TargetNotConnectedException | CommonErrors;
/**
 * Runs a command remotely on a container within a task.
 *
 * If you use a condition key in your IAM policy to refine the conditions for the policy statement, for example limit the actions to a specific cluster, you receive an `AccessDeniedException` when there is a mismatch between the condition key value and the corresponding parameter value.
 *
 * For information about required permissions and considerations, see Using Amazon ECS Exec for debugging in the *Amazon ECS Developer Guide*.
 */
export declare const executeCommand: API.OperationMethod<ExecuteCommandRequest, ExecuteCommandResponse, ExecuteCommandError, Credentials | HttpClient.HttpClient>;
export type GetTaskProtectionError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ResourceNotFoundException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Retrieves the protection status of tasks in an Amazon ECS service.
 */
export declare const getTaskProtection: API.OperationMethod<GetTaskProtectionRequest, GetTaskProtectionResponse, GetTaskProtectionError, Credentials | HttpClient.HttpClient>;
export type ListAccountSettingsError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Lists the account settings for a specified principal.
 */
export declare const listAccountSettings: API.PaginatedOperationMethod<ListAccountSettingsRequest, ListAccountSettingsResponse, ListAccountSettingsError, Credentials | HttpClient.HttpClient, Setting>;
export type ListAttributesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Lists the attributes for Amazon ECS resources within a specified target type and cluster. When you specify a target type and cluster, `ListAttributes` returns a list of attribute objects, one for each attribute on each resource. You can filter the list of results to a single attribute name to only return results that have that name. You can also filter the results by attribute name and value. You can do this, for example, to see which container instances in a cluster are running a Linux AMI (`ecs.os-type=linux`).
 */
export declare const listAttributes: API.PaginatedOperationMethod<ListAttributesRequest, ListAttributesResponse, ListAttributesError, Credentials | HttpClient.HttpClient, Attribute>;
export type ListClustersError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Returns a list of existing clusters.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersRequest, ListClustersResponse, ListClustersError, Credentials | HttpClient.HttpClient, string>;
export type ListContainerInstancesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Returns a list of container instances in a specified cluster. You can filter the results of a `ListContainerInstances` operation with cluster query language statements inside the `filter` parameter. For more information, see Cluster Query Language in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const listContainerInstances: API.PaginatedOperationMethod<ListContainerInstancesRequest, ListContainerInstancesResponse, ListContainerInstancesError, Credentials | HttpClient.HttpClient, string>;
export type ListDaemonDeploymentsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Returns a list of daemon deployments for a specified daemon. You can filter the results by status or creation time.
 */
export declare const listDaemonDeployments: API.OperationMethod<ListDaemonDeploymentsRequest, ListDaemonDeploymentsResponse, ListDaemonDeploymentsError, Credentials | HttpClient.HttpClient>;
export type ListDaemonsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Returns a list of daemons. You can filter the results by cluster or capacity provider.
 */
export declare const listDaemons: API.OperationMethod<ListDaemonsRequest, ListDaemonsResponse, ListDaemonsError, Credentials | HttpClient.HttpClient>;
export type ListDaemonTaskDefinitionsError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Returns a list of daemon task definitions that are registered to your account. You can filter the results by family name, status, or both to find daemon task definitions that match your criteria.
 */
export declare const listDaemonTaskDefinitions: API.OperationMethod<ListDaemonTaskDefinitionsRequest, ListDaemonTaskDefinitionsResponse, ListDaemonTaskDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListServiceDeploymentsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * This operation lists all the service deployments that meet the specified filter criteria.
 *
 * A service deployment happens when you release a software update for the service. You route traffic from the running service revisions to the new service revison and control the number of running tasks.
 *
 * This API returns the values that you use for the request parameters in DescribeServiceRevisions.
 */
export declare const listServiceDeployments: API.OperationMethod<ListServiceDeploymentsRequest, ListServiceDeploymentsResponse, ListServiceDeploymentsError, Credentials | HttpClient.HttpClient>;
export type ListServicesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Returns a list of services. You can filter the results by cluster, launch type, and scheduling strategy.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesRequest, ListServicesResponse, ListServicesError, Credentials | HttpClient.HttpClient, string>;
export type ListServicesByNamespaceError = AccessDeniedException | ClientException | InvalidParameterException | NamespaceNotFoundException | ServerException | CommonErrors;
/**
 * This operation lists all of the services that are associated with a Cloud Map namespace. This list might include services in different clusters. In contrast, `ListServices` can only list services in one cluster at a time. If you need to filter the list of services in a single cluster by various parameters, use `ListServices`. For more information, see Service Connect in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const listServicesByNamespace: API.PaginatedOperationMethod<ListServicesByNamespaceRequest, ListServicesByNamespaceResponse, ListServicesByNamespaceError, Credentials | HttpClient.HttpClient, string>;
export type ListTagsForResourceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * List the tags for an Amazon ECS resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTaskDefinitionFamiliesError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Returns a list of task definition families that are registered to your account. This list includes task definition families that no longer have any `ACTIVE` task definition revisions.
 *
 * You can filter out task definition families that don't contain any `ACTIVE` task definition revisions by setting the `status` parameter to `ACTIVE`. You can also filter the results with the `familyPrefix` parameter.
 */
export declare const listTaskDefinitionFamilies: API.PaginatedOperationMethod<ListTaskDefinitionFamiliesRequest, ListTaskDefinitionFamiliesResponse, ListTaskDefinitionFamiliesError, Credentials | HttpClient.HttpClient, string>;
export type ListTaskDefinitionsError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Returns a list of task definitions that are registered to your account. You can filter the results by family name with the `familyPrefix` parameter or by status with the `status` parameter.
 */
export declare const listTaskDefinitions: API.PaginatedOperationMethod<ListTaskDefinitionsRequest, ListTaskDefinitionsResponse, ListTaskDefinitionsError, Credentials | HttpClient.HttpClient, string>;
export type ListTasksError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotFoundException | CommonErrors;
/**
 * Returns a list of tasks. You can filter the results by cluster, task definition family, container instance, launch type, what IAM principal started the task, or by the desired status of the task.
 *
 * Recently stopped tasks might appear in the returned results.
 */
export declare const listTasks: API.PaginatedOperationMethod<ListTasksRequest, ListTasksResponse, ListTasksError, Credentials | HttpClient.HttpClient, string>;
export type PutAccountSettingError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Modifies an account setting. Account settings are set on a per-Region basis.
 *
 * If you change the root user account setting, the default settings are reset for users and roles that do not have specified individual account settings. For more information, see Account Settings in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const putAccountSetting: API.OperationMethod<PutAccountSettingRequest, PutAccountSettingResponse, PutAccountSettingError, Credentials | HttpClient.HttpClient>;
export type PutAccountSettingDefaultError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Modifies an account setting for all users on an account for whom no individual account setting has been specified. Account settings are set on a per-Region basis.
 */
export declare const putAccountSettingDefault: API.OperationMethod<PutAccountSettingDefaultRequest, PutAccountSettingDefaultResponse, PutAccountSettingDefaultError, Credentials | HttpClient.HttpClient>;
export type PutAttributesError = AccessDeniedException | AttributeLimitExceededException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | TargetNotFoundException | CommonErrors;
/**
 * Create or update an attribute on an Amazon ECS resource. If the attribute doesn't exist, it's created. If the attribute exists, its value is replaced with the specified value. To delete an attribute, use DeleteAttributes. For more information, see Attributes in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const putAttributes: API.OperationMethod<PutAttributesRequest, PutAttributesResponse, PutAttributesError, Credentials | HttpClient.HttpClient>;
export type PutClusterCapacityProvidersError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ResourceInUseException | ServerException | UpdateInProgressException | CommonErrors;
/**
 * Modifies the available capacity providers and the default capacity provider strategy for a cluster.
 *
 * You must specify both the available capacity providers and a default capacity provider strategy for the cluster. If the specified cluster has existing capacity providers associated with it, you must specify all existing capacity providers in addition to any new ones you want to add. Any existing capacity providers that are associated with a cluster that are omitted from a PutClusterCapacityProviders API call will be disassociated with the cluster. You can only disassociate an existing capacity provider from a cluster if it's not being used by any existing tasks.
 *
 * When creating a service or running a task on a cluster, if no capacity provider or launch type is specified, then the cluster's default capacity provider strategy is used. We recommend that you define a default capacity provider strategy for your cluster. However, you must specify an empty array (`[]`) to bypass defining a default strategy.
 *
 * Amazon ECS Managed Instances doesn't support this, because when you create a capacity provider with Amazon ECS Managed Instances, it becomes available only within the specified cluster.
 */
export declare const putClusterCapacityProviders: API.OperationMethod<PutClusterCapacityProvidersRequest, PutClusterCapacityProvidersResponse, PutClusterCapacityProvidersError, Credentials | HttpClient.HttpClient>;
export type RegisterContainerInstanceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * This action is only used by the Amazon ECS agent, and it is not intended for use outside of the agent.
 *
 * Registers an EC2 instance into the specified cluster. This instance becomes available to place containers on.
 */
export declare const registerContainerInstance: API.OperationMethod<RegisterContainerInstanceRequest, RegisterContainerInstanceResponse, RegisterContainerInstanceError, Credentials | HttpClient.HttpClient>;
export type RegisterDaemonTaskDefinitionError = AccessDeniedException | ClientException | InvalidParameterException | LimitExceededException | ServerException | CommonErrors;
/**
 * Registers a new daemon task definition from the supplied `family` and `containerDefinitions`. Optionally, you can add data volumes to your containers with the `volumes` parameter. For more information, see Daemon task definitions in the *Amazon Elastic Container Service Developer Guide*.
 *
 * A daemon task definition is a template that describes the containers that form a daemon. Daemons deploy cross-cutting software agents such as security monitoring, telemetry, and logging across your Amazon ECS infrastructure.
 *
 * Each time you call `RegisterDaemonTaskDefinition`, a new revision of the daemon task definition is created. You can't modify a revision after you register it.
 */
export declare const registerDaemonTaskDefinition: API.OperationMethod<RegisterDaemonTaskDefinitionRequest, RegisterDaemonTaskDefinitionResponse, RegisterDaemonTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type RegisterTaskDefinitionError = AccessDeniedException | ClientException | InvalidParameterException | LimitExceededException | ServerException | CommonErrors;
/**
 * Registers a new task definition from the supplied `family` and `containerDefinitions`. Optionally, you can add data volumes to your containers with the `volumes` parameter. For more information about task definition parameters and defaults, see Amazon ECS Task Definitions in the *Amazon Elastic Container Service Developer Guide*.
 *
 * You can specify a role for your task with the `taskRoleArn` parameter. When you specify a role for a task, its containers can then use the latest versions of the CLI or SDKs to make API requests to the Amazon Web Services services that are specified in the policy that's associated with the role. For more information, see IAM Roles for Tasks in the *Amazon Elastic Container Service Developer Guide*.
 *
 * You can specify a Docker networking mode for the containers in your task definition with the `networkMode` parameter. If you specify the `awsvpc` network mode, the task is allocated an elastic network interface, and you must specify a NetworkConfiguration when you create a service or run a task with the task definition. For more information, see Task Networking in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const registerTaskDefinition: API.OperationMethod<RegisterTaskDefinitionRequest, RegisterTaskDefinitionResponse, RegisterTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type RunTaskError = AccessDeniedException | BlockedException | ClientException | ClusterNotFoundException | ConflictException | InvalidParameterException | PlatformTaskDefinitionIncompatibilityException | PlatformUnknownException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Starts a new task using the specified task definition.
 *
 * On March 21, 2024, a change was made to resolve the task definition revision before authorization. When a task definition revision is not specified, authorization will occur using the latest revision of a task definition.
 *
 * Amazon Elastic Inference (EI) is no longer available to customers.
 *
 * You can allow Amazon ECS to place tasks for you, or you can customize how Amazon ECS places tasks using placement constraints and placement strategies. For more information, see Scheduling Tasks in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Alternatively, you can use `StartTask` to use your own scheduler or place tasks manually on specific container instances.
 *
 * You can attach Amazon EBS volumes to Amazon ECS tasks by configuring the volume when creating or updating a service. For more information, see Amazon EBS volumes in the *Amazon Elastic Container Service Developer Guide*.
 *
 * The Amazon ECS API follows an eventual consistency model. This is because of the distributed nature of the system supporting the API. This means that the result of an API command you run that affects your Amazon ECS resources might not be immediately visible to all subsequent commands you run. Keep this in mind when you carry out an API command that immediately follows a previous API command.
 *
 * To manage eventual consistency, you can do the following:
 *
 * - Confirm the state of the resource before you run a command to modify it. Run the DescribeTasks command using an exponential backoff algorithm to ensure that you allow enough time for the previous command to propagate through the system. To do this, run the DescribeTasks command repeatedly, starting with a couple of seconds of wait time and increasing gradually up to five minutes of wait time.
 *
 * - Add wait time between subsequent commands, even if the DescribeTasks command returns an accurate response. Apply an exponential backoff algorithm starting with a couple of seconds of wait time, and increase gradually up to about five minutes of wait time.
 *
 * If you get a `ConflictException` error, the `RunTask` request could not be processed due to conflicts. The provided `clientToken` is already in use with a different `RunTask` request. The `resourceIds` are the existing task ARNs which are already associated with the `clientToken`.
 *
 * To fix this issue:
 *
 * - Run `RunTask` with a unique `clientToken`.
 *
 * - Run `RunTask` with the `clientToken` and the original set of parameters
 *
 * If you get a `ClientException`error, the `RunTask` could not be processed because you use managed scaling and there is a capacity error because the quota of tasks in the `PROVISIONING` per cluster has been reached. For information about the service quotas, see Amazon ECS service quotas.
 */
export declare const runTask: API.OperationMethod<RunTaskRequest, RunTaskResponse, RunTaskError, Credentials | HttpClient.HttpClient>;
export type StartTaskError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | NamespaceNotFoundException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Starts a new task from the specified task definition on the specified container instance or instances.
 *
 * On March 21, 2024, a change was made to resolve the task definition revision before authorization. When a task definition revision is not specified, authorization will occur using the latest revision of a task definition.
 *
 * Amazon Elastic Inference (EI) is no longer available to customers.
 *
 * Alternatively, you can use`RunTask` to place tasks for you. For more information, see Scheduling Tasks in the *Amazon Elastic Container Service Developer Guide*.
 *
 * You can attach Amazon EBS volumes to Amazon ECS tasks by configuring the volume when creating or updating a service. For more information, see Amazon EBS volumes in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const startTask: API.OperationMethod<StartTaskRequest, StartTaskResponse, StartTaskError, Credentials | HttpClient.HttpClient>;
export type StopServiceDeploymentError = AccessDeniedException | ClientException | ConflictException | InvalidParameterException | ServerException | ServiceDeploymentNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Stops an ongoing service deployment.
 *
 * The following stop types are avaiable:
 *
 * - ROLLBACK - This option rolls back the service deployment to the previous service revision.
 *
 * You can use this option even if you didn't configure the service deployment for the rollback option.
 *
 * For more information, see Stopping Amazon ECS service deployments in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const stopServiceDeployment: API.OperationMethod<StopServiceDeploymentRequest, StopServiceDeploymentResponse, StopServiceDeploymentError, Credentials | HttpClient.HttpClient>;
export type StopTaskError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Stops a running task. Any tags associated with the task will be deleted.
 *
 * When you call `StopTask` on a task, the equivalent of `docker stop` is issued to the containers running in the task. This results in a stop signal value and a default 30-second timeout, after which the `SIGKILL` value is sent and the containers are forcibly stopped. This signal can be defined in your container image with the `STOPSIGNAL` instruction and will default to `SIGTERM`. If the container handles the `SIGTERM` value gracefully and exits within 30 seconds from receiving it, no `SIGKILL` value is sent.
 *
 * For Windows containers, POSIX signals do not work and runtime stops the container by sending a `CTRL_SHUTDOWN_EVENT`. For more information, see Unable to react to graceful shutdown of (Windows) container #25982 on GitHub.
 *
 * The default 30-second timeout can be configured on the Amazon ECS container agent with the `ECS_CONTAINER_STOP_TIMEOUT` variable. For more information, see Amazon ECS Container Agent Configuration in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const stopTask: API.OperationMethod<StopTaskRequest, StopTaskResponse, StopTaskError, Credentials | HttpClient.HttpClient>;
export type SubmitAttachmentStateChangesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * This action is only used by the Amazon ECS agent, and it is not intended for use outside of the agent.
 *
 * Sent to acknowledge that an attachment changed states.
 */
export declare const submitAttachmentStateChanges: API.OperationMethod<SubmitAttachmentStateChangesRequest, SubmitAttachmentStateChangesResponse, SubmitAttachmentStateChangesError, Credentials | HttpClient.HttpClient>;
export type SubmitContainerStateChangeError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * This action is only used by the Amazon ECS agent, and it is not intended for use outside of the agent.
 *
 * Sent to acknowledge that a container changed states.
 */
export declare const submitContainerStateChange: API.OperationMethod<SubmitContainerStateChangeRequest, SubmitContainerStateChangeResponse, SubmitContainerStateChangeError, Credentials | HttpClient.HttpClient>;
export type SubmitTaskStateChangeError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * This action is only used by the Amazon ECS agent, and it is not intended for use outside of the agent.
 *
 * Sent to acknowledge that a task changed states.
 */
export declare const submitTaskStateChange: API.OperationMethod<SubmitTaskStateChangeRequest, SubmitTaskStateChangeResponse, SubmitTaskStateChangeError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `resourceArn`. If existing tags on a resource aren't specified in the request parameters, they aren't changed. When a resource is deleted, the tags that are associated with that resource are deleted as well.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Deletes specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCapacityProviderError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Modifies the parameters for a capacity provider.
 *
 * These changes only apply to new Amazon ECS Managed Instances, or EC2 instances, not existing ones.
 */
export declare const updateCapacityProvider: API.OperationMethod<UpdateCapacityProviderRequest, UpdateCapacityProviderResponse, UpdateCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | NamespaceNotFoundException | ServerException | CommonErrors;
/**
 * Updates the cluster.
 */
export declare const updateCluster: API.OperationMethod<UpdateClusterRequest, UpdateClusterResponse, UpdateClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterSettingsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UpdateInProgressException | CommonErrors;
/**
 * Modifies the settings to use for a cluster.
 */
export declare const updateClusterSettings: API.OperationMethod<UpdateClusterSettingsRequest, UpdateClusterSettingsResponse, UpdateClusterSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateContainerAgentError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | MissingVersionException | NoUpdateAvailableException | ServerException | UpdateInProgressException | CommonErrors;
/**
 * Updates the Amazon ECS container agent on a specified container instance. Updating the Amazon ECS container agent doesn't interrupt running tasks or services on the container instance. The process for updating the agent differs depending on whether your container instance was launched with the Amazon ECS-optimized AMI or another operating system.
 *
 * The `UpdateContainerAgent` API isn't supported for container instances using the Amazon ECS-optimized Amazon Linux 2 (arm64) AMI. To update the container agent, you can update the `ecs-init` package. This updates the agent. For more information, see Updating the Amazon ECS container agent in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Agent updates with the `UpdateContainerAgent` API operation do not apply to Windows container instances. We recommend that you launch new container instances to update the agent version in your Windows clusters.
 *
 * The `UpdateContainerAgent` API requires an Amazon ECS-optimized AMI or Amazon Linux AMI with the `ecs-init` service installed and running. For help updating the Amazon ECS container agent on other operating systems, see Manually updating the Amazon ECS container agent in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const updateContainerAgent: API.OperationMethod<UpdateContainerAgentRequest, UpdateContainerAgentResponse, UpdateContainerAgentError, Credentials | HttpClient.HttpClient>;
export type UpdateContainerInstancesStateError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Modifies the status of an Amazon ECS container instance.
 *
 * Once a container instance has reached an `ACTIVE` state, you can change the status of a container instance to `DRAINING` to manually remove an instance from a cluster, for example to perform system updates, update the Docker daemon, or scale down the cluster size.
 *
 * A container instance can't be changed to `DRAINING` until it has reached an `ACTIVE` status. If the instance is in any other status, an error will be received.
 *
 * When you set a container instance to `DRAINING`, Amazon ECS prevents new tasks from being scheduled for placement on the container instance and replacement service tasks are started on other container instances in the cluster if the resources are available. Service tasks on the container instance that are in the `PENDING` state are stopped immediately.
 *
 * Service tasks on the container instance that are in the `RUNNING` state are stopped and replaced according to the service's deployment configuration parameters, `minimumHealthyPercent` and `maximumPercent`. You can change the deployment configuration of your service using UpdateService.
 *
 * - If `minimumHealthyPercent` is below 100%, the scheduler can ignore `desiredCount` temporarily during task replacement. For example, `desiredCount` is four tasks, a minimum of 50% allows the scheduler to stop two existing tasks before starting two new tasks. If the minimum is 100%, the service scheduler can't remove existing tasks until the replacement tasks are considered healthy. Tasks for services that do not use a load balancer are considered healthy if they're in the `RUNNING` state. Tasks for services that use a load balancer are considered healthy if they're in the `RUNNING` state and are reported as healthy by the load balancer.
 *
 * - The `maximumPercent` parameter represents an upper limit on the number of running tasks during task replacement. You can use this to define the replacement batch size. For example, if `desiredCount` is four tasks, a maximum of 200% starts four new tasks before stopping the four tasks to be drained, provided that the cluster resources required to do this are available. If the maximum is 100%, then replacement tasks can't start until the draining tasks have stopped.
 *
 * Any `PENDING` or `RUNNING` tasks that do not belong to a service aren't affected. You must wait for them to finish or stop them manually.
 *
 * A container instance has completed draining when it has no more `RUNNING` tasks. You can verify this using ListTasks.
 *
 * When a container instance has been drained, you can set a container instance to `ACTIVE` status and once it has reached that status the Amazon ECS scheduler can begin scheduling tasks on the instance again.
 */
export declare const updateContainerInstancesState: API.OperationMethod<UpdateContainerInstancesStateRequest, UpdateContainerInstancesStateResponse, UpdateContainerInstancesStateError, Credentials | HttpClient.HttpClient>;
export type UpdateDaemonError = AccessDeniedException | ClientException | ClusterNotFoundException | DaemonNotActiveException | DaemonNotFoundException | InvalidParameterException | PlatformUnknownException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Updates the specified daemon. When you update a daemon, a new deployment is triggered that progressively rolls out the changes to the container instances associated with the daemon's capacity providers. For more information, see Daemon deployments in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Amazon ECS drains existing container instances and provisions new instances with the updated daemon. Amazon ECS automatically launches replacement tasks for your services.
 *
 * Updating a daemon triggers a rolling deployment that drains and replaces container instances. Plan updates during maintenance windows to minimize impact on running services.
 *
 * ECS Managed Daemons is only supported for Amazon ECS Managed Instances Capacity Providers.
 */
export declare const updateDaemon: API.OperationMethod<UpdateDaemonRequest, UpdateDaemonResponse, UpdateDaemonError, Credentials | HttpClient.HttpClient>;
export type UpdateExpressGatewayServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotActiveException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Updates an existing Express service configuration. Modifies container settings, resource allocation, auto-scaling configuration, and other service parameters without recreating the service.
 *
 * Amazon ECS creates a new service revision with updated configuration and performs a rolling deployment to replace existing tasks. The service remains available during updates, ensuring zero-downtime deployments.
 *
 * Some parameters like the infrastructure role cannot be modified after service creation and require creating a new service.
 */
export declare const updateExpressGatewayService: API.OperationMethod<UpdateExpressGatewayServiceRequest, UpdateExpressGatewayServiceResponse, UpdateExpressGatewayServiceError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | NamespaceNotFoundException | PlatformTaskDefinitionIncompatibilityException | PlatformUnknownException | ServerException | ServiceNotActiveException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Modifies the parameters of a service.
 *
 * On March 21, 2024, a change was made to resolve the task definition revision before authorization. When a task definition revision is not specified, authorization will occur using the latest revision of a task definition.
 *
 * For services using the rolling update (`ECS`) you can update the desired count, deployment configuration, network configuration, load balancers, service registries, enable ECS managed tags option, propagate tags option, task placement constraints and strategies, and task definition. When you update any of these parameters, Amazon ECS starts new tasks with the new configuration.
 *
 * You can attach Amazon EBS volumes to Amazon ECS tasks by configuring the volume when starting or running a task, or when creating or updating a service. For more information, see Amazon EBS volumes in the *Amazon Elastic Container Service Developer Guide*. You can update your volume configurations and trigger a new deployment. `volumeConfigurations` is only supported for REPLICA service and not DAEMON service. If you leave `volumeConfigurations` `null`, it doesn't trigger a new deployment. For more information on volumes, see Amazon EBS volumes in the *Amazon Elastic Container Service Developer Guide*.
 *
 * For services using the blue/green (`CODE_DEPLOY`) deployment controller, only the desired count, deployment configuration, health check grace period, task placement constraints and strategies, enable ECS managed tags option, and propagate tags can be updated using this API. If the network configuration, platform version, task definition, or load balancer need to be updated, create a new CodeDeploy deployment. For more information, see CreateDeployment in the *CodeDeploy API Reference*.
 *
 * For services using an external deployment controller, you can update only the desired count, task placement constraints and strategies, health check grace period, enable ECS managed tags option, and propagate tags option, using this API. If the launch type, load balancer, network configuration, platform version, or task definition need to be updated, create a new task set For more information, see CreateTaskSet.
 *
 * You can add to or subtract from the number of instantiations of a task definition in a service by specifying the cluster that the service is running in and a new `desiredCount` parameter.
 *
 * You can attach Amazon EBS volumes to Amazon ECS tasks by configuring the volume when starting or running a task, or when creating or updating a service. For more information, see Amazon EBS volumes in the *Amazon Elastic Container Service Developer Guide*.
 *
 * If you have updated the container image of your application, you can create a new task definition with that image and deploy it to your service. The service scheduler uses the minimum healthy percent and maximum percent parameters (in the service's deployment configuration) to determine the deployment strategy.
 *
 * If your updated Docker image uses the same tag as what is in the existing task definition for your service (for example, `my_image:latest`), you don't need to create a new revision of your task definition. You can update the service using the `forceNewDeployment` option. The new tasks launched by the deployment pull the current image/tag combination from your repository when they start.
 *
 * You can also update the deployment configuration of a service. When a deployment is triggered by updating the task definition of a service, the service scheduler uses the deployment configuration parameters, `minimumHealthyPercent` and `maximumPercent`, to determine the deployment strategy.
 *
 * - If `minimumHealthyPercent` is below 100%, the scheduler can ignore `desiredCount` temporarily during a deployment. For example, if `desiredCount` is four tasks, a minimum of 50% allows the scheduler to stop two existing tasks before starting two new tasks. Tasks for services that don't use a load balancer are considered healthy if they're in the `RUNNING` state. Tasks for services that use a load balancer are considered healthy if they're in the `RUNNING` state and are reported as healthy by the load balancer.
 *
 * - The `maximumPercent` parameter represents an upper limit on the number of running tasks during a deployment. You can use it to define the deployment batch size. For example, if `desiredCount` is four tasks, a maximum of 200% starts four new tasks before stopping the four older tasks (provided that the cluster resources required to do this are available).
 *
 * When UpdateService stops a task during a deployment, the equivalent of `docker stop` is issued to the containers running in the task. This results in a `SIGTERM` and a 30-second timeout. After this, `SIGKILL` is sent and the containers are forcibly stopped. If the container handles the `SIGTERM` gracefully and exits within 30 seconds from receiving it, no `SIGKILL` is sent.
 *
 * When the service scheduler launches new tasks, it determines task placement in your cluster with the following logic.
 *
 * - Determine which of the container instances in your cluster can support your service's task definition. For example, they have the required CPU, memory, ports, and container instance attributes.
 *
 * - By default, the service scheduler attempts to balance tasks across Availability Zones in this manner even though you can choose a different placement strategy.
 *
 * - Sort the valid container instances by the fewest number of running tasks for this service in the same Availability Zone as the instance. For example, if zone A has one running service task and zones B and C each have zero, valid container instances in either zone B or C are considered optimal for placement.
 *
 * - Place the new service task on a valid container instance in an optimal Availability Zone (based on the previous steps), favoring container instances with the fewest number of running tasks for this service.
 *
 * When the service scheduler stops running tasks, it attempts to maintain balance across the Availability Zones in your cluster using the following logic:
 *
 * - Sort the container instances by the largest number of running tasks for this service in the same Availability Zone as the instance. For example, if zone A has one running service task and zones B and C each have two, container instances in either zone B or C are considered optimal for termination.
 *
 * - Stop the task on a container instance in an optimal Availability Zone (based on the previous steps), favoring container instances with the largest number of running tasks for this service.
 */
export declare const updateService: API.OperationMethod<UpdateServiceRequest, UpdateServiceResponse, UpdateServiceError, Credentials | HttpClient.HttpClient>;
export type UpdateServicePrimaryTaskSetError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotActiveException | ServiceNotFoundException | TaskSetNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Modifies which task set in a service is the primary task set. Any parameters that are updated on the primary task set in a service will transition to the service. This is used when a service uses the `EXTERNAL` deployment controller type. For more information, see Amazon ECS Deployment Types in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const updateServicePrimaryTaskSet: API.OperationMethod<UpdateServicePrimaryTaskSetRequest, UpdateServicePrimaryTaskSetResponse, UpdateServicePrimaryTaskSetError, Credentials | HttpClient.HttpClient>;
export type UpdateTaskProtectionError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ResourceNotFoundException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Updates the protection status of a task. You can set `protectionEnabled` to `true` to protect your task from termination during scale-in events from Service Autoscaling or deployments.
 *
 * Task-protection, by default, expires after 2 hours at which point Amazon ECS clears the `protectionEnabled` property making the task eligible for termination by a subsequent scale-in event.
 *
 * You can specify a custom expiration period for task protection from 1 minute to up to 2,880 minutes (48 hours). To specify the custom expiration period, set the `expiresInMinutes` property. The `expiresInMinutes` property is always reset when you invoke this operation for a task that already has `protectionEnabled` set to `true`. You can keep extending the protection expiration period of a task by invoking this operation repeatedly.
 *
 * To learn more about Amazon ECS task protection, see Task scale-in protection in the * Amazon Elastic Container Service Developer Guide* .
 *
 * This operation is only supported for tasks belonging to an Amazon ECS service. Invoking this operation for a standalone task will result in an `TASK_NOT_VALID` failure. For more information, see API failure reasons.
 *
 * If you prefer to set task protection from within the container, we recommend using the Task scale-in protection endpoint.
 */
export declare const updateTaskProtection: API.OperationMethod<UpdateTaskProtectionRequest, UpdateTaskProtectionResponse, UpdateTaskProtectionError, Credentials | HttpClient.HttpClient>;
export type UpdateTaskSetError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | LimitExceededException | ServerException | ServiceNotActiveException | ServiceNotFoundException | TaskSetNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Modifies a task set. This is used when a service uses the `EXTERNAL` deployment controller type. For more information, see Amazon ECS Deployment Types in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const updateTaskSet: API.OperationMethod<UpdateTaskSetRequest, UpdateTaskSetResponse, UpdateTaskSetError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ecs.d.ts.map