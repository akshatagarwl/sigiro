import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnprocessableEntityException_base: S.Class<UnprocessableEntityException, S.TaggedStruct<"UnprocessableEntityException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AnalyzerArn = string;
export type Name = string;
export interface ApplyArchiveRuleRequest {
    analyzerArn: string;
    ruleName: string;
    clientToken?: string;
}
export declare const ApplyArchiveRuleRequest: S.Schema<ApplyArchiveRuleRequest>;
export interface ApplyArchiveRuleResponse {
}
export declare const ApplyArchiveRuleResponse: S.Schema<ApplyArchiveRuleResponse>;
export type JobId = string;
export interface CancelPolicyGenerationRequest {
    jobId: string;
}
export declare const CancelPolicyGenerationRequest: S.Schema<CancelPolicyGenerationRequest>;
export interface CancelPolicyGenerationResponse {
}
export declare const CancelPolicyGenerationResponse: S.Schema<CancelPolicyGenerationResponse>;
export type AccessCheckPolicyDocument = string | redacted.Redacted<string>;
export type Action = string;
export type ActionsList = string[];
export declare const ActionsList: any;
export type Resource = string;
export type ResourcesList = string[];
export declare const ResourcesList: any;
export interface Access {
    actions?: string[];
    resources?: string[];
}
export declare const Access: S.Schema<Access>;
export type AccessList = Access[];
export declare const AccessList: any;
export type AccessCheckPolicyType = string;
export interface CheckAccessNotGrantedRequest {
    policyDocument: string | redacted.Redacted<string>;
    access: Access[];
    policyType: string;
}
export declare const CheckAccessNotGrantedRequest: S.Schema<CheckAccessNotGrantedRequest>;
export type CheckAccessNotGrantedResult = string;
export interface ReasonSummary {
    description?: string;
    statementIndex?: number;
    statementId?: string;
}
export declare const ReasonSummary: S.Schema<ReasonSummary>;
export type ReasonSummaryList = ReasonSummary[];
export declare const ReasonSummaryList: any;
export interface CheckAccessNotGrantedResponse {
    result?: string;
    message?: string;
    reasons?: ReasonSummary[];
}
export declare const CheckAccessNotGrantedResponse: S.Schema<CheckAccessNotGrantedResponse>;
export interface CheckNoNewAccessRequest {
    newPolicyDocument: string | redacted.Redacted<string>;
    existingPolicyDocument: string | redacted.Redacted<string>;
    policyType: string;
}
export declare const CheckNoNewAccessRequest: S.Schema<CheckNoNewAccessRequest>;
export type CheckNoNewAccessResult = string;
export interface CheckNoNewAccessResponse {
    result?: string;
    message?: string;
    reasons?: ReasonSummary[];
}
export declare const CheckNoNewAccessResponse: S.Schema<CheckNoNewAccessResponse>;
export type AccessCheckResourceType = string;
export interface CheckNoPublicAccessRequest {
    policyDocument: string | redacted.Redacted<string>;
    resourceType: string;
}
export declare const CheckNoPublicAccessRequest: S.Schema<CheckNoPublicAccessRequest>;
export type CheckNoPublicAccessResult = string;
export interface CheckNoPublicAccessResponse {
    result?: string;
    message?: string;
    reasons?: ReasonSummary[];
}
export declare const CheckNoPublicAccessResponse: S.Schema<CheckNoPublicAccessResponse>;
export type ConfigurationsMapKey = string;
export type EbsUserId = string;
export type EbsUserIdList = string[];
export declare const EbsUserIdList: any;
export type EbsGroup = string;
export type EbsGroupList = string[];
export declare const EbsGroupList: any;
export type EbsSnapshotDataEncryptionKeyId = string;
export interface EbsSnapshotConfiguration {
    userIds?: string[];
    groups?: string[];
    kmsKeyId?: string;
}
export declare const EbsSnapshotConfiguration: S.Schema<EbsSnapshotConfiguration>;
export type EcrRepositoryPolicy = string;
export interface EcrRepositoryConfiguration {
    repositoryPolicy?: string;
}
export declare const EcrRepositoryConfiguration: S.Schema<EcrRepositoryConfiguration>;
export type IamTrustPolicy = string;
export interface IamRoleConfiguration {
    trustPolicy?: string;
}
export declare const IamRoleConfiguration: S.Schema<IamRoleConfiguration>;
export type EfsFileSystemPolicy = string;
export interface EfsFileSystemConfiguration {
    fileSystemPolicy?: string;
}
export declare const EfsFileSystemConfiguration: S.Schema<EfsFileSystemConfiguration>;
export type PolicyName = string;
export type KmsKeyPolicy = string;
export type KmsKeyPoliciesMap = {
    [key: string]: string | undefined;
};
export declare const KmsKeyPoliciesMap: any;
export type KmsGrantOperation = string;
export type KmsGrantOperationsList = string[];
export declare const KmsGrantOperationsList: any;
export type GranteePrincipal = string;
export type RetiringPrincipal = string;
export type KmsConstraintsKey = string;
export type KmsConstraintsValue = string;
export type KmsConstraintsMap = {
    [key: string]: string | undefined;
};
export declare const KmsConstraintsMap: any;
export interface KmsGrantConstraints {
    encryptionContextEquals?: {
        [key: string]: string | undefined;
    };
    encryptionContextSubset?: {
        [key: string]: string | undefined;
    };
}
export declare const KmsGrantConstraints: S.Schema<KmsGrantConstraints>;
export type IssuingAccount = string;
export interface KmsGrantConfiguration {
    operations: string[];
    granteePrincipal: string;
    retiringPrincipal?: string;
    constraints?: KmsGrantConstraints;
    issuingAccount: string;
}
export declare const KmsGrantConfiguration: S.Schema<KmsGrantConfiguration>;
export type KmsGrantConfigurationsList = KmsGrantConfiguration[];
export declare const KmsGrantConfigurationsList: any;
export interface KmsKeyConfiguration {
    keyPolicies?: {
        [key: string]: string | undefined;
    };
    grants?: KmsGrantConfiguration[];
}
export declare const KmsKeyConfiguration: S.Schema<KmsKeyConfiguration>;
export type RdsDbClusterSnapshotAttributeName = string;
export type RdsDbClusterSnapshotAccountId = string;
export type RdsDbClusterSnapshotAccountIdsList = string[];
export declare const RdsDbClusterSnapshotAccountIdsList: any;
export type RdsDbClusterSnapshotAttributeValue = {
    accountIds: string[];
};
export declare const RdsDbClusterSnapshotAttributeValue: any;
export type RdsDbClusterSnapshotAttributesMap = {
    [key: string]: RdsDbClusterSnapshotAttributeValue | undefined;
};
export declare const RdsDbClusterSnapshotAttributesMap: any;
export type RdsDbClusterSnapshotKmsKeyId = string;
export interface RdsDbClusterSnapshotConfiguration {
    attributes?: {
        [key: string]: RdsDbClusterSnapshotAttributeValue | undefined;
    };
    kmsKeyId?: string;
}
export declare const RdsDbClusterSnapshotConfiguration: S.Schema<RdsDbClusterSnapshotConfiguration>;
export type RdsDbSnapshotAttributeName = string;
export type RdsDbSnapshotAccountId = string;
export type RdsDbSnapshotAccountIdsList = string[];
export declare const RdsDbSnapshotAccountIdsList: any;
export type RdsDbSnapshotAttributeValue = {
    accountIds: string[];
};
export declare const RdsDbSnapshotAttributeValue: any;
export type RdsDbSnapshotAttributesMap = {
    [key: string]: RdsDbSnapshotAttributeValue | undefined;
};
export declare const RdsDbSnapshotAttributesMap: any;
export type RdsDbSnapshotKmsKeyId = string;
export interface RdsDbSnapshotConfiguration {
    attributes?: {
        [key: string]: RdsDbSnapshotAttributeValue | undefined;
    };
    kmsKeyId?: string;
}
export declare const RdsDbSnapshotConfiguration: S.Schema<RdsDbSnapshotConfiguration>;
export type SecretsManagerSecretKmsId = string;
export type SecretsManagerSecretPolicy = string;
export interface SecretsManagerSecretConfiguration {
    kmsKeyId?: string;
    secretPolicy?: string;
}
export declare const SecretsManagerSecretConfiguration: S.Schema<SecretsManagerSecretConfiguration>;
export type S3BucketPolicy = string;
export type AclPermission = string;
export type AclCanonicalId = string;
export type AclUri = string;
export type AclGrantee = {
    id: string;
    uri?: never;
} | {
    id?: never;
    uri: string;
};
export declare const AclGrantee: any;
export interface S3BucketAclGrantConfiguration {
    permission: string;
    grantee: AclGrantee;
}
export declare const S3BucketAclGrantConfiguration: S.Schema<S3BucketAclGrantConfiguration>;
export type S3BucketAclGrantConfigurationsList = S3BucketAclGrantConfiguration[];
export declare const S3BucketAclGrantConfigurationsList: any;
export interface S3PublicAccessBlockConfiguration {
    ignorePublicAcls: boolean;
    restrictPublicBuckets: boolean;
}
export declare const S3PublicAccessBlockConfiguration: S.Schema<S3PublicAccessBlockConfiguration>;
export type AccessPointArn = string;
export type AccessPointPolicy = string;
export type VpcId = string;
export interface VpcConfiguration {
    vpcId: string;
}
export declare const VpcConfiguration: S.Schema<VpcConfiguration>;
export interface InternetConfiguration {
}
export declare const InternetConfiguration: S.Schema<InternetConfiguration>;
export type NetworkOriginConfiguration = {
    vpcConfiguration: VpcConfiguration;
    internetConfiguration?: never;
} | {
    vpcConfiguration?: never;
    internetConfiguration: InternetConfiguration;
};
export declare const NetworkOriginConfiguration: any;
export interface S3AccessPointConfiguration {
    accessPointPolicy?: string;
    publicAccessBlock?: S3PublicAccessBlockConfiguration;
    networkOrigin?: NetworkOriginConfiguration;
}
export declare const S3AccessPointConfiguration: S.Schema<S3AccessPointConfiguration>;
export type S3AccessPointConfigurationsMap = {
    [key: string]: S3AccessPointConfiguration | undefined;
};
export declare const S3AccessPointConfigurationsMap: any;
export interface S3BucketConfiguration {
    bucketPolicy?: string;
    bucketAclGrants?: S3BucketAclGrantConfiguration[];
    bucketPublicAccessBlock?: S3PublicAccessBlockConfiguration;
    accessPoints?: {
        [key: string]: S3AccessPointConfiguration | undefined;
    };
}
export declare const S3BucketConfiguration: S.Schema<S3BucketConfiguration>;
export type SnsTopicPolicy = string;
export interface SnsTopicConfiguration {
    topicPolicy?: string;
}
export declare const SnsTopicConfiguration: S.Schema<SnsTopicConfiguration>;
export type SqsQueuePolicy = string;
export interface SqsQueueConfiguration {
    queuePolicy?: string;
}
export declare const SqsQueueConfiguration: S.Schema<SqsQueueConfiguration>;
export type S3ExpressDirectoryBucketPolicy = string;
export type S3ExpressDirectoryAccessPointArn = string;
export interface S3ExpressDirectoryAccessPointConfiguration {
    accessPointPolicy?: string;
    networkOrigin?: NetworkOriginConfiguration;
}
export declare const S3ExpressDirectoryAccessPointConfiguration: S.Schema<S3ExpressDirectoryAccessPointConfiguration>;
export type S3ExpressDirectoryAccessPointConfigurationsMap = {
    [key: string]: S3ExpressDirectoryAccessPointConfiguration | undefined;
};
export declare const S3ExpressDirectoryAccessPointConfigurationsMap: any;
export interface S3ExpressDirectoryBucketConfiguration {
    bucketPolicy?: string;
    accessPoints?: {
        [key: string]: S3ExpressDirectoryAccessPointConfiguration | undefined;
    };
}
export declare const S3ExpressDirectoryBucketConfiguration: S.Schema<S3ExpressDirectoryBucketConfiguration>;
export type DynamodbStreamPolicy = string;
export interface DynamodbStreamConfiguration {
    streamPolicy?: string;
}
export declare const DynamodbStreamConfiguration: S.Schema<DynamodbStreamConfiguration>;
export type DynamodbTablePolicy = string;
export interface DynamodbTableConfiguration {
    tablePolicy?: string;
}
export declare const DynamodbTableConfiguration: S.Schema<DynamodbTableConfiguration>;
export type Configuration = {
    ebsSnapshot: EbsSnapshotConfiguration;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository: EcrRepositoryConfiguration;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole: IamRoleConfiguration;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem: EfsFileSystemConfiguration;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey: KmsKeyConfiguration;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot: RdsDbClusterSnapshotConfiguration;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot: RdsDbSnapshotConfiguration;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret: SecretsManagerSecretConfiguration;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket: S3BucketConfiguration;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic: SnsTopicConfiguration;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue: SqsQueueConfiguration;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket: S3ExpressDirectoryBucketConfiguration;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream: DynamodbStreamConfiguration;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable: DynamodbTableConfiguration;
};
export declare const Configuration: any;
export type ConfigurationsMap = {
    [key: string]: Configuration | undefined;
};
export declare const ConfigurationsMap: any;
export interface CreateAccessPreviewRequest {
    analyzerArn: string;
    configurations: {
        [key: string]: Configuration | undefined;
    };
    clientToken?: string;
}
export declare const CreateAccessPreviewRequest: S.Schema<CreateAccessPreviewRequest>;
export type AccessPreviewId = string;
export interface CreateAccessPreviewResponse {
    id: string;
}
export declare const CreateAccessPreviewResponse: S.Schema<CreateAccessPreviewResponse>;
export type AnalyzerName = string;
export type Type = string;
export type ValueList = string[];
export declare const ValueList: any;
export interface Criterion {
    eq?: string[];
    neq?: string[];
    contains?: string[];
    exists?: boolean;
}
export declare const Criterion: S.Schema<Criterion>;
export type FilterCriteriaMap = {
    [key: string]: Criterion | undefined;
};
export declare const FilterCriteriaMap: any;
export interface InlineArchiveRule {
    ruleName: string;
    filter: {
        [key: string]: Criterion | undefined;
    };
}
export declare const InlineArchiveRule: S.Schema<InlineArchiveRule>;
export type InlineArchiveRulesList = InlineArchiveRule[];
export declare const InlineArchiveRulesList: any;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export type AccountIdsList = string[];
export declare const AccountIdsList: any;
export type TagsList = {
    [key: string]: string | undefined;
}[];
export declare const TagsList: any;
export interface AnalysisRuleCriteria {
    accountIds?: string[];
    resourceTags?: {
        [key: string]: string | undefined;
    }[];
}
export declare const AnalysisRuleCriteria: S.Schema<AnalysisRuleCriteria>;
export type AnalysisRuleCriteriaList = AnalysisRuleCriteria[];
export declare const AnalysisRuleCriteriaList: any;
export interface AnalysisRule {
    exclusions?: AnalysisRuleCriteria[];
}
export declare const AnalysisRule: S.Schema<AnalysisRule>;
export interface UnusedAccessConfiguration {
    unusedAccessAge?: number;
    analysisRule?: AnalysisRule;
}
export declare const UnusedAccessConfiguration: S.Schema<UnusedAccessConfiguration>;
export type ResourceType = string;
export type ResourceTypeList = string[];
export declare const ResourceTypeList: any;
export type ResourceArnsList = string[];
export declare const ResourceArnsList: any;
export interface InternalAccessAnalysisRuleCriteria {
    accountIds?: string[];
    resourceTypes?: string[];
    resourceArns?: string[];
}
export declare const InternalAccessAnalysisRuleCriteria: S.Schema<InternalAccessAnalysisRuleCriteria>;
export type InternalAccessAnalysisRuleCriteriaList = InternalAccessAnalysisRuleCriteria[];
export declare const InternalAccessAnalysisRuleCriteriaList: any;
export interface InternalAccessAnalysisRule {
    inclusions?: InternalAccessAnalysisRuleCriteria[];
}
export declare const InternalAccessAnalysisRule: S.Schema<InternalAccessAnalysisRule>;
export interface InternalAccessConfiguration {
    analysisRule?: InternalAccessAnalysisRule;
}
export declare const InternalAccessConfiguration: S.Schema<InternalAccessConfiguration>;
export type AnalyzerConfiguration = {
    unusedAccess: UnusedAccessConfiguration;
    internalAccess?: never;
} | {
    unusedAccess?: never;
    internalAccess: InternalAccessConfiguration;
};
export declare const AnalyzerConfiguration: any;
export interface CreateAnalyzerRequest {
    analyzerName: string;
    type: string;
    archiveRules?: InlineArchiveRule[];
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
    configuration?: AnalyzerConfiguration;
}
export declare const CreateAnalyzerRequest: S.Schema<CreateAnalyzerRequest>;
export interface CreateAnalyzerResponse {
    arn?: string;
}
export declare const CreateAnalyzerResponse: S.Schema<CreateAnalyzerResponse>;
export interface CreateArchiveRuleRequest {
    analyzerName: string;
    ruleName: string;
    filter: {
        [key: string]: Criterion | undefined;
    };
    clientToken?: string;
}
export declare const CreateArchiveRuleRequest: S.Schema<CreateArchiveRuleRequest>;
export interface CreateArchiveRuleResponse {
}
export declare const CreateArchiveRuleResponse: S.Schema<CreateArchiveRuleResponse>;
export interface CreateServiceLinkedAnalyzerRequest {
    type: string;
    archiveRules?: InlineArchiveRule[];
    clientToken?: string;
    configuration?: AnalyzerConfiguration;
}
export declare const CreateServiceLinkedAnalyzerRequest: S.Schema<CreateServiceLinkedAnalyzerRequest>;
export interface CreateServiceLinkedAnalyzerResponse {
    arn?: string;
}
export declare const CreateServiceLinkedAnalyzerResponse: S.Schema<CreateServiceLinkedAnalyzerResponse>;
export interface DeleteAnalyzerRequest {
    analyzerName: string;
    clientToken?: string;
}
export declare const DeleteAnalyzerRequest: S.Schema<DeleteAnalyzerRequest>;
export interface DeleteAnalyzerResponse {
}
export declare const DeleteAnalyzerResponse: S.Schema<DeleteAnalyzerResponse>;
export interface DeleteArchiveRuleRequest {
    analyzerName: string;
    ruleName: string;
    clientToken?: string;
}
export declare const DeleteArchiveRuleRequest: S.Schema<DeleteArchiveRuleRequest>;
export interface DeleteArchiveRuleResponse {
}
export declare const DeleteArchiveRuleResponse: S.Schema<DeleteArchiveRuleResponse>;
export interface DeleteServiceLinkedAnalyzerRequest {
    analyzerName: string;
    clientToken?: string;
}
export declare const DeleteServiceLinkedAnalyzerRequest: S.Schema<DeleteServiceLinkedAnalyzerRequest>;
export interface DeleteServiceLinkedAnalyzerResponse {
}
export declare const DeleteServiceLinkedAnalyzerResponse: S.Schema<DeleteServiceLinkedAnalyzerResponse>;
export interface GenerateFindingRecommendationRequest {
    analyzerArn: string;
    id: string;
}
export declare const GenerateFindingRecommendationRequest: S.Schema<GenerateFindingRecommendationRequest>;
export interface GenerateFindingRecommendationResponse {
}
export declare const GenerateFindingRecommendationResponse: S.Schema<GenerateFindingRecommendationResponse>;
export interface GetAccessPreviewRequest {
    accessPreviewId: string;
    analyzerArn: string;
}
export declare const GetAccessPreviewRequest: S.Schema<GetAccessPreviewRequest>;
export type AccessPreviewStatus = string;
export type AccessPreviewStatusReasonCode = string;
export interface AccessPreviewStatusReason {
    code: string;
}
export declare const AccessPreviewStatusReason: S.Schema<AccessPreviewStatusReason>;
export interface AccessPreview {
    id: string;
    analyzerArn: string;
    configurations: {
        [key: string]: Configuration | undefined;
    };
    createdAt: Date;
    status: string;
    statusReason?: AccessPreviewStatusReason;
}
export declare const AccessPreview: S.Schema<AccessPreview>;
export interface GetAccessPreviewResponse {
    accessPreview: AccessPreview;
}
export declare const GetAccessPreviewResponse: S.Schema<GetAccessPreviewResponse>;
export type ResourceArn = string;
export interface GetAnalyzedResourceRequest {
    analyzerArn: string;
    resourceArn: string;
}
export declare const GetAnalyzedResourceRequest: S.Schema<GetAnalyzedResourceRequest>;
export type ActionList = string[];
export declare const ActionList: any;
export type SharedViaList = string[];
export declare const SharedViaList: any;
export type FindingStatus = string;
export interface AnalyzedResource {
    resourceArn: string;
    resourceType: string;
    createdAt: Date;
    analyzedAt: Date;
    updatedAt: Date;
    isPublic: boolean;
    actions?: string[];
    sharedVia?: string[];
    status?: string;
    resourceOwnerAccount: string;
    error?: string;
}
export declare const AnalyzedResource: S.Schema<AnalyzedResource>;
export interface GetAnalyzedResourceResponse {
    resource?: AnalyzedResource;
}
export declare const GetAnalyzedResourceResponse: S.Schema<GetAnalyzedResourceResponse>;
export interface GetAnalyzerRequest {
    analyzerName: string;
}
export declare const GetAnalyzerRequest: S.Schema<GetAnalyzerRequest>;
export type AnalyzerStatus = string;
export type ReasonCode = string;
export interface StatusReason {
    code: string;
}
export declare const StatusReason: S.Schema<StatusReason>;
export interface AnalyzerSummary {
    arn: string;
    name: string;
    type: string;
    createdAt: Date;
    lastResourceAnalyzed?: string;
    lastResourceAnalyzedAt?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    status: string;
    statusReason?: StatusReason;
    configuration?: AnalyzerConfiguration;
    managedBy?: string;
}
export declare const AnalyzerSummary: S.Schema<AnalyzerSummary>;
export interface GetAnalyzerResponse {
    analyzer: AnalyzerSummary;
}
export declare const GetAnalyzerResponse: S.Schema<GetAnalyzerResponse>;
export interface GetArchiveRuleRequest {
    analyzerName: string;
    ruleName: string;
}
export declare const GetArchiveRuleRequest: S.Schema<GetArchiveRuleRequest>;
export interface ArchiveRuleSummary {
    ruleName: string;
    filter: {
        [key: string]: Criterion | undefined;
    };
    createdAt: Date;
    updatedAt: Date;
}
export declare const ArchiveRuleSummary: S.Schema<ArchiveRuleSummary>;
export interface GetArchiveRuleResponse {
    archiveRule: ArchiveRuleSummary;
}
export declare const GetArchiveRuleResponse: S.Schema<GetArchiveRuleResponse>;
export type FindingId = string;
export interface GetFindingRequest {
    analyzerArn: string;
    id: string;
}
export declare const GetFindingRequest: S.Schema<GetFindingRequest>;
export type PrincipalMap = {
    [key: string]: string | undefined;
};
export declare const PrincipalMap: any;
export type ConditionKeyMap = {
    [key: string]: string | undefined;
};
export declare const ConditionKeyMap: any;
export type FindingSourceType = string;
export interface FindingSourceDetail {
    accessPointArn?: string;
    accessPointAccount?: string;
}
export declare const FindingSourceDetail: S.Schema<FindingSourceDetail>;
export interface FindingSource {
    type: string;
    detail?: FindingSourceDetail;
}
export declare const FindingSource: S.Schema<FindingSource>;
export type FindingSourceList = FindingSource[];
export declare const FindingSourceList: any;
export type ResourceControlPolicyRestriction = string;
export interface Finding {
    id: string;
    principal?: {
        [key: string]: string | undefined;
    };
    action?: string[];
    resource?: string;
    isPublic?: boolean;
    resourceType: string;
    condition: {
        [key: string]: string | undefined;
    };
    createdAt: Date;
    analyzedAt: Date;
    updatedAt: Date;
    status: string;
    resourceOwnerAccount: string;
    error?: string;
    sources?: FindingSource[];
    resourceControlPolicyRestriction?: string;
}
export declare const Finding: S.Schema<Finding>;
export interface GetFindingResponse {
    finding?: Finding;
}
export declare const GetFindingResponse: S.Schema<GetFindingResponse>;
export type Token = string;
export interface GetFindingRecommendationRequest {
    analyzerArn: string;
    id: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const GetFindingRecommendationRequest: S.Schema<GetFindingRecommendationRequest>;
export interface RecommendationError {
    code: string;
    message: string;
}
export declare const RecommendationError: S.Schema<RecommendationError>;
export type RecommendedRemediationAction = string;
export interface UnusedPermissionsRecommendedStep {
    policyUpdatedAt?: Date;
    recommendedAction: string;
    recommendedPolicy?: string;
    existingPolicyId?: string;
}
export declare const UnusedPermissionsRecommendedStep: S.Schema<UnusedPermissionsRecommendedStep>;
export type RecommendedStep = {
    unusedPermissionsRecommendedStep: UnusedPermissionsRecommendedStep;
};
export declare const RecommendedStep: any;
export type RecommendedStepList = RecommendedStep[];
export declare const RecommendedStepList: any;
export type RecommendationType = string;
export type Status = string;
export interface GetFindingRecommendationResponse {
    startedAt: Date;
    completedAt?: Date;
    nextToken?: string;
    error?: RecommendationError;
    resourceArn: string;
    recommendedSteps?: RecommendedStep[];
    recommendationType: string;
    status: string;
}
export declare const GetFindingRecommendationResponse: S.Schema<GetFindingRecommendationResponse>;
export interface GetFindingsStatisticsRequest {
    analyzerArn: string;
}
export declare const GetFindingsStatisticsRequest: S.Schema<GetFindingsStatisticsRequest>;
export interface ResourceTypeDetails {
    totalActivePublic?: number;
    totalActiveCrossAccount?: number;
    totalActiveErrors?: number;
}
export declare const ResourceTypeDetails: S.Schema<ResourceTypeDetails>;
export type ResourceTypeStatisticsMap = {
    [key: string]: ResourceTypeDetails | undefined;
};
export declare const ResourceTypeStatisticsMap: any;
export interface ExternalAccessFindingsStatistics {
    resourceTypeStatistics?: {
        [key: string]: ResourceTypeDetails | undefined;
    };
    totalActiveFindings?: number;
    totalArchivedFindings?: number;
    totalResolvedFindings?: number;
}
export declare const ExternalAccessFindingsStatistics: S.Schema<ExternalAccessFindingsStatistics>;
export interface InternalAccessResourceTypeDetails {
    totalActiveFindings?: number;
    totalResolvedFindings?: number;
    totalArchivedFindings?: number;
}
export declare const InternalAccessResourceTypeDetails: S.Schema<InternalAccessResourceTypeDetails>;
export type InternalAccessResourceTypeStatisticsMap = {
    [key: string]: InternalAccessResourceTypeDetails | undefined;
};
export declare const InternalAccessResourceTypeStatisticsMap: any;
export interface InternalAccessFindingsStatistics {
    resourceTypeStatistics?: {
        [key: string]: InternalAccessResourceTypeDetails | undefined;
    };
    totalActiveFindings?: number;
    totalArchivedFindings?: number;
    totalResolvedFindings?: number;
}
export declare const InternalAccessFindingsStatistics: S.Schema<InternalAccessFindingsStatistics>;
export interface UnusedAccessTypeStatistics {
    unusedAccessType?: string;
    total?: number;
}
export declare const UnusedAccessTypeStatistics: S.Schema<UnusedAccessTypeStatistics>;
export type UnusedAccessTypeStatisticsList = UnusedAccessTypeStatistics[];
export declare const UnusedAccessTypeStatisticsList: any;
export type FindingAggregationAccountDetailsMap = {
    [key: string]: number | undefined;
};
export declare const FindingAggregationAccountDetailsMap: any;
export interface FindingAggregationAccountDetails {
    account?: string;
    numberOfActiveFindings?: number;
    details?: {
        [key: string]: number | undefined;
    };
}
export declare const FindingAggregationAccountDetails: S.Schema<FindingAggregationAccountDetails>;
export type AccountAggregations = FindingAggregationAccountDetails[];
export declare const AccountAggregations: any;
export interface UnusedAccessFindingsStatistics {
    unusedAccessTypeStatistics?: UnusedAccessTypeStatistics[];
    topAccounts?: FindingAggregationAccountDetails[];
    totalActiveFindings?: number;
    totalArchivedFindings?: number;
    totalResolvedFindings?: number;
}
export declare const UnusedAccessFindingsStatistics: S.Schema<UnusedAccessFindingsStatistics>;
export type FindingsStatistics = {
    externalAccessFindingsStatistics: ExternalAccessFindingsStatistics;
    internalAccessFindingsStatistics?: never;
    unusedAccessFindingsStatistics?: never;
} | {
    externalAccessFindingsStatistics?: never;
    internalAccessFindingsStatistics: InternalAccessFindingsStatistics;
    unusedAccessFindingsStatistics?: never;
} | {
    externalAccessFindingsStatistics?: never;
    internalAccessFindingsStatistics?: never;
    unusedAccessFindingsStatistics: UnusedAccessFindingsStatistics;
};
export declare const FindingsStatistics: any;
export type FindingsStatisticsList = FindingsStatistics[];
export declare const FindingsStatisticsList: any;
export interface GetFindingsStatisticsResponse {
    findingsStatistics?: FindingsStatistics[];
    lastUpdatedAt?: Date;
}
export declare const GetFindingsStatisticsResponse: S.Schema<GetFindingsStatisticsResponse>;
export interface GetFindingV2Request {
    analyzerArn: string;
    id: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const GetFindingV2Request: S.Schema<GetFindingV2Request>;
export type InternalAccessType = string;
export type PrincipalType = string;
export type ServiceControlPolicyRestriction = string;
export interface InternalAccessDetails {
    action?: string[];
    condition?: {
        [key: string]: string | undefined;
    };
    principal?: {
        [key: string]: string | undefined;
    };
    principalOwnerAccount?: string;
    accessType?: string;
    principalType?: string;
    sources?: FindingSource[];
    resourceControlPolicyRestriction?: string;
    serviceControlPolicyRestriction?: string;
}
export declare const InternalAccessDetails: S.Schema<InternalAccessDetails>;
export interface ExternalAccessDetails {
    action?: string[];
    condition: {
        [key: string]: string | undefined;
    };
    isPublic?: boolean;
    principal?: {
        [key: string]: string | undefined;
    };
    sources?: FindingSource[];
    resourceControlPolicyRestriction?: string;
}
export declare const ExternalAccessDetails: S.Schema<ExternalAccessDetails>;
export interface UnusedAction {
    action: string;
    lastAccessed?: Date;
}
export declare const UnusedAction: S.Schema<UnusedAction>;
export type UnusedActionList = UnusedAction[];
export declare const UnusedActionList: any;
export interface UnusedPermissionDetails {
    actions?: UnusedAction[];
    serviceNamespace: string;
    lastAccessed?: Date;
}
export declare const UnusedPermissionDetails: S.Schema<UnusedPermissionDetails>;
export interface UnusedIamUserAccessKeyDetails {
    accessKeyId: string;
    lastAccessed?: Date;
}
export declare const UnusedIamUserAccessKeyDetails: S.Schema<UnusedIamUserAccessKeyDetails>;
export interface UnusedIamRoleDetails {
    lastAccessed?: Date;
}
export declare const UnusedIamRoleDetails: S.Schema<UnusedIamRoleDetails>;
export interface UnusedIamUserPasswordDetails {
    lastAccessed?: Date;
}
export declare const UnusedIamUserPasswordDetails: S.Schema<UnusedIamUserPasswordDetails>;
export type FindingDetails = {
    internalAccessDetails: InternalAccessDetails;
    externalAccessDetails?: never;
    unusedPermissionDetails?: never;
    unusedIamUserAccessKeyDetails?: never;
    unusedIamRoleDetails?: never;
    unusedIamUserPasswordDetails?: never;
} | {
    internalAccessDetails?: never;
    externalAccessDetails: ExternalAccessDetails;
    unusedPermissionDetails?: never;
    unusedIamUserAccessKeyDetails?: never;
    unusedIamRoleDetails?: never;
    unusedIamUserPasswordDetails?: never;
} | {
    internalAccessDetails?: never;
    externalAccessDetails?: never;
    unusedPermissionDetails: UnusedPermissionDetails;
    unusedIamUserAccessKeyDetails?: never;
    unusedIamRoleDetails?: never;
    unusedIamUserPasswordDetails?: never;
} | {
    internalAccessDetails?: never;
    externalAccessDetails?: never;
    unusedPermissionDetails?: never;
    unusedIamUserAccessKeyDetails: UnusedIamUserAccessKeyDetails;
    unusedIamRoleDetails?: never;
    unusedIamUserPasswordDetails?: never;
} | {
    internalAccessDetails?: never;
    externalAccessDetails?: never;
    unusedPermissionDetails?: never;
    unusedIamUserAccessKeyDetails?: never;
    unusedIamRoleDetails: UnusedIamRoleDetails;
    unusedIamUserPasswordDetails?: never;
} | {
    internalAccessDetails?: never;
    externalAccessDetails?: never;
    unusedPermissionDetails?: never;
    unusedIamUserAccessKeyDetails?: never;
    unusedIamRoleDetails?: never;
    unusedIamUserPasswordDetails: UnusedIamUserPasswordDetails;
};
export declare const FindingDetails: any;
export type FindingDetailsList = FindingDetails[];
export declare const FindingDetailsList: any;
export type FindingType = string;
export interface GetFindingV2Response {
    analyzedAt: Date;
    createdAt: Date;
    error?: string;
    id: string;
    nextToken?: string;
    resource?: string;
    resourceType: string;
    resourceOwnerAccount: string;
    status: string;
    updatedAt: Date;
    findingDetails: FindingDetails[];
    findingType?: string;
}
export declare const GetFindingV2Response: S.Schema<GetFindingV2Response>;
export interface GetGeneratedPolicyRequest {
    jobId: string;
    includeResourcePlaceholders?: boolean;
    includeServiceLevelTemplate?: boolean;
}
export declare const GetGeneratedPolicyRequest: S.Schema<GetGeneratedPolicyRequest>;
export type JobStatus = string;
export type JobErrorCode = string;
export interface JobError {
    code: string;
    message: string;
}
export declare const JobError: S.Schema<JobError>;
export interface JobDetails {
    jobId: string;
    status: string;
    startedOn: Date;
    completedOn?: Date;
    jobError?: JobError;
}
export declare const JobDetails: S.Schema<JobDetails>;
export type PrincipalArn = string;
export type CloudTrailArn = string;
export type RegionList = string[];
export declare const RegionList: any;
export interface TrailProperties {
    cloudTrailArn: string;
    regions?: string[];
    allRegions?: boolean;
}
export declare const TrailProperties: S.Schema<TrailProperties>;
export type TrailPropertiesList = TrailProperties[];
export declare const TrailPropertiesList: any;
export interface CloudTrailProperties {
    trailProperties: TrailProperties[];
    startTime: Date;
    endTime: Date;
}
export declare const CloudTrailProperties: S.Schema<CloudTrailProperties>;
export interface GeneratedPolicyProperties {
    isComplete?: boolean;
    principalArn: string;
    cloudTrailProperties?: CloudTrailProperties;
}
export declare const GeneratedPolicyProperties: S.Schema<GeneratedPolicyProperties>;
export interface GeneratedPolicy {
    policy: string;
}
export declare const GeneratedPolicy: S.Schema<GeneratedPolicy>;
export type GeneratedPolicyList = GeneratedPolicy[];
export declare const GeneratedPolicyList: any;
export interface GeneratedPolicyResult {
    properties: GeneratedPolicyProperties;
    generatedPolicies?: GeneratedPolicy[];
}
export declare const GeneratedPolicyResult: S.Schema<GeneratedPolicyResult>;
export interface GetGeneratedPolicyResponse {
    jobDetails: JobDetails;
    generatedPolicyResult: GeneratedPolicyResult;
}
export declare const GetGeneratedPolicyResponse: S.Schema<GetGeneratedPolicyResponse>;
export interface ListAccessPreviewFindingsRequest {
    accessPreviewId: string;
    analyzerArn: string;
    filter?: {
        [key: string]: Criterion | undefined;
    };
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAccessPreviewFindingsRequest: S.Schema<ListAccessPreviewFindingsRequest>;
export type AccessPreviewFindingId = string;
export type FindingChangeType = string;
export interface AccessPreviewFinding {
    id: string;
    existingFindingId?: string;
    existingFindingStatus?: string;
    principal?: {
        [key: string]: string | undefined;
    };
    action?: string[];
    condition?: {
        [key: string]: string | undefined;
    };
    resource?: string;
    isPublic?: boolean;
    resourceType: string;
    createdAt: Date;
    changeType: string;
    status: string;
    resourceOwnerAccount: string;
    error?: string;
    sources?: FindingSource[];
    resourceControlPolicyRestriction?: string;
}
export declare const AccessPreviewFinding: S.Schema<AccessPreviewFinding>;
export type AccessPreviewFindingsList = AccessPreviewFinding[];
export declare const AccessPreviewFindingsList: any;
export interface ListAccessPreviewFindingsResponse {
    findings: AccessPreviewFinding[];
    nextToken?: string;
}
export declare const ListAccessPreviewFindingsResponse: S.Schema<ListAccessPreviewFindingsResponse>;
export interface ListAccessPreviewsRequest {
    analyzerArn: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAccessPreviewsRequest: S.Schema<ListAccessPreviewsRequest>;
export interface AccessPreviewSummary {
    id: string;
    analyzerArn: string;
    createdAt: Date;
    status: string;
    statusReason?: AccessPreviewStatusReason;
}
export declare const AccessPreviewSummary: S.Schema<AccessPreviewSummary>;
export type AccessPreviewsList = AccessPreviewSummary[];
export declare const AccessPreviewsList: any;
export interface ListAccessPreviewsResponse {
    accessPreviews: AccessPreviewSummary[];
    nextToken?: string;
}
export declare const ListAccessPreviewsResponse: S.Schema<ListAccessPreviewsResponse>;
export interface ListAnalyzedResourcesRequest {
    analyzerArn: string;
    resourceType?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAnalyzedResourcesRequest: S.Schema<ListAnalyzedResourcesRequest>;
export interface AnalyzedResourceSummary {
    resourceArn: string;
    resourceOwnerAccount: string;
    resourceType: string;
}
export declare const AnalyzedResourceSummary: S.Schema<AnalyzedResourceSummary>;
export type AnalyzedResourcesList = AnalyzedResourceSummary[];
export declare const AnalyzedResourcesList: any;
export interface ListAnalyzedResourcesResponse {
    analyzedResources: AnalyzedResourceSummary[];
    nextToken?: string;
}
export declare const ListAnalyzedResourcesResponse: S.Schema<ListAnalyzedResourcesResponse>;
export interface ListAnalyzersRequest {
    nextToken?: string;
    maxResults?: number;
    type?: string;
}
export declare const ListAnalyzersRequest: S.Schema<ListAnalyzersRequest>;
export type AnalyzersList = AnalyzerSummary[];
export declare const AnalyzersList: any;
export interface ListAnalyzersResponse {
    analyzers: AnalyzerSummary[];
    nextToken?: string;
}
export declare const ListAnalyzersResponse: S.Schema<ListAnalyzersResponse>;
export interface ListArchiveRulesRequest {
    analyzerName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListArchiveRulesRequest: S.Schema<ListArchiveRulesRequest>;
export type ArchiveRulesList = ArchiveRuleSummary[];
export declare const ArchiveRulesList: any;
export interface ListArchiveRulesResponse {
    archiveRules: ArchiveRuleSummary[];
    nextToken?: string;
}
export declare const ListArchiveRulesResponse: S.Schema<ListArchiveRulesResponse>;
export type OrderBy = string;
export interface SortCriteria {
    attributeName?: string;
    orderBy?: string;
}
export declare const SortCriteria: S.Schema<SortCriteria>;
export interface ListFindingsRequest {
    analyzerArn: string;
    filter?: {
        [key: string]: Criterion | undefined;
    };
    sort?: SortCriteria;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListFindingsRequest: S.Schema<ListFindingsRequest>;
export interface FindingSummary {
    id: string;
    principal?: {
        [key: string]: string | undefined;
    };
    action?: string[];
    resource?: string;
    isPublic?: boolean;
    resourceType: string;
    condition: {
        [key: string]: string | undefined;
    };
    createdAt: Date;
    analyzedAt: Date;
    updatedAt: Date;
    status: string;
    resourceOwnerAccount: string;
    error?: string;
    sources?: FindingSource[];
    resourceControlPolicyRestriction?: string;
}
export declare const FindingSummary: S.Schema<FindingSummary>;
export type FindingsList = FindingSummary[];
export declare const FindingsList: any;
export interface ListFindingsResponse {
    findings: FindingSummary[];
    nextToken?: string;
}
export declare const ListFindingsResponse: S.Schema<ListFindingsResponse>;
export interface ListFindingsV2Request {
    analyzerArn: string;
    filter?: {
        [key: string]: Criterion | undefined;
    };
    maxResults?: number;
    nextToken?: string;
    sort?: SortCriteria;
}
export declare const ListFindingsV2Request: S.Schema<ListFindingsV2Request>;
export interface FindingSummaryV2 {
    analyzedAt: Date;
    createdAt: Date;
    error?: string;
    id: string;
    resource?: string;
    resourceType: string;
    resourceOwnerAccount: string;
    status: string;
    updatedAt: Date;
    findingType?: string;
}
export declare const FindingSummaryV2: S.Schema<FindingSummaryV2>;
export type FindingsListV2 = FindingSummaryV2[];
export declare const FindingsListV2: any;
export interface ListFindingsV2Response {
    findings: FindingSummaryV2[];
    nextToken?: string;
}
export declare const ListFindingsV2Response: S.Schema<ListFindingsV2Response>;
export interface ListPolicyGenerationsRequest {
    principalArn?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListPolicyGenerationsRequest: S.Schema<ListPolicyGenerationsRequest>;
export interface PolicyGeneration {
    jobId: string;
    principalArn: string;
    status: string;
    startedOn: Date;
    completedOn?: Date;
}
export declare const PolicyGeneration: S.Schema<PolicyGeneration>;
export type PolicyGenerationList = PolicyGeneration[];
export declare const PolicyGenerationList: any;
export interface ListPolicyGenerationsResponse {
    policyGenerations: PolicyGeneration[];
    nextToken?: string;
}
export declare const ListPolicyGenerationsResponse: S.Schema<ListPolicyGenerationsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PolicyGenerationDetails {
    principalArn: string;
}
export declare const PolicyGenerationDetails: S.Schema<PolicyGenerationDetails>;
export interface Trail {
    cloudTrailArn: string;
    regions?: string[];
    allRegions?: boolean;
}
export declare const Trail: S.Schema<Trail>;
export type TrailList = Trail[];
export declare const TrailList: any;
export type RoleArn = string;
export interface CloudTrailDetails {
    trails: Trail[];
    accessRole: string;
    startTime: Date;
    endTime?: Date;
}
export declare const CloudTrailDetails: S.Schema<CloudTrailDetails>;
export interface StartPolicyGenerationRequest {
    policyGenerationDetails: PolicyGenerationDetails;
    cloudTrailDetails?: CloudTrailDetails;
    clientToken?: string;
}
export declare const StartPolicyGenerationRequest: S.Schema<StartPolicyGenerationRequest>;
export interface StartPolicyGenerationResponse {
    jobId: string;
}
export declare const StartPolicyGenerationResponse: S.Schema<StartPolicyGenerationResponse>;
export interface StartResourceScanRequest {
    analyzerArn: string;
    resourceArn: string;
    resourceOwnerAccount?: string;
}
export declare const StartResourceScanRequest: S.Schema<StartResourceScanRequest>;
export interface StartResourceScanResponse {
}
export declare const StartResourceScanResponse: S.Schema<StartResourceScanResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAnalyzerRequest {
    analyzerName: string;
    configuration?: AnalyzerConfiguration;
}
export declare const UpdateAnalyzerRequest: S.Schema<UpdateAnalyzerRequest>;
export interface UpdateAnalyzerResponse {
    configuration?: AnalyzerConfiguration;
}
export declare const UpdateAnalyzerResponse: S.Schema<UpdateAnalyzerResponse>;
export interface UpdateArchiveRuleRequest {
    analyzerName: string;
    ruleName: string;
    filter: {
        [key: string]: Criterion | undefined;
    };
    clientToken?: string;
}
export declare const UpdateArchiveRuleRequest: S.Schema<UpdateArchiveRuleRequest>;
export interface UpdateArchiveRuleResponse {
}
export declare const UpdateArchiveRuleResponse: S.Schema<UpdateArchiveRuleResponse>;
export type FindingStatusUpdate = string;
export type FindingIdList = string[];
export declare const FindingIdList: any;
export interface UpdateFindingsRequest {
    analyzerArn: string;
    status: string;
    ids?: string[];
    resourceArn?: string;
    clientToken?: string;
}
export declare const UpdateFindingsRequest: S.Schema<UpdateFindingsRequest>;
export interface UpdateFindingsResponse {
}
export declare const UpdateFindingsResponse: S.Schema<UpdateFindingsResponse>;
export type Locale = string;
export type PolicyDocument = string;
export type PolicyType = string;
export type ValidatePolicyResourceType = string;
export interface ValidatePolicyRequest {
    locale?: string;
    maxResults?: number;
    nextToken?: string;
    policyDocument: string;
    policyType: string;
    validatePolicyResourceType?: string;
}
export declare const ValidatePolicyRequest: S.Schema<ValidatePolicyRequest>;
export type ValidatePolicyFindingType = string;
export type IssueCode = string;
export type LearnMoreLink = string;
export interface Substring {
    start: number;
    length: number;
}
export declare const Substring: S.Schema<Substring>;
export type PathElement = {
    index: number;
    key?: never;
    substring?: never;
    value?: never;
} | {
    index?: never;
    key: string;
    substring?: never;
    value?: never;
} | {
    index?: never;
    key?: never;
    substring: Substring;
    value?: never;
} | {
    index?: never;
    key?: never;
    substring?: never;
    value: string;
};
export declare const PathElement: any;
export type PathElementList = PathElement[];
export declare const PathElementList: any;
export interface Position {
    line: number;
    column: number;
    offset: number;
}
export declare const Position: S.Schema<Position>;
export interface Span {
    start: Position;
    end: Position;
}
export declare const Span: S.Schema<Span>;
export interface Location {
    path: PathElement[];
    span: Span;
}
export declare const Location: S.Schema<Location>;
export type LocationList = Location[];
export declare const LocationList: any;
export interface ValidatePolicyFinding {
    findingDetails: string;
    findingType: string;
    issueCode: string;
    learnMoreLink: string;
    locations: Location[];
}
export declare const ValidatePolicyFinding: S.Schema<ValidatePolicyFinding>;
export type ValidatePolicyFindingList = ValidatePolicyFinding[];
export declare const ValidatePolicyFindingList: any;
export interface ValidatePolicyResponse {
    findings: ValidatePolicyFinding[];
    nextToken?: string;
}
export declare const ValidatePolicyResponse: S.Schema<ValidatePolicyResponse>;
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type ApplyArchiveRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retroactively applies the archive rule to existing findings that meet the archive rule criteria.
 */
export declare const applyArchiveRule: API.OperationMethod<ApplyArchiveRuleRequest, ApplyArchiveRuleResponse, ApplyArchiveRuleError, Credentials | HttpClient.HttpClient>;
export type CancelPolicyGenerationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the requested policy generation.
 */
export declare const cancelPolicyGeneration: API.OperationMethod<CancelPolicyGenerationRequest, CancelPolicyGenerationResponse, CancelPolicyGenerationError, Credentials | HttpClient.HttpClient>;
export type CheckAccessNotGrantedError = AccessDeniedException | InternalServerException | InvalidParameterException | ThrottlingException | UnprocessableEntityException | ValidationException | CommonErrors;
/**
 * Checks whether the specified access isn't allowed by a policy.
 */
export declare const checkAccessNotGranted: API.OperationMethod<CheckAccessNotGrantedRequest, CheckAccessNotGrantedResponse, CheckAccessNotGrantedError, Credentials | HttpClient.HttpClient>;
export type CheckNoNewAccessError = AccessDeniedException | InternalServerException | InvalidParameterException | ThrottlingException | UnprocessableEntityException | ValidationException | CommonErrors;
/**
 * Checks whether new access is allowed for an updated policy when compared to the existing policy.
 *
 * You can find examples for reference policies and learn how to set up and run a custom policy check for new access in the IAM Access Analyzer custom policy checks samples repository on GitHub. The reference policies in this repository are meant to be passed to the `existingPolicyDocument` request parameter.
 */
export declare const checkNoNewAccess: API.OperationMethod<CheckNoNewAccessRequest, CheckNoNewAccessResponse, CheckNoNewAccessError, Credentials | HttpClient.HttpClient>;
export type CheckNoPublicAccessError = AccessDeniedException | InternalServerException | InvalidParameterException | ThrottlingException | UnprocessableEntityException | ValidationException | CommonErrors;
/**
 * Checks whether a resource policy can grant public access to the specified resource type.
 */
export declare const checkNoPublicAccess: API.OperationMethod<CheckNoPublicAccessRequest, CheckNoPublicAccessResponse, CheckNoPublicAccessError, Credentials | HttpClient.HttpClient>;
export type CreateAccessPreviewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an access preview that allows you to preview IAM Access Analyzer findings for your resource before deploying resource permissions.
 */
export declare const createAccessPreview: API.OperationMethod<CreateAccessPreviewRequest, CreateAccessPreviewResponse, CreateAccessPreviewError, Credentials | HttpClient.HttpClient>;
export type CreateAnalyzerError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an analyzer for your account.
 */
export declare const createAnalyzer: API.OperationMethod<CreateAnalyzerRequest, CreateAnalyzerResponse, CreateAnalyzerError, Credentials | HttpClient.HttpClient>;
export type CreateArchiveRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an archive rule for the specified analyzer. Archive rules automatically archive new findings that meet the criteria you define when you create the rule.
 *
 * To learn about filter keys that you can use to create an archive rule, see IAM Access Analyzer filter keys in the **IAM User Guide**.
 */
export declare const createArchiveRule: API.OperationMethod<CreateArchiveRuleRequest, CreateArchiveRuleResponse, CreateArchiveRuleError, Credentials | HttpClient.HttpClient>;
export type CreateServiceLinkedAnalyzerError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a service-linked analyzer managed by an Amazon Web Services service. This operation can only be invoked by authorized Amazon Web Services services. Direct customer invocation returns `AccessDeniedException`.
 *
 * Service-linked analyzers enable Amazon Web Services services to create and manage analyzers on behalf of customers. The lifecycle of these analyzers is managed by the calling service.
 */
export declare const createServiceLinkedAnalyzer: API.OperationMethod<CreateServiceLinkedAnalyzerRequest, CreateServiceLinkedAnalyzerResponse, CreateServiceLinkedAnalyzerError, Credentials | HttpClient.HttpClient>;
export type DeleteAnalyzerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified analyzer. When you delete an analyzer, IAM Access Analyzer is disabled for the account or organization in the current or specific Region. All findings that were generated by the analyzer are deleted. You cannot undo this action.
 */
export declare const deleteAnalyzer: API.OperationMethod<DeleteAnalyzerRequest, DeleteAnalyzerResponse, DeleteAnalyzerError, Credentials | HttpClient.HttpClient>;
export type DeleteArchiveRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified archive rule.
 */
export declare const deleteArchiveRule: API.OperationMethod<DeleteArchiveRuleRequest, DeleteArchiveRuleResponse, DeleteArchiveRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceLinkedAnalyzerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a service-linked analyzer. This operation can be invoked by both authorized Amazon Web Services services and customers.
 *
 * When invoked by a customer, IAM Access Analyzer performs a callback to the managing service to verify whether the analyzer is still in use and can be deleted. If the service indicates the analyzer is still in use, the deletion is rejected with `ConflictException`.
 */
export declare const deleteServiceLinkedAnalyzer: API.OperationMethod<DeleteServiceLinkedAnalyzerRequest, DeleteServiceLinkedAnalyzerResponse, DeleteServiceLinkedAnalyzerError, Credentials | HttpClient.HttpClient>;
export type GenerateFindingRecommendationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a recommendation for an unused permissions finding.
 */
export declare const generateFindingRecommendation: API.OperationMethod<GenerateFindingRecommendationRequest, GenerateFindingRecommendationResponse, GenerateFindingRecommendationError, Credentials | HttpClient.HttpClient>;
export type GetAccessPreviewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an access preview for the specified analyzer.
 */
export declare const getAccessPreview: API.OperationMethod<GetAccessPreviewRequest, GetAccessPreviewResponse, GetAccessPreviewError, Credentials | HttpClient.HttpClient>;
export type GetAnalyzedResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a resource that was analyzed.
 *
 * This action is supported only for external access analyzers.
 */
export declare const getAnalyzedResource: API.OperationMethod<GetAnalyzedResourceRequest, GetAnalyzedResourceResponse, GetAnalyzedResourceError, Credentials | HttpClient.HttpClient>;
export type GetAnalyzerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified analyzer.
 */
export declare const getAnalyzer: API.OperationMethod<GetAnalyzerRequest, GetAnalyzerResponse, GetAnalyzerError, Credentials | HttpClient.HttpClient>;
export type GetArchiveRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an archive rule.
 *
 * To learn about filter keys that you can use to create an archive rule, see IAM Access Analyzer filter keys in the **IAM User Guide**.
 */
export declare const getArchiveRule: API.OperationMethod<GetArchiveRuleRequest, GetArchiveRuleResponse, GetArchiveRuleError, Credentials | HttpClient.HttpClient>;
export type GetFindingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified finding. GetFinding and GetFindingV2 both use `access-analyzer:GetFinding` in the `Action` element of an IAM policy statement. You must have permission to perform the `access-analyzer:GetFinding` action.
 *
 * GetFinding is supported only for external access analyzers. You must use GetFindingV2 for internal and unused access analyzers.
 */
export declare const getFinding: API.OperationMethod<GetFindingRequest, GetFindingResponse, GetFindingError, Credentials | HttpClient.HttpClient>;
export type GetFindingRecommendationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a finding recommendation for the specified analyzer.
 */
export declare const getFindingRecommendation: API.PaginatedOperationMethod<GetFindingRecommendationRequest, GetFindingRecommendationResponse, GetFindingRecommendationError, Credentials | HttpClient.HttpClient, RecommendedStep>;
export type GetFindingsStatisticsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of aggregated finding statistics for an external access or unused access analyzer.
 */
export declare const getFindingsStatistics: API.OperationMethod<GetFindingsStatisticsRequest, GetFindingsStatisticsResponse, GetFindingsStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetFindingV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified finding. GetFinding and GetFindingV2 both use `access-analyzer:GetFinding` in the `Action` element of an IAM policy statement. You must have permission to perform the `access-analyzer:GetFinding` action.
 */
export declare const getFindingV2: API.PaginatedOperationMethod<GetFindingV2Request, GetFindingV2Response, GetFindingV2Error, Credentials | HttpClient.HttpClient, FindingDetails>;
export type GetGeneratedPolicyError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the policy that was generated using `StartPolicyGeneration`.
 */
export declare const getGeneratedPolicy: API.OperationMethod<GetGeneratedPolicyRequest, GetGeneratedPolicyResponse, GetGeneratedPolicyError, Credentials | HttpClient.HttpClient>;
export type ListAccessPreviewFindingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of access preview findings generated by the specified access preview.
 */
export declare const listAccessPreviewFindings: API.PaginatedOperationMethod<ListAccessPreviewFindingsRequest, ListAccessPreviewFindingsResponse, ListAccessPreviewFindingsError, Credentials | HttpClient.HttpClient, AccessPreviewFinding>;
export type ListAccessPreviewsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of access previews for the specified analyzer.
 */
export declare const listAccessPreviews: API.PaginatedOperationMethod<ListAccessPreviewsRequest, ListAccessPreviewsResponse, ListAccessPreviewsError, Credentials | HttpClient.HttpClient, AccessPreviewSummary>;
export type ListAnalyzedResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of resources of the specified type that have been analyzed by the specified analyzer.
 */
export declare const listAnalyzedResources: API.PaginatedOperationMethod<ListAnalyzedResourcesRequest, ListAnalyzedResourcesResponse, ListAnalyzedResourcesError, Credentials | HttpClient.HttpClient, AnalyzedResourceSummary>;
export type ListAnalyzersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of analyzers.
 */
export declare const listAnalyzers: API.PaginatedOperationMethod<ListAnalyzersRequest, ListAnalyzersResponse, ListAnalyzersError, Credentials | HttpClient.HttpClient, AnalyzerSummary>;
export type ListArchiveRulesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of archive rules created for the specified analyzer.
 */
export declare const listArchiveRules: API.PaginatedOperationMethod<ListArchiveRulesRequest, ListArchiveRulesResponse, ListArchiveRulesError, Credentials | HttpClient.HttpClient, ArchiveRuleSummary>;
export type ListFindingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of findings generated by the specified analyzer. ListFindings and ListFindingsV2 both use `access-analyzer:ListFindings` in the `Action` element of an IAM policy statement. You must have permission to perform the `access-analyzer:ListFindings` action.
 *
 * To learn about filter keys that you can use to retrieve a list of findings, see IAM Access Analyzer filter keys in the **IAM User Guide**.
 *
 * ListFindings is supported only for external access analyzers. You must use ListFindingsV2 for internal and unused access analyzers.
 */
export declare const listFindings: API.PaginatedOperationMethod<ListFindingsRequest, ListFindingsResponse, ListFindingsError, Credentials | HttpClient.HttpClient, FindingSummary>;
export type ListFindingsV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of findings generated by the specified analyzer. ListFindings and ListFindingsV2 both use `access-analyzer:ListFindings` in the `Action` element of an IAM policy statement. You must have permission to perform the `access-analyzer:ListFindings` action.
 *
 * To learn about filter keys that you can use to retrieve a list of findings, see IAM Access Analyzer filter keys in the **IAM User Guide**.
 */
export declare const listFindingsV2: API.PaginatedOperationMethod<ListFindingsV2Request, ListFindingsV2Response, ListFindingsV2Error, Credentials | HttpClient.HttpClient, FindingSummaryV2>;
export type ListPolicyGenerationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all of the policy generations requested in the last seven days.
 */
export declare const listPolicyGenerations: API.PaginatedOperationMethod<ListPolicyGenerationsRequest, ListPolicyGenerationsResponse, ListPolicyGenerationsError, Credentials | HttpClient.HttpClient, PolicyGeneration>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of tags applied to the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartPolicyGenerationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the policy generation request.
 */
export declare const startPolicyGeneration: API.OperationMethod<StartPolicyGenerationRequest, StartPolicyGenerationResponse, StartPolicyGenerationError, Credentials | HttpClient.HttpClient>;
export type StartResourceScanError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Immediately starts a scan of the policies applied to the specified resource.
 *
 * This action is supported only for external access analyzers.
 */
export declare const startResourceScan: API.OperationMethod<StartResourceScanRequest, StartResourceScanResponse, StartResourceScanError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a tag to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAnalyzerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies the configuration of an existing analyzer.
 *
 * This action is not supported for external access analyzers.
 */
export declare const updateAnalyzer: API.OperationMethod<UpdateAnalyzerRequest, UpdateAnalyzerResponse, UpdateAnalyzerError, Credentials | HttpClient.HttpClient>;
export type UpdateArchiveRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the criteria and values for the specified archive rule.
 */
export declare const updateArchiveRule: API.OperationMethod<UpdateArchiveRuleRequest, UpdateArchiveRuleResponse, UpdateArchiveRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateFindingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status for the specified findings.
 */
export declare const updateFindings: API.OperationMethod<UpdateFindingsRequest, UpdateFindingsResponse, UpdateFindingsError, Credentials | HttpClient.HttpClient>;
export type ValidatePolicyError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Requests the validation of a policy and returns a list of findings. The findings help you identify issues and provide actionable recommendations to resolve the issue and enable you to author functional policies that meet security best practices.
 */
export declare const validatePolicy: API.PaginatedOperationMethod<ValidatePolicyRequest, ValidatePolicyResponse, ValidatePolicyError, Credentials | HttpClient.HttpClient, ValidatePolicyFinding>;
export {};
//# sourceMappingURL=accessanalyzer.d.ts.map