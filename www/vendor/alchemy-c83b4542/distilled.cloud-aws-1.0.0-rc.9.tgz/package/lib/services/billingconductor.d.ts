import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly RetryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceLimitExceededException_base: S.Class<ServiceLimitExceededException, S.TaggedStruct<"ServiceLimitExceededException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly LimitCode: any;
    readonly ServiceCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceLimitExceededException extends /*@__PURE__*/ ServiceLimitExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly RetryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly Fields: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type BillingGroupArn = string;
export type AccountId = string;
export type AccountIdList = string[];
export declare const AccountIdList: any;
export interface AssociateAccountsInput {
    Arn: string;
    AccountIds: string[];
}
export declare const AssociateAccountsInput: S.Schema<AssociateAccountsInput>;
export interface AssociateAccountsOutput {
    Arn?: string;
}
export declare const AssociateAccountsOutput: S.Schema<AssociateAccountsOutput>;
export type PricingPlanArn = string;
export type PricingRuleArn = string;
export type PricingRuleArnsNonEmptyInput = string[];
export declare const PricingRuleArnsNonEmptyInput: any;
export interface AssociatePricingRulesInput {
    Arn: string;
    PricingRuleArns: string[];
}
export declare const AssociatePricingRulesInput: S.Schema<AssociatePricingRulesInput>;
export interface AssociatePricingRulesOutput {
    Arn?: string;
}
export declare const AssociatePricingRulesOutput: S.Schema<AssociatePricingRulesOutput>;
export type CustomLineItemArn = string;
export type CustomLineItemAssociationElement = string;
export type CustomLineItemBatchAssociationsList = string[];
export declare const CustomLineItemBatchAssociationsList: any;
export type BillingPeriod = string;
export interface CustomLineItemBillingPeriodRange {
    InclusiveStartBillingPeriod: string;
    ExclusiveEndBillingPeriod?: string;
}
export declare const CustomLineItemBillingPeriodRange: S.Schema<CustomLineItemBillingPeriodRange>;
export interface BatchAssociateResourcesToCustomLineItemInput {
    TargetArn: string;
    ResourceArns: string[];
    BillingPeriodRange?: CustomLineItemBillingPeriodRange;
}
export declare const BatchAssociateResourcesToCustomLineItemInput: S.Schema<BatchAssociateResourcesToCustomLineItemInput>;
export type AssociateResourceErrorReason = "INVALID_ARN" | "SERVICE_LIMIT_EXCEEDED" | "ILLEGAL_CUSTOMLINEITEM" | "INTERNAL_SERVER_EXCEPTION" | "INVALID_BILLING_PERIOD_RANGE" | (string & {});
export declare const AssociateResourceErrorReason: any;
export interface AssociateResourceError {
    Message?: string;
    Reason?: AssociateResourceErrorReason;
}
export declare const AssociateResourceError: S.Schema<AssociateResourceError>;
export interface AssociateResourceResponseElement {
    Arn?: string;
    Error?: AssociateResourceError;
}
export declare const AssociateResourceResponseElement: S.Schema<AssociateResourceResponseElement>;
export type AssociateResourcesResponseList = AssociateResourceResponseElement[];
export declare const AssociateResourcesResponseList: any;
export interface BatchAssociateResourcesToCustomLineItemOutput {
    SuccessfullyAssociatedResources?: AssociateResourceResponseElement[];
    FailedAssociatedResources?: AssociateResourceResponseElement[];
}
export declare const BatchAssociateResourcesToCustomLineItemOutput: S.Schema<BatchAssociateResourcesToCustomLineItemOutput>;
export type CustomLineItemBatchDisassociationsList = string[];
export declare const CustomLineItemBatchDisassociationsList: any;
export interface BatchDisassociateResourcesFromCustomLineItemInput {
    TargetArn: string;
    ResourceArns: string[];
    BillingPeriodRange?: CustomLineItemBillingPeriodRange;
}
export declare const BatchDisassociateResourcesFromCustomLineItemInput: S.Schema<BatchDisassociateResourcesFromCustomLineItemInput>;
export interface DisassociateResourceResponseElement {
    Arn?: string;
    Error?: AssociateResourceError;
}
export declare const DisassociateResourceResponseElement: S.Schema<DisassociateResourceResponseElement>;
export type DisassociateResourcesResponseList = DisassociateResourceResponseElement[];
export declare const DisassociateResourcesResponseList: any;
export interface BatchDisassociateResourcesFromCustomLineItemOutput {
    SuccessfullyDisassociatedResources?: DisassociateResourceResponseElement[];
    FailedDisassociatedResources?: DisassociateResourceResponseElement[];
}
export declare const BatchDisassociateResourcesFromCustomLineItemOutput: S.Schema<BatchDisassociateResourcesFromCustomLineItemOutput>;
export type ClientToken = string;
export type BillingGroupName = string | redacted.Redacted<string>;
export type ResponsibilityTransferArn = string;
export interface AccountGrouping {
    LinkedAccountIds?: string[];
    AutoAssociate?: boolean;
    ResponsibilityTransferArn?: string;
}
export declare const AccountGrouping: S.Schema<AccountGrouping>;
export type PricingPlanFullArn = string;
export interface ComputationPreference {
    PricingPlanArn: string;
}
export declare const ComputationPreference: S.Schema<ComputationPreference>;
export type BillingGroupDescription = string | redacted.Redacted<string>;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateBillingGroupInput {
    ClientToken?: string;
    Name: string | redacted.Redacted<string>;
    AccountGrouping: AccountGrouping;
    ComputationPreference: ComputationPreference;
    PrimaryAccountId?: string;
    Description?: string | redacted.Redacted<string>;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateBillingGroupInput: S.Schema<CreateBillingGroupInput>;
export interface CreateBillingGroupOutput {
    Arn?: string;
}
export declare const CreateBillingGroupOutput: S.Schema<CreateBillingGroupOutput>;
export type CustomLineItemName = string | redacted.Redacted<string>;
export type CustomLineItemDescription = string | redacted.Redacted<string>;
export type CustomLineItemChargeValue = number;
export interface CustomLineItemFlatChargeDetails {
    ChargeValue: number;
}
export declare const CustomLineItemFlatChargeDetails: S.Schema<CustomLineItemFlatChargeDetails>;
export type CustomLineItemPercentageChargeValue = number;
export type CustomLineItemAssociationsList = string[];
export declare const CustomLineItemAssociationsList: any;
export interface CustomLineItemPercentageChargeDetails {
    PercentageValue: number;
    AssociatedValues?: string[];
}
export declare const CustomLineItemPercentageChargeDetails: S.Schema<CustomLineItemPercentageChargeDetails>;
export type CustomLineItemType = "CREDIT" | "FEE" | (string & {});
export declare const CustomLineItemType: any;
export type LineItemFilterAttributeName = "LINE_ITEM_TYPE" | "SERVICE" | (string & {});
export declare const LineItemFilterAttributeName: any;
export type MatchOption = "NOT_EQUAL" | "EQUAL" | (string & {});
export declare const MatchOption: any;
export type LineItemFilterValue = "SAVINGS_PLAN_NEGATION" | (string & {});
export declare const LineItemFilterValue: any;
export type LineItemFilterValuesList = LineItemFilterValue[];
export declare const LineItemFilterValuesList: any;
export type AttributeValue = string;
export type AttributeValueList = string[];
export declare const AttributeValueList: any;
export interface LineItemFilter {
    Attribute: LineItemFilterAttributeName;
    MatchOption: MatchOption;
    Values?: LineItemFilterValue[];
    AttributeValues?: string[];
}
export declare const LineItemFilter: S.Schema<LineItemFilter>;
export type LineItemFiltersList = LineItemFilter[];
export declare const LineItemFiltersList: any;
export interface CustomLineItemChargeDetails {
    Flat?: CustomLineItemFlatChargeDetails;
    Percentage?: CustomLineItemPercentageChargeDetails;
    Type: CustomLineItemType;
    LineItemFilters?: LineItemFilter[];
}
export declare const CustomLineItemChargeDetails: S.Schema<CustomLineItemChargeDetails>;
export type ComputationRuleEnum = "ITEMIZED" | "CONSOLIDATED" | (string & {});
export declare const ComputationRuleEnum: any;
export type Service = string;
export interface PresentationObject {
    Service: string;
}
export declare const PresentationObject: S.Schema<PresentationObject>;
export interface CreateCustomLineItemInput {
    ClientToken?: string;
    Name: string | redacted.Redacted<string>;
    Description: string | redacted.Redacted<string>;
    BillingGroupArn: string;
    BillingPeriodRange?: CustomLineItemBillingPeriodRange;
    Tags?: {
        [key: string]: string | undefined;
    };
    ChargeDetails: CustomLineItemChargeDetails;
    AccountId?: string;
    ComputationRule?: ComputationRuleEnum;
    PresentationDetails?: PresentationObject;
}
export declare const CreateCustomLineItemInput: S.Schema<CreateCustomLineItemInput>;
export interface CreateCustomLineItemOutput {
    Arn?: string;
}
export declare const CreateCustomLineItemOutput: S.Schema<CreateCustomLineItemOutput>;
export type PricingPlanName = string | redacted.Redacted<string>;
export type PricingPlanDescription = string | redacted.Redacted<string>;
export type PricingRuleArnsInput = string[];
export declare const PricingRuleArnsInput: any;
export interface CreatePricingPlanInput {
    ClientToken?: string;
    Name: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    PricingRuleArns?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePricingPlanInput: S.Schema<CreatePricingPlanInput>;
export interface CreatePricingPlanOutput {
    Arn?: string;
}
export declare const CreatePricingPlanOutput: S.Schema<CreatePricingPlanOutput>;
export type PricingRuleName = string | redacted.Redacted<string>;
export type PricingRuleDescription = string | redacted.Redacted<string>;
export type PricingRuleScope = "GLOBAL" | "SERVICE" | "BILLING_ENTITY" | "SKU" | (string & {});
export declare const PricingRuleScope: any;
export type PricingRuleType = "MARKUP" | "DISCOUNT" | "TIERING" | (string & {});
export declare const PricingRuleType: any;
export type ModifierPercentage = number;
export type BillingEntity = string;
export type TieringActivated = boolean;
export interface CreateFreeTierConfig {
    Activated: boolean;
}
export declare const CreateFreeTierConfig: S.Schema<CreateFreeTierConfig>;
export interface CreateTieringInput {
    FreeTier: CreateFreeTierConfig;
}
export declare const CreateTieringInput: S.Schema<CreateTieringInput>;
export type UsageType = string;
export type Operation = string;
export interface CreatePricingRuleInput {
    ClientToken?: string;
    Name: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    Scope: PricingRuleScope;
    Type: PricingRuleType;
    ModifierPercentage?: number;
    Service?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    BillingEntity?: string;
    Tiering?: CreateTieringInput;
    UsageType?: string;
    Operation?: string;
}
export declare const CreatePricingRuleInput: S.Schema<CreatePricingRuleInput>;
export interface CreatePricingRuleOutput {
    Arn?: string;
}
export declare const CreatePricingRuleOutput: S.Schema<CreatePricingRuleOutput>;
export interface DeleteBillingGroupInput {
    Arn: string;
}
export declare const DeleteBillingGroupInput: S.Schema<DeleteBillingGroupInput>;
export interface DeleteBillingGroupOutput {
    Arn?: string;
}
export declare const DeleteBillingGroupOutput: S.Schema<DeleteBillingGroupOutput>;
export interface DeleteCustomLineItemInput {
    Arn: string;
    BillingPeriodRange?: CustomLineItemBillingPeriodRange;
}
export declare const DeleteCustomLineItemInput: S.Schema<DeleteCustomLineItemInput>;
export interface DeleteCustomLineItemOutput {
    Arn?: string;
}
export declare const DeleteCustomLineItemOutput: S.Schema<DeleteCustomLineItemOutput>;
export interface DeletePricingPlanInput {
    Arn: string;
}
export declare const DeletePricingPlanInput: S.Schema<DeletePricingPlanInput>;
export interface DeletePricingPlanOutput {
    Arn?: string;
}
export declare const DeletePricingPlanOutput: S.Schema<DeletePricingPlanOutput>;
export interface DeletePricingRuleInput {
    Arn: string;
}
export declare const DeletePricingRuleInput: S.Schema<DeletePricingRuleInput>;
export interface DeletePricingRuleOutput {
    Arn?: string;
}
export declare const DeletePricingRuleOutput: S.Schema<DeletePricingRuleOutput>;
export interface DisassociateAccountsInput {
    Arn: string;
    AccountIds: string[];
}
export declare const DisassociateAccountsInput: S.Schema<DisassociateAccountsInput>;
export interface DisassociateAccountsOutput {
    Arn?: string;
}
export declare const DisassociateAccountsOutput: S.Schema<DisassociateAccountsOutput>;
export interface DisassociatePricingRulesInput {
    Arn: string;
    PricingRuleArns: string[];
}
export declare const DisassociatePricingRulesInput: S.Schema<DisassociatePricingRulesInput>;
export interface DisassociatePricingRulesOutput {
    Arn?: string;
}
export declare const DisassociatePricingRulesOutput: S.Schema<DisassociatePricingRulesOutput>;
export interface BillingPeriodRange {
    InclusiveStartBillingPeriod: string;
    ExclusiveEndBillingPeriod: string;
}
export declare const BillingPeriodRange: S.Schema<BillingPeriodRange>;
export type GroupByAttributeName = "PRODUCT_NAME" | "BILLING_PERIOD" | (string & {});
export declare const GroupByAttributeName: any;
export type GroupByAttributesList = GroupByAttributeName[];
export declare const GroupByAttributesList: any;
export type MaxBillingGroupCostReportResults = number;
export type Token = string;
export interface GetBillingGroupCostReportInput {
    Arn: string;
    BillingPeriodRange?: BillingPeriodRange;
    GroupBy?: GroupByAttributeName[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const GetBillingGroupCostReportInput: S.Schema<GetBillingGroupCostReportInput>;
export type AWSCost = string;
export type ProformaCost = string;
export type Margin = string;
export type MarginPercentage = string;
export type Currency = string;
export interface Attribute {
    Key?: string;
    Value?: string;
}
export declare const Attribute: S.Schema<Attribute>;
export type AttributesList = Attribute[];
export declare const AttributesList: any;
export interface BillingGroupCostReportResultElement {
    Arn?: string;
    AWSCost?: string;
    ProformaCost?: string;
    Margin?: string;
    MarginPercentage?: string;
    Currency?: string;
    Attributes?: Attribute[];
}
export declare const BillingGroupCostReportResultElement: S.Schema<BillingGroupCostReportResultElement>;
export type BillingGroupCostReportResultsList = BillingGroupCostReportResultElement[];
export declare const BillingGroupCostReportResultsList: any;
export interface GetBillingGroupCostReportOutput {
    BillingGroupCostReportResults?: BillingGroupCostReportResultElement[];
    NextToken?: string;
}
export declare const GetBillingGroupCostReportOutput: S.Schema<GetBillingGroupCostReportOutput>;
export type Association = string;
export type AccountIdFilterList = string[];
export declare const AccountIdFilterList: any;
export interface ListAccountAssociationsFilter {
    Association?: string;
    AccountId?: string;
    AccountIds?: string[];
}
export declare const ListAccountAssociationsFilter: S.Schema<ListAccountAssociationsFilter>;
export interface ListAccountAssociationsInput {
    BillingPeriod?: string;
    Filters?: ListAccountAssociationsFilter;
    NextToken?: string;
}
export declare const ListAccountAssociationsInput: S.Schema<ListAccountAssociationsInput>;
export type AccountName = string | redacted.Redacted<string>;
export type AccountEmail = string | redacted.Redacted<string>;
export interface AccountAssociationsListElement {
    AccountId?: string;
    BillingGroupArn?: string;
    AccountName?: string | redacted.Redacted<string>;
    AccountEmail?: string | redacted.Redacted<string>;
}
export declare const AccountAssociationsListElement: S.Schema<AccountAssociationsListElement>;
export type AccountAssociationsList = AccountAssociationsListElement[];
export declare const AccountAssociationsList: any;
export interface ListAccountAssociationsOutput {
    LinkedAccounts?: AccountAssociationsListElement[];
    NextToken?: string;
}
export declare const ListAccountAssociationsOutput: S.Schema<ListAccountAssociationsOutput>;
export type MaxBillingGroupResults = number;
export type BillingGroupArnList = string[];
export declare const BillingGroupArnList: any;
export interface ListBillingGroupCostReportsFilter {
    BillingGroupArns?: string[];
}
export declare const ListBillingGroupCostReportsFilter: S.Schema<ListBillingGroupCostReportsFilter>;
export interface ListBillingGroupCostReportsInput {
    BillingPeriod?: string;
    MaxResults?: number;
    NextToken?: string;
    Filters?: ListBillingGroupCostReportsFilter;
}
export declare const ListBillingGroupCostReportsInput: S.Schema<ListBillingGroupCostReportsInput>;
export interface BillingGroupCostReportElement {
    Arn?: string;
    AWSCost?: string;
    ProformaCost?: string;
    Margin?: string;
    MarginPercentage?: string;
    Currency?: string;
}
export declare const BillingGroupCostReportElement: S.Schema<BillingGroupCostReportElement>;
export type BillingGroupCostReportList = BillingGroupCostReportElement[];
export declare const BillingGroupCostReportList: any;
export interface ListBillingGroupCostReportsOutput {
    BillingGroupCostReports?: BillingGroupCostReportElement[];
    NextToken?: string;
}
export declare const ListBillingGroupCostReportsOutput: S.Schema<ListBillingGroupCostReportsOutput>;
export type BillingGroupStatus = "ACTIVE" | "PRIMARY_ACCOUNT_MISSING" | "PENDING" | (string & {});
export declare const BillingGroupStatus: any;
export type BillingGroupStatusList = BillingGroupStatus[];
export declare const BillingGroupStatusList: any;
export type PrimaryAccountIdList = string[];
export declare const PrimaryAccountIdList: any;
export type BillingGroupType = "STANDARD" | "TRANSFER_BILLING" | (string & {});
export declare const BillingGroupType: any;
export type BillingGroupTypeList = BillingGroupType[];
export declare const BillingGroupTypeList: any;
export type SearchOption = "STARTS_WITH" | (string & {});
export declare const SearchOption: any;
export type SearchValue = string;
export interface StringSearch {
    SearchOption: SearchOption;
    SearchValue: string;
}
export declare const StringSearch: S.Schema<StringSearch>;
export type StringSearches = StringSearch[];
export declare const StringSearches: any;
export type ResponsibilityTransferArnsList = string[];
export declare const ResponsibilityTransferArnsList: any;
export interface ListBillingGroupsFilter {
    Arns?: string[];
    PricingPlan?: string;
    Statuses?: BillingGroupStatus[];
    AutoAssociate?: boolean;
    PrimaryAccountIds?: string[];
    BillingGroupTypes?: BillingGroupType[];
    Names?: StringSearch[];
    ResponsibilityTransferArns?: string[];
}
export declare const ListBillingGroupsFilter: S.Schema<ListBillingGroupsFilter>;
export interface ListBillingGroupsInput {
    BillingPeriod?: string;
    MaxResults?: number;
    NextToken?: string;
    Filters?: ListBillingGroupsFilter;
}
export declare const ListBillingGroupsInput: S.Schema<ListBillingGroupsInput>;
export type NumberOfAccounts = number;
export type Instant = number;
export type BillingGroupStatusReason = string;
export interface ListBillingGroupAccountGrouping {
    AutoAssociate?: boolean;
    ResponsibilityTransferArn?: string;
}
export declare const ListBillingGroupAccountGrouping: S.Schema<ListBillingGroupAccountGrouping>;
export interface BillingGroupListElement {
    Name?: string | redacted.Redacted<string>;
    Arn?: string;
    Description?: string | redacted.Redacted<string>;
    PrimaryAccountId?: string;
    ComputationPreference?: ComputationPreference;
    Size?: number;
    CreationTime?: number;
    LastModifiedTime?: number;
    Status?: BillingGroupStatus;
    StatusReason?: string;
    AccountGrouping?: ListBillingGroupAccountGrouping;
    BillingGroupType?: BillingGroupType;
}
export declare const BillingGroupListElement: S.Schema<BillingGroupListElement>;
export type BillingGroupList = BillingGroupListElement[];
export declare const BillingGroupList: any;
export interface ListBillingGroupsOutput {
    BillingGroups?: BillingGroupListElement[];
    NextToken?: string;
}
export declare const ListBillingGroupsOutput: S.Schema<ListBillingGroupsOutput>;
export type MaxCustomLineItemResults = number;
export type CustomLineItemNameList = (string | redacted.Redacted<string>)[];
export declare const CustomLineItemNameList: any;
export type CustomLineItemArns = string[];
export declare const CustomLineItemArns: any;
export interface ListCustomLineItemsFilter {
    Names?: (string | redacted.Redacted<string>)[];
    BillingGroups?: string[];
    Arns?: string[];
    AccountIds?: string[];
}
export declare const ListCustomLineItemsFilter: S.Schema<ListCustomLineItemsFilter>;
export interface ListCustomLineItemsInput {
    BillingPeriod?: string;
    MaxResults?: number;
    NextToken?: string;
    Filters?: ListCustomLineItemsFilter;
}
export declare const ListCustomLineItemsInput: S.Schema<ListCustomLineItemsInput>;
export interface ListCustomLineItemFlatChargeDetails {
    ChargeValue: number;
}
export declare const ListCustomLineItemFlatChargeDetails: S.Schema<ListCustomLineItemFlatChargeDetails>;
export interface ListCustomLineItemPercentageChargeDetails {
    PercentageValue: number;
}
export declare const ListCustomLineItemPercentageChargeDetails: S.Schema<ListCustomLineItemPercentageChargeDetails>;
export interface ListCustomLineItemChargeDetails {
    Flat?: ListCustomLineItemFlatChargeDetails;
    Percentage?: ListCustomLineItemPercentageChargeDetails;
    Type: CustomLineItemType;
    LineItemFilters?: LineItemFilter[];
}
export declare const ListCustomLineItemChargeDetails: S.Schema<ListCustomLineItemChargeDetails>;
export type CurrencyCode = "USD" | "CNY" | (string & {});
export declare const CurrencyCode: any;
export type CustomLineItemProductCode = string;
export type NumberOfAssociations = number;
export interface CustomLineItemListElement {
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    ChargeDetails?: ListCustomLineItemChargeDetails;
    CurrencyCode?: CurrencyCode;
    Description?: string | redacted.Redacted<string>;
    ProductCode?: string;
    BillingGroupArn?: string;
    CreationTime?: number;
    LastModifiedTime?: number;
    AssociationSize?: number;
    AccountId?: string;
    ComputationRule?: ComputationRuleEnum;
    PresentationDetails?: PresentationObject;
}
export declare const CustomLineItemListElement: S.Schema<CustomLineItemListElement>;
export type CustomLineItemList = CustomLineItemListElement[];
export declare const CustomLineItemList: any;
export interface ListCustomLineItemsOutput {
    CustomLineItems?: CustomLineItemListElement[];
    NextToken?: string;
}
export declare const ListCustomLineItemsOutput: S.Schema<ListCustomLineItemsOutput>;
export interface ListCustomLineItemVersionsBillingPeriodRangeFilter {
    StartBillingPeriod?: string;
    EndBillingPeriod?: string;
}
export declare const ListCustomLineItemVersionsBillingPeriodRangeFilter: S.Schema<ListCustomLineItemVersionsBillingPeriodRangeFilter>;
export interface ListCustomLineItemVersionsFilter {
    BillingPeriodRange?: ListCustomLineItemVersionsBillingPeriodRangeFilter;
}
export declare const ListCustomLineItemVersionsFilter: S.Schema<ListCustomLineItemVersionsFilter>;
export interface ListCustomLineItemVersionsInput {
    Arn: string;
    MaxResults?: number;
    NextToken?: string;
    Filters?: ListCustomLineItemVersionsFilter;
}
export declare const ListCustomLineItemVersionsInput: S.Schema<ListCustomLineItemVersionsInput>;
export interface CustomLineItemVersionListElement {
    Name?: string | redacted.Redacted<string>;
    ChargeDetails?: ListCustomLineItemChargeDetails;
    CurrencyCode?: CurrencyCode;
    Description?: string | redacted.Redacted<string>;
    ProductCode?: string;
    BillingGroupArn?: string;
    CreationTime?: number;
    LastModifiedTime?: number;
    AssociationSize?: number;
    StartBillingPeriod?: string;
    EndBillingPeriod?: string;
    Arn?: string;
    StartTime?: number;
    AccountId?: string;
    ComputationRule?: ComputationRuleEnum;
    PresentationDetails?: PresentationObject;
}
export declare const CustomLineItemVersionListElement: S.Schema<CustomLineItemVersionListElement>;
export type CustomLineItemVersionList = CustomLineItemVersionListElement[];
export declare const CustomLineItemVersionList: any;
export interface ListCustomLineItemVersionsOutput {
    CustomLineItemVersions?: CustomLineItemVersionListElement[];
    NextToken?: string;
}
export declare const ListCustomLineItemVersionsOutput: S.Schema<ListCustomLineItemVersionsOutput>;
export type PricingPlanArns = string[];
export declare const PricingPlanArns: any;
export interface ListPricingPlansFilter {
    Arns?: string[];
}
export declare const ListPricingPlansFilter: S.Schema<ListPricingPlansFilter>;
export type MaxPricingPlanResults = number;
export interface ListPricingPlansInput {
    BillingPeriod?: string;
    Filters?: ListPricingPlansFilter;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListPricingPlansInput: S.Schema<ListPricingPlansInput>;
export type NumberOfAssociatedPricingRules = number;
export interface PricingPlanListElement {
    Name?: string | redacted.Redacted<string>;
    Arn?: string;
    Description?: string | redacted.Redacted<string>;
    Size?: number;
    CreationTime?: number;
    LastModifiedTime?: number;
}
export declare const PricingPlanListElement: S.Schema<PricingPlanListElement>;
export type PricingPlanList = PricingPlanListElement[];
export declare const PricingPlanList: any;
export interface ListPricingPlansOutput {
    BillingPeriod?: string;
    PricingPlans?: PricingPlanListElement[];
    NextToken?: string;
}
export declare const ListPricingPlansOutput: S.Schema<ListPricingPlansOutput>;
export type MaxPricingRuleResults = number;
export interface ListPricingPlansAssociatedWithPricingRuleInput {
    BillingPeriod?: string;
    PricingRuleArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListPricingPlansAssociatedWithPricingRuleInput: S.Schema<ListPricingPlansAssociatedWithPricingRuleInput>;
export interface ListPricingPlansAssociatedWithPricingRuleOutput {
    BillingPeriod?: string;
    PricingRuleArn?: string;
    PricingPlanArns?: string[];
    NextToken?: string;
}
export declare const ListPricingPlansAssociatedWithPricingRuleOutput: S.Schema<ListPricingPlansAssociatedWithPricingRuleOutput>;
export type PricingRuleArns = string[];
export declare const PricingRuleArns: any;
export interface ListPricingRulesFilter {
    Arns?: string[];
}
export declare const ListPricingRulesFilter: S.Schema<ListPricingRulesFilter>;
export interface ListPricingRulesInput {
    BillingPeriod?: string;
    Filters?: ListPricingRulesFilter;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListPricingRulesInput: S.Schema<ListPricingRulesInput>;
export type NumberOfPricingPlansAssociatedWith = number;
export interface FreeTierConfig {
    Activated: boolean;
}
export declare const FreeTierConfig: S.Schema<FreeTierConfig>;
export interface Tiering {
    FreeTier: FreeTierConfig;
}
export declare const Tiering: S.Schema<Tiering>;
export interface PricingRuleListElement {
    Name?: string | redacted.Redacted<string>;
    Arn?: string;
    Description?: string | redacted.Redacted<string>;
    Scope?: PricingRuleScope;
    Type?: PricingRuleType;
    ModifierPercentage?: number;
    Service?: string;
    AssociatedPricingPlanCount?: number;
    CreationTime?: number;
    LastModifiedTime?: number;
    BillingEntity?: string;
    Tiering?: Tiering;
    UsageType?: string;
    Operation?: string;
}
export declare const PricingRuleListElement: S.Schema<PricingRuleListElement>;
export type PricingRuleList = PricingRuleListElement[];
export declare const PricingRuleList: any;
export interface ListPricingRulesOutput {
    BillingPeriod?: string;
    PricingRules?: PricingRuleListElement[];
    NextToken?: string;
}
export declare const ListPricingRulesOutput: S.Schema<ListPricingRulesOutput>;
export interface ListPricingRulesAssociatedToPricingPlanInput {
    BillingPeriod?: string;
    PricingPlanArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListPricingRulesAssociatedToPricingPlanInput: S.Schema<ListPricingRulesAssociatedToPricingPlanInput>;
export interface ListPricingRulesAssociatedToPricingPlanOutput {
    BillingPeriod?: string;
    PricingPlanArn?: string;
    PricingRuleArns?: string[];
    NextToken?: string;
}
export declare const ListPricingRulesAssociatedToPricingPlanOutput: S.Schema<ListPricingRulesAssociatedToPricingPlanOutput>;
export type CustomLineItemRelationship = "PARENT" | "CHILD" | (string & {});
export declare const CustomLineItemRelationship: any;
export interface ListResourcesAssociatedToCustomLineItemFilter {
    Relationship?: CustomLineItemRelationship;
}
export declare const ListResourcesAssociatedToCustomLineItemFilter: S.Schema<ListResourcesAssociatedToCustomLineItemFilter>;
export interface ListResourcesAssociatedToCustomLineItemInput {
    BillingPeriod?: string;
    Arn: string;
    MaxResults?: number;
    NextToken?: string;
    Filters?: ListResourcesAssociatedToCustomLineItemFilter;
}
export declare const ListResourcesAssociatedToCustomLineItemInput: S.Schema<ListResourcesAssociatedToCustomLineItemInput>;
export interface ListResourcesAssociatedToCustomLineItemResponseElement {
    Arn?: string;
    Relationship?: CustomLineItemRelationship;
    EndBillingPeriod?: string;
}
export declare const ListResourcesAssociatedToCustomLineItemResponseElement: S.Schema<ListResourcesAssociatedToCustomLineItemResponseElement>;
export type ListResourcesAssociatedToCustomLineItemResponseList = ListResourcesAssociatedToCustomLineItemResponseElement[];
export declare const ListResourcesAssociatedToCustomLineItemResponseList: any;
export interface ListResourcesAssociatedToCustomLineItemOutput {
    Arn?: string;
    AssociatedResources?: ListResourcesAssociatedToCustomLineItemResponseElement[];
    NextToken?: string;
}
export declare const ListResourcesAssociatedToCustomLineItemOutput: S.Schema<ListResourcesAssociatedToCustomLineItemOutput>;
export type Arn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateBillingGroupAccountGrouping {
    AutoAssociate?: boolean;
    ResponsibilityTransferArn?: string;
}
export declare const UpdateBillingGroupAccountGrouping: S.Schema<UpdateBillingGroupAccountGrouping>;
export interface UpdateBillingGroupInput {
    Arn: string;
    Name?: string | redacted.Redacted<string>;
    Status?: BillingGroupStatus;
    ComputationPreference?: ComputationPreference;
    Description?: string | redacted.Redacted<string>;
    AccountGrouping?: UpdateBillingGroupAccountGrouping;
}
export declare const UpdateBillingGroupInput: S.Schema<UpdateBillingGroupInput>;
export interface UpdateBillingGroupOutput {
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    PrimaryAccountId?: string;
    PricingPlanArn?: string;
    Size?: number;
    LastModifiedTime?: number;
    Status?: BillingGroupStatus;
    StatusReason?: string;
    AccountGrouping?: UpdateBillingGroupAccountGrouping;
}
export declare const UpdateBillingGroupOutput: S.Schema<UpdateBillingGroupOutput>;
export interface UpdateCustomLineItemFlatChargeDetails {
    ChargeValue: number;
}
export declare const UpdateCustomLineItemFlatChargeDetails: S.Schema<UpdateCustomLineItemFlatChargeDetails>;
export interface UpdateCustomLineItemPercentageChargeDetails {
    PercentageValue: number;
}
export declare const UpdateCustomLineItemPercentageChargeDetails: S.Schema<UpdateCustomLineItemPercentageChargeDetails>;
export interface UpdateCustomLineItemChargeDetails {
    Flat?: UpdateCustomLineItemFlatChargeDetails;
    Percentage?: UpdateCustomLineItemPercentageChargeDetails;
    LineItemFilters?: LineItemFilter[];
}
export declare const UpdateCustomLineItemChargeDetails: S.Schema<UpdateCustomLineItemChargeDetails>;
export interface UpdateCustomLineItemInput {
    Arn: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    ChargeDetails?: UpdateCustomLineItemChargeDetails;
    BillingPeriodRange?: CustomLineItemBillingPeriodRange;
}
export declare const UpdateCustomLineItemInput: S.Schema<UpdateCustomLineItemInput>;
export type BillingGroupFullArn = string;
export interface UpdateCustomLineItemOutput {
    Arn?: string;
    BillingGroupArn?: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    ChargeDetails?: ListCustomLineItemChargeDetails;
    LastModifiedTime?: number;
    AssociationSize?: number;
}
export declare const UpdateCustomLineItemOutput: S.Schema<UpdateCustomLineItemOutput>;
export interface UpdatePricingPlanInput {
    Arn: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
}
export declare const UpdatePricingPlanInput: S.Schema<UpdatePricingPlanInput>;
export interface UpdatePricingPlanOutput {
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    Size?: number;
    LastModifiedTime?: number;
}
export declare const UpdatePricingPlanOutput: S.Schema<UpdatePricingPlanOutput>;
export interface UpdateFreeTierConfig {
    Activated: boolean;
}
export declare const UpdateFreeTierConfig: S.Schema<UpdateFreeTierConfig>;
export interface UpdateTieringInput {
    FreeTier: UpdateFreeTierConfig;
}
export declare const UpdateTieringInput: S.Schema<UpdateTieringInput>;
export interface UpdatePricingRuleInput {
    Arn: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    Type?: PricingRuleType;
    ModifierPercentage?: number;
    Tiering?: UpdateTieringInput;
}
export declare const UpdatePricingRuleInput: S.Schema<UpdatePricingRuleInput>;
export interface UpdatePricingRuleOutput {
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    Scope?: PricingRuleScope;
    Type?: PricingRuleType;
    ModifierPercentage?: number;
    Service?: string;
    AssociatedPricingPlanCount?: number;
    LastModifiedTime?: number;
    BillingEntity?: string;
    Tiering?: UpdateTieringInput;
    UsageType?: string;
    Operation?: string;
}
export declare const UpdatePricingRuleOutput: S.Schema<UpdatePricingRuleOutput>;
export type ConflictExceptionReason = "RESOURCE_NAME_CONFLICT" | "PRICING_RULE_IN_PRICING_PLAN_CONFLICT" | "PRICING_PLAN_ATTACHED_TO_BILLING_GROUP_DELETE_CONFLICT" | "PRICING_RULE_ATTACHED_TO_PRICING_PLAN_DELETE_CONFLICT" | "WRITE_CONFLICT_RETRY" | (string & {});
export declare const ConflictExceptionReason: any;
export type RetryAfterSeconds = number;
export type ValidationExceptionReason = "UNKNOWN_OPERATION" | "CANNOT_PARSE" | "FIELD_VALIDATION_FAILED" | "OTHER" | "PRIMARY_NOT_ASSOCIATED" | "PRIMARY_CANNOT_DISASSOCIATE" | "ACCOUNTS_NOT_ASSOCIATED" | "ACCOUNTS_ALREADY_ASSOCIATED" | "ILLEGAL_PRIMARY_ACCOUNT" | "ILLEGAL_ACCOUNTS" | "MISMATCHED_BILLINGGROUP_ARN" | "MISSING_BILLINGGROUP" | "MISMATCHED_CUSTOMLINEITEM_ARN" | "ILLEGAL_BILLING_PERIOD" | "ILLEGAL_BILLING_PERIOD_RANGE" | "TOO_MANY_ACCOUNTS_IN_REQUEST" | "DUPLICATE_ACCOUNT" | "INVALID_BILLING_GROUP_STATUS" | "MISMATCHED_PRICINGPLAN_ARN" | "MISSING_PRICINGPLAN" | "MISMATCHED_PRICINGRULE_ARN" | "DUPLICATE_PRICINGRULE_ARNS" | "MISSING_COSTCATEGORY" | "ILLEGAL_EXPRESSION" | "ILLEGAL_SCOPE" | "ILLEGAL_SERVICE" | "PRICINGRULES_NOT_EXIST" | "PRICINGRULES_ALREADY_ASSOCIATED" | "PRICINGRULES_NOT_ASSOCIATED" | "INVALID_TIME_RANGE" | "INVALID_BILLINGVIEW_ARN" | "MISMATCHED_BILLINGVIEW_ARN" | "ILLEGAL_CUSTOMLINEITEM" | "MISSING_CUSTOMLINEITEM" | "ILLEGAL_CUSTOMLINEITEM_UPDATE" | "TOO_MANY_CUSTOMLINEITEMS_IN_REQUEST" | "ILLEGAL_CHARGE_DETAILS" | "ILLEGAL_UPDATE_CHARGE_DETAILS" | "INVALID_ARN" | "ILLEGAL_RESOURCE_ARNS" | "ILLEGAL_CUSTOMLINEITEM_MODIFICATION" | "MISSING_LINKED_ACCOUNT_IDS" | "MULTIPLE_LINKED_ACCOUNT_IDS" | "MISSING_PRICING_PLAN_ARN" | "MULTIPLE_PRICING_PLAN_ARN" | "ILLEGAL_CHILD_ASSOCIATE_RESOURCE" | "CUSTOM_LINE_ITEM_ASSOCIATION_EXISTS" | "INVALID_BILLING_GROUP" | "INVALID_BILLING_PERIOD_FOR_OPERATION" | "ILLEGAL_BILLING_ENTITY" | "ILLEGAL_MODIFIER_PERCENTAGE" | "ILLEGAL_TYPE" | "ILLEGAL_BILLING_GROUP_TYPE" | "ILLEGAL_BILLING_GROUP_PRICING_PLAN" | "ILLEGAL_ENDED_BILLINGGROUP" | "ILLEGAL_TIERING_INPUT" | "ILLEGAL_OPERATION" | "ILLEGAL_USAGE_TYPE" | "INVALID_SKU_COMBO" | "INVALID_FILTER" | "TOO_MANY_AUTO_ASSOCIATE_BILLING_GROUPS" | "CANNOT_DELETE_AUTO_ASSOCIATE_BILLING_GROUP" | "ILLEGAL_ACCOUNT_ID" | "BILLING_GROUP_ALREADY_EXIST_IN_CURRENT_BILLING_PERIOD" | "ILLEGAL_COMPUTATION_RULE" | "ILLEGAL_LINE_ITEM_FILTER" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type AssociateAccountsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Connects an array of account IDs in a consolidated billing family to a predefined billing group. The account IDs must be a part of the consolidated billing family during the current month, and not already associated with another billing group. The maximum number of accounts that can be associated in one call is 30.
 */
export declare const associateAccounts: API.OperationMethod<AssociateAccountsInput, AssociateAccountsOutput, AssociateAccountsError, Credentials | HttpClient.HttpClient>;
export type AssociatePricingRulesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Connects an array of `PricingRuleArns` to a defined `PricingPlan`. The maximum number `PricingRuleArn` that can be associated in one call is 30.
 */
export declare const associatePricingRules: API.OperationMethod<AssociatePricingRulesInput, AssociatePricingRulesOutput, AssociatePricingRulesError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateResourcesToCustomLineItemError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a batch of resources to a percentage custom line item.
 */
export declare const batchAssociateResourcesToCustomLineItem: API.OperationMethod<BatchAssociateResourcesToCustomLineItemInput, BatchAssociateResourcesToCustomLineItemOutput, BatchAssociateResourcesToCustomLineItemError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateResourcesFromCustomLineItemError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a batch of resources from a percentage custom line item.
 */
export declare const batchDisassociateResourcesFromCustomLineItem: API.OperationMethod<BatchDisassociateResourcesFromCustomLineItemInput, BatchDisassociateResourcesFromCustomLineItemOutput, BatchDisassociateResourcesFromCustomLineItemError, Credentials | HttpClient.HttpClient>;
export type CreateBillingGroupError = AccessDeniedException | ConflictException | InternalServerException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a billing group that resembles a consolidated billing family that Amazon Web Services charges, based off of the predefined pricing plan computation.
 */
export declare const createBillingGroup: API.OperationMethod<CreateBillingGroupInput, CreateBillingGroupOutput, CreateBillingGroupError, Credentials | HttpClient.HttpClient>;
export type CreateCustomLineItemError = AccessDeniedException | ConflictException | InternalServerException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a custom line item that can be used to create a one-time fixed charge that can be applied to a single billing group for the current or previous billing period. The one-time fixed charge is either a fee or discount.
 */
export declare const createCustomLineItem: API.OperationMethod<CreateCustomLineItemInput, CreateCustomLineItemOutput, CreateCustomLineItemError, Credentials | HttpClient.HttpClient>;
export type CreatePricingPlanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a pricing plan that is used for computing Amazon Web Services charges for billing groups.
 */
export declare const createPricingPlan: API.OperationMethod<CreatePricingPlanInput, CreatePricingPlanOutput, CreatePricingPlanError, Credentials | HttpClient.HttpClient>;
export type CreatePricingRuleError = AccessDeniedException | ConflictException | InternalServerException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a pricing rule can be associated to a pricing plan, or a set of pricing plans.
 */
export declare const createPricingRule: API.OperationMethod<CreatePricingRuleInput, CreatePricingRuleOutput, CreatePricingRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteBillingGroupError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a billing group.
 */
export declare const deleteBillingGroup: API.OperationMethod<DeleteBillingGroupInput, DeleteBillingGroupOutput, DeleteBillingGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomLineItemError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the custom line item identified by the given ARN in the current, or previous billing period.
 */
export declare const deleteCustomLineItem: API.OperationMethod<DeleteCustomLineItemInput, DeleteCustomLineItemOutput, DeleteCustomLineItemError, Credentials | HttpClient.HttpClient>;
export type DeletePricingPlanError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a pricing plan. The pricing plan must not be associated with any billing groups to delete successfully.
 */
export declare const deletePricingPlan: API.OperationMethod<DeletePricingPlanInput, DeletePricingPlanOutput, DeletePricingPlanError, Credentials | HttpClient.HttpClient>;
export type DeletePricingRuleError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the pricing rule that's identified by the input Amazon Resource Name (ARN).
 */
export declare const deletePricingRule: API.OperationMethod<DeletePricingRuleInput, DeletePricingRuleOutput, DeletePricingRuleError, Credentials | HttpClient.HttpClient>;
export type DisassociateAccountsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the specified list of account IDs from the given billing group.
 */
export declare const disassociateAccounts: API.OperationMethod<DisassociateAccountsInput, DisassociateAccountsOutput, DisassociateAccountsError, Credentials | HttpClient.HttpClient>;
export type DisassociatePricingRulesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a list of pricing rules from a pricing plan.
 */
export declare const disassociatePricingRules: API.OperationMethod<DisassociatePricingRulesInput, DisassociatePricingRulesOutput, DisassociatePricingRulesError, Credentials | HttpClient.HttpClient>;
export type GetBillingGroupCostReportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the margin summary report, which includes the Amazon Web Services cost and charged amount (pro forma cost) by Amazon Web Services service for a specific billing group.
 */
export declare const getBillingGroupCostReport: API.PaginatedOperationMethod<GetBillingGroupCostReportInput, GetBillingGroupCostReportOutput, GetBillingGroupCostReportError, Credentials | HttpClient.HttpClient, BillingGroupCostReportResultElement>;
export type ListAccountAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This is a paginated call to list linked accounts that are linked to the payer account for the specified time period. If no information is provided, the current billing period is used. The response will optionally include the billing group that's associated with the linked account.
 */
export declare const listAccountAssociations: API.PaginatedOperationMethod<ListAccountAssociationsInput, ListAccountAssociationsOutput, ListAccountAssociationsError, Credentials | HttpClient.HttpClient, AccountAssociationsListElement>;
export type ListBillingGroupCostReportsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A paginated call to retrieve a summary report of actual Amazon Web Services charges and the calculated Amazon Web Services charges based on the associated pricing plan of a billing group.
 */
export declare const listBillingGroupCostReports: API.PaginatedOperationMethod<ListBillingGroupCostReportsInput, ListBillingGroupCostReportsOutput, ListBillingGroupCostReportsError, Credentials | HttpClient.HttpClient, BillingGroupCostReportElement>;
export type ListBillingGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A paginated call to retrieve a list of billing groups for the given billing period. If you don't provide a billing group, the current billing period is used.
 */
export declare const listBillingGroups: API.PaginatedOperationMethod<ListBillingGroupsInput, ListBillingGroupsOutput, ListBillingGroupsError, Credentials | HttpClient.HttpClient, BillingGroupListElement>;
export type ListCustomLineItemsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A paginated call to get a list of all custom line items (FFLIs) for the given billing period. If you don't provide a billing period, the current billing period is used.
 */
export declare const listCustomLineItems: API.PaginatedOperationMethod<ListCustomLineItemsInput, ListCustomLineItemsOutput, ListCustomLineItemsError, Credentials | HttpClient.HttpClient, CustomLineItemListElement>;
export type ListCustomLineItemVersionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A paginated call to get a list of all custom line item versions.
 */
export declare const listCustomLineItemVersions: API.PaginatedOperationMethod<ListCustomLineItemVersionsInput, ListCustomLineItemVersionsOutput, ListCustomLineItemVersionsError, Credentials | HttpClient.HttpClient, CustomLineItemVersionListElement>;
export type ListPricingPlansError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A paginated call to get pricing plans for the given billing period. If you don't provide a billing period, the current billing period is used.
 */
export declare const listPricingPlans: API.PaginatedOperationMethod<ListPricingPlansInput, ListPricingPlansOutput, ListPricingPlansError, Credentials | HttpClient.HttpClient, PricingPlanListElement>;
export type ListPricingPlansAssociatedWithPricingRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A list of the pricing plans that are associated with a pricing rule.
 */
export declare const listPricingPlansAssociatedWithPricingRule: API.PaginatedOperationMethod<ListPricingPlansAssociatedWithPricingRuleInput, ListPricingPlansAssociatedWithPricingRuleOutput, ListPricingPlansAssociatedWithPricingRuleError, Credentials | HttpClient.HttpClient, PricingPlanArn>;
export type ListPricingRulesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes a pricing rule that can be associated to a pricing plan, or set of pricing plans.
 */
export declare const listPricingRules: API.PaginatedOperationMethod<ListPricingRulesInput, ListPricingRulesOutput, ListPricingRulesError, Credentials | HttpClient.HttpClient, PricingRuleListElement>;
export type ListPricingRulesAssociatedToPricingPlanError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the pricing rules that are associated with a pricing plan.
 */
export declare const listPricingRulesAssociatedToPricingPlan: API.PaginatedOperationMethod<ListPricingRulesAssociatedToPricingPlanInput, ListPricingRulesAssociatedToPricingPlanOutput, ListPricingRulesAssociatedToPricingPlanError, Credentials | HttpClient.HttpClient, PricingRuleArn>;
export type ListResourcesAssociatedToCustomLineItemError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the resources that are associated to a custom line item.
 */
export declare const listResourcesAssociatedToCustomLineItem: API.PaginatedOperationMethod<ListResourcesAssociatedToCustomLineItemInput, ListResourcesAssociatedToCustomLineItemOutput, ListResourcesAssociatedToCustomLineItemError, Credentials | HttpClient.HttpClient, ListResourcesAssociatedToCustomLineItemResponseElement>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A list the tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `resourceArn`. If existing tags on a resource are not specified in the request parameters, they are not changed.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBillingGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This updates an existing billing group.
 */
export declare const updateBillingGroup: API.OperationMethod<UpdateBillingGroupInput, UpdateBillingGroupOutput, UpdateBillingGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomLineItemError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an existing custom line item in the current or previous billing period.
 */
export declare const updateCustomLineItem: API.OperationMethod<UpdateCustomLineItemInput, UpdateCustomLineItemOutput, UpdateCustomLineItemError, Credentials | HttpClient.HttpClient>;
export type UpdatePricingPlanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This updates an existing pricing plan.
 */
export declare const updatePricingPlan: API.OperationMethod<UpdatePricingPlanInput, UpdatePricingPlanOutput, UpdatePricingPlanError, Credentials | HttpClient.HttpClient>;
export type UpdatePricingRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing pricing rule.
 */
export declare const updatePricingRule: API.OperationMethod<UpdatePricingRuleInput, UpdatePricingRuleOutput, UpdatePricingRuleError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=billingconductor.d.ts.map