import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
    readonly errorCode: any;
    readonly canRetry: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AgentsAlreadyRunningAssessmentException_base: S.Class<AgentsAlreadyRunningAssessmentException, S.TaggedStruct<"AgentsAlreadyRunningAssessmentException", {
    readonly message: any;
    readonly agents: any;
    readonly agentsTruncated: any;
    readonly canRetry: any;
}>, import("effect/Cause").YieldableError>;
export declare class AgentsAlreadyRunningAssessmentException extends /*@__PURE__*/ AgentsAlreadyRunningAssessmentException_base {
}
declare const AssessmentRunInProgressException_base: S.Class<AssessmentRunInProgressException, S.TaggedStruct<"AssessmentRunInProgressException", {
    readonly message: any;
    readonly assessmentRunArns: any;
    readonly assessmentRunArnsTruncated: any;
    readonly canRetry: any;
}>, import("effect/Cause").YieldableError>;
export declare class AssessmentRunInProgressException extends /*@__PURE__*/ AssessmentRunInProgressException_base {
}
declare const InternalException_base: S.Class<InternalException, S.TaggedStruct<"InternalException", {
    readonly message: any;
    readonly canRetry: any;
}>, import("effect/Cause").YieldableError>;
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InvalidCrossAccountRoleException_base: S.Class<InvalidCrossAccountRoleException, S.TaggedStruct<"InvalidCrossAccountRoleException", {
    readonly message: any;
    readonly errorCode: any;
    readonly canRetry: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidCrossAccountRoleException extends /*@__PURE__*/ InvalidCrossAccountRoleException_base {
}
declare const InvalidInputException_base: S.Class<InvalidInputException, S.TaggedStruct<"InvalidInputException", {
    readonly message: any;
    readonly errorCode: any;
    readonly canRetry: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
    readonly errorCode: any;
    readonly canRetry: any;
}>, import("effect/Cause").YieldableError>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NoSuchEntityException_base: S.Class<NoSuchEntityException, S.TaggedStruct<"NoSuchEntityException", {
    readonly message: any;
    readonly errorCode: any;
    readonly canRetry: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchEntityException extends /*@__PURE__*/ NoSuchEntityException_base {
}
declare const PreviewGenerationInProgressException_base: S.Class<PreviewGenerationInProgressException, S.TaggedStruct<"PreviewGenerationInProgressException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PreviewGenerationInProgressException extends /*@__PURE__*/ PreviewGenerationInProgressException_base {
}
declare const ServiceTemporarilyUnavailableException_base: S.Class<ServiceTemporarilyUnavailableException, S.TaggedStruct<"ServiceTemporarilyUnavailableException", {
    readonly message: any;
    readonly canRetry: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceTemporarilyUnavailableException extends /*@__PURE__*/ ServiceTemporarilyUnavailableException_base {
}
declare const UnsupportedFeatureException_base: S.Class<UnsupportedFeatureException, S.TaggedStruct<"UnsupportedFeatureException", {
    readonly message: any;
    readonly canRetry: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnsupportedFeatureException extends /*@__PURE__*/ UnsupportedFeatureException_base {
}
export type Arn = string;
export type AddRemoveAttributesFindingArnList = string[];
export declare const AddRemoveAttributesFindingArnList: any;
export type AttributeKey = string;
export type AttributeValue = string;
export interface Attribute {
    key: string;
    value?: string;
}
export declare const Attribute: S.Schema<Attribute>;
export type UserAttributeList = Attribute[];
export declare const UserAttributeList: any;
export interface AddAttributesToFindingsRequest {
    findingArns: string[];
    attributes: Attribute[];
}
export declare const AddAttributesToFindingsRequest: S.Schema<AddAttributesToFindingsRequest>;
export type FailedItemErrorCode = "INVALID_ARN" | "DUPLICATE_ARN" | "ITEM_DOES_NOT_EXIST" | "ACCESS_DENIED" | "LIMIT_EXCEEDED" | "INTERNAL_ERROR" | (string & {});
export declare const FailedItemErrorCode: any;
export interface FailedItemDetails {
    failureCode: FailedItemErrorCode;
    retryable: boolean;
}
export declare const FailedItemDetails: S.Schema<FailedItemDetails>;
export type FailedItems = {
    [key: string]: FailedItemDetails | undefined;
};
export declare const FailedItems: any;
export interface AddAttributesToFindingsResponse {
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export declare const AddAttributesToFindingsResponse: S.Schema<AddAttributesToFindingsResponse>;
export type AssessmentTargetName = string;
export interface CreateAssessmentTargetRequest {
    assessmentTargetName: string;
    resourceGroupArn?: string;
}
export declare const CreateAssessmentTargetRequest: S.Schema<CreateAssessmentTargetRequest>;
export interface CreateAssessmentTargetResponse {
    assessmentTargetArn: string;
}
export declare const CreateAssessmentTargetResponse: S.Schema<CreateAssessmentTargetResponse>;
export type AssessmentTemplateName = string;
export type AssessmentRunDuration = number;
export type AssessmentTemplateRulesPackageArnList = string[];
export declare const AssessmentTemplateRulesPackageArnList: any;
export interface CreateAssessmentTemplateRequest {
    assessmentTargetArn: string;
    assessmentTemplateName: string;
    durationInSeconds: number;
    rulesPackageArns: string[];
    userAttributesForFindings?: Attribute[];
}
export declare const CreateAssessmentTemplateRequest: S.Schema<CreateAssessmentTemplateRequest>;
export interface CreateAssessmentTemplateResponse {
    assessmentTemplateArn: string;
}
export declare const CreateAssessmentTemplateResponse: S.Schema<CreateAssessmentTemplateResponse>;
export interface CreateExclusionsPreviewRequest {
    assessmentTemplateArn: string;
}
export declare const CreateExclusionsPreviewRequest: S.Schema<CreateExclusionsPreviewRequest>;
export type UUID = string;
export interface CreateExclusionsPreviewResponse {
    previewToken: string;
}
export declare const CreateExclusionsPreviewResponse: S.Schema<CreateExclusionsPreviewResponse>;
export type TagKey = string;
export type TagValue = string;
export interface ResourceGroupTag {
    key: string;
    value?: string;
}
export declare const ResourceGroupTag: S.Schema<ResourceGroupTag>;
export type ResourceGroupTags = ResourceGroupTag[];
export declare const ResourceGroupTags: any;
export interface CreateResourceGroupRequest {
    resourceGroupTags: ResourceGroupTag[];
}
export declare const CreateResourceGroupRequest: S.Schema<CreateResourceGroupRequest>;
export interface CreateResourceGroupResponse {
    resourceGroupArn: string;
}
export declare const CreateResourceGroupResponse: S.Schema<CreateResourceGroupResponse>;
export interface DeleteAssessmentRunRequest {
    assessmentRunArn: string;
}
export declare const DeleteAssessmentRunRequest: S.Schema<DeleteAssessmentRunRequest>;
export interface DeleteAssessmentRunResponse {
}
export declare const DeleteAssessmentRunResponse: S.Schema<DeleteAssessmentRunResponse>;
export interface DeleteAssessmentTargetRequest {
    assessmentTargetArn: string;
}
export declare const DeleteAssessmentTargetRequest: S.Schema<DeleteAssessmentTargetRequest>;
export interface DeleteAssessmentTargetResponse {
}
export declare const DeleteAssessmentTargetResponse: S.Schema<DeleteAssessmentTargetResponse>;
export interface DeleteAssessmentTemplateRequest {
    assessmentTemplateArn: string;
}
export declare const DeleteAssessmentTemplateRequest: S.Schema<DeleteAssessmentTemplateRequest>;
export interface DeleteAssessmentTemplateResponse {
}
export declare const DeleteAssessmentTemplateResponse: S.Schema<DeleteAssessmentTemplateResponse>;
export type BatchDescribeArnList = string[];
export declare const BatchDescribeArnList: any;
export interface DescribeAssessmentRunsRequest {
    assessmentRunArns: string[];
}
export declare const DescribeAssessmentRunsRequest: S.Schema<DescribeAssessmentRunsRequest>;
export type AssessmentRunName = string;
export type AssessmentRunState = "CREATED" | "START_DATA_COLLECTION_PENDING" | "START_DATA_COLLECTION_IN_PROGRESS" | "COLLECTING_DATA" | "STOP_DATA_COLLECTION_PENDING" | "DATA_COLLECTED" | "START_EVALUATING_RULES_PENDING" | "EVALUATING_RULES" | "FAILED" | "ERROR" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "CANCELED" | (string & {});
export declare const AssessmentRunState: any;
export type AssessmentRulesPackageArnList = string[];
export declare const AssessmentRulesPackageArnList: any;
export interface AssessmentRunStateChange {
    stateChangedAt: Date;
    state: AssessmentRunState;
}
export declare const AssessmentRunStateChange: S.Schema<AssessmentRunStateChange>;
export type AssessmentRunStateChangeList = AssessmentRunStateChange[];
export declare const AssessmentRunStateChangeList: any;
export type InspectorEvent = "ASSESSMENT_RUN_STARTED" | "ASSESSMENT_RUN_COMPLETED" | "ASSESSMENT_RUN_STATE_CHANGED" | "FINDING_REPORTED" | "OTHER" | (string & {});
export declare const InspectorEvent: any;
export type Message = string;
export type AssessmentRunNotificationSnsStatusCode = "SUCCESS" | "TOPIC_DOES_NOT_EXIST" | "ACCESS_DENIED" | "INTERNAL_ERROR" | (string & {});
export declare const AssessmentRunNotificationSnsStatusCode: any;
export interface AssessmentRunNotification {
    date: Date;
    event: InspectorEvent;
    message?: string;
    error: boolean;
    snsTopicArn?: string;
    snsPublishStatusCode?: AssessmentRunNotificationSnsStatusCode;
}
export declare const AssessmentRunNotification: S.Schema<AssessmentRunNotification>;
export type AssessmentRunNotificationList = AssessmentRunNotification[];
export declare const AssessmentRunNotificationList: any;
export type Severity = "Low" | "Medium" | "High" | "Informational" | "Undefined" | (string & {});
export declare const Severity: any;
export type FindingCount = number;
export type AssessmentRunFindingCounts = {
    [key in Severity]?: number;
};
export declare const AssessmentRunFindingCounts: any;
export interface AssessmentRun {
    arn: string;
    name: string;
    assessmentTemplateArn: string;
    state: AssessmentRunState;
    durationInSeconds: number;
    rulesPackageArns: string[];
    userAttributesForFindings: Attribute[];
    createdAt: Date;
    startedAt?: Date;
    completedAt?: Date;
    stateChangedAt: Date;
    dataCollected: boolean;
    stateChanges: AssessmentRunStateChange[];
    notifications: AssessmentRunNotification[];
    findingCounts: {
        [key: string]: number | undefined;
    };
}
export declare const AssessmentRun: S.Schema<AssessmentRun>;
export type AssessmentRunList = AssessmentRun[];
export declare const AssessmentRunList: any;
export interface DescribeAssessmentRunsResponse {
    assessmentRuns: AssessmentRun[];
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export declare const DescribeAssessmentRunsResponse: S.Schema<DescribeAssessmentRunsResponse>;
export interface DescribeAssessmentTargetsRequest {
    assessmentTargetArns: string[];
}
export declare const DescribeAssessmentTargetsRequest: S.Schema<DescribeAssessmentTargetsRequest>;
export interface AssessmentTarget {
    arn: string;
    name: string;
    resourceGroupArn?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const AssessmentTarget: S.Schema<AssessmentTarget>;
export type AssessmentTargetList = AssessmentTarget[];
export declare const AssessmentTargetList: any;
export interface DescribeAssessmentTargetsResponse {
    assessmentTargets: AssessmentTarget[];
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export declare const DescribeAssessmentTargetsResponse: S.Schema<DescribeAssessmentTargetsResponse>;
export interface DescribeAssessmentTemplatesRequest {
    assessmentTemplateArns: string[];
}
export declare const DescribeAssessmentTemplatesRequest: S.Schema<DescribeAssessmentTemplatesRequest>;
export type ArnCount = number;
export interface AssessmentTemplate {
    arn: string;
    name: string;
    assessmentTargetArn: string;
    durationInSeconds: number;
    rulesPackageArns: string[];
    userAttributesForFindings: Attribute[];
    lastAssessmentRunArn?: string;
    assessmentRunCount: number;
    createdAt: Date;
}
export declare const AssessmentTemplate: S.Schema<AssessmentTemplate>;
export type AssessmentTemplateList = AssessmentTemplate[];
export declare const AssessmentTemplateList: any;
export interface DescribeAssessmentTemplatesResponse {
    assessmentTemplates: AssessmentTemplate[];
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export declare const DescribeAssessmentTemplatesResponse: S.Schema<DescribeAssessmentTemplatesResponse>;
export interface DescribeCrossAccountAccessRoleRequest {
}
export declare const DescribeCrossAccountAccessRoleRequest: S.Schema<DescribeCrossAccountAccessRoleRequest>;
export interface DescribeCrossAccountAccessRoleResponse {
    roleArn: string;
    valid: boolean;
    registeredAt: Date;
}
export declare const DescribeCrossAccountAccessRoleResponse: S.Schema<DescribeCrossAccountAccessRoleResponse>;
export type BatchDescribeExclusionsArnList = string[];
export declare const BatchDescribeExclusionsArnList: any;
export type Locale = "EN_US" | (string & {});
export declare const Locale: any;
export interface DescribeExclusionsRequest {
    exclusionArns: string[];
    locale?: Locale;
}
export declare const DescribeExclusionsRequest: S.Schema<DescribeExclusionsRequest>;
export type Text = string;
export type ScopeType = "INSTANCE_ID" | "RULES_PACKAGE_ARN" | (string & {});
export declare const ScopeType: any;
export type ScopeValue = string;
export interface Scope {
    key?: ScopeType;
    value?: string;
}
export declare const Scope: S.Schema<Scope>;
export type ScopeList = Scope[];
export declare const ScopeList: any;
export type AttributeList = Attribute[];
export declare const AttributeList: any;
export interface Exclusion {
    arn: string;
    title: string;
    description: string;
    recommendation: string;
    scopes: Scope[];
    attributes?: Attribute[];
}
export declare const Exclusion: S.Schema<Exclusion>;
export type ExclusionMap = {
    [key: string]: Exclusion | undefined;
};
export declare const ExclusionMap: any;
export interface DescribeExclusionsResponse {
    exclusions: {
        [key: string]: Exclusion | undefined;
    };
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export declare const DescribeExclusionsResponse: S.Schema<DescribeExclusionsResponse>;
export interface DescribeFindingsRequest {
    findingArns: string[];
    locale?: Locale;
}
export declare const DescribeFindingsRequest: S.Schema<DescribeFindingsRequest>;
export type NumericVersion = number;
export type ServiceName = string;
export interface InspectorServiceAttributes {
    schemaVersion: number;
    assessmentRunArn?: string;
    rulesPackageArn?: string;
}
export declare const InspectorServiceAttributes: S.Schema<InspectorServiceAttributes>;
export type AssetType = "ec2-instance" | (string & {});
export declare const AssetType: any;
export type AgentId = string;
export type AutoScalingGroup = string;
export type AmiId = string;
export type Hostname = string;
export type Ipv4Address = string;
export type Ipv4AddressList = string[];
export declare const Ipv4AddressList: any;
export interface Tag {
    key: string;
    value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export interface PrivateIp {
    privateDnsName?: string;
    privateIpAddress?: string;
}
export declare const PrivateIp: S.Schema<PrivateIp>;
export type PrivateIpAddresses = PrivateIp[];
export declare const PrivateIpAddresses: any;
export type Ipv6Addresses = string[];
export declare const Ipv6Addresses: any;
export interface SecurityGroup {
    groupName?: string;
    groupId?: string;
}
export declare const SecurityGroup: S.Schema<SecurityGroup>;
export type SecurityGroups = SecurityGroup[];
export declare const SecurityGroups: any;
export interface NetworkInterface {
    networkInterfaceId?: string;
    subnetId?: string;
    vpcId?: string;
    privateDnsName?: string;
    privateIpAddress?: string;
    privateIpAddresses?: PrivateIp[];
    publicDnsName?: string;
    publicIp?: string;
    ipv6Addresses?: string[];
    securityGroups?: SecurityGroup[];
}
export declare const NetworkInterface: S.Schema<NetworkInterface>;
export type NetworkInterfaces = NetworkInterface[];
export declare const NetworkInterfaces: any;
export interface AssetAttributes {
    schemaVersion: number;
    agentId?: string;
    autoScalingGroup?: string;
    amiId?: string;
    hostname?: string;
    ipv4Addresses?: string[];
    tags?: Tag[];
    networkInterfaces?: NetworkInterface[];
}
export declare const AssetAttributes: S.Schema<AssetAttributes>;
export type FindingId = string;
export type NumericSeverity = number;
export type IocConfidence = number;
export interface Finding {
    arn: string;
    schemaVersion?: number;
    service?: string;
    serviceAttributes?: InspectorServiceAttributes;
    assetType?: AssetType;
    assetAttributes?: AssetAttributes;
    id?: string;
    title?: string;
    description?: string;
    recommendation?: string;
    severity?: Severity;
    numericSeverity?: number;
    confidence?: number;
    indicatorOfCompromise?: boolean;
    attributes: Attribute[];
    userAttributes: Attribute[];
    createdAt: Date;
    updatedAt: Date;
}
export declare const Finding: S.Schema<Finding>;
export type FindingList = Finding[];
export declare const FindingList: any;
export interface DescribeFindingsResponse {
    findings: Finding[];
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export declare const DescribeFindingsResponse: S.Schema<DescribeFindingsResponse>;
export interface DescribeResourceGroupsRequest {
    resourceGroupArns: string[];
}
export declare const DescribeResourceGroupsRequest: S.Schema<DescribeResourceGroupsRequest>;
export interface ResourceGroup {
    arn: string;
    tags: ResourceGroupTag[];
    createdAt: Date;
}
export declare const ResourceGroup: S.Schema<ResourceGroup>;
export type ResourceGroupList = ResourceGroup[];
export declare const ResourceGroupList: any;
export interface DescribeResourceGroupsResponse {
    resourceGroups: ResourceGroup[];
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export declare const DescribeResourceGroupsResponse: S.Schema<DescribeResourceGroupsResponse>;
export interface DescribeRulesPackagesRequest {
    rulesPackageArns: string[];
    locale?: Locale;
}
export declare const DescribeRulesPackagesRequest: S.Schema<DescribeRulesPackagesRequest>;
export type RulesPackageName = string;
export type Version = string;
export type ProviderName = string;
export interface RulesPackage {
    arn: string;
    name: string;
    version: string;
    provider: string;
    description?: string;
}
export declare const RulesPackage: S.Schema<RulesPackage>;
export type RulesPackageList = RulesPackage[];
export declare const RulesPackageList: any;
export interface DescribeRulesPackagesResponse {
    rulesPackages: RulesPackage[];
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export declare const DescribeRulesPackagesResponse: S.Schema<DescribeRulesPackagesResponse>;
export type ReportFileFormat = "HTML" | "PDF" | (string & {});
export declare const ReportFileFormat: any;
export type ReportType = "FINDING" | "FULL" | (string & {});
export declare const ReportType: any;
export interface GetAssessmentReportRequest {
    assessmentRunArn: string;
    reportFileFormat: ReportFileFormat;
    reportType: ReportType;
}
export declare const GetAssessmentReportRequest: S.Schema<GetAssessmentReportRequest>;
export type ReportStatus = "WORK_IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export declare const ReportStatus: any;
export type Url = string;
export interface GetAssessmentReportResponse {
    status: ReportStatus;
    url?: string;
}
export declare const GetAssessmentReportResponse: S.Schema<GetAssessmentReportResponse>;
export type PaginationToken = string;
export type ListMaxResults = number;
export interface GetExclusionsPreviewRequest {
    assessmentTemplateArn: string;
    previewToken: string;
    nextToken?: string;
    maxResults?: number;
    locale?: Locale;
}
export declare const GetExclusionsPreviewRequest: S.Schema<GetExclusionsPreviewRequest>;
export type PreviewStatus = "WORK_IN_PROGRESS" | "COMPLETED" | (string & {});
export declare const PreviewStatus: any;
export interface ExclusionPreview {
    title: string;
    description: string;
    recommendation: string;
    scopes: Scope[];
    attributes?: Attribute[];
}
export declare const ExclusionPreview: S.Schema<ExclusionPreview>;
export type ExclusionPreviewList = ExclusionPreview[];
export declare const ExclusionPreviewList: any;
export interface GetExclusionsPreviewResponse {
    previewStatus: PreviewStatus;
    exclusionPreviews?: ExclusionPreview[];
    nextToken?: string;
}
export declare const GetExclusionsPreviewResponse: S.Schema<GetExclusionsPreviewResponse>;
export interface GetTelemetryMetadataRequest {
    assessmentRunArn: string;
}
export declare const GetTelemetryMetadataRequest: S.Schema<GetTelemetryMetadataRequest>;
export type MessageType = string;
export interface TelemetryMetadata {
    messageType: string;
    count: number;
    dataSize?: number;
}
export declare const TelemetryMetadata: S.Schema<TelemetryMetadata>;
export type TelemetryMetadataList = TelemetryMetadata[];
export declare const TelemetryMetadataList: any;
export interface GetTelemetryMetadataResponse {
    telemetryMetadata: TelemetryMetadata[];
}
export declare const GetTelemetryMetadataResponse: S.Schema<GetTelemetryMetadataResponse>;
export type AgentHealth = "HEALTHY" | "UNHEALTHY" | "UNKNOWN" | (string & {});
export declare const AgentHealth: any;
export type AgentHealthList = AgentHealth[];
export declare const AgentHealthList: any;
export type AgentHealthCode = "IDLE" | "RUNNING" | "SHUTDOWN" | "UNHEALTHY" | "THROTTLED" | "UNKNOWN" | (string & {});
export declare const AgentHealthCode: any;
export type AgentHealthCodeList = AgentHealthCode[];
export declare const AgentHealthCodeList: any;
export interface AgentFilter {
    agentHealths: AgentHealth[];
    agentHealthCodes: AgentHealthCode[];
}
export declare const AgentFilter: S.Schema<AgentFilter>;
export interface ListAssessmentRunAgentsRequest {
    assessmentRunArn: string;
    filter?: AgentFilter;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAssessmentRunAgentsRequest: S.Schema<ListAssessmentRunAgentsRequest>;
export interface AssessmentRunAgent {
    agentId: string;
    assessmentRunArn: string;
    agentHealth: AgentHealth;
    agentHealthCode: AgentHealthCode;
    agentHealthDetails?: string;
    autoScalingGroup?: string;
    telemetryMetadata: TelemetryMetadata[];
}
export declare const AssessmentRunAgent: S.Schema<AssessmentRunAgent>;
export type AssessmentRunAgentList = AssessmentRunAgent[];
export declare const AssessmentRunAgentList: any;
export interface ListAssessmentRunAgentsResponse {
    assessmentRunAgents: AssessmentRunAgent[];
    nextToken?: string;
}
export declare const ListAssessmentRunAgentsResponse: S.Schema<ListAssessmentRunAgentsResponse>;
export type ListParentArnList = string[];
export declare const ListParentArnList: any;
export type NamePattern = string;
export type AssessmentRunStateList = AssessmentRunState[];
export declare const AssessmentRunStateList: any;
export interface DurationRange {
    minSeconds?: number;
    maxSeconds?: number;
}
export declare const DurationRange: S.Schema<DurationRange>;
export type FilterRulesPackageArnList = string[];
export declare const FilterRulesPackageArnList: any;
export interface TimestampRange {
    beginDate?: Date;
    endDate?: Date;
}
export declare const TimestampRange: S.Schema<TimestampRange>;
export interface AssessmentRunFilter {
    namePattern?: string;
    states?: AssessmentRunState[];
    durationRange?: DurationRange;
    rulesPackageArns?: string[];
    startTimeRange?: TimestampRange;
    completionTimeRange?: TimestampRange;
    stateChangeTimeRange?: TimestampRange;
}
export declare const AssessmentRunFilter: S.Schema<AssessmentRunFilter>;
export interface ListAssessmentRunsRequest {
    assessmentTemplateArns?: string[];
    filter?: AssessmentRunFilter;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAssessmentRunsRequest: S.Schema<ListAssessmentRunsRequest>;
export type ListReturnedArnList = string[];
export declare const ListReturnedArnList: any;
export interface ListAssessmentRunsResponse {
    assessmentRunArns: string[];
    nextToken?: string;
}
export declare const ListAssessmentRunsResponse: S.Schema<ListAssessmentRunsResponse>;
export interface AssessmentTargetFilter {
    assessmentTargetNamePattern?: string;
}
export declare const AssessmentTargetFilter: S.Schema<AssessmentTargetFilter>;
export interface ListAssessmentTargetsRequest {
    filter?: AssessmentTargetFilter;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAssessmentTargetsRequest: S.Schema<ListAssessmentTargetsRequest>;
export interface ListAssessmentTargetsResponse {
    assessmentTargetArns: string[];
    nextToken?: string;
}
export declare const ListAssessmentTargetsResponse: S.Schema<ListAssessmentTargetsResponse>;
export interface AssessmentTemplateFilter {
    namePattern?: string;
    durationRange?: DurationRange;
    rulesPackageArns?: string[];
}
export declare const AssessmentTemplateFilter: S.Schema<AssessmentTemplateFilter>;
export interface ListAssessmentTemplatesRequest {
    assessmentTargetArns?: string[];
    filter?: AssessmentTemplateFilter;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAssessmentTemplatesRequest: S.Schema<ListAssessmentTemplatesRequest>;
export interface ListAssessmentTemplatesResponse {
    assessmentTemplateArns: string[];
    nextToken?: string;
}
export declare const ListAssessmentTemplatesResponse: S.Schema<ListAssessmentTemplatesResponse>;
export type ListEventSubscriptionsMaxResults = number;
export interface ListEventSubscriptionsRequest {
    resourceArn?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListEventSubscriptionsRequest: S.Schema<ListEventSubscriptionsRequest>;
export interface EventSubscription {
    event: InspectorEvent;
    subscribedAt: Date;
}
export declare const EventSubscription: S.Schema<EventSubscription>;
export type EventSubscriptionList = EventSubscription[];
export declare const EventSubscriptionList: any;
export interface Subscription {
    resourceArn: string;
    topicArn: string;
    eventSubscriptions: EventSubscription[];
}
export declare const Subscription: S.Schema<Subscription>;
export type SubscriptionList = Subscription[];
export declare const SubscriptionList: any;
export interface ListEventSubscriptionsResponse {
    subscriptions: Subscription[];
    nextToken?: string;
}
export declare const ListEventSubscriptionsResponse: S.Schema<ListEventSubscriptionsResponse>;
export interface ListExclusionsRequest {
    assessmentRunArn: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListExclusionsRequest: S.Schema<ListExclusionsRequest>;
export interface ListExclusionsResponse {
    exclusionArns: string[];
    nextToken?: string;
}
export declare const ListExclusionsResponse: S.Schema<ListExclusionsResponse>;
export type AgentIdList = string[];
export declare const AgentIdList: any;
export type AutoScalingGroupList = string[];
export declare const AutoScalingGroupList: any;
export type RuleName = string;
export type RuleNameList = string[];
export declare const RuleNameList: any;
export type SeverityList = Severity[];
export declare const SeverityList: any;
export interface FindingFilter {
    agentIds?: string[];
    autoScalingGroups?: string[];
    ruleNames?: string[];
    severities?: Severity[];
    rulesPackageArns?: string[];
    attributes?: Attribute[];
    userAttributes?: Attribute[];
    creationTimeRange?: TimestampRange;
}
export declare const FindingFilter: S.Schema<FindingFilter>;
export interface ListFindingsRequest {
    assessmentRunArns?: string[];
    filter?: FindingFilter;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListFindingsRequest: S.Schema<ListFindingsRequest>;
export interface ListFindingsResponse {
    findingArns: string[];
    nextToken?: string;
}
export declare const ListFindingsResponse: S.Schema<ListFindingsResponse>;
export interface ListRulesPackagesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListRulesPackagesRequest: S.Schema<ListRulesPackagesRequest>;
export interface ListRulesPackagesResponse {
    rulesPackageArns: string[];
    nextToken?: string;
}
export declare const ListRulesPackagesResponse: S.Schema<ListRulesPackagesResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export type TagList = Tag[];
export declare const TagList: any;
export interface ListTagsForResourceResponse {
    tags: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type PreviewAgentsMaxResults = number;
export interface PreviewAgentsRequest {
    previewAgentsArn: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const PreviewAgentsRequest: S.Schema<PreviewAgentsRequest>;
export type AgentVersion = string;
export type OperatingSystem = string;
export type KernelVersion = string;
export interface AgentPreview {
    hostname?: string;
    agentId: string;
    autoScalingGroup?: string;
    agentHealth?: AgentHealth;
    agentVersion?: string;
    operatingSystem?: string;
    kernelVersion?: string;
    ipv4Address?: string;
}
export declare const AgentPreview: S.Schema<AgentPreview>;
export type AgentPreviewList = AgentPreview[];
export declare const AgentPreviewList: any;
export interface PreviewAgentsResponse {
    agentPreviews: AgentPreview[];
    nextToken?: string;
}
export declare const PreviewAgentsResponse: S.Schema<PreviewAgentsResponse>;
export interface RegisterCrossAccountAccessRoleRequest {
    roleArn: string;
}
export declare const RegisterCrossAccountAccessRoleRequest: S.Schema<RegisterCrossAccountAccessRoleRequest>;
export interface RegisterCrossAccountAccessRoleResponse {
}
export declare const RegisterCrossAccountAccessRoleResponse: S.Schema<RegisterCrossAccountAccessRoleResponse>;
export type UserAttributeKeyList = string[];
export declare const UserAttributeKeyList: any;
export interface RemoveAttributesFromFindingsRequest {
    findingArns: string[];
    attributeKeys: string[];
}
export declare const RemoveAttributesFromFindingsRequest: S.Schema<RemoveAttributesFromFindingsRequest>;
export interface RemoveAttributesFromFindingsResponse {
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export declare const RemoveAttributesFromFindingsResponse: S.Schema<RemoveAttributesFromFindingsResponse>;
export interface SetTagsForResourceRequest {
    resourceArn: string;
    tags?: Tag[];
}
export declare const SetTagsForResourceRequest: S.Schema<SetTagsForResourceRequest>;
export interface SetTagsForResourceResponse {
}
export declare const SetTagsForResourceResponse: S.Schema<SetTagsForResourceResponse>;
export interface StartAssessmentRunRequest {
    assessmentTemplateArn: string;
    assessmentRunName?: string;
}
export declare const StartAssessmentRunRequest: S.Schema<StartAssessmentRunRequest>;
export interface StartAssessmentRunResponse {
    assessmentRunArn: string;
}
export declare const StartAssessmentRunResponse: S.Schema<StartAssessmentRunResponse>;
export type StopAction = "START_EVALUATION" | "SKIP_EVALUATION" | (string & {});
export declare const StopAction: any;
export interface StopAssessmentRunRequest {
    assessmentRunArn: string;
    stopAction?: StopAction;
}
export declare const StopAssessmentRunRequest: S.Schema<StopAssessmentRunRequest>;
export interface StopAssessmentRunResponse {
}
export declare const StopAssessmentRunResponse: S.Schema<StopAssessmentRunResponse>;
export interface SubscribeToEventRequest {
    resourceArn: string;
    event: InspectorEvent;
    topicArn: string;
}
export declare const SubscribeToEventRequest: S.Schema<SubscribeToEventRequest>;
export interface SubscribeToEventResponse {
}
export declare const SubscribeToEventResponse: S.Schema<SubscribeToEventResponse>;
export interface UnsubscribeFromEventRequest {
    resourceArn: string;
    event: InspectorEvent;
    topicArn: string;
}
export declare const UnsubscribeFromEventRequest: S.Schema<UnsubscribeFromEventRequest>;
export interface UnsubscribeFromEventResponse {
}
export declare const UnsubscribeFromEventResponse: S.Schema<UnsubscribeFromEventResponse>;
export interface UpdateAssessmentTargetRequest {
    assessmentTargetArn: string;
    assessmentTargetName: string;
    resourceGroupArn?: string;
}
export declare const UpdateAssessmentTargetRequest: S.Schema<UpdateAssessmentTargetRequest>;
export interface UpdateAssessmentTargetResponse {
}
export declare const UpdateAssessmentTargetResponse: S.Schema<UpdateAssessmentTargetResponse>;
export type ErrorMessage = string;
export type AccessDeniedErrorCode = "ACCESS_DENIED_TO_ASSESSMENT_TARGET" | "ACCESS_DENIED_TO_ASSESSMENT_TEMPLATE" | "ACCESS_DENIED_TO_ASSESSMENT_RUN" | "ACCESS_DENIED_TO_FINDING" | "ACCESS_DENIED_TO_RESOURCE_GROUP" | "ACCESS_DENIED_TO_RULES_PACKAGE" | "ACCESS_DENIED_TO_SNS_TOPIC" | "ACCESS_DENIED_TO_IAM_ROLE" | (string & {});
export declare const AccessDeniedErrorCode: any;
export type InvalidInputErrorCode = "INVALID_ASSESSMENT_TARGET_ARN" | "INVALID_ASSESSMENT_TEMPLATE_ARN" | "INVALID_ASSESSMENT_RUN_ARN" | "INVALID_FINDING_ARN" | "INVALID_RESOURCE_GROUP_ARN" | "INVALID_RULES_PACKAGE_ARN" | "INVALID_RESOURCE_ARN" | "INVALID_SNS_TOPIC_ARN" | "INVALID_IAM_ROLE_ARN" | "INVALID_ASSESSMENT_TARGET_NAME" | "INVALID_ASSESSMENT_TARGET_NAME_PATTERN" | "INVALID_ASSESSMENT_TEMPLATE_NAME" | "INVALID_ASSESSMENT_TEMPLATE_NAME_PATTERN" | "INVALID_ASSESSMENT_TEMPLATE_DURATION" | "INVALID_ASSESSMENT_TEMPLATE_DURATION_RANGE" | "INVALID_ASSESSMENT_RUN_DURATION_RANGE" | "INVALID_ASSESSMENT_RUN_START_TIME_RANGE" | "INVALID_ASSESSMENT_RUN_COMPLETION_TIME_RANGE" | "INVALID_ASSESSMENT_RUN_STATE_CHANGE_TIME_RANGE" | "INVALID_ASSESSMENT_RUN_STATE" | "INVALID_TAG" | "INVALID_TAG_KEY" | "INVALID_TAG_VALUE" | "INVALID_RESOURCE_GROUP_TAG_KEY" | "INVALID_RESOURCE_GROUP_TAG_VALUE" | "INVALID_ATTRIBUTE" | "INVALID_USER_ATTRIBUTE" | "INVALID_USER_ATTRIBUTE_KEY" | "INVALID_USER_ATTRIBUTE_VALUE" | "INVALID_PAGINATION_TOKEN" | "INVALID_MAX_RESULTS" | "INVALID_AGENT_ID" | "INVALID_AUTO_SCALING_GROUP" | "INVALID_RULE_NAME" | "INVALID_SEVERITY" | "INVALID_LOCALE" | "INVALID_EVENT" | "ASSESSMENT_TARGET_NAME_ALREADY_TAKEN" | "ASSESSMENT_TEMPLATE_NAME_ALREADY_TAKEN" | "INVALID_NUMBER_OF_ASSESSMENT_TARGET_ARNS" | "INVALID_NUMBER_OF_ASSESSMENT_TEMPLATE_ARNS" | "INVALID_NUMBER_OF_ASSESSMENT_RUN_ARNS" | "INVALID_NUMBER_OF_FINDING_ARNS" | "INVALID_NUMBER_OF_RESOURCE_GROUP_ARNS" | "INVALID_NUMBER_OF_RULES_PACKAGE_ARNS" | "INVALID_NUMBER_OF_ASSESSMENT_RUN_STATES" | "INVALID_NUMBER_OF_TAGS" | "INVALID_NUMBER_OF_RESOURCE_GROUP_TAGS" | "INVALID_NUMBER_OF_ATTRIBUTES" | "INVALID_NUMBER_OF_USER_ATTRIBUTES" | "INVALID_NUMBER_OF_AGENT_IDS" | "INVALID_NUMBER_OF_AUTO_SCALING_GROUPS" | "INVALID_NUMBER_OF_RULE_NAMES" | "INVALID_NUMBER_OF_SEVERITIES" | (string & {});
export declare const InvalidInputErrorCode: any;
export type NoSuchEntityErrorCode = "ASSESSMENT_TARGET_DOES_NOT_EXIST" | "ASSESSMENT_TEMPLATE_DOES_NOT_EXIST" | "ASSESSMENT_RUN_DOES_NOT_EXIST" | "FINDING_DOES_NOT_EXIST" | "RESOURCE_GROUP_DOES_NOT_EXIST" | "RULES_PACKAGE_DOES_NOT_EXIST" | "SNS_TOPIC_DOES_NOT_EXIST" | "IAM_ROLE_DOES_NOT_EXIST" | (string & {});
export declare const NoSuchEntityErrorCode: any;
export type InvalidCrossAccountRoleErrorCode = "ROLE_DOES_NOT_EXIST_OR_INVALID_TRUST_RELATIONSHIP" | "ROLE_DOES_NOT_HAVE_CORRECT_POLICY" | (string & {});
export declare const InvalidCrossAccountRoleErrorCode: any;
export type LimitExceededErrorCode = "ASSESSMENT_TARGET_LIMIT_EXCEEDED" | "ASSESSMENT_TEMPLATE_LIMIT_EXCEEDED" | "ASSESSMENT_RUN_LIMIT_EXCEEDED" | "RESOURCE_GROUP_LIMIT_EXCEEDED" | "EVENT_SUBSCRIPTION_LIMIT_EXCEEDED" | (string & {});
export declare const LimitExceededErrorCode: any;
export type AssessmentRunInProgressArnList = string[];
export declare const AssessmentRunInProgressArnList: any;
export interface AgentAlreadyRunningAssessment {
    agentId: string;
    assessmentRunArn: string;
}
export declare const AgentAlreadyRunningAssessment: S.Schema<AgentAlreadyRunningAssessment>;
export type AgentAlreadyRunningAssessmentList = AgentAlreadyRunningAssessment[];
export declare const AgentAlreadyRunningAssessmentList: any;
export type AddAttributesToFindingsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Assigns attributes (key and value pairs) to the findings that are specified by the
 * ARNs of the findings.
 */
export declare const addAttributesToFindings: API.OperationMethod<AddAttributesToFindingsRequest, AddAttributesToFindingsResponse, AddAttributesToFindingsError, Credentials | HttpClient.HttpClient>;
export type CreateAssessmentTargetError = AccessDeniedException | InternalException | InvalidCrossAccountRoleException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Creates a new assessment target using the ARN of the resource group that is generated
 * by CreateResourceGroup. If resourceGroupArn is not specified, all EC2
 * instances in the current AWS account and region are included in the assessment target. If
 * the service-linked role isn’t already registered, this action also creates and
 * registers a service-linked role to grant Amazon Inspector access to AWS Services needed to
 * perform security assessments. You can create up to 50 assessment targets per AWS account.
 * You can run up to 500 concurrent agents per AWS account. For more information, see
 * Amazon Inspector Assessment Targets.
 */
export declare const createAssessmentTarget: API.OperationMethod<CreateAssessmentTargetRequest, CreateAssessmentTargetResponse, CreateAssessmentTargetError, Credentials | HttpClient.HttpClient>;
export type CreateAssessmentTemplateError = AccessDeniedException | InternalException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Creates an assessment template for the assessment target that is specified by the ARN
 * of the assessment target. If the service-linked role isn’t already registered, this action also creates and
 * registers a service-linked role to grant Amazon Inspector access to AWS Services needed to
 * perform security assessments.
 */
export declare const createAssessmentTemplate: API.OperationMethod<CreateAssessmentTemplateRequest, CreateAssessmentTemplateResponse, CreateAssessmentTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateExclusionsPreviewError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | PreviewGenerationInProgressException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Starts the generation of an exclusions preview for the specified assessment template.
 * The exclusions preview lists the potential exclusions (ExclusionPreview) that Inspector can
 * detect before it runs the assessment.
 */
export declare const createExclusionsPreview: API.OperationMethod<CreateExclusionsPreviewRequest, CreateExclusionsPreviewResponse, CreateExclusionsPreviewError, Credentials | HttpClient.HttpClient>;
export type CreateResourceGroupError = AccessDeniedException | InternalException | InvalidInputException | LimitExceededException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Creates a resource group using the specified set of tags (key and value pairs) that
 * are used to select the EC2 instances to be included in an Amazon Inspector assessment
 * target. The created resource group is then used to create an Amazon Inspector assessment
 * target. For more information, see CreateAssessmentTarget.
 */
export declare const createResourceGroup: API.OperationMethod<CreateResourceGroupRequest, CreateResourceGroupResponse, CreateResourceGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteAssessmentRunError = AccessDeniedException | AssessmentRunInProgressException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Deletes the assessment run that is specified by the ARN of the assessment
 * run.
 */
export declare const deleteAssessmentRun: API.OperationMethod<DeleteAssessmentRunRequest, DeleteAssessmentRunResponse, DeleteAssessmentRunError, Credentials | HttpClient.HttpClient>;
export type DeleteAssessmentTargetError = AccessDeniedException | AssessmentRunInProgressException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Deletes the assessment target that is specified by the ARN of the assessment
 * target.
 */
export declare const deleteAssessmentTarget: API.OperationMethod<DeleteAssessmentTargetRequest, DeleteAssessmentTargetResponse, DeleteAssessmentTargetError, Credentials | HttpClient.HttpClient>;
export type DeleteAssessmentTemplateError = AccessDeniedException | AssessmentRunInProgressException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Deletes the assessment template that is specified by the ARN of the assessment
 * template.
 */
export declare const deleteAssessmentTemplate: API.OperationMethod<DeleteAssessmentTemplateRequest, DeleteAssessmentTemplateResponse, DeleteAssessmentTemplateError, Credentials | HttpClient.HttpClient>;
export type DescribeAssessmentRunsError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the assessment runs that are specified by the ARNs of the assessment
 * runs.
 */
export declare const describeAssessmentRuns: API.OperationMethod<DescribeAssessmentRunsRequest, DescribeAssessmentRunsResponse, DescribeAssessmentRunsError, Credentials | HttpClient.HttpClient>;
export type DescribeAssessmentTargetsError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the assessment targets that are specified by the ARNs of the assessment
 * targets.
 */
export declare const describeAssessmentTargets: API.OperationMethod<DescribeAssessmentTargetsRequest, DescribeAssessmentTargetsResponse, DescribeAssessmentTargetsError, Credentials | HttpClient.HttpClient>;
export type DescribeAssessmentTemplatesError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the assessment templates that are specified by the ARNs of the assessment
 * templates.
 */
export declare const describeAssessmentTemplates: API.OperationMethod<DescribeAssessmentTemplatesRequest, DescribeAssessmentTemplatesResponse, DescribeAssessmentTemplatesError, Credentials | HttpClient.HttpClient>;
export type DescribeCrossAccountAccessRoleError = InternalException | CommonErrors;
/**
 * Describes the IAM role that enables Amazon Inspector to access your AWS
 * account.
 */
export declare const describeCrossAccountAccessRole: API.OperationMethod<DescribeCrossAccountAccessRoleRequest, DescribeCrossAccountAccessRoleResponse, DescribeCrossAccountAccessRoleError, Credentials | HttpClient.HttpClient>;
export type DescribeExclusionsError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the exclusions that are specified by the exclusions' ARNs.
 */
export declare const describeExclusions: API.OperationMethod<DescribeExclusionsRequest, DescribeExclusionsResponse, DescribeExclusionsError, Credentials | HttpClient.HttpClient>;
export type DescribeFindingsError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the findings that are specified by the ARNs of the findings.
 */
export declare const describeFindings: API.OperationMethod<DescribeFindingsRequest, DescribeFindingsResponse, DescribeFindingsError, Credentials | HttpClient.HttpClient>;
export type DescribeResourceGroupsError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the resource groups that are specified by the ARNs of the resource
 * groups.
 */
export declare const describeResourceGroups: API.OperationMethod<DescribeResourceGroupsRequest, DescribeResourceGroupsResponse, DescribeResourceGroupsError, Credentials | HttpClient.HttpClient>;
export type DescribeRulesPackagesError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the rules packages that are specified by the ARNs of the rules
 * packages.
 */
export declare const describeRulesPackages: API.OperationMethod<DescribeRulesPackagesRequest, DescribeRulesPackagesResponse, DescribeRulesPackagesError, Credentials | HttpClient.HttpClient>;
export type GetAssessmentReportError = AccessDeniedException | AssessmentRunInProgressException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | UnsupportedFeatureException | CommonErrors;
/**
 * Produces an assessment report that includes detailed and comprehensive results of a
 * specified assessment run.
 */
export declare const getAssessmentReport: API.OperationMethod<GetAssessmentReportRequest, GetAssessmentReportResponse, GetAssessmentReportError, Credentials | HttpClient.HttpClient>;
export type GetExclusionsPreviewError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Retrieves the exclusions preview (a list of ExclusionPreview objects) specified by
 * the preview token. You can obtain the preview token by running the CreateExclusionsPreview
 * API.
 */
export declare const getExclusionsPreview: API.PaginatedOperationMethod<GetExclusionsPreviewRequest, GetExclusionsPreviewResponse, GetExclusionsPreviewError, Credentials | HttpClient.HttpClient, unknown>;
export type GetTelemetryMetadataError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Information about the data that is collected for the specified assessment
 * run.
 */
export declare const getTelemetryMetadata: API.OperationMethod<GetTelemetryMetadataRequest, GetTelemetryMetadataResponse, GetTelemetryMetadataError, Credentials | HttpClient.HttpClient>;
export type ListAssessmentRunAgentsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Lists the agents of the assessment runs that are specified by the ARNs of the
 * assessment runs.
 */
export declare const listAssessmentRunAgents: API.PaginatedOperationMethod<ListAssessmentRunAgentsRequest, ListAssessmentRunAgentsResponse, ListAssessmentRunAgentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAssessmentRunsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Lists the assessment runs that correspond to the assessment templates that are
 * specified by the ARNs of the assessment templates.
 */
export declare const listAssessmentRuns: API.PaginatedOperationMethod<ListAssessmentRunsRequest, ListAssessmentRunsResponse, ListAssessmentRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAssessmentTargetsError = AccessDeniedException | InternalException | InvalidInputException | CommonErrors;
/**
 * Lists the ARNs of the assessment targets within this AWS account. For more
 * information about assessment targets, see Amazon Inspector Assessment
 * Targets.
 */
export declare const listAssessmentTargets: API.PaginatedOperationMethod<ListAssessmentTargetsRequest, ListAssessmentTargetsResponse, ListAssessmentTargetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAssessmentTemplatesError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Lists the assessment templates that correspond to the assessment targets that are
 * specified by the ARNs of the assessment targets.
 */
export declare const listAssessmentTemplates: API.PaginatedOperationMethod<ListAssessmentTemplatesRequest, ListAssessmentTemplatesResponse, ListAssessmentTemplatesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEventSubscriptionsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Lists all the event subscriptions for the assessment template that is specified by
 * the ARN of the assessment template. For more information, see SubscribeToEvent and UnsubscribeFromEvent.
 */
export declare const listEventSubscriptions: API.PaginatedOperationMethod<ListEventSubscriptionsRequest, ListEventSubscriptionsResponse, ListEventSubscriptionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListExclusionsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * List exclusions that are generated by the assessment run.
 */
export declare const listExclusions: API.PaginatedOperationMethod<ListExclusionsRequest, ListExclusionsResponse, ListExclusionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFindingsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Lists findings that are generated by the assessment runs that are specified by the
 * ARNs of the assessment runs.
 */
export declare const listFindings: API.PaginatedOperationMethod<ListFindingsRequest, ListFindingsResponse, ListFindingsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRulesPackagesError = AccessDeniedException | InternalException | InvalidInputException | CommonErrors;
/**
 * Lists all available Amazon Inspector rules packages.
 */
export declare const listRulesPackages: API.PaginatedOperationMethod<ListRulesPackagesRequest, ListRulesPackagesResponse, ListRulesPackagesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Lists all tags associated with an assessment template.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PreviewAgentsError = AccessDeniedException | InternalException | InvalidCrossAccountRoleException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Previews the agents installed on the EC2 instances that are part of the specified
 * assessment target.
 */
export declare const previewAgents: API.PaginatedOperationMethod<PreviewAgentsRequest, PreviewAgentsResponse, PreviewAgentsError, Credentials | HttpClient.HttpClient, unknown>;
export type RegisterCrossAccountAccessRoleError = AccessDeniedException | InternalException | InvalidCrossAccountRoleException | InvalidInputException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Registers the IAM role that grants Amazon Inspector access to AWS Services needed to
 * perform security assessments.
 */
export declare const registerCrossAccountAccessRole: API.OperationMethod<RegisterCrossAccountAccessRoleRequest, RegisterCrossAccountAccessRoleResponse, RegisterCrossAccountAccessRoleError, Credentials | HttpClient.HttpClient>;
export type RemoveAttributesFromFindingsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Removes entire attributes (key and value pairs) from the findings that are specified
 * by the ARNs of the findings where an attribute with the specified key exists.
 */
export declare const removeAttributesFromFindings: API.OperationMethod<RemoveAttributesFromFindingsRequest, RemoveAttributesFromFindingsResponse, RemoveAttributesFromFindingsError, Credentials | HttpClient.HttpClient>;
export type SetTagsForResourceError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Sets tags (key and value pairs) to the assessment template that is specified by the
 * ARN of the assessment template.
 */
export declare const setTagsForResource: API.OperationMethod<SetTagsForResourceRequest, SetTagsForResourceResponse, SetTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartAssessmentRunError = AccessDeniedException | AgentsAlreadyRunningAssessmentException | InternalException | InvalidCrossAccountRoleException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Starts the assessment run specified by the ARN of the assessment template. For this
 * API to function properly, you must not exceed the limit of running up to 500 concurrent
 * agents per AWS account.
 */
export declare const startAssessmentRun: API.OperationMethod<StartAssessmentRunRequest, StartAssessmentRunResponse, StartAssessmentRunError, Credentials | HttpClient.HttpClient>;
export type StopAssessmentRunError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Stops the assessment run that is specified by the ARN of the assessment
 * run.
 */
export declare const stopAssessmentRun: API.OperationMethod<StopAssessmentRunRequest, StopAssessmentRunResponse, StopAssessmentRunError, Credentials | HttpClient.HttpClient>;
export type SubscribeToEventError = AccessDeniedException | InternalException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Enables the process of sending Amazon Simple Notification Service (SNS) notifications
 * about a specified event to a specified SNS topic.
 */
export declare const subscribeToEvent: API.OperationMethod<SubscribeToEventRequest, SubscribeToEventResponse, SubscribeToEventError, Credentials | HttpClient.HttpClient>;
export type UnsubscribeFromEventError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Disables the process of sending Amazon Simple Notification Service (SNS)
 * notifications about a specified event to a specified SNS topic.
 */
export declare const unsubscribeFromEvent: API.OperationMethod<UnsubscribeFromEventRequest, UnsubscribeFromEventResponse, UnsubscribeFromEventError, Credentials | HttpClient.HttpClient>;
export type UpdateAssessmentTargetError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Updates the assessment target that is specified by the ARN of the assessment
 * target.
 *
 * If resourceGroupArn is not specified, all EC2 instances in the current AWS account
 * and region are included in the assessment target.
 */
export declare const updateAssessmentTarget: API.OperationMethod<UpdateAssessmentTargetRequest, UpdateAssessmentTargetResponse, UpdateAssessmentTargetError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=inspector.d.ts.map