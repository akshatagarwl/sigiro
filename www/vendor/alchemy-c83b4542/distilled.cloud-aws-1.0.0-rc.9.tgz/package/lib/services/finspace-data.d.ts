import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials as Creds } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type PermissionGroupId = string;
export type UserId = string;
export type ClientToken = string;
export interface AssociateUserToPermissionGroupRequest {
    permissionGroupId: string;
    userId: string;
    clientToken?: string;
}
export declare const AssociateUserToPermissionGroupRequest: S.Schema<AssociateUserToPermissionGroupRequest>;
export type StatusCode = number;
export interface AssociateUserToPermissionGroupResponse {
    statusCode?: number;
}
export declare const AssociateUserToPermissionGroupResponse: S.Schema<AssociateUserToPermissionGroupResponse>;
export type DatasetId = string;
export type ChangeType = "REPLACE" | "APPEND" | "MODIFY" | (string & {});
export declare const ChangeType: any;
export type StringMapKey = string;
export type StringMapValue = string;
export type SourceParams = {
    [key: string]: string | undefined;
};
export declare const SourceParams: any;
export type FormatParams = {
    [key: string]: string | undefined;
};
export declare const FormatParams: any;
export interface CreateChangesetRequest {
    clientToken?: string;
    datasetId: string;
    changeType: ChangeType;
    sourceParams: {
        [key: string]: string | undefined;
    };
    formatParams: {
        [key: string]: string | undefined;
    };
}
export declare const CreateChangesetRequest: S.Schema<CreateChangesetRequest>;
export type ChangesetId = string;
export interface CreateChangesetResponse {
    datasetId?: string;
    changesetId?: string;
}
export declare const CreateChangesetResponse: S.Schema<CreateChangesetResponse>;
export type DatasetTitle = string;
export type DatasetKind = "TABULAR" | "NON_TABULAR" | (string & {});
export declare const DatasetKind: any;
export type DatasetDescription = string;
export type OwnerName = string;
export type PhoneNumber = string;
export type Email = string | redacted.Redacted<string>;
export interface DatasetOwnerInfo {
    name?: string;
    phoneNumber?: string;
    email?: string | redacted.Redacted<string>;
}
export declare const DatasetOwnerInfo: S.Schema<DatasetOwnerInfo>;
export type StringValueLength1to250 = string;
export interface ResourcePermission {
    permission?: string;
}
export declare const ResourcePermission: S.Schema<ResourcePermission>;
export type ResourcePermissionsList = ResourcePermission[];
export declare const ResourcePermissionsList: any;
export interface PermissionGroupParams {
    permissionGroupId?: string;
    datasetPermissions?: ResourcePermission[];
}
export declare const PermissionGroupParams: S.Schema<PermissionGroupParams>;
export type AliasString = string;
export type ColumnDataType = "STRING" | "CHAR" | "INTEGER" | "TINYINT" | "SMALLINT" | "BIGINT" | "FLOAT" | "DOUBLE" | "DATE" | "DATETIME" | "BOOLEAN" | "BINARY" | (string & {});
export declare const ColumnDataType: any;
export type ColumnName = string;
export type ColumnDescription = string;
export interface ColumnDefinition {
    dataType?: ColumnDataType;
    columnName?: string;
    columnDescription?: string;
}
export declare const ColumnDefinition: S.Schema<ColumnDefinition>;
export type ColumnList = ColumnDefinition[];
export declare const ColumnList: any;
export type ColumnNameList = string[];
export declare const ColumnNameList: any;
export interface SchemaDefinition {
    columns?: ColumnDefinition[];
    primaryKeyColumns?: string[];
}
export declare const SchemaDefinition: S.Schema<SchemaDefinition>;
export interface SchemaUnion {
    tabularSchemaConfig?: SchemaDefinition;
}
export declare const SchemaUnion: S.Schema<SchemaUnion>;
export interface CreateDatasetRequest {
    clientToken?: string;
    datasetTitle: string;
    kind: DatasetKind;
    datasetDescription?: string;
    ownerInfo?: DatasetOwnerInfo;
    permissionGroupParams: PermissionGroupParams;
    alias?: string;
    schemaDefinition?: SchemaUnion;
}
export declare const CreateDatasetRequest: S.Schema<CreateDatasetRequest>;
export interface CreateDatasetResponse {
    datasetId?: string;
}
export declare const CreateDatasetResponse: S.Schema<CreateDatasetResponse>;
export type StringValueLength1to255 = string;
export type SortColumnList = string[];
export declare const SortColumnList: any;
export type PartitionColumnList = string[];
export declare const PartitionColumnList: any;
export type TimestampEpoch = number;
export type DataViewDestinationType = string;
export type ExportFileFormat = "PARQUET" | "DELIMITED_TEXT" | (string & {});
export declare const ExportFileFormat: any;
export type S3DestinationFormatOptions = {
    [key: string]: string | undefined;
};
export declare const S3DestinationFormatOptions: any;
export interface DataViewDestinationTypeParams {
    destinationType: string;
    s3DestinationExportFileFormat?: ExportFileFormat;
    s3DestinationExportFileFormatOptions?: {
        [key: string]: string | undefined;
    };
}
export declare const DataViewDestinationTypeParams: S.Schema<DataViewDestinationTypeParams>;
export interface CreateDataViewRequest {
    clientToken?: string;
    datasetId: string;
    autoUpdate?: boolean;
    sortColumns?: string[];
    partitionColumns?: string[];
    asOfTimestamp?: number;
    destinationTypeParams: DataViewDestinationTypeParams;
}
export declare const CreateDataViewRequest: S.Schema<CreateDataViewRequest>;
export type DataViewId = string;
export interface CreateDataViewResponse {
    datasetId?: string;
    dataViewId?: string;
}
export declare const CreateDataViewResponse: S.Schema<CreateDataViewResponse>;
export type PermissionGroupName = string | redacted.Redacted<string>;
export type PermissionGroupDescription = string | redacted.Redacted<string>;
export type ApplicationPermission = "CreateDataset" | "ManageClusters" | "ManageUsersAndGroups" | "ManageAttributeSets" | "ViewAuditData" | "AccessNotebooks" | "GetTemporaryCredentials" | (string & {});
export declare const ApplicationPermission: any;
export type ApplicationPermissionList = ApplicationPermission[];
export declare const ApplicationPermissionList: any;
export interface CreatePermissionGroupRequest {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    applicationPermissions: ApplicationPermission[];
    clientToken?: string;
}
export declare const CreatePermissionGroupRequest: S.Schema<CreatePermissionGroupRequest>;
export interface CreatePermissionGroupResponse {
    permissionGroupId?: string;
}
export declare const CreatePermissionGroupResponse: S.Schema<CreatePermissionGroupResponse>;
export type UserType = "SUPER_USER" | "APP_USER" | (string & {});
export declare const UserType: any;
export type FirstName = string | redacted.Redacted<string>;
export type LastName = string | redacted.Redacted<string>;
export type ApiAccess = "ENABLED" | "DISABLED" | (string & {});
export declare const ApiAccess: any;
export type RoleArn = string;
export interface CreateUserRequest {
    emailAddress: string | redacted.Redacted<string>;
    type: UserType;
    firstName?: string | redacted.Redacted<string>;
    lastName?: string | redacted.Redacted<string>;
    apiAccess?: ApiAccess;
    apiAccessPrincipalArn?: string;
    clientToken?: string;
}
export declare const CreateUserRequest: S.Schema<CreateUserRequest>;
export interface CreateUserResponse {
    userId?: string;
}
export declare const CreateUserResponse: S.Schema<CreateUserResponse>;
export interface DeleteDatasetRequest {
    clientToken?: string;
    datasetId: string;
}
export declare const DeleteDatasetRequest: S.Schema<DeleteDatasetRequest>;
export interface DeleteDatasetResponse {
    datasetId?: string;
}
export declare const DeleteDatasetResponse: S.Schema<DeleteDatasetResponse>;
export interface DeletePermissionGroupRequest {
    permissionGroupId: string;
    clientToken?: string;
}
export declare const DeletePermissionGroupRequest: S.Schema<DeletePermissionGroupRequest>;
export interface DeletePermissionGroupResponse {
    permissionGroupId?: string;
}
export declare const DeletePermissionGroupResponse: S.Schema<DeletePermissionGroupResponse>;
export interface DisableUserRequest {
    userId: string;
    clientToken?: string;
}
export declare const DisableUserRequest: S.Schema<DisableUserRequest>;
export interface DisableUserResponse {
    userId?: string;
}
export declare const DisableUserResponse: S.Schema<DisableUserResponse>;
export interface DisassociateUserFromPermissionGroupRequest {
    permissionGroupId: string;
    userId: string;
    clientToken?: string;
}
export declare const DisassociateUserFromPermissionGroupRequest: S.Schema<DisassociateUserFromPermissionGroupRequest>;
export interface DisassociateUserFromPermissionGroupResponse {
    statusCode?: number;
}
export declare const DisassociateUserFromPermissionGroupResponse: S.Schema<DisassociateUserFromPermissionGroupResponse>;
export interface EnableUserRequest {
    userId: string;
    clientToken?: string;
}
export declare const EnableUserRequest: S.Schema<EnableUserRequest>;
export interface EnableUserResponse {
    userId?: string;
}
export declare const EnableUserResponse: S.Schema<EnableUserResponse>;
export interface GetChangesetRequest {
    datasetId: string;
    changesetId: string;
}
export declare const GetChangesetRequest: S.Schema<GetChangesetRequest>;
export type ChangesetArn = string;
export type IngestionStatus = "PENDING" | "FAILED" | "SUCCESS" | "RUNNING" | "STOP_REQUESTED" | (string & {});
export declare const IngestionStatus: any;
export type ErrorMessage = string;
export type ErrorCategory = "VALIDATION" | "SERVICE_QUOTA_EXCEEDED" | "ACCESS_DENIED" | "RESOURCE_NOT_FOUND" | "THROTTLING" | "INTERNAL_SERVICE_EXCEPTION" | "CANCELLED" | "USER_RECOVERABLE" | (string & {});
export declare const ErrorCategory: any;
export interface ChangesetErrorInfo {
    errorMessage?: string;
    errorCategory?: ErrorCategory;
}
export declare const ChangesetErrorInfo: S.Schema<ChangesetErrorInfo>;
export interface GetChangesetResponse {
    changesetId?: string;
    changesetArn?: string;
    datasetId?: string;
    changeType?: ChangeType;
    sourceParams?: {
        [key: string]: string | undefined;
    };
    formatParams?: {
        [key: string]: string | undefined;
    };
    createTime?: number;
    status?: IngestionStatus;
    errorInfo?: ChangesetErrorInfo;
    activeUntilTimestamp?: number;
    activeFromTimestamp?: number;
    updatesChangesetId?: string;
    updatedByChangesetId?: string;
}
export declare const GetChangesetResponse: S.Schema<GetChangesetResponse>;
export interface GetDatasetRequest {
    datasetId: string;
}
export declare const GetDatasetRequest: S.Schema<GetDatasetRequest>;
export type DatasetArn = string;
export type DatasetStatus = "PENDING" | "FAILED" | "SUCCESS" | "RUNNING" | (string & {});
export declare const DatasetStatus: any;
export interface GetDatasetResponse {
    datasetId?: string;
    datasetArn?: string;
    datasetTitle?: string;
    kind?: DatasetKind;
    datasetDescription?: string;
    createTime?: number;
    lastModifiedTime?: number;
    schemaDefinition?: SchemaUnion;
    alias?: string;
    status?: DatasetStatus;
}
export declare const GetDatasetResponse: S.Schema<GetDatasetResponse>;
export interface GetDataViewRequest {
    dataViewId: string;
    datasetId: string;
}
export declare const GetDataViewRequest: S.Schema<GetDataViewRequest>;
export interface DataViewErrorInfo {
    errorMessage?: string;
    errorCategory?: ErrorCategory;
}
export declare const DataViewErrorInfo: S.Schema<DataViewErrorInfo>;
export type DataViewArn = string;
export type DataViewStatus = "RUNNING" | "STARTING" | "FAILED" | "CANCELLED" | "TIMEOUT" | "SUCCESS" | "PENDING" | "FAILED_CLEANUP_FAILED" | (string & {});
export declare const DataViewStatus: any;
export interface GetDataViewResponse {
    autoUpdate?: boolean;
    partitionColumns?: string[];
    datasetId?: string;
    asOfTimestamp?: number;
    errorInfo?: DataViewErrorInfo;
    lastModifiedTime?: number;
    createTime?: number;
    sortColumns?: string[];
    dataViewId?: string;
    dataViewArn?: string;
    destinationTypeParams?: DataViewDestinationTypeParams;
    status?: DataViewStatus;
}
export declare const GetDataViewResponse: S.Schema<GetDataViewResponse>;
export interface GetExternalDataViewAccessDetailsRequest {
    dataViewId: string;
    datasetId: string;
}
export declare const GetExternalDataViewAccessDetailsRequest: S.Schema<GetExternalDataViewAccessDetailsRequest>;
export type AccessKeyId = string;
export type SecretAccessKey = string | redacted.Redacted<string>;
export type SessionToken = string | redacted.Redacted<string>;
export interface AwsCredentials {
    accessKeyId?: string;
    secretAccessKey?: string | redacted.Redacted<string>;
    sessionToken?: string | redacted.Redacted<string>;
    expiration?: number;
}
export declare const AwsCredentials: S.Schema<AwsCredentials>;
export type S3BucketName = string;
export type S3Key = string;
export interface S3Location {
    bucket: string;
    key: string;
}
export declare const S3Location: S.Schema<S3Location>;
export interface GetExternalDataViewAccessDetailsResponse {
    credentials?: AwsCredentials;
    s3Location?: S3Location;
}
export declare const GetExternalDataViewAccessDetailsResponse: S.Schema<GetExternalDataViewAccessDetailsResponse>;
export interface GetPermissionGroupRequest {
    permissionGroupId: string;
}
export declare const GetPermissionGroupRequest: S.Schema<GetPermissionGroupRequest>;
export type PermissionGroupMembershipStatus = "ADDITION_IN_PROGRESS" | "ADDITION_SUCCESS" | "REMOVAL_IN_PROGRESS" | (string & {});
export declare const PermissionGroupMembershipStatus: any;
export interface PermissionGroup {
    permissionGroupId?: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    applicationPermissions?: ApplicationPermission[];
    createTime?: number;
    lastModifiedTime?: number;
    membershipStatus?: PermissionGroupMembershipStatus;
}
export declare const PermissionGroup: S.Schema<PermissionGroup>;
export interface GetPermissionGroupResponse {
    permissionGroup?: PermissionGroup;
}
export declare const GetPermissionGroupResponse: S.Schema<GetPermissionGroupResponse>;
export type SessionDuration = number;
export type IdType = string;
export interface GetProgrammaticAccessCredentialsRequest {
    durationInMinutes?: number;
    environmentId: string;
}
export declare const GetProgrammaticAccessCredentialsRequest: S.Schema<GetProgrammaticAccessCredentialsRequest>;
export type StringValueLength1to2552 = string;
export type StringValueMaxLength1000 = string;
export interface Credentials {
    accessKeyId?: string;
    secretAccessKey?: string;
    sessionToken?: string;
}
export declare const Credentials: S.Schema<Credentials>;
export interface GetProgrammaticAccessCredentialsResponse {
    credentials?: Credentials;
    durationInMinutes?: number;
}
export declare const GetProgrammaticAccessCredentialsResponse: S.Schema<GetProgrammaticAccessCredentialsResponse>;
export interface GetUserRequest {
    userId: string;
}
export declare const GetUserRequest: S.Schema<GetUserRequest>;
export type UserStatus = "CREATING" | "ENABLED" | "DISABLED" | (string & {});
export declare const UserStatus: any;
export interface GetUserResponse {
    userId?: string;
    status?: UserStatus;
    firstName?: string | redacted.Redacted<string>;
    lastName?: string | redacted.Redacted<string>;
    emailAddress?: string | redacted.Redacted<string>;
    type?: UserType;
    apiAccess?: ApiAccess;
    apiAccessPrincipalArn?: string;
    createTime?: number;
    lastEnabledTime?: number;
    lastDisabledTime?: number;
    lastModifiedTime?: number;
    lastLoginTime?: number;
}
export declare const GetUserResponse: S.Schema<GetUserResponse>;
export type LocationType = "INGESTION" | "SAGEMAKER" | (string & {});
export declare const LocationType: any;
export interface GetWorkingLocationRequest {
    locationType?: LocationType;
}
export declare const GetWorkingLocationRequest: S.Schema<GetWorkingLocationRequest>;
export type StringValueLength1to1024 = string;
export type StringValueLength1to63 = string;
export interface GetWorkingLocationResponse {
    s3Uri?: string;
    s3Path?: string;
    s3Bucket?: string;
}
export declare const GetWorkingLocationResponse: S.Schema<GetWorkingLocationResponse>;
export type ResultLimit = number;
export type PaginationToken = string;
export interface ListChangesetsRequest {
    datasetId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListChangesetsRequest: S.Schema<ListChangesetsRequest>;
export interface ChangesetSummary {
    changesetId?: string;
    changesetArn?: string;
    datasetId?: string;
    changeType?: ChangeType;
    sourceParams?: {
        [key: string]: string | undefined;
    };
    formatParams?: {
        [key: string]: string | undefined;
    };
    createTime?: number;
    status?: IngestionStatus;
    errorInfo?: ChangesetErrorInfo;
    activeUntilTimestamp?: number;
    activeFromTimestamp?: number;
    updatesChangesetId?: string;
    updatedByChangesetId?: string;
}
export declare const ChangesetSummary: S.Schema<ChangesetSummary>;
export type ChangesetList = ChangesetSummary[];
export declare const ChangesetList: any;
export interface ListChangesetsResponse {
    changesets?: ChangesetSummary[];
    nextToken?: string;
}
export declare const ListChangesetsResponse: S.Schema<ListChangesetsResponse>;
export interface ListDatasetsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDatasetsRequest: S.Schema<ListDatasetsRequest>;
export interface Dataset {
    datasetId?: string;
    datasetArn?: string;
    datasetTitle?: string;
    kind?: DatasetKind;
    datasetDescription?: string;
    ownerInfo?: DatasetOwnerInfo;
    createTime?: number;
    lastModifiedTime?: number;
    schemaDefinition?: SchemaUnion;
    alias?: string;
}
export declare const Dataset: S.Schema<Dataset>;
export type DatasetList = Dataset[];
export declare const DatasetList: any;
export interface ListDatasetsResponse {
    datasets?: Dataset[];
    nextToken?: string;
}
export declare const ListDatasetsResponse: S.Schema<ListDatasetsResponse>;
export interface ListDataViewsRequest {
    datasetId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDataViewsRequest: S.Schema<ListDataViewsRequest>;
export interface DataViewSummary {
    dataViewId?: string;
    dataViewArn?: string;
    datasetId?: string;
    asOfTimestamp?: number;
    partitionColumns?: string[];
    sortColumns?: string[];
    status?: DataViewStatus;
    errorInfo?: DataViewErrorInfo;
    destinationTypeProperties?: DataViewDestinationTypeParams;
    autoUpdate?: boolean;
    createTime?: number;
    lastModifiedTime?: number;
}
export declare const DataViewSummary: S.Schema<DataViewSummary>;
export type DataViewList = DataViewSummary[];
export declare const DataViewList: any;
export interface ListDataViewsResponse {
    nextToken?: string;
    dataViews?: DataViewSummary[];
}
export declare const ListDataViewsResponse: S.Schema<ListDataViewsResponse>;
export interface ListPermissionGroupsRequest {
    nextToken?: string;
    maxResults: number;
}
export declare const ListPermissionGroupsRequest: S.Schema<ListPermissionGroupsRequest>;
export type PermissionGroupList = PermissionGroup[];
export declare const PermissionGroupList: any;
export interface ListPermissionGroupsResponse {
    permissionGroups?: PermissionGroup[];
    nextToken?: string;
}
export declare const ListPermissionGroupsResponse: S.Schema<ListPermissionGroupsResponse>;
export interface ListPermissionGroupsByUserRequest {
    userId: string;
    nextToken?: string;
    maxResults: number;
}
export declare const ListPermissionGroupsByUserRequest: S.Schema<ListPermissionGroupsByUserRequest>;
export interface PermissionGroupByUser {
    permissionGroupId?: string;
    name?: string | redacted.Redacted<string>;
    membershipStatus?: PermissionGroupMembershipStatus;
}
export declare const PermissionGroupByUser: S.Schema<PermissionGroupByUser>;
export type PermissionGroupByUserList = PermissionGroupByUser[];
export declare const PermissionGroupByUserList: any;
export interface ListPermissionGroupsByUserResponse {
    permissionGroups?: PermissionGroupByUser[];
    nextToken?: string;
}
export declare const ListPermissionGroupsByUserResponse: S.Schema<ListPermissionGroupsByUserResponse>;
export interface ListUsersRequest {
    nextToken?: string;
    maxResults: number;
}
export declare const ListUsersRequest: S.Schema<ListUsersRequest>;
export interface User {
    userId?: string;
    status?: UserStatus;
    firstName?: string | redacted.Redacted<string>;
    lastName?: string | redacted.Redacted<string>;
    emailAddress?: string | redacted.Redacted<string>;
    type?: UserType;
    apiAccess?: ApiAccess;
    apiAccessPrincipalArn?: string;
    createTime?: number;
    lastEnabledTime?: number;
    lastDisabledTime?: number;
    lastModifiedTime?: number;
    lastLoginTime?: number;
}
export declare const User: S.Schema<User>;
export type UserList = User[];
export declare const UserList: any;
export interface ListUsersResponse {
    users?: User[];
    nextToken?: string;
}
export declare const ListUsersResponse: S.Schema<ListUsersResponse>;
export interface ListUsersByPermissionGroupRequest {
    permissionGroupId: string;
    nextToken?: string;
    maxResults: number;
}
export declare const ListUsersByPermissionGroupRequest: S.Schema<ListUsersByPermissionGroupRequest>;
export interface UserByPermissionGroup {
    userId?: string;
    status?: UserStatus;
    firstName?: string | redacted.Redacted<string>;
    lastName?: string | redacted.Redacted<string>;
    emailAddress?: string | redacted.Redacted<string>;
    type?: UserType;
    apiAccess?: ApiAccess;
    apiAccessPrincipalArn?: string;
    membershipStatus?: PermissionGroupMembershipStatus;
}
export declare const UserByPermissionGroup: S.Schema<UserByPermissionGroup>;
export type UserByPermissionGroupList = UserByPermissionGroup[];
export declare const UserByPermissionGroupList: any;
export interface ListUsersByPermissionGroupResponse {
    users?: UserByPermissionGroup[];
    nextToken?: string;
}
export declare const ListUsersByPermissionGroupResponse: S.Schema<ListUsersByPermissionGroupResponse>;
export interface ResetUserPasswordRequest {
    userId: string;
    clientToken?: string;
}
export declare const ResetUserPasswordRequest: S.Schema<ResetUserPasswordRequest>;
export type Password = string | redacted.Redacted<string>;
export interface ResetUserPasswordResponse {
    userId?: string;
    temporaryPassword?: string | redacted.Redacted<string>;
}
export declare const ResetUserPasswordResponse: S.Schema<ResetUserPasswordResponse>;
export interface UpdateChangesetRequest {
    clientToken?: string;
    datasetId: string;
    changesetId: string;
    sourceParams: {
        [key: string]: string | undefined;
    };
    formatParams: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateChangesetRequest: S.Schema<UpdateChangesetRequest>;
export interface UpdateChangesetResponse {
    changesetId?: string;
    datasetId?: string;
}
export declare const UpdateChangesetResponse: S.Schema<UpdateChangesetResponse>;
export interface UpdateDatasetRequest {
    clientToken?: string;
    datasetId: string;
    datasetTitle: string;
    kind: DatasetKind;
    datasetDescription?: string;
    alias?: string;
    schemaDefinition?: SchemaUnion;
}
export declare const UpdateDatasetRequest: S.Schema<UpdateDatasetRequest>;
export interface UpdateDatasetResponse {
    datasetId?: string;
}
export declare const UpdateDatasetResponse: S.Schema<UpdateDatasetResponse>;
export interface UpdatePermissionGroupRequest {
    permissionGroupId: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    applicationPermissions?: ApplicationPermission[];
    clientToken?: string;
}
export declare const UpdatePermissionGroupRequest: S.Schema<UpdatePermissionGroupRequest>;
export interface UpdatePermissionGroupResponse {
    permissionGroupId?: string;
}
export declare const UpdatePermissionGroupResponse: S.Schema<UpdatePermissionGroupResponse>;
export interface UpdateUserRequest {
    userId: string;
    type?: UserType;
    firstName?: string | redacted.Redacted<string>;
    lastName?: string | redacted.Redacted<string>;
    apiAccess?: ApiAccess;
    apiAccessPrincipalArn?: string;
    clientToken?: string;
}
export declare const UpdateUserRequest: S.Schema<UpdateUserRequest>;
export interface UpdateUserResponse {
    userId?: string;
}
export declare const UpdateUserResponse: S.Schema<UpdateUserResponse>;
export type ErrorMessage2 = string;
export type AssociateUserToPermissionGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a user to a permission group to grant permissions for actions a user can perform in FinSpace.
 */
export declare const associateUserToPermissionGroup: API.OperationMethod<AssociateUserToPermissionGroupRequest, AssociateUserToPermissionGroupResponse, AssociateUserToPermissionGroupError, Creds | HttpClient.HttpClient>;
export type CreateChangesetError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Changeset in a FinSpace Dataset.
 */
export declare const createChangeset: API.OperationMethod<CreateChangesetRequest, CreateChangesetResponse, CreateChangesetError, Creds | HttpClient.HttpClient>;
export type CreateDatasetError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new FinSpace Dataset.
 */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest, CreateDatasetResponse, CreateDatasetError, Creds | HttpClient.HttpClient>;
export type CreateDataViewError = ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Dataview for a Dataset.
 */
export declare const createDataView: API.OperationMethod<CreateDataViewRequest, CreateDataViewResponse, CreateDataViewError, Creds | HttpClient.HttpClient>;
export type CreatePermissionGroupError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a group of permissions for various actions that a user can perform in FinSpace.
 */
export declare const createPermissionGroup: API.OperationMethod<CreatePermissionGroupRequest, CreatePermissionGroupResponse, CreatePermissionGroupError, Creds | HttpClient.HttpClient>;
export type CreateUserError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new user in FinSpace.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest, CreateUserResponse, CreateUserError, Creds | HttpClient.HttpClient>;
export type DeleteDatasetError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a FinSpace Dataset.
 */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest, DeleteDatasetResponse, DeleteDatasetError, Creds | HttpClient.HttpClient>;
export type DeletePermissionGroupError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a permission group. This action is irreversible.
 */
export declare const deletePermissionGroup: API.OperationMethod<DeletePermissionGroupRequest, DeletePermissionGroupResponse, DeletePermissionGroupError, Creds | HttpClient.HttpClient>;
export type DisableUserError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Denies access to the FinSpace web application and API for the specified user.
 */
export declare const disableUser: API.OperationMethod<DisableUserRequest, DisableUserResponse, DisableUserError, Creds | HttpClient.HttpClient>;
export type DisassociateUserFromPermissionGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a user from a permission group.
 */
export declare const disassociateUserFromPermissionGroup: API.OperationMethod<DisassociateUserFromPermissionGroupRequest, DisassociateUserFromPermissionGroupResponse, DisassociateUserFromPermissionGroupError, Creds | HttpClient.HttpClient>;
export type EnableUserError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows the specified user to access the FinSpace web application and API.
 */
export declare const enableUser: API.OperationMethod<EnableUserRequest, EnableUserResponse, EnableUserError, Creds | HttpClient.HttpClient>;
export type GetChangesetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get information about a Changeset.
 */
export declare const getChangeset: API.OperationMethod<GetChangesetRequest, GetChangesetResponse, GetChangesetError, Creds | HttpClient.HttpClient>;
export type GetDatasetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a Dataset.
 */
export declare const getDataset: API.OperationMethod<GetDatasetRequest, GetDatasetResponse, GetDatasetError, Creds | HttpClient.HttpClient>;
export type GetDataViewError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a Dataview.
 */
export declare const getDataView: API.OperationMethod<GetDataViewRequest, GetDataViewResponse, GetDataViewError, Creds | HttpClient.HttpClient>;
export type GetExternalDataViewAccessDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the credentials to access the external Dataview from an S3 location. To call this API:
 *
 * - You must retrieve the programmatic credentials.
 *
 * - You must be a member of a FinSpace user group, where the dataset that you want to access has `Read Dataset Data` permissions.
 */
export declare const getExternalDataViewAccessDetails: API.OperationMethod<GetExternalDataViewAccessDetailsRequest, GetExternalDataViewAccessDetailsResponse, GetExternalDataViewAccessDetailsError, Creds | HttpClient.HttpClient>;
export type GetPermissionGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a specific permission group.
 */
export declare const getPermissionGroup: API.OperationMethod<GetPermissionGroupRequest, GetPermissionGroupResponse, GetPermissionGroupError, Creds | HttpClient.HttpClient>;
export type GetProgrammaticAccessCredentialsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Request programmatic credentials to use with FinSpace SDK. For more information, see Step 2. Access credentials programmatically using IAM access key id and secret access key.
 */
export declare const getProgrammaticAccessCredentials: API.OperationMethod<GetProgrammaticAccessCredentialsRequest, GetProgrammaticAccessCredentialsResponse, GetProgrammaticAccessCredentialsError, Creds | HttpClient.HttpClient>;
export type GetUserError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details for a specific user.
 */
export declare const getUser: API.OperationMethod<GetUserRequest, GetUserResponse, GetUserError, Creds | HttpClient.HttpClient>;
export type GetWorkingLocationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A temporary Amazon S3 location, where you can copy your files from a source location to stage or use
 * as a scratch space in FinSpace notebook.
 */
export declare const getWorkingLocation: API.OperationMethod<GetWorkingLocationRequest, GetWorkingLocationResponse, GetWorkingLocationError, Creds | HttpClient.HttpClient>;
export type ListChangesetsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the FinSpace Changesets for a Dataset.
 */
export declare const listChangesets: API.PaginatedOperationMethod<ListChangesetsRequest, ListChangesetsResponse, ListChangesetsError, Creds | HttpClient.HttpClient, ChangesetSummary>;
export type ListDatasetsError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all of the active Datasets that a user has access to.
 */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest, ListDatasetsResponse, ListDatasetsError, Creds | HttpClient.HttpClient, Dataset>;
export type ListDataViewsError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all available Dataviews for a Dataset.
 */
export declare const listDataViews: API.PaginatedOperationMethod<ListDataViewsRequest, ListDataViewsResponse, ListDataViewsError, Creds | HttpClient.HttpClient, DataViewSummary>;
export type ListPermissionGroupsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all available permission groups in FinSpace.
 */
export declare const listPermissionGroups: API.PaginatedOperationMethod<ListPermissionGroupsRequest, ListPermissionGroupsResponse, ListPermissionGroupsError, Creds | HttpClient.HttpClient, PermissionGroup>;
export type ListPermissionGroupsByUserError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the permission groups that are associated with a specific user.
 */
export declare const listPermissionGroupsByUser: API.OperationMethod<ListPermissionGroupsByUserRequest, ListPermissionGroupsByUserResponse, ListPermissionGroupsByUserError, Creds | HttpClient.HttpClient>;
export type ListUsersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all available users in FinSpace.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest, ListUsersResponse, ListUsersError, Creds | HttpClient.HttpClient, User>;
export type ListUsersByPermissionGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists details of all the users in a specific permission group.
 */
export declare const listUsersByPermissionGroup: API.OperationMethod<ListUsersByPermissionGroupRequest, ListUsersByPermissionGroupResponse, ListUsersByPermissionGroupError, Creds | HttpClient.HttpClient>;
export type ResetUserPasswordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Resets the password for a specified user ID and generates a temporary one. Only a superuser can reset password for other users. Resetting the password immediately invalidates the previous password associated with the user.
 */
export declare const resetUserPassword: API.OperationMethod<ResetUserPasswordRequest, ResetUserPasswordResponse, ResetUserPasswordError, Creds | HttpClient.HttpClient>;
export type UpdateChangesetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a FinSpace Changeset.
 */
export declare const updateChangeset: API.OperationMethod<UpdateChangesetRequest, UpdateChangesetResponse, UpdateChangesetError, Creds | HttpClient.HttpClient>;
export type UpdateDatasetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a FinSpace Dataset.
 */
export declare const updateDataset: API.OperationMethod<UpdateDatasetRequest, UpdateDatasetResponse, UpdateDatasetError, Creds | HttpClient.HttpClient>;
export type UpdatePermissionGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies the details of a permission group. You cannot modify a `permissionGroupID`.
 */
export declare const updatePermissionGroup: API.OperationMethod<UpdatePermissionGroupRequest, UpdatePermissionGroupResponse, UpdatePermissionGroupError, Creds | HttpClient.HttpClient>;
export type UpdateUserError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies the details of the specified user. You cannot update the `userId` for a user.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest, UpdateUserResponse, UpdateUserError, Creds | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=finspace-data.d.ts.map