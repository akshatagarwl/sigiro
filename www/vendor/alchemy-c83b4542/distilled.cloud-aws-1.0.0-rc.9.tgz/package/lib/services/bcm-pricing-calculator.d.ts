import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DataUnavailableException_base: S.Class<DataUnavailableException, S.TaggedStruct<"DataUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DataUnavailableException extends /*@__PURE__*/ DataUnavailableException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
export type ResourceId = string;
export type Key = string;
export type UsageGroup = string;
export type AccountId = string;
export type Uuid = string;
export type ReservedInstanceInstanceCount = number;
export interface AddReservedInstanceAction {
    reservedInstancesOfferingId?: string;
    instanceCount?: number;
}
export declare const AddReservedInstanceAction: S.Schema<AddReservedInstanceAction>;
export type SavingsPlanCommitment = number;
export interface AddSavingsPlanAction {
    savingsPlanOfferingId?: string;
    commitment?: number;
}
export declare const AddSavingsPlanAction: S.Schema<AddSavingsPlanAction>;
export interface NegateReservedInstanceAction {
    reservedInstancesId?: string;
}
export declare const NegateReservedInstanceAction: S.Schema<NegateReservedInstanceAction>;
export interface NegateSavingsPlanAction {
    savingsPlanId?: string;
}
export declare const NegateSavingsPlanAction: S.Schema<NegateSavingsPlanAction>;
export type BillScenarioCommitmentModificationAction = {
    addReservedInstanceAction: AddReservedInstanceAction;
    addSavingsPlanAction?: never;
    negateReservedInstanceAction?: never;
    negateSavingsPlanAction?: never;
} | {
    addReservedInstanceAction?: never;
    addSavingsPlanAction: AddSavingsPlanAction;
    negateReservedInstanceAction?: never;
    negateSavingsPlanAction?: never;
} | {
    addReservedInstanceAction?: never;
    addSavingsPlanAction?: never;
    negateReservedInstanceAction: NegateReservedInstanceAction;
    negateSavingsPlanAction?: never;
} | {
    addReservedInstanceAction?: never;
    addSavingsPlanAction?: never;
    negateReservedInstanceAction?: never;
    negateSavingsPlanAction: NegateSavingsPlanAction;
};
export declare const BillScenarioCommitmentModificationAction: any;
export interface BatchCreateBillScenarioCommitmentModificationEntry {
    key: string;
    group?: string;
    usageAccountId: string;
    commitmentAction: BillScenarioCommitmentModificationAction;
}
export declare const BatchCreateBillScenarioCommitmentModificationEntry: S.Schema<BatchCreateBillScenarioCommitmentModificationEntry>;
export type BatchCreateBillScenarioCommitmentModificationEntries = BatchCreateBillScenarioCommitmentModificationEntry[];
export declare const BatchCreateBillScenarioCommitmentModificationEntries: any;
export type ClientToken = string;
export interface BatchCreateBillScenarioCommitmentModificationRequest {
    billScenarioId: string;
    commitmentModifications: BatchCreateBillScenarioCommitmentModificationEntry[];
    clientToken?: string;
}
export declare const BatchCreateBillScenarioCommitmentModificationRequest: S.Schema<BatchCreateBillScenarioCommitmentModificationRequest>;
export interface BatchCreateBillScenarioCommitmentModificationItem {
    key?: string;
    id?: string;
    group?: string;
    usageAccountId?: string;
    commitmentAction?: BillScenarioCommitmentModificationAction;
}
export declare const BatchCreateBillScenarioCommitmentModificationItem: S.Schema<BatchCreateBillScenarioCommitmentModificationItem>;
export type BatchCreateBillScenarioCommitmentModificationItems = BatchCreateBillScenarioCommitmentModificationItem[];
export declare const BatchCreateBillScenarioCommitmentModificationItems: any;
export type BatchCreateBillScenarioCommitmentModificationErrorCode = "CONFLICT" | "INTERNAL_SERVER_ERROR" | "INVALID_ACCOUNT" | (string & {});
export declare const BatchCreateBillScenarioCommitmentModificationErrorCode: any;
export interface BatchCreateBillScenarioCommitmentModificationError_ {
    key?: string;
    errorMessage?: string;
    errorCode?: BatchCreateBillScenarioCommitmentModificationErrorCode;
}
export declare const BatchCreateBillScenarioCommitmentModificationError_: S.Schema<BatchCreateBillScenarioCommitmentModificationError_>;
export type BatchCreateBillScenarioCommitmentModificationErrors = BatchCreateBillScenarioCommitmentModificationError_[];
export declare const BatchCreateBillScenarioCommitmentModificationErrors: any;
export interface BatchCreateBillScenarioCommitmentModificationResponse {
    items?: BatchCreateBillScenarioCommitmentModificationItem[];
    errors?: BatchCreateBillScenarioCommitmentModificationError_[];
}
export declare const BatchCreateBillScenarioCommitmentModificationResponse: S.Schema<BatchCreateBillScenarioCommitmentModificationResponse>;
export type ServiceCode = string;
export type UsageType = string;
export type Operation = string;
export type AvailabilityZone = string;
export interface UsageAmount {
    startHour: Date;
    amount: number;
}
export declare const UsageAmount: S.Schema<UsageAmount>;
export type UsageAmounts = UsageAmount[];
export declare const UsageAmounts: any;
export interface BillInterval {
    start?: Date;
    end?: Date;
}
export declare const BillInterval: S.Schema<BillInterval>;
export type ExpressionList = Expression[];
export declare const ExpressionList: S.Schema<ExpressionList>;
export type StringList = string[];
export declare const StringList: any;
export interface ExpressionFilter {
    key?: string;
    matchOptions?: string[];
    values?: string[];
}
export declare const ExpressionFilter: S.Schema<ExpressionFilter>;
export interface Expression {
    and?: Expression[];
    or?: Expression[];
    not?: Expression;
    costCategories?: ExpressionFilter;
    dimensions?: ExpressionFilter;
    tags?: ExpressionFilter;
}
export declare const Expression: S.Schema<Expression>;
export interface HistoricalUsageEntity {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string;
    usageAccountId: string;
    billInterval: BillInterval;
    filterExpression: Expression;
}
export declare const HistoricalUsageEntity: S.Schema<HistoricalUsageEntity>;
export interface BatchCreateBillScenarioUsageModificationEntry {
    serviceCode: string;
    usageType: string;
    operation: string;
    availabilityZone?: string;
    key: string;
    group?: string;
    usageAccountId: string;
    amounts?: UsageAmount[];
    historicalUsage?: HistoricalUsageEntity;
}
export declare const BatchCreateBillScenarioUsageModificationEntry: S.Schema<BatchCreateBillScenarioUsageModificationEntry>;
export type BatchCreateBillScenarioUsageModificationEntries = BatchCreateBillScenarioUsageModificationEntry[];
export declare const BatchCreateBillScenarioUsageModificationEntries: any;
export interface BatchCreateBillScenarioUsageModificationRequest {
    billScenarioId: string;
    usageModifications: BatchCreateBillScenarioUsageModificationEntry[];
    clientToken?: string;
}
export declare const BatchCreateBillScenarioUsageModificationRequest: S.Schema<BatchCreateBillScenarioUsageModificationRequest>;
export interface UsageQuantity {
    startHour?: Date;
    unit?: string;
    amount?: number;
}
export declare const UsageQuantity: S.Schema<UsageQuantity>;
export type UsageQuantities = UsageQuantity[];
export declare const UsageQuantities: any;
export interface BatchCreateBillScenarioUsageModificationItem {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string;
    availabilityZone?: string;
    id?: string;
    group?: string;
    usageAccountId?: string;
    quantities?: UsageQuantity[];
    historicalUsage?: HistoricalUsageEntity;
    key?: string;
}
export declare const BatchCreateBillScenarioUsageModificationItem: S.Schema<BatchCreateBillScenarioUsageModificationItem>;
export type BatchCreateBillScenarioUsageModificationItems = BatchCreateBillScenarioUsageModificationItem[];
export declare const BatchCreateBillScenarioUsageModificationItems: any;
export type BatchCreateBillScenarioUsageModificationErrorCode = "BAD_REQUEST" | "NOT_FOUND" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export declare const BatchCreateBillScenarioUsageModificationErrorCode: any;
export interface BatchCreateBillScenarioUsageModificationError_ {
    key?: string;
    errorMessage?: string;
    errorCode?: BatchCreateBillScenarioUsageModificationErrorCode;
}
export declare const BatchCreateBillScenarioUsageModificationError_: S.Schema<BatchCreateBillScenarioUsageModificationError_>;
export type BatchCreateBillScenarioUsageModificationErrors = BatchCreateBillScenarioUsageModificationError_[];
export declare const BatchCreateBillScenarioUsageModificationErrors: any;
export interface BatchCreateBillScenarioUsageModificationResponse {
    items?: BatchCreateBillScenarioUsageModificationItem[];
    errors?: BatchCreateBillScenarioUsageModificationError_[];
}
export declare const BatchCreateBillScenarioUsageModificationResponse: S.Schema<BatchCreateBillScenarioUsageModificationResponse>;
export interface BatchCreateWorkloadEstimateUsageEntry {
    serviceCode: string;
    usageType: string;
    operation: string;
    key: string;
    group?: string;
    usageAccountId: string;
    amount: number;
    historicalUsage?: HistoricalUsageEntity;
}
export declare const BatchCreateWorkloadEstimateUsageEntry: S.Schema<BatchCreateWorkloadEstimateUsageEntry>;
export type BatchCreateWorkloadEstimateUsageEntries = BatchCreateWorkloadEstimateUsageEntry[];
export declare const BatchCreateWorkloadEstimateUsageEntries: any;
export interface BatchCreateWorkloadEstimateUsageRequest {
    workloadEstimateId: string;
    usage: BatchCreateWorkloadEstimateUsageEntry[];
    clientToken?: string;
}
export declare const BatchCreateWorkloadEstimateUsageRequest: S.Schema<BatchCreateWorkloadEstimateUsageRequest>;
export interface WorkloadEstimateUsageQuantity {
    unit?: string;
    amount?: number;
}
export declare const WorkloadEstimateUsageQuantity: S.Schema<WorkloadEstimateUsageQuantity>;
export type CurrencyCode = "USD" | (string & {});
export declare const CurrencyCode: any;
export type WorkloadEstimateCostStatus = "VALID" | "INVALID" | "STALE" | (string & {});
export declare const WorkloadEstimateCostStatus: any;
export interface BatchCreateWorkloadEstimateUsageItem {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string;
    id?: string;
    usageAccountId?: string;
    group?: string;
    quantity?: WorkloadEstimateUsageQuantity;
    cost?: number;
    currency?: CurrencyCode;
    status?: WorkloadEstimateCostStatus;
    historicalUsage?: HistoricalUsageEntity;
    key?: string;
}
export declare const BatchCreateWorkloadEstimateUsageItem: S.Schema<BatchCreateWorkloadEstimateUsageItem>;
export type BatchCreateWorkloadEstimateUsageItems = BatchCreateWorkloadEstimateUsageItem[];
export declare const BatchCreateWorkloadEstimateUsageItems: any;
export type BatchCreateWorkloadEstimateUsageCode = "BAD_REQUEST" | "NOT_FOUND" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export declare const BatchCreateWorkloadEstimateUsageCode: any;
export interface BatchCreateWorkloadEstimateUsageError_ {
    key?: string;
    errorCode?: BatchCreateWorkloadEstimateUsageCode;
    errorMessage?: string;
}
export declare const BatchCreateWorkloadEstimateUsageError_: S.Schema<BatchCreateWorkloadEstimateUsageError_>;
export type BatchCreateWorkloadEstimateUsageErrors = BatchCreateWorkloadEstimateUsageError_[];
export declare const BatchCreateWorkloadEstimateUsageErrors: any;
export interface BatchCreateWorkloadEstimateUsageResponse {
    items?: BatchCreateWorkloadEstimateUsageItem[];
    errors?: BatchCreateWorkloadEstimateUsageError_[];
}
export declare const BatchCreateWorkloadEstimateUsageResponse: S.Schema<BatchCreateWorkloadEstimateUsageResponse>;
export type BatchDeleteBillScenarioCommitmentModificationEntries = string[];
export declare const BatchDeleteBillScenarioCommitmentModificationEntries: any;
export interface BatchDeleteBillScenarioCommitmentModificationRequest {
    billScenarioId: string;
    ids: string[];
}
export declare const BatchDeleteBillScenarioCommitmentModificationRequest: S.Schema<BatchDeleteBillScenarioCommitmentModificationRequest>;
export type BatchDeleteBillScenarioCommitmentModificationErrorCode = "BAD_REQUEST" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export declare const BatchDeleteBillScenarioCommitmentModificationErrorCode: any;
export interface BatchDeleteBillScenarioCommitmentModificationError_ {
    id?: string;
    errorCode?: BatchDeleteBillScenarioCommitmentModificationErrorCode;
    errorMessage?: string;
}
export declare const BatchDeleteBillScenarioCommitmentModificationError_: S.Schema<BatchDeleteBillScenarioCommitmentModificationError_>;
export type BatchDeleteBillScenarioCommitmentModificationErrors = BatchDeleteBillScenarioCommitmentModificationError_[];
export declare const BatchDeleteBillScenarioCommitmentModificationErrors: any;
export interface BatchDeleteBillScenarioCommitmentModificationResponse {
    errors?: BatchDeleteBillScenarioCommitmentModificationError_[];
}
export declare const BatchDeleteBillScenarioCommitmentModificationResponse: S.Schema<BatchDeleteBillScenarioCommitmentModificationResponse>;
export type BatchDeleteBillScenarioUsageModificationEntries = string[];
export declare const BatchDeleteBillScenarioUsageModificationEntries: any;
export interface BatchDeleteBillScenarioUsageModificationRequest {
    billScenarioId: string;
    ids: string[];
}
export declare const BatchDeleteBillScenarioUsageModificationRequest: S.Schema<BatchDeleteBillScenarioUsageModificationRequest>;
export type BatchDeleteBillScenarioUsageModificationErrorCode = "BAD_REQUEST" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export declare const BatchDeleteBillScenarioUsageModificationErrorCode: any;
export interface BatchDeleteBillScenarioUsageModificationError_ {
    id?: string;
    errorMessage?: string;
    errorCode?: BatchDeleteBillScenarioUsageModificationErrorCode;
}
export declare const BatchDeleteBillScenarioUsageModificationError_: S.Schema<BatchDeleteBillScenarioUsageModificationError_>;
export type BatchDeleteBillScenarioUsageModificationErrors = BatchDeleteBillScenarioUsageModificationError_[];
export declare const BatchDeleteBillScenarioUsageModificationErrors: any;
export interface BatchDeleteBillScenarioUsageModificationResponse {
    errors?: BatchDeleteBillScenarioUsageModificationError_[];
}
export declare const BatchDeleteBillScenarioUsageModificationResponse: S.Schema<BatchDeleteBillScenarioUsageModificationResponse>;
export type BatchDeleteWorkloadEstimateUsageEntries = string[];
export declare const BatchDeleteWorkloadEstimateUsageEntries: any;
export interface BatchDeleteWorkloadEstimateUsageRequest {
    workloadEstimateId: string;
    ids: string[];
}
export declare const BatchDeleteWorkloadEstimateUsageRequest: S.Schema<BatchDeleteWorkloadEstimateUsageRequest>;
export type WorkloadEstimateUpdateUsageErrorCode = "BAD_REQUEST" | "NOT_FOUND" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export declare const WorkloadEstimateUpdateUsageErrorCode: any;
export interface BatchDeleteWorkloadEstimateUsageError_ {
    id?: string;
    errorMessage?: string;
    errorCode?: WorkloadEstimateUpdateUsageErrorCode;
}
export declare const BatchDeleteWorkloadEstimateUsageError_: S.Schema<BatchDeleteWorkloadEstimateUsageError_>;
export type BatchDeleteWorkloadEstimateUsageErrors = BatchDeleteWorkloadEstimateUsageError_[];
export declare const BatchDeleteWorkloadEstimateUsageErrors: any;
export interface BatchDeleteWorkloadEstimateUsageResponse {
    errors?: BatchDeleteWorkloadEstimateUsageError_[];
}
export declare const BatchDeleteWorkloadEstimateUsageResponse: S.Schema<BatchDeleteWorkloadEstimateUsageResponse>;
export interface BatchUpdateBillScenarioCommitmentModificationEntry {
    id: string;
    group?: string;
}
export declare const BatchUpdateBillScenarioCommitmentModificationEntry: S.Schema<BatchUpdateBillScenarioCommitmentModificationEntry>;
export type BatchUpdateBillScenarioCommitmentModificationEntries = BatchUpdateBillScenarioCommitmentModificationEntry[];
export declare const BatchUpdateBillScenarioCommitmentModificationEntries: any;
export interface BatchUpdateBillScenarioCommitmentModificationRequest {
    billScenarioId: string;
    commitmentModifications: BatchUpdateBillScenarioCommitmentModificationEntry[];
}
export declare const BatchUpdateBillScenarioCommitmentModificationRequest: S.Schema<BatchUpdateBillScenarioCommitmentModificationRequest>;
export interface BillScenarioCommitmentModificationItem {
    id?: string;
    usageAccountId?: string;
    group?: string;
    commitmentAction?: BillScenarioCommitmentModificationAction;
}
export declare const BillScenarioCommitmentModificationItem: S.Schema<BillScenarioCommitmentModificationItem>;
export type BillScenarioCommitmentModificationItems = BillScenarioCommitmentModificationItem[];
export declare const BillScenarioCommitmentModificationItems: any;
export type BatchUpdateBillScenarioCommitmentModificationErrorCode = "BAD_REQUEST" | "NOT_FOUND" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export declare const BatchUpdateBillScenarioCommitmentModificationErrorCode: any;
export interface BatchUpdateBillScenarioCommitmentModificationError_ {
    id?: string;
    errorCode?: BatchUpdateBillScenarioCommitmentModificationErrorCode;
    errorMessage?: string;
}
export declare const BatchUpdateBillScenarioCommitmentModificationError_: S.Schema<BatchUpdateBillScenarioCommitmentModificationError_>;
export type BatchUpdateBillScenarioCommitmentModificationErrors = BatchUpdateBillScenarioCommitmentModificationError_[];
export declare const BatchUpdateBillScenarioCommitmentModificationErrors: any;
export interface BatchUpdateBillScenarioCommitmentModificationResponse {
    items?: BillScenarioCommitmentModificationItem[];
    errors?: BatchUpdateBillScenarioCommitmentModificationError_[];
}
export declare const BatchUpdateBillScenarioCommitmentModificationResponse: S.Schema<BatchUpdateBillScenarioCommitmentModificationResponse>;
export interface BatchUpdateBillScenarioUsageModificationEntry {
    id: string;
    group?: string;
    amounts?: UsageAmount[];
}
export declare const BatchUpdateBillScenarioUsageModificationEntry: S.Schema<BatchUpdateBillScenarioUsageModificationEntry>;
export type BatchUpdateBillScenarioUsageModificationEntries = BatchUpdateBillScenarioUsageModificationEntry[];
export declare const BatchUpdateBillScenarioUsageModificationEntries: any;
export interface BatchUpdateBillScenarioUsageModificationRequest {
    billScenarioId: string;
    usageModifications: BatchUpdateBillScenarioUsageModificationEntry[];
}
export declare const BatchUpdateBillScenarioUsageModificationRequest: S.Schema<BatchUpdateBillScenarioUsageModificationRequest>;
export interface BillScenarioUsageModificationItem {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string;
    availabilityZone?: string;
    id?: string;
    group?: string;
    usageAccountId?: string;
    quantities?: UsageQuantity[];
    historicalUsage?: HistoricalUsageEntity;
}
export declare const BillScenarioUsageModificationItem: S.Schema<BillScenarioUsageModificationItem>;
export type BillScenarioUsageModificationItems = BillScenarioUsageModificationItem[];
export declare const BillScenarioUsageModificationItems: any;
export type BatchUpdateBillScenarioUsageModificationErrorCode = "BAD_REQUEST" | "NOT_FOUND" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export declare const BatchUpdateBillScenarioUsageModificationErrorCode: any;
export interface BatchUpdateBillScenarioUsageModificationError_ {
    id?: string;
    errorMessage?: string;
    errorCode?: BatchUpdateBillScenarioUsageModificationErrorCode;
}
export declare const BatchUpdateBillScenarioUsageModificationError_: S.Schema<BatchUpdateBillScenarioUsageModificationError_>;
export type BatchUpdateBillScenarioUsageModificationErrors = BatchUpdateBillScenarioUsageModificationError_[];
export declare const BatchUpdateBillScenarioUsageModificationErrors: any;
export interface BatchUpdateBillScenarioUsageModificationResponse {
    items?: BillScenarioUsageModificationItem[];
    errors?: BatchUpdateBillScenarioUsageModificationError_[];
}
export declare const BatchUpdateBillScenarioUsageModificationResponse: S.Schema<BatchUpdateBillScenarioUsageModificationResponse>;
export interface BatchUpdateWorkloadEstimateUsageEntry {
    id: string;
    group?: string;
    amount?: number;
}
export declare const BatchUpdateWorkloadEstimateUsageEntry: S.Schema<BatchUpdateWorkloadEstimateUsageEntry>;
export type BatchUpdateWorkloadEstimateUsageEntries = BatchUpdateWorkloadEstimateUsageEntry[];
export declare const BatchUpdateWorkloadEstimateUsageEntries: any;
export interface BatchUpdateWorkloadEstimateUsageRequest {
    workloadEstimateId: string;
    usage: BatchUpdateWorkloadEstimateUsageEntry[];
}
export declare const BatchUpdateWorkloadEstimateUsageRequest: S.Schema<BatchUpdateWorkloadEstimateUsageRequest>;
export interface WorkloadEstimateUsageItem {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string;
    id?: string;
    usageAccountId?: string;
    group?: string;
    quantity?: WorkloadEstimateUsageQuantity;
    cost?: number;
    currency?: CurrencyCode;
    status?: WorkloadEstimateCostStatus;
    historicalUsage?: HistoricalUsageEntity;
}
export declare const WorkloadEstimateUsageItem: S.Schema<WorkloadEstimateUsageItem>;
export type WorkloadEstimateUsageItems = WorkloadEstimateUsageItem[];
export declare const WorkloadEstimateUsageItems: any;
export interface BatchUpdateWorkloadEstimateUsageError_ {
    id?: string;
    errorMessage?: string;
    errorCode?: WorkloadEstimateUpdateUsageErrorCode;
}
export declare const BatchUpdateWorkloadEstimateUsageError_: S.Schema<BatchUpdateWorkloadEstimateUsageError_>;
export type BatchUpdateWorkloadEstimateUsageErrors = BatchUpdateWorkloadEstimateUsageError_[];
export declare const BatchUpdateWorkloadEstimateUsageErrors: any;
export interface BatchUpdateWorkloadEstimateUsageResponse {
    items?: WorkloadEstimateUsageItem[];
    errors?: BatchUpdateWorkloadEstimateUsageError_[];
}
export declare const BatchUpdateWorkloadEstimateUsageResponse: S.Schema<BatchUpdateWorkloadEstimateUsageResponse>;
export type BillEstimateName = string;
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export interface CreateBillEstimateRequest {
    billScenarioId: string;
    name: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateBillEstimateRequest: S.Schema<CreateBillEstimateRequest>;
export type BillEstimateStatus = "IN_PROGRESS" | "COMPLETE" | "FAILED" | (string & {});
export declare const BillEstimateStatus: any;
export interface CostAmount {
    amount?: number;
    currency?: CurrencyCode;
}
export declare const CostAmount: S.Schema<CostAmount>;
export interface CostDifference {
    historicalCost?: CostAmount;
    estimatedCost?: CostAmount;
}
export declare const CostDifference: S.Schema<CostDifference>;
export type ServiceCostDifferenceMap = {
    [key: string]: CostDifference | undefined;
};
export declare const ServiceCostDifferenceMap: any;
export interface BillEstimateCostSummary {
    totalCostDifference?: CostDifference;
    serviceCostDifferences?: {
        [key: string]: CostDifference | undefined;
    };
}
export declare const BillEstimateCostSummary: S.Schema<BillEstimateCostSummary>;
export type GroupSharingPreferenceEnum = "OPEN" | "PRIORITIZED" | "RESTRICTED" | (string & {});
export declare const GroupSharingPreferenceEnum: any;
export type CostCategoryArn = string;
export interface CreateBillEstimateResponse {
    id: string;
    name?: string;
    status?: BillEstimateStatus;
    failureMessage?: string;
    billInterval?: BillInterval;
    costSummary?: BillEstimateCostSummary;
    createdAt?: Date;
    expiresAt?: Date;
    groupSharingPreference?: GroupSharingPreferenceEnum;
    costCategoryGroupSharingPreferenceArn?: string;
    costCategoryGroupSharingPreferenceEffectiveDate?: Date;
}
export declare const CreateBillEstimateResponse: S.Schema<CreateBillEstimateResponse>;
export type BillScenarioName = string;
export interface CreateBillScenarioRequest {
    name: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    groupSharingPreference?: GroupSharingPreferenceEnum;
    costCategoryGroupSharingPreferenceArn?: string;
}
export declare const CreateBillScenarioRequest: S.Schema<CreateBillScenarioRequest>;
export type BillScenarioStatus = "READY" | "LOCKED" | "FAILED" | "STALE" | (string & {});
export declare const BillScenarioStatus: any;
export interface CreateBillScenarioResponse {
    id: string;
    name?: string;
    billInterval?: BillInterval;
    status?: BillScenarioStatus;
    createdAt?: Date;
    expiresAt?: Date;
    failureMessage?: string;
    groupSharingPreference?: GroupSharingPreferenceEnum;
    costCategoryGroupSharingPreferenceArn?: string;
}
export declare const CreateBillScenarioResponse: S.Schema<CreateBillScenarioResponse>;
export type WorkloadEstimateName = string;
export type WorkloadEstimateRateType = "BEFORE_DISCOUNTS" | "AFTER_DISCOUNTS" | "AFTER_DISCOUNTS_AND_COMMITMENTS" | (string & {});
export declare const WorkloadEstimateRateType: any;
export interface CreateWorkloadEstimateRequest {
    name: string;
    clientToken?: string;
    rateType?: WorkloadEstimateRateType;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateWorkloadEstimateRequest: S.Schema<CreateWorkloadEstimateRequest>;
export type WorkloadEstimateStatus = "UPDATING" | "VALID" | "INVALID" | "ACTION_NEEDED" | (string & {});
export declare const WorkloadEstimateStatus: any;
export interface CreateWorkloadEstimateResponse {
    id: string;
    name?: string;
    createdAt?: Date;
    expiresAt?: Date;
    rateType?: WorkloadEstimateRateType;
    rateTimestamp?: Date;
    status?: WorkloadEstimateStatus;
    totalCost?: number;
    costCurrency?: CurrencyCode;
    failureMessage?: string;
}
export declare const CreateWorkloadEstimateResponse: S.Schema<CreateWorkloadEstimateResponse>;
export interface DeleteBillEstimateRequest {
    identifier: string;
}
export declare const DeleteBillEstimateRequest: S.Schema<DeleteBillEstimateRequest>;
export interface DeleteBillEstimateResponse {
}
export declare const DeleteBillEstimateResponse: S.Schema<DeleteBillEstimateResponse>;
export interface DeleteBillScenarioRequest {
    identifier: string;
}
export declare const DeleteBillScenarioRequest: S.Schema<DeleteBillScenarioRequest>;
export interface DeleteBillScenarioResponse {
}
export declare const DeleteBillScenarioResponse: S.Schema<DeleteBillScenarioResponse>;
export interface DeleteWorkloadEstimateRequest {
    identifier: string;
}
export declare const DeleteWorkloadEstimateRequest: S.Schema<DeleteWorkloadEstimateRequest>;
export interface DeleteWorkloadEstimateResponse {
}
export declare const DeleteWorkloadEstimateResponse: S.Schema<DeleteWorkloadEstimateResponse>;
export interface GetBillEstimateRequest {
    identifier: string;
}
export declare const GetBillEstimateRequest: S.Schema<GetBillEstimateRequest>;
export interface GetBillEstimateResponse {
    id: string;
    name?: string;
    status?: BillEstimateStatus;
    failureMessage?: string;
    billInterval?: BillInterval;
    costSummary?: BillEstimateCostSummary;
    createdAt?: Date;
    expiresAt?: Date;
    groupSharingPreference?: GroupSharingPreferenceEnum;
    costCategoryGroupSharingPreferenceArn?: string;
    costCategoryGroupSharingPreferenceEffectiveDate?: Date;
}
export declare const GetBillEstimateResponse: S.Schema<GetBillEstimateResponse>;
export interface GetBillScenarioRequest {
    identifier: string;
}
export declare const GetBillScenarioRequest: S.Schema<GetBillScenarioRequest>;
export interface GetBillScenarioResponse {
    id: string;
    name?: string;
    billInterval?: BillInterval;
    status?: BillScenarioStatus;
    createdAt?: Date;
    expiresAt?: Date;
    failureMessage?: string;
    groupSharingPreference?: GroupSharingPreferenceEnum;
    costCategoryGroupSharingPreferenceArn?: string;
}
export declare const GetBillScenarioResponse: S.Schema<GetBillScenarioResponse>;
export interface GetPreferencesRequest {
}
export declare const GetPreferencesRequest: S.Schema<GetPreferencesRequest>;
export type RateType = "BEFORE_DISCOUNTS" | "AFTER_DISCOUNTS" | "AFTER_DISCOUNTS_AND_COMMITMENTS" | (string & {});
export declare const RateType: any;
export type RateTypes = RateType[];
export declare const RateTypes: any;
export interface GetPreferencesResponse {
    managementAccountRateTypeSelections?: RateType[];
    memberAccountRateTypeSelections?: RateType[];
    standaloneAccountRateTypeSelections?: RateType[];
}
export declare const GetPreferencesResponse: S.Schema<GetPreferencesResponse>;
export interface GetWorkloadEstimateRequest {
    identifier: string;
}
export declare const GetWorkloadEstimateRequest: S.Schema<GetWorkloadEstimateRequest>;
export interface GetWorkloadEstimateResponse {
    id: string;
    name?: string;
    createdAt?: Date;
    expiresAt?: Date;
    rateType?: WorkloadEstimateRateType;
    rateTimestamp?: Date;
    status?: WorkloadEstimateStatus;
    totalCost?: number;
    costCurrency?: CurrencyCode;
    failureMessage?: string;
}
export declare const GetWorkloadEstimateResponse: S.Schema<GetWorkloadEstimateResponse>;
export type NextPageToken = string;
export type MaxResults = number;
export interface ListBillEstimateCommitmentsRequest {
    billEstimateId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListBillEstimateCommitmentsRequest: S.Schema<ListBillEstimateCommitmentsRequest>;
export type PurchaseAgreementType = "SAVINGS_PLANS" | "RESERVED_INSTANCE" | (string & {});
export declare const PurchaseAgreementType: any;
export interface BillEstimateCommitmentSummary {
    id?: string;
    purchaseAgreementType?: PurchaseAgreementType;
    offeringId?: string;
    usageAccountId?: string;
    region?: string;
    termLength?: string;
    paymentOption?: string;
    upfrontPayment?: CostAmount;
    monthlyPayment?: CostAmount;
}
export declare const BillEstimateCommitmentSummary: S.Schema<BillEstimateCommitmentSummary>;
export type BillEstimateCommitmentSummaries = BillEstimateCommitmentSummary[];
export declare const BillEstimateCommitmentSummaries: any;
export interface ListBillEstimateCommitmentsResponse {
    items?: BillEstimateCommitmentSummary[];
    nextToken?: string;
}
export declare const ListBillEstimateCommitmentsResponse: S.Schema<ListBillEstimateCommitmentsResponse>;
export interface ListBillEstimateInputCommitmentModificationsRequest {
    billEstimateId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListBillEstimateInputCommitmentModificationsRequest: S.Schema<ListBillEstimateInputCommitmentModificationsRequest>;
export interface BillEstimateInputCommitmentModificationSummary {
    id?: string;
    group?: string;
    usageAccountId?: string;
    commitmentAction?: BillScenarioCommitmentModificationAction;
}
export declare const BillEstimateInputCommitmentModificationSummary: S.Schema<BillEstimateInputCommitmentModificationSummary>;
export type BillEstimateInputCommitmentModificationSummaries = BillEstimateInputCommitmentModificationSummary[];
export declare const BillEstimateInputCommitmentModificationSummaries: any;
export interface ListBillEstimateInputCommitmentModificationsResponse {
    items?: BillEstimateInputCommitmentModificationSummary[];
    nextToken?: string;
}
export declare const ListBillEstimateInputCommitmentModificationsResponse: S.Schema<ListBillEstimateInputCommitmentModificationsResponse>;
export type ListUsageFilterName = "USAGE_ACCOUNT_ID" | "SERVICE_CODE" | "USAGE_TYPE" | "OPERATION" | "LOCATION" | "USAGE_GROUP" | "HISTORICAL_USAGE_ACCOUNT_ID" | "HISTORICAL_SERVICE_CODE" | "HISTORICAL_USAGE_TYPE" | "HISTORICAL_OPERATION" | "HISTORICAL_LOCATION" | (string & {});
export declare const ListUsageFilterName: any;
export type ListUsageFilterValues = string[];
export declare const ListUsageFilterValues: any;
export type MatchOption = "EQUALS" | "STARTS_WITH" | "CONTAINS" | (string & {});
export declare const MatchOption: any;
export interface ListUsageFilter {
    name: ListUsageFilterName;
    values: string[];
    matchOption?: MatchOption;
}
export declare const ListUsageFilter: S.Schema<ListUsageFilter>;
export type ListUsageFilters = ListUsageFilter[];
export declare const ListUsageFilters: any;
export interface ListBillEstimateInputUsageModificationsRequest {
    billEstimateId: string;
    filters?: ListUsageFilter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const ListBillEstimateInputUsageModificationsRequest: S.Schema<ListBillEstimateInputUsageModificationsRequest>;
export interface BillEstimateInputUsageModificationSummary {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string;
    availabilityZone?: string;
    id?: string;
    group?: string;
    usageAccountId?: string;
    quantities?: UsageQuantity[];
    historicalUsage?: HistoricalUsageEntity;
}
export declare const BillEstimateInputUsageModificationSummary: S.Schema<BillEstimateInputUsageModificationSummary>;
export type BillEstimateInputUsageModificationSummaries = BillEstimateInputUsageModificationSummary[];
export declare const BillEstimateInputUsageModificationSummaries: any;
export interface ListBillEstimateInputUsageModificationsResponse {
    items?: BillEstimateInputUsageModificationSummary[];
    nextToken?: string;
}
export declare const ListBillEstimateInputUsageModificationsResponse: S.Schema<ListBillEstimateInputUsageModificationsResponse>;
export type ListBillEstimateLineItemsFilterName = "USAGE_ACCOUNT_ID" | "SERVICE_CODE" | "USAGE_TYPE" | "OPERATION" | "LOCATION" | "LINE_ITEM_TYPE" | (string & {});
export declare const ListBillEstimateLineItemsFilterName: any;
export type ListBillEstimateLineItemsFilterValues = string[];
export declare const ListBillEstimateLineItemsFilterValues: any;
export interface ListBillEstimateLineItemsFilter {
    name: ListBillEstimateLineItemsFilterName;
    values: string[];
    matchOption?: MatchOption;
}
export declare const ListBillEstimateLineItemsFilter: S.Schema<ListBillEstimateLineItemsFilter>;
export type ListBillEstimateLineItemsFilters = ListBillEstimateLineItemsFilter[];
export declare const ListBillEstimateLineItemsFilters: any;
export interface ListBillEstimateLineItemsRequest {
    billEstimateId: string;
    filters?: ListBillEstimateLineItemsFilter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const ListBillEstimateLineItemsRequest: S.Schema<ListBillEstimateLineItemsRequest>;
export interface UsageQuantityResult {
    amount?: number;
    unit?: string;
}
export declare const UsageQuantityResult: S.Schema<UsageQuantityResult>;
export type SavingsPlanArns = string[];
export declare const SavingsPlanArns: any;
export interface BillEstimateLineItemSummary {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string;
    availabilityZone?: string;
    id?: string;
    lineItemId?: string;
    lineItemType?: string;
    payerAccountId?: string;
    usageAccountId?: string;
    estimatedUsageQuantity?: UsageQuantityResult;
    estimatedCost?: CostAmount;
    historicalUsageQuantity?: UsageQuantityResult;
    historicalCost?: CostAmount;
    savingsPlanArns?: string[];
}
export declare const BillEstimateLineItemSummary: S.Schema<BillEstimateLineItemSummary>;
export type BillEstimateLineItemSummaries = BillEstimateLineItemSummary[];
export declare const BillEstimateLineItemSummaries: any;
export interface ListBillEstimateLineItemsResponse {
    items?: BillEstimateLineItemSummary[];
    nextToken?: string;
}
export declare const ListBillEstimateLineItemsResponse: S.Schema<ListBillEstimateLineItemsResponse>;
export type ListBillEstimatesFilterName = "STATUS" | "NAME" | (string & {});
export declare const ListBillEstimatesFilterName: any;
export type ListBillEstimatesFilterValues = string[];
export declare const ListBillEstimatesFilterValues: any;
export interface ListBillEstimatesFilter {
    name: ListBillEstimatesFilterName;
    values: string[];
    matchOption?: MatchOption;
}
export declare const ListBillEstimatesFilter: S.Schema<ListBillEstimatesFilter>;
export type ListBillEstimatesFilters = ListBillEstimatesFilter[];
export declare const ListBillEstimatesFilters: any;
export interface FilterTimestamp {
    afterTimestamp?: Date;
    beforeTimestamp?: Date;
}
export declare const FilterTimestamp: S.Schema<FilterTimestamp>;
export interface ListBillEstimatesRequest {
    filters?: ListBillEstimatesFilter[];
    createdAtFilter?: FilterTimestamp;
    expiresAtFilter?: FilterTimestamp;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListBillEstimatesRequest: S.Schema<ListBillEstimatesRequest>;
export interface BillEstimateSummary {
    id: string;
    name?: string;
    status?: BillEstimateStatus;
    billInterval?: BillInterval;
    createdAt?: Date;
    expiresAt?: Date;
}
export declare const BillEstimateSummary: S.Schema<BillEstimateSummary>;
export type BillEstimateSummaries = BillEstimateSummary[];
export declare const BillEstimateSummaries: any;
export interface ListBillEstimatesResponse {
    items?: BillEstimateSummary[];
    nextToken?: string;
}
export declare const ListBillEstimatesResponse: S.Schema<ListBillEstimatesResponse>;
export interface ListBillScenarioCommitmentModificationsRequest {
    billScenarioId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListBillScenarioCommitmentModificationsRequest: S.Schema<ListBillScenarioCommitmentModificationsRequest>;
export interface ListBillScenarioCommitmentModificationsResponse {
    items?: BillScenarioCommitmentModificationItem[];
    nextToken?: string;
}
export declare const ListBillScenarioCommitmentModificationsResponse: S.Schema<ListBillScenarioCommitmentModificationsResponse>;
export type ListBillScenariosFilterName = "STATUS" | "NAME" | "GROUP_SHARING_PREFERENCE" | "COST_CATEGORY_ARN" | (string & {});
export declare const ListBillScenariosFilterName: any;
export type ListBillScenariosFilterValues = string[];
export declare const ListBillScenariosFilterValues: any;
export interface ListBillScenariosFilter {
    name: ListBillScenariosFilterName;
    values: string[];
    matchOption?: MatchOption;
}
export declare const ListBillScenariosFilter: S.Schema<ListBillScenariosFilter>;
export type ListBillScenariosFilters = ListBillScenariosFilter[];
export declare const ListBillScenariosFilters: any;
export interface ListBillScenariosRequest {
    filters?: ListBillScenariosFilter[];
    createdAtFilter?: FilterTimestamp;
    expiresAtFilter?: FilterTimestamp;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListBillScenariosRequest: S.Schema<ListBillScenariosRequest>;
export interface BillScenarioSummary {
    id: string;
    name?: string;
    billInterval?: BillInterval;
    status?: BillScenarioStatus;
    createdAt?: Date;
    expiresAt?: Date;
    failureMessage?: string;
    groupSharingPreference?: GroupSharingPreferenceEnum;
    costCategoryGroupSharingPreferenceArn?: string;
}
export declare const BillScenarioSummary: S.Schema<BillScenarioSummary>;
export type BillScenarioSummaries = BillScenarioSummary[];
export declare const BillScenarioSummaries: any;
export interface ListBillScenariosResponse {
    items?: BillScenarioSummary[];
    nextToken?: string;
}
export declare const ListBillScenariosResponse: S.Schema<ListBillScenariosResponse>;
export interface ListBillScenarioUsageModificationsRequest {
    billScenarioId: string;
    filters?: ListUsageFilter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const ListBillScenarioUsageModificationsRequest: S.Schema<ListBillScenarioUsageModificationsRequest>;
export interface ListBillScenarioUsageModificationsResponse {
    items?: BillScenarioUsageModificationItem[];
    nextToken?: string;
}
export declare const ListBillScenarioUsageModificationsResponse: S.Schema<ListBillScenarioUsageModificationsResponse>;
export type Arn = string;
export interface ListTagsForResourceRequest {
    arn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type ListWorkloadEstimatesFilterName = "STATUS" | "NAME" | (string & {});
export declare const ListWorkloadEstimatesFilterName: any;
export type ListWorkloadEstimatesFilterValues = string[];
export declare const ListWorkloadEstimatesFilterValues: any;
export interface ListWorkloadEstimatesFilter {
    name: ListWorkloadEstimatesFilterName;
    values: string[];
    matchOption?: MatchOption;
}
export declare const ListWorkloadEstimatesFilter: S.Schema<ListWorkloadEstimatesFilter>;
export type ListWorkloadEstimatesFilters = ListWorkloadEstimatesFilter[];
export declare const ListWorkloadEstimatesFilters: any;
export interface ListWorkloadEstimatesRequest {
    createdAtFilter?: FilterTimestamp;
    expiresAtFilter?: FilterTimestamp;
    filters?: ListWorkloadEstimatesFilter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const ListWorkloadEstimatesRequest: S.Schema<ListWorkloadEstimatesRequest>;
export interface WorkloadEstimateSummary {
    id: string;
    name?: string;
    createdAt?: Date;
    expiresAt?: Date;
    rateType?: WorkloadEstimateRateType;
    rateTimestamp?: Date;
    status?: WorkloadEstimateStatus;
    totalCost?: number;
    costCurrency?: CurrencyCode;
    failureMessage?: string;
}
export declare const WorkloadEstimateSummary: S.Schema<WorkloadEstimateSummary>;
export type WorkloadEstimateSummaries = WorkloadEstimateSummary[];
export declare const WorkloadEstimateSummaries: any;
export interface ListWorkloadEstimatesResponse {
    items?: WorkloadEstimateSummary[];
    nextToken?: string;
}
export declare const ListWorkloadEstimatesResponse: S.Schema<ListWorkloadEstimatesResponse>;
export type WorkloadEstimateUsageMaxResults = number;
export interface ListWorkloadEstimateUsageRequest {
    workloadEstimateId: string;
    filters?: ListUsageFilter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const ListWorkloadEstimateUsageRequest: S.Schema<ListWorkloadEstimateUsageRequest>;
export interface ListWorkloadEstimateUsageResponse {
    items?: WorkloadEstimateUsageItem[];
    nextToken?: string;
}
export declare const ListWorkloadEstimateUsageResponse: S.Schema<ListWorkloadEstimateUsageResponse>;
export interface TagResourceRequest {
    arn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type ResourceTagKeys = string[];
export declare const ResourceTagKeys: any;
export interface UntagResourceRequest {
    arn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateBillEstimateRequest {
    identifier: string;
    name?: string;
    expiresAt?: Date;
}
export declare const UpdateBillEstimateRequest: S.Schema<UpdateBillEstimateRequest>;
export interface UpdateBillEstimateResponse {
    id: string;
    name?: string;
    status?: BillEstimateStatus;
    failureMessage?: string;
    billInterval?: BillInterval;
    costSummary?: BillEstimateCostSummary;
    createdAt?: Date;
    expiresAt?: Date;
    groupSharingPreference?: GroupSharingPreferenceEnum;
    costCategoryGroupSharingPreferenceArn?: string;
    costCategoryGroupSharingPreferenceEffectiveDate?: Date;
}
export declare const UpdateBillEstimateResponse: S.Schema<UpdateBillEstimateResponse>;
export interface UpdateBillScenarioRequest {
    identifier: string;
    name?: string;
    expiresAt?: Date;
    groupSharingPreference?: GroupSharingPreferenceEnum;
    costCategoryGroupSharingPreferenceArn?: string;
}
export declare const UpdateBillScenarioRequest: S.Schema<UpdateBillScenarioRequest>;
export interface UpdateBillScenarioResponse {
    id: string;
    name?: string;
    billInterval?: BillInterval;
    status?: BillScenarioStatus;
    createdAt?: Date;
    expiresAt?: Date;
    failureMessage?: string;
    groupSharingPreference?: GroupSharingPreferenceEnum;
    costCategoryGroupSharingPreferenceArn?: string;
}
export declare const UpdateBillScenarioResponse: S.Schema<UpdateBillScenarioResponse>;
export interface UpdatePreferencesRequest {
    managementAccountRateTypeSelections?: RateType[];
    memberAccountRateTypeSelections?: RateType[];
    standaloneAccountRateTypeSelections?: RateType[];
}
export declare const UpdatePreferencesRequest: S.Schema<UpdatePreferencesRequest>;
export interface UpdatePreferencesResponse {
    managementAccountRateTypeSelections?: RateType[];
    memberAccountRateTypeSelections?: RateType[];
    standaloneAccountRateTypeSelections?: RateType[];
}
export declare const UpdatePreferencesResponse: S.Schema<UpdatePreferencesResponse>;
export interface UpdateWorkloadEstimateRequest {
    identifier: string;
    name?: string;
    expiresAt?: Date;
}
export declare const UpdateWorkloadEstimateRequest: S.Schema<UpdateWorkloadEstimateRequest>;
export interface UpdateWorkloadEstimateResponse {
    id: string;
    name?: string;
    createdAt?: Date;
    expiresAt?: Date;
    rateType?: WorkloadEstimateRateType;
    rateTimestamp?: Date;
    status?: WorkloadEstimateStatus;
    totalCost?: number;
    costCurrency?: CurrencyCode;
    failureMessage?: string;
}
export declare const UpdateWorkloadEstimateResponse: S.Schema<UpdateWorkloadEstimateResponse>;
export type BatchCreateBillScenarioCommitmentModificationError = ConflictException | DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Create Compute Savings Plans, EC2 Instance Savings Plans, or EC2 Reserved Instances commitments that you want to model in a Bill Scenario.
 *
 * The `BatchCreateBillScenarioCommitmentModification` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:CreateBillScenarioCommitmentModification` in your policies.
 */
export declare const batchCreateBillScenarioCommitmentModification: API.OperationMethod<BatchCreateBillScenarioCommitmentModificationRequest, BatchCreateBillScenarioCommitmentModificationResponse, BatchCreateBillScenarioCommitmentModificationError, Credentials | HttpClient.HttpClient>;
export type BatchCreateBillScenarioUsageModificationError = ConflictException | DataUnavailableException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create Amazon Web Services service usage that you want to model in a Bill Scenario.
 *
 * The `BatchCreateBillScenarioUsageModification` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:CreateBillScenarioUsageModification` in your policies.
 */
export declare const batchCreateBillScenarioUsageModification: API.OperationMethod<BatchCreateBillScenarioUsageModificationRequest, BatchCreateBillScenarioUsageModificationResponse, BatchCreateBillScenarioUsageModificationError, Credentials | HttpClient.HttpClient>;
export type BatchCreateWorkloadEstimateUsageError = ConflictException | DataUnavailableException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create Amazon Web Services service usage that you want to model in a Workload Estimate.
 *
 * The `BatchCreateWorkloadEstimateUsage` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:CreateWorkloadEstimateUsage` in your policies.
 */
export declare const batchCreateWorkloadEstimateUsage: API.OperationMethod<BatchCreateWorkloadEstimateUsageRequest, BatchCreateWorkloadEstimateUsageResponse, BatchCreateWorkloadEstimateUsageError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteBillScenarioCommitmentModificationError = ConflictException | DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Delete commitment that you have created in a Bill Scenario. You can only delete a commitment that you had added and cannot model deletion (or removal) of a existing commitment. If you want model deletion of an existing commitment, see the negate BillScenarioCommitmentModificationAction of BatchCreateBillScenarioCommitmentModification operation.
 *
 * The `BatchDeleteBillScenarioCommitmentModification` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:DeleteBillScenarioCommitmentModification` in your policies.
 */
export declare const batchDeleteBillScenarioCommitmentModification: API.OperationMethod<BatchDeleteBillScenarioCommitmentModificationRequest, BatchDeleteBillScenarioCommitmentModificationResponse, BatchDeleteBillScenarioCommitmentModificationError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteBillScenarioUsageModificationError = ConflictException | DataUnavailableException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Delete usage that you have created in a Bill Scenario. You can only delete usage that you had added and cannot model deletion (or removal) of a existing usage. If you want model removal of an existing usage, see BatchUpdateBillScenarioUsageModification.
 *
 * The `BatchDeleteBillScenarioUsageModification` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:DeleteBillScenarioUsageModification` in your policies.
 */
export declare const batchDeleteBillScenarioUsageModification: API.OperationMethod<BatchDeleteBillScenarioUsageModificationRequest, BatchDeleteBillScenarioUsageModificationResponse, BatchDeleteBillScenarioUsageModificationError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteWorkloadEstimateUsageError = DataUnavailableException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Delete usage that you have created in a Workload estimate. You can only delete usage that you had added and cannot model deletion (or removal) of a existing usage. If you want model removal of an existing usage, see BatchUpdateWorkloadEstimateUsage.
 *
 * The `BatchDeleteWorkloadEstimateUsage` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:DeleteWorkloadEstimateUsage` in your policies.
 */
export declare const batchDeleteWorkloadEstimateUsage: API.OperationMethod<BatchDeleteWorkloadEstimateUsageRequest, BatchDeleteWorkloadEstimateUsageResponse, BatchDeleteWorkloadEstimateUsageError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateBillScenarioCommitmentModificationError = ConflictException | DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Update a newly added or existing commitment. You can update the commitment group based on a commitment ID and a Bill scenario ID.
 *
 * The `BatchUpdateBillScenarioCommitmentModification` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:UpdateBillScenarioCommitmentModification` in your policies.
 */
export declare const batchUpdateBillScenarioCommitmentModification: API.OperationMethod<BatchUpdateBillScenarioCommitmentModificationRequest, BatchUpdateBillScenarioCommitmentModificationResponse, BatchUpdateBillScenarioCommitmentModificationError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateBillScenarioUsageModificationError = ConflictException | DataUnavailableException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Update a newly added or existing usage lines. You can update the usage amounts, usage hour, and usage group based on a usage ID and a Bill scenario ID.
 *
 * The `BatchUpdateBillScenarioUsageModification` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:UpdateBillScenarioUsageModification` in your policies.
 */
export declare const batchUpdateBillScenarioUsageModification: API.OperationMethod<BatchUpdateBillScenarioUsageModificationRequest, BatchUpdateBillScenarioUsageModificationResponse, BatchUpdateBillScenarioUsageModificationError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateWorkloadEstimateUsageError = DataUnavailableException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Update a newly added or existing usage lines. You can update the usage amounts and usage group based on a usage ID and a Workload estimate ID.
 *
 * The `BatchUpdateWorkloadEstimateUsage` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:UpdateWorkloadEstimateUsage` in your policies.
 */
export declare const batchUpdateWorkloadEstimateUsage: API.OperationMethod<BatchUpdateWorkloadEstimateUsageRequest, BatchUpdateWorkloadEstimateUsageResponse, BatchUpdateWorkloadEstimateUsageError, Credentials | HttpClient.HttpClient>;
export type CreateBillEstimateError = ConflictException | DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Create a Bill estimate from a Bill scenario. In the Bill scenario you can model usage addition, usage changes, and usage removal. You can also model commitment addition and commitment removal. After all changes in a Bill scenario is made satisfactorily, you can call this API with a Bill scenario ID to generate the Bill estimate. Bill estimate calculates the pre-tax cost for your consolidated billing family, incorporating all modeled usage and commitments alongside existing usage and commitments from your most recent completed anniversary bill, with any applicable discounts applied.
 */
export declare const createBillEstimate: API.OperationMethod<CreateBillEstimateRequest, CreateBillEstimateResponse, CreateBillEstimateError, Credentials | HttpClient.HttpClient>;
export type CreateBillScenarioError = ConflictException | DataUnavailableException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new bill scenario to model potential changes to Amazon Web Services usage and costs.
 */
export declare const createBillScenario: API.OperationMethod<CreateBillScenarioRequest, CreateBillScenarioResponse, CreateBillScenarioError, Credentials | HttpClient.HttpClient>;
export type CreateWorkloadEstimateError = ConflictException | DataUnavailableException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new workload estimate to model costs for a specific workload.
 */
export declare const createWorkloadEstimate: API.OperationMethod<CreateWorkloadEstimateRequest, CreateWorkloadEstimateResponse, CreateWorkloadEstimateError, Credentials | HttpClient.HttpClient>;
export type DeleteBillEstimateError = ConflictException | DataUnavailableException | CommonErrors;
/**
 * Deletes an existing bill estimate.
 */
export declare const deleteBillEstimate: API.OperationMethod<DeleteBillEstimateRequest, DeleteBillEstimateResponse, DeleteBillEstimateError, Credentials | HttpClient.HttpClient>;
export type DeleteBillScenarioError = ConflictException | DataUnavailableException | CommonErrors;
/**
 * Deletes an existing bill scenario.
 */
export declare const deleteBillScenario: API.OperationMethod<DeleteBillScenarioRequest, DeleteBillScenarioResponse, DeleteBillScenarioError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkloadEstimateError = DataUnavailableException | CommonErrors;
/**
 * Deletes an existing workload estimate.
 */
export declare const deleteWorkloadEstimate: API.OperationMethod<DeleteWorkloadEstimateRequest, DeleteWorkloadEstimateResponse, DeleteWorkloadEstimateError, Credentials | HttpClient.HttpClient>;
export type GetBillEstimateError = DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves details of a specific bill estimate.
 */
export declare const getBillEstimate: API.OperationMethod<GetBillEstimateRequest, GetBillEstimateResponse, GetBillEstimateError, Credentials | HttpClient.HttpClient>;
export type GetBillScenarioError = DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves details of a specific bill scenario.
 */
export declare const getBillScenario: API.OperationMethod<GetBillScenarioRequest, GetBillScenarioResponse, GetBillScenarioError, Credentials | HttpClient.HttpClient>;
export type GetPreferencesError = DataUnavailableException | CommonErrors;
/**
 * Retrieves the current preferences for Pricing Calculator.
 */
export declare const getPreferences: API.OperationMethod<GetPreferencesRequest, GetPreferencesResponse, GetPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetWorkloadEstimateError = DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves details of a specific workload estimate.
 */
export declare const getWorkloadEstimate: API.OperationMethod<GetWorkloadEstimateRequest, GetWorkloadEstimateResponse, GetWorkloadEstimateError, Credentials | HttpClient.HttpClient>;
export type ListBillEstimateCommitmentsError = DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the commitments associated with a bill estimate.
 */
export declare const listBillEstimateCommitments: API.PaginatedOperationMethod<ListBillEstimateCommitmentsRequest, ListBillEstimateCommitmentsResponse, ListBillEstimateCommitmentsError, Credentials | HttpClient.HttpClient, BillEstimateCommitmentSummary>;
export type ListBillEstimateInputCommitmentModificationsError = DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the input commitment modifications associated with a bill estimate.
 */
export declare const listBillEstimateInputCommitmentModifications: API.PaginatedOperationMethod<ListBillEstimateInputCommitmentModificationsRequest, ListBillEstimateInputCommitmentModificationsResponse, ListBillEstimateInputCommitmentModificationsError, Credentials | HttpClient.HttpClient, BillEstimateInputCommitmentModificationSummary>;
export type ListBillEstimateInputUsageModificationsError = DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the input usage modifications associated with a bill estimate.
 */
export declare const listBillEstimateInputUsageModifications: API.PaginatedOperationMethod<ListBillEstimateInputUsageModificationsRequest, ListBillEstimateInputUsageModificationsResponse, ListBillEstimateInputUsageModificationsError, Credentials | HttpClient.HttpClient, BillEstimateInputUsageModificationSummary>;
export type ListBillEstimateLineItemsError = DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the line items associated with a bill estimate.
 */
export declare const listBillEstimateLineItems: API.PaginatedOperationMethod<ListBillEstimateLineItemsRequest, ListBillEstimateLineItemsResponse, ListBillEstimateLineItemsError, Credentials | HttpClient.HttpClient, BillEstimateLineItemSummary>;
export type ListBillEstimatesError = DataUnavailableException | CommonErrors;
/**
 * Lists all bill estimates for the account.
 */
export declare const listBillEstimates: API.PaginatedOperationMethod<ListBillEstimatesRequest, ListBillEstimatesResponse, ListBillEstimatesError, Credentials | HttpClient.HttpClient, BillEstimateSummary>;
export type ListBillScenarioCommitmentModificationsError = DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the commitment modifications associated with a bill scenario.
 */
export declare const listBillScenarioCommitmentModifications: API.PaginatedOperationMethod<ListBillScenarioCommitmentModificationsRequest, ListBillScenarioCommitmentModificationsResponse, ListBillScenarioCommitmentModificationsError, Credentials | HttpClient.HttpClient, BillScenarioCommitmentModificationItem>;
export type ListBillScenariosError = DataUnavailableException | CommonErrors;
/**
 * Lists all bill scenarios for the account.
 */
export declare const listBillScenarios: API.PaginatedOperationMethod<ListBillScenariosRequest, ListBillScenariosResponse, ListBillScenariosError, Credentials | HttpClient.HttpClient, BillScenarioSummary>;
export type ListBillScenarioUsageModificationsError = DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the usage modifications associated with a bill scenario.
 */
export declare const listBillScenarioUsageModifications: API.PaginatedOperationMethod<ListBillScenarioUsageModificationsRequest, ListBillScenarioUsageModificationsResponse, ListBillScenarioUsageModificationsError, Credentials | HttpClient.HttpClient, BillScenarioUsageModificationItem>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Lists all tags associated with a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkloadEstimatesError = DataUnavailableException | CommonErrors;
/**
 * Lists all workload estimates for the account.
 */
export declare const listWorkloadEstimates: API.PaginatedOperationMethod<ListWorkloadEstimatesRequest, ListWorkloadEstimatesResponse, ListWorkloadEstimatesError, Credentials | HttpClient.HttpClient, WorkloadEstimateSummary>;
export type ListWorkloadEstimateUsageError = DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the usage associated with a workload estimate.
 */
export declare const listWorkloadEstimateUsage: API.PaginatedOperationMethod<ListWorkloadEstimateUsageRequest, ListWorkloadEstimateUsageResponse, ListWorkloadEstimateUsageError, Credentials | HttpClient.HttpClient, WorkloadEstimateUsageItem>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Adds one or more tags to a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBillEstimateError = ConflictException | DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an existing bill estimate.
 */
export declare const updateBillEstimate: API.OperationMethod<UpdateBillEstimateRequest, UpdateBillEstimateResponse, UpdateBillEstimateError, Credentials | HttpClient.HttpClient>;
export type UpdateBillScenarioError = ConflictException | DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an existing bill scenario.
 */
export declare const updateBillScenario: API.OperationMethod<UpdateBillScenarioRequest, UpdateBillScenarioResponse, UpdateBillScenarioError, Credentials | HttpClient.HttpClient>;
export type UpdatePreferencesError = DataUnavailableException | ServiceQuotaExceededException | CommonErrors;
/**
 * Updates the preferences for Pricing Calculator.
 */
export declare const updatePreferences: API.OperationMethod<UpdatePreferencesRequest, UpdatePreferencesResponse, UpdatePreferencesError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkloadEstimateError = ConflictException | DataUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an existing workload estimate.
 */
export declare const updateWorkloadEstimate: API.OperationMethod<UpdateWorkloadEstimateRequest, UpdateWorkloadEstimateResponse, UpdateWorkloadEstimateError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bcm-pricing-calculator.d.ts.map