import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidCampaignStateException_base: S.Class<InvalidCampaignStateException, S.TaggedStruct<"InvalidCampaignStateException", {
    readonly state: any;
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidCampaignStateException extends /*@__PURE__*/ InvalidCampaignStateException_base {
}
declare const InvalidStateException_base: S.Class<InvalidStateException, S.TaggedStruct<"InvalidStateException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CampaignName = string;
export type InstanceId = string;
export type BandwidthAllocation = number;
export type DialingCapacity = number;
export interface ProgressiveDialerConfig {
    bandwidthAllocation: number;
    dialingCapacity?: number;
}
export declare const ProgressiveDialerConfig: S.Schema<ProgressiveDialerConfig>;
export interface PredictiveDialerConfig {
    bandwidthAllocation: number;
    dialingCapacity?: number;
}
export declare const PredictiveDialerConfig: S.Schema<PredictiveDialerConfig>;
export interface AgentlessDialerConfig {
    dialingCapacity?: number;
}
export declare const AgentlessDialerConfig: S.Schema<AgentlessDialerConfig>;
export type DialerConfig = {
    progressiveDialerConfig: ProgressiveDialerConfig;
    predictiveDialerConfig?: never;
    agentlessDialerConfig?: never;
} | {
    progressiveDialerConfig?: never;
    predictiveDialerConfig: PredictiveDialerConfig;
    agentlessDialerConfig?: never;
} | {
    progressiveDialerConfig?: never;
    predictiveDialerConfig?: never;
    agentlessDialerConfig: AgentlessDialerConfig;
};
export declare const DialerConfig: any;
export type ContactFlowId = string;
export type SourcePhoneNumber = string;
export type QueueId = string;
export interface AnswerMachineDetectionConfig {
    enableAnswerMachineDetection: boolean;
    awaitAnswerMachinePrompt?: boolean;
}
export declare const AnswerMachineDetectionConfig: S.Schema<AnswerMachineDetectionConfig>;
export interface OutboundCallConfig {
    connectContactFlowId: string;
    connectSourcePhoneNumber?: string;
    connectQueueId?: string;
    answerMachineDetectionConfig?: AnswerMachineDetectionConfig;
}
export declare const OutboundCallConfig: S.Schema<OutboundCallConfig>;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateCampaignRequest {
    name: string;
    connectInstanceId: string;
    dialerConfig: DialerConfig;
    outboundCallConfig: OutboundCallConfig;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateCampaignRequest: S.Schema<CreateCampaignRequest>;
export type CampaignId = string;
export type CampaignArn = string;
export interface CreateCampaignResponse {
    id?: string;
    arn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateCampaignResponse: S.Schema<CreateCampaignResponse>;
export interface DeleteCampaignRequest {
    id: string;
}
export declare const DeleteCampaignRequest: S.Schema<DeleteCampaignRequest>;
export interface DeleteCampaignResponse {
}
export declare const DeleteCampaignResponse: S.Schema<DeleteCampaignResponse>;
export interface DeleteConnectInstanceConfigRequest {
    connectInstanceId: string;
}
export declare const DeleteConnectInstanceConfigRequest: S.Schema<DeleteConnectInstanceConfigRequest>;
export interface DeleteConnectInstanceConfigResponse {
}
export declare const DeleteConnectInstanceConfigResponse: S.Schema<DeleteConnectInstanceConfigResponse>;
export interface DeleteInstanceOnboardingJobRequest {
    connectInstanceId: string;
}
export declare const DeleteInstanceOnboardingJobRequest: S.Schema<DeleteInstanceOnboardingJobRequest>;
export interface DeleteInstanceOnboardingJobResponse {
}
export declare const DeleteInstanceOnboardingJobResponse: S.Schema<DeleteInstanceOnboardingJobResponse>;
export interface DescribeCampaignRequest {
    id: string;
}
export declare const DescribeCampaignRequest: S.Schema<DescribeCampaignRequest>;
export interface Campaign {
    id: string;
    arn: string;
    name: string;
    connectInstanceId: string;
    dialerConfig: DialerConfig;
    outboundCallConfig: OutboundCallConfig;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Campaign: S.Schema<Campaign>;
export interface DescribeCampaignResponse {
    campaign?: Campaign;
}
export declare const DescribeCampaignResponse: S.Schema<DescribeCampaignResponse>;
export interface GetCampaignStateRequest {
    id: string;
}
export declare const GetCampaignStateRequest: S.Schema<GetCampaignStateRequest>;
export type CampaignState = string;
export interface GetCampaignStateResponse {
    state?: string;
}
export declare const GetCampaignStateResponse: S.Schema<GetCampaignStateResponse>;
export type CampaignIdList = string[];
export declare const CampaignIdList: any;
export interface GetCampaignStateBatchRequest {
    campaignIds: string[];
}
export declare const GetCampaignStateBatchRequest: S.Schema<GetCampaignStateBatchRequest>;
export interface SuccessfulCampaignStateResponse {
    campaignId?: string;
    state?: string;
}
export declare const SuccessfulCampaignStateResponse: S.Schema<SuccessfulCampaignStateResponse>;
export type SuccessfulCampaignStateResponseList = SuccessfulCampaignStateResponse[];
export declare const SuccessfulCampaignStateResponseList: any;
export type GetCampaignStateBatchFailureCode = string;
export interface FailedCampaignStateResponse {
    campaignId?: string;
    failureCode?: string;
}
export declare const FailedCampaignStateResponse: S.Schema<FailedCampaignStateResponse>;
export type FailedCampaignStateResponseList = FailedCampaignStateResponse[];
export declare const FailedCampaignStateResponseList: any;
export interface GetCampaignStateBatchResponse {
    successfulRequests?: SuccessfulCampaignStateResponse[];
    failedRequests?: FailedCampaignStateResponse[];
}
export declare const GetCampaignStateBatchResponse: S.Schema<GetCampaignStateBatchResponse>;
export interface GetConnectInstanceConfigRequest {
    connectInstanceId: string;
}
export declare const GetConnectInstanceConfigRequest: S.Schema<GetConnectInstanceConfigRequest>;
export type ServiceLinkedRoleArn = string;
export type Enabled = boolean;
export type EncryptionType = string;
export type EncryptionKey = string;
export interface EncryptionConfig {
    enabled: boolean;
    encryptionType?: string;
    keyArn?: string;
}
export declare const EncryptionConfig: S.Schema<EncryptionConfig>;
export interface InstanceConfig {
    connectInstanceId: string;
    serviceLinkedRoleArn: string;
    encryptionConfig: EncryptionConfig;
}
export declare const InstanceConfig: S.Schema<InstanceConfig>;
export interface GetConnectInstanceConfigResponse {
    connectInstanceConfig?: InstanceConfig;
}
export declare const GetConnectInstanceConfigResponse: S.Schema<GetConnectInstanceConfigResponse>;
export interface GetInstanceOnboardingJobStatusRequest {
    connectInstanceId: string;
}
export declare const GetInstanceOnboardingJobStatusRequest: S.Schema<GetInstanceOnboardingJobStatusRequest>;
export type InstanceOnboardingJobStatusCode = string;
export type InstanceOnboardingJobFailureCode = string;
export interface InstanceOnboardingJobStatus {
    connectInstanceId: string;
    status: string;
    failureCode?: string;
}
export declare const InstanceOnboardingJobStatus: S.Schema<InstanceOnboardingJobStatus>;
export interface GetInstanceOnboardingJobStatusResponse {
    connectInstanceOnboardingJobStatus?: InstanceOnboardingJobStatus;
}
export declare const GetInstanceOnboardingJobStatusResponse: S.Schema<GetInstanceOnboardingJobStatusResponse>;
export type MaxResults = number;
export type NextToken = string;
export type InstanceIdFilterOperator = string;
export interface InstanceIdFilter {
    value: string;
    operator: string;
}
export declare const InstanceIdFilter: S.Schema<InstanceIdFilter>;
export interface CampaignFilters {
    instanceIdFilter?: InstanceIdFilter;
}
export declare const CampaignFilters: S.Schema<CampaignFilters>;
export interface ListCampaignsRequest {
    maxResults?: number;
    nextToken?: string;
    filters?: CampaignFilters;
}
export declare const ListCampaignsRequest: S.Schema<ListCampaignsRequest>;
export interface CampaignSummary {
    id: string;
    arn: string;
    name: string;
    connectInstanceId: string;
}
export declare const CampaignSummary: S.Schema<CampaignSummary>;
export type CampaignSummaryList = CampaignSummary[];
export declare const CampaignSummaryList: any;
export interface ListCampaignsResponse {
    nextToken?: string;
    campaignSummaryList?: CampaignSummary[];
}
export declare const ListCampaignsResponse: S.Schema<ListCampaignsResponse>;
export type Arn = string;
export interface ListTagsForResourceRequest {
    arn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PauseCampaignRequest {
    id: string;
}
export declare const PauseCampaignRequest: S.Schema<PauseCampaignRequest>;
export interface PauseCampaignResponse {
}
export declare const PauseCampaignResponse: S.Schema<PauseCampaignResponse>;
export type ClientToken = string;
export type DestinationPhoneNumber = string | redacted.Redacted<string>;
export type AttributeName = string;
export type AttributeValue = string;
export type Attributes = {
    [key: string]: string | undefined;
};
export declare const Attributes: any;
export interface DialRequest {
    clientToken: string;
    phoneNumber: string | redacted.Redacted<string>;
    expirationTime: Date;
    attributes: {
        [key: string]: string | undefined;
    };
}
export declare const DialRequest: S.Schema<DialRequest>;
export type DialRequestList = DialRequest[];
export declare const DialRequestList: any;
export interface PutDialRequestBatchRequest {
    id: string;
    dialRequests: DialRequest[];
}
export declare const PutDialRequestBatchRequest: S.Schema<PutDialRequestBatchRequest>;
export type DialRequestId = string;
export interface SuccessfulRequest {
    clientToken?: string;
    id?: string;
}
export declare const SuccessfulRequest: S.Schema<SuccessfulRequest>;
export type SuccessfulRequestList = SuccessfulRequest[];
export declare const SuccessfulRequestList: any;
export type FailureCode = string;
export interface FailedRequest {
    clientToken?: string;
    id?: string;
    failureCode?: string;
}
export declare const FailedRequest: S.Schema<FailedRequest>;
export type FailedRequestList = FailedRequest[];
export declare const FailedRequestList: any;
export interface PutDialRequestBatchResponse {
    successfulRequests?: SuccessfulRequest[];
    failedRequests?: FailedRequest[];
}
export declare const PutDialRequestBatchResponse: S.Schema<PutDialRequestBatchResponse>;
export interface ResumeCampaignRequest {
    id: string;
}
export declare const ResumeCampaignRequest: S.Schema<ResumeCampaignRequest>;
export interface ResumeCampaignResponse {
}
export declare const ResumeCampaignResponse: S.Schema<ResumeCampaignResponse>;
export interface StartCampaignRequest {
    id: string;
}
export declare const StartCampaignRequest: S.Schema<StartCampaignRequest>;
export interface StartCampaignResponse {
}
export declare const StartCampaignResponse: S.Schema<StartCampaignResponse>;
export interface StartInstanceOnboardingJobRequest {
    connectInstanceId: string;
    encryptionConfig: EncryptionConfig;
}
export declare const StartInstanceOnboardingJobRequest: S.Schema<StartInstanceOnboardingJobRequest>;
export interface StartInstanceOnboardingJobResponse {
    connectInstanceOnboardingJobStatus?: InstanceOnboardingJobStatus;
}
export declare const StartInstanceOnboardingJobResponse: S.Schema<StartInstanceOnboardingJobResponse>;
export interface StopCampaignRequest {
    id: string;
}
export declare const StopCampaignRequest: S.Schema<StopCampaignRequest>;
export interface StopCampaignResponse {
}
export declare const StopCampaignResponse: S.Schema<StopCampaignResponse>;
export interface TagResourceRequest {
    arn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    arn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateCampaignDialerConfigRequest {
    id: string;
    dialerConfig: DialerConfig;
}
export declare const UpdateCampaignDialerConfigRequest: S.Schema<UpdateCampaignDialerConfigRequest>;
export interface UpdateCampaignDialerConfigResponse {
}
export declare const UpdateCampaignDialerConfigResponse: S.Schema<UpdateCampaignDialerConfigResponse>;
export interface UpdateCampaignNameRequest {
    id: string;
    name: string;
}
export declare const UpdateCampaignNameRequest: S.Schema<UpdateCampaignNameRequest>;
export interface UpdateCampaignNameResponse {
}
export declare const UpdateCampaignNameResponse: S.Schema<UpdateCampaignNameResponse>;
export interface UpdateCampaignOutboundCallConfigRequest {
    id: string;
    connectContactFlowId?: string;
    connectSourcePhoneNumber?: string;
    answerMachineDetectionConfig?: AnswerMachineDetectionConfig;
}
export declare const UpdateCampaignOutboundCallConfigRequest: S.Schema<UpdateCampaignOutboundCallConfigRequest>;
export interface UpdateCampaignOutboundCallConfigResponse {
}
export declare const UpdateCampaignOutboundCallConfigResponse: S.Schema<UpdateCampaignOutboundCallConfigResponse>;
export type XAmazonErrorType = string;
export type CreateCampaignError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a campaign for the specified Amazon Connect account. This API is idempotent.
 */
export declare const createCampaign: API.OperationMethod<CreateCampaignRequest, CreateCampaignResponse, CreateCampaignError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a campaign from the specified Amazon Connect account.
 */
export declare const deleteCampaign: API.OperationMethod<DeleteCampaignRequest, DeleteCampaignResponse, DeleteCampaignError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectInstanceConfigError = AccessDeniedException | InternalServerException | InvalidStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a connect instance config from the specified AWS account.
 */
export declare const deleteConnectInstanceConfig: API.OperationMethod<DeleteConnectInstanceConfigRequest, DeleteConnectInstanceConfigResponse, DeleteConnectInstanceConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteInstanceOnboardingJobError = AccessDeniedException | InternalServerException | InvalidStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete the Connect Campaigns onboarding job for the specified Amazon Connect instance.
 */
export declare const deleteInstanceOnboardingJob: API.OperationMethod<DeleteInstanceOnboardingJobRequest, DeleteInstanceOnboardingJobResponse, DeleteInstanceOnboardingJobError, Credentials | HttpClient.HttpClient>;
export type DescribeCampaignError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the specific campaign.
 */
export declare const describeCampaign: API.OperationMethod<DescribeCampaignRequest, DescribeCampaignResponse, DescribeCampaignError, Credentials | HttpClient.HttpClient>;
export type GetCampaignStateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get state of a campaign for the specified Amazon Connect account.
 */
export declare const getCampaignState: API.OperationMethod<GetCampaignStateRequest, GetCampaignStateResponse, GetCampaignStateError, Credentials | HttpClient.HttpClient>;
export type GetCampaignStateBatchError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get state of campaigns for the specified Amazon Connect account.
 */
export declare const getCampaignStateBatch: API.OperationMethod<GetCampaignStateBatchRequest, GetCampaignStateBatchResponse, GetCampaignStateBatchError, Credentials | HttpClient.HttpClient>;
export type GetConnectInstanceConfigError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Get the specific Connect instance config.
 */
export declare const getConnectInstanceConfig: API.OperationMethod<GetConnectInstanceConfigRequest, GetConnectInstanceConfigResponse, GetConnectInstanceConfigError, Credentials | HttpClient.HttpClient>;
export type GetInstanceOnboardingJobStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Get the specific instance onboarding job status.
 */
export declare const getInstanceOnboardingJobStatus: API.OperationMethod<GetInstanceOnboardingJobStatusRequest, GetInstanceOnboardingJobStatusResponse, GetInstanceOnboardingJobStatusError, Credentials | HttpClient.HttpClient>;
export type ListCampaignsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Provides summary information about the campaigns under the specified Amazon Connect account.
 */
export declare const listCampaigns: API.PaginatedOperationMethod<ListCampaignsRequest, ListCampaignsResponse, ListCampaignsError, Credentials | HttpClient.HttpClient, CampaignSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PauseCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Pauses a campaign for the specified Amazon Connect account.
 */
export declare const pauseCampaign: API.OperationMethod<PauseCampaignRequest, PauseCampaignResponse, PauseCampaignError, Credentials | HttpClient.HttpClient>;
export type PutDialRequestBatchError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates dials requests for the specified campaign Amazon Connect account. This API is idempotent.
 */
export declare const putDialRequestBatch: API.OperationMethod<PutDialRequestBatchRequest, PutDialRequestBatchResponse, PutDialRequestBatchError, Credentials | HttpClient.HttpClient>;
export type ResumeCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a campaign for the specified Amazon Connect account.
 */
export declare const resumeCampaign: API.OperationMethod<ResumeCampaignRequest, ResumeCampaignResponse, ResumeCampaignError, Credentials | HttpClient.HttpClient>;
export type StartCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a campaign for the specified Amazon Connect account.
 */
export declare const startCampaign: API.OperationMethod<StartCampaignRequest, StartCampaignResponse, StartCampaignError, Credentials | HttpClient.HttpClient>;
export type StartInstanceOnboardingJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Onboard the specific Amazon Connect instance to Connect Campaigns.
 */
export declare const startInstanceOnboardingJob: API.OperationMethod<StartInstanceOnboardingJobRequest, StartInstanceOnboardingJobResponse, StartInstanceOnboardingJobError, Credentials | HttpClient.HttpClient>;
export type StopCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a campaign for the specified Amazon Connect account.
 */
export declare const stopCampaign: API.OperationMethod<StopCampaignRequest, StopCampaignResponse, StopCampaignError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tag a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Untag a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignDialerConfigError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the dialer config of a campaign. This API is idempotent.
 */
export declare const updateCampaignDialerConfig: API.OperationMethod<UpdateCampaignDialerConfigRequest, UpdateCampaignDialerConfigResponse, UpdateCampaignDialerConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignNameError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the name of a campaign. This API is idempotent.
 */
export declare const updateCampaignName: API.OperationMethod<UpdateCampaignNameRequest, UpdateCampaignNameResponse, UpdateCampaignNameError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignOutboundCallConfigError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the outbound call config of a campaign. This API is idempotent.
 */
export declare const updateCampaignOutboundCallConfig: API.OperationMethod<UpdateCampaignOutboundCallConfigRequest, UpdateCampaignOutboundCallConfigResponse, UpdateCampaignOutboundCallConfigError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=connectcampaigns.d.ts.map