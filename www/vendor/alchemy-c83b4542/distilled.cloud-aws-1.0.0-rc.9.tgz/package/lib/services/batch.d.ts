import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ClientException_base: S.Class<ClientException, S.TaggedStruct<"ClientException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClientException extends /*@__PURE__*/ ClientException_base {
}
declare const ComputeEnvironmentBeingModified_base: S.Class<ComputeEnvironmentBeingModified, S.TaggedStruct<"ComputeEnvironmentBeingModified", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ComputeEnvironmentBeingModified extends /*@__PURE__*/ ComputeEnvironmentBeingModified_base {
}
declare const ComputeEnvironmentInUse_base: S.Class<ComputeEnvironmentInUse, S.TaggedStruct<"ComputeEnvironmentInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ComputeEnvironmentInUse extends /*@__PURE__*/ ComputeEnvironmentInUse_base {
}
declare const ComputeEnvironmentNotFound_base: S.Class<ComputeEnvironmentNotFound, S.TaggedStruct<"ComputeEnvironmentNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ComputeEnvironmentNotFound extends /*@__PURE__*/ ComputeEnvironmentNotFound_base {
}
declare const ComputeEnvironmentNotValid_base: S.Class<ComputeEnvironmentNotValid, S.TaggedStruct<"ComputeEnvironmentNotValid", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ComputeEnvironmentNotValid extends /*@__PURE__*/ ComputeEnvironmentNotValid_base {
}
declare const JobQueueAlreadyExists_base: S.Class<JobQueueAlreadyExists, S.TaggedStruct<"JobQueueAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class JobQueueAlreadyExists extends /*@__PURE__*/ JobQueueAlreadyExists_base {
}
declare const JobQueueBeingModified_base: S.Class<JobQueueBeingModified, S.TaggedStruct<"JobQueueBeingModified", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class JobQueueBeingModified extends /*@__PURE__*/ JobQueueBeingModified_base {
}
declare const JobQueueNotFound_base: S.Class<JobQueueNotFound, S.TaggedStruct<"JobQueueNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class JobQueueNotFound extends /*@__PURE__*/ JobQueueNotFound_base {
}
declare const ServerException_base: S.Class<ServerException, S.TaggedStruct<"ServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServerException extends /*@__PURE__*/ ServerException_base {
}
export interface CancelJobRequest {
    jobId?: string;
    reason?: string;
}
export declare const CancelJobRequest: S.Schema<CancelJobRequest>;
export interface CancelJobResponse {
}
export declare const CancelJobResponse: S.Schema<CancelJobResponse>;
export type CEType = "MANAGED" | "UNMANAGED" | (string & {});
export declare const CEType: any;
export type CEState = "ENABLED" | "DISABLED" | (string & {});
export declare const CEState: any;
export type CRType = "EC2" | "SPOT" | "FARGATE" | "FARGATE_SPOT" | "ECS_MANAGED_INSTANCES" | (string & {});
export declare const CRType: any;
export type CRAllocationStrategy = "BEST_FIT" | "BEST_FIT_PROGRESSIVE" | "BEST_FIT_PROGRESSIVE_ORDERED" | "SPOT_CAPACITY_OPTIMIZED" | "SPOT_PRICE_CAPACITY_OPTIMIZED" | "SPOT_CAPACITY_OPTIMIZED_PRIORITIZED" | (string & {});
export declare const CRAllocationStrategy: any;
export type StringList = string[];
export declare const StringList: any;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export type UserdataType = "EKS_BOOTSTRAP_SH" | "EKS_NODEADM" | (string & {});
export declare const UserdataType: any;
export interface LaunchTemplateSpecificationOverride {
    launchTemplateId?: string;
    launchTemplateName?: string;
    version?: string;
    targetInstanceTypes?: string[];
    userdataType?: UserdataType;
}
export declare const LaunchTemplateSpecificationOverride: S.Schema<LaunchTemplateSpecificationOverride>;
export type LaunchTemplateSpecificationOverrideList = LaunchTemplateSpecificationOverride[];
export declare const LaunchTemplateSpecificationOverrideList: any;
export interface LaunchTemplateSpecification {
    launchTemplateId?: string;
    launchTemplateName?: string;
    version?: string;
    overrides?: LaunchTemplateSpecificationOverride[];
    userdataType?: UserdataType;
}
export declare const LaunchTemplateSpecification: S.Schema<LaunchTemplateSpecification>;
export type ImageType = string;
export type ImageIdOverride = string;
export type KubernetesVersion = string;
export interface Ec2Configuration {
    imageType?: string;
    imageIdOverride?: string;
    batchImageStatus?: string;
    imageKubernetesVersion?: string;
}
export declare const Ec2Configuration: S.Schema<Ec2Configuration>;
export type Ec2ConfigurationList = Ec2Configuration[];
export declare const Ec2ConfigurationList: any;
export interface ComputeScalingPolicy {
    minScaleDownDelayMinutes?: number;
}
export declare const ComputeScalingPolicy: S.Schema<ComputeScalingPolicy>;
export interface ManagedInstancesNetworkConfiguration {
    subnets?: string[];
    securityGroups?: string[];
}
export declare const ManagedInstancesNetworkConfiguration: S.Schema<ManagedInstancesNetworkConfiguration>;
export interface InstanceRequirementsRequest {
    allowedInstanceTypes?: string[];
}
export declare const InstanceRequirementsRequest: S.Schema<InstanceRequirementsRequest>;
export interface ManagedInstancesStorageConfiguration {
    storageSizeGiB?: number;
}
export declare const ManagedInstancesStorageConfiguration: S.Schema<ManagedInstancesStorageConfiguration>;
export interface CapacityReservationRequest {
    reservationGroupArn?: string;
    reservationPreference?: string;
}
export declare const CapacityReservationRequest: S.Schema<CapacityReservationRequest>;
export interface ManagedInstancesLocalStorageConfiguration {
    useLocalStorage?: boolean;
}
export declare const ManagedInstancesLocalStorageConfiguration: S.Schema<ManagedInstancesLocalStorageConfiguration>;
export interface InstanceLaunchTemplate {
    ec2InstanceProfileArn?: string;
    networkConfiguration?: ManagedInstancesNetworkConfiguration;
    instanceRequirements?: InstanceRequirementsRequest;
    capacityOptionType?: string;
    storageConfiguration?: ManagedInstancesStorageConfiguration;
    monitoring?: string;
    fipsEnabled?: boolean;
    capacityReservations?: CapacityReservationRequest;
    instanceMetadataTagsPropagation?: boolean;
    localStorageConfiguration?: ManagedInstancesLocalStorageConfiguration;
}
export declare const InstanceLaunchTemplate: S.Schema<InstanceLaunchTemplate>;
export interface InfrastructureOptimization {
    scaleInAfter?: number;
}
export declare const InfrastructureOptimization: S.Schema<InfrastructureOptimization>;
export interface ManagedInstancesProvider {
    propagateTags?: string;
    infrastructureRoleArn?: string;
    instanceLaunchTemplate?: InstanceLaunchTemplate;
    infrastructureOptimization?: InfrastructureOptimization;
}
export declare const ManagedInstancesProvider: S.Schema<ManagedInstancesProvider>;
export type TagKey = string;
export type TagValue = string;
export type TagrisTagsMap = {
    [key: string]: string | undefined;
};
export declare const TagrisTagsMap: any;
export interface ComputeResource {
    type?: CRType;
    allocationStrategy?: CRAllocationStrategy;
    minvCpus?: number;
    maxvCpus?: number;
    desiredvCpus?: number;
    instanceTypes?: string[];
    imageId?: string;
    subnets?: string[];
    securityGroupIds?: string[];
    ec2KeyPair?: string;
    instanceRole?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    placementGroup?: string;
    bidPercentage?: number;
    spotIamFleetRole?: string;
    launchTemplate?: LaunchTemplateSpecification;
    ec2Configuration?: Ec2Configuration[];
    scalingPolicy?: ComputeScalingPolicy;
    managedInstancesProvider?: ManagedInstancesProvider;
    capacityTags?: {
        [key: string]: string | undefined;
    };
}
export declare const ComputeResource: S.Schema<ComputeResource>;
export interface EksConfiguration {
    eksClusterArn?: string;
    kubernetesNamespace?: string;
}
export declare const EksConfiguration: S.Schema<EksConfiguration>;
export type ContainerInsights = "ENABLED" | "ENHANCED" | "DISABLED" | (string & {});
export declare const ContainerInsights: any;
export interface EcsSettings {
    containerInsights?: ContainerInsights;
}
export declare const EcsSettings: S.Schema<EcsSettings>;
export interface CreateComputeEnvironmentRequest {
    computeEnvironmentName?: string;
    type?: CEType;
    state?: CEState;
    unmanagedvCpus?: number;
    computeResources?: ComputeResource;
    serviceRole?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    eksConfiguration?: EksConfiguration;
    context?: string;
    ecsSettings?: EcsSettings;
}
export declare const CreateComputeEnvironmentRequest: S.Schema<CreateComputeEnvironmentRequest>;
export interface CreateComputeEnvironmentResponse {
    computeEnvironmentName?: string;
    computeEnvironmentArn?: string;
}
export declare const CreateComputeEnvironmentResponse: S.Schema<CreateComputeEnvironmentResponse>;
export interface CreateConsumableResourceRequest {
    consumableResourceName?: string;
    totalQuantity?: number;
    resourceType?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateConsumableResourceRequest: S.Schema<CreateConsumableResourceRequest>;
export interface CreateConsumableResourceResponse {
    consumableResourceName: string;
    consumableResourceArn: string;
}
export declare const CreateConsumableResourceResponse: S.Schema<CreateConsumableResourceResponse>;
export type JQState = "ENABLED" | "DISABLED" | (string & {});
export declare const JQState: any;
export interface ComputeEnvironmentOrder {
    order?: number;
    computeEnvironment?: string;
}
export declare const ComputeEnvironmentOrder: S.Schema<ComputeEnvironmentOrder>;
export type ComputeEnvironmentOrders = ComputeEnvironmentOrder[];
export declare const ComputeEnvironmentOrders: any;
export interface ServiceEnvironmentOrder {
    order?: number;
    serviceEnvironment?: string;
}
export declare const ServiceEnvironmentOrder: S.Schema<ServiceEnvironmentOrder>;
export type ServiceEnvironmentOrders = ServiceEnvironmentOrder[];
export declare const ServiceEnvironmentOrders: any;
export type JobQueueType = "EKS" | "ECS" | "ECS_FARGATE" | "SAGEMAKER_TRAINING" | "ECS_MANAGED_INSTANCES" | (string & {});
export declare const JobQueueType: any;
export type JobStateTimeLimitActionsState = "RUNNABLE" | (string & {});
export declare const JobStateTimeLimitActionsState: any;
export type JobStateTimeLimitActionsAction = "CANCEL" | "TERMINATE" | (string & {});
export declare const JobStateTimeLimitActionsAction: any;
export interface JobStateTimeLimitAction {
    reason?: string;
    state?: JobStateTimeLimitActionsState;
    maxTimeSeconds?: number;
    action?: JobStateTimeLimitActionsAction;
}
export declare const JobStateTimeLimitAction: S.Schema<JobStateTimeLimitAction>;
export type JobStateTimeLimitActions = JobStateTimeLimitAction[];
export declare const JobStateTimeLimitActions: any;
export interface CreateJobQueueRequest {
    jobQueueName?: string;
    state?: JQState;
    schedulingPolicyArn?: string;
    priority?: number;
    computeEnvironmentOrder?: ComputeEnvironmentOrder[];
    serviceEnvironmentOrder?: ServiceEnvironmentOrder[];
    jobQueueType?: JobQueueType;
    tags?: {
        [key: string]: string | undefined;
    };
    jobStateTimeLimitActions?: JobStateTimeLimitAction[];
}
export declare const CreateJobQueueRequest: S.Schema<CreateJobQueueRequest>;
export interface CreateJobQueueResponse {
    jobQueueName: string;
    jobQueueArn: string;
}
export declare const CreateJobQueueResponse: S.Schema<CreateJobQueueResponse>;
export interface QuotaShareCapacityLimit {
    maxCapacity?: number;
    capacityUnit?: string;
}
export declare const QuotaShareCapacityLimit: S.Schema<QuotaShareCapacityLimit>;
export type QuotaShareCapacityLimits = QuotaShareCapacityLimit[];
export declare const QuotaShareCapacityLimits: any;
export type QuotaShareResourceSharingStrategy = "RESERVE" | "LEND" | "LEND_AND_BORROW" | (string & {});
export declare const QuotaShareResourceSharingStrategy: any;
export interface QuotaShareResourceSharingConfiguration {
    strategy?: QuotaShareResourceSharingStrategy;
    borrowLimit?: number;
}
export declare const QuotaShareResourceSharingConfiguration: S.Schema<QuotaShareResourceSharingConfiguration>;
export type QuotaShareInSharePreemptionState = "ENABLED" | "DISABLED" | (string & {});
export declare const QuotaShareInSharePreemptionState: any;
export interface QuotaSharePreemptionConfiguration {
    inSharePreemption?: QuotaShareInSharePreemptionState;
}
export declare const QuotaSharePreemptionConfiguration: S.Schema<QuotaSharePreemptionConfiguration>;
export type QuotaShareState = "ENABLED" | "DISABLED" | (string & {});
export declare const QuotaShareState: any;
export interface CreateQuotaShareRequest {
    quotaShareName?: string;
    jobQueue?: string;
    capacityLimits?: QuotaShareCapacityLimit[];
    resourceSharingConfiguration?: QuotaShareResourceSharingConfiguration;
    preemptionConfiguration?: QuotaSharePreemptionConfiguration;
    state?: QuotaShareState;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateQuotaShareRequest: S.Schema<CreateQuotaShareRequest>;
export interface CreateQuotaShareResponse {
    quotaShareName?: string;
    quotaShareArn?: string;
}
export declare const CreateQuotaShareResponse: S.Schema<CreateQuotaShareResponse>;
export type QuotaShareIdleResourceAssignmentStrategy = "FIFO" | (string & {});
export declare const QuotaShareIdleResourceAssignmentStrategy: any;
export interface QuotaSharePolicy {
    idleResourceAssignmentStrategy?: QuotaShareIdleResourceAssignmentStrategy;
}
export declare const QuotaSharePolicy: S.Schema<QuotaSharePolicy>;
export interface ShareAttributes {
    shareIdentifier?: string;
    weightFactor?: number;
}
export declare const ShareAttributes: S.Schema<ShareAttributes>;
export type ShareAttributesList = ShareAttributes[];
export declare const ShareAttributesList: any;
export interface FairsharePolicy {
    shareDecaySeconds?: number;
    computeReservation?: number;
    shareDistribution?: ShareAttributes[];
}
export declare const FairsharePolicy: S.Schema<FairsharePolicy>;
export interface CreateSchedulingPolicyRequest {
    name?: string;
    quotaSharePolicy?: QuotaSharePolicy;
    fairsharePolicy?: FairsharePolicy;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateSchedulingPolicyRequest: S.Schema<CreateSchedulingPolicyRequest>;
export interface CreateSchedulingPolicyResponse {
    name: string;
    arn: string;
}
export declare const CreateSchedulingPolicyResponse: S.Schema<CreateSchedulingPolicyResponse>;
export type ServiceEnvironmentType = "SAGEMAKER_TRAINING" | (string & {});
export declare const ServiceEnvironmentType: any;
export type ServiceEnvironmentState = "ENABLED" | "DISABLED" | (string & {});
export declare const ServiceEnvironmentState: any;
export interface CapacityLimit {
    maxCapacity?: number;
    capacityUnit?: string;
}
export declare const CapacityLimit: S.Schema<CapacityLimit>;
export type CapacityLimits = CapacityLimit[];
export declare const CapacityLimits: any;
export interface CreateServiceEnvironmentRequest {
    serviceEnvironmentName?: string;
    serviceEnvironmentType?: ServiceEnvironmentType;
    state?: ServiceEnvironmentState;
    capacityLimits?: CapacityLimit[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateServiceEnvironmentRequest: S.Schema<CreateServiceEnvironmentRequest>;
export interface CreateServiceEnvironmentResponse {
    serviceEnvironmentName: string;
    serviceEnvironmentArn: string;
}
export declare const CreateServiceEnvironmentResponse: S.Schema<CreateServiceEnvironmentResponse>;
export interface DeleteComputeEnvironmentRequest {
    computeEnvironment?: string;
}
export declare const DeleteComputeEnvironmentRequest: S.Schema<DeleteComputeEnvironmentRequest>;
export interface DeleteComputeEnvironmentResponse {
}
export declare const DeleteComputeEnvironmentResponse: S.Schema<DeleteComputeEnvironmentResponse>;
export interface DeleteConsumableResourceRequest {
    consumableResource?: string;
}
export declare const DeleteConsumableResourceRequest: S.Schema<DeleteConsumableResourceRequest>;
export interface DeleteConsumableResourceResponse {
}
export declare const DeleteConsumableResourceResponse: S.Schema<DeleteConsumableResourceResponse>;
export interface DeleteJobQueueRequest {
    jobQueue?: string;
}
export declare const DeleteJobQueueRequest: S.Schema<DeleteJobQueueRequest>;
export interface DeleteJobQueueResponse {
}
export declare const DeleteJobQueueResponse: S.Schema<DeleteJobQueueResponse>;
export interface DeleteQuotaShareRequest {
    quotaShareArn?: string;
}
export declare const DeleteQuotaShareRequest: S.Schema<DeleteQuotaShareRequest>;
export interface DeleteQuotaShareResponse {
}
export declare const DeleteQuotaShareResponse: S.Schema<DeleteQuotaShareResponse>;
export interface DeleteSchedulingPolicyRequest {
    arn?: string;
}
export declare const DeleteSchedulingPolicyRequest: S.Schema<DeleteSchedulingPolicyRequest>;
export interface DeleteSchedulingPolicyResponse {
}
export declare const DeleteSchedulingPolicyResponse: S.Schema<DeleteSchedulingPolicyResponse>;
export interface DeleteServiceEnvironmentRequest {
    serviceEnvironment?: string;
}
export declare const DeleteServiceEnvironmentRequest: S.Schema<DeleteServiceEnvironmentRequest>;
export interface DeleteServiceEnvironmentResponse {
}
export declare const DeleteServiceEnvironmentResponse: S.Schema<DeleteServiceEnvironmentResponse>;
export interface DeregisterJobDefinitionRequest {
    jobDefinition?: string;
}
export declare const DeregisterJobDefinitionRequest: S.Schema<DeregisterJobDefinitionRequest>;
export interface DeregisterJobDefinitionResponse {
}
export declare const DeregisterJobDefinitionResponse: S.Schema<DeregisterJobDefinitionResponse>;
export interface DescribeComputeEnvironmentsRequest {
    computeEnvironments?: string[];
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeComputeEnvironmentsRequest: S.Schema<DescribeComputeEnvironmentsRequest>;
export type CEStatus = "CREATING" | "UPDATING" | "DELETING" | "DELETED" | "VALID" | "INVALID" | (string & {});
export declare const CEStatus: any;
export type JobExecutionTimeoutMinutes = number;
export interface UpdatePolicy {
    terminateJobsOnUpdate?: boolean;
    jobExecutionTimeoutMinutes?: number;
}
export declare const UpdatePolicy: S.Schema<UpdatePolicy>;
export type OrchestrationType = "ECS" | "EKS" | (string & {});
export declare const OrchestrationType: any;
export interface ComputeEnvironmentDetail {
    computeEnvironmentName?: string;
    computeEnvironmentArn?: string;
    unmanagedvCpus?: number;
    ecsClusterArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    type?: CEType;
    state?: CEState;
    status?: CEStatus;
    statusReason?: string;
    computeResources?: ComputeResource;
    serviceRole?: string;
    updatePolicy?: UpdatePolicy;
    eksConfiguration?: EksConfiguration;
    containerOrchestrationType?: OrchestrationType;
    uuid?: string;
    context?: string;
    ecsSettings?: EcsSettings;
}
export declare const ComputeEnvironmentDetail: S.Schema<ComputeEnvironmentDetail>;
export type ComputeEnvironmentDetailList = ComputeEnvironmentDetail[];
export declare const ComputeEnvironmentDetailList: any;
export interface DescribeComputeEnvironmentsResponse {
    computeEnvironments?: (ComputeEnvironmentDetail & {
        computeEnvironmentName: string;
        computeEnvironmentArn: string;
        computeResources: ComputeResource & {
            type: CRType;
            maxvCpus: number;
            ec2Configuration: (Ec2Configuration & {
                imageType: ImageType;
            })[];
            managedInstancesProvider: ManagedInstancesProvider & {
                infrastructureRoleArn: string;
                instanceLaunchTemplate: InstanceLaunchTemplate & {
                    ec2InstanceProfileArn: string;
                    networkConfiguration: ManagedInstancesNetworkConfiguration & {
                        subnets: StringList;
                        securityGroups: StringList;
                    };
                };
            };
        };
        eksConfiguration: EksConfiguration & {
            eksClusterArn: string;
            kubernetesNamespace: string;
        };
    })[];
    nextToken?: string;
}
export declare const DescribeComputeEnvironmentsResponse: S.Schema<DescribeComputeEnvironmentsResponse>;
export interface DescribeConsumableResourceRequest {
    consumableResource?: string;
}
export declare const DescribeConsumableResourceRequest: S.Schema<DescribeConsumableResourceRequest>;
export interface DescribeConsumableResourceResponse {
    consumableResourceName: string;
    consumableResourceArn: string;
    totalQuantity?: number;
    inUseQuantity?: number;
    availableQuantity?: number;
    resourceType?: string;
    createdAt?: number;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DescribeConsumableResourceResponse: S.Schema<DescribeConsumableResourceResponse>;
export interface DescribeJobDefinitionsRequest {
    jobDefinitions?: string[];
    maxResults?: number;
    jobDefinitionName?: string;
    status?: string;
    nextToken?: string;
}
export declare const DescribeJobDefinitionsRequest: S.Schema<DescribeJobDefinitionsRequest>;
export type ParametersMap = {
    [key: string]: string | undefined;
};
export declare const ParametersMap: any;
export type RetryAction = "RETRY" | "EXIT" | (string & {});
export declare const RetryAction: any;
export interface EvaluateOnExit {
    onStatusReason?: string;
    onReason?: string;
    onExitCode?: string;
    action?: RetryAction;
}
export declare const EvaluateOnExit: S.Schema<EvaluateOnExit>;
export type EvaluateOnExitList = EvaluateOnExit[];
export declare const EvaluateOnExitList: any;
export interface RetryStrategy {
    attempts?: number;
    evaluateOnExit?: EvaluateOnExit[];
}
export declare const RetryStrategy: S.Schema<RetryStrategy>;
export interface Host {
    sourcePath?: string;
}
export declare const Host: S.Schema<Host>;
export type EFSTransitEncryption = "ENABLED" | "DISABLED" | (string & {});
export declare const EFSTransitEncryption: any;
export type EFSAuthorizationConfigIAM = "ENABLED" | "DISABLED" | (string & {});
export declare const EFSAuthorizationConfigIAM: any;
export interface EFSAuthorizationConfig {
    accessPointId?: string;
    iam?: EFSAuthorizationConfigIAM;
}
export declare const EFSAuthorizationConfig: S.Schema<EFSAuthorizationConfig>;
export interface EFSVolumeConfiguration {
    fileSystemId?: string;
    rootDirectory?: string;
    transitEncryption?: EFSTransitEncryption;
    transitEncryptionPort?: number;
    authorizationConfig?: EFSAuthorizationConfig;
}
export declare const EFSVolumeConfiguration: S.Schema<EFSVolumeConfiguration>;
export interface S3FilesVolumeConfiguration {
    fileSystemArn?: string;
    rootDirectory?: string;
    transitEncryptionPort?: number;
    accessPointArn?: string;
}
export declare const S3FilesVolumeConfiguration: S.Schema<S3FilesVolumeConfiguration>;
export interface Volume {
    host?: Host;
    name?: string;
    efsVolumeConfiguration?: EFSVolumeConfiguration;
    s3filesVolumeConfiguration?: S3FilesVolumeConfiguration;
}
export declare const Volume: S.Schema<Volume>;
export type Volumes = Volume[];
export declare const Volumes: any;
export interface KeyValuePair {
    name?: string;
    value?: string;
}
export declare const KeyValuePair: S.Schema<KeyValuePair>;
export type EnvironmentVariables = KeyValuePair[];
export declare const EnvironmentVariables: any;
export interface MountPoint {
    containerPath?: string;
    readOnly?: boolean;
    sourceVolume?: string;
}
export declare const MountPoint: S.Schema<MountPoint>;
export type MountPoints = MountPoint[];
export declare const MountPoints: any;
export interface Ulimit {
    hardLimit?: number;
    name?: string;
    softLimit?: number;
}
export declare const Ulimit: S.Schema<Ulimit>;
export type Ulimits = Ulimit[];
export declare const Ulimits: any;
export type ResourceType = "GPU" | "VCPU" | "MEMORY" | (string & {});
export declare const ResourceType: any;
export interface ResourceRequirement {
    value?: string;
    type?: ResourceType;
}
export declare const ResourceRequirement: S.Schema<ResourceRequirement>;
export type ResourceRequirements = ResourceRequirement[];
export declare const ResourceRequirements: any;
export type DeviceCgroupPermission = "READ" | "WRITE" | "MKNOD" | (string & {});
export declare const DeviceCgroupPermission: any;
export type DeviceCgroupPermissions = DeviceCgroupPermission[];
export declare const DeviceCgroupPermissions: any;
export interface Device {
    hostPath?: string;
    containerPath?: string;
    permissions?: DeviceCgroupPermission[];
}
export declare const Device: S.Schema<Device>;
export type DevicesList = Device[];
export declare const DevicesList: any;
export interface Tmpfs {
    containerPath?: string;
    size?: number;
    mountOptions?: string[];
}
export declare const Tmpfs: S.Schema<Tmpfs>;
export type TmpfsList = Tmpfs[];
export declare const TmpfsList: any;
export interface LinuxParameters {
    devices?: Device[];
    initProcessEnabled?: boolean;
    sharedMemorySize?: number;
    tmpfs?: Tmpfs[];
    maxSwap?: number;
    swappiness?: number;
}
export declare const LinuxParameters: S.Schema<LinuxParameters>;
export type LogDriver = "json-file" | "syslog" | "journald" | "gelf" | "fluentd" | "awslogs" | "splunk" | "awsfirelens" | (string & {});
export declare const LogDriver: any;
export type LogConfigurationOptionsMap = {
    [key: string]: string | undefined;
};
export declare const LogConfigurationOptionsMap: any;
export interface Secret {
    name?: string;
    valueFrom?: string;
}
export declare const Secret: S.Schema<Secret>;
export type SecretList = Secret[];
export declare const SecretList: any;
export interface LogConfiguration {
    logDriver?: LogDriver;
    options?: {
        [key: string]: string | undefined;
    };
    secretOptions?: Secret[];
}
export declare const LogConfiguration: S.Schema<LogConfiguration>;
export type AssignPublicIp = "ENABLED" | "DISABLED" | (string & {});
export declare const AssignPublicIp: any;
export interface NetworkConfiguration {
    assignPublicIp?: AssignPublicIp;
}
export declare const NetworkConfiguration: S.Schema<NetworkConfiguration>;
export interface FargatePlatformConfiguration {
    platformVersion?: string;
}
export declare const FargatePlatformConfiguration: S.Schema<FargatePlatformConfiguration>;
export interface EphemeralStorage {
    sizeInGiB?: number;
}
export declare const EphemeralStorage: S.Schema<EphemeralStorage>;
export interface RuntimePlatform {
    operatingSystemFamily?: string;
    cpuArchitecture?: string;
}
export declare const RuntimePlatform: S.Schema<RuntimePlatform>;
export interface RepositoryCredentials {
    credentialsParameter?: string;
}
export declare const RepositoryCredentials: S.Schema<RepositoryCredentials>;
export interface ContainerProperties {
    image?: string;
    vcpus?: number;
    memory?: number;
    command?: string[];
    jobRoleArn?: string;
    executionRoleArn?: string;
    volumes?: Volume[];
    environment?: KeyValuePair[];
    mountPoints?: MountPoint[];
    readonlyRootFilesystem?: boolean;
    privileged?: boolean;
    ulimits?: Ulimit[];
    user?: string;
    instanceType?: string;
    resourceRequirements?: ResourceRequirement[];
    linuxParameters?: LinuxParameters;
    logConfiguration?: LogConfiguration;
    secrets?: Secret[];
    networkConfiguration?: NetworkConfiguration;
    fargatePlatformConfiguration?: FargatePlatformConfiguration;
    enableExecuteCommand?: boolean;
    ephemeralStorage?: EphemeralStorage;
    runtimePlatform?: RuntimePlatform;
    repositoryCredentials?: RepositoryCredentials;
}
export declare const ContainerProperties: S.Schema<ContainerProperties>;
export interface JobTimeout {
    attemptDurationSeconds?: number;
}
export declare const JobTimeout: S.Schema<JobTimeout>;
export interface TaskContainerDependency {
    containerName?: string;
    condition?: string;
}
export declare const TaskContainerDependency: S.Schema<TaskContainerDependency>;
export type TaskContainerDependencyList = TaskContainerDependency[];
export declare const TaskContainerDependencyList: any;
export type FirelensConfigurationType = "fluentd" | "fluentbit" | (string & {});
export declare const FirelensConfigurationType: any;
export type FirelensConfigurationOptionsMap = {
    [key: string]: string | undefined;
};
export declare const FirelensConfigurationOptionsMap: any;
export interface FirelensConfiguration {
    type?: FirelensConfigurationType;
    options?: {
        [key: string]: string | undefined;
    };
}
export declare const FirelensConfiguration: S.Schema<FirelensConfiguration>;
export interface TaskContainerProperties {
    command?: string[];
    dependsOn?: TaskContainerDependency[];
    environment?: KeyValuePair[];
    essential?: boolean;
    firelensConfiguration?: FirelensConfiguration;
    image?: string;
    linuxParameters?: LinuxParameters;
    logConfiguration?: LogConfiguration;
    mountPoints?: MountPoint[];
    name?: string;
    privileged?: boolean;
    readonlyRootFilesystem?: boolean;
    repositoryCredentials?: RepositoryCredentials;
    resourceRequirements?: ResourceRequirement[];
    secrets?: Secret[];
    ulimits?: Ulimit[];
    user?: string;
    startTimeout?: number;
    stopTimeout?: number;
}
export declare const TaskContainerProperties: S.Schema<TaskContainerProperties>;
export type ListTaskContainerProperties = TaskContainerProperties[];
export declare const ListTaskContainerProperties: any;
export interface EcsTaskProperties {
    containers?: TaskContainerProperties[];
    ephemeralStorage?: EphemeralStorage;
    executionRoleArn?: string;
    platformVersion?: string;
    ipcMode?: string;
    taskRoleArn?: string;
    pidMode?: string;
    networkConfiguration?: NetworkConfiguration;
    runtimePlatform?: RuntimePlatform;
    volumes?: Volume[];
    enableExecuteCommand?: boolean;
    networkMode?: string;
}
export declare const EcsTaskProperties: S.Schema<EcsTaskProperties>;
export type ListEcsTaskProperties = EcsTaskProperties[];
export declare const ListEcsTaskProperties: any;
export interface EcsProperties {
    taskProperties?: EcsTaskProperties[];
}
export declare const EcsProperties: S.Schema<EcsProperties>;
export interface ImagePullSecret {
    name?: string;
}
export declare const ImagePullSecret: S.Schema<ImagePullSecret>;
export type ImagePullSecrets = ImagePullSecret[];
export declare const ImagePullSecrets: any;
export interface EksContainerEnvironmentVariable {
    name?: string;
    value?: string;
}
export declare const EksContainerEnvironmentVariable: S.Schema<EksContainerEnvironmentVariable>;
export type EksContainerEnvironmentVariables = EksContainerEnvironmentVariable[];
export declare const EksContainerEnvironmentVariables: any;
export type Quantity = string;
export type EksLimits = {
    [key: string]: string | undefined;
};
export declare const EksLimits: any;
export type EksRequests = {
    [key: string]: string | undefined;
};
export declare const EksRequests: any;
export interface EksContainerResourceRequirements {
    limits?: {
        [key: string]: string | undefined;
    };
    requests?: {
        [key: string]: string | undefined;
    };
}
export declare const EksContainerResourceRequirements: S.Schema<EksContainerResourceRequirements>;
export interface EksContainerVolumeMount {
    name?: string;
    mountPath?: string;
    subPath?: string;
    readOnly?: boolean;
}
export declare const EksContainerVolumeMount: S.Schema<EksContainerVolumeMount>;
export type EksContainerVolumeMounts = EksContainerVolumeMount[];
export declare const EksContainerVolumeMounts: any;
export interface EksContainerSecurityContext {
    runAsUser?: number;
    runAsGroup?: number;
    privileged?: boolean;
    allowPrivilegeEscalation?: boolean;
    readOnlyRootFilesystem?: boolean;
    runAsNonRoot?: boolean;
}
export declare const EksContainerSecurityContext: S.Schema<EksContainerSecurityContext>;
export interface EksContainer {
    name?: string;
    image?: string;
    imagePullPolicy?: string;
    command?: string[];
    args?: string[];
    env?: EksContainerEnvironmentVariable[];
    resources?: EksContainerResourceRequirements;
    volumeMounts?: EksContainerVolumeMount[];
    securityContext?: EksContainerSecurityContext;
}
export declare const EksContainer: S.Schema<EksContainer>;
export type EksContainers = EksContainer[];
export declare const EksContainers: any;
export interface EksHostPath {
    path?: string;
}
export declare const EksHostPath: S.Schema<EksHostPath>;
export interface EksEmptyDir {
    medium?: string;
    sizeLimit?: string;
}
export declare const EksEmptyDir: S.Schema<EksEmptyDir>;
export interface EksSecret {
    secretName?: string;
    optional?: boolean;
}
export declare const EksSecret: S.Schema<EksSecret>;
export interface EksPersistentVolumeClaim {
    claimName?: string;
    readOnly?: boolean;
}
export declare const EksPersistentVolumeClaim: S.Schema<EksPersistentVolumeClaim>;
export interface EksVolume {
    name?: string;
    hostPath?: EksHostPath;
    emptyDir?: EksEmptyDir;
    secret?: EksSecret;
    persistentVolumeClaim?: EksPersistentVolumeClaim;
}
export declare const EksVolume: S.Schema<EksVolume>;
export type EksVolumes = EksVolume[];
export declare const EksVolumes: any;
export type EksLabelsMap = {
    [key: string]: string | undefined;
};
export declare const EksLabelsMap: any;
export type EksAnnotationsMap = {
    [key: string]: string | undefined;
};
export declare const EksAnnotationsMap: any;
export interface EksMetadata {
    labels?: {
        [key: string]: string | undefined;
    };
    annotations?: {
        [key: string]: string | undefined;
    };
    namespace?: string;
}
export declare const EksMetadata: S.Schema<EksMetadata>;
export interface EksPodProperties {
    serviceAccountName?: string;
    hostNetwork?: boolean;
    dnsPolicy?: string;
    imagePullSecrets?: ImagePullSecret[];
    containers?: EksContainer[];
    initContainers?: EksContainer[];
    volumes?: EksVolume[];
    metadata?: EksMetadata;
    shareProcessNamespace?: boolean;
}
export declare const EksPodProperties: S.Schema<EksPodProperties>;
export interface EksProperties {
    podProperties?: EksPodProperties;
}
export declare const EksProperties: S.Schema<EksProperties>;
export interface ConsumableResourceRequirement {
    consumableResource?: string;
    quantity?: number;
}
export declare const ConsumableResourceRequirement: S.Schema<ConsumableResourceRequirement>;
export type ConsumableResourceList = ConsumableResourceRequirement[];
export declare const ConsumableResourceList: any;
export interface ConsumableResourceProperties {
    consumableResourceList?: ConsumableResourceRequirement[];
}
export declare const ConsumableResourceProperties: S.Schema<ConsumableResourceProperties>;
export interface NodeRangeProperty {
    targetNodes?: string;
    container?: ContainerProperties;
    instanceTypes?: string[];
    ecsProperties?: EcsProperties;
    eksProperties?: EksProperties;
    consumableResourceProperties?: ConsumableResourceProperties;
}
export declare const NodeRangeProperty: S.Schema<NodeRangeProperty>;
export type NodeRangeProperties = NodeRangeProperty[];
export declare const NodeRangeProperties: any;
export interface NodeProperties {
    numNodes?: number;
    mainNode?: number;
    nodeRangeProperties?: NodeRangeProperty[];
}
export declare const NodeProperties: S.Schema<NodeProperties>;
export type PlatformCapability = "EC2" | "FARGATE" | "MANAGED_INSTANCES" | (string & {});
export declare const PlatformCapability: any;
export type PlatformCapabilityList = PlatformCapability[];
export declare const PlatformCapabilityList: any;
export interface JobDefinition {
    jobDefinitionName?: string;
    jobDefinitionArn?: string;
    revision?: number;
    status?: string;
    type?: string;
    schedulingPriority?: number;
    parameters?: {
        [key: string]: string | undefined;
    };
    retryStrategy?: RetryStrategy;
    containerProperties?: ContainerProperties;
    timeout?: JobTimeout;
    nodeProperties?: NodeProperties;
    tags?: {
        [key: string]: string | undefined;
    };
    propagateTags?: boolean;
    platformCapabilities?: PlatformCapability[];
    ecsProperties?: EcsProperties;
    eksProperties?: EksProperties;
    containerOrchestrationType?: OrchestrationType;
    consumableResourceProperties?: ConsumableResourceProperties;
}
export declare const JobDefinition: S.Schema<JobDefinition>;
export type JobDefinitionList = JobDefinition[];
export declare const JobDefinitionList: any;
export interface DescribeJobDefinitionsResponse {
    jobDefinitions?: (JobDefinition & {
        jobDefinitionName: string;
        jobDefinitionArn: string;
        revision: number;
        type: string;
        retryStrategy: RetryStrategy & {
            evaluateOnExit: (EvaluateOnExit & {
                action: RetryAction;
            })[];
        };
        containerProperties: ContainerProperties & {
            volumes: (Volume & {
                efsVolumeConfiguration: EFSVolumeConfiguration & {
                    fileSystemId: string;
                };
                s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                    fileSystemArn: string;
                };
            })[];
            ulimits: (Ulimit & {
                hardLimit: number;
                name: string;
                softLimit: number;
            })[];
            resourceRequirements: (ResourceRequirement & {
                value: string;
                type: ResourceType;
            })[];
            linuxParameters: LinuxParameters & {
                devices: (Device & {
                    hostPath: string;
                })[];
                tmpfs: (Tmpfs & {
                    containerPath: string;
                    size: number;
                })[];
            };
            logConfiguration: LogConfiguration & {
                logDriver: LogDriver;
                secretOptions: (Secret & {
                    name: string;
                    valueFrom: string;
                })[];
            };
            secrets: (Secret & {
                name: string;
                valueFrom: string;
            })[];
            ephemeralStorage: EphemeralStorage & {
                sizeInGiB: number;
            };
            repositoryCredentials: RepositoryCredentials & {
                credentialsParameter: string;
            };
        };
        nodeProperties: NodeProperties & {
            numNodes: number;
            mainNode: number;
            nodeRangeProperties: (NodeRangeProperty & {
                targetNodes: string;
                container: ContainerProperties & {
                    volumes: (Volume & {
                        efsVolumeConfiguration: EFSVolumeConfiguration & {
                            fileSystemId: string;
                        };
                        s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                            fileSystemArn: string;
                        };
                    })[];
                    ulimits: (Ulimit & {
                        hardLimit: number;
                        name: string;
                        softLimit: number;
                    })[];
                    resourceRequirements: (ResourceRequirement & {
                        value: string;
                        type: ResourceType;
                    })[];
                    linuxParameters: LinuxParameters & {
                        devices: (Device & {
                            hostPath: string;
                        })[];
                        tmpfs: (Tmpfs & {
                            containerPath: string;
                            size: number;
                        })[];
                    };
                    logConfiguration: LogConfiguration & {
                        logDriver: LogDriver;
                        secretOptions: (Secret & {
                            name: string;
                            valueFrom: string;
                        })[];
                    };
                    secrets: (Secret & {
                        name: string;
                        valueFrom: string;
                    })[];
                    ephemeralStorage: EphemeralStorage & {
                        sizeInGiB: number;
                    };
                    repositoryCredentials: RepositoryCredentials & {
                        credentialsParameter: string;
                    };
                };
                ecsProperties: EcsProperties & {
                    taskProperties: (EcsTaskProperties & {
                        containers: (TaskContainerProperties & {
                            image: string;
                            firelensConfiguration: FirelensConfiguration & {
                                type: FirelensConfigurationType;
                            };
                            linuxParameters: LinuxParameters & {
                                devices: (Device & {
                                    hostPath: string;
                                })[];
                                tmpfs: (Tmpfs & {
                                    containerPath: string;
                                    size: number;
                                })[];
                            };
                            logConfiguration: LogConfiguration & {
                                logDriver: LogDriver;
                                secretOptions: (Secret & {
                                    name: string;
                                    valueFrom: string;
                                })[];
                            };
                            repositoryCredentials: RepositoryCredentials & {
                                credentialsParameter: string;
                            };
                            resourceRequirements: (ResourceRequirement & {
                                value: string;
                                type: ResourceType;
                            })[];
                            secrets: (Secret & {
                                name: string;
                                valueFrom: string;
                            })[];
                            ulimits: (Ulimit & {
                                hardLimit: number;
                                name: string;
                                softLimit: number;
                            })[];
                        })[];
                        ephemeralStorage: EphemeralStorage & {
                            sizeInGiB: number;
                        };
                        volumes: (Volume & {
                            efsVolumeConfiguration: EFSVolumeConfiguration & {
                                fileSystemId: string;
                            };
                            s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                                fileSystemArn: string;
                            };
                        })[];
                    })[];
                };
                eksProperties: EksProperties & {
                    podProperties: EksPodProperties & {
                        imagePullSecrets: (ImagePullSecret & {
                            name: string;
                        })[];
                        containers: (EksContainer & {
                            image: string;
                            env: (EksContainerEnvironmentVariable & {
                                name: string;
                            })[];
                        })[];
                        initContainers: (EksContainer & {
                            image: string;
                            env: (EksContainerEnvironmentVariable & {
                                name: string;
                            })[];
                        })[];
                        volumes: (EksVolume & {
                            name: string;
                            secret: EksSecret & {
                                secretName: string;
                            };
                            persistentVolumeClaim: EksPersistentVolumeClaim & {
                                claimName: string;
                            };
                        })[];
                    };
                };
            })[];
        };
        ecsProperties: EcsProperties & {
            taskProperties: (EcsTaskProperties & {
                containers: (TaskContainerProperties & {
                    image: string;
                    firelensConfiguration: FirelensConfiguration & {
                        type: FirelensConfigurationType;
                    };
                    linuxParameters: LinuxParameters & {
                        devices: (Device & {
                            hostPath: string;
                        })[];
                        tmpfs: (Tmpfs & {
                            containerPath: string;
                            size: number;
                        })[];
                    };
                    logConfiguration: LogConfiguration & {
                        logDriver: LogDriver;
                        secretOptions: (Secret & {
                            name: string;
                            valueFrom: string;
                        })[];
                    };
                    repositoryCredentials: RepositoryCredentials & {
                        credentialsParameter: string;
                    };
                    resourceRequirements: (ResourceRequirement & {
                        value: string;
                        type: ResourceType;
                    })[];
                    secrets: (Secret & {
                        name: string;
                        valueFrom: string;
                    })[];
                    ulimits: (Ulimit & {
                        hardLimit: number;
                        name: string;
                        softLimit: number;
                    })[];
                })[];
                ephemeralStorage: EphemeralStorage & {
                    sizeInGiB: number;
                };
                volumes: (Volume & {
                    efsVolumeConfiguration: EFSVolumeConfiguration & {
                        fileSystemId: string;
                    };
                    s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                        fileSystemArn: string;
                    };
                })[];
            })[];
        };
        eksProperties: EksProperties & {
            podProperties: EksPodProperties & {
                imagePullSecrets: (ImagePullSecret & {
                    name: string;
                })[];
                containers: (EksContainer & {
                    image: string;
                    env: (EksContainerEnvironmentVariable & {
                        name: string;
                    })[];
                })[];
                initContainers: (EksContainer & {
                    image: string;
                    env: (EksContainerEnvironmentVariable & {
                        name: string;
                    })[];
                })[];
                volumes: (EksVolume & {
                    name: string;
                    secret: EksSecret & {
                        secretName: string;
                    };
                    persistentVolumeClaim: EksPersistentVolumeClaim & {
                        claimName: string;
                    };
                })[];
            };
        };
    })[];
    nextToken?: string;
}
export declare const DescribeJobDefinitionsResponse: S.Schema<DescribeJobDefinitionsResponse>;
export interface DescribeJobQueuesRequest {
    jobQueues?: string[];
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeJobQueuesRequest: S.Schema<DescribeJobQueuesRequest>;
export type JQStatus = "CREATING" | "UPDATING" | "DELETING" | "DELETED" | "VALID" | "INVALID" | (string & {});
export declare const JQStatus: any;
export interface JobQueueDetail {
    jobQueueName?: string;
    jobQueueArn?: string;
    state?: JQState;
    schedulingPolicyArn?: string;
    status?: JQStatus;
    statusReason?: string;
    priority?: number;
    computeEnvironmentOrder?: ComputeEnvironmentOrder[];
    serviceEnvironmentOrder?: ServiceEnvironmentOrder[];
    jobQueueType?: JobQueueType;
    tags?: {
        [key: string]: string | undefined;
    };
    jobStateTimeLimitActions?: JobStateTimeLimitAction[];
}
export declare const JobQueueDetail: S.Schema<JobQueueDetail>;
export type JobQueueDetailList = JobQueueDetail[];
export declare const JobQueueDetailList: any;
export interface DescribeJobQueuesResponse {
    jobQueues?: (JobQueueDetail & {
        jobQueueName: string;
        jobQueueArn: string;
        state: JQState;
        priority: number;
        computeEnvironmentOrder: (ComputeEnvironmentOrder & {
            order: number;
            computeEnvironment: string;
        })[];
        serviceEnvironmentOrder: (ServiceEnvironmentOrder & {
            order: number;
            serviceEnvironment: string;
        })[];
        jobStateTimeLimitActions: (JobStateTimeLimitAction & {
            reason: string;
            state: JobStateTimeLimitActionsState;
            maxTimeSeconds: number;
            action: JobStateTimeLimitActionsAction;
        })[];
    })[];
    nextToken?: string;
}
export declare const DescribeJobQueuesResponse: S.Schema<DescribeJobQueuesResponse>;
export interface DescribeJobsRequest {
    jobs?: string[];
}
export declare const DescribeJobsRequest: S.Schema<DescribeJobsRequest>;
export type JobStatus = "SUBMITTED" | "PENDING" | "RUNNABLE" | "STARTING" | "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const JobStatus: any;
export interface NetworkInterface {
    attachmentId?: string;
    ipv6Address?: string;
    privateIpv4Address?: string;
}
export declare const NetworkInterface: S.Schema<NetworkInterface>;
export type NetworkInterfaceList = NetworkInterface[];
export declare const NetworkInterfaceList: any;
export interface AttemptContainerDetail {
    containerInstanceArn?: string;
    taskArn?: string;
    exitCode?: number;
    reason?: string;
    logStreamName?: string;
    networkInterfaces?: NetworkInterface[];
}
export declare const AttemptContainerDetail: S.Schema<AttemptContainerDetail>;
export interface AttemptTaskContainerDetails {
    exitCode?: number;
    name?: string;
    reason?: string;
    logStreamName?: string;
    networkInterfaces?: NetworkInterface[];
}
export declare const AttemptTaskContainerDetails: S.Schema<AttemptTaskContainerDetails>;
export type ListAttemptTaskContainerDetails = AttemptTaskContainerDetails[];
export declare const ListAttemptTaskContainerDetails: any;
export interface AttemptEcsTaskDetails {
    containerInstanceArn?: string;
    taskArn?: string;
    containers?: AttemptTaskContainerDetails[];
}
export declare const AttemptEcsTaskDetails: S.Schema<AttemptEcsTaskDetails>;
export type ListAttemptEcsTaskDetails = AttemptEcsTaskDetails[];
export declare const ListAttemptEcsTaskDetails: any;
export interface AttemptDetail {
    container?: AttemptContainerDetail;
    startedAt?: number;
    stoppedAt?: number;
    statusReason?: string;
    taskProperties?: AttemptEcsTaskDetails[];
}
export declare const AttemptDetail: S.Schema<AttemptDetail>;
export type AttemptDetails = AttemptDetail[];
export declare const AttemptDetails: any;
export type ArrayJobDependency = "N_TO_N" | "SEQUENTIAL" | (string & {});
export declare const ArrayJobDependency: any;
export interface JobDependency {
    jobId?: string;
    type?: ArrayJobDependency;
}
export declare const JobDependency: S.Schema<JobDependency>;
export type JobDependencyList = JobDependency[];
export declare const JobDependencyList: any;
export interface ContainerDetail {
    image?: string;
    vcpus?: number;
    memory?: number;
    command?: string[];
    jobRoleArn?: string;
    executionRoleArn?: string;
    volumes?: Volume[];
    environment?: KeyValuePair[];
    mountPoints?: MountPoint[];
    readonlyRootFilesystem?: boolean;
    ulimits?: Ulimit[];
    privileged?: boolean;
    user?: string;
    exitCode?: number;
    reason?: string;
    containerInstanceArn?: string;
    taskArn?: string;
    logStreamName?: string;
    instanceType?: string;
    networkInterfaces?: NetworkInterface[];
    resourceRequirements?: ResourceRequirement[];
    linuxParameters?: LinuxParameters;
    logConfiguration?: LogConfiguration;
    secrets?: Secret[];
    networkConfiguration?: NetworkConfiguration;
    fargatePlatformConfiguration?: FargatePlatformConfiguration;
    ephemeralStorage?: EphemeralStorage;
    runtimePlatform?: RuntimePlatform;
    repositoryCredentials?: RepositoryCredentials;
    enableExecuteCommand?: boolean;
}
export declare const ContainerDetail: S.Schema<ContainerDetail>;
export interface NodeDetails {
    nodeIndex?: number;
    isMainNode?: boolean;
}
export declare const NodeDetails: S.Schema<NodeDetails>;
export type ArrayJobStatusSummary = {
    [key: string]: number | undefined;
};
export declare const ArrayJobStatusSummary: any;
export interface ArrayPropertiesDetail {
    statusSummary?: {
        [key: string]: number | undefined;
    };
    statusSummaryLastUpdatedAt?: number;
    size?: number;
    index?: number;
}
export declare const ArrayPropertiesDetail: S.Schema<ArrayPropertiesDetail>;
export interface EksContainerDetail {
    name?: string;
    image?: string;
    imagePullPolicy?: string;
    command?: string[];
    args?: string[];
    env?: EksContainerEnvironmentVariable[];
    resources?: EksContainerResourceRequirements;
    exitCode?: number;
    reason?: string;
    volumeMounts?: EksContainerVolumeMount[];
    securityContext?: EksContainerSecurityContext;
}
export declare const EksContainerDetail: S.Schema<EksContainerDetail>;
export type EksContainerDetails = EksContainerDetail[];
export declare const EksContainerDetails: any;
export interface EksPodPropertiesDetail {
    serviceAccountName?: string;
    hostNetwork?: boolean;
    dnsPolicy?: string;
    imagePullSecrets?: ImagePullSecret[];
    containers?: EksContainerDetail[];
    initContainers?: EksContainerDetail[];
    volumes?: EksVolume[];
    podName?: string;
    nodeName?: string;
    metadata?: EksMetadata;
    shareProcessNamespace?: boolean;
}
export declare const EksPodPropertiesDetail: S.Schema<EksPodPropertiesDetail>;
export interface EksPropertiesDetail {
    podProperties?: EksPodPropertiesDetail;
}
export declare const EksPropertiesDetail: S.Schema<EksPropertiesDetail>;
export interface EksAttemptContainerDetail {
    name?: string;
    containerID?: string;
    exitCode?: number;
    reason?: string;
}
export declare const EksAttemptContainerDetail: S.Schema<EksAttemptContainerDetail>;
export type EksAttemptContainerDetails = EksAttemptContainerDetail[];
export declare const EksAttemptContainerDetails: any;
export interface EksAttemptDetail {
    containers?: EksAttemptContainerDetail[];
    initContainers?: EksAttemptContainerDetail[];
    eksClusterArn?: string;
    podName?: string;
    podNamespace?: string;
    nodeName?: string;
    startedAt?: number;
    stoppedAt?: number;
    statusReason?: string;
}
export declare const EksAttemptDetail: S.Schema<EksAttemptDetail>;
export type EksAttemptDetails = EksAttemptDetail[];
export declare const EksAttemptDetails: any;
export interface TaskContainerDetails {
    command?: string[];
    dependsOn?: TaskContainerDependency[];
    environment?: KeyValuePair[];
    essential?: boolean;
    firelensConfiguration?: FirelensConfiguration;
    image?: string;
    linuxParameters?: LinuxParameters;
    logConfiguration?: LogConfiguration;
    mountPoints?: MountPoint[];
    name?: string;
    privileged?: boolean;
    readonlyRootFilesystem?: boolean;
    repositoryCredentials?: RepositoryCredentials;
    resourceRequirements?: ResourceRequirement[];
    secrets?: Secret[];
    ulimits?: Ulimit[];
    user?: string;
    startTimeout?: number;
    stopTimeout?: number;
    exitCode?: number;
    reason?: string;
    logStreamName?: string;
    networkInterfaces?: NetworkInterface[];
}
export declare const TaskContainerDetails: S.Schema<TaskContainerDetails>;
export type ListTaskContainerDetails = TaskContainerDetails[];
export declare const ListTaskContainerDetails: any;
export interface EcsTaskDetails {
    containers?: TaskContainerDetails[];
    containerInstanceArn?: string;
    taskArn?: string;
    ephemeralStorage?: EphemeralStorage;
    executionRoleArn?: string;
    platformVersion?: string;
    ipcMode?: string;
    taskRoleArn?: string;
    pidMode?: string;
    networkConfiguration?: NetworkConfiguration;
    runtimePlatform?: RuntimePlatform;
    volumes?: Volume[];
    enableExecuteCommand?: boolean;
    networkMode?: string;
}
export declare const EcsTaskDetails: S.Schema<EcsTaskDetails>;
export type ListEcsTaskDetails = EcsTaskDetails[];
export declare const ListEcsTaskDetails: any;
export interface EcsPropertiesDetail {
    taskProperties?: EcsTaskDetails[];
}
export declare const EcsPropertiesDetail: S.Schema<EcsPropertiesDetail>;
export interface JobDetail {
    jobArn?: string;
    jobName?: string;
    jobId?: string;
    jobQueue?: string;
    status?: JobStatus;
    shareIdentifier?: string;
    schedulingPriority?: number;
    attempts?: AttemptDetail[];
    statusReason?: string;
    createdAt?: number;
    retryStrategy?: RetryStrategy;
    startedAt?: number;
    stoppedAt?: number;
    dependsOn?: JobDependency[];
    jobDefinition?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
    container?: ContainerDetail;
    nodeDetails?: NodeDetails;
    nodeProperties?: NodeProperties;
    arrayProperties?: ArrayPropertiesDetail;
    timeout?: JobTimeout;
    tags?: {
        [key: string]: string | undefined;
    };
    propagateTags?: boolean;
    platformCapabilities?: PlatformCapability[];
    eksProperties?: EksPropertiesDetail;
    eksAttempts?: EksAttemptDetail[];
    ecsProperties?: EcsPropertiesDetail;
    isCancelled?: boolean;
    isTerminated?: boolean;
    consumableResourceProperties?: ConsumableResourceProperties;
}
export declare const JobDetail: S.Schema<JobDetail>;
export type JobDetailList = JobDetail[];
export declare const JobDetailList: any;
export interface DescribeJobsResponse {
    jobs?: (JobDetail & {
        jobName: string;
        jobId: string;
        jobQueue: string;
        status: JobStatus;
        startedAt: number;
        jobDefinition: string;
        retryStrategy: RetryStrategy & {
            evaluateOnExit: (EvaluateOnExit & {
                action: RetryAction;
            })[];
        };
        container: ContainerDetail & {
            volumes: (Volume & {
                efsVolumeConfiguration: EFSVolumeConfiguration & {
                    fileSystemId: string;
                };
                s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                    fileSystemArn: string;
                };
            })[];
            ulimits: (Ulimit & {
                hardLimit: number;
                name: string;
                softLimit: number;
            })[];
            resourceRequirements: (ResourceRequirement & {
                value: string;
                type: ResourceType;
            })[];
            linuxParameters: LinuxParameters & {
                devices: (Device & {
                    hostPath: string;
                })[];
                tmpfs: (Tmpfs & {
                    containerPath: string;
                    size: number;
                })[];
            };
            logConfiguration: LogConfiguration & {
                logDriver: LogDriver;
                secretOptions: (Secret & {
                    name: string;
                    valueFrom: string;
                })[];
            };
            secrets: (Secret & {
                name: string;
                valueFrom: string;
            })[];
            ephemeralStorage: EphemeralStorage & {
                sizeInGiB: number;
            };
            repositoryCredentials: RepositoryCredentials & {
                credentialsParameter: string;
            };
        };
        nodeProperties: NodeProperties & {
            numNodes: number;
            mainNode: number;
            nodeRangeProperties: (NodeRangeProperty & {
                targetNodes: string;
                container: ContainerProperties & {
                    volumes: (Volume & {
                        efsVolumeConfiguration: EFSVolumeConfiguration & {
                            fileSystemId: string;
                        };
                        s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                            fileSystemArn: string;
                        };
                    })[];
                    ulimits: (Ulimit & {
                        hardLimit: number;
                        name: string;
                        softLimit: number;
                    })[];
                    resourceRequirements: (ResourceRequirement & {
                        value: string;
                        type: ResourceType;
                    })[];
                    linuxParameters: LinuxParameters & {
                        devices: (Device & {
                            hostPath: string;
                        })[];
                        tmpfs: (Tmpfs & {
                            containerPath: string;
                            size: number;
                        })[];
                    };
                    logConfiguration: LogConfiguration & {
                        logDriver: LogDriver;
                        secretOptions: (Secret & {
                            name: string;
                            valueFrom: string;
                        })[];
                    };
                    secrets: (Secret & {
                        name: string;
                        valueFrom: string;
                    })[];
                    ephemeralStorage: EphemeralStorage & {
                        sizeInGiB: number;
                    };
                    repositoryCredentials: RepositoryCredentials & {
                        credentialsParameter: string;
                    };
                };
                ecsProperties: EcsProperties & {
                    taskProperties: (EcsTaskProperties & {
                        containers: (TaskContainerProperties & {
                            image: string;
                            firelensConfiguration: FirelensConfiguration & {
                                type: FirelensConfigurationType;
                            };
                            linuxParameters: LinuxParameters & {
                                devices: (Device & {
                                    hostPath: string;
                                })[];
                                tmpfs: (Tmpfs & {
                                    containerPath: string;
                                    size: number;
                                })[];
                            };
                            logConfiguration: LogConfiguration & {
                                logDriver: LogDriver;
                                secretOptions: (Secret & {
                                    name: string;
                                    valueFrom: string;
                                })[];
                            };
                            repositoryCredentials: RepositoryCredentials & {
                                credentialsParameter: string;
                            };
                            resourceRequirements: (ResourceRequirement & {
                                value: string;
                                type: ResourceType;
                            })[];
                            secrets: (Secret & {
                                name: string;
                                valueFrom: string;
                            })[];
                            ulimits: (Ulimit & {
                                hardLimit: number;
                                name: string;
                                softLimit: number;
                            })[];
                        })[];
                        ephemeralStorage: EphemeralStorage & {
                            sizeInGiB: number;
                        };
                        volumes: (Volume & {
                            efsVolumeConfiguration: EFSVolumeConfiguration & {
                                fileSystemId: string;
                            };
                            s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                                fileSystemArn: string;
                            };
                        })[];
                    })[];
                };
                eksProperties: EksProperties & {
                    podProperties: EksPodProperties & {
                        imagePullSecrets: (ImagePullSecret & {
                            name: string;
                        })[];
                        containers: (EksContainer & {
                            image: string;
                            env: (EksContainerEnvironmentVariable & {
                                name: string;
                            })[];
                        })[];
                        initContainers: (EksContainer & {
                            image: string;
                            env: (EksContainerEnvironmentVariable & {
                                name: string;
                            })[];
                        })[];
                        volumes: (EksVolume & {
                            name: string;
                            secret: EksSecret & {
                                secretName: string;
                            };
                            persistentVolumeClaim: EksPersistentVolumeClaim & {
                                claimName: string;
                            };
                        })[];
                    };
                };
            })[];
        };
        eksProperties: EksPropertiesDetail & {
            podProperties: EksPodPropertiesDetail & {
                imagePullSecrets: (ImagePullSecret & {
                    name: string;
                })[];
                containers: (EksContainerDetail & {
                    env: (EksContainerEnvironmentVariable & {
                        name: string;
                    })[];
                })[];
                initContainers: (EksContainerDetail & {
                    env: (EksContainerEnvironmentVariable & {
                        name: string;
                    })[];
                })[];
                volumes: (EksVolume & {
                    name: string;
                    secret: EksSecret & {
                        secretName: string;
                    };
                    persistentVolumeClaim: EksPersistentVolumeClaim & {
                        claimName: string;
                    };
                })[];
            };
        };
        ecsProperties: EcsPropertiesDetail & {
            taskProperties: (EcsTaskDetails & {
                containers: (TaskContainerDetails & {
                    firelensConfiguration: FirelensConfiguration & {
                        type: FirelensConfigurationType;
                    };
                    linuxParameters: LinuxParameters & {
                        devices: (Device & {
                            hostPath: string;
                        })[];
                        tmpfs: (Tmpfs & {
                            containerPath: string;
                            size: number;
                        })[];
                    };
                    logConfiguration: LogConfiguration & {
                        logDriver: LogDriver;
                        secretOptions: (Secret & {
                            name: string;
                            valueFrom: string;
                        })[];
                    };
                    repositoryCredentials: RepositoryCredentials & {
                        credentialsParameter: string;
                    };
                    resourceRequirements: (ResourceRequirement & {
                        value: string;
                        type: ResourceType;
                    })[];
                    secrets: (Secret & {
                        name: string;
                        valueFrom: string;
                    })[];
                    ulimits: (Ulimit & {
                        hardLimit: number;
                        name: string;
                        softLimit: number;
                    })[];
                })[];
                ephemeralStorage: EphemeralStorage & {
                    sizeInGiB: number;
                };
                volumes: (Volume & {
                    efsVolumeConfiguration: EFSVolumeConfiguration & {
                        fileSystemId: string;
                    };
                    s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                        fileSystemArn: string;
                    };
                })[];
            })[];
        };
    })[];
}
export declare const DescribeJobsResponse: S.Schema<DescribeJobsResponse>;
export interface DescribeQuotaShareRequest {
    quotaShareArn?: string;
}
export declare const DescribeQuotaShareRequest: S.Schema<DescribeQuotaShareRequest>;
export type QuotaShareStatus = "CREATING" | "VALID" | "INVALID" | "UPDATING" | "DELETING" | (string & {});
export declare const QuotaShareStatus: any;
export interface DescribeQuotaShareResponse {
    quotaShareName?: string;
    quotaShareArn?: string;
    jobQueueArn?: string;
    capacityLimits?: (QuotaShareCapacityLimit & {
        maxCapacity: number;
        capacityUnit: string;
    })[];
    resourceSharingConfiguration?: QuotaShareResourceSharingConfiguration & {
        strategy: QuotaShareResourceSharingStrategy;
    };
    preemptionConfiguration?: QuotaSharePreemptionConfiguration & {
        inSharePreemption: QuotaShareInSharePreemptionState;
    };
    state?: QuotaShareState;
    status?: QuotaShareStatus;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DescribeQuotaShareResponse: S.Schema<DescribeQuotaShareResponse>;
export interface DescribeSchedulingPoliciesRequest {
    arns?: string[];
}
export declare const DescribeSchedulingPoliciesRequest: S.Schema<DescribeSchedulingPoliciesRequest>;
export interface SchedulingPolicyDetail {
    name?: string;
    arn?: string;
    quotaSharePolicy?: QuotaSharePolicy;
    fairsharePolicy?: FairsharePolicy;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const SchedulingPolicyDetail: S.Schema<SchedulingPolicyDetail>;
export type SchedulingPolicyDetailList = SchedulingPolicyDetail[];
export declare const SchedulingPolicyDetailList: any;
export interface DescribeSchedulingPoliciesResponse {
    schedulingPolicies?: (SchedulingPolicyDetail & {
        name: string;
        arn: string;
        quotaSharePolicy: QuotaSharePolicy & {
            idleResourceAssignmentStrategy: QuotaShareIdleResourceAssignmentStrategy;
        };
        fairsharePolicy: FairsharePolicy & {
            shareDistribution: (ShareAttributes & {
                shareIdentifier: string;
            })[];
        };
    })[];
}
export declare const DescribeSchedulingPoliciesResponse: S.Schema<DescribeSchedulingPoliciesResponse>;
export interface DescribeServiceEnvironmentsRequest {
    serviceEnvironments?: string[];
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeServiceEnvironmentsRequest: S.Schema<DescribeServiceEnvironmentsRequest>;
export type ServiceEnvironmentStatus = "CREATING" | "UPDATING" | "DELETING" | "DELETED" | "VALID" | "INVALID" | (string & {});
export declare const ServiceEnvironmentStatus: any;
export interface ServiceEnvironmentDetail {
    serviceEnvironmentName?: string;
    serviceEnvironmentArn?: string;
    serviceEnvironmentType?: ServiceEnvironmentType;
    state?: ServiceEnvironmentState;
    status?: ServiceEnvironmentStatus;
    capacityLimits?: CapacityLimit[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ServiceEnvironmentDetail: S.Schema<ServiceEnvironmentDetail>;
export type ServiceEnvironmentDetailList = ServiceEnvironmentDetail[];
export declare const ServiceEnvironmentDetailList: any;
export interface DescribeServiceEnvironmentsResponse {
    serviceEnvironments?: (ServiceEnvironmentDetail & {
        serviceEnvironmentName: string;
        serviceEnvironmentArn: string;
        serviceEnvironmentType: ServiceEnvironmentType;
        capacityLimits: CapacityLimits;
    })[];
    nextToken?: string;
}
export declare const DescribeServiceEnvironmentsResponse: S.Schema<DescribeServiceEnvironmentsResponse>;
export interface DescribeServiceJobRequest {
    jobId?: string;
}
export declare const DescribeServiceJobRequest: S.Schema<DescribeServiceJobRequest>;
export type ServiceResourceIdName = "TrainingJobArn" | (string & {});
export declare const ServiceResourceIdName: any;
export interface ServiceResourceId {
    name?: ServiceResourceIdName;
    value?: string;
}
export declare const ServiceResourceId: S.Schema<ServiceResourceId>;
export interface ServiceJobAttemptDetail {
    serviceResourceId?: ServiceResourceId;
    startedAt?: number;
    stoppedAt?: number;
    statusReason?: string;
}
export declare const ServiceJobAttemptDetail: S.Schema<ServiceJobAttemptDetail>;
export type ServiceJobAttemptDetails = ServiceJobAttemptDetail[];
export declare const ServiceJobAttemptDetails: any;
export interface ServiceJobCapacityUsageDetail {
    capacityUnit?: string;
    quantity?: number;
}
export declare const ServiceJobCapacityUsageDetail: S.Schema<ServiceJobCapacityUsageDetail>;
export type ServiceJobCapacityUsageDetailList = ServiceJobCapacityUsageDetail[];
export declare const ServiceJobCapacityUsageDetailList: any;
export interface LatestServiceJobAttempt {
    serviceResourceId?: ServiceResourceId;
}
export declare const LatestServiceJobAttempt: S.Schema<LatestServiceJobAttempt>;
export type ServiceJobRetryAction = "RETRY" | "EXIT" | (string & {});
export declare const ServiceJobRetryAction: any;
export interface ServiceJobEvaluateOnExit {
    action?: ServiceJobRetryAction;
    onStatusReason?: string;
}
export declare const ServiceJobEvaluateOnExit: S.Schema<ServiceJobEvaluateOnExit>;
export type ServiceJobEvaluateOnExitList = ServiceJobEvaluateOnExit[];
export declare const ServiceJobEvaluateOnExitList: any;
export interface ServiceJobRetryStrategy {
    attempts?: number;
    evaluateOnExit?: ServiceJobEvaluateOnExit[];
}
export declare const ServiceJobRetryStrategy: S.Schema<ServiceJobRetryStrategy>;
export type ServiceJobType = "SAGEMAKER_TRAINING" | (string & {});
export declare const ServiceJobType: any;
export interface ServiceJobPreemptionConfiguration {
    preemptionRetriesBeforeTermination?: number;
}
export declare const ServiceJobPreemptionConfiguration: S.Schema<ServiceJobPreemptionConfiguration>;
export interface ServiceJobPreemptedAttempt {
    serviceResourceId?: ServiceResourceId;
    startedAt?: number;
    stoppedAt?: number;
    statusReason?: string;
}
export declare const ServiceJobPreemptedAttempt: S.Schema<ServiceJobPreemptedAttempt>;
export type ServiceJobRecentPreemptedAttemptList = ServiceJobPreemptedAttempt[];
export declare const ServiceJobRecentPreemptedAttemptList: any;
export interface ServiceJobPreemptionSummary {
    preemptedAttemptCount?: number;
    recentPreemptedAttempts?: ServiceJobPreemptedAttempt[];
}
export declare const ServiceJobPreemptionSummary: S.Schema<ServiceJobPreemptionSummary>;
export type ServiceJobStatus = "SUBMITTED" | "PENDING" | "RUNNABLE" | "SCHEDULED" | "STARTING" | "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const ServiceJobStatus: any;
export interface ServiceJobTimeout {
    attemptDurationSeconds?: number;
}
export declare const ServiceJobTimeout: S.Schema<ServiceJobTimeout>;
export interface DescribeServiceJobResponse {
    attempts?: (ServiceJobAttemptDetail & {
        serviceResourceId: ServiceResourceId & {
            name: ServiceResourceIdName;
            value: string;
        };
    })[];
    capacityUsage?: ServiceJobCapacityUsageDetail[];
    createdAt?: number;
    isTerminated?: boolean;
    jobArn?: string;
    jobId: string;
    jobName: string;
    jobQueue: string;
    latestAttempt?: LatestServiceJobAttempt & {
        serviceResourceId: ServiceResourceId & {
            name: ServiceResourceIdName;
            value: string;
        };
    };
    retryStrategy?: ServiceJobRetryStrategy & {
        attempts: number;
    };
    scheduledAt?: number;
    schedulingPriority?: number;
    serviceRequestPayload?: string;
    serviceJobType: ServiceJobType;
    shareIdentifier?: string;
    quotaShareName?: string;
    preemptionConfiguration?: ServiceJobPreemptionConfiguration;
    preemptionSummary?: ServiceJobPreemptionSummary & {
        recentPreemptedAttempts: (ServiceJobPreemptedAttempt & {
            serviceResourceId: ServiceResourceId & {
                name: ServiceResourceIdName;
                value: string;
            };
        })[];
    };
    startedAt: number;
    status: ServiceJobStatus;
    statusReason?: string;
    stoppedAt?: number;
    tags?: {
        [key: string]: string | undefined;
    };
    timeoutConfig?: ServiceJobTimeout;
}
export declare const DescribeServiceJobResponse: S.Schema<DescribeServiceJobResponse>;
export interface GetJobQueueSnapshotRequest {
    jobQueue?: string;
}
export declare const GetJobQueueSnapshotRequest: S.Schema<GetJobQueueSnapshotRequest>;
export interface FrontOfQueueJobSummary {
    jobArn?: string;
    earliestTimeAtPosition?: number;
}
export declare const FrontOfQueueJobSummary: S.Schema<FrontOfQueueJobSummary>;
export type FrontOfQueueJobSummaryList = FrontOfQueueJobSummary[];
export declare const FrontOfQueueJobSummaryList: any;
export interface FrontOfQueueDetail {
    jobs?: FrontOfQueueJobSummary[];
    lastUpdatedAt?: number;
}
export declare const FrontOfQueueDetail: S.Schema<FrontOfQueueDetail>;
export interface FrontOfQuotaShareJobSummary {
    jobArn?: string;
    earliestTimeAtPosition?: number;
}
export declare const FrontOfQuotaShareJobSummary: S.Schema<FrontOfQuotaShareJobSummary>;
export type FrontOfQuotaShareJobSummaryList = FrontOfQuotaShareJobSummary[];
export declare const FrontOfQuotaShareJobSummaryList: any;
export type FrontOfQuotaSharesJobSummaryMap = {
    [key: string]: FrontOfQuotaShareJobSummary[] | undefined;
};
export declare const FrontOfQuotaSharesJobSummaryMap: any;
export interface FrontOfQuotaSharesDetail {
    quotaShares?: {
        [key: string]: FrontOfQuotaShareJobSummary[] | undefined;
    };
    lastUpdatedAt?: number;
}
export declare const FrontOfQuotaSharesDetail: S.Schema<FrontOfQuotaSharesDetail>;
export interface QueueSnapshotCapacityUsage {
    capacityUnit?: string;
    quantity?: number;
}
export declare const QueueSnapshotCapacityUsage: S.Schema<QueueSnapshotCapacityUsage>;
export type QueueSnapshotCapacityUsageList = QueueSnapshotCapacityUsage[];
export declare const QueueSnapshotCapacityUsageList: any;
export interface FairshareCapacityUsage {
    capacityUnit?: string;
    quantity?: number;
}
export declare const FairshareCapacityUsage: S.Schema<FairshareCapacityUsage>;
export type FairshareCapacityUsageList = FairshareCapacityUsage[];
export declare const FairshareCapacityUsageList: any;
export interface FairshareCapacityUtilization {
    shareIdentifier?: string;
    capacityUsage?: FairshareCapacityUsage[];
}
export declare const FairshareCapacityUtilization: S.Schema<FairshareCapacityUtilization>;
export type FairshareCapacityUtilizationList = FairshareCapacityUtilization[];
export declare const FairshareCapacityUtilizationList: any;
export interface FairshareUtilizationDetail {
    activeShareCount?: number;
    topCapacityUtilization?: FairshareCapacityUtilization[];
}
export declare const FairshareUtilizationDetail: S.Schema<FairshareUtilizationDetail>;
export interface QuotaShareCapacityUsage {
    capacityUnit?: string;
    quantity?: number;
}
export declare const QuotaShareCapacityUsage: S.Schema<QuotaShareCapacityUsage>;
export type QuotaShareCapacityUsageList = QuotaShareCapacityUsage[];
export declare const QuotaShareCapacityUsageList: any;
export interface QuotaShareCapacityUtilization {
    quotaShareName?: string;
    capacityUsage?: QuotaShareCapacityUsage[];
}
export declare const QuotaShareCapacityUtilization: S.Schema<QuotaShareCapacityUtilization>;
export type QuotaShareCapacityUtilizationList = QuotaShareCapacityUtilization[];
export declare const QuotaShareCapacityUtilizationList: any;
export interface QuotaShareUtilizationDetail {
    topCapacityUtilization?: QuotaShareCapacityUtilization[];
}
export declare const QuotaShareUtilizationDetail: S.Schema<QuotaShareUtilizationDetail>;
export interface QueueSnapshotUtilizationDetail {
    totalCapacityUsage?: QueueSnapshotCapacityUsage[];
    fairshareUtilization?: FairshareUtilizationDetail;
    quotaShareUtilization?: QuotaShareUtilizationDetail;
    lastUpdatedAt?: number;
}
export declare const QueueSnapshotUtilizationDetail: S.Schema<QueueSnapshotUtilizationDetail>;
export interface GetJobQueueSnapshotResponse {
    frontOfQueue?: FrontOfQueueDetail;
    frontOfQuotaShares?: FrontOfQuotaSharesDetail;
    queueUtilization?: QueueSnapshotUtilizationDetail;
}
export declare const GetJobQueueSnapshotResponse: S.Schema<GetJobQueueSnapshotResponse>;
export interface KeyValuesPair {
    name?: string;
    values?: string[];
}
export declare const KeyValuesPair: S.Schema<KeyValuesPair>;
export type ListConsumableResourcesFilterList = KeyValuesPair[];
export declare const ListConsumableResourcesFilterList: any;
export interface ListConsumableResourcesRequest {
    filters?: KeyValuesPair[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListConsumableResourcesRequest: S.Schema<ListConsumableResourcesRequest>;
export interface ConsumableResourceSummary {
    consumableResourceArn?: string;
    consumableResourceName?: string;
    totalQuantity?: number;
    inUseQuantity?: number;
    resourceType?: string;
}
export declare const ConsumableResourceSummary: S.Schema<ConsumableResourceSummary>;
export type ConsumableResourceSummaryList = ConsumableResourceSummary[];
export declare const ConsumableResourceSummaryList: any;
export interface ListConsumableResourcesResponse {
    consumableResources: (ConsumableResourceSummary & {
        consumableResourceArn: string;
        consumableResourceName: string;
    })[];
    nextToken?: string;
}
export declare const ListConsumableResourcesResponse: S.Schema<ListConsumableResourcesResponse>;
export type ListJobsFilterList = KeyValuesPair[];
export declare const ListJobsFilterList: any;
export interface ListJobsRequest {
    jobQueue?: string;
    arrayJobId?: string;
    multiNodeJobId?: string;
    jobStatus?: JobStatus;
    maxResults?: number;
    nextToken?: string;
    filters?: KeyValuesPair[];
}
export declare const ListJobsRequest: S.Schema<ListJobsRequest>;
export interface JobCapacityUsageSummary {
    capacityUnit?: string;
    quantity?: number;
}
export declare const JobCapacityUsageSummary: S.Schema<JobCapacityUsageSummary>;
export type JobCapacityUsageSummaryList = JobCapacityUsageSummary[];
export declare const JobCapacityUsageSummaryList: any;
export interface ContainerSummary {
    exitCode?: number;
    reason?: string;
}
export declare const ContainerSummary: S.Schema<ContainerSummary>;
export interface ArrayPropertiesSummary {
    size?: number;
    index?: number;
    statusSummary?: {
        [key: string]: number | undefined;
    };
    statusSummaryLastUpdatedAt?: number;
}
export declare const ArrayPropertiesSummary: S.Schema<ArrayPropertiesSummary>;
export interface NodePropertiesSummary {
    isMainNode?: boolean;
    numNodes?: number;
    nodeIndex?: number;
}
export declare const NodePropertiesSummary: S.Schema<NodePropertiesSummary>;
export interface JobSummary {
    jobArn?: string;
    jobId?: string;
    jobName?: string;
    capacityUsage?: JobCapacityUsageSummary[];
    createdAt?: number;
    scheduledAt?: number;
    shareIdentifier?: string;
    status?: JobStatus;
    statusReason?: string;
    startedAt?: number;
    stoppedAt?: number;
    container?: ContainerSummary;
    arrayProperties?: ArrayPropertiesSummary;
    nodeProperties?: NodePropertiesSummary;
    jobDefinition?: string;
}
export declare const JobSummary: S.Schema<JobSummary>;
export type JobSummaryList = JobSummary[];
export declare const JobSummaryList: any;
export interface ListJobsResponse {
    jobSummaryList: (JobSummary & {
        jobId: string;
        jobName: string;
    })[];
    nextToken?: string;
}
export declare const ListJobsResponse: S.Schema<ListJobsResponse>;
export type ListJobsByConsumableResourceFilterList = KeyValuesPair[];
export declare const ListJobsByConsumableResourceFilterList: any;
export interface ListJobsByConsumableResourceRequest {
    consumableResource?: string;
    filters?: KeyValuesPair[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListJobsByConsumableResourceRequest: S.Schema<ListJobsByConsumableResourceRequest>;
export interface ListJobsByConsumableResourceSummary {
    jobArn?: string;
    jobQueueArn?: string;
    jobName?: string;
    jobDefinitionArn?: string;
    shareIdentifier?: string;
    jobStatus?: string;
    quantity?: number;
    statusReason?: string;
    startedAt?: number;
    createdAt?: number;
    consumableResourceProperties?: ConsumableResourceProperties;
}
export declare const ListJobsByConsumableResourceSummary: S.Schema<ListJobsByConsumableResourceSummary>;
export type ListJobsByConsumableResourceSummaryList = ListJobsByConsumableResourceSummary[];
export declare const ListJobsByConsumableResourceSummaryList: any;
export interface ListJobsByConsumableResourceResponse {
    jobs: (ListJobsByConsumableResourceSummary & {
        jobArn: string;
        jobQueueArn: string;
        jobName: string;
        jobStatus: string;
        quantity: number;
        createdAt: number;
        consumableResourceProperties: ConsumableResourceProperties;
    })[];
    nextToken?: string;
}
export declare const ListJobsByConsumableResourceResponse: S.Schema<ListJobsByConsumableResourceResponse>;
export interface ListQuotaSharesRequest {
    jobQueue?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListQuotaSharesRequest: S.Schema<ListQuotaSharesRequest>;
export interface QuotaShareDetail {
    quotaShareName?: string;
    quotaShareArn?: string;
    jobQueueArn?: string;
    capacityLimits?: QuotaShareCapacityLimit[];
    resourceSharingConfiguration?: QuotaShareResourceSharingConfiguration;
    preemptionConfiguration?: QuotaSharePreemptionConfiguration;
    state?: QuotaShareState;
    status?: QuotaShareStatus;
}
export declare const QuotaShareDetail: S.Schema<QuotaShareDetail>;
export type QuotaShareList = QuotaShareDetail[];
export declare const QuotaShareList: any;
export interface ListQuotaSharesResponse {
    quotaShares?: (QuotaShareDetail & {
        capacityLimits: (QuotaShareCapacityLimit & {
            maxCapacity: number;
            capacityUnit: string;
        })[];
        resourceSharingConfiguration: QuotaShareResourceSharingConfiguration & {
            strategy: QuotaShareResourceSharingStrategy;
        };
        preemptionConfiguration: QuotaSharePreemptionConfiguration & {
            inSharePreemption: QuotaShareInSharePreemptionState;
        };
    })[];
    nextToken?: string;
}
export declare const ListQuotaSharesResponse: S.Schema<ListQuotaSharesResponse>;
export interface ListSchedulingPoliciesRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSchedulingPoliciesRequest: S.Schema<ListSchedulingPoliciesRequest>;
export interface SchedulingPolicyListingDetail {
    arn?: string;
}
export declare const SchedulingPolicyListingDetail: S.Schema<SchedulingPolicyListingDetail>;
export type SchedulingPolicyListingDetailList = SchedulingPolicyListingDetail[];
export declare const SchedulingPolicyListingDetailList: any;
export interface ListSchedulingPoliciesResponse {
    schedulingPolicies?: (SchedulingPolicyListingDetail & {
        arn: string;
    })[];
    nextToken?: string;
}
export declare const ListSchedulingPoliciesResponse: S.Schema<ListSchedulingPoliciesResponse>;
export interface ListServiceJobsRequest {
    jobQueue?: string;
    jobStatus?: ServiceJobStatus;
    maxResults?: number;
    nextToken?: string;
    filters?: KeyValuesPair[];
}
export declare const ListServiceJobsRequest: S.Schema<ListServiceJobsRequest>;
export interface ServiceJobCapacityUsageSummary {
    capacityUnit?: string;
    quantity?: number;
}
export declare const ServiceJobCapacityUsageSummary: S.Schema<ServiceJobCapacityUsageSummary>;
export type ServiceJobCapacityUsageSummaryList = ServiceJobCapacityUsageSummary[];
export declare const ServiceJobCapacityUsageSummaryList: any;
export interface ServiceJobSummary {
    latestAttempt?: LatestServiceJobAttempt;
    capacityUsage?: ServiceJobCapacityUsageSummary[];
    createdAt?: number;
    jobArn?: string;
    jobId?: string;
    jobName?: string;
    scheduledAt?: number;
    serviceJobType?: ServiceJobType;
    shareIdentifier?: string;
    quotaShareName?: string;
    status?: ServiceJobStatus;
    statusReason?: string;
    startedAt?: number;
    stoppedAt?: number;
}
export declare const ServiceJobSummary: S.Schema<ServiceJobSummary>;
export type ServiceJobSummaryList = ServiceJobSummary[];
export declare const ServiceJobSummaryList: any;
export interface ListServiceJobsResponse {
    jobSummaryList: (ServiceJobSummary & {
        jobId: string;
        jobName: string;
        serviceJobType: ServiceJobType;
        latestAttempt: LatestServiceJobAttempt & {
            serviceResourceId: ServiceResourceId & {
                name: ServiceResourceIdName;
                value: string;
            };
        };
    })[];
    nextToken?: string;
}
export declare const ListServiceJobsResponse: S.Schema<ListServiceJobsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type JobDefinitionType = "container" | "multinode" | (string & {});
export declare const JobDefinitionType: any;
export interface RegisterJobDefinitionRequest {
    jobDefinitionName?: string;
    type?: JobDefinitionType;
    parameters?: {
        [key: string]: string | undefined;
    };
    schedulingPriority?: number;
    containerProperties?: ContainerProperties;
    nodeProperties?: NodeProperties;
    retryStrategy?: RetryStrategy;
    propagateTags?: boolean;
    timeout?: JobTimeout;
    tags?: {
        [key: string]: string | undefined;
    };
    platformCapabilities?: PlatformCapability[];
    eksProperties?: EksProperties;
    ecsProperties?: EcsProperties;
    consumableResourceProperties?: ConsumableResourceProperties;
}
export declare const RegisterJobDefinitionRequest: S.Schema<RegisterJobDefinitionRequest>;
export interface RegisterJobDefinitionResponse {
    jobDefinitionName: string;
    jobDefinitionArn: string;
    revision: number;
}
export declare const RegisterJobDefinitionResponse: S.Schema<RegisterJobDefinitionResponse>;
export interface ArrayProperties {
    size?: number;
}
export declare const ArrayProperties: S.Schema<ArrayProperties>;
export interface ContainerOverrides {
    vcpus?: number;
    memory?: number;
    command?: string[];
    instanceType?: string;
    environment?: KeyValuePair[];
    resourceRequirements?: ResourceRequirement[];
}
export declare const ContainerOverrides: S.Schema<ContainerOverrides>;
export interface TaskContainerOverrides {
    command?: string[];
    environment?: KeyValuePair[];
    name?: string;
    resourceRequirements?: ResourceRequirement[];
}
export declare const TaskContainerOverrides: S.Schema<TaskContainerOverrides>;
export type ListTaskContainerOverrides = TaskContainerOverrides[];
export declare const ListTaskContainerOverrides: any;
export interface TaskPropertiesOverride {
    containers?: TaskContainerOverrides[];
}
export declare const TaskPropertiesOverride: S.Schema<TaskPropertiesOverride>;
export type ListTaskPropertiesOverride = TaskPropertiesOverride[];
export declare const ListTaskPropertiesOverride: any;
export interface EcsPropertiesOverride {
    taskProperties?: TaskPropertiesOverride[];
}
export declare const EcsPropertiesOverride: S.Schema<EcsPropertiesOverride>;
export interface EksContainerOverride {
    name?: string;
    image?: string;
    command?: string[];
    args?: string[];
    env?: EksContainerEnvironmentVariable[];
    resources?: EksContainerResourceRequirements;
}
export declare const EksContainerOverride: S.Schema<EksContainerOverride>;
export type EksContainerOverrideList = EksContainerOverride[];
export declare const EksContainerOverrideList: any;
export interface EksPodPropertiesOverride {
    containers?: EksContainerOverride[];
    initContainers?: EksContainerOverride[];
    metadata?: EksMetadata;
}
export declare const EksPodPropertiesOverride: S.Schema<EksPodPropertiesOverride>;
export interface EksPropertiesOverride {
    podProperties?: EksPodPropertiesOverride;
}
export declare const EksPropertiesOverride: S.Schema<EksPropertiesOverride>;
export interface NodePropertyOverride {
    targetNodes?: string;
    containerOverrides?: ContainerOverrides;
    ecsPropertiesOverride?: EcsPropertiesOverride;
    instanceTypes?: string[];
    eksPropertiesOverride?: EksPropertiesOverride;
    consumableResourcePropertiesOverride?: ConsumableResourceProperties;
}
export declare const NodePropertyOverride: S.Schema<NodePropertyOverride>;
export type NodePropertyOverrides = NodePropertyOverride[];
export declare const NodePropertyOverrides: any;
export interface NodeOverrides {
    numNodes?: number;
    nodePropertyOverrides?: NodePropertyOverride[];
}
export declare const NodeOverrides: S.Schema<NodeOverrides>;
export interface SubmitJobRequest {
    jobName?: string;
    jobQueue?: string;
    shareIdentifier?: string;
    schedulingPriorityOverride?: number;
    arrayProperties?: ArrayProperties;
    dependsOn?: JobDependency[];
    jobDefinition?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
    containerOverrides?: ContainerOverrides;
    nodeOverrides?: NodeOverrides;
    retryStrategy?: RetryStrategy;
    propagateTags?: boolean;
    timeout?: JobTimeout;
    tags?: {
        [key: string]: string | undefined;
    };
    eksPropertiesOverride?: EksPropertiesOverride;
    ecsPropertiesOverride?: EcsPropertiesOverride;
    consumableResourcePropertiesOverride?: ConsumableResourceProperties;
}
export declare const SubmitJobRequest: S.Schema<SubmitJobRequest>;
export interface SubmitJobResponse {
    jobArn?: string;
    jobName: string;
    jobId: string;
}
export declare const SubmitJobResponse: S.Schema<SubmitJobResponse>;
export type ClientRequestToken = string;
export interface SubmitServiceJobRequest {
    jobName?: string;
    jobQueue?: string;
    retryStrategy?: ServiceJobRetryStrategy;
    schedulingPriority?: number;
    serviceRequestPayload?: string;
    serviceJobType?: ServiceJobType;
    shareIdentifier?: string;
    quotaShareName?: string;
    preemptionConfiguration?: ServiceJobPreemptionConfiguration;
    timeoutConfig?: ServiceJobTimeout;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const SubmitServiceJobRequest: S.Schema<SubmitServiceJobRequest>;
export interface SubmitServiceJobResponse {
    jobArn?: string;
    jobName: string;
    jobId: string;
}
export declare const SubmitServiceJobResponse: S.Schema<SubmitServiceJobResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface TerminateJobRequest {
    jobId?: string;
    reason?: string;
}
export declare const TerminateJobRequest: S.Schema<TerminateJobRequest>;
export interface TerminateJobResponse {
}
export declare const TerminateJobResponse: S.Schema<TerminateJobResponse>;
export interface TerminateServiceJobRequest {
    jobId?: string;
    reason?: string;
}
export declare const TerminateServiceJobRequest: S.Schema<TerminateServiceJobRequest>;
export interface TerminateServiceJobResponse {
}
export declare const TerminateServiceJobResponse: S.Schema<TerminateServiceJobResponse>;
export type TagKeysList = string[];
export declare const TagKeysList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys?: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type CRUpdateAllocationStrategy = "BEST_FIT_PROGRESSIVE" | "BEST_FIT_PROGRESSIVE_ORDERED" | "SPOT_CAPACITY_OPTIMIZED" | "SPOT_PRICE_CAPACITY_OPTIMIZED" | "SPOT_CAPACITY_OPTIMIZED_PRIORITIZED" | (string & {});
export declare const CRUpdateAllocationStrategy: any;
export interface InstanceLaunchTemplateUpdate {
    ec2InstanceProfileArn?: string;
    networkConfiguration?: ManagedInstancesNetworkConfiguration;
    instanceRequirements?: InstanceRequirementsRequest;
    storageConfiguration?: ManagedInstancesStorageConfiguration;
    monitoring?: string;
    capacityReservations?: CapacityReservationRequest;
    instanceMetadataTagsPropagation?: boolean;
    localStorageConfiguration?: ManagedInstancesLocalStorageConfiguration;
}
export declare const InstanceLaunchTemplateUpdate: S.Schema<InstanceLaunchTemplateUpdate>;
export interface UpdateManagedInstancesProviderConfiguration {
    propagateTags?: string;
    infrastructureRoleArn?: string;
    instanceLaunchTemplate?: InstanceLaunchTemplateUpdate;
    infrastructureOptimization?: InfrastructureOptimization;
}
export declare const UpdateManagedInstancesProviderConfiguration: S.Schema<UpdateManagedInstancesProviderConfiguration>;
export interface ComputeResourceUpdate {
    minvCpus?: number;
    maxvCpus?: number;
    desiredvCpus?: number;
    subnets?: string[];
    securityGroupIds?: string[];
    allocationStrategy?: CRUpdateAllocationStrategy;
    instanceTypes?: string[];
    ec2KeyPair?: string;
    instanceRole?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    placementGroup?: string;
    bidPercentage?: number;
    launchTemplate?: LaunchTemplateSpecification;
    ec2Configuration?: Ec2Configuration[];
    updateToLatestImageVersion?: boolean;
    type?: CRType;
    imageId?: string;
    scalingPolicy?: ComputeScalingPolicy;
    managedInstancesProvider?: UpdateManagedInstancesProviderConfiguration;
    capacityTags?: {
        [key: string]: string | undefined;
    };
}
export declare const ComputeResourceUpdate: S.Schema<ComputeResourceUpdate>;
export interface UpdateComputeEnvironmentRequest {
    computeEnvironment?: string;
    state?: CEState;
    unmanagedvCpus?: number;
    computeResources?: ComputeResourceUpdate;
    serviceRole?: string;
    updatePolicy?: UpdatePolicy;
    context?: string;
    ecsSettings?: EcsSettings;
}
export declare const UpdateComputeEnvironmentRequest: S.Schema<UpdateComputeEnvironmentRequest>;
export interface UpdateComputeEnvironmentResponse {
    computeEnvironmentName?: string;
    computeEnvironmentArn?: string;
}
export declare const UpdateComputeEnvironmentResponse: S.Schema<UpdateComputeEnvironmentResponse>;
export interface UpdateConsumableResourceRequest {
    consumableResource?: string;
    operation?: string;
    quantity?: number;
    clientToken?: string;
}
export declare const UpdateConsumableResourceRequest: S.Schema<UpdateConsumableResourceRequest>;
export interface UpdateConsumableResourceResponse {
    consumableResourceName: string;
    consumableResourceArn: string;
    totalQuantity?: number;
}
export declare const UpdateConsumableResourceResponse: S.Schema<UpdateConsumableResourceResponse>;
export interface UpdateJobQueueRequest {
    jobQueue?: string;
    state?: JQState;
    schedulingPolicyArn?: string;
    priority?: number;
    computeEnvironmentOrder?: ComputeEnvironmentOrder[];
    serviceEnvironmentOrder?: ServiceEnvironmentOrder[];
    jobStateTimeLimitActions?: JobStateTimeLimitAction[];
}
export declare const UpdateJobQueueRequest: S.Schema<UpdateJobQueueRequest>;
export interface UpdateJobQueueResponse {
    jobQueueName?: string;
    jobQueueArn?: string;
}
export declare const UpdateJobQueueResponse: S.Schema<UpdateJobQueueResponse>;
export interface UpdateQuotaShareRequest {
    quotaShareArn?: string;
    capacityLimits?: QuotaShareCapacityLimit[];
    resourceSharingConfiguration?: QuotaShareResourceSharingConfiguration;
    preemptionConfiguration?: QuotaSharePreemptionConfiguration;
    state?: QuotaShareState;
}
export declare const UpdateQuotaShareRequest: S.Schema<UpdateQuotaShareRequest>;
export interface UpdateQuotaShareResponse {
    quotaShareName?: string;
    quotaShareArn?: string;
}
export declare const UpdateQuotaShareResponse: S.Schema<UpdateQuotaShareResponse>;
export interface UpdateSchedulingPolicyRequest {
    arn?: string;
    quotaSharePolicy?: QuotaSharePolicy;
    fairsharePolicy?: FairsharePolicy;
}
export declare const UpdateSchedulingPolicyRequest: S.Schema<UpdateSchedulingPolicyRequest>;
export interface UpdateSchedulingPolicyResponse {
}
export declare const UpdateSchedulingPolicyResponse: S.Schema<UpdateSchedulingPolicyResponse>;
export interface UpdateServiceEnvironmentRequest {
    serviceEnvironment?: string;
    state?: ServiceEnvironmentState;
    capacityLimits?: CapacityLimit[];
}
export declare const UpdateServiceEnvironmentRequest: S.Schema<UpdateServiceEnvironmentRequest>;
export interface UpdateServiceEnvironmentResponse {
    serviceEnvironmentName: string;
    serviceEnvironmentArn: string;
}
export declare const UpdateServiceEnvironmentResponse: S.Schema<UpdateServiceEnvironmentResponse>;
export interface UpdateServiceJobRequest {
    jobId?: string;
    schedulingPriority?: number;
}
export declare const UpdateServiceJobRequest: S.Schema<UpdateServiceJobRequest>;
export interface UpdateServiceJobResponse {
    jobArn?: string;
    jobName?: string;
    jobId?: string;
}
export declare const UpdateServiceJobResponse: S.Schema<UpdateServiceJobResponse>;
export type CancelJobError = ClientException | ServerException | CommonErrors;
/**
 * Cancels a job in an Batch job queue. Jobs that are in a `SUBMITTED`, `PENDING`, or `RUNNABLE` state are cancelled and the job status is updated to `FAILED`.
 *
 * A `PENDING` job is canceled after all dependency jobs are completed.
 * Therefore, it may take longer than expected to cancel a job in `PENDING`
 * status.
 *
 * When you try to cancel an array parent job in `PENDING`, Batch attempts to
 * cancel all child jobs. The array parent job is canceled when all child jobs are
 * completed.
 *
 * Jobs that progressed to the `STARTING` or
 * `RUNNING` state aren't canceled. However, the API operation still succeeds, even
 * if no job is canceled. These jobs must be terminated with the TerminateJob
 * operation.
 */
export declare const cancelJob: API.OperationMethod<CancelJobRequest, CancelJobResponse, CancelJobError, Credentials | HttpClient.HttpClient>;
export type CreateComputeEnvironmentError = ClientException | ServerException | CommonErrors;
/**
 * Creates an Batch compute environment. You can create `MANAGED` or
 * `UNMANAGED` compute environments. `MANAGED` compute environments can
 * use Amazon EC2 or Fargate resources. `UNMANAGED` compute environments can only use
 * EC2 resources.
 *
 * In a managed compute environment, Batch manages the capacity and instance types of the
 * compute resources within the environment. This is based on the compute resource specification
 * that you define or the launch template that you
 * specify when you create the compute environment. Either, you can choose to use EC2 On-Demand
 * Instances and EC2 Spot Instances. Or, you can use Fargate and Fargate Spot capacity in
 * your managed compute environment. You can optionally set a maximum price so that Spot
 * Instances only launch when the Spot Instance price is less than a specified percentage of the
 * On-Demand price.
 *
 * In an unmanaged compute environment, you can manage your own EC2 compute resources and
 * have flexibility with how you configure your compute resources. For example, you can use
 * custom AMIs. However, you must verify that each of your AMIs meet the Amazon ECS container instance
 * AMI specification. For more information, see container instance AMIs in the
 * *Amazon Elastic Container Service Developer Guide*. After you created your unmanaged compute environment,
 * you can use the DescribeComputeEnvironments operation to find the Amazon ECS
 * cluster that's associated with it. Then, launch your container instances into that Amazon ECS
 * cluster. For more information, see Launching an Amazon ECS container
 * instance in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Batch doesn't automatically upgrade the AMIs in a compute environment after it's
 * created. For more information on how to update a compute environment's AMI, see Updating compute environments in the *Batch User Guide*.
 */
export declare const createComputeEnvironment: API.OperationMethod<CreateComputeEnvironmentRequest, CreateComputeEnvironmentResponse, CreateComputeEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Creates an Batch consumable resource.
 */
export declare const createConsumableResource: API.OperationMethod<CreateConsumableResourceRequest, CreateConsumableResourceResponse, CreateConsumableResourceError, Credentials | HttpClient.HttpClient>;
export type CreateJobQueueError = ClientException | ServerException | ComputeEnvironmentNotValid | JobQueueAlreadyExists | CommonErrors;
/**
 * Creates an Batch job queue. When you create a job queue, you associate one or more
 * compute environments to the queue and assign an order of preference for the compute
 * environments.
 *
 * You also set a priority to the job queue that determines the order that the Batch
 * scheduler places jobs onto its associated compute environments. For example, if a compute
 * environment is associated with more than one job queue, the job queue with a higher priority
 * is given preference for scheduling jobs to that compute environment.
 */
export declare const createJobQueue: API.OperationMethod<CreateJobQueueRequest, CreateJobQueueResponse, CreateJobQueueError, Credentials | HttpClient.HttpClient>;
export type CreateQuotaShareError = ClientException | ServerException | CommonErrors;
/**
 * Creates an Batch quota share. Each quota share operates as a virtual queue with a configured compute capacity, resource sharing strategy, and borrow limits.
 */
export declare const createQuotaShare: API.OperationMethod<CreateQuotaShareRequest, CreateQuotaShareResponse, CreateQuotaShareError, Credentials | HttpClient.HttpClient>;
export type CreateSchedulingPolicyError = ClientException | ServerException | CommonErrors;
/**
 * Creates an Batch scheduling policy.
 */
export declare const createSchedulingPolicy: API.OperationMethod<CreateSchedulingPolicyRequest, CreateSchedulingPolicyResponse, CreateSchedulingPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateServiceEnvironmentError = ClientException | ServerException | CommonErrors;
/**
 * Creates a service environment for running service jobs. Service environments define capacity limits for specific service types such as SageMaker Training jobs.
 */
export declare const createServiceEnvironment: API.OperationMethod<CreateServiceEnvironmentRequest, CreateServiceEnvironmentResponse, CreateServiceEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteComputeEnvironmentError = ClientException | ServerException | ComputeEnvironmentNotFound | ComputeEnvironmentInUse | ComputeEnvironmentBeingModified | CommonErrors;
/**
 * Deletes an Batch compute environment.
 *
 * Before you can delete a compute environment, you must set its state to
 * `DISABLED` with the UpdateComputeEnvironment API operation and
 * disassociate it from any job queues with the UpdateJobQueue API operation.
 * Compute environments that use Fargate resources must terminate all active jobs on that
 * compute environment before deleting the compute environment. If this isn't done, the compute
 * environment enters an invalid state.
 */
export declare const deleteComputeEnvironment: API.OperationMethod<DeleteComputeEnvironmentRequest, DeleteComputeEnvironmentResponse, DeleteComputeEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Deletes the specified consumable resource.
 */
export declare const deleteConsumableResource: API.OperationMethod<DeleteConsumableResourceRequest, DeleteConsumableResourceResponse, DeleteConsumableResourceError, Credentials | HttpClient.HttpClient>;
export type DeleteJobQueueError = ClientException | ServerException | JobQueueNotFound | JobQueueBeingModified | CommonErrors;
/**
 * Deletes the specified job queue. You must first disable submissions for a queue with the
 * UpdateJobQueue operation. All jobs in the queue are eventually terminated
 * when you delete a job queue.
 *
 * It's not necessary to disassociate compute environments from a queue before submitting a
 * `DeleteJobQueue` request.
 */
export declare const deleteJobQueue: API.OperationMethod<DeleteJobQueueRequest, DeleteJobQueueResponse, DeleteJobQueueError, Credentials | HttpClient.HttpClient>;
export type DeleteQuotaShareError = ClientException | ServerException | CommonErrors;
/**
 * Deletes the specified quota share. You must first disable submissions for the share by
 * updating the state to `DISABLED` using the UpdateQuotaShare operation.
 * All jobs in the share are eventually terminated when you delete a quota share.
 */
export declare const deleteQuotaShare: API.OperationMethod<DeleteQuotaShareRequest, DeleteQuotaShareResponse, DeleteQuotaShareError, Credentials | HttpClient.HttpClient>;
export type DeleteSchedulingPolicyError = ClientException | ServerException | CommonErrors;
/**
 * Deletes the specified scheduling policy.
 *
 * You can't delete a scheduling policy that's used in any job queues.
 */
export declare const deleteSchedulingPolicy: API.OperationMethod<DeleteSchedulingPolicyRequest, DeleteSchedulingPolicyResponse, DeleteSchedulingPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceEnvironmentError = ClientException | ServerException | CommonErrors;
/**
 * Deletes a Service environment. Before you can delete a service environment, you must first set its state to `DISABLED` with the `UpdateServiceEnvironment` API operation and disassociate it from any job queues with the `UpdateJobQueue` API operation.
 */
export declare const deleteServiceEnvironment: API.OperationMethod<DeleteServiceEnvironmentRequest, DeleteServiceEnvironmentResponse, DeleteServiceEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeregisterJobDefinitionError = ClientException | ServerException | CommonErrors;
/**
 * Deregisters an Batch job definition. Job definitions are permanently deleted after 180
 * days.
 */
export declare const deregisterJobDefinition: API.OperationMethod<DeregisterJobDefinitionRequest, DeregisterJobDefinitionResponse, DeregisterJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeComputeEnvironmentsError = ClientException | ServerException | CommonErrors;
/**
 * Describes one or more of your compute environments.
 *
 * If you're using an unmanaged compute environment, you can use the
 * `DescribeComputeEnvironment` operation to determine the
 * `ecsClusterArn` that you launch your Amazon ECS container instances into.
 */
export declare const describeComputeEnvironments: API.PaginatedOperationMethod<DescribeComputeEnvironmentsRequest, DescribeComputeEnvironmentsResponse, DescribeComputeEnvironmentsError, Credentials | HttpClient.HttpClient, ComputeEnvironmentDetail>;
export type DescribeConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Returns a description of the specified consumable resource.
 */
export declare const describeConsumableResource: API.OperationMethod<DescribeConsumableResourceRequest, DescribeConsumableResourceResponse, DescribeConsumableResourceError, Credentials | HttpClient.HttpClient>;
export type DescribeJobDefinitionsError = ClientException | ServerException | CommonErrors;
/**
 * Describes a list of job definitions. You can specify a `status` (such as
 * `ACTIVE`) to only return job definitions that match that status.
 */
export declare const describeJobDefinitions: API.PaginatedOperationMethod<DescribeJobDefinitionsRequest, DescribeJobDefinitionsResponse, DescribeJobDefinitionsError, Credentials | HttpClient.HttpClient, JobDefinition>;
export type DescribeJobQueuesError = ClientException | ServerException | CommonErrors;
/**
 * Describes one or more of your job queues.
 */
export declare const describeJobQueues: API.PaginatedOperationMethod<DescribeJobQueuesRequest, DescribeJobQueuesResponse, DescribeJobQueuesError, Credentials | HttpClient.HttpClient, JobQueueDetail>;
export type DescribeJobsError = ClientException | ServerException | CommonErrors;
/**
 * Describes a list of Batch jobs.
 */
export declare const describeJobs: API.OperationMethod<DescribeJobsRequest, DescribeJobsResponse, DescribeJobsError, Credentials | HttpClient.HttpClient>;
export type DescribeQuotaShareError = ClientException | ServerException | CommonErrors;
/**
 * Returns a description of the specified quota share.
 */
export declare const describeQuotaShare: API.OperationMethod<DescribeQuotaShareRequest, DescribeQuotaShareResponse, DescribeQuotaShareError, Credentials | HttpClient.HttpClient>;
export type DescribeSchedulingPoliciesError = ClientException | ServerException | CommonErrors;
/**
 * Describes one or more of your scheduling policies.
 */
export declare const describeSchedulingPolicies: API.OperationMethod<DescribeSchedulingPoliciesRequest, DescribeSchedulingPoliciesResponse, DescribeSchedulingPoliciesError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceEnvironmentsError = ClientException | ServerException | CommonErrors;
/**
 * Describes one or more of your service environments.
 */
export declare const describeServiceEnvironments: API.PaginatedOperationMethod<DescribeServiceEnvironmentsRequest, DescribeServiceEnvironmentsResponse, DescribeServiceEnvironmentsError, Credentials | HttpClient.HttpClient, ServiceEnvironmentDetail>;
export type DescribeServiceJobError = ClientException | ServerException | CommonErrors;
/**
 * The details of a service job.
 */
export declare const describeServiceJob: API.OperationMethod<DescribeServiceJobRequest, DescribeServiceJobResponse, DescribeServiceJobError, Credentials | HttpClient.HttpClient>;
export type GetJobQueueSnapshotError = ClientException | ServerException | CommonErrors;
/**
 * Provides a snapshot of job queue state, including ordering of `RUNNABLE` jobs, as well as capacity utilization for already dispatched jobs.
 * The first 100 `RUNNABLE` jobs in the job queue are listed in order of dispatch. For job queues with an attached
 * quota-share policy, the first `RUNNABLE` job in each quota share is also listed. Capacity utilization for the job queue is provided, as well as
 * break downs by share for job queues with attached fair-share or quota-share scheduling policies.
 */
export declare const getJobQueueSnapshot: API.OperationMethod<GetJobQueueSnapshotRequest, GetJobQueueSnapshotResponse, GetJobQueueSnapshotError, Credentials | HttpClient.HttpClient>;
export type ListConsumableResourcesError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch consumable resources.
 */
export declare const listConsumableResources: API.PaginatedOperationMethod<ListConsumableResourcesRequest, ListConsumableResourcesResponse, ListConsumableResourcesError, Credentials | HttpClient.HttpClient, ConsumableResourceSummary>;
export type ListJobsError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch jobs.
 *
 * You must specify only one of the following items:
 *
 * - A job queue ID to return a list of jobs in that job queue
 *
 * - A multi-node parallel job ID to return a list of nodes for that job
 *
 * - An array job ID to return a list of the children for that job
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest, ListJobsResponse, ListJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListJobsByConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch jobs that require a specific consumable resource.
 */
export declare const listJobsByConsumableResource: API.PaginatedOperationMethod<ListJobsByConsumableResourceRequest, ListJobsByConsumableResourceResponse, ListJobsByConsumableResourceError, Credentials | HttpClient.HttpClient, ListJobsByConsumableResourceSummary>;
export type ListQuotaSharesError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch quota shares associated with a job queue.
 */
export declare const listQuotaShares: API.PaginatedOperationMethod<ListQuotaSharesRequest, ListQuotaSharesResponse, ListQuotaSharesError, Credentials | HttpClient.HttpClient, QuotaShareDetail>;
export type ListSchedulingPoliciesError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch scheduling policies.
 */
export declare const listSchedulingPolicies: API.PaginatedOperationMethod<ListSchedulingPoliciesRequest, ListSchedulingPoliciesResponse, ListSchedulingPoliciesError, Credentials | HttpClient.HttpClient, SchedulingPolicyListingDetail>;
export type ListServiceJobsError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of service jobs for a specified job queue.
 */
export declare const listServiceJobs: API.PaginatedOperationMethod<ListServiceJobsRequest, ListServiceJobsResponse, ListServiceJobsError, Credentials | HttpClient.HttpClient, ServiceJobSummary>;
export type ListTagsForResourceError = ClientException | ServerException | CommonErrors;
/**
 * Lists the tags for an Batch resource. Batch resources that support tags are compute environments, jobs, job definitions, job queues,
 * and scheduling policies. ARNs for child jobs of array and multi-node parallel (MNP) jobs aren't supported.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterJobDefinitionError = ClientException | ServerException | CommonErrors;
/**
 * Registers an Batch job definition.
 */
export declare const registerJobDefinition: API.OperationMethod<RegisterJobDefinitionRequest, RegisterJobDefinitionResponse, RegisterJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type SubmitJobError = ClientException | ServerException | CommonErrors;
/**
 * Submits an Batch job from a job definition. Parameters that are specified during SubmitJob override parameters defined in the job definition. vCPU and memory
 * requirements that are specified in the `resourceRequirements` objects in the job
 * definition are the exception. They can't be overridden this way using the `memory`
 * and `vcpus` parameters. Rather, you must specify updates to job definition
 * parameters in a `resourceRequirements` object that's included in the
 * `containerOverrides` parameter.
 *
 * Job queues with a scheduling policy are limited to 500 active share identifiers at
 * a time.
 *
 * Jobs that run on Fargate resources can't be guaranteed to run for more than 14 days.
 * This is because, after 14 days, Fargate resources might become unavailable and job might be
 * terminated.
 */
export declare const submitJob: API.OperationMethod<SubmitJobRequest, SubmitJobResponse, SubmitJobError, Credentials | HttpClient.HttpClient>;
export type SubmitServiceJobError = ClientException | ServerException | CommonErrors;
/**
 * Submits a service job to a specified job queue to run on SageMaker AI. A service job is a unit of work that you submit to Batch for execution on SageMaker AI.
 */
export declare const submitServiceJob: API.OperationMethod<SubmitServiceJobRequest, SubmitServiceJobResponse, SubmitServiceJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ClientException | ServerException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `resourceArn`.
 * If existing tags on a resource aren't specified in the request parameters, they aren't
 * changed. When a resource is deleted, the tags that are associated with that resource are
 * deleted as well. Batch resources that support tags are compute environments, jobs, job definitions, job queues,
 * and scheduling policies. ARNs for child jobs of array and multi-node parallel (MNP) jobs aren't supported.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateJobError = ClientException | ServerException | CommonErrors;
/**
 * Terminates a job in a job queue. Jobs that are in the `STARTING` or
 * `RUNNING` state are terminated, which causes them to transition to
 * `FAILED`. Jobs that have not progressed to the `STARTING` state are
 * cancelled.
 */
export declare const terminateJob: API.OperationMethod<TerminateJobRequest, TerminateJobResponse, TerminateJobError, Credentials | HttpClient.HttpClient>;
export type TerminateServiceJobError = ClientException | ServerException | CommonErrors;
/**
 * Terminates a service job in a job queue.
 */
export declare const terminateServiceJob: API.OperationMethod<TerminateServiceJobRequest, TerminateServiceJobResponse, TerminateServiceJobError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ClientException | ServerException | CommonErrors;
/**
 * Deletes specified tags from an Batch resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateComputeEnvironmentError = ClientException | ServerException | ComputeEnvironmentNotFound | ComputeEnvironmentBeingModified | CommonErrors;
/**
 * Updates an Batch compute environment.
 */
export declare const updateComputeEnvironment: API.OperationMethod<UpdateComputeEnvironmentRequest, UpdateComputeEnvironmentResponse, UpdateComputeEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Updates a consumable resource.
 */
export declare const updateConsumableResource: API.OperationMethod<UpdateConsumableResourceRequest, UpdateConsumableResourceResponse, UpdateConsumableResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateJobQueueError = ClientException | ServerException | JobQueueNotFound | JobQueueBeingModified | CommonErrors;
/**
 * Updates a job queue.
 */
export declare const updateJobQueue: API.OperationMethod<UpdateJobQueueRequest, UpdateJobQueueResponse, UpdateJobQueueError, Credentials | HttpClient.HttpClient>;
export type UpdateQuotaShareError = ClientException | ServerException | CommonErrors;
/**
 * Updates a quota share.
 */
export declare const updateQuotaShare: API.OperationMethod<UpdateQuotaShareRequest, UpdateQuotaShareResponse, UpdateQuotaShareError, Credentials | HttpClient.HttpClient>;
export type UpdateSchedulingPolicyError = ClientException | ServerException | CommonErrors;
/**
 * Updates a scheduling policy.
 */
export declare const updateSchedulingPolicy: API.OperationMethod<UpdateSchedulingPolicyRequest, UpdateSchedulingPolicyResponse, UpdateSchedulingPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceEnvironmentError = ClientException | ServerException | CommonErrors;
/**
 * Updates a service environment. You can update the state of a service environment from `ENABLED` to `DISABLED` to prevent new service jobs from being placed in the service environment.
 */
export declare const updateServiceEnvironment: API.OperationMethod<UpdateServiceEnvironmentRequest, UpdateServiceEnvironmentResponse, UpdateServiceEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceJobError = ClientException | ServerException | CommonErrors;
/**
 * Updates the priority of a specified service job in an Batch job queue.
 */
export declare const updateServiceJob: API.OperationMethod<UpdateServiceJobRequest, UpdateServiceJobResponse, UpdateServiceJobError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=batch.d.ts.map