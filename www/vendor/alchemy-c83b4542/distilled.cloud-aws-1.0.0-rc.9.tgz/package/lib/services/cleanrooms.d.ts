import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
    readonly reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly quotaName: any;
    readonly quotaValue: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CollaborationIdentifier = string;
export type AnalysisTemplateArn = string;
export type AnalysisTemplateArnList = string[];
export declare const AnalysisTemplateArnList: any;
export interface BatchGetCollaborationAnalysisTemplateInput {
    collaborationIdentifier: string;
    analysisTemplateArns: string[];
}
export declare const BatchGetCollaborationAnalysisTemplateInput: S.Schema<BatchGetCollaborationAnalysisTemplateInput>;
export type AnalysisTemplateIdentifier = string;
export type UUID = string;
export type CollaborationArn = string;
export type ResourceDescription = string;
export type AccountId = string;
export type ResourceAlias = string;
export type TableAlias = string;
export type QueryTables = string[];
export declare const QueryTables: any;
export interface AnalysisSchema {
    referencedTables?: string[];
}
export declare const AnalysisSchema: S.Schema<AnalysisSchema>;
export type AnalysisFormat = "SQL" | "PYSPARK_1_0" | (string & {});
export declare const AnalysisFormat: any;
export type AnalysisTemplateText = string | redacted.Redacted<string>;
export interface S3Location {
    bucket: string;
    key: string;
}
export declare const S3Location: S.Schema<S3Location>;
export interface AnalysisTemplateArtifact {
    location: S3Location;
}
export declare const AnalysisTemplateArtifact: S.Schema<AnalysisTemplateArtifact>;
export type AnalysisTemplateArtifactList = AnalysisTemplateArtifact[];
export declare const AnalysisTemplateArtifactList: any;
export type RoleArn = string;
export interface AnalysisTemplateArtifacts {
    entryPoint: AnalysisTemplateArtifact;
    additionalArtifacts?: AnalysisTemplateArtifact[];
    roleArn: string;
}
export declare const AnalysisTemplateArtifacts: S.Schema<AnalysisTemplateArtifacts>;
export type AnalysisSource = {
    text: string | redacted.Redacted<string>;
    artifacts?: never;
} | {
    text?: never;
    artifacts: AnalysisTemplateArtifacts;
};
export declare const AnalysisSource: any;
export interface Hash {
    sha256?: string;
}
export declare const Hash: S.Schema<Hash>;
export type HashList = Hash[];
export declare const HashList: any;
export interface AnalysisTemplateArtifactMetadata {
    entryPointHash: Hash;
    additionalArtifactHashes?: Hash[];
}
export declare const AnalysisTemplateArtifactMetadata: S.Schema<AnalysisTemplateArtifactMetadata>;
export type AnalysisSourceMetadata = {
    artifacts: AnalysisTemplateArtifactMetadata;
};
export declare const AnalysisSourceMetadata: any;
export type ParameterName = string;
export type ParameterType = "SMALLINT" | "INTEGER" | "BIGINT" | "DECIMAL" | "REAL" | "DOUBLE_PRECISION" | "BOOLEAN" | "CHAR" | "VARCHAR" | "DATE" | "TIMESTAMP" | "TIMESTAMPTZ" | "TIME" | "TIMETZ" | "VARBYTE" | "BINARY" | "BYTE" | "CHARACTER" | "DOUBLE" | "FLOAT" | "INT" | "LONG" | "NUMERIC" | "SHORT" | "STRING" | "TIMESTAMP_LTZ" | "TIMESTAMP_NTZ" | "TINYINT" | (string & {});
export declare const ParameterType: any;
export type ParameterValue = string;
export interface AnalysisParameter {
    name: string;
    type: ParameterType;
    defaultValue?: string;
}
export declare const AnalysisParameter: S.Schema<AnalysisParameter>;
export type AnalysisParameterList = AnalysisParameter[];
export declare const AnalysisParameterList: any;
export type AnalysisTemplateValidationType = "DIFFERENTIAL_PRIVACY" | (string & {});
export declare const AnalysisTemplateValidationType: any;
export type AnalysisTemplateValidationStatus = "VALID" | "INVALID" | "UNABLE_TO_VALIDATE" | (string & {});
export declare const AnalysisTemplateValidationStatus: any;
export interface AnalysisTemplateValidationStatusReason {
    message: string;
}
export declare const AnalysisTemplateValidationStatusReason: S.Schema<AnalysisTemplateValidationStatusReason>;
export type AnalysisTemplateValidationStatusReasonList = AnalysisTemplateValidationStatusReason[];
export declare const AnalysisTemplateValidationStatusReasonList: any;
export interface AnalysisTemplateValidationStatusDetail {
    type: AnalysisTemplateValidationType;
    status: AnalysisTemplateValidationStatus;
    reasons?: AnalysisTemplateValidationStatusReason[];
}
export declare const AnalysisTemplateValidationStatusDetail: S.Schema<AnalysisTemplateValidationStatusDetail>;
export type AnalysisTemplateValidationStatusDetailList = AnalysisTemplateValidationStatusDetail[];
export declare const AnalysisTemplateValidationStatusDetailList: any;
export type ErrorMessageType = "DETAILED" | (string & {});
export declare const ErrorMessageType: any;
export interface ErrorMessageConfiguration {
    type: ErrorMessageType;
}
export declare const ErrorMessageConfiguration: S.Schema<ErrorMessageConfiguration>;
export type MaxMembershipInferenceAttackScore = number;
export type SyntheticDataColumnName = string;
export type SyntheticDataColumnType = "CATEGORICAL" | "NUMERICAL" | (string & {});
export declare const SyntheticDataColumnType: any;
export interface SyntheticDataColumnProperties {
    columnName: string;
    columnType: SyntheticDataColumnType;
    isPredictiveValue: boolean;
}
export declare const SyntheticDataColumnProperties: S.Schema<SyntheticDataColumnProperties>;
export type ColumnMappingList = SyntheticDataColumnProperties[];
export declare const ColumnMappingList: any;
export interface ColumnClassificationDetails {
    columnMapping: SyntheticDataColumnProperties[];
}
export declare const ColumnClassificationDetails: S.Schema<ColumnClassificationDetails>;
export interface MLSyntheticDataParameters {
    epsilon: number;
    maxMembershipInferenceAttackScore: number;
    columnClassification: ColumnClassificationDetails;
}
export declare const MLSyntheticDataParameters: S.Schema<MLSyntheticDataParameters>;
export type SyntheticDataParameters = {
    mlSyntheticDataParameters: MLSyntheticDataParameters;
};
export declare const SyntheticDataParameters: any;
export interface CollaborationAnalysisTemplate {
    id: string;
    arn: string;
    collaborationId: string;
    collaborationArn: string;
    description?: string;
    creatorAccountId: string;
    name: string;
    createTime: Date;
    updateTime: Date;
    schema: AnalysisSchema;
    format: AnalysisFormat;
    source?: AnalysisSource;
    sourceMetadata?: AnalysisSourceMetadata;
    analysisParameters?: AnalysisParameter[];
    validations?: AnalysisTemplateValidationStatusDetail[];
    errorMessageConfiguration?: ErrorMessageConfiguration;
    syntheticDataParameters?: SyntheticDataParameters;
}
export declare const CollaborationAnalysisTemplate: S.Schema<CollaborationAnalysisTemplate>;
export type CollaborationAnalysisTemplateList = CollaborationAnalysisTemplate[];
export declare const CollaborationAnalysisTemplateList: any;
export interface BatchGetCollaborationAnalysisTemplateError_ {
    arn: string;
    code: string;
    message: string;
}
export declare const BatchGetCollaborationAnalysisTemplateError_: S.Schema<BatchGetCollaborationAnalysisTemplateError_>;
export type BatchGetCollaborationAnalysisTemplateErrorList = BatchGetCollaborationAnalysisTemplateError_[];
export declare const BatchGetCollaborationAnalysisTemplateErrorList: any;
export interface BatchGetCollaborationAnalysisTemplateOutput {
    collaborationAnalysisTemplates: CollaborationAnalysisTemplate[];
    errors: BatchGetCollaborationAnalysisTemplateError_[];
}
export declare const BatchGetCollaborationAnalysisTemplateOutput: S.Schema<BatchGetCollaborationAnalysisTemplateOutput>;
export type TableAliasList = string[];
export declare const TableAliasList: any;
export interface BatchGetSchemaInput {
    collaborationIdentifier: string;
    names: string[];
}
export declare const BatchGetSchemaInput: S.Schema<BatchGetSchemaInput>;
export type ColumnName = string;
export type ColumnTypeString = string;
export interface Column {
    name: string;
    type: string;
}
export declare const Column: S.Schema<Column>;
export type ColumnList = Column[];
export declare const ColumnList: any;
export type AnalysisRuleType = "AGGREGATION" | "LIST" | "CUSTOM" | "ID_MAPPING_TABLE" | (string & {});
export declare const AnalysisRuleType: any;
export type AnalysisRuleTypeList = AnalysisRuleType[];
export declare const AnalysisRuleTypeList: any;
export type AnalysisMethod = "DIRECT_QUERY" | "DIRECT_JOB" | "MULTIPLE" | (string & {});
export declare const AnalysisMethod: any;
export type SelectedAnalysisMethod = "DIRECT_QUERY" | "DIRECT_JOB" | (string & {});
export declare const SelectedAnalysisMethod: any;
export type SelectedAnalysisMethods = SelectedAnalysisMethod[];
export declare const SelectedAnalysisMethods: any;
export type TableDescription = string;
export type SchemaType = "TABLE" | "ID_MAPPING_TABLE" | "INTERMEDIATE_TABLE" | (string & {});
export declare const SchemaType: any;
export type SchemaStatus = "READY" | "NOT_READY" | (string & {});
export declare const SchemaStatus: any;
export type SchemaStatusReasonCode = "ANALYSIS_RULE_MISSING" | "ANALYSIS_TEMPLATES_NOT_CONFIGURED" | "ANALYSIS_PROVIDERS_NOT_CONFIGURED" | "DIFFERENTIAL_PRIVACY_POLICY_NOT_CONFIGURED" | "ID_MAPPING_TABLE_NOT_POPULATED" | "COLLABORATION_ANALYSIS_RULE_NOT_CONFIGURED" | "ADDITIONAL_ANALYSES_NOT_CONFIGURED" | "RESULT_RECEIVERS_NOT_CONFIGURED" | "ADDITIONAL_ANALYSES_NOT_ALLOWED" | "RESULT_RECEIVERS_NOT_ALLOWED" | "ANALYSIS_RULE_TYPES_NOT_COMPATIBLE" | "INTERMEDIATE_TABLE_NOT_POPULATED" | "INTERMEDIATE_TABLE_ANALYSIS_RULE_MISSING" | "INTERMEDIATE_TABLE_BASE_TABLE_REMOVED" | "INTERMEDIATE_TABLE_INHERITED_CONSTRAINTS_VIOLATED" | "INTERMEDIATE_TABLE_DISALLOWED_BY_DATA_PROVIDER" | "INTERMEDIATE_TABLE_RETENTION_PERIOD_EXPIRED" | (string & {});
export declare const SchemaStatusReasonCode: any;
export interface SchemaStatusReason {
    code: SchemaStatusReasonCode;
    message: string;
}
export declare const SchemaStatusReason: S.Schema<SchemaStatusReason>;
export type SchemaStatusReasonList = SchemaStatusReason[];
export declare const SchemaStatusReasonList: any;
export type SchemaConfiguration = "DIFFERENTIAL_PRIVACY" | (string & {});
export declare const SchemaConfiguration: any;
export type SchemaConfigurationList = SchemaConfiguration[];
export declare const SchemaConfigurationList: any;
export type AnalysisType = "DIRECT_ANALYSIS" | "ADDITIONAL_ANALYSIS" | (string & {});
export declare const AnalysisType: any;
export interface SchemaStatusDetail {
    status: SchemaStatus;
    reasons?: SchemaStatusReason[];
    analysisRuleType?: AnalysisRuleType;
    configurations?: SchemaConfiguration[];
    analysisType: AnalysisType;
}
export declare const SchemaStatusDetail: S.Schema<SchemaStatusDetail>;
export type SchemaStatusDetailList = SchemaStatusDetail[];
export declare const SchemaStatusDetailList: any;
export type SchemaResourceArn = string;
export type IdNamespaceType = "SOURCE" | "TARGET" | (string & {});
export declare const IdNamespaceType: any;
export interface IdMappingTableInputSource {
    idNamespaceAssociationId: string;
    type: IdNamespaceType;
}
export declare const IdMappingTableInputSource: S.Schema<IdMappingTableInputSource>;
export type IdMappingTableInputSourceList = IdMappingTableInputSource[];
export declare const IdMappingTableInputSourceList: any;
export interface IdMappingTableSchemaTypeProperties {
    idMappingTableInputSource: IdMappingTableInputSource[];
    idMappingTableId?: string;
}
export declare const IdMappingTableSchemaTypeProperties: S.Schema<IdMappingTableSchemaTypeProperties>;
export interface IntermediateTableSchemaTypeProperties {
    intermediateTableId: string;
}
export declare const IntermediateTableSchemaTypeProperties: S.Schema<IntermediateTableSchemaTypeProperties>;
export interface ConfiguredTableAssociationSchemaTypeProperties {
    configuredTableAssociationId: string;
}
export declare const ConfiguredTableAssociationSchemaTypeProperties: S.Schema<ConfiguredTableAssociationSchemaTypeProperties>;
export type SchemaTypeProperties = {
    idMappingTable: IdMappingTableSchemaTypeProperties;
    intermediateTable?: never;
    configuredTableAssociation?: never;
} | {
    idMappingTable?: never;
    intermediateTable: IntermediateTableSchemaTypeProperties;
    configuredTableAssociation?: never;
} | {
    idMappingTable?: never;
    intermediateTable?: never;
    configuredTableAssociation: ConfiguredTableAssociationSchemaTypeProperties;
};
export declare const SchemaTypeProperties: any;
export interface Schema {
    columns: Column[];
    partitionKeys: Column[];
    analysisRuleTypes: AnalysisRuleType[];
    analysisMethod?: AnalysisMethod;
    selectedAnalysisMethods?: SelectedAnalysisMethod[];
    creatorAccountId: string;
    name: string;
    collaborationId: string;
    collaborationArn: string;
    description: string;
    createTime: Date;
    updateTime: Date;
    type: SchemaType;
    schemaStatusDetails: SchemaStatusDetail[];
    resourceArn?: string;
    schemaTypeProperties?: SchemaTypeProperties;
}
export declare const Schema: S.Schema<Schema>;
export type SchemaList = Schema[];
export declare const SchemaList: any;
export interface BatchGetSchemaError_ {
    name: string;
    code: string;
    message: string;
}
export declare const BatchGetSchemaError_: S.Schema<BatchGetSchemaError_>;
export type BatchGetSchemaErrorList = BatchGetSchemaError_[];
export declare const BatchGetSchemaErrorList: any;
export interface BatchGetSchemaOutput {
    schemas: Schema[];
    errors: BatchGetSchemaError_[];
}
export declare const BatchGetSchemaOutput: S.Schema<BatchGetSchemaOutput>;
export interface SchemaAnalysisRuleRequest {
    name: string;
    type: AnalysisRuleType;
}
export declare const SchemaAnalysisRuleRequest: S.Schema<SchemaAnalysisRuleRequest>;
export type SchemaAnalysisRuleRequestList = SchemaAnalysisRuleRequest[];
export declare const SchemaAnalysisRuleRequestList: any;
export interface BatchGetSchemaAnalysisRuleInput {
    collaborationIdentifier: string;
    schemaAnalysisRuleRequests: SchemaAnalysisRuleRequest[];
}
export declare const BatchGetSchemaAnalysisRuleInput: S.Schema<BatchGetSchemaAnalysisRuleInput>;
export type AnalysisRuleColumnName = string;
export type AnalysisRuleColumnList = string[];
export declare const AnalysisRuleColumnList: any;
export type JoinOperator = string;
export type JoinOperatorsList = string[];
export declare const JoinOperatorsList: any;
export type AdditionalAnalyses = "ALLOWED" | "REQUIRED" | "NOT_ALLOWED" | (string & {});
export declare const AdditionalAnalyses: any;
export interface AnalysisRuleList {
    joinColumns: string[];
    allowedJoinOperators?: string[];
    listColumns: string[];
    additionalAnalyses?: AdditionalAnalyses;
}
export declare const AnalysisRuleList: S.Schema<AnalysisRuleList>;
export type AnalysisRuleColumnNameList = string[];
export declare const AnalysisRuleColumnNameList: any;
export type AggregateFunctionName = string;
export interface AggregateColumn {
    columnNames: string[];
    function: string;
}
export declare const AggregateColumn: S.Schema<AggregateColumn>;
export type AggregateColumnList = AggregateColumn[];
export declare const AggregateColumnList: any;
export type JoinRequiredOption = string;
export type ScalarFunctions = string;
export type ScalarFunctionsList = string[];
export declare const ScalarFunctionsList: any;
export type AggregationType = string;
export interface AggregationConstraint {
    columnName: string;
    minimum: number;
    type: string;
}
export declare const AggregationConstraint: S.Schema<AggregationConstraint>;
export type AggregationConstraints = AggregationConstraint[];
export declare const AggregationConstraints: any;
export interface AnalysisRuleAggregation {
    aggregateColumns: AggregateColumn[];
    joinColumns: string[];
    joinRequired?: string;
    allowedJoinOperators?: string[];
    dimensionColumns: string[];
    scalarFunctions: string[];
    outputConstraints: AggregationConstraint[];
    additionalAnalyses?: AdditionalAnalyses;
}
export declare const AnalysisRuleAggregation: S.Schema<AnalysisRuleAggregation>;
export type AnalysisTemplateArnOrQueryWildcard = string;
export type AllowedAnalysesList = string[];
export declare const AllowedAnalysesList: any;
export type AllowedAnalysisProviderList = string[];
export declare const AllowedAnalysisProviderList: any;
export interface DifferentialPrivacyColumn {
    name: string;
}
export declare const DifferentialPrivacyColumn: S.Schema<DifferentialPrivacyColumn>;
export type DifferentialPrivacyColumnList = DifferentialPrivacyColumn[];
export declare const DifferentialPrivacyColumnList: any;
export interface DifferentialPrivacyConfiguration {
    columns: DifferentialPrivacyColumn[];
}
export declare const DifferentialPrivacyConfiguration: S.Schema<DifferentialPrivacyConfiguration>;
export type AggregationThresholdType = "COUNT_DISTINCT" | (string & {});
export declare const AggregationThresholdType: any;
export interface OutputColumnThreshold {
    outputColumnName: string;
    minimumIdentityCount: number;
}
export declare const OutputColumnThreshold: S.Schema<OutputColumnThreshold>;
export type OutputColumnThresholdList = OutputColumnThreshold[];
export declare const OutputColumnThresholdList: any;
export type AllowedAggregateExpressionType = "COLUMNS_ONLY" | "ANY_EXPRESSION" | (string & {});
export declare const AllowedAggregateExpressionType: any;
export interface AggregationThreshold {
    identityColumns: string[];
    minimumIdentityCount: number;
    type: AggregationThresholdType;
    outputColumnThresholds?: OutputColumnThreshold[];
    allowedAggregateExpressionType: AllowedAggregateExpressionType;
}
export declare const AggregationThreshold: S.Schema<AggregationThreshold>;
export type AggregationThresholdList = AggregationThreshold[];
export declare const AggregationThresholdList: any;
export interface ComparisonControls {
    allowedLiteralComparisonColumns: string[];
    allowedColumnComparisonColumns: string[];
}
export declare const ComparisonControls: S.Schema<ComparisonControls>;
export type AllowedResultReceivers = string[];
export declare const AllowedResultReceivers: any;
export type AdditionalAnalysesResourceArn = string;
export type AllowedAdditionalAnalyses = string[];
export declare const AllowedAdditionalAnalyses: any;
export interface AnalysisRuleCustom {
    allowedAnalyses: string[];
    allowedAnalysisProviders?: string[];
    additionalAnalyses?: AdditionalAnalyses;
    disallowedOutputColumns?: string[];
    differentialPrivacy?: DifferentialPrivacyConfiguration;
    aggregationThresholds?: AggregationThreshold[];
    comparisonControls?: ComparisonControls;
    allowedResultReceivers?: string[];
    allowedAdditionalAnalyses?: string[];
}
export declare const AnalysisRuleCustom: S.Schema<AnalysisRuleCustom>;
export interface QueryConstraintRequireOverlap {
    columns?: string[];
}
export declare const QueryConstraintRequireOverlap: S.Schema<QueryConstraintRequireOverlap>;
export type QueryConstraint = {
    requireOverlap: QueryConstraintRequireOverlap;
};
export declare const QueryConstraint: any;
export type QueryConstraintList = QueryConstraint[];
export declare const QueryConstraintList: any;
export interface AnalysisRuleIdMappingTable {
    joinColumns: string[];
    queryConstraints: QueryConstraint[];
    dimensionColumns?: string[];
}
export declare const AnalysisRuleIdMappingTable: S.Schema<AnalysisRuleIdMappingTable>;
export type AnalysisRulePolicyV1 = {
    list: AnalysisRuleList;
    aggregation?: never;
    custom?: never;
    idMappingTable?: never;
} | {
    list?: never;
    aggregation: AnalysisRuleAggregation;
    custom?: never;
    idMappingTable?: never;
} | {
    list?: never;
    aggregation?: never;
    custom: AnalysisRuleCustom;
    idMappingTable?: never;
} | {
    list?: never;
    aggregation?: never;
    custom?: never;
    idMappingTable: AnalysisRuleIdMappingTable;
};
export declare const AnalysisRulePolicyV1: any;
export type AnalysisRulePolicy = {
    v1: AnalysisRulePolicyV1;
};
export declare const AnalysisRulePolicy: any;
export interface ConfiguredTableAssociationAnalysisRuleList {
    allowedResultReceivers?: string[];
    allowedAdditionalAnalyses?: string[];
}
export declare const ConfiguredTableAssociationAnalysisRuleList: S.Schema<ConfiguredTableAssociationAnalysisRuleList>;
export interface ConfiguredTableAssociationAnalysisRuleAggregation {
    allowedResultReceivers?: string[];
    allowedAdditionalAnalyses?: string[];
}
export declare const ConfiguredTableAssociationAnalysisRuleAggregation: S.Schema<ConfiguredTableAssociationAnalysisRuleAggregation>;
export interface ConfiguredTableAssociationAnalysisRuleCustom {
    allowedResultReceivers?: string[];
    allowedAdditionalAnalyses?: string[];
}
export declare const ConfiguredTableAssociationAnalysisRuleCustom: S.Schema<ConfiguredTableAssociationAnalysisRuleCustom>;
export type ConfiguredTableAssociationAnalysisRulePolicyV1 = {
    list: ConfiguredTableAssociationAnalysisRuleList;
    aggregation?: never;
    custom?: never;
} | {
    list?: never;
    aggregation: ConfiguredTableAssociationAnalysisRuleAggregation;
    custom?: never;
} | {
    list?: never;
    aggregation?: never;
    custom: ConfiguredTableAssociationAnalysisRuleCustom;
};
export declare const ConfiguredTableAssociationAnalysisRulePolicyV1: any;
export type ConfiguredTableAssociationAnalysisRulePolicy = {
    v1: ConfiguredTableAssociationAnalysisRulePolicyV1;
};
export declare const ConfiguredTableAssociationAnalysisRulePolicy: any;
export interface ConsolidatedPolicyList {
    joinColumns: string[];
    allowedJoinOperators?: string[];
    listColumns: string[];
    additionalAnalyses?: AdditionalAnalyses;
    allowedResultReceivers?: string[];
    allowedAdditionalAnalyses?: string[];
}
export declare const ConsolidatedPolicyList: S.Schema<ConsolidatedPolicyList>;
export interface ConsolidatedPolicyAggregation {
    aggregateColumns: AggregateColumn[];
    joinColumns: string[];
    joinRequired?: string;
    allowedJoinOperators?: string[];
    dimensionColumns: string[];
    scalarFunctions: string[];
    outputConstraints: AggregationConstraint[];
    additionalAnalyses?: AdditionalAnalyses;
    allowedResultReceivers?: string[];
    allowedAdditionalAnalyses?: string[];
}
export declare const ConsolidatedPolicyAggregation: S.Schema<ConsolidatedPolicyAggregation>;
export interface ConsolidatedPolicyCustom {
    allowedAnalyses: string[];
    allowedAnalysisProviders?: string[];
    additionalAnalyses?: AdditionalAnalyses;
    disallowedOutputColumns?: string[];
    differentialPrivacy?: DifferentialPrivacyConfiguration;
    aggregationThresholds?: AggregationThreshold[];
    comparisonControls?: ComparisonControls;
    allowedResultReceivers?: string[];
    allowedAdditionalAnalyses?: string[];
}
export declare const ConsolidatedPolicyCustom: S.Schema<ConsolidatedPolicyCustom>;
export type ConsolidatedPolicyV1 = {
    list: ConsolidatedPolicyList;
    aggregation?: never;
    custom?: never;
} | {
    list?: never;
    aggregation: ConsolidatedPolicyAggregation;
    custom?: never;
} | {
    list?: never;
    aggregation?: never;
    custom: ConsolidatedPolicyCustom;
};
export declare const ConsolidatedPolicyV1: any;
export type ConsolidatedPolicy = {
    v1: ConsolidatedPolicyV1;
};
export declare const ConsolidatedPolicy: any;
export interface AnalysisRule {
    collaborationId: string;
    type: AnalysisRuleType;
    name: string;
    createTime: Date;
    updateTime: Date;
    policy: AnalysisRulePolicy;
    collaborationPolicy?: ConfiguredTableAssociationAnalysisRulePolicy;
    consolidatedPolicy?: ConsolidatedPolicy;
}
export declare const AnalysisRule: S.Schema<AnalysisRule>;
export type SchemaAnalysisRuleList = AnalysisRule[];
export declare const SchemaAnalysisRuleList: any;
export interface BatchGetSchemaAnalysisRuleError_ {
    name: string;
    type: AnalysisRuleType;
    code: string;
    message: string;
}
export declare const BatchGetSchemaAnalysisRuleError_: S.Schema<BatchGetSchemaAnalysisRuleError_>;
export type BatchGetSchemaAnalysisRuleErrorList = BatchGetSchemaAnalysisRuleError_[];
export declare const BatchGetSchemaAnalysisRuleErrorList: any;
export interface BatchGetSchemaAnalysisRuleOutput {
    analysisRules: AnalysisRule[];
    errors: BatchGetSchemaAnalysisRuleError_[];
}
export declare const BatchGetSchemaAnalysisRuleOutput: S.Schema<BatchGetSchemaAnalysisRuleOutput>;
export type MembershipIdentifier = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateAnalysisTemplateInput {
    description?: string;
    membershipIdentifier: string;
    name: string;
    format: AnalysisFormat;
    source: AnalysisSource;
    tags?: {
        [key: string]: string | undefined;
    };
    analysisParameters?: AnalysisParameter[];
    schema?: AnalysisSchema;
    errorMessageConfiguration?: ErrorMessageConfiguration;
    syntheticDataParameters?: SyntheticDataParameters;
}
export declare const CreateAnalysisTemplateInput: S.Schema<CreateAnalysisTemplateInput>;
export type MembershipArn = string;
export interface AnalysisTemplate {
    id: string;
    arn: string;
    collaborationId: string;
    collaborationArn: string;
    membershipId: string;
    membershipArn: string;
    description?: string;
    name: string;
    createTime: Date;
    updateTime: Date;
    schema: AnalysisSchema;
    format: AnalysisFormat;
    source: AnalysisSource;
    sourceMetadata?: AnalysisSourceMetadata;
    analysisParameters?: AnalysisParameter[];
    validations?: AnalysisTemplateValidationStatusDetail[];
    errorMessageConfiguration?: ErrorMessageConfiguration;
    syntheticDataParameters?: SyntheticDataParameters;
}
export declare const AnalysisTemplate: S.Schema<AnalysisTemplate>;
export interface CreateAnalysisTemplateOutput {
    analysisTemplate: AnalysisTemplate;
}
export declare const CreateAnalysisTemplateOutput: S.Schema<CreateAnalysisTemplateOutput>;
export type MemberAbility = "CAN_QUERY" | "CAN_RECEIVE_RESULTS" | "CAN_RUN_JOB" | "CAN_EXPORT_QUERY_ANALYSIS_LOG" | (string & {});
export declare const MemberAbility: any;
export type MemberAbilities = MemberAbility[];
export declare const MemberAbilities: any;
export type CustomMLMemberAbility = "CAN_RECEIVE_MODEL_OUTPUT" | "CAN_RECEIVE_INFERENCE_OUTPUT" | (string & {});
export declare const CustomMLMemberAbility: any;
export type CustomMLMemberAbilities = CustomMLMemberAbility[];
export declare const CustomMLMemberAbilities: any;
export interface MLMemberAbilities {
    customMLMemberAbilities: CustomMLMemberAbility[];
}
export declare const MLMemberAbilities: S.Schema<MLMemberAbilities>;
export type DisplayName = string;
export interface QueryComputePaymentConfig {
    isResponsible: boolean;
}
export declare const QueryComputePaymentConfig: S.Schema<QueryComputePaymentConfig>;
export interface ModelTrainingPaymentConfig {
    isResponsible: boolean;
}
export declare const ModelTrainingPaymentConfig: S.Schema<ModelTrainingPaymentConfig>;
export interface ModelInferencePaymentConfig {
    isResponsible: boolean;
}
export declare const ModelInferencePaymentConfig: S.Schema<ModelInferencePaymentConfig>;
export interface SyntheticDataGenerationPaymentConfig {
    isResponsible: boolean;
}
export declare const SyntheticDataGenerationPaymentConfig: S.Schema<SyntheticDataGenerationPaymentConfig>;
export interface MLPaymentConfig {
    modelTraining?: ModelTrainingPaymentConfig;
    modelInference?: ModelInferencePaymentConfig;
    syntheticDataGeneration?: SyntheticDataGenerationPaymentConfig;
}
export declare const MLPaymentConfig: S.Schema<MLPaymentConfig>;
export interface JobComputePaymentConfig {
    isResponsible: boolean;
}
export declare const JobComputePaymentConfig: S.Schema<JobComputePaymentConfig>;
export interface PaymentConfiguration {
    queryCompute: QueryComputePaymentConfig;
    machineLearning?: MLPaymentConfig;
    jobCompute?: JobComputePaymentConfig;
}
export declare const PaymentConfiguration: S.Schema<PaymentConfiguration>;
export interface MemberSpecification {
    accountId: string;
    memberAbilities: MemberAbility[];
    mlMemberAbilities?: MLMemberAbilities;
    displayName: string;
    paymentConfiguration?: PaymentConfiguration;
}
export declare const MemberSpecification: S.Schema<MemberSpecification>;
export type MemberList = MemberSpecification[];
export declare const MemberList: any;
export type CollaborationName = string;
export type CollaborationDescription = string;
export interface DataEncryptionMetadata {
    allowCleartext: boolean;
    allowDuplicates: boolean;
    allowJoinsOnColumnsWithDifferentNames: boolean;
    preserveNulls: boolean;
}
export declare const DataEncryptionMetadata: S.Schema<DataEncryptionMetadata>;
export type CollaborationQueryLogStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const CollaborationQueryLogStatus: any;
export type CollaborationJobLogStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const CollaborationJobLogStatus: any;
export type AnalyticsEngine = "SPARK" | "CLEAN_ROOMS_SQL" | (string & {});
export declare const AnalyticsEngine: any;
export type AutoApprovedChangeType = "ADD_MEMBER" | "GRANT_RECEIVE_RESULTS_ABILITY" | "REVOKE_RECEIVE_RESULTS_ABILITY" | "GRANT_EXPORT_QUERY_ANALYSIS_LOG_ABILITY" | "REVOKE_EXPORT_QUERY_ANALYSIS_LOG_ABILITY" | (string & {});
export declare const AutoApprovedChangeType: any;
export type AutoApprovedChangeTypeList = AutoApprovedChangeType[];
export declare const AutoApprovedChangeTypeList: any;
export type SupportedS3Region = "us-west-1" | "us-west-2" | "us-east-1" | "us-east-2" | "af-south-1" | "ap-east-1" | "ap-east-2" | "ap-south-2" | "ap-southeast-1" | "ap-southeast-2" | "ap-southeast-3" | "ap-southeast-5" | "ap-southeast-4" | "ap-southeast-7" | "ap-south-1" | "ap-northeast-3" | "ap-northeast-1" | "ap-northeast-2" | "ca-central-1" | "ca-west-1" | "eu-south-1" | "eu-west-3" | "eu-south-2" | "eu-central-2" | "eu-central-1" | "eu-north-1" | "eu-west-1" | "eu-west-2" | "me-south-1" | "me-central-1" | "il-central-1" | "sa-east-1" | "mx-central-1" | (string & {});
export declare const SupportedS3Region: any;
export type AllowedResultRegions = SupportedS3Region[];
export declare const AllowedResultRegions: any;
export interface CreateCollaborationInput {
    members: MemberSpecification[];
    name: string;
    description?: string;
    creatorMemberAbilities: MemberAbility[];
    creatorMLMemberAbilities?: MLMemberAbilities;
    creatorDisplayName: string;
    dataEncryptionMetadata?: DataEncryptionMetadata;
    queryLogStatus: CollaborationQueryLogStatus;
    jobLogStatus?: CollaborationJobLogStatus;
    tags?: {
        [key: string]: string | undefined;
    };
    creatorPaymentConfiguration?: PaymentConfiguration;
    analyticsEngine?: AnalyticsEngine;
    autoApprovedChangeRequestTypes?: AutoApprovedChangeType[];
    allowedResultRegions?: SupportedS3Region[];
    isMetricsEnabled?: boolean;
}
export declare const CreateCollaborationInput: S.Schema<CreateCollaborationInput>;
export type MemberStatus = string;
export interface Collaboration {
    id: string;
    arn: string;
    name: string;
    description?: string;
    creatorAccountId: string;
    creatorDisplayName: string;
    createTime: Date;
    updateTime: Date;
    memberStatus: string;
    membershipId?: string;
    membershipArn?: string;
    dataEncryptionMetadata?: DataEncryptionMetadata;
    queryLogStatus: CollaborationQueryLogStatus;
    jobLogStatus?: CollaborationJobLogStatus;
    analyticsEngine?: AnalyticsEngine;
    autoApprovedChangeTypes?: AutoApprovedChangeType[];
    allowedResultRegions?: SupportedS3Region[];
    isMetricsEnabled?: boolean;
}
export declare const Collaboration: S.Schema<Collaboration>;
export interface CreateCollaborationOutput {
    collaboration: Collaboration;
}
export declare const CreateCollaborationOutput: S.Schema<CreateCollaborationOutput>;
export type ChangeSpecificationType = "MEMBER" | "COLLABORATION" | (string & {});
export declare const ChangeSpecificationType: any;
export interface MemberChangeSpecification {
    accountId: string;
    memberAbilities: MemberAbility[];
    mlMemberAbilities?: MLMemberAbilities;
    paymentConfiguration?: PaymentConfiguration;
    displayName?: string;
}
export declare const MemberChangeSpecification: S.Schema<MemberChangeSpecification>;
export interface CollaborationChangeSpecification {
    autoApprovedChangeTypes?: AutoApprovedChangeType[];
}
export declare const CollaborationChangeSpecification: S.Schema<CollaborationChangeSpecification>;
export type ChangeSpecification = {
    member: MemberChangeSpecification;
    collaboration?: never;
} | {
    member?: never;
    collaboration: CollaborationChangeSpecification;
};
export declare const ChangeSpecification: any;
export interface ChangeInput {
    specificationType: ChangeSpecificationType;
    specification: ChangeSpecification;
}
export declare const ChangeInput: S.Schema<ChangeInput>;
export type ChangeInputList = ChangeInput[];
export declare const ChangeInputList: any;
export interface CreateCollaborationChangeRequestInput {
    collaborationIdentifier: string;
    changes: ChangeInput[];
}
export declare const CreateCollaborationChangeRequestInput: S.Schema<CreateCollaborationChangeRequestInput>;
export type ChangeRequestStatus = "PENDING" | "APPROVED" | "CANCELLED" | "DENIED" | "COMMITTED" | (string & {});
export declare const ChangeRequestStatus: any;
export type ChangeType = "ADD_MEMBER" | "GRANT_RECEIVE_RESULTS_ABILITY" | "REVOKE_RECEIVE_RESULTS_ABILITY" | "EDIT_AUTO_APPROVED_CHANGE_TYPES" | "ADD_PAYER_CANDIDATE" | "REMOVE_PAYER_CANDIDATE" | "GRANT_CAN_RECEIVE_MODEL_OUTPUT" | "GRANT_CAN_RECEIVE_INFERENCE_OUTPUT" | "REVOKE_CAN_RECEIVE_MODEL_OUTPUT" | "REVOKE_CAN_RECEIVE_INFERENCE_OUTPUT" | "GRANT_EXPORT_QUERY_ANALYSIS_LOG_ABILITY" | "REVOKE_EXPORT_QUERY_ANALYSIS_LOG_ABILITY" | (string & {});
export declare const ChangeType: any;
export type ChangeTypeList = ChangeType[];
export declare const ChangeTypeList: any;
export interface Change {
    specificationType: ChangeSpecificationType;
    specification: ChangeSpecification;
    types: ChangeType[];
}
export declare const Change: S.Schema<Change>;
export type ChangeList = Change[];
export declare const ChangeList: any;
export type ApprovalStatus = "APPROVED" | "DENIED" | "PENDING" | (string & {});
export declare const ApprovalStatus: any;
export interface ApprovalStatusDetails {
    status: ApprovalStatus;
}
export declare const ApprovalStatusDetails: S.Schema<ApprovalStatusDetails>;
export type ApprovalStatuses = {
    [key: string]: ApprovalStatusDetails | undefined;
};
export declare const ApprovalStatuses: any;
export interface CollaborationChangeRequest {
    id: string;
    collaborationId: string;
    createTime: Date;
    updateTime: Date;
    status: ChangeRequestStatus;
    isAutoApproved: boolean;
    changes: Change[];
    approvals?: {
        [key: string]: ApprovalStatusDetails | undefined;
    };
}
export declare const CollaborationChangeRequest: S.Schema<CollaborationChangeRequest>;
export interface CreateCollaborationChangeRequestOutput {
    collaborationChangeRequest: CollaborationChangeRequest;
}
export declare const CreateCollaborationChangeRequestOutput: S.Schema<CreateCollaborationChangeRequestOutput>;
export type ConfiguredAudienceModelArn = string;
export type ConfiguredAudienceModelAssociationName = string;
export interface CreateConfiguredAudienceModelAssociationInput {
    membershipIdentifier: string;
    configuredAudienceModelArn: string;
    configuredAudienceModelAssociationName: string;
    manageResourcePolicies: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
    description?: string;
}
export declare const CreateConfiguredAudienceModelAssociationInput: S.Schema<CreateConfiguredAudienceModelAssociationInput>;
export type ConfiguredAudienceModelAssociationIdentifier = string;
export type ConfiguredAudienceModelAssociationArn = string;
export interface ConfiguredAudienceModelAssociation {
    id: string;
    arn: string;
    configuredAudienceModelArn: string;
    membershipId: string;
    membershipArn: string;
    collaborationId: string;
    collaborationArn: string;
    name: string;
    manageResourcePolicies: boolean;
    description?: string;
    createTime: Date;
    updateTime: Date;
}
export declare const ConfiguredAudienceModelAssociation: S.Schema<ConfiguredAudienceModelAssociation>;
export interface CreateConfiguredAudienceModelAssociationOutput {
    configuredAudienceModelAssociation: ConfiguredAudienceModelAssociation;
}
export declare const CreateConfiguredAudienceModelAssociationOutput: S.Schema<CreateConfiguredAudienceModelAssociationOutput>;
export type CommercialRegion = "us-west-1" | "us-west-2" | "us-east-1" | "us-east-2" | "af-south-1" | "ap-east-1" | "ap-south-2" | "ap-southeast-1" | "ap-southeast-2" | "ap-southeast-3" | "ap-southeast-5" | "ap-southeast-4" | "ap-southeast-7" | "ap-south-1" | "ap-northeast-3" | "ap-northeast-1" | "ap-northeast-2" | "ca-central-1" | "ca-west-1" | "eu-south-1" | "eu-west-3" | "eu-south-2" | "eu-central-2" | "eu-central-1" | "eu-north-1" | "eu-west-1" | "eu-west-2" | "me-south-1" | "me-central-1" | "il-central-1" | "sa-east-1" | "mx-central-1" | "ap-east-2" | (string & {});
export declare const CommercialRegion: any;
export type GlueTableName = string;
export type GlueDatabaseName = string;
export interface GlueTableReference {
    region?: CommercialRegion;
    tableName: string;
    databaseName: string;
}
export declare const GlueTableReference: S.Schema<GlueTableReference>;
export type SecretsManagerArn = string;
export type SnowflakeAccountIdentifier = string;
export type SnowflakeDatabaseName = string;
export type SnowflakeTableName = string;
export type SnowflakeSchemaName = string;
export interface SnowflakeTableSchemaV1 {
    columnName: string;
    columnType: string;
}
export declare const SnowflakeTableSchemaV1: S.Schema<SnowflakeTableSchemaV1>;
export type SnowflakeTableSchemaList = SnowflakeTableSchemaV1[];
export declare const SnowflakeTableSchemaList: any;
export type SnowflakeTableSchema = {
    v1: SnowflakeTableSchemaV1[];
};
export declare const SnowflakeTableSchema: any;
export interface SnowflakeTableReference {
    secretArn: string;
    accountIdentifier: string;
    databaseName: string;
    tableName: string;
    schemaName: string;
    tableSchema: SnowflakeTableSchema;
}
export declare const SnowflakeTableReference: S.Schema<SnowflakeTableReference>;
export type AthenaWorkGroup = string;
export type AthenaOutputLocation = string;
export type AthenaDatabaseName = string;
export type AthenaTableName = string;
export type AthenaCatalogName = string;
export interface AthenaTableReference {
    region?: CommercialRegion;
    workGroup: string;
    outputLocation?: string;
    databaseName: string;
    tableName: string;
    catalogName?: string;
}
export declare const AthenaTableReference: S.Schema<AthenaTableReference>;
export type TableReference = {
    glue: GlueTableReference;
    snowflake?: never;
    athena?: never;
} | {
    glue?: never;
    snowflake: SnowflakeTableReference;
    athena?: never;
} | {
    glue?: never;
    snowflake?: never;
    athena: AthenaTableReference;
};
export declare const TableReference: any;
export type AllowedColumnList = string[];
export declare const AllowedColumnList: any;
export interface CreateConfiguredTableInput {
    name: string;
    description?: string;
    tableReference: TableReference;
    allowedColumns: string[];
    analysisMethod: AnalysisMethod;
    selectedAnalysisMethods?: SelectedAnalysisMethod[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateConfiguredTableInput: S.Schema<CreateConfiguredTableInput>;
export type ConfiguredTableArn = string;
export type ConfiguredTableAnalysisRuleType = "AGGREGATION" | "LIST" | "CUSTOM" | (string & {});
export declare const ConfiguredTableAnalysisRuleType: any;
export type ConfiguredTableAnalysisRuleTypeList = ConfiguredTableAnalysisRuleType[];
export declare const ConfiguredTableAnalysisRuleTypeList: any;
export interface ConfiguredTable {
    id: string;
    arn: string;
    name: string;
    description?: string;
    tableReference: TableReference;
    createTime: Date;
    updateTime: Date;
    analysisRuleTypes: ConfiguredTableAnalysisRuleType[];
    analysisMethod: AnalysisMethod;
    allowedColumns: string[];
    selectedAnalysisMethods?: SelectedAnalysisMethod[];
}
export declare const ConfiguredTable: S.Schema<ConfiguredTable>;
export interface CreateConfiguredTableOutput {
    configuredTable: ConfiguredTable;
}
export declare const CreateConfiguredTableOutput: S.Schema<CreateConfiguredTableOutput>;
export type ConfiguredTableIdentifier = string;
export type ConfiguredTableAnalysisRulePolicyV1 = {
    list: AnalysisRuleList;
    aggregation?: never;
    custom?: never;
} | {
    list?: never;
    aggregation: AnalysisRuleAggregation;
    custom?: never;
} | {
    list?: never;
    aggregation?: never;
    custom: AnalysisRuleCustom;
};
export declare const ConfiguredTableAnalysisRulePolicyV1: any;
export type ConfiguredTableAnalysisRulePolicy = {
    v1: ConfiguredTableAnalysisRulePolicyV1;
};
export declare const ConfiguredTableAnalysisRulePolicy: any;
export interface CreateConfiguredTableAnalysisRuleInput {
    configuredTableIdentifier: string;
    analysisRuleType: ConfiguredTableAnalysisRuleType;
    analysisRulePolicy: ConfiguredTableAnalysisRulePolicy;
}
export declare const CreateConfiguredTableAnalysisRuleInput: S.Schema<CreateConfiguredTableAnalysisRuleInput>;
export interface ConfiguredTableAnalysisRule {
    configuredTableId: string;
    configuredTableArn: string;
    policy: ConfiguredTableAnalysisRulePolicy;
    type: ConfiguredTableAnalysisRuleType;
    createTime: Date;
    updateTime: Date;
}
export declare const ConfiguredTableAnalysisRule: S.Schema<ConfiguredTableAnalysisRule>;
export interface CreateConfiguredTableAnalysisRuleOutput {
    analysisRule: ConfiguredTableAnalysisRule;
}
export declare const CreateConfiguredTableAnalysisRuleOutput: S.Schema<CreateConfiguredTableAnalysisRuleOutput>;
export interface CreateConfiguredTableAssociationInput {
    name: string;
    description?: string;
    membershipIdentifier: string;
    configuredTableIdentifier: string;
    roleArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateConfiguredTableAssociationInput: S.Schema<CreateConfiguredTableAssociationInput>;
export type ConfiguredTableAssociationArn = string;
export type ConfiguredTableAssociationAnalysisRuleType = "AGGREGATION" | "LIST" | "CUSTOM" | (string & {});
export declare const ConfiguredTableAssociationAnalysisRuleType: any;
export type ConfiguredTableAssociationAnalysisRuleTypeList = ConfiguredTableAssociationAnalysisRuleType[];
export declare const ConfiguredTableAssociationAnalysisRuleTypeList: any;
export type ChildResourceType = "INTERMEDIATE_TABLE" | (string & {});
export declare const ChildResourceType: any;
export type ResourceStatus = "CREATED" | "POPULATE_STARTED" | "POPULATE_SUCCESS" | "POPULATE_FAILED" | "DISALLOWED_BY_DATA_PROVIDER" | "BASE_TABLE_REMOVED" | "RETENTION_PERIOD_EXPIRED" | (string & {});
export declare const ResourceStatus: any;
export interface ChildResource {
    resourceId?: string;
    resourceType: ChildResourceType;
    resourceName: string;
    ownerAccountId: string;
    resourceStatus?: ResourceStatus;
}
export declare const ChildResource: S.Schema<ChildResource>;
export type ChildResourceList = ChildResource[];
export declare const ChildResourceList: any;
export interface ConfiguredTableAssociation {
    arn: string;
    id: string;
    configuredTableId: string;
    configuredTableArn: string;
    membershipId: string;
    membershipArn: string;
    roleArn: string;
    name: string;
    description?: string;
    analysisRuleTypes?: ConfiguredTableAssociationAnalysisRuleType[];
    createTime: Date;
    updateTime: Date;
    childResources?: ChildResource[];
}
export declare const ConfiguredTableAssociation: S.Schema<ConfiguredTableAssociation>;
export interface CreateConfiguredTableAssociationOutput {
    configuredTableAssociation: ConfiguredTableAssociation;
}
export declare const CreateConfiguredTableAssociationOutput: S.Schema<CreateConfiguredTableAssociationOutput>;
export type ConfiguredTableAssociationIdentifier = string;
export interface CreateConfiguredTableAssociationAnalysisRuleInput {
    membershipIdentifier: string;
    configuredTableAssociationIdentifier: string;
    analysisRuleType: ConfiguredTableAssociationAnalysisRuleType;
    analysisRulePolicy: ConfiguredTableAssociationAnalysisRulePolicy;
}
export declare const CreateConfiguredTableAssociationAnalysisRuleInput: S.Schema<CreateConfiguredTableAssociationAnalysisRuleInput>;
export interface ConfiguredTableAssociationAnalysisRule {
    membershipIdentifier: string;
    configuredTableAssociationId: string;
    configuredTableAssociationArn: string;
    policy: ConfiguredTableAssociationAnalysisRulePolicy;
    type: ConfiguredTableAssociationAnalysisRuleType;
    createTime: Date;
    updateTime: Date;
}
export declare const ConfiguredTableAssociationAnalysisRule: S.Schema<ConfiguredTableAssociationAnalysisRule>;
export interface CreateConfiguredTableAssociationAnalysisRuleOutput {
    analysisRule: ConfiguredTableAssociationAnalysisRule;
}
export declare const CreateConfiguredTableAssociationAnalysisRuleOutput: S.Schema<CreateConfiguredTableAssociationAnalysisRuleOutput>;
export type IdMappingTableInputReferenceArn = string;
export interface IdMappingTableInputReferenceConfig {
    inputReferenceArn: string;
    manageResourcePolicies: boolean;
}
export declare const IdMappingTableInputReferenceConfig: S.Schema<IdMappingTableInputReferenceConfig>;
export type KMSKeyArn = string;
export interface CreateIdMappingTableInput {
    membershipIdentifier: string;
    name: string;
    description?: string;
    inputReferenceConfig: IdMappingTableInputReferenceConfig;
    tags?: {
        [key: string]: string | undefined;
    };
    kmsKeyArn?: string;
}
export declare const CreateIdMappingTableInput: S.Schema<CreateIdMappingTableInput>;
export type IdMappingTableArn = string;
export interface IdMappingTableInputReferenceProperties {
    idMappingTableInputSource: IdMappingTableInputSource[];
}
export declare const IdMappingTableInputReferenceProperties: S.Schema<IdMappingTableInputReferenceProperties>;
export interface IdMappingTable {
    id: string;
    arn: string;
    inputReferenceConfig: IdMappingTableInputReferenceConfig;
    membershipId: string;
    membershipArn: string;
    collaborationId: string;
    collaborationArn: string;
    description?: string;
    name: string;
    createTime: Date;
    updateTime: Date;
    inputReferenceProperties: IdMappingTableInputReferenceProperties;
    kmsKeyArn?: string;
    childResources?: ChildResource[];
}
export declare const IdMappingTable: S.Schema<IdMappingTable>;
export interface CreateIdMappingTableOutput {
    idMappingTable: IdMappingTable;
}
export declare const CreateIdMappingTableOutput: S.Schema<CreateIdMappingTableOutput>;
export type IdNamespaceAssociationInputReferenceArn = string;
export interface IdNamespaceAssociationInputReferenceConfig {
    inputReferenceArn: string;
    manageResourcePolicies: boolean;
}
export declare const IdNamespaceAssociationInputReferenceConfig: S.Schema<IdNamespaceAssociationInputReferenceConfig>;
export type GenericResourceName = string;
export interface IdMappingConfig {
    allowUseAsDimensionColumn: boolean;
}
export declare const IdMappingConfig: S.Schema<IdMappingConfig>;
export interface CreateIdNamespaceAssociationInput {
    membershipIdentifier: string;
    inputReferenceConfig: IdNamespaceAssociationInputReferenceConfig;
    tags?: {
        [key: string]: string | undefined;
    };
    name: string;
    description?: string;
    idMappingConfig?: IdMappingConfig;
}
export declare const CreateIdNamespaceAssociationInput: S.Schema<CreateIdNamespaceAssociationInput>;
export type IdNamespaceAssociationIdentifier = string;
export type IdNamespaceAssociationArn = string;
export type IdMappingWorkflowsSupported = any[];
export declare const IdMappingWorkflowsSupported: any;
export interface IdNamespaceAssociationInputReferenceProperties {
    idNamespaceType: IdNamespaceType;
    idMappingWorkflowsSupported: any[];
}
export declare const IdNamespaceAssociationInputReferenceProperties: S.Schema<IdNamespaceAssociationInputReferenceProperties>;
export interface IdNamespaceAssociation {
    id: string;
    arn: string;
    membershipId: string;
    membershipArn: string;
    collaborationId: string;
    collaborationArn: string;
    name: string;
    description?: string;
    createTime: Date;
    updateTime: Date;
    inputReferenceConfig: IdNamespaceAssociationInputReferenceConfig;
    inputReferenceProperties: IdNamespaceAssociationInputReferenceProperties;
    idMappingConfig?: IdMappingConfig;
}
export declare const IdNamespaceAssociation: S.Schema<IdNamespaceAssociation>;
export interface CreateIdNamespaceAssociationOutput {
    idNamespaceAssociation: IdNamespaceAssociation;
}
export declare const CreateIdNamespaceAssociationOutput: S.Schema<CreateIdNamespaceAssociationOutput>;
export interface PopulationAnalysisSqlParameters {
    queryString?: string;
    analysisTemplateArn?: string;
}
export declare const PopulationAnalysisSqlParameters: S.Schema<PopulationAnalysisSqlParameters>;
export type PopulationAnalysisConfiguration = {
    sqlParameters: PopulationAnalysisSqlParameters;
};
export declare const PopulationAnalysisConfiguration: any;
export interface CreateIntermediateTableInput {
    membershipIdentifier: string;
    name: string;
    description?: string;
    populationAnalysisConfiguration: PopulationAnalysisConfiguration;
    kmsKeyArn?: string;
    retentionInDays?: number;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateIntermediateTableInput: S.Schema<CreateIntermediateTableInput>;
export type IntermediateTableArn = string;
export type IntermediateTableStatus = "CREATED" | "POPULATE_STARTED" | "POPULATE_SUCCESS" | "POPULATE_FAILED" | "DISALLOWED_BY_DATA_PROVIDER" | "BASE_TABLE_REMOVED" | "RETENTION_PERIOD_EXPIRED" | (string & {});
export declare const IntermediateTableStatus: any;
export type BaseTableDependencyType = "TABLE" | "INTERMEDIATE_TABLE" | "ID_MAPPING_TABLE" | (string & {});
export declare const BaseTableDependencyType: any;
export type BaseTableParentType = "DIRECT" | "INDIRECT" | (string & {});
export declare const BaseTableParentType: any;
export interface IntermediateTableDependency {
    id: string;
    name: string;
    type: BaseTableDependencyType;
    parentType: BaseTableParentType;
    creatorAccountId: string;
}
export declare const IntermediateTableDependency: S.Schema<IntermediateTableDependency>;
export type DependencyList = IntermediateTableDependency[];
export declare const DependencyList: any;
export type AnalysisIdentifier = string;
export type PopulateIntermediateTableAnalysisType = "QUERY" | (string & {});
export declare const PopulateIntermediateTableAnalysisType: any;
export type ParameterMap = {
    [key: string]: string | undefined;
};
export declare const ParameterMap: any;
export interface InheritedAdditionalAnalysesSource {
    name: string;
    id: string;
    type: BaseTableDependencyType;
    value: AdditionalAnalyses;
    sourceAccountId: string;
}
export declare const InheritedAdditionalAnalysesSource: S.Schema<InheritedAdditionalAnalysesSource>;
export type InheritedAdditionalAnalysesSourceList = InheritedAdditionalAnalysesSource[];
export declare const InheritedAdditionalAnalysesSourceList: any;
export interface InheritedAdditionalAnalyses {
    value: AdditionalAnalyses;
    sources: InheritedAdditionalAnalysesSource[];
}
export declare const InheritedAdditionalAnalyses: S.Schema<InheritedAdditionalAnalyses>;
export interface InheritedAllowedAdditionalAnalysesSource {
    name: string;
    id: string;
    type: BaseTableDependencyType;
    value: string[];
    sourceAccountId: string;
}
export declare const InheritedAllowedAdditionalAnalysesSource: S.Schema<InheritedAllowedAdditionalAnalysesSource>;
export type InheritedAllowedAdditionalAnalysesSourceList = InheritedAllowedAdditionalAnalysesSource[];
export declare const InheritedAllowedAdditionalAnalysesSourceList: any;
export interface InheritedAllowedAdditionalAnalyses {
    value: string[];
    sources: InheritedAllowedAdditionalAnalysesSource[];
}
export declare const InheritedAllowedAdditionalAnalyses: S.Schema<InheritedAllowedAdditionalAnalyses>;
export type AccountIdList = string[];
export declare const AccountIdList: any;
export interface InheritedAllowedResultReceiversSource {
    name: string;
    id: string;
    type: BaseTableDependencyType;
    value: string[];
    sourceAccountId: string;
}
export declare const InheritedAllowedResultReceiversSource: S.Schema<InheritedAllowedResultReceiversSource>;
export type InheritedAllowedResultReceiversSourceList = InheritedAllowedResultReceiversSource[];
export declare const InheritedAllowedResultReceiversSourceList: any;
export interface InheritedAllowedResultReceivers {
    value: string[];
    sources: InheritedAllowedResultReceiversSource[];
}
export declare const InheritedAllowedResultReceivers: S.Schema<InheritedAllowedResultReceivers>;
export interface ColumnLineageEntry {
    column: string;
    sourceColumn: string;
    sourceName: string;
    sourceId: string;
    sourceType: BaseTableDependencyType;
    sourceAccountId: string;
}
export declare const ColumnLineageEntry: S.Schema<ColumnLineageEntry>;
export type ColumnLineageList = ColumnLineageEntry[];
export declare const ColumnLineageList: any;
export interface InheritedDisallowedOutputColumns {
    value: string[];
    columnLineage: ColumnLineageEntry[];
}
export declare const InheritedDisallowedOutputColumns: S.Schema<InheritedDisallowedOutputColumns>;
export interface IntermediateTableInheritedConstraints {
    additionalAnalyses?: InheritedAdditionalAnalyses;
    allowedAdditionalAnalyses?: InheritedAllowedAdditionalAnalyses;
    allowedResultReceivers?: InheritedAllowedResultReceivers;
    disallowedOutputColumns?: InheritedDisallowedOutputColumns;
}
export declare const IntermediateTableInheritedConstraints: S.Schema<IntermediateTableInheritedConstraints>;
export interface IntermediateTableActiveVersion {
    versionId: string;
    analysisId: string;
    analysisType: PopulateIntermediateTableAnalysisType;
    kmsKeyArn?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
    inheritedConstraints: IntermediateTableInheritedConstraints;
    expirationTime?: Date;
}
export declare const IntermediateTableActiveVersion: S.Schema<IntermediateTableActiveVersion>;
export type IntermediateTableAnalysisRuleType = "CUSTOM" | (string & {});
export declare const IntermediateTableAnalysisRuleType: any;
export type IntermediateTableAnalysisRuleTypeList = IntermediateTableAnalysisRuleType[];
export declare const IntermediateTableAnalysisRuleTypeList: any;
export interface IntermediateTableSchema {
    columns: Column[];
}
export declare const IntermediateTableSchema: S.Schema<IntermediateTableSchema>;
export interface IntermediateTable {
    id: string;
    arn: string;
    name: string;
    description?: string;
    membershipArn: string;
    membershipId: string;
    collaborationArn: string;
    collaborationId: string;
    childResources?: ChildResource[];
    createTime: Date;
    updateTime: Date;
    status: IntermediateTableStatus;
    statusReason?: string;
    kmsKeyArn?: string;
    populationAnalysisConfiguration: PopulationAnalysisConfiguration;
    retentionInDays?: number;
    tableDependencies?: IntermediateTableDependency[];
    intermediateTableVersion?: IntermediateTableActiveVersion;
    analysisRuleTypes?: IntermediateTableAnalysisRuleType[];
    schema?: IntermediateTableSchema;
}
export declare const IntermediateTable: S.Schema<IntermediateTable>;
export interface CreateIntermediateTableOutput {
    intermediateTable: IntermediateTable;
}
export declare const CreateIntermediateTableOutput: S.Schema<CreateIntermediateTableOutput>;
export type IntermediateTableIdentifier = string;
export interface IntermediateTableAnalysisRuleCustom {
    allowedAnalyses?: string[];
    additionalAnalyses?: AdditionalAnalyses;
    allowedAdditionalAnalyses?: string[];
    allowedAnalysisProviders?: string[];
    allowedResultReceivers?: string[];
    differentialPrivacy?: DifferentialPrivacyConfiguration;
    disallowedOutputColumns?: string[];
    aggregationThresholds?: AggregationThreshold[];
    comparisonControls?: ComparisonControls;
}
export declare const IntermediateTableAnalysisRuleCustom: S.Schema<IntermediateTableAnalysisRuleCustom>;
export type IntermediateTableAnalysisRulePolicyV1 = {
    custom: IntermediateTableAnalysisRuleCustom;
};
export declare const IntermediateTableAnalysisRulePolicyV1: any;
export type IntermediateTableAnalysisRulePolicy = {
    v1: IntermediateTableAnalysisRulePolicyV1;
};
export declare const IntermediateTableAnalysisRulePolicy: any;
export interface CreateIntermediateTableAnalysisRuleInput {
    membershipIdentifier: string;
    intermediateTableIdentifier: string;
    analysisRuleType: IntermediateTableAnalysisRuleType;
    analysisRulePolicy: IntermediateTableAnalysisRulePolicy;
}
export declare const CreateIntermediateTableAnalysisRuleInput: S.Schema<CreateIntermediateTableAnalysisRuleInput>;
export interface IntermediateTableAnalysisRule {
    intermediateTableIdentifier: string;
    intermediateTableArn: string;
    analysisRulePolicy: IntermediateTableAnalysisRulePolicy;
    analysisRuleType: IntermediateTableAnalysisRuleType;
    createTime: Date;
    updateTime: Date;
}
export declare const IntermediateTableAnalysisRule: S.Schema<IntermediateTableAnalysisRule>;
export interface CreateIntermediateTableAnalysisRuleOutput {
    analysisRule: IntermediateTableAnalysisRule;
}
export declare const CreateIntermediateTableAnalysisRuleOutput: S.Schema<CreateIntermediateTableAnalysisRuleOutput>;
export type MembershipQueryLogStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const MembershipQueryLogStatus: any;
export type MembershipJobLogStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const MembershipJobLogStatus: any;
export type ResultFormat = "CSV" | "PARQUET" | (string & {});
export declare const ResultFormat: any;
export type KeyPrefix = string;
export interface ProtectedQueryS3OutputConfiguration {
    resultFormat: ResultFormat;
    bucket: string;
    keyPrefix?: string;
    singleFileOutput?: boolean;
}
export declare const ProtectedQueryS3OutputConfiguration: S.Schema<ProtectedQueryS3OutputConfiguration>;
export type MembershipProtectedQueryOutputConfiguration = {
    s3: ProtectedQueryS3OutputConfiguration;
};
export declare const MembershipProtectedQueryOutputConfiguration: any;
export interface MembershipProtectedQueryResultConfiguration {
    outputConfiguration: MembershipProtectedQueryOutputConfiguration;
    roleArn?: string;
}
export declare const MembershipProtectedQueryResultConfiguration: S.Schema<MembershipProtectedQueryResultConfiguration>;
export interface ProtectedJobS3OutputConfigurationInput {
    bucket: string;
    keyPrefix?: string;
}
export declare const ProtectedJobS3OutputConfigurationInput: S.Schema<ProtectedJobS3OutputConfigurationInput>;
export type MembershipProtectedJobOutputConfiguration = {
    s3: ProtectedJobS3OutputConfigurationInput;
};
export declare const MembershipProtectedJobOutputConfiguration: any;
export interface MembershipProtectedJobResultConfiguration {
    outputConfiguration: MembershipProtectedJobOutputConfiguration;
    roleArn: string;
}
export declare const MembershipProtectedJobResultConfiguration: S.Schema<MembershipProtectedJobResultConfiguration>;
export interface MembershipQueryComputePaymentConfig {
    isResponsible: boolean;
}
export declare const MembershipQueryComputePaymentConfig: S.Schema<MembershipQueryComputePaymentConfig>;
export interface MembershipModelTrainingPaymentConfig {
    isResponsible: boolean;
}
export declare const MembershipModelTrainingPaymentConfig: S.Schema<MembershipModelTrainingPaymentConfig>;
export interface MembershipModelInferencePaymentConfig {
    isResponsible: boolean;
}
export declare const MembershipModelInferencePaymentConfig: S.Schema<MembershipModelInferencePaymentConfig>;
export interface MembershipSyntheticDataGenerationPaymentConfig {
    isResponsible: boolean;
}
export declare const MembershipSyntheticDataGenerationPaymentConfig: S.Schema<MembershipSyntheticDataGenerationPaymentConfig>;
export interface MembershipMLPaymentConfig {
    modelTraining?: MembershipModelTrainingPaymentConfig;
    modelInference?: MembershipModelInferencePaymentConfig;
    syntheticDataGeneration?: MembershipSyntheticDataGenerationPaymentConfig;
}
export declare const MembershipMLPaymentConfig: S.Schema<MembershipMLPaymentConfig>;
export interface MembershipJobComputePaymentConfig {
    isResponsible: boolean;
}
export declare const MembershipJobComputePaymentConfig: S.Schema<MembershipJobComputePaymentConfig>;
export interface MembershipPaymentConfiguration {
    queryCompute: MembershipQueryComputePaymentConfig;
    machineLearning?: MembershipMLPaymentConfig;
    jobCompute?: MembershipJobComputePaymentConfig;
}
export declare const MembershipPaymentConfiguration: S.Schema<MembershipPaymentConfiguration>;
export interface CreateMembershipInput {
    collaborationIdentifier: string;
    queryLogStatus: MembershipQueryLogStatus;
    jobLogStatus?: MembershipJobLogStatus;
    tags?: {
        [key: string]: string | undefined;
    };
    defaultResultConfiguration?: MembershipProtectedQueryResultConfiguration;
    defaultJobResultConfiguration?: MembershipProtectedJobResultConfiguration;
    paymentConfiguration?: MembershipPaymentConfiguration;
    isMetricsEnabled?: boolean;
}
export declare const CreateMembershipInput: S.Schema<CreateMembershipInput>;
export type MembershipStatus = string;
export interface Membership {
    id: string;
    arn: string;
    collaborationArn: string;
    collaborationId: string;
    collaborationCreatorAccountId: string;
    collaborationCreatorDisplayName: string;
    collaborationName: string;
    createTime: Date;
    updateTime: Date;
    status: string;
    memberAbilities: MemberAbility[];
    mlMemberAbilities?: MLMemberAbilities;
    queryLogStatus: MembershipQueryLogStatus;
    jobLogStatus?: MembershipJobLogStatus;
    defaultResultConfiguration?: MembershipProtectedQueryResultConfiguration;
    defaultJobResultConfiguration?: MembershipProtectedJobResultConfiguration;
    paymentConfiguration: MembershipPaymentConfiguration;
    isMetricsEnabled?: boolean;
}
export declare const Membership: S.Schema<Membership>;
export interface CreateMembershipOutput {
    membership: Membership;
}
export declare const CreateMembershipOutput: S.Schema<CreateMembershipOutput>;
export type PrivacyBudgetTemplateAutoRefresh = "CALENDAR_MONTH" | "NONE" | (string & {});
export declare const PrivacyBudgetTemplateAutoRefresh: any;
export type PrivacyBudgetType = "DIFFERENTIAL_PRIVACY" | "ACCESS_BUDGET" | (string & {});
export declare const PrivacyBudgetType: any;
export type Epsilon = number;
export type UsersNoisePerQuery = number;
export interface DifferentialPrivacyTemplateParametersInput {
    epsilon: number;
    usersNoisePerQuery: number;
}
export declare const DifferentialPrivacyTemplateParametersInput: S.Schema<DifferentialPrivacyTemplateParametersInput>;
export type AccessBudgetType = "CALENDAR_DAY" | "CALENDAR_MONTH" | "CALENDAR_WEEK" | "LIFETIME" | (string & {});
export declare const AccessBudgetType: any;
export type Budget = number;
export type AutoRefreshMode = "ENABLED" | "DISABLED" | (string & {});
export declare const AutoRefreshMode: any;
export interface BudgetParameter {
    type: AccessBudgetType;
    budget: number;
    autoRefresh?: AutoRefreshMode;
}
export declare const BudgetParameter: S.Schema<BudgetParameter>;
export type BudgetParameters = BudgetParameter[];
export declare const BudgetParameters: any;
export type BudgetedResourceArn = string;
export interface AccessBudgetsPrivacyTemplateParametersInput {
    budgetParameters: BudgetParameter[];
    resourceArn: string;
}
export declare const AccessBudgetsPrivacyTemplateParametersInput: S.Schema<AccessBudgetsPrivacyTemplateParametersInput>;
export type PrivacyBudgetTemplateParametersInput = {
    differentialPrivacy: DifferentialPrivacyTemplateParametersInput;
    accessBudget?: never;
} | {
    differentialPrivacy?: never;
    accessBudget: AccessBudgetsPrivacyTemplateParametersInput;
};
export declare const PrivacyBudgetTemplateParametersInput: any;
export interface CreatePrivacyBudgetTemplateInput {
    membershipIdentifier: string;
    autoRefresh?: PrivacyBudgetTemplateAutoRefresh;
    privacyBudgetType: PrivacyBudgetType;
    parameters: PrivacyBudgetTemplateParametersInput;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePrivacyBudgetTemplateInput: S.Schema<CreatePrivacyBudgetTemplateInput>;
export type PrivacyBudgetTemplateIdentifier = string;
export type PrivacyBudgetTemplateArn = string;
export interface DifferentialPrivacyTemplateParametersOutput {
    epsilon: number;
    usersNoisePerQuery: number;
}
export declare const DifferentialPrivacyTemplateParametersOutput: S.Schema<DifferentialPrivacyTemplateParametersOutput>;
export interface AccessBudgetsPrivacyTemplateParametersOutput {
    budgetParameters: BudgetParameter[];
    resourceArn: string;
}
export declare const AccessBudgetsPrivacyTemplateParametersOutput: S.Schema<AccessBudgetsPrivacyTemplateParametersOutput>;
export type PrivacyBudgetTemplateParametersOutput = {
    differentialPrivacy: DifferentialPrivacyTemplateParametersOutput;
    accessBudget?: never;
} | {
    differentialPrivacy?: never;
    accessBudget: AccessBudgetsPrivacyTemplateParametersOutput;
};
export declare const PrivacyBudgetTemplateParametersOutput: any;
export interface PrivacyBudgetTemplate {
    id: string;
    arn: string;
    membershipId: string;
    membershipArn: string;
    collaborationId: string;
    collaborationArn: string;
    createTime: Date;
    updateTime: Date;
    privacyBudgetType: PrivacyBudgetType;
    autoRefresh: PrivacyBudgetTemplateAutoRefresh;
    parameters: PrivacyBudgetTemplateParametersOutput;
}
export declare const PrivacyBudgetTemplate: S.Schema<PrivacyBudgetTemplate>;
export interface CreatePrivacyBudgetTemplateOutput {
    privacyBudgetTemplate: PrivacyBudgetTemplate;
}
export declare const CreatePrivacyBudgetTemplateOutput: S.Schema<CreatePrivacyBudgetTemplateOutput>;
export interface DeleteAnalysisTemplateInput {
    membershipIdentifier: string;
    analysisTemplateIdentifier: string;
}
export declare const DeleteAnalysisTemplateInput: S.Schema<DeleteAnalysisTemplateInput>;
export interface DeleteAnalysisTemplateOutput {
}
export declare const DeleteAnalysisTemplateOutput: S.Schema<DeleteAnalysisTemplateOutput>;
export interface DeleteCollaborationInput {
    collaborationIdentifier: string;
}
export declare const DeleteCollaborationInput: S.Schema<DeleteCollaborationInput>;
export interface DeleteCollaborationOutput {
}
export declare const DeleteCollaborationOutput: S.Schema<DeleteCollaborationOutput>;
export interface DeleteConfiguredAudienceModelAssociationInput {
    configuredAudienceModelAssociationIdentifier: string;
    membershipIdentifier: string;
}
export declare const DeleteConfiguredAudienceModelAssociationInput: S.Schema<DeleteConfiguredAudienceModelAssociationInput>;
export interface DeleteConfiguredAudienceModelAssociationOutput {
}
export declare const DeleteConfiguredAudienceModelAssociationOutput: S.Schema<DeleteConfiguredAudienceModelAssociationOutput>;
export interface DeleteConfiguredTableInput {
    configuredTableIdentifier: string;
}
export declare const DeleteConfiguredTableInput: S.Schema<DeleteConfiguredTableInput>;
export interface DeleteConfiguredTableOutput {
}
export declare const DeleteConfiguredTableOutput: S.Schema<DeleteConfiguredTableOutput>;
export interface DeleteConfiguredTableAnalysisRuleInput {
    configuredTableIdentifier: string;
    analysisRuleType: ConfiguredTableAnalysisRuleType;
}
export declare const DeleteConfiguredTableAnalysisRuleInput: S.Schema<DeleteConfiguredTableAnalysisRuleInput>;
export interface DeleteConfiguredTableAnalysisRuleOutput {
}
export declare const DeleteConfiguredTableAnalysisRuleOutput: S.Schema<DeleteConfiguredTableAnalysisRuleOutput>;
export interface DeleteConfiguredTableAssociationInput {
    configuredTableAssociationIdentifier: string;
    membershipIdentifier: string;
}
export declare const DeleteConfiguredTableAssociationInput: S.Schema<DeleteConfiguredTableAssociationInput>;
export interface DeleteConfiguredTableAssociationOutput {
}
export declare const DeleteConfiguredTableAssociationOutput: S.Schema<DeleteConfiguredTableAssociationOutput>;
export interface DeleteConfiguredTableAssociationAnalysisRuleInput {
    membershipIdentifier: string;
    configuredTableAssociationIdentifier: string;
    analysisRuleType: ConfiguredTableAssociationAnalysisRuleType;
}
export declare const DeleteConfiguredTableAssociationAnalysisRuleInput: S.Schema<DeleteConfiguredTableAssociationAnalysisRuleInput>;
export interface DeleteConfiguredTableAssociationAnalysisRuleOutput {
}
export declare const DeleteConfiguredTableAssociationAnalysisRuleOutput: S.Schema<DeleteConfiguredTableAssociationAnalysisRuleOutput>;
export interface DeleteIdMappingTableInput {
    idMappingTableIdentifier: string;
    membershipIdentifier: string;
}
export declare const DeleteIdMappingTableInput: S.Schema<DeleteIdMappingTableInput>;
export interface DeleteIdMappingTableOutput {
}
export declare const DeleteIdMappingTableOutput: S.Schema<DeleteIdMappingTableOutput>;
export interface DeleteIdNamespaceAssociationInput {
    idNamespaceAssociationIdentifier: string;
    membershipIdentifier: string;
}
export declare const DeleteIdNamespaceAssociationInput: S.Schema<DeleteIdNamespaceAssociationInput>;
export interface DeleteIdNamespaceAssociationOutput {
}
export declare const DeleteIdNamespaceAssociationOutput: S.Schema<DeleteIdNamespaceAssociationOutput>;
export interface DeleteIntermediateTableInput {
    membershipIdentifier: string;
    intermediateTableIdentifier: string;
}
export declare const DeleteIntermediateTableInput: S.Schema<DeleteIntermediateTableInput>;
export interface DeleteIntermediateTableOutput {
}
export declare const DeleteIntermediateTableOutput: S.Schema<DeleteIntermediateTableOutput>;
export interface DeleteIntermediateTableAnalysisRuleInput {
    membershipIdentifier: string;
    intermediateTableIdentifier: string;
    analysisRuleType: IntermediateTableAnalysisRuleType;
}
export declare const DeleteIntermediateTableAnalysisRuleInput: S.Schema<DeleteIntermediateTableAnalysisRuleInput>;
export interface DeleteIntermediateTableAnalysisRuleOutput {
}
export declare const DeleteIntermediateTableAnalysisRuleOutput: S.Schema<DeleteIntermediateTableAnalysisRuleOutput>;
export interface DeleteMemberInput {
    collaborationIdentifier: string;
    accountId: string;
}
export declare const DeleteMemberInput: S.Schema<DeleteMemberInput>;
export interface DeleteMemberOutput {
}
export declare const DeleteMemberOutput: S.Schema<DeleteMemberOutput>;
export interface DeleteMembershipInput {
    membershipIdentifier: string;
}
export declare const DeleteMembershipInput: S.Schema<DeleteMembershipInput>;
export interface DeleteMembershipOutput {
}
export declare const DeleteMembershipOutput: S.Schema<DeleteMembershipOutput>;
export interface DeletePrivacyBudgetTemplateInput {
    membershipIdentifier: string;
    privacyBudgetTemplateIdentifier: string;
}
export declare const DeletePrivacyBudgetTemplateInput: S.Schema<DeletePrivacyBudgetTemplateInput>;
export interface DeletePrivacyBudgetTemplateOutput {
}
export declare const DeletePrivacyBudgetTemplateOutput: S.Schema<DeletePrivacyBudgetTemplateOutput>;
export interface DisallowIntermediateTableInput {
    membershipIdentifier: string;
    intermediateTableName: string;
    includeDescendants?: boolean;
}
export declare const DisallowIntermediateTableInput: S.Schema<DisallowIntermediateTableInput>;
export interface DisallowIntermediateTableOutput {
}
export declare const DisallowIntermediateTableOutput: S.Schema<DisallowIntermediateTableOutput>;
export type AnalysisLogExportIdentifier = string;
export interface GetAnalysisLogExportInput {
    membershipIdentifier: string;
    analysisLogExportIdentifier: string;
}
export declare const GetAnalysisLogExportInput: S.Schema<GetAnalysisLogExportInput>;
export type LogExportAnalysisType = "PROTECTED_QUERY" | (string & {});
export declare const LogExportAnalysisType: any;
export type AnalysisLogExportStatus = "IN_PROGRESS" | "SUCCESS" | "FAILED" | (string & {});
export declare const AnalysisLogExportStatus: any;
export interface AnalysisLogExportS3OutputConfiguration {
    bucket: string;
    keyPrefix?: string;
}
export declare const AnalysisLogExportS3OutputConfiguration: S.Schema<AnalysisLogExportS3OutputConfiguration>;
export interface AnalysisLogExportOutputConfiguration {
    s3: AnalysisLogExportS3OutputConfiguration;
}
export declare const AnalysisLogExportOutputConfiguration: S.Schema<AnalysisLogExportOutputConfiguration>;
export interface AnalysisLogExportResultConfiguration {
    outputConfiguration: AnalysisLogExportOutputConfiguration;
}
export declare const AnalysisLogExportResultConfiguration: S.Schema<AnalysisLogExportResultConfiguration>;
export interface AnalysisLogExportError {
    code: string;
    message: string;
}
export declare const AnalysisLogExportError: S.Schema<AnalysisLogExportError>;
export interface AnalysisLogExport {
    analysisLogExportId: string;
    analysisId: string;
    analysisType: LogExportAnalysisType;
    membershipId: string;
    status: AnalysisLogExportStatus;
    resultConfiguration: AnalysisLogExportResultConfiguration;
    createTime: Date;
    updateTime: Date;
    error?: AnalysisLogExportError;
}
export declare const AnalysisLogExport: S.Schema<AnalysisLogExport>;
export interface GetAnalysisLogExportOutput {
    analysisLogExport: AnalysisLogExport;
}
export declare const GetAnalysisLogExportOutput: S.Schema<GetAnalysisLogExportOutput>;
export interface GetAnalysisTemplateInput {
    membershipIdentifier: string;
    analysisTemplateIdentifier: string;
}
export declare const GetAnalysisTemplateInput: S.Schema<GetAnalysisTemplateInput>;
export interface GetAnalysisTemplateOutput {
    analysisTemplate: AnalysisTemplate;
}
export declare const GetAnalysisTemplateOutput: S.Schema<GetAnalysisTemplateOutput>;
export interface GetCollaborationInput {
    collaborationIdentifier: string;
}
export declare const GetCollaborationInput: S.Schema<GetCollaborationInput>;
export interface GetCollaborationOutput {
    collaboration: Collaboration;
}
export declare const GetCollaborationOutput: S.Schema<GetCollaborationOutput>;
export interface GetCollaborationAnalysisTemplateInput {
    collaborationIdentifier: string;
    analysisTemplateArn: string;
}
export declare const GetCollaborationAnalysisTemplateInput: S.Schema<GetCollaborationAnalysisTemplateInput>;
export interface GetCollaborationAnalysisTemplateOutput {
    collaborationAnalysisTemplate: CollaborationAnalysisTemplate;
}
export declare const GetCollaborationAnalysisTemplateOutput: S.Schema<GetCollaborationAnalysisTemplateOutput>;
export type CollaborationChangeRequestIdentifier = string;
export interface GetCollaborationChangeRequestInput {
    collaborationIdentifier: string;
    changeRequestIdentifier: string;
}
export declare const GetCollaborationChangeRequestInput: S.Schema<GetCollaborationChangeRequestInput>;
export interface GetCollaborationChangeRequestOutput {
    collaborationChangeRequest: CollaborationChangeRequest;
}
export declare const GetCollaborationChangeRequestOutput: S.Schema<GetCollaborationChangeRequestOutput>;
export interface GetCollaborationConfiguredAudienceModelAssociationInput {
    collaborationIdentifier: string;
    configuredAudienceModelAssociationIdentifier: string;
}
export declare const GetCollaborationConfiguredAudienceModelAssociationInput: S.Schema<GetCollaborationConfiguredAudienceModelAssociationInput>;
export interface CollaborationConfiguredAudienceModelAssociation {
    id: string;
    arn: string;
    collaborationId: string;
    collaborationArn: string;
    configuredAudienceModelArn: string;
    name: string;
    description?: string;
    creatorAccountId: string;
    createTime: Date;
    updateTime: Date;
}
export declare const CollaborationConfiguredAudienceModelAssociation: S.Schema<CollaborationConfiguredAudienceModelAssociation>;
export interface GetCollaborationConfiguredAudienceModelAssociationOutput {
    collaborationConfiguredAudienceModelAssociation: CollaborationConfiguredAudienceModelAssociation;
}
export declare const GetCollaborationConfiguredAudienceModelAssociationOutput: S.Schema<GetCollaborationConfiguredAudienceModelAssociationOutput>;
export interface GetCollaborationIdNamespaceAssociationInput {
    collaborationIdentifier: string;
    idNamespaceAssociationIdentifier: string;
}
export declare const GetCollaborationIdNamespaceAssociationInput: S.Schema<GetCollaborationIdNamespaceAssociationInput>;
export interface CollaborationIdNamespaceAssociation {
    id: string;
    arn: string;
    collaborationId: string;
    collaborationArn: string;
    name: string;
    description?: string;
    creatorAccountId: string;
    createTime: Date;
    updateTime: Date;
    inputReferenceConfig: IdNamespaceAssociationInputReferenceConfig;
    inputReferenceProperties: IdNamespaceAssociationInputReferenceProperties;
    idMappingConfig?: IdMappingConfig;
}
export declare const CollaborationIdNamespaceAssociation: S.Schema<CollaborationIdNamespaceAssociation>;
export interface GetCollaborationIdNamespaceAssociationOutput {
    collaborationIdNamespaceAssociation: CollaborationIdNamespaceAssociation;
}
export declare const GetCollaborationIdNamespaceAssociationOutput: S.Schema<GetCollaborationIdNamespaceAssociationOutput>;
export interface GetCollaborationPrivacyBudgetTemplateInput {
    collaborationIdentifier: string;
    privacyBudgetTemplateIdentifier: string;
}
export declare const GetCollaborationPrivacyBudgetTemplateInput: S.Schema<GetCollaborationPrivacyBudgetTemplateInput>;
export interface CollaborationPrivacyBudgetTemplate {
    id: string;
    arn: string;
    collaborationId: string;
    collaborationArn: string;
    creatorAccountId: string;
    createTime: Date;
    updateTime: Date;
    privacyBudgetType: PrivacyBudgetType;
    autoRefresh: PrivacyBudgetTemplateAutoRefresh;
    parameters: PrivacyBudgetTemplateParametersOutput;
}
export declare const CollaborationPrivacyBudgetTemplate: S.Schema<CollaborationPrivacyBudgetTemplate>;
export interface GetCollaborationPrivacyBudgetTemplateOutput {
    collaborationPrivacyBudgetTemplate: CollaborationPrivacyBudgetTemplate;
}
export declare const GetCollaborationPrivacyBudgetTemplateOutput: S.Schema<GetCollaborationPrivacyBudgetTemplateOutput>;
export interface GetConfiguredAudienceModelAssociationInput {
    configuredAudienceModelAssociationIdentifier: string;
    membershipIdentifier: string;
}
export declare const GetConfiguredAudienceModelAssociationInput: S.Schema<GetConfiguredAudienceModelAssociationInput>;
export interface GetConfiguredAudienceModelAssociationOutput {
    configuredAudienceModelAssociation: ConfiguredAudienceModelAssociation;
}
export declare const GetConfiguredAudienceModelAssociationOutput: S.Schema<GetConfiguredAudienceModelAssociationOutput>;
export interface GetConfiguredTableInput {
    configuredTableIdentifier: string;
}
export declare const GetConfiguredTableInput: S.Schema<GetConfiguredTableInput>;
export interface GetConfiguredTableOutput {
    configuredTable: ConfiguredTable;
}
export declare const GetConfiguredTableOutput: S.Schema<GetConfiguredTableOutput>;
export interface GetConfiguredTableAnalysisRuleInput {
    configuredTableIdentifier: string;
    analysisRuleType: ConfiguredTableAnalysisRuleType;
}
export declare const GetConfiguredTableAnalysisRuleInput: S.Schema<GetConfiguredTableAnalysisRuleInput>;
export interface GetConfiguredTableAnalysisRuleOutput {
    analysisRule: ConfiguredTableAnalysisRule;
}
export declare const GetConfiguredTableAnalysisRuleOutput: S.Schema<GetConfiguredTableAnalysisRuleOutput>;
export interface GetConfiguredTableAssociationInput {
    configuredTableAssociationIdentifier: string;
    membershipIdentifier: string;
}
export declare const GetConfiguredTableAssociationInput: S.Schema<GetConfiguredTableAssociationInput>;
export interface GetConfiguredTableAssociationOutput {
    configuredTableAssociation: ConfiguredTableAssociation;
}
export declare const GetConfiguredTableAssociationOutput: S.Schema<GetConfiguredTableAssociationOutput>;
export interface GetConfiguredTableAssociationAnalysisRuleInput {
    membershipIdentifier: string;
    configuredTableAssociationIdentifier: string;
    analysisRuleType: ConfiguredTableAssociationAnalysisRuleType;
}
export declare const GetConfiguredTableAssociationAnalysisRuleInput: S.Schema<GetConfiguredTableAssociationAnalysisRuleInput>;
export interface GetConfiguredTableAssociationAnalysisRuleOutput {
    analysisRule: ConfiguredTableAssociationAnalysisRule;
}
export declare const GetConfiguredTableAssociationAnalysisRuleOutput: S.Schema<GetConfiguredTableAssociationAnalysisRuleOutput>;
export interface GetIdMappingTableInput {
    idMappingTableIdentifier: string;
    membershipIdentifier: string;
}
export declare const GetIdMappingTableInput: S.Schema<GetIdMappingTableInput>;
export interface GetIdMappingTableOutput {
    idMappingTable: IdMappingTable;
}
export declare const GetIdMappingTableOutput: S.Schema<GetIdMappingTableOutput>;
export interface GetIdNamespaceAssociationInput {
    idNamespaceAssociationIdentifier: string;
    membershipIdentifier: string;
}
export declare const GetIdNamespaceAssociationInput: S.Schema<GetIdNamespaceAssociationInput>;
export interface GetIdNamespaceAssociationOutput {
    idNamespaceAssociation: IdNamespaceAssociation;
}
export declare const GetIdNamespaceAssociationOutput: S.Schema<GetIdNamespaceAssociationOutput>;
export interface GetIntermediateTableInput {
    intermediateTableIdentifier: string;
    membershipIdentifier: string;
}
export declare const GetIntermediateTableInput: S.Schema<GetIntermediateTableInput>;
export interface GetIntermediateTableOutput {
    intermediateTable: IntermediateTable;
}
export declare const GetIntermediateTableOutput: S.Schema<GetIntermediateTableOutput>;
export interface GetIntermediateTableAnalysisRuleInput {
    membershipIdentifier: string;
    intermediateTableIdentifier: string;
    analysisRuleType: IntermediateTableAnalysisRuleType;
}
export declare const GetIntermediateTableAnalysisRuleInput: S.Schema<GetIntermediateTableAnalysisRuleInput>;
export interface GetIntermediateTableAnalysisRuleOutput {
    analysisRule: IntermediateTableAnalysisRule;
}
export declare const GetIntermediateTableAnalysisRuleOutput: S.Schema<GetIntermediateTableAnalysisRuleOutput>;
export interface GetMembershipInput {
    membershipIdentifier: string;
}
export declare const GetMembershipInput: S.Schema<GetMembershipInput>;
export interface GetMembershipOutput {
    membership: Membership;
}
export declare const GetMembershipOutput: S.Schema<GetMembershipOutput>;
export interface GetPrivacyBudgetTemplateInput {
    membershipIdentifier: string;
    privacyBudgetTemplateIdentifier: string;
}
export declare const GetPrivacyBudgetTemplateInput: S.Schema<GetPrivacyBudgetTemplateInput>;
export interface GetPrivacyBudgetTemplateOutput {
    privacyBudgetTemplate: PrivacyBudgetTemplate;
}
export declare const GetPrivacyBudgetTemplateOutput: S.Schema<GetPrivacyBudgetTemplateOutput>;
export type ProtectedJobIdentifier = string;
export interface GetProtectedJobInput {
    membershipIdentifier: string;
    protectedJobIdentifier: string;
}
export declare const GetProtectedJobInput: S.Schema<GetProtectedJobInput>;
export type JobParameterName = string;
export type JobParameterValue = string;
export type JobParameterMap = {
    [key: string]: string | undefined;
};
export declare const JobParameterMap: any;
export interface ProtectedJobParameters {
    analysisTemplateArn: string;
    parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const ProtectedJobParameters: S.Schema<ProtectedJobParameters>;
export type ProtectedJobStatus = "SUBMITTED" | "STARTED" | "CANCELLED" | "CANCELLING" | "FAILED" | "SUCCESS" | (string & {});
export declare const ProtectedJobStatus: any;
export interface ProtectedJobS3OutputConfigurationOutput {
    bucket: string;
    keyPrefix?: string;
}
export declare const ProtectedJobS3OutputConfigurationOutput: S.Schema<ProtectedJobS3OutputConfigurationOutput>;
export interface ProtectedJobMemberOutputConfigurationOutput {
    accountId: string;
}
export declare const ProtectedJobMemberOutputConfigurationOutput: S.Schema<ProtectedJobMemberOutputConfigurationOutput>;
export type ProtectedJobOutputConfigurationOutput = {
    s3: ProtectedJobS3OutputConfigurationOutput;
    member?: never;
} | {
    s3?: never;
    member: ProtectedJobMemberOutputConfigurationOutput;
};
export declare const ProtectedJobOutputConfigurationOutput: any;
export interface ProtectedJobResultConfigurationOutput {
    outputConfiguration: ProtectedJobOutputConfigurationOutput;
}
export declare const ProtectedJobResultConfigurationOutput: S.Schema<ProtectedJobResultConfigurationOutput>;
export interface BilledJobResourceUtilization {
    units: number;
}
export declare const BilledJobResourceUtilization: S.Schema<BilledJobResourceUtilization>;
export interface ProtectedJobStatistics {
    totalDurationInMillis?: number;
    billedResourceUtilization?: BilledJobResourceUtilization;
}
export declare const ProtectedJobStatistics: S.Schema<ProtectedJobStatistics>;
export interface ProtectedJobS3Output {
    location: string;
}
export declare const ProtectedJobS3Output: S.Schema<ProtectedJobS3Output>;
export interface ProtectedJobSingleMemberOutput {
    accountId: string;
}
export declare const ProtectedJobSingleMemberOutput: S.Schema<ProtectedJobSingleMemberOutput>;
export type ProtectedJobMemberOutputList = ProtectedJobSingleMemberOutput[];
export declare const ProtectedJobMemberOutputList: any;
export type ProtectedJobOutput = {
    s3: ProtectedJobS3Output;
    memberList?: never;
} | {
    s3?: never;
    memberList: ProtectedJobSingleMemberOutput[];
};
export declare const ProtectedJobOutput: any;
export interface ProtectedJobResult {
    output: ProtectedJobOutput;
}
export declare const ProtectedJobResult: S.Schema<ProtectedJobResult>;
export interface ProtectedJobError {
    message: string;
    code: string;
}
export declare const ProtectedJobError: S.Schema<ProtectedJobError>;
export type ProtectedJobWorkerComputeType = "CR.1X" | "CR.4X" | (string & {});
export declare const ProtectedJobWorkerComputeType: any;
export type SparkPropertyKey = string;
export type SparkPropertyValue = string;
export type SparkProperties = {
    [key: string]: string | undefined;
};
export declare const SparkProperties: any;
export type WorkerComputeConfigurationProperties = {
    spark: {
        [key: string]: string | undefined;
    };
};
export declare const WorkerComputeConfigurationProperties: any;
export interface ProtectedJobWorkerComputeConfiguration {
    type: ProtectedJobWorkerComputeType;
    number: number;
    properties?: WorkerComputeConfigurationProperties;
}
export declare const ProtectedJobWorkerComputeConfiguration: S.Schema<ProtectedJobWorkerComputeConfiguration>;
export type ProtectedJobComputeConfiguration = {
    worker: ProtectedJobWorkerComputeConfiguration;
};
export declare const ProtectedJobComputeConfiguration: any;
export interface ProtectedJob {
    id: string;
    membershipId: string;
    membershipArn: string;
    createTime: Date;
    jobParameters?: ProtectedJobParameters;
    status: ProtectedJobStatus;
    resultConfiguration?: ProtectedJobResultConfigurationOutput;
    statistics?: ProtectedJobStatistics;
    result?: ProtectedJobResult;
    error?: ProtectedJobError;
    computeConfiguration?: ProtectedJobComputeConfiguration;
    jobComputePayerAccountId?: string;
}
export declare const ProtectedJob: S.Schema<ProtectedJob>;
export interface GetProtectedJobOutput {
    protectedJob: ProtectedJob;
}
export declare const GetProtectedJobOutput: S.Schema<GetProtectedJobOutput>;
export type ProtectedQueryIdentifier = string;
export interface GetProtectedQueryInput {
    membershipIdentifier: string;
    protectedQueryIdentifier: string;
}
export declare const GetProtectedQueryInput: S.Schema<GetProtectedQueryInput>;
export interface ProtectedQuerySQLParameters {
    queryString?: string;
    analysisTemplateArn?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const ProtectedQuerySQLParameters: S.Schema<ProtectedQuerySQLParameters>;
export type ProtectedQueryStatus = string;
export interface ProtectedQueryMemberOutputConfiguration {
    accountId: string;
}
export declare const ProtectedQueryMemberOutputConfiguration: S.Schema<ProtectedQueryMemberOutputConfiguration>;
export type ProtectedQueryDistributeOutputConfigurationLocation = {
    s3: ProtectedQueryS3OutputConfiguration;
    member?: never;
} | {
    s3?: never;
    member: ProtectedQueryMemberOutputConfiguration;
};
export declare const ProtectedQueryDistributeOutputConfigurationLocation: any;
export type ProtectedQueryDistributeOutputConfigurationLocations = ProtectedQueryDistributeOutputConfigurationLocation[];
export declare const ProtectedQueryDistributeOutputConfigurationLocations: any;
export interface ProtectedQueryDistributeOutputConfiguration {
    locations: ProtectedQueryDistributeOutputConfigurationLocation[];
}
export declare const ProtectedQueryDistributeOutputConfiguration: S.Schema<ProtectedQueryDistributeOutputConfiguration>;
export interface IntermediateTableOutputConfiguration {
    id: string;
    arn: string;
    name: string;
}
export declare const IntermediateTableOutputConfiguration: S.Schema<IntermediateTableOutputConfiguration>;
export type ProtectedQueryOutputConfiguration = {
    s3: ProtectedQueryS3OutputConfiguration;
    member?: never;
    distribute?: never;
    intermediateTable?: never;
} | {
    s3?: never;
    member: ProtectedQueryMemberOutputConfiguration;
    distribute?: never;
    intermediateTable?: never;
} | {
    s3?: never;
    member?: never;
    distribute: ProtectedQueryDistributeOutputConfiguration;
    intermediateTable?: never;
} | {
    s3?: never;
    member?: never;
    distribute?: never;
    intermediateTable: IntermediateTableOutputConfiguration;
};
export declare const ProtectedQueryOutputConfiguration: any;
export interface ProtectedQueryResultConfiguration {
    outputConfiguration: ProtectedQueryOutputConfiguration;
}
export declare const ProtectedQueryResultConfiguration: S.Schema<ProtectedQueryResultConfiguration>;
export interface BilledResourceUtilization {
    units: number;
}
export declare const BilledResourceUtilization: S.Schema<BilledResourceUtilization>;
export interface ProtectedQueryStatistics {
    totalDurationInMillis?: number;
    billedResourceUtilization?: BilledResourceUtilization;
}
export declare const ProtectedQueryStatistics: S.Schema<ProtectedQueryStatistics>;
export interface ProtectedQueryS3Output {
    location: string;
}
export declare const ProtectedQueryS3Output: S.Schema<ProtectedQueryS3Output>;
export interface ProtectedQuerySingleMemberOutput {
    accountId: string;
}
export declare const ProtectedQuerySingleMemberOutput: S.Schema<ProtectedQuerySingleMemberOutput>;
export type ProtectedQueryMemberOutputList = ProtectedQuerySingleMemberOutput[];
export declare const ProtectedQueryMemberOutputList: any;
export interface ProtectedQueryDistributeOutput {
    s3?: ProtectedQueryS3Output;
    memberList?: ProtectedQuerySingleMemberOutput[];
}
export declare const ProtectedQueryDistributeOutput: S.Schema<ProtectedQueryDistributeOutput>;
export type ProtectedQueryOutput = {
    s3: ProtectedQueryS3Output;
    memberList?: never;
    distribute?: never;
} | {
    s3?: never;
    memberList: ProtectedQuerySingleMemberOutput[];
    distribute?: never;
} | {
    s3?: never;
    memberList?: never;
    distribute: ProtectedQueryDistributeOutput;
};
export declare const ProtectedQueryOutput: any;
export interface ProtectedQueryResult {
    output: ProtectedQueryOutput;
}
export declare const ProtectedQueryResult: S.Schema<ProtectedQueryResult>;
export interface ProtectedQueryError {
    message: string;
    code: string;
}
export declare const ProtectedQueryError: S.Schema<ProtectedQueryError>;
export type DifferentialPrivacyAggregationType = "AVG" | "COUNT" | "COUNT_DISTINCT" | "SUM" | "STDDEV" | (string & {});
export declare const DifferentialPrivacyAggregationType: any;
export type DifferentialPrivacyAggregationExpression = string;
export interface DifferentialPrivacySensitivityParameters {
    aggregationType: DifferentialPrivacyAggregationType;
    aggregationExpression: string;
    userContributionLimit: number;
    minColumnValue?: number;
    maxColumnValue?: number;
}
export declare const DifferentialPrivacySensitivityParameters: S.Schema<DifferentialPrivacySensitivityParameters>;
export type DifferentialPrivacySensitivityParametersList = DifferentialPrivacySensitivityParameters[];
export declare const DifferentialPrivacySensitivityParametersList: any;
export interface DifferentialPrivacyParameters {
    sensitivityParameters: DifferentialPrivacySensitivityParameters[];
}
export declare const DifferentialPrivacyParameters: S.Schema<DifferentialPrivacyParameters>;
export type WorkerComputeType = "CR.1X" | "CR.4X" | "CR.8X" | (string & {});
export declare const WorkerComputeType: any;
export interface WorkerComputeConfiguration {
    type?: WorkerComputeType;
    number?: number;
    properties?: WorkerComputeConfigurationProperties;
}
export declare const WorkerComputeConfiguration: S.Schema<WorkerComputeConfiguration>;
export type ComputeConfiguration = {
    worker: WorkerComputeConfiguration;
};
export declare const ComputeConfiguration: any;
export interface ProtectedQuery {
    id: string;
    membershipId: string;
    membershipArn: string;
    createTime: Date;
    sqlParameters?: ProtectedQuerySQLParameters;
    status: string;
    resultConfiguration?: ProtectedQueryResultConfiguration;
    statistics?: ProtectedQueryStatistics;
    result?: ProtectedQueryResult;
    error?: ProtectedQueryError;
    differentialPrivacy?: DifferentialPrivacyParameters;
    computeConfiguration?: ComputeConfiguration;
    queryComputePayerAccountId?: string;
}
export declare const ProtectedQuery: S.Schema<ProtectedQuery>;
export interface GetProtectedQueryOutput {
    protectedQuery: ProtectedQuery;
}
export declare const GetProtectedQueryOutput: S.Schema<GetProtectedQueryOutput>;
export interface GetSchemaInput {
    collaborationIdentifier: string;
    name: string;
}
export declare const GetSchemaInput: S.Schema<GetSchemaInput>;
export interface GetSchemaOutput {
    schema: Schema;
}
export declare const GetSchemaOutput: S.Schema<GetSchemaOutput>;
export interface GetSchemaAnalysisRuleInput {
    collaborationIdentifier: string;
    name: string;
    type: AnalysisRuleType;
}
export declare const GetSchemaAnalysisRuleInput: S.Schema<GetSchemaAnalysisRuleInput>;
export interface GetSchemaAnalysisRuleOutput {
    analysisRule: AnalysisRule;
}
export declare const GetSchemaAnalysisRuleOutput: S.Schema<GetSchemaAnalysisRuleOutput>;
export type PaginationToken = string;
export type MaxResults = number;
export interface ListAnalysisLogExportsInput {
    membershipIdentifier: string;
    analysisIdentifier?: string;
    status?: AnalysisLogExportStatus;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAnalysisLogExportsInput: S.Schema<ListAnalysisLogExportsInput>;
export interface AnalysisLogExportSummary {
    analysisLogExportId: string;
    analysisId: string;
    analysisType: LogExportAnalysisType;
    status: AnalysisLogExportStatus;
    createTime: Date;
}
export declare const AnalysisLogExportSummary: S.Schema<AnalysisLogExportSummary>;
export type AnalysisLogExportSummaryList = AnalysisLogExportSummary[];
export declare const AnalysisLogExportSummaryList: any;
export interface ListAnalysisLogExportsOutput {
    nextToken?: string;
    analysisLogExports: AnalysisLogExportSummary[];
}
export declare const ListAnalysisLogExportsOutput: S.Schema<ListAnalysisLogExportsOutput>;
export interface ListAnalysisTemplatesInput {
    membershipIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAnalysisTemplatesInput: S.Schema<ListAnalysisTemplatesInput>;
export interface AnalysisTemplateSummary {
    arn: string;
    createTime: Date;
    id: string;
    name: string;
    updateTime: Date;
    membershipArn: string;
    membershipId: string;
    collaborationArn: string;
    collaborationId: string;
    description?: string;
    isSyntheticData?: boolean;
}
export declare const AnalysisTemplateSummary: S.Schema<AnalysisTemplateSummary>;
export type AnalysisTemplateSummaryList = AnalysisTemplateSummary[];
export declare const AnalysisTemplateSummaryList: any;
export interface ListAnalysisTemplatesOutput {
    nextToken?: string;
    analysisTemplateSummaries: AnalysisTemplateSummary[];
}
export declare const ListAnalysisTemplatesOutput: S.Schema<ListAnalysisTemplatesOutput>;
export interface ListCollaborationAnalysisTemplatesInput {
    collaborationIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListCollaborationAnalysisTemplatesInput: S.Schema<ListCollaborationAnalysisTemplatesInput>;
export interface CollaborationAnalysisTemplateSummary {
    arn: string;
    createTime: Date;
    id: string;
    name: string;
    updateTime: Date;
    collaborationArn: string;
    collaborationId: string;
    creatorAccountId: string;
    description?: string;
    isSyntheticData?: boolean;
}
export declare const CollaborationAnalysisTemplateSummary: S.Schema<CollaborationAnalysisTemplateSummary>;
export type CollaborationAnalysisTemplateSummaryList = CollaborationAnalysisTemplateSummary[];
export declare const CollaborationAnalysisTemplateSummaryList: any;
export interface ListCollaborationAnalysisTemplatesOutput {
    nextToken?: string;
    collaborationAnalysisTemplateSummaries: CollaborationAnalysisTemplateSummary[];
}
export declare const ListCollaborationAnalysisTemplatesOutput: S.Schema<ListCollaborationAnalysisTemplatesOutput>;
export interface ListCollaborationChangeRequestsInput {
    collaborationIdentifier: string;
    status?: ChangeRequestStatus;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListCollaborationChangeRequestsInput: S.Schema<ListCollaborationChangeRequestsInput>;
export interface CollaborationChangeRequestSummary {
    id: string;
    collaborationId: string;
    createTime: Date;
    updateTime: Date;
    status: ChangeRequestStatus;
    isAutoApproved: boolean;
    changes: Change[];
    approvals?: {
        [key: string]: ApprovalStatusDetails | undefined;
    };
}
export declare const CollaborationChangeRequestSummary: S.Schema<CollaborationChangeRequestSummary>;
export type CollaborationChangeRequestSummaryList = CollaborationChangeRequestSummary[];
export declare const CollaborationChangeRequestSummaryList: any;
export interface ListCollaborationChangeRequestsOutput {
    collaborationChangeRequestSummaries: CollaborationChangeRequestSummary[];
    nextToken?: string;
}
export declare const ListCollaborationChangeRequestsOutput: S.Schema<ListCollaborationChangeRequestsOutput>;
export interface ListCollaborationConfiguredAudienceModelAssociationsInput {
    collaborationIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListCollaborationConfiguredAudienceModelAssociationsInput: S.Schema<ListCollaborationConfiguredAudienceModelAssociationsInput>;
export interface CollaborationConfiguredAudienceModelAssociationSummary {
    arn: string;
    createTime: Date;
    id: string;
    name: string;
    updateTime: Date;
    collaborationArn: string;
    collaborationId: string;
    creatorAccountId: string;
    description?: string;
}
export declare const CollaborationConfiguredAudienceModelAssociationSummary: S.Schema<CollaborationConfiguredAudienceModelAssociationSummary>;
export type CollaborationConfiguredAudienceModelAssociationSummaryList = CollaborationConfiguredAudienceModelAssociationSummary[];
export declare const CollaborationConfiguredAudienceModelAssociationSummaryList: any;
export interface ListCollaborationConfiguredAudienceModelAssociationsOutput {
    collaborationConfiguredAudienceModelAssociationSummaries: CollaborationConfiguredAudienceModelAssociationSummary[];
    nextToken?: string;
}
export declare const ListCollaborationConfiguredAudienceModelAssociationsOutput: S.Schema<ListCollaborationConfiguredAudienceModelAssociationsOutput>;
export interface ListCollaborationIdNamespaceAssociationsInput {
    collaborationIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListCollaborationIdNamespaceAssociationsInput: S.Schema<ListCollaborationIdNamespaceAssociationsInput>;
export interface IdNamespaceAssociationInputReferencePropertiesSummary {
    idNamespaceType: IdNamespaceType;
}
export declare const IdNamespaceAssociationInputReferencePropertiesSummary: S.Schema<IdNamespaceAssociationInputReferencePropertiesSummary>;
export interface CollaborationIdNamespaceAssociationSummary {
    arn: string;
    createTime: Date;
    id: string;
    updateTime: Date;
    collaborationArn: string;
    collaborationId: string;
    creatorAccountId: string;
    inputReferenceConfig: IdNamespaceAssociationInputReferenceConfig;
    name: string;
    description?: string;
    inputReferenceProperties: IdNamespaceAssociationInputReferencePropertiesSummary;
}
export declare const CollaborationIdNamespaceAssociationSummary: S.Schema<CollaborationIdNamespaceAssociationSummary>;
export type CollaborationIdNamespaceAssociationSummaryList = CollaborationIdNamespaceAssociationSummary[];
export declare const CollaborationIdNamespaceAssociationSummaryList: any;
export interface ListCollaborationIdNamespaceAssociationsOutput {
    nextToken?: string;
    collaborationIdNamespaceAssociationSummaries: CollaborationIdNamespaceAssociationSummary[];
}
export declare const ListCollaborationIdNamespaceAssociationsOutput: S.Schema<ListCollaborationIdNamespaceAssociationsOutput>;
export interface ListCollaborationPrivacyBudgetsInput {
    collaborationIdentifier: string;
    privacyBudgetType: PrivacyBudgetType;
    maxResults?: number;
    nextToken?: string;
    accessBudgetResourceArn?: string;
}
export declare const ListCollaborationPrivacyBudgetsInput: S.Schema<ListCollaborationPrivacyBudgetsInput>;
export interface DifferentialPrivacyPrivacyBudgetAggregation {
    type: DifferentialPrivacyAggregationType;
    maxCount: number;
    remainingCount: number;
}
export declare const DifferentialPrivacyPrivacyBudgetAggregation: S.Schema<DifferentialPrivacyPrivacyBudgetAggregation>;
export type DifferentialPrivacyPrivacyBudgetAggregationList = DifferentialPrivacyPrivacyBudgetAggregation[];
export declare const DifferentialPrivacyPrivacyBudgetAggregationList: any;
export interface DifferentialPrivacyPrivacyBudget {
    aggregations: DifferentialPrivacyPrivacyBudgetAggregation[];
    epsilon: number;
}
export declare const DifferentialPrivacyPrivacyBudget: S.Schema<DifferentialPrivacyPrivacyBudget>;
export type RemainingBudget = number;
export interface AccessBudgetDetails {
    startTime: Date;
    endTime?: Date;
    remainingBudget: number;
    budget: number;
    budgetType: AccessBudgetType;
    autoRefresh?: AutoRefreshMode;
}
export declare const AccessBudgetDetails: S.Schema<AccessBudgetDetails>;
export type AccessBudgetDetailsList = AccessBudgetDetails[];
export declare const AccessBudgetDetailsList: any;
export interface AccessBudget {
    resourceArn: string;
    details: AccessBudgetDetails[];
    aggregateRemainingBudget: number;
}
export declare const AccessBudget: S.Schema<AccessBudget>;
export type PrivacyBudget = {
    differentialPrivacy: DifferentialPrivacyPrivacyBudget;
    accessBudget?: never;
} | {
    differentialPrivacy?: never;
    accessBudget: AccessBudget;
};
export declare const PrivacyBudget: any;
export interface CollaborationPrivacyBudgetSummary {
    id: string;
    privacyBudgetTemplateId: string;
    privacyBudgetTemplateArn: string;
    collaborationId: string;
    collaborationArn: string;
    creatorAccountId: string;
    type: PrivacyBudgetType;
    createTime: Date;
    updateTime: Date;
    budget: PrivacyBudget;
}
export declare const CollaborationPrivacyBudgetSummary: S.Schema<CollaborationPrivacyBudgetSummary>;
export type CollaborationPrivacyBudgetSummaryList = CollaborationPrivacyBudgetSummary[];
export declare const CollaborationPrivacyBudgetSummaryList: any;
export interface ListCollaborationPrivacyBudgetsOutput {
    collaborationPrivacyBudgetSummaries: CollaborationPrivacyBudgetSummary[];
    nextToken?: string;
}
export declare const ListCollaborationPrivacyBudgetsOutput: S.Schema<ListCollaborationPrivacyBudgetsOutput>;
export interface ListCollaborationPrivacyBudgetTemplatesInput {
    collaborationIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListCollaborationPrivacyBudgetTemplatesInput: S.Schema<ListCollaborationPrivacyBudgetTemplatesInput>;
export interface CollaborationPrivacyBudgetTemplateSummary {
    id: string;
    arn: string;
    collaborationId: string;
    collaborationArn: string;
    creatorAccountId: string;
    privacyBudgetType: PrivacyBudgetType;
    createTime: Date;
    updateTime: Date;
}
export declare const CollaborationPrivacyBudgetTemplateSummary: S.Schema<CollaborationPrivacyBudgetTemplateSummary>;
export type CollaborationPrivacyBudgetTemplateSummaryList = CollaborationPrivacyBudgetTemplateSummary[];
export declare const CollaborationPrivacyBudgetTemplateSummaryList: any;
export interface ListCollaborationPrivacyBudgetTemplatesOutput {
    nextToken?: string;
    collaborationPrivacyBudgetTemplateSummaries: CollaborationPrivacyBudgetTemplateSummary[];
}
export declare const ListCollaborationPrivacyBudgetTemplatesOutput: S.Schema<ListCollaborationPrivacyBudgetTemplatesOutput>;
export type FilterableMemberStatus = string;
export interface ListCollaborationsInput {
    nextToken?: string;
    maxResults?: number;
    memberStatus?: string;
}
export declare const ListCollaborationsInput: S.Schema<ListCollaborationsInput>;
export interface CollaborationSummary {
    id: string;
    arn: string;
    name: string;
    creatorAccountId: string;
    creatorDisplayName: string;
    createTime: Date;
    updateTime: Date;
    memberStatus: string;
    membershipId?: string;
    membershipArn?: string;
    analyticsEngine?: AnalyticsEngine;
}
export declare const CollaborationSummary: S.Schema<CollaborationSummary>;
export type CollaborationSummaryList = CollaborationSummary[];
export declare const CollaborationSummaryList: any;
export interface ListCollaborationsOutput {
    nextToken?: string;
    collaborationList: CollaborationSummary[];
}
export declare const ListCollaborationsOutput: S.Schema<ListCollaborationsOutput>;
export interface ListConfiguredAudienceModelAssociationsInput {
    membershipIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListConfiguredAudienceModelAssociationsInput: S.Schema<ListConfiguredAudienceModelAssociationsInput>;
export interface ConfiguredAudienceModelAssociationSummary {
    membershipId: string;
    membershipArn: string;
    collaborationArn: string;
    collaborationId: string;
    createTime: Date;
    updateTime: Date;
    id: string;
    arn: string;
    name: string;
    configuredAudienceModelArn: string;
    description?: string;
}
export declare const ConfiguredAudienceModelAssociationSummary: S.Schema<ConfiguredAudienceModelAssociationSummary>;
export type ConfiguredAudienceModelAssociationSummaryList = ConfiguredAudienceModelAssociationSummary[];
export declare const ConfiguredAudienceModelAssociationSummaryList: any;
export interface ListConfiguredAudienceModelAssociationsOutput {
    configuredAudienceModelAssociationSummaries: ConfiguredAudienceModelAssociationSummary[];
    nextToken?: string;
}
export declare const ListConfiguredAudienceModelAssociationsOutput: S.Schema<ListConfiguredAudienceModelAssociationsOutput>;
export interface ListConfiguredTableAssociationsInput {
    membershipIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListConfiguredTableAssociationsInput: S.Schema<ListConfiguredTableAssociationsInput>;
export interface ConfiguredTableAssociationSummary {
    configuredTableId: string;
    membershipId: string;
    membershipArn: string;
    name: string;
    createTime: Date;
    updateTime: Date;
    id: string;
    arn: string;
    analysisRuleTypes?: ConfiguredTableAssociationAnalysisRuleType[];
}
export declare const ConfiguredTableAssociationSummary: S.Schema<ConfiguredTableAssociationSummary>;
export type ConfiguredTableAssociationSummaryList = ConfiguredTableAssociationSummary[];
export declare const ConfiguredTableAssociationSummaryList: any;
export interface ListConfiguredTableAssociationsOutput {
    configuredTableAssociationSummaries: ConfiguredTableAssociationSummary[];
    nextToken?: string;
}
export declare const ListConfiguredTableAssociationsOutput: S.Schema<ListConfiguredTableAssociationsOutput>;
export interface ListConfiguredTablesInput {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListConfiguredTablesInput: S.Schema<ListConfiguredTablesInput>;
export interface ConfiguredTableSummary {
    id: string;
    arn: string;
    name: string;
    createTime: Date;
    updateTime: Date;
    analysisRuleTypes: ConfiguredTableAnalysisRuleType[];
    analysisMethod: AnalysisMethod;
    selectedAnalysisMethods?: SelectedAnalysisMethod[];
}
export declare const ConfiguredTableSummary: S.Schema<ConfiguredTableSummary>;
export type ConfiguredTableSummaryList = ConfiguredTableSummary[];
export declare const ConfiguredTableSummaryList: any;
export interface ListConfiguredTablesOutput {
    configuredTableSummaries: ConfiguredTableSummary[];
    nextToken?: string;
}
export declare const ListConfiguredTablesOutput: S.Schema<ListConfiguredTablesOutput>;
export interface ListIdMappingTablesInput {
    membershipIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListIdMappingTablesInput: S.Schema<ListIdMappingTablesInput>;
export interface IdMappingTableSummary {
    collaborationArn: string;
    collaborationId: string;
    membershipId: string;
    membershipArn: string;
    createTime: Date;
    updateTime: Date;
    id: string;
    arn: string;
    description?: string;
    inputReferenceConfig: IdMappingTableInputReferenceConfig;
    name: string;
}
export declare const IdMappingTableSummary: S.Schema<IdMappingTableSummary>;
export type IdMappingTableSummaryList = IdMappingTableSummary[];
export declare const IdMappingTableSummaryList: any;
export interface ListIdMappingTablesOutput {
    idMappingTableSummaries: IdMappingTableSummary[];
    nextToken?: string;
}
export declare const ListIdMappingTablesOutput: S.Schema<ListIdMappingTablesOutput>;
export interface ListIdNamespaceAssociationsInput {
    membershipIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListIdNamespaceAssociationsInput: S.Schema<ListIdNamespaceAssociationsInput>;
export interface IdNamespaceAssociationSummary {
    membershipId: string;
    membershipArn: string;
    collaborationArn: string;
    collaborationId: string;
    createTime: Date;
    updateTime: Date;
    id: string;
    arn: string;
    inputReferenceConfig: IdNamespaceAssociationInputReferenceConfig;
    name: string;
    description?: string;
    inputReferenceProperties: IdNamespaceAssociationInputReferencePropertiesSummary;
}
export declare const IdNamespaceAssociationSummary: S.Schema<IdNamespaceAssociationSummary>;
export type IdNamespaceAssociationSummaryList = IdNamespaceAssociationSummary[];
export declare const IdNamespaceAssociationSummaryList: any;
export interface ListIdNamespaceAssociationsOutput {
    nextToken?: string;
    idNamespaceAssociationSummaries: IdNamespaceAssociationSummary[];
}
export declare const ListIdNamespaceAssociationsOutput: S.Schema<ListIdNamespaceAssociationsOutput>;
export interface ListIntermediateTablesInput {
    membershipIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListIntermediateTablesInput: S.Schema<ListIntermediateTablesInput>;
export interface IntermediateTableSummary {
    id: string;
    arn: string;
    name: string;
    description?: string;
    membershipArn: string;
    membershipId: string;
    collaborationArn: string;
    collaborationId: string;
    createTime: Date;
    updateTime: Date;
    status: IntermediateTableStatus;
    retentionInDays?: number;
    analysisRuleTypes?: IntermediateTableAnalysisRuleType[];
}
export declare const IntermediateTableSummary: S.Schema<IntermediateTableSummary>;
export type IntermediateTableSummaryList = IntermediateTableSummary[];
export declare const IntermediateTableSummaryList: any;
export interface ListIntermediateTablesOutput {
    intermediateTableSummaries: IntermediateTableSummary[];
    nextToken?: string;
}
export declare const ListIntermediateTablesOutput: S.Schema<ListIntermediateTablesOutput>;
export interface ListIntermediateTableVersionsInput {
    membershipIdentifier: string;
    intermediateTableIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListIntermediateTableVersionsInput: S.Schema<ListIntermediateTableVersionsInput>;
export type IntermediateTableVersionStatus = "POPULATE_STARTED" | "POPULATE_SUCCESS" | "POPULATE_FAILED" | "RETENTION_PERIOD_EXPIRED" | (string & {});
export declare const IntermediateTableVersionStatus: any;
export interface IntermediateTableVersionSummary {
    versionId: string;
    tableId: string;
    createTime: Date;
    analysisId: string;
    status: IntermediateTableVersionStatus;
    analysisType: PopulateIntermediateTableAnalysisType;
    kmsKeyArn?: string;
    expirationTime?: Date;
}
export declare const IntermediateTableVersionSummary: S.Schema<IntermediateTableVersionSummary>;
export type IntermediateTableVersionSummaryList = IntermediateTableVersionSummary[];
export declare const IntermediateTableVersionSummaryList: any;
export interface ListIntermediateTableVersionsOutput {
    intermediateTableVersionSummaries: IntermediateTableVersionSummary[];
    nextToken?: string;
}
export declare const ListIntermediateTableVersionsOutput: S.Schema<ListIntermediateTableVersionsOutput>;
export interface ListMembersInput {
    collaborationIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListMembersInput: S.Schema<ListMembersInput>;
export interface MemberSummary {
    accountId: string;
    status: string;
    displayName: string;
    abilities: MemberAbility[];
    mlAbilities?: MLMemberAbilities;
    createTime: Date;
    updateTime: Date;
    membershipId?: string;
    membershipArn?: string;
    paymentConfiguration: PaymentConfiguration;
}
export declare const MemberSummary: S.Schema<MemberSummary>;
export type MemberSummaryList = MemberSummary[];
export declare const MemberSummaryList: any;
export interface ListMembersOutput {
    nextToken?: string;
    memberSummaries: MemberSummary[];
}
export declare const ListMembersOutput: S.Schema<ListMembersOutput>;
export interface ListMembershipsInput {
    nextToken?: string;
    maxResults?: number;
    status?: string;
}
export declare const ListMembershipsInput: S.Schema<ListMembershipsInput>;
export interface MembershipSummary {
    id: string;
    arn: string;
    collaborationArn: string;
    collaborationId: string;
    collaborationCreatorAccountId: string;
    collaborationCreatorDisplayName: string;
    collaborationName: string;
    createTime: Date;
    updateTime: Date;
    status: string;
    memberAbilities: MemberAbility[];
    mlMemberAbilities?: MLMemberAbilities;
    paymentConfiguration: MembershipPaymentConfiguration;
}
export declare const MembershipSummary: S.Schema<MembershipSummary>;
export type MembershipSummaryList = MembershipSummary[];
export declare const MembershipSummaryList: any;
export interface ListMembershipsOutput {
    nextToken?: string;
    membershipSummaries: MembershipSummary[];
}
export declare const ListMembershipsOutput: S.Schema<ListMembershipsOutput>;
export interface ListPrivacyBudgetsInput {
    membershipIdentifier: string;
    privacyBudgetType: PrivacyBudgetType;
    nextToken?: string;
    maxResults?: number;
    accessBudgetResourceArn?: string;
}
export declare const ListPrivacyBudgetsInput: S.Schema<ListPrivacyBudgetsInput>;
export interface PrivacyBudgetSummary {
    id: string;
    privacyBudgetTemplateId: string;
    privacyBudgetTemplateArn: string;
    membershipId: string;
    membershipArn: string;
    collaborationId: string;
    collaborationArn: string;
    type: PrivacyBudgetType;
    createTime: Date;
    updateTime: Date;
    budget: PrivacyBudget;
}
export declare const PrivacyBudgetSummary: S.Schema<PrivacyBudgetSummary>;
export type PrivacyBudgetSummaryList = PrivacyBudgetSummary[];
export declare const PrivacyBudgetSummaryList: any;
export interface ListPrivacyBudgetsOutput {
    privacyBudgetSummaries: PrivacyBudgetSummary[];
    nextToken?: string;
}
export declare const ListPrivacyBudgetsOutput: S.Schema<ListPrivacyBudgetsOutput>;
export interface ListPrivacyBudgetTemplatesInput {
    membershipIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPrivacyBudgetTemplatesInput: S.Schema<ListPrivacyBudgetTemplatesInput>;
export interface PrivacyBudgetTemplateSummary {
    id: string;
    arn: string;
    membershipId: string;
    membershipArn: string;
    collaborationId: string;
    collaborationArn: string;
    privacyBudgetType: PrivacyBudgetType;
    createTime: Date;
    updateTime: Date;
}
export declare const PrivacyBudgetTemplateSummary: S.Schema<PrivacyBudgetTemplateSummary>;
export type PrivacyBudgetTemplateSummaryList = PrivacyBudgetTemplateSummary[];
export declare const PrivacyBudgetTemplateSummaryList: any;
export interface ListPrivacyBudgetTemplatesOutput {
    nextToken?: string;
    privacyBudgetTemplateSummaries: PrivacyBudgetTemplateSummary[];
}
export declare const ListPrivacyBudgetTemplatesOutput: S.Schema<ListPrivacyBudgetTemplatesOutput>;
export interface ListProtectedJobsInput {
    membershipIdentifier: string;
    status?: ProtectedJobStatus;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListProtectedJobsInput: S.Schema<ListProtectedJobsInput>;
export type ProtectedJobAnalysisType = "DIRECT_ANALYSIS" | (string & {});
export declare const ProtectedJobAnalysisType: any;
export type ProtectedJobReceiverAccountIds = string[];
export declare const ProtectedJobReceiverAccountIds: any;
export interface ProtectedJobDirectAnalysisConfigurationDetails {
    receiverAccountIds?: string[];
}
export declare const ProtectedJobDirectAnalysisConfigurationDetails: S.Schema<ProtectedJobDirectAnalysisConfigurationDetails>;
export type ProtectedJobConfigurationDetails = {
    directAnalysisConfigurationDetails: ProtectedJobDirectAnalysisConfigurationDetails;
};
export declare const ProtectedJobConfigurationDetails: any;
export interface ProtectedJobReceiverConfiguration {
    analysisType: ProtectedJobAnalysisType;
    configurationDetails?: ProtectedJobConfigurationDetails;
}
export declare const ProtectedJobReceiverConfiguration: S.Schema<ProtectedJobReceiverConfiguration>;
export type ProtectedJobReceiverConfigurations = ProtectedJobReceiverConfiguration[];
export declare const ProtectedJobReceiverConfigurations: any;
export interface ProtectedJobSummary {
    id: string;
    membershipId: string;
    membershipArn: string;
    createTime: Date;
    status: ProtectedJobStatus;
    receiverConfigurations: ProtectedJobReceiverConfiguration[];
    jobComputePayerAccountId?: string;
}
export declare const ProtectedJobSummary: S.Schema<ProtectedJobSummary>;
export type ProtectedJobSummaryList = ProtectedJobSummary[];
export declare const ProtectedJobSummaryList: any;
export interface ListProtectedJobsOutput {
    nextToken?: string;
    protectedJobs: ProtectedJobSummary[];
}
export declare const ListProtectedJobsOutput: S.Schema<ListProtectedJobsOutput>;
export interface ListProtectedQueriesInput {
    membershipIdentifier: string;
    status?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListProtectedQueriesInput: S.Schema<ListProtectedQueriesInput>;
export type ReceiverAccountIds = string[];
export declare const ReceiverAccountIds: any;
export interface DirectAnalysisConfigurationDetails {
    receiverAccountIds?: string[];
}
export declare const DirectAnalysisConfigurationDetails: S.Schema<DirectAnalysisConfigurationDetails>;
export type ConfigurationDetails = {
    directAnalysisConfigurationDetails: DirectAnalysisConfigurationDetails;
};
export declare const ConfigurationDetails: any;
export interface ReceiverConfiguration {
    analysisType: AnalysisType;
    configurationDetails?: ConfigurationDetails;
}
export declare const ReceiverConfiguration: S.Schema<ReceiverConfiguration>;
export type ReceiverConfigurationsList = ReceiverConfiguration[];
export declare const ReceiverConfigurationsList: any;
export interface ProtectedQuerySummary {
    id: string;
    membershipId: string;
    membershipArn: string;
    createTime: Date;
    status: string;
    receiverConfigurations: ReceiverConfiguration[];
    queryComputePayerAccountId?: string;
    intermediateTableConfiguration?: IntermediateTableOutputConfiguration;
}
export declare const ProtectedQuerySummary: S.Schema<ProtectedQuerySummary>;
export type ProtectedQuerySummaryList = ProtectedQuerySummary[];
export declare const ProtectedQuerySummaryList: any;
export interface ListProtectedQueriesOutput {
    nextToken?: string;
    protectedQueries: ProtectedQuerySummary[];
}
export declare const ListProtectedQueriesOutput: S.Schema<ListProtectedQueriesOutput>;
export interface ListSchemasInput {
    collaborationIdentifier: string;
    schemaType?: SchemaType;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListSchemasInput: S.Schema<ListSchemasInput>;
export interface SchemaSummary {
    name: string;
    type: SchemaType;
    creatorAccountId: string;
    createTime: Date;
    updateTime: Date;
    collaborationId: string;
    collaborationArn: string;
    analysisRuleTypes: AnalysisRuleType[];
    analysisMethod?: AnalysisMethod;
    resourceArn?: string;
    selectedAnalysisMethods?: SelectedAnalysisMethod[];
}
export declare const SchemaSummary: S.Schema<SchemaSummary>;
export type SchemaSummaryList = SchemaSummary[];
export declare const SchemaSummaryList: any;
export interface ListSchemasOutput {
    schemaSummaries: SchemaSummary[];
    nextToken?: string;
}
export declare const ListSchemasOutput: S.Schema<ListSchemasOutput>;
export type CleanroomsArn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export declare const ListTagsForResourceInput: S.Schema<ListTagsForResourceInput>;
export interface ListTagsForResourceOutput {
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceOutput: S.Schema<ListTagsForResourceOutput>;
export type JobType = "BATCH" | "INCREMENTAL" | "DELETE_ONLY" | (string & {});
export declare const JobType: any;
export interface PopulateIdMappingTableInput {
    idMappingTableIdentifier: string;
    membershipIdentifier: string;
    jobType?: JobType;
}
export declare const PopulateIdMappingTableInput: S.Schema<PopulateIdMappingTableInput>;
export interface PopulateIdMappingTableOutput {
    idMappingJobId: string;
}
export declare const PopulateIdMappingTableOutput: S.Schema<PopulateIdMappingTableOutput>;
export type IntermediateTableComputeConfiguration = {
    queryComputeConfiguration: WorkerComputeConfiguration;
};
export declare const IntermediateTableComputeConfiguration: any;
export interface PopulateIntermediateTableInput {
    intermediateTableIdentifier: string;
    membershipIdentifier: string;
    parameters?: {
        [key: string]: string | undefined;
    };
    computeConfiguration?: IntermediateTableComputeConfiguration;
    analysisPayerAccountId?: string;
}
export declare const PopulateIntermediateTableInput: S.Schema<PopulateIntermediateTableInput>;
export interface PopulateIntermediateTableOutput {
    analysisId: string;
    analysisType: PopulateIntermediateTableAnalysisType;
    versionId: string;
}
export declare const PopulateIntermediateTableOutput: S.Schema<PopulateIntermediateTableOutput>;
export interface DifferentialPrivacyPreviewParametersInput {
    epsilon: number;
    usersNoisePerQuery: number;
}
export declare const DifferentialPrivacyPreviewParametersInput: S.Schema<DifferentialPrivacyPreviewParametersInput>;
export type PreviewPrivacyImpactParametersInput = {
    differentialPrivacy: DifferentialPrivacyPreviewParametersInput;
};
export declare const PreviewPrivacyImpactParametersInput: any;
export interface PreviewPrivacyImpactInput {
    membershipIdentifier: string;
    parameters: PreviewPrivacyImpactParametersInput;
}
export declare const PreviewPrivacyImpactInput: S.Schema<PreviewPrivacyImpactInput>;
export interface DifferentialPrivacyPreviewAggregation {
    type: DifferentialPrivacyAggregationType;
    maxCount: number;
}
export declare const DifferentialPrivacyPreviewAggregation: S.Schema<DifferentialPrivacyPreviewAggregation>;
export type DifferentialPrivacyPreviewAggregationList = DifferentialPrivacyPreviewAggregation[];
export declare const DifferentialPrivacyPreviewAggregationList: any;
export interface DifferentialPrivacyPrivacyImpact {
    aggregations: DifferentialPrivacyPreviewAggregation[];
}
export declare const DifferentialPrivacyPrivacyImpact: S.Schema<DifferentialPrivacyPrivacyImpact>;
export type PrivacyImpact = {
    differentialPrivacy: DifferentialPrivacyPrivacyImpact;
};
export declare const PrivacyImpact: any;
export interface PreviewPrivacyImpactOutput {
    privacyImpact: PrivacyImpact;
}
export declare const PreviewPrivacyImpactOutput: S.Schema<PreviewPrivacyImpactOutput>;
export interface StartAnalysisLogExportInput {
    membershipIdentifier: string;
    analysisId: string;
    analysisType: LogExportAnalysisType;
    resultConfiguration: AnalysisLogExportResultConfiguration;
}
export declare const StartAnalysisLogExportInput: S.Schema<StartAnalysisLogExportInput>;
export interface StartAnalysisLogExportOutput {
    analysisLogExport: AnalysisLogExport;
}
export declare const StartAnalysisLogExportOutput: S.Schema<StartAnalysisLogExportOutput>;
export type ProtectedJobType = "PYSPARK" | (string & {});
export declare const ProtectedJobType: any;
export interface ProtectedJobMemberOutputConfigurationInput {
    accountId: string;
}
export declare const ProtectedJobMemberOutputConfigurationInput: S.Schema<ProtectedJobMemberOutputConfigurationInput>;
export type ProtectedJobOutputConfigurationInput = {
    member: ProtectedJobMemberOutputConfigurationInput;
};
export declare const ProtectedJobOutputConfigurationInput: any;
export interface ProtectedJobResultConfigurationInput {
    outputConfiguration: ProtectedJobOutputConfigurationInput;
}
export declare const ProtectedJobResultConfigurationInput: S.Schema<ProtectedJobResultConfigurationInput>;
export interface StartProtectedJobInput {
    type: ProtectedJobType;
    membershipIdentifier: string;
    jobParameters: ProtectedJobParameters;
    resultConfiguration?: ProtectedJobResultConfigurationInput;
    computeConfiguration?: ProtectedJobComputeConfiguration;
    jobComputePayerAccountId?: string;
}
export declare const StartProtectedJobInput: S.Schema<StartProtectedJobInput>;
export interface StartProtectedJobOutput {
    protectedJob: ProtectedJob;
}
export declare const StartProtectedJobOutput: S.Schema<StartProtectedJobOutput>;
export type ProtectedQueryType = string;
export interface StartProtectedQueryInput {
    type: string;
    membershipIdentifier: string;
    sqlParameters: ProtectedQuerySQLParameters;
    resultConfiguration?: ProtectedQueryResultConfiguration;
    computeConfiguration?: ComputeConfiguration;
    queryComputePayerAccountId?: string;
}
export declare const StartProtectedQueryInput: S.Schema<StartProtectedQueryInput>;
export interface StartProtectedQueryOutput {
    protectedQuery: ProtectedQuery;
}
export declare const StartProtectedQueryOutput: S.Schema<StartProtectedQueryOutput>;
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceInput: S.Schema<TagResourceInput>;
export interface TagResourceOutput {
}
export declare const TagResourceOutput: S.Schema<TagResourceOutput>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceInput: S.Schema<UntagResourceInput>;
export interface UntagResourceOutput {
}
export declare const UntagResourceOutput: S.Schema<UntagResourceOutput>;
export interface UpdateAnalysisTemplateInput {
    membershipIdentifier: string;
    analysisTemplateIdentifier: string;
    description?: string;
}
export declare const UpdateAnalysisTemplateInput: S.Schema<UpdateAnalysisTemplateInput>;
export interface UpdateAnalysisTemplateOutput {
    analysisTemplate: AnalysisTemplate;
}
export declare const UpdateAnalysisTemplateOutput: S.Schema<UpdateAnalysisTemplateOutput>;
export interface UpdateCollaborationInput {
    collaborationIdentifier: string;
    name?: string;
    description?: string;
    analyticsEngine?: AnalyticsEngine;
}
export declare const UpdateCollaborationInput: S.Schema<UpdateCollaborationInput>;
export interface UpdateCollaborationOutput {
    collaboration: Collaboration;
}
export declare const UpdateCollaborationOutput: S.Schema<UpdateCollaborationOutput>;
export type ChangeRequestAction = "APPROVE" | "DENY" | "CANCEL" | "COMMIT" | (string & {});
export declare const ChangeRequestAction: any;
export interface UpdateCollaborationChangeRequestInput {
    collaborationIdentifier: string;
    changeRequestIdentifier: string;
    action: ChangeRequestAction;
}
export declare const UpdateCollaborationChangeRequestInput: S.Schema<UpdateCollaborationChangeRequestInput>;
export interface UpdateCollaborationChangeRequestOutput {
    collaborationChangeRequest: CollaborationChangeRequest;
}
export declare const UpdateCollaborationChangeRequestOutput: S.Schema<UpdateCollaborationChangeRequestOutput>;
export interface UpdateConfiguredAudienceModelAssociationInput {
    configuredAudienceModelAssociationIdentifier: string;
    membershipIdentifier: string;
    description?: string;
    name?: string;
}
export declare const UpdateConfiguredAudienceModelAssociationInput: S.Schema<UpdateConfiguredAudienceModelAssociationInput>;
export interface UpdateConfiguredAudienceModelAssociationOutput {
    configuredAudienceModelAssociation: ConfiguredAudienceModelAssociation;
}
export declare const UpdateConfiguredAudienceModelAssociationOutput: S.Schema<UpdateConfiguredAudienceModelAssociationOutput>;
export interface UpdateConfiguredTableInput {
    configuredTableIdentifier: string;
    name?: string;
    description?: string;
    tableReference?: TableReference;
    allowedColumns?: string[];
    analysisMethod?: AnalysisMethod;
    selectedAnalysisMethods?: SelectedAnalysisMethod[];
}
export declare const UpdateConfiguredTableInput: S.Schema<UpdateConfiguredTableInput>;
export interface UpdateConfiguredTableOutput {
    configuredTable: ConfiguredTable;
}
export declare const UpdateConfiguredTableOutput: S.Schema<UpdateConfiguredTableOutput>;
export interface UpdateConfiguredTableAnalysisRuleInput {
    configuredTableIdentifier: string;
    analysisRuleType: ConfiguredTableAnalysisRuleType;
    analysisRulePolicy: ConfiguredTableAnalysisRulePolicy;
}
export declare const UpdateConfiguredTableAnalysisRuleInput: S.Schema<UpdateConfiguredTableAnalysisRuleInput>;
export interface UpdateConfiguredTableAnalysisRuleOutput {
    analysisRule: ConfiguredTableAnalysisRule;
}
export declare const UpdateConfiguredTableAnalysisRuleOutput: S.Schema<UpdateConfiguredTableAnalysisRuleOutput>;
export interface UpdateConfiguredTableAssociationInput {
    configuredTableAssociationIdentifier: string;
    membershipIdentifier: string;
    description?: string;
    roleArn?: string;
}
export declare const UpdateConfiguredTableAssociationInput: S.Schema<UpdateConfiguredTableAssociationInput>;
export interface UpdateConfiguredTableAssociationOutput {
    configuredTableAssociation: ConfiguredTableAssociation;
}
export declare const UpdateConfiguredTableAssociationOutput: S.Schema<UpdateConfiguredTableAssociationOutput>;
export interface UpdateConfiguredTableAssociationAnalysisRuleInput {
    membershipIdentifier: string;
    configuredTableAssociationIdentifier: string;
    analysisRuleType: ConfiguredTableAssociationAnalysisRuleType;
    analysisRulePolicy: ConfiguredTableAssociationAnalysisRulePolicy;
}
export declare const UpdateConfiguredTableAssociationAnalysisRuleInput: S.Schema<UpdateConfiguredTableAssociationAnalysisRuleInput>;
export interface UpdateConfiguredTableAssociationAnalysisRuleOutput {
    analysisRule: ConfiguredTableAssociationAnalysisRule;
}
export declare const UpdateConfiguredTableAssociationAnalysisRuleOutput: S.Schema<UpdateConfiguredTableAssociationAnalysisRuleOutput>;
export interface UpdateIdMappingTableInput {
    idMappingTableIdentifier: string;
    membershipIdentifier: string;
    description?: string;
    kmsKeyArn?: string;
}
export declare const UpdateIdMappingTableInput: S.Schema<UpdateIdMappingTableInput>;
export interface UpdateIdMappingTableOutput {
    idMappingTable: IdMappingTable;
}
export declare const UpdateIdMappingTableOutput: S.Schema<UpdateIdMappingTableOutput>;
export interface UpdateIdNamespaceAssociationInput {
    idNamespaceAssociationIdentifier: string;
    membershipIdentifier: string;
    name?: string;
    description?: string;
    idMappingConfig?: IdMappingConfig;
}
export declare const UpdateIdNamespaceAssociationInput: S.Schema<UpdateIdNamespaceAssociationInput>;
export interface UpdateIdNamespaceAssociationOutput {
    idNamespaceAssociation: IdNamespaceAssociation;
}
export declare const UpdateIdNamespaceAssociationOutput: S.Schema<UpdateIdNamespaceAssociationOutput>;
export type IntermediateTableColumnTypeString = string;
export interface IntermediateTableColumn {
    name: string;
    type: string;
}
export declare const IntermediateTableColumn: S.Schema<IntermediateTableColumn>;
export type IntermediateTableColumnList = IntermediateTableColumn[];
export declare const IntermediateTableColumnList: any;
export interface UpdateIntermediateTableInput {
    intermediateTableIdentifier: string;
    membershipIdentifier: string;
    description?: string;
    kmsKeyArn?: string;
    columns?: IntermediateTableColumn[];
}
export declare const UpdateIntermediateTableInput: S.Schema<UpdateIntermediateTableInput>;
export interface UpdateIntermediateTableOutput {
    intermediateTable: IntermediateTable;
}
export declare const UpdateIntermediateTableOutput: S.Schema<UpdateIntermediateTableOutput>;
export interface UpdateIntermediateTableAnalysisRuleInput {
    membershipIdentifier: string;
    intermediateTableIdentifier: string;
    analysisRuleType: IntermediateTableAnalysisRuleType;
    analysisRulePolicy: IntermediateTableAnalysisRulePolicy;
}
export declare const UpdateIntermediateTableAnalysisRuleInput: S.Schema<UpdateIntermediateTableAnalysisRuleInput>;
export interface UpdateIntermediateTableAnalysisRuleOutput {
    analysisRule: IntermediateTableAnalysisRule;
}
export declare const UpdateIntermediateTableAnalysisRuleOutput: S.Schema<UpdateIntermediateTableAnalysisRuleOutput>;
export interface UpdateMembershipPaymentConfiguration {
    queryCompute?: MembershipQueryComputePaymentConfig;
    machineLearning?: MembershipMLPaymentConfig;
    jobCompute?: MembershipJobComputePaymentConfig;
}
export declare const UpdateMembershipPaymentConfiguration: S.Schema<UpdateMembershipPaymentConfiguration>;
export interface UpdateMembershipInput {
    membershipIdentifier: string;
    queryLogStatus?: MembershipQueryLogStatus;
    jobLogStatus?: MembershipJobLogStatus;
    defaultResultConfiguration?: MembershipProtectedQueryResultConfiguration;
    defaultJobResultConfiguration?: MembershipProtectedJobResultConfiguration;
    membershipPaymentConfiguration?: UpdateMembershipPaymentConfiguration;
}
export declare const UpdateMembershipInput: S.Schema<UpdateMembershipInput>;
export interface UpdateMembershipOutput {
    membership: Membership;
}
export declare const UpdateMembershipOutput: S.Schema<UpdateMembershipOutput>;
export interface DifferentialPrivacyTemplateUpdateParameters {
    epsilon?: number;
    usersNoisePerQuery?: number;
}
export declare const DifferentialPrivacyTemplateUpdateParameters: S.Schema<DifferentialPrivacyTemplateUpdateParameters>;
export interface AccessBudgetsPrivacyTemplateUpdateParameters {
    budgetParameters: BudgetParameter[];
}
export declare const AccessBudgetsPrivacyTemplateUpdateParameters: S.Schema<AccessBudgetsPrivacyTemplateUpdateParameters>;
export type PrivacyBudgetTemplateUpdateParameters = {
    differentialPrivacy: DifferentialPrivacyTemplateUpdateParameters;
    accessBudget?: never;
} | {
    differentialPrivacy?: never;
    accessBudget: AccessBudgetsPrivacyTemplateUpdateParameters;
};
export declare const PrivacyBudgetTemplateUpdateParameters: any;
export interface UpdatePrivacyBudgetTemplateInput {
    membershipIdentifier: string;
    privacyBudgetTemplateIdentifier: string;
    privacyBudgetType: PrivacyBudgetType;
    parameters?: PrivacyBudgetTemplateUpdateParameters;
}
export declare const UpdatePrivacyBudgetTemplateInput: S.Schema<UpdatePrivacyBudgetTemplateInput>;
export interface UpdatePrivacyBudgetTemplateOutput {
    privacyBudgetTemplate: PrivacyBudgetTemplate;
}
export declare const UpdatePrivacyBudgetTemplateOutput: S.Schema<UpdatePrivacyBudgetTemplateOutput>;
export type TargetProtectedJobStatus = "CANCELLED" | (string & {});
export declare const TargetProtectedJobStatus: any;
export interface UpdateProtectedJobInput {
    membershipIdentifier: string;
    protectedJobIdentifier: string;
    targetStatus: TargetProtectedJobStatus;
}
export declare const UpdateProtectedJobInput: S.Schema<UpdateProtectedJobInput>;
export interface UpdateProtectedJobOutput {
    protectedJob: ProtectedJob;
}
export declare const UpdateProtectedJobOutput: S.Schema<UpdateProtectedJobOutput>;
export type TargetProtectedQueryStatus = string;
export interface UpdateProtectedQueryInput {
    membershipIdentifier: string;
    protectedQueryIdentifier: string;
    targetStatus: string;
}
export declare const UpdateProtectedQueryInput: S.Schema<UpdateProtectedQueryInput>;
export interface UpdateProtectedQueryOutput {
    protectedQuery: ProtectedQuery;
}
export declare const UpdateProtectedQueryOutput: S.Schema<UpdateProtectedQueryOutput>;
export type AccessDeniedExceptionReason = string;
export type ResourceType = string;
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type ConflictExceptionReason = string;
export type BatchGetCollaborationAnalysisTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves multiple analysis templates within a collaboration by their Amazon Resource Names (ARNs).
 */
export declare const batchGetCollaborationAnalysisTemplate: API.OperationMethod<BatchGetCollaborationAnalysisTemplateInput, BatchGetCollaborationAnalysisTemplateOutput, BatchGetCollaborationAnalysisTemplateError, Credentials | HttpClient.HttpClient>;
export type BatchGetSchemaError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves multiple schemas by their identifiers.
 */
export declare const batchGetSchema: API.OperationMethod<BatchGetSchemaInput, BatchGetSchemaOutput, BatchGetSchemaError, Credentials | HttpClient.HttpClient>;
export type BatchGetSchemaAnalysisRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves multiple analysis rule schemas.
 */
export declare const batchGetSchemaAnalysisRule: API.OperationMethod<BatchGetSchemaAnalysisRuleInput, BatchGetSchemaAnalysisRuleOutput, BatchGetSchemaAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type CreateAnalysisTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new analysis template.
 */
export declare const createAnalysisTemplate: API.OperationMethod<CreateAnalysisTemplateInput, CreateAnalysisTemplateOutput, CreateAnalysisTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateCollaborationError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new collaboration.
 */
export declare const createCollaboration: API.OperationMethod<CreateCollaborationInput, CreateCollaborationOutput, CreateCollaborationError, Credentials | HttpClient.HttpClient>;
export type CreateCollaborationChangeRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new change request to modify an existing collaboration. This enables post-creation modifications to collaborations through a structured API-driven approach.
 */
export declare const createCollaborationChangeRequest: API.OperationMethod<CreateCollaborationChangeRequestInput, CreateCollaborationChangeRequestOutput, CreateCollaborationChangeRequestError, Credentials | HttpClient.HttpClient>;
export type CreateConfiguredAudienceModelAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the details necessary to create a configured audience model association.
 */
export declare const createConfiguredAudienceModelAssociation: API.OperationMethod<CreateConfiguredAudienceModelAssociationInput, CreateConfiguredAudienceModelAssociationOutput, CreateConfiguredAudienceModelAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateConfiguredTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new configured table resource.
 */
export declare const createConfiguredTable: API.OperationMethod<CreateConfiguredTableInput, CreateConfiguredTableOutput, CreateConfiguredTableError, Credentials | HttpClient.HttpClient>;
export type CreateConfiguredTableAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new analysis rule for a configured table. Currently, only one analysis rule can be created for a given configured table.
 */
export declare const createConfiguredTableAnalysisRule: API.OperationMethod<CreateConfiguredTableAnalysisRuleInput, CreateConfiguredTableAnalysisRuleOutput, CreateConfiguredTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type CreateConfiguredTableAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a configured table association. A configured table association links a configured table with a collaboration.
 */
export declare const createConfiguredTableAssociation: API.OperationMethod<CreateConfiguredTableAssociationInput, CreateConfiguredTableAssociationOutput, CreateConfiguredTableAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateConfiguredTableAssociationAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new analysis rule for an associated configured table.
 */
export declare const createConfiguredTableAssociationAnalysisRule: API.OperationMethod<CreateConfiguredTableAssociationAnalysisRuleInput, CreateConfiguredTableAssociationAnalysisRuleOutput, CreateConfiguredTableAssociationAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type CreateIdMappingTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ID mapping table.
 */
export declare const createIdMappingTable: API.OperationMethod<CreateIdMappingTableInput, CreateIdMappingTableOutput, CreateIdMappingTableError, Credentials | HttpClient.HttpClient>;
export type CreateIdNamespaceAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ID namespace association.
 */
export declare const createIdNamespaceAssociation: API.OperationMethod<CreateIdNamespaceAssociationInput, CreateIdNamespaceAssociationOutput, CreateIdNamespaceAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateIntermediateTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an intermediate table in a membership. The intermediate table is owned by the member with the CAN_QUERY ability. To populate the table with results, use `PopulateIntermediateTable`.
 */
export declare const createIntermediateTable: API.OperationMethod<CreateIntermediateTableInput, CreateIntermediateTableOutput, CreateIntermediateTableError, Credentials | HttpClient.HttpClient>;
export type CreateIntermediateTableAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an analysis rule for an intermediate table. Only the CUSTOM analysis rule type is supported. Only the intermediate table owner can call this operation.
 */
export declare const createIntermediateTableAnalysisRule: API.OperationMethod<CreateIntermediateTableAnalysisRuleInput, CreateIntermediateTableAnalysisRuleOutput, CreateIntermediateTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type CreateMembershipError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a membership for a specific collaboration identifier and joins the collaboration.
 */
export declare const createMembership: API.OperationMethod<CreateMembershipInput, CreateMembershipOutput, CreateMembershipError, Credentials | HttpClient.HttpClient>;
export type CreatePrivacyBudgetTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a privacy budget template for a specified collaboration. Each collaboration can have only one privacy budget template. If you need to change the privacy budget template, use the UpdatePrivacyBudgetTemplate operation.
 */
export declare const createPrivacyBudgetTemplate: API.OperationMethod<CreatePrivacyBudgetTemplateInput, CreatePrivacyBudgetTemplateOutput, CreatePrivacyBudgetTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteAnalysisTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an analysis template.
 */
export declare const deleteAnalysisTemplate: API.OperationMethod<DeleteAnalysisTemplateInput, DeleteAnalysisTemplateOutput, DeleteAnalysisTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteCollaborationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a collaboration. It can only be called by the collaboration owner.
 */
export declare const deleteCollaboration: API.OperationMethod<DeleteCollaborationInput, DeleteCollaborationOutput, DeleteCollaborationError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredAudienceModelAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the information necessary to delete a configured audience model association.
 */
export declare const deleteConfiguredAudienceModelAssociation: API.OperationMethod<DeleteConfiguredAudienceModelAssociationInput, DeleteConfiguredAudienceModelAssociationOutput, DeleteConfiguredAudienceModelAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a configured table.
 */
export declare const deleteConfiguredTable: API.OperationMethod<DeleteConfiguredTableInput, DeleteConfiguredTableOutput, DeleteConfiguredTableError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredTableAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a configured table analysis rule.
 */
export declare const deleteConfiguredTableAnalysisRule: API.OperationMethod<DeleteConfiguredTableAnalysisRuleInput, DeleteConfiguredTableAnalysisRuleOutput, DeleteConfiguredTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredTableAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a configured table association.
 */
export declare const deleteConfiguredTableAssociation: API.OperationMethod<DeleteConfiguredTableAssociationInput, DeleteConfiguredTableAssociationOutput, DeleteConfiguredTableAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredTableAssociationAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an analysis rule for a configured table association.
 */
export declare const deleteConfiguredTableAssociationAnalysisRule: API.OperationMethod<DeleteConfiguredTableAssociationAnalysisRuleInput, DeleteConfiguredTableAssociationAnalysisRuleOutput, DeleteConfiguredTableAssociationAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteIdMappingTableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an ID mapping table.
 */
export declare const deleteIdMappingTable: API.OperationMethod<DeleteIdMappingTableInput, DeleteIdMappingTableOutput, DeleteIdMappingTableError, Credentials | HttpClient.HttpClient>;
export type DeleteIdNamespaceAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an ID namespace association.
 */
export declare const deleteIdNamespaceAssociation: API.OperationMethod<DeleteIdNamespaceAssociationInput, DeleteIdNamespaceAssociationOutput, DeleteIdNamespaceAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteIntermediateTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an intermediate table. The delete is idempotent. Only the intermediate table owner can call this operation.
 */
export declare const deleteIntermediateTable: API.OperationMethod<DeleteIntermediateTableInput, DeleteIntermediateTableOutput, DeleteIntermediateTableError, Credentials | HttpClient.HttpClient>;
export type DeleteIntermediateTableAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an analysis rule from an intermediate table. After the analysis rule is deleted, the intermediate table becomes unqueryable until a new analysis rule is attached. Only the intermediate table owner can call this operation.
 */
export declare const deleteIntermediateTableAnalysisRule: API.OperationMethod<DeleteIntermediateTableAnalysisRuleInput, DeleteIntermediateTableAnalysisRuleOutput, DeleteIntermediateTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteMemberError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the specified member from a collaboration. The removed member is placed in the Removed status and can't interact with the collaboration. The removed member's data is inaccessible to active members of the collaboration.
 */
export declare const deleteMember: API.OperationMethod<DeleteMemberInput, DeleteMemberOutput, DeleteMemberError, Credentials | HttpClient.HttpClient>;
export type DeleteMembershipError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specified membership. All resources under a membership must be deleted.
 */
export declare const deleteMembership: API.OperationMethod<DeleteMembershipInput, DeleteMembershipOutput, DeleteMembershipError, Credentials | HttpClient.HttpClient>;
export type DeletePrivacyBudgetTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a privacy budget template for a specified collaboration.
 */
export declare const deletePrivacyBudgetTemplate: API.OperationMethod<DeletePrivacyBudgetTemplateInput, DeletePrivacyBudgetTemplateOutput, DeletePrivacyBudgetTemplateError, Credentials | HttpClient.HttpClient>;
export type DisallowIntermediateTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Marks an intermediate table as invalid when it references the caller's base table. The data provider (base table owner) calls this operation, not the intermediate table owner. By default, the operation also marks all descendant intermediate tables as invalid.
 */
export declare const disallowIntermediateTable: API.OperationMethod<DisallowIntermediateTableInput, DisallowIntermediateTableOutput, DisallowIntermediateTableError, Credentials | HttpClient.HttpClient>;
export type GetAnalysisLogExportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an analysis log export, including its current status and, if the export failed, the reason for the failure.
 *
 * Poll this operation until the `status` is `SUCCESS` or `FAILED`. An export can't be canceled after it starts.
 */
export declare const getAnalysisLogExport: API.OperationMethod<GetAnalysisLogExportInput, GetAnalysisLogExportOutput, GetAnalysisLogExportError, Credentials | HttpClient.HttpClient>;
export type GetAnalysisTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an analysis template.
 */
export declare const getAnalysisTemplate: API.OperationMethod<GetAnalysisTemplateInput, GetAnalysisTemplateOutput, GetAnalysisTemplateError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns metadata about a collaboration.
 */
export declare const getCollaboration: API.OperationMethod<GetCollaborationInput, GetCollaborationOutput, GetCollaborationError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationAnalysisTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an analysis template within a collaboration.
 */
export declare const getCollaborationAnalysisTemplate: API.OperationMethod<GetCollaborationAnalysisTemplateInput, GetCollaborationAnalysisTemplateOutput, GetCollaborationAnalysisTemplateError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationChangeRequestError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific collaboration change request.
 */
export declare const getCollaborationChangeRequest: API.OperationMethod<GetCollaborationChangeRequestInput, GetCollaborationChangeRequestOutput, GetCollaborationChangeRequestError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationConfiguredAudienceModelAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a configured audience model association within a collaboration.
 */
export declare const getCollaborationConfiguredAudienceModelAssociation: API.OperationMethod<GetCollaborationConfiguredAudienceModelAssociationInput, GetCollaborationConfiguredAudienceModelAssociationOutput, GetCollaborationConfiguredAudienceModelAssociationError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationIdNamespaceAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an ID namespace association from a specific collaboration.
 */
export declare const getCollaborationIdNamespaceAssociation: API.OperationMethod<GetCollaborationIdNamespaceAssociationInput, GetCollaborationIdNamespaceAssociationOutput, GetCollaborationIdNamespaceAssociationError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationPrivacyBudgetTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about a specified privacy budget template.
 */
export declare const getCollaborationPrivacyBudgetTemplate: API.OperationMethod<GetCollaborationPrivacyBudgetTemplateInput, GetCollaborationPrivacyBudgetTemplateOutput, GetCollaborationPrivacyBudgetTemplateError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredAudienceModelAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a configured audience model association.
 */
export declare const getConfiguredAudienceModelAssociation: API.OperationMethod<GetConfiguredAudienceModelAssociationInput, GetConfiguredAudienceModelAssociationOutput, GetConfiguredAudienceModelAssociationError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredTableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a configured table.
 */
export declare const getConfiguredTable: API.OperationMethod<GetConfiguredTableInput, GetConfiguredTableOutput, GetConfiguredTableError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredTableAnalysisRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a configured table analysis rule.
 */
export declare const getConfiguredTableAnalysisRule: API.OperationMethod<GetConfiguredTableAnalysisRuleInput, GetConfiguredTableAnalysisRuleOutput, GetConfiguredTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredTableAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a configured table association.
 */
export declare const getConfiguredTableAssociation: API.OperationMethod<GetConfiguredTableAssociationInput, GetConfiguredTableAssociationOutput, GetConfiguredTableAssociationError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredTableAssociationAnalysisRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the analysis rule for a configured table association.
 */
export declare const getConfiguredTableAssociationAnalysisRule: API.OperationMethod<GetConfiguredTableAssociationAnalysisRuleInput, GetConfiguredTableAssociationAnalysisRuleOutput, GetConfiguredTableAssociationAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type GetIdMappingTableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an ID mapping table.
 */
export declare const getIdMappingTable: API.OperationMethod<GetIdMappingTableInput, GetIdMappingTableOutput, GetIdMappingTableError, Credentials | HttpClient.HttpClient>;
export type GetIdNamespaceAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an ID namespace association.
 */
export declare const getIdNamespaceAssociation: API.OperationMethod<GetIdNamespaceAssociationInput, GetIdNamespaceAssociationOutput, GetIdNamespaceAssociationError, Credentials | HttpClient.HttpClient>;
export type GetIntermediateTableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an intermediate table. Returns the full details of the intermediate table, including schema, table dependencies, inherited constraints, child resources, and status. Only the intermediate table owner can call this operation.
 */
export declare const getIntermediateTable: API.OperationMethod<GetIntermediateTableInput, GetIntermediateTableOutput, GetIntermediateTableError, Credentials | HttpClient.HttpClient>;
export type GetIntermediateTableAnalysisRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the analysis rule for an intermediate table.
 */
export declare const getIntermediateTableAnalysisRule: API.OperationMethod<GetIntermediateTableAnalysisRuleInput, GetIntermediateTableAnalysisRuleOutput, GetIntermediateTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type GetMembershipError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a specified membership for an identifier.
 */
export declare const getMembership: API.OperationMethod<GetMembershipInput, GetMembershipOutput, GetMembershipError, Credentials | HttpClient.HttpClient>;
export type GetPrivacyBudgetTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details for a specified privacy budget template.
 */
export declare const getPrivacyBudgetTemplate: API.OperationMethod<GetPrivacyBudgetTemplateInput, GetPrivacyBudgetTemplateOutput, GetPrivacyBudgetTemplateError, Credentials | HttpClient.HttpClient>;
export type GetProtectedJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns job processing metadata.
 */
export declare const getProtectedJob: API.OperationMethod<GetProtectedJobInput, GetProtectedJobOutput, GetProtectedJobError, Credentials | HttpClient.HttpClient>;
export type GetProtectedQueryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns query processing metadata.
 */
export declare const getProtectedQuery: API.OperationMethod<GetProtectedQueryInput, GetProtectedQueryOutput, GetProtectedQueryError, Credentials | HttpClient.HttpClient>;
export type GetSchemaError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the schema for a relation within a collaboration.
 */
export declare const getSchema: API.OperationMethod<GetSchemaInput, GetSchemaOutput, GetSchemaError, Credentials | HttpClient.HttpClient>;
export type GetSchemaAnalysisRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a schema analysis rule.
 */
export declare const getSchemaAnalysisRule: API.OperationMethod<GetSchemaAnalysisRuleInput, GetSchemaAnalysisRuleOutput, GetSchemaAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type ListAnalysisLogExportsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists analysis log exports, sorted by the most recent export. Results are paginated. Use the `nextToken` parameter to retrieve additional results.
 */
export declare const listAnalysisLogExports: API.PaginatedOperationMethod<ListAnalysisLogExportsInput, ListAnalysisLogExportsOutput, ListAnalysisLogExportsError, Credentials | HttpClient.HttpClient, AnalysisLogExportSummary>;
export type ListAnalysisTemplatesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists analysis templates that the caller owns.
 */
export declare const listAnalysisTemplates: API.PaginatedOperationMethod<ListAnalysisTemplatesInput, ListAnalysisTemplatesOutput, ListAnalysisTemplatesError, Credentials | HttpClient.HttpClient, AnalysisTemplateSummary>;
export type ListCollaborationAnalysisTemplatesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists analysis templates within a collaboration.
 */
export declare const listCollaborationAnalysisTemplates: API.PaginatedOperationMethod<ListCollaborationAnalysisTemplatesInput, ListCollaborationAnalysisTemplatesOutput, ListCollaborationAnalysisTemplatesError, Credentials | HttpClient.HttpClient, CollaborationAnalysisTemplateSummary>;
export type ListCollaborationChangeRequestsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all change requests for a collaboration with pagination support. Returns change requests sorted by creation time.
 */
export declare const listCollaborationChangeRequests: API.PaginatedOperationMethod<ListCollaborationChangeRequestsInput, ListCollaborationChangeRequestsOutput, ListCollaborationChangeRequestsError, Credentials | HttpClient.HttpClient, CollaborationChangeRequestSummary>;
export type ListCollaborationConfiguredAudienceModelAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists configured audience model associations within a collaboration.
 */
export declare const listCollaborationConfiguredAudienceModelAssociations: API.PaginatedOperationMethod<ListCollaborationConfiguredAudienceModelAssociationsInput, ListCollaborationConfiguredAudienceModelAssociationsOutput, ListCollaborationConfiguredAudienceModelAssociationsError, Credentials | HttpClient.HttpClient, CollaborationConfiguredAudienceModelAssociationSummary>;
export type ListCollaborationIdNamespaceAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the ID namespace associations in a collaboration.
 */
export declare const listCollaborationIdNamespaceAssociations: API.PaginatedOperationMethod<ListCollaborationIdNamespaceAssociationsInput, ListCollaborationIdNamespaceAssociationsOutput, ListCollaborationIdNamespaceAssociationsError, Credentials | HttpClient.HttpClient, CollaborationIdNamespaceAssociationSummary>;
export type ListCollaborationPrivacyBudgetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an array that summarizes each privacy budget in a specified collaboration. The summary includes the collaboration ARN, creation time, creating account, and privacy budget details.
 */
export declare const listCollaborationPrivacyBudgets: API.PaginatedOperationMethod<ListCollaborationPrivacyBudgetsInput, ListCollaborationPrivacyBudgetsOutput, ListCollaborationPrivacyBudgetsError, Credentials | HttpClient.HttpClient, CollaborationPrivacyBudgetSummary>;
export type ListCollaborationPrivacyBudgetTemplatesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an array that summarizes each privacy budget template in a specified collaboration.
 */
export declare const listCollaborationPrivacyBudgetTemplates: API.PaginatedOperationMethod<ListCollaborationPrivacyBudgetTemplatesInput, ListCollaborationPrivacyBudgetTemplatesOutput, ListCollaborationPrivacyBudgetTemplatesError, Credentials | HttpClient.HttpClient, CollaborationPrivacyBudgetTemplateSummary>;
export type ListCollaborationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists collaborations the caller owns, is active in, or has been invited to.
 */
export declare const listCollaborations: API.PaginatedOperationMethod<ListCollaborationsInput, ListCollaborationsOutput, ListCollaborationsError, Credentials | HttpClient.HttpClient, CollaborationSummary>;
export type ListConfiguredAudienceModelAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists information about requested configured audience model associations.
 */
export declare const listConfiguredAudienceModelAssociations: API.PaginatedOperationMethod<ListConfiguredAudienceModelAssociationsInput, ListConfiguredAudienceModelAssociationsOutput, ListConfiguredAudienceModelAssociationsError, Credentials | HttpClient.HttpClient, ConfiguredAudienceModelAssociationSummary>;
export type ListConfiguredTableAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists configured table associations for a membership.
 */
export declare const listConfiguredTableAssociations: API.PaginatedOperationMethod<ListConfiguredTableAssociationsInput, ListConfiguredTableAssociationsOutput, ListConfiguredTableAssociationsError, Credentials | HttpClient.HttpClient, ConfiguredTableAssociationSummary>;
export type ListConfiguredTablesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists configured tables.
 */
export declare const listConfiguredTables: API.PaginatedOperationMethod<ListConfiguredTablesInput, ListConfiguredTablesOutput, ListConfiguredTablesError, Credentials | HttpClient.HttpClient, ConfiguredTableSummary>;
export type ListIdMappingTablesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of ID mapping tables.
 */
export declare const listIdMappingTables: API.PaginatedOperationMethod<ListIdMappingTablesInput, ListIdMappingTablesOutput, ListIdMappingTablesError, Credentials | HttpClient.HttpClient, IdMappingTableSummary>;
export type ListIdNamespaceAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of ID namespace associations.
 */
export declare const listIdNamespaceAssociations: API.PaginatedOperationMethod<ListIdNamespaceAssociationsInput, ListIdNamespaceAssociationsOutput, ListIdNamespaceAssociationsError, Credentials | HttpClient.HttpClient, IdNamespaceAssociationSummary>;
export type ListIntermediateTablesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists intermediate tables owned by the caller in a membership. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listIntermediateTables: API.PaginatedOperationMethod<ListIntermediateTablesInput, ListIntermediateTablesOutput, ListIntermediateTablesError, Credentials | HttpClient.HttpClient, IntermediateTableSummary>;
export type ListIntermediateTableVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the version history of an intermediate table. Each call to `PopulateIntermediateTable` creates a new version. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listIntermediateTableVersions: API.PaginatedOperationMethod<ListIntermediateTableVersionsInput, ListIntermediateTableVersionsOutput, ListIntermediateTableVersionsError, Credentials | HttpClient.HttpClient, IntermediateTableVersionSummary>;
export type ListMembersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all members within a collaboration.
 */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersInput, ListMembersOutput, ListMembersError, Credentials | HttpClient.HttpClient, MemberSummary>;
export type ListMembershipsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all memberships resources within the caller's account.
 */
export declare const listMemberships: API.PaginatedOperationMethod<ListMembershipsInput, ListMembershipsOutput, ListMembershipsError, Credentials | HttpClient.HttpClient, MembershipSummary>;
export type ListPrivacyBudgetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed information about the privacy budgets in a specified membership.
 */
export declare const listPrivacyBudgets: API.PaginatedOperationMethod<ListPrivacyBudgetsInput, ListPrivacyBudgetsOutput, ListPrivacyBudgetsError, Credentials | HttpClient.HttpClient, PrivacyBudgetSummary>;
export type ListPrivacyBudgetTemplatesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed information about the privacy budget templates in a specified membership.
 */
export declare const listPrivacyBudgetTemplates: API.PaginatedOperationMethod<ListPrivacyBudgetTemplatesInput, ListPrivacyBudgetTemplatesOutput, ListPrivacyBudgetTemplatesError, Credentials | HttpClient.HttpClient, PrivacyBudgetTemplateSummary>;
export type ListProtectedJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists protected jobs, sorted by most recent job.
 */
export declare const listProtectedJobs: API.PaginatedOperationMethod<ListProtectedJobsInput, ListProtectedJobsOutput, ListProtectedJobsError, Credentials | HttpClient.HttpClient, ProtectedJobSummary>;
export type ListProtectedQueriesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists protected queries, sorted by the most recent query.
 */
export declare const listProtectedQueries: API.PaginatedOperationMethod<ListProtectedQueriesInput, ListProtectedQueriesOutput, ListProtectedQueriesError, Credentials | HttpClient.HttpClient, ProtectedQuerySummary>;
export type ListSchemasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the schemas for relations within a collaboration.
 */
export declare const listSchemas: API.PaginatedOperationMethod<ListSchemasInput, ListSchemasOutput, ListSchemasError, Credentials | HttpClient.HttpClient, SchemaSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all of the tags that have been added to a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PopulateIdMappingTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Defines the information that's necessary to populate an ID mapping table.
 */
export declare const populateIdMappingTable: API.OperationMethod<PopulateIdMappingTableInput, PopulateIdMappingTableOutput, PopulateIdMappingTableError, Credentials | HttpClient.HttpClient>;
export type PopulateIntermediateTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Runs the stored query of an intermediate table and makes the results available for querying. Each call creates a new version. Use `GetProtectedQuery` with the returned analysis ID to track progress. Only the intermediate table owner can call this operation.
 */
export declare const populateIntermediateTable: API.OperationMethod<PopulateIntermediateTableInput, PopulateIntermediateTableOutput, PopulateIntermediateTableError, Credentials | HttpClient.HttpClient>;
export type PreviewPrivacyImpactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * An estimate of the number of aggregation functions that the member who can query can run given epsilon and noise parameters.
 */
export declare const previewPrivacyImpact: API.OperationMethod<PreviewPrivacyImpactInput, PreviewPrivacyImpactOutput, PreviewPrivacyImpactError, Credentials | HttpClient.HttpClient>;
export type StartAnalysisLogExportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an export of the Apache Spark logs for a protected query to an Amazon S3 bucket that you own. Use the exported logs to diagnose a query that failed or that ran more slowly than you expected.
 *
 * Clean Rooms exports a redacted copy of the Spark logs instead of the raw logs. Analyze the exported logs with the tooling of your choice, such as Spark History Server. For details about what the exported logs contain, see https://docs.aws.amazon.com/clean-rooms/latest/userguide/export-analysis-logs-contents.html.
 *
 * The export runs asynchronously and returns with a `status` of `IN_PROGRESS`. Call `GetAnalysisLogExport` to poll for the final status.
 *
 * To use this operation, you must have the `CAN_EXPORT_QUERY_ANALYSIS_LOG` ability for your membership. You must also be the query runner or the query payer. Having the ability alone is not sufficient.
 *
 * The query must have reached a terminal state, and it must have reached the execution stage. A query that failed validation or that was canceled before it started produces no Spark logs.
 *
 * Log export isn't supported for queries that use differential privacy, and isn't supported for PySpark jobs.
 *
 * The destination bucket must be in the same Amazon Web Services Region as the collaboration. Cross-Region export isn't supported.
 *
 * For more information, see https://docs.aws.amazon.com/clean-rooms/latest/userguide/export-analysis-logs.html.
 */
export declare const startAnalysisLogExport: API.OperationMethod<StartAnalysisLogExportInput, StartAnalysisLogExportOutput, StartAnalysisLogExportError, Credentials | HttpClient.HttpClient>;
export type StartProtectedJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a protected job that is started by Clean Rooms.
 */
export declare const startProtectedJob: API.OperationMethod<StartProtectedJobInput, StartProtectedJobOutput, StartProtectedJobError, Credentials | HttpClient.HttpClient>;
export type StartProtectedQueryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a protected query that is started by Clean Rooms.
 */
export declare const startProtectedQuery: API.OperationMethod<StartProtectedQueryInput, StartProtectedQueryOutput, StartProtectedQueryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Tags a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag or list of tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAnalysisTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the analysis template metadata.
 */
export declare const updateAnalysisTemplate: API.OperationMethod<UpdateAnalysisTemplateInput, UpdateAnalysisTemplateOutput, UpdateAnalysisTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateCollaborationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates collaboration metadata and can only be called by the collaboration owner.
 */
export declare const updateCollaboration: API.OperationMethod<UpdateCollaborationInput, UpdateCollaborationOutput, UpdateCollaborationError, Credentials | HttpClient.HttpClient>;
export type UpdateCollaborationChangeRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing collaboration change request. This operation allows approval actions for pending change requests in collaborations (APPROVE, DENY, CANCEL, COMMIT).
 *
 * For change requests without automatic approval, a member in the collaboration can manually APPROVE or DENY a change request. The collaboration owner can manually CANCEL or COMMIT a change request.
 */
export declare const updateCollaborationChangeRequest: API.OperationMethod<UpdateCollaborationChangeRequestInput, UpdateCollaborationChangeRequestOutput, UpdateCollaborationChangeRequestError, Credentials | HttpClient.HttpClient>;
export type UpdateConfiguredAudienceModelAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the details necessary to update a configured audience model association.
 */
export declare const updateConfiguredAudienceModelAssociation: API.OperationMethod<UpdateConfiguredAudienceModelAssociationInput, UpdateConfiguredAudienceModelAssociationOutput, UpdateConfiguredAudienceModelAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateConfiguredTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a configured table.
 */
export declare const updateConfiguredTable: API.OperationMethod<UpdateConfiguredTableInput, UpdateConfiguredTableOutput, UpdateConfiguredTableError, Credentials | HttpClient.HttpClient>;
export type UpdateConfiguredTableAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a configured table analysis rule.
 */
export declare const updateConfiguredTableAnalysisRule: API.OperationMethod<UpdateConfiguredTableAnalysisRuleInput, UpdateConfiguredTableAnalysisRuleOutput, UpdateConfiguredTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateConfiguredTableAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a configured table association.
 */
export declare const updateConfiguredTableAssociation: API.OperationMethod<UpdateConfiguredTableAssociationInput, UpdateConfiguredTableAssociationOutput, UpdateConfiguredTableAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateConfiguredTableAssociationAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the analysis rule for a configured table association.
 */
export declare const updateConfiguredTableAssociationAnalysisRule: API.OperationMethod<UpdateConfiguredTableAssociationAnalysisRuleInput, UpdateConfiguredTableAssociationAnalysisRuleOutput, UpdateConfiguredTableAssociationAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateIdMappingTableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the details that are necessary to update an ID mapping table.
 */
export declare const updateIdMappingTable: API.OperationMethod<UpdateIdMappingTableInput, UpdateIdMappingTableOutput, UpdateIdMappingTableError, Credentials | HttpClient.HttpClient>;
export type UpdateIdNamespaceAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the details that are necessary to update an ID namespace association.
 */
export declare const updateIdNamespaceAssociation: API.OperationMethod<UpdateIdNamespaceAssociationInput, UpdateIdNamespaceAssociationOutput, UpdateIdNamespaceAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateIntermediateTableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an intermediate table. You can update the description, KMS key ARN, and column types of existing columns. Only the intermediate table owner can call this operation.
 */
export declare const updateIntermediateTable: API.OperationMethod<UpdateIntermediateTableInput, UpdateIntermediateTableOutput, UpdateIntermediateTableError, Credentials | HttpClient.HttpClient>;
export type UpdateIntermediateTableAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the analysis rule policy for an intermediate table. Only the intermediate table owner can call this operation.
 */
export declare const updateIntermediateTableAnalysisRule: API.OperationMethod<UpdateIntermediateTableAnalysisRuleInput, UpdateIntermediateTableAnalysisRuleOutput, UpdateIntermediateTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateMembershipError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a membership.
 */
export declare const updateMembership: API.OperationMethod<UpdateMembershipInput, UpdateMembershipOutput, UpdateMembershipError, Credentials | HttpClient.HttpClient>;
export type UpdatePrivacyBudgetTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the privacy budget template for the specified collaboration.
 */
export declare const updatePrivacyBudgetTemplate: API.OperationMethod<UpdatePrivacyBudgetTemplateInput, UpdatePrivacyBudgetTemplateOutput, UpdatePrivacyBudgetTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateProtectedJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the processing of a currently running job.
 */
export declare const updateProtectedJob: API.OperationMethod<UpdateProtectedJobInput, UpdateProtectedJobOutput, UpdateProtectedJobError, Credentials | HttpClient.HttpClient>;
export type UpdateProtectedQueryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the processing of a currently running query.
 */
export declare const updateProtectedQuery: API.OperationMethod<UpdateProtectedQueryInput, UpdateProtectedQueryOutput, UpdateProtectedQueryError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cleanrooms.d.ts.map