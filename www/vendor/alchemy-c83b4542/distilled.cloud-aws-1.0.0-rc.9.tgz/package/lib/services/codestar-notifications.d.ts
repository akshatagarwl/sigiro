import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConcurrentModificationException_base: S.Class<ConcurrentModificationException, S.TaggedStruct<"ConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConfigurationException_base: S.Class<ConfigurationException, S.TaggedStruct<"ConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConfigurationException extends /*@__PURE__*/ ConfigurationException_base {
}
declare const InvalidNextTokenException_base: S.Class<InvalidNextTokenException, S.TaggedStruct<"InvalidNextTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.Class<ResourceAlreadyExistsException, S.TaggedStruct<"ResourceAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type NotificationRuleName = string | redacted.Redacted<string>;
export type EventTypeId = string;
export type EventTypeIds = string[];
export declare const EventTypeIds: any;
export type NotificationRuleResource = string;
export type TargetType = string;
export type TargetAddress = string | redacted.Redacted<string>;
export interface Target {
    TargetType?: string;
    TargetAddress?: string | redacted.Redacted<string>;
}
export declare const Target: S.Schema<Target>;
export type Targets = Target[];
export declare const Targets: any;
export type DetailType = "BASIC" | "FULL" | (string & {});
export declare const DetailType: any;
export type ClientRequestToken = string;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export type NotificationRuleStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const NotificationRuleStatus: any;
export interface CreateNotificationRuleRequest {
    Name: string | redacted.Redacted<string>;
    EventTypeIds: string[];
    Resource: string;
    Targets: Target[];
    DetailType: DetailType;
    ClientRequestToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Status?: NotificationRuleStatus;
}
export declare const CreateNotificationRuleRequest: S.Schema<CreateNotificationRuleRequest>;
export type NotificationRuleArn = string;
export interface CreateNotificationRuleResult {
    Arn?: string;
}
export declare const CreateNotificationRuleResult: S.Schema<CreateNotificationRuleResult>;
export interface DeleteNotificationRuleRequest {
    Arn: string;
}
export declare const DeleteNotificationRuleRequest: S.Schema<DeleteNotificationRuleRequest>;
export interface DeleteNotificationRuleResult {
    Arn?: string;
}
export declare const DeleteNotificationRuleResult: S.Schema<DeleteNotificationRuleResult>;
export type ForceUnsubscribeAll = boolean;
export interface DeleteTargetRequest {
    TargetAddress: string | redacted.Redacted<string>;
    ForceUnsubscribeAll?: boolean;
}
export declare const DeleteTargetRequest: S.Schema<DeleteTargetRequest>;
export interface DeleteTargetResult {
}
export declare const DeleteTargetResult: S.Schema<DeleteTargetResult>;
export interface DescribeNotificationRuleRequest {
    Arn: string;
}
export declare const DescribeNotificationRuleRequest: S.Schema<DescribeNotificationRuleRequest>;
export type ServiceName = string;
export type EventTypeName = string;
export type ResourceType = string;
export interface EventTypeSummary {
    EventTypeId?: string;
    ServiceName?: string;
    EventTypeName?: string;
    ResourceType?: string;
}
export declare const EventTypeSummary: S.Schema<EventTypeSummary>;
export type EventTypeBatch = EventTypeSummary[];
export declare const EventTypeBatch: any;
export type TargetStatus = "PENDING" | "ACTIVE" | "UNREACHABLE" | "INACTIVE" | "DEACTIVATED" | (string & {});
export declare const TargetStatus: any;
export interface TargetSummary {
    TargetAddress?: string | redacted.Redacted<string>;
    TargetType?: string;
    TargetStatus?: TargetStatus;
}
export declare const TargetSummary: S.Schema<TargetSummary>;
export type TargetsBatch = TargetSummary[];
export declare const TargetsBatch: any;
export type NotificationRuleCreatedBy = string;
export type CreatedTimestamp = Date;
export type LastModifiedTimestamp = Date;
export interface DescribeNotificationRuleResult {
    Arn: string;
    Name?: string | redacted.Redacted<string>;
    EventTypes?: EventTypeSummary[];
    Resource?: string;
    Targets?: TargetSummary[];
    DetailType?: DetailType;
    CreatedBy?: string;
    Status?: NotificationRuleStatus;
    CreatedTimestamp?: Date;
    LastModifiedTimestamp?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DescribeNotificationRuleResult: S.Schema<DescribeNotificationRuleResult>;
export type ListEventTypesFilterName = "RESOURCE_TYPE" | "SERVICE_NAME" | (string & {});
export declare const ListEventTypesFilterName: any;
export type ListEventTypesFilterValue = string;
export interface ListEventTypesFilter {
    Name: ListEventTypesFilterName;
    Value: string;
}
export declare const ListEventTypesFilter: S.Schema<ListEventTypesFilter>;
export type ListEventTypesFilters = ListEventTypesFilter[];
export declare const ListEventTypesFilters: any;
export type NextToken = string;
export type MaxResults = number;
export interface ListEventTypesRequest {
    Filters?: ListEventTypesFilter[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEventTypesRequest: S.Schema<ListEventTypesRequest>;
export interface ListEventTypesResult {
    EventTypes?: EventTypeSummary[];
    NextToken?: string;
}
export declare const ListEventTypesResult: S.Schema<ListEventTypesResult>;
export type ListNotificationRulesFilterName = "EVENT_TYPE_ID" | "CREATED_BY" | "RESOURCE" | "TARGET_ADDRESS" | (string & {});
export declare const ListNotificationRulesFilterName: any;
export type ListNotificationRulesFilterValue = string;
export interface ListNotificationRulesFilter {
    Name: ListNotificationRulesFilterName;
    Value: string;
}
export declare const ListNotificationRulesFilter: S.Schema<ListNotificationRulesFilter>;
export type ListNotificationRulesFilters = ListNotificationRulesFilter[];
export declare const ListNotificationRulesFilters: any;
export interface ListNotificationRulesRequest {
    Filters?: ListNotificationRulesFilter[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListNotificationRulesRequest: S.Schema<ListNotificationRulesRequest>;
export type NotificationRuleId = string;
export interface NotificationRuleSummary {
    Id?: string;
    Arn?: string;
}
export declare const NotificationRuleSummary: S.Schema<NotificationRuleSummary>;
export type NotificationRuleBatch = NotificationRuleSummary[];
export declare const NotificationRuleBatch: any;
export interface ListNotificationRulesResult {
    NextToken?: string;
    NotificationRules?: NotificationRuleSummary[];
}
export declare const ListNotificationRulesResult: S.Schema<ListNotificationRulesResult>;
export interface ListTagsForResourceRequest {
    Arn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResult {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResult: S.Schema<ListTagsForResourceResult>;
export type ListTargetsFilterName = "TARGET_TYPE" | "TARGET_ADDRESS" | "TARGET_STATUS" | (string & {});
export declare const ListTargetsFilterName: any;
export type ListTargetsFilterValue = string;
export interface ListTargetsFilter {
    Name: ListTargetsFilterName;
    Value: string;
}
export declare const ListTargetsFilter: S.Schema<ListTargetsFilter>;
export type ListTargetsFilters = ListTargetsFilter[];
export declare const ListTargetsFilters: any;
export interface ListTargetsRequest {
    Filters?: ListTargetsFilter[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListTargetsRequest: S.Schema<ListTargetsRequest>;
export interface ListTargetsResult {
    Targets?: TargetSummary[];
    NextToken?: string;
}
export declare const ListTargetsResult: S.Schema<ListTargetsResult>;
export interface SubscribeRequest {
    Arn: string;
    Target: Target;
    ClientRequestToken?: string;
}
export declare const SubscribeRequest: S.Schema<SubscribeRequest>;
export interface SubscribeResult {
    Arn?: string;
}
export declare const SubscribeResult: S.Schema<SubscribeResult>;
export interface TagResourceRequest {
    Arn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResult {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceResult: S.Schema<TagResourceResult>;
export interface UnsubscribeRequest {
    Arn: string;
    TargetAddress: string | redacted.Redacted<string>;
}
export declare const UnsubscribeRequest: S.Schema<UnsubscribeRequest>;
export interface UnsubscribeResult {
    Arn: string;
}
export declare const UnsubscribeResult: S.Schema<UnsubscribeResult>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    Arn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResult {
}
export declare const UntagResourceResult: S.Schema<UntagResourceResult>;
export interface UpdateNotificationRuleRequest {
    Arn: string;
    Name?: string | redacted.Redacted<string>;
    Status?: NotificationRuleStatus;
    EventTypeIds?: string[];
    Targets?: Target[];
    DetailType?: DetailType;
}
export declare const UpdateNotificationRuleRequest: S.Schema<UpdateNotificationRuleRequest>;
export interface UpdateNotificationRuleResult {
}
export declare const UpdateNotificationRuleResult: S.Schema<UpdateNotificationRuleResult>;
export type Message = string;
export type CreateNotificationRuleError = AccessDeniedException | ConcurrentModificationException | ConfigurationException | LimitExceededException | ResourceAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates a notification rule for a resource. The rule specifies the events you want
 * notifications about and the targets (such as Amazon Q Developer in chat applications topics or Amazon Q Developer in chat applications clients configured for Slack) where you want to receive
 * them.
 */
export declare const createNotificationRule: API.OperationMethod<CreateNotificationRuleRequest, CreateNotificationRuleResult, CreateNotificationRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteNotificationRuleError = ConcurrentModificationException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Deletes a notification rule for a resource.
 */
export declare const deleteNotificationRule: API.OperationMethod<DeleteNotificationRuleRequest, DeleteNotificationRuleResult, DeleteNotificationRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteTargetError = ValidationException | CommonErrors;
/**
 * Deletes a specified target for notifications.
 */
export declare const deleteTarget: API.OperationMethod<DeleteTargetRequest, DeleteTargetResult, DeleteTargetError, Credentials | HttpClient.HttpClient>;
export type DescribeNotificationRuleError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a specified notification rule.
 */
export declare const describeNotificationRule: API.OperationMethod<DescribeNotificationRuleRequest, DescribeNotificationRuleResult, DescribeNotificationRuleError, Credentials | HttpClient.HttpClient>;
export type ListEventTypesError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Returns information about the event types available for configuring notifications.
 */
export declare const listEventTypes: API.PaginatedOperationMethod<ListEventTypesRequest, ListEventTypesResult, ListEventTypesError, Credentials | HttpClient.HttpClient, EventTypeSummary>;
export type ListNotificationRulesError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Returns a list of the notification rules for an Amazon Web Services account.
 */
export declare const listNotificationRules: API.PaginatedOperationMethod<ListNotificationRulesRequest, ListNotificationRulesResult, ListNotificationRulesError, Credentials | HttpClient.HttpClient, NotificationRuleSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of the tags associated with a notification rule.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResult, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTargetsError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Returns a list of the notification rule targets for an Amazon Web Services account.
 */
export declare const listTargets: API.PaginatedOperationMethod<ListTargetsRequest, ListTargetsResult, ListTargetsError, Credentials | HttpClient.HttpClient, TargetSummary>;
export type SubscribeError = ConfigurationException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates an association between a notification rule and an Amazon Q Developer in chat applications topic or Amazon Q Developer in chat applications client so that the
 * associated target can receive notifications when the events described in the rule are
 * triggered.
 */
export declare const subscribe: API.OperationMethod<SubscribeRequest, SubscribeResult, SubscribeError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConcurrentModificationException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Associates a set of provided tags with a notification rule.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResult, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UnsubscribeError = ValidationException | CommonErrors;
/**
 * Removes an association between a notification rule and an Amazon Q Developer in chat applications topic so that
 * subscribers to that topic stop receiving notifications when the events described in the
 * rule are triggered.
 */
export declare const unsubscribe: API.OperationMethod<UnsubscribeRequest, UnsubscribeResult, UnsubscribeError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConcurrentModificationException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the association between one or more provided tags and a notification
 * rule.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResult, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateNotificationRuleError = ConfigurationException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a notification rule for a resource. You can change the events that trigger the
 * notification rule, the status of the rule, and the targets that receive the
 * notifications.
 *
 * To add or remove tags for a notification rule, you must use TagResource and UntagResource.
 */
export declare const updateNotificationRule: API.OperationMethod<UpdateNotificationRuleRequest, UpdateNotificationRuleResult, UpdateNotificationRuleError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codestar-notifications.d.ts.map