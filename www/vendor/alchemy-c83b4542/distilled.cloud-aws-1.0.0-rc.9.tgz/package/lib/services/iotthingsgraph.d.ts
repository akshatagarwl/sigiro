import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalFailureException_base: S.Class<InternalFailureException, S.TaggedStruct<"InternalFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.Class<ResourceAlreadyExistsException, S.TaggedStruct<"ResourceAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type ThingName = string;
export type Urn = string;
export type Version = number;
export interface AssociateEntityToThingRequest {
    thingName: string;
    entityId: string;
    namespaceVersion?: number;
}
export declare const AssociateEntityToThingRequest: S.Schema<AssociateEntityToThingRequest>;
export interface AssociateEntityToThingResponse {
}
export declare const AssociateEntityToThingResponse: S.Schema<AssociateEntityToThingResponse>;
export type DefinitionLanguage = "GRAPHQL" | (string & {});
export declare const DefinitionLanguage: any;
export type DefinitionText = string;
export interface DefinitionDocument {
    language: DefinitionLanguage;
    text: string;
}
export declare const DefinitionDocument: S.Schema<DefinitionDocument>;
export interface CreateFlowTemplateRequest {
    definition: DefinitionDocument;
    compatibleNamespaceVersion?: number;
}
export declare const CreateFlowTemplateRequest: S.Schema<CreateFlowTemplateRequest>;
export type Arn = string;
export interface FlowTemplateSummary {
    id?: string;
    arn?: string;
    revisionNumber?: number;
    createdAt?: Date;
}
export declare const FlowTemplateSummary: S.Schema<FlowTemplateSummary>;
export interface CreateFlowTemplateResponse {
    summary?: FlowTemplateSummary;
}
export declare const CreateFlowTemplateResponse: S.Schema<CreateFlowTemplateResponse>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type DeploymentTarget = "GREENGRASS" | "CLOUD" | (string & {});
export declare const DeploymentTarget: any;
export type GroupName = string;
export type S3BucketName = string;
export type Enabled = boolean;
export type RoleArn = string;
export interface MetricsConfiguration {
    cloudMetricEnabled?: boolean;
    metricRuleRoleArn?: string;
}
export declare const MetricsConfiguration: S.Schema<MetricsConfiguration>;
export interface CreateSystemInstanceRequest {
    tags?: Tag[];
    definition: DefinitionDocument;
    target: DeploymentTarget;
    greengrassGroupName?: string;
    s3BucketName?: string;
    metricsConfiguration?: MetricsConfiguration;
    flowActionsRoleArn?: string;
}
export declare const CreateSystemInstanceRequest: S.Schema<CreateSystemInstanceRequest>;
export type SystemInstanceDeploymentStatus = "NOT_DEPLOYED" | "BOOTSTRAP" | "DEPLOY_IN_PROGRESS" | "DEPLOYED_IN_TARGET" | "UNDEPLOY_IN_PROGRESS" | "FAILED" | "PENDING_DELETE" | "DELETED_IN_TARGET" | (string & {});
export declare const SystemInstanceDeploymentStatus: any;
export type GreengrassGroupId = string;
export type GreengrassGroupVersionId = string;
export interface SystemInstanceSummary {
    id?: string;
    arn?: string;
    status?: SystemInstanceDeploymentStatus;
    target?: DeploymentTarget;
    greengrassGroupName?: string;
    createdAt?: Date;
    updatedAt?: Date;
    greengrassGroupId?: string;
    greengrassGroupVersionId?: string;
}
export declare const SystemInstanceSummary: S.Schema<SystemInstanceSummary>;
export interface CreateSystemInstanceResponse {
    summary?: SystemInstanceSummary;
}
export declare const CreateSystemInstanceResponse: S.Schema<CreateSystemInstanceResponse>;
export interface CreateSystemTemplateRequest {
    definition: DefinitionDocument;
    compatibleNamespaceVersion?: number;
}
export declare const CreateSystemTemplateRequest: S.Schema<CreateSystemTemplateRequest>;
export interface SystemTemplateSummary {
    id?: string;
    arn?: string;
    revisionNumber?: number;
    createdAt?: Date;
}
export declare const SystemTemplateSummary: S.Schema<SystemTemplateSummary>;
export interface CreateSystemTemplateResponse {
    summary?: SystemTemplateSummary;
}
export declare const CreateSystemTemplateResponse: S.Schema<CreateSystemTemplateResponse>;
export interface DeleteFlowTemplateRequest {
    id: string;
}
export declare const DeleteFlowTemplateRequest: S.Schema<DeleteFlowTemplateRequest>;
export interface DeleteFlowTemplateResponse {
}
export declare const DeleteFlowTemplateResponse: S.Schema<DeleteFlowTemplateResponse>;
export interface DeleteNamespaceRequest {
}
export declare const DeleteNamespaceRequest: S.Schema<DeleteNamespaceRequest>;
export type NamespaceName = string;
export interface DeleteNamespaceResponse {
    namespaceArn?: string;
    namespaceName?: string;
}
export declare const DeleteNamespaceResponse: S.Schema<DeleteNamespaceResponse>;
export interface DeleteSystemInstanceRequest {
    id?: string;
}
export declare const DeleteSystemInstanceRequest: S.Schema<DeleteSystemInstanceRequest>;
export interface DeleteSystemInstanceResponse {
}
export declare const DeleteSystemInstanceResponse: S.Schema<DeleteSystemInstanceResponse>;
export interface DeleteSystemTemplateRequest {
    id: string;
}
export declare const DeleteSystemTemplateRequest: S.Schema<DeleteSystemTemplateRequest>;
export interface DeleteSystemTemplateResponse {
}
export declare const DeleteSystemTemplateResponse: S.Schema<DeleteSystemTemplateResponse>;
export interface DeploySystemInstanceRequest {
    id?: string;
}
export declare const DeploySystemInstanceRequest: S.Schema<DeploySystemInstanceRequest>;
export type GreengrassDeploymentId = string;
export interface DeploySystemInstanceResponse {
    summary: SystemInstanceSummary;
    greengrassDeploymentId?: string;
}
export declare const DeploySystemInstanceResponse: S.Schema<DeploySystemInstanceResponse>;
export interface DeprecateFlowTemplateRequest {
    id: string;
}
export declare const DeprecateFlowTemplateRequest: S.Schema<DeprecateFlowTemplateRequest>;
export interface DeprecateFlowTemplateResponse {
}
export declare const DeprecateFlowTemplateResponse: S.Schema<DeprecateFlowTemplateResponse>;
export interface DeprecateSystemTemplateRequest {
    id: string;
}
export declare const DeprecateSystemTemplateRequest: S.Schema<DeprecateSystemTemplateRequest>;
export interface DeprecateSystemTemplateResponse {
}
export declare const DeprecateSystemTemplateResponse: S.Schema<DeprecateSystemTemplateResponse>;
export interface DescribeNamespaceRequest {
    namespaceName?: string;
}
export declare const DescribeNamespaceRequest: S.Schema<DescribeNamespaceRequest>;
export interface DescribeNamespaceResponse {
    namespaceArn?: string;
    namespaceName?: string;
    trackingNamespaceName?: string;
    trackingNamespaceVersion?: number;
    namespaceVersion?: number;
}
export declare const DescribeNamespaceResponse: S.Schema<DescribeNamespaceResponse>;
export type EntityType = "DEVICE" | "SERVICE" | "DEVICE_MODEL" | "CAPABILITY" | "STATE" | "ACTION" | "EVENT" | "PROPERTY" | "MAPPING" | "ENUM" | (string & {});
export declare const EntityType: any;
export interface DissociateEntityFromThingRequest {
    thingName: string;
    entityType: EntityType;
}
export declare const DissociateEntityFromThingRequest: S.Schema<DissociateEntityFromThingRequest>;
export interface DissociateEntityFromThingResponse {
}
export declare const DissociateEntityFromThingResponse: S.Schema<DissociateEntityFromThingResponse>;
export type Urns = string[];
export declare const Urns: any;
export interface GetEntitiesRequest {
    ids: string[];
    namespaceVersion?: number;
}
export declare const GetEntitiesRequest: S.Schema<GetEntitiesRequest>;
export interface EntityDescription {
    id?: string;
    arn?: string;
    type?: EntityType;
    createdAt?: Date;
    definition?: DefinitionDocument;
}
export declare const EntityDescription: S.Schema<EntityDescription>;
export type EntityDescriptions = EntityDescription[];
export declare const EntityDescriptions: any;
export interface GetEntitiesResponse {
    descriptions?: EntityDescription[];
}
export declare const GetEntitiesResponse: S.Schema<GetEntitiesResponse>;
export interface GetFlowTemplateRequest {
    id: string;
    revisionNumber?: number;
}
export declare const GetFlowTemplateRequest: S.Schema<GetFlowTemplateRequest>;
export interface FlowTemplateDescription {
    summary?: FlowTemplateSummary;
    definition?: DefinitionDocument;
    validatedNamespaceVersion?: number;
}
export declare const FlowTemplateDescription: S.Schema<FlowTemplateDescription>;
export interface GetFlowTemplateResponse {
    description?: FlowTemplateDescription;
}
export declare const GetFlowTemplateResponse: S.Schema<GetFlowTemplateResponse>;
export type NextToken = string;
export type MaxResults = number;
export interface GetFlowTemplateRevisionsRequest {
    id: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetFlowTemplateRevisionsRequest: S.Schema<GetFlowTemplateRevisionsRequest>;
export type FlowTemplateSummaries = FlowTemplateSummary[];
export declare const FlowTemplateSummaries: any;
export interface GetFlowTemplateRevisionsResponse {
    summaries?: FlowTemplateSummary[];
    nextToken?: string;
}
export declare const GetFlowTemplateRevisionsResponse: S.Schema<GetFlowTemplateRevisionsResponse>;
export interface GetNamespaceDeletionStatusRequest {
}
export declare const GetNamespaceDeletionStatusRequest: S.Schema<GetNamespaceDeletionStatusRequest>;
export type NamespaceDeletionStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const NamespaceDeletionStatus: any;
export type NamespaceDeletionStatusErrorCodes = "VALIDATION_FAILED" | (string & {});
export declare const NamespaceDeletionStatusErrorCodes: any;
export interface GetNamespaceDeletionStatusResponse {
    namespaceArn?: string;
    namespaceName?: string;
    status?: NamespaceDeletionStatus;
    errorCode?: NamespaceDeletionStatusErrorCodes;
    errorMessage?: string;
}
export declare const GetNamespaceDeletionStatusResponse: S.Schema<GetNamespaceDeletionStatusResponse>;
export interface GetSystemInstanceRequest {
    id: string;
}
export declare const GetSystemInstanceRequest: S.Schema<GetSystemInstanceRequest>;
export interface DependencyRevision {
    id?: string;
    revisionNumber?: number;
}
export declare const DependencyRevision: S.Schema<DependencyRevision>;
export type DependencyRevisions = DependencyRevision[];
export declare const DependencyRevisions: any;
export interface SystemInstanceDescription {
    summary?: SystemInstanceSummary;
    definition?: DefinitionDocument;
    s3BucketName?: string;
    metricsConfiguration?: MetricsConfiguration;
    validatedNamespaceVersion?: number;
    validatedDependencyRevisions?: DependencyRevision[];
    flowActionsRoleArn?: string;
}
export declare const SystemInstanceDescription: S.Schema<SystemInstanceDescription>;
export interface GetSystemInstanceResponse {
    description?: SystemInstanceDescription;
}
export declare const GetSystemInstanceResponse: S.Schema<GetSystemInstanceResponse>;
export interface GetSystemTemplateRequest {
    id: string;
    revisionNumber?: number;
}
export declare const GetSystemTemplateRequest: S.Schema<GetSystemTemplateRequest>;
export interface SystemTemplateDescription {
    summary?: SystemTemplateSummary;
    definition?: DefinitionDocument;
    validatedNamespaceVersion?: number;
}
export declare const SystemTemplateDescription: S.Schema<SystemTemplateDescription>;
export interface GetSystemTemplateResponse {
    description?: SystemTemplateDescription;
}
export declare const GetSystemTemplateResponse: S.Schema<GetSystemTemplateResponse>;
export interface GetSystemTemplateRevisionsRequest {
    id: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetSystemTemplateRevisionsRequest: S.Schema<GetSystemTemplateRevisionsRequest>;
export type SystemTemplateSummaries = SystemTemplateSummary[];
export declare const SystemTemplateSummaries: any;
export interface GetSystemTemplateRevisionsResponse {
    summaries?: SystemTemplateSummary[];
    nextToken?: string;
}
export declare const GetSystemTemplateRevisionsResponse: S.Schema<GetSystemTemplateRevisionsResponse>;
export type UploadId = string;
export interface GetUploadStatusRequest {
    uploadId: string;
}
export declare const GetUploadStatusRequest: S.Schema<GetUploadStatusRequest>;
export type UploadStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const UploadStatus: any;
export type StringList = string[];
export declare const StringList: any;
export interface GetUploadStatusResponse {
    uploadId: string;
    uploadStatus: UploadStatus;
    namespaceArn?: string;
    namespaceName?: string;
    namespaceVersion?: number;
    failureReason?: string[];
    createdDate: Date;
}
export declare const GetUploadStatusResponse: S.Schema<GetUploadStatusResponse>;
export type FlowExecutionId = string;
export interface ListFlowExecutionMessagesRequest {
    flowExecutionId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListFlowExecutionMessagesRequest: S.Schema<ListFlowExecutionMessagesRequest>;
export type FlowExecutionMessageId = string;
export type FlowExecutionEventType = "EXECUTION_STARTED" | "EXECUTION_FAILED" | "EXECUTION_ABORTED" | "EXECUTION_SUCCEEDED" | "STEP_STARTED" | "STEP_FAILED" | "STEP_SUCCEEDED" | "ACTIVITY_SCHEDULED" | "ACTIVITY_STARTED" | "ACTIVITY_FAILED" | "ACTIVITY_SUCCEEDED" | "START_FLOW_EXECUTION_TASK" | "SCHEDULE_NEXT_READY_STEPS_TASK" | "THING_ACTION_TASK" | "THING_ACTION_TASK_FAILED" | "THING_ACTION_TASK_SUCCEEDED" | "ACKNOWLEDGE_TASK_MESSAGE" | (string & {});
export declare const FlowExecutionEventType: any;
export type FlowExecutionMessagePayload = string;
export interface FlowExecutionMessage {
    messageId?: string;
    eventType?: FlowExecutionEventType;
    timestamp?: Date;
    payload?: string;
}
export declare const FlowExecutionMessage: S.Schema<FlowExecutionMessage>;
export type FlowExecutionMessages = FlowExecutionMessage[];
export declare const FlowExecutionMessages: any;
export interface ListFlowExecutionMessagesResponse {
    messages?: FlowExecutionMessage[];
    nextToken?: string;
}
export declare const ListFlowExecutionMessagesResponse: S.Schema<ListFlowExecutionMessagesResponse>;
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    maxResults?: number;
    resourceArn: string;
    nextToken?: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: Tag[];
    nextToken?: string;
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type EntityTypes = EntityType[];
export declare const EntityTypes: any;
export type EntityFilterName = "NAME" | "NAMESPACE" | "SEMANTIC_TYPE_PATH" | "REFERENCED_ENTITY_ID" | (string & {});
export declare const EntityFilterName: any;
export type EntityFilterValue = string;
export type EntityFilterValues = string[];
export declare const EntityFilterValues: any;
export interface EntityFilter {
    name?: EntityFilterName;
    value?: string[];
}
export declare const EntityFilter: S.Schema<EntityFilter>;
export type EntityFilters = EntityFilter[];
export declare const EntityFilters: any;
export interface SearchEntitiesRequest {
    entityTypes: EntityType[];
    filters?: EntityFilter[];
    nextToken?: string;
    maxResults?: number;
    namespaceVersion?: number;
}
export declare const SearchEntitiesRequest: S.Schema<SearchEntitiesRequest>;
export interface SearchEntitiesResponse {
    descriptions?: EntityDescription[];
    nextToken?: string;
}
export declare const SearchEntitiesResponse: S.Schema<SearchEntitiesResponse>;
export interface SearchFlowExecutionsRequest {
    systemInstanceId: string;
    flowExecutionId?: string;
    startTime?: Date;
    endTime?: Date;
    nextToken?: string;
    maxResults?: number;
}
export declare const SearchFlowExecutionsRequest: S.Schema<SearchFlowExecutionsRequest>;
export type FlowExecutionStatus = "RUNNING" | "ABORTED" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const FlowExecutionStatus: any;
export interface FlowExecutionSummary {
    flowExecutionId?: string;
    status?: FlowExecutionStatus;
    systemInstanceId?: string;
    flowTemplateId?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const FlowExecutionSummary: S.Schema<FlowExecutionSummary>;
export type FlowExecutionSummaries = FlowExecutionSummary[];
export declare const FlowExecutionSummaries: any;
export interface SearchFlowExecutionsResponse {
    summaries?: FlowExecutionSummary[];
    nextToken?: string;
}
export declare const SearchFlowExecutionsResponse: S.Schema<SearchFlowExecutionsResponse>;
export type FlowTemplateFilterName = "DEVICE_MODEL_ID" | (string & {});
export declare const FlowTemplateFilterName: any;
export type FlowTemplateFilterValue = string;
export type FlowTemplateFilterValues = string[];
export declare const FlowTemplateFilterValues: any;
export interface FlowTemplateFilter {
    name: FlowTemplateFilterName;
    value: string[];
}
export declare const FlowTemplateFilter: S.Schema<FlowTemplateFilter>;
export type FlowTemplateFilters = FlowTemplateFilter[];
export declare const FlowTemplateFilters: any;
export interface SearchFlowTemplatesRequest {
    filters?: FlowTemplateFilter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const SearchFlowTemplatesRequest: S.Schema<SearchFlowTemplatesRequest>;
export interface SearchFlowTemplatesResponse {
    summaries?: FlowTemplateSummary[];
    nextToken?: string;
}
export declare const SearchFlowTemplatesResponse: S.Schema<SearchFlowTemplatesResponse>;
export type SystemInstanceFilterName = "SYSTEM_TEMPLATE_ID" | "STATUS" | "GREENGRASS_GROUP_NAME" | (string & {});
export declare const SystemInstanceFilterName: any;
export type SystemInstanceFilterValue = string;
export type SystemInstanceFilterValues = string[];
export declare const SystemInstanceFilterValues: any;
export interface SystemInstanceFilter {
    name?: SystemInstanceFilterName;
    value?: string[];
}
export declare const SystemInstanceFilter: S.Schema<SystemInstanceFilter>;
export type SystemInstanceFilters = SystemInstanceFilter[];
export declare const SystemInstanceFilters: any;
export interface SearchSystemInstancesRequest {
    filters?: SystemInstanceFilter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const SearchSystemInstancesRequest: S.Schema<SearchSystemInstancesRequest>;
export type SystemInstanceSummaries = SystemInstanceSummary[];
export declare const SystemInstanceSummaries: any;
export interface SearchSystemInstancesResponse {
    summaries?: SystemInstanceSummary[];
    nextToken?: string;
}
export declare const SearchSystemInstancesResponse: S.Schema<SearchSystemInstancesResponse>;
export type SystemTemplateFilterName = "FLOW_TEMPLATE_ID" | (string & {});
export declare const SystemTemplateFilterName: any;
export type SystemTemplateFilterValue = string;
export type SystemTemplateFilterValues = string[];
export declare const SystemTemplateFilterValues: any;
export interface SystemTemplateFilter {
    name: SystemTemplateFilterName;
    value: string[];
}
export declare const SystemTemplateFilter: S.Schema<SystemTemplateFilter>;
export type SystemTemplateFilters = SystemTemplateFilter[];
export declare const SystemTemplateFilters: any;
export interface SearchSystemTemplatesRequest {
    filters?: SystemTemplateFilter[];
    nextToken?: string;
    maxResults?: number;
}
export declare const SearchSystemTemplatesRequest: S.Schema<SearchSystemTemplatesRequest>;
export interface SearchSystemTemplatesResponse {
    summaries?: SystemTemplateSummary[];
    nextToken?: string;
}
export declare const SearchSystemTemplatesResponse: S.Schema<SearchSystemTemplatesResponse>;
export interface SearchThingsRequest {
    entityId: string;
    nextToken?: string;
    maxResults?: number;
    namespaceVersion?: number;
}
export declare const SearchThingsRequest: S.Schema<SearchThingsRequest>;
export type ThingArn = string;
export interface Thing {
    thingArn?: string;
    thingName?: string;
}
export declare const Thing: S.Schema<Thing>;
export type Things = Thing[];
export declare const Things: any;
export interface SearchThingsResponse {
    things?: Thing[];
    nextToken?: string;
}
export declare const SearchThingsResponse: S.Schema<SearchThingsResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface UndeploySystemInstanceRequest {
    id?: string;
}
export declare const UndeploySystemInstanceRequest: S.Schema<UndeploySystemInstanceRequest>;
export interface UndeploySystemInstanceResponse {
    summary?: SystemInstanceSummary;
}
export declare const UndeploySystemInstanceResponse: S.Schema<UndeploySystemInstanceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateFlowTemplateRequest {
    id: string;
    definition: DefinitionDocument;
    compatibleNamespaceVersion?: number;
}
export declare const UpdateFlowTemplateRequest: S.Schema<UpdateFlowTemplateRequest>;
export interface UpdateFlowTemplateResponse {
    summary?: FlowTemplateSummary;
}
export declare const UpdateFlowTemplateResponse: S.Schema<UpdateFlowTemplateResponse>;
export interface UpdateSystemTemplateRequest {
    id: string;
    definition: DefinitionDocument;
    compatibleNamespaceVersion?: number;
}
export declare const UpdateSystemTemplateRequest: S.Schema<UpdateSystemTemplateRequest>;
export interface UpdateSystemTemplateResponse {
    summary?: SystemTemplateSummary;
}
export declare const UpdateSystemTemplateResponse: S.Schema<UpdateSystemTemplateResponse>;
export type SyncWithPublicNamespace = boolean;
export type DeprecateExistingEntities = boolean;
export interface UploadEntityDefinitionsRequest {
    document?: DefinitionDocument;
    syncWithPublicNamespace?: boolean;
    deprecateExistingEntities?: boolean;
}
export declare const UploadEntityDefinitionsRequest: S.Schema<UploadEntityDefinitionsRequest>;
export interface UploadEntityDefinitionsResponse {
    uploadId: string;
}
export declare const UploadEntityDefinitionsResponse: S.Schema<UploadEntityDefinitionsResponse>;
export type ErrorMessage = string;
export type AssociateEntityToThingError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a device with a concrete thing that is in the user's registry.
 *
 * A thing can be associated with only one device at a time. If you associate a thing with a new device id, its previous association will be removed.
 */
export declare const associateEntityToThing: API.OperationMethod<AssociateEntityToThingRequest, AssociateEntityToThingResponse, AssociateEntityToThingError, Credentials | HttpClient.HttpClient>;
export type CreateFlowTemplateError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a workflow template. Workflows can be created only in the user's namespace. (The public namespace contains only
 * entities.) The workflow can contain only entities in the specified namespace. The workflow is validated against the entities in the
 * latest version of the user's namespace unless another namespace version is specified in the request.
 */
export declare const createFlowTemplate: API.OperationMethod<CreateFlowTemplateRequest, CreateFlowTemplateResponse, CreateFlowTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateSystemInstanceError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a system instance.
 *
 * This action validates the system instance, prepares the deployment-related resources. For Greengrass deployments, it updates the Greengrass group that is
 * specified by the `greengrassGroupName` parameter. It also adds a file to the S3 bucket specified by the `s3BucketName` parameter. You need to
 * call `DeploySystemInstance` after running this action.
 *
 * For Greengrass deployments, since this action modifies and adds resources to a Greengrass group and an S3 bucket on the caller's behalf, the calling identity must have write permissions
 * to both the specified Greengrass group and S3 bucket. Otherwise, the call will fail with an authorization error.
 *
 * For cloud deployments, this action requires a `flowActionsRoleArn` value. This is an IAM role
 * that has permissions to access AWS services, such as AWS Lambda and AWS IoT, that the flow uses when it executes.
 *
 * If the definition document doesn't specify a version of the user's namespace, the latest version will be used by default.
 */
export declare const createSystemInstance: API.OperationMethod<CreateSystemInstanceRequest, CreateSystemInstanceResponse, CreateSystemInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateSystemTemplateError = InternalFailureException | InvalidRequestException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a system. The system is validated against the entities in the
 * latest version of the user's namespace unless another namespace version is specified in the request.
 */
export declare const createSystemTemplate: API.OperationMethod<CreateSystemTemplateRequest, CreateSystemTemplateResponse, CreateSystemTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowTemplateError = InternalFailureException | InvalidRequestException | ResourceInUseException | ThrottlingException | CommonErrors;
/**
 * Deletes a workflow. Any new system or deployment that contains this workflow will fail to update or deploy.
 * Existing deployments that contain the workflow will continue to run (since they use a snapshot of the workflow taken at the time of deployment).
 */
export declare const deleteFlowTemplate: API.OperationMethod<DeleteFlowTemplateRequest, DeleteFlowTemplateResponse, DeleteFlowTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteNamespaceError = InternalFailureException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified namespace. This action deletes all of the entities in the namespace. Delete the systems and flows that use entities in the namespace before performing this action. This action takes no
 * request parameters.
 */
export declare const deleteNamespace: API.OperationMethod<DeleteNamespaceRequest, DeleteNamespaceResponse, DeleteNamespaceError, Credentials | HttpClient.HttpClient>;
export type DeleteSystemInstanceError = InternalFailureException | InvalidRequestException | ResourceInUseException | ThrottlingException | CommonErrors;
/**
 * Deletes a system instance.
 * Only system instances that have never been deployed, or that have been undeployed can be deleted.
 *
 * Users can create a new system instance that has the same ID as a deleted system instance.
 */
export declare const deleteSystemInstance: API.OperationMethod<DeleteSystemInstanceRequest, DeleteSystemInstanceResponse, DeleteSystemInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteSystemTemplateError = InternalFailureException | InvalidRequestException | ResourceInUseException | ThrottlingException | CommonErrors;
/**
 * Deletes a system. New deployments can't contain the system after its deletion.
 * Existing deployments that contain the system will continue to work because they use a snapshot of the system that is taken when it is deployed.
 */
export declare const deleteSystemTemplate: API.OperationMethod<DeleteSystemTemplateRequest, DeleteSystemTemplateResponse, DeleteSystemTemplateError, Credentials | HttpClient.HttpClient>;
export type DeploySystemInstanceError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * **Greengrass and Cloud Deployments**
 *
 * Deploys the system instance to the target specified in `CreateSystemInstance`.
 *
 * **Greengrass Deployments**
 *
 * If the system or any workflows and entities have been updated before this action is called, then the deployment will create a new Amazon Simple Storage Service
 * resource file and then deploy it.
 *
 * Since this action creates a Greengrass deployment on the caller's behalf, the calling identity must have write permissions
 * to the specified Greengrass group. Otherwise, the call will fail with an authorization error.
 *
 * For information about the artifacts that get added to your Greengrass core device when you use this API, see AWS IoT Things Graph and AWS IoT Greengrass.
 */
export declare const deploySystemInstance: API.OperationMethod<DeploySystemInstanceRequest, DeploySystemInstanceResponse, DeploySystemInstanceError, Credentials | HttpClient.HttpClient>;
export type DeprecateFlowTemplateError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deprecates the specified workflow. This action marks the workflow for deletion. Deprecated flows can't be deployed, but existing deployments will continue to run.
 */
export declare const deprecateFlowTemplate: API.OperationMethod<DeprecateFlowTemplateRequest, DeprecateFlowTemplateResponse, DeprecateFlowTemplateError, Credentials | HttpClient.HttpClient>;
export type DeprecateSystemTemplateError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deprecates the specified system.
 */
export declare const deprecateSystemTemplate: API.OperationMethod<DeprecateSystemTemplateRequest, DeprecateSystemTemplateResponse, DeprecateSystemTemplateError, Credentials | HttpClient.HttpClient>;
export type DescribeNamespaceError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the latest version of the user's namespace and the public version that it is tracking.
 */
export declare const describeNamespace: API.OperationMethod<DescribeNamespaceRequest, DescribeNamespaceResponse, DescribeNamespaceError, Credentials | HttpClient.HttpClient>;
export type DissociateEntityFromThingError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Dissociates a device entity from a concrete thing. The action takes only the type of the entity that you need to dissociate because only
 * one entity of a particular type can be associated with a thing.
 */
export declare const dissociateEntityFromThing: API.OperationMethod<DissociateEntityFromThingRequest, DissociateEntityFromThingResponse, DissociateEntityFromThingError, Credentials | HttpClient.HttpClient>;
export type GetEntitiesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets definitions of the specified entities. Uses the latest version of the user's namespace by default. This API returns the
 * following TDM entities.
 *
 * - Properties
 *
 * - States
 *
 * - Events
 *
 * - Actions
 *
 * - Capabilities
 *
 * - Mappings
 *
 * - Devices
 *
 * - Device Models
 *
 * - Services
 *
 * This action doesn't return definitions for systems, flows, and deployments.
 */
export declare const getEntities: API.OperationMethod<GetEntitiesRequest, GetEntitiesResponse, GetEntitiesError, Credentials | HttpClient.HttpClient>;
export type GetFlowTemplateError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the latest version of the `DefinitionDocument` and `FlowTemplateSummary` for the specified workflow.
 */
export declare const getFlowTemplate: API.OperationMethod<GetFlowTemplateRequest, GetFlowTemplateResponse, GetFlowTemplateError, Credentials | HttpClient.HttpClient>;
export type GetFlowTemplateRevisionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets revisions of the specified workflow. Only the last 100 revisions are stored. If the workflow has been deprecated,
 * this action will return revisions that occurred before the deprecation. This action won't work for workflows that have been deleted.
 */
export declare const getFlowTemplateRevisions: API.PaginatedOperationMethod<GetFlowTemplateRevisionsRequest, GetFlowTemplateRevisionsResponse, GetFlowTemplateRevisionsError, Credentials | HttpClient.HttpClient, FlowTemplateSummary>;
export type GetNamespaceDeletionStatusError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Gets the status of a namespace deletion task.
 */
export declare const getNamespaceDeletionStatus: API.OperationMethod<GetNamespaceDeletionStatusRequest, GetNamespaceDeletionStatusResponse, GetNamespaceDeletionStatusError, Credentials | HttpClient.HttpClient>;
export type GetSystemInstanceError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets a system instance.
 */
export declare const getSystemInstance: API.OperationMethod<GetSystemInstanceRequest, GetSystemInstanceResponse, GetSystemInstanceError, Credentials | HttpClient.HttpClient>;
export type GetSystemTemplateError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets a system.
 */
export declare const getSystemTemplate: API.OperationMethod<GetSystemTemplateRequest, GetSystemTemplateResponse, GetSystemTemplateError, Credentials | HttpClient.HttpClient>;
export type GetSystemTemplateRevisionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets revisions made to the specified system template. Only the previous 100 revisions are stored. If the system has been deprecated, this action will return
 * the revisions that occurred before its deprecation. This action won't work with systems that have been deleted.
 */
export declare const getSystemTemplateRevisions: API.PaginatedOperationMethod<GetSystemTemplateRevisionsRequest, GetSystemTemplateRevisionsResponse, GetSystemTemplateRevisionsError, Credentials | HttpClient.HttpClient, SystemTemplateSummary>;
export type GetUploadStatusError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the status of the specified upload.
 */
export declare const getUploadStatus: API.OperationMethod<GetUploadStatusRequest, GetUploadStatusResponse, GetUploadStatusError, Credentials | HttpClient.HttpClient>;
export type ListFlowExecutionMessagesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of objects that contain information about events in a flow execution.
 */
export declare const listFlowExecutionMessages: API.PaginatedOperationMethod<ListFlowExecutionMessagesRequest, ListFlowExecutionMessagesResponse, ListFlowExecutionMessagesError, Credentials | HttpClient.HttpClient, FlowExecutionMessage>;
export type ListTagsForResourceError = InternalFailureException | InvalidRequestException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Lists all tags on an AWS IoT Things Graph resource.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type SearchEntitiesError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Searches for entities of the specified type. You can search for entities in your namespace and the public namespace that you're tracking.
 */
export declare const searchEntities: API.PaginatedOperationMethod<SearchEntitiesRequest, SearchEntitiesResponse, SearchEntitiesError, Credentials | HttpClient.HttpClient, EntityDescription>;
export type SearchFlowExecutionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for AWS IoT Things Graph workflow execution instances.
 */
export declare const searchFlowExecutions: API.PaginatedOperationMethod<SearchFlowExecutionsRequest, SearchFlowExecutionsResponse, SearchFlowExecutionsError, Credentials | HttpClient.HttpClient, FlowExecutionSummary>;
export type SearchFlowTemplatesError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Searches for summary information about workflows.
 */
export declare const searchFlowTemplates: API.PaginatedOperationMethod<SearchFlowTemplatesRequest, SearchFlowTemplatesResponse, SearchFlowTemplatesError, Credentials | HttpClient.HttpClient, FlowTemplateSummary>;
export type SearchSystemInstancesError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Searches for system instances in the user's account.
 */
export declare const searchSystemInstances: API.PaginatedOperationMethod<SearchSystemInstancesRequest, SearchSystemInstancesResponse, SearchSystemInstancesError, Credentials | HttpClient.HttpClient, SystemInstanceSummary>;
export type SearchSystemTemplatesError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Searches for summary information about systems in the user's account. You can filter by the ID of a workflow to return only systems that use the specified workflow.
 */
export declare const searchSystemTemplates: API.PaginatedOperationMethod<SearchSystemTemplatesRequest, SearchSystemTemplatesResponse, SearchSystemTemplatesError, Credentials | HttpClient.HttpClient, SystemTemplateSummary>;
export type SearchThingsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for things associated with the specified entity. You can search by both device and device model.
 *
 * For example, if two different devices, camera1 and camera2, implement the camera device model, the user can associate thing1 to camera1 and thing2 to camera2.
 * `SearchThings(camera2)` will return only thing2, but `SearchThings(camera)` will return both thing1 and thing2.
 *
 * This action searches for exact matches and doesn't perform partial text matching.
 */
export declare const searchThings: API.PaginatedOperationMethod<SearchThingsRequest, SearchThingsResponse, SearchThingsError, Credentials | HttpClient.HttpClient, Thing>;
export type TagResourceError = InternalFailureException | InvalidRequestException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a tag for the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UndeploySystemInstanceError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes a system instance from its target (Cloud or Greengrass).
 */
export declare const undeploySystemInstance: API.OperationMethod<UndeploySystemInstanceRequest, UndeploySystemInstanceResponse, UndeploySystemInstanceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalFailureException | InvalidRequestException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Removes a tag from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowTemplateError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the specified workflow. All deployed systems and system instances that use the workflow will see the changes in the flow when it is redeployed. If you don't want this
 * behavior, copy the workflow (creating a new workflow with a different ID), and update the copy. The workflow can contain only entities in the specified namespace.
 */
export declare const updateFlowTemplate: API.OperationMethod<UpdateFlowTemplateRequest, UpdateFlowTemplateResponse, UpdateFlowTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateSystemTemplateError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the specified system. You don't need to run this action after updating a workflow. Any deployment that uses the system will see the changes in the system when it is redeployed.
 */
export declare const updateSystemTemplate: API.OperationMethod<UpdateSystemTemplateRequest, UpdateSystemTemplateResponse, UpdateSystemTemplateError, Credentials | HttpClient.HttpClient>;
export type UploadEntityDefinitionsError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Asynchronously uploads one or more entity definitions to the user's namespace. The `document` parameter is required if
 * `syncWithPublicNamespace` and `deleteExistingEntites` are false. If the `syncWithPublicNamespace` parameter is set to
 * `true`, the user's namespace will synchronize with the latest version of the public namespace. If `deprecateExistingEntities` is set to true,
 * all entities in the latest version will be deleted before the new `DefinitionDocument` is uploaded.
 *
 * When a user uploads entity definitions for the first time, the service creates a new namespace for the user. The new namespace tracks the public namespace. Currently users
 * can have only one namespace. The namespace version increments whenever a user uploads entity definitions that are backwards-incompatible and whenever a user sets the
 * `syncWithPublicNamespace` parameter or the `deprecateExistingEntities` parameter to `true`.
 *
 * The IDs for all of the entities should be in URN format. Each entity must be in the user's namespace. Users can't create entities in the public namespace, but entity definitions can refer to entities in the public namespace.
 *
 * Valid entities are `Device`, `DeviceModel`, `Service`, `Capability`, `State`, `Action`, `Event`, `Property`,
 * `Mapping`, `Enum`.
 */
export declare const uploadEntityDefinitions: API.OperationMethod<UploadEntityDefinitionsRequest, UploadEntityDefinitionsResponse, UploadEntityDefinitionsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iotthingsgraph.d.ts.map