import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const CodeValidationException_base: S.Class<CodeValidationException, S.TaggedStruct<"CodeValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CodeValidationException extends /*@__PURE__*/ CodeValidationException_base {
}
declare const ConcurrentModificationException_base: S.Class<ConcurrentModificationException, S.TaggedStruct<"ConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const InvalidApplicationConfigurationException_base: S.Class<InvalidApplicationConfigurationException, S.TaggedStruct<"InvalidApplicationConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidApplicationConfigurationException extends /*@__PURE__*/ InvalidApplicationConfigurationException_base {
}
declare const InvalidArgumentException_base: S.Class<InvalidArgumentException, S.TaggedStruct<"InvalidArgumentException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidArgumentException extends /*@__PURE__*/ InvalidArgumentException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceProvisionedThroughputExceededException_base: S.Class<ResourceProvisionedThroughputExceededException, S.TaggedStruct<"ResourceProvisionedThroughputExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceProvisionedThroughputExceededException extends /*@__PURE__*/ ResourceProvisionedThroughputExceededException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnableToDetectSchemaException_base: S.Class<UnableToDetectSchemaException, S.TaggedStruct<"UnableToDetectSchemaException", {
    readonly message: any;
    readonly RawInputRecords: any;
    readonly ProcessedInputRecords: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnableToDetectSchemaException extends /*@__PURE__*/ UnableToDetectSchemaException_base {
}
declare const UnsupportedOperationException_base: S.Class<UnsupportedOperationException, S.TaggedStruct<"UnsupportedOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export type ApplicationName = string;
export type ApplicationVersionId = number;
export type LogStreamARN = string;
export interface CloudWatchLoggingOption {
    LogStreamARN: string;
}
export declare const CloudWatchLoggingOption: S.Schema<CloudWatchLoggingOption>;
export type ConditionalToken = string;
export interface AddApplicationCloudWatchLoggingOptionRequest {
    ApplicationName: string;
    CurrentApplicationVersionId?: number;
    CloudWatchLoggingOption: CloudWatchLoggingOption;
    ConditionalToken?: string;
}
export declare const AddApplicationCloudWatchLoggingOptionRequest: S.Schema<AddApplicationCloudWatchLoggingOptionRequest>;
export type ResourceARN = string;
export type Id = string;
export type RoleARN = string;
export interface CloudWatchLoggingOptionDescription {
    CloudWatchLoggingOptionId?: string;
    LogStreamARN: string;
    RoleARN?: string;
}
export declare const CloudWatchLoggingOptionDescription: S.Schema<CloudWatchLoggingOptionDescription>;
export type CloudWatchLoggingOptionDescriptions = CloudWatchLoggingOptionDescription[];
export declare const CloudWatchLoggingOptionDescriptions: any;
export type OperationId = string;
export interface AddApplicationCloudWatchLoggingOptionResponse {
    ApplicationARN?: string;
    ApplicationVersionId?: number;
    CloudWatchLoggingOptionDescriptions?: CloudWatchLoggingOptionDescription[];
    OperationId?: string;
}
export declare const AddApplicationCloudWatchLoggingOptionResponse: S.Schema<AddApplicationCloudWatchLoggingOptionResponse>;
export type InAppStreamName = string;
export interface InputLambdaProcessor {
    ResourceARN: string;
}
export declare const InputLambdaProcessor: S.Schema<InputLambdaProcessor>;
export interface InputProcessingConfiguration {
    InputLambdaProcessor: InputLambdaProcessor;
}
export declare const InputProcessingConfiguration: S.Schema<InputProcessingConfiguration>;
export interface KinesisStreamsInput {
    ResourceARN: string;
}
export declare const KinesisStreamsInput: S.Schema<KinesisStreamsInput>;
export interface KinesisFirehoseInput {
    ResourceARN: string;
}
export declare const KinesisFirehoseInput: S.Schema<KinesisFirehoseInput>;
export type InputParallelismCount = number;
export interface InputParallelism {
    Count?: number;
}
export declare const InputParallelism: S.Schema<InputParallelism>;
export type RecordFormatType = "JSON" | "CSV" | (string & {});
export declare const RecordFormatType: any;
export type RecordRowPath = string;
export interface JSONMappingParameters {
    RecordRowPath: string;
}
export declare const JSONMappingParameters: S.Schema<JSONMappingParameters>;
export type RecordRowDelimiter = string;
export type RecordColumnDelimiter = string;
export interface CSVMappingParameters {
    RecordRowDelimiter: string;
    RecordColumnDelimiter: string;
}
export declare const CSVMappingParameters: S.Schema<CSVMappingParameters>;
export interface MappingParameters {
    JSONMappingParameters?: JSONMappingParameters;
    CSVMappingParameters?: CSVMappingParameters;
}
export declare const MappingParameters: S.Schema<MappingParameters>;
export interface RecordFormat {
    RecordFormatType: RecordFormatType;
    MappingParameters?: MappingParameters;
}
export declare const RecordFormat: S.Schema<RecordFormat>;
export type RecordEncoding = string;
export type RecordColumnName = string;
export type RecordColumnMapping = string;
export type RecordColumnSqlType = string;
export interface RecordColumn {
    Name: string;
    Mapping?: string;
    SqlType: string;
}
export declare const RecordColumn: S.Schema<RecordColumn>;
export type RecordColumns = RecordColumn[];
export declare const RecordColumns: any;
export interface SourceSchema {
    RecordFormat: RecordFormat;
    RecordEncoding?: string;
    RecordColumns: RecordColumn[];
}
export declare const SourceSchema: S.Schema<SourceSchema>;
export interface Input {
    NamePrefix: string;
    InputProcessingConfiguration?: InputProcessingConfiguration;
    KinesisStreamsInput?: KinesisStreamsInput;
    KinesisFirehoseInput?: KinesisFirehoseInput;
    InputParallelism?: InputParallelism;
    InputSchema: SourceSchema;
}
export declare const Input: S.Schema<Input>;
export interface AddApplicationInputRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    Input: Input;
}
export declare const AddApplicationInputRequest: S.Schema<AddApplicationInputRequest>;
export type InAppStreamNames = string[];
export declare const InAppStreamNames: any;
export interface InputLambdaProcessorDescription {
    ResourceARN: string;
    RoleARN?: string;
}
export declare const InputLambdaProcessorDescription: S.Schema<InputLambdaProcessorDescription>;
export interface InputProcessingConfigurationDescription {
    InputLambdaProcessorDescription?: InputLambdaProcessorDescription;
}
export declare const InputProcessingConfigurationDescription: S.Schema<InputProcessingConfigurationDescription>;
export interface KinesisStreamsInputDescription {
    ResourceARN: string;
    RoleARN?: string;
}
export declare const KinesisStreamsInputDescription: S.Schema<KinesisStreamsInputDescription>;
export interface KinesisFirehoseInputDescription {
    ResourceARN: string;
    RoleARN?: string;
}
export declare const KinesisFirehoseInputDescription: S.Schema<KinesisFirehoseInputDescription>;
export type InputStartingPosition = "NOW" | "TRIM_HORIZON" | "LAST_STOPPED_POINT" | (string & {});
export declare const InputStartingPosition: any;
export interface InputStartingPositionConfiguration {
    InputStartingPosition?: InputStartingPosition;
}
export declare const InputStartingPositionConfiguration: S.Schema<InputStartingPositionConfiguration>;
export interface InputDescription {
    InputId?: string;
    NamePrefix?: string;
    InAppStreamNames?: string[];
    InputProcessingConfigurationDescription?: InputProcessingConfigurationDescription;
    KinesisStreamsInputDescription?: KinesisStreamsInputDescription;
    KinesisFirehoseInputDescription?: KinesisFirehoseInputDescription;
    InputSchema?: SourceSchema;
    InputParallelism?: InputParallelism;
    InputStartingPositionConfiguration?: InputStartingPositionConfiguration;
}
export declare const InputDescription: S.Schema<InputDescription>;
export type InputDescriptions = InputDescription[];
export declare const InputDescriptions: any;
export interface AddApplicationInputResponse {
    ApplicationARN?: string;
    ApplicationVersionId?: number;
    InputDescriptions?: InputDescription[];
}
export declare const AddApplicationInputResponse: S.Schema<AddApplicationInputResponse>;
export interface AddApplicationInputProcessingConfigurationRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    InputId: string;
    InputProcessingConfiguration: InputProcessingConfiguration;
}
export declare const AddApplicationInputProcessingConfigurationRequest: S.Schema<AddApplicationInputProcessingConfigurationRequest>;
export interface AddApplicationInputProcessingConfigurationResponse {
    ApplicationARN?: string;
    ApplicationVersionId?: number;
    InputId?: string;
    InputProcessingConfigurationDescription?: InputProcessingConfigurationDescription;
}
export declare const AddApplicationInputProcessingConfigurationResponse: S.Schema<AddApplicationInputProcessingConfigurationResponse>;
export interface KinesisStreamsOutput {
    ResourceARN: string;
}
export declare const KinesisStreamsOutput: S.Schema<KinesisStreamsOutput>;
export interface KinesisFirehoseOutput {
    ResourceARN: string;
}
export declare const KinesisFirehoseOutput: S.Schema<KinesisFirehoseOutput>;
export interface LambdaOutput {
    ResourceARN: string;
}
export declare const LambdaOutput: S.Schema<LambdaOutput>;
export interface DestinationSchema {
    RecordFormatType: RecordFormatType;
}
export declare const DestinationSchema: S.Schema<DestinationSchema>;
export interface Output {
    Name: string;
    KinesisStreamsOutput?: KinesisStreamsOutput;
    KinesisFirehoseOutput?: KinesisFirehoseOutput;
    LambdaOutput?: LambdaOutput;
    DestinationSchema: DestinationSchema;
}
export declare const Output: S.Schema<Output>;
export interface AddApplicationOutputRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    Output: Output;
}
export declare const AddApplicationOutputRequest: S.Schema<AddApplicationOutputRequest>;
export interface KinesisStreamsOutputDescription {
    ResourceARN: string;
    RoleARN?: string;
}
export declare const KinesisStreamsOutputDescription: S.Schema<KinesisStreamsOutputDescription>;
export interface KinesisFirehoseOutputDescription {
    ResourceARN: string;
    RoleARN?: string;
}
export declare const KinesisFirehoseOutputDescription: S.Schema<KinesisFirehoseOutputDescription>;
export interface LambdaOutputDescription {
    ResourceARN: string;
    RoleARN?: string;
}
export declare const LambdaOutputDescription: S.Schema<LambdaOutputDescription>;
export interface OutputDescription {
    OutputId?: string;
    Name?: string;
    KinesisStreamsOutputDescription?: KinesisStreamsOutputDescription;
    KinesisFirehoseOutputDescription?: KinesisFirehoseOutputDescription;
    LambdaOutputDescription?: LambdaOutputDescription;
    DestinationSchema?: DestinationSchema;
}
export declare const OutputDescription: S.Schema<OutputDescription>;
export type OutputDescriptions = OutputDescription[];
export declare const OutputDescriptions: any;
export interface AddApplicationOutputResponse {
    ApplicationARN?: string;
    ApplicationVersionId?: number;
    OutputDescriptions?: OutputDescription[];
}
export declare const AddApplicationOutputResponse: S.Schema<AddApplicationOutputResponse>;
export type InAppTableName = string;
export type BucketARN = string;
export type FileKey = string;
export interface S3ReferenceDataSource {
    BucketARN?: string;
    FileKey?: string;
}
export declare const S3ReferenceDataSource: S.Schema<S3ReferenceDataSource>;
export interface ReferenceDataSource {
    TableName: string;
    S3ReferenceDataSource?: S3ReferenceDataSource;
    ReferenceSchema: SourceSchema;
}
export declare const ReferenceDataSource: S.Schema<ReferenceDataSource>;
export interface AddApplicationReferenceDataSourceRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    ReferenceDataSource: ReferenceDataSource;
}
export declare const AddApplicationReferenceDataSourceRequest: S.Schema<AddApplicationReferenceDataSourceRequest>;
export interface S3ReferenceDataSourceDescription {
    BucketARN: string;
    FileKey: string;
    ReferenceRoleARN?: string;
}
export declare const S3ReferenceDataSourceDescription: S.Schema<S3ReferenceDataSourceDescription>;
export interface ReferenceDataSourceDescription {
    ReferenceId: string;
    TableName: string;
    S3ReferenceDataSourceDescription: S3ReferenceDataSourceDescription;
    ReferenceSchema?: SourceSchema;
}
export declare const ReferenceDataSourceDescription: S.Schema<ReferenceDataSourceDescription>;
export type ReferenceDataSourceDescriptions = ReferenceDataSourceDescription[];
export declare const ReferenceDataSourceDescriptions: any;
export interface AddApplicationReferenceDataSourceResponse {
    ApplicationARN?: string;
    ApplicationVersionId?: number;
    ReferenceDataSourceDescriptions?: ReferenceDataSourceDescription[];
}
export declare const AddApplicationReferenceDataSourceResponse: S.Schema<AddApplicationReferenceDataSourceResponse>;
export type SubnetId = string;
export type SubnetIds = string[];
export declare const SubnetIds: any;
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export declare const SecurityGroupIds: any;
export interface VpcConfiguration {
    SubnetIds: string[];
    SecurityGroupIds: string[];
}
export declare const VpcConfiguration: S.Schema<VpcConfiguration>;
export interface AddApplicationVpcConfigurationRequest {
    ApplicationName: string;
    CurrentApplicationVersionId?: number;
    VpcConfiguration: VpcConfiguration;
    ConditionalToken?: string;
}
export declare const AddApplicationVpcConfigurationRequest: S.Schema<AddApplicationVpcConfigurationRequest>;
export type VpcId = string;
export interface VpcConfigurationDescription {
    VpcConfigurationId: string;
    VpcId: string;
    SubnetIds: string[];
    SecurityGroupIds: string[];
}
export declare const VpcConfigurationDescription: S.Schema<VpcConfigurationDescription>;
export interface AddApplicationVpcConfigurationResponse {
    ApplicationARN?: string;
    ApplicationVersionId?: number;
    VpcConfigurationDescription?: VpcConfigurationDescription;
    OperationId?: string;
}
export declare const AddApplicationVpcConfigurationResponse: S.Schema<AddApplicationVpcConfigurationResponse>;
export type ApplicationDescription = string;
export type RuntimeEnvironment = "SQL-1_0" | "FLINK-1_6" | "FLINK-1_8" | "ZEPPELIN-FLINK-1_0" | "FLINK-1_11" | "FLINK-1_13" | "ZEPPELIN-FLINK-2_0" | "FLINK-1_15" | "ZEPPELIN-FLINK-3_0" | "FLINK-1_18" | "FLINK-1_19" | "FLINK-1_20" | "FLINK-2_2" | "FLINK-2_3" | (string & {});
export declare const RuntimeEnvironment: any;
export type Inputs = Input[];
export declare const Inputs: any;
export type Outputs = Output[];
export declare const Outputs: any;
export type ReferenceDataSources = ReferenceDataSource[];
export declare const ReferenceDataSources: any;
export interface SqlApplicationConfiguration {
    Inputs?: Input[];
    Outputs?: Output[];
    ReferenceDataSources?: ReferenceDataSource[];
}
export declare const SqlApplicationConfiguration: S.Schema<SqlApplicationConfiguration>;
export type ConfigurationType = "DEFAULT" | "CUSTOM" | (string & {});
export declare const ConfigurationType: any;
export type CheckpointInterval = number;
export type MinPauseBetweenCheckpoints = number;
export interface CheckpointConfiguration {
    ConfigurationType: ConfigurationType;
    CheckpointingEnabled?: boolean;
    CheckpointInterval?: number;
    MinPauseBetweenCheckpoints?: number;
}
export declare const CheckpointConfiguration: S.Schema<CheckpointConfiguration>;
export type MetricsLevel = "APPLICATION" | "TASK" | "OPERATOR" | "PARALLELISM" | (string & {});
export declare const MetricsLevel: any;
export type LogLevel = "INFO" | "WARN" | "ERROR" | "DEBUG" | (string & {});
export declare const LogLevel: any;
export interface MonitoringConfiguration {
    ConfigurationType: ConfigurationType;
    MetricsLevel?: MetricsLevel;
    LogLevel?: LogLevel;
}
export declare const MonitoringConfiguration: S.Schema<MonitoringConfiguration>;
export type Parallelism = number;
export type ParallelismPerKPU = number;
export interface ParallelismConfiguration {
    ConfigurationType: ConfigurationType;
    Parallelism?: number;
    ParallelismPerKPU?: number;
    AutoScalingEnabled?: boolean;
}
export declare const ParallelismConfiguration: S.Schema<ParallelismConfiguration>;
export interface FlinkApplicationConfiguration {
    CheckpointConfiguration?: CheckpointConfiguration;
    MonitoringConfiguration?: MonitoringConfiguration;
    ParallelismConfiguration?: ParallelismConfiguration;
}
export declare const FlinkApplicationConfiguration: S.Schema<FlinkApplicationConfiguration>;
export type PropertyKey = string;
export type PropertyValue = string;
export type PropertyMap = {
    [key: string]: string | undefined;
};
export declare const PropertyMap: any;
export interface PropertyGroup {
    PropertyGroupId: string;
    PropertyMap: {
        [key: string]: string | undefined;
    };
}
export declare const PropertyGroup: S.Schema<PropertyGroup>;
export type PropertyGroups = PropertyGroup[];
export declare const PropertyGroups: any;
export interface EnvironmentProperties {
    PropertyGroups: PropertyGroup[];
}
export declare const EnvironmentProperties: S.Schema<EnvironmentProperties>;
export type TextContent = string;
export type ZipFileContent = Uint8Array;
export type ObjectVersion = string;
export interface S3ContentLocation {
    BucketARN: string;
    FileKey: string;
    ObjectVersion?: string;
}
export declare const S3ContentLocation: S.Schema<S3ContentLocation>;
export interface CodeContent {
    TextContent?: string;
    ZipFileContent?: Uint8Array;
    S3ContentLocation?: S3ContentLocation;
}
export declare const CodeContent: S.Schema<CodeContent>;
export type CodeContentType = "PLAINTEXT" | "ZIPFILE" | (string & {});
export declare const CodeContentType: any;
export interface ApplicationCodeConfiguration {
    CodeContent?: CodeContent;
    CodeContentType: CodeContentType;
}
export declare const ApplicationCodeConfiguration: S.Schema<ApplicationCodeConfiguration>;
export interface ApplicationSnapshotConfiguration {
    SnapshotsEnabled: boolean;
}
export declare const ApplicationSnapshotConfiguration: S.Schema<ApplicationSnapshotConfiguration>;
export interface ApplicationSystemRollbackConfiguration {
    RollbackEnabled: boolean;
}
export declare const ApplicationSystemRollbackConfiguration: S.Schema<ApplicationSystemRollbackConfiguration>;
export type VpcConfigurations = VpcConfiguration[];
export declare const VpcConfigurations: any;
export interface ZeppelinMonitoringConfiguration {
    LogLevel: LogLevel;
}
export declare const ZeppelinMonitoringConfiguration: S.Schema<ZeppelinMonitoringConfiguration>;
export type DatabaseARN = string;
export interface GlueDataCatalogConfiguration {
    DatabaseARN: string;
}
export declare const GlueDataCatalogConfiguration: S.Schema<GlueDataCatalogConfiguration>;
export interface CatalogConfiguration {
    GlueDataCatalogConfiguration: GlueDataCatalogConfiguration;
}
export declare const CatalogConfiguration: S.Schema<CatalogConfiguration>;
export type BasePath = string;
export interface S3ContentBaseLocation {
    BucketARN: string;
    BasePath?: string;
}
export declare const S3ContentBaseLocation: S.Schema<S3ContentBaseLocation>;
export interface DeployAsApplicationConfiguration {
    S3ContentLocation: S3ContentBaseLocation;
}
export declare const DeployAsApplicationConfiguration: S.Schema<DeployAsApplicationConfiguration>;
export type ArtifactType = "UDF" | "DEPENDENCY_JAR" | (string & {});
export declare const ArtifactType: any;
export type MavenGroupId = string;
export type MavenArtifactId = string;
export type MavenVersion = string;
export interface MavenReference {
    GroupId: string;
    ArtifactId: string;
    Version: string;
}
export declare const MavenReference: S.Schema<MavenReference>;
export interface CustomArtifactConfiguration {
    ArtifactType: ArtifactType;
    S3ContentLocation?: S3ContentLocation;
    MavenReference?: MavenReference;
}
export declare const CustomArtifactConfiguration: S.Schema<CustomArtifactConfiguration>;
export type CustomArtifactsConfigurationList = CustomArtifactConfiguration[];
export declare const CustomArtifactsConfigurationList: any;
export interface ZeppelinApplicationConfiguration {
    MonitoringConfiguration?: ZeppelinMonitoringConfiguration;
    CatalogConfiguration?: CatalogConfiguration;
    DeployAsApplicationConfiguration?: DeployAsApplicationConfiguration;
    CustomArtifactsConfiguration?: CustomArtifactConfiguration[];
}
export declare const ZeppelinApplicationConfiguration: S.Schema<ZeppelinApplicationConfiguration>;
export type KeyId = string;
export type KeyType = "AWS_OWNED_KEY" | "CUSTOMER_MANAGED_KEY" | (string & {});
export declare const KeyType: any;
export interface ApplicationEncryptionConfiguration {
    KeyId?: string;
    KeyType: KeyType;
}
export declare const ApplicationEncryptionConfiguration: S.Schema<ApplicationEncryptionConfiguration>;
export interface ApplicationConfiguration {
    SqlApplicationConfiguration?: SqlApplicationConfiguration;
    FlinkApplicationConfiguration?: FlinkApplicationConfiguration;
    EnvironmentProperties?: EnvironmentProperties;
    ApplicationCodeConfiguration?: ApplicationCodeConfiguration;
    ApplicationSnapshotConfiguration?: ApplicationSnapshotConfiguration;
    ApplicationSystemRollbackConfiguration?: ApplicationSystemRollbackConfiguration;
    VpcConfigurations?: VpcConfiguration[];
    ZeppelinApplicationConfiguration?: ZeppelinApplicationConfiguration;
    ApplicationEncryptionConfiguration?: ApplicationEncryptionConfiguration;
}
export declare const ApplicationConfiguration: S.Schema<ApplicationConfiguration>;
export type CloudWatchLoggingOptions = CloudWatchLoggingOption[];
export declare const CloudWatchLoggingOptions: any;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export type ApplicationMode = "STREAMING" | "INTERACTIVE" | (string & {});
export declare const ApplicationMode: any;
export interface CreateApplicationRequest {
    ApplicationName: string;
    ApplicationDescription?: string;
    RuntimeEnvironment: RuntimeEnvironment;
    ServiceExecutionRole: string;
    ApplicationConfiguration?: ApplicationConfiguration;
    CloudWatchLoggingOptions?: CloudWatchLoggingOption[];
    Tags?: Tag[];
    ApplicationMode?: ApplicationMode;
}
export declare const CreateApplicationRequest: S.Schema<CreateApplicationRequest>;
export type ApplicationStatus = "DELETING" | "STARTING" | "STOPPING" | "READY" | "RUNNING" | "UPDATING" | "AUTOSCALING" | "FORCE_STOPPING" | "ROLLING_BACK" | "MAINTENANCE" | "ROLLED_BACK" | (string & {});
export declare const ApplicationStatus: any;
export interface SqlApplicationConfigurationDescription {
    InputDescriptions?: InputDescription[];
    OutputDescriptions?: OutputDescription[];
    ReferenceDataSourceDescriptions?: ReferenceDataSourceDescription[];
}
export declare const SqlApplicationConfigurationDescription: S.Schema<SqlApplicationConfigurationDescription>;
export type CodeMD5 = string;
export type CodeSize = number;
export interface S3ApplicationCodeLocationDescription {
    BucketARN: string;
    FileKey: string;
    ObjectVersion?: string;
}
export declare const S3ApplicationCodeLocationDescription: S.Schema<S3ApplicationCodeLocationDescription>;
export interface CodeContentDescription {
    TextContent?: string;
    CodeMD5?: string;
    CodeSize?: number;
    S3ApplicationCodeLocationDescription?: S3ApplicationCodeLocationDescription;
}
export declare const CodeContentDescription: S.Schema<CodeContentDescription>;
export interface ApplicationCodeConfigurationDescription {
    CodeContentType: CodeContentType;
    CodeContentDescription?: CodeContentDescription;
}
export declare const ApplicationCodeConfigurationDescription: S.Schema<ApplicationCodeConfigurationDescription>;
export type ApplicationRestoreType = "SKIP_RESTORE_FROM_SNAPSHOT" | "RESTORE_FROM_LATEST_SNAPSHOT" | "RESTORE_FROM_CUSTOM_SNAPSHOT" | (string & {});
export declare const ApplicationRestoreType: any;
export type SnapshotName = string;
export interface ApplicationRestoreConfiguration {
    ApplicationRestoreType: ApplicationRestoreType;
    SnapshotName?: string;
}
export declare const ApplicationRestoreConfiguration: S.Schema<ApplicationRestoreConfiguration>;
export interface FlinkRunConfiguration {
    AllowNonRestoredState?: boolean;
}
export declare const FlinkRunConfiguration: S.Schema<FlinkRunConfiguration>;
export interface RunConfigurationDescription {
    ApplicationRestoreConfigurationDescription?: ApplicationRestoreConfiguration;
    FlinkRunConfigurationDescription?: FlinkRunConfiguration;
}
export declare const RunConfigurationDescription: S.Schema<RunConfigurationDescription>;
export interface CheckpointConfigurationDescription {
    ConfigurationType?: ConfigurationType;
    CheckpointingEnabled?: boolean;
    CheckpointInterval?: number;
    MinPauseBetweenCheckpoints?: number;
}
export declare const CheckpointConfigurationDescription: S.Schema<CheckpointConfigurationDescription>;
export interface MonitoringConfigurationDescription {
    ConfigurationType?: ConfigurationType;
    MetricsLevel?: MetricsLevel;
    LogLevel?: LogLevel;
}
export declare const MonitoringConfigurationDescription: S.Schema<MonitoringConfigurationDescription>;
export interface ParallelismConfigurationDescription {
    ConfigurationType?: ConfigurationType;
    Parallelism?: number;
    ParallelismPerKPU?: number;
    CurrentParallelism?: number;
    AutoScalingEnabled?: boolean;
}
export declare const ParallelismConfigurationDescription: S.Schema<ParallelismConfigurationDescription>;
export type JobPlanDescription = string;
export interface FlinkApplicationConfigurationDescription {
    CheckpointConfigurationDescription?: CheckpointConfigurationDescription;
    MonitoringConfigurationDescription?: MonitoringConfigurationDescription;
    ParallelismConfigurationDescription?: ParallelismConfigurationDescription;
    JobPlanDescription?: string;
}
export declare const FlinkApplicationConfigurationDescription: S.Schema<FlinkApplicationConfigurationDescription>;
export interface EnvironmentPropertyDescriptions {
    PropertyGroupDescriptions?: PropertyGroup[];
}
export declare const EnvironmentPropertyDescriptions: S.Schema<EnvironmentPropertyDescriptions>;
export interface ApplicationSnapshotConfigurationDescription {
    SnapshotsEnabled: boolean;
}
export declare const ApplicationSnapshotConfigurationDescription: S.Schema<ApplicationSnapshotConfigurationDescription>;
export interface ApplicationSystemRollbackConfigurationDescription {
    RollbackEnabled: boolean;
}
export declare const ApplicationSystemRollbackConfigurationDescription: S.Schema<ApplicationSystemRollbackConfigurationDescription>;
export type VpcConfigurationDescriptions = VpcConfigurationDescription[];
export declare const VpcConfigurationDescriptions: any;
export interface ZeppelinMonitoringConfigurationDescription {
    LogLevel?: LogLevel;
}
export declare const ZeppelinMonitoringConfigurationDescription: S.Schema<ZeppelinMonitoringConfigurationDescription>;
export interface GlueDataCatalogConfigurationDescription {
    DatabaseARN: string;
}
export declare const GlueDataCatalogConfigurationDescription: S.Schema<GlueDataCatalogConfigurationDescription>;
export interface CatalogConfigurationDescription {
    GlueDataCatalogConfigurationDescription: GlueDataCatalogConfigurationDescription;
}
export declare const CatalogConfigurationDescription: S.Schema<CatalogConfigurationDescription>;
export interface S3ContentBaseLocationDescription {
    BucketARN: string;
    BasePath?: string;
}
export declare const S3ContentBaseLocationDescription: S.Schema<S3ContentBaseLocationDescription>;
export interface DeployAsApplicationConfigurationDescription {
    S3ContentLocationDescription: S3ContentBaseLocationDescription;
}
export declare const DeployAsApplicationConfigurationDescription: S.Schema<DeployAsApplicationConfigurationDescription>;
export interface CustomArtifactConfigurationDescription {
    ArtifactType?: ArtifactType;
    S3ContentLocationDescription?: S3ContentLocation;
    MavenReferenceDescription?: MavenReference;
}
export declare const CustomArtifactConfigurationDescription: S.Schema<CustomArtifactConfigurationDescription>;
export type CustomArtifactsConfigurationDescriptionList = CustomArtifactConfigurationDescription[];
export declare const CustomArtifactsConfigurationDescriptionList: any;
export interface ZeppelinApplicationConfigurationDescription {
    MonitoringConfigurationDescription: ZeppelinMonitoringConfigurationDescription;
    CatalogConfigurationDescription?: CatalogConfigurationDescription;
    DeployAsApplicationConfigurationDescription?: DeployAsApplicationConfigurationDescription;
    CustomArtifactsConfigurationDescription?: CustomArtifactConfigurationDescription[];
}
export declare const ZeppelinApplicationConfigurationDescription: S.Schema<ZeppelinApplicationConfigurationDescription>;
export interface ApplicationEncryptionConfigurationDescription {
    KeyId?: string;
    KeyType: KeyType;
}
export declare const ApplicationEncryptionConfigurationDescription: S.Schema<ApplicationEncryptionConfigurationDescription>;
export interface ApplicationConfigurationDescription {
    SqlApplicationConfigurationDescription?: SqlApplicationConfigurationDescription;
    ApplicationCodeConfigurationDescription?: ApplicationCodeConfigurationDescription;
    RunConfigurationDescription?: RunConfigurationDescription;
    FlinkApplicationConfigurationDescription?: FlinkApplicationConfigurationDescription;
    EnvironmentPropertyDescriptions?: EnvironmentPropertyDescriptions;
    ApplicationSnapshotConfigurationDescription?: ApplicationSnapshotConfigurationDescription;
    ApplicationSystemRollbackConfigurationDescription?: ApplicationSystemRollbackConfigurationDescription;
    VpcConfigurationDescriptions?: VpcConfigurationDescription[];
    ZeppelinApplicationConfigurationDescription?: ZeppelinApplicationConfigurationDescription;
    ApplicationEncryptionConfigurationDescription?: ApplicationEncryptionConfigurationDescription;
}
export declare const ApplicationConfigurationDescription: S.Schema<ApplicationConfigurationDescription>;
export type ApplicationMaintenanceWindowStartTime = string;
export type ApplicationMaintenanceWindowEndTime = string;
export interface ApplicationMaintenanceConfigurationDescription {
    ApplicationMaintenanceWindowStartTime: string;
    ApplicationMaintenanceWindowEndTime: string;
}
export declare const ApplicationMaintenanceConfigurationDescription: S.Schema<ApplicationMaintenanceConfigurationDescription>;
export interface ApplicationDetail {
    ApplicationARN: string;
    ApplicationDescription?: string;
    ApplicationName: string;
    RuntimeEnvironment: RuntimeEnvironment;
    ServiceExecutionRole?: string;
    ApplicationStatus: ApplicationStatus;
    ApplicationVersionId: number;
    CreateTimestamp?: Date;
    LastUpdateTimestamp?: Date;
    ApplicationConfigurationDescription?: ApplicationConfigurationDescription;
    CloudWatchLoggingOptionDescriptions?: CloudWatchLoggingOptionDescription[];
    ApplicationMaintenanceConfigurationDescription?: ApplicationMaintenanceConfigurationDescription;
    ApplicationVersionUpdatedFrom?: number;
    ApplicationVersionRolledBackFrom?: number;
    ApplicationVersionCreateTimestamp?: Date;
    ConditionalToken?: string;
    ApplicationVersionRolledBackTo?: number;
    ApplicationMode?: ApplicationMode;
}
export declare const ApplicationDetail: S.Schema<ApplicationDetail>;
export interface CreateApplicationResponse {
    ApplicationDetail: ApplicationDetail;
}
export declare const CreateApplicationResponse: S.Schema<CreateApplicationResponse>;
export type UrlType = "FLINK_DASHBOARD_URL" | "ZEPPELIN_UI_URL" | (string & {});
export declare const UrlType: any;
export type SessionExpirationDurationInSeconds = number;
export interface CreateApplicationPresignedUrlRequest {
    ApplicationName: string;
    UrlType: UrlType;
    SessionExpirationDurationInSeconds?: number;
}
export declare const CreateApplicationPresignedUrlRequest: S.Schema<CreateApplicationPresignedUrlRequest>;
export type AuthorizedUrl = string;
export interface CreateApplicationPresignedUrlResponse {
    AuthorizedUrl?: string;
}
export declare const CreateApplicationPresignedUrlResponse: S.Schema<CreateApplicationPresignedUrlResponse>;
export interface CreateApplicationSnapshotRequest {
    ApplicationName: string;
    SnapshotName: string;
}
export declare const CreateApplicationSnapshotRequest: S.Schema<CreateApplicationSnapshotRequest>;
export interface CreateApplicationSnapshotResponse {
}
export declare const CreateApplicationSnapshotResponse: S.Schema<CreateApplicationSnapshotResponse>;
export interface DeleteApplicationRequest {
    ApplicationName: string;
    CreateTimestamp: Date;
}
export declare const DeleteApplicationRequest: S.Schema<DeleteApplicationRequest>;
export interface DeleteApplicationResponse {
}
export declare const DeleteApplicationResponse: S.Schema<DeleteApplicationResponse>;
export interface DeleteApplicationCloudWatchLoggingOptionRequest {
    ApplicationName: string;
    CurrentApplicationVersionId?: number;
    CloudWatchLoggingOptionId: string;
    ConditionalToken?: string;
}
export declare const DeleteApplicationCloudWatchLoggingOptionRequest: S.Schema<DeleteApplicationCloudWatchLoggingOptionRequest>;
export interface DeleteApplicationCloudWatchLoggingOptionResponse {
    ApplicationARN?: string;
    ApplicationVersionId?: number;
    CloudWatchLoggingOptionDescriptions?: CloudWatchLoggingOptionDescription[];
    OperationId?: string;
}
export declare const DeleteApplicationCloudWatchLoggingOptionResponse: S.Schema<DeleteApplicationCloudWatchLoggingOptionResponse>;
export interface DeleteApplicationInputProcessingConfigurationRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    InputId: string;
}
export declare const DeleteApplicationInputProcessingConfigurationRequest: S.Schema<DeleteApplicationInputProcessingConfigurationRequest>;
export interface DeleteApplicationInputProcessingConfigurationResponse {
    ApplicationARN?: string;
    ApplicationVersionId?: number;
}
export declare const DeleteApplicationInputProcessingConfigurationResponse: S.Schema<DeleteApplicationInputProcessingConfigurationResponse>;
export interface DeleteApplicationOutputRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    OutputId: string;
}
export declare const DeleteApplicationOutputRequest: S.Schema<DeleteApplicationOutputRequest>;
export interface DeleteApplicationOutputResponse {
    ApplicationARN?: string;
    ApplicationVersionId?: number;
}
export declare const DeleteApplicationOutputResponse: S.Schema<DeleteApplicationOutputResponse>;
export interface DeleteApplicationReferenceDataSourceRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    ReferenceId: string;
}
export declare const DeleteApplicationReferenceDataSourceRequest: S.Schema<DeleteApplicationReferenceDataSourceRequest>;
export interface DeleteApplicationReferenceDataSourceResponse {
    ApplicationARN?: string;
    ApplicationVersionId?: number;
}
export declare const DeleteApplicationReferenceDataSourceResponse: S.Schema<DeleteApplicationReferenceDataSourceResponse>;
export interface DeleteApplicationSnapshotRequest {
    ApplicationName: string;
    SnapshotName: string;
    SnapshotCreationTimestamp: Date;
}
export declare const DeleteApplicationSnapshotRequest: S.Schema<DeleteApplicationSnapshotRequest>;
export interface DeleteApplicationSnapshotResponse {
}
export declare const DeleteApplicationSnapshotResponse: S.Schema<DeleteApplicationSnapshotResponse>;
export interface DeleteApplicationVpcConfigurationRequest {
    ApplicationName: string;
    CurrentApplicationVersionId?: number;
    VpcConfigurationId: string;
    ConditionalToken?: string;
}
export declare const DeleteApplicationVpcConfigurationRequest: S.Schema<DeleteApplicationVpcConfigurationRequest>;
export interface DeleteApplicationVpcConfigurationResponse {
    ApplicationARN?: string;
    ApplicationVersionId?: number;
    OperationId?: string;
}
export declare const DeleteApplicationVpcConfigurationResponse: S.Schema<DeleteApplicationVpcConfigurationResponse>;
export interface DescribeApplicationRequest {
    ApplicationName: string;
    IncludeAdditionalDetails?: boolean;
}
export declare const DescribeApplicationRequest: S.Schema<DescribeApplicationRequest>;
export interface DescribeApplicationResponse {
    ApplicationDetail: ApplicationDetail;
}
export declare const DescribeApplicationResponse: S.Schema<DescribeApplicationResponse>;
export interface DescribeApplicationOperationRequest {
    ApplicationName: string;
    OperationId: string;
}
export declare const DescribeApplicationOperationRequest: S.Schema<DescribeApplicationOperationRequest>;
export type Operation = string;
export type OperationStatus = "IN_PROGRESS" | "CANCELLED" | "SUCCESSFUL" | "FAILED" | (string & {});
export declare const OperationStatus: any;
export interface ApplicationVersionChangeDetails {
    ApplicationVersionUpdatedFrom: number;
    ApplicationVersionUpdatedTo: number;
}
export declare const ApplicationVersionChangeDetails: S.Schema<ApplicationVersionChangeDetails>;
export type ErrorString = string;
export interface ErrorInfo {
    ErrorString?: string;
}
export declare const ErrorInfo: S.Schema<ErrorInfo>;
export interface OperationFailureDetails {
    RollbackOperationId?: string;
    ErrorInfo?: ErrorInfo;
}
export declare const OperationFailureDetails: S.Schema<OperationFailureDetails>;
export interface ApplicationOperationInfoDetails {
    Operation: string;
    StartTime: Date;
    EndTime: Date;
    OperationStatus: OperationStatus;
    ApplicationVersionChangeDetails?: ApplicationVersionChangeDetails;
    OperationFailureDetails?: OperationFailureDetails;
}
export declare const ApplicationOperationInfoDetails: S.Schema<ApplicationOperationInfoDetails>;
export interface DescribeApplicationOperationResponse {
    ApplicationOperationInfoDetails?: ApplicationOperationInfoDetails;
}
export declare const DescribeApplicationOperationResponse: S.Schema<DescribeApplicationOperationResponse>;
export interface DescribeApplicationSnapshotRequest {
    ApplicationName: string;
    SnapshotName: string;
}
export declare const DescribeApplicationSnapshotRequest: S.Schema<DescribeApplicationSnapshotRequest>;
export type SnapshotStatus = "CREATING" | "READY" | "DELETING" | "FAILED" | (string & {});
export declare const SnapshotStatus: any;
export interface SnapshotDetails {
    SnapshotName: string;
    SnapshotStatus: SnapshotStatus;
    ApplicationVersionId: number;
    SnapshotCreationTimestamp?: Date;
    RuntimeEnvironment?: RuntimeEnvironment;
    ApplicationEncryptionConfigurationDescription?: ApplicationEncryptionConfigurationDescription;
}
export declare const SnapshotDetails: S.Schema<SnapshotDetails>;
export interface DescribeApplicationSnapshotResponse {
    SnapshotDetails: SnapshotDetails;
}
export declare const DescribeApplicationSnapshotResponse: S.Schema<DescribeApplicationSnapshotResponse>;
export interface DescribeApplicationVersionRequest {
    ApplicationName: string;
    ApplicationVersionId: number;
}
export declare const DescribeApplicationVersionRequest: S.Schema<DescribeApplicationVersionRequest>;
export interface DescribeApplicationVersionResponse {
    ApplicationVersionDetail?: ApplicationDetail;
}
export declare const DescribeApplicationVersionResponse: S.Schema<DescribeApplicationVersionResponse>;
export interface S3Configuration {
    BucketARN: string;
    FileKey: string;
}
export declare const S3Configuration: S.Schema<S3Configuration>;
export interface DiscoverInputSchemaRequest {
    ResourceARN?: string;
    ServiceExecutionRole: string;
    InputStartingPositionConfiguration?: InputStartingPositionConfiguration;
    S3Configuration?: S3Configuration;
    InputProcessingConfiguration?: InputProcessingConfiguration;
}
export declare const DiscoverInputSchemaRequest: S.Schema<DiscoverInputSchemaRequest>;
export type ParsedInputRecordField = string;
export type ParsedInputRecord = string[];
export declare const ParsedInputRecord: any;
export type ParsedInputRecords = string[][];
export declare const ParsedInputRecords: any;
export type ProcessedInputRecord = string;
export type ProcessedInputRecords = string[];
export declare const ProcessedInputRecords: any;
export type RawInputRecord = string;
export type RawInputRecords = string[];
export declare const RawInputRecords: any;
export interface DiscoverInputSchemaResponse {
    InputSchema?: SourceSchema;
    ParsedInputRecords?: string[][];
    ProcessedInputRecords?: string[];
    RawInputRecords?: string[];
}
export declare const DiscoverInputSchemaResponse: S.Schema<DiscoverInputSchemaResponse>;
export type ListApplicationOperationsInputLimit = number;
export type NextToken = string;
export interface ListApplicationOperationsRequest {
    ApplicationName: string;
    Limit?: number;
    NextToken?: string;
    Operation?: string;
    OperationStatus?: OperationStatus;
}
export declare const ListApplicationOperationsRequest: S.Schema<ListApplicationOperationsRequest>;
export interface ApplicationOperationInfo {
    Operation?: string;
    OperationId?: string;
    StartTime?: Date;
    EndTime?: Date;
    OperationStatus?: OperationStatus;
}
export declare const ApplicationOperationInfo: S.Schema<ApplicationOperationInfo>;
export type ApplicationOperationInfoList = ApplicationOperationInfo[];
export declare const ApplicationOperationInfoList: any;
export interface ListApplicationOperationsResponse {
    ApplicationOperationInfoList?: ApplicationOperationInfo[];
    NextToken?: string;
}
export declare const ListApplicationOperationsResponse: S.Schema<ListApplicationOperationsResponse>;
export type ListApplicationsInputLimit = number;
export interface ListApplicationsRequest {
    Limit?: number;
    NextToken?: string;
}
export declare const ListApplicationsRequest: S.Schema<ListApplicationsRequest>;
export interface ApplicationSummary {
    ApplicationName: string;
    ApplicationARN: string;
    ApplicationStatus: ApplicationStatus;
    ApplicationVersionId: number;
    RuntimeEnvironment: RuntimeEnvironment;
    ApplicationMode?: ApplicationMode;
}
export declare const ApplicationSummary: S.Schema<ApplicationSummary>;
export type ApplicationSummaries = ApplicationSummary[];
export declare const ApplicationSummaries: any;
export interface ListApplicationsResponse {
    ApplicationSummaries: ApplicationSummary[];
    NextToken?: string;
}
export declare const ListApplicationsResponse: S.Schema<ListApplicationsResponse>;
export type ListSnapshotsInputLimit = number;
export interface ListApplicationSnapshotsRequest {
    ApplicationName: string;
    Limit?: number;
    NextToken?: string;
}
export declare const ListApplicationSnapshotsRequest: S.Schema<ListApplicationSnapshotsRequest>;
export type SnapshotSummaries = SnapshotDetails[];
export declare const SnapshotSummaries: any;
export interface ListApplicationSnapshotsResponse {
    SnapshotSummaries?: SnapshotDetails[];
    NextToken?: string;
}
export declare const ListApplicationSnapshotsResponse: S.Schema<ListApplicationSnapshotsResponse>;
export type ListApplicationVersionsInputLimit = number;
export interface ListApplicationVersionsRequest {
    ApplicationName: string;
    Limit?: number;
    NextToken?: string;
}
export declare const ListApplicationVersionsRequest: S.Schema<ListApplicationVersionsRequest>;
export interface ApplicationVersionSummary {
    ApplicationVersionId: number;
    ApplicationStatus: ApplicationStatus;
}
export declare const ApplicationVersionSummary: S.Schema<ApplicationVersionSummary>;
export type ApplicationVersionSummaries = ApplicationVersionSummary[];
export declare const ApplicationVersionSummaries: any;
export interface ListApplicationVersionsResponse {
    ApplicationVersionSummaries?: ApplicationVersionSummary[];
    NextToken?: string;
}
export declare const ListApplicationVersionsResponse: S.Schema<ListApplicationVersionsResponse>;
export type KinesisAnalyticsARN = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface RollbackApplicationRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
}
export declare const RollbackApplicationRequest: S.Schema<RollbackApplicationRequest>;
export interface RollbackApplicationResponse {
    ApplicationDetail: ApplicationDetail;
    OperationId?: string;
}
export declare const RollbackApplicationResponse: S.Schema<RollbackApplicationResponse>;
export interface SqlRunConfiguration {
    InputId: string;
    InputStartingPositionConfiguration: InputStartingPositionConfiguration;
}
export declare const SqlRunConfiguration: S.Schema<SqlRunConfiguration>;
export type SqlRunConfigurations = SqlRunConfiguration[];
export declare const SqlRunConfigurations: any;
export interface RunConfiguration {
    FlinkRunConfiguration?: FlinkRunConfiguration;
    SqlRunConfigurations?: SqlRunConfiguration[];
    ApplicationRestoreConfiguration?: ApplicationRestoreConfiguration;
}
export declare const RunConfiguration: S.Schema<RunConfiguration>;
export interface StartApplicationRequest {
    ApplicationName: string;
    RunConfiguration?: RunConfiguration;
}
export declare const StartApplicationRequest: S.Schema<StartApplicationRequest>;
export interface StartApplicationResponse {
    OperationId?: string;
}
export declare const StartApplicationResponse: S.Schema<StartApplicationResponse>;
export interface StopApplicationRequest {
    ApplicationName: string;
    Force?: boolean;
}
export declare const StopApplicationRequest: S.Schema<StopApplicationRequest>;
export interface StopApplicationResponse {
    OperationId?: string;
}
export declare const StopApplicationResponse: S.Schema<StopApplicationResponse>;
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface InputLambdaProcessorUpdate {
    ResourceARNUpdate: string;
}
export declare const InputLambdaProcessorUpdate: S.Schema<InputLambdaProcessorUpdate>;
export interface InputProcessingConfigurationUpdate {
    InputLambdaProcessorUpdate: InputLambdaProcessorUpdate;
}
export declare const InputProcessingConfigurationUpdate: S.Schema<InputProcessingConfigurationUpdate>;
export interface KinesisStreamsInputUpdate {
    ResourceARNUpdate: string;
}
export declare const KinesisStreamsInputUpdate: S.Schema<KinesisStreamsInputUpdate>;
export interface KinesisFirehoseInputUpdate {
    ResourceARNUpdate: string;
}
export declare const KinesisFirehoseInputUpdate: S.Schema<KinesisFirehoseInputUpdate>;
export interface InputSchemaUpdate {
    RecordFormatUpdate?: RecordFormat;
    RecordEncodingUpdate?: string;
    RecordColumnUpdates?: RecordColumn[];
}
export declare const InputSchemaUpdate: S.Schema<InputSchemaUpdate>;
export interface InputParallelismUpdate {
    CountUpdate: number;
}
export declare const InputParallelismUpdate: S.Schema<InputParallelismUpdate>;
export interface InputUpdate {
    InputId: string;
    NamePrefixUpdate?: string;
    InputProcessingConfigurationUpdate?: InputProcessingConfigurationUpdate;
    KinesisStreamsInputUpdate?: KinesisStreamsInputUpdate;
    KinesisFirehoseInputUpdate?: KinesisFirehoseInputUpdate;
    InputSchemaUpdate?: InputSchemaUpdate;
    InputParallelismUpdate?: InputParallelismUpdate;
}
export declare const InputUpdate: S.Schema<InputUpdate>;
export type InputUpdates = InputUpdate[];
export declare const InputUpdates: any;
export interface KinesisStreamsOutputUpdate {
    ResourceARNUpdate: string;
}
export declare const KinesisStreamsOutputUpdate: S.Schema<KinesisStreamsOutputUpdate>;
export interface KinesisFirehoseOutputUpdate {
    ResourceARNUpdate: string;
}
export declare const KinesisFirehoseOutputUpdate: S.Schema<KinesisFirehoseOutputUpdate>;
export interface LambdaOutputUpdate {
    ResourceARNUpdate: string;
}
export declare const LambdaOutputUpdate: S.Schema<LambdaOutputUpdate>;
export interface OutputUpdate {
    OutputId: string;
    NameUpdate?: string;
    KinesisStreamsOutputUpdate?: KinesisStreamsOutputUpdate;
    KinesisFirehoseOutputUpdate?: KinesisFirehoseOutputUpdate;
    LambdaOutputUpdate?: LambdaOutputUpdate;
    DestinationSchemaUpdate?: DestinationSchema;
}
export declare const OutputUpdate: S.Schema<OutputUpdate>;
export type OutputUpdates = OutputUpdate[];
export declare const OutputUpdates: any;
export interface S3ReferenceDataSourceUpdate {
    BucketARNUpdate?: string;
    FileKeyUpdate?: string;
}
export declare const S3ReferenceDataSourceUpdate: S.Schema<S3ReferenceDataSourceUpdate>;
export interface ReferenceDataSourceUpdate {
    ReferenceId: string;
    TableNameUpdate?: string;
    S3ReferenceDataSourceUpdate?: S3ReferenceDataSourceUpdate;
    ReferenceSchemaUpdate?: SourceSchema;
}
export declare const ReferenceDataSourceUpdate: S.Schema<ReferenceDataSourceUpdate>;
export type ReferenceDataSourceUpdates = ReferenceDataSourceUpdate[];
export declare const ReferenceDataSourceUpdates: any;
export interface SqlApplicationConfigurationUpdate {
    InputUpdates?: InputUpdate[];
    OutputUpdates?: OutputUpdate[];
    ReferenceDataSourceUpdates?: ReferenceDataSourceUpdate[];
}
export declare const SqlApplicationConfigurationUpdate: S.Schema<SqlApplicationConfigurationUpdate>;
export interface S3ContentLocationUpdate {
    BucketARNUpdate?: string;
    FileKeyUpdate?: string;
    ObjectVersionUpdate?: string;
}
export declare const S3ContentLocationUpdate: S.Schema<S3ContentLocationUpdate>;
export interface CodeContentUpdate {
    TextContentUpdate?: string;
    ZipFileContentUpdate?: Uint8Array;
    S3ContentLocationUpdate?: S3ContentLocationUpdate;
}
export declare const CodeContentUpdate: S.Schema<CodeContentUpdate>;
export interface ApplicationCodeConfigurationUpdate {
    CodeContentTypeUpdate?: CodeContentType;
    CodeContentUpdate?: CodeContentUpdate;
}
export declare const ApplicationCodeConfigurationUpdate: S.Schema<ApplicationCodeConfigurationUpdate>;
export interface CheckpointConfigurationUpdate {
    ConfigurationTypeUpdate?: ConfigurationType;
    CheckpointingEnabledUpdate?: boolean;
    CheckpointIntervalUpdate?: number;
    MinPauseBetweenCheckpointsUpdate?: number;
}
export declare const CheckpointConfigurationUpdate: S.Schema<CheckpointConfigurationUpdate>;
export interface MonitoringConfigurationUpdate {
    ConfigurationTypeUpdate?: ConfigurationType;
    MetricsLevelUpdate?: MetricsLevel;
    LogLevelUpdate?: LogLevel;
}
export declare const MonitoringConfigurationUpdate: S.Schema<MonitoringConfigurationUpdate>;
export interface ParallelismConfigurationUpdate {
    ConfigurationTypeUpdate?: ConfigurationType;
    ParallelismUpdate?: number;
    ParallelismPerKPUUpdate?: number;
    AutoScalingEnabledUpdate?: boolean;
}
export declare const ParallelismConfigurationUpdate: S.Schema<ParallelismConfigurationUpdate>;
export interface FlinkApplicationConfigurationUpdate {
    CheckpointConfigurationUpdate?: CheckpointConfigurationUpdate;
    MonitoringConfigurationUpdate?: MonitoringConfigurationUpdate;
    ParallelismConfigurationUpdate?: ParallelismConfigurationUpdate;
}
export declare const FlinkApplicationConfigurationUpdate: S.Schema<FlinkApplicationConfigurationUpdate>;
export interface EnvironmentPropertyUpdates {
    PropertyGroups: PropertyGroup[];
}
export declare const EnvironmentPropertyUpdates: S.Schema<EnvironmentPropertyUpdates>;
export interface ApplicationSnapshotConfigurationUpdate {
    SnapshotsEnabledUpdate: boolean;
}
export declare const ApplicationSnapshotConfigurationUpdate: S.Schema<ApplicationSnapshotConfigurationUpdate>;
export interface ApplicationSystemRollbackConfigurationUpdate {
    RollbackEnabledUpdate: boolean;
}
export declare const ApplicationSystemRollbackConfigurationUpdate: S.Schema<ApplicationSystemRollbackConfigurationUpdate>;
export interface VpcConfigurationUpdate {
    VpcConfigurationId: string;
    SubnetIdUpdates?: string[];
    SecurityGroupIdUpdates?: string[];
}
export declare const VpcConfigurationUpdate: S.Schema<VpcConfigurationUpdate>;
export type VpcConfigurationUpdates = VpcConfigurationUpdate[];
export declare const VpcConfigurationUpdates: any;
export interface ZeppelinMonitoringConfigurationUpdate {
    LogLevelUpdate: LogLevel;
}
export declare const ZeppelinMonitoringConfigurationUpdate: S.Schema<ZeppelinMonitoringConfigurationUpdate>;
export interface GlueDataCatalogConfigurationUpdate {
    DatabaseARNUpdate: string;
}
export declare const GlueDataCatalogConfigurationUpdate: S.Schema<GlueDataCatalogConfigurationUpdate>;
export interface CatalogConfigurationUpdate {
    GlueDataCatalogConfigurationUpdate: GlueDataCatalogConfigurationUpdate;
}
export declare const CatalogConfigurationUpdate: S.Schema<CatalogConfigurationUpdate>;
export interface S3ContentBaseLocationUpdate {
    BucketARNUpdate?: string;
    BasePathUpdate?: string;
}
export declare const S3ContentBaseLocationUpdate: S.Schema<S3ContentBaseLocationUpdate>;
export interface DeployAsApplicationConfigurationUpdate {
    S3ContentLocationUpdate?: S3ContentBaseLocationUpdate;
}
export declare const DeployAsApplicationConfigurationUpdate: S.Schema<DeployAsApplicationConfigurationUpdate>;
export interface ZeppelinApplicationConfigurationUpdate {
    MonitoringConfigurationUpdate?: ZeppelinMonitoringConfigurationUpdate;
    CatalogConfigurationUpdate?: CatalogConfigurationUpdate;
    DeployAsApplicationConfigurationUpdate?: DeployAsApplicationConfigurationUpdate;
    CustomArtifactsConfigurationUpdate?: CustomArtifactConfiguration[];
}
export declare const ZeppelinApplicationConfigurationUpdate: S.Schema<ZeppelinApplicationConfigurationUpdate>;
export interface ApplicationEncryptionConfigurationUpdate {
    KeyIdUpdate?: string;
    KeyTypeUpdate: KeyType;
}
export declare const ApplicationEncryptionConfigurationUpdate: S.Schema<ApplicationEncryptionConfigurationUpdate>;
export interface ApplicationConfigurationUpdate {
    SqlApplicationConfigurationUpdate?: SqlApplicationConfigurationUpdate;
    ApplicationCodeConfigurationUpdate?: ApplicationCodeConfigurationUpdate;
    FlinkApplicationConfigurationUpdate?: FlinkApplicationConfigurationUpdate;
    EnvironmentPropertyUpdates?: EnvironmentPropertyUpdates;
    ApplicationSnapshotConfigurationUpdate?: ApplicationSnapshotConfigurationUpdate;
    ApplicationSystemRollbackConfigurationUpdate?: ApplicationSystemRollbackConfigurationUpdate;
    VpcConfigurationUpdates?: VpcConfigurationUpdate[];
    ZeppelinApplicationConfigurationUpdate?: ZeppelinApplicationConfigurationUpdate;
    ApplicationEncryptionConfigurationUpdate?: ApplicationEncryptionConfigurationUpdate;
}
export declare const ApplicationConfigurationUpdate: S.Schema<ApplicationConfigurationUpdate>;
export interface RunConfigurationUpdate {
    FlinkRunConfiguration?: FlinkRunConfiguration;
    ApplicationRestoreConfiguration?: ApplicationRestoreConfiguration;
}
export declare const RunConfigurationUpdate: S.Schema<RunConfigurationUpdate>;
export interface CloudWatchLoggingOptionUpdate {
    CloudWatchLoggingOptionId: string;
    LogStreamARNUpdate?: string;
}
export declare const CloudWatchLoggingOptionUpdate: S.Schema<CloudWatchLoggingOptionUpdate>;
export type CloudWatchLoggingOptionUpdates = CloudWatchLoggingOptionUpdate[];
export declare const CloudWatchLoggingOptionUpdates: any;
export interface UpdateApplicationRequest {
    ApplicationName: string;
    CurrentApplicationVersionId?: number;
    ApplicationConfigurationUpdate?: ApplicationConfigurationUpdate;
    ServiceExecutionRoleUpdate?: string;
    RunConfigurationUpdate?: RunConfigurationUpdate;
    CloudWatchLoggingOptionUpdates?: CloudWatchLoggingOptionUpdate[];
    ConditionalToken?: string;
    RuntimeEnvironmentUpdate?: RuntimeEnvironment;
}
export declare const UpdateApplicationRequest: S.Schema<UpdateApplicationRequest>;
export interface UpdateApplicationResponse {
    ApplicationDetail: ApplicationDetail;
    OperationId?: string;
}
export declare const UpdateApplicationResponse: S.Schema<UpdateApplicationResponse>;
export interface ApplicationMaintenanceConfigurationUpdate {
    ApplicationMaintenanceWindowStartTimeUpdate: string;
}
export declare const ApplicationMaintenanceConfigurationUpdate: S.Schema<ApplicationMaintenanceConfigurationUpdate>;
export interface UpdateApplicationMaintenanceConfigurationRequest {
    ApplicationName: string;
    ApplicationMaintenanceConfigurationUpdate: ApplicationMaintenanceConfigurationUpdate;
}
export declare const UpdateApplicationMaintenanceConfigurationRequest: S.Schema<UpdateApplicationMaintenanceConfigurationRequest>;
export interface UpdateApplicationMaintenanceConfigurationResponse {
    ApplicationARN?: string;
    ApplicationMaintenanceConfigurationDescription?: ApplicationMaintenanceConfigurationDescription;
}
export declare const UpdateApplicationMaintenanceConfigurationResponse: S.Schema<UpdateApplicationMaintenanceConfigurationResponse>;
export type ErrorMessage = string;
export type AddApplicationCloudWatchLoggingOptionError = ConcurrentModificationException | InvalidApplicationConfigurationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Adds an Amazon CloudWatch log stream to monitor application configuration errors.
 */
export declare const addApplicationCloudWatchLoggingOption: API.OperationMethod<AddApplicationCloudWatchLoggingOptionRequest, AddApplicationCloudWatchLoggingOptionResponse, AddApplicationCloudWatchLoggingOptionError, Credentials | HttpClient.HttpClient>;
export type AddApplicationInputError = CodeValidationException | ConcurrentModificationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Adds a streaming source to your SQL-based Kinesis Data Analytics application.
 *
 * You can add a streaming source when you create an application, or you can use this
 * operation to add a streaming source after you create an application. For more information, see
 * CreateApplication.
 *
 * Any configuration update, including adding a streaming source using this operation,
 * results in a new version of the application. You can use the DescribeApplication operation
 * to find the current application version.
 */
export declare const addApplicationInput: API.OperationMethod<AddApplicationInputRequest, AddApplicationInputResponse, AddApplicationInputError, Credentials | HttpClient.HttpClient>;
export type AddApplicationInputProcessingConfigurationError = ConcurrentModificationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Adds an InputProcessingConfiguration to a SQL-based Kinesis Data Analytics application. An input processor pre-processes records
 * on the input stream before the
 * application's SQL code executes. Currently, the only input processor available is Amazon Lambda.
 */
export declare const addApplicationInputProcessingConfiguration: API.OperationMethod<AddApplicationInputProcessingConfigurationRequest, AddApplicationInputProcessingConfigurationResponse, AddApplicationInputProcessingConfigurationError, Credentials | HttpClient.HttpClient>;
export type AddApplicationOutputError = ConcurrentModificationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Adds an external destination to your SQL-based Kinesis Data Analytics application.
 *
 * If you want Kinesis Data Analytics to deliver data from an in-application stream within
 * your application to an external destination (such as an Kinesis data stream, a Kinesis Data
 * Firehose delivery stream, or an Amazon Lambda function), you add the relevant configuration to
 * your application using this operation. You can configure one or more outputs for your
 * application. Each output configuration maps an in-application stream and an external
 * destination.
 *
 * You can use one of the output configurations to deliver data from your
 * in-application error stream to an external destination so that you can analyze the
 * errors.
 *
 * Any configuration update, including adding a streaming source using this
 * operation, results in a new version of the application. You can use the DescribeApplication operation to find the current application
 * version.
 */
export declare const addApplicationOutput: API.OperationMethod<AddApplicationOutputRequest, AddApplicationOutputResponse, AddApplicationOutputError, Credentials | HttpClient.HttpClient>;
export type AddApplicationReferenceDataSourceError = ConcurrentModificationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Adds a reference data source to an existing SQL-based Kinesis Data Analytics application.
 *
 * Kinesis Data Analytics reads reference data (that is, an Amazon S3 object) and creates an
 * in-application table within your application. In the request, you provide the source (S3
 * bucket name and object key name), name of the in-application table to create, and the
 * necessary mapping information that describes how data in an Amazon S3 object maps to columns
 * in the resulting in-application table.
 */
export declare const addApplicationReferenceDataSource: API.OperationMethod<AddApplicationReferenceDataSourceRequest, AddApplicationReferenceDataSourceResponse, AddApplicationReferenceDataSourceError, Credentials | HttpClient.HttpClient>;
export type AddApplicationVpcConfigurationError = ConcurrentModificationException | InvalidApplicationConfigurationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Adds a Virtual Private Cloud (VPC) configuration to the application. Applications can use VPCs to store
 * and access resources securely.
 *
 * Note the following about VPC configurations for Managed Service for Apache Flink applications:
 *
 * - VPC configurations are not supported for SQL applications.
 *
 * - When a VPC is added to a Managed Service for Apache Flink application, the application can no longer be accessed from the
 * Internet directly. To enable Internet access to the application, add an Internet gateway to your VPC.
 */
export declare const addApplicationVpcConfiguration: API.OperationMethod<AddApplicationVpcConfigurationRequest, AddApplicationVpcConfigurationResponse, AddApplicationVpcConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = CodeValidationException | ConcurrentModificationException | InvalidArgumentException | InvalidRequestException | LimitExceededException | ResourceInUseException | TooManyTagsException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a Managed Service for Apache Flink application. For information about creating a
 * Managed Service for Apache Flink application, see Creating an
 * Application.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationPresignedUrlError = InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Creates and returns a URL that you can use to connect to
 * an application's extension.
 *
 * The IAM role or user used to call this API defines the permissions to access the
 * extension. After the presigned URL is created, no additional permission is required to access
 * this URL. IAM authorization policies for this API are also enforced for every HTTP request
 * that attempts to connect to the extension.
 *
 * You control the amount of time that the URL will be valid using the `SessionExpirationDurationInSeconds`
 * parameter. If you do not provide this parameter, the returned URL is valid for twelve hours.
 *
 * The URL that you get from a call to CreateApplicationPresignedUrl must be used within 3 minutes
 * to be valid.
 * If you first try to use the URL after the 3-minute limit expires, the service returns an HTTP 403 Forbidden error.
 */
export declare const createApplicationPresignedUrl: API.OperationMethod<CreateApplicationPresignedUrlRequest, CreateApplicationPresignedUrlResponse, CreateApplicationPresignedUrlError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationSnapshotError = InvalidApplicationConfigurationException | InvalidArgumentException | InvalidRequestException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a snapshot of the application's state data.
 */
export declare const createApplicationSnapshot: API.OperationMethod<CreateApplicationSnapshotRequest, CreateApplicationSnapshotResponse, CreateApplicationSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = ConcurrentModificationException | InvalidApplicationConfigurationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified application. Managed Service for Apache Flink halts application execution and deletes the application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationCloudWatchLoggingOptionError = ConcurrentModificationException | InvalidApplicationConfigurationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Amazon CloudWatch log stream from an SQL-based Kinesis Data Analytics application.
 */
export declare const deleteApplicationCloudWatchLoggingOption: API.OperationMethod<DeleteApplicationCloudWatchLoggingOptionRequest, DeleteApplicationCloudWatchLoggingOptionResponse, DeleteApplicationCloudWatchLoggingOptionError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationInputProcessingConfigurationError = ConcurrentModificationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an InputProcessingConfiguration from an input.
 */
export declare const deleteApplicationInputProcessingConfiguration: API.OperationMethod<DeleteApplicationInputProcessingConfigurationRequest, DeleteApplicationInputProcessingConfigurationResponse, DeleteApplicationInputProcessingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationOutputError = ConcurrentModificationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the output destination configuration from your SQL-based Kinesis Data Analytics application's configuration.
 * Kinesis Data Analytics will no longer write data from
 * the corresponding in-application stream to the external output destination.
 */
export declare const deleteApplicationOutput: API.OperationMethod<DeleteApplicationOutputRequest, DeleteApplicationOutputResponse, DeleteApplicationOutputError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationReferenceDataSourceError = ConcurrentModificationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a reference data source configuration from the specified SQL-based Kinesis Data Analytics application's configuration.
 *
 * If the application is running, Kinesis Data Analytics immediately removes the in-application table
 * that you created using the AddApplicationReferenceDataSource operation.
 */
export declare const deleteApplicationReferenceDataSource: API.OperationMethod<DeleteApplicationReferenceDataSourceRequest, DeleteApplicationReferenceDataSourceResponse, DeleteApplicationReferenceDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationSnapshotError = ConcurrentModificationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes a snapshot of application state.
 */
export declare const deleteApplicationSnapshot: API.OperationMethod<DeleteApplicationSnapshotRequest, DeleteApplicationSnapshotResponse, DeleteApplicationSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationVpcConfigurationError = ConcurrentModificationException | InvalidApplicationConfigurationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Removes a VPC configuration from a Managed Service for Apache Flink application.
 */
export declare const deleteApplicationVpcConfiguration: API.OperationMethod<DeleteApplicationVpcConfigurationRequest, DeleteApplicationVpcConfigurationResponse, DeleteApplicationVpcConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationError = InvalidArgumentException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about a specific Managed Service for Apache Flink application.
 *
 * If you want to retrieve a list of all applications in your account,
 * use the ListApplications operation.
 */
export declare const describeApplication: API.OperationMethod<DescribeApplicationRequest, DescribeApplicationResponse, DescribeApplicationError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationOperationError = InvalidArgumentException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Provides a detailed description of a specified application operation. To see a list of all the operations of an application, invoke the ListApplicationOperations operation.
 *
 * This operation is supported only for Managed Service for Apache Flink.
 */
export declare const describeApplicationOperation: API.OperationMethod<DescribeApplicationOperationRequest, DescribeApplicationOperationResponse, DescribeApplicationOperationError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationSnapshotError = InvalidArgumentException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Returns information about a snapshot of application state data.
 */
export declare const describeApplicationSnapshot: API.OperationMethod<DescribeApplicationSnapshotRequest, DescribeApplicationSnapshotResponse, DescribeApplicationSnapshotError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationVersionError = InvalidArgumentException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Provides a detailed description of a specified version of the application. To see a list of all the versions of an application, invoke the ListApplicationVersions operation.
 *
 * This operation is supported only for Managed Service for Apache Flink.
 */
export declare const describeApplicationVersion: API.OperationMethod<DescribeApplicationVersionRequest, DescribeApplicationVersionResponse, DescribeApplicationVersionError, Credentials | HttpClient.HttpClient>;
export type DiscoverInputSchemaError = InvalidArgumentException | InvalidRequestException | ResourceProvisionedThroughputExceededException | ServiceUnavailableException | UnableToDetectSchemaException | UnsupportedOperationException | CommonErrors;
/**
 * Infers a schema for a SQL-based Kinesis Data Analytics application by evaluating
 * sample records on the specified streaming source (Kinesis data stream or Kinesis Data Firehose
 * delivery stream) or Amazon S3 object. In the response, the operation returns the inferred
 * schema and also the sample records that the operation used to infer the schema.
 *
 * You can use the inferred schema when configuring a streaming source for your application.
 * When you create an application using the Kinesis Data Analytics console, the console uses this
 * operation to infer a schema and show it in the console user interface.
 */
export declare const discoverInputSchema: API.OperationMethod<DiscoverInputSchemaRequest, DiscoverInputSchemaResponse, DiscoverInputSchemaError, Credentials | HttpClient.HttpClient>;
export type ListApplicationOperationsError = InvalidArgumentException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Lists all the operations performed for the specified application such as UpdateApplication, StartApplication etc.
 * The response also includes a summary of the operation.
 *
 * To get the complete description of a specific operation, invoke the DescribeApplicationOperation operation.
 *
 * This operation is supported only for Managed Service for Apache Flink.
 */
export declare const listApplicationOperations: API.PaginatedOperationMethod<ListApplicationOperationsRequest, ListApplicationOperationsResponse, ListApplicationOperationsError, Credentials | HttpClient.HttpClient, ApplicationOperationInfo>;
export type ListApplicationsError = InvalidRequestException | CommonErrors;
/**
 * Returns a list of Managed Service for Apache Flink applications in your account. For each
 * application, the response includes the application name, Amazon Resource Name (ARN), and
 * status.
 *
 * If you want detailed information about a specific application, use
 * DescribeApplication.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListApplicationSnapshotsError = InvalidArgumentException | UnsupportedOperationException | CommonErrors;
/**
 * Lists information about the current application snapshots.
 */
export declare const listApplicationSnapshots: API.PaginatedOperationMethod<ListApplicationSnapshotsRequest, ListApplicationSnapshotsResponse, ListApplicationSnapshotsError, Credentials | HttpClient.HttpClient, SnapshotDetails>;
export type ListApplicationVersionsError = InvalidArgumentException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Lists all the versions for the specified application, including versions that were rolled back. The response also includes a summary of the configuration
 * associated with each version.
 *
 * To get the complete description of a specific application version, invoke the DescribeApplicationVersion operation.
 *
 * This operation is supported only for Managed Service for Apache Flink.
 */
export declare const listApplicationVersions: API.PaginatedOperationMethod<ListApplicationVersionsRequest, ListApplicationVersionsResponse, ListApplicationVersionsError, Credentials | HttpClient.HttpClient, ApplicationVersionSummary>;
export type ListTagsForResourceError = ConcurrentModificationException | InvalidArgumentException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the list of key-value tags assigned to the application. For more information, see
 * Using Tagging.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RollbackApplicationError = ConcurrentModificationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Reverts the application to the previous running version. You can roll back an
 * application if you suspect it is stuck in a transient status or in the running status.
 *
 * You can roll back an application only if it is in the `UPDATING`,
 * `AUTOSCALING`, or `RUNNING` statuses.
 *
 * When you rollback an application, it loads state data from the last successful snapshot.
 * If the application has no snapshots, Managed Service for Apache Flink rejects the rollback request.
 */
export declare const rollbackApplication: API.OperationMethod<RollbackApplicationRequest, RollbackApplicationResponse, RollbackApplicationError, Credentials | HttpClient.HttpClient>;
export type StartApplicationError = InvalidApplicationConfigurationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Starts the specified Managed Service for Apache Flink application. After creating an application, you must exclusively call this operation to
 * start your application.
 */
export declare const startApplication: API.OperationMethod<StartApplicationRequest, StartApplicationResponse, StartApplicationError, Credentials | HttpClient.HttpClient>;
export type StopApplicationError = ConcurrentModificationException | InvalidApplicationConfigurationException | InvalidArgumentException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Stops the application from processing data. You can stop
 * an application only if it is in the running status, unless you set the `Force`
 * parameter to `true`.
 *
 * You can use the DescribeApplication operation to find the application status.
 *
 * Managed Service for Apache Flink takes a snapshot when the application is stopped, unless `Force` is set
 * to `true`.
 */
export declare const stopApplication: API.OperationMethod<StopApplicationRequest, StopApplicationResponse, StopApplicationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Adds one or more key-value tags to a Managed Service for Apache Flink application. Note that the maximum number of application
 * tags includes system tags. The maximum number of user-defined application tags is 50.
 * For more information, see Using Tagging.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Removes one or more tags from a Managed Service for Apache Flink application. For more information, see
 * Using Tagging.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = CodeValidationException | ConcurrentModificationException | InvalidApplicationConfigurationException | InvalidArgumentException | InvalidRequestException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an existing Managed Service for Apache Flink application. Using this operation, you
 * can update application code, input configuration, and output configuration.
 *
 * Managed Service for Apache Flink updates the `ApplicationVersionId` each time you update
 * your application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationMaintenanceConfigurationError = ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Updates the maintenance configuration of the Managed Service for Apache Flink application.
 *
 * You can invoke this operation on an application that is in one of the two following
 * states: `READY` or `RUNNING`. If you invoke it when the application is
 * in a state other than these two states, it throws a `ResourceInUseException`. The
 * service makes use of the updated configuration the next time it schedules maintenance for the
 * application. If you invoke this operation after the service schedules maintenance, the service
 * will apply the configuration update the next time it schedules maintenance for the
 * application. This means that you might not see the maintenance configuration update applied to
 * the maintenance process that follows a successful invocation of this operation, but to the
 * following maintenance process instead.
 *
 * To see the current maintenance configuration of your application, invoke the
 * DescribeApplication operation.
 *
 * For information about application maintenance, see Managed Service for Apache Flink for Apache Flink Maintenance.
 *
 * This operation is supported only for Managed Service for Apache Flink.
 */
export declare const updateApplicationMaintenanceConfiguration: API.OperationMethod<UpdateApplicationMaintenanceConfigurationRequest, UpdateApplicationMaintenanceConfigurationResponse, UpdateApplicationMaintenanceConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=kinesis-analytics-v2.d.ts.map