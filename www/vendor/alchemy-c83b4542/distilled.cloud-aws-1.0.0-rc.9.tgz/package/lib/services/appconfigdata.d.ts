import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly message: any;
    readonly Reason: any;
    readonly Details: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceType: any;
    readonly ReferencedBy: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type Token = string;
export interface GetLatestConfigurationRequest {
    ConfigurationToken: string;
}
export declare const GetLatestConfigurationRequest: S.Schema<GetLatestConfigurationRequest>;
export interface GetLatestConfigurationResponse {
    NextPollConfigurationToken?: string;
    NextPollIntervalInSeconds?: number;
    ContentType?: string;
    Configuration?: T.StreamingOutputBody;
    VersionLabel?: string;
}
export declare const GetLatestConfigurationResponse: S.Schema<GetLatestConfigurationResponse>;
export type Identifier = string;
export type OptionalPollSeconds = number;
export interface StartConfigurationSessionRequest {
    ApplicationIdentifier: string;
    EnvironmentIdentifier: string;
    ConfigurationProfileIdentifier: string;
    RequiredMinimumPollIntervalInSeconds?: number;
}
export declare const StartConfigurationSessionRequest: S.Schema<StartConfigurationSessionRequest>;
export interface StartConfigurationSessionResponse {
    InitialConfigurationToken?: string;
}
export declare const StartConfigurationSessionResponse: S.Schema<StartConfigurationSessionResponse>;
export type BadRequestReason = string;
export type InvalidParameterProblem = string;
export interface InvalidParameterDetail {
    Problem?: string;
}
export declare const InvalidParameterDetail: S.Schema<InvalidParameterDetail>;
export type InvalidParameterMap = {
    [key: string]: InvalidParameterDetail | undefined;
};
export declare const InvalidParameterMap: any;
export type BadRequestDetails = {
    InvalidParameters: {
        [key: string]: InvalidParameterDetail | undefined;
    };
};
export declare const BadRequestDetails: any;
export type ResourceType = string;
export type StringMap = {
    [key: string]: string | undefined;
};
export declare const StringMap: any;
export type GetLatestConfigurationError = BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the latest deployed configuration. This API may return empty configuration
 * data if the client already has the latest version. For more information about this API
 * action and to view example CLI commands that show how to use it with the StartConfigurationSession API action, see Retrieving the
 * configuration in the *AppConfig User Guide*.
 *
 * Note the following important information.
 *
 * - Each configuration token is only valid for one call to
 * `GetLatestConfiguration`. The `GetLatestConfiguration`
 * response includes a `NextPollConfigurationToken` that should always
 * replace the token used for the just-completed call in preparation for the next
 * one.
 *
 * - `GetLatestConfiguration` is a priced call. For more information, see
 * Pricing.
 */
export declare const getLatestConfiguration: API.OperationMethod<GetLatestConfigurationRequest, GetLatestConfigurationResponse, GetLatestConfigurationError, Credentials | HttpClient.HttpClient>;
export type StartConfigurationSessionError = BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts a configuration session used to retrieve a deployed configuration. For more
 * information about this API action and to view example CLI commands that show how to use
 * it with the GetLatestConfiguration API action, see Retrieving the
 * configuration in the *AppConfig User Guide*.
 */
export declare const startConfigurationSession: API.OperationMethod<StartConfigurationSessionRequest, StartConfigurationSessionResponse, StartConfigurationSessionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appconfigdata.d.ts.map